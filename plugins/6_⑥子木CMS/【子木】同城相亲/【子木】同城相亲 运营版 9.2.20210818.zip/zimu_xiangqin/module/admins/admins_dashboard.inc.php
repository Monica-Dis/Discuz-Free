<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    $all_user_nums = DB::result_first("SELECT count(*) FROM %t", array(
        "zimu_xiangqin_users"
    ));

    $today_user_nums = DB::result_first("SELECT count(*) FROM %t where addtime>%d", array(
        "zimu_xiangqin_users",
        strtotime(date('Y-m-d', $_G['timestamp']))
    ));

    $all_user_nums1 = DB::result_first("SELECT count(*) FROM %t where sex=1", array(
        "zimu_xiangqin_users"
    ));

    $today_user_nums1 = DB::result_first("SELECT count(*) FROM %t where sex=1 and addtime>%d", array(
        "zimu_xiangqin_users",
        strtotime(date('Y-m-d', $_G['timestamp']))
    ));

    $all_user_nums2 = DB::result_first("SELECT count(*) FROM %t where sex=2", array(
        "zimu_xiangqin_users"
    ));

    $today_user_nums2 = DB::result_first("SELECT count(*) FROM %t where sex=2 and addtime>%d", array(
        "zimu_xiangqin_users",
        strtotime(date('Y-m-d', $_G['timestamp']))
    ));

    $all_user_nums3 = DB::result_first("SELECT count(*) FROM %t where vip_type > 0", array(
        "zimu_xiangqin_users"
    ));

    $today_user_nums3 = DB::result_first("SELECT count(*) FROM %t where is_paid = 2 and service_name = %s and addtime>%d", array(
        "zimu_xiangqin_order",
        "buyvip",
        strtotime(date('Y-m-d', $_G['timestamp']))
    ));

    $order_nums = DB::result_first("SELECT sum(amount) FROM %t where is_paid=2", array(
        "zimu_xiangqin_order"
    ));

    $order_nums2 = DB::result_first("SELECT sum(amount) FROM %t where is_paid=2 and addtime>%d", array(
        "zimu_xiangqin_order",
        strtotime(date('Y-m-d', $_G['timestamp']))
    ));

    $month_nums = DB::result_first("SELECT sum(amount) FROM %t where is_paid=2 and addtime>=%d and addtime<=%d", array(
        "zimu_xiangqin_order",
        mktime(0,0,0,date('m'),1,date('Y')),
        mktime(23,59,59,date('m'),date('t'),date('Y'))
    ));

    $month_nums2 = DB::result_first("SELECT sum(amount) FROM %t where is_paid=2 and addtime>=%d and addtime<=%d", array(
        "zimu_xiangqin_order",
        strtotime(date('Y-m-01 00:00:00',strtotime('-1 month'))),
        strtotime(date("Y-m-d 23:59:59", strtotime(-date('d').'day')))
    ));


    $audit_user = DB::result_first("SELECT count(*) FROM %t where state=0", array(
        "zimu_xiangqin_users"
    ));

    $audit_again_user = DB::result_first("SELECT count(*) FROM %t", array(
        "zimu_xiangqin_users2"
    ));

    $pyq_user = DB::result_first("SELECT count(*) FROM %t where status=0", array(
        "zimu_xiangqin_pyq"
    ));

    $line_user = DB::result_first("SELECT count(*) FROM %t where status = 1 or status = 2", array(
        "zimu_xiangqin_applyline"
    ));

    $audit_report = DB::result_first("SELECT count(*) FROM %t where status=0", array(
        "zimu_xiangqin_jubao"
    ));



    include zimu_template('admins/admins_'.$type,'');

