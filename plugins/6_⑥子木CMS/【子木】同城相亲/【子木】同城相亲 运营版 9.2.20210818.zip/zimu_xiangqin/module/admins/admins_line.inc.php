<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_xiangqin_applyline', array(
        'id' => $ids
    ));
    
    include template('zimu_xiangqin:common/success');

} else if ($op == 'changeline') {

    $ids = intval($_GET['ids']);
    $line_note = zimu_array_gbk(strip_tags($_GET['line_note']));
    $linestatus = intval($_GET['linestatus']);
    if($linestatus==4 && !$line_note){

        zimu_json('',$language_zimu['admins_line_inc_php_0'],202);exit();

    }

    $lineuid = DB::result_first('select uid from %t where id=%d', array(
        'zimu_xiangqin_applyline',
        $ids
    ));

    $smsinfo = DB::fetch_first('select * from %t where uid=%d', array(
        'zimu_xiangqin_users',
        $lineuid
    ));

    if($linestatus==3 || $linestatus==4){

        DB::query("update %t set note=%s,status=%d,endtime=%d where id=%d", array(
            'zimu_xiangqin_applyline',
            $line_note,
            $linestatus,
            time(),
            $ids
        ));

        if($linestatus==3) {
            notification_user_sms($smsinfo, 'chanyoo_sms_tp2');
        }

        if($linestatus==4 && !$zmdata['settings']['line_back']){
            if($smsinfo['vip_type'] > 0 && $smsinfo['vip_etime'] > time() ){
                DB::query("update %t set line_num=line_num+1 where uid=%d", array(
                    'zimu_xiangqin_users',
                    $lineuid
                ));
                $crm_feedback['uid']     = $lineuid;
                $crm_feedback['note']       = $language_zimu['admins_line_inc_php_1'];
                $crm_feedback['addtime']     = time();
                DB::insert('zimu_xiangqin_feedback', $crm_feedback);
            }else{
                DB::query("update %t set line_num2=line_num2+1 where uid=%d", array(
                    'zimu_xiangqin_users',
                    $lineuid
                ));
                $crm_feedback['uid']     = $lineuid;
                $crm_feedback['note']       = $language_zimu['admins_line_inc_php_2'];
                $crm_feedback['addtime']     = time();
                DB::insert('zimu_xiangqin_feedback', $crm_feedback);
            }
            notification_user_sms($smsinfo,'chanyoo_sms_tp3');
        }
    }else{
        DB::query("update %t set note=%s,status=%d where id=%d", array(
            'zimu_xiangqin_applyline',
            $line_note,
            $linestatus,
            $ids
        ));
    }

    zimu_json('',$language_zimu['admins_line_inc_php_3']);

} else {
    
    $wheresql = 'where 1=1 ';
    $whereorder = 'id';

    $status = intval($_GET['status']);
    if (!empty($status)) {
        $wheresql .= " and status = ".($status-1);
    }

    $keywordtype = intval($_GET['keywordtype']);
    $keyword = trim($_GET['keyword']);
    $keyword = dhtmlspecialchars($keyword);
    $keyword = stripsearchkey($keyword);
    $keyword = daddslashes($keyword);

    if (!empty($keyword)) {
        if ($keywordtype == 1) {
            $wheresql .= " and `uid` = '{$keyword}' ";
        } elseif ($keywordtype == 2) {
            $wheresql .= " and `username` LIKE '%{$keyword}%' ";
        } elseif ($keywordtype == 3) {
            $wheresql .= " and `touid` = '{$keyword}' ";
        } elseif ($keywordtype == 4) {
            $wheresql .= " and `tousername` LIKE '%{$keyword}%' ";
        }
    }

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_xiangqin_applyline",
        $wheresql
    ));


    $listdata = DB::fetch_all('select * from %t %i order by %i desc limit %d,%d', array(
        'zimu_xiangqin_applyline',
        $wheresql,
        $whereorder,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type,'');
    
    
}