<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';

    if ($op == 'edit') {

        if (submitcheck('submit')) {


            $data['cat']        = strip_tags($_GET['cat']);
            $data['name']        = strip_tags($_GET['name']);
            $data['value']         = intval($_GET['value']);
            $data['price']        = strip_tags($_GET['price']);
            $data['sort']        = intval($_GET['sort']);
            $data['id']      = intval($_GET['ids']);


            if ($data['id'] > 0) {

                DB::update('zimu_xiangqin_setmeal_increment', $data, array(
                    'id' => $data['id']
                ));

            } else {

                $result = DB::insert('zimu_xiangqin_setmeal_increment', $data, 1);

            }


            include template('zimu_xiangqin:common/success');


        } else {

            $ids = intval($_GET['ids']);

            $listdata = DB::fetch_first('select * from %t where id=%d', array(
                'zimu_xiangqin_setmeal_increment',
                $ids
            ));

            include zimu_template('admins/admins_' . $type,'');

        }


    } else if ($op == 'del' && $_GET['md5hash'] == formhash()) {

        $ids = intval($_GET['ids']);

        $result = DB::delete('zimu_xiangqin_setmeal_increment', array(
            'id' => $ids
        ));

        include template('zimu_xiangqin:common/success');


    } else {

        $wheresql = 'where 1=1 ';

        $pindex = max(1, intval($_GET['page']));
        $psize  = 100;

        $listdata = DB::fetch_all('select * from %t %i order by id asc limit %d,%d', array(
            'zimu_xiangqin_setmeal_increment',
            $wheresql,
            ($pindex - 1) * $psize,
            $psize
        ));

        $pager = pagination($total, $pindex, $psize);


        include zimu_template('admins/admins_' . $type,'');


    }