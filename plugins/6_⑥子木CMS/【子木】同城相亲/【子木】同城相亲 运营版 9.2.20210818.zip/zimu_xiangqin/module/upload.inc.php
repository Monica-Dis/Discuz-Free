<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);
    $op = addslashes($_GET['op']);

    if ($op == 'wximg') {

        $config_params = savepic('album');

        $data = array(
            'imgurl' => $config_params['show_path']
        );

        $album_data['uid'] = $myuid['uid'];
        $album_data['url'] = $config_params['show_path'];
        $album_data['sort'] = 100;
        Db::name('zimu_xiangqin_users_album')->insert($album_data);

        zimu_json($data);

    }else if ($op == 'towximg'){

        $config_params = savepic('album',0);

        $data = array(
            'imgurl' => $config_params['show_path']
        );
        zimu_json($data);

    }

function savepic($type,$oss=1){
    global $_G;

    $config_params = array(
        'upload_ok' => false,
        'save_path' => '',
        'show_path' => ''
    );
    $filename      = uniqid() . '.jpg';
    $pic           = base64_decode($_GET['base64_string']);
    $sids = $_GET['serverId'];

    if(!$pic && !$sids){

        $picurl = zm_saveimages($_FILES[$type]);
        $config_params['save_path'] = $picurl;
        $config_params['show_path'] = $picurl;
        $config_params['upload_ok'] = true;
        return $config_params;

    }

    $date        = date('ym/d/');
    $save_avatar = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date;

    if (!is_dir($save_avatar)) {
        mkdir($save_avatar, 0777, true);
    }

    if($sids){

    require_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/class/wechat.lib.class.php';
    $wechat_client = new WeChatClient(SF_APPID, SF_APPSECRET);
    $temp = $wechat_client->download($sids);
    if(!empty($temp)) {
            $content = '';
            if (preg_match('/^(http|\.)/i', $temp)) {
                $content = zm_curl($temp);
            }else{
                $content = $temp;
            }
                $fp = fopen($save_avatar . $filename, 'wb');
                flock($fp, 2);
                fwrite($fp, $content);
                fclose($fp);
    }


    }else{

    file_put_contents($save_avatar . $filename, $pic);

    }

    require_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/class/imgcompress.class.php';
    $source = DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date . $filename;
    $dst_img = DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date . $filename;
    $percent = 0.5;
    $image = (new imgcompress($source,$percent))->compressImg($dst_img);

        $oss_paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'alioss')->find();
        $oss_paramter = unserialize($oss_paramter['parameter']);

    if(!$oss_paramter['oss_type'] && $oss_paramter['ACCESS_ID'] && $oss_paramter['ACCESS_KEY'] && $oss_paramter['ENDPOINT'] && $oss_paramter['BUCKET']){
        $saved_file = DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date . $filename;
        include_once DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/OSS/Common.php';
        if ($surl = zm_oss_upload('zimu_xiangqin/'. $type . '/' . $date . $filename, $saved_file)) {
            @unlink($saved_file);
            $imgurl = $surl;
            $config_params['save_path'] = $imgurl;
            $config_params['show_path'] = $imgurl;
            $config_params['upload_ok'] = true;
            return $config_params;
            exit();
        }
    }elseif ($oss_paramter['oss_type']==1 && $oss_paramter['qn_ak'] && $oss_paramter['qn_sk'] && $oss_paramter['qn_bk']){

        $saved_file = DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date . $filename;
        include_once(DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/Qiniu/upload.php');
        if ($surl=zm_qn_upload('zimu_xiangqin/'. $type . '/' . $date . $filename,$saved_file)) {
            unlink($saved_file);
            error_reporting(0);
            $imgurl = $surl;
            $config_params['save_path'] = $imgurl;
            $config_params['show_path'] = $imgurl;
            $config_params['upload_ok'] = true;
            return $config_params;
        }

    }

    $config_params['save_path'] = '/source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date . $filename;
    $config_params['show_path'] = $_G['siteurl'] . 'source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date . $filename;
    $config_params['upload_ok'] = true;
    return $config_params;
    
}