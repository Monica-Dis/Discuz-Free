<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);
    $op = addslashes($_GET['op']);
    $zimu_get = zimu_array_gbk($_GET);

    if($op == 'buyvip') {

        $ids = intval($_GET['ids']);
        $setmeal = Db::name('zimu_xiangqin_setmeal')->where('id', $ids)->find();
        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();

        if($myinfo['sex']==2 && $zmdata['settings']['women_vip']>0){
            $setmeal['expense'] = intval($setmeal['expense']*$zmdata['settings']['women_vip']/100)>0 ? intval($setmeal['expense']*$zmdata['settings']['women_vip']/100) : 1;
        }

        $params['oid'] = date('YmdHis') . mt_rand(100000, 999999);
        $params['uid'] = $myinfo['uid'];
        $params['openid'] = $myuid['openid'];
        $params['pay_type'] = 2;
        $params['is_paid'] = 1;
        $params['amount'] = $setmeal['expense']/100;
        $params['pay_amount'] = $setmeal['expense']/100;
        $params['payment'] = 'wxpay';
        $params['payment_cn'] = $language_zimu['vip_inc_php_0'];
        $params['description'] = $language_zimu['vip_inc_php_1'].$setmeal['setmeal_name'];
        $params['service_name'] = 'buyvip';
        $params_array['setmeal_name'] = $setmeal['setmeal_name'];
        $params_array['setmeal_id'] = $setmeal['id'];
        $params_array['days'] = $setmeal['days'];
        $params_array['line'] = $setmeal['line'];
        $params_array['days2'] = $setmeal['days2'];
        $params['params'] = serialize($params_array);
        $params['addtime'] = $_G['timestamp'];

        $return_order_info['order_id'] = Db::name('zimu_xiangqin_order')->insertGetId($params);

        zimu_json($return_order_info);



    }else{

        $info['setmeal'] = Db::name('zimu_xiangqin_setmeal')->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();
        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();
        $myinfo['vip_etime_cn'] = $myinfo['vip_etime']>0 ? $language_zimu['vip_inc_php_2'].date('Y-m-d',$myinfo['vip_etime']) : $language_zimu['vip_inc_php_3'];
        $info['myinfo'] = $myinfo;
        $info['zmdata'] = $zmdata2;

        if($myinfo['sex']==2 && $zmdata['settings']['women_vip']>0){
            foreach ($info['setmeal'] as $key => $value){
                $info['setmeal'][$key]['expense'] = intval($value['expense']*$zmdata['settings']['women_vip']/100)>0 ? intval($value['expense']*$zmdata['settings']['women_vip']/100) : 1;
            }
        }

        zimu_json($info);

    }