<?php

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE  IF EXISTS pre_zimu_xiangqin_applyline;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_baodeng;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_feedback;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_jubao;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_order;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_parameter2;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_pyq;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_reallog;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_setmeal;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_setmeal_increment;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_setting;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_smslog;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_token;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_users;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_users2;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_users_album;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_users_fav;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_users_ideal;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_viewlog;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_mptpl;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_kefu;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_sendsmslog;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_qmhn_user;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_qmhn_log;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_activity;
DROP TABLE  IF EXISTS pre_zimu_xiangqin_activity_user;

EOF;

runquery($sql);

deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_xiangqin/uploadzimucms");

deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_xiangqin/static/kindeditor/attached/image");


$finish = TRUE;



function deldirfile($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }

    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @deldirfile($path, $empty);
                } else {
                    @unlink($path);
                }
            }
        }

        @closedir($directoryHandle);

        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }

        return true;
    }
}
function deletecache($cachenames) {  
    if(!empty($cachenames)) {  
  DB::delete('common_syscache', array('cname' => $cachenames));
    }  
}