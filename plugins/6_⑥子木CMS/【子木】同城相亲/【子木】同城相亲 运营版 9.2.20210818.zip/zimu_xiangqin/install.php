<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_applyline` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(30) NOT NULL,
  `touid` int(10) UNSIGNED NOT NULL,
  `tousername` char(30) NOT NULL,
  `hn_id` tinyint(3) UNSIGNED NOT NULL,
  `hn_name` char(30) NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL,
  `note` varchar(1000) NOT NULL,
  `applytime` int(10) UNSIGNED NOT NULL,
  `endtime` int(10) UNSIGNED NOT NULL,
  `viewtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_baodeng` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(30) NOT NULL,
  `photo` char(255) NOT NULL,
  `touid` int(10) UNSIGNED NOT NULL,
  `tousername` char(30) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_feedback` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `note` varchar(3000) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_jubao` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(30) NOT NULL,
  `touid` int(10) UNSIGNED NOT NULL,
  `tousername` char(30) NOT NULL,
  `type` char(100) NOT NULL,
  `con` varchar(3000) NOT NULL,
  `myname` char(30) NOT NULL,
  `myphone` char(20) NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL,
  `ip` char(30) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_order` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `oid` varchar(200) NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `openid` varchar(1000) NOT NULL,
  `pay_type` tinyint(1) UNSIGNED NOT NULL,
  `is_paid` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `order_sn` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `pay_amount` decimal(10,2) NOT NULL,
  `pay_points` int(10) UNSIGNED NOT NULL,
  `payment` varchar(20) NOT NULL,
  `payment_cn` varchar(20) NOT NULL,
  `description` varchar(150) NOT NULL,
  `service_name` varchar(30) NOT NULL,
  `params` text NOT NULL,
  `notes` varchar(150) NOT NULL,
  `addtime` int(11) UNSIGNED NOT NULL,
  `payment_time` int(10) UNSIGNED NOT NULL,
  `referer` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `payment_name` (`payment`),
  KEY `oid` (`oid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_parameter2` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  `parameter` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_pyq` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(30) NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL,
  `note` varchar(5000) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_reallog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `realname` char(20) NOT NULL,
  `mobile` char(20) NOT NULL,
  `idcard` char(30) NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL,
  `res` varchar(10000) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_setmeal` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `setmeal_name` char(30) NOT NULL,
  `days` smallint(3) UNSIGNED NOT NULL,
  `expense` int(10) UNSIGNED NOT NULL,
  `line` tinyint(3) UNSIGNED NOT NULL,
  `days2` smallint(3) UNSIGNED NOT NULL,
  `tip` char(100) NOT NULL,
  `note` varchar(5000) NOT NULL,
  `sort` tinyint(3) UNSIGNED NOT NULL DEFAULT '100',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_setmeal_increment` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `cat` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `value` int(10) UNSIGNED NOT NULL,
  `price` varchar(10) NOT NULL,
  `sort` int(10) UNSIGNED NOT NULL DEFAULT '100',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_setting` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `settings` longtext NOT NULL,
  `notifytext` text NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_smslog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `mobile` char(20) NOT NULL,
  `code` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_token` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(50) NOT NULL,
  `token` char(255) NOT NULL,
  `openid` char(255) NOT NULL,
  `unionid` char(255) NOT NULL,
  `xcx_openid` char(255) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `no` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `nickname` char(50) NOT NULL,
  `realname` char(30) NOT NULL,
  `photo` char(255) NOT NULL,
  `sex` tinyint(1) UNSIGNED NOT NULL,
  `xueli` tinyint(2) UNSIGNED NOT NULL,
  `yuexin` tinyint(2) UNSIGNED NOT NULL,
  `birth` char(30) NOT NULL,
  `age` smallint(2) UNSIGNED NOT NULL,
  `shuxiang` tinyint(2) UNSIGNED NOT NULL,
  `constellation` tinyint(2) UNSIGNED NOT NULL,
  `city` char(20) NOT NULL,
  `city2` char(20) NOT NULL,
  `height` smallint(3) UNSIGNED NOT NULL,
  `weight` smallint(3) UNSIGNED NOT NULL,
  `ganqing` tinyint(1) UNSIGNED NOT NULL,
  `work` tinyint(2) UNSIGNED NOT NULL,
  `zhufang` tinyint(1) UNSIGNED NOT NULL,
  `gouche` tinyint(1) UNSIGNED NOT NULL,
  `xiyan` tinyint(1) UNSIGNED NOT NULL,
  `hejiu` tinyint(1) UNSIGNED NOT NULL,
  `xingge` char(100) NOT NULL,
  `aihao` char(100) NOT NULL,
  `intro` varchar(3000) NOT NULL,
  `weixin` char(30) NOT NULL,
  `mobile` char(20) NOT NULL,
  `openid` char(255) NOT NULL,
  `state` tinyint(1) UNSIGNED NOT NULL,
  `state_note` varchar(1000) NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `guesthide` tinyint(1) UNSIGNED NOT NULL,
  `ispay` tinyint(1) UNSIGNED NOT NULL,
  `real_state` tinyint(1) UNSIGNED NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `vip_type` tinyint(1) UNSIGNED NOT NULL,
  `vip_name` char(50) NOT NULL,
  `vip_etime` int(10) UNSIGNED NOT NULL,
  `line_num` smallint(5) UNSIGNED NOT NULL,
  `line_num2` smallint(5) UNSIGNED NOT NULL,
  `toptime` int(10) UNSIGNED NOT NULL,
  `hn_uid` int(10) UNSIGNED NOT NULL,
  `hn_name` char(30) NOT NULL,
  `hn_say` varchar(3000) NOT NULL,
  `remark` varchar(5000) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  `refreshtime` int(10) UNSIGNED NOT NULL,
  `bind_weixin` tinyint(1) UNSIGNED NOT NULL,
  `isindex` smallint(3) UNSIGNED NOT NULL,
  `isqmhn` smallint(3) UNSIGNED NOT NULL,
  `qmhn_uid` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_users2` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `nickname` char(50) NOT NULL,
  `photo` char(255) NOT NULL,
  `xueli` tinyint(2) UNSIGNED NOT NULL,
  `yuexin` tinyint(2) UNSIGNED NOT NULL,
  `birth` char(30) NOT NULL,
  `age` smallint(2) UNSIGNED NOT NULL,
  `shuxiang` tinyint(2) UNSIGNED NOT NULL,
  `constellation` tinyint(2) UNSIGNED NOT NULL,
  `city` char(20) NOT NULL,
  `city2` char(20) NOT NULL,
  `height` smallint(3) UNSIGNED NOT NULL,
  `weight` smallint(3) UNSIGNED NOT NULL,
  `ganqing` tinyint(1) UNSIGNED NOT NULL,
  `work` tinyint(2) UNSIGNED NOT NULL,
  `zhufang` tinyint(1) UNSIGNED NOT NULL,
  `gouche` tinyint(1) UNSIGNED NOT NULL,
  `xiyan` tinyint(1) UNSIGNED NOT NULL,
  `hejiu` tinyint(1) UNSIGNED NOT NULL,
  `weixin` char(30) NOT NULL,
  `mobile` char(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_users_album` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `url` char(255) NOT NULL,
  `sort` smallint(2) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_users_fav` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `touid` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_users_ideal` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `age` char(20) NOT NULL,
  `age_cn` char(30) NOT NULL,
  `heights` char(20) NOT NULL,
  `heights_cn` char(30) NOT NULL,
  `xueli` char(20) NOT NULL,
  `xueli_cn` char(200) NOT NULL,
  `yuexin` tinyint(2) UNSIGNED NOT NULL,
  `work` char(50) NOT NULL,
  `work_cn` char(200) NOT NULL,
  `ganqing` char(20) NOT NULL,
  `ganqing_cn` char(200) NOT NULL,
  `zhufang` tinyint(2) UNSIGNED NOT NULL,
  `xiyan` tinyint(2) UNSIGNED NOT NULL,
  `hejiu` tinyint(2) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_viewlog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `touid` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_mptpl` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tpl` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_kefu` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `kefu_name` char(30) NOT NULL,
  `kefu_photo` char(255) NOT NULL,
  `kefu_mobile` char(20) NOT NULL,
  `kefu_wxid` char(20) NOT NULL,
  `kefu_qrcode_url` char(255) NOT NULL,
  `kefu_slogan` char(100) NOT NULL,
  `kefu_power` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_sendsmslog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `mobile` char(20) NOT NULL,
  `con` varchar(300) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_qmhn_user` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(20) NOT NULL,
  `mobile` char(20) NOT NULL,
  `weixin` char(20) NOT NULL,
  `can_cash` int(10) UNSIGNED NOT NULL,
  `cash` int(10) UNSIGNED NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL,
  `tip` char(200) NOT NULL,
  `tixian_log` text NOT NULL,
  `addtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_qmhn_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `touid` int(10) UNSIGNED NOT NULL,
  `money` int(10) UNSIGNED NOT NULL,
  `type` char(30) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_activity` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(1000) NOT NULL,
  `price` int(10) UNSIGNED NOT NULL,
  `vip_price` int(10) UNSIGNED NOT NULL,
  `realname` tinyint(1) UNSIGNED NOT NULL,
  `starttime` int(10) UNSIGNED NOT NULL,
  `endtime` int(10) UNSIGNED NOT NULL,
  `activitytime` int(10) UNSIGNED NOT NULL,
  `all_nums` int(10) UNSIGNED NOT NULL,
  `men_nums` int(10) UNSIGNED NOT NULL,
  `women_nums` int(10) UNSIGNED NOT NULL,
  `thumb` char(255) NOT NULL,
  `address` char(255) NOT NULL,
  `con` longtext NOT NULL,
  `url` char(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_activity_user` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `aid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `name` char(100) NOT NULL,
  `sex` tinyint(1) UNSIGNED NOT NULL,
  `photo` char(255) NOT NULL,
  `weixin` char(100) NOT NULL,
  `mobile` char(20) NOT NULL,
  `isvip` tinyint(1) UNSIGNED NOT NULL,
  `ispay` tinyint(1) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

SQL;

runquery($sql);

$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3ppbXVfeGlhbmdxaW4vaDUvaW5kZXggY29weS5odG1s'));
?>