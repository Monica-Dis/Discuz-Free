<?php
/*
��ľCMS http://www.zimucms.com/
CopyRight 2016 All Rights Reserved
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$zmdata = (array) unserialize($_G['setting']['zimucms_weixin']);

$model = 'base';

if ($model == 'base') {
    
    if (!submitcheck('basesubmit')) {
        
        showformheader("plugins&operation=config&do=" . $pluginid . "&identifier=" . $plugin['identifier'] . "&pmod=Admin_base&model=base", "enctype");
        
        
        showtableheader(lang('plugin/zimucms_weixin', 'system_text1'));
        showsetting(lang('plugin/zimucms_weixin', 'system_text2'), 'zmdata[weixin_appid]', $zmdata['weixin_appid'], 'text', '', 0);
        showsetting(lang('plugin/zimucms_weixin', 'system_text3'), 'zmdata[weixin_appsecret]', $zmdata['weixin_appsecret'], 'text', '', 0);
        showtablefooter();/*dis'.'m.tao'.'bao.com*/
        
        showtableheader(lang('plugin/zimucms_weixin', 'system_text21'));
        showsetting(lang('plugin/zimucms_weixin', 'system_text22'), 'zmdata[weixin_oauth_domain]', $zmdata['weixin_oauth_domain'], 'text');
        
        
        showsetting(lang('plugin/zimucms_weixin', 'system_text23'), '', '', lang('plugin/zimucms_weixin', 'system_text24'));
        
        showtablefooter();/*dis'.'m.tao'.'bao.com*/
        

        showtableheader(lang('plugin/zimucms_weixin', 'system_text13'));
        showsetting(lang('plugin/zimucms_weixin', 'system_text14'), 'zmdata[weixin_name]', $zmdata['weixin_name'], 'text');
        showsetting(lang('plugin/zimucms_weixin', 'system_text69'), 'zmdata[weixin_desc]', $zmdata['weixin_desc'], 'text');


        if ($zmdata['weixin_icon']) {
            showsetting(lang('plugin/zimucms_weixin', 'system_text68'), 'zmdata[weixin_icon]', $zmdata['weixin_icon'], 'text', '', 0, imglable($zmdata['weixin_icon']));
        } else {
            showsetting(lang('plugin/zimucms_weixin', 'system_text68'), 'zmdata[weixin_icon]', $zmdata['weixin_icon'], 'text');
            
        }

        if ($zmdata['weixin_qrcode']) {
            showsetting(lang('plugin/zimucms_weixin', 'system_text15'), 'zmdata[weixin_qrcode]', $zmdata['weixin_qrcode'], 'text', '', 0, imglable($zmdata['weixin_qrcode']));
        } else {
            showsetting(lang('plugin/zimucms_weixin', 'system_text15'), 'zmdata[weixin_qrcode]', $zmdata['weixin_qrcode'], 'text');
            
        }
        
        showtablefooter();/*dis'.'m.tao'.'bao.com*/
        


        showtableheader();
        showsubmit('basesubmit');
        showtablefooter();/*dis'.'m.tao'.'bao.com*/
        showformfooter();


    } else {
        
        require_once DISCUZ_ROOT . './source/plugin/zimucms_weixin/class/wechat.lib.class.php';
        $wechat_client = new WeChatClient($_GET['zmdata']['weixin_appid'], $_GET['zmdata']['weixin_appsecret']);
        $token         = $wechat_client->getAccessToken(1,0);
        if (!$token) {
            cpmsg(lang('plugin/zimucms_weixin', 'system_text25'), '', 'error');
        }
        
        $r = true;
        if (!empty($_GET['zmdata']['apiclient_cert'])) {
            $ret = file_put_contents(DISCUZ_ROOT . './source/plugin/zimucms_weixin/pay/cacert/apiclient_cert.pem', trim($_GET['zmdata']['apiclient_cert']));
            $r   = $r && $ret;
        }
        if (!empty($_GET['zmdata']['apiclient_key'])) {
            $ret = file_put_contents(DISCUZ_ROOT . '/source/plugin/zimucms_weixin/pay/cacert/apiclient_key.pem', trim($_GET['zmdata']['apiclient_key']));
            $r   = $r && $ret;
        }
        if (!$r) {
            cpmsg(lang('plugin/zimucms_weixin', 'system_text26'), '', 'error');
        }
        
        
        $zmdata = array(
            'zimucms_weixin' => serialize($_GET['zmdata'] + $zmdata)
        );
        C::t('common_setting')->update_batch($zmdata);
        updatecache('setting');
        
        
        cpmsg(lang('plugin/zimucms_weixin', 'system_text27'), "action=plugins&operation=config&do=" . $pluginid . "&identifier=" . $plugin['identifier'] . "&pmod=Admin_base&model=base", "succeed");
        
    }
    
    
}


function imglable($src, $comment = '')
{
    global $_G;
    return $src ? "<img width='128' height='128' src='$src' /><label>" . $comment . '</label>' : '';
}