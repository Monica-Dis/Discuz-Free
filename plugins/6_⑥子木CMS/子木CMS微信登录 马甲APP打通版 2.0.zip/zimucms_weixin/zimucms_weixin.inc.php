<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: [DisM!] (C)2001-2099 DisM Inc..
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once DISCUZ_ROOT . './source/plugin/zimucms_weixin/function.php';
global $_G;
$zmdata  = (array) unserialize($_G['setting']['zimucms_weixin']);
$model   = addslashes($_GET['model']);
//$referer = dreferer();

$referer = $_G['siteurl'] . $_SERVER['REQUEST_URI'];

$referer = urldecode(urldecode(urldecode($referer)));

$referer2 = explode('referer=',$referer);

if($referer2[2]){
$referer = $referer2[2];
}else if($referer2[1]){
$referer = $referer2[1];
}else{
$referer = dreferer();
}
$referer = str_replace("/&","/?1=1&",$referer);
$referer = str_replace(".html&",".html?1=1&",$referer);
$referer = str_replace(".php&",".php?1=1&",$referer);

require_once DISCUZ_ROOT . './source/plugin/zimucms_weixin/class/wechat.lib.class.php';
$wechat_client = new WeChatClient($zmdata['weixin_appid'], $zmdata['weixin_appsecret']);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
if ($model == 'OAuth') {
    $hash = addslashes($_GET['hash']);
    if ($hash) {
        $ispcuid = C::t("#zimucms_weixin#zimucms_weixin_authcode")->fetch_by_hash($hash);
        if ($ispcuid['uid'] > 0) {
            require_once libfile('function/member');
            $member     = getuserbyuid($ispcuid['uid'], 1);
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
        }
    }
    
    
    if ($_GET['code']) {
        $token = $wechat_client->getAccessTokenByCode($_GET['code']);
        if (!$token['openid']) {
            showmessage(lang('plugin/zimucms_weixin', 'system_text50') . ($token['errmsg'] ? ' AccessToken: ' . $token['errmsg'] : ''), $referer);
        }
        
        $referer = $referer . (strpos($referer, '?') ? '&' : '?') . 'code=' . $_GET['code'] . '&state=' . $_GET['state'];
        
        $snsapi_userinfo = in_array('snsapi_userinfo', explode(',', $token['scope'])) ? true : false;
        
        if (!$snsapi_userinfo) {
            $info = $wechat_client->getUserInfoById($token['openid'], 'zh_CN');
            if ($info['openid']) {
                $userinfo = $info;
            } else {

if(strpos($zmdata['weixin_oauth_domain'],'oauth2.htm') !== false){

            $login_url = $zmdata['weixin_oauth_domain'].'?appid='.$zmdata['weixin_appid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri=' . urlencode( $_G['setting'][siteurl] .  '/plugin.php?id=zimucms_weixin&model=OAuth&hash=' . $_GET['hash'] . '&getinfo=' . $_GET['getinfo'] . '&iszhuce=' .$_GET['iszhuce']. '&referer=' . urlencode($_GET['referer']));

}else{

            $login_url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $zmdata['weixin_appid'] . '&redirect_uri=' . urlencode($zmdata['weixin_oauth_domain'] . '/plugin.php?id=zimucms_weixin&model=OAuth&hash=' . $_GET['hash'] . '&getinfo=' . $_GET['getinfo'] . '&iszhuce=' .$_GET['iszhuce']. '&referer=' . urlencode($_GET['referer'])) . '&response_type=code&scope=snsapi_userinfo&state=' . md5(FORMHASH) . '#wechat_redirect';
}
                dheader('Location:' . $login_url);


            }
        } else {
            $userinfo = $wechat_client->getUserInfoByAuth($token['access_token'], $token['openid']);
        }
        
        if ($userinfo['errcode']) {
            showmessage(lang('plugin/zimucms_weixin', 'system_text50') . ($userinfo['errmsg'] ? ' UserInfo: ' . $userinfo['errmsg'] : ''));
        }
        
        if ($_GET['getinfo']) {
            set_oauth_cookie($userinfo, $token);
            dheader('Location:' . $referer);
        }
        
        require_once libfile('function/member');

        if ($token['unionid']) {
            
            
            if ($zmdata['discuz_isappbyme']) {

            $bind_member = checkbind_member($token['unionid']);

            } else {
                $bind_member = C::t('#zimucms_weixin#zimucms_weixin_binduser')->fetch_by_unionid($token['unionid']);
            }
            
            
            
        }
        if (empty($bind_member) && $userinfo['unionid']) {
            
            
            if ($zmdata['discuz_isappbyme']) {

            $bind_member = checkbind_member($userinfo['unionid']);

            } else {
                $bind_member = C::t('#zimucms_weixin#zimucms_weixin_binduser')->fetch_by_unionid($userinfo['unionid']);
            }
        }
        
        if (empty($bind_member) && $token['openid']) {
            $bind_member = C::t('#zimucms_weixin#zimucms_weixin_binduser')->fetch_by_openid($token['openid']);
        }
        if (empty($bind_member) && $userinfo['openid']) {
            $bind_member = C::t('#zimucms_weixin#zimucms_weixin_binduser')->fetch_by_openid($userinfo['openid']);
        }
        if(!$ZIMUCMS_MYUSER){exit();}
        if ($bind_member) {
            $member = getuserbyuid($bind_member['uid']);
            if (empty($member)) {
                C::t('#zimucms_weixin#zimucms_weixin_binduser')->delete($bind_member['id']);
                unset($bind_member);
            }
        }

        if ($_GET['hash'] && $bind_member && $bind_member['uid'] != $_G['uid'] && $_G['uid']>0) {
            //$referer2 = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
            require_once libfile('function/misc');
            loaducenter();
            uc_user_synlogout();
            clearcookies();
            $_G['groupid'] = $_G['member']['groupid'] = 7;
            $_G['uid'] = $_G['member']['uid'] = 0;
            $_G['username'] = $_G['member']['username'] = $_G['member']['password'] = '';
            /*
            showmessage(lang('plugin/zimucms_weixin', 'system_text51'), 'home.php?mod=space&do=profile', array(
                'username' => $_G['member']['username']
                ));
            */
        }

        if ($_G['uid']) {
            
            if ($bindmember2 = C::t('#zimucms_weixin#zimucms_weixin_binduser')->fetch_by_uid($_G['uid'])) {
                $_G['member']['openid']     = $bindmember2['openid'];
                $_G['member']['unionid']    = $bindmember2['unionid'];
                $_G['member']['subscribe']  = $bindmember2['subscribe'] == 1 ? 1 : 0;
                $_G['member']['isregister'] = $bindmember2['isregister'];
                unset($bindmember2);
            }
            if(!$_GET['hash']){
            $isbind = DB::fetch_first("SELECT * FROM %t WHERE userid = %d", array('user_weixin_relations',$_G['uid']));

            if ($isbind && $isbind['userid'] != $_G['uid']){
                showmessage(lang('plugin/zimucms_weixin', 'system_text60'), $referer);
                exit();
            }

            }
            if (empty($bind_member)) {
                C::t('#zimucms_weixin#zimucms_weixin_binduser')->insert(array(
                    'openid' => $userinfo['openid'],
                    'uid' => $_G['uid'],
                    'username' => $_G['username'],
                    'nickname' => dhtmlspecialchars(diconv($userinfo['nickname'], 'utf-8', CHARSET)),
                    'sex' => intval($userinfo['sex']),
                    'dateline' => TIMESTAMP,
                    'unionid' => $userinfo['unionid'],
                    'lastauth' => TIMESTAMP,
                    'counts' => 1,
                    'status' => '1',
                    'subscribe' => $userinfo['subscribe']
                ));
                if(!$ZIMUCMS_MYUSER){exit();}
                if ($zmdata['discuz_isappbyme']) {
                    C::t('#zimucms_weixin#user_weixin_relations')->insert(array(
                        'userid' => $_G['uid'],
                        'name' => $_G['username'],
                        'create_time' => TIMESTAMP,
                        'unionid' => $userinfo['unionid']
                    ));
                }
                
                
            } else {
                C::t('#zimucms_weixin#zimucms_weixin_binduser')->update($bind_member['id'], array(
                    'nickname' => dhtmlspecialchars(diconv($userinfo['nickname'], 'utf-8', CHARSET)),
                    'counts' => $bind_member['counts'] + 1,
                    'lastauth' => TIMESTAMP,
                    'subscribe' => $userinfo['subscribe'],
                    'unionid' => $userinfo['unionid'],
                    'openid' => $userinfo['openid']
                ));
            }
            
            if ($_GET['hash']) {
                C::t("#zimucms_weixin#zimucms_weixin_authcode")->update_by_hash($userinfo['unionid'], $_GET['hash']);
                C::t("#zimucms_weixin#zimucms_weixin_authcode")->update_by_hash_openid($userinfo['openid'], $_GET['hash']);
            }
            
            set_oauth_cookie($userinfo, $token);
            dheader('Location:' . $referer);
            
        } else {

            if ($bind_member) {

                bind_login($bind_member);

                C::t('#zimucms_weixin#zimucms_weixin_binduser')->update($bind_member['id'], array(
                    'username' => $_G['username'],
                    'nickname' => dhtmlspecialchars(diconv($userinfo['nickname'], 'utf-8', CHARSET)),
                    'counts' => $bind_member['counts'] + 1,
                    'lastauth' => TIMESTAMP,
                    'subscribe' => $userinfo['subscribe'],
                    'unionid' => $userinfo['unionid'],
                    'openid' => $userinfo['openid']
                ));

                $ucsynlogin = '';
                if ($_G['setting']['allowsynlogin']) {
                    loaducenter();
                    $ucsynlogin = uc_user_synlogin($_G['uid']);
                }

                if ($_GET['hash']) {
                    C::t("#zimucms_weixin#zimucms_weixin_authcode")->update_by_hash($userinfo['unionid'], $_GET['hash']);
                    C::t("#zimucms_weixin#zimucms_weixin_authcode")->update_by_hash_openid($userinfo['openid'], $_GET['hash']);
                }
                
                set_oauth_cookie($userinfo, $token);
                dheader('Location:' . $referer);
                
            } else {

                if ($zmdata['discuz_allowregister']) {


               if($_GET['iszhuce']!='tozhuce' && $zmdata['discuz_isbindold']){
$ismobilelogin = $_G['cache']['plugin']['zimucms_mobilelogin']['isopen'];
if(!$ZIMUCMS_MYUSER){exit();}
if(strpos($zmdata['weixin_oauth_domain'],'oauth2.htm') !== false){

            $redirect = $zmdata['weixin_oauth_domain'].'?appid='.$zmdata['weixin_appid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri=' . urlencode( $_G['setting'][siteurl] .  '/plugin.php?id=zimucms_weixin&model=OAuth&iszhuce=tozhuce&hash=' . $_GET['hash'] . '&referer=' . urlencode($referer));

}else{

            $redirect = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $zmdata['weixin_appid'] . '&redirect_uri=' . urlencode($zmdata['weixin_oauth_domain'] . '/plugin.php?id=zimucms_weixin&model=OAuth&iszhuce=tozhuce&hash=' . $_GET['hash'] . '&referer=' . urlencode($referer)) . '&response_type=code&scope=snsapi_userinfo&state=' . md5(FORMHASH) . '#wechat_redirect';
}

 $login_url = $redirect;



                include template('zimucms_weixin:firstbind');exit();
               }

                $regname = getnewname($userinfo['nickname']);
                $uid     = register($regname, 1, $zmdata['discuz_newusergroupid'], $userinfo['sex']);
                if ($uid) {
                    syncAvatar($uid, $userinfo['headimgurl']);
                    C::t('#zimucms_weixin#zimucms_weixin_binduser')->insert(array(
                        'openid' => $userinfo['openid'],
                        'uid' => $uid,
                        'username' => $_G['username'],
                        'nickname' => dhtmlspecialchars(diconv($userinfo['nickname'], 'utf-8', CHARSET)),
                        'sex' => intval($userinfo['sex']),
                        'dateline' => TIMESTAMP,
                        'unionid' => $userinfo['unionid'],
                        'lastauth' => TIMESTAMP,
                        'counts' => 1,
                        'subscribe' => $userinfo['subscribe'],
                        'isregister' => 1
                    ));
                    
                    
                    if ($zmdata['discuz_isappbyme']) {
                        C::t('#zimucms_weixin#user_weixin_relations')->insert(array(
                        'userid' => $uid,
                        'name' => $_G['username'],
                        'create_time' => TIMESTAMP,
                        'unionid' => $userinfo['unionid']
                        ));
                    }
                    
                    if ($zmdata['discuz_credit'] && $zmdata['discuz_regreward']) {
                        updatemembercount($_G['uid'], array(
                            'extcredits' . $zmdata['discuz_credit'] => $zmdata['discuz_regreward']
                        ));
                    }
                    
                    if ($_GET['hash']) {
                        C::t("#zimucms_weixin#zimucms_weixin_authcode")->update_by_hash($userinfo['unionid'], $_GET['hash']);
                        C::t("#zimucms_weixin#zimucms_weixin_authcode")->update_by_hash_openid($userinfo['openid'], $_GET['hash']);
                    }
                    set_oauth_cookie($userinfo, $token);
                    dheader('Location:' . $referer);
                    
                } else {
                    showmessage(lang('plugin/zimucms_weixin', 'system_text52'), $referer);
                }
                }  
            }
        }
        
    } else {
        showmessage('quickclear_noperm');
    }
}

if ($model == 'checkhash') {
    $hash     = addslashes($_GET['hash']);
    $codeInfo = C::t("#zimucms_weixin#zimucms_weixin_authcode")->fetch_by_hash($hash);
    if ($_G['uid']) {
        $checkUser = C::t("#zimucms_weixin#zimucms_weixin_binduser")->fetch_by_uid($_G['uid']);
        if ($codeInfo['openid']) {
            $user = C::t("#zimucms_weixin#zimucms_weixin_binduser")->fetch_by_openid($codeInfo['openid']);
            if ($user['uid'] != $_G['uid']) {
                C::t("#zimucms_weixin#zimucms_weixin_authcode")->delete_by_hash($hash);
                echo '<root>4</root>';
                exit;
            }
        }
        if ($codeInfo['unionid']) {
            $user = C::t("#zimucms_weixin#zimucms_weixin_binduser")->fetch_by_unionid($codeInfo['unionid']);
            if ($user['uid'] != $_G['uid']) {
                C::t("#zimucms_weixin#zimucms_weixin_authcode")->delete_by_hash($hash);
                echo '<root>4</root>';
                exit;
            }
        }
        if ($checkUser) {
            C::t("#zimucms_weixin#zimucms_weixin_authcode")->delete_by_hash($hash);
            echo '<root>1</root>';
            exit;
        } else {
            echo '<root>0</root>';
            exit;
        }
    } else {
        if ($codeInfo['openid']) {
            $checkUser = C::t("#zimucms_weixin#zimucms_weixin_binduser")->fetch_by_openid($codeInfo['openid']);
            require_once libfile('function/member');
            $uid = $checkUser['uid'];
            
            if (!($member = getuserbyuid($uid, 1))) {
                C::t("#zimucms_weixin#zimucms_weixin_authcode")->delete_by_hash($hash);
                echo '<root>3</root>';
                exit;
            } else {
                if (isset($member['_inarchive'])) {
                    C::t('common_member_archive')->move_to_master($uid);
                }
            }
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
            
            C::t("#zimucms_weixin#zimucms_weixin_authcode")->delete_by_openid($codeInfo['openid']);
            echo '<root>2</root>';
            exit;
        } else if ($codeInfo['unionid']) {
            $checkUser = C::t("#zimucms_weixin#zimucms_weixin_binduser")->fetch_by_unionid($codeInfo['unionid']);
            
            require_once libfile('function/member');
            $uid = $checkUser['uid'];
            
            if (!($member = getuserbyuid($uid, 1))) {
                C::t("#zimucms_weixin#zimucms_weixin_authcode")->delete_by_hash($hash);
                echo '<root>3</root>';
                exit;
            } else {
                if (isset($member['_inarchive'])) {
                    C::t('common_member_archive')->move_to_master($uid);
                }
            }
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
            
            C::t("#zimucms_weixin#zimucms_weixin_authcode")->delete_by_unionid($codeInfo['unionid']);
            echo '<root>2</root>';
            exit;
        } else {
            echo '<root>0</root>';
            exit;
        }
    }
    
    
    
    
}


if ($model == 'tip') {
    
    $op        = $_GET['op'];
    $url       = "index.php";
    $alert     = 'error';
    $closetime = 1;
    if ($op == 'bindsuccess') {
        $tip       = lang('plugin/zimucms_weixin', 'system_text53');
        $alert     = 'right';
        $url       = "index.php";
        $closetime = 0;
    } elseif ($op == 'loginsuccess') {
        $tip       = lang('plugin/zimucms_weixin', 'system_text54');
        $url       = "index.php";
        $alert     = 'right';
        $closetime = 0;
    } elseif ($op == 'error') {
        $tip       = lang('plugin/zimucms_weixin', 'system_text55');
        $url       = "index.php";
        $alert     = 'error';
        $closetime = 1;
    } elseif ($op == 'binderror') {
        $tip       = lang('plugin/zimucms_weixin', 'system_text56');
        $url       = "index.php";
        $alert     = 'error';
        $closetime = 1;
    }
    $ext = array(
        'alert' => $alert,
        'showdialog' => 1
    );
    if ($closetime) {
        $ext['closetime'] = 3;
    } else {
        $ext['locationtime'] = 3;
    }
    showmessage($tip, $url, array(), $ext);
}


if($model=='wapbinduser' && $_GET['formhash']==formhash()){

    global $_G;

$username = $_GET['account_username'];
$password = $_GET['account_password'];

$ismobilelogin = $_G['cache']['plugin']['zimucms_magappmobile']['isopen'];

if($ismobilelogin==1){
$mobilenumber = ismobilenumber($username);
if($mobilenumber){
                $mobileuid = DB::result_first('select userid from %t where phone=%s', array(
                    'user_mobile_relations',
                    $mobilenumber
                ));
}
$mobilemember = getuserbyuid($mobileuid, 1);
if($mobilemember){
$username = $mobilemember['username'];
}
}


    loaducenter();
    list($result) = uc_user_login($username, $password, 0, 0);
    if($result >= 0) {
    
$member = getuserbyuid($result, 1);
    if (!$member) {
        return false;
    }
    require_once libfile('function/member');
    $cookietime = 1296000;
    setloginstatus($member, $cookietime);
    
    C::t('common_member_status')->update($result, array(
        'lastip' => $_G['clientip'],
        'lastvisit' => TIMESTAMP,
        'lastactivity' => TIMESTAMP
    ));

                $ucsynlogin = '';
                if ($_G['setting']['allowsynlogin']) {
                    loaducenter();
                    $ucsynlogin = uc_user_synlogin($result);
                }

echo $_G['uid'];


    }

}

function set_oauth_cookie($userinfo, $accessToken)
{
    global $_G;
    dsetcookie('wxoauth', authcode($userinfo['openid'] . "\t" . $userinfo['unionid'] . "\t" . $_G['uid'] . "\t" . dhtmlspecialchars(diconv($userinfo['nickname'], 'utf-8', CHARSET)) . "\t" . $userinfo['headimgurl'] . "\t" . TIMESTAMP, 'ENCODE'), 7200, 1, true);
    dsetcookie('wxtoken', authcode($accessToken['access_token'] . "\t" . $accessToken['refresh_token'], 'ENCODE'), 7200, 1, true);
}

function bind_login($bind_member)
{
    global $_G;
    
    if (!($member = getuserbyuid($bind_member['uid'], 1))) {
        return false;
    }else {
        if (isset($member['_inarchive'])) {
            C::t('common_member_archive')->move_to_master($member['uid']);
        }
    }

    require_once libfile('function/member');
    $cookietime = 1296000;
    setloginstatus($member, $cookietime);
    
    C::t('common_member_status')->update($bind_member['uid'], array(
        'lastip' => $_G['clientip'],
        'lastvisit' => TIMESTAMP,
        'lastactivity' => TIMESTAMP
    ));
    return true;
}



function getnewname($username)
{
    global $_G;
    $newname = cutstr(WeChatEmoji::clear($username), 15, '');
    $newname = removeEmoji($newname);
    if ($newname) {
        $censorexp = '/^(' . str_replace(array(
            '\\*',
            "\r\n",
            ' '
        ), array(
            '.*',
            '|',
            ''
        ), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')) . ')$/i';
        $newname   = preg_replace($censorexp, '', $newname);
        
        $guestexp = '\xA1\xA1|\xAC\xA3|^Guest|^\xD3\xCE\xBF\xCD|\xB9\x43\xAB\xC8';
        $newname  = preg_replace("/\s+|^c:\\con\\con|[%,\*\"\s\<\>\&]|$guestexp/is", '', $newname);
    }
    
    if (dstrlen($newname) >= 3) {
        loaducenter();
        if (uc_get_user($newname)) {
         $nums = 1;
         $oldname = $newname;
        do {
            $newname = $oldname.$nums;
            $nums++;
        } while (uc_get_user($newname));
        $newname = cutstr($newname, 14, '');
        }
    } else if ($newname) {
        $newname = $newname . '_' . random(5);
    } else {
        $newname = 'wx_' . random(5);
    }
    
    return $newname;
}

function register($username, $inapi = 0, $groupid = 0, $sex = 0)
{
    global $_G;
    if (!$username && IN_WECHATAPI) {
        echo WeChatServer::getXml4Txt(lang('message', 'undefined_action'));
        exit;
    } else if (!$username) {
        showmessage('undefined_action');
    }
    
    if (!$zmdata) {
        $zmdata = (array) unserialize($_G['setting']['zimucms_weixin']);
    }
    
    loaducenter();
    $groupid = !$groupid ? $_G['setting']['newusergroupid'] : $groupid;
    
    $password = md5(random(10));
    $email    = 'weixin_' . strtolower(random(10)) . '@null.null';
    
    $usernamelen = dstrlen($username);
    if ($usernamelen < 3) {
        $username = $username . '_' . random(5);
    }
    if ($usernamelen > 15) {
        if (!IN_WECHATAPI) {
            showmessage('profile_username_toolong');
        } else {
            echo WeChatServer::getXml4Txt(lang('message', 'profile_username_toolong'));
            exit;
        }
    }
    
    $censorexp = '/^(' . str_replace(array(
        '\\*',
        "\r\n",
        ' '
    ), array(
        '.*',
        '|',
        ''
    ), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')) . ')$/i';
    
    if (@preg_match($censorexp, $username)) {
        if (!IN_WECHATAPI) {
            showmessage('profile_username_protect');
        } else {
            echo WeChatServer::getXml4Txt(lang('message', 'profile_username_protect'));
            exit;
        }
    }
    
    if (!$zmdata['discuz_disableregrule']) {
        loadcache('ipctrl');
        if ($_G['cache']['ipctrl']['ipregctrl']) {
            foreach (explode("\n", $_G['cache']['ipctrl']['ipregctrl']) as $ctrlip) {
                if (preg_match("/^(" . preg_quote(($ctrlip = trim($ctrlip)), '/') . ")/", $_G['clientip'])) {
                    $ctrlip                   = $ctrlip . '%';
                    $_G['setting']['regctrl'] = $_G['setting']['ipregctrltime'];
                    break;
                } else {
                    $ctrlip = $_G['clientip'];
                }
            }
        } else {
            $ctrlip = $_G['clientip'];
        }
        
        if ($_G['setting']['regctrl']) {
            if (C::t('common_regip')->count_by_ip_dateline($ctrlip, $_G['timestamp'] - $_G['setting']['regctrl'] * 3600)) {
                if (!IN_WECHATAPI) {
                    showmessage('register_ctrl', null, array(
                        'regctrl' => $_G['setting']['regctrl']
                    ));
                } else {
                    echo WeChatServer::getXml4Txt(lang('message', 'register_ctrl', array(
                        'regctrl' => $_G['setting']['regctrl']
                    )));
                    exit;
                }
            }
        }
        
        $setregip = null;
        if ($_G['setting']['regfloodctrl']) {
            $regip = C::t('common_regip')->fetch_by_ip_dateline($_G['clientip'], $_G['timestamp'] - 86400);
            if ($regip) {
                if ($regip['count'] >= $_G['setting']['regfloodctrl']) {
                    if (!IN_WECHATAPI) {
                        showmessage('register_flood_ctrl', null, array(
                            'regfloodctrl' => $_G['setting']['regfloodctrl']
                        ));
                    } else {
                        echo WeChatServer::getXml4Txt(lang('message', 'register_flood_ctrl', array(
                            'regfloodctrl' => $_G['setting']['regfloodctrl']
                        )));
                        exit;
                    }
                } else {
                    $setregip = 1;
                }
            } else {
                $setregip = 2;
            }
        }
        
        if ($setregip !== null) {
            if ($setregip == 1) {
                C::t('common_regip')->update_count_by_ip($_G['clientip']);
            } else {
                C::t('common_regip')->insert(array(
                    'ip' => $_G['clientip'],
                    'count' => 1,
                    'dateline' => $_G['timestamp']
                ));
            }
        }
    }
    
    $uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
    if ($uid <= 0) {
        if (!IN_WECHATAPI) {
            if ($uid == -1) {
                showmessage('profile_username_illegal');
            } elseif ($uid == -2) {
                showmessage('profile_username_protect');
            } elseif ($uid == -3) {
                showmessage('profile_username_duplicate');
            } elseif ($uid == -4) {
                showmessage('profile_email_illegal');
            } elseif ($uid == -5) {
                showmessage('profile_email_domain_illegal');
            } elseif ($uid == -6) {
                showmessage('profile_email_duplicate');
            } else {
                showmessage('undefined_action');
            }
        } else {
            if ($uid == -1) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_username_illegal'));
            } elseif ($uid == -2) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_username_protect'));
            } elseif ($uid == -3) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_username_duplicate'));
            } elseif ($uid == -4) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_email_illegal'));
            } elseif ($uid == -5) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_email_domain_illegal'));
            } elseif ($uid == -6) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_email_duplicate'));
            } else {
                echo WeChatServer::getXml4Txt(lang('message', 'undefined_action'));
            }
            exit;
        }
    }
    
    $init_arr = array(
        'credits' => explode(',', $_G['setting']['initcredits']),
        'profile' => array(
            'gender' => $sex
        )
    );
    C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);
    
    if ($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
        C::t('common_regip')->delete_by_dateline($_G['timestamp'] - ($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72) * 3600);
        if ($_G['setting']['regctrl']) {
            C::t('common_regip')->insert(array(
                'ip' => $_G['clientip'],
                'count' => -1,
                'dateline' => $_G['timestamp']
            ));
        }
    }
    
    if ($_G['setting']['regverify'] == 2) {
        C::t('common_member_validate')->insert(array(
            'uid' => $uid,
            'submitdate' => $_G['timestamp'],
            'moddate' => 0,
            'admin' => '',
            'submittimes' => 1,
            'status' => 0,
            'message' => '',
            'remark' => ''
        ), false, true);
        manage_addnotify('verifyuser');
    }
    
    setloginstatus(array(
        'uid' => $uid,
        'username' => $username,
        'password' => $password,
        'groupid' => $groupid
    ), 0);
    

    include_once libfile('function/stat');
    updatestat('register');
    
    return $uid;
}


function syncAvatar($uid, $avatar)
{
    
    if (!$uid || !$avatar) {
        return false;
    }
    
    if (!$content = dfsockopen($avatar)) {
        return false;
    }
    
    $tmpFile = DISCUZ_ROOT . './data/avatar/' . TIMESTAMP . random(6);
    file_put_contents($tmpFile, $content);
    
    if (!is_file($tmpFile)) {
        return false;
    }
    $result = uploadUcAvatar($uid, $tmpFile);
    unlink($tmpFile);
    
    C::t('common_member')->update($uid, array(
        'avatarstatus' => '1'
    ));
    return $result;
}

function uploadUcAvatar($uid, $localFile)
{
    
    global $_G;
    if (!$uid || !$localFile) {
        return false;
    }
    
    list($width, $height, $type, $attr) = getimagesize($localFile);
    if (!$width) {
        return false;
    }
    if ($width < 10 || $height < 10 || $type == 4) {
        return false;
    }
    
    $imageType = array(
        1 => '.gif',
        2 => '.jpg',
        3 => '.png'
    );
    $fileType  = $imgType[$type];
    if (!$fileType) {
        $fileType = '.jpg';
    }
    $avatarPath = $_G['setting']['attachdir'];
    $tmpAvatar  = $avatarPath . './temp/upload' . $uid . $fileType;
    file_exists($tmpAvatar) && @unlink($tmpAvatar);
    file_put_contents($tmpAvatar, file_get_contents($localFile));
    
    if (!is_file($tmpAvatar)) {
        return false;
    }
    
    $tmpAvatarBig    = './temp/upload' . $uid . 'big' . $fileType;
    $tmpAvatarMiddle = './temp/upload' . $uid . 'middle' . $fileType;
    $tmpAvatarSmall  = './temp/upload' . $uid . 'small' . $fileType;
    
    $image = new image;
    if ($image->Thumb($tmpAvatar, $tmpAvatarBig, 200, 250, 1) <= 0) {
        return false;
    }
    if ($image->Thumb($tmpAvatar, $tmpAvatarMiddle, 120, 120, 1) <= 0) {
        return false;
    }
    if ($image->Thumb($tmpAvatar, $tmpAvatarSmall, 48, 48, 2) <= 0) {
        return false;
    }
    
    $tmpAvatarBig    = $avatarPath . $tmpAvatarBig;
    $tmpAvatarMiddle = $avatarPath . $tmpAvatarMiddle;
    $tmpAvatarSmall  = $avatarPath . $tmpAvatarSmall;
    $avatar1         = byte2hex(file_get_contents($tmpAvatarBig));
    $avatar2         = byte2hex(file_get_contents($tmpAvatarMiddle));
    $avatar3         = byte2hex(file_get_contents($tmpAvatarSmall));
    
    $extra  = '&avatar1=' . $avatar1 . '&avatar2=' . $avatar2 . '&avatar3=' . $avatar3;
    $result = uc_api_post_ex('user', 'rectavatar', array(
        'uid' => $uid
    ), $extra);
    
    @unlink($tmpAvatar);
    @unlink($tmpAvatarBig);
    @unlink($tmpAvatarMiddle);
    @unlink($tmpAvatarSmall);
    return true;
}

function byte2hex($string)
{
    $buffer = '';
    $value  = unpack('H*', $string);
    $value  = str_split($value[1], 2);
    $b      = '';
    foreach ($value as $k => $v) {
        $b .= strtoupper($v);
    }
    
    return $b;
}

function uc_api_post_ex($module, $action, $arg = array(), $extra = '')
{
    $s = $sep = '';
    foreach ($arg as $k => $v) {
        $k = urlencode($k);
        if (is_array($v)) {
            $s2 = $sep2 = '';
            foreach ($v as $k2 => $v2) {
                $k2 = urlencode($k2);
                $s2 .= "$sep2{$k}[$k2]=" . urlencode(uc_stripslashes($v2));
                $sep2 = '&';
            }
            $s .= $sep . $s2;
        } else {
            $s .= "$sep$k=" . urlencode(uc_stripslashes($v));
        }
        $sep = '&';
    }
    $postdata = uc_api_requestdata($module, $action, $s, $extra);
    return uc_fopen2(UC_API . '/index.php', 500000, $postdata, '', true, UC_IP, 20);
}

function checkbind_member($unionid){

                $bind_member1 = C::t('#zimucms_weixin#user_weixin_relations')->fetch_by_unionid($unionid);
                $bind_member2 = C::t('#zimucms_weixin#zimucms_weixin_binduser')->fetch_by_unionid($unionid);
                if ($bind_member1 && !$bind_member2) {
                    C::t('#zimucms_weixin#zimucms_weixin_binduser')->insert(array(
                        'openid' => '',
                        'uid' => $bind_member1['userid'],
                        'username' => '',
                        'nickname' => '',
                        'sex' => '1',
                        'dateline' => TIMESTAMP,
                        'unionid' => $bind_member1['unionid'],
                        'lastauth' => TIMESTAMP,
                        'counts' => 1,
                        'subscribe' => 0
                    ));
                $bind_member2 = C::t('#zimucms_weixin#zimucms_weixin_binduser')->fetch_by_unionid($unionid);
                    $bind_member = $bind_member2;
                }
                if (!$bind_member1 && $bind_member2) {
                    C::t('#zimucms_weixin#user_weixin_relations')->insert(array(
                        'userid' => $bind_member2['uid'],
                        'name' => $bind_member2['username'],
                        'create_time' => TIMESTAMP,
                        'unionid' => $bind_member2['unionid']
                    ));
                    $bind_member = $bind_member2;
                }
                if ($bind_member1 && $bind_member2) {
                    $bind_member = $bind_member2;
                }
    return $bind_member;
}

function ismobilenumber($mobile)
{
    $preg = "/^(13[0-9]|15[0-9]|17[0678]|18[0-9]|14[57])[0-9]{8}$/";
    if (!preg_match($preg, $mobile)) {
        return '';
    }
    return $mobile;
}
   function removeEmoji($text) {
        $clean_text = "";
        // Match Emoticons
        $regexEmoticons = '/[\x{1F600}-\x{1F64F}]/u';
        $clean_text = preg_replace($regexEmoticons, '', $text);
        // Match Miscellaneous Symbols and Pictographs
        $regexSymbols = '/[\x{1F300}-\x{1F5FF}]/u';
        $clean_text = preg_replace($regexSymbols, '', $clean_text);
        // Match Transport And Map Symbols
        $regexTransport = '/[\x{1F680}-\x{1F6FF}]/u';
        $clean_text = preg_replace($regexTransport, '', $clean_text);
        // Match Miscellaneous Symbols
        $regexMisc = '/[\x{2600}-\x{26FF}]/u';
        $clean_text = preg_replace($regexMisc, '', $clean_text);
        // Match Dingbats
        $regexDingbats = '/[\x{2700}-\x{27BF}]/u';
        $clean_text = preg_replace($regexDingbats, '', $clean_text);
if(!$clean_text){
$clean_text = $text;
}
        return $clean_text;
    }