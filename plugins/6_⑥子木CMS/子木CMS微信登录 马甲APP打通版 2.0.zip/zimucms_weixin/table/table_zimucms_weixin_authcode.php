<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, [DisM!] (C)2001-2099 DisM Inc.
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_zimucms_weixin_authcode extends discuz_table
{
	public function __construct() {

		$this->_table = 'zimucms_weixin_authcode';
		$this->_pk    = 'id';
		parent::__construct();
	}
	
	public function delete_by_hash($hash){
		return DB::query("DELETE FROM %t WHERE code=%s",array($this->_table,$hash) );
	}

	public function delete_by_openid($openid){
		return DB::query("DELETE FROM %t WHERE openid=%s",array($this->_table,$openid) );
	}
	
	public function delete_by_unionid($unionid){
		return DB::query("DELETE FROM %t WHERE unionid=%s",array($this->_table,$unionid) );
	}

	public function fetch_by_hash($hash){
		return DB::fetch_first("SELECT * FROM %t WHERE code=%s",array($this->_table,$hash));
	}

	public function update_by_hash($unionid,$hash){
		return DB::query("UPDATE %t SET unionid=%s WHERE code=%s",array($this->_table,$unionid,$hash));
	}

	public function update_by_hash_openid($openid,$hash){
		return DB::query("UPDATE %t SET openid=%s WHERE code=%s",array($this->_table,$openid,$hash));
	}

}
