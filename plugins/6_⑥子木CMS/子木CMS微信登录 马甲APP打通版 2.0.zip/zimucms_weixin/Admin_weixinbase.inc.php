<?php
/*
��ľCMS http://www.zimucms.com/
CopyRight 2016 All Rights Reserved
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$zmdata = (array) unserialize($_G['setting']['zimucms_weixin']);

$model = 'weixinbase';

if ($model == 'weixinbase') {
    
    
    if (submitcheck('weixinbasesubmit')) {
        
        if ($_GET['zmdata']['discuz_autologin'] && !$_GET['zmdata']['discuz_allowregister']) {
            cpmsg(lang('plugin/zimucms_weixin', 'system_text28'), '', 'error');
        }
        $zmdata = array(
            'zimucms_weixin' => serialize($_GET['zmdata'] + $zmdata)
        );
        
        C::t('common_setting')->update_batch($zmdata);
        updatecache('setting');
        cpmsg(lang('plugin/zimucms_weixin', 'system_text27'), "action=plugins&operation=config&do=" . $pluginid . "&identifier=" . $plugin['identifier'] . "&pmod=Admin_weixinbase&model=weixinbase", "succeed");


    } else {
        
        $groupselect = array();
        foreach (C::t('common_usergroup')->range_orderby_credit() as $group) {
            if ($group['type'] != 'member' || $_G['setting']['newusergroupid'] == $group['groupid']) {
                $groupselect[$group['type']] .= '<option value="' . $group['groupid'] . '"' . ($zmdata['discuz_newusergroupid'] == $group['groupid'] ? ' selected' : '') . '>' . $group['grouptitle'] . '</option>';
            }
        }
        $usergroups = '<select name="zmdata[discuz_newusergroupid]"><option value="">' . cplang('plugins_empty') . '</option>' . '<optgroup label="' . $lang['usergroups_member'] . '">' . $groupselect['member'] . '</optgroup>' . ($groupselect['special'] ? '<optgroup label="' . $lang['usergroups_special'] . '">' . $groupselect['special'] . '</optgroup>' : '') . ($groupselect['specialadmin'] ? '<optgroup label="' . $lang['usergroups_specialadmin'] . '">' . $groupselect['specialadmin'] . '</optgroup>' : '') . '<optgroup label="' . $lang['usergroups_system'] . '">' . $groupselect['system'] . '</optgroup></select>';
        
        $apicredits = '<option value="0">' . cplang('none') . '</option>';
        foreach ($_G['setting']['extcredits'] as $i => $credit) {
            $extcredit = 'extcredits' . $i . ' (' . $credit['title'] . ')';
            $apicredits .= '<option value="' . $i . '" ' . ($i == intval($zmdata['discuz_credit']) ? 'selected' : '') . '>' . $extcredit . '</option>';
        }
        
        showformheader("plugins&operation=config&do=" . $pluginid . "&identifier=" . $plugin['identifier'] . "&pmod=Admin_weixinbase&model=weixinbase");
        
        showtableheader(lang('plugin/zimucms_weixin', 'system_text29'));
        
        showsetting(lang('plugin/zimucms_weixin', 'system_text63'), 'zmdata[discuz_isappbyme]', $zmdata['discuz_isappbyme'], 'radio', '', 0, lang('plugin/zimucms_weixin', 'system_text64'));
        
        showsetting(lang('plugin/zimucms_weixin', 'system_text30'), 'zmdata[discuz_autologin]', $zmdata['discuz_autologin'], 'radio', '', 0, lang('plugin/zimucms_weixin', 'system_text31'));

        showsetting(lang('plugin/zimucms_weixin', 'system_text61'), 'zmdata[discuz_isbindold]', $zmdata['discuz_isbindold'], 'radio', '', 0, lang('plugin/zimucms_weixin', 'system_text62'));

        
        showsetting(lang('plugin/zimucms_weixin', 'system_text32'), 'zmdata[discuz_allowregister]', $zmdata['discuz_allowregister'], 'radio', 0, 1, lang('plugin/zimucms_weixin', 'system_text33'));
        showsetting(lang('plugin/zimucms_weixin', 'system_text34'), 'zmdata[discuz_disableregrule]', $zmdata['discuz_disableregrule'], 'radio', 0, 0, $langs['admincp_disucz_disableregrule_tips']);
        showsetting(lang('plugin/zimucms_weixin', 'system_text35'), 'zmdata[discuz_allownewusername]', $zmdata['discuz_allownewusername'], 'radio', 0, 0, $langs['discuz_allownewusername_tips']);
        showsetting(lang('plugin/zimucms_weixin', 'system_text36'), '', '', $usergroups, 0, 0, lang('plugin/zimucms_weixin', 'system_text37'));
        
        
        showsetting(lang('plugin/zimucms_weixin', 'system_text38'), '', '', '<select name="zmdata[discuz_credit]">' . $apicredits . '</select>', 0, 0, lang('plugin/zimucms_weixin', 'system_text39'));
        showsetting(lang('plugin/zimucms_weixin', 'system_text59'), 'zmdata[discuz_regreward]', $zmdata['discuz_regreward'], 'text', 0, 0, lang('plugin/zimucms_weixin', 'system_text40'));
        showtagfooter('tbody');
        
        
        showtableheader();
        showsubmit('weixinbasesubmit');
        showtablefooter();/*dis'.'m.tao'.'bao.com*/
        
        showformfooter();
    }
    
}