<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if ($_G['uid']) {
    if ($bindmember = C::t('#zimucms_weixin#zimucms_weixin_binduser')->fetch_by_uid($_G['uid'])) {
        $_G['member']['openid']    = $bindmember['openid'];
        $_G['member']['unionid']   = $bindmember['unionid'];
        $_G['member']['subscribe'] = $bindmember['subscribe'] == 1 ? 1 : 0;
        CURSCRIPT == 'home' && $_G['member']['isregister'] = $bindmember['isregister'];
        unset($bindmember);
    }
}
//���԰�
class plugin_zimucms_weixin
{
    
    function global_login_extra()
    {
        global $_G;
        $zmdata = (array) unserialize($_G['setting']['zimucms_weixin']);
        if (!$_G['uid'] && $zmdata['discuz_allowregister']) {
            include template('zimucms_weixin:global_login');
            return $html;
        }
        
    }
    
    function global_usernav_extra1()
    {
        global $_G;
        
        if (!$_G['uid'] || $_G['member']['unionid'] || $_G['member']['openid']) {
            return;
        }
        $zmdata = (array) unserialize($_G['setting']['zimucms_weixin']);
        
        if ($zmdata['discuz_allowregister']) {
            include template('zimucms_weixin:global_usernav');
            return $html;
        }
        
    }
    
}

class plugin_zimucms_weixin_member extends plugin_zimucms_weixin
{
    
    
    function logging_method()
    {
        global $_G;
        $zmdata = (array) unserialize($_G['setting']['zimucms_weixin']);
        if ($zmdata['discuz_allowregister']) {
            include template('zimucms_weixin:weixin_login');
            return $html;
        }
    }
    
    
    function register_logging_method()
    {
        global $_G;
        $zmdata = (array) unserialize($_G['setting']['zimucms_weixin']);
        if ($zmdata['discuz_allowregister']) {
            include template('zimucms_weixin:weixin_login');
            return $html;
        }
    }
    
    
}

//�ֻ���
class mobileplugin_zimucms_weixin
{
    
    function global_footer_mobile()
    {
        
        global $_G;
        $zmdata = (array) unserialize($_G['setting']['zimucms_weixin']);
        
        define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);

        if (CURMODULE == 'register' && $zmdata['discuz_allowregister'] && IN_WECHAT) {
           
            $referer = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'] . ($_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '') : dreferer();
            
if(strpos($zmdata['weixin_oauth_domain'],'oauth2.htm') !== false){

            $login_url = $zmdata['weixin_oauth_domain'].'?appid='.$zmdata['weixin_appid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri=' . urlencode( $_G['setting'][siteurl] .  '/plugin.php?id=zimucms_weixin&model=OAuth&referer=' . urlencode($referer));

}else{

            $login_url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $zmdata['weixin_appid'] . '&redirect_uri=' . urlencode($zmdata['weixin_oauth_domain'] . '/plugin.php?id=zimucms_weixin&model=OAuth&referer=' . urlencode($referer)) . '&response_type=code&scope=snsapi_userinfo&state=' . md5(FORMHASH) . '#wechat_redirect';
}

            include template('zimucms_weixin:global_footer');
            return $html;
}
        
        if ($zmdata['discuz_autologin'] && !$_G['uid'] && IN_WECHAT && $_GET['action'] != 'logout') {
            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
            if (isset($_SERVER['HTTP_X_REWRITE_URL'])) {
                $requestUri = $_SERVER['HTTP_X_REWRITE_URL'];
            } elseif (isset($_SERVER['REQUEST_URI'])) {
                $requestUri = $_SERVER['REQUEST_URI'];
            } elseif (isset($_SERVER['REDIRECT_URL'])) {
                $requestUri = $_SERVER['REDIRECT_URL'];
            } elseif (isset($_SERVER['ORIG_PATH_INFO'])) {
                $requestUri = $_SERVER['ORIG_PATH_INFO'];
                if (!empty($_SERVER['QUERY_STRING'])) {
                    $requestUri .= '?' . $_SERVER['QUERY_STRING'];
                }
            }
            $url = $protocol . $_SERVER['HTTP_HOST'] . $requestUri;
            
            //include_once DISCUZ_ROOT . './source/plugin/zimucms_weixin/class/wechat.lib.class.php';
            //$wechat_client = new WeChatClient($zmdata['weixin_appid'], $zmdata['weixin_appsecret']);
            
if(strpos($zmdata['weixin_oauth_domain'],'oauth2.htm') !== false){

            $login_url = $zmdata['weixin_oauth_domain'].'?appid='.$zmdata['weixin_appid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri=' . urlencode( $_G['setting'][siteurl] .  '/plugin.php?id=zimucms_weixin&model=OAuth&referer=' . urlencode($url));

}else{

            $login_url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $zmdata['weixin_appid'] . '&redirect_uri=' . urlencode($zmdata['weixin_oauth_domain'] . '/plugin.php?id=zimucms_weixin&model=OAuth&referer=' . urlencode($url)) . '&response_type=code&scope=snsapi_userinfo&state=' . md5(FORMHASH) . '#wechat_redirect';
}

            dheader('Location:' . $login_url);
        }



            include template('zimucms_weixin:wx_guide');
            return $html2;
        
    }
    
    
}


class mobileplugin_zimucms_weixin_member extends mobileplugin_zimucms_weixin
{
    
    function logging_bottom_mobile()
    {
        
        global $_G;
        $zmdata = (array) unserialize($_G['setting']['zimucms_weixin']);
        
        define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
        
        if ($zmdata['discuz_allowregister'] && IN_WECHAT) {
            $referer = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'] . ($_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '') : dreferer();
            
if(strpos($zmdata['weixin_oauth_domain'],'oauth2.htm') !== false){

            $login_url = $zmdata['weixin_oauth_domain'].'?appid='.$zmdata['weixin_appid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri=' . urlencode( $_G['setting'][siteurl] .  '/plugin.php?id=zimucms_weixin&model=OAuth&referer=' . urlencode($referer));

}else{

            $login_url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $zmdata['weixin_appid'] . '&redirect_uri=' . urlencode($zmdata['weixin_oauth_domain'] . '/plugin.php?id=zimucms_weixin&model=OAuth&referer=' . urlencode($referer)) . '&response_type=code&scope=snsapi_userinfo&state=' . md5(FORMHASH) . '#wechat_redirect';
}
            
            include template('zimucms_weixin:global_footer');
            
            return $html;
        }
    }
}