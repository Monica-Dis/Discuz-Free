<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, [DisM!] (C)2001-2099 DisM Inc.
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$zmdata = (array)unserialize($_G['setting']['zimucms_weixin']);
$data = array();
if($_G['uid']){//检查是否绑定过
    $checkUser = C::t("#zimucms_weixin#zimucms_weixin_binduser")->fetch_by_uid($_G['uid']);
    if($checkUser){
        showmessage(lang('plugin/zimucms_weixin','system_text41'));
    }
	$data['uid'] = $_G['uid'];
}
$data['dateline'] = $_G['timestamp'];
$data['code'] = $hash = random(10);
C::t("#zimucms_weixin#zimucms_weixin_authcode")->insert($data);

$referer = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'] . ($_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '') : dreferer();


if(strpos($zmdata['weixin_oauth_domain'],'oauth2.htm') !== false){

            $login_url = $zmdata['weixin_oauth_domain'].'?appid='.$zmdata['weixin_appid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri=' . urlencode( $_G['setting'][siteurl] .  '/plugin.php?id=zimucms_weixin&model=OAuth&hash='.$hash.'&referer=' . urlencode($referer));

}else{

            $login_url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $zmdata['weixin_appid'] . '&redirect_uri=' . urlencode($zmdata['weixin_oauth_domain'] . '/plugin.php?id=zimucms_weixin&model=OAuth&hash='.$hash.'&referer=' . urlencode($referer)) . '&response_type=code&scope=snsapi_userinfo&state=' . md5(FORMHASH) . '#wechat_redirect';
}

$qrsize = 5;
$dir = 'data/cache/qrcode/';//存储路径
$file = $dir.'zimucms_weixin_'.$data['code'].'.jpg';
if(!file_exists($file) || !filesize($file)) {
    dmkdir($dir);
    require_once DISCUZ_ROOT.'source/plugin/zimucms_weixin/class/qrcode.class.php';
    QRcode::png($login_url, $file, QR_ECLEVEL_L, $qrsize);
}

$qrcode = base64_encode(file_get_contents($file));

unlink($file);
include template("zimucms_weixin:qrcode");
