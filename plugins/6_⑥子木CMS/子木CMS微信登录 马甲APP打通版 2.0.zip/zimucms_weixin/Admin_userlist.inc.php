<?php
/*
��ľCMS http://www.zimucms.com/
CopyRight 2016 All Rights Reserved
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$zmdata = (array) unserialize($_G['setting']['zimucms_weixin']);

$model = addslashes($_GET['model']);

if(!$model){
$model = 'userlist';
}

if ($model == 'userlist') {
    
    
    
    $uid      = intval($_GET['uid']);
    $username = strip_tags($_GET['username']);
    $nickname = strip_tags($_GET['nickname']);
    $openid   = strip_tags($_GET['openid']);
    
    
    $username = dhtmlspecialchars($username);
    $username = stripsearchkey($username);
    $username = daddslashes($username);
    
    $nickname = dhtmlspecialchars($nickname);
    $nickname = stripsearchkey($nickname);
    $nickname = daddslashes($nickname);
    
    $openid = dhtmlspecialchars($openid);
    $openid = stripsearchkey($openid);
    $openid = daddslashes($openid);
    
    
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    
    //$subscribe = intval($_GET['subscribe']);

    if ($uid > 0) {
        $wherearr[] = DB::field('uid', $uid);
    }
    
    if (!is_null($_GET['subscribe'])) {
        $wherearr[] = DB::field('subscribe', intval($_GET['subscribe']));
    }
    
    if ($username) {
        include_once libfile('function/search');
        $wherearr[] = ' 1 ' . searchkey($username, "username LIKE '%{text}%'");
    }
    if ($nickname) {
        include_once libfile('function/search');
        $wherearr[] = ' 1 ' . searchkey($nickname, "nickname LIKE '%{text}%'");
    }
    
    if ($openid) {
        $wherearr[] = DB::field('openid', dhtmlspecialchars($openid)) . ' OR ' . DB::field('unionid', dhtmlspecialchars($openid));
    }
    
    
    $wheresql = empty($wherearr) ? '1' : implode(' AND ', $wherearr);
    
    $count = DB::result_first("SELECT count(*) FROM %t WHERE %i", array(
        "zimucms_weixin_binduser",
        $wheresql
    ));
    
    $limit    = 10;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    
    $userlist = DB::fetch_all('select * from %t where %i order by lastauth desc,id desc limit %d,%d', array(
        'zimucms_weixin_binduser',
        $wheresql,
        $start,
        $limit
    ));
    
    if ($page_num > 1) {

if(!is_null($_GET['subscribe'])){

        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin[pluginid] . '&identifier=' . $plugin[identifier] . '&pmod=' . $module[name] . '&model=' . $model . '&subscribe=' . intval($_GET['subscribe']), '10000', '20', TRUE, TRUE);
}else{
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin[pluginid] . '&identifier=' . $plugin[identifier] . '&pmod=' . $module[name] . '&model=' . $model, '10000', '20', TRUE, TRUE);

}


    }
    
    
    
    include template('zimucms_weixin:userlist');
    



} else if ($model == 'delbind' && $_GET['md5formhash'] == formhash()) {

    $userid = intval($_GET['userid']);

    C::t("#zimucms_weixin#zimucms_weixin_binduser")->delete_by_uid($userid);
    C::t("#zimucms_weixin#user_weixin_relations")->delete_by_uid($_G['uid']);

        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']) . '&leixing=' . intval($_GET['leixing']);

        cpmsg(lang('plugin/zimucms_weixin', 'system_text42'), $url, 'succeed');

}









function imglable($src, $comment = '')
{
    global $_G;
    return $src ? "<img width='128' height='128' src='$src' /><label>" . $comment . '</label>' : '';
}