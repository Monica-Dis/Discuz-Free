<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: [DisM!] (C)2001-2099 DisM Inc..
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$plugin_identifier = addslashes($_GET['id']);
$addon = addslashes($_GET['addon']);
if (!$plugin_identifier) {
	$plugin_identifier = $plugin['identifier'];
}
$plugin_identifier2 = explode(':', $plugin_identifier);
if ($plugin_identifier2[1]) {
	$plugin_identifier = $plugin_identifier2[0];
}
define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/' . $plugin_identifier . '/');
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=' . $plugin_identifier);
$ZIMUCMS_MYUSER = '1';
$formhash = $_G['formhash'];
if ($_G['charset'] == 'gbk') {
	$charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
	$charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
	$charset = 'big5';
}
function deldirfile($directory, $empty = false)
{
	if (substr($directory, 0 - 1) == '/') {
		$directory = substr($directory, 0, 0 - 1);
	}
	if (!file_exists($directory) || !is_dir($directory)) {
		return false;
	}
	if (!is_readable($directory)) {
		return false;
	}
	@($directoryHandle = opendir($directory));
	while ($contents = @readdir($directoryHandle)) {
		if ($contents != '.' && $contents != '..') {
			$path = $directory . '/' . $contents;
			if (is_dir($path)) {
				@deldirfile($path, $empty);
			} else {
				@unlink($path);
			}
		}
	}
	@closedir($directoryHandle);
	if ($empty == false) {
		if (!@rmdir($directory)) {
			return false;
		}
	}
	return true;
}