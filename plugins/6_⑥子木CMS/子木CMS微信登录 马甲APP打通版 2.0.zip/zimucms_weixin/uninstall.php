<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, [DisM!] (C)2001-2099 DisM Inc.
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

delpay();

$sql = <<<EOF
DROP TABLE  IF EXISTS pre_zimucms_weixin_authcode;
DROP TABLE  IF EXISTS pre_zimucms_weixin_binduser;
EOF;
runquery($sql);

$zmdata  = (array) unserialize($_G['setting']['zimucms_weixin']);

deletecache('zmweixin_'.$zmdata['weixin_appid']);
deletecache('zmjst_'.$zmdata['weixin_appid']);
DB::delete('common_setting', array('skey' => 'zimucms_weixin'));
updatecache('setting');


$finish = TRUE;


function delpay(){
global $_G;

if(file_exists(DISCUZ_ROOT . './source/plugin/zimucms_weixin/pay/cacert/apiclient_cert.pem')){
unlink(DISCUZ_ROOT . './source/plugin/zimucms_weixin/pay/cacert/apiclient_cert.pem');
}
if(file_exists(DISCUZ_ROOT . './source/plugin/zimucms_weixin/pay/cacert/apiclient_key.pem')){
unlink(DISCUZ_ROOT . './source/plugin/zimucms_weixin/pay/cacert/apiclient_key.pem');
}

}

function deletecache($cachenames) {  
    if(!empty($cachenames)) {  
  DB::delete('common_syscache', array('cname' => $cachenames));
    }  
}