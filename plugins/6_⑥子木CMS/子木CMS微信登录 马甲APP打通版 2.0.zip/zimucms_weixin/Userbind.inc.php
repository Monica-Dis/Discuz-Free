<?php


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$zmdata = (array)unserialize($_G['setting']['zimucms_weixin']);

$isbinduser = C::t("#zimucms_weixin#zimucms_weixin_binduser")->fetch_by_uid($_G['uid']);

$url = "home.php?mod=spacecp&ac=plugin&id=zimucms_weixin:Userbind";

$myemail = DB::fetch_first("SELECT * FROM %t where uid=%d", array(
    "common_member",
    $_G['uid']
));


if(submitcheck("unbindsubmit")){
    C::t("#zimucms_weixin#zimucms_weixin_binduser")->delete_by_uid($_G['uid']);
    C::t("#zimucms_weixin#user_weixin_relations")->delete_by_uid($_G['uid']);
    $tip = lang('plugin/zimucms_weixin','system_text42');
    showmessage($tip, $url, array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3));
}elseif(submitcheck("editsubmit")){
    $data['username'] = $username = addslashes($_GET['username']);
    if(C::t('common_member')->fetch_uid_by_username($username) || C::t('common_member_archive')->fetch_uid_by_username($username)) {
        showmessage(lang('plugin/zimucms_weixin','system_text43'), $url, array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3));    
    }
    $data['pwd'] = addslashes($_GET['password']);
    if(!$data['pwd'])
        showmessage(lang('plugin/zimucms_weixin','system_text44'), $url, array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3));    
    if($data['pwd'] != $_GET['password1'])
        showmessage(lang('plugin/zimucms_weixin','system_text45'), $url, array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3));    
    $data['email'] = strtolower(addslashes(trim($_GET['email'])));
    $isemail = C::t('common_member')->fetch_by_email($data['email']);
    if($isemail && $_G['uid'] != $isemail['uid']){
        showmessage(lang('plugin/zimucms_weixin','system_text46'), $url, array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3));    
    }
    loaducenter();
    $ucresult = uc_user_edit($_G['username'], $data['pwd'], $data['pwd'], $data['email'], 1, '');
    if($ucresult < 0) {
        if($ucresult == -4) {
            showmessage(lang('plugin/zimucms_weixin','system_text47'), $url, array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3));    
        } elseif($ucresult == -5) {
            showmessage(lang('plugin/zimucms_weixin','system_text47'), $url, array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3));    
        } elseif($ucresult == -6) {
                showmessage(lang('plugin/zimucms_weixin','system_text48'), $url, array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3));    
        }
    }

        // 新增修改用户名
    if($data['username'] && $data['username'] != $_G['username']) {
        global $uc_controls;
        $newusername = $data['username'];
        DB::query('UPDATE %t SET username = %s WHERE username = %s', array('common_member', $newusername, $_G['username']));
        $uc_controls['user']->db->query("UPDATE " . UC_DBTABLEPRE . "members SET username='$newusername' WHERE username='{$_G[username]}'");
        C::t('common_member')->update_cache($_G['uid'], array('username' => $newusername));
    }

    C::t("#zimucms_weixin#zimucms_weixin_binduser")->update_status($_G['uid'],'1');
    showmessage(lang('plugin/zimucms_weixin','system_text49'),$url);
}