<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'jobfairlist';

if ($op == 'editjobfair') {

if(submitcheck('submit')) {

        $data['title']        = strip_tags($_GET['title']);
        $data['catcn']        = strip_tags($_GET['catcn']);
        $data['starttime'] = strtotime($_GET['starttime']);
        $data['endtime'] = strtotime($_GET['endtime']);
        $data['contact']        = strip_tags($_GET['contact']);
        $data['tel']        = strip_tags($_GET['tel']);
        if ($_FILES['thumb']['tmp_name']) {
            $data['thumb'] = zm_saveimages($_FILES['thumb']);
        }
        if ($_FILES['poster']['tmp_name']) {
            $data['poster'] = zm_saveimages($_FILES['poster']);
        }
        if ($_FILES['pc_poster']['tmp_name']) {
            $data['pc_poster'] = zm_saveimages($_FILES['pc_poster']);
        }
        if ($_FILES['kefu_qrcode']['tmp_name']) {
            $data['kefu_qrcode'] = zm_saveimages($_FILES['kefu_qrcode']);
        }
        $data['kefu_tip']        = strip_tags($_GET['kefu_tip']);
        $data['summary']        = strip_tags($_GET['summary']);
        $data['addtime'] = strtotime($_GET['addtime']);
        $data['intro']    = dhtmlspecialchars($_GET['intro']);
        $data['price']        = strip_tags($_GET['price']);
        $data['bgcolor']        = strip_tags($_GET['bgcolor']);
        $data['id']      = intval($_GET['ids']);
        
        if ($data['id'] > 0) {

        DB::update('zimu_zhaopin_jobfair_online', $data, array(
            'id' => $data['id']
        ));
            
        } else {
            
            $result = DB::insert('zimu_zhaopin_jobfair_online', $data, 1);
            
        }
          
        include template('zimu_zhaopin:common/success');

}else{

        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_zhaopin_jobfair_online',
            $ids
        ));

        include zimu_template('admins/admins_' . $type .'_jobfairlist','');

}


} else if ($op == 'jobfair_company') {

    $fid = intval($_GET['fid']);

if(submitcheck('submit')) {

        if (!empty($_GET['ids'])) {
            foreach ($_GET['ids'] as $k => $v) {

if($v){
        $data = array(
            'fid' => $fid,
            'uid' => intval($_GET['uid'][$k]),
            'com_id' => intval($_GET['com_id'][$k]),
            'sort' => intval($_GET['sort'][$k]),
            'com_name' => trim($_GET['com_name'][$k]),
            'catcn' => intval($_GET['catcn'][$k]),
            'zhiding' => intval($_GET['zhiding'][$k]),
            'note' => trim($_GET['note'][$k]),
            'status' => intval($_GET['status'][$k]),
            'addtime' => intval($_GET['addtime'][$k]),
        );

            DB::update('zimu_zhaopin_jobfair_online_com', $data, array(
                'fid' => $fid,
                'id' => $v
            ));

}elseif(trim($_GET['uid'][$k])){

    $tocomdata = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_company_profile',
        intval($_GET['uid'][$k])
    ));

        $data = array(
            'fid' => $fid,
            'uid' => intval($_GET['uid'][$k]),
            'com_id' => $tocomdata['id'],
            'sort' => intval($_GET['sort'][$k]),
            'com_name' => $tocomdata['companyname'],
            'zhiding' => 0,
            'note' => '',
            'status' => 1,
            'addtime' => $_G['timestamp'],
        );

        DB::insert('zimu_zhaopin_jobfair_online_com', $data);

}

}
        }

        include template('zimu_zhaopin:common/success');

}else{

    $ids = intval($_GET['ids']);

    $status = intval($_GET['status']);
    if (!empty($status)) {
        $wheresql = " and status = 0 ";
    }

    $catcn = intval($_GET['catcn']);
    if (!empty($catcn)) {
        $wheresql = " and catcn = ".$catcn;
    }

    $lists = DB::fetch_all('select * from %t where fid=%d %i order by zhiding desc,sort asc,addtime asc', array(
        'zimu_zhaopin_jobfair_online_com',
        $ids,
        $wheresql
    ));

    foreach ($lists as $key => $value) {

        $lists[$key]['profile'] = DB::fetch_first('select * from %t where id=%d order by id desc', array(
            'zimu_zhaopin_company_profile',
            $value['com_id']
        ));
    }

    $jobfairdata = DB::fetch_first('select * from %t where id=%d', array(
        'zimu_zhaopin_jobfair_online',
        $ids
    ));
    $jobfairdata['catcn'] = explode(',',$jobfairdata['catcn']);


include zimu_template('admins/admins_' . $type .'_jobfairlist','');

}


} else if ($op == 'del_company' && $_GET['md5hash'] == formhash()) {

    $ids = intval($_GET['ids']);
    $fid = intval($_GET['fid']);
    
    $result = DB::delete('zimu_zhaopin_jobfair_online_com', array(
        'id' => $ids,
        'fid' => $fid
    ));
    
    include template('zimu_zhaopin:common/success');


} else if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_zhaopin_jobfair_online', array(
        'id' => $ids
    ));
    
    include template('zimu_zhaopin:common/success');

} else if ($op == 'exportcompany') {

    $ids = intval($_GET['ids']);

    $jobfairdata = DB::fetch_first('select * from %t where id=%d', array(
        'zimu_zhaopin_jobfair_online',
        $ids
    ));
    $jobfairdata['catcn'] = explode(',',$jobfairdata['catcn']);


    $lists = DB::fetch_all('select * from %t where fid=%d order by id asc', array(
        'zimu_zhaopin_jobfair_online_com',
        $ids
    ));

    foreach ($lists as $key => $value) {

        $lists[$key]['profile'] = DB::fetch_first('select * from %t where id=%d order by id desc', array(
            'zimu_zhaopin_company_profile',
            $value['com_id']
        ));
    }

    $filename = $jobfairdata['title'].date('Y-m-d',time()).'.xlsx';

    $titles = array($language_zimu['admins_jobfair_online_inc_php_0'].'ID',$language_zimu['admins_jobfair_online_inc_php_1'],$language_zimu['admins_jobfair_online_inc_php_2'],$language_zimu['admins_jobfair_online_inc_php_3'],$language_zimu['admins_jobfair_online_inc_php_4'],$language_zimu['admins_jobfair_online_inc_php_5'],$language_zimu['admins_jobfair_online_inc_php_6'],$language_zimu['admins_jobfair_online_inc_php_7'],$language_zimu['admins_jobfair_online_inc_php_8'],$language_zimu['admins_jobfair_online_inc_php_9'],$language_zimu['admins_jobfair_online_inc_php_10']);

    ob_get_clean();
    ob_start();
    echo implode("\t", $titles),"\n";

    foreach ($lists as $key=>$value) {
        $row                             = array();
        $row['id']                = $value['profile']['id'];
        $row['companyname']            = $value['profile']['companyname'];
        $row['trade_cn']            = $value['profile']['trade_cn'];
        $row['catcn']            = $jobfairdata['catcn'][$value['catcn']];
        $row['district_cn']                = $value['profile']['district_cn'];
        $row['contact']                        = $value['profile']['contact'];
        $row['telephone']                   = $value['profile']['telephone'];
        $row['setmeal_name']                    = $value['profile']['setmeal_name'];
        $row['address']                 = $value['profile']['address'];
        $row['contents']       = strip_tags($value['profile']['contents']);
        $row['contents'] = str_replace(array(
            "\r\n",
            "\r",
            "\n"
        ), "", $row['contents']);
        $row['addtime']         = date('Y-m-d H:i',$value['profile']['addtime']);

        echo implode("\t", $row),"\n";
    }


    header('Content-Disposition: attachment; filename='.$filename);
    header('Accept-Ranges:bytes');
    header('Content-Length:' . ob_get_length());
    header('Content-Type:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    ob_end_flush();
    exit();


} else {


        
    $wheresql = 'where 1=1 ';

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_jobfair_online",
        $wheresql
    ));

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_zhaopin_jobfair_online',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type .'_'. $op,'');
    
    
}