<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');

require_once DISCUZ_ROOT . './source/plugin/zimu_domain/config.php';

@include DISCUZ_ROOT . './data/sysdata/cache_domain.php';

if (!$_G['setting']['domain']['root']['plugin']) {
	cpmsg($language_zimu['Admin_plugin_inc_php_0'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zimu_domain&pmod=Admin_plugin', 'succeed');
}

$domainlist = $_G['setting']['domain']['list'];

foreach ($domainlist as $k => $v) {
	if ($v['idtype'] == 'plugin') {
		$domainlist2[$v['id']] = $k;
	}
}

if (!submitcheck('editsubmit')) {

	showtips($language_zimu['Admin_plugin_inc_php_1']);

	showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zimu_domain&pmod=Admin_plugin');

	showtableheader($language_zimu['Admin_plugin_inc_php_2']);

	showsubtitle(array($language_zimu['Admin_plugin_inc_php_3'], $language_zimu['Admin_plugin_inc_php_4']));

	$list = C::t('common_plugin')->fetch_all_data(1);

	foreach ($list as $value) {

		$value['id'] = substr($value['id'], 0, strpos($value['id'], ':'));

		showtablerow('', array('width="400px"', 'class="longtxt"', 'class="longtxt"'), array(
			$value['name'] . "(" . $value['identifier'] . ")",
			'<input type="text" class="txt" name="newdomain[' . $value['pluginid'] . ']" value="' . $domainlist2[$value['identifier']] . '" />',
		));
	}
	showsubmit('editsubmit', 'submit');
	showtablefooter();
	showformfooter();

} else {

	foreach ($_GET['newdomain'] as $key => $value) {
		if (!empty($value)) {
			$domainroot_array = explode('.', $value);
			$domain = $domainroot_array[0];
			$domainroot = $domainroot_array[1].'.'.$domainroot_array[2];
			$data = array('domain' => $domain, 'domainroot' => $domainroot, 'idtype' => 'plugin', 'id' => $key);
			C::t('common_domain')->insert($data, false, true);
		}else{
			C::t('common_domain')->delete_by_id_idtype($key,'plugin');
		}
	}

	updatecache('setting');
	cpmsg($language_zimu['Admin_base_inc_php_2'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zimu_domain&pmod=Admin_plugin', 'succeed');

}