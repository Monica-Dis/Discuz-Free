<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$language_zimu =  array (
  'Admin_base_inc_php_0' => '<li>开启插件域名前请先在此页面配置根域名，否则插件二级域名将不会生效。</li>
<li>此处的根域名是指你网站的根域名，请不要加http://或www，如百度的根域名为：<b>baidu.com</b></li>',
  'Admin_base_inc_php_1' => '网站根域名',
  'Admin_base_inc_php_2' => '修改成功',
  'Admin_plugin_inc_php_0' => '请先配置网站根域名',
  'Admin_plugin_inc_php_1' => '<li>插件各自绑定的域名不能相同，域名不需要添加“http://”，也不要以“/”结尾，例如：portal.comsenz.com</li><li>任意开启一项域名，需要配置默认域名，否则会造成多入口问题，<a href="'.ADMINSCRIPT.'?action=domain&operation=app" target="_blank">马上配置</a></li><li>当开启多域名时，请在 config/config_global.php 中修改 cookiedomain 值来设置 cookie 作用域，如修改为 “.baidu.com“, 注意前面有个点</li>',
  'Admin_plugin_inc_php_2' => '插件域名列表',
  'Admin_plugin_inc_php_3' => '插件名称',
  'Admin_plugin_inc_php_4' => '插件域名',
);
?>