<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$langfile = DISCUZ_ROOT . './source/plugin/zimu_domain/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_domain');

include $includefile;

$zmdata = $_G['cache']['plugin']['zimu_domain'];

$formhash = $_G['formhash'];