<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$langfile = DISCUZ_ROOT . './source/plugin/zimu_dati/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_dati');

include $includefile;

define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimu_dati/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimu_dati');
define('SITE_URL', $_G['siteurl']);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);

$zmdata = $_G['cache']['plugin']['zimu_dati'];

$formhash = $_G['formhash'];

if ($_G['charset'] == 'gbk') {
	$charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
	$charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
	$charset = 'big5';
}

$_G['isajax'] = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
$_G['ispost'] = $_SERVER['REQUEST_METHOD'] == 'POST';


function isuid()
{
    global $_G;
    $zmdata = $_G['cache']['plugin']['zimu_dati'];
    define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
    define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
    define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);

    $referer = $_G['siteurl'] . $_SERVER['REQUEST_URI'];

    if (IN_MAGAPP && !$_G['uid'] && $zmdata['magapp_hostname'] && $zmdata['magapp_secret']){

        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        $info = strstr($userAgent, "MAGAPPX");
        $info=explode("|",$info);
        $token = $info[7];

        $appurl = $zmdata['magapp_hostname'].'/mag/cloud/cloud/getUserInfo?token='.$token.'&secret='.$zmdata['magapp_secret'];
        
        $appdata = dfsockopen($appurl);
        if (!$appdata) {
            $appdata = file_get_contents($appurl);
        }
        $r =  json_decode($appdata, true);
        if($r['data']['user_id']>0){

            $member = getuserbyuid($r['data']['user_id'], 1);
            if (!$member) {
                dheader('Location:' . $_G['siteurl'] . 'member.php?mod=logging&action=login&referer=' . urlencode($referer));
                exit();
            }
            if (isset($member['_inarchive'])) {
                C::t('common_member_archive')->move_to_master($member['uid']);
            }
            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
            return true;

        }else{
            exit('<script src="source/plugin/zimu_dati/static/js/magjs-x.js"></script><script>
                mag.toLogin(function(){
                    top.location.href="' . $referer . '";
                    });
                    </script>'); 
        }


    }else if (!$_G['uid']) {

            if (IN_XIAOYUNAPP) {
                exit('<script language="javascript" src="source/plugin/zimu_dati/static/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
        AppbymeJavascriptBridge.login(function(data){
            top.location.href="' . $referer . '";
        });
    });
    </script>');
            } else if (IN_MAGAPP) {
                exit('<script src="source/plugin/zimu_dati/static/js/magjs-x.js"></script><script>
                    mag.toLogin(function(){
            top.location.href="' . $referer . '";
  });
    </script>');
            } else if (IN_QFAPP) {
                exit('<script src="//apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //登陆失败
                alert(data.error);//data.error: string
            }
        });
    }
    </script>');
            } else {
                dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&referer=' . urlencode($referer));
                exit();
            }
        }




    }


function tpl_form_field_image($id, $val) {
	if (!$val) {
		$val = 'source/plugin/zimu_dati/static/nopic.jpg';
	}

$langfile = DISCUZ_ROOT . './source/plugin/zimu_dati/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_dati');

include $includefile;

	return '<div class="input-group "><input type="text" name="textfield_' . $id . '" type="file" id="textfield_' . $id . '" class="form-control valid" /><span class="input-group-btn"><input type="button" name="button" id="button1" value="'.$language_zimu['config_php_0'].'" class="btn btn-primary" /></span><input name="' . $id . '" type="file" class="type-file-file" id="' . $id . '" style="position: absolute;top: 0px;left: 0px;height: 40px;width: 100%;filter: alpha(opacity: 0);opacity: 0;cursor: pointer;" size="200" hidefocus="true">
  </div><div class="input-group " style="margin-top:6px;"><img src="' . $val . '" class="img-responsive img-thumbnail" width="150" id="img_' . $id . '"></div>';

}

function savebasepic($post) {
	if (!file_exists(dirname(__FILE__) . '/uploadzimucms/' . date("Ym") . '/' . date("d"))) {
		mkdir(dirname(__FILE__) . '/uploadzimucms/' . date("Ym") . '/' . date("d"));
	}
	$picname = '/uploadzimucms/' . date("Ym") . '/' . date("d") . '/' . time() . rand(100, 999) . '.jpg';
	$file = dirname(__FILE__) . $picname;
	$base64 = base64_decode($post);
	$save = file_put_contents($file, $base64);
	if ($save) {
		return ZIMUCMS_PATH . $picname;
	}
}

function zimu_array_utf8($String)
{
    if (is_array($String)) {
        foreach ($String as $key => $val) {
            $String[$key] = zimu_array_utf8($val);
        }
    } else {
        if (preg_match("/^[A-Za-z0-9\s]+$/", $String)) {
            $String = $String;
        } else {
            $String = diconv($String,CHARSET,'UTF-8');
        }
    }
    return $String;
}
function sqr($n){
    return $n*$n;
}
function xRandom($bonus_min,$bonus_max){
    $sqr = intval(sqr($bonus_max-$bonus_min));
    $rand_num = rand(0, ($sqr-1));
    return intval(sqrt($rand_num));
}
function getBonus($bonus_total, $bonus_count, $bonus_max, $bonus_min) {
    $result = array();

    $average = $bonus_total / $bonus_count;

    $a = $average - $bonus_min;
    $b = $bonus_max - $bonus_min;

    //
    //这样的随机数的概率实际改变了，产生大数的可能性要比产生小数的概率要小。
    //这样就实现了大部分红包的值在平均数附近。大红包和小红包比较少。
    $range1 = sqr($average - $bonus_min);
    $range2 = sqr($bonus_max - $average);

    for ($i = 0; $i < $bonus_count; $i++) {
        //因为小红包的数量通常是要比大红包的数量要多的，因为这里的概率要调换过来。
        //当随机数>平均值，则产生小红包
        //当随机数<平均值，则产生大红包
        if (rand($bonus_min, $bonus_max) > $average) {
            // 在平均线上减钱
            $temp = $bonus_min + xRandom($bonus_min, $average);
            $result[$i] = $temp;
            $bonus_total -= $temp;
        } else {
            // 在平均线上加钱
            $temp = $bonus_max - xRandom($average, $bonus_max);
            $result[$i] = $temp;
            $bonus_total -= $temp;
        }
    }
    // 如果还有余钱，则尝试加到小红包里，如果加不进去，则尝试下一个。
    while ($bonus_total > 0) {
        for ($i = 0; $i < $bonus_count; $i++) {
            if ($bonus_total > 0 && $result[$i] < $bonus_max) {
                $result[$i]++;
                $bonus_total--;
            }
        }
    }
    // 如果钱是负数了，还得从已生成的小红包中抽取回来
    while ($bonus_total < 0) {
        for ($i = 0; $i < $bonus_count; $i++) {
            if ($bonus_total < 0 && $result[$i] > $bonus_min) {
                $result[$i]--;
                $bonus_total++;
            }
        }
    }
    return $result;
}

function sendHB($money_total, $num,$min,$max) {
    if($money_total < $num*0.01) {
        echo 'money to little';exit();
    }

    $rand_arr = array();
    for($i=0; $i<$num; $i++) {
        $rand = rand(1, 100);
        $rand_arr[] = $rand;
    }

    $rand_sum = array_sum($rand_arr);
    $rand_money_arr = array();
    $rand_money_arr = array_pad($rand_money_arr, $num, $min);  //保证每个红包至少0.01
    foreach ($rand_arr as $key => $r) {
        $rand_money = number_format($money_total*$r/$rand_sum, 2);
        if($rand_money <= $min || round(array_sum($rand_money_arr),2) >= round($money_total, 2)) {
            $rand_money_arr[$key] = $min;
        }else if($rand_money >= $max) {
            $rand_money_arr[$key] = $max;
        } else {
            $rand_money_arr[$key] = $rand_money;
        }
    }
    $max_index = $max_rand = 0;
    foreach ($rand_money_arr as $key => $rm) {
        if($rm > $max_rand) {
            $max_rand = $rm;
            $max_index = $key;
        }
    }

    ksort($rand_money_arr);
    return $rand_money_arr;
}

function zm_wechat_auth()
{
    global $_G;

    if (!IN_WECHAT) {
        return;
    }

$aid = intval($_GET['aid']);

$zmdata = $_G['cache']['plugin']['zimu_dati'];

$wechat_client2 = new WeChatClient($zmdata['weixin_appid'],$zmdata['weixin_appsecret']);

list($openid,$uptime) = getcookie('zm_dati_openid') ? explode("\t",authcode(getcookie('zm_dati_openid'), 'DECODE')) : array();

if($openid){
return $openid;
}

$code = addslashes($_GET['code']);

if ($code && $_GET['codewx']==1){
        $token = $wechat_client2->getAccessTokenByCode($code);
        if (!$token['openid'] && !$openid) {
            showmessage('error'.($token['errmsg'] ? ' AccessToken: '.$token['errmsg'] : ''), $referer);
        }

if(!$token['openid']){
$newtoken = $wechat_client2->getAccessToken(1,0);
}else{
set_oauth_cookie($token['openid']);
}

}else{

if($_G['cache']['plugin']['zimu_dati']['oauth2_url']){

$login_url = $_G['cache']['plugin']['zimu_dati']['oauth2_url'].'?appid='.$zmdata['weixin_appid'].'&scope=snsapi_base&state='.md5(FORMHASH).'&redirect_uri=' . urlencode(ZIMUCMS_URL.'&model=view&aid='.$aid.'&codewx=1&type='.intval($_GET['type']).'&fromuid='.intval($_GET['fromuid']));

}else{

$login_url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $zmdata['weixin_appid'] . '&redirect_uri=' . urlencode(ZIMUCMS_URL.'&model=view&aid='.$aid.'&codewx=1&type='.intval($_GET['type']).'&fromuid='.intval($_GET['fromuid'])) . '&response_type=code&scope=snsapi_base&state=' . md5(FORMHASH) . '#wechat_redirect';

}

dheader('Location:' . $login_url);

}



}

function set_oauth_cookie($openid)
{
    global $_G;
    dsetcookie('zm_dati_openid', authcode($openid . "\t" . TIMESTAMP, 'ENCODE'), 12000, 1, true);
}
function qf_nonce($length = 32)
{
    $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    $str   = "";
    for ($i = 0; $i < $length; $i++) {
        $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
    }
    return $str;
}
function qf_sign($params, $secret)
{
    ksort($params);
    $sparams = array();
    foreach ($params as $k => $v) {
        if ("@" != substr($v, 0, 1)) {
            $sparams[] = "$k=$v";
        }
    }
    $sparams[] = "secret=" . $secret;
    return strtoupper(md5(implode("&", $sparams)));
}
function lizimu_post($url, $data) {
        if (!function_exists('curl_init')) {
            return '';
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        # curl_setopt( $ch, CURLOPT_HEADER, 1);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $data = curl_exec($ch);
        if (!$data) {
            error_log(curl_error($ch));
        }
        curl_close($ch);
        return $data;
}
function zm_saveimages($FILES, $type = 'zimucms')
{
    global $_G;

    require_once DISCUZ_ROOT . './source/plugin/zimu_dati/new_discuz_upload.php';

    $upload = new discuz_upload_zimucms();

    $upload->init($FILES, 'uploadzimucms');
    if ($upload->error()) {
        return '';
    }

    $upload->save();
    if ($upload->error()) {
        return '';
    }

    $pic = $upload->attach['attachment'];

    if ($upload->attach['imageinfo'][0] > 1500 || $upload->attach['imageinfo'][1] > 1500) {
        if ($upload->attach['imageinfo'][0] >= $upload->attach['imageinfo'][1]) {
            $thumb_width = $upload->attach['imageinfo'][0] / 2;
        } else {
            $thumb_width = $upload->attach['imageinfo'][1] / 2;
        }

        require_once libfile('class/image');
        $image = new image();
        $pic2  = $image->Thumb($upload->attach['target'], '', $thumb_width, $thumb_width, 2);
    }

    if ($pic2) {
        return ZIMUCMS_PATH . 'uploadzimucms/' . $pic . '.thumb.jpg';
    } else {
        return ZIMUCMS_PATH . 'uploadzimucms/' . $pic;
    }
}
function zimu_currenturl($related = 0)
{
    $sys_protocal = (isset($_SERVER['SERVER_PORT']) ? $_SERVER['SERVER_PORT'] == 443 : (isset($_SERVER['SERVER_PORT']) ? 'https://' : 'http://'));
    if($sys_protocal==1){
    $sys_protocal = 'https://';
    }else if($sys_protocal==0){
    $sys_protocal = 'http://';
    }
    global $_G;
    $php_self   = ($_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME']);
    $path_info  = (isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '');
    $relate_url = (isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self . (isset($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : $path_info));
    return ($related ? $relate_url : $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '') . $relate_url);
}
function getrandshare(){
    global $_G;
    $zmdata = $_G['cache']['plugin']['zimu_dati'];
    $sharedomainarr = array_filter(explode("\r\n",$zmdata['share_domain']));
    if($sharedomainarr){
        return $sharedomainarr[rand(0,count($sharedomainarr) - 1)].'plugin.php?';
    }
}
function get_response($secret_key, $url, $get_params, $post_data = array()){
    $nonce         = rand(10000, 99999);
    $timestamp  = time();
    $array = array($nonce, $timestamp, $secret_key);
    sort($array, SORT_STRING);
    $token = md5(implode($array));
    $params['nonce'] = $nonce;
    $params['timestamp'] = $timestamp;
    $params['token']     = $token;
    $params = array_merge($params,$get_params);  
    $url .= '?';
    foreach ($params as $k => $v) 
    {
        $url .= $k .'='. $v . '&';
    }
    $url = rtrim($url,'&');   
    $curlHandle = curl_init();
    curl_setopt($curlHandle, CURLOPT_URL, $url);   
    curl_setopt($curlHandle, CURLOPT_HEADER, 0);   
    curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, 1);  
    curl_setopt($curlHandle, CURLOPT_SSL_VERIFYPEER, false);  
    curl_setopt($curlHandle, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($curlHandle, CURLOPT_POST, count($post_data));  
    curl_setopt($curlHandle, CURLOPT_POSTFIELDS, $post_data);  
    $data = curl_exec($curlHandle);    
    $status = curl_getinfo($curlHandle, CURLINFO_HTTP_CODE);
    curl_close($curlHandle);    
    return $data;
}
function pagination($total, $pageIndex, $pageSize = 15, $url = '', $context = array('before' => 5, 'after' => 4, 'ajaxcallback' => '', 'callbackfuncname' => '')) {
    global $_G;

$langfile = DISCUZ_ROOT . './source/plugin/zimu_dati/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_dati');

include $includefile;

    $pdata = array(
        'tcount' => 0,
        'tpage' => 0,
        'cindex' => 0,
        'findex' => 0,
        'pindex' => 0,
        'nindex' => 0,
        'lindex' => 0,
        'options' => ''
    );
    
    $pdata['tcount'] = $total;
    $pdata['tpage'] = (empty($pageSize) || $pageSize < 0) ? 1 : ceil($total / $pageSize);
    if ($pdata['tpage'] <= 1) {
        return '';
    }
    $cindex = $pageIndex;
    $cindex = min($cindex, $pdata['tpage']);
    $cindex = max($cindex, 1);
    $pdata['cindex'] = $cindex;
    $pdata['findex'] = 1;
    $pdata['pindex'] = $cindex > 1 ? $cindex - 1 : 1;
    $pdata['nindex'] = $cindex < $pdata['tpage'] ? $cindex + 1 : $pdata['tpage'];
    $pdata['lindex'] = $pdata['tpage'];


    $_GET['page'] = $pdata['findex'];
    $pdata['faa'] = 'href="'.ADMINSCRIPT.'?' . http_build_query($_GET) . '"';
    $_GET['page'] = $pdata['pindex'];
    $pdata['paa'] = 'href="'.ADMINSCRIPT.'?' . http_build_query($_GET) . '"';
    $_GET['page'] = $pdata['nindex'];
    $pdata['naa'] = 'href="'.ADMINSCRIPT.'?' . http_build_query($_GET) . '"';
    $_GET['page'] = $pdata['lindex'];
    $pdata['laa'] = 'href="'.ADMINSCRIPT.'?' . http_build_query($_GET) . '"';

    $html = '<div><ul class="pagination pagination-centered">';
    if ($pdata['cindex'] > 1) {
        $html .= "<li><a {$pdata['faa']} class=\"pager-nav\">".$language_zimu['config_php_1']."</a></li>";
        $html .= "<li><a {$pdata['paa']} class=\"pager-nav\">&laquo;".$language_zimu['config_php_2']."</a></li>";
    }
    if (!$context['before'] && $context['before'] != 0) {
        $context['before'] = 5;
    }
    if (!$context['after'] && $context['after'] != 0) {
        $context['after'] = 4;
    }

    if ($context['after'] != 0 && $context['before'] != 0) {
        $range = array();
        $range['start'] = max(1, $pdata['cindex'] - $context['before']);
        $range['end'] = min($pdata['tpage'], $pdata['cindex'] + $context['after']);
        if ($range['end'] - $range['start'] < $context['before'] + $context['after']) {
            $range['end'] = min($pdata['tpage'], $range['start'] + $context['before'] + $context['after']);
            $range['start'] = max(1, $range['end'] - $context['before'] - $context['after']);
        }
        for ($i = $range['start']; $i <= $range['end']; $i++) {
            if ($context['isajax']) {
                $aa = 'href="javascript:;" page="' . $i . '" '. ($callbackfunc ? 'onclick="'.$callbackfunc.'(\'' . $url . '\', \'' . $i . '\', this);return false;"' : '');
            } else {
                if ($url) {
                    $aa = 'href="?' . str_replace('*', $i, $url) . '"';
                } else {
                    $_GET['page'] = $i;
                    $aa = 'href="?' . http_build_query($_GET) . '"';
                }
            }
            $html .= ($i == $pdata['cindex'] ? '<li class="active"><a href="javascript:;">' . $i . '</a></li>' : "<li><a {$aa}>" . $i . '</a></li>');
        }
    }

    if ($pdata['cindex'] < $pdata['tpage']) {
        $html .= "<li><a {$pdata['naa']} class=\"pager-nav\">".$language_zimu['config_php_3']."&raquo;</a></li>";
        $html .= "<li><a {$pdata['laa']} class=\"pager-nav\">".$language_zimu['config_php_4']."</a></li>";
    }
    $html .= '</ul></div>';
    return $html;
}