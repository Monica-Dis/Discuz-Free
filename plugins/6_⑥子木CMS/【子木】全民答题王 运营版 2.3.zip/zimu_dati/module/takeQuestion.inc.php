<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$_G['uid']){exit();}

$aid = intval($_GET['aid']);

$aiddata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimu_dati_list',
        $aid
    ));


if($aiddata['startDate'] > $_G['timestamp']){

$json['retCode'] = -2;
$json['model']['responseCode'] = 5;
$json['message'] = zimu_array_utf8($language_zimu['takeQuestion_inc_php_0']);
echo json_encode($json);exit();

}

if($aiddata['endDate'] < $_G['timestamp']){

$json['retCode'] = -2;
$json['model']['responseCode'] = 5;
$json['message'] = zimu_array_utf8($language_zimu['takeQuestion_inc_php_1']);
echo json_encode($json);exit();

}

$issuccess = DB::result_first("SELECT count(*) FROM %t where aid=%d and uid=%d", array(
    "zimu_dati_successlog",
    $aid,
    $_G['uid']
));

$issuccess_ty = DB::result_first("SELECT count(*) FROM %t where aid=%d and uid=%d and addtime>%d", array(
    "zimu_dati_successlog",
    $aid,
    $_G['uid'],
		strtotime(date('Y-m-d',$_G['timestamp']))
));

if($issuccess >= $aiddata['singleUserAwards']){
$json['retCode'] = -2;
$json['model']['responseCode'] = 5;
$json['message'] = zimu_array_utf8($language_zimu['takeQuestion_inc_php_2'].$aiddata['singleUserAwards'].$language_zimu['takeQuestion_inc_php_3']);
echo json_encode($json);exit();
}

if($issuccess_ty >= $aiddata['singleUserDayAwards']){
$json['retCode'] = -2;
$json['model']['responseCode'] = 5;
$json['message'] = zimu_array_utf8($language_zimu['takeQuestion_inc_php_4'].$aiddata['singleUserDayAwards'].$language_zimu['takeQuestion_inc_php_5']);
echo json_encode($json);exit();
}

$question = DB::fetch_first('select * from %t where aid=%d and postion=1 order by rand() limit 1', array(
        'zimu_dati_question',
        $aid
    ));

if(!$question){

$question = DB::fetch_first('select id,question,options1,options2,options3,options4,options5 from %t where aid=%d and postion=0 order by rand() limit 1', array(
        'zimu_dati_question',
        $aid
    ));

}

if(!$question){

$question = DB::fetch_first('select id,question,options1,options2,options3,options4,options5 from %t where aid=0 order by rand() limit 1', array(
        'zimu_dati_question',
        $aid
    ));

}

if($_GET['md5hash'] == formhash() ){
    $userlogdata = array(
        'aid' => $aid,
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'addtime' => $_G['timestamp']
    );
    DB::insert('zimu_dati_userlog', $userlogdata);
}

dsetcookie('answer_order_'.$_G['uid'],0, 120, 1, true);
dsetcookie('redheartnum_' . $_G['uid'].'_'.$aid, 0, 360, 1, true);

dsetcookie('answer_time_'.$aid,time(),300);


$json['retCode'] = 0;
$json['message'] = 'success';
$json['model']['question'] = zimu_array_utf8($question);

echo json_encode($json);
