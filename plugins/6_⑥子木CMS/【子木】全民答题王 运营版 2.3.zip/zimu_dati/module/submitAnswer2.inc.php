<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if (!$_G['uid']) {
    exit();
}

$aid = intval($_GET['aid']);

$issuccess = DB::result_first("SELECT count(*) FROM %t where aid=%d and uid=%d", array(
    "zimu_dati_successlog",
    $aid,
    $_G['uid']
));

$order = intval($_GET['order']);

$myorder = getcookie('answer_order_' . $_G['uid']);

$listview = DB::fetch_first('select * from %t where id=%d order by id desc', array(
    'zimu_dati_list',
    $aid
));

$newquestion = DB::fetch_first('select * from %t where aid=%d and postion=%d order by rand() limit 1', array(
    'zimu_dati_question',
    $aid,
    $myorder + 2
));

if (!$newquestion) {
    
    $newquestion = DB::fetch_first('select id,question,options1,options2,options3,options4 from %t order by rand() limit 1', array(
        'zimu_dati_question'
    ));
}

$myuser = DB::fetch_first('select * from %t where aid=%d and uid=%d order by id desc', array(
    'zimu_dati_user',
    $aid,
    $_G['uid']
));


$json['retCode']                  = 0;
$json['message']                  = 'success';
$json['type']                     = $listview['awardType'];
$json['model']['lastOneQuestion'] = $question['answer'];
$json['model']['question']        = zimu_array_utf8($newquestion);


if ($myuser['redheartnum'] > $listview['milriddleReliveCardNum']) {
    
    $curCanUseReliveCard = $listview['milriddleReliveCardNum'];
    
} else {
    
    $curCanUseReliveCard = $myuser['redheartnum'];
    
}

    $curCanUseReliveCard = $curCanUseReliveCard - getcookie('redheartnum_' . $_G['uid'].'_'.$aid);

if($listview['share_hy_nums'] > 0 ){
$share_hy_nums = $listview['share_hy_nums'] - getcookie('share_hy_nums_' . $_G['uid']);
}
if($listview['share_pyq_nums'] > 0 ){
$share_pyq_nums = $listview['share_pyq_nums'] - getcookie('share_pyq_nums_' . $_G['uid']);
}

if (IN_WECHAT && ($share_hy_nums > 0 || $share_pyq_nums > 0) ) {

if($share_hy_nums>0){
dsetcookie('share_hy_nums_' . $_G['uid'], getcookie('share_hy_nums_' . $_G['uid'])+1, 3600, 1, true);
}elseif($share_pyq_nums>0){
dsetcookie('share_pyq_nums_' . $_G['uid'], getcookie('share_pyq_nums_' . $_G['uid'])+1, 3600, 1, true);    
}

    $json['model']['share_hy_nums'] = $share_hy_nums;
    $json['model']['share_pyq_nums'] = $share_pyq_nums;
    $json['model']['responseCode'] = 6;

}


$json['myorder'] = getcookie('answer_order_' . $_G['uid']);


echo json_encode($json);
