<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(IN_WECHAT && $zmdata['share_domain'] && $_GET['share'] != 333 ){
$oldurl = str_replace('//', '/', zimu_currenturl());
$oldurl = parse_url($oldurl);
$newdomain = getrandshare();
$newurl = $newdomain.$oldurl['query'].'&share=333';
dheader('Location:' . $newurl);
exit();
}

$touser = intval($_GET['touser']);
if($zmdata['open_app']){$zmdata['guest_help']=0;}
if(!$zmdata['guest_help'] || $touser == 1 ){
isuid();
}

$aid = intval($_GET['aid']);

$listview = DB::fetch_first('select * from %t where id=%d order by id desc', array(
	'zimu_dati_list',
	$aid,
));

if(IN_WECHAT && $zmdata['weixin_appid'] && $zmdata['weixin_appsecret'] && $listview['awardType'] == 1){
$openid = zm_wechat_auth();
}


$issuccess = DB::result_first("SELECT count(*) FROM %t where aid=%d and uid=%d order by id desc", array(
		"zimu_dati_successlog",
		$aid,
    $_G['uid']
));

$myavatar = avatar($_G['uid'],'middle',true);

$myuser = DB::fetch_first('select * from %t where aid=%d and uid=%d order by id desc', array(
        'zimu_dati_user',
        $aid,
        $_G['uid']
    ));

if(!$myuser){
  $zimu_dati_userdata = array(
      'aid' => $aid,
      'uid' => $_G['uid'],
      'username' => $_G['username'],
      'redheartnum' => 0,
      'addtime' => $_G['timestamp']
  );
  DB::insert('zimu_dati_user', $zimu_dati_userdata);
}

$todayUsedNum = DB::result_first("SELECT count(*) FROM %t where aid=%d and uid=%d and addtime>%d", array(
    "zimu_dati_userlog",
    $aid,
    $_G['uid'],
    strtotime(date('Y-m-d',$_G['timestamp']))
));

if($listview['totalLotteryCountRadio']==2){

$yesterdayUsedNum = DB::result_first("SELECT count(*) FROM %t where aid=%d and uid=%d and addtime<%d", array(
    "zimu_dati_userlog",
    $aid,
    $_G['uid'],
    strtotime(date('Y-m-d',$_G['timestamp']))
));

if($listview['totalLotteryCount'] - $yesterdayUsedNum > $listview['dayLotteryCount'] ){

$mr_day_answer_num = $listview['dayLotteryCount'] - $todayUsedNum;

}else{

$mr_day_answer_num = $listview['totalLotteryCount'] - $yesterdayUsedNum - $todayUsedNum;

}

}else{

$mr_day_answer_num = $listview['dayLotteryCount'] - $todayUsedNum;

}

$curCanUseReliveCard = $myuser['redheartnum'];

$fromuid = intval($_GET['fromuid']);
$type = intval($_GET['type']);

if( ( !$zmdata['guest_help'] || $_G['uid'] > 0 ) && $_GET['type'] ){

	$used_lucky = DB::result_first("SELECT count(*) FROM %t where aid=%d and uid=%d", array(
	        'zimu_dati_helplog',
	        $aid,
	        $_G['uid']
	));

if($listview['withHelpCount'] == 0){
$vip_lucky = $listview['withHelpCountLimit'];
}else{
$vip_lucky = 33333;
}

	$isadd = DB::fetch_first('select * from %t where aid=%d and uid=%d and touid=%d order by id desc', array(
	        'zimu_dati_helplog',
	        $aid,
	        $_G['uid'],
	        $fromuid,
	        $type,
	        strtotime(date('Y-m-d',$_G['timestamp']))
	    ));

	if($_G['uid']>0 && $fromuid != $_G['uid'] && $fromuid>0 && $used_lucky < $vip_lucky && !$isadd ){

	$isluckyadd = 1;

	}

}else{

	if($listview['withHelpCount'] == 0){
	$vip_lucky = $listview['withHelpCountLimit'];
	}else{
	$vip_lucky = 33333;
	}

	if(getcookie('help_'.$aid.'_'.$fromuid) !=1 && $fromuid > 0 && getcookie('help_'.$aid.'_nums') < $vip_lucky && $fromuid != $_G['uid'] ){

  $isluckyadd = 1;

	}


}

if($fromuid){
	$fromuiduser = DB::fetch_first('select * from %t where aid=%d and uid=%d order by id desc', array(
	        'zimu_dati_user',
	        $aid,
	        $fromuid
	    ));
}

if($_G['uid'] && $zmdata['open_app'] && (IN_MAGAPP || IN_QFAPP || IN_XIAOYUNAPP)){

    DB::query("update %t set open_app=1 where uid=%d and aid=%d and addtime>%d", array(
        'zimu_dati_helplog',
        $_G['uid'],
        $aid,
        $_G['timestamp'] - $zmdata['open_app_time']*3600
    ));

    $affect_rows = DB::affected_rows();

  DB::query("update %t set redheartnum=redheartnum+%d where aid=%d and uid=%d", array(
      'zimu_dati_user',
      $affect_rows,
      $aid,
      $fromuid
  ));

}




    DB::query("update %t set views=views+1 where id=%d", array(
        'zimu_dati_list',
        $aid,
    ));
 

$allnums = DB::result_first("SELECT count(*) FROM %t where aid=%d order by id desc", array(
    "zimu_dati_user",
    $aid
));

$successnums = DB::result_first("SELECT count(*) FROM %t where aid=%d order by id desc", array(
    "zimu_dati_successlog",
    $aid
));

$successnums = $successnums + $listview['milriddleRankNum2'];


$zmdata['view_tips'] = str_replace(array('views','allnums','successnums'),array($listview['views'],$allnums,$successnums),$zmdata['view_tips']);


if(!$listview['shareType']){
$listview['title_bg'] = explode('source/plugin/zimu_dati', $listview['title_bg']);
$listview['title_bg'] = $_G['siteurl'].'source/plugin/zimu_dati'.$listview['title_bg'][1];
//$myavatar = parse_url($myavatar);
$myavatar = ZIMUCMS_URL.'&model=imgurl&imgurl='.$myavatar;
}

$share_title = str_replace('#username#', $_G['username'],$listview['share_title']);
$share_desc = str_replace('#username#', $_G['username'],$listview['share_desc']);
$share_thumb = $listview['share_thumb'];
if(IN_XIAOYUNAPP || IN_QFAPP || IN_MAGAPP){
$share_url = ZIMUCMS_URL.'&model=view&aid='.$aid.'&type=3&fromuid='.$_G['uid'];
}else{
$share_url = ZIMUCMS_URL.'&model=view&aid='.$aid.'&type=1&fromuid='.$_G['uid'];
}

include template('zimu_dati:view');
