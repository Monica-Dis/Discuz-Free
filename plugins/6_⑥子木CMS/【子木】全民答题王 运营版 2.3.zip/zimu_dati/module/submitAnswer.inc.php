<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if (!$_G['uid']) {
    exit();
}

$aid = intval($_GET['aid']);

$aiddata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimu_dati_list',
        $aid
    ));

$issuccess = DB::result_first("SELECT count(*) FROM %t where aid=%d and uid=%d", array(
    "zimu_dati_successlog",
    $aid,
    $_G['uid']
));

$issuccess_ty = DB::result_first("SELECT count(*) FROM %t where aid=%d and uid=%d and addtime>%d", array(
    "zimu_dati_successlog",
    $aid,
    $_G['uid'],
    strtotime(date('Y-m-d',$_G['timestamp']))
));

if($issuccess >= $aiddata['singleUserAwards']){
$json['retCode'] = -2;
$json['model']['responseCode'] = 5;
$json['message'] = zimu_array_utf8($language_zimu['takeQuestion_inc_php_2'].$aiddata['singleUserAwards'].$language_zimu['takeQuestion_inc_php_3']);
echo json_encode($json);exit();
}

if($issuccess_ty >= $aiddata['singleUserDayAwards']){
$json['retCode'] = -2;
$json['model']['responseCode'] = 5;
$json['message'] = zimu_array_utf8($language_zimu['takeQuestion_inc_php_4'].$aiddata['singleUserDayAwards'].$language_zimu['takeQuestion_inc_php_5']);
echo json_encode($json);exit();
}


$questionId = intval($_GET['questionId']);

$answerIndex = intval($_GET['answerIndex']);

$order = intval($_GET['order']);

$myorder = getcookie('answer_order_' . $_G['uid']);

$listview = DB::fetch_first('select * from %t where id=%d order by id desc', array(
    'zimu_dati_list',
    $aid
));

$question = DB::fetch_first('select * from %t where id=%d order by id desc', array(
    'zimu_dati_question',
    $questionId
));


$newquestion = DB::fetch_first('select * from %t where aid=%d and postion=%d order by rand() limit 1', array(
    'zimu_dati_question',
    $aid,
    $myorder + 2
));

if (!$newquestion) {
    
    $newquestion = DB::fetch_first('select id,question,options1,options2,options3,options4,options5 from %t where aid=%d and postion=0 order by rand() limit 1', array(
        'zimu_dati_question',
        $aid
    ));
}

if (!$newquestion) {
    
    $newquestion = DB::fetch_first('select id,question,options1,options2,options3,options4,options5 from %t where aid=0 order by rand() limit 1', array(
        'zimu_dati_question',
        $aid
    ));
}

$myuser = DB::fetch_first('select * from %t where aid=%d and uid=%d order by id desc', array(
    'zimu_dati_user',
    $aid,
    $_G['uid']
));


$json['retCode']                  = 0;
$json['message']                  = 'success';
$json['type']                     = $listview['awardType'];
$json['model']['lastOneQuestion'] = $question['answer'];
$json['model']['question']        = zimu_array_utf8($newquestion);


if ($myuser['redheartnum'] > $listview['milriddleReliveCardNum']) {
    
    $curCanUseReliveCard = $listview['milriddleReliveCardNum'];
    
} else {
    
    $curCanUseReliveCard = $myuser['redheartnum'];
    
}

    $curCanUseReliveCard = $curCanUseReliveCard - getcookie('redheartnum_' . $_G['uid'].'_'.$aid);

if($listview['share_hy_nums'] > 0 ){
$share_hy_nums = $listview['share_hy_nums'] - getcookie('share_hy_nums_' . $_G['uid']);
}
if($listview['share_pyq_nums'] > 0 ){
$share_pyq_nums = $listview['share_pyq_nums'] - getcookie('share_pyq_nums_' . $_G['uid']);
}

if ($question['answer'] == $answerIndex) {
    
    dsetcookie('answer_order_' . $_G['uid'], $myorder + 1, 120, 1, true);
    
    if ($myorder == $listview['milriddleQuestionNum'] - 1 && $order == $listview['milriddleQuestionNum']) {
        
        $json['model']['responseCode'] = 5;
        
        if ($_GET['md5hash'] == formhash()) {
            
            $successnum = DB::result_first("SELECT count(*) FROM %t where aid=%d", array(
                "zimu_dati_successlog",
                $aid
            ));
            
            if ($successnum < $listview['milriddleRankNum'] - $listview['milriddleRankNum2'] ) {
                
                if ($listview['awardType'] == 1) {
                    
                    $luckymoneylist = unserialize($listview['luckymoneylist']);
                    
                    $money = $luckymoneylist[$successnum];
                    
                    $successlog = array(
                        'aid' => $aid,
                        'uid' => $_G['uid'],
                        'username' => $_G['username'],
                        'money' => $money,
                        'addtime' => $_G['timestamp']
                    );
                    
                    if ($zmdata['app_money'] == 1) {
                        
                        if (IN_WECHAT) {
                            
                            /*
                            list($openid, $uptime) = getcookie('zm_dati_openid') ? explode("\t", authcode(getcookie('zm_dati_openid'), 'DECODE')) : array();
                            
                            require_once DISCUZ_ROOT . '/source/plugin/zimu_dati/class/wxpay.class.php';
                            $input               = new WxPayData();
                            $input->mch_billno   = MCHID . date('Ymd') . time();
                            $input->send_name    = strip_tags(diconv($zmdata['send_name'], CHARSET, 'UTF-8'));
                            $input->wishing      = strip_tags(diconv($zmdata['wishing'], CHARSET, 'UTF-8'));
                            $input->act_name     = strip_tags(diconv($zmdata['act_name'], CHARSET, 'UTF-8'));
                            $input->remark       = strip_tags(diconv($zmdata['act_name'], CHARSET, 'UTF-8'));
                            $input->re_openid    = $openid;
                            $input->total_amount = intval($money);
                            $input->total_num    = 1;
                            $input->scene_id     = 'PRODUCT_4';
                            $result              = WxPayApi::sendredpack($input);
                            
                            if ($result["result_code"] == "SUCCESS") {
                                
                                $successlog['status']     = 1;
                                $successlog['resultcode'] = $result['send_listid'] . diconv($result['return_msg'], 'utf-8', CHARSET);
                                
                            } else {
                                
                                $successlog['status']     = 0;
                                $successlog['resultcode'] = $result['send_listid'] . diconv($result['return_msg'], 'utf-8', CHARSET);
                                
                            }
                            */
                            
                        } else {
                            
                            $successlog['status'] = 0;
                            
                        }
                        
                        
                        
                        
                        
                        
                    } elseif ($zmdata['app_money'] == 2) {

                        /*
                        $order_id = 'APP' . date('Ymd') . time();
                        $amount   = round($money / 100, 2);
                        $urls     = $zmdata['magapp_hostname'] . '/core/pay/pay/accountTransfer?&user_id=' . $_G['uid'] . '&amount=' . $amount . '&remark=dati&out_trade_code=' . $order_id . '&secret=' . $zmdata['magapp_secret'];
                        $r        = dfsockopen($urls);
                        $r        = json_decode($r, true);
                        
                        if (!intval($r['success'])) {
                            
                            $successlog['status']     = 0;
                            $successlog['resultcode'] = $order_id . diconv($r['msg'], 'utf-8', CHARSET);
                            
                            
                        } else {
                            
                            $successlog['status']     = 1;
                            $successlog['resultcode'] = $order_id . diconv($r['msg'], 'utf-8', CHARSET);
                            
                            if ($zmdata['magapp_hostname'] && $zmdata['magapp_secret']) {
                                $magurl                          = $zmdata['magapp_hostname'] . '/mag/operative/v1/assistant/sendAssistantMsg';
                                $magpostdata['user_id']          = $_G['uid'];
                                $magpostdata['type']             = 'remind';
                                $magpostdata['content']          = diconv('{"type":"text","content":"' . $language_zimu['submitAnswer_inc_php_0'] . $amount . $language_zimu['submitAnswer_inc_php_1'] . '"}', CHARSET, 'utf-8');
                                $magpostdata['assistant_secret'] = $zmdata['assistant_secret'];
                                $magpostdata['secret']           = $zmdata['magapp_secret'];
                                $magpostdata['is_push']          = 1;
                                $magdata                         = lizimu_post($magurl, $magpostdata);
                            }
                            
                            
                        }
                        */

                    } elseif ($zmdata['app_money'] == 3) {
                        
                        /*
                        $nonce        = qf_nonce();
                        $secret       = $zmdata['qf_secret'];
                        $data         = array(
                            'uid' => $_G['uid'],
                            'type' => $zmdata['qf_type'],
                            'amount' => $userinfo['money'],
                            'nonce' => $nonce
                        );
                        $data['sign'] = qf_sign($data, $secret);
                        $qfurl        = 'http://' . $zmdata['qf_hostname'] . '.qianfanapi.com/api1_2/balance/add';
                        $qfdata       = lizimu_post($qfurl, $data);
                        $retqf        = json_decode($qfdata, true);
                        if ($retqf['ret'] == 0) {
                            
                            $successlog['status']     = 1;
                            $successlog['resultcode'] = $retqf['data']['record_id'] . diconv($retqf['text'], 'utf-8', CHARSET);
                            
                        } else {
                            
                            $successlog['status']     = 0;
                            $successlog['resultcode'] = $retqf['data']['record_id'] . diconv($retqf['text'], 'utf-8', CHARSET);
                            
                        }
                        */
                        
                        
                    }
                    
                    if(getcookie('answer_time_' . $aid)){
                    $successlog['usetime'] = time() - getcookie('answer_time_' . $aid);
                    }
                    
                    DB::insert('zimu_dati_successlog', $successlog);
                    
                    $json['curGetPrizeRank'] = $successnum + 1;
                    $json['getPrizeVal']     = $money;
                    
                    //判断奖品为卡券的情况
                } else {
                    
                    $verifycode = random(8, true);
                    while (1) {
                        $count = DB::result_first("SELECT count(*) FROM %t where verifycode=%d and aid=%d", array(
                            "zimu_dati_successlog",
                            $verifycode,
                            $aid
                        ));
                        if ($count <= 0) {
                            break;
                        }
                        $verifycode = random(8, true);
                    }
                    
                    $successlog = array(
                        'aid' => $aid,
                        'uid' => $_G['uid'],
                        'username' => $_G['username'],
                        'verifycode' => $verifycode,
                        'addtime' => $_G['timestamp']
                    );
                    if ($listview['handticket'] == 1) {
                        $successlog['verifycode'] = 'zimu_dati';
                    }
                    
                    if(getcookie('answer_time_' . $aid)){
                    $successlog['usetime'] = time() - getcookie('answer_time_' . $aid);
                    }
                    
                    DB::insert('zimu_dati_successlog', $successlog);
                    $json['curGetPrizeRank'] = $successnum + 1;
                    
                    
                    
                }
                
                
            } else {
                
                $json['retCode'] = -2;
                $json['message'] = zimu_array_utf8($language_zimu['submitAnswer_inc_php_2'] . $listview['trophyName'] . $language_zimu['submitAnswer_inc_php_3']);
                
            }
            
            
        }
        
    } else {
        
        $json['model']['responseCode'] = 4;
        
    }

} else if ($_GET['md5hash'] == formhash() && IN_WECHAT && ($share_hy_nums > 0 || $share_pyq_nums > 0) && $question['answer'] != $answerIndex) {

    $json['model']['share_hy_nums'] = $share_hy_nums;
    $json['model']['share_pyq_nums'] = $share_pyq_nums;
    $json['model']['responseCode'] = 6;

} else if ($_GET['md5hash'] == formhash() && $curCanUseReliveCard > 0 && $question['answer'] != $answerIndex) {

    dsetcookie('redheartnum_' . $_G['uid'].'_'.$aid, getcookie('redheartnum_' . $_G['uid'].'_'.$aid)+1, 360, 1, true);
    DB::query("update %t set redheartnum=redheartnum-1 where aid=%d and uid=%d", array(
        'zimu_dati_user',
        $aid,
        $_G['uid']
    ));
    
    $json['model']['responseCode'] = 3;
    
} else {
    
    dsetcookie('answer_order_' . $_G['uid'], 0, 120, 1, true);
    $json['model']['responseCode'] = -2;
    
}



$json['myorder'] = getcookie('answer_order_' . $_G['uid']);


echo json_encode($json);
