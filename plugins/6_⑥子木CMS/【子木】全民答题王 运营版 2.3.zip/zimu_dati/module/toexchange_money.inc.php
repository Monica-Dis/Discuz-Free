<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!$_G['uid']){exit();}


define('SF_APPID', $zmdata['weixin_appid']);
define('SF_MCHID', $zmdata['weixin_mchid']);
define('SF_APPSECRET', $zmdata['weixin_appsecret']);
define('SF_WXPAY_KEY', $zmdata['weixin_paykey']);

include_once(DISCUZ_ROOT.'source/plugin/zimu_dati/lib/wxpay/lib/WxPay.Config.php');
include_once(DISCUZ_ROOT.'source/plugin/zimu_dati/lib/wxpay/lib/WxPay.Api.php');
include_once(DISCUZ_ROOT.'source/plugin/zimu_dati/lib/wxpay/example/WxPay.JsApiPay.php');
include_once(DISCUZ_ROOT.'source/plugin/zimu_dati/lib/wxpay/example/WxPay.NativePay.php');
include_once(DISCUZ_ROOT.'source/plugin/zimu_dati/lib/wxpay/example/log.php');
include_once(DISCUZ_ROOT.'source/plugin/zimu_dati/lib/wxpay/lib/WxPay.Data.php');




$aid = intval($_GET['aid']);
$sid = intval($_GET['sid']);

$userinfo = DB::fetch_first('select * from %t where aid=%d and id=%d and uid=%d and status=0', array(
    'zimu_dati_successlog',
    $aid,
    $sid,
    $_G['uid']
));

if($userinfo && $userinfo['status'] == 0 ){
if($zmdata['app_money']==1 && $_GET['md5hash'] == formhash() ){

list($openid,$uptime) = getcookie('zm_dati_openid') ? explode("\t",authcode(getcookie('zm_dati_openid'), 'DECODE')) : array();

if(!$openid){
  $json['retCode'] = -2;
  $json['message'] = zimu_array_utf8($language_zimu['toexchange_money_inc_php_0']);
  echo json_encode($json);exit();
}


if($zmdata['hb_type']==1){

    $result = WxPayApiSF::promotion(SF_MCHID . date('Ymd') . time(),$openid,intval($userinfo['money']),strip_tags(diconv($zmdata['act_name'], CHARSET, 'UTF-8')));


}else{

require_once DISCUZ_ROOT . '/source/plugin/zimu_dati/class/wxpay.class.php';
$input               = new WxPayData();
$input->mch_billno   = MCHID . date('Ymd') . time();
$input->send_name    = strip_tags(diconv($zmdata['send_name'], CHARSET, 'UTF-8'));
$input->wishing      = strip_tags(diconv($zmdata['wishing'], CHARSET, 'UTF-8'));
$input->act_name     = strip_tags(diconv($zmdata['act_name'], CHARSET, 'UTF-8'));
$input->remark       = strip_tags(diconv($zmdata['act_name'], CHARSET, 'UTF-8'));
$input->re_openid    = $openid;
$input->total_amount = intval($userinfo['money']);
$input->total_num    = 1;
$input->scene_id     = 'PRODUCT_4';
$result              = WxPayApi::sendredpack($input);


}





                if ($result["result_code"] == "SUCCESS") {

                  DB::query("update %t set status=1,exchangetime=%d,resultcode=%s where aid=%d and id=%d and uid=%d", array(
                      'zimu_dati_successlog',
                      $_G['timestamp'],
                      $input->mch_billno,
                      $aid,
                      $sid,
                      $_G['uid']
                  ));

                  $json['retCode'] = 333;
                  echo json_encode($json);exit();

                }else{

                  $json['retCode'] = -2;
                  $json['message'] = $result['return_msg'];
                  echo json_encode($json);exit();

                }

}

if($zmdata['app_money']==2 && $_GET['md5hash'] == formhash() ){

    $order_id = 'APP' . date('Ymd') . time();
    $amount = round($userinfo['money']/100,2);
    $urls = $zmdata['magapp_hostname'].'/core/pay/pay/accountTransfer?&user_id='.$_G['uid'].'&amount='.$amount.'&remark=dati&out_trade_code='.$order_id.'&secret='.$zmdata['magapp_secret'];
    $r = dfsockopen($urls);
    $r =  json_decode($r, true);

    if(!intval($r['success'])){

      DB::query("update %t set resultcode=%s where aid=%d and id=%d and uid=%d", array(
          'zimu_dati_successlog',
          $order_id.diconv($r['msg'], 'utf-8', CHARSET),
          $aid,
          $sid,
          $_G['uid']
      ));

            echo urldecode(json_encode(array(
                'retCode' => -2,
                'message' => urlencode(mb_convert_encoding($r['msg'], CHARSET, 'UTF-8'))
                )));

    }else{

      if($zmdata['magapp_hostname'] && $zmdata['magapp_secret']){
			    $magurl = $zmdata['magapp_hostname'].'/mag/operative/v1/assistant/sendAssistantMsg';
			    $magpostdata['user_id'] = $_G['uid'];
			    $magpostdata['type'] = 'remind';
			    $magpostdata['content'] = diconv('{"type":"text","content":"'.$language_zimu['toexchange_money_inc_php_1'].$amount.$language_zimu['toexchange_money_inc_php_2'].'"}',CHARSET,'utf-8');
			    $magpostdata['assistant_secret'] = $zmdata['assistant_secret'];
			    $magpostdata['secret'] = $zmdata['magapp_secret'];
			    $magpostdata['is_push'] = 1;
			    $magdata = lizimu_post($magurl,$magpostdata);
			}

      DB::query("update %t set status=1,exchangetime=%d,resultcode=%s where aid=%d and id=%d and uid=%d", array(
          'zimu_dati_successlog',
          $_G['timestamp'],
          $order_id,
          $aid,
          $sid,
          $_G['uid']
      ));
      $json['retCode'] = 333;
      echo json_encode($json);exit();

    }

}

if($zmdata['app_money']==3 && $_GET['md5hash'] == formhash() ){

  $nonce  = qf_nonce();
  $secret = $zmdata['qf_secret'];
  $data = array(
      'uid' => $_G['uid'],
      'type' => $zmdata['qf_type'],
      'amount' => $userinfo['money'],
      'nonce' => $nonce
  );
  $data['sign'] = qf_sign($data, $secret);
  $qfurl = 'http://' . $zmdata['qf_hostname'] . '.qianfanapi.com/api1_2/balance/add';
  $qfdata = lizimu_post($qfurl,$data);
  $retqf = json_decode($qfdata, true);
  if($retqf['ret']==0){

  DB::query("update %t set status=1,exchangetime=%d,resultcode=%s where aid=%d and id=%d and uid=%d", array(
      'zimu_dati_successlog',
      $_G['timestamp'],
      $retqf['data']['record_id'],
      $aid,
      $sid,
      $_G['uid']
  ));
  $json['retCode'] = 333;
  echo json_encode($json);exit();

  } else {

    DB::query("update %t set resultcode=%s where aid=%d and id=%d and uid=%d", array(
        'zimu_dati_successlog',
        $retqf['data']['record_id'].diconv($retqf['text'], 'utf-8', CHARSET),
        $aid,
        $sid,
        $_G['uid']
    ));

      echo urldecode(json_encode(array(
          'retCode' => -2,
          'message' => urlencode(mb_convert_encoding($retqf['text'], CHARSET, 'UTF-8'))
          )));

  }

}

}else{
  $json['retCode'] = -2;
  $json['message'] = zimu_array_utf8($language_zimu['toexchange_money_inc_php_3']);
  echo json_encode($json);exit();
}
