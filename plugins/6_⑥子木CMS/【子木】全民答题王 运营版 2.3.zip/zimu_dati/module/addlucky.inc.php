<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$aid = intval($_GET['aid']);
$type = intval($_GET['type']);
$fromuid = intval($_GET['fromuid']);

if($aid && $fromuid && $fromuid != $_G['uid'] && $_GET['md5hash'] == formhash()) {

if($_G['uid']){

  $isadd = DB::fetch_first('select * from %t where aid=%d and uid=%d and touid=%d order by id desc', array(
          'zimu_dati_helplog',
          $aid,
          $_G['uid'],
          $fromuid
      ));

  if(!$isadd){
      $zimu_dati_helplogdata = array(
          'uid' => $_G['uid'],
          'username' => $_G['username'],
          'touid' => $fromuid,
          'aid' => $aid,
          'type' => $type,
          'addtime' => $_G['timestamp']
      );
      if(IN_MAGAPP || IN_QFAPP || IN_XIAOYUNAPP){
        $zimu_dati_helplogdata['open_app'] = 1;
      }
      DB::insert('zimu_dati_helplog', $zimu_dati_helplogdata);
  }

}else{

  if(getcookie('help_'.$aid.'_'.$fromuid) !=1){

	dsetcookie('help_'.$aid.'_'.$fromuid,1,86400,1,true);
	dsetcookie('help_'.$aid.'_nums',getcookie('help_'.$aid.'_nums')+1,86400,1,true);
  $zimu_dati_helplogdata = array(
      'uid' => 0,
      'username' => 'Guest',
      'touid' => $fromuid,
      'aid' => $aid,
      'type' => $type,
      'addtime' => $_G['timestamp']
  );
  DB::insert('zimu_dati_helplog', $zimu_dati_helplogdata);

	}

}


$myuser = DB::fetch_first('select * from %t where aid=%d and uid=%d order by id desc', array(
        'zimu_dati_user',
        $aid,
        $fromuid
    ));

if(!$myuser){

$fromuser = getuserbyuid($fromuid,1);

  $zimu_dati_userdata = array(
      'aid' => $aid,
      'uid' => $fromuid,
      'username' => $fromuser['username'],
      'redheartnum' => 1,
      'addtime' => $_G['timestamp']
  );
  DB::insert('zimu_dati_user', $zimu_dati_userdata);

}else{

if (!$zmdata['open_app'] || ($zmdata['open_app'] && (IN_MAGAPP || IN_QFAPP || IN_XIAOYUNAPP) ) ) {

  DB::query("update %t set redheartnum=redheartnum+1 where aid=%d and uid=%d", array(
      'zimu_dati_user',
      $aid,
      $fromuid
  ));

}

}

    DB::query("update %t set views=views+1 where id=%d", array(
        'zimu_dati_list',
        $aid,
    ));

}
