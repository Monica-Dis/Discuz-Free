<?php
/**
 * Copyright (c) 2021 by dism.taobao.com
 * User: TK
 * Date: 2016/1/19
 * Time: 16:10
 */

class PayNotifyCallBack extends WxPayNotify
{
    public $data = null;
    //查询订单
    public function Queryorder($transaction_id)
    {
        $input = new WxPayOrderQuerySF();
        $input->SetTransaction_id($transaction_id);
        $result = WxPayApiSF::orderQuery($input);
        LogSF::DEBUG("query:" . json_encode($result));
        if(array_key_exists("return_code", $result)
            && array_key_exists("result_code", $result)
            && $result["return_code"] == "SUCCESS"
            && $result["result_code"] == "SUCCESS")
        {
            return true;
        }
        return false;
    }

    //重写回调处理函数
    public function NotifyProcess($data, &$msg)
    {
        $this->data = $data;
        LogSF::DEBUG("call back:" . json_encode($data));
        $notfiyOutput = array();
        if(!array_key_exists("transaction_id", $data)){
            $msg = "param error";
            return false;
        }
        //查询订单，判断订单真实性
        if(!$this->Queryorder($data["transaction_id"])){
            $msg = "query order error";
            return false;
        }
        return true;
    }
}