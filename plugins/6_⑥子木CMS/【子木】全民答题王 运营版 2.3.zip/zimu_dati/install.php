<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

 $sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_zimu_dati_helplog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(100) NOT NULL,
  `touid` int(10) UNSIGNED NOT NULL,
  `aid` int(10) UNSIGNED NOT NULL,
  `type` tinyint(1) UNSIGNED NOT NULL,
  `open_app` tinyint(1) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `touid` (`touid`),
 KEY `aid` (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_dati_list` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` char(250) NOT NULL,
  `startDate` int(10) UNSIGNED NOT NULL,
  `endDate` int(10) UNSIGNED NOT NULL,
  `totalLotteryCountRadio` tinyint(1) UNSIGNED NOT NULL,
  `totalLotteryCount` tinyint(3) UNSIGNED NOT NULL,
  `dayLotteryCount` tinyint(3) UNSIGNED NOT NULL,
  `singleUserDayAwards` tinyint(2) UNSIGNED NOT NULL,
  `singleUserAwards` tinyint(3) UNSIGNED NOT NULL,
  `milriddleQuestionNum` tinyint(3) UNSIGNED NOT NULL DEFAULT '12',
  `milriddleRankNum` smallint(3) UNSIGNED NOT NULL,
  `milriddleRankNum2` smallint(3) UNSIGNED NOT NULL,
  `is_options` tinyint(1) UNSIGNED NOT NULL,
  `milriddleAnswerTimeNum` tinyint(3) UNSIGNED NOT NULL,
  `share_hy_nums` smallint(3) UNSIGNED NOT NULL,
  `share_pyq_nums` smallint(3) UNSIGNED NOT NULL,
  `milriddleReliveCardNum` tinyint(3) UNSIGNED NOT NULL,
  `withHelpCount` tinyint(1) UNSIGNED NOT NULL,
  `withHelpCountLimit` tinyint(3) UNSIGNED NOT NULL,
  `awardType` tinyint(1) UNSIGNED NOT NULL,
  `trophyName` char(200) NOT NULL,
  `handticket` tinyint(1) UNSIGNED NOT NULL,
  `leixing1_tip` char(200) NOT NULL,
  `shopuid` char(200) NOT NULL,
  `exchange_pass` char(30) NOT NULL,
  `totalCount` float NOT NULL,
  `singleMin` float NOT NULL,
  `singleMax` float NOT NULL,
  `luckymoneylist` text NOT NULL,
  `validityStart` int(10) UNSIGNED NOT NULL,
  `validityStop` int(10) UNSIGNED NOT NULL,
  `validityNotice` char(250) NOT NULL,
  `title_bg` char(255) NOT NULL,
  `bg_bg` char(255) NOT NULL,
  `music_url` char(255) NOT NULL,
  `hd_rule` text NOT NULL,
  `shareType` tinyint(1) UNSIGNED NOT NULL,
  `share_thumb` char(255) NOT NULL,
  `share_title` char(255) NOT NULL,
  `share_desc` char(255) NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `sort` tinyint(3) UNSIGNED NOT NULL DEFAULT '100',
  `addtime` int(10) UNSIGNED NOT NULL,
  `is_diyfields` tinyint(1) UNSIGNED NOT NULL,
  `diyfields` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_dati_question` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `aid` int(10) UNSIGNED NOT NULL,
  `question` char(100) DEFAULT NULL,
  `options1` char(100) DEFAULT NULL,
  `options2` char(100) DEFAULT NULL,
  `options3` char(100) DEFAULT NULL,
  `options4` char(100) DEFAULT NULL,
  `options5` char(100) DEFAULT NULL,
  `answer` tinyint(1) UNSIGNED NOT NULL,
  `postion` tinyint(3) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
 KEY `aid` (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_dati_successlog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `aid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(50) NOT NULL,
  `money` smallint(5) UNSIGNED NOT NULL,
  `verifycode` char(30) NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL,
  `resultcode` varchar(2000) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  `exchangetime` int(10) UNSIGNED NOT NULL,
  `leixing1_text` char(200) NOT NULL,
  `usetime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `aid` (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_dati_user` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `aid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(50) NOT NULL,
  `redheartnum` tinyint(3) UNSIGNED NOT NULL,
  `diyfields` text NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `aid` (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_dati_userlog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `aid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) NOT NULL,
  `username` char(50) NOT NULL,
  `questionid` int(10) UNSIGNED NOT NULL,
  `answer` tinyint(1) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `aid` (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;

runquery($sql);

$finish = TRUE;
?>