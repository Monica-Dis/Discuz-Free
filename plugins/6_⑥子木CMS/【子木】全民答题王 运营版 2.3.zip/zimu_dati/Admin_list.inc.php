<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimu_dati/config.php';

loadcache('plugin');

$zmdata = $_G['cache']['plugin']['zimu_dati'];

$model = addslashes($_GET['model']);

if ($model == 'edit') {

    if (submitcheck('submit')) {

        $data['title']                  = strip_tags($_GET['title']);
        $data['startDate']              = strtotime($_GET['startDate']);
        $data['endDate']                = strtotime($_GET['endDate']);
        $data['totalLotteryCountRadio'] = intval($_GET['totalLotteryCountRadio']);
        $data['totalLotteryCount']      = intval($_GET['totalLotteryCount']);
        $data['dayLotteryCount']        = intval($_GET['dayLotteryCount']);
        $data['singleUserDayAwards']       = intval($_GET['singleUserDayAwards']);
        $data['singleUserAwards']       = intval($_GET['singleUserAwards']);
        $data['milriddleQuestionNum']   = intval($_GET['milriddleQuestionNum']);
        $data['milriddleRankNum']       = intval($_GET['milriddleRankNum']);
        $data['milriddleRankNum2']       = intval($_GET['milriddleRankNum2']);
        $data['is_options']             = intval($_GET['is_options']);
        $data['milriddleAnswerTimeNum'] = intval($_GET['milriddleAnswerTimeNum']);
        $data['milriddleReliveCardNum'] = intval($_GET['milriddleReliveCardNum']);
        $data['share_hy_nums']          = intval($_GET['share_hy_nums']); 
        $data['share_pyq_nums']         = intval($_GET['share_pyq_nums']);
        $data['withHelpCount']          = intval($_GET['withHelpCount']);
        $data['withHelpCountLimit']     = intval($_GET['withHelpCountLimit']);
        $data['awardType']              = intval($_GET['awardType']);
        $data['trophyName']             = strip_tags($_GET['trophyName']);
        $data['handticket']             = intval($_GET['handticket']);
        $data['leixing1_tip']             = strip_tags($_GET['leixing1_tip']);
        $data['shopuid']             = strip_tags($_GET['shopuid']);
        $data['exchange_pass']             = strip_tags($_GET['exchange_pass']);
        $data['totalCount']             = round($_GET['totalCount'], 2);
        $data['singleMin']              = round($_GET['singleMin'], 2);
        $data['singleMax']              = round($_GET['singleMax'], 2);

        $luckymoneylist = explode("\r\n", trim($_GET['luckymoneylist']));

        $data['luckymoneylist'] = serialize($luckymoneylist);

        $data['validityStart'] = strtotime($_GET['validityStart']);
        $data['validityStop']  = strtotime($_GET['validityStop']);
        $data['validityNotice']  = strip_tags($_GET['validityNotice']);
        if ($_FILES['title_bg']['tmp_name']) {
            $data['title_bg'] = zm_saveimages($_FILES['title_bg']);
        }
        if ($_FILES['bg_bg']['tmp_name']) {
            $data['bg_bg'] = zm_saveimages($_FILES['bg_bg']);
        }
        $data['music_url'] = strip_tags($_GET['music_url']);
        $data['hd_rule']   = dhtmlspecialchars($_GET['hd_rule']);
        $data['shareType'] = intval($_GET['shareType']);
        if ($_FILES['share_thumb']['tmp_name']) {
            $data['share_thumb'] = zm_saveimages($_FILES['share_thumb']);
        }
        $data['share_title'] = strip_tags($_GET['share_title']);
        $data['share_desc']  = strip_tags($_GET['share_desc']);
        $data['views']       = intval($_GET['views']);
        $data['sort']        = intval($_GET['sort']);
        $data['addtime']     = strtotime($_GET['addtime']);
        $data['id']          = intval($_GET['ids']);

        if ($data['is_options'] == 1) {
            $options = array();
            foreach ($_GET['options']['question'] as $key => $val) {
                $val      = trim($val);
                $options1 = trim($_GET['options']['options1'][$key]);
                $options2 = trim($_GET['options']['options2'][$key]);
                $options3 = trim($_GET['options']['options3'][$key]);
                $options4 = trim($_GET['options']['options4'][$key]);
                $options5 = trim($_GET['options']['options5'][$key]);
                $answer   = intval($_GET['options']['answer'][$key]);
                $postion  = intval($_GET['options']['postion'][$key]);
                $addtime  = strtotime($_GET['options']['addtime'][$key]);
                if (empty($val)) {
                    continue;
                }
                $options[] = array(
                    'id' => intval($_GET['options']['id'][$key]),
                    'question' => $val,
                    'options1' => $options1,
                    'options2' => $options2,
                    'options3' => $options3,
                    'options4' => $options4,
                    'options5' => $options5,
                    'answer' => $answer,
                    'postion' => $postion,
                    'addtime' => $addtime
                );
            }
        }

        $data['is_diyfields'] = intval($_GET['is_diyfields']);
        if($data['is_diyfields'] == 1) {
            $data['diyfields'] = serialize($_GET['diyfields']);
        }

        if ($data['id'] > 0) {

            $result = DB::update('zimu_dati_list', $data, array(
                'id' => $data['id']
            ));

        } else {

            if(!$data['title_bg']){
                $data['title_bg'] = $_G['siteurl'].'source/plugin/zimu_dati/static/image/title.png';
            }
            if(!$data['bg_bg']){
                $data['bg_bg'] = $_G['siteurl'].'source/plugin/zimu_dati/static/image/bg.jpg';
            }
                 
            $result = DB::insert('zimu_dati_list', $data, 1);

            $data['id'] = $result;

        }

        if (!empty($options) && $data['is_options'] == 1) {
            foreach ($options as $val) {
                $option_id = $val['id'];
                if ($option_id > 0) {

                    DB::update('zimu_dati_question', $val, array(
                        'id' => $option_id,
                        'aid' => $data['id']
                    ));

                } else {
                    $val['aid'] = $data['id'];
                    $option_id  = DB::insert('zimu_dati_question', $val, 1);
                }
                $option_ids[] = $option_id;
            }
        }

        DB::query('delete from %t WHERE aid = %d and postion!=0 and ' . DB::field('id', $option_ids, 'notin'), array(
            'zimu_dati_question',
            $data['id']
        ));


        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']);
        cpmsg($language_zimu['Admin_list_inc_php_0'], $url, 'succeed');

    } else {

        $aid = intval($_GET['aid']);

        $listdata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
            'zimu_dati_list',
            $aid
        ));

        if ($listdata['is_options']) {
            $listdata['options'] = DB::fetch_all('select * from %t where aid=%d order by postion asc,id asc', array(
                'zimu_dati_question',
                $aid
            ));
        }

        if($listdata['is_diyfields'] == 1) {
            $listdata['diyfields'] = (array) unserialize($listdata['diyfields']);;
        }


        $luckymoneylist      = unserialize($listdata['luckymoneylist']);
        $luckymoneylist_text = '';
        foreach ($luckymoneylist as $key => $v) {
            $luckymoneylist_text = $luckymoneylist_text . "\r\n" . $v;
        }
        include template('zimu_dati:Admin_editlist');

    }

} else if ($model == 'user') {

    $aid = intval($_GET['aid']);

    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);

    $wheresql = ' WHERE aid = ' . $aid;

    $keyword = strip_tags($_GET['keyword']);    
    $keyword = dhtmlspecialchars($keyword);
    $keyword = stripsearchkey($keyword);
    $keyword = daddslashes($keyword);

    if ($keyword) {
        include_once libfile('function/search');
        $wheresql .= searchkey($keyword, "uid LIKE '%{text}%' or username LIKE '%{text}%'");
    }

    $count = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_dati_user",
        $wheresql
    ));

    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_dati_user',
        $wheresql,
        $start,
        $limit
    ));

    if ($page_num > 1) {

        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=' . $model . '&aid=' . $aid, '10000', '20', TRUE, TRUE);

    }

    include template('zimu_dati:Admin_user');

} else if ($model == 'successlog') {

    $aid = intval($_GET['aid']);

    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);

    $wheresql = ' WHERE aid = ' . $aid;

    $keyword = strip_tags($_GET['keyword']);    
    $keyword = dhtmlspecialchars($keyword);
    $keyword = stripsearchkey($keyword);
    $keyword = daddslashes($keyword);

    if ($keyword) {
        include_once libfile('function/search');
        $wheresql .= searchkey($keyword, "uid LIKE '%{text}%' or username LIKE '%{text}%'");
    }

    $count = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_dati_successlog",
        $wheresql
    ));

    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_dati_successlog',
        $wheresql,
        $start,
        $limit
    ));

    if ($page_num > 1) {

        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=' . $model . '&aid=' . $aid, '10000', '20', TRUE, TRUE);

    }


$viewdata = DB::fetch_first('select * from %t where id=%d', array(
        'zimu_dati_list',
        $aid
    ));


$view_diyfields = unserialize($viewdata['diyfields']);



    include template('zimu_dati:Admin_successlog');

} else if ($model == 'successlogstatus' && $_GET['md5formhash'] == formhash()) {

    $sid    = intval($_GET['sid']);
    $aid    = intval($_GET['aid']);
    $status = intval($_GET['status']);

    $leixing1_text = strip_tags($_GET['leixing1_text']);

    $addata['leixing1_text'] = $leixing1_text;
    $addata['status']        = $status;
    if ($status == 1) {
        $addata['exchangetime'] = $_G['timestamp'];
    } else {
        $addata['exchangetime'] = '';
    }

    $result = DB::update('zimu_dati_successlog', $addata, array(
        'id' => $sid
    ));

    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=successlog&aid=' . $aid . '&page=' . intval($_GET['page']);
        cpmsg($language_zimu['Admin_list_inc_php_0'], $url, 'succeed');
    } else {
        cpmsg($language_zimu['Admin_list_inc_php_1'], '', 'error');
    }

} else if ($model == 'delsuccesslog' && $_GET['md5formhash'] == formhash()) {

    $sid = intval($_GET['sid']);
    $aid = intval($_GET['aid']);

    $result = DB::delete('zimu_dati_successlog', array(
        'id' => $sid
    ));

    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=successlog&aid=' . $aid . '&page=' . intval($_GET['page']);
        cpmsg($language_zimu['Admin_list_inc_php_0'], $url, 'succeed');
    } else {
        cpmsg($language_zimu['Admin_list_inc_php_1'], '', 'error');
    }

} else if ($model == 'del' && $_GET['md5formhash'] == formhash()) {

    $aid = intval($_GET['aid']);

    $result = DB::delete('zimu_dati_list', array(
        'id' => $aid
    ));

    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg($language_zimu['Admin_list_inc_php_0'], $url, 'succeed');
    } else {
        cpmsg($language_zimu['Admin_list_inc_php_1'], '', 'error');
    }

} else if ($model == 'deluser' && $_GET['md5formhash'] == formhash()) {

    $aid = intval($_GET['aid']);
    $uid = intval($_GET['uid']);

    $result = DB::delete('zimu_dati_user', array(
        'aid' => $aid,
        'uid' => $uid
    ));

    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=user&aid=' . $aid;
        cpmsg($language_zimu['Admin_list_inc_php_0'], $url, 'succeed');
    } else {
        cpmsg($language_zimu['Admin_list_inc_php_1'], '', 'error');
    }

} else if ($model == 'userlog') {

    $aid = intval($_GET['aid']);
    $uid = intval($_GET['uid']);

    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);

    $wheresql = ' WHERE aid = ' . $aid.' and uid='.$uid;

    $keyword = strip_tags($_GET['keyword']);    
    $keyword = dhtmlspecialchars($keyword);
    $keyword = stripsearchkey($keyword);
    $keyword = daddslashes($keyword);

    if ($keyword) {
        include_once libfile('function/search');
        $wheresql .= searchkey($keyword, "uid LIKE '%{text}%' or username LIKE '%{text}%'");
    }

    $count = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_dati_userlog",
        $wheresql
    ));

    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_dati_userlog',
        $wheresql,
        $start,
        $limit
    ));

    if ($page_num > 1) {

        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=' . $model . '&aid=' . $aid . '&$uid=' . $uid, '10000', '20', TRUE, TRUE);

    }

    include template('zimu_dati:Admin_userlog');

} else if ($model == 'helplog') {

    $aid = intval($_GET['aid']);
    $uid = intval($_GET['uid']);

    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);

    $wheresql = ' WHERE aid = ' . $aid.' and touid='.$uid;

    $keyword = strip_tags($_GET['keyword']);    
    $keyword = dhtmlspecialchars($keyword);
    $keyword = stripsearchkey($keyword);
    $keyword = daddslashes($keyword);

    if ($keyword) {
        include_once libfile('function/search');
        $wheresql .= searchkey($keyword, "uid LIKE '%{text}%' or username LIKE '%{text}%'");
    }

    $count = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_dati_helplog",
        $wheresql
    ));

    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_dati_helplog',
        $wheresql,
        $start,
        $limit
    ));

    if ($page_num > 1) {

        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=' . $model . '&aid=' . $aid . '&$uid=' . $uid, '10000', '20', TRUE, TRUE);

    }

    include template('zimu_dati:Admin_helplog');

} else {

    $count = DB::result_first("SELECT count(*) FROM %t", array(
        "zimu_dati_list"
    ));

    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);

    $listdata = DB::fetch_all('select * from %t order by sort asc,id desc limit %d,%d', array(
        'zimu_dati_list',
        $start,
        $limit
    ));

    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']), '10000', '10', TRUE, TRUE);
    }

    include template('zimu_dati:Admin_list');

}
