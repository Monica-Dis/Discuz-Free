<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimu_dati/config.php';

loadcache('plugin');

$zmdata = $_G['cache']['plugin']['zimu_dati'];

$model = addslashes($_GET['model']);
if(!$model){
    $model = 'list';
}

if($model=='list'){


if(submitcheck('submit')) {

        if (!empty($_GET['ids'])) {
            foreach ($_GET['ids'] as $k => $v) {

if($v){

        $data = array('aid' => intval($_GET['aid'][$k]), 'question' => trim($_GET['question'][$k]), 'options1' => trim($_GET['options1'][$k]), 'options2' => trim($_GET['options2'][$k]), 'options3' => trim($_GET['options3'][$k]), 'options4' => trim($_GET['options4'][$k]), 'options5' => trim($_GET['options5'][$k]), 'answer' => intval($_GET['answer'][$k]), 'postion' => intval($_GET['postion'][$k]), 'addtime' => 1);

            DB::update('zimu_dati_question', $data, array(
                'id' => $v
            ));

}elseif(trim($_GET['question'][$k])){

        $data = array('aid' => intval($_GET['aid'][$k]), 'question' => trim($_GET['question'][$k]), 'options1' => trim($_GET['options1'][$k]), 'options2' => trim($_GET['options2'][$k]), 'options3' => trim($_GET['options3'][$k]), 'options4' => trim($_GET['options4'][$k]), 'options5' => trim($_GET['options5'][$k]), 'answer' => intval($_GET['answer'][$k]), 'postion' => intval($_GET['postion'][$k]), 'addtime' => 1);

        DB::insert('zimu_dati_question', $data);

}

            }
        }

        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg($language_zimu['Admin_list_inc_php_0'], $url, 'succeed');

}else{

    $top_lists = DB::fetch_all('select * from %t order by id asc', array(
        'zimu_dati_list',
    ));


    $aid = intval($_GET['aid']);
    if (!empty($aid)) {
        $wheresql .= " where aid = ".$aid;
    }

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_dati_question",
        $wheresql
    ));
    
    $lists = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_dati_question',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);

include template('zimu_dati:Admin_question');

}


} else if ($model == 'del' && $_GET['md5formhash'] == formhash()) {

    $qid = intval($_GET['qid']);

    $result = DB::delete('zimu_dati_question', array(
        'id' => $qid
    ));

    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg($language_zimu['Admin_list_inc_php_0'], $url, 'succeed');
    } else {
        cpmsg($language_zimu['Admin_list_inc_php_1'], '', 'error');
    }

}
