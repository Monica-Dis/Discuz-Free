window.milRiddle = {};
$(function() {  
    FastClick.attach(document.body);  
});
    milRiddle.alertModel = function(t, u) {
        var u = u ? u: 2000;
        $(".mrAlertPage .mrAlertModel").text(t);
        $(".mrAlertPage").show();
        setTimeout(function() {
            $(".mrAlertPage").hide();
            $(".mrAlertPage .mrAlertModel").text("")
        },
        u)
    };
    milRiddle.alertModel2 = function(t, u) {
        $(".mrAlertPage .mrAlertModel").html(t);
        $(".mrAlertPage").show();
        setTimeout(function() {
            $(".mrAlertPage").hide();
            $(".mrAlertPage .mrAlertModel").text("");
            if (typeof(u) == "function") {
                u()
            }
        },
        2500)
    }