<?php
/**
 * 插件更新时执行此文件
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$question = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimu_dati_question'));
$questionarray = mysqltoarray($question);
if (!in_array('options5', $questionarray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimu_dati_question` ADD COLUMN `options5` CHAR(100) NOT NULL;
EOF;
    runquery($sql1);
}

$helplog = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimu_dati_helplog'));
$helplogarray = mysqltoarray($helplog);
if (!in_array('open_app', $helplogarray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimu_dati_helplog` ADD COLUMN `open_app` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

$list = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimu_dati_list'));
$listarray = mysqltoarray($list);
if (!in_array('share_hy_nums', $listarray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimu_dati_list` ADD COLUMN `share_hy_nums` SMALLINT(3) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('share_pyq_nums', $listarray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimu_dati_list` ADD COLUMN `share_pyq_nums` SMALLINT(3) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('milriddleRankNum', $listarray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimu_dati_list` ADD COLUMN `milriddleRankNum` SMALLINT(3) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('milriddleRankNum2', $listarray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimu_dati_list` ADD COLUMN `milriddleRankNum2` SMALLINT(3) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('is_diyfields', $listarray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimu_dati_list` ADD COLUMN `is_diyfields` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('diyfields', $listarray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimu_dati_list` ADD COLUMN `diyfields` TEXT NOT NULL;
EOF;
    runquery($sql1);
}



$user = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimu_dati_user'));
$userarray = mysqltoarray($user);
if (!in_array('diyfields', $userarray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimu_dati_user` ADD COLUMN `diyfields` TEXT NOT NULL;
EOF;
    runquery($sql1);
}


$successlog = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimu_dati_successlog'));
$successlogarray = mysqltoarray($successlog);
if (!in_array('usetime', $successlogarray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimu_dati_successlog` ADD COLUMN `usetime` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}



    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_dati_list` CHANGE `milriddleRankNum` `milriddleRankNum` SMALLINT(3) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);

    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_dati_list` CHANGE `luckymoneylist` `luckymoneylist` MEDIUMTEXT NOT NULL;
EOF;
    runquery($sql1);

$finish = TRUE;

function mysqltoarray($test) {
    $temp = array();
    foreach ($test as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}
