<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: Ӧ�ø���֧�֣�https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimu_fc/config.php';

if (IN_WECHAT && $zmdata['weixin_appid'] && $zmdata['weixin_appsecret']) {
    require_once DISCUZ_ROOT . './source/plugin/zimu_fc/class/wechat.lib.class.php';
    $wechat_client = new WeChatClient($zmdata['weixin_appid'], $zmdata['weixin_appsecret']);
    $jssdkvalue    = $wechat_client->getSignPackage();
}

$model = addslashes($_GET['model']);
$model = !empty($model) ? $model : 'list';

$modellist = array(
    0 => 'addlucky',
    1 => 'dhqrcode',
    2 => 'exchange',
    3 => 'exchange_scan',
    4 => 'joinuser',
    5 => 'list',
    6 => 'myuser',
    7 => 'qrcode',
    8 => 'view',
    9 => 'showdedetails',
    10 => 'cron'
);

if ($model && in_array($model,$modellist) ) {
    
    include DISCUZ_ROOT . './source/plugin/zimu_fc/module/' . $model . '.inc.php';
    
}