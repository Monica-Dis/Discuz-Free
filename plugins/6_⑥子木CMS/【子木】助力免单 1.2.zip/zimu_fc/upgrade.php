<?php
/**
 * 插件更新时执行此文件
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$helplog = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimu_fc_helplog'));
$helplogarray = mysqltoarray($helplog);
if (!in_array('open_app', $helplogarray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimu_fc_helplog` ADD COLUMN `open_app` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('usersign', $helplogarray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimu_fc_helplog` ADD COLUMN `usersign` CHAR(100) NOT NULL;
EOF;
    runquery($sql1);
}

$finish = TRUE;

function mysqltoarray($test) {
    $temp = array();
    foreach ($test as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}
