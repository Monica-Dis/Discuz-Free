<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: Ӧ�ø���֧�֣�https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

 $sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_zimu_fc_helplog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(100) NOT NULL,
  `touid` int(10) UNSIGNED NOT NULL,
  `aid` int(10) UNSIGNED NOT NULL,
  `sid` int(10) UNSIGNED NOT NULL,
  `type` tinyint(1) UNSIGNED NOT NULL,
  `open_app` tinyint(1) UNSIGNED NOT NULL,
  `usersign` char(100) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `username` (`username`),
  KEY `touid` (`touid`),
  KEY `aid` (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_fc_list` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` char(255) NOT NULL,
  `thumb` char(255) NOT NULL,
  `price` char(10) NOT NULL,
  `nums` tinyint(3) UNSIGNED NOT NULL,
  `usednums` tinyint(3) UNSIGNED NOT NULL,
  `content` text NOT NULL,
  `helpnums` tinyint(3) UNSIGNED NOT NULL,
  `handticket` tinyint(1) UNSIGNED NOT NULL,
  `leixing1_tip` char(100) NOT NULL,
  `leixing2_mima` char(10) NOT NULL,
  `shopuid` char(100) NOT NULL,
  `sort` tinyint(3) UNSIGNED NOT NULL DEFAULT '100',
  `views` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `nums` (`nums`),
  KEY `usednums` (`usednums`),
  KEY `helpnums` (`helpnums`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_fc_user` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `aid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(50) NOT NULL,
  `nickname` char(50) NOT NULL,
  `phone` char(20) NOT NULL,
  `address` char(255) NOT NULL,
  `helpnums` tinyint(1) UNSIGNED NOT NULL,
  `helpstatus` tinyint(1) UNSIGNED NOT NULL,
  `verifycode` char(30) NOT NULL,
  `resultcode` char(200) NOT NULL,
  `exchangetime` int(10) UNSIGNED NOT NULL,
  `leixing1_text` char(200) NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `aid` (`aid`),
  KEY `uid` (`uid`),
  KEY `helpnums` (`helpnums`),
  KEY `helpstatus` (`helpstatus`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


EOF;

runquery($sql);

$finish = TRUE;
?>