<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: Ӧ�ø���֧�֣�https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE  IF EXISTS pre_zimu_fc_helplog;
DROP TABLE  IF EXISTS pre_zimu_fc_list;
DROP TABLE  IF EXISTS pre_zimu_fc_user;
EOF;

runquery($sql);

deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_fc/uploadzimucms");

deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_fc/static/kindeditor/attached/image");



deletecache('scache_zimu_fc');
$finish = TRUE;



function deldirfile($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }

    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @deldirfile($path, $empty);
                } else {
                    @unlink($path);
                }
            }
        }

        @closedir($directoryHandle);

        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }

        return true;
    }
}
function deletecache($cachenames) {  
    if(!empty($cachenames)) {  
  DB::delete('common_syscache', array('cname' => $cachenames));
    }  
}