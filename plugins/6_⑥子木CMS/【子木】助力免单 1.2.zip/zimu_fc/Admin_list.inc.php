<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimu_fc/config.php';

loadcache('plugin');/*dism-Taobao-com*/

$zmdata = $_G['cache']['plugin']['zimu_fc'];

$model = addslashes($_GET['model']);

if ($model == 'edit') {

    if (submitcheck('submit')) {

        $data['title']                  = strip_tags($_GET['title']);
        if ($_FILES['thumb']['tmp_name']) {
            $data['thumb'] = zm_saveimages($_FILES['thumb']);
        }
        $data['price']                  = strip_tags($_GET['price']);
        $data['nums']                  = intval($_GET['nums']);
        $data['usednums']                  = intval($_GET['usednums']);
        $data['helpnums']                  = intval($_GET['helpnums']);
        $data['handticket']                = intval($_GET['handticket']);
        $data['leixing1_tip']              = strip_tags($_GET['leixing1_tip']);
        $data['leixing2_mima']             = strip_tags($_GET['leixing2_mima']);
        $data['shopuid']                  = strip_tags($_GET['shopuid']);
        $data['content']   = dhtmlspecialchars($_GET['content']);
        $data['sort']        = intval($_GET['sort']);
        $data['views']        = intval($_GET['views']);
        $data['addtime']              = strtotime($_GET['addtime']);
        $data['id']          = intval($_GET['ids']);

        if ($data['id'] > 0) {

            $result = DB::update('zimu_fc_list', $data, array(
                'id' => $data['id']
            ));

        } else {

            $result = DB::insert('zimu_fc_list', $data, 1);

            $data['id'] = $result;

        }

        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']);
        cpmsg($language_zimu['Admin_list_inc_php_0'], $url, 'succeed');

    }else{


        $aid = intval($_GET['aid']);

        $listdata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
            'zimu_fc_list',
            $aid
        ));

        include template('zimu_fc:Admin_editlist');


    }


} else if ($model == 'del' && $_GET['md5formhash'] == formhash()) {

    $aid = intval($_GET['aid']);

    $result = DB::delete('zimu_fc_list', array(
        'id' => $aid
    ));

    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg($language_zimu['Admin_list_inc_php_1'], $url, 'succeed');
    } else {
        cpmsg($language_zimu['Admin_list_inc_php_2'], '', 'error');
    }

} else if ($model == 'user') {

    $aid = intval($_GET['aid']);

    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);

    $wheresql = ' WHERE aid = ' . $aid;

    $keyword = strip_tags($_GET['keyword']);    
    $keyword = dhtmlspecialchars($keyword);
    $keyword = stripsearchkey($keyword);
    $keyword = daddslashes($keyword);

    if ($keyword) {
        include_once libfile('function/search');
        $wheresql .= searchkey($keyword, "uid LIKE '%{text}%' or username LIKE '%{text}%'");
    }

    $count = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_fc_user",
        $wheresql
    ));

    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_fc_user',
        $wheresql,
        $start,
        $limit
    ));

    if ($page_num > 1) {

        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=' . $model . '&aid=' . $aid, '10000', '20', TRUE, TRUE);

    }

    include template('zimu_fc:Admin_user');

} else if ($model == 'deluser' && $_GET['md5formhash'] == formhash()) {

    $aid = intval($_GET['aid']);
    $sid = intval($_GET['sid']);
    $uid = intval($_GET['uid']);

    $result = DB::delete('zimu_fc_user', array(
        'aid' => $aid,
        'id' => $sid,
        'uid' => $uid
    ));

    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=user&aid=' . $aid;
        cpmsg($language_zimu['Admin_list_inc_php_3'], $url, 'succeed');
    } else {
        cpmsg($language_zimu['Admin_list_inc_php_4'], '', 'error');
    }

} else if ($model == 'successlog') {

    $aid = intval($_GET['aid']);

    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);

    $wheresql = ' WHERE helpstatus=1 and aid = ' . $aid;

    $keyword = strip_tags($_GET['keyword']);    
    $keyword = dhtmlspecialchars($keyword);
    $keyword = stripsearchkey($keyword);
    $keyword = daddslashes($keyword);

    if ($keyword) {
        include_once libfile('function/search');
        $wheresql .= searchkey($keyword, "uid LIKE '%{text}%' or username LIKE '%{text}%'");
    }

    $count = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_fc_user",
        $wheresql
    ));

    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_fc_user',
        $wheresql,
        $start,
        $limit
    ));

    if ($page_num > 1) {

        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=' . $model . '&aid=' . $aid, '10000', '20', TRUE, TRUE);

    }

    include template('zimu_fc:Admin_successlog');

} else if ($model == 'successlogstatus' && $_GET['md5formhash'] == formhash()) {

    $sid    = intval($_GET['sid']);
    $aid    = intval($_GET['aid']);
    $status = intval($_GET['status']);

    $leixing1_text = strip_tags($_GET['leixing1_text']);

    $addata['leixing1_text'] = $leixing1_text;
    $addata['status']        = $status;
    if ($status == 1) {
        $addata['exchangetime'] = $_G['timestamp'];
    } else {
        $addata['exchangetime'] = '';
    }

    $result = DB::update('zimu_fc_user', $addata, array(
        'id' => $sid
    ));

    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=successlog&aid=' . $aid . '&page=' . intval($_GET['page']);
        cpmsg($language_zimu['Admin_list_inc_php_5'], $url, 'succeed');
    } else {
        cpmsg($language_zimu['Admin_list_inc_php_6'], '', 'error');
    }
    
} else if ($model == 'helplog') {

    $aid = intval($_GET['aid']);
    $sid = intval($_GET['sid']);
    $uid = intval($_GET['uid']);

    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);

    $wheresql = ' WHERE aid = ' . $aid.' and sid= ' . $sid . ' and touid='.$uid;

    $count = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_fc_helplog",
        $wheresql
    ));

    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_fc_helplog',
        $wheresql,
        $start,
        $limit
    ));

    if ($page_num > 1) {

        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=' . $model . '&aid=' . $aid . '&$uid=' . $uid, '10000', '20', TRUE, TRUE);

    }

    include template('zimu_fc:Admin_helplog');

}else{


    $count = DB::result_first("SELECT count(*) FROM %t", array(
        "zimu_fc_list"
    ));

    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);

    $listdata = DB::fetch_all('select * from %t order by sort asc,id desc limit %d,%d', array(
        'zimu_fc_list',
        $start,
        $limit
    ));

    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']), '10000', '10', TRUE, TRUE);
    }

    include template('zimu_fc:Admin_list');

}