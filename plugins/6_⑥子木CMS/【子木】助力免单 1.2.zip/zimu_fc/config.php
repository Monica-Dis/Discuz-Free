<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * 应用更新支持：https://dism.taobao.com
 * 应用更新支持：https://dism.taobao.com
 * 本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$langfile = DISCUZ_ROOT . './source/plugin/zimu_fc/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_fc');

include $includefile;

define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimu_fc/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimu_fc');
define('SITE_URL', $_G['siteurl']);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);

$zmdata = $_G['cache']['plugin']['zimu_fc'];

$formhash = $_G['formhash'];

if ($_G['charset'] == 'gbk') {
    $charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
    $charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
    $charset = 'big5';
}


function zm_diconv($str)
{
    global $_G;
    $encode = mb_detect_encoding($str, array(
        "UTF-8",
        "GB2312",
        "GBK"
    ));
    if ($encode != strtoupper(CHARSET)) {
        $keytitle = mb_convert_encoding($str, strtoupper(CHARSET), $encode);
    }
    
    $censorexp = '/^(' . str_replace(array(
        '\\*',
        "\r\n",
        ' '
    ), array(
        '.*',
        '|',
        ''
    ), preg_quote(($_G['cache']['plugin']['zimu_fc']['zimu_luanma'] = trim($_G['cache']['plugin']['zimu_fc']['zimu_luanma'])), '/')) . ')$/i';
    if ($_G['cache']['plugin']['zimu_fc']['zimu_luanma'] && @preg_match($censorexp, $keytitle)) {
        $keytitle = $str;
    }
    if (!$keytitle) {
        $keytitle = $str;
    }
    return $keytitle;
}


function isuid()
{
    global $_G;
    define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
    define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
    define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
        if (!$_G['uid']) {

$referer = $_G['siteurl'] . $_SERVER['REQUEST_URI'];

            if (IN_XIAOYUNAPP) {
                exit('<script language="javascript" src="source/plugin/zimu_fc/static/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
        AppbymeJavascriptBridge.login(function(data){
            top.location.href="' . $referer . '";
        });
    });
    </script>');
            } else if (IN_MAGAPP) {
                exit('<script src="source/plugin/zimu_fc/static/js/magjs-x.js"></script><script>
                    mag.toLogin(function(){
            top.location.href="' . $referer . '";
  });
    </script>');
            } else if (IN_QFAPP) {
                exit('<script src="//apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //登陆失败
                alert(data.error);//data.error: string
            }
        });
    }
    </script>');
            } else {
                dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&referer=' . urlencode($referer));
                exit();
            }
        }
    }


function tpl_form_field_image($id, $val) {
	if (!$val) {
		$val = 'source/plugin/zimu_fc/static/nopic.jpg';
	}

$langfile = DISCUZ_ROOT . './source/plugin/zimu_fc/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_fc');

include $includefile;

	return '<div class="input-group "><input type="text" name="textfield_' . $id . '" type="file" id="textfield_' . $id . '" class="form-control valid" /><span class="input-group-btn"><input type="button" name="button" id="button1" value="'.$language_zimu['config_php_0'].'" class="btn btn-primary" /></span><input name="' . $id . '" type="file" class="type-file-file" id="' . $id . '" style="position: absolute;top: 0px;left: 0px;height: 40px;width: 100%;filter: alpha(opacity: 0);opacity: 0;cursor: pointer;" size="200" hidefocus="true">
  </div><div class="input-group " style="margin-top:6px;"><img src="' . $val . '" class="img-responsive img-thumbnail" width="150" id="img_' . $id . '"></div>';

}

function zimu_array_utf8($String)
{
    if (is_array($String)) {
        foreach ($String as $key => $val) {
            $String[$key] = zimu_array_utf8($val);
        }
    } else {
        if (preg_match("/^[A-Za-z0-9\s]+$/", $String)) {
            $String = $String;
        } else {
            $String = diconv($String,CHARSET,'UTF-8');
        }
    }
    return $String;
}

function qf_nonce($length = 32)
{
    $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    $str   = "";
    for ($i = 0; $i < $length; $i++) {
        $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
    }
    return $str;
}
function qf_sign($params, $secret)
{
    ksort($params);
    $sparams = array();
    foreach ($params as $k => $v) {
        if ("@" != substr($v, 0, 1)) {
            $sparams[] = "$k=$v";
        }
    }
    $sparams[] = "secret=" . $secret;
    return strtoupper(md5(implode("&", $sparams)));
}
function lizimu_post($url, $data) {
        if (!function_exists('curl_init')) {
            return '';
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        # curl_setopt( $ch, CURLOPT_HEADER, 1);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $data = curl_exec($ch);
        if (!$data) {
            error_log(curl_error($ch));
        }
        curl_close($ch);
        return $data;
}

function zm_saveimages($FILES, $type = 'zimucms')
{
    global $_G;

    require_once DISCUZ_ROOT . './source/plugin/zimu_fc/new_discuz_upload.php';

    $upload = new discuz_upload_zimucms();

    $upload->init($FILES, 'uploadzimucms');
    if ($upload->error()) {
        return '';
    }

    $upload->save();
    if ($upload->error()) {
        return '';
    }

    $pic = $upload->attach['attachment'];

    if ($upload->attach['imageinfo'][0] > 1500 || $upload->attach['imageinfo'][1] > 1500) {
        if ($upload->attach['imageinfo'][0] >= $upload->attach['imageinfo'][1]) {
            $thumb_width = $upload->attach['imageinfo'][0] / 2;
        } else {
            $thumb_width = $upload->attach['imageinfo'][1] / 2;
        }

        require_once libfile('class/image');
        $image = new image();
        $pic2  = $image->Thumb($upload->attach['target'], '', $thumb_width, $thumb_width, 2);
    }

    if ($pic2) {
        return '/source/plugin/zimu_fc/uploadzimucms/' . $pic . '.thumb.jpg';
    } else {
        return '/source/plugin/zimu_fc/uploadzimucms/' . $pic;
    }
}
function limit_city($lng,$lat,$address){
        global $_G;
        $zmdata = $_G['cache']['plugin']['zimu_fc'];
        $citys = array_filter(explode("|",$zmdata['citys']));
        if($lng && $lat && (strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme') !== false || strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPPX') !== false || strpos($_SERVER["HTTP_USER_AGENT"],'QianFan') !== false || strpos($_SERVER["HTTP_USER_AGENT"],'MicroMessenger') !== false)){
            if($_G['cookie']['fcaddress']){
                foreach($citys as $key=>$val){
                    if(strpos($_G['cookie']['fcaddress'],$val) !== false){
                        return false;
                    }
                }
                return true; 
            }else{
                $location = json_decode(dfsockopen('https://apis.map.qq.com/ws/geocoder/v1/?location='.$lat.','.$lng.'&key='.$zmdata['key'].'&get_poi=1'),true);
                $location['result']['address'] = diconv($location['result']['address'],'UTF-8',CHARSET);
                if($location['status'] === 0 && $location['result']['address']){
                    dsetcookie('fcaddress',$location['result']['address'],3600);
                    foreach($citys as $key=>$val){
                        if(strpos($location['result']['address'],$val) !== false){
                            return false;
                        }
                    }
                    return true; 
                }
            }
        }else{//ip限制
            if($_G['cookie']['fcaddress']){
                foreach($citys as $key=>$val){
                    if(strpos($_G['cookie']['fcaddress'],$val) !== false){
                        return false;
                    }
                }
                return true;
            }else{
                $location = json_decode(dfsockopen("https://apis.map.qq.com/ws/location/v1/ip?ip=".$_G['clientip'].'&key='.$zmdata['key']),true);
                $address = diconv($location['result']['ad_info']['province'],'UTF-8',CHARSET).diconv($location['result']['ad_info']['city'],'UTF-8',CHARSET).diconv($location['result']['ad_info']['district'],'UTF-8',CHARSET);
                dsetcookie('fcaddress',$address,60);
                foreach($citys as $key=>$val){
                    if(strpos($address,$val) !== false){
                        return false;
                    }
                }
                return true;
            }
        }




}



