<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$aid     = intval($_GET['aid']);
$type    = intval($_GET['type']);
$fromuid = intval($_GET['fromuid']);
$lng     = strip_tags($_GET['lng']);
$lat     = strip_tags($_GET['lat']);
$address = strip_tags($_GET['address']);

if ($zmdata['citys'] && $zmdata['key']) {
    
    if (limit_city($lng, $lat, $address)) {
        $json['status'] = 0;
        echo json_encode($json);
        exit();
    }
    
}

$listdata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
    'zimu_fc_list',
    $aid
));

if ($listdata['usednums'] >= $listdata['nums']) {
    $json['status'] = 0;
    echo json_encode($json);
    exit();
}


if ($aid && $fromuid && $fromuid != $_G['uid'] && $_GET['md5hash'] == formhash()) {
    
    $myuser = DB::fetch_first('select * from %t where aid=%d and uid=%d order by id desc', array(
        'zimu_fc_user',
        $aid,
        $fromuid
    ));
    
    if ($_G['timestamp'] - $zmdata['overtime'] * 3600 > $myuser['addtime']) {
        $json['status'] = 0;
        echo json_encode($json);
        exit();
    }
    
    
    if ($myuser) {
        
        $myuserid = $myuser['id'];
        
        if (!$zmdata['open_app'] && !$zmdata['help_subscribe']) {
            DB::query("update %t set helpnums=helpnums+1 where aid=%d and uid=%d order by id desc limit 1", array(
                'zimu_fc_user',
                $aid,
                $fromuid
            ));
        }
        
        if ($_G['uid']) {
            
            $isadd = DB::fetch_first('select * from %t where aid=%d and uid=%d and touid=%d order by id desc', array(
                'zimu_fc_helplog',
                $aid,
                $_G['uid'],
                $fromuid
            ));
            
            if (!$isadd) {
                $zimu_dati_helplogdata = array(
                    'uid' => $_G['uid'],
                    'username' => $_G['username'],
                    'touid' => $fromuid,
                    'aid' => $aid,
                    'sid' => $myuserid,
                    'type' => $type,
                    'usersign' => getcookie('fc_openid'),
                    'addtime' => $_G['timestamp']
                );
                if (IN_MAGAPP || IN_QFAPP || IN_XIAOYUNAPP || getcookie('issubscribe')==1 ) {
                    $zimu_dati_helplogdata['open_app'] = 1;
                }
                DB::insert('zimu_fc_helplog', $zimu_dati_helplogdata);
            }
            
        } else {
            
            if (getcookie('help_' . $aid . '_' . $fromuid) != 1) {
                
                dsetcookie('help_' . $aid . '_' . $fromuid, 1, 86400, 1, true);
                dsetcookie('help_' . $aid . '_nums', getcookie('help_' . $aid . '_nums') + 1, 86400, 1, true);
                $zimu_dati_helplogdata = array(
                    'uid' => 0,
                    'username' => 'Guest',
                    'touid' => $fromuid,
                    'aid' => $aid,
                    'sid' => $myuserid,
                    'type' => $type,
                    'usersign' => getcookie('fc_openid'),
                    'addtime' => $_G['timestamp']
                );
                DB::insert('zimu_fc_helplog', $zimu_dati_helplogdata);
                
            }
            
        }
        
        if ($listdata['helpnums'] - 1 == $myuser['helpnums'] || ($listdata['helpnums'] >= $myuser['helpnums'] && $myuser['helpstatus'] != 1)) {
            
            if ($listdata['handticket'] == 1) {
                
                DB::query("update %t set helpstatus=1,verifycode=%s where aid=%d and uid=%d order by id desc limit 1", array(
                    'zimu_fc_user',
                    'zimu_fc',
                    $aid,
                    $fromuid
                ));
                
            } else {
                
                $verifycode = random(8, true);
                while (1) {
                    $count = DB::result_first("SELECT count(*) FROM %t where verifycode=%d and aid=%d", array(
                        "zimu_fc_user",
                        $verifycode,
                        $aid
                    ));
                    if ($count <= 0) {
                        break;
                    }
                    $verifycode = random(8, true);
                }
                
                DB::query("update %t set helpstatus=1,verifycode=%d where aid=%d and uid=%d order by id desc limit 1", array(
                    'zimu_fc_user',
                    $verifycode,
                    $aid,
                    $fromuid
                ));
                
            }
            
            DB::query("update %t set views=views+1,usednums=usednums+1 where id=%d", array(
                'zimu_fc_list',
                $aid
            ));
            
            
        } else {
            
            DB::query("update %t set views=views+1 where id=%d", array(
                'zimu_fc_list',
                $aid
            ));
            
        }
        
        $json['status'] = 333;
        echo json_encode($json);
        exit();
        
    }
    
}