<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!$_G['uid']){exit();}

$aid = intval($_GET['aid']);
$nickname = zm_diconv(strip_tags($_GET['nickname']));
$phone = strip_tags($_GET['phone']);
$address = zm_diconv(strip_tags($_GET['address']));
$lng = strip_tags($_GET['lng']);
$lat = strip_tags($_GET['lat']);

if($zmdata['citys'] && $zmdata['key']){
if(limit_city($lng,$lat,$address)){
  $json['status'] = 0;
  $json['message'] = zimu_array_utf8($language_zimu['joinuser_inc_php_0'].$zmdata['citys'].$language_zimu['joinuser_inc_php_1']);
  echo json_encode($json);exit();
}
}

$listdata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimu_fc_list',
        $aid
    ));

$userdata2 = DB::fetch_first('select * from %t where aid=%d and uid=%d and addtime > %d order by id desc', array(
        'zimu_fc_user',
        $aid,
        $_G['uid'],
        $_G['timestamp']-($zmdata['overtime']*3600)
    ));

if($aid && $listdata && $listdata['usednums'] < $listdata['nums'] && $_GET['md5hash'] == formhash() ) {

if(!$userdata2){

        $userdata['aid']                  = $aid;
        $userdata['uid']                  = $_G['uid'];
        $userdata['username']                  = $_G['username'];
        $userdata['nickname']                  = $nickname;
        $userdata['phone']                  = $phone;
        $userdata['address']                  = $address;
        $userdata['helpnums']   = 0;
        $userdata['status']   = 0;
        $userdata['addtime']              = $_G['timestamp'];
        DB::insert('zimu_fc_user', $userdata);
    
}

    $json['status'] = 333;
    echo json_encode($json);exit();


}else{

  $json['status'] = 0;
  $json['message'] = zimu_array_utf8($language_zimu['joinuser_inc_php_2']);
  echo json_encode($json);exit();

}
