<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$aid = intval($_GET['aid']);
$sid = intval($_GET['sid']);
$fromuid = intval($_GET['fromuid']);

$post_shangjia_mima       = strip_tags($_GET['verfiy_pwd']);

$listdata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimu_fc_list',
        $aid
    ));

if($aid && $sid && $fromuid && $_GET['md5hash'] == formhash()) {

if($post_shangjia_mima == $listdata['leixing2_mima']){

    DB::query("update %t set status=1,exchangetime=%d where aid=%d and id=%d and uid=%d", array(
        'zimu_fc_user',
        $_G['timestamp'],
        $aid,
        $sid,
        $fromuid
    ));
    $json['retCode'] = 333;
    echo json_encode($json);exit();

}else{

  $json['retCode'] = -2;
  $json['message'] = zimu_array_utf8($language_zimu['exchange_inc_php_0']);
  echo json_encode($json);exit();

}

}else{

  $json['retCode'] = -2;
  $json['message'] = zimu_array_utf8($language_zimu['exchange_inc_php_1']);
  echo json_encode($json);exit();

}
