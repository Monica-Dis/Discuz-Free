<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$aid = intval($_GET['aid']);
$sid = intval($_GET['sid']);

if(!$_G['uid']){exit();}

	$myuser = DB::result_first("SELECT id FROM %t where id=%d and aid=%d and uid=%d", array(
	        'zimu_fc_user',
	        $sid,
	        $aid,
	        $_G['uid']
	));

	$helploglist = DB::fetch_all("SELECT * FROM %t where aid=%d and sid=%d and touid=%d order by addtime desc", array(
	        'zimu_fc_helplog',
	        $aid,
	        $myuser,
	        $_G['uid']
	));

    $tohtml = '';
	foreach ($helploglist as $key => $value) {

		if($zmdata['open_app']){
			if($value['open_app']==1){
				$open_app = $language_zimu['myuser_htm_49'];
			}else{
				$open_app = $language_zimu['myuser_htm_50'];	
			}
		}else{
			$open_app = $language_zimu['myuser_htm_49'];
		}

$tohtml .= '<a class="weui-cell" href="javascript:;" style="padding:10px 0;text-align: left;"><div class="weui-cell__hd weui-head_fix" style="margin-right:10px"><img class="order_avatar" src="'.avatar($value['uid'],'middle',true).'"></div><div class="weui-cell__bd"><div class="weui-desc">'.$value['username'].'</div><div class="c9">'.dgmdate($value['addtime'],'u').$language_zimu['myuser_htm_48'].'</div></div><div class="weui-cell__ft" style="color:#fd537b;font-size:18px;">'.$open_app.'</div></a>';

	}

	echo $tohtml;