<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_G['uid']<=0){exit();}

$aid = intval($_GET['aid']);
$sid = intval($_GET['sid']);

$haibao_url = ZIMUCMS_URL.'&model=exchange_scan&aid='.$aid.'&sid='.$sid.'&fromuid='.$_G['uid'];
$qrsize = 5;
$dir = 'source/plugin/zimu_fc/uploadzimucms/dhqrcode/';//存储路径
$file = $dir.$fid.'_'.$_G['uid'].'.jpg';

if(!file_exists($file) || !filesize($file) ) {
    dmkdir($dir);
    require_once DISCUZ_ROOT.'source/plugin/zimu_fc/class/qrcode.class.php';
    QRcode::png($haibao_url, $file, QR_ECLEVEL_L, $qrsize);
}

//$qrcode = base64_encode(file_get_contents($file));

dheader('Location: '.$_G['siteurl'].$file);
