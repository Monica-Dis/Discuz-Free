<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_G['uid']<=0){exit();}

$aid = intval($_GET['aid']);

$haibao_url = ZIMUCMS_URL.'&model2=addhelp&aid='.$aid.'&type=2&fromuid='.$_G['uid'];
$qrsize = 5;
$dir = 'source/plugin/zimu_fc/uploadzimucms/qrcode/';//存储路径
$file = $dir.$aid.'_'.$_G['uid'].'.jpg';
if(!file_exists($file) || !filesize($file) || filemtime($file) < $_G['timestamp'] - 86400 ) {
    dmkdir($dir);
    require_once DISCUZ_ROOT.'source/plugin/zimu_fc/class/qrcode.class.php';
    QRcode::png($haibao_url, $file, QR_ECLEVEL_L, $qrsize);
}

dheader('Location: '.$_G['siteurl'].$file);

//$qrcode = base64_encode(file_get_contents($file));

