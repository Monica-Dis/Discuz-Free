<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$model2 = addslashes($_GET['model2']);
if ($zmdata['open_app'] || $zmdata['join_subscribe'] || $zmdata['help_subscribe']) {
    $zmdata['guest_help'] = 0;
}
$touser = intval($_GET['touser']);
if ($touser == 1 || !$zmdata['guest_help']) {
    isuid();
}


if (IN_WECHAT && ($zmdata['join_subscribe'] || $zmdata['help_subscribe'])) {
    
    $referer = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
    if ($zmdata['weixin_oauth_domain']) {
        $referer = str_replace(array(
            $zmdata['weixin_oauth_domain'] . '/',
            $_G['siteurl'] . '/'
        ), array(
            $zmdata['weixin_oauth_domain'],
            $_G['siteurl']
        ), $referer);
    } else {
        $referer = str_replace($_G['siteurl'] . '/', $_G['siteurl'], $referer);
    }
    
    if ($_GET['code'] && getcookie('wechat_code') != $_GET['code']) {
        
        dsetcookie('wechat_code', $_GET['code'], 120, 1, true);
        
        $token = $wechat_client->getAccessTokenByCode($_GET['code']);

        if (!$token['openid']) {
            showmessage($language_zimu['list_inc_php_0'] . ($token['errmsg'] ? ' AccessToken: ' . $token['errmsg'] : ''), $referer);
        }
        $userinfo = $wechat_client->getUserInfoById($token['openid'], 'zh_CN');

        if(!$userinfo['openid']){
            $newtoken = $wechat_client->getAccessToken_new(1);
            $userinfo = $wechat_client->getUserInfoById($token['openid'], 'zh_CN');
        }

        $issubscribe = $userinfo['subscribe'];
        
        dsetcookie('issubscribe', $issubscribe, 3600, 1, true);
        dsetcookie('fc_openid', $userinfo['openid'], 3600, 1, true);
        
    } else {
        if ($zmdata['weixin_oauth_domain']) {
            $redirect = $zmdata['weixin_oauth_domain'] . '?appid=' . $zmdata['weixin_appid'] . '&scope=snsapi_userinfo&state=' . md5(FORMHASH) . '&redirect_uri=' . urlencode($referer);
            
        } else {
            $redirect = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $zmdata['weixin_appid'] . '&redirect_uri=' . urlencode($referer) . '&response_type=code&scope=snsapi_userinfo&state=' . md5(FORMHASH) . '#wechat_redirect';
        }
        dheader('Location:' . $redirect);
    }
    
}

$listdata = DB::fetch_all('select * from %t order by sort asc,id desc', array(
    'zimu_fc_list'
));

if ($_G['uid']) {
    
    foreach ($listdata as $key => $value) {
        
        $listdata[$key]['userdata'] = DB::fetch_first('select * from %t where aid=%d and uid=%d and (addtime > %d or helpstatus=1) order by id desc', array(
            'zimu_fc_user',
            $value['id'],
            $_G['uid'],
            $_G['timestamp'] - ($zmdata['overtime'] * 3600)
        ));
        
        DB::query("update %t set views=views+1 where id=%d", array(
            'zimu_fc_list',
            $value['id']
        ));


        if ($listdata[$key]['userdata']['helpnums'] >= $value['usednums'] && $listdata[$key]['userdata']['helpstatus'] != 1) {
            
            if ($value['handticket'] == 1) {
                
                DB::query("update %t set helpstatus=1,verifycode=%s where aid=%d and uid=%d order by id desc limit 1", array(
                    'zimu_fc_user',
                    'zimu_fc',
                    $value['id'],
                    $_G['uid']
                ));
                
            } else {
                
                $verifycode = random(8, true);
                while (1) {
                    $count = DB::result_first("SELECT count(*) FROM %t where verifycode=%d and aid=%d", array(
                        "zimu_fc_user",
                        $verifycode,
                        $value['id']
                    ));
                    if ($count <= 0) {
                        break;
                    }
                    $verifycode = random(8, true);
                }
                
                DB::query("update %t set helpstatus=1,verifycode=%d where aid=%d and uid=%d order by id desc limit 1", array(
                    'zimu_fc_user',
                    $verifycode,
                    $value['id'],
                    $_G['uid']
                ));
                
            }
            
            
            $listdata[$key]['userdata']['helpstatus'] = 1;
            $listdata[$key]['userdata']['verifycode'] = $verifycode;
            
            
        }
        
    }
    
}


if ($model2 == 'addhelp') {
    
    $fromuid = intval($_GET['fromuid']);
    $type    = intval($_GET['type']);
    $aid     = intval($_GET['aid']);
    if ((!$zmdata['guest_help'] || $_G['uid'] > 0) && $type) {
        
        $used_lucky = DB::result_first("SELECT count(*) FROM %t where aid=%d and uid=%d", array(
            'zimu_fc_helplog',
            $aid,
            $_G['uid']
        ));
        
        $vip_lucky = $zmdata['user_helpnums'];
        
        $isadd = DB::fetch_first('select * from %t where aid=%d and uid=%d and touid=%d order by id desc', array(
            'zimu_fc_helplog',
            $aid,
            $_G['uid'],
            $fromuid
        ));
        
        if ($_G['uid'] > 0 && $fromuid != $_G['uid'] && $fromuid > 0 && $used_lucky < $vip_lucky && !$isadd) {
            
            $isluckyadd = 1;
            
        }
        
    } else {
        
        $vip_lucky = $zmdata['user_helpnums'];
        
        if (getcookie('help_' . $aid . '_' . $fromuid) != 1 && $fromuid > 0 && getcookie('help_' . $aid . '_nums') < $vip_lucky && $fromuid != $_G['uid']) {
            
            $isluckyadd = 1;
            
        }
        
    }
}


if ($_G['uid'] && (IN_MAGAPP || IN_QFAPP || IN_XIAOYUNAPP) && $zmdata['open_app']) {
    
    $todo_helplog = DB::fetch_all('select * from %t where uid=%d and touid>0 and open_app=0 and addtime>%d order by id desc', array(
        'zimu_fc_helplog',
        $_G['uid'],
        $_G['timestamp'] - $zmdata['open_app_time'] * 3600
    ));
    
    foreach ($todo_helplog as $key => $value) {
        
        DB::query("update %t set open_app=1 where id=%d", array(
            'zimu_fc_helplog',
            $value['id']
        ));
        
        DB::query("update %t set helpnums=helpnums+1 where id=%d and uid=%d order by id desc limit 1", array(
            'zimu_fc_user',
            $value['sid'],
            $value['touid']
        ));
        
        
    }
    
}

if ($_G['uid'] && IN_WECHAT && $zmdata['help_subscribe'] && $issubscribe) {
    
    $todo_helplog = DB::fetch_all('select * from %t where uid=%d and touid>0 and open_app=0 and addtime>%d order by id desc', array(
        'zimu_fc_helplog',
        $_G['uid'],
        $_G['timestamp'] - $zmdata['open_app_time'] * 3600
    ));
    
    foreach ($todo_helplog as $key => $value) {
        
        DB::query("update %t set open_app=1 where id=%d", array(
            'zimu_fc_helplog',
            $value['id']
        ));
        
        DB::query("update %t set helpnums=helpnums+1 where id=%d and uid=%d order by id desc limit 1", array(
            'zimu_fc_user',
            $value['sid'],
            $value['touid']
        ));
        
    }
    
}

$share_title = $zmdata['share_title'];
$share_desc  = $zmdata['share_desc'];
$share_thumb = $zmdata['share_thumb'];
$share_url   = ZIMUCMS_URL;

include template('zimu_fc:list');