<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$aid = intval($_GET['aid']);
$sid = intval($_GET['sid']);
$fromuid = intval($_GET['fromuid']);

if(!$fromuid){
$fromuid = 0;
}

$fudaidata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimu_fc_list',
        $aid
    ));

$shopuid_array = explode('|',$fudaidata['shopuid']);

if (in_array($_G['uid'],$shopuid_array)){

$isshopuid = 1;

$alluserdata = DB::fetch_all('select * from %t where aid=%d and helpstatus=1 order by id desc', array(
        'zimu_fc_user',
        $aid
    ));
}

$userdata = DB::fetch_first('select * from %t where aid=%d and id=%d and uid=%d order by id desc', array(
        'zimu_fc_user',
        $aid,
        $sid,
        $fromuid
    ));

include template('zimu_fc:exchange_scan');
