<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

global $_G;

DB::delete('common_setting', array('skey' => 'zimu_rewrite'));
updatecache('setting');

$finish = TRUE;