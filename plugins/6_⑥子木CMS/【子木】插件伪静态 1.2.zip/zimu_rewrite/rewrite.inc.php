<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$lang = array_merge($lang, $scriptlang['zimu_rewrite']);

if(empty($_GET['ac'])) {

	if(!submitcheck('rewritesubmit')) {

		showtips('rewrite_tips');
		showformheader('plugins&operation=config&identifier=zimu_rewrite&pmod=rewrite');
		showtableheader();
		showtitle(cplang('rewritestatus'));
		showsubtitle(array('page', 'var', 'rule', 'available'));
		$rewrite = array(
			'zx_model' => array('{model}/', '{model}'),
			'zx_xiaoguotu' => array('xiaoguotu/o{order}h{huxing}f{fengge}y{yusuan}p{page}/', '{order},{huxing},{fengge},{yusuan},{page}'),
			'zx_xiaoqu' => array('xiaoqu/a{area}p{page}/', '{area},{page}'),
			'zx_viewxiaoqu' => array('viewxiaoqu/q{qid}/', '{qid}'),
			'zx_viewxiaoqu_case' => array('viewxiaoqu_case/q{qid}/', '{qid}'),
			'zx_viewxiaoqu_site' => array('viewxiaoqu_site/q{qid}/', '{qid}'),
			'zx_shop' => array('shop/a{area}o{order}p{page}/', '{area},{order},{page}'),
			'zx_building' => array('building/a{area}b{buildingtype}o{order}p{page}/', '{area},{buildingtype},{order},{page}'),
			'zx_viewbuilding' => array('viewbuilding/s{bid}/', '{bid}'),
			'zx_daily' => array('daily/h{huxing}f{fengge}y{yusuan}f{fangshi}p{page}/', '{huxing},{fengge},{yusuan},{fangshi},{page}'),
			'zx_newslist' => array('newslist/{newstypeid}/p{page}/', '{newstypeid},{page}'),
			'zx_viewnews' => array('viewnews/{newstypeurl}a{aid}/', '{newstypeurl},{aid}'),
			'zx_viewshop' => array('s{sid}/', '{sid}'),
			'zx_tuceshop' => array('s{sid}/case/', '{sid}'),
			'zx_tuce' => array('tuce/t{tid}/', '{tid}'),
			'zx_gongdishop' => array('s{sid}/gongdi/', '{sid}'),
			'zx_gongdi' => array('gongdi/g{gid}/', '{gid}'),
			'zx_teamshop' => array('s{sid}/team/', '{sid}'),
			'zx_designer' => array('designer/d{did}/', '{did}'),
			'zx_contactshop' => array('s{sid}/contact/', '{sid}'),
			'zx_activity' => array('activity/a{aid}/', '{aid}'),
			'zx_viewworkmen' => array('viewworkmen/g{gid}/', '{gid}'),
			'zp_model' => array('{model}/', '{model}'),
			'zp_viewjob' => array('viewjob/j{jid}/', '{jid}'),
			'zp_viewresume' => array('viewresume/r{rid}/', '{rid}'),
			'zp_viewcom' => array('viewcom/c{cid}/', '{cid}'),
			'zp_viewnews' => array('viewnews/n{nid}/', '{nid}'),
		);
		$zimu_rewrite = dunserialize($_G['setting']['zimu_rewrite']);
		foreach($rewrite as $key => $value) {
			$rule = $zimu_rewrite[$key]['rule'] ? $zimu_rewrite[$key]['rule'] : $value[0];
			$available = $zimu_rewrite[$key]['available'] ? ' checked="checked"' : '';
			showtablerow('', array('class="td24"', 'class="td31"', 'class="longtxt"', 'class="td25"'), array(
				cplang($key),
				$value[1],
				'<input type="text" name="zimu_rewrite['.$key.'][rule]" class="txt" value="'.$rule.'" />',
				'<input type="checkbox" name="zimu_rewrite['.$key.'][available]" class="checkbox" value="1"'.$available.' />',
			));
		}
		showsubmit('rewritesubmit', 'submit');
		showtablefooter();
		showformfooter();

	} else {

		$zimu_rewrite = serialize($_GET['zimu_rewrite']);
		DB::query("REPLACE INTO ".DB::table('common_setting')." (skey, svalue) VALUES ('zimu_rewrite', '$zimu_rewrite')");
		updatecache('setting');

		cpmsg('rewrite_update_succeed', 'action=plugins&operation=config&identifier=zimu_rewrite&pmod=rewrite', 'succeed');
	}
}

?>