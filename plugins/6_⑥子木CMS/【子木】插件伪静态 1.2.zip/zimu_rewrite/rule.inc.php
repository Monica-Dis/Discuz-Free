<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$lang = array_merge($lang, $scriptlang['zimu_rewrite']);

$rule = array();
$zimu_rewrite = dunserialize($_G['setting']['zimu_rewrite']);
$rewritedata = array(
	'rulesearch' => array(
		'zx_xiaoguotu' => $zimu_rewrite['zx_xiaoguotu']['rule'],
		'zx_xiaoqu' => $zimu_rewrite['zx_xiaoqu']['rule'],
		'zx_viewxiaoqu' => $zimu_rewrite['zx_viewxiaoqu']['rule'],
		'zx_viewxiaoqu_case' => $zimu_rewrite['zx_viewxiaoqu_case']['rule'],
		'zx_viewxiaoqu_site' => $zimu_rewrite['zx_viewxiaoqu_site']['rule'],
		'zx_shop' => $zimu_rewrite['zx_shop']['rule'],
		'zx_building' => $zimu_rewrite['zx_building']['rule'],
		'zx_viewbuilding' => $zimu_rewrite['zx_viewbuilding']['rule'],
		'zx_daily' => $zimu_rewrite['zx_daily']['rule'],
		'zx_newslist' => $zimu_rewrite['zx_newslist']['rule'],
		'zx_viewnews' => $zimu_rewrite['zx_viewnews']['rule'],
		'zx_viewshop' => $zimu_rewrite['zx_viewshop']['rule'],
		'zx_tuceshop' => $zimu_rewrite['zx_tuceshop']['rule'],
		'zx_tuce' => $zimu_rewrite['zx_tuce']['rule'],
		'zx_gongdishop' => $zimu_rewrite['zx_gongdishop']['rule'],
		'zx_gongdi' => $zimu_rewrite['zx_gongdi']['rule'],
		'zx_teamshop' => $zimu_rewrite['zx_teamshop']['rule'],
		'zx_designer' => $zimu_rewrite['zx_designer']['rule'],
		'zx_contactshop' => $zimu_rewrite['zx_contactshop']['rule'],
		'zx_activity' => $zimu_rewrite['zx_activity']['rule'],
		'zx_viewworkmen' => $zimu_rewrite['zx_viewworkmen']['rule'],
		'zx_model' => $zimu_rewrite['zx_model']['rule'],
		'zp_model' => $zimu_rewrite['zp_model']['rule'],
		'zp_viewjob' => $zimu_rewrite['zp_viewjob']['rule'],
		'zp_viewresume' => $zimu_rewrite['zp_viewresume']['rule'],
		'zp_viewcom' => $zimu_rewrite['zp_viewcom']['rule'],
		'zp_viewnews' => $zimu_rewrite['zp_viewnews']['rule'],
	),
	'rulereplace' => array(
		'zx_xiaoguotu' => 'plugin.php?id=zimucms_zhuangxiu&model=xiaoguotu&order={order}&huxing={huxing}&fengge={fengge}&yusuan={yusuan}&page={page}',
		'zx_xiaoqu' => 'plugin.php?id=zimucms_zhuangxiu&model=xiaoqu&area={area}&page={page}',
		'zx_viewxiaoqu' => 'plugin.php?id=zimucms_zhuangxiu&model=viewxiaoqu&qid={qid}',
		'zx_viewxiaoqu_case' => 'plugin.php?id=zimucms_zhuangxiu&model=viewxiaoqu_case&qid={qid}',
		'zx_viewxiaoqu_site' => 'plugin.php?id=zimucms_zhuangxiu&model=viewxiaoqu_site&qid={qid}',
		'zx_shop' => 'plugin.php?id=zimucms_zhuangxiu&model=shop&area={area}&order={order}&page={page}',
		'zx_building' => 'plugin.php?id=zimucms_zhuangxiu&model=building&area={area}&buildingtype={buildingtype}&order={order}&page={page}',
		'zx_viewbuilding' => 'plugin.php?id=zimucms_zhuangxiu&model=viewbuilding&bid={bid}',
		'zx_daily' => 'plugin.php?id=zimucms_zhuangxiu&model=daily&huxing={huxing}&fengge={fengge}&yusuan={yusuan}&fangshi={fangshi}&page={page}',
		'zx_newslist' => 'plugin.php?id=zimucms_zhuangxiu&model=news&newstypeid={newstypeid}&page={page}',
		'zx_viewnews' => 'plugin.php?id=zimucms_zhuangxiu&model=viewnews&newstypeurl={newstypeurl}&aid={aid}',
		'zx_viewshop' => 'plugin.php?id=zimucms_zhuangxiu&model=viewshop&sid={sid}',
		'zx_tuceshop' => 'plugin.php?id=zimucms_zhuangxiu&model=tuceshop&sid={sid}',
		'zx_tuce' => 'plugin.php?id=zimucms_zhuangxiu&model=tuce&tid={tid}',
		'zx_gongdishop' => 'plugin.php?id=zimucms_zhuangxiu&model=gongdishop&sid={sid}',
		'zx_gongdi' => 'plugin.php?id=zimucms_zhuangxiu&model=gongdi&gid={gid}',
		'zx_teamshop' => 'plugin.php?id=zimucms_zhuangxiu&model=teamshop&sid={sid}',
		'zx_designer' => 'plugin.php?id=zimucms_zhuangxiu&model=designer&did={did}',
		'zx_contactshop' => 'plugin.php?id=zimucms_zhuangxiu&model=contactshop&sid={sid}',
		'zx_activity' => 'plugin.php?id=zimucms_zhuangxiu&model=activity&aid={aid}',
		'zx_viewworkmen' => 'plugin.php?id=zimucms_zhuangxiu&model=viewworkmen&gid={gid}',
		'zx_model' => 'plugin.php?id=zimucms_zhuangxiu&model={model}',
		'zp_model' => 'plugin.php?id=zimu_zhaopin&model={model}',
		'zp_viewjob' => 'plugin.php?id=zimu_zhaopin&model=viewjob&jid={jid}',
		'zp_viewresume' => 'plugin.php?id=zimu_zhaopin&model=viewresume&rid={rid}',
		'zp_viewcom' => 'plugin.php?id=zimu_zhaopin&model=viewcom&cid={cid}',
		'zp_viewnews' => 'plugin.php?id=zimu_zhaopin&model=viewnews&nid={nid}',
	),
	'rulevars' => array(
		'zx_xiaoguotu' => array('{order}' => '([0-9]+)','{huxing}' => '([0-9]+)','{fengge}' => '([0-9]+)','{yusuan}' => '([0-9]+)','{page}' => '([0-9]+)'),
		'zx_xiaoqu' => array('{area}' => '([0-9]+)','{page}' => '([0-9]+)'),
		'zx_viewxiaoqu' => array('{qid}' => '([0-9]+)'),
		'zx_viewxiaoqu_case' => array('{qid}' => '([0-9]+)'),
		'zx_viewxiaoqu_site' => array('{qid}' => '([0-9]+)'),
		'zx_shop' => array('{area}' => '([0-9]+)','{order}' => '([0-9]+)','{page}' => '([0-9]+)'),
		'zx_building' => array('{area}' => '([0-9]+)','{buildingtype}' => '([0-9]+)','{order}' => '([0-9]+)','{page}' => '([0-9]+)'),
		'zx_viewbuilding' => array('{bid}' => '([0-9]+)'),
		'zx_daily' => array('{huxing}' => '([0-9]+)','{fengge}' => '([0-9]+)','{yusuan}' => '([0-9]+)','{fangshi}' => '([0-9]+)','{page}' => '([0-9]+)'),
		'zx_newslist' => array('{newstypeid}' => '([0-9]+)','{page}' => '([0-9]+)'),
		'zx_viewnews' => array('{newstypeurl}' => '(\w+)','{aid}' => '([0-9]+)'),
		'zx_viewshop' => array('{sid}' => '([0-9]+)'),
		'zx_tuceshop' => array('{sid}' => '([0-9]+)','{page}' => '([0-9]+)'),
		'zx_tuce' => array('{tid}' => '([0-9]+)'),
		'zx_gongdishop' => array('{sid}' => '([0-9]+)','{page}' => '([0-9]+)'),
		'zx_gongdi' => array('{gid}' => '([0-9]+)'),
		'zx_teamshop' => array('{sid}' => '([0-9]+)'),
		'zx_designer' => array('{did}' => '([0-9]+)'),
		'zx_contactshop' => array('{sid}' => '([0-9]+)'),
		'zx_activity' => array('{aid}' => '([0-9]+)'),
		'zx_viewworkmen' => array('{gid}' => '([0-9]+)'),
		'zx_model' => array('{model}' => '(bid_design|bid_decoration|bid_check|bid_superv|xiaoguotu|xiaoqu|shop|activitylist|building|workmen|daily|newslist)'),
		'zp_model' => array('{model}' => '(jobs|resume|qiye|news)'),
		'zp_viewjob' => array('{jid}' => '([0-9]+)'),
		'zp_viewresume' => array('{rid}' => '([0-9]+)'),
		'zp_viewcom' => array('{cid}' => '([0-9]+)'),
		'zp_viewnews' => array('{nid}' => '([0-9]+)'),
	)
);
$rule['{apache1}'] = $rule['{apache2}'] = $rule['{iis}'] = $rule['{iis7}'] = $rule['{zeus}'] = $rule['{nginx}'] = '';

foreach($rewritedata['rulesearch'] as $k => $v) {
	if(!$zimu_rewrite[$k]['available']) {
		continue;
	}
	$v = !$_G['setting']['rewriterule'][$k] ? $v : $_G['setting']['rewriterule'][$k];
	$pvmaxv = count($rewritedata['rulevars'][$k]) + 2;
	$vkeys = array_keys($rewritedata['rulevars'][$k]);
	$rewritedata['rulereplace'][$k] = pvsort($vkeys, $v, $rewritedata['rulereplace'][$k]);
	$v = str_replace($vkeys, $rewritedata['rulevars'][$k], addcslashes($v, '?*+^$.[]()|'));
	$rule['{apache1}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^(.*)/'.$v.'$ $1/'.pvadd($rewritedata['rulereplace'][$k])."&%1\n";
	if($k != 'forum_archiver') {
		$rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^'.$v.'$ '.$rewritedata['rulereplace'][$k]."&%1\n";
	} else {
		$rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^archiver/'.$v.'$ archiver/'.$rewritedata['rulereplace'][$k]."&%1\n";
	}
	$rule['{iis}'] .= 'RewriteRule ^(.*)/'.$v.'(\?(.*))*$ $1/'.addcslashes(pvadd($rewritedata['rulereplace'][$k]).'&$'.($pvmaxv + 1), '.?')."\n";
	$rule['{iis7}'] .= '&lt;rule name="'.$k.'"&gt;'."\n\t".'&lt;match url="^(.*/)*'.str_replace('\.', '.', $v).'\?*(.*)$" /&gt;'."\n\t".'&lt;action type="Rewrite" url="{R:1}/'.str_replace(array('&', 'page\%3D'), array('&amp;amp;', 'page%3D'), addcslashes(pvadd($rewritedata['rulereplace'][$k], 1).'&{R:'.$pvmaxv.'}', '?')).'" /&gt;'."\n".'&lt;/rule&gt;'."\n";
	$rule['{zeus}'] .= 'match URL into $ with ^(.*)/'.$v.'\?*(.*)$'."\n".'if matched then'."\n\t".'set URL = $1/'.pvadd($rewritedata['rulereplace'][$k]).'&$'.$pvmaxv."\nendif\n";
	$rule['{nginx}'] .= 'rewrite ^([^\.]*)/'.$v.'$ $1/'.stripslashes(pvadd($rewritedata['rulereplace'][$k]))." last;\n";
}
echo str_replace(array_keys($rule), $rule, cplang('rewrite_message'));

function pvsort($key, $v, $s) {
	$r = '/';
	$p = '';
	foreach($key as $k) {
		$r .= $p.preg_quote($k);
		$p = '|';
	}
	$r .= '/';
	preg_match_all($r, $v, $a);
	$a = $a[0];
	$a = array_flip($a);
	foreach($a as $key => $value) {
		$s = str_replace($key, '$'.($value + 1), $s);
	}
	return $s;
}

function pvadd($s, $t = 0) {
	$s = str_replace(array('$5', '$4', '$3', '$2', '$1'), array('~6', '~5', '~4', '~3', '~2'), $s);
	if(!$t) {
		return str_replace(array('~6', '~5', '~4', '~3', '~2'), array('$6', '$5', '$4', '$3', '$2'), $s);
	} else {
		return str_replace(array('~6', '~5', '~4', '~3', '~2'), array('{R:6}', '{R:5}', '{R:4}', '{R:3}', '{R:2}'), $s);
	}

}

?>