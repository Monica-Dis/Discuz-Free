<?php

/**
 *      [DisM!] (C)2019-2022 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: rewrite.class.php 29558 2013-12-06 17:57:48Z mpage $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

		$zimu_rewrite = dunserialize($_G['setting']['zimu_rewrite']);

		$_G['domain']['pregxprw']['zimucms_zhuangxiu'] = $_G['setting']['domain']['plugin']['zimucms_zhuangxiu'] ? preg_quote('http://'.$_G['setting']['domain']['plugin']['zimucms_zhuangxiu'].'/', '/') : preg_quote($_G['siteurl'], '/');

		$_G['domain']['pregxprw']['zimu_zhaopin'] = $_G['setting']['domain']['plugin']['zimu_zhaopin'] ? preg_quote('http://'.$_G['setting']['domain']['plugin']['zimu_zhaopin'].'/', '/') : preg_quote($_G['siteurl'], '/');

		$plugindomain = array();
		if(!empty($_G['setting']['domain']['zimu_domain']['plugin'])) {
			foreach($_G['setting']['domain']['zimu_domain']['plugin'] as $key => $value) {
				if($value['idtype'] == 'plugin') {
					$plugin_id = substr($value['id'], 0, strpos(":", $value['id']));
					$plugindomain[$plugin_id] = $key;
				}
			}
		} else {
			foreach($_G['setting']['domain']['list'] as $key => $value) {
				if($value['idtype'] == 'plugin') {
					$plugindomain[$value['id']] = $key;

			$_G['setting']['output']['preg']['search']['zx_'.$value['id']] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=".$value['id']."\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_'.$value['id']] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_plugin\', 0,\'/\')';


			$_G['setting']['output']['preg']['search']['zp_'.$value['id']] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimu_zhaopin'].")plugin.php\?id\=".$value['id']."\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zp_'.$value['id']] = 'plugin_zimu_rewrite::rewriteoutput(\'zp_plugin\', 0,\'/\')';

				}
			}

		}

		if($zimu_rewrite['zx_model']['available']) {
			$_G['setting']['output']['preg']['search']['zx_model'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=(\w+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_model'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_model\', 0,\'/\', $matches[3],$matches[4])';

			$_G['setting']['output']['preg']['search']['zx_activitylist'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=activitylist&(amp;)?typeid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_activitylist'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_activitylist\', 0,\'/\', $matches[4],$matches[5])';

			$_G['setting']['output']['preg']['search']['zx_activitylist2'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=activitylist&(amp;)?typeid\=(\d+)&(amp;)?page\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_activitylist2'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_activitylist2\', 0,\'/\', $matches[4],$matches[6],$matches[7])';

			$_G['setting']['output']['preg']['search']['zx_workmen'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=workmen&(amp;)?type\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_workmen'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_workmen\', 0,\'/\', $matches[4],$matches[5])';

			$_G['setting']['output']['preg']['search']['zx_workmen2'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=workmen&(amp;)?area\=(\d+)&(amp;)?type\=(\d+)&(amp;)?wid\=(\d+)&(amp;)?page\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_workmen2'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_workmen2\', 0,\'/\', $matches[4],$matches[6],$matches[8],$matches[10],$matches[11])';

		}

		if($zimu_rewrite['zx_xiaoguotu']['available']) {
			$_G['setting']['output']['preg']['search']['zx_xiaoguotu'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=xiaoguotu&(amp;)?order\=(\d+)&(amp;)?huxing\=(\d+)&(amp;)?fengge\=(\d+)&(amp;)?yusuan\=(\d+)&(amp;)?page\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_xiaoguotu'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_xiaoguotu\', 0,\'/\', $matches[4],$matches[6],$matches[8],$matches[10],$matches[12])';
		}


		if($zimu_rewrite['zx_xiaoqu']['available']) {
			$_G['setting']['output']['preg']['search']['zx_xiaoqu'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=xiaoqu&(amp;)?area\=(\d+)&(amp;)?page\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_xiaoqu'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_xiaoqu\', 0,\'/\', $matches[4],$matches[6],$matches[8])';
		}

		if($zimu_rewrite['zx_viewxiaoqu']['available']) {
			$_G['setting']['output']['preg']['search']['zx_viewxiaoqu'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=viewxiaoqu&(amp;)?qid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_viewxiaoqu'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_viewxiaoqu\', 0,\'/\', $matches[4],$matches[5])';
			$_G['setting']['output']['preg']['search']['zx_viewxiaoqu2'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=viewxiaoqu&(amp;)?qid\=(\d+)#top\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_viewxiaoqu2'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_viewxiaoqu2\', 0,\'/\', $matches[4],$matches[5])';
		}

		if($zimu_rewrite['zx_viewxiaoqu_case']['available']) {
			$_G['setting']['output']['preg']['search']['zx_viewxiaoqu_case'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=viewxiaoqu_case&(amp;)?qid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_viewxiaoqu_case'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_viewxiaoqu_case\', 0,\'/\', $matches[4],$matches[5])';

			$_G['setting']['output']['preg']['search']['zx_viewxiaoqu_case2'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=viewxiaoqu_case&(amp;)?qid\=(\d+)#top\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_viewxiaoqu_case2'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_viewxiaoqu_case2\', 0,\'/\', $matches[4],$matches[5])';

			$_G['setting']['output']['preg']['search']['zx_viewxiaoqu_case3'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=viewxiaoqu_case&(amp;)?qid\=(\d+)&(amp;)?page\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_viewxiaoqu_case3'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_viewxiaoqu_case3\', 0,\'/\', $matches[4],$matches[6],$matches[7])';

		}

		if($zimu_rewrite['zx_viewxiaoqu_site']['available']) {
			$_G['setting']['output']['preg']['search']['zx_viewxiaoqu_site'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=viewxiaoqu_site&(amp;)?qid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_viewxiaoqu_site'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_viewxiaoqu_site\', 0,\'/\', $matches[4],$matches[5])';

			$_G['setting']['output']['preg']['search']['zx_viewxiaoqu_site2'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=viewxiaoqu_site&(amp;)?qid\=(\d+)#top\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_viewxiaoqu_site2'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_viewxiaoqu_site2\', 0,\'/\', $matches[4],$matches[5])';

			$_G['setting']['output']['preg']['search']['zx_viewxiaoqu_site3'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=viewxiaoqu_site&(amp;)?qid\=(\d+)&(amp;)?page\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_viewxiaoqu_site3'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_viewxiaoqu_site3\', 0,\'/\', $matches[4],$matches[6],$matches[7])';

		}

		if($zimu_rewrite['zx_shop']['available']) {
			$_G['setting']['output']['preg']['search']['zx_shop'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=shop&(amp;)?area\=(\d+)&(amp;)?order\=(\d+)&(amp;)?page\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_shop'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_shop\', 0,\'/\', $matches[4],$matches[6],$matches[8],$matches[10])';
		}

		if($zimu_rewrite['zx_building']['available']) {
			$_G['setting']['output']['preg']['search']['zx_building'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=building&(amp;)?area\=(\d+)&(amp;)?buildingtype\=(\d+)&(amp;)?order\=(\d+)&(amp;)?page\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_building'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_building\', 0,\'/\', $matches[4],$matches[6],$matches[8],$matches[10],$matches[12])';
		}

		if($zimu_rewrite['zx_viewbuilding']['available']) {
			$_G['setting']['output']['preg']['search']['zx_viewbuilding'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=viewbuilding&(amp;)?bid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_viewbuilding'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_viewbuilding\', 0,\'/\', $matches[4],$matches[5])';

			$_G['setting']['output']['preg']['search']['zx_viewbuilding2'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=viewbuilding&(amp;)?bid\=(\d+)&show\=anli&(amp;)?page\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_viewbuilding2'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_viewbuilding2\', 0,\'/\', $matches[4],$matches[6],$matches[7])';

		}

		if($zimu_rewrite['zx_daily']['available']) {
			$_G['setting']['output']['preg']['search']['zx_daily'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=daily&(amp;)?huxing\=(\d+)&(amp;)?fengge\=(\d+)&(amp;)?yusuan\=(\d+)&(amp;)?fangshi\=(\d+)&(amp;)?page\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_daily'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_daily\', 0,\'/\', $matches[4],$matches[6],$matches[8],$matches[10],$matches[12],$matches[13])';
		}

		if($zimu_rewrite['zx_newslist']['available']) {
			$_G['setting']['output']['preg']['search']['zx_newslist'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=news&(amp;)?newstypeid\=(\d+)&(amp;)?page\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_newslist'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_newslist\', 0,\'/\', $matches[4],$matches[6])';
		}

		if($zimu_rewrite['zx_viewnews']['available']) {
			$_G['setting']['output']['preg']['search']['zx_viewnews'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=viewnews&(amp;)?newstypeurl\=(\w+)&(amp;)?aid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_viewnews'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_viewnews\', 0,\'/\', $matches[4],$matches[6],$matches[7])';
		}

		if($zimu_rewrite['zx_viewshop']['available']) {
			$_G['setting']['output']['preg']['search']['zx_viewshop'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=viewshop&(amp;)?sid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_viewshop'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_viewshop\', 0,\'/\', $matches[4],$matches[5])';
		}

		if($zimu_rewrite['zx_tuceshop']['available']) {
			$_G['setting']['output']['preg']['search']['zx_tuceshop'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=tuceshop&(amp;)?sid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_tuceshop'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_tuceshop\', 0,\'/\', $matches[4],$matches[5])';

			$_G['setting']['output']['preg']['search']['zx_tuceshop2'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=tuceshop&(amp;)?sid\=(\d+)&(amp;)?page\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_tuceshop2'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_tuceshop2\', 0,\'/\', $matches[4],$matches[6],$matches[7])';
		}

		if($zimu_rewrite['zx_tuce']['available']) {
			$_G['setting']['output']['preg']['search']['zx_tuce'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=tuce&(amp;)?tid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_tuce'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_tuce\', 0,\'/\', $matches[4],$matches[5])';
		}

		if($zimu_rewrite['zx_gongdishop']['available']) {
			$_G['setting']['output']['preg']['search']['zx_gongdishop'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=gongdishop&(amp;)?sid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_gongdishop'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_gongdishop\', 0,\'/\', $matches[4],$matches[5])';

			$_G['setting']['output']['preg']['search']['zx_gongdishop2'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=gongdishop&(amp;)?sid\=(\d+)&(amp;)?page\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_gongdishop2'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_gongdishop2\', 0,\'/\', $matches[4],$matches[6],$matches[7])';
		}

		if($zimu_rewrite['zx_gongdi']['available']) {
			$_G['setting']['output']['preg']['search']['zx_gongdi'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=gongdi&(amp;)?gid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_gongdi'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_gongdi\', 0,\'/\', $matches[4],$matches[5])';
		}

		if($zimu_rewrite['zx_teamshop']['available']) {
			$_G['setting']['output']['preg']['search']['zx_teamshop'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=teamshop&(amp;)?sid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_teamshop'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_teamshop\', 0,\'/\', $matches[4],$matches[5])';
		}

		if($zimu_rewrite['zx_designer']['available']) {
			$_G['setting']['output']['preg']['search']['zx_designer'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=designer&(amp;)?did\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_designer'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_designer\', 0,\'/\', $matches[4],$matches[5])';
		}

		if($zimu_rewrite['zx_contactshop']['available']) {
			$_G['setting']['output']['preg']['search']['zx_contactshop'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=contactshop&(amp;)?sid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_contactshop'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_contactshop\', 0,\'/\', $matches[4],$matches[5])';
		}

		if($zimu_rewrite['zx_activity']['available']) {
			$_G['setting']['output']['preg']['search']['zx_activity'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=activity&(amp;)?aid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_activity'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_activity\', 0,\'/\', $matches[4],$matches[5])';
		}

		if($zimu_rewrite['zx_viewworkmen']['available']) {
			$_G['setting']['output']['preg']['search']['zx_viewworkmen'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?model\=viewworkmen&(amp;)?gid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zx_viewworkmen'] = 'plugin_zimu_rewrite::rewriteoutput(\'zx_viewworkmen\', 0,\'/\', $matches[4],$matches[5])';
		}

		if($zimu_rewrite['zp_model']['available']) {

			$_G['setting']['output']['preg']['search']['zp_model'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimu_zhaopin'].")plugin.php\?id\=zimu_zhaopin&(amp;)?model\=(\w+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zp_model'] = 'plugin_zimu_rewrite::rewriteoutput(\'zp_model\', 0,\'/\', $matches[3],$matches[4])';

			$_G['setting']['output']['preg']['search']['zp_jobs'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimu_zhaopin'].")plugin.php\?id\=zimu_zhaopin&(amp;)?model\=zp_jobs(\w+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zp_jobs'] = 'plugin_zimu_rewrite::rewriteoutput(\'zp_jobs\', 0,\'/\', $matches[3],$matches[4])';
			
		}

		if($zimu_rewrite['zp_viewjob']['available']) {

			$_G['setting']['output']['preg']['search']['zp_viewjob'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimu_zhaopin'].")plugin.php\?id\=zimu_zhaopin&(amp;)?model\=viewjob&(amp;)?jid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zp_viewjob'] = 'plugin_zimu_rewrite::rewriteoutput(\'zp_viewjob\', 0,\'/\', $matches[4],$matches[5])';

		}

		if($zimu_rewrite['zp_viewresume']['available']) {

			$_G['setting']['output']['preg']['search']['zp_viewresume'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimu_zhaopin'].")plugin.php\?id\=zimu_zhaopin&(amp;)?model\=viewresume&(amp;)?rid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zp_viewresume'] = 'plugin_zimu_rewrite::rewriteoutput(\'zp_viewresume\', 0,\'/\', $matches[4],$matches[5])';

		}

		if($zimu_rewrite['zp_viewcom']['available']) {

			$_G['setting']['output']['preg']['search']['zp_viewcom'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimu_zhaopin'].")plugin.php\?id\=zimu_zhaopin&(amp;)?model\=viewcom&(amp;)?cid\=(\d+)\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zp_viewcom'] = 'plugin_zimu_rewrite::rewriteoutput(\'zp_viewcom\', 0,\'/\', $matches[4],$matches[5])';

			$_G['setting']['output']['preg']['search']['zp_viewcom2'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimu_zhaopin'].")plugin.php\?id\=zimu_zhaopin&(amp;)?model\=viewcom&(amp;)?cid\=(\d+)#jobslist\"([^\>]*)\>/";
			$_G['setting']['output']['preg']['replace']['zp_viewcom2'] = 'plugin_zimu_rewrite::rewriteoutput(\'zp_viewcom2\', 0,\'/\', $matches[4],$matches[5])';

		}

		foreach($_G['setting']['domain']['plugin'] as $key => $value) {
			if($value) {
				$_G['setting']['output']['preg']['search'][$key] = '/\/plugin.php\?id='.$key.'\"/';
				$_G['setting']['output']['preg']['replace'][$key] = '"';
			}
		}
		
class plugin_zimu_rewrite {
	
	function plugin_zimu_rewrite() {
		global $_G;

	}

	function global_footer(){
		global $_G;

		return '<!-- rewrite_replace -->';
	}

	function rewriteoutput($type, $returntype, $host) {
		global $_G;
		$fextra = '';
		$zimu_rewrite = dunserialize($_G['setting']['zimu_rewrite']);
		if($type == 'zx_model') {
			list(,,, $model, $extra) = func_get_args();
			$r = array(
				'{model}' => $model,
			);
		}elseif($type == 'zx_activitylist') {
			list(,,, $typeid, $extra) = func_get_args();

		$zimu_rewrite['zx_activitylist']['rule'] = $zimu_rewrite['zx_model']['rule'].'?typeid='.$typeid;

         $zimu_rewrite['zx_activitylist']['rule'] = str_replace('{model}', 'activitylist', $zimu_rewrite['zx_activitylist']['rule']);

		}elseif($type == 'zx_activitylist2') {
			list(,,, $typeid,$page, $extra) = func_get_args();

		$zimu_rewrite['zx_activitylist2']['rule'] = $zimu_rewrite['zx_model']['rule'].'?typeid='.$typeid.'&page='.$page;

         $zimu_rewrite['zx_activitylist2']['rule'] = str_replace('{model}', 'activitylist', $zimu_rewrite['zx_activitylist2']['rule']);

		}elseif($type == 'zx_workmen') {
			list(,,, $typeid, $extra) = func_get_args();

		$zimu_rewrite['zx_workmen']['rule'] = $zimu_rewrite['zx_model']['rule'].'?type='.$typeid;

         $zimu_rewrite['zx_workmen']['rule'] = str_replace('{model}', 'workmen', $zimu_rewrite['zx_workmen']['rule']);

		}elseif($type == 'zx_workmen2') {

			list(,,, $area,$type2,$wid,$page, $extra) = func_get_args();

		$zimu_rewrite['zx_workmen2']['rule'] = $zimu_rewrite['zx_model']['rule'].'?area='.$area.'&type='.$type2.'&wid='.$wid.'&page='.$page;

         $zimu_rewrite['zx_workmen2']['rule'] = str_replace('{model}', 'workmen', $zimu_rewrite['zx_workmen2']['rule']);

		}elseif($type == 'zx_xiaoguotu') {
			list(,,, $order,$huxing,$fengge,$yusuan,$page, $extra) = func_get_args();
			$r = array(
				'{order}' => $order ? $order : 0,
				'{huxing}' => $huxing ? $huxing : 0,
				'{fengge}' => $fengge ? $fengge : 0,
				'{yusuan}' => $yusuan ? $yusuan : 0,
				'{page}' => $page ? $page : 1,
			);
		}elseif($type == 'zx_xiaoqu') {
			list(,,, $area,$page, $extra) = func_get_args();
			$r = array(
				'{area}' => $area,
				'{page}' => $page ? $page : 1,
			);
		}elseif($type == 'zx_viewxiaoqu') {
			list(,,, $qid, $extra) = func_get_args();
			$r = array(
				'{qid}' => $qid,
			);
		}elseif($type == 'zx_viewxiaoqu2') {
			list(,,, $qid, $extra) = func_get_args();
			$r = array(
				'{qid}' => $qid,
			);
		$zimu_rewrite['zx_viewxiaoqu2']['rule'] = $zimu_rewrite['zx_viewxiaoqu']['rule'].'#top';

		}elseif($type == 'zx_viewxiaoqu_case') {
			list(,,, $qid,$extra) = func_get_args();
			$r = array(
				'{qid}' => $qid,
			);
		}elseif($type == 'zx_viewxiaoqu_case2') {
			list(,,, $qid,$extra) = func_get_args();
			$r = array(
				'{qid}' => $qid,
			);

		$zimu_rewrite['zx_viewxiaoqu_case2']['rule'] = $zimu_rewrite['zx_viewxiaoqu_case']['rule'].'#top';

		}elseif($type == 'zx_viewxiaoqu_case3') {
			list(,,, $qid,$page,$extra) = func_get_args();
			$r = array(
				'{qid}' => $qid,
			);

		$zimu_rewrite['zx_viewxiaoqu_case3']['rule'] = $zimu_rewrite['zx_viewxiaoqu_case']['rule'].'?page='.$page;

		}elseif($type == 'zx_viewxiaoqu_site') {
			list(,,, $qid,$extra) = func_get_args();
			$r = array(
				'{qid}' => $qid,
			);
		}elseif($type == 'zx_viewxiaoqu_site2') {
			list(,,, $qid,$extra) = func_get_args();
			$r = array(
				'{qid}' => $qid,
			);

		$zimu_rewrite['zx_viewxiaoqu_site2']['rule'] = $zimu_rewrite['zx_viewxiaoqu_site']['rule'].'#top';

		}elseif($type == 'zx_viewxiaoqu_site3') {
			list(,,, $qid,$page,$extra) = func_get_args();
			$r = array(
				'{qid}' => $qid,
			);

		$zimu_rewrite['zx_viewxiaoqu_site3']['rule'] = $zimu_rewrite['zx_viewxiaoqu_site']['rule'].'?page='.$page;

		}elseif($type == 'zx_shop') {
			list(,,, $area,$order,$page, $extra) = func_get_args();
			$r = array(
				'{area}' => $area,
				'{order}' => $order ? $order : 1,
				'{page}' => $page ? $page : 1,
			);
		}elseif($type == 'zx_building') {
			list(,,, $area,$buildingtype,$order,$page, $extra) = func_get_args();
			$r = array(
				'{area}' => $area,
				'{buildingtype}' => $buildingtype,
				'{order}' => $order ? $order : 1,
				'{page}' => $page ? $page : 1,
			);
		}elseif($type == 'zx_viewbuilding') {
			list(,,, $bid, $extra) = func_get_args();
			$r = array(
				'{bid}' => $bid,
			);
		}elseif($type == 'zx_viewbuilding2') {
			list(,,, $bid, $page, $extra) = func_get_args();
			$r = array(
				'{bid}' => $bid,
			);

		$zimu_rewrite['zx_viewbuilding2']['rule'] = $zimu_rewrite['zx_viewbuilding']['rule'].'?show=anli&page='.$page;

		}elseif($type == 'zx_daily') {
			list(,,, $huxing,$fengge,$yusuan,$fangshi,$page, $extra) = func_get_args();
			$r = array(
				'{huxing}' => $huxing,
				'{fengge}' => $fengge,
				'{yusuan}' => $yusuan,
				'{fangshi}' => $fangshi,
				'{page}' => $page ? $page : 1,
			);
		}elseif($type == 'zx_newslist') {
			list(,,, $newstypeid,$page, $extra) = func_get_args();
			$r = array(
				'{newstypeid}' => $newstypeid,
				'{page}' => $page ? $page : 1,
			);
		}elseif($type == 'zx_viewnews') {
			list(,,, $newstypeurl,$aid, $extra) = func_get_args();
			$r = array(
				'{newstypeurl}' => $newstypeurl,
				'{aid}' => $aid,
			);
		}elseif($type == 'zx_viewshop') {
			list(,,, $sid, $extra) = func_get_args();
			$r = array(
				'{sid}' => $sid,
			);
		}elseif($type == 'zx_tuceshop') {
			list(,,, $sid, $extra,) = func_get_args();
			$r = array(
				'{sid}' => $sid,
			);
		}elseif($type == 'zx_tuceshop2') {
			list(,,, $sid, $page, $extra) = func_get_args();
			$r = array(
				'{sid}' => $sid,
			);

		$zimu_rewrite['zx_tuceshop2']['rule'] = $zimu_rewrite['zx_tuceshop']['rule'].'?page='.$page;

		}elseif($type == 'zx_tuce') {
			list(,,, $tid, $extra) = func_get_args();
			$r = array(
				'{tid}' => $tid,
			);
		}elseif($type == 'zx_gongdishop') {
			list(,,, $sid, $extra, $page) = func_get_args();
			$r = array(
				'{sid}' => $sid,
				'{page}' => intval($page) ? intval($page) : 1,
			);

		}elseif($type == 'zx_gongdishop2') {
			list(,,, $sid, $page, $extra) = func_get_args();
			$r = array(
				'{sid}' => $sid,
			);

		$zimu_rewrite['zx_gongdishop2']['rule'] = $zimu_rewrite['zx_gongdishop']['rule'].'?page='.$page;

		}elseif($type == 'zx_gongdi') {
			list(,,, $gid, $extra) = func_get_args();
			$r = array(
				'{gid}' => $gid,
			);
		}elseif($type == 'zx_teamshop') {
			list(,,, $sid, $extra) = func_get_args();
			$r = array(
				'{sid}' => $sid,
			);
		}elseif($type == 'zx_designer') {
			list(,,, $did, $extra) = func_get_args();
			$r = array(
				'{did}' => $did,
			);
		}elseif($type == 'zx_contactshop') {
			list(,,, $sid, $extra) = func_get_args();
			$r = array(
				'{sid}' => $sid,
			);
		}elseif($type == 'zx_activity') {
			list(,,, $aid, $extra) = func_get_args();
			$r = array(
				'{aid}' => $aid,
			);
		}elseif($type == 'zx_viewworkmen') {
			list(,,, $gid, $extra) = func_get_args();
			$r = array(
				'{gid}' => $gid,
			);
		}elseif($type == 'zp_model') {
			list(,,, $model, $extra) = func_get_args();
			$r = array(
				'{model}' => $model,
			);
		}elseif($type == 'zp_viewjob') {
			list(,,, $jid, $extra) = func_get_args();
			$r = array(
				'{jid}' => $jid,
			);
		}elseif($type == 'zp_viewresume') {
			list(,,, $rid, $extra) = func_get_args();
			$r = array(
				'{rid}' => $rid,
			);
		}elseif($type == 'zp_viewcom') {
			list(,,, $cid, $extra) = func_get_args();
			$r = array(
				'{cid}' => $cid,
			);
		}elseif($type == 'zp_viewcom2') {
			list(,,, $cid, $extra) = func_get_args();
			$r = array(
				'{cid}' => $cid,
			);

		$zimu_rewrite['zp_viewcom2']['rule'] = $zimu_rewrite['zp_viewcom']['rule'].'#jobslist';

		}

		$href = str_replace(array_keys($r), $r, $zimu_rewrite[$type]['rule']).$fextra;
		if(!$returntype) {
			return '<a href="'.$host.$href.'"'.(!empty($extra) ? stripslashes($extra) : '').'>';
		} else {
			return $host.$href;
		}
	}

}