<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

//插件目录常量
define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimucms_apprenew/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimucms_apprenew');
define('SITE_URL', $_G['siteurl']);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);


$SELF   = $_SERVER["PHP_SELF"];
$zmdata = $_G['cache']['plugin']['zimucms_apprenew'];

$formhash = $_G['formhash'];

if ($_G['charset'] == 'gbk') {
    $charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
    $charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
    $charset = 'big5';
}

$model = addslashes($_GET['model']);

if($model == 'getscore' && $_GET['md5hash'] == FORMHASH ){

isuid();

$leixing = intval($_GET['leixing']);

if($leixing == 1 ){
$new_version = $zmdata['new_version'];
}else{
$new_version = $zmdata['android_new_version'];
}

    $isyes = DB::result_first('select id from %t where uid=%d and version=%s', array(
        'zimucms_apprenew',
        $_G['uid'],
        $new_version
    ));

if($isyes){
        $out['code'] = 200;
        echo $result      = json_encode($out);
        exit();
}

        $jifen_type = explode(',', $zmdata['jifen_type']);
        
        $jifen_score = explode(',', $zmdata['jifen_score']);

$scoretext = '';
    foreach ($jifen_type as $key => $value) {
        
        updatemembercount($_G['uid'], array(
            'extcredits' . $value => $jifen_score[$key]
        ), true, '', 1,lang('plugin/zimucms_apprenew', 'system_text3'),lang('plugin/zimucms_apprenew', 'system_text3'),lang('plugin/zimucms_apprenew', 'system_text3'));

        notification_add($_G['uid'], 'system', lang('plugin/zimucms_apprenew', 'system_text4'), array('num' => $jifen_score[$key] ,'scoretype' => $_G['setting']['extcredits'][$jifen_type[$key]]['title'] ), 1);

        $scoretext = $scoretext.$jifen_score[$key].$_G['setting']['extcredits'][$jifen_type[$key]]['title'];

    }

            $oldversion = addslashes($_GET['oldversion']);

            $adddata['uid']     = $_G['uid'];
            $adddata['username']     = $_G['username'];
            $adddata['version']    = $new_version;
            if($leixing == 1 ){
                $adddata['scoretext']    = '<font color=red>iOS</font>'.lang('plugin/zimucms_apprenew', 'system_text3').$scoretext;
            }else{
                $adddata['scoretext']    = '<font color=red>Android</font>'.lang('plugin/zimucms_apprenew', 'system_text3').$scoretext;
            }
            $adddata['addtime'] = $_G['timestamp'];
            $result = DB::insert('zimucms_apprenew', $adddata);

if($result){
        $out['code'] = 200;
        echo $result      = json_encode($out);
        exit();
}else{
        $out['code'] = 201;
        $out['err']  = urlencode(lang('plugin/zimucms_apprenew', 'system_text5'));
        $result      = json_encode($out);
        echo $result = urldecode($result);
        exit();
}

}else{


if(IN_MAGAPP){

$userAgent = $_SERVER['HTTP_USER_AGENT'];
$info = strstr($userAgent, "MAGAPPX");
$info=explode("|",$info);
$oldversion = $info[1];

}

if($_G['uid']){
    $isyes = DB::result_first('select id from %t where uid=%d and version=%s', array(
        'zimucms_apprenew',
        $_G['uid'],
        $zmdata['new_version']
    ));
}
include template('zimucms_apprenew:newindex');

}










function isuid()
{
    global $_G;
    define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
    define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
    define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
        if (!$_G['uid']) {
            $refererurl = $_G['siteurl'] . 'plugin.php?id=zimucms_apprenew';
            if (IN_XIAOYUNAPP) {
                exit('<script language="javascript" src="source/plugin/zimucms_apprenew/static/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
        AppbymeJavascriptBridge.login(function(data){
            top.location.href="' . $refererurl . '";
        });
    });
    </script>');
            } else if (IN_MAGAPP) {
                exit('<script src="source/plugin/zimucms_apprenew/static/magjs-x.js"></script><script>
                    mag.toLogin(function(){
            window.location.href="' . $refererurl . '";
  });
    </script>');
            } else if (IN_QFAPP) {
                exit('<script src="//apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //登陆失败
                alert(data.error);//data.error: string
            }
        });
    }
    </script>');
            } else {
                dheader('Location:' . $_G[siteurl] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }
        }
}