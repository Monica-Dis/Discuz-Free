<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$model = addslashes($_GET['model']);
$formhash = $_G['formhash'];
if(!$model){
$model = 'userlist';
}
if ($model == 'userlist') {
    
    
    
    $userid      = intval($_GET['uid']);
    $username = strip_tags($_GET['username']);
    
    
    $username = dhtmlspecialchars($username);
    $username = stripsearchkey($username);
    $username = daddslashes($username);
    
    
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);

    if ($userid > 0) {
        $wherearr[] = DB::field('uid', $userid);
    }
    
    if ($username) {
        include_once libfile('function/search');
        $wherearr[] = ' 1 ' . searchkey($username, "username LIKE '%{text}%'");
    }
    
    
    $wheresql = empty($wherearr) ? '1' : implode(' AND ', $wherearr);
    
    $count = DB::result_first("SELECT count(*) FROM %t WHERE %i", array(
        "zimucms_apprenew",
        $wheresql
    ));
    
    $limit    = 10;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);

    $userlist = DB::fetch_all('select * from %t where %i order by id desc', array(
        'zimucms_apprenew',
        $wheresql
    ));

    if ($page_num > 1) {

        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin[pluginid] . '&identifier=' . $plugin[identifier] . '&pmod=' . $module[name] . '&model=' . $model, '10000', '20', TRUE, TRUE);

    }
    
    
    
    include template('zimucms_apprenew:scorelog');
    
    
}