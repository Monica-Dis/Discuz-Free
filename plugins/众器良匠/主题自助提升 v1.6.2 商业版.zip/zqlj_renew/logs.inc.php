<?php
/*
 * 主页：http://dism.taobao.com/?@72763.developer
 * https://dism.taobao.com
 * DisM!应用中心：dism.taobao.com
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$op=trim($_GET['op']);
$itemid=intval($_GET['itemid']);
if($op=='del'&&$_GET['formhash']==formhash()){
	DB::delete('zqlj_renew',array('id'=>$itemid));
	cpmsg(lang('plugin/zqlj_renew','log_op_ok'),'action=plugins&operation=config&identifier=zqlj_renew&pmod=logs', 'succeed');
}elseif(submitcheck('submit')){
	if(is_array($_POST['delete'])){
		foreach($_POST['delete'] as $k=>$id){
			if($id){
				DB::delete('zqlj_renew',array('id'=>$id));			
			}
		}
	}
	cpmsg(lang('plugin/zqlj_renew','log_del_ok'),'action=plugins&operation=config&identifier=zqlj_renew&pmod=logs', 'succeed');
}else{
	$pagenum=20;
	$page=max(1,intval($_GET['page']));
	$count=DB::result_first("select count(*) from ".DB::table("zqlj_renew")." ");
	$data=DB::fetch_all("select * from ".DB::table("zqlj_renew")." where 1 order by id desc limit ".($page-1)*$pagenum.",$pagenum");
	showformheader('plugins&operation=config&identifier=zqlj_renew&pmod=logs');
	showtableheader(lang('plugin/zqlj_renew','log_title'));
	showsubtitle(array('',lang('plugin/zqlj_renew','log_m_index'),lang('plugin/zqlj_renew','log_m_user'),lang('plugin/zqlj_renew','log_m_time'),lang('plugin/zqlj_renew','log_m_view'),lang('plugin/zqlj_renew','log_m_cost'),lang('plugin/zqlj_renew','log_m_del')));
	foreach($data as $item) {
		showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[".$item['id']."]\" value=\"".$item['id']."\">",
			$item['id'],
			'<a href="home.php?mod=space&uid='.$item['uid'].'" target="_blank">'.$item['username'].'</a>',
			dgmdate($item['dateline'],'Y-m-d H:i:s'),
			'<a href="forum.php?mod=viewthread&tid='.$item['tid'].'" target="_blank">'.lang('plugin/zqlj_renew','log_m_view').'</a>',
			$item['cost'].$_G['setting']['extcredits'][$item['creditid']]['title'],
			'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=zqlj_renew&pmod=logs&op=del&itemid='.$item['id'].'&formhash='.FORMHASH.'">'.lang('plugin/zqlj_renew','log_m_del').'</a>',
		));
				
	}
	$multipage=multi($count,$pagenum,$page,ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=zqlj_renew&pmod=logs");
	showsubmit('submit', 'submit', 'del', '', $multipage);
	showtablefooter();
	showformfooter();
}
//From: Dism·taobao·com
?>