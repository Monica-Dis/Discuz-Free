<?php
/*
 * 主页：http://dism.taobao.com/?@72763.developer
 * https://dism.taobao.com
 * DisM!应用中心：dism.taobao.com
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_zqlj_renew{
	function __construct(){
	    loadcache('plugin');
		global $_G;
		$this->vars=$_G['cache']['plugin']['zqlj_renew'];
		$this->forums=(array)unserialize($this->vars['forums']);
		$this->groups=(array)unserialize($this->vars['groups']);
		$this->isauthor=intval($this->vars['isauthor']);
		$this->title=trim($this->vars['title']);
		$this->color=trim($this->vars['color']);
	}
}

class plugin_zqlj_renew_forum extends plugin_zqlj_renew{
	function viewthread_title_extra(){
		global $_G;
		if(!$_G['uid']) return '';
		if($this->isauthor&&$_G['thread']['authorid']!=$_G['uid']) return '';
		if(in_array($_G['groupid'],$this->groups)&&in_array($_G['fid'],$this->forums)){
			return '<a href="plugin.php?id=zqlj_renew:renew&fid='.$_G['fid'].'&tid='.$_G['tid'].'&hash='.FORMHASH.'"><font color="'.$this->color.'">'.$this->title.'</font></a>';
		}	
	}
}
//From: Dism_taobao-com
?>