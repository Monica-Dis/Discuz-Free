<?php
/*
 * ��ҳ��http://dism.taobao.com/?@72763.developer
 * https://dism.taobao.com
 * DisM!Ӧ�����ģ�dism.taobao.com
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$groups=(array)unserialize($_G['cache']['plugin']['zqlj_renew']['groups']);
if(submitcheck('submit')){
	$rnum=array();
	foreach($groups as $k=>$groupid){
		$rnum[intval($groupid)]=intval($_POST['num'.$groupid]);
	}
	@require_once libfile('function/cache');
	$cacheArray = "\$rnum=".arrayeval($rnum).";\n";
	writetocache('zqlj_rnum', $cacheArray);
	cpmsg(lang('plugin/zqlj_renew','right_ok'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=zqlj_renew&pmod=right');
}else{
	$_price=intval($_G['cache']['plugin']['zqlj_renew']['price']);
	$filepath=DISCUZ_ROOT.'./data/sysdata/cache_zqlj_rnum.php';
	if(file_exists($filepath)){
		@include $filepath;	
	}	
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=zqlj_renew&pmod=right');
	showtableheader(lang('plugin/zqlj_renew','right_title'));
	showsubtitle(array('groupid',lang('plugin/zqlj_renew','right_m_group'),lang('plugin/zqlj_renew','right_m_price')));
	foreach($groups as $k=>$groupid) {
		if($groupid){
			$r=$rnum[$groupid]? $rnum[$groupid]:$_price;
			$grouptitle=DB::result_first("SELECT grouptitle FROM ".DB::table('common_usergroup')." where groupid=$groupid ");
			showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
				'<input type="hidden" class="px" value="'.$groupid.'" name="groupid'.$groupid.'"/>'.$groupid,
				$grouptitle,
				'<input type="text" class="px" size="10" value="'.$r.'" name="num'.$groupid.'"/>',
			));		
		}
	}
	showsubmit('submit', 'submit');
	showtablefooter();
	showformfooter();	
}
//From: Dism_taobao-com
?>