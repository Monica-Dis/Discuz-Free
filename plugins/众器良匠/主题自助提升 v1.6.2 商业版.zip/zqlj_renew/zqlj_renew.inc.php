<?php 
/*
 * 主页：http://dism.taobao.com/?@72763.developer
 * https://dism.taobao.com
 * DisM!应用中心：dism.taobao.com
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache('plugin');
$vars=$_G['cache']['plugin']['zqlj_renew'];
$c_url=trim($vars['c_url']);
if(!$c_url){
	$c_url='home.php?mod=spacecp&ac=credit&op=buy';
}
echo '<script type="text/javascript">window.location.href = "'.$c_url.'";</script>';
?>