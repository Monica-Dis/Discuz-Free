<?php
/*
 * 主页：http://dism.taobao.com/?@72763.developer
 * https://dism.taobao.com
 * DisM!应用中心：dism.taobao.com
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<SQL
DROP TABLE IF EXISTS pre_zqlj_renew;
SQL;
runquery($sql);
$finish = TRUE;
?>