<?php
/*
 * ��ҳ��http://dism.taobao.com/?@72763.developer
 * https://dism.taobao.com
 * DisM!Ӧ�����ģ�dism.taobao.com
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$_G['uid']){//�ο�
	showmessage(lang('plugin/zqlj_renew','op_msg_login'), '', array(), array('login' => true));
}
$hash=trim($_GET['hash']);
if($hash!=formhash()) showmessage(lang('plugin/zqlj_renew','op_msg_hash'));
loadcache('plugin');
$vars=$_G['cache']['plugin']['zqlj_renew'];
$forums=(array)unserialize($vars['forums']);
$groups=(array)unserialize($vars['groups']);
$isauthor=intval($vars['isauthor']);
$creditid=intval($vars['creditid']);
$_price=intval($vars['price']);
$credit_name=$_G['setting']['extcredits'][$creditid]['title'];
$credit_max = getuserprofile('extcredits'.$creditid); 

if(!in_array($_G['groupid'],$groups)) showmessage(lang('plugin/zqlj_renew','op_msg_error_group'));
$tid=intval($_GET['tid']);
$fid=intval($_GET['fid']);
if($tid&&$fid){
	$thread=DB::fetch_first("select authorid,fid from ".DB::table('forum_thread')." where fid='$fid' and tid='$tid'");
	if(!$thread) showmessage(lang('plugin/zqlj_renew','op_msg_error_thread'));
	if(!in_array($thread['fid'],$forums)) showmessage(lang('plugin/zqlj_renew','op_msg_error_forum'));
	if($isauthor&&$thread['authorid']!=$_G['uid']) showmessage(lang('plugin/zqlj_renew','op_msg_error_author'));
	//$price=0;//free
	$filepath=DISCUZ_ROOT.'./data/sysdata/cache_zqlj_rnum.php';
	if(file_exists($filepath)){
		@include $filepath;	
	}
	$price=$rnum[$_G['groupid']]? $rnum[$_G['groupid']]:$_price;
	if($price){
		if($credit_max<$price){
			showmessage(lang('plugin/zqlj_renew','op_msg_error_cost_1').$price.$credit_name.lang('plugin/zqlj_renew','op_msg_error_cost_2').'<a href="plugin.php?id=zqlj_renew">'.$vars['c_tips'].'</a>');
		}
		updatemembercount($_G['uid'], array($creditid=>-$price),true,'',0,lang('plugin/zqlj_renew','appname'),lang('plugin/zqlj_renew','appname'),lang('plugin/zqlj_renew','appname'));
	}

	DB::update('forum_thread',array('lastpost'=>TIMESTAMP),array('tid'=>$tid));
	C::t('forum_forum')->clear_cache($fid);
	C::t('forum_thread')->clear_cache($tid);
	$data=array(
		'tid'=>$tid,
		'fid'=>$fid,
		'username'=>$_G['username'],
		'uid'=>$_G['uid'],
		'cost'=>$price,	
		'creditid'=>$creditid,	
		'dateline'=>TIMESTAMP,	
	);
	DB::insert('zqlj_renew',$data);
	showmessage(lang('plugin/zqlj_renew','op_msg_ok').$price.$credit_name, dreferer(), array(), array('locationtime'=>true,'refreshtime'=>3, 'showdialog'=>1, 'showmsg' => true));
}else{
	showmessage(lang('plugin/zqlj_renew','op_msg_error_id'));
}
//From: Dism_taobao-com
?>