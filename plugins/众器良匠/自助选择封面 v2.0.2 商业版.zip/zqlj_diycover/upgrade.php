<?php
/*
 * 主页：https://dism.taobao.com/?@72763.developer
 * 众器良匠：Discuz!应用中心认证开发者！
 * 插件定制 联系QQ281688302
 * 承接各类插件定制开发业务！
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
/* 删除文件 */
$identifier = 'zqlj_diycover';
$extras = array("SC_UTF8","SC_GBK","TC_UTF8","TC_BIG5");
$entrydir = DISCUZ_ROOT.'./source/plugin/'.$identifier;
foreach($extras as $extra){
  @unlink($entrydir.'/discuz_plugin_'.$identifier."_".$extra.'.xml');
}
@unlink($entrydir.'/discuz_plugin_'.$identifier.'.xml');
@unlink($entrydir.'/install.php');
@unlink($entrydir.'/upgrade.php');
/* 删除文件 */
$finish = TRUE;

?>