<?php
/*
 * ��ҳ��https://dism.taobao.com/?@72763.developer
 * ����������Discuz!Ӧ��������֤�����ߣ�
 * ������� ��ϵQQ281688302
 * �нӸ��������ƿ���ҵ��
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$_G['uid']){//δ��½����
	showmessage(lang('plugin/zqlj_diycover','userlogin'), '', array(), array('login' => true));
}
if($_GET['formhash']!=formhash()){
	showmessage(lang('plugin/zqlj_diycover','hasherror'));
}
loadcache('plugin');
$vars = $_G['cache']['plugin']['zqlj_diycover'];
$groups=unserialize($vars['groups']);	
$forums=unserialize($vars['forums']);	
$opengroup=intval($vars['opengroup']);	
$isauthor=intval($vars['isauthor']);	
$imgurl=trim($vars['imgurl']);	
$fid=intval($_GET['fid']);
$tid=intval($_GET['tid']);
$pid=intval($_GET['pid']);
$thread=C::t('forum_thread')->fetch($tid);
if(!$thread){
	showmessage(lang('plugin/zqlj_diycover','nothread'));
}
if(!in_array($thread['fid'],$forums)&&!($thread['isgroup']&&$opengroup)){
	showmessage(lang('plugin/zqlj_diycover','fiderror'));
}
if(in_array($_G['groupid'],$groups)||($isauthor&&$thread['authorid']==$_G['uid'])){ 
	$attachlist=DB::fetch_all("select * from ".DB::table('forum_attachment_'.($tid%10))." where tid='$tid' and pid='$pid' and isimage=1");
	if(!$attachlist) showmessage(lang('plugin/zqlj_diycover','noimg'));
	$ftype='jpg';//cover ǿ��������jpg��ʽ
	$coverdir = DISCUZ_ROOT.'./data/attachment/forum/threadcover/'.substr(md5($tid),0,2).'/'.substr(md5($tid),2,2).'/';
	$coverdir .= $tid.'.'.$ftype;
	if(file_exists($coverdir)){
		$_cover=$_G['siteurl'].'data/attachment/forum/threadcover/'.substr(md5($tid),0,2).'/'.substr(md5($tid),2,2).'/'.$tid.'.'.$ftype;
	}else{
		$_cover='';
	}
	include template('zqlj_diycover:push');
}else{
	showmessage(lang('plugin/zqlj_diycover','noright'));
}


?>