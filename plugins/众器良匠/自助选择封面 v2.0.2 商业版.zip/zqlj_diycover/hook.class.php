<?php

/*
 * ��ҳ��https://dism.taobao.com/?@72763.developer
 * ����������Discuz!Ӧ��������֤�����ߣ�
 * ������� ��ϵQQ281688302
 * �нӸ��������ƿ���ҵ��
 */


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_zqlj_diycover{
	function __construct(){
		global $_G;	
		loadcache('plugin');
		$vars=$_G['cache']['plugin']['zqlj_diycover'];		
		$this->forums=unserialize($vars['forums']);
		$this->groups=unserialize($vars['groups']);
		$this->isauthor=intval($vars['isauthor']);
		$this->place=intval($vars['place']);
		$this->opengroup=intval($vars['opengroup']);
	}
}
class plugin_zqlj_diycover_forum extends plugin_zqlj_diycover{
	function viewthread_title_extra_output(){//�����Ҳ�
		global $_G,$postlist;
		if($this->place!=1) return '';
		if(!in_array($_G['fid'],$this->forums)) return '';
		if(intval($_GET['page'])>=2) return '';
		if(in_array($_G['groupid'],$this->groups)||($_G['uid']&&$this->isauthor&&$_G['thread']['authorid']==$_G['uid'])){
			foreach($postlist as $k=>$post){
				$pid=$post['pid'];
				break;
			}
			return '<a href="javascript:;" onclick=showWindow(\'zqlj_diycover\',\'plugin.php?id=zqlj_diycover:push&fid='.$_G['fid'].'&tid='.$_G['tid'].'&pid='.$pid.'&formhash='.FORMHASH.'\')>'.lang('plugin/zqlj_diycover','setcover').'</a>';
		}
		return '';
	}
	
	function viewthread_postfooter_output(){//�ײ���ť
		global $_G,$postlist;
		if($this->place!=2) return '';
		if(!in_array($_G['fid'],$this->forums)) return array();
		if(intval($_GET['page'])>=2) return array();
		if(in_array($_G['groupid'],$this->groups)||($_G['uid']&&$this->isauthor&&$_G['thread']['authorid']==$_G['uid'])){
			foreach($postlist as $k=>$post){
				$pid=$post['pid'];
				break;
			}
			return array('<a class="push" href="javascript:;" onclick=showWindow(\'zqlj_diycover\',\'plugin.php?id=zqlj_diycover:push&fid='.$_G['fid'].'&tid='.$_G['tid'].'&pid='.$pid.'&formhash='.FORMHASH.'\')>'.lang('plugin/zqlj_diycover','setcover').'</a>');
		}
		return array();
	}	
}

class plugin_zqlj_diycover_group extends plugin_zqlj_diycover{
	function viewthread_title_extra_output(){//�����Ҳ�
		global $_G,$postlist;
		if($this->place!=1) return '';
		if(!$this->opengroup) return '';
		if(intval($_GET['page'])>=2) return '';
		if(in_array($_G['groupid'],$this->groups)||($_G['uid']&&$this->isauthor&&$_G['thread']['authorid']==$_G['uid'])){
			foreach($postlist as $k=>$post){
				$pid=$post['pid'];
				break;
			}
			return '<a href="javascript:;" onclick=showWindow(\'zqlj_diycover\',\'plugin.php?id=zqlj_diycover:push&fid='.$_G['fid'].'&tid='.$_G['tid'].'&pid='.$pid.'&formhash='.FORMHASH.'\')>'.lang('plugin/zqlj_diycover','setcover').'</a>';
		}
		return '';
	}
	
	function viewthread_postfooter_output(){//�ײ���ť
		global $_G,$postlist;
		if($this->place!=2) return '';
		if(!$this->opengroup) return array();
		if(intval($_GET['page'])>=2) return array();
		if(in_array($_G['groupid'],$this->groups)||($_G['uid']&&$this->isauthor&&$_G['thread']['authorid']==$_G['uid'])){
			foreach($postlist as $k=>$post){
				$pid=$post['pid'];
				break;
			}
			return array('<a class="push" href="javascript:;" onclick=showWindow(\'zqlj_diycover\',\'plugin.php?id=zqlj_diycover:push&fid='.$_G['fid'].'&tid='.$_G['tid'].'&pid='.$pid.'&formhash='.FORMHASH.'\')>'.lang('plugin/zqlj_diycover','setcover').'</a>');
		}
		return array();
	}		
}	

?>