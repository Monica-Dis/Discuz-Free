<?php
/*
 * 主页：https://dism.taobao.com/?@72763.developer
 * 众器良匠：Discuz!应用中心认证开发者！
 * 插件定制 联系QQ281688302
 * 承接各类插件定制开发业务！
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$identifier = 'zqlj_diycover';
if(!function_exists('cloudaddons_deltree')) require libfile('function/cloudaddons');
cloudaddons_deltree(DISCUZ_ROOT .'./source/plugin/'.$identifier.'/');
$finish = TRUE;

?>