<?php 
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_GET['op']=='clear'&&$_GET['formhash']==formhash()){
	DB::query("delete from ".DB::table('gourl_logs')." ");
	cpmsg(lang('plugin/gourl','clear_ok'),'action=plugins&operation=config&do='.$pluginid.'&identifier=gourl&pmod=logs', 'succeed');
}

$page=max(1,intval($_GET['page']));
$pagenum=20;
$partlist=array(
	0=>lang('plugin/gourl','client_0'),
	1=>lang('plugin/gourl','client_1'),
	2=>lang('plugin/gourl','client_2'),
);
$count=DB::result_first("select count(*) from ".DB::table("gourl_logs")." where 1");
$data=DB::fetch_all("select * from ".DB::table('gourl_logs')." a join ".DB::table('gourl_urls')." b on a.aid=b.aid where 1 order by logid desc".DB::limit(($page-1)*$pagenum,$pagenum));
showtableheader('<a style="float:right;" href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=gourl&pmod=logs&op=clear&formhash='.FORMHASH.'"><font color="red">'.lang('plugin/gourl','clear').'</font></a>'.lang('plugin/gourl','ls_title_1'));
showsubtitle(array(lang('plugin/gourl','ls_m_1'),lang('plugin/gourl','ls_m_2'),lang('plugin/gourl','ls_m_3'),lang('plugin/gourl','ls_m_4'),lang('plugin/gourl','ls_m_5'),lang('plugin/gourl','ls_m_6'),lang('plugin/gourl','ls_m_7'),lang('plugin/gourl','ls_m_8')));	
$index=1;
foreach($data as $k=>$log) {
	showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
		$log['logid'],
		$log['username']? '<a href="home.php?mod=space&uid='.$log['uid'].'" target="_blank">'.$log['username'].'</a>':lang('plugin/gourl','youke'),
		$log['title'],
		$log['url'],
		$log['ip'],
		dgmdate($log['dateline'],'Y-m-d H:i:s'),
		$log['money'],
		$partlist[$log['client']],
	));
	$index++;
			
}
showtablefooter(); //d'.'is'.'m.ta'.'obao.com	
echo multi($count,$pagenum,$page,ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=gourl&pmod=logs");
?>