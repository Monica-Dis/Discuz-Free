<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
if($_GET['op']=='delete'&&$_GET['formhash']==formhash()){
	$aid=intval($_GET['aid']);
	DB::delete('gourl_urls',array('aid'=>$aid));
	DB::delete('gourl_logs',array('aid'=>$aid));
	addcache();
    cpmsg(lang('plugin/gourl','ok_del'),'action=plugins&operation=config&do='.$pluginid.'&identifier=gourl&pmod=item', 'succeed');	
	exit;
}
if(!submitcheck('linksubmit')){
?>
<script type="text/JavaScript">
var rowtypedata = [
	[
		[1,'', 'td25'],
		[1,'', 'td28'],
		[1,'<input type="text" class="txt" name="newname[]" size="150" style="width:150px;">'],
		[1,'<input type="text" class="txt" name="newurl[]" size="200" style="width:300px;">']
	]
]
</script>
<?php
	//��������
	$where ='';
	if(submitcheck('searchsubmit')){
		$stype=intval($_GET['stype']);
		$skw=trim($_GET['skw']);
		if($stype==1){//�������û���
			$skw=addslashes($skw);
			$where=" and title like '%".$skw."%'";
		}elseif($stype==2){//������uid
			$skw=addslashes($skw);
			$where=" and url like '%".$skw."%'";
		}
		//cpmsg(lang('plugin/gourl','s_free'),'action=plugins&operation=config&do='.$pluginid.'&identifier=gourl&pmod=item', 'succeed');
	}

	showformheader("plugins&operation=config&do=$pluginid&identifier=gourl&pmod=item");
	showtableheader(lang('plugin/gourl','s_title'), 'nobottom');		
	showsetting(lang('plugin/gourl','s_type'), array('stype',forumSelect()),$stype, 'select');
	showsetting(lang('plugin/gourl','s_kw'),'skw',$skw,'text','', 0,lang('plugin/gourl','s_kw_tip'));
	showsubmit('searchsubmit');
	showtablefooter(); //d'.'is'.'m.ta'.'obao.com
	showformfooter(); //di'.'sm.t'.'aoba'.'o.com
	//�б�
	$page=max(1,intval($_GET['page']));
	$pagenum=20;
	$adlist=array();
	$filepath=DISCUZ_ROOT.'./data/sysdata/cache_gourl_urls.php';
	if(file_exists($filepath)){
		@include $filepath;	
	}
	$count=count($adlist);
    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=gourl&pmod=item');
    showtableheader(lang('plugin/gourl','item_title')."(<font color=\"red\">$count</font>)");
    showsubtitle(array('', 'AID', lang('plugin/gourl','item_m_title'), lang('plugin/gourl','item_m_url'),lang('plugin/gourl','item_m_url_1'),lang('plugin/gourl','item_m_url_2'),lang('plugin/gourl','item_m_click'),lang('plugin/gourl','item_m_del')));
    $count=DB::result_first("select count(*) from ".DB::table('gourl_urls')." where 1 $where");
    $adlist = DB::fetch_all("SELECT * FROM ".DB::table('gourl_urls')." where 1 $where ORDER BY aid desc limit ".($pagenum*($page-1)).",$pagenum");
	echo '<tr><td></td><td colspan="4"><div><a href="#" onclick="addrow(this, 0)" class="addtr">'.lang('plugin/gourl','item_add').'</a></div></td></tr>';
    foreach($adlist as $k=>$link) {
		$aid=$link['aid'];
		$url_1=$_G['siteurl'].'plugin.php?id=gourl&aid='.$aid;
		$url_2=$_G['siteurl'].'gourl-'.$aid.'.html';
		$click=DB::result_first("select count(*) from ".DB::table('gourl_logs')." where aid='$aid'");
        showtablerow('', array('class="td25"', 'class="td28"', '', '', ''), array('<input type="checkbox" class="checkbox" name="delete[]" value="' . $link['aid'] . '" />',
			$link['aid'],
			'<input type="text" class="txt" name="name['.$aid.']" value="'.dhtmlspecialchars($link['title']).'" size="150" style="width:150px;"/>',
			'<input type="text" class="txt" name="url['.$aid.']" value="'.dhtmlspecialchars($link['url']).'" size="200" style="width:300px;"/>',
			'<a href="'.$url_1.'" target="_blank">'.$url_1.'</a>',
			'<a href="'.$url_2.'" target="_blank">'.$url_2.'</a>',
			$click,
			'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=gourl&pmod=item&op=delete&aid='.$link['aid'].'&formhash='.FORMHASH.'">'.lang('plugin/gourl','item_m_del').'</a>',
        ));
    }
	$pages=multi($count,$pagenum,$page,ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=gourl&pmod=item");
    showsubmit('linksubmit', 'submit', 'del');
    showtablefooter(); //d'.'is'.'m.ta'.'obao.com
    showformfooter(); //di'.'sm.t'.'aoba'.'o.com
	echo $pages;
}else {
    // ���ǰ����
    $postdata = daddslashes(dstripslashes($_POST));
    if($postdata['delete']) {
        DB::delete('gourl_urls',"aid IN (" . dimplode($postdata['delete']) . ")");
        DB::delete('gourl_logs',"aid IN (" . dimplode($postdata['delete']) . ")");
    }
	//����
    if(is_array($postdata['name'])) {
        foreach($postdata['name'] as $id => $val) {
            $type_str = intval($postdata['portal'][$id]) . intval($postdata['forum'][$id]) . intval($postdata['group'][$id]) . intval($postdata['home'][$id]);
            $type_str = intval($type_str, '2');
            DB::update('gourl_urls', array(
				'title' => $postdata['name'][$id],
				'url' => $postdata['url'][$id],
			), array('aid' => intval($id)));
        }
    }
	//����
    if(is_array($postdata['newname'])){
        foreach($postdata['newname'] as $key => $value){
            if($value){
                DB::insert('gourl_urls', array(
					'title' => $value,
					'url' => $postdata['newurl'][$key],
				));
            }
        }
    }
	addcache();
    cpmsg(lang('plugin/gourl','ok_update'),'action=plugins&operation=config&do='.$pluginid.'&identifier=gourl&pmod=item', 'succeed');
}

//�����������ӣ����ǰ̨�ٶ�
function addcache(){
	$linklist=DB::fetch_all("select * from ".DB::table('gourl_urls')." where 1 order by aid");
	$adlist=array();
	foreach($linklist as $k=>$ad){
		$adlist[$ad['aid']]=$ad;
	}
	@require_once libfile('function/cache');
	$cacheArray = "\$adlist=".arrayeval($adlist).";\n";
	writetocache('gourl_urls',$cacheArray);		
}

function forumSelect(){
	$arr[0]=array(0,lang('plugin/gourl','type_0'));
	$arr[1]=array(1,lang('plugin/gourl','type_1'));
	$arr[2]=array(2,lang('plugin/gourl','type_2'));
	return $arr;
}

//From: dis'.'m.tao'.'bao.com
?>