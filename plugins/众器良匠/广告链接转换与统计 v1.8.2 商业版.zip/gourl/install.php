<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
DROP TABLE IF EXISTS `pre_gourl_urls`;
CREATE TABLE `pre_gourl_urls` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`aid`)
)ENGINE=MyISAM;
DROP TABLE IF EXISTS `pre_gourl_logs`;
CREATE TABLE `pre_gourl_logs` (
  `logid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL default '',  
  `aid` int(11) unsigned NOT NULL,
  `money` int(11) unsigned NOT NULL,
  `ip` varchar(50) NOT NULL,
  `client` tinyint(1) unsigned NOT NULL default '0',
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`logid`)
)ENGINE=MyISAM;
EOF;

runquery($sql);
$finish = TRUE;

?>