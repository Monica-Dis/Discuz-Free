<?php
/*
 * 主页：https://addon.dismall.com/?@72763.developer
 * 苏州众器良匠网络科技有限公司 出品
 * 插件定制 联系QQ281688302
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
//From: Dism_taobao-com
?>
<iframe src="https://addon.dismall.com/?@72763.developer" width="100%" height="2000" frameborder="0" scrolling="no" style="min-width:870px;margin-left:-3px; background:#F4FAFD" ></iframe> 