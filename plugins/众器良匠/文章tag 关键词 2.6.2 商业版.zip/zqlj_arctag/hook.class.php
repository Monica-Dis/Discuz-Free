<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_zqlj_arctag {
	function __construct(){
		global $_G;
		loadcache('plugin');
		$var = $_G['cache']['plugin']['zqlj_arctag'];
		$this->autoTags=$this->tagTrim($var['autoTags']);
		$this->rewrite=intval($var['rewrite']);
	}	

	function _tagUrl($tagid){
		if($this->rewrite) return 'arctag-'.$tagid.'-1.html';
		else return 'plugin.php?id=zqlj_arctag:list&tagid='.$tagid;
	}
	
	function pluginCache($aid){//��ȡ & ����
		$list=array();
		$filepath=DISCUZ_ROOT.'./data/sysdata/cache_zqlj_arctag_'.$aid.'.php';
		if(file_exists($filepath)){
			@include_once $filepath;
		}else{
			$list=DB::fetch_all("select a.tagid,a.tagname from ".DB::table('zqlj_arctag_tag')." a join ".DB::table('zqlj_arctag_connect')." b on a.tagid=b.tagid where b.aid='$aid'");
			@require_once libfile('function/cache');
			$cacheArray = "\$list=".arrayeval($list).";\n";
			writetocache('zqlj_arctag_'.$aid, $cacheArray);			
		}
		return $list;
	}

	function pluginUpdateCache($aid){//�༭ʱ ǿ�Ƹ���
		$list=DB::fetch_all("select a.tagid,a.tagname from ".DB::table('zqlj_arctag_tag')." a join ".DB::table('zqlj_arctag_connect')." b on a.tagid=b.tagid where b.aid='$aid'");
		@require_once libfile('function/cache');
		$cacheArray = "\$list=".arrayeval($list).";\n";
		writetocache('zqlj_arctag_'.$aid, $cacheArray);	
	}	
}

class plugin_zqlj_arctag_portal extends plugin_zqlj_arctag {
	function view_article_content_output(){//������� ��ʾtag
		global $_G,$metakeywords;
		$aid=intval($_GET['aid']);
		$list=$this->pluginCache($aid);
		if($list){
			$tags='';
			foreach($list as $k=>$v){
				$tags.=$tags? ','.$v['tagname']:$v['tagname'];
			}
			$metakeywords=$metakeywords? $tags.','.$metakeywords:$tags;	
		}		
		include template('zqlj_arctag:tag_list');
		return $return;		
	}
	
	function portalcp_fromthread_output($var){
		global $_G,$aid,$op;
		loadcache('plugin');
		if(submitcheck('articlesubmit')){
			if($op=='add_success'&&$aid){//����ʱ&�༭ʱ
				$update=0;
				$tags=$this->tagTrim($_GET['tags']);
				$list=$this->pluginCache($aid);
				$old=array();
				foreach($list as $k=>$v){
					if(!$tags){//�༭ʱ �����
						DB::delete('zqlj_arctag_connect',array('tagid'=>$v['tagid'],'aid'=>$aid));
						$update++;
					}else{
						$old[md5($v['tagname'])]=$v['tagid'];
					}
				}
				foreach($tags as $kk=>$tag){
					if(isset($old[md5($tag)])){
						unset($old[md5($tag)]);
					}else{
						$tagid=$this->getTagId($tag);
						if($tagid){
							DB::insert('zqlj_arctag_connect',array('tagid'=>$tagid,'aid'=>$aid));
							$update++;
						}
					}
				}
				if(count($old)){//�༭ʱȥ����ĳЩtag ɾ��connect��ϵ
					foreach($old as $hash=>$tagid){
						DB::delete('zqlj_arctag_connect',array('tagid'=>$tagid,'aid'=>$aid));
						$update++;
					}
				}
				if($update){//�и���
					$this->pluginUpdateCache($aid);
				}
			}
		}
	}
	
	function portalcp_middle(){
		global $_G;
		$tags='';
		if($_GET['op']=='edit'){
			$aid=intval($_GET['aid']);
			$list=$this->pluginCache($aid);
			if($list){
				foreach($list as $k=>$v){
					$tags.=$tags? ','.$v['tagname']:$v['tagname'];
				}
			}
		}
		$last=DB::fetch_all("select * from ".DB::table('zqlj_arctag_tag')." order by tagid desc limit 0,10");
		$autoTags=$this->autoTags;
		include template('zqlj_arctag:tag_item');
		return $return;		
	}
	
	function getTagId($tag){
		$tagid=DB::result_first("select tagid from ".DB::table('zqlj_arctag_tag')." where tagname='$tag'");
		if($tagid){
			return $tagid;
		}else{
			return DB::insert('zqlj_arctag_tag',array('tagname'=>$tag),true);
		}
	}
	function tagTrim($tags){
		$tags = str_replace(array(chr(0xa3).chr(0xac), chr(0xa1).chr(0x41), chr(0xef).chr(0xbc).chr(0x8c)), ',',trim($tags));
		$langcore = lang('core');
		$tags = str_replace(' ',',',$tags);
		$tags = str_replace($langcore['fullblankspace'],',',$tags);		
		$tagarray = array_unique(explode(',', $tags));
		$tagcount = 0;
		foreach($tagarray as $k=>$tagname) {
			$tagname = trim($tagname);
			if(!preg_match('/^([\x7f-\xff_-]|\w|\s){3,20}$/', $tagname)) {
				unset($tagarray[$k]);
			}
		}
		return $tagarray;
	}
}
//From: Dism��taobao��com
?>