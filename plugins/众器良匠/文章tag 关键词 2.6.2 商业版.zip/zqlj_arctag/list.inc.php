<?php 
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache('plugin');
$vars = $_G['cache']['plugin']['zqlj_arctag'];
$rewrite=intval($vars['rewrite']);//伪静态开关
$pagenum=max(2,intval($vars['pagenum']));//分页条数
$tagid=intval($_GET['tagid']);
$tag=DB::fetch_first("select * from ".DB::table('zqlj_arctag_tag')." where tagid='$tagid'");
if(!$tag){
	showmessage(lang('plugin/zqlj_arctag','notag'));
}else{
	$page=max(1,intval($_GET['page']));
	$count=DB::result_first("select count(*) from ".DB::table('zqlj_arctag_connect')." b join ".DB::table('portal_article_title')." c on b.aid=c.aid join ".DB::table('portal_article_count')." d on b.aid=d.aid where b.tagid='$tagid' ");
	$arclist=DB::fetch_all("select c.*,d.viewnum from ".DB::table('zqlj_arctag_connect')." b join ".DB::table('portal_article_title')." c on b.aid=c.aid join ".DB::table('portal_article_count')." d on b.aid=d.aid where b.tagid='$tagid' order by c.aid desc ".DB::limit(($page-1)*$pagenum,$pagenum)." ");
	if($rewrite) $multipage = rewriteMulti($count, $pagenum, $page);
	else $multipage = multi($count, $pagenum, $page, 'plugin.php?id=zqlj_arctag:list&tagid='.$tagid);
	
	$tag['tagname']=dhtmlspecialchars($tag['tagname']);
	$navtitle=$tag['tagname'];
	$metakeywords=$tag['tagname'];	
}
include template('zqlj_arctag:threadlist');

function rewriteMulti($num, $perpage, $curpage, $mpurl, $maxpages = 0, $page = 11, $autogoto = FALSE, $jsfunc = FALSE) {
	global $tagid;
	$lang['prev'] = '&lsaquo;&lsaquo;';
	$lang['next'] = '&rsaquo;&rsaquo;';	
	$lang['pageunit'] = lang('core', 'pageunit');
	$lang['total'] = lang('core', 'total');
	$lang['prevpage'] = lang('core', 'prevpage');
	$lang['head'] = lang('plugin/zqlj_arctag','head');
	$lang['foot'] = lang('plugin/zqlj_arctag','foot');
	$multipage='';
	$mpurl.='';
	$realpages = 1;
	$page -= strlen($curpage) - 1;
	if($page<= 0) {
		$page = 1;
	}
	if($num > $perpage) {
		$offset = floor($page * 0.5);
		$realpages = @ceil($num / $perpage);
		$curpage = $curpage > $realpages ? $realpages : $curpage;
		$pages = $maxpages && $maxpages < $realpages ? $maxpages : $realpages;
		if($page > $pages) {
			$from = 1;
			$to = $pages;
		} else {
			$from = $curpage - $offset;
			$to = $from + $page - 1;
			if($from < 1) {
				$to = $curpage + 1 - $from;
				$from = 1;
				if($to - $from < $page) {
					$to = $page;
				}
			} elseif($to > $pages) {
				$from = $pages - $page + 1;
				$to = $pages;
			}
		}
		$multipage = ($curpage - $offset > 1 && $pages > $page ? '<a href="arctag-'.$tagid.'-1.html">'.$lang['head'].'</a>' : '');
		$multipage .=($curpage>1 ? '<a href="arctag-'.$tagid.'-'.($curpage - 1).'.html">'.$lang['prev'].'</a>' : '');
		for($i = $from; $i <= $to; $i++) {
			$multipage .= $i == $curpage ? '<strong>'.$i.'</strong>':'<a href="arctag-'.$tagid.'-'.$i.'.html">'.$i.'</a>';
		}
		$multipage .=($curpage<$pages? '<a href="arctag-'.$tagid.'-'.($curpage + 1).'.html">'.$lang['next'].'</a>' : '');
		$multipage .=($to < $pages ? '<a title="'.$lang['total'].$pages.$lang['pageunit'].'" href="arctag-'.$tagid.'-'.$pages.'.html">'.$lang['foot'].'</a>' : '');
	}
	return '<div class="pg">'.$multipage.'</div>';
}
//From: Dism·taobao·com
?>