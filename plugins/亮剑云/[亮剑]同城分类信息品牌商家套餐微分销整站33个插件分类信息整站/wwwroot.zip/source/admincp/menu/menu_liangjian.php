<?php

/*
 * 作者: Discuz!亮剑工作室
 * 技术支持: http://www.dzx30.com/
 * 客服QQ: 190360183
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$topmenu['liangjian'] = '';
$_G['lang']['admincp']['header_liangjian'] = '亮剑';

loadcache('adminmenu');
if(is_array($_G['cache']['adminmenu'])) {
	foreach($_G['cache']['adminmenu'] as $thismenu) {
		if(strpos($thismenu['name'], '亮剑') !== false) {
			$menu['liangjian'][] = array($thismenu['name'], $thismenu['action']);
		}
	}
}

?>