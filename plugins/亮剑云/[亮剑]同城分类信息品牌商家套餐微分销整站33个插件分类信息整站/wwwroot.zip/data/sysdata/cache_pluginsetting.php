<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 61d750fcdf3a072adc753af2a4f9a92f

$pluginsetting = array (
);
?>