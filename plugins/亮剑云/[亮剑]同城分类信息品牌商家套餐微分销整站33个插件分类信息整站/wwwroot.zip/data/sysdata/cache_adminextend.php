<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 423d8cb4af95238309d920b0e208c479

$adminextend = array (
  0 => 'liangjian.php',
);
?>