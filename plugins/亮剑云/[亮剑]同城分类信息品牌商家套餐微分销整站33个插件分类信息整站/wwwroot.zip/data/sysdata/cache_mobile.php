<?php
//Discuz! cache file, DO NOT modify me!
//Identify: d4ad2f213261f33361c80b81b533f76d

$mobilecheck = '{"discuzversion":"X3.4","charset":"utf-8","version":"4","pluginversion":"1.4.8","oemversion":"0","regname":"register","qqconnect":"0","sitename":"Discuz! Board","mysiteid":"","ucenterurl":"http:\\/\\/127.0.0.1\\/liangjian\\/uc_server","setting":{"closeforumorderby":null},"extends":{"used":null,"lastupdate":null}}';
?>