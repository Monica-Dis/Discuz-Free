<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($settings['mobile_integral_recharge_desc']['value'] && $mobile_integral_recharge && $ext_yes) { ?>
<div class="weui-cells__title" style="padding-top: 2px;margin-top: 0px;">
    <?php echo htmlspecialchars_decode($settings['mobile_integral_recharge_desc']['value'])?></div>
<?php } ?>