<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<table id="tips" class="tb tb2 ">
<tbody><tr><th class="partition">技巧提示</th></tr>
<tr><td s="1" class="tipsblock"><ul id="tipslis">
<li>如果您在使用钱包支付的过程中有任何疑问，欢迎您直接QQ联系亮剑客服1919080885，我们将竭诚为您服务</li>
<li>钱包支付配置教程<a href="http://docs.liangjianyun.com/qy/" target="_blank">http://docs.liangjianyun.com/qy/</a></li>
</ul></td></tr></tbody></table>

<form id="cpform" action="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=aljqb&pmod=paysetting&do=<?php echo $_GET['do'];?>" enctype="multipart/form-data" autocomplete="off" method="post" name="cpform">
<input type="hidden" name="formhash" value="<?php echo FORMHASH;?>">
<table class="tb tb2 nobdb">
<tbody>
<tr><th class="partition" colspan="15">全局设置</th></tr>
<tr><td s="1" class="td27" colspan="2">统一回调地址</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <input  name="settingsnew[OAuth]" value="<?php echo $settings['OAuth']['value'];?>" type="text" class="txt">
    </td>
    <td class="vtop tips2">请填写域名以http://开关以 /结尾，防止多域名支付出错</td>
</tr>
<tr><th class="partition" colspan="15">商城退款设置</th></tr>
<tr><td s="1" class="td27" colspan="2">退款类型</td></tr>
<tr class="noborder" onmouseover="setfaq(this, 'faqd69d')">
    <td class="vtop rowform">
        <select name="settingsnew[refundstype]">
            <option value="0" <?php if(!$settings['refundstype']['value']) { ?>selected=""<?php } ?>>退钱包余额</option>
            <option value="1" <?php if($settings['refundstype']['value'] == 1) { ?>selected=""<?php } ?>>原路退回</option>
        </select>
    </td>
    <td class="vtop tips2" s="1">退钱包余额：所有支付退款都退回钱包余额<br/>原路退回：支持支付宝、微信、app微信、千帆APP支付原路退回<br/>退款与转账共用证书，已配置过转账的可以直接使用原路退回，未配置过的请按教程配置下<a href="https://docs.liangjianyun.com/qy/">https://docs.liangjianyun.com/qy/</a></td>
</tr>
<tr><td s="1" class="td27" colspan="2">退款方式</td></tr>
<tr class="noborder" onmouseover="setfaq(this, 'faqd69d')">
    <td class="vtop rowform">
        <select name="settingsnew[refundstatus]">
            <option value="0" <?php if(!$settings['refundstatus']['value']) { ?>selected=""<?php } ?>>商家同意后管理员同意退款</option>
            <option value="1" <?php if($settings['refundstatus']['value'] == 1) { ?>selected=""<?php } ?>>商家同意直接退款</option>
        </select>
    </td>
    <td class="vtop tips2" s="1">商家同意后管理员同意退款：商家同意后需要管理员再点击同意才能退款<br/>商家同意直接退款:不需要管理员同意商家同意后直接退款</td>
</tr>
<tr><th class="partition" colspan="15">钱包余额自动提现到APP余额设置</th></tr>
<tr><td s="1" class="td27" colspan="2">钱包余额自动提现到APP余额</td></tr>
<tr class="noborder" onmouseover="setfaq(this, 'faqd69d')"><td class="vtop rowform">
    <select name="settingsnew[autoBalanceToApp]">
        <option value="0" <?php if(!$settings['autoBalanceToApp']['value']) { ?>selected=""<?php } ?>>不开启</option>
        <option value="1" <?php if($settings['autoBalanceToApp']['value'] == 1) { ?>selected=""<?php } ?>>提现到马甲APP余额</option>
        <option value="2" <?php if($settings['autoBalanceToApp']['value'] == 2) { ?>selected=""<?php } ?>>提现到千帆APP余额</option>
    </select>
</td><td class="vtop tips2" s="1">目前支持千帆与马甲APP内自动把钱包余额提现到APP余额，请选择对应的APP环境自动提现</td></tr>
<tr><th class="partition" colspan="15">钱包引导下载APP设置</th></tr>
<tr><td s="1" class="td27" colspan="2">引导下载APPLOGO</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <input  name="settingsnew[guideLogo]" value="<?php echo $settings['guideLogo']['value'];?>" type="text" class="txt">
</td>
    <td class="vtop tips2">
    填写LOGO路径<br/>
    填写LOGO、文本、链接，非APP环境会在钱包底部显示引导下载APP<br/>
    填写文本、链接，非APP环境会提示引导下载APP<br/>
    </td>
</tr>
<tr><td s="1" class="td27" colspan="2">引导下载APP文本</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <input  name="settingsnew[guideText]" value="<?php echo $settings['guideText']['value'];?>" type="text" class="txt">
</td>
    <td class="vtop tips2">
        填写LOGO路径<br/>
        填写LOGO、文本、链接，非APP环境会在钱包底部显示引导下载APP<br/>
        填写文本、链接，非APP环境会提示引导下载APP<br/>
    </td>
</tr>
<tr><td s="1" class="td27" colspan="2">引导下载APP链接</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <input  name="settingsnew[guideUrl]" value="<?php echo $settings['guideUrl']['value'];?>" type="text" class="txt">
</td>
    <td class="vtop tips2">
        填写LOGO路径<br/>
        填写LOGO、文本、链接，非APP环境会在钱包底部显示引导下载APP<br/>
        <img src="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljqb/t2.png" width="300"/><br/>
        填写文本、链接，非APP环境会提示引导下载APP<br/>
        <img src="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljqb/t1.png" width="300"/>
    </td>
</tr>

<tr><th class="partition" colspan="15">千帆APP支付设置</th></tr>
<tr><td s="1" class="td27" colspan="2">千帆hostname</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <input  name="settingsnew[qianfanapp_hostname]" value="<?php echo $settings['qianfanapp_hostname']['value'];?>" type="text" class="txt">
</td>
    <td class="vtop tips2">http://<?php echo hostname;?>.qianfanapi.com/填写<?php echo hostname;?>部分</td>
</tr>
<tr><td s="1" class="td27" colspan="2">千帆接口密匙secret</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <input  name="settingsnew[qianfanapp_secert]" value="<?php echo $settings['qianfanapp_secert']['value'];?>" type="text" class="txt">
</td>
    <td class="vtop tips2"></td>
</tr>
<tr><td s="1" class="td27" colspan="2">千帆订单类型</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <input  name="settingsnew[qianfanapp_paytype]" value="<?php echo $settings['qianfanapp_paytype']['value'];?>" type="text" class="txt">
</td>
    <td class="vtop tips2">请前往小后台>>金币与支付>>支付管理>>支付JS类型 获取你想要的支付类型</td>
</tr>
<tr>

<tr><td s="1" class="td27" colspan="2">添加余额的type类型</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <input  name="settingsnew[qianfanapp_txtype]" value="<?php echo $settings['qianfanapp_txtype']['value'];?>" type="text" class="txt">
</td>
    <td class="vtop tips2">需要在小后台>>金币与支付>>支付管理>>设置>>支付设置 添加用户收入类型</td>
</tr>
<tr>

<tr><th class="partition" colspan="15">马甲支付设置</th></tr>
<tr><td s="1" class="td27" colspan="2">马甲客户端网址</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <input  name="settingsnew[magapp_url]" value="<?php echo $settings['magapp_url']['value'];?>" type="text" class="txt">
</td>
    <td class="vtop tips2"></td>
</tr>
<tr><td s="1" class="td27" colspan="2">马甲密钥</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <input  name="settingsnew[magapp_secret]" value="<?php echo $settings['magapp_secret']['value'];?>" type="text" class="txt">
</td>
    <td class="vtop tips2"></td>
</tr>
<tr>



<tr><th class="partition" colspan="15">APP微信支付设置</th></tr>

<tr><td s="1" class="td27" colspan="2">微信APP应用APPID</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <input  name="settingsnew[appid2]" value="<?php echo $settings['appid2']['value'];?>" type="text" class="txt">
</td>
    <td class="vtop tips2">微信支付商户资料审核通过的邮件中可查看</td>
</tr>

<tr><td s="1" class="td27" colspan="2">受理商MCHID</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <input  name="settingsnew[mchid2]" value="<?php echo $settings['mchid2']['value'];?>" type="text" class="txt">
    <td></tr>
<tr><td s="1" class="td27" colspan="2">商户支付密钥Key</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <input  name="settingsnew[key2]" value="<?php echo $settings['key2']['value'];?>" type="text" class="txt">
    <td></tr>



<th class="partition" colspan="15">微信公众号支付接口参数</th></tr>

<tr><td s="1" class="td27" colspan="2">公众号APPID</td></tr>
<tr class="noborder"><td class="vtop rowform">
<input  name="settingsnew[appid]" value="<?php echo $settings['appid']['value'];?>" type="text" class="txt">
<td>
<td class="vtop tips2">微信支付商户资料审核通过的邮件中可查看</td>
</tr>
<tr><td s="1" class="td27" colspan="2">公众号APPSECRET</td></tr>
<tr class="noborder"><td class="vtop rowform">
<input  name="settingsnew[appsecret]" value="<?php echo $settings['appsecret']['value'];?>" type="text" class="txt">
<td></tr>
<tr><td s="1" class="td27" colspan="2">受理商MCHID</td></tr>
<tr class="noborder"><td class="vtop rowform">
<input  name="settingsnew[mchid]" value="<?php echo $settings['mchid']['value'];?>" type="text" class="txt">
<td></tr>
<tr><td s="1" class="td27" colspan="2">商户支付密钥Key</td></tr>
<tr class="noborder"><td class="vtop rowform">
<input  name="settingsnew[key]" value="<?php echo $settings['key']['value'];?>" type="text" class="txt">
<td></tr>

<tr><th class="partition" colspan="15">支付宝手机网站支付</th></tr>
<tr><td s="1" class="td27" colspan="2">合作者身份 (PID)</td></tr>
<tr class="noborder"><td class="vtop rowform">
<input  name="settingsnew[mpartner]" value="<?php echo $settings['mpartner']['value'];?>" type="text" class="txt">
<td></tr>
<tr><td s="1" class="td27" colspan="2">交易安全校验码 (KEY)</td></tr>
<tr class="noborder"><td class="vtop rowform">
<input  name="settingsnew[mkey]" value="<?php echo $settings['mkey']['value'];?>" type="text" class="txt">
<td></tr>
<tr><th class="partition" colspan="15">支付宝转账设置</th></tr>
<tr><td s="1" class="td27" colspan="2">支付宝转账应用(APPID)</td></tr>
<tr class="noborder"><td class="vtop rowform">
<input  name="settingsnew[trans_appid]" value="<?php echo $settings['trans_appid']['value'];?>" type="text" class="txt">
<td>
<td class="vtop tips2">还要将RSA2(SHA256)密钥文件rsa_private_key.pem放在source/plugin/aljqb/function/cert/目录下
</td>
</tr>
<tr><td colspan="15"><div class="fixsel"><input type="submit" value="提交" name="alipaysubmit" id="submit_alipaysubmit" class="btn"></div></td></tr>

</tbody></table>
</form>