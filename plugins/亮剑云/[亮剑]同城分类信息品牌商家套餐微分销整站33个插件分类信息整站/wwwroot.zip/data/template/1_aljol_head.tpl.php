<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="<?php echo CHARSET;?>">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport">
    <meta name="apple-mobile-web-app-capable" content="no">
    <meta content="telephone=no" name="format-detection">
    <meta content="black" name="apple-mobile-web-app-status-bar-style">
    <link href="source/plugin/aljol/static/css/aljol/swiper.min.css?v=<?php echo $version;?>" rel="stylesheet" type="text/css">
    <link href="source/plugin/aljol/static/css/aljol/aljol.css?v=<?php echo $version;?>" rel="stylesheet" type="text/css">
<link href="source/plugin/aljol/static/css/aljol/common.css?v=<?php echo $version;?>" rel="stylesheet" type="text/css">
<link href="source/plugin/aljol/static/mlayer/need/layer.css?v=<?php echo $version;?>" rel="stylesheet" type="text/css">
    <script src="source/plugin/aljol/static/js/jquery.min.js?v=<?php echo $version;?>" type="text/javascript" type="text/javascript"></script>
    <script src="source/plugin/aljol/static/mlayer/layer.js?v=<?php echo $version;?>" type="text/javascript" type="text/javascript"></script>
    <script src="source/plugin/aljol/static/js/lrz.mobile.min.js?v=<?php echo $version;?>" type="text/javascript" type="text/javascript"></script>
    <script src="source/plugin/aljol/static/js/swiper.min.js?v=<?php echo $version;?>" type="text/javascript" type="text/javascript"></script>
    <script src="source/plugin/aljol/static/js/jquery.form.min.js?v=<?php echo $version;?>" type="text/javascript" type="text/javascript"></script>
    <script src="source/plugin/aljol/static/js/jquery-weui.min.js?v=<?php echo $version;?>" type="text/javascript"></script>
    <title><?php if($_GET['act'] == 'talk') { if(!$friendid) { ?><?php echo $_G['cache']['plugin']['aljol']['q_name'];?>
        <?php } elseif($_GET['act'] == 'newstype') { ?>
        <?php echo $navtitle;?>
        <?php } else { ?><?php echo $firendname['username'];?><?php } } else { ?>在线聊天<?php } ?></title>
    <script>
    document.documentElement.style.fontSize = '38px';
    var ws;
    var mobile = <?php if($_G['mobile']) { ?>'_mobile'<?php } else { ?>'_pc'<?php } ?>;
    var uid = '<?php echo $_G['uid'];?>';
    var friendid = '<?php echo $friendid;?>';
    var token = '<?php echo $token;?>';
    <?php if(file_exists('chat.php') && $_G['cache']['plugin']['aljol']['is_socket']) { ?>
    var ws_on = true;
    <?php } else { ?>
    var ws_on = false;    
    <?php } ?>
    </script>
        <script src="source/plugin/aljol/static/js/aljol/aljol.js?v=<?php echo $version;?>" type="text/javascript" type="text/javascript"></script>
</head>
<body >
<style>
    html,body{
        min-height:100vh;
    }
    <?php if($_G['cache']['plugin']['aljol']['header_color']) { ?>
    .topBar,.topBar2 {
        background: <?php echo $_G['cache']['plugin']['aljol']['header_color'];?>;
    }
    .topBar>ul>li.active {
        color: <?php echo $_G['cache']['plugin']['aljol']['header_color'];?>;
    }
    .layim-chat-send button {
    background-color: <?php echo $_G['cache']['plugin']['aljol']['header_color'];?>;
    }
    <?php } ?>
</style>