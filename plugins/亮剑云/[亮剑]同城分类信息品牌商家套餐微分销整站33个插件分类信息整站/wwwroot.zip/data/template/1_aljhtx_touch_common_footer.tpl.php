<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div><?php echo $_G['cache']['plugin']['aljhtx']['common_footer_count'];?></div>
<script type="text/javascript">var STYLEID = '<?php echo STYLEID;?>', STATICURL = '<?php echo STATICURL;?>', IMGDIR = '<?php echo IMGDIR;?>', VERHASH = '<?php echo VERHASH;?>', charset = '<?php echo CHARSET;?>', discuz_uid = '<?php echo $_G['uid'];?>', cookiepre = '<?php echo $_G['config']['cookie']['cookiepre'];?>', cookiedomain = '<?php echo $_G['config']['cookie']['cookiedomain'];?>', cookiepath = '<?php echo $_G['config']['cookie']['cookiepath'];?>', showusercard = '<?php echo $_G['setting']['showusercard'];?>', attackevasive = '<?php echo $_G['config']['security']['attackevasive'];?>', disallowfloat = '<?php echo $_G['setting']['disallowfloat'];?>', creditnotice = '<?php if($_G['setting']['creditnotice']) { ?><?php echo $_G['setting']['creditnames'];?><?php } ?>', defaultstyle = '<?php echo $_G['style']['defaultextstyle'];?>', REPORTURL = '<?php echo $_G['currenturl_encode'];?>', SITEURL = '<?php echo $_G['siteurl'];?>', JSPATH = '<?php echo $_G['setting']['jspath'];?>', CSSPATH = '<?php echo $_G['setting']['csspath'];?>', DYNAMICURL = '<?php echo $_G['dynamicurl'];?>';</script>
<script>
function setcookie(cookieName, cookieValue, seconds, path, domain, secure) {
if(cookieValue == '' || seconds < 0) {
cookieValue = '';
seconds = -2592000;
}
if(seconds) {
var expires = new Date();
expires.setTime(expires.getTime() + seconds * 1000);
}
domain = !domain ? cookiedomain : domain;
path = !path ? cookiepath : path;
document.cookie = escape(cookiepre + cookieName) + '=' + escape(cookieValue)
+ (expires ? '; expires=' + expires.toGMTString() : '')
+ (path ? '; path=' + path : '/')
+ (domain ? '; domain=' + domain : '')
+ (secure ? '; secure' : '');
}

function getcookie(name, nounescape) {
name = cookiepre + name;
var cookie_start = document.cookie.indexOf(name);
var cookie_end = document.cookie.indexOf(";", cookie_start);
if(cookie_start == -1) {
return '';
} else {
var v = document.cookie.substring(cookie_start + name.length + 1, (cookie_end > cookie_start ? cookie_end : document.cookie.length));
return !nounescape ? unescape(v) : v;
}
}
</script>
<?php if($_G['cache']['plugin']['aljyzm']) { include_once DISCUZ_ROOT.'source/plugin/aljyzm/hook.class.php';
$ljqq = mobileplugin_aljyzm::global_footer_mobile();
echo $ljqq;?><?php } if($_G['cache']['plugin']['qu_welcomead']) { include_once DISCUZ_ROOT.'source/plugin/qu_welcomead/welcome.class.php';
echo mobileplugin_qu_welcomead::global_header_mobile();?><?php } ?>