<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div class="form-group starttime" style="display: none">
    <label class="col-sm-3 control-label">开始时间</label>
    <div class="col-sm-9">
    <input  name="starttime" class="laydate-icon form-control" style="height: auto"  id="starttime" value="<?php if($goods['starttime']) { echo gmdate('Y-m-d',$goods['starttime']+8*3600);?><?php } ?>" placeholder="开始时间">
</div>
</div>