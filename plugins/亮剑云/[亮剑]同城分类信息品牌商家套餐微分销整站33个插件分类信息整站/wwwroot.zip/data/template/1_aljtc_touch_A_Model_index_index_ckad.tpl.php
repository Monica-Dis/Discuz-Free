<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<style>
.wx-index__find .find__list{list-style:none;margin:0;padding:0;overflow: hidden;}.wx-index__find .find__item{width: calc(50% - 15px);margin: 10px 0px 0px 10px;float:left;position:relative;height:70px;border-radius:4px;}.wx-index__find .find__item .item__thumb{position:absolute;top:40px;right:10px;max-height:60%;background-color:inherit;-webkit-transform:translateY(-50%);-moz-transform:translateY(-50%);-ms-transform:translateY(-50%);-o-transform:translateY(-50%);transform:translateY(-50%);}.wx-index__find .find__item .item__entry{color:#fff;margin-top:16px;padding-left:16px;}.wx-index__find .find__item .entry__title{margin:0 0 10px 2px;font-size:16px;font-weight:700;height:16px;line-height:16px;-webkit-text-shadow:1px 1px 2px rgba(0,0,0,.12);-moz-text-shadow:1px 1px 2px rgba(0,0,0,.12);-o-text-shadow:1px 1px 2px rgba(0,0,0,.12);text-shadow:1px 1px 2px rgba(0,0,0,.12);}.wx-index__find .find__item .entry__subtitle{width:auto;height: 32px;line-height: 28px;overflow: hidden;text-align:center;border:1px solid #fff;display:inline-block;margin:0;font-size:20px;padding:2px 8px;-webkit-border-radius:16px;-moz-border-radius:16px;-ms-border-radius:16px;-o-border-radius:16px;border-radius:16px;-webkit-transform:scale(.5);-moz-transform:scale(.5);-ms-transform:scale(.5);-o-transform:scale(.5);transform:scale(.5);-webkit-transform-origin:left top;-moz-transform-origin:left top;-ms-transform-origin:left top;-o-transform-origin:left top;transform-origin:left top;}
</style>
<?php if($_G['cache']['plugin']['aljtc']['ck_ad']) { ?>
<div class="wx-index__find">
    <ul class="find__list">
        <?php $ck_ads = array_filter(explode("\n", trim($_G['cache']['plugin']['aljtc'][ck_ad])));?>        <?php if(is_array($ck_ads)) foreach($ck_ads as $ck_ad_v) { ?>        <?php list($_font1, $_font2, $_icon, $_link, $_color)= explode("|", trim($ck_ad_v));?>        <li class="find__item" <?php if($_color) { ?>style="background-color:<?php echo $_color;?>"<?php } ?>>
            <a href="<?php echo $_link;?>"> 
                <img class="item__thumb" src="<?php echo $_icon;?>" >
                <div class="item__entry">
                    <p class="entry__title"><?php echo $_font1;?></p>
                    <p class="entry__subtitle"><?php echo $_font2;?></p>
                </div>
            </a>
        </li>
        <?php } ?>
    </ul>
</div>
<?php } ?>

