<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('yes_header');?>
<?php if(!$_GET['act'] &&  ($_GET['id'] == 'aljbd' || $_GET['id'] == 'aljbd:aljbd' || !$_GET['id']) && $_G['cache']['plugin']['aljbd']['sj_index_lz']) { include template('aljbd:header/common_header_index'); } elseif((($_GET['act'] == 'goodview' && $_GET['op'] != 'expose_detail') || $_GET['act'] == 'view')) { include template('aljbd:header/common_header'); } elseif($_GET['act']!='user' && $_GET['id'] != 'aljspt' && $_GET['id'] != 'aljstg' && $_GET['id'] != 'aljshd' && $_GET['id'] != 'aljbd:so') { ?>
<style>
    .header{
        position: fixed !important;
        width: 100%;
        top: 0px;
        z-index: 999 !important;
    }
    .null_header{height:44px;}
    .tab-nav,.weui-navbar{top:44px !important;}
</style>
<header>
    <div class="null_header"></div>
    <div class="header" >
        <?php if($_GET['act'] || $_GET['id'] == 'aljgwc' || $_GET['id'] == 'aljbzj' || $_GET['id'] == 'aljms' || $_GET['id'] == 'aljskm' || $_GET['a'] || $_GET['id'] == 'aljsd') { ?>
            <a class="header-left" href="javascript:;" >
                <?php if($settings['mobilenavbackcolor']['value']) { ?>
                <img src="source/plugin/aljbd/images/header/mobile/back.png" width="22/">
                <?php } else { ?>
                <img src="source/plugin/aljbd/images/sj/deta_06.png" width="12/">
                <?php } ?>
            </a>
        <?php } ?>
        <p class="header-title" style="color:<?php if($settings['header_font_color']['value']) { ?><?php echo $settings['header_font_color']['value'];?><?php } else { ?>#333;<?php } ?>">
            <?php if($_GET['act'] == 'dianpu') { ?>
            商家列表
            <?php } elseif($_GET['a'] == 'couponList' ) { ?>
            &#25105;&#30340;&#20248;&#24800;&#21048;
            <?php } elseif($_GET['act'] == 'view' ) { ?>
            <?php echo $aljbdlang['template']['Business_details'];?>
            <?php } elseif($_GET['act'] == 'goodview' ) { ?>
            <?php if($_GET['op'] == 'expose_list') { ?>
            <?php echo $aljbdlang['template']['Commodity_review'];?>
            <?php } elseif($_GET['op'] == 'expose_detail') { ?>
            <?php echo $aljbdlang['template']['Comment_details'];?>
            <?php } else { ?>
            <?php echo $aljbdlang['template']['Product_details'];?>
            <?php } ?>
            <?php } elseif($_GET['act'] == 'trade' ) { ?>
            <?php echo $aljbdlang['template']['Commodity_purchase'];?>
            <?php } elseif($_GET['act'] == 'addr' ) { ?>
            <?php echo $aljbdlang['template']['Receipt_address'];?>
            <?php } elseif($_GET['act'] == 'user' ) { ?>
            <?php echo $aljbdlang['template']['User_center'];?>
            <?php } elseif($_GET['act'] == 'nlist' ) { ?>
            <?php echo $aljbdlang['template']['Activity_list'];?>
            <?php } elseif($_GET['act'] == 'member' || $_GET['act'] == 'yes') { ?>
            <?php echo $aljbdlang['template']['Business_management'];?>
            <?php } elseif($_GET['act'] == 'appointment_list' ) { ?>
            <?php echo $aljbdlang['template']['Booking_Management'];?>
            <?php } elseif($_GET['act'] == 'appointment_view' ) { ?>
            <?php echo $aljbdlang['template']['Booking_details'];?>
            <?php } elseif($_GET['act'] == 'goodslist' ) { ?>
            <?php echo $aljbdlang['template']['Commodity_management'];?>
            <?php } elseif($_GET['act'] == 'orderlist' ) { ?>
            <?php echo $aljbdlang['template']['Order_management'];?>
            <?php } elseif($_GET['act'] == 'settlelist' ) { ?>
            <?php echo $aljbdlang['template']['Settlement_management'];?>
            <?php } elseif($_GET['act'] == 'settle' ) { ?>
            <?php echo $aljbdlang['template']['Application_for_settlement'];?>
            <?php } elseif($_GET['act'] == 'noticelist' ) { ?>
            <?php echo $aljbdlang['template']['Activity_management'];?>
            <?php } elseif($_GET['act'] == 'consumelist' ) { ?>
            <?php echo $aljbdlang['template']['Coupon_management'];?>
            <?php } elseif($_GET['act'] == 'consumeview' ) { ?>
            <?php echo $aljbdlang['template']['Coupon_details'];?>
            <?php } elseif($_GET['act'] == 'noticeview' ) { ?>
            <?php echo $aljbdlang['template']['Event_details'];?>
            <?php } elseif($_GET['act'] == 'albumview' ) { ?>
            <?php echo $aljbdlang['template']['Photo_album'];?>
            <?php } elseif($_GET['act'] == 'fl' ) { ?>
            <?php echo $aljbdlang['template']['Classification_list'];?>
            <?php } elseif($_GET['act'] == 'dq' ) { ?>
            <?php echo $aljbdlang['template']['Area_list'];?>
            <?php } elseif($_GET['act'] == 'comment' ) { ?>
            <?php echo $aljgwclang['template']['Comment_commodity'];?>
            <?php } elseif($_GET['act'] == 'wuliu' ) { ?>
            &#21457;&#36135;
            <?php } elseif($_GET['act'] == 'viewaddr' ) { ?>
            &#25910;&#36135;&#22320;&#22336;
            <?php } elseif($_GET['act'] == 'dianping' ) { ?>
            <?php echo $aljbdlang['template']['Comment_merchant'];?>
            <?php } elseif($_GET['act'] == 'goods' ) { ?>
            商品列表
            <?php } elseif($_GET['act'] == 'alist' ) { ?>
            相册
            <?php } else { ?>
                <?php echo $title?$title:$navtitle?>            <?php } ?>
        </p>
        <?php if($_GET['act'] == 'goodview' || $_GET['act'] == 'view' || $_GET['act'] == 'buy') { ?>
        <div class="header-right">
            <link href="source/plugin/aljbd/images/sj/dian.css" type="text/css" rel="styleSheet" >
            <?php if($settings['mobilenavbackcolor']['value']) { ?>
            <style>.w-headMenu{background:url(source/plugin/aljbd/template/touch/view/bdian.png) no-repeat center center;background-size: 22px 22px;}</style>
            <?php } ?>
            <a class="w-headMenu show-w-headMenu" id="w-headMenu"></a>

        </div>
        <?php } elseif($_GET['act'] == 'dianpu' || $_GET['act'] == 'goods' || $_GET['a'] == 'goods') { ?>
        <div class="header-right">
            <?php if($_GET['a'] == 'goods') { ?>
            <a class="w-headMenu" href="plugin.php?id=aljtsc&amp;c=aljtsc&amp;a=search">
            <?php } else { ?>
            <a class="w-headMenu" href="plugin.php?id=aljbd&amp;act=search">
            <?php } ?>
                <?php if($settings['mobilenavbackcolor']['value']) { ?>
                <img src="source/plugin/aljbd/images/header/mobile/search.png" width="20/">
                <?php } else { ?>
                <img src="source/plugin/aljbd/images/sj/search_v.png" width=20/>
                <?php } ?>
            </a>
        </div>
        <?php } ?>
    </div>
    <style>
        .menu-list {
            top: 55px;
            z-index: 51;
            right:12px;
            position: fixed;
        }
    </style>
    <?php include template('aljbd:common/common_dian'); ?></header>
<?php } ?>