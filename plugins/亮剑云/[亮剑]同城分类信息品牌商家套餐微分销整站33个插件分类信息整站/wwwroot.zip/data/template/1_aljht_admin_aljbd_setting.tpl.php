<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template('aljht:admin/iframe_header_common'); ?><style>
    td, input, textarea, select {
        color: #555;
        font: 12px "Lucida Grande", Verdana, Lucida, Helvetica, Arial, 'Simsun', sans-serif !important;
    }
    .td27 {
        font-weight: 700 !important;
    }
</style>
<div class="content-wrapper">
    <section class="content">
        <div class="row">
            <?php if($_GET['ajax'] != 'yes') { ?>
            <?php include template('aljht:admin/aljbd/aljbd_status'); ?>            <?php } ?>
            <div class="<?php if($_GET['ajax'] != 'yes') { ?>col-md-10<?php } else { ?>col-md-12<?php } ?>" style="padding-left: 0px;">
                <?php if($_GET['ajax'] != 'yes') { ?>
                <div class="col-md-12">
                    <ul class="nav nav-tabs" role="tablist" >
                        <?php if(is_array($statusarray)) foreach($statusarray as $sk => $sv) { ?>                        <li <?php if((!$_GET['status'] && $sv=='index')||$_GET['status'] == $sv) { ?>class="active"<?php } ?>><a href="<?php echo $dourl;?>&status=<?php echo $sv;?>"><?php echo $statustextarray[$sk];?></a></li>
                        <?php } ?>

                    </ul>
                </div>
                <?php } ?>
                <div class="col-md-12">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <ul id="tipslis">
                                <li><b style="color:red;">设置中的设置项统一到常用设置中，方便查找设置项</b></li>
                                <li><b style="color:red;">插件设置中的设置依然是有效果的，如果这里做了设置将会覆盖插件设置项中的设置</b></li>
                                <li><b>如果您对设置项有不了解的地方，欢迎您直接QQ联系亮剑客服1919080885，我们将竭诚为您服务</b></li>
                                <li>品牌商家教程<a href="http://docs.liangjianyun.com/flow/" target="_blank">http://docs.liangjianyun.com/flow/</a></li>
                                <li>文本框双击输入框可扩大/缩小</li>
                            </ul>
                            <!-- /.box-tools -->
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body no-padding">
                            <div class="table-responsive mailbox-messages" >
                                <iframe style="display:none;" name="submitiframe"></iframe>
                                <form name="cpform" enctype="multipart/form-data" id="admingoodssubmit" method="post" autocomplete="off" action="<?php echo $dourl;?>&page=<?php echo $_GET['page'];?>&username=<?php echo $_GET['username'];?>&phone=<?php echo $_GET['phone'];?>" target="submitiframe">
                                    <input type="hidden"  value="0" name="sign" id="sign">
                                    <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>">
                                <table class="table table-hover table-striped">
                                    <tbody>
                                    <?php include template($pluginid.':admin/'.$op.'/setting/'.$status);?>                                    </tbody>
                                </table>
                                <!-- /.table -->
                            <!-- /.mail-box-messages -->
                        <!-- /.box-body -->
                            <div class="form-group"><input type="submit" class="btn btn-submit btn-primary" value="提交"></div>
                            </form>
                            </div>
                        </div>
                    </div>
                    <!-- /. box -->
                </div>
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
</div>
<script>
    function color_add_text(cid,tid) {
        $('#'+tid).val($('#'+cid).val());
    }
    function text_add_color(tid,cid) {
        $('#'+cid).val($('#'+tid).val());
    }

    $('.btn-submit').click(function(){
        $('#sign').val($(this).attr('data-id'));
        var index = layer.load(0, {shade: false});
    });
    function tips(info,url){
        layer.closeAll('loading');
        if(info == 0){
            layer.alert('<?php echo $aljhtlang['js']['brand_6'];?>', {icon: 6},function(){
                location.href=location.href;
            });
        }else{
            if(url){
                layer.alert(info, {icon: 6},function(){
                    location.href=url;
                });
            }else{
                layer.msg(info);
            }
        }
    }
    var BROWSER = {};
    var USERAGENT = navigator.userAgent.toLowerCase();
    browserVersion({'ie':'msie','firefox':'','chrome':'','opera':'','safari':'','mozilla':'','webkit':'','maxthon':'','qq':'qqbrowser','rv':'rv'});
    if(BROWSER.safari || BROWSER.rv) {
        BROWSER.firefox = true;
    }
    BROWSER.opera = BROWSER.opera ? opera.version() : 0;

    HTMLNODE = document.getElementsByTagName('head')[0].parentNode;
    if(BROWSER.ie) {
        BROWSER.iemode = parseInt(typeof document.documentMode != 'undefined' ? document.documentMode : BROWSER.ie);
        HTMLNODE.className = 'ie_all ie' + BROWSER.iemode;
    }
    var heightag = BROWSER.chrome ? 4 : 0;
    function textareakey(obj, event) {
        if(event.keyCode == 9) {
            insertunit(obj, '\t');
            doane(event);
        }
    }
    function browserVersion(types) {
        var other = 1;
        for(i in types) {
            var v = types[i] ? types[i] : i;
            if(USERAGENT.indexOf(v) != -1) {
                var re = new RegExp(v + '(\\/|\\s|:)([\\d\\.]+)', 'ig');
                var matches = re.exec(USERAGENT);
                var ver = matches != null ? matches[2] : 0;
                other = ver !== 0 && v != 'mozilla' ? 0 : other;
            }else {
                var ver = 0;
            }
            eval('BROWSER.' + i + '= ver');
        }
        BROWSER.other = other;
    }
    function textareasize(obj, op) {
        if(!op) {
            if(obj.scrollHeight > 70) {
                obj.style.height = (obj.scrollHeight < 300 ? obj.scrollHeight - heightag: 300) + 'px';
                if(obj.style.position == 'absolute') {
                    obj.parentNode.style.height = (parseInt(obj.style.height) + 20) + 'px';
                }
            }
        } else {
            if(obj.style.position == 'absolute') {
                obj.style.position = '';
                obj.style.width = '';
                obj.parentNode.style.height = '';
            } else {
                obj.parentNode.style.height = obj.parentNode.offsetHeight + 'px';
                obj.style.width = BROWSER.ie > 6 || !BROWSER.ie ? '90%' : '600px';
                obj.style.position = 'absolute';
            }
        }
    }
</script>
<link rel="stylesheet" href="source/plugin/<?php echo $pluginid;?>/js/combo.select.css">
<script src="source/plugin/<?php echo $pluginid;?>/js/jquery.combo.select.js" type="text/javascript"></script>
<style>
.combo-dropdown li {
    float: none;
}
</style>
<script>
$(function() {
    $('select').comboSelect();
});
</script><?php include template($pluginid.':admin/footer')?>