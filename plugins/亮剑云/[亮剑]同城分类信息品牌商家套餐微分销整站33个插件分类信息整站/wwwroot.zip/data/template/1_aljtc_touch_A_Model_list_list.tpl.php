<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('list');?><?php include template('aljtc:A_Model/header'); ?><style>
.nav_filter_l a.on {
    color: <?php if($color) { ?><?php echo $color;?><?php } else { ?>#f42424<?php } ?> !important;
}
::-webkit-scrollbar {
    display: none;
}
</style>

<body>
<main class="indexcontent">
<div class="list_nav_l" >
    <ul class="nav_filter_l">
        <li>
            <a class="spot_l" href="javascript:;">
            	<?php if($_GET['subsubrid']) { ?>
            		<?php echo $regions[$_GET['subsubrid']]['subject'];?>
            	<?php } else { ?>
            	<?php if($_GET['subrid']) { ?>
            		<?php echo $regions[$_GET['subrid']]['subject'];?>
            	<?php } elseif($_GET['rid']) { ?>
            		<?php echo $regions[$_GET['rid']]['subject'];?>
            	<?php } else { ?>
            		地区
            	<?php } ?>
            	<?php } ?>
            </a>
<ul class="aclist_l hide_l region_l">
<li><a  href="<?php echo getaljurl($geturl,array('rid'=>'','subrid'=>'','subsubrid'=>''));?>">全部</a></li><?php if(is_array($rs)) foreach($rs as $r) { ?><li>
<a <?php if($r['id'] == $_GET['rid']) { ?>class="on"<?php } ?> <?php if(C::t('#'.$pluginid.'#'.$pluginid.'_region')->fetch_all_by_upid($r['id'])) { ?>onclick="region_1(<?php echo $r['id'];?>,this)" href="javascript:;"<?php } else { ?>href="<?php echo getaljurl($geturl,array('rid'=>$r['id']));?>"<?php } ?> <?php if($r['id'] == $_GET['rid']) { ?>class="on"<?php } ?>><?php echo $r['subject'];?><?php if(C::t('#'.$pluginid.'#'.$pluginid.'_region')->fetch_all_by_upid($r['id'])) { ?><b></b><?php } ?></a>
</li>
<?php } ?>
</ul>
<div id="aclist_l_sub" >
<?php if($_GET['subrid']) { ?>
<style type="text/css">
.aclist_l_sub{left:50%;border-left:1px solid #f0f0f0;width:51%}
.region_l{width:51%}
</style>
<ul class="aclist_l aclist_l_sub hide_l"><?php $subregion = DB::fetch_first('select * from %t where id=%d',array('aljtc_region',$_GET['subrid']))?><?php $upregion = DB::fetch_all('select * from %t where upid=%d',array('aljtc_region',$subregion['upid']))?><?php $tupregion = DB::fetch_all('select * from %t where upid=%d',array('aljtc_region',$_GET['subrid']))?><?php if(is_array($upregion)) foreach($upregion as $tmp_key => $tmp_value) { if($tupregion) { ?>
<li><a <?php if($tmp_value['id'] == $_GET['subrid']) { ?>class="on"<?php } ?> onclick="subregion_1(<?php echo $tmp_value['id'];?>,<?php echo $subregion['upid'];?>)" href="javascript:;"><?php echo $tmp_value['subject'];?><b></b></a></li>
<?php } else { ?>
<li><a <?php if($tmp_value['id'] == $_GET['subrid']) { ?>class="on"<?php } ?> href="plugin.php?id=aljtc&amp;act=list&amp;rid=<?php echo $subregion['upid'];?>&amp;subrid=<?php echo $tmp_value['id'];?>"><?php echo $tmp_value['subject'];?></a></li>
<?php } } ?>
</ul>
<?php } ?>

</div>
<div id="aclist_l_subsub" >
<?php if($_GET['subrid'] && $tupregion) { ?>
<style type="text/css">
.aclist_l_sub{left:33%;width:34%}
.aclist_l_subsub{left:66%;right:0;border-left:1px solid #f0f0f0;width:34%}
.region_l{width:34%}
</style>
<ul class="aclist_l aclist_l_subsub hide_l"><?php if(is_array($tupregion)) foreach($tupregion as $tmp_key => $tmp_value) { ?><li><a <?php if($tmp_value['id'] == $_GET['subsubrid']) { ?>class="on"<?php } ?> href="plugin.php?id=aljtc&amp;act=list&amp;subsubrid=<?php echo $tmp_value['id'];?>&amp;rid=<?php echo $subregion['upid'];?>&amp;subrid=<?php echo $_GET['subrid'];?>"><?php echo $tmp_value['subject'];?></a></li>
<?php } ?>
</ul>
<?php } ?>

</div>
        </li>
        <li>
<a class="spot_l" href="javascript:;">
<?php if($_GET['subsubtype']) { ?>
<?php echo $pos_all[$_GET['subsubtype']]['subject'];?>
<?php } elseif($_GET['subtype']) { ?>
<?php echo $pos_all[$_GET['subtype']]['subject'];?>
<?php } elseif($_GET['zufangtype']) { ?>
<?php echo $pos_all[$_GET['zufangtype']]['subject'];?>
<?php } else { ?>
类型
<?php } ?>
</a>
            <ul class="aclist_l hide_l type_l">
                <li>
                	<a href="<?php echo getaljurl($geturl,array('zufangtype'=>'','subtype'=>'','subsubtype'=>''));?>">
                		全部
                	</a>
                </li><?php if(is_array($gtypes)) foreach($gtypes as $typeid => $type) { ?><li>
<a <?php if(C::t('#'.$pluginid.'#'.$pluginid.'_position')->fetch_all_by_upid($typeid)) { ?>onclick="type_1(<?php echo $type['id'];?>)" href="javascript:;"<?php } else { ?>href="<?php echo getaljurl($geturl,array('zufangtype'=>$typeid));?>"<?php } ?> <?php if($type['id'] == $_GET['zufangtype']) { ?>class="on"<?php } ?>><?php echo $type['subject'];?><?php if(C::t('#aljtc#aljtc_position')->fetch_all_by_upid($typeid)) { ?><b></b><?php } ?></a> </li>
<?php } ?>
            </ul>
<div id="aclist_l_subtype" >
<?php if($_GET['zufangtype']>0) { $subtype = C::t('#'.$pluginid.'#'.$pluginid.'_position')->fetch_all_by_upid($_GET['zufangtype']);?><?php if($subtype) { ?>
<style type="text/css">
.aclist_l_subtype{left:50%;border-left:1px solid #f0f0f0;width:51%}
.type_l{width:51%}
</style>
<ul class="aclist_l aclist_l_subtype hide_l">
<li><a href="<?php echo getaljurl($geturl,array('subtype'=>'','subsubtype'=>''));?>">全部</a></li><?php if(is_array($subtype)) foreach($subtype as $subt) { ?><li>
<a <?php if($subt['id'] == $_GET['subtype']) { ?>class="on"<?php } ?> <?php if(C::t('#aljtc#aljtc_position')->fetch_all_by_upid($subt['id'])) { ?>onclick="subtype_1(<?php echo $subt['id'];?>,<?php echo $_GET['zufangtype'];?>)" href="javascript:;"<?php } else { ?>href="<?php echo getaljurl($geturl,array('subtype'=>$subt['id']));?>"<?php } ?>><?php echo $subt['subject'];?><?php if(C::t('#aljtc#aljtc_position')->fetch_all_by_upid($subt['id'])) { ?><b></b><?php } ?></a></li>
<?php } ?>
</ul>
<?php } } ?>
</div>
<div id="aclist_l_subsubtype" >
<?php if($_GET['subtype']>0) { $subsubtype = C::t('#'.$pluginid.'#'.$pluginid.'_position')->fetch_all_by_upid($_GET['subtype']);?><?php if($subsubtype) { ?>
<style type="text/css">
.aclist_l_subtype{left:33%;width:34%}
.aclist_l_subsubtype{left:66%;right:0;border-left:1px solid #f0f0f0;width:34%}
.type_l{width:34%}
</style>
<ul class="aclist_l aclist_l_subsubtype hide_l">
<li><a  href="<?php echo getaljurl($geturl,array('subsubtype'=>''));?>">全部</a></li><?php if(is_array($subsubtype)) foreach($subsubtype as $subsubt) { ?><li><a <?php if($subsubt['id'] == $_GET['subsubtype']) { ?>class="on"<?php } ?> href="<?php echo getaljurl($geturl,array('subsubtype'=>$subsubt['id']));?>"><?php echo $subsubt['subject'];?></a></li>
<?php } ?>
</ul>
<?php } } ?>
</div>
        </li>
       <li>
       		<a class="spot_l" href="javascript:;">
<?php if($_GET['order'] == 'new') { ?>
最新				
<?php } elseif($_GET['order'] == 'hot') { ?>
最热
<?php } elseif($_GET['order'] == 'lbs') { ?>
附近
<?php } elseif($_GET['order'] == 'notfinish') { ?>
未完成
<?php } else { ?>
排序
<?php } ?>

</a>
            <ul class="aclist_l hide_l">
<li><a href="<?php echo getaljurl($geturl,array('order'=>''));?>">全部</a></li>
<?php if($_G['cache']['plugin']['aljtsq']) { ?>
<li>
<a href="<?php echo getaljurl($geturl,array('order'=> 'lbs'));?>">附近</a> 
</li>
<?php } ?>
<li>
<a href="<?php echo getaljurl($geturl,array('order'=> 'new'));?>">最新</a> 
</li>
<li>
<a href="<?php echo getaljurl($geturl,array('order'=> 'hot'));?>">最热</a> 
</li>
<li>
<a href="<?php echo getaljurl($geturl,array('order'=> 'notfinish'));?>">未完成</a> 
</li>
            </ul>
        </li>
</ul>
<?php if($subtype || $subsubtype) { ?>
<style>
.tab-reply-center{
-webkit-flex-shrink: 0;
-ms-flex: 0 0 auto;
flex-shrink: 0;
width: auto;
height: 100%;
position: relative;
margin: 0px 10px;
    }
    .tab-reply{
        text-align: center;
        color: #999999;
        background: #f2f2f7;
        border-radius: 15px;
padding:4px 10px;
font-size: 14px;
    }
    .cur .tab-reply{
        color: #ffffff;
        background: <?php if($color) { ?><?php echo $color;?><?php } else { ?>#f42424<?php } ?>;
    }
.type_text{
position: relative;
width: 100%;
height: 46px;
line-height: 46px;
overflow: hidden;
overflow-x: scroll;
-webkit-overflow-scrolling: touch;
padding-left: 15px;
display: -webkit-box;
display: -webkit-flex;
display: flex;
}
</style>

<?php if($subsubtype) { ?>
<div class="type_text">
<div class=" tab-reply-center <?php if(!$_GET['subsubtype']) { ?>cur<?php } ?>" >
<a class="tab-reply"  href="<?php echo getaljurl($geturl,array('subsubtype'=>''));?>">全部</a>
</div><?php if(is_array($subsubtype)) foreach($subsubtype as $subtypev) { ?><div class=" tab-reply-center <?php if($subtypev['id'] == $_GET['subsubtype']) { ?>cur<?php } ?>" >
<a class="tab-reply"  href="<?php echo getaljurl($geturl,array('subsubtype'=>$subtypev['id']));?>"><?php echo $subtypev['subject'];?></a>
</div>
<?php } ?>
</div>

<?php } else { ?>
<div class="type_text">
<div class=" tab-reply-center <?php if(!$_GET['subtype']) { ?>cur<?php } ?>" >
<a class="tab-reply"  href="<?php echo getaljurl($geturl,array('subtype'=>'','subsubtype'=>''));?>">全部</a>
</div><?php if(is_array($subtype)) foreach($subtype as $subtypev) { ?><div class=" tab-reply-center <?php if($subtypev['id'] == $_GET['subtype']) { ?>cur<?php } ?>" >
<a class="tab-reply" href="<?php echo getaljurl($geturl,array('subtype'=>$subtypev['id']));?>"><?php echo $subtypev['subject'];?></a>
</div>
<?php } ?>
</div>
<?php } ?>
<script type="text/javascript">
            //��ȡѡ��Ԫ��
            $(function(){
                var scrollLeftCur = $('.type_text .cur');
                $(".type_text").animate({scrollLeft:scrollLeftCur.position().left-100},300);
            })
            
            </script>
<?php } ?>
</div>
<?php if($subtype || $subsubtype) { ?>
<style>
.list_nav_l{height:86px;}
</style>
<div style="height:86px"></div>
<?php } else { ?>
<div style="height:40px"></div>
<?php } ?>
<div id="mask_l" style="display: none;"></div>
<div class="datacontent">
</div>
<div class="weui-loadmore" id="load" style="display: none;">
    <i class="weui-loading"></i>
    <span class="weui-loadmore__tips bcf8">正在加载</span>
</div>
<div class="weui-loadmore weui-loadmore_line" id="loaded"style="display: none;">
  	<span class="weui-loadmore__tips bcf8">暂无数据</span>
</div>
<div id="empty" style="display: none;">
<div class="empty_data"></div>
<div class="empty_title">
<p>找不到相关内容</p>
</div>
</main>
<div class="swiper-container1" style="display: none">
<div class="swiper-wrapper swiper-wrapper12545">

</div>
 <div class="swiper-pagination"></div>
</div><?php include template('aljtc:A_Model/footer'); ?></body><?php $region_l_url = getaljurl($geturl,array('act'=>'mobile_list_region','rid'=>'','subrid'=>'','subsubrid'=>''))?><?php $type_l_url = getaljurl($geturl,array('act'=>'mobile_list_type','zufangtype'=>'','subtype'=>'','subsubtype'=>''))?><?php $ajax_url = getaljurl($geturl,array('act'=>'mobile_index_goods'))?><script>
$(function () {
    var isload = {};
    $('.spot_l').click(function(){
$('.list_nav_l').addClass('pos_l');
        $('.aclist_l').addClass('hide_l');
        var pf = $(this).parent().find('ul');
        var status = $('.spot_l').index($(this));
        if(!isload[status]){
            pf.removeClass('hide_l');
$('.list_nav_l').addClass('pos_l');
$('.type_text').addClass('hide_l');
            $('#mask_l').show();
isload = {};
            isload[status] = 1;
        }else{
            pf.addClass('hide_l');
$('.list_nav_l').removeClass('pos_l');
$('.type_text').removeClass('hide_l');
            $('#mask_l').hide();
isload = {};
            isload[status] = 0;
        }
    });
    $('#mask_l').click(function () {
        $('.aclist_l').addClass('hide_l');
        $('.type_text').removeClass('hide_l');
$('.list_nav_l').removeClass('pos_l');
        $('#mask_l').hide();
        isload = {};
    });

});
function region_1(rid){
$("#aclist_l_sub").html('<ul class="aclist_l " style="left:50%"><img src="static/image/common/loading.gif" /></ul>');
$("#aclist_l_subsub").html('');

$.post('<?php echo $region_l_url;?>',{"rid":rid},function(data){
$("#aclist_l_sub").html(data);
});
}
function subregion_1(rid,subrid){
$("#aclist_l_subsub").html('<ul class="aclist_l " style="left:80%"><img src="static/image/common/loading.gif" /></ul>');

$.post('<?php echo $region_l_url;?>',{"rid":rid,'sub':'1','subrid':subrid},function(data){
$("#aclist_l_subsub").html(data);
});
}
function type_1(type){
$("#aclist_l_subtype").html('<ul class="aclist_l " style="left:50%"><img src="static/image/common/loading.gif" /></ul>');
$("#aclist_l_subsubtype").html('');

$.post('<?php echo $type_l_url;?>',{"zufangtype":type},function(data){
$("#aclist_l_subtype").html(data);
});
}
function subtype_1(type,subtype){
$("#aclist_l_subsubtype").html('<ul class="aclist_l " style="left:80%"><img src="static/image/common/loading.gif" /></ul>');

$.post('<?php echo $type_l_url;?>',{"zufangtype":type,'sub':'1','subtype':subtype},function(data){
$("#aclist_l_subsubtype").html(data);
});
}
var page = 1;
var loading = false;
$(document.body).infinite(100).on("infinite", function() {
  if(loading) return;
  $('#load').show();
  page++;
  loading = true;
  getdata(page);
});
function getdata(page) {
var data ={
'page':page
}
var url = '<?php echo $ajax_url;?>';
$.post(url,data,function(res) {
if(page == 1) {
if(res != 1) {
loading = false;
$('#load').hide();
$('.content').append(res);
$('.datacontent').append(res);
}else {
$('#load').hide();
$('#loaded').hide();
$('#empty').show();
loading = true;	
}
}else {
if(res != 1) {
loading = false;
$('#load').hide();
$('.datacontent').append(res);
} else {
$('#load').hide();
$('#loaded').show();
loading = true;	
}

}
});
}
getdata(page);

</script>
</html>