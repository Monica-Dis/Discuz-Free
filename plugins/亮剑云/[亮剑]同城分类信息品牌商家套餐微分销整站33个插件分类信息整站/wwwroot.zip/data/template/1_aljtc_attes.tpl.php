<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div class="itemtitle">

<ul class="tab1">
<li <?php if(!$_GET['act']) { ?>class="current"<?php } ?>><a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=<?php echo $pluginid;?>&do=<?php echo $_GET['do'];?>&pmod=attes"><span>待审</span></a></li>
<li <?php if($_GET['act']=='yes') { ?>class="current"<?php } ?>><a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=<?php echo $pluginid;?>&do=<?php echo $_GET['do'];?>&pmod=attes&act=yes"><span>已审</a></li>
</ul>

</div>
