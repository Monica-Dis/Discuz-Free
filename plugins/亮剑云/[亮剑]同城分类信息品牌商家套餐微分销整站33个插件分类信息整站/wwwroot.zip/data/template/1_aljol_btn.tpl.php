<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<style>
.menulist{
position: fixed;
    z-index: 999999999;
    width: 40px;
    height: 40px;
<?php if($_GET['act'] == 'talk') { ?>
bottom: 100px;
<?php } else { ?>
    bottom: 60px;
<?php } ?>
    right: 15px;
    border: 1px solid rgba(0,0,0,0.1);
    -moz-border-radius: 60px;
    -webkit-border-radius: 60px;
    border-radius: 60px;
background-color:rgba(255,255,255,1);
}
.menulist ul li {
    width: 40px;
    height: 40px;
    line-height: 40px;
    text-align: center;
    position: absolute;
    overflow: hidden;
background-color:rgba(255,255,255,0);
}
.tab1{
background:url(source/plugin/aljol/static/img/icon1.png) no-repeat center;
background-size:20px 20px;
background-color: rgba(255, 255, 255, 0);
border-radius: 20px;
left: 0px;
    top: 0px;
}
.tab2{
background:url(source/plugin/aljol/static/img/icon2.png) no-repeat center;
background-size:20px 20px;
background-color: rgba(255, 255, 255, 0);
border-radius: 20px;
}
.q1{
left: 40px;
    top: 0px;
background:url(source/plugin/aljol/static/img/icon3.png) no-repeat center;
background-size:28px 28px;
}
.q2{
left: 0px;
    top: 40px;
background:url(source/plugin/aljol/static/img/icon4.png) no-repeat center;
background-size:28px 28px;
}
.q3{
left: 40px;
    top: 80px;
background:url(source/plugin/aljol/static/img/icon6.png) no-repeat center;
background-size:27px 27px;
}
.q4{
left: 80px;
    top: 40px;
background:url(source/plugin/aljol/static/img/icon5.png) no-repeat center;
background-size:27px 27px;
}
</style>
<section class="menulist" id="menu">
<ul>
<li class="qc q1 cm" style="display:none;" onclick="$(window).scrollTop(0);"></li>
<li class="qc q2 cm" style="display:none;" onclick="javascript:history.back(-1);"></li>
<li class="tab1" onclick="showmenu();"></li>
<li class="qc q3 cm" style="display:none;" onclick="location.reload()" ></li>
<li class="qc q4 cm" style="display:none;" onclick="location.href='plugin.php?id=aljol'"></li>
</ul>
</section>
  <script>

  function showmenu(){
if($('#menu').hasClass("open")){
$('#menu').removeClass('open');
$('#menu li.qc').hide();
$('#menu').animate({width:40,height:40}, 150);
$('#menu li.tab1').css({'background-color':'rgba(255,255,255,0)'});
$('#menu li.tab1').removeClass('tab2');
$(' #menu li.tab1').animate({left:0,top:0}, 150);
$('#menu').css({'background-color':'none'});

}else{
$('#menu').addClass('open');
$('#menu li.qc').fadeIn();
$('#menu').animate({width:120,height:120}, 150,function(){$('#menu li.qc').fadeIn();});
$('#menu li.tab1').css({'background-color':'#cdcdcd'});
$('#menu li.tab1').addClass('tab2');
$('#menu li.tab1').animate({left:40,top:40}, 150);
$('#menu').css({'background-color':'rgba(255,255,255,1)'});
}
}
  </script>
