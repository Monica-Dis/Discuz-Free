<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>


    
<style>
.floor-container{width:100%;height:100%;overflow:hidden;font-size:0;margin-top: -10px;}.floor-container img{width:100%;height:auto;overflow:hidden}.flsPit{height:auto;background-color:#ffffff;padding:0px 5px;}.floor-graphic-item{width:100%;background:#fff;font-size:100%;overflow:hidden}.graphic-col04-bg,.graphic-col04-sm{position:relative;width:25%;float:left}.graphic-col04-bg{height:auto}.graphic-separation{background:#fff;position:relative;font-family:PingFangSC-Light,PingFang-Medium,PingFangSC-Regular,Helvetica,Droid Sans,Arial,sans-serif;font-size:0}.real-show,.show-img{width:100%;height:100%;overflow:hidden;}.show-img img{width:100%;height:100%}.floor-container img{width:100%;height:auto;overflow:hidden}
</style>

<div class="floor-container">
<div class="flsPit">
<div class="floor-graphic-item">

<div class="graphic-separation  graphic-col04-bg">
<a  href="<?php echo $row_four_grids_types['0']['1'];?>" class="J_ping">
<div class="show-img"><img src="<?php echo $row_four_grids_types['0']['0'];?>" class="opa1" style="opacity: 1;"></div>
</a>
</div>

<div class="graphic-separation  graphic-col04-bg">
<a  href="<?php echo $row_four_grids_types['1']['1'];?>" class="J_ping">
<div class="show-img"><img src="<?php echo $row_four_grids_types['1']['0'];?>" class="opa1" style="opacity: 1;"></div>
</a>
</div>

<div class="graphic-separation  graphic-col04-bg">
<a  href="<?php echo $row_four_grids_types['2']['1'];?>" class="J_ping">
<div class="show-img"><img src="<?php echo $row_four_grids_types['2']['0'];?>" class="opa1" style="opacity: 1;"></div>
</a>
</div>


<div class="graphic-separation  graphic-col04-bg">
<a  href="<?php echo $row_four_grids_types['3']['1'];?>" class="J_ping">
<div class="show-img"><img src="<?php echo $row_four_grids_types['3']['0'];?>" class="opa1" style="opacity: 1;"></div>
</a>
</div>

</div>
</div>
</div>
