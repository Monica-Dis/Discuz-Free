<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<tr ><th class="partition" colspan="15" >&#35814;&#24773;&#39029;&#38754;&#26435;&#38480;&#35774;&#32622;</th></tr>

<tr><td colspan="2" class="td27" s="1">&#35814;&#24773;&#39029;&#24213;&#37096;&#35843;&#29992;&#20844;&#20849;&#24213;&#37096;</td></tr>
<tr class="noborder">
    <td class="vtop rowform" s="1">
        <ul onmouseover="altStyle(this);">
            <li class="checked">
                <input type="radio"  value="1"  <?php if($settings['is_viewtoindex_footer']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[is_viewtoindex_footer]" class="radio">&nbsp;&#26159;</li>
            <li><input type="radio" value="0" <?php if($settings['is_viewtoindex_footer']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[is_viewtoindex_footer]" class="radio">&nbsp;&#21542;</li>
        </ul>
        <br>
    </td>
    <td>&#24320;&#21551;&#24320;&#20851;&#35814;&#24773;&#39029;&#23558;&#35843;&#29992;&#39318;&#39029;&#30340;&#24213;&#37096;</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#35814;&#24773;&#39029;&#22768;&#26126;</td></tr>
<tr class="noborder" onmouseover="setfaq(this, 'faqd8d7')">
    <td class="vtop rowform">
<textarea rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)" name="settingsnew[shengming]"  cols="50" class="tarea">
<?php echo $settings['shengming']['value'];?>
</textarea>
    </td>
    <td class="vtop tips2" s="1"><?php echo sitename;?>=&#32593;&#31449;&#21517;&#31216;<br>&#21452;&#20987;&#36755;&#20837;&#26694;&#21487;&#25193;&#22823;&#47;&#32553;&#23567;</td>
</tr>
<tr><td colspan="2" class="td27" s="1">&#26159;&#21542;&#24320;&#21551;&#35780;&#35770;&#31449;&#20869;&#36890;&#30693;</td></tr>
<tr class="noborder">
    <td class="vtop rowform" s="1">
        <ul onmouseover="altStyle(this);">
            <li class="checked">
                <input type="radio"  value="1"  <?php if($settings['is_ping']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[is_ping]" class="radio">&nbsp;&#26159;</li>
            <li><input type="radio" value="0" <?php if($settings['is_ping']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[is_ping]" class="radio">&nbsp;&#21542;</li>
        </ul>
        <br></td>
</tr>