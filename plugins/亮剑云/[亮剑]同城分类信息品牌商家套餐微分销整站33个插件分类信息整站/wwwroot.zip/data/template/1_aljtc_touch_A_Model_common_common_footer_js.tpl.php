<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div class="swiper-container1" style="display: none">
    <div class="swiper-wrapper swiper-wrapper12545">

    </div>
    <div class="swiper-pagination"></div>
</div>
<script>
$(document).on('click', '.aljsqImg', function () {
    var imgs = '';
    $(this).parent().parent().find('img').each(function () {
        imgs += "<div class=\"swiper-slide slide1\"><div class='swiper-zoom-container'><img src=\""+$(this).attr('src')+"\"></div></div>";
    });
    $('.swiper-wrapper12545').html(imgs);
    $('.swiper-container1').show();
    aljsqImgSwiper = new Swiper('.swiper-container1', {
        pagination : '.swiper-pagination',
        paginationType: 'fraction',
        //freeMode:true,
        zoom: true,
        observer:true,
        loop:true,
    });
    aljsqImgSwiper.slideTo($(this).parent().find('.aljsqImg').index($(this))+1,0);
    return false;
});
$('.swiper-container1').click(function () {
$('.swiper-container1').hide();
aljsqImgSwiper.destroy();
return false;
});
</script>
<script>
function praise(user_id,tc_id){
    var num = $(".detail-list__"+tc_id+" .num").html();
    num = num * 1;
    $.post('plugin.php?id=aljtc&act=praise&&formhash=<?php echo FORMHASH;?>&getdata=yes',{'user_id':user_id,'lid':tc_id},function(res){
        if(res.code == '200'){
            if($('.detail-list__'+tc_id).hasClass('hide_l')){
                $('.detail-list__'+tc_id).removeClass('hide_l');
            }
            $(".detail-list__"+tc_id+" .num").html(++num);
            $(".detail-praise__"+tc_id).prepend('<span>'+res.avatar+'</span>');
            $.toast(res.msg);
        }else if(res.code == '100'){
            $.toast(res.msg, "cancel");
        }else{
            $.toast(res.msg, "cancel");
        }
    },'json')
}

function deletecomment(id,obj) {
    layer.open({
    content: '&#24744;&#30830;&#23450;&#35201;&#21024;&#38500;&#26412;&#26465;&#35780;&#35770;&#21527;&#65311;'
    ,btn: ['&#30830;&#23450;', '&#19981;&#35201;']
    ,yes: function(index){
        layer.open({type: 2});
        var url = 'plugin.php?id=<?php echo $pluginid;?>&act=deletecomment&getdata=yes&lid='+id;
        $.post(url,function(res) {
            if(res.code == 200) {
                tips(res.msg,1);
            }else {
                tips(res.msg,0);
            }
        },'json');
    }
  });
    
}
$(document).on('click', '.login_tel', function () {
    <?php if($_G['cache']['plugin']['aljtc']['is_login_tel'] && !$_G['uid']) { ?>
    location.href='member.php?mod=logging&action=login&referer='+l_href
    return false;
    <?php } ?>
    that = $(this);
    if(that.data('price')>0){
        $.confirm('\u62e8\u6253\u7535\u8bdd\u9700\u8981\u4ed8\u8d39'+that.data('price')+'\u5143', function() {
        //���ȷ�Ϻ�Ļص�����
            $.post('plugin.php?id=aljtc&act=qb_pay_tel',{'price':that.data('price'),'lid':that.data('id')},function(res){
                if(res.code == 100){
                    tips(res.text,res.url);
                }else{
                    tips(res.text);
                }
            },'json');
        });
        return false;
    }
});
$(document).on('click', '.fullText', function () {
    console.log($(this).prev().attr('data-tel'));
    if($(this).hasClass('t_open')){
        $(this).html('全文');
        $(this).prev().addClass('clamp');
        $(this).removeClass('t_open');
        $(this).prev().children("a").remove();
    }else{
        $(this).html('收起');
        $(this).addClass('t_open');
        if($(this).prev().attr('data-tel') != '1'){
            $(this).prev().append('<a  href="tel:'+$(this).prev().attr('data-tel')+'" data-id="'+$(this).prev().data('id')+'" data-price="'+$(this).prev().data('price')+'" class="weui-btn weui-btn_mini weui-btn_primary login_tel"><i class="iconfont icon-dianhua2"></i>拨打电话</a>');
        }
        $(this).prev().removeClass('clamp');
        //$(this).hide();
    }
    
    return false;
});

function showset(obj){
var menu = $(obj).prev('.menubar');
if(menu.hasClass('openright')) {
menu.removeClass('openright').addClass('openleft');
}else {
        if($('.menubar').hasClass('openright')) {
            $('.menubar').removeClass('openright').addClass('openleft');
        }
menu.removeClass('openleft').addClass('openright');
}
}
function comment(lid) {
    if(typeof lid == 'undefined' || lid == ''){
        
        lid = '<?php echo $_GET['lid'];?>';
    }else{
        var prependHtml = 1;
    }
    
layer.open({
    title: [
      '随便说点什么',
      'background-color:#fcfcfc; color:#333;font-size:14px;',
      
    ]
    ,content: '<textarea placeholder="请输入文字" class="commentarea" rows="3"></textarea>'
    ,btn: ['留言', '取消']
    ,yes: function(index){
  			$.ajax({
            url:'plugin.php?id=aljtc&act=ask&getdata=yes',
            type:'post',
            dataType:'json',
            data:{formhash:'<?php echo FORMHASH;?>',lid:lid,message:$('.commentarea').val(),upid:0},
            success:function(data){
                if(prependHtml == 1){
                    if(data.status != 1){
                        $('.comment-list__'+lid+' .comment-list').prepend("<a href='javascript:void(0);' onclick=\"reply('"+data.username+"','"+data.cid+"','"+lid+"','"+data.uid+")\"><span class='nick'>"+data.username+":</span>"+ data.content +"</a>");
      
                        if($('.detail-list__'+lid).hasClass('hide_l')){
                            $('.detail-list__'+lid).removeClass('hide_l');
                        }
                        if($('.comment-list__'+lid).hasClass('hide_l')){
                            $('.comment-list__'+lid).removeClass('hide_l');
                        }
                    }
                    
                    tips(data.tip);
                }else{
                    tips(data.tip,data.url);
                }
            },
            
        	});        
}
});

}
function reply(username,id,lid,uid,mod) {
    if(mod == 'index'){
        var prependHtml = 1;
    }
    
layer.open({
    title: [
      '回复'+username,
      'background-color:#fcfcfc; color:#333;font-size:14px;',
      
    ]
    ,content: '<textarea placeholder="请输入文字" class="commentarea" rows="3"></textarea>'
    ,btn: ['留言', '取消']
    ,yes: function(index){
  			$.ajax({
            url:'plugin.php?id=aljtc&act=ask&getdata=yes',
            type:'post',
            dataType:'json',
            data:{formhash:'<?php echo FORMHASH;?>',lid:lid,message:$('.commentarea').val(),upid:id,uid:uid,username:username},
            success:function(data){
                if(prependHtml == 1){
                    if(data.status != 1){
                        $('.comment-list__'+lid+' .comment-list').prepend("<a href='javascript:void(0);' onclick=\"reply('"+data.username+"','"+data.cid+"','"+lid+"','"+data.uid+"')\"><span class='nick'>"+data.username+"</span>&nbsp;回复&nbsp;<span class='nick'>"+username+":</span>"+ data.content +"</a>");
        
                        if($('.detail-list__'+lid).hasClass('hide_l')){
                            $('.detail-list__'+lid).removeClass('hide_l');
                        }
                        if($('.comment-list__'+lid).hasClass('hide_l')){
                            $('.comment-list__'+lid).removeClass('hide_l');
                        }
                    }
                    tips(data.tip);
                }else{
                    tips(data.tip,data.url);
                }
            },
            
        	});        
}
});

}
if (typeof tips != 'function') {
    function tips(txt, fun) {
        layer.closeAll(); //���ģʽ���ر����в�
        $.hideLoading();
        $.toast(txt, "text");
        setTimeout(function() {
            console.log(fun);
            if (typeof fun == 'function') {
                fun();
            }else if(fun == 1){
                location.href=location.href;
            }else if(fun){
                location.href=fun;
            }
        }, 2000);
    }
}
</script>
<a class="u_top" target="_self"  style="display: none;"></a>
<script>
function backTop() {
var main = $(window);
    main.scroll(function() {
        if (main.scrollTop() > (main.height() * 0.7)) {
            $(".u_top").fadeIn(500);
        } else {
           $(".u_top").fadeOut(500);
        }
        if($('.menubar').length>0){
            if($('.menubar').hasClass('openright')) {
                $('.menubar').removeClass('openright').addClass('openleft');
            }
        }
    });
    $(".u_top").click(function() {
        $('body,html').animate({
            scrollTop: 0
        }, 1000);
        return false;
    });
}
$(function() {
backTop();
});
</script>
<?php if($_G['cache']['plugin']['aljoss']['Access_Key'] && $_G['cache']['plugin']['aljtsp']['is_aljtc']) { include template('aljtsp:video_player'); ?><style>
.video_iframe{
    width: 100%;
    height: 100%;
    background: #000000
}
</style>
<?php } if(file_exists('source/plugin/mapp_share/api/api.php') && $_G['cache']['plugin']['mapp_share']) { include template('mapp_share:api'); } elseif($_G['cache']['plugin']['aljtwx']) { include template('aljtwx:share_new'); } elseif($_G['cache']['plugin']['aljwx']) { include template('aljwx:share_new'); } if($_G['cache']['plugin']['mapp_wechat']) { include_once DISCUZ_ROOT."source/plugin/mapp_wechat/touch.class.php";
echo mobileplugin_mapp_wechat::global_footer_mobile();?><?php } if($_G['cache']['plugin']['aljhtx'] && file_exists('source/plugin/aljhtx/template/touch/aljol.htm')) { include_once DISCUZ_ROOT."source/plugin/aljhtx/aljhtx.class.php";
echo mobileplugin_aljhtx::global_footer_mobile();?><?php } if($_G['cache']['plugin']['aljtsq']) { include template('aljtsq:map/map_include_api'); include template('aljtsq:map/map_location'); include template('aljtsq:map/post_map'); } if(!$diy['auto_module']) { if($_G['cache']['plugin']['aljhtx']) { include template('aljhtx:common_footer'); } } ?>