<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template('aljol:head'); ?><header class="topBar">
<ul id="header-list" style="width: 6.4rem;">
<li class="active" onclick="switch_list(1,this);">
<span>聊天</span>
</li>
<li onclick="switch_list(2,this);">
<span>联系人</span>
</li>
<?php if(!$_G['cache']['plugin']['aljol']['is_qun'] || !$_G['cache']['plugin']['aljol']['is_groupqun']) { ?>
<li onclick="switch_list(3,this);" style="padding:0px 5px">
<span>在线聊天室</span>
</li>
<?php } ?>
<!--onclick="location.href='plugin.php?id=aljol&act=talk&friendid=0';"-->
</ul>
</header>
<style>.main{height:auto !important;}</style>
<main class="main" style="overflow: hidden">
<div id="information" ><?php if(is_array($chatlist)) foreach($chatlist as $tmp_key => $tmp_value) { ?><div class="friend" onclick="friendtalk('<?php echo $tmp_value['uid'];?>');" id="f_<?php echo $tmp_value['uid'];?>" data-time="<?php echo $tmp_value['datetime'];?>" data-id="<?php echo $tmp_value['uid'];?>">
<div class="friend-head">
<?php if($tmp_value['fidicon']) { if($tmp_value['fidicon']) { ?>
<?php echo $tmp_value['fidicon'];?>
<?php } else { echo avatar($_G['uid'])?><?php } } else { echo avatar($tmp_value['uid'])?><?php } ?>
</div>
<div class="friend-name">
<div class="friend-name-left">
<p><?php if($tmp_value['username']) { ?><?php echo $tmp_value['username'];?><?php } else { ?><?php echo $_G['cache']['plugin']['aljol']['q_name'];?><?php } ?></p>
<span><?php echo $tmp_value['lastnews'];?></span>
</div>
<div class="friend-name-right">
<p><?php echo $tmp_value['time'];?></p>
<?php if($tmp_value['newscount']>0) { ?>
<i class="order-numbers"><?php echo $tmp_value['newscount'];?></i>
<?php } ?>
</div>
</div>
</div>

<?php } ?>
</div>
<div id="friend" style="display: none;">
<ul class="layim-list-top">
<li onclick="opensearch();">
<i class="iconfont icon-jwj_tianjiahaoyou"></i>添加好友
</li>
<li onclick="requestfriend();">
<i class="iconfont icon-pengyou"></i>新的朋友
</li>
</ul>
<ul class="layim-list-friend">
<li data-id="1">
<h5 ><i class="iconfont icon-you-copy-copy"></i><span>我的好友</span></h5>
<ul class="layui-layim-list close">

</ul>
</li>
<li data-id="2">
<h5 ><i class="iconfont icon-you-copy-copy"></i><span>我关注的</span></h5>
<ul class="layui-layim-list close" >

</ul>
</li>
<li data-id="3">
<h5 ><i class="iconfont icon-you-copy-copy"></i><span>关注我的</span></h5>
<ul class="layui-layim-list close" >

</ul>
</li>
</ul>
</div>
<div id="informationfid" style="display: none;">
<?php if(!$_G['cache']['plugin']['aljol']['is_qun']) { ?>
<div class="friend" onclick="location.href='plugin.php?id=aljol&act=talk&friendid=0';" >
<div class="friend-head"><?php echo avatar($_G['uid'])?></div>
<div class="friend-name">
<div class="friend-name-left">
<p><?php echo $_G['cache']['plugin']['aljol']['q_name'];?></p>
</div>
</div>
</div>
<?php } if(!$_G['cache']['plugin']['aljol']['is_groupqun']) { if(is_array($fids)) foreach($fids as $tmp_key => $tmp_value) { ?><div class="friend" onclick="location.href='plugin.php?id=aljol&act=talk&friendid=-<?php echo $tmp_value['fid'];?>&talkname=<?php echo $tmp_value['fidname'];?>';" >
<div class="friend-head">
<?php if($tmp_value['fidicon']) { ?>
<img src="<?php echo $tmp_value['fidicon'];?>">
<?php } else { echo avatar($_G['uid'])?><?php } ?>
</div>
<div class="friend-name">
<div class="friend-name-left">
<p><?php echo $tmp_value['fidname'];?></p>
</div>
</div>
</div>
<?php } } ?>
</div>
<div class="search" style="display: none;">
<section  class="search-header">
        <span class="search-text">
          <i class="iconfont icon-fanhui c" onclick="closesearch()"></i>
          <input type="text"  id="searchuser" value="" placeholder="UID/用户名">
          <button class="layui-btn" onclick="search()"><i class="iconfont icon-sousuo"></i></button>
         </span>
    	</section>
    	<section class="userlist">
    		<ul id="user">

</ul>
    	</section>
</div>
</main>
<script>
var list=$('.layim-list-friend li');
news();

var page =1;
list.each(function(){
$(this).click(function(){
var type = parseInt($(this).attr('data-id'));
var ul=$(this).find('ul');
if(ul.hasClass('open')) {
$(this).find('i').removeClass('icon-arrow_down').addClass('icon-you-copy-copy');
ul.removeClass('open').addClass('close');
}else{
$(this).find('i').removeClass('icon-you-copy-copy').addClass('icon-arrow_down');
page =1;
ul.html('');
friendlist(type,ul,1);
ul.removeClass('close').addClass('open');
$(this).siblings().find('ul').html('');
$(this).siblings().find('ul').removeClass('open').addClass('close');
$(this).siblings().find('i').removeClass('icon-arrow_down').addClass('icon-you-copy-copy');
}
});
});
function friendlist(type,ul,page) {
var url='plugin.php?id=aljol&act=friendlist&page='+page;
var data={'listtype':type};
$.post(url,data,function(res){
if(res !=null && res != '') {
$.each(res, function(k,d) {
if(d.code == 200) {
var datedom = '<li onclick="friendtalk('+d.friendid+')"><div>'+
d.head+
'</div><span>'+d.friendname+'</span>'+
'<p>'+d.sign+'</p>'+
'</li>';
ul.append(datedom);
}
});
setTimeout(function(){
page=page+1;
friendlist(type,ul,page);
}, 500);
}

},'json');
}

</script><?php include template('aljol:btn'); include template('aljol:foot'); ?>