<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<tr ><th class="partition" colspan="15" >&#35748;&#35777;&#39029;&#38754;&#26435;&#38480;&#35774;&#32622;</th></tr>
<tr><td s="1" class="td27" colspan="2">&#35748;&#35777;&#28201;&#39336;&#25552;&#31034;</td></tr>
<tr class="noborder" onmouseover="setfaq(this, 'faqd8d7')">
    <td class="vtop rowform">
<textarea rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)" name="settingsnew[r_tsy]"  cols="50" class="tarea">
<?php echo $settings['r_tsy']['value'];?>
</textarea>
    </td>
    <td class="vtop tips2" s="1">&#21452;&#20987;&#36755;&#20837;&#26694;&#21487;&#25193;&#22823;&#47;&#32553;&#23567;</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#35748;&#35777;&#28040;&#32791;&#31215;&#20998;&#31867;&#22411;</td></tr>
<tr onmouseover="setfaq(this, 'faq205a')" class="noborder"><td class="vtop rowform">
    <select name="settingsnew[r_ext]">
        <option value="" >&#31354;
            <?php if(is_array($_G['setting']['extcredits'])) foreach($_G['setting']['extcredits'] as $id => $credit) { ?>        <option value="<?php echo $id;?>" <?php if($id == $settings['r_ext']['value']) { ?>selected<?php } ?>><?php echo $credit['title'];?>
        <?php } ?>
    </select>
</td></tr>
<tr><td s="1" class="td27" colspan="2">&#35748;&#35777;&#28040;&#32791;&#31215;&#20998;&#25968;</td></tr>
<tr onmouseover="setfaq(this, 'faq1e8e')" class="noborder"><td class="vtop rowform">
    <input type="text" class="txt" value="<?php echo $settings['r_pay']['value'];?>" name="settingsnew[r_pay]"></td><td s="1" class="vtop tips2"></td>
</tr>