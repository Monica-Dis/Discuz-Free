<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<tr ><th class="partition" colspan="15" >&#33258;&#21161;&#24191;&#21578;&#35774;&#32622;</th></tr>

<tr><td s="1" class="td27" colspan="2">&#39318;&#39029;&#36718;&#25773;&#33258;&#21161;&#24191;&#21578;</td></tr>
<tr class="noborder" onmouseover="setfaq(this, 'faqd8d7')">
    <td class="vtop rowform">
<textarea rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)" name="settingsnew[lunad]"  cols="50" class="tarea">
<?php echo $settings['lunad']['value'];?>
</textarea>
    </td>
    <td class="vtop tips2" s="1">&#19968;&#34892;&#19968;&#20010;&#65292;&#38543;&#20415;&#25918;<br>&#21452;&#20987;&#36755;&#20837;&#26694;&#21487;&#25193;&#22823;&#47;&#32553;&#23567;</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#39318;&#39029;&#19977;&#26684;&#33258;&#21161;&#24191;&#21578;</td></tr>
<tr class="noborder" onmouseover="setfaq(this, 'faqd8d7')">
    <td class="vtop rowform">
<textarea rows="6" cols="20" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)" name="settingsnew[sangead]"  cols="50" class="tarea">
<?php echo $settings['sangead']['value'];?>
</textarea>
    </td>
    <td class="vtop tips2" s="1">&#19968;&#34892;&#19968;&#20010;&#65292;&#20849;&#19977;&#20010;<br>&#21452;&#20987;&#36755;&#20837;&#26694;&#21487;&#25193;&#22823;&#47;&#32553;&#23567;</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#39318;&#39029;&#27178;&#24133;&#33258;&#21161;&#24191;&#21578;</td></tr>
<tr class="noborder" onmouseover="setfaq(this, 'faqd8d7')">
    <td class="vtop rowform">
<textarea rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)" name="settingsnew[hengfuad]"  cols="50" class="tarea">
<?php echo $settings['hengfuad']['value'];?>
</textarea>
    </td>
<tr><td s="1" class="td27" colspan="2">&#35814;&#24773;&#39029;&#33258;&#21161;&#24191;&#21578;</td></tr>
<tr class="noborder" onmouseover="setfaq(this, 'faqd8d7')">
    <td class="vtop rowform">
<textarea rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)" name="settingsnew[xiangad]"  cols="50" class="tarea">
<?php echo $settings['xiangad']['value'];?>
</textarea>
    </td>
    <td class="vtop tips2" s="1">&#21482;&#26377;&#19968;&#20010;<br>&#21452;&#20987;&#36755;&#20837;&#26694;&#21487;&#25193;&#22823;&#47;&#32553;&#23567;</td>
</tr>
