<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<ul class="nav nav-tabs" role="tablist" >
    <li <?php if($_GET['c'] != 'group') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljdiy&amp;c=page&amp;a=list_index&amp;admin_id=<?php echo $admin_id;?>&amp;station_id=<?php echo $station_id;?>">全部页面</a></li>
    <?php if($type == 0) { ?>
    <li <?php if($_GET['c'] == 'group') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljdiy&amp;c=group&amp;a=list_index&amp;admin_id=<?php echo $admin_id;?>&amp;station_id=<?php echo $station_id;?>">分组管理</a></li>
    <?php } ?>
</ul>