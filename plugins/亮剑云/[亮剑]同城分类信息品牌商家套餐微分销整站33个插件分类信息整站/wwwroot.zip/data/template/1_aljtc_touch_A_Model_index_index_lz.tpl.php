<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<style>
.a_banner{line-height: 0px !important;}
.a_banner .swiper-slide span{line-height: 1.6 !important;}
</style>
<?php if($settings['lunad']['value'] && $is_aljad) { ?>
<section class="a_banner">
<div class="swiper-container" id="a_banner" style="visibility: visible;height: auto;">
<div class="swiper-wrapper"><?php if(is_array($lunad)) foreach($lunad as $lun_value) { ?>   <div class='swiper-slide page_bg_card_pd page_bg_none'>
<a href='javascript:;' class="page_bg_card_br"><?php echo htmlspecialchars_decode($lun_value)?></a>
</div>
<?php } ?>
</div>
<div class="swiper-pagination"  ></div>
</div>
</section>
   <?php } else { ?>
<section class="a_banner">
<div class="swiper-container" id="a_banner" style="visibility: visible;height: auto;">
<div class="swiper-wrapper"><?php if(is_array($lz_types)) foreach($lz_types as $val) { ?>   <div class='swiper-slide page_bg_card_pd page_bg_none'>
<a href='<?php echo $val['0'];?>' class="page_bg_card_br">
<img src='<?php echo $val['1'];?>' width=100% />
</a>
</div>
<?php } ?>
</div>
<div class="swiper-pagination"  ></div>
</div>
</section>
<?php } ?>