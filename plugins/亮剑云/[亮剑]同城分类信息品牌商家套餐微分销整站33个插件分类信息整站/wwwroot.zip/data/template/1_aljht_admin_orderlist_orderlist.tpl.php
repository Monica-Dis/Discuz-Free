<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template('aljht:admin/iframe_header_common'); ?><div class="content-wrapper">
    <section class="content-header">
        <?php if($_GET['ajax'] != 'yes') { ?>
        <h1>
            <?php echo $aljhtlang['template']['orderlist_1'];?>
            <small><?php echo $aljhtlang['template']['orderlist_2'];?><?php echo $num;?><?php echo $aljhtlang['template']['orderlist_3'];?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo $index_url;?>"><i class="fa fa-dashboard"></i> <?php echo $aljhtlang['template']['brand_31'];?></a></li>
            <li><a href="plugin.php?id=aljht&amp;act=admin"><?php echo $aljhtlang['template']['brand_32'];?></a></li>
            <li class="active"><?php echo $aljhtlang['template']['orderlist_1'];?></li>
        </ol>
        <?php } ?>
    </section>
<style type="text/css">
.info-box-content {
  margin-left: 25%;
  padding: 20px 10px;
  text-align: center;
}
.info-box-icon {
  background: rgba(0, 0, 0, 0.2) none repeat scroll 0 0;
  border-radius: 2px 0 0 2px;
  display: block;
  float: left;
  font-size: 45px;
  height: 90px;
  line-height: 90px;
  text-align: center;
  width: 25%;
}
    .wm_type{border: 1px solid #f42424;color:#f42424;padding:0px 4px;font-size: 12px;border-radius: 5px;margin-right: 5px;}
</style>
    <section class="content" onkeypress="EnterPress(event)" onkeydown="EnterPress()">
<?php if(($ids && $ord=='dianpu') || $administrators) { ?>
<div class="row">
        <?php if($_G['cache']['plugin']['aljbdx']['is_aljqb']) { ?>
        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

        <div class="col-md-2 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-green"><i class="ion ion-social-usd-outline"></i></span>

                <div class="info-box-content">

                    <span class="info-box-number"><b style="color:red;"><?php if($fhcount) { ?><?php echo $fhcount;?><?php } else { ?>0<?php } ?></b></span>
                    <span class="info-box-text">待发货订单</span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <div class="col-md-2 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-aqua"><i class="fa ion-social-usd"></i></span>

                <div class="info-box-content">

                    <span class="info-box-number"><b style="color:red;"><?php if($aljqbcount) { ?><?php echo $aljqbcount;?><?php } else { ?>0.00<?php } ?></b></span>
                    <span class="info-box-text">已付款</span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <div class="col-md-2 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-red"><i class="fa ion-social-usd"></i></span>

                <div class="info-box-content">

                    <span class="info-box-number"><b style="color:red;"><?php if($waljqbcount) { ?><?php echo $waljqbcount;?><?php } else { ?>0.00<?php } ?></b></span>
                    <span class="info-box-text">未付款</span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <?php } else { ?>
        <div class="col-md-2 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="ion ion-social-usd-outline"></i></span>

            <div class="info-box-content">

              <span class="info-box-number"><b style="color:red;"><?php if($wxcount) { ?><?php echo $wxcount;?><?php } else { ?>0.00<?php } ?></b></span>
  <span class="info-box-text">已付款微信</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-2 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa ion-social-usd"></i></span>

            <div class="info-box-content">

              <span class="info-box-number"><b style="color:red;"><?php if($wwxcount) { ?><?php echo $wwxcount;?><?php } else { ?>0.00<?php } ?></b></span>
  <span class="info-box-text">未付款微信</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

        <div class="col-md-2 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="ion ion-social-usd-outline"></i></span>

            <div class="info-box-content">

              <span class="info-box-number"><b style="color:red;"><?php if($alipay) { ?><?php echo $alipay;?><?php } else { ?>0.00<?php } ?></b></span>
  <span class="info-box-text">已付款支付宝</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-2 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-social-usd"></i></span>

            <div class="info-box-content">

              <span class="info-box-number"><b style="color:red;"><?php if($walipay) { ?><?php echo $walipay;?><?php } else { ?>0.00<?php } ?></b></span>
  <span class="info-box-text">未付款支付宝</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
<div class="col-md-2 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="ion ion-social-usd-outline"></i></span>

            <div class="info-box-content">

              <span class="info-box-number"><b style="color:red;"><?php if($wxcountapp) { ?><?php echo $wxcountapp;?><?php } else { ?>0.00<?php } ?></b></span>
  <span class="info-box-text">已付款APP微信</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-2 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa ion-social-usd"></i></span>

            <div class="info-box-content">

              <span class="info-box-number"><b style="color:red;"><?php if($wwxcountapp) { ?><?php echo $wwxcountapp;?><?php } else { ?>0.00<?php } ?></b></span>
  <span class="info-box-text">未付款APP微信</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <?php } ?>
        <!-- /.col -->
      </div>

<div class="callout callout-info" style="background-color: #ffffff !important;">
<div class="row" style="color: #333 !important;">
<form name="cpform"  method="post" autocomplete="off" action="plugin.php?id=<?php echo $pluginid;?>&amp;act=admin&amp;op=<?php echo $op;?>&amp;do=<?php echo $do;?><?php echo $urlmod;?>&amp;ord=<?php echo $ord;?>">
<div class="col-md-12">
<select name="ordertype">
<option value="1" <?php if($_GET['ordertype'] == 1) { ?>selected<?php } ?>><?php echo $aljhtlang['template']['orderlist_4'];?>
<option value="2" <?php if($_GET['ordertype'] == 2) { ?>selected<?php } ?>><?php echo $aljhtlang['template']['orderlist_5'];?>
<option value="3" <?php if($_GET['ordertype'] == 3) { ?>selected<?php } ?>><?php echo $aljhtlang['template']['orderlist_6'];?>
<option value="4" <?php if($_GET['ordertype'] == 4) { ?>selected<?php } ?>>uid或用户名
<option value="5" <?php if($_GET['ordertype'] == 5) { ?>selected<?php } ?>>订单备注
</select>
<input name="search"  value="<?php echo $keyword;?>" type="text">&nbsp;&nbsp;&nbsp;&nbsp;
<?php echo $aljhtlang['template']['orderlist_7'];?> <input name="start"   id="start" value="<?php echo $_GET['start'];?>" placeholder="<?php echo $aljhtlang['template']['orderlist_8'];?>"> <?php echo $aljhtlang['template']['orderlist_9'];?> <input name="end" id="end" value="<?php echo $_GET['end'];?>" placeholder="<?php echo $aljhtlang['template']['orderlist_10'];?>">
</div>
<div class="col-md-12" style="margin-top:20px">
<?php echo $aljhtlang['template']['orderlist_11'];?> <select name="status">
<option value="" ><?php echo $aljhtlang['template']['orderlist_12'];?>
<option value="1" <?php if($_GET['status'] == '1') { ?>selected<?php } ?>><?php echo $aljhtlang['template']['orderlist_13'];?>
<option value="2" <?php if($_GET['status'] == '2') { ?>selected<?php } ?>><?php echo $aljhtlang['template']['orderlist_14'];?>
<option value="3" <?php if($_GET['status'] == '3') { ?>selected<?php } ?>><?php echo $aljhtlang['template']['orderlist_15'];?>
<option value="4" <?php if($_GET['status'] == '4') { ?>selected<?php } ?>><?php echo $aljhtlang['template']['orderlist_16'];?>
<option value="5" <?php if($_GET['status'] == '5') { ?>selected<?php } ?>><?php echo $aljhtlang['template']['orderlist_17'];?>
</select>&nbsp;&nbsp;&nbsp;&nbsp;
<?php echo $aljhtlang['template']['orderlist_18'];?> <select name="payment">
<option value="" ><?php echo $aljhtlang['template']['orderlist_12'];?>
<option value="1" <?php if($_GET['payment'] == '1') { ?>selected<?php } ?>><?php echo $aljhtlang['template']['orderlist_19'];?>
<option value="2" <?php if($_GET['payment'] == '2') { ?>selected<?php } ?>><?php echo $aljhtlang['template']['orderlist_20'];?>
<option value="3" <?php if($_GET['payment'] == '3') { ?>selected<?php } ?>><?php echo $aljhtlang['template']['orderlist_21'];?>
</select>
</div>
<div class="col-md-12" style="margin-top:20px">
<input class="btn btn-primary" value="<?php echo $aljhtlang['template']['orderlist_22'];?>" type="submit">&nbsp;&nbsp;<a href="plugin.php?id=aljbdx:export&amp;status=<?php echo $_GET['status'];?>&amp;ordertype=<?php echo $_GET['ordertype'];?>&amp;search=<?php echo $keyword;?>&amp;payment=<?php echo $_GET['payment'];?>&amp;start=<?php echo $_GET['start'];?>&amp;end=<?php echo $_GET['end'];?><?php echo $urlmod;?>&amp;ord=<?php echo $ord;?>" style="color:red; text-decoration:none; ">导出订单</a>
</div>

</form>
</div>
     </div>
        <div class="callout callout-info" style="background-color: #ffffff !important;">
            <div class="row" style="color: #333 !important;">
                <div class="col-md-12">
                    <span class="fa fa-volume-up" style="margin-right: 5px;color:#0097bc;"></span>点击收货信息栏下的姓名、电话、地址可以一键复制对应的内容，复制全部可以复制带逗号姓名,电话,收货地址
                </div>
                <?php if($_G['cache']['plugin']['aljgwc']['aljol'] || $_G['cache']['plugin']['aljbdx']['aljol']) { ?>
                <div class="col-md-12">
                    <span class="fa fa-volume-up" style="margin-right: 5px;color:#0097bc;"></span>点击付款人用户名可联系买家
                </div>
                <?php } ?>
            </div>
        </div>
 <?php } ?>
        <?php if($_GET['ajax'] != 'yes' || $_GET['dzAdmin'] == 1) { ?>
        <ul class="nav nav-tabs" role="tablist" >
<li <?php if(!$status) { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=orderlist<?php echo $urlmod;?>&amp;ord=<?php echo $ord;?>"> <?php echo $aljhtlang['template']['orderlist_23'];?></a></li>
<li <?php if($status == 1) { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=orderlist&amp;status=1<?php echo $urlmod;?>&amp;ord=<?php echo $ord;?>"> <?php echo $aljhtlang['template']['orderlist_13'];?></a></li>
<li <?php if($status == 2) { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=orderlist&amp;status=2<?php echo $urlmod;?>&amp;ord=<?php echo $ord;?>"> <?php echo $aljhtlang['template']['orderlist_14'];?></a></li>
<li <?php if($status == 3) { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=orderlist&amp;status=3<?php echo $urlmod;?>&amp;ord=<?php echo $ord;?>"> <?php echo $aljhtlang['template']['orderlist_15'];?></a></li>
<li <?php if($status == 4) { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=orderlist&amp;status=4<?php echo $urlmod;?>&amp;ord=<?php echo $ord;?>"> <?php echo $aljhtlang['template']['orderlist_16'];?></a></li>
<li <?php if($status == 5) { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=orderlist&amp;status=5<?php echo $urlmod;?>&amp;ord=<?php echo $ord;?>"> <?php echo $aljhtlang['template']['orderlist_17'];?></a></li>
</ul>
        <?php } ?>
<link rel="stylesheet" href="source/plugin/aljht/static/css/orderlist.css">
        <div class="row">

            <!-- /.col -->
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo $aljhtlang['template']['orderlist_24'];?></h3>
<?php if($ord=='ge') { ?>
                        <div class="box-tools pull-right">
                            <div class="has-feedback">
                                <input type="text" id="search" class="form-control input-sm" placeholder="<?php echo $aljhtlang['template']['orderlist_25'];?>" value="<?php echo $keyword;?>">
                                <div class="glyphicon glyphicon-search form-control-feedback" style="pointer-events: visible;" onclick="location.href='plugin.php?id=aljht&act=admin&op=orderlist&do=<?php echo $do;?>&ord=<?php echo $ord;?><?php echo $urlmod;?>&search='+$('#search').val()"></div>
                            </div>
                        </div>
<?php } ?>
                        <!-- /.box-tools -->
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body no-padding">
                        <div class="table-responsive mailbox-messages">
                            <iframe style="display:none;" name="submitiframe"></iframe>
                            <form name="cpform" id="admingoodssubmit" method="post" autocomplete="off" action="plugin.php?id=aljht&amp;act=admin&amp;op=orderlist<?php echo $urlmod;?>" target="submitiframe">
                                <input type="hidden"  value="0" name="sign" id="sign">
                                <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>">
        <div class="info_box" >
            <div class="info_table order_table">

                <table>
                    <tbody>
                        <tr>
                            <th width="50">
                                &nbsp;
                            </th>
                            <th width="auto">
                                详情
                            </th>
                            <th width="80">
                                价格
                            </th>
                            <th width="70">
                                数量
                            </th>
<th width="90">
                                付款方式
                            </th>
                            <th width="200">
                                收货信息
                            </th>
                            <th width="90">
                                状态
                            </th>

                            <th width="90">
                                操作
                            </th>
                            <?php if($status == 4) { ?>
                            <th></th>
                            <?php } ?>
                        </tr><?php if(is_array($orderlist)) foreach($orderlist as $value) { ?>                        <tr>
                            <td class="tl order_sum" colspan="<?php if($status == 4) { ?>10<?php } else { ?>9<?php } ?>">
                                <div class="f_l">
                                    <?php if($value['store_id']>0) { ?>
                                        <?php $obrand = C::t('#aljtsq#aljtsq_store')->fetch($value['store_id']);
                                        $obrand['uid'] = $obrand['tc_uid'];
                                        $obrand['name'] = $obrand['tc_store_name'];?>                                        <?php if($value['order_type'] == 3) { ?>
                                            <?php $obrand['url'] = 'plugin.php?id=aljwm&a=view&c=food&store_id='.$value['store_id'];?>                                        <?php } else { ?>
                                            <?php $obrand['url'] = 'plugin.php?id=aljtsc&a=storeView&c=aljtsc&store_id='.$value['store_id'];?>                                        <?php } ?>
                                    <?php } else { ?>
                                        <?php $obrand = C::t('#aljbd#aljbd')->fetch($value['shop_id'])?>                                        <?php $obrand['url'] = 'plugin.php?id=aljbd&act=view&bid='.$value['shop_id'];?>                                    <img src="<?php echo $obrand['logo'] ? $obrand['logo'] : 'source/plugin/aljbd/images/sj/shang.png'?>" style="width:20px;margin-right: 5px;"/>
                                    <?php } ?>
                                    <a target="_blank" href="<?php echo $obrand['url'];?>" class="right-go a-brand" style="margin-right: 15px;">
                                        <?php if($value['store_id']>0) { ?>
                                            <span class="wm_type"><?php if($value['order_type'] == 3) { ?>外卖<?php } else { ?>&#38376;&#24215;<?php } ?></span>
                                            <?php } ?>
                                        <?php echo $obrand['name'];?></a>
                                    <?php if($value['commodity_type'] == 1 && $_G['cache']['plugin']['aljstg']) { include template('aljstg:orderlist/tg_text'); } elseif($value['commodity_type'] == 2 && $_G['cache']['plugin']['aljspt']) { include template('aljspt:orderlist/pt_text'); } ?>订单编号
                                    <h1>
                                        <?php echo $value['orderid'];?>
                                    </h1>，交易时间：
                                    <h1>
                                        <?php echo dgmdate($value['submitdate']);?>                                    </h1>订单总价：
                                    <h1>
                                        <?php echo $price_unit;?>
                                        <?php echo $value['price'];?>
                                        <?php if(file_exists("source/plugin/dz_3/dz_3.inc.php")) { ?>
                                        <?php include template('dz_3:h_orderlist'); ?>                                        <?php } ?>
                                    </h1>
                                    &#20184;&#27454;&#20154;/UID&#65306;
                                    
                                    <h1>
                                        <?php if($_G['cache']['plugin']['aljgwc']['aljol'] || $_G['cache']['plugin']['aljbdx']['aljol']) { ?>
                                        <a href="javascript:;" onclick="openaljol('<?php echo $value['uid'];?>');"><?php echo $value['username'];?>/<?php echo $value['uid'];?></a>
                                        <?php } else { ?>
                                        <?php echo $value['username'];?>/<?php echo $value['uid'];?>
                                        <?php } ?>
                                    </h1>
                                    <?php if($value['remarks']) { ?>备注：<?php echo $value['remarks'];?><?php } ?>
                                </div>
                                <div class="f_r">
                                    <?php if($_G['uid'] == $value['uid'] && $value['status'] == 1 && $value['payment'] !=6) { ?>
                                        <a class="continue_pay" href="plugin.php?id=aljgwc&amp;act=cart_pay&amp;orderid=<?php echo $value['orderid'];?>">继续付款</a>
                                    <?php } ?>
                                    <?php if($value['deliverydate']) { ?>
                                    <span class="endtime" value="<?php echo $value['deliverydate']+$deliverytime?>" val-date="<?php echo $value['orderid'];?>" date-val="<?php if($value['status'] == 3) { ?>1<?php } else { ?>0<?php } ?>"></span>
                                    <?php } ?>
                                </div>
                            </td>
                        </tr><?php $shop_order=C::t('#aljgwc#aljbd_goods_order_list')->fetch_all_by_orderid($value['orderid']);?><?php $i=1;?>                        <?php if(is_array($shop_order)) foreach($shop_order as $key => $val) { ?>                        
                        <?php if(unserialize($val['goodsinfo'])) { ?>
                        <?php $orderlist_cart = unserialize($val['goodsinfo']);?>                        <?php } else { ?>
                        <?php $orderlist_cart=C::t('#aljbd#aljbd_goods')->fetch($val['goods_id']);?>                        <?php } ?>
                        <tr class="alt">
                            <td>
                                <a target="_blank" href="
                                <?php if($value['order_type'] == 3 && $value['store_id']>0) { ?>
                                <?php echo $obrand['url'];?>
                                <?php } else { ?>
                                plugin.php?id=<?php echo $pluginid_aljbd;?>&act=goodview&bid=<?php echo $val['shop_id'];?>&gid=<?php echo $val['goods_id'];?>
                                <?php } ?>"><img class="deal_icon" style="width: 50px;" lazy="true" data-src="<?php echo $orderlist_cart['pic1'];?>" src="<?php echo $orderlist_cart['pic1'];?>"></a>
                            </td>
                            <td class="tl">
                                <a target="_blank" href="
                                <?php if($value['order_type'] == 3 && $value['store_id']>0) { ?>
                                <?php echo $obrand['url'];?>
                                <?php } else { ?>
                                plugin.php?id=<?php echo $pluginid_aljbd;?>&act=goodview&bid=<?php echo $val['shop_id'];?>&gid=<?php echo $val['goods_id'];?>
                                <?php } ?>">
                                    <?php if($value['commodity_type'] == 1) { ?>
                                    <?php include template('aljstg:orderlist/order_label'); ?>                                    <?php } ?>
                                    <?php if($value['commodity_type'] == 2) { ?>
                                    <?php include template('aljspt:orderlist/order_label'); ?>                                    <?php } ?>
                                    <?php if($val['is_distribution']>0 && $val['dis_commission']>0) { ?>
                                    <span style="font-size: 12px;background: #f39c12;color:#ffffff;padding:2px;border-radius: 5px;margin-right: 5px">分销</span>
                                    <?php } ?>
                                    <?php echo $val['name'];?><br/>
                                    <?php if($orderlist_cart['commodity_code']) { ?>
                                    商品货号:&nbsp;<?php echo $orderlist_cart['commodity_code'];?><br/>
                                    <?php } ?>
                                    <?php if($val['content']) { ?>规格留言：<?php echo $val['content'];?><?php } ?>
                                    
                                </a>
                                
                                <?php if(file_exists("source/plugin/aljbd_dzfj/aljbd_dzfj.inc.php")) { ?>
                                <?php include template('aljbd_dzfj:orderlist'); ?>                                <?php } ?>
                            </td>
                            
                            <td class="op_box">
                                <?php echo $price_unit;?><?php echo $val['price'];?>
                                <?php if(file_exists("source/plugin/dz_3/dz_3.inc.php")) { ?>
                                <br/><?php include template('dz_3:h_orderlist'); ?>                                <?php } ?>
                            </td>
                            <td class="op_box">
                                <?php echo $val['num'];?>
                            </td>

<?php if($i == 1) { ?>
                            <td class="op_box" rowspan="<?php echo count($shop_order);?>">
<?php if($value['admin']) { ?><?php echo $qb_pay_type[$value['admin']];?><?php } else { ?><?php echo $paymentarr[$value['payment']];?><?php } ?>
                            </td>
<?php } ?>
                            <?php if($i == 1) { ?>
                            <td class="op_box" rowspan="<?php echo count($shop_order);?>">
                                <?php if($other = unserialize($value['other'])) { ?>
                                <?php if(is_array($other)) foreach($other as $other_k => $other_v) { ?>                                    <?php if($other_k == 'name') { ?>
                                        <p data-clipboard-text="<?php echo $other_v;?>" class="copybtn"><a href="javascript:;"><?php echo $other_v;?></a></p>
                                    <?php } elseif($other_k == 'tel') { ?>
                                        <p data-clipboard-text="<?php echo $other_v;?>" class="copybtn"><a href="javascript:;"><?php echo $other_v;?></a></p>
                                    <?php } elseif($other_k == 'id_card') { ?>
                                        <p data-clipboard-text="<?php echo $other_v;?>" class="copybtn"><a href="javascript:;"><?php echo $other_v;?></a></p>
                                    <?php } ?>
                                    <?php $allother .= $other_v.',';?>                                <?php } ?>
                                <p class="copybtn" data-clipboard-text="<?php echo trim($allother,',')?>">
                                    <a href="javascript:;">复制全部</a>
                                </p>
                                <?php } else { ?>
                                    <?php $address = unserialize($value['address']);?>                                    <?php if($address && $value['category'] == 0) { ?>
                                    <p data-clipboard-text="<?php echo $address['fullName'];?>" class="copybtn"><a href="javascript:;"><?php echo $address['fullName'];?></a></p>
                                    <p class="copybtn" data-clipboard-text="<?php if($address['mobile']) { ?><?php echo $address['mobile'];?><?php } else { if($address['phoneSection'] || $address['phoneCode'] || $address['phoneExt']) { if($address['phoneSection']) { ?><?php echo $address['phoneSection'];?> - <?php } if($address['phoneCode']) { ?><?php echo $address['phoneCode'];?><?php } if($address['phoneExt']) { ?> - <?php echo $address['phoneExt'];?><?php } } } ?>"><a href="javascript:;"><?php if($address['mobile']) { ?><?php echo $address['mobile'];?><?php } else { if($address['phoneSection'] || $address['phoneCode'] || $address['phoneExt']) { if($address['phoneSection']) { ?><?php echo $address['phoneSection'];?> - <?php } if($address['phoneCode']) { ?><?php echo $address['phoneCode'];?><?php } if($address['phoneExt']) { ?> - <?php echo $address['phoneExt'];?><?php } } } ?></a></p>
                                    <?php if($regionlist[$address['region']]['name']) { ?>
                                    <?php $addresstext = $regionlist[$address['region']][name].$regionlist[$address['region1']][name].$regionlist[$address['region2']][name].$address['addressDetail']?>                                    <?php } else { ?>
                                    <?php $addresstext = $address['province'].$address['city'].$address['district'].$address['addressDetail']?>                                    <?php } ?>
                                    <p class="copybtn" data-clipboard-text="<?php echo $addresstext;?>">
                                        <a href="javascript:;">
                                            <?php echo $addresstext;?>
                                        </a>
                                    </p>
                                    <p class="copybtn" data-clipboard-text="<?php echo $address['fullName'];?>,<?php if($address['mobile']) { ?><?php echo $address['mobile'];?><?php } else { if($address['phoneSection'] || $address['phoneCode'] || $address['phoneExt']) { if($address['phoneSection']) { ?><?php echo $address['phoneSection'];?> - <?php } if($address['phoneCode']) { ?><?php echo $address['phoneCode'];?><?php } if($address['phoneExt']) { ?> - <?php echo $address['phoneExt'];?><?php } } } ?>,<?php echo $addresstext;?>">
                                        <a href="javascript:;">复制全部</a>
                                    </p>
                                    <?php } else { ?>
                                    ---
                                    <?php } ?>
                                <?php } ?>
                            </td>
                            <?php } if($i == 1) { ?>
                            <td class="op_box" rowspan="<?php echo count($shop_order);?>">
                                <?php if($value['status']==2) { if($value['payment'] == 6) { ?>
                                        已下单
<?php } else { ?>
待发货
<?php } } elseif($value['status']==3) { ?>
                                    <?php if((($value['commodity_type'] == 1 && $value['category'] == 1) || $value['get_to_the_shop'] == 1) && $_G['cache']['plugin']['aljstg']) { ?>
                                        <?php if($value['commodity_type'] == 1 && $value['category'] == 1) { ?>
                                            &#24453;&#26680;&#38144;
                                        <?php } else { ?>
                                            &#24453;&#21462;&#36135;
                                        <?php } ?>
                                    <?php } else { ?>
                                        已发货
                                    <?php } } elseif($value['status']==4) { ?>
                                    交易完成
<?php } elseif($value['status']==5) { ?>
<?php echo $aljbdlang['template']['Already_evaluated'];?>
<?php } elseif($value['status']==6) { ?>
                                    已退款
                                <?php } elseif($value['status']==7) { ?>
                                    交易关闭
<?php } else { ?>
付款中
<?php } ?><br>
                                <?php $refund = C::t('#aljgwc#aljgwc_refund')->fetch($value['orderid'])?>                                <?php if($refund && $value['status'] < 4  && $value['status'] >1) { ?>
                                <br>

                                <a  style="padding:3px 10px;border:1px dashed #f15353;color:#f15353;margin-bottom:5px;font-size: 12px;border-radius: 20px">
                                    <?php if($refund['state'] < 3) { ?>
                                    退款中
                                    <?php } elseif($refund['state'] == 4) { ?>
                                    退款失败
                                    <?php } ?>
                                </a>
                                <?php } else { ?>
                                <?php if($value['commodity_type'] == 2 && $value['status']<6) { ?>
                                <?php include template('aljspt:orderlist/open_pt_url'); ?>                                <?php } ?>
                                    <?php if(($value['status']==2 && in_array($value['shop_id'],$ids) && $ord=='dianpu') || ($administrators && $value['status']==2)) { ?>
                                        <?php if($value['commodity_type'] != 2  || ($value['commodity_type'] == 2 && $value['amount'] == 1)) { ?>

                                            <a  href="javascript:;" onclick="fahuo('<?php echo $value['orderid'];?>','<?php echo $value['category'];?>','<?php echo $value['get_to_the_shop'];?>',0,'<?php echo $value['order_type'];?>');">发货</a>&nbsp;
                                        <?php } ?>
                                    <?php } } ?>
                            </td>

                            <td class="op_box" rowspan="<?php echo count($shop_order);?>">

                                <a href="javascript:;" onclick="iframeorderview('<?php echo $value['orderid'];?>')">查看</a><br>
<?php if(($value['status']==3 && $value['uid'] == $_G['uid']) || ($administrators && $value['status']==3)) { if(!$value['d'] && $value['payment'] == 2) { $del_ts = '您确认要收货吗？担保交易请前往支付宝同步点击下收货，谢谢！'?><?php } else { $del_ts = '您确认要收货吗？'?><?php } ?>
                                <?php if(($value['commodity_type'] == 1 && $value['category'] == 1) || $value['get_to_the_shop'] == 1) { ?>
                                <?php } else { ?>
<a class="del_order" onclick="receipt('<?php echo $value['orderid'];?>','<?php echo $del_ts;?>')" href="javascript:;">确认收货</a><br>
                                <?php } } ?>
                                <?php if($value['status'] == 1 || ($value['status'] < 3 && $value['payment']==6)) { ?>
                                <a class="can_order" onclick="canorder('<?php echo $value['orderid'];?>','您确认要取消订单吗？');" href="javascript:;">取消订单</a><br>
                                <?php } ?>
                                <?php if($value['status'] == 7) { ?>
                                <a class="del_order" onclick="delorder('<?php echo $value['orderid'];?>','你确定要删除？删除后将无法恢复哦，请谨慎操作！');" href="javascript:;" style="color:red;">删除订单</a><br>
                                
                                <?php } ?>
                                <?php if($administrators && ($value['status'] == 7 || $value['status'] == 1)) { ?>
                                <a onclick="buorder('<?php echo $value['orderid'];?>','你确定要把订单改为已付款吗？请确认货款已收到，请谨慎操作！');" href="javascript:;" style="color:red;">补单</a><br>
                                <?php } ?>
                                <?php if($value['status']>=3 && $value['status']<6 && $_G['cache']['plugin']['aljhtx'] && $value['category'] == 0 && $value['get_to_the_shop'] != 1) { ?>
                                <?php $wuliuinfo=C::t('#aljbd#aljbd_wuliu')->fetch($value['orderid']);?>                                <a href="javascript:;" onclick="iframewuliu('<?php echo $value['orderid'];?>','<?php echo $wuliuinfo['companyname'];?>','<?php echo $wuliuinfo['worderid'];?>');">查看物流</a><br/>
                                <?php } ?>
                            </td>
<?php } ?>
                            <?php if($status == 4) { ?>
                            <td class="op_box">
                                <?php if($value['uid'] == $_G['uid']  && $_G['cache']['plugin']['aljgwc'][$pluginid_aljbd]) { ?>
                                    <?php $check = DB::result_first("select count(*) from %t where gid=%d and orderid=%s",array('aljbd_comment_goods',$val['goods_id'],$value['orderid']));?>                                    <?php if($check) { ?>
                                    <?php echo $aljbdlang['template']['Already_evaluated'];?>
                                    <?php } else { ?>
                                        <a href="javascript:;" onclick="iframecomment('<?php echo $value['orderid'];?>','<?php echo $val['goods_id'];?>')" >
                                            <?php if($_G['cache']['plugin']['aljbd']['goods_reply_type'] && $_G['cache']['plugin']['aljbd']['goods_reply_num']) { ?>
                                            <span class="o_reply">评价送积分</span>
                                            <?php } else { ?>
                                            <span class="o_reply"><?php echo $aljbdlang['template']['evaluate'];?></span>
                                            <?php } ?>
                                        </a>
                                    <?php } ?>
                                <?php } else { ?>
                                --
                                <?php } ?>
                            </td>
                            <?php } ?>
                        </tr><?php $i++;?>                        <?php } ?>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

                            <!-- /.table -->
                        </div>
                        <!-- /.mail-box-messages -->
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer no-padding">
                        <div class="mailbox-controls">

                            <div class="pull-right">
                                <?php echo $paging;?>
                                <!-- /.btn-group -->
                            </div>
                            <!-- /.pull-right -->
                        </div>
                    </div>
                    </form>
                </div>
                <!-- /. box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
</div>
<style type="text/css">
    .c_publish_time{vertical-align: middle;}
</style><?php include template('aljht:admin/orderlist/common/common_js'); ?><script src="source/plugin/aljht/static/js/clipboard.js" type="text/javascript"></script>
<script>
    //一键复制
    var show = true;
    var clipboard = new Clipboard('.copybtn');
    clipboard.on('success', function (e) {
        if(show) {
            alert('\u590d\u5236\u6210\u529f');
            show = false;
            setTimeout(function () {
                show = true;
            }, 1000);
        }

    });
    clipboard.on('error', function (e) {
        if(show) {
            alert('\u590d\u5236\u5931\u8d25');
            show = false;
            setTimeout(function () {
                show = true;
            }, 1000);
        }
    });
    
    function p_change_price(orderid,tipc){
        layer.closeAll('iframe'); //关闭所有的iframe层

        //prompt层
        layer.prompt({title: tipc, formType: 0}, function(pass, index){
            layer.close(index);
            layer.msg('<?php echo $aljhtlang['js']['orderlist_9'];?>', {icon: 16});
            $.post('plugin.php?id=aljht&act=admin&op=orderlist&do=change_price&formhash=<?php echo FORMHASH;?><?php echo $urlmod;?>',{"orderid":orderid,"price":pass},function(data){
                if(data){
                    tips('<?php echo $aljhtlang['js']['orderlist_10'];?>');
                }else{
                    tips('<?php echo $aljhtlang['js']['orderlist_13'];?>');
                }
            });
        });
    }
laydate.render({
    elem: '#start'
    ,type: 'datetime'
});

laydate.render({
    elem: '#end'
    ,type: 'datetime'
});

function EnterPress(e){ //传入 event
    var e = e || window.event;
    if(e.keyCode == 13){
        <?php if($ord=='ge') { ?>
        $('.glyphicon-search').click();
        <?php } else { ?>
        $('.btn-primary').submit();
        <?php } ?>
    }
}
</script>
<script>

    function tips(info){
        if(info == 0){
            layer.alert('<?php echo $aljhtlang['js']['orderlist_11'];?>', {icon: 6},function(){
                location.href=location.href;
            });
        }else{
            layer.alert(info, {icon: 6},function(){
                location.href=location.href;
            });
        }
    }
    $('.btn-submit').click(function(){
        $('#sign').val($(this).attr('data-id'));
        if($(this).attr('data-id') == 2){
layer.confirm('<?php echo $aljhtlang['js']['orderlist_12'];?>', {
  btn: ['<?php echo $aljhtlang['js']['orderlist_8'];?>'] //按钮
}, function(){
  layer.msg('<?php echo $aljhtlang['js']['orderlist_9'];?>', {icon: 16});
  $('#admingoodssubmit').submit();
});
}else{
layer.msg('<?php echo $aljhtlang['js']['orderlist_9'];?>', {icon: 16});
$('#admingoodssubmit').submit();
}
    });
    $(function () {
        //Enable iCheck plugin for checkboxes
        //iCheck for checkbox and radio inputs
        $('.mailbox-messages input[type="checkbox"]').iCheck({
            checkboxClass: 'icheckbox_flat-blue',
            radioClass: 'iradio_flat-blue'
        });

        //Enable check and uncheck all functionality
        $(".checkbox-toggle").click(function () {
            var clicks = $(this).data('clicks');
            if (clicks) {
                //Uncheck all checkboxes
                $(".mailbox-messages input[type='checkbox']").iCheck("uncheck");
                $(".fa", this).removeClass("fa-check-square-o").addClass('fa-square-o');
            } else {
                //Check all checkboxes
                $(".mailbox-messages input[type='checkbox']").iCheck("check");
                $(".fa", this).removeClass("fa-square-o").addClass('fa-check-square-o');
            }
            $(this).data("clicks", !clicks);
        });

        //Handle starring for glyphicon and font awesome
        $(".mailbox-star").click(function (e) {
            e.preventDefault();
            //detect type
            var thisstar = $(this).find("a > i");
            var glyph = thisstar.hasClass("glyphicon");
            var fa = thisstar.hasClass("fa");

            //Switch states
            if (glyph) {
                thisstar.toggleClass("glyphicon-star");
                thisstar.toggleClass("glyphicon-star-empty");
            }

            if (fa) {
                thisstar.toggleClass("fa-star");
                thisstar.toggleClass("fa-star-o");
            }
        });
    });
</script><?php include template('aljht:admin/footer'); ?>