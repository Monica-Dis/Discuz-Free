<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<ul class="nav nav-tabs" role="tablist" >
    <li <?php if(ACTION == 'common' || DEFAULT_ACTION == ACTION) { ?>class="active"<?php } ?>><a href="plugin.php?id=aljhtx&amp;c=qrcode&amp;a=common">通用二维码</a></li>
    <li <?php if(ACTION == 'wechat') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljhtx&amp;c=qrcode&amp;a=wechat">公众号二维码</a></li>
    <li <?php if(ACTION == 'miniprogram') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljhtx&amp;c=qrcode&amp;a=miniprogram">小程序二维码</a></li>
    <li <?php if(ACTION == 'goods') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljhtx&amp;c=qrcode&amp;a=goods">商品二维码</a></li>
</ul>