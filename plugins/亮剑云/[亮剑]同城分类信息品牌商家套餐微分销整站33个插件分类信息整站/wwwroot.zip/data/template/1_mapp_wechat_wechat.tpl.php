<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?><?php
$__TIMESTAMP = TIMESTAMP;$return = <<<EOF

<div class="fastlg_fm y" style="margin-right: 10px; padding-right: 10px">
<p><a href="plugin.php?id=mapp_wechat:m&amp;act=qrcode"><img src="source/plugin/mapp_wechat/images/wechat_login.png?{$__TIMESTAMP}" class="vm"></a></p>
<p class="hm xg1" style="padding-top: 2px;">&#25195;&#19968;&#25195;&#65292;&#26497;&#36895;&#30331;&#24405;</p>
</div>

EOF;
?>