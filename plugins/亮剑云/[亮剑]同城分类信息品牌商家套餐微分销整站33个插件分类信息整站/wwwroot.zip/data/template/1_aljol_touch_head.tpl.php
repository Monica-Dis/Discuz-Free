<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="<?php echo CHARSET;?>">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" name="viewport">
    <meta name="apple-mobile-web-app-capable" content="no">
    <meta content="telephone=no" name="format-detection">
    <meta content="black" name="apple-mobile-web-app-status-bar-style">
    <link href="source/plugin/aljol/static/css/aljol/swiper.min.css?<?php echo VERHASH;?>" rel="stylesheet" type="text/css">
    <link href="source/plugin/aljol/static/css/aljol/aljol.css?<?php echo VERHASH;?>" rel="stylesheet" type="text/css">
<link href="source/plugin/aljol/static/css/aljol/common.css?<?php echo VERHASH;?>" rel="stylesheet" type="text/css">
<link href="source/plugin/aljol/static/mlayer/need/layer.css?<?php echo VERHASH;?>" rel="stylesheet" type="text/css">
    <script src="source/plugin/aljol/static/js/jquery.min.js?<?php echo VERHASH;?>" type="text/javascript" type="text/javascript"></script>
    <script src="source/plugin/aljol/static/mlayer/layer.js?<?php echo VERHASH;?>" type="text/javascript" type="text/javascript"></script>
    <script src="source/plugin/aljol/static/js/lrz.mobile.min.js?<?php echo VERHASH;?>" type="text/javascript" type="text/javascript"></script>
    <script src="source/plugin/aljol/static/js/swiper.min.js?<?php echo VERHASH;?>" type="text/javascript" type="text/javascript"></script>
    <script src="source/plugin/aljol/static/js/jquery.form.min.js?<?php echo VERHASH;?>" type="text/javascript" type="text/javascript"></script>
    <script src="source/plugin/aljol/static/js/jquery-weui.min.js?<?php echo VERHASH;?>" type="text/javascript"></script>
    <title>
        <?php if($_GET['act'] == 'talk') { ?>
            <?php if(!$friendid) { ?><?php echo $_G['cache']['plugin']['aljol']['q_name'];?><?php } else { ?><?php echo $firendname['username'];?><?php } ?>
        <?php } elseif($_GET['act'] == 'newstype') { ?>
        <?php echo $navtitle;?>
        <?php } else { ?>
        在线聊天
        <?php } ?>
    </title>
    <script>
    document.documentElement.style.fontSize = document.documentElement.clientWidth / 10 + 'px';
    var ws;
    var mobile = <?php if($_G['mobile']) { ?>'_mobile'<?php } else { ?>'_pc'<?php } ?>;
    var uid = '<?php echo $_G['uid'];?>';
    var friendid = '<?php echo $friendid;?>';
    var token = '<?php echo $token;?>';
    <?php if(file_exists('chat.php') && $_G['cache']['plugin']['aljol']['is_socket']) { ?>
    var ws_on = true;
    <?php } else { ?>
    var ws_on = false;    
    <?php } ?>
    </script>
    <script src="source/plugin/aljol/static/js/aljol/aljol.js?<?php echo VERHASH;?>" type="text/javascript" type="text/javascript"></script>
</head>
<body>
<style>
    <?php if($_G['cache']['plugin']['aljol']['header_color']) { ?>
    .topBar,.topBar2 {
        background: <?php echo $_G['cache']['plugin']['aljol']['header_color'];?>;
    }
    .topBar>ul>li.active {
        color: <?php echo $_G['cache']['plugin']['aljol']['header_color'];?>;
    }
    .layim-chat-send button {
        background-color: <?php echo $_G['cache']['plugin']['aljol']['header_color'];?>;
    }
    <?php } ?>
    
</style>
<?php if(strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false) { include template('aljapp:uniapp'); } ?>
