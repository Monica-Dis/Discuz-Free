<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<ul class="tab-ul" >


<li class="tab-li active">

<div class="tab-list">
<?php if($brand_id ['type_ad']) { ?>
<div class="swiper-container ">
<div class="swiper-wrapper" ><?php if(is_array($type_ad_types)) foreach($type_ad_types as $k => $v) { ?><div class="swiper-slide" >
<a href="<?php echo $v['1'];?>">
<img src="<?php echo $k;?>"  alt="<?php echo $v['2'];?>" width="100%" height="<?php if($settings['mobile_lz_height']['value']) { ?><?php echo $settings['mobile_lz_height']['value'];?>px<?php } else { ?>auto<?php } ?>">
</a>
</div>
<?php } ?>
</div>

</div>
<?php } if(is_array($kkk2)) foreach($kkk2 as $subtype) { ?><hgroup class="module-title class-title" showtype="">
<em>
<?php echo $subtype['subject'];?>
</em>
<a href="<?php if($subtype['type_url']) { ?><?php echo $subtype['type_url'];?><?php } else { ?>plugin.php?id=aljbd&act=goods&type=<?php echo $_GET['tid'];?>&subtype=<?php echo $subtype['id'];?><?php } ?>">&#26597;&#30475;<i></i></a>
</hgroup>
<?php if(DB::result_first('select count(*) from %t where upid=%d and is_open=0',array('aljbd_type_goods',$subtype['id']))) { ?>
<ul><?php if(is_array(C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($subtype['id']))) foreach(C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($subtype['id']) as $sstype) { ?><li>
<a href="<?php if($sstype['type_url']) { ?><?php echo $sstype['type_url'];?><?php } else { ?>plugin.php?id=aljbd&act=goods&type=<?php echo $_GET['tid'];?>&subtype=<?php echo $subtype['id'];?>&subtype3=<?php echo $sstype['id'];?><?php } ?>">
<div class="tab-img">

<img data-src="<?php echo $sstype['logo'];?>" src="<?php if($sstype['logo']) { ?><?php echo $sstype['logo'];?><?php } else { ?>source/plugin/aljbd/template/touch/type/images/no_image.jpg<?php } ?>">

</div>
<p class="tab-desc"><?php echo $sstype['subject'];?></p>
</a>
</li>
<?php } ?>
</ul>
<?php } } ?>
</div>


<?php if($ppq) { ?>
<div class="tab-list">
<h2>&#21697;&#29260;&#22681;</h2>
<ul><?php if(is_array($ppq)) foreach($ppq as $pp) { ?><li>
<a href="plugin.php?id=aljbd&amp;act=view&amp;bid=<?php echo $pp['id'];?>">
<div class="tab-img logo">
<img data-src="<?php echo $pp['logo'];?>" src="<?php echo $pp['logo'];?>">
</div>
</a>
</li>
<?php } ?>


</ul>
</div>
<?php } ?>
<h2><a href="<?php if($tlist[$_GET['tid']]['type_url']) { ?><?php echo $tlist[$_GET['tid']]['type_url'];?><?php } else { ?>plugin.php?id=aljbd&act=goods&type=<?php echo $_GET['tid'];?><?php } ?>" >&#28857;&#20987;&#36827;&#20837;<?php echo $tlist[$_GET['tid']]['subject'];?>&#39057;&#36947; ></a></h2>
</li>


</ul>