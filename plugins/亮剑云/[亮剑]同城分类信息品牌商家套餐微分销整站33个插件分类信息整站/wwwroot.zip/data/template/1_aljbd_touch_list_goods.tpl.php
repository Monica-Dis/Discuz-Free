<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template('aljbd:header/header_head'); ?><link rel="stylesheet" href="source/plugin/aljbd/css/sj/module.css?<?php echo VERHASH;?>" />
<style type="text/css">
    .panel-heading ul li{position:relative;width:33.3%;font-size:12px;float:left;text-align:center;height:39px}.panel-heading ul li img{position:relative;top:-2px;width:15px}.search{position:relative;background:#fff}.search-keyword{width:100%;padding:0 0 0 5px;font-size:1em;color:#3c3c3c;background:#f4f4f4;line-height:30px;border-radius:3px;border:1px solid #cfcbc5;box-shadow:0 1px 3px #c8c8c8 inset}.search-button{position:absolute;display:inline-block;right:10px;top:12px;font-size:0;line-height:0;text-indent:-999px;border:0;width:30px;height:25px;background-position:-605px 6px;vertical-align:middle}.search-keyword{background:#fff;border:1px solid #f8f8f8;box-shadow:none}.icon18{background:url(source/plugin/aljbd/images/sj/search_v.png) no-repeat center center;background-size:20px}
    .y{float: right;}
</style>

<div class="container module-item" id="mobile_body">
    <div class="panel-comm panel-default panel-fullsize">
        <div class="header_search_nav">
    <div class="tabbox swiper-container2" style="margin:0px;background:#fff;width: 100%;overflow: hidden;"><div class=" swiper-wrapper" id="s_kw" data-tab="finer" ></div></div>
    <?php if(!$settings['is_type_bg']['value']) { ?>
        <style>
            .header_search_nav{position: fixed;z-index:999;width:100%;top:<?php if($yes_header) { ?>44px;<?php } else { ?>0px;<?php } ?>}
            .list_nav_l{background:#fff;width:100%;height:auto;z-index:999;}.nav_filter_l{width:100%;display:-webkit-box;display:-webkit-flex;display:flex;background:#fff;height:40px;line-height:40px;border-bottom:1px solid #eee;-webkit-user-select:none;position:relative}.nav_filter_l:before{content:" ";position:absolute;left:0;bottom:0;width:100%;height:1px;color:#f0f0f0;-webkit-transform-origin:0 0;transform-origin:0 0;-webkit-transform:scaleY(0.5);transform:scaleY(0.5)}.nav_filter_l>li:first-child{border-left:0}.nav_filter_l>li{width:100%;-webkit-box-flex:1;-webkit-flex:1;flex:1}.nav_filter_l>li>a{display:inline-block;text-align:center;width:100%;-o-text-overflow:ellipsis;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;-webkit-user-select:none;position:relative}.nav_filter_l>li>a:after{content:'';position:absolute;right:10px;top:18px;border-style:solid;border-width:5px 5px 0;border-color:transparent;border-top-color:#e6e6e6}.hide_l{display:none !important}.aclist_l{background:#fff;position:absolute;top:40px;width:100%;left:0;height:320px;overflow-y:auto}.aclist_l a{padding:0 15px;display:block;position: relative}.aclist_l a.on{background:#f3f3f3}#mask_l{background:#000;opacity:.3;width:100%;height:100%;position:fixed;z-index:998;top:0;left:0;display:none}.pos_l{position:fixed;top:<?php if($yes_header) { ?>44px<?php } else { ?>0<?php } ?>}.aclist_l b{font-weight:400;float:right;color:#CCC;}
            .list_nav_l a{color:#333;}
            .rotate180:after  {
                -webkit-transform: rotate(-180deg);
                transform: rotate(-180deg);
            }
            .aclist_l b::after {
                content: "";
                border-right: 1px solid #333;
                border-bottom: 1px solid #333;
                width: 5px;
                height: 5px;
                -webkit-transform: rotate(-45deg);
                position: absolute;
                right: 5%;
                top: 50%;
                margin-top: -4px;
            }
            .nav_filter_l a.on{color:#f42424}
            .nav_filter_l a.on::after{border-color: transparent;
                border-top-color: #f42424;}
        </style>
        <div class="list_nav_l" >
            <ul class="nav_filter_l">
                <li>
                    <a class="spot_l <?php if($_GET['subtype3'] || $_GET['subtype'] || $_GET['type']) { ?>on<?php } ?>" href="javascript:;"><?php if($_GET['subtype3']) { ?><?php echo $typelist[$_GET['subtype3']]['subject'];?><?php } elseif($_GET['subtype']) { ?><?php echo $typelist[$_GET['subtype']]['subject'];?><?php } elseif($_GET['type']) { ?><?php echo $typelist[$_GET['type']]['subject'];?><?php } else { ?><?php echo $aljbdlang['template']['classification'];?><?php } ?></a>
                    <ul class="aclist_l hide_l type_l">
                        <li><a class="type_a <?php if(!$_GET['type']) { ?>on<?php } ?>" href="<?php echo getaljurl($geturl,array('type'=>'','subtype'=>'','subtype3'=>''))?>"><?php echo $aljbdlang['template']['whole'];?></a></li>
                        <?php if(is_array(C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid(0))) foreach(C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid(0) as $typeid => $type) { ?>                        <li>
                        <a <?php if(C::t('#'.$pluginid.'#'.$pluginid.'_type_goods')->fetch_all_by_upid($type['id'])) { ?>onclick="type_1(<?php echo $type['id'];?>,this)" href="javascript:;"<?php } else { ?>href="<?php echo getaljurl($geturl,array('type'=>$type['id'],'subtype'=>'','subtype3'=>''))?>"<?php } ?> class="type_a <?php if($type['id'] == $_GET['type']) { ?>on<?php } ?>"><?php echo $type['subject'];?><?php if(C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($type['id'])) { ?><b></b><?php } ?></a> </li>
                        <?php } ?>
                    </ul>
                    <div id="aclist_l_subtype" >
                        <?php if($_GET['type']>0) { ?>
                            <?php $subtype = C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($_GET['type']);?>                            <?php if($subtype) { ?>
                            <style type="text/css">
                                .aclist_l_subtype{left:50%;border-left:1px solid #f0f0f0;width:51%}
                                .type_l{width:51%}
                                </style>
                                <ul class="aclist_l aclist_l_subtype hide_l">
                                    <li><a class="subtype_a <?php if(!$_GET['subtype']) { ?>on<?php } ?>" href="<?php echo getaljurl($geturl,array('subtype'=>'','subtype3'=>''));?>"><?php echo $aljbdlang['template']['whole'];?></a></li>
                                    <?php if(is_array($subtype)) foreach($subtype as $subt) { ?>                                    <li>
                                    <a class="subtype_a <?php if($subt['id'] == $_GET['subtype']) { ?>on<?php } ?>" <?php if(C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($subt['id'])) { ?>onclick="subtype_1(<?php echo $subt['id'];?>,<?php echo $_GET['type'];?>,this)" href="javascript:;"<?php } else { ?>href="<?php echo getaljurl($geturl,array('subtype'=>$subt['id']));?>"<?php } ?>><?php echo $subt['subject'];?><?php if(C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($subt['id'])) { ?><b></b><?php } ?></a></li>
                                    <?php } ?>
                                </ul>
                            <?php } ?>
                        <?php } ?>
                    </div>
                    <div id="aclist_l_subsubtype" >
                        <?php if($_GET['subtype']>0) { ?>
                            <?php $subsubtype = C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($_GET['subtype']);?>                            <?php if($subsubtype) { ?>
                                <style type="text/css">
                                    .aclist_l_subtype{left:33%;width:34%}
                                    .aclist_l_subsubtype{left:66%;right:0;border-left:1px solid #f0f0f0;width:34%}
                                    .type_l{width:34%}
                                </style>
                                <ul class="aclist_l aclist_l_subsubtype hide_l">
                                    <li><a class="<?php if(!$_GET['subtype3']) { ?>on<?php } ?>" href="<?php echo getaljurl($geturl,array('subtype3'=>''));?>"><?php echo $aljbdlang['template']['whole'];?></a></li>
                                    <?php if(is_array($subsubtype)) foreach($subsubtype as $subsubt) { ?>                                    <li><a <?php if($subsubt['id'] == $_GET['subtype3']) { ?>class="on"<?php } ?> href="<?php echo getaljurl($geturl,array('subtype3'=>$subsubt['id']));?>"><?php echo $subsubt['subject'];?></a></li>
                                    <?php } ?>
                                </ul>
                            <?php } ?>
                        <?php } ?>
                    </div>
                </li>
                <?php if($_GET['commodity_type'] == 1 || $_GET['commodity_type'] == 2) { ?>
                <li>
                    <a class="spot_l" href="javascript:;"><?php if($_GET['lat'] && $_GET['lng']) { ?><?php echo $aljbdlang['template']['Nearby_businesses'];?><?php } else { if($_GET['region1']) { ?><?php echo $titlelist[$_GET['region1']]['name'];?><?php } else { if($_GET['subregion']) { ?><?php echo $titlelist[$_GET['subregion']]['name'];?><?php } elseif($_GET['region']) { ?><?php echo $titlelist[$_GET['region']]['name'];?><?php } else { ?><?php echo $aljbdlang['template']['region'];?><?php } } } ?></a>
                    <ul class="aclist_l hide_l region_l">
                        <li><a <?php if(!$_GET['region']) { ?>class="on"<?php } ?>  href="<?php echo getaljurl($geturl,array('region'=>'','subregion'=>'','region1'=>'','lat'=>'','lng'=>''))?>"><?php echo $aljbdlang['template']['whole'];?></a></li>
                        <?php $onerlist=C::t('#aljbd#aljbd_region')->fetch_all_by_upid('','',0);?>                        <?php if(is_array($onerlist)) foreach($onerlist as $k => $r) { ?>                        <li>
                            <a <?php if(C::t('#aljbd#aljbd_region')->fetch_all_by_upid('','',$k)) { ?>onclick="region_1(<?php echo $k;?>,this)" href="javascript:;"<?php } else { ?>href="<?php echo getaljurl($geturl,array('region'=>$k,'subregion'=>'','region1'=>''))?>"<?php } ?> <?php if($k == $_GET['region']) { ?>class="on"<?php } ?>><?php echo $r['name'];?><?php if(C::t('#aljbd#aljbd_region')->fetch_all_by_upid('','',$k)) { ?><b></b><?php } ?></a>
                        </li>
                        <?php } ?>
                    </ul>
                    <div id="aclist_l_sub" >
                        
                    </div>
                    <div id="aclist_l_subsub" >
                        
                    </div>
                </li>
                <?php } ?>
                <li><a class="spot_l <?php if($_GET['order'] && $_GET['order'] != 'comment') { ?>on<?php } ?>" href="javascript:;"><?php if($_GET['order'] == 'comment') { ?><?php echo $aljbdlang['template']['default'];?><?php } elseif($_GET['order'] == 'dateline') { ?><?php echo $aljbdlang['template']['time'];?><?php } elseif($_GET['order'] == 'view') { ?><?php echo $aljbdlang['template']['Browse_volume'];?><?php } elseif($_GET['order'] == 'buyamount') { ?><?php echo $aljbdlang['template']['Sales_volume'];?><?php } else { ?><?php echo $aljbdlang['template']['sort'];?><?php } ?></a>
                    <ul class="aclist_l hide_l">
                        <li><a <?php if($_GET['order']=="comment" || !$_GET['order']) { ?>class="on"<?php } ?> href="<?php echo getaljurl($geturl,array('order'=>'comment','lat'=>'','lng'=>''))?>">默认</a></li>
                        <li><a <?php if($_GET['order']=="dateline") { ?>class="on"<?php } ?> rel="nofollow" href="<?php echo getaljurl($geturl,array('order'=>'dateline','lat'=>'','lng'=>''))?>">时间</a></li>
                        <li><a <?php if($_GET['order']=="view") { ?>class="on"<?php } ?> rel="nofollow" href="<?php echo getaljurl($geturl,array('order'=>'view','lat'=>'','lng'=>''))?>"><?php if(file_exists("source/plugin/dz_3/dz_3.inc.php")) { ?>&#20154;&#27668;<?php } else { ?>浏览量<?php } ?></a></li>
                        <li><a <?php if($_GET['order']=="price1") { ?>class="on"<?php } ?> rel="nofollow" href="<?php echo getaljurl($geturl,array('order'=>'price1','lat'=>'','lng'=>''))?>">价格</a></li>
                        <?php if($_G['cache']['plugin']['aljgwc'][$pluginid]) { ?>
                        <li><a <?php if($_GET['order']=="buyamount") { ?>class="on"<?php } ?> rel="nofollow" href="<?php echo getaljurl($geturl,array('order'=>'buyamount','lat'=>'','lng'=>''))?>"><?php echo $aljbdlang['template']['Sales_volume'];?></a></li>
                        <?php } ?>
                    </ul>
                </li>
                <?php if($_G['cache']['plugin']['aljsp']['is_sp'] && $_G['cache']['plugin']['aljoss']['Access_Key']) { ?>
                <a class="lj_video <?php if($_GET['v'] == 1) { ?>on<?php } ?> " href="<?php if($_GET['v'] == 1) { echo getaljurl($geturl,array('v'=>''))?><?php } else { echo getaljurl($geturl,array('v'=>'1'))?><?php } ?>">&#35270;&#39057;<i class="iconfont icon-ziyuan3" style="font-size: 12px;margin-left: 3px;"></i></a>
                <?php } ?>
                <a class="lj-more <?php if($settings['is_goodslist_l']['value']==1) { ?>up<?php } else { ?>down<?php } ?>" href="javascript:void(0)"><i></i></a>
                <?php if(!$settings['is_mobile_gheader']['value']) { ?>
                <a class="lj_search" href="plugin.php?id=<?php echo $pluginid;?>&amp;act=search"><i></i></a>
                <?php } ?>
            </ul>
            <?php if(($subtype || $subsubtype) && !$settings['is_type_swiper']['value']) { ?>
            <style>
            .tab-reply-center{
                -webkit-flex-shrink: 0;
                -ms-flex: 0 0 auto;
                flex-shrink: 0;
                width: auto;
                height: 100%;
                position: relative;
                margin: 0px 10px;
            }
            .tab-reply{
                text-align: center;
                color: #999999;
                background: #f2f2f7;
                border-radius: 15px;
                padding:4px 10px;
                font-size: 14px;
            }
            .cur .tab-reply{
                color: #ffffff;
                background: <?php if($color) { ?><?php echo $color;?><?php } else { ?>#f42424<?php } ?>;
            }
            .type_text{
                position: relative;
                width: 100%;
                height: 46px;
                line-height: 46px;
                overflow: hidden;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                padding-left: 15px;
                display: -webkit-box;
                display: -webkit-flex;
                display: flex;
            }
            </style>
            
                <?php if($subsubtype) { ?>
                    <div class="type_text">
                        <div class=" tab-reply-center <?php if(!$_GET['subtype3']) { ?>cur<?php } ?>" >
                            <a class="tab-reply"  href="<?php echo getaljurl($geturl,array('subtype3'=>''));?>"><?php echo $aljbdlang['template']['whole'];?></a>
                        </div>
                        <?php if(is_array($subsubtype)) foreach($subsubtype as $subtypev) { ?>                            <div class=" tab-reply-center <?php if($subtypev['id'] == $_GET['subtype3']) { ?>cur<?php } ?>" >
                                <a class="tab-reply"  href="<?php echo getaljurl($geturl,array('subtype3'=>$subtypev['id']));?>"><?php echo $subtypev['subject'];?></a>
                            </div>
                        <?php } ?>
                    </div>
                    
                <?php } else { ?>
                    <div class="type_text">
                        <div class=" tab-reply-center <?php if(!$_GET['subtype']) { ?>cur<?php } ?>" >
                            <a class="tab-reply"  href="<?php echo getaljurl($geturl,array('subtype'=>'','subtype3'=>''));?>"><?php echo $aljbdlang['template']['whole'];?></a>
                        </div>
                        <?php if(is_array($subtype)) foreach($subtype as $subtypev) { ?>                            <div class=" tab-reply-center <?php if($subtypev['id'] == $_GET['subtype']) { ?>cur<?php } ?>" >
                                <a class="tab-reply" href="<?php echo getaljurl($geturl,array('subtype'=>$subtypev['id']));?>"><?php echo $subtypev['subject'];?></a>
                            </div>
                        <?php } ?>
                    </div>
                <?php } ?>
                <script type="text/javascript">
                //��ȡѡ��Ԫ��
                $(function(){
                    var scrollLeftCur = $('.type_text .cur');
                    $(".type_text").animate({scrollLeft:scrollLeftCur.position().left},300);
                })
                
                </script>
            <?php } ?>
            
        </div>
    </div>
    <?php if(($subtype || $subsubtype) && !$settings['is_type_swiper']['value']) { ?>
        <?php $header_null_h = '86'?>        <div class="header_null" style="height: 86px;display: block;overflow: hidden;clear: both"></div>
    <?php } else { ?>
    <?php $header_null_h = '40'?>        <div class="header_null" style="height: 40px;display: block;overflow: hidden;clear: both"></div>
    <?php } ?>
    
<div id="mask_l" style="display: none;"></div>
<style type="text/css">
    .lj-more,.lj_video,.lj_search{padding-left:1px;background:url(source/plugin/aljbd/template/touch/list/images/bg_nav_line.png) no-repeat 0 center;background-size:1px 20px;width:15%;text-align:center}.down i{background:url(source/plugin/aljbd/template/touch/list/images/icon_more.png) no-repeat center center;background-size:20px 20px;width:20px;height:20px;display:block;margin:10px auto}.up i{background:url(source/plugin/aljbd/template/touch/list/images/icon_horizon.png) no-repeat center center;background-size:20px 20px;width:20px;height:20px;display:block;margin:10px auto}.lj_search i{background:url(source/plugin/aljbd/template/touch/list/images/search.png) no-repeat center center;background-size:20px 20px;width:20px;height:20px;display:block;margin:10px auto}
</style>
    <?php $region_l_url = getaljurl($geturl,array('act'=>'mobile_list_region','region'=>'','subregion'=>'','region1'=>''))?><?php $type_l_url = getaljurl($geturl,array('act'=>'mobile_list_type','type'=>'','subtype'=>'','subtype3'=>''))?><script>
    $(function () {
        var isload = {};
        $('.spot_l').click(function(){
$('.list_nav_l').addClass('pos_l');
            $('.aclist_l').addClass('hide_l');

            var pf = $(this).parent().find('ul');
            
            $(this).addClass('rotate180');
            var status = $('.spot_l').index($(this));
            if(!isload[status]){
                pf.removeClass('hide_l');
                $('.list_nav_l').addClass('pos_l');
                $('.type_text').addClass('hide_l');
                $('#mask_l').show();
isload = {};
                isload[status] = 1;
            }else{
                pf.addClass('hide_l');
                $('.list_nav_l').removeClass('pos_l');
                $('.type_text').removeClass('hide_l');
                $(this).removeClass('rotate180');
                $('#mask_l').hide();
isload = {};
                isload[status] = 0;
            }
        });
        $('#mask_l').click(function () {
            $('.aclist_l').addClass('hide_l');
            $('.type_text').removeClass('hide_l');
$('.list_nav_l').removeClass('pos_l');
            $('#mask_l').hide();
            isload = {};
        });

    });
    function region_1(rid){
        $("#aclist_l_sub").html('<ul class="aclist_l " style="left:50%"><img src="static/image/common/loading.gif" /></ul>');
        $("#aclist_l_subsub").html('');

        $.post('<?php echo $region_l_url;?>',{"region":rid,'brand':'goods'},function(data){
            $("#aclist_l_sub").html(data);
        });
    }
    function subregion_1(rid,subrid){
        $("#aclist_l_subsub").html('<ul class="aclist_l " style="left:80%"><img src="static/image/common/loading.gif" /></ul>');

        $.post('<?php echo $region_l_url;?>',{"region":rid,'sub':'1','subregion':subrid,'brand':'goods'},function(data){
            $("#aclist_l_subsub").html(data);
        });
    }
    function type_1(type,that){
$("#aclist_l_subtype").html('<ul class="aclist_l " style="left:50%"><img src="static/image/common/loading.gif" /></ul>');
$("#aclist_l_subsubtype").html('');
        $('.type_a').removeClass('on');
    $(that).addClass('on');
$.post('<?php echo $type_l_url;?>',{"type":type,'brand':'goods'},function(data){
$("#aclist_l_subtype").html(data);
});
}
function subtype_1(type,subtype,that){
$("#aclist_l_subsubtype").html('<ul class="aclist_l " style="left:80%"><img src="static/image/common/loading.gif" /></ul>');
        $('.subtype_a').removeClass('on');
    $(that).addClass('on');
$.post('<?php echo $type_l_url;?>',{"type":type,'sub':'1','subtype':subtype,'brand':'goods'},function(data){
$("#aclist_l_subsubtype").html(data);
});
}
</script>
<?php } else { ?>
<style type="text/css">
.subject-category-list .a {
  color:red;
}
.subject-category-list h4{border-top: 1px solid #fff;float: left;padding: 10px 0px 10px 10px;text-align: center;font-size: 12px;white-space: nowrap;overflow: hidden;height:37px;}
.subject-category-list-item{height:37px}
</style>
<div class="panel-body" style="padding:0px 0px 10px 0px;">
        <div class="panel-group" style="border-top:0;" id="subject_category">
            <div class="panel-comm panel-white">
                <div class="panel-collapse" style="border-top:0px;border-bottom: 1px dotted #ddd;">
                    <div class="subject-category-list lj_type" <?php if($_GET['type']) { ?>style="border-bottom: 1px dotted #ddd;"<?php } else { ?>style="height:34px;overflow: hidden;"<?php } ?>>
<a href="javascript:;" onclick="lj_type(this)" style="float:right;padding: 10px 10px 10px 0px;text-align: center;font-size: 12px;white-space: nowrap;overflow: hidden;height:37px;" class="lj_type-right"><?php if($_GET['type']) { ?>&#25910;&#36215;<?php } else { ?>更多<?php } ?></a>
<h4 >分类</h4>
<a href="<?php if($config['isrewrite']) { ?>goods_0_0_<?php if($_GET['order']=='price1') { ?>2<?php } elseif($_GET['order']=='view') { ?>1<?php } else { echo intval($_GET['order'])?><?php } ?>_<?php if($_GET['view']=='pic') { ?>3<?php } elseif($_GET['view']=='list') { ?>4<?php } else { echo intval($_GET['view'])?><?php } ?>.html<?php } else { ?>plugin.php?id=aljbd&act=goods&order=<?php echo $_GET['order'];?>&view=<?php echo $_GET['view'];?><?php } ?>" class="subject-category-list-item <?php if(empty($_GET['type'])) { ?>a<?php } ?>">全部</a><?php if(is_array($tlist)) foreach($tlist as $t) { ?>                        <a href="<?php if($config['isrewrite']) { ?>goods_<?php echo $t['id'];?>_0_<?php if($_GET['order']=='price1') { ?>2<?php } elseif($_GET['order']=='view') { ?>1<?php } else { echo intval($_GET['order'])?><?php } ?>_<?php if($_GET['view']=='pic') { ?>3<?php } elseif($_GET['view']=='list') { ?>4<?php } else { echo intval($_GET['view'])?><?php } ?>.html<?php } else { ?>plugin.php?id=aljbd&act=goods&type=<?php echo $t['id'];?>&subtype=0&order=<?php echo $_GET['order'];?>&view=<?php echo $_GET['view'];?><?php } ?>" class="subject-category-list-item <?php if($t['id']==$_GET['type']) { ?>a<?php } ?>"><?php echo $t['subject'];?></a>
                   <?php } ?>
                   </div>
   <?php if($_GET['type']) { $subtypelist=C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($_GET['type']);?><?php if($subtypelist) { ?>
   <div class="subject-category-list" <?php if($_GET['subtype']) { ?>style="border-bottom: 1px dotted #ddd;"<?php } ?>>
<a href="<?php if($config['isrewrite']) { ?>goods_<?php echo intval(0)?>_<?php echo intval(0)?>_<?php if($_GET['order']=='price1') { ?>2<?php } elseif($_GET['order']=='view') { ?>1<?php } else { echo intval($_GET['order'])?><?php } ?>_<?php if($_GET['view']=='pic') { ?>3<?php } elseif($_GET['view']=='list') { ?>4<?php } else { echo intval($_GET['view'])?><?php } ?>.html<?php } else { ?>plugin.php?id=aljbd&act=goods&type=<?php echo intval($_GET['type'])?>&subtype=&order=<?php echo $_GET['order'];?>&view=<?php echo $_GET['view'];?><?php } ?>" class="subject-category-list-item <?php if(empty($_GET['subtype'])) { ?>a<?php } ?>">
                            全部
                        </a><?php if(is_array($subtypelist)) foreach($subtypelist as $tt) { ?>                        <a class="subject-category-list-item <?php if($_GET['subtype']==$tt['id']) { ?>a<?php } ?>" href="<?php if($config['isrewrite']) { ?>goods_<?php echo intval($_GET['type'])?>_<?php echo intval($tt['id'])?>_<?php if($_GET['order']=='price1') { ?>2<?php } elseif($_GET['order']=='view') { ?>1<?php } else { echo intval($_GET['order'])?><?php } ?>_<?php if($_GET['view']=='pic') { ?>3<?php } elseif($_GET['view']=='list') { ?>4<?php } else { echo intval($_GET['view'])?><?php } ?>.html<?php } else { ?>plugin.php?id=aljbd&act=goods&type=<?php echo $_GET['type'];?>&subtype=<?php echo $tt['id'];?>&order=<?php echo $_GET['order'];?>&view=<?php echo $_GET['view'];?><?php } ?>"><?php echo $tt['subject'];?></a>
                   <?php } ?>
                   </div>
   <?php } ?>
   <?php } ?>
   <?php if($_GET['subtype']) { $subtype3list=C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($_GET['subtype']);?><?php if($subtype3list) { ?>
   <div class="subject-category-list">
<a href="plugin.php?id=aljbd&amp;act=goods&amp;type=<?php echo $_GET['type'];?>&amp;subtype=<?php echo $_GET['subtype'];?>&amp;order=<?php echo $_GET['order'];?>&amp;view=<?php echo $_GET['view'];?>" class="subject-category-list-item <?php if(empty($_GET['subtype3'])) { ?>a<?php } ?>">
                            全部
                        </a><?php if(is_array($subtype3list)) foreach($subtype3list as $tt) { ?>                        <a href="plugin.php?id=aljbd&amp;act=goods&amp;type=<?php echo $_GET['type'];?>&amp;subtype=<?php echo $_GET['subtype'];?>&amp;subtype3=<?php echo $tt['id'];?>&amp;order=<?php echo $_GET['order'];?>&amp;view=<?php echo $_GET['view'];?>" class="subject-category-list-item <?php if($_GET['subtype3']==$tt['id']) { ?>a<?php } ?>">
                            <?php echo $tt['subject'];?>
                        </a>
                   <?php } ?>
                   </div>
   <?php } ?>
   <?php } ?>

                </div>
<div class="panel-collapse" style="border-top:0px;">
<div class="subject-category-list region" style="height:34px;overflow: hidden;">
<h4 >排序</h4>
    <a href="plugin.php?id=aljbd&amp;act=goods&amp;type=<?php echo $_GET['type'];?>&amp;subtype=<?php echo $_GET['subtype'];?>&amp;order=comment" class="subject-category-list-item <?php if($_GET['order']=='p'||empty($_GET['order'])) { ?>a<?php } ?>">
                            默认
                        </a>

                        <a href="plugin.php?id=aljbd&amp;act=goods&amp;type=<?php echo $_GET['type'];?>&amp;subtype=<?php echo $_GET['subtype'];?>&amp;order=view" class="subject-category-list-item <?php if($_GET['order']=='view') { ?>a<?php } ?>">
                            浏览量
                        </a>

<a href="plugin.php?id=aljbd&amp;act=goods&amp;type=<?php echo $_GET['type'];?>&amp;subtype=<?php echo $_GET['subtype'];?>&amp;order=price1" class="subject-category-list-item <?php if($_GET['order']=='price1') { ?>a<?php } ?>">
                            价格
                        </a>
                   </div>
                </div>


                </div>
            </div>
<script type="text/javascript">

function lj_type(a) {
if($(".lj_type-right").text()=='更多'){

$(".lj_type-right").html('&#25910;&#36215;');
$(".lj_type").attr("style","height:auto;");
}else{
$(".lj_type-right").html('更多');
$(".lj_type").attr("style","height:34px;overflow: hidden;");
}
}
</script>


       </div>
   <?php } ?>
</div>
<?php if($settings['aljad_glist_top']['value']) { ?>
<div style="width:100%; height:auto;" class="aljbd_ad">
    <?php echo htmlspecialchars_decode($settings['aljad_glist_top']['value']);?></div>
<?php } if($settings['mobile_list_goods_ad']['value']) { ?>
<div style="width:100%; height:auto;" class="aljbd_ad">
   <?php echo htmlspecialchars_decode($settings['mobile_list_goods_ad']['value']);?></div>
<?php } ?>
<div class="panel-body search" style="display:none;padding-bottom:10px;">
    <form action="plugin.php?id=aljbd&amp;act=goods" method="post" enctype="multipart/form-data" accept-charset="utf-8" style="border:1px solid #eee;">
        <input type="hidden" value="<?php echo FORMHASH;?>" name="formhash">
<input type="text" class="search-keyword" name="kw" placeholder="搜商品" value="<?php echo $_GET['kw'];?>">
<input type="submit" class="icon18 icon18-search search-button" value="搜商品" name="submit">
    </form>
</div>
<script type="text/javascript">
$('#search_l').toggle(function(){$('.search').show();},function(){$('.search').hide();});
</script>
<?php if($settings['mobile_list_goods_ad_1']['value']) { ?>
<div style="width:100%; height:auto;" class="aljbd_ad">
   <?php echo htmlspecialchars_decode($settings['mobile_list_goods_ad_1']['value']);?></div>
<?php } ?>
<style type="text/css">
    .c_goods_size{width:96%;margin:5px 2%}.c_goods_size a{display:block;width:100%}.c_goods_details dd a{width:94%;margin:0 3%;line-height:24px;font-size:14px;color:#444;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.c_goods_details dd h2{color:#666;font-size:12px;width:94%;margin:0 3%;line-height:14px}.c_goods_details dd p span{float:right}.c_goods_details{width:100%;overflow:hidden}.c_goods_details dd{width:50%;float:left;position:relative}dd{margin-left:0}*{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.c_new_goods{width:100%;padding-bottom:10px}.c_goods_title{width:100%;height:42px;background:#fff;border-bottom:1px solid #eee}.c_newgoods_title{position:fixed;top:0;left:0;z-index:20}.c_goods_title li{float:left;width:25%;line-height:40px;height:40px;text-align:center;font-size:14px;color:#666}.c_click_see{width:100%;height:36px;line-height:34px;color:#999;margin:0 0 10px 0;border:1px solid #eee;border-radius:2px;font-size:12px;text-align:center;background:#fff;cursor:pointer}.c_goods_title .c_hot_color{color:#dd2726}.c_goods_details dd p{color:#666;font-size:12px;width:90%;margin:0 3% 10px;line-height:14px}#dataList dd{border-bottom:1px solid #eee;border-right:1px solid #eee}.richtxt-img-defaultsize>.fl{width:30%;text-align:center}.t_h4{overflow:hidden;font-weight:400;color:#333;font-size:16px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
</style>
<link rel="stylesheet" media="screen,projection,tv" href="source/plugin/<?php echo $pluginid;?>/template/touch/view/css/label.css?<?php echo VERHASH;?>" /></link>
<style>
    .c_goods_size {
        width: 100%;
        margin:0px 0px 5px 0px;
    }

    .c_goods_details {
        width: 100%;
        border-top: 5px solid #f8f8f8;
        overflow: hidden;
    }
    .c_goods_details dd {
        width: 47%;
        float: left;
        border-bottom: 0px solid #f8f8f8;
        border-left: 0px solid #f8f8f8;
        position: relative;
        border-right: 0px;
        margin-left: 2%;
        margin-bottom: 2%;
        background: #ffffff;
        border-radius: 5px;
    }
    .container-fluid {
        background: #f8f8f8 !important;
    }
    .b-color-f {
        background: #f8f8f8;
    }
    h4.title-hrbg span {
        background: #f8f8f8;
        padding: 10px 6px;
        font-size: 14px;
        z-index: 10;
    }
    .c_goods_details dd p {
        color: #666;
        font-size: 12px;
        width: 90%;
        margin: 5px 5% 8px;
        line-height: 14px;
    }
    .c_goods_details dd a {
        width: 100%;
        margin:0px;
        line-height: 24px;
        font-size: 12px;
        color: #333 !important;
        display: block;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .list-group-item {
        position: relative;
        display: block;
        padding: 10px;
        margin-bottom: -1px;
        background-color: #fff;
        border: 0px solid #f8f8f8;
        margin-top: 10px;
    }

</style>
<div class="list-group list-group-insertmod item-subject-list" id="data_container" <?php if($settings['is_goodslist_l']['value']==1) { ?>style="display:block"<?php } else { ?>style="display:none"<?php } ?>>


</div>
<dl class="c_goods_details" id="dataList" <?php if($settings['is_goodslist_l']['value']==1) { ?>style="display:none"<?php } else { ?>style="display:block"<?php } ?>>

</dl>
<div id="dataMore" class="more">
      <div class="c_clear"></div>
       <div class="c_click_see" id="loading" >
       <img alt="loading" src="source/plugin/aljbd/images/sj/loading2.gif" style="height:30px">
       </div>
   	   <div class="c_click_see" id="more" ><?php echo $aljbdlang['template']['See_more'];?></div>
</div>
</div>
<?php if($settings['mobile_list_goods_ad_2']['value']) { ?>
<div style="width:100%; height:auto;" class="aljbd_ad"><?php echo htmlspecialchars_decode($settings['mobile_list_goods_ad_2']['value']);?></div>
<?php } $page_url = getaljurl($geturl,array('act'=>'mobile_list_goods'))?><script src="source/plugin/<?php echo $pluginid;?>/template/touch/round_robin/round_robin.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<link rel="stylesheet" media="screen,projection,tv" href="source/plugin/<?php echo $pluginid;?>/template/touch/round_robin/round_robin.css?<?php echo VERHASH;?>" /></link>
<script type="text/javascript">

   function lazyload(page) {
//����ͼƬ�ӳټ���  ������Ļ100���ؿ�ʼ����ͼƬ
$("img.lazy" + page).lazyload({
effect: "fadeIn",
placeholder: "<?php echo $loading;?>",
threshold: 100,
failure_limit : 10,
skip_invisible: false
});
}
</script>
<script type="text/javascript">
    var than=2.8;
    var h = document.body.clientWidth/than;
$('.lj-more').click(function(){
if($(this).hasClass("down")){
$(this).removeClass("down").addClass("up");
$("#data_container").show();
$("#dataList").hide();
dynamic();
}else{
$(this).removeClass("up").addClass("down");
$("#data_container").hide();
$("#dataList").show();
dynamic();
}
});
function dynamic(){
//��̬����ͼƬ����
h1 = $(".fl").width()-2;
$('.richtxt-img').css({'height':h1+'px','width':h1+'px','max-height':h1+'px','max-width':h1+'px','margin':'0 auto','display':'block'});
    <?php if($_G['cache']['plugin']['aljbd']['is_mobile_goods_size']) { ?>
    h = $(".c_goods_size").width();
    $('.c_img').css({'height':h+'px','width':h+'px','margin':'0 auto','display':'block'});
    <?php } else { ?>
    h = document.body.clientWidth/than;
    $('.c_goods_size').css({'height':h+'px','overflow':'hidden'});
    <?php } ?>
}
var page=1;
var max=2;
var isload = true;
var html = new Array();
var aljgwc_on = '<?php echo $_G['cache']['plugin']['aljgwc'][$pluginid];?>';
var aljspt_on = '<?php echo $_G['cache']['plugin']['aljspt']['is_aljspt'];?>';
var buyamount = '';
function dataeach(data){
var listarray = new Array();
var html = '';
var shtml = '';
var str = '';
var extunit = '<?php echo $_G['setting']['extcredits'][$config['extcredit']]['title'];?>';
    if(data.bdlist!='' && data.bdlist!=null) {
        $.each(data.bdlist, function (index, val) {
            var hb_html = '';
            if(val.hb_status == 1){
                hb_html = '<img src="source/plugin/aljhb/static/img/hb_icon.png" class="swing" style="width:20px;position: absolute;left:2px;top:2px;">';
            }
            if(val.store_id > 0 && val.commodity_type == 4){
                html += '<a href="plugin.php?id=aljwm&amp;c=food&amp;a=view&amp;store_id=' + val.store_id + '" class="list-group-item navigateTo" data-name="newload">';
            }else{
                html += '<a href="plugin.php?id=aljbd&amp;act=goodview&amp;bid=' + val.bid + '&amp;gid=' + val.id + '" class="list-group-item navigateTo" data-name="newload">';
            }

            html += '<div class="richtxt-comm richtxt-img-defaultsize">';

            <?php if(file_exists("source/plugin/aljhtx/template/touch/video_player.htm") && $_G['cache']['plugin']['aljsp']['is_sp'] && $_G['cache']['plugin']['aljoss']['Access_Key'] && $_GET['v'] == 1) { ?>
                if(typeof val.video_status !== 'undefined' && val.video_status == 1){
                    html += '<div class="fl sd-video-play" style="position: relative;cursor:pointer">'+hb_html;
                    html += '<div class="video_iframe" src="'+val.video_path+'" data-payurl="plugin.php?id=aljbd&amp;act=goodview&amp;bid=' + val.bid + '&amp;gid=' + val.id + '" style="display: none"></div>';
                    html += '<div class="sd_video_li"></div>';
                }else{
                    html += '<div class="fl" style="position: relative">'+hb_html;
                }
            <?php } else { ?>
                html += '<div class="fl" style="position: relative">'+hb_html;
            <?php } ?>

            <?php if($_G['cache']['plugin']['aljstg']['is_aljstg']) { ?>
                <?php include template('aljstg:goods/list_goods_js_label'); ?>            <?php } ?>
            <?php if($_G['cache']['plugin']['aljspt']['is_aljspt']) { ?>
                <?php include template('aljspt:goods/list_goods_js_label'); ?>            <?php } ?>
            <?php if($_G['cache']['plugin']['aljwm']['is_aljwm']) { ?>
            <?php include template('aljwm:goods/list_goods_js_label'); ?>            <?php } ?>
            html += '<img data-original=' + val.pic1 + ' style="width:80px;height:80px;" class="richtxt-img lazy' + page + '">';
            html += '<div class="goods_status goods_status_end_'+val.goods_status+'"></div>';
            html += '</div><div class="richtxt-body"><div style="height:72px;">';
            html += '<h4 class="t_h4" >';

            html += val.name + '</h4>';
            if(typeof val.selling_point !== 'undefined' && val.selling_point){
                html += '<div class="detail-tags" ><div class=" detail-tags-h">';
                for(var i=0; i<val.selling_point.length; i++){
                    html += '<span class="span'+i+' border-global">'+val.selling_point[i]+'</span>';
                }

                html += '</div></div></div>';
            }else{
                html += '<div class="detail-tags" ><div class="brief" >';
                html += val.brief+'</div></div></div>';
            }

            html += '<div>';
            html += '<p class="txt-comm txt-small" style="margin-top:5px;height:18px">';
            var price2 = '';
            <?php if(!file_exists("source/plugin/dz_1/dz_1.inc.php")) { ?>
            var price2 = val.price2 > 0 ? '<s><?php echo $price_unit;?>' + val.price2 + '</s><span class="y">'+val.view + '<?php echo $aljbdlang['template']['follow'];?></span>' : '';
            <?php } ?>
            html += price2;
            <?php if(!file_exists("source/plugin/aljbd/act/skzx.php") && !$settings['is_goods_sales']['value']) { ?>
            if (aljgwc_on && val.buyamount > 0) {
                buyamount = '&#24050;&#21806;' + val.buyamount + '&#20214;';
            }
            <?php } ?>
            

            html += '</p>';
            html += '<p class="txt-comm txt-small">';
            if(parseFloat(val.collage_price) > 0 && val.commodity_type ==2 && aljspt_on){
                <?php if($_G['cache']['plugin']['aljspt']['is_aljspt']) { ?>
                <?php include template('aljspt:goods/list_goods_js_price'); ?>                <?php } ?>
            }else{
                var price1 = parseFloat(val.price1) > 0 ? (aljgwc_on ? '<em style="font-size: 12px;"><?php echo $price_unit;?></em>' + val.price1 : val.price1 + extunit) : '面议';
            }
            html += '<span style="color:#f42424;font-size:18px;">' + price1 + '</span>';
            if(buyamount){
                html += '<span class="y" style="margin-top:3px;">'+buyamount+'</span>';
            }else if(parseFloat(val.price1)>0){
                html += '<span class="y buy_mini" style="margin-top:3px;">立即购买</span>';
            }
            
            
            html += '</p>';
            html += '</div></div></div></a>';
            str += '<dd>';

            <?php if(file_exists("source/plugin/aljhtx/template/touch/video_player.htm") && $_G['cache']['plugin']['aljsp']['is_sp'] && $_G['cache']['plugin']['aljoss']['Access_Key'] && $_GET['v'] == 1) { ?>
                if(typeof val.video_status !== 'undefined' && val.video_status == 1){
                    str += '<div class="c_goods_size sd-video-play" style="position: relative;cursor:pointer">';
                    str += '<div class="video_iframe" src="'+val.video_path+'" data-payurl="plugin.php?id=aljbd&amp;act=goodview&amp;bid=' + val.bid + '&amp;gid=' + val.id + '" style="display: none"></div>';
                    str += '<div class="sd_video_li"></div>';
                }else{
                    str += '<div class="c_goods_size">';
                }
            <?php } else { ?>
                str += '<div class="c_goods_size">';
            <?php } ?>
            str += '<a class="navigateTo" href="plugin.php?id=aljbd&amp;act=goodview&amp;bid=' + val.bid + '&amp;gid=' + val.id + '">';
            str += '<img id="img_' + val.id + '" data-original="' + val.pic1 + '" class="img-responsive lazy' + page + ' c_img" style="width: 100%; display: block;" >';
            str += '<div class="goods_status goods_status_end_'+val.goods_status+'"></div>';
            str += '</a>'+hb_html+'</div><a href="plugin.php?id=aljbd&amp;act=goodview&amp;bid=' + val.bid + '&amp;gid=' + val.id + '">';
            <?php if($_G['cache']['plugin']['aljstg']['is_aljstg']) { ?>
            <?php include template('aljstg:goods/list_goods_js_label_str'); ?>            <?php } ?>
            <?php if($_G['cache']['plugin']['aljspt']['is_aljspt']) { ?>
            <?php include template('aljspt:goods/list_goods_js_label_str'); ?>            <?php } ?>
            <?php if($_G['cache']['plugin']['aljwm']['is_aljwm'] && file_exists("source/plugin/aljwm/template/touch/goods/list_goods_js_label_str.htm")) { ?>
            <?php include template('aljwm:goods/list_goods_js_label_str'); ?>            <?php } ?>
            str += val.name + '</a>';
            if(typeof val.selling_point !== 'undefined' && val.selling_point){
                //console.log(val.selling_point);
                str += '<div class="detail-tags" style="padding:0px 5px"><div class=" detail-tags-h">';
                for(var i=0; i<val.selling_point.length; i++){
                    str += '<span class="span'+i+' border-global">'+val.selling_point[i]+'</span>';
                }

                str += '</div></div>';
            }else{
                str += '<div class="detail-tags" style="padding:0px 5px"><div class="brief">';
                str += val.brief+'</div></div>';
            }
            
            
            
            
            str += '<p><i style="color:#f42424;font-style:normal;font-size: 18px;">' + price1 + '</i></p>';
            if(buyamount){
                var g_fare = '';
                if(val.fare<=0 || val.fare_desc == 1){
                    if(buyamount){
                        g_fare = '&nbsp;包邮';
                    }else{
                        g_fare = '<em>包邮</em>';
                    }
                }
                str += '<p style="height:17px;margin: 5px 5% 5px;">'+buyamount+g_fare+'</p>';
            }
            
            str += '</dd>';
        });
    }
    if (data.max_page) {
        html += data.max_page;
        str += data.max_page;
    }
    listarray['small'] = html;
    listarray['big'] = str;
listarray['s_kw'] = '';
if(data.sbdlist!='' && data.sbdlist!=null){
shtml = '';
$.each(data.sbdlist,function(index,val){

shtml += '<div class="subject-item swiper-slide kw_list" style="width:200px;height:100px;">';
var logo = val.logo ? val.logo : '<?php echo $noimg;?>';
shtml += '<a class="navigateTo" href="plugin.php?id=aljbd&amp;act=view&amp;bid='+val.id+'"><img src="'+logo+'" style="width:80px;height:80px;float:left;margin-right:10px"/><div style="font-size:12px;color: #444;float:right;width:auto;position: relative;overflow: hidden;height: 80px;width: 110px;text-align: left;"><div style="height:50px;overflow: hidden;">'+val.name+'</div><div style="position: absolute;right: 0;bottom: 0px;background: #ec5151;color: #fff;padding: 3px 8px;border: 1px solid #ec5151;font-size: 14px;border-radius: 4px;">&#36827;&#24215;</div></div></a>';
shtml += '</div>';
});

listarray['s_kw'] = shtml;
}
return listarray;
}
function xxx(){
$(window).scroll(function(){

if(isload){
// �жϴ��ڵĹ������Ƿ�ӽ�ҳ��ײ�
if( $(document).scrollTop() + $(window).height() >= $(document).height() - 10 ) {
if($('#max-page').val()){
max=$('#max-page').val();
}
page++;
isload = false;
if(page<=max){
$("#dataMore").show();
$.post('<?php echo $page_url;?>',{'page':page,'kw':'<?php echo $_GET['kw'];?>'},function(data){
if(data==0){
return false;
}else{
html = dataeach(data);
$("#data_container").append(html['small']);
$("#dataList").append(html['big']);
if(data.mes){
//$("#data_container").after(data.mes);
$("#dataList").after(data.mes);
}
if(html.s_kw){
$("#s_kw").append(html.s_kw);
                                
$('#s_kw').css({'padding':'10px 0px 0px 10px','border-bottom':'1px solid #eee'});
scroll_swiper()
}
}
$("#dataMore").hide();
isload = true;
lazyload(page);
dynamic();

}, "json");
}
// �ж���һҳ�����Ƿ�Ϊ��
}
}
});
}
$(function() {
//console.log(1);
$("#dataMore").show();
$.post('<?php echo $page_url;?>',{'page':page,'kw':'<?php echo $_GET['kw'];?>'},function(data){
//console.log(data);
if(data==0){
$("#data_container").append('<a  class="list-group-item" data-name="newload"><?php echo $aljbdlang['js']['Meet_the_conditions'];?></a>');
$("#dataList").append('<a  class="list-group-item" data-name="newload"><?php echo $aljbdlang['js']['Meet_the_conditions'];?></a>');
}else{
html = dataeach(data);
if(html['small'] && html['big']){
                $("#data_container").append(html['small']);
                $("#dataList").append(html['big']);
            }else{
                $("#data_container").append('<a  class="list-group-item" data-name="newload"><?php echo $aljbdlang['js']['Meet_the_conditions'];?></a>');
                $("#dataList").append('<a  class="list-group-item" data-name="newload"><?php echo $aljbdlang['js']['Meet_the_conditions'];?></a>');
            }

if(data.mes){
//$("#data_container").after(data.mes);
$("#dataList").after(data.mes);
}
if(html.s_kw){
$("#s_kw").append(html.s_kw);
$('#s_kw').css({'padding':'10px 0px 0px 10px','border-bottom':'1px solid #eee'});
scroll_swiper()
}
dynamic();
}
$("#dataMore").hide();
lazyload(1);
}, "json");
xxx();
});
$(window).resize(function() {
dynamic();
});

function scroll_swiper(){
var swiper = new Swiper('.swiper-container2', {
scrollbarHide: true,
slidesPerView: 'auto',
centeredSlides: false,
spaceBetween: 10,
grabCursor: true
});
        $(".header_null").css('height','<?php echo $header_null_h+111; ?>px');
}
</script>
<?php if(file_exists("source/plugin/aljhtx/template/touch/video_player.htm") && $_G['cache']['plugin']['aljsp']['is_sp'] && $_G['cache']['plugin']['aljoss']['Access_Key']) { include template('aljhtx:video_player'); } include template('aljbd:footer'); ?></body>
</html>
