<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<script>
    function checkhHtml5()
    {   <?php if($settings['is_img_u']['value']) { ?>
        var is_img_u='1';
        <?php } else { ?>
        var is_img_u='0';
        <?php } ?>
        if(typeof editor !== 'undefined'){
            
            editor.sync();
        }
        if(is_img_u !== '0' && is_img_u !== 'null'){
            $("#compress").val('1');
            $("#admingoodssubmit").attr("enctype", "multipart/form-data");
            $("#admingoodssubmit").attr("encoding", "multipart/form-data");
            $("#admingoodssubmit").submit();
        }else{
            if (typeof(Worker) !== "undefined")
            {
                $("#admingoodssubmit").submit();
            } else
            {   $("#compress").val('1');
                $("#admingoodssubmit").attr("enctype", "multipart/form-data");
                $("#admingoodssubmit").attr("encoding", "multipart/form-data");
                $("#admingoodssubmit").submit();
            }
        }
        
    }
    function lrz_mobile(id,evt){
        file = evt.files[0];


        if (!file.type.match('image.*')) {
            alert('<?php echo $imgmes;?>');
        }

        lrz(file, {
            width:1200,
            before: function() {
                //console.log('start');
            },
            fail: function(err) {
                console.error(err);
            },
            always: function() {
                //console.log('end');
            },
            done: function (results) {
                $('#img_'+id).html('<br/>\u4e0a\u4f20\u4e2d\u8bf7\u7a0d\u540e<img src="static/image/common/loading.gif"/>');

                $('#img_'+id).html('<br/><img src="'+results.base64+'" width="60px" height="60px"><input type="hidden" name="'+id+'"  value="'+results.base64+'"><a href="javascript:;" onclick="delattach(\''+id+'\')" class="upload_delete bw_delimg" id="upload_delete_0" data-index="0"><img src="source/plugin/<?php echo $pluginid_aljbd;?>/images/img_close.png" width="20"></a>');
            }})
    }
    function delattach(id){
        $('#img_'+id).html('<br/>');
        $('#'+id).html('<input type="file" name="'+id+'" style="width:200px;"  onchange="lrz_mobile(\''+id+'\',this)">');
    }
</script>
