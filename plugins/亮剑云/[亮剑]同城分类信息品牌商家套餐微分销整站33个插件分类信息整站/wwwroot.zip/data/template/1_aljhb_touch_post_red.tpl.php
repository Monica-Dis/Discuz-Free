<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); require_once DISCUZ_ROOT.'source/plugin/aljhb/include/common.php';?><script>
    //���������
    function red_packet_post(id,pluginid,module){
        var red_tab = [];
        var url = '';
        if (typeof(module) == "undefined"){
            module = '';
        }else{
            url = '&module='+module;
        }
        <?php if($settings_hb['red_pecket_num']['value']) { ?>
        <?php if(is_array($red_pecket_lists)) foreach($red_pecket_lists as $rv) { ?>        red_tab.push({
            text: '<?php echo $rv['title'];?>',
            onClick: function() {
                $.modal({
                    title: "������ʾ",
                    text: "<?php echo $rv['title'];?>,ƽ̨��ȡ<?php echo $rv['fee'];?>Ԫ�����",
                    buttons: [
                        { text: "ȥ���", onClick: function(){
                            window.location.href = 'plugin.php?id=aljhb&act=pay&hid='+id+'&pluginid='+pluginid+'&price=<?php echo $rv['price'];?>&num=<?php echo $rv['num'];?>'+url;
                        }
                        },
                        { text: "ȡ��", className: "default", onClick: function(){ console.log(3)} },
                    ]
                });
            }
        });
        <?php } ?>
        <?php } else { ?>
        alert('���޿�ѡ������');
        return false;
        <?php } ?>
        $.actions({
            actions: red_tab
        });
    }
    //��������� ����
    function red_packet_post_dg(id,pluginid,module){
        var url = '';
        if (typeof(module) == "undefined"){
            module = '';
        }else{
            url = '&module='+module;
        }
        $.prompt({
            title: '�����',
            text: '���������������<?php echo $perfee;?>%',
            input: '1',
            empty: false, // �Ƿ�����Ϊ��
            onOK: function (input) {
                if(parseFloat(input) < 0.01){
                    alert('����������0');
                    return false;
                }
                //���ȷ��
                window.location.href = 'plugin.php?id=aljhb&act=pay&hid='+id+'&pluginid='+pluginid+'&price='+input+'&num=1'+url;
            },
            onCancel: function () {
                //���ȡ��
            }
        });

    }
</script>