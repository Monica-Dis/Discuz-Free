<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<link rel="stylesheet" href="source/plugin/aljht/static/css/bootstrap.css">
<!-- Font Awesome -->
<link rel="stylesheet" href="source/plugin/aljht/static/css/font-awesome.min.css">
<!-- Ionicons -->
<link rel="stylesheet" href="source/plugin/aljht/static/css/ionicons.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="source/plugin/aljht/static/css/AdminLTE.css">
<link rel="stylesheet" href="source/plugin/aljht/static/css/blue.css">
<link rel="stylesheet" href="source/plugin/aljht/static/js/skin/layer.css">
<!-- AdminLTE Skins. Choose a skin from the css/skins
     folder instead of downloading all of them to reduce the load. -->
<link rel="stylesheet" href="source/plugin/aljht/static/css/skins/_all-skins.min.css">



<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="source/plugin/aljht/static/js/html5shiv.min.js" type="text/javascript"></script>
<script src="source/plugin/aljht/static/js/respond.min.js" type="text/javascript"></script>
<![endif]-->
<!-- jQuery 2.2.3 -->
<script src="source/plugin/aljht/static/js/jquery-2.2.3.min.js" type="text/javascript"></script>
<script src="source/plugin/aljht/static/js/layer.js" type="text/javascript"></script>
<?php if(CHARSET == 'gbk') { ?>
<script src="source/plugin/aljht/static/laydate/laydate_gbk.js" type="text/javascript"></script>
<?php } else { ?>
<script src="source/plugin/aljht/static/laydate/laydate.js" type="text/javascript"></script>
<?php } ?>
<style type="text/css">
    .board {
        background: rgba(0, 0, 0, 0) url("static/image/admincp/bg_repno.gif") no-repeat scroll -240px -550px;
        padding-left: 55px;
        padding-right: 55px;
        position: relative;
    }
    .addtr {
        background: rgba(0, 0, 0, 0) url("static/image/admincp/bg_repno.gif") no-repeat scroll 0 1px;
        color: #f60;
        line-height: 25px;
        padding-left: 17px;
    }
    .deleterow {
        background: rgba(0, 0, 0, 0) url("static/image/admincp/close.gif") no-repeat scroll 0 50%;
        padding-left: 12px;
        color: #fff;
        line-height: 25px;
        margin-right: 5px;
        position: absolute;
        left: 71%;
        top: 5px;
    }
    .lj_right{padding-right: 55px;
        position: relative;}
    .lj_input{width:70%}
</style>
<style>
    .rowform li {
        overflow: hidden;
        float: left;
        margin-right: 10px;
        white-space: nowrap;
        cursor: pointer;
    }
    .rowform ul,.itemtitle ul{
        padding: 0px;
        margin: 0px;
    }
    .itemtitle li{
        display: inline-block;
        padding:2px 10px;
        border-radius: 3px;
    }
    .itemtitle li.current{
        background: #3c8dbc;
        color:#ffffff;

    }
    .itemtitle li.current a{
        color:#ffffff;
    }
    .rowform .radio {
        margin-top: -2px !important;
        display: inline-block;
    }
    .radio, .checkbox, .pr, .pc {
        border: none;
        background: none;
        vertical-align: middle;
    }
    .table-striped > tbody > tr:nth-of-type(odd) {
        background-color: #ffffff;
    }
    .txt{width:320px}
    .color-text{padding-left:0px;padding-top: 5px}
    .rowform select {
        margin-right: 10px;
        width: 256px;
    }
    .txt, select, .vmiddle {
        vertical-align: middle;
    }
    .partition {
        padding: 5px;

        line-height: 21px;
        font-size: 12px;
        color:#3c8dbc;
    }
</style>
<style type="text/css">
    .board {
        background: rgba(0, 0, 0, 0) url("static/image/admincp/bg_repno.gif") no-repeat scroll -240px -550px;
        padding-left: 55px;
        position: relative;
        margin-left:5px;
    }
    .boardnext {
        background: rgba(0, 0, 0, 0) url("static/image/admincp/bg_repno.gif") no-repeat scroll -185px -600px;
        padding-left: 110px;
        position: relative;
        margin-left:5px;
    }
    .addtr {
        background: rgba(0, 0, 0, 0) url("static/image/admincp/bg_repno.gif") no-repeat scroll 0 -598px;
        color: #3c8dbc;
        line-height: 25px;
        padding-left: 17px;
    }
    .deleterow {
        background: rgba(0, 0, 0, 0) url("static/image/admincp/close.gif") no-repeat scroll 0 50%;
        padding-left: 15px;
        color: #fff;
        line-height: 25px;
        margin-right: 5px;

        right:90px;
        top: 6px;
    }

    .lj_right{padding-right: 55px;
        position: relative;}

    .lj_input{
        width:66%;
        border-radius: 6px;
    }

    .sort_input{
        width:50px;
        float:left;
        margin-right:10px;

        border-radius: 6px;
        text-align:center;
    }

    .breadcrumbs{
        margin-bottom: 5px;
        list-style: none;
        margin-left: 30px;

    }
    .breadcrumbs > li {
        display: inline-block;
        padding-right:30px;
        color: #FF6600;
    }
    .submit_bin{
        line-height:1.8;
        margin-left:3%;
        width:65px;
    }
    .nav > li > a {
        position: relative;
        display: block;
        padding: 12px 20px;
    }
    .lj-edit-a{right:10px;top: 8px;}
    .tarea,.txt{border:1px solid #ccc}
    .mailbox-messages{padding:0px 10px}
    .vtop {
        vertical-align: top;
    }
    .td27 {

        font-weight: 700;
    }
    .rowform {
        width: 350px;
    }
    .itemtitle{padding:10px 0px}
    .notic {
        color: #999;
        width: 100%;
        display: block;
        margin-top: 5px;
        line-height: 25px;
    }
    #tipslis{line-height: 30px;}
</style>