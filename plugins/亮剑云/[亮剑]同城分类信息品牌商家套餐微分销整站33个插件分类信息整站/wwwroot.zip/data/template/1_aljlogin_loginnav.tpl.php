<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($setting_aljlogin['dxyz_login']) { ?>
<style>
    .login_nav .title:before {
    position: absolute;
    top: 11px;
    width: 90%;
    left: 50%;
    margin-left: -45%;
    height: 1px;
    background: none;
    content: '';
}
</style>
<?php } ?>
<div class="login_nav" style="padding-bottom:20px;">
    <div class="title">
            <?php if($setting_aljlogin['dxyz_login']) { ?>
            <span><a href="plugin.php?id=aljlogin&amp;act=mobilelogin&amp;referer=<?php echo $urlreferer;?>" style="font-size:12px;text-decoration: underline;color:#333;">&#30701;&#20449;&#39564;&#35777;&#30721;&#30331;&#24405;</a></span>
            <?php } else { ?>
        <span>
            &#24555;&#25463;&#30331;&#24405;&#47;&#27880;&#20876;
        </span>
        <?php } ?>
    </div>
    <ul>
        <?php if($setting_aljlogin['qqurl']) { ?>
        <li class="qq" id="qqlogin">
            <a href="<?php echo $setting_aljlogin['qqurl'];?>&referer=<?php echo $urlreferer;?>">
                <i class="imge icon3"></i>
                &#81;&#81;</a>
        </li>
        <?php } ?>
        <?php if($setting_aljlogin['pcwxurl']) { ?>
        <li class="wx display1" id="wxlogin">
            <a href=" <?php echo $setting_aljlogin['pcwxurl'];?>&referer=<?php echo $urlreferer;?>">
                <i class="imge icon4"></i>
                &#24494;&#20449;</a>
        </li>
        <?php } ?>
        <?php if($setting_aljlogin['wburl']) { ?>
        <li class="wb">
            <a href=" <?php echo $setting_aljlogin['wburl'];?>&referer=<?php echo $urlreferer;?>">
                <i class="imge icon20"></i>
                &#24494;&#21338;</a>
        </li>
        <?php } ?>
        <?php if($_GET['act'] == 'register' || $_GET['act'] == 'forgot') { ?>
        <li class="reg">
            <a href="plugin.php?id=aljlogin&amp;pluginid=<?php echo $pluginid;?>&amp;referer=<?php echo $urlreferer;?>">
                <i class="imge icon5"></i>
                &#30331;&#24405;</a>
        </li>
        <?php } elseif(!$setting_aljlogin['wsq_allow']) { ?>
        <li class="reg">
            <a href="plugin.php?id=aljlogin&amp;act=register&amp;pluginid=<?php echo $pluginid;?>&amp;referer=<?php echo $urlreferer;?>">
                <i class="imge icon5"></i>
                &#27880;&#20876;</a>
        </li>
        <?php } ?>
    </ul>
</div>