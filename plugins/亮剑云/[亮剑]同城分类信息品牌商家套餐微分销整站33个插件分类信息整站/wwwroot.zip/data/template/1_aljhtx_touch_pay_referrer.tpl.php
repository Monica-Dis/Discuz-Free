<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<script>
function get_ios_version(){
var ua = navigator.userAgent.toLowerCase();
var version = null;
if (ua.indexOf("like mac os x") > 0) {
var reg = /os [\d._]+/gi;
var v_info = ua.match(reg);
version = (v_info + "").replace(/[^0-9|_.]/ig, "").replace(/_/ig, "."); //得到版本号9.3.2或者9.0
version = parseInt(version.split('.')[0]); // 得到版本号第一位
}

return version;
}
function get_android_version() {
var ua = navigator.userAgent.toLowerCase();
var version = null;
if (ua.indexOf("android") > 0) {
var reg = /android [\d._]+/gi;
var v_info = ua.match(reg);
version = (v_info + "").replace(/[^0-9|_.]/ig, "").replace(/_/ig, "."); //得到版本号4.2.2
version = parseInt(version.split('.')[0]);// 得到版本号第一位
}

return version;
}
var veriosIos = get_ios_version();

        var veriosAndroid = get_android_version();
if((veriosIos>8 || veriosAndroid>4) && (document.referrer.indexOf("success") != -1 || document.referrer.indexOf("cart_pay") != -1)) {
$(document).ready(function ($) {

if (window.history && window.history.pushState) {

$(window).on('popstate', function () {
var hashLocation = location.hash;
var hashSplit = hashLocation.split("#!/");
var hashName = hashSplit[1];
if (hashName !== '') {
var hash = window.location.hash;
if (hash === '') {
window.history.go(-4); //此处 相当于连续返回4下，跳过 支付页得history
}
}
});

window.history.pushState('forward', null, location.href);
}

});
}
</script>