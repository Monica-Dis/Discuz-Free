<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div class="form-group collage_num" style="display: none">
    <label class="col-sm-3 control-label">拼团人数</label>
    <div class="col-sm-6">
    <input class="form-control " placeholder="拼团人数" name="collage_num" value="<?php echo $goods['collage_num'];?>">
</div>
</div>