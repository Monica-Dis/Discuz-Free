<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template('aljht:admin/iframe_header_common'); ?><div class="content-wrapper">
    <?php if($_GET['ajax'] != 'yes') { ?>
    <section class="content-header">
        <h1>
            分销管理
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo $index_url;?>"><i class="fa fa-dashboard"></i> <?php echo $aljhtlang['template']['brand_31'];?></a></li>
            <li><a href="plugin.php?id=aljht&amp;act=admin"><?php echo $aljhtlang['template']['brand_32'];?></a></li>
            <li class="active">分销管理</li>
        </ol>
    </section>
    <?php } ?>
    <style>
        .num-text{width:60px}
        .box-title {
            display: -webkit-box;
            display: -webkit-flex;
            display: flex;
            width: 100%;
        }
        .box-title a{
            position: relative;
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            flex: 1;
            padding: 13px 15px;
            text-align: center;
            font-size: 15px;
            -webkit-tap-highlight-color: rgba(0,0,0,0);
        }
        .nav_on span {
            color: #f42424 !important;
        }
        .nav_on span:after {
            content: ' ';
            width: 12px;
            height: 4px;
            background: #f42424 !important;
            position: absolute;
            left: 50%;
            bottom: 0px;
            -webkit-transform: translateX(-50%);
            -ms-transform: translateX(-50%);
            transform: translateX(-50%);
            border-radius: 10px;
            transition: all .5s;
            -moz-transition: all .5s;
            -webkit-transition: all .5s;
            -o-transition: all .5s;
        }
    </style>

    <section class="content">
        <div class="callout callout-info" style="background-color: #ffffff !important;">
            <div class="row" style="color: #333 !important;">

                <div class="col-md-12">
                    <div style="padding-bottom: 10px"><span class="fa fa-volume-up" style="margin-right: 5px;color:#0097bc;"></span>
                        点击通过用户微店上线，状态为已审核，用户可正常推广，点击不通过用户微店打回，状态为不通过，可填写理由
                    </div>
                    <div style="padding-bottom: 10px"><span class="fa fa-volume-up" style="margin-right: 5px;color:#0097bc;"></span>
                        支持批量审核通过与批量审核不通过（批量不通过不支持填写理由，填写理由请点击信息后面的不通过）
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- /.col -->
            <?php include template('aljht:admin/distribution/distribution_status'); ?>            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header with-border" style="margin-bottom:10px; ">
                        <div class="box-title">
                            <a href="plugin.php?id=aljht&amp;act=admin&amp;op=<?php echo $op;?>&amp;do=<?php echo $do;?><?php echo $urlmod;?>" class="nav_a <?php if(!$status) { ?>nav_on<?php } ?>"><span>待审核</span></a>
                            <a href="plugin.php?id=aljht&amp;act=admin&amp;op=<?php echo $op;?>&amp;do=<?php echo $do;?>&amp;status=1<?php echo $urlmod;?>" class="nav_a <?php if($status == 1) { ?>nav_on<?php } ?>"><span>已审核</span></a>
                            <a href="plugin.php?id=aljht&amp;act=admin&amp;op=<?php echo $op;?>&amp;do=<?php echo $do;?>&amp;status=3<?php echo $urlmod;?>" class="nav_a <?php if($status == 3) { ?>nav_on<?php } ?>"><span>不通过</span></a>
                            <a href="plugin.php?id=aljht&amp;act=admin&amp;op=<?php echo $op;?>&amp;do=<?php echo $do;?>&amp;status=2<?php echo $urlmod;?>" class="nav_a <?php if($status == 2) { ?>nav_on<?php } ?>"><span>未支付</span></a>
                        </div>
                        <!-- /.box-tools -->
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body no-padding" >
                        <div class="table-responsive mailbox-messages">
                            <iframe style="display:none;" name="submitiframe"></iframe>
                            <form name="cpform" id="admingoodssubmit" method="post" autocomplete="off" action="plugin.php?id=aljht&amp;act=admin&amp;op=<?php echo $op;?>&amp;do=<?php echo $do;?><?php echo $urlmod;?>" target="submitiframe">
                                <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>">
                                <input type="hidden"  value="0" name="sign" id="sign">
                                <table class="table table-hover table-striped">
                                    <tbody>
                                    <tr>
                                        <th></th>
                                        <th >申请人<br/>uid
                                        </th>
                                        <th >店铺名称<br/>店铺等级</th>
                                        <th >姓名<br/>电话</th>
                                        <th >总佣金<br/>已提现佣金<br/><b style="color:red;">可提现佣金</b></th>
                                        <th >已分成佣金<br/>未分成佣金</th>
                                        
                                        <th>店铺图片</th>
                                        <th>微信</th>
                                        <th>申请时间</th>
                                        <th>状态</th>
                                        <th>操作</th>
                                    </tr>
                                    <?php if(is_array($teamList)) foreach($teamList as $key => $value) { ?>                                    <tr>
                                        <td><input type="checkbox" name="delete[<?php echo $value['id'];?>]" value="<?php echo $value['id'];?>"></td>
                                        <td><?php echo $value['username'];?><br/><?php echo $value['uid'];?></td>
                                        <td><?php echo $value['shop_name'];?><br/><?php echo $value['title'];?>&nbsp;<?php echo $value['rankendtimes'];?></td>
                                        <td><?php echo $value['name'];?><br/><?php echo $value['tel'];?></td>
                                        <td>
                                            <?php if($value['total_commission']>0) { ?><?php echo $value['total_commission'];?><?php } else { ?>--<?php } ?>
                                            <br/>
                                            <?php if($value['extraction_commission']>0) { ?>
                                            <?php echo $value['extraction_commission'];?>
                                            <?php } else { ?>
                                            --
                                            <?php } ?>
                                            <br/>
                                            <?php if($value['account_commissions'] - $value['extraction_commission']>0) { ?>
                                            <b style="color:red;"><?php echo sprintf("%.2f",$value['account_commissions'] - $value['extraction_commission']);?></b>
                                            <?php } else { ?>
                                            --
                                            <?php } ?>
                                        </td>
                                        <td>
                                            <?php if($value['account_commissions']>0) { ?><?php echo $value['account_commissions'];?><?php } else { ?>--<?php } ?><br/>
                                            <?php if($value['total_commission']-$value['account_commissions']>0) { ?>
                                            <?php echo sprintf("%.2f",$value['total_commission']-$value['account_commissions']);?>                                            <?php } else { ?>
                                            --
                                            <?php } ?>
                                        </td>
                                        
                                        <td class="mailbox-name">
                                            <?php if($value['shop_img']) { ?>
                                            <img src="<?php echo $value['shop_img'];?>" width="50">
                                            <?php } ?>
                                        </td>
                                        <td class="mailbox-subject" >
                                            <?php if($value['shop_weixin']) { ?>
                                            <img src="<?php echo $value['shop_weixin'];?>" width="50">
                                            <?php } ?>
                                        </td>
                                        <td class="mailbox-subject">
                                            <?php echo $value['timestamp'];?>
                                        </td>

                                        <td class="mailbox-subject">
                                            <?php echo $value['statustext'];?>
                                        </td>
                                        <td>
                                            <a class="edit_btn" href="javascript:;" onclick="layer_iframe('plugin.php?id=aljht&act=admin&op=<?php echo $op;?>&do=add&shop_id=<?php echo $value['id'];?>&ajax=yes','管理员编辑<?php echo $value['shop_name'];?>资料')">编辑</a>
                                            <?php if($value['status'] == 0) { ?>
                                            <a class="edit_btn btn_open" href="javascript:;" data-id="1" cash-id="<?php echo $value['id'];?>"  >通过</a>
                                            <a class="edit_btn btn_open" href="javascript:;" data-id="3" cash-id="<?php echo $value['id'];?>" >不通过</a>
                                            <?php } elseif($value['status'] == 3) { ?>
                                            <a class="edit_btn btn_open" href="javascript:;" data-id="1" cash-id="<?php echo $value['id'];?>">通过</a>
                                            <?php } elseif($value['status'] == 1) { ?>
                                            
                                            <a class="edit_btn" href="javascript:;" onclick="layer_iframe('plugin.php?id=aljht&act=admin&op=<?php echo $op;?>&do=user&shop_uid=<?php echo $value['uid'];?>','<?php echo $value['shop_name'];?>的下级会员')">查看下级</a>
                                            
                                            <?php } ?>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                    </tbody>
                                </table>
                                <!-- /.table -->
                        </div>
                        <!-- /.mail-box-messages -->
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer no-padding">
                        <div class="mailbox-controls">
                            <button type="button" class="btn btn-default btn-sm checkbox-toggle"><i class="fa fa-square-o"></i>
                            </button>
                            <?php if($status == 0 || $status == 3 || $status == 2) { ?>
                            <div class="btn-group">
                                <button type="button" class="btn btn-default btn-sm btn-submit" data-id="3">批量通过</button>
                            </div>
                            <?php } ?>
                            <?php if($status == 0 || $status == 1) { ?>
                            <div class="btn-group">
                                <button type="button" class="btn btn-default btn-sm btn-submit" data-id="4">批量不通过</button>
                            </div>
                            <?php } ?>
                            <?php if($status == 2 || $status == 3) { ?>
                            <div class="btn-group">
                                <button type="button" class="btn btn-default btn-sm btn-submit" data-id="5" style="color: red">批量删除</button>
                            </div>
                            <?php } ?>
                            <?php if($value['status'] == 2 || $value['status'] == 3) { ?>

                            <?php } ?>
                            <?php echo $paging;?>
                        </div>
                    </div>
                    </form>
                </div>
                <!-- /. box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
</div>
<script src="source/plugin/<?php echo $pluginid_aljbd;?>/js/lrz.mobile.min.js" type="text/javascript"></script>
<script>
    var R = {
        spost: function (status,cashid,message) {
            if(typeof message != 'undefined'){
                var data = {
                    'status':status,
                    'cashid':cashid,
                    'message':message,
                    'formhash':'<?php echo FORMHASH;?>',
                }
            }else{
                var data = {
                    'status':status,
                    'cashid':cashid,
                    'formhash':'<?php echo FORMHASH;?>',
                }
            }

            var index = layer.load(1, {
                shade: [0.1,'#fff'] //0.1透明度的白色背景
            });
            $.post('plugin.php?id=aljsfx&a=shopstatus&c=distribution&do=ajax',data,function (res) {
                layer.close(index);
                if(res.code == 1){
                    layer.msg(res.text);
                    location.href=location.href;
                }else{
                    layer.msg(res.text);
                }
            },'json');
        },
        init: function() {
            $(document).on('click','.btn_open',function () {
                var status = $(this).attr('data-id');
                var cashid = $(this).attr('cash-id');
                if(status == 3){
                    layer.prompt({
                        formType: 2,
                        value: '<?php echo $config['tips'];?>',
                        title: '审核不通过理由',
                        area: ['400px', '250px'] //自定义文本域宽高
                    }, function(value, index, elem){
                        R.spost(status,cashid,value);

                    });
                }else{
                    R.spost(status,cashid);
                }
            });
        }
    }
    R.init();
</script>
<script>
    function lrz_mobile(id,evt,dkey){
        file = evt.files[0];

        if (!file.type.match('image.*')) {
            alert('<?php echo $imgmes;?>');
        }
        lrz(file, {
            width:1200,
            before: function() {
                //console.log('start');
            },
            fail: function(err) {
                console.error(err);
            },
            always: function() {
                //console.log('end');
            },
            done: function (results) {
                $('#img_'+id).html('<br/>\u4e0a\u4f20\u4e2d\u8bf7\u7a0d\u540e<img src="static/image/common/loading.gif"/>');

                $('#img_'+id).html('<br/><img src="'+results.base64+'" width="20px" height="20px"><input type="hidden" name="yhz['+dkey+'][logo]"  value="'+results.base64+'"><a href="javascript:;" onclick="delattach(\''+id+'\')" class="upload_delete bw_delimg" id="upload_delete_0" data-index="0"><img src="source/plugin/<?php echo $pluginid_aljbd;?>/images/img_close.png" width="20"></a>');
            }})
    }
    function delattach(id){
        $('#img_'+id).html('<br/>');
        $('#'+id).html('<input type="file" name="'+id+'" style="width:200px;"  onchange="lrz_mobile(\''+id+'\',this)">');
    }
    function tips(info){
        if(info == 0){
            layer.alert('<?php echo $aljhtlang['js']['brand_6'];?>', {icon: 6},function(){
                location.href=location.href;
            });
        }else{
            layer.alert(info, {icon: 6},function(){
                location.href=location.href;
            });
        }
    }
    $('.btn-submit').click(function(){
        $('#sign').val($(this).attr('data-id'));
        if($(this).attr('data-id') == 5){
            layer.confirm('您确认要删除吗', {
                btn: ['<?php echo $aljhtlang['js']['brand_8'];?>'] //按钮
            }, function(){
                layer.msg('删除中', {icon: 16});
                $('#admingoodssubmit').submit();
            });
        }else{
            layer.msg('<?php echo $aljhtlang['js']['brand_9'];?>', {icon: 16});
            $('#admingoodssubmit').submit();
        }
    });
    $(function () {
        //Enable iCheck plugin for checkboxes
        //iCheck for checkbox and radio inputs
        $('.mailbox-messages input[type="checkbox"]').iCheck({
            checkboxClass: 'icheckbox_flat-blue',
            radioClass: 'iradio_flat-blue'
        });

        //Enable check and uncheck all functionality
        $(".checkbox-toggle").click(function () {
            var clicks = $(this).data('clicks');
            if (clicks) {
                //Uncheck all checkboxes
                $(".mailbox-messages input[type='checkbox']").iCheck("uncheck");
                $(".fa", this).removeClass("fa-check-square-o").addClass('fa-square-o');
            } else {
                //Check all checkboxes
                $(".mailbox-messages input[type='checkbox']").iCheck("check");
                $(".fa", this).removeClass("fa-square-o").addClass('fa-check-square-o');
            }
            $(this).data("clicks", !clicks);
        });

        //Handle starring for glyphicon and font awesome
        $(".mailbox-star").click(function (e) {
            e.preventDefault();
            //detect type
            var thisstar = $(this).find("a > i");
            var glyph = thisstar.hasClass("glyphicon");
            var fa = thisstar.hasClass("fa");

            //Switch states
            if (glyph) {
                thisstar.toggleClass("glyphicon-star");
                thisstar.toggleClass("glyphicon-star-empty");
            }

            if (fa) {
                thisstar.toggleClass("fa-star");
                thisstar.toggleClass("fa-star-o");
            }
        });
    });
</script><?php include template('aljht:admin/footer'); ?>