<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<tr ><th class="partition" colspan="15" >&#39318;&#39029;&#35774;&#32622;&#39033;</th></tr>

<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#36718;&#36716;&#22270;&#29255;</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <textarea class="tarea" cols="50"   name="settingsnew[mobile_index_new_lz]" onkeydown="textareakey(this, event)" id="varsnew[mobile_index_new_lz]"  ondblclick="textareasize(this, 1)" rows="6"><?php echo $settings['mobile_index_new_lz']['value'];?></textarea>
</td><td colspan=2>&#26684;&#24335;&#65306;&#38142;&#25509;&#124;&#22270;&#29255;&#36335;&#24452;<br>
    &#19968;&#34892;&#19968;&#20010;
</td></tr>
<tr><td s="1" class="td27" colspan="2">&#39318;&#39029;&#25628;&#32034;&#40664;&#35748;&#25552;&#31034;&#35821;</td></tr>
<tr onmouseover="setfaq(this, 'faq1e8e')" class="noborder">
    <td class="vtop rowform">
        <input type="text" class="txt" value="<?php echo $settings['index_search_tips']['value'];?>" name="settingsnew[index_search_tips]">
    </td>
    <td s="1" class="vtop tips2">&#40664;&#35748;&#65306;&#25214;&#24037;&#20316;&#12289;&#25214;&#25151;&#23376;&#12289;&#25214;&#39034;&#39118;&#36710;</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#36718;&#36716;&#19979;&#26041;&#23548;&#33322;</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <textarea class="tarea" cols="50"  name="settingsnew[mobile_index_new_dh]" onkeydown="textareakey(this, event)" id="varsnew[mobile_index_new_dh]"  ondblclick="textareasize(this, 1)" rows="6"><?php echo $settings['mobile_index_new_dh']['value'];?></textarea>
</td><td colspan=2>&#26684;&#24335;&#65306;&#38142;&#25509;&#124;&#22270;&#29255;&#36335;&#24452;&#124;&#25991;&#23383;&#25551;&#36848;<br/>
    &#19968;&#34892;&#19968;&#20010;
</td></tr>

<tr><td s="1" class="td27" colspan="2">&#21516;&#22478;&#28909;&#28857;&#26631;&#39064;</td></tr>
<tr onmouseover="setfaq(this, 'faq1e8e')" class="noborder">
    <td class="vtop rowform">
        <input type="text" class="txt" value="<?php echo $settings['mobile_index_hot_title']['value'];?>" name="settingsnew[mobile_index_hot_title]">
    </td>
    <td s="1" class="vtop tips2">&#40664;&#35748;&#65306;&#21516;&#22478;&#28909;&#28857;</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#21516;&#22478;&#28909;&#28857;&#20869;&#23481;</td></tr>
<tr class="noborder">
    <td class="vtop rowform">
        <textarea class="tarea" cols="50"  name="settingsnew[mobile_index_hot_text]" onkeydown="textareakey(this, event)" id="varsnew[mobile_index_hot_text]"  ondblclick="textareasize(this, 1)" rows="6"><?php echo $settings['mobile_index_hot_text']['value'];?></textarea>
    </td>
    <td colspan=2>
        &#26684;&#24335;&#65306;&#25991;&#23383;&#124;&#38142;&#25509; <br/>&#19968;&#34892;&#19968;&#20010;
    </td>
</tr>
<tr><td colspan="2" class="td27" s="1">&#21516;&#22478;&#28909;&#28857;&#35843;&#29992;&#25968;&#25454;&#31867;&#22411;</td></tr>
<tr class="noborder">
    <td class="vtop rowform" s="1">
            <select name="settingsnew[mobile_index_hot_type]">
                <option value="0" <?php if(!$settings['mobile_index_hot_type']['value']) { ?>selected<?php } ?>>&#21516;&#22478;&#28909;&#28857;&#20869;&#23481;
                <option value="1" <?php if($settings['mobile_index_hot_type']['value'] == 1) { ?>selected<?php } ?>>&#21516;&#22478;&#28909;&#28857;&#20869;&#23481;&#43;&#26368;&#26032;&#20449;&#24687;&#49;&#48;&#26465;
                <option value="2" <?php if($settings['mobile_index_hot_type']['value'] == 2) { ?>selected<?php } ?>>&#21516;&#22478;&#28909;&#28857;&#20869;&#23481;&#43;&#26368;&#26032;&#38376;&#24215;&#49;&#48;&#26465;
                <option value="3" <?php if($settings['mobile_index_hot_type']['value'] == 3) { ?>selected<?php } ?>>&#21516;&#22478;&#28909;&#28857;&#20869;&#23481;&#43;&#26368;&#26032;&#20449;&#24687;&#49;&#48;&#26465;&#43;&#26368;&#26032;&#38376;&#24215;&#49;&#48;&#26465;
            </select>
        <br></td>
        <td>
            &#38376;&#24215;&#25968;&#25454;&#35843;&#29992;&#38656;&#35201;&#36141;&#20080;&#23433;&#35013;&#21516;&#22478;&#38376;&#24215;&#25554;&#20214;
            <a herf="https://addon.liangjianyun.com/aljtsq/" target="_black">https://addon.liangjianyun.com/aljtsq/</a>
        </td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#39318;&#39029;&#20449;&#24687;&#27969;&#19978;&#26041;&#24191;&#21578;</td></tr>
<tr  class="noborder"><td class="vtop rowform">
    <textarea class="tarea" cols="50"  name="settingsnew[index_list_top_lz_ad]"  id="varsnew[index_list_top_lz_ad]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['index_list_top_lz_ad']['value'];?></textarea>
</td>
    <td>
        &#26222;&#36890;&#24191;&#21578;&#22270;&#29255;&#65306;&#60;&#105;&#109;&#103;&#32;&#115;&#114;&#99;&#61;&#34;&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#97;&#108;&#106;&#116;&#99;&#47;&#105;&#109;&#97;&#103;&#101;&#115;&#47;&#108;&#122;&#95;&#97;&#100;&#95;&#49;&#46;&#112;&#110;&#103;&#34;&#32;&#47;&#62;<br/>
        &#24102;&#38142;&#25509;&#36339;&#36716;&#24191;&#21578;&#22270;&#29255;&#65306;&#60;&#97;&#32;&#104;&#114;&#101;&#102;&#61;&#34;&#35;&#34;&#62;&#60;&#105;&#109;&#103;&#32;&#115;&#114;&#99;&#61;&#34;&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#97;&#108;&#106;&#116;&#99;&#47;&#105;&#109;&#97;&#103;&#101;&#115;&#47;&#108;&#122;&#95;&#97;&#100;&#95;&#49;&#46;&#112;&#110;&#103;&#34;&#32;&#47;&#62;&#60;&#47;&#97;&#62;<br/>
        &#33258;&#21161;&#24191;&#21578;&#65306;&#60;&#115;&#99;&#114;&#105;&#112;&#116;&#32;&#115;&#114;&#99;&#61;&#39;&#112;&#108;&#117;&#103;&#105;&#110;&#46;&#112;&#104;&#112;&#63;&#105;&#100;&#61;&#97;&#108;&#106;&#97;&#100;&#38;&#97;&#99;&#116;&#61;&#103;&#101;&#116;&#97;&#100;&#38;&#107;&#101;&#121;&#110;&#97;&#109;&#101;&#61;&#97;&#108;&#106;&#116;&#99;&#38;&#109;&#111;&#100;&#117;&#108;&#101;&#61;&#105;&#110;&#100;&#101;&#120;&#95;&#108;&#105;&#115;&#116;&#95;&#116;&#111;&#112;&#95;&#108;&#122;&#95;&#97;&#100;&#38;&#104;&#101;&#105;&#103;&#104;&#116;&#61;&#97;&#117;&#116;&#111;&#39;&#62;&#60;&#47;&#115;&#99;&#114;&#105;&#112;&#116;&#62;
        <br/>&#19968;&#34892;&#19968;&#20010;&#65292;&#22810;&#20010;&#36718;&#36716;&#25773;&#25918;
    </td>
</tr>

<tr><td colspan="2" class="td27" s="1">&#39318;&#39029;&#24320;&#21551;&#25512;&#33616;&#21830;&#23478;</td></tr>
<tr class="noborder">
    <td class="vtop rowform" s="1">
            <select name="settingsnew[rec_brand]">
                    <option value="0" <?php if(!$settings['rec_brand']['value']) { ?>selected<?php } ?>>&#19981;&#24320;&#21551;
                    <option value="1" <?php if($settings['rec_brand']['value'] == 1) { ?>selected<?php } ?>>&#25512;&#33616;&#21830;&#23478;&#40;&#21697;&#29260;&#21830;&#23478;&#41;
                    <option value="2" <?php if($settings['rec_brand']['value'] == 2) { ?>selected<?php } ?>>&#25512;&#33616;&#38376;&#24215;&#40;&#21830;&#22280;&#38376;&#24215;&#41;
            </select>
        <br></td>
</tr>

<tr><td s="1" class="td27" colspan="2">&#22270;&#25991;&#24191;&#21578;</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <textarea class="tarea" cols="50"  name="settingsnew[mobile_index_Photo_Ads]" onkeydown="textareakey(this, event)" id="varsnew[mobile_index_Photo_Ads]"  ondblclick="textareasize(this, 1)" rows="6"><?php echo $settings['mobile_index_Photo_Ads']['value'];?></textarea>
</td><td colspan=2>&#19968;&#34892;&#19968;&#20010;<br/>&#26684;&#24335;&#58;&#22823;&#25991;&#23383;&#124;&#23567;&#25991;&#23383;&#124;&#22270;&#29255;&#36335;&#24452;&#124;&#38142;&#25509;<br/><img src="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/WX20180717-152528.png" width="200"/></td></tr>

<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#19977;&#26684;&#24191;&#21578;&#22270;</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <textarea class="tarea" cols="50"  name="settingsnew[mobile_index_ad]" onkeydown="textareakey(this, event)" id="varsnew[mobile_index_ad]"  ondblclick="textareasize(this, 1)" rows="6"><?php echo $settings['mobile_index_ad']['value'];?></textarea>
</td><td colspan=2>&#19968;&#34892;&#19968;&#20010;<br/>&#26684;&#24335;&#65306;&#22270;&#29255;&#36335;&#24452;&#124;&#38142;&#25509;<br/>&#31532;&#19968;&#34892;&#24038;&#36793;&#22823;&#22270;&#25512;&#33616;&#23610;&#23544;&#51;&#48;&#48;&#42;&#51;&#48;&#48;<br/>&#31532;&#20108;&#34892;&#21491;&#36793;&#19978;&#26041;&#22270;&#25512;&#33616;&#23610;&#23544;&#51;&#48;&#48;&#42;&#49;&#52;&#56;<br/>&#31532;&#19977;&#34892;&#21491;&#36793;&#19979;&#26041;&#22270;&#25512;&#33616;&#23610;&#23544;&#51;&#48;&#48;&#42;&#49;&#52;&#56;
</td></tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#19977;&#26684;&#24191;&#21578;&#22270;&#21491;&#36793;&#20004;&#22270;&#20013;&#38388;&#38388;&#36317;</td></tr>
<tr onmouseover="setfaq(this, 'faq1e8e')" class="noborder"><td class="vtop rowform">
    <input type="text" class="txt" value="<?php echo $settings['mobile_index_ad_px']['value'];?>" name="settingsnew[mobile_index_ad_px]"></td><td s="1" class="vtop tips2">&#21333;&#20301;&#65306;&#112;&#120;&#65292;&#35831;&#22635;&#20889;&#25968;&#23383;</td>
</tr>

<tr><td s="1" class="td27" colspan="2">&#83;&#69;&#79;&#26631;&#39064;</td></tr>
<tr onmouseover="setfaq(this, 'faq1e8e')" class="noborder"><td class="vtop rowform">
    <input type="text" class="txt" value="<?php echo $settings['daohang']['value'];?>" name="settingsnew[daohang]"></td><td s="1" class="vtop tips2"></td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#83;&#69;&#79;&#45;&#25551;&#36848;</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <textarea class="tarea" cols="50"  name="settingsnew[description]" onkeydown="textareakey(this, event)" id="varsnew[description]"  ondblclick="textareasize(this, 1)" rows="6"><?php echo $settings['description']['value'];?></textarea>
</td><td colspan=2>&#20998;&#20139;&#40664;&#35748;&#25551;&#36848;
</td></tr>
<tr><td s="1" class="td27" colspan="2">&#40664;&#35748;&#20998;&#20139;&#22270;&#29255;</td></tr>
<tr class="noborder" ><td class="vtop rowform">
<input id="fileIM_0share_logo" style="display:none" name="TMPshare_logo" value="" type="file" class="txt uploadbtn marginbot">
<input id="fileIM_1share_logo" style="display:" name="share_logo" value="<?php echo $share_logo;?>" type="text" class="txt marginbot">
<br><a id="fileIM_0ashare_logo" style="" href="javascript:;" onclick="$('fileIM_1ashare_logo').style.fontWeight = '';this.style.fontWeight = 'bold';$('fileIM_1share_logo').name = 'TMPshare_logo';$('fileIM_0share_logo').name = 'share_logo';$('fileIM_0share_logo').style.display = '';$('fileIM_1share_logo').style.display = 'none'">&#19978;&#20256;&#25991;&#20214;</a>&nbsp;<a id="fileIM_1ashare_logo" style="font-weight:bold" href="javascript:;" onclick="$('fileIM_0ashare_logo').style.fontWeight = '';this.style.fontWeight = 'bold';$('fileIM_0share_logo').name = 'TMPshare_logo';$('fileIM_1share_logo').name = 'share_logo';$('fileIM_1share_logo').style.display = '';$('fileIM_0share_logo').style.display = 'none'">&#36755;&#20837;&#32;&#85;&#82;&#76;</a></td>

<?php if($share_logo) { ?>
<td class="vtop tips2" s="1"><label><input type="checkbox" class="checkbox" name="deleteshare_logo" value="yes"> &#21024;&#38500;</label><br><img src="<?php echo $share_logo;?>" height="60px"><br></td>
<?php } ?>
</tr>