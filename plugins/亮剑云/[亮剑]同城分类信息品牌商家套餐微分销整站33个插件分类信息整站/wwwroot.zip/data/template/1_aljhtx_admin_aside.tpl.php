<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template(PLUGIN_ID.':stylecss')?><aside class="main-sidebar">
<!-- sidebar: style can be found in sidebar.less -->
<section class="sidebar">
    <!-- Sidebar user panel -->
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu">
<!--
        <li class="<?php if($op == 'aljqb' || !$op) { ?>active<?php } ?> treeview">
            <a href="#">
                <span>钱包</span>
                <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
            </a>
            <ul class="treeview-menu">
                <li <?php if(!$do) { ?>class="active"<?php } ?> data-url="plugin.php?id=aljht&amp;act=admin&amp;op=orderlist"><a href="javascript:;">订单管理</a></li>
                <li <?php if($do == 'walletuser') { ?>class="active"<?php } ?> data-url="plugin.php?id=aljht&amp;act=admin&amp;op=orderlist"><a href="javascript:;">订单管理2</a></li>

            </ul>
        </li>
        <li class="<?php if($op == 'aljbd') { ?>active<?php } ?> treeview">
            <a href="#">
                <span>品牌商家</span>
                <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
            </a>
            <ul class="treeview-menu">
                <li <?php if(!$do) { ?>class="active"<?php } ?>><a href="<?php echo $pluginurl;?>&act=admin&op=aljqb&identity=aljqb"> 系统设置</a></li>
                <li <?php if($do == 'walletuser') { ?>class="active"<?php } ?>><a href="<?php echo $pluginurl;?>&act=admin&op=aljqb&do=walletuser&identity=aljqb"> 钱包用户</a></li>
                <li <?php if($do == 'secretkey') { ?>class="active"<?php } ?>><a href="<?php echo $pluginurl;?>&act=admin&op=aljqb&do=secretkey&identity=aljqb"> 插件秘钥设置</a></li>
                <li <?php if($do == 'paysetting') { ?>class="active"<?php } ?>><a href="<?php echo $pluginurl;?>&act=admin&op=aljqb&do=paysetting&identity=aljqb"> 支付设置</a></li>
                <li <?php if($do == 'diary') { ?>class="active"<?php } ?>><a href="<?php echo $pluginurl;?>&act=admin&op=aljqb&do=diary&identity=aljqb"> 帐户明细</a></li>
                <li <?php if($do == 'order') { ?>class="active"<?php } ?>><a href="<?php echo $pluginurl;?>&act=admin&op=aljqb&do=order&identity=aljqb"> 申请记录</a></li>
                <li <?php if($do == 'rechargelog') { ?>class="active"<?php } ?>><a href="<?php echo $pluginurl;?>&act=admin&op=aljqb&do=rechargelog&identity=aljqb"> 充值记录</a></li>
                <li <?php if($do == 'cashierlog') { ?>class="active"<?php } ?>><a href="<?php echo $pluginurl;?>&act=admin&op=aljqb&do=cashierlog&identity=aljqb"> 收银日记</a></li>
                <li <?php if($do == 'errorlog') { ?>class="active"<?php } ?>><a href="<?php echo $pluginurl;?>&act=admin&op=aljqb&do=errorlog&identity=aljqb"> 报错日志</a></li>
            </ul>
        </li>

          -->
          <?php $sidearray = Page::loadConfig('first_nav');?>        <?php if(is_array($sidearray[$_GET['type']]['nav'])) foreach($sidearray[$_GET['type']]['nav'] as $onek => $onev) { ?><li class="<?php if(($onek==0 && !$_GET['onek']) || $onek==$_GET['onek']) { ?>active<?php } ?> treeview">
            <a href="#">
                <?php echo $onev['icon'];?><span><?php echo $onev['name'];?></span>
                <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
            </a>
            <ul class="treeview-menu">

                <?php if(is_array($onev['navlist'])) foreach($onev['navlist'] as $twok => $twov) { ?>                <?php if($twov['is_open'] == 1) { ?>
                <li <?php if(($twok == 0 && !$_GET['twok']) || $_GET['twok'] == $twok) { ?>class="active"<?php } ?> data-url="<?php echo $twov['url'];?>"><a href="javascript:;"> <?php echo $twov['icon'];?><?php echo $twov['name'];?></a></li>
                <?php } ?>
                <?php } ?>
            </ul>
        </li>
        <?php } ?>

</section>
<!-- /.sidebar -->
</aside>
<style>
.content-wrapper{top:0px}
.main-sidebar{padding-top:0px}
</style>
<style>
    .rowform li {
        overflow: hidden;
        float: left;
        margin-right: 10px;
        white-space: nowrap;
        cursor: pointer;
    }
    .rowform ul,.itemtitle ul{
        padding: 0px;
        margin: 0px;
    }
    .itemtitle li{
        display: inline-block;
        padding:2px 10px;
        border-radius: 3px;
    }
    .itemtitle li.current{
        background: #3c8dbc;
        color:#ffffff;

    }
    .itemtitle li.current a{
        color:#ffffff;
    }
    .rowform .radio {
        margin-top: -2px !important;
        display: inline-block;
    }
    .radio, .checkbox, .pr, .pc {
        border: none;
        background: none;
        vertical-align: middle;
    }
    .table-striped > tbody > tr:nth-of-type(odd) {
        background-color: #ffffff;
    }
    .txt{width:320px}
    .color-text{padding-left:0px;padding-top: 5px}
    .rowform select {
        margin-right: 10px;
        width: 256px;
    }
    .txt, select, .vmiddle {
        vertical-align: middle;
    }
    .partition {
        padding: 5px;
        line-height: 21px;
        font-size: 12px;
        color:#3c8dbc;
    }
</style>
<style type="text/css">
    .board {
        background: rgba(0, 0, 0, 0) url("static/image/admincp/bg_repno.gif") no-repeat scroll -240px -550px;
        padding-left: 55px;
        position: relative;
        margin-left:5px;
    }
    .boardnext {
        background: rgba(0, 0, 0, 0) url("static/image/admincp/bg_repno.gif") no-repeat scroll -185px -600px;
        padding-left: 110px;
        position: relative;
        margin-left:5px;
    }
    .addtr {
        background: rgba(0, 0, 0, 0) url("static/image/admincp/bg_repno.gif") no-repeat scroll 0 -598px;
        color: #3c8dbc;
        line-height: 25px;
        padding-left: 17px;
    }
    .deleterow {
        background: rgba(0, 0, 0, 0) url("static/image/admincp/close.gif") no-repeat scroll 0 50%;
        padding-left: 15px;
        color: #fff;
        line-height: 25px;
        margin-right: 5px;

        right:90px;
        top: 6px;
    }

    .lj_right{padding-right: 55px;
        position: relative;}

    .lj_input{
        width:66%;
        border-radius: 6px;
    }

    .sort_input{
        width:50px;
        float:left;
        margin-right:10px;

        border-radius: 6px;
        text-align:center;
    }

    .breadcrumbs{
        margin-bottom: 5px;
        list-style: none;
        margin-left: 30px;

    }
    .breadcrumbs > li {
        display: inline-block;
        padding-right:30px;
        color: #FF6600;
    }
    .submit_bin{
        line-height:1.8;
        margin-left:3%;
        width:65px;
    }
    .nav > li > a {
        position: relative;
        display: block;
        padding: 12px 20px;
    }
    .lj-edit-a{right:10px;top: 8px;}
</style>
