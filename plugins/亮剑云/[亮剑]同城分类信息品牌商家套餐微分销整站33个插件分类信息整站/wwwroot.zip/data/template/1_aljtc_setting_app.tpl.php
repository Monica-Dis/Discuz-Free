<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<tr ><th class="partition" colspan="15" >APP</th></tr>

<tr><td colspan="2" class="td27" s="1">&#65;&#80;&#80;&#20869;&#38544;&#34255;&#36864;&#20986;&#25353;&#38062;</td></tr>
<tr class="noborder">
    <td class="vtop rowform" s="1">
        <ul onmouseover="altStyle(this);">
            <li class="checked">
                <input type="radio"  value="1"  <?php if($settings['hidelogout']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[hidelogout]" class="radio">&nbsp;&#26159;
            </li>
            <li><input type="radio" value="0" <?php if($settings['hidelogout']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[hidelogout]" class="radio">&nbsp;&#21542;</li>
        </ul>
        <br>
    </td>
    <td>&#25903;&#25345;&#20142;&#21073;&#12289;&#23433;&#31859;&#12289;&#39532;&#30002;&#12289;&#21315;&#24070;&#32;&#65;&#80;&#80;&#20869;&#38544;&#34255;&#36864;&#20986;&#25353;&#38062;</td>
</tr>