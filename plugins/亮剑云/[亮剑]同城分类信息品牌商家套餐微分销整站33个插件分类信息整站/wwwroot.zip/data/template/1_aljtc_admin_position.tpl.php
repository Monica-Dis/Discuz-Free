<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<style>
.sp {
    position: relative;
    display: inline-block;
    background: #fff;
}
.imgi {
    height: 20px;
    vertical-align: middle;
    cursor: pointer;
}
.imgprevew {
    position: absolute;
    z-index: 9;
    display: none;
    border: 2px solid #fff;
    box-shadow: 0 2px 1px rgba(0,0,0,0.2);
}
#icon1{
width: 400px;
}

</style>
<style>.copybtn{margin-left:5px;}</style>
<script src="source/plugin/aljtc/static/js/jquery.min.js" type="text/javascript"></script>
<script src="source/plugin/aljtc/static/js/lrz.mobile.min.js" type="text/javascript"></script>
<script type="text/javascript">
var jq = jQuery.noConflict();
</script>
<table class="tb tb2 ">
        <tbody>
            <tr><th class="partition">&#25216;&#24039;&#25552;&#31034;</th></tr>
            <tr>
                <td class="tipsblock">
                    <ul id="tipslis">
                        <li>&#26412;&#39029;&#38754;&#25903;&#25345;&#19977;&#32423;&#20998;&#31867;&#21450;&#21069;&#20108;&#32423;&#20998;&#39029;&#33258;&#23450;&#20041;&#34920;&#21333;</li>
                        <li>&#40664;&#35748;&#20998;&#39029;&#56;&#65292;&#22914;&#36935;&#21040;&#20998;&#31867;&#36807;&#22810;&#26080;&#27861;&#28155;&#21152;&#26102;&#65292;&#35831;&#21040;&#24120;&#29992;&#35774;&#32622;&#26368;&#21518;&#38754;&#20998;&#31867;&#20998;&#39029;&#25968;&#35774;&#32622;&#19968;&#20010;&#27604;&#56;&#23567;&#30340;&#25968;&#20540;&#20877;&#28155;&#21152;&#25552;&#20132;</li>

                    </ul>
                </td>
            </tr>
        </tbody>
    </table>
<div style="height:30px;line-height:30px;padding-left: 10px;">
<a href="javascript:;" onclick="show_all()">&#20840;&#37096;&#23637;&#24320;</a> | <a href="javascript:;" onclick="hide_all()">&#20840;&#37096;&#25240;&#21472;</a>
</div>
<form name="cpform" method="post" autocomplete="off" action="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=aljtc&pmod=position&page=<?php echo $_GET['page'];?>" id="cpform">
<input type="hidden" name="formhash" value="<?php echo FORMHASH;?>">
<table class="tb tb2 ">
<tbody>
<tr class="header">
<th></th>
<th>&#25490;&#24207;</th>
<th>&#21517;&#31216;</th>
<th style="width: 15%;">&#22270;&#26631;</th>
<th >&#25805;&#20316;</th>
</tr><?php if(is_array($position)) foreach($position as $tmp_key => $tmp_value) { ?><tr class="hover">
<td  class="td25" onclick="toggle_group('group_<?php echo $tmp_value['id'];?>', $('a_group_<?php echo $tmp_value['id'];?>'))"><a id="a_group_<?php echo $tmp_value['id'];?>" href="javascript:;">[-]</a></td>
<td class="td25">
<input type="text" class="txt" name="order[<?php echo $tmp_value['id'];?>]" value="<?php echo $tmp_value['displayorder'];?>">
</td>
<td>
<div class="parentboard">
<input type="text" class="txt" name="name[<?php echo $tmp_value['id'];?>]" value="<?php echo $tmp_value['subject'];?>">
</div>
</td>
<td class="td25">
<input class="short" name="fileimg" type="file" style="width: 64px;" onchange="upload(this,<?php echo $tmp_value['id'];?>)">
<span class="sp">
<?php if($tmp_value['logo']) { ?>
     <img class="imgi" src="<?php echo $tmp_value['logo'];?>" onmouseover="showimg(this,1);" onmouseout="showimg(this,2);">
     <img id="icon1" src="<?php echo $tmp_value['logo'];?>" class="imgprevew" style="display: none;">
     		<label>
     			&nbsp;&nbsp;&nbsp;
     			<a onclick="delimg(this,<?php echo $tmp_value['id'];?>)" href="###">&#21024;&#63;</if>
     		</label>
     		<?php } ?>
 				</span>
</td>
<td >
<a onclick="del(<?php echo $tmp_value['id'];?>)" href="###">&#21024;&#38500;</a>
&nbsp;
<a  href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=aljtc&pmod=position&act=customlist&typeid=<?php echo $tmp_value['id'];?>">&#33258;&#23450;&#20041;&#34920;&#21333;</a>
&nbsp;
<a  href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=aljtc&pmod=position&act=settings&typeid=<?php echo $tmp_value['id'];?>">&#24120;&#29992;&#35774;&#32622;</a>
&nbsp;
<?php if($tmp_value['is_open'] == 1) { ?>
<a  href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=aljtc&pmod=position&act=open&typeid=<?php echo $tmp_value['id'];?>&oid=0">&#24320;&#21551;</a>
<?php } else { ?>
<a  href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=aljtc&pmod=position&act=open&typeid=<?php echo $tmp_value['id'];?>&oid=1" style="color:red;">&#20851;&#38381;</a>
<?php } ?>
<span class="copybtn" data-clipboard-text="<?php echo rtrim($_G['siteurl'],'/'); ?>/plugin.php?id=aljtc&act=list&zufangtype=<?php echo $tmp_value['id'];?>" href="javascript:;"><a href="javascript:;">&#22797;&#21046;&#38142;&#25509;</a></span>
</td>
</tr>
<tbody id="group_<?php echo $tmp_value['id'];?>"><?php $subtype = getsubtype($tmp_value['id'])?><?php if($subtype) { if(is_array($subtype)) foreach($subtype as $tmp_key_first => $tmp_value_first) { ?><tr>
<td  class="td25">&nbsp;</td>
<td colspan="1" class="td25">
<input type="text" class="txt" name="order[<?php echo $tmp_value_first['id'];?>]" value="<?php echo $tmp_value_first['displayorder'];?>">
</td>
<td colspan="2">
<div class="board">
<input name="name[<?php echo $tmp_value_first['id'];?>]" value="<?php echo $tmp_value_first['subject'];?>" size="20" type="text" class="txt">
<a class="addchildboard" onclick="addrowdirect = 1;addrow(this, 2,<?php echo $tmp_value_first['id'];?>);" href="###">&#28155;&#21152;&#31532;&#19977;&#32423;&#20998;&#31867;</a>
</div>
</td>
<td>
<a onclick="del(<?php echo $tmp_value_first['id'];?>)" href="###">&#21024;&#38500;</a>
<a  href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=aljtc&pmod=position&act=customlist&typeid=<?php echo $tmp_value_first['id'];?>">&#33258;&#23450;&#20041;&#34920;&#21333;</a>
&nbsp;
<a  href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=aljtc&pmod=position&act=settings&typeid=<?php echo $tmp_value_first['id'];?>">&#24120;&#29992;&#35774;&#32622;</a>
<?php if($tmp_value_first['is_open'] == 1) { ?>
<a  href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=aljtc&pmod=position&act=open&typeid=<?php echo $tmp_value_first['id'];?>&oid=0">&#24320;&#21551;</a>
<?php } else { ?>
<a  href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=aljtc&pmod=position&act=open&typeid=<?php echo $tmp_value_first['id'];?>&oid=1" style="color:red;">&#20851;&#38381;</a>
<?php } ?>
<span class="copybtn" data-clipboard-text="<?php echo rtrim($_G['siteurl'],'/'); ?>/plugin.php?id=aljtc&act=list&zufangtype=<?php echo $tmp_value['id'];?>&subtype=<?php echo $tmp_value_first['id'];?>" href="javascript:;"><a href="javascript:;">&#22797;&#21046;&#38142;&#25509;</a></span>
</td>
</tr><?php $thirdtype = getsubtype($tmp_value_first['id'])?><?php if($thirdtype) { if(is_array($thirdtype)) foreach($thirdtype as $tmp_key_second => $tmp_value_second) { ?><tr class="hover">
<td  class="td25">&nbsp;</td>
<td class="td25">
<input type="text" class="txt" name="order[<?php echo $tmp_value_second['id'];?>]" value="<?php echo $tmp_value_second['displayorder'];?>">
</td>
<td colspan="2">
<div class="childboard">
<input type="text" class="txt" name="name[<?php echo $tmp_value_second['id'];?>]" value="<?php echo $tmp_value_second['subject'];?>">
</div>
</td>
<td >
<a onclick="del(<?php echo $tmp_value_second['id'];?>)" href="###">&#21024;&#38500;</a>
<?php if($tmp_value_second['is_open'] == 1) { ?>
<a  href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=aljtc&pmod=position&act=open&typeid=<?php echo $tmp_value_second['id'];?>&oid=0">&#24320;&#21551;</a>
<?php } else { ?>
<a  href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=aljtc&pmod=position&act=open&typeid=<?php echo $tmp_value_second['id'];?>&oid=1" style="color:red;">&#20851;&#38381;</a>
<?php } ?>
<span class="copybtn" data-clipboard-text="<?php echo rtrim($_G['siteurl'],'/'); ?>/plugin.php?id=aljtc&act=list&subsubtype=<?php echo $tmp_value_second['id'];?>&zufangtype=<?php echo $tmp_value['id'];?>&subtype=<?php echo $tmp_value_first['id'];?>" href="javascript:;"><a href="javascript:;">&#22797;&#21046;&#38142;&#25509;</a></span>
</td>
</tr>
<?php } } } } ?>
<tr class="hover">
<td class="td25">&nbsp;</td>
<td colspan="3">
<div class="lastboard">
<a href="###" onclick="addrow(this,1,<?php echo $tmp_value['id'];?>)" class="addtr">&#28155;&#21152;&#20998;&#31867;</a>
</div>
</td>
</tr>
</tbody>
<?php } ?>

<tr class="hover">
<td class="td25">&nbsp;</td>
<td colspan="2">
<div>
<a href="###" onclick="addrow(this,0)" class="addtr">&#28155;&#21152;</a>
</div>
</td>
</tr>
<tr>
<td colspan="15">
<div class="cuspages right"><?php echo $paging;?></div>
<div class="fixsel"><input type="submit" class="btn" id="submit_editsubmit" name="editsubmit"  value="&#25552;&#20132;"></div>
</td>

</tr>
</tbody>
</table>
</form>
<script>
var rowtypedata = [
[[1,'<input type="text" class="txt" name="newcatorder[]" value="0" />', 'td25'], [3, '<input name="newcat[]" value="" size="20" type="text" class="txt" />']],
[[1,'<input type="text" class="txt" name="newsuborder[{1}][]" value="0" />', 'td25'], [3, '<div class="board"><input name="newsubcat[{1}][]" value="" size="20" type="text" class="txt" /></div>']],
[[1,'<input type="text" class="txt" name="newsuborder[{1}][]" value="0" />', 'td25'], [3, '<div class="childboard"><input name="newsubcat[{1}][]" value="" size="20" type="text" class="txt" /></div>']],

];
function showimg(e,imgid) {
if(imgid == 1) {
jq(e).next().show();
}else {
jq(e).next().hide();
}
}
function delimg(e,id) {
var span = jq(e).parent().parent();
var url = 'plugin.php?id=aljtc&act=delimg&adminedit=yes';
var data ={'imgid':id};
jq.get(url,data,function(res) {
if(res == 1) {
alert('\u5220\u9664\u6210\u529f');
span.html('');
}else{
alert('\u5220\u9664\u5931\u8d25');
}
});
}
function upload(e,id){
var file = e.files[0];
var filesize = file.size;
var size = filesize/1024/1024;
var type = file.name.split('.')[1];
if (!file.type.match('image.*')) {
alert('\u6587\u4ef6\u7c7b\u578b\u9519\u8bef');
   return;
}
lrz(file, {
width:1200,
before: function() {
},
done: function (results) {
   var url ='plugin.php?id=aljtc&act=upimg&adminedit=yes';
   var data = {'base64':results.base64,'imgid':id};
   jq.post(url,data,function(res) {
   	  if(res == 1) {
   	  	alert('\u4e0a\u4f20\u6210\u529f');
   	  	var datadom = '<img class="imgi" src="'+results.base64+'" onmouseover="showimg(this,1);" onmouseout="showimg(this,2);">'+
     '<img id="icon1" src="'+results.base64+'" class="imgprevew" style="display: none;">'+
     		'<label>&nbsp;&nbsp;&nbsp;'+
     			'<a onclick="delimg(this,'+id+')" href="###">&#21024;&#63;</label>';
     		jq(e).next().html('');
     		jq(e).next().append(datadom);
   	  }else {
   	  	alert('\u4e0a\u4f20\u5931\u8d25');
   	  }
   });
}
})
}
function del(id) {
if(confirm('\u786e\u8ba4\u5220\u9664\u5417\uff1f')) {
window.location = '<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=aljtc&pmod=position&act=del&page=<?php echo $_GET['page'];?>&tid='+id;
} else {
return false;
}
}
</script>
<script src="source/plugin/aljhtx/static/js/clipboard.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<script>
//һ������
var show = true;
var clipboard = new Clipboard('.copybtn');
clipboard.on('success', function (e) {
if(show) {
alert('\u590d\u5236\u6210\u529f');
show = false;
setTimeout(function () {
show = true;
}, 1000);
}

});
clipboard.on('error', function (e) {
if(show) {
alert('\u590d\u5236\u5931\u8d25');
show = false;
setTimeout(function () {
show = true;
}, 1000);
}
});
</script>