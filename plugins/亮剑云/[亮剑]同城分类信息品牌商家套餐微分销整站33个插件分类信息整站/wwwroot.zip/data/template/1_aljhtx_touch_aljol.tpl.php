<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?><?php
$return = <<<EOF


EOF;
 if($_G['cache']['plugin']['aljhtx']['is_mobile_global_aljol_lr']) { 
$return .= <<<EOF

<style>
    .aljol-layui-layer-shade {
        position: fixed;
        _position: absolute;
        pointer-events: auto;
        -webkit-overflow-scrolling: touch;
        margin: 0;
        padding: 0;
        top:auto;
        right:10px;
        transition: all .2s ease;
        transform: translateX(40px);
        -webkit-transition: all .2s ease;
        -webkit-transform: translateX(40px);
        -webkit-background-clip: content;
        z-index: 50000;
    }
</style>

EOF;
 } else { 
$return .= <<<EOF

<style>
    .aljol-layui-layer-shade {
        position: fixed;
        _position: absolute;
        pointer-events: auto;
        -webkit-overflow-scrolling: touch;
        margin: 0;
        padding: 0;
        top:auto;
        left:10px;
        transition: all .2s ease;
        transform: translateX(-40px);
        -webkit-transition: all .2s ease;
        -webkit-transform: translateX(-40px);
        -webkit-background-clip: content;
        z-index: 50000;
    }
</style>

EOF;
 } 
$return .= <<<EOF

<style>
    .aljol-layui-layer-shade {
        bottom:80px;
    }
    .aljol-commom-nav-show {
        transform: translateX(0px);
        -webkit-transform: translateX(0px);
    }
    .aljol-layui-layer-shade img{
        width:40px;
        height:40px;
        border-radius: 50%;
    }
    .ajlol-order-numbers {
        display: inline-block;
        text-align: center;
        position: absolute;
        bottom: 35px;
        background-color: #f23030;
        height: 14px;
        line-height: 14px;
        padding-left: 5px;
        padding-right: 5px;
        font-style: normal;
        border-radius: 12px;
        right: -8px;
        font-size: 9px;
        color: #fff;
        font-family: PingFangSC-Regular,Helvetica,"Droid Sans",Arial,sans-serif;
        border:1px solid #fff
    }
</style>

EOF;
 if($_G['cache']['plugin']['aljhtx']['is_mobile_global_aljol_bottom']) { 
$return .= <<<EOF

<style>.aljol-layui-layer-shade {bottom:{$_G['cache']['plugin']['aljhtx']['is_mobile_global_aljol_bottom']}px;}</style>

EOF;
 } 
$return .= <<<EOF


<a href="plugin.php?id=aljol"  class="aljol-layui-layer-shade">
    {$avatar}
    <div class="aljol-newscount">
        
EOF;
 if($newsCount) { 
$return .= <<<EOF
<i class="ajlol-order-numbers">{$newsCount}</i>
EOF;
 } 
$return .= <<<EOF

    </div>
</a>
<script>

    OL = {
        voice_aljol: function() {
            var audio = document.createElement("audio");
            audio.src = '{$_G['cache']['plugin']['aljol']['mp3']}';
            audio.play();
        },
        newsMes_aljol:function () {
            var url='plugin.php?id=aljol&act=newsnum&ajax=1';
            jQuery.post(url,function(res){
                if(res!=null && res!='') {
                    if(res.newscount>0){
                        jQuery('.aljol-newscount').html('<i class="ajlol-order-numbers">'+res.newscount+'</i>');
                    }else{
                        jQuery('.aljol-newscount').html('');
                    }
                    
EOF;
 if($_G['cache']['plugin']['aljol']['mp3']) { 
$return .= <<<EOF

                    if(res.newscnum>0){
                        OL.voice_aljol();
                    }
                    
EOF;
 } 
$return .= <<<EOF

                }
            },'json');
        },
        init:function () {
            setInterval(function(){
                OL.newsMes_aljol();
            },5000)
            var aljol_time = setTimeout(function(){
                $('.aljol-layui-layer-shade').addClass('aljol-commom-nav-show');
            },1000);
            jQuery(window).scroll(function() {
                clearTimeout(aljol_time);
                jQuery('.aljol-layui-layer-shade').removeClass('aljol-commom-nav-show');
                aljol_time = setTimeout(function(){
                    jQuery('.aljol-layui-layer-shade').addClass('aljol-commom-nav-show');
                },1000);

            });
        }
    };
    OL.init();
</script>


EOF;
?>