<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($_G['cache']['plugin']['mapp_wechat']) { include_once DISCUZ_ROOT."source/plugin/mapp_wechat/touch.class.php";
echo mobileplugin_mapp_wechat::global_footer_mobile();?><?php } if($_G['cache']['plugin']['aljhtx'] && file_exists('source/plugin/aljhtx/template/touch/aljol.htm')) { include_once DISCUZ_ROOT."source/plugin/aljhtx/aljhtx.class.php";
echo mobileplugin_aljhtx::global_footer_mobile();?><?php } if(file_exists('source/plugin/aljbd/template/touch/common/minbbs_follow.htm')) { include template('aljbd:common/minbbs_follow'); } ?>
