<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<link href="source/plugin/aljbd/css/1200.css" rel="stylesheet">