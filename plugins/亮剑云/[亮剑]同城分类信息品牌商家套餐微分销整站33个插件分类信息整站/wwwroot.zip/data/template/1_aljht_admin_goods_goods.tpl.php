<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template('aljht:admin/iframe_header_common'); ?><div class="content-wrapper">
    <?php if($_GET['ajax'] != 'yes') { ?>
    <section class="content-header">
        <h1>
            <?php echo $aljhtlang['template']['goods_1'];?>
            <small><?php echo $aljhtlang['template']['goods_2'];?><?php echo $num;?><?php echo $aljhtlang['template']['goods_3'];?>
<?php if($brandnum['good'] && $brandnum['good'] != $checksign && !$administrators && $yhzqx) { ?> (<b style="color:red;">您目前所有用户组：<?php echo $brandnum['grouptitle'];?>，允许发布商品个数：<?php echo $brandnum['good'];?> 个</b>)<?php } ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo $index_url;?>"><i class="fa fa-dashboard"></i> <?php echo $aljhtlang['template']['brand_31'];?></a></li>
            <li><a href="plugin.php?id=aljht&amp;act=admin"><?php echo $aljhtlang['template']['brand_32'];?></a></li>
            <li class="active"><?php echo $aljhtlang['template']['goods_1'];?></li>
        </ol>
    </section>
    <?php } ?>
    <section class="content">
        <div class="callout callout-info" style="background-color: #ffffff !important;">
            <div class="row" style="color: #333 !important;">
                <div class="col-md-12">
                    <?php if($administrators) { ?>
                    <div style="padding-bottom: 10px"><span class="fa fa-volume-up" style="margin-right: 5px;color:#0097bc;"></span>排序越大越靠前</div>
                    <div style="padding-bottom: 10px"><span class="fa fa-volume-up" style="margin-right: 5px;color:#0097bc;"></span><b>审核商品时备注选填，填写后备注会一并站内通过用户</b></div>
                    <div style="padding-bottom: 10px"><span class="fa fa-volume-up" style="margin-right: 5px;color:#0097bc;"></span>修改排序、库存、销量、价格等直接修改对应值后点击修改按钮提交</div>
                    <?php } else { ?>
                    <div style="padding-bottom: 10px"><span class="fa fa-volume-up" style="margin-right: 5px;color:#0097bc;"></span>修改库存直接修改对应值后点击修改按钮提交</div>

                    <?php } ?>
                    <div style="padding-bottom: 10px"><span class="fa fa-volume-up" style="margin-right: 5px;color:#0097bc;"></span>其它操作需要点击复选框后选择对应的操作按钮点击提交才会生效</div>
                    <div style="padding-bottom: 10px"><span class="fa fa-volume-up" style="margin-right: 5px;color:#0097bc;"></span>右侧高级搜索可以检索分类、上下架、关键</div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <?php include template('aljht:admin/goods/goods_status'); ?>            
            <!-- /.col -->
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">
                            <select class="form-control" name="ordertype" style="font-size: 12px;" onchange="location.href='plugin.php?id=aljht&act=admin&op=goods&do=<?php echo $do;?><?php echo $urlmod;?>&order='+$(this).val()">
                                <option value="0">请选择商品排序</option>
                                <option value="1">库存正序排</option>
                                <option value="2">销量倒序排</option>
                            </select>
                        </h3>
                        <div class="box-tools pull-right" style="top:10px;right:200px">
                            <select class="form-control g_type" name="g_type" style="font-size: 12px;height:30px">
                                <option value="0" <?php if(!$_GET['g_type']) { ?>selected<?php } ?>>商品标题</option>
                                <option value="1" <?php if($_GET['g_type'] == 1) { ?>selected<?php } ?>>商品ID</option>
                                <option value="2" <?php if($_GET['g_type'] == 2) { ?>selected<?php } ?>>店铺ID</option>
                            </select>
                        </div>
                        <div class="box-tools pull-right" style="top:10px">
                            
                            <div class="has-feedback">
                                
                                <input type="text" id="search" value="<?php echo $_GET['search'];?>" class="form-control input-sm" placeholder="<?php echo $aljhtlang['template']['goods_5'];?>" onkeypress="EnterPress(event)" onkeydown="EnterPress()">
                                <div class="glyphicon glyphicon-search form-control-feedback" style="pointer-events: visible;" onclick="location.href='plugin.php?id=aljht&act=admin&op=goods&do=<?php echo $do;?><?php echo $urlmod;?>&search='+$('#search').val()+'&g_type='+$('.g_type').val()"></div>
                            </div>
                        </div>
                        <!-- /.box-tools -->
                    </div>
                    <?php if($settings['is_post_btn']['value']) { ?>
                    <div class="box-footer" >
                        <a href="plugin.php?id=aljht&amp;act=admin&amp;op=goods&amp;do=addgoods<?php echo $urlmod;?>" class="btn btn-primary mr10"><i class="fa fa-fw fa-plus"></i>&#21457;&#24067;&#21830;&#21697;</a>
                        <?php if($_G['cache']['plugin']['aljtbk']['on'] && $administrators && !$_GET['dzAdmin']) { ?>
                            <?php include template('aljtbk:post'); ?>                        <?php } ?>
                    </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <div class="box-body no-padding">
                        <div class="table-responsive mailbox-messages">
                            <iframe style="display:none;" name="submitiframe"></iframe>
                            <form name="cpform" id="admingoodssubmit" method="post" autocomplete="off" action="plugin.php?id=aljht&amp;act=admin&amp;op=goods<?php echo $urlmod;?>" target="submitiframe">
                                <input type="hidden"  value="0" name="sign" id="sign">
                                <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>">
<table class="table table-hover table-striped">
                                <tbody>
                                <tr>
                                    <th></th>
                                    <th>编号</th>
                                    <th colspan="2">商品名称</th>
                                    <th >所属商家</th>
                                    <th>当前价格</th>
                                    
                                    <th>
                                        <?php if($do != 'no' && $do != 'lose') { ?>销量/<?php } ?>
                                        <?php if($do != 'no' && $do != 'lose' && $administrators) { ?>
                                        排序/
                                        <?php } ?>
                                        数量
                                    </th>

<th>申请时间/状态</th>
                                    <?php if($do == 'no' || $do == 'lose') { ?>
                                        <th>备注</th>
                                    <?php } ?>
                                    <th>操作</th>
                                </tr>
                                <style>
                                    .label_type span{line-height: 2;}
                                </style>
                                <?php if(is_array($bdlist)) foreach($bdlist as $bd) { ?>                                <?php if($_GET['dzAdmin'] == 1) { ?>
                                <?php $bd_name = C::t('#aljtsq#aljtsq_store')->fetch($bd['store_id']);$bd_name['name'] = $bd_name['tc_store_name'];?>                                <?php } else { ?>
                                <?php $bd_name = C::t('#aljbd#aljbd')->fetch($bd['bid']);?>                                <?php } ?>
                                <tr>
                                    <td><input type="checkbox" name="delete[<?php echo $bd['id'];?>]" value="<?php echo $bd['id'];?>"></td>
                                    <td><?php echo $bd['id'];?></td>
                                    <td class="layer-photos-demo"><img src="<?php echo $bd['pic1'];?>" layer-src="<?php echo $bd['pic1'];?>" style="max-width: 60px;max-height: 60px;vertical-align: middle;"></td>
                                    <td class="mailbox-name" style="max-width:200px;">
                                        <a href="plugin.php?id=aljbd&amp;act=goodview&amp;bid=<?php echo $bd['bid'];?>&amp;gid=<?php echo $bd['id'];?>" target="_blank">
                                            <?php echo dhtmlspecialchars($bd['name'])?>                                        </a>
                                        <p class="label_type" style="margin-top: 10px;display: inline-block">
                                        <?php if($bd['sign']) { ?>
                                        <span class="label label-primary"><?php echo $aljhtlang['template']['goods_14'];?></span>
                                        <?php } ?>
                                        <?php if($_G['cache']['plugin']['aljstg']['is_aljstg']) { ?>
                                        <?php include template('aljstg:goods/goods'); ?>                                        <?php } ?>
                                        <?php if($_G['cache']['plugin']['aljspt']['is_aljspt']) { ?>
                                        <?php include template('aljspt:goods/goods'); ?>                                        <?php } ?>
                                        <?php if($bd['is_distribution']>0 && $bd['dis_commission']>0) { ?>
                                        <span class="label label-danger ">分销 <?php echo $bd['dis_commission'];?>%</span>
                                        <?php } ?>
                                        <?php if($bd['give_integral']>0) { ?>
                                        <span class="label label-danger " style="background-color: #999 !important;">返<?php echo $bd['give_integral'];?><?php if($settings['is_give_integral']['value']==1) { ?>%<?php } ?><?php echo $_G['setting']['extcredits'][$_G['cache']['plugin']['aljbdx']['exttype']]['title'];?></span>

                                        <?php } ?>
                                        <?php if($bd['pay_integral']>0) { ?>
                                        <span class="label label-danger " style="background-color: #999 !important;"><?php echo $_G['setting']['extcredits'][$_G['cache']['plugin']['aljbdx']['exttype']]['title'];?>抵现<?php echo $bd['pay_integral'];?>%</span>

                                        <?php } ?>
                                        </p>
                                    </td>
<td class="mailbox-subject" title="<?php echo $bd_name['name'];?>">
                                        <?php if($_GET['dzAdmin'] == 1) { ?>
                                        <a href="plugin.php?id=aljht&amp;act=admin&amp;op=goods&amp;bid=<?php echo $bd['bid'];?>&amp;store_id=<?php echo $bd['store_id'];?>&amp;b=1<?php echo $urlmod;?>"><?php echo cutstr($bd_name['name'],'10','')?></a>
                                        <?php } else { ?>
                                        <a href="plugin.php?id=aljht&amp;act=admin&amp;op=goods&amp;bid=<?php echo $bd['bid'];?>&amp;b=1<?php echo $urlmod;?>"><?php echo cutstr($bd_name['name'],'10','')?></a>
                                        <?php } ?>
                                    </td>
                                    <td class="mailbox-subject">
                                        <?php if(unserialize($bd['attr_key'])) { ?>
                                            <div class="notic">
                                                <a href="javascript:;" style="color:#f42424;" onclick="iframeattr(<?php echo $bd['id'];?>)">规格价格</a>
                                                <input type="hidden" value="<?php if($bd['price1']>0) { echo floatval($bd['price1'])?><?php } else { ?>0<?php } ?>" name="price1[<?php echo $bd['id'];?>]" >
                                            </div>
                                        <?php } else { ?>
                                            <?php if($administrators) { ?>
                                            <input type="text" class="form-control" value="<?php if($bd['price1']>0) { echo floatval($bd['price1'])?><?php } else { ?>0<?php } ?>" name="price1[<?php echo $bd['id'];?>]" style="width:75px;">
                                            <?php } else { ?>
                                            <?php echo $bd['price1'];?>
                                            <?php } ?>
                                        <?php } ?>
                                    </td>
                                    
                                    <td class="mailbox-subject">
                                        <?php if($do != 'no' && $do != 'lose') { ?>
                                        <div>
                                            <span style="float: left;margin-top: 7px;">
                                            销量:&nbsp;
                                            </span>
                                            <?php if($administrators) { ?>
                                            <input type="text" class="form-control" value="<?php if($bd['buyamount']) { ?><?php echo $bd['buyamount'];?><?php } else { ?>0<?php } ?>" name="buyamount[<?php echo $bd['id'];?>]" style="width:55px;margin-bottom: 2px;">
                                            <?php } else { ?>
                                            <?php echo $bd['buyamount'];?><br/>
                                            <?php } ?>
                                        </div>
                                        <?php } ?>
                                        <?php if($do != 'no' && $do != 'lose' && $administrators) { ?>
                                        <div>
                                            <span style="float: left;margin-top: 7px;">
                                        排序:&nbsp;
                                    </span>
                                        <input type="text" class="form-control" value="<?php if($bd['displayorder']) { ?><?php echo $bd['displayorder'];?><?php } else { ?>0<?php } ?>" name="displayorder[<?php echo $bd['id'];?>]" style="width:55px;margin-bottom: 2px;">
                                    </div>
                                        <?php } ?>
                                        <div>
                                            <span style="float: left;margin-top: 7px;">
                                        数量:&nbsp;
                                    </span>
                                        <input type="text" class="form-control" value="<?php if($bd['amount']) { ?><?php echo $bd['amount'];?><?php } else { ?>0<?php } ?>" name="amount[<?php echo $bd['id'];?>]" style="width:55px;margin-bottom: 2px;">
                                    </div>
                                    </td>

<td class="mailbox-subject">
                                        <?php echo dgmdate($bd['dateline']);?><br/>
                                        <?php if($bd['sh_status'] == 1) { ?>
                                        <p>待审核</p>
                                        <?php } elseif($bd['sh_status'] == 2) { ?>
                                        <p>不通过</p>
                                        <?php } ?>
                                        <?php if($do != 'no' && $do != 'lose') { ?>
                                            <?php if($bd['state'] == 1) { ?>
                                                <span style="color:red;">已下架</span>
                                            <?php } else { ?>
                                                <span style="color:green">已上架</span>
                                            <?php } ?>
                                            <?php if($bd['category'] == 1) { ?>
                                                <p>虚拟物品</p>
                                            <?php } ?>
                                        <?php } ?>
                                    </td>
                                    <?php if($do == 'no' || $do == 'lose') { ?>
                                    <td>
                                        <?php if($administrators) { ?>
                                        <textarea name="reason[<?php echo $bd['id'];?>]" class="form-control"><?php echo $bd['reason'];?></textarea>
                                        <?php } else { ?>
                                        <?php echo $bd['reason'];?>
                                        <?php } ?>
                                    </td>
                                    <?php } ?>
                                    <td class="mailbox-attachment" style="max-width:200px">
<a class="edit_btn" href="javascript:;" onclick="iframeeditgoods(<?php echo $bd['id'];?>,<?php echo $bd['bid'];?>)" >
                                        编辑
                                    </a>
<?php if($_G['cache']['plugin']['aljgwc']['aljbd'] && $administrators) { ?>
<a class="edit_btn" href="javascript:;" onclick="iframereply(<?php echo $bd['id'];?>)">
                                        评论管理
                                    </a>
<?php } ?>
<a class="edit_btn" href="javascript:;" onclick="iframeattr(<?php echo $bd['id'];?>)">
                                        商品规格
                                    </a>
                                    <a class="edit_btn" href="plugin.php?id=aljht&amp;act=admin&amp;op=goods&amp;do=addgoods&amp;gid=<?php echo $bd['id'];?>&amp;bid=<?php echo $bd['bid'];?><?php echo $urlmod;?>&amp;copy=1" >
                                        复制商品
                                    </a>
                                    <?php if($_G['cache']['plugin']['aljms']['is_aljms']) { ?>
                                        <a class="edit_btn" href="javascript:;" onclick="iframems_enter(<?php echo $bd['id'];?>)">
                                            秒杀报名
                                        </a>
                                    <?php } ?>
                                
                                    <?php if($bd['state'] == 1) { ?>
                                        <a href="javascript:;" data-url="plugin.php?id=aljht&amp;act=admin&amp;op=goods&amp;do=up_down&amp;gid=<?php echo $bd['id'];?>&amp;state=2&amp;formhash=<?php echo FORMHASH;?><?php echo $urlmod;?>" class="up_down edit_btn">上架</a>
                                    <?php } else { ?>
                                        <a href="javascript:;" data-url="plugin.php?id=aljht&amp;act=admin&amp;op=goods&amp;do=up_down&amp;gid=<?php echo $bd['id'];?>&amp;state=1&amp;formhash=<?php echo FORMHASH;?><?php echo $urlmod;?>" class="up_down edit_btn" style="color:#f42424;border: 1px solid #f42424;">下架</a>
                                    <?php } ?>
</td>
                                </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                            <!-- /.table -->

                        <!-- /.mail-box-messages -->

                    <!-- /.box-body -->
                    <div class="box-footer no-padding">
                        <div class="mailbox-controls">
                            <!-- Check all button -->
                            <button type="button" class="btn btn-default btn-sm checkbox-toggle"><i class="fa fa-square-o"></i>
                            </button>
                            <div class="btn-group">
                                <button type="button" class="btn btn-default btn-sm btn-submit" >
                                    修改
                                </button>
                            </div>
                            <?php if($do == 'no') { ?>
                                <?php if($administrators) { ?>
                                <button type="button" class="btn btn-default btn-sm btn-submit" data-id="10">审核通过</button>
                                <button type="button" class="btn btn-default btn-sm btn-submit" data-id="11">审核不通过</button>
                                <?php } ?>
                            <?php } elseif($do == 'lose') { ?>
                                <?php if($administrators) { ?>
                                    <button type="button" class="btn btn-default btn-sm btn-submit" data-id="10">审核通过</button>
                                <?php } ?>
                            <?php } else { ?>
                                <?php if($do == 'grounding') { ?>
                                    <button type="button" class="btn btn-default btn-sm btn-submit" data-id="7">下架</button>
                                <?php } elseif($do == 'undercarriage') { ?>
                                    <button type="button" class="btn btn-default btn-sm btn-submit" data-id="6">上架</button>
                                <?php } else { ?>
                                    <button type="button" class="btn btn-default btn-sm btn-submit" data-id="7">下架</button>
                                    <button type="button" class="btn btn-default btn-sm btn-submit" data-id="6">上架</button>
                                <?php } ?>
                                <?php if($administrators) { ?>
                                    <?php if($do == 'rec') { ?>
                                        
                                        <button type="button" class="btn btn-default btn-sm btn-submit" data-id="4">取消推荐</button>
                                    <?php } else { ?>
                                        
                                        <button type="button" class="btn btn-default btn-sm btn-submit" data-id="4">取消推荐</button>
                                        
                                        <button type="button" class="btn btn-default btn-sm btn-submit" data-id="3">推荐</button>
                                    <?php } ?>
                                <?php } ?>
                            <?php } ?>
                            <button type="button" class="btn btn-default btn-sm btn-submit" data-id="2">删除</button>
                            

                            <?php echo $paging;?>
                            <!-- /.pull-right -->
                        </div>
                    </div>
                    </form>
                </div>
                <!-- /. box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
</div>
<style>
    .search-gao-list{
        color: #FFF;
        background-color: #3c8dbc;
        width: 30px;
        padding: 8px 6px 8px 7px;
        margin-top: -80px;
        border: solid 1px #3c8dbc;
        border-right: 0 none;
        position: fixed;
        display: block;
        z-index: 99;
        top: 50%;
        right: 0;
        font-size:14px;
        cursor: pointer;
        box-shadow: 0 0 5px 0 rgba(204,204,204,0.5);
        border-radius:5px 0 0 5px;
    }
    .search-gao-bar {
        background-color: #F5F5F5;
        border-left: solid 1px #D7D7D7;
        height: 100%;
        padding: 0 0 10px 20px;
        position: fixed;
        z-index: 99;
        top: 0;
        bottom: 0;
        right: -230px;
        box-shadow: 0 0 10px 0 rgba(100,100,100,0.5);
        min-height:650px;
    }
    .search-gao-bar .handle-btn{
        color: #FFF;
        background-color: #3c8dbc;
        width: 30px;
        padding: 8px 6px 8px 7px;
        margin-top: -80px;
        border: solid 1px #3c8dbc;
        border-right: 0 none;
        position:absolute;
        display: block;
        z-index: 99;
        top: 50%;
        left: -30px;
        font-size:14px;
        cursor: pointer;
        box-shadow: 0 0 5px 0 rgba(204,204,204,0.5);
        border-radius:5px 0 0 5px;
    }
    .search-gao-bar .title{ padding: 0;line-height: normal;border: 0;height: auto;font-size: 0;}
    .search-gao-bar .title h3{ font-size:14px; font-weight:normal; color:#000; padding:100px 0 0 0;}
    .search-gao-bar .searchContent{ padding:20px 0 0 0; width:166px; float:left;}
    .search-gao-bar .searchContent .layout-box{ float:left;}
    .search-gao-bar .searchContent dl{ float:left;margin-bottom:10px; margin-right:10px;}
    .search-gao-bar .searchContent dt{ color:#686868; line-height:25px; float:left;}
    .search-gao-bar .searchContent dd{ float:left; width:100%;}
    .search-gao-bar .searchContent dd .s-input-txt,.search-gao-bar .searchContent dd .s-input-txt-2{ padding:2px 0 2px 5px; border:1px solid #dbdbdb; height:20px; float:left; width:139px;}
    .search-gao-bar .searchContent dd .s-input-txt-2{ width:54px;}
    .search-gao-bar .searchContent dd .bool{ float:left; line-height:26px;}
    .search-gao-bar .searchContent dd .imitate_select{ margin-right:0;}
    .w260 {
        width: 260px !important;
    }
    .text {
        float: left;
        border: 1px solid #dbdbdb;
        border-radius: 2px;
        height: 38px;
        line-height: 38px;
        padding: 0 10px;
        text-shadow: 0 1px 2px rgba(0,0,0,.1);
        -moz-box-shadow: 0 2px 3px 0 rgba(0,0,0,.1) inset;
        -webkit-box-shadow: 0 2px 3px 0 rgba(0,0,0,.1) inset;
        box-shadow: 0 2px 3px 0 rgba(0,0,0,.1) inset;
        -o-transition: all .2s;
        -moz-transition: all .2s;
        -webkit-transition: all .2s;
        -ms-transition: all .2s;
        margin-right: 10px;
    }
    .w300 {
        width: 300px !important;
    }
    .bot_btn {
        position: absolute;
        bottom: 120px;
    }

    .bot_btn .btn {
        height: 28px;
        line-height: 26px;
        color: #3c8dbc;
        border-radius: 3px;
        padding: 0 13px;
        border: 1px solid #3c8dbc;
        background: #fff;
        cursor: pointer;
    }
    .bot_btn .btn {
        height: 28px;
        line-height: 26px;
        color: #3c8dbc;
        border-radius: 3px;
        padding: 0 13px;
        border: 1px solid #3c8dbc;
        background: #fff;
        cursor: pointer;
    }
    .bot_btn .red_btn {
        background: #3c8dbc;
        color: #fff;
        padding: 0 16px;
        margin-right: 10px;
    }
    .w270 {
        width: 270px;
    }
    .mr0 {
        margin-right: 0px !important;
    }
</style>
<form action="plugin.php?id=aljht&amp;act=admin&amp;op=goods<?php echo $urlmod;?>" method="post" name="searchHighForm">
    <div class="gj_search">
        <div class="search-gao-list" id="searchBarOpen" style="right: 0px;">
            <i class="fa fa-fw fa-search-plus" style="text-align:left"></i>高级搜索	</div>
        <div class="search-gao-bar" style="right: -350px;">
            <div class="handle-btn" id="searchBarClose"><i class="fa fa-fw fa-search-minus" style="text-align:left"></i>收起边栏</div>
            <div class="title"><h3>高级搜索</h3></div>
            <div class="searchContent w300">
                <div class="layout-box">
                    <dl class="w300">
                        <dt>分类</dt>
                        <dd>
                            <div class="categorySelect">
                                <div class="selection">
                                    <select name="type" id="type" class="form-control" onchange="lj_type();">
                                        <option value="">全部</option>
                                        <?php if(is_array($onetypelist)) foreach($onetypelist as $typeid => $type) { ?>                                        <option value="<?php echo $typeid;?>" <?php if($typeid==$_GET['type']) { ?>selected<?php } ?>><?php echo $type['subject'];?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="selection" id="type1" <?php if(!$_GET['subtype']) { ?>style="margin-bottom: 15px"<?php } ?>>
                                    <?php if($_GET['subtype']) { ?>
                                    <select name="subtype" id="subtype" class="form-control" onchange="lj_subtype();">
                                        <?php if(is_array(C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type_goods')->fetch_all_by_upid($_GET['type']))) foreach(C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type_goods')->fetch_all_by_upid($_GET['type']) as $typeid => $type) { ?>                                        <option value="<?php echo $typeid;?>" <?php if($typeid==$_GET['subtype']) { ?>selected<?php } ?>><?php echo $type['subject'];?></option>
                                        <?php } ?>
                                    </select>
                                    <?php } ?>
                                </div>
                                <div class="selection" id="type2" <?php if(!$_GET['subtype3']) { ?>style="margin-bottom: 15px"<?php } ?>>
                                    <?php if($_GET['subtype3']) { ?>
                                    <select name="subtype3" class="form-control">
                                        <?php if(is_array(C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type_goods')->fetch_all_by_upid($_GET['subtype']))) foreach(C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type_goods')->fetch_all_by_upid($_GET['subtype']) as $typeid => $type) { ?>                                        <option value="<?php echo $typeid;?>" <?php if($typeid==$_GET['subtype3']) { ?>selected<?php } ?>><?php echo $type['subject'];?></option>
                                        <?php } ?>
                                    </select>
                                    <?php } ?>
                                </div>
                            </div>
                        </dd>
                    </dl>
                    <dl class="w140">
                        <dt>上下架</dt>
                        <dd>
                            <div class="imitate_select select_w140">
                                <select name="state"  class="form-control" >
                                    <option value="" selected>全部</option>

                                    <option value="2" <?php if($_GET['state'] == 2) { ?>selected<?php } ?>>上架</option>
                                    <option value="1" <?php if($_GET['state'] == 1) { ?>selected<?php } ?>>下架</option>

                                </select>

                            </div>
                        </dd>
                    </dl>
                    <!--dl class="w140">
                        <dt>审核</dt>
                        <dd>
                            <div class="imitate_select select_w140">
                                <select name="sh_status"  class="form-control" >
                                    <option value="" selected>全部</option>
                                    <option value="1" <?php if($_GET['sh_status'] == 1) { ?>selected<?php } ?>>未审核</option>
                                    <option value="2" <?php if($_GET['sh_status'] == 2) { ?>selected<?php } ?>>审核已通过</option>
                                </select>
                            </div>
                        </dd>
                    </dl-->


                    <dl class="w140">
                        <dt>关键字</dt>
                        <dd>
                            <input type="text" name="search" value="<?php echo $_GET['search'];?>" size="15" class="text w270 mr0" autocomplete="off">
                        </dd>
                    </dl>
                </div>
            </div>
            <div class="bot_btn">
                <input type="submit" class="btn red_btn" name="tj_search" value="提交查询">
                <a href="plugin.php?id=aljht&amp;act=admin&amp;op=goods<?php echo $urlmod;?>" class="btn btn_reset" >重置</a>
            </div>
        </div>
    </div>
</form>
<link rel="stylesheet" href="source/plugin/<?php echo $pluginid;?>/js/combo.select.css">
<script src="source/plugin/<?php echo $pluginid;?>/js/jquery.combo.select.js" type="text/javascript"></script>
<script>
    $(document).on('click','.up_down',function () {
        var d_url = $(this).attr('data-url');
        var index = layer.load(0, {shade: false});
        $.post(d_url,function (res) {
            layer.closeAll('loading');
            if(res.code == 1){
                tips(res.text,function () {
                    location.href = location.href;
                });
            }else{
                tips(res.text);
            }
        },'json');
    });
    function lj_type(){
        var r = $('#type').val();
        $("#type1").html('<div class="form-group" style="text-align: center;"><img src="static/image/common/loading.gif" /></div>');
        $("#type2").html('');
        $.post('plugin.php?id=<?php echo $pluginid;?>&act=gettype&do=goods',{"upid":r},function(data){
            if(data){
                $("#type1").html(data);
            }else{
                $("#type1").html('');
            }
        });
    }
    function lj_subtype(){
        var r = $('#subtype').val();
        $("#type2").html('<div class="form-group" style="text-align: center;"><img src="static/image/common/loading.gif" /><div>');
        $.post('plugin.php?id=<?php echo $pluginid;?>&act=gettype&do=goods',{"upid":r,"op":'subtype'},function(data){
            if(data){
                $("#type2").html(data);
            }else{
                $("#type2").html('');
            }
        });
    }
    $(function() {
        $('.gj_search select').comboSelect();
    });
    // 高级搜索边栏动画
    jQuery.gjSearch = function(right){
        $('#searchBarOpen').click(function() {
            $('.search-gao-list').animate({'right': '-40px'},200,
                function() {
                    $('.search-gao-bar').animate({'right': '0'},300);
                });
        });
        $('#searchBarClose').click(function() {
            $('.search-gao-bar').animate({'right': right}, 300,
                function() {
                    $('.search-gao-list').animate({'right': '0'},  200);
                });
        });
    }
    $.gjSearch("-350px");
    function EnterPress(e){ //传入 event
        var e = e || window.event;
        if(e.keyCode == 13){
            $('.glyphicon-search').click();
        }
    }
    function iframems_enter(gid){
        //iframe窗
        layer.open({
            type: 2,
            title: '秒杀报名',
            shadeClose: true,
            shade: false,
            //maxmin: true, //开启最大化最小化按钮
            area: ['80%', '80%'],
            content: 'plugin.php?id=aljms&c=activity&a=ms_enter&ajax=yes&ms_gid='+gid
        });
    }
function iframereply(gid){
//iframe窗

layer.open({
  type: 2,
  title: '<?php echo $aljhtlang['js']['brand_5'];?>',
  shadeClose: true,
  shade: false,
  //maxmin: true, //开启最大化最小化按钮
  area: ['80%', '80%'],
  content: 'plugin.php?id=aljht&act=admin&op=goods&do=greply<?php echo $urlmod;?>&gid='+gid
});
}

    function tips(info){
        if(info == 0){
            layer.alert('<?php echo $aljhtlang['js']['brand_6'];?>', {icon: 6},function(){
                location.href=location.href;
            });
        }else{
            layer.alert(info, {icon: 6},function(){
                location.href=location.href;
            });
        }
    }
    $('.btn-submit').click(function(){
        $('#sign').val($(this).attr('data-id'));
        if($(this).attr('data-id') == 2){
layer.confirm('<?php echo $aljhtlang['js']['addresslist_3'];?>', {
  btn: ['<?php echo $aljhtlang['js']['brand_8'];?>'] //按钮
}, function(){
  layer.msg('<?php echo $aljhtlang['js']['brand_9'];?>', {icon: 16});
  $('#admingoodssubmit').submit();
});
}else{
layer.msg('<?php echo $aljhtlang['js']['brand_9'];?>', {icon: 16});
$('#admingoodssubmit').submit();
}
    });
    $(function () {
        //Enable iCheck plugin for checkboxes
        //iCheck for checkbox and radio inputs
        $('.mailbox-messages input[type="checkbox"]').iCheck({
            checkboxClass: 'icheckbox_flat-blue',
            radioClass: 'iradio_flat-blue'
        });

        //Enable check and uncheck all functionality
        $(".checkbox-toggle").click(function () {
            var clicks = $(this).data('clicks');
            if (clicks) {
                //Uncheck all checkboxes
                $(".mailbox-messages input[type='checkbox']").iCheck("uncheck");
                $(".fa", this).removeClass("fa-check-square-o").addClass('fa-square-o');
            } else {
                //Check all checkboxes
                $(".mailbox-messages input[type='checkbox']").iCheck("check");
                $(".fa", this).removeClass("fa-square-o").addClass('fa-check-square-o');
            }
            $(this).data("clicks", !clicks);
        });

        //Handle starring for glyphicon and font awesome
        $(".mailbox-star").click(function (e) {
            e.preventDefault();
            //detect type
            var thisstar = $(this).find("a > i");
            var glyph = thisstar.hasClass("glyphicon");
            var fa = thisstar.hasClass("fa");

            //Switch states
            if (glyph) {
                thisstar.toggleClass("glyphicon-star");
                thisstar.toggleClass("glyphicon-star-empty");
            }

            if (fa) {
                thisstar.toggleClass("fa-star");
                thisstar.toggleClass("fa-star-o");
            }
        });
    });
</script><?php include template('aljht:admin/goods/common_goods_js'); include template('aljht:admin/footer'); ?>