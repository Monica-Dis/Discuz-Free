<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<script>
jQuery(document).on('click', '.navigateTo', function () {
    //alert(jQuery(this).attr('href'));
    var webVUrl = jQuery(this).attr('href');
    if (webVUrl != 'javascript:;' && webVUrl != 'javascript:void(0)') {
        <?php if(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'qianfan') !== false) { ?>
            webVUrl = (webVUrl.substr(0, 8).toLowerCase() == "https://" || webVUrl.substr(0, 7).toLowerCase() == "http://") ? webVUrl : '<?php echo $_G['siteurl'];?>'+webVUrl;
            QFH5.jumpNewWebview(webVUrl);
            return false;
        <?php } elseif(false !== strpos($_SERVER['HTTP_USER_AGENT'],'swan')) { ?>
            var path = '/pages/nav/nav?url=' + encodeURIComponent(webVUrl);
            swan.webView.navigateTo({
                url: path
            });
        <?php } else { ?>
            if (isWeiXin() && typeof wx !== 'undefined') {
                if (window.__wxjs_environment === 'miniprogram') {
                    miniProgramwebview(webVUrl);
                    return false;
                }
            }
        <?php } ?>
    }
});
jQuery(document).on('click', '.redirectTo', function () {
    //alert(jQuery(this).attr('href'));
    var webVUrl = jQuery(this).attr('href');
    if (isWeiXin() && webVUrl != 'javascript:;' && webVUrl != 'javascript:void(0)') {
        if (typeof wx !== 'undefined') {
            if (window.__wxjs_environment === 'miniprogram') {
                miniProgramwebviewredirectTo(webVUrl);
                return false;
            }
        }
    }
});

function isWeiXin() {
    var ua = window.navigator.userAgent.toLowerCase();
    if (ua.match(/MicroMessenger/i) == 'micromessenger') {
        return true;
    } else {
        return false;
    }
}
function miniProgramwebview(url){
    var path = '/pages/index/index?webVUrl=' + encodeURIComponent(url);
    wx.miniProgram.navigateTo({
        url: path
    });
}
function miniProgramwebviewredirectTo(url){
    var path = '/pages/index/index?webVUrl=' + encodeURIComponent(url);
    wx.miniProgram.redirectTo({
        url: path
    });
}
</script>