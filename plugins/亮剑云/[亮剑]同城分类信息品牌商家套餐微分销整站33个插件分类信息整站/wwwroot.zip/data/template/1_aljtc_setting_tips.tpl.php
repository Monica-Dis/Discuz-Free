<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>

<table id="tips" class="tb tb2 ">
    <tbody>
        <tr><th class="partition">&#25216;&#24039;&#25552;&#31034;</th></tr>
        <tr><td s="1" class="tipsblock"><ul id="tipslis">
            <li>
                <b>&#22914;&#26524;&#24744;&#23545;&#35774;&#32622;&#39033;&#26377;&#19981;&#20102;&#35299;&#30340;&#22320;&#26041;&#65292;&#21487;&#20197;&#25353;&#20197;&#19979;&#25805;&#20316;<br/>
                    1.&#25991;&#26723;&#25628;&#32034;<a href="https://docs.liangjianyun.com/" target="_black">https://docs.liangjianyun.com/</a><br/>
                    2.&#28155;&#21152;&#24494;&#20449;&#23458;&#26381; <font style="color:red;">liangjian-xiaobai</font>  &#30003;&#35831;&#24037;&#21333;&#24080;&#21495;&#21457;&#24067;&#24037;&#21333;
                </b>
            </li>
            <li>
                <b><a href="source/plugin/aljtc/static/css/fonts/demo_index.html" target="_black">&#21516;&#22478;&#105;&#99;&#111;&#110;&#102;&#111;&#110;&#116;&#22270;&#26631;&#24211;</a>&#65292;&#21487;&#29992;&#20110;&#24213;&#37096;&#23548;&#33322;<br/>
                1.&#28857;&#20987;&#25171;&#24320;<a href="source/plugin/aljtc/static/css/fonts/demo_index.html" target="_black">&#21516;&#22478;&#105;&#99;&#111;&#110;&#102;&#111;&#110;&#116;&#22270;&#26631;&#24211;</a>&#28857;&#20987;&#70;&#111;&#110;&#116;&#32;&#99;&#108;&#97;&#115;&#115;&#26631;&#31614;<a href="//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljtc/del/WX20200311-152406.png"><img src="//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljtc/del/WX20200311-152406.png" style="max-height:100px"></a></br/>
                2.&#22797;&#21046;&#20320;&#36873;&#25321;&#22270;&#26631;&#19979;&#26041;&#30340;&#46;&#105;&#99;&#111;&#110;&#45;&#20195;&#30721;<a href="//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljtc/del/WX20200311-152441.png"><img src="//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljtc/del/WX20200311-152441.png" style="max-height:100px"></a><br/>
                3.&#25226;&#21407;&#24213;&#37096;&#23548;&#33322;&#22270;&#26631;&#38142;&#25509;&#26367;&#25442;&#25104;&#20320;&#22797;&#21046;&#30340;&#46;&#105;&#99;&#111;&#110;&#45;&#20195;&#30721;<a href="//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljtc/del/WX20200311-152658.png"><img src="//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljtc/del/WX20200311-152658.png" style="max-height:100px"></a>
            </li>
        </ul></td>
        </tr>
    </tbody>
</table>
