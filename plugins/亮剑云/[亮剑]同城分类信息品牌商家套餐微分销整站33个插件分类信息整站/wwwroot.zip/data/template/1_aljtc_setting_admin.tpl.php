<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<tr ><th class="partition" colspan="15" >&#21518;&#21488;&#35774;&#32622;</th></tr>
<tr><td s="1" class="td27" colspan="2">&#20998;&#31867;&#20998;&#39029;&#25968;</td></tr>
<tr onmouseover="setfaq(this, 'faq1e8e')" class="noborder">
    <td class="vtop rowform">
        <input type="text" class="txt" value="<?php echo $settings['type_page']['value'];?>" name="settingsnew[type_page]">
    </td>
    <td s="1" class="vtop tips2">&#40664;&#35748;&#65306;8</td>
</tr>