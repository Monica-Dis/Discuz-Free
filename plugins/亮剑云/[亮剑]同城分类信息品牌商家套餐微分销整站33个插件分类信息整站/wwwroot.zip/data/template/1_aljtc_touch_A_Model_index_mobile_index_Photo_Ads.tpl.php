<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($settings['mobile_index_Photo_Ads']['value']) { ?>
<!--ͼ�Ĺ��-->
<style>
    .activity:before {
        display:block;content:'';position:absolute;width:200%;height:200%;left:0;top:0;border-right:1px solid #e5e5e5;border-bottom: 1px solid #e5e5e5;-webkit-transform: scale(.5);-webkit-transform-origin: 0 0;  pointer-events: none;  box-sizing: border-box;  -webkit-box-sizing: border-box;  }.activities{width:100%;background:#fff;}.activities .activity-wrap:after{content:'';display:block;clear:both}.activities .activity-wrap .activity{display:inline-block;float:left;width:50%;height:70px;box-sizing:border-box;padding-left:4vw;position:relative}.activities .activity-wrap .activity .activity-mask{display:none;position:absolute;left:0;right:0;top:0;bottom:0;background-color:#000;opacity:.06;z-index:9}.activities .activity-wrap .activity.active{background-color:#000;opacity:.06}.activities .activity-wrap .activity>a{display:inline-block;height:70px;width:100%;position:relative;text-align:center}.activities .activity-wrap .activity .ad_content{position:absolute;top:50%;-webkit-transform:translateY(-50%);z-index:1}.activities .activity-wrap .activity .ad_content .title{font-size:16px;color:#666;text-align:left}.activities .activity-wrap .activity .ad_content .sub-title{font-size:11px;color:#999;text-align:left}.activities .activity-wrap .activity .ad_content .timeWrap{display:block;width:100%;height:100%}.activities .activity-wrap .activity .ad_content .timeWrap .time-colon{display:inline-block;color:#666;width:.5vw;height:.5vw;font-size:.5vw}.activities .activity-wrap .activity .ad_content .timeWrap .time{display:inline-block;background:#333;border-radius:2px;color:#fff;margin:0 3px;text-align:center}.activities .activity-wrap .activity .img{float:right;height:69px;width:69px;margin-right:1vw;position:absolute;bottom:1px;right:0}.activities .activity-wrap .activity.selected{height:158px;padding-left:4vw;border-top:0}.activities .activity-wrap .activity.selected .ad_content{position:absolute;top:25%}.activities .activity-wrap .activity.selected .ad_content .title{letter-spacing:16px}.activities .activity-wrap .activity.selected .ad_content .timeWrap .time-text-selected{font-size:11px;color:#333;margin-right:-3px}.activities .activity-wrap .activity.selected .ad_content .timeWrap .time{width:21px;height:22.5px;line-height:22.5px;font-size:16px;text-align:center}.activities .activity-wrap .activity.selected .img{height:79px;width:118.5px;position:absolute;bottom:0;-webkit-transform:translateX(-54%)}.activities .activity-wrap .activity.small-selected{border-top:0}.activities .activity-wrap .activity.small-selected .timeWrap .time{width:14px;height:14px;line-height:14px;font-size:10px}
</style>
<div class="line-5"></div>
<section class="activities diyDocument" diy-id="mobile_index_Photo_Ads">
    <ul class="activity-wrap activity-wrap-6 all-small">
        <?php if(is_array($mobile_index_Photo_Ads_arr)) foreach($mobile_index_Photo_Ads_arr as $k => $v) { ?>        <li class="activity activity-0 border-rt " data-mon="1">
            <div class="activity-mask"></div>
            <a href="<?php echo $v['3'];?>" class="navigateTo">
                <div class="ad_content">
                    <p class="title"><?php echo $v['0'];?></p>
                    <p class="sub-title"><?php echo $v['1'];?></p>
                </div>
                <img src="<?php echo $v['2'];?>" class="img">
            </a>
        </li>
        <?php } ?>
    </ul>
</section>
<div class="line-5"></div>
<!--ͼ�Ĺ��-->
<?php } ?>