<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template('aljbd:header/header_head'); ?><a name="top"></a>
<link rel="stylesheet" href="source/plugin/aljbd/template/touch/type/css/tm.css?<?php echo VERHASH;?>" />
<header>
    <div class="header" style="line-height: 40px;">
        <div class="search-content wbox" style="position: relative; background: none;">
            <a class="class_back" name="index_none_header_syfl" href="javascript:;" ></a>
            <div class="wbox-flex search-bar pr">
                <a name="index_none_header_sysc" class="new_search" href="plugin.php?id=aljbd&amp;act=search"></a>
                <form><input id="searchInput" name="index_none_header_sysc" type="text" placeholder="<?php if($config['m_search_default']) { ?><?php echo $config['m_search_default'];?><?php } else { ?>&#35831;&#36755;&#20837;&#24744;&#24819;&#25214;&#30340;&#21830;&#21697;&#25110;&#24215;&#38138;<?php } ?>" autocomplete="off"></form>
            </div>

            <div class="my-cart pr" >
                <div class="icon_dian" ></div>
                <a id="w-headMenu"></a>
            </div>
        </div>
    </div>
</header>
<link href="source/plugin/aljbd/images/sj/dian.css?<?php echo VERHASH;?>" type="text/css" rel="styleSheet" ><?php include template('aljbd:common/common_dian'); ?><style type="text/css">
    .search-content{width:100%;height:44px}
    .my-cart {
        width: 44px;
        height: 44px
    }

    .my-cart a {
        display: block;
        width: 100%;
        height: 100%
    }
    .my-cart .l_type {
        position: absolute;
        top: 0;
        left: 10px;
        margin: 12px 4px 1px;
        width: 22px;
        height: 28px;
        background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAABGCAYAAAC363Y9AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NTU4RDEyNkMzM0MzMTFFNzhBMURBNENDREMzNjY1QzgiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NTU4RDEyNkQzM0MzMTFFNzhBMURBNENDREMzNjY1QzgiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDowQjU3NEVGRjMzQzMxMUU3OEExREE0Q0NEQzM2NjVDOCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDowQjU3NEYwMDMzQzMxMUU3OEExREE0Q0NEQzM2NjVDOCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pg4GdlwAAATWSURBVHja7FrNi1RHEH/99s3MukI2fsB6iYsJMaeIOejBFaMkBj1oDmIg5EuS9SOi4MEvBA+6KgmIB9c/IGoOOZiA5iI5ZRc2B0+6OeVgHBFCPDnxnu1U6a+Xmtp6/Wbd3ZFAN/yYef2qq6ur66t7xnnvM9FcZjdf0l9GP19txryFMbEzBrmXJPAM4Qtj8k60LGldF7QblOYLQ7uuZLBF5zrYoTkJKPqf9eWGANsJj4DtkUWE/lygRz3PBnqsOa8jp3NKYBZ0Bd7/TXjNMH6m+5UwtMB2O0HYLDTt84oBMWcb6oKjDWkZLIH3Ex4T/iLsU3Yl7WmiCwL/pnc3mITlSJagUsN5hfPNxfG8wJSUoVARwFcwyQxav0BRIpo4YtnMRxbgRPhZiDisBfeFob0qwV2JNrqRPNo03OnkPutei5rEvDBc6FZ0GHdTtZaqtVStpWotVWupWkvVWqrWUrWWqrVUraVqLVVrqVpL1Vqq1lK1lqq1VK21tzz7n7UkcBJ4np3uRVtVzV0aXosXZDwfx6jYycaV8S0qhHWRtO0itUYZL93W4vNu5ODQkQ1LYZcSfiK8o/ruE7bEim3Rv4TwI2GPKvovAbJwPwLeZjGWV5wk+BRwmrCJ0BI0LeB05IQgJ3xK+J1wkfA6+PYI2vDMijhMGC/ly3+hEXBAD6FO2OqftxFCgf4efH8f73aDlvtzwSPwqREahF5Ck3CO0EdYTBgHFqPvI0KLMIAxNfAI/J7Vw9omw8p4tX8QHhLWoS6dErSskRvQ/nrCA1W7Ms0qQGsq7Ow3+DypauBM1MIPgOfvDM3WsMJ7WO1bSoO5omuCdkBoJNCc8XNvZ8TOTWvYCa2xZn8hDBK2wYOnjGgQdoI9/TZ2YrfQdGacqvn5VcK34M9tJTQ9Dh7ypCEx4xDKzN6FGQziiD9pTKqdYRK0POYO4cNIiNqIsyAL+bE6bE4AnxBeKY2P6ph/H6s8TtjZYQkZhLtC+AHRY5ewY17cF4RPYe/nCRcw5jY+t0FInvMUduEWYYTwZ5t9CxtmO3kD9vrBLO2M7XgRPHu5iCbvEZ6A5hphtYgYjH1AL/oDhsHzCSLStA1bTlfAeepgxOHmBCbtg2C94t15hKaG4XT8fBSOK4XqBZ9RYJEhNONNLXCutt00dNjYz+j7V7zjz7eN47lsozAznUx47s8i1wuZGFd5avZg6GFbO3CpIhcSnK/fuEsIwn0OlBU9/eC9JuIvVwnfVRU/csWHCP8QbqrkIYV7WBIVmoQx43qWcVCEtUnAOt638zZScw67YRtej+QxgudC2WdDvNdpVNJJf+A0fAA+8TXhe/DYgHfBnuvKJ9qcLlOT1EW2k1msUEIMYOJh9OUlAjeEwMcx5jqe+/Ddo86QDlgpcJhgK1bdgpbDamtKY8cw0WrlzXqnBhC+mqAfhUB1oIFo0gLNXiPVzwhr3LmMcBlM70GQIOxXhLPY/hHEVW5jhjmExX9JuCni9RiUUTeqvxrmC3w5Bl8l7JICa6drIcVyhjmnHKAfqVu264Sj1tU+vg8Cx5C5mtaNpHBEzmrDmH8nwt6YTs1Wwe1Kbi2teDlVEtIsel9yyRe78pVjfFFxP1v140yM3s/iGtVX/Mw2zd+pP+3P5WheNWa293Dm2P8EGAB7ny0XXi7C0gAAAABJRU5ErkJggg==);
        background-size: 22px 28px;
        -webkit-mask-image: none;
        pointer-events: none
    }
    .my-cart .icon {
        position: absolute;
        top: 0;
        left: 0;
        margin: 8px 4px 1px;
        width: 34px;
        height: 34px;
        background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD8AAABECAYAAAA2uu3dAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6MEI1NzRFRjkzM0MzMTFFNzhBMURBNENDREMzNjY1QzgiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MEI1NzRFRkEzM0MzMTFFNzhBMURBNENDREMzNjY1QzgiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDowQjU3NEVGNzMzQzMxMUU3OEExREE0Q0NEQzM2NjVDOCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDowQjU3NEVGODMzQzMxMUU3OEExREE0Q0NEQzM2NjVDOCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PmBDvA8AAAdNSURBVHja7FtrbBVFFJ69vTwEFTChGoltSfiHgCQmREMvReUhj/aHaHygiT9IRUAT4wvBP7agJuoPiS9igoIaNJAgVdBopL3tH41GCjFqILG3MUZMlPKKD2LHM95vw+E4s3u3d3e7xE7y5c7Ozpw9Z85jzs7s9bTWqsoynbCaMJcwjTBe3O8hvEJ4R2WtGOGrwFpdeVlb5bNih1eF5m8ifBJxzBTCT1lRfK6KsatZvZNwDeFigifQ6Rgz7KUazR8j1KJ+OeEXR78mwgF2vYDw6YWu+dGs/ldAP6P5XezauIqOEebZnxFuTTPgdbBgtoMwjXCRo28t4ZhOvmyJIkM1wi8JYWSW6L9Cp1OmVypDNWa/j/BswP17xfUuSzCMA8b9XmPPmZuGz5vyOGEO4Q3CUcLv7N6dhFEpxK2zw5Xk2PAdM8GWlBKWI2mbvau8HmD6SZQGpNWm/Ez4Ji2zt5VtrL6EMDlh4QusHil/SEL4Xwmfoz4Kvp9kmc/qxeEW3pTnUjT9JlY/kFZ6G1ZOEi5B3eT9vQn5+w+o/0i4KguaN2V7CtoviDRaZUX4bSms+UP296SF/4rwPeqTEfkz4+9JC5/0mt8A+P5+NGvCyzW/Nkba86rx9zSEl2v+HQmZfFcWhU9yzW+qVvNJrvOuNT+ObSzjQh8OdX1PU/OmPM/qOwn3YN8vSjFuczWhjbCbtb88HBuYUUotMrwrYqbbT5hFGMiy5s3O7u2Eb2Ok+SXhlqEKnqbmeVlFWKTK201RTP8skiZz/PXuUIPccAufmfK/Fj6X8vNaCB8RTuO3JaWx9pLiqehexz77+wmPTeTQIgrCDiyaExqb+u6trfDT2SdU+TR3g+N+nGMzEfD+VOcONseo8uGiEeIU2k6z9DfOsZkIeD2s/giYf9BxP86xmQh4mfT5NKP9HgfzexIemwnhFbS0n3AKv80pjY39g6SR9HZE+BHhR4S/4IX3oqYKlT4rJjphdPVQhPcYIa9CYrqCPpKmdjCuhzAJnkP4imjkBBEPbRw1lrbZhKmoy6+jlKUth/6z2Rj/d75DiCBhJZ83ALwt6Auu8zTPGZnneLA5ci6h3x/Is1/ELA86tMaF3AjaN7L7DYQjqryX3ym0pkOsiNP+AhuZC8GLDrHQf5+TZwRzYM4w2S0GFvACYQ4ImtkLRQ73PUZ4UFiWOaB4lFlZDbvvHzEfRrtkXFvcxBPWYz58mEm4j7VrxwRweHlH0FgsfPQMe9hytC8H5Kx2qXNnZzlM3GWCccVoHMJraY0lLmgxIUbQFwTP9fi9CwiLGw8RvvY17wp4K1HfwdomEZaxjQVX8S2nCb+TwOQEWFc/zHQ5eyd3lXbCUw6BDL06WI50j9Cglw+I4nUWP7sf9SlgXprkGTGJvlbeZv32Ezaz66Wq/OWGMV3zRefThBP43SeE6UV88IPwfkzk9cr+RfZ//Jzfi7KZMYOwnvASBK+DSQ4GLC8zYNZLMQFGQ+aQ8QPCGrR1Y5K6gZOIJz0h+YGxmkZCK+NhJXZ2pZ8P2iYlFyEhuRSCbIZQ5uhploWoZLADMaCESSuCaYVAaLag5kJwjfrhELM1k/UqFFEU1loIyB/O4zOK5g1z17EZLqlzn5dxoiXUJ4DJvWIFMPe2qPKR1XEWQ4rM1foClryJqnxcVRLuY8szlCNxC/T5sCzOaPQtrNP10KwnhP8NG485EYA081+FieyAny/Db9A3e82ID+Y5Oy0WoZjpy2XTRPqDfnteRS8z8RDzP7m1MP3ukHSYa6IAq+hAvRFLq0a9KGiUxHUnVgDP4ap1jB8Z+E64NC+ZbhRC+WUNGO9nEzAVpuqKFxMxYY3QSitbLrvZc4xFbRJjS5br9oBsrxErhWYBmecMnkvzYWtjA8z0ZvbgfiyBj1n6P4B13V/P+zG2DwcPBcQRX/AJiBG6Qlf0WIYZ9D5g7Z8PeBOqF+uzKc8wjfkR+wQYt/1ddB1WiFam+T749gZouZflEEVm5p5FgHmA53Ar/y8m6x1yacSnA77wPDdvQwRtgO8cAtPjcX8m2gYY41ORbMywaGcaS1s3CgbaQcOD6xSwAmgRvKRCCgH+Xs9cVjny+z55aGHe7moIowljCe2EPsIi7I/fhvYx6DMa9bH4O9mVhMXou5AwCvRqUDd92whdFhpzCAP4W9hYBv/ZCwS9PK59+DyPI2zCmHGMX943Dxo5I7Mt2t8Nk2yFGZrcfitm7CB/K2KBZoCt0V3C3AYdb1ceAuFWFsRkwFWwLm0ZG7YhIgOe9ZWWEzCm+SQEfhNtq2Du7xGuRWJiSguWOY+ZbtGR7moLY6Z8jElbhAlch6A3kdE7LvYMKtkN+luk3taAyQOeByHbAE5sBRg7Lt6o+MaHidIPV/gu7WM7BOxla3QzLGGHhZ5rFZCbKYMhafd5OzmeZSvJNrvasaWkAt6qbP1c7xGSh4qECHhGxcKrAAajbEzqALOMg17UsYns23sxbj/HRS+K8tQ/AgwALZsz8ziTN90AAAAASUVORK5CYII=);
        background-size: 34px 34px;
        -webkit-mask-image: none;
        pointer-events: none
    }
    .my-cart .icon_dian {
        position: absolute;
        top: 0;
        left: 5px;
        margin: 8px 4px 1px;
        width: 28px;
        height: 28px;
    <?php if($settings['mobilenavbackcolor']['value']) { ?>
        background: url(source/plugin/<?php echo $pluginid;?>/template/touch/view/bdian.png);
    <?php } else { ?>
    background: url(source/plugin/<?php echo $pluginid;?>/template/touch/view/images/dian.png);
    <?php } ?>
        background-size: 28px 28px;
        -webkit-mask-image: none;
        pointer-events: none
    }
    .search-bar:before,.sn-search-input:before,.sn-search-top input:before {
        content: "";
        position: absolute;
        left: 14px;
        top: 14px;
        width: 14px;
        height: 16px;
        background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAcCAYAAACQ0cTtAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QAAAAAAAD5Q7t/AAAACXBIWXMAAAsSAAALEgHS3X78AAACZUlEQVRIx7WWu2tUQRSHv6yPxcZHBIM2ii+IgogxBkllE6JZxUKLFS1SHSGtBGWDa0xE/QMETxtZLOwSXGIau+jiA60CuoVWIvjASnSRtZiZ3bPXm91N9nqquWdmft+cw9w5p4sWpqr7gSHgBLAX2OqnvgJl4CmwICLvWml1NYEMAleBvlYi3l4Bt0VksW2Yqm4ApoFsm5CoPQQmRORnU5iqbgEeAEeMuwIUgXngJfAJSAM9QC8wDJwF1pk9r4FLIvI9FuYjehQBzfrUfGwWiqruBK4BZyLA8zbCtWbypgH9AXIiMtNO3vxhLqvqInALWOO1poArYV3Kn2wQuGD2T7cLikBnPCxY1mvXYcC4SemsiOhKQQZ436cfrzleg6nqQaDff/8G8qsFGct7LYB+zyAFjJhFcyLyuVOS15gzrpEAO2ac8wlEFac1EGB7jHMpQdhbM94dYN3G2XEKl9HqDrCqcVYShP1jKcA+KdsS1O4x428BVjbOwwnCrFY5wJ4b58kEYcNmXAqwonFmVHVHpxRV3Q6cNq7HACkRWQpkXJm4kUBUk9RLTskzam/jHeq3MqOqox1ENQpk/GfVa1ODiUgJKJg9U6o6tgrQGK6sBCt4baCxnuWBA7g6lAJyqnoUmBSRDy0gu4DrNF6KN0Qe9WhbsBnXFtgmpwIsAE+AF7iXYT3uPzrkAUM0tgUAX4BztuuKa3jSuKp9kSbd1zJWxZWWdBywWSs3gCt8x9sEPQPu4lqKArAxCmx5clXtBU7hysQ+YJOf+gG8x/02xXC9/Z6+GODwStPUtsUAc/8NZoD3gF9A9i+YmrjxJaFx6gAAAABJRU5ErkJggg==);
        background-size: 14px 16px
    }
    .wbox-flex {
        -webkit-flex: 1!important;
        -webkit-box-flex: 1
    }
    .wbox {
        display: -webkit-flex!important;
        display: -webkit-box;
    }
    .class {
        display: block;
        margin: 6px 6px 2px 5px;
        width: 28px;
        height: 38px;
        background: url(source/plugin/aljbd/template/touch/header/img/my1.png);
        background-size: 28px 38px
    }
    .class_back {
    <?php if($settings['mobilenavbackcolor']['value']) { ?>
    border: 6px solid #ffffff;
    <?php } else { ?>
        border: 6px solid #999999;
    <?php } ?>
        border-width: 2px 0 0 2px;
        -webkit-transform: rotate(-45deg);
        width: 12px;
        height: 12px;
        margin: 16px 10px 16px 15px;
    }
    .pr {
        position: relative;
    }
    .search-bar a.new_search {
        display: block;
        position: absolute;
        height: 44px;
        width: 100%;
        z-index: 10
    }
    .search-bar form {
        height: 44px
    }
    .search-bar input {
        border: 0;
        -webkit-border-radius: 24px;
        padding: 0 4px 0 34px;
        width: 100%;
        height: 34px;
        line-height: 34px;
        background: #ffffff;
        font-size: 12px;
        color: #999;
        -webkit-appearance: none
    }
    .w-headMenu {
        border-radius: 50%;
        top: 0px;
        height: 40px;
        opacity: 0.5;
        position: fixed;
        right: 10px;
        width: 40px;
        z-index: 50;
        background: #333 url(source/plugin/<?php echo $pluginid;?>/template/touch/view/bdian.png) no-repeat center center;
        background-size: 25px;
    }
    .menu-list {
        top: 45px;
        z-index: 51;
        right:12px;
        position: fixed;
    }
</style>
<script type="text/javascript">
    $("#w-headMenu").click(function(){
        if($(".menu-list").css("display")=="none"){
            $(".menu-list").show();
        }else{
            $(".menu-list").hide();
        }
    });
</script>
<style type="text/css">
    .mui-nav-tab .tab-nav li:first-child{visibility: visible;}
    .module-title.class-title:before {
        width: 100%;
        position: absolute;
        top: 10px;
        left: 0;
        content: '';
        height: 1px;
        background: #f2f2f2;
    }
    .module-title.class-title {
        position: relative;
        width: 100%;
        text-align: left;
        margin: 20px auto 10px auto;
    }
    .module-title em {
        display: inline-block;
        position: relative;
        height: 12px;
        line-height: 12px;
        font-size: 12px;
        vertical-align: middle;
        padding: 0 10px;
    }
    .module-title.class-title em {
        background: #FFF;
        padding: 0 5px 0 0;
    }
    .tab-li h2 a {
        display: block;
        text-align: center;
        line-height: 35px;
        font-size: 12px;
        color: #fff;
        background-color: <?php if($settings['mobilenavbackcolor']['value']) { ?><?php echo $settings['mobilenavbackcolor']['value'];?><?php } else { ?>#DD2726<?php } ?>;
        margin:10px 0px 30px 0px;
    }
    .mui-nav-tab .tab-nav li.active {
        background: #fff;
        color: <?php echo $config['s_color'];?>;
        border-left:5px solid <?php if($settings['mobilenavbackcolor']['value']) { ?><?php echo $settings['mobilenavbackcolor']['value'];?><?php } else { ?>#DD2726<?php } ?>;
    }
    .module-title.class-title a {
        display: block;
        position: absolute;
        right: 0;
        top: .15rem;
        background: #FFF;
        padding: 0 10px 0 5px;
        height: 12px;
        line-height: 12px;
        font-size: 12px;
    }
    .module-title.class-title a i {
        position: absolute;
        right: 0;
        top: 0;
        display: block;
        width: .28rem;
        height: .48rem;
        background: url(source/plugin/<?php echo $pluginid;?>/template/touch/type/images/more.png) no-repeat;
        background-size: 100%;
        height: 12px;
        width: 7px;
    }
    .mui-nav-tab .tab-content {
        bottom: 50px;
    }
</style>

<div class="mui-nav-tab" id="J_tab">

    <div class="tab-container" id="J_tabContainer" >

        <div class="tab-content" id="J_tabContent" >

            <div class="tab-nav" id="J_tabNav" style="OVERFLOW-Y: auto; OVERFLOW-X:hidden;">
                <ul class="type_tab_nav">
                    
                    <?php if(is_array($kkk)) foreach($kkk as $k => $t) { ?>                    <li  data-id="<?php echo $t['id'];?>"  id="gtid_<?php echo $t['id'];?>" <?php if($k == 0) { ?>class="active"<?php } ?>><?php echo $t['subject'];?></li>

                    <?php } ?>
                </ul>
            </div>
            <div class="tab-menu" id="J_tabMenu" style="OVERFLOW-Y: auto; OVERFLOW-X:hidden;">

            </div>
        </div>
    </div>
</div>
<script src="source/plugin/<?php echo $pluginid;?>/template/touch/round_robin/round_robin.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<link rel="stylesheet" media="screen,projection,tv" href="source/plugin/<?php echo $pluginid;?>/template/touch/round_robin/round_robin.css?<?php echo VERHASH;?>" /></link>
<script type="text/javascript">
keep_scrollheight = 1;

jQuery(document).ready(function ($) {
    function lunzhuan(){
        var swiper = new Swiper('.swiper-container', {
            pagination: '.swiper-pagination',
            paginationClickable: true,
            spaceBetween: 30,
            loop : true,
            loopAdditionalSlides:1,
            autoplay: 3000,//��ѡѡ��Զ�����
        });
    }
    $(document).on('click', '.type_tab_nav li', function () {
        var tid = $(this).data('id');
        getdata(tid);
    });
    function getdata(id){
        var gtid='#gtid_'+id;
        $("#J_tabMenu").html('<div  style="text-align:center;margin-top:200px;"><img src="static/image/common/loading.gif" /></div>');
        $.post('plugin.php?id=aljbd&act=type&do=getdata',{"tid":id},function(data){
            $("#J_tabMenu").html(data);
            lunzhuan();
            sessionStorage.setItem(keep_page, 1);
            keep_scroll_init();
        });
        $(gtid).addClass('active').siblings().removeClass('active');
    }
    function keep_scroll_init(){
        if (keep_scrollheight) {
            
            sessionStorage.setItem(keep_scroll, $('#J_tabNav').scrollTop());
            sessionStorage.setItem(keep_data, $('#J_tabContent').html());
            $('#J_tabNav').scroll(function(){
                console.log(1);
                sessionStorage.setItem(keep_scroll, $('#J_tabNav').scrollTop());
                sessionStorage.setItem(keep_data, $('#J_tabContent').html());
            });
            $('#J_tabMenu').scroll(function(){
                console.log(2);
                sessionStorage.setItem(keep_scroll_1, $('#J_tabMenu').scrollTop());
                sessionStorage.setItem(keep_data, $('#J_tabContent').html());
            });
        }else{
            sessionStorage.removeItem(keep_page);
            sessionStorage.removeItem(keep_data);
            sessionStorage.removeItem(keep_scroll);
            sessionStorage.removeItem(keep_scroll_1);
        }
    }
    
    if (keep_scrollheight && sessionStorage.getItem(keep_page) == 1) {
        $('#J_tabContent').html(sessionStorage.getItem(keep_data));
        lunzhuan();
        $('#J_tabNav').scrollTop(sessionStorage.getItem(keep_scroll));
        $('#J_tabMenu').scrollTop(sessionStorage.getItem(keep_scroll_1));
        //console.log(sessionStorage.getItem(keep_data).length);
    } else {
        getdata(<?php echo $kkk['0']['id'];?>);
    }
    keep_scroll_init();
});
</script><?php include template('aljbd:footer'); ?></body>
</html>