<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<script>disallowfloat = 'newthread';</script>
<script src="source/plugin/aljtc/static/js/jquery.min.js" type="text/javascript"></script>
<link href="source/plugin/aljtc/static/js/layer/need/layer.css" rel="stylesheet" type="text/css">
<script src="source/plugin/aljtc/static/pclayer/layer.js" type="text/javascript"></script>
<script type="text/javascript">
    var jq = jQuery.noConflict();
</script>
<form id="cpform" action="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=<?php echo $pluginid;?>&do=<?php echo $_GET['do'];?>&pmod=attes&act=<?php echo $_GET['act'];?>" autocomplete="off" method="post" name="cpform">
<input type="hidden" value="<?php echo FORMHASH;?>" name="formhash">
<table class="tb tb2 nobdb">
<tbody><?php include template('aljtc:attes'); ?><tr class="header">
    <th></th>
    <th >申请人</th>
    <th>认证类型</th>
    <th>商家名</th>
    <th>ID</th>
    <th>照片</th>
    <th>申请时间</th>
    <th>状态</th>
    <th>&#25805;&#20316;</th>
</tr><?php if(is_array($atlist)) foreach($atlist as $bd) { ?><tr class="header">
    <td><input type="checkbox" value="<?php echo $bd['id'];?>" name="delete[]" class="checkbox"></td>
<td><?php echo $bd['username'];?></td>
<td><?php echo $typearr[$bd['type']];?></td>
<td><?php echo $bd['gongsiname'];?></td>
<td><?php echo $bd['num'];?></td>
<td>
    <?php if(strpos($bd['pic'],$oss_domain) !== false) { ?>
        <a href="<?php echo $bd['pic'];?>" target="_blank" class="img-bgloading aljsqImg">
            <img src="<?php echo $bd['pic'];?>" style="width:140px;height:100px;">
        </a>
    <?php } elseif(file_exists($tmp_key_value)) { ?>
        <a href="<?php echo $_G['siteurl'];?><?php echo $bd['pic'];?>" target="_blank" class="img-bgloading aljsqImg">
            <img src="<?php echo $bd['pic'];?>" style="width:140px;height:100px;">
        </a>
    <?php } ?>
</td>
<td><?php echo gmdate('Y-m-d H:i:s',$bd['timestamp']+8*3600);?></td>
<td><?php if($bd['sign']) { ?>已审核<?php } else { ?>未审核<?php } ?></td>
<td class="td_l">
    <a href="javascript:void(0);" onclick="showiframe(<?php echo $bd['uid'];?>,<?php echo $bd['type'];?>);">&#32534;&#36753;</a>
</td>
</tr>
<?php } ?>
<tr><td colspan="3"><div class="fixsel"><input type="checkbox" onclick="checkAll('prefix', this.form, 'delete','chkallUMP3')" class="checkbox" id="chkallUMP3" name="chkall"><label for="chkallUMP3"><?php if($_GET['act']!='yes') { ?>审/<?php } ?>删？</label>&nbsp;<?php if($_GET['act']!='yes') { ?><input type="submit" value="批量审核"  name="sh_submit" id="sh_submit" class="btn">&nbsp;<input type="submit" value="批量删除"  name="del_submit" id="del_submit" class="btn"><?php } else { ?><input type="submit" value="提交" title="" name="submit" id="submit_submit" class="btn"><?php } ?></div></td><td><?php echo $paging;?></td></tr>
</tbody></table>
</form>
<script>
function showiframe(id,type) {
    var formurl = '';
    if(type == 2){
        formurl = '&form=gongsi';
    }
    layer.open({
        type: 2,
        title: '&#32534;&#36753;&#27169;&#24335;',
        shadeClose: true,
        shade: 0,
        area: ['60%', '90%'],
        offset: ['5%', '16%'],
        anim: 5,
        content: 'plugin.php?id=aljtc&act=attes&adminedit=yes&uid='+id+formurl
    });
}
function tips(txt, fun) {
    if(fun){
        layer.alert(txt, {icon: 6},function(){
            layer.closeAll(); //���ģʽ���ر����в�
            location.href=location.href;
        });
    }else{
        layer.msg(txt);
    }
}
</script>