<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div style="height:80px"></div>
<footer class="footerarea">
<ul class="flex_box" id="foot-list">
<li class="flex active" onclick="switch_list(1,this);">
<i class="iconfont icon-xiaoxi"></i>
消息
</li>
<li class="flex" onclick="switch_list(2,this);">
<i class="iconfont icon-haoyou"></i>
联系人
</li>
</ul>
</footer>
</body>
</html>
