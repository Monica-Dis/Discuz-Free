<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($settings['mobile_footer_nav']['value']) { ?>
            <style>.indexBox {top:-22px;}</style>
                <?php $mobile_footer_nav = explode ("\n", str_replace ("\r", "", $settings['mobile_footer_nav']['value']));
                foreach($mobile_footer_nav as $key=>$value){
                    $arr=explode('|',$value);
                    $mobile_footer_nav_arr[]=$arr;
                }
                $c_li_w = sprintf("%.3f",(100/count($mobile_footer_nav)));?>                <style>#c_main_menu li{width:<?php echo $c_li_w;?>%;}</style>
                <?php $is_sy = !$_GET['act'] && ($_GET['id'] == 'aljtc' || $_GET['id'] == 'aljtc:aljtc' || !$_GET['id']) ? 1 : 0;?>        <?php $is_qt = ($_GET['id'] == 'aljbd:so' || $_GET['id'] == 'aljgwc' || $_GET['id'] == 'aljol' || $_GET['id'] == 'aljsd' || $_GET['id'] == 'aljspt') && $_GET['act'] != 'user' ? 1 : 0;?>                <?php if(is_array($mobile_footer_nav_arr)) foreach($mobile_footer_nav_arr as $mcfk => $mcfv) { ?>                    <?php if($mcfv['4'] == 1) { ?>
                    <?php if($_GET['zufangtype']>0 && strpos($mcfv['3'], 'act=posttype') !== false) { ?>
                        <?php if($_GET['subtype']>0) { ?>
                            <?php $p_url = 'plugin.php?id=aljtc&act=post&typeid='.$_GET['zufangtype'].'&sid='.$_GET['subtype'];?>                        <?php } else { ?>
                            <?php $p_url = 'plugin.php?id=aljtc&act=posttype&zufangtype='.$_GET['zufangtype'];?>                        <?php } ?>
                    <?php } else { ?>
                        <?php $p_url = $mcfv[3];?>                    <?php } ?>
                        <li id="nav_post" <?php if(($is_sy && $mcfk == 0) || strpos($mcfv['3'], $_GET['act']) !== false || (strpos($mcfv['3'], $_GET['id']) !== false && $is_qt)) { ?>class="c_menu_this"<?php } ?>>
                            <a href="<?php echo $p_url;?>">
                                <div class="nav_post1 nav_post" ></div>
                                <div class="indexBox">
                                    <?php if(strpos($mcfv['0'],'/')===false) { ?><style>.indexBox{top:-28px;}</style><?php } ?>
                                        <?php if(($is_sy && $mcfk == 0) || strpos($mcfv['3'], $_GET['act']) !== false || (strpos($mcfv['3'], $_GET['id']) !== false && $is_qt)) { ?>
                                        <i class="post-i">
                                            <?php if(strpos($mcfv['0'],'/')!==false) { ?><img src="<?php echo $mcfv['0'];?>" /> <?php } else { ?><i class="iconfont <?php echo $mcfv['0'];?> post-i"></i><?php } ?>
                                        </i>
                                        <?php } else { ?>
                                        <i class="post-i">
                                            <?php if(strpos($mcfv['1'],'/')!==false) { ?><img src="<?php echo $mcfv['1'];?>" /> <?php } else { ?><i class="iconfont <?php echo $mcfv['1'];?> post-i"></i><?php } ?>
                                        </i>
                                        <?php } ?>
                                </div>
                                <b class="post-p"><?php echo $mcfv['2'];?></b>
                            </a>
                        </li>
                    <?php } else { ?>
                        <li id="nav_index" <?php if(($is_sy && $mcfk == 0) || strpos($mcfv['3'], $_GET['act']) !== false || (strpos($mcfv['3'], $_GET['id']) !== false && $is_qt)) { ?>class="c_menu_this"<?php } ?>>
                            <a href="<?php echo $mcfv['3'];?>">
                                <?php if(($is_sy && $mcfk == 0) || strpos($mcfv['3'], $_GET['act']) !== false || (strpos($mcfv['3'], $_GET['id']) !== false && $is_qt)) { ?>
                                <?php if(strpos($mcfv['0'],'/')!==false) { ?><span><img src="<?php echo $mcfv['0'];?>" /></span> <?php } else { ?><span class="iconfont <?php echo $mcfv['0'];?>"></span><?php } ?>
                                <?php } else { ?>
                                <?php if(strpos($mcfv['1'],'/')!==false) { ?><span><img src="<?php echo $mcfv['1'];?>" /></span> <?php } else { ?><span class="iconfont <?php echo $mcfv['1'];?>"></span><?php } ?>
                                <?php } ?>
                                <b><?php echo $mcfv['2'];?></b>
                                <?php if($newscount && strpos($mcfv['3'], $settings['footer_red_dot']['value']) !== false) { ?>
                                <i class="c_news"><?php echo $newscount;?></i>
                                <?php } ?>
                            </a>
                        </li>
                    <?php } ?>
                <?php } ?>
            <?php } else { ?>
                <li id="nav_index" <?php if(!$_GET['act']) { ?>class="c_menu_this"<?php } ?>>
                <a href="plugin.php?id=aljtc">
                    <span class="iconfont icon-ziyuan"></span>
                    <b>&#39318;&#39029;</b>
                </a>
                </li>
                <?php if($_G['cache']['plugin']['aljtsq']['is_aljtsq']) { ?>
                <li id="nav_goods" >
                <a href="plugin.php?id=aljtsq">
                    <span class="iconfont icon-shangjia"></span>
                    <b>&#21830;&#22280;</b>
                </a>
                </li>
                <?php } else { ?>
                <li id="nav_goods" <?php if($_GET['act'] == 'list') { ?>class="c_menu_this"<?php } ?>>
                <a href="plugin.php?id=aljtc&amp;act=list&amp;subrid=<?php echo $_COOKIE['subrid'];?>">
                    <span class="iconfont icon-all"></span>
                    <b>&#21015;&#34920;</b>
                </a>
                </li>
                <?php } ?>
                <li id="nav_post" <?php if($_GET['act'] == 'posttype') { ?>class="c_menu_this"<?php } ?>>
                    <?php if($_GET['zufangtype']>0) { ?>
                    <?php if($_GET['subtype']>0) { ?>
                    <?php $p_url = 'plugin.php?id=aljtc&act=post&typeid='.$_GET['zufangtype'].'&sid='.$_GET['subtype'];?>                    <?php } else { ?>
                    <?php $p_url = 'plugin.php?id=aljtc&act=posttype&zufangtype='.$_GET['zufangtype'];?>                    <?php } ?>
                    <?php } else { ?>
                    <?php $p_url = 'plugin.php?id=aljtc&act=posttype';?>                    <?php } ?>
                    <a href="<?php echo $p_url;?>">
                        <div class="nav_post1 nav_post" ></div>
                        <div class="indexBox">

                                <i class="iconfont icon-fabu post-i"></i>

                        </div>
                        <b class="post-p">发布</b>
                    </a>
                </li>
                <?php if($_G['cache']['plugin']['aljbd']) { ?>
                <li id="nav_resume" >
                    <a href="plugin.php?id=aljbd">
                        <span class="iconfont icon-shangpin"></span>
                        <b>&#21830;&#22478;</b>
                    </a>
                </li>
                <?php } elseif($_G['cache']['plugin']['aljwm']) { ?>
                    <li id="nav_resume">
                        <a href="plugin.php?id=aljwm" >
                            <span class="iconfont icon-ziyuan5"></span>
                            <b>&#22806;&#21334;</b>
                        </a>
                    </li>
                <?php } elseif($_G['cache']['plugin']['aljtyh']) { ?>
                    <li id="nav_resume">
                        <a href="plugin.php?id=aljtyh" >
                            <span class="iconfont icon-youhui"></span>
                            <b>&#20248;&#24800;</b>
                        </a>
                    </li>
                <?php } else { ?>
                <li id="nav_resume" <?php if($_GET['act'] == 'search') { ?>class="c_menu_this"<?php } ?>>
                <a href="plugin.php?id=aljtc&amp;act=search">
                    <span class="iconfont icon-sousuo"></span>
                    <b>&#25628;&#32034;</b>
                </a>
                </li>
                <?php } ?>
                <li id="nav_member" <?php if($_GET['act'] == 'user') { ?>class="c_menu_this"<?php } ?>>
                <a href="<?php if($_G['cache']['plugin']['aljhtx']['is_aljtc'] && !$_G['cache']['plugin']['aljtc']['footernav'] && $_G['cache']['plugin']['aljbd']) { ?>plugin.php?id=aljbd&act=user<?php } else { ?>plugin.php?id=aljtc&act=user<?php } ?>">
                    <span class="iconfont icon-wode"></span>
                    <b>&#25105;&#30340;</b>
                </a>
                </li>
            <?php } ?>