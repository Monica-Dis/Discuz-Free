<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>

<script>
    function iframebood(bid){
        //iframe窗
        location.href='plugin.php?id=aljbzj&bid='+bid;
        return ;
        layer.open({
            type: 2,
            title: '缴纳保证金',
            shadeClose: true,
            shade: false,
            maxmin: true, //开启最大化最小化按钮
            area: ['540px', '70%'],
            content: 'plugin.php?id=aljbzj&bid='+bid
        });
    }
</script>