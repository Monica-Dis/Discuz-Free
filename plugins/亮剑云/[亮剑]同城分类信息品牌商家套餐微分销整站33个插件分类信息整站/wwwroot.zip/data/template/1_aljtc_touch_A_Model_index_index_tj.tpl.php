<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<style>
    .weui-cell-count {
            padding: 5px 15px;
            position: relative;
            display: -webkit-box;
            display: -webkit-flex;
            display: flex;
            -webkit-box-align: center;
            -webkit-align-items: center;
            align-items: center;
        }
        .weui-cell-count p {
            font-size: 14px;
            padding:5px 0px 0px;
            text-align: right;
        }
        .weui-cell-count__bd {
            -webkit-box-flex: 1;
            -webkit-flex: 1;
            flex: 1;
            color:#666;
        }
        .weui-cell-count__bd span{
            color:#f42424;
            font-size: 15px;
        }
        .mr5{margin-right:5px;}
        .mr10{margin-right:10px;}
        .ml10{margin-left:10px;}
        .weui-cell-count__ft {
            text-align: right;
            color: #999;
        }
        .c_c_p{
            padding:0px 6px;
            color:#ccc;
        }
</style>
<?php if($_G['cache']['plugin']['aljhelp']) { ?>
    <div class="weui-cell-count" style="background: #ffffff;">
        <div class="weui-cell-count__bd">
            <p style="text-align: left;">
                <?php echo $v_p_num;?>
                <a href="plugin.php?id=aljhelp" style="color: #999;float: right;">&#24110;&#21161;</a>
            </p>
        </div>
        <div class="weui-cell-count__ft"></div>
    </div>
<?php } else { ?>
    <div class="weui-cell-count" style="background: #ffffff;">
        <div class="weui-cell-count__bd">
            <p>
                <?php echo $v_p_num;?>
            </p>
        </div>
        <div class="weui-cell-count__ft"></div>
    </div>
<?php } ?>