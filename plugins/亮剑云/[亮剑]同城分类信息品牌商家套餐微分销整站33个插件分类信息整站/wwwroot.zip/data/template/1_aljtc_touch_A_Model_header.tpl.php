<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET;?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
<meta name="format-detection" content="telephone=no" />
<base href="<?php echo $_G['siteurl'];?>" />
<script src="source/plugin/aljtc/static/js/jquery.min.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<link href="source/plugin/aljtc/static/js/weui/weui.min.css?<?php echo VERHASH;?>" rel="stylesheet" type="text/css">
<link href="source/plugin/aljtc/static/js/weui/jquery-weui.min.css?<?php echo VERHASH;?>" rel="stylesheet" type="text/css">
<link href="source/plugin/aljtc/static/js/layer/need/layer.css?<?php echo VERHASH;?>" rel="stylesheet" type="text/css">
<link href="source/plugin/aljtc/static/css/fonts/iconfont.css?<?php echo VERHASH;?>" rel="stylesheet" type="text/css">
<script src="source/plugin/aljtc/static/js/layer/layer.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<script src="source/plugin/aljtc/static/js/weui/jquery-weui.min.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<script src="source/plugin/aljtc/static/js/lrz.mobile.min.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<link rel="stylesheet" href="source/plugin/aljtc/static/js/swiper/swiper.min.css?<?php echo VERHASH;?>" />
<script src="source/plugin/aljtc/static/js/swiper/swiper.min.js?<?php echo VERHASH;?>" type="text/javascript" type="text/javascript"></script>
<link rel="stylesheet" href="source/plugin/aljtc/static/css/style.css?<?php echo VERHASH;?>" />
<title><?php echo $navtitle;?></title>
<meta name="description" content="<?php echo $description;?>">
<meta name="keywords" content="<?php echo $metakeywords;?>">
<script>var auto_lbs=0,fastclick=0;</script>
<style>
.c_news {
    display: inline-block;
    position: absolute;
    top: 2px;
    background-color: #f23030;
    height: 14px;
    line-height: 14px;
    padding-left: 5px;
    padding-right: 5px;
    font-style: normal;
    border-radius: 12px;
    right: 20%;
    font-size: 9px;
    color: #fff !important;
    font-family: PingFangSC-Regular,Helvetica,"Droid Sans",Arial,sans-serif;
    border: 1px solid #fff;
}
</style>
</head><?php include template('aljtc:A_Model/loading'); include template('aljtc:A_Model/page_color'); if(strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false) { include template('aljapp:uniapp'); } $no_act_array = array('administrators','user','all','search');?><?php if((
    ($_GET['act'] 
    &&  !in_array($_GET['act'],$no_act_array)  
    && ($_GET['id'] == 'aljtc' || $_GET['id'] == 'aljtc:aljtc')
    )
    || ($_GET['id'] == 'aljtfz')
    || ($_GET['id'] == 'aljskm')
    || ($_GET['id'] == 'aljtsq' && $_GET['a'] && $_GET['a'] != 'storeView')
    || ($_GET['id'] == 'aljthd' && $_GET['a'] && $_GET['a']!='view')
    || ($_GET['id'] == 'aljhhr' && $_GET['a'] && $_GET['a']!='user')
    || ($_GET['id'] == 'aljbzj' && $_GET['a'] && $_GET['a']=='bondLog')
    || ($_GET['id'] == 'aljtsc' && $_GET['a'] && $_GET['a']=='btype')
    || ($_GET['id'] == 'aljtyh' && $_GET['a'] && $_GET['a']!='view' && $_GET['a']!='voucherView')
    || ($_GET['id'] == 'aljwm' && $_GET['a'] && $_GET['a']!='view' && $_GET['a']!='pay' && $_GET['a']!='orderView' && $_GET['a']!='alist')
    || ($_GET['id'] == 'aljrz' && $_GET['a'] && $_GET['a']=='certificationAudit')
    )  
&& (($_G['cache']['plugin']['aljtc']['common_header']==2 && !$ismini && !$isappbyme) || ($_G['cache']['plugin']['aljtc']['common_header']==1)) && $_GET['adminedit'] != 'yes') { ?>
<style>
    .sh_header {
        width: 100%;
        height: 42px;
        line-height: 42px;
        text-align: center;
        color: <?php echo $_G['cache']['plugin']['aljtc']['common_header_color'];?>;
        font-size: 15px;
        overflow: hidden;
        background: <?php echo $_G['cache']['plugin']['aljtc']['common_header_bg_color'];?>;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 100;
    }
    .weui-navbar,.list_nav_l{top:42px !important;}
    .z {
        float: left;
    }
    .navtitle {
        width: 60%;
        text-align: center;
        margin: 0 auto;
        height: 42px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }
    .sh_header a {
        display: block;
        height: 42px;
        line-height: 42px;
        margin: 0;
        color: <?php echo $_G['cache']['plugin']['aljtc']['common_header_color'];?>;
        padding: 0 15px;
        text-align: center;
        overflow: hidden;
        position: absolute;
    }
    .sh_header_null {
        position: relative;
        clear: both;
        height: 42px;
    }
    .sh_header .ry {
        right: 0;
        font-size: 14px;
    }
    .sh_header i{
        width: 15px;
        display: inline-block;
        font-size: 20px;
    }
    .tab-nav{top:44px !important;}
    </style>
    
    <header class="sh_header">
        <a class="z class_back" href="javascript:;"><i class="iconfont icon-huise"></i></a>
        
        <div class="navtitle"><?php echo $title?$title:$navtitle?></div>
    </header>
    <div class="sh_header_null"></div>
    
<?php } ?>
<script>
    jQuery(document).on('click', '.class_back,.header-left', function() {
        <?php if(strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false) { ?>
            if(document.referrer == ''){
                currentWebview().close();
                return false;
            }else{
                history.back();
                return false;
            }
        <?php } elseif(false !== strpos($_SERVER['HTTP_USER_AGENT'],'swan')) { ?>
            if(document.referrer == ''){
                swan.webView.navigateBack({ changed: true });//������һҳ
            }else{
                history.back();
                return false;
            }
        <?php } elseif(strpos(strtolower($_SERVER['HTTP_USER_AGENT']),"miniprogram") !== false) { ?>
            if (window.__wxjs_environment === 'miniprogram') {
                if(document.referrer == ''){
                    wx.miniProgram.navigateBack({ changed: true });//������һҳ
                }else{
                    history.back();
                    return false;
                }
                return false;
            }
        <?php } ?>
        if($('#back_url').length > 0){
            location.href = $('#back_url').data('url');
        }else{
            history.go(-1);
        }
        return false;
    });
</script>