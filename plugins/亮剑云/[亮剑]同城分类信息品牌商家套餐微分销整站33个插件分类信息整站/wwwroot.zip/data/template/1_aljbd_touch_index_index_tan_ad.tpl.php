<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($_G['cache']['plugin']['aljbd']['mobile_index_tan_ad']) { ?>
<div class="app-download-popup smally" id="aljbd_index_tanc" style="display: none;">
    <div class="app-download-popup-inner">
        <i class="btn-close"><span style="color:#ffbe22;" id="second"><?php if($_G['cache']['plugin']['aljbd']['mobile_index_tan_ad_time']>0) { ?><?php echo $_G['cache']['plugin']['aljbd']['mobile_index_tan_ad_time'];?><?php } else { ?>3<?php } ?></span><span style="color:#ffbe22;">&#31186;&nbsp;</span>&#20851;&#38381;</i>
        <?php echo $_G['cache']['plugin']['aljbd']['mobile_index_tan_ad'];?>
    </div>
</div>

<style>
    .app-download-popup {
        position: fixed;
        overflow: auto;
        width: 100%;
        height: 100%;
        top: 0;
        bottom: 0;
        right: 0;
        background-color: rgba(0,0,0,.3);
    }
    .app-download-popup-inner img{
        border-radius: 15px;
        max-width:100%;
        margin: 0 auto;
    }

    .app-download-popup {
        z-index: 9999!important;
    }
    .app-download-popup.smally .app-download-popup-inner {
        width: 90%;
        border-radius: 6px;
        height: auto;
        overflow: visible;
        top: 50%;
        -webkit-transform: translateY(-50%);
        -ms-transform: translateY(-50%);
        transform: translateY(-50%);
        text-align: center;
    }
    .app-download-popup .app-download-popup-inner {
        position: relative;
        width: 100%;
        height: 100%;
        background-size: cover;
        background-repeat: no-repeat;
        margin: 0 auto;
        overflow: auto;
        -webkit-overflow-scrolling: touch;
        overflow-scrolling: touch;
    }
    .app-download-popup .banner {
        width: 100%;
        display: block;
        border-radius: 6px;
    }
    .app-download-popup .btn-close {
        position: absolute;
        display: flex;
        bottom: -35px;
        justify-content: center;
        color: #d9d9d9;
        align-items: center;
        background: rgba(0,0,0,.3);
        border-radius: 10px;
        right: 50%;
        margin-right: -40px;
        width: 80px;
        height: 21px;
        font-size: 12px;
    }
    i{font-style: normal;}
</style>
<script>
    $(function () {
        var rate_time = <?php if($settings['mobile_index_tan_ad_rate_time']['value']) { ?><?php echo $settings['mobile_index_tan_ad_rate_time']['value'];?><?php } else { ?>86400<?php } ?>;
        rate_time = rate_time * 1000;
        if(localStorage_get("aljbd_index_tanc",rate_time) == 1) {
            $('#aljbd_index_tanc').show();
            localStorage_set("aljbd_index_tanc", 2);
            var i=<?php if($_G['cache']['plugin']['aljbd']['mobile_index_tan_ad_time']>0) { ?><?php echo $_G['cache']['plugin']['aljbd']['mobile_index_tan_ad_time'];?><?php } else { ?>3<?php } ?>;
            var j = setInterval(function(){
                i--;
                if(i) {
                    $('#second').html(i);
                }else {
                    $('#aljbd_index_tanc').hide();
                    clearInterval(j);
                    //window.sessionStorage.setItem("aljbd_index_tanc", 1);
                }
            },1000)
        }
        $('.btn-close').click(function(){
            $('#aljbd_index_tanc').hide();
        })
    });
</script>
<?php } ?>