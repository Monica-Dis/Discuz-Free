<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($_G['cache']['plugin']['aljol']['footer_type'] == 1 && $_G['cache']['plugin']['aljbd']) { $settings=C::t('#aljbd#aljbd_setting')->range();
$mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_common_footernav']['value']));
foreach($mobile_common_footernav as $key=>$value){
$arr=explode('|',$value);
$mobile_common_footernav_arr[]=$arr;
}
$newscount = DB::result_first('select count(*) from %t where friendid=%d and talkstate=1',array('aljol_talk',$_G['uid']));
$new_noti = DB::result_first('select count(*) from %t where uid=%d and status=0 and news_type=1',array('aljhtx_notification',$_G['uid']));
$newscount = $newscount + $new_noti;?><style>
.nav-cont li a img {
display: inline;
}
.footermenu ul{
z-index: 99999 !important;
}
.c_news{
display: inline-block;
position: absolute;
top: 2px;
background-color: #f23030;
height: 14px;
line-height: 14px;
padding-left: 5px;
padding-right: 5px;
font-style: normal;
border-radius: 12px;
right: 20%;
font-size: 9px;
color: #fff !important;
font-family: PingFangSC-Regular,Helvetica,"Droid Sans",Arial,sans-serif;
border: 1px solid #fff;
}
</style><?php include template('aljbd:footer_nav'); } elseif($_G['cache']['plugin']['aljol']['footer_type'] == 2 && $_G['cache']['plugin']['aljol']['custom_footer']) { ?>
<style>
.ol_null_footer{
height:52px;
}
@supports (bottom: constant(safe-area-inset-bottom)) or (bottom: env(safe-area-inset-bottom)) {
.ol_null_footer{
height: calc(52px + constant(safe-area-inset-bottom));
height: calc(52px + env(safe-area-inset-bottom));
}
.footerarea{
padding-bottom: constant(safe-area-inset-bottom);
padding-bottom: env(safe-area-inset-bottom);
}
}
</style>
<div class="ol_null_footer"></div>
<footer class="footerarea">
<ul class="flex_box" id="foot-list" style="padding-bottom: 5px;"><?php $custom_footer = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljol']['custom_footer']));
foreach($custom_footer as $key=>$value){
$arr=explode('|',$value);
$mobile_custom_footer[]=$arr;
}?><?php if(is_array($mobile_custom_footer)) foreach($mobile_custom_footer as $k => $v) { ?><a class="flex active" href="<?php echo $v['2'];?>">
<i class="iconfont" style="background: url(<?php echo $v['0'];?>) no-repeat scroll 5% center / 20px auto;background-size: 22px;margin: 0 auto;width: 22px;height: 22px;"></i>
<?php echo $v['1'];?>
</a>
<?php } ?>

</ul>
</footer>
<?php } else { ?>
<style>
.ol_null_footer{
height:52px;
}
@supports (bottom: constant(safe-area-inset-bottom)) or (bottom: env(safe-area-inset-bottom)) {
.ol_null_footer{
height: calc(52px + constant(safe-area-inset-bottom));
height: calc(52px + env(safe-area-inset-bottom));
}
.footerarea{
padding-bottom: constant(safe-area-inset-bottom);
padding-bottom: env(safe-area-inset-bottom);
}
}
</style>
<div class="ol_null_footer"></div>
<footer class="footerarea">
<ul class="flex_box" id="foot-list" style="padding-bottom: 5px;">
<?php if(file_exists('source/plugin/aljol/template/touch/index.htm')) { include template('aljol:index'); } ?>
<li class="flex active" onclick="switch_list(1,this);">
<i class="iconfont icon-xiaoxi"></i>
消息
</li>
<li class="flex" onclick="switch_list(2,this);">
<i class="iconfont icon-haoyou"></i>
联系人
</li>
<?php if(($_G['cache']['plugin']['aljgwc']['aljol'] || $_G['cache']['plugin']['aljbdx']['aljol']) && $_G['cache']['plugin']['aljol']['footernav']) { $footernav = explode('|',$_G['cache']['plugin']['aljol']['footernav'])?><li class="flex" onclick="window.location.href='<?php echo $footernav['2'];?>'">
<i class="iconfont" style="background: url(<?php echo $footernav['0'];?>) no-repeat scroll 5% center / 20px auto;background-size: 22px;margin: 0 auto;width: 22px;height: 22px;"></i>
<?php echo $footernav['1'];?>
</li>
<?php } ?>
</ul>
</footer>
<?php } ?>
</body>
</html>
