<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
$(".price1").text('单独购买价格');
$(".starttime").hide();//开始时间隐藏
$(".endtime").hide();//结束时间隐藏
$(".gwurl").hide();//外商品链接隐藏
$(".category").hide();//商品类别隐藏
$(".collage_price").show();//拼团价显示
$(".collage_num").show();//拼团人数显示
$("#category").html('<input type="hidden" name="category" value="0" >');//商品类别指定为实物
$(".price1").next().attr("placeholder","单独购买价格");