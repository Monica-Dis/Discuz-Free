<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('aljbd_list');?><?php include template('aljbd:index_header'); if(1) { include template('aljbd:new/index'); } else { ?>
<link href="source/plugin/aljbd/css/new_index/pagestyle.css" rel="stylesheet">
<link href="source/plugin/aljbd/css/style.css" rel="stylesheet">
<style type="text/css">
/* �б�ͼƬ����-Ĭ�϶������ߡ�ͼƬ���� */
.u-img2{display:block;position:relative;width:130px;height:130px;padding:5px;border:1px solid #ccc;}
.u-img2 img{display:block;width:100%;height:100%;}
.right dd a{color:#999;}
.shop-top {
  background: none repeat scroll 0 0 <?php echo $config['ddcolor'];?>;
  border-bottom: 2px solid #999;
  height: 33px;
  line-height: 33px;
  width: 100%;
}
.tungou ul li {
  display: inline;
  float: left;
  margin: 20px 15px 0 10px;
  width: 165px;
}
.youhui .title a {
  color: #333;
}
.shop-main .shop-title a {
  color: #333;
  font-size: 14px;
  font-weight: bold;
}

.column-news dt {
  background: none repeat scroll 0 0 <?php echo $config['ddcolor'];?>;
  color: #333;
  font-size: 14px;
  font-weight: bold;
  letter-spacing:1px;
}
.column-top {
color: #333;
  font-size: 14px;
  font-weight: bold;
  letter-spacing:1px;
}

.pd {
  margin-top: 10px;
}
.layout{
margin-top:10px;
}


.shop-main .shop-img img {
  height: 130px;
  width: 130px;
}
.shop-main ul li {
  display: inline;
  float: left;
  <?php if(($config['ispd'] && !$settings['templatepx']['value']) || ($config['ispd'] && !$config['is_daohang']&& !$settings['templatepx']['value'])) { ?>
  margin: 20px 15px 0 25px;
  <?php } else { ?>
  <?php if(!$settings['templatepx']['value']) { ?>
margin: 20px 8px 0 18px;
  <?php } else { ?>
margin: 20px 10px 0 10px;
  <?php } ?>
  <?php } ?>
  text-align: center;
  width: 130px;
}

.shop-top h1{
color:#333;
letter-spacing:1px;
font-weight:bold;
}
.youz .shop-main li {
margin-right: 15px;
}

.meng-main ul li{margin: 20px 15px 0 10px;}
.slides{position:static}
.shop-top h1 {
  color: #333;
  font-weight: bold;
  letter-spacing: 1px;
  border-left:4px solid <?php echo $_G['cache']['plugin'][$pluginid]['color_daohang'];?>;
  line-height:24px;
}
.img_8s {-webkit-transition-duration: .8s;-moz-transition-duration: .8s;-ms-transition-duration: .8s;-o-transition-duration: .8s;transition-duration: .8s;}
.img_8s:hover {-webkit-transform: scale(1.15, 1.15);-khtml-transform: scale(1.15, 1.15);-moz-transform: scale(1.15, 1.15);-ms-transform: scale(1.15, 1.15);-o-transform: scale(1.15, 1.15);transform: scale(1.15, 1.15);}
</style>
<link href="source/plugin/aljbd/js/index_new/flexslider.css" rel="stylesheet">

                <script src="source/plugin/aljbd/js/index_new/jquery.flexslider-min.js" type="text/javascript" type="text/javascript"></script>
<style id="diy_style" type="text/css"></style>
    <!--banner-->
    <div class="wrap c1">
        <div class="layout c1">
            
            <!--bannerͼƬ-->
        	<div class="banner_lj" >
<div class="flexslider" >

<ul class="slides"> <?php if(is_array($index_lz_types)) foreach($index_lz_types as $k => $v) { ?><li style="display: block;">
<a href='<?php echo $v;?>' target='_blank'><img src='<?php echo $k;?>' <?php if($settings['templatepx']['value']) { ?>width='956'<?php } else { ?>width='716'<?php } ?> height='290' /></a></li>
<?php } ?> 
        
</ul> 
</div>
            </div>
                
            <script>
//�õ�Ƭ������	
lj_jq(function() {
lj_jq(".flexslider").flexslider({

animation: "slide",
direction:"horizontal",
easing:"swing",
slideshowSpeed: 4000, //չʾʱ����ms
animationSpeed: 400, //����ʱ��ms
touch: true //�Ƿ�֧�ִ�������

});
});	
</script>
            <script type="text/javascript">
          
        	
lj_jq(function(){	   
  lj_jq(".column-span").mousemove(function(){					 
lj_jq(".column-span").each(function(i){				
lj_jq(this).attr("style","border-bottom:1px solid #e9e9e9;")}
);
if(lj_jq(this).attr("num")=="0"){
lj_jq("#news-list0").show();
lj_jq("#news-list1").hide();
lj_jq("#news-list2").hide();
lj_jq(this).attr("style","border-bottom:0px;border-right:1px solid #e9e9e9; color:#c24040");
}else if(lj_jq(this).attr("num")=="1"){
lj_jq("#news-list1").show();
lj_jq("#news-list2").hide();
lj_jq("#news-list0").hide();
lj_jq(this).attr("style","border-bottom:0px;border-right:1px solid #e9e9e9;border-left:1px solid #e9e9e9; color:#c24040");
}
else{
lj_jq("#news-list2").show();
lj_jq("#news-list1").hide();
lj_jq("#news-list0").hide();
lj_jq(this).attr("style","border-bottom:0px;border-left:1px solid #e9e9e9; color:#c24040");
}
});   
});
</script>

<div class="lj_rz">

<div id="button" class="mbm cl">
<a href="plugin.php?id=aljbd&amp;act=attend" class="lj_btn" style="float:left;"  ><?php echo $config['attend'];?></a>
<a onclick="<?php if(empty($aljbd)) { ?>showDialog('您还没有入驻哦，先申请吧！');return false;<?php } else { ?>location.href=this.href<?php } ?>" href="plugin.php?id=aljbd&amp;act=member" class="lj_btn d"><?php echo $config['aljbd'];?></a>
</div>

</div>
            <!--��Ѷ����-->

            <div class="news bor" style="margin-top:0px;width:230px">

                <span class="column-span" style="<?php if(!$settings['index_gg']['value']) { ?>border-right:1px solid #e9e9e9;<?php } ?> color:#c24040;" num="0">
                    <span aria-hidden="true" class="icon-mobile" style="color:#000;padding-right:5px;"></span>二维码</span>
<?php if(!$settings['index_gg']['value']) { ?>
                     <span class="column-span" style="border-bottom:1px solid #e9e9e9;" num="1">
                  <span aria-hidden="true" class="icon-news" style="color:#000;padding-right:5px;"></span>&#20844;&#21578;</span>
<?php } if(!$config['is_daohang']&&$yd_types) { ?>
<style type="text/css">
.column-span{width:75px}
</style>
<span class="column-span" style="border-bottom:1px solid #e9e9e9;" num="2">
                  <span aria-hidden="true" class="icon-news" style="color:#000;padding-right:5px;"></span>&#23548;&#33322;</span>
<?php } ?>

                <ul class="news-list-lj newsL-1" id="news-list0" >
                  
                   <div style="text-align:center;">
                        <img style="height:180px;width:180px;" src="<?php echo $_G['siteurl'];?>/source/plugin/aljbd/images/qrcode/aljbd_qrcode.jpg">
</div>
<p style="text-align:center;">扫描二维码进入品牌商家手机版</p>
                   
                </ul>
<?php if(!$settings['index_gg']['value']) { ?>
                <ul class="news-list-lj newsL-1" style='display:none;' id="news-list1" ><?php if(is_array($gg_types)) foreach($gg_types as $k => $v) { ?>                    <li>
                    <a target="_blank" href="<?php echo $v;?>" title="<?php echo $k;?>"><?php echo $k;?></a>
                    </li>
<?php } ?>
                </ul>
<?php } ?>
            <!--��Ѷ���� end-->
<div class="news-list-lj newsL-1 daren_lj" style='display:none;' id="news-list2" >
                  
                   
   <style type="text/css">
.daren_lj ul li {
  display: inline;
  float: left;
  height: 74px;
  margin: 5px;
  width: 64px;
  text-align: center;
  white-space:normal;
}
   </style>
<ul><?php if(is_array($yd_types)) foreach($yd_types as $yd) { ?><li><a href="<?php echo $yd['1'];?>"><img src="<?php echo $yd['2'];?>" width="54" height="54" alt="" ><?php echo $yd['0'];?>
</a>
</li>
<?php } ?>

   </ul>

                   
                </div>
        </div>

    </div>
    <script type="text/javascript">
//�������
lj_jq(function(){ 
//����Ӧ��@Mr.Think 
var _wrap=lj_jq('#s2');//����������� 
var _interval=2000;//���������϶ʱ�� 
var _moving;//��Ҫ����Ķ��� 
_wrap.hover(function(){ 
clearInterval(_moving);//������ڹ���������ʱ,ֹͣ���� 
},function(){ 
_moving=setInterval(function(){ 
var _field=_wrap.find('li:first');//�˱������ɷ����ں�����ʼ��,li:firstȡֵ�Ǳ仯�� 
var _h=_field.height();//ȡ��ÿ�ι����߶� 
_field.animate({marginTop:-_h+'px'},600,function(){//ͨ��ȡ��marginֵ,���ص�һ�� 
_field.css('marginTop',0).appendTo(_wrap);//���غ�,�����е�marginֵ����,�����뵽���,ʵ���޷���� 
}) 
},_interval)//�������ʱ��ȡ����_interval 
}).trigger('mouseleave');//��������ʱ,ģ��ִ��mouseleave,���Զ����� 
}); 
lj_jq(function(){ 
//����Ӧ��@Mr.Think 
var _wrap=lj_jq('#s3');//����������� 
var _interval=2000;//���������϶ʱ�� 
var _moving;//��Ҫ����Ķ��� 
_wrap.hover(function(){ 
clearInterval(_moving);//������ڹ���������ʱ,ֹͣ���� 
},function(){ 
_moving=setInterval(function(){ 
var _field=_wrap.find('li:first');//�˱������ɷ����ں�����ʼ��,li:firstȡֵ�Ǳ仯�� 
var _h=_field.height();//ȡ��ÿ�ι����߶� 
_field.animate({marginTop:-_h+'px'},600,function(){//ͨ��ȡ��marginֵ,���ص�һ�� 
_field.css('marginTop',0).appendTo(_wrap);//���غ�,�����е�marginֵ����,�����뵽���,ʵ���޷���� 
}) 
},_interval)//�������ʱ��ȡ����_interval 
}).trigger('mouseleave');//��������ʱ,ģ��ִ��mouseleave,���Զ����� 
}); 
</script>
    <style>
    #s2{ height:125px;overflow:hidden;display:block;}
    #s3{ height:125px;overflow:hidden;display:block;}
    </style>
    <!--��������-->
    <div class="layout c1">
        <div class="<?php if($config['ispd']) { ?>column_lj<?php } else { ?>pd<?php } ?>">
<style type="text/css">
.column-news{*height:158px;}
</style>
<?php if($config['isnews'] && $config['ispd']) { ?>
            <div class="column-news c1" >

                <dl style="width:49.5%">
                    <dt><span aria-hidden="true" class="icon-note" style="color:#000;padding-right:5px;"></span>最新活动</dt>
                    <div style="height:122px;overflow:hidden;display:block;">
                    
<ul id="s2">
                   <?php if(is_array($notice)) foreach($notice as $n) { ?>                        <li><span aria-hidden="true" class="icon-info" style="color:#000;padding-right:2px;"></span>
<a title="<?php echo $n['subject'];?>" href="<?php if($config['isrewrite']) { ?>brand_notice_<?php echo $n['bid'];?>_<?php echo $n['id'];?>.html<?php } else { ?>plugin.php?id=aljbd&act=noticeview&bid=<?php echo $n['bid'];?>&nid=<?php echo $n['id'];?><?php } ?>"><?php echo $n['subject'];?></a>
    </li>
                        <?php } ?>                             
                     </ul>
                   
                    </div>
                </dl>

                <dl>
                    <dt><span aria-hidden="true" class="icon-note" style="color:#000;padding-right:5px;"></span>推荐活动</dt>
                    <div style="height:122px;overflow:hidden;display:block;">
                    
<ul id="s3"><?php if(is_array($recommendlist_notice_index)) foreach($recommendlist_notice_index as $n) { ?>                        <li>
<span aria-hidden="true" class="icon-info" style="color:#000;padding-right:2px;"></span>
<a title="<?php echo $n['subject'];?>" href="<?php if($config['isrewrite']) { ?>brand_notice_<?php echo $n['bid'];?>_<?php echo $n['id'];?>.html<?php } else { ?>plugin.php?id=aljbd&act=noticeview&bid=<?php echo $n['bid'];?>&nid=<?php echo $n['id'];?><?php } ?>"><?php echo $n['subject'];?></a>
    </li>
                        <?php } ?>                
                         </ul>
                    
                    </div>
                </dl>
                <div class="clear">
                </div>
            </div>
<?php } ?>
            <?php if(!$config['is_res_brand']) { ?>
            <!--�Ƽ�����-->
            <div class="shop c1" <?php if($config['ispd']) { ?>style="width:<?php if($settings['templatepx']['value']) { ?>955px<?php } else { ?>715px<?php } ?>;"<?php } ?>>
                <div class="shop-top">
                    <h1>推荐商家</h1>
                    <dl class="right">
                    <dd>
                        <a href="plugin.php?id=aljbd&amp;act=dianpu&amp;order=dateline">更多&#187;</a></dd></dl>
                </div>
                <div class="shop-main c1">
                    <ul><?php if(is_array($recommendlist_1)) foreach($recommendlist_1 as $recommend) { $avg=C::t('#aljbd#aljbd_comment')->count_avg_by_bid($recommend['id']);$avg=intval($avg);?>                        <li title="<?php echo $recommend['name'];?>" <?php if($config['ispd'] && $settings['templatepx']['value']) { ?>style="width:237px"<?php } ?>>
                            <div class="shop-img u-img2">
                                <a href="<?php if($config['isrewrite']) { ?>brand_shop_<?php echo $recommend['id'];?>.html<?php } else { ?>plugin.php?id=aljbd&act=view&bid=<?php echo $recommend['id'];?><?php } ?>">
                                    <img class="img_8s" src="<?php if($recommend['logo']) { ?><?php echo $recommend['logo'];?><?php } else { ?><?php echo $noimg;?><?php } ?>"  alt="<?php echo $recommend['name'];?>"></a></div>
                            <div class="shop-title">
                                <a href="<?php if($config['isrewrite']) { ?>brand_shop_<?php echo $recommend['id'];?>.html<?php } else { ?>plugin.php?id=aljbd&act=view&bid=<?php echo $recommend['id'];?><?php } ?>">
                                    <?php echo $recommend['name'];?></a></div>
                            <div class="shop-ping pingl FC2 SiteNone" userid="128464">
                            <p class="zhibiao1">
    总评：<span class="xing xx0<?php echo $avg;?>"><b></b></span></p>
    </div>
                        </li>
                         <?php } ?>                    
                        
                    </ul>
                </div>
            </div>
        </div>
        <?php } if($config['ispd']) { ?>
        <!--�Ҳ���Ŀ-->
        <div class="sidebar_lj">
<?php if(!$config['is_daohang']&&$yd_types) { ?>
 <div class="daren_lj bor " style="width:230px;margin-top: 10px;">
               <style type="text/css">
.daren_lj ul li {
  display: inline;
  float: left;
  height: 74px;
  margin: 5px;
  width: 64px;
  text-align: center;
}

               </style>
                <ul><?php if(is_array($yd_types)) foreach($yd_types as $yd) { ?>                    <li><a href="<?php echo $yd['1'];?>"><img src="<?php echo $yd['2'];?>" width="54" height="54" alt=""><?php echo $yd['0'];?>
                    </a>
                    </li>
<?php } ?>

               </ul>
                <div class="clear">
                </div>
            </div>
<?php } ?>
            <!--Ʒ�ƴ���-->
            <div class="daren bor " style="width:230px;margin-top: 10px;">
                <h1 class="column-top"><span aria-hidden="true" class="icon-users" style="padding-right:5px;"></span>品牌达人</h1>
                <ul><?php if(is_array($dianpinguser)) foreach($dianpinguser as $u) { ?>                    <li><a href="home.php?mod=space&amp;uid=<?php echo $u['uid'];?>"><img class="img_8s" src="<?php echo avatar($u['uid'],'middle',true);?>" alt=""  width="54px" height="54px">
                    </a>
                    </li>
                    <?php } ?> 

               </ul>
                <div class="clear">
                </div>
            </div>
            <!--���Ҵ��� end-->
             <script type="text/javascript">
         	lj_jq(function(){ 
        		//����Ӧ��@Mr.Think 
        		var _wrap=lj_jq('#s4');//����������� 
        		var _interval=2500;//���������϶ʱ�� 
        		var _moving;//��Ҫ����Ķ��� 
        		_wrap.hover(function(){ 
        		clearInterval(_moving);//������ڹ���������ʱ,ֹͣ���� 
        		},function(){ 
        		_moving=setInterval(function(){ 
        		var _field=_wrap.find('li:first');//�˱������ɷ����ں�����ʼ��,li:firstȡֵ�Ǳ仯�� 
        		var _h=_field.height();//ȡ��ÿ�ι����߶� 
        		_field.animate({marginTop:-_h+'px'},600,function(){//ͨ��ȡ��marginֵ,���ص�һ�� 
        		_field.css('marginTop',0).appendTo(_wrap);//���غ�,�����е�marginֵ����,�����뵽���,ʵ���޷���� 
        		}) 
        		},_interval)//�������ʱ��ȡ����_interval 
        		}).trigger('mouseleave');//��������ʱ,ģ��ִ��mouseleave,���Զ����� 
        		}); 
</script>
 <style>
    #s4{ height:<?php if(!$config['is_daohang']) { ?>310px<?php } else { ?>510px<?php } ?>;overflow:hidden;display:block;}
.bbs ul li a {
  background: url("") no-repeat scroll left center rgba(0, 0, 0, 0);
  color: #666;
  font-weight: normal;
  padding-left: 0px;
}
    </style>
            <!--�û����µ���-->
            <div class="bbs bor mr10" style="margin:10px 0px 10px 0px;">
                <h1 class="column-top">
                    <span aria-hidden="true" class="icon-bubble2" style="padding-right:5px;"></span>用户最新点评</h1>
                <div  style="overflow:hidden;height:<?php if(!$config['is_daohang']) { ?>310px<?php } else { ?>510px<?php } ?>">
                <ul id="s4"><?php if(is_array($dianping)) foreach($dianping as $d) { $aljbd_index_1 = C::t('#aljbd#aljbd')->fetch($d['bid']);?>                    <li>
                        <span><span aria-hidden="true" class="icon-info" style="color:#000;padding-right:2px;"></span>点评[<a href="<?php if($config['isrewrite']) { ?>brand_shop_<?php echo $d['bid'];?>.html<?php } else { ?>plugin.php?id=aljbd&act=view&bid=<?php echo $d['bid'];?><?php } ?>"><?php echo dhtmlspecialchars($aljbd_index_1[name])?></a>]&nbsp;:&nbsp;<?php echo cutstr($d['content'],'50')?></span>
                    </li>
                    <?php } ?>                
                                    
                </ul>
                </div>
            </div>
            <!--�û����µ��� end-->
<?php } ?>
        </div>
    </div>
        <div class="clear">
    </div>
    <?php if($config['isyouh'] && !$settings['close_consume']['value']) { ?>
    <div class="layout">
        <!--�̼��Ż�ȯ-->
        <div class="youh c1">
            <div class="shop-top">
                <h1>商家优惠券</h1>
                <dl class="right">
                    <dd>
                        <a href="plugin.php?id=aljbd&amp;act=clist">更多&#187;</a></dd></dl>
            </div>
            <div class="youhui c1">
                <ul>
<style type="text/css">
.pic span {
  background: url("source/plugin/aljbd/images/ineffect_consumer.gif") no-repeat scroll 0 0 rgba(0, 0, 0, 0);
  display: block;
  height: 51px;
  left: -1px;
  overflow: hidden;
  position: absolute;
  text-indent: -105px;
  top: 1px;
  width: 51px;
}
.pic .expire {
  background: url("source/plugin/aljbd/images/expire_consumer.gif") no-repeat scroll 0 0 rgba(0, 0, 0, 0);
}
</style><?php if(is_array($recommendlist_consume_index)) foreach($recommendlist_consume_index as $c) { ?>                    <li title="<?php echo $c['subject'];?>">
                        <div class="pic">
                            <a target="_blank" href="<?php if($config['isrewrite']) { ?>brand_consume_<?php echo $c['bid'];?>_<?php echo $c['id'];?>.html<?php } else { ?>plugin.php?id=aljbd&act=consumeview&bid=<?php echo $c['bid'];?>&cid=<?php echo $c['id'];?><?php } ?>">
                                <img class="img_8s" src="<?php echo $c['pic'];?>" ></a>

                                <?php if(TIMESTAMP< $c['end']||!$c['end']) { ?><span class="ineffect">有效</span><?php } else { ?><span class="expire">无效</span><?php } ?></div>
                        <div class="title">
                            <a target="_blank"  href="<?php if($config['isrewrite']) { ?>brand_consume_<?php echo $c['bid'];?>_<?php echo $c['id'];?>.html<?php } else { ?>plugin.php?id=aljbd&act=consumeview&bid=<?php echo $c['bid'];?>&cid=<?php echo $c['id'];?><?php } ?>">
                                <?php echo $c['subject'];?></a></div>
                        <div class="time">
                          	<?php if($c['end']) { echo date('Y-m-d',$c['start']);?>&nbsp;至&nbsp;<?php echo date('Y-m-d',$c['end']);?><?php } else { ?>有效期：&nbsp;&nbsp;不限制<?php } ?></div>
                    </li>
                    <?php } ?>                  
                                        
                </ul>
            </div>
        </div>
        <!--�̼��Ż��� end-->
    </div>
<?php } ?>
    <div class="clear">
    </div>
    <div class="layout banner-three">
        <?php echo $config['cad'];?>
<!--[diy=aljbd_001]--><div id="aljbd_001" class="area"></div><!--[/diy]-->
    </div>
    <?php if(!$config['is_new_brand']) { ?>
    <div class="layout mr10">
        <!--�����̼�-->
        <div class="youz">
            <div class="shop-top">
                <h1>最新加盟商家</h1>
                <dl class="right">
                    <dd>
                        <a href="plugin.php?id=aljbd&amp;act=dianpu">更多&#187;</a></dd></dl>
            </div>
            <div class="clear">
            </div>
            <div class="shop-main meng-main c1">
                <ul><?php if(is_array($timelist_index)) foreach($timelist_index as $recommend) { $avg=C::t('#aljbd#aljbd_comment')->count_avg_by_bid($recommend['id']);$avg=intval($avg);?>                      <li title="<?php echo $recommend['name'];?>">
                            <div class="shop-img u-img2">
                                <a href="<?php if($config['isrewrite']) { ?>brand_shop_<?php echo $recommend['id'];?>.html<?php } else { ?>plugin.php?id=aljbd&act=view&bid=<?php echo $recommend['id'];?><?php } ?>"><img class="img_8s" src="<?php if($recommend['logo']) { ?><?php echo $recommend['logo'];?><?php } else { ?><?php echo $noimg;?><?php } ?>">
                                    </a></div>
                            <div class="shop-title">
                                <a href="<?php if($config['isrewrite']) { ?>brand_shop_<?php echo $recommend['id'];?>.html<?php } else { ?>plugin.php?id=aljbd&act=view&bid=<?php echo $recommend['id'];?><?php } ?>">
                                    <?php echo $recommend['name'];?></a></div>
                            <div class="shop-ping pingl FC2 SiteNone" userid="128464">
                          
<p class="zhibiao1">
    总评：<span class="xing xx0<?php echo $avg;?>"><b></b></span></p>
    </div>
                        </li>
                    <?php } ?>                        
                    
                   
                    
                </ul>
            </div>
            <div class="clear">
            </div>
        </div>
        <!--�����̼� end-->
    </div>
    

    
    <div class="clear">
    </div>
<div class="layout banner-three">
        <?php echo $config['bad'];?>
<!--[diy=aljbd_002]--><div id="aljbd_002" class="area"></div><!--[/diy]-->
    </div>
<?php } ?>
 <div class="clear">
    </div>
<?php if(!$settings['close_goods']['value']) { ?>
    <div class="layout c1">
       <!--�Ƽ���Ʒ-->
        <div class="tun">
            <div class="shop-top c1">
                <h1>推荐商品</h1>
                <dl class="right">
                    <dd>
                        <a href="plugin.php?id=aljbd&amp;act=goods">更多&#187;</a></dd></dl>
            </div>
            <div class="tungou c1">
                <ul>
                    <?php if(is_array($recommendlist_goods_index)) foreach($recommendlist_goods_index as $recommend) { ?><li title="<?php echo $recommend['name'];?>">
                        <div class="pic">
                            <a target='_blank' href="<?php if($config['isrewrite']) { ?>brand_good_<?php echo $recommend['bid'];?>_<?php echo $recommend['id'];?>.html<?php } else { ?>plugin.php?id=aljbd&act=goodview&bid=<?php echo $recommend['bid'];?>&gid=<?php echo $recommend['id'];?><?php } ?>">
                                <img class="img_8s" src="<?php if($recommend['pic1']) { ?><?php echo $recommend['pic1'];?><?php } else { ?><?php echo $noimg;?><?php } ?>" ></a><i class="icon-j"></i></div>
                        <div class="title">
                            <a  target='_blank' href="<?php if($config['isrewrite']) { ?>brand_good_<?php echo $recommend['bid'];?>_<?php echo $recommend['id'];?>.html<?php } else { ?>plugin.php?id=aljbd&act=goodview&bid=<?php echo $recommend['bid'];?>&gid=<?php echo $recommend['id'];?><?php } ?>" >
                                	<?php echo $recommend['name'];?></a></div>
                        <?php if($recommend['price1']) { ?>
                        <div class="indexprice" >
                            <span class="f14">价格：</span>
                            <span class="f14 fbold rcolor">
                                <?php if($_G['cache']['plugin']['aljgwc'][$pluginid]) { ?>
                                    <?php echo $price_unit;?><?php echo number_format($recommend['price1'],2);?>                                <?php } else { ?>
                                    <?php if($config['isextcredit'] && $config['extcredit']) { ?>
                                        <?php echo $recommend['price1'];?><?php echo $_G['setting']['extcredits'][$config['extcredit']]['title'];?>
                                    <?php } else { ?>
                                        <?php echo $price_unit;?><?php echo number_format($recommend['price1'],2);?>                                    <?php } ?>
                                <?php } ?>
                            </span>
                        </div>
                        <?php } else { ?><div class="indexprice"> <span class="f14">价格：</span> <span class="f14 fbold rcolor">面议</span></div><?php } ?>
                    </li>
                    <?php } ?>                
                    
                    
                </ul>
            </div>
        </div>
        <!--�Ƽ���Ʒ end-->
    </div>
<style type="text/css">
.title{padding:0 5px;}
.indexprice{padding:0 5px;}
</style>
 <div class="clear">
    
    </div>
<div class="layout banner-three">
        <?php echo $config['gad'];?>
<!--[diy=aljbd_003]--><div id="aljbd_003" class="area"></div><!--[/diy]-->
    </div>
    <?php if(!$settings['is_new_goods']['value']) { ?>
    <div class="layout c1">
       <!--������Ʒ-->
        <div class="tun">
            <div class="shop-top c1">
                <h1>
                    最新商品</h1>
                <dl class="right">
                    <dd>
                        <a href="plugin.php?id=aljbd&amp;act=goods">更多&#187;</a></dd></dl>
            </div>
            <div class="tungou c1">
                <ul>
                    <?php if(is_array($glist)) foreach($glist as $recommend) { ?><li title="<?php echo $recommend['name'];?>">
                        <div class="pic">
                            <a target='_blank' href="<?php if($config['isrewrite']) { ?>brand_good_<?php echo $recommend['bid'];?>_<?php echo $recommend['id'];?>.html<?php } else { ?>plugin.php?id=aljbd&act=goodview&bid=<?php echo $recommend['bid'];?>&gid=<?php echo $recommend['id'];?><?php } ?>">
                                <img class="img_8s" src="<?php if($recommend['pic1']) { ?><?php echo $recommend['pic1'];?><?php } else { ?><?php echo $noimg;?><?php } ?>" ></a><i class="icon-j"></i></div>
                        <div class="title" >
                            <a  target='_blank' href="<?php if($config['isrewrite']) { ?>brand_good_<?php echo $recommend['bid'];?>_<?php echo $recommend['id'];?>.html<?php } else { ?>plugin.php?id=aljbd&act=goodview&bid=<?php echo $recommend['bid'];?>&gid=<?php echo $recommend['id'];?><?php } ?>" >
                                	<?php echo $recommend['name'];?></a></div>
                        <?php if($recommend['price1']) { ?>
                        <div class="indexprice" >
                            <span class="f14">价格：</span>
                            <span class="f14 fbold rcolor">
                                <?php if($_G['cache']['plugin']['aljgwc'][$pluginid]) { ?>
                                    <?php echo $price_unit;?><?php echo number_format($recommend['price1'],2);?>                                <?php } else { ?>
                                    <?php if($config['isextcredit'] && $config['extcredit']) { ?>
                                    <?php echo $recommend['price1'];?><?php echo $_G['setting']['extcredits'][$config['extcredit']]['title'];?>
                                    <?php } else { ?>
                                    <?php echo $price_unit;?><?php echo number_format($recommend['price1'],2);?>                                    <?php } ?>
                                <?php } ?>
                            </span>
                        </div>
                        <?php } else { ?><div class="indexprice"> <span class="f14">价格：</span> <span class="f14 fbold rcolor">面议</span></div><?php } ?>
                    </li>
                    <?php } ?>                
                    
                    
                </ul>
            </div>
        </div>
        <!--������Ʒ end-->
    </div>
    <?php } ?>
    <?php } ?>
<!--�ײ�AD-->
<div class="clear"></div>
<div class="c1" style="<?php if($settings['templatepx']['value']) { ?>width: 1200px;<?php } else { ?>width: 960px;<?php } ?>margin: 0 auto;">
<div class="layout banner-three" style="float:left;">
<?php echo $config['fad'];?>
<!--[diy=aljbd_004]--><div id="aljbd_004" class="area"></div><!--[/diy]-->
</div>
<div class="clear" style="float:left;"></div>
</div>
<!--�ײ�AD end-->
 </div>
<style type="text/css">
.quick-menu .user-center .menu-bd {right: 0;width: 80px;}
</style>
<?php if($settings['templatepx']['value']) { include template('aljbd:footercss'); } } include template('aljbd:common/footer'); ?>