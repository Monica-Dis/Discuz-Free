<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($_G['cache']['plugin']['aljol']['is_header']) { ?>
    <?php $index_url = ($_G['cache']['plugin']['aljol']['footer_type'] == 1 && $_G['cache']['plugin']['aljbd']) ? 'plugin.php?id=aljbd' : 'plugin.php?id=aljol'?>    <?php if($_GET['act'] == 'talk') { ?>
        <header class="topBar2 top1" style="position: fixed;z-index: 1000;width:100%;">
            <a href="javascript:;" class="toback" onclick="R.toback();"><i class="iconfont icon-fanhui"></i></a>
            <?php if($bd) { ?>
                <span><?php echo $bd['name'];?></span>
                <a href="plugin.php?id=aljbd&amp;act=view&amp;bid=<?php echo $bd['id'];?>" style="font-size: 16px;" class="no_set_url">进店</a>
            <?php } elseif($off_uid && $off_name &&  $off_uid== $friendid) { ?>
                <style>
                    .top1>a {
                        flex: 2;
                    }
                    .toback{
                        text-align: left;
                    }
                    .toback i{
                        padding-left: 10px;
                    }
                </style>
                <span><?php echo $off_name;?></span>
                <?php if($_G['cache']['plugin']['aljhelp']) { ?>
                <a href="plugin.php?id=aljhelp&amp;c=help&amp;a=help" class="no_set_url" style="font-size: 14px;">帮助中心</a>
                <?php } else { ?>
                <a href="<?php echo $index_url;?>" class="no_set_url"><i class="iconfont icon-shouye"></i></a>
                <?php } ?>
            <?php } else { ?>
                <span><?php if(!$friendid) { ?><?php echo $_G['cache']['plugin']['aljol']['q_name'];?><?php } else { ?><?php echo $firendname['username'];?><?php } ?></span>
                <a href="<?php echo $index_url;?>" class="no_set_url"><i class="iconfont icon-shouye"></i></a>
            <?php } ?>
        </header>
        <style>
            .nottopBar1{height:46px;}
        </style>
        <div class="nottopBar1"></div>
    <?php } elseif($_GET['act'] == 'newstype') { ?>
        <header class="topBar2 top1">
            <a href="javascript:;" onclick="R.toback();"><i class="iconfont icon-fanhui"></i></a>
            <span><?php echo $navtitle;?></span>
            <a href="<?php echo $index_url;?>"><i class="iconfont icon-shouye"></i></a>
        </header>
    <?php } else { ?>
        <header class="topBar2 top1">
            <a href="javascript:;" onclick="closesearch()"><i class="iconfont icon-fanhui"></i></a>
            <span>添加好友</span>
            <a href="<?php echo $index_url;?>"><i class="iconfont icon-shouye"></i></a>
        </header>
    <?php } } ?>