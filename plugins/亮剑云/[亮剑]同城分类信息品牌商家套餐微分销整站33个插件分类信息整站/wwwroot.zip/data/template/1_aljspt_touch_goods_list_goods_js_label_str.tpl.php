<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
if(val.commodity_type == 2){
str += '<span class="xf_laber">拼团</span>';
}