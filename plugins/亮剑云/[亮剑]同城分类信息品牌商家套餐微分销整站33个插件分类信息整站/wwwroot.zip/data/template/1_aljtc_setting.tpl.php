<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template('aljtc:setting_tips'); ?><div class="floattop" style="top:40px;">
<div class="itemtitle">
<ul class="tab1">
<li>
<a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=<?php echo $pluginid;?>&pmod=setting#jump1"><span>&#39318;&#39029;&#35774;&#32622;&#39033;</span></a>
</li>
<li >
<a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=<?php echo $pluginid;?>&pmod=setting#jump2"><span>&#20840;&#23616;&#35774;&#32622;&#39033;</span></a>
</li>
<li>
<a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=<?php echo $pluginid;?>&pmod=setting#jump3">
<span>&#21457;&#24067;&#39029;&#38754;&#35774;&#32622;</span>
</a>
</li>
<li>
<a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=<?php echo $pluginid;?>&pmod=setting#jump4"><span>&#35748;&#35777;&#39029;&#38754;&#35774;&#32622;</span></a>
</li>
<li><a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=<?php echo $pluginid;?>&pmod=setting#jump5"><span>&#35814;&#24773;&#39029;&#38754;&#35774;&#32622;</span></a></li>
<li><a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=<?php echo $pluginid;?>&pmod=setting#jump6"><span>&#21457;&#24067;&#31649;&#29702;&#39029;&#38754;&#35774;&#32622;</span></a></li>
<li><a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=<?php echo $pluginid;?>&pmod=setting#jump7"><span>&#33258;&#21161;&#24191;&#21578;&#35774;&#32622;</span></a></li>
<li><a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=<?php echo $pluginid;?>&pmod=setting#jump9"><span>&#25105;&#30340;&#39029;&#38754;</span></a></li>
<li><a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=<?php echo $pluginid;?>&pmod=setting#jump8"><span>&#21518;&#21488;&#35774;&#32622;</span></a></li>
<li><a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=<?php echo $pluginid;?>&pmod=setting#jump10"><span>&#24494;&#20449;&#23567;&#31243;&#24207;</span></a></li>
<li><a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=<?php echo $pluginid;?>&pmod=setting#jump11"><span>APP</span></a></li>
<li><a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=<?php echo $pluginid;?>&pmod=setting&act=upgrade"><span style="color:red;">&#20462;&#22797;&#25554;&#20214;</span></a></li>
</ul>
</div>
</div>

<form id="cpform" action="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=<?php echo $pluginid;?>&pmod=setting" enctype="multipart/form-data" autocomplete="off" method="post" name="cpform">
<input type="hidden" name="formhash" value="<?php echo FORMHASH;?>">
<table class="tb tb2 nobdb">
<tbody>
<!--�°���ҳ s-->
<tr style="height:40px;" id="jump1"></tr><?php include template('aljtc:setting/index'); ?><!--�°���ҳ e-->
<!--ȫ�������� s-->
<tr style="height:40px;" id="jump2"></tr><?php include template('aljtc:setting/common'); ?><!--����ҳ������ s-->
<tr style="height:40px;" id="jump3"></tr><?php include template('aljtc:setting/post'); ?><!--��֤ҳ��Ȩ������ s-->
<tr style="height:40px;" id="jump4"></tr><?php include template('aljtc:setting/attes'); ?><!--����ҳ��Ȩ������ s-->
<tr style="height:40px;" id="jump5"></tr><?php include template('aljtc:setting/view'); ?><!--��������ҳ��Ȩ������ s-->
<tr style="height:40px;" id="jump6"></tr><?php include template('aljtc:setting/user'); ?><!--����������� e-->
<tr style="height:40px;" id="jump7"></tr><?php include template('aljtc:setting/ad'); ?><!--�ҵ�ҳ�� e-->
<tr style="height:40px;" id="jump9"></tr><?php include template('aljtc:setting/myuser'); ?><tr style="height:40px;" id="jump8"></tr><?php include template('aljtc:setting/admin'); ?><tr style="height:40px;" id="jump10"></tr><?php include template('aljtc:setting/mini'); ?><tr style="height:40px;" id="jump11"></tr><?php include template('aljtc:setting/app'); ?><!--appbyme-->
<tr><td colspan="15"><div class="fixsel"><input type="submit" value="&#25552;&#20132;" name="alipaysubmit" id="submit_alipaysubmit" class="btn"></div></td></tr>
</tbody></table>
</form>
