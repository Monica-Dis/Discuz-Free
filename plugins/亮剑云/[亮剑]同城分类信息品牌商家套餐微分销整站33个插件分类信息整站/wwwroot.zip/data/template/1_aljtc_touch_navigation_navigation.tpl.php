<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<link rel="stylesheet" media="screen,projection,tv" href="source/plugin/<?php echo $pluginid;?>/template/touch/navigation/navigation.css?<?php echo VERHASH;?>" /></link>
<div class="s_index_icon  swiper-container-horizontal" id="navigation">
    <div class="swiper-wrapper" id="c_main_Prefecture">
        <!-- ͼƬ���� -->
        <ul class="s_index_ul swiper-slide " style="display:block;">
        <?php if(is_array($mobile_index_new_dh_types)) foreach($mobile_index_new_dh_types as $k => $v) { ?>            <?php if($k && $k%10==0) { ?>
                </ul>
                <ul class="s_index_ul swiper-slide" >
            <?php } ?>
            <li >
                <a href="<?php echo $v['0'];?>" class="navigateTo">
                    <img src="<?php if($v['1']) { ?><?php echo $v['1'];?><?php } else { ?>source/plugin/aljtc/static/img/moren.png<?php } ?>">
                    <em style="font-style: normal;"><?php echo $v['2'];?></em>
                </a>
            </li>
        <?php } ?>
        </ul>
    </div>
    <div class=" swiper-pagination swiper-pagination-clickable " id="navigation_page"></div>
</div>
<script>
new Swiper("#navigation",{pagination:"#navigation_page",paginationClickable:!0,spaceBetween:30,loop:!1})
</script>
