<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<script>
var isshow=true;
function clickarea(obj) {
if(isshow) {
$('.cmNavBar').addClass('color-header').removeClass('global-header');
$('#allregion').show();
$('#mask_l').show();
}else {
$('.cmNavBar').removeClass('color-header').addClass('global-header');
$('#allregion').hide();
$('#mask_l').hide();
}
isshow=!isshow;
}
function showtop() {
$('.cmNavBar').removeClass('color-header').addClass('global-header');
$('#allregion').hide();
    $('#mask_l').hide();
    isshow=true;
}
function region_1(rid){
$.post('plugin.php?id=aljtc&act=mobile_list_region&getjson=yes',{"rid":rid},function(data){
        $("#subregion").html('');
$.each(data, function(k,d) {
var str = "'"+d.subject+"'";
var dataDom = '<li><a onclick="postarea('+d.id+','+str+');" href="javascript:;">'+d.subject+'</a></li>';
$("#subregion").append(dataDom);
});
},'json');
}
function postarea(id,name) {
var url = 'plugin.php?id=aljtc&act=saveregion';
var data = {'rid':id,'rname':name};
$.ajaxSetup ({ cache: false });
$.post(url,data,function(res) {
if(res == 1) {
$('.cmNavBar').removeClass('color-header').addClass('global-header');
$('#allregion').hide();
$('#mask_l').hide();
$('.w-headMenu').html(name);
location.href = 'plugin.php?id=aljtc&'+Math.random();
}
});
}
function alldata(){
var url = 'plugin.php?id=aljtc&act=saveregion&cancel=yes';
$.post(url,function(res) {
if(res == 1) {
$('.cmNavBar').removeClass('color-header').addClass('global-header');
$('#allregion').hide();
$('#mask_l').hide();
$('.w-headMenu').html(name);
location.href = 'plugin.php?id=aljtc';
}
});
}
</script>
<?php if(!$_G['cache']['plugin']['aljtfz']['site_show']) { ?>
    <?php if($_G['cache']['plugin']['aljtsq']) { ?>
        <script>
        <?php if(!$_COOKIE['changecitystate'] && $settings['is_more_city']['value']) { ?>
            if(window.sessionStorage.getItem("aljtc_city") == null) {
                function showPositionTc(latitude,longitude){
                    var data ={'latitude':latitude,'longitude':longitude};
                    var url = 'plugin.php?id=aljtc&act=getaddress&'+Math.random();
                    $.post(url,data,function(res) {
                        if(!res.code) {
                            layer.open({
                                content: res.message
                                ,btn: ['&#30830;&#23450;', '&#21462;&#28040;']
                                ,yes: function(index){
                                    postarea(res.cityid,res.city);
                                    layer.close(index);
                                }
                            });

                        }else{
                            layer.open({
                                content: res.message
                                ,btn: ['&#30830;&#23450;']
                                ,yes: function(index){
                                    window.sessionStorage.setItem("aljtc_city", 1);
                                    layer.close(index);
                                }
                            });
                        }
                    },'json')
                }
            }
        <?php } ?>
        </script>
    <?php } else { ?>
        <?php $Browser_Tencent_map_key = $_G['cache']['plugin']['aljhtx']['Browser_Tencent_map_key'] ? $_G['cache']['plugin']['aljhtx']['Browser_Tencent_map_key'] : 'SA5BZ-HX46G-3CFQP-IY4TP-KKMU7-MLBGO';?>        <?php if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) { ?>
        <script src="//apis.map.qq.com/tools/geolocation/min?key=<?php echo $Browser_Tencent_map_key;?>&referer=myapp" type="text/javascript"></script>
        <script>
            function getLocationTc(){
                l_tips = layer.open({type: 2, content: '\u5b9a\u4f4d\u4e2d'});
                var options = {timeout: 9000, failTipFlag:true};
                var geolocation = new qq.maps.Geolocation();
                var positionNum = 0;
                geolocation.getLocation(sucCallbackTc, errCallbackTc, options);

            }
        </script>
        <?php } else { ?>
        <script src="source/plugin/aljtc/static/js/geolocation.min.js?<?php echo VERHASH;?>" type="text/javascript"></script>
        <script>
            function getLocationTc(){
                l_tips = layer.open({type: 2,content: '\u5b9a\u4f4d\u4e2d'});
                var geolocation = new qq.maps.Geolocation("<?php echo $Browser_Tencent_map_key;?>", "myapp");
                var options = {timeout: 9000, failTipFlag:true};
                geolocation.getLocation(sucCallbackTc, errCallbackTc,options);
            }
        </script>
        <?php } ?>
        <script>

            function errCallbackTc(error){
                layer.close(l_tips);
                
                getLocationTc();
            }
            function sucCallbackTc(position) {
                layer.close(l_tips);
                showPositionTc(position.lat, position.lng);
            }
            <?php if(!$_COOKIE['changecitystate'] && $settings['is_more_city']['value']) { ?>
                if(window.sessionStorage.getItem("aljtc_city") == null) {
                    function showPositionTc(latitude,longitude){
                        var data ={'latitude':latitude,'longitude':longitude};
                        var url = 'plugin.php?id=aljtc&act=getaddress&'+Math.random();
                        $.post(url,data,function(res) {
                            if(!res.code) {
                                layer.open({
                                    content: res.message
                                    ,btn: ['&#30830;&#23450;', '&#21462;&#28040;']
                                    ,yes: function(index){
                                        postarea(res.cityid,res.city);
                                        layer.close(index);
                                    }
                                });

                            }else{
                                layer.open({
                                    content: res.message
                                    ,btn: ['&#30830;&#23450;']
                                    ,yes: function(index){
                                        window.sessionStorage.setItem("aljtc_city", 1);
                                        layer.close(index);
                                    }
                                });
                            }
                        },'json')
                    }
                
                    setTimeout(function () {
                        $(function () {
                            getLocationTc();
                        });
                    }, 300);
                }
                
        
        <?php } ?>
        </script>
    <?php } } elseif(((!$_G['cache']['plugin']['aljtsq'] && $_G['cache']['plugin']['aljtfz']['is_lbs'] && !getcookie('aljtfz_lbs')) || $_GET['lbs']=='yes') && $_GET['mobilediy'] != 'yes' && $_GET['id'] != 'aljwm') { $Browser_Tencent_map_key = $_G['cache']['plugin']['aljhtx']['Browser_Tencent_map_key'] ? $_G['cache']['plugin']['aljhtx']['Browser_Tencent_map_key'] : 'SA5BZ-HX46G-3CFQP-IY4TP-KKMU7-MLBGO';?><?php if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) { ?>
<script src="//apis.map.qq.com/tools/geolocation/min?key=<?php echo $Browser_Tencent_map_key;?>&referer=myapp" type="text/javascript"></script>
<script>
    function getLocationTc(){
        l_tips = layer.open({type: 2, content: '\u5b9a\u4f4d\u4e2d'});
        var options = {timeout: 9000, failTipFlag:true};
        var geolocation = new qq.maps.Geolocation();
        var positionNum = 0;
        geolocation.getLocation(sucCallbackTc, errCallbackTc, options);

    }
</script>
<?php } else { ?>
<script src="source/plugin/aljtc/static/js/geolocation.min.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<script>
    function getLocationTc(){
        l_tips = layer.open({type: 2,content: '\u5b9a\u4f4d\u4e2d'});
        var geolocation = new qq.maps.Geolocation("<?php echo $Browser_Tencent_map_key;?>", "myapp");
        var options = {timeout: 9000, failTipFlag:true};
        geolocation.getLocation(sucCallbackTc, errCallbackTc,options);
    }
</script>
<?php } ?>
<script>
    function errCallbackTc(error){
        layer.close(l_tips);
        
        getLocationTc();
    }
    function sucCallbackTc(position) {
        layer.close(l_tips);
        showPositionTc(position.lat, position.lng);
    }
        function showPositionTc(latitude,longitude){
            fz_lbs(latitude,longitude);
        }
        function fz_lbs(latitude,longitude){
            var index = layer.open({
                type: 2
                ,content: '\u5b9a\u4f4d\u4e2d'
            });
            var l_href = location.href;
            l_href = l_href.replace(/&/g,'%26');
            var data ={'latitude':latitude,'longitude':longitude,'url':l_href};
            var url = 'plugin.php?id=aljtfz&c=aljtfz&a=lbs&'+Math.random();
            $.get(url,data,function(res) {
                layer.close(index);
                if(!res.code) {
                    layer.open({
                        content: res.message
                        ,btn: ['\u91cd\u8bd5', '\u53d6\u6d88']
                        ,yes: function(index){
                            showPositionTc(latitude,longitude);
                        }
                    });
                }else{
                    location.href = res.url
                }
            },'json')
        }
        setTimeout(function () {
            $(function () {
                getLocationTc();
            });
        }, 300);
</script>
<?php } ?>