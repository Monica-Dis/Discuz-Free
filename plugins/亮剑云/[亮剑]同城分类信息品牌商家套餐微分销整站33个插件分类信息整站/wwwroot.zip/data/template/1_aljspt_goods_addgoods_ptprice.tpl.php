<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div class="form-group collage_price" style="display: none">
    <label class="col-sm-3 control-label">拼团价格</label>
    <div class="col-sm-6">
    <input class="form-control " placeholder="拼团价格" name="collage_price" value="<?php echo $goods['collage_price'];?>">
    </div>
</div>