<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template('aljht:admin/iframe_header_common'); include template('aljbd:editor'); ?><style>
.box-body{max-width:840px;margin:0 auto;}
.form-group .box-title{margin-left: 440px;color:#999;}
</style>
<div class="content-wrapper">
<?php if($_GET['ajax'] != 'yes') { ?>
    <section class="content-header">
        <h1>
            <?php echo $aljhtlang['template']['brand_1'];?>

        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo $index_url;?>"><i class="fa fa-dashboard"></i> <?php echo $aljhtlang['template']['brand_31'];?></a></li>
            <li><a href="plugin.php?id=aljht&amp;act=admin"><?php echo $aljhtlang['template']['brand_32'];?></a></li>
            <li class="active"><?php echo $aljhtlang['template']['brand_1'];?></li>
        </ol>
    </section>
<?php } ?>
    <section class="content">
        <div class="row">

            <iframe style="display:none;" name="submitiframe"></iframe>
            <form name="cpform" id="admingoodssubmit" method="post" class="form-horizontal" autocomplete="off" action="plugin.php?id=<?php echo $pluginid;?>&amp;act=admin&amp;op=<?php echo $op;?>&amp;do=<?php echo $do;?><?php echo $urlmod;?>" target="submitiframe">
                <input type="hidden" value="<?php echo FORMHASH;?>" name="formhash">
                <input type="hidden" value="<?php echo $bid;?>" name="bid">
<input type="hidden" name="compress" value="" id="compress">
<input type="hidden" name="aljbd_token" value="<?php echo create_token('aljbd_token');?>">
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php if($do == 'edit') { ?><?php echo $aljhtlang['template']['adddp_1'];?><?php } else { ?><?php echo $aljhtlang['template']['adddp_2'];?><?php } ?><?php echo $aljhtlang['template']['adddp_3'];?></h3>
                    </div>
<?php if((($_G['cache']['plugin']['aljbdx']['is_aljqb'] && $_G['cache']['plugin']['aljbdx']['adddp_price']) || ($_G['cache']['plugin']['aljbd']['money']&&$_G['cache']['plugin']['aljbd']['money_lx'])) && !$aljbd_groups) { ?>
<div class="box-header with-border">
<h3 class="box-title">
<?php if($_G['cache']['plugin']['aljbdx']['is_aljqb'] && $_G['cache']['plugin']['aljbdx']['adddp_price']) { ?>
入驻需要支付费用<?php echo $_G['cache']['plugin']['aljbdx']['adddp_price'];?>元
<?php } elseif($_G['cache']['plugin']['aljbd']['money']&&$_G['cache']['plugin']['aljbd']['money_lx']) { ?>
入驻需要支付费用<?php echo $_G['cache']['plugin']['aljbd']['money'];?><?php echo $_G['setting']['extcredits'][$_G['cache']['plugin']['aljbd']['money_lx']]['title'];?>
<?php } ?>
</h3>
</div>
<?php } ?>
                    <!-- /.box-header -->
                    <div class="box-body">
<?php if($administrators) { ?>
<div class="form-group">

<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">管理员权限</h3>

<div class="box-tools">
<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
</button>
</div>
</div>
<div class="box-body no-padding" >
<div class="form-group">
<label class="col-sm-3 control-label"><?php echo $aljhtlang['template']['adddp_4'];?></label>
<div class="col-sm-9">
<input class="form-control" placeholder="<?php echo $aljhtlang['template']['adddp_4'];?>" name="displayorder" value="<?php echo $bd['displayorder'];?>">
</div>
</div>
<?php if($do == 'adddp') { ?>
<div class="form-group">
<label class="col-sm-3 control-label">用户UID</label>
<div class="col-sm-9">
<input class="form-control" placeholder="帮助哪个用户UID发布店铺，不填写调用当前登录用户UID" name="uid" value="<?php echo $bd['uid'];?>">
</div>
</div>
<?php } if($do == 'edit') { ?>
<div class="form-group">
<label class="col-sm-3 control-label">状态</label>
<div class="col-sm-9">

<label class="control-label"><input type="radio" name="status" value="1"  <?php if($bd['status'] == 1) { ?>checked="checked"<?php } ?>>&nbsp;审核</label>
<label class="control-label"><input type="radio" name="status" value="0"  <?php if($bd['status'] == 0) { ?>checked="checked"<?php } ?>>&nbsp;未审核</label>
<label class="control-label"><input type="radio" name="status" value="2"  <?php if($bd['status'] == 2) { ?>checked="checked"<?php } ?>>&nbsp;未支付</label>
<label class="control-label"><input type="radio" name="status" value="3"  <?php if($bd['status'] == 3) { ?>checked="checked"<?php } ?>>&nbsp;不通过</label>
<label class="control-label"><input type="radio" name="status" value="4"  <?php if($bd['status'] == 4) { ?>checked="checked"<?php } ?>>&nbsp;已关闭</label>
</div>
</div>
<?php } ?>
<div class="form-group m_type">
<label class="col-sm-3 control-label">商家标签</label>
<div class="col-sm-9">
<input class="form-control" placeholder="如:自营，旗舰店、授权店、专营店、专卖店等等" name="label"  value="<?php echo $bd['label'];?>">
</div>
</div>
</div>
</div>
</div>
<?php } ?>
<div class="form-group">

<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">基本信息</h3>

<div class="box-tools">
<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
</button>
</div>
</div>
<div class="box-body no-padding" >
<div class="form-group">
<label class="col-sm-3 control-label"><?php echo $aljhtlang['template']['adddp_5'];?></label>
<div class="col-sm-9">
<input class="form-control" placeholder="<?php echo $aljhtlang['template']['adddp_5'];?>" name="name"  value="<?php echo $bd['name'];?>">
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label"><?php echo $aljhtlang['template']['adddp_6'];?></label>
<div class="col-sm-6">
<input class="form-control"  name="tel" placeholder="<?php echo $aljhtlang['template']['adddp_6'];?>" value="<?php echo $bd['tel'];?>" >
</div>
<div class="col-sm-3">
<div class="checkbox">
<label>
<input type="checkbox" name="hide_tel" value="1" <?php if($bd['hide_tel']) { ?>checked<?php } ?>>不公开
</label>
</div>
</div>
</div>
<div class="form-group m_type_1">
<label class="col-sm-3 control-label"><?php echo $aljhtlang['template']['adddp_20'];?></label>
<div class="col-sm-9">
<input class="form-control" placeholder="<?php echo $aljhtlang['template']['adddp_20'];?>" name="business_hours" value="<?php if($bd['business_hours']) { ?><?php echo $bd['business_hours'];?><?php } else { ?>8:00-21:00<?php } ?>">
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label"><?php echo $aljhtlang['template']['adddp_7'];?></label>

<div class="col-sm-9">
<div class="form-group" style="margin-left: 0px">
<div class="btn btn-default btn-file">
<i class="fa fa-file-image-o"></i><?php echo $aljhtlang['template']['adddp_7'];?>
<input type="file" name="logo" id="logo" onchange="lrz_mobile('logo',this)">
</div><font color="red"><?php echo $aljhtlang['template']['adddp_8'];?><?php echo $_G['cache']['plugin']['aljbd']['img_size'];?><?php echo $aljhtlang['template']['adddp_9'];?></font>
</div>
<p id="img_logo"><?php if($bd['logo']) { ?><img src="<?php echo $bd['logo'];?>" width="100px" height="100px"><?php } ?></p>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label"><?php echo $aljhtlang['template']['adddp_10'];?></label>
<div class="col-sm-9">
<select name="type" id="type" class="form-control" onchange="lj_type();">
<option value=""><?php echo $aljhtlang['template']['adddp_11'];?></option><?php if(is_array($typelist)) foreach($typelist as $typeid => $type) { ?><option value="<?php echo $typeid;?>" <?php if($typeid==$bd['type']) { ?>selected<?php } ?>><?php echo $type['subject'];?></option>
<?php } ?>
</select>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label"></label>
<div class="col-sm-9" id="type1">
<?php if($bd['subtype']) { ?>
<select name="subtype" id="subtype" class="form-control" onchange="lj_subtype();"><?php if(is_array(C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type')->fetch_all_by_upid($bd['type']))) foreach(C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type')->fetch_all_by_upid($bd['type']) as $typeid => $type) { ?><option value="<?php echo $typeid;?>" <?php if($typeid==$bd['subtype']) { ?>selected<?php } ?>><?php echo $type['subject'];?></option>
<?php } ?>
</select>
<?php } ?>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label"></label>
<div class="col-sm-9" id="type2">
<?php if($bd['subtype3']) { ?>
<select name="subtype3" class="form-control"><?php if(is_array(C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type')->fetch_all_by_upid($bd['subtype']))) foreach(C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type')->fetch_all_by_upid($bd['subtype']) as $typeid => $type) { ?><option value="<?php echo $typeid;?>" <?php if($typeid==$bd['subtype3']) { ?>selected<?php } ?>><?php echo $type['subject'];?></option>
<?php } ?>
</select>
<?php } ?>

</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label"><?php echo $aljhtlang['template']['adddp_12'];?></label>
<div class="col-sm-9">
<select name="region" id="region" class="form-control" onchange="lj_region();">
<option value=""><?php echo $aljhtlang['template']['adddp_11'];?></option><?php if(is_array($rlist)) foreach($rlist as $rid => $r) { ?><option value="<?php echo $rid;?>" <?php if($rid==$bd['region']) { ?>selected<?php } ?>><?php echo $r['name'];?></option>
<?php } ?>
</select>
</div>
</div>
<div name="subregion"  class="form-group">
<label class="col-sm-3 control-label"></label>
<div class="col-sm-9" id="province">
<?php if($bd['subregion']) { ?>
<select name="subregion" class="form-control" id="subregion" onchange="lj_subregion();"><?php if(is_array(C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_region')->fetch_all_by_upid('','',$bd['region']))) foreach(C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_region')->fetch_all_by_upid('','',$bd['region']) as $rid => $r) { ?><option value="<?php echo $rid;?>" <?php if($rid==$bd['subregion']) { ?>selected<?php } ?>><?php echo $r['name'];?></option>
<?php } ?>
</select>
<?php } ?>
</div>
</div>
<div  class="form-group">
<label class="col-sm-3 control-label"></label>
<div class="col-sm-9" id="getregion">
<?php if($bd['region1']) { ?>
<select name="region1" class="form-control"><?php if(is_array(C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_region')->fetch_all_by_upid('','',$bd['subregion']))) foreach(C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_region')->fetch_all_by_upid('','',$bd['subregion']) as $rid => $r) { ?><option value="<?php echo $rid;?>" <?php if($rid==$bd['region1']) { ?>selected<?php } ?>><?php echo $r['name'];?></option>
<?php } ?>
</select>
<?php } ?>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">联系地址</label>
<div class="col-sm-9">
<input class="form-control" placeholder="联系地址" name="addr" value="<?php echo $bd['addr'];?>">
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label"><?php echo $aljhtlang['template']['adddp_22'];?></label>
<div class="col-sm-9">
<input class="form-control" placeholder="<?php echo $aljhtlang['template']['adddp_22'];?>" name="xy" value="<?php if($bd['x'] && $bd['y']) { ?><?php echo $bd['x'];?>,<?php echo $bd['y'];?><?php } ?>" id="xy">
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label"></label>
<div class="col-sm-9">
<div class="has-feedback">
<input type="text" placeholder="<?php echo $aljhtlang['template']['adddp_23'];?>" class="form-control input-sm" name="ss" id="ss">
<div onclick="initialize()" style="pointer-events: visible;" class="glyphicon glyphicon-search form-control-feedback"></div>
</div>
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label"></label>
<div class="col-sm-9">
<div style="width: 100%; height: 400px;margin-left: 0px" class="form-group" id="mapObj">
</div>
</div>
</div>
</div>
</div>
</div>

<?php if($do == 'adddp' && !$administrators) { if($aljbd_groups) { ?>
<div class="form-group">
<label class="col-sm-3 control-label">付费入驻</label>
<div class="col-sm-7" style="line-height: 21px"><?php if(is_array($aljbd_groups)) foreach($aljbd_groups as $vipk => $vipv) { ?><div class="radio">
<label>
<input type="radio" class="weui-check c-price" data-price="<?php echo $vipv['price'];?>" onchange="autodiscount();" name="vipid" value="<?php echo $vipv['id'];?>" id="s<?php echo $vipv['id'];?>" <?php if($vipk == 0) { ?>checked="checked"<?php } ?>>
<?php echo $vipv['title'];?>(<?php if($vipv['day'] == 0) { ?>永久<?php } else { ?><?php echo $vipv['day'];?>天<?php } ?>/<?php echo $price_unit;?><?php echo $vipv['price'];?>)
</label>
</div>
<?php } if($_G['cache']['plugin']['aljac']['open'] && !$bd) { ?>

<div class="radio">
<label>
<input type="radio" class="weui-check c-price" name="vipid" value="jhm" id="sjhm" <?php if(!$aljbd_groups) { ?>checked="checked"<?php } ?>>
激活码入驻
</label>
</div>
<?php } ?>
</div>
<div class="col-sm-2" style="line-height: 37px;text-align: right;">
<?php if($_G['cache']['plugin']['aljbd']['difference']) { ?>
<a href="javascript:;" style="color:red;" onclick="layer.alert($('#table_difference').html(), {title: '版本区别',})">版本区别</a><?php include template('aljht:admin/viphelp'); } ?>
</div>
</div>
<?php } if($_G['cache']['plugin']['aljac']['open']) { ?>
<script>
function vipJhm(){
var rankid = $('.c-price:checked').val();
if(rankid == 'jhm'){
$('.activation_code').show();
}else{
$('.activation_code').hide();
}
}
$('.c-price').change(function() {
vipJhm();
});

</script>
<div class="activation_code" style="display: none">
<div class="form-group">
<label class="col-sm-3 control-label">激活码</label>
<div class="col-sm-9">
<input class="form-control" placeholder="请输入激活码" name="activation_code" value="<?php echo $bd['activation_code'];?>">
</div>
</div>
</div>
<?php } if($_G['cache']['plugin']['aljsyh']['is_aljsyh']) { include template('aljsyh:consume/member/member'); } } else { if($administrators) { if($aljbd_groups) { ?>
<div class="form-group">
<label class="col-sm-3 control-label">商家VIP等级</label>
<div class="col-sm-9" style="line-height: 21px">
<select name="vipid"  class="form-control" >
<option value="0" >请选择VIP商家等级</option><?php if(is_array($aljbd_groups)) foreach($aljbd_groups as $vipk => $vipv) { ?><option value="<?php echo $vipv['id'];?>" <?php if($vipv['id']==$bd['vipid']) { ?>selected<?php } ?>><?php echo $vipv['title'];?>(<?php if($vipv['day'] == 0) { ?>永久<?php } else { ?><?php echo $vipv['day'];?>天<?php } ?>/<?php echo $price_unit;?><?php echo $vipv['price'];?>)</option>
<?php } ?>
</select>
</div>
</div>
<?php } } } if($do == 'edit' || $administrators) { ?>
<div class="form-group">

                            <div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">更多信息</h3>

<div class="box-tools">
<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
</button>
</div>
</div>

<div class="box-body no-padding" >
<?php if($_G['cache']['plugin']['aljbdx']) { ?>
<div class="form-group">
<label class="col-sm-3 control-label">运费设置</label>
<div class="col-sm-9" style="line-height: 21px">
<select name="fare_type"  class="form-control b_fare_type" ><?php if(is_array($fare_type)) foreach($fare_type as $f_k => $f_v) { ?><option value="<?php echo $f_k;?>" <?php if($f_k==$bd['fare_type']) { ?>selected<?php } ?>><?php echo $f_v;?></option>
<?php } ?>
</select>
</div>
</div>
<div class="form-group postal_amount">
<label class="col-sm-3 control-label">订单满</label>
<div class="col-sm-2">
<input class="form-control" placeholder="多少" name="postal_amount" value="<?php echo $bd['postal_amount'];?>">
</div>
<div class="col-sm-6" style="padding-top: 7px;">包邮</div>
</div>
<script>
$('.b_fare_type').change(function() {
b_fare_typechange();
});
function b_fare_typechange(){
var f_t_id = $('.b_fare_type option:selected').val();
if(f_t_id == 3){
$('.postal_amount').show();
}else{
$('.postal_amount').hide();
}
}
b_fare_typechange();
</script>
<?php } if(!$_G['cache']['plugin']['aljbd']['is_post_adddp_kf']) { ?>
<div class="form-group m_type">
<label class="col-sm-3 control-label">QQ</label>
<div class="col-sm-9">
<input class="form-control" placeholder="QQ" name="qq" value="<?php echo $bd['qq'];?>">
</div>
</div>
<div class="form-group m_type">
<label class="col-sm-3 control-label"><?php echo $aljhtlang['template']['adddp_13'];?></label>
<div class="col-sm-9">
<input class="form-control"  placeholder="<?php echo $aljhtlang['template']['adddp_13'];?>" name="wangwang" value="<?php echo $bd['wangwang'];?>">
</div>
</div>
<div class="form-group m_type">
<label class="col-sm-3 control-label"><?php echo $aljhtlang['template']['adddp_14'];?></label>
<div class="col-sm-9">
<input class="form-control" placeholder="<?php echo $aljhtlang['template']['adddp_14'];?>" name="weixin_id" value="<?php echo $bd['weixin_id'];?>">
</div>
</div>
<?php } ?>
<div class="form-group m_type">
<label class="col-sm-3 control-label"><?php echo $aljhtlang['template']['adddp_19'];?></label>
<div class="col-sm-9">
<input class="form-control" placeholder="<?php echo $aljhtlang['template']['adddp_19'];?>" name="other" value="<?php echo $bd['other'];?>">
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label"><?php echo $aljhtlang['template']['adddp_15'];?> &nbsp;<span style="color:red;"><?php echo $aljhtlang['template']['adddp_16'];?></span></label>
<div class="col-sm-9">
<div class="form-group" style="margin-left: 0px"><?php if(is_array($businesstypearr)) foreach($businesstypearr as $k => $v) { ?><input type=checkbox name=businesstype[] onClick="countChoices(this)" value="<?php echo $k;?>" <?php if(in_array($k,explode(',',$bd['businesstype']))) { ?>checked<?php } ?>><?php echo $v;?>&nbsp;&nbsp;
<?php } ?>
</div>
</div>
</div>
<div class="form-group m_type_1">
<label class="col-sm-3 control-label"><?php echo $aljhtlang['template']['adddp_21'];?></label>
<div class="col-sm-9">
<input class="form-control" placeholder="<?php echo $aljhtlang['template']['adddp_21'];?>" name="bus_routes" value="<?php echo $bd['bus_routes'];?>">
</div>
</div>
<?php if(!$settings['brand_wurl']['value']) { ?>
<div class="form-group m_type">
<label class="col-sm-3 control-label"><?php echo $aljhtlang['template']['adddp_17'];?></label>
<div class="col-sm-9">
<input type="text" name="wurl" class="form-control" value="<?php echo $bd['wurl'];?>" placeholder="<?php echo $aljhtlang['template']['adddp_18'];?>">
</div>
</div>
<?php } ?>
<div class="form-group">
<label class="col-sm-3 control-label"><?php echo $aljhtlang['template']['adddp_26'];?></label>
<div class="col-sm-9">
<textarea name="gg" class="form-control"  style="height:100px;" placeholder="<?php echo $aljhtlang['template']['adddp_27'];?>"><?php echo $bd['gg'];?></textarea>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">PC转播广告图</label>
<div class="col-sm-9">
<div class="row">

<div class="col-md-4">
<p><input class="form-control" placeholder="<?php echo $aljhtlang['template']['adddp_29'];?>" name="advurl[1]" value="<?php echo $advurl['1'];?>"></p>

<div class="btn btn-default btn-file">
<i class="fa fa-file-image-o"></i> <?php echo $aljhtlang['template']['adddp_39'];?>
<input type="file" name="adv[1]" onchange="lrz_mobile('adv1',this)">
</div>

<p id="img_<?php echo adv1;?>"><?php if($adv['1']) { ?><img src="<?php echo $adv['1'];?>" width="100px" height="100px"><input type="hidden" name="adv1" value="<?php echo $adv['1'];?>">&nbsp;<input type="checkbox" onclick="delattach('adv1')"><?php echo $aljhtlang['template']['adddp_31'];?><?php } ?></p>
</div>
<div class="col-md-4">
<p><input class="form-control" placeholder="<?php echo $aljhtlang['template']['adddp_29'];?>" name="advurl[2]" value="<?php echo $advurl['2'];?>"></p>

<div class="btn btn-default btn-file">
<i class="fa fa-file-image-o"></i> <?php echo $aljhtlang['template']['adddp_40'];?>
<input type="file" name="adv[2]" onchange="lrz_mobile('adv2',this)">
</div>

<p id="img_<?php echo adv2;?>"><?php if($adv['2']) { ?><img src="<?php echo $adv['2'];?>" width="100px" height="100px"><input type="hidden" name="adv2" value="<?php echo $adv['2'];?>">&nbsp;<input type="checkbox" onclick="delattach('adv2')"><?php echo $aljhtlang['template']['adddp_31'];?><?php } ?></p>
</div>
<div class="col-md-4">
<p><input class="form-control" placeholder="<?php echo $aljhtlang['template']['adddp_29'];?>" name="advurl[3]" value="<?php echo $advurl['3'];?>"></p>

<div class="btn btn-default btn-file">
<i class="fa fa-file-image-o"></i> <?php echo $aljhtlang['template']['adddp_41'];?>
<input type="file" name="adv[3]" onchange="lrz_mobile('adv3',this)">
</div>

<p id="img_<?php echo adv3;?>"><?php if($adv['3']) { ?><img src="<?php echo $adv['3'];?>" width="100px" height="100px"><input type="hidden" name="adv3" value="<?php echo $adv['3'];?>">&nbsp;<input type="checkbox" onclick="delattach('adv3')"><?php echo $aljhtlang['template']['adddp_31'];?><?php } ?></p>
</div>
</div>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">手机转播广告图</label>
<div class="col-sm-9">
<div class="row">

<div class="col-md-4">
<p><input class="form-control" placeholder="<?php echo $aljhtlang['template']['adddp_29'];?>" name="madvurl[1]" value="<?php echo $madvurl['1'];?>"></p>

<div class="btn btn-default btn-file">
<i class="fa fa-file-image-o"></i> <?php echo $aljhtlang['template']['adddp_36'];?>
<input type="file" name="madv[1]" onchange="lrz_mobile('madv1',this)">
</div>

<p id="img_<?php echo madv1;?>"><?php if($madv['1']) { ?><img src="<?php echo $madv['1'];?>" width="100px" height="100px"><input type="hidden" name="madv1" value="<?php echo $madv['1'];?>">&nbsp;<input type="checkbox" onclick="delattach('madv1')"><?php echo $aljhtlang['template']['adddp_31'];?><?php } ?></p>
</div>
<div class="col-md-4">
<p><input class="form-control" placeholder="<?php echo $aljhtlang['template']['adddp_29'];?>" name="madvurl[2]" value="<?php echo $madvurl['2'];?>"></p>

<div class="btn btn-default btn-file">
<i class="fa fa-file-image-o"></i> <?php echo $aljhtlang['template']['adddp_37'];?>
<input type="file" name="madv[2]" onchange="lrz_mobile('madv2',this)">
</div>

<p id="img_<?php echo madv2;?>"><?php if($madv['2']) { ?><img src="<?php echo $madv['2'];?>" width="100px" height="100px"><input type="hidden" name="madv2" value="<?php echo $madv['2'];?>">&nbsp;<input type="checkbox" onclick="delattach('madv2')"><?php echo $aljhtlang['template']['adddp_31'];?><?php } ?></p>
</div>
<div class="col-md-4">
<p><input class="form-control" placeholder="<?php echo $aljhtlang['template']['adddp_29'];?>" name="madvurl[3]" value="<?php echo $madvurl['3'];?>"></p>

<div class="btn btn-default btn-file">
<i class="fa fa-file-image-o"></i> <?php echo $aljhtlang['template']['adddp_38'];?>
<input type="file" name="madv[3]" onchange="lrz_mobile('madv3',this)">
</div>

<p id="img_<?php echo madv3;?>"><?php if($madv['3']) { ?><img src="<?php echo $madv['3'];?>" width="100px" height="100px"><input type="hidden" name="madv3" value="<?php echo $madv['3'];?>">&nbsp;<input type="checkbox" onclick="delattach('madv3')"><?php echo $aljhtlang['template']['adddp_31'];?><?php } ?></p>
</div>
</div>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">手机版顶部背景图</label>

<div class="col-sm-3">
<div class="form-group" style="margin-left: 0px">
<div class="btn btn-default btn-file">
<i class="fa fa-file-image-o"></i><?php echo $aljhtlang['template']['adddp_7'];?>
<input type="file" name="brand_bg" id="brand_bg" onchange="lrz_mobile('brand_bg',this)">
</div>

</div>
<p id="img_brand_bg"><?php if($bd['brand_bg']) { ?><img src="<?php echo $bd['brand_bg'];?>" width="100px" height="100px"><?php } ?></p>
</div>
<div class="col-sm-3"><font style="color:red;margin-top:7px;display: block;">建议640*200</font></div>
</div>

</div>
<!-- /.box-body -->
</div>
                        </div>

<?php } ?>
<div class="form-group">
<label class="col-sm-3 control-label"> <?php echo $aljhtlang['template']['adddp_24'];?></label>
<div class="col-sm-9">
<textarea name="intro"  id="intro" style="height:500px;"><?php if($bd['intro']) { ?><?php echo $bd['intro'];?><?php } else { echo str_replace ("\r\n", "<br/>", $_G['cache']['plugin']['aljbd']['yushe']);?><?php } ?></textarea>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label"></label>
<div class="col-sm-9" style="text-align: center;">
<input type="submit" class="btn btn-submit btn-primary" value="<?php echo $aljhtlang['template']['adddp_35'];?>" style="width:40%;margin-top:30px">
</div>
</div>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /. box -->
            </div>
            <!-- /.col -->
            </form>
        </div>
        <!-- /.row -->
    </section>
</div>
<script src="source/plugin/<?php echo $pluginid_aljbd;?>/js/lrz.mobile.min.js" type="text/javascript"></script><?php include template('aljht:admin/common_tips_js'); ?><script>
function countChoices(obj)
{
var inputs = document.getElementsByName("businesstype[]");

var checked_counts = 0;

for(var i=0;i<inputs.length;i++){
if(inputs[i].checked){
checked_counts++;
}
}
max = 3;
if (checked_counts > max) {
alert("对不起，你只能选择" + max + "个!");
obj.checked = false;
}
}
function lj_region(){
var r = $('#region').val();
$("#province").html('<div class="form-group" style="text-align: center;"><img src="static/image/common/loading.gif" /></div>');
$("#getregion").html('');

$.post('plugin.php?id=<?php echo $pluginid;?>',{"upid":r,'act':'getregion'},function(data){

if(data){
$("#province").html(data);
}else{
$("#province").html('');
}
});
}
function lj_subregion(){
var r = $('#subregion').val();
$("#getregion").html('<div class="form-group" style="text-align: center;"><img src="static/image/common/loading.gif" /><div>');
$.post('plugin.php?id=<?php echo $pluginid;?>&act=getregion',{"upid":r,"op":'subregion'},function(data){
if(data){
$("#getregion").html(data);
}else{
$("#getregion").html('');
}
});
}
function lj_type(){
var r = $('#type').val();
$("#type1").html('<div class="form-group" style="text-align: center;"><img src="static/image/common/loading.gif" /></div>');
$("#type2").html('');
$.post('plugin.php?id=<?php echo $pluginid;?>&act=gettype',{"upid":r},function(data){
if(data){
$("#type1").html(data);
}else{
$("#type1").html('');
}
});
}
function lj_subtype(){
var r = $('#subtype').val();
$("#type2").html('<div class="form-group" style="text-align: center;"><img src="static/image/common/loading.gif" /><div>');
$.post('plugin.php?id=<?php echo $pluginid;?>&act=gettype',{"upid":r,"op":'subtype'},function(data){
if(data){
$("#type2").html(data);
}else{
$("#type2").html('');
}
});
}
    $('.btn-submit').click(function(){
        $('#sign').val($(this).attr('data-id'));
        layer.msg('<?php echo $aljhtlang['js']['brand_9'];?>', {icon: 16});
checkhHtml5();
return false;
    });
    $(function () {
        //Enable iCheck plugin for checkboxes
        //iCheck for checkbox and radio inputs
        $('.mailbox-messages input[type="checkbox"]').iCheck({
            checkboxClass: 'icheckbox_flat-blue',
            radioClass: 'iradio_flat-blue'
        });

        //Enable check and uncheck all functionality
        $(".checkbox-toggle").click(function () {
            var clicks = $(this).data('clicks');
            if (clicks) {
                //Uncheck all checkboxes
                $(".mailbox-messages input[type='checkbox']").iCheck("uncheck");
                $(".fa", this).removeClass("fa-check-square-o").addClass('fa-square-o');
            } else {
                //Check all checkboxes
                $(".mailbox-messages input[type='checkbox']").iCheck("check");
                $(".fa", this).removeClass("fa-square-o").addClass('fa-check-square-o');
            }
            $(this).data("clicks", !clicks);
        });

        //Handle starring for glyphicon and font awesome
        $(".mailbox-star").click(function (e) {
            e.preventDefault();
            //detect type
            var thisstar = $(this).find("a > i");
            var glyph = thisstar.hasClass("glyphicon");
            var fa = thisstar.hasClass("fa");

            //Switch states
            if (glyph) {
                thisstar.toggleClass("glyphicon-star");
                thisstar.toggleClass("glyphicon-star-empty");
            }

            if (fa) {
                thisstar.toggleClass("fa-star");
                thisstar.toggleClass("fa-star-o");
            }
        });
    });

</script>
<?php if($gookey) { ?>
<script src="//maps.googleapis.com/maps/api/js?key=<?php echo $gookey;?>" type="text/javascript" reload="1"></script>
<script type="text/javascript" charset="utf-8" reload="1">
    var contentString = "<div style=\"text-align:center;\"><?php if($bd['x']!=0&&$bd['y']!=0) { ?><b><?php echo $bd['name'];?></b><br />电话：<?php echo $bd['tel'];?><br />地址：<?php echo $bd['addr'];?><?php } else { ?>拖动图标，在地图上标注精确位置<?php } ?></div>";
    var confirmString = "<div style=\"text-align:center;\">把当前位置设为该商户的精确位置？<br><font color=\"red\">（继续拖动图标重新定位）</font><br><div><a id=\"correctOk\" class=\"mapmark left\"><font color=\"blue\">确定</font></a><a id=\"correctCancel\" class=\"mapmark right\">&nbsp;&nbsp;<font color=\"blue\">取消</font></a></div></div>";

    var marker;
    var map;
    var infowindow;
    <?php if($bd['x']!=0 && $bd['y']!=0) { ?>
    var y = <?php echo $bd['x'];?>;
    var x = <?php echo $bd['y'];?>;
    <?php } else { ?>
    var x = <?php echo $_G['cache']['plugin']['aljbd']['x'];?>;
    var y = <?php echo $_G['cache']['plugin']['aljbd']['y'];?>;
    <?php } ?>

    function initialize(){
        var point;
        var address = document.getElementById("ss").value;
        if(address){
            var geocoder = new google.maps.Geocoder(); //申明地址解析对象
            if (geocoder) {
                geocoder.geocode( { 'address': address}, function(results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        if(results[0]){
                            point = results[0].geometry.location;
                            //console.log(point.lng()+ "," +point.lat());
                            $('#xy').val(point.lng()+ "," +point.lat());
                            marker.setPosition(point);
                            map.setCenter(point);
                        }
                    } else {
                        alert("Geocode was not successful for the following reason: " + status);
                    }
                });
            }
        }
    }

    function initMap() {

        map = new google.maps.Map(document.getElementById('mapObj'), {
            zoom: 13,
            center: {lat: x, lng: y}
        });

        marker = new google.maps.Marker({
            map: map,
            draggable: true,
            animation: google.maps.Animation.DROP,
            position: {lat: x, lng: y}
        });

        infowindow = new google.maps.InfoWindow({
            content: contentString,
            position: MouseEvent.latLng,
        });
        infowindow.open(marker.get('map'), marker);
        marker.addListener('click', toggleBounce);
        google.maps.event.addListener(marker, 'dragend', function(MouseEvent) {
            var point=MouseEvent.latLng;
            infowindow.close();
            infowindow = new google.maps.InfoWindow({
                content: confirmString,
                position: MouseEvent.latLng,
            });
            infowindow.open(marker.get('map'), marker);
            google.maps.event.addListener(infowindow,"domready",function(){
                $("#correctOk").click(function() {
                    $('#xy').val(point.lng()+ "," +point.lat());
                    infowindow.close();
                    infowindow = new google.maps.InfoWindow({
                        content: '\u6807\u6ce8\u6210\u529f\uff0c\u8bf7\u91cd\u65b0\u67e5\u770b\u5730\u56fe\uff0c\u6216\u7ee7\u7eed\u62d6\u62fd\u91cd\u65b0\u6807\u6ce8\uff01',
                        position: MouseEvent.latLng,
                    });
                    infowindow.open(marker.get('map'), marker);
                });
                $("#correctCancel").click(function() {
                    infowindow.close();
                });
            });

        });


    }
    function toggleBounce(event) {
        if (marker.getAnimation() !== null) {
            marker.setAnimation(null);
        } else {
            marker.setAnimation(google.maps.Animation.BOUNCE);
        }
    }
    initMap();
</script>
<?php } else { ?>
<script src="//api.map.baidu.com/api?v=2.0&ak=Mz8y6VOGZv8AbIfQas83nf1B&s=1" type="text/javascript" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
var map;
var marker;
var infowindow;
var draggable = false;
var contentString = "<div style=\"text-align:center;\"><?php if($bd['x']>0&&$bd['y']>0) { ?><b><?php echo $bd['name'];?></b><br />电话：<?php echo $bd['tel'];?><br />地址：<?php echo $bd['addr'];?><?php } else { ?>拖动图标，在地图上标注精确位置<?php } ?></div>";
var confirmString = "<div style=\"text-align:center;\">把当前位置设为该商户的精确位置？<br><font color=\"red\">（继续拖动图标重新定位）</font><br><div><a id=\"correctOk\" class=\"mapmark left\"><font color=\"blue\">确定</font></a><a id=\"correctCancel\" class=\"mapmark right\">&nbsp;&nbsp;<font color=\"blue\">取消</font></a></div></div>";

function initialize() {

var point;
var op = "mark";
var mapapimark = "<?php if($bd['x']>0&&$bd['y']>0) { ?>(<?php echo $bd['x'];?>, <?php echo $bd['y'];?>)<?php } ?>";
var local = document.getElementById("ss").value;
var x = "<?php echo $bd['x'];?>";
var y = "<?php echo $bd['y'];?>";
if(mapapimark && !local) {
var mapapimarkaction = true;
point = new BMap.Point(x,y);
} else {
if(!local) {
var defaultmapaction = true;
point = new BMap.Point(<?php echo $_G['cache']['plugin']['aljbd']['x'];?>,<?php echo $_G['cache']['plugin']['aljbd']['y'];?>);
} else {
var geoaction = true;
}
}
var map = new BMap.Map("mapObj");
map.enableScrollWheelZoom();
map.centerAndZoom(point, 14);
if(mapapimarkaction || (defaultmapaction && (op == 'mark'))) {
marker = new BMap.Marker(point, {title: "<?php echo $bd['name'];?>"});
map.addOverlay(marker);
var opts = {
width : 250,
title : ''
}
infoWindow = new BMap.InfoWindow(contentString, opts);
marker.openInfoWindow(infoWindow);
marker.enableDragging();
} else if(geoaction) {
var Geocoder = new BMap.Geocoder();
if(Geocoder) {
Geocoder.getPoint(local, function(point){
if (point) {
map.centerAndZoom(point, 14);
                        $('#xy').val(point.lng+ "," +point.lat);
if(op == 'mark') {
marker = new BMap.Marker(point, {title: "<?php echo $bd['name'];?>"});
map.addOverlay(marker);
marker.enableDragging();
map_biaozhu();
}
} else {
alert("对不起，服务器异常，请稍候再试。");
}
}, "");
}
}
map_biaozhu();
}
initialize();

function map_biaozhu(){
var opts = {
width : 250,
title : ''
}
infoWindow = new BMap.InfoWindow(contentString, opts);
marker.addEventListener("click", function(e){
marker.openInfoWindow(infoWindow);
});
infoWindow.setContent(contentString);
marker.openInfoWindow(infoWindow);
marker.addEventListener("dragstart", function(e){
marker.closeInfoWindow();
});
marker.addEventListener("dragend", function(e){
infoWindow.setContent(confirmString);
marker.openInfoWindow(infoWindow);
infoWindow.enableAutoPan();
marker.setAnimation(BMAP_ANIMATION_BOUNCE);
marker.setAnimation(null);
$("#correctOk").click(function() {
newpoint = "("+e.point.lng + ", " + e.point.lat+")";
$('#xy').val(e.point.lng+ "," +e.point.lat);
infoWindow.setContent('<?php echo $aljhtlang['js']['adddp_1'];?>');
marker.openInfoWindow(infoWindow);
marker.setAnimation(BMAP_ANIMATION_BOUNCE);
marker.setAnimation(null);

});
$("#correctCancel").click(function() {
map.closeInfoWindow();
});
});
}
</script>
<?php } include template('aljht:admin/img_js'); include template('aljht:admin/footer'); ?>