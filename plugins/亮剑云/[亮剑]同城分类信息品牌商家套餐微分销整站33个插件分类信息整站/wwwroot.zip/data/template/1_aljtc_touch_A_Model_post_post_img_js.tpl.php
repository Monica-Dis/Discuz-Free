<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<script src="source/plugin/aljhtx//static/js/jquery.form.min.js?<?php echo VERHASH;?>" type="text/javascript" charset="utf-8"></script>
<script src="source/plugin/aljhtx//static/js/lrz.mobile.min.js?<?php echo VERHASH;?>" type="text/javascript" charset="utf-8"></script>
<!-- ���ʹ����ĳЩ��չ�������Ҫ�����JS -->
<script src="source/plugin/aljhtx//static/weui/js/fastclick.js?<?php echo VERHASH;?>" type="text/javascript" charset="utf-8"></script>
<?php if($errmsg) { ?>
<script>
    $.alert('<?php echo $errmsg;?>', function () {
        window.history.go(-1);
    });
</script>
<?php } ?>
<script>
       
       function tips(txt, fun, type) {
            layer.closeAll(); //���ģʽ���ر����в�
            $.hideLoading();
            console.log(type);
            if(type != 'undefined'){
                if(type == 'error'){
                    type = 'cancel';
                }
                $.toast(txt, type);
            }else{
                $.toast(txt, "text");
            }
            setTimeout(function() {
                if (typeof fun == 'function') {
                    fun();
                }else if(fun == 1){
                    location.href=location.href;
                }else if(fun){
                    location.href=fun;
                }
            }, 2000);
        }
        
        function delimg(obj){
            $(obj).parent().parent().next().remove();
            $(obj).parent().parent().remove();
        }
        function delimg_slt(obj){
            $(obj).parent().parent().parent().remove();
        }
        $('#postform').submit(function() {
            if($('#introContent').length > 0){
                $('#introPostContent').val($('#introContent').html());
            }
            $(this).ajaxSubmit({
                target:'#myiframe',
                //success:tips
            });
            return false;
        });
        $(document).ready(function() {
            if (typeof FastClick !== 'undefined' && fastclick==1) {
                FastClick.attach(document.body);
            }
            $("#datetime-picker").datetimePicker();
            $(".time_Picker").datetimePicker();
        });
    
    </script>
    <script>
        var num = null;
        var dataname = null;
        var datatype = 0;
        var data_placeholder = null;
        var dataid = 0;
        var ul = null;
        var img_src = 0;
        <?php if(IN_MINI == 1) { ?>
        $(function () {
            $(document).on('touchstart', '.weui-uploader__input', function() {
                num = $(this).attr('data-number');
                img_src = $(this).attr('data-img');
                if(num>9){
                  num = 9;
                }
                dataname = $(this).attr('data-name');
                dataid = $(this).attr('data-id');
                datatype = $(this).attr('data-type');
                ul = $(this).parent().prev();
                wx.chooseImage({
                    count: num,
                    success: function (res) {
                        var localIds = res.localIds; // ����ѡ����Ƭ�ı���ID�б���localId������Ϊimg��ǩ��src������ʾͼƬ
                        $.showLoading();
                        wxUploadImage(localIds);
    
                        return false;
                    }
                });
                return false;
            });
        });
    
        function wxUploadImage(localIds) {
            var localId = localIds.shift();
            wx.uploadImage({
                localId: localId, // ��Ҫ�ϴ���ͼƬ�ı���ID����chooseImage�ӿڻ��
                isShowProgressTips: 0, // Ĭ��Ϊ1����ʾ������ʾ
                success: function (res) {
                    var serverId = res.serverId; // ����ͼƬ�ķ�������ID
                    appendhtml(localId,serverId);
                    if(localIds.length > 0){
                        wxUploadImage(localIds);
                    }else{
                        $.hideLoading();
                        $(this).val('');
                    }
                }
            });
        }
        <?php } elseif(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'qianfan') !== false) { ?>
        $(function () {
            var uploadImageInput = $('.weui-uploader__input');
            uploadImageInput.on("touchstart", function() {
                num = $(this).attr('data-number');
                img_src = $(this).attr('data-img');
                if(num>9){
                  num = 9;
                }
                dataname = $(this).attr('data-name');
                dataid = $(this).attr('data-id');
                datatype = $(this).attr('data-type');
                ul = $(this).parent().prev();
                var type = 0;
                var jsUploadOptions = {
                    'picFormat': 1,
                    'picMaxSize': 1200,// ͼƬѹ�����������
                    'compressOption':100,
                    'uploadNum': num,
                    'uploadType': 0, // �ϴ����� 0: ͼƬ 1����Ƶ
                    'showCamera':false // ���ϴ���ʱ���Ƿ���ʾ���ա�
                }
                QFH5.uploadImageOrVideo(type, JSON.stringify(jsUploadOptions), function (state, data) {
                    if (state == 1) {
                        for(var i in data){
                            appendhtml(data[i].url,data[i].url);
                        }
                    } else {
                    }
                })
                $(this).val('');
                return false;
            });
        });
        <?php } elseif(strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPPX')>0) { ?>
        !function(){function n(n){if(!window.MagAndroidClient){if(window.WebViewJavascriptBridge)return n(WebViewJavascriptBridge);if(document.addEventListener("WebViewJavascriptBridgeReady",function(i){n(WebViewJavascriptBridge)},!1),window.WVJBCallbacks)return window.WVJBCallbacks.push(n);window.WVJBCallbacks=[n];var i=document.createElement("iframe");i.style.display="none",i.src="wvjbscheme://__BRIDGE_LOADED__",document.documentElement.appendChild(i),setTimeout(function(){document.documentElement.removeChild(i)},0)}}n(function(n){n.init&&"function"==typeof n.init&&n.init(function(n,i){}),n.registerHandler("jsCallBack",function(n,i){var o=JSON.parse(n),a=o.id,c=o.val,e=mag.callbacks[a];e&&(e.type&&"json"==e.type&&c&&(c=JSON.parse(c)),e.success(c))})}),mag={VERSION:"1.0",ready:function(i){n(function(){i()}),window.MagAndroidClient&&i()},callbacks:{},iosConnect:n,jsCallBack:function(n,i){var o=mag.callbacks[n];o&&(o.type&&"json"==o.type&&i&&(i=JSON.parse(i)),o.success(i))},getLocation:function(i){i&&(mag.callbacks.getLocation={type:"json",success:i},window.MagAndroidClient&&window.MagAndroidClient.getLocation(),n(function(n){n.callHandler("getLocation","",function(n){})}))},mapPick:function(i){i&&(mag.callbacks.mapPick={type:"json",success:i},window.MagAndroidClient&&window.MagAndroidClient.mapPick(),n(function(n){n.callHandler("mapPick","",function(){})}))},closeWin:function(){window.MagAndroidClient&&window.MagAndroidClient.closeWin(),n(function(n){n.callHandler("closeWin","",function(n){})})},previewImage:function(i){var o=JSON.stringify(i);window.MagAndroidClient&&window.MagAndroidClient.previewImage(o),n(function(n){n.callHandler("previewImage",o,function(n){})})},picPick:function(i){mag.callbacks.picPickPreview={type:"json",success:i.preview},mag.callbacks.picPickSuccess={type:"json",success:i.success},mag.callbacks.picPickFail={type:"json",success:i.fail};var o=JSON.stringify(i);window.MagAndroidClient&&window.MagAndroidClient.picPick(o),n(function(n){n.callHandler("picPick",o,function(n){})})},camera:function(i){mag.callbacks.cameraPreview={type:"json",success:i.preview},mag.callbacks.cameraSuccess={type:"json",success:i.success},mag.callbacks.cameraFail={type:"json",success:i.fail};var o=JSON.stringify(i);window.MagAndroidClient&&window.MagAndroidClient.camera(o),n(function(n){n.callHandler("camera",o,function(n){})})},setData:function(i){var o=JSON.stringify(i);window.MagAndroidClient&&window.MagAndroidClient.setData(o),n(function(n){n.callHandler("setData",o,function(n){})})},share:function(i,o){mag.callbacks.shareSuccess={type:"",success:o},window.MagAndroidClient&&window.MagAndroidClient.share(i),n(function(n){n.callHandler("share",i,function(n){})})},socialBind:function(i,o,a){mag.callbacks.bindOnSuccess={type:"json",success:o},mag.callbacks.bindOnFail={type:"json",success:a},window.MagAndroidClient&&window.MagAndroidClient.socialBind(i),n(function(n){n.callHandler("socialBind",i,function(n){})})},report:function(i){var o=JSON.stringify(i);window.MagAndroidClient&&window.MagAndroidClient.report(o),n(function(n){n.callHandler("report",o,function(n){})})},scanQR:function(i){i&&(mag.callbacks.scanQR={type:"",success:i},window.MagAndroidClient&&window.MagAndroidClient.scanQR(),n(function(n){n.callHandler("scanQR","",function(n){})}))},actionSheet:function(i,o){if(o){var a=JSON.stringify(i);mag.callbacks.actionSheet={type:"json",success:o},window.MagAndroidClient&&window.MagAndroidClient.actionSheet(a),n(function(n){n.callHandler("actionSheet",a,function(n){})})}},toast:function(i){window.MagAndroidClient&&window.MagAndroidClient.toast(i),n(function(n){n.callHandler("toast",i,function(n){})})},dialog:function(i){var o=JSON.stringify(i);mag.callbacks.dialogSuccess={type:"json",success:i.success},mag.callbacks.dialogCancel={type:"json",success:i.cancel},window.MagAndroidClient&&window.MagAndroidClient.dialog(o),n(function(n){n.callHandler("dialog",o,function(n){})})},progress:function(){window.MagAndroidClient&&window.MagAndroidClient.progress(),n(function(n){n.callHandler("progress","",function(n){})})},hideProgress:function(){window.MagAndroidClient&&window.MagAndroidClient.hideProgress(),n(function(n){n.callHandler("hideProgress","",function(n){})})},setTitle:function(i){window.MagAndroidClient&&window.MagAndroidClient.setTitle(i),n(function(n){n.callHandler("setTitle",i,function(n){})})},showNavigation:function(){window.MagAndroidClient&&window.MagAndroidClient.showNavigation(),n(function(n){n.callHandler("showNavigation","",function(n){})})},hideNavigation:function(){window.MagAndroidClient&&window.MagAndroidClient.hideNavigation(),n(function(n){n.callHandler("hideNavigation","",function(n){})})},setNavigationColor:function(i){window.MagAndroidClient&&window.MagAndroidClient.setNavigationColor(i),n(function(n){n.callHandler("setNavigationColor",i,function(n){})})},hideMore:function(){window.MagAndroidClient&&window.MagAndroidClient.hideMore(),n(function(n){n.callHandler("hideMore","",function(n){})})},showMore:function(){window.MagAndroidClient&&window.MagAndroidClient.showMore(),n(function(n){n.callHandler("showMore","",function(n){})})},tel:function(i){window.MagAndroidClient&&window.MagAndroidClient.tel(i),n(function(n){n.callHandler("tel",i,function(n){})})},sms:function(i,o){var a=JSON.stringify({phone:i,content:o});window.MagAndroidClient&&window.MagAndroidClient.sms(a),n(function(n){n.callHandler("sms",a,function(n){})})},toLogin:function(i){mag.callbacks.loginSuccess={type:"json",success:i},window.MagAndroidClient&&window.MagAndroidClient.toLogin(),n(function(n){n.callHandler("toLogin","",function(n){})})},toUserHome:function(i){window.MagAndroidClient&&window.MagAndroidClient.toUserHome(i),n(function(n){n.callHandler("toUserHome",i,function(n){})})},commentBar:function(i){var o=JSON.stringify(i);i.onComment&&(mag.callbacks.commentBar={type:"json",success:i.onComment}),i.onPageSelect&&(mag.callbacks.pageSelect={type:"json",success:i.onPageSelect}),i.onApplaud&&(mag.callbacks.applaud={type:"json",success:i.onApplaud}),window.MagAndroidClient&&window.MagAndroidClient.commentBar(o),n(function(n){n.callHandler("commentBar",o,function(n){})})},toComment:function(i){var o=JSON.stringify(i);i.success&&(mag.callbacks.comment={type:"json",success:i.success}),window.MagAndroidClient&&window.MagAndroidClient.toComment(o),n(function(n){n.callHandler("toComment",o,function(n){})})},newWin:function(i,o){i.indexOf("?")<0&&(i+="?");for(var a in o)i+="&"+a+"="+o[a];window.MagAndroidClient&&window.MagAndroidClient.newWin(i),n(function(n){n.callHandler("newWin",i,function(n){})})},setPageLife:function(n){mag.callbacks.pageAppear={type:"",success:n.pageAppear},mag.callbacks.pageDisappear={type:"",success:n.pageDisappear}},pay:function(i,o,a){mag.callbacks.payOnSuccess={type:"",success:o},mag.callbacks.payOnFail={type:"",success:a};var c=JSON.stringify(i);window.MagAndroidClient&&window.MagAndroidClient.pay(c),n(function(n){n.callHandler("pay",c,function(n){})})},alipay:function(i,o,a){if(!i)return!1;mag.callbacks.alipayOnSuccess={type:"",success:o},mag.callbacks.alipayOnFail={type:"",success:a},window.MagAndroidClient&&window.MagAndroidClient.alipay(i),n(function(n){n.callHandler("alipay",i,function(n){})})},phoneBind:function(i){mag.callbacks.phoneBindSuccess={type:"string",success:i},window.MagAndroidClient&&window.MagAndroidClient.phoneBind(),n(function(n){n.callHandler("phoneBind","",function(n){})})},qqConnectLogin:function(i){window.MagAndroidClient&&window.MagAndroidClient.qqConnectLogin(i),n(function(n){n.callHandler("qqConnectLogin",i,function(n){})})},bounceEnable:function(i){n(function(n){n.callHandler("bounceEnable",i,function(n){})})}},window.mag=mag,mag.VERSION="1.0"}();
        $(function () {
            var uploadImageInput = $('.weui-uploader__input');
            uploadImageInput.on("touchstart", function() {
                num = $(this).attr('data-number');
                img_src = $(this).attr('data-img');
                if(num>9){
                  num = 9;
                }
                dataname = $(this).attr('data-name');
                dataid = $(this).attr('data-id');
                datatype = $(this).attr('data-type');
                ul = $(this).parent().prev();
                mag.picPick({
                    preview: function(res){
                        $.showLoading();
                    },
                    success: function(res){
                        $.hideLoading();
                        if(res.url && typeof res.url != 'undefined'){
                            var imgurl = res.url;
                        }else{
                            var imgurl = '<?php echo $_G['cache']['plugin']['aljhtx']['magapp_url'];?>/core/attachment/attachment/attach?aid='+res.aid;
                        }
                        appendhtml(imgurl,imgurl);
                    },
                    fail: function(res){
                        $.hideLoading();
                    },limit_count:num
                });
                $(this).val('');
                return false;
            });
        });
        <?php } else { ?>
        $(document).on('change', '.weui-uploader__input', function() {
            num = $(this).attr('data-number');
            img_src = $(this).attr('data-img');
            dataname = $(this).attr('data-name');
            dataid = $(this).attr('data-id');
            datatype = $(this).attr('data-type');
            ul = $(this).parent().prev();
            var file = this.files[0];
            if (!file.type.match('image.*')) {
                layer.open({content: '&#22270;&#29255;&#31867;&#22411;&#38169;&#35823;',skin: 'msg',time: 2});
                return false;
            }
            $.showLoading();
            lrz(file, {
                //width:800,
                done: function (results) {
                    appendhtml(results.base64,results.base64);
                    $.hideLoading();
                }
    
            })
            $(this).val('');
        });
        <?php } ?>
        function appendhtml(localId,serverId) {
            if(img_src == 1){
            
                $.post('plugin.php?id=aljtc&act=echo_imgsrc',{'base':serverId},function(res){
                    if(res.code == 1){
                        sendImgSrc(res.src);
                    }else{
                        tips(res.tips);
                    }
                },'json');
            }else{
                appendhtml_base(localId,serverId);
            }
        }
        function appendhtml_base(localId,serverId) {
            if(datatype == '1'){
                if(dataname == 'adv'){
                   var d_img_name = 'madv';
                   var d_text_name = 'madvurl';
                   var d_p_name = '&#35831;&#36755;&#20837;&#38142;&#25509;';
                }else{
                    var d_img_name = dataname+'_img';
                    var d_text_name = dataname+'_text';
                    if(dataid == 'url'){
                        var d_p_name = '&#35831;&#36755;&#20837;&#38142;&#25509;';
                    }else{
                        var d_p_name = '&#25991;&#26412;&#20869;&#23481;';
                    }
                }
                console.log(ul.children('a').length);
                if(num <= ul.children('a').length){
                    $.hideLoading();
                    layer.open({content: '&#26368;&#22810;&#19978;&#20256;'+num+'&#24352;',skin: 'msg',time: 2});
                    return false;
                }
                var html = '<a href="javascript:void(0);" class="weui-media-box weui-media-box_appmsg">';
                html += '<div class="weui-media-box__hd" style="position: relative">';
                html += '<div class="weui-uploader__file-content" style="display: block"><i class="weui-icon-cancel" onclick="delimg_slt(this)"></i></div>';
                html += '<img class="weui-media-box__thumb" src="'+localId+'">';
                html += '</div><div class="weui-media-box__bd">';
                html += '<textarea class="weui-textarea pic_slt_text" name="'+d_text_name+'[]" placeholder="'+d_p_name+'" rows="4"></textarea>';
                html += '<input name="'+d_img_name+'[]" class="pic_slt" type="hidden" value="'+serverId+'">';
                html += '</div></a>';
                var domdata =html;
                ul.append(domdata);
            }else{
                var domdata ='<li class="weui-uploader__file weui-uploader__file_status img_list">'
                    +'<img src="'+localId+'" style="width:79px;height:79px"/>'
                    +'<div class="weui-uploader__file-content">'
                    +'<i class="weui-icon-cancel" onclick="delimg(this)"></i>'
                    +'</div></li>';
                if(typeof dataname !== 'undefined' && typeof dataid !== 'undefined'){
                    domdata += '<input name="'+dataname+'['+dataid+']" class="pic" type="hidden" value="'+serverId+'">';
                }else if(typeof dataname !== 'undefined'){
                    domdata += '<input name="'+dataname+'" class="pic" type="hidden" value="'+serverId+'">';
                }else{
                    domdata += '<input name="pic[]" class="pic" type="hidden" value="'+serverId+'">';
                }
    
                if(num == 1){
                    ul.html(domdata);
                }else{
                    if(num <= ul.children('li').length){
                        $.hideLoading();
                        layer.open({content: '最多上传'+num+'张',skin: 'msg',time: 2});
                        return false;
                    }
                    ul.append(domdata);
                }
            }
        }
    </script>