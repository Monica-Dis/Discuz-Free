<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<style>
.swiper-slide img{width:100%}
</style>
<section class="ad_banner">
<div class="swiper-container" id="ad_banner" style="visibility: visible;height: auto;">
<div class="swiper-wrapper"><?php if(is_array($index_list_top_lz_ad)) foreach($index_list_top_lz_ad as $lun_ad_value) { ?><div class='swiper-slide'><?php echo htmlspecialchars_decode($lun_ad_value)?></div>
<?php } ?>
</div>
<div class="swiper-pagination" ></div>
</div>
</section>

<script>
var swiper = new Swiper('#ad_banner', {
pagination: '.swiper-pagination',
paginationClickable: true,
spaceBetween: 30,
autoplay: 5000,
});
</script>
<div class="line-5"></div>