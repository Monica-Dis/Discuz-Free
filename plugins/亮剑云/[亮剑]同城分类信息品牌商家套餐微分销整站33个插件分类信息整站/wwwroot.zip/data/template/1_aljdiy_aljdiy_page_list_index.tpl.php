<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template(PLUGIN_ID.':admin/header')?><style>
    
    body{ font-size: 14px; }
    tr th{
        color:#666;
        font-size: 14px;
    }
    .info-box-number{
        margin-top:5px;
        margin-left:5px;
    }
    .info-box-text{
        margin-top:10px;
    }
    .layui-table-body{overflow-x: hidden;}
    .content-wrapper{background-color: #ffffff;}
    .layui-laypage-limits select{margin-top:2px;}
    .layui-table, .layui-table-view {
        margin: 3px 0;
    }
    .box.box-default {
        border-top-color: #009688;
    }
    .box {
        position: relative;
        border-radius: 3px;
        background: #fff;
        border-top: 2px solid #009688;
        margin-bottom: 20px;
        width: 100%;
        box-shadow: 0 1px 1px rgba(0,0,0,0.1);
    }
    .nav-tabs {
        border-bottom: none;
    }
    .box.box-primary {
        border-top-color: #009688;
    }
    .btn-primary {
        background-color: #009688;
        border-color: #009688;
    }
    .layui-table-tips-c {
        line-height: 14px;
    }
    .layui-table-cell {
        height: auto;
        line-height: 28px;
        padding: 0 15px;
        position: relative;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: normal;
        box-sizing: border-box;
    }
    .layui-table-view .layui-table{
        width:100%!important;
    }
    .catpic img{
        width:40px;
    }
</style>
<div class="content-wrapper" style="margin-left:0px">
    <section class="content">
        <div class="row">
            <div class="col-md-7">
                <?php include template(APP_ID.':'.APP_ID.'/'.CONTROLLER.'/list_nav');?>            </div>

            <div class="col-md-5" style="text-align:right">
                <a href="javascript:;"  class="btn btn-primary realtime"><strong>&nbsp;创建新页面</strong></a>
                
            </div>

            <!-- /.col -->
            <div class="col-md-12">
                <div class="box box-primary">
                    <!-- /.box-header -->
                    <?php if($type == 0) { ?>
                    <div style="margin-top: 10px;">
                        <a href="javascript:;"  class="btn btn-primary def_daoru" data-type="aljbd"><strong>&nbsp;导入默认商城模板</strong></a>
                        <a href="javascript:;"  class="btn btn-primary def_daoru" data-type="aljtc"><strong>&nbsp;导入默认同城模板</strong></a>
                        <div class="box-tools pull-right layui-form">
                            
                            <div class="layui-inline">
                              <input type="text" name="search" value="<?php echo $_GET['search'];?>" id="search" class="layui-input" placeholder="页面名称或描述" onkeypress="R.enterPress(event)" onkeydown="R.enterPress()">
                          </div>
                          <div class="layui-inline">
                              <button class="layui-btn layui_btn_search" lay-submit="" lay-filter="formDemoPane">搜索</button>
                            </div>
                      </div>
                    </div>
                    <?php } ?>
                    <iframe style="display:none;" name="submitiframe"></iframe>
                    <form name="cpform" id="admingoodssubmit" method="post" autocomplete="off" action="<?php echo $dourl;?>" target="submitiframe">
                        <input type="hidden" value="yes" name="ajax">
                        <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>">
                    </form>
                    <blockquote class="layui-elem-quote" style="margin-top:10px;font-size:14px;">
                        创建页面后您即可自行将创建的页面DIY成您想要的样子
                        <?php if($type == 1) { ?>
                        <br/>单店DIY中的链接不用带&bid=ID,程序会自动在链接中加入您页面中绑定的商家 ID
                        <?php } ?>
                    </blockquote>
                    
                    <table id="demo" lay-filter="test"></table>
                    
                </div>
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
</div>
<script>


    var R = {
        options: {
            formhash: '<?php echo FORMHASH;?>',
        },
        realtime: function(){
            $('.realtime').click(function() {
                layer.open({
                    type: 2,
                    title: '创建新页面',
                    shadeClose: true,
                    shade: false,
                    maxmin: true, //开启最大化最小化按钮
                    offset: "20px",
                    area: ['70%', '90%'],
                    content: 'plugin.php?id=<?php echo APP_ID;?>&c=<?php echo CONTROLLER;?>&a=list_submit&admin_id=<?php echo $admin_id;?>&station_id=<?php echo $station_id;?><?php echo $com_url;?>'
                });
            });
        },
        enterPress: function(e){
            var e = e || window.event;
            if(e.keyCode == 13){
                $('.layui_btn_search').click();
            }
        },
        init: function(){
            layui.use('table', function(){
                var table = layui.table;
                var tableIns = table.render({
                    elem: '#demo'
                    ,limit: 20
                    ,url: 'plugin.php?id=<?php echo APP_ID;?>&c=<?php echo CONTROLLER;?>&a=list_index&ajax=yes&render=yes&groupid=<?php echo htmlspecialchars($_GET[groupid])?>&admin_id=<?php echo $admin_id;?>&station_id=<?php echo $station_id;?><?php echo $com_url;?>'
                    ,page: true
                    ,skin: 'line'
                    ,even: true
                    ,cols: [[
                        {field: 'qrcode', title: '二维码',width: 110, templet: function(d){
                            return '<img class="catpic" style="width:80px;" src=http://qr.liantu.com/api.php?text=<?php echo $url;?>plugin.php?id=aljdiy%26c=index%26a=index%26ajax=yes%26page_id='+d.id+'>';
                        }}
                        ,{field: 'title', title: '页面名称', templet: function(d){
                            return '<a target="_blank" href="plugin.php?id=aljdiy&amp;c=index&amp;a=index&amp;ajax=yes<?php echo $com_url;?>&amp;page_id='+d.id+'">'+d.title+'</a>';
                        }}
                        ,{field: 'intro', title: '页面描述'}
                        ,{field: 'title', title: '分组名',width: 100, templet: function(d){
                            return d.group_title;
                        }}
                        ,{field: 'push_to_page_title',width: 150, title: '绑定页面'}
                        ,{field: 'createtime',width: 100, title: '创建时间'}
                        ,{field: 'updatetime',width: 100, title: '修改时间'}
                        ,{align:'center', title: '操作',width: 200, templet: function(d){
                            var btn = '';
                            btn += '<a href="plugin.php?id=aljdiy&amp;c=diy&amp;a=index<?php echo $com_url;?>&amp;ajax=yes&amp;page_id='+d.id+'" onclick="return false;" class="layui-btn layui-btn-normal layui-btn-xs" lay-event="view">可视化DIY</a>';
                            btn += '<a class="layui-btn layui-btn-primary layui-btn-xs copybtn" data-clipboard-text="" lay-event="copy">复制页面链接</a>';
                            btn += '<a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="query">编辑</a>';
                            btn += '<a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del">删除</a>';
                            btn += '<a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="copy_page">复制页面</a>';
                            return btn;
                        }}
                    ]]
                });
                table.on('tool(test)', function(obj){
                    var data = obj.data;
                    if(obj.event === 'del'){
                        layer.confirm('您确定要删除吗？', {"offset": "50px"}, function(index){
                            layer.load(0, {"offset": "50px"});
                            $.post('plugin.php?id=<?php echo APP_ID;?>&c=<?php echo CONTROLLER;?>&a=list_delete&ajax=yes<?php echo $com_url;?>&mid='+data.id, function(){
                                layer.alert('删除成功！', {"offset": "50px"}, function(){
                                    obj.del();
                                    layer.closeAll();
                                });
                            });

                        });
                    }
                    if(obj.event === 'copy_page'){
                        layer.confirm('您确定要复制一个此页面吗？', {"offset": "50px"}, function(index){
                            layer.load(0, {"offset": "50px"});
                            $.post('plugin.php?id=<?php echo APP_ID;?>&c=<?php echo CONTROLLER;?>&a=list_copy&ajax=yes<?php echo $com_url;?>&mid='+data.id, function(){
                                layer.alert('复制成功', {"offset": "50px"}, function(){
                                    R.init();
                                    layer.closeAll();
                                });
                            });

                        });
                    }
                    if(obj.event === 'query'){
                        layer.open({
                            type: 2,
                            title: '编辑页面',
                            shadeClose: true,
                            shade: false,
                            maxmin: true, 
                            offset: "20px",
                            area: ['70%', '90%'],
                            content: 'plugin.php?id=<?php echo APP_ID;?>&c=<?php echo CONTROLLER;?>&a=list_submit<?php echo $com_url;?>&mid='+data.id
                        });
                    }
                    if(obj.event === 'view'){
                        location.href='plugin.php?id=aljdiy&c=diy&a=index<?php echo $com_url;?>&ajax=yes&page_id='+data.id;
                    }
                    if(obj.event === 'copy'){
                        var url = '<?php echo $url;?>plugin.php?id=aljdiy&c=index&a=index&ajax=yes<?php echo $com_url;?>&page_id='+data.id;
                        $(this).attr('data-clipboard-text', url);
                    }
                });
                $('.layui_btn_search').on('click', function(){
                    tableIns.reload({
                        where: {
                            search: $('#search').val()
                        }
                        ,page: {
                            curr: 1
                        }
                    });
                });

            });
            R.realtime();
        }
    }
    R.init();
    $(document).on('click', '.catpic', function(){
        layer.open({
            type: 1,
            title: false,
            closeBtn: 0,
            area: ['660px', '660px'],
            shadeClose: true,
            content: "<div style='display:table-cell; vertical-align:middle;width: 660px;height: 660px;text-align:center;'><img style='max-wdith:100%;max-height:100%;' src="+$(this).parent().parent().parent().find('img').attr('src')+"></div>"
        });
    });
    $(document).on('click', '.def_daoru', function(){
        var type = $(this).data('type');
        $.post('plugin.php?id=<?php echo APP_ID;?>&c=<?php echo CONTROLLER;?>&a=daoru&ajax=yes',{'type':type}, function(data){
            if(data == 1){
                layer.alert('导入成功', {"offset": "50px"}, function(){
                    R.init();
                    layer.closeAll();
                });
            }else{
                layer.alert('导入失败', {"offset": "50px"});
            }
            
        });
    });
</script>
<script src="source/plugin/aljhtx/static/js/clipboard.js" type="text/javascript"></script>
<script>
 //一键复制
 var show = true;
 var clipboard = new Clipboard('.copybtn');
 clipboard.on('success', function (e) {
  if(show) {
   alert('\u590d\u5236\u6210\u529f');
   show = false;
   setTimeout(function () {
    show = true;
   }, 1000);
  }

 });
 clipboard.on('error', function (e) {
  if(show) {
   alert('\u590d\u5236\u5931\u8d25');
   show = false;
   setTimeout(function () {
    show = true;
   }, 1000);
  }
 });
 </script><?php include template(PLUGIN_ID.':admin/footer')?>