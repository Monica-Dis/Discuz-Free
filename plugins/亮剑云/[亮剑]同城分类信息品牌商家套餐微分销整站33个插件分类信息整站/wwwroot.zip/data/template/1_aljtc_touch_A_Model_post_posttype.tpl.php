<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('posttype');?><?php include template('aljtc:A_Model/header'); ?><style>
.weui-grids {
    position: relative;
    overflow: hidden;
background: #fff;
}
.js_grid {
    width: 25%!important;
    position: relative;
    float: left;
    padding: 15px 0px;
    box-sizing: border-box;
}

.weui-mask {
    opacity: 0;
    -webkit-transition-duration: .3s;
    transition-duration: .3s;
    visibility: hidden;
}
.weui-mask.weui-mask--visible {
    opacity: 1;
    visibility: visible;
}
.w-tip{
width: 100%;
    display: inline-block;
    height: 100%;
}
</style>
<body >
<main class="indexcontent" style="background:#fff">
<?php if(($_G['cache']['plugin']['aljhtx']['is_aljtc'] && $_G['cache']['plugin']['aljbd']) || $_G['cache']['plugin']['aljtsq']['is_aljtsq']) { ?>
<div class="weui-cells__title">我是商家</div>
<div class="weui-cells">
<a class="weui-cell weui-cell_access navigateTo" href="<?php if($_G['cache']['plugin']['aljtsq']['is_aljtsq']) { ?>plugin.php?id=aljtsq&c=aljtsq&a=addStore<?php } else { ?>plugin.php?id=aljbd&act=attend<?php } ?>">
<div class="weui-cell__hd"><img src="source/plugin/aljtc/static/img/tops.png" width="50"/></div>
<div class="weui-cell__bd">
<h4 class="weui-media-box__title">点击入驻 开向未来</h4>
<p class="weui-media-box__desc">超低成本，本地宣传，简单有效，方便快捷！</p>
</div>
<div class="weui-cell__ft"></div>
</a>
</div>
<?php } ?>
<div class="weui-cells__title" style="border-bottom: 1px solid #f4f4f4;padding-bottom: 10px;"><?php echo $tips;?></div>
<div class="weui-cells__title">请选择发布的栏目</div>
<div class="weui-grids"><?php if(is_array($typelist)) foreach($typelist as $tmp_key => $tmp_value) { ?>  <a href="javascript:;" class="js_grid navigateTo" onclick="return showtypelist(<?php echo $tmp_value['id'];?>,'<?php echo $tmp_value['subject'];?>')">
    <div class="weui-grid__icon">
      <img src="<?php if($tmp_value['logo']) { ?><?php echo $tmp_value['logo'];?><?php } else { ?>source/plugin/aljtc/static/img/moren.png<?php } ?>" alt="">
    </div>
    <p class="weui-grid__label">
      <?php echo $tmp_value['subject'];?>
    </p>
  </a>
<?php } ?>
  
</div>
<?php if($_G['cache']['plugin']['aljhtx']['is_aljtc'] && $bd) { ?>
<style>
.fs24{font-size: 24px;}
.ic_c_1{
color:#3CC385;
}
.ic_c_2{
color:#F47944;
}
.ic_c_3{
color:#5CAFF0;
}
</style>
<div class="weui-cells__title">我是商家，请选择要发布的项目</div>
<div class="weui-grids">

<a href="plugin.php?id=aljbd&amp;act=addgoods" class="js_grid navigateTo" >
<div class="weui-grid__icon">
<i class="iconfont icon-shangpin2 ic_c_1 fs24"></i>
</div>
<p class="weui-grid__label">
发布商品
</p>
</a>
<?php if($_G['cache']['plugin']['aljspt']) { ?>
<a href="plugin.php?id=aljbd&amp;act=addgoods&amp;commodity_type=2" class="js_grid navigateTo" >
<div class="weui-grid__icon">
<i class="iconfont icon-pintuangou ic_c_3 fs24"></i>
</div>
<p class="weui-grid__label">
发布拼团
</p>
</a>
<?php } if($_G['cache']['plugin']['aljstg']) { ?>
<a href="plugin.php?id=aljbd&amp;act=addgoods&amp;commodity_type=1" class="js_grid navigateTo" >
<div class="weui-grid__icon">
<i class="iconfont icon-yingxiaogongju-tuangoumiaosha1 ic_c_1 fs24"></i>
</div>
<p class="weui-grid__label">
发布团购
</p>
</a>
<?php } if($_G['cache']['plugin']['aljthd']) { ?>
<a href="plugin.php?id=aljthd&amp;a=post&amp;c=aljthd" class="js_grid navigateTo" >
<div class="weui-grid__icon">
<i class="iconfont icon-huodong ic_c_2 fs24"></i>
</div>
<p class="weui-grid__label">
发布活动
</p>
</a>
<?php } else { ?>
<a href="plugin.php?id=aljbd&amp;act=addnotice" class="js_grid navigateTo" >
<div class="weui-grid__icon">
<i class="iconfont icon-huodong ic_c_2 fs24"></i>
</div>
<p class="weui-grid__label">
发布活动
</p>
</a>
<?php } ?>
<a href="plugin.php?id=aljbd&amp;act=addconsume" class="js_grid navigateTo" >
<div class="weui-grid__icon">
<i class="iconfont icon-youhuiquan-xianxing ic_c_3 fs24"></i>
</div>
<p class="weui-grid__label">
发布优惠券
</p>
</a>
<?php if($_G['cache']['plugin']['aljtsq']) { ?>
<a href="plugin.php?id=aljtsq&amp;a=addStore&amp;c=aljtsq" class="js_grid navigateTo" >
<div class="weui-grid__icon">
<i class="iconfont icon-xinjianmendian ic_c_2 fs24"></i>
</div>
<p class="weui-grid__label">
添加门店
</p>
</a>
<?php } if($_G['cache']['plugin']['aljsp']) { ?>
<a href="plugin.php?id=aljsp&amp;act=addvideo" class="js_grid navigateTo" >
<div class="weui-grid__icon">
<i class="iconfont icon-shipin1 ic_c_2 fs24"></i>
</div>
<p class="weui-grid__label">
上传视频
</p>
</a>
<?php } if($_G['cache']['plugin']['aljsfx']) { ?>
<a href="plugin.php?id=aljsfx&amp;a=add&amp;c=distribution" class="js_grid navigateTo" >
<div class="weui-grid__icon">
<i class="iconfont icon-jiagoufenxiao ic_c_1 fs24"></i>
</div>
<p class="weui-grid__label">
入驻微店
</p>
</a>
<?php } ?>
</div>
<?php } ?>

</main><?php include template('aljtc:A_Model/footer'); ?></body>
<script>
function showtypelist(upid,name) {
var url = 'plugin.php?id=aljtc&act=getpos';
var data={'rid':upid};
$.post(url,data,function(res) {
console.log(res);
if(!res.code) {
var act=[];

$.each(res,function(k,d) {
var surl = 'plugin.php?id=aljtc&act=post&typeid='+upid+'&sid='+d.id;
var dom = '<a href="'+surl+'" class="w-tip navigateTo">'+d.subject+'</a>';
var dataarray = {'text':dom};
act.push(dataarray);
});
console.log(act);
getsubtype(act);
}else {
if (window.__wxjs_environment === 'miniprogram' && typeof wx !== 'undefined') {
miniProgramwebview('plugin.php?id=aljtc&act=post&typeid='+upid);
return false;
}else{
location.href = 'plugin.php?id=aljtc&act=post&typeid='+upid;
}
}
},'json');

}
function getsubtype(act) {
$.actions({
  actions: act,
});
}
<?php if($_GET['zufangtype']>0) { ?>
showtypelist('<?php echo $_GET['zufangtype'];?>')
<?php } ?>
</script>
</html>