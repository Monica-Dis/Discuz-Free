<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<script src="source/plugin/aljhtx/static/js/md5.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<script>
var fastclick = 1;
var keep_scrollheight = 0;
var keep_url_md5 = jQuery.md5(window.location.href);
var keep_scroll = 'aljbd_' + keep_url_md5;
var keep_scroll_1 = 'aljbd_scroll' + keep_url_md5;
var keep_page = 'keep_listpage_' + keep_url_md5;
var keep_data = 'keep_listdata_' + keep_url_md5;
var keep_type_data = 'keep_typelistdata_' + keep_url_md5;
var keep_typeid = 'keep_listtypeid_' + keep_url_md5;
function get_cache_size(t){
        t = t == undefined ? "l" : t;
        var obj = "";
        if(t==='l'){
            if(!window.localStorage) {
                console.log('\u6d4f\u89c8\u5668\u4e0d\u652f\u6301localStorage');
            }else{
                obj = window.localStorage;
            }
        }else{
            if(!window.sessionStorage) {
                console.log('\u6d4f\u89c8\u5668\u4e0d\u652f\u6301sessionStorage');
            }else{
                obj = window.sessionStorage;
            }
        }
        if(obj!==""){
            var size = 0;
            for(item in obj) {
                if(obj.hasOwnProperty(item)) {
                    size += obj.getItem(item).length;
                }
            }
            console.log('\u5f53\u524d\u5df2\u7528\u5b58\u50a8\uff1a' + (size / 1024).toFixed(2) + 'KB');
        }
    }
    get_cache_size('t');
    
</script>
<?php if(strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false) { include template('aljapp:uniapp'); } if(false !== strpos($_SERVER['HTTP_USER_AGENT'],'swan')) { ?>
<script src="https://b.bdstatic.com/searchbox/icms/searchbox/js/swan-2.0.18.js" type="text/javascript"></script>
<?php } ?>
<script>
     jQuery(document).on('click', '.class_back,.header-left,.c_header_left', function() {
        <?php if($_GET['act'] == 'set') { ?>
            <?php if(strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false) { ?>
                currentWebview().close();
                return false;
            <?php } elseif(false !== strpos($_SERVER['HTTP_USER_AGENT'],'swan')) { ?>
                swan.webView.navigateBack({ changed: true });//������һҳ
                return false;
            <?php } elseif(strpos(strtolower($_SERVER['HTTP_USER_AGENT']),"miniprogram") !== false) { ?>
                wx.miniProgram.navigateBack({ changed: true });//������һҳ
                return false;
            <?php } ?>
        <?php } else { ?>
            <?php if(strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false) { ?>
                if(document.referrer == ''){
                    currentWebview().close();
                    return false;
                }else{
                    history.back();
                    return false;
                }
            <?php } elseif(false !== strpos($_SERVER['HTTP_USER_AGENT'],'swan')) { ?>
                if(document.referrer == ''){
                    swan.webView.navigateBack({ changed: true });//������һҳ
                }else{
                    history.back();
                    return false;
                }
            <?php } elseif(strpos(strtolower($_SERVER['HTTP_USER_AGENT']),"miniprogram") !== false) { ?>
                if (window.__wxjs_environment === 'miniprogram') {
                    if(document.referrer == ''){
                        wx.miniProgram.navigateBack({ changed: true });//������һҳ
                    }else{
                        history.back();
                        return false;
                    }
                    return false;
                }
            <?php } ?>
        <?php } ?>
        if($('#back_url').length > 0){
            location.href = $('#back_url').data('url');
        }else if($('#back_user').length > 0){
            location.href = 'plugin.php?id=aljbdx&act=user';
        }else if($('#back_user_tc').length > 0){
            location.href = 'plugin.php?id=aljtc&act=user';
        }else{
            
            if(document.referrer == ''){
                if($('.store_info_num').length > 0){
                    location.href = 'plugin.php?id=aljtsc';
                }else{
                    location.href = 'plugin.php?id=aljbd';
                }
            }else{
                history.go(-1);
            }
        }
        return false;
    });
</script>
<?php if($settings['mobilenavbackcolor']['value']) { ?>
<style type="text/css">
.header {
display: block;
position: relative;
height: 44px;
line-height: 44px;
color: white;
overflow: hidden;
border-bottom: 1px solid <?php echo $settings['mobilenavbackcolor']['value'];?>;
background: <?php echo $settings['mobilenavbackcolor']['value'];?>;
}
.label-mycolor {
background: -webkit-linear-gradient(top, <?php echo $settings['mobilenavbackcolor']['value'];?>, <?php echo $settings['mobilenavbackcolor']['value'];?>);
}
.global-header { 
    display: block;
    position: relative;
    height: 44px;
    line-height: 44px;
    color: white;
    overflow: hidden;
    border-bottom: 1px solid <?php echo $settings['mobilenavbackcolor']['value'];?>;
    background:-webkit-linear-gradient(top, <?php echo $settings['mobilenavbackcolor']['value'];?>, <?php echo $settings['mobilenavbackcolor']['value'];?>);
    background:-moz-linear-gradient(top, <?php echo $settings['mobilenavbackcolor']['value'];?>, <?php echo $settings['mobilenavbackcolor']['value'];?>);
}

.cost-box .buy-box .buy-btn {
height: 34px;
width: 105px;
color: #fff;
background-color: <?php echo $settings['mobilenavbackcolor']['value'];?>;
border-radius: 5px;
text-align: center;
line-height: 35px;
display: block;
font-size: 16px;
}
.buy-now {
display: block;
height: 40px;
margin: 10px 9px;
color: #fff;
background-color: <?php echo $settings['mobilenavbackcolor']['value'];?>;
border-radius: 4px;
text-align: center;
}
.nav_filter_l a.on{color:<?php echo $settings['mobilenavbackcolor']['value'];?> !important;}
.nav_filter_l a.on::after{border-top-color: <?php echo $settings['mobilenavbackcolor']['value'];?> !important;}
.gbt-green{
    background: <?php echo $settings['mobilenavbackcolor']['value'];?> none repeat scroll 0 0 !important;
    border: 1px solid <?php echo $settings['mobilenavbackcolor']['value'];?> !important;
}
.type_text .cur .tab-reply{
    background: <?php echo $settings['mobilenavbackcolor']['value'];?> !important;
}
.p-tab td.p-pay {
    
    background: <?php echo $settings['mobilenavbackcolor']['value'];?> !important;
}
</style>
<?php } ?>
<style>
    .c_news{
        display: inline-block;
        position: absolute;
        top: 2px;
        background-color: #f23030;
        height: 14px;
        line-height: 14px;
        padding-left: 5px;
        padding-right: 5px;
        font-style: normal;
        border-radius: 12px;
        right: 20%;
        font-size: 9px;
        color: #fff !important;
        font-family: PingFangSC-Regular,Helvetica,"Droid Sans",Arial,sans-serif;
        border: 1px solid #fff;
    }
    .attes_logo{width:20px;position: relative;
        top: -2px;}
    .weui-picker-container, .weui-picker-overlay{
        z-index: 100000;
    }
    .c_expose_goods .aljsqImg img{
        width:100px;height:100px;
    }
    .pointer{cursor: pointer;}
    .c_p_t {
    color: rgb(230,220,190);
    background: #2B2B2A;
    display: inline-block;
    vertical-align: middle;
    padding: 0 3px;
    white-space: nowrap;
    font-size: 10px;
    border-radius: 3px;
    line-height: 14px;
    position: relative;
    margin-left: 5px;
    height: 14px;
}
.c_p_t:before {
    position: absolute;
    content: "";
    right: 100%;
    top: 4px;
    width: 0;
    height: 0;
    border-top: 3px solid transparent;
    border-right: 3px solid #2B2B2A;
    border-bottom: 3px solid transparent;
    border-left: 3px solid transparent;
}
.buy_mini {
    line-height: 14px;
    height: 14px;
    font-size: 10px;
    padding: 0 6px;
    color: #fff;
    border-radius: 14px;
    background: -webkit-linear-gradient(left,#e93b3d,#fe9373);
    background: -webkit-gradient(linear,left top,right top,from(#e93b3d),to(#fe9373));
    background: linear-gradient(90deg,#e93b3d,#fe9373);
    box-shadow: 0 3px 6px rgba(233,59,61,.2);
    display: inline-block;
    vertical-align: middle;
    margin-top: 2px;
}
i,em{font-style:normal}
.intro_img{max-width:100%}
.intro_video{width:100%;background: #000000;}
.before_none:before{display: none !important}
.after_none:after{display: none !important}
.goods_status{
    overflow: hidden;
    position: absolute;
    top: 0;
    right: 0;
    width: 100%;
    height: 100%;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    background-position: 50%;
    background-repeat: no-repeat;
    background-size: auto 60%;
}
.goods_status.goods_status_end_1{
    background-color: rgba(0,0,0,.4);
    background-image: url(source/plugin/aljbd/images/common/wks.png);
}
.goods_status.goods_status_end_2{
    background-color: rgba(0,0,0,.4);
    background-image: url(source/plugin/aljbd/images/common/yjs.png);
}
.goods_status.goods_status_end_3{
    background-color: rgba(0,0,0,.4);
    background-image: url(source/plugin/aljbd/images/common/ysx.png);
}
.c_goods_size{position: relative;}
</style>
<?php if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false) { ?>
<style>
    body{
        -webkit-touch-callout: none;
        -webkit-user-select: none;
    }
</style>
<?php } ?>
<script>
function localStorage_set(key,v) {
    //����һ����������ؼ��ֵ�ʱ���ʱ���
    var currentTime = new Date().getTime();
    localStorage.setItem(key,JSON.stringify({data:v,time:currentTime}))
}
function localStorage_get (key, exp) {
    var data= localStorage.getItem(key);
    if(data == null){
        return 1;
    }
    var dataObj = JSON.parse(data);
    var currentTime = new Date().getTime();
    if(currentTime-dataObj.time >exp){
        console.log("\u8d85\u65f6\u4e86");
        return 1;
        //ҵ����
    }else {
        //ҵ����
        console.log(dataObj.data);
        return 0;
    }
}
</script>
<?php if($_G['cache']['plugin']['aljsfx_rt']['is_new_reward']) { include template('aljsfx_rt:aljbd/common'); } ?>
<style>
    
    .qr_code_pc_outer {
        display: none!important;
        position: fixed;
        left: 0;
        right: 0;
        top: 20px;
        color: #717375;
        text-align: center;
    }
    .qr_code_pc_inner {
        position: relative;
        width: 740px;
        margin-left: auto;
        margin-right: auto;
    }
    .qr_code_pc {
        -webkit-box-sizing: border-box;
        box-sizing: border-box;
    }
    .qr_code_pc {
        position: absolute;
        right: -140px;
        top: 0;
        width: 140px;
        padding: 16px;
        border: 1px solid #d9dadc;
        background-color: #fff;
        word-wrap: break-word;
        word-break: break-all;
    }
    .qr_code_pc_img {
        width: 102px;
        height: 102px;
        vertical-align: inherit;
    }
    .qr_code_pc p {
        font-size: 14px;
        line-height: 20px;
    }
    @media screen and (min-width: 1024px) {
        body, html,.sh_header,#topNav,.order-submitOrder,.weui-popup__container, .weui-popup__overlay,#view_entry_form,.weui-btn-area,.search_header,.footer_nav,.navbar-fixed-bottom,.cmNavBar,.tab-nav,#c_main_menu,.cart-concern-btm-fixed,.list_nav_l,.bar-tab,.header,.payment-bar,.weui-fixed,.weui-navbar,.fix-bottom,.aui-footer-fixed,.bottom_fixed,.couponCenterNavTwo,.footer_nav {
            width:640px !important;
            margin: 0 auto !important;
            left: auto !important;
            right:auto !important;
        }
        <?php if($_GET['id'] != 'aljwm') { ?>
        .search-bar:before, .sn-search-input:before, .sn-search-top input:before {
            left: 35px !important;
        }
        <?php } ?>
        .qr_code_pc_outer {
            display: block!important;
            top: 32px;
        }
        <?php if($_GET['id'] == 'aljthd') { ?>
        <?php if($_GET['a'] != 'post') { ?>
        html{font-size: 88px !important;}
        .event-details-banner-box .event-details-banner-bg,.event-details-banner-box .event-details-banner-filter,.event-details-banner-box{height:300px !important;max-height:300px !important;}
        .event-details-banner .banner-main{max-height:280px !important;}
        <?php } ?>
        <?php } ?>
    }
</style>
<div id="js_pc_qr_code" class="qr_code_pc_outer" style="display: block;">
    <div class="qr_code_pc_inner">
        <div class="qr_code_pc">
            <div id="js_pc_qr_code_img" ></div>
            <p><?php echo $navtitle;?></p>
        </div>
    </div>
</div>
<script>
    var l_href = location.href;
    l_href = l_href.replace(/&/g,'%26');
    console.log(l_href);
    $('#js_pc_qr_code_img').html('<img class="qr_code_pc_img" src="source/plugin/aljhtx/api/reg_qrcode.php?url='+l_href+'" />');
</script>
