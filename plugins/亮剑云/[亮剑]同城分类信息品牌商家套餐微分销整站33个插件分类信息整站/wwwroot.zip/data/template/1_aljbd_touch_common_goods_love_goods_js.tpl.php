<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); $ajax_url = 'plugin.php?id='.$pluginid.'&act=mobile_index_goods&mobilediy='.dhtmlspecialchars($_GET['mobilediy']).'&mobiledemomode='.dhtmlspecialchars($_GET['mobiledemomode']).$page_url?><script src="source/plugin/aljbd/js/sj/jquery.lazyload.min.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<script type="text/javascript">
    var than=2.8;
    var h = document.body.clientWidth/than;
    var b='addtime';
    <?php if(($settings['is_mobile_index_love_type']['value'] && !$config['is_mobile_index_love']) || $recommend == 'yes') { ?>
    var typeid='recommend';
    <?php } else { ?>
    var typeid='';
    <?php } ?>
    var page=1;
    var max=2;
    var isload = true;
    if(typeof keep_scrollheight == 'undefined'){
        var keep_scrollheight = 0;
    }
    jQuery(document).ready(function ($) {
        function lazyload(page) {
            console.log(page);
            //����ͼƬ�ӳټ���  ������Ļ100���ؿ�ʼ����ͼƬ
            $("img.lazy" + page).lazyload({
                effect: "fadeIn",
                placeholder: "<?php echo $loading;?>",
                threshold: 100,
                failure_limit : 20,
                skip_invisible: false
            });
        }
        function imgwidth(){

            <?php if($_G['cache']['plugin']['aljbd']['is_mobile_goods_size']) { ?>
            h = $(".c_goods_size").width();
            $('.c_img').css({'height':h+'px','width':h+'px','margin':'0 auto','display':'block'});
            <?php } else { ?>
            h = document.body.clientWidth/than;
            $('.c_goods_size').css({'height':h+'px','overflow':'hidden'});
            <?php } ?>

        }
        
        function xxx(){
            $(window).scroll(function(){
                
                if(isload){
                    // �жϴ��ڵĹ������Ƿ�ӽ�ҳ��ײ�
                    if( $(document).scrollTop() + $(window).height() >= $(document).height() - 10 ) {
                        if($('#max-page').val()){
                            max=$('#max-page').val();
                        }
                        page++;
                        isload = false;
                        if(page<=max){

                            ajaxgetdata();
                        }else{
                            $("#dataMore").hide();
                        }
                        // �ж���һҳ�����Ƿ�Ϊ��
                    }
                }
            });
        }
        function ajaxgetdata(swiper) {
            $("#dataMore").show();
            
            $.post('<?php echo $ajax_url;?>',{"order":b,'page':page,'typeid':typeid},function(data){
                if(data==0){
                    //console.log(data);
                    $("#dataMore").hide();
                    if(typeof swiper !== 'undefined'){
                        $("#dataList").html('<div class="c_click_see" id="more" style="float: left;">\u6ca1\u6709\u66f4\u591a\u6570\u636e</div>');
                    }else{
                        $("#dataList").append('<div class="c_click_see" id="more" style="float: left;">\u6ca1\u6709\u66f4\u591a\u6570\u636e</div>');
                    }
                    return false;
                }else{
                    if(typeof swiper !== 'undefined'){
                        $("#dataList").html(data);
                    }else{
                        $("#dataList").append(data);
                    }
                    isload = true;
                }
                setTimeout(keep_scroll_init,1000)
                
                $("#dataMore").hide();
                console.log('ajaxgetdata'+page);
                lazyload(page);
                imgwidth();
                <?php if($_GET['mobilediy'] != 'yes') { ?>
                xxx();
                <?php } ?>
            });
        }
        
        
        <?php if($settings['is_mobile_index_love_type']['value'] && !$config['is_mobile_index_love']) { ?>
            function swiper_keep(){
                var mySwiper = new Swiper('#topNav', {
                    freeMode: true,
                    freeModeMomentumRatio: 0.5,
                    slidesPerView: 'auto',

                });

                swiperWidth = mySwiper.container[0].clientWidth
                maxTranslate = mySwiper.maxTranslate();
                maxWidth = -maxTranslate + swiperWidth / 2


                mySwiper.on('tap', function(swiper, e) {

                    slide = swiper.slides[swiper.clickedIndex]
                    slideLeft = slide.offsetLeft
                    slideWidth = slide.clientWidth
                    slideCenter = slideLeft + slideWidth / 2
                    // !aljsq_htm_17!

                    mySwiper.setWrapperTransition(300)

                    if (slideCenter < swiperWidth / 2) {

                        mySwiper.setWrapperTranslate(0)

                    } else if (slideCenter > maxWidth) {

                        mySwiper.setWrapperTranslate(maxTranslate)

                    } else {

                        nowTlanslate = slideCenter - swiperWidth / 2

                        mySwiper.setWrapperTranslate(-nowTlanslate)

                    }

                    jQuery("#topNav .active").removeClass('active')

                    jQuery("#topNav .swiper-slide").eq(swiper.clickedIndex).addClass('active')
                    typeid=jQuery("#topNav .active").attr('val-data');
                    
                    page=1;
                    isload = false;
                    //jQuery("#dataList").html('');
                    console.log('topNav'+page);
                    
                    ajaxgetdata(1);
                    
                })
            }
            swiper_keep();
        <?php } ?>
        if (keep_scrollheight && sessionStorage.getItem(keep_page)) {
            //console.log(sessionStorage.getItem(keep_data));
            $('#guess').html(sessionStorage.getItem(keep_data));
            page = sessionStorage.getItem(keep_page);
            console.log('fy_'+page);
            typeid = sessionStorage.getItem(keep_typeid);
            if(page > 1){
                for (var i=1;i<page;i++)
                {
                    lazyload(i);
                }
            }else{
                lazyload(page);
            }
            
            <?php if($settings['is_mobile_index_love_type']['value'] && !$config['is_mobile_index_love']) { ?>
            swiper_keep();
            <?php } ?>
            $(document).scrollTop(sessionStorage.getItem(keep_scroll));
            topNavscroll();
            <?php if($_GET['mobilediy'] != 'yes') { ?>
                xxx();
            <?php } ?>
        } else {
            ajaxgetdata();
        }
        function topNavscroll(){
            <?php if($settings['is_mobile_index_love_type']['value']) { ?>
            $(document).on('touchmove',function(e) {
                $(window).scrollTop()>=$(".b_index_fixed1").offset().top?($("#topNav").css({position:"fixed",top:"<?php if(!$settings['is_lz_search']['value']) { ?>50<?php } else { ?>0<?php } ?>px",left:"0",zIndex:"149"})):($("#topNav").css({position:"relative",top:'0'}));
            })
            $(window).scroll(function(){
                $(window).scrollTop()>=$(".b_index_fixed1").offset().top?($("#topNav").css({position:"fixed",top:"<?php if(!$settings['is_lz_search']['value']) { ?>50<?php } else { ?>0<?php } ?>px",left:"0",zIndex:"149"})):($("#topNav").css({position:"relative",top:'0'}));
            })
            <?php } ?>
        }
        topNavscroll();
        function keep_scroll_init(){
            if (keep_scrollheight) {
                if(sessionStorage.getItem(keep_scroll) >= 500){
                    console.log('y1');
                    keep_url_md5 = $.md5(window.location.href);
                    keep_scroll = 'aljbd_' + keep_url_md5;
                    keep_page = 'keep_listpage_' + keep_url_md5;
                    keep_data = 'keep_listdata_' + keep_url_md5;
                    keep_typeid = 'keep_listtypeid_' + keep_url_md5;
                    sessionStorage.setItem(keep_scroll, $(window).scrollTop());
                    sessionStorage.setItem(keep_data, $('#guess').html());
                    sessionStorage.setItem(keep_page, page);
                    sessionStorage.setItem(keep_typeid, typeid);
                }else{
                    console.log('x1');
                    sessionStorage.removeItem(keep_page);
                    sessionStorage.removeItem(keep_data);
                    sessionStorage.removeItem(keep_scroll);
                    sessionStorage.removeItem(keep_typeid);
                }
                $(window).scroll(function(){
                    if ($(window).scrollTop() >= 500||sessionStorage.getItem(keep_scroll) >= 500) {
                        console.log('y');
                        sessionStorage.setItem(keep_scroll, $(window).scrollTop());
                        sessionStorage.setItem(keep_data, $('#guess').html());
                        sessionStorage.setItem(keep_page, page);
                        sessionStorage.setItem(keep_typeid, typeid);
                    }else{
                        console.log('x');
                        sessionStorage.removeItem(keep_page);
                        sessionStorage.removeItem(keep_data);
                        sessionStorage.removeItem(keep_scroll);
                        sessionStorage.removeItem(keep_typeid);
                    }
                });
            }
        }
        keep_scroll_init();
    });

</script>