<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($_G['cache']['plugin']['aljgwc']['aljol'] || $_G['cache']['plugin']['aljbdx']['aljol']) { ?>
<script>
    function openaljol(uid) {
        layer.open({
            type: 2
            ,offset: 'rb'
            ,title: '&#22312;&#32447;&#32842;&#22825;'
            ,area: ['414px', '80%']
            ,content: 'plugin.php?id=aljol&act=talk&friendid='+uid //iframe的url
            ,shade: 0 //不显示遮罩
        });
    }
</script>
<?php } ?>
<script>
function iframewuliu(orderid,kgs,number){
        //iframe窗

        layer.open({
            type: 2,
            title: '&#29289;&#27969;&#35814;&#24773;',
            shadeClose: true,
            shade: false,
            maxmin: true, //开启最大化最小化按钮
            area: ['570px', '470px'],
            content: 'plugin.php?id=aljht&act=admin&op=orderlist&do=logistics_details&kgs='+kgs+'&number='+number+'&orderid='+orderid
        });
    }
    function iframeorderview(orderid,url){
        //iframe窗
        var open_url = 'plugin.php?id=aljht&act=admin&op=orderlist&do=orderview&ord=<?php echo $ord;?><?php echo $urlmod;?>&orderid='+orderid;
        if(typeof url != 'undefined'){
            open_url = url+orderid;
        }
        layer.open({
            type: 2,
            title: '&#35746;&#21333;&#35814;&#24773;',
            shadeClose: true,
            shade: false,
            maxmin: true, //开启最大化最小化按钮
            area: ['70%', '80%'],
            content: open_url
        });
    }
    function iframecomment(orderid,gid){
        layer.closeAll('iframe'); //关闭所有的iframe层
        //iframe窗
        layer.open({
            type: 2,
            title: '<?php echo $aljhtlang['js']['orderview_2'];?>',
            shadeClose: true,
            shade: false,
            maxmin: true, //开启最大化最小化按钮
            area: ['470px', '670px'],
            content: 'plugin.php?id=aljht&act=admin&op=orderlist&do=comment<?php echo $urlmod;?>&gid='+gid+'&orderid='+orderid
        });
    }
</script><?php include template('aljht:admin/orderlist/order_common_js'); ?>