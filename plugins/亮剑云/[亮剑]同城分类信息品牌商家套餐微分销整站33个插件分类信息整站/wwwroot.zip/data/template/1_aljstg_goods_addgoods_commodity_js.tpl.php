<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
$(".price1").text('<?php echo $_G['cache']['plugin']['aljstg']['aljstg_name'];?>价格');
$(".starttime").show();
$(".endtime").show();
$(".gwurl").hide();
$(".category").hide();
$("#category").html('<input type="hidden" name="category" value="1" >');
$(".price1").next().attr("placeholder","<?php echo $_G['cache']['plugin']['aljstg']['aljstg_name'];?>价格");
$(".collage_num").hide();
$(".collage_price").hide();