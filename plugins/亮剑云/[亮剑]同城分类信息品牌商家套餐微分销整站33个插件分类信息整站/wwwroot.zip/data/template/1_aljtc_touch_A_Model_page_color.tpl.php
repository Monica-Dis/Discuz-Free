<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($color) { ?>
<style>
    #topNav .active span {
        color: <?php echo $color;?>!important;
    }
    #topNav .active span:after {
        background: <?php echo $color;?>!important;
    }
    .clolorblue {
        color: <?php echo $color;?>!important;
    }
    #c_main_menu .c_menu_this span {
        color: <?php echo $color;?>!important;
    }
    #c_main_menu .c_menu_this b {
        color: <?php echo $color;?>!important;
    }
    .post-i {
       color: <?php echo $color;?>!important;
    }
    .swiper-pagination-bullet-active {
        background: <?php echo $color;?>!important;
    }
    .weui-btn_primary, .weui-switch:checked {
        background-color: <?php echo $color;?>!important;
    }
    .hot-top-row .hot-top span {
        color: <?php echo $color;?>!important;
    }
    .layui-m-layerbtn span[yes] {
        color: <?php echo $color;?>!important;
    }
    .weui_bar__item_on span {
        color: <?php echo $color;?>!important;
    }
    .weui_bar__item_on span:after {
        background: <?php echo $color;?>!important;
    }
    .tag-on {
        background-color: <?php echo $color;?>!important;
    }
    .color-header {
        background: <?php echo $color;?>!important;
    }
    .swiper-pagination-bullet-active {
        opacity: 1;
        background: <?php echo $color;?>!important;
        width: 12px;
        border-radius: 2px;
        height: 4px;
    }
    .timeline-li-detail .detail-message .message-p span {
        background: <?php echo $color;?>!important;
    }
    .timeline-li-detail .detail-message .view-p span {
        background: <?php echo $color;?>!important;
    }
    .weui-btn_warn {
        background-color: <?php echo $color;?>!important;
        border-radius: 30px;
    }
    .weui-cell-count__bd span{
        color:<?php echo $color;?> !important;
    }
    
    .change-tab .buttons-tab .button.active span {
        background: <?php echo $color;?> !important;
    }
    .sq-hot>div>p>span {
      color: <?php echo $color;?> !important;
    }
    .sq-hot>div>a{background: <?php echo $color;?> !important;}
    .hot-top-row .swiper-slide span{color:<?php echo $color;?> !important;margin-right: 5px;}
    .top-view-p span {

        background: <?php echo $color;?> !important;

    }
    
    .detail-call i {
        color: <?php echo $color;?> !important;
    }
    .weui-icon-success {
        color: <?php echo $color;?> !important;
    }
    .set_icon{color: <?php echo $color;?> !important;}
    .weui-vcode-btn {
        color: <?php echo $color;?> !important;
    }
    .weui-icon-success {
        color: <?php echo $color;?> !important;
    }
    .weui-dialog__btn{
        color: <?php echo $color;?> ;
    }
</style>
<?php } ?>

<style>
    
    .qr_code_pc_outer {
        display: none!important;
        position: fixed;
        left: 0;
        right: 0;
        top: 20px;
        color: #717375;
        text-align: center;
    }
    .qr_code_pc_inner {
        position: relative;
        width: 740px;
        margin-left: auto;
        margin-right: auto;
    }
    .qr_code_pc {
        -webkit-box-sizing: border-box;
        box-sizing: border-box;
    }
    .qr_code_pc {
        position: absolute;
        right: -140px;
        top: 0;
        width: 140px;
        padding: 16px;
        border: 1px solid #d9dadc;
        background-color: #fff;
        word-wrap: break-word;
        word-break: break-all;
    }
    .qr_code_pc_img {
        width: 102px;
        height: 102px;
        vertical-align: inherit;
    }
    .qr_code_pc p {
        font-size: 14px;
        line-height: 20px;
    }
    @media screen and (min-width: 1024px) {
        body, html,.sh_header,.aljyzm_dialog,.order-submitOrder,#topNav,.weui-popup__container,#J_tabContent, .weui-popup__overlay,#view_entry_form,.weui-btn-area,.search_header,.footer_nav,.navbar-fixed-bottom,.cmNavBar,#c_main_menu,.cart-concern-btm-fixed,.list_nav_l,.bar-tab,.header,.payment-bar,.weui-fixed,.weui-navbar,.fix-bottom,.aui-footer-fixed,.bottom_fixed,.couponCenterNavTwo,.footer_nav {
            width:640px !important;
            margin: 0 auto !important;
            left: auto !important;
            right:auto !important;
        }
        <?php if($_GET['id'] != 'aljtsc' && $_GET['a'] != 'type') { ?>
        .tab-nav{
            width:640px !important;
            margin: 0 auto !important;
            left: auto !important;
            right:auto !important;
        }
        <?php } ?>
        <?php if($_GET['id'] != 'aljwm' && $_GET['id'] != 'aljtsc' && $_GET['a'] != 'type') { ?>
        .search-bar:before, .sn-search-input:before, .sn-search-top input:before {
            left: 35px !important;
        }
        <?php } ?>
        .qr_code_pc_outer {
            display: block!important;
            top: 32px;
        }
        <?php if($_GET['id'] == 'aljthd') { ?>
        <?php if($_GET['a'] != 'post') { ?>
        html{font-size: 88px !important;}
        .event-details-banner-box .event-details-banner-bg,.event-details-banner-box .event-details-banner-filter,.event-details-banner-box{height:300px !important;max-height:300px !important;}
        .event-details-banner .banner-main{max-height:280px !important;}
        <?php } ?>
        <?php } ?>
    }
</style>
<div id="js_pc_qr_code" class="qr_code_pc_outer" style="display: block;">
    <div class="qr_code_pc_inner">
        <div class="qr_code_pc">
            <div id="js_pc_qr_code_img" ></div>
            <p><?php echo $navtitle;?></p>
        </div>
    </div>
</div>
<script>
    var l_href = location.href;
    l_href = l_href.replace(/&/g,'%26');
    console.log(l_href);
    $('#js_pc_qr_code_img').html('<img class="qr_code_pc_img" src="source/plugin/aljhtx/api/reg_qrcode.php?url='+l_href+'" />');
</script>
<style>
.weui-actionsheet .weui-actionsheet__title {
    height: auto!important;
    padding: 10px 0;
    text-align: center;
    font-size: 16px;
    color: #999;
    background-color: #f4f4f4;
    position: relative;
}
.pay_btn{
font-size: 12px;color:#ffffff;margin-right: 10px;border-radius: 5px;width:auto;height:22px;padding:2px 10px;top: 4px;
background:<?php if($color) { ?><?php echo $color;?><?php } else { ?>red<?php } ?>;
}
.all-btn{
position: absolute;
    left: 0px;
    top: 60px;
    width: 42px;
    padding-left: 8px;
}
.all-btn a.weui-btn {
    width: 42px;
    height: 26px;
    line-height: 26px;
    background-color: #fff!important;
    color: #666!important;
padding:0px;
margin:0px;
}
.all-btn .weui-btn + .weui-btn {
    margin-top: 0px;
}
.tc_end_i {
    position: absolute;
    font-size: 60px;
    right: 5%;
    top: 25%;
    color: #666 !important;
    z-index: 5;
}
.ocy7{opacity: .7;}
</style>
<?php if($_G['cache']['plugin']['aljtc']['no_data_img']) { ?>
<style>
    .empty_data{background: url(<?php echo $_G['cache']['plugin']['aljtc']['no_data_img'];?>) no-repeat center;background-size: 200px;}
</style>
<?php } ?>