<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div class="hot">
<div class="lj_left">
<a href="<?php echo $mobile_index_ad_arr['0']['1'];?>" ><img src="<?php echo $mobile_index_ad_arr['0']['0'];?>"></a>
</div>
<div class="lj_right">
<a href="<?php echo $mobile_index_ad_arr['1']['1'];?>" ><img src="<?php echo $mobile_index_ad_arr['1']['0'];?>" alt=""></a>
<?php if($settings['mobile_index_ad_px']['value']) { ?>
<div style="display:block;height:<?php echo $settings['mobile_index_ad_px']['value'];?>px;"></div>
<?php } else { ?>
<div style="display:block;height:5px;"></div>
<?php } ?>
<a href="<?php echo $mobile_index_ad_arr['2']['1'];?>" ><img src="<?php echo $mobile_index_ad_arr['2']['0'];?>" alt=""></a>
</div>
</div>
<div class="line-5"></div>