<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>

    发布信息:&nbsp;
    <?php if($price>0) { ?>
        <span class="color-red">
                <?php echo $price;?>元 / 条
        </span>
        ,&nbsp;&#26377;&#25928;&#26399;&#65306;<?php if($expiry_time_day>0) { ?><span class="color-red"><?php echo $expiry_time_day;?>&#22825;</span><?php } else { ?>&#27704;&#20037;<?php } ?>
        ,&nbsp;我的余额:&nbsp;<span class="color-red"><?php echo $my_price;?>元 </span><a href="plugin.php?id=aljqb&amp;act=recharge" style="padding:2px 10px;background: #f42424;color:#ffffff;border-radius: 10px;font-size: 12px;border: 1px solid #f42424;margin-left: 5px;display: inline-block;height: 20px;line-height: 15px;">充值</a>
    <?php } else { ?>
        <?php if($settings['releasepay']['value']) { ?>
        <span class="color-red">
            <?php echo $settings['releasepay']['value'];?> <?php echo $_G['setting']['extcredits'][$settings['releaseextcredit']['value']]['title'];?> / 条
        </span>
        <?php } else { ?>
        免费
        <?php } ?>
        <?php $ext_yes?>        <?php if(1) { ?>
        ,&nbsp;&#26377;&#25928;&#26399;&#65306;<?php if($expiry_time_day>0) { ?><span class="color-red"><?php echo $expiry_time_day;?>&#22825;</span><?php } else { ?>&#27704;&#20037;<?php } ?>
        ,&nbsp;我的<?php echo $_G['setting']['extcredits'][$settings['releaseextcredit']['value']]['title'];?>:&nbsp;<span class="color-red"><?php echo getuserprofile('extcredits' . $settings['releaseextcredit']['value'])?> </span>
        
            <?php if($mobile_integral_recharge) { ?>
                <a href="<?php echo $mobile_integral_recharge;?>" style="padding:2px 10px;background: #f42424;color:#ffffff;border-radius: 10px;font-size: 12px;border: 1px solid #f42424;margin-left: 5px;display: inline-block;height: 20px;line-height: 15px;">充值</a>
            <?php } ?>
        <?php } ?>
    <?php } ?>
    
