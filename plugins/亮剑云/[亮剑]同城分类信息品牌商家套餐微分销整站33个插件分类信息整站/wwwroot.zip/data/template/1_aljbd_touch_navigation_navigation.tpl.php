<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($config ['sj_index_dh']) { ?>
<link rel="stylesheet" media="screen,projection,tv" href="source/plugin/<?php echo $pluginid;?>/template/touch/navigation/navigation.css" /></link>
<div class="s_index_icon  swiper-container-horizontal diyDocument" diy-id="swiper-container-horizontal" id="navigation" style="background: #ffffff;padding:0px">
    <div class="swiper-wrapper" id="c_main_Prefecture" style="padding:10px 0px 0px 0px;">
        <!-- ͼƬ���� -->
        <ul class="s_index_ul swiper-slide " style="display:block;">
        <?php if(is_array($sj_index_dh_types)) foreach($sj_index_dh_types as $k => $v) { ?>            <?php if($k && $k%10==0) { ?>
                </ul>
                <ul class="s_index_ul swiper-slide" >
            <?php } ?>
            <li >
                <a class="navigateTo" href="<?php echo $v['1'];?>">
                    <img src="<?php echo $v['2'];?>">
                    <em style="font-style: normal;"><?php echo $v['0'];?></em>
                </a>
            </li>
        <?php } ?>
        </ul>
    </div>
</div>
<?php } ?>
