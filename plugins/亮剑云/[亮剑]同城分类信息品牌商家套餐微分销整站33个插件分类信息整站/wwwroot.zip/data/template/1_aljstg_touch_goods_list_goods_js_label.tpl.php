<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
if(val.commodity_type == 1) {
html += '<span class="xf_laber"><?php echo $_G['cache']['plugin']['aljstg']['aljstg_name'];?></span>';
}