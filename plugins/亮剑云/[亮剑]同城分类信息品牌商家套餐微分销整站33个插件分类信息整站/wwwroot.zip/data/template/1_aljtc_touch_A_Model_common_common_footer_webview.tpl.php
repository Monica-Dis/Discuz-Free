<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<script>
jQuery(document).on('click', '.navigateTo', function () {
    //alert(jQuery(this).attr('href'));
    var webVUrl = jQuery(this).attr('href');
    if (isWeiXin() && webVUrl != 'javascript:;' && webVUrl != 'javascript:void(0)') {
        if (typeof wx !== 'undefined') {
            if (window.__wxjs_environment === 'miniprogram') {
                miniProgramwebview(webVUrl);
                return false;
            }
        }
    }
});
jQuery(document).on('click', '.redirectTo', function () {
    //alert(jQuery(this).attr('href'));
    var webVUrl = jQuery(this).attr('href');
    if (isWeiXin() && webVUrl != 'javascript:;' && webVUrl != 'javascript:void(0)') {
        if (typeof wx !== 'undefined') {
            if (window.__wxjs_environment === 'miniprogram') {
                miniProgramwebviewredirectTo(webVUrl);
                return false;
            }
        }
    }
});

function isWeiXin() {
    var ua = window.navigator.userAgent.toLowerCase();
    if (ua.match(/MicroMessenger/i) == 'micromessenger') {
        return true;
    } else {
        return false;
    }
}
function miniProgramwebview(url){
    var path = '/pages/index/index?webVUrl=' + encodeURIComponent(url);
    wx.miniProgram.navigateTo({
        url: path
    });
}
function miniProgramwebviewredirectTo(url){
    var path = '/pages/index/index?webVUrl=' + encodeURIComponent(url);
    wx.miniProgram.redirectTo({
        url: path
    });
}
</script>