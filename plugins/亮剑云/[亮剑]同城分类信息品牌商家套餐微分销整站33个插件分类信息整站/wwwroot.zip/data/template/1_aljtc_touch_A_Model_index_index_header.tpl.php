<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<style>
.cmNavBar>.cmNavBarLeft .cmBtnWrapper, .cmNavBar>.cmNavBarLeft.cmBtnWrapper {
    padding-left: 15px;
    height:44px;
    overflow: hidden;
}
.w-headMenu i{padding-left: 5px;font-size: 13px;position: relative;top: -1px;}
</style>
<?php if($_G['cache']['plugin']['aljtc']['index_search_line']) { ?>
<style>
.search-span{
    float: left;
    font-size: 14px;
    color:#999;
    white-space: nowrap;
    width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
   }
   .search-a{
    background: #ffffff;overflow: hidden;display: block;position: relative;flex: 1;
   }
   .weui-flex .site-a{
    padding-left: 10px;
    display: block;
    margin: 0 0 0 5px;
    font-size: 14px;
   }
   .weui-flex .site-a i{vertical-align: middle;font-size: 13px;
    margin-left: 5px;}
   .search_header{
    width: 100%;
    height: 50px;
    line-height: 50px;
    text-align: center;
    color: #fff;
    font-size: 16px;
    overflow: hidden;
    background: #ffffff;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 501;
   }
   .mr5{margin-right:5px;}
   .mr10{margin-right:10px;}
   .ml10{margin-left:10px;}
   .weui-cell-count-aljtc{
    padding: 0px 10px;
    position: relative;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    height: 32px;
    line-height: 32px;
    margin-top: 9px;
   }
   .page_bg_card_pd {
    padding: 0px 10px !important;
}
.page_bg_none {
    background: none !important;
}
.page_bg_card_br {
    border-radius: 10px;
    display: block;
    overflow: hidden;
}
.a_banner{background: #ffffff;}
<?php if($_G['cache']['plugin']['aljtc']['index_page_bg']) { ?>
.a_banner{background: none;}
.search_banner{background: #ffffff url(<?php echo $_G['cache']['plugin']['aljtc']['index_page_bg'];?>) no-repeat;background-size: 100% auto;}
.search_header{background: none}
.search-a{background: none !important;}
.site-a{color:#ffffff;}
<?php } ?>
</style>
<div class="weui-flex search_header">
    
    <?php if($_G['cache']['plugin']['aljtfz']['site_show']) { ?>
    <a class="site-a" href="plugin.php?id=aljtfz<?php if($_G['cookie']['fz_id']) { ?>&amp;fz_id=<?php echo $_G['cookie']['fz_id'];?><?php } ?>">
        <?php echo $city_info['name']?$city_info['name']:$_G['cache']['plugin']['aljtfz']['city_name']; ?><i class="iconfont icon-xiangxia"></i>
    </a>
    <?php } else { ?>
        <?php if($settings['is_more_city']['value']) { ?>
        <a class="site-a" href="javascript:;" onclick="clickarea(this)">
            <?php if($_COOKIE['rname']) { ?><?php echo $_COOKIE['rname'];?><?php } else { ?>&#22320;&#21306;<?php } ?><i class="iconfont icon-xiangxia"></i>
        </a>
        <?php } ?>
    <?php } ?>
    
  <a  class=" search-a" href="plugin.php?id=aljtc&amp;act=search">
    <div class="weui-cell-count-aljtc mr10 ml10" style="background: #f5f5f5;border-radius: 10px;">
        <span  class="search-span"><i class="iconfont icon-sousuo" style="margin-top: -4px;font-size: 16px;margin-right: 5px;"></i><?php if($settings['index_search_tips']['value']) { ?><?php echo $settings['index_search_tips']['value'];?><?php } else { ?>找工作、找房子、找顺风车<?php } ?></span>
    </div>
    </a>
</div>
<div style="height:50px;overflow: hidden;display: block;"></div>
<?php if($_G['cache']['plugin']['aljtc']['index_page_bg']) { ?>
<script>
    function aljtc_header(){

        $(document).on('touchmove',function(e) {
            if($(window).scrollTop()>=5){
                $(".search_header").css({position:"fixed",top:"0",left:"0",height:'50px',background:"<?php if($color) { ?><?php echo $color;?><?php } else { ?>#f42424<?php } ?>"})
            }
        })
        $(window).scroll(function(){
            if($(window).scrollTop()<=5){
                $(".search_header").css({position:"absolute",height:'<?php echo 54+$immersed;?>px',background:'none'})
                
            }else if($(window).scrollTop()>=5){
                $(".search_header").css({position:"fixed",top:"0",left:"0",height:'50px',background:"<?php if($color) { ?><?php echo $color;?><?php } else { ?>#f42424<?php } ?>"})
            }
        })
    }
    $(function(){
        aljtc_header();
    });
</script>
<?php } } else { ?>
<header>
    <nav class="cmNavBar global-header">
        <h1 style="color:#ffffff;margin-right: 0%;line-height: 40px;"><div class="wbox-flex search-bar pr">
            <a name="index_none_header_sysc" class="new_search" href="plugin.php?id=aljtc&amp;act=search"></a>
            <form><input id="searchInput" name="index_none_header_sysc" type="text" placeholder="<?php if($settings['index_search_tips']['value']) { ?><?php echo $settings['index_search_tips']['value'];?><?php } else { ?>找工作、找房子、找顺风车<?php } ?>" autocomplete="off"></form>
        </div></h1>
        <div class="cmBtnWrapper cmNavBarLeft" style="padding-top:0px;">
            <?php if($_G['cache']['plugin']['aljtfz']['site_show']) { ?>
                <a class="w-headMenu" href="plugin.php?id=aljtfz<?php if($_G['cookie']['fz_id']) { ?>&amp;fz_id=<?php echo $_G['cookie']['fz_id'];?><?php } ?>" style="color:#fff" >
                    <?php echo $city_info['name']?$city_info['name']:$_G['cache']['plugin']['aljtfz']['city_name']; ?><i class="iconfont icon-xiangxia"></i>
                </a>
            <?php } else { ?>
                <?php if($settings['is_more_city']['value']) { ?>
                <a class="w-headMenu" href="javascript:;" style="color:#fff" onclick="clickarea(this)">
                    <?php if($_COOKIE['rname']) { ?><?php echo $_COOKIE['rname'];?><?php } else { ?>&#22320;&#21306;<?php } ?><i class="iconfont icon-xiangxia"></i>
                </a>
                <?php } ?>
            <?php } ?>
        </div>
    </nav>
</header>
<?php } ?>
