<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($settings['is_lazyload']['value']) { ?>

<script type="text/javascript">
    jQuery(document).ready(function ($) {
        $("img").lazyload({
            placeholder : "<?php echo $loading;?>",
            effect: "fadeIn",
            threshold: 100,
            failure_limit : 50,
            skip_invisible: false
        });
    });
</script>
<?php } ?>
<script type="text/javascript">
    <?php if($isappbyme || $ismagapp || $isqianfanapp) { ?>
        <?php if($settings['hidetop']['value']==1) { ?>
        $('header').hide();
        $('li header').show();
        <?php } ?>
        <?php if($settings['hidebottom']['value']==1) { ?>
        $('footer').hide();
        $('.footermenu').hide();
        <?php } ?>
    <?php } ?>
</script>
<style type="text/css">
    .u_top {
        border-radius: 50%;
        bottom: 58px;
        display: none;
        height: 40px;
        opacity: 0.5;
        position: fixed;
        right: 10px;
        width: 40px;
        z-index: 50;
        background: #888 url("source/plugin/<?php echo $pluginid;?>/images/sj/deta_15.png") no-repeat center center;
        background-size: 18px;
    }
    .u_post {
        border-radius: 50%;
        bottom: 108px;
        display: block;
        height: 40px;
        opacity: 0.3;
        position: fixed;
        right: 10px;
        width: 40px;
        z-index: 50;
        background: #000 url("source/plugin/<?php echo $pluginid;?>/images/sj/edit.png") no-repeat center center;
        background-size: 18px;
    }
    .u_search {
        border-radius: 50%;
        bottom: 158px;
        display: block;
        height: 40px;
        opacity: 0.5;
        position: fixed;
        right: 10px;
        width: 40px;
        z-index: 50;
        background: #888 url("source/plugin/<?php echo $pluginid;?>/images/sj/search_v.png") no-repeat center center;
        background-size: 18px;
    }

    .u_user {
        border-radius: 50%;
        bottom: 208px;
        display: block;
        height: 40px;
        opacity: 0.3;
        position: fixed;
        right: 10px;
        width: 40px;
        z-index: 50;
        background: #000 url("source/plugin/<?php echo $pluginid;?>/images/sj/avatar.png") no-repeat center center;
        background-size: 18px;
    }
    .u_index {
        border-radius: 50%;
        bottom: 258px;
        display: block;
        height: 40px;
        opacity: 0.4;
        position: fixed;
        right: 10px;
        width: 40px;
        z-index: 50;
        background:#000 url("source/plugin/<?php echo $pluginid;?>/images/sj/index_v.png") no-repeat center center;
        background-size: 18px;
    }
    @supports (bottom: constant(safe-area-inset-bottom)) or (bottom: env(safe-area-inset-bottom)) {
        .u_top{
            bottom: calc(58px + constant(safe-area-inset-bottom));
            bottom: calc(58px + env(safe-area-inset-bottom));
        }
        .u_post{
            bottom: calc(108px + constant(safe-area-inset-bottom));
            bottom: calc(108px + env(safe-area-inset-bottom));
        }
        .u_search{
            bottom: calc(158px + constant(safe-area-inset-bottom));
            bottom: calc(158px + env(safe-area-inset-bottom));
        }
        .u_user{
            bottom: calc(208px + constant(safe-area-inset-bottom));
            bottom: calc(208px + env(safe-area-inset-bottom));
        }
        .u_index{
            bottom: calc(258px + constant(safe-area-inset-bottom));
            bottom: calc(258px + env(safe-area-inset-bottom));
        }
    }
</style>

<?php if(!$settings['is_mobile_suspension']['value']) { if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0) { ?>
<a class="u_user"  href="plugin.php?id=<?php echo $pluginid;?>&amp;act=user" ></a>
<a class="u_index" href="plugin.php?id=<?php echo $pluginid;?>"></a>
<?php } if(($_GET['act'] == 'dianpu' || $_GET['act'] == 'goods') && $settings['is_type_bg']['value']==1) { if(file_exists("source/plugin/dcdz/dcdz.inc.php")) { ?>
<a class="u_search"  id="u_search" ></a>
<script type="text/javascript">
    $(function() {
        $("#u_search").click(function(){
            if($(".search").css("display")=="none"){
                $(".search").show();
            }else{
                $(".search").hide();
            }
        });
    });
</script>
<?php } else { ?>
<a class="u_search"  href="plugin.php?id=aljbd&amp;act=search" ></a>
<?php } } if(!$_G['cache']['plugin']['aljbd']['sj_index_lz']) { ?>
<a class="u_post"  href="plugin.php?id=<?php echo $pluginid;?>&amp;act=attend" ></a>
<?php } } ?>
<a class="u_top" target="_self"  style="display: none;"></a>
<script type="text/javascript">
    
    function backTop() {
        $(window).scroll(function() {
            if ($(window).scrollTop() > ($(window).height() * 0.5)) {
                $(".u_top").fadeIn(500);
                
            } else {
                $(".u_top").fadeOut(500);
                
            }
            
            if($('.menubar').length>0){
                if($('.menubar').hasClass('openright')) {
                    $('.menubar').removeClass('openright').addClass('openleft');
                }
            }
            if($(".menu-list").css("display")=="block"){
                $(".menu-list").hide();
            }
        });
        $(".u_top").click(function() {
            $('body,html').animate({
                scrollTop: 0
            }, 1000);
            return false;
        });
    }
    $(function() {
        backTop();
    });
    <?php if($_GET['id']!='aljgwc' && $_GET['id']!='aljbdx') { ?>
    function tips(txt, fun) {
        $('.tips').remove();
        var div = $('<div style="background: url(source/plugin/aljbd/images/tips.png);max-width: 85%;min-height: 77px;min-width: 270px;position: absolute;left: -1000px;top: -1000px;text-align: center;border-radius:10px;"><span style="color: #ffffff;line-height: 77px;font-size: 23px;">' + txt + '</span></div>');
        $('body').append(div);
        div.css('zIndex', 999999999999);
        div.css('left', parseInt(($(window).width() - div.width()) / 2));
        var top = parseInt($(window).scrollTop() + ($(window).height() - div.height()) / 2);
        div.css('top', top);
        setTimeout(function() {
            div.remove();
            if (fun) {
                fun();
            }
        }, 2000);
    }
    <?php } ?>
    
</script><?php include template('aljbd:common/common_footer_webview'); ?><script src="source/plugin/aljbd/js/jquery.sticky.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<script>
    
    <?php if($_GET['act']=='goods' && 0) { ?>
        <?php if($yes_header) { ?>
            $(".panel-comm").sticky({
                top: "-1px",
                topSpacing:'44px',
                zIndex: 200
            });
        <?php } else { ?>
            $(".panel-comm").sticky({
                top: "-1px",
                zIndex: 200
            });
        <?php } ?>
    <?php } ?>
    <?php if($_GET['id']=='aljsd') { ?>
    $(".couponCenterNavTwo").sticky({
        top: "-1px",
        zIndex: 200,
        display: 'block',
    });
    <?php } ?>
</script>

<?php if($_G['cache']['plugin']['aljhtx']) { include template('aljhtx:common_footer'); } if($_G['cache']['plugin']['aljhb'] && $_GET['id']!='aljgwc' && ($_GET['act']=='member' || $_GET['act']=='goodslist' || $_GET['act']=='noticelist' || $_GET['act']=='consumelist' || $_GET['act']=='consumeview' || $_GET['act']=='noticeview' || $_GET['act']=='goodslist' || $_GET['act']=='view') && $cparray['aljhb']['available'] == 1) { include template('aljhb:red_packet'); } if(file_exists('source/plugin/mapp_share/api/api.php') && $_G['cache']['plugin']['mapp_share']) { include template('mapp_share:api'); } elseif($_G['cache']['plugin']['aljwx']) { include template('aljwx:share_new'); } include template('aljbd:common/p_footer'); if($_G['cache']['plugin']['ljqq'] && 0) { include_once DISCUZ_ROOT.'source/plugin/ljqq/ljqq.class.php';
$ljqq = mobileplugin_ljqq::global_footer_mobile();
echo $ljqq;?><?php } ?>
