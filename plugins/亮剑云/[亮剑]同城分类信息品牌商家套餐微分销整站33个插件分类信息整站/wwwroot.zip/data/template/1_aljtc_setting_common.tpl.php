<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<tr ><th class="partition" colspan="15" >&#20840;&#23616;&#35774;&#32622;&#39033;</th></tr>

<tr><td s="1" class="td27" colspan="2">&#20449;&#24687;&#27969;&#22836;&#20687;&#19979;&#26041;&#26174;&#31034;&#25805;&#20316;&#25353;&#38062;</td></tr>
<tr class="noborder">
    <td class="vtop rowform" s="1">
        <ul onmouseover="altStyle(this);">
            <li class="checked"><input type="radio"  value="1"  <?php if($settings['is_head_btn']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[is_head_btn]" class="radio">&nbsp;&#26159;</li>
            <li><input type="radio" value="0" <?php if($settings['is_head_btn']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[is_head_btn]" class="radio">&nbsp;&#21542;</li>
        </ul>
        <br></td>
        <td>&#20449;&#24687;&#26159;&#26412;&#20154;&#25110;&#31649;&#29702;&#21592;&#26102;&#20449;&#24687;&#27969;&#22836;&#20687;&#19979;&#26041;&#26174;&#31034;&#25805;&#20316;&#25353;&#38062;</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#31215;&#20998;&#20805;&#20540;&#38142;&#25509;</td></tr>
<tr onmouseover="setfaq(this, 'faqe889')" class="noborder"><td class="vtop rowform">
    <input type="text" class="txt" value="<?php echo $settings['mobile_integral_recharge']['value'];?>" name="settingsnew[mobile_integral_recharge]"></td>
    <td s="1" class="vtop tips2">&#35831;&#22635;&#20889;&#31215;&#20998;&#20805;&#20540;&#38142;&#25509;&#65292;&#19981;&#22635;&#20889;&#19981;&#35843;&#29992;</td>
</tr>

<tr><td s="1" class="td27" colspan="2">&#31215;&#20998;&#20805;&#20540;&#25551;&#36848;</td></tr>
<tr onmouseover="setfaq(this, 'faqe889')" class="noborder">
    <td class="vtop rowform">
        <textarea class="tarea" cols="50"  name="settingsnew[mobile_integral_recharge_desc]" onkeydown="textareakey(this, event)" id="varsnew[mobile_integral_recharge_desc]"  ondblclick="textareasize(this, 1)" rows="6"><?php echo $settings['mobile_integral_recharge_desc']['value'];?></textarea>
    </td>
    <td s="1" class="vtop tips2">&#25903;&#25345;&#104;&#116;&#109;&#108;&#65292;&#26174;&#31034;&#22312;&#31215;&#20998;&#20805;&#20540;&#25353;&#38062;&#19979;&#26041;&#65292;&#24517;&#39035;&#22635;&#20889;&#25163;&#26426;&#31215;&#20998;&#20805;&#20540;&#38142;&#25509;</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#24213;&#37096;&#23548;&#33322;</td></tr>
<tr onmouseover="setfaq(this, 'faqe889')" class="noborder">
    <td class="vtop rowform">
        <textarea class="tarea" cols="50"  name="settingsnew[mobile_footer_nav]" onkeydown="textareakey(this, event)" id="varsnew[mobile_footer_nav]"  ondblclick="textareasize(this, 1)" rows="6"><?php echo $settings['mobile_footer_nav']['value'];?></textarea>
    </td>
    <td s="1" class="vtop tips2">
            &#26684;&#24335;&#65306;&#36873;&#20013;&#22270;&#26631;&#124;&#26410;&#36873;&#20013;&#22270;&#26631;&#124;&#25991;&#23383;&#124;&#38142;&#25509;&#124;&#26159;&#21542;&#31361;&#36215;&#40;&#49;&#61;&#31361;&#36215;&#44;&#48;&#61;&#19981;&#31361;&#36215;&#41;<br/>
            &#19968;&#34892;&#19968;&#20010;<br/>
            &#22914;&#65306;<br/>
        source/plugin/aljtc/static/img/index1.png|source/plugin/aljtc/static/img/index.png|&#39318;&#39029;|plugin.php?id=aljtc<br/>
        source/plugin/aljtc/static/img/brand1.png|source/plugin/aljtc/static/img/brand.png|&#21830;&#22280;|plugin.php?id=aljtsq<br/>
        source/plugin/aljtc/static/img/post1.png|source/plugin/aljtc/static/img/post.png|&#21457;&#24067;|plugin.php?id=aljtc&act=posttype|1<br/>
        source/plugin/aljtc/static/img/search1.png|source/plugin/aljtc/static/img/search.png|&#25628;&#32034;|plugin.php?id=aljtc&act=search<br/>
        source/plugin/aljtc/static/img/my1.png|source/plugin/aljtc/static/img/my.png|&#25105;&#30340;|plugin.php?id=aljtc&act=user<br/>
    </td>
</tr>

<tr><td s="1" class="td27" colspan="2">&#25554;&#20214;&#22270;&#29255;&#23384;&#25918;&#20301;&#32622;</td></tr>
<tr onmouseover="setfaq(this, 'faqe889')" class="noborder"><td class="vtop rowform">
    <input type="text" class="txt" value="<?php echo $settings['image_path']['value'];?>" name="settingsnew[image_path]"></td>
    <td s="1" class="vtop tips2">&#19981;&#22635;&#20889;&#35843;&#29992;&#40664;&#35748;&#65292;&#40664;&#35748;&#36335;&#24452;&#65306;source/plugin/aljtc/images/logo/<br/>&#20197;&#47;&#32467;&#23614;&#44;&#25991;&#20214;&#22841;&#24517;&#39035;&#23384;&#22312;</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#22270;&#29255;&#19978;&#20256;&#21387;&#32553;&#23485;&#24230;</td></tr>
<tr onmouseover="setfaq(this, 'faq1e8e')" class="noborder"><td class="vtop rowform">
    <input type="text" class="txt" value="<?php echo $settings['uploadwidth']['value'];?>" name="settingsnew[uploadwidth]"></td><td s="1" class="vtop tips2">&#40664;&#35748;&#23485;&#24230;&#65306;&#49;&#48;&#48;&#48;</td></tr>

<tr><td s="1" class="td27" colspan="2">&#20840;&#23616;&#37197;&#33394;</td></tr>
<tr onmouseover="setfaq(this, 'faqca6e')" class="noborder">
    <td class="vtop rowform">
        <input type="text" onchange="updatecolorpreview('c1')" name="settingsnew[allbackcolor]" value="<?php echo $settings['allbackcolor']['value'];?>" style="float:left; width:210px;" class="txt" id="c1_v">
        <input type="button" style="background: <?php echo $settings['allbackcolor']['value'];?>" value="" class="colorwd" onclick="c1_frame.location='static/image/admincp/getcolor.htm?c1|c1_v';showMenu({'ctrlid':'c1'})" id="c1" ><span id="c1_menu" style="position: absolute; z-index: 301; left: 251px; top: 317px; display: none;"><iframe width="210" height="148" frameborder="0" scrolling="no" src="" name="c1_frame"></iframe></span>
    </td></tr>
<tr><td s="1" class="td27" colspan="2">&#22495;&#21517;&#36339;&#36716;</td></tr>
<tr class="noborder"><td class="vtop rowform">
    <textarea class="tarea" cols="50"  name="settingsnew[domainname]" onkeydown="textareakey(this, event)" id="varsnew[domainname]"  ondblclick="textareasize(this, 1)" rows="6"><?php echo $settings['domainname']['value'];?></textarea>
</td><td colspan=2>&#19968;&#34892;&#19968;&#20010;<br/>&#20363;&#22914;&#65306;&#21271;&#20140;&#24066;&#124;&#21271;&#20140;&#24066;&#124;www.xxxxxx.com<br/><a href='http://addon.discuz.com/?@aljdm.plugin' target="_blank" >&#38656;&#35201;&#23433;&#35013;&#20142;&#21073;&#22495;&#21517;&#32465;&#23450;&#25554;&#20214;</a><br/>
</td></tr>

<tr><td s="1" class="td27" colspan="2">&#26159;&#21542;&#24320;&#21551;&#22810;&#22478;&#24066;</td></tr>
<tr class="noborder">
    <td class="vtop rowform" s="1">
        <ul onmouseover="altStyle(this);"><li class="checked"><input type="radio"  value="1"  <?php if($settings['is_more_city']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[is_more_city]" class="radio">&nbsp;&#26159;</li><li><input type="radio" value="0" <?php if($settings['is_more_city']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[is_more_city]" class="radio">&nbsp;&#21542;</li></ul>
        <br></td>
        <td>&#22914;&#33150;&#35759;&#22320;&#22270;&#40664;&#35748;&#75;&#69;&#89;&#23450;&#20301;&#19981;&#29983;&#25928;&#35831;&#21040;&#21830;&#23478;&#21161;&#25163;&#35774;&#32622;&#20013;&#37197;&#32622;&#33150;&#35759;&#22320;&#22270;&#75;&#69;&#89;</td>
</tr>

<tr><td s="1" class="td27" colspan="2">&#23450;&#20301;&#23618;&#32423;&#35774;&#32622;</td></tr>
<tr onmouseover="setfaq(this, 'faq1e8e')" class="noborder">
    <td class="vtop rowform">
        <select name="settingsnew[citymod]">
            <option value="0" >&#22478;&#24066;
            <option value="1" <?php if(1 == $settings['citymod']['value']) { ?>selected<?php } ?>>&#21439;&#21306;
        </select>
    </td>
    <td s="1" class="vtop tips2">&#40664;&#35748;&#23450;&#20301;&#22478;&#24066;&#65292;&#22320;&#21306;&#35774;&#32622;&#20013;&#19968;&#32423;&#20026;&#30465;&#65292;&#20108;&#32423;&#20026;&#24066;&#65292;&#20010;&#21035;&#31449;&#28857;&#22320;&#21306;&#35774;&#32622;&#20013;&#19968;&#32423;&#20026;&#24066;&#65292;&#20108;&#32423;&#20026;&#21439;&#47;&#21306;&#30340;&#35831;&#36873;&#25321;&#23450;&#20301;&#23618;&#32423;&#20026;&#21439;&#21306;</td>
</tr>

<tr><td s="1" class="td27" colspan="2">&#20010;&#20154;&#35748;&#35777;&#22270;&#26631;</td></tr>
<tr onmouseover="setfaq(this, 'faq1e8e')" class="noborder">
    <td class="vtop rowform">
        <input type="text" class="txt" value="<?php echo $settings['grrz_img']['value'];?>" name="settingsnew[grrz_img]">
    </td>
    <td s="1" class="vtop tips2">&#26174;&#31034;&#22312;&#20449;&#24687;&#29992;&#25143;&#21517;&#26049;</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#20225;&#19994;&#35748;&#35777;&#22270;&#26631;</td></tr>
<tr onmouseover="setfaq(this, 'faq1e8e')" class="noborder">
    <td class="vtop rowform">
        <input type="text" class="txt" value="<?php echo $settings['qyrz_img']['value'];?>" name="settingsnew[qyrz_img]">
    </td>
    <td s="1" class="vtop tips2">&#26174;&#31034;&#22312;&#20449;&#24687;&#29992;&#25143;&#21517;&#26049;</td>
</tr>