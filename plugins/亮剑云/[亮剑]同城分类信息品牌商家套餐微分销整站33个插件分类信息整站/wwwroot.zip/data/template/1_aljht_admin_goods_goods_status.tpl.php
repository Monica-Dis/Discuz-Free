<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div class="col-md-12">
<ul class="nav nav-tabs" role="tablist" >
<li <?php if(!$do) { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=goods<?php echo $urlmod;?>">已审核</a></li>

<li <?php if($do == 'no') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=goods&amp;do=no<?php echo $urlmod;?>">未审核<?php if($no_num>0) { ?>&nbsp;<b style="color:red;">(<?php echo $no_num;?>)</b><?php } ?></a></li>
<li <?php if($do == 'lose') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=goods&amp;do=lose<?php echo $urlmod;?>">不通过</a></li>

<li <?php if($do == 'grounding') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=goods&amp;do=grounding<?php echo $urlmod;?>"> 已上架</a></li>
<li <?php if($do == 'undercarriage') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=goods&amp;do=undercarriage<?php echo $urlmod;?>"> 已下架</a></li>
<?php if($_G['cache']['plugin']['aljsfx']['is_aljsfx'] && !$_GET['dzAdmin']) { ?>
<li <?php if($do == 'distribution') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=goods&amp;do=distribution<?php echo $urlmod;?>"> 分销</a></li>
<?php } if($administrators) { ?>
<li <?php if($do == 'rec') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=goods&amp;do=rec<?php echo $urlmod;?>"> 推荐</a></li>
<?php if($_GET['ajax'] != 'yes') { ?>
<li <?php if($do == 'reply') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=goods&amp;do=reply<?php echo $urlmod;?>">评论管理</a></li>
<?php } } ?>
</ul>
</div>
