<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<tr ><th class="partition" colspan="15" >&#25105;&#30340;&#39029;&#38754;</th></tr>


<tr><td s="1" class="td27" colspan="2">&#24179;&#21488;&#20844;&#21578;&#26631;&#39064;</td></tr>
<tr onmouseover="setfaq(this, 'faq1e8e')" class="noborder">
    <td class="vtop rowform">
        <input type="text" class="txt" value="<?php echo $settings['mobile_user_gg_title']['value'];?>" name="settingsnew[mobile_user_gg_title]">
    </td>
    <td s="1" class="vtop tips2"></td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#24179;&#21488;&#20844;&#21578;&#20869;&#23481;</td></tr>
<tr class="noborder">
    <td class="vtop rowform">
        <textarea class="tarea" cols="50"  name="settingsnew[mobile_user_gg_text]" onkeydown="textareakey(this, event)" id="varsnew[mobile_user_gg_text]"  ondblclick="textareasize(this, 1)" rows="6"><?php echo $settings['mobile_user_gg_text']['value'];?></textarea>
    </td>
    <td colspan=2>
        &#26684;&#24335;&#65306;&#25991;&#23383;&#124;&#38142;&#25509; <br/>&#19968;&#34892;&#19968;&#20010;
    </td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#25105;&#30340;&#24037;&#20855;&#33258;&#23450;&#20041;</td></tr>
<tr class="noborder">
    <td class="vtop rowform">
        <textarea class="tarea" cols="50"  name="settingsnew[mobile_user_my_tools]" onkeydown="textareakey(this, event)" id="varsnew[mobile_user_my_tools]"  ondblclick="textareasize(this, 1)" rows="6"><?php echo $settings['mobile_user_my_tools']['value'];?></textarea>
    </td>
    <td colspan=2>
        &#26684;&#24335;&#65306;&#22270;&#26631;&#40;&#23383;&#20307;&#41;&#124;&#38142;&#25509;&#124;&#25991;&#23383;<br/>
        &#19968;&#34892;&#19968;&#20010;<br/>
        &#22635;&#20889;&#21518;&#20250;&#25340;&#25509;&#22312;&#25105;&#30340;&#24037;&#20855;&#26368;&#21518;&#19968;&#20010;&#21518;&#38754;&#26174;&#31034;
    </td>
</tr>
