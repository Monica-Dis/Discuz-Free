<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<script src="source/plugin/aljtc/static/js/jquery.min.js" type="text/javascript"></script>
<link href="source/plugin/aljtc/static/js/layer/need/layer.css" rel="stylesheet" type="text/css">
<script src="source/plugin/aljtc/static/pclayer/layer.js" type="text/javascript"></script>
<script type="text/javascript">
    var jq = jQuery.noConflict();
</script>

<?php if($settings['isreview']['value']) { ?>
<div class="itemtitle">
<h3>
<ul class="tab1">
<li <?php if(!$_GET['state']) { ?>class="current" <?php } ?>>
<a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=<?php echo $pluginid;?>&do=<?php echo $_GET['do'];?>&pmod=admin">
<span>未审</span></a>
</li>
<li <?php if($_GET['state'] == 'yes') { ?>class="current" <?php } ?>>
<a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=<?php echo $pluginid;?>&do=<?php echo $_GET['do'];?>&pmod=admin&state=yes">
<span>已审</span>
</a>	
</li>
<li <?php if($_GET['state'] == 'top') { ?>class="current" <?php } ?>>
<a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=<?php echo $pluginid;?>&do=<?php echo $_GET['do'];?>&pmod=admin&state=top">
<span>&#24050;&#32622;&#39030;</span>
</a>	
</li>
</ul>
</h3>	
</div>
<?php } ?>
<table class="tb tb2 ">
        <tbody>
            <tr><th class="partition">&#25216;&#24039;&#25552;&#31034;</th></tr>
            <tr>
                <td class="tipsblock">
                    <ul id="tipslis">
<?php if($settings['isreview']['value']) { ?>
<li>&#26412;&#39029;&#38754;&#25903;&#25345;&#25209;&#37327;&#31649;&#29702;&#25968;&#25454;&#65292;&#28857;&#20987;&#25171;&#21246;&#24038;&#20391;&#22797;&#36873;&#26694;&#21518;&#21487;&#20197;&#25209;&#37327;&#23457;&#26680;&#47;&#25209;&#37327;&#21024;&#38500;</li>
<?php } else { ?>
<li>&#26412;&#39029;&#38754;&#25903;&#25345;&#25209;&#37327;&#31649;&#29702;&#25968;&#25454;&#65292;&#28857;&#20987;&#25171;&#21246;&#24038;&#20391;&#22797;&#36873;&#26694;&#21518;&#21487;&#20197;&#25209;&#37327;&#21024;&#38500;</li>
<?php } ?>
                        <li><b style="color:red;">&#21024;&#38500;&#25805;&#20316;&#19981;&#21487;&#36870;&#65292;&#35831;&#35880;&#24910;&#25805;&#20316;</b></li>
                        <li>&#35780;&#35770;&#31649;&#29702;&#31532;&#19968;&#20010;&#25324;&#21495;&#20026;&#35780;&#35770;&#24635;&#25968;&#65292;&#31532;&#20108;&#20010;&#32418;&#33394;&#25324;&#21495;&#20026;&#35780;&#35770;&#24453;&#23457;&#25968;&#37327;&#65292;&#28857;&#20987;&#21487;&#31649;&#29702;&#35780;&#35770;</li>
                    </ul>
                </td>
            </tr>
        </tbody>
    </table>
<form name="cpform" method="post" autocomplete="off" action="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=aljtc&pmod=admin&do=<?php echo $_GET['do'];?>&page=<?php echo $_GET['page'];?>" id="cpform">
<input type="hidden" name="formhash" value="<?php echo FORMHASH;?>">	
<table class="tb tb2 ">
<tbody>
<tr>
<th class="partition" colspan="2">
&#20449;&#24687;&#24635;&#25968;&#65306;<?php echo $num;?>
</th>
<th colspan="6" class="partition" style="text-align: right;">
<input type="hidden" name="state" value="<?php echo $_GET['state'];?>">
<input type="text" name="search" placeholder="&#26631;&#39064;&#25110;&#25551;&#36848;" value="<?php echo $_GET['search'];?>">
<input type="submit" name="searchsubmit" value="&#25628;&#32034;">
</th>
</tr>
<tr class="header">
<th></th>
<th>&#29992;&#25143;&#21517;<br/>uid</th>
<th>&#32852;&#31995;&#20154;<br/>&#32852;&#31995;&#30005;&#35805;</th>
<th>&#20998;&#31867;</th>
<th>&#20869;&#23481;</th>
<th>&#22270;&#29255;</th>
<th>&#21457;&#24067;&#26102;&#38388;<br/>&#26368;&#21518;&#26356;&#26032;&#26102;&#38388;<br/>&#32622;&#39030;&#36807;&#26399;&#26102;&#38388;</th>
<th>&#25805;&#20316;</th>
</tr><?php if(is_array($query)) foreach($query as $tmp_key => $tmp_value) { ?><tr class="hover">
<td>
<input class="checkbox" type="checkbox" name="delete[]" value="<?php echo $tmp_value['id'];?>">
</td>
<td class="td_m" >
<?php echo $tmp_value['username'];?><br/>uid:<?php echo $tmp_value['uid'];?>
</td>
<td class="td_m" >
<?php echo $tmp_value['lxr'];?><br/><?php echo $tmp_value['contact'];?>
</td>
<td class="td_m" >
<?php echo $pos_all[$tmp_value['zufangtype']]['subject'];?><br/><?php echo $pos_all[$tmp_value['subtype']]['subject'];?><br/><?php echo $pos_all[$tmp_value['subsubtype']]['subject'];?>
</td>
<td class="td_m" style="width:35%">
<?php echo $tmp_value['content'];?>
</td>
<td class="td_l"><?php $pics = explode('|',$tmp_value['pic']);?><?php if(is_array($pics)) foreach($pics as $tmp_key_first => $tmp_key_value) { if(strpos($tmp_key_value,$oss_domain) !== false) { ?>
<a href="<?php echo $tmp_key_value;?>" target="_blank" class="img-bgloading aljsqImg">
<img src="<?php echo $tmp_key_value;?>" width="80" height="80" />
</a>
<?php } elseif(file_exists($tmp_key_value)) { ?>
<a href="<?php echo $_G['siteurl'];?><?php echo $tmp_key_value;?>" target="_blank" class="img-bgloading aljsqImg">
<img src="<?php echo $tmp_key_value;?>" width="80" height="80" />
</a>
<?php } } ?></td>

<td class="td_l"><?php echo date('Y-m-d H:i:s',$tmp_value['addtime'])?><br/><?php echo date('Y-m-d H:i:s',$tmp_value['updatetime'])?><br/>
<?php if($tmp_value['topetime']) { ?>
<b style="color:red;"><?php echo date('Y-m-d H:i:s',$tmp_value['topetime'])?></b>
<?php } ?>
</td>
<td class="td_l">
<a href="javascript:void(0);" onclick="showiframe(<?php echo $tmp_value['id'];?>,<?php echo $tmp_value['zufangtype'];?>,<?php echo $tmp_value['subtype'];?>);">&#32534;&#36753;</a>
<a href="javascript:void(0);" onclick="showviewiframe(<?php echo $tmp_value['id'];?>);">&#39044;&#35272;</a>
<a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=aljtc&do=<?php echo $_GET['do'];?>&pmod=admin&act=commentlist&lid=<?php echo $tmp_value['id'];?>" onclick="showWindow('edit',this.href)">
&#35780;&#35770;&#31649;&#29702;
(<?php echo DB::result_first('select count(*) from %t where lid=%d',array('aljtc_comment',$tmp_value['id']))?>)

<b style="color:red;">(<?php echo DB::result_first('select count(*) from %t where lid=%d and status=1',array('aljtc_comment',$tmp_value['id']))?>)</b>

</a>
</td>
</tr>
<?php } ?>
<tr>
<td class="td25" style="width:6%">
<input type="checkbox" name="chkall" id="chkallK5T1" class="checkbox" onclick="checkAll('prefix', this.form, 'delete')">
<label for="chkallK5T1">&#21024;&#63;<?php if($settings['isreview']['value']) { ?>&#47;&#23457;&#65311;<?php } ?></label>
</td>
<td colspan="2">
<div class="fixsel">
<input type="submit" class="btn" id="submit_submit" name="del_submit"  value="&#25209;&#37327;&#21024;&#38500;">
<?php if($settings['isreview']['value']) { ?>
<input type="submit" class="btn" id="submit_submit" name="submit"  value="&#25209;&#37327;&#23457;&#26680;">
<?php } ?>
</div>
</td>
<td colspan="4"><?php echo $paging;?><td>
</tr>
</tbody>
</table>
</form>

<script>
function showiframe(id,typeid,sid) {
layer.open({
type: 2,
title: '&#32534;&#36753;&#27169;&#24335;',
shadeClose: true,
shade: 0,
area: ['60%', '90%'],
offset: ['5%', '16%'],
anim: 5,
content: 'plugin.php?id=aljtc&act=edit&adminedit=yes&lid='+id+'&typeid='+typeid+'&sid='+sid
});
}
function showviewiframe(id) {
layer.open({
type: 2,
title: '&#39044;&#35272;&#27169;&#24335;',
shadeClose: true,
shade: 0,
area: ['60%', '90%'],
offset: ['5%', '16%'],
anim: 5,
content: 'plugin.php?id=aljtc&act=view&adminedit=yes&lid='+id
});
}
function tips(txt, fun) {
if(fun){
layer.alert(txt, {icon: 6},function(){
layer.closeAll(); //���ģʽ���ر����в�
location.href=location.href;
});
}else{
layer.msg(txt);
}
}
</script>