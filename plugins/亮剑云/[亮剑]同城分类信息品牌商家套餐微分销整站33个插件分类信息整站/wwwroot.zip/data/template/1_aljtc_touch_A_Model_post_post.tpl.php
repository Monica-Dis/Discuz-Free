<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('post');?><?php include template('aljtc:A_Model/header'); ?><style>
.weui-uploader__input-box {
    border: 1px solid #efefef;
    background: #f5f5f5;
}
.fix-bottom {
    position: fixed;
    left: 0;
    width: 100%;
    bottom: 0;
    z-index: 9;
    border-radius: 0;
    padding: 15px;
    background: #fff;
    box-sizing: border-box;
    box-shadow: 0 0 10px #f5f5f5;
}
.weui-btn_primary,.weui-switch:checked{
background-color: <?php if($color) { ?><?php echo $color;?><?php } else { ?>rgba(246, 6, 6, 0.6)<?php } ?>!important;
}
.weui-switch:checked{
border-color: <?php if($color) { ?><?php echo $color;?><?php } else { ?>rgba(246, 6, 6, 0.6)<?php } ?>;
}

.weui-label{
color:#000;
}
.weui-cells_form .weui-cell__ft {
    font-size: 17px;
}
.weui-icon-cancel {
    color: #FFFFFF;
    font-size: 36px;
}
.weui-btn_mini {
    padding: 16px 1em;
    line-height: 0;
    float: left;
    margin: 4px 8px 4px 0;
    border-radius: 80px;
}
.tag-on {
    background-color: <?php if($color) { ?><?php echo $color;?><?php } else { ?>rgba(246, 6, 6, 0.6)<?php } ?>!important;
    color: #fff;
}
.color-red{
color: rgba(246, 6, 6, 0.6);
}
.weui-btn_default:not(.weui-btn_disabled):active {
    color: rgb(246, 244, 244);
    background-color: #dedede;
}
.tag-btn_mini:after {
    border-radius: 80px;
}
</style>
<div class="bodyheight">
<main class="indexcontent" style="background: #f8f8f8;">

        <iframe name="myiframe" id="myiframe" style="display:none;"></iframe>
<form action="plugin.php?id=aljtc&amp;act=friendpost&amp;lid=<?php echo $lp['id'];?>" method="post" id="postform"  accept-charset="UTF-8">
<input type="hidden" value="<?php echo FORMHASH;?>" name="formhash">
        <?php if($lp['zufangtype'] || $lp['subtype']) { ?>
            <input type="hidden" name="typeid" id="typeid" autocomplete="off" value="<?php echo $lp['zufangtype'];?>">
            <input type="hidden" name="sid" id="sid" autocomplete="off" value="<?php echo $lp['subtype'];?>">
        <?php } else { ?>
            <input type="hidden" name="typeid" id="typeid" autocomplete="off" value="<?php echo $_GET['typeid'];?>">
            <input type="hidden" name="sid" id="sid" autocomplete="off" value="<?php echo $_GET['sid'];?>">
        <?php } ?>
        <input type="hidden" name="cid" id="cid" autocomplete="off" value="<?php echo $lp['subsubtype'];?>">
        <input type="hidden" value="<?php echo $subridlist['upid'];?>" name="region">
        <input type="hidden" value="<?php echo $subridlist['id'];?>" name="region1">
        <input type="hidden" value="<?php echo $lp['lat'];?>" name="lat">
        <input type="hidden" value="<?php echo $lp['lng'];?>" name="lng">
        <input type="hidden" value="<?php echo $_GET['adminedit'];?>" name="adminedit">
<input type="hidden" name="<?php echo $pluginid;?>_token" value="<?php echo create_token($pluginid.'_token');?>">
        <?php if($tip) { ?>    
            <div class="weui-cells__title" style="padding-top: 10px;margin-top: 0px;">
                <?php echo $tip;?>
            </div>
        <?php } ?>
        <?php if($_GET['act'] == 'post') { ?>
        <div class="weui-cells__title" style="padding-top: 10px;margin-top: 0px;">
        <?php include template('aljtc:A_Model/post/post_tips'); ?>        <?php if($card_info['card_tc_post']>0 && $_G['cache']['plugin']['aljtcc'] && ($settings['releasepay']['value']>0 || $price>0)) { ?>
            <style>
                    .goods-info{margin:5px 0px 10px 0px;}
                    .goods-info .member-card {
                    display: flex;
                    justify-content: space-between;
                    padding: 8px 14px;
                    background: #f42424;
                    border-radius: 10px;
                    color: #f8f8f8;
                    align-items: center;
                    }
                    .goods-info .card-left {
                    display: flex;
                    align-items: center;
                    }
                    
                    .goods-info .card-left > i {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    width: 20px;
                    height: 20px;
                    background: #f8f8f8;
                    border-radius: 5px;
                    position: relative;
                    color: rgb(255, 130, 50);
                    text-align: center;
                    margin-right: 6px;
                    line-height: 15px;
                    }
                    .goods-info .card-right,.card-right {
                    padding: 0 15px 0 10px;
                    background-color: rgba(255,255,255,.3);
                    border-radius: 10px;
                    }
                    .goods-info .card-right {
                    display: flex;
                    align-items: center;
                    }
                            .card-open-btn{
                                text-align: center;
                                padding: 0 10px 0 10px;
                    background-color: #f42424;
                    border-radius: 10px;
                                color:#ffffff;
                    float: right;
                    font-size: 12px;
                            }
                    .goods-info .card-left > span {
                    color:#ffffff;
                    font-size: 12px;
                    }
                    .goods-info .card-right > span {
                    position: relative;
                    color:#ffffff;
                    font-size: 12px;
                    }
                    .card-right span:after {
                    content: '';
                    position: absolute;
                    top: 50%;
                    border-top: 1px solid #ffffff;
                    border-right: 1px solid #ffffff;
                    width: 4px;
                    height: 4px;
                    -webkit-transform: translateY(-50%) rotate(45deg);
                    -moz-transform: translateY(-50%) rotate(45deg);
                    -ms-transform: translateY(-50%) rotate(45deg);
                    transform: translateY(-50%) rotate(45deg);
                    }
                    i {
                                font-style: normal;
                            }
                        </style>
            
            <div class="goods-info">
                <div class="member-card">
                <p class="card-left">
                <i class="iconfont icon-rongyu p_color"></i>
                <span>
                    <?php echo $card_info['card_title'];?>专享价 <?php echo $card_releasepay;?>
                </span>
                </p>
                <a class="card-right" href="plugin.php?id=aljtcc&amp;c=index&amp;a=index&amp;ajax=yes&amp;card_id=2">
                        <?php if($card_user) { ?>
                            <span>查看特权</span>
                        <?php } else { ?>
                            <span>立即开通</span>
                        <?php } ?>
                </a>
                </div>
            </div>
            <?php } ?>
    </div>
        <?php } ?>
<div class="weui-cells weui-cells_form">
        <?php if($_GET['adminedit'] == 'yes' && $admin_status) { ?>
            <div class="weui-cell weui-cell_access">
<div class="weui-cell__hd"><label class="weui-label">&#31867;&#22411;</label></div>
<div class="weui-cell__bd">
<input class="weui-input" type="text" id='type-picker' value="<?php echo $default_type;?>" />
</div>
<div class="weui-cell__ft"></div>
</div>
        <?php } else { ?>
            <?php if($pos) { ?>
                <div class="weui-cell weui-cell_select weui-cell_select-after">
                    <div class="weui-cell__hd">
                        <label for="" class="weui-label">&#31867;&#22411;</label>
                    </div>
                    <div class="weui-cell__bd">
                        <select class="weui-select" name="cid">
                            <?php if(is_array($pos)) foreach($pos as $r) { ?>                            <option value="<?php echo $r['id'];?>" <?php if($lp['subsubtype']== $r['id']) { ?> selected <?php } ?>><?php echo $r['subject'];?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
            <?php } ?>
        <?php } ?>
        <?php if(!$customlist && $_GET['adminedit'] == 'yes' && $admin_status) { ?>
        <?php include template('aljtc:A_Model/post/post_region'); ?>        <?php } ?>
        <?php $reg_i = 0;?><?php if(is_array($customlist)) foreach($customlist as $tmp_key => $tmp_value) { ?>    <?php if($tmp_value['custom_type'] == 'title' && $tmp_value['custom_state']) { ?>
    <div class="weui-cell">
        <div class="weui-cell__hd"><label class="weui-label"><?php echo $tmp_value['custom_title'];?></label></div>
        <div class="weui-cell__bd">
          <input class="weui-input" type="text" name="<?php echo $tmp_value['custom_name'];?>" placeholder="<?php echo $tmp_value['custom_extra'];?>" value="<?php echo $lp['title'];?>">
      </div>
      </div>
  	<?php } if($tmp_value['custom_type'] == 'select' && $tmp_value['custom_state']) { if($tmp_value['custom_extra']) { ?>
<div class="weui-cell weui-cell_select weui-cell_select-after">
            <div class="weui-cell__hd">
                <label for="" class="weui-label"><?php echo $tmp_value['custom_title'];?></label>
            </div>
            <div class="weui-cell__bd">
                <select class="weui-select" name="<?php echo $tmp_value['custom_name'];?>" <?php if($lid && !$tmp_value['custom_change']) { ?> disabled="disabled"  <?php } ?>>
                <?php if(is_array($tmp_value['custom_extra'])) foreach($tmp_value['custom_extra'] as $tmp_key_first => $tmp_value_first) { ?>                    <option value="<?php echo $tmp_value_first;?>" <?php if($lp[$tmp_value['custom_name']] == $tmp_value_first) { ?> selected <?php } ?>><?php echo $tmp_value_first;?></option>
                    <?php } ?>
                </select>

            </div>
        </div>
        <?php } ?>
    <?php } ?>
        <?php if($tmp_value['custom_type'] == 'text' && $tmp_value['custom_state']) { ?>
  	<div class="weui-cell">
  		<?php if($tmp_value['custom_title']) { ?>
    <div class="weui-cell__hd"><label class="weui-label"><?php echo $tmp_value['custom_title'];?></label></div>
    <?php } ?>
    <div class="weui-cell__bd">
      <input class="weui-input" type="text" name="<?php echo $tmp_value['custom_name'];?>" placeholder="<?php echo $tmp_value['custom_extra'];?>" value="<?php echo $lp[$tmp_value['custom_name']];?>" <?php if($lid && !$tmp_value['custom_change']) { ?> disabled="disabled" <?php } ?>>
    </div>
    <?php if($tmp_value['custom_unit']) { ?>
    	<div class="weui-cell__ft"><?php echo $tmp_value['custom_unit'];?></div>
    <?php } ?>
  	</div>
          <?php } ?>
          <?php if($tmp_value['custom_type'] == 'url' && $tmp_value['custom_state']) { ?>
  	<div class="weui-cell">
  		<?php if($tmp_value['custom_title']) { ?>
    <div class="weui-cell__hd"><label class="weui-label"><?php echo $tmp_value['custom_title'];?></label></div>
    <?php } ?>
    <div class="weui-cell__bd">
      <input class="weui-input" type="text" name="<?php echo $tmp_value['custom_name'];?>" placeholder="<?php echo $tmp_value['custom_extra'];?>" value="<?php echo $lp[$tmp_value['custom_name']];?>" <?php if($lid && !$tmp_value['custom_change']) { ?> disabled="disabled" <?php } ?>>
    </div>
    <?php if($tmp_value['custom_unit']) { ?>
    	<div class="weui-cell__ft"><?php echo $tmp_value['custom_unit'];?></div>
    <?php } ?>
  	</div>
          <?php } ?>
          <?php if($tmp_value['custom_type'] == 'video' && $tmp_value['custom_state'] && $_G['cache']['plugin']['aljtsp']['is_aljtc']) { ?>
  	    <?php include template('aljtsp:aljtc/addvideo'); ?>        <?php } ?>
  	<?php if($tmp_value['custom_type'] == 'checkbox' && $tmp_value['custom_state']) { ?>
  	<div class="weui-cell weui-cell_switch">
    <div class="weui-cell__bd"><?php echo $tmp_value['custom_title'];?></div>
    <div class="weui-cell__ft">
      <input class="weui-switch" type="checkbox" name="<?php echo $tmp_value['custom_name'];?>" value="&#26159;" <?php if($lp[$tmp_value['custom_name']]) { ?>  checked="checked" <?php } ?> <?php if($lid && !$tmp_value['custom_change']) { ?> disabled="disabled"  <?php } ?>>
    </div>
  		</div>
  		<?php } if($tmp_value['custom_type'] == 'textarea' && $tmp_value['custom_state']) { ?>
  	<div class="weui-cell">
    <div class="weui-cell__bd">
      <textarea class="weui-textarea" <?php if($lid && !$tmp_value['custom_change']) { ?> readonly="readonly"  <?php } ?> placeholder="<?php echo $tmp_value['custom_extra'];?>" rows="3" name="<?php echo $tmp_value['custom_name'];?>"><?php echo $lp[$tmp_value['custom_name']];?></textarea>
    </div>
  	</div>
  	<?php } ?>
        <?php if($tmp_value['custom_type'] == 'date' && $tmp_value['custom_state']) { ?>
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label for="" class="weui-label"><?php echo $tmp_value['custom_title'];?></label></div>
            <div class="weui-cell__bd">
                <input type="text" id='datetime-picker' class="weui-input" style="width:90%" name="<?php echo $tmp_value['custom_name'];?>" placeholder="<?php echo $tmp_value['custom_extra'];?>" value="<?php echo str_replace('T',' ',$lp[$tmp_value['custom_name']])?>" <?php if($lid && !$tmp_value['custom_change']) { ?> disabled="disabled" <?php } ?> />
            </div>
            <div class="weui-cell__ft"></div>
            <script>
            $("#datetime-picker").datetimePicker();
            </script>
        </div>
        <?php } ?>
        
        <?php if(($tmp_value['custom_type'] == 'region' && $tmp_value['custom_state'] && $_GET['adminedit'] != 'yes') || ($_GET['adminedit'] == 'yes' && $admin_status && $reg_i==0)) { ?>
            <?php include template('aljtc:A_Model/post/post_region'); ?>            <?php $reg_i++?>        <?php } ?>
        <?php if($tmp_value['custom_type'] == 'address' && $tmp_value['custom_state']) { ?>
            <div class="weui-cell weui-cell_vcode">
                <div class="weui-cell__hd">
                    <label class="weui-label"><?php echo $tmp_value['custom_title'];?></label>
                </div>
                <div class="weui-cell__bd" id="city-picker">
                    <input class="weui-input" type="text" value="<?php echo $lp['region3'];?>" name="region3" id="addr" placeholder="<?php echo $tmp_value['custom_extra'];?>">
                </div>
                
                <div class="weui-cell__ft">
                    <a class="weui-vcode-btn" id="geocity" onclick="zxc();return false;">&#23450;&#20301;</a>
                    
                    <script>
                        <?php if($_GET['act'] == 'post') { ?>
                        var auto_lbs = 1;
                        <?php } ?>
                        var tc_auto_address = 1;
                    </script>
                    
                </div>
               
            </div>
        <?php } ?>
        <?php } ?>
        <?php if($formsetting['desc_title']) { ?>
        <div class="weui-cells__title" >
            <?php echo $formsetting['desc_title'];?>
        </div>
        <?php } ?>
<div class="weui-cell">
    <div class="weui-cell__bd">
      <textarea class="weui-textarea" placeholder="<?php if($formsetting['desc_content']) { ?><?php echo $formsetting['desc_content'];?><?php } else { ?>&#25551;&#36848;&#20449;&#24687;<?php } ?>" rows="3" name="content"><?php echo $lp['content'];?></textarea>
    </div>
        </div>
        <?php if(!$formsetting['is_post_lxfs']) { ?>
        <div class="weui-cell">
  		    <div class="weui-cell__hd"><label class="weui-label">&#32852;&#31995;&#20154;</label></div>
       	 	<div class="weui-cell__bd">
      			<input class="weui-input" type="text" name="lxr" placeholder="&#22914;&#65306;&#26446;&#20808;&#29983;" value="<?php echo $lp['lxr'];?>">
   			</div>
      	</div>
      	<div class="weui-cell">
  		    <div class="weui-cell__hd"><label class="weui-label">&#32852;&#31995;&#30005;&#35805;</label></div>
        	<div class="weui-cell__bd">
      			<input class="weui-input" type="text" name="contact" placeholder="&#20363;&#58;138**&#25110;1234-12345678" value="<?php echo $lp['contact'];?>">
   		    </div>
        </div>
        <?php } ?>
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <div class="weui-uploader">
                    <div class="weui-uploader__hd">
                        <p class="weui-uploader__title">&#19978;&#20256;&#29031;&#29255;</p>
                        <div class="weui-uploader__info"></div>
                    </div>
                    <div class="weui-uploader__bd">
                        <ul class="weui-uploader__files" id="uploaderFiles">
                            <?php if($lp['pic']) { ?>
                            <?php if(is_array($lp['pic'])) foreach($lp['pic'] as $tmp_value) { ?>                            <li class="weui-uploader__file weui-uploader__file_status img_list" style="background-image:url('<?php echo $tmp_value;?>')">
                                <div class="weui-uploader__file-content">
                                    <i class="weui-icon-cancel" onclick="delimg(this)"></i>
                                </div>
                            </li>
                            <input name="pic[]" class="pic" type="hidden" value="<?php echo $tmp_value;?>">
                            <?php } ?>
                            <?php } ?>
                        </ul>
                        <div class="weui-uploader__input-box">
                            <?php if(IN_MINI == 1) { ?>
                            <span class="weui-uploader__input" data-number="9"></span>
                            <?php } else { ?>
                            <input  class="weui-uploader__input" type="file" data-number="9" >
                            <?php } ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <?php if($formsetting['mobile_label']) { ?>
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <div class="post-tags cl" id="post-typeid">
                <?php if(is_array($mobile_label)) foreach($mobile_label as $tmp_key => $tmp_value) { ?>                    <a class="weui-btn weui-btn_mini weui-btn_default tag-btn_mini <?php if(in_array($tmp_value,$lp['label'])) { ?>tag-on<?php } ?>" href="javascript:;" onclick="addlabelvalue(<?php echo $tmp_key;?>,'<?php echo $tmp_value;?>',this)"><?php echo $tmp_value;?></a>
                    <input name="form[tagid][<?php echo $tmp_key;?>]" type="hidden" value="<?php if(in_array($tmp_value,$lp['label'])) { ?><?php echo $tmp_value;?><?php } else { ?>0<?php } ?>">
                    <?php } ?>
                </div>
            </div>
        </div>
        <?php } ?>
      </div>
      <?php if($_GET['adminedit'] == 'yes' && $admin_status) { ?>
        <div class="weui-cells weui-cells_form">
            <div class="weui-cells__title" >
                &#31649;&#29702;&#21592;&#26435;&#38480;
            </div>
            <div class="weui-cells__title" >
                &#32622;&#39030;&#26102;&#38388;&#23567;&#20110;&#31561;&#20110;&#24403;&#21069;&#26102;&#38388;&#23558;&#21462;&#28040;&#32622;&#39030;
            </div>
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label for="" class="weui-label">&#32622;&#39030;&#32467;&#26463;&#26102;&#38388;</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" id='topdatetime-picker' style="width:90%" name="topetime" value="<?php if($lp['topetime']>0) { echo date('Y-m-d H:i',$lp['topetime'])?><?php } else { echo date('Y-m-d H:i',TIMESTAMP)?><?php } ?>" />
                </div>
                <div class="weui-cell__ft"></div>
                <script>
                $("#topdatetime-picker").datetimePicker();
                </script>
            </div>
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label for="" class="weui-label">&#20449;&#24687;&#36807;&#26399;&#26102;&#38388;</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" id='expiry_time-picker' style="width:90%" name="expiry_time" value="<?php if($lp['expiry_time']>0) { echo date('Y-m-d H:i',$lp['expiry_time'])?><?php } ?>" />
                </div>
                <div class="weui-cell__ft"></div>
                <script>
                $("#expiry_time-picker").datetimePicker();
                </script>
            </div>
            <div class="weui-cell weui-cell_select weui-cell_select-after">
            <div class="weui-cell__hd">
                <label for="" class="weui-label">&#29366;&#24577;</label>
            </div>
            <div class="weui-cell__bd">
                <select class="weui-select" name="state">
                    <option value="0" <?php if(!$lp['state']) { ?>selected=""<?php } ?>>&#24050;&#23457;&#26680;</option>
                    <option value="1" <?php if($lp['state'] == 1) { ?>selected=""<?php } ?>>&#24453;&#23457;&#26680;</option>
                </select>
            </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">&#20998;&#31449;ID</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input " type="text"  placeholder="&#20998;&#31449;ID" name="fz_id" value="<?php echo $lp['fz_id'];?>">
                </div>
            </div>
        </div>
      <?php } ?>
      <?php if($_G['cache']['plugin']['aljtc']['agreement']) { ?>
      <style>.weui-agree__checkbox:checked:before {color: <?php echo $color;?>!important;}
      .weui-popup__modal .page__bd {
            position: absolute;
            height: calc(100vh - 60px);
            width: 100%;
            background: #ffffff;
            -webkit-overflow-scrolling: touch;
            overflow: hidden;
            overflow-y: auto;
        }
        .popib_bottom_fixed {
            position: fixed;
            bottom: 0px;
            height: 60px;
            background: #ffffff;
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            border-top: 1px solid #f8f8f8;
            z-index: 99999;
        }
        .w90{width:90%;}
        .mt0{margin-top:0px}
      </style>
      <label for="weuiAgree" class="weui-agree" onclick="$('#weui-agree').popup();">
            <input id="weuiAgree" type="checkbox" name="agreement_checked" <?php if($_G['cache']['plugin']['aljtc']['agreement_checked'] || $_GET['act'] == 'edit') { ?>checked="checked"<?php } ?> readonly="" class="weui-agree__checkbox">
            <span class="weui-agree__text">
              阅读并同意<a href="javascript:void(0);"><?php echo $_G['cache']['plugin']['aljtc']['agreement_title'];?></a>
            </span>
        </label>
        <div id="weui-agree" class="weui-popup__container" style="z-index: 1000">
            <div class="weui-popup__overlay"></div>
            <div class="weui-popup__modal">
                <div class="page__bd">
                    <article class="weui-article">
                        <?php echo $_G['cache']['plugin']['aljtc']['agreement'];?>
                    </article>
                </div>
                <style>.w30{width:30%}.w60{width:60%;margin-top: 0px !important;}</style>
                <script>
                $(document).on('click','.close_btn',function(){
                    if($(this).data('id') == 1){
                        $("#weuiAgree").prop("checked",true);
                    }else{
                        $("#weuiAgree").prop("checked",false);
                    }
                })
                </script>
                <div class="popib_bottom_fixed">
                    <a href="javascript:;" class="weui-btn weui-btn_default close-popup w30 close_btn" data-id="0">不同意</a>
                    <a href="javascript:;" class="weui-btn weui-btn_primary close-popup w60 close_btn" data-id="1">我已阅读并同意此协议</a>
                </div>
            </div>
        </div>
        <?php } ?>
  	<div class="fix-bottom weui-cells mt0" style="position: relative;">
        <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="提交" <?php if($_GET['adminedit'] != 'yes') { ?>onclick="$.showLoading();"<?php } ?>>
        <?php if($_GET['act'] == 'post') { ?>
        <div class="weui-cells__title" style="padding: 10px 0px;margin-top: 0px;">
            <?php include template('aljtc:A_Model/post/post_tips'); ?>        </div>
        <?php include template('aljtc:A_Model/post/post_btn_tips'); ?>        
        <?php if($card_info['card_tc_post']>0 && $_G['cache']['plugin']['aljtcc'] && ($settings['releasepay']['value']>0 || $price>0)) { ?>
            <style>
                    .goods-info{margin:5px 0px 10px 0px;}
                    .goods-info .member-card {
                    display: flex;
                    justify-content: space-between;
                    padding: 8px 14px;
                    background: #f42424;
                    border-radius: 10px;
                    color: #f8f8f8;
                    align-items: center;
                    }
                    .goods-info .card-left {
                    display: flex;
                    align-items: center;
                    }
                    
                    .goods-info .card-left > i {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    width: 20px;
                    height: 20px;
                    background: #f8f8f8;
                    border-radius: 5px;
                    position: relative;
                    color: rgb(255, 130, 50);
                    text-align: center;
                    margin-right: 6px;
                    line-height: 15px;
                    }
                    .goods-info .card-right,.card-right {
                    padding: 0 15px 0 10px;
                    background-color: rgba(255,255,255,.3);
                    border-radius: 10px;
                    }
                    .goods-info .card-right {
                    display: flex;
                    align-items: center;
                    }
                            .card-open-btn{
                                text-align: center;
                                padding: 0 10px 0 10px;
                    background-color: #f42424;
                    border-radius: 10px;
                                color:#ffffff;
                    float: right;
                    font-size: 12px;
                            }
                    .goods-info .card-left > span {
                    color:#ffffff;
                    font-size: 12px;
                    }
                    .goods-info .card-right > span {
                    position: relative;
                    color:#ffffff;
                    font-size: 12px;
                    }
                    .card-right span:after {
                    content: '';
                    position: absolute;
                    top: 50%;
                    border-top: 1px solid #ffffff;
                    border-right: 1px solid #ffffff;
                    width: 4px;
                    height: 4px;
                    -webkit-transform: translateY(-50%) rotate(45deg);
                    -moz-transform: translateY(-50%) rotate(45deg);
                    -ms-transform: translateY(-50%) rotate(45deg);
                    transform: translateY(-50%) rotate(45deg);
                    }
                    i {
                                font-style: normal;
                            }
                        </style>
            
            <div class="goods-info">
                <div class="member-card">
                <p class="card-left">
                <i class="iconfont icon-rongyu p_color"></i>
                <span>
                    <?php echo $card_info['card_title'];?>专享价 <?php echo $card_releasepay;?>
                </span>
                </p>
                <a class="card-right" href="plugin.php?id=aljtcc&amp;c=index&amp;a=index&amp;ajax=yes&amp;card_id=2">
                        <?php if($card_user) { ?>
                            <span>查看特权</span>
                        <?php } else { ?>
                            <span>立即开通</span>
                        <?php } ?>
                </a>
                </div>
            </div>
            <?php } ?>
            <?php } ?>
    </div>
    </form>
</main>

<div>

<style>

.layui-m-layerbtn {
    display: box;
    display: -moz-box;
    display: -webkit-box;
    width: 100%;
    height: 50px;
    line-height: 50px;
    font-size: 0;
    border-top: 1px solid #dfdfdf;
    background-color: #fff;
    position: relative;
    	bottom: 0;
}
.layui-m-layercont{
overflow-y: scroll;
height: 76%;
-webkit-overflow-scrolling: touch;
}
.layui-m-layer1 .layui-m-layercont {
    padding: 3%;
    text-align: left;
}
.layui-m-layercont>p{
font-size: 12px;
padding: 0 15px 10px 15px;
}
.layui-m-layerbtn span[yes] {
    	color: #ff0804;
}
</style>
<script>

function lj_region(obj){
var r = $(obj).val();
$("#getregion").hide();
$("#region1").hide();
$('#load').show();
if(r != 0) {
$.post('plugin.php?id=<?php echo $pluginid;?>&act=mgetregion&getdata=yes',{"upid":r,op:0},function(data){
if(data){
$("#getregion").html(data);
$("#getregion").show();
}else{
$("#getregion").html('');
$("#getregion").hide();
}
$('#load').hide();
});
}else {
$('#load').hide();
}

}
function lj_subregion(obj){
var r = $(obj).val();
$("#region1").hide();
$('#load').show();
if(r != 0) {
$.post('plugin.php?id=<?php echo $pluginid;?>&act=mgetregion&getdata=yes',{"upid":r,op:1},function(data){
if(data){
$("#region1").html(data);
$("#region1").show();
}else{
$("#region1").html('');
$("#region1").hide();

}
$('#load').hide();
});
}else{
$('#load').hide();
}
}

function addlabelvalue(id,value,el){
var name = 'form[tagid]['+id+']';
var input = $("input[name='"+name+"']");
if(input.val()!=0) {
$(el).removeClass('tag-on');
input.val(0);
}else {
$(el).addClass('tag-on');
input.val(value);
}

}
<?php if($no_post == 1) { ?>
    $.alert('<?php echo $on_post_tip;?>', function() {
        <?php if($no_post_qd_url == 1) { ?>
            window.history.go(-1);
        <?php } else { ?>
            location.href = '<?php echo $no_post_qd_url;?>'+'&referer='+l_href;
        <?php } ?>
    })
<?php } ?>

</script>
<?php if($_GET['adminedit'] == 'yes' && $admin_status) { ?>
<script>
+function($){
        $.rawtypeData = <?php echo $typejson;?>;
    }($);
</script>
<script src="source/plugin/aljhtx/static/weui/js/type-picker.min.js" type="text/javascript" charset="utf-8"></script>
<script>
    $("#type-picker").cityPicker({
        title: "&#36873;&#25321;&#20998;&#31867;",
        onChange: function (picker, values, displayValues) {
            console.log(values);
            $('#typeid').val(values[0]);
            $('#sid').val(values[1]);
            if(values[1] == values[2]){
                $('#cid').val('');
            }else{
                $('#cid').val(values[2]);
            }
        }
    });
</script>
<?php } ?>
    <?php include template('aljtc:A_Model/footer'); ?></body>
</html>
