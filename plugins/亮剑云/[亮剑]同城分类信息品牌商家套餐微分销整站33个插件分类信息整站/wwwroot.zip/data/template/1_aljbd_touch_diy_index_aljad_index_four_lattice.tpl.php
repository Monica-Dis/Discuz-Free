<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($settings['aljad_index_four_lattice']['value'] || $settings['aljad_index_four_lattice_up']['value']) { ?>
<div class="blank8"></div>
<?php if($settings['aljad_index_four_lattice_up']['value']) { ?>
<div class="hot diyDocument" diy-id="aljad_index_four_lattice_up">
    <?php echo htmlspecialchars_decode($settings['aljad_index_four_lattice_up']['value']);?></div>
<?php } ?>
<div class="hot diyDocument" diy-id="mobile_index_fad-change">
    <?php if($settings['aljad_index_four_lattice']['value']) { ?>
    <div class="lj_left">
        <?php echo $aljad_index_four_lattice['0'];?>
        <?php echo $aljad_index_four_lattice['1'];?>
    </div>
    <div class="lj_right">
        <?php echo $aljad_index_four_lattice['2'];?>
        <?php echo $aljad_index_four_lattice['3'];?>
    </div>
    <?php } ?>
</div>
<?php } else { ?>
<!--�ĸ���λ-->
<?php if($settings['mobile_index_fad']['value']) { ?>
<div class="blank8"></div>
<?php if($settings['mobile_index_fad_title']['value']) { ?>
<div class="hot diyDocument" diy-id="mobile_index_fad_title"><img src="<?php echo $settings['mobile_index_fad_title']['value'];?>" /></div>
<?php } ?>

<div class="hot diyDocument" diy-id="mobile_index_fad">
    <div class="lj_left">
        <a href="<?php echo $mobile_index_fad_arr['0']['1'];?>" class="navigateTo"><img src="<?php echo $mobile_index_fad_arr['0']['0'];?>" style="margin-bottom:2px;"></a>
        <a href="<?php echo $mobile_index_fad_arr['1']['1'];?>" class="navigateTo"><img src="<?php echo $mobile_index_fad_arr['1']['0'];?>" alt="" ></a>
    </div>
    <div class="lj_right">
        <a href="<?php echo $mobile_index_fad_arr['2']['1'];?>" class="navigateTo"><img src="<?php echo $mobile_index_fad_arr['2']['0'];?>" alt="" style="margin-bottom:2px;"></a>
        <a href="<?php echo $mobile_index_fad_arr['3']['1'];?>" class="navigateTo"><img src="<?php echo $mobile_index_fad_arr['3']['0'];?>" alt=""></a>
    </div>
</div>
<?php } ?>
<!--�ĸ���λ-->
<?php } ?>
