<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<script>
    function tips(info,url,iframe){
        if(info == 0){
            layer.alert('<?php echo $aljhtlang['js']['brand_6'];?>', {icon: 6,fixed:false,top:30},function(){
                if(iframe == 1){
                    parent.location.reload();
                }else{
                    location.href=location.href;
                }
            });
        }else{
            if(url){
                layer.alert(info, {icon: 6,fixed:false,top:30},function(){
                    if(iframe == 1){
                        parent.location.reload();
                    }else{
                        location.href=url;
                    }
                });
            }else{
                layer.msg(info,{fixed:false,top:30});
            }
        }
    }
</script>