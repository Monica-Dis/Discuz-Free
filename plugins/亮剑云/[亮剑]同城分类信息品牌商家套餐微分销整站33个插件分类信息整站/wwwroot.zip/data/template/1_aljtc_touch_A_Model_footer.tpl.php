<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template('aljtc:A_Model/my/operation'); include template('aljtc:A_Model/common/common_footer_webview'); include template('aljtc:A_Model/post/post_img_js'); include template('aljtc:A_Model/common/common_footer_js'); if($_GET['act'] == 'view' && !$settings['is_viewtoindex_footer']['value']) { ?>
<style type="text/css">
    .cart-concern-btm-fixed {
        position: fixed;
        left: 0;
        bottom: 0;
        z-index: 40;
        text-align: center;
        width: 100%;
        height: 50px;
    }

    .concern-cart:before {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 1px;
        content: '';
        -webkit-transform: scaleY(.5);
        transform: scaleY(.5);
        border-top: 1px solid #d2d2d2;
    }

    .concern-cart a,.action-list a {
        display: inline-block;
        height: 50px;
        line-height: 50px;
        float: left;
    }

    .concern-cart,.action-list {
        float: left;
    }

    .concern-cart {
        background-color: rgba(255,255,255,.9);
        position: relative;
    }

    .concern-cart a {
        color: #666666;
        font-size: 10px;
    }

    #cart1 em {
        width: 23px;
        height: 21px;
        display: block;
        margin: 0 auto;
        margin-top: 10px;
        margin-bottom: 4px;
        position: relative;
        line-height: 16px;
        color:#333;
    }
    .action-list a span {
        display: block;
        line-height: 9px;
        height: 15px;
        text-align: center;
    }
    .concern-cart a span {
        display: block;
        line-height: 9px;
        height: 15px;
        text-align: center;
    }

    .action-list a {
        color: #fff;
        font-size: 10px;
    }

    .red-color {
        background-color: <?php if($color) { ?><?php echo $color;?><?php } else { ?>#f23030<?php } ?>;
    }

    .yellow-color {
        background-color: #ffb03f;
    }

    .disabled {
        background-color: #bfbfbf!important;
    }

    .five-column .concern-cart {
        width: 47.5%;
    }

    .five-column .action-list {
        width: 52.5%;
    }

    .four-column .concern-cart {
        width: 60%;
    }

    .four-column .action-list {
        width: 40%;
    }

    .three-column .concern-cart {
        width: 62%;
    }

    .three-column .action-list {
        width: 38%;
    }

    .concern-cart a,.action-list a {
        width: 100%;
    }

    .three-column .action-list a:last-child {
        display: none;
    }

    .five-column .concern-cart a {
        width: 25%;
    }
    .messge-box-icon h1 {
        color:#ffffff;
        display:inline;
        font-size:22px;
        margin-top:5px;
    }
    .bd_null_footer{height:60px}
    
</style>
<style>
    .bd_null_footer{height:60px}
@supports (bottom: constant(safe-area-inset-bottom)) or (bottom: env(safe-area-inset-bottom)) {
.bd_null_footer{
height: calc(60px + constant(safe-area-inset-bottom));
height: calc(60px + env(safe-area-inset-bottom));
}
.cart-concern-btm-fixed{
padding-bottom: constant(safe-area-inset-bottom);
            padding-bottom: env(safe-area-inset-bottom);
            height:auto;
}

}
</style>
<div class="bd_null_footer" ></div>
<div id="cart1" class="cart-concern-btm-fixed five-column four-column" style="display: table;">
    <div class="concern-cart">
        <a class="dong-dong-icn J_ping"  id="imBottom" href="plugin.php?id=aljtc">
        <em class="iconfont icon-ziyuan"></em>
        <span class="focus-info"> 首页 </span>
        </a>
        <?php if(!$hide_mini) { ?>
        <a class="cart-car-icn" href="plugin.php?id=aljtc&amp;act=posttype">
            <em class="iconfont icon-fasong" >
            </em>
            <span class="focus-info">发布</span>
        </a>
        <?php } else { ?>
            <style>
                .four-column .concern-cart {
                    width: 50%;
                }

                .four-column .action-list {
                    width: 50%;
                }
                .five-column .concern-cart a {
                    width: 50%;
                }
            </style>
        <?php } ?>
        <a class="cart-car-icn" onclick="shoucang(<?php echo $lp['id'];?>)">
            <?php if(DB::result_first('select count(*) from %t where uid=%d and lid=%d ',array('aljtc_collection',$_G['uid'],$_GET['lid']))) { ?>
            <em class="iconfont icon-shoucang-1" ></em>
            <?php } else { ?>
            <em class="iconfont icon-ziyuan1" ></em>
            <?php } ?>
            <span class="focus-info">收藏</span>
        </a>
        <?php if($_G['cache']['plugin']['aljol'] && !$hide_mini) { ?>
        <a class="cart-car-icn" href="plugin.php?id=aljol&amp;act=talk&amp;friendid=<?php echo $lp['uid'];?>">
            
            <em class="iconfont icon-xiaoxi" ></em>
            
            <span class="focus-info">聊天</span>
        </a>
        <?php } ?>
    </div>
    <div class="action-list">
        <?php if($lp['contact']) { ?>
        <?php if($lp['solve'] !=1 || $admin_status || ($lp['expiry_time']==0 || TIMESTAMP<$lp['expiry_time'])) { ?>
            <a class="red-color login_tel" href="tel:<?php echo $lp['contact'];?>" data-id="<?php echo $lp['id'];?>" data-price="<?php if($formsetting['open_tel_price']>0 && $typeSettins['is_see_tel']<=0 && !$admin_status && $lp['uid'] != $_G['uid']) { ?><?php echo $formsetting['open_tel_price'];?><?php } else { ?>0<?php } ?>" style="transform-origin: 0px 0px 0px; opacity: 1; transform: scale(1, 1);">
                <em class="iconfont icon-dianhua4" style="color:#ffffff;"></em>
                <span class="focus-info">拨打电话</span>
            </a>
        
        <?php } else { ?>
            <a class="red-color " href="javascript:;" style="transform-origin: 0px 0px 0px; opacity: 1; transform: scale(1, 1);">
                <?php if($lp['expiry_time']>0 && TIMESTAMP>$lp['expiry_time']) { ?>已过期<?php } else { ?>已完成<?php } ?>
            </a>
        <?php } ?>
        <?php } else { ?>
        <style>
        .four-column .concern-cart {
                    width: 100%;
                }
        </style>
        <?php } ?>
    </div>
</div>
<?php } else { ?>
<style>
    .bd_null_footer{height:60px}
@supports (bottom: constant(safe-area-inset-bottom)) or (bottom: env(safe-area-inset-bottom)) {
.bd_null_footer{
height: calc(60px + constant(safe-area-inset-bottom));
height: calc(60px + env(safe-area-inset-bottom));
}
#c_main_menu{
padding-bottom: constant(safe-area-inset-bottom);
            padding-bottom: env(safe-area-inset-bottom);
            height:auto;
}

}
</style>
    <?php if($_G['cache']['plugin']['aljhtx']['is_aljtc'] && !$_G['cache']['plugin']['aljtc']['footernav'] && $_G['cache']['plugin']['aljbd']) { ?>
        <?php $settings=C::t('#aljbd#aljbd_setting')->range();
            $mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_common_footernav']['value']));
            foreach($mobile_common_footernav as $key=>$value){
                $arr=explode('|',$value);
                $mobile_common_footernav_arr[]=$arr;
            }?>        <?php include template('aljbd:footer_nav'); ?>    <?php } else { ?>
    <div class="bd_null_footer"></div>
    <div class="c_main_menu_1">
        <ul id="c_main_menu">
            <?php if($hide_mini) { ?>
                <?php include template('aljtc:A_Model/common/common_footer_nav_mini'); ?>            <?php } else { ?>
                <?php include template('aljtc:A_Model/common/common_footer_nav'); ?>            <?php } ?>
        </ul>
    </div>
    <?php } } include template('aljhtx:pay_referrer'); if($_G['cache']['plugin']['aljhb'] && $_GET['act'] && $cparray['aljhb']['available'] == 1 && $_GET['act'] != 'post' && $_GET['act'] != 'edit' && $_GET['act'] != 'attes') { include template('aljhb:red_packet'); } ?>
