<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<script>
function iframeattr(gid){
    //iframe窗
    
    layer.open({
        type: 2,
        title: '<?php echo $aljhtlang['js']['goods_1'];?>',
        shadeClose: true,
        shade: false,
        //maxmin: true, //开启最大化最小化按钮
        area: ['90%', '80%'],
        content: 'plugin.php?id=aljht&act=admin&op=goods&do=attr<?php echo $urlmod;?>&gid='+gid
    });
}
function iframeeditgoods(gid,bid){
    //iframe窗
    
    layer.open({
        type: 2,
        title: '<?php echo $aljhtlang['template']['addgoods_1'];?><?php echo $aljhtlang['template']['addgoods_3'];?>',
        shadeClose: true,
        shade: false,
        //maxmin: true, //开启最大化最小化按钮
        area: ['90%', '80%'],
        content: 'plugin.php?id=aljht&act=admin&op=goods&do=editgoods&ajax=yes&iframeeditgoods=1&bid='+bid+'<?php echo $urlmod;?>&gid='+gid
    });
}
</script>