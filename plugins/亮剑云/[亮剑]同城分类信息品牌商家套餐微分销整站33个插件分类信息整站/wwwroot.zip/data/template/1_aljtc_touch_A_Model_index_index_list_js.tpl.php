<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<script>
    var zufangtype=<?php if($lp['zufangtype']) { ?>'<?php echo $lp['zufangtype'];?>'<?php } else { ?>'0'<?php } ?>;
    var page = 1;
    var loading = false;
    $(document.body).infinite(100).on("infinite", function() {
        
        if(loading) return;
        $('#load').show();
        page++;
        loading = true;
        getdata(page,zufangtype);
    });
    function getdata(page,id) {
        var data ={
            'zufangtype':id,
            'page':page,
            'subrid':<?php if($_COOKIE['subrid']) { ?><?php echo $_COOKIE['subrid'];?><?php } else { ?>0<?php } ?>,
        }
    
        var url = 'plugin.php?id=aljtc&act=mobile_index_goods';
        <?php if($_GET['act'] == 'view' && $_GET['op'] == 'aljtc') { ?>
        <?php $ajax_url = 'plugin.php?id=aljtc&act=mobile_index_goods&uid='.intval($bd['uid']).'&bid='.intval($bd['id'])?>        url = '<?php echo $ajax_url;?>';
        <?php } ?>
        $.post(url,data,function(res) {
            if(page == 1) {
                if(res != 1) {
                    loading = false;
                    $('#load').hide();
                    $('.content').append(res);
                    $('.datacontent').append(res);
                }else {
                    $('#load').hide();
                    $('#loaded').show();
                    $('#empty').show();
                    loading = true;
                }
            }else {
                if(res != 1) {
                    loading = false;
                    $('#load').hide();
                    $('.datacontent').append(res);
                } else {
                    $('#load').hide();
                    $('#loaded').show();
                    $('#empty').show();
                    loading = true;
                }

            }
        });
    }
    getdata(1,zufangtype);
    var mySwiper = new Swiper('#topNav', {
        freeMode: true,
        slidesPerView: 'auto',
        slideToClickedSlide:true,
        observer:true,

    });
    function changedata(id,el){
        $(el).addClass('active').siblings().removeClass('active');
        $('.datacontent').html('');
        page=1;
        zufangtype = id;
        $('#load').hide();
        $('#loaded').hide();
        $('#empty').hide();
        getdata(page,id);
    }
    
</script>