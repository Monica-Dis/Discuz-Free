<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<ul class="layui-tab-title">
    <li <?php if(ACTION == 'setting' || empty($_GET['a'])) { ?>class="layui-this"<?php } ?> onclick="location.href='plugin.php?id=aljhtx&c=diy&a=setting'">手机端首页</li>
    <li <?php if(ACTION == 'my') { ?>class="layui-this"<?php } ?> onclick="location.href='plugin.php?id=aljhtx&c=diy&a=my'">我的</li>
    <li <?php if(ACTION == 'shop') { ?>class="layui-this"<?php } ?> onclick="location.href='plugin.php?id=aljhtx&c=diy&a=shop'">店铺详情页</li>
    <li onclick="location.href='plugin.php?id=aljbd&ljdiy=yes'">电脑端首页</li>
    <?php if($_G['cache']['plugin']['aljdiy']['open']) { ?>
    <li onclick="location.href='plugin.php?id=aljdiy&c=page&a=list_index&ajax=yes'">DIY专题</li>
    <?php } ?>
    <li>待开放功能</li>
</ul>