<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template(PLUGIN_ID.':admin/header')?><style type="text/css">
.board {
    background: rgba(0, 0, 0, 0) url("static/image/admincp/bg_repno.gif") no-repeat scroll -240px -550px;
    padding-left: 55px;
    position: relative;
margin-left:5px;
}
.boardnext {
    background: rgba(0, 0, 0, 0) url("static/image/admincp/bg_repno.gif") no-repeat scroll -185px -600px;
    padding-left: 110px;
    position: relative;
margin-left:5px;
}
.addtr {
background: rgba(0, 0, 0, 0) url("static/image/admincp/bg_repno.gif") no-repeat scroll 0 1px;
color: #F60;
line-height: 25px;
padding-left: 17px;
}
.deleterow {
    background: rgba(0, 0, 0, 0) url("static/image/admincp/close.gif") no-repeat scroll 0 50%;
    padding-left: 15px;
color: #fff;
    line-height: 25px;
    margin-right: 5px;

    right:90px;
    top: 6px;
}

.lj_right{padding-right: 55px;
    position: relative;}

.lj_input{
width:66%;
border-radius: 6px;
}

.sort_input{
width:50px;
float:left;
margin-right:10px;

border-radius: 6px;
text-align:center;
}

.box.box-primary {
border-top-color: #1E9FFF;
}
.btn-primary {
background-color: #1E9FFF;
border-color: #1E9FFF;
}
.breadcrumbs > li {
    display: inline-block;
 padding-right:30px;
 color: #FF6600;
}
.btn{
line-height:1.8;
margin-left:3%;
width:65px;
}
.nav > li > a {
    position: relative;
    display: block;
    padding: 12px 20px;
}
.lj-edit-a{right:10px;top: 8px;}
</style>

<div class="content-wrapper" style="margin-left:0px;background-color:#ffffff;">
<section class="content">
        <div class="row">



            <div class="col-md-12">
                <div class="box box-primary">
<div class="col-md-12" style="color: #1E9FFF;padding:10px 0px;">
<div class="col-md-1">排序</div><div class="col-md-6">活动分类</div><div class="col-md-2">分类图片</div><div class="col-md-1">操作</div>
</div>



                    <div class="box-body no-padding">
                        <div class="mailbox-messages">
                     <iframe style="display:none;" name="submitiframe"></iframe>
<form name="cpform" id="adminsettingsubmit" method="post" autocomplete="off" action="<?php echo $dourl;?>" target="submitiframe">
<input type="hidden" value="<?php echo FORMHASH;?>" name="formhash">



<?php if($type_list) { if(is_array($type_list)) foreach($type_list as $tmp_type_first) { ?><div class="row lj_row">
<div class="col-md-12">
<div class="col-md-1"><input class="form-control sort_input"  name="type_displayorder_first_old[<?php echo $tmp_type_first['id'];?>]" value="<?php echo $tmp_type_first['displayorder'];?>" title="<?php echo $tmp_type_first['type_id'];?>"></div>
<div class="col-md-6" >
<div class="form-group">
<input class="form-control lj_input" name="type_name_first_old[<?php echo $tmp_type_first['id'];?>]" value="<?php echo $tmp_type_first['subject'];?>">
</div>
</div>
<div class="col-md-2">
<img style="width:40px;" src="<?php echo $tmp_type_first['pic'];?>">
<button type="button" class="layui-btn upload-contract" style="background-color: #1E9FFF;"  data-id="<?php echo $tmp_type_first['id'];?>" id="test1"><i class="layui-icon">&#xe67c;</i>上传图片</button>
</div>
<div class="col-md-1"><a href="<?php echo A_URL;?>&ajax=yes&do=deleterow&typeid=<?php echo $tmp_type_first['id'];?>" class="deleterow"  target="submitiframe">删除</a></div>
</div>
<?php if(empty($_GET['link']) && empty($_GET['upid'])) { $type_list_second = DB::fetch_all('select * from %t where upid=%d order by displayorder',array($mall_type,$tmp_type_first['id']));?><?php if($type_list_second) { if(is_array($type_list_second)) foreach($type_list_second as $tmp_type_second) { ?><div class="col-md-12" >
<div class="col-md-1">
<input class="form-control sort_input"  name="type_displayorder_second_old[<?php echo $tmp_type_second['id'];?>][]" value="<?php echo $tmp_type_second['displayorder'];?>" title="<?php echo $tmp_type_second['id'];?>">
</div>
<div class="col-md-6">
<div class="form-group board ">
<input class="form-control lj_input" name="type_name_second_old[<?php echo $tmp_type_second['id'];?>][]" value="<?php echo $tmp_type_second['subject'];?>">
</div>
</div>
<div class="col-md-2">
<img style="width:40px;" src="<?php echo $tmp_type_second['pic'];?>">
<button type="button" class="layui-btn upload-contract" style="background-color: #1E9FFF;"  data-id="<?php echo $tmp_type_second['id'];?>" id="test1"><i class="layui-icon">&#xe67c;</i>上传图片</button>
</div>
<div class="col-md-1"><a href="<?php echo A_URL;?>&ajax=yes&do=deleterow&typeid=<?php echo $tmp_type_second['id'];?>" class="deleterow"  target="submitiframe">删除</a></div>
</div>

<?php } } } ?>


<div class="col-md-12 ">
<div class="col-md-1 ">&nbsp;</div>
<div class="col-md-7">
<div class="form-group board ">
<a href="javascript:;" onclick="addrow(this, 1,<?php echo $tmp_type_first['id'];?>)" class="addtr">添加二级商品分类</a>
</div>
</div>
</div>

</div>
<?php } } ?>

<div class="form-group ">
<div class="col-md-12 ">
<div class="form-group">
<a href="javascript:;" onclick="<?php if(empty($_GET['link'])) { ?>addrow(this,0)<?php } else { ?>addrow(this,3,<?php echo $type_upid;?>)<?php } ?>" class="addtr lj_addtr" style="margin-top:30px;margin-left:30px;">添加一级商品分类</a>
</div>
</div>
</div>

<div class="form-group"><input type="submit" class="btn btn-primary" value="提交"></div>
</form></div>


                    </div>


                </div>


            </div>


<div class="pull-right">


</div>
        </div>


    </section>

</div>
<script>
function addrow(obj,type,v){
if(type==1){
$(obj).parent().parent().parent().before('<div class="col-md-12 " ><div class="col-md-1 "><input class="form-control sort_input"  name="type_displayorder_second['+v+'][]" value=""></div><div class="col-md-7"><div class="form-group board"><input class="form-control lj_input"  name="type_name_second['+v+'][]" value=""></div></div><div class="col-md-2">&nbsp;</div><div class="col-md-2"><a href="javascript:;" class="deleterow" onclick="deleterow(this,1)">&nbsp;</a></div></div>');
}else if(type==2){
$(obj).parent().parent().parent().before('<div class="col-md-12 " ><div class="col-md-1 "><input class="form-control sort_input"  name="type_displayorder_second['+v+'][]" value=""></div><div class="col-md-7"><div class="form-group boardnext"><input class="form-control lj_input"  name="type_name_second['+v+'][]" value=""></div></div><div class="col-md-2">&nbsp;</div><div class="col-md-2"><a href="javascript:;" class="deleterow" onclick="deleterow(this,1)">&nbsp;</a></div></div>');

}else if(type==3){
$(obj).parent().parent().parent().before('<div class="col-md-12 " ><div class="col-md-1 "><input class="form-control sort_input"  name="type_displayorder_second['+v+'][]" value=""></div><div class="col-md-7"><div class="form-group "><input class="form-control lj_input"  name="type_name_second['+v+'][]" value=""></div></div><div class="col-md-2">&nbsp;</div><div class="col-md-2"><a href="javascript:;" class="deleterow" onclick="deleterow(this,1)">&nbsp;</a></div></div>');

}else{
$(obj).parent().parent().parent().before('<div class="col-md-12 " ><div class="col-md-1 "><input class="form-control sort_input"  name="type_displayorder_first[]" value=""></div><div class="col-md-7"><div class="form-group  "><input class="form-control lj_input"  name="type_name_first[]" value=""></div></div><div class="col-md-2">&nbsp;</div><div class="col-md-2"><a href="javascript:;" class="deleterow" onclick="deleterow(this,0)">&nbsp;</a></div></div>');
}
}
function deleterow(obj,type){
if(type == 1){
$(obj).parent().parent().remove();
}else{
$(obj).parent().parent().remove();
var l = $('.lj_row').length;
if(l<3){
$('.lj_addtr').show();
}
}
}
$(document).on('click', '.upload-contract', function(){
    var that = this;
    layer.open({
        type: 2,
        title: '上传分类图片',
        shadeClose: true,
        shade: false,
        maxmin: true, //开启最大化最小化按钮
        area: ['650px', '650px'],
        offset: '20px',
        content: 'plugin.php?id=aljayy&c=type&a=uploadcontract&type_id='+$(that).attr('data-id')
    });
});
</script><?php include template(PLUGIN_ID.':admin/footer')?>