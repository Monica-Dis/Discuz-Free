<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div class="div-component diyDocument" diy-id="<?php echo $diy['auto_module'];?>">
<style>
    .index_left_bottom {
        position: fixed;
        bottom: 140px;
        left: 0;
        background: rgba(0,0,0,.4);
        color: #fff;
        font-size: 12px;
        z-index: 998;
        text-align: center;
        padding: 10px 6px 10px 8px;
        letter-spacing: 1px;
        border-radius: 0 2px 2px 0;
    }
    .index_left_bottom span:first-child {
        border-top: 0;
        margin: 0;
        padding: 0;
    }
    .index_left_bottom span {
        display: block;
        border-top: 1px solid #eee;
        margin: 10px 0 0;
        padding: 10px 0 0;
    }
    </style>
    <div class="index_left_bottom">
        <?php if($_G['cache']['plugin']['aljtc']['SetPublicNumber']) { ?>
        <span onclick="$.alert('<img src=<?php echo $_G['cache']['plugin']['aljtc']['SetPublicNumber'];?> />', '长按关注公众号，随时了解最新动态');">订阅</span>
        <?php } ?>
        <?php if($_G['cache']['plugin']['aljtc']['WeChatCustomerService']) { ?>
        <span onclick="$.alert('<img src=<?php echo $_G['cache']['plugin']['aljtc']['WeChatCustomerService'];?> />', '长按添加微信客服');">客服</span>
        <?php } ?>
    </div>
</div>