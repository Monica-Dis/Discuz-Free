<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if(!$app_dowm) { ?>
<style>
.shopCart{ float:right; margin-top:35px;}
.attached-search-container .shopCart{ margin-top:12px;}
.shopCart .shopCart-con{ width:178px; height:33px; line-height:27px; border-color:#d2d2d2;}
.attached-search-container .shopCart .shopCart-con{ width:150px; height:34px; line-height:34px; border:none;}
.shopCart .shopCart-con a{ display:block; color:#f42424;}
.shopCart .shopCart-con .icon-carts{ padding-left:30px; font-size:20px;}
.shopCart .shopCart-con span{ margin-left:8px;}
.shopCart .shopCart-con .count,.attached-search-container .shopCart-con .count{ min-width:13px; height:13px; line-height:13px; padding:1px; border-radius:50%; background:#f42424; color:#fff; position:absolute; top:6px; left:122px; text-align:center; font-size:12px;}
.attached-search-container .shopCart-con .count{left:40px;top:0px}
.shopCart .dorpdown-layer{ top:35px; width:312px;}
.shopCart .prompt{ padding:20px 20px 20px 36px;}
.shopCart .prompt .nogoods{ overflow:hidden;}
.shopCart .prompt b{ background:url(source/plugin/aljbd/template/index/images/cart-nogoods.png) no-repeat; display:block; width:110px; height:68px; float:left;}
.shopCart .prompt span{ float:left; display:block; font-size:12px; color:#8c8c8c; margin:6px 0 0 14px; line-height:25px; width:132px;}
.shopCart .dorpdown-layer .load{ width:108px; height:108px; margin-left:100px;}
.dsc-cm {
position: relative;
border: 1px solid #eee;
height: 28px;
line-height: 28px;
z-index: 1;
}
.dorpdown-layer {
display: none;
position: absolute;
border: 1px solid #d2d2d2;
background-color: #fff;
top: 30px;
right: 0;
}
.hover {
z-index: 22;
position: relative;
}
.hover .dorpdown-layer {
display: block;
}
.hover .dsc-cm {
padding-bottom: 2px;
border-color: #ccc;
border-bottom: none;
background-color: #fff;
}
.settleup-content{ position:relative; width:100%; z-index:2; background:#fff;}
.settleup-content .mc{ height:auto; max-height:334px; overflow:auto;}
.settleup-content ul{ margin-top:-1px;}
.settleup-content li{ padding:10px; border-top: 1px dashed #ccc; overflow: hidden; line-height: 18px; vertical-align: bottom;}
.settleup-content li:hover{ background-color:#f5f5f5;}
.settleup-content .c-p-img{ float:left; width:50px; height:50px; border:1px solid #d3d3d3; padding:0; margin-right:8px; font-size:0;}
.settleup-content .p-name{ float:left; width:100px; height:36px; overflow:hidden; margin:5px 8px 0 0;}
.settleup-content .p-number{ float:left; margin-top:9px;}
.settleup-content .p-number .num{ width:23px; height:28px; line-height:28px; border:1px solid #d6d6d6; display:block; float:left; text-align:center;}
.settleup-content .p-number .count{ float:left; height:28px; width:18px; border-top:1px solid #d6d6d6; border-bottom:1px solid #d6d6d6;}
.settleup-content .p-number .count a{ display:block; width:18px; height:14px; border-right:1px solid #d6d6d6; text-align:center;}
.settleup-content .p-number .count .count-add{ border-bottom:1px solid #d6d6d6;}
.settleup-content .p-number .count .iconfont{ font-size:12px; display:block; height:14px;}
.settleup-content .p-oper{ float:right; text-align:center; margin-top:5px;}
.settleup-content .p-oper .price{ font-weight:700;}

.settleup-content .mb{ padding:10px; background-color:#eee; overflow:hidden;}
.settleup-content .p-total{ float:left; line-height:28px; color:#999;}
.settleup-content .btn-cart{ display:block; float:right; width:96px; height:26px; line-height:26px; border:1px solid #f42424; background:#eee; text-align:center; color:#f42424;}
.settleup-content .btn-cart:hover{ background-color:#f42424; color:#fff;}

</style><?php $cart_all=C::t('#aljbdx#aljgwc')->fetch_all_by_uid($_G['uid'],$_GET['shop_id']);?><div class="shopCart" >
<div class="shopCart-con dsc-cm">
<a href="plugin.php?id=aljbdx&amp;act=cart&amp;pluginid=<?php echo $pluginid;?>">
<i class="iconfont icon-carts"><img src="source/plugin/aljbd/template/index/images/cart.png" width="20"/></i>
<span>我的购物车</span>
<em class="count cart_num"><?php echo count($cart_all);?></em>
</a>
</div>
<div class="dorpdown-layer" ectype="dorpdownLayer">
<?php if($cart_all) { ?>
<div class="settleup-content">
<div class="mc">
<ul><?php if(is_array($cart_all)) foreach($cart_all as $val) { $header_cart=C::t('#aljbd#aljbd_goods')->fetch($val['goods_id']);?><li>
<div class="c-p-img">
<a href="plugin.php?id=<?php echo $pluginid;?>&amp;act=goodview&amp;bid=<?php echo $val['shop_id'];?>&amp;gid=<?php echo $val['goods_id'];?>" target="_blank">
<img src="<?php echo $header_cart['pic1'];?>" width="50" height="50">
</a>
</div>
<div class="p-name"><a href="plugin.php?id=<?php echo $pluginid;?>&amp;act=goodview&amp;bid=<?php echo $val['shop_id'];?>&amp;gid=<?php echo $val['goods_id'];?>" target="_blank" title="<?php echo $header_cart['name'];?>"><?php echo $header_cart['name'];?></a></div>
<div class="p-oper">
<div class="price"><em><?php echo $price_unit;?></em><?php echo $header_cart['price1'];?></div>
<a href="plugin.php?id=aljbdx&amp;act=delcart&amp;cart_id=<?php echo $val['id'];?>&amp;formhash=<?php echo FORMHASH;?>&amp;pluginid=<?php echo $pluginid;?>"  class="remove" onClick="showDialog('您确定要删除吗？', 'confirm', '', 'window.location=\''+this.href+'\'');return false;">删除</a>
</div>
</li>
<?php } ?>
</ul>
</div>
<div class="mb">
<a href="plugin.php?id=aljbdx&amp;act=cart&amp;pluginid=<?php echo $pluginid;?>" class="btn-cart">查看我的购物车</a>
</div>
</div>
<?php } else { ?>
<div class="prompt"><div class="nogoods"><b></b><span>暂时没有商品</span></div></div>
<?php } ?>
</div>
<script>
        lj_jq(".shopCart").hover(function(){
            lj_jq(this).addClass('hover');
        },function(){
            lj_jq(this).removeClass('hover');
        });
</script>
</div>
<?php } ?>