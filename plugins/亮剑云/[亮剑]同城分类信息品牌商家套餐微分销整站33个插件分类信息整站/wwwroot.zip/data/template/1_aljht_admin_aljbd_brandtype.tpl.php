<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template('aljht:admin/iframe_header_common'); ?><div class="content-wrapper" >
<section class="content">
        <div class="row">
<?php if($_GET['ajax'] != 'yes') { include template('aljht:admin/aljbd/aljbd_status'); } ?>
<div class="col-md-<?php if($_GET['ajax'] != 'yes') { ?>10<?php } else { ?>12<?php } ?>" style="padding-left: 0px;">
<div class="col-md-12">
<ul class="nav nav-tabs" role="tablist" >
<li <?php if(!$_GET['status']) { ?>class="active"<?php } ?>><a href="<?php echo $dourl;?><?php echo $urlmod;?>&link=1">店铺</a></li>
<li <?php if($_GET['status'] == 'goods') { ?>class="active"<?php } ?>><a href="<?php echo $dourl;?>&status=goods&link=1<?php echo $urlmod;?>">商品</a></li>
<li <?php if($_GET['status'] == 'consume') { ?>class="active"<?php } ?>><a href="<?php echo $dourl;?>&status=consume<?php echo $urlmod;?>">优惠券</a></li>
<li <?php if($_GET['status'] == 'notice') { ?>class="active"<?php } ?>><a href="<?php echo $dourl;?>&status=notice<?php echo $urlmod;?>">商情</a></li>
<?php if($_G['cache']['plugin']['aljsp']) { ?>
<li <?php if($_GET['status'] == 'video') { ?>class="active"<?php } ?>><a href="<?php echo $dourl;?>&status=video<?php echo $urlmod;?>">视频</a></li>
<?php } ?>
</ul>
</div>

<div class="col-md-12">
<div class="box box-primary">
<style>
.btn-border{
border: 1px solid #ddd;
padding: 5px 10px;
margin-right: 10px;
}
.col-md-1_5 {
width: 12.45%;
float: left;
min-height: 1px;
padding-right: 15px;
padding-left: 15px;
}
.col-md-6 p{text-align: center}
.tarea{z-index: 1;margin-bottom: 10px;}
</style>
<div class="itemtitle">
<h3>

</h3>
<ul class="tab1">

<?php if(!$_GET['status']) { ?>
<li >
<a class="btn-border" style="border: 1px solid red;" onclick="layer_confirm('&#24744;&#30830;&#35748;&#35201;&#28165;&#31354;&#21830;&#23478;&#20998;&#31867;&#34920;&#21527;&#65311;','<?php echo $dourl;?>&ord=emptytable&totable=aljbd_type<?php echo $urlmod;?>')" href="javascript:;">
<span style="color:red;">&#28165;&#31354;&#21830;&#23478;&#20998;&#31867;</span>
</a>
</li>
<li >
<a class="btn-border" target="submitiframe" href="<?php echo $dourl;?>&ord=import&gotable=aljbd_type_goods&totable=aljbd_type<?php echo $urlmod;?>">
<span>&#23548;&#20837;&#21830;&#21697;&#20998;&#31867;</span>
</a>
</li>
<li >
<a class="btn-border" target="submitiframe" href="<?php echo $dourl;?>&ord=import&gotable=aljbd_type_consume&totable=aljbd_type<?php echo $urlmod;?>">
<span>&#23548;&#20837;&#20248;&#24800;&#21048;&#20998;&#31867;</span>
</a>
</li>
<li >
<a class="btn-border" target="submitiframe" href="<?php echo $dourl;?>&ord=import&gotable=aljbd_type_notice&totable=aljbd_type<?php echo $urlmod;?>">
<span>&#23548;&#20837;&#27963;&#21160;&#20998;&#31867;</span>
</a>
</li>
<?php } elseif($_GET['status']=='goods') { ?>
<li >
<a class="btn-border" style="border: 1px solid red;" onclick="layer_confirm('&#24744;&#30830;&#35748;&#35201;&#28165;&#31354;&#21830;&#21697;&#20998;&#31867;&#34920;&#21527;&#65311;','<?php echo $dourl;?>&ord=emptytable&totable=aljbd_type_goods&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>')" href="javascript:;">
<span style="color:red;">&#28165;&#31354;&#21830;&#21697;&#20998;&#31867;</span>
</a>
</li>
<li >
<a class="btn-border" target="submitiframe" href="<?php echo $dourl;?>&ord=import&gotable=aljbd_type&totable=aljbd_type_goods&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>">
<span>&#23548;&#20837;&#21830;&#23478;&#20998;&#31867;</span>
</a>
</li>
<li >
<a class="btn-border" target="submitiframe" href="<?php echo $dourl;?>&ord=import&gotable=aljbd_type_consume&totable=aljbd_type_goods&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>">
<span>&#23548;&#20837;&#20248;&#24800;&#21048;&#20998;&#31867;</span>
</a>
</li>
<li >
<a class="btn-border" target="submitiframe" href="<?php echo $dourl;?>&ord=import&gotable=aljbd_type_notice&totable=aljbd_type_goods&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>">
<span>&#23548;&#20837;&#27963;&#21160;&#20998;&#31867;</span>
</a>
</li>
<?php } elseif($_GET['status']=='consume') { ?>
<li >
<a class="btn-border" style="border: 1px solid red;" onclick="layer_confirm('&#24744;&#30830;&#35748;&#35201;&#28165;&#31354;&#20248;&#24800;&#21048;&#20998;&#31867;&#34920;&#21527;&#65311;','<?php echo $dourl;?>&ord=emptytable&totable=aljbd_type_consume&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>');" href="javascript:;">
<span style="color:red;">&#28165;&#31354;&#20248;&#24800;&#21048;&#20998;&#31867;</span>
</a>
</li>
<li >
<a class="btn-border" target="submitiframe" href="<?php echo $dourl;?>&ord=import&gotable=aljbd_type&totable=aljbd_type_consume&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>">
<span>&#23548;&#20837;&#21830;&#23478;&#20998;&#31867;</span>
</a>
</li>
<li >
<a class="btn-border" target="submitiframe" href="<?php echo $dourl;?>&ord=import&gotable=aljbd_type_goods&totable=aljbd_type_consume&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>">
<span>&#23548;&#20837;&#21830;&#21697;&#20998;&#31867;</span>
</a>
</li>
<li >
<a class="btn-border" target="submitiframe" href="<?php echo $dourl;?>&ord=import&gotable=aljbd_type_notice&totable=aljbd_type_consume&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>">
<span>&#23548;&#20837;&#27963;&#21160;&#20998;&#31867;</span>
</a>
</li>
<?php } elseif($_GET['status']=='notice') { ?>
<li >
<a class="btn-border" style="border: 1px solid red;" onclick="layer_confirm('&#24744;&#30830;&#35748;&#35201;&#28165;&#31354;&#27963;&#21160;&#20998;&#31867;&#34920;&#21527;&#65311;','<?php echo $dourl;?>&ord=emptytable&totable=aljbd_type_notice&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>');" href="javascript:;">
<span style="color:red;">&#28165;&#31354;&#27963;&#21160;&#20998;&#31867;</span>
</a>
</li>
<li >
<a class="btn-border" target="submitiframe" href="<?php echo $dourl;?>&ord=import&gotable=aljbd_type&totable=aljbd_type_notice&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>">
<span>&#23548;&#20837;&#21830;&#23478;&#20998;&#31867;</span>
</a>
</li>
<li >
<a class="btn-border" target="submitiframe" href="<?php echo $dourl;?>&ord=import&gotable=aljbd_type_goods&totable=aljbd_type_notice&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>">
<span>&#23548;&#20837;&#21830;&#21697;&#20998;&#31867;</span>
</a>
</li>
<li >
<a class="btn-border" target="submitiframe" href="<?php echo $dourl;?>&ord=import&gotable=aljbd_type_consume&totable=aljbd_type_notice&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>">
<span>&#23548;&#20837;&#20248;&#24800;&#21048;&#20998;&#31867;</span>
</a>
</li>
<?php } elseif($_GET['status']=='video') { ?>
<li >
<a class="btn-border" style="border: 1px solid red;" onclick="layer_confirm('您确认要清空视频分类表吗？','<?php echo $dourl;?>&ord=emptytable&totable=aljbd_type_video&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>');" href="javascript:;">
<span style="color:red;">清空视频分类</span>
</a>
</li>
<li >
<a class="btn-border" target="submitiframe" href="<?php echo $dourl;?>&ord=import&gotable=aljbd_type&totable=aljbd_type_video&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>">
<span>&#23548;&#20837;&#21830;&#23478;&#20998;&#31867;</span>
</a>
</li>
<li >
<a class="btn-border" target="submitiframe" href="<?php echo $dourl;?>&ord=import&gotable=aljbd_type_goods&totable=aljbd_type_video&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>">
<span>&#23548;&#20837;&#21830;&#21697;&#20998;&#31867;</span>
</a>
</li>
<li >
<a class="btn-border" target="submitiframe" href="<?php echo $dourl;?>&ord=import&gotable=aljbd_type_consume&totable=aljbd_type_video&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>">
<span>&#23548;&#20837;&#20248;&#24800;&#21048;&#20998;&#31867;</span>
</a>
</li>
<li >
<a class="btn-border" target="submitiframe" href="<?php echo $dourl;?>&ord=import&gotable=aljbd_type_notice&totable=aljbd_type_video&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>">
<span>导入商情分类</span>
</a>
</li>
<?php } ?>
</ul>

</div>
<div class="col-md-12" style="color: #3c8dbc;padding:10px 0px;">
<div class="col-md-1">排序</div>
<?php if($_GET['status'] == 'goods') { ?>
<div class="col-md-2">分类</div><div class="col-md-2">LOGO</div><div class="col-md-1_5">pc推荐标签</div><div class="col-md-1_5">推荐品牌</div><div class="col-md-1_5">轮转广告</div>
<?php } else { ?>
<div class="col-md-7">分类</div><div class="col-md-1_5">分类ID</div>
<?php } ?>
<div class="col-md-1_5">链接</div>
<div class="col-md-1">操作</div>
</div>



<div class="box-body no-padding">
<div class="mailbox-messages">
 <iframe style="display:none;" name="submitiframe"></iframe>
<form name="cpform" id="adminsettingsubmit" enctype="multipart/form-data" method="post" autocomplete="off" action="<?php echo $dourl;?>&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>" target="submitiframe">
<input type="hidden" value="<?php echo FORMHASH;?>" name="formhash">



<?php if($list) { if(is_array($list)) foreach($list as $tmp_first) { ?><div class="row lj_row">
<div class="col-md-12">
<div class="col-md-1"><input class="form-control sort_input"  name="displayorder_first_old[<?php echo $tmp_first['id'];?>]" value="<?php echo $tmp_first['displayorder'];?>"></div>
<?php if($_GET['status'] == 'goods') { ?>
<div class="col-md-2">
<div class="form-group">
<input class="form-control" name="subject_first_old[<?php echo $tmp_first['id'];?>]" value="<?php echo $tmp_first['subject'];?>">
</div>
</div>
<div class="col-md-2">

<div class="row">
<div class="col-md-6">
<div class="form-group">
<div class="btn btn-default btn-file">
<i class="fa fa-file-image-o"></i>LOGO<input type="file" name="logo_first_old[<?php echo $tmp_first['id'];?>]" id="logo_first_old_<?php echo $tmp_first['id'];?>" onchange="lrz_mobile('logo_first_old','<?php echo $tmp_first['id'];?>',this)">
</div>
</div>
</div>
<div class="col-md-6">
<p id="img_logo_first_old_<?php echo $tmp_first['id'];?>" ><?php if($tmp_first['logo']) { ?><img style="background-color: rgba(0,0,0,0.1);" src="<?php echo $tmp_first['logo'];?>" width="20px" height="20px"><a href="javascript:;" onclick="delete_img('<?php echo $tmp_first['id'];?>')" class="upload_delete bw_delimg"><img src="source/plugin/aljht/static/img/img_close.png" width="20"></a><?php } ?></p>
</div>
</div>

</div>
<?php if(!$_GET['level']) { ?>
<div class="col-md-1_5">
<div class="form-group">
<textarea ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)" name="pclabel_first_old[<?php echo $tmp_first['id'];?>]" class="form-control tarea" placeholder="格式：文字|链接，一行一个"><?php echo $tmp_first['pclabel'];?></textarea>
</div>
</div>
<div class="col-md-1_5">
<div class="form-group">
<textarea ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)" name="brand_id_first_old[<?php echo $tmp_first['id'];?>]" class="form-control tarea" placeholder="填写商家ID,多个以英文逗号分隔,分类下方调用显示"><?php echo $tmp_first['brand_id'];?></textarea>
</div>
</div>
<div class="col-md-1_5">
<div class="form-group">
<textarea ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)" name="type_ad_first_old[<?php echo $tmp_first['id'];?>]" class="form-control tarea" placeholder="格式：图片路径|图片链接|图片描述，一行一个"><?php echo $tmp_first['type_ad'];?></textarea>
</div>
</div>
<?php } else { ?>
<div class="col-md-1_5"></div><div class="col-md-1_5"></div><div class="col-md-1_5"></div>
<?php } } else { ?>
<div class="col-md-7" >
<div class="form-group">
<input class="form-control " name="subject_first_old[<?php echo $tmp_first['id'];?>]" value="<?php echo $tmp_first['subject'];?>">
</div>
</div>
<div class="col-md-1_5">
<?php echo $tmp_first['id'];?>
</div>
<?php } ?>
<div class="col-md-1_5">
<textarea ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)" name="type_url_first_old[<?php echo $tmp_first['id'];?>]" class="form-control tarea" placeholder="自定义跳转链接"><?php echo $tmp_first['type_url'];?></textarea>
</div>
<div class="col-md-1" style="text-align: center;">
<a href="<?php echo $dourl;?>&ord=deleterow&type_id=<?php echo $tmp_first['id'];?>&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>" onclick="if(confirm('&#24744;&#30830;&#35748;&#35201;&#21024;&#38500;&#35813;&#20998;&#31867;&#21527;&#65311;')){return true;}else{return false;}" target="submitiframe">删除</a>
<br/>
<?php if($tmp_first['is_open'] == 1) { ?>
<a href="<?php echo $dourl;?>&ord=open&type_id=<?php echo $tmp_first['id'];?>&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>&oid=0"  target="submitiframe">开启</a>
<?php } else { ?>
<a href="<?php echo $dourl;?>&ord=open&type_id=<?php echo $tmp_first['id'];?>&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>&oid=1" style="color:red;" target="submitiframe">关闭</a>
<?php } ?>
</div>
</div>
<?php if(empty($_GET['link']) && empty($_GET['upid'])) { $list_second = DB::fetch_all('select * from %t where upid=%d order by displayorder',array($mall_type,$tmp_first['id']));?><?php if($list_second) { if(is_array($list_second)) foreach($list_second as $tmp_second) { ?><div class="col-md-12" >
<div class="col-md-1">
<input class="form-control sort_input"  name="displayorder_second_old[<?php echo $tmp_second['id'];?>][]" value="<?php echo $tmp_second['displayorder'];?>">
</div>

<div class="col-md-7">
<div class="form-group board ">
<input class="form-control " name="subject_second_old[<?php echo $tmp_second['id'];?>][]" value="<?php echo $tmp_second['subject'];?>">
</div>
</div>
<div class="col-md-1_5">
<?php echo $tmp_second['id'];?>

</div>
<div class="col-md-1_5">
<textarea ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)" name="type_url_first_old[<?php echo $tmp_second['id'];?>]" class="form-control tarea" placeholder="自定义跳转链接"><?php echo $tmp_second['type_url'];?></textarea>
</div>
<div class="col-md-1"><a style="left: 20%;" href="<?php echo $dourl;?>&ord=deleterow&type_id=<?php echo $tmp_second['id'];?>&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>" class="deleterow"  target="submitiframe">删除</a></div>
</div><?php $list_third = DB::fetch_all('select * from %t where upid=%d order by displayorder',array($mall_type,$tmp_second['id']));?><?php if($list_third  && ($_GET['status'] == 'goods' || $_GET['status'] == 'video' || !$_GET['status'])) { if(is_array($list_third)) foreach($list_third as $tmp_third) { ?><div class="col-md-12" >
<div class="col-md-1"><input class="form-control sort_input"  name="displayorder_second_old[<?php echo $tmp_third['id'];?>][]" value="<?php echo $tmp_third['displayorder'];?>"></div>
<?php if($_GET['status'] == 'goods') { ?>
<div class="col-md-2">
<div class="form-group boardnext ">
<input class="form-control " name="subject_second_old[<?php echo $tmp_third['id'];?>][]" value="<?php echo $tmp_third['subject'];?>">
</div>
</div>
<div class="col-md-2">
<div class="row">
<div class="col-md-10">
<div class="form-group">
<div class="btn btn-default btn-file">
<i class="fa fa-file-image-o"></i>LOGO<input type="file" name="logo_third_old[<?php echo $tmp_third['id'];?>]" id="logo_third_old_<?php echo $tmp_third['id'];?>" onchange="lrz_mobile('logo_third_old','<?php echo $tmp_third['id'];?>',this)">
</div>
</div>
</div>
<div class="col-md-2">
<p id="img_logo_third_old_<?php echo $tmp_third['id'];?>"><?php if($tmp_third['logo']) { ?><img src="<?php echo $tmp_third['logo'];?>" width="40px" height="40px"><a href="javascript:;" onclick="delete_img('<?php echo $tmp_third['id'];?>')" class="upload_delete bw_delimg"><img src="source/plugin/aljht/static/img/img_close.png" width="20"></a><?php } ?></p>
</div>
</div>
</div>
<div class="col-md-1_5">

</div>
<div class="col-md-1_5">

</div>
<?php } else { ?>
<div class="col-md-7">
<div class="form-group boardnext ">
<input class="form-control lj_input" name="subject_second_old[<?php echo $tmp_third['id'];?>][]" value="<?php echo $tmp_third['subject'];?>">
</div>
</div>
<div class="col-md-1_5">
<?php echo $tmp_third['id'];?>
</div>
<?php } ?>

<div class="col-md-1_5">
<textarea ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)" name="type_url_first_old[<?php echo $tmp_third['id'];?>]" class="form-control tarea" placeholder="自定义跳转链接"><?php echo $tmp_third['type_url'];?></textarea>
</div>
<div class="col-md-1">
<a style="left: 20%;" href="<?php echo $dourl;?>&ord=deleterow&type_id=<?php echo $tmp_third['id'];?>&status=<?php echo $_GET['status'];?><?php echo $urlmod;?>" class="deleterow"  target="submitiframe">删除</a>
</div>
</div>
<?php } } if($maxlevel == 3) { ?>
<div class="col-md-12 ">
<div class="col-md-1 ">&nbsp;</div>
<div class="col-md-7">
<div class="form-group boardnext ">
<a href="javascript:;" onclick="addrow(this, 2,<?php echo $tmp_second['id'];?>)" class="addtr">添加三级</a>
</div>
</div>
</div>
<?php } } } } if($level<$maxlevel || $_GET['status']=='notice' || $_GET['status']=='consume' || $_GET['status']=='video') { ?>
<div class="col-md-12 ">
<div class="col-md-1 ">&nbsp;</div>
<div class="col-md-7">
<div class="form-group board ">
<a <?php if(empty($_GET['link'])) { ?>href="javascript:;" onclick="addrow(this, 1,<?php echo $tmp_first['id'];?>)"<?php } else { ?>href="<?php echo $dourl;?>&status=<?php echo $_GET['status'];?>&upid=<?php echo $tmp_first['id'];?>&level=<?php echo $level+1?>&link=<?php echo intval($_GET['link']);?><?php echo $urlmod;?>"<?php } ?> class="addtr"><?php if(empty($_GET['link'])) { ?>添加二级<?php } else { ?>添加或查看下一级分类<?php } ?></a>
</div>
</div>
</div>
<?php } ?>
</div>
<?php } } ?>

<div class="form-group ">
<div class="col-md-12 ">
<div class="form-group">
<a href="javascript:;" onclick="<?php if(empty($_GET['link'])) { ?>addrow(this,0)<?php } else { ?>addrow(this,3,<?php echo $upid;?>)<?php } ?>" class="addtr lj_addtr" >添加</a>
</div>
</div>
</div>

<div class="form-group"><input type="submit" class="btn btn-primary submit_bin" value="提交"></div>
</form></div>


</div>


</div>


</div>


<div class="pull-right">

<div class="btn-group">
  <?php echo $paging;?>
</div>


</div>
</div>
</div>


    </section>

</div>
<script src="<?php echo $path;?>/static/js/lrz.mobile.min.js" type="text/javascript"></script>
<script>
function layer_confirm(text,url) {
        layer.confirm(text, {
            btn: ['确认','取消'] //按钮
        }, function(){
            location.href=url
        })
    }
function addrow(obj,type,v){
if(type==1){
$(obj).parent().parent().parent().before('<div class="col-md-12 " ><div class="col-md-1 "><input class="form-control sort_input"  name="displayorder_second['+v+'][]" value=""></div><div class="col-md-7"><div class="form-group board"><input class="form-control lj_input"  name="subject_second['+v+'][]" value=""></div></div><div class="col-md-2">&nbsp;</div><div class="col-md-2"><a href="javascript:;" class="deleterow" onclick="deleterow(this,1)">&nbsp;</a></div></div>');
}else if(type==2){
$(obj).parent().parent().parent().before('<div class="col-md-12 " ><div class="col-md-1 "><input class="form-control sort_input"  name="displayorder_second['+v+'][]" value=""></div><div class="col-md-7"><div class="form-group boardnext"><input class="form-control lj_input"  name="subject_second['+v+'][]" value=""></div></div><div class="col-md-2">&nbsp;</div><div class="col-md-2"><a href="javascript:;" class="deleterow" onclick="deleterow(this,1)">&nbsp;</a></div></div>');

}else if(type==3){
$(obj).parent().parent().parent().before('<div class="col-md-12 " ><div class="col-md-1 "><input class="form-control sort_input"  name="displayorder_second['+v+'][]" value=""></div><div class="col-md-7"><div class="form-group "><input class="form-control lj_input"  name="subject_second['+v+'][]" value=""></div></div><div class="col-md-2">&nbsp;</div><div class="col-md-2"><a href="javascript:;" class="deleterow" onclick="deleterow(this,1)">&nbsp;</a></div></div>');

}else{
$(obj).parent().parent().parent().before('<div class="col-md-12 " ><div class="col-md-1 "><input class="form-control sort_input"  name="displayorder_first[]" value=""></div><div class="col-md-7"><div class="form-group  "><input class="form-control lj_input"  name="subject_first[]" value=""></div></div><div class="col-md-2">&nbsp;</div><div class="col-md-2"><a href="javascript:;" class="deleterow" onclick="deleterow(this,0)">&nbsp;</a></div></div>');
}	
}
function deleterow(obj,type){
if(type == 1){
$(obj).parent().parent().remove();
}else{
$(obj).parent().parent().parent().remove();
var l = $('.lj_row').length;
if(l<3){
$('.lj_addtr').show();
}
}
}
function tips(info,url){
    layer.closeAll('loading');
    if(info == 0){
        layer.alert('<?php echo $aljhtlang['js']['brand_6'];?>', {icon: 6},function(){
            location.href=location.href;
        });
    }else{
        if(url){
            layer.alert(info, {icon: 6},function(){
                location.href=url;
            });
        }else{
            layer.alert(info, {icon: 6},function(){
                location.href=location.href;
            });
        }
    }
}
function lrz_mobile(name,id,evt){
    file = evt.files[0];

    if (!file.type.match('image.*')) {
        alert('<?php echo $imgmes;?>');
    }

    lrz(file, {
        before: function() {
            //console.log('start');
        },
        fail: function(err) {
            console.error(err);
        },
        always: function() {
            //console.log('end');
        },
        done: function (results) {
            $('#img_'+name+'_'+id).html('<br/>\u4e0a\u4f20\u4e2d\u8bf7\u7a0d\u540e<img src="static/image/common/loading.gif"/>');

            $('#img_'+name+'_'+id).html('<br/><img src="'+results.base64+'" width="20px" height="20px"><input type="hidden" name="'+name+'['+id+']"  value="'+results.base64+'"><a href="javascript:;" onclick="delattach(\''+name+'\',\''+id+'\')" class="upload_delete bw_delimg" id="upload_delete_0" data-index="0"><img src="<?php echo $path;?>/static/img/img_close.png" width="20"></a>');
        }})
}
function delattach(name,id){
    $('#img_'+name+'_'+id).html('<br/>');
    $('#'+name+'_'+id).html('<input type="file" name="'+id+'" style="width:200px;"  onchange="lrz_mobile(\''+name+'\',\''+id+'\',this)">');
}
function delete_img(typeid){
layer.confirm('确认要删除分类图片吗', {
btn: ['确认','取消'] //按钮
}, function(){
layer.msg('删除中', {
icon: 16
,shade: 0.01
});
$.post('<?php echo $dourl;?>&ord=deleteimg',{"typeid":typeid,'formhash':'<?php echo FORMHASH;?>','status':'<?php echo $_GET['status'];?>'},function(data){
layer.closeAll('loading');
if(data == 1){
layer.msg('删除成功',function(){
location.reload();
});
}else{
layer.msg('删除失败，请重试！');
}

});
})
}
    var BROWSER = {};
    var USERAGENT = navigator.userAgent.toLowerCase();
    browserVersion({'ie':'msie','firefox':'','chrome':'','opera':'','safari':'','mozilla':'','webkit':'','maxthon':'','qq':'qqbrowser','rv':'rv'});
    if(BROWSER.safari || BROWSER.rv) {
        BROWSER.firefox = true;
    }
    BROWSER.opera = BROWSER.opera ? opera.version() : 0;

    HTMLNODE = document.getElementsByTagName('head')[0].parentNode;
    if(BROWSER.ie) {
        BROWSER.iemode = parseInt(typeof document.documentMode != 'undefined' ? document.documentMode : BROWSER.ie);
        HTMLNODE.className = 'ie_all ie' + BROWSER.iemode;
    }
    var heightag = BROWSER.chrome ? 4 : 0;
    function textareakey(obj, event) {
        if(event.keyCode == 9) {
            insertunit(obj, '\t');
            doane(event);
        }
    }
    function browserVersion(types) {
        var other = 1;
        for(i in types) {
            var v = types[i] ? types[i] : i;
            if(USERAGENT.indexOf(v) != -1) {
                var re = new RegExp(v + '(\\/|\\s|:)([\\d\\.]+)', 'ig');
                var matches = re.exec(USERAGENT);
                var ver = matches != null ? matches[2] : 0;
                other = ver !== 0 && v != 'mozilla' ? 0 : other;
            }else {
                var ver = 0;
            }
            eval('BROWSER.' + i + '= ver');
        }
        BROWSER.other = other;
    }
    function textareasize(obj, op) {
        if(!op) {
            if(obj.scrollHeight > 70) {
                obj.style.height = (obj.scrollHeight < 300 ? obj.scrollHeight - heightag: 300) + 'px';
                if(obj.style.position == 'absolute') {
                    obj.parentNode.style.height = (parseInt(obj.style.height) + 20) + 'px';
                }
            }
        } else {
            if(obj.style.position == 'absolute') {
                obj.style.position = '';
                obj.style.width = '';
                obj.parentNode.style.height = '';
            } else {
                obj.parentNode.style.height = obj.parentNode.offsetHeight + 'px';
                obj.style.width = BROWSER.ie > 6 || !BROWSER.ie ? '90%' : '600px';
                obj.style.position = 'absolute';
            }
        }
    }
</script><?php include template($pluginid.':admin/footer')?>