<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<tr ><th class="partition" colspan="15" >&#24494;&#20449;&#23567;&#31243;&#24207;</th></tr>

<tr><td colspan="2" class="td27" s="1">&#24320;&#21551;&#23567;&#31243;&#24207;&#23457;&#26680;&#27169;&#24335;</td></tr>
<tr class="noborder">
    <td class="vtop rowform" s="1">
        <ul onmouseover="altStyle(this);">
            <li class="checked">
                <input type="radio"  value="1"  <?php if($settings['mini_hide']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[mini_hide]" class="radio">&nbsp;&#26159;
            </li>
            <li><input type="radio" value="0" <?php if($settings['mini_hide']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[mini_hide]" class="radio">&nbsp;&#21542;</li>
        </ul>
        <br>
    </td>
    <td>&#24320;&#21551;&#21518;&#26174;&#31034;&#40664;&#35748;&#24213;&#37096;&#24182;&#38544;&#34255;&#21457;&#24067;&#12289;&#21830;&#23478;&#31561;&#23637;&#31034;&#65292;&#26041;&#20415;&#23567;&#31243;&#24207;&#36807;&#23457;</td>
</tr>