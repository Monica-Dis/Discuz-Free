<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if(($_G['cache']['plugin']['aljbdx']['is_aljqb'] || $_G['cache']['plugin']['aljgwc']['aljbd']) && $_G['cache']['plugin'][$pluginid]['is_daohang']) { ?>
<style>
    .w:after, .w:before {
        content: ".";
        display: block;
        height: 0;
        clear: both;
        visibility: hidden;
    }
    .footer-new{ background-color:#eee; margin-top:80px; overflow:hidden;}
    .home_visual_body .footer-new,.topic_visual_body .footer-new,.store_visual_body .footer-new,.bonusBody .footer-new{ margin:0;}

    .footer-new-con,.footer-new-bot{ background-color:#262626;}
    .f-icon{  display:inline-block;}

    .footer-new-top{ padding:24px 0;}
    .footer-new-top .service-list{ overflow:hidden; float:left;}
    .footer-new-top .contact-lj{ float:right;}

    .service-list .service-item{ float:left; width:170px; height:32px; line-height:30px; overflow:hidden; padding-right:10px; }

    .service-list .service-item .f-icon{ width:32px; height:32px; float:left;}
    .service-list .service-item span{ float:left; font-size:18px; color:#888888; margin-left:12px;}
    .service-list .service-item img{width: 32px;}
    .contact-lj .contact-item{ float:left; height:32px; line-height:30px;}
    .contact-lj .contact-item.contact-item-first{}
    .contact-lj .contact-item .f-icon-tel{ width:22px; height:24px; float:left; margin-top:4px;}
    .contact-lj .contact-item .f-icon-kefu{ width:27px; height:24px; float:left; margin-top:4px;}
    .contact-lj .contact-item span{ float:left; color:#262626; font-size:16px; font-weight:bold; margin-left:8px; overflow:hidden}

    .contact-lj .contact-item.contact-item-first span{ width:140px; margin-right:10px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;}

    .footer-new-con .fnc-warp{ padding:30px 0; width:1200px; margin:0 auto; border-bottom:1px solid #464646; overflow:hidden;}
    .footer-new-con .help-list{ float:left; width:900px;}
    .footer-new-con .help-list .help-item{ float:left; width:170px; padding-right:10px;}
    .footer-new-con .help-list .help-item h3{ font-size:16px; font-weight:bold; color:#fff; margin-bottom:20px;}
    .footer-new-con .help-list .help-item li{ line-height:28px; overflow:hidden; text-overflow: ellipsis; white-space:nowrap;}
    .footer-new-con .help-list .help-item li a{ font-size:14px; color:#cccccc; width: 100%;}
    .footer-new-con .help-list .help-item li a:hover{ color:#f42424;}

    .footer-new-con .qr-code{ float:right;}
    .footer-new-con .qr-code .qr-item{ float:left; width:104px; padding:2px; background-color:#fff;}
    .footer-new-con .qr-code .qr-item .code_img,.footer-new-con .qr-code .qr-item .code_img img{ width:104px; height:104px;}
    .footer-new-con .qr-code .qr-item .code_txt{ width:100%; height:20px; background-color:#121212; text-align:center; color:#fff;}
    .footer-new-con .qr-code .qr-item-first{ margin-right:60px;}

    .footer-new-bot{ overflow:hidden; padding:30px 0 20px;}
    .footer-new-bot p{ text-align:center; color:#4c4c4c;}
    .footer-new-bot .copyright_links{ margin-bottom:10px;}
    .footer-new-bot .copyright_links a{ color:#888; display:inline-block;}
    .footer-new-bot .copyright_links a:hover{ color:#f42424;}
    .footer-new-bot .copyright_links .spacer{ overflow: hidden; margin: 0 17px; width: 1px;height: 11px; background-color: #444; display:inline-block;}

    .footer-new-bot .copyright_auth{ overflow:hidden; padding-top:15px;}
    .footer-new-bot .copyright_auth a img{ max-height:48px;}
</style>
<div class="footer-new" style="position: relative">
    <?php if($_GET['ljdiy'] == 'yes') { ?>
    <div style="
    background-color: rgba(0,0,0,0.7);
    position: absolute;
    height: 100%;
    text-align: center;
    font-size: 60px;
        width: 100%;
    "><a class="diyDocument" data-id="pcdiy_footer" href="javascript:;" style="
    color: #fff;
    font-weight: bold;
    display: table-cell;
    vertical-align: middle;
    height: 350px;
    width: 1200px;
    overflow: hidden;
    cursor: pointer;
">点击编辑底部</a></div>
    <?php } ?>
    <div class="footer-new-top">
        <div class="w w1200" >

            <?php if($settings['pc_footer_new_top']['value']) { ?>
                <div class="service-list">
                    <?php if(is_array($pc_footer_new_top_arr)) foreach($pc_footer_new_top_arr as $nt) { ?>                    <div class="service-item">
                        <i class="f-icon "><img src="<?php echo $nt['0'];?>" /></i>
                        <span><?php echo $nt['1'];?></span>
                    </div>
                    <?php } ?>
                </div>
            <?php } ?>
            <div class="contact-lj">
                <?php if($settings['pc_footer_new_top_tel']['value']) { ?>
                    <div class="contact-item contact-item-first">
                        <i class="f-icon f-icon-tel"><img src="<?php echo $pc_footer_new_top_tel['0'];?>" width="24"/></i><span><?php echo $pc_footer_new_top_tel['1'];?></span>
                    </div>
                <?php } ?>
                <?php if($settings['pc_footer_new_top_kefu']['value']) { ?>
                    <div class="contact-item">
                        <a  href="<?php echo $pc_footer_new_top_kefu['1'];?>" <?php if($pc_footer_new_top_kefu['3']) { ?>onclick="kefualjol('<?php echo $pc_footer_new_top_kefu['3'];?>')"<?php } ?> class="btn-ctn" >
                            <i class="f-icon f-icon-kefu"><img width="24" src="<?php echo $pc_footer_new_top_kefu['0'];?>" /></i><span><?php echo $pc_footer_new_top_kefu['2'];?></span>
                        </a>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <div class="footer-new-con">
        <div class="fnc-warp">
            <div class="help-list">
                <?php if($_G['cache']['plugin']['aljbd']['pc_footer_new_cron_t1'] || $settings['pc_footer_new_cron_c1']['value']) { ?>
                    <div class="help-item">
                        <h3><?php echo $_G['cache']['plugin']['aljbd']['pc_footer_new_cron_t1'];?> </h3>
                        <ul>
                            <?php if(is_array($pc_footer_new_cron_c1_arr)) foreach($pc_footer_new_cron_c1_arr as $c1) { ?>                            <li><a href="<?php echo $c1['1'];?>" title="<?php echo $c1['0'];?>" target="_blank"><?php echo $c1['0'];?></a></li>
                            <?php } ?>
                        </ul>

                    </div>
                <?php } ?>
                <?php if($_G['cache']['plugin']['aljbd']['pc_footer_new_cron_t2'] || $settings['pc_footer_new_cron_c2']['value']) { ?>
                <div class="help-item">
                    <h3><?php echo $_G['cache']['plugin']['aljbd']['pc_footer_new_cron_t2'];?> </h3>
                    <ul>
                        <?php if(is_array($pc_footer_new_cron_c2_arr)) foreach($pc_footer_new_cron_c2_arr as $c2) { ?>                        <li><a href="<?php echo $c2['1'];?>" title="<?php echo $c2['0'];?>" target="_blank"><?php echo $c2['0'];?></a></li>
                        <?php } ?>
                    </ul>

                </div>
                <?php } ?>
                <?php if($_G['cache']['plugin']['aljbd']['pc_footer_new_cron_t3'] || $settings['pc_footer_new_cron_c3']['value']) { ?>
                <div class="help-item">
                    <h3><?php echo $_G['cache']['plugin']['aljbd']['pc_footer_new_cron_t3'];?> </h3>
                    <ul>
                        <?php if(is_array($pc_footer_new_cron_c3_arr)) foreach($pc_footer_new_cron_c3_arr as $c3) { ?>                        <li><a href="<?php echo $c3['1'];?>" title="<?php echo $c3['0'];?>" target="_blank"><?php echo $c3['0'];?></a></li>
                        <?php } ?>
                    </ul>

                </div>
                <?php } ?>
                <?php if($_G['cache']['plugin']['aljbd']['pc_footer_new_cron_t4'] || $settings['pc_footer_new_cron_c4']['value']) { ?>
                <div class="help-item">
                    <h3><?php echo $_G['cache']['plugin']['aljbd']['pc_footer_new_cron_t4'];?> </h3>
                    <ul>
                        <?php if(is_array($pc_footer_new_cron_c4_arr)) foreach($pc_footer_new_cron_c4_arr as $c4) { ?>                        <li><a href="<?php echo $c4['1'];?>" title="<?php echo $c4['0'];?>" target="_blank"><?php echo $c4['0'];?></a></li>
                        <?php } ?>
                    </ul>

                </div>
                <?php } ?>
                <?php if($_G['cache']['plugin']['aljbd']['pc_footer_new_cron_t5'] || $settings['pc_footer_new_cron_c5']['value']) { ?>
                <div class="help-item">
                    <h3><?php echo $_G['cache']['plugin']['aljbd']['pc_footer_new_cron_t5'];?></h3>
                    <ul>
                        <?php if(is_array($pc_footer_new_cron_c5_arr)) foreach($pc_footer_new_cron_c5_arr as $c5) { ?>                            <li><a href="<?php echo $c5['1'];?>" title="<?php echo $c5['0'];?>" target="_blank"><?php echo $c5['0'];?></a></li>
                        <?php } ?>
                    </ul>
                </div>
                <?php } ?>
            </div>
            <?php if($settings['pc_footer_new_cron_qrcode']['value']) { ?>
            <div class="qr-code">
                <div class="qr-item qr-item-first">
                    <div class="code_img"><img src="<?php echo $pc_footer_new_cron_qrcode_arr['0']['0'];?>"></div>
                    <div class="code_txt"><?php echo $pc_footer_new_cron_qrcode_arr['0']['1'];?></div>
                </div>
                <div class="qr-item">
                    <div class="code_img"><img src="<?php echo $pc_footer_new_cron_qrcode_arr['1']['0'];?>"></div>
                    <div class="code_txt"><?php echo $pc_footer_new_cron_qrcode_arr['1']['1'];?></div>
                </div>
            </div>
            <?php } ?>
        </div>

    </div>
    <?php if($settings['pc_footer_new_bot']['value']) { ?>
    <div class="footer-new-bot">
        <div class="w w1200">
            <p class="copyright_links">
                <?php echo htmlspecialchars_decode($settings['pc_footer_new_bot']['value']);?>            </p>
        </div>
    </div>
    <?php } ?>
</div>
<?php if($_G['cache']['plugin']['aljgwc']['aljol'] || $_G['cache']['plugin']['aljbdx']['aljol']) { ?>
<script src="<?php echo $common_path;?>static/js/layer/layer.js?<?php echo VERHASH;?>" type="text/javascript" charset="utf-8"></script>
<script>
    function kefualjol(uid) {
        layer.open({
            type: 2
            ,offset: 'rb'
            ,title: '<?php echo $pc_footer_new_top_kefu['2'];?>'
            ,area: ['414px', '80%']
            ,content: 'plugin.php?id=aljol&act=talk&friendid='+uid+'&gid=<?php echo $g['id'];?>' //iframe��url
            ,shade: 0 //����ʾ����
        });
    }
</script>
<?php } } else { include template('common/footer'); } if($_GET['ljdiy'] == 'yes') { ?>
<script>
    lj_jq('.diyDocument').click(function(){
        layer.open({
                type: 2,
                title: '可视化DIY配置',
                shadeClose: true,
                shade: false,
                maxmin: true, 
                offset: "20px",
                area: ['993px', '80%'],
                content: 'plugin.php?id=aljhtx&c=diy&ajax=yes&a='+lj_jq(this).attr('data-id')
            });
    });
</script>
<?php } if($_G['cache']['plugin']['aljhtx']) { include_once DISCUZ_ROOT."source/plugin/aljhtx/aljhtx.class.php";
echo plugin_aljhtx::global_footer();?><?php } if($_G['cache']['plugin']['ljqq']) { include_once DISCUZ_ROOT.'source/plugin/ljqq/ljqq.class.php';
echo plugin_ljqq::global_footer();?><?php } ?>
