<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template(PLUGIN_ID.':admin/header')?><style>
    body{ font-size: 14px; }
    tr th{
        color:#666;
        font-size: 14px;
    }
    .info-box-number{
        margin-top:5px;
        margin-left:5px;
    }
    .info-box-text{
        margin-top:10px;
    }
    .layui-table-body{overflow-x: hidden;}
    .content-wrapper{background-color: #ffffff;}
    .layui-laypage-limits select{margin-top:2px;}
    .layui-table, .layui-table-view {
        margin: 3px 0;
    }
    .box.box-default {
        border-top-color: #009688;
    }
    .box {
        position: relative;
        border-radius: 3px;
        background: #fff;
        border-top: 2px solid #009688;
        margin-bottom: 20px;
        width: 100%;
        box-shadow: 0 1px 1px rgba(0,0,0,0.1);
    }
    .nav-tabs {
        border-bottom: none;
    }
    .box.box-primary {
        border-top-color: #009688;
    }
    .btn-primary {
        background-color: #009688;
        border-color: #009688;
    }
    .layui-table-tips-c {
        line-height: 14px;
    }
    .layui-table-cell {
        height: auto;
        line-height: 28px;
        padding: 0 15px;
        position: relative;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: normal;
        box-sizing: border-box;
    }
    .layui-table-view .layui-table{
        width:100%!important;
    }
    .catpic img{
        width:40px;
    }
    
</style>
<div class="content-wrapper" style="margin-left:0px">
    <section class="content">
        <div class="row">
            <div class="col-md-9">
                <?php include template(APP_ID.':'.APP_ID.'/goods/list_nav');?>            </div>

            <div class="col-md-3" style="text-align:right">
                    <div class="box-tools pull-right">
                            <div class="has-feedback">
                                <input type="text" value="<?php echo $_GET['search'];?>" id="search" class="form-control input-sm" placeholder="请输入商品标题" onkeypress="R.enterPress(event)" onkeydown="R.enterPress()">
                                <div class="glyphicon glyphicon-search form-control-feedback" style="pointer-events: visible;"></div>
                            </div>
                        </div>
                </div>

            <!-- /.col -->
            <div class="col-md-12">
                <div class="box box-primary">
                    <!-- /.box-header -->
                    
                    <iframe style="display:none;" name="submitiframe"></iframe>
                    <form name="cpform" id="admingoodssubmit" method="post" autocomplete="off" action="<?php echo $dourl;?>" target="submitiframe">
                        <input type="hidden" value="yes" name="ajax">
                        <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>">
                    </form>
                    <blockquote class="layui-elem-quote" style="margin-top:10px;font-size:14px;">库存扣减方式等与运营有关的设置将统一整合在本插件</blockquote>
                    <table id="demo" lay-filter="test"></table>
                    <script type="text/html" id="barDemo">
                        <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="view">设置</a>
                    </script>
                </div>
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
</div>
<script>


    var R = {
        options: {
            formhash: '<?php echo FORMHASH;?>',
        },
        realtime: function(){
            $('.realtime').click(function() {
                $.post('plugin.php?id=<?php echo APP_ID;?>&c=goods&a=sync_goods', function(){
                    layer.alert('同步成功！', function(){
                        location.href = location.href;
                    });
                });
            });
        },
        enterPress: function(e){
            var e = e || window.event;
            if(e.keyCode == 13){
                $('.glyphicon-search').click();
            }
        },
        init: function(){
            layui.use('table', function(){
                var table = layui.table;
                var tableIns = table.render({
                    elem: '#demo'
                    ,limit: 20
                    ,url: 'plugin.php?id=<?php echo APP_ID;?>&c=goods&a=list_index&ajax=yes&render=yes&reduction_method=<?php echo htmlspecialchars($_GET[reduction_method])?>&bysku=<?php echo htmlspecialchars($_GET[bysku])?>'
                    ,page: true
                    ,skin: 'line'
                    ,even: true
                    ,cols: [[
                        {field: 'pic1', title: '主图',width: 100, templet: function(d){
                            return '<img style="width:100px" src="'+d.pic1+'">';
                        }}
                        ,{field: 'title', title: '商品',templet: function(d){
                            var str = "商品名称："+d.name+"<br/>";
                            str += "商品编码："+d.id+"<br/>";
                            str += "商品库存："+d.amount+"<br/>";
                            return str;
                        }}
                        ,{field: 'reduction_method', title: '库存扣减方式',width: 200, templet: function(d){
                            if(d.reduction_method == 'bypayment'){
                                return '付款时扣减库存数量';
                            }else{
                                return '下单时扣减库存数量';
                            }
                        }}
                        ,{align:'center', toolbar: '#barDemo', title: '操作'}
                    ]]
                });
                table.on('tool(test)', function(obj){
                    var data = obj.data;
                    var url = 'plugin.php?id=<?php echo APP_ID;?>&c=goods&a=list_submit&gid='+data.id;
                    if(obj.event === 'view'){
                        layer.open({
                            type: 2,
                            title: data.name,
                            shadeClose: true,
                            shade: false,
                            maxmin: true,
                            offset: "20px",
                            area: ['750px', '550px'],
                            content: url
                        });
                    }
                });
                $('.glyphicon-search').on('click', function(){
                    tableIns.reload({
                        where: {
                            search: $('#search').val()
                        }
                        ,page: {
                            curr: 1
                        }
                    });
                });

            });
            R.realtime();
        }
    }
    R.init();
</script><?php include template(PLUGIN_ID.':admin/footer')?>