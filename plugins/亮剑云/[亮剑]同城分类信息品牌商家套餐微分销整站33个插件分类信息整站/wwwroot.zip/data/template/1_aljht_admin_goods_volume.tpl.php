<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<script>
    //添加阶梯价格 有删除
    function add_clonetd(obj,type){
        var obj = $(obj);
        var table = obj.parent().parent().parent().parent().parent();
        var number_td = obj.parent().prev();
        var price_tr = obj.parent().parent().next();
        var pt_price_tr = obj.parent().parent().next().next();
        var handle_tr = obj.parent().parent().siblings().last();
        var td_num = table.find(".td_num").length;
        var number = 3;
        var sku = obj.data("sku");
        if( table.length > 0){
            number = table.data("number");
        }

        if(td_num < number){
            if(type == "mj"){
                number_td.after("<td><input type='text' name='cfull[]' value='' class='form-control dis-inline w50 td_num'><input type='hidden' name='v_id[]' value='' class='text w50' autocomplete='off'></td>");
                price_tr.append("<td><input type='text' name='creduce[]' value='' class='form-control dis-inline w50'></td>");
            }else{
                if(cdtype == 2){
                    $('.last_td').attr('rowspan','4');
                    $('.is_pt_show').show();
                }else{
                    $('.is_pt_show').hide();
                    $('.last_td').attr('rowspan','3');
                }
                if(sku){
                    number_td.after("<td><input type='text' name='volume_number["+sku+"][]' value='' class='form-control dis-inline w50 td_num'><input type='hidden' name='v_id["+sku+"][]' value='' class='text w50' autocomplete='off'></td>");
                    if(cdtype == 2){
                        pt_price_tr.append("<td><input type='text' name='volume_price_pt["+sku+"][]' value='' class='form-control dis-inline w50'></td>");
                    }
                    price_tr.append("<td><input type='text' name='volume_price["+sku+"][]' value='' class='form-control dis-inline w50'></td>");
                }else{
                    number_td.after("<td><input type='text' name='volume_number[]' value='' class='form-control dis-inline w50 td_num'><input type='hidden' name='v_id["+sku+"]' value='' class='text w50' autocomplete='off'></td>");
                    if(cdtype == 2){
                        pt_price_tr.append("<td><input type='text' name='volume_price_pt[]' value='' class='form-control dis-inline w50'></td>");
                    }
                    price_tr.append("<td><input type='text' name='volume_price[]' value='' class='form-control dis-inline w50'></td>");
                }

            }
            handle_tr.append("<td><a href='javascript:;' class='btn btn-primary w50' data-id='0' data-type='del_volume' ectype='remove_volume'>删除</a></td>");
        }else{
            alert("最多设置不能超过"+number+"个","",0);
        }
    }

    $(document).on("click","a[ectype='remove_volume']",function(){
        var index = $(this).parent("td").index();
        var parent = $(this).parent().parent().parent();
        var id = $(this).data('id');
        var type = $(this).data('type');
        var goods_id = $("input[name='gid']").val();

        if(id > 0){
            if(confirm('您确定删除该优惠价格吗？')){
                $.post('plugin.php?id=aljht&act=<?php echo $act;?>&op=<?php echo $op;?><?php echo $urlmod;?>&do=' + type + '&vid=' + id + '&gid=' + goods_id, function(data){
                    if(data.code == 1){
                        parent.find("tr").each(function(){
                            $(this).find("td").eq(index).remove();
                        });
                    }else{
                        tips(data.text);
                    }
                },'json');
            }

        }else{
            parent.find("tr").each(function(){
                $(this).find("td").eq(index).remove();
            });
        }
    });
</script>