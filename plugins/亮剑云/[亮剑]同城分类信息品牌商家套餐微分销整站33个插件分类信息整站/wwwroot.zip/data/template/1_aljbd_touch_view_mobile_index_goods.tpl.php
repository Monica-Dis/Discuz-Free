<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($goodslist) { if(is_array($goodslist)) foreach($goodslist as $val) { ?><dd>
<div class="c_goods_size">
<?php if($val['commodity_type'] == 4) { ?>
<a class="navigateTo" href="plugin.php?id=aljwm&amp;c=food&amp;a=view&amp;store_id=<?php echo $val['store_id'];?>">
<?php } else { ?>
<a class="navigateTo" href="plugin.php?id=aljbd&amp;act=goodview&amp;bid=<?php echo $val['bid'];?>&amp;gid=<?php echo $val['id'];?>">
<?php } ?>
<img id="img_<?php echo $val['id'];?>" data-original="<?php echo $val['pic1'];?>" class="img-responsive lazy<?php echo $currpage;?> c_img" style="width: 100%; display: block;" >
<div class="goods_status goods_status_end_<?php echo $val['goods_status'];?>"></div>
</a>
</div>
<?php if($val['commodity_type'] == 4) { ?>
<a class="navigateTo" href="plugin.php?id=aljwm&amp;c=food&amp;a=view&amp;store_id=<?php echo $val['store_id'];?>">
<?php } else { ?>
<a class="navigateTo" href="plugin.php?id=aljbd&amp;act=goodview&amp;bid=<?php echo $val['bid'];?>&amp;gid=<?php echo $val['id'];?>">
<?php } if($val['commodity_type'] == 1) { include template('aljstg:goods/indexListLabel'); } if($val['commodity_type'] == 2) { include template('aljspt:goods/indexListLabel'); } if($val['commodity_type'] == 4) { include template('aljwm:goods/indexListLabel'); } ?><?php echo $val['name'];?></a>

<div class="detail-tags" style="padding:0px 5px">
<?php if($val['selling_point']) { ?>
<div class=" detail-tags-h"><?php if(is_array($val['selling_point'])) foreach($val['selling_point'] as $sk => $sv) { ?><span class="span0 border-global"><?php echo $sv;?></span>
<?php } ?>
</div>
<?php } else { ?>
<div class="brief">
<?php echo $val['brief'];?>
</div>
<?php } ?>
</div>

<p>
<i style="color:#f42424;font-style:normal;font-size: 18px;">
<?php if($val['commodity_type'] == 2 && $val['collage_price']>0 && $_G['cache']['plugin']['aljspt']['is_aljspt']) { include template('aljspt:goods/indexListPrice'); } else { if($val['price1']) { if($_G['cache']['plugin']['aljgwc']['aljbd']) { ?>
<em style="font-size: 12px"><?php echo $price_unit;?></em><?php echo $val['price1'];?>
<?php } else { if($config['isextcredit'] && $config['extcredit']) { ?>
<?php echo $val['price1'];?><?php echo $_G['setting']['extcredits'][$config['extcredit']]['title'];?>
<?php } else { ?>
<em style="font-size: 12px"><?php echo $price_unit;?></em><?php echo $val['price1'];?>
<?php } } } else { ?>
面议
<?php } } ?>
</i>

</p>
<?php if(!$settings['is_goods_sales']['value']) { ?>
<p style="height:17px;margin: 5px 5% 5px;">
<?php if($_G['cache']['plugin']['aljgwc'][$pluginid] && $val['buyamount']>0) { ?>
&#24050;&#21806;<?php echo $val['buyamount'];?>&#20214;&nbsp;<?php } if($val['commodity_type'] == 1) { ?>
到店核销<?php } else { if($val['fare']<=0 || $val['fare_desc'] == 1) { ?>包邮<?php } } ?>
</p>
<?php } ?>
</dd>
<?php } ?>
<?php echo $max_page;?>
<?php echo $mes;?>
<?php } ?>