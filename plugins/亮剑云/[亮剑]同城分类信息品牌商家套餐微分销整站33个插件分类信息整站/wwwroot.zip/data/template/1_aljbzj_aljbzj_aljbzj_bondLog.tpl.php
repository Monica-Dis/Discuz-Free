<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template(PLUGIN_ID.':admin/header')?><style>
    body{ font-size: 14px; }
    tr th{
        color:#666;
        font-size: 14px;
    }
    .info-box-number{
        margin-top:5px;
        margin-left:5px;
    }
    .info-box-text{
        margin-top:10px;
    }
    .layui-table-body{overflow-x: hidden;}
    .content-wrapper{background-color: #ffffff;}
    .layui-laypage-limits select{margin-top:2px;}
    .layui-table, .layui-table-view {
        margin: 3px 0;
    }
    .box.box-default {
        border-top-color: #009688;
    }
    .box {
        position: relative;
        border-radius: 3px;
        background: #fff;
        border-top: 2px solid #009688;
        margin-bottom: 20px;
        width: 100%;
        box-shadow: 0 1px 1px rgba(0,0,0,0.1);
    }
    .nav-tabs {
        border-bottom: none;
    }
    .box.box-primary {
        border-top-color: #009688;
    }
    .btn-primary {
        background-color: #009688;
        border-color: #009688;
    }
    .layui-table-tips-c {
        line-height: 14px;
    }
    .layui-table-cell {
        height: auto;
        line-height: 28px;
        padding: 0 15px;
        position: relative;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: normal;
        box-sizing: border-box;
    }
    .layui-table-view .layui-table{
        width:100%!important;
    }
    .catpic img{
        width:40px;
    }
</style>
<div class="content-wrapper" style="margin-left:0px">
    <section class="content">
        <div class="row">
            <?php if($_G['groupid'] == 1 && $_GET['i'] == 1) { ?>
            <div class="col-md-9">
                <ul class="nav nav-tabs" role="tablist" >
                    <li <?php if(!$_GET['status'] || $_GET['status'] == 2) { ?>class="active"<?php } ?>><a href="plugin.php?id=<?php echo APP_ID;?>&amp;c=<?php echo APP_ID;?>&amp;a=bondLog&amp;ajax=yes&amp;status=2&amp;i=1">待审核</a></li>
                    <li <?php if($_GET['status'] == 3) { ?>class="active"<?php } ?>><a href="plugin.php?id=<?php echo APP_ID;?>&amp;c=<?php echo APP_ID;?>&amp;a=bondLog&amp;ajax=yes&amp;status=3&amp;i=1">已通过</a></li>
                    <li <?php if($_GET['status'] == 4) { ?>class="active"<?php } ?>><a href="plugin.php?id=<?php echo APP_ID;?>&amp;c=<?php echo APP_ID;?>&amp;a=bondLog&amp;ajax=yes&amp;status=4&amp;i=1">未通过</a></li>
                    <li <?php if($_GET['status'] == 99) { ?>class="active"<?php } ?>><a href="plugin.php?id=<?php echo APP_ID;?>&amp;c=<?php echo APP_ID;?>&amp;a=bondLog&amp;ajax=yes&amp;status=99&amp;i=1">已缴纳</a></li>
                </ul>
            </div>
            <?php } ?>
            <!-- /.col -->
            <div class="col-md-12">
                <div class="box box-primary">
                    <!-- /.box-header -->

                    <iframe style="display:none;" name="submitiframe"></iframe>
                    <form name="cpform" id="admingoodssubmit" method="post" autocomplete="off" action="<?php echo $dourl;?>" target="submitiframe">
                        <input type="hidden" value="yes" name="ajax">
                        <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>">
                    </form>
                    <?php if($_G['groupid'] == 1 && $_GET['i'] == 1) { ?>
                    <blockquote class="layui-elem-quote" style="margin-top:10px;font-size:14px;">温馨提示：点击通过保证金退回到申请人的钱包账户，点击不通过请填写理由。</blockquote>
                    <?php } ?>
                    <table id="demo" lay-filter="test"></table>
                    <?php if($_G['groupid'] == 1 && $_GET['i'] == 1) { ?>
                    <script type="text/html" id="barDemo">
                        <?php if($_GET['status'] == 2) { ?>
                        <a class="layui-btn layui-btn-normal layui-btn-xs catpic" lay-event="pass"> 通过</a>
                        <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="not_pass">不通过</a>
                        <?php } ?>
                        <?php if($_GET['status'] != 99) { ?>
                        <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del">删除</a>
                        <?php } ?>
                    </script>
                    <?php } ?>
                </div>
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
</div>
<script>


    var R = {
        options: {
            formhash: '<?php echo FORMHASH;?>',
        },
        enterPress: function(e){
            var e = e || window.event;
            if(e.keyCode == 13){
                $('.glyphicon-search').click();
            }
        },
        init: function(){
            layui.use('table', function(){
                var table = layui.table;
                var tableIns = table.render({
                    elem: '#demo'
                    ,limit: 20
                    ,url: 'plugin.php?id=<?php echo APP_ID;?>&c=<?php echo APP_ID;?>&a=bondLog&ajax=yes&do=ajax&status=<?php echo $_GET['status'];?>&i=<?php echo $_GET['i'];?>'
                    ,page: true
                    ,skin: 'line'
                    ,even: true
                    ,cols: [[
                        ,{field: 'username', title: '申请人'}
                        ,{field: 'bname', title: '店铺', templet: function(d){
                            return '<a href="plugin.php?id=aljbd&amp;act=view&amp;bid='+d.bid+'">'+d.bname+'</a>';
                        }}
                        ,{field: 'price', title: '金额'}
                        ,{field: 'addtime', title: '添加时间'}
                        ,{field: 'statustext', title: '状态'}
                        <?php if($_GET['status'] != 99) { ?>
                        ,{field: 'info', title: '备注'}

                        <?php if($_G['groupid'] == 1 && $_GET['i'] == 1) { ?>
                        ,{align:'center', toolbar: '#barDemo', title: '操作'}
                        <?php } ?>
                        <?php } ?>
                    ]]
                });
                table.on('tool(test)', function(obj){
                    var data = obj.data;
                    if(obj.event === 'del'){
                        layer.confirm('你确定要删除吗？', {"offset": "50px"}, function(index){
                            layer.load(0, {"offset": "50px"});
                            $.post('plugin.php?id=<?php echo APP_ID;?>&c=<?php echo APP_ID;?>&a=bondDelete&qid='+data.id, function(){
                                layer.alert('删除成功', {"offset": "50px"}, function(){
                                    obj.del();
                                    layer.closeAll();
                                });
                            });

                        });
                    }
                    if(obj.event === 'not_pass'){
                        layer.prompt({
                            formType: 2,
                            value: '<?php echo $config['tips'];?>',
                            title: '审核不通过理由',
                            area: ['400px', '250px'] //自定义文本域宽高
                        }, function(value, index, elem){
                            layer.load(0, {"offset": "50px"});
                            var d_url = {
                                'status':4,
                                'cashid':data.id,
                                'message':value,
                                'i':'<?php echo $_GET['i'];?>',
                                'formhash':'<?php echo FORMHASH;?>',
                            }
                            $.post('plugin.php?id=<?php echo APP_ID;?>&c=<?php echo APP_ID;?>&a=bondStatus',d_url, function(res){
                                if(res.code == 1){
                                    layer.alert(res.text, {"offset": "50px"}, function(){
                                        obj.del();
                                        layer.closeAll();
                                    });
                                }else{
                                    layer.alert(res.text, {"offset": "50px"});
                                }
                            },'json');
                        });
                    }
                    if(obj.event === 'pass'){
                        layer.confirm('你确定要通过吗？通过后保证金将退回用户的钱包帐户中！', {"offset": "50px"}, function(index){
                            layer.load(0, {"offset": "50px"});
                            var d_url = {
                                'status':3,
                                'cashid':data.id,
                                'i':'<?php echo $_GET['i'];?>',
                                'formhash':'<?php echo FORMHASH;?>',
                            }
                            $.post('plugin.php?id=<?php echo APP_ID;?>&c=<?php echo APP_ID;?>&a=bondStatus',d_url, function(res){
                                if(res.code == 1){
                                    layer.alert(res.text, {"offset": "50px"}, function(){
                                        obj.del();
                                        layer.closeAll();
                                    });
                                }else{
                                    layer.alert(res.text, {"offset": "50px"});
                                }

                            },'json');

                        });
                    }
                });
                $('.glyphicon-search').on('click', function(){
                    tableIns.reload({
                        where: {
                            search: $('#search').val()
                        }
                        ,page: {
                            curr: 1
                        }
                    });
                });

            });
        }
    }
    R.init();
</script><?php include template(PLUGIN_ID.':admin/footer')?>