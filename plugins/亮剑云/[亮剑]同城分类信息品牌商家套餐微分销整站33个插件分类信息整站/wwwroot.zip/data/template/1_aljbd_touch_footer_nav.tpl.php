<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($_GET['id'] != 'aljol' && $_GET['id'] != 'aljtc') { ?>
<link href="source/plugin/aljbd/css/sj/iconfont/iconfont.css" rel="stylesheet">
<?php } ?>
<style type="text/css">
.footermenu .iconfont {
font-size: 20px;
}
img {
vertical-align: middle;
}
img {
border: 0;
}
</style>
<style type="text/css">
ul, li {
list-style: none;
}
.footer-img{font-size:18px;}
.footer_nav {
position: fixed;
z-index: 900;
bottom: 0;
left: 0;
right: 0;
margin: auto;
display: block;
width: 100%;
height: auto;
padding-bottom: 2px;
display: -webkit-box;
display: box;
-webkit-box-orient: horizontal;
background-color: <?php if($settings['footer_color']['value']) { ?><?php echo $settings['footer_color']['value'];?><?php } else { ?>#ffffff<?php } ?>;
border-top:1px solid #eee;
}

.footer_nav li {
width: auto!important;
height: 100%;
position: static!important;
margin: 0;
border-radius: 0!important;
-webkit-box-sizing: border-box;
box-sizing: border-box;
-webkit-box-flex: 1;
box-flex: 1;
-webkit-box-sizing: border-box;
box-shadow: none!important;
background: none;
line-height:18px
}
.footer_nav li  {
color: #5D656B;
}

.footer_nav li a {
color: <?php if($settings['footer_img_color']['value']) { ?><?php echo $settings['footer_img_color']['value'];?><?php } else { ?>#333333<?php } ?>;
text-align: center;
display: block;
text-decoration: none;
padding-top: 5px;

font-size: 16px;
position: relative;
height: auto;
}
.bd_null_footer{
height:55px;
}
@supports (bottom: constant(safe-area-inset-bottom)) or (bottom: env(safe-area-inset-bottom)) {
.bd_null_footer{
height: calc(55px + constant(safe-area-inset-bottom));
height: calc(55px + env(safe-area-inset-bottom));
}
.footer_nav li a{
padding-bottom: constant(safe-area-inset-bottom);
padding-bottom: env(safe-area-inset-bottom);
}
.mui-nav-tab .tab-content{
bottom: calc(52px + constant(safe-area-inset-bottom));
bottom: calc(52px + env(safe-area-inset-bottom));
    	}
}

.footer_nav li a.l_Selected{color:<?php if($settings['footer_color_s']['value']) { ?><?php echo $settings['footer_color_s']['value'];?><?php } else { ?>red<?php } ?>;}
.footer_nav li a img {
width: 24px;
height: 24px;
}

.footer_nav li a p {
margin: 2px 0 0 0;
font-size: 12px;
display: block !important;

text-align: center;
}

.top-btn {
display: none;
position: fixed;
right: .3rem;
bottom: 1.5rem;
width: .86rem;
height: .86rem;
line-height: .86rem;
background: #FF658E;
z-index: 130;
border-radius: 50%;
color: #fff;
overflow: hidden;
text-align: center;
font-size: .5rem;
}
.indexBox {
width: 40px;
margin: auto;
background: none !important;
position: relative;
top: -18px;
height: 40px;
-moz-border-radius: 50%;
-webkit-border-radius: 50%;
border-radius: 50%;
}
.indexBox b{color:#ffffff !important;}
.indexBox span{margin: 4px auto 0;}
.post-i{font-size:40px;color:#f42424;}
.c_menu_this b {
    color: <?php if($settings['footer_color_s']['value']) { ?><?php echo $settings['footer_color_s']['value'];?><?php } else { ?>red<?php } ?>;
}
.post-i img{
    width:40px !important;
    height:40px !important;
}
.post-p{
    position: absolute;
    top: 30px;
    text-align: center;
    font-size: 12px;
    margin: 0 auto;
    z-index: 99;
    display: block;
    width: 100%;
}
#nav_post{
position: relative;
}
.nav_post {
position: absolute;
top: -20px;
left: 50%;
height: 68px;
width: 68px;
transform: translateX(-50%);
background-color: #fff;
border-radius: 50%;
}
.nav_post:before {
content: " ";
height: 48px;
width: 100%;
background-color: #fff;
position: absolute;
bottom: 0;
left: 0;
z-index: 1;
}
.nav_post:after {
content: " ";
width: 200%;
height: 200%;
position: absolute;
top: 0;
left: 0;
border: 2px solid #eee;
border-radius: 50%;
-webkit-transform: scale(.5);
transform: scale(.5);
-webkit-transform-origin: 0 0;
transform-origin: 0 0;
box-sizing: border-box;
}
</style>
<div class="footermenu">
<?php if(!$diy['auto_module']) { ?>
<div class="bd_null_footer" ></div>
<?php } ?>
<ul class="diyDocument footer_nav"  diy-id="<?php if($diy['auto_module']) { ?><?php echo $diy['auto_module'];?><?php } else { ?>footermenu<?php } ?>">
<?php if($settings['mobile_common_footernav']['value']) { $is_sy = !$_GET['act'] && ($_GET['id'] == 'aljbd' || $_GET['id'] == 'aljdiy' || $_GET['id'] == 'aljdiy:aljdiy' || $_GET['id'] == 'aljbd:aljbd' || !$_GET['id']) ? 1 : 0;?><?php $is_qt = ($_GET['id'] == 'aljbd:so' || $_GET['id'] == 'aljgwc' || $_GET['id'] == 'aljol' || $_GET['id'] == 'aljsd' || $_GET['id'] == 'aljspt' || $_GET['id'] == 'aljms') && $_GET['act'] != 'user' ? 1 : 0;?><?php if(is_array($mobile_common_footernav_arr)) foreach($mobile_common_footernav_arr as $mcfk => $mcfv) { if($mcfv['4'] == 1) { ?>
<li id="nav_post" <?php if(($is_sy && $mcfk == 0) || strpos($mcfv['3'], $_GET['act']) !== false || (strpos($mcfv['3'], $_GET['id']) !== false && $is_qt)) { ?>class="c_menu_this"<?php } ?>>
<a href="<?php echo $mcfv['3'];?><?php echo $dp_bid_url;?>">
<div class="nav_post1 nav_post" ></div>
<div class="indexBox">
<?php if(($is_sy && $mcfk == 0) || strpos($mcfv['3'], $_GET['act']) !== false || (strpos($mcfv['3'], $_GET['id']) !== false && $is_qt)) { ?>
<i class="post-i"><img src="<?php echo $mcfv['0'];?>" /></i>
<?php } else { ?>
<i class="post-i"><img src="<?php echo $mcfv['1'];?>" /></i>
<?php } ?>
</div>
<b class="post-p"><?php echo $mcfv['2'];?></b>
</a>
</li>
<?php } else { ?>
<li>
<a  href="<?php echo $mcfv['3'];?><?php echo $dp_bid_url;?>" <?php if(($is_sy && $mcfk == 0) || strpos($mcfv['3'], $_GET['act']) !== false || (strpos($mcfv['3'], $_GET['id']) !== false && $is_qt)) { ?>class="l_Selected redirectTo"<?php } else { ?>class="reLaunch"<?php } ?>>
<?php if(($is_sy && $mcfk == 0) || strpos($mcfv['3'], $_GET['act']) !== false || (strpos($mcfv['3'], $_GET['id']) !== false && $is_qt)) { ?>
<img src="<?php echo $mcfv['0'];?>" />
<?php } else { ?>
<img src="<?php echo $mcfv['1'];?>" />
<?php } ?>
<p><?php echo $mcfv['2'];?></p>
<?php if($newscount && strpos($mcfv['3'], $settings['footer_red_dot']['value']) !== false) { ?>
<i class="c_news"><?php echo $newscount;?></i>
<?php } ?>
</a>
</li>
<?php } } } else { ?>
<li><a  href="plugin.php?id=aljbd<?php echo $dp_bid_url;?>" <?php if(!$_GET['act'] && $_GET['id'] != 'aljgwc'&& $_GET['id'] != 'aljbd:so') { ?>class="l_Selected redirectTo"<?php } else { ?>class="reLaunch"<?php } ?>><span class="iconfont icon-home"></span><p>首页</p></a></li>
<?php if(!$settings['close_goods']['value']) { ?>
<li><a  href="plugin.php?id=aljbd&amp;act=goods<?php echo $dp_bid_url;?>" <?php if($_GET['act'] == 'goods') { ?>class="l_Selected redirectTo"<?php } else { ?>class="reLaunch"<?php } ?>><span class="iconfont icon-goods"></span><p>商品</p></a></li>
<?php } if(file_exists("source/plugin/dz_1/dz_1.inc.php")) { include template('dz_1:footer'); } else { ?>
<li><a  href="plugin.php?id=aljbd&amp;act=dianpu<?php echo $dp_bid_url;?>" <?php if($_GET['act'] == 'dianpu') { ?>class="l_Selected redirectTo"<?php } else { ?>class="reLaunch"<?php } ?>><span class="iconfont icon-shop"></span><p>&#21830;&#23478;</p></a></li>
<?php } if($_G['cache']['plugin']['aljgwc']['aljbd']) { ?>
<li><a  href="plugin.php?id=aljgwc<?php echo $dp_bid_url;?>" <?php if($_GET['id'] == 'aljgwc' && !$_GET['act']) { ?>class="l_Selected redirectTo"<?php } else { ?>class="reLaunch"<?php } ?>><span class="iconfont icon-cart" ></span><p>&#36141;&#29289;&#36710;</p></a></li>
<?php } ?>
<li><a  href="plugin.php?id=aljbd&amp;act=user<?php echo $dp_bid_url;?>" <?php if($_GET['act'] == 'user' || $_GET['act'] == 'member' || $_GET['act'] == 'yes' || $_GET['act'] == 'appointment_list' || $_GET['act'] == 'appointment_view' || $_GET['act'] == 'collection_list' || $_GET['act'] == 'goodslist' || $_GET['act'] == 'addgoods' || $_GET['act'] == 'orderlist' || $_GET['act'] == 'settlelist' || $_GET['act'] == 'settle' || $_GET['act'] == 'noticelist' || $_GET['act'] == 'consumelist') { ?>class="l_Selected redirectTo"<?php } else { ?>class="reLaunch"<?php } ?>><span class="iconfont icon-my"></span><p>&#25105;&#30340;</p></a></li>
<?php } ?>
</ul>
</div>
