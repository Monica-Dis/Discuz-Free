<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) { ?>
<script src="//res.wx.qq.com/open/js/jweixin-1.3.2.js?20190115" type="text/javascript"></script>
<script>
getSignature(location.href);

function getSignature(locUrl){
    jQuery.ajax({
        url: 'plugin.php?id=mapp_share',
        data:{
            act:'getSignature',
            urlstr: locUrl.split('#')[0],
            formhash:'<?php echo FORMHASH;?>'
        },
        dataType: 'json', //����������json��ʽ����
        type: 'get', //HTTP��������
        async:false,
        cache: false,
        success: function(res) {
            //alert(JSON.stringify(res));
            //wxConfig(res);
            setTimeout(function(){return wxConfig(res);},"1000");
        },
        error: function(xhr, type, errorThrown) {
            //alert('\u7f51\u7edc\u8fde\u63a5\u5931\u8d25\uff0c\u8bf7\u68c0\u67e5\u7f51\u7edc\u3002');
            console.log('error');
        }
    });
}
// ΢������
function wxConfig(res){
    wx.config({
        debug: <?php echo $_G['cache']['plugin']['mapp_share']['is_debug'];?>,
        appId: res.appId,
        timestamp: res.timestamp,
        nonceStr:  res.nonceStr,
        signature:  res.signature,
        jsApiList: ['onMenuShareTimeline',
'onMenuShareAppMessage',
'onMenuShareQQ',
'onMenuShareWeibo',
'onMenuShareQZone',
'setNavigationBarColor',
'setBounceBackground',
'hideMenuItems','scanQRCode',
'checkJsApi','chooseImage','previewImage','uploadImage','downloadImage',
'openLocation', 'getLocation',
'translateVoice','startRecord',
'stopRecord', 'onVoiceRecordEnd', 'playVoice', 'onVoicePlayEnd', 'pauseVoice', 'stopVoice', 'uploadVoice', 'downloadVoice']
    });
    wx.ready(function(){
<?php if($sharedata['name']) { ?>
var share_title = '<?php echo $sharedata['name'];?>';
<?php } else { ?>
var share_title = document.title;
<?php } if($sharedata['intro']) { ?>
var share_desc = '<?php echo $sharedata['intro'];?>';
<?php } else { ?>
var share_description = jQuery('meta[name="description"]');
var share_desc = share_description.length> 0 ? share_description.attr('content') : '<?php echo $sharedata['intro'];?>';
<?php } if($shareurl) { ?>
var share_link = '<?php echo $shareurl;?>';
<?php } else { ?>
var share_link = location.href.split('#')[0];
<?php } if($sharedata['logo']) { ?>
var share_img = '<?php echo $sharedata['logo'];?>';
<?php } else { ?>
var share_img = '<?php echo $_G['cache']['plugin']['mapp_share']['defaultsharelogo'];?>';
<?php } ?>
var auto_imglist = jQuery('img');

            var imgtext = /logo|avatar|icon|base64|none/;
for(var i=0; i<auto_imglist.length; i++){
if(!auto_imglist[i].src || imgtext.test(auto_imglist[i].src)){
continue;
}
if(auto_imglist[i].naturalWidth < 200){
continue;
}
if(auto_imglist[i].naturalHeight < 200){
continue;
}
share_img = auto_imglist[i].src;

break;
}

if(share_img.indexOf('http://')===-1 && share_img.indexOf('https://')===-1){
share_img = "<?php echo $_G['siteurl'];?>"+share_img;
}
console.log(auto_imglist);
var Public_setting = {
title: share_title,
desc: share_desc, // ��������
link: share_link,
imgUrl: share_img,
trigger: function (res) {
<?php if($sharethread) { if(empty($_G['uid'])) { ?>
alert('\u8bf7\u5148\u5728\u4eae\u5251\u4e91\u516c\u4f17\u53f7\u7ed1\u5b9a\u8bba\u575b\u5e10\u53f7\uff01');
{else if !<?php echo $check;?>}
alert('\u5206\u4eab\u6210\u529f\u540e\u6709\u5956\u52b1\u54e6\uff01');
<?php } } ?>
},
success: function (res) {
jQuery.post('plugin.php?id=mapp_share&tid=<?php echo $shareid;?>&type=<?php echo $sharetype;?>&openid=<?php echo $openid;?>',function(data){
if(data == 1){
<?php if($check && $binduser && $sharethread['stips']) { ?>
alert('<?php echo $sharethread['stips'];?>');
<?php } ?>
//window.location.href='<?php echo $shareurl;?>';
if(typeof(show_red_packet) == 'function'){
show_red_packet('<?php echo $hb_id;?>','<?php echo $hb_pluginid;?>','<?php echo $hb_module;?>');
}
}
});
},
cancel: function (res) {
if(typeof(red_packet_cancel) == 'function'){
red_packet_cancel();
}
},
fail: function (res) {
if(typeof(red_packet_cancel) == 'function'){
red_packet_cancel();
}
}
};
            var Public_setting_other = {
                title: share_title,
                desc: share_desc, // ��������
                link: share_link,
                imgUrl: share_img,
            };
            wx.onMenuShareQQ(Public_setting_other);
            wx.onMenuShareWeibo(Public_setting_other);
            wx.onMenuShareQZone(Public_setting_other);
wx.onMenuShareTimeline(Public_setting);
wx.onMenuShareAppMessage(Public_setting);
        if (window.__wxjs_environment === 'miniprogram'){
            wx.miniProgram.postMessage({ data: {title:share_title, desc:share_desc} })
        }
    });
    wx.error(function(res){
            // config��Ϣ��֤ʧ�ܻ�ִ��error��������ǩ�����ڵ�����֤ʧ�ܣ����������Ϣ���Դ�config��debugģʽ�鿴��Ҳ�����ڷ��ص�res�����в鿴������SPA�������������ǩ����
    });
}

</script>
<?php } if(strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false) { ?>
<script src="source/plugin/aljapp/plusShare.js?2018102302" type="text/javascript"></script>
<script>
function myshare(){
<?php if($sharedata['name']) { ?>
var share_title = '<?php echo $sharedata['name'];?>';
<?php } else { ?>
var share_title = document.title;
<?php } if($sharedata['intro']) { ?>
var share_desc = '<?php echo $sharedata['intro'];?>';
<?php } else { ?>
var share_description = jQuery('meta[name="description"]');
var share_desc = share_description.length> 0 ? share_description.attr('content') : '<?php echo $sharedata['intro'];?>';
<?php } if($shareurl) { ?>
var share_link = '<?php echo $shareurl;?>';
<?php } else { ?>
var share_link = location.href.split('#')[0];
<?php } if($sharedata['logo']) { ?>
var share_img = '<?php echo $sharedata['logo'];?>';
<?php } else { ?>
var share_img = '<?php echo $_G['cache']['plugin']['mapp_share']['defaultsharelogo'];?>';
<?php } ?>
var auto_imglist = jQuery('img');

var imgtext = /logo/g;
for(var i=0; i<auto_imglist.length; i++){
if(!auto_imglist[i].src){
continue;
}
if(auto_imglist[i].naturalWidth < 200){
continue;
}
if(auto_imglist[i].naturalHeight < 200){
continue;
}
share_img = auto_imglist[i].src;

break;
}

if(share_img.indexOf('http://')===-1 && share_img.indexOf('https://')===-1){
share_img = "<?php echo $_G['siteurl'];?>"+share_img;
}
console.log(window.plusShare);
window.plusShare({
title: share_title,
content: share_desc,
href: share_link,
thumbs: [share_img]
}, function(result) {
if(result) {
plus.nativeUI.toast("\u5206\u4eab\u6210\u529f");
} else {
plus.nativeUI.toast("\u5206\u4eab\u5931\u8d25");
}
});
}
function more(){
if(l_jq(".menu-list").css("display")=="none"){
l_jq(".menu-list").show();
}else{
l_jq(".menu-list").hide();
}

}
</script>
<?php } ?>
