<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template('aljbd:header/header_head'); ?><link rel="stylesheet" href="source/plugin/aljbd/css/sj/module.css" />
<div class="container module-item" id="mobile_body"><div class="panel-comm panel-default panel-fullsize">
    <div class="panel-body">
        <div class="panel-group" style="border-top:0;" id="subject_category">
            <?php if(is_array(C::t('#aljbd#aljbd_type')->fetch_all_by_upid(0))) foreach(C::t('#aljbd#aljbd_type')->fetch_all_by_upid(0) as $t) { ?>            <div class="panel-comm panel-white">
                <div class="panel-heading">
                    <h4><?php echo $t['subject'];?></h4>
                </div>
                <div class="panel-collapse">
                    <div class="subject-category-list">
                        <a href="plugin.php?id=aljbd&amp;act=dianpu&amp;type=<?php echo $t['id'];?>&amp;region=<?php echo $_GET['region'];?>&amp;subregion=<?php echo $_GET['subregion'];?>&amp;order=<?php echo $_GET['order'];?>" class="subject-category-list-item">
                            <span style="color:green;"><?php echo $t['subject'];?></span>
                        </a>
                        <?php if(is_array(C::t('#aljbd#aljbd_type')->fetch_all_by_upid($t['id']))) foreach(C::t('#aljbd#aljbd_type')->fetch_all_by_upid($t['id']) as $tt) { ?>                     
                        <a href="plugin.php?id=aljbd&amp;act=dianpu&amp;type=<?php echo $t['id'];?>&amp;subtype=<?php echo $tt['id'];?>&amp;region=<?php echo $_GET['region'];?>&amp;subregion=<?php echo $_GET['subregion'];?>&amp;order=<?php echo $_GET['order'];?>" class="subject-category-list-item">
                            <span class="bar"></span><?php echo $tt['subject'];?>                        </a>
                        <?php } ?>
                                                <a href="javascript:void(0);" class="subject-category-list-item">
                            &nbsp;
                        </a>
                                            </div>
                </div>
            </div>
<?php } ?>

                        
       </div>
    </div>
</div>

</div>
<style type="text/css">
.subject-category-list-item {
    border-top:1px solid #fff;
    float: left;
    width:33%;
    padding:10px 0;
    text-align:center;
    color:#546280;
    font-size:12px;
    white-space:nowrap;
    overflow:hidden;
}
</style><?php include template('aljbd:footer'); ?></body>
</html>