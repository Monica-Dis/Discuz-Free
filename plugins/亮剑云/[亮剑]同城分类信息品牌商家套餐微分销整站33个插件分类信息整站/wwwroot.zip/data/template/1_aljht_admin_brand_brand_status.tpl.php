<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div class="col-md-12">
<ul class="nav nav-tabs" role="tablist" >
<li <?php if($do == 'yes' || !$do) { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=brand&amp;do=yes<?php echo $urlmod;?>">已审核</a></li>
<li <?php if($do == 'no') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=brand&amp;do=no<?php echo $urlmod;?>"> 未审核<?php if($no_num>0) { ?>&nbsp;<b style="color:red;">(<?php echo $no_num;?>)</b><?php } ?></a></li>
<li <?php if($do == 'no_pay') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=brand&amp;do=no_pay<?php echo $urlmod;?>"> 未支付</a></li>
<li <?php if($do == 'lose') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=brand&amp;do=lose<?php echo $urlmod;?>"> 不通过</a></li>
<li <?php if($do == 'close') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=brand&amp;do=close<?php echo $urlmod;?>"> 已关闭</a></li>
<?php if($administrators) { ?>
<li <?php if($do == 'rec') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=brand&amp;do=rec<?php echo $urlmod;?>"> 推荐</a></li>
<?php if($_GET['ajax'] != 'yes') { ?>
<li <?php if($do == 'reply') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=brand&amp;do=reply<?php echo $urlmod;?>">评论管理</a></li>
<?php } } ?>

</ul>
</div>