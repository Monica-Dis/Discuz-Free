<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($_G['cache']['plugin']['aljue']['is_open']) { ?>
<script type="text/javascript" charset="<?php echo $_G['charset'];?>" src="source/plugin/aljue/ueditor.config.js"></script>
<?php if($_G['charset']=='gbk') { ?>
<script src="source/plugin/aljue/ueditor.all.min.js" type="text/javascript"></script>
<script src="source/plugin/aljue/lang/zh-cn/zh-cn.js" type="text/javascript"></script>
<?php } else { ?>
<script src="source/plugin/aljue/ueditor.all.min.u8.js" type="text/javascript"></script>
<script src="source/plugin/aljue/lang/zh-cn/zh-cn-u8.js" type="text/javascript"></script>
<?php } ?>
<script>
    var ue = UE.getEditor('intro');
</script>
<?php } else { ?>
<script charset="<?php echo $_G['charset'];?>" src="source/plugin/aljbd/js/editor/kindeditor-min.js" reload="true"></script>
<?php if($_G['charset']=='gbk') { ?>
<script src="source/plugin/aljbd/js/editor/lang/zh_CN.js" type="text/javascript" reload="true"></script>
<?php } else { ?>
<script src="source/plugin/aljbd/js/editor/lang/zh_CN_U8.js" type="text/javascript" reload="true"></script>
<?php } ?>
<script type="text/javascript" reload="true">
    KindEditor.ready(function(K) {
        window.editor = KindEditor.create('#intro', {
            resizeType : 1,
            allowPreviewEmoticons : false,
            allowImageUpload : true,
            width : '100%',
            items : [
                'source', '|', 'undo', 'redo', '|', 'preview', 'print', 'template', 'code', 'cut', 'copy', 'paste',
                'plainpaste', 'wordpaste', '|', 'justifyleft', 'justifycenter', 'justifyright',
                'justifyfull', 'insertorderedlist', 'insertunorderedlist', 'indent', 'outdent', 'subscript',
                'superscript', 'clearhtml', 'quickformat', 'selectall', '/', 'fullscreen',
                'formatblock', 'fontname', 'fontsize', '|', 'forecolor', 'hilitecolor', 'bold',
                'italic', 'underline', 'strikethrough', 'lineheight', 'removeformat', '|', 'image', 'multiimage',
                'table', 'hr', 'emoticons', 'pagebreak',
                'anchor', 'link', 'unlink']
        });
    });
    
    KindEditor.options.cssData = 'img { max-width:400px; }';
</script>
<?php } ?>