<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div class="itemtitle">
<ul class="tab1">
<li <?php if($_GET['b'] == 'pc' || !$_GET['b']) { ?>class="current"<?php } ?>>
<a href="<?php echo $dourl;?>&b=pc<?php echo $urlmod;?>"><span>PC</span></a>
</li>
<li <?php if($_GET['b'] == 'mobile') { ?>class="current"<?php } ?>>
<a href="<?php echo $dourl;?>&b=mobile<?php echo $urlmod;?>"><span>&#25163;&#26426;</span></a>
</li>
</ul>
</div>
<?php if($_GET['b'] == 'pc' || !$_GET['b']) { ?>
<tr id="aljbd_Common_setup_term"><th class="partition" colspan="15">&#80;&#67;&#39318;&#39029;&#35774;&#32622;&#39033;</th></tr>

<tr><td s="1" class="td27" colspan="2">&#24555;&#25463;&#20837;&#21475;</td></tr>
<tr  class="noborder">
<td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[HomePageShortcut]"  id="varsnew[HomePageShortcut]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)">
<?php echo $settings['HomePageShortcut']['value'];?>
</textarea>
</td>
<td>&#26684;&#24335;&#65306;&#22270;&#26631;&#124;&#38142;&#25509;&#124;&#25991;&#23383;<br>&#19968;&#34892;&#19968;&#20010;<br/>&#26368;&#22810;&#54;&#20010;</td>
</tr>

<tr><td s="1" class="td27" colspan="2">&#27169;&#22359;&#49;&#26631;&#39064;</td></tr>
<tr  class="noborder"><td class="vtop rowform">
<input  name="settingsnew[HomePageModuleTitle_1]" value="<?php echo $setting['HomePageModuleTitle_1']['value'];?>" type="text" class="form-control">
</td>
<td>
&#40664;&#35748;&#65306;&#28909;&#38376;&#27963;&#21160;<br/>
<a href="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mktips1.png" target="_blank"><img src="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mktips1.png" width="500"/></a>
</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#27169;&#22359;&#49;&#20869;&#23481;</td></tr>
<tr  class="noborder">
<td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[HomePageModuleContent_1]"  id="varsnew[HomePageModuleContent_1]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)">
<?php echo $settings['HomePageModuleContent_1']['value'];?>
</textarea>
</td>
<td>
&#26684;&#24335;&#65306;&#20027;&#26631;&#39064;&#124;&#27425;&#26631;&#39064;&#124;&#24191;&#21578;&#22270;&#29255;&#49;&#36335;&#24452;&#124;&#24191;&#21578;&#22270;&#29255;&#50;&#36335;&#24452;&#124;&#24191;&#21578;&#22270;&#29255;&#51;&#36335;&#24452;&#124;&#24191;&#21578;&#22270;&#29255;&#52;&#36335;&#24452;&#124;&#38142;&#25509;<br>
&#19968;&#34892;&#19968;&#20010;<br/>
&#26368;&#22810;&#54;&#20010;<br/>
<a href="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mktips2.png" target="_blank"><img src="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mktips2.png" width="500"/></a>
</td>
</tr>

<tr><td s="1" class="td27" colspan="2">&#27169;&#22359;&#50;&#26631;&#39064;</td></tr>
<tr  class="noborder"><td class="vtop rowform">
<input  name="settingsnew[HomePageModuleTitle_2]" value="<?php echo $setting['HomePageModuleTitle_2']['value'];?>" type="text" class="form-control">
</td>
<td>
&#40664;&#35748;&#65306;&#29305;&#33394;&#25512;&#33616;<br/>
<a href="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mktips3.png" target="_blank"><img src="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mktips3.png" width="500"/></a>
</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#27169;&#22359;&#50;&#20869;&#23481;</td></tr>
<tr  class="noborder">
<td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[HomePageModuleContent_2]"  id="varsnew[HomePageModuleContent_2]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)">
<?php echo $settings['HomePageModuleContent_2']['value'];?>
</textarea>
</td>
<td>
&#26684;&#24335;&#65306;&#20027;&#26631;&#39064;&#124;&#27425;&#26631;&#39064;&#124;&#32972;&#26223;&#22270;&#29255;&#36335;&#24452;&#124;&#24191;&#21578;&#22270;&#29255;&#36335;&#24452;&#124;&#25353;&#38062;&#25991;&#23383;&#124;&#25353;&#38062;&#39068;&#33394;&#124;&#38142;&#25509;<br>
&#19968;&#34892;&#19968;&#20010;<br/>
&#26368;&#22810;&#53;&#20010;<br/>
<a href="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mktips4.png" target="_blank"><img src="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mktips4.png" width="500"/></a>
</td>
</tr>

<tr><td s="1" class="td27" colspan="2">&#27169;&#22359;&#51;&#26631;&#39064;</td></tr>
<tr  class="noborder"><td class="vtop rowform">
<input  name="settingsnew[HomePageModuleTitle_3]" value="<?php echo $setting['HomePageModuleTitle_3']['value'];?>" type="text" class="form-control">
</td>
<td>
&#40664;&#35748;&#65306;&#21457;&#29616;&#22909;&#36135;<br/>
<a href="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mktips5.png" target="_blank"><img src="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mktips5.png" width="500"/></a>
</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#27169;&#22359;&#51;&#20869;&#23481;</td></tr>
<tr  class="noborder">
<td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[HomePageModuleContent_3]"  id="varsnew[HomePageModuleContent_3]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)">
<?php echo $settings['HomePageModuleContent_3']['value'];?>
</textarea>
</td>
<td>&#26684;&#24335;&#65306;&#20027;&#26631;&#39064;&#124;&#27425;&#26631;&#39064;&#124;&#24191;&#21578;&#22270;&#29255;&#36335;&#24452;&#124;&#38142;&#25509;<br>
&#19968;&#34892;&#19968;&#20010;<br/>
&#26368;&#22810;&#54;&#20010;<br/>
<a href="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mktips6.png" target="_blank"><img src="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mktips6.png" width="500"/></a>
</td>
</tr>

<tr><td s="1" class="td27" colspan="2">&#39318;&#39029;&#25512;&#33616;&#21830;&#21697;&#20851;&#38381;&#20998;&#31867;</td></tr>
<tr class="noborder">
<td class="vtop rowform" s="1">
<ul onmouseover="altStyle(this);">
<li class="checked"><input type="radio"  value="1"  <?php if($settings['closeGoodsType']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[closeGoodsType]" class="radio">&nbsp;&#26159;</li>
<li><input type="radio" value="0" <?php if($settings['closeGoodsType']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[closeGoodsType]" class="radio">&nbsp;&#21542;</li>
</ul>
<br></td><td>&#24320;&#21551;&#24320;&#20851;&#23558;&#20851;&#38381;&#12300;&#36824;&#27809;&#36891;&#22815;&#12301;&#19979;&#26041;&#21830;&#21697;&#20998;&#31867;&#23548;&#33322;</td>
</tr>


<tr><td s="1" class="td27" colspan="2">&#39318;&#39029;&#36718;&#36716;&#22270;&#29255;</td></tr>
<tr  class="noborder"><td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[index_lz]"  id="varsnew[index_lz]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['index_lz']['value'];?></textarea>
</td><td>&#26684;&#24335;&#65306;&#22270;&#29255;&#36335;&#24452;&#124;&#22270;&#29255;&#38142;&#25509;&#124;&#22270;&#29255;&#25551;&#36848;<br/>&#40664;&#35748;&#20363;&#23376;&#65306;<br/>source/plugin/aljbd/images/adv1.jpg|http://addon.discuz.com/?@aljbd.plugin|&#22270;&#29255;&#25551;&#36848;<br/>source/plugin/aljbd/images/adv2.jpg|http://addon.discuz.com/?@aljbd.plugin|&#22270;&#29255;&#25551;&#36848;</td></tr>

<tr><td s="1" class="td27" colspan="2">关闭轮转右侧模块</td></tr>
<tr class="noborder">
<td class="vtop rowform" s="1">
<ul onmouseover="altStyle(this);">
<li class="checked"><input type="radio"  value="1"  <?php if($settings['closeggcard']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[closeggcard]" class="radio">&nbsp;&#26159;</li>
<li><input type="radio" value="0" <?php if($settings['closeggcard']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[closeggcard]" class="radio">&nbsp;&#21542;</li>
</ul>
<br></td><td>关闭后不显示首页轮转右侧模块(头像、店铺管理、公告、快捷入口那块隐藏不显示)</td>
</tr>

<tr><td s="1" class="td27" colspan="2">&#39318;&#39029;&#20844;&#21578;</td></tr>
<tr  class="noborder"><td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[gg]"  id="varsnew[gg]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['gg']['value'];?></textarea>
</td><td>&#26684;&#24335;&#65306;&#20844;&#21578;&#124;&#38142;&#25509;<br/>&#19968;&#34892;&#19968;&#21477;<br/>&#26368;&#22810;&#26174;&#31034;&#56;&#34892;&#65292;&#33258;&#24049;&#25511;&#21046;</td></tr>

<tr><td s="1" class="td27" colspan="2">&#19981;&#26174;&#31034;&#39318;&#39029;&#20844;&#21578;</td></tr>
<tr class="noborder">
<td class="vtop rowform" s="1">
<ul ><li class="checked"><input type="radio"  value="1"  <?php if($settings['index_gg']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[index_gg]" class="radio">&nbsp;&#26159;</li><li><input type="radio" value="0" <?php if($settings['index_gg']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[index_gg]" class="radio">&nbsp;&#21542;</li></ul>
<br></td><td></td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#21697;&#29260;&#20837;&#39547;&#25353;&#32445;&#25991;&#23383;&#25551;&#36848;</td></tr>
<tr  class="noborder"><td class="vtop rowform">
<input  name="settingsnew[attend]" value="<?php echo $setting['attend']['value'];?>" type="text" class="form-control">
</td><td>&#40664;&#35748;&#65306;&#21697;&#29260;&#20837;&#39547;</td></tr>
<tr><td s="1" class="td27" colspan="2">&#21697;&#29260;&#20837;&#39547;&#25353;&#38062;&#39068;&#33394;</td></tr>
<tr  class="noborder">
<td class="vtop rowform">
<div class="row">
<div class="col-md-10">
<input class="form-control" type="text" id="p_color_text" onchange="text_add_color('p_color_text','p_color_color')" name="settingsnew[p_color]" value="<?php echo $settings['p_color']['value'];?>">
</div>
<div class="col-md-2 color-text" >
<input id="p_color_color" type="color" onchange="color_add_text('p_color_color','p_color_text')" value="<?php echo $settings['p_color']['value'];?>">
</div>
</div>
</td>
<td>&#40664;&#35748;&#65306;#cc0033</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#24215;&#38138;&#31649;&#29702;&#25991;&#23383;&#25551;&#36848;</td></tr>
<tr  class="noborder">
<td class="vtop rowform">
<input  name="settingsnew[aljbd]" value="<?php echo $setting['aljbd']['value'];?>" type="text" class="form-control">
</td><td>&#40664;&#35748;&#65306;&#24215;&#38138;&#31649;&#29702;</td></tr>
<tr><td s="1" class="td27" colspan="2">&#25628;&#32034;&#25353;&#38062;&#39068;&#33394;</td></tr>
<tr  class="noborder">
<td class="vtop rowform">
<div class="row">
<div class="col-md-10">
<input class="form-control" type="text" id="s_color_text" onchange="text_add_color('s_color_text','s_color_color')" name="settingsnew[s_color]" value="<?php echo $settings['s_color']['value'];?>">
</div>
<div class="col-md-2 color-text" >
<input id="s_color_color" type="color" onchange="color_add_text('s_color_color','s_color_text')" value="<?php echo $settings['s_color']['value'];?>">
</div>
</div>
</td>
<td>&#40664;&#35748;&#65306;#cc0033</td></tr>
<tr><td s="1" class="td27" colspan="2">&#24215;&#38138;&#31649;&#29702;&#25353;&#38062;&#39068;&#33394;</td></tr>
<tr  class="noborder">
<td class="vtop rowform">
<div class="row">
<div class="col-md-10">
<input class="form-control" type="text" id="d_color_text" onchange="text_add_color('d_color_text','d_color_color')" name="settingsnew[d_color]" value="<?php echo $settings['d_color']['value'];?>">
</div>
<div class="col-md-2 color-text" >
<input id="d_color_color" type="color" onchange="color_add_text('d_color_color','d_color_text')" value="<?php echo $settings['d_color']['value'];?>">
</div>
</div>
</td>
<td>&#40664;&#35748;&#65306;#cc0033</td></tr>


<tr><td s="1" class="td27" colspan="2">&#20851;&#38381;&#39318;&#39029;&#25512;&#33616;&#21830;&#23478;</td></tr>
<tr class="noborder">
<td class="vtop rowform" s="1">
<ul ><li class="checked"><input type="radio"  value="1"  <?php if($settings['is_res_brand']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[is_res_brand]" class="radio">&nbsp;&#26159;</li><li><input type="radio" value="0" <?php if($settings['is_res_brand']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[is_res_brand]" class="radio">&nbsp;&#21542;</li></ul>
<br></td><td>&#24517;&#39035;&#20445;&#35777;&#21830;&#24773;&#19982;&#21697;&#29260;&#36798;&#20154;&#28857;&#35780;&#26159;&#20851;&#38381;&#29366;&#24577;&#25165;&#33021;&#20851;&#38381;&#25512;&#33616;&#21830;&#23478;</td>
</tr>

<tr><td s="1" class="td27" colspan="2">&#39318;&#39029;&#25512;&#33616;&#21830;&#23478;&#19979;&#26041;&#65;&#68;</td></tr>
<tr  class="noborder"><td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[bad]"  id="varsnew[bad]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['bad']['value'];?></textarea>
</td><td>&#60;&#97;&#32;&#104;&#114;&#101;&#102;&#61;&#39;&#104;&#116;&#116;&#112;&#58;&#47;&#47;&#97;&#100;&#100;&#111;&#110;&#46;&#100;&#105;&#115;&#99;&#117;&#122;&#46;&#99;&#111;&#109;&#47;&#63;&#64;&#97;&#108;&#106;&#98;&#100;&#46;&#112;&#108;&#117;&#103;&#105;&#110;&#46;&#50;&#56;&#49;&#50;&#57;&#39;&#32;&#116;&#97;&#114;&#103;&#101;&#116;&#61;&#39;&#95;&#98;&#108;&#97;&#110;&#107;&#39;&#62;&#60;&#105;&#109;&#103;&#32;&#115;&#116;&#121;&#108;&#101;&#61;&#39;&#119;&#105;&#100;&#116;&#104;&#58;&#49;&#50;&#48;&#48;&#112;&#120;&#59;&#104;&#101;&#105;&#103;&#104;&#116;&#58;&#49;&#50;&#53;&#112;&#120;&#39;&#32;&#98;&#111;&#114;&#100;&#101;&#114;&#61;&#39;&#48;&#39;&#32;&#115;&#114;&#99;&#61;&#39;&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#97;&#108;&#106;&#98;&#100;&#47;&#116;&#101;&#109;&#112;&#108;&#97;&#116;&#101;&#47;&#105;&#110;&#100;&#101;&#120;&#47;&#105;&#109;&#97;&#103;&#101;&#115;&#47;&#109;&#114;&#97;&#100;&#46;&#106;&#112;&#103;&#39;&#32;&#97;&#108;&#116;&#61;&#39;&#21697;&#29260;&#21830;&#23478;&#39;&#47;&#62;&#60;&#47;&#97;&#62;</td></tr>
<tr><td s="1" class="td27" colspan="2">&#39318;&#39029;&#28909;&#38376;&#27963;&#21160;&#19979;&#26041;&#65;&#68;</td></tr>
<tr  class="noborder"><td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[gad]"  id="varsnew[gad]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['gad']['value'];?></textarea>
</td><td>&#60;&#97;&#32;&#104;&#114;&#101;&#102;&#61;&#39;&#104;&#116;&#116;&#112;&#58;&#47;&#47;&#97;&#100;&#100;&#111;&#110;&#46;&#100;&#105;&#115;&#99;&#117;&#122;&#46;&#99;&#111;&#109;&#47;&#63;&#64;&#97;&#108;&#106;&#98;&#100;&#46;&#112;&#108;&#117;&#103;&#105;&#110;&#46;&#50;&#56;&#49;&#50;&#57;&#39;&#32;&#116;&#97;&#114;&#103;&#101;&#116;&#61;&#39;&#95;&#98;&#108;&#97;&#110;&#107;&#39;&#62;&#60;&#105;&#109;&#103;&#32;&#115;&#116;&#121;&#108;&#101;&#61;&#39;&#119;&#105;&#100;&#116;&#104;&#58;&#49;&#50;&#48;&#48;&#112;&#120;&#59;&#104;&#101;&#105;&#103;&#104;&#116;&#58;&#49;&#50;&#53;&#112;&#120;&#39;&#32;&#98;&#111;&#114;&#100;&#101;&#114;&#61;&#39;&#48;&#39;&#32;&#115;&#114;&#99;&#61;&#39;&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#97;&#108;&#106;&#98;&#100;&#47;&#116;&#101;&#109;&#112;&#108;&#97;&#116;&#101;&#47;&#105;&#110;&#100;&#101;&#120;&#47;&#105;&#109;&#97;&#103;&#101;&#115;&#47;&#109;&#114;&#97;&#100;&#46;&#106;&#112;&#103;&#39;&#32;&#97;&#108;&#116;&#61;&#39;&#21697;&#29260;&#21830;&#23478;&#39;&#47;&#62;&#60;&#47;&#97;&#62;</td></tr>
<tr><td s="1" class="td27" colspan="2">&#39318;&#39029;&#29305;&#33394;&#25512;&#33616;&#19979;&#26041;&#65;&#68;</td></tr>
<tr  class="noborder"><td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[cad]"  id="varsnew[cad]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['cad']['value'];?></textarea>
</td><td>&#60;&#97;&#32;&#104;&#114;&#101;&#102;&#61;&#39;&#104;&#116;&#116;&#112;&#58;&#47;&#47;&#97;&#100;&#100;&#111;&#110;&#46;&#100;&#105;&#115;&#99;&#117;&#122;&#46;&#99;&#111;&#109;&#47;&#63;&#64;&#97;&#108;&#106;&#98;&#100;&#46;&#112;&#108;&#117;&#103;&#105;&#110;&#46;&#50;&#56;&#49;&#50;&#57;&#39;&#32;&#116;&#97;&#114;&#103;&#101;&#116;&#61;&#39;&#95;&#98;&#108;&#97;&#110;&#107;&#39;&#62;&#60;&#105;&#109;&#103;&#32;&#115;&#116;&#121;&#108;&#101;&#61;&#39;&#119;&#105;&#100;&#116;&#104;&#58;&#49;&#50;&#48;&#48;&#112;&#120;&#59;&#104;&#101;&#105;&#103;&#104;&#116;&#58;&#49;&#50;&#53;&#112;&#120;&#39;&#32;&#98;&#111;&#114;&#100;&#101;&#114;&#61;&#39;&#48;&#39;&#32;&#115;&#114;&#99;&#61;&#39;&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#97;&#108;&#106;&#98;&#100;&#47;&#116;&#101;&#109;&#112;&#108;&#97;&#116;&#101;&#47;&#105;&#110;&#100;&#101;&#120;&#47;&#105;&#109;&#97;&#103;&#101;&#115;&#47;&#109;&#114;&#97;&#100;&#46;&#106;&#112;&#103;&#39;&#32;&#97;&#108;&#116;&#61;&#39;&#21697;&#29260;&#21830;&#23478;&#39;&#47;&#62;&#60;&#47;&#97;&#62;</td></tr>
<tr><td s="1" class="td27" colspan="2">&#39318;&#39029;&#21457;&#29616;&#22909;&#36135;&#19979;&#26041;&#65;&#68;</td></tr>
<tr  class="noborder"><td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[fad]"  id="varsnew[fad]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['fad']['value'];?></textarea>
</td><td>&#60;&#97;&#32;&#104;&#114;&#101;&#102;&#61;&#39;&#104;&#116;&#116;&#112;&#58;&#47;&#47;&#97;&#100;&#100;&#111;&#110;&#46;&#100;&#105;&#115;&#99;&#117;&#122;&#46;&#99;&#111;&#109;&#47;&#63;&#64;&#97;&#108;&#106;&#98;&#100;&#46;&#112;&#108;&#117;&#103;&#105;&#110;&#46;&#50;&#56;&#49;&#50;&#57;&#39;&#32;&#116;&#97;&#114;&#103;&#101;&#116;&#61;&#39;&#95;&#98;&#108;&#97;&#110;&#107;&#39;&#62;&#60;&#105;&#109;&#103;&#32;&#115;&#116;&#121;&#108;&#101;&#61;&#39;&#119;&#105;&#100;&#116;&#104;&#58;&#49;&#50;&#48;&#48;&#112;&#120;&#59;&#104;&#101;&#105;&#103;&#104;&#116;&#58;&#49;&#50;&#53;&#112;&#120;&#39;&#32;&#98;&#111;&#114;&#100;&#101;&#114;&#61;&#39;&#48;&#39;&#32;&#115;&#114;&#99;&#61;&#39;&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#97;&#108;&#106;&#98;&#100;&#47;&#116;&#101;&#109;&#112;&#108;&#97;&#116;&#101;&#47;&#105;&#110;&#100;&#101;&#120;&#47;&#105;&#109;&#97;&#103;&#101;&#115;&#47;&#109;&#114;&#97;&#100;&#46;&#106;&#112;&#103;&#39;&#32;&#97;&#108;&#116;&#61;&#39;&#21697;&#29260;&#21830;&#23478;&#39;&#47;&#62;&#60;&#47;&#97;&#62;</td></tr>

<tr><td s="1" class="td27" colspan="2">&#39318;&#39029;&#25512;&#33616;&#21830;&#23478;&#26174;&#31034;&#35760;&#24405;&#25968;</td></tr>
<tr class="noborder"><td class="vtop rowform">
<input  name="settingsnew[recnum]" value="<?php echo $settings['recnum']['value'];?>" type="text" class="txt">
<td></tr>

<tr>
<td s="1" class="td27" colspan="2">&#39318;&#39029;&#84;&#73;&#84;&#76;&#69;&#32972;&#26223;&#33258;&#23450;&#20041;&#39068;&#33394;</td>
</tr>
<tr  class="noborder">
<td class="vtop rowform">
<div class="row">
<div class="col-md-10">
<input class="form-control" type="text" id="ddcolor_text" onchange="text_add_color('ddcolor_text','ddcolor_color')" name="settingsnew[ddcolor]" value="<?php echo $settings['ddcolor']['value'];?>">
</div>
<div class="col-md-2 color-text" >
<input id="ddcolor_color" type="color" onchange="color_add_text('ddcolor_color','ddcolor_text')" value="<?php echo $settings['ddcolor']['value'];?>">
</div>
</div>
</td>
</tr>
<?php } else { ?>
<tr id="aljbd_Common_setup_term"><th class="partition" colspan="15">&#25163;&#26426;&#29256;&#39318;&#39029;&#35774;&#32622;&#39033;</th></tr>

<tr><td s="1" class="td27" colspan="2">首页图片弹窗广告</td></tr>
<tr  class="noborder"><td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[mobile_index_tan_ad]"  id="varsnew[mobile_index_tan_ad]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['mobile_index_tan_ad']['value'];?></textarea>
</td>
<td>
首页图片弹窗广告，最大宽度330px<br/>
普通广告图片：&#60;&#105;&#109;&#103;&#32;&#115;&#114;&#99;&#61;&#34;&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#97;&#108;&#106;&#104;&#116;&#47;&#115;&#116;&#97;&#116;&#105;&#99;&#47;&#105;&#109;&#103;&#47;&#55;&#46;&#106;&#112;&#103;&#34;&#32;&#47;&#62;<br/>
带链接跳转广告图片：&#60;&#97;&#32;&#104;&#114;&#101;&#102;&#61;&#34;&#35;&#34;&#62;&#60;&#105;&#109;&#103;&#32;&#115;&#114;&#99;&#61;&#34;&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#97;&#108;&#106;&#104;&#116;&#47;&#115;&#116;&#97;&#116;&#105;&#99;&#47;&#105;&#109;&#103;&#47;&#55;&#46;&#106;&#112;&#103;&#34;&#32;&#47;&#62;&#60;&#47;&#97;&#62;<br/>
自助广告：&#60;&#115;&#99;&#114;&#105;&#112;&#116;&#32;&#115;&#114;&#99;&#61;&#39;&#112;&#108;&#117;&#103;&#105;&#110;&#46;&#112;&#104;&#112;&#63;&#105;&#100;&#61;&#97;&#108;&#106;&#97;&#100;&#38;&#97;&#99;&#116;&#61;&#103;&#101;&#116;&#97;&#100;&#38;&#107;&#101;&#121;&#110;&#97;&#109;&#101;&#61;&#97;&#108;&#106;&#98;&#100;&#38;&#109;&#111;&#100;&#117;&#108;&#101;&#61;&#109;&#111;&#98;&#105;&#108;&#101;&#95;&#105;&#110;&#100;&#101;&#120;&#95;&#116;&#97;&#110;&#95;&#97;&#100;&#38;&#104;&#101;&#105;&#103;&#104;&#116;&#61;&#97;&#117;&#116;&#111;&#39;&#62;&#60;&#47;&#115;&#99;&#114;&#105;&#112;&#116;&#62;
</td>
</tr>
<tr><td s="1" class="td27" colspan="2">首页图片弹窗广告自动关闭时间</td></tr>
<tr class="noborder">
<td class="vtop rowform">
<input  name="settingsnew[mobile_index_tan_ad_time]" value="<?php echo $settings['mobile_index_tan_ad_time']['value'];?>" type="text" class="form-control">
</td>
<td>单位：秒<br/>默认3秒</td>
</tr>
<tr><td s="1" class="td27" colspan="2">首页图片弹窗广告弹出频率</td></tr>
<tr class="noborder">
<td class="vtop rowform">
<input  name="settingsnew[mobile_index_tan_ad_rate_time]" value="<?php echo $settings['mobile_index_tan_ad_rate_time']['value'];?>" type="text" class="form-control">
</td>
<td>单位：秒<br/>默认一天一弹86400秒</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#20851;&#38381;&#21830;&#22478;&#28909;&#28857;</td></tr>
<tr class="noborder">
<td class="vtop rowform" s="1">
<ul onmouseover="altStyle(this);"><li class="checked"><input type="radio"  value="1"  <?php if($settings['is_mobile_index_hot']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[is_mobile_index_hot]" class="radio">&nbsp;&#26159;</li><li><input type="radio" value="0" <?php if($settings['is_mobile_index_hot']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[is_mobile_index_hot]" class="radio">&nbsp;&#21542;</li></ul>
<br></td><td></td>
</tr>

<tr><td s="1" class="td27" colspan="2">&#21830;&#22478;&#28909;&#28857;&#22270;&#26631;</td></tr>
<tr class="noborder"><td class="vtop rowform">
<input  name="settingsnew[gg_icon]" value="<?php echo $settings['gg_icon']['value'];?>" type="text" class="form-control">
</td><td>&#22270;&#29255;&#36335;&#24452;</td></tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#25628;&#32034;&#20004;&#20391;&#22270;&#26631;</td></tr>
<tr  class="noborder"><td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[mobile_index_img_s]"  id="varsnew[mobile_index_img_s]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['mobile_index_img_s']['value'];?></textarea>
</td>
<td>
&#19981;&#24320;&#21551;&#20840;&#23616;&#39030;&#37096;&#26631;&#39064;&#36718;&#36716;&#19978;&#26041;&#25628;&#32034;&#20004;&#20391;&#22270;&#26631;&#33258;&#23450;&#20041;&#65292;&#19968;&#34892;&#19968;&#20010;&#65292;&#22270;&#26631;&#22823;&#23567;64*64&#65292;&#31532;&#19968;&#34892;&#24038;&#65292;&#31532;&#20108;&#34892;&#21491;
<br/>&#26684;&#24335;&#65306;&#22270;&#26631;&#36335;&#24452;&#124;&#38142;&#25509;
<br/>&#40664;&#35748;&#65306;
<br/>source/plugin/aljbd/template/touch/header/img/btype.png|plugin.php?id=aljbd&act=type
<br/>source/plugin/aljbd/template/touch/header/img/badd.png|plugin.php?id=aljbd&act=attend
</td>
</tr>
<tr><td s="1" class="td27" colspan="2">关闭轮转上方悬浮搜索</td></tr>
<tr class="noborder">
<td class="vtop rowform" s="1">
<ul onmouseover="altStyle(this);">
<li class="checked"><input type="radio"  value="1"  <?php if($settings['is_lz_search']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[is_lz_search]" class="radio">&nbsp;&#26159;</li>
<li><input type="radio" value="0" <?php if($settings['is_lz_search']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[is_lz_search]" class="radio">&nbsp;&#21542;</li>
</ul>
<br>
</td>
<td></td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#24320;&#21551;&#36718;&#36716;</td></tr>
<tr class="noborder">
<td class="vtop rowform" s="1">
<ul onmouseover="altStyle(this);"><li class="checked"><input type="radio"  value="1"  <?php if($settings['sj_index_lz']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[sj_index_lz]" class="radio">&nbsp;&#26159;</li><li><input type="radio" value="2" <?php if($settings['sj_index_lz']['value']==2) { ?>checked=""<?php } ?> name="settingsnew[sj_index_lz]" class="radio">&nbsp;&#21542;</li></ul>
<br></td><td></td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#36718;&#36716;&#22270;&#29255;</td></tr>
<tr  class="noborder"><td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[sj_img_1]"  id="varsnew[sj_img_1]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['sj_img_1']['value'];?></textarea>
</td><td>&#26684;&#24335;&#65306;&#22270;&#29255;&#36335;&#24452;&#124;&#22270;&#29255;&#38142;&#25509;&#124;&#22270;&#29255;&#25551;&#36848;<br/>&#40664;&#35748;&#20363;&#23376;&#65306;<br/>source/plugin/aljbd/images/m1.jpg|http://addon.discuz.com/?@aljbd.plugin|&#25551;&#36848;<br/>source/plugin/aljbd/images/m2.jpg|http://addon.discuz.com/?@aljbd.plugin|&#25551;&#36848;<br/>source/plugin/aljbd/images/m3.jpg|http://addon.discuz.com/?@aljbd.plugin|&#25551;&#36848;</td></tr>

<tr><td s="1" class="td27" colspan="2">是否关闭轮转下方波浪线</td></tr>
<tr class="noborder">
<td class="vtop rowform" s="1">
<ul onmouseover="altStyle(this);">
<li class="checked">
<input type="radio"  value="1"  <?php if($settings['is_wave']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[is_wave]" class="radio">&nbsp;&#26159;
</li>
<li>
<input type="radio" value="0" <?php if($settings['is_wave']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[is_wave]" class="radio">&nbsp;&#21542;
</li>
</ul>
<br></td>
<td></td>
</tr>

<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#22270;&#26631;&#23548;&#33322;</td></tr>
<tr  class="noborder"><td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[sj_index_dh]"  id="varsnew[sj_index_dh]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['sj_index_dh']['value'];?></textarea>
</td><td>&#26684;&#24335;&#65306;&#21517;&#31216;&#124;&#38142;&#25509;&#124;&#22270;&#29255;&#36335;&#24452;<br/>&#40664;&#35748;&#20363;&#23376;&#65306;<br/>&#21830;&#38138;&#20998;&#31867;|plugin.php?id=aljbd&act=fl|source/plugin/aljbd/images/sj/categorys.png<br/>&#21830;&#38138;|plugin.php?id=aljbd&act=dianpu|source/plugin/aljbd/images/sj/nearby.png<br/>&#21830;&#21697;|plugin.php?id=aljbd&act=goods|source/plugin/aljbd/images/sj/tops.png<br/>&#21830;&#38138;&#30456;&#20876;|plugin.php?id=aljbd&act=alist|source/plugin/aljbd/images/sj/album.png<br/>&#22320;&#21306;|plugin.php?id=aljbd&act=dq|source/plugin/aljbd/images/sj/fenlei.png<br/>&#21830;&#24773;|plugin.php?id=aljbd&act=nlist|source/plugin/aljbd/images/sj/article.png<br/>&#20248;&#24800;&#21048;|plugin.php?id=aljbd&act=clist|source/plugin/aljbd/images/sj/coupon.png<br/>&#35770;&#22363;|forum.php|source/plugin/aljbd/images/sj/group.png</td></tr>

<tr><td s="1" class="td27" colspan="2">&#22270;&#25991;&#24191;&#21578;</td></tr>
<tr class="noborder"><td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[mobile_index_Photo_Ads]"  id="varsnew[mobile_index_Photo_Ads]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['mobile_index_Photo_Ads']['value'];?></textarea>
</td><td colspan=2>&#19968;&#34892;&#19968;&#20010;<br/>&#26684;&#24335;&#58;&#22823;&#25991;&#23383;&#124;&#23567;&#25991;&#23383;&#124;&#22270;&#29255;&#36335;&#24452;&#124;&#38142;&#25509;<br/><img src="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/WX20180717-152528.png" width="200"/></td></tr>

<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#19977;&#26684;&#24191;&#21578;&#22270;&#27004;&#23618;&#26631;&#39064;&#22270;&#29255;</td></tr>
<tr class="noborder"><td class="vtop rowform">
<input  name="settingsnew[mobile_index_tad_title]" placeholder="&#22635;&#20889;&#22270;&#29255;&#36335;&#24452;" value="<?php echo $settings['mobile_index_tad_title']['value'];?>" type="text" class="form-control">
</td><td colspan=2>&#27004;&#23618;&#26631;&#39064;&#22270;&#29255;,&#22635;&#20889;&#22270;&#29255;&#36335;&#24452;<br/><img src="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/clickImage.png" width="200"/>
</td></tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#19977;&#26684;&#24191;&#21578;&#22270;</td></tr>
<tr class="noborder"><td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[mobile_index_tad]"  id="varsnew[mobile_index_tad]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['mobile_index_tad']['value'];?></textarea>
</td><td colspan=2>&#19968;&#34892;&#19968;&#20010;<br/>&#26684;&#24335;&#65306;&#22270;&#29255;&#36335;&#24452;&#124;&#38142;&#25509;<br/>&#31532;&#19968;&#34892;&#24038;&#36793;&#22823;&#22270;&#25512;&#33616;&#23610;&#23544;&#51;&#48;&#48;&#42;&#51;&#48;&#48;<br/>&#31532;&#20108;&#34892;&#21491;&#36793;&#19978;&#26041;&#22270;&#25512;&#33616;&#23610;&#23544;&#51;&#48;&#48;&#42;&#49;&#52;&#56;<br/>&#31532;&#19977;&#34892;&#21491;&#36793;&#19979;&#26041;&#22270;&#25512;&#33616;&#23610;&#23544;&#51;&#48;&#48;&#42;&#49;&#52;&#56;<br/><img src="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/clickImagesange.png" width="200"/>
</td></tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#22235;&#26684;&#24191;&#21578;&#22270;&#27004;&#23618;&#26631;&#39064;&#22270;&#29255;</td></tr>
<tr class="noborder"><td class="vtop rowform">
<input  name="settingsnew[mobile_index_fad_title]" placeholder="&#22635;&#20889;&#22270;&#29255;&#36335;&#24452;" value="<?php echo $settings['mobile_index_fad_title']['value'];?>" type="text" class="form-control">
</td><td colspan=2>&#27004;&#23618;&#26631;&#39064;&#22270;&#29255;,&#22635;&#20889;&#22270;&#29255;&#36335;&#24452;<br/><img src="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/clickImage.png" width="200"/>
</td></tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#22235;&#26684;&#24191;&#21578;&#22270;</td></tr>
<tr class="noborder"><td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[mobile_index_fad]"  id="varsnew[mobile_index_fad]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['mobile_index_fad']['value'];?></textarea>
</td><td colspan=2>&#19968;&#34892;&#19968;&#20010;<br/>&#26684;&#24335;&#65306;&#22270;&#29255;&#36335;&#24452;&#124;&#38142;&#25509;<br/>&#31532;&#19968;&#34892;&#24038;&#36793;&#19978;&#26041;&#22270;&#25512;&#33616;&#23610;&#23544;&#51;&#48;&#48;&#42;&#49;&#52;&#56;<br/>&#31532;&#20108;&#34892;&#24038;&#36793;&#19979;&#26041;&#22270;&#25512;&#33616;&#23610;&#23544;&#51;&#48;&#48;&#42;&#49;&#52;&#56;<br/>&#31532;&#19977;&#34892;&#21491;&#36793;&#19978;&#26041;&#22270;&#25512;&#33616;&#23610;&#23544;&#51;&#48;&#48;&#42;&#49;&#52;&#56;<br/>&#31532;&#22235;&#34892;&#21491;&#36793;&#19979;&#26041;&#22270;&#25512;&#33616;&#23610;&#23544;&#51;&#48;&#48;&#42;&#49;&#52;&#56;<br/><img src="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/clickImagesige.png" width="200" />
</td></tr>

<tr><td s="1" class="td27" colspan="2">&#27178;&#21521;&#22235;&#26684;&#24191;&#21578;&#27004;&#23618;&#26631;&#39064;&#22270;&#29255;</td></tr>
<tr class="noborder"><td class="vtop rowform">
<input  name="settingsnew[mobile_index_siad_title]" placeholder="&#22635;&#20889;&#22270;&#29255;&#36335;&#24452;" value="<?php echo $settings['mobile_index_siad_title']['value'];?>" type="text" class="form-control">
</td><td colspan=2>&#27004;&#23618;&#26631;&#39064;&#22270;&#29255;,&#22635;&#20889;&#22270;&#29255;&#36335;&#24452;<br/><img src="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/clickImage.png" width="200"/>
</td></tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#27178;&#21521;&#22235;&#26684;&#24191;&#21578;</td></tr>
<tr class="noborder"><td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[mobile_index_siad]"  id="varsnew[mobile_index_siad]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['mobile_index_siad']['value'];?></textarea>
</td><td colspan=2>&#19968;&#34892;&#19968;&#20010;<br/>&#26684;&#24335;&#65306;&#22270;&#29255;&#36335;&#24452;&#124;&#38142;&#25509;<br/>&#20174;&#24038;&#24448;&#21491;&#19968;&#19968;&#23545;&#24212;&#65292;&#25512;&#33616;&#23610;&#23544;&#49;&#56;&#54;&#120;&#50;&#52;&#48;<br/><img src="https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/xiaosige.png" width="200" />
</td></tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#25512;&#33616;&#21830;&#21697;&#24320;&#21551;&#27178;&#25490;</td></tr>
<tr class="noborder">
<td class="vtop rowform" s="1">
<ul onmouseover="altStyle(this);"><li class="checked"><input type="radio"  value="1"  <?php if($settings['is_mobile_index_resgoods']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[is_mobile_index_resgoods]" class="radio">&nbsp;&#26159;</li><li><input type="radio" value="0" <?php if($settings['is_mobile_index_resgoods']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[is_mobile_index_resgoods]" class="radio">&nbsp;&#21542;</li></ul>
<br></td><td>&#24320;&#21551;&#21518;&#19968;&#34892;&#25490;&#19968;&#20010;&#25512;&#33616;&#21830;&#21697;</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#24215;&#38138;&#26174;&#31034;&#21407;&#26377;&#26679;&#24335;</td></tr>
<tr class="noborder">
<td class="vtop rowform" s="1">
<ul onmouseover="altStyle(this);"><li class="checked"><input type="radio"  value="1"  <?php if($settings['is_mobile_index_resdp']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[is_mobile_index_resdp]" class="radio">&nbsp;&#26159;</li><li><input type="radio" value="0" <?php if($settings['is_mobile_index_resdp']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[is_mobile_index_resdp]" class="radio">&nbsp;&#21542;</li></ul>
<br></td><td>&#24320;&#21551;&#24320;&#20851;&#23558;&#26174;&#31034;&#21407;&#26377;&#25512;&#33616;&#21830;&#23478;&#12289;&#28909;&#38376;&#21830;&#23478;&#12289;&#26368;&#26032;&#21830;&#23478;</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#39318;&#39029;&#20851;&#38381;&#29468;&#24744;&#21916;&#27426;</td></tr>
<tr class="noborder">
<td class="vtop rowform" s="1">
<ul onmouseover="altStyle(this);"><li class="checked"><input type="radio"  value="1"  <?php if($settings['is_mobile_index_love']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[is_mobile_index_love]" class="radio">&nbsp;&#26159;</li><li><input type="radio" value="0" <?php if($settings['is_mobile_index_love']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[is_mobile_index_love]" class="radio">&nbsp;&#21542;</li></ul>
<br></td><td>&#24320;&#21551;&#24320;&#20851;&#23558;&#19981;&#26174;&#31034;&#39318;&#39029;&#29468;&#24744;&#21916;&#27426;</td>
</tr>

<tr><td s="1" class="td27" colspan="2">猜您喜欢调用推荐商品</td></tr>
<tr class="noborder">
<td class="vtop rowform" s="1">
<ul onmouseover="altStyle(this);">
<li class="checked"><input type="radio"  value="1"  <?php if($settings['is_mobile_index_love_rec']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[is_mobile_index_love_rec]" class="radio">&nbsp;&#26159;</li>
<li><input type="radio" value="0" <?php if($settings['is_mobile_index_love_rec']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[is_mobile_index_love_rec]" class="radio">&nbsp;&#21542;</li></ul>
<br></td>
<td>猜您喜欢开启分类横向滚动模式开关未开启时生效</td>
</tr>
<tr><td s="1" class="td27" colspan="2">猜您喜欢上方广告</td></tr>
<tr  class="noborder"><td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[mobile_index_love_top_ad]"  id="varsnew[mobile_index_love_top_ad]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['mobile_index_love_top_ad']['value'];?></textarea>
</td>
<td>
普通广告图片：&#60;&#105;&#109;&#103;&#32;&#115;&#114;&#99;&#61;&#34;&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#97;&#108;&#106;&#98;&#100;&#47;&#105;&#109;&#97;&#103;&#101;&#115;&#47;&#105;&#110;&#100;&#101;&#120;&#47;&#108;&#111;&#118;&#101;&#95;&#116;&#111;&#112;&#95;&#97;&#100;&#46;&#103;&#105;&#102;&#34;&#32;&#47;&#62;<br/>
带链接跳转广告图片：&#60;&#97;&#32;&#104;&#114;&#101;&#102;&#61;&#34;&#35;&#34;&#62;&#60;&#105;&#109;&#103;&#32;&#115;&#114;&#99;&#61;&#34;&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#97;&#108;&#106;&#98;&#100;&#47;&#105;&#109;&#97;&#103;&#101;&#115;&#47;&#105;&#110;&#100;&#101;&#120;&#47;&#108;&#111;&#118;&#101;&#95;&#116;&#111;&#112;&#95;&#97;&#100;&#46;&#103;&#105;&#102;&#34;&#32;&#47;&#62;&#60;&#47;&#97;&#62;<br/>
自助广告：&#60;&#115;&#99;&#114;&#105;&#112;&#116;&#32;&#115;&#114;&#99;&#61;&#39;&#112;&#108;&#117;&#103;&#105;&#110;&#46;&#112;&#104;&#112;&#63;&#105;&#100;&#61;&#97;&#108;&#106;&#97;&#100;&#38;&#97;&#99;&#116;&#61;&#103;&#101;&#116;&#97;&#100;&#38;&#107;&#101;&#121;&#110;&#97;&#109;&#101;&#61;&#97;&#108;&#106;&#98;&#100;&#38;&#109;&#111;&#100;&#117;&#108;&#101;&#61;&#109;&#111;&#98;&#105;&#108;&#101;&#95;&#105;&#110;&#100;&#101;&#120;&#95;&#108;&#111;&#118;&#101;&#95;&#116;&#111;&#112;&#95;&#97;&#100;&#38;&#104;&#101;&#105;&#103;&#104;&#116;&#61;&#97;&#117;&#116;&#111;&#39;&#62;&#60;&#47;&#115;&#99;&#114;&#105;&#112;&#116;&#62;
</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#29468;&#24744;&#21916;&#27426;&#24320;&#21551;&#20998;&#31867;&#27178;&#21521;&#28378;&#21160;&#27169;&#24335;</td></tr>
<tr class="noborder">
<td class="vtop rowform" s="1">
<ul onmouseover="altStyle(this);"><li class="checked"><input type="radio"  value="1"  <?php if($settings['is_mobile_index_love_type']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[is_mobile_index_love_type]" class="radio">&nbsp;&#26159;</li><li><input type="radio" value="0" <?php if($settings['is_mobile_index_love_type']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[is_mobile_index_love_type]" class="radio">&nbsp;&#21542;</li></ul>
<br></td><td>&#24320;&#21551;&#21518;&#23558;&#20851;&#38381;&#25512;&#33616;&#21830;&#21697;&#65292;&#20998;&#31867;&#27169;&#24335;&#40664;&#35748;&#35843;&#29992;&#25512;&#33616;&#21830;&#21697;<br/></td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#25512;&#33616;&#21830;&#23478;&#26174;&#31034;&#25968;&#37327;</td></tr>
<tr class="noborder"><td class="vtop rowform">
<input  name="settingsnew[recommendlistnum]" value="<?php echo $settings['recommendlistnum']['value'];?>" type="text" class="form-control">
<td></tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#28909;&#38376;&#21830;&#23478;&#26174;&#31034;&#25968;&#37327;</td></tr>
<tr class="noborder"><td class="vtop rowform">
<input  name="settingsnew[viewslistnum]" value="<?php echo $settings['viewslistnum']['value'];?>" type="text" class="form-control">
<td></tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#26368;&#26032;&#21830;&#23478;&#26174;&#31034;&#25968;&#37327;</td></tr>
<tr class="noborder"><td class="vtop rowform">
<input  name="settingsnew[timelistnum]" value="<?php echo $settings['timelistnum']['value'];?>" type="text" class="form-control">
<td></tr>
<tr><td s="1" class="td27" colspan="2">&#39318;&#39029;&#25512;&#33616;&#21830;&#21697;&#26174;&#31034;&#35760;&#24405;&#25968;</td></tr>
<tr class="noborder"><td class="vtop rowform">
<input  name="settingsnew[recgnum]" value="<?php echo $settings['recgnum']['value'];?>" type="text" class="txt">
<td></tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#36718;&#36716;&#39640;&#24230;</td></tr>
<tr class="noborder"><td class="vtop rowform">
<input  name="settingsnew[mobile_lz_height]" value="<?php echo $settings['mobile_lz_height']['value'];?>" type="text" class="form-control">
</td><td>&#40664;&#35748;&#39640;&#24230;&#33258;&#36866;&#24212;&#65292;&#35774;&#32622;&#21518;&#35831;&#33258;&#34892;&#37197;&#32622;&#35774;&#32622;&#20013;&#25163;&#26426;&#36718;&#36716;&#22270;&#29255;&#23610;&#23544;</td></tr>
<tr><td s="1" class="td27" colspan="2">首页轮转下方 AD</td></tr>
<tr class="noborder"><td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[mobile_index_ad_1]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['mobile_index_ad_1']['value'];?></textarea>
</td><td>&#40664;&#35748;&#22270;&#29255;&#24191;&#21578;&#65306;<br/>&#60;&#97;&#32;&#104;&#114;&#101;&#102;&#61;&#34;&#35;&#34;&#62;&#60;&#105;&#109;&#103;&#32;&#115;&#114;&#99;&#61;&#34;&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#97;&#108;&#106;&#98;&#100;&#47;&#105;&#109;&#97;&#103;&#101;&#115;&#47;&#97;&#100;&#118;&#49;&#46;&#106;&#112;&#103;&#34;&#32;&#47;&#62;&#60;&#47;&#97;&#62;<br/>&#35;&#61;&#38142;&#25509;<br/>&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#97;&#108;&#106;&#98;&#100;&#47;&#105;&#109;&#97;&#103;&#101;&#115;&#47;&#97;&#100;&#118;&#49;&#46;&#106;&#112;&#103;&#61;&#22270;&#29255;&#36335;&#24452;</td></tr>

<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#29256;&#39318;&#39029;&#24213;&#37096;&#65;&#68;</td></tr>
<tr class="noborder"><td class="vtop rowform">
<textarea class="tarea" cols="50"  name="settingsnew[mobile_index_ad]"   rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)"><?php echo $settings['mobile_index_ad']['value'];?></textarea>
</td><td>&#25903;&#25345;&#104;&#116;&#109;&#108;</td></tr>

<?php } ?>