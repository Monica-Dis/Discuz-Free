<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('talk');?><?php include template('aljol:head'); include template('aljol:header'); ?><link href="source/plugin/aljol/static/css/aljol/talk.css?v=<?php echo $version;?>" rel="stylesheet" type="text/css">
<style>
    .s_voice{
cursor:pointer;
}
.upload_pic{
margin-top:25px;
display: inline-block;
vertical-align: top;
}
.topBar2{
        position: absolute !important;
    }
    .talk-foot{
        position: absolute !important;
    }
    html, body{overflow: hidden}
</style>
<main class="talk">
<?php if($selfrecordcount>10) { ?>
<div style="text-align: center;margin-top:20px;color:#666666;" class="scroll_text" onclick="loadmore(this, <?php echo $friendid;?>, <?php echo $_G['uid'];?>, <?php echo $loadchatid;?>)">加载更多
</div>
<?php } ?>
<ul id="loadmore"><?php if(is_array($selftalkrecord)) foreach($selftalkrecord as $tmp_key => $tmp_value) { if($tmp_value['uid'] != $_G['uid']) { ?>
<li class="layim-chat-li w" date-id="<?php echo $tmp_value['id'];?>">
<div style="font-size:12px;color:#999999;text-align:center;padding:20px;"><?php echo $tmp_value['datetime'];?></div>
<div class="layim-chat-user" data-uid="<?php echo $tmp_value['uid'];?>">

<?php echo $tmp_value['fidicon'];?>

<cite><?php echo $tmp_value['username'];?></cite>
</div>
<div <?php if($tmp_value['picture'] || $tmp_value['type'] == 1 || $tmp_value['type'] == 5) { ?>class="upload_pic w" <?php } else { ?>class="layim-chat-text w"<?php } ?> <?php if($tmp_value['type'] == 3 && $iswechat) { ?>style="width: <?php echo 40+intval($tmp_value[time]*2/1000);?>px"<?php } ?>>
<?php if($tmp_value['type'] == 1) { ?>
<img src="<?php echo $_G['cache']['plugin']['aljol']['aljhb_img'];?>" width="180"
 <?php if($friendid > 0) { ?>onclick="show_red_packet('<?php echo $tmp_value['id'];?>','aljol','per')"<?php } else { ?>onclick="show_red_packet('<?php echo $tmp_value['id'];?>','aljol','group')"<?php } ?>/>
<?php } elseif($tmp_value['type'] == 3) { if($iswechat) { ?>
<s class="s_voice s_voice_right"  data-id="<?php echo $tmp_value['talk'];?>"></s>
<?php } else { ?>
[语音信息]
<?php } } else { if($tmp_value['talk']) { ?>
<?php echo $tmp_value['talk'];?>
<?php } else { ?>
<img src="<?php echo $tmp_value['picture'];?>" class="jm" onclick="clickjm(this);">
<?php } } ?>
</div>
</li>
<?php } else { ?>
<li class="layim-chat-li layim-chat-mine" date-id="<?php echo $tmp_value['id'];?>">
<div style="font-size:12px;color:#999999;text-align:center;padding:20px;"><?php echo $tmp_value['datetime'];?></div>
<div class="layim-chat-user" data-uid="<?php echo $tmp_value['uid'];?>">
<?php echo $tmp_value['fidicon'];?>
<cite><?php echo $tmp_value['username'];?></cite>
</div>
<div <?php if($tmp_value['picture'] || $tmp_value['type'] == 1 || $tmp_value['type'] == 5) { ?>class="upload_pic"<?php } else { ?>class="layim-chat-text"<?php } ?> <?php if($tmp_value['type'] == 3) { ?>style="width: <?php echo 40+intval($tmp_value[time]*2/1000);?>px"<?php } ?>>
<?php if($tmp_value['type'] == 1) { ?>
<img src="<?php echo $_G['cache']['plugin']['aljol']['aljhb_img'];?>" width="180"
 <?php if($friendid > 0) { ?>onclick="show_red_packet('<?php echo $tmp_value['id'];?>','aljol','per')"<?php } else { ?>onclick="show_red_packet('<?php echo $tmp_value['id'];?>','aljol','group')"<?php } ?>/>
<?php } elseif($tmp_value['type'] == 3) { if($iswechat) { ?>
<s class="s_voice s_voice_left" data-id="<?php echo $tmp_value['talk'];?>"></s>
<?php } else { ?>
[语音信息]
<?php } } else { if($tmp_value['talk']) { ?>
<?php echo $tmp_value['talk'];?>
<?php } else { ?>
<img src="<?php echo $tmp_value['picture'];?>" class="jm" onclick="clickjm(this);">
<?php } } ?>
</div>
</li>
<?php } } if($g) { ?>
<div style="width:100%;background: #ffffff;padding:10px 0px;margin-bottom: 60px">
<div style="float: left;width:20%;margin: 0px 1%"><img src="<?php echo $g['pic1'];?>" style="width:100%;height: 70px;object-fit: cover;" /></div>
<div style="float: right;width:78%">
<?php echo $g['name'];?>
<p style="color:#f42424;font-size: 12px">&#65509;<span style="font-size: 16px;"><?php if($g['collage_price']>0 && $g['commodity_type'] == 2) { ?><?php echo $g['collage_price'];?><?php } else { ?><?php echo $g['price1'];?><?php } if($g['price2']>0) { ?>-<?php echo $g['price2'];?><?php } ?></span></p>
</div>
<div style="width:100%;text-align: center;clear: both;padding-top: 10px;"><a href="javascript:;" id="bgoosid" data-id="<?php echo $g['id'];?>" data-uid="<?php echo $friendid;?>" style="padding:5px 20px;border-radius:10px;border: 1px solid #f42424;color:#f42424;font-size: 14px;">发送宝贝</a></div>
</div>
<?php } ?>
</ul>

</main>


<div class="swiper-container1" style="display: none;">
<div class="closeswiper"><i class="iconfont icon-remove"></i></div>
<div class="swiper-wrapper">

</div>
</div><?php include template('aljol:video_player'); ?><div class="Emain">
<div class="layim-layer" id='emoji'>
<div class="Econt">
<ul class="Eface">
</ul>
</div>
</div>
</div>
<style>
    <?php if($_G['cache']['plugin']['aljol']['is_header']) { ?>
.talk{
        height: -moz-calc(100% - 46px - 90px);
        height: -webkit-calc(100% - 46px - 90px);
        height: calc(100% - 46px - 90px);
    }
    <?php } else { ?>
    .talk{
        height: -moz-calc(100% - 90px);
        height: -webkit-calc(100% - 90px);
        height: calc(100% - 90px);
    }
    <?php } ?>
.ol_null_footer{
height:90px;background:#F3F3F3
}
@supports (bottom: constant(safe-area-inset-bottom)) or (bottom: env(safe-area-inset-bottom)) {
.ol_null_footer{
height: calc(90px + constant(safe-area-inset-bottom));
height: calc(90px + env(safe-area-inset-bottom));
}
.talk-foot{
padding-bottom: constant(safe-area-inset-bottom);
padding-bottom: env(safe-area-inset-bottom);
}
        <?php if($_G['cache']['plugin']['aljol']['is_header']) { ?>
.talk{
            height: calc(100% - 46px - 90px - constant(safe-area-inset-bottom));
            height: calc(100% - 46px - 90px - env(safe-area-inset-bottom));
        }
        <?php } else { ?>
        .talk{
            height: calc(100% - 90px - constant(safe-area-inset-bottom));
            height: calc(100% - 90px - env(safe-area-inset-bottom));
        }
        <?php } ?>
}
</style>
<footer class="talk-foot">
<div class="layim-chat-send">
<input type="text" autocomplete="off" id="saytext" oninput="addtext()" onkeydown="sendKeyDown(<?php echo $friendid;?>)">
<button class="layim-send layui-disabled" onclick="send(<?php echo $friendid;?>,this);">发送</button>
</div>
<div class="layim-chat-tool" >
<?php if(!$_G['cache']['plugin']['aljol']['is_header'] && !$immersed) { ?>
<i class="iconfont icon-fanhui" onclick="R.toback();"></i>
<?php } ?>
<i class="iconfont icon-biaoqing emotion" style="color:#333333;"></i>
<i class="iconfont pic" style="text-align: center;margin: 3px 15px 0px;">
<img src="source/plugin/aljol/static/img/pic.png" width="26"/>
<?php if(IN_MINI != 1) { ?>
<form  method="post" enctype="multipart/form-data" action="" id="picturefile">
            	<input id="picture" type="file" name="picture" onchange="lrz_mobile(<?php echo $friendid;?>,this)">
        	</form>
<?php } ?>
</i>
<?php if($_G['cache']['plugin']['aljoss']['Access_Key'] && $_G['cache']['plugin']['aljol']['is_video']) { ?>
<i class="iconfont " id="selectfiles" style="text-align: center;margin: 3px 15px 0px;">
<img src="source/plugin/aljol/static/img/video.png" width="26"/>
</i>


<script src="source/plugin/aljoss/OSS/js/lib/plupload-2.1.2/js/plupload.full.min.js" type="text/javascript"></script><?php $oss_domain = $_G['cache']['plugin']['aljoss']['cdn_domain'] ? $_G['cache']['plugin']['aljoss']['cdn_domain'] : $_G['cache']['plugin']['aljoss']['domain']?><script type="text/javascript">
            var domain_url = '<?php echo $oss_domain;?>';
            var aljol = 1;
            var friendid = '<?php echo $friendid;?>';
            var video_mb = '<?php echo $_G['cache']['plugin']['aljoss']['video_mb'];?>';
            function sendVideo(v_url) {
                var talk=$('#saytext').val();
                var date={'chat':v_url};
                var url='plugin.php?id=aljol&act=sendvideo&friendid='+friendid;
                $.post(url,date,function(res){
                    layer.closeAll();
                    if(res.code == 4) {
                        alert('\u60a8\u5df2\u88ab\u7981\u6b62\u53d1\u8a00\uff01\uff01\uff01');
                        return false;
                    }
                    if(res.code == 5) {
                        alert('\u60a8\u5df2\u88ab\u7981\u6b62\u8bbf\u95ee\uff01\uff01\uff01');
                        return false;
                    }
                    var talkarea=$('.talk ul');
                    if(res.code == 200) {
                        if(ws_on){
        ws.send(JSON.stringify(res));
        }
                        var datedom = '<li class="layim-chat-li layim-chat-mine">'+
                            '<div class="layim-chat-user" data-uid='+res.uid+'>'+
                            res.head+
                            '<cite>'+res.username+'</cite>'+
                            '</div>'+
                            '<div class="upload_pic" >'+res.chat+'</div>'+
                            '</li>';
                        var talk=$('#saytext').val('');
                        $('.layim-send').addClass('layui-disabled');
                        talkarea.append(datedom);
                        $('.talk').animate({scrollTop:$('.talk')[0].scrollHeight}, 500);
                    }
                }, 'json');
            }
</script>
<script src="source/plugin/aljoss/OSS/js/upload.js" type="text/javascript"></script>
<?php } if($_G['cache']['plugin']['aljhb']) { if($friendid > 0 && $_G['cache']['plugin']['aljol']['is_grhb']) { ?>
<i class="iconfont " style="text-align: center;margin: 3px 15px 0px;" onclick="red_packet_post_dg('<?php echo $hb_friendid;?>','aljol','per')">
<img src="source/plugin/aljol/static/img/red_p.png" width="26"/>
</i>
<?php } elseif($friendid <= 0 && $_G['cache']['plugin']['aljol']['is_aljhb']) { ?>
<i class="iconfont " style="text-align: center;margin: 3px 15px 0px;" onclick="red_packet_post('<?php echo $hb_friendid;?>','aljol','group')">
<img src="source/plugin/aljol/static/img/red_p.png" width="26"/>
</i>
<?php } } if($iswechat) { ?>
        <i class="iconfont " id="startVoice" style="text-align: center;margin: 3px 15px 0px;">
            <img src="source/plugin/aljol/static/img/timg.png" width="26"/>
        </i>
        <div class="content">
            <div class="dialogBox" id="dialogBox">
            </div>
            <div class="voice-remote active" style="z-index:1000;display:none;">
                <span class="cover"></span>
                <span class="icon"></span>
            </div>
        </div>
<?php } ?>

</div>
</footer>

</body>
<script>
    
    

    var morepage = '<?php echo $morepage;?>';
if(ws_on === false){
        setInterval(function(){
            chat(<?php echo $friendid;?>);
        },2000)
    }

    addslide();
    $(document).on('click','#bgoosid',function(){
        var gid = $(this).attr('data-id');
        var friendid = $(this).attr('data-uid');
        if(gid && friendid){
            var date={'gid':gid,'friendid':friendid};
            var url='plugin.php?id=aljol&act=sendgoods';
            $.post(url,date,function(res){
                if(res.code == 4) {
                    alert('您已被禁止发言！！！');
                    return false;
                }
                if(res.code == 5) {
                    alert('您已被禁止访问！！！');
                    return false;
                }
                if(res.code == 6) {
                    alert('商品信息不存在');
                    return false;
                }
                var talkarea=$('.talk ul');
                if(res.code == 200) {
                    var datedom = '<li class="layim-chat-li layim-chat-mine">'+
                        '<div class="layim-chat-user" data-uid='+res.uid+'>'+
                        res.head+
                        '<cite>'+res.username+'</cite>'+
                        '</div>'+
                        '<div class="layim-chat-text" >'+res.talk+'</div>'+
                        '</li>';
                    var talk=$('#saytext').val('');
                    $('.layim-send').addClass('layui-disabled');
                    talkarea.append(datedom);
                    
                    $('.talk').animate({scrollTop:$('.talk')[0].scrollHeight}, 500);
                }
            }, 'json');
}
    });
    var isload = true,page=1;
    <?php if($selfrecordcount>10) { ?>
    $(function(){
        setTimeout(function() {
            loadmore($('.scroll_text'), '<?php echo $friendid;?>', '<?php echo $_G['uid'];?>', '<?php echo $loadchatid;?>');
        }, 100);
    })
    <?php } ?>
</script>
<?php if($_G['cache']['plugin']['aljhb'] && ($_G['cache']['plugin']['aljol']['is_aljhb'] || $_G['cache']['plugin']['aljol']['is_grhb'])) { include template('aljhb:red_packet'); } if($iswechat) { ?>
<script src="https://res.wx.qq.com/open/js/jweixin-1.3.2.js" type="text/javascript"></script>
<script>
wx.config({
debug: <?php echo $_G['cache']['plugin']['aljol']['is_test'];?>,
appId: '<?php echo $signPackage["appId"];?>',
timestamp: '<?php echo $signPackage["timestamp"];?>',
nonceStr: '<?php echo $signPackage["nonceStr"];?>',
signature: '<?php echo $signPackage["signature"];?>',
jsApiList: [
'startRecord',
'stopRecord',
'onVoiceRecordEnd',
'playVoice',
'pauseVoice',
'stopVoice',
'onVoicePlayEnd',
'translateVoice',
'uploadVoice',
'downloadVoice',
        'checkJsApi','chooseImage','previewImage','uploadImage','downloadImage',
]
});

var R = {
    options: {
        spoint: 0,
        tpoint: 0,
        epoint: 0,
        timer: 0,
        iOrder: 0
    },
toback: function () {
        <?php if(strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false) { ?>
            if(document.referrer == ''){
                currentWebview().close();
                return false;
            }else{
                history.back();
                return false;
            }
        <?php } elseif(strpos(strtolower($_SERVER['HTTP_USER_AGENT']),"miniprogram") !== false) { ?>
            if (window.__wxjs_environment === 'miniprogram') {
                if(document.referrer === '' || document.referrer.indexOf("success") != -1){
                    wx.miniProgram.navigateBack({ changed: true });//返回上一页
                }else{
                    window.history.go(-1);
                }
                
                return false;
            }
        <?php } ?>
        document.referrer === '' || document.referrer.indexOf("success") != -1 ?
            window.location.href = 'plugin.php?id=aljol' :
            window.history.go(-1);
        
        return false;
},
    recode: function() {
        R.options.timer = setInterval(function() {
            var time = +new Date() - R.options.spoint;
            if (time >= 60000) {
                $('.voice-remote').hide();
                $('.voice-remote').removeClass('voice-remote_active');
                $('.voice-remote .cover').removeClass('voice-remote_active_cover');
                $('.voice-remote .icon').removeClass('icon_active');
                setTimeout(function() {
                    R.translate(60000);
                }, 100);
                clearInterval(R.options.timer);
            }
        }, 1000);
    },
    translate: function(time) {
        setTimeout(function(){
            wx.stopRecord({
                success: function(res) {
                    localId = res.localId;
                    wx.uploadVoice({
                        localId: localId,
                        isShowProgressTips: 0,
                        success: function (res) {
                            var serverId = res.serverId;
                            localStorage.setItem(serverId, localId);
                            R.sendVoice(<?php echo $friendid;?>, serverId, time);
                        }
                    });
                    $(".voice-remote").addClass("vrPause");
                },
                fail: function(res) {
                    if(res.errMsg == 'stopRecord:tooshort'){
                        setTimeout(function(){
                            wx.stopRecord({
                                success: function (res) {
                                    layer.open({
                                        content: '\u5f55\u97f3\u65f6\u95f4\u592a\u77ed\uff01'
                                        ,skin: 'msg'
                                        ,time: 2
                                    });
                                    return false;
                                }
                            });
}, 800);

                    }
                    //alert(JSON.stringify(res));
                }
            });
        },800);
    },
    playVoice: function() {
        $(document).on('click','.s_voice',function(){
          var serverId = $(this).attr('data-id');
          if(!localStorage.getItem(serverId)){
            wx.downloadVoice({
                serverId: serverId,
                isShowProgressTips: 1,
                success: function (res) {
                    localStorage.setItem(serverId, res.localId);
                    $(this).addClass("bofang");
                    wx.playVoice({
                        localId: res.localId
                    });
                },
                fail: function (res) {
                    alert(JSON.stringify(res));
                    return;
                }
            });

        }else{
            $(this).addClass("bofang");
            wx.playVoice({
                localId: localStorage.getItem(serverId),
            });
        }
        });

    },
    sendVoice: function(id,serverId,time) {
        var serverId = serverId;
        var talk=$('#saytext').val();
        var localId= localStorage.getItem(serverId);
        var date={'chat':serverId,'time':time};
        var url='plugin.php?id=aljol&act=sendvoice&friendid='+id;
        $.post(url,date,function(res){
            if(res.code == 4) {
                alert('您已被禁止发言！！！');
                return false;
            }
            if(res.code == 5) {
                alert('您已被禁止访问！！！');
                return false;
            }
            var talkarea=$('.talk ul');
            if(res.code == 200) {
                if(ws_on){
ws.send(JSON.stringify(res));
}
                var voiceTime = parseInt(40+parseInt(time)*2/1000);
                var datedom = '<li class="layim-chat-li layim-chat-mine">'+
                    '<div class="layim-chat-user" data-uid='+res.uid+'>'+
                    res.head+
                    '<cite>'+res.username+'</cite>'+
                    '</div>'+
                    '<div class="layim-chat-text" style="width:'+voiceTime+'px"><s class="s_voice s_voice_left" data-id="'+serverId+'"></s></div>'+
                    '</li>';
                var talk=$('#saytext').val('');
                $('.layim-send').addClass('layui-disabled');
                talkarea.append(datedom);
                $('.talk').animate({scrollTop:$('.talk')[0].scrollHeight}, 500);
            }
        }, 'json');
},
    init: function() {
        R.playVoice();
        if (window.__wxjs_environment === 'miniprogram') {
            $('a:not(.no_set_url)').attr('href', 'javascript:;');
            //return false;
        }
        wx.ready(function() {
            if(!localStorage.getItem('checkAuth')){
                localStorage.setItem("checkAuth", 1);
                wx.startRecord();
                setTimeout(function(){
                    wx.stopRecord({
                        fail:function(res){
                        },
                        success: function (res) {
                            var localId = res.localId;
                        }
                    });
                },800);
}
            $('.voice-remote,#startVoice').on('touchstart', function(e) {
                $('.voice-remote').show();
                $('.voice-remote').addClass('voice-remote_active');
                $('.voice-remote .cover').addClass('voice-remote_active_cover');
                $('.voice-remote .icon').addClass('icon_active');
                R.options.tpoint = +new Date();
                wx.startRecord({
                    success: function() {
                        $('.voice-remote').addClass('active');
                        R.options.spoint = +new Date();
                        R.recode();
                    },
                    fail: function(res) {
                        //alert(JSON.stringify(res));
                    },
                    cancel: function() {
                        alert('\u60a8\u62d2\u7edd\u4e86\u6388\u6743\u5f55\u97f3');
                    }
                });
            });

            document.oncontextmenu = function(e) {
                e.preventDefault();
            };

            $('.voice-remote,#startVoice').on('touchend', function() {
                $('.voice-remote').hide();
                $('.voice-remote').removeClass('voice-remote_active');
                $('.voice-remote .cover').removeClass('voice-remote_active_cover');
                $('.voice-remote .icon').removeClass('icon_active');
                R.options.epoint = +new Date(); //记录touchend时间点
                $('.voice-remote').removeClass('active');

                var time = +new Date() - R.options.tpoint;
                if (time <= 60000 && time>1000) {
                        R.translate(time);
                }else{
                    layer.open({
                        content: '\u5f55\u97f3\u65f6\u95f4\u592a\u77ed\uff01'
                        ,skin: 'msg'
                        ,time: 2
                    });
                    setTimeout(function(){
                        wx.stopRecord({
                            success: function (res) {

                            }
                        })
}, 800);
clearInterval(R.options.timer);

                }
            });
wx.onVoicePlayEnd({
success: function (res) {
$('.s_voice').each(function(){
if(localStorage.getItem($(this).attr('data-id')) == res.localId){
$(this).removeClass("bofang");
}
});
}
});
            <?php if(IN_MINI == 1) { ?>

$(document).on('touchstart', '.pic', function() {

wx.chooseImage({
success: function (res) {
var localIds = res.localIds; // 返回选定照片的本地ID列表，localId可以作为img标签的src属性显示图片
                        var index = layer.open({
                            content: '\u56fe\u7247\u4e0a\u4f20\u4e2d'
                            ,skin: 'msg'
                            ,time: 2 //2秒后自动关闭
                        });//动态图片不得超过2M
wxUploadImage(localIds);

return false;
}
});
return false;
});


            function wxUploadImage(localIds) {
                var localId = localIds.shift();
                wx.uploadImage({
                    localId: localId, // 需要上传的图片的本地ID，由chooseImage接口获得
                    isShowProgressTips: 0, // 默认为1，显示进度提示
                    success: function (res) {
                        var serverId = res.serverId; // 返回图片的服务器端ID
                        imgpost(localId,serverId);
                        if(localIds.length > 0){
                            wxUploadImage(localIds);
                        }else{
                            layer.close(index)
                            $(this).val('');
                        }
                    }
                });
            }
            function imgpost(localId,serverId) {

                var data={'picpath':serverId,'friendid':'<?php echo $friendid;?>','type':'png'};
                var url='plugin.php?id=aljol&act=upload';
                $.post(url,data,function(res){
                    if(res.code == 4) {
                        alert('\u60a8\u5df2\u88ab\u7981\u6b62\u53d1\u8a00\uff01\uff01\uff01');
                        return false;
                    }
                    if(res.code == 5) {
                        alert('\u60a8\u5df2\u88ab\u7981\u6b62\u8bbf\u95ee\uff01\uff01\uff01');
                        return false;
                    }
                    if(res.code == 200){
                        if(ws_on){
        ws.send(JSON.stringify(res));
        }
                        var talkarea=$('.talk ul');
                        var datedom = '<li class="layim-chat-li layim-chat-mine">'+
                            '<div class="layim-chat-user" data-uid='+res.uid+'>'+
                            res.head+
                            '<cite>'+res.username+'</cite>'+
                            '</div>'+
                            '<div class="upload_pic"><img src="'+res.src+'" class="jm" onclick="clickjm(this);"></div>'+
                            '</li>';
                        talkarea.append(datedom);
                        addslide();
                        $('.talk').animate({scrollTop:$('.talk')[0].scrollHeight}, 500);
                    }
                },'json');
            }
<?php } ?>
        });
    }
}

R.init();


</script>
<?php } else { ?>
<script>
    var R = {
        toback: function () {
            <?php if(strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false) { ?>
                if(document.referrer == ''){
                    currentWebview().close();
                    return false;
                }else{
                    history.back();
                    return false;
                }
            <?php } elseif(strpos(strtolower($_SERVER['HTTP_USER_AGENT']),"miniprogram") !== false) { ?>
                if (window.__wxjs_environment === 'miniprogram') {
                    
                    if(document.referrer === '' || document.referrer.indexOf("success") != -1){
                        wx.miniProgram.navigateBack({ changed: true });//返回上一页
                    }else{
                        window.history.go(-1);
                    }
                    return false;
                }
            <?php } ?>
            document.referrer === '' || document.referrer.indexOf("success") != -1 ?
                window.location.href = 'plugin.php?id=aljol' :
                window.history.go(-1);
            
            return false;
        }
    }
</script>
<?php } ?>
</html>
