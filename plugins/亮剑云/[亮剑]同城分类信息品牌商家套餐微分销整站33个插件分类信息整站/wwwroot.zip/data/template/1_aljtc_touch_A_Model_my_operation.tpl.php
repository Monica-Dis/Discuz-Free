<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>

<script>
    function showsetlist(id,solve,zufangtype,subtype){
        if(solve == 1){
            var tabs = [{
                text: "删除",
                onClick: function() {
                    $.confirm({
                        title: '提示',
                        text: '您确定要删除吗？删除后无法恢复！',
                        onOK: function () {
                            //���ȷ��
                            del(id);
                        },
                        onCancel: function () {
                        }
                    });
                }
            },{
                text: "重新发布",
                onClick: function() {
                    $.confirm({
                        title: '提示',
                        text: '重新发布后可以编辑、刷新、置顶信息等操作',
                        onOK: function () {
                            //���ȷ��
                            getsolve(id);
                        },
                        onCancel: function () {
                        }
                    });
                }
            }];
        }else{
            var tabs = [{
                text: "编辑",
                onClick: function() {
                    window.location.href = 'plugin.php?id=<?php echo $pluginid;?>&act=edit&adminedit=<?php echo $_GET['adminedit'];?>&lid='+id+'&typeid='+zufangtype+'&sid='+subtype;
                }
            },{
                text: "删除",
                onClick: function() {
                    $.confirm({
                        title: '提示',
                        text: '您确定要删除吗？删除后无法恢复！',
                        onOK: function () {
                            //���ȷ��
                            del(id);
                        },
                        onCancel: function () {
                        }
                    });
                }
            },{
                text: "完成信息",
                onClick: function() {
                    $.confirm({
                        title: '提示',
                        text: '确认完成信息，将隐藏电话并标识已完成！',
                        onOK: function () {
                            //���ȷ��
                            getsolve(id);
                        },
                        onCancel: function () {
                        }
                    });
                }
            },{
                text: "刷新信息",
                onClick: function() {
                    updatalist(id);
                }
            },{
                text: "置顶信息",
                onClick: function() {
                    top1(id);
                }
            }
            <?php if($_G['cache']['plugin']['aljhb']) { ?>
                ,{
                    text: "红包",
                    onClick: function() {
                        red_packet_post(id,'<?php echo $pluginid;?>');
                    }
                }
            <?php } ?>
            ];
        }
        $.actions({
            actions: tabs
        });
    }
    function del(id,obj) {
        layer.open({type: 2});
        var url = 'plugin.php?id=<?php echo $pluginid;?>&act=delete&getdata=yes&lid='+id;
        $.post(url,function(res) {
            if(res.code == 200) {
                tips(res.msg,1);
            }else {
                tips(res.msg,0);
            }
        },'json');
    }
    function updatalist(id,obj) {
        layer.open({
            content: '刷新一次需要消耗<?php echo $settings['reflashpay']['value'].$_G['setting']['extcredits'][$settings['reflashextcredit']['value']]['title'];?>'
            ,btn: ['确定', '取消']
            ,yes: function(index){
                layer.open({type: 2});
                var url = 'plugin.php?id=<?php echo $pluginid;?>&act=reflash&getdata=yes&lid='+id;
                $.post(url,function(res) {
                    if(res.code == 200) {
                        tips(res.msg,0);
                    }
                    if(res.code == 300) {
                        tips(res.msg,res.url);
                    }
                    if(res.code == 400) {
                        tips(res.msg,res.url);
                    }
                },'json');
            }
        });

    }
    function top1(id,obj) {
        var red_tab = [];
        <?php if($settings['top_tz']['value']) { ?>
            
            <?php if(is_array($top_tz_arr)) foreach($top_tz_arr as $rv) { ?>                red_tab.push({
                    text: '<?php echo $rv['title'];?>',
                    onClick: function() {
                        $.modal({
                            title: "&#31215;&#20998;&#28040;&#32791;&#25552;&#31034;",
                            text: "<?php echo $rv['title'];?>",
                            buttons: [
                                { text: "&#30830;&#35748;", onClick: function(){
                                    var url = 'plugin.php?id=<?php echo $pluginid;?>&act=top&getdata=yes&lid='+id;
                                    var data = {'days':'<?php echo $rv['day'];?>','price':'<?php echo $rv['num'];?>','formhash':'<?php echo FORMHASH;?>'};
                                    $.post(url,data,function(res) {
                                        if(res.code == 200) {
                                            tips(res.msg,res.url);
                                            $('#inputtext').val('');
                                        }
                                        if(res.code == 300) {
                                            tips(res.msg,res.url);
                                        }
                                        if(res.code == 400) {
                                            tips(res.msg,res.url);
                                        }
                                        if(res.code == 500) {
                                            tips(res.msg,res.url);
                                        }
                                    },'json');
                                }
                                },
                                { text: "&#21462;&#28040;", className: "default", onClick: function(){ console.log(3)} },
                            ]
                        });
                    }
                });
            <?php } ?>
           
        
        red_tab.push({
            text: '&#33258;&#23450;&#20041;&#32622;&#39030;&#65292;<?php echo $settings['toppay']['value'];?><?php echo $_G['setting']['extcredits'][$settings['topextcredit']['value']]['title'];?>/&#22825;',
            onClick: function() {
                zdy_top(id,obj);
            }
        });
        
        $.actions({
            title: "&#35831;&#36873;&#25321;&#32622;&#39030;&#22871;&#39184;",
            actions: red_tab
        });
        <?php } else { ?>
        zdy_top(id,obj);
        <?php } ?>
    }
    function zdy_top(id,obj){
        layer.open({
            title:['置顶一天需要消耗<?php echo $settings['toppay']['value'];?><?php echo $_G['setting']['extcredits'][$settings['topextcredit']['value']]['title'];?>','background-color: <?php if($color) { ?><?php echo $color;?><?php } else { ?>#FF4351<?php } ?>; color:#fff;']
            ,content:'置顶天数：<input type="number" value="7" name="days" style="width: 60px;border:1px solid #f8f8f8;padding-left: 10px;margin-right: 5px;" id="inputtext">&#22825;'
            ,btn: ['确定', '取消']
            ,yes: function(index){
                layer.open({type: 2});
                var days = parseInt($('#inputtext').val());
                if(days) {
                    var url = 'plugin.php?id=<?php echo $pluginid;?>&act=top&getdata=yes&lid='+id;
                    var data = {'days':days,'formhash':'<?php echo FORMHASH;?>'};
                    $.post(url,data,function(res) {
                        if(res.code == 200) {
                            tips(res.msg,res.url);
                            $('#inputtext').val('');
                        }
                        if(res.code == 300) {
                            tips(res.msg,res.url);
                        }
                        if(res.code == 400) {
                            tips(res.msg,res.url);
                        }
                        if(res.code == 500) {
                            tips(res.msg,res.url);
                        }
                    },'json');
                }else {
                    tips('未填写天数',1);
                }
            }
        });
    }
    function getsolve(id,obj) {
        var url = 'plugin.php?id=<?php echo $pluginid;?>&act=solve&getdata=yes&lid='+id;
        layer.open({type: 2});
        $.post(url,function(res) {
            if(res.code == 200) {
                tips(res.msg,res.url);
            }else {
                tips(res.msg,res.url);
            }
        },'json')
    }
    $(document).on('click','.sh_mes',function(){
        var l_id = $(this).data('id');
        var url = 'plugin.php?id=<?php echo $pluginid;?>&act=sh_mes&getdata=yes&lid='+l_id;
        $.showLoading();
        $.post(url,function(res) {
            if(res.code == 200) {
                tips(res.msg,res.url);
            }else {
                tips(res.msg,res.url);
            }
        },'json')
    })
</script>