<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template('aljbd:footercss'); ?><link href="source/plugin/aljbd/css/new_index/20190124/new_index.css?<?php echo VERHASH;?>" rel="stylesheet" type="text/css">
<style type="text/css">

.login-info a.login-success{ border-color:<?php echo $config['d_color'];?>; color:<?php echo $config['d_color'];?>; float:none; width:108px; margin:0 auto;}
.login-info a:hover,.login-info a.register_button{ border-color:<?php echo $config['p_color'];?>; color:<?php echo $config['p_color'];?>;}

.login-info a.login-success:hover{ background-color:<?php echo $config['d_color'];?>; color:#fff;}

</style>
<style id="diy_style" type="text/css"></style>
<div class="visual-item" data-mode="lunbo" data-purebox="banner" data-li="1" data-length="5" ectype="visualItme" style="display: block; position: relative; opacity: 1; left: 0px; top: 0px;" data-diff="0">

    <div class="view">
        <div class="bannerLj home-banner" >
            <?php if($_GET['ljdiy'] == 'yes') { ?>
            <div style="
    background-color: rgba(0,0,0,0.9);
    position: absolute;
    width: 100%;
    height: 100%;
    text-align: center;
    font-size: 50px;
    z-index: 100;
    "><a class="diyDocument" data-id="pcdiy_swiper" href="javascript:;" style="
    color: #fff;
    font-weight: bold;
    display: table-cell;
    vertical-align: middle;
    height: 500px;
    width: 1200px;
    overflow: hidden;
">上传图片轮播图</a></div>
            <?php } ?>
            <div class="bd swiper-container" id="bannerLj">
                <ul class="swiper-wrapper">
                    <?php if(is_array($index_lz_types)) foreach($index_lz_types as $k => $v) { ?>                    <li class="swiper-slide" style="background-image: url(<?php echo $k;?>); background-position: center center; background-repeat: no-repeat;background-size: cover;">
                        <div class="banner-width"><a href="<?php echo $v;?>" target="_blank" style="height:500px;"></a></div>
                    </li>
                    <?php } ?>

                </ul><div class="spec" data-spec=""></div>
            </div>
            <div class="hd "><ul class="swiper-pagination"></ul></div>
            <?php if(!$settings['closeggcard']['value']) { ?>
            <div class="vip-outcon">
                <div class="vip-con">
                    <div class="insertVipEdit" data-mode="insertVipEdit">
                        <div class="userVip-info" ectype="user_info">
                            <div class="avatar">
                                <a href="plugin.php?id=aljbd&amp;act=member"><?php echo avatar($_G['uid'],'middle')?></a>
                            </div>
                            <div class="login-info">
                                <?php if($_G['uid']) { ?>
                                    <span>Hi,&nbsp;<?php echo $_G['username'];?></span>
                                    <?php if(!$settings['is_self_support']['value']) { ?>
                                    <a href="plugin.php?id=aljbd&amp;act=member" class="login-button login-success"><?php echo $config['aljbd'];?></a>
                                    <?php } ?>
                                <?php } else { ?>
                                <span>Hi，欢迎来到<?php echo $_G['cache']['plugin'][$pluginid]['aljbd_plugins'];?>!</span>
                                <a onclick="return showWindow('bdlogin', 'member.php?mod=logging&action=login&infloat=yes', 'get', 1);" href="javascript:;" class="login-button">登录</a>
                                <?php if(!$settings['is_self_support']['value']) { ?><a href="plugin.php?id=aljbd&amp;act=attend" target="_blank" class="register_button"><?php echo $config['attend'];?></a><?php } ?>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="vip-item vip_article_cat">
                            <div class="tit">
                                <a href="javascript:void(0);" class="tab_head_item" >资讯公告</a>

                            </div>
                            <div class="con swiper-container" id="swiperGg">
                                <div class="swiper-wrapper">
                                    <ul class="swiper-slide" style="display: inline-block;text-align: left;font-size: 12px;">
                                        <?php $gi=0?>                                    <?php if(is_array($gg_types)) foreach($gg_types as $k => $v) { ?>                                        <?php if($gi && $gi%3==0) { ?>
                                        </ul>
                                        <ul class=" swiper-slide" style="display: inline-block;text-align: left;font-size: 12px;">
                                        <?php } ?>
                                        <li >
                                            <a target="_blank" href="<?php echo $v;?>" title="<?php echo $k;?>" ><?php echo $k;?></a>
                                        </li>
                                            <?php $gi++?>                                    <?php } ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="vip-item backup_tpl_1">
                            <div class="tit">快捷入口</div>
                            <div class="kj_con">

                                <?php if(is_array($HomePageShortcut_arr)) foreach($HomePageShortcut_arr as $hpskey => $hps) { ?>                                <?php if($hpskey<7) { ?>
                                <?php $itemi = $hpskey+1?>                                <div class="item item_<?php echo $itemi;?>">
                                    <a href="<?php echo $hps['1'];?>" target="_blank">
                                        <i class="iconfont icon-zan-alt"><img src="<?php echo $hps['0'];?>" width="18"/></i>
                                        <span><?php echo $hps['2'];?></span>
                                    </a>
                                </div>
                                <?php } ?>
                                <?php } ?>
                            </div>
                        </div>
                    </div><div class="spec" data-spec=""></div>

                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</div>

<div class="wrap">
    <?php if(!$config['is_res_brand'] && !$settings['is_self_support']['value']) { ?>
    <div class="visual-item w1200"  style="display: block;">
        <div class="view">
            <div class="store-channel" id="h-storeRec_1" >
                <div class="ftit"><h3>推荐商家</h3></div>
                <div class="rec-store-list swiper-container" id="recshopswiper">
                    <div class="swiper-wrapper">
                        <?php if(is_array($recommendlist_1)) foreach($recommendlist_1 as $recommendkey => $recommend) { ?>                        <div class="rec-store-item opacity_img swiper-slide" >
                            <a href="<?php if($config['isrewrite']) { ?>brand_shop_<?php echo $recommend['id'];?>.html<?php } else { ?>plugin.php?id=aljbd&act=view&bid=<?php echo $recommend['id'];?><?php } ?>" target="_blank">
                                <div class="p-img"><img class="img_8s" src="<?php if($recommend['logo']) { ?><?php echo $recommend['logo'];?><?php } else { ?><?php echo $noimg;?><?php } ?>"></div>
                                <div class="info">

                                    <div class="s-title" >
                                        <div class="tit"><?php echo $recommend['name'];?>
                                            <?php if($recommend['label']) { ?>
                                            <span  class="bd-label"><?php echo $recommend['label'];?></span>
                                            <?php } ?>
                                        </div>
                                        <div class="ui-tit"><?php echo $recommend['addr'];?></div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php } ?>
                    </div>
                </div>
                <div class="spec"></div>
            </div>
        </div>
    </div>
    <?php } ?>
    <div class="visual-item w1200 pindao-enter"  style="display: block;">
    <?php echo $config['bad'];?>
    <!--[diy=aljbd_002]--><div id="aljbd_002" class="area"></div><!--[/diy]-->
    </div>
    <?php if($settings['HomePageModuleTitle_1']['value'] || $settings['HomePageModuleContent_1']['value']) { ?>
    <div class="grid_c1 scene_inner clearfix w1200 visual-item" style="position: relative;">
        <?php if($_GET['ljdiy'] == 'yes') { ?>        
            <div style="
    background-color: rgba(0,0,0,0.7);
    position: absolute;
    width: 100%;
    height: 100%;
    text-align: center;
    font-size: 50px;
    z-index: 100;
    "><a href="javascript:;" class="diyDocument" data-id="pcdiy_hot" style="
    color: #fff;
    font-weight: bold;
    display: table-cell;
    vertical-align: middle;
    height: 500px;
    width: 1200px;
    overflow: hidden;
">点击编辑热门活动</a></div>
<?php } ?>
        <div class="ftit"><h3><?php echo $settings['HomePageModuleTitle_1']['value'];?></h3></div>
        <?php if(is_array($HomePageModuleContent_1_arr)) foreach($HomePageModuleContent_1_arr as $hpmc1key => $hpmc1val) { ?>        <?php if($hpmc1key<7) { ?>
        <div class="box scene_item">
            <a class="scene_lk" href="<?php echo $hpmc1val['6'];?>"  target="_blank">
                <div class="scene_cover">
                    <div class="lazyimg lazyimg_loaded scene_cover_img">
                        <img src="<?php echo $hpmc1val['2'];?>" class="lazyimg_img">
                    </div>
                    <div class="scene_mask"></div>
                    <h4 class="scene_tit" clstag="h|keycount|joy|chan#01_a"><?php echo $hpmc1val['0'];?><span class="scene_subtit"><?php echo $hpmc1val['1'];?></span></h4>
                </div>
                <ul class="scene_prodlist">
                    <li class="scene_proditem">
                        <div class="lazyimg lazyimg_loaded scene_proditem_img">
                            <img src="<?php echo $hpmc1val['3'];?>" class="lazyimg_img">
                        </div>
                    </li>
                    <li class="scene_proditem">
                        <div class="lazyimg lazyimg_loaded scene_proditem_img">
                            <img src="<?php echo $hpmc1val['4'];?>" class="lazyimg_img">
                        </div>
                    </li>
                    <li class="scene_proditem">
                        <div class="lazyimg lazyimg_loaded scene_proditem_img">
                            <img src="<?php echo $hpmc1val['5'];?>" class="lazyimg_img">
                        </div>
                    </li>
                </ul>
            </a>
        </div>
        <?php } ?>
        <?php } ?>
        <div class="spec" ></div>
    </div>
    <?php } ?>
    <div class="visual-item w1200 pindao-enter"  style="display: block;">
    <?php echo $config['gad'];?>
    <!--[diy=aljbd_003]--><div id="aljbd_003" class="area"></div><!--[/diy]-->
    </div>
    <?php if($settings['HomePageModuleTitle_2']['value'] || $settings['HomePageModuleContent_2']['value']) { ?>
<div class="visual-item w1200"  style="display: block;position: relative;">
            <?php if($_GET['ljdiy'] == 'yes') { ?>        
            <div style="
    background-color: rgba(0,0,0,0.7);
    position: absolute;
    width: 100%;
    height: 100%;
    text-align: center;
    font-size: 30px;
    z-index: 100;
    "><a class="diyDocument" data-id="pcdiy_rec" href="javascript:;" style="
    color: #fff;
    font-weight: bold;
    display: table-cell;
    vertical-align: middle;
    height: 175px;
    width: 1200px;
    overflow: hidden;
">点击编辑特色推荐</a></div>
<?php } ?>
    <div class="view">
        <div class="master-channel" >

            <div class="ftit"><h3><?php echo $settings['HomePageModuleTitle_2']['value'];?></h3></div>
            <div class="master-con">
                <?php if(is_array($HomePageModuleContent_2_arr)) foreach($HomePageModuleContent_2_arr as $hpmckey => $hpmc) { ?>                <?php if($hpmckey<5) { ?>
                <?php $mci = $hpmckey+1?>                <div class="m-c-item m-c-i-<?php echo $mci;?>" style="background:url(<?php echo $hpmc['2'];?>) center center no-repeat;">
                    <div class="m-c-main">
                        <div class="f-title">
                            <h3><?php echo $hpmc['0'];?></h3>
                            <span><?php echo $hpmc['1'];?></span>
                        </div>
                        <a href="<?php echo $hpmc['6'];?>" class="m-c-btn" target="_blank" style="color:<?php echo $hpmc['5'];?>"><?php echo $hpmc['4'];?></a>
                    </div>
                    <div class="img"><a href="<?php echo $hpmc['6'];?>" target="_blank"><img src="<?php echo $hpmc['3'];?>"></a></div>
                </div>
                <?php } ?>
                <?php } ?>
            </div>
            <div class="spec" ></div></div>
    </div>
</div>
    <?php } ?>
    <div class="visual-item w1200 pindao-enter"  style="display: block;">
    <?php echo $config['cad'];?>
    <!--[diy=aljbd_001]--><div id="aljbd_001" class="area"></div><!--[/diy]-->
    </div>
    <?php if($settings['HomePageModuleTitle_3']['value'] || $settings['HomePageModuleContent_3']['value']) { ?>
    <div class="visual-item w1200"  style="display: block;position: relative;">
 <?php if($_GET['ljdiy'] == 'yes') { ?>        
            <div style="
    background-color: rgba(0,0,0,0.7);
    position: absolute;
    width: 100%;
    height: 100%;
    text-align: center;
    font-size: 50px;
    z-index: 100;
    "><a class="diyDocument" data-id="pcdiy_find" href="javascript:;" style="
    color: #fff;
    font-weight: bold;
    display: table-cell;
    vertical-align: middle;
    height: 500px;
    width: 1200px;
    overflow: hidden;
">点击编辑发现好货</a></div>
<?php } ?>
        <div class="view">
            <div class="pindao-enter clearfix">
                <div class="ftit"><h3><?php echo $settings['HomePageModuleTitle_3']['value'];?></h3></div>
                <ul class="clearfix" >
                    <?php if(is_array($HomePageModuleContent_3_arr)) foreach($HomePageModuleContent_3_arr as $hpmc3key => $hpmc3val) { ?>                    <?php if($hpmc3key<6) { ?>
                    <?php $mc3i = $hpmc3key+1?>                    <li class="item<?php echo $mc3i;?>">
                        <a href="<?php echo $hpmc3val['3'];?>" target="_blank">
                            <span class="line n-line"></span>
                            <p class="name"><?php echo $hpmc3val['0'];?></p>
                            <span class="line w-line"></span>
                            <p class="desc"><?php echo $hpmc3val['1'];?></p>
                            <img src="<?php echo $hpmc3val['2'];?>" alt="">
                        </a>
                    </li>
                    <?php } ?>
                    <?php } ?>
                </ul><div class="spec" data-spec=""></div>
            </div>
        </div>
    </div>
    <?php } ?>
    <div class="visual-item w1200 pindao-enter"  style="display: block;">
    <?php echo $config['fad'];?>
    <!--[diy=aljbd_002]--><div id="aljbd_004" class="area"></div><!--[/diy]-->
    </div>

    <link rel="stylesheet" media="screen,projection,tv" href="source/plugin/<?php echo $pluginid;?>/template/touch/view/css/label.css" /></link>
    <style>
        .c_click_see{width:100%;height:36px;line-height:34px;color:#999;margin:0 0 10px 0;font-size:12px;text-align:center;background:#f8f8f8;cursor:pointer}
    </style>
    <div class=" w1200 visual-item lift-channel" >
        <div class="ftit"><h3>还没逛够</h3></div>
        <style>
            *{margin:0;padding:0}#topNavrem{width:100%;overflow:hidden;font:16px/32px hiragino sans gb,microsoft yahei,simsun;border-bottom: 2px solid <?php echo $_G['cache']['plugin'][$pluginid]['color_daohang'];?>;padding:5px 0 0px 0}#topNavrem .swiper-slide{margin-right: 5px;letter-spacing:2px;width:auto;text-align:center;font-size:14px}#topNavrem .swiper-slide span{transition:all .3s ease;display:block;padding:0px 10px}#topNavrem .active span{color:#ffffff;background:<?php echo $_G['cache']['plugin'][$pluginid]['color_daohang'];?>;}#topNavrem .active background:{padding: 0px 10px;transform:scale(1.1);color:<?php echo $_G['cache']['plugin'][$pluginid]['color_daohang'];?>}
            #topNavrem .swiper-slide{background: #f8f8f8}
            #topNavrem span{cursor:pointer;}
            #topNavrem span:hover{color:#ffffff;background:<?php echo $_G['cache']['plugin'][$pluginid]['color_daohang'];?>;}
        </style>
        <?php if($settings['closeGoodsType']['value'] !=1 && $settings['is_mobile_index_love_type']['value']) { ?>
        <div class="b_index_fixed1">
            <div id="topNavrem" class="swiper-container1234 bordertop" >
                <div class="swiper-wrapper b_index_fixed">
                    <div class="swiper-slide <?php if(!$_GET['order']) { ?>active<?php } ?>" val-data="recommend" ><span>精选</span></div>
                    <?php if(is_array($onetype)) foreach($onetype as $k => $v) { ?>                    <div class="swiper-slide " val-data="<?php echo $v['id'];?>" ><span><?php echo $v['subject'];?></span></div>
                    <?php } ?>
                </div>
            </div>
        </div>
        <?php } ?>
        <div class="list-view" >
            <dl class="c_goods_details" id="dataList" >

            </dl>
            <div id="dataMore" class="more">
                <div class="c_clear"></div>
                <div class="c_click_see" id="loading" style="background: none">
                    <img alt="loading" src="static/image/common/loading.gif" >&#21152;&#36733;&#20013;&#46;&#46;&#46;
                </div>
            </div>
        </div>

    </div>


</div>

<script src="source/plugin/aljbd/js/sj/jquery.lazyload.min.js" type="text/javascript"></script>
<script type="text/javascript">
    new Swiper('#swiperGg', {
        paginationClickable: true,
        direction: 'vertical',
        autoplay: 3000,//��ѡѡ��Զ�����
        scrollbarHide: true,
    });
    var lzSwiper = new Swiper('#bannerLj', {
        pagination : '.swiper-pagination',
        paginationBulletRender: function (swiper, index, className) {
            return '<li class="' + className + ' on">' + (index + 1) + '</li>';
        },
        paginationClickable: true,
        spaceBetween: 30,
        loop : true,
        loopAdditionalSlides:1,
        autoplay: 5000,//��ѡѡ��Զ�����

    });
    <?php if(!$config['is_res_brand'] && count($recommendlist_1)>5) { ?>
    var recShopSwiper = new Swiper('#recshopswiper', {
        loop : true,
        slidesPerView: 5,
        centeredSlides: true,
        spaceBetween: 30,
        loopAdditionalSlides:1,
        autoplay: 5000,//��ѡѡ��Զ�����
    });
    <?php } ?>
    function lazyload(page) {
        console.log(page);
        //����ͼƬ�ӳټ���  ������Ļ100���ؿ�ʼ����ͼƬ
        lj_jq("img.lazy" + page).lazyload({
            effect: "fadeIn",
            placeholder: "<?php echo $loading;?>",
            threshold: 100,
            failure_limit : 20,
            skip_invisible: false
        });

    }
    lj_jq(function() {
        lazyload(0);
    });
</script><?php $ajax_url = 'plugin.php?id='.$pluginid.'&act=mobile_index_goods&mobilediy='.dhtmlspecialchars($_GET['mobilediy']).'&mobiledemomode='.dhtmlspecialchars($_GET['mobiledemomode'])?><?php if($_GET['ljdiy'] == 'yes') { ?>
<link rel="stylesheet" href="source/plugin/aljhtx/static/layui/css/layui.css">
<script src="source/plugin/aljhtx/static/js/layer/layer.js" type="text/javascript"></script>
<script src="source/plugin/aljhtx/static/layui/layui.js" type="text/javascript"></script>
<?php } ?>
<script type="text/javascript">
    var type='addtime';
    <?php if($settings['is_mobile_index_love_type']['value'] && !$config['is_mobile_index_love']) { ?>
    var typeid='recommend';
    <?php } else { ?>
    var typeid='';
    <?php } ?>
    var page=1;
    var max=2;
    var isload = true;
    function imgwidth(){
        <?php if($_G['cache']['plugin']['aljbd']['is_mobile_goods_size']) { ?>
        h = lj_jq(".c_goods_size").width()-22;
        lj_jq('.c_img').css({'height':h+'px','width':h+'px','margin':'0 auto','display':'block'});

        <?php } ?>
    }
    function scroll_swiper(){
        var swiperLabel = new Swiper('.swiperLabel', {
            scrollbarHide: true,
            slidesPerView: 'auto',
            centeredSlides: false,
            spaceBetween: 10,
            grabCursor: true
        });
    }
    function xxx(){
        lj_jq(window).scroll(function(){

            if(isload){
                // �жϴ��ڵĹ������Ƿ�ӽ�ҳ��ײ�
                if( lj_jq(document).scrollTop() + lj_jq(window).height() >= lj_jq(document).height() - 10 ) {
                    if(lj_jq('#max-page').val()){
                        max=lj_jq('#max-page').val();
                    }

                    page++;
                    isload = false;
                    console.log('xxxx'+page);
                    if(page<=max){

                        ajaxgetdata();
                    }else{
                        lj_jq("#dataMore").hide();
                    }
                    // �ж���һҳ�����Ƿ�Ϊ��
                }
            }
        });
    }
    function ajaxgetdata(swiper) {
        lj_jq("#dataMore").show();
        lj_jq.post('<?php echo $ajax_url;?>',{"order":type,'page':page,'typeid':typeid},function(data){
            if(data==0){
                //console.log(data);
                lj_jq("#dataMore").hide();
                if(typeof swiper !== 'undefined'){
                    lj_jq("#dataList").html('<div class="c_click_see" id="more" style="float: left;">\u6ca1\u6709\u66f4\u591a\u6570\u636e</div>');
                }else{
                    lj_jq("#dataList").append('<div class="c_click_see" id="more" style="float: left;">\u6ca1\u6709\u66f4\u591a\u6570\u636e</div>');
                }

                return false;
            }else{
                if(typeof swiper !== 'undefined'){
                    lj_jq("#dataList").html(data);
                }else{
                    lj_jq("#dataList").append(data);
                }
                isload = true;
            }
            lj_jq("#dataMore").hide();
            console.log('ajaxgetdata'+page);
            lazyload(page);
            scroll_swiper();
            imgwidth();
            xxx();
        });
    }
    lj_jq(function() {
        ajaxgetdata();
    });

    var mySwiper = new Swiper('#topNavrem', {
        freeMode: true,
        freeModeMomentumRatio: 0.5,
        slidesPerView: 'auto',

    });

    swiperWidth = mySwiper.container[0].clientWidth
    maxTranslate = mySwiper.maxTranslate();
    maxWidth = -maxTranslate + swiperWidth / 2

    lj_jq("#topNavrem").on('touchstart', function(e) {
        e.preventDefault()
    })

    mySwiper.on('tap', function(swiper, e) {

        slide = swiper.slides[swiper.clickedIndex]
        slideLeft = slide.offsetLeft
        slideWidth = slide.clientWidth
        slideCenter = slideLeft + slideWidth / 2
        // !aljsq_htm_17!

        mySwiper.setWrapperTransition(300)

        if (slideCenter < swiperWidth / 2) {

            mySwiper.setWrapperTranslate(0)

        } else if (slideCenter > maxWidth) {

            mySwiper.setWrapperTranslate(maxTranslate)

        } else {

            nowTlanslate = slideCenter - swiperWidth / 2

            mySwiper.setWrapperTranslate(-nowTlanslate)

        }

        lj_jq("#topNavrem .active").removeClass('active')

        lj_jq("#topNavrem .swiper-slide").eq(swiper.clickedIndex).addClass('active')
        typeid=lj_jq("#topNavrem .active").attr('val-data');
        //console.log(typeid);
        page=1;
        isload = false;
        //jq("#dataList").html('');
        console.log('topNavrem'+page);
        ajaxgetdata(1);

    })
</script>