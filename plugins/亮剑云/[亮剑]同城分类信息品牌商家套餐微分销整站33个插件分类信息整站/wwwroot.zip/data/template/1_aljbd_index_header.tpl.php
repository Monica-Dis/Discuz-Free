<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('index_header');?>
<?php if($_G['cache']['plugin'][$pluginid]['is_daohang']) { ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET;?>" />
<?php if($_G['config']['output']['iecompatible']) { ?><meta http-equiv="X-UA-Compatible" content="IE=EmulateIE<?php echo $_G['config']['output']['iecompatible'];?>" /><?php } ?>
<title><?php if(!empty($navtitle)) { ?><?php echo $navtitle;?><?php } ?></title>
<?php echo $_G['setting']['seohead'];?>

<meta name="keywords" content="<?php if(!empty($metakeywords)) { echo dhtmlspecialchars($metakeywords); } ?>" />
<meta name="description" content="<?php if(!empty($metadescription)) { echo dhtmlspecialchars($metadescription); ?> <?php } if(empty($nobbname)) { ?>,<?php echo $_G['setting']['bbname'];?><?php } ?>" />
<meta name="generator" content="Discuz! <?php echo $_G['setting']['version'];?>" />
<meta name="author" content="Discuz! Team and Comsenz UI Team" />
<meta name="copyright" content="2001-2017 Comsenz Inc." />
<meta name="MSSmartTagsPreventParsing" content="True" />
<meta http-equiv="MSThemeCompatible" content="Yes" />
<base href="<?php echo $_G['siteurl'];?>" /><link rel="stylesheet" type="text/css" href="data/cache/style_1_common.css?<?php echo VERHASH;?>" /><?php if($_G['uid'] && isset($_G['cookie']['extstyle']) && strpos($_G['cookie']['extstyle'], TPLDIR) !== false) { ?><link rel="stylesheet" id="css_extstyle" type="text/css" href="<?php echo $_G['cookie']['extstyle'];?>/style.css" /><?php } elseif($_G['style']['defaultextstyle']) { ?><link rel="stylesheet" id="css_extstyle" type="text/css" href="<?php echo $_G['style']['defaultextstyle'];?>/style.css" /><?php } ?><script type="text/javascript">var STYLEID = '<?php echo STYLEID;?>', STATICURL = '<?php echo STATICURL;?>', IMGDIR = '<?php echo IMGDIR;?>', VERHASH = '<?php echo VERHASH;?>', charset = '<?php echo CHARSET;?>', discuz_uid = '<?php echo $_G['uid'];?>', cookiepre = '<?php echo $_G['config']['cookie']['cookiepre'];?>', cookiedomain = '<?php echo $_G['config']['cookie']['cookiedomain'];?>', cookiepath = '<?php echo $_G['config']['cookie']['cookiepath'];?>', showusercard = '<?php echo $_G['setting']['showusercard'];?>', attackevasive = '<?php echo $_G['config']['security']['attackevasive'];?>', disallowfloat = '<?php echo $_G['setting']['disallowfloat'];?>', creditnotice = '<?php if($_G['setting']['creditnotice']) { ?><?php echo $_G['setting']['creditnames'];?><?php } ?>', defaultstyle = '<?php echo $_G['style']['defaultextstyle'];?>', REPORTURL = '<?php echo $_G['currenturl_encode'];?>', SITEURL = '<?php echo $_G['siteurl'];?>', JSPATH = '<?php echo $_G['setting']['jspath'];?>', CSSPATH = '<?php echo $_G['setting']['csspath'];?>', DYNAMICURL = '<?php echo $_G['dynamicurl'];?>';</script>
<script src="<?php echo $_G['setting']['jspath'];?>common.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<?php if(empty($_GET['diy'])) { $_GET['diy'] = '';?><?php } if(!isset($topic)) { $topic = array();?><?php } if($_GET['id'] == 'aljbd' || $_GET['id'] == 'aljbd:so') { $config = $_G['cache']['plugin']['aljbd'];?><?php } ?>
<script src="source/plugin/aljbd/js/index_new/jquery1.9.1.js" type="text/javascript"></script>
<script type="text/javascript">
var lj_jq=jQuery.noConflict();
</script>
<link href="source/plugin/aljbd/css/new_index/header.css" rel="stylesheet" type="text/css">
<link href="source/plugin/aljbd/css/new_index/reset.css" rel="stylesheet">
<style id="diy_style" type="text/css"></style>
<?php if($_G['basescript'] != 'portal' && $_GET['diy'] == 'yes' && check_diy_perm($topic)) { ?>
<script src="<?php echo $_G['setting']['jspath'];?>portal.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<?php } if($_GET['diy'] == 'yes' && check_diy_perm($topic)) { ?>
<link rel="stylesheet" type="text/css" id="diy_common" href="data/cache/style_<?php echo STYLEID;?>_css_diy.css?<?php echo VERHASH;?>" />
<?php } ?>
 <?php if($_GET['diy'] == 'yes' && check_diy_perm($topic)) { include template('common/header_diy'); } ?>
<div id="append_parent"></div>
<div id="ajaxwaitid"></div><?php include template('aljbd:common/common_header_css'); ?><style>
.layout {
width: 1200px;
margin: 0 auto;
}
</style>

<!--����-->
<div id="page">
  <div id="topNav" class="warp-all">

        <dl class="user-entry">
<dt>您好<?php echo $_G['username'];?>，欢迎来到<?php echo $_G['cache']['plugin'][$pluginid]['aljbd_plugins'];?></dt>

</dl>
        <ul class="quick-menu">
<li class="user-center">
<div class="menu"><a class="menu-hd" href="<?php if($_G['cache']['plugin']['aljht']['on']) { ?>plugin.php?id=aljht&act=user&op=orderlist&mod=my&ord=ge<?php } else { ?>plugin.php?id=aljbd&act=member<?php } ?>" target="_top" title="会员中心" >会员中心<i></i></a>
<div class="menu-bd">
<ul>
<li><a href="<?php if($_G['cache']['plugin']['aljht']['on']) { ?>plugin.php?id=aljht&act=user&op=orderlist&mod=my&ord=ge<?php } else { ?>plugin.php?id=aljbd&act=orderlist<?php } ?>" target="_top" title="订单管理" >订单管理</a></li>
<?php if($_G['cache']['plugin']['aljsyy']['is_yy']) { ?>
<li><a href="plugin.php?id=aljht&amp;act=user&amp;op=appointment_list&amp;state=2&amp;mod=my" target="_top" title="预约管理" >预约管理</a></li>
<?php } if($cparray['aljgz']) { ?>
<li><a href="plugin.php?id=aljht&amp;act=user&amp;op=collection&amp;mod=my" target="_top" title="我的收藏" >我的收藏</a></li>
<?php } if($cparray['aljgwc']) { ?>
<li><a href="plugin.php?id=aljht&amp;act=user&amp;op=addresslist&amp;mod=my" target="_top" title="收货地址" >收货地址</a></li>
<?php } ?>
</ul>
</div>
</div>
</li>
<?php if(!$settings['is_self_support']['value']) { ?>
  <li class="user-center">
<div class="menu"><a class="menu-hd" href="<?php if($_G['cache']['plugin']['aljht']['on']) { ?>plugin.php?id=aljht&act=admin&op=brand&mod=my<?php } else { ?>plugin.php?id=aljbd&act=member<?php } ?>" target="_top" title="卖家中心" >卖家中心<i></i></a>
  <div class="menu-bd">
<ul>

<li><a href="plugin.php?id=aljbd&amp;act=attend" target="_blank" class="register_button"><?php echo $_G['cache']['plugin'][$pluginid]['attend'];?></a></li>

<?php if(!$settings['is_self_support']['value']) { ?>
  <li><a href="<?php if($_G['cache']['plugin']['aljht']['on']) { ?>plugin.php?id=aljht&act=admin&op=brand&mod=my<?php } else { ?>plugin.php?id=aljbd&act=member<?php } ?>" target="_top" title="店铺管理" >店铺管理</a></li>
<?php } if(!$settings['close_goods']['value']) { ?>
<li><a href="<?php if($_G['cache']['plugin']['aljht']['on']) { ?>plugin.php?id=aljht&act=admin&op=goods&mod=my<?php } else { ?>plugin.php?id=aljbd&act=goodslist<?php } ?>" target="_top" title="商品" >商品管理</a></li>
<?php } ?>
  <li><a href="<?php if($_G['cache']['plugin']['aljht']['on']) { ?>plugin.php?id=aljht&act=admin&op=orderlist&mod=my&ord=dianpu<?php } else { ?>plugin.php?id=aljbd&act=orderlist<?php } ?>" target="_top" title="订单管理" >订单管理</a></li>

<?php if($_G['cache']['plugin']['aljsyy']['is_yy']) { ?>
<li><a href="plugin.php?id=aljht&amp;act=admin&amp;op=appointment_list&amp;mod=my" target="_top" title="我的收藏" >预约管理</a></li>
<?php } ?>

</ul>
  </div>
</div>
  </li>
<?php } if(!$settings['is_self_support']['value'] || !$settings['close_goods']['value'] || !$settings['close_notice']['value'] || !$settings['close_consume']['value'] || !$settings['close_map']['value']) { ?>
<!-- �ղؼ� -->
  <li class="favorite" <?php if($_G['groupid'] != 1) { ?>style="background: none"<?php } ?>>
<div class="menu"><a class="menu-hd" href="plugin.php?id=aljbd" title="<?php echo $_G['cache']['plugin'][$pluginid]['aljbd_plugins'];?>" target="_top" >快速导航<i></i></a>
  <div class="menu-bd">
<ul>
<?php if(!$settings['is_self_support']['value']) { ?>
<li><a href="<?php if($_G['cache']['plugin'][$pluginid]['isrewrite']) { ?>brand.html<?php } else { ?>plugin.php?id=aljbd&act=dianpu<?php } ?>" target="_top" title="商家" >商家</a></li>
<?php } if(!$settings['close_goods']['value']) { ?>
<li><a href="<?php if($_G['cache']['plugin'][$pluginid]['isrewrite']) { ?>goods.html<?php } else { ?>plugin.php?id=aljbd&act=goods<?php } ?>" target="_top" title="商品" >商品</a></li>
<?php } if(!$settings['close_notice']['value']) { ?>
<li><a href="<?php if($_G['cache']['plugin'][$pluginid]['isrewrite']) { ?>notice.html<?php } else { ?>plugin.php?id=aljbd&act=nlist<?php } ?>" target="_top" title="活动" >活动</a></li>
<?php } if(!$settings['close_consume']['value']) { ?>
<li><a href="<?php if($_G['cache']['plugin'][$pluginid]['isrewrite']) { ?>consume.html<?php } else { ?>plugin.php?id=aljbd&act=clist<?php } ?>" target="_top" title="优惠券" >优惠券</a></li>
<?php } if(!$settings['close_map']['value']) { ?>
<li><a href="<?php if($_G['cache']['plugin'][$pluginid]['isrewrite']) { ?>map.html<?php } else { ?>plugin.php?id=aljbd:so<?php } ?>" target="_top" title="地图搜店">地图搜店</a></li>
<?php } ?>
</ul>
  </div>
</div>
  </li>
<?php } if($_G['groupid'] == 1) { ?>
<li style="background: none"><a style="color:red;" target="_blank" href="plugin.php?id=aljhtx&amp;c=aljbd&amp;a=order&amp;type=5">管理员后台</a></li>
<?php } if($_G['uid']) { ?>
<style>
.quick-menu img {
width:20px;
height:20px;
}
</style>
 <li style="background: none"><a style="padding: 2px 1px 0;" href="plugin.php?id=aljbd&amp;act=member"><?php echo avatar($_G['uid'],'small')?>&nbsp;&nbsp;<?php echo $_G['username'];?></a></li>
 <li style="background: none"><a  href="javascript:;" onclick="logout ()">[退出]</a></li>
 <?php } else { ?>
 <li style="background: none"><a style="padding: 2px 1px 0;" onclick="return showWindow('bdlogin', 'member.php?mod=logging&action=login&infloat=yes&referer=plugin.php?id=aljbd', 'get', 1);" href="javascript:;">[登录]</a></li>
 <li style="background: none"><a href="member.php?mod=<?php echo $_G['setting']['regname'];?>&amp;referer=plugin.php?id=aljbd">[注册]</a></li>
 <?php } if(check_diy_perm($topic)) { ?><?php
$diynav = <<<EOF

<li style="background: url('') no-repeat scroll 100% -26px;"><a style="background: #f42424;border: 1px solid #f42424;color:#ffffff;padding: 0px 10px;" title="打开 DIY 面板" href="javascript:saveUserdata('diy_advance_mode', '1');openDiy();" >DIY</a></li>

EOF;
?>
<?php } if(CURMODULE == 'topic' && $topic && empty($topic['useheader']) && check_diy_perm($topic)) { ?>
<?php echo $diynav;?>
<?php } if(check_diy_perm($topic)) { ?>
<?php echo $diynav;?>
<?php } ?>
          </ul>
<script>
            function logout (){
                lj_jq.post('plugin.php?id=aljbd&act=logout&formhash=<?php echo FORMHASH;?>',function(res){
                    if(res == 1){
                        showDialog('&#36864;&#20986;&#25104;&#21151;','right','',function(){
                            location.href = 'plugin.php?id=aljbd';
                        });
                    }else{
                        showDialog('&#36864;&#20986;&#22833;&#36133;','','');
                    }
                })
            }
</script>
  </div>


</div>



    <script src="source/plugin/aljbd/js/index_new/main.js" type="text/javascript"></script>
    <script src="source/plugin/aljbd/js/index_new/autocomplete.js" type="text/javascript" type="text/javascript"></script>
    <style type="text/css">
        .liss1
        {
            padding: 5px 10px;
        }
        .liss2
        {
            background: #efefef;
            color: #c00;
        }

    </style>
    <script type="text/javascript">
        lj_jq(function () {
            //�Զ����� panbb
        /*    lj_jq("#txtKeyWords").autocomplete({
                zindex: 82282828282,
                "httpUrl": "/Handler/seaechKeyWord.ashx",
                "keyupFun": function () { }
            });*/

            //�򿪴���
            lj_jq(".openwin").click(function () {

                return false;
            });
        });
        function openwin(showdom) {

            if (lj_jq(showdom).is(":hidden")) {
                //ִ����ʾ
                lj_jq(showdom).show();
            } else {
                //ִ������
                lj_jq(showdom).hide();
            }
            if (showdom == "#ajhskd1") {
                //ִ������
                lj_jq("#ajhskd2").hide();
            } else {
                //ִ������
                lj_jq("#ajhskd1").hide();
            }
            return false;
        }
    </script>


<script type="text/javascript">
    function stripsc(s) {
        var pattern = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>/?~��@#������&*������|{}��������������'��������]")
        var rs = "";
        for (var i = 0; i < s.length; i++) {
            rs = rs + s.substr(i, 1).replace(pattern, '').replace("-", "");
        }
        return rs;
    }
lj_jq(document).ready(function(){
lj_jq("#scrolltop").css('display','none');
});
</script>
<!--ͷ��-->
<div class=" header" style="margin-top:0px;background: #ffffff">
    <div class="layout logomain">
<style type="text/css">
.logo_lj {
  display: inline;
  float: left;
  margin: 10px;
  height: 80px;
  width: 220px;
}
.logo_lj a {
  display:table-cell;
  vertical-align:middle;
  height: 80px;
  width: 220px;
  overflow: hidden;
}
.logo_lj img {max-height:80px;}
</style><?php $record = C::t('#aljbd#aljbd_setting')->fetch('logo');?>        <div class="logo_lj">
        <?php if($_GET['ljdiy'] == 'yes') { ?>
        <div style="
    background-color: rgba(0,0,0,0.7);
    position: absolute;
    height: 100%;
    text-align: center;
    font-size: 22px;
    "><a class="diyDocument" data-id="pcdiy_logo" href="javascript:;" style="
    color: #ffffff;
    font-weight: bold;
    height:100px;
">点击上传LOGO</a></div>
<?php } ?>
            <a  href="<?php if($_G['cache']['plugin'][$pluginid]['index_url']) { ?><?php echo $_G['cache']['plugin'][$pluginid]['index_url'];?><?php } else { ?>./<?php } ?>" title="">
<?php if($record['value']) { ?><img border="0" alt="<?php echo $_G['cache']['plugin'][$pluginid]['aljbd_plugins'];?>" src="<?php echo $record['value'];?>"><?php } else { if($_G['cache']['plugin'][$pluginid]['logo']) { ?><img border="0" alt="<?php echo $_G['cache']['plugin'][$pluginid]['aljbd_plugins'];?>" src="<?php echo $_G['cache']['plugin'][$pluginid]['logo'];?>"><?php } else { ?><img src="source/plugin/aljbd/images/header/aljbd_logo.png" /><?php } } ?>
            </a>
        </div>

        <div class="search">
            <div class="search-item searchhov">
                <h1>
                    <span id="typevalue">
<?php if($_G['cache']['plugin'][$pluginid]['p_search_def']) { if($_G['cache']['plugin'][$pluginid]['p_search_def'] == 1) { ?>
商品
<?php } elseif($_G['cache']['plugin'][$pluginid]['p_search_def'] == 2) { ?>
活动
<?php } elseif($_G['cache']['plugin'][$pluginid]['p_search_def'] == 3) { ?>
优惠券
<?php } } else { ?>
商家
<?php } ?></span><span class="W_arrow"><em>&#9670;</em></span></h1>
                <ul class="search-list">
                	<li><a href="javascript:;">商家</a></li>
                    <li><a href="javascript:;">商品</a></li>
                    <li><a href="javascript:;">活动</a></li>
                    <li><a href="javascript:;">优惠券</a></li>

                </ul>
            </div>
<style type="text/css">
.search-item {
width: 78px;
}
.search-item h1 .W_arrow {
  left: 62px;
}
</style>
            <div class="search-form">
                <div id="wraptxtKeyWords" style="position:relative;color:#000;z-index:82282828282"><div style="display:none;background:#fff;border:2px solid #999;border-top:none;width:268px;position:absolute; top:40px; left:-12px;" id="tiptxtKeyWords"><ul></ul><div></div></div>
                <input type="text" class="input-txt" value="<?php echo $_GET['kw'];?>" id="txtKeyWords" onkeypress="EnterPress(event)" onkeydown="EnterPress()" placeholder="<?php if($_G['cache']['plugin'][$pluginid]['p_search_def']) { ?><?php echo $_G['cache']['plugin'][$pluginid]['search'];?><?php } else { ?>请输入商家名或地址关键词...<?php } ?>" autocomplete="off" style="height: 20px; padding: 0px;"></div>
                <input class="input-ss" type="button" value="搜索" onclick="seachfun();">
                <script type="text/javascript">
                    function EnterPress(e){ //���� event
                        var e = e || window.event;
                        if(e.keyCode == 13){
                            seachfun();
                        }
                    }
lj_jq(".search-list li a").click(function () {
  lj_jq("#typevalue").html(lj_jq(this).html());
  if(lj_jq(this).html()=='商家'){
lj_jq("#txtKeyWords").attr('placeholder','请输入商家名或地址关键词...');
  }else{
lj_jq("#txtKeyWords").attr('placeholder','<?php echo $_G['cache']['plugin'][$pluginid]['search'];?>');
  }

});
                    function seachfun() {
                        var typevalue = lj_jq.trim(lj_jq("#typevalue").html());
                        var keyw = lj_jq("#txtKeyWords").val();
                        keyw = stripsc(keyw);
                        var uuuu = '';

                        switch (typevalue) {
                            case "商家":
                                uuuu = 'plugin.php?id=aljbd&act=dianpu&kw=' + keyw;
                                break;
                            case "商品":
                                uuuu = 'plugin.php?id=aljbd&act=goods&kw=' + keyw;
                                break;
                            case "活动":
                                uuuu = 'plugin.php?id=aljbd&act=nlist&kw=' + keyw;
                                break;
                            case "优惠券":
                                uuuu = 'plugin.php?id=aljbd&act=clist&kw=' + keyw;
                                break;

                        }
                        //��ת

                        window.location.href = encodeURI(uuuu);
                    }
                </script>
            </div>

        </div>
<?php if($_G['cache']['plugin']['aljgwc'][$pluginid] || $_G['cache']['plugin']['aljbdx']['is_aljqb']) { if($_G['cache']['plugin']['aljbdx']['is_aljqb'] && file_exists('source/plugin/aljbdx/template/aljbd_index_header_cart.htm')) { include template('aljbdx:aljbd_index_header_cart'); } else { include template('aljgwc:aljbd_index_header_cart'); } } ?>
    </div>
</div>

<div class="navLj dsc-zoom" ectype="dscNav">
<div class="w w1200">
<?php if($settings['displaynavs']['value']) { ?>
<div class="categorys ">
<div class="categorys-type">
<?php if($settings['displaygoodsnav']['value']) { ?>
<a href="plugin.php?id=aljbd&amp;act=goods" target="_blank">全部商品分类</a>
<?php } else { ?>
<a href="plugin.php?id=aljbd&amp;act=dianpu" target="_blank">全部商家分类</a>
<?php } ?>
</div>
<div class="categorys-tab-content" <?php if(!$_GET['act'] && !$nosearch && ($_GET['id'] == 'aljbd' || $_GET['id'] == 'aljbd:aljbd' || !$_GET['id'])) { ?>style="display:block"<?php } else { ?>style="display:none"<?php } ?>>

<div class="categorys-items" id="cata-nav" ><?php if(is_array($alltype)) foreach($alltype as $tttk => $ttt) { if($tttk<=7) { ?>
<div class="categorys-item" ectype="cateItem" >
<div class="item item-content">
<?php if($ttt['logo']) { ?>
<div class="icon-other"><img src="<?php echo $ttt['logo'];?>" ></div>
<?php } ?>
<div class="categorys-title">
<strong>
<a href="<?php if($ttt['type_url']) { ?><?php echo $ttt['type_url'];?><?php } else { if($settings['displaygoodsnav']['value']) { ?>plugin.php?id=aljbd&act=goods&type=<?php echo $ttt['id'];?><?php } else { ?>plugin.php?id=aljbd&act=dianpu&type=<?php echo $ttt['id'];?><?php } } ?>" target="_blank"><?php echo $ttt['subject'];?></a>
</strong>
<span><?php $ttk = 0;?><?php if($settings['displaygoodsnav']['value']) { if(is_array(C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($ttt['id']))) foreach(C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($ttt['id']) as $ttv) { if($ttk <2) { ?>
<a href="<?php if($ttv['type_url']) { ?><?php echo $ttv['type_url'];?><?php } else { ?>plugin.php?id=aljbd&act=goods&type=<?php echo $ttt['id'];?>&subtype=<?php echo $ttv['id'];?><?php } ?>" target="_blank"><?php echo $ttv['subject'];?></a>
<?php } $ttk++;?><?php } } else { if(is_array(C::t('#aljbd#aljbd_type')->fetch_all_by_upid($ttt['id']))) foreach(C::t('#aljbd#aljbd_type')->fetch_all_by_upid($ttt['id']) as $ttv) { if($ttk <2) { ?>
<a href="<?php if($ttv['type_url']) { ?><?php echo $ttv['type_url'];?><?php } else { ?>plugin.php?id=aljbd&act=dianpu&type=<?php echo $ttt['id'];?>&subtype=<?php echo $ttv['id'];?><?php } ?>" target="_blank"><?php echo $ttv['subject'];?></a>
<?php } $ttk++;?><?php } } ?>
                                    </span>
</div>
</div>
<div class="categorys-items-layer" ectype="cateLayer" style="display: none;">
<div class="cate-layer-con clearfix" ectype="cateLayerCon_858"><div class="cate-layer-left"><?php $brand_ids = explode(',',str_replace('��',',',$ttt['brand_id']));
$ppq=C::t('#aljbd#aljbd')->fetch_all($brand_ids);
$type_ad = explode ("\n", str_replace ("\r", "", $ttt ['type_ad']));
foreach($type_ad as $key=>$value){
$arr=explode('|',$value);
$type_ad_types[]=$arr;
}
$pclabel = explode ("\n", str_replace ("\r", "", $ttt ['pclabel']));
foreach($pclabel as $key=>$value){
$arr=explode('|',$value);
$type_pclabel[$arr[0]]=$arr[1];
}?><?php if($ttt ['pclabel']) { ?>
<div class="cate_channel"><?php if(is_array($type_pclabel)) foreach($type_pclabel as $pk => $pv) { ?><a href="<?php echo $pv;?>" target="_blank"><?php echo $pk;?></a>
<?php } ?>
</div>
<?php } ?>
<div class="cate_detail">



<?php if($settings['displaygoodsnav']['value']) { if(is_array(C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($ttt['id']))) foreach(C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($ttt['id']) as $tt) { ?><dl class="dl_fore1">
<dt><a href="<?php if($tt['type_url']) { ?><?php echo $tt['type_url'];?><?php } else { ?>plugin.php?id=aljbd&act=goods&type=<?php echo $ttt['id'];?>&subtype=<?php echo $tt['id'];?><?php } ?>" style="cursor:pointer;"><?php echo $tt['subject'];?></a></dt>
<dd><?php if(is_array(C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($tt['id']))) foreach(C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($tt['id']) as $tttt) { ?><a class="active" href="<?php if($tttt['type_url']) { ?><?php echo $tttt['type_url'];?><?php } else { ?>plugin.php?id=aljbd&act=goods&type=<?php echo $ttt['id'];?>&subtype=<?php echo $tt['id'];?>&subtype3=<?php echo $tttt['id'];?><?php } ?>"><?php echo $tttt['subject'];?></a>
<?php } ?>
</dd>
</dl>

<?php } } else { if(is_array(C::t('#aljbd#aljbd_type')->fetch_all_by_upid($ttt['id']))) foreach(C::t('#aljbd#aljbd_type')->fetch_all_by_upid($ttt['id']) as $tt) { ?><dl class="dl_fore1">
<dt><a href="<?php if($tt['type_url']) { ?><?php echo $tt['type_url'];?><?php } else { ?>plugin.php?id=aljbd&act=dianpu&type=<?php echo $ttt['id'];?>&subtype=<?php echo $tt['id'];?><?php } ?>" style="cursor:pointer;"><?php echo $tt['subject'];?></a></dt>
<dd><?php if(is_array(C::t('#aljbd#aljbd_type')->fetch_all_by_upid($tt['id']))) foreach(C::t('#aljbd#aljbd_type')->fetch_all_by_upid($tt['id']) as $tttt) { ?><a class="active" href="<?php if($tttt['type_url']) { ?><?php echo $tttt['type_url'];?><?php } else { ?>plugin.php?id=aljbd&act=dianpu&type=<?php echo $ttt['id'];?>&subtype=<?php echo $tt['id'];?>&subtype3=<?php echo $tttt['id'];?><?php } ?>"><?php echo $tttt['subject'];?></a>
<?php } ?>
</dd>
</dl>

<?php } } ?>

</div>
</div>

<div class="cate-layer-rihgt">
<?php if($ttt['brand_id']) { ?>
<div class="cate-brand"><?php if(is_array($ppq)) foreach($ppq as $pp) { ?><div class="img">
<a href="plugin.php?id=aljbd&amp;act=view&amp;bid=<?php echo $pp['id'];?>" target="_blank" title="<?php echo $pp['name'];?>"><img src="<?php echo $pp['logo'];?>"></a>
</div>

<?php } ?>
</div>
<?php } if($ttt['type_ad']) { ?>
<div class="cate-promotion">
<div class="swiper-container type_ad" >
<div class="swiper-wrapper" ><?php if(is_array($type_ad_types)) foreach($type_ad_types as $k => $v) { ?><div class="swiper-slide" >
<a href="<?php echo $v['1'];?>">
<img src="<?php echo $v['0'];?>"  alt="<?php echo $v['2'];?>" style="width:199px;height:97px;" width="199" height="97">
</a>
</div>
<?php } ?>
</div>
</div>
</div>
<?php } unset($type_ad_types)?><?php unset($type_pclabel)?></div>
</div>
<div class="clear"></div>
</div>
</div>
<?php } } ?>
   </div>

</div>

</div>
<?php } ?>
<div class="nav-main" id="navLj">
<?php if($_GET['ljdiy'] == 'yes') { ?>
<div style="
    background-color: rgba(0,0,0,0.7);
    position: absolute;
    width: 100%;
    height: 100%;
    text-align: center;
    font-size: 22px;
    "><a class="diyDocument" data-id="pcdiy_nav" href="javascript:;" style="
    color: #ffffff;
    font-weight: bold;
">点击编辑导航菜单</a></div>
<?php } ?>
<ul class="navitems" data-type="range"><?php if(is_array($index_dh_types)) foreach($index_dh_types as $k => $v) { $dt=$ress[$v]?$ress[$v]:$v?><li><a href="<?php echo $v;?>" <?php if($dt===$url_dh||strpos($dt,$_GET['act'])||$v===$the_uri ||(!$_GET['act']&&strpos($url_dh,$dt))) { ?>class="curr"<?php } ?>><?php echo $k;?></a></li>
<?php } ?>
</ul>
</div>

</div>
</div>

<style type="text/css">
body{
<?php if(!$settings['body_color']['value']) { ?>background: url("") repeat-x scroll 0 0 #ffffff;<?php } ?>
}
</style>
<?php if($settings['pc_header_css']['value']) { echo htmlspecialchars_decode($settings['pc_header_css']['value']);?><?php } } else { include template('common/header'); if($_GET['id'] == 'aljbd') { $config = $_G['cache']['plugin']['aljbd'];?><?php } ?>
<script src="source/plugin/aljbd/js/index_new/jquery1.9.1.js" type="text/javascript"></script>
<script type="text/javascript">
</script>
<link href="source/plugin/aljbd/css/new_index/header.css" rel="stylesheet" type="text/css">
<link href="source/plugin/aljbd/css/new_index/reset.css" rel="stylesheet"><?php include template('aljbd:common/common_header_css'); ?></div>
<?php } ?>

<style type="text/css">

.lj_btn {background-color: <?php echo $_G['cache']['plugin'][$pluginid]['p_color'];?>;}
.d {background-color: <?php echo $_G['cache']['plugin'][$pluginid]['d_color'];?>;}
a{text-decoration: none !important;}

#wraptxtKeyWords {width: 450px;}

.icon-mail-alt::before, .icon-heart::before, .icon-heart-empty::before, .icon-music-tb::before, .icon-video::before, .icon-picture::before, .icon-th::before, .icon-quote-left::before, .icon-emo-tongue::before, .icon-indent-right::before, .icon-grid4x::before, .icon-fire::before, .icon-tag::before, .icon-tags::before, .icon-pencil::before, .icon-pencil-squared::before, .icon-location::before, .icon-comment::before, .icon-chat::before, .icon-doc::before, .icon-clock::before, .icon-dress::before, .icon-cog::before, .icon-off::before, .icon-qq::before, .icon-check::before, .icheckbox_line.checked .icheck_line-icon::before, .icheckbox_line.checked.disabled .icheck_line-icon::before, .icon-check-empty::before, .icheckbox_line .icheck_line-icon::before, .icheckbox_line.disabled .icheck_line-icon::before, .icon-circle-empty::before, .iradio_line .icheck_line-icon::before, .iradio_line.disabled .icheck_line-icon::before, .icon-dot-circled::before, .iradio_line.checked .icheck_line-icon::before, .iradio_line.checked.disabled .icheck_line-icon::before, .icon-magic::before, .icon-rmb::before, .icon-smile::before, .icon-search::before, .icon-plus::before, .icon-user::before, .icon-cancel::before, #fancybox-close::before, div.tagsinput span.titag a.deltag::before, .icon-forward::before, .icon-alert::before, .icon-down-dir::before, #goods_adv .icon-dir::before, .icon-up-dir::before, .goods-exts.show-ext #goods_adv .icon-dir::before, .icon-photography::before, .icon-home::before, .icon-left-open::before, .digg_pagination.digg_simple .previous_page::before, .pgslides .i_previous::before, .icon-right-open::before, .digg_pagination.digg_simple .next_page::before, .pgslides .i_next::before, .icon-doc-text::before, .icon-tick::before, .icon-code::before, .icon-supplies::before, .icon-jewelry::before, .icon-ceremony::before, .icon-more::before, .icon-banquet::before, .icon-experience::before, .icon-travel::before, .icon-music::before, .i_music::before, .icon-play::before, .i_video::before, .icon-down-open::before, .pgrid.pgrid-2x.recommendations .ias_trigger .btn.btn-primary::before, .icon-up-open::before, #toTop::before, .icon-logo-text::before, .icon-docs::before, .icon-lightbulb::before, .icon-align-left::before, .icon-align-center::before, .icon-align-right::before, .icon-align-justify::before, .icon-list-bullet::before, .icon-list-numbered::before, .icon-strike::before, .icon-underline::before {
  display: inline;
  font-family: "icomoon";
  font-style: normal;
  font-variant: normal;
  font-weight: normal;
  line-height: 1em;
  margin-left: 0em;
  margin-right: 0.2em;
  text-align: center;
  text-decoration: inherit;
  text-transform: none;
  width: 1em;
}
#pt .z {
padding: 0px;
padding-right: 10px;
}
.lj-more{background:url(source/plugin/aljbd/template/touch/list/images/bg_nav_line.png) no-repeat 0 center;background-size:1px 20px;width: 20px;  height: 20px;text-align:center}.down i{background:url(source/plugin/aljbd/template/touch/list/images/icon_more.png) no-repeat center center;background-size:20px 20px;width:20px;height:20px;display:block;margin-right:10px}.up i{background:url(source/plugin/aljbd/template/touch/list/images/icon_horizon.png) no-repeat center center;background-size:20px 20px;width:20px;height:20px;display:block;margin-right:10px}

</style>
<script type="text/javascript">
var lj_jq=jQuery.noConflict();
<?php if(!$_GET['act'] && ($_GET['id'] == 'aljbd' || $_GET['id'] == 'aljbd:aljbd' || !$_GET['id'])) { } else { ?>
lj_jq(".categorys").hover(function(){
lj_jq(".categorys-tab-content").show();
},function(){
lj_jq(".categorys-tab-content").hide();
});
<?php } if(!$app_dowm) { ?>
lj_jq(".categorys-item").hover(function(){
lj_jq(this).find(".categorys-items-layer").show();
    lunzhuan();
},function(){
lj_jq(this).find(".categorys-items-layer").hide();
});
<?php } ?>
function lunzhuan(){
    new Swiper('.type_ad', {
        spaceBetween: 30,
        loop : true,
        loopAdditionalSlides:1,
        autoplay: 3000,//��ѡѡ��Զ�����
    });
}
</script>
<style>
.bd-label{
background-color: #f42424 !important;border:1px solid #f42424;color: #fff !important;padding:2px 5px;text-align: center;border-radius: 5px;font-size: 12px;margin-left: 5px;
}
img{
object-fit: cover;
}
</style>
<link rel="stylesheet" media="screen,projection,tv" href="source/plugin/<?php echo $pluginid;?>/template/touch/round_robin/round_robin.css" /></link>
<script src="source/plugin/<?php echo $pluginid;?>/template/touch/round_robin/round_robin.js" type="text/javascript"></script>
<!--����-->

