<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
var price1 = '<em style="font-size: 12px;"><?php echo $price_unit;?></em>' + val.collage_price;