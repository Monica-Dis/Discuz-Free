<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<style>
    .video_iframe{
        width: 100px;
        height: 100px;
        background: #000000
    }
    .sd_video_li {
        background: rgba(0, 0, 0, .5) url(source/plugin/aljol/static/img/video_play.png) repeat;
        position: absolute;
        width: 30px;
        height: 30px;
        margin: -15px 0px 0px -15px;
        left: 50%;
        top: 50%;
        background-size: 30px;
        border-radius: 50%;
        -webkit-animation: playvideo 1.2s infinite;
        animation: playvideo 1.2s infinite;
    }
    @-webkit-keyframes sd_playvideo {
        0%,100% {
            -webkit-transform: scale(1);
            transform: scale(1)
        }

        50% {
            -webkit-transform: scale(1.4);
            transform: scale(1.4)
        }
    }

    @keyframes playvideo {
        0%,100% {
            -webkit-transform: scale(1);
            transform: scale(1)
        }

        50% {
            -webkit-transform: scale(1.4);
            transform: scale(1.4)
        }
    }
    .video_fixed {
        z-index: 999999999;
        text-align: center;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        margin: 0 auto;
        background-color: #000;
    }
    .video_fixed_main {
        max-width: none;
        margin-top: 200px;
        font-size: 0;
        font-family: none;
        white-space: nowrap;
        overflow: hidden;
    }
    .sd_video_div {
        overflow: hidden;
        position: relative !important;
        background: #000;
        max-height: 18rem;
    }
    .sd_video_div video {
        width: 100%;
        height: 100%;
        background: #000;
    }
    .video_fixed_close {
        display: inline-block;
        text-align: center;
        margin-top: 15px;
        font-size: 12px;
        color: #333;
        letter-spacing: 0;
        padding: 2px 15px;
        background: hsla(0,0%,100%,.8);
        box-shadow: 0 2.5px 5px 0 rgba(0,0,0,.05);
        border-radius: 15px;
        height: 14px;
        line-height: 14px;
    }
    .pointer{cursor:pointer}
    #partVideoMain {height: calc(100vh - 60px);}
</style>
<div id="part_video" class="video_fixed" style="display: none;">
    <div id="partVideoMain" class="video_fixed_main sd_video_div" style="max-height: none; margin-top: 0px;"></div>
    <div class="closeswiper"><i class="iconfont icon-remove"></i></div>
    <div class="video_fixed_close pointer">退出播放</div>
</div>
<script>
    $(document).on('click','.video_fixed_close,.closeswiper',function () {
        $('#partVideoMain').html('');
        $('#part_video').hide();
    });
    $(document).on('click','.sd-video-play',function () {
        var v_url = $(this).find(".video_iframe").attr('src');

        var v_html = '<video data-width="720" id="video_common" data-height="1280" width="100%" height="auto" src="'+v_url+'"  webkit-playsinline="true" x5-playsinline playsinline="" preload="true" muted="muted" controls="controls" >暂时不支持播放该视频</video>';
        $('#partVideoMain').html(v_html);

        $('#part_video').show();
        var video = $("#partVideoMain video")[0];

        if(video.paused){ // 我点击的这个是暂停的
            video.muted = false;//不静音
            video.play(); //播放
            
        }else{
            video.pause(); //停止
        }

        return false;
    });
</script>