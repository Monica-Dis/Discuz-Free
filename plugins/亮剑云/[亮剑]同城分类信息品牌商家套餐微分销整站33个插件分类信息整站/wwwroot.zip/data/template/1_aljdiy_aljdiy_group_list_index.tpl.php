<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template(PLUGIN_ID.':admin/header')?><style>
    body{ font-size: 14px; }
    tr th{
        color:#666;
        font-size: 14px;
    }
    .info-box-number{
        margin-top:5px;
        margin-left:5px;
    }
    .info-box-text{
        margin-top:10px;
    }
    .layui-table-body{overflow-x: hidden;}
    .content-wrapper{background-color: #ffffff;}
    .layui-laypage-limits select{margin-top:2px;}
    .layui-table, .layui-table-view {
        margin: 3px 0;
    }
    .box.box-default {
        border-top-color: #009688;
    }
    .box {
        position: relative;
        border-radius: 3px;
        background: #fff;
        border-top: 2px solid #009688;
        margin-bottom: 20px;
        width: 100%;
        box-shadow: 0 1px 1px rgba(0,0,0,0.1);
    }
    .nav-tabs {
        border-bottom: none;
    }
    .box.box-primary {
        border-top-color: #009688;
    }
    .btn-primary {
        background-color: #009688;
        border-color: #009688;
    }
    .layui-table-tips-c {
        line-height: 14px;
    }
    .layui-table-cell {
        height: auto;
        line-height: 28px;
        padding: 0 15px;
        position: relative;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: normal;
        box-sizing: border-box;
    }
    .layui-table-view .layui-table{
        width:100%!important;
    }
    .catpic img{
        width:40px;
    }
</style>
<div class="content-wrapper" style="margin-left:0px">
    <section class="content">
        <div class="row">
            <div class="col-md-9">
                <?php include template('aljdiy:aljdiy/page/list_nav'); ?>            </div>

            <div class="col-md-3" style="text-align:right">
                <a href="javascript:;"  class="btn btn-primary realtime"><strong>&nbsp;创建页面分组</strong></a>
            </div>

            <!-- /.col -->
            <div class="col-md-12">
                <div class="box box-primary">
                    <!-- /.box-header -->

                    <iframe style="display:none;" name="submitiframe"></iframe>
                    <form name="cpform" id="admingoodssubmit" method="post" autocomplete="off" action="<?php echo $dourl;?>" target="submitiframe">
                        <input type="hidden" value="yes" name="ajax">
                        <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>">
                    </form>
                    <blockquote class="layui-elem-quote" style="margin-top:10px;font-size:14px;">每个分组都支持开启顶部轮转导航，可用于快速切换分组内的所有页面</blockquote>
                    <table id="demo" lay-filter="test"></table>
                    <script type="text/html" id="barDemo">
                        <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="view">管理页面</a>
                        <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="query">编辑</a>
                        <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="del">删除</a>
                    </script>
                </div>
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
</div>
<script>


    var R = {
        options: {
            formhash: '<?php echo FORMHASH;?>',
        },
        realtime: function(){
            $('.realtime').click(function() {
                layer.open({
                    type: 2,
                    title: '添加分组',
                    shadeClose: true,
                    shade: false,
                    maxmin: true, //开启最大化最小化按钮
                    offset: "20px",
                    area: ['550px', '250px'],
                    content: 'plugin.php?id=aljdiy&c=group&a=list_submit'
                });
            });
        },
        enterPress: function(e){
            var e = e || window.event;
            if(e.keyCode == 13){
                $('.glyphicon-search').click();
            }
        },
        init: function(){
            layui.use('table', function(){
                var table = layui.table;
                var tableIns = table.render({
                    elem: '#demo'
                    ,limit: 20
                    ,url: 'plugin.php?id=aljdiy&c=group&a=list_index&ajax=yes&render=yes&admin_id=<?php echo $admin_id;?>&station_id=<?php echo $station_id;?>'
                    ,page: true
                    ,skin: 'line'
                    ,even: true
                    ,cols: [[
                        {field: 'title', title: '分组名',width: 100, templet: function(d){
                            return d.title;
                        }}
                        ,{field: 'dateline', title: '创建时间'}
                        ,{field: 'open', title: '开关', templet: function(d){
                            if(d.open == 'on'){
                                return '已开启';
                            }else{
                                return '已关闭';
                            }
                            
                        }}
                        ,{align:'center', toolbar: '#barDemo', title: '操作'}
                    ]]
                });
                table.on('tool(test)', function(obj){
                    var data = obj.data;
                    if(obj.event === 'del'){
                        layer.confirm('您确定要删除吗？', {"offset": "50px"}, function(index){
                            layer.load(0, {"offset": "50px"});
                            $.post('plugin.php?id=aljdiy&c=group&a=list_delete&ajax=yes&mid='+data.id, function(){
                                layer.alert('删除成功！', {"offset": "50px"}, function(){
                                    obj.del();
                                    layer.closeAll();
                                });
                            });

                        });
                    }
                    if(obj.event === 'query'){
                        layer.open({
                            type: 2,
                            title: '编辑分组',
                            shadeClose: true,
                            shade: false,
                            maxmin: true, 
                            offset: "20px",
                            area: ['550px', '350px'],
                            content: 'plugin.php?id=aljdiy&c=group&a=list_submit&mid='+data.id
                        });
                    }
                    if(obj.event === 'view'){
                        location.href = 'plugin.php?id=aljdiy&c=page&a=list_index&groupid='+data.id;
                    }
                });
                $('.glyphicon-search').on('click', function(){
                    tableIns.reload({
                        where: {
                            search: $('#search').val()
                        }
                        ,page: {
                            curr: 1
                        }
                    });
                });

            });
            R.realtime();
        }
    }
    R.init();
</script><?php include template(PLUGIN_ID.':admin/footer')?>