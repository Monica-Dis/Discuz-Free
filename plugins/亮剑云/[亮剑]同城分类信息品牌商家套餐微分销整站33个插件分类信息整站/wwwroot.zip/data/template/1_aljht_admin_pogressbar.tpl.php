<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template('aljht:admin/iframe_header_common'); ?><style>
.progress{
background:#fff;
 position: absolute;
border-radius:10px;
width:50%;
height:50%;
top:23%;
left:30%;
}
.layui-color-red{
background-color:RGBA(247,36,36,0.77);
}

</style>
<div class="content-wrapper">
<section class="content ">
<div class="progress text-center">
<blockquote class="layui-elem-quote layui-bg-blue" style="background-color: #3c8dbc;border-left: 5px solid #3c8dbc; color:#fff;">&#25552;&#31034;</blockquote>

<div class="layui-progress layui-progress-big " lay-showpercent="true" lay-filter="demo"  style="margin-top: 130px;font-size: 20px">
<?php echo $aljht_tips;?><br/><a  href="javascript:;" onclick="history.go(-1);">&#36820;&#22238;&#19978;&#19968;&#39029;</a>
</div>
</div>
</section>
</div><?php include template('aljht:admin/footer'); ?>