<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>

<style>
* {
margin: 0;
padding: 0;
}
.hot-top-row {
  padding-left: 12px;
  padding-right: 12px;
  display: -webkit-box;
  -webkit-box-align: center;
  height: 40px;
  border-top: 1px solid #f8f8f8;
  background: #ffffff;
}
.hot-top-row .hot-top {
  position: relative;
  font-weight: 700;
  line-height: 40px;
  padding-right: 8px;
  color:#007aff;
  font-size: 16px;
  font-family: 'Helvetica Neue',Roboto,'microsoft yahei';
}
.hot-top-row .hot-slide {
  color: #666;
  position: relative;
  overflow: hidden;
  -webkit-box-flex: 1;
  margin-left: 8px;
  font-size: 14px;
  line-height: 16px;
  height: 40px;
  width: 100%;
}
.hot-top-row .hot-slide a{color: #666;}
.hot-top-row ul.swiper-wrapper>li {
  float: left;
  position: relative;
  width: 100%;
  height: 40px;
  line-height: 40px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.hot-top-row .hot-top span{
  color: #FF2D2D;
  padding: 3px 5px;
  border-radius: 5px;
}
.hot-top-content{
  position: fixed;
  top: 0px;
  background: #ffffff;
  z-index: 10000;
  left: 0px;
  width: 100%;
  height: 100%;
  display: none;
  overflow: hidden;
}
.subject-max{text-align: center;padding:10px;}
.content-max{margin-bottom: 100px;}
.hot-top-content-show .show_popups{
  display: block;
  -webkit-animation: popups-box .3s forwards ease;
  animation:popups-box .3s forwards ease;
}
.show_popups{
  display: none;
  width:100%;
  position: fixed;
  left: 0;
  top: 0px;
  z-index: 10000;
  padding: 0 10px;
  transform: translateY(100%);
  -webkit-transform: translateY(100%);
  overflow-x: hidden;
  overflow-y: auto;
  height:100%;
}
@keyframes show_popups {
  100% {
    transform: translateY(0);
    -webkit-transform: translateY(0);
  }
}

@-webkit-keyframes show_popups {
  100% {
    transform: translateY(0);
    -webkit-transform: translateY(0);
  }
}
.close-popup-btn{
  position: fixed;
  left: 0;
  bottom: 0px;
  z-index: 10000;
  display: block;
  margin-left: auto;
  margin-right: auto;
  padding-left: 14px;
  padding-right: 14px;
  box-sizing: border-box;
  font-size: 18px;
  text-align: center;
  text-decoration: none;
  color: #FFFFFF;
  line-height: 50px;
  border-radius: 5px;
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
  overflow: hidden;
  background-color: #007aff;
  width: 100%;
}
  .hot-top-row .swiper-slide span{color:#f42424;margin-right: 5px;}
</style>
</head>
<body>
<div class="hot-top-row">
  <div class="hot-top"><span><?php if($settings['mobile_index_hot_title']['value']) { ?><?php echo $settings['mobile_index_hot_title']['value'];?><?php } else { ?>同城热点<?php } ?></span></div>
  <div class="hot-slide swiper-container swiper-container-vertical" id="hot-slide">
    <ul class="swiper-wrapper" >
      
      <?php if($settings ['mobile_index_hot_text']['value']) { ?>
      <?php if(is_array($mobile_index_hot_text_types)) foreach($mobile_index_hot_text_types as $hv) { ?>      <li class="swiper-slide swiper-slide-duplicate" > <a href="<?php echo $hv['1'];?>"><?php echo $hv['0'];?></a> </li>
      <?php } ?>
      <?php } ?>
      <?php if($mobile_index_hot_type_1) { ?>
      <?php if(is_array($mobile_index_hot_type_1)) foreach($mobile_index_hot_type_1 as $new_t_1) { ?>        <li class="swiper-slide swiper-slide-duplicate">
          <a href="plugin.php?id=aljtc&amp;act=view&amp;lid=<?php echo $new_t_1['id'];?>">
              [<?php echo date('m-d',$new_t_1['addtime'])?>] <span class="p_color"><?php echo $new_t_1['username'];?></span>发布了<?php echo $pos_all[$new_t_1['zufangtype']]['subject'];?>信息
            </a>
        </li>
      <?php } ?>
      <?php } ?>
      <?php if($mobile_index_hot_type_2) { ?>
      <?php if(is_array($mobile_index_hot_type_2)) foreach($mobile_index_hot_type_2 as $newv) { ?>        <li class="swiper-slide swiper-slide-duplicate">
          <a href="plugin.php?id=aljtsq&amp;a=view&amp;c=aljtsq&amp;store_id=<?php echo $newv['tc_id'];?>">
              <span class="p_color"><?php echo $newv['tc_store_name'];?></span> 成功入驻 [<?php echo date('m-d',$newv['tc_dateline'])?>]
            </a>
        </li>
      <?php } ?>
      <?php } ?>
    </ul>
  </div>
</div>

<script type="text/javascript">
var mySwiper = new Swiper('#hot-slide', {
    paginationClickable: true,
    direction: 'vertical',
    autoplay: 3000,//可选选项，自动滑动
    scrollbarHide: true,

});
</script>
