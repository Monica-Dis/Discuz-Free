<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if(!$settings['is_mobile_index_hot']['value']) { ?>
<style type="text/css">
    .div-component{position:relative;background:#f6f6f9}.div-component .handle{position:absolute;left:0;bottom:0;right:0;top:0;z-index:3}.div-component.active .actions,.div-component.active .remove-module,.div-component:hover .actions,.div-component:hover .remove-module{display:block;cursor:pointer}.div-component .actions{border:2px dashed #27b9d7;box-sizing:border-box;position:absolute;left:0;bottom:0;right:0;top:0;z-index:2;display:none}.div-component .remove-module{background:#27b9d7;color:#fff;font-size:13px;padding:3px 6px;position:absolute;right:0;bottom:0;z-index:8;display:none}.announcement{background:#fff;display:box;display:-webkit-box;display:flex;display:-webkit-flex;-webkit-box-pack:center;-ms-flex-pack:center;padding:5px 0;height:55px;line-height:55px}.announ-left,.announ-right,.announcement{align-items:center;-webkit-align-items:center;justify-content:center}.announ-left,.announ-right{padding:0 10px}.announ-left{float:left;color:#ec5151;line-height:normal;height:100%}.announ-left img{vertical-align:midden;max-height:90%;width:auto;margin-top:5px}.announ-right{float:right;font-size:14px;padding-bottom:3px;padding-top:3px;height:28px;line-height:28px;box-sizing:content-box;border-left:1px solid #f6f6f9;color:#666;position:relative}.announ-right a{position:absolute;left:0;right:0;top:0;bottom:0}.announ-right i{font-size:14px;margin-left:2px}.announ-center{overflow:hidden;float:left;width:64%;-webkit-box-flex:1;box-flex:1;flex:1;-webkit-flex:1;color:#333;height:53px;padding:0 7px;padding-left:0}.announ-center .swiper-container5{width:100%;height:100%}.announ-center .swiper-slide .announcement-cont{font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:left;line-height:53px;position:relative}.announ-center .swiper-slide a{position:absolute;left:0;right:0;top:0;bottom:0}
</style>
<div class="div-component">
    <div id="mod-announcement" class="vue-model mod-announcement">
        <div class="frontend">
            <section class="announcement">
                <div class="announ-left diyDocument" diy-id="gg_icon">
                    <img src="<?php if($settings['gg_icon']['value']) { ?><?php echo $settings['gg_icon']['value'];?><?php } else { ?>source/plugin/aljbd/template/touch/round_robin/hot.png<?php } ?>" alt="">
                </div>
                <div class="announ-center diyDocument" diy-id="gg_types">
                    <div class="swiper-container5 announ-del swiper-container-vertical">
                        <div class="swiper-wrapper" >
                            <?php if(is_array($gg_types)) foreach($gg_types as $gk => $gv) { ?>                            <div class="swiper-no-swiping swiper-slide swiper-slide-prev" style="height: 36px;" data-swiper-slide-index="0">
                                <a class="navigateTo" href="<?php echo $gv;?>">
                                    <div class="announcement-cont"><?php echo $gk;?></div>
                                </a>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>

            </section>
        </div> <!---->
    </div>
</div>
<?php } ?>