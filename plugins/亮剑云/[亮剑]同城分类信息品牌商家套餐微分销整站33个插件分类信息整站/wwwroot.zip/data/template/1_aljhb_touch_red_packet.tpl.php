<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); require_once DISCUZ_ROOT.'source/plugin/aljhb/include/common.php';?><link rel="stylesheet" href="source/plugin/aljhb/static/css/red_packet.css">
<script src="source/plugin/aljhb/static/weui/jquery.min.js" type="text/javascript"></script>
<?php if($weui) { ?>
<link href="source/plugin/aljhb/static/weui/weui.min.css" rel="stylesheet" type="text/css">
<?php } ?>
<link rel="stylesheet" href="source/plugin/aljhb/static/weui/jquery-weui.min.css">

<script src="source/plugin/aljhb/static/weui/jquery-weui.min.js" type="text/javascript"></script>
<style>
.red_header {
width: 100%;
height: 40px;
line-height: 40px;
text-align: center;
color: #FC951E;
font-size: 16px;
overflow: hidden;
position: fixed;
top: 0;
left: 0;
z-index: 9999;
}
.red_header a {
display: block;
height: 40px;
line-height: 40px;
margin: 0;
padding: 0 15px;
color: #FC951E;
text-align: center;
overflow: hidden;
position: absolute;
font-size: 14px;
}
.red_header i {
font-size: 20px;
vertical-align: middle;
}
.red_header .red_right {
right: 0;
font-size: 14px;
}
.red_packet_box_showname span {
font-size: 24px;
padding:0px 2px;
}
.red_packet_res_wrap span {
color: #ffffff;
font-size: 16px;
padding:0px 2px;
}
.red_packet_box .plugin-act-close {

width: 0.868752rem;
height: 0.868752rem;
background-image: url(source/plugin/aljhb/static/img/btn_close.png);
right: 0.468752rem;
top: 0.875008rem;
z-index: 300;
background-size: cover;
background-repeat: no-repeat;
position: absolute;
}
</style>
<?php if($iswechat || $_GET['id'] == 'aljol' || $_GET['id'] == 'aljhbx') { ?>
<div class="red_packet_res red_packet_box" id="red_packet_box">
<div class="plugin-act-close" onclick="hide_red_packet()"></div>
<div class="red_packet_box_main zoomIn animated ">
<div class="red_packet_box_title">
<div class="send_title"></div>
<div class="red_packet_star"></div>
<div class="red_packet_box_showname">
<p>�ܼ�<span class="red_price"><?php echo $hb_array['h_price'];?></span>Ԫ</p>
</div>
<div class="red_packet_btn animated" id="red_packet_btn" onclick="show_red_packet_Box(this);">
<div class="red_packet_btn_mask"></div>
<a href="javascript:;"> </a>
</div>
</div>
<div class="red_packet_from">
<p><span class="red_user"><?php echo $hb_array['user']['username'];?></span></p>
<p>����һ�����</p>
</div>
<div class="view_oth">
<p>��ȡ�ĺ������������Ǯ��</p>
</div>
<div class="sub_bg"></div>
</div>
</div>
<?php } ?>
<div class="red_packet" >

<div class="red_packet_res animated zoomIn" id="red_packet_list_box" >
<header class="red_header">
<a  href="javascript:;" onclick="hide_red_packet_list()"><i style="display: inline-block"><img src="source/plugin/aljhb/static/img/back.png" width="22" style="top: 2px;position: relative;vertical-align: baseline;display: inline-block"/></i>����</a>
<?php if($_GET['id'] != 'aljol') { ?>
<a class="red_right" href="javascript:;" onclick="share_guider_show()"><i style="display: inline-block"><img src="source/plugin/aljhb/static/img/share.png" width="18" style="margin-right: 5px;vertical-align: baseline;display: inline-block"/></i>����</a>
<?php } else { ?>
<a class="red_right" href="plugin.php?id=aljqb" >Ǯ��</a>
<?php } ?>
</header>

<div class="red_packet_res_wrap">
<div class="red_packet_res_head">
<div class="red_packet_res_head_in">
<img src="<?php echo avatar($v['uid'], 'big', true);?>">
</div>
</div>
<div class="red_packet_res_cnt">
<div class="red_packet_res_box">
<p ><span class="red_user"><?php echo $hb_array['user']['username'];?></span></p>
<p >����<span class="red_price"><?php echo $hb_array['h_price'];?></span>Ԫ���</p>
<div class="red_packet_money"></div>
</div>
<div class="red_packet_list_outer" style="display: block">
<div class="red_packet_list_h weui-flex">
<span></span>
<p class="weui-flex__item tit js-cnt">��<span id="h_num"></span>������<span id="y_num"></span>����ʣ<span id="over"></span>��������<span id="o_num"></span>��</p>
<span></span>
</div>
<div class="red_packet_list" id="red_packet_list">

</div>
</div>



</div>
<div class="sub_bg"></div>
<a class="enter-purse" href="plugin.php?id=aljqb">�����ҵ�Ǯ��</a>
</div>
</div>
<div class="share-mask" onclick="share_guider_hide()"><div class="share-guider"></div></div>
</div>
<style>
.red_packet_res_wrap .enter-purse {
font-size: 14px;
color: rgba(255,255,255,.6);
text-align: center;
position: fixed;
left: 50%;
bottom: 20px;
transform: translateX(-50%);
-webkit-transform: translateX(-50%);
}
.share-mask {
position: fixed;
top: 0;
left: 0;
right: 0;
bottom: 0;
background: rgba(0,0,0,.5);
z-index: 9999999;
display: none;
}
.share-guider {
background: url(source/plugin/aljhb/static/img/guide_share.png) no-repeat right top;
background-size: 240px auto;
width: 100%;
height: 300px;
position: absolute;
right: 10px;
top: 10px;
}
</style>
<script src="source/plugin/aljhb/static/js/js_sdk20170302.js" type="text/javascript"></script>
<script>
    var solve= 1;
    var formhash= '<?php echo FORMHASH;?>';
    var page=1;
    var loading=false;
    var max=2;
    var p_id='';
    var h_id='';
    var mod='';

    //ͼƬ����
function share_guider_show() {
if(is_kingkr_obj()){
var share_img = 'source/plugin/aljhb/static/img/kai.png';
var s_url = location.href.split('#')[0];
var auto_imglist = $('img');
for(var i=0; i<auto_imglist.length; i++){

                if(auto_imglist[i].naturalWidth < 200){

                    continue;

                }

                if(auto_imglist[i].naturalHeight < 200){

                    continue;

                }

                share_img = auto_imglist[i].src;

                break;

            }

            if(share_img.indexOf('http://')===-1 && share_img.indexOf('https://')===-1){

                share_img = "<?php echo $_G['siteurl'];?>"+share_img;

            }
var share_title = document.title ? document.title : '\u7b7e\u5230\u9886\u7ea2\u5305';


share('share',share_title, share_img, s_url, share_title);
}else{
$('.share-mask').show();
}
    }
    //���ط���
    function share_guider_hide() {
        $('.share-mask').hide();
    }
    //������ȡ�������
    function hide_red_packet() {
        $('#red_packet_box').removeClass('show');
    }

<?php if($hb_array || $_GET['id'] == 'aljol') { ?>
    //�ж��Ƿ�����ȡ���ǽ�������ҳ��
    function show_red_packet(aaa, bbb,ccc){
if (typeof(aaa) == "undefined"){aaa = '';}
if (typeof(bbb) == "undefined"){bbb = '';}
if (typeof(ccc) == "undefined"){ccc = '';}
p_id = bbb;
h_id = aaa;
        mod = ccc;
        p_id = p_id == ''? '<?php echo $hb_array['pluginid'];?>':p_id;
        h_id = h_id == ''? '<?php echo $hb_array['hid'];?>':h_id;
        mod = mod == ''? '<?php echo $hb_array['module'];?>':mod;
        $.post('plugin.php?id=aljhb&act=show_red_packet&pluginid='+p_id+'&hid='+h_id+'&module='+mod,function(data) {
            $('.red_user').html(data.h_array.username);
            $('.red_price').html(data.h_array.h_price);
            if(data.status == 0){
                $('#red_packet_box').addClass('show');
            }else if(data.status > 0){
                show_red_packet_list();
            }else if(data.status == '-1'){
                h_tips('���������');
}else if(data.status == '-3'){
                h_tips('����ѹ���');
            }else if(data.status == '-2'){
                show_red_packet_list();
            }
        },'json');
    }
<?php } ?>
    //show_red_packet();
//��ȡ���
    function show_red_packet_Box(obj) {
        $(obj).addClass('stuff');
        console.log(p_id+'=='+h_id+'=='+mod);
        setTimeout(function () {
            $.post('plugin.php?id=aljhb&act=receive&pluginid='+p_id+'&hid='+h_id+'&module='+mod,function(data) {
                if(data == 2){
                    h_tips('������ȡ���ú����');
                }else if(data == 3){
                    h_tips('��������꣡');
                }else if(data == 4){
                    h_tips('����쳣��');
                }else if (data == 1){
                    h_tips('��ȡ�ɹ���');
                    show_red_packet_list();
                }
                $('#red_packet_box').removeClass('show');
                $(obj).removeClass ('stuff');
            },'json');
        }, 500);
    }
    //����������
    function red_packet_html(data){
        var red_html = '';
    	if(data!='0'){
            for(var i =0; i<data.length; i++){
                red_html += '<div class="red_packet_item">';
                red_html += '<div class="red_packet_portrait"><img src="'+data[i].avatar+'"></div>';
                red_html += '<div class="red_packet_iteminfo"><p>'+data[i].username+'</p><p class="red_packet_itemdate">'+data[i].updatetime+'</p></div>';
                red_html += '<div class="red_packet_itemamount"><p>'+data[i].price+'Ԫ</p></div>';
                red_html += '</div>';
            }
}
$('#red_packet_list').append(red_html);
}
//���������ݵ�ȡ
    function show_red_packet_list(){
        p_id = p_id == ''? '<?php echo $hb_array['pluginid'];?>':p_id;
        h_id = h_id == ''? '<?php echo $hb_array['hid'];?>':h_id;
        mod = mod == ''? '<?php echo $hb_array['module'];?>':mod;
        $.post('plugin.php?id=aljhb&act=red_packet_list&pluginid='+p_id+'&hid='+h_id+'&module='+mod,function(data) {
            $('#red_packet_list').html('');
            red_packet_html(data.h_array);
            //$('#red_packet_size').html();//�����Ǯ
if(data.price){
var h_yhtm = '<p style="padding-top:10px">';
h_yhtm += '<b id="red_packet_size" style="font-size:36px">'+data.price+'</b>';
h_yhtm += '<em>Ԫ</em>';
h_yhtm += '</p><p><a href="plugin.php?id=aljqb" style="color:#ffffff;">������Զ���������Ǯ����</a></p>';
}else{
<?php if($_G['uid']) { ?>
var h_yhtm = '<p style="padding-top:10px">��������</p>';
<?php } else { ?>
                var h_yhtm = '<p style="padding-top:10px">��¼���������ȡ���</p>';
<?php } ?>
}
            $('.red_packet_money').html(h_yhtm);//�����Ǯ
            $('#h_num').html(data.h_num);//�����ٸ�
            $('#y_num').html(data.y_num);//���ڶ��ٸ�
            $('#over').html(data.over);//��ʣ���ٸ�
            $('#o_num').html(data.o_num);//���ڶ��ٸ�
            $('.red_packet_res_head_in').html('<img src="'+data.avatar+'">');
$('#red_packet_res').hide();
$('#red_packet_list_box').show();
        },'json');
    }
    //�ر�������ҳ��
    function hide_red_packet_list() {
        $('#red_packet_list_box').hide();
    }

    function toDecimal(x) {
        var f = parseFloat(x);
        if (isNaN(f)) {
            return;
        }
        f = Math.round(x*100)/100;
        return f;
    }
    //��ʾ
    function h_tips(info,url) {

if(typeof(url) == "undefined"){
          $.toast(info, "text");
}else{
$.toast(info, "text",function() {
window.location.href = url;
});

}
    }
    //��ʾ��¼�к������
    function h_login() {
        $.notification({
            title: "��ʾ",
            text: "��¼��΢�ŷ�������ȡ���������ɵ�¼",
            media: "<img src='source/plugin/aljhb/static/img/red.png'>",
            data: "123",
            onClick: function(data) {
                window.location.href = 'member.php?mod=logging&action=login&referer='+location.href.split('#')[0].replace(/&/g, "%26");
            },
            onClose: function(data) {
                $.modal({
                    title: "��ʾ",
                    text: "��¼��΢�ŷ�������ȡ���",
                    buttons: [
                        { text: "ȥ��¼", onClick: function(){
                            window.location.href = 'member.php?mod=logging&action=login&referer='+location.href.split('#')[0].replace(/&/g, "%26");
                        }
                        },
                        { text: "��������", className: "default", onClick: function(){ console.log(3)} },
                    ]
                });
            }
        });
    }
    <?php if($hb_array && empty($_G['uid'])) { ?>
    //h_login();
<?php } ?>
    //������ҳ����������
    $('.red_packet_res_wrap').infinite(100).on("infinite", function() {

        if(loading==true) return;
        page++;
        loading = true;
        $('#load').show();
        var url='plugin.php?id=aljhb&act=red_packet_list';
        p_id = p_id == ''? '<?php echo $hb_array['pluginid'];?>':p_id;
        h_id = h_id == ''? '<?php echo $hb_array['hid'];?>':h_id;
        mod = mod == ''? '<?php echo $hb_array['module'];?>':mod;
        var data = {
            'page':page,
            'pluginid':p_id,
            'hid':h_id,
            'module':mod,
        }
        $.post(url,data,function(res){
            if(res.h_array==0){
                loading = true;
                $('#load').hide();
                return false;
            }else {
                red_packet_html(res.h_array);
                loading = false;
                $('#load').hide();
            }
        },'json')

    });
</script><?php include template('aljhb:post_red'); if($hb_array) { ?>
<div class="global-rightpanel animated slideInRight">
<a class="rightpanel-redpack" onclick="show_red_packet_list()"><i ><img src="source/plugin/aljhb/static/img/red.png" width="16"/></i><em>���</em></a>
</div>
<style>
.global-rightpanel a {
display: block;
height: auto;
width: 35px;
padding-top: 6px;
padding-bottom: 6px;
font-size: 12px;
background: rgba(0,0,0,.5);
border-bottom: 1px solid rgba(0,0,0,.05);
color: #fff;
text-align: center;
box-sizing: border-box;
}
.global-rightpanel {
position: fixed;
bottom: 20%;
left: 1px;
z-index: 6;
border-radius: 2px;
overflow: hidden;
}
.global-rightpanel a.rightpanel-redpack {
background: rgba(233,28,45,.7)
}

.global-rightpanel i {
display: block;
height: 18px;
line-height: 18px;
font-size: 16px;
margin-bottom: 3px
}

.global-rightpanel em {
display: block;
line-height: 13px;
font-size: 12px
}
address, cite, dfn, em, i, var {
font-style: normal;
}
</style>
<?php if($hb_array['h_num'] > $hb_array['y_num'] && !$h_log) { ?>
<div style="display: none" ><audio id="hb_mp3" preload="preload"><source src="<?php echo $_G['cache']['plugin']['aljhb']['mp3'];?>" type="audio/mpeg" /></audio></div>
<script>
    if(window.sessionStorage.getItem("aljhb_mp3") == null) {
        document.getElementById("hb_mp3").play();
        window.sessionStorage.setItem("aljhb_mp3", 1);
    }

</script>
<?php } } ?>
<style>
@keyframes swing {
5% {
transform: rotate3d(0, 0, 1, 25deg);
}

10% {
transform: rotate3d(0, 0, 1, -20deg);
}

20% {
transform: rotate3d(0, 0, 1, 5deg);
}

25% {
transform: rotate3d(0, 0, 1, -5deg);
}

30% {
transform: translate3d(0,0,1,0);
}
}

.swing {
animation: swing 1.48s infinite cubic-bezier(0.000, 0.460, 0.520, 1.000) both;
}
</style>
<?php if($_GET['id'] != 'aljol' && $_GET['id'] != 'aljhbx' && !$_G['cache']['plugin']['mapp_share']) { include template('aljhb:share'); } ?>
