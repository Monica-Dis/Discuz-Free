<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template('aljht:admin/iframe_header_common'); include template('aljbd:editor'); if(file_exists("source/plugin/aljbzj/template/force_pay_tips.htm")) { include template('aljbzj:force_pay_tips'); } ?>
<style>

    .lb{padding-right: 10px;}
</style>
<div class="content-wrapper">
    <?php if($_GET['ajax'] != 'yes') { ?>
    <section class="content-header">
        <h1>
            <?php echo $aljhtlang['template']['goods_1'];?>

        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo $index_url;?>"><i class="fa fa-dashboard"></i> <?php echo $aljhtlang['template']['brand_31'];?></a></li>
            <li><a href="plugin.php?id=aljht&amp;act=admin"><?php echo $aljhtlang['template']['brand_32'];?></a></li>
            <li class="active"><?php echo $aljhtlang['template']['goods_1'];?></li>
        </ol>
    </section>
    <?php } ?>
    <section class="content">
        <div class="row">
            <!-- /.col -->
            <iframe style="display:none;" name="submitiframe"></iframe>
            <form name="cpform" id="admingoodssubmit" class="form-horizontal" method="post" autocomplete="off" action="plugin.php?id=<?php echo $pluginid;?>&amp;act=admin&amp;op=<?php echo $op;?>&amp;do=<?php echo $do;?><?php echo $urlmod;?>" target="submitiframe" >
                <input type="hidden" value="<?php echo FORMHASH;?>" name="formhash">
                <input type="hidden" value="<?php echo $gid;?>" name="gid">
                <input type="hidden" value="<?php echo $bid;?>" name="bid">
                <input type="hidden" value="<?php echo $_GET['iframeeditgoods'];?>" name="iframeeditgoods">
 <input type="hidden" name="compress" value="" id="compress">
                <input type="hidden" name="copy" value="<?php echo $_GET['copy']?>" >
<input type="hidden" name="aljbd_goods_token" value="<?php echo create_token('aljbd_goods_token');?>">
            <div class="col-md-12">
                <div class="box box-primary mailbox-messages">
                    <div class="box-header with-border ">
                        <h3 class="box-title"><?php if($do == 'editgoods') { ?><?php echo $aljhtlang['template']['addgoods_1'];?><?php } else { ?><?php echo $aljhtlang['template']['addgoods_2'];?><?php } ?><?php echo $aljhtlang['template']['addgoods_3'];?></h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
<?php if($administrators) { ?>
                        <div class="form-group">
                            <label class="col-sm-3 control-label"><?php echo $aljhtlang['template']['addgoods_4'];?></label>
                            <div class="col-sm-6">
                            <input class="form-control" placeholder="<?php echo $aljhtlang['template']['addgoods_4'];?>" name="displayorder" value="<?php echo $goods['displayorder'];?>">
                            </div>
                        </div>
                    <?php } ?>
                    <?php if($_GET['dzAdmin'] == 1) { ?>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">&#20998;&#31449;&#73;&#68;</label>
                        <div class="col-sm-6">
                        <input class="form-control" placeholder="&#22635;&#20889;&#20998;&#31449;&#73;&#68;" name="fz_id" value="<?php echo $goods['fz_id'];?>">
                        </div>
                    </div>
                    <?php } ?>
                        <div class="form-group" <?php if($settings['is_post_btn']['value']) { ?>style="margin-bottom: 0px"<?php } ?>>
                            <?php if($_GET['dzAdmin'] == 1) { ?>
                            <label class="col-sm-3 control-label">关联门店</label>
                            <div class="col-sm-6">
                                
                                <select name="store_id"  class="form-control brandid" >
                                    <?php if(is_array($bdlist)) foreach($bdlist as $bdv) { ?>                                    <option value="<?php echo $bdv['tc_id'];?>" <?php if($bdv['tc_id']==$store_id) { ?>selected<?php } ?> data_goods_intro_video="<?php echo $bdv['vipdata']['goods_intro_video'];?>" data-give-integral="<?php echo $bdv['vipdata']['give_integral'];?>" data-pay-integral="<?php echo $bdv['vipdata']['pay_integral'];?>" data-is-distribution="<?php echo $bdv['vipdata']['is_distribution'];?>" data-is-video="<?php echo intval($bdv['vipdata']['is_video']);?>"><?php echo dhtmlspecialchars($bdv['tc_store_name']);?></option>
                                    <?php } ?>
                                </select>
                                
                            </div>
                            <?php } else { ?>
                            <label class="col-sm-3 control-label">选择店铺</label>
                            <div class="col-sm-6">
                                <?php if($settings['is_post_btn']['value']) { ?>
                                <select name="bid"  class="form-control brandid" >
                                    <?php if(is_array($bdlist)) foreach($bdlist as $bdv) { ?>                                    <option value="<?php echo $bdv['id'];?>" <?php if($bdv['id']==$bid) { ?>selected<?php } ?> data_goods_intro_video="<?php echo $bdv['vipdata']['goods_intro_video'];?>" data-give-integral="<?php echo $bdv['vipdata']['give_integral'];?>" data-pay-integral="<?php echo $bdv['vipdata']['pay_integral'];?>" data-is-distribution="<?php echo $bdv['vipdata']['is_distribution'];?>" data-is-video="<?php echo intval($bdv['vipdata']['is_video']);?>"><?php echo dhtmlspecialchars($bdv['name']);?></option>
                                    <?php } ?>
                                </select>
                                <?php } else { ?>
                                <div class="form-control" style="text-align: left">
                                    <?php echo dhtmlspecialchars($bd['name']);?>                                    <select class="form-control brandid" style="display: none">
    
                                        <option value="<?php echo $bd['id'];?>" selected data_goods_intro_video="<?php echo $vipdata['goods_intro_video'];?>" data-give-integral="<?php echo intval($vipdata['give_integral']);?>" data-pay-integral="<?php echo intval($vipdata['pay_integral']);?>" data-is-distribution="<?php echo intval($vipdata['is_distribution']);?>" data-is-video="<?php echo intval($vipdata['is_video']);?>"><?php echo dhtmlspecialchars($bdv['name']);?></option>
    
                                    </select>
                                </div>
                                <?php } ?>
                                </div>
                            <?php } ?>
                            
                        </div>
                        <script>
                            var data_give_integral='';
                            var data_pay_integral='';
                            var data_is_distribution='';
                            var data_is_video='';
                            var data_goods_intro_video='';
                            var c_brandid='0';
                            var cdtype = 0;
                            $('.brandid').change(function() {
                                c_brandid = 1;
                                brandtypechange();
                            });
                            function brandtypechange() {
                                data_give_integral = parseInt($('.brandid option:selected').attr('data-give-integral'));
                                data_pay_integral = parseInt($('.brandid option:selected').attr('data-pay-integral'));
                                data_is_distribution = parseInt($('.brandid option:selected').attr('data-is-distribution'));
                                data_is_video = parseInt($('.brandid option:selected').attr('data-is-video'));
                                data_goods_intro_video = parseInt($('.brandid option:selected').attr('data_goods_intro_video'));
                                console.log(data_give_integral+'==='+data_pay_integral);

                                if($('.brandid option:selected').val() && c_brandid==1){
                                    $.post('plugin.php?id=<?php echo $pluginid;?>&act=admin&op=<?php echo $op;?>&do=ajax_btype<?php echo $urlmod;?>',{'bid':$('.brandid option:selected').val()},function(data){
                                        $(".brandtype").html(data);
                                    });
                                }

                                if(data_give_integral > 0){
                                    $('.div_give_integral').show();
                                }else{
                                    $('.div_give_integral').hide();
                                }
                                if(data_pay_integral > 0){
                                    $('.div_pay_integral').show();
                                }else{
                                    $('.div_pay_integral').hide();
                                }
                                if(data_is_distribution > 0){
                                    $('.distribution').show();
                                }else{
                                    $('.distribution').hide();
                                }
                                if(data_is_video > 0){
                                    $('.video_box').show();
                                }else{
                                    $('.video_box').hide();
                                }
                                if(data_goods_intro_video > 0){
                                    $('.goods_intro_video_box').show();
                                }else{
                                    $('.goods_intro_video_box').hide();
                                }
                            }
                            $(function() {
                                <?php if($do == 'addgoods') { ?>
                                c_brandid = 1;
                                <?php } ?>
                                brandtypechange();
                            });
                        </script>
                        <?php if($_G['cache']['plugin']['aljstg']['is_aljstg'] || $_G['cache']['plugin']['aljspt']['is_aljspt'] || $_G['cache']['plugin']['aljtbk']['on']) { ?>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">商品类型</label>
                            <div class="col-sm-6 " style="line-height: 34px">
                                <label class="lb"><input type="radio" name="commodity_type" value="0" class="commodity_type" <?php if(!$goods['commodity_type'] && !$_GET['commodity_type']) { ?>checked="checked"<?php } ?>>&#26222;&#36890;&#21830;&#21697;</label>
                                <?php if($_G['cache']['plugin']['aljstg']['is_aljstg']) { ?>
                                <label class="lb"><input type="radio" name="commodity_type" value="1" class="commodity_type" <?php if($goods['commodity_type'] == 1 || ($_GET['commodity_type']==1 &&!$goods['commodity_type'])) { ?>checked="checked"<?php } ?>><?php echo $_G['cache']['plugin']['aljstg']['aljstg_name'];?>商品</label>
                                <?php } ?>
                                <?php if($_G['cache']['plugin']['aljspt']['is_aljspt']) { ?>
                                <label class="lb"><input type="radio" name="commodity_type" value="2" class="commodity_type" <?php if($goods['commodity_type'] == 2 || ($_GET['commodity_type']==2 && !$goods['commodity_type'])) { ?>checked="checked"<?php } ?>>拼团商品</label>
                                <?php } ?>
                                <?php if($_G['cache']['plugin']['aljtbk']['on']) { ?>
                                <?php include template('aljtbk:addgoods'); ?>                                <?php } ?>
                            </div>
                        </div>
                        <script>
                            $('.commodity_type').change(function() {
                                commodityType();
                            });

                            function commodityType() {
                                console.log($(".commodity_type:checked").val());
                                cdtype = $(".commodity_type:checked").val();
                                if($(".commodity_type:checked").val()=='1'){
                                    <?php if($_G['cache']['plugin']['aljstg']['is_aljstg']) { ?>
                                    <?php include template('aljstg:goods/addgoods_commodity_js'); ?>                                    <?php } ?>
                                    $(".pt_input").hide();
                                }else if($(".commodity_type:checked").val()=='2'){
                                    <?php if($_G['cache']['plugin']['aljspt']['is_aljspt']) { ?>
                                    <?php include template('aljspt:goods/addgoods_commodity_js'); ?>                                    <?php } ?>
                                    $(".pt_input").show();
                                }else{
                                    $(".collage_price").hide();
                                    $(".price1").text('当前价格');
                                    $(".price1").next().attr("placeholder","当前价格");
                                    $(".collage_num").hide();
                                    $(".starttime").hide();
                                    $(".endtime").show();
                                    $(".category").show();
                                    $("#category").html('');
                                    $(".gwurl").show();
                                    $(".pt_input").hide();
                                }
                            }
                            $(function() {
                                commodityType();
                            });
                        </script>
                        <?php } ?>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">商品名称</label>
                            <div class="col-sm-6">
                            <input class="form-control"  name="name" placeholder="商品名称" value="<?php echo $goods['name'];?>" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">商品货号</label>
                            <div class="col-sm-6">
                            <input class="form-control"  name="commodity_code" placeholder="填写唯一的商品货号" value="<?php echo $goods['commodity_code'];?>" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">商品简单描述</label>
                            <div class="col-sm-6">
                            <input class="form-control"  name="brief" placeholder="一句话描述商品" value="<?php echo $goods['brief'];?>" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">商品卖点</label>
                            <div class="col-sm-6">
                            <input class="form-control"  name="selling_point" placeholder="重要卖点介绍，多个以英文逗号隔开,前台标签展示" value="<?php echo $goods['selling_point'];?>" >
                            </div>
                        </div>
<div class="form-group">
                            <label class="col-sm-3 control-label">商品状态</label>
<div class="col-sm-6 " style="line-height: 34px">
<label class="lb"><input type="radio" name="state" value="0" class="pc" <?php if(!$goods['state']) { ?>checked="checked"<?php } ?>>上架</label>
<label class="lb"><input type="radio" name="state" value="1" class="pc" <?php if($goods['state'] == 1) { ?>checked="checked"<?php } ?>>下架</label>
</div>
                        </div>
                        <div class="form-group category" >
                            <label class="col-sm-3 control-label">商品类别</label>
                            <div class="col-sm-6 " style="line-height: 34px">
                                <label class="lb"><input type="radio" name="category" value="0" class="pc" <?php if(!$goods['category']) { ?>checked="checked"<?php } ?>>实物</label>
                                <label class="lb"><input type="radio" name="category" value="1" class="pc" <?php if($goods['category'] == 1) { ?>checked="checked"<?php } ?>>虚拟</label>
                            </div>
                        </div>
                        <div id="category"></div>
                        <div class="form-group" style="margin-bottom: 0px;">
                            <label class="col-sm-3 control-label">商品分类</label>
                            <div class="col-sm-6">
<select name="type" id="type" class="form-control" onchange="lj_type();">
<option value="">请选择</option><?php if(is_array($typelist)) foreach($typelist as $typeid => $type) { ?><option value="<?php echo $typeid;?>" <?php if($typeid==$goods['type']) { ?>selected<?php } ?>><?php echo $type['subject'];?></option>
<?php } ?>
</select>
                            </div>
                        </div>
<div name="subtype"  class="form-group" style="margin-bottom: 0px;">
                            <label class="col-sm-3 control-label"></label>
                            <div class="col-sm-6" id="type1">
<?php if($goods['subtype']) { ?>
<select name="subtype" id="subtype" class="form-control" onchange="lj_subtype();"><?php if(is_array(C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type_goods')->fetch_all_by_upid($goods['type']))) foreach(C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type_goods')->fetch_all_by_upid($goods['type']) as $typeid => $type) { ?><option value="<?php echo $typeid;?>" <?php if($typeid==$goods['subtype']) { ?>selected<?php } ?>><?php echo $type['subject'];?></option>
<?php } ?>
</select>
<?php } ?>
</div>
</div>
<div  class="form-group" style="margin-bottom: 0px;">
                            <label class="col-sm-3 control-label"></label>
                            <div class="col-sm-6" id="type2">
<?php if($goods['subtype3']) { ?>
<select name="subtype3" class="form-control"><?php if(is_array(C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type_goods')->fetch_all_by_upid($goods['subtype']))) foreach(C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type_goods')->fetch_all_by_upid($goods['subtype']) as $typeid => $type) { ?><option value="<?php echo $typeid;?>" <?php if($typeid==$goods['subtype3']) { ?>selected<?php } ?>><?php echo $type['subject'];?></option>
<?php } ?>
</select>
<?php } ?>
                            </div>
</div>
                        <div class="form-group" style="margin-bottom: 0px;">
                            <label class="col-sm-3 control-label">店内分类</label>
                            <div class="col-sm-6 brandtype">
                            <select name="btypeid" id="btypeid" class="form-control" onchange="lj_btype();">
                                <option value="">请选择</option>
                                <?php if(is_array($btype)) foreach($btype as $bt) { ?>                                <option value="<?php echo $bt['id'];?>" <?php if($bt['id']==$goods['btypeid']) { ?>selected<?php } ?>><?php echo $bt['subject'];?></option>
                                <?php } ?>
                            </select>
                            </div>
                        </div>
                        <div name="subbtypeid"  class="form-group" style="margin-bottom: 0px;">
                            <label class="col-sm-3 control-label"></label>
                            <div class="col-sm-6" id="btype1">
                            <?php if($goods['bsubtypeid']) { ?>
                            <select name="bsubtypeid" id="bsubtypeid" class="form-control" >
                                <?php $subtype = DB::fetch_all('select * from %t where bid=%d and upid=%d and type=0 ',array('aljbd_type_brand',$bid,$goods['btypeid']));?>                                <?php if(is_array($subtype)) foreach($subtype as $type) { ?>                                <option value="<?php echo $type['id'];?>" <?php if($type['id']==$goods['bsubtypeid']) { ?>selected<?php } ?>><?php echo $type['subject'];?></option>
                                <?php } ?>
                            </select>
                            <?php } ?>
                            </div>
                        </div>
                        <div class="pt_input" style="display: none">
                            <?php if($_G['cache']['plugin']['aljspt']['is_aljspt']) { ?>
                            <?php include template('aljspt:goods/addgoods_ptprice'); ?>                            <?php } ?>
                            <?php if($_G['cache']['plugin']['aljspt']['is_aljspt']) { ?>
                            <?php include template('aljspt:goods/addgoods_ptnum'); ?>                            <?php } ?>
                            <div class="form-group" >
                                <label class="col-sm-3 control-label">限同一商品规格拼团</label>
                                <div class="col-sm-6 " style="line-height: 34px">
                                    <label class="lb"><input type="radio" name="is_pt_sku" value="1" class="pc" <?php if($goods['is_pt_sku'] == 1) { ?>checked="checked"<?php } ?>>是</label>
                                    <label class="lb"><input type="radio" name="is_pt_sku" value="0" class="pc" <?php if(!$goods['is_pt_sku']) { ?>checked="checked"<?php } ?>>否</label>
                                    <div class="notic">此开关只在商品添加了规格后才会生效</div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="price1 col-sm-3 control-label">当前价格</label>
                            <div class="col-sm-6">
                            <input class="form-control price-integral" placeholder="当前价格" name="price1" value="<?php echo $goods['price1'];?>">
                            <?php if(unserialize($goods['attr_key'])) { ?>
                                <div class="notic"><a style="color:#f42424;" href="javascript:;" onclick="iframeattr(<?php echo $goods['id'];?>)">规格价格</a></div>
                            <?php } ?>
                            </div>
                            
                        </div>
                        <?php include template('aljht:admin/goods/common_goods_js'); ?>                        <div class="form-group">
                            <label class="col-sm-3 control-label">市场价格</label>
                            <div class="col-sm-6">
                            <input class="form-control"  placeholder="市场价格" name="price2" value="<?php echo $goods['price2'];?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">新人专享价格</label>
                            <div class="col-sm-6">
                            <input class="form-control" placeholder="新人专享价格" name="new_price" value="<?php echo $goods['new_price'];?>">
                            </div>
                        </div>
                        <?php if($_G['cache']['plugin']['aljtcc']) { ?>
                            <?php if($settings['is_card_price']['value']==1) { ?>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">&#20250;&#21592;&#20215;</label>
                                    <div class="col-sm-6">
                                    <input class="form-control" placeholder="&#22635;&#20889;&#20250;&#21592;&#20215;" name="card_price" value="<?php echo $goods['card_price'];?>">
                                    
                                    </div>
                                </div>
                            <?php } else { ?>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">会员卡专享折扣</label>
                                    <div class="col-sm-6">
                                    <input class="form-control" placeholder="如9.85折请填写98.5,即售价为原价的98.5%" name="card_price" value="<?php echo $goods['card_price'];?>">
                                    <div class="notic">会员卡专享折扣:如<b style="color:red;">9.85折</b>请填写<b style="color:red;">98.5</b>,即售价为原价的98.5%，支持两位小数，填写后商品售价、规格价格、阶梯价格及秒杀价格都会受此折扣影响</div>
                                    </div>
                                </div>
                            <?php } ?>
                        <?php } ?>
                        <?php if(file_exists("source/plugin/dz_3/dz_3.inc.php")) { ?>
                        <?php include template('dz_3:addgoods'); ?>                        <?php } ?>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">商品数量</label>
                            <div class="col-sm-6">
                            <input class="form-control" placeholder="商品数量" name="amount" value="<?php echo $goods['amount'];?>">
                            </div>
                        </div>
<?php if(file_exists("source/plugin/xydz/xydz.inc.php")) { include template('xydz:addgoods'); } if($_G['cache']['plugin']['aljgwc']['aljbd'] && !file_exists("source/plugin/dz_1/dz_1.inc.php")) { ?>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">运费</label>
                            <div class="col-sm-6">
                                <select name="fare_desc" id="fare_desc" class="form-control">
                                    <?php if(is_array($fare_desc)) foreach($fare_desc as $k => $v) { ?>                                    <option <?php if($goods['fare_desc'] == $k) { ?>selected<?php } ?> value="<?php echo $k;?>"><?php echo $v;?>
                                    <?php } ?>
                                    <?php if($_G['cache']['plugin']['aljmb']['is_aljmb']) { ?>
                                        <option value="3" <?php if($goods['fare_desc']=='3') { ?>selected<?php } ?>>运费模板
                                    <?php } ?>
                                    <option value="999999" <?php if($goods['fare_desc']=='999999') { ?>selected<?php } ?>>自定义邮费
                                </select>
                            </div>
                        </div>
                        
                        <?php } elseif(file_exists("source/plugin/dz_1/dz_1.inc.php")) { ?>
                        <?php include template('dz_1:addgoods'); } ?>
<div class="form-group" <?php if($goods['fare_desc']<'3') { ?>style="display:none"<?php } ?> id="fare">
<label class="col-sm-3 control-label">运费金额</label>
                            <div class="col-sm-6">
    <input type="text" class="form-control" name="fare" value="<?php echo $goods['fare'];?>" placeholder="运费金额">
                            </div>
                            <div class="col-sm-2" style="padding-top: 7px;<?php if($goods['fare_desc']<'3') { ?>display:none<?php } ?>">
                                <?php if($_G['cache']['plugin']['aljmb']['is_aljmb']) { ?>
                                    <a href="javascript:;" onclick="open_mb();">添加运费模板</a>
                                    <script>
                                        //plugin.php?id=aljmb
                                        function open_mb(){
                                            layer.open({
                                                type: 2,
                                                title: '添加运费模板',
                                                shadeClose: true,
                                                shade: false,
                                                maxmin: true, 
                                                offset: "20px",
                                                area: ['90%', '90%'],
                                                content: 'plugin.php?id=aljmb'
                                            });
                                        }
                                    </script>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="form-group" id="weight_2"></div>
                        <?php if(!file_exists("source/plugin/dz_1/dz_1.inc.php")) { ?>
                        <?php if($_G['cache']['plugin']['aljstg']) { ?>
                        <?php include template('aljstg:goods/addgoods_starttime'); ?>                        <?php } ?>
                        <div class="form-group endtime">
                            <label class="col-sm-3 control-label">到期时间</label>
                            <div class="col-sm-6">
                            <input  name="endtime" class="form-control laydate-icon" style="height: auto"  id="endtime" value="<?php if($goods['endtime']) { echo gmdate('Y-m-d',$goods['endtime']+8*3600);?><?php } ?>" placeholder="&#30041;&#31354;&#27704;&#20037;&#26377;&#25928;,<?php echo $aljhtlang['template']['addgoods_8'];?>">
                            </div>
                        </div>
                        <?php } ?>
                    <div class="form-group">
                        <div class="col-sm-3 control-label" style="padding: 0;">
                            <div class="btn btn-default btn-file" >
                                <i class="fa fa-file-image-o"></i>
                                <?php if(file_exists("source/plugin/dz_4/dz_4.inc.php")) { ?>
                                正面
                                <?php } else { ?>
                                <?php echo $aljhtlang['template']['addgoods_5'];?>
                                <?php } ?>
                                <input type="file" name="pic1" onchange="lrz_mobile('pic1',this)">
                            </div>

                            <p id="img_pic1">
                                <?php if($goods['pic1']) { ?>
                                <?php if($_GET['copy']) { ?>
                                <input type="hidden" name="pic1" value="<?php echo $goods['pic1'];?>" >
                                <?php } ?>
                                <img src="<?php echo $goods['pic1'];?>" width="100px" height="100px">
                                <?php } ?>
                            </p>
                        </div>
<div class="col-sm-6" style="padding: 0px">
                            <?php if(file_exists("source/plugin/dz_4/dz_4.inc.php")) { ?>
                            <?php $shoplogo = array('pic2','pic3','pic4','pic5','pic6','pic7','pic8','pic9','pic10','pic11','pic12');?>                            <?php } else { ?>
                            <?php $shoplogo = array('pic2','pic3','pic4','pic5');?>                            <?php } ?>

                            <?php if(is_array($shoplogo)) foreach($shoplogo as $k => $v) { ?>                            <div class="col-sm-3">

                                <div class="btn btn-default btn-file" >
                                    <i class="fa fa-file-image-o"></i>
                                    <?php if(file_exists("source/plugin/dz_4/dz_4.inc.php")) { ?>
                                        <?php if($v=='pic1') { ?>
                                        &#27491;&#38754;
                                        <?php } elseif($v=='pic2') { ?>
                                        &#27491;&#38754;1
                                        <?php } elseif($v=='pic3') { ?>
                                        &#27491;&#38754;2
                                        <?php } elseif($v=='pic4') { ?>
                                        &#27491;&#38754;3
                                        <?php } elseif($v=='pic5') { ?>
                                        &#27491;&#38754;4
                                        <?php } elseif($v=='pic6') { ?>
                                        &#32972;&#38754;1
                                        <?php } elseif($v=='pic7') { ?>
                                        &#32972;&#38754;2
                                        <?php } elseif($v=='pic8') { ?>
                                        &#32972;&#38754;3
                                        <?php } elseif($v=='pic9') { ?>
                                        &#32972;&#38754;4
                                        <?php } elseif($v=='pic10') { ?>
                                        &#20391;&#38754;1
                                        <?php } elseif($v=='pic11') { ?>
                                        &#20391;&#38754;2
                                        <?php } elseif($v=='pic12') { ?>
                                        &#32972;&#38754;
                                        <?php } ?>
                                    <?php } else { ?>
                                        <?php if($v=='pic1') { ?>
                                            <?php echo $aljhtlang['template']['addgoods_5'];?>
                                        <?php } else { ?>
                                            <?php echo $aljhtlang['template']['addgoods_6'];?>
                                        <?php } ?>
                                    <?php } ?>
                                    <input type="file" name="<?php echo $v;?>" onchange="lrz_mobile('<?php echo $v;?>',this)">
                                </div>

                            <p id="img_<?php echo $v;?>">
                                <?php if($goods[$v]) { ?>
                                    <?php if($_GET['copy']) { ?>
                                    <input type="hidden" name="<?php echo $v;?>" value="<?php echo $goods[$v];?>" >
                                    <?php } ?>
                                    <img src="<?php echo $goods[$v];?>" width="100px" height="100px">
                                    <?php if($v!='pic1') { ?>&nbsp;<input type="checkbox" name="del_logo['<?php echo $v;?>']" value="<?php echo $v;?>">删？<?php } ?>
                                <?php } ?>
                            </p>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
<?php if(!$settings['good_wurl']['value'] && !file_exists("source/plugin/dz_1/dz_1.inc.php")) { ?>
                        <div class="form-group gwurl">
                            <label class="col-sm-3 control-label">外部商品链接</label>
                            <div class="col-sm-6">
                            <input class="form-control" placeholder="外部商品链接" name="gwurl" value="<?php echo $goods['gwurl'];?>">
                            </div>
                        </div>
<?php } ?>



                        <div class="form-group div_give_integral" <?php if($vipdata['give_integral'] > 0) { ?>style="display:block;"<?php } else { ?>style="display:none;"<?php } ?>>
                            <label class="col-sm-3 control-label"><?php if($settings['is_give_integral']['value']==1) { ?>赠送积分比例<?php } else { ?>赠送积分数<?php } ?></label>
                            <div class="col-sm-6">
                                <input class="form-control give_integral"  name="give_integral" placeholder="填写整数" value="<?php echo $goods['give_integral'];?>" onblur="get_give_integral(this.value);">
                                <div class="notic"><?php if($settings['is_give_integral']['value']==1) { ?>购买该商品时赠送积分比例，最高可设置<?php } else { ?>购买该商品时赠送积分数，最高可设置<?php } ?><em id="give_integral">0</em><?php if($settings['is_give_integral']['value']==1) { ?>%<?php } else { ?>积分<?php } ?></div>
                            </div>

                        </div>

                        <div class="form-group div_pay_integral" <?php if($vipdata['pay_integral'] > 0) { ?>style="display:block;"<?php } else { ?>style="display:none;"<?php } ?>>
                            <label class="col-sm-3 control-label">积分抵扣金额比例</label>
                            <div class="col-sm-6">
                                <input class="form-control pay_integral"  name="pay_integral" placeholder="填写整数，单位：%" value="<?php echo $goods['pay_integral'];?>" onblur="parseint_integral(this.value);">
                                <div class="notic">购买该商品时最多可以使用积分抵扣的金额比例，最高可设置积分抵扣金额比例<em id="pay_integral">0</em>%</div>
                            </div>

                        </div>


                    <script>

                        $('.price-integral').change(function() {
                            priceIntegral();
                        });
                        function priceIntegral() {
                            var price_integral = $('.price-integral').val();//商品价格
                            console.log(price_integral);
                            var pay_integral = data_pay_integral;//积分付款百分比
                            var give_integral = data_give_integral;//赠送积分数量
                            console.log('333333'+pay_integral+'==='+give_integral);

                            var pay_integral_res = parseInt(pay_integral)/100*price_integral*1;
                            console.log(Math.floor(pay_integral_res)+'aaaaaa');
                            if(Math.floor(pay_integral_res)<=0){
                                pay_integral = 0;
                            }
                            var give_integral_res = parseInt(give_integral)/100*price_integral*1;
                            console.log('333333'+pay_integral_res+'==='+give_integral_res);
                            $('#pay_integral').html(Math.floor(pay_integral));
                            <?php if($settings['is_give_integral']['value']==1) { ?>
                            $('#give_integral').html(Math.floor(give_integral));
                            <?php } else { ?>
                            $('#give_integral').html(Math.floor(give_integral_res));
                            <?php } ?>
                        }

                        function get_give_integral(val)
                        {
                            var val = Number(val);
                            if(val > 0){
                                var give_integral = Number($("#give_integral").html());
                                if(val > give_integral){
                                    <?php if($settings['is_give_integral']['value']==1) { ?>
                                    alert("赠送积分比例最多设置不能超过" +give_integral+"%");
                                    <?php } else { ?>
                                    alert("赠送积分数最高只能设置" +give_integral+"积分范围内");
                                    <?php } ?>
                                    var val = give_integral;
                                }
                            }
                            else
                            {
                                val = 0;
                            }
                            $('.give_integral').val(val);
                        }


                        function parseint_integral(val) {
                            var val = Number(val);
                            if(val > 0){
                                var pay_integral = Number($("#pay_integral").html());

                                if(val > pay_integral){
                                    alert("积分抵扣金额比例最高只能设置" +pay_integral+"%范围内");
                                    var val = pay_integral;
                                }
                            }else{
                                val = 0;
                            }
                            $('.pay_integral').val(val);
                        }


                        $(function() {
                            priceIntegral();
                        });

                    </script>

                    <?php if($service_label) { ?>
                    <div class="form-group goodstype" >
                        <label class="col-sm-3 control-label">商品服务</label>
                        <div class="col-sm-6">
                            <?php if(is_array($service_label)) foreach($service_label as $slv) { ?>                            <label class="control-label" style="margin-right: 10px"><input type=checkbox name=service_label[]  value="<?php echo $slv['id'];?>" <?php if(in_array($slv['id'],explode(',',$goods['service_label'])) ) { ?>checked<?php } ?>>&nbsp;<?php echo $slv['title'];?></label>
                            <?php } ?>
                        </div>
                    </div>
                    <?php } ?>
                    <div class="form-group " >
                        <label class="col-sm-3 control-label">限购</label>
                        <div class="col-sm-6">
                            <input class="form-control "  name="limit_amount" placeholder="单位：个" value="<?php echo $goods['limit_amount'];?>">
                        </div>

                    </div>
                    <div class="form-group distribution" >
                        <label class="col-sm-3 control-label">是否开启分销</label>
                        <div class="col-sm-6">
                            <label class="control-label"><input type="radio" name="is_distribution" value="1"  <?php if($goods['is_distribution'] == 1) { ?>checked="checked"<?php } ?>>&nbsp;是</label>
                            <label class="control-label"><input type="radio" name="is_distribution" value="0"  <?php if($goods['is_distribution'] == 0) { ?>checked="checked"<?php } ?>>&nbsp;否</label>
                        </div>

                    </div>
                    <div class="form-group distribution" >
                        <label class="col-sm-3 control-label">分销佣金比例</label>
                        <div class="col-sm-6">
                            <input class="form-control "  name="dis_commission" placeholder="填写0~100之间的有效数字" value="<?php echo $goods['dis_commission'];?>">
                            <div class="notic">填写0~100之间的有效数字，用于支付平台分销商提成（分销佣金）计算，<b style="color:#f42424">如：商品当前价格10元，分销佣金比例10，那分销佣金就是1元，扣除分销佣金您可入账9元</b></div>
                        </div>

                    </div>
                    <div class="video_box" style="display: none">
                    <?php if($u20181224) { ?>
                        <?php if($_G['cache']['plugin']['aljsp']['is_sp']) { ?>
                        <div class="form-group " >
                            <label class="col-sm-3 control-label">商品全景VR</label>
                            <div class="col-sm-6">
                                <input class="form-control "  name="vr_url" placeholder="全景VR链接" value="<?php echo $goods['vr_url'];?>">
                            </div>
                        </div>
                        <div class="form-group " >
                            <label class="col-sm-3 control-label">商品视频</label>
                            <div class="col-sm-6">
                                <input class="form-control "  name="video_url" placeholder="填写优酷、腾讯、爱奇艺等网页链接" value="<?php echo $goods['video_url'];?>">
                            </div>
                        </div>
                        <?php } ?>
                        <?php if($_G['cache']['plugin']['aljoss']['Access_Key']) { ?>
                        
                        <div class="form-group " >
                            <label class="col-sm-3 control-label">上传商品视频</label>
                            <div class="col-sm-6">

                                <div class="weui-cell">
                                    <div class="weui-cell__bd">
                                        <div class="weui-uploader">
                                            <div class="weui-uploader__bd">
                                                <ul class="weui-uploader__files" id="ossfile">
                                                    <?php if($goods['video_path']) { ?>
                                                    <li class="weui-uploader__file weui-uploader__file_status img_list" style="width:180px">
                                                        <video controls="controls" class="vr_iframe" style="height:80px;width:180px">
                                                            <source src="<?php echo $goods['video_path'];?>" type="video/mp4">
                                                        </video>
                                                        
                                                    </li>
                                                    <li class="weui-uploader__file  img_list" >
                                                        <label style="padding: 25px 10px;overflow: hidden;display: block;">
                                                            <input type="hidden" name="video_path" value="<?php echo $goods['video_path'];?>">
                                                            <input type="checkbox" name="del_video" value="1">删？
                                                        </label>
                                                    </li>
                                                    <?php } ?>

                                                </ul>
                                                <div class="weui-uploader__input-box" >
                                                    <span type=file class="weui-uploader__input__video" id="selectfiles" ></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <script src="source/plugin/aljoss/OSS/js/lib/plupload-2.1.2/js/plupload.full.min.js" type="text/javascript"></script>
                                <?php $oss_domain = $_G['cache']['plugin']['aljoss']['cdn_domain'] ? $_G['cache']['plugin']['aljoss']['cdn_domain'] : $_G['cache']['plugin']['aljoss']['domain']?>                                <script type="text/javascript">
                                    var domain_url = '<?php echo $oss_domain;?>';
                                    var video_mb = '<?php echo $_G['cache']['plugin']['aljoss']['video_mb'];?>';
                                </script>
                                <script src="source/plugin/aljoss/OSS/js/upload.js" type="text/javascript"></script>
                                <div class="notic">显示顺序商品上传视频、全景VR、商品视频链接，上传视频大小不得超过<?php echo $_G['cache']['plugin']['aljoss']['video_mb'];?>M</div>
                            </div>

                        </div>
                        <?php } ?>
                    <?php } ?>
                    </div>
                    <style>
                        .table_div {
                            border: 1px solid #dcdcdc;
                        }
                        .table_heng td.first_td {
                            width: 56px;
                            background: #fff5f9;
                            border-right: 1px solid #dcdcdc;
                            text-align: center;
                            color: #000;
                        }
                        .table_heng td {
                            padding: 9px 0;
                            width: 100px;
                            text-align: center;
                            font-size: 12px;
                        }
                        .table_heng .first_tr td {
                            border-bottom: 1px solid #dcdcdc;
                            padding: 9px 0;

                        }
                        .table_heng td.last_td .addTd {
                            display: block;
                            width: 20px;
                            height: 20px;
                            font-size: 20px;
                            margin: 0 auto;
                        }
                        .w50{width:70px !important;}
                        .table_heng td.last_td {
                            width: 48px;
                            border-left: 1px solid #dcdcdc;
                        }
                        .mr50{margin-right: 50px;}
                        .dis-inline{
                            display:inline-block;
                        }
                    </style>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">阶梯价格</label>
                        <div class="col-sm-9">
                            <label class="control-label mr50"><input type="radio" class="is_volume" name="is_volume" value="2"  <?php if($goods['is_volume'] == 2) { ?>checked="checked"<?php } ?>>&nbsp;是(带规格)</label>
                            <label class="control-label mr50"><input type="radio" class="is_volume" name="is_volume" value="1"  <?php if($goods['is_volume'] == 1) { ?>checked="checked"<?php } ?>>&nbsp;是(不带规格)</label>
                            <label class="control-label mr50"><input type="radio" class="is_volume" name="is_volume" value="0"  <?php if($goods['is_volume'] == 0) { ?>checked="checked"<?php } ?>>&nbsp;否</label>
                            <div class="special_div" ectype="volumeNumber" data-number="100" style="margin-top:20px;display: none;">
                                <table class="table_div table_heng">
                                    <tbody>
                                    <?php if($volume_price) { ?>
                                    <tr class="first_tr">
                                        <td class="first_td">数量</td>
                                        <?php if(is_array($volume_price)) foreach($volume_price as $num_val) { ?>                                        <td>
                                            <input type="text" name="volume_number[]" value="<?php echo $num_val['volume_number'];?>" class="form-control dis-inline w50 td_num">
                                            <input type="hidden" name="v_id[]" value="<?php echo $num_val['id'];?>" class="text w50" autocomplete="off">
                                        </td>
                                        <?php } ?>
                                        <td class="last_td" rowspan="3"><a href="javascript:void(0);" class="addTd  fa-plus-square fa fa-fw " data-sku="" onclick="add_clonetd(this);"></a></td>
                                    </tr>
                                    <tr class="first_tr">
                                        <td class="first_td">价格</td>


                                        <?php if(is_array($volume_price)) foreach($volume_price as $num_val) { ?>                                        <td><input type="text" name="volume_price[]" value="<?php echo $num_val['volume_price'];?>" class="form-control dis-inline w50"></td>
                                        <?php } ?>
                                    </tr>
                                    
                                    <tr class="first_tr is_pt_show">
                                        <td class="first_td">拼团价</td>
                                        <?php if(is_array($volume_price)) foreach($volume_price as $num_val) { ?>                                        <td><input type="text" name="volume_price_pt[]" value="<?php echo $num_val['volume_price_pt'];?>" class="form-control dis-inline w50"></td>
                                        <?php } ?>
                                    </tr>
                                    
                                    <tr>
                                        <td class="first_td">操作</td>
                                        <?php if(is_array($volume_price)) foreach($volume_price as $num_val) { ?>                                        <td><a href="javascript:;" class="btn btn-primary w50 remove_volume" data-id="<?php echo $num_val['id'];?>" data-type='del_volume' ectype="remove_volume">删除</a></td>
                                        <?php } ?>
                                    </tr>
                                    <?php } else { ?>
                                    <tr class="first_tr">
                                        <td class="first_td">数量</td>
                                        <td>
                                            <input type="text" name="volume_number[]" value="<?php echo $num_val['volume_number'];?>" class="form-control dis-inline w50 td_num">
                                            <input type="hidden" name="v_id[]" value="<?php echo $num_val['id'];?>" class="text w50" autocomplete="off">
                                        </td>
                                        <td class="last_td" rowspan="3"><a href="javascript:void(0);" class="addTd  fa-plus-square fa fa-fw " data-sku="" onclick="add_clonetd(this);"></a></td>
                                    </tr>
                                    <tr class="first_tr">
                                        <td class="first_td">价格</td>
                                        <td><input type="text" name="volume_price[]" value="<?php echo $num_val['volume_price'];?>" class="form-control dis-inline w50"></td>
                                    </tr>
                                    
                                    <tr class="first_tr is_pt_show">
                                        <td class="first_td">拼团价</td>
                                        <td><input type="text" name="volume_price_pt[<?php echo $kvid;?>]" value="" class="form-control dis-inline w50"></td>
                                    </tr>
                                    
                                    <tr>
                                        <td class="first_td">操作</td>

                                        <td><a href="javascript:;" class="btn btn-primary w50" data-id="<?php echo $num_val['id'];?>" data-type='del_volume' ectype="remove_volume">删除</a></td>

                                    </tr>
                                    <?php } ?>
                                    </tbody></table>
                            </div>
                            <div class="notic">删除阶梯价格成功会<span style="color:#f42424;">实时生效</span>哦，带商品规格商品请到商品规格中添加阶梯价格,不带商品规格的直接本页面操作</div>
                        </div>

                    </div>
                    <script>
                        $('.is_volume').change(function() {
                            isVolumeType();
                        });
                        function isVolumeType() {
                            if(cdtype == 2){
                                $('.last_td').attr('rowspan','4');
                                $('.is_pt_show').show();
                            }else{
                                $('.is_pt_show').hide();
                                $('.last_td').attr('rowspan','3');
                            }
                            if($(".is_volume:checked").val()=='1'){
                                $(".special_div").show();
                            }else{
                                $(".special_div").hide();
                            }
                        }
                        $(function() {
                            isVolumeType();
                        });
                    </script>
                    <?php include template('aljht:admin/goods/volume'); ?>                    <div class="form-group" id="weight_1">
                        <label class="col-sm-3 control-label">重量</label>
                        <div class="col-sm-6">
                        <input class="form-control" placeholder="运费模板按重量计算时必须填写" name="weight" value="<?php echo $goods['weight'];?>">
                        </div>
                        <div class="col-sm-3" style="padding-top: 7px;">KG</div>
                    </div>
                    <div class="goods_intro_video_box" style="display: none">
                        <?php if($u20181224) { ?>
                            <?php if($_G['cache']['plugin']['aljoss']['Access_Key']) { ?>
                            
                            <div class="form-group " >
                                <label class="col-sm-3 control-label">详情视频</label>
                                <div class="col-sm-6">
    
                                    <div class="weui-cell">
                                        <div class="weui-cell__bd">
                                            <div class="weui-uploader">
                                                <div class="weui-uploader__bd">
                                                    <ul class="weui-uploader__files" id="ossfile_intro">
                                                        <?php if($goods['intro_video_path']) { ?>
                                                        <li class="weui-uploader__file weui-uploader__file_status img_list" style="width:180px">
                                                            <video controls="controls" class="vr_iframe" style="height:80px;width:180px">
                                                                <source src="<?php echo $goods['intro_video_path'];?>" type="video/mp4">
                                                            </video>
                                                            <img src="source/plugin/aljoss/img/del.png" class="del_video" onclick="DelVideo()"/>
                                                            <input type="hidden" name="intro_video_path" value="<?php echo $goods['intro_video_path'];?>">
                                                        </li>
                                                        <?php } ?>
    
                                                    </ul>
                                                    <div class="weui-uploader__input-box" >
                                                        <span type=file class="weui-uploader__input__video" id="selectfiles_intro" ></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <script src="source/plugin/aljoss/OSS/js/lib/plupload-2.1.2/js/plupload.full.min.js" type="text/javascript"></script>
                                    <?php $oss_domain = $_G['cache']['plugin']['aljoss']['cdn_domain'] ? $_G['cache']['plugin']['aljoss']['cdn_domain'] : $_G['cache']['plugin']['aljoss']['domain']?>                                    <script type="text/javascript">
                                        var domain_url = '<?php echo $oss_domain;?>';
                                        var video_mb = '<?php echo $_G['cache']['plugin']['aljoss']['video_mb'];?>';
                                        var input_video_name = 'intro_video_path';
                                    </script>
                                    <script src="source/plugin/aljoss/OSS/js/upload_intro.js" type="text/javascript"></script>
                                </div>
    
                            </div>
                            <?php } ?>
                        <?php } ?>
                        </div>
                    <div class="form-group">
                            <label class="col-sm-3 control-label">商品介绍</label>
                        <div class="col-sm-6">
                    <textarea name="intro"  id="intro" style="height:500px;"><?php echo $goods['intro'];?></textarea>
                        </div>
                        </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label"></label>
                        <div class="col-sm-6" style="text-align: center;">
                            <input type="submit" class="btn btn-submit btn-primary" value="<?php echo $aljhtlang['template']['addgoods_7'];?>" style="width:40%;margin-top:30px">
                        </div>
                    </div>
                    <!-- /.box-body -->
                    <!-- /. box -->
            <!-- /.col -->
            </form>
        </div>
        <!-- /.row -->
    </section>
</div>
<script src="source/plugin/<?php echo $pluginid_aljbd;?>/js/lrz.mobile.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="source/plugin/<?php echo $pluginid;?>/js/combo.select.css">
<script src="source/plugin/<?php echo $pluginid;?>/js/jquery.combo.select.js" type="text/javascript"></script><?php include template('aljht:admin/common_tips_js'); ?><script>
$(function() {
    $('select').comboSelect();
    fare_val();
});
$('#fare_desc').change(function() {
    fare_val();
});
var fare = parseFloat('<?php echo $goods['fare'];?>');

function fare_val(){
    var f_input = '<input type="text" class="form-control" name="fare" value="<?php echo $goods['fare'];?>" placeholder="运费金额">';
    var f_select = '';
if($("#fare_desc").val()=='999999'){
        $("#fare").show();
        $("#fare").find('.col-sm-6').html(f_input);
        $("#fare").find('.control-label').html('运费金额');
        $("#fare").find('.col-sm-2').hide();
}else if($("#fare_desc").val()=='3'){
        
        $.post('plugin.php?id=aljbd&act=addgoods&op=mb&do=ajax',{'bid':$('.brandid option:selected').val()},function(data){
            console.log(data);
            if(data != 1){
                f_select = '<select name="fare" class="form-control">';
                for(var key in data){
                    var sel = '';
                    if(data[key].id == fare){
                        sel = 'selected';
                    }
                    f_select += '<option value="'+data[key].id+'" '+sel+'>'+data[key].title;
                }
                f_select += '</select>';
                $("#fare").show();
                $("#fare").find('.col-sm-6').html(f_select);
                $("#fare").find('.control-label').html('选择运费模板');
                $("#fare").find('.col-sm-2').show();
            }else{
                $("#fare").show();
                $("#fare").find('.col-sm-6').html(f_select);
                $("#fare").find('.control-label').html('选择运费模板');
                $("#fare").find('.col-sm-2').show();
            }
        },'json');
        
        $('#weight_2').html($('#weight_1').html());
        $('#weight_1').html('');
    }else{
$("#fare").hide();
}
}
laydate.render({
    elem: '#endtime'
    ,type: 'datetime'
});
<?php if($_G['cache']['plugin']['aljstg']['is_aljstg']) { ?>
laydate.render({
    elem: '#starttime'
    ,type: 'datetime'
});
<?php } ?>
</script>
<script>
    function lj_btype(){
        var r = $('#btypeid').val();
        if($('.brandid option:selected').val()) {
            var bid = $('.brandid option:selected').val();
        }else{
            var bid = '<?php echo $bid;?>';
        }
        $("#btype1").html('<div class="form-group" style="text-align: center;"><img src="static/image/common/loading.gif" /></div>');
        $.post('plugin.php?id=<?php echo $pluginid;?>&act=gettype&do=btype<?php echo $urlmod;?>',{"upid":r,'bid':bid},function(data){
            if(data){
                $("#btype1").html(data);
            }else{
                $("#btype1").html('');
            }
        });
    }
function lj_type(){
var r = $('#type').val();
$("#type1").html('<div class="form-group" style="text-align: center;"><img src="static/image/common/loading.gif" /></div>');
$("#type2").html('');
$.post('plugin.php?id=<?php echo $pluginid;?>&act=gettype&do=goods',{"upid":r},function(data){
if(data){
$("#type1").html(data);
}else{
$("#type1").html('');
}
});
}
function lj_subtype(){
var r = $('#subtype').val();
$("#type2").html('<div class="form-group" style="text-align: center;"><img src="static/image/common/loading.gif" /><div>');
$.post('plugin.php?id=<?php echo $pluginid;?>&act=gettype&do=goods',{"upid":r,"op":'subtype'},function(data){
if(data){
$("#type2").html(data);
}else{
$("#type2").html('');
}
});
}

    $('.btn-submit').click(function(){
        
        $('#sign').val($(this).attr('data-id'));
        layer.msg('<?php echo $aljhtlang['js']['brand_9'];?>', {icon: 16});
        checkhHtml5();
        return false;
    });
    $(function () {
        //Enable iCheck plugin for checkboxes
        //iCheck for checkbox and radio inputs
        $('.mailbox-messages input[type="checkbox"]').iCheck({
            checkboxClass: 'icheckbox_flat-blue',
            radioClass: 'iradio_flat-blue'
        });

        //Enable check and uncheck all functionality
        $(".checkbox-toggle").click(function () {
            var clicks = $(this).data('clicks');
            if (clicks) {
                //Uncheck all checkboxes
                $(".mailbox-messages input[type='checkbox']").iCheck("uncheck");
                $(".fa", this).removeClass("fa-check-square-o").addClass('fa-square-o');
            } else {
                //Check all checkboxes
                $(".mailbox-messages input[type='checkbox']").iCheck("check");
                $(".fa", this).removeClass("fa-square-o").addClass('fa-check-square-o');
            }
            $(this).data("clicks", !clicks);
        });

        //Handle starring for glyphicon and font awesome
        $(".mailbox-star").click(function (e) {
            e.preventDefault();
            //detect type
            var thisstar = $(this).find("a > i");
            var glyph = thisstar.hasClass("glyphicon");
            var fa = thisstar.hasClass("fa");

            //Switch states
            if (glyph) {
                thisstar.toggleClass("glyphicon-star");
                thisstar.toggleClass("glyphicon-star-empty");
            }

            if (fa) {
                thisstar.toggleClass("fa-star");
                thisstar.toggleClass("fa-star-o");
            }
        });
    });

</script><?php include template('aljht:admin/img_js'); include template('aljht:admin/footer'); ?>