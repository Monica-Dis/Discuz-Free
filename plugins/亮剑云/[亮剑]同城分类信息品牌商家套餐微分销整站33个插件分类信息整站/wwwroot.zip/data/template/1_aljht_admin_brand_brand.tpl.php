<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template('aljht:admin/iframe_header_common'); ?><div class="content-wrapper">
    <?php if($_GET['ajax'] != 'yes') { ?>
    <section class="content-header">
        <h1>
            <?php echo $aljhtlang['template']['brand_1'];?>
            <small><?php echo $aljhtlang['template']['brand_2'];?><?php echo $num;?><?php echo $aljhtlang['template']['brand_3'];?>
<?php if($brandnum['brand'] && $brandnum['brand'] != $checksign && !$administrators && $yhzqx) { ?> (<b style="color:red;">您目前所有用户组：<?php echo $brandnum['grouptitle'];?>，允许发布商家个数：<?php echo $brandnum['brand'];?> 个</b>)<?php } ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo $index_url;?>"><i class="fa fa-dashboard"></i> <?php echo $aljhtlang['template']['brand_31'];?></a></li>
            <li><a href="plugin.php?id=aljht&amp;act=admin"><?php echo $aljhtlang['template']['brand_32'];?></a></li>
            <li class="active"><?php echo $aljhtlang['template']['brand_1'];?></li>
        </ol>
    </section>
    <?php } ?>
    <section class="content">
        <?php if($administrators) { ?>
        <div class="callout callout-info" style="background-color: #ffffff !important;">
            <div class="row" style="color: #333 !important;">
                <div class="col-md-12">

                    <div style="padding-bottom: 10px"><span class="fa fa-volume-up" style="margin-right: 5px;color:#0097bc;"></span>排序规则，先按推荐排再按排序排，排序<?php if($settings['brandlistorder']['value'] == 1) { ?>越大<?php } else { ?>越小<?php } ?>越靠前</div>
                    <div style="padding-bottom: 10px"><span class="fa fa-volume-up" style="margin-right: 5px;color:#0097bc;"></span>修改排序直接修改对应值后点击修改按钮提交</div>
                    <div style="padding-bottom: 10px"><span class="fa fa-volume-up" style="margin-right: 5px;color:#0097bc;"></span>其它操作需要点击复选框后选择对应的操作按钮点击提交才会生效</div>
                    <div style="padding-bottom: 10px"><span class="fa fa-volume-up" style="margin-right: 5px;color:#0097bc;"></span><b>审核商家时通过不通过均可选填备注，填写后备注会一并站内通过用户</b></div>

                </div>
            </div>
        </div>
        <?php } ?>
        <div class="row"><?php include template('aljht:admin/brand/brand_status'); ?>            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo $aljhtlang['template']['brand_6'];?></h3>

                        <div class="box-tools pull-right">
                            <div class="has-feedback">
                                <input type="text" id="search" value="<?php echo $_GET['search'];?>" class="form-control input-sm" placeholder="<?php echo $aljhtlang['template']['brand_7'];?>" onkeypress="EnterPress(event)" onkeydown="EnterPress()">
                                <div class="glyphicon glyphicon-search form-control-feedback" style="pointer-events: visible;" onclick="location.href='plugin.php?id=aljht&act=admin&op=brand&do=<?php echo $do;?><?php echo $urlmod;?>&search='+$('#search').val()"></div>
                            </div>
                        </div>
                        <!-- /.box-tools -->
                    </div>
                    <?php if(!$settings['is_one_brand']['value']==1 || ($settings['is_one_brand']['value']==1 && $num < 1) || $administrators) { ?>
                    <div class="box-footer" >
                        <a href="plugin.php?id=aljht&amp;act=admin&amp;op=brand&amp;do=adddp<?php echo $urlmod;?>" class="btn btn-primary mr10"><i class="fa fa-fw fa-plus"></i><?php echo $aljhtlang['template']['brand_4'];?></a>
                    </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <div class="box-body no-padding">
                        <div class="table-responsive mailbox-messages" >
                            <iframe style="display:none;" name="submitiframe"></iframe>
                            <form name="cpform" id="admingoodssubmit" method="post" autocomplete="off" action="plugin.php?id=aljht&amp;act=admin&amp;op=brand<?php echo $urlmod;?>" target="submitiframe">
                                <input type="hidden"  value="0" name="sign" id="sign">
                                <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>">
                            <table class="table table-hover table-striped">
                                <tbody>
                                <tr>
                                    <th></th>
                                    <th>商家ID<br/><?php echo $aljhtlang['template']['brand_9'];?></th>
                                    <th colspan="2"><?php echo $aljhtlang['template']['brand_8'];?></th>
                                    <th><?php echo $aljhtlang['template']['brand_10'];?><br/><?php echo $aljhtlang['template']['brand_11'];?></th>
                                    <th>数量</th>
                                    <th><?php echo $aljhtlang['template']['brand_12'];?></th>
                                    <?php if($administrators) { ?><th><?php echo $aljhtlang['template']['brand_13'];?></th><?php } ?>
                                    <?php if($do == 'no' || $do == 'lose') { ?>
                                    <th>备注</th>
                                    <?php } ?>
                                    <th ><?php echo $aljhtlang['template']['brand_14'];?></th>
                                </tr>
                                <?php if(is_array($bdlist)) foreach($bdlist as $bd) { ?>                                <tr>
                                    <td><input type="checkbox" name="delete[<?php echo $bd['id'];?>]" value="<?php echo $bd['id'];?>"></td>
                                    <td><?php echo $bd['id'];?><br/><?php echo $bd['username'];?></td>
                                    <td class="layer-photos-demo"><img src="<?php echo $bd['logo'];?>" layer-src="<?php echo $bd['logo'];?>" style="max-width: 60px;max-height: 60px;vertical-align: middle;"></td>
                                    <td class="mailbox-name" style="max-width:300px;">
                                        <a href="plugin.php?id=aljbd&amp;act=view&amp;bid=<?php echo $bd['id'];?>" target="_blank"><?php echo dhtmlspecialchars($bd['name'])?></a>
                                        <p class="weui-media-box__desc" style="margin-top: 10px">
                                        <?php if($attestations[$bd['id']]['sign']) { ?><img title="认证店铺" class="attes_logo" src="<?php echo $settings['attes_logo']['value'];?>"><?php } ?>
                                        <?php if($_G['cache']['plugin']['aljbzj']['is_aljbzj']) { ?>

                                        <?php if($bzjs[$bd['id']]['price']>0) { ?><img class="attes_logo" src="<?php echo $_G['cache']['plugin']['aljbzj']['bond_logo'];?>" ><?php } ?>
                                        <?php } ?>
                                        <?php if($bd['recommend']) { ?>
                                        <span class="label label-primary"><?php echo $aljhtlang['template']['brand_15'];?></span>
                                        <?php } ?>
                                        <?php if($bd['label']) { ?>
                                        <span class="label label-primary" style="background-color: #f42424 !important;color: #fff !important"><?php echo $bd['label'];?></span>
                                        <?php } ?>
                                        </p>
                                        <?php if($aljbd_groups && $bd['vipid']>0) { ?>
                                        <p class="weui-media-box__desc" style="margin-top: 10px">
                                            <?php echo $vipinfos[$bd['vipid']]['title'];?>&nbsp;<?php echo $bd['vipendtimes'];?>
                                        </p>
                                        <?php } ?>
                                    </td>
                                    <td class="mailbox-subject"><?php echo $typelist[$bd['type']]['subject'];?><br/><?php echo $rlist[$bd['region']]['name'];?>
                                    </td>
                                    <td class="mailbox-subject">
                                        <a href="plugin.php?id=aljht&amp;act=admin&amp;op=goods&amp;bid=<?php echo $bd['id'];?>&amp;b=1<?php echo $urlmod;?>">商品(<span style="color: red;"><?php echo intval($goodscounts[$bd['id']]['g_num'])?></span>)</a><br/>
                                        <a href="plugin.php?id=aljht&amp;act=admin&amp;op=notice&amp;bid=<?php echo $bd['id'];?>&amp;b=1<?php echo $urlmod;?>">活动(<span style="color: red;"><?php echo intval($noticecounts[$bd['id']]['n_num'])?></span>)</a><br/>
                                        <a href="plugin.php?id=aljht&amp;act=admin&amp;op=consume&amp;bid=<?php echo $bd['id'];?>&amp;b=1<?php echo $urlmod;?>">优惠券(<span style="color: red;"><?php echo intval($consumecounts[$bd['id']]['c_num'])?></span>)</a><br/>
                                        <a href="plugin.php?id=aljht&amp;act=admin&amp;op=videolist&amp;bid=<?php echo $bd['id'];?>&amp;b=1<?php echo $urlmod;?>">视频(<span style="color: red;"><?php echo intval($videocounts[$bd['id']]['v_num'])?></span>)</a><br/>
                                        <a href="plugin.php?id=aljht&amp;act=admin&amp;op=album&amp;bid=<?php echo $bd['id'];?>&amp;b=1<?php echo $urlmod;?>">相册(<span style="color: red;"><?php echo intval($albumcounts[$bd['id']]['a_num'])?></span>)</a><br/>
                                        <?php if($administrators) { ?>
                                        <a href="plugin.php?id=aljht&amp;act=admin&amp;op=brand&amp;do=reply&amp;ajax=yes&amp;bid=<?php echo $bd['id'];?>&amp;b=1<?php echo $urlmod;?>">评论(<span style="color: red;"><?php echo intval($replycounts[$bd['id']]['r_num'])?></span>)</a><br/>
                                        <?php } ?>
                                        
                                    </td>
                                    <td class="mailbox-subject"><?php echo dgmdate($bd['dateline']);?>                                    </td>
<?php if($administrators) { ?>
                                    <td>
                                        <input type="text" class="form-control" value="<?php if($bd['displayorder']) { ?><?php echo $bd['displayorder'];?><?php } else { ?>0<?php } ?>" name="displayorder[<?php echo $bd['id'];?>]" style="width:55px;">
                                    </td>
<?php } ?>
                                    <?php if($do == 'no' || $do == 'lose') { ?>
                                    <td>
                                        <?php if($administrators) { ?>
                                        <textarea name="reason[<?php echo $bd['id'];?>]" class="form-control"><?php echo $bd['reason'];?></textarea>
                                        <?php } else { ?>
                                        <?php echo $bd['reason'];?>
                                        <?php } ?>
                                    </td>
                                    <?php } ?>
                                    <td class="mailbox-attachment" style="max-width:300px;">
 
  

                                        <?php if($bd['status'] == 1) { ?>
                                            <a class="edit_btn" href="plugin.php?id=aljht&amp;act=admin&amp;op=brand&amp;do=edit&amp;bid=<?php echo $bd['id'];?><?php echo $urlmod;?>"><?php echo $aljhtlang['template']['brand_16'];?></a>
                                            <?php if(file_exists('source/plugin/aljbd/template/com/commentlist.htm')) { ?>
                                                <a class="edit_btn" href="javascript:;" onclick="iframereply(<?php echo $bd['id'];?>)"><?php echo $aljhtlang['template']['brand_17'];?></a>
                                            <?php } ?>
                                            <?php if(file_exists('source/plugin/aljbd/template/com/iwantclaim.htm')) { ?>
                                                <a class="edit_btn" href="javascript:;" onclick="iwantclaim(<?php echo $bd['id'];?>)"><font><?php echo $aljhtlang['template']['brand_18'];?></font></a>
                                            <?php } ?>

                                            <a class="edit_btn" href="plugin.php?id=aljht&amp;act=admin&amp;op=attestation&amp;do=addattestation&amp;bid=<?php echo $bd['id'];?><?php echo $urlmod;?>"><?php if($attestations[$bd['id']]['sign']) { ?><?php echo $aljhtlang['template']['brand_19'];?><?php } else { ?><?php echo $aljhtlang['template']['brand_20'];?><?php } ?></a>
                                            <?php if($_G['cache']['plugin']['aljbzj']['is_aljbzj']) { ?>
                                            <a class="edit_btn" href="javascript:;" onclick="iframebood(<?php echo $bd['id'];?>)">缴纳保证金</a>
                                            <?php } ?>
                                            <?php if(($vipinfos[$bd['vipid']]['store_authority'] && in_array('brand_diy',$vipinfos[$bd['vipid']]['store_authority'])) || ($administrators && $_G['cache']['plugin']['aljdd'])) { ?>
                                                <?php if($administrators) { ?>
                                                <a class="edit_btn" href="plugin.php?id=aljdiy&amp;c=page&amp;a=list_index&amp;ajax=yes&amp;type=1&amp;brand_id=<?php echo $bd['id'];?>" >店铺DIY</a>
                                                <?php } else { ?>
                                                <a class="edit_btn" href="plugin.php?id=aljht&amp;act=iframe<?php echo $urlmod;?>&amp;iframe_id=100000&amp;iframe_url=plugin.php?id=aljdiy%26c=page%26a=list_index%26ajax=yes%26type=1%26brand_id=<?php echo $bd['id'];?>" >店铺DIY</a>
                                                <?php } ?>
                                            <?php } ?>
                                        <?php if(!$settings['close_goods']['value']) { ?>

                                            <a class="edit_btn" href="plugin.php?id=aljht&amp;act=admin&amp;op=goods&amp;do=addgoods&amp;bid=<?php echo $bd['id'];?><?php echo $urlmod;?>">添加商品</a>

                                        <?php } ?>
                                        <?php if(!$settings['close_notice']['value']) { ?>

                                            <a class="edit_btn" href="plugin.php?id=aljht&amp;act=admin&amp;op=notice&amp;do=addnotice&amp;bid=<?php echo $bd['id'];?><?php echo $urlmod;?>">添加活动</a>

                                        <?php } ?>
                                        <?php if(!$settings['close_consume']['value']) { ?>

                                            <a class="edit_btn" href="plugin.php?id=aljht&amp;act=admin&amp;op=consume&amp;do=addconsume&amp;bid=<?php echo $bd['id'];?><?php echo $urlmod;?>">添加优惠券</a>

                                        <?php } ?>
                                        <?php if(!$settings['close_album']['value']) { ?>

                                            <a class="edit_btn" href="plugin.php?id=aljht&amp;act=admin&amp;op=album&amp;do=addalbum<?php echo $urlmod;?>&amp;&amp;bid=<?php echo $bd['id'];?>">添加相册</a>

                                        <?php } ?>


                                            <a class="edit_btn" href="plugin.php?id=aljht&amp;act=admin&amp;op=pagelist&amp;do=addpagelist&amp;bid=<?php echo $bd['id'];?><?php echo $urlmod;?>">添加菜单</a>

                                            <a class="edit_btn" href="javascript:;" onclick="iframebtype(<?php echo $bd['id'];?>)">添加店铺分类</a>

                                        <?php } elseif($bd['status'] == 2) { ?>
                                        <a class="edit_btn" href="plugin.php?id=aljht&amp;act=admin&amp;op=brand&amp;do=edit&amp;bid=<?php echo $bd['id'];?><?php echo $urlmod;?>"><?php echo $aljhtlang['template']['brand_16'];?></a>
                                        <a href="plugin.php?id=aljbdx&amp;act=pay&amp;bid=<?php echo $bd['id'];?>&amp;vipid=<?php echo $bd['vipid'];?>">
                                            <span>去支付</span>
                                        </a>
                                        <?php } else { ?>
                                        <a href="plugin.php?id=aljht&amp;act=admin&amp;op=brand&amp;do=edit&amp;bid=<?php echo $bd['id'];?><?php echo $urlmod;?>"><?php echo $aljhtlang['template']['brand_16'];?></a>
                                        <?php } ?>
</td>
                                </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                            <!-- /.table -->
                        </div>
                        <!-- /.mail-box-messages -->
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer no-padding">
                        <div class="mailbox-controls">
                            <?php if($settings['is_brand_del']['value']==1 || $administrators) { ?>
                            <button type="button" class="btn btn-default btn-sm checkbox-toggle"><i class="fa fa-square-o"></i>
                            </button>
                            <?php } ?>
                            <div class="btn-group">
                                <button type="button" class="btn btn-default btn-sm btn-submit" >修改</button>
                            </div>
                            <?php if($administrators && $do != 'no_pay') { ?>
                                <?php if($do == 'no') { ?>
                                    <button type="button" class="btn btn-default btn-sm btn-submit" data-id="0">审核通过</button>
                                    <button type="button" class="btn btn-default btn-sm btn-submit" data-id="1">审核不通过</button>
                                <?php } elseif($do == 'lose') { ?>
                                    <?php if($administrators) { ?>
                                    <button type="button" class="btn btn-default btn-sm btn-submit" data-id="0">审核通过</button>
                                    <?php } ?>
                                <?php } else { ?>

                                    <?php if($administrators) { ?>
                                        <?php if($do == 'rec') { ?>
                                        <button type="button" class="btn btn-default btn-sm btn-submit" data-id="4">取消推荐</button>
                                        <?php } elseif($do != 'close') { ?>
                                        <button type="button" class="btn btn-default btn-sm btn-submit" data-id="4">取消推荐</button>
                                        <button type="button" class="btn btn-default btn-sm btn-submit" data-id="3">推荐</button>
                                        <?php } ?>
                                    <?php } ?>
                                <?php } ?>
                            <?php } ?>
                            <?php if($do != 'no_pay' && $do != 'lose' && $do != 'no') { ?>
                            <?php if($do == 'close') { ?>
                            
                            <button type="button" class="btn btn-default btn-sm btn-submit" data-id="6">开启</button>
                            <?php } else { ?>
                            
                            <button type="button" class="btn btn-default btn-sm btn-submit" data-id="7">关闭</button>
                            <?php } ?>
                            <?php } ?>
                            <?php if($settings['is_brand_del']['value']==1 || $administrators) { ?>
                                <button type="button" class="btn btn-default btn-sm btn-submit" data-id="2">删除</button>
                            <?php } ?>
                            <?php echo $paging;?>
                            <!-- /.pull-right -->
                        </div>
                    </div>
                    </form>
                </div>
                <!-- /. box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
</div>
<style type="text/css">
div.dropdown-lj {
color: #555;
margin: 3px -22px 0 0;
width: 113px;
position: relative;
height: 17px;
text-align:left;
}
div.submenu
{
background: #fff;
position: absolute;
top: -12px;
left: -20px;
z-index: 100;
width: 115px;
display: none;
margin-left: 10px;
padding: 40px 0 5px;
border-radius: 6px;
box-shadow: 0 2px 8px rgba(0, 0, 0, 0.45);
}
a.account{cursor: pointer;}
a.account-lj {
line-height: 16px;
color: #555;
position: absolute;
z-index: 110;
display: block;
padding: 11px 0 0 10px;
height: 28px;
width: 121px;
margin: -11px 0 0 -10px;
text-decoration: none;
background: url(source/plugin/aljht/static/img/arrow.png) 76px 17px no-repeat;
cursor:pointer;
}
.dropdown-lj  li a {
    color: #555555;
    display: block;
    font-family: arial;
    font-weight: bold;
    padding: 6px 15px;
  cursor: pointer;
text-decoration:none;
}
.dropdown-lj li a:hover{
    background:#155FB0;
    color: #FFFFFF;
    text-decoration: none;   
}
.root
{
list-style:none;
margin:0px;
padding:0px;
padding: 11px 0 0 0px;
border-top:1px solid #dedede;
}
</style>
<?php if(file_exists("source/plugin/aljbzj/template/bood_iframe.htm")) { include template('aljbzj:bood_iframe'); } ?>
<script>
    <?php if($_GET['bzj'] == 'yes' && $_GET['bid']) { ?>
    iframebood('<?php echo $_GET['bid'];?>')
    <?php } ?>
    function EnterPress(e){ //传入 event
        var e = e || window.event;
        if(e.keyCode == 13){
            $('.glyphicon-search').click();
        }
    }
$(".account").click(function()  
{ 
var b=$(this).attr('val-data');	
if($(".submenu"+b).css("display")=="none")  
{  
$(this).addClass('account-lj');
$(".submenu"+b).show();      
}  
else  
{  
$(this).removeClass('account-lj');
$(".submenu"+b).hide();  
}   
});
$(".submenu").mouseup(function()
{
return false
});
$(".account").mouseup(function()
{
return false
});
$(document).mouseup(function()
{
$(".submenu").hide();
$(".account").removeClass('account-lj');
});

function iframebtype(bid){
    //iframe窗

    layer.open({
        type: 2,
        title: '\u6dfb\u52a0\u5e97\u94fa\u5546\u54c1\u5206\u7c7b',
        shadeClose: true,
        shade: false,
        maxmin: true, //开启最大化最小化按钮
        area: ['80%', '70%'],
        content: 'plugin.php?id=aljht&act=admin&op=brand&do=btype<?php echo $urlmod;?>&bid='+bid
    });
}

function iwantclaim(bid){
layer.open({
  type: 1,
  title: '<?php echo $aljhtlang['js']['brand_1'];?>',
  skin: 'layui-layer-rim', //加上边框
  area: ['420px', '240px'], //宽高
  content: '<iframe style="display:none;" name="submitiframe"></iframe><form name="cpform" id="admingoodssubmit" method="post" autocomplete="off" action="plugin.php?id=<?php echo $pluginid;?>&amp;act=admin&amp;op=brand&amp;do=iwantclaim<?php echo $urlmod;?>" target="submitiframe" style="padding:10px 20px"><input type="hidden" value="<?php echo FORMHASH;?>" name="formhash"><input type="hidden" value="'+bid+'" name="bid"><div class="form-group"><label><?php echo $aljhtlang['js']['brand_2'];?></label><input class="form-control" placeholder="<?php echo $aljhtlang['js']['brand_3'];?>" name="name" value=""></div><div class="form-group"><input type="submit" class="btn btn-primary" value="<?php echo $aljhtlang['js']['brand_4'];?>"></div></form>'
});
}
function iframereply(bid){
//iframe窗

layer.open({
  type: 2,
  title: '<?php echo $aljhtlang['js']['brand_5'];?>',
  shadeClose: true,
  shade: false,
  maxmin: true, //开启最大化最小化按钮
  area: ['893px', '600px'],
  content: 'plugin.php?id=aljht&act=admin&op=brand&do=breply<?php echo $urlmod;?>&bid='+bid
});
}
    function tips(info){
        if(info == 0){
            layer.alert('<?php echo $aljhtlang['js']['brand_6'];?>', {icon: 6},function(){
                location.href=location.href;
            });
        }else{
            layer.alert(info, {icon: 6},function(){
                location.href=location.href;
            });
        }
    }
    $('.btn-submit').click(function(){
        $('#sign').val($(this).attr('data-id'));
        if($(this).attr('data-id') == 2){
layer.confirm('<?php echo $aljhtlang['js']['brand_7'];?>', {
  btn: ['<?php echo $aljhtlang['js']['brand_8'];?>'] //按钮
}, function(){
  layer.msg('<?php echo $aljhtlang['js']['brand_9'];?>', {icon: 16});
  $('#admingoodssubmit').submit();
});
}else if($(this).attr('data-id') == 7){
            layer.confirm('您确认要关闭店铺吗？关闭店铺会连带关闭商品、活动、优惠券、视频、相册等，请谨慎操作！', {
                btn: ['<?php echo $aljhtlang['js']['brand_8'];?>'] //按钮
            }, function(){
                layer.msg('<?php echo $aljhtlang['js']['brand_9'];?>', {icon: 16});
                $('#admingoodssubmit').submit();
            });
        }else{
layer.msg('<?php echo $aljhtlang['js']['brand_9'];?>', {icon: 16});
$('#admingoodssubmit').submit();
}
    });
    $(function () {
        //Enable iCheck plugin for checkboxes
        //iCheck for checkbox and radio inputs
        $('.mailbox-messages input[type="checkbox"]').iCheck({
            checkboxClass: 'icheckbox_flat-blue',
            radioClass: 'iradio_flat-blue'
        });

        //Enable check and uncheck all functionality
        $(".checkbox-toggle").click(function () {
            var clicks = $(this).data('clicks');
            if (clicks) {
                //Uncheck all checkboxes
                $(".mailbox-messages input[type='checkbox']").iCheck("uncheck");
                $(".fa", this).removeClass("fa-check-square-o").addClass('fa-square-o');
            } else {
                //Check all checkboxes
                $(".mailbox-messages input[type='checkbox']").iCheck("check");
                $(".fa", this).removeClass("fa-square-o").addClass('fa-check-square-o');
            }
            $(this).data("clicks", !clicks);
        });

        //Handle starring for glyphicon and font awesome
        $(".mailbox-star").click(function (e) {
            e.preventDefault();
            //detect type
            var thisstar = $(this).find("a > i");
            var glyph = thisstar.hasClass("glyphicon");
            var fa = thisstar.hasClass("fa");

            //Switch states
            if (glyph) {
                thisstar.toggleClass("glyphicon-star");
                thisstar.toggleClass("glyphicon-star-empty");
            }

            if (fa) {
                thisstar.toggleClass("fa-star");
                thisstar.toggleClass("fa-star-o");
            }
        });
    });
</script><?php include template('aljht:admin/footer'); ?>