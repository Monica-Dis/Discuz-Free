<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<tr ><th class="partition" colspan="15" >&#21457;&#24067;&#31649;&#29702;&#39029;&#38754;&#26435;&#38480;&#35774;&#32622;</th></tr>
<tr><td s="1" class="td27" colspan="2">&#21047;&#26032;&#31215;&#20998;&#31867;&#22411;</td></tr>
<tr onmouseover="setfaq(this, 'faq205a')" class="noborder"><td class="vtop rowform">
    <select name="settingsnew[reflashextcredit]">
        <option value="" >&#31354;
            <?php if(is_array($_G['setting']['extcredits'])) foreach($_G['setting']['extcredits'] as $id => $credit) { ?>        <option value="<?php echo $id;?>" <?php if($id == $settings['reflashextcredit']['value']) { ?>selected<?php } ?>><?php echo $credit['title'];?>
        <?php } ?>
    </select>
</td></tr>
<tr><td s="1" class="td27" colspan="2">&#21047;&#26032;&#38656;&#35201;&#28040;&#32791;&#30340;&#31215;&#20998;&#25968;&#37327;</td></tr>
<tr onmouseover="setfaq(this, 'faq1e8e')" class="noborder"><td class="vtop rowform">
    <input type="text" class="txt" value="<?php echo $settings['reflashpay']['value'];?>" name="settingsnew[reflashpay]"></td><td s="1" class="vtop tips2"></td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#32622;&#39030;&#31215;&#20998;&#31867;&#22411;</td></tr>
<tr onmouseover="setfaq(this, 'faq205a')" class="noborder"><td class="vtop rowform">
    <select name="settingsnew[topextcredit]">
        <option value="" >&#31354;
            <?php if(is_array($_G['setting']['extcredits'])) foreach($_G['setting']['extcredits'] as $id => $credit) { ?>        <option value="<?php echo $id;?>" <?php if($id == $settings['topextcredit']['value']) { ?>selected<?php } ?>><?php echo $credit['title'];?>
        <?php } ?>
    </select>
</td></tr>
<tr><td s="1" class="td27" colspan="2">&#32622;&#39030;&#38656;&#35201;&#28040;&#32791;&#30340;&#31215;&#20998;&#25968;&#37327;</td></tr>
<tr onmouseover="setfaq(this, 'faq1e8e')" class="noborder"><td class="vtop rowform">
    <input type="text" class="txt" value="<?php echo $settings['toppay']['value'];?>" name="settingsnew[toppay]"></td><td s="1" class="vtop tips2"></td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#32622;&#39030;&#22871;&#39184;</td></tr>
<tr class="noborder" onmouseover="setfaq(this, 'faqd8d7')">
    <td class="vtop rowform">
<textarea rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)" name="settingsnew[top_tz]"  cols="50" class="tarea">
<?php echo $settings['top_tz']['value'];?>
</textarea>
    </td>
    <td class="vtop tips2" s="1">
            &#26684;&#24335;&#65306;&#22825;&#25968;&#61;&#31215;&#20998;<br/>
            &#22914;&#65306;<br/>
        1=10<br/>
        7=50<br/>
        15=100<br/>
    </td>
</tr>