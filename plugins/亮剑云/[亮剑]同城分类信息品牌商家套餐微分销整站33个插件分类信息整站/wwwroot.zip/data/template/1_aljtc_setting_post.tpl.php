<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<tr ><th class="partition" colspan="15" >&#21457;&#24067;&#39029;&#38754;&#35774;&#32622; </th></tr>

<tr><td colspan="2" class="td27" s="1">&#26159;&#21542;&#35843;&#29992;&#35770;&#22363;&#30340;&#27700;&#21360;&#21151;&#33021;</td></tr>
<tr class="noborder">
    <td class="vtop rowform" s="1">
        <ul onmouseover="altStyle(this);">
            <li class="checked">
                <input type="radio"  value="1"  <?php if($settings['iswatermark']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[iswatermark]" class="radio">&nbsp;&#26159;
            </li>
            <li><input type="radio" value="0" <?php if($settings['iswatermark']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[iswatermark]" class="radio">&nbsp;&#21542;</li>
        </ul>
        <br>
    </td>
    <td>&#24320;&#21551;&#20043;&#21069;&#35831;&#20808;&#24320;&#21551;&#32;&#20840;&#23616;&#45;&#27700;&#21360;&#35774;&#32622;&#45;&#35770;&#22363;&#45;&#35770;&#22363;&#38468;&#20214;&#22270;&#29255;&#27700;&#21360;&#35774;&#32622;</td>
</tr>
<tr><td colspan="2" class="td27" s="1">&#32852;&#31995;&#20154;&#35843;&#29992;&#21830;&#22478;&#40664;&#35748;&#25910;&#36135;&#22320;&#22336;</td></tr>
<tr class="noborder">
    <td class="vtop rowform" s="1">
        <ul onmouseover="altStyle(this);">
            <li class="checked">
                <input type="radio"  value="1"  <?php if($settings['is_bd_address']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[is_bd_address]" class="radio">&nbsp;&#26159;
            </li>
            <li><input type="radio" value="0" <?php if($settings['is_bd_address']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[is_bd_address]" class="radio">&nbsp;&#21542;</li>
        </ul>
        <br>
    </td>
    <td>&#38656;&#35201;&#21830;&#22478;&#19968;&#22871;&#37197;&#21512;</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#21457;&#24067;&#39029;&#38754;&#20813;&#36131;&#22768;&#26126;</td></tr>
<tr class="noborder" onmouseover="setfaq(this, 'faqd8d7')">
    <td class="vtop rowform">
<textarea rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)" name="settingsnew[mianzeinfo]"  cols="50" class="tarea">
<?php echo $settings['mianzeinfo']['value'];?>
</textarea>
    </td>
    <td class="vtop tips2" s="1">&#21452;&#20987;&#36755;&#20837;&#26694;&#21487;&#25193;&#22823;&#47;&#32553;&#23567;</td>



<tr><td colspan="2" class="td27" s="1">&#26159;&#21542;&#23457;&#26680;&#25968;&#25454;</td></tr>
<tr class="noborder">
    <td class="vtop rowform" s="1">
        <ul onmouseover="altStyle(this);">
            <li class="checked">
                <input type="radio"  value="1"  <?php if($settings['isreview']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[isreview]" class="radio">&nbsp;&#26159;
            </li>
            <li><input type="radio" value="0" <?php if($settings['isreview']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[isreview]" class="radio">&nbsp;&#21542;</li>
        </ul>
        <br></td>
</tr>
<tr><td colspan="2" class="td27" s="1">&#20813;&#23457;&#26680;&#29992;&#25143;&#32452;</td></tr>
<tr class="noborder" onmouseover="setfaq(this, 'faqd8d7')">
    <td class="vtop rowform">
        <?php echo l_groups('m_groups',$type=0)?>    </td>
    <td class="vtop tips2" s="1">&#25353;&#20303;&#32;&#67;&#84;&#82;&#76;&#32;&#22810;&#36873;</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#21457;&#24067;&#20449;&#24687;&#28040;&#32791;&#31215;&#20998;&#31867;&#22411;</td></tr>
<tr onmouseover="setfaq(this, 'faq205a')" class="noborder"><td class="vtop rowform">
    <select name="settingsnew[releaseextcredit]">
        <option value="" >&#31354;
            <?php if(is_array($_G['setting']['extcredits'])) foreach($_G['setting']['extcredits'] as $id => $credit) { ?>        <option value="<?php echo $id;?>" <?php if($id == $settings['releaseextcredit']['value']) { ?>selected<?php } ?>><?php echo $credit['title'];?>
        <?php } ?>
    </select>
</td></tr>
<tr><td s="1" class="td27" colspan="2">&#21457;&#24067;&#20449;&#24687;&#28040;&#32791;&#31215;&#20998;&#25968;&#37327;</td></tr>
<tr onmouseover="setfaq(this, 'faq1e8e')" class="noborder"><td class="vtop rowform">
    <input type="text" class="txt" value="<?php echo $settings['releasepay']['value'];?>" name="settingsnew[releasepay]"></td><td s="1" class="vtop tips2"></td>
</tr>
<tr><td colspan="2" class="td27" s="1">&#20801;&#35768;&#21457;&#24067;&#29992;&#25143;&#32452;</td></tr>
<tr class="noborder" onmouseover="setfaq(this, 'faqd8d7')">
    <td class="vtop rowform">
        <?php echo l_groups('lj_groups',$type=0)?>    </td>
    <td class="vtop tips2" s="1">&#25353;&#20303;&#32;&#67;&#84;&#82;&#76;&#32;&#22810;&#36873;</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#26159;&#21542;&#35770;&#22363;&#25163;&#26426;&#21495;&#22635;&#20889;&#21518;&#25165;&#33021;&#21457;&#24067;&#20449;&#24687;</td></tr>
<tr class="noborder">
    <td class="vtop rowform" s="1">
        <ul onmouseover="altStyle(this);"><li class="checked"><input type="radio"  value="1"  <?php if($settings['is_forum_mobile']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[is_forum_mobile]" class="radio">&nbsp;&#26159;</li><li><input type="radio" value="0" <?php if($settings['is_forum_mobile']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[is_forum_mobile]" class="radio">&nbsp;&#21542;</li></ul>
        <br></td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#25163;&#26426;&#21495;&#32465;&#23450;&#38142;&#25509;</td></tr>
<tr onmouseover="setfaq(this, 'faq1e8e')" class="noborder">
    <td class="vtop rowform">
        <input type="text" class="txt" value="<?php echo $settings['forum_mobile_url']['value'];?>" name="settingsnew[forum_mobile_url]">
    </td>
    <td s="1" class="vtop tips2">&#35831;&#22635;&#20889;&#32465;&#23450;&#25163;&#26426;&#21495;&#30340;&#38142;&#25509;&#65292;&#19981;&#22635;&#20889;&#36820;&#22238;&#19978;&#19968;&#39029;</td>
</tr>

<tr><td s="1" class="td27" colspan="2">&#26159;&#21542;&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#20449;&#24687;</td></tr>
<tr class="noborder">
    <td class="vtop rowform" s="1">
        <ul onmouseover="altStyle(this);"><li class="checked"><input type="radio"  value="1"  <?php if($settings['is_plugin_rz']['value']==1) { ?>checked=""<?php } ?> name="settingsnew[is_plugin_rz]" class="radio">&nbsp;&#26159;</li><li><input type="radio" value="0" <?php if($settings['is_plugin_rz']['value']==0) { ?>checked=""<?php } ?> name="settingsnew[is_plugin_rz]" class="radio">&nbsp;&#21542;</li></ul>
        <br></td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#26410;&#35748;&#35777;&#27599;&#22825;&#21457;&#24067;&#20449;&#24687;&#25968;&#37327;</td></tr>
<tr onmouseover="setfaq(this, 'faq1e8e')" class="noborder"><td class="vtop rowform">
    <input type="text" class="txt" value="<?php echo $settings['no_rz_post_num']['value'];?>" name="settingsnew[no_rz_post_num]"></td>
    <td s="1" class="vtop tips2">&#19981;&#22635;&#20889;&#19981;&#38480;&#21046;&#44;&#35748;&#35777;&#21518;&#21457;&#24067;&#20449;&#24687;&#24320;&#20851;&#24320;&#21551;&#27492;&#39033;&#22833;&#25928;</td>
</tr>
<tr><td s="1" class="td27" colspan="2">&#35748;&#35777;&#21518;&#27599;&#22825;&#21457;&#24067;&#20449;&#24687;&#25968;&#37327;</td></tr>
<tr onmouseover="setfaq(this, 'faq1e8e')" class="noborder"><td class="vtop rowform">
    <input type="text" class="txt" value="<?php echo $settings['rz_post_num']['value'];?>" name="settingsnew[rz_post_num]"></td><td s="1" class="vtop tips2">&#19981;&#22635;&#20889;&#19981;&#38480;&#21046;</td></tr>
