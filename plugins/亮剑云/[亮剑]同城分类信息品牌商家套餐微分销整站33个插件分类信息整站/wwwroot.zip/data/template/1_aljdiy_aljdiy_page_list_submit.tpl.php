<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template(PLUGIN_ID.':admin/header')?><style>
    body,button,input,select,textarea{ font-family: "Segoe UI", \5b8b\4f53, "Lucida Grande", Helvetica, "Microsoft YaHei", FreeSans, Arimo, "Droid Sans","wenquanyi micro hei","Hiragino Sans GB", "Hiragino Sans GB W3", Arial, sans-serif; }
    body{ font-size: 13px; }
    * {
        -webkit-box-sizing: inherit;
        -moz-box-sizing: inherit;
        box-sizing: inherit;
    }
    .layui-form-item .layui-input-inline {
        float: left;
        width: 60px;
        margin-right: 10px;
    }
    .layui-form-label {
    float: left;
    display: block;
    padding: 9px 15px;
    width: auto; 
    font-weight: 400;
    line-height: 20px;
    text-align: right;
}
.wrapper{overflow: auto;}
.layui-input-block {
    margin-left: 135px;
    min-height: 36px;
}
</style>
<div style="padding:20px;margin-left:0px;">

    <section class="content" style="padding:0;min-height: 100px;">
        <div class="row">
            <div class="col-md-12">
                <iframe name="submitiframe" id="submitiframe" style="display: none;"></iframe>
                <input type="hidden" value="yes" name="ajax">
                <form class="layui-form" method="post" action=""  target="submitiframe">
                    <input type="hidden" value="<?php echo FORMHASH;?>" name="formhash">
                    <input type="hidden" value="<?php echo $admin_id;?>" name="admin_id" id="admin_id">
                    <input type="hidden" value="<?php echo $station_id;?>" name="station_id" id="station_id">
                    <input type="hidden" value="<?php echo $type;?>" name="type" >
                    <fieldset class="layui-elem-field">
                        <div class="layui-field-box">
                        <div class="layui-form-item">
                                <label class="layui-form-label" style="width:auto">页面排序号</label>
                            <div class="layui-input-block">
                                <input type="text" name="displayorder" lay-verify="displayorder" value="<?php if($data['displayorder']) { ?><?php echo $data['displayorder'];?><?php } else { ?>100<?php } ?>" autocomplete="off" placeholder="排序号" class="layui-input">
                            </div>
                        </div>
                        <div class="layui-form-item">
                            <label class="layui-form-label" style="width:auto">页面LOGO</label>
                            <div class="layui-input-block">
                                <button type="button" class="layui-btn layui-btn-primary upload">
                                        <i class="layui-icon">&#xe67c;</i>上传页面LOGO
                                    </button>
                                    
                                    <div class="upload_img" style="margin-top:5px;">
                                        <?php if($data['logo']) { ?>
                                        <img style="max-width:80px;" src="<?php echo $data['logo'];?>">
                                        <?php } ?>
                                    </div>
                                    
                            </div>
                            
                        </div>

                        <div class="layui-form-item">
                                <label class="layui-form-label" style="width:auto">页面标题</label>
                            <div class="layui-input-block">
                                <input type="text" name="title" lay-verify="title" value="<?php if(!$data['title']) { ?><?php echo $branddiy['name'];?><?php } else { ?><?php echo $data['title'];?><?php } ?>" autocomplete="off" placeholder="请输入页面名称" class="layui-input">
                            </div>
                        </div>
                        
                        <div class="layui-form-item">
                            <label class="layui-form-label" style="width:auto">页面描述</label>
                            <div class="layui-input-block">
                                <textarea name="intro" placeholder="请输入页面描述" class="layui-textarea"><?php if(!$data['title']) { ?><?php echo $branddiy['name'];?><?php } else { ?><?php echo $data['intro'];?><?php } ?></textarea>
                            </div>
                        </div>
                        <div class="layui-form-item">
                            <label class="layui-form-label" style="width:auto">页面背景图</label>
                            <div class="layui-input-block">
                                <button type="button" class="layui-btn layui-btn-primary upload_two">
                                        <i class="layui-icon">&#xe67c;</i>上传页面背景图
                                    </button>
                                    
                                    <div class="upload_img_two" style="margin-top:5px;">
                                        <?php if($data['page_bg_img']) { ?>
                                        <img style="max-width:80px;" src="<?php echo $data['page_bg_img'];?>">
                                        &nbsp;<input type="checkbox" value="1" name="page_bg_img_delete" title="删除">
                                        <?php } ?>
                                    </div>
                                    <p>背景图设置后前台模块会以卡片展示</p>
                            </div>
                            
                        </div>
                        <div class="layui-form-item">
                                <label class="layui-form-label" style="width:auto">页面背景色</label>
                            <div class="layui-input-block">
                                <input type="text" name="page_bg_color" lay-verify="page_bg_color" value="<?php echo $data['page_bg_color'];?>" autocomplete="off" placeholder="请填写颜色代码如：#FFFFFF" class="layui-input">
                                <p>背景色设置后前台模块会以卡片展示</p>
                            </div>
                        </div>
                        <?php if($type == 0) { ?>
                        
                        <div class="layui-form-item">
                            <label class="layui-form-label" style="width:auto">选择分组</label>
                            <div class="layui-input-block">
                                <select name="groupid" lay-filter="groupid">
                                    <option value="0">默认分组</option>
                                    <?php if(is_array($group_list)) foreach($group_list as $group) { ?>                                    <option value="<?php echo $group['id'];?>" <?php if($group['id'] == $data['groupid']) { ?>selected<?php } ?>><?php echo $group['title'];?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="group_parm" <?php if(!$data['groupid']) { ?>style="display:none"<?php } ?>>
                            <div class="layui-form-item">
                                <label class="layui-form-label" style="width:auto">分组标题</label>
                                <div class="layui-input-block">
                                    <input type="text" name="group_title" lay-verify="group_title" value="<?php echo $data['group_title'];?>" autocomplete="off" placeholder="填写分组名称，不填写分组显示页面标题"" class="layui-input">
                                    <p>开启分组后，页面显示的专题名称</p>
                                </div>
                                
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label" style="width:auto">分组背景色</label>
                                <div class="layui-input-block">
                                    <input type="text" name="group_bg_color" lay-verify="group_bg_color" value="<?php echo $data['group_bg_color'];?>" autocomplete="off" placeholder="请填写颜色代码如：#FFFFFF" class="layui-input">
                                    <p>开启分组后，页面显示专题名称那一行的背景颜色</p>
                                </div>
                                
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label" style="width:auto">文字颜色</label>
                                <div class="layui-input-block">
                                    <input type="text" name="text_color" lay-verify="text_color" value="<?php if($data['text_color']) { ?><?php echo $data['text_color'];?><?php } else { ?>#333333<?php } ?>" autocomplete="off" placeholder="请填写颜色代码如：#FFFFFF" class="layui-input">
                                    <p>开启分组后，页面显示专题名称的颜色</p>
                                </div>
                                
                            </div>
                            
                            <div class="layui-form-item">
                                <label class="layui-form-label" style="width:auto">选中文字颜色</label>
                                <div class="layui-input-block">
                                    <input type="text" name="sel_text_color" lay-verify="sel_text_color" value="<?php if($data['sel_text_color']) { ?><?php echo $data['sel_text_color'];?><?php } else { ?>#DF1540<?php } ?>" autocomplete="off" placeholder="请填写颜色代码如：#FFFFFF" class="layui-input">
                                    <p>开启分组后，页面显示选中专题名称的颜色</p>
                                </div>
                                
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label" style="width:auto">分组滚动背景色</label>
                                <div class="layui-input-block">
                                    <input type="text" name="scroll_group_bg_color" lay-verify="scroll_group_bg_color" value="<?php if($data['scroll_group_bg_color']) { ?><?php echo $data['scroll_group_bg_color'];?><?php } else { ?>#f42424<?php } ?>" autocomplete="off" placeholder="请填写颜色代码如：#FFFFFF" class="layui-input">
                                    <p>开启分组后，页面滚动时专题名称那一行的背景颜色</p>
                                </div>
                                
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label" style="width:auto">滚动文字颜色</label>
                                <div class="layui-input-block">
                                    <input type="text" name="scroll_text_color" lay-verify="scroll_text_color" value="<?php if($data['scroll_text_color']) { ?><?php echo $data['scroll_text_color'];?><?php } else { ?>#ffffff<?php } ?>" autocomplete="off" placeholder="请填写颜色代码如：#FFFFFF" class="layui-input">
                                    <p>开启分组后，页面滚动时显示专题名称的颜色</p>
                                </div>
                                
                            </div>
                            
                            <div class="layui-form-item">
                                <label class="layui-form-label" style="width:auto">滚动选中文字颜色</label>
                                <div class="layui-input-block">
                                    <input type="text" name="scroll_sel_text_color" lay-verify="scroll_sel_text_color" value="<?php if($data['scroll_sel_text_color']) { ?><?php echo $data['scroll_sel_text_color'];?><?php } else { ?>#ffffff<?php } ?>" autocomplete="off" placeholder="请填写颜色代码如：#FFFFFF" class="layui-input">
                                    <p>开启分组后，页面滚动时显示选中专题名称的颜色</p>
                                </div>
                                
                            </div>
                        </div>
                        <div class="layui-form-item">
                            <label class="layui-form-label" style="width:auto">跳转链接</label>
                            <div class="layui-input-block">
                                <input type="text" name="page_url" lay-verify="page_url" value="<?php echo $data['page_url'];?>" autocomplete="off" placeholder="http开头，填写自定义跳转链接" class="layui-input">
                                <p>填写后分组顶部轮转导航点击直接跳转至该链接</p>
                            </div>
                        </div>
                        <?php } elseif($_G['cache']['plugin']['aljdd']['is_aljdd']) { ?>
                            <div class="layui-form-item">
                                <label class="layui-form-label" style="width:auto">关联店铺</label>
                                <div class="layui-input-block">
                                    
                                    
                                    <select name="bid" lay-filter="bid" lay-verify="required" lay-search="">
                                        <?php if($brand_id<=0) { ?>
                                        <option value="">请直接选择或搜索选择店铺</option>
                                        <?php } ?>
                                        <?php if(is_array($bdlist)) foreach($bdlist as $bd) { ?>                                        <option value="<?php echo $bd['id'];?>" <?php if($bd['id'] == $data['bid'] || ($data['bid']<=0 && $bd['id'] == $brand_id)) { ?>selected<?php } ?>><?php echo $bd['name'];?></option>
                                        <?php } ?>
                                    </select>
                                    
                                </div>
                            </div>
                        <?php } ?>
                        <?php if($data) { ?>
                        <div class="layui-form-item">
                            <label class="layui-form-label">设为</label>
                            <div class="layui-input-block">
                              <select name="push_to_page">
                                <option value="">不设置</option>
                                <?php if($type == 0) { ?>
                                <option value="aljbd_index" <?php if($data['push_to_page'] == 'aljbd_index') { ?>selected<?php } ?>>品牌商家首页</option>
                                <option value="aljtc_index" <?php if($data['push_to_page'] == 'aljtc_index') { ?>selected<?php } ?>>同城首页</option>
                                <option value="aljtsc_index" <?php if($data['push_to_page'] == 'aljtsc_index') { ?>selected<?php } ?>>同城商城首页</option>
                                <option value="aljtsq_index" <?php if($data['push_to_page'] == 'aljtsq_index') { ?>selected<?php } ?>>同城商圈首页</option>
                                <?php } else { ?>
                                <option value="aljbd_view" <?php if($data['push_to_page'] == 'aljbd_view') { ?>selected<?php } ?>>商城店铺详情</option>
                                <?php } ?>
                              </select>
                            </div>
                          </div>
                        </div>
                        <?php } ?>
                        <div class="layui-form-item">
                            <div class="layui-input-block">
                                <button class="layui-btn" lay-submit lay-filter="*">立即提交</button>
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
        <!-- /.row -->
    </section>
</div>
<script>
        var transfer;
        var R = {
            init: function(){
                layui.use('laydate', function(){
                    var laydate = layui.laydate;
                    laydate.render({
                        elem: '#start_time'
                        ,type: 'time'
                    });
                    laydate.render({
                        elem: '#end_time'
                        ,type: 'time'
                    });
                });
                layui.use('form', function(){
                    var form = layui.form;
                    form.on('submit(*)', function(data){
                        
                    });
                    form.on('select(groupid)', function(data){
                        if(data.value > 0){
                            $('.group_parm').show();
                        }else{
                            $('.group_parm').hide();
                        }
                    });
                });
            },
            layuiUpload: function(){
            layui.use('upload', function(){
                var upload = layui.upload;
                //upload
                upload.render({
                    elem: '.upload'
                    ,auto: false
                    ,choose: function(obj){
                        var item = this.item;
                        obj.preview(function(index, file, result){

                            if (!file.type.match('image.*')) {
                                layer.open({content: '图片类型错误',skin: 'msg',time: 2});
                                return false;
                            }
                            lrz(file, {
                                width:600,
                                done: function (results) {
                                    var domdata ='<img  style="height:80px;" src="'+results.base64+'">';
                                    domdata += '<input name="uploadPhoto" type="hidden" value="'+results.base64+'">';
                                    domdata += '<input name="size" type="hidden" value="'+results.base64.length+'">';
                                    //console.log(domdata);
                                    $(item).parent().find('.upload_img').html(domdata);
                                }

                            });
                        });

                    }
                });
                upload.render({
                    elem: '.upload_two'
                    ,auto: false
                    ,choose: function(obj){
                        var item = this.item;
                        obj.preview(function(index, file, result){

                            if (!file.type.match('image.*')) {
                                layer.open({content: '图片类型错误',skin: 'msg',time: 2});
                                return false;
                            }
                            var domdata ='<img  style="max-height:80px;" src="'+result+'">';
                            domdata += '<input name="uploadPhoto_two" type="hidden" value="'+result+'">';
                            domdata += '<input name="size_two" type="hidden" value="'+result.length+'">';
                            //console.log(domdata);
                            $(item).parent().find('.upload_img_two').html(domdata);
                        });

                    }
                });
            });
            },
            tips: function(info,url){
                if(info == 0){
                    layer.alert('操作成功', {icon: 6, shade: 0,offset: '100px'},function(){
                        parent.location.href=parent.location.href;
                    });
                }else if(typeof (url) !== 'undefined'){
                    layer.alert(info, {icon: 6, shade: 0,offset: '100px'},function(){
                        location.href=url;
                    });
                }else{
                    layer.alert(info, {icon: 6, shade: 0,offset: '100px'},function(){
                        parent.location.href=parent.location.href;
                    });
                }
            }
        };
        $(function() {
            R.init();
            R.layuiUpload();
        });
    </script>
