<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('orderlist');?><?php include template('aljbd:index_header'); ?><style>
.wm_type{border: 1px solid #f42424;color:#f42424;padding:0px 4px;font-size: 12px;border-radius: 5px;margin-right: 5px;}
.o_reply{border: 1px solid #f42424;color:#f42424;padding:2px 10px;font-size: 12px;border-radius: 5px;display: block;width:80px}
</style>
<link rel="stylesheet" type="text/css" href="source/plugin/aljht/static/css/user.css">
<div class="user-content clearfix">
    <?php include template('aljht:user/common/l_side'); ?>    <div class="user-main" >
        <div class="user-mod" >
            <div class="user-title">
                <h2>我的订单</h2>
                <ul class="tabs">
                    <li <?php if(!$_GET['status']) { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=user&amp;op=orderlist">全部订单</a></li> 
                    <li class="user-count1 <?php if($_GET['status'] == 1) { ?>active<?php } ?>">
                        <a href="plugin.php?id=aljht&amp;act=user&amp;op=orderlist&amp;status=1">待付款</a>
                    </li>
                    <li class="user-count2 <?php if($_GET['status'] == 2) { ?>active<?php } ?>">
                        <a href="plugin.php?id=aljht&amp;act=user&amp;op=orderlist&amp;status=2">待发货</a>
                    </li>
                    <li class="user-count3 <?php if($_GET['status'] == 3) { ?>active<?php } ?>" >
                        <a href="plugin.php?id=aljht&amp;act=user&amp;op=orderlist&amp;status=3">已发货</a>
                    </li>
                    <li class="user-count4 <?php if($_GET['status'] == 4) { ?>active<?php } ?>">
                        <a href="plugin.php?id=aljht&amp;act=user&amp;op=orderlist&amp;status=4">待晒单</a>
                    </li>
                    <li class="user-count5 <?php if($_GET['status'] == 5) { ?>active<?php } ?>">
                        <a href="plugin.php?id=aljht&amp;act=user&amp;op=orderlist&amp;status=5">已晒单</a>
                    </li>
                </ul>
                <!--a href="user.php?act=order_recycle" class="more">订单回收站</a-->
            </div>
            <div class="user-list-title clearfix">
                <!--div class="user-list-filter">
                    <div id="order_status" class="imitate_select w120 mgr10">
                        <div class="cite"><span>全部状态</span><i class="iconfont icon-icon_down_arrow"></i></div>
                    </div>
                    <div id="dateTime" class="imitate_select w120">
                        <div class="cite"><span>全部时间</span><i class="iconfont icon-icon_down_arrow"></i></div>
                    </div>
                </div-->
                
                <div class="user-list-search">
                    <input type="text" id="search" class="text"  placeholder="输入商品名称或者订单号搜索或备注" onkeypress="EnterPress(event)" onkeydown="EnterPress()" value="<?php echo $keyword;?>" style="color:#999;width:300px">
                    <button type="button" class="glyphicon-search" onclick="location.href='plugin.php?id=aljht&act=user&op=orderlist&search='+lj_jq('#search').val()"><i class="iconfont icon-sousuo"></i></button type="button">
                </div>
            </div>
            <link rel="stylesheet" href="source/plugin/aljht/static/css/orderlist.css">
            <div class="info_box" >
                <div class="info_table order_table">
    
                    <table>
                        <tbody>
                            <tr>
                                <th width="50">
                                    &nbsp;
                                </th>
                                <th width="auto">
                                    详情
                                </th>
                                <th width="80">
                                    价格
                                </th>
                                <th width="70">
                                    数量
                                </th>
                                
                                <th width="90">
                                    状态
                                </th>
    
                                <th width="90">
                                    操作
                                </th>
                                <?php if($status == 4) { ?>
                                <th></th>
                                <?php } ?>
                            </tr>
                            <?php if(is_array($orderlist)) foreach($orderlist as $value) { ?>    
                            <tr>
                                <td class="tl order_sum" colspan="<?php if($status == 4) { ?>9<?php } else { ?>8<?php } ?>">
                                    <div class="f_l">
                                        <?php if($value['store_id']>0) { ?>
                                        <?php $obrand = C::t('#aljtsq#aljtsq_store')->fetch($value['store_id']);
                                        $obrand['uid'] = $obrand['tc_uid'];
                                        $obrand['name'] = $obrand['tc_store_name'];?>                                        <?php if($value['order_type'] == 3) { ?>
                                            <?php $obrand['url'] = 'plugin.php?id=aljwm&a=view&c=food&store_id='.$value['store_id'];?>                                        <?php } else { ?>
                                            <?php $obrand['url'] = 'plugin.php?id=aljtsc&a=storeView&c=aljtsc&store_id='.$value['store_id'];?>                                        <?php } ?>
                                        <?php } else { ?>
                                        <?php $obrand = C::t('#aljbd#aljbd')->fetch($value['shop_id'])?>                                        <?php $obrand['url'] = 'plugin.php?id=aljbd&act=view&bid='.$value['shop_id'];?>                                        <img src="<?php echo $obrand['logo'] ? $obrand['logo'] : 'source/plugin/aljbd/images/sj/shang.png'?>" style="width:20px;margin-right: 5px;"/>
                                        <?php } ?>
                                        <a target="_blank" href="<?php echo $obrand['url'];?>" class="right-go a-brand" style="margin-right: 15px;">
                                            <?php if($value['store_id']>0) { ?>
                                            <span class="wm_type"><?php if($value['order_type'] == 3) { ?>外卖<?php } else { ?>&#38376;&#24215;<?php } ?></span>
                                            <?php } ?>
                                            <?php echo $obrand['name'];?></a>
                                        <?php if($value['commodity_type'] == 1 && $_G['cache']['plugin']['aljstg']) { include template('aljstg:orderlist/tg_text'); } elseif($value['commodity_type'] == 2 && $_G['cache']['plugin']['aljspt']) { include template('aljspt:orderlist/pt_text'); } ?>订单号：
                                        <h1>
                                            <?php echo $value['orderid'];?>
                                        </h1>时间：
                                        <h1>
                                            <?php echo dgmdate($value['submitdate']);?>                                        </h1>总价：
                                        <h1>
                                            <?php echo $price_unit;?>
                                            <?php echo $value['price'];?>
                                            <?php if(file_exists("source/plugin/dz_3/dz_3.inc.php")) { ?>
                                            <?php include template('dz_3:h_orderlist'); ?>                                            <?php } ?>
                                        </h1>
                                        <?php echo $aljhtlang['template']['orderlist_26'];?>
                                        <h1>
                                            <?php if($_G['cache']['plugin']['aljgwc']['aljol'] || $_G['cache']['plugin']['aljbdx']['aljol']) { ?>
                                            <a href="javascript:;" onclick="openaljol('<?php echo $value['uid'];?>');"><?php echo $value['username'];?></a>
                                            <?php } else { ?>
                                            <?php echo $value['username'];?>
                                            <?php } ?>
                                        </h1>
                                        <?php if($value['remarks']) { ?>备注：<?php echo $value['remarks'];?><?php } ?>
                                    </div>
                                    <div class="f_r">
                                        <?php if($_G['uid'] == $value['uid'] && $value['status'] == 1 && $value['payment'] !=6) { ?>
                                            <a class="continue_pay" href="plugin.php?id=aljgwc&amp;act=cart_pay&amp;orderid=<?php echo $value['orderid'];?>">继续付款</a>
                                        <?php } ?>
                                        <?php if($value['deliverydate']) { ?>
                                        <span class="endtime" value="<?php echo $value['deliverydate']+$deliverytime?>" val-date="<?php echo $value['orderid'];?>" date-val="<?php if($value['status'] == 3) { ?>1<?php } else { ?>0<?php } ?>"></span>
                                        <?php } ?>
                                    </div>
                                </td>
                            </tr>
                            <?php $shop_order=C::t('#aljgwc#aljbd_goods_order_list')->fetch_all_by_orderid($value['orderid']);?>                            <?php $i=1;?>                            <?php if(is_array($shop_order)) foreach($shop_order as $key => $val) { ?>                            <?php $orderlist_cart=C::t('#aljbd#aljbd_goods')->fetch($val['goods_id']);?>                            <tr class="alt">
                                <td>
                                    <a target="_blank" href="
                                    <?php if($value['order_type'] == 3 && $value['store_id']>0) { ?>
                                    <?php echo $obrand['url'];?>
                                    <?php } else { ?>
                                    plugin.php?id=<?php echo $pluginid_aljbd;?>&act=goodview&bid=<?php echo $val['shop_id'];?>&gid=<?php echo $val['goods_id'];?>
                                    <?php } ?>"><img class="deal_icon" style="width: 50px;" lazy="true" data-src="<?php echo $orderlist_cart['pic1'];?>" src="<?php echo $orderlist_cart['pic1'];?>"></a>
                                </td>
                                <td class="tl">
                                    <a target="_blank" href="
                                    <?php if($value['order_type'] == 3 && $value['store_id']>0) { ?>
                                    <?php echo $obrand['url'];?>
                                    <?php } else { ?>
                                    plugin.php?id=<?php echo $pluginid_aljbd;?>&act=goodview&bid=<?php echo $val['shop_id'];?>&gid=<?php echo $val['goods_id'];?>
                                    <?php } ?>">
                                        <?php if($value['commodity_type'] == 1) { ?>
                                        <?php include template('aljstg:orderlist/order_label'); ?>                                        <?php } ?>
                                        <?php if($value['commodity_type'] == 2) { ?>
                                        <?php include template('aljspt:orderlist/order_label'); ?>                                        <?php } ?>
                                        <?php if($val['is_distribution']>0 && $val['dis_commission']>0) { ?>
                                        <span style="font-size: 12px;background: #f39c12;color:#ffffff;padding:2px;border-radius: 5px;margin-right: 5px">分销</span>
                                        <?php } ?>
                                        <?php echo $val['name'];?><br/>
                                        <?php if($val['content']) { ?>规格留言：<?php echo $val['content'];?><?php } ?>
                                    </a>
                                    <?php if(file_exists("source/plugin/aljbd_dzfj/aljbd_dzfj.inc.php")) { ?>
                                    <?php include template('aljbd_dzfj:orderlist'); ?>                                    <?php } ?>
                                </td>
                                <td>
                                    <?php echo $price_unit;?><?php echo $val['price'];?>
                                    <?php if(file_exists("source/plugin/dz_3/dz_3.inc.php")) { ?>
                                    <br/><?php include template('dz_3:h_orderlist'); ?>                                    <?php } ?>
                                </td>
                                <td>
                                    <?php echo $val['num'];?>
                                </td>
    
                                
                                <?php if($i == 1) { ?>
                                <td class="op_box" rowspan="<?php echo count($shop_order);?>">
                                    <?php if($value['status']==2) { ?>
                                        <?php if($value['payment'] == 6) { ?>
                                            已下单
                                        <?php } else { ?>
                                            待发货
                                        <?php } ?>
                                    <?php } elseif($value['status']==3) { ?>
                                        已发货
                                    <?php } elseif($value['status']==4) { ?>
                                        交易完成
                                    <?php } elseif($value['status']==5) { ?>
                                        <?php echo $aljbdlang['template']['Already_evaluated'];?>
                                    <?php } elseif($value['status']==6) { ?>
                                        已退款
                                    <?php } elseif($value['status']==7) { ?>
                                        交易关闭
                                    <?php } else { ?>
                                        付款中
                                    <?php } ?><br>
                                    <?php $refund = C::t('#aljgwc#aljgwc_refund')->fetch($value['orderid'])?>                                    <?php if($refund && $value['status'] < 4  && $value['status'] >1) { ?>
                                    <br>
    
                                    <a  style="padding:3px 10px;border:1px dashed #f15353;color:#f15353;margin-bottom:5px;font-size: 12px;border-radius: 20px">
                                        <?php if($refund['state'] < 3) { ?>
                                        退款中
                                        <?php } elseif($refund['state'] == 4) { ?>
                                        退款失败
                                        <?php } ?>
                                    </a>
                                    <?php } else { ?>
                                    <?php if($value['commodity_type'] == 2 && $value['status']<6) { ?>
                                    <?php include template('aljspt:orderlist/open_pt_url'); ?>                                    <?php } ?>
                                        
                                    <?php } ?>
                                </td>
    
                                <td class="op_box" rowspan="<?php echo count($shop_order);?>">
                                    
                                    <?php if($value['order_type'] == 3 && $value['store_id']>0) { ?>
                                        <a href="javascript:;" onclick="iframeorderview('<?php echo $value['orderid'];?>','plugin.php?id=aljwm&c=food&a=orderView&orderid=')">查看</a><br>
                                    <?php } else { ?>
                                        <a href="javascript:;" onclick="iframeorderview('<?php echo $value['orderid'];?>')">查看</a><br>
                                        
                                        <?php if(($value['status']==3 && $value['uid'] == $_G['uid']) || ($administrators && $value['status']==3)) { ?>
                                        
                                        <?php $del_ts = '您确认要收货吗？'?>                                        
                                        <?php if(($value['commodity_type'] == 1 && $value['category'] == 1) || $value['get_to_the_shop'] == 1) { ?>
                                        <?php } else { ?>
                                            <a class="del_order" onclick="receipt('<?php echo $value['orderid'];?>','<?php echo $del_ts;?>')" href="javascript:;">确认收货</a><br>
                                        <?php } ?>
                                        <?php } ?>
                                        <?php if($value['status'] == 1 || ($value['status'] < 3 && $value['payment']==6)) { ?>
                                        <a class="can_order" onclick="canorder('<?php echo $value['orderid'];?>','您确认要取消订单吗？');" href="javascript:;">取消订单</a><br>
                                        <?php } ?>
                                        <?php if($value['status'] == 7) { ?>
                                        <a class="del_order" onclick="delorder('<?php echo $value['orderid'];?>','你确定要删除？删除后将无法恢复哦，请谨慎操作！');" href="javascript:;" style="color:red;">删除订单</a><br>
                                        
                                        <?php } ?>
                                        
                                        <?php if($value['status']>=3 && $value['status']<6 && $_G['cache']['plugin']['aljhtx'] && $value['category'] == 0 && $value['get_to_the_shop'] != 1) { ?>
                                        <?php $wuliuinfo=C::t('#aljbd#aljbd_wuliu')->fetch($value['orderid']);?>                                        <a href="javascript:;" onclick="iframewuliu('<?php echo $value['orderid'];?>','<?php echo $wuliuinfo['companyname'];?>','<?php echo $wuliuinfo['worderid'];?>');">查看物流</a><br/>
                                        <?php } ?>
                                    <?php } ?>
                                </td>
                                <?php } ?>
                                <?php if($status == 4 && $value['order_type'] != 3) { ?>
                                <td class="op_box">
                                    <?php if($value['uid'] == $_G['uid']  && $_G['cache']['plugin']['aljgwc'][$pluginid_aljbd]) { ?>
                                        <?php $check = DB::result_first("select count(*) from %t where gid=%d and orderid=%s",array('aljbd_comment_goods',$val['goods_id'],$value['orderid']));?>                                        <?php if($check) { ?>
                                        <?php echo $aljbdlang['template']['Already_evaluated'];?>
                                        <?php } else { ?>
                                            <a href="javascript:;" onclick="iframecomment('<?php echo $value['orderid'];?>','<?php echo $val['goods_id'];?>')" >
                                                <?php if($_G['cache']['plugin']['aljbd']['goods_reply_type'] && $_G['cache']['plugin']['aljbd']['goods_reply_num']) { ?>
                                                <span class="o_reply">评价送积分</span>
                                                <?php } else { ?>
                                                <span class="o_reply"><?php echo $aljbdlang['template']['evaluate'];?></span>
                                                <?php } ?>
                                            </a>
                                        <?php } ?>
                                    <?php } else { ?>
                                    --
                                    <?php } ?>
                                </td>
                                <?php } ?>
                            </tr>
                            <?php $i++;?>                            <?php } ?>
                            <?php } ?>
                        </tbody>
                    </table>
                    
                </div>
            </div>
            <div class="pages pages_warp"><?php echo $paging;?> </div>
        </div>
    </div>
</div><?php include template('aljht:admin/orderlist/common/common_js'); ?><script>
function EnterPress(e){ //传入 event
    var e = e || window.event;
    if(e.keyCode == 13){
        jQuery('.glyphicon-search').click();
    }
}
function tips(info){
    if(info == 0){
        layer.alert('操作成功', {icon: 6},function(){
            location.href=location.href;
        });
    }else{
        layer.alert(info, {icon: 6},function(){
            location.href=location.href;
        });
    }
}
</script><?php include template('aljbd:common/footer'); ?>         
        

        
         
        	

        
         
        		
        
        
         
        	
        
        
         
        	

        
         
        
        
         
                
        
         
                 
        
         
                  

         
                 






         
        




        
                

        
                
        
        
                
                
                
                
                	

        
                	
        
        
                	
        
        
                
        
        
                       

        
        		
        
                    
        
         
        
        
        
                

        
                
        
        
         
        
        
        
                	
        
        
                
        
        
                    
                
                

        
                
        
        
        
         
                 
        
        
         
        
        
        
         
              
        
         
                
        
         
                  
        
        
    </div>
</div>