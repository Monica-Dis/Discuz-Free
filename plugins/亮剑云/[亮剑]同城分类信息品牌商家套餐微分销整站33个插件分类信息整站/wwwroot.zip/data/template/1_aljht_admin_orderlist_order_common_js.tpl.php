<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<style type="text/css">
    .c_publish_time {
        background: url(source/plugin/aljht/static/img/daojishi.png) left center no-repeat;
        background-size: auto 16px;
        padding-left: 20px;
    }
</style>
<script>

    function fahuo(orderid,category,get_to_the_shop,sub_type,order_type){
        if(get_to_the_shop == 1){
            layer.confirm('到店自取订单是否发送取货码', {
                btn: ['确认发送'] //按钮
            }, function(){
                layer.msg('取货码生成中', {icon: 16});
                jQuery.post('plugin.php?id=aljht&act=admin&op=orderlist&do=qhm_code<?php echo $urlmod;?>',{"orderid":orderid,'formhash':'<?php echo FORMHASH;?>'},function(data){
                    if(data==1){
                        tips('生成成功');
                    }else{
                        tips('生成失败');
                    }
                });
            });
        }else{
            var html = '<iframe style="display:none;" name="submitiframe"></iframe>';
            if(sub_type == 1){
                html += '<form name="cpform" id="admingoodssubmit" method="post" autocomplete="off" action="plugin.php?id=<?php echo $pluginid;?>&amp;act=admin&amp;op=orderlist&amp;do=editfahuo<?php echo $urlmod;?>" target="submitiframe" style="padding:10px 20px">';
            }else{
                html += '<form name="cpform" id="admingoodssubmit" method="post" autocomplete="off" action="plugin.php?id=<?php echo $pluginid;?>&amp;act=admin&amp;op=orderlist&amp;do=fahuo<?php echo $urlmod;?>" target="submitiframe" style="padding:10px 20px">';
            }

            html += '<input type="hidden" value="<?php echo FORMHASH;?>" name="formhash">';
            html += '<input type="hidden" value="'+orderid+'" name="orderid">';
            html += '<input type="hidden" value="'+category+'" name="category">';

            if(category == 1){
                html += '<div class="form-group">';
                html += '<textarea name="e" class="form-control" placeholder="虚拟物品发货，可以填写留言、方法、卡密、优惠券、代金券、密码等"><?php echo strip_tags($wuliulist['e'])?></textarea>';
                html += '</div>';
                html += '<div class="form-group"><input type="submit" class="btn btn-primary" value="发货"></div>';
            }else{
                html += '<div class="form-group tab_nav">';
                if(order_type != 3){
                    html += '<div class="radio" style="width:33%;float: left;">';
                    html += '<label>';
                    html += '<input type="radio" name="wl_type"  value="1" <?php if($wuliulist['type'] == 1 || !$wuliulist) { ?>checked=""<?php } ?>>';
                    html += '快递发货';
                    html += '</label>';
                    html += '</div>';
                    html += '<div class="radio" style="width:33%;float: left;margin-top: 10px;">';
                    html += '<label>';
                    html += '<input type="radio" name="wl_type"  value="3" <?php if($wuliulist['type'] == 3) { ?>checked=""<?php } ?>>';
                    html += '商家配送';
                    html += '</label>';
                    html += '</div>';
                }else{
                    html += '<div class="radio" style="width:33%;float: left;margin-top: 10px;">';
                    html += '<label>';
                    html += '<input type="radio" name="wl_type"  value="3" checked="">';
                    html += '商家配送';
                    html += '</label>';
                    html += '</div>';
                }

                html += '<div class="radio" style="width:33%;float: left;margin-top: 10px;">';
                html += '<label>';
                html += '<input type="radio" name="wl_type"  value="4" <?php if($wuliulist['type'] == 4) { ?>checked=""<?php } ?>>';
                html += '同城配送';
                html += '</label>';
                html += '</div>';
                html += '</div>';

                html += '<div class=" body_li">';
                <?php if($wuliulist['type']>1) { ?>
                    html += '<div class="form-group " >';
                    html += '<textarea name="e" class="form-control" placeholder="商家配送备注"><?php echo strip_tags($wuliulist['e'])?></textarea>';
                    html += '</div>';
                <?php } else { ?>
                    if(order_type == 3){
                        html += '<div class="form-group " >';
                        html += '<textarea name="e" class="form-control" placeholder="商家配送备注"><?php echo strip_tags($wuliulist['e'])?></textarea>';
                        html += '</div>';
                    }else{
                        html += '<div class="form-group">';
                        <?php if($expressCompanyList) { ?>
                        html += '<select name="companyname" class="form-control">';
                        <?php if(is_array($expressCompanyList)) foreach($expressCompanyList as $ek => $ev) { ?>                        html += '<option value="<?php echo $ek;?>" <?php if($wuliulist['companyname'] == $ek) { ?>checked=""<?php } ?>><?php echo $ev;?>';
                        <?php } ?>
                        html += '</select>';
                        <?php } else { ?>
                        html += '<input class="form-control" value="<?php echo $wuliulist['companyname'];?>" placeholder="<?php echo $aljhtlang['js']['orderlist_2'];?>" name="companyname" >';
                        <?php } ?>
                        html += '</div>';
                        html += '<div class="form-group"><input class="form-control" placeholder="<?php echo $aljhtlang['js']['orderlist_3'];?>" name="worderid" value="<?php echo $wuliulist['worderid'];?>"></div>';
                    }
                <?php } ?>
                html += '</div>';
                //html += '<div class="form-group"><select name="c" class="form-control"><option value="<?php echo $aljhtlang['js']['orderlist_5'];?>">EXPRESS(<?php echo $aljhtlang['js']['orderlist_5'];?>)<option value="<?php echo $aljhtlang['js']['orderlist_6'];?>">POST(<?php echo $aljhtlang['js']['orderlist_6'];?>)<option value="EMS">EMS(EMS)</select></div>';
                html += '<div class="form-group"><input type="submit" class="btn btn-primary" value="<?php echo $aljhtlang['js']['orderlist_7'];?>"></div>';
            }

            html += '</form>';
            layer.open({
                type: 1,
                title: '<?php echo $aljhtlang['js']['orderlist_1'];?>',
                skin: 'layui-layer-rim', //加上边框
                area: ['420px', 'auto'], //宽高
                content: html
            });
        }
    }
    jQuery(document).on('click', '.tab_nav input', function() {
        var index = jQuery(this).val();
        console.log(index);
        var html = '';
        if(index == 3){
            html += '<div class="form-group " >';
            html += '<textarea name="e" class="form-control" placeholder="商家配送备注"><?php echo strip_tags($wuliulist['e'])?></textarea>';
            html += '</div>';
        }else if(index == 4){
            html += '<div class="form-group " >';
            html += '<textarea name="e" class="form-control" placeholder="同城配送备注"><?php echo strip_tags($wuliulist['e'])?></textarea>';
            html += '</div>';
        }else{
            html += '<div class="form-group">';
            <?php if($expressCompanyList) { ?>
            html += '<select name="companyname" class="form-control">';
            <?php if(is_array($expressCompanyList)) foreach($expressCompanyList as $ek => $ev) { ?>            html += '<option value="<?php echo $ek;?>" <?php if($wuliulist['companyname'] == $ek) { ?>checked=""<?php } ?>><?php echo $ev;?>';
            <?php } ?>
            html += '</select>';
            <?php } else { ?>
            html += '<input class="form-control" placeholder="<?php echo $aljhtlang['js']['orderlist_2'];?>" name="companyname" value="<?php echo $wuliulist['companyname'];?>">';
            <?php } ?>
            html += '</div>';
            html += '<div class="form-group"><input class="form-control" placeholder="<?php echo $aljhtlang['js']['orderlist_3'];?>" name="worderid" value="<?php echo $wuliulist['worderid'];?>"></div>';
        }

        jQuery('.body_li').html(html);
    });
    function receipt(orderid,info){
        layer.confirm(info, {
            btn: ['<?php echo $aljhtlang['js']['orderlist_8'];?>'] //按钮
        }, function(){
            layer.load(0, {shade: false});
            jQuery.post('plugin.php?id=aljht&act=admin&op=orderlist&do=receipt<?php echo $urlmod;?>',{"orderid":orderid},function(data){
                tips('<?php echo $aljhtlang['js']['orderlist_10'];?>');
            });
        });
    }
    function delorder(orderid,info){
        layer.confirm(info, {
            btn: ['<?php echo $aljhtlang['js']['orderlist_8'];?>'] //按钮
        }, function(){
            layer.msg('<?php echo $aljhtlang['js']['orderlist_9'];?>', {icon: 16});
            jQuery.post('plugin.php?id=aljht&act=admin&op=orderlist&do=delorder&formhash=<?php echo FORMHASH;?><?php echo $urlmod;?>',{"orderid":orderid},function(data){
                if(data==1){
                    tips('<?php echo $aljhtlang['js']['orderlist_10'];?>');
                }else{
                    tips('<?php echo $aljhtlang['js']['orderlist_13'];?>');
                }
            });
        });
    }
    function buorder(orderid,info){
        layer.confirm(info, {
            btn: ['<?php echo $aljhtlang['js']['orderlist_8'];?>'] //按钮
        }, function(){
            layer.msg('<?php echo $aljhtlang['js']['orderlist_9'];?>', {icon: 16});
            jQuery.post('plugin.php?id=aljht&act=admin&op=orderlist&do=buorder&formhash=<?php echo FORMHASH;?><?php echo $urlmod;?>',{"orderid":orderid},function(data){
                if(data==1){
                    tips('<?php echo $aljhtlang['js']['orderlist_10'];?>');
                }else{
                    tips('<?php echo $aljhtlang['js']['orderlist_13'];?>');
                }
            });
        });
    }
    
    function canorder(orderid,info){
        layer.confirm(info, {
            btn: ['<?php echo $aljhtlang['js']['orderlist_8'];?>'] //按钮
        }, function(){
            layer.msg('<?php echo $aljhtlang['js']['orderlist_9'];?>', {icon: 16});
            jQuery.post('plugin.php?id=aljht&act=admin&op=orderlist&do=canorder&formhash=<?php echo FORMHASH;?><?php echo $urlmod;?>',{"orderid":orderid},function(data){
                if(data==1){
                    tips('<?php echo $aljhtlang['js']['orderlist_10'];?>');
                }else{
                    tips('<?php echo $aljhtlang['js']['orderlist_13'];?>');
                }
            });
        });
    }

    var time_current = (new Date()).valueOf();//获取当前时间
    function PublishList(){
        var dateTime = new Date();
        var difference = dateTime.getTime() - time_current;
        jQuery(".endtime").each(function() {
            var obj = jQuery(this);
            var v = jQuery(this).attr('val-date');
            var r = jQuery(this).attr('date-val');

            if(r == 0){
                return true;
            }
            var endTime = new Date(parseInt(obj.attr('value')) * 1000);

            actionTimer(endTime,v,difference,obj);
        });
    }
    function actionTimer(endTime,arr,difference,obj){
        var iCount = window.setInterval(function() {
            var nowTime = new Date();
            var nMS = endTime.getTime() - nowTime.getTime() + difference;

            var myD = Math.floor(nMS / (1000 * 60 * 60 * 24));
            var myH = Math.floor(nMS / (1000 * 60 * 60)) % 24;
            var myM = Math.floor(nMS / (1000 * 60)) % 60;
            var myS = Math.floor(nMS / 1000) % 60;
            var myMS = Math.floor(nMS / 100) % 10;
            if (myH <= 9) myH = '0' + myH;
            if (myM <= 9) myM = '0' + myM;
            if (myS <= 9) myS = '0' + myS;

            var hh = myM.toString();
            var mm = myS.toString();

            if (myH >= 0 && nMS>0) {
                var str =  "<p class='c_publish_time'><span>" + myD + "</span>" + "<span class='c_colon'>\u5929</span>" + "<span>" + myH + "</span>"  + "<span class='c_colon'>\u65f6</span>" +  "<span>" + hh[0] + "</span>" + "<span>" + hh[1] + "</span>" + "<span class='c_colon'>\u5206</span>" + "<span>" + mm[0] + "</span>" + "<span>" + mm[1] + "</span>" + "<span class='c_colon'>\u79d2</span>" + "<span>" + myMS + "</span>\u5c06\u81ea\u52a8\u6536\u8d27</p>";
                obj.html(str);
            } else {
                obj.html('\u6b63\u5728\u81ea\u52a8\u6536\u8d27');
                window.clearInterval(iCount);
                jQuery.post('plugin.php?id=aljht&act=admin&op=orderlist&do=receipt',{orderid:arr},function(data){
                    location.href = location.href;
                });
            }
        }, 100);
    }
    PublishList();
</script>