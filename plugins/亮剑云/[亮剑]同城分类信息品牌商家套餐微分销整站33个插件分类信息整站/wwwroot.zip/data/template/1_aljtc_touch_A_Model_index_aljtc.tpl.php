<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('aljtc');?><?php include template('aljtc:A_Model/header'); if($city_info['logo']) { ?>
<img src="<?php echo $city_info['logo'];?>" style="display: none;"/>
<?php } ?>
<script>var auto_lbs=1;</script><?php include template('aljtc:A_Model/index/index_tan_ad'); if(!$ismini && $iswechat && $_G['cache']['plugin']['aljtc']['index_cel_tips']) { include template('aljtc:A_Model/index/index_cel_tips'); } if($_G['cache']['plugin']['aljtc']['index_left_show']) { include template('aljtc:A_Model/index/index_left_bottom'); } ?>
<style>
.regiondiv {
    background: #fff;
    position: fixed;
    top: 40px;
    width: 100%;
    left: 0;
    height: 320px;
    overflow-y: auto;
    z-index: 10000000;
    line-height: 40px;
    display: flex;
}
.aclist_l {
    background: #fff;
    position: relative;;
    top: 0px;
    width: 100%;
    left: 0;
    height: 320px;
    overflow-y: auto;
    flex: 1;
}

.global-header{
background: none;
}
.color-header {
position: fixed;
    background: rgb(249, 105, 105);
}
.blank8 {
overflow: hidden;
clear: both;
height: 10px;
font-size: 0px;
line-height: 0px;
background: #f8f8f8;
}
.line-5 {
overflow: hidden;
clear: both;
height: 10px;
font-size: 0px;
line-height: 0px;
background: #f8f8f8;
}

.pr {
position: relative
}

.search-bar a.new_search {
display: block;
position: absolute;
height: 40px;
width: 100%;
z-index: 10
}

.search-bar form {
height: 40px
}

.search-bar input {
border: 0;
-webkit-border-radius: 20px;
padding: 0 4px 0 34px;
width: 90%;
height: 30px;
line-height: 30px;
background: rgba(255,255,255,0.8);
font-size: 14px;
color: #999;
-webkit-appearance: none
}
.search-bar:before, .sn-search-input:before, .sn-search-top input:before {
content: "";
position: absolute;
left: 25px;
top: 13px;
width: 14px;
height: 16px;
background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAcCAYAAACQ0cTtAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QAAAAAAAD5Q7t/AAAACXBIWXMAAAsSAAALEgHS3X78AAACZUlEQVRIx7WWu2tUQRSHv6yPxcZHBIM2ii+IgogxBkllE6JZxUKLFS1SHSGtBGWDa0xE/QMETxtZLOwSXGIau+jiA60CuoVWIvjASnSRtZiZ3bPXm91N9nqquWdmft+cw9w5p4sWpqr7gSHgBLAX2OqnvgJl4CmwICLvWml1NYEMAleBvlYi3l4Bt0VksW2Yqm4ApoFsm5CoPQQmRORnU5iqbgEeAEeMuwIUgXngJfAJSAM9QC8wDJwF1pk9r4FLIvI9FuYjehQBzfrUfGwWiqruBK4BZyLA8zbCtWbypgH9AXIiMtNO3vxhLqvqInALWOO1poArYV3Kn2wQuGD2T7cLikBnPCxY1mvXYcC4SemsiOhKQQZ436cfrzleg6nqQaDff/8G8qsFGct7LYB+zyAFjJhFcyLyuVOS15gzrpEAO2ac8wlEFac1EGB7jHMpQdhbM94dYN3G2XEKl9HqDrCqcVYShP1jKcA+KdsS1O4x428BVjbOwwnCrFY5wJ4b58kEYcNmXAqwonFmVHVHpxRV3Q6cNq7HACkRWQpkXJm4kUBUk9RLTskzam/jHeq3MqOqox1ENQpk/GfVa1ODiUgJKJg9U6o6tgrQGK6sBCt4baCxnuWBA7g6lAJyqnoUmBSRDy0gu4DrNF6KN0Qe9WhbsBnXFtgmpwIsAE+AF7iXYT3uPzrkAUM0tgUAX4BztuuKa3jSuKp9kSbd1zJWxZWWdBywWSs3gCt8x9sEPQPu4lqKArAxCmx5clXtBU7hysQ+YJOf+gG8x/02xXC9/Z6+GODwStPUtsUAc/8NZoD3gF9A9i+YmrjxJaFx6gAAAABJRU5ErkJggg==);
background-size: 14px 16px;
}
</style>
<body>
<main class="indexcontent">
<div class="search_banner"><?php include template('aljtc:A_Model/index/index_header'); ?><div class="regiondiv" style="display: none;" id="allregion">
<ul class="region aclist_l"  id="region" style="border-right: 1px solid #e3e3e3;">
<li><a href="javascript:;" onclick="alldata()">&#20840;&#37096;</a></li><?php if(is_array($regionlist)) foreach($regionlist as $tmp_key => $tmp_value) { ?><li>
<a onclick="region_1(<?php echo $tmp_value['id'];?>,this)" href="javascript:;"><?php echo $tmp_value['subject'];?><b></b></a>
</li>
<?php } ?>
</ul>
<ul class="subregion aclist_l"  id="subregion">
<?php if($_COOKIE['rname']) { $subregion = DB::fetch_first('select * from %t where id=%d',array('aljtc_region',$_COOKIE['subrid']))?><?php $upregion = DB::fetch_all('select * from %t where upid=%d',array('aljtc_region',$subregion['upid']))?><?php if(is_array($upregion)) foreach($upregion as $tmp_key => $tmp_value) { ?><li><a onclick="postarea(<?php echo $tmp_value['id'];?>,'<?php echo $tmp_value['subject'];?>');" href="javascript:;"><?php echo $tmp_value['subject'];?></a></li>
<?php } } ?>

</ul>
</div><?php include template('aljtc:A_Model/index/index_lz'); ?></div>
   	<?php if(!$hide_mini) { if($v_p_num) { include template('aljtc:A_Model/index/index_tj'); } } if($mobile_index_new_dh_types) { include template('aljtc:navigation/navigation'); } if(!$hide_mini) { include template('aljtc:A_Model/index/index_row_four_grids'); include template('aljtc:A_Model/index/index_hot'); include template('aljtc:A_Model/index/index_ckad'); include template('aljtc:A_Model/index/mobile_index_Photo_Ads'); if($settings['mobile_index_ad']['value']) { include template('aljtc:A_Model/index/index_mobile_index_ad'); } if($settings['sangead']['value'] && $is_aljad) { include template('aljtc:A_Model/index/index_sangead'); } if($settings['hengfuad']['value'] && $is_aljad) { ?>
<div style="padding:0 1%"><?php echo htmlspecialchars_decode($settings['hengfuad']['value'])?></div>
<div class="line-5"></div>
<?php } if(($settings['rec_brand']['value'] == 1 || $settings['rec_brand']['value'] == 2) && $recommendlist) { include template('aljtc:A_Model/index/index_rec_brand'); } if($settings['index_list_top_lz_ad']['value']) { include template('aljtc:A_Model/index/index_list_top_lz_ad'); } } include template('aljtc:A_Model/index/index_list'); ?></main>

<script>
var swiper = new Swiper('#a_banner', {
pagination: '.swiper-pagination',
paginationClickable: true,
spaceBetween: 30,
autoplay: 5000,
});

</script><?php include template('aljtc:A_Model/index/index_map_js'); include template('aljtc:A_Model/index/index_list_js'); include template('aljtc:A_Model/footer'); ?></body>
</html>
