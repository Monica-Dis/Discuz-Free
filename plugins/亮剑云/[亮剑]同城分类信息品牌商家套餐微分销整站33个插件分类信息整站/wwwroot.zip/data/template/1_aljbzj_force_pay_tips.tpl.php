<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<script src="source/plugin/aljht/static/js/jquery-2.2.3.min.js" type="text/javascript"></script>
<?php if($post == 1) { ?>
<script>
    parent.layer.alert('需要缴纳保证金后才能发布商品哦，点击确定前往缴纳！', {fixed:false,top:30,closeBtn: 0},function(){
        var purl = {'bid':'<?php echo $bid;?>'};
        $.post('plugin.php?id=aljbzj&c=aljbzj&a=isBzj',purl,function (res) {
            if(res == 1){
                parent.layer.closeAll();
            }else{
                parent.iframebood('<?php echo $bid;?>');
            }
        },'json');
        
    });
</script>
<?php } else { include template('aljbzj:bood_iframe'); if($_G['cache']['plugin']['aljbzj']['is_force_pay'] && $bzj_info['price'] <= 0 && $bid && !$administrators) { ?>
<script>
    $(function() {
        layer.alert('需要缴纳保证金后才能发布商品哦，点击确定前往缴纳！', {fixed:false,top:30,closeBtn: 0},function(){
            var purl = {'bid':'<?php echo $bid;?>'};
            $.post('plugin.php?id=aljbzj&c=aljbzj&a=isBzj',purl,function (res) {
                if(res == 1){
                    parent.layer.closeAll();
                }else{
                    iframebood('<?php echo $bid;?>');
                }
            },'json');
        });
    });
</script>
<?php } } ?>