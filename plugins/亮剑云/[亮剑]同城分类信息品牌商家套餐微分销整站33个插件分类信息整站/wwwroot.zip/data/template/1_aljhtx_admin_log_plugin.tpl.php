<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template(PLUGIN_ID.':admin/header')?><style>
    body{ font-size: 14px; }
    tr th{
        color:#666;
        font-size: 14px;
    }
    .info-box-number{
        margin-top:5px;
        margin-left:5px;
    }
    .info-box-text{
        margin-top:10px;
    }
    .layui-table-body{overflow-x: hidden;}
    .content-wrapper{background-color: #ffffff;}
    .layui-laypage-limits select{margin-top:2px;}
    .box.box-default {
        border-top-color: #e6e6e6;
    }
    .box {
        position: relative;
        border-radius: 3px;
        background: #fff;
        border-top: 1px solid #e6e6e6;
        margin-bottom: 20px;
        width: 100%;
        box-shadow: 0 1px 1px rgba(0,0,0,0.1);
    }
    .nav-tabs {
        border-bottom: none;
    }
    .box.box-primary {
        border-top-color: #e6e6e6;
    }
    .btn-primary {
        background-color: #009688;
        border-color: #009688;
    }
</style>
<div class="content-wrapper" style="margin-left:0px">
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div style="float: left;">
                    <ul class="nav nav-tabs" role="tablist" >
                        <li <?php if(!$_GET['act']) { ?>class="active"<?php } ?>><a href="plugin.php?id=aljhtx&amp;c=log&amp;a=plugin">全部</a></li>
                        <li <?php if($_GET['act'] == 'yes') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljhtx&amp;c=log&amp;a=plugin&amp;act=yes">已安装插件</a></li>
                        <li <?php if($_GET['act'] == 'no') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljhtx&amp;c=log&amp;a=plugin&amp;act=no">未安装插件</a></li>
                        <li ><a href="https://addon.liangjianyun.com/plugin.php?id=aljhy&amp;act=sn_list" target="_blank">我的授权</a></li>
                    </ul>
                </div>
                <div style="position: absolute;right:15px;">

                    <a style="float: right;margin-left: 10px;" class="layui-btn" target="_blank" href="<?php echo $param_url;?>">进入应用中心</a>
                    <a style="float: right;" class="layui-btn layui-btn-primary update_app" href="javascript:;">更新缓存</a>
                </div>
            </div>
            <!-- /.col -->
            <div class="col-md-12">
                <div class="box box-primary">
                    <!-- /.box-header -->

                            <iframe style="display:none;" name="submitiframe"></iframe>
                            <form name="cpform" id="admingoodssubmit" method="post" autocomplete="off" action="<?php echo $dourl;?>" target="submitiframe">
                                <input type="hidden"  value="0" name="sign" id="sign">
                                <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>">
                            </form>

                            <table id="demo" lay-filter="test"></table>
                        </div>
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
</div>
<script>


var R = {
        options: {
            formhash: '<?php echo FORMHASH;?>',
        },
    init: function(){
            layui.use('table', function(){
                var table = layui.table;
                var tableIns = table.render({
                    elem: '#demo'
                    ,limit: 100
                    ,url: 'plugin.php?id=aljhtx&c=log&a=plugin&ajax=yes&render=yes&act=<?php echo $_GET['act'];?>'
                    ,page: false
                    ,skin: 'line'
                    ,even: true
                    ,cols: [[
                        {field: 'name', title: '插件名称', width:300, sort: true}
                        ,{field: 'identifier', title: '插件标识', width:100, sort: true}
                        ,{field: 'intro', title: '功能介绍'}
                        ,{width:220, align:'center', templet: function(d){
                            var btn_html = '';
                            if(d.is_install == 1){
                                if(d.is_update){
                                    btn_html += '<a  target="_blank" href="'+d.is_update_url+'" class="layui-btn layui-btn-warm layui-btn-xs">更新</a>'
                                }
                            }else{
                                btn_html += '<a  target="_blank" href="'+d.is_update_url+'" class="layui-btn layui-btn-warm layui-btn-xs">立即安装</a>'
                            }
                            if(d.is_install == 1 && d.type != 'pack'){
                                if(d.available == 1){
                                    btn_html += '&nbsp;&nbsp;<a href="plugin.php?id=aljhtx&amp;c=log&amp;a=download&amp;operation=disable&amp;ajax=yes&amp;formhash=<?php echo FORMHASH;?>&amp;pluginid='+d.pluginid+'" onclick="layer.load(0, {shade: false});" class="layui-btn layui-btn-normal layui-btn-xs "><span >关闭</span></a>';
                                }else{
                                    btn_html += '&nbsp;&nbsp;<a href="plugin.php?id=aljhtx&amp;c=log&amp;a=download&amp;operation=enable&amp;ajax=yes&amp;formhash=<?php echo FORMHASH;?>&amp;pluginid='+d.pluginid+'" onclick="layer.load(0, {shade: false});" class="layui-btn layui-btn-primary layui-btn-xs"><span >启用</span></a>';
                                }
                                btn_html += '<a href="plugin.php?id=aljhtx&amp;c=log&amp;a=download&amp;operation=delete&amp;ajax=yes&amp;pluginid='+d.pluginid+'" onclick="layer.load(0, {shade: false});" class="layui-btn layui-btn-danger layui-btn-xs">卸载</a>'
                                <?php if(file_exists('liangjianyun.php')) { ?>
                                btn_html += '&nbsp;&nbsp;<a href="liangjianyun.php?a=download&amp;c=log&amp;operation=config&amp;do='+d.pluginid+'&amp;ajax=yes" onclick="layer.load(0, {shade: false});" class="layui-btn layui-btn-xs "><span >设置</span></a>';
                                <?php } ?>
                            }
                            
                            return btn_html;

                        }}
                    ]]
                });
                $('.glyphicon-search').on('click', function(){
                    tableIns.reload({
                        where: {
                            search: $('#search').val()
                        }
                        ,page: {
                            curr: 1
                        }
                    });
                });
                $('.update_app').on('click', function(){
                    var url = 'plugin.php?id=aljhtx&c=log&a=plugin&ajax=yes&render=update_app';
                    layer.load(0, {shade: false});
                    $.post(url,function(res) {
                        layer.closeAll('loading');
                        layer.msg('更新成功', function(){
                            location.href = location.href;
                        });
                    },'json');
                });
            });
        }
    }
    R.init();
</script><?php include template(PLUGIN_ID.':admin/footer')?>