<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('header_head');?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=<?php echo CHARSET;?>"/>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" name="viewport" >
    <title><?php echo $navtitle;?></title>
    <meta name="description" content="<?php echo $metadescription;?>" />
    <meta name="keywords" content="<?php echo $metakeywords;?>" />
    <?php if($_G['cache']['plugin']['aljhtx']['base_url']) { ?>
        <base href="<?php echo $_G['cache']['plugin']['aljhtx']['base_url'];?>" />
    <?php } else { ?>
        <base href="<?php echo $_G['siteurl'];?>" />
    <?php } ?>
    <link rel="stylesheet" href="source/plugin/aljbd/css/sj/base.css?<?php echo VERHASH;?>" />
    <script src="<?php echo $common_path;?>/static/js/jquery-2.2.3.min.js?<?php echo VERHASH;?>" type="text/javascript" charset="utf-8"></script>
    <link rel="stylesheet" href="<?php echo $common_path;?>/static/weui/css/weui.min.css?<?php echo VERHASH;?>">
<link rel="stylesheet" href="<?php echo $common_path;?>/static/weui/css/jquery-weui.min.css?<?php echo VERHASH;?>">
    <script src="<?php echo $common_path;?>/static/weui/js/jquery-weui.min.js?<?php echo VERHASH;?>" type="text/javascript" charset="utf-8"></script>
    <script src="<?php echo $common_path;?>/static/weui/js/fastclick.js?<?php echo VERHASH;?>" type="text/javascript" charset="utf-8"></script>
    <script>
    $(document).ready(function() {
        FastClick.attach(document.body);
    });

    </script>
    <?php if($_GET['id'] == 'aljms') { ?>
    <style>
    html{font-size: 16px;}
    body{line-height: normal;}
    </style>
    <?php } ?>
   
    <script src="source/plugin/aljbd/js/sj/jquery.lazyload.min.js?<?php echo VERHASH;?>" type="text/javascript"></script>
    <?php include template('aljbd:common'); ?>    <?php if($c['pic'] && $_GET['act'] == 'consumeview') { ?>
    <div id='wx_pic' style='margin:0 auto;display:none;'>
        <img src="<?php echo $c['pic'];?>" />
    </div>
    <?php } elseif($g['pic1'] && $_GET['act'] == 'goodview') { ?>
    <div id='wx_pic' style='margin:0 auto;display:none;'>
        <img src="<?php echo strpos($g['pic1'],$oss_domain) !== false?$g['pic1'].'?x-oss-process=image/resize,m_fill,h_200,w_200':$g['pic1']?>" />
    </div>

    <?php } elseif($bd['logo'] && $_GET['act'] == 'view') { ?>
    <div id='wx_pic' style='margin:0 auto;display:none;'>
        <img src="<?php echo $bd['logo'];?>" />
    </div>
    <?php } ?>
    <?php if($g) { ?>
    <script>(function(a,d){var b=a.documentElement,e="orientationchange"in window?"orientationchange":"resize",c=function(){var a=b.clientWidth;a&&(b.style.fontSize=640<=a?"40px":a/320*20+"px")};a.addEventListener&&(d.addEventListener(e,c,!1),a.addEventListener("DOMContentLoaded",c,!1))})(document,window);</script>
    <?php } ?>

</head>
<body id="body">
<?php if($hidegoback) { ?>
<script>
    document.body.classList.add("hidegoback");
</script>
<style>
    .hidegoback .hide-back{display: none !important;}
</style>
<?php } include template('aljbd:new/common/loading'); ?><div id="append_parent"></div>
<a name="top"></a>
<?php if($_GET['act'] != 'type' && $_GET['act'] != 'search' && $_GET['op'] != 'btype' && $_GET['op'] != 'search') { include template('aljbd:header'); } ?>

<!-- ��Ʒ���� -->

<?php if((!$_GET['act'] || (($_GET['act'] == 'view' || $_GET['act'] == 'goodview') && !$_GET['op'])) && ($_GET['id'] == 'aljbd' || $_GET['id'] == 'aljbd:aljbd' || !$_GET['id'])) { ?>
<!-- ��ҳ/�������� -->
<script>
    function b_header(){

        $(document).on('touchmove',function(e) {
            if($(window).scrollTop()>=5){
                $(".header").css({position:"fixed",top:"0",left:"0",height:'50px',background:"<?php echo $mobilenavbackcolor;?>"})
                <?php if($_GET['act'] == 'goodview') { ?>
                $(".header").show();
                $(".hide-header").hide();
                <?php } ?>
            }

        })
        $(window).scroll(function(){
            if($(window).scrollTop()<=5){
                $(".header").css({position:"absolute",height:'<?php echo 54+$immersed;?>px',background:'none'})
                <?php if($_GET['act'] == 'goodview') { ?>
                $(".header").hide();
                $(".hide-header").show();
                <?php } ?>
            }else if($(window).scrollTop()>=5){
                $(".header").css({position:"fixed",top:"0",left:"0",height:'50px',background:"<?php echo $mobilenavbackcolor;?>"})
                <?php if($_GET['act'] == 'goodview') { ?>
                $(".header").show();
                $(".hide-header").hide();
                <?php } ?>
            }
        })

    }
    $(function(){
        b_header();
    });
</script>
<?php } ?>

