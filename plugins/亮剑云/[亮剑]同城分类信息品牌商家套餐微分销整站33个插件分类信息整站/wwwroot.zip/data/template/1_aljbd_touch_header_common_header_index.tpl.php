<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if(!$settings['is_lz_search']['value'] && !$nosearch) { ?>
<header>
    <div class="header" style="background: none;border-bottom: 0px solid #dd2726;position: absolute;z-index: 999;width:100%;">
        <div class="search-content wbox" style="position: relative; background: none;width:100%;">
            
            <a class="navigateTo class"  href="<?php if($index_img_s_types['0']['1']) { ?><?php echo $index_img_s_types['0']['1'];?><?php } else { ?>plugin.php?id=aljbd&act=type&mobile=2<?php } ?>"></a>
            <div class="wbox-flex search-bar pr">
                <a  class="new_search navigateTo" href="plugin.php?id=<?php echo $pluginid;?>&amp;act=search"></a>
                <form><input id="searchInput"  type="text" placeholder="<?php if($config['m_search_default']) { ?><?php echo $config['m_search_default'];?><?php } else { ?>&#35831;&#36755;&#20837;&#24744;&#24819;&#25214;&#30340;&#21830;&#21697;&#25110;&#24215;&#38138;<?php } ?>" autocomplete="off"></form>
            </div>
            <div class="my-cart pr">
                <div class="icon"></div>
                <a class="navigateTo" id="cartnum" href="<?php if($index_img_s_types['1']['1']) { ?><?php echo $index_img_s_types['1']['1'];?><?php } else { ?>plugin.php?id=aljbd&act=attend&mobile=2<?php } ?>"></a>
            </div>
        </div>
    </div>
</header>
<?php } ?>