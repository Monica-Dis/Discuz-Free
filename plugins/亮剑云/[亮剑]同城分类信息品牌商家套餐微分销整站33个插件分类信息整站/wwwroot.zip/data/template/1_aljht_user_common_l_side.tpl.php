<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>

<link href="source/plugin/aljbd/css/sj/iconfont/iconfont.css?<?php echo VERHASH;?>" rel="stylesheet">
<script src="source/plugin/aljhtx/static/js/layer/layer.js?20181220" type="text/javascript" type="text/javascript" charset="utf-8"></script>
<link rel="stylesheet" href="source/plugin/aljhtx/static/layui/css/layui.css">
<script src="source/plugin/aljhtx/static/layui/layui.js" type="text/javascript"></script>
<style type="text/css">
body{
font: 12px/1.5 Tahoma,Helvetica,"SimSun",sans-serif;
    }
    .layui-table-cell{height:auto;}
</style>
<style>
.mgr10 {
    margin-right: 10px;
}
.w120 {
    width: 120px !important;
}
.imitate_select {
    float: left;
    position: relative;
    border: 1px solid #d2d2d2;
    height: 28px;
    line-height: 28px;
    font-size: 12px;
}
.imitate_select .cite {
    background: #fff;
    padding: 0 10px;
    cursor: pointer;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    text-align: left;
}
.imitate_select .cite i.iconfont {
    font-size: 12px;
    height: 12px;
    line-height: 12px;
    float: right;
    margin-top: 9px;
}
.layui-laypage .layui-laypage-curr .layui-laypage-em {
    background-color: <?php echo $_G['cache']['plugin']['aljbd']['color_daohang'];?>;
}
.layui-form-checked[lay-skin=primary] i {
    border-color: <?php echo $_G['cache']['plugin']['aljbd']['color_daohang'];?>!important;
    background-color: <?php echo $_G['cache']['plugin']['aljbd']['color_daohang'];?>;
}
.user-title h2:before {
    background: <?php echo $_G['cache']['plugin']['aljbd']['color_daohang'];?>;
}
.user-side .side-menu dd .current a {
    color: <?php echo $_G['cache']['plugin']['aljbd']['color_daohang'];?>;
}
.user-title .tabs li:hover a, .user-title .tabs li.active a {
    color: <?php echo $_G['cache']['plugin']['aljbd']['color_daohang'];?>;
}
.user-title .tabs li.active {
    border-bottom-color: <?php echo $_G['cache']['plugin']['aljbd']['color_daohang'];?>;
}
.no_records{ height:104px; padding:70px 0 70px 165px; width:auto; position:relative; overflow:hidden;}
.no_records .no_icon{ width:159px; height:104px; display:block; float:left; background:url(source/plugin/aljht/static/img/not-common-icon.png) no-repeat;}
.no_records .no_info{ float:left; margin-left:25px; line-height:104px; max-width:500px;}
.no_records .no_info_line{ line-height:normal;}
.no_records h3{ color:#8c8c8c; font-size:16px; font-weight:bold; display:block;}

.no_records .no_info_line h3{ margin-top:8px;line-height:25px;}
.no_records .no_info_line .no_btn{ display:block; margin-top:15px;}

.no_records .no_icon_two{ width:188px; height:104px; display:block; float:left; background:url(source/plugin/aljht/static/img/not-wait-icon.png) no-repeat;}
.no_records .no_icon_three{ width:186px; height:129px; display:block; float:left; background:url(source/plugin/aljht/static/img/not-comment.png) no-repeat;}

.no_records_tc{ padding-left:400px;}

.no_records_1200{ padding-left:330px;}
</style>
<div class="user-side" ectype="userSide">
    <div class="user-perinfo-ny">
        <div class="profile clearfix">
            <div class="avatar">
                <a href="plugin.php?id=aljht&amp;act=user" class="u-pic">
                    <?php echo avatar($_G['uid'], 'middle')?>                </a>
            </div>
            <div class="name">
                <h2><?php echo $_G['username'];?></h2>
                <div><?php echo $_G['group']['grouptitle'];?></div>
            </div>
        </div>
    </div>
    <div class="user-mod">
        
<div class="side-menu">
<dl>
    <dt><i class="square"></i><span>订单中心</span></dt>
    <dd>
        <p <?php if(!$_GET['op'] || $_GET['op'] == 'orderlist') { ?>class="current"<?php } ?>><a href="plugin.php?id=aljht&amp;act=user&amp;op=orderlist" target="_self">我的订单</a></p>
        <p <?php if($_GET['op'] == 'addresslist') { ?>class="current"<?php } ?>><a href="plugin.php?id=aljht&amp;act=user&amp;op=addresslist" target="_self">收货地址</a></p>
    </dd>
</dl>
<dl>
    <dt><i class="square"></i><span>会员中心</span></dt>
    <dd>
        <?php if($_G['cache']['plugin']['aljsyy']['is_yy']) { ?>
        <p <?php if($_GET['op'] == 'appointment_list') { ?>class="current"<?php } ?>><a href="plugin.php?id=aljht&amp;act=user&amp;op=appointment_list&amp;state=2" target="_self">我的预约</a></p>
        <?php } ?>
        <?php if($_G['cache']['plugin']['aljgz']['is_gz']) { ?>
        <p <?php if($_GET['op'] == 'collection') { ?>class="current"<?php } ?>><a href="plugin.php?id=aljht&amp;act=user&amp;op=collection" target="_self">我的收藏</a></p>
        <?php } ?>
        <?php if($_G['cache']['plugin']['aljbdx']) { ?>
        <p <?php if($_GET['op'] == 'commentlist') { ?>class="current"<?php } ?>><a href="plugin.php?id=aljht&amp;act=user&amp;op=commentlist" target="_self">我的晒单</a></p>
        <?php } ?>
        <p <?php if($_GET['op'] == 'replylist') { ?>class="current"<?php } ?>><a href="plugin.php?id=aljht&amp;act=user&amp;op=replylist" target="_self">我的评论</a></p>
    </dd>
</dl>
<?php if($_G['cache']['plugin']['aljsyh'] || $_G['cache']['plugin']['aljqb']) { ?>
<dl>
    <dt><i class="square"></i><span>账户中心</span></dt>
    <dd>
        <?php if($_G['cache']['plugin']['aljsyh']) { ?>
        <p <?php if($_GET['op'] == 'coupons') { ?>class="current"<?php } ?>><a href="plugin.php?id=aljsyh&amp;a=couponList&amp;c=voucher&amp;op=coupons" target="_self">我的优惠券</a></p>
        <?php } ?>
        <?php if($_G['cache']['plugin']['aljqb']) { ?>
        <p <?php if($_GET['op'] == 'wallet') { ?>class="current"<?php } ?>><a href="plugin.php?id=aljht&amp;act=user&amp;op=wallet" target="_self">我的钱包</a></p>
        <?php } ?>
    </dd>
</dl>
<?php } ?>
</div>        </div>
</div>
<script>
// 用户菜单展开效果
(function($, window, undefined) {
$(".user-side .side-menu dt .square").click(function(){
    var that = lj_jq(this);
    var dd = that.parent("dt").siblings("dd");
    that.toggleClass("square-plus");
    dd.slideToggle();
});
})(jQuery, window);
</script>