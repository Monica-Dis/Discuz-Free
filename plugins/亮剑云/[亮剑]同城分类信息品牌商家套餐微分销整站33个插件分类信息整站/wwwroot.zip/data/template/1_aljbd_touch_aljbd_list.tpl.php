<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include template('aljbd:header/header_head'); ?><link rel="stylesheet" href="source/plugin/aljbd/css/sj/index.css?<?php echo VERHASH;?>" />
<?php if($_GET['mobilediy'] == 'yes') { ?>
<script>
    $(function(){
        var R = {
            options: {

            },
            init: function(){
                $('.swiper-container').css({'border':'1px solid red'});
                $('a').attr('href', 'javascript:;');
                $('.diyDocument').click(function(){
                    $('.diyDocument').css('border', 'none');
                    $(this).css('border', '1px solid red');
                    parent.R.followChange($(this).attr('diy-id'));
                });
            }
        };
        R.init();
    });
</script>
<style>
body{overflow-x: hidden;min-width: 305px;}
</style>
<?php } if($_G['cache']['plugin']['aljbd']['mobile_index_tan_ad'] && $_GET['mobilediy'] != 'yes') { include template('aljbd:index/index_tan_ad'); } ?>
<link rel="stylesheet" media="screen,projection,tv" href="source/plugin/<?php echo $pluginid;?>/template/touch/round_robin/round_robin.css?<?php echo VERHASH;?>" /></link>
<?php if($config['sj_index_lz'] || $settings['aljad_index_lz']['value']) { ?>
<!-- ͼƬ�ߴ� 304X80 -->
<style type="text/css">
.swiper-container {
    width:100%;
    height:<?php if($settings['mobile_lz_height']['value']) { ?><?php echo $settings['mobile_lz_height']['value'];?>px<?php } else { ?>auto<?php } ?>;
    margin:0 auto;
    overflow: hidden;
}
</style>
<div class="swiper-container diyDocument" diy-id="swiper-container">
    <div class="swiper-wrapper" >
<?php if($settings['aljad_index_lz']['value']) { if(is_array($aljad_index_lz)) foreach($aljad_index_lz as $ad) { ?><div class="swiper-slide" >
<?php echo $ad;?>
</div>
<?php } } else { if(is_array($lz_types)) foreach($lz_types as $k => $v) { ?><div class="swiper-slide" >
<a href="<?php echo $v['1'];?>">
<img src="<?php echo $k;?>"  alt="<?php echo $v['2'];?>" width="100%" height="<?php if($settings['mobile_lz_height']['value']) { ?><?php echo $settings['mobile_lz_height']['value'];?>px<?php } else { ?>auto<?php } ?>">
</a>
</div>
<?php } } ?>
    </div>
<?php if(!$settings['aljad_index_lz']['value'] && !file_exists("source/plugin/aljbd/act/skzx.php") && !$settings['is_wave']['value']) { ?>
<div class="water">
<div class="water-c">
<div class="water-1"></div>
<div class="water-2"></div>
</div>
</div>
<?php } ?>
</div>
<?php } ?>

<style type="text/css">
.search-keyword{background:#fff;border:0 solid #f8f8f8;box-shadow:none}.search-button{position:absolute;display:inline-block;right:10px;top:12px;font-size:0;line-height:0;text-indent:-999px;border:0;width:30px;height:25px;background-position:-605px 6px;vertical-align:middle}.search{position:relative;background:#fff;margin-top:8px}.icon18{background:url(source/plugin/aljbd/images/sj/search_v.png) no-repeat center center;background-size:20px}
</style>
<div class="panel-body search" style="display:none">
    <form action="plugin.php?id=aljbd&amp;act=dianpu" method="post" enctype="multipart/form-data" style="border:1px solid #eee;" accept-charset="utf-8">
        <input type="hidden" value="<?php echo FORMHASH;?>" name="formhash">
<input type="text" class="search-keyword"  name="kw" placeholder="搜索商家">
<input type="submit" class="icon18 icon18-search search-button" value="搜索商家" name="submit">
    </form>
</div>
<script type="text/javascript">
$(function() {
$('#search_l').toggle(function(){$('.search').show();},function(){$('.search').hide();}); 
});
</script>

<?php if($aljad_index_lz_lower) { ?>
<div style="width:100%; height:auto;" class="aljbd_ad">
<?php echo $aljad_index_lz_lower;?>
</div>
<?php } if($settings['mobile_index_ad_1']['value']) { ?>
<div style="width:100%; height:auto;" class="aljbd_ad">
   <?php echo htmlspecialchars_decode($settings['mobile_index_ad_1']['value']);?></div>
<?php } ?>

<div class="activities1">
    <div class="container">
        <!-- �Ź��� --><?php foreach($diyList as  $diy){
include template('aljbd:diy/'.$diy['page'].'/'.$diy['module']);
if($diy['module'] == 'gg' && $ms_goods_list && $_G['cache']['plugin']['aljms']['is_aljms']){
include template('aljbd:diy/index/mobile_index_ms');
}
}?><?php include template('aljbd:three_lattice_ad/three_lattice_ad'); ?><style type="text/css">
.list_title{position:relative;text-indent:10px;font-size:15px;padding:5px 0;line-height:20px;margin-left:10px;background: #ffffff;}.list_title:before{content:" ";height:17px;position:absolute;left:0;top:6px;border-left:2px solid<?php if($settings['mobilenavbackcolor']['value']) { ?><?php echo $settings['mobilenavbackcolor']['value'];?><?php } else { ?>#DD2726<?php } ?>}.c_goods_size{width:96%;margin:5px 2%}.c_goods_size a{display:block;width:100%}.c_goods_details dd h2{color:#666;font-size:12px;width:94%;margin:0 3%;line-height:14px}.c_goods_details dd p span{margin-left:10%}.c_goods_details{width:100%;padding-top:5px;overflow:hidden}.c_goods_details dd{width:50%;float:left;position:relative}dd{margin-left:0}*{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.c_new_goods{width:100%;padding-bottom:10px}.c_goods_title{width:100%;height:42px;background:#fff;border-bottom:1px solid #eee}.c_newgoods_title{position:fixed;top:0;left:0;z-index:20}.c_goods_title li{float:left;width:25%;line-height:40px;height:40px;text-align:center;font-size:14px;color:#666}.c_goods_title .c_hot_color{color:#dd2726}.c_goods_details dd p{color:#666;font-size:12px;width:90%;margin:0 3% 10px;line-height:14px}#dataList dd{border-bottom:1px solid #f8f8f8;border-right:1px solid #f8f8f8}
</style>
<?php if($recommendlist_goods_index && !$settings['close_goods']['value'] && !$settings['is_mobile_index_love_type']['value'] && !$settings['is_mobile_index_love_rec']['value']) { ?>

<div class="blank8"></div>
<!--�Ƽ���Ʒ-->

<div class="list-view">
<div class="list_title">推荐商品<a style="float:right;margin-right:10px" href="plugin.php?id=aljbd&amp;act=goods">&#26356;&#22810;</a></div>
<?php if(!$settings['is_mobile_index_resgoods']['value']) { ?>

<link rel="stylesheet" media="screen,projection,tv" href="source/plugin/<?php echo $pluginid;?>/template/touch/round_robin/navigation.css?<?php echo VERHASH;?>" /></link>
<div class="s_index_icon swiper-container1 swiper-container-horizontal">
        <div class="swiper-wrapper" id="c_main_Prefecture">
   <!-- ͼƬ���� -->
   <?php $rk = 0;?>   <?php if(is_array($recommendlist_goods_index)) foreach($recommendlist_goods_index as $recommend) { $rk++?><?php if($rk%2==1) { ?>
<dl class="c_goods_details swiper-slide" >
<?php } ?>
<dd >
<div class="c_goods_size">
<a class="navigateTo" href="plugin.php?id=aljbd&amp;act=goodview&amp;bid=<?php echo $recommend['bid'];?>&amp;gid=<?php echo $recommend['id'];?>">
<img  src="<?php if($recommend['pic1']) { ?><?php echo $recommend['pic1'];?><?php } else { ?><?php echo $noimg;?><?php } ?>" class="img-responsive c_img" style="width: 140px;height:140px;margin:0 auto; display: block;" >
</a>
</div>
<a class="navigateTo" style="font-size: 14px;color: #333;text-align: left;margin-bottom: 8px;" href="plugin.php?id=aljbd&amp;act=goodview&amp;bid=<?php echo $recommend['bid'];?>&amp;gid=<?php echo $recommend['id'];?>"><?php echo $recommend['name'];?></a>
<h2 style="font-size:12px;margin:0;">

<?php if($recommend['price1']) { ?>
<strong style="color:red;font-size:12px;">
<?php if($_G['cache']['plugin']['aljgwc'][$pluginid]) { ?>
<?php echo $price_unit;?><?php echo number_format($recommend['price1'],2);?><?php } else { ?>
 	<?php if($config['isextcredit'] && $config['extcredit']) { ?>
<?php echo $recommend['price1'];?><?php echo $_G['setting']['extcredits'][$config['extcredit']]['title'];?>
<?php } else { ?>
<?php echo $price_unit;?><?php echo number_format($recommend['price1'],2);?><?php } } ?>
</strong>
<?php if(!file_exists("source/plugin/dz_1/dz_1.inc.php")) { ?>
 <?php if($recommend['price2']) { ?>
<del>
<?php if($_G['cache']['plugin']['aljgwc'][$pluginid]) { ?>
<?php echo $price_unit;?><?php echo number_format($recommend['price2'],2);?><?php } else { if($config['isextcredit'] && $config['extcredit']) { ?>
<?php echo $recommend['price2'];?><?php echo $_G['setting']['extcredits'][$config['extcredit']]['title'];?>
<?php } else { ?>
<?php echo $price_unit;?><?php echo number_format($recommend['price2'],2);?><?php } ?>
</del>
<?php } } } ?>
 
<?php } else { ?>
<strong style="color:red;">
面议</strong>
<?php } ?> </h2>

</dd>
<?php if($rk%2==0) { ?>
</dl>
<?php } } ?>
</dl>
</div>
    <div class=" swiper-pagination swiper-pagination-clickable swiper-pagination2"><span class="swiper-pagination-bullet swiper-pagination-bullet-active"></span><span class="swiper-pagination-bullet"></span></div>
    </div>

<?php } else { ?>
<ul class="tuan_ul"><?php if(is_array($recommendlist_goods_index)) foreach($recommendlist_goods_index as $recommend) { ?><li class="tuan_li">
<a class="navigateTo" href="plugin.php?id=aljbd&amp;act=goodview&amp;bid=<?php echo $recommend['bid'];?>&amp;gid=<?php echo $recommend['id'];?>">
 <div class="list_item">
 <div class="pic">
<img <?php if($settings['is_lazyload']['value']) { ?>src="<?php echo $loading;?>" data-original="<?php if($recommend['pic1']) { ?><?php echo $recommend['pic1'];?><?php } else { ?><?php echo $noimg;?><?php } ?>"<?php } else { ?>src="<?php if($recommend['pic1']) { ?><?php echo $recommend['pic1'];?><?php } else { ?><?php echo $noimg;?><?php } ?>"<?php } ?> width="85" height="85" >

 </div>
 <div class="info">
<h2 style="height:38px;line-height:20px;margin:0px 0px 25px 0px"><?php echo $recommend['name'];?></h2>

<div class="tuan_price">
<?php if($recommend['price1']) { ?>
 <p class="price">
 <em>
 <?php if($_G['cache']['plugin']['aljgwc'][$pluginid]) { ?>
 	<?php echo $price_unit;?><?php echo number_format($recommend['price1'],2);?> <?php } else { ?>
 <?php if($config['isextcredit'] && $config['extcredit']) { ?>
<?php echo $recommend['price1'];?><?php echo $_G['setting']['extcredits'][$config['extcredit']]['title'];?>
 <?php } else { ?>
<?php echo $price_unit;?><?php echo number_format($recommend['price1'],2);?> <?php } ?>
 <?php } ?>
 </em>
 <?php if($recommend['price2']) { ?>
 <del>
 <?php if($_G['cache']['plugin']['aljgwc'][$pluginid]) { ?>
 	<?php echo $price_unit;?><?php echo number_format($recommend['price2'],2);?> <?php } else { ?>
 <?php if($config['isextcredit'] && $config['extcredit']) { ?>
<?php echo $recommend['price2'];?><?php echo $_G['setting']['extcredits'][$config['extcredit']]['title'];?>
 <?php } else { ?>
<?php echo $price_unit;?><?php echo number_format($recommend['price2'],2);?> <?php } ?>
 <?php } ?>
 </del>
 <?php } ?>
 </p>
 
<?php } else { ?>
<p class="price">面议</p>
<?php } ?>
<p class="bought"><i></i>浏览<?php echo $recommend['view'];?></p>
 </div>
 </div>
</div>
 </a>
</li>
<?php } ?>
</ul>
<?php } ?>
</div>
<?php } ?>
<!--�Ƽ���Ʒ-->
<div class="blank8"></div>
<?php if($config['isyouh'] && $recommendlist_consume_index && !$settings['close_consume']['value']) { ?>
<!--�Ƽ��Ż�ȯ-->

<div class="list-view">
<div class="list_title">&#25512;&#33616;&#20248;&#24800;&#21048;</div>
<ul class="tuan_ul"><?php if(is_array($recommendlist_consume_index)) foreach($recommendlist_consume_index as $c) { ?><li class="tuan_li">
<a class="navigateTo" href="plugin.php?id=aljbd&amp;act=consumeview&amp;bid=<?php echo $c['bid'];?>&amp;cid=<?php echo $c['id'];?>">
 <div class="list_item">
 <div class="pic">
<img <?php if($settings['is_lazyload']['value']) { ?>src="<?php echo $loading;?>" data-original="<?php echo $c['pic'];?>"<?php } else { ?>src="<?php echo $c['pic'];?>"<?php } ?> width="85" height="85" >
 </div>
 <div class="info">
<h2 style="height:38px;line-height:20px;margin:0px 0px 25px 0px"><?php echo $c['subject'];?></h2>

<div class="tuan_price">

<p class="price"><?php if($c['end']) { echo date('Y-m-d',$c['start']);?>&nbsp;至&nbsp;<?php echo date('Y-m-d',$c['end']);?><?php } else { ?>有效期：&nbsp;&nbsp;不限制<?php } ?></p>

 </div>
 </div>
</div>
 </a>
</li>
<?php } ?>
</ul>
 <div class="see_more">
<a href="plugin.php?id=aljbd&amp;act=clist">&#26597;&#30475;&#20840;&#37096;&#20248;&#24800;&#21048;</a>
 </div>
</div>
<!--�Ƽ��Ż�ȯ-->
<div class="blank8"></div>
<?php } ?>
 <!-- ���ݾۺ� -->
<style type="text/css">
.tabbox .tabs li a.selected{color:#c00;border-bottom:1px solid #c00}.tabbox .tabs-hd{background:#fff;border-top:0;border-bottom:1px solid #eee}.tabbox .tabs li{border-right:0}.tabbox .tab-show .subjects li{float:left;width:32%;height:auto;font-size:12px;padding:0 8px 10px 8px}.app img{border-radius:10px}.tuan_li .list_item .pic{width:85px;height:85px}
</style>
<?php if(!$settings['is_self_support']['value']) { if(!$settings['is_mobile_index_resdp']['value']) { if($recommendlist) { ?>
<div class="tabbox swiper-container2" style="margin:0px;background:#fff;width: 100%;overflow: hidden;">
<div class="list_title">推荐商家<a style="float:right;margin-right:10px;color:#999;font-size: 14px" href="plugin.php?id=aljbd&amp;act=dianpu">&#26356;&#22810;</a></div>
<div class=" swiper-wrapper" data-tab="finer" style="margin:10px 0px 0px 10px">
<style>
.swiper-slide a .bd_name {
display: inline-block;
width: 100px;
height: 30px;
line-height: 30px;
overflow: hidden;
text-overflow: ellipsis;
white-space: nowrap;
font-size: 14px;
}
</style><?php if(is_array($recommendlist)) foreach($recommendlist as $recommend) { ?><div class="subject-item swiper-slide" style="width:100px;height:130px;">
<a class="navigateTo" href="plugin.php?id=aljbd&amp;act=view&amp;bid=<?php echo $recommend['id'];?>">
<img src="<?php if($recommend['logo']) { ?><?php echo $recommend['logo'];?><?php } else { ?><?php echo $noimg;?><?php } ?>" title="<?php echo $recommend['name'];?>" style="width:100px;height:100px"/>
<span class="bd_name">
<?php echo $recommend['name'];?>
</span>
</a>
</div>
<?php } ?>
</div>

</div>
<div class="blank8"></div>
<?php } } else { ?>
<div class="tabbox activities" style="margin:0px;background:#fff;">
<div class="tabs-hd">
<ul class="tabs">
<li data-tab="hot" id="tab2" ><a href="javascript:;"  class="selected" onclick="switchTab('tab2','con2');this.blur();return false;">推荐商家</a></li>
<li  data-tab="finer" id="tab1"><a href="javascript:;" onclick="switchTab('tab1','con1');this.blur();return false;">热门商家</a></li>
<li data-tab="new" id="tab3" ><a href="javascript:;" onclick="switchTab('tab3','con3');this.blur();return false;">最新加入</a></li>
</ul>
<div class="clear"></div>
</div>
<div class="tab-show" data-tab="finer" id="con1"  style="display: none">
<ul class="subjects"><?php if(is_array($viewslist)) foreach($viewslist as $recommend) { ?><li>
<div class="subject-item">
<a class="navigateTo" href="plugin.php?id=aljbd&amp;act=view&amp;bid=<?php echo $recommend['id'];?>"><img  <?php if($settings['is_lazyload']['value']) { ?>src="<?php echo $loading;?>" data-original="<?php if($recommend['logo']) { ?><?php echo $recommend['logo'];?><?php } else { ?><?php echo $noimg;?><?php } ?>"<?php } else { ?>src="<?php if($recommend['logo']) { ?><?php echo $recommend['logo'];?><?php } else { ?><?php echo $noimg;?><?php } ?>"<?php } ?> alt="<?php echo $recommend['name'];?>" title="<?php echo $recommend['name'];?>" /></a>
<span class="subject-title"><a href="plugin.php?id=aljbd&amp;act=view&amp;bid=<?php echo $recommend['id'];?>" title="<?php echo $recommend['name'];?>"><?php echo $recommend['name'];?></a></span>
</div>
</li>
<?php } ?>

</ul>
</div>
<div class="tab-show " data-tab="hot" id="con2">
<ul class="subjects">
 <?php if(is_array($recommendlist)) foreach($recommendlist as $recommend) { ?><li>
<div class="subject-item">
<a class="navigateTo" href="plugin.php?id=aljbd&amp;act=view&amp;bid=<?php echo $recommend['id'];?>">
<img <?php if($settings['is_lazyload']['value']) { ?>src="<?php echo $loading;?>" data-original="<?php if($recommend['logo']) { ?><?php echo $recommend['logo'];?><?php } else { ?><?php echo $noimg;?><?php } ?>"<?php } else { ?>src="<?php if($recommend['logo']) { ?><?php echo $recommend['logo'];?><?php } else { ?><?php echo $noimg;?><?php } ?>"<?php } ?>  alt="<?php echo $recommend['name'];?>" title="<?php echo $recommend['name'];?>" /></a>
<span class="subject-title"><a href="plugin.php?id=aljbd&amp;act=view&amp;bid=<?php echo $recommend['id'];?>" title="<?php echo $recommend['name'];?>"><?php echo $recommend['name'];?></a></span>
</div>
</li>
<?php } ?>
</ul>
</div>
<div class="tab-show " data-tab="new" id="con3" style="display: none">
<ul class="subjects"><?php if(is_array($timelist)) foreach($timelist as $recommend) { ?><li>
<div class="subject-item">
<a class="navigateTo" href="plugin.php?id=aljbd&amp;act=view&amp;bid=<?php echo $recommend['id'];?>">
<img <?php if($settings['is_lazyload']['value']) { ?>src="<?php echo $loading;?>" data-original="<?php if($recommend['logo']) { ?><?php echo $recommend['logo'];?><?php } else { ?><?php echo $noimg;?><?php } ?>"<?php } else { ?>src="<?php if($recommend['logo']) { ?><?php echo $recommend['logo'];?><?php } else { ?><?php echo $noimg;?><?php } ?>"<?php } ?>  alt="<?php echo $recommend['name'];?>" title="<?php echo $recommend['name'];?>" /></a>
<span class="subject-title"><a href="plugin.php?id=aljbd&amp;act=view&amp;bid=<?php echo $recommend['id'];?>" title="<?php echo $recommend['name'];?>"><?php echo $recommend['name'];?></a></span>
</div>
</li>
<?php } ?>

</ul>
</div>
<script type="text/javascript">
function switchTab(ProTag, ProBox) {
for (i = 1; i < 4; i++) {
if ("tab" + i == ProTag) {
document.getElementById(ProTag).getElementsByTagName("a")[0].className = "selected";
} else {
document.getElementById("tab" + i).getElementsByTagName("a")[0].className = "";
}
if ("con" + i == ProBox) {
document.getElementById(ProBox).style.display = "";
} else {
document.getElementById("con" + i).style.display = "none";
}
}
}
var h = document.body.clientWidth/3.5;
$('.subject-item').css({'height':h+'px','width':h+'px','overflow':'hidden'});
$('.subject-item img').css({'height':h+'px','width':h+'px','overflow':'hidden'});
</script>
</div>
<div class="blank8"></div>
<?php } } if($settings['mobile_index_love_top_ad']['value']) { ?>
<div style="width:100%; height:auto;" class="aljbd_ad"><?php echo htmlspecialchars_decode($settings['mobile_index_love_top_ad']['value']);?></div>
<div class="blank8"></div>
<?php } if(!$config['is_mobile_index_love']) { ?>
<link rel="stylesheet" media="screen,projection,tv" href="source/plugin/<?php echo $pluginid;?>/template/touch/view/css/label.css?<?php echo VERHASH;?>" /></link><?php include template('aljbd:common/goods/love_goods'); ?><style>
.b-color-f {
background: #f8f8f8;
}
.container-fluid {
background: #f8f8f8 !important;
}
</style>
<?php } ?>
    </div>
</div>
<?php if($settings['mobile_index_ad']['value']) { ?>
<div style="width:100%; height:auto;" class="aljbd_ad"><?php echo htmlspecialchars_decode($settings['mobile_index_ad']['value']);?></div>
<?php } ?>

<script src="source/plugin/<?php echo $pluginid;?>/template/touch/round_robin/round_robin.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<script>

var swiper = new Swiper('.swiper-container', {
paginationClickable: true,
spaceBetween: 30,
loop : true,
loopAdditionalSlides:1,
autoplay: 5000,//��ѡѡ��Զ�����
});
new Swiper('.swiper-container2', {
        scrollbarHide: true,
        slidesPerView: 'auto',
        centeredSlides: false,
        spaceBetween: 10,
        grabCursor: true,
    	autoplay: 3000,//��ѡѡ��Զ�����
    });
new Swiper(".swiper-container1",{pagination:".swiper-pagination2",paginationClickable:!0,spaceBetween:30,loop : true,loopAdditionalSlides:1});
var swiper = new Swiper('.swiper-container5', {
    paginationClickable: true,
    direction: 'vertical',
    autoplay: 3000,//��ѡѡ��Զ�����
    scrollbarHide: true,
});
</script>
<script>
new Swiper("#navigation",{spaceBetween:30,loop:!1});
keep_scrollheight = 1;
</script><?php include template('aljbd:common/goods/love_goods_js'); include template('aljbd:footer'); if(debuginfo()) { ?>
<script>
console.log('Processed in <?php echo $_G['debuginfo']['time'];?> second(s), <?php echo $_G['debuginfo']['queries'];?> queries');
</script>
<?php } ?>
</body>
</html>
