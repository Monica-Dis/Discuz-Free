<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<style>
    .c_goods_size {
        width: 100%;
        margin:0px 0px 5px 0px;
    }

    .c_goods_details {
        width: 100%;
        overflow: hidden;
        padding-top:5px;
    }
    .c_goods_details dd {
        width: 47%;
        float: left;
        border-bottom: 0px solid #f8f8f8;
        border-left: 0px solid #f8f8f8;
        position: relative;
        border-right: 0px;
        margin-left: 2%;
        margin-bottom: 2%;
        background: #ffffff;
        border-radius: 5px;
    }


    .c_goods_details dd p {
        color: #666;
        font-size: 12px;
        width: 90%;
        margin: 5px 5%;
        line-height: 14px;
    }
    .c_goods_details dd a {
        width: 100%;
        margin:0px;
        line-height: 24px;
        font-size: 12px;
        color: #333 !important;
        display: block;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .c_click_see{width:100%;height:36px;line-height:34px;color:#999;margin:0 0 10px 0;font-size:12px;text-align:center;background:#fff;cursor:pointer}
</style>
<?php if($settings['is_mobile_index_love_type']['value']) { ?>
<style>
    *{margin:0;padding:0}#topNav{width:100%;overflow:hidden;font:16px/32px hiragino sans gb,microsoft yahei,simsun;border-bottom:1px solid #f8f8f8;padding:5px 0 2px 0}#topNav .swiper-slide{padding:0 10px;letter-spacing:2px;width:auto;text-align:center;font-size:14px}#topNav .swiper-slide span{transition:all .3s ease;display:block}#topNav .active span:after{content:' ';width:12px;height:2px;background:<?php if($settings['mobilenavbackcolor']['value']) { ?><?php echo $settings['mobilenavbackcolor']['value'];?><?php } else { ?>#DD2726<?php } ?>;position:absolute;left:50%;bottom:0;-webkit-transform:translateX(-50%);-ms-transform:translateX(-50%);transform:translateX(-50%);border-radius:10px;transition:all .5s;-moz-transition:all .5s;-webkit-transition:all .5s;-o-transition:all .5s}#topNav .active span{transform:scale(1.1);color:<?php if($settings['mobilenavbackcolor']['value']) { ?><?php echo $settings['mobilenavbackcolor']['value'];?><?php } else { ?>#DD2726<?php } ?>}
</style>
<?php } ?>
<div class="diyDocument m-top08" diy-id="is_mobile_index_love" id="guess">
    <?php if($settings['is_mobile_index_love_type']['value']) { ?>
    
    <div class="b_index_fixed1">
        <div id="topNav" class="swiper-container1234 bordertop" style="background: #fff;">
            <div class="swiper-wrapper b_index_fixed">
                <a class="swiper-slide <?php if(!$_GET['typeid']) { ?>active<?php } ?>" val-data="recommend"  style="color:#333 !important;"><span>精选</span></a>
                <?php if(is_array($onetype)) foreach($onetype as $k => $v) { ?>                <a href="javascript:;" class="swiper-slide <?php if($_GET['typeid'] == $v['id']) { ?>active<?php } ?>" val-data="<?php echo $v['id'];?>" style="color:#333 !important;"><span><?php echo $v['subject'];?></span></a>
                <?php } ?>
            </div>
        </div>
    </div>
    <div class="list-view" style="background: #f8f8f8">
        <dl class="c_goods_details" id="dataList" >

        </dl>
        <div id="dataMore" class="more" style="display: none;">
            <div class="c_clear"></div>
            <div class="c_click_see" id="loading" style="background: none">
                <img alt="loading" src="static/image/common/loading.gif" >&#21152;&#36733;&#20013;&#46;&#46;&#46;
            </div>
        </div>
    </div>
    <?php } else { ?>
    <style>.padding-all {
        padding: 11px;
    }
    .goods-shop-pic .title-hrbg {
        margin-top: 0px;
    }
    h4.title-hrbg {
        font-size: 13px;
        position: relative;
        z-index: 1;
        height: 40px;
        line-height: 40px;
        overflow: hidden;
        color: #888;
        text-align: center;
        margin-top: 40px;
    }
    h4.title-hrbg span {
        background: #fff;
        padding: 10px 6px;
        font-size: 14px;
        z-index: 10;
    }
    h4.title-hrbg hr {
        background: #f6f6f9;
        height: 1px;
        border: 0;
        position: absolute;
        left: 0;
        right: 0;
        top: 50%;
        margin-top: 1px;
        z-index: -1;
    }</style>
    <div class="list-view" style="background: #f8f8f8">
        <div class="goods-shop-pic b-color-f" style="background: #f8f8f8">
            <div class="padding-all">
                <h4 class="title-hrbg m-top06">
                    <span style="background: #f8f8f8;"><img src="<?php if(file_exists('source/plugin/aljgwc/template/touch/user/img/love.png')) { ?>source/plugin/aljgwc/template/touch/user/img/love.png<?php } else { ?>source/plugin/aljbd/images/index/love.png<?php } ?>" style="width:16px;margin-right:5px;">&#29468;&#24744;&#21916;&#27426;</span><hr>
                </h4>
            </div>
        </div>
        <dl class="c_goods_details" id="dataList" >

        </dl>
        <div id="dataMore" class="more">
            <div class="c_clear"></div>
            <div class="c_click_see" id="loading" style="background: none">
                <img alt="loading" src="static/image/common/loading.gif" >&#21152;&#36733;&#20013;&#46;&#46;&#46;
            </div>
        </div>
    </div>
    <?php } ?>
</div>