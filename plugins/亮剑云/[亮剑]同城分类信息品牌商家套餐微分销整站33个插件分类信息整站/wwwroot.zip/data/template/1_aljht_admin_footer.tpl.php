<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>

<!-- jQuery UI 1.11.4 -->
<script src="source/plugin/aljht/static/js/jquery-ui.min.js" type="text/javascript"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
    $.widget.bridge('uibutton', $.ui.button);
    function layer_iframe(url,text){
        //iframe窗
        layer.open({
            type: 2,
            title: text,
            shadeClose: true,
            shade: false,
            maxmin: true, //开启最大化最小化按钮
            area: ['90%', '90%'],
            content: url
        });
    }
    function layer_iframe_viptime(url,text){
        //iframe窗
        layer.open({
            type: 2,
            title: text,
            shadeClose: true,
            shade: false,
            maxmin: true, //开启最大化最小化按钮
            area: ['50%', '60%'],
            content: url
        });
    }
    function layer_iframe_wh(url,text,w,h){
        //iframe窗
        layer.open({
            type: 2,
            title: text,
            shadeClose: true,
            shade: false,
            maxmin: true, //开启最大化最小化按钮
            area: [w, h],
            content: url
        });
    }
    //调用示例
    layer.photos({
        photos: '.layer-photos-demo'
    });
</script>
<!-- Bootstrap 3.3.6 -->
<script src="source/plugin/aljht/static/js/bootstrap.min.js" type="text/javascript"></script>
<script src="source/plugin/aljht/static/js/app.min.js" type="text/javascript"></script>
<script src="source/plugin/aljht/static/js/icheck.min.js" type="text/javascript"></script>

</body>
</html>