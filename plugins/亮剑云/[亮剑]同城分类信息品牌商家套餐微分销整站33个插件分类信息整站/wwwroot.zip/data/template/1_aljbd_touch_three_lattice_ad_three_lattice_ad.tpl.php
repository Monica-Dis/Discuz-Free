<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($settings['mobile_index_siad']['value']) { ?>
<style>
    .floor-container{width:100%;height:100%;overflow:hidden;font-size:0}.floor-container img{width:100%;height:auto;overflow:hidden}.flsPit{height:120px;background-color:#f5f5f5}.floor-graphic-item{width:100%;background:#fff;font-size:100%;overflow:hidden}.graphic-col04-bg,.graphic-col04-sm{position:relative;width:25%;float:left}.graphic-col04-bg{height:120px}.graphic-separation{background:#fff;position:relative;font-family:PingFangSC-Light,PingFang-Medium,PingFangSC-Regular,Helvetica,Droid Sans,Arial,sans-serif;font-size:0}.real-show,.show-img{width:100%;height:100%;overflow:hidden;position:absolute;left:0;top:0}.show-img img{width:100%;height:100%}.floor-container img{width:100%;height:auto;overflow:hidden}
</style>
<div class="blank8"></div>
<?php if($settings['mobile_index_siad_title']['value']) { ?>
<div class="hot diyDocument" diy-id="mobile_index_siad_title">
    <img src="<?php echo $settings['mobile_index_siad_title']['value'];?>">
</div>
<?php } ?>
<div class="floor-container diyDocument" diy-id="floor-container"><div id="floor-8-0" class="flsPit fls06013" data-index="8" data-sub="0" data-id="5386" load="true"><div class="floor-graphic-item">


    <div class="   graphic-separation  graphic-col04-bg">
        <a  href="<?php echo $mobile_index_siad_arr['0']['1'];?>" class="J_ping">

            <!-- ��ͼ -->
            <div class="show-img"><img src="<?php echo $mobile_index_siad_arr['0']['0'];?>" class="opa1" style="opacity: 1;"></div>

        </a>
    </div>


    <div class="   graphic-separation  graphic-col04-bg">
        <a  href="<?php echo $mobile_index_siad_arr['1']['1'];?>" class="J_ping">

            <!-- ��ͼ -->
            <div class="show-img"><img src="<?php echo $mobile_index_siad_arr['1']['0'];?>" class="opa1" style="opacity: 1;"></div>

        </a>
    </div>


    <div class="   graphic-separation  graphic-col04-bg">
        <a  href="<?php echo $mobile_index_siad_arr['2']['1'];?>" class="J_ping">

            <!-- ��ͼ -->
            <div class="show-img"><img src="<?php echo $mobile_index_siad_arr['2']['0'];?>" class="opa1" style="opacity: 1;"></div>

        </a>
    </div>


    <div class="   graphic-separation  graphic-col04-bg">
        <a  href="<?php echo $mobile_index_siad_arr['3']['1'];?>" class="J_ping">

            <!-- ��ͼ -->
            <div class="show-img"><img src="<?php echo $mobile_index_siad_arr['3']['0'];?>" class="opa1" style="opacity: 1;"></div>

        </a>
    </div>

</div></div></div>
<?php } ?>