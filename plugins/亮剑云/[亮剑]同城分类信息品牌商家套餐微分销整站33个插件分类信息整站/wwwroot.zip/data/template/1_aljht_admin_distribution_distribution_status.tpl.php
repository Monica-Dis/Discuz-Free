<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div class="col-md-12">
    <ul class="nav nav-tabs" role="tablist" >
        <li <?php if(!$do) { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=<?php echo $op;?><?php echo $urlmod;?>">等级管理</a></li>
        <li <?php if($do == 'shoplist') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=<?php echo $op;?>&amp;do=shoplist<?php echo $urlmod;?>"> 店铺管理</a></li>
        <li <?php if($do == 'cashlog') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=<?php echo $op;?>&amp;do=cashlog<?php echo $urlmod;?>"> 提现管理</a></li>
        <li <?php if($do == 'order') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=<?php echo $op;?>&amp;do=order<?php echo $urlmod;?>"> 分销订单</a></li>
        <li <?php if($do == 'userlist') { ?>class="active"<?php } ?>><a href="plugin.php?id=aljht&amp;act=admin&amp;op=<?php echo $op;?>&amp;do=userlist<?php echo $urlmod;?>"> 分销用户</a></li>
    </ul>
</div>