<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="<?php echo CHARSET;?>">
<base href="<?php echo $_G['siteurl'];?>" />
<title>&#30331;&#24405;</title>
<link rel="stylesheet" href="source/plugin/aljlogin/static/css/mods.css">
<link rel="stylesheet" href="source/plugin/aljlogin/static/css/style.css" type="text/css"/>
<script src="source/plugin/aljlogin/static/js/jquery-2.1.4.js" type="text/javascript"></script>
<script src="source/plugin/aljlogin/static/vegas/vegas.min.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="source/plugin/aljlogin/static/vegas/jquery.vegas.min.css">
<?php if($_G['cache']['plugin']['aljlogin']['beijingtu']) { $beijingtu = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljlogin']['beijingtu']));?><script>

        $( function() {
            var slides = [];

            <?php if(is_array($beijingtu)) foreach($beijingtu as $rv) { ?>            slides.push({
                src: '<?php echo $rv;?>',
            });
            <?php } ?>
            console.log(slides);
            $('body').vegas({
                delay: 8000,
                timer:false,
                transition:"fade2",
                transitionDuration:1000,
                animation:"random",
                animationDuration:4000,
                overlay:"source/plugin/aljlogin/static/images/zhezhao.png",
                slides: slides
            } )
        } );
</script>
<?php } ?>
</head>
<body class="bg-admin-login" <?php if(!$_G['cache']['plugin']['aljhtx']['verify_appid']) { ?>onkeypress="EnterPress(event)" onkeydown="EnterPress()"<?php } ?>>
<style>
.bg-admin-login {
background: url(<?php echo $beijingtu['0'];?>) no-repeat center center;
background-size: cover;
}
.bg-admin-login .lj-dialog .hd {
text-align: center;
padding: 18px 0;
background-color: <?php echo $colorname;?>;
color: #fff;
font-size: 20px
}
.lj-btn.theme {
color: #fff;
background-color: <?php echo $colorname;?>
}
ul, ul li {
list-style-type: none;
}
.login {
margin-top: 10%;
}
.login-name, .register-name {
width: 80%;
}
.login-submit, .register-submit {
width: 80%;
}
</style>

<div class="lj-dialog operation">
<div class="hd">&#30331;&#24405;</div>
<iframe name="submitiframe" style="display:none;"></iframe>
<form id="login" method="post" action="plugin.php?id=aljlogin" target="submitiframe" >
<?php if(!$_G['cache']['plugin']['aljhtx']['verify_appid']) { ?>
<input type="hidden" value="<?php echo FORMHASH;?>" name="formhash">
<?php } ?>
<input type="hidden" value="<?php echo $referer;?>" name="referer">
<input type="hidden" value="" name="ticket" id="ticket">
<input type="hidden" value="" name="randstr" id="randstr">
<div class="login">
<div class="login-name">
<i class="image-icon icon1"></i>
<input name="username" type="text" value="" placeholder="&#36134;&#21495;<?php if($setting_aljlogin['dxyz']) { ?>&#47;&#25163;&#26426;&#21495;<?php } ?>"/>
<div class="clear"></div>
</div>
<div class="login-name">
<i class="image-icon icon2"></i>
<input type="password" value="" name="password" placeholder="&#23494;&#30721;"/>
<?php if($setting_aljlogin['dxyz']) { ?>
<a href="plugin.php?id=aljlogin&amp;act=forgot&amp;pluginid=<?php echo $pluginid;?>" style="display:block; position:absolute; right:5px;padding-left: 5px; top:9px; font-size:12px;border-left: 1px solid #eeeeee;">&#24536;&#35760;&#63;</a>
<?php } ?>
<div class="clear"></div>
</div>
<button type="submit" class="login-submit" id="TencentCaptcha" data-appid="<?php echo $_G['cache']['plugin']['aljhtx']['verify_appid'];?>" data-cbfn="callback" onclick="loadindex = layer.load();" style="background-color:<?php echo $colorname;?>">&#30331;&#24405;</button>
</div>
</form><?php include template('aljlogin:loginnav'); ?></div>
<div class="water">
<div class="water-c">
<div class="water-1"></div>
<div class="water-2"></div>
</div>
</div>




<script src="source/plugin/aljlogin/static/layer/layer.js" type="text/javascript"></script>
<?php if($_G['cache']['plugin']['aljhtx']['verify_appid']) { ?>
<script src="https://ssl.captcha.qq.com/TCaptcha.js" type="text/javascript"></script>
<?php } ?>
<script>
    window.callback = function(res){
        console.log(res)
        // res���û������ر���֤�룩= {ret: 2, ticket: null}
        // res����֤�ɹ��� = {ret: 0, ticket: "String", randstr: "String"}
        if(res.ret === 0){
            //alert(res.ticket)   // Ʊ��
            $('#ticket').val(res.ticket);
            $('#randstr').val(res.randstr);
            $('#login').submit();
        }
layer.closeAll();
    }
    <?php if(!$_G['cache']['plugin']['aljhtx']['verify_appid']) { ?>
    function EnterPress(e){ //���� event
        var e = e || window.event;
        if(e.keyCode == 13){
            $('#TencentCaptcha').click();
        }
    }
<?php } ?>
    function tips(info,url){
        layer.close(loadindex);
        if(info == 0){
            layer.msg('\u64cd\u4f5c\u6210\u529f', function(){
                location.href=location.href;
            });
        }else{
            if(url){
                layer.msg(info, function(){
                    window.location.href = url;
                });
            }else{
                layer.msg(info);
            }
        }
    }
</script>
</body>
</html>