<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<ul class="nav nav-tabs" role="tablist" >
    <li <?php if(empty($_GET['reduction_method'])) { ?>class="active"<?php } ?>><a href="plugin.php?id=<?php echo APP_ID;?>">全部商品</a></li>
    <!--<li <?php if($_GET['reduction_method'] == 'byorder') { ?>class="active"<?php } ?>><a href="plugin.php?id=<?php echo APP_ID;?>&amp;reduction_method=byorder">付款时扣减库存数量的商品</a></li>-->
    <li <?php if($_GET['reduction_method'] == 'bypayment') { ?>class="active"<?php } ?>><a href="plugin.php?id=<?php echo APP_ID;?>&amp;reduction_method=bypayment">下单时扣减库存数量的商品</a></li>
</ul>