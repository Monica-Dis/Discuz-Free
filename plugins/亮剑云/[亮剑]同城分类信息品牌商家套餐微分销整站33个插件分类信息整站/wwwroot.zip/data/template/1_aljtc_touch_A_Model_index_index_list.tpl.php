<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>


<div id="topNav" class="swiper-container1234 bordertop">
    <div class="swiper-wrapper">
        <div class="swiper-slide active" onclick="changedata(0,this)">
            <span>最新信息</span>
        </div>
        <?php if($_G['cache']['plugin']['aljtsq']) { ?>
        <div class="swiper-slide" onclick="changedata('lbs',this)">
            <span>附近信息</span>
        </div>
        <?php } ?>
        <?php if(is_array($gtypes_tmp)) foreach($gtypes_tmp as $tmp_key => $tmp_value) { ?>        <div class="swiper-slide" onclick="changedata(<?php echo $tmp_value['id'];?>,this)">
            <span><?php echo $tmp_value['subject'];?></span>
        </div>
        <?php } ?>
    </div>
</div>
<div class="datacontent">
</div>
<div class="weui-loadmore" id="load" style="display: none;">
    <i class="weui-loading"></i>
    <span class="weui-loadmore__tips bcf8">正在加载</span>
</div>
<div class="weui-loadmore weui-loadmore_line" id="loaded"style="display: none;">
    <span class="weui-loadmore__tips bcf8">暂无数据</span>
</div>
<div id="empty" style="display: none;">
    <?php if($hide_mini) { } else { ?>
    <?php if(!$_GET['act'] && $_G['cache']['plugin']['aljhtx']['is_aljtc']) { ?>
    <div style="padding:10px">
        <a href="plugin.php?id=aljtc&amp;act=posttype" class="weui-btn weui-btn_warn" >发布信息</a>
        <?php if($_G['cache']['plugin']['aljtfz']['site_show']) { ?>
        <a href="plugin.php?id=aljtfz<?php if($_G['cookie']['fz_id']) { ?>&amp;fz_id=<?php echo $_G['cookie']['fz_id'];?><?php } ?>" class="weui-btn weui-btn_default">查看其它城市信息</a>
        <?php } elseif($settings['is_more_city']['value']) { ?>
        <a href="javascript:;" onclick="clickarea(this)" class="weui-btn weui-btn_default">查看其它城市信息</a>
        <?php } ?>
    </div>
    <?php } ?>
    <?php } ?>
</div>
<div id="mask_l" style="display: none;" onclick="showtop()"></div>