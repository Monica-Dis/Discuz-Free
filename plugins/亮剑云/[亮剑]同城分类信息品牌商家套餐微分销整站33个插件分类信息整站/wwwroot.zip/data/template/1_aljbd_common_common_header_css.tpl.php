<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<style type="text/css">

    .categorys-items-layer{ display:none; position:absolute; top:0; left:232px; width:966px; min-height:498px; border:1px solid #fff; background-color: #fff;box-shadow: 0px 0px 3px 2px rgba(0,0,0,.1);-webkit-transition: top .25s ease;transition: top .25s ease;}
    .cate-layer-con{ padding:20px 20px 28px 18px;}
    .cate-layer-con .lazy{ margin:100px 0 0 360px;}
    .cate-layer-left{ float:left; width:704px;}
    .cate-layer-rihgt{ float:right; width:200px;}
    .cateLayer_items_all{ width:276px; }
    .cateLayer_items_all .cate-layer-con{ padding:25px 35px; }

    .cate_channel{ overflow:hidden; height:24px; width:100%;}
    .cate_channel a,
    .cate_two_channel a{ float:left; margin-right:10px; padding:0 10px 0 12px; height:24px; line-height:24px; color:#fff; background-color:#5f4f4f;}
    .cate_channel .iconfont{ float:none; font-size:12px; margin-left:5px;}

    .cate_detail{ margin-top:20px; width:100%;}
    .cate_detail dl{ padding-left:80px; position:relative;}
    .cate_detail dt{ overflow:hidden; position:absolute; color:#555; left:0; top:13px; width:70px; text-align:right; font-weight:700; white-space:nowrap;text-overflow: ellipsis;}
    .cate_detail dt .iconfont{ font-size:12px; color:#666; margin-left:6px; float:none;}
    .cate_detail dd{ padding:8px 0; overflow:hidden; border-bottom: 1px dashed #d2d2d2; min-height:28px;}
    .cate_detail dl:last-child dd{ border-bottom:0;}
    .cate_detail dd a{ float: left;margin: 8px 0;padding: 0 10px;height: 12px;border-left: 1px solid #e0e0e0;line-height: 12px;white-space: nowrap;}

    .cate-brand{ margin:auto; font-size:0;}
    .cate-brand .img{ overflow:hidden; display:inline-block; width:98px; height:98px; border:1px solid #f9f9f9; text-align:center; margin:-1px -1px 0 0;}
    .cate-brand a{ display:table-cell; vertical-align:middle; width:98px; height:98px;}
    .cate-brand a img{ width:100%; height:auto;}

    .categorys-tab-content .categorys-item:hover .categorys-items-layer{ display:block;}

    .navLj .nav-main{ float:left; width:968px; overflow:hidden; height:40px; line-height:40px;}
    .navLj .nav-main li{ float:left; margin-left:28px;}
    .navLj .nav-main li a{ font-size:16px; color:#555; display:block;padding:0px 10px}
    .navLj .nav-main li a:hover,.navLj .nav-main li a.curr{ color:<?php echo $_G['cache']['plugin'][$pluginid]['color_daohang'];?>;}
    .navLj .nav-main li a:hover{background: <?php echo $_G['cache']['plugin'][$pluginid]['color_daohang'];?>;color:#ffffff;}
    .categorys-tab-content .nav_cat_model{ height:6.25%;}
    .categorys-tab-content .nav_cat_model .item-content{ padding:4px 16px 3px;}

    .cate_two_detail{ margin-bottom: 30px; overflow: hidden;}
    .cate_two_detail ul{ padding-bottom: 20px; border-bottom: 1px dashed #d2d2d2; min-height: 280px; overflow: hidden;}
    .cate_two_detail .li_fore{ width: 100%; line-height: 30px; margin-bottom: 10px;}
    .cate_two_detail .li_fore a{ display: block; font-weight: bold; }
    .cate_two_detail .li_fore i{ display: block; width: 3px; height:6px; background-position:-10px -177px; float: right; margin:12px 0;}
    .cate_two_channel ul{ width:216px; }
    .cate_two_channel li{ width: 98px; float: left; margin:0 10px 12px 0;}
    .cate_two_channel li a{ margin-right:0; }
    .clear, .clearfix {
        clear: both;
    }
    .clearfix:after, .clearfix:before {
        content: ".";
        display: block;
        height: 0;
        clear: both;
        visibility: hidden;
    }
    .cate_channel a, .cate_two_channel a {
        float: left;
        margin-right: 10px;
        padding: 0 10px 0 12px;
        height: 24px;
        line-height: 24px;
        color: #fff !important;
        background-color: #5f4f4f !important;
    }
    .cate_detail a {
        text-decoration: none;
        color: #555;
        padding:0px
    }
    .cate-layer-rihgt a{padding:0px}
    .categorys-items-layer a{color:#555;font-size: 12px}
    .categorys-items-layer dl{clear: both;float:none !important;}
    .categorys-items-layer dl dd{clear: both;float:none!important;}
    .categorys-items-layer dt{clear: both}
    /* nav start*/
    .navLj{ height:40px; position:relative; z-index:9; background-color:#fff;padding-top:10px}
    .navLj .categorys,.attached-search-container .categorys{ float:left; width:232px; height:40px; position:relative;}
    .attached-search-container .categorys{ margin-top:12px; height:34px;}
    .navLj .categorys .categorys-type,.attached-search-container .categorys .categorys-type{ background-color:<?php echo $_G['cache']['plugin'][$pluginid]['color_daohang'];?>; text-align:center; font-size:0; line-height:40px;}
    .attached-search-container .categorys .categorys-type{ line-height:34px;}
    .navLj .categorys .categorys-type a,.attached-search-container .categorys .categorys-type a{ font-size:16px; font-weight:700; color:#fff; display:block;}


    .dsc-zoom{ border-bottom: 2px solid <?php echo $_G['cache']['plugin'][$pluginid]['color_daohang'];?>;}
    .dsc-zoom .categorys .categorys-type{ padding-bottom:2px;}

    .categorys-tab-content{ height:500px; z-index:30; background-color:#000; background-color:rgba(0,0,0,0.6);}
    .categorys-tab-content .categorys-items{ position:relative; height:100%;}
    .categorys-tab-content .categorys-item{ cursor:pointer; height:10.29%;}
    .categorys-tab-content .item-content{ padding:10px 16px; float:left; width:200px;}
    .categorys-tab-content .item-content .icon-other{ float:left; width:16px; height:16px;padding-top: 4px;}
    .categorys-tab-content .item-content .icon-other img{ width:100%;}
    .categorys-tab-content .item-content:hover{  background-color:rgba(0,0,0,1);}
    .categorys-tab-content .iconfont{ float:left; color:#bfbfbf;}
    .categorys-tab-content .categorys-title{ float:left; margin-left:10px; width:173px;}
    .categorys-tab-content .categorys-title strong{ display:block; font-weight:normal; width:100%; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;}
    .categorys-tab-content .categorys-title strong a{ color:#fff; font-size:14px;}
    .categorys-tab-content .categorys-title span{ display:block; font-size:0; width:100%; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;}
    .categorys-tab-content .categorys-title span a{ color:#bfbfbf; margin-right:10px; font-size:14px;}
    .categorys-tab-content .categorys-title span a:hover,.categorys-tab-content .categorys-title strong a:hover{ color:#e23435;}

    .site-mast .categorys-tab-content{ display:none;}
    .site-mast:hover .categorys-tab-content{ display:block;}
    .w1200 {
        width: 1200px;
    }
    .wp {
        width: 1200px !important;
    }
    .w {
        margin: 0 auto;
    }
    <?php if($_G['cache']['plugin']['aljsyh']['coupon_color'] && ($_GET['act'] == 'consume' || $_GET['act'] == 'clist' || $_GET['act'] == 'consumeview')) { ?>
    .navLj .categorys .categorys-type, .attached-search-container .categorys .categorys-type {
        background-color: <?php echo $_G['cache']['plugin']['aljsyh']['coupon_color'];?>;
        text-align: center;
        font-size: 0;
        line-height: 40px;
    }
    .dsc-zoom {
        border-bottom: 2px solid <?php echo $_G['cache']['plugin']['aljsyh']['coupon_color'];?>;
    }
    .search-form .input-ss {
        background: <?php echo $_G['cache']['plugin']['aljsyh']['coupon_color'];?>;
    }
    .search {
        border: 2px solid <?php echo $_G['cache']['plugin']['aljsyh']['coupon_color'];?>;
    }
    .navLj .nav-main li a:hover, .navLj .nav-main li a.curr {
        color: <?php echo $_G['cache']['plugin']['aljsyh']['coupon_color'];?>;
    }
    .navLj .nav-main li a:hover{background: <?php echo $_G['cache']['plugin']['aljsyh']['coupon_color'];?>;color:#ffffff;}
    .search-item ul {
        border: 2px solid <?php echo $_G['cache']['plugin']['aljsyh']['coupon_color'];?>;
        border-top: none;
    }
    <?php } else { ?>

    .search-form .input-ss{background:<?php echo $_G['cache']['plugin'][$pluginid]['s_color'];?>;}
    .search {  border: 2px solid <?php echo $_G['cache']['plugin'][$pluginid]['s_color'];?>;  }
    .search-item ul {
    border: 2px solid <?php echo $_G['cache']['plugin'][$pluginid]['s_color'];?>;
    border-top: none;
    }

    <?php } ?>
    .selection .a {color: <?php echo $_G['cache']['plugin'][$pluginid]['cd_xuanzhong'];?>;}
    .header {

        width: 100%;
    }
    input, button, select, textarea {
        font-size: 14px;
    }
    .attes_logo{width:20px}
    .ct2_a .mn {
        width: 1040px;
        padding: 10px 0 0;
    }
    .c_p_t {
    color: rgb(230,220,190);
    background: #2B2B2A;
    display: inline-block;
    vertical-align: middle;
    padding: 0 3px;
    white-space: nowrap;
    font-size: 10px;
    border-radius: 3px;
    line-height: 14px;
    position: relative;
    margin-left: 5px;
    height: 14px;
}
.c_p_t:before {
    position: absolute;
    content: "";
    right: 100%;
    top: 4px;
    width: 0;
    height: 0;
    border-top: 3px solid transparent;
    border-right: 3px solid #2B2B2A;
    border-bottom: 3px solid transparent;
    border-left: 3px solid transparent;
}   
.buy_mini {
    line-height: 14px;
    height: 14px;
    font-size: 10px;
    padding: 0 6px;
    color: #fff;
    border-radius: 14px;
    background: -webkit-linear-gradient(left,#e93b3d,#fe9373);
    background: -webkit-gradient(linear,left top,right top,from(#e93b3d),to(#fe9373));
    background: linear-gradient(90deg,#e93b3d,#fe9373);
    box-shadow: 0 3px 6px rgba(233,59,61,.2);
    display: inline-block;
    vertical-align: middle;
    margin-top: 6px;
}

</style>