<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('iframe_header_common');?>
<?php if($_GET['ajax'] != 'yes') { include template('aljht:admin/header'); include template('aljht:admin/aside'); } else { include template('aljht:admin/iframe_header'); ?><style>
    .content-wrapper{margin-left: 0px!important;}
    .content-wrapper, .right-side {
        background-color: #f8f8f8;
    }
</style>
<?php } ?>
<style>
    .weui-cell {
        padding: 10px 0px;
        position: relative;
        display: -webkit-box;
        display: -webkit-flex;
        display: flex;
        -webkit-box-align: center;
        -webkit-align-items: center;
        align-items: center
    }
    .weui-cell__bd {
        -webkit-box-flex: 1;
        -webkit-flex: 1;
        flex: 1
    }

    .weui-cell__ft {
        text-align: right;
        color: #999
    }
    .weui-uploader__bd {
        margin-bottom: -4px;
        margin-right: -9px;
        overflow: hidden
    }

    .weui-uploader__files {
        list-style: none
    }

    .weui-uploader__file {
        float: left;
        margin-right: 9px;
        margin-bottom: 9px;
        width: 79px;
        height: 79px;
        background: no-repeat 50%;
        background-size: cover
    }

    .weui-uploader__file_status {
        position: relative;
    }

    .weui-uploader__file_status:before {
        content: " ";
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background-color: rgba(0,0,0,.5)
    }

    .weui-uploader__file_status .weui-uploader__file-content {
        display: block
    }

    .weui-uploader__file-content {
        display: none;
        position: absolute;
        top: 50%;
        left: 50%;
        -webkit-transform: translate(-50%,-50%);
        transform: translate(-50%,-50%);
        color: #fff
    }

    .weui-uploader__file-content .weui-icon-warn {
        display: inline-block
    }

    .weui-uploader__input-box {
        float: left;
        position: relative;
        margin-right: 9px;
        margin-bottom: 9px;
        width: 77px;
        height: 77px;
        border: 1px solid #d9d9d9
    }

    .weui-uploader__input-box:after,.weui-uploader__input-box:before {
        content: " ";
        position: absolute;
        top: 50%;
        left: 50%;
        -webkit-transform: translate(-50%,-50%);
        transform: translate(-50%,-50%);
        background-color: #d9d9d9
    }

    .weui-uploader__input-box:before {
        width: 2px;
        height: 39.5px
    }

    .weui-uploader__input-box:after {
        width: 39.5px;
        height: 2px
    }

    .weui-uploader__input-box:active {
        border-color: #999
    }

    .weui-uploader__input-box:active:after,.weui-uploader__input-box:active:before {
        background-color: #999
    }

    .weui-uploader__input {
        position: absolute;
        z-index: 1;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        opacity: 0;
        -webkit-tap-highlight-color: rgba(0,0,0,0)
    }
    ul, ol, li {
        margin: 0;
        padding: 0;
        border: 0;
        list-style: none;
        font-weight: normal;
    }
    .weui-uploader__input__video {
        position: absolute;
        z-index: 0;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        opacity: 0;
        -webkit-tap-highlight-color: rgba(0,0,0,0);
    }
    #ossfile img{position: absolute;top:5px;right:10px;width:20px;cursor: pointer;z-index: 99999;}
    #ossfile_intro img{position: absolute;top:5px;right:10px;width:20px;cursor: pointer;z-index: 99999;}
</style>
<style>
    
    .o_reply{border: 1px solid #f42424;color:#f42424;padding:2px 10px;font-size: 12px;border-radius: 5px;display: block;}
    .attes_logo{width:20px}
    .control-label-left{
        padding-top: 7px;
        margin-bottom: 0;
        margin-left: -15px;
    }
</style>