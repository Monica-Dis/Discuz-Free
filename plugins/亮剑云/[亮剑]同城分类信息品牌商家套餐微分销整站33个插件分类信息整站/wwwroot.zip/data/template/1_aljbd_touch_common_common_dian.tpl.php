<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<ul class="menu-list" style="display: none;">
        <?php if($settings['is_mobile_spot_popup']['value'] && $settings['mobile_common_footernav']['value']) { ?>
        <style>
            .menu-list:before {
                border-bottom: 8px solid #ffffff;
            }
            .menu-list{
                background: #ffffff;
                -webkit-box-shadow: 0 0 2px 2px #f8f8f8;
                box-shadow: 0 0 2px 2px #f8f8f8;
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
            }
            .menu-list li{
                border-bottom: 1px solid #f8f8f8;
            }
            .menu-list a{color:#333;padding: 0 0 0 10px;}
            .menu-list img{width:22px;margin-top: -4px;vertical-align: middle !important;}
        </style>
            <?php if(is_array($mobile_common_footernav_arr)) foreach($mobile_common_footernav_arr as $mcfk => $mcfv) { ?>                <li>
                    <a  href="<?php echo $mcfv['3'];?>" >
                    
                    <img src="<?php echo $mcfv['1'];?>" />
                    <?php echo $mcfv['2'];?>
                    </a>
                </li>
            <?php } ?>
        <?php } else { ?>
            <li><a href="plugin.php?id=aljbd" class="index-link">&#39318;&#39029;</a></li>
            <li><a href="plugin.php?id=aljbd&amp;act=user" class="state-link">&#25105;&#30340;</a></li>
            <?php if(!$settings['is_self_support']['value']) { ?>
            <li><a href="plugin.php?id=aljbd&amp;act=dianpu" class="brand-link">&#21830;&#23478;</a></li>
            <?php } ?>
            <li><a href="plugin.php?id=aljbd&amp;act=goods" class="shop-group">&#21830;&#21697;</a></li>
            <li><a href="plugin.php?id=aljbd&amp;act=search" class="search-link">&#25628;&#32034;</a></li>
            <?php if(file_exists("static/js/js_sdk20170302.js") && $_GET['act'] == 'goodview') { ?>
            <script src="static/js/js_sdk20170302.js" type="text/javascript"></script>
            <style>
                .share-link:before {
                    background: url(source/plugin/aljbd/template/touch/view/images/share.png) no-repeat 50% 50%;
                    -webkit-background-size: 17px 17px;
                    background-size: 17px 17px;
                }
            </style>
            <li style="display:none;" id="share-link"><a href="plugin.php?id=aljbd&amp;act=search" class="share-link" >&#20998;&#20139;</a></li>
            <?php $kingsharelogo = strpos($g['pic1'],$oss_domain) !== false ? $g['pic1'] :$_G['siteurl'].$g['pic1']?>            <script>
                if(is_kingkr_obj()){
                    $('#share-link').show();
                    $('.share-link').click(function() {
                        share('share','<?php echo $g['name'];?>', '<?php echo $kingsharelogo;?>', '<?php echo $_G['siteurl'];?>plugin.php?id=aljbd&act=goodview&bid=<?php echo $g['bid'];?>&gid=<?php echo $g['id'];?>', '<?php echo $g['name'];?>');
                    });
                }
            </script>
            <?php } ?>
        <?php } ?>
    </ul>