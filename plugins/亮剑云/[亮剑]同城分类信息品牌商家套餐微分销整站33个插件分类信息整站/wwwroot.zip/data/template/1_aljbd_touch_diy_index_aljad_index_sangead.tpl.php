<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<style type="text/css">
    .hot{overflow:hidden}.hot .lj_right{width:50%}.hot .lj_left{width:50%;float:left}.lj_right{float:right}img{border:0;vertical-align:middle}.hot img{width:100%}
</style>
<?php if($settings['aljad_index_sangead']['value'] || $settings['sj_index_dh_ad']['value']) { ?>
    <div class="blank8"></div>
    <?php if($settings['sj_index_dh_ad']['value']) { ?>
    <div class="hot diyDocument" diy-id="sj_index_dh_ad">
        <?php echo htmlspecialchars_decode($settings['sj_index_dh_ad']['value']);?>    </div>
    <?php } ?>
    <div class="hot diyDocument" diy-id="mobile_index_tad-change">

        <?php if($settings['aljad_index_sangead']['value']) { ?>
        <div class="lj_left">
            <?php echo $aljad_index_sangead['0'];?>
        </div>
        <div class="lj_right">
            <?php echo $aljad_index_sangead['1'];?>
            <?php echo $aljad_index_sangead['2'];?>
        </div>
        <?php } ?>
    </div>
<?php } else { ?>
    <!--������λ-->
    <?php if($settings['mobile_index_tad']['value']) { ?>
        <div class="blank8"></div>
        <?php if($settings['mobile_index_tad_title']['value']) { ?>
        <div class="hot diyDocument" diy-id="mobile_index_tad_title"><img src="<?php echo $settings['mobile_index_tad_title']['value'];?>" /></div>
        <?php } ?>
        <div class="hot diyDocument" diy-id="mobile_index_tad">
            <div class="lj_left">
                <a href="<?php echo $mobile_index_tad_arr['0']['1'];?>" class="navigateTo"><img src="<?php echo $mobile_index_tad_arr['0']['0'];?>"></a>
            </div>
            <div class="lj_right">
                <a href="<?php echo $mobile_index_tad_arr['1']['1'];?>" class="navigateTo"><img src="<?php echo $mobile_index_tad_arr['1']['0'];?>" alt="" ></a>
                <a href="<?php echo $mobile_index_tad_arr['2']['1'];?>" class="navigateTo"><img src="<?php echo $mobile_index_tad_arr['2']['0'];?>" alt=""></a>
            </div>
        </div>
    <?php } ?>
    <!--������λ-->
<?php } ?>