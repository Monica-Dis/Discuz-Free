<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'liangjian');
define('UC_DBPW', 'liangjian123');
define('UC_DBNAME', 'liangjian');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`liangjian`.pre_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'O4A4l1NeD3h8cb43A1o084O1qefan7qa32z5u889zfybc902b9mfj3If5a1076Vc');
define('UC_API', 'http://127.0.0.1/liangjian/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>