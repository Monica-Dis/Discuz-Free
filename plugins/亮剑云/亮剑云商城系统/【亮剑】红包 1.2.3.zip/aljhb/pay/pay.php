<?php
define('DISABLEXSSCHECK',true);
require '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
loadcache('plugin');
require_once '../../../../source/plugin/aljqb/class/Qbapi.class.php';
if(file_exists('../../../../source/plugin/aljqb/class/Getdata.class.php')){
    require_once '../../../../source/plugin/aljqb/class/Getdata.class.php';
    $getdata = new Getdata();
}
require_once '../../../../source/plugin/aljhb/function/function_core.php';
$settings_pay=C::t('#aljhb#aljhb_setting')->range();
//file_put_contents('d.txt',$key."\r",FILE_APPEND);
//file_put_contents('d.txt',$_GET['key']."\r",FILE_APPEND);
$qbapi = new Qbapi();
$keyarray = array(
    'aljorderid'=> $_GET['aljorderid'],
    'paytime' => $_GET['paytime'],
    'orderid' => $_GET['orderid'],
);
if($_GET['key']) {
    $keyarray['key'] = $settings_pay['qb_key']['value'];
    $key = $qbapi->createKey($keyarray);
    $getkey = $_GET['key'];
}elseif(file_exists('../../../../source/plugin/aljqb/class/Getdata.class.php')) {
    $appinfo = $getdata->getAppParam();
    $appinfo['posttime']=$_GET['posttime'];
    $key = $getdata->CreateAppSign($appinfo);
    $getkey = $_GET['sign'];
}
if($key == $getkey) {
    $orderid = $_GET['orderid'];
    $order = C::t('#aljhb#aljhb_order')->fetch($orderid);
    if($order['status'] == 1){
        $orderarray = array('status' => 2, 'buyer' => $_GET['aljorderid'], 'confirmdate' => TIMESTAMP);
        if($order['pluginid'] == 'aljol'){
            $hid=DB::insert('aljol_talk',array(
                'uid'=>$order['uid'],
                'username'=>$order['username'],
                'friendid'=>($order['hid']<0 || $order['h_num']==1) ? $order['hid'] : 0,
                'talk'=>'',
                'datetime'=>TIMESTAMP,
                'talkstate'=>1,
                'type'=>1,
            ),true);
            $orderarray['hid'] = $hid;
        }

        C::t('#aljhb#aljhb_order')->update($orderid,$orderarray);
        $order = C::t('#aljhb#aljhb_order')->fetch($orderid);
        send_hb($order['h_num'],$order['h_price'],$order['hid'],$order['pluginid'],$order['module'],$order['uid'],$orderid);
    }
    echo 'success';
    exit;
}
function unescape($str) {
    if(is_array($str)) {
        foreach($str as $tmp_key=> $tmp_value) {
            $str[$tmp_key] = unicode_decode($tmp_value);
        }
        return $str;
    }else {
        return unicode_decode($str);
    }
}
function unicode_decode($str) {
    $str = rawurldecode($str);
    preg_match_all("/(?:%u.{4})|&#x.{4};|&#\d+;|.+/U",$str,$r);
    $ar = $r[0];
    foreach($ar as $k=>$v) {
        if(substr($v,0,2) == "%u"){
            if(strtolower(CHARSET) == 'gbk'){
                $ar[$k] = iconv("UCS-2BE","gbk",pack("H4",substr($v,-4)));
            }else {
                $ar[$k] = iconv("UCS-2BE","UTF-8",pack("H4",substr($v,-4)));
            }

        }
        elseif(substr($v,0,3) == "&#x"){
            if(strtolower(CHARSET) == 'gbk'){
                $ar[$k] = iconv("UCS-2BE","gbk",pack("H4",substr($v,3,-1)));
            }else{
                $ar[$k] = iconv("UCS-2BE","UTF-8",pack("H4",substr($v,3,-1)));
            }
        }
        elseif(substr($v,0,2) == "&#") {
            if(strtolower(CHARSET) == 'gbk'){
                $ar[$k] = iconv("UCS-2BE","gbk",pack("n",substr($v,2,-1)));
            }else{
                $ar[$k] = iconv("UCS-2BE","UTF-8",pack("n",substr($v,2,-1)));
            }
        }
    }
    return join("",$ar);
}
//From: Dism��taobao��com
?>