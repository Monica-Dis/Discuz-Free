<?php

/*
 * ����: Discuz!�����ƹ�����
 * Ӧ�ø���֧�֣�https://dism.taobao.com/
 * DisM.taobao.Com
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//���24Сʱ�˿�
function hb_refund (){
    global $_G,$qbapi;
    $refundtime = $_G['cache']['plugin']['aljhb']['refundtime']?$_G['cache']['plugin']['aljhb']['refundtime']*3600:86400;
    //����2018-12-13 10:46:35�ĺ�������˿�
    $strtotime = '1544669195';
    //ȡ���������ĺ������1��
    $order = DB::fetch_first('select * from %t where status=2 and confirmdate>%d and confirmdate+%d<%d and h_num > y_num+o_num limit 1',array('aljhb_order',$strtotime,$refundtime,TIMESTAMP));

    if($order){
        //δ��ȡ������
        $hb_count_price = DB::result_first('select sum(price) from %t where orderid=%s and uid=0',array('aljhb_log',$order['orderid']));
        $hb_count = DB::result_first('select count(*) from %t where orderid=%s and uid=0',array('aljhb_log',$order['orderid']));
        if($hb_count_price > 0){
            if(DB::update('aljhb_order',array('status'=>3), array('orderid' => $order['orderid'],'status'=>2))){
                $queuearray = array(
                    'app_name' => 'aljhb',
                    'app_type' => 'aljhbrefund',
                    'app_phone' => '123456789',
                    'app_ip' => '123456789',
                );
                $balancearray = array(
                    'type'=> 'charge',
                    'uid'=>$order['uid'],
                    'price' => $hb_count_price,
                    'orderid'=> $order['orderid'],
                    'desc'=> $order['title'].',�����ʱδ��ȡ�꣬�˻�'.$hb_count_price.'Ԫ('.$order['pluginid'].','.$order['module'].','.$order['hid'].')',
                );
                $result = $qbapi->balance($queuearray,$balancearray);
                if($result['code'] == 200) {
                    //�����˿����
                    DB::query("update %t set o_num=%d where orderid = %s", array('aljhb_order',$hb_count,$order['orderid']));
                    //�����˿����
                    DB::query("update %t set o_num=o_num+%d where hid = %d and status=0", array('aljhb_count',$hb_count,$order['hid']));
                    //�ж��Ƿ�Ϊȫ�����꣬��״̬��Ϊ1���ڣ���״̬����
                    DB::query("update %t set status=1 where hid = %d and status=0 and y_num+o_num>=h_num", array('aljhb_count',$order['hid']));
                    //δ��ȡ�����Ϊ����
                    DB::update('aljhb_log',array('status'=>1), array('orderid' => $order['orderid']));
                }else{
                    DB::update('aljhb_order',array('status'=>2), array('orderid' => $order['orderid'],'status'=>3));
                }
            }

        }else{
            DB::query("update %t set y_num=h_num where orderid = %s", array('aljhb_order',$order['orderid']));
        }
    }
}
if($_G['cache']['plugin']['aljhb']['is_refund']){
    hb_refund();
}
//��ȡ��� //1 �ɹ� 2����� 3������ 4�쳣
function Receive($hid,$pluginid,$module){
	global $_G,$qbapi;
    $h_array = DB::fetch_first('select * from %t where hid=%d and pluginid=%s and module = %s',array('aljhb_count',$hid,$pluginid,$module));
    $h_price = DB::result_first("select price from %t where hid=%d and pluginid=%s and uid=%d and module = %s", array('aljhb_log',$hid,$pluginid,$_G['uid'],$module));
    if($h_price){
        return 2;
        exit;
    }
    if($h_array['h_num'] <= $h_array['y_num']){
        return 3;
        exit;
    }
    if($h_array['h_price'] <= 0 || $h_array['h_num'] <= 0){
        return 4;
        exit;
    }
    //ȡһ��δ���ڿպ����Ϊ����ȡ
    if(DB::query("update %t set uid=%d,username=%s,updatetime=%d where status=0 and hid=%d and pluginid=%s and uid=0 and module = %s LIMIT 1", array('aljhb_log',$_G['uid'],$_G['username'],TIMESTAMP,$hid,$pluginid,$module))){
        DB::query("update %t set y_num=y_num+1 where hid=%d and pluginid=%s and module = %s", array('aljhb_count',$hid,$pluginid,$module));
        DB::query("update %t set y_num=y_num+1 where hid=%d and pluginid=%s and module = %s", array('aljhb_order',$hid,$pluginid,$module));
        update_table($pluginid,$hid);
        $h_price = DB::result_first("select price from %t where hid=%d and pluginid=%s and uid=%d and module = %s ", array('aljhb_log',$hid,$pluginid,$_G['uid'],$module));
        //����Ǯ��
        $queuearray = array(
            'app_name' => 'aljhb',
            'app_type' => 'hb_txcancel',
            'app_phone' => '123456789',
            'app_ip' => '123456789',
        );
        $balancearray = array(
            'type'=> 'charge',
            'uid'=>$_G['uid'],
            'price' => $h_price,
            'orderid'=> dgmdate(TIMESTAMP, 'YmdHis').random(10),
            'desc'=> '��ú��'.$h_price.'Ԫ',
        );
        $result = $qbapi -> balance($queuearray,$balancearray);

        //����Ǯ��
        if(!$h_price || $result['code'] != 200){
            DB::query("update %t set uid=%d,updatetime=%d where hid=%d and pluginid=%s and uid=%s and module = %s LIMIT 1", array('aljhb_log',0,TIMESTAMP,$hid,$pluginid,$_G['uid'],$module));
            DB::query("update %t set y_num=y_num-1 where hid=%d and pluginid=%s and module = %s", array('aljhb_count',$hid,$pluginid,$module));
            DB::query("update %t set y_num=y_num-1 where hid=%d and pluginid=%s and module = %s", array('aljhb_order',$hid,$pluginid,$module));
            return 4;
            exit;
        }else{
            return 1;
            exit;
        }
    }
}
//��ȡ����ͬ��д���Ӧ�����
function update_table ($pluginid,$hid){
    global $_G;
    $plugin_array = array('aljhbx');
    if(in_array($pluginid,$plugin_array)){
        if($pluginid == 'aljhbx'){
            $table = 'aljhbx_post';
        }
        DB::query('update %t set y_num=y_num+1 where id=%d', array($table, $hid));
    }
}
//���������
function send_hb($h_num,$h_price=0,$hid=0,$pluginid='',$module='',$uid=0,$orderid=0){
    global $order;
    $countarray = DB::fetch_first('select * from %t where hid=%d and pluginid=%s and module=%s',array('aljhb_count',$hid,$pluginid,$module));
    if($countarray){
        $hb_num = intval($countarray['h_num'])+$h_num;
        $hb_price = $countarray['h_price']+$h_price;
        $hb_y_num = intval($countarray['y_num']);
        $updatearray = array(
            'h_num'     => $hb_num,
            'h_price'   => $hb_price,
            'y_num' => $hb_y_num,
            'status' => 0,
            'username' => $order['username'],
        );
        $wherearray = array(
            'hid' => $hid,
            'pluginid' => $pluginid,
            'module' => $module,
        );
        DB::update('aljhb_count',$updatearray,$wherearray);
    }else{
        $hb_num = $h_num;
        $hb_price = $h_price;
        $updatearray = array(
            'uid' => $uid,
            'username' => $order['username'],
            'hid' => $hid,
            'pluginid' => $pluginid,
            'h_price' => $h_price,
            'h_num' => $h_num,
            'module' => $module,
            'addtime' => TIMESTAMP,
            'updatetime' => TIMESTAMP,
        );
        DB::insert('aljhb_count',$updatearray);
        if($pluginid == 'aljhbx'){
            $order = C::t('#aljhb#aljhb_order')->fetch($orderid);
            hbx_sh_notice($order);
        }
    }
    $h_log = sendHB($h_price, $h_num);
    if($h_log){
        foreach($h_log as $h_k => $h_v){
            DB::insert('aljhb_log',array(
                'orderid' => $orderid,
                'hid' => $hid,
                'pluginid' => $pluginid,
                'module' => $module,
                'price' => $h_v,
                'addtime' => TIMESTAMP,
            ));
        }
    }
    if($pluginid == 'aljhbx') {
        DB::query('update %t set status=1, attes=1,h_price=%i,h_num=%d,y_num=%d where id=%d', array('aljhbx_post',$hb_price,$hb_num,$hb_y_num, $order['hid']));
    }
}
//�����緢��ϵͳ���Ѽ��޸����״̬
function hbx_sh_notice($order){
    DB::query('update %t set status=1, attes=1 where id=%d',array('aljhbx_post', $order['hid']));
    hb_notice($order['uid'], '�������ĸ�����Ϣ�����ͨ���� ���κ����ʻ�ӭ����ϵ�����ͷ�17191093889' ,$order['hid'],'aljhbx');
    $followlist = DB::fetch_all('select * from %t where fuid=%d', array('aljhbx_follow', $order['uid']));
    if($followlist){
        foreach($followlist as $follow){
            hb_notice($follow['uid'], '����ע���߱�Ա��'.$order['username'].'���ո��ַ������µĴ�������߱�Ŷ, �������Ϣ������ȡ�����' ,$order['hid'],'aljhbx');
        }
    }
}
//����ϵͳ����
function hb_notice ($uid,$mes='',$from_id='',$from_idtype=''){
    notification_add($uid, 'system', $mes ,array('from_id' =>$from_id,'from_idtype'=>from_idtype));
}
function sendHB($money_total, $num) {

    $rand_arr = array();
    for($i=0; $i<$num; $i++) {
        $rand = rand(1, 100);
        $rand_arr[] = $rand;
    }

    $rand_sum = array_sum($rand_arr);
    $rand_money_arr = array();
    $rand_money_arr = array_pad($rand_money_arr, $num, 0.01);  //��֤ÿ���������0.01

    foreach ($rand_arr as $key => $r) {
        $rand_money = number_format($money_total*$r/$rand_sum, 2);

        if($rand_money <= 0.01 || number_format(array_sum($rand_money_arr), 2) >= number_format($money_total, 2)) {
            $rand_money_arr[$key] = 0.01;
        } else {
            $rand_money_arr[$key] = $rand_money;
        }

    }

    $max_index = $max_rand = 0;
    foreach ($rand_money_arr as $key => $rm) {
        if($rm > $max_rand) {
            $max_rand = $rm;
            $max_index = $key;
        }
    }

    unset($rand_money_arr[$max_index]);
    //�����array_sum($rand_money_arr)һ����С��$money_total��
    $rand_money_arr[$max_index] = number_format($money_total - array_sum($rand_money_arr), 2);

    ksort($rand_money_arr);
    return $rand_money_arr;
}
?>
