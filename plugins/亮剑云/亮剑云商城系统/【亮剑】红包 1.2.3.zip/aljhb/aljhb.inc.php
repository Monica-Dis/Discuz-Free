<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!is_file('source/plugin/aljqb/class/Qbapi.class.php')){
    echo '���Ȱ�װǮ�������';
    exit;
}
require_once 'source/plugin/aljqb/class/Qbapi.class.php';
$qbapi = new Qbapi();
require_once DISCUZ_ROOT.'source/plugin/aljhb/include/common.php';
$hid = intval($_GET['hid']);
$pluginid = $_GET['pluginid'];
require_once 'source/plugin/aljhb/function/function_core.php';

if($_GET['act'] == 'red_packet_list'){
    $h_price = DB::result_first("select price from %t where hid=%d and pluginid=%s and uid=%d and module = %s ", array('aljhb_log',$hid,$pluginid,$_G['uid'],$_GET['module']));
    $datearray['price'] = $h_price;
    $hb_array = DB::fetch_first('select * from %t where hid=%d and pluginid=%s and module = %s',array('aljhb_count',$hid,$pluginid,$_GET['module']));
    $datearray['h_num'] = $hb_array['h_num'];//�������
    $datearray['y_num'] = ($hb_array['y_num'] > $hb_array['h_num']) ? $hb_array['h_num'] : $hb_array['y_num'];//������ٸ�
    $datearray['over'] = ($hb_array['h_num']-$hb_array['y_num']-$hb_array['o_num']) <0 ? 0 : $hb_array['h_num']-$hb_array['y_num']-$hb_array['o_num'];//��ʣ���ٸ�
    $datearray['o_num'] = $hb_array['o_num'];//���ڶ��ٸ�
    $datearray['avatar'] = avatar($hb_array['uid'], 'middle', true);
    $datearray['avatar'] = avatar($hb_array['uid'], 'middle', true);
    $currpage=$_GET['page']?$_GET['page']:1;
    $perpage=20;
    $start=($currpage-1)*$perpage;
    $red_log_array = DB::fetch_all("select * from %t where hid=%d and pluginid=%s and uid>0 and module = %s order by updatetime desc limit %d,%d", array('aljhb_log',$hid,$pluginid,$_GET['module'],$start,$perpage));
    foreach($red_log_array as $redk => $redv){
        $red_log_array[$redk]['updatetime'] = dgmdate($redv['updatetime'], 'u');
        $user = getuserbyuid($redv['uid']);
        $red_log_array[$redk]['username'] = $user['username'];
        $red_log_array[$redk]['avatar'] = avatar($redv['uid'], 'middle', true);
        unset($user);
    }
    $datearray['h_array'] = $red_log_array ? $red_log_array : 0;
    echo json_encode(ajaxPostCharSet_aljhb($datearray));
    exit;
}else if($_GET['act'] == 'parameter'){
    require_once DISCUZ_ROOT.'source/plugin/aljhb/static/class/wechatclient.lib.class.php';
    $wx_appid = $qbapi->getsettings();
    $wechat_client = new WeChatClient($wx_appid['appid'],$wx_appid['appsecret']);
    $signPackage = $wechat_client -> getJsApiSignPackage($_GET['url']);
    $signPackage['def_title'] = $settings_hb['def_title']['value'];
    $signPackage['def_desc'] = $settings_hb['def_desc']['value'];
    $signPackage['def_logo'] = $settings_hb['new_logo']['value'];
    //debug(ajaxPostCharSet_aljhb($signPackage));
    echo json_encode(ajaxPostCharSet_aljhb($signPackage));
    exit;
}else if($_GET['act'] == 'show_red_packet'){
    $datearray = array();
    $h_array = DB::fetch_first('select * from %t where hid=%d and pluginid=%s and module = %s',array('aljhb_count',$hid,$pluginid,$_GET['module']));
    if($_GET['module'] == 'per' && $h_array['uid'] == $_G['uid']){
        $datearray['status'] = -2;
        $user = getuserbyuid($h_array['uid']);
        $h_array['username'] = $user['username'];
        $datearray['h_array'] = $h_array;
        echo json_encode(ajaxPostCharSet_aljhb($datearray));
        exit;
    }
    if($h_array['status'] == 1){
        $datearray['status'] = -3;
        $user = getuserbyuid($h_array['uid']);
        $h_array['username'] = $user['username'];
        $datearray['h_array'] = $h_array;
        echo json_encode(ajaxPostCharSet_aljhb($datearray));
        exit;
    }
    if(!$h_array){
        $datearray['status'] = -1;
        $user = getuserbyuid($h_array['uid']);
        $h_array['username'] = $user['username'];
        $datearray['h_array'] = $h_array;
        echo json_encode(ajaxPostCharSet_aljhb($datearray));
        exit;
    }
    $user = getuserbyuid($h_array['uid']);
    $h_array['username'] = $user['username'];
    $h_price = DB::result_first("select price from %t where hid=%d and pluginid=%s and uid=%d and module = %s ", array('aljhb_log',$hid,$pluginid,$_G['uid'],$_GET['module']));
    if($h_price){
        $datearray['status'] = $h_price;
    }elseif($h_array['h_num'] <= $h_array['y_num']){
        $datearray['status'] = 1;
    }else{
        $datearray['status'] = 0;
    }
    $datearray['h_array'] = $h_array;
    echo json_encode(ajaxPostCharSet_aljhb($datearray));
    exit;
}else if($_GET['act'] == 'receive'){
    //1 �ɹ� 2����� 3������ 4�쳣
    $result = Receive($hid,$pluginid,$_GET['module']);
    echo $result;
    exit;
}else if($_GET['act'] == 'pay'){
    $price = $_GET['price'];
    $fee = 0;
    if($settings_hb['def_fee']['value']){
        $fee = $price*($settings_hb['def_fee']['value']/100);
        $fee = sprintf("%.2f", $fee);
    }
    $f_price = $price + $fee;
    $num = intval($_GET['num']);

    if($pluginid == 'aljol' && $_GET['module'] == 'per' && $hid>0){

        $aljol_user = getuserbyuid($hid);

        if($aljol_user['username']){
            $red_pecket_lists[$price]['title'] = '����'.$price.'Ԫ�����'.$aljol_user['username'];
        }

    }

    if($price >= 0.01 && $hid && $pluginid && $num){
        $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
        //status 1������ 2�Ѹ���
        DB::insert('aljhb_order',array(
            'orderid' => $orderid,
            'pluginid' => $pluginid,
            'hid' => $hid,
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'h_price' => $price,
            'h_num' => $num,
            'fee' => $fee,
            'f_price' => $f_price,
            'title' => $red_pecket_lists[$price]['title'],
            'submitdate' => TIMESTAMP,
            'status' => 1,
            'module' => $_GET['module'],
        ));
        $keyurlarray = array(
            'orderid' => $orderid,
            'time' => TIMESTAMP,
            'price' => $f_price,
            'keyname' => 'aljhb',
            'return_url' => $_SERVER['HTTP_REFERER'],
            'key' => $settings_hb['qb_key']['value'],
        );
        $url = $qbapi -> createUrl($keyurlarray);
        //debug($url);
        //$url = 'plugin.php?id=aljqb&act=confirmorder&orderid='.$orderid.'&time='.TIMESTAMP.'&price='.$f_price.'&keyname=aljhb&return_url=';
        dheader('location: ' . $url);
    }else{
        echo '�����쳣�������ԣ�';
        exit;
    }
}else{
    include template('aljhb:red_packet');
}
function ajaxPostCharSet_aljhb($arr) {
    if(is_array($arr)){
        if (strtolower(CHARSET) == 'gbk') {
            foreach ($arr as $key => $val) {
                if(is_array($val)){
                    $pt_goods[$key] = ajaxPostCharSet_aljhb($val);
                }else{
                    $pt_goods[$key] = diconv($val,'gbk','utf-8');
                }

            }
            return $pt_goods;
        }
        return $arr;
    } else {
        if (strtolower(CHARSET) == 'gbk') {
            return diconv($arr,'gbk','utf-8');
        }
        return $arr;
    }
}
?>