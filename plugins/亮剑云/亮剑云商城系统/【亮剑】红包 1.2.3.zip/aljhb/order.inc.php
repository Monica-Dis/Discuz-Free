<?php

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

loadcache('plugin');

$kw = strip_tags($_GET['kw']);
$currpage = $_GET['page'] ? $_GET['page'] : 1;
$perpage = 30;
$where = ' where 1 ';
$conn = array('aljhb_order');
if($kw){
    $where .= ' and uid=%d';
    $conn[] = $kw;
}
if($_GET['pluginid']){
    $where .= ' and pluginid=%s';
    $conn[] = $_GET['pluginid'];
}
if($_GET['date_s']){
    $date_s = strtotime($_GET['date_s']);
    $where .= ' and submitdate>=%d';
    $conn[] = $date_s;
}
if($_GET['date_e']){
    $date_e = strtotime($_GET['date_e']);
    $where .= ' and submitdate<%d';
    $conn[] = $date_e;
}
$zong_y_price = DB::result_first('select sum(f_price) from %t '.$where.' and status=2', $conn);
$zong_fee = DB::result_first('select sum(fee) from %t '.$where.' and status=2', $conn);
$zong_w_price = DB::result_first('select sum(f_price) from %t '.$where.' and status=1', $conn);
$num = DB::result_first('select count(*) from %t '.$where, $conn);
$start = ($currpage - 1) * $perpage;
$conn[] = $start;
$conn[] = $perpage;
$where .= ' order by submitdate desc limit %d,%d';

$loglist = DB::fetch_all('select * from %t '.$where, $conn);
$paging = helper_page :: multi($num, $perpage, $currpage, 'admin.php?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljhb&pmod=order', 0, 11, false, false);
include template('aljhb:order');
