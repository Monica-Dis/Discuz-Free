<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

//start to put your own code
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljhb_count` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `hid` int(11) NOT NULL,
  `pluginid` char(30) NOT NULL,
  `addtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `h_price` double(10,2) NOT NULL,
  `h_num` int(11) NOT NULL,
  `y_num` int(11) NOT NULL,
  `module` char(32) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `username` varchar(255) NOT NULL,
  `o_num` int(11) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljhb_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `addtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `hid` int(11) NOT NULL,
  `orderid` char(24) NOT NULL,
  `pluginid` char(30) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `module` char(32) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljhb_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` char(24) NOT NULL,
  `pluginid` char(30) NOT NULL,
  `hid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `h_price` double(10,2) NOT NULL,
  `h_num` int(11) NOT NULL,
  `y_num` int(11) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  `f_price` double(10,2) NOT NULL,
  `title` varchar(255) NOT NULL,
  `buyer` char(50) NOT NULL,
  `submitdate` int(11) NOT NULL,
  `confirmdate` int(11) NOT NULL,
  `payment` char(30) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `module` char(32) NOT NULL,
  `o_num` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hid` (`hid`),
  KEY `pluginid` (`pluginid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljhb_setting` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `a` varchar(255) NOT NULL,
  `b` varchar(255) NOT NULL,
  `c` text NOT NULL,
  `d` int(11) NOT NULL,
  `e` int(11) NOT NULL,
  PRIMARY KEY (`key`)
);
EOF;
runquery($sql);
if(!DB::result_first('select count(*) from %t where pluginname=%s',array('aljqb_secretkey','aljhb'))){
    loadcache('plugin');
    DB::insert('aljqb_secretkey',array('pluginname'=>'aljhb','secretkey'=>'shenmikey123','tokenurl'=>rtrim($_G['siteurl'],'/').'/source/plugin/aljhb/pay/pay.php'));
}
//finish to put your own code
$finish = TRUE;
?>
