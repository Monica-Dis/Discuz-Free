<?php

/*
 * ���ߣ�����
 * ��ϵQQ:578933760
 *
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$p_array = array('aljbd','aljqdx','aljol');
$act_array = array('view','goodview','consumeview','noticeview');
$no_act_array = array('aljqdx');
$settings_hb=C::t('#aljhb#aljhb_setting')->range();
$perfee = $settings_hb['def_fee']['value'];
$red_pecket_list = explode ("\n", str_replace ("\r", "", $settings_hb['red_pecket_num']['value']));
foreach($red_pecket_list as $key=>$value){
    $arr=explode('=',$value);
    if($settings_hb['def_fee']['value']){
        $fee = $arr[0]*($settings_hb['def_fee']['value']/100);
        $fee = sprintf("%.2f", $fee);
    }
    $red_pecket_lists[$arr[0]]=array(
        'title' =>  $arr[0].'Ԫ��'.$arr[1].'��',
        'price' => $arr[0],
        'num'   => $arr[1],
        'fee'   => $fee,
        'total'   => $fee+$arr[0],
    );
    unset($fee);
    unset($arr);
}
if(in_array($_GET['id'],$no_act_array)){//����Ҫ��ϢID

    if(!intval($_GET['lid'])){
        $_GET['lid'] = 1;
    }
}
//s ͳһ��ϢID
if($_GET['id'] == 'aljbd'){
    if($_GET['bid'] && $_GET['act'] == 'view'){
        $_GET['lid'] = $_GET['bid'];
        $_GET['module'] = 'brand';
    }
    if($_GET['gid'] && $_GET['act'] == 'goodview'){
        $_GET['lid'] = $_GET['gid'];
        $_GET['module'] = 'goods';
    }
    if($_GET['cid'] && $_GET['act'] == 'consumeview'){
        $_GET['lid'] = $_GET['cid'];
        $_GET['module'] = 'consume';
    }
    if($_GET['nid'] && $_GET['act'] == 'noticeview'){
        $_GET['lid'] = $_GET['nid'];
        $_GET['module'] = 'notice';
    }
}
//e ͳһ��ϢID
$hid = intval($_GET['lid']);
if($_GET['id'] && $hid && (in_array($_GET['act'],$act_array) || in_array($_GET['id'],$no_act_array))){//��Ҫ��������ж�

    $hb_array = DB::fetch_first('select * from %t where hid=%d and pluginid=%s and module = %s',array('aljhb_count',$hid,$_GET['id'],$_GET['module']));
    if($hb_array['uid']){
        $hb_array['user'] = getuserbyuid($hb_array['uid']);
    }

    $h_log = DB::result_first("select count(*) from %t where hid=%d and pluginid=%s and uid=%d and module = %s ", array('aljhb_log',$hid,$_GET['id'],$_G['uid'],$_GET['module']));
}
if(in_array($_GET['id'],$p_array)){//��Ҫ��weui��ʽ
    $weui = 1;
}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
    $iswechat = true;
}
?>
