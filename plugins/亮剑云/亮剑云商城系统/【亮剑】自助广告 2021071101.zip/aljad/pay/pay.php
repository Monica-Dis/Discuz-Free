<?php
	define('DISABLEXSSCHECK',true);
	require '../../../../source/class/class_core.php';
	$discuz = C::app();
	$discuz->init();
	loadcache('plugin');
	$config = $_G['cache']['plugin']['aljad'];
	require_once '../../../../source/plugin/aljqb/class/Qbapi.class.php';
	$qbapi = new Qbapi();
	$keyarray = array(
		'aljorderid'=> $_GET['aljorderid'],
		'paytime' => $_GET['paytime'],
		'orderid' => $_GET['orderid'],
		'key'=>  $config['aljadkey'],
	);
	$key = $qbapi->createKey($keyarray);
	file_put_contents('d.txt',$key."\r",FILE_APPEND);
	file_put_contents('d.txt',$_GET['key']."\r",FILE_APPEND);
	if($key == $_GET['key']) {
		$order = DB::fetch_first('select * from %t where orderid=%s',array('aljad_adorder',$_GET['orderid']));
		$updatearray =array(
			'paytime' => $_GET['paytime'],
			'transaction_id' => $_GET['aljorderid'],
			'status'=>1,
		);
		if(DB::update('aljad_adorder',$updatearray,array('orderid' => $order['orderid']))) {
			echo 'success';
			exit;
		}
	}

	
?>