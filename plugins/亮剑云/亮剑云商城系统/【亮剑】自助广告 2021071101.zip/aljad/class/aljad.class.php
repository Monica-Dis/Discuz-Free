<?php
	Class Aljad {
		//���ɶ���
		public function createOrder($orderparams=array()) {
			if(!empty($orderparams)) {
				$orderparams['createtime'] = TIMESTAMP;
				$orderparams['orderid'] = $this->createOrderid();
				DB::insert('aljad_adorder',$orderparams);
				return $orderparams;
			}	
		}
		//��鶩����
		public function createOrderid() {
			$orderid = 'aljad'.random(7).dgmdate(TIMESTAMP, 'His');
			$check = DB::result_first('select count(*) from %t where orderid=%s',array('aljad_adorder',$orderid));
			while($check){
				$this->createOrderid();
			}
			return $orderid;
		}
		//���ɹ��λid 
		public function createAdid($keyname='',$module='',$height=0) {
			if($keyname && $module) {
				$ad = DB::fetch_first('select * from %t where keyname=%s and module=%s',array('aljad_adsettings',$keyname,$module));
				if($ad) {
					return $ad['id'];
				}else {
					return DB::insert('aljad_adsettings',array('keyname'=>$keyname,'module'=>$module,'adheight'=>$height),true);
				}
			}
			
		}
		
	}
//From: d'.'is'.'m.ta'.'obao.com
?>