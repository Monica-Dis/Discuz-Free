<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
/*
 * Copyright (c) 2021 by dism.taobao.com
 * 技术支持: https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljad_adorder` (
  `orderid` varchar(255) NOT NULL,
  `uid` int(10) DEFAULT '0',
  `username` varchar(255) DEFAULT '',
  `starttime` varchar(255) DEFAULT '0',
  `endtime` varchar(255) DEFAULT '0',
  `createtime` varchar(255) DEFAULT '0',
  `paytime` varchar(255) DEFAULT '0',
  `keyname` varchar(255) DEFAULT '',
  `adid` int(10) DEFAULT '0',
  `price` double(15,2) NOT NULL,
  `day` int(10) NOT NULL,
  `status` int(10) DEFAULT '0',
  `transaction_id` varchar(255) DEFAULT '',
  `adimg` varchar(255) NOT NULL,
  `adurl` varchar(255) NOT NULL,
  PRIMARY KEY (`orderid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljad_adsettings` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `keyname` varchar(255) DEFAULT NULL,
  `module` varchar(255) DEFAULT NULL,
  `adheight` varchar(255) NOT NULL,
  `adimg` varchar(255) NOT NULL,
  `adprice` double(15,2) NOT NULL,
  `adopen` int(10) NOT NULL,
  `maxday` int(10) NOT NULL,
  PRIMARY KEY (`id`)
);
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>