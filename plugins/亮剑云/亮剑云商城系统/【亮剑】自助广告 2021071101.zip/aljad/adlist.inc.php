<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

loadcache('plugin');
$config = $_G['cache']['plugin']['aljad'];
if($_GET['act'] == 'editad') {
	$adid = intval($_GET['adid']);
	$setdata = DB::fetch_first('select * from %t where id=%d',array('aljad_adsettings',$adid));
	if(submitcheck('formhash')) {
		$updatearray=array();
        $updatearray['adprice'] = $_GET['adprice'] + 0;
		$updatearray['maxday'] = $_GET['maxday'] + 0;
		$updatearray['adprice'] = round($updatearray['adprice'],2);
		if($updatearray['adprice']<=0) {
			$updatearray['adprice'] = 0;
		}

        if($updatearray['maxday']<=0) {
            $updatearray['maxday'] = 0;
        }
		
		if(isset($_GET['pic'])) {
			$src = saveimg($_GET['pic']);
			if(is_file($setdata['adimg'])) {
				@unlink($setdata['adimg']);
			}
			$updatearray['adimg'] = $src;
		}
		$updatearray['adopen'] = intval($_GET['adopen']);
		DB::update('aljad_adsettings', $updatearray,array('id'=>$adid));
		cpmsg('&#26356;&#26032;&#25104;&#21151;','action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljad&pmod=adlist&act=editad&adid='.$adid); 
		
	}else {
		include template('aljad:editad'); 
	} 
}else if($_GET['act'] == 'delimg') {
	$adid = intval($_GET['adid']);
	$setdata = DB::fetch_first('select * from %t where id=%d',array('aljad_adsettings',$adid));
	if(is_file($setdata['adimg'])) {
		@unlink($setdata['adimg']);
	}
	if(DB::update('aljad_adsettings',array('adimg'=>''),array('id'=>$adid))){
		echo 1;
	}else {
		echo 0;
	}
} else {
	$currpage = $_GET['page'] ? intval($_GET['page']) : 1;
	$perpage = 16;
	$start = ($currpage - 1) * $perpage;
	$num = DB::result_first('select count(*) from %t',array('aljad_adsettings'));
	$orderlist = DB::fetch_all('select * from %t order by id asc limit %d,%d',array('aljad_adsettings',$start,$perpage));
	foreach($orderlist as $tmp_key => $tmp_value) {
		$ordercount = DB::fetch_first('select * from %t where keyname=%s and adid=%d and status=1 and starttime<=%d and endtime>=%d',array('aljad_adorder',$tmp_value['keyname'],$tmp_value['id'],TIMESTAMP,TIMESTAMP));
		if(!empty($ordercount)) {
			$tmp_value['adimg'] = !empty($ordercount['adimg'])?$ordercount['adimg']:'source/plugin/aljad/static/images/zs.png';
			$tmp_value['state'] = 1;
		 }else {
			$tmp_value['adimg'] = !empty($tmp_value['adimg'])?$tmp_value['adimg']:'source/plugin/aljad/static/images/zs.png';
			$tmp_value['state'] = 0;
		}
		$orderlist[$tmp_key] = $tmp_value;
	}
	$paging = helper_page :: multi($num, $perpage, $currpage, 'admin.php?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljad&pmod=adlist', 0, 11, false, false);
	include template('aljad:adlist'); 
}

function saveimg($pic) {
    $rand = rand(100, 999);
    $pics = date("YmdHis").$rand.'.png';
    $dir='source/plugin/aljad/static/imgfile/'.date('Ymd',TIMESTAMP).'/';
    if(!is_dir($dir)) {
        @mkdir($dir, 0777);
    }
    $src = $dir. $pics;
	if(file_put_contents($src,file_get_contents($pic))) {
		return $src;
	}else {
		return '';
	}
	
}
 ?>