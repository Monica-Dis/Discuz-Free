<?php
/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once 'source/plugin/aljhtx/class/class_aljhtx.php';
$login_callback = 'member.php?mod=logging&action=login&referer=plugin.php?id=aljad%26act='.$_GET['act'];
if(($_G['cache']['plugin']['aljwx'] || $_G['cache']['plugin']['aljwsq']) && strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
    define('IN_MINI', '1');
}
if($_GET['act'] != 'getad'){
    if(is_file('source/plugin/aljqb/class/Qbapi.class.php')) {
        require_once 'source/plugin/aljqb/class/Qbapi.class.php';
        $qbapi = new Qbapi();
        $is_aljad = true;
    }else {
        $is_aljad = false;
    }
}
$is_aljad = true;
require_once 'source/plugin/aljad/class/aljad.class.php';
$config = $_G['cache']['plugin']['aljad'];
$aljad = new Aljad();
$act = htmlspecialchars($_GET['act']);
if($act == 'getad') {
	$geturl = base64_encode(ltrim($_SERVER['HTTP_REFERER'],'/'));
	$keyname = $_GET['keyname'];
	$module = $_GET['module'];
	$height = $_GET['height']?$_GET['height']:'auto';
	//���÷�������url
	GsetCookie($keyname.$module, $geturl,'');
	$adid = $aljad->createAdid($keyname,$module,$height);
	$addata = DB::fetch_first('select * from %t where id=%d',array('aljad_adsettings',$adid));
	if(!$addata['adopen']) {
		$is_addata = DB::fetch_first('select * from %t where keyname=%s and adid=%d and status=1 and starttime<=%d and endtime>=%d',array('aljad_adorder',$keyname,$adid,TIMESTAMP,TIMESTAMP));
        if($is_addata) {
            $url = $is_addata['adurl']?$is_addata['adurl']:'#';
            if($_GET['pc'] == 'yes'){
                $imgscr = $is_addata['adimg']?$is_addata['adimg']:'source/plugin/aljad/static/images/zs_pc.jpg';
            }else{
                $imgscr = $is_addata['adimg']?$is_addata['adimg']:'source/plugin/aljad/static/images/zs.png';
            }

        }else {
            $url = 'plugin.php?id=aljad&act=createorder&keyname='.$keyname.'&adid='.$adid.'&adheight='.$height;
            if($_GET['pc'] == 'yes'){
                $imgscr = is_file($addata['adimg'])?$addata['adimg']:'source/plugin/aljad/static/images/zs_pc.jpg';
            }else{
                $imgscr = is_file($addata['adimg'])?$addata['adimg']:'source/plugin/aljad/static/images/zs.png';
            }

        }
        $buyurl = "\'".'plugin.php?id=aljad&act=createorder&keyname='.$keyname.'&adid='.$adid.'&adheight='.$height."\'";
		echo "document.write('";
		echo '<div style="width:100%;padding:0%;display:block;position:relative;font-size:0;">';
		if($is_addata['uid'] == $_G['uid'] && $_G['uid']) {
			$settingsurl = 'plugin.php?id=aljad&act=adsettings&orderid='.$is_addata['orderid'];
			$settingsurl = "\'".$settingsurl."\'";
			echo '<span style="position:absolute;bottom:0;left: 0;font-size: 14px;background: rgba(0,0,0,.3);width: 40px;text-align:center;z-index:600;color:#fff;" onclick="location.href='.$settingsurl.'">&#32534;&#36753;</span>';
		}
		echo '<a href="'.$url.'" style="display:inline-block;line-height:0px;font-size: 0px;">';
		echo '<img src="'.$imgscr.'" style="width:100%;height:'.$height.'"/>';
		echo '</a>';
		echo '<span onclick="location.href='.$buyurl.'" style="position: absolute;right: 0;bottom: 0;background: rgba(0,0,0,.3);width:36px;text-align: center;z-index: 600;color:#fff;font-size: 12px;">&#24191;&#21578;</span>';
		echo '</div>';
		echo "');";
		exit;
	}else {
		exit;
	}
}else if($act == 'createorder') {
	if(!$_G['uid']){
		dheader("location:".$login_callback);
		exit;
	}
	$keyname = $_GET['keyname'];
	$adid = intval($_GET['adid']);
	$addata = DB::fetch_first('select * from %t where id=%d',array('aljad_adsettings',$adid));
	$adheight = $_GET['adheight'];
	$orderlist = DB::fetch_all('select * from %t where keyname=%s and adid=%d and status=1 and endtime>=%s order by starttime asc',array('aljad_adorder',$keyname,$adid,TIMESTAMP));
	foreach($orderlist as $k => $v){
        if(strtolower(CHARSET) == 'gbk'){
            $v['username'] = diconv($v['username'], gbk, 'utf-8');
            $orderlist[$k] = $v;
        }

    }
	if($orderlist) {
		$stime = DB::result_first('select max(endtime) from %t where keyname=%s and adid=%d and status=1 and endtime>=%s',array('aljad_adorder',$keyname,$adid,TIMESTAMP));
		if($stime) {
			$stime = date('Y-m-d ',$stime+1);//+1s��Ϊ��ǰ����+1��
		}else {
			$stime = date('Y-m-d ',TIMESTAMP);//��ȡ��ǰ����
		}
	}else {
		$stime = date('Y-m-d ',TIMESTAMP);//��ȡ��ǰ����
	}
    $estime = date('Y-m-d ',TIMESTAMP+86400*(($addata['maxday']?$addata['maxday']:1)-1));
	$addata['adprice'] = $addata['adprice']>0?$addata['adprice']:$config['dayprice'];
	$guize = str_replace ("{price}", $addata['adprice'], $config['guize']);
	$guize = str_replace ("{height}", $adheight, $guize);
	if(strtolower(CHARSET) == 'gbk'){
		$guize = diconv($guize, gbk, 'utf-8');
	}
	include template('aljad:createorder');
}else if($act == 'confirmorder') {
	if(!$is_aljad) {
		$tips = array('status'=>1,'message'=>'&#26410;&#23433;&#35013;&#38065;&#21253;&#25554;&#20214;');//δ��װǮ�����
		echo json_encode(ajaxPostCharSet_aljad($tips));
		exit;
	}
	$keyname = htmlspecialchars($_GET['keyname']);
	$adid = intval($_GET['adid']);
	$starttime = strtotime($_GET['starttime']);
	$endtime = strtotime($_GET['endtime']);
	$today = strtotime(date('Y-m-d', time()));
	$addata = DB::fetch_first('select * from %t where id=%d',array('aljad_adsettings',$adid));
	if($starttime<$today) {
		$tips = array('status'=>1,'message'=>'&#24320;&#22987;&#26102;&#38388;&#19981;&#24471;&#23567;&#20110;&#24403;&#21069;&#26102;&#38388;');//��ʼʱ�䲻��С�ڵ�ǰʱ��
		echo json_encode(ajaxPostCharSet_aljad($tips));
		exit;
	}
	$endtime = $endtime+86399;
	$time = $endtime - $starttime;
	$day = ceil($time/24/60/60);
	if($starttime > $endtime) {
		$tips = array('status'=>1,'message'=>'&#24320;&#22987;&#26102;&#38388;&#19981;&#24471;&#22823;&#20110;&#32467;&#26463;&#26102;&#38388;');//��ʼʱ�䲻�úͽ���ʱ��һ��
		echo json_encode(ajaxPostCharSet_aljad($tips));
		exit;
	}
    if($addata['maxday'] && ($day > $addata['maxday'] || DB::fetch_first('select * from %t where uid=%d and status=1 and adid=%d and endtime>%d', array('aljad_adorder', $_G['uid'], $adid, TIMESTAMP)))) {
        $tips = array('status'=>1,'message'=>'&#36229;&#36807;&#26368;&#22823;&#36141;&#20080;&#22825;&#25968;');//�������������
        echo json_encode(ajaxPostCharSet_aljad($tips));
        exit;
    }
	
	if($day<=0) {
		$tips = array('status'=>1,'message'=>'&#26102;&#38388;&#38169;&#35823;');//ʱ�����
		echo json_encode(ajaxPostCharSet_aljad($tips));
		exit;
	}
	if($addata['adprice']>0) {
		$dayprice = $addata['adprice']?substr(sprintf("%.3f",$addata['adprice']+0),0,-1):0;
	}else {
		$dayprice = $config['dayprice']?substr(sprintf("%.3f",$config['dayprice']+0),0,-1):0;
	}
	
	$price = $day*$dayprice;
	if($price<=0) {
		$tips = array('status'=>1,'message'=>'&#37329;&#39069;&#19981;&#24471;&#23567;&#20110;&#48;');//����С��0
		echo json_encode(ajaxPostCharSet_aljad($tips));
		exit;
	}else {
		$price = substr(sprintf("%.3f",$price),0,-1);
	}
	$keydata = DB::fetch_all('select * from %t where keyname=%s and adid=%d and status=1 and endtime>=%s',array('aljad_adorder',$keyname,$adid,TIMESTAMP));
	foreach ($keydata as $tmp_key => $tmp_value) {
		if($tmp_value['starttime'] <= $starttime && $tmp_value['endtime'] >= $starttime) {
			$tips = array('status'=>1,'message'=>'&#35813;&#26102;&#38388;&#27573;&#20869;&#24050;&#32463;&#26377;&#20154;&#20351;&#29992;&#20102;&#36825;&#20010;&#24191;&#21578;&#20301;&#32622;');//��ʱ������Ѿ�����ʹ����������λ��
			echo json_encode(ajaxPostCharSet_aljad($tips));
			exit;
		}
		if($tmp_value['starttime'] <= $endtime && $tmp_value['endtime'] >= $endtime) {
			$tips = array('status'=>1,'message'=>'&#35813;&#26102;&#38388;&#27573;&#20869;&#24050;&#32463;&#26377;&#20154;&#20351;&#29992;&#20102;&#36825;&#20010;&#24191;&#21578;&#20301;&#32622;');//��ʱ������Ѿ�����ʹ����������λ��
			echo json_encode(ajaxPostCharSet_aljad($tips));
			exit;
		}
	}
	$orderparams = array(
		'uid'=> $_G['uid'],
		'username'=>$_G['username'],
		'starttime'=> $starttime,
		'endtime'=> $endtime,
		'keyname'=> $keyname,
		'adid' => $adid,
		'price'=>$price,
		'day'=>$day,
	);
	$params = $aljad->createOrder($orderparams);
	$dataparams = array(
		'orderid'=> $params['orderid'],
		'time' => $params['createtime'],
		'price'=> $params['price'],
		'keyname' => 'aljad',
		'key'=> $config['aljadkey'],
		'return_url'=>$_G['siteurl'].'plugin.php?id=aljad&act=adsettings&orderid='.$params['orderid'],	
	);
	$url = $qbapi->createUrl($dataparams);
	$tips = array('status' => 0,'url'=>$url);
	echo json_encode(ajaxPostCharSet_aljad($tips));
	exit;
}else if($act == 'adsettings') {
	if(!$_G['uid']){
		dheader("location:".$login_callback);
		exit;
	}
	
	$orderid = $_GET['orderid'];
	$order = DB::fetch_first('select * from %t where orderid=%s and status=1 and endtime>=%s',array('aljad_adorder',$orderid,TIMESTAMP));
	if($order) {
		$addata = DB::fetch_first('select * from %t where id=%d',array('aljad_adsettings',$order['adid']));
		$url = base64_decode($_COOKIE[$addata['keyname'].$addata['module']]);
		include template('aljad:adsettings');
	}else {
		include template('aljad:tip');
	}
	
}else if($act == 'addendad') {
	$orderid = $_GET['orderid'];
	$pic = $_GET['pic'];
	$adurl = $_GET['adurl'];
	$order = DB::fetch_first('select * from %t where orderid=%s and uid=%d',array('aljad_adorder',$orderid,$_G['uid']));
	if(!empty($order)) {
		if(!is_file($pic)) {
			@unlink($order['adimg']);
			$pic = T::saveimg($pic,'source/plugin/aljad/static/imgfile/');
		}
		$updatearray = array(
			'adimg' => $pic,
			'adurl' => $adurl,
		);
		if(DB::update('aljad_adorder',$updatearray,array('orderid'=> $orderid))) {
			$addata = DB::fetch_first('select * from %t where id=%d',array('aljad_adsettings',$order['adid']));
			$url = base64_decode($_COOKIE[$addata['keyname'].$addata['module']]);
			$tips = array('status' => 1,'message'=>'&#24191;&#21578;&#35774;&#32622;&#20462;&#25913;&#25104;&#21151;','url'=>$url);//��������޸ĳɹ�
			echo json_encode(ajaxPostCharSet_aljad($tips));
			exit;
		}else {
			$tips = array('status' => 1,'message'=>'&#35831;&#21247;&#37325;&#22797;&#35774;&#32622;');//�����ظ�����
			echo json_encode(ajaxPostCharSet_aljad($tips));
			exit;
		}
	}else {
		$tips = array('status' => 1,'message'=>'&#35746;&#21333;&#19981;&#23384;&#22312;');//����������
		echo json_encode(ajaxPostCharSet_aljad($tips));
		exit;
	}
}
function ajaxPostCharSet_aljad($arr) {
	if(is_array($arr)){
		if (strtolower(CHARSET) == 'gbk') {
			foreach ($arr as $key => $val) {
				if(is_array($val)){
					$pt_goods[$key] = ajaxPostCharSet_aljad($val);
				}else{
					$pt_goods[$key] = diconv($val,'gbk','utf-8');
				}

			}
			return $pt_goods;
		}
		return $arr;
	} else {
		if (strtolower(CHARSET) == 'gbk') {
			return diconv($arr,'gbk','utf-8');
		}
		return $arr;
	}
}
function saveimg($pic) {
    global $_G;
    $rand = rand(100, 999);
    $pics = date("YmdHis").$rand.'.png';
    $dir='source/plugin/aljad/static/imgfile/'.date('Ymd',TIMESTAMP).'/';
    if(!is_dir($dir)) {
        @mkdir($dir, 0777);
    }
    $src = $dir. $pics;
    if(IN_MINI == 1){
        require_once DISCUZ_ROOT.'source/plugin/aljwx/class/wechatclient.lib.class.php';
        $wechat_client = new WeChatClient($_G['cache']['plugin']['aljwx']['g_appid'],$_G['cache']['plugin']['aljwx']['g_AppSecret']);
        $return = $wechat_client -> download($pic);
        if(file_put_contents(DISCUZ_ROOT.'./'.$src, $return) !== false){

            return $src;
        }else {
            return '';
        }
    }else {
        file_put_contents($src, file_get_contents($pic));
        return $src;
    }
}
function GsetCookie($name, $value, $expire = null){
    //����ʱ��
    if(empty($expire)) {
		$expire = time() + 86400;
	}else {
		$expire = time() + $expire;
	}
    $_COOKIE[$name] = $value;
    //�ж�value�Ƿ�������
    if(is_array($value)){
        foreach ($value as $k => $v){
            if(empty($v)) continue;
            setcookie($name . "[$k]", $v, $expire);
        }
    }else{
        setcookie($name, $value, $expire);
    }
}
//From: d'.'is'.'m.ta'.'obao.com
?>