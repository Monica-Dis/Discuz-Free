<?php
/*
 * Copyright (c) 2021 by dism.taobao.com
 * 技术支持: https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 */
if($_GET['adminedit']!='yes') {
	if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
		exit('Access Denied');
	}
}
if($_G['groupid']!=1){
	exit;
}if($_GET['act'] == 'delete'){
    if(is_array($_GET['delete'])) {
        foreach($_GET['delete'] as $id) {
			$orderdata = DB::fetch_first('select * from %t where orderid=%s',array('aljad_adorder',$id));
			if(is_file($orderdata['img'])) {
				@unlink($orderdata['img']);
			}
			DB::query('delete from %t where orderid=%s',array('aljad_adorder',$id));
        }
    }
    cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljad&pmod=order');
}else if ($_GET['act'] == 'delimg') { //后台删除过期订单图片
	$allorder = DB::fetch_all('select * from %t where status=1 and endtime<%d and adimg!=%s',array('aljad_adorder',TIMESTAMP,0)); 
	if($allorder) {
		foreach($allorder as $tmp_key => $tmp_value) {
			if(is_file($tmp_value['adimg'])) {
				@unlink($tmp_value['adimg']);
			}
			DB::update('aljad_adorder',array('adimg'=>0),array('orderid'=> $tmp_value['orderid']));
		}
		$tips = array('status'=>1);
		echo json_encode($tips);
		exit;
	}else {
		$tips = array('status'=>0);
		echo json_encode($tips);
		exit;
	}
	
}else{
	$orderid = addslashes($_GET['orderid']);
	$username = addslashes($_GET['username']);	
	$currpage = $_GET['page'] ? intval($_GET['page']) : 1;
	$perpage = 16;
	$start = ($currpage - 1) * $perpage;
	$where  = 'where 1 ';
	$conn = array('aljad_adorder');
	if($_GET['orderid']){
		$where .= ' and orderid=%s ';
		$conn[] = $_GET['orderid'];
	}

	if($_GET['username']){
		$where .= ' and username like %i ';
		$conn[] = "'%".$username."%'";
	}
	$num = DB::result_first('select count(*) from %t '.$where,$conn);
	$where .=  'order by createtime desc limit %d,%d';
	$conn[] = $start;
	$conn[] = $perpage;
	$orderlist = DB::fetch_all('select * from %t '.$where,$conn);
	$paging = helper_page :: multi($num, $perpage, $currpage, 'admin.php?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljad&pmod=order&orderid='.$_GET['orderid'].'&username='.$username, 0, 11, false, false);
	include template('aljad:order');
}
//From: d'.'is'.'m.ta'.'obao.com
?>