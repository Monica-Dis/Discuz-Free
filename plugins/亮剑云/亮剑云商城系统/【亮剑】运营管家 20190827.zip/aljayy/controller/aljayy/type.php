<?php

/**
 * Controller�Ļ����ģ��
 *
 * @author DisM!Ӧ������[dism.taobao.com]
 * @version 2019081401
 * @link https://dism.taobao.com/?
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class TypeAction{
    public $page;
    public $bid;

    public function __construct($page) {
        $this->page = $page;
    }

    /**
     * ��Ʒ����
     *
     * @return void
     */
    public function type(){
        $mall_type = 'aljayy_type';
        if($this->page->get->do=='deleterow'){
            $type_id=$_GET['typeid'];

            DB::query('delete from %t where id=%d',array($mall_type,$type_id));
            echo '<script>parent.tips("'.lang("plugin/aljayy","type_php_1").'");</script>';
            exit;


        }
        if(submitcheck('formhash')) {
            $type_name_first_old= $_GET['type_name_first_old'];
            $type_name_first = $_GET['type_name_first'];
            $type_displayorder_first_old= $_GET['type_displayorder_first_old'];
            $type_displayorder_first=$_GET['type_displayorder_first'];
            $type_name_second_old=$_GET['type_name_second_old'];
            $type_name_second= $_GET['type_name_second'];
            $type_displayorder_second_old=$_GET['type_displayorder_second_old'];
            $type_displayorder_second=$_GET['type_displayorder_second'];

            if(is_array($type_name_first_old) && $type_name_first_old){
                foreach($type_name_first_old as  $tmp_key => $tmp_value){
                    DB::query('update %t set subject=%s where id=%d ',array($mall_type, $tmp_value, $tmp_key));
                }
            }
            if(is_array($type_displayorder_first_old) && $type_displayorder_first_old){
                foreach($type_displayorder_first_old as  $tmp_key => $tmp_value){
                    DB::query('update %t set displayorder=%d where id=%d',array($mall_type, $tmp_value, $tmp_key));
                }
            }
            if(is_array($type_name_second_old) && $type_name_second_old){
                foreach($type_name_second_old as  $tmp_key => $tmp_value){
                    foreach($tmp_value as  $tmp_key_second => $tmp_value_second){
                        DB::query('update %t set subject=%s where id=%d',array($mall_type,$tmp_value_second,$tmp_key));
                    }
                }

            }
            if(is_array($type_displayorder_second_old) && $type_displayorder_second_old){
                foreach($type_displayorder_second_old as $tmp_key =>$tmp_value){
                    foreach($tmp_value as $tmp_key_second =>$tmp_value_second){
                        DB::query('update %t set displayorder=%d where id=%d',array($mall_type,$tmp_value_second,$tmp_key));
                    }
                }

            }
            if(is_array($type_name_first)){
                foreach($type_name_first as $tmp_key =>$tmp_value){
                    if(empty($tmp_value)) {
                        continue;
                    }
                    DB::insert($mall_type,array(
                        'subject'=>$tmp_value,
                        'displayorder' => $type_displayorder_first[$tmp_key],
                    ));
                }
            }
            if(is_array($type_name_second)){
                foreach ($type_name_second as $tmp_key=> $tmp_value){
                    foreach($tmp_value as $tmp_key_second => $tmp_value_second){
                        DB::insert($mall_type,array(
                            'subject'=>$tmp_value_second,
                            'upid'=>$tmp_key,
                            'displayorder' => $type_displayorder_second[$tmp_key][$tmp_key_second],
                        ));
                    }
                }
            }
            echo '<script>parent.tips("'.lang("plugin/aljayy","type_php_2").'");</script>';
            exit;
        }else{
            $type_upid = $_GET['upid'] ? intval($_GET['upid']) : 0;
            $page=!empty($_GET['page'])?intval($_GET['page']):1;
            $pagesize=1000;
            $offset=($page-1) * $pagesize;
            $type_list=DB::fetch_all('select * from %t where upid=%d order by displayorder asc limit %d,%d',array($mall_type,$type_upid,$offset,$pagesize));

            $this->page->assign('mall_type', $mall_type, true);
            $this->page->assign('type_list', $type_list, true);

            $this->page->display();
        }
    }

    public function upload(){
        $file = T::upload('file');
        DB::update('aljayy_type', array('pic' => $file['file']), array('id' => $this->page->get->type_id));
        T::responseJson(array('code' => 0, 'file' => $file['file']));
    }

    public function uploadContract(){
        $data = DB::fetch_first('select * from %t where id=%d', array('aljbd_type_brand', $this->page->get->type_id));
        $this->page->assign('type_id', $this->page->get->type_id, true);
        $this->page->assign('pic', $data['pic'], true);
        $this->page->display();
    }
}

