<?php

/**
 * �������̳�
 *
 * @author DisM!Ӧ������[dism.taobao.com]
 * @version 2019072701
 * @link https://dism.taobao.com/?
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class GoodsAction{
    public $page;

    public function __construct() {
        global $requestPage;
        $this->page = $requestPage;
    }

    public function list_index(){
        global $_G;
        if($this->page->get->render == 'yes'){
            $per = 20;
            $page = $this->page->get->page>0 ? $this->page->get->page :1;
            $start = ($page - 1) * $per;

            $where = ' where a.rubbish = 0 ';
            $conn = array('aljbd_goods', 'aljayy_goods');
            if($_GET['search']){
                $search = '%'.stripsearchkey($_GET['search']).'%';
                $where .= ' and a.name like %s';
                $conn[] = $search;
            }

            if($_GET['reduction_method']){
                //$_GET['reduction_method'] = $_GET['reduction_method'] == 'bypayment' ? 1 : 0;
                $where .= ' and b.reduction_method = %s';
                $conn[] = $_GET['reduction_method'];
            }

            $count = DB::result_first('select count(*) from %t a left join %t b on a.id = b.goods_id  ' . $where, $conn);
            
            
            
            $conn[] = $start;
            $conn[] = $per;
            $logList = DB::fetch_all('select * from %t a left join %t b on a.id=b.goods_id '. $where .' order by a.id desc limit %d, %d', $conn);
            foreach($logList as $k => $v){
                $logList[$k]['dateline'] = dgmdate($v['dateline'], 'u');
            }
            T::responseJson(array(
                'code' => 0,
                'msg' => "",
                'count' => $count,
                'data' => $logList
            ));
        }

    
        $this->page->display();
    }


    public function list_submit(){
        global $_G;
        $gid = intval($_GET['gid']);
        $goods = DB::fetch_first('select * from %t  where goods_id=%d', array('aljayy_goods', $gid));
        if(submitcheck('formhash')){
            if($goods){
                DB::update('aljayy_goods', array(
                    'reduction_method' => $_GET['reduction_method'],
                    'type_id_list' => implode(',', $_GET['type_id_list'])
                ), array('goods_id' => $gid));
            }else{
                DB::insert('aljayy_goods', array(
                    'goods_id' => $gid,
                    'reduction_method' => $_GET['reduction_method'],
                    'type_id_list' => implode(',', $_GET['type_id_list']),
                    'dateline' => TIMESTAMP,
                ));
            }
            $this->page->tips();
        }else{

            $type_list=DB::fetch_all('select * from %t where upid=%d order by displayorder asc',array('aljayy_type',0));
            $this->page->assign('type_list', $type_list, true);
            $this->page->assign('goods', $goods);
            $this->page->assign('gid', $gid);
            $this->page->display();
        }
    }
}
