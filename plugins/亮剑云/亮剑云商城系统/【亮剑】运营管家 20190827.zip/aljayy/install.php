<?php

/**
 * �������̳�
 *
 * @author DisM!Ӧ������[dism.taobao.com]
 * @version 2019072701
 * @link https://dism.taobao.com/?
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljayy_goods` (
  `goods_id` int(11) NOT NULL,
  `reduction_method` char(50) NOT NULL,
  `dateline` int(11) NOT NULL,
  `type_id_list` text NOT NULL,
  PRIMARY KEY (`goods_id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljayy_type` (
  `id` mediumint(9) UNSIGNED NOT NULL AUTO_INCREMENT,
  `upid` mediumint(9) UNSIGNED NOT NULL,
  `subject` varchar(255) NOT NULL,
  `displayorder` mediumint(9) UNSIGNED NOT NULL,
  `pic` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `upid` (`upid`)
);
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>