<?php
/**
 * Copyright (c) 2021 by dism.taobao.com
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * Date: 2017/6/20
 * Time: ����11:11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once 'source/plugin/aljqb/class/Qbapi.class.php';
$payment = new Qbapi();
if(DB::query("update %t set status=4 where orderid = %s  and status=3",array('aljbd_goods_order',$order['orderid']))){
    
    $brand = C::t('#aljbd#aljbd') -> fetch($order['shop_id']);

    $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$brand['vipid']));
    if($vipdata['fee']>0){
        $fee = sprintf("%.2f",$order['price']*($vipdata['fee']/100));//վ����ɱ���
    }else{
        $fee = sprintf("%.2f",$order['price']*($_G['cache']['plugin']['aljbdx']['fee']/100));//վ����ɱ���
    }


    if($brand && $order['price']>0){
        //����Ǯ�� +money
        $queuearray = array(
            'app_name' => 'aljbdx',
            'app_type' => 'aljbdx_txcancel',
            'app_phone' => '123456789',
            'app_ip' => $_G['clientip'],
        );
        $balancearray = array(
            'type'=> 'charge',
            'uid'=>$brand['uid'],
            'price' => $order['price'],
            'orderid'=> $order['orderid'],
            'desc'=> str_replace(array('{username}','{title}','{money}'),array(lang('plugin/aljbd','l_danyinghao').$order['username'].lang('plugin/aljbd','r_danyinghao'),$order['stitle'],$order['price']),$_G['cache']['plugin']['aljbdx']['qb_desc_add']),
        );
        $result = $payment -> balance($queuearray,$balancearray);

        //����Ǯ��
        if($result['code'] == 200){
            if($_G['cache']['plugin']['aljbdx']){
                DB::query("update %t set status=4 WHERE status=3 and orderid=%s ",array('aljbd_goods_order_list',$order['orderid']));
            }
            if($order['give_integral']>0){
                if($_G['cache']['plugin']['aljtcc']){
                    $card_user = DB::fetch_first('select * from %t where uid=%d and end_time>%d',array('aljtcc_card_user',$order['uid'],TIMESTAMP));
                    $card_info = DB::fetch_first('select * from %t where id=%d ',array('aljtcc_card',1));
                    if($card_info['integral_multiple'] > 0){
                        $order['give_integral'] = $order['give_integral']*$card_info['integral_multiple'];
                    }
                }
                updatemembercount(
                    $order['uid'],
                    array($_G['cache']['plugin']['aljbdx']['exttype'] => intval($order['give_integral'])),
                    '',
                    '',
                    '',
                    '',
                    lang("plugin/aljbdx","receipt_php_1"),
                    lang("plugin/aljbdx","receipt_php_2") . $order['give_integral'] . $_G['setting']['extcredits'][$_G['cache']['plugin']['aljbdx']['exttype']]['title'] . lang("plugin/aljbdx","receipt_php_3") . $order['orderid']);
            }
            //s ������ѯ���� �ֵ�
            if($_G['cache']['plugin']['aljsfx']['is_aljsfx']){
                require_once 'source/plugin/aljsfx/include/receipt.php';
                if($fx_goods_prices>0){
                    sleep(1);
                    $fx_goods_price = substr(sprintf("%.3f",$fx_goods_prices),0,-1);//��Ʒ����Ӷ�����
                    //����Ǯ�� -money
                    $queuearray = array(
                        'app_name' => 'aljbdx',
                        'app_type' => 'aljbdx_txcancel',
                        'app_phone' => '123456789',
                        'app_ip' => $_G['clientip'],
                    );
                    $balancearray = array(
                        'type'=> 'take',
                        'uid'=>$brand['uid'],
                        'price' => $fx_goods_price,
                        'orderid'=> $order['orderid'],
                        'desc'=> str_replace(array('{money}'),array($fx_goods_price),lang("plugin/aljbdx","receipt_php_5")),
                    );
                    $result_take_fx = $payment -> balance($queuearray,$balancearray);
                    //����Ǯ��
                }
            }
            //e ������ѯ����
            if($fee>0){
                sleep(1);
                //����Ǯ�� -money
                $queuearray = array(
                    'app_name' => 'aljbdx',
                    'app_type' => 'aljbdx_txcancel',
                    'app_phone' => '123456789',
                    'app_ip' => $_G['clientip'],
                );
                $balancearray = array(
                    'type'=> 'take',
                    'uid'=>$brand['uid'],
                    'price' => $fee,
                    'orderid'=> $order['orderid'],
                    'desc'=> str_replace(array('{money}'),array($fee),$_G['cache']['plugin']['aljbdx']['qb_desc_fee']),
                );
                $result_take = $payment -> balance($queuearray,$balancearray);
                //����Ǯ��
                //����Ǯ�� +money ����ͳ���ʻ�
                if($_G['cache']['plugin']['aljbdx']['money_uid']>0){
                    $queuearray = array(
                        'app_name' => 'aljbdx',
                        'app_type' => 'aljbdx_add',
                        'app_phone' => '123456789',
                        'app_ip' => $_G['clientip'],
                    );
                    $balancearray = array(
                        'type'=> 'charge',
                        'uid'=>$_G['cache']['plugin']['aljbdx']['money_uid'],
                        'price' => $fee,
                        'orderid'=> $order['orderid'],
                        'desc'=> str_replace(array('{username}','{name}','{title}','{money}'),array(lang('plugin/aljbd','l_danyinghao').$brand['username'].lang('plugin/aljbd','r_danyinghao'),$brand['name'],$order['stitle'],$fee),$_G['cache']['plugin']['aljbdx']['qb_desc_uid_fee']),
                    );
                    $result_money_uid = $payment -> balance($queuearray,$balancearray);
                }

            }
            $orderlurln = '/plugin.php?id=aljbd&act=orderlist';
            //s ��ѯ�Ƿ������� ��ά���ƹ㺣��
            if($_G['cache']['plugin']['aljreg']['qb_desc']){
                $fromuid = DB::result_first('select fromuid from %t where uid=%d ', array('aljreg_invite', $order['uid']));
                $new_order_num = DB::result_first('select count(*) from %t where uid=%d and status>3 and pid=0',array('aljbd_goods_order',$_G['uid']));
                if($_G['cache']['plugin']['aljbdx']['reg_type'] == 1){
                    $order['price'] = $fee;
                }
                if($_G['cache']['plugin']['aljbdx']['new_regfee'] && $new_order_num<=1){
                    $regfee = sprintf("%.2f",$order['price']*($_G['cache']['plugin']['aljbdx']['new_regfee']/100));//�׵���ɱ���
                }else {
                    $regfee = sprintf("%.2f", $order['price'] * ($_G['cache']['plugin']['aljbdx']['regfee'] / 100));//
                }
                if($fromuid>0 && $regfee>0){
                    sleep(1);
                    //����Ǯ�� +money
                    $queuearray = array(
                        'app_name' => 'aljbdx',
                        'app_type' => 'aljbdx_txcancel',
                        'app_phone' => '123456789',
                        'app_ip' => $_G['clientip'],
                    );
                    $balancearray = array(
                        'type'=> 'charge',
                        'uid'=>$fromuid,
                        'price' => $regfee,
                        'orderid'=> $order['orderid'],
                        'desc'=> str_replace(array('{username}','{money}'),array($order['username'].lang('plugin/aljbd','r_danyinghao'),$regfee),$_G['cache']['plugin']['aljbdx']['qb_desc_regfee']),
                    );
                    $result_reg = $payment -> balance($queuearray,$balancearray);

                    //����Ǯ��
                    if($result_reg['code'] == '200'){
                        //notification_add($fromuid,'system','���ƹ���û� '.$order['username'].' �������Ʒ��ȷ���ջ���������ƹ㽱��'.$regfee.lang("plugin/aljbdx","receipt_php_4"));
                    }
                }
            }
            //e��ѯ�Ƿ������� ��ά���ƹ㺣��
            $brand = C::t('#aljbd#aljbd') -> fetch($order['shop_id']);
            //s ������Ա������Ϣ
            if($_G['cache']['plugin']['aljbdx']['receipt_tips']){
                $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
                $mes = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],$orderlurln,$brand['name']),$_G['cache']['plugin']['aljbdx']['receipt_tips']);
                foreach($groupids as $g_uid){
                    notification_add($g_uid['uid'], 'system',$mes);
                }
            }
            //s ������Ա������Ϣ
            if($_G['cache']['plugin']['aljbdx']['receipt_tips_brand']){

                $mes_brand = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],$orderlurln,$brand['name']),$_G['cache']['plugin']['aljbdx']['receipt_tips_brand']);
                notification_add($brand['uid'], 'system',$mes_brand);
            }
        }else{
            DB::query("update %t set status=3 where orderid = %s and status=4",array('aljbd_goods_order',$order['orderid']));
        }
    }
}

?>