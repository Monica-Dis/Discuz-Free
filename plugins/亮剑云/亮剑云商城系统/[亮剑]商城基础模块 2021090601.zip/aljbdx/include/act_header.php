<?php
/**
 * Copyright (c) 2021 by dism.taobao.com
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * Date: 2017/6/20
 * Time: ����11:11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$actarray = array(
    'addcart',
    'mobile_goodsview_pay',
    'cartsubmit',
    'buy',
    'buysubmit',
    'cart_pay',
    'addresslist',
    'editaddress',
);
require_once 'source/plugin/aljqb/class/Qbapi.class.php';
$qbapi = new Qbapi();
if(!$_GET['act'] || in_array($_GET['act'],$actarray)){
    if(!$_GET['act']){
        $url_cart = '&act=cart&';
    }else{
        $url_cart = '&';
    }
    unset($_GET['id']);
    if($_G['mobile'] || $_GET['act'] == 'addcart'){
        $act_header_url = 'plugin.php?id=aljbdx'.$url_cart.http_build_query($_GET);
    }else{
        $act_header_url = rtrim($qbapi->siteurl, '/').'/plugin.php?id=aljbdx'.$url_cart.http_build_query($_GET);
    }
    dheader("location:".$act_header_url);
    exit;
}
?>