<?php
/**
 * Copyright (c) 2021 by dism.taobao.com
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * Date: 2017/6/20
 * Time: ����11:11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($keyname == 'aljbdx' || $keyname == 'aljbdx_rz' || $keyname == 'aljsfx'){
    $subject = DB::result_first('select stitle from %t where orderid=%s',array('aljbd_goods_order',$orderid));
    if(!$_G['mobile']) {
        $pluginid = 'aljbd';
        require_once 'source/plugin/aljbd/include/aljbd_parameter.php';
    }
}
?>