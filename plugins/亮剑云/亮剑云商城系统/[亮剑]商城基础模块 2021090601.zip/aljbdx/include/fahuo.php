<?php
/**
 * Copyright (c) 2021 by dism.taobao.com
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * Date: 2017/6/20
 * Time: ����11:11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$orderlurln = 'plugin.php?id=aljht&act=admin&op=orderlist&do=logistics_details&kgs='.$_GET['companyname'].'&number='.$_GET['worderid'].'&orderid='.$_GET['orderid'];
$brand = C::t('#aljbd#aljbd') -> fetch($order['shop_id']);
//s ��ѯ�Ƿ�������
if($_G['cache']['plugin']['aljreg']['qb_desc'] && $_G['cache']['plugin']['aljbdx']['reg_tips']){
    $fromuid = DB::result_first('select fromuid from %t where uid=%d ', array('aljreg_invite', $order['uid']));
    $regfee = sprintf("%1.2f",$order['price']*($_G['cache']['plugin']['aljbdx']['regfee']/100));
    if($fromuid>0 && $regfee>0){
        $regmes = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],str_replace(array('{bid}','{goods_id}'),array($order['shop_id'],$shop_order[0]['goods_id']),$ggurl),$brand['name']),$_G['cache']['plugin']['aljbdx']['reg_tips']);
        notification_add($fromuid,'system',$regmes);
    }
}
//e��ѯ�Ƿ�������
//s ������Ա������Ϣ
if(file_exists(DISCUZ_ROOT ."source/plugin/aljhtx/include/delivery_admin_send_template.php")){
    require_once DISCUZ_ROOT .'source/plugin/aljhtx/include/delivery_admin_send_template.php';
}
//s ������Ա������Ϣ

?>