<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljbd_goods_settle` (
  `settleid` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `account` varchar(255) NOT NULL,
  `settleprice` varchar(255) NOT NULL,
  `payment` tinyint(3) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `applytime` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `uid` int(10) NOT NULL,
  PRIMARY KEY (`settleid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljgwc_paysetting` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY  (`key`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region` int(11) NOT NULL,
  `region1` int(11) NOT NULL,
  `region2` int(11) NOT NULL,
  `addressDetail` varchar(255) NOT NULL,
  `post` int(11) NOT NULL,
  `fullName` varchar(100) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `phoneSection` int(11) NOT NULL,
  `phoneCode` int(11) NOT NULL,
  `phoneExt` int(11) NOT NULL,
  `defaultAddress` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljgwc_statistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `total` decimal(10,2) NOT NULL,
  `withdrawals` decimal(10,2) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `addtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `pid` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `pid` (`pid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljgwc_region` (
  `id` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  `level` tinyint(3) NOT NULL,
  `havechild` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `upid` (`upid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_comment_goods` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `gid` int(10) NOT NULL,
  `orderid` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `overall_ticket` int(10) NOT NULL DEFAULT '0',
  `descriptiongrade` int(10) NOT NULL DEFAULT '0',
  `environmentgrade` int(10) NOT NULL DEFAULT '0',
  `attitudegrade` int(10) NOT NULL,
  `deliveryspeed` int(10) NOT NULL,
  `displayorder` varchar(255) NOT NULL DEFAULT '0',
  `dateline` varchar(255) NOT NULL,
  `upid` int(10) NOT NULL,
  `uusername` varchar(255) NOT NULL,
  `subcatid` varchar(255) NOT NULL,
  `uuid` int(11) NOT NULL,
  `imgs` text NOT NULL,
  `bid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `upid` (`upid`),
  KEY `gid` (`gid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljgwc_refund` (
  `orderid` char(32) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `pid` int(11) NOT NULL,
  `payment` tinyint(4) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `addtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `refund_type` int(11) NOT NULL,
  `content` text NOT NULL,
  `imgs` text NOT NULL,
  `state` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `guid` int(11) NOT NULL,
  `goodsname` varchar(255) NOT NULL,
  `buyer` char(32) NOT NULL,
  `batch_no` char(32) NOT NULL,
  `result_details` text NOT NULL,
  PRIMARY KEY (`orderid`),
  UNIQUE KEY `orderid` (`orderid`),
  KEY `guid` (`guid`),
  KEY `uid` (`uid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljgwc_payorderlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `error` text NOT NULL,
  `time` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_write_off_code` (
`password` bigint(12) NOT NULL,
  `orderid` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `shop_id` int(10) NOT NULL,
  `goods_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `endtime` int(10) NOT NULL,
  `status` int(10) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `hx_uid` int(10) NOT NULL,
  `store_id` int(10) NOT NULL,
  `hx_username` varchar(255) NOT NULL,
  PRIMARY KEY (`password`),
  KEY `orderid` (`orderid`),
  KEY `password` (`password`)
)
EOF;
runquery($sql);

$sql ="ALTER TABLE  ".DB::table('aljbd_address')." ADD  `lat` decimal(10,6) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_address')." ADD  `lng` decimal(10,6) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_address')." ADD  `sex` char(12) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_address')." ADD  `tag` char(32) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_address')." ADD  `type` tinyint(4) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_address')." ADD  `address` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

if(file_exists("source/plugin/aljms/aljms.inc.php")) {
  $sql ="ALTER TABLE ".DB::table('aljhtx_activity_ms_enter')." ADD `ms_status` tinyint(3) NOT NULL" ;
  DB::query($sql,'SILENT');
  $sql ="ALTER TABLE ".DB::table('aljhtx_activity_ms_enter')." ADD `ms_uid` int(11) NOT NULL" ;
  DB::query($sql,'SILENT');
}
$sql ="ALTER TABLE ".DB::table('aljbd_comment_goods')." ADD `video_path` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `order_type` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql = "ALTER TABLE " . DB::table('aljbd_goods_order_list') . " ADD `order_type` tinyint(3) NOT NULL";
DB::query($sql, 'SILENT');
$sql = "ALTER TABLE " . DB::table('aljbd_goods_order_list') . " ADD `ms_enter_id` int(10) NOT NULL";
DB::query($sql, 'SILENT');
$sql = "ALTER TABLE " . DB::table('aljbd_goods_order_list') . " ADD `status` tinyint(4) NOT NULL";
DB::query($sql, 'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods_order_list')." ADD  `store_id` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql = "ALTER TABLE " . DB::table('aljbd_goods_order_list') . " ADD `confirmdate` int(11) NOT NULL";
    DB::query($sql, 'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_write_off_code')." ADD  `hx_uid` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_write_off_code')." ADD  `store_id` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_write_off_code')." ADD  `hx_username` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `coupon_validity` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods_order')." ADD  `store_id` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods_order')." ADD  `store_address` text NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE  ".DB::table('aljbd_goods_order')." ADD  `give_integral` INT NOT NULL ,
ADD  `pay_integral` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods_order')." ADD  `give_integral` INT NOT NULL ,
ADD  `pay_integral` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE  ".DB::table('aljbd_address')." ADD  `province` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_address')." ADD  `city` VARCHAR( 255 ) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_address')." ADD  `district` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `cid`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `opentime` int(11) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `collage_num` int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `collage_num` int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `collage_order` char(32) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `collage_order` char(32) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `get_to_the_shop` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `get_to_the_shop` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `commodity_type` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `commodity_type` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `discount`  decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `ext`  int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `pay_ext`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `pay_ext`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `deliverydate`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `proportion`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljgwc')." ADD `path`  varchar(100) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `path`  varchar(100) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." CHANGE `status` `status` TINYINT( 3 ) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_video')." ADD `rubbish`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `original_price` decimal(8,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljgwc')." ADD `fare_desc`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `fare_desc`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `fare_desc`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljgwc')." ADD `ext` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljtg_goods')." ADD `fare` decimal(8,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `category` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `category` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljgwc')." ADD `pid` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_settle')." ADD `pid` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `pid` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `pid` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `fare` decimal(8,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `fare` decimal(8,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `address` text NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `browser` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `mobile`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `other` text NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljgwc')." ADD `browser` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljgwc')." ADD `mobile`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `price` DECIMAL( 10, 2 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `orderid` char( 32 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljgwc')." ADD  `store_id` INT NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljgwc')." ADD  `type` tinyint(4) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljgwc')." ADD  `upid` INT NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljgwc_refund')." ADD `store_id`  int(11) NOT NULL" ;
DB::query($sql,'SILENT');
if(file_exists("source/plugin/aljbdx/aljbdx.inc.php")){
  $sql = "ALTER TABLE " . DB::table('aljgwc_refund') . " ADD `type` tinyint(4) NOT NULL";
  DB::query($sql, 'SILENT');
}
$sql ="ALTER TABLE ".DB::table('aljgwc_refund')." ADD `bd_info` TEXT NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods_order_list')." ADD  `goodsinfo` TEXT NOT NULL" ;
DB::query($sql,'SILENT');
DB::query('update %t set name=%s where identifier=%s',array('common_plugin',$installlang[upgrade_php_1],'aljbdx'));
if(file_exists("source/plugin/aljatt/aljatt.inc.php")) {
  $sql ="ALTER TABLE  ".DB::table('aljhtx_cron_script')." CHANGE `name` `name` VARCHAR(255) NOT NULL" ;
  DB::query($sql,'SILENT');
  if(!DB::fetch_first('select * from %t where file=%s',array('aljhtx_cron_script','source/plugin/aljhtx/api/auto.php'))){
    DB::insert('aljhtx_cron_script',array('name'=>'&#25340;&#22242;&#33258;&#21160;&#36864;&#27454;&#21450;&#35746;&#21333;&#33258;&#21160;&#25910;&#36135;','file'=>'source/plugin/aljhtx/api/auto.php','cycle'=>'5','open'=>'on'));
  }
}
$order_fee = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'fee\'', array('aljbd_goods_order'), true);
if(!$order_fee){
$sql = <<<EOF
ALTER TABLE `pre_aljbd_goods_order` ADD `fee` decimal(10,2) NOT NULL;
ALTER TABLE `pre_aljbd_goods_order` ADD INDEX(`fee`);
ALTER TABLE `pre_aljbd_goods_order` ADD INDEX(`confirmdate`);
ALTER TABLE `pre_aljbd_goods_order` ADD INDEX(`status`);
ALTER TABLE `pre_aljbd_goods_order` ADD INDEX(`price`);
EOF;
runquery($sql);
}
$finish = TRUE;
?>