<?php
loadcache('plugin');
$aljpluginid = 'aljbdx';
include template($aljpluginid.':aljqb');
?>