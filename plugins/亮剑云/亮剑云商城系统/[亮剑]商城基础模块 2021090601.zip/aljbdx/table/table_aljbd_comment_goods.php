<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljbd_comment_goods extends discuz_table{
	public function __construct() {

			$this->_table = 'aljbd_comment_goods';
			$this->_pk    = 'id';

			parent::__construct(); /*dism �� taobao �� com*/
	}
	public function fetch_by_bid($bid=0){
		return DB::fetch_first('select * from %t where bid=%d and upid=0 and uid!=0',array($this->_table,$bid));
	}
	public function count_by_bid_upid($bid=0,$upid=0,$ask=0){
		return DB::result_first('select count(*) from %t where bid=%d and upid=%d and ask=%d and uid!=0 and rubbish=0',array($this->_table,$bid,$upid,$ask));
	}
	public function fetch_all_by_bid_upid($bid=0,$upid=0,$ask=0){
		return DB::fetch_all('select * from %t where bid=%d and upid=%d and ask=%d and uid!=0 and rubbish=0 order by id desc',array($this->_table,$bid,$upid,$ask));
	}
	public function fetch_all_by_upid($upid=0,$nid=0,$overall_ticket=0,$start=0,$perpage=0){
		$where = 'where rubbish=0 ';
		$con[] = $this->_table;
        if($overall_ticket){
			$con[] = $overall_ticket;
            $where .= ' and overall_ticket = %d';
		}
		$con[] = $upid;
		$where .= ' and upid = %d';
		if($nid){
			$con[] = $nid;
            $where .= ' and gid = %d';
		}
	    $where .= ' order by id desc';
        if($perpage){
			$con[] = $start;
			$con[] = $perpage;
	        $where .= ' limit %d,%d';
        }
		return DB::fetch_all('select * from %t '.$where,$con);
	}
    public function count_by_upid($upid=0,$nid=0,$overall_ticket=0){
		$where = 'where rubbish=0 ';
		$con[] = $this->_table;
        if($overall_ticket){
			$con[] = $overall_ticket;
            $where .= ' and overall_ticket = %d';
		}
		$con[] = $upid;
		$where .= ' and upid = %d';
		if($nid){
			$con[] = $nid;
            $where .= ' and gid = %d';
		}
        return DB::result_first('select count(*) from %t '.$where,$con);
    }
	public function count_by_bid($bid=0){
		return DB::fetch_all('select avg(k) k,avg(h) h,avg(f) f from %t where bid=%d and ask=0 and rubbish=0',array($this->_table,$bid));
	}
	public function count_avg_by_bid($bid=0){
		return DB::result_first('select (avg(h)+avg(f))/2 from %t where bid=%d and ask=0 and uid!=0 and rubbish=0',array($this->_table,$bid));
	}
	public function count_by_bid_all($bid=0){
		if($bid>0){
			$where = ' and gid='.intval($bid);
		}
		return DB::result_first('select count(*) from %t where rubbish=0 and upid=0'.$where,array($this->_table));
	}
	public function fetch_all_by_bid_page($bid=0,$start=0,$perpage=0){
		return DB::fetch_all('select * from %t where gid=%d and rubbish=0 order by id desc limit %d,%d ',array($this->_table,$bid,$start,$perpage));
	}
	
}




?>