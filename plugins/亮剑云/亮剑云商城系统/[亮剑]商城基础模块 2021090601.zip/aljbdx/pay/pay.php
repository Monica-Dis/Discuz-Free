<?php
	define('DISABLEXSSCHECK',true);
	require '../../../../source/class/class_core.php';
	$discuz = C::app();
	$discuz->init();
  	loadcache('plugin');
	require_once '../../../../source/plugin/aljqb/class/Qbapi.class.php';
	if(file_exists('../../../../source/plugin/aljqb/class/Getdata.class.php')){
		require_once '../../../../source/plugin/aljqb/class/Getdata.class.php';
		$getdata = new Getdata();
	}
	//file_put_contents('d.txt',$key."\r",FILE_APPEND);
	//file_put_contents('d.txt',$_GET['key']."\r",FILE_APPEND);
	$_G['siteurl'] = str_replace('source/plugin/aljbdx/pay/', '',$_G['siteurl'] );
	$pluginid = 'aljbd';
	$orderlurl = $_G['siteurl'].'/plugin.php?id='.$pluginid.'&act=orderlist';
	$orderlurln = '/plugin.php?id='.$pluginid.'&act=orderlist';
	$data['transaction_id'] = $_GET['aljorderid'];
    require '../../../../source/plugin/aljbdx/function/function_core.php';
	$qbapi = new Qbapi();
	$keyarray = array(
		'aljorderid'=> $_GET['aljorderid'],
		'paytime' => $_GET['paytime'],
		'orderid' => $_GET['orderid'],
	);
	if($_GET['key']) {
		$keyarray['key'] = $_G['cache']['plugin']['aljbdx']['qb_key'];
		$key = $qbapi->createKey($keyarray);
		$getkey = $_GET['key'];
	}elseif(file_exists('../../../../source/plugin/aljqb/class/Getdata.class.php')) {
		$appinfo = $getdata->getAppParam();
		$appinfo['posttime']=$_GET['posttime'];
		$key = $getdata->CreateAppSign($appinfo);
		$getkey = $_GET['sign'];
	}
	if($getkey && $getkey && $key == $getkey) {
        $data['out_trade_no'] = $_GET['orderid'];
        $order = C::t('#aljgwc#aljbd_goods_order') -> fetch($data['out_trade_no']);
		$others = unserialize($order['other']);
		if($order['status'] == 1){
			$status = orderStatus($order);
            $brand = C::t('#'.$pluginid.'#'.$pluginid) -> fetch($order['shop_id']);
			$qborder = DB::fetch_first('select * from %t where aljorderid=%s',array('aljqb_payorder',$_GET['aljorderid']));
			$updatearray = array('admin'=>$qborder['trade_mod'],'status' => $status, 'buyer' => $data['transaction_id'], 'confirmdate' => $_GET['paytime']);
			$address = unserialize($order['address']);
			if(($order['commodity_type'] == 0 || $order['commodity_type'] == 7 || $order['commodity_type'] == 8) && $order['get_to_the_shop'] != 1 && $address['lat'] !=0 && $address['lng'] != 0 && (($brand['platform_distribution'] == 1  && $_G['cache']['plugin']['aljpps']['is_aljbd']) || $_G['cache']['plugin']['aljsqtg']['platform_distribution'] == 1) && $_G['cache']['plugin']['aljpps']['aljbd_auto_order']){
				require DISCUZ_ROOT .'/source/plugin/aljpps/include/pay.php';
			}
			
			if($order['order_type'] == 7){
				
				$timeoffset = getglobal('setting/timeoffset');
				$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$timeoffset),dgmdate($_G['timestamp'], 'j',$timeoffset),dgmdate($_G['timestamp'], 'Y',$timeoffset)) - $timeoffset*3600;
				$todaypaynum = DB::result_first('select count(*) from %t where order_type=7 and status>1 and status < 7 and confirmdate>=%d',array('aljbd_goods_order',$nowDayTime));
				$others['todaypaynum'] = $todaypaynum+1;
				
				$mycount = DB::result_first('select count(*) from %t where order_type=7 and status>1 and status < 7 and uid=%d',array('aljbd_goods_order',$order['uid']));
				if(!$mycount){
					$updatearray['d'] = 1;//�Ƿ��׵�
				}
			}
			if($order['commodity_type'] == 6){
				DB::update('aljsdj_order',array('status'=>2,'updatetime'=>$_GET['paytime'],'trade_mod'=>$qborder['trade_mod'],'buyer'=>$data['transaction_id']), array('dj_orderid'=>$_GET['orderid'].'2'));
				$others['wk_array'] = DB::fetch_first('select * from %t where dj_orderid=%s',array('aljsdj_order',$_GET['orderid']));
			}
			
			
			$updatearray['other'] = serialize($others);
			
            C::t('#aljgwc#aljbd_goods_order')->update($data['out_trade_no'], $updatearray);
			DB::update('aljbd_goods_order_list',array('status'=>$status), array('orderid'=>$data['out_trade_no']));
			bdx_notice($data['out_trade_no']);//����֪ͨ
		}
        echo 'success';
        exit;
	}
?>
