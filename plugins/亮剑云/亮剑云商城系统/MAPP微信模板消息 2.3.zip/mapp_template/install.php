<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljhtx_wechat_template` (
  `template_id` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `primary_industry` varchar(255) NOT NULL,
  `deputy_industry` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `example` text NOT NULL,
  `times` int(11) NOT NULL,
  `last_time` int(11) NOT NULL,
  `succeed_times` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `last_content` text NOT NULL
);
CREATE TABLE IF NOT EXISTS `pre_aljhtx_wechat_bindtemplate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `template_id` varchar(255) NOT NULL,
  `param` text NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljwsq_mapp_template_keyword` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `upid` int(10) NOT NULL,
  `mykeyword` varchar(255) NOT NULL,
  `bindkeyword` varchar(255) NOT NULL,
  `type` char(50) NOT NULL,
  `msgtype` char(50) NOT NULL,
  `returnmsgtype` char(50) NOT NULL,
  `event` char(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `fid` int(10) NOT NULL,
  `tid` int(10) NOT NULL,
  `forumnum` int(10) NOT NULL,
  `threadnum` int(10) NOT NULL,
  `picurl` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `addline` int(10) NOT NULL,
  `updatetime` int(10) NOT NULL,
  `resnum` int(10) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `displayorder` int(10) NOT NULL,
  `description` varchar(255) NOT NULL,
  `massmessage` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljwsq_mapp_template_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `touser` varchar(255) NOT NULL,
  `template_id` varchar(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `dateline` int(11) NOT NULL,
  `template` text NOT NULL,
  `param` text NOT NULL,
  `a` varchar(255) NOT NULL,
  `b` varchar(255) NOT NULL,
  `c` varchar(255) NOT NULL,
  `d` int(10) NOT NULL,
  `e` int(10) NOT NULL,
  PRIMARY KEY (`id`)
);
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>