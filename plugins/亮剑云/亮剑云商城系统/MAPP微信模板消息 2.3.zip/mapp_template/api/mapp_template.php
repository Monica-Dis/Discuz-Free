<?php

/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ��ϵQQ: DISM.TAOBAO.COM
 * ����˵��:MAPP΢�ź��Ӻ���API
 */


function mapp_template($postObj){
	global $_G;
	$_G['defaultpic'] = $_G[siteurl].'source/plugin/mapp_base/images/default.jpg';
	$content = trim($postObj['content']);
	$news = DB::fetch_first('select * from %t where mykeyword = %s and status>0 order by displayorder desc',array('aljwsq_mapp_template_keyword',$content));
	if($news['type'] == 'template'){
		$aljwsq_config = array();
		$plugin_aljwsq = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljwsq'));
		$tmp_aljwsq_config = DB::fetch_all('select * from %t where  pluginid = %s',array('common_pluginvar',$plugin_aljwsq['pluginid']));
		foreach($tmp_aljwsq_config as $value){
			$aljwsq_config[$value['variable']] = $value['value'];
		}
		require_once DISCUZ_ROOT . './source/plugin/aljwsq/mapp_wechatclient.lib.class.php';
		$wechat_client = new WeChatClient($aljwsq_config['appid'], $aljwsq_config['appsecret']);
		$param_list = explode ("\n", str_replace ("\r", "", $news['description']));
		foreach($param_list as $key=>$value){
			$new_arr=explode('|',$value);
			if($value){
				$color = $new_arr[2]?$new_arr[2]:'#173177';
				$params[$new_arr[0]]=array('value' => diconv($new_arr[1],CHARSET,'UTF-8'),'color' => $color);
			}
			
		}
		//return  mappapi::getXml4Txt(json_encode($params));
		$data = array(
			'touser' => $postObj['from'],
			//'touser' => 'omiTXt9-aemRYp7NDHThsDBdHZsQ',
			'template_id' => $news['url'],
			'url'  => $news['title'],
			'topcolor'  => '#ff0000',
			'data'  => $params,
		);
		//debug($data);
		$wechat_client -> sendtemplate($data);
		//return  mappapi::getXml4Txt($wechat_client -> sendtemplate($data));
		return  mappapi::getXml4Txt($news['bindkeyword']);
	}else{
		return false;
	}
}
//From: d'.'is'.'m.ta'.'obao.com
?>