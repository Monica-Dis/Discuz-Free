<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
//start to put your own code
$sql ="ALTER TABLE ".DB::table('aljwsq_mapp_template_log')." ADD `template` text NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljwsq_mapp_template_log')." ADD `param` text NOT NULL" ;
DB::query($sql,'SILENT');
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljhtx_wechat_template` (
  `template_id` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `primary_industry` varchar(255) NOT NULL,
  `deputy_industry` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `example` text NOT NULL,
  `times` int(11) NOT NULL,
  `last_time` int(11) NOT NULL,
  `succeed_times` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `last_content` text NOT NULL
);
CREATE TABLE IF NOT EXISTS `pre_aljhtx_wechat_bindtemplate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `template_id` varchar(255) NOT NULL,
  `param` text NOT NULL,
  PRIMARY KEY (`id`)
);
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>