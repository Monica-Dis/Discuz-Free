<?php

/**
 * MAPP΢��ģ����Ϣ
 *
 * Copyright (c) 2021 by dism.taobao.com
 * @version 2.3
 * @link https://dism.taobao.com?/ 
 * 
 */


if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_mapp_template {

    function common() {
        global $_G;
        $mapp_wechat = unserialize($_G['setting']['mapp_wechat']);
        $wxurl = $mapp_wechat['wxurl'] ? $mapp_wechat['wxurl'] : $_G['siteurl'];
        $wxurl = trim($wxurl, '/').'/';
        if($_G['cache']['plugin']['aljhtx']['auto']){
                //2.3�汾��ʼ����ʱ����ģʽתΪcronģ����д���
        }else{
            if(!$_G['cache']['plugin']['aljhtx']['server']) {
                $mapp_template_config = $_G['cache']['plugin']['mapp_template'];
                $dateline = DB::result_first('select dateline from %t order by dateline desc',array('aljwsq_mapp_template_log'));
                if($mapp_template_config['enabled'] and $dateline+$mapp_template_config['time'] < TIMESTAMP){
                    $aljwsq_config = array();
                    $plugin_aljwsq = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljwsq'));
                    $tmp_aljwsq_config = DB::fetch_all('select * from %t where  pluginid = %s',array('common_pluginvar',$plugin_aljwsq['pluginid']));
                    foreach($tmp_aljwsq_config as $value){
                        $aljwsq_config[$value['variable']] = $value['value'];
                    }
                    require_once DISCUZ_ROOT . './source/plugin/aljwsq/mapp_wechatclient.lib.class.php';
                    $wechat_client = new WeChatClient($aljwsq_config['appid'], $aljwsq_config['appsecret']);

                    /*��Ϣ����*/
                    $pm = DB::fetch_first('select a.*, b.openid from %t a left join %t b on a.uid=b.uid where a.new = 1 and a.uid!=0 and b.uid!=0 limit 0,1',array('home_notification',$mapp_template_config['usertable']));
                    if($pm){
                        DB::query('update %t set  new = 0 where id=%d',array('home_notification',$pm['id']));
                        $postuser = DB::fetch_first('select * from %t where uid = %s',array($mapp_template_config['usertable'],$pm['uid']));
                        $openid = $postuser['openid'];
                        if(empty($postuser['openid'])){
                            return;
                        }
                        if($pm['type'] == 'system'){
                            $keyword = DB::fetch_first('select * from %t where status = %d and type = %s',array('aljwsq_mapp_template_keyword',1,'system'));
                            $param_list = explode ("\n", str_replace ("\r", "", $keyword['description']));
                            $template_id = $keyword['url'];
                            if(preg_match_all("/<a(.+?)href=(['\"]?)([^>\s]+)\\2([^>]*)>/i", $pm['note'], $marray)){
                                $link = array_pop($marray[3]);
                                if($link == 'about:blank'){
                                    $link = array_pop($marray[3]);
                                }
                                $tmpurl = ($link ? $link : '/home.php?mod=space&do=notice&view=system');
                                if(!in_array(strtolower(substr($tmpurl, 0, 6)), array('http:/', 'https:', 'ftp://'))){
                                    $url = $wxurl.$tmpurl;
                                }
                            }else{
                                $typelist = array('aljpc','aljes','aljzp','aljesc','aljcw','aljlp','aljesf','aljesc','aljzc');
                                if(in_array($pm['from_idtype'],$typelist)){
                                    $url = $wxurl.'plugin.php?id='.$pm['from_idtype'].'&act=view&mobile=2&lid='.$pm['from_id'];
                                }else if($pm['from_idtype'] == 'aljol'){
                                    $url = $wxurl.'plugin.php?id=aljol&act=talk&friendid='.$pm['from_id'];
                                }else if($pm['from_idtype'] == 'aljbd'){
                                    if($pm['from_id']){
                                        $url = $wxurl.'plugin.php?id=aljbd&act=orderlist';
                                    }else{
                                        $url = $wxurl.'plugin.php?id=aljbd';
                                    }
                                }else if($pm['type'] == 'friend'){
                                    $url = $wxurl.'plugin.php?id=aljol&act=requestfriendlist';
                                }else if($pm['from_idtype'] == 'aljhbx'){
                                    if($pm['from_id']){
                                        $url = $wxurl.'plugin.php?id=aljhbx&action=view&pid='.$pm['from_id'];
                                    }else{
                                        $url = $wxurl.'plugin.php?id=aljhbx&action=list';
                                    }
                                }else{
                                    $url = $wxurl;
                                }
                            }
                            $type = diconv(strip_tags($keyword['title']),CHARSET,'UTF-8');
                            $user = getuserbyuid($pm['uid']);
                            $fromuser = getuserbyuid($pm['authorid']);
                            if($user){
                                $username = diconv($user['username'],CHARSET,'UTF-8');
                            }
                            if($fromuser){
                                $fromusername = diconv($fromuser['username'],CHARSET,'UTF-8');
                            }


                            foreach($param_list as $key=>$value){
                                if($value){
                                    $value = diconv(strip_tags($value),CHARSET,'UTF-8');
                                    $new_arr=explode('|',$value);
                                    $new_arr[1] = str_replace('{type}',$type,$new_arr[1]);
                                    $new_arr[1] = str_replace('{username}',$username,$new_arr[1]);
                                    $new_arr[1] = str_replace('{fromusername}',$fromusername,$new_arr[1]);
                                    $new_arr[1] = str_replace('{content}',diconv(unescape(strip_tags($pm['note'])),CHARSET,'UTF-8'),$new_arr[1]);
                                    $new_arr[1] = str_replace('{time}',dgmdate($pm['dateline']),$new_arr[1]);
                                    $params[$new_arr[0]] = array('value' => $new_arr[1],'color' => $new_arr[2]);
                                }
                            }
                        }else if($pm['type'] == 'post'){
                            $keyword = DB::fetch_first('select * from %t where status = %d and type = %s',array('aljwsq_mapp_template_keyword',1,'post'));
                            $param_list = explode ("\n", str_replace ("\r", "", $keyword['description']));
                            $thread = C::t('forum_thread')->fetch($pm['from_id']);
                            $template_id = $keyword['url'];
                            if($pm['from_idtype'] == 'quote'){
                                $pm['from_id'] = DB::result_first('select tid from %t where pid=%d',array('forum_post',$pm['from_id']));
                            }
                            if(preg_match_all("/<a(.+?)href=(['\"]?)([^>\s]+)\\2([^>]*)>/i", $pm['note'], $marray)){
                                $link = array_pop($marray[3]);
                                if($link == 'about:blank'){
                                    $link = array_pop($marray[3]);
                                }
                                $tmpurl = ($link ? $link : '/home.php?mod=space&do=notice&view=mypost');
                                if(!in_array(strtolower(substr($tmpurl, 0, 6)), array('http:/', 'https:', 'ftp://'))){
                                    $url = $wxurl.$tmpurl;
                                }
                            }else{
                                $url = $wxurl.'forum.php?mod=viewthread&mobile=2&tid='.$pm['from_id'];
                            }
                            $type = diconv(strip_tags($keyword['title']),CHARSET,'UTF-8');
                            $user = getuserbyuid($pm['uid']);
                            $fromuser = getuserbyuid($pm['authorid']);
                            if($user){
                                $username = diconv($user['username'],CHARSET,'UTF-8');
                            }
                            if($fromuser){
                                $fromusername = diconv($fromuser['username'],CHARSET,'UTF-8');
                            }
                            $note = diconv(strip_tags($pm['note']),CHARSET,'UTF-8');
                            $note = str_replace(array('&nbsp;',diconv(strip_tags(unescape('&#26597;&#30475;')),CHARSET,'UTF-8')),'',$note);
                            foreach($param_list as $key=>$value){
                                if($value){
                                    $value = diconv(strip_tags($value),CHARSET,'UTF-8');
                                    $new_arr=explode('|',$value);
                                    $new_arr[1] = str_replace('{thread}',diconv(strip_tags($thread['subject']),CHARSET,'UTF-8'),$new_arr[1]);
                                    $new_arr[1] = str_replace('{type}',$type,$new_arr[1]);
                                    $new_arr[1] = str_replace('{username}',$username,$new_arr[1]);
                                    $new_arr[1] = str_replace('{fromusername}',$fromusername,$new_arr[1]);
                                    $new_arr[1] = str_replace('{content}',$note,$new_arr[1]);
                                    $new_arr[1] = str_replace('{time}',dgmdate($pm['dateline']),$new_arr[1]);
                                    $params[$new_arr[0]] = array('value' => $new_arr[1],'color' => $new_arr[2]);
                                }
                            }
                        }else{
                            DB::query('update %t set  new = 0 where id=%d',array('home_notification',$pm['id']));
                        }
                        //debug($params);
                        $data = array(
                            //'touser' => $postObj['from'],
                            'touser' => $openid,
                            'template_id' => $template_id,
                            'url'  => $url,
                            'topcolor'  => '#ff0000',
                            'data'  => $params,
                        );
                        //debug($data);
                        $result = $wechat_client -> sendtemplate($data);

                        if(file_exists('source/plugin/aljhtx/class/class_aljhtx.php')){
                            require_once 'source/plugin/aljhtx/class/class_aljhtx.php';
                            $template = DB::fetch_first('select * from %t where template_id = %s', array('aljhtx_wechat_template', $template_id));
                            $new = str_replace("{{first.DATA}}", lang("plugin/mapp_template", "first").'{{first.DATA}}', $template['content']);
                            $new = str_replace("{{remark.DATA}}", lang("plugin/mapp_template", "remark").'{{remark.DATA}}', $new);
                            $new = explode("\n", $new);
                            foreach($new as $key => $value){
                                $value = trim($value);
                                if($value){
                                    $value = str_replace('{{', '', $value);
                                    $value = str_replace('.DATA}}', '', $value);
                                    $newContent[$key] = explode('��', $value);
                                }
                            }

                            $param = T::ajaxGetCharSet($params);
                            foreach($newContent as $k => $v){
                                if($v[1] == 'first' || $v[1] == 'remark'){
                                    $newContent[$k][0] = '';
                                }
                                $newContent[$k][1] = $param[$v[1]];
                            }
                        }

                        $insertdata = array(
                            'touser' => $openid,
                            'template_id' => $template_id,
                            'url'  => $url,
                            'dateline'  => TIMESTAMP,
                            'status'  => $result ? 1 : 0,
                            'template'  => serialize(T::ajaxGetCharSet($data)),
                            'param'  => serialize($newContent),
                            'a'  => diconv($wechat_client->error(), 'UTF-8'),
                        );
                        C::t('#mapp_template#aljwsq_mapp_template_log')->insert($insertdata);

                        /*��Ϣ����*/
                    }
                }
            }
        }
    }

}
function unescape($str) {
    $str = rawurldecode($str);
    preg_match_all("/(?:%u.{4})|&#x.{4};|&#\d+;|.+/U",$str,$r);
    $ar = $r[0];
    foreach($ar as $k=>$v) {
        if(substr($v,0,2) == "%u"){
            if(strtolower(CHARSET) == 'gbk'){
                $ar[$k] = iconv("UCS-2BE","gbk",pack("H4",substr($v,-4)));
            }else {
                $ar[$k] = iconv("UCS-2BE","UTF-8",pack("H4",substr($v,-4)));
            }

        }
        elseif(substr($v,0,3) == "&#x"){
            if(strtolower(CHARSET) == 'gbk'){
                $ar[$k] = iconv("UCS-2BE","gbk",pack("H4",substr($v,3,-1)));
            }else{
                $ar[$k] = iconv("UCS-2BE","UTF-8",pack("H4",substr($v,3,-1)));
            }
        }
        elseif(substr($v,0,2) == "&#") {
            if(strtolower(CHARSET) == 'gbk'){
                $ar[$k] = iconv("UCS-2BE","gbk",pack("n",substr($v,2,-1)));
            }else{
                $ar[$k] = iconv("UCS-2BE","UTF-8",pack("n",substr($v,2,-1)));
            }
        }
    }
    return join("",$ar);
}
