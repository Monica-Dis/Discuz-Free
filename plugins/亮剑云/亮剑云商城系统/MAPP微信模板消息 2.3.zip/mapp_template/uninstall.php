<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//start to put your own code 
$sql = <<<EOF
DROP TABLE IF  EXISTS `pre_aljhtx_wechat_template`;
DROP TABLE IF  EXISTS `pre_aljwsq_mapp_template_keyword`;
DROP TABLE IF  EXISTS `pre_aljwsq_mapp_template_log`;
EOF;

runquery($sql);
//finish to put your own code
$finish = TRUE;
?>