<?php

/**
 * MAPP΢��ģ����Ϣ
 *
 * Copyright (c) 2021 by dism.taobao.com
 * @version 2.3
 * @link https://www.liangjianyun.com/
 */


if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

mapp_template_cron();
function mapp_template_cron(){
    global $_G;
    $mapp_wechat = unserialize($_G['setting']['mapp_wechat']);
    $wxurl = $mapp_wechat['wxurl'] ? $mapp_wechat['wxurl'] : $_G['siteurl'];
    $wxurl = trim($wxurl, '/').'/';
    $mapp_template_config = $_G['cache']['plugin']['mapp_template'];
    $dateline = DB::result_first('select dateline from %t order by dateline desc',array('aljwsq_mapp_template_log'));
    if($mapp_template_config['enabled'] and $dateline+$mapp_template_config['time'] < TIMESTAMP) {
        /*��Ϣ����*/
        $pm = DB::fetch_first('select a.*, b.openid from %t a left join %t b on a.uid=b.uid where a.new = 1 and a.uid!=0 and b.uid!=0 limit 0,1',array('home_notification',$mapp_template_config['usertable']));

        if($pm){
            DB::query('update %t set  new = 0 where id=%d',array('home_notification',$pm['id']));
            if(empty($pm['openid'])){
                return;
            }
            require_once 'source/plugin/aljhtx/class/class_aljhtx.php';
            if($pm['type'] == 'system'){
                $postuser = getuserbyuid($pm['uid']);
                if(preg_match_all("/<a(.+?)href=(['\"]?)([^>\s]+)\\2([^>]*)>/i", $pm['note'], $marray)){
                    $link = array_pop($marray[3]);
                    if($link == 'about:blank'){
                        $link = array_pop($marray[3]);
                    }
                    $tmpurl = ($link ? $link : '/home.php?mod=space&do=notice&view=system');
                    if(!in_array(strtolower(substr($tmpurl, 0, 6)), array('http:/', 'https:', 'ftp://'))){
                        $url = $wxurl.$tmpurl;
                    }
                }else{
                    $typelist = array('aljpc','aljes','aljzp','aljesc','aljcw','aljlp','aljesf','aljesc','aljzc');
                    if(in_array($pm['from_idtype'],$typelist)){
                        $url = $wxurl.'plugin.php?id='.$pm['from_idtype'].'&act=view&mobile=2&lid='.$pm['from_id'];
                    }else if($pm['from_idtype'] == 'aljol'){
                        $url = $wxurl.'plugin.php?id=aljol&act=talk&friendid='.$pm['from_id'];
                    }else if($pm['from_idtype'] == 'aljbd'){
                        if($pm['from_id']){
                            $url = $wxurl.'plugin.php?id=aljbd&act=orderlist';
                        }else{
                            $url = $wxurl.'plugin.php?id=aljbd';
                        }
                    }else if($pm['type'] == 'friend'){
                        $url = $wxurl.'plugin.php?id=aljol&act=requestfriendlist';
                    }else if($pm['from_idtype'] == 'aljhbx'){
                        if($pm['from_id']){
                            $url = $wxurl.'plugin.php?id=aljhbx&action=view&pid='.$pm['from_id'];
                        }else{
                            $url = $wxurl.'plugin.php?id=aljhbx&action=list';
                        }
                    }else{
                        $url = $wxurl;
                    }
                }

                if(file_exists('source/plugin/aljhtx/config/bind_template.php')){
                    $bindTemplateConfig = include('source/plugin/aljhtx/config/bind_template.php');
                }
                if ($bindTemplateConfig && array_key_exists($pm['from_idtype'], $bindTemplateConfig)) {
                    $cron = T::getObject('cron', array(
                        'param' => serialize(
                            array(
                                'dateline' => dgmdate($pm['dateline'], 'Y-m-d H:i:s'),
                                'author' => $pm['author'],
                                'id' => $pm['from_id'],
                                'username' => $postuser['username'],
                                'type' => $pm['from_idtype'],
                                'content' => mapp_template_unescape(strip_tags($pm['note']))
                            )
                        ),
                        'type' => 'bindtemplate',
                        'uid' => $pm['authorid'],
                        'touid' => $pm['uid'],
                        'content' => $url,
                    ));
                }else{
                    $cron = T::getObject('cron', array(
                        'param' => serialize(
                            array(
                                'dateline' => dgmdate($pm['dateline'], 'Y-m-d H:i:s'),
                                'author' => $pm['author'],
                                'username' => $postuser['username'],
                                'type' => 'system',
                                'content' => mapp_template_unescape(strip_tags($pm['note']))
                            )
                        ),
                        'type' => 'bindtemplate',
                        'uid' => $pm['authorid'],
                        'touid' => $pm['uid'],
                        'content' => $url,
                    ));
                }

                $cron->push();
            }else if($pm['type'] == 'post'){
                $post = DB::fetch_first('select * from %t where pid=%d',array('forum_post',$pm['from_id']));
                $thread = C::t('forum_thread')->fetch($post['tid']);
                if(preg_match_all("/<a(.+?)href=(['\"]?)([^>\s]+)\\2([^>]*)>/i", $pm['note'], $marray)){
                    $link = array_pop($marray[3]);
                    if($link == 'about:blank'){
                        $link = array_pop($marray[3]);
                    }
                    $tmpurl = ($link ? $link : '/home.php?mod=space&do=notice&view=mypost');
                    if(!in_array(strtolower(substr($tmpurl, 0, 6)), array('http:/', 'https:', 'ftp://'))){
                        $url = $wxurl.$tmpurl;
                    }
                }else{
                    $url = $wxurl.'forum.php?mod=viewthread&mobile=2&tid='.$post['tid'];
                }
                $user = getuserbyuid($pm['uid']);
                $fromuser = getuserbyuid($pm['authorid']);
                if($user){
                    $username = $user['username'];
                }
                if($fromuser){
                    $fromusername = $fromuser['username'];
                }
                $note = strip_tags($pm['note']);
                $note = str_replace(array('&nbsp;',strip_tags(mapp_template_unescape('&#26597;&#30475;'))),'',$note);
                $cron = T::getObject('cron', array(
                    'param' => serialize(
                        array(
                            'title' => $thread['subject'],
                            'type' => 'reply',
                            'username' => $username,
                            'fromusername' => $fromusername,
                            'content' => $note,
                            'posttime' => dgmdate($thread['dateline'], 'Y-m-d H:i:s'),
                            'replytime' => dgmdate($pm['dateline'], 'Y-m-d H:i:s')
                        )
                    ),
                    'type' => 'bindtemplate',
                    'uid' => $pm['authorid'],
                    'touid' => $pm['uid'],
                    'content' => $url,
                ));

                $cron->push();
            }
        }

    }
}

function mapp_template_unescape($str) {
    $str = rawurldecode($str);
    preg_match_all("/(?:%u.{4})|&#x.{4};|&#\d+;|.+/U",$str,$r);
    $ar = $r[0];
    foreach($ar as $k=>$v) {
        if(substr($v,0,2) == "%u"){
            if(strtolower(CHARSET) == 'gbk'){
                $ar[$k] = iconv("UCS-2BE","gbk",pack("H4",substr($v,-4)));
            }else {
                $ar[$k] = iconv("UCS-2BE","UTF-8",pack("H4",substr($v,-4)));
            }

        }
        elseif(substr($v,0,3) == "&#x"){
            if(strtolower(CHARSET) == 'gbk'){
                $ar[$k] = iconv("UCS-2BE","gbk",pack("H4",substr($v,3,-1)));
            }else{
                $ar[$k] = iconv("UCS-2BE","UTF-8",pack("H4",substr($v,3,-1)));
            }
        }
        elseif(substr($v,0,2) == "&#") {
            if(strtolower(CHARSET) == 'gbk'){
                $ar[$k] = iconv("UCS-2BE","gbk",pack("n",substr($v,2,-1)));
            }else{
                $ar[$k] = iconv("UCS-2BE","UTF-8",pack("n",substr($v,2,-1)));
            }
        }
    }
    return join("",$ar);
}