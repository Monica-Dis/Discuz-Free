<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `goodstype` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `available_goods` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `coupon_type` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `coupon_num` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `coupon_limit` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `start` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljsyh_consume_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `receive_time` int(11) NOT NULL,
  `use_time` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cid` (`cid`)
)
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>
