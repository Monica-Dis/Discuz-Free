<?php
/**
 * Created by PhpStorm.
 * User: lixinyuan
 * Date: 2017/6/20
 * Time: ����11:11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if(!$_GET['reduction'] && $_GET['coupon_type'] != 2){
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo '<script>parent.tips("'.lang("plugin/aljsyh","addconsume_php_1").'","");</script>';
        exit;
    }else{
        echo '<script>parent.tips("'.lang("plugin/aljsyh","addconsume_php_2").'","");</script>';
        exit;
    }
}
if(!$_GET['coupon_num']){
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo '<script>parent.tips("'.lang("plugin/aljsyh","addconsume_php_3").'","");</script>';
        exit;
    }else{
        echo '<script>parent.tips("'.lang("plugin/aljsyh","addconsume_php_4").'","");</script>';
        exit;
    }
}
if(!$_GET['start'] || !$_GET['end']){
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo '<script>parent.tips("'.lang("plugin/aljsyh","addconsume_php_5").'","");</script>';
        exit;
    }else{
        echo '<script>parent.tips("'.lang("plugin/aljsyh","addconsume_php_6").'","");</script>';
        exit;
    }
}
$insertarray['full'] = $_GET['full'];
$insertarray['reduction'] = $_GET['reduction'];
$insertarray['coupon_type']=$_GET['coupon_type'];
$insertarray['coupon_num']=$_GET['coupon_num'];
$insertarray['coupon_limit']=$_GET['coupon_limit'];
$insertarray['available_goods']=$_GET['available_goods'];
if($_GET['available_goods']){
    $insertarray['goodstype']=implode(',', $_GET['goodstype']);
}else{
    $insertarray['goodstype']='';
}
$insertarray['start']=strtotime($_GET['start']);
?>