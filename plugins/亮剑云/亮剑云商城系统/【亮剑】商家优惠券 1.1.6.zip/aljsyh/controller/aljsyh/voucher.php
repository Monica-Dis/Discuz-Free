<?php

/**
 *
 * @author DisM!Ӧ������ dism.taobao.com
 * @version 1.0
 * @link http://docs.liangjianyun.com/
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class voucherAction{
    public $page;

    public function __construct($page) {
        $this->page = $page;
        $this->aljbdParameter();
    }
    /**
     * ��ȡ�Ż�ȯ
     *
     * @return void
     */
    public function voucher (){
        if($this->page->get->formhash == FORMHASH){
            $consume = DB::fetch_first('select * from %t where id=%d',array('aljbd_consume',$this->page->get->cid));
            $consumeLog = DB::result_first('select count(*) from %t where cid=%d and uid=%d',array('aljsyh_consume_log',$this->page->get->cid,$this->page->global->uid));
            if($consume['coupon_limit'] && $consume['coupon_limit'] <= $consumeLog){
                $tips = array(
                    'code' => 400,
                    'tip' => lang("plugin/aljsyh","voucher_php_1").$consume['coupon_limit'].lang("plugin/aljsyh","voucher_php_2")
                );
                echo json_encode(T::ajaxPostCharSet($tips));
                exit;
            }
            if($consume['start'] && $consume['start'] > TIMESTAMP){
                $tips = array(
                    'code' => 400,
                    'tip' => lang("plugin/aljsyh","voucher_php_3").dgmdate($consume['start'],'Y-m-d H:i:s')
                );
                echo json_encode(T::ajaxPostCharSet($tips));
                exit;
            }
            if($consume['end'] && $consume['end'] < TIMESTAMP){
                $tips = array(
                    'code' => 400,
                    'tip' => lang("plugin/aljsyh","voucher_php_4")
                );
                echo json_encode(T::ajaxPostCharSet($tips));
                exit;
            }
            if($consume['rubbish']!=0){
                $tips = array(
                    'code' => 400,
                    'tip' => lang("plugin/aljsyh","voucher_php_5")
                );
                echo json_encode(T::ajaxPostCharSet($tips));
                exit;
            }
            $consumeLogInfo = DB::result_first('select count(*) from %t where cid=%d and uid=%d and status=1',array('aljsyh_consume_log',$this->page->get->cid,$this->page->global->uid));
            if($consumeLogInfo){
                $tips = array(
                    'code' => 400,
                    'tip' => lang("plugin/aljsyh","voucher_php_6")
                );
                echo json_encode(T::ajaxPostCharSet($tips));
                exit;
            }
            $insertArray = array(
                'uid'=>$this->page->global->uid,
                'username'=>$this->page->global->username,
                'receive_time'=>TIMESTAMP,
                'cid'=>$this->page->get->cid,
                'status'=>1,
            );
            DB::insert('aljsyh_consume_log',$insertArray);
            DB::query('update %t set downnum=downnum+1 where id=%d',array('aljbd_consume',$this->page->get->cid));
            $tips = array(
                'code' => 100,
                'tip' => lang("plugin/aljsyh","voucher_php_7")
            );
            echo json_encode(T::ajaxPostCharSet($tips));
            exit;
        }else{
            $tips = array(
                'code' => 400,
                'tip' => lang("plugin/aljsyh","voucher_php_8")
            );
            echo json_encode(T::ajaxPostCharSet($tips));
            exit;
        }
    }
    /**
     * �ҵ��Ż�ȯ
     *
     *
     * @return void
     */
    public function couponList () {
        $do = $this->page->get->do;
        if($do == 'ajax'){
            $currpage = $this->page->get->page ? $this->page->get->page : 1;
            $perpage = 12;
            $start = ($currpage - 1) * $perpage;
            if($this->page->get->status == 1){
                $where = ' and b.end>0 and b.end > '.TIMESTAMP.' and a.status = '.$this->page->get->status;
            }else if($this->page->get->status == 3){
                $where = ' and b.end>0 and b.end < '.TIMESTAMP;
            }else{
                $where = ' and a.status = '.$this->page->get->status;
            }
            $couponList = DB::fetch_all('select * from %t a left join %t b on a.cid=b.id where a.uid=%d '.$where.' order by a.id desc limit %d,%d',
                array('aljsyh_consume_log','aljbd_consume',$this->page->global->uid,$start,$perpage));
            $goodstypename = array('0'=>lang("plugin/aljsyh","voucher_php_9"),'1'=>lang("plugin/aljsyh","voucher_php_10"),'2'=>lang("plugin/aljsyh","voucher_php_11"));

            foreach($couponList as $ck => $cv){
                $couponList[$ck]['clog'] = DB::result_first('select count(*) from %t where cid=%d and status=1',array('aljsyh_consume_log',$cv['id']));
                $couponList[$ck]['bdname'] = cutstr(DB::result_first('select name from %t where id=%d',array('aljbd',$cv['bid'])),20,'');
                $couponList[$ck]['start'] = dgmdate($cv['start'],'Y.m.d');
                if($cv['end'] < TIMESTAMP){
                    $couponList[$ck]['status'] = 3;
                }
                $couponList[$ck]['end'] = dgmdate($cv['end'],'Y.m.d');
                if($cv['available_goods'] == 1){
                    $goodstype = explode(',',$cv['goodstype']);
                    $goodstypenamestr = '';
                    foreach($goodstype as $gtv){
                        $goodstypenamestr .=  $goodstypename[$gtv].',';
                    }
                    $couponList[$ck]['goodstypename'] = trim($goodstypenamestr,',');
                }else{
                    $couponList[$ck]['goodstypename'] = '';
                }
            }
            if($couponList){
                echo json_encode(T::ajaxPostCharSet($couponList));
            }else{
                echo '1';
            }
            exit;
        }else{
            $countStatus[1] = DB::result_first('select count(*) from %t a left join %t b on a.cid=b.id where a.uid=%d and a.status = 1 and b.end>0 and b.end > '.TIMESTAMP,
                array('aljsyh_consume_log','aljbd_consume',$this->page->global->uid));
            $countStatus[2] = DB::result_first('select count(*) from %t a left join %t b on a.cid=b.id where a.uid=%d and a.status = 2 ',
                array('aljsyh_consume_log','aljbd_consume',$this->page->global->uid));
            $countStatus[3] = DB::result_first('select count(*) from %t a left join %t b on a.cid=b.id where a.uid=%d and b.end>0 and b.end < '.TIMESTAMP,
                array('aljsyh_consume_log','aljbd_consume',$this->page->global->uid));

            $this->page->assign('countStatus', $countStatus);

            $this->page->assign('navtitle', lang("plugin/aljsyh","voucher_php_12"));

            $this->page->display();
        }
    }
    /**
     * Ʒ���̼ҹ�������ע��
     *
     *
     * @return void
     */
    public function aljbdParameter(){
        global $Html5Plusapp,$immersed;
        $settings=C::t('#aljbd#aljbd_setting')->range();
        $mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_common_footernav']['value']));
        foreach($mobile_common_footernav as $key=>$value){
            $arr=explode('|',$value);
            $mobile_common_footernav_arr[]=$arr;
        }
        $price_unit = '&#65509;';
        $this->page->assign('price_unit', $price_unit,true);
        $this->page->assign('pluginid', 'aljbd');
        $this->page->assign('Html5Plusapp', $Html5Plusapp);
        $this->page->assign('immersed', $immersed);
        $this->page->assign('settings', $settings);
        $this->page->assign('mobile_common_footernav_arr', $mobile_common_footernav_arr,true);
        $this->page->assign('common_template_pluginid', 'aljbd');
        $this->page->assign('common_path', 'source/plugin/aljhtx');
    }
}

