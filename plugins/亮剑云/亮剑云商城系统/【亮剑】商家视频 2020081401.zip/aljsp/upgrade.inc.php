<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql ="ALTER TABLE  ".DB::table('aljbd_video')." ADD  `status` TINYINT( 3 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_video')." ADD  `reason` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_video')." ADD  `video_path` VARCHAR( 255 ) NOT NULL" ;
$sql ="ALTER TABLE ".DB::table('aljbd_video')." ADD `rubbish`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljbd_type_video')." (
  `id` mediumint(9) unsigned NOT NULL auto_increment,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
);";
if(DB::query($sql,'SILENT')){print('create table `aljbd_type_video` succeed!<br>');}
echo '<br/>repair succeed';
?>