<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$pluginid='aljsp';
$table_name = 'aljbd_type_video';
$act = $_GET['act'];
$do = intval($_GET['do']);
/**
 * @param $gotable ��Դ��
 * @param $totable �����
 */
function tableGoTo($gotable,$totable){
    $sql = 'insert into '.DB::table($totable).'(id,upid,subid,subject,displayorder) select id,upid,subid,subject,displayorder from '.DB::table($gotable);
    DB::query($sql);
}
if($_GET['act'] == 'emptytable'){
    $totable = $_GET['totable'];
    if(!$_GET['totable']){
        cpmsg('&#34920;&#19981;&#33021;&#20026;&#31354;');
    }
    $sql='TRUNCATE TABLE '.DB::table($totable);
    DB::query($sql);
    cpmsg(lang('plugin/aljbd','s10'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=type');
}if($_GET['act'] == 'import'){
    if(!$_GET['gotable'] || !$_GET['totable']){
        cpmsg('&#34920;&#19981;&#33021;&#20026;&#31354;');
    }
    $gotable = $_GET['gotable'];
    $totable = $_GET['totable'];
    if(DB::result_first('select count(*) from %t ',array($totable))){
        cpmsg('&#23548;&#20837;&#20998;&#31867;&#38656;&#35201;&#20808;&#28165;&#31354;&#26412;&#20998;&#31867;&#25968;&#25454;');
    }
    tableGoTo($gotable,$totable);
    cpmsg(lang('plugin/aljbd','s10'), 'action=plugins&operation=config&identifier='.$pluginid.'&pmod=type', 'succeed');
}

if(!submitcheck('editsubmit')) {	

?>
<script type="text/JavaScript">
var rowtypedata = [
	[[1,'&nbsp;', 'td25'],[1,'<input type="text" class="txt" name="newcatorder[]" value="0" />', 'td25'], [2, '<input name="newcat[]" value="" size="20" type="text" class="txt" />']],
	[[1,'&nbsp;', 'td25'],[1,'<input type="text" class="txt" name="newsuborder[{1}][]" value="0" />', 'td25'], [2, '<div class="board"><input name="newsubcat[{1}][]" value="" size="20" type="text" class="txt" /></div>']],
	[[1,'&nbsp;', 'td25'],[1,'<input type="text" class="txt" name="newsuborder[{1}][]" value="0" />', 'td25'], [2, '<div class="childboard"><input name="newsubcat[{1}][]" value="" size="20" type="text" class="txt" /></div>']],
	];

function del(id) {
	if(confirm('&#24744;&#30830;&#35748;&#35201;&#21024;&#38500;&#21527;&#65311;')) {
		window.location = '<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $do;?>&identifier=<?php echo $pluginid;?>&pmod=type&act=del&tid='+id;
	} else {
		return false;
	}
}
</script>
<?php
	showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=type');
	showtableheader();
	showsubtitle(array('',lang('plugin/aljbd','s2'),lang('plugin/aljbd','s3'),  lang('plugin/aljbd','s4')));
    ?>
    <style>
        .btn-border{
            border: 1px solid #ddd;
            padding: 5px 10px;
            margin-right: 10px;
        }
    </style>
    <div class="itemtitle" style="margin-top: 20px">
        <h3>

        </h3>
        <ul class="tab1">
            <li >
                <a class="btn-border" style="border: 1px solid red;" onclick="showDialog('&#24744;&#30830;&#35748;&#35201;&#28165;&#31354;&#35270;&#39057;&#20998;&#31867;&#34920;&#21527;&#65311;','confirm','',function(){location.href='<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=<?php echo $pluginid;?>&do=<?php echo $do;?>&pmod=type&act=emptytable&totable=<?php echo $table_name;?>'});return false;" href="#">
                    <span style="color:red;">&#28165;&#31354;&#35270;&#39057;&#20998;&#31867;</span>
                </a>
            </li>
            <li >
                <a class="btn-border" href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=<?php echo $pluginid;?>&do=<?php echo $do;?>&pmod=type&act=import&gotable=aljbd_type&totable=<?php echo $table_name;?>">
                    <span>&#23548;&#20837;&#21830;&#23478;&#20998;&#31867;</span>
                </a>
            </li>
            <li >
                <a class="btn-border" href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=<?php echo $pluginid;?>&do=<?php echo $do;?>&pmod=type&act=import&gotable=aljbd_type_goods&totable=<?php echo $table_name;?>">
                    <span>&#23548;&#20837;&#21830;&#21697;&#20998;&#31867;</span>
                </a>
            </li>
            <li >
                <a class="btn-border" href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=<?php echo $pluginid;?>&do=<?php echo $do;?>&pmod=type&act=import&gotable=aljbd_type_notice&totable=<?php echo $table_name;?>">
                    <span>&#23548;&#20837;&#27963;&#21160;&#20998;&#31867;</span>
                </a>
            </li>
            <li >
                <a class="btn-border" href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=<?php echo $pluginid;?>&do=<?php echo $do;?>&pmod=type&act=import&gotable=aljbd_type_consume&totable=<?php echo $table_name;?>">
                    <span>&#23548;&#20837;&#20248;&#24800;&#21048;&#20998;&#31867;</span>
                </a>
            </li>
        </ul>

    </div>
    <?php
	$brandtype = C::t('#'.$pluginid.'#'.$table_name)->fetch_all_by_upid(0);
	foreach($brandtype as $key=>$value){

		$bt = C::t('#'.$pluginid.'#'.$table_name)->fetch_all_by_upid($key);
		foreach($bt as $k=>$v){
			$brandtype[$key]['subtype'][$k] = $v;
			$brandtype3 = C::t('#'.$pluginid.'#'.$table_name)->fetch_all_by_upid($v['id']);
			if($brandtype3){
				foreach($brandtype3 as $k3=>$v3){
					$brandtype[$key]['subtype'][$k]['subtype3'][$k3] = $v3;
				}
			}
		}
	}
	if($brandtype) {
		foreach($brandtype as $id=>$type) {
			$show = '<tr class="hover"><td  class="td25" onclick="toggle_group(\'group_'.$id.'\', $(\'a_group_'.$id.'\'))"><a id="a_group_'.$id.'" href="javascript:;">[-]</a></td><td class="td25"><input type="text" class="txt" name="order['.$id.']" value="'.$type['displayorder'].'" /></td><td><div class="parentboard"><input type="text" class="txt" name="name['.$id.']" value="'.$type['subject'].'"></div></td>';
			if(!$type['subid']) {
				$show .= '<td><a  onclick="del('.$id.')" href="###">'.lang('plugin/aljbd','s5').'</td></tr><tbody id="group_'.$id.'">';
			} else {
				$show .= '<td>&nbsp;</td></tr><tbody id="group_'.$id.'">';
			}
			echo $show;
			if($type['subtype']) {
				foreach($type['subtype'] as $subid=>$stype) {
					echo '<tr class="hover"><td  class="td25">&nbsp;</td><td class="td25"><input type="text" class="txt" name="order['.$subid.']" value="'.$stype['displayorder'].'" /></td><td><div class="board"><input type="text" class="txt" name="name['.$subid.']" value="'.$stype['subject'].'">
					<a class="addchildboard" onclick="addrowdirect = 1;addrow(this, 2, '.$stype['id'].')" href="###">&#28155;&#21152;&#31532;&#19977;&#32423;&#20998;&#31867;</a>
					</div></td><td><a  onclick="del('.$subid.')" href="###">'.lang('plugin/aljbd','s6').'</td></tr>';
					if($stype['subtype3']){
						foreach($stype['subtype3'] as $subid3=>$stype3){
							echo '<tr class="hover"><td  class="td25">&nbsp;</td><td class="td25"><input type="text" class="txt" name="order['.$subid3.']" value="'.$stype3['displayorder'].'" /></td><td><div class="childboard"><input type="text" class="txt" name="name['.$subid3.']" value="'.$stype3['subject'].'">
							</div></td><td><a  onclick="del('.$subid3.')" href="###">'.lang('plugin/aljbd','s5').'</td></tr>';
						}
					}
				}
				
			}
			echo '<tr class="hover"><td class="td25">&nbsp;</td><td colspan="2" ><div class="lastboard"><a href="###" onclick="addrow(this, 1,'.$id.' )" class="addtr">'.lang('plugin/aljbd','s7').'</a></div></td></tr></tbody>';
		}	
	}
	echo '<tr class="hover"><td class="td25">&nbsp;</td><td colspan="2" ><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.lang('plugin/aljbd','s8').'</a></div></td></tr>';
	

	showsubmit('editsubmit');
	showtablefooter();
	showformfooter();/*dis'.'m.tao'.'bao.com*/

} else {
	$order = $_GET['order'];
	$name = $_GET['name'];
	$newsubcat = $_GET['newsubcat'];
	$newcat = $_GET['newcat'];
	$newsuborder = $_GET['newsuborder'];
	$newcatorder = $_GET['newcatorder'];
	if(is_array($order)) {
		foreach($order as $id=>$value) {
			C::t('#'.$pluginid.'#'.$table_name)->update($id,array('displayorder'=>$value,'subject'=>$name[$id]));
		}
	}

	if(is_array($newcat)) {
		foreach($newcat as $key=>$name) {
			if(empty($name)) {
				continue;
			}
			$cid=C::t('#'.$pluginid.'#'.$table_name)->insert(array('upid' => '0', 'subject' => $name, 'displayorder' => $newcatorder[$key]),1);
		}
	}

	if(is_array($newsubcat)) {
		foreach($newsubcat as $cid=>$subcat) {
			$sub=C::t('#'.$pluginid.'#'.$table_name)->fetch($cid);
			$subtype =$sub['subid'];
			foreach($subcat as $key=>$name) {
				$subid=C::t('#'.$pluginid.'#'.$table_name)->insert(array('upid' => $cid, 'subject' => $name, 'displayorder' => $newsuborder[$cid][$key]),1);
				$subtype .= $subtype ? ','.$subid : $subid;
			}
			C::t('#'.$pluginid.'#'.$table_name)->update($cid,array('subid'=>$subtype));
		}
	}

	cpmsg(lang('plugin/aljbd','s9'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=type', 'succeed');	
}
//From: Dism��taobao��com
?>


