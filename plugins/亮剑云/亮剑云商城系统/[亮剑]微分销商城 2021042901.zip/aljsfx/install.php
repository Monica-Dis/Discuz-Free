<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


//fx e
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljsfx_cashorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(32) NOT NULL,
  `trans_uid` varchar(255) NOT NULL,
  `trans_time` varchar(255) NOT NULL,
  `uid` int(8) unsigned NOT NULL,
  `username` char(50) NOT NULL,
  `time` char(50) NOT NULL,
  `rmb` double(15,2) NOT NULL,
  `status` int(8) NOT NULL,
  `admindesc` varchar(255) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `orderid` (`orderid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljsfx_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` char(32) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `beneficiary_uid` int(11) NOT NULL,
  `beneficiary_username` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `scale` int(11) NOT NULL,
  `level` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `payment_days` int(11) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `desc` varchar(255) NOT NULL,
  `shop_scale` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `num` int(11) NOT NULL,
  `goods_id` int(11) NOT NULL,
  `dis_commission` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `orderid` (`orderid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljsfx_rank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `day` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `first_scale` int(11) NOT NULL,
  `second_scale` int(11) NOT NULL,
  `third_scale` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `displayorder` int(11) NOT NULL,
  `shop_scale` int(11) NOT NULL,
  `f_shop_scale` int(11) NOT NULL,
  `payment_days` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `mincashmoney` decimal(10,2) NOT NULL,
  `open_mypay` tinyint(4) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `fx_jf_type` tinyint(4) NOT NULL,
  `fx_ext` int(11) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljsfx_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `total_commission` decimal(10,2) NOT NULL,
  `account_commissions` decimal(10,2) NOT NULL,
  `extraction_commission` decimal(10,2) NOT NULL,
  `uid` int(11) NOT NULL,
  `shop_name` varchar(255) NOT NULL,
  `tel` char(15) NOT NULL,
  `shop_img` varchar(255) NOT NULL,
  `shop_weixin` varchar(255) NOT NULL,
  `shop_logo` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `subid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `rankid` int(4) NOT NULL,
  `rankendtime` int(11) NOT NULL,
  `admindesc` varchar(255) NOT NULL,
  `view` int(11) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljsfx_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `first_leader_uid` int(11) NOT NULL,
  `second_leader_uid` int(11) NOT NULL,
  `third_leader_uid` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `is_distribution` tinyint(4) NOT NULL,
  `fx_jf_type` tinyint(4) NOT NULL,
  `fx_ext` int(11) NOT NULL,
  PRIMARY KEY (`id`)
)
EOF;
runquery($sql);
//fx s
$sql ="ALTER TABLE ".DB::table('aljsfx_rank')." ADD `donation_amount` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `is_distribution` tinyint(4) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `dis_commission` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql = "ALTER TABLE " . DB::table('aljbd_goods_order_list') . " ADD `status` tinyint(4) NOT NULL";
DB::query($sql, 'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `is_distribution` tinyint(4) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `dis_commission` int(11) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_vip')." ADD `is_distribution` tinyint(4) NOT NULL" ;
DB::query($sql,'SILENT');
foreach(DB::fetch_all('select * from %t',array('common_plugin')) as $cpv){
    $cparray[$cpv['identifier']] = $cpv;
}
if($cparray['aljqb']){
    if(!DB::result_first('select count(*) from %t where pluginname=%s',array('aljqb_secretkey','aljsfx'))){
        loadcache('plugin');
        DB::insert('aljqb_secretkey',array('pluginname'=>'aljsfx','secretkey'=>'shenmikey123','tokenurl'=>rtrim($_G['siteurl'],'/').'/source/plugin/aljsfx/pay/pay.php'));
    }
}
//�ҵ�ҳ�泣����� �ҵ��ղ�
$mobile_user_common_entrance = C::t('#aljbd#aljbd_setting')->fetch('mobile_user_common_entrance');
if($mobile_user_common_entrance){
    $mobile_user_common_entrance['value'] .= '
source/plugin/aljsfx/static/img/fx_bind.png|plugin.php?id=aljsfx&c=distribution&a=inviteCode&mobile=2|&#32465;&#23450;&#36992;&#35831;&#20154;
source/plugin/aljsfx/static/img/fx_user.png|plugin.php?id=aljsfx&c=distribution&a=user&mobile=2|&#25105;&#30340;&#24494;&#24215;';
    C::t('#aljbd#aljbd_setting')->update_value_by_key($mobile_user_common_entrance['value'],'mobile_user_common_entrance');
}
//finish to put your own code
$finish = TRUE;
?>
