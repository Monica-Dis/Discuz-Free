<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljsfx_shop extends discuz_table{
	public function __construct() {

			$this->_table = 'aljsfx_shop';
			$this->_pk    = 'id';

			parent::__construct(); /*dism��taobao��com*/
	}
	

}




?>