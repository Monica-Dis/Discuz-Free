<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljsfx_rank extends discuz_table{
	public function __construct() {

			$this->_table = 'aljsfx_rank';
			$this->_pk    = 'id';

			parent::__construct(); /*dism��taobao��com*/
	}
	

}




?>