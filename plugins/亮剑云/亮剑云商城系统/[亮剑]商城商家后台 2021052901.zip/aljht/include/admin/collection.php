<?php
if(submitcheck('formhash') && empty($keyword)){
	if($_GET['sign'] == 2){
		if(is_array($_GET['delete'])) {
			foreach($_GET['delete'] as $k => $id) {
				DB::query('delete from %t where id = %d',array('aljbd_collection',$id));
			}
		}
	}
	echo '<script>parent.tips(0);</script>';
	exit;
}
if($_GET['frommod']){
	$frommod = addcslashes($_GET['frommod'], '%_');
}else{
	$frommod = 'aljbd';
}

$currpage=$_GET['page']?intval($_GET['page']):1;
$perpage=10;
$start=($currpage-1)*$perpage;
$con[]='aljbd_collection';

$where=" where uid = %d";
$con[] = $_G['uid'];
$where.=" and frommod = %s";
$con[] = $frommod;


$num = DB::result_first('select count(*) from %t'.$where,$con);
$con[]=$start;
$con[]=$perpage;
$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY id desc limit %d,%d',$con);

foreach($bdlist as $l => $log){
	if($log['frommod'] == 'aljbd'){
		$bd_c = C::t('#aljbd#aljbd') -> fetch($log['tid']);
		$bdlist[$l]['title'] = $bd_c['name'];
		$bdlist[$l]['dateline'] = $bd_c['dateline'];
		$bdlist[$l]['url'] = 'plugin.php?id=aljbd&act=view&bid='.$log['tid'];
	}else if($log['frommod'] == 'goods'){
		$bd_c = C::t('#aljbd#aljbd_goods') -> fetch($log['tid']);
		$bdlist[$l]['title'] = $bd_c['name'];
		$bdlist[$l]['dateline'] = $bd_c['dateline'];
		$bdlist[$l]['url'] = 'plugin.php?id=aljbd&act=goodview&gid='.$log['tid'].'&bid='.$bd_c['bid'];
	}else if($log['frommod'] == 'consume'){
		$bd_c = C::t('#aljbd#aljbd_consume') -> fetch($log['tid']);
		$bdlist[$l]['title'] = $bd_c['subject'];
		$bdlist[$l]['dateline'] = $bd_c['dateline'];
		$bdlist[$l]['url'] = 'plugin.php?id=aljbd&act=consumeview&cid='.$log['tid'].'&bid='.$bd_c['bid'];
	}else if($log['frommod'] == 'notice'){
		$bd_c = C::t('#aljbd#aljbd_notice') -> fetch($log['tid']);
		$bdlist[$l]['title'] = $bd_c['subject'];
		$bdlist[$l]['dateline'] = $bd_c['dateline'];
		$bdlist[$l]['url'] = 'plugin.php?id=aljbd&act=noticeview&nid='.$log['tid'].'&bid='.$bd_c['bid'];
	}
		
}
$bdlist = dhtmlspecialchars($bdlist);
$navtitle = $_G['cache']['plugin'][$pluginid]['title'];
$metakeywords = $_G['cache']['plugin'][$pluginid]['keywords'];
$metadescription = $_G['cache']['plugin'][$pluginid]['description'];
include template('aljht:admin/collection/collection');
?>