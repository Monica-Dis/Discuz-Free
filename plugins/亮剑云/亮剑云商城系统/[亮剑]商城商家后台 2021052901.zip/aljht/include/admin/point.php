<?php
if(submitcheck('formhash') && empty($keyword)){
	if($_GET['sign'] == 2){
		if(is_array($_GET['delete'])) {
			foreach($_GET['delete'] as $k => $id) {
				DB::query('delete from %t where id = %d',array('aljbd_point',$id));
			}
		}
	}else{
		if(is_array($_GET['delete'])) {
			foreach($_GET['delete'] as $k => $id) {
				$point=C::t('#aljbd#aljbd_point')->fetch($id);
				C::t('#aljbd#aljbd')->update($point['bid'],array('x'=>$point['x'],'y'=>$point['y']));
				C::t('#aljbd#aljbd_point')->delete($id);
			}
		}
	}
	echo '<script>parent.tips(0);</script>';
	exit;
}
$currpage=intval($_GET['page'])?intval($_GET['page']):1;
$perpage=10;
$start=($currpage-1)*$perpage;
$num=C::t('#aljbd#aljbd_point')->count_by_buid($_G['uid']);
$pointlist=C::t('#aljbd#aljbd_point')->fetch_all_by_buid($_G['uid'],$start,$perpage);
$navtitle = '&#32416;&#27491;&#26631;&#27880;&#31649;&#29702;-'.$config['title'];
$metakeywords =  $bd['other']?$bd['other']:$config['keywords'];
$metadescription = $config['description'];
include template('aljht:admin/point/point');
?>