<?php
$gid = intval($_GET['gid']);
if($do == 'isopen'){
    $status = intval($_GET['status']);

    if(C::t('#aljbd#aljbd_ather')->update($gid,array('status'=>$status))){
        echo 1;
    }else{
        echo 0;
    }
    exit;
}else if($do == 'addather' || $do == 'editather'){
    $gvip = C::t('#aljbd#aljbd_ather') -> fetch($gid);
    if(submitcheck('formhash')){
        if($_GET['compress'] == '1'){
            if($_FILES['logo']['tmp_name']) {
                $picname = $_FILES['logo']['name'];
                $picsize = $_FILES['logo']['size'];

                if ($picname != "") {
                    $type = strtolower(strrchr($picname, '.'));
                    if ($type != ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
                        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                            echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
                            exit;
                        }else{
                            echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
                            exit;
                        }
                    }
                    if (($picsize/1024)>$_G['cache']['plugin']['aljbd']['img_size']) {
                        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                            echo "<script>parent.tips('".lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB'."','');</script>";
                            exit;
                        }else{
                            echo "<script>parent.tips('".lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB'."','');</script>";
                            exit;
                        }
                    }
                    $rand = rand(100, 999);
                    $pics = date("YmdHis") . $rand . $type;
                    $img_dir = $image_path.'logo/'.date('Ymd',TIMESTAMP).'/';
                    if (!is_dir($img_dir)) {
                        mkdir($img_dir);
                    }
                    $logo = $img_dir.$pics;
                    if(@copy($_FILES['logo']['tmp_name'], $logo)||@move_uploaded_file($_FILES['logo']['tmp_name'], $logo)){
                        if($_G['cache']['plugin']['aljbd']['iswatermark']){
                            $image->Watermark(DISCUZ_ROOT.'./'.$logo,'', 'forum');
                        }
                        @unlink($_FILES['logo']['tmp_name']);
                    }
                }
            }
        }else{
            if ($_GET['logo']) {
                $rand = rand(100, 999);
                $pics = date("YmdHis") . $rand . '.jpg';
                $img_dir = $image_path.'logo/'.date('Ymd',TIMESTAMP).'/';
                if (!is_dir($img_dir)) {
                    mkdir($img_dir);
                }
                $$pic = $img_dir . $pics;

                $logo = file_put_contents($$pic,file_get_contents($_GET['logo']));

                if ($logo) {
                    $imageinfo = getimagesize($$pic);
                    if($_G['cache']['plugin']['aljbd']['iswatermark']){
                        $image->Watermark(DISCUZ_ROOT.'./'.$$pic,'', 'forum');
                    }
                    //@unlink($_FILES[$pic]['tmp_name']);
                }
                $logo = $$pic;
            }
        }
        $updatearray = array(
            'title'=>$_GET['title'],
            'desc'=>$_GET['desc'],
            'type'=>1,
            'status'=>$_GET['status'],
            'displayorder'=>$_GET['displayorder'],
        );
        if($gvip){
            if($logo){
                unlink($gvip['logo']);
                $updatearray['logo']=$logo;
            }
            C::t('#aljbd#aljbd_ather')->update($gid,$updatearray);
        }else{
            $updatearray['addtime'] = TIMESTAMP;
            $updatearray['logo']=$logo;
            C::t('#aljbd#aljbd_ather')->insert($updatearray);
        }

        echo "<script>parent.tips('".lang('plugin/aljbd','s53')."','plugin.php?id=aljht&act=admin&op=".$op.$urlmod."');</script>";
        exit;

    }else{

        include template('aljht:admin/ather/addather');
    }
}else{
    if(submitcheck('formhash')){

        $gs=dhtmlspecialchars($_GET['yhz']);
        if($_GET['sign'] == 2){
            if(is_array($_GET['delete'])) {
                foreach($_GET['delete'] as $k => $id) {
                    C::t('#aljbd#aljbd_ather')->delete($id);//ɾ��
                }
            }
        }else if($_GET['sign'] == 3){
            if(is_array($_GET['delete'])) {
                foreach($_GET['delete'] as $k => $id) {
                    C::t('#aljbd#aljbd_ather')->update($id,array('status'=>'1'));//����
                }
            }
        }else if($_GET['sign'] == 4){
            if(is_array($_GET['delete'])) {
                foreach($_GET['delete'] as $k => $id) {
                    C::t('#aljbd#aljbd_ather')->update($id,array('status'=>'0'));//�ر�
                }
            }
        }else{
            foreach($gs as $k => $v){

                if ($v['logo']) {
                    $rand = rand(100, 999);
                    $pics = date("YmdHis") . $rand . '.jpg';
                    $img_dir = $image_path.'logo/'.date('Ymd',TIMESTAMP).'/';
                    if (!is_dir($img_dir)) {
                        mkdir($img_dir);
                    }
                    $pic = $img_dir . $pics;

                    file_put_contents($pic,file_get_contents($v['logo']));

                }
                if(C::t('#aljbd#aljbd_ather')->fetch($k)){
                    $updatearray = array(
                        'title'=>$v['title'],
                        'desc'=>$v['desc'],
                        'displayorder'=>$v['displayorder'],
                    );
                    if($pic){
                        $updatearray['logo'] = $pic;
                    }
                    C::t('#aljbd#aljbd_ather')->update($k,$updatearray);
                }else{
                    $insertarray = array(
                        'title'=>$v['title'],
                        'desc'=>$v['desc'],
                        'type'=>1,
                        'displayorder'=>$v['displayorder'],
                    );
                    if($pic){
                        $insertarray['logo'] = $pic;
                    }
                    $insertarray['addtime'] = TIMESTAMP;
                    C::t('#aljbd#aljbd_ather')->insert($insertarray);
                }
                unset($pic);
                unset($insertarray);
                unset($updatearray);
            }
        }
        echo '<script>parent.tips(0);</script>';
        exit;
    }else{

        //$aljbd_groups=C::t('#aljbd#aljbd_ather')->range();
        $aljbd_groups=DB::fetch_all('select * from %t where type=1 order by displayorder desc,id asc',array('aljbd_ather'));
        include template('aljht:admin/ather/ather');
    }
}
//di'.'sm.t'.'aoba'.'o.com
?>