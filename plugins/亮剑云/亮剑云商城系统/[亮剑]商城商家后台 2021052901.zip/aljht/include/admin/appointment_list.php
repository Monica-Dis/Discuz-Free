<?php
if($do == 'view'){
	$user=C::t('#aljsyy#'.$pluginid_aljbd.'_appointment')->fetch($_GET['yid']);
	$lp=C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd)->fetch($user['bid']);
	include template('aljht:admin/appointment_list/view');
}else{
	$keyword = addcslashes($_GET['search'], '%_');
	if(submitcheck('formhash') && empty($keyword)){
		if($_GET['sign'] == 1){
			if(is_array($_GET['delete'])) {
				foreach($_GET['delete'] as $k => $id) {
					DB::query('update %t set state=1  where id = %d',array($pluginid_aljbd.'_appointment',$id));
				}
			}
		}else if($_GET['sign'] == 2){
			if(is_array($_GET['delete'])) {
				foreach($_GET['delete'] as $k => $id) {
					DB::query('delete from %t where id = %d',array($pluginid_aljbd.'_appointment',$id));
				}
			}
		}
		echo '<script>parent.tips(0);</script>';
		exit;
	}
	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	$con[]=$pluginid_aljbd.'_appointment';
	if($administrators){
		if($_GET['state'] == 1){
			$where=" where state = 1";
		}else{
			$where=" where state = 0";
		}
	}else{
		if($_GET['state'] == 2){
			$where=" where uid = %d";
			$con[] = $_G['uid'];
		}else{
			$where=" where buid = %d";
			$con[] = $_G['uid'];
			if($_GET['state'] == 1){
				$where.= ' and state = 1';
			}else{
				$where.= ' and state = 0';
			}
		}
	}
	
	if($_GET['search']){
		$con[] ='%' . $keyword . '%';
		$where.=" and title like %s";
	}
	
	$num = DB::result_first('select count(*) from %t'.$where,$con);
	$con[]=$start;
	$con[]=$perpage;
	$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY id desc limit %d,%d',$con);
	
	$bdlist = dhtmlspecialchars($bdlist);
	$navtitle = $_G['cache']['plugin'][$pluginid]['title'];
	$metakeywords = $_G['cache']['plugin'][$pluginid]['keywords'];
	$metadescription = $_G['cache']['plugin'][$pluginid]['description'];
	include template('aljht:admin/appointment_list/appointment_list');
}
//di'.'sm.t'.'aoba'.'o.com
?>