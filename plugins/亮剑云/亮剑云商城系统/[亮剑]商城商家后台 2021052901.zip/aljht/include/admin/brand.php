<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_G['cache']['plugin']['aljbdx']['is_aljqb']){
    if($administrators){
        $aljbd_groups=DB::fetch_all('select * from %t where type=0 and status=1 order by displayorder desc,id asc',array('aljbd_vip'));
    }else{
        $aljbd_groups=DB::fetch_all('select * from %t where type=0 and status=1 and is_hide=0 order by displayorder desc,id asc',array('aljbd_vip'));
    }
}
if($do == 'sh_status'){
    if($_GET['formhash'] == FORMHASH) {
        if(!$administrators && $_GET[i] != 1){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","brand_php_4"))));
            exit;
        }
        if(!$_GET[cashid]){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","brand_php_5"))));
            exit;
        }

        $goods = C::t('#aljbd#aljbd')->fetch($_GET[cashid]);
        if(!$goods){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","brand_php_6"))));
            exit;
        }

        if(strtolower(CHARSET) == 'gbk' && !$_G[mobile] && $_GET[message]){
            $_GET[message] = diconv($_GET[message],'utf-8','gbk');
        }

        if(DB::query('update %t set status=%d,reason=%s  where id = %d and status = %d',array('aljbd',$_GET[status],$_GET[message],$_GET[cashid],$goods['status']))){
            if($_GET[status] == 3){
                $send_goods_tips = $_G['cache']['plugin']['aljbd']['refusetips'].'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=brand&mod=my" target="_blank">'.lang("plugin/aljht","brand_php_7").'</a>';
            }else{
                $send_goods_tips = $_G['cache']['plugin']['aljbd']['passtips'].'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=brand&mod=my" target="_blank">'.lang("plugin/aljht","brand_php_8").'</a>';
            }
            $reason = $_GET[message] ? lang("plugin/aljht","brand_php_9").$_GET[message] : '';
            
            notification_add(
                $goods['uid'],
                'system',str_replace(array('{username}','{shopname}','{reason}'),array($goods['username'],$goods['name'],$reason), $send_goods_tips),
                array('from_idtype'  => 'aljbd_brand','from_id' => $goods['id'])
            );
            echo json_encode(T::ajaxPostCharSet(array('code'=>1,'text'=>lang("plugin/aljht","brand_php_10"))));
            exit;
        }else{
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","brand_php_11"))));
            exit;
        }
    }else{
        echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","brand_php_12"))));
        exit;
    }
}else if($do == 'edit' || $do == 'adddp'){
	$bd = C::t('#aljbd#aljbd') -> fetch($bid);
    if($do == 'adddp' && !$administrators){
        if($settings['is_one_brand']['value']==1){
            $bnum=C::t('#aljbd#aljbd')->count_by_status('',$_G['uid']);
            if($bnum>=1){
                $onebrandtips = lang("plugin/aljht","brand_php_13");
                if(submitcheck('formhash')) {
                    echo '<script>parent.tips("'.$onebrandtips.'");</script>';
                    exit;
                }else {
                    if($bnum == 1){
                        echo "<script>alert('".$onebrandtips."');location.href='plugin.php?id=aljht&act=admin&op=brand&do=edit&bid=".$aljbd['id']."';</script>";
                        exit;
                    }else{
                        $aljht_tips = $onebrandtips;
                        include template('aljht:admin/pogressbar');
                        exit;
                    }
                }
            }
        }
        if($yhzqx) {
            $bnum=C::t('#aljbd#aljbd')->count_by_status('',$_G['uid']);
            if($brandnum['brand'] && !$administrators){
                if($brandnum['brand'] == $checksign){
                    if(submitcheck('formhash')) {
                        echo '<script>parent.tips("'.lang('plugin/aljbd','noauth').$brandtips.'");</script>';
                        exit;
                    }else{
                        $aljht_tips = lang('plugin/aljbd','noauth').$brandtips;
                        include template('aljht:admin/pogressbar');
                        exit;
                    }
                }
                if($bnum>=$brandnum['brand']){
                    if(submitcheck('formhash')) {
                        echo '<script>parent.tips("'.lang('plugin/aljbd', 'groups_1') . $brandnum['brand'] . lang('plugin/aljbd', 'groups_2') . $brandtips.'");</script>';
                        exit;
                    }else {
                        $aljht_tips = lang('plugin/aljbd', 'groups_1') . $brandnum['brand'] . lang('plugin/aljbd', 'groups_2') . $brandtips;
                        include template('aljht:admin/pogressbar');
                        exit;
                    }
                }
            }
        }

        if ($_G['cache']['plugin']['aljbd']['money'] 
        && $_G['cache']['plugin']['aljbd']['money_lx'] 
        && getuserprofile('extcredits' . $_G['cache']['plugin']['aljbd']['money_lx']) < $_G['cache']['plugin']['aljbd']['money']
        && !$_G['cache']['plugin']['aljbdx']['is_aljqb']
        ) {
            if($_G['cache']['plugin']['aljpay']){
                $ext_pay_url = '<a href="plugin.php?id=aljpay" target="_blank">&#62;&#62;&#62;&#21435;&#20805;&#20540;</a>';
                $ext_pay = 'plugin.php?id=aljpay';
            }
            if(submitcheck('formhash')) {
                echo '<script>parent.tips("'.$_G['setting']['extcredits'][$_G['cache']['plugin']['aljbd']['money_lx']]['title'] . lang('plugin/aljbd', 'index_4').'","'.$ext_pay.'");</script>';
                exit;
            }else {

                $aljht_tips = $_G['setting']['extcredits'][$_G['cache']['plugin']['aljbd']['money_lx']]['title'] . lang('plugin/aljbd', 'index_4').$ext_pay_url;
                include template('aljht:admin/pogressbar');
                exit;
            }
        }
    }
	if(submitcheck('formhash')){
		if(!$_GET['name']){
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_3')."','');</script>";
				exit;
			}else{
				echo '<script>parent.tips("'.lang('plugin/aljbd','aljbd_3').'");</script>';
				exit;
			}
			
		}
		if(!$_GET['type']){
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_4')."','');</script>";
				exit;
			}else{
				echo '<script>parent.tips("'.lang('plugin/aljbd','aljbd_4').'");</script>';
				exit;
			}
		}
		if(!$_GET['region']){
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_5')."','');</script>";
				exit;
			}else{
				echo '<script>parent.tips("'.lang('plugin/aljbd','aljbd_5').'");</script>';
				exit;
			}
		}
		if($_G['cache']['plugin']['aljbd']['islogo'] && $do == 'adddp'){
			if(!$_GET['logo'] || ($_GET['compress'] && !$_FILES['logo']['tmp_name'])) {
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('".lang('plugin/aljbd','logo')."','');</script>";
					exit;
				}else{
					echo '<script>parent.tips("'.lang('plugin/aljbd','logo').'");</script>';
					exit;
				}
			}
		}
		if($settings['is_form']['value'] && $do == 'adddp'){
			if(DB::result_first('select * from %t where name = %s',array('aljbd',$_GET['name']))){
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('&#24215;&#38138;&#24050;&#23384;&#22312;','');</script>";
					exit;
				}else{
					echo '<script>parent.tips("&#24215;&#38138;&#24050;&#23384;&#22312;");</script>';
					exit;
				}
			}
			if(!valid_token($_GET['aljbd_token'],getcookie('aljbd_token'),'aljbd_token')){
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#35831;&#21047;&#26032;&#21518;&#37325;&#26032;&#21457;&#24067;&#25110;&#36820;&#22238;&#24215;&#38138;&#31649;&#29702;&#26597;&#30475;&#24215;&#38138;','');</script>";
					exit;
				}else{
					echo '<script>parent.tips("&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#35831;&#21047;&#26032;&#21518;&#37325;&#26032;&#21457;&#24067;&#25110;");</script>';
					exit;
				}
			}
        }
        if($_GET['fare_type'] == 3 && $_GET['postal_amount']<=0){
            echo '<script>parent.tips("'.lang("plugin/aljht","brand_php_1").'");</script>';
            exit;
        }
		if($_GET['compress'] == '1'){
			if($_FILES['logo']['tmp_name']) {
				$picname = $_FILES['logo']['name'];
				$picsize = $_FILES['logo']['size'];
			
				if ($picname != "") {
					$type = strtolower(strrchr($picname, '.'));
					if ($type!= ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
							exit;
						}else{
							echo '<script>parent.tips("'.lang('plugin/aljbd','s19').'");</script>';
							exit;
						}
					}
					if (($picsize/1024)>$_G['cache']['plugin']['aljbd']['img_size']) {
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('".lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB'."','');</script>";
							exit;
						}else{
							echo '<script>parent.tips("'.lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB'.'");</script>';
							exit;
						}
					}
					$rand = rand(100, 999);
					$pics = date("YmdHis") . $rand . $type;
					$img_dir = $image_path."logo/".date('Ymd',TIMESTAMP).'/';
					if (!is_dir($img_dir)) {
						mkdir($img_dir);
					}
					$logo = $img_dir. $pics;
					if(@copy($_FILES['logo']['tmp_name'], $logo)||@move_uploaded_file($_FILES['logo']['tmp_name'], $logo)){
						if($_G['cache']['plugin']['aljbd']['iswatermark']){
							$image->Watermark(DISCUZ_ROOT.'./'.$logo,'', 'forum');
						}
                        if (file_exists($logo)) {
                            if($_G['cache']['plugin']['aljoss']['Access_Key']){
                                $logo = T::oss($logo, 'aljbd');
                            }
                        }
						@unlink($_FILES['logo']['tmp_name']);
					}
				}
			}
		}else{
			if ($_GET['logo']) {
                if (strpos($_GET['logo'],"base64") === false) {
                    $logo = $_GET['logo'];
                } else {
                    unlink($bd['logo']);
                    T::delete_oss($bd['logo']);
                    unlink('source/plugin/aljwx/static/miniqrcode/'.md5('plugin.php?id=aljbd&act=view&bid='.$bd['id']).'.jpg');
                    $logo = T::saveimg($_GET['logo'],$image_path.'logo/');
                }
			}
		}
		if(in_array($_G['groupid'],unserialize($_G['cache']['plugin']['aljbd']['mgroups'])) || $administrators){
			$status=1;
        }
        
		if($_G['cache']['plugin']['aljbd']['yushe'] && $do != 'edit'){
			$_GET['intro']=str_replace ("\r\n", "<br/>", $_GET['intro']);
		}
		if($_GET['xy']){
			$xy = explode(',', $_GET['xy']);
        }
        if($_GET['compress'] == '1'){
			if($_FILES['brand_bg']['tmp_name']) {
				$picname = $_FILES['brand_bg']['name'];
				$picsize = $_FILES['brand_bg']['size'];
			
				if ($picname != "") {
					$type = strtolower(strrchr($picname, '.'));
					if ($type!= ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
							exit;
						}else{
							echo '<script>parent.tips("'.lang('plugin/aljbd','s19').'");</script>';
							exit;
						}
					}
					if (($picsize/1024)>$_G['cache']['plugin']['aljbd']['img_size']) {
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('".lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB'."','');</script>";
							exit;
						}else{
							echo '<script>parent.tips("'.lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB'.'");</script>';
							exit;
						}
					}
					$rand = rand(100, 999);
					$pics = date("YmdHis") . $rand . $type;
					$img_dir = $image_path."logo/".date('Ymd',TIMESTAMP).'/';
					if (!is_dir($img_dir)) {
						mkdir($img_dir);
					}
					$brand_bg = $img_dir. $pics;
					if(@copy($_FILES['brand_bg']['tmp_name'], $brand_bg)||@move_uploaded_file($_FILES['brand_bg']['tmp_name'], $brand_bg)){
						if($_G['cache']['plugin']['aljbd']['iswatermark']){
							$image->Watermark(DISCUZ_ROOT.'./'.$brand_bg,'', 'forum');
						}
                        if (file_exists($brand_bg)) {
                            if($_G['cache']['plugin']['aljoss']['Access_Key']){
                                $brand_bg = T::oss($brand_bg, 'aljbd');
                            }
                        }
						@unlink($_FILES['brand_bg']['tmp_name']);
					}
				}
			}
		}else{
			if ($_GET['brand_bg']) {
                if (strpos($_GET['brand_bg'],"base64") === false) {
                    $brand_bg = $_GET['brand_bg'];
                } else {
                    unlink($bd['brand_bg']);
                    T::delete_oss($bd['brand_bg']);
                    $brand_bg = T::saveimg($_GET['brand_bg'],$image_path.'logo/');
                }
			}
		}
		$insertarray=array(
			'name'=>$_GET['name'],
			'tel'=>$_GET['tel'],
			'addr'=>$_GET['addr'],
			'intro'=>$_GET['intro'],
			'other'=>$_GET['other'],
			'type'=>$_GET['type'],
			'subtype'=>$_GET['subtype'],
			'subtype3'=>$_GET['subtype3'],
			'region'=>$_GET['region'],
			'region1'=>$_GET['region1'],
			'subregion'=>$_GET['subregion'],
			'qq'=>$_GET['qq'],
			'gg'=>$_GET['gg'],
			'wurl'=>$_GET['wurl'],
			'wangwang'=>$_GET['wangwang'],
			'weixin_id'=>$_GET['weixin_id'],
			'business_hours'=>$_GET['business_hours'],
			'bus_routes'=>$_GET['bus_routes'],
			'displayorder'=>$_GET['displayorder'],
			'fare_type'=>$_GET['fare_type'],
			'postal_amount'=>$_GET['postal_amount'],
			'hide_tel'=>$_GET['hide_tel'],
			'label'=>$_GET['label'],
			'x'=>$xy[0],
			'y'=>$xy[1],
			'businesstype'=>implode(',', $_GET['businesstype']),
        );
        if($_G['cache']['plugin']['aljpps']['is_aljbd']){
            $insertarray['platform_distribution'] = $_GET['platform_distribution'];
        }
		if($bd){
			if($logo){
                
				$insertarray['logo']=$logo;
            }
            if($brand_bg){
                
				$insertarray['brand_bg']=$brand_bg;
			}
			//����Ա�༭�̼�VIP�ȼ�
            if($administrators){
                $vipid = intval($_GET['vipid']);
                if($bd['vipid'] != $vipid){
                    $insertarray['vipid'] = $vipid;
                    $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$vipid));
                    if($vipdata){
                        if($vipdata['day'] == 0){
                            $insertarray['vipendtime'] = 0;
                        }else{
                            $insertarray['vipendtime'] = TIMESTAMP + ($vipdata['day'] * 86400);
                        }
                    }
                }
                $insertarray['status'] = $_GET['status'];
            }else if ($bd['status'] == 3){
                $insertarray['status'] = 0;
            }
            //���ͼPC
            if($_GET['compress'] == '1'){
                for($i=1;$i<=3;$i++){
                    if($_FILES['adv']['tmp_name'][$i]) {
                        $picname = $_FILES['adv']['name'][$i];
                        $picsize = $_FILES['adv']['size'][$i];

                        if ($picname != "") {
                            $type = strtolower(strrchr($picname, '.'));
                            if ($type != ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
                                showerror(lang('plugin/aljbd','s25'));
                            }
                            if (($picsize/1024)>$_G['cache']['plugin']['aljbd']['img_size']) {
                                showerror(lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB');
                            }
                            $rand = rand(100, 999);
                            $pics = date("YmdHis") . $rand . $type;

                            $dir=$image_path.'adv/'.date('Ymd',TIMESTAMP).'/';
                            if(!is_dir($dir)) {
                                @mkdir($dir, 0777);
                            }
                            $adv[$i] = $dir. $pics;
                            if(@copy($_FILES['adv']['tmp_name'][$i], $adv[$i])||@move_uploaded_file($_FILES['adv']['tmp_name'][$i], $adv[$i])){
                                if (file_exists($adv[$i])) {
                                    if($_G['cache']['plugin']['aljoss']['Access_Key']){
                                        $adv[$i] = T::oss($adv[$i], 'aljbd');
                                    }
                                }
                                @unlink($_FILES['adv']['tmp_name'][$i]);
                            }
                        }
                    }else{
                        $adv[$i] = $_GET['adv'][$i];
                    }
                }
            }else{
                $badv=unserialize($bd['adv']);
                for($i=1;$i<=3;$i++){
                    if ($_GET['adv'.$i]) {
                        if(strpos($_GET['adv'.$i],$oss_domain) !== false){
                            $adv[$i] = $_GET['adv'.$i];
                        }else if (is_file($_GET['adv'.$i])) {
                            $adv[$i] = $_GET['adv'.$i];
                        } else {
                            unlink($badv[$_GET['adv'.$i]]);
                            T::delete_oss($badv[$_GET['adv'.$i]]);
                            $adv[$i] = T::saveimg($_GET['adv'.$i],$image_path.'adv/');
                        }
                    }
                }
            }




            $insertarray['advurl'] = serialize($_GET['advurl']);
            $insertarray['adv'] = serialize($adv);
            //C::t('#aljbd#aljbd')->update($bid,array('advurl'=>serialize($_GET['advurl']),'adv'=>serialize($adv)));
            //���ͼPC
            //�ֻ����ͼ
            if($_GET['compress'] == '1'){
                for($i=1;$i<=3;$i++){

                    if($_FILES['madv']['tmp_name'][$i]) {
                        $picname = $_FILES['madv']['name'][$i];
                        $picsize = $_FILES['madv']['size'][$i];

                        if ($picname != "") {
                            $type = strtolower(strrchr($picname, '.'));
                            if ($type != ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
                                showerror(lang('plugin/aljbd','s25'));
                            }
                            if (($picsize/1024)>$_G['cache']['plugin']['aljbd']['img_size']) {
                                showerror(lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB');
                            }
                            $rand = rand(100, 999);
                            $pics = date("YmdHis") . $rand . $type;

                            $dir=$image_path.'adv/'.date('Ymd',TIMESTAMP).'/';
                            if(!is_dir($dir)) {
                                @mkdir($dir, 0777);
                            }
                            $madv[$i] = $dir. $pics;
                            if(@copy($_FILES['madv']['tmp_name'][$i], $madv[$i])||@move_uploaded_file($_FILES['madv']['tmp_name'][$i], $madv[$i])){
                                if (file_exists($madv[$i])) {
                                    if($_G['cache']['plugin']['aljoss']['Access_Key']){
                                        $madv[$i] = T::oss($madv[$i], 'aljbd');
                                    }
                                }
                                @unlink($_FILES['madv']['tmp_name'][$i]);
                            }
                        }
                    }else{
                        $madv[$i] = $_GET['madv'][$i];
                    }
                    
                }

            }else{
                
                $mbadv=unserialize($bd['madv']);
                for($i=1;$i<=3;$i++){
                    if ($_GET['madv'.$i]) {
                        if(strpos($_GET['madv'.$i],$oss_domain) !== false){
                            $madv[$i] = $_GET['madv'.$i];
                        }else if (is_file($_GET['madv'.$i])) {
                            $madv[$i] = $_GET['madv'.$i];
                        } else {
                            unlink($mbadv[$_GET['madv'.$i]]);
                            T::delete_oss($badv[$_GET['madv'.$i]]);
                            $madv[$i] = T::saveimg($_GET['madv'.$i],$image_path.'adv/');
                        }
                    }
                }
            }

            
            //C::t('#aljbd#aljbd')->update($bid,array('madvurl'=>serialize($_GET['madvurl']),'madv'=>serialize($madv)));
            $insertarray['madvurl'] = serialize($_GET['madvurl']);
            $insertarray['madv'] = serialize($madv);
            //�ֻ����ͼ
			C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd)->update($bid,$insertarray);
            $return_url = 'plugin.php?id=aljht&act=admin&op=brand'.$urlmod;
		}else{
			$insertarray['dateline'] = TIMESTAMP;
			$insertarray['status'] = $status;
            if($administrators && $_GET['uid']>0){
                $insertarray['uid'] = $_GET['uid'];
                $user = getuserbyuid($_GET['uid']);
                $insertarray['username'] = $user['username'];
            }else{
                $insertarray['username'] = $_G['username'];
                $insertarray['uid'] = $_G['uid'];
            }
			$insertarray['logo']=$logo;
			$insertarray['brand_bg']=$brand_bg;
            if($_GET['vipid'] == 'jhm'){
                $_GET['card_number'] = $_GET['activation_code'];
                $card = DB::fetch_first('select * from %t where card_number=%s and card_service_id = 1 and used = 0 and dateline+card_day_num*86400>%d', array('aljac_card', $_GET['card_number'], TIMESTAMP)); //�ж��û�����ļ������Ƿ���Ч
                if(!$card){
                    echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_php_10')."','');</script>";
                    exit;
                }
                
                $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$card['card_vip_id']));
                
                if(!$vipdata){
                    echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_php_10')."','');</script>";
                    exit;
                }
                if(DB::query('update %t set used = 1, used_time=%d,uid=%d,username=%s where id = %d', array('aljac_card', TIMESTAMP, $_G['uid'], $_G['username'], $card['id']))){//����������Ϊ��ʹ�ò�����ʹ��ʱ��
                    DB::query('update %t set unused_card_num = unused_card_num-1,  used_card_num = used_card_num+1 where id=%d', array('aljac_card_type', $card['card_type']));  //��������ʹ��+1 δʹ��-1
                    if($vipdata['day'] == 0){
                        $insertarray['vipendtime'] = 0;
                    }else{
                        $insertarray['vipendtime'] = TIMESTAMP + ($vipdata['day'] * 86400);
                    }
                    $insertarray['vipid'] = $vipdata['id'];
                    $insertid =C::t('#aljbd#aljbd')->insert($insertarray, true);
                    $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
                    $orderarray=array(
                        'orderid' => $orderid,
                        'status' => 2,
                        'uid' => $_G['uid'],
                        'username' => $_G['username'],
                        'price' => $vipdata['price'],
                        'submitdate' => $_G['timestamp'],
                        'remarks' => $vipdata['day'].'/'.$vipdata['price'].'_'.$_GET['activation_code'],
                        'stitle' => $card['id'].'_'.lang('plugin/aljbd','aljbd_php_11').'-'.$_GET['name'],
                        'payment' => 7,
                        'pid'  => 3,//�̼�
                        'browser'  => $_SERVER['HTTP_USER_AGENT'],
                    );
                    $orderarray['fare_desc'] = $vipdata['id'];
                    if($_G['mobile']){//1���ֻ���2��PC
                        $orderarray['mobile'] = 1;
                    }else{
                        $orderarray['mobile'] = 2;
                    }
                    $orderarray['shop_id'] = $insertid;
                    $orderarray['status'] = 2;
                    
                    C::t('#aljbdx#aljbd_goods_order')->insert($orderarray);
                }else{
                    echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_php_10')."','');</script>";
                    exit;
                }
                if($settings['post_brand_type']['value'] > 0){
                    $return_url =  rtrim($qbapi->siteurl, '/').'/'.'plugin.php?id=aljht&act=admin&op=attestation&do=addattestation&bid='.$insertid;
                }else{
                    $return_url = rtrim($qbapi->siteurl, '/').'/'.'plugin.php?id=aljht&act=admin&op=brand&do=edit&bid='.$insertid;
                }
            }else{
                $vipid = intval($_GET['vipid']);
                $insertarray['vipid'] = $vipid;
                $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$vipid));
                if($vipdata && $_G['cache']['plugin']['aljbdx']['is_aljqb']){

                    $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
                    $orderarray=array(
                        'orderid' => $orderid,
                        'status' => 1,
                        'uid' => $_G['uid'],
                        'username' => $_G['username'],
                        'price' => $vipdata['price'],
                        'submitdate' => $_G['timestamp'],
                        'remarks' => $vipdata['day'].'/'.$vipdata['price'],
                        'stitle' => lang('plugin/aljbd','attend_php_1').'-'.$_GET['name'],
                        'payment' => 7,
                        'pid'  => 3,
                        'browser'  => $_SERVER['HTTP_USER_AGENT'],
                    );
                    $orderarray['fare_desc'] = $vipid;
                    if($_G['mobile']){//1���ֻ���2��PC
                        $orderarray['mobile'] = 1;
                    }else{
                        $orderarray['mobile'] = 2;
                    }
                    if($_GET['couponid'] && $_G['cache']['plugin']['aljsyh']['is_aljsyh']){
                        $clogdata = DB::fetch_first('select * from %t a left join %t b on a.cid=b.id where a.status=1 and a.uid=%d and a.id=%d',array('aljsyh_consume_log','aljbd_consume',$_G['uid'],intval($_GET['couponid'])));

                        if($clogdata){
                            $vipdata['price'] = $vipdata['price']-$clogdata['reduction'];
                        }
                        if(DB::update('aljsyh_consume_log',array('status'=>2),array('id'=>intval($_GET['couponid']),'status'=>1))){
                            $orderarray['cid']=intval($_GET['couponid']);
                            $orderarray['discount']=$clogdata['reduction'];
                        }
                    }

                    if($vipdata['price']>0 && !$administrators){
                        $insertarray['status'] = 2;
                        $insertarray['price'] = $vipdata['price'];
                        //$insertarray['orderid'] = $orderid;
                        $insertid =C::t('#aljbd#aljbd')->insert($insertarray, true);
                        $orderarray['shop_id'] = $insertid;
                        C::t('#aljgwc#aljbd_goods_order')->insert($orderarray);
                        //$url = 'plugin.php?id=aljbdx&act=pay&bid='.$insertid;
                        require_once 'source/plugin/aljqb/class/Qbapi.class.php';
                        $qbapi = new Qbapi();
                        if($settings['post_brand_type']['value'] > 0){
                            $return_url =  rtrim($qbapi->siteurl, '/').'/'.'plugin.php?id=aljht&act=admin&op=attestation&do=addattestation&bid='.$insertid;
                        }else{
                            $return_url = rtrim($qbapi->siteurl, '/').'/'.'plugin.php?id=aljht&act=admin&op=brand&do=edit&bid='.$insertid;
                        }
                        $keyurlarray = array(
                            'orderid' => $orderid,
                            'time' => TIMESTAMP,
                            'price' => $vipdata['price'],
                            'keyname' => 'aljbdx_rz',
                            'return_url' => $return_url,
                            'key' => $_G['cache']['plugin']['aljbdx']['qb_key'],
                        );
                        $url = $qbapi -> createUrl($keyurlarray);
                        echo "<script>parent.location.href='" .$url . "';</script>";
                        exit;
                    }else{


                        if($vipdata['day'] == 0){
                            $insertarray['vipendtime'] = 0;
                        }else{
                            $insertarray['vipendtime'] = TIMESTAMP + ($vipdata['day'] * 86400);
                        }

                        $insertid =C::t('#aljbd#aljbd')->insert($insertarray, true);
                        $orderarray['shop_id'] = $insertid;
                        if($settings['post_brand_type']['value'] > 0){
                            $return_url =  'plugin.php?id=aljht&act=admin&op=attestation&do=addattestation&bid='.$insertid;
                        }else{
                            $return_url = 'plugin.php?id=aljht&act=admin&op=brand&do=edit&bid='.$insertid;
                        }
                        //����Ա�����̼Ҳ����շ�
                        if($administrators){
                            $orderarray['stitle'] = lang("plugin/aljht","brand_php_14");
                            $orderarray['price'] = 0;
                            $return_url = 'plugin.php?id=aljht&act=admin&op=brand'.$urlmod;
                        }
                        $orderarray['status'] = 2;
                        C::t('#aljgwc#aljbd_goods_order')->insert($orderarray);
                    }
                }else{

                    if($_G['cache']['plugin']['aljbdx']['is_aljqb'] && $_G['cache']['plugin']['aljbdx']['adddp_price'] && !$administrators){

                        $insertarray['status'] = 2;
                        $insertarray['price'] = $_G['cache']['plugin']['aljbdx']['adddp_price'];
                        $insertid =C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd)->insert($insertarray, true);
                        $url = '/plugin.php?id=aljbdx&act=pay&bid='.$insertid;
                        require_once 'source/plugin/aljqb/class/Qbapi.class.php';
                        $qbapi = new Qbapi();
                        echo "<script>parent.location.href='".rtrim($qbapi->siteurl, '/').'/'.$url . "';</script>";
                        exit;
                    }else{
                        $insertid =C::t('#aljbd#aljbd')->insert($insertarray, true);
                        if($_G['cache']['plugin']['aljbd']['money']&&$_G['cache']['plugin']['aljbd']['money_lx']&& !$_G['cache']['plugin']['aljbdx']['is_aljqb']){
                            updatemembercount($_G['uid'], array($_G['cache']['plugin']['aljbd']['money_lx'] => '-' . $_G['cache']['plugin']['aljbd']['money']));
                        }
                        $return_url = 'plugin.php?id=aljht&act=admin&op=brand'.$urlmod;
                    }
                }
            }

			//$insertid =C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd)->insert($insertarray, true);
			$bid = $insertid;

			if(!in_array($_G['groupid'],unserialize($_G['cache']['plugin']['aljbd']['mgroups'])) && $do == 'adddp'){
				$groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
				foreach($groupids as $g_uid){
					notification_add($g_uid['uid'], 'system','<a href="plugin.php?id=aljhtx&c=aljbd&a=order&type=5&do=no">'.lang('plugin/aljbd','n_add_tips').'</a>',array('from_idtype'  => 'aljbd_brand','from_id' => $insertid));
				}
			}
		}
		if($bd){
            savecache('aljbd_rec_brand', '');//�Ƽ��̼� �����ÿ�
			echo '<script>parent.tips("'.lang("plugin/aljht","brand_php_2").'","'.$return_url.'");</script>';
			exit;
		}else{
			if($administrators){
				echo '<script>parent.tips("'.lang('plugin/aljbd','mgroups').'","'.$return_url.'");</script>';
				exit;
			}else{
				echo '<script>parent.tips("'.lang('plugin/aljbd','s20').'","'.$return_url.'");</script>';
				exit;
			}
		}
	}else{
		if($bd['uid']!=$_G['uid'] && $do == 'edit' && !$administrators){
            $aljht_tips = lang('plugin/aljbd','s20');
            include template('aljht:admin/pogressbar');
            exit;
		}
        if($do == 'adddp'){
            if($_G['cache']['plugin']['aljsyh']['is_aljsyh']){
                $discount = DB::fetch_all('select a.id,b.full,b.reduction,b.coupon_type from %t a left join %t b on a.cid=b.id where (b.end>%s || b.end=0) and b.coupon_type=9 and a.status=%d and a.uid=%d order by b.reduction desc',array('aljsyh_consume_log','aljbd_consume', TIMESTAMP,1,$_G['uid']));
                foreach($discount as $dk => $kv){
                    $discount[$dk]['full'] = floatval($kv['full']);
                    $discount[$dk]['reduction'] = floatval($kv['reduction']);
                }
            }
        }
		$typelist=C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type')->fetch_all_by_upid(0);
		$rlist=C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_region')->fetch_all_by_upid();
		$adv=unserialize($bd['adv']);
		$advurl=unserialize($bd['advurl']);
		$madv=unserialize($bd['madv']);
		$madvurl=unserialize($bd['madvurl']);
		include template($pluginid.':admin/brand/adddp');
	}
}elseif($do == 'btype'){
    $store_id = intval($_GET['store_id']);
    if(submitcheck('formhash')){
        $name = $_GET['name'];
        
        $newkey = $_GET['newkey'];
        $newvalue = $_GET['newvalue'];
        $newcat = $newkey;
        $newsubcat = $newvalue;
        if(is_array($name)) {
            foreach($name as $id=>$value) {
                C::t('#aljht#aljbd_type_brand')->update($id,array('subject'=>$value));
            }
        }
        $sname = $_GET['sname'];
        if(is_array($sname)) {
            foreach($sname as $id=>$value) {
                C::t('#aljht#aljbd_type_brand')->update($id,array('subject'=>$value));
            }
        }
        if(is_array($newcat)) {
            foreach($newcat as $key=>$name) {
                if(empty($name)) {
                    continue;
                }
                $cid=C::t('#aljht#aljbd_type_brand')->insert(array('bid' => $bid, 'store_id' => $store_id, 'type' => $store_id>0?1:0, 'upid' => '0', 'subject' => $name, 'displayorder' => $newcatorder[$key]),1);
            }
        }

        if(is_array($newsubcat)) {
            foreach($newsubcat as $cid=>$subcat) {
                $sub=C::t('#aljht#aljbd_type_brand')->fetch($cid);
                $subtype =$sub['subid'];
                foreach($subcat as $key=>$name) {
                    $subid=C::t('#aljht#aljbd_type_brand')->insert(array('bid' => $bid, 'store_id' => $store_id, 'type' => $store_id>0?1:0,'upid' => $cid, 'subject' => $name, 'displayorder' => $newsuborder[$cid][$key]),1);
                    $subtype .= $subtype ? ','.$subid : $subid;
                }
                C::t('#aljht#aljbd_type_brand')->update($cid,array('subid'=>$subtype));
            }
        }
        echo '<script>parent.location.href="plugin.php?id=aljht&act=admin&op=brand&do=btype'.$urlmod.'&bid='.$bid.'&store_id='.$store_id.'";</script>';
        exit;
    }else{
        $currpage=intval($_GET['page'])?intval($_GET['page']):1;
        $perpage=50;
        $start=($currpage-1)*$perpage;
        if($store_id>0){
            $where = ' and store_id='.$store_id.' and type=1';
        }else{
            $where = ' and type=0';
        }
        $num = DB::result_first('select count(*) from %t where bid=%d and upid=0'.$where,array('aljbd_type_brand',$bid));
        $btype = DB::fetch_all('select * from %t where bid=%d  and upid=0 '.$where,array('aljbd_type_brand',$bid,$start,$perpage));
        $navtitle = lang("plugin/aljht","brand_php_15");
        include template($pluginid.':admin/brand/btype');
    }
}elseif($do == 'del_btype'){
    $store_id = intval($_GET['store_id']);
    $del_brand = C::t('#aljbd#aljbd')->fetch($bid);
    if(($_GET['formhash'] == formhash() && $del_brand['uid'] == $_G['uid']) || $administrators){
        if($_GET['type'] == 1 && $_GET['symbol']){
            C::t('#aljht#aljbd_type_brand')->delete($_GET['symbol']);
        }elseif($_GET['tid']){
            C::t('#aljht#aljbd_type_brand')->delete($_GET['tid']);
            DB::query('delete from %t where upid = %d',array('aljbd_type_brand',$_GET['tid']));
        }
    }
    echo '<script>parent.location.href="plugin.php?id=aljht&act=admin&op=brand&do=btype'.$urlmod.'&bid='.$bid.'&store_id='.$store_id.'";</script>';
    exit;
}elseif($do == 'breply'){
	$currpage=intval($_GET['page'])?intval($_GET['page']):1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	$num=C::t('#aljbd#aljbd_comment')->count_by_bid_all($bid);
	$commentlist=C::t('#aljbd#aljbd_comment')->fetch_all_by_bid_page($bid,$start,$perpage);
	$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=commentlist&bid='.$bid, 0, 11, false, false);
	include template($pluginid.':admin/brand/commentlist');
}elseif($do == 'winfolist'){
	$currpage=intval($_GET['page'])?intval($_GET['page']):1;
    $perpage=1;

    $num=C::t('#aljbd#aljbd_winfo')->count_by_bid($bid);
    if(@ceil($num/$perpage) < $currpage && $no_max_page){
        $currpage=1;
    }
    $start=($currpage-1)*$perpage;
    $winfolist=C::t('#aljbd#aljbd_winfo')->fetch_all_by_bid($bid,$start,$perpage);
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=winfolist&bid='.$bid, 0, 11, false, false);
	include template($pluginid.':admin/brand/winfolist');
}elseif($do == 'reply'){
    if(!$administrators){
        $aljht_tips = lang("plugin/aljht","brand_php_16");
        include template('aljht:admin/pogressbar');
        exit;
    }
    $currpage=$_GET['page']?intval($_GET['page']):1;
    $perpage=20;
    $start=($currpage-1)*$perpage;
    $keyword = addcslashes($_GET['search'], '%_');
    if(submitcheck('formhash') && empty($keyword)) {
        if ($_GET['sign'] == 1) {
            if (is_array($_GET['delete'])) {
                foreach ($_GET['delete'] as $k => $id) {
                    DB::query('update %t set status=1  where id = %d', array('aljbd_comment', $id));
                }
            }
        } else if ($_GET['sign'] == 2) {
            if (is_array($_GET['delete'])) {
                foreach ($_GET['delete'] as $k => $id) {
                    DB::query('update %t set rubbish=1  where id = %d', array('aljbd_comment', $id));
                }
            }
        } else {
            if (is_array($_GET['delete'])) {
                foreach ($_GET['delete'] as $k => $id) {
                    DB::query('update %t set status=0  where id = %d', array('aljbd_comment', $id));
                }
            }
        }
        echo '<script>parent.tips(0);</script>';
        exit;
    }
    $businesstype = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljbd']['businesstype']));
    foreach($businesstype as $key=>$value){
        $arr=explode('=',$value);
        $businesstypearr[$arr[0]]=$arr[1];
        $busarr[$arr[0]]=diconv($arr[1],CHARSET,'UTF-8');;
    }
    $currpage=intval($_GET['page'])?intval($_GET['page']):1;
    $perpage=20;
    $start=($currpage-1)*$perpage;
    $con[]='aljbd_comment';
    $where = 'where rubbish=0';
    if($_GET['bid']){
        $con[]=$_GET['bid'];
        $where.=' and bid=%d';
    }
    if($_GET['search']){
        $con[] ='%' . $keyword . '%';
        $where.=" and content like %s";
    }
    $num=DB::result_first('select count(*) from %t '.$where,$con);
    $where.=" order by status desc,id desc limit %d,%d";
    $con[]= $start;
    $con[]= $perpage;
    $commentlist=DB::fetch_all('select * from %t '.$where,$con);
    $pagingurl = getaljurl($geturl,'');
    $paging = _mall_paging($currpage,$num,$perpage,$pagingurl.'&page=');
    include template($pluginid.':admin/brand/replylist');
}elseif($do == 'dreply'){
	if($_GET['cid']){
		$del_bd=C::t('#aljbd#aljbd')->fetch($bid);
		if($del_bd['uid'] == $_G['uid'] || $administrators){
			C::t('#aljbd#aljbd_comment')->delete($_GET['cid']);
		}
		echo 1;
		exit;
	}
}else if($do=='iwantclaim'){
	$bd=C::t('#aljbd#aljbd')->fetch($bid);
	if(submitcheck('formhash') && ($bd['uid'] == $_G['uid'] || $administrators)){
		if(empty($_GET['name'])){
			echo "<script>parent.tips('".lang('plugin/aljbd','s47')."','');</script>";
			exit;
		}
		$user=C::t('common_member')->fetch_by_username($_GET['name']);
		if(empty($user)){
			echo "<script>parent.tips('".lang('plugin/aljbd','s48')."','');</script>";
			exit;
		}
		
		C::t('#aljbd#aljbd')->update($_GET['bid'],array('uid'=>$user['uid'],'username'=>$_GET['name']));//�̼�
		DB::update('aljbd_album',array('uid'=>$user['uid'],'username'=>$_GET['name']),'bid='.$_GET['bid']);//���
		DB::update('aljbd_album_attachments',array('uid'=>$user['uid']),'bid='.$_GET['bid']);
		DB::update('aljbd_consume',array('uid'=>$user['uid'],'username'=>$_GET['name']),'bid='.$_GET['bid']);//�Ż�ȯ
		DB::update('aljbd_notice',array('uid'=>$user['uid'],'username'=>$_GET['name']),'bid='.$_GET['bid']);//����
		DB::update('aljbd_goods',array('uid'=>$user['uid']),'bid='.$_GET['bid']);//��Ʒ
		DB::update('aljbd_page',array('uid'=>$user['uid'],'username'=>$_GET['name']),'bid='.$_GET['bid']);//�����ڵ���
		$is_plugin = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljsp'));
		if($is_plugin){
			DB::update('aljbd_video',array('uid'=>$user['uid'],'username'=>$_GET['name']),'bid='.$_GET['bid']);//�̼���Ƶ
		}
		if($is_plugin_js){
			DB::update('aljjs_brandsettle',array('uid'=>$user['uid']),'bid='.$_GET['bid']);//����
		}
		echo '<script>parent.tips("'.lang('plugin/aljbd','s49').'");</script>';
		exit;
	}
}else if($do == 'viptime'){
    $bd = C::t('#aljbd#aljbd') -> fetch($bid);
    if($bd['vipid']){
        $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$bd['vipid']));
    }
    if(submitcheck('formhash')) {
        if(strtotime($_GET['vipendtime']) > TIMESTAMP){
            DB::query('update %t set vipendtime=%d,vipid=%d where id = %d',array('aljbd',strtotime($_GET['vipendtime']),$_GET['vipid'],$bid));
        }else{
            DB::query('update %t set vipid=%d where id = %d',array('aljbd',$_GET['vipid'],$bid));
        }
        echo '<script>parent.tips("'.lang("plugin/aljht","brand_php_3").'");</script>';
		exit;
    }else{
        include template($pluginid.':admin/brand/viptime');
    }
}else{
    if($_G['mobile']){
        header('location: plugin.php?id=aljbd&act=member');
        exit;
    }
	$keyword = addcslashes($_GET['search'], '%_');
	if(submitcheck('formhash') && empty($keyword)){
        savecache('aljbd_rec_brand', '');//�Ƽ��̼� �����ÿ�
        if($administrators){//����Ա
			if(is_array($_GET['displayorder'])) {
				foreach($_GET['displayorder'] as $k => $id) {
					DB::query('update %t set displayorder=%d  where id = %d',array('aljbd',$id,$k));
				}
			}
			if($_GET['sign'] == 1){
				if(is_array($_GET['delete'])) {
                    $send_goods_tips = $_G['cache']['plugin']['aljbd']['refusetips'].'{reason}';
                    
                    foreach($_GET['delete'] as $k => $id) {
						
                        $reason = $_GET['reason'][$id] ? lang("plugin/aljht","brand_php_18").$_GET['reason'][$id] : '';
                        $brand = C::t('#aljbd#aljbd')->fetch($id);
                        //debug(str_replace(array('{shopname}','{username}','{reason}'),array($brand['name'],$brand['username'],$reason),$send_goods_tips));
                        DB::query('update %t set status=3,reason=%s  where id = %d',array('aljbd',$_GET['reason'][$id],$id));
                        
                        notification_add($brand['uid'], 'system',str_replace(array('{shopname}','{username}','{reason}'),array($brand['name'],$brand['username'],$reason.'<a href="plugin.php?id=aljht&act=admin&op=brand&mod=my" target="_blank">'.lang("plugin/aljht","brand_php_17").'</a>'),$send_goods_tips),array('from_idtype'  => 'aljbd_brand','from_id' => $brand['id']));
                        if($_G['cache']['plugin']['aljbd']['time']){
                            $email_first=C::t("common_member")->fetch($brand['uid']);
                            $email=$email_first['email'];
                            if($email_first['email']){
                                $m=str_replace(array('{shopname}','{username}','{reason}'),array($brand['name'],$brand['username'],$reason.'<a href="'.$_G['siteurl'].'/plugin.php?id=aljht&act=admin&op=brand&mod=my" target="_blank">'.lang("plugin/aljht","brand_php_17").'</a>'),$send_goods_tips);
                                newsendmail_cron($email,$_G['cache']['plugin']['aljbd']['mailtitle'],$m);
                            }
                        }
                        unset($brand);
                        unset($email_first);
                        unset($reason);
					}
				}
			}else if($_GET['sign'] == 3){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						DB::query('update %t set recommend=1  where id = %d',array('aljbd',$id));
                        $brand = C::t('#aljbd#aljbd')->fetch($id);
                        notification_add($brand['uid'], 'system',str_replace('{username}',$brand['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=view&bid='.$id.'">'.$brand['name'].'</a>',$_G['cache']['plugin']['aljbd']['shoptips'])),array('from_idtype'  => 'aljbd_brand','from_id' => $brand['id']));
                        if($_G['cache']['plugin']['aljbd']['time']){
                            $email_first=C::t("common_member")->fetch($brand['uid']);
                            $email=$email_first['email'];

                            if($email_first['email']){
                                $m=str_replace('{username}',$brand['username'],str_replace('{shopname}','<a href="'.$_G['siteurl'].'/plugin.php?id=aljbd&act=view&bid='.$id.'">'.$brand['name'].'</a>',$_G['cache']['plugin']['aljbd']['shoptips']));
                                newsendmail_cron($email,$_G['cache']['plugin']['aljbd']['mailtitle'],$m);
                            }
                        }
                        unset($brand);
                        unset($email_first);
                    }
				}
			}else if($_GET['sign'] == 4){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						DB::query('update %t set recommend=0  where id = %d',array('aljbd',$id));
                    }
				}
			}else if($_GET['sign'] == 2){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						del_brand_all($id,1);
                    }
				}
			}else if($_GET['sign'] == 6){
                if(is_array($_GET['delete'])) {
                    foreach($_GET['delete'] as $k => $id) {
                        close_brand_all($id,1);
                    }
                }
            }else if($_GET['sign'] == 7){
                if(is_array($_GET['delete'])) {
                    foreach($_GET['delete'] as $k => $id) {
                        close_brand_all($id,4);
                    }
                }
            }else{
				if(is_array($_GET['delete'])) {
                    $send_goods_tips = $_G['cache']['plugin']['aljbd']['passtips'].'{reason}';
					foreach($_GET['delete'] as $k => $id) {
                        $brand = C::t('#aljbd#aljbd')->fetch($id);
                        $reason = $_GET['reason'][$id] ? lang("plugin/aljht","brand_php_20").$_GET['reason'][$id] : '';
                        DB::query('update %t set status=1,reason=%s  where id = %d',array('aljbd',$_GET['reason'][$id],$id));
                        notification_add($brand['uid'], 'system',str_replace(array('{shopname}','{username}','{reason}'),array($brand['name'],$brand['username'],$reason.'<a href="plugin.php?id=aljht&act=admin&op=brand&mod=my" target="_blank">'.lang("plugin/aljht","brand_php_19").'</a>'),$send_goods_tips),array('from_idtype'  => 'aljbd_brand','from_id' => $goods['id']));
                        if($_G['cache']['plugin']['aljbd']['time']){
                            $email_first=C::t("common_member")->fetch($brand['uid']);
                            $email=$email_first['email'];

                            if($email_first['email']){
                                $m=str_replace(array('{shopname}','{username}','{reason}'),array($brand['name'],$brand['username'],$reason.'<a href="'.$_G['siteurl'].'/plugin.php?id=aljht&act=admin&op=brand&mod=my" target="_blank">'.lang("plugin/aljht","brand_php_19").'</a>'),$send_goods_tips);
                                newsendmail_cron($email,$_G['cache']['plugin']['aljbd']['mailtitle'],$m);
                            }
                        }
                        unset($brand);
                        unset($email_first);
					}
				}
			}
		}else{
			if($_GET['sign'] == 2){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						del_brand_all($id,1);
					}
				}
			}else if($_GET['sign'] == 6){
                if(is_array($_GET['delete'])) {
                    foreach($_GET['delete'] as $k => $id) {
                        close_brand_all($id,1);
                    }
                }
            }else if($_GET['sign'] == 7){
                if(is_array($_GET['delete'])) {
                    foreach($_GET['delete'] as $k => $id) {
                        close_brand_all($id,4);
                    }
                }
            }
		}
		echo '<script>parent.tips(0);</script>';
		exit;
	}

	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=20;
	$start=($currpage-1)*$perpage;
	
	$con[]='aljbd';
	if($administrators){
        $where=" where rubbish=0";
        $no_num = DB::result_first('select count(*) from %t'. $where .' and status=0',$con);
	}else{
		$where=" where rubbish=0 and uid = %d";
		$con[] = $_G['uid'];
	}
	if($_GET['search']){
		$con[] ='%' . $keyword . '%';
		$where.=" and name like %s";
	}
	if($do == 'yes' || !$do){
		$where.=' and status=1';
	}else if($do == 'rec'){
		$where.=' and status=1 and recommend=1';
	}else if($do == 'no'){
		$where.=' and status=0';
	}else if($do == 'no_pay'){
        $where.=' and status=2';
    }else if($do == 'lose'){
        $where.=' and status=3';
    }else if($do == 'close'){
        $where.=' and status=4';
    }

	$num = DB::result_first('select count(*) from %t'.$where,$con);
	$con[]=$start;
	$con[]=$perpage;

	$pagingurl = getaljurl($geturl,'');
    $paging = _mall_paging($currpage,$num,$perpage,$pagingurl.'&page=');

    if($settings['brandlistorder']['value'] == 1){
        $orderby = ' ORDER BY recommend desc,displayorder desc,id desc';
    }else{
        $orderby = ' ORDER BY recommend desc,displayorder asc,id desc';
    }
    $bdlist = DB::fetch_all('SELECT * FROM %t '.$where.$orderby.' limit %d,%d',$con);
    $vipids = $bdids = array();
    foreach ($bdlist as $bk => $bv){
        if($bv['vipendtime']){
            if($bv['vipendtime'] > TIMESTAMP){
                
                $bdlist[$bk]['vipendtimes'] = dgmdate($bv['vipendtime'],'').lang('plugin/aljbd','member_php_1');
            }else{
                $bdlist[$bk]['vipendtimes'] = lang('plugin/aljbd','member_php_2');
            }
            if($administrators){//����Ա
                $bdlist[$bk]['vipendtimes'] .= '<a href="javascript:;" onclick="layer_iframe_viptime(\'plugin.php?id=aljht&act=admin&op=brand&do=viptime'.$urlmod.'&bid='.$bv['id'].'\',\''.lang("plugin/aljht","brand_php_21").'\');">'.lang("plugin/aljht","brand_php_22").'</a>';
            }
            
        }else if($bv['vipid'] && $bv['vipendtime']==0){
            $bdlist[$bk]['vipendtimes'] = lang('plugin/aljbd','member_php_3');
            if($administrators){//����Ա
                $bdlist[$bk]['vipendtimes'] .= '<a href="javascript:;" onclick="layer_iframe_viptime(\'plugin.php?id=aljht&act=admin&op=brand&do=viptime'.$urlmod.'&bid='.$bv['id'].'\',\''.lang("plugin/aljht","brand_php_23").'\');">'.lang("plugin/aljht","brand_php_24").'</a>';
            }
        }
        if($bv['vipid']){
            //$bdlist[$bk]['grouptitle'] = DB::result_first('select title from %t where id=%d',array('aljbd_vip',$bv['vipid']));
            $vipids[] = $bv['vipid'];
        }
        $u_name = getuserbyuid($bv['uid']);
        $bdlist[$bk]['username'] = $u_name['username'];
        $bdids[] = $bv['id'];
        unset($u_name);
    }
    
    if($bdids){
        $attestations  = DB::fetch_all('SELECT sign,bid FROM %t WHERE bid IN (%n)', array('aljbd_attestation', $bdids), 'bid');
        if($_G['cache']['plugin']['aljbzj']) {
            $bzjs = DB::fetch_all('SELECT price,bid FROM %t WHERE bid IN (%n)', array('aljbzj', $bdids), 'bid');
        }
        $vipinfos = DB::fetch_all('SELECT title,store_authority,id FROM %t WHERE id IN (%n)', array('aljbd_vip', $vipids), 'id');
        if(is_array($vipinfos) && $vipinfos){
            foreach($vipinfos as $v_k => $v_v){
                $vipinfos[$v_k][store_authority] =  explode(',',$v_v[store_authority]);
            }
        }
        $goodscounts = DB::fetch_all('select count(*) g_num,bid from %t where bid IN (%n) and commodity_type<4 and rubbish=0 group by bid',array('aljbd_goods',$bdids), 'bid');
        $noticecounts = DB::fetch_all('select count(*) n_num,bid from %t where bid IN (%n) and rubbish=0 group by bid',array('aljbd_notice',$bdids), 'bid');
        if($_G['cache']['plugin']['aljtyh']){
            $consumecounts = DB::fetch_all('select count(*) c_num,bid from %t where bid IN (%n) and rubbish=0 and store_id=0 group by bid',array('aljbd_consume',$bdids), 'bid');
        }else{
            $consumecounts = DB::fetch_all('select count(*) c_num,bid from %t where bid IN (%n) and rubbish=0 group by bid',array('aljbd_consume',$bdids), 'bid');
        }
        
        if($_G['cache']['plugin']['aljsp']){
            $videocounts = DB::fetch_all('select count(*) v_num,bid from %t where bid IN (%n) and rubbish=0 group by bid',array('aljbd_video',$bdids), 'bid');
        }
        $albumcounts = DB::fetch_all('select count(*) a_num,bid from %t where bid IN (%n) and rubbish=0 group by bid',array('aljbd_album',$bdids), 'bid');
        if($administrators){
            $replycounts = DB::fetch_all('select count(*) r_num,bid from %t where bid IN (%n) and rubbish=0 group by bid',array('aljbd_comment',$bdids), 'bid');
        }
    }

	//$bdlist = dhtmlspecialchars($bdlist);
	include template('aljht:admin/brand/brand');
}
//di'.'sm.t'.'aoba'.'o.com
?>