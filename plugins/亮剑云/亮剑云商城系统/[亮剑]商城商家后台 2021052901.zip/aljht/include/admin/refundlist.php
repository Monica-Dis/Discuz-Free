<?php
if(!$administrators){
    $refund_tips_no = lang("plugin/aljht","refundlist_php_2");
    $refund_tips_yes = lang("plugin/aljht","refundlist_php_3");
}else{
    $refund_tips_no = lang("plugin/aljht","refundlist_php_4");
    $refund_tips_yes = lang("plugin/aljht","refundlist_php_5");
}
if($_G['cache']['plugin']['aljbdx']['is_aljqb']){
    require_once 'source/plugin/aljqb/class/Qbapi.class.php';
    require_once 'source/plugin/aljqb/class/Queue.class.php';
    $queue = new Queue();
    $payment = new Qbapi();
    require_once 'source/plugin/aljqb/function/function_core.php';
    
    if(!$config['refundstatus'] && !$administrators){
        $refund_tips_no = lang("plugin/aljht","refundlist_php_6");
        $refund_tips_yes = lang("plugin/aljht","refundlist_php_7");
    }else{
        $refund_tips_no = lang("plugin/aljht","refundlist_php_8");
        $refund_tips_yes = lang("plugin/aljht","refundlist_php_9");
    }
}else if($is_plugin_gwc){
    require_once 'source/plugin/aljgwc/function/function_core.php';
}

if(submitcheck('formhash') && empty($keyword)){
    
    if($_GET['cz'] == 'jujue' && $administrators){
        
        $orderid = $_GET['orderid'];
        $_POST['delete'] = array($orderid);
        $_GET['sign'] = 1;
        $r_refund = C::t('#aljbdx#aljgwc_refund')->fetch($orderid);
        if(!$r_refund){
            $order = DB::fetch_first('select * from %t where orderid=%s',array('aljbd_goods_order',$orderid));
            if($order['payment'] == 6){
                C::t('#aljgwc#aljbd_goods_order')->update($orderid, array('status' => 7));
                if($_G['cache']['plugin']['aljbdx']){
                    DB::query("update %t set status=7 WHERE orderid=%s ",array('aljbd_goods_order_list',$orderid));
                }
                //notification_add($order['uid'],'system',lang("plugin/aljht","refundlist_php_14").' <a href="plugin.php?id=aljsqtg&a=orderView&orderid='.$orderid.'">'.'�鿴����'.'</a>');
                $array = array('code'=>100,'text'=>lang("plugin/aljht","refundlist_php_15"));
                echo json_encode(aljhtx::ajaxPostCharSet($array));
                exit;
            }
            
            $insertarray = array(
                'orderid' => $orderid,
                'shop_id' => $order[shop_id],
                'pid' => $pid,
                'payment' => $order['payment'],
                'price' => $order['price'],
                'goodsname' => $order['stitle'],
                'buyer' => $order['buyer'],
                'uid' => $order['uid'],
                'guid' => $shops['uid'],
                'username' => $order['username'],
                'imgs' => trim($imgs,','),
                'content' => lang("plugin/aljht","refundlist_php_16"),
                'refund_type' => 10,
                'addtime' => TIMESTAMP,
                'bd_info' => serialize($shops),
                'type' => $order['order_type'] == 7 ? 5 : 0,
            );
            
            
            C::t('#aljbdx#aljgwc_refund')->insert($insertarray);
        }
    }
    //debug($_POST['delete']);
    if($_GET['refundid']){
        $r_refund = C::t('#aljbdx#aljgwc_refund')->fetch($_GET['refundid']);
        if($r_refund){
            if($administrators){
                $_POST['delete'] = array($_GET['refundid']);
            }
        }
    }
    //0�̼Ҵ������˿� 1����Ա�������˿� 2�˿�ִ���� 3 �˿�ɹ� 4��ͬ���˿�
	if($_GET['sign'] == 1 || $_GET['sign'] == 2){
		if(is_array($_POST['delete'])) {
			$batch_no = dgmdate(TIMESTAMP,'Ymd').rand(100,99999999);
			$i = 0;
			foreach($_POST['delete'] as $oid) {
                $order = C::t('#aljgwc#aljgwc_refund')->fetch($oid);
                $pay_order = DB::fetch_first('select a.*,b.transaction_id,b.aljorderid from %t a left join %t b on a.buyer=b.aljorderid where a.orderid=%s',array('aljbd_goods_order','aljqb_payorder',$oid));
                $order['buyer'] = $pay_order['transaction_id'];
				if(($order['state'] == 1 || $order['state'] == 0 || $order['state'] == 2) && $administrators){
					if($_GET['sign'] == 1){
						DB::update('aljgwc_refund',array('state'=>2,'batch_no'=>$batch_no),"orderid='".$oid."'");
						if($order['payment'] == 1 || $order['payment'] == 3){
                            if(!$config['pem_location']){
                                if($_GET['getdata'] == 'yes'){
                                    $array = array('code'=>200,'text'=>lang("plugin/aljht","refundlist_php_1"));
                                    echo json_encode(aljhtx::ajaxPostCharSet($array));
                                }else{
                                    echo '<script>parent.tips("'.lang("plugin/aljht","refundlist_php_1").'");</script>';
                                }
                                exit;
                            }
							wx_refund_list($senddata,$oid,$order);
						}else if($order['payment'] == 7){
                            if($order['price']>0){
                                if($config['refundstype'] == 1){
                                    if($pay_order['admin'] == 'wxpay' || $pay_order['admin'] == 'APP'){
                                        wx_refund_list($senddata,$oid,$order);
                                    }else if($pay_order['admin'] == 'alipay'){
                                        alipay_refund_list($order,$oid);
                                    }else if($pay_order['admin'] == 'qianfanapp'){
                                        qianfanapp_refund_list($order,$oid,$pay_order);
                                    }else {
                                        refund_balance_list($order,$oid);
                                    }
                                }else{
                                    refund_balance_list($order,$oid);
                                }
                            }
                        }else{
							alipay_refund_list($order,$oid);
						}
					}else{
						DB::update('aljgwc_refund',array('state'=>4),"orderid='".$oid."'");
					}	
				}else{
					if($order['state'] == 0){
						if($_GET['sign'] == 1){
							if($config['refundstatus'] == '1'){//����
								DB::update('aljgwc_refund',array('state'=>2,'batch_no'=>$batch_no),"orderid='".$oid."'");
								if($order['payment'] == 1 || $order['payment'] == 3){
									wx_refund_list($senddata,$oid,$order);
								}else if($order['payment'] == 7){
                                    if($order['price']>0){
                                        if($config['refundstype'] == 1){
                                            if($pay_order['admin'] == 'wxpay' || $pay_order['admin'] == 'APP'){
                                                wx_refund_list($senddata,$oid,$order);
                                            }else if($pay_order['admin'] == 'alipay'){
                                                alipay_refund_list($order,$oid);
                                            }else if($pay_order['admin'] == 'qianfanapp'){
                                                qianfanapp_refund_list($order,$oid,$pay_order);
                                            }else {
                                                refund_balance_list($order,$oid);
                                            }
                                        }else{
                                            refund_balance_list($order,$oid);
                                        }
                                    }
                                }else{
									alipay_refund_list($order,$oid);
								}
							}else{
								DB::update('aljgwc_refund',array('state'=>1),"orderid='".$oid."'");
							}
						}else{
							DB::update('aljgwc_refund',array('state'=>4),"orderid='".$oid."'");
						}			
						//notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$order['sid'].'">'.$order['title'].'</a>',$config['fahuotips'])));
					}
				}
			}
		}
    }
    if($_GET['getdata'] == 'yes'){
        $array = array('code'=>100,'text'=>lang('plugin/aljht','attestation_php_1'));
        echo json_encode(aljhtx::ajaxPostCharSet($array));
    }else{
        echo '<script>parent.tips(0);</script>';
    }
	exit;
}

$currpage=$_GET['page']?intval($_GET['page']):1;
$perpage=10;
$start=($currpage-1)*$perpage;
$con[]='aljgwc_refund';
if($aljtsq_post_goods){//�ŵ��˿����
    if($administrators && $_GET[i] == 1){
        $where=" where pid=0 AND store_id > 0";
        if(empty($_GET['state'])){
            $_GET['state'] = 1;
        }
        if($_GET['state'] < 5){
            if($_GET['state'] == 1){
                $where.=" and state <= %d";
                $con[] = $_GET['state'];
            }else{
                $where.=" and state = %d";
                $con[] = $_GET['state'];
            }
        }
    }else{
        if($store_id > 0 && ($bd['tc_uid'] == $_G['uid'] || $administrators)){
            $where .= ' where store_id = %d';
            $con[] = $store_id;
        }else{
            $bdlist=C::t('#aljtsq#aljtsq_store')->fetch_all_by_where(array('status'=>1,'uid'=>$_G['uid']));//����
            
            foreach($bdlist as $b_id){
                $ids[] = $b_id['tc_id'];
            }
            $bids = implode(',',$ids);
            if(is_array($ids)){
                $where .= ' where store_id in(%i)';
                $con[] = $bids;
            }else{
                $where=" where guid = %d";
                $con[] = $_G['uid'];
            }
        }
        if($_GET['state'] < 5){
            $where.=" and state = %d";
            $con[] = $_GET['state'];
        }
    }
    
}else{
    if($administrators){
        $where=" where pid=0";
        if(empty($_GET['state'])){
            $_GET['state'] = 1;
        }
        if($_GET['state'] < 5){
            if($_GET['state'] == 1){
                $where.=" and state <= %d";
                $con[] = $_GET['state'];
            }else{
                $where.=" and state = %d";
                $con[] = $_GET['state'];
            }
        }
    }else{
       
        if($bid > 0 && $bd['uid'] == $_G['uid']){
            $where .= ' where shop_id = %d';
            $con[] = $bid;
        }else{
            $bids = DB::fetch_all('select id from %t where uid = %d',array('aljbd',$_G['uid']));
            foreach($bids as $b_id){
                $ids[] = $b_id['id'];
            }
            $bids = implode(',',$ids);
            if(is_array($ids)){
                $where .= ' where shop_id in(%i)';
                $con[] = $bids;
            }else{
                $where=" where guid = %d";
                $con[] = $_G['uid'];
            }
            
        }
        $where .= ' AND store_id=0 ';
        if($_GET['state'] < 5){
            $where.=" and state = %d";
            $con[] = $_GET['state'];
        }
    }
}
if($_G['cache']['plugin']['aljwm']){
    $where.=" and type != 1";
}
if($_GET['kw']){
    $keyword = addcslashes($_GET['kw'], '%_');
    $con[] ='%' . $keyword . '%';
    $con[] ='%' . $keyword . '%';
    $where.=" and (orderid like %s or goodsname like %s)";
}
$num = DB::result_first('select count(*) from %t'.$where,$con);
$con[]=$start;
$con[]=$perpage;
$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY addtime desc limit %d,%d',$con);
if($_GET['getdata'] == 'yes'){
    
    if($bdlist){
        
        foreach($bdlist as $b_k => $b_v){
            $order_cart=C::t('#aljgwc#aljbd_goods_order')->fetch($b_v[orderid]);
            $bdlist[$b_k]['addtime'] = dgmdate($b_v['addtime'],'u');
            $bdlist[$b_k]['bd_info'] = unserialize($b_v['bd_info']);
            $bdlist[$b_k]['gpic'] = avatar($b_v['uid'],'middle','true');
            $bdlist[$b_k]['refund_type_text'] = $refund_type_array[$b_v['refund_type']].'('.($order_cart['admin'] ? $qb_pay_type[$order_cart['admin']] : $paymentarr[$b_v['payment']]).')';
            if($b_v['type'] == 5){
                $bdlist[$b_k]['laizhi'] = $b_v['username'].'&#30003;&#35831;&#36864;&#27454;&#65292;&#26469;&#33267;'.$_G['cache']['plugin']['aljsqtg']['aljsqtg_name'];
            }else{
                if($b_v['store_id'] > 0){
                    $bdlist[$b_k]['laizhi'] = $b_v['username'].lang('plugin/aljht','refundlist_php_11').($bdlist[$b_k]['bd_info']['tc_store_name'] ? '-'.$bdlist[$b_k]['bd_info']['tc_store_name'] : '').'-'.$b_v['goodsname'];
                }else{
                    $bdlist[$b_k]['laizhi'] = $b_v['username'].lang('plugin/aljht','refundlist_php_12').($bdlist[$b_k]['bd_info']['name'] ? '-'.$bdlist[$b_k]['bd_info']['name'] : '').'-'.$b_v['goodsname'];
                }
            }
            
            if($b_v['imgs']){
                $imagesarray = explode(',',$b_v['imgs']);
                $img_html = '<ul class="c_expose_img">';
                foreach($imagesarray as $i_k => $img){
                    $img_html .= '<li class="aljsqImg reply_aljsqImg"><img layer-src="$img" src="'.$img.'" ></li>';
                }
                $img_html .= '</ul>';
                $bdlist[$b_k]['img_html'] = $img_html;
                unset($img_html);
            }
        }
        echo json_encode(aljhtx::ajaxPostCharSet($bdlist));
    }else{
        echo 1;
    }
    exit;
}
//$bdlist = dhtmlspecialchars($bdlist);
$navtitle = lang('plugin/aljht','refundlist_php_10');
$metakeywords = $_G['cache']['plugin']['aljbd']['keywords'];
$metadescription = $_G['cache']['plugin']['aljbd']['description'];
include template('aljht:admin/refundlist/refundlist');
function qianfanapp_refund_list ($order,$oid,$pay_order) {
    global $payment,$config;
    if($config['qianfanapp_api_type'] == 1){
        $data = qianfanapp_refund($pay_order['transaction_id'],$pay_order['aljorderid'],$order['price']);
    }else{
        $data = qianfanapp_refund($pay_order['transaction_id'],$pay_order['aljorderid'],$order['price']*100);
    }
    
    if($data['ret'] == '0' || $data['code'] == '0'){
        DB::update('aljgwc_refund',array('state'=>3, 'updatetime' => TIMESTAMP),"orderid='".$oid."'");
        refund_order_status($oid,$order);
        DB::update('aljqb_payorder',array('status'=>2, 'overtime' => TIMESTAMP),"orderid='".$oid."'");
    }else{
        if($config['qianfanapp_api_type'] == 1){
            $query_info = qianfanapp_query_new($pay_order['transaction_id']);
            if($query_info['data']['refund'] == 2){
                DB::update('aljgwc_refund',array('state'=>3, 'updatetime' => TIMESTAMP),"orderid='".$oid."'");
                refund_order_status($oid,$order);
                DB::update('aljqb_payorder',array('status'=>2, 'overtime' => TIMESTAMP),"orderid='".$oid."'");
            }else{
                 DB::update('aljgwc_refund',array('state'=>0, 'updatetime' => TIMESTAMP),"orderid='".$oid."'");
         
                $error = diconv(var_export($data, true),'utf-8',CHARSET);
                
                $payment ->insertLog('qianfanapp_refund '.$error);
            }
        }else{
             DB::update('aljgwc_refund',array('state'=>0, 'updatetime' => TIMESTAMP),"orderid='".$oid."'");
         
            $error = diconv(var_export($data, true),'utf-8',CHARSET);
            
            $payment ->insertLog('qianfanapp_refund '.$error);
        }
    }
}
function wx_refund_list($senddata,$oid,$order){
    global $payment,$config,$pay_order,$batch_no;
    $config['pem_location'] = getcwd().'/source/plugin/aljqb/function/cert/apiclient_cert.pem';
    if($order['payment'] == 3 || $pay_order['admin'] == 'APP'){
        $senddata_query['mch_id'] = $config['mchid2'];
        $senddata_query['appid'] = $config['appid2'];
        $senddata_query['key'] = $config['key2'];
        $senddata_query['orderid'] = $order['buyer'];
        $senddata['out_refund_no'] = $batch_no;
        $senddata['mch_id'] = $config['mchid2'];
        $senddata['appid'] = $config['appid2'];
        $senddata['op_user_id'] = $config['mchid2'];
        $senddata['orderid'] = $order['buyer'];
        $senddata['price'] = $order['price'];
        $senddata['refund_fee'] = $order['price'];
        $senddata['key'] = $config['key2'];
        $senddata['location'] = $config['pem_location'].'app/';
    }else if($order['payment'] == 1 || $pay_order['admin'] == 'wxpay'){
        $senddata_query['mch_id'] = $config['mchid'];
        $senddata_query['appid'] = $config['appid'];
        $senddata_query['key'] = $config['key'];
        $senddata_query['orderid'] = $order['buyer'];
        $senddata['out_refund_no'] = $batch_no;
        $senddata['mch_id'] = $config['mchid'];
        $senddata['appid'] = $config['appid'];
        $senddata['op_user_id'] = $config['mchid'];
        $senddata['orderid'] = $order['buyer'];
        $senddata['price'] = $order['price'];
        $senddata['refund_fee'] = $order['price'];
        $senddata['key'] = $config['key'];
        $senddata['location'] = $config['pem_location'];
    }else{
        $i++;
    }
    $wxrefund = wxpayrefund($senddata);
							
    $data = xmlToArray($wxrefund);
    
    if($data['result_code'] == 'SUCCESS'){
        DB::update('aljgwc_refund',array('state'=>3, 'updatetime' => TIMESTAMP),"orderid='".$oid."'");
        refund_order_status($oid,$order);
        DB::update('aljqb_payorder',array('status'=>2, 'overtime' => TIMESTAMP),"orderid='".$oid."'");
    }else{
        DB::update('aljgwc_refund',array('state'=>0, 'updatetime' => TIMESTAMP),"orderid='".$oid."'");
    }
}
function alipay_refund_list($order,$oid){
    global $payment;
    $alipay_refund = alipayrefund($order);
    $result = json_decode($alipay_refund,true);
    if($result['alipay_trade_refund_response']['msg'] == 'Success'){
        DB::update('aljgwc_refund',array('state'=>3, 'updatetime' => TIMESTAMP),"orderid='".$oid."'");
        refund_order_status($oid,$order);
        DB::update('aljqb_payorder',array('status'=>2, 'overtime' => TIMESTAMP),"orderid='".$oid."'");
    }else{
        DB::update('aljgwc_refund',array('state'=>0, 'updatetime' => TIMESTAMP),"orderid='".$oid."'");
        
        $error = diconv($alipay_refund,'utf-8',CHARSET);
        
        $payment ->insertLog('alipay_refund '.$error);
    }
}
function refund_balance_list($order,$oid){
    global $payment,$_G;
    //����Ǯ�� -money
    $queuearray = array(
        'app_name' => 'aljbdx',
        'app_type' => 'gwc_txcancel',
        'app_phone' => '123456789',
        'app_ip' => $_G['clientip'],
    );
    $balancearray = array(
        'type'=> 'charge',
        'uid'=>$order['uid'],
        'price' => $order['price'],
        'orderid'=> $oid,
        'desc'=> str_replace(array('{money}'),array($order['price']),$_G['cache']['plugin']['aljbdx']['qb_desc_refund']),
    );
    $result = $payment -> balance($queuearray,$balancearray);
    if($result['code'] == 200){
        DB::update('aljgwc_refund',array('state'=>3, 'updatetime' => TIMESTAMP),"orderid='".$oid."'");
        refund_order_status($oid,$order);
    }
    //����Ǯ��
    
}
function refund_order_status ($oid,$order) {
    global $_G;
    C::t('#aljgwc#aljbd_goods_order')->update($oid, array('status' => 6));
    if($_G['cache']['plugin']['aljbdx']){
        DB::query("update %t set status=6 WHERE orderid=%s ",array('aljbd_goods_order_list',$oid));
    }
    if($order){
        gaddnum($order);
    }
}
function gaddnum($order){
	$orderlist = DB::fetch_all('select * from %t where orderid=%s',array('aljbd_goods_order_list',$order['orderid']));
	foreach($orderlist as $k => $v){
		DB::query('update %t set amount=amount+%d where id=%d', array('aljbd_goods',$v['num'],$v['goods_id']));
		$goods=C::t('#aljbd#aljbd_goods')->fetch($v['goods_id']);
		if($goods['attr_sku']){
			$attr_sku = unserialize($goods['attr_sku']);
			foreach($attr_sku as $sk => $sv){
				if($v['path'] == $sv['path']){
					$attr_sku[$sk]['stock'] = $attr_sku[$sk]['stock']+$v['num'];
				}
			}
			C::t('#aljbd#aljbd_goods')->update($v['goods_id'],array('attr_sku'=>serialize($attr_sku)));
			unset($attr_sku);
			unset($goods);
		}
	}
}
?>