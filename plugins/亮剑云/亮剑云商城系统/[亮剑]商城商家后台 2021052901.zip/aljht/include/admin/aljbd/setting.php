<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$_GET=dhtmlspecialchars($_GET);

loadcache('plugin');
$config = $_G['cache']['plugin'][$op];
if(submitcheck('formhash')){

    if($_FILES['logo']['tmp_name']) {
        $picname = $_FILES['logo']['name'];
        $picsize = $_FILES['logo']['size'];

        if ($picname != "") {
            $type = strtolower(strrchr($picname, '.'));
            if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
                echo '<script>parent.tips('.lang('plugin/aljbd','s19').');</script>';
                exit;
            }
            $rand = rand(100, 999);
            $pics = date("YmdHis") . $rand . $type;
            $logo = "source/plugin/aljbd/images/logo/". $pics;
            if(@copy($_FILES['logo']['tmp_name'], $logo)||@move_uploaded_file($_FILES['logo']['tmp_name'], $logo)){
                @unlink($_FILES['logo']['tmp_name']);
            }
        }
    }

    if(empty($logo)){
        $logo = $_GET['logo'];
    }


    $record = C::t('#aljbd#aljbd_setting')->fetch('logo');

    if($_GET['deletelogo']){
        C::t('#aljbd#aljbd_setting') -> delete('logo');
        if($record['value']){
            unlink($record['value']);
        }
    }
    if($logo){
        if(!$record){
            C::t('#aljbd#aljbd_setting')->insert(array('key'=>'logo','value'=>$logo));
        }else{
            C::t('#aljbd#aljbd_setting')->update_value_by_key($logo,'logo');
        }
    }

    if($_FILES['lazyloadlogo']['tmp_name']) {
        $picname = $_FILES['lazyloadlogo']['name'];
        $picsize = $_FILES['lazyloadlogo']['size'];

        if ($picname != "") {
            $type = strtolower(strrchr($picname, '.'));
            if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
                echo '<script>parent.tips('.lang('plugin/aljbd','s19').');</script>';
                exit;
            }
            $rand = rand(100, 999);
            $pics = date("YmdHis") . $rand . $type;
            $logo1 = "source/plugin/aljbd/images/logo/". $pics;
            if(@copy($_FILES['lazyloadlogo']['tmp_name'], $logo1)||@move_uploaded_file($_FILES['lazyloadlogo']['tmp_name'], $logo1)){
                @unlink($_FILES['lazyloadlogo']['tmp_name']);
            }
        }
    }

    if(empty($logo1)){
        $logo1 = $_GET['lazyloadlogo'];
    }


    $record1 = C::t('#aljbd#aljbd_setting')->fetch('lazyloadlogo');

    if($_GET['deletelazyloadlogo']){
        C::t('#aljbd#aljbd_setting') -> delete('lazyloadlogo');
        if($record1['value']){
            unlink($record1['value']);
        }
    }
    if($logo1){
        if(!$record1){
            C::t('#aljbd#aljbd_setting')->insert(array('key'=>'lazyloadlogo','value'=>$logo1));
        }else{
            C::t('#aljbd#aljbd_setting')->update_value_by_key($logo1,'lazyloadlogo');
        }
    }
    if(!C::t('#aljbd#aljbd_setting')->fetch('mhot')){
        C::t('#aljbd#aljbd_setting')->insert(array('key'=>'mhot','value'=>$_GET['mhot']));
    }else{
        if($_GET['mhot']){
            C::t('#aljbd#aljbd_setting')->update_value_by_key($_GET['mhot'],'mhot');
        }
    }

    if(!C::t('#aljbd#aljbd_setting')->fetch('mhotmore')){
        C::t('#aljbd#aljbd_setting')->insert(array('key'=>'mhotmore','value'=>$_GET['mhotmore']));
    }else{
        if($_GET['mhotmore']){
            C::t('#aljbd#aljbd_setting')->update_value_by_key($_GET['mhotmore'],'mhotmore');
        }
    }
    foreach($_GET['settingsnew'] as $k=>$v){
        if(in_array($k, array('mgroups','managegroups','allow_visit'))){
            $v = (string)serialize($v);
        }
        if(!C::t('#aljbd#aljbd_setting')->fetch($k)){
            C::t('#aljbd#aljbd_setting')->insert(array('key'=>$k,'value'=>$v));
        }else{
            C::t('#aljbd#aljbd_setting')->update_value_by_key($v,$k);
        }
    }
    savecache('aljbd_settings', '');
    echo '<script>parent.tips(0);</script>';
    exit;
}else{
    //require_once 'source/plugin/aljbd/include/initalData.php';
    $record = C::t('#aljbd#aljbd_setting')->fetch('logo');
    $logo = $record['value'];
    $record1 = C::t('#aljbd#aljbd_setting')->fetch('lazyloadlogo');
    $lazyloadlogo = $record1['value'];
    $setting = C::t('#aljbd#aljbd_setting')->range();
    $settings= $setting;
    $statusarray = array(
        'index',
        'nav',
        'footer',
        'common',
        'list',
        'view',
        'member',
        'post',
        'search',
        'comment',
        'tips',
        'mail',
        'mod',
        'seo',
        'forum',
        'anmi',
        'dx',
        'ad'
    );
    $statustextarray = array(
        '&#39318;&#39029;',
        '&#23548;&#33322;&#30456;&#20851;',
        '&#80;&#67;&#20840;&#23616;&#24213;&#37096;',
        '&#20840;&#23616;',
        '&#21015;&#34920;&#39029;',
        '&#35814;&#24773;&#39029;',
        '&#20250;&#21592;&#20013;&#24515;',
        '&#20449;&#24687;&#21457;&#24067;&#30456;&#20851;',
        '&#25628;&#32034;&#35774;&#32622;',
        '&#35780;&#35770;&#30456;&#20851;',
        '&#25552;&#31034;&#35821;&#30456;&#20851;',
        '&#31449;&#20869;&#47;&#37038;&#20214;&#36890;&#30693;',
        '&#27169;&#22359;&#24320;&#20851;',
        '&#40664;&#35748;&#83;&#69;&#79;',
        '&#35770;&#22363;&#30456;&#20851;',
        '&#23433;&#31859;&#19987;&#29992;',
        '&#30701;&#20449;&#35774;&#32622;',
        '&#33258;&#21161;&#24191;&#21578;'
    );
    $status = addslashes($_GET['status']);
    $status = !in_array($status, $statusarray) ? 'index' : $status;

    include template($pluginid.':admin/'.$op.'/setting');

}
function l_groups($group,$type=0){
    global $_G,$config,$settings;
    define('IN_ADMINCP', TRUE);
    lang('admincp');
    $lang = & $_G['lang']['admincp'];

    if($type){
        $var['type'] = '<select name="'.$group.'"><option value="">'.lang("plugin/aljht","setting_php_1").'</option>';
        $var['value'] = $_GET['groupid'];
    }else{
        $var['description'] = ($var['description'] ? (isset($lang[$var['description']]) ? $lang[$var['description']] : $var['description'])."\n" : '').$lang['plugins_edit_vars_multiselect_comment']."\n".$var['comment'];
        $var['value'] = dunserialize($settings[$group]['value']);
        $var['type'] = '<select name="settingsnew['.$group.'][]" size="10" multiple="multiple"><option value=""'.(@in_array('', $var['value']) ? ' selected' : '').'>'.lang("plugin/aljht","setting_php_2").'</option>';
    }

    $var['value'] = is_array($var['value']) ? $var['value'] : array($var['value']);

    $query = C::t('common_usergroup')->range_orderby_credit();
    $groupselect = array();
    foreach($query as $group) {
        $group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
        $groupselect[$group['type']] .= '<option value="'.$group['groupid'].'"'.(@in_array($group['groupid'], $var['value']) ? ' selected' : '').'>'.$group['grouptitle'].'</option>';
    }
    $var['type'] .= '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
        ($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
        ($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
        '<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup></select>';
    return $var['type'];
}
//di'.'sm.t'.'aoba'.'o.com
?>