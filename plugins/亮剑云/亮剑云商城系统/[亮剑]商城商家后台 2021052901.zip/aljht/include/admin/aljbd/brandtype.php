<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
savecache('aljbd_type', '');
if($_GET['status']){
    $status = '_'.$_GET['status'];
    if($_GET['status'] == 'goods' || $_GET['status'] == 'video'){
        $maxlevel = 3;
    }
}else{
    $maxlevel = 3;
}
$level = intval($_GET['level']) ? intval($_GET['level']) : 1;
$mall_type = $op.'_type'.$status;
/**
 * @param $gotable ��Դ��
 * @param $totable �����
 */
function tableGoTo($gotable,$totable){
    $sql = 'insert into '.DB::table($totable).'(id,upid,subid,subject,displayorder) select id,upid,subid,subject,displayorder from '.DB::table($gotable);
    DB::query($sql);
}
if($ord == 'emptytable'){
    $totable = $_GET['totable'];
    if(!$_GET['totable']){
        $aljht_tips = '&#34920;&#19981;&#33021;&#20026;&#31354;';
        include template('aljht:admin/pogressbar');
        exit;
    }
    $sql='TRUNCATE TABLE '.DB::table($totable);
    DB::query($sql);
    dheader("location: ".$dourl.'&status='.$_GET[status].$urlmod);
    exit;
}else if($ord == 'import'){
    if(!$_GET['gotable'] || !$_GET['totable']){
        $aljht_tips = '&#34920;&#19981;&#33021;&#20026;&#31354;';
        include template('aljht:admin/pogressbar');
        exit;
    }
    $gotable = $_GET['gotable'];
    $totable = $_GET['totable'];
    if(DB::result_first('select count(*) from %t ',array($totable))){
        $aljht_tips = '&#23548;&#20837;&#20998;&#31867;&#38656;&#35201;&#20808;&#28165;&#31354;&#26412;&#20998;&#31867;&#25968;&#25454;';
        include template('aljht:admin/pogressbar');
        exit;
    }
    tableGoTo($gotable,$totable);
    echo '<script>parent.tips("'.lang("plugin/aljht","brandtype_php_1").'");</script>';
    exit;
}else if($ord=='deleterow'){
    $id=$_GET['type_id'];
    $id_count=DB::result_first('select count(*) from %t where upid=%d ',array($mall_type,$id));
    if($id_count){
        echo '<script>parent.tips("'.lang("plugin/aljht","brandtype_php_2").'");</script>';
        exit;
    }else{
        DB::query('delete from %t where id=%d',array($mall_type,$id));
        echo '<script>parent.tips("'.lang("plugin/aljht","brandtype_php_3").'");</script>';
        exit;
    }

}else if($ord=='open'){
    $id=$_GET['type_id'];
    if($_GET['oid'] == 1){
        $open=1;
        $open_tips = '&#20851;&#38381;&#25104;&#21151;';
    }else{
        $open=0;
        $open_tips = '&#24320;&#21551;&#25104;&#21151;';
    }
    DB::update($mall_type,array('is_open'=>$open),array('id'=>$_GET['type_id']));
    echo '<script>parent.tips("'.$open_tips.'");</script>';
    exit;
}else if($ord=='deleteimg'){
    if(!$_GET['typeid']){
        echo 0;
        exit;
    }
    $type=DB::fetch_first('select * from %t where id=%d ',array($mall_type,$_GET['typeid']));
    if($type && $_GET['formhash'] == formhash()){
        DB::update($mall_type,array('logo'=>''),'id='.$_GET['typeid']);
        unlink($type['logo']);
        T::delete_oss($type['logo']);
        echo 1;
        exit;
    }else{
        echo 0;
        exit;
    }
}
if(submitcheck('formhash')) {
    $subject_first_old= $_GET['subject_first_old'];
    $pluginid_first_old= $_GET['pluginid_first_old'];
    $subject_first = $_GET['subject_first'];
    $displayorder_first_old= $_GET['displayorder_first_old'];
    $displayorder_first=$_GET['displayorder_first'];
    $subject_second_old=$_GET['subject_second_old'];
    $subject_second= $_GET['subject_second'];
    $displayorder_second_old=$_GET['displayorder_second_old'];
    $mod_second_old=$_GET['mod_second_old'];
    $displayorder_second=$_GET['displayorder_second'];
    $logo_third_old=$_GET['logo_third_old'];
    $logo_first_old=$_GET['logo_first_old'];
    $pclabel_first_old=$_GET['pclabel_first_old'];
    $brand_id_first_old=$_GET['brand_id_first_old'];
    $type_ad_first_old=$_GET['type_ad_first_old'];
    $type_url_first_old=$_GET['type_url_first_old'];
    if(is_array($logo_third_old) && $logo_third_old){

        foreach($logo_third_old as  $tmp_key => $tmp_value){

            if($_FILES['logo_third_old']['tmp_name'][$tmp_key]){
                $picname = $_FILES['logo_third_old']['name'][$tmp_key];
                $picsize = $_FILES['logo_third_old']['size'][$tmp_key];

                if ($picname != "") {
                    $type = strtolower(strrchr($picname, '.'));
                    if ($type!= ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {

                        continue;

                    }

                    $rand = rand(100, 999);
                    $pics = date("YmdHis") . $rand . $type;
                    $route = "source/plugin/aljbd/images/typelogo/".date("Ymd")."/";
                    if (!is_dir($route)) {
                        mkdir($route);
                    }
                    $logo = $route. $pics;
                    if(@copy($_FILES['logo_first_old']['tmp_name'][$tmp_key], $logo)||@move_uploaded_file($_FILES['logo_first_old']['tmp_name'][$tmp_key], $logo)){
                        if (file_exists($logo)) {
                            if($_G['cache']['plugin']['aljoss']['Access_Key']){
                                $logo = T::oss($logo, 'aljbd');
                            }
                        }
                        @unlink($_FILES['logo_first_old']['tmp_name'][$tmp_key]);
                    }
                }
            }
            if($logo){
                DB::query('update %t set logo=%s where id=%d ',array($mall_type, $logo, $tmp_key));
            }
        }

    }
    if(is_array($logo_first_old) && $logo_first_old){

        foreach($logo_first_old as  $tmp_key_1 => $tmp_value_1){

            if($_FILES['logo_first_old']['tmp_name'][$tmp_key_1]){
                $picname = $_FILES['logo_first_old']['name'][$tmp_key_1];
                $picsize = $_FILES['logo_first_old']['size'][$tmp_key_1];

                if ($picname != "") {
                    $type = strtolower(strrchr($picname, '.'));
                    if ($type!= ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {

                        continue;

                    }

                    $rand = rand(100, 999);
                    $pics = date("YmdHis") . $rand . $type;
                    $route = "source/plugin/aljbd/images/typelogo/".date("Ymd")."/";
                    if (!is_dir($route)) {
                        mkdir($route);
                    }
                    $logo1 = $route. $pics;
                    if(@copy($_FILES['logo_first_old']['tmp_name'][$tmp_key_1], $logo1)||@move_uploaded_file($_FILES['logo_first_old']['tmp_name'][$tmp_key_1], $logo1)){
                        if (file_exists($logo1)) {
                            if($_G['cache']['plugin']['aljoss']['Access_Key']){
                                $logo1 = T::oss($logo1, 'aljbd');
                            }
                        }
                        @unlink($_FILES['logo_first_old']['tmp_name'][$tmp_key_1]);
                    }
                }
            }
            if($logo1){

                DB::query('update %t set logo=%s where id=%d ',array($mall_type, $logo1, $tmp_key_1));
            }
        }

    }
    if(is_array($subject_first_old) && $subject_first_old){
        foreach($subject_first_old as  $tmp_key => $tmp_value){
            if($_GET['status'] == 'goods') {
                DB::query('update %t set subject=%s,brand_id=%s,pclabel=%s,type_ad=%s,type_url=%s where id=%d ', array($mall_type, $tmp_value, $brand_id_first_old[$tmp_key], $pclabel_first_old[$tmp_key], $type_ad_first_old[$tmp_key],$type_url_first_old[$tmp_key], $tmp_key));
            }else{
                DB::query('update %t set subject=%s,type_url=%s where id=%d ', array($mall_type, $tmp_value,$type_url_first_old[$tmp_key], $tmp_key));
            }
        }
    }
    if(is_array($pluginid_first_old) && $pluginid_first_old){
        foreach($pluginid_first_old as  $tmp_key => $tmp_value){
            DB::query('update %t set pluginid=%s where id=%d ',array($mall_type, $tmp_value, $tmp_key));
        }
    }
    if(is_array($displayorder_first_old) && $displayorder_first_old){
        foreach($displayorder_first_old as  $tmp_key => $tmp_value){
            DB::query('update %t set displayorder=%d where id=%d',array($mall_type, $tmp_value, $tmp_key));
        }
    }
    if(is_array($subject_second_old) && $subject_second_old){
        foreach($subject_second_old as  $tmp_key => $tmp_value){
            foreach($tmp_value as  $tmp_key_second => $tmp_value_second){
                DB::query('update %t set subject=%s where id=%d',array($mall_type,$tmp_value_second,$tmp_key));
            }
        }

    }
    if(is_array($displayorder_second_old) && $displayorder_second_old){
        foreach($displayorder_second_old as $tmp_key =>$tmp_value){
            foreach($tmp_value as $tmp_key_second =>$tmp_value_second){
                DB::query('update %t set displayorder=%d where id=%d',array($mall_type,$tmp_value_second,$tmp_key));
            }
        }

    }

    if(is_array($subject_first)){
        foreach($subject_first as $tmp_key =>$tmp_value){
            if(empty($tmp_value)) {
                continue;
            }
            DB::insert($mall_type,array(
                'subject'=>$tmp_value,
                'displayorder' => $displayorder_first[$tmp_key],
            ));
        }
    }
    
    if(is_array($subject_second)){
        foreach ($subject_second as $tmp_key=> $tmp_value){
            foreach($tmp_value as $tmp_key_second => $tmp_value_second){
                DB::insert($mall_type,array(
                    'subject'=>$tmp_value_second,
                    'upid'=>$tmp_key,
                    'displayorder' => $displayorder_second[$tmp_key][$tmp_key_second],
                ));
            }
        }
    }
    echo '<script>parent.tips(0);</script>';
    exit;
}else{
    $upid = $_GET['upid'] ? intval($_GET['upid']) : 0;
    $page=!empty($_GET['page'])?intval($_GET['page']):1;
    if($_GET['link']){
        $pagesize=50;
    }else{
        $pagesize=6;
    }
    $offset=($page-1) * $pagesize;
    $url=$dourl."&status=".$_GET['status'].$urlmod."&page=";
    $allnum=DB::result_first('select count(*) from %t where upid=%d',array($mall_type,$upid));
    $paging=_mall_paging($page,$allnum,$pagesize,$url);
    $list=DB::fetch_all('select * from %t where upid=%d order by displayorder asc limit %d,%d',array($mall_type,$upid,$offset,$pagesize));
    include template($pluginid.':admin/'.$op.'/'.$do);
}
//di'.'sm.t'.'aoba'.'o.com
?>