<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once 'source/plugin/aljbd/include/upgrade.php';
require_once 'source/plugin/aljbd/include/initalData.php';
$aljht_tips = lang("plugin/aljht","upgrade_php_1");
include template('aljht:admin/pogressbar');
exit;
?>