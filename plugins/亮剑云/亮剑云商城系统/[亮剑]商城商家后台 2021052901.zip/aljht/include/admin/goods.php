<?php

$imgnum = 12;


if($do == 'sh_status'){
    if($_GET['formhash'] == FORMHASH) {
        if(!$administrators && $_GET[i] != 1){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","goods_php_7"))));
            exit;
        }
        if(!$_GET[cashid]){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","goods_php_8"))));
            exit;
        }

        $goods = C::t('#aljbd#aljbd_goods')->fetch($_GET[cashid]);
        if(!$goods){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","goods_php_9"))));
            exit;
        }

        if(strtolower(CHARSET) == 'gbk' && !$_G[mobile] && $_GET[message]){
            $_GET[message] = diconv($_GET[message],'utf-8','gbk');
        }

        if(DB::query('update %t set sh_status=%d,reason=%s  where id = %d and sh_status = %d',array('aljbd_goods',$_GET[status],$_GET[message],$_GET[cashid],$goods['sh_status']))){
            if($_GET[status] == 2){
                $send_goods_tips = lang("plugin/aljht","goods_php_10").'{shopname}'.lang("plugin/aljht","goods_php_11").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=goods&mod=my">'.lang("plugin/aljht","goods_php_12").'</a>';
            }else{
                $send_goods_tips = lang("plugin/aljht","goods_php_13").'{shopname}'.lang("plugin/aljht","goods_php_14").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=goods&mod=my">'.lang("plugin/aljht","goods_php_15").'</a>';
            }
            $reason = $_GET[message] ? lang("plugin/aljht","goods_php_16").$_GET[message] : '';
            notification_add(
                $goods['uid'],
                'system',str_replace(array('{shopname}','{reason}'),array($goods['name'],$reason), $send_goods_tips),
                array('from_idtype'  => 'aljbd_goods','from_id' => $goods['id'])
            );
            echo json_encode(T::ajaxPostCharSet(array('code'=>1,'text'=>lang("plugin/aljht","goods_php_17"))));
            exit;
        }else{
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","goods_php_18"))));
            exit;
        }
    }else{
        echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","goods_php_19"))));
        exit;
    }
}else if($do == 'up_down'){//���¼�

    if($_GET['formhash'] == FORMHASH) {
        if (!$goods || (!$administrators && $goods['uid'] != $_G['uid'] && !in_array($in_a,$staff['st_staff_authority']))) {
            echo json_encode(T::ajaxPostCharSet(array('code' => 0, 'text' => lang("plugin/aljht","goods_php_20"))));
            exit;
        }
        if (!$_GET[state]) {
            echo json_encode(T::ajaxPostCharSet(array('code' => 0, 'text' => lang("plugin/aljht","goods_php_21"))));
            exit;
        }
        if($_GET['state'] == 1){
            DB::query('update %t set state=1  where id = %d', array('aljbd_goods', $gid));
        }else{
            DB::query('update %t set state=0  where id = %d', array('aljbd_goods', $gid));
        }
        echo json_encode(T::ajaxPostCharSet(array('code'=>1,'text'=>lang("plugin/aljht","goods_php_22"))));
        exit;
    }else{
        echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","goods_php_23"))));
        exit;
    }
}else if($do == 'editgoods' || $do == 'addgoods'){
    if($_GET['dzAdmin'] == 1){//�ŵ귢����Ʒ
        $settings['is_post_btn']['value'] = 1;
        if($admin_status){
            $bdlist=C::t('#aljtsq#aljtsq_store')->fetch_all_by_where(array('status'=>1));//����Ա
        }else{
            $bdlist=C::t('#aljtsq#aljtsq_store')->fetch_all_by_where(array('status'=>1,'uid'=>$_G['uid']));//����
        }
        if($bdlist){
            foreach($bdlist as $bk=>$bv){
                
                if($bv['vipid']){
                    $v_data = DB::fetch_first('select * from %t where id=%d and type=1',array('aljbd_vip',$bv['vipid']));
                    if($v_data){
                        $v_data['store_authority'] = explode(',',$v_data['store_authority']);
                        $v_data['goods_intro_video'] = $v_data['store_authority'] && in_array('goods_intro_video',$v_data['store_authority']) ? 1 : 0;
                    }
                    $bdlist[$bk]['vipdata'] = $v_data;
                }
                unset($v_data);
            }
        }
        
        if($do == 'addgoods'){
            if($bd['vipid']){
                $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$bd['vipid']));
                $brandnum['good']=$vipdata['good'];
                $bnum=C::t('#aljbd#aljbd_goods')->count_by_status('',$_G['uid'],'','','','','','','',array('store_id'=>$store_id));
                if($brandnum['good']){
                    if($brandnum['good'] == $checksign){
                        if(submitcheck('formhash')){
                            echo "<script>parent.tips('".lang('plugin/aljbd','noauth')."','');</script>";
                        }else {
                            $aljht_tips = lang('plugin/aljbd', 'noauth') . $goodstips;
                            include template('aljht:admin/pogressbar');
                        }
                        exit;
                    }
                    if($bnum>=$brandnum['good']){
                        if(submitcheck('formhash')){
                            echo "<script>parent.tips('".lang('plugin/aljbd', 'groups_1') . $brandnum['good'] . lang('plugin/aljbd', 'groups_3')."','');</script>";
                        }else {
                            $aljht_tips = lang('plugin/aljbd', 'groups_1') . $brandnum['good'] . lang('plugin/aljbd', 'groups_3') . $goodstips;
                            include template('aljht:admin/pogressbar');
                        }
                        exit;
                    }
                }
            }
        }
    }else{
        if($administrators){
            $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','','');//����Ա
        }else{
            $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','',$_G['uid']);//����
        }
        foreach($bdlist as $bk=>$bv){
            if($bv['vipid']){
                $v_data = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$bv['vipid']));
                if($v_data){
                    $v_data['store_authority'] = explode(',',$v_data['store_authority']);
                    $v_data['goods_intro_video'] = $v_data['store_authority'] && in_array('goods_intro_video',$v_data['store_authority']) ? 1 : 0;
                }
                $bdlist[$bk]['vipdata'] = $v_data;
            }
            unset($v_data);
        }
        if($bd['vipid']) {
            $vipdata = DB::fetch_first('select * from %t where id=%d', array('aljbd_vip', $bd['vipid']));
            if($vipdata){
                $vipdata['store_authority'] = explode(',',$vipdata['store_authority']);
                $vipdata['goods_intro_video'] = $vipdata['store_authority'] && in_array('goods_intro_video',$vipdata['store_authority']) ? 1 : 0;
            }
        }
        
        if($_G['cache']['plugin']['aljbzj']['is_force_pay'] && $bzj_info['price'] <= 0 && $bid && file_exists("source/plugin/aljbzj/template/force_pay_tips.htm") && !$administrators){
            if(submitcheck('formhash')) {
                $post = 1;
                include template('aljbzj:force_pay_tips');
                exit;
            }
        }
        if($do == 'addgoods'){
            if($bd['vipid']){
                $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$bd['vipid']));
                $brandnum['good']=$vipdata['good'];
                $bnum = C::t('#aljbd#aljbd_goods')->count_by_status('', $_G['uid']);
                if ($brandnum['good'] && !$administrators) {
                    if ($brandnum['good'] == $checksign) {
                        if(submitcheck('formhash')){
                            echo "<script>parent.tips('".lang('plugin/aljbd','noauth')."','');</script>";
                        }else {
                            $aljht_tips = lang('plugin/aljbd', 'noauth') . $goodstips;
                            include template('aljht:admin/pogressbar');
                        }
                        exit;
                    }
                    if ($bnum >= $brandnum['good']) {
                        if(submitcheck('formhash')){
                            echo "<script>parent.tips('".lang('plugin/aljbd', 'groups_1') . $brandnum['good'] . lang('plugin/aljbd', 'groups_3')."','');</script>";
                        }else {
                            $aljht_tips = lang('plugin/aljbd', 'groups_1') . $brandnum['good'] . lang('plugin/aljbd', 'groups_3') . $goodstips;
                            include template('aljht:admin/pogressbar');
                        }
                        exit;
                    }
                }
            }
            if($yhzqx) {
                $bnum = C::t('#aljbd#aljbd_goods')->count_by_status('', $_G['uid']);
                if ($brandnum['good'] && !$administrators) {
                    if ($brandnum['good'] == $checksign) {
                        if(submitcheck('formhash')){
                            echo "<script>parent.tips('".lang('plugin/aljbd','noauth')."','');</script>";
                        }else{
                            $aljht_tips = lang('plugin/aljbd', 'noauth') . $goodstips;
                            include template('aljht:admin/pogressbar');
                        }
                        exit;
                    }
                    if ($bnum >= $brandnum['good']) {
                        if(submitcheck('formhash')){
                            echo "<script>parent.tips('".lang('plugin/aljbd', 'groups_1') . $brandnum['good'] . lang('plugin/aljbd', 'groups_3')."','');</script>";
                        }else {
                            $aljht_tips = lang('plugin/aljbd', 'groups_1') . $brandnum['good'] . lang('plugin/aljbd', 'groups_3') . $goodstips;
                            include template('aljht:admin/pogressbar');
                        }
                        exit;
                    }
                }
            }
        }
    }
    
    $goods = C::t('#aljbd#aljbd_goods') -> fetch($gid);
    if($goods['other']){
        $other = unserialize($goods['other']);
    }
	if(submitcheck('formhash')){

	    if($vipdata){
	        $s_pay_integral = floor($vipdata['pay_integral']/100*$_GET['price1']);
	        if($s_pay_integral<=0){
                $is_pay_integral =0;
            }else{
                $is_pay_integral = $vipdata['pay_integral'];
            }
            if($vipdata['pay_integral']>0 && $is_pay_integral<$_GET['pay_integral']){
	            $tips_s = lang("plugin/aljht","goods_php_24");
                $tips_e = lang("plugin/aljht","goods_php_25");
                echo "<script>parent.tips('".$tips_s.$is_pay_integral."%".$tips_e."','');</script>";
                exit;
            }
            if($settings['is_give_integral']['value']==1 || $_GET['dzAdmin'] == 1){
                $s_give_integral = $vipdata['give_integral'];
                $tips_s = lang("plugin/aljht","goods_php_44");
                $tips_e = '%';
            }else{
                $s_give_integral = floor($vipdata['give_integral']/100*$_GET['price1']);
                $tips_s = lang("plugin/aljht","goods_php_26");
                $tips_e = lang("plugin/aljht","goods_php_27");
            }
            
            if($vipdata['give_integral']>0 && $s_give_integral<$_GET['give_integral']){
                
                echo "<script>parent.tips('".$tips_s.$s_give_integral.$tips_e."','');</script>";
                exit;
            }
        }
        
		if($settings['is_attes']['value'] && $bid){
			$sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
			if(!$sign){
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('&#24215;&#38138;&#24517;&#39035;&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#21830;&#21697;','');</script>";
					exit;
				}else{
					echo "<script>parent.tips('&#24215;&#38138;&#24517;&#39035;&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#21830;&#21697;','');</script>";
					exit;
				}
			}
		}
		if(empty($_GET['name'])){
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljbd','s52')."','');</script>";
				exit;
			}else{
				echo "<script>parent.tips('".lang('plugin/aljbd','s52')."','');</script>";
				exit;
			}
		}
		if(!empty($_GET['price1'])){
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				if(!is_numeric($_GET['price1'])) {
					echo "<script>parent.tips('&#35831;&#22635;&#20889;&#25968;&#23383;','');</script>";
					exit;
				}
			}else{
				if(!is_numeric($_GET['price1'])) {
					echo "<script>parent.tips('&#35831;&#22635;&#20889;&#25968;&#23383;','');</script>";
					exit;
				}
				
			}
		}
		if(!empty($_GET['price2'])){
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				if(!is_numeric($_GET['price2'])) {
					echo "<script>parent.tips('&#35831;&#22635;&#20889;&#25968;&#23383;','');</script>";
					exit;
				}
			}else{
				if(!is_numeric($_GET['price2'])) {
					echo "<script>parent.tips('&#35831;&#22635;&#20889;&#25968;&#23383;','');</script>";
					exit;
				}
				
			}
		}

		if($_GET['price1'] > $_GET['price2'] && $_GET['price2']>0){
            echo "<script>parent.tips('".lang("plugin/aljht","goods_php_1")."','');</script>";
            exit;
        }
        if($_GET['new_price'] > $_GET['price1'] && $_GET['new_price']>0){
            echo "<script>parent.tips('".lang("plugin/aljht","goods_php_2")."','');</script>";
            exit;
        }
        
        if($_G['cache']['plugin']['aljbd']['is_goods_postcensor']){
        
            $censor_arr = array('name'=>'&#21830;&#21697;&#21517;&#31216;','commodity_code'=>'&#21830;&#21697;&#36135;&#21495;','brief'=>'&#21830;&#21697;&#31616;&#21333;&#25551;&#36848;','selling_point'=>'&#21830;&#21697;&#21334;&#28857;','gwurl'=>'&#21830;&#21697;&#22806;&#38142;','intro'=>'&#21830;&#21697;&#20171;&#32461;');
            foreach($censor_arr as $c_k => $c_v){
                if($_GET[$c_k]){
                    $censor = & discuz_censor::instance();
                    $censor->check($_GET[$c_k]);
                    if($censor->modbanned() || $censor->modmoderated()) {
                        echo "<script>parent.tips('".$c_v.'&#21253;&#21547;&#25935;&#24863;&#35789;&#65292;&#35831;&#37325;&#26032;&#36755;&#20837;'."','');</script>";
                        exit;
                    }
                }
            }
        }
		/*if(empty($_GET['endtime'])){
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljbd','mendtime')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljbd','mendtime'));
			}
		}*/
        $insertarray = array(
            'bid'=>$bid,
            'name'=>$_GET['name'],
            'price1'=>$_GET['price1'],
            'price2'=>$_GET['price2'],
            'new_price'=>$_GET['new_price'],
            'intro'=>$_GET['intro'],
            'gwurl'=>$_GET['gwurl'],
            'dateline'=>TIMESTAMP,
            'type'=>$_GET['type'],
            'subtype'=>$_GET['subtype'],
            'btypeid'=>$_GET['btypeid'],
            'bsubtypeid'=>$_GET['bsubtypeid'],
            'subtype3'=>$_GET['subtype3'],
            'amount'=>$_GET['amount'],
            'state'=>$_GET['state'],
            'displayorder'=>$_GET['displayorder'] ? $_GET['displayorder'] : $goods['displayorder'],
            'selling_point'=>$_GET['selling_point'],
            'category'=>$_GET['category'],
            'commodity_type'=>$_GET['commodity_type'],
            'starttime'=>strtotime($_GET['starttime']),
            'endtime'=>strtotime($_GET['endtime']),
            'brief'=>$_GET['brief'],
            'give_integral'=>$_GET['give_integral'],
            'pay_integral'=>$_GET['pay_integral'],
            'limit_amount'=>$_GET['limit_amount'],
            'region'=>$bd['region'],
            'region1'=>$bd['region1'],
            'subregion'=>$bd['subregion'],
            'is_pt_sku'=>$_GET['is_pt_sku'],
            'weight'=>$_GET['weight'],
            'service_label'=>implode(',', $_GET['service_label']),
            'product_label'=>implode(',', $_GET['product_label']),
        );
        $other = array();
        $insertarray['limit_type'] = $_GET['limit_type'];
        if(($_G['cache']['plugin']['aljsqtg']['is_aljsqtg'] || $_G['cache']['plugin']['aljspt']['is_aljspt']) && $_GET['dzAdmin'] != 1){
            
            $insertarray['qg_type'] = $_GET['qg_type'];
            if($_GET['qg_type'] == 2){
                if(!$_GET['start_time'] || !$_GET['end_time']){
                    echo "<script>parent.tips('&#27599;&#26085;&#25250;&#36141;&#24320;&#22987;&#36319;&#32467;&#26463;&#26102;&#38388;&#24517;&#39035;&#36873;&#25321;','');</script>";
                    exit;
                }
                $other['start_time'] = $_GET['start_time'];
                $other['end_time'] = $_GET['end_time'];
            }
        }
        
        $other['unified_inventory'] = $_GET['unified_inventory'];
        $other['jiaobiao_img'] = $_GET['jiaobiao_img'];
        if($_G['cache']['plugin']['aljkj']['is_aljkj']){
            $other['kj_min_price'] = $_GET['kj_min_price'];
            $other['kj_max_price'] = $_GET['kj_max_price'];
            $other['kj_my_multiple'] = $_GET['kj_my_multiple'];
            $other['kj_new_multiple'] = $_GET['kj_new_multiple'];
            
            if($_GET['commodity_type'] == 7){
                if(!$_GET['kj_min_price'] || !$_GET['kj_max_price']){
                    echo "<script>parent.tips('&#30733;&#20215;&#21830;&#21697;&#30733;&#20215;&#26368;&#23567;&#20540;&#36319;&#26368;&#22823;&#20540;&#24517;&#39035;&#22635;&#20889;','');</script>";
                    exit;
                }
                if($_GET['price2']<=0){
                    echo "<script>parent.tips('&#30733;&#20215;&#21830;&#21697;&#24066;&#22330;&#20215;&#26684;&#24517;&#39035;&#22635;&#20889;','');</script>";
                    exit;
                }
            }
        }
        $other['goodsview_type'] = $_GET['goodsview_type'];
        $other['aljsqtg_goods_id'] = $_GET['aljsqtg_goods_id'];
        $other['is_aljsqtg_stock'] = $_GET['is_aljsqtg_stock'];
        $other['aljsqtg_goods_stock_num'] = $_GET['aljsqtg_goods_stock_num'];
        if($other){
            $insertarray['other'] = serialize($other);
        }
        
        if($_GET['commodity_code'] && $settings['is_commodity_code']['value']==1){
            if($do == 'addgoods'){
                $mod = DB::result_first('select count(*) from %t where commodity_code=%s',array('aljbd_goods',$_GET['commodity_code']));
                if($mod){
                    echo "<script>parent.tips('".lang('plugin/aljbd','addgoods_php_3')."','');</script>";
                    exit;
                }
            } else {
                $mod = DB::result_first('select count(*) from %t where commodity_code=%s',array('aljbd_goods',$_GET['commodity_code']));
                if($mod && $goods['commodity_code'] != $_GET['commodity_code']){
                    echo "<script>parent.tips('".lang('plugin/aljbd','addgoods_php_3')."','');</script>";
                    exit;
                }
            }
        }
        
        $insertarray['commodity_code'] = $_GET['commodity_code'] ? $_GET['commodity_code'] : createOrderSn();
        if($_GET['dzAdmin'] == 1){//�ŵ귢����Ʒ
            $insertarray['store_id'] = $store_id;
            $insertarray['uid'] = $bd['tc_uid'];
            $insertarray['bid'] = $bd['bid'];
            if(empty($store_id)){
                echo "<script>parent.tips('".lang('plugin/aljbd','addgoods_php_2')."','');</script>";
                exit;
            }
            $insertarray['fz_id'] = $_GET['fz_id'];
        }else{
            if(empty($bid)){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('".lang('plugin/aljbd','s51')."','');</script>";
                    exit;
                }else{
                    echo "<script>parent.tips('".lang('plugin/aljbd','s51')."','');</script>";
                    exit;
                }
            }
            $insertarray['uid'] = $bd['uid'];
        }
        
        if($_G['cache']['plugin']['aljtcc']){
            if($_GET['card_price'] >= 100 && $_GET['card_price']>0 && !$settings['is_card_price']['value']){
                $hy_tips = lang("plugin/aljht","goods_php_28").'100%';
                echo "<script>parent.tips('".$hy_tips."','');</script>";
                exit;
            }
            $insertarray['card_price'] = $_GET['card_price'];
            $insertarray['is_aljtcc'] = $_GET['is_aljtcc'];
        }else{
            $insertarray['card_price'] = '0';//��Ա���ر��ۿ۹�0
        }
        
            
        if ($_GET['cover_image']) {
            if($_GET['copy'] == '1'){//������ƷͼƬ����
                $insertarray['cover_image'] = T::saveimg($_GET['cover_image'],$image_path.'logo/');
            }else{
                if (strpos($_GET['cover_image'],"base64") === false) {
                    $insertarray['cover_image'] = $_GET['cover_image'];
                } else {
                    unlink($goods['cover_image']);
                    T::delete_oss($goods['cover_image']);
                    $insertarray['cover_image'] = T::saveimg($_GET['cover_image'],$image_path.'logo/');
                }
            }
        }
        
        if($_GET['commodity_type'] == 3){
            if(!$_GET['starttime']){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#38480;&#26102;&#25250;&#36141;&#24320;&#22987;&#26102;&#38388;&#24517;&#39035;&#36873;&#25321;','');</script>";
                    exit;
                }else{
                    echo "<script>parent.tips('&#38480;&#26102;&#25250;&#36141;&#24320;&#22987;&#26102;&#38388;&#24517;&#39035;&#36873;&#25321;','');</script>";
                    exit;
                }
            }
        }
        if($_GET['commodity_type'] == 2){
            if($_GET['collage_price']<=0){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#25340;&#22242;&#20215;&#26684;&#24517;&#39035;&#22635;&#20889;','');</script>";
                    exit;
                }else{
                    echo "<script>parent.tips('&#25340;&#22242;&#20215;&#26684;&#24517;&#39035;&#22635;&#20889;','');</script>";
                    exit;
                }
            }
            $insertarray['collage_price'] = $_GET['collage_price'];
            if($_GET['collage_num']<=0){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#25340;&#22242;&#20154;&#25968;&#24517;&#39035;&#22635;&#20889;','');</script>";
                    exit;
                }else{
                    echo "<script>parent.tips('&#25340;&#22242;&#20154;&#25968;&#24517;&#39035;&#22635;&#20889;','');</script>";
                    exit;
                }
            }
            $insertarray['collage_num'] = $_GET['collage_num'];
        }

        if($_G['cache']['plugin']['aljsfx']['is_aljsfx']){
            $insertarray['is_distribution'] = $_GET['is_distribution'];
            if($_GET['is_distribution']>0 && $_GET['dis_commission']<1){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#24320;&#21551;&#20998;&#38144;&#20998;&#38144;&#20323;&#37329;&#27604;&#20363;&#24517;&#39035;&#22823;&#20110;&#48;','');</script>";
                    exit;
                }else{
                    echo "<script>parent.tips('&#24320;&#21551;&#20998;&#38144;&#20998;&#38144;&#20323;&#37329;&#27604;&#20363;&#24517;&#39035;&#22823;&#20110;&#48;','');</script>";
                    exit;
                }
            }
            if($_G['cache']['plugin']['aljsfx']['fx_goods_bili']>0){
                $fx_goods_bili = $_G['cache']['plugin']['aljsfx']['fx_goods_bili'];
                if($_GET['is_distribution']>0 && $_GET['dis_commission']<$fx_goods_bili){
                    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                        echo "<script>parent.tips('&#20998;&#38144;&#20323;&#37329;&#27604;&#20363;&#24517;&#39035;&#22823;&#20110;".$fx_goods_bili."%','');</script>";
                        exit;
                    }else{
                        echo "<script>parent.tips('&#20998;&#38144;&#20323;&#37329;&#27604;&#20363;&#24517;&#39035;&#22823;&#20110;".$fx_goods_bili."%','');</script>";
                        exit;
                    }
                }
            }
            if($_GET['is_distribution'] == 0){
                $insertarray['dis_commission'] = 0;
            }else{
                $insertarray['dis_commission'] = $_GET['dis_commission'];
            }
            if($vipdata['is_distribution'] == 0){
                $insertarray['dis_commission'] = 0;
                $insertarray['is_distribution'] = 0;
            }
        }

		if($_G['cache']['plugin']['aljgwc']['aljbd']){
			if($_GET['fare_desc'] == '999999' || $_GET['fare_desc'] == '3'){
				$insertarray['fare'] = $_GET['fare'];
			}else{
                $insertarray['fare'] = 0;
            }
            
			$insertarray['fare_desc'] = $_GET['fare_desc'];
			if($_GET['fare_desc'] == '3'){
                if($_GET['fare']<=0){
                    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                        echo "<script>parent.tips('".lang("plugin/aljht","goods_php_3")."','');</script>";
                        exit;
                    }else{
                        echo "<script>parent.tips('".lang("plugin/aljht","goods_php_4")."','');</script>";
                        exit;
                    }
                }
                $mb_info = DB::fetch_first('select * from %t where mid=%d and type=%s',array('aljmb_fee_template',$_GET['fare'],'byweight'));
                if($_GET['weight'] <=0 && $mb_info){
                    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                        echo "<script>parent.tips('".lang("plugin/aljht","goods_php_5")."','');</script>";
                        exit;
                    }else{
                        echo "<script>parent.tips('".lang("plugin/aljht","goods_php_6")."','');</script>";
                        exit;
                    }
                }
            }
		}
        
        if($u20181224){
            if($_G['cache']['plugin']['aljsp']['is_sp']){
                $insertarray['vr_url'] = $_GET['vr_url'];
                $insertarray['video_url'] = $_GET['video_url'];
                $pattern="/(\\w+(-\\w+)*)(\\.(\\w+(-\\w+)*))*(\\?\\S*)?/";//�������ʽ
                if($_GET['vr_url'] && !in_array(strtolower(substr($_GET['vr_url'], 0, 6)), array('http:/', 'https:', 'ftp://')))
                {
                    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                        echo "<script>parent.tips('&#35831;&#36755;&#20837;&#27491;&#30830;&#30340;&#86;&#82;&#35270;&#39057;&#32593;&#22336;','');</script>";
                        exit;
                    }else{
                        echo "<script>parent.tips('&#35831;&#36755;&#20837;&#27491;&#30830;&#30340;&#86;&#82;&#35270;&#39057;&#32593;&#22336;','');</script>";
                        exit;
                    }
                }
                if($_GET['video_url'] && !in_array(strtolower(substr($_GET['video_url'], 0, 6)), array('http:/', 'https:', 'ftp://')))
                {
                    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                        echo "<script>parent.tips('&#35831;&#36755;&#20837;&#27491;&#30830;&#30340;&#35270;&#39057;&#32593;&#22336;','');</script>";
                        exit;
                    }else{
                        echo "<script>parent.tips('&#35831;&#36755;&#20837;&#27491;&#30830;&#30340;&#35270;&#39057;&#32593;&#22336;','');</script>";
                        exit;
                    }
                }
            }
            if($_G['cache']['plugin']['aljoss']['Access_Key']){
                $insertarray['video_path'] = $_GET['video_path'];

                if($goods && ($_GET['del_video'] || ($goods['video_path']!=$_GET['video_path'] && $_GET['copy'] != '1'))){
                    
                    T::delete_oss($goods['video_path']);
                    if($_GET['del_video']){
                        $insertarray['video_path'] = '';
                    }
                }
                $insertarray['intro_video_path'] = $_GET['intro_video_path'];
                if($goods && ($goods['intro_video_path']!=$_GET['intro_video_path'] && $_GET['copy'] != '1')){
                    
                    T::delete_oss($goods['intro_video_path']);
                }
            }
            if($vipdata['is_video'] == 0){
                $insertarray['vr_url'] = '';
                $insertarray['video_url'] = '';
                if($_GET['video_path']){
                    T::delete_oss($_GET['video_path']);
                }
                T::delete_oss($goods['video_path']);
                $insertarray['video_path'] = '';
            }
            if($vipdata['goods_intro_video'] == 0){
                T::delete_oss($goods['intro_video_path']);
                $insertarray['intro_video_path'] = '';
            }
        }
		//$bd=C::t('#aljbd#aljbd')->fetch($bid);
		
        
		if(file_exists("source/plugin/xydz/xydz.inc.php")){
			require_once 'source/plugin/xydz/include/addgoods.php';
		}

        if(file_exists("source/plugin/dz_3/dz_3.inc.php")){
            require_once 'source/plugin/dz_3/include/ht_addgoods.php';
        }
        if(file_exists("source/plugin/dz_1/dz_1.inc.php")){
            $insertarray['sccj'] = $_GET['sccj'];
            $insertarray['cpgg'] = $_GET['cpgg'];
            $insertarray['fyts'] = $_GET['fyts'];
            $insertarray['ysqz'] = $_GET['ysqz'];
            $insertarray['hdtj'] = $_GET['hdtj'];
            $insertarray['ext_num'] = $_GET['ext_num'];
        }
        $insertarray['is_volume'] = $_GET['is_volume'];
        if($_GET['is_volume'] == 1){
            if($_GET['v_id']){
                foreach ($_GET['v_id'] as $v_id_key => $v_id_val){
                    if($v_id_val && $_GET['volume_price'][$v_id_key] > 0 && $_GET['volume_number'][$v_id_key]>1){
                        DB::update('aljbd_goods_volume_price',array('volume_number'=>$_GET['volume_number'][$v_id_key],'volume_price'=>$_GET['volume_price'][$v_id_key],'volume_price_pt'=>$_GET['volume_price_pt'][$v_id_key]),array('id' => $v_id_val));
                    }
                }
            }

            if($_GET['volume_number']){
                foreach ($_GET['volume_number'] as $v_n_key => $v_n_val){

                    if($_GET['volume_price'][$v_n_key] && $v_n_val>1 && !$_GET['v_id'][$v_n_key]){
                        DB::insert('aljbd_goods_volume_price',array('price_type'=>1,'volume_number'=>$v_n_val,'volume_price'=>$_GET['volume_price'][$v_n_key],'volume_price_pt'=>$_GET['volume_price_pt'][$v_n_key],'goods_id'=>$gid));
                    }
                }
            }
        }
        if($settings['is_form']['value'] && $do == 'addgoods'){
            if(DB::result_first('select * from %t where name = %s and bid=%d',array('aljbd_goods',$_GET['name'],$bid))){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#21830;&#21697;&#24050;&#23384;&#22312;','');</script>";
                    exit;
                }else{
                    echo "<script>parent.tips('&#21830;&#21697;&#24050;&#23384;&#22312;','');</script>";
                    exit;
                }
            }
            if(!valid_token($_GET['aljbd_goods_token'],getcookie('aljbd_goods_token'),'aljbd_goods_token')){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#27491;&#22312;&#21069;&#24448;&#21830;&#21697;&#31649;&#29702;','');</script>";
                    exit;
                }else{
                    echo "<script>parent.tips('&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#27491;&#22312;&#21069;&#24448;&#21830;&#21697;&#31649;&#29702;','plugin.php?id=aljbd&act=goodslist');</script>";
                    exit;
                }
            }
        }
        if($_GET['copy'] == '1'){//������ƷͼƬ����
            for ($i = 1; $i <= $imgnum; $i++) {
                $pic = 'pic' . $i;
                if ($_GET[$pic]) {
                    if (strpos($_GET[$pic],$oss_domain) === false) {
                        $rand = rand(100, 999);
                        $pics = date("YmdHis") . $rand . '.jpg';
                        $img_dir = $image_path . 'logo/' . date('Ymd', TIMESTAMP) . '/';
                        if (!is_dir($img_dir)) {
                            mkdir($img_dir);
                        }
                        $$pic = $img_dir . $pics;
                        if (@copy($_GET[$pic], $$pic) || @move_uploaded_file($_GET[$pic], $$pic)) {
                            if ($_G['cache']['plugin']['aljbd']['iswatermark']) {
                                $image->Watermark(DISCUZ_ROOT . './' . $$pic, '', 'forum');
                            }
                            $imageinfo = getimagesize($$pic);
                        }
                        $insertarray['pic'.$i] = $$pic;
                    }else{
                        $insertarray['pic'.$i] = T::saveimg($_GET[$pic],$image_path.'logo/');
                    }
                }
            }
        }else{
            if($_GET['compress'] == '1'){

                if(!$_FILES['pic1']['tmp_name'] && $do != 'editgoods') {
                    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                        echo "<script>parent.tips('".lang('plugin/aljbd','s56')."','');</script>";
                        exit;
                    }else{
                        echo "<script>parent.tips('".lang('plugin/aljbd','s56')."','');</script>";
                        exit;
                    }
                }
                for ($i = 1; $i <= $imgnum; $i++) {
                    $pic = 'pic' . $i;
                    if ($_FILES[$pic]['tmp_name']) {
                        $picname = $_FILES[$pic]['name'];
                        $picsize = $_FILES[$pic]['size'];
                        if ($picname != "") {
                            $type = strtolower(strrchr($picname, '.'));
                            if ($type != ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
                                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                                    echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
                                    exit;
                                }else{
                                    echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
                                    exit;
                                }
                            }
                            if (($picsize/1024)>$_G['cache']['plugin']['aljbd']['img_size']) {

                                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                                    echo "<script>parent.tips('".lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB'."','');</script>";
                                    exit;
                                }else{
                                    echo "<script>parent.tips('".lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB'."','');</script>";
                                    exit;
                                }
                            }
                            $rand = rand(100, 999);
                            $pics = date("YmdHis") . $rand . $type;
                            $img_dir = $image_path.'logo/'.date('Ymd',TIMESTAMP).'/';
                            if (!is_dir($img_dir)) {
                                mkdir($img_dir);
                            }
                            $$pic = $img_dir . $pics;
                            if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {

                                if($_G['cache']['plugin']['aljbd']['iswatermark']){
                                    $image->Watermark(DISCUZ_ROOT.'./'.$$pic,'', 'forum');
                                }
                                $imageinfo = getimagesize($$pic);
                                if (file_exists($$pic)) {
                                    if($_G['cache']['plugin']['aljoss']['Access_Key']){
                                        $$pic = T::oss($$pic, 'aljbd');
                                    }
                                }
                                @unlink($_FILES[$pic]['tmp_name']);
                            }

                        }
                    }
                }
                for ($i = 1; $i <= $imgnum; $i++) {
                    $pic = 'pic' . $i;
                    if ($$pic) {
                        if($goods && !$_GET['copy']){
                            unlink($goods[$pic]);
                            unlink($goods[$pic].'.60x60.jpg');
                            unlink($goods[$pic].'.205x205.jpg');
                            unlink($goods[$pic].'.470x470.jpg');
                            T::delete_oss($goods[$pic]);
                        }
                        $insertarray[$pic] = $$pic;
                    }
                }
            }else{
                if(!$_GET['pic1'] && $do != 'editgoods') {

                    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                        echo "<script>parent.tips('".lang('plugin/aljbd','s56')."','');</script>";
                        exit;
                    }else{
                        echo "<script>parent.tips('".lang('plugin/aljbd','s56')."','');</script>";
                        exit;
                    }
                }

                for ($i = 1; $i <= $imgnum; $i++) {
                    $pic = 'pic' . $i;
                    if ($_GET[$pic]) {
                        if (strpos($_GET[$pic],"base64") === false) {
                            $insertarray['pic'.$i] = $_GET[$pic];
                        } else {
                            unlink($g['pic'.$i]);
                            unlink($g['pic'.$i].'.60x60.jpg');
                            unlink($g['pic'.$i].'.205x205.jpg');
                            unlink($g['pic'.$i].'.470x470.jpg');
                            T::delete_oss($g['pic'.$pi]);
                            $insertarray['pic'.$i] = T::saveimg($_GET[$pic],$image_path.'logo/');
                        }
                    }
                }

            }
        }




        
        
		if($goods && !$_GET['copy']){
			
			if($_GET['del_logo']){
				foreach($_GET['del_logo'] as $v){
					if($goods){
						unlink($goods[$v]);
						unlink($goods[$v].'.60x60.jpg');
						unlink($goods[$v].'.205x205.jpg');
                        unlink($goods[$v].'.470x470.jpg');
                        T::delete_oss($goods[$v]);
					}
					$insertarray[$v] = '';
				}
			}
			savecache('aljbd_rec_goods', '');//�Ƽ���Ʒ �������
            C::t('#aljbd#aljbd_goods')->update($gid,$insertarray);
            DB::insert('aljbd_goods_log',array(
                'gid' => $gid,
                'addtime' => TIMESTAMP,
                'uid' => $_G['uid'],
                'username' => $_G['username'],
                'goodsinfo' => serialize(C::t('#aljbd#aljbd_goods')->fetch($gid)),
                'url' => ltrim('plugin.php?'.$_SERVER['QUERY_STRING'],'/')
            ));
		}else{
			/*if($_GET['copy'] == 1){
                $sql = "INSERT INTO ".DB::table('aljht_attr_key')." (gid,name,displayorder,uid) SELECT 2 as gid,name,displayorder,uid FROM ".DB::table('aljht_attr_key')." WHERE `gid` = 9";
                $sql .= "INSERT INTO ".DB::table('aljht_attr_value')." (kid,gid,value,displayorder,uid) SELECT 2 as gid,name,displayorder,uid FROM ".DB::table('aljht_attr_value')." WHERE `gid` = 9";
                DB::query($sql,'SILENT');
                
            }*/

			if($vipdata['is_goods'] >0 && !$administrators){
                require_once 'source/plugin/aljht/include/aljbd/addgoods_send.php';
            }
            $oldgid = $gid;
			$insertid = C::t('#aljbd#aljbd_goods')->insert($insertarray, true);
            $gid = $insertid;
            if($_GET['copy'] == 1){
                $attrkey = DB::fetch_all('select * from %t where gid=%d',array('aljht_attr_key',$oldgid));
                if($attrkey){
                    foreach($attrkey as $ak => $av){
                        $kid = DB::insert('aljht_attr_key', array(//$v['pid']���Ա�key����ID����ѡ���Լ�¼����Ӧ���ǵ�kid
                            'gid' => $gid,
                            'name' => $av['name'],
                            'uid' => $av['uid'],
                        ), true);
                        $attrvalue = DB::fetch_all('select * from %t where kid=%d',array('aljht_attr_value',$av['kid']));
                        foreach($attrvalue as $akk => $avv){//$vv['vid']���Ա�value����ID����ѡ���Լ�¼����Ӧ���ǵ�symbol
                            $symbol = DB::insert('aljht_attr_value', array(
                                'kid' => $kid,
                                'gid' => $gid,
                                'value' => $avv['value'],
                                'uid' => $avv['uid'],
                            ), true);
                        }
                    }
                    
                    $oldkey = DB::fetch_all('select * from %t where gid=%d', array('aljht_attr_key', $oldgid));
                    $oldvalue = DB::fetch_all('select * from %t where gid=%d', array('aljht_attr_value', $oldgid));
                    $key = DB::fetch_all('select * from %t where gid=%d', array('aljht_attr_key', $gid));
                    $value = DB::fetch_all('select * from %t where gid=%d', array('aljht_attr_value', $gid));
                    $str = attrsku($key,$value);
                    $oldstr = attrsku($oldkey,$oldvalue);
                    foreach($oldstr as $o_k => $o_v){
                        $skulist = DB::fetch_first('select * from %t where path=%s',array('aljht_attr_sku',implode(',',$o_v)));
                        
                        DB::insert('aljht_attr_sku', array(
                            'gid' => $gid,
                            'path' => implode(',',$str[$o_k]),
                            'saleprice' => $skulist['saleprice'],
                            'marketprice' => $skulist['marketprice'],
                            'freight' => $skulist['freight'],
                            'newprice' => $skulist['newprice'],
                            'sku_logo' => $skulist['sku_logo'],
                            'fujian' => $skulist['fujian'],
                            'fujian_name' => $skulist['fujian_name'],
                            'card_price' => $skulist['card_price'],
                            'commodity_code' => $skulist['commodity_code'],
                            'market_value' => $skulist['market_value'],
                            'displayorder' => $skulist['displayorder'],
                            'stock' => 100
                        ));
                    }
                    
                    
    
                    $sku = DB::fetch_all('select * from %t where gid=%d', array('aljht_attr_sku', $gid));
                    DB::query('update %t set attr_key = %s, attr_value=%s, attr_sku=%s where id=%d', array('aljbd_goods', serialize($key), serialize($value), serialize($sku), $gid));
                }
				
			}
		}
        $sh_tips = $sh_tips ? $sh_tips : lang('plugin/aljbd','s53');
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			
			echo "<script>parent.tips('".$sh_tips."',function(){parent.location.href='plugin.php?id=aljbd&act=goodview&bid=".$bid."&gid=" . $insertid . "';});</script>";
			exit;
		}else{
            
            if($_GET['commodity_type'] == 8 || $_GET['commodity_type'] == 7){
                $urlmod .= '&commodity_type='.$_GET['commodity_type'];
            }
            
            if($_GET['iframeeditgoods']){
                echo "<script>parent.tips(0,0,1);</script>";
            }else{
                echo "<script>parent.tips('".$sh_tips."','plugin.php?id=aljht&act=admin&op=goods".$urlmod."');</script>";
            }
			
			exit;
		}
	}else{
		if($goods['uid']!=$_G['uid'] && $do == 'editgoods' && !$administrators){
            $aljht_tips = lang('plugin/aljbd','s20');
            include template('aljht:admin/pogressbar');
            exit;
		}

        if($settings['is_attes']['value'] && !$settings['is_post_btn']['value']){
            $sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
            if(!$sign){
                $aljht_tips = '&#24215;&#38138;&#24517;&#39035;&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#21830;&#21697;';
                include template('aljht:admin/pogressbar');
                exit;
            }
        }
        if($_GET['dzAdmin'] == 1){//�ŵ귢����Ʒ
            $typelist=C::t('#aljtsc#aljtsc_type')->fetch_all_by_upid_admin(0);
        }else{
            $typelist=C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid(0);
        }
        $btype = DB::fetch_all('select * from %t where bid=%d  and upid=0 and type=0',array('aljbd_type_brand',$bid));
        
        $service_label = DB::fetch_all('select * from %t where type=1 order by displayorder desc,id asc',array('aljbd_ather'));
        if($goods['is_volume'] == 1) {
            // price_type 1=������� 2=����� 3=����
            $volume_price = DB::fetch_all('select * from %t where goods_id=%d and price_type=1', array('aljbd_goods_volume_price', $gid));
        }
        if($_G['cache']['plugin']['aljbd_bq']['is_aljbd_bq']){
            $biaoqian = DB::fetch_all('select * from %t ',array('aljbd_bq'));
            $jiaobiao = $zhuanti = $dapeishangpin = $autohtml = array();
            foreach($biaoqian as $bq_k => $bq_v){
                if($bq_v['type'] == 1){
                    $jiaobiao[] = $bq_v;
                }else if($bq_v['type'] == 2){
                    $zhuanti[] = $bq_v;
                }else if($bq_v['type'] == 3){
                    if($bq_v['bid'] == $bid){
                        $dapeishangpin[] = $bq_v;
                    }
                    
                }else if($bq_v['type'] == 4){
                    $autohtml[] = $bq_v;
                }
            }
        }
		include template('aljht:admin/goods/addgoods');
	}
}elseif($do == 'del_volume'){
    $goods = C::t('#aljbd#aljbd_goods') -> fetch($gid);

    if($goods['uid'] != $_G['uid'] && !$administrators){
        echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","goods_php_29"))));
        exit;
    }
    if($_GET['vid']){
        DB::query('delete from %t where id=%d',array('aljbd_goods_volume_price',$_GET['vid']));
        echo json_encode(T::ajaxPostCharSet(array('code'=>1)));
        exit;
    }else{
        echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","goods_php_30"))));
        exit;
    }
}elseif($do == 'sku_volume'){
    $goods = C::t('#aljbd#aljbd_goods') -> fetch($gid);

    if($goods['uid'] != $_G['uid'] && !$administrators){
        echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","goods_php_31"))));
        exit;
    }
    if($_GET['vid']){
        DB::query('delete from %t where id=%d',array('aljbd_goods_volume_price',$_GET['vid']));
        echo json_encode(T::ajaxPostCharSet(array('code'=>1)));
        exit;
    }else{
        echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","goods_php_32"))));
        exit;
    }
}elseif($do == 'ajax_btype'){
    if($_GET['dzAdmin'] == 1){
        
        $brandtype=DB::fetch_all('SELECT * FROM %t WHERE store_id=%d and type=0  and upid=0',array('aljbd_type_brand',$bid),'id');
        
    }else{
        $brandtype = DB::fetch_all('select * from %t where bid=%d  and upid=0 and type=0 ',array('aljbd_type_brand',$bid));
    }
    $bstr = '<select name="btypeid" id="btypeid" class="form-control" onchange="lj_btype();"><option value="">'.lang("plugin/aljht","goods_php_33").'</option>';
    foreach($brandtype as $brandv){
        $bstr .= '<option value="'.$brandv['id'].'" >'.$brandv['subject'].'</option>';
    }
    $bstr .= '</select>';
    echo $bstr;
    exit;
}elseif($do == 'ajax_biaoqian_dpsp'){
    $biaoqian = DB::fetch_all('select * from %t where type=3 and bid=%d',array('aljbd_bq',$bid));
    $bstr = '<select name="product_label[]" class="form-control"><option value="">'.'&#35831;&#36873;&#25321;&#25645;&#37197;&#21830;&#21697;'.'</option>';
    foreach($biaoqian as $brandv){
        $bstr .= '<option value="'.$brandv['id'].'" >['.$brandv['id'].']'.$brandv['title'].'</option>';
    }
    $bstr .= '</select>';
    echo $bstr;
    exit;
}elseif($do == 'greply'){
	$currpage=intval($_GET['page'])?intval($_GET['page']):1;
	$perpage=20;
	$start=($currpage-1)*$perpage;
	$num=C::t('#aljgwc#aljbd_comment_goods')->count_by_bid_all($gid);
	$commentlist=C::t('#aljgwc#aljbd_comment_goods')->fetch_all_by_bid_page($gid,$start,$perpage);
	include template($pluginid.':admin/goods/commentlist');
}elseif($do == 'dreply'){
	if($_GET['cid']){
		$del_goods = C::t('#aljbd#aljbd_goods')->fetch($gid);
		if($del_goods['uid'] == $_G['uid'] || $administrators){
            $comment = C::t('#aljgwc#aljbd_comment_goods')->fetch($_GET['cid']);
            if($comment['imgs']){
                $imagesarray = explode('|',$comment['imgs']);
                foreach($imagesarray as $img){
                    unlink($img);
                    T::delete_oss($img);
                }
            }
			C::t('#aljgwc#aljbd_comment_goods')->delete($_GET['cid']);
		}
		echo 1;
		exit;
	}
}elseif($do == 'reply'){
    if(!$administrators){
        $aljht_tips = lang("plugin/aljht","goods_php_34");
        include template('aljht:admin/pogressbar');
        exit;
    }
    $currpage=$_GET['page']?intval($_GET['page']):1;
    $perpage=20;
    $start=($currpage-1)*$perpage;
    $keyword = addcslashes($_GET['search'], '%_');
    $replytable = 'aljbd_comment_goods';
    if(submitcheck('formhash') && empty($keyword)) {
        if ($_GET['sign'] == 1) {
            if (is_array($_GET['delete'])) {
                foreach ($_GET['delete'] as $k => $id) {
                    DB::query('update %t set rubbish=0  where id = %d', array($replytable, $id));
                }
            }
        } else if ($_GET['sign'] == 2) {
            if (is_array($_GET['delete'])) {
                foreach ($_GET['delete'] as $k => $id) {
                    DB::query('update %t set rubbish=1  where id = %d', array($replytable, $id));
                }
            }
        } else {
            if (is_array($_GET['delete'])) {
                foreach ($_GET['delete'] as $k => $id) {
                    DB::query('DELETE FROM %t WHERE id=%d',array($replytable,$id));
                }
            }
        }
        echo '<script>parent.tips(0);</script>';
        exit;
    }

    $currpage=intval($_GET['page'])?intval($_GET['page']):1;
    $perpage=20;
    $start=($currpage-1)*$perpage;
    $con[]= $replytable;
    if($_GET['rubbish'] == 1){
        $where = 'where rubbish=1';
    }else{
        $where = 'where rubbish=0';
    }
    
    if($_GET['search']){
        $con[] ='%' . $keyword . '%';
        $where.=" and content like %s";
    }
    $num=DB::result_first('select count(*) from %t '.$where,$con);
    $where.=" order by id desc limit %d,%d";
    $con[]= $start;
    $con[]= $perpage;
    $commentlist=DB::fetch_all('select * from %t '.$where,$con);
    $pagingurl = getaljurl($geturl,'');
    $paging = _mall_paging($currpage,$num,$perpage,$pagingurl.'&rubbish='.$_GET['rubbish'].'&page=');
    include template($pluginid.':admin/goods/replylist');
}elseif($do == 'del_attr'){
	$del_goods = C::t('#aljbd#aljbd_goods')->fetch($gid);
	if(($_GET['formhash'] == formhash() && $del_goods['uid'] == $_G['uid']) || $administrators){
		if($_GET['type'] == 1 && $_GET['symbol']){
			C::t('#aljht#aljht_attr_value')->delete($_GET['symbol']);
		}elseif($_GET['kid']){
			C::t('#aljht#aljht_attr_key')->delete($_GET['kid']);
			DB::query('delete from %t where kid = %d',array('aljht_attr_value',$_GET['kid']));
		}
	}
	echo '<script>parent.location.href="plugin.php?id=aljht&act=admin&op=goods&do=attr'.$urlmod.'&gid='.$gid.'";</script>';
	exit;
}elseif($do == 'qingkong_sku'){
	$del_goods = C::t('#aljbd#aljbd_goods')->fetch($gid);
	if(($_GET['formhash'] == formhash() && $del_goods['uid'] == $_G['uid']) || $administrators){
        C::t('#aljbd#aljbd_goods')->update($gid,array('attr_key'=>'','attr_value'=>'','attr_sku'=>''));
        echo 1;
        exit;
	}
	echo 0;
    exit;
}elseif($do == 'attr'){
    if($_GET['wm'] == 'yes'){
        if(strtolower(CHARSET) == 'gbk' && !$_G['mobile']){
            $_GET=T::ajaxGetCharSet($_GET);
        }
        define('IN_MOBILE', 2);
	    $_G['mobile'] = 2;
    }
    
	if($goods['other']){
        $other = unserialize($goods['other']);
    }//$other[unified_inventory]
	if(submitcheck('formhash')){
		$name = $_GET['name'];
		$sname = $_GET['sname'];
		$newkey = $_GET['newkey'];
		$newvalue = $_GET['newvalue'];
		$sku_price = $_GET['sku_price'];
		$stock_num = $_GET['stock_num'];
        $sku_marketprice = $_GET['sku_marketprice'];
        $sku_newprice = $_GET['sku_newprice'];
        $sku_logos = $_GET['sku_logo'];
        $card_price = $_GET['card_price'];
        $market_value = $_GET['market_value'];
        $commodity_code = $_GET['commodity_code'];
		if($_GET['sku']){
            //������
            
			if(is_array($sku_price)) {
				if(count($sku_price)>0 && count($sku_price) != DB::result_first('select count(*) from %t where gid=%d',array('aljht_attr_sku',$gid))){
					DB::query('delete from %t where gid = %d',array('aljht_attr_sku',$gid));
                }
                $ii = 1;
				foreach($sku_price as $key=>$name) {
                    $sku_info = DB::result_first('select count(*) from %t where gid=%d and path=%s',array('aljht_attr_sku',$gid,$key));
                    if(strpos($sku_logos[$key],$oss_domain) !== false){
                        $sku_logo = $sku_logos[$key];
                    }else if (is_file($sku_logos[$key])) {
                        $sku_logo = $sku_logos[$key];
                    }else if($sku_logos[$key]){
                        unlink($sku_info['sku_logo']);
                        T::delete_oss($sku_info['sku_logo']);
                        $sku_logo = T::saveimg($sku_logos[$key],$image_path.'logo/');
                    }
                    
                    if($_FILES['fujian']['tmp_name']) {
                        $picname = $_FILES['fujian']['name'][$key];
                        $picsize = $_FILES['fujian']['size'][$key];
                        $file_size = $_G['cache']['plugin']['aljbd_dzfj']['file_size'] ? $_G['cache']['plugin']['aljbd_dzfj']['file_size'] : 1024;
                        $file_format = $_G['cache']['plugin']['aljbd_dzfj']['file_format'] ? $_G['cache']['plugin']['aljbd_dzfj']['file_format'] : '.zip,.rar,.png';
                        if ($picsize/1024>$file_size) {
                            echo "<script>parent.tips('�ϴ��������ܳ���".$file_size."K','');</script>";
                            exit;
                        }
                        if ($picname != "") {
                            $type = strtolower(strrchr($picname, '.'));
                            $fj_name = str_replace($type,'',$picname);
                            
                            $filetype = explode(",",$file_format);
                            if (!in_array($type, $filetype)) {
            
                                echo "<script>parent.tips('���ϴ���׺�ļ�Ϊ".$file_format."','');</script>";
                                exit;
                            }
                            $rand = rand(100, 999);
                            $filepath = $fj_name.'_'.date("Ymd").'_'. $rand . $type;
                            $dir = "source/plugin/aljbd_dzfj/static/file/".date("Ymd").'/';
                            if(!is_dir($dir)) {
                                @mkdir($dir, 0777);
                            }
                            $resfile = $dir. $filepath;
                            if(@copy($_FILES['fujian']['tmp_name'][$key], $resfile)||@move_uploaded_file($_FILES['fujian']['tmp_name'][$key], $resfile)){
                                @unlink($_FILES['fujian']['tmp_name']);
                                if($_G['cache']['plugin']['aljoss']['Access_Key']){

                                    $src = T::oss($resfile, 'aljbd_dzfj',$type,$filepath);
                                    
                                    $resfile=$src;
                                }
                                
                            }
                        }
                    }
                    $data_array = array('marketprice' => $sku_marketprice[$key],'newprice' => $sku_newprice[$key],'sku_logo' => $sku_logo,'saleprice' => $name, 'stock' => $stock_num[$key]);
                    if($resfile){
                        $data_array['fujian'] = $resfile;
                        $data_array['fujian_name'] = $filepath;
                    }
                    if($settings['is_card_price']['value']==1){
                        $data_array['card_price'] = $card_price[$key];
                    }
                    $data_array['market_value'] = $market_value[$key];
                    $data_array['commodity_code'] = $commodity_code[$key] ? $commodity_code[$key] : ($goods['commodity_code'] ? $goods['commodity_code'].'_'.$ii : '');
                    if($sku_info) {
						DB::update('aljht_attr_sku',$data_array , array('gid' => $gid,'path' => $key));
					}else{
                        $data_array['gid'] = $gid;
                        $data_array['path'] = $key;
						$cid=C::t('#aljht#aljht_attr_sku')->insert($data_array,1);
                    }
                    $ii++;
					unset($sku_logo);
					unset($sku_info);
					unset($resfile);
					unset($filepath);
				}
				$gkey = DB::fetch_all('select * from %t where gid = %d order by kid asc',array('aljht_attr_key',$gid));
				$gvalue = DB::fetch_all('select * from %t where gid = %d order by symbol asc',array('aljht_attr_value',$gid));
				$gsku = DB::fetch_all('select * from %t where gid = %d order by sid asc',array('aljht_attr_sku',$gid));
                C::t('#aljbd#aljbd_goods')->update($gid,array('attr_key'=>serialize($gkey),'attr_value'=>serialize($gvalue),'attr_sku'=>serialize($gsku)));
                DB::insert('aljbd_goods_log',array(
                    'gid' => $gid,
                    'addtime' => TIMESTAMP,
                    'uid' => $_G['uid'],
                    'username' => $_G['username'],
                    'goodsinfo' => serialize(C::t('#aljbd#aljbd_goods')->fetch($gid)),
                    'url' => ltrim('plugin.php?'.$_SERVER['QUERY_STRING'],'/')
                ));
                if(!$other[unified_inventory]){
                    C::t('#aljbd#aljbd_goods')->update($gid,array('amount'=>DB::result_first('select sum(stock) from %t where gid=%d',array('aljht_attr_sku',$gid))));
                }
			}else{
				C::t('#aljbd#aljbd_goods')->update($gid,array('attr_key'=>'','attr_value'=>'','attr_sku'=>''));
			}

            if($goods['is_volume'] == 2){
                if($_GET['v_id']){
                    foreach ($_GET['v_id'] as $v_id_key => $v_id_val){
                        foreach ($v_id_val as $t_v_id_k => $t_v_id_v){
                            if($t_v_id_v && $_GET['volume_price'][$v_id_key][$t_v_id_k] > 0 && $_GET['volume_number'][$v_id_key][$t_v_id_k]>1){
                                DB::update('aljbd_goods_volume_price',array('volume_number'=>$_GET['volume_number'][$v_id_key][$t_v_id_k],'volume_price'=>$_GET['volume_price'][$v_id_key][$t_v_id_k],'volume_price_pt'=>$_GET['volume_price_pt'][$v_id_key][$t_v_id_k]),array('id' => $t_v_id_v));
                            }
                        }
                    }
                }
                if($_GET['volume_number']){
                    foreach ($_GET['volume_number'] as $v_n_key => $v_n_val){
                        foreach ($v_n_val as $t_v_n_k => $t_v_n_v){
                            if($_GET['volume_price'][$v_n_key][$t_v_n_k] && $t_v_n_v>1 && !$_GET['v_id'][$v_n_key][$t_v_n_k]){
                                DB::insert('aljbd_goods_volume_price',array('price_type'=>2,'volume_number'=>$t_v_n_v,'volume_price'=>$_GET['volume_price'][$v_n_key][$t_v_n_k],'volume_price_pt'=>$_GET['volume_price_pt'][$v_n_key][$t_v_n_k],'goods_id'=>$gid,'path'=>$v_n_key));
                            }
                        }
                    }
                }
            }
		}else{
			if(is_array($name)) {
				foreach($name as $id=>$value) {
					C::t('#aljht#aljht_attr_key')->update($id,array('name'=>$value));
				}
			}
			if(is_array($sname)) {
				foreach($sname as $id=>$value) {
					C::t('#aljht#aljht_attr_value')->update($id,array('value'=>$value));
				}
			}
			if(is_array($newkey)) {
				foreach($newkey as $key=>$name) {
					if(empty($name)) {
						continue;
					}
					$cid=C::t('#aljht#aljht_attr_key')->insert(array('gid' => $gid, 'name' => $name,'uid'=>$goods['uid']),1);
				}
			}
			if(is_array($newvalue)) {
				foreach($newvalue as $cid=>$subcat) {
					foreach($subcat as $key=>$value) {
						if(empty($value)) {
							continue;
						}
						C::t('#aljht#aljht_attr_value')->insert(array('gid' => $gid,'kid' => $cid, 'value' => $value,'uid'=>$goods['uid']),1);
					}
					
				}
			}
		}
		echo '<script>parent.location.href="plugin.php?id=aljht&act=admin&op=goods&do=attr'.$urlmod.'&gid='.$gid.'";</script>';
		exit;
	}else{
        
		$gattrkey = unserialize($goods['attr_key']);
		$gattrvalue = unserialize($goods['attr_value']);
		$gvalue_attr = attrsku($gattrkey,$gattrvalue);
		
		foreach($gattrvalue as $gk => $gv){
			$gattr_value[$gv['symbol']] = $gv;
		}
		$gattrsku = unserialize($goods['attr_sku']);
		foreach($gattrsku as $k => $v){
			$gskuvalue[$v['path']] = $v;
        }
        
		$attr_value = C::t('#aljht#aljht_attr_value')->range('','','asc');
		$attrkey = DB::fetch_all('select * from %t where gid=%d order by kid asc',array('aljht_attr_key',$gid));
		$attrvalue = DB::fetch_all('select * from %t where gid=%d order by symbol asc',array('aljht_attr_value',$gid));
		$value_attr = attrsku($attrkey,$attrvalue);
		
		$skulist = DB::fetch_all('select * from %t where gid=%d order by sid asc',array('aljht_attr_sku',$gid));
		foreach($skulist as $k => $v){
			$skuvalue[$v['path']] = $v;
		}
		$navtitle = lang("plugin/aljht","goods_php_35");
		include template($pluginid.':admin/goods/attr');
	}
}else{
    if($_G[mobile]){
        dheader("location: plugin.php?id=aljbd&act=goodslist");
        exit;
    }
	$keyword = addcslashes($_GET['search'], '%_');
	if(submitcheck('formhash') && empty($keyword)){
        savecache('aljbd_rec_goods', '');//�Ƽ���Ʒ �������
		if($administrators){
			if(is_array($_GET['displayorder'])) {
				foreach($_GET['displayorder'] as $k => $id) {
                    
					DB::query('update %t set displayorder=%d,buyamount=%d,price1=%s  where id = %d',array(
					    'aljbd_goods',
                        $id,
                        $_GET['buyamount'][$k],
                        $_GET['price1'][$k],
                        $k
                    ));
				}
			}
			if($_GET['sign'] == 3){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						DB::query('update %t set sign=1  where id = %d',array('aljbd_goods',$id));
                        $brand = C::t('#aljbd#aljbd_goods')->fetch($id);
                        notification_add($brand['uid'], 'system',str_replace('{username}',$brand['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&bid='.$brand['bid'].'&gid='.$id.'">'.$brand['name'].'</a>',$_G['cache']['plugin']['aljbd']['goodtips'])),array('from_idtype'  => 'aljbd_goods','from_id' => $brand['id']));
                        if($_G['cache']['plugin']['aljbd']['time']){
                            $email_first=C::t("common_member")->fetch($brand['uid']);
                            $email=$email_first['email'];

                            if($email_first['email']){
                                $m=str_replace('{username}',$brand['username'],str_replace('{shopname}','<a href="'.$_G['siteurl'].'/plugin.php?id=aljbd&act=goodview&bid='.$brand['bid'].'&gid='.$id.'">'.$brand['name'].'</a>',$_G['cache']['plugin']['aljbd']['goodtips']));
                                newsendmail_cron($email,$_G['cache']['plugin']['aljbd']['mailtitle'],$m);
                            }
                        }
					}
				}
			}else if($_GET['sign'] == 4){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						DB::query('update %t set sign=0  where id = %d',array('aljbd_goods',$id));
					}
				}
			}else if($_GET['sign'] == 6){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						DB::query('update %t set state=0  where id = %d',array('aljbd_goods',$id));
					}
				}
			}else if($_GET['sign'] == 7){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						DB::query('update %t set state=1  where id = %d',array('aljbd_goods',$id));
					}
				}
			}else if($_GET['sign'] == 2){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						C::t('#aljbd#aljbd_goods')->update($id,array('rubbish'=>'1'));//�������վ
						//����
						if($is_plugin_gwc){
							DB::update('aljbd_comment_goods',array('rubbish'=>0), array('gid'=>$id));
						}
					}
				}
			}else if($_GET['sign'] == 10){
                if(is_array($_GET['delete'])) {
                    $send_goods_tips = lang("plugin/aljht","goods_php_36").'{shopname}'.lang("plugin/aljht","goods_php_37").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=goods&mod=my">'.lang("plugin/aljht","goods_php_38").'</a>';
                    foreach($_GET['delete'] as $k => $id) {
                        DB::query('update %t set sh_status=0,reason=%s  where id = %d',array('aljbd_goods',$_GET['reason'][$id],$id));
                        $brand = C::t('#aljbd#aljbd_goods')->fetch($id);
                        $reason = $_GET['reason'][$id] ? lang("plugin/aljht","goods_php_39").$_GET['reason'][$id] : '';
                        notification_add($brand['uid'], 'system',str_replace(array('{shopname}','{reason}'),array($brand['name'],$reason),$send_goods_tips),array('from_idtype'  => 'aljbd_goods','from_id' => $brand['id']));
                        unset($reason);
                    }
                }
            }else if($_GET['sign'] == 11){
                $send_goods_tips = lang("plugin/aljht","goods_php_40").'{shopname}'.lang("plugin/aljht","goods_php_41").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=goods&mod=my">'.lang("plugin/aljht","goods_php_42").'</a>';
                if(is_array($_GET['delete'])) {
                    foreach($_GET['delete'] as $k => $id) {
                        DB::query('update %t set sh_status=2,reason=%s  where id = %d',array('aljbd_goods',$_GET['reason'][$id],$id));
                        $brand = C::t('#aljbd#aljbd_goods')->fetch($id);
                        $reason = $_GET['reason'][$id] ? lang("plugin/aljht","goods_php_43").$_GET['reason'][$id] : '';
                        notification_add($brand['uid'], 'system',str_replace(array('{shopname}','{reason}'),array($brand['name'],$reason),$send_goods_tips),array('from_idtype'  => 'aljbd_goods','from_id' => $brand['id']));
                        unset($reason);
                    }
                }
            }else if($_GET['sign'] == 99){
                if(is_array($_GET['delete'])) {
                    
					foreach($_GET['delete'] as $k => $id) {
                        DB::query('update %t set amount=%d  where id = %d',array('aljbd_goods',$_GET['amount'][$k],$id));
                        DB::insert('aljbd_goods_log',array(
                            'gid' => $k,
                            'addtime' => TIMESTAMP,
                            'uid' => $_G['uid'],
                            'username' => $_G['username'],
                            'goodsinfo' => serialize(C::t('#aljbd#aljbd_goods')->fetch($k)),
                            'url' => ltrim('plugin.php?'.$_SERVER['QUERY_STRING'],'/')
                        ));
					}
				}
            }
		}else{
            
			if($_GET['sign'] == 2){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						C::t('#aljbd#aljbd_goods')->update($id,array('rubbish'=>'1'));//�������վ
						//����
						if($is_plugin_gwc){
							DB::update('aljbd_comment_goods',array('rubbish'=>0), array('gid'=>$id));
						}
					}
				}
			}else if($_GET['sign'] == 6){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						DB::query('update %t set state=0  where id = %d',array('aljbd_goods',$id));
					}
				}
			}else if($_GET['sign'] == 7){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						DB::query('update %t set state=1  where id = %d',array('aljbd_goods',$id));
					}
				}
			}else if($_GET['sign'] == 99){
                if(is_array($_GET['delete'])) {
                    foreach($_GET['delete'] as $k => $id) {
                        
                        DB::query('update %t set amount=%d  where id = %d',array('aljbd_goods',$_GET['amount'][$k],$id));
                        DB::insert('aljbd_goods_log',array(
                            'gid' => $k,
                            'addtime' => TIMESTAMP,
                            'uid' => $_G['uid'],
                            'username' => $_G['username'],
                            'goodsinfo' => serialize(C::t('#aljbd#aljbd_goods')->fetch($k)),
                            'url' => ltrim('plugin.php?'.$_SERVER['QUERY_STRING'],'/')
                        ));
					}
				}
            }
		}
		echo '<script>parent.tips(0);</script>';
		exit;
	}

	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=20;
	$start=($currpage-1)*$perpage;
	
    $con[]='aljbd_goods';
    
	if($administrators){
        $where=" where rubbish=0";
        
        $no_num = DB::result_first('select count(*) from %t '.$where.'  and sh_status=1',$con);
	}else{
		$where=" where rubbish=0 and uid = %d";
		$con[] = $_G['uid'];
    }
    if($_GET['dzAdmin'] != 1){
        $con[]=0;
        $where.=' and store_id=%d';
    }else if($store_id > 0){
        $con[]=$store_id;
        $where.=' and store_id=%d';
    }
    if($administrators){
        $no_num = DB::result_first('select count(*) from %t '.$where.'  and sh_status=1',$con);
    }
	
	if($do == 'rec'){
		$where.=' and sign=1';
	}
    if($do == 'grounding'){
        $where.=' and state=0';
    }
    if($do == 'no'){
        $where.=' and sh_status=1';
    }else if($do == 'lose'){
        $where.=' and sh_status=2';
    }else{
        $where.=' and sh_status=0';
    }
    if($do == 'undercarriage'){
        $where.=' and state=1';
    }
    if($do == 'distribution'){
        $where.=' and is_distribution=1';
    }

    if($_GET['type']){
        $con[]=$_GET['type'];
        $where.=' and type=%d';
    }
    if($_GET['subtype']){
        $con[]=$_GET['subtype'];
        $where.=' and subtype=%d';
    }
    if($_GET['bid']){
        $con[]=$_GET['bid'];
        $where.=' and bid=%d';
    }
    if($_GET['subtype3']){
        $con[]=$_GET['subtype3'];
        $where.=' and subtype3=%d';
    }
    if($_GET['commodity_type']){
        
        if($_GET['commodity_type'] == 999){
            $con[]=0;
            $where.=' and commodity_type=%d';
        }else{
            $con[]=$_GET['commodity_type'];
            $where.=' and commodity_type=%d';
        }
        
        $urlmod .= '&commodity_type='.$_GET['commodity_type'];
    }
    if($_GET['sh_status']){
        $con[]=$_GET['sh_status'] == 2 ? 0 : $_GET['sh_status'];
        $where.=' and sh_status=%d';
    }
    if($_GET['p_type'] == 1){
        $where.=' and new_price>0';
    }else if($_GET['p_type'] == 2){
        $where.=' and card_price>0';
    }
    if($_GET['state']){
        $con[]=$_GET['state'] == 2 ? 0 : $_GET['state'];
        $where.=' and state=%d';
    }
    if($_GET['search']){
        if($_GET['g_type'] == 1){
            $con[] = $_GET['search'];
            $where.=" and id = %d";
        }else if($_GET['g_type'] == 2){
            $con[] = $_GET['search'];
            $where.=" and bid = %d";
        }else if($_GET['g_type'] == 3){
            $con[] = $_GET['search'];
            $where.=" and store_id = %d";
        }else{
            //$con[] ='%' . $keyword . '%';
		    //$where.=" and name like %s";
            require_once libfile('function/search');
            $srcharr = searchkey($_GET['search'],"name LIKE '%{text}%'", true);
            $srchtxt = $srcharr[0];
            $sqlsrch .= $srcharr[1];
            $sql.=" $sqlsrch ";
            $con[]=$sql;
		    $where.=' %i';
        }
	}
	$num = DB::result_first('select count(*) from %t '.$where,$con);
	$con[]=$start;
	$con[]=$perpage;
	if($_GET['order'] == 1){
	    $where .= ' ORDER BY amount asc';
    }else if($_GET['order'] == 2){
        $where .= ' ORDER BY buyamount desc';
    }else{
        $where .= ' ORDER BY displayorder desc,id desc,view desc';
    }
    $geturl['order'] = $_GET['order'];
    $geturl['g_type'] = $_GET['g_type'];
    $geturl['type'] = $_GET['type'];
    $geturl['subtype'] = $_GET['subtype'];
    $geturl['subtype3'] = $_GET['subtype3'];
    $geturl['commodity_type'] = $_GET['commodity_type'];
    $geturl['state'] = $_GET['state'];
    $geturl['bid'] = $_GET['bid'];
    
    $pagingurl = getaljurl($geturl,'');
    
    $paging = _mall_paging($currpage,$num,$perpage,$pagingurl.$urlmod.'&page=');
	$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' limit %d,%d',$con);
	if($_GET['dzAdmin'] == 1){//�ŵ귢����Ʒ
        $onetypelist=C::t('#aljtsc#aljtsc_type')->fetch_all_by_upid_admin(0);
    }else{
        $onetypelist=C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid(0);
    }
	include template('aljht:admin/goods/goods');
}

function attrsku($gattrkey,$gattrvalue){
	if($gattrkey){
		foreach($gattrkey as $sku){
			foreach($gattrvalue as $value){
				if($value['kid'] == $sku['kid']){
					$gsku_tmp[] = $value['symbol'];
				}
			}
			if($gsku_tmp){
				$gnewsku[] = $gsku_tmp;
			}
			unset($gsku_tmp);
		}
	}
	foreach(get_all($gnewsku) as $v){
		$sort_asc[] = $v['0'];
	}
	$value_attr = get_all($gnewsku);
	array_multisort($sort_asc, SORT_ASC, $value_attr);
	return $value_attr;
}
//From: dis'.'m.tao'.'bao.com
?>