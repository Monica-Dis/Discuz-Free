<?php


if(count($staff) > 1){
    foreach($staff as $st_v){
        $store_ids[] = $st_v['store_id'];
    }
    
    $bdlist = DB::fetch_all('select * from %t where id in (%n)',array('aljbd',$store_ids));
    foreach ($bdlist as $bk => $bv){
        if($bv['status'] == 1){
            if($bv['vipendtime']){
                if($bv['vipendtime'] > TIMESTAMP){
                    $bdlist[$bk]['vipendtimes'] = dgmdate($bv['vipendtime'],'Y-m-d H:i:s').lang('plugin/aljbd','member_php_1');
                }else{
                    $bdlist[$bk]['vipendtimes'] = lang('plugin/aljbd','member_php_2');
                }

            }else if($bv['vipid'] && $bv['vipendtime']==0){
                $bdlist[$bk]['vipendtimes'] = lang('plugin/aljbd','member_php_3');
            }
            if($bv['vipid']){
                $bdlist[$bk]['grouptitle'] = DB::result_first('select title from %t where id=%d',array('aljbd_vip',$bv['vipid']));
            }
        }else if($bv['status'] == 2){
            if($bv['vipid']){
                $bdlist[$bk]['grouptitle'] = DB::result_first('select title from %t where id=%d',array('aljbd_vip',$bv['vipid']));
                $bdlist[$bk]['vipendtimes'] = lang('plugin/aljbd','member_php_5');
            }

        }else{
            if($bv['vipid']){
                $bdlist[$bk]['grouptitle'] = DB::result_first('select title from %t where id=%d',array('aljbd_vip',$bv['vipid']));
                $bdlist[$bk]['vipendtimes'] = lang('plugin/aljbd','member_php_4');
            }

        }
        $sign=DB::result_first("select sign from ".DB::table('aljbd_attestation')." where sign=1 and bid=".$bv['id']);
        if($sign){
            $bdlist[$bk]['v'] = 1;
        }
        if($_G['cache']['plugin']['aljbzj']['is_aljbzj']){
            $bzj_info = DB::fetch_first('select * from %t where uid=%d and bid=%d ',array('aljbzj',$bv['uid'],$bv['id']));
            if($bzj_info['price']>0){
                $bdlist[$bk]['bond'] = 1;
            }
        }
        if($typelist[$bv['subtype3']]['subject']){
            $bdlist[$bk]['typename'] = $typelist[$bv['subtype3']]['subject'];
        }else if($typelist[$bv['subtype']]['subject']){
            $bdlist[$bk]['typename'] = $typelist[$bv['subtype']]['subject'];
        }else{
            $bdlist[$bk]['typename'] = $typelist[$bv['type']]['subject'];
        }
        if($bv['status'] == 0){
            $bdlist[$bk]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_1');
        }else if($bv['status'] == 3){
            $bdlist[$bk]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_2');
        }else if($bv['status'] == 4){
            $bdlist[$bk]['sh_status_text'] = '&#24050;&#20851;&#38381;';
        }else{
            $bdlist[$bk]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_3');
        }
        $u_name = getuserbyuid($bv['uid']);
        $bdlist[$bk]['username'] = $u_name['username'];
        unset($u_name);
        unset($sign);
        unset($bzj_info);
    }
}else if(count($staff) == 1){
    dheader('Location: plugin.php?id=aljbd&act=member_view&bid='.$staff[0]['store_id']);
    exit;
}else{
    dheader('Location: plugin.php?id=aljbdx&act=user');
    exit;
}
if($bdlist){
    $store_list = json_encode(T::ajaxPostCharSet($bdlist));
}else{
    $store_list = 1;
}
$navtitle = lang("plugin/aljht","staffStoreList_php_1");
if(!$_G['mobile']){
    if(strtolower(CHARSET) == 'gbk'){
		$_GET=T::ajaxGetCharSet($_GET);
	}
    $_G['setting']['hookscript'] = array();
    define('IN_MOBILE', 2);
	$_G['mobile'] = 2;
}

include template('aljht:admin/staffStoreList/staffStoreList');

?>