<?php
$doarray = array('setting','admin','seo','brandtype','region','cache','upgrade');
$do = !in_array($do, $doarray) ? 'setting' : $do;
$identity = $_GET['identity']?$_GET['identity']:'aljbd';
$dourl = $pluginurl.'&act='.$act.'&op='.$op.'&do='.$do.'&identity='.$identity.$typeurl;


require_once 'source/plugin/aljht/include/admin/'.$op.'/'.$do.'.php';
?>