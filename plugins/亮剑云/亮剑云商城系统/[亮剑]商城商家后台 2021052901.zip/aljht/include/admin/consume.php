<?php
if($bid){
    $bd=C::t('#aljbd#aljbd')->fetch($bid);
}
if($do == 'sh_status'){
    if($_GET['formhash'] == FORMHASH) {
        if(!$administrators && $_GET[i] != 1){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","consume_php_3"))));
            exit;
        }
        if(!$_GET[cashid]){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","consume_php_4"))));
            exit;
        }

        $goods = C::t('#aljbd#aljbd_consume')->fetch($_GET[cashid]);
        if(!$goods){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","consume_php_5"))));
            exit;
        }

        if(strtolower(CHARSET) == 'gbk' && !$_G[mobile] && $_GET[message]){
            $_GET[message] = diconv($_GET[message],'utf-8','gbk');
        }

        if(DB::query('update %t set status=%d,reason=%s  where id = %d and status = %d',array('aljbd_consume',$_GET[status],$_GET[message],$_GET[cashid],$goods['status']))){
            if($_GET[status] == 2){
                $send_goods_tips = lang("plugin/aljht","consume_php_6").'{shopname}'.lang("plugin/aljht","consume_php_7").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=consume&mod=my">'.lang("plugin/aljht","consume_php_8").'</a>';
            }else{
                $send_goods_tips = lang("plugin/aljht","consume_php_9").'{shopname}'.lang("plugin/aljht","consume_php_10").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=consume&mod=my">'.lang("plugin/aljht","consume_php_11").'</a>';
            }
            $reason = $_GET[message] ? lang("plugin/aljht","consume_php_12").$_GET[message] : '';
            notification_add(
                $goods['uid'],
                'system',str_replace(array('{shopname}','{reason}'),array($goods['subject'],$reason), $send_goods_tips),
                array('from_idtype'  => 'aljbd_consume','from_id' => $goods['id'])
            );
            echo json_encode(T::ajaxPostCharSet(array('code'=>1,'text'=>lang("plugin/aljht","consume_php_13"))));
            exit;
        }else{
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","consume_php_14"))));
            exit;
        }
    }else{
        echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","consume_php_15"))));
        exit;
    }
}else if($do == 'editconsume' || $do == 'addconsume'){
	$consume = C::t('#aljbd#aljbd_consume') -> fetch($cid);
    if($_G['cache']['plugin']['aljbzj']['is_force_pay'] && $bzj_info['price'] <= 0 && $bid && file_exists("source/plugin/aljbzj/template/force_pay_tips.htm") && !$administrators){
        if(submitcheck('formhash')) {
            $post = 1;
            include template('aljbzj:force_pay_tips');
            exit;
        }
    }
    if($do == 'addconsume'){
        if($bd['vipid']){
            $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$bd['vipid']));
            $brandnum['consume']=$vipdata['consume'];
            $bnum = C::t('#aljbd#aljbd_consume')->count_by_uid_bid($_G['uid']);
            if ($brandnum['consume'] && !$administrators) {
                if ($brandnum['consume'] == $checksign) {
                    if(submitcheck('formhash')){
                        echo "<script>parent.tips('".lang('plugin/aljbd','noauth')."','');</script>";
                    }else {
                        $aljht_tips = lang('plugin/aljbd', 'noauth') . $consumetips;
                        include template('aljht:admin/pogressbar');
                    }
                    exit;
                }
                if ($bnum >= $brandnum['consume']) {
                    if(submitcheck('formhash')){
                        echo "<script>parent.tips('".lang('plugin/aljbd', 'groups_1') . $brandnum['consume'] . lang('plugin/aljbd', 'groups_4')."','');</script>";
                    }else {
                        $aljht_tips = lang('plugin/aljbd', 'groups_1') . $brandnum['consume'] . lang('plugin/aljbd', 'groups_4') . $consumetips;
                        include template('aljht:admin/pogressbar');
                    }
                    exit;
                }
            }
        }
        if($yhzqx) {
            $bnum = C::t('#aljbd#aljbd_consume')->count_by_uid_bid($_G['uid']);
            if ($brandnum['consume'] && !$administrators) {
                if ($brandnum['consume'] == $checksign) {
                    if(submitcheck('formhash')){
                        echo "<script>parent.tips('".lang('plugin/aljbd','noauth')."','');</script>";
                    }else {
                        $aljht_tips = lang('plugin/aljbd', 'noauth') . $consumetips;
                        include template('aljht:admin/pogressbar');
                    }
                    exit;
                }
                if ($bnum >= $brandnum['consume']) {
                    if(submitcheck('formhash')){
                        echo "<script>parent.tips('".lang('plugin/aljbd', 'groups_1') . $brandnum['consume'] . lang('plugin/aljbd', 'groups_4')."','');</script>";
                    }else {
                        $aljht_tips = lang('plugin/aljbd', 'groups_1') . $brandnum['consume'] . lang('plugin/aljbd', 'groups_4') . $consumetips;
                        include template('aljht:admin/pogressbar');
                    }
                    exit;
                }
            }
        }
    }
	if(submitcheck('formhash')){
        if($_GET['coupon_type'] < 7){
            $yes_coupon_type = 1;
        }
        if($yes_coupon_type) {
            if (empty($bid)) {
                if ($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
                    echo '<script>parent.tips("'.lang("plugin/aljht","consume_php_1").'","");</script>';
                    exit;
                } else {
                    echo '<script>parent.tips("'.lang("plugin/aljht","consume_php_2").'","");</script>';
                    exit;
                }
            }
        }
		if($settings['is_attes']['value'] && $yes_coupon_type){
			$sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
			if(!$sign){
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('&#24215;&#38138;&#24517;&#39035;&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#20248;&#24800;&#21048;','');</script>";
					exit;
				}else{
					echo "<script>parent.tips('&#24215;&#38138;&#24517;&#39035;&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#20248;&#24800;&#21048;','');</script>";
					exit;
				}
			}
		}
		if((!$_GET['logo'] || (!$_FILES['logo']['tmp_name'] && $_GET['compress'])) && $do != 'editconsume'){
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljbd','logo')."','');</script>";
				exit;
			}else{
				echo "<script>parent.tips('".lang('plugin/aljbd','logo')."','');</script>";
				exit;
			}
			
		}
        if($_GET['copy'] == '1'){//������ƷͼƬ����
            if($_GET['logo']){
                $logo = T::saveimg($_GET['logo'],$image_path.'consume/');
            }
        }else{
            if($_GET['compress'] == '1'){
                if($_FILES['logo']['tmp_name']) {
                    $picname = $_FILES['logo']['name'];
                    $picsize = $_FILES['logo']['size'];
                
                    if ($picname != "") {
                        $type = strtolower(strrchr($picname, '.'));
                        if ($type != ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
                            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                                echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
                                exit;
                            }else{
                                echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
                                exit;
                            }
                        }
                        if (($picsize/1024)>$_G['cache']['plugin']['aljbd']['img_size']) {
                            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                                echo "<script>parent.tips('".lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB'."','');</script>";
                                exit;
                            }else{
                                echo "<script>parent.tips('".lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB'."','');</script>";
                                exit;
                            }
                        }
                        $rand = rand(100, 999);
                        $pics = date("YmdHis") . $rand . $type;
                        $img_dir = $image_path."consume/".date('Ymd',TIMESTAMP).'/';
                        if (!is_dir($img_dir)) {
                            mkdir($img_dir);
                        }
                        $logo = $img_dir.$pics;
                        if(@copy($_FILES['logo']['tmp_name'], $logo)||@move_uploaded_file($_FILES['logo']['tmp_name'], $logo)){
                            if($_G['cache']['plugin']['aljbd']['iswatermark']){
                                $image->Watermark(DISCUZ_ROOT.'./'.$logo,'', 'forum');
                            }
                            if (file_exists($logo)) {
                                if($_G['cache']['plugin']['aljoss']['Access_Key']){
                                    $logo = T::oss($logo, 'aljbd');
                                }
                            }
                            @unlink($_FILES['logo']['tmp_name']);
                        }
                    }
                }
            }else{
                if ($_GET['pic']) {
                    foreach ($_GET['pic'] as $tmp_key => $tmp_value) {
                        if (strpos($tmp_value,"base64") === false) {
                            $logo = $tmp_value;
                        } else {
                            unlink($consume['pic']);
                            T::delete_oss($consume['pic']);
                            $logo = T::saveimg($tmp_value,$image_path.'consume/');

                        }
                    }
                }else if($_GET['logo']){
                    if (strpos($_GET['logo'],"base64") === false) {
                        $logo = $_GET['logo'];
                    } else {
                        unlink($consume['pic']);
                        T::delete_oss($consume['pic']);
                        $logo = T::saveimg($_GET['logo'],$image_path.'consume/');
                    }
                }
            }
		}
		$insertarray=array(
			'subject'=>$_GET['name'],
			'bid'=>$bid,
			'jieshao'=>$_GET['jieshao'],
			'xianzhi'=>$_GET['xianzhi'],
			'end'=>strtotime($_GET['end']),
			'mianze'=>$_GET['mianze'],
			'type'=>$_GET['type'],
			'subtype'=>$_GET['subtype'],
            'region'=>$bd['region'],
            'region1'=>$bd['region1'],
            'subregion'=>$bd['subregion'],
		);
		if($_G['cache']['plugin']['aljgwc']['aljbd']){
            if($_G['cache']['plugin']['aljsyh']['is_aljsyh']) {
                require_once 'source/plugin/aljsyh/include/addconsume.php';
            }else{
                if (!$_GET['full'] || !$_GET['reduction']) {
                    if ($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
                        echo "<script>parent.tips('&#28385;&#20943;&#37329;&#39069;&#24517;&#39035;&#22635;&#20889;','');</script>";
                        exit;
                    } else {
                        echo "<script>parent.tips('&#28385;&#20943;&#37329;&#39069;&#24517;&#39035;&#22635;&#20889;','');</script>";
                        exit;
                    }
                }
                $insertarray['full'] = $_GET['full'];
                $insertarray['reduction'] = $_GET['reduction'];
            }

        }
        if($settings['is_form']['value'] && $do == 'addconsume'){
            if(DB::result_first('select * from %t where subject = %s and bid=%d',array('aljbd_consume',$_GET['name'],$bid))){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#20248;&#24800;&#21048;&#24050;&#23384;&#22312;','');</script>";
                    exit;
                }else{
                    echo "<script>parent.tips('&#20248;&#24800;&#21048;&#24050;&#23384;&#22312;','');</script>";
                    exit;
                }
            }
            if(!valid_token($_GET['aljbd_consume_token'],getcookie('aljbd_consume_token'),'aljbd_consume_token')){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#27491;&#22312;&#21069;&#24448;&#20248;&#24800;&#21048;&#31649;&#29702;',function(){parent.location.href='plugin.php?id=aljbd&act=consumelist';});</script>";
                    exit;
                }else{
                    echo "<script>parent.tips('&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#27491;&#22312;&#21069;&#24448;&#20248;&#24800;&#21048;&#31649;&#29702;','plugin.php?id=aljbd&act=consumelist')</script>";
                    exit;
                }
            }
        }
		//$bd=C::t('#aljbd#aljbd')->fetch($bid);
        if($yes_coupon_type) {
            $insertarray['uid'] = $bd['uid'];
            $insertarray['username'] = $bd['username'];
        }else{
            $insertarray['uid'] = $_G['uid'];
            $insertarray['username'] = $_G['username'];
        }
		if($consume && !$_GET['copy']){
			if($logo){
                
				$insertarray['pic']=$logo;
			}
            C::t('#aljbd#aljbd_consume')->update($cid,$insertarray);
            savecache('aljbd_rec_consume', '');//�Ƽ��Ż�ȯ ��ջ���
		}else{

			//$insertarray['start'] = TIMESTAMP;
			$insertarray['dateline'] = TIMESTAMP;
			$insertarray['pic']=$logo;
            if($vipdata['is_consume'] >0 && $yes_coupon_type && !$administrators){
                require_once 'source/plugin/aljht/include/aljbd/addconsume_send.php';
            }
			$insertid=C::t('#aljbd#aljbd_consume')->insert($insertarray,true);

		}
        $sh_tips = $sh_tips ? $sh_tips : lang('plugin/aljbd','s53');
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".$sh_tips."',function(){parent.location.href='plugin.php?id=aljbd&act=consumeview&bid=".$bid."&cid=" . $insertid . "';});</script>";
			exit;
		}else{
           
			echo "<script>parent.tips('".$sh_tips."','plugin.php?id=aljht&act=admin&op=consume".$urlmod."');</script>";
			exit;
		}
	}else{
		if($consume['uid']!=$_G['uid'] && $do == 'editconsume' && !$administrators){
            $aljht_tips = lang('plugin/aljbd','s20');
            include template('aljht:admin/pogressbar');
            exit;
		}

        if($settings['is_attes']['value'] && !$settings['is_post_btn']['value']){
            $sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
            if(!$sign){
                $aljht_tips = '&#24215;&#38138;&#24517;&#39035;&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#20248;&#24800;&#21048;';
                include template('aljht:admin/pogressbar');
                exit;
            }
        }
		$typelist=C::t('#aljbd#aljbd_type_consume')->fetch_all_by_upid(0);
		if($administrators){
			$bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','','');//����Ա
		}else{
			$bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','',$_G['uid']);//����
		}

		include template('aljht:admin/consume/addconsume');
	}
}elseif($do == 'creply'){
	$currpage=intval($_GET['page'])?intval($_GET['page']):1;
	$perpage=20;
	$start=($currpage-1)*$perpage;
	$num=C::t('#aljbd#aljbd_comment_consume')->count_by_bid_all($cid);
	$commentlist=C::t('#aljbd#aljbd_comment_consume')->fetch_all_by_bid_page($cid,$start,$perpage);
	include template($pluginid.':admin/consume/commentlist');
}elseif($do == 'dreply'){
	if($_GET['cid']){
		$del_consume = C::t('#aljbd#aljbd_consume')->fetch($nid);
		if($del_consume['uid'] == $_G['uid'] || $administrators){
			C::t('#aljbd#aljbd_comment_consume')->delete($_GET['cid']);
		}
		echo 1;
		exit;
	}
}elseif($do == 'reply'){
    if(!$administrators){
        $aljht_tips = lang("plugin/aljht","consume_php_16");
        include template('aljht:admin/pogressbar');
        exit;
    }
    $currpage=$_GET['page']?intval($_GET['page']):1;
    $perpage=20;
    $start=($currpage-1)*$perpage;
    $keyword = addcslashes($_GET['search'], '%_');
    $replytable = 'aljbd_comment_consume';
    if(submitcheck('formhash') && empty($keyword)) {
        if ($_GET['sign'] == 1) {
            if (is_array($_GET['delete'])) {
                foreach ($_GET['delete'] as $k => $id) {
                    DB::query('update %t set status=1  where id = %d', array($replytable, $id));
                }
            }
        } else if ($_GET['sign'] == 2) {
            if (is_array($_GET['delete'])) {
                foreach ($_GET['delete'] as $k => $id) {
                    DB::query('update %t set rubbish=1  where id = %d', array($replytable, $id));
                }
            }
        } else {
            if (is_array($_GET['delete'])) {
                foreach ($_GET['delete'] as $k => $id) {
                    DB::query('update %t set status=0  where id = %d', array($replytable, $id));
                }
            }
        }
        echo '<script>parent.tips(0);</script>';
        exit;
    }

    $currpage=intval($_GET['page'])?intval($_GET['page']):1;
    $perpage=20;
    $start=($currpage-1)*$perpage;
    $con[]= $replytable;
    $where = 'where rubbish=0';
    if($_GET['search']){
        $con[] ='%' . $keyword . '%';
        $where.=" and content like %s";
    }
    $num=DB::result_first('select count(*) from %t '.$where,$con);
    $where.=" order by id desc limit %d,%d";
    $con[]= $start;
    $con[]= $perpage;
    $commentlist=DB::fetch_all('select * from %t '.$where,$con);
    $pagingurl = getaljurl($geturl,'');
    $paging = _mall_paging($currpage,$num,$perpage,$pagingurl.'&page=');
    include template($pluginid.':admin/consume/replylist');
}else{
    if($_G[mobile]){
        dheader("location: plugin.php?id=aljbd&act=consumelist");
        exit;
    }
	$keyword = addcslashes($_GET['search'], '%_');
	if(submitcheck('formhash') && empty($keyword)){
        savecache('aljbd_rec_consume', '');//�Ƽ��Ż�ȯ ��ջ���
		if($administrators){
			if($_GET['sign'] == 3){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						DB::query('update %t set sign=1  where id = %d',array('aljbd_consume',$id));
					}
				}
			}else if($_GET['sign'] == 4){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						DB::query('update %t set sign=0  where id = %d',array('aljbd_consume',$id));
					}
				}
			}else if($_GET['sign'] == 2){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						C::t('#aljbd#aljbd_consume')->update($id,array('rubbish'=>'1'));
					}
				}
			}else if($_GET['sign'] == 6){
                if(is_array($_GET['delete'])) {
                    foreach($_GET['delete'] as $k => $id) {
                        DB::query('update %t set status=0  where id = %d',array('aljbd_consume',$id));
                    }
                }
            }else if($_GET['sign'] == 7){
                if(is_array($_GET['delete'])) {
                    foreach($_GET['delete'] as $k => $id) {
                        DB::query('update %t set status=3  where id = %d',array('aljbd_consume',$id));
                    }
                }
            }else if($_GET['sign'] == 1){
                $send_goods_tips = lang("plugin/aljht","consume_php_17").'{shopname}'.lang("plugin/aljht","consume_php_18").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=consume&mod=my">'.lang("plugin/aljht","consume_php_19").'</a>';
                if(is_array($_GET['delete'])) {
                    foreach($_GET['delete'] as $k => $id) {
                        DB::query('update %t set status=2,reason=%s  where id = %d',array('aljbd_consume',$_GET['reason'][$id],$id));
                        $brand = C::t('#aljbd#aljbd_consume')->fetch($id);
                        $reason = $_GET['reason'][$id] ? lang("plugin/aljht","consume_php_20").$_GET['reason'][$id] : '';
                        notification_add($brand['uid'], 'system',str_replace(array('{shopname}','{reason}'),array($brand['subject'],$reason),$send_goods_tips),array('from_idtype'  => 'aljbd_consume','from_id' => $brand['id']));
                        unset($reason);
                    }
                }
            }else{
                if(is_array($_GET['delete'])) {
                    $send_goods_tips = lang("plugin/aljht","consume_php_21").'{shopname}'.lang("plugin/aljht","consume_php_22").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=consume&mod=my">'.lang("plugin/aljht","consume_php_23").'</a>';
                    foreach($_GET['delete'] as $k => $id) {
                        DB::query('update %t set status=0,reason=%s  where id = %d',array('aljbd_consume',$_GET['reason'][$id],$id));
                        $brand = C::t('#aljbd#aljbd_consume')->fetch($id);
                        $reason = $_GET['reason'][$id] ? lang("plugin/aljht","consume_php_24").$_GET['reason'][$id] : '';
                        notification_add($brand['uid'], 'system',str_replace(array('{shopname}','{reason}'),array($brand['subject'],$reason),$send_goods_tips),array('from_idtype'  => 'aljbd_consume','from_id' => $brand['id']));
                        unset($reason);
                    }
                }
            }
		}else{
			if($_GET['sign'] == 2){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						C::t('#aljbd#aljbd_consume')->update($id,array('rubbish'=>'1'));
					}
				}
			}else if($_GET['sign'] == 6){
                if(is_array($_GET['delete'])) {
                    foreach($_GET['delete'] as $k => $id) {
                        DB::query('update %t set status=0  where id = %d',array('aljbd_consume',$id));
                    }
                }
            }else if($_GET['sign'] == 7){
                if(is_array($_GET['delete'])) {
                    foreach($_GET['delete'] as $k => $id) {
                        DB::query('update %t set status=3  where id = %d',array('aljbd_consume',$id));
                    }
                }
            }
		}
		echo '<script>parent.tips(0);</script>';
		exit;
	}

	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=20;
	$start=($currpage-1)*$perpage;
	$con[]='aljbd_consume';
	if($administrators){
		$where=" where rubbish=0";
	}else{
		$where=" where rubbish=0 and uid = %d";
		$con[] = $_G['uid'];
    }
    if($_G['cache']['plugin']['aljtyh']){
        $where .=' and store_id=0';
    }
    if($_GET['bid']){
        $con[]=$_GET['bid'];
        $where.=' and bid=%d';
    }
    if($_GET['coupon_type']){
        $con[]=$_GET['coupon_type'];
        $where.=' and coupon_type=%d';
    }else if($_GET['dzAdmin'] == 1){
        $where.=' and coupon_type in(%n)';
        $con[]=array(7,9,10);
    }
	if($_GET['search']){
		$con[] ='%' . $keyword . '%';
		$where.=" and subject like %s";
	}
    if($do == 'rec'){
        $where.=' and status=0 and sign=1';
    }else if($do == 'no'){
        $where.=' and status=1';
    }else if($do == 'lose'){
        $where.=' and status=2';
    }else if($do == 'close'){
        $where.=' and status=3';
    }else{
        $where.=' and status=0';
    }
	$num = DB::result_first('select count(*) from %t'.$where,$con);
	$con[]=$start;
	$con[]=$perpage;
	$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY id desc limit %d,%d',$con);
	$bdlist = dhtmlspecialchars($bdlist);
	include template('aljht:admin/consume/consume');
}
//di'.'sm.t'.'aoba'.'o.com
?>