<?php
if($do == 'brand' || !$do){
	$del_tips = lang("plugin/aljht","rubbish_php_1");
}else{
	$del_tips = lang("plugin/aljht","rubbish_php_2");
}
if($do == 'video'){
	$keyword = addcslashes($_GET['search'], '%_');
	if(submitcheck('formhash') && empty($keyword)){
		if($_GET['sign'] == 2){
			if(is_array($_GET['delete'])) {
				foreach($_GET['delete'] as $k => $id) {
					//C::t('#aljsp#aljbd_video')->update($id,array('rubbish'=>'1'));
					$d_bd=C::t('#aljsp#aljbd_video')->fetch($id);
					unlink($d_bd['logo']);
					T::delete_oss($d_bd['logo']);
					C::t('#aljsp#aljbd_video')->delete($id);
				}
			}
		}else{
			if(is_array($_GET['delete'])) {
				foreach($_GET['delete'] as $k => $id) {
					C::t('#aljsp#aljbd_video')->update($id,array('rubbish'=>'0'));
				}
			}
		}
		echo '<script>parent.tips(0);</script>';
		exit;
	}
	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	$con[]='aljbd_video';
	
	$where=" where rubbish=1";
	
	
	
	if($_GET['search']){
		$con[] ='%' . $keyword . '%';
		$where.=" and subject like %s";
	}
	
	$num = DB::result_first('select count(*) from %t'.$where,$con);
	$con[]=$start;
	$con[]=$perpage;
	$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY id desc limit %d,%d',$con);
	
	$bdlist = dhtmlspecialchars($bdlist);
	$navtitle = $_G['cache']['plugin'][$pluginid]['title'];
	$metakeywords = $_G['cache']['plugin'][$pluginid]['keywords'];
	$metadescription = $_G['cache']['plugin'][$pluginid]['description'];
	include template('aljht:admin/rubbish/rubbish_video');
}elseif($do == 'album'){
	$keyword = addcslashes($_GET['search'], '%_');
	if(submitcheck('formhash') && empty($keyword)){
		if($administrators){
			if($_GET['sign'] == 2){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						if(C::t('#aljbd#aljbd_album_attachments')->conut_by_aid($id)){
							foreach(C::t('#aljbd#aljbd_album_attachments')->fetch_all_by_status(' where aid='.$id) as $atid){
								unlink($atid['pic']);
								unlink($atid['pic'].'.72x72.jpg');
								unlink($atid['pic'].'.100x100.jpg');
								unlink($atid['pic'].'.550x550.jpg');
								T::delete_oss($atid['pic']);
								C::t('#aljbd#aljbd_album_attachments')->delete($atid['id']);
							}
						}
						C::t('#aljbd#aljbd_album')->delete($id);
					}
				}
			}else{
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						DB::update('aljbd_album_attachments',array('rubbish'=>'0'),array('aid'=>$id));
						C::t('#aljbd#aljbd_album')->update($id,array('rubbish'=>'0'));
					}
				}
			}
		}
		echo '<script>parent.tips(0);</script>';
		exit;
	}

	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	$con[]='aljbd_album';
	
	$where=" where rubbish=1";
	
	if($_GET['search']){
		$con[] ='%' . $keyword . '%';
		$where.=" and albumname like %s";
	}
	
	$num = DB::result_first('select count(*) from %t'.$where,$con);
	$con[]=$start;
	$con[]=$perpage;
	$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY id desc limit %d,%d',$con);
	$bdlist = dhtmlspecialchars($bdlist);
	include template('aljht:admin/rubbish/rubbish_album');
}elseif($do == 'consume'){
	$keyword = addcslashes($_GET['search'], '%_');
	if(submitcheck('formhash') && empty($keyword)){
		if($administrators){
			if($_GET['sign'] == 2){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						$d_bd=C::t('#aljbd#aljbd_consume')->fetch($id);
						unlink($d_bd['pic']);
						T::delete_oss($d_bd['pic']);
						C::t('#aljbd#aljbd_consume')->delete($id);
						//����
						DB::query('DELETE FROM %t WHERE cid=%d',array('aljbd_comment_consume',$id));
					}
				}
			}else{
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						C::t('#aljbd#aljbd_consume')->update($id,array('rubbish'=>'0'));
					}
				}
			}
		}
		echo '<script>parent.tips(0);</script>';
		exit;
	}

	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	$con[]='aljbd_consume';
	
	$where=" where rubbish=1";
	
	if($_GET['search']){
		$con[] ='%' . $keyword . '%';
		$where.=" and subject like %s";
	}
	
	$num = DB::result_first('select count(*) from %t'.$where,$con);
	$con[]=$start;
	$con[]=$perpage;
	$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY id desc limit %d,%d',$con);
	$bdlist = dhtmlspecialchars($bdlist);
	include template('aljht:admin/rubbish/rubbish_consume');
}elseif($do == 'notice'){
	$keyword = addcslashes($_GET['search'], '%_');
	if(submitcheck('formhash') && empty($keyword)){
		if($administrators){
			if($_GET['sign'] == 2){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						C::t('#aljbd#aljbd_notice')->delete($id);
						//����
						DB::query('DELETE FROM %t WHERE nid=%d',array('aljbd_comment_notice',$id));
					}
				}
			}else{
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						C::t('#aljbd#aljbd_notice')->update($id,array('rubbish'=>'0'));
					}
				}
			}
		}
		echo '<script>parent.tips(0);</script>';
		exit;
	}

	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	$con[]='aljbd_notice';
	
	$where=" where rubbish=1";
	
	if($_GET['search']){
		$con[] ='%' . $keyword . '%';
		$where.=" and subject like %s";
	}
	
	$num = DB::result_first('select count(*) from %t'.$where,$con);
	$con[]=$start;
	$con[]=$perpage;
	$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY id desc limit %d,%d',$con);
	$bdlist = dhtmlspecialchars($bdlist);
	include template('aljht:admin/rubbish/rubbish_notice');
}elseif($do == 'goods'){
	$keyword = addcslashes($_GET['search'], '%_');
	if(submitcheck('formhash') && empty($keyword)){
		if($administrators){
			if($_GET['sign'] == 2){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						$d_bd=C::t('#aljbd#aljbd_goods')->fetch($id);
						for ($i = 1; $i <= 5; $i++) {
							$pic = 'pic' . $i;
							unlink($d_bd[$pic]);
							unlink($d_bd[$pic].'.60x60.jpg');
							unlink($d_bd[$pic].'.205x205.jpg');
							unlink($d_bd[$pic].'.470x470.jpg');
							
							T::delete_oss($d_bd[$pic]);
							
						}
						C::t('#aljbd#aljbd_goods')->delete($id);
						//����
						if($is_plugin_gwc){
							$comment_goods = DB::fetch_all('select * from %t where gid=%d ',array('aljbd_comment_goods',$id));
							if($comment_goods){
								foreach($comment_goods as $cgv){
									if($cgv['imgs']){
										$imagesarray = explode('|',$cgv['imgs']);
										foreach($imagesarray as $img){
											unlink($img);
											T::delete_oss($img);
										}
									}
									DB::query('DELETE FROM %t WHERE id=%d',array('aljbd_comment_goods',$cgv['id']));
								}
							}
						}
					}
				}
			}else{
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						C::t('#aljbd#aljbd_goods')->update($id,array('rubbish'=>'0'));//�������վ
						//����
						if($is_plugin_gwc){
							DB::update('aljbd_comment_goods',array('rubbish'=>0), array('gid'=>$id));
						}
					}
				}
			}
		}
		echo '<script>parent.tips(0);</script>';
		exit;
	}

	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	
	$con[]='aljbd_goods';
	
	$where=" where rubbish=1";
	
	if($_GET['search']){
		$con[] ='%' . $keyword . '%';
		$where.=" and name like %s";
	}
	$num = DB::result_first('select count(*) from %t'.$where,$con);
	$con[]=$start;
	$con[]=$perpage;
	$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY id desc limit %d,%d',$con);
	$bdlist = dhtmlspecialchars($bdlist);
	include template('aljht:admin/rubbish/rubbish_goods');
}else{
	$keyword = addcslashes($_GET['search'], '%_');
	if(submitcheck('formhash') && empty($keyword)){
		if($administrators){//����Ա
			if($_GET['sign'] == 2){
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						del_brand_all_1($id);
					}
				}
			}else{
				if(is_array($_GET['delete'])) {
					foreach($_GET['delete'] as $k => $id) {
						del_brand_all($id,0);
					}
				}
			}
		}
		echo '<script>parent.tips(0);</script>';
		exit;
	}

	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=10;
	$start=($currpage-1)*$perpage;

	$con[]='aljbd';

	$where=" where rubbish=1";

	if($_GET['search']){
		$con[] ='%' . $keyword . '%';
		$where.=" and name like %s";
	}
	$num = DB::result_first('select count(*) from %t'.$where,$con);
	$con[]=$start;
	$con[]=$perpage;
	$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY id desc limit %d,%d',$con);
	$bdlist = dhtmlspecialchars($bdlist);
	include template('aljht:admin/rubbish/rubbish');
}
//di'.'sm.t'.'aoba'.'o.com
?>