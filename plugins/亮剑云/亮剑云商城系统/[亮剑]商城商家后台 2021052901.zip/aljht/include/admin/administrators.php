<?php

/*
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����˵��:������̨-�������̳�
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_G['mobile']){
    $conn[] ='aljbd_goods_order';
    $where = 'where 1 and pid = 0 ';
    $aljqbcount = DB::result_first('select sum(price) from %t '.$where.' and status>1 and status<=5 ',$conn);
    
    $conn[] ='aljbd_goods_order';
    $where = 'where pid = 0 and status < 5';
    $where .= ' group by status';
    $num = DB::fetch_all('select status,count(*) a from %t '.$where,$conn);
    foreach($num as $k => $v){
        if($v['status'] == '1'){
            $order_pay = $v['a'];
        }elseif($v['status'] == '2'){
            $order_send = $v['a'];
        }elseif($v['status'] == '3'){
            $order_deliver = $v['a'];
        }elseif($v['status'] == '4'){
            $order_evaluate = $v['a'];
        }
    }
    $brandcounts = DB::result_first('select count(*) from %t where rubbish=0 ',array('aljbd'));
    $dsbrandnum = DB::result_first('select count(*) from %t where rubbish=0 and status=0 ',array('aljbd'));
    if($_G['cache']['plugin']['aljtsc']){
        $goodscounts = DB::result_first('select count(*) from %t where commodity_type<4 and rubbish=0 and store_id=0',array('aljbd_goods'));
        $dsgoodsnum = DB::result_first('select count(*) from %t where commodity_type<4 and rubbish=0 and sh_status=1 and store_id=0',array('aljbd_goods'));
    }else{
        $goodscounts = DB::result_first('select count(*) from %t where commodity_type<4 and rubbish=0 ',array('aljbd_goods'));
        $dsgoodsnum = DB::result_first('select count(*) from %t where commodity_type<4 and rubbish=0 and sh_status=1',array('aljbd_goods'));
    }
    
    $noticecounts = DB::result_first('select count(*) from %t where rubbish=0 ',array('aljbd_notice'));
    $dsnoticenum = DB::result_first('select count(*) from %t where rubbish=0 and status=1',array('aljbd_notice'));
    
    $consumecounts = DB::result_first('select count(*) from %t where rubbish=0 ',array('aljbd_consume'));
    $dsconsumenum = DB::result_first('select count(*) from %t where rubbish=0 and status=1',array('aljbd_consume'));
    
    if($_G['cache']['plugin']['aljsp']){
        $videocounts = DB::result_first('select count(*)  from %t where rubbish=0 ',array('aljbd_video'));
        $dsvideonum = DB::result_first('select count(*)  from %t where rubbish=0 and status=1',array('aljbd_video'));
        
    }

    $albumcounts = DB::result_first('select count(*) from %t where rubbish=0 ',array('aljbd_album'));
    $dsalbumnum = DB::result_first('select count(*) from %t where rubbish=0 and status=1',array('aljbd_album'));
    

    if($_G['cache']['plugin']['aljsfx']){
        $wdcounts = DB::result_first('select count(*) from %t ',array('aljsfx_shop'));
        $dswdnum = DB::result_first('select count(*) from %t where status=0',array('aljsfx_shop'));

        $cscounts = DB::result_first('select count(*) from %t ',array('aljsfx_cashorder'));
        $dscsnum = DB::result_first('select count(*) from %t where status=0',array('aljsfx_cashorder'));
        
        $fxordercounts = DB::result_first('select count(*) from %t ',array('aljsfx_order'));
        $fxusercounts = DB::result_first('select count(*) from %t ',array('aljsfx_user'));
    }
    if($_G['cache']['plugin']['aljtc']){
        $aljtccounts = DB::result_first('select count(*) from %t ',array('aljtc'));
        $dsaljtcnum = DB::result_first('select count(*) from %t where state=1',array('aljtc'));
    }
    $navtitle = lang("plugin/aljht","administrators_php_1");
    include template('aljht:admin/administrators/administrators');
}else{
    header('location: plugin.php?id=aljhtx&c=aljbd&a=order&type=5');
    exit;
}
?>