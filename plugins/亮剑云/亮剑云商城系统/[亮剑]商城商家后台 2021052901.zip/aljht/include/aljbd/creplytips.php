<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
foreach($groupids as $g_uid){
    notification_add($g_uid['uid'], 'system',lang("plugin/aljht","creplytips_php_1"),array('from_idtype'  => 'aljbd','from_id' => $insertid));
}
$replytips = lang("plugin/aljht","creplytips_php_2");
?>