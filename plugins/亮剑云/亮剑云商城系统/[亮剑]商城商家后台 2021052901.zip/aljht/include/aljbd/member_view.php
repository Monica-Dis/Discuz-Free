<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if ($_GET['uid'] < 0) {
    echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>'UID'.lang("plugin/aljht","member_view_php_1").'0')));
    exit;
}
if(!$bid){
    echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","member_view_php_2"))));
    exit;
}
if($_GET['uid']>0){
    $username = DB::result_first('select username from %t WHERE uid=%d', array(
        'common_member',
        $_GET['uid']
    ));
    if(!$username){
        echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","member_view_php_3"))));
        exit;
    }
    $set_uid = DB::result_first('select count(*) from %t WHERE kf_uid=%d', array(
        'aljbd',
        $_GET['uid']
    ));
    if($set_uid){
        echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","member_view_php_4"))));
        exit;
    }
    list($off_logo,$off_name,$off_desc,$off_uid)=explode('|',$_G['cache']['plugin']['aljol']['official_uid']);
    if($off_uid == $_GET['uid']){
        echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","member_view_php_5"))));
        exit;
    }
}

C::t('#aljbd#aljbd')->update($bid,array('kf_uid'=>$_GET['uid']));
echo json_encode(T::ajaxPostCharSet(array('code'=>1,'text'=>lang("plugin/aljht","member_view_php_6"))));
exit;
?>