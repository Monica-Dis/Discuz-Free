<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$insertarray['status'] = 1;

$groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));

$n_add_tips = lang("plugin/aljht","addconsume_send_php_1").'<a href="plugin.php?id=aljhtx&c=aljbd&a=order&type=5&frames=yes&twok=7&do=no" target="_blank">'.lang("plugin/aljht","addconsume_send_php_2").'</a>';

foreach($groupids as $g_uid){
    notification_add($g_uid['uid'], 'system',$n_add_tips,array('from_idtype'  => 'aljbd_consume'));
}
$sh_tips = lang("plugin/aljht","addconsume_send_php_3");
?>