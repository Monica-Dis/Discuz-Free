<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$s_pay_integral = floor($vipdata['pay_integral']/100*$_GET['price1']);
if($s_pay_integral<=0){
    $is_pay_integral =0;
}else{
    $is_pay_integral = $vipdata['pay_integral'];
}
if($vipdata['pay_integral']>0 && $is_pay_integral<$_GET['pay_integral']){
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        $vptips1 = lang("plugin/aljht","viptips_php_1");
        $vptips2 = lang("plugin/aljht","viptips_php_2");
        echo "<script>parent.tips('".$vptips1.$is_pay_integral."%".$vptips2."','');</script>";
        exit;
    }else{
        showerror($vptips1.$is_pay_integral."%".$vptips2);
    }
}
if($settings['is_give_integral']['value']==1 || $aljtsq_post_goods){
    $s_give_integral = $vipdata['give_integral'];
    $tips_s = lang("plugin/aljht","goods_php_44");
    $tips_e = '%';
}else{
    $s_give_integral = floor($vipdata['give_integral']/100*$_GET['price1']);
    $tips_s = lang("plugin/aljht","goods_php_26");
    $tips_e = lang("plugin/aljht","goods_php_27");
}

if($vipdata['give_integral']>0 && $s_give_integral<$_GET['give_integral']){
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('".$tips_s.$s_give_integral.$tips_e."','');</script>";
        exit;
    }else{
        showerror($tips_s.$s_give_integral.$tips_e);
    }
}
?>