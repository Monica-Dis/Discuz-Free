<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function cloudaddons_validator_lj($addonid) {
	global $_G;
	require_once libfile('function/cloudaddons');
	$array = cloudaddons_getmd5($addonid);
	if(cloudaddons_open('&mod=app&ac=validator&ver=2&addonid='.$addonid.($array !== false ? '&rid='.$array['RevisionID'].'&sn='.$array['SN'].'&rd='.$array['RevisionDateline'] : '')) === '0') {
		showmessage('&#35831;&#36141;&#20080;&#27491;&#29256;&#24212;&#29992;&#36141;&#29289;&#36710;&#12289;&#21697;&#29260;&#21830;&#23478; <a href="http&#58;//dism.taobao.com/?@aljbd.plugin">&#28857;&#20987;&#36141;&#20080;</a>');
	}
}
//cloudaddons_validator_lj('aljbd.plugin');
function get_all($e)
{
    $elem_total = count($e);
    $max = 1;
    for ($i=0; $i<$elem_total; $i++) {
        $len = count($e[$i])+1;
        $elem_size[] = $len;
        $max *= $len;
    }   
    for ($i=1; $i<$max; $i++) {
        $m = $i; 
        $item = array();
        $ct = 0;
        for ($j=0; $j<$elem_total; $j++) {
            $n = $m%$elem_size[$j];
            $item[] = $n>0?$e[$j][$n-1]:"";
            $ct += $n>0?1:0;
            $m = (int)($m/$elem_size[$j]);
        }   
        if ($ct>=$elem_total)
            $all[] = $item;
    }   
    return $all;
}
//di'.'sm.t'.'aoba'.'o.com
?>