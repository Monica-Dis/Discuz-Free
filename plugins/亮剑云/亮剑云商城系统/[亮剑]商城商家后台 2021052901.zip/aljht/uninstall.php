<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//start to put your own code 
$sql = <<<EOF
DROP TABLE IF  EXISTS `pre_aljht_attr_key`;
DROP TABLE IF  EXISTS `pre_aljht_attr_sku`;
DROP TABLE IF  EXISTS `pre_aljht_attr_value`;
EOF;

if(file_exists("source/plugin/aljhtx/aljhtx.inc.php")) {
	$un_set = DB::fetch_all('select * from %t', array('aljhtx_system_setting'),'skey');
	if($un_set['is_del_mysql']['svalue']){
		runquery($sql);	
	}
}
//finish to put your own code
$finish = TRUE;
?>