<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//start to put your own code
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljht_attr_key` (
  `kid` int(10) NOT NULL AUTO_INCREMENT,
  `gid` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `displayorder` int(10) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`kid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljht_attr_sku` (
  `sid` int(10) NOT NULL AUTO_INCREMENT,
  `gid` int(10) NOT NULL,
  `path` varchar(255) NOT NULL,
  `marketprice` double(15,2) NOT NULL,
  `saleprice` double(15,2) NOT NULL,
  `freight` double(15,2) NOT NULL,
  `newprice` double(15,2) NOT NULL,
  `card_price` double(15,2) NOT NULL,
  `market_value` double(15,2) NOT NULL,
  `stock` int(10) NOT NULL,
  `displayorder` int(10) NOT NULL,
  `sku_logo` varchar(255) NOT NULL,
  `commodity_code` varchar(255) NOT NULL,
  PRIMARY KEY (`sid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljht_attr_value` (
  `kid` int(10) NOT NULL,
  `gid` int(10) NOT NULL,
  `symbol` int(10) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) NOT NULL,
  `displayorder` int(10) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`symbol`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_ather` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `desc` text NOT NULL,
  `addtime` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `displayorder` int(11) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljht_iframe_nav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `displayorder` int(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL,
  `upid` int(11) NOT NULL,
  `hide` tinyint(3) NOT NULL,
  `pluginid` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_goods_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gid` int(11) NOT NULL,
  `addtime` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `goodsinfo` text NOT NULL,
  `url` varchar(300) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gid` (`gid`),
  KEY `uid` (`uid`)
)
EOF;
runquery($sql);
$sql ="ALTER TABLE ".DB::table('aljbd_type')." ADD `type_url`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_type_goods')." ADD `type_url`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_type_consume')." ADD `type_url`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_type_notice')." ADD `type_url`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `qg_type`  TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');
if(file_exists("source/plugin/aljsp/aljsp.inc.php")){
  $sql ="ALTER TABLE ".DB::table('aljbd_type_video')." ADD `type_url`  varchar(255) NOT NULL" ;
  DB::query($sql,'SILENT');
}
if(file_exists("source/plugin/aljbdx/aljbdx.inc.php")){
  $sql = "ALTER TABLE " . DB::table('aljgwc_refund') . " ADD `type` tinyint(4) NOT NULL";
  DB::query($sql, 'SILENT');
}
$sql = "ALTER TABLE ".DB::table('aljbd_vip')." ADD `payment_days` int(11) NOT NULL";
DB::query($sql,'SILENT');
if(file_exists("source/plugin/aljmb/aljmb.inc.php")){
  if(!DB::result_first('select count(*) from %t where pluginid=%s',array('aljht_iframe_nav','aljmb'))){
    DB::insert('aljht_iframe_nav',array(
      'name'=>'&#36816;&#36153;&#27169;&#26495;',
      'url'=>'plugin.php?id=aljmb',
      'addtime'=>time(),
      'pluginid'=>'aljmb',
    ));
  }
}
if(file_exists("source/plugin/aljms/aljms.inc.php")){
  if(!DB::result_first('select count(*) from %t where pluginid=%s',array('aljht_iframe_nav','aljms'))){
    DB::insert('aljht_iframe_nav',array(
      'name'=>'&#31186;&#26432;&#21830;&#21697;',
      'url'=>'plugin.php?id=aljms&c=activity&a=ms_goods&ajax=yes',
      'addtime'=>time(),
      'pluginid'=>'aljms',
    ));
  }
}
if(file_exists("source/plugin/aljat/aljat.inc.php")){
  if(!DB::result_first('select count(*) from %t where pluginid=%s',array('aljht_iframe_nav','aljat'))){
    DB::insert('aljht_iframe_nav',array(
      'name'=>'&#21345;&#23494;&#20179;&#24211;',
      'url'=>'plugin.php?id=aljat&c=kami&a=list_index&ajax=yes',
      'addtime'=>time(),
      'pluginid'=>'aljat',
    ));
  }
}
//finish to put your own code
$finish = TRUE;
?>
