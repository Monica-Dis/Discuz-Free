<?php

/*
 * Discuz! x3.4 By DisM.taobao.COM
 * ��ϵQQ:578933760
 *
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljbd_type_brand extends discuz_table {

    public function __construct() {

        $this->_table = 'aljbd_type_brand';
        $this->_pk = 'id';

        parent::__construct();
    }
}

?>