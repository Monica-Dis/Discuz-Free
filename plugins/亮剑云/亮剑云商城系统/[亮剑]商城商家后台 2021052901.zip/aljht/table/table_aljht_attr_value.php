<?php

/*
 * Discuz! x3.4 By DisM.taobao.COM
 * ��ϵQQ:578933760
 *
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljht_attr_value extends discuz_table {

    public function __construct() {

        $this->_table = 'aljht_attr_value';
        $this->_pk = 'symbol';

        parent::__construct();
    }
}

?>