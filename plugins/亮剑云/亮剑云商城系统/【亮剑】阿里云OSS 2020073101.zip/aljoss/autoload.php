<?php

function classLoader($a)
{

    $path = str_replace('\\', DIRECTORY_SEPARATOR, $a);
    $file = __DIR__ . DIRECTORY_SEPARATOR . $path . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
}
// 取原有的加载方法
$oldFunctions = spl_autoload_functions();

// 逐个卸载
if ($oldFunctions){
    foreach ($oldFunctions as $f) {
        spl_autoload_unregister($f);
    }
}
spl_autoload_register('classLoader');