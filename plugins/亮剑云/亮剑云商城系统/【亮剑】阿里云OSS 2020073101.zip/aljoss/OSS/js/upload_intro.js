
accessid = ''
accesskey = ''
host = ''
policyBase64 = ''
signature = ''
callbackbody = ''
filename = ''
key = ''
expire = 0
g_object_name = ''
g_object_name_type = 'random_name'
now = timestamp = Date.parse(new Date()) / 1000; 

function send_request()
{
    var xmlhttp = null;
    if (window.XMLHttpRequest)
    {
        xmlhttp=new XMLHttpRequest();
    }
    else if (window.ActiveXObject)
    {
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
  
    if (xmlhttp!=null)
    {
        // serverUrl 用户获取 '签名和Policy' 等信息的应用服务器的URL，请将下面的IP和Port配置为您自己的真实信息
        // serverUrl = 'http://88.88.88.88:8888/aliyun-oss-appserver-php/php/get.php'
        serverUrl = 'source/plugin/aljoss/OSS/js/php/get.php'
		
        xmlhttp.open( "GET", serverUrl, false );
        xmlhttp.send( null );
        return xmlhttp.responseText
    }
    else
    {
        alert("Your browser does not support XMLHTTP.");
    }
};

function get_signature()
{
    // 可以判断当前expire是否超过了当前时间， 如果超过了当前时间， 就重新取一下，3s 作为缓冲
    now = timestamp = Date.parse(new Date()) / 1000; 
    if (expire < now + 3)
    {
        body = send_request()
        var obj = eval ("(" + body + ")");
        host = obj['host']
        policyBase64 = obj['policy']
        accessid = obj['accessid']
        signature = obj['signature']
        expire = parseInt(obj['expire'])
        callbackbody = obj['callback'] 
        key = obj['dir']
        return true;
    }
    return false;
};

function random_string(len) {
    len = len || 32;
    var chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678';
    var maxPos = chars.length;
    var pwd = '';
    for (i = 0; i < len; i++) {
        pwd += chars.charAt(Math.floor(Math.random() * maxPos));
    }
    return pwd;
}

function get_suffix(filename) {
    pos = filename.lastIndexOf('.')
    suffix = ''
    if (pos != -1) {
        suffix = filename.substring(pos)
    }
    return suffix;
}

function calculate_object_name(filename)
{
    if (g_object_name_type == 'local_name')
    {
        g_object_name += "${filename}"
    }
    else if (g_object_name_type == 'random_name')
    {
        suffix = get_suffix(filename)
        g_object_name = key + random_string(10) + suffix
    }
    return ''
}

function get_uploaded_object_name(filename)
{
    if (g_object_name_type == 'local_name')
    {
        tmp_name = g_object_name
        tmp_name = tmp_name.replace("${filename}", filename);
        return tmp_name
    }
    else if(g_object_name_type == 'random_name')
    {
        return g_object_name
    }
}

function set_upload_param(up, filename, ret)
{
    if (ret == false)
    {
        ret = get_signature()
    }
    g_object_name = key;
    if (filename != '') { suffix = get_suffix(filename)
        calculate_object_name(filename)
    }
    new_multipart_params = {
        'key' : g_object_name,
        'policy': policyBase64,
        'OSSAccessKeyId': accessid, 
        'success_action_status' : '200', //让服务端返回200,不然，默认会返回204
        'signature': signature,
    };

    up.setOption({
        'url': host,
        'multipart_params': new_multipart_params
    });

    up.start();
}
function DelVideo() {
    var box=document.getElementById("ossfile_intro");
    box.parentNode.removeChild(box);
}
var uploader_intro = new plupload.Uploader({
	runtimes : 'html5,flash,silverlight,html4',
	browse_button : 'selectfiles_intro', 
    multi_selection: false,
	flash_swf_url : 'lib/plupload-2.1.2/js/Moxie.swf',
	silverlight_xap_url : 'lib/plupload-2.1.2/js/Moxie.xap',
    url : 'http://oss.aliyuncs.com',

    filters: {
        mime_types : [ //只允许上传图片和zip文件
        { title : "video files", extensions : "mp4,mov" }
        ],
        max_file_size : video_mb+'mb', //最大只能上10mb的文
        prevent_duplicates : true //不允许选取重复文件
    },

	init: {
		
		FilesAdded: function(up, files) {
			plupload.each(files, function(file) {
                if(typeof aljol !== 'undefined'){
                    layer.open({
                        type: 2
                        ,content: '<div id="layer_video_text">\u89c6\u9891\u4e0a\u4f20\u4e2d</div>'
                        ,shadeClose: false
                    });
                }else {
                    document.getElementById('ossfile_intro').innerHTML = '<li class="weui-uploader__file weui-uploader__file_status" id="' + file.id + '">'
                        + '<div class="weui-uploader__file-content"></div>'
                        + '</li>';
                }
			});
			set_upload_param(uploader_intro, '', false);
            return false;
		},

		BeforeUpload: function(up, file) {

            set_upload_param(up, file.name, true);
        },
		UploadProgress: function(up, file) {
		    if(typeof aljol !== 'undefined'){
                var d = document.getElementById('layer_video_text');
                d.innerHTML = '\u89c6\u9891\u4e0a\u4f20'+file.percent + "%";
            }else{
                var d = document.getElementById(file.id);
                d.getElementsByTagName('div')[0].innerHTML = file.percent + "%";
            }
		},

		FileUploaded: function(up, file, info) {
            if (info.status == 200)
            {
                if(typeof aljol !== 'undefined'){
                    sendVideo('//'+domain_url+'/'+get_uploaded_object_name(file.name));
                }else{
                    var video_path_name = typeof input_video_name !== 'undefined' ? input_video_name : 'video_path';
                    document.getElementById('ossfile_intro').innerHTML = '<li class="weui-uploader__file weui-uploader__file_status img_list" style="width:180px">'
                        +'<video controls="controls" class="vr_iframe" style="height:80px;width:180px">'
                        +'<source src="//'+domain_url+'/'+get_uploaded_object_name(file.name)+'" type="video/mp4">'
                        +'</video><input type="hidden" name="'+video_path_name+'" value="//'+domain_url+'/'+get_uploaded_object_name(file.name)+'">'
                        +'<img src="source/plugin/aljoss/img/del.png" class="del_video" onclick="DelVideo()"/>'
                        +'</li>';
                }
            }
            else if (info.status == 203)
            {
                alert('\u4e0a\u4f20\u5230\u004f\u0053\u0053\u6210\u529f\uff0c\u4f46\u662f\u006f\u0073\u0073\u8bbf\u95ee\u7528\u6237\u8bbe\u7f6e\u7684\u4e0a\u4f20\u56de\u8c03\u670d\u52a1\u5668\u5931\u8d25\uff0c\u5931\u8d25\u539f\u56e0\u662f\u003a' + info.response);
            }
            else
            {
                alert(info.response);
            } 
		},
		Error: function(up, err) {
		    console.log(err);
            if (err.code == -600) {
                alert('\u9009\u62e9\u7684\u6587\u4ef6\u592a\u5927\u4e86\u002c\u89c6\u9891\u4e0d\u80fd\u8d85\u8fc7'+video_mb+'M');
            }
            else if (err.code == -601) {
                alert('\u9009\u62e9\u7684\u6587\u4ef6\u540e\u7f00\u4e0d\u5bf9\u002c\u0020\u53ea\u80fd\u4e0a\u4f20\u002e\u006d\u0070\u0034\u6216\u002e\u006d\u006f\u0076');
            }
            else if (err.code == -602) {
                alert('\u8fd9\u4e2a\u6587\u4ef6\u5df2\u7ecf\u4e0a\u4f20\u8fc7\u4e00\u904d\u4e86');
            }
            else 
            {
                alert(err.response);
            }
		}
	}
});

uploader_intro.init();
