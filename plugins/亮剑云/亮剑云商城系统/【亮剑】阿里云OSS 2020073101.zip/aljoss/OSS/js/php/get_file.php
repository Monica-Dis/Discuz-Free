<?php
    define('DISABLEXSSCHECK',true);
    require '../../../../../../source/class/class_core.php';
    $discuz = C::app();
    $discuz->init();
    loadcache('plugin');
    function gmt_iso8601($time) {
        $dtStr = date("c", $time);
        $mydatetime = new DateTime($dtStr);
        $expiration = $mydatetime->format(DateTime::ISO8601);
        $pos = strpos($expiration, '+');
        $expiration = substr($expiration, 0, $pos);
        return $expiration."Z";
    }

    $id= $_G['cache']['plugin']['aljoss']['Access_Key'];          // 璇峰～鍐欐偍鐨凙ccessKeyId銆�
    $key= $_G['cache']['plugin']['aljoss']['Secret_Key'];     // 璇峰～鍐欐偍鐨凙ccessKeySecret銆�
    // $host鐨勬牸寮忎负 bucketname.endpoint锛岃鏇挎崲涓烘偍鐨勭湡瀹炰俊鎭€�
    $host = 'https://'.$_G['cache']['plugin']['aljoss']['domain'];
    // $callbackUrl涓轰笂浼犲洖璋冩湇鍔″櫒鐨刄RL锛岃灏嗕笅闈㈢殑IP鍜孭ort閰嶇疆涓烘偍鑷繁鐨勭湡瀹濽RL淇℃伅銆�
    //$callbackUrl = 'https://dism.taobao.com/?source/plugin/aljoss/callback.php';
    //$callbackUrl = 'https://dism.taobao.com/?oss/php/callback.php';
    $dir = 'aljrz/file/'.date('Ymd');          // 鐢ㄦ埛涓婁紶鏂囦欢鏃舵寚瀹氱殑鍓嶇紑銆�

    $callback_param = array('callbackUrl'=>$callbackUrl,
                 'callbackBody'=>'filename=${object}&size=${size}&mimeType=${mimeType}&height=${imageInfo.height}&width=${imageInfo.width}',
                 'callbackBodyType'=>"application/x-www-form-urlencoded");
    $callback_string = json_encode($callback_param);

    $base64_callback_body = base64_encode($callback_string);
    $now = time();
    $expire = 30;  //璁剧疆璇olicy瓒呮椂鏃堕棿鏄�10s. 鍗宠繖涓猵olicy杩囦簡杩欎釜鏈夋晥鏃堕棿锛屽皢涓嶈兘璁块棶銆�
    $end = $now + $expire;
    $expiration = gmt_iso8601($end);


    //鏈€澶ф枃浠跺ぇ灏�.鐢ㄦ埛鍙互鑷繁璁剧疆
    $condition = array(0=>'content-length-range', 1=>0, 2=>1048576000);
    $conditions[] = $condition;

    // 琛ㄧず鐢ㄦ埛涓婁紶鐨勬暟鎹紝蹇呴』鏄互$dir寮€濮嬶紝涓嶇劧涓婁紶浼氬け璐ワ紝杩欎竴姝ヤ笉鏄繀椤婚」锛屽彧鏄负浜嗗畨鍏ㄨ捣瑙侊紝闃叉鐢ㄦ埛閫氳繃policy涓婁紶鍒板埆浜虹殑鐩綍銆�
    $start = array(0=>'starts-with', 1=>'$key', 2=>$dir);
    $conditions[] = $start;


    $arr = array('expiration'=>$expiration,'conditions'=>$conditions);
    $policy = json_encode($arr);
    $base64_policy = base64_encode($policy);
    $string_to_sign = $base64_policy;
    $signature = base64_encode(hash_hmac('sha1', $string_to_sign, $key, true));

    $response = array();
    $response['accessid'] = $id;
    $response['host'] = $host;
    $response['policy'] = $base64_policy;
    $response['signature'] = $signature;
    $response['expire'] = $end;
    $response['callback'] = $base64_callback_body;
    $response['dir'] = $dir;  // 杩欎釜鍙傛暟鏄缃敤鎴蜂笂浼犳枃浠舵椂鎸囧畾鐨勫墠缂€銆�
    echo json_encode($response);
?>
