<?php

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

loadcache('plugin');

if(!file_exists('source/plugin/aljhtx/class/class_oss.php')){
    echo '<a target="_blank" href="https://addon.discuz.com/?@aljhtx.plugin">&#35831;&#20808;&#28857;&#20987;&#25105;&#21069;&#24448;&#23433;&#35013;&#47;&#26356;&#26032;&#21830;&#23478;&#21161;&#25163;&#25554;&#20214;</a>';
    exit;
}

$config_aljoss = $_G['cache']['plugin']['aljoss'];

if(!$config_aljoss['Access_Key'] || !$config_aljoss['Secret_Key'] || !$config_aljoss['endpoint'] || !$config_aljoss['bucket']){
    echo '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'">&#35831;&#28857;&#20987;&#25105;&#21069;&#24448;&#35774;&#32622;&#39029;&#38754;&#35774;&#32622;&#21442;&#25968;&#21518;&#20877;&#27979;&#35797;&#65281;</a>';
    exit;
}

require_once 'source/plugin/aljhtx/class/class_aljhtx.php';
T::getObject('oss');
$oss = new Oss();
$object = 'test/'.TIMESTAMP.'.png';
$result = $oss->upload($object, 'source/plugin/aljoss/logo.png');

if(is_array($result) && $result['info']['url']){
    debug('&#27979;&#35797;&#25104;&#21151;&#65281;&#24050;&#33719;&#21462;&#21040;&#38463;&#37324;&#20113;&#36820;&#22238;&#30340;&#27979;&#35797;&#22270;&#29255;&#38142;&#25509;&#65306;<a target="_blank" href="https://'.$config_aljoss['domain'].'/'.$object.'">https://'.$config_aljoss['domain'].'/'.$object.'</a>');
}else{
    debug('&#27979;&#35797;&#22833;&#36133;&#65292;&#35831;&#26816;&#26597;&#21442;&#25968;&#35774;&#32622;&#65281;&#38169;&#35823;&#20449;&#24687;&#65306;'.$result);
}