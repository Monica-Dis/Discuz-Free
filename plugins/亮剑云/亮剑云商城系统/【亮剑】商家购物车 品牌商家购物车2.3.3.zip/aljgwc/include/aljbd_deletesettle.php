<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if ($_GET['settleid']){
	C::t('#aljgwc#aljbd_goods_settle') -> delete($_GET['settleid']);
}
//From: Dism��taobao��com
?>