<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			
	$order = C::t('#aljgwc#aljbd_goods_order') -> fetch($_GET['orderid']);
	if(submitcheck('formhash')){
		
		if($_GET['orderid']){
			
			if($order['uid'] == $_G['uid'] || in_array($_G['groupid'],$admingroups)){
				C::t('#aljgwc#aljbd_goods_order') -> delete($_GET['orderid']);
			}
		}
		showmessage(lang('plugin/aljbd','sc7'),'plugin.php?id=aljbd&act=orderlist');
	}else{
		$url='plugin.php?id=aljbd&act=deleteorder&orderid='.$order['orderid'];
		include template('aljbd:state');
	}
}else{
	if($_GET['orderid'] && $_GET['formhash'] == FORMHASH){
		$order = C::t('#aljgwc#aljbd_goods_order') -> fetch($_GET['orderid']);
		if($order['uid'] == $_G['uid'] || in_array($_G['groupid'],$admingroups)){
			C::t('#aljgwc#aljbd_goods_order') -> delete($_GET['orderid']);
		}
		
	}
	showmessage(lang('plugin/aljbd','sc7'),'plugin.php?id=aljbd&act=orderlist');
}
//From: Dism��taobao��com
?>