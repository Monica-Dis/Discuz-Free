<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$bids = DB::fetch_all('select id from %t where uid = %d',array('aljbd',$_G['uid']));
foreach($bids as $bid){
	$ids[] = $bid['id'];
}
$bids = implode(',',$ids);

$cur = DB::result_first('select sum(price) from %t where status >= 2 and shop_id in(%i)',array('aljbd_goods_order',$bids)) * (1-$_G['cache']['plugin']['aljbd']['per']);

$cur = $cur - DB::result_first('select sum(settleprice) from %t where uid = %d and status < 2 and settleid != %s group by uid',array('aljbd_goods_settle',$_G['uid'],$settleid));
if (submitcheck('formhash')){
	if (empty($settleid)) {
		showerror(lang('plugin/aljbd','tg34'));
		exit;
	}
	$settle = C::t('#aljgwc#aljbd_goods_settle') -> fetch($_GET['settleid']);
	if ($settle['uid'] != $_G['uid'] && !in_array($_G['groupid'],$admingroups)) {
		showerror(lang('plugin/aljbd','tg35'));
		exit;
	}
	if ($settle['status'] != 0) {
		showerror(lang('plugin/aljbd','tg36'));
		exit;
	}
	if ($cur < $_G['cache']['plugin']['aljbd']['min']) {
		showerror(lang('plugin/aljbd','tg37'));
		exit;
	}
	C::t('#aljgwc#aljbd_goods_settle') -> update($_GET['settleid'],array(
		'settleprice' => $_GET['settleprice'],
		'username' => $_GET['username'],	
		'account' => $_GET['account'],	
		'payment' => $_G['cache']['plugin']['aljbd']['payment'],	
		'status' => 0,	
		'applytime' => TIMESTAMP,	
	));
	if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
		echo "<script>parent.tips('".lang('plugin/aljbd','tg38')."','');</script>";
		exit;
	}else{
		showmsg(lang('plugin/aljbd','tg38'));
	}
	
} else{
	if (empty($settleid)){
		showmessage(lang('plugin/aljbd','tg39'));
	}
	$settle = C::t('#aljgwc#aljbd_goods_settle') -> fetch($_GET['settleid']);
	if ($settle['uid'] != $_G['uid'] && !in_array($_G['groupid'],$admingroups)) {
		showmessage(lang('plugin/aljbd','tg40'));
		exit;
	}
	include template('aljbd:settle');
}
//From: Dism��taobao��com
?>