<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$bids = DB::fetch_all('select id from %t where uid = %d',array('aljbd',$_G['uid']));
foreach($bids as $bid){
	$ids[] = $bid['id'];
}
$bids = implode(',',$ids);

$cur = DB::result_first('select sum(price) from %t where status >= 2 and shop_id in(%i)',array('aljbd_goods_order',$bids)) * (1-$_G['cache']['plugin']['aljbd']['per']);
$cur = $cur - DB::result_first('select sum(settleprice) from %t where uid = %d and status < 2 group by uid',array('aljbd_goods_settle',$_G['uid']));
$cur = sprintf("%.3f",$cur);
if (submitcheck('formhash')){
	if ($cur < $_G['cache']['plugin']['aljbd']['min']) {
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".lang('plugin/aljbd','tg32')."','');</script>";
			exit;
		}else{
			showerror(lang('plugin/aljbd','tg32'));
			exit;
		}
	}
	$settleid = dgmdate(TIMESTAMP, 'YmdHis').random(18);
	C::t('#aljgwc#aljbd_goods_settle') -> insert(array(
		'uid' => $_G['uid'],
		'settleid' => $settleid,
		'settleprice' => $_GET['settleprice'],
		'username' => $_GET['username'],	
		'account' => $_GET['account'],	
		'payment' => $_G['cache']['plugin']['aljbd']['payment'],	
		'status' => 0,	
		'applytime' => TIMESTAMP,
		'name' => $_G['username'],
	));
	if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
		echo "<script>parent.tips('".lang('plugin/aljbd','tg33')."',function(){parent.location.href='plugin.php?id=aljbd&act=settlelist&cart=".$_GET['cart']."';});</script>";
		exit;
	}else{
		showmsg(lang('plugin/aljbd','tg33'));
	}
} else{
	include template('aljbd:settle');
}
//From: Dism��taobao��com
?>