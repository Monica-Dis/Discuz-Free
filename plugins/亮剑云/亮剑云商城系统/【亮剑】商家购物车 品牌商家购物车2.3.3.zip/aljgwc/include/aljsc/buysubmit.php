<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$goods_id = $_GET['goods_id'];
$num = intval($_GET['num']);

if ($num < 1) {
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        showmessage('&#21830;&#21697;&#25968;&#37327;&#24517;&#39035;&#22823;&#20110;&#48;');
    }else{
        echo '<script>parent.showDialog("&#21830;&#21697;&#25968;&#37327;&#24517;&#39035;&#22823;&#20110;&#48;","")</script>';
        exit;
    }

}
if(!$address){
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        showmessage('&#35831;&#22635;&#20889;&#25910;&#36135;&#22320;&#22336;');
    }else{
        echo '<script>parent.showDialog("&#35831;&#22635;&#20889;&#25910;&#36135;&#22320;&#22336;","")</script>';
        exit;
    }

}
if(!$_GET['payment']){
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        showmessage('&#35831;&#36873;&#25321;&#20184;&#27454;&#26041;&#24335;');
    }else{
        echo '<script>parent.showDialog("&#35831;&#36873;&#25321;&#20184;&#27454;&#26041;&#24335;","")</script>';
        exit;
    }
}

if ($_GET['totalprice']) {
    $totalprice = $_GET['totalprice'];
}
if ($_GET['totalpriceext']) {
    $pay_ext = $_GET['totalpriceext'];
    if($extcredits_aljsc < $_GET['totalpriceext']){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            showmessage('&#31215;&#20998;&#19981;&#36275;');
        }else{
            echo '<script>parent.showDialog("&#31215;&#20998;&#19981;&#36275;","")</script>';
            exit;
        }
    }
}
if ($_GET['fare']) {
    $fare = $_GET['fare'];
}
$goods=C::t('#'.$pluginid.'#'.$pluginid)->fetch($_GET['goods_id']);
$goods['name'] = $goods['title'];
$goods['amount'] = $goods['num'];
$goods['price1'] = $goods['price'];

if($goods['price']){
	$shop_id = 1;
}else{
	$shop_id = 2;
}
$shop = $goods;

if(!$goods){
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        showmessage($alj_lang['The_goods_do_not_exist']);
    }else{
        echo '<script>parent.showDialog("'.$alj_lang['The_goods_do_not_exist'].'","")</script>';
        exit;
    }
}
if($_GET['payment'] == 4){
	$money = getuserprofile('extcredits' . $_G['cache']['plugin']['aljsc']['extcredit']);
	if (in_array($_G['groupid'], $notallowgroups)) {
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            showmessage(lang('plugin/aljsc','sc23'));
        }else{
            echo '<script>parent.showDialog("'.lang('plugin/aljsc','sc23').'","")</script>';
            exit;
        }
	}
	$num = intval($_GET['num']);

	if ($num < 1) {
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            showmessage('&#21830;&#21697;&#25968;&#37327;&#24517;&#39035;&#22823;&#20110;&#48;');
        }else{
            echo '<script>parent.showDialog("&#21830;&#21697;&#25968;&#37327;&#24517;&#39035;&#22823;&#20110;&#48;","")</script>';
            exit;
        }
	}
	if ($shop['num'] < $num) {
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            showmessage(lang('plugin/aljsc','sc17'));
        }else{
            echo '<script>parent.showDialog("'.lang('plugin/aljsc','sc17').'","")</script>';
            exit;
        }
	}


	if ($shop['e']) {
		$limitnum=DB::result_first('select sum(num) from %t where sid=%d and uid=%d',array('aljsc_log',$shop['id'],$_G['uid']));
		
		if(($limitnum + $num) > $shop['e'] || $num >$shop['e']){
			$lnum=($shop['e']-$limitnum)>=0 ? ($shop['e']-$limitnum):0;
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                showmessage("&#27599;&#20154;&#38480;&#25442;".$shop['e']."&#20010;&#65292;&#24744;&#24050;&#20817;&#25442;".$limitnum."&#20010;&#65292;&#36824;&#21487;&#20197;&#20817;&#25442;".$lnum."&#20010;");
            }else{
                echo '<script>parent.showDialog("&#27599;&#20154;&#38480;&#25442;".$shop[\'e\']."&#20010;&#65292;&#24744;&#24050;&#20817;&#25442;".$limitnum."&#20010;&#65292;&#36824;&#21487;&#20197;&#20817;&#25442;".$lnum."&#20010;","")</script>';
                exit;
            }

		}
	}

	if ($money < $shop['extcredit'] * $num) {
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            showmessage($_G['setting']['extcredits'][$_G['cache']['plugin']['aljsc']['extcredit']]['title'].lang('plugin/aljsc','sc18'));
        }else{
            echo '<script>parent.showDialog("'.$_G['setting']['extcredits'][$_G['cache']['plugin']['aljsc']['extcredit']]['title'].lang('plugin/aljsc','sc18').'","")</script>';
            exit;
        }
	}
	if (TIMESTAMP < $shop['starttime']) {
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            showmessage(lang('plugin/aljsc','sc19'));
        }else{
            echo '<script>parent.showDialog("'.lang('plugin/aljsc','sc19').'","")</script>';
            exit;
        }

	}
	if (TIMESTAMP > $shop['endtime']) {
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            showmessage(lang('plugin/aljsc','sc19'));
        }else{
            echo '<script>parent.showDialog("'.lang('plugin/aljsc','sc19').'","")</script>';
            exit;
        }
	}


	$insertarray = array(
		'uid' => $_G['uid'],
		'username' => $_G['username'],
		'sid' => $shop['id'],
		'mode' => $shop['mode'],
		'title' => $shop['title'],
		'extcredit' => $shop['extcredit']*$num,
		'num' => $num,
		'dateline' => TIMESTAMP,
		'a' => $_GET['content'].$_GET['remarks'],
	);
	$insertarray['c'] = serialize($address);
	updatemembercount($_G['uid'], array($_G['cache']['plugin']['aljsc']['extcredit'] => '-' . $num * $shop['extcredit']));
	$insertid = C::t('#aljsc#aljsc_log')->insert($insertarray,true);
	C::t('#aljsc#aljsc')->update_num_by_id($goods_id,$num);
	C::t('#aljsc#aljsc')->update_num2_by_id($goods_id,$num);

	$sid = intval($goods_id);
	$kamilist = DB::fetch_all('select * from %t where sid = %d and uid =0 limit %d',array('aljsc_kami',$sid,$num));
	if($kamilist && count($kamilist) == $num){
		DB::query('update %t set status = 1,d = 1 where id=%d',array('aljsc_log',$insertid));
		foreach($kamilist as $kami){
			DB::query('update %t set orderid = %d,dateline = %d,uid =%d,username = %s where mid=%d',array('aljsc_kami',$insertid,TIMESTAMP,$_G['uid'],$_G['username'],$kami['mid']));
		}
		$order = C::t('#aljsc#aljsc_log')->fetch($insertid);
		notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$order['sid'].'">'.$order['title'].'</a>',$_G['cache']['plugin']['aljsc']['fahuotips'])));
		if($_G['cache']['plugin']['aljsc']['ismail']){
			$email_first=C::t("common_member")->fetch($order['uid']);
			$email=$email_first['email'];
			sendmail_cron($email,$_G['cache']['plugin']['aljsc']['mailtitle'],str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=orderlist&sid='.$order['sid'].'">'.$order['title'].'</a>',$_G['cache']['plugin']['aljsc']['fahuotips'])));
		}
		
	}


	notification_add($_G['uid'], 'system',str_replace('{username}',$_G['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$shop['id'].'">'.$shop['title'].'</a>',$_G['cache']['plugin']['aljsc']['suctips'])));
	if($_G['cache']['plugin']['aljsc']['ismail']){
		$email_first = C::t("common_member")->fetch($_G['uid']);
		$email = $email_first['email'];
		sendmail_cron($email,$_G['cache']['plugin']['aljsc']['mailtitle'],str_replace('{username}',$_G['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$shop['id'].'">'.$shop['title'].'</a>',$_G['cache']['plugin']['aljsc']['suctips'])));
	}

	foreach(DB::fetch_all('select uid from '.DB::table('common_member').' where groupid in ('.dimplode($groups).')') as $u){
		notification_add($u['uid'], 'system',str_replace('{username}',$_G['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$shop['id'].'">'.$shop['title'].'</a>',$_G['cache']['plugin']['aljsc']['tsy'])));
		if($_G['cache']['plugin']['aljsc']['ismail']){
			$email_first=C::t("common_member")->fetch($u['uid']);
			$email=$email_first['email'];
			sendmail_cron($email,$_G['cache']['plugin']['aljsc']['mailtitle'],str_replace('{username}',$_G['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$shop['id'].'">'.$shop['title'].'</a>',$_G['cache']['plugin']['aljsc']['tsy'])));
		}
		
	}
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        showmessage(lang('plugin/aljsc','sc20'),'plugin.php?id=aljsc&act=order');
    }else{
        echo '<script>parent.location.href="plugin.php?id=aljsc&act=order"</script>';
        exit;
    }
}else{
	if($pluginid == 'aljsc' && $pid == 2){
		if ($shop['e']) {
			$limitnum=DB::result_first('select sum(num) from %t where goods_id=%d and uid=%d',array('aljbd_goods_order_list',$_GET['goods_id'],$_G['uid']));
			if(($limitnum + $num) > $shop['e'] || $num >$shop['e']){
				$lnum=($shop['e']-$limitnum)>=0 ? ($shop['e']-$limitnum):0;
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    showmessage("&#27599;&#20154;&#38480;&#25442;".$shop['e']."&#20010;&#65292;&#24744;&#24050;&#20817;&#25442;".$limitnum."&#20010;&#65292;&#36824;&#21487;&#20197;&#20817;&#25442;".$lnum."&#20010;");
                }else{
                    echo '<script>parent.showDialog("&#27599;&#20154;&#38480;&#25442;".$shop[\'e\']."&#20010;&#65292;&#24744;&#24050;&#20817;&#25442;".$limitnum."&#20010;&#65292;&#36824;&#21487;&#20197;&#20817;&#25442;".$lnum."&#20010;","")</script>';
                    exit;
                }
			}
		}
	}
	$orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
	if(C::t('#aljgwc#aljbd_goods_order')->fetch($orderid)) {
		showmessage('credits_addfunds_order_invalid', '', array(), array('showdialog' => 1, 'showmsg' => true, 'closetime' => true));
	}
	
	
	if ($goods['amount'] < $num) {
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            showmessage($goods['name'].'&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;');
        }else{
            echo '<script>parent.showDialog("'.$goods['name'].'&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;","")</script>';
            exit;
        }

	}
	
	if (TIMESTAMP > $goods['endtime']  && !empty($goods['endtime'])) {
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            showmessage($goods['name'].'&#19981;&#22312;&#27963;&#21160;&#26102;&#38388;&#20869;');
        }else{
            echo '<script>parent.showDialog("'.$goods['name'].'&#19981;&#22312;&#27963;&#21160;&#26102;&#38388;&#20869;","")</script>';
            exit;
        }
	}
    //$yuantotalprice = $goods['price1']*$num;
    //debug($yuantotalprice.'==='.$totalprice);
    if(($goods['price1']*$num !=$totalprice) || $goods['extcredit']*$num !=$pay_ext){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            showmessage('&#35746;&#21333;&#24322;&#24120;&#35831;&#37325;&#35797;');
        }else{
            echo '<script>parent.showDialog("&#35746;&#21333;&#24322;&#24120;&#35831;&#37325;&#35797;","")</script>';
            exit;
        }
    }
	
	if($goods['goodstype'] == 1){
		$category = 1;
	}
	$goods_name.=$goods['name'];
	$insertarray = array(
		'orderid' => $orderid,
		'goods_id' => $goods['id'],
		'shop_id'  => $shop_id,
		'uid'      => $_G['uid'],
		'num'      => $num,
		'price'	   => $goods['price1'],
		'ip'	   => $_G['clientip'],
		'dateline' => $_G['timestamp'],
		'content'  => $_GET['content'],
		'path'  => $_GET['path'],
		'name'  => $goods['name'],
		'fare'  => $goods['fare'],
		'fare_desc'  => $goods['fare_desc'],
		'pid'  => $pid,
		'category'  => $category,
		'pay_ext' => $goods['extcredit']
	);
	
	C::t('#aljgwc#aljbd_goods_order_list')->insert($insertarray);
	
	C::t('#'.$pluginid.'#'.$pluginid)->update_num_by_id($goods['id'],$num);
	
	if($isappbyme && $_GET['payment'] == 1){
		$_GET['payment'] = 3;
	}
	$orderarray=array(
		'orderid' => $orderid,
		'status' => '1',
		'uid' => $_G['uid'],
		'username' => $_G['username'],
		'shop_id' => $shop_id,
		'price' => $totalprice,
		'submitdate' => $_G['timestamp'],
		'remarks' => $_GET['content'].$_GET['remarks'],
		'stitle' => $goods_name,
		'payment' => $_GET['payment'],
		'fare' => $fare,
		'pid'  => $pid,
		'category'  => $category,
		'browser'  => $_SERVER['HTTP_USER_AGENT'],
        'pay_ext' => $pay_ext
	);
	if($_G['mobile']){//1���ֻ���2��PC
		$orderarray['mobile'] = 1;
	}else{
		$orderarray['mobile'] = 2;
	}
	
	if(($config['service'] == 'create_direct_pay_by_user' && $_GET['payment'] == '2') || ($_GET['payment'] == '2' && $_G['mobile'])){
		$orderarray['d'] = 1;
	}
	$orderarray['address'] = serialize($address);
	C::t('#aljgwc#aljbd_goods_order')->insert($orderarray);
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        showmessage($alj_lang['Single_success'],'plugin.php?id=aljgwc&act=cart_pay&orderid='.$orderid.'&pluginid='.$pluginid, array(), array('header' => true));
    }else{
        echo '<script>parent.location.href="plugin.php?id=aljgwc&act=cart_pay&orderid='.$orderid.'&pluginid='.$pluginid.'"</script>';
        exit;
    }
}
//From: Dism��taobao��com
?>