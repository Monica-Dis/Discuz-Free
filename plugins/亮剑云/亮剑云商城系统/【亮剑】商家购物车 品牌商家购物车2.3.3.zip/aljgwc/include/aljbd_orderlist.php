 <?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
 if($_G['cache']['plugin']['aljspt']['is_aljspt'] && file_exists("source/plugin/aljht/function/pt_order.php")){
     require_once 'source/plugin/aljht/function/pt_order.php';
     pt_grouporderstate_auto();
     pt_orderstate_auto();
 }
$regionlist=C::t('#aljgwc#aljgwc_region')->range();
$page = intval($_GET['page']);
$currpage = $page?$page:1;
$perpage = 10;
$start = ($currpage-1)*$perpage;
$bids = DB::fetch_all('select id from %t where uid = %d',array('aljbd',$_G['uid']));
foreach($bids as $bid){
	$ids[] = $bid['id'];
}
$bids = implode(',',$ids);
//DB::query("update %t set status=7 WHERE status=1 and submitdate+900 < %i ",array('aljbd_goods_order',TIMESTAMP));//�������ڶ���
$queryorder = DB::fetch_all('select * from %t where status=1 and submitdate+900 < %i and pid=0',array('aljbd_goods_order',TIMESTAMP));
foreach ($queryorder as $qok => $qov){
    //�������ڶ���
    if(DB::query("update %t set status=7 WHERE status=1 and orderid=%s ",array('aljbd_goods_order',$qov['orderid']))){
        if($qov['pay_integral']>0 && $qov['pay_ext']>0){
            updatemembercount(
                $qov['uid'],
                array($_G['cache']['plugin']['aljbdx']['exttype'] => $qov['pay_ext']),
                '',
                '',
                '',
                '',
                '&#21462;&#28040;&#35746;&#21333;&#36864;&#36824;&#31215;&#20998;',
                '&#21462;&#28040;&#35746;&#21333;&#36864;&#36824;&#25269;&#29616;&#31215;&#20998;' . $qov['pay_ext'] . $_G['setting']['extcredits'][$_G['cache']['plugin']['aljbdx']['exttype']]['title'] . '&#44;&#35746;&#21333;&#21495;&#65306;' . $qov['orderid']);
        }
        gaddnum($qov);
    }

}
$conn[] ='aljbd_goods_order';
$where = 'where 1 and pid = 0 ';

if($_GET['ord'] == 'dianp'){
    $where .= ' and shop_id in(%i)';
    if($bids){
        $conn[] = $bids;
    }else{
        $conn[] = 0;
    }
}elseif($_GET['ord'] == 'ge'){
    $where .= ' and uid = %d';
    $conn[] = $_G['uid'];
}else{
    if(!in_array($_G['groupid'],$admingroups)){
        if($_GET['ord'] == 'dianp'){
            $where .= ' and shop_id in(%i)';
            $conn[] = $bids;
        }else{
            $where .= ' and uid = %d';
            $conn[] = $_G['uid'];
        }
    }
}

if($_GET['status']){
	
	$status = intval($_GET['status']);
	if($status == 99){
			$where .= ' and status > %d';
			$conn[] = 1;
	}else{
		$where .= ' and status = %d';
		$conn[] = $status;
	}
}
$keyword = stripsearchkey($_GET['keyword']);
$keyword = '%'.$keyword.'%';
if($_GET['order_good'] == 'order_id'){
	if($_GET['keyword']){
		$where .= ' and orderid like %s';
		$conn[] = $keyword;
	}
}elseif($_GET['order_good'] == 'product_name'){
	if($_GET['keyword']){
		$where .= ' and stitle like %s';
		$conn[] = $keyword;
	}
}elseif($_GET['order_good'] == 'user_name'){
	if($_GET['keyword']){
		$where.=" and username like %s";
		$conn[] = $keyword;
	}
}elseif($_GET['order_good'] == 'shop_id'){
	if($_GET['keyword']){
		$conn[] = stripsearchkey($_GET['keyword']);
		$where.=" and shop_id = %d";
	}
}else{
	if($_GET['keyword']){
		$where.=" and (orderid like %s or stitle like %s)";
		$conn[] = $keyword;
		$conn[] = $keyword;
	}
}


$num = DB::result_first('select count(*) from %t '.$where,$conn);
$start=($currpage-1)*$perpage;
$where .= ' order by submitdate desc';
$where .= ' limit %d,%d';
$conn[] = $start;
$conn[] = $perpage;

$orderlist = DB::fetch_all('select * from %t '.$where,$conn);
$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=orderlist&ord='.$_GET['ord'].'&status='.$_GET['status'].'&keyword='.$_GET['keyword'].'&order_good='.$_GET['order_good'], 0, 11, false, false);
$navtitle = '&#35746;&#21333;&#31649;&#29702;-'.$_G['cache']['plugin']['aljbd']['title'];
$metakeywords =  $bd['other']?$bd['other']:$_G['cache']['plugin']['aljbd']['keywords'];
$metadescription = $_G['cache']['plugin']['aljbd']['description'];
if($_GET['ajax'] == 'yes'){
    $max = ceil($num/$perpage);

    if($currpage == 1){
        $max_page ='<input type="hidden" id="max-page" value="'.$max.'">';
    }

    if($currpage == $max){
        $mes = '<div class="c_click_see" id="more" style="background: none;float: left;">'.$aljbdlang['php']['No_more_data'].'</div>';
    }
    include template('aljgwc:ajaxOrderList');
}else{
    if(0){
        include template($common_template_pluginid.':new/list/orderlist');
    }else {
        include template('aljgwc:orderlist_new');
    }
}

function gaddnum($order){
 $orderlist = DB::fetch_all('select * from %t where orderid=%s',array('aljbd_goods_order_list',$order['orderid']));
 foreach($orderlist as $k => $v){
     DB::query('update %t set amount=amount+%d where id=%d', array('aljbd_goods',$v['num'],$v['goods_id']));
     $goods=C::t('#aljbd#aljbd_goods')->fetch($v['goods_id']);
     if($goods['attr_sku']){
         $attr_sku = unserialize($goods['attr_sku']);
         foreach($attr_sku as $sk => $sv){
             if($v['path'] == $sv['path']){
                 $attr_sku[$sk]['stock'] = $attr_sku[$sk]['stock']+$v['num'];
             }
         }
         C::t('#aljbd#aljbd_goods')->update($v['goods_id'],array('attr_sku'=>serialize($attr_sku)));
         unset($attr_sku);
         unset($goods);
     }
 }
}
//From: Dism��taobao��com
?>