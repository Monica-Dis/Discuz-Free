<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(C::t('#aljbd#aljbd_wuliu')->fetch($_GET['orderid'])){
	C::t('#aljbd#aljbd_wuliu')->update($_GET['orderid'],array(
		'companyname' => $_GET['companyname'],
		'worderid' => $_GET['worderid'],
		'updatetime' => TIMESTAMP,
	));


	$order = C::t('#aljgwc#aljbd_goods_order')->fetch($_GET['orderid']);
	$shop_order=C::t('#aljgwc#aljbd_goods_order_list')->fetch_all_by_orderid($notify['out_trade_no']);
		
	foreach($shop_order as $key => $val){
		notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&gid='.$val['goods_id'].'">'.$val['name'].'</a>',$_G['cache']['plugin']['aljbd']['fahuotips'])));
		if($_G['cache']['plugin']['aljbd']['time']){
			$email_first=C::t("common_member")->fetch($order['uid']);
			$email=$email_first['email'];

			if($email_first['email']){
				$m=str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&gid='.$val['goods_id'].'">'.$val['name'].'</a>',$_G['cache']['plugin']['aljbd']['fahuotips']));
				newsendmail_cron($email,$_G['cache']['plugin']['aljbd']['mailtitle'],$m);
			}
		}
	}
	C::t('#aljbd#aljbd_goods_order')->update_status_by_orderid($_GET['orderid']);
	showmessage(lang('plugin/aljbd','s9'), 'plugin.php?id=aljbd&act=orderlist');
}else{
	C::t('#aljbd#aljbd_wuliu')->insert(array(
		'orderid' => $_GET['orderid'],
		'type' => 1,
		'companyname' => $_GET['companyname'],
		'worderid' => $_GET['worderid'],
		'dateline' => TIMESTAMP,
	));
	C::t('#aljgwc#aljbd_goods_order')->update_status_by_orderid($_GET['orderid']);

	$order = C::t('#aljbd#aljbd_order')->fetch($_GET['orderid']);
	$shop_order=C::t('#aljgwc#aljbd_goods_order_list')->fetch_all_by_orderid($notify['out_trade_no']);
		
	foreach($shop_order as $key => $val){
		notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&gid='.$val['goods_id'].'">'.$val['name'].'</a>',$_G['cache']['plugin']['aljbd']['fahuotips'])));
		if($_G['cache']['plugin']['aljbd']['time']){
			$email_first=C::t("common_member")->fetch($order['uid']);
			$email=$email_first['email'];

			if($email_first['email']){
				$m=str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&gid='.$val['goods_id'].'">'.$val['name'].'</a>',$_G['cache']['plugin']['aljbd']['fahuotips']));
				newsendmail_cron($email,$_G['cache']['plugin']['aljbd']['mailtitle'],$m);
			}
		}
	}
	showmessage(lang('plugin/aljbd','tg44'), 'plugin.php?id=aljbd&act=orderlist');
}
//From: Dism��taobao��com
?>