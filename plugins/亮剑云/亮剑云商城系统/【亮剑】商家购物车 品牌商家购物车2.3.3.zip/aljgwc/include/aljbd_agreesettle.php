<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if ($_GET['settleid']){
	DB::query('update %t set status = 1,dateline = %d where settleid = %s',array('aljbd_goods_settle',TIMESTAMP,$_GET['settleid']));
}
//From: Dism��taobao��com
?>