<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$regionlist=C::t('#aljgwc#aljgwc_region')->range();
$page = intval($_GET['page']);
$currpage = $page?$page:1;
$perpage = 10;
$start = ($currpage-1)*$perpage;
if($_G['cache']['plugin']['aljtg']['tobrand'] && file_exists('source/plugin/aljbd/aljbd.inc.php')){
	//$bids = DB::fetch_all('select id from %t where uid = %d',array('aljbd',$_G['uid']));
	$bids_bd = DB::fetch_all('select id from %t where uid = %d',array('aljbd',$_G['uid']));
	$bids_tg = DB::fetch_all('select id from %t where uid = %d',array('aljtg',$_G['uid']));
	$bids = array_merge($bids_bd, $bids_tg);
	
}else{
	$bids = DB::fetch_all('select id from %t where uid = %d',array('aljtg',$_G['uid']));
}
foreach($bids as $bid){
	$ids[] = $bid['id'];
}

$bids = implode(',',$ids);

$conn[] ='aljbd_goods_order';
$where = 'where pid=1 ';
if(!in_array($_G['groupid'],$admingroups)){
	if($_GET['ord'] == 'dianp'){
		$where .= ' and shop_id in(%i)';
		$conn[] = $bids;
	}else{
		$where .= ' and uid = %d';
		$conn[] = $_G['uid'];
	}
}
if($_GET['status']){
	
	$status = intval($_GET['status']);
	if($status == 99){
			$where .= ' and status > %d  and status <6';
			$conn[] = 1;
	}else{
		$where .= ' and status = %d';
		$conn[] = $status;
	}
}
$keyword = stripsearchkey($_GET['keyword']);
$keyword = '%'.$keyword.'%';
if($_GET['order_good'] == 'order_id'){
	if($_GET['keyword']){
		$where .= ' and orderid like %s';
		$conn[] = $keyword;
	}
}elseif($_GET['order_good'] == 'product_name'){
	if($_GET['keyword']){
		$where .= ' and stitle like %s';
		$conn[] = $keyword;
	}
}elseif($_GET['order_good'] == 'user_name'){
	if($_GET['keyword']){
		$where.=" and username like %s";
		$conn[] = $keyword;
	}
}elseif($_GET['order_good'] == 'shop_id'){
	if($_GET['keyword']){
		$conn[] = stripsearchkey($_GET['keyword']);
		$where.=" and shop_id = %d";
	}
}else{
	if($_GET['keyword']){
		$where.=" and (orderid like %s or stitle like %s)";
		$conn[] = $keyword;
		$conn[] = $keyword;
	}
}

$num = DB::result_first('select count(*) from %t '.$where,$conn);
if($status == 99){
    $sumprice = DB::result_first('select sum(price) from %t '.$where,$conn);
}
$start=($currpage-1)*$perpage;
$where .= ' order by submitdate desc';
$where .= ' limit %d,%d';
$conn[] = $start;
$conn[] = $perpage;

$orderlist = DB::fetch_all('select * from %t '.$where,$conn);
$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljtg:member&act=orderlist&ord='.$_GET['ord'].'&status='.$_GET['status'].'&keyword='.$_GET['keyword'].'&order_good='.$_GET['order_good'], 0, 11, false, false);
require_once 'source/plugin/aljgwc/lang/lang.php';
$aljtglang['template']['Order_management'] = '&#35746;&#21333;&#31649;&#29702;';//��������
include template('aljgwc:aljtg/orderlist_new');
?>