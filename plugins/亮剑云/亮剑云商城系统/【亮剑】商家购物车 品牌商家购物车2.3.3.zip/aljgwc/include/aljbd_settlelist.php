<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(in_array($_G['groupid'],$admingroups)){
	$num = DB::result_first('select count(*) from %t',array('aljbd_goods_settle'));
	$settlelist = DB::fetch_all('select * from %t order by applytime desc limit %d,%d',array('aljbd_goods_settle',$start,$perpage));
}else{
	$num = DB::result_first('select count(*) from %t where uid = %d',array('aljbd_goods_settle',$_G['uid']));
	$settlelist = DB::fetch_all('select * from %t where uid = %d order by applytime desc limit %d,%d',array('aljbd_goods_settle',$_G['uid'],$start,$perpage));
}
//From: Dism��taobao��com
?>