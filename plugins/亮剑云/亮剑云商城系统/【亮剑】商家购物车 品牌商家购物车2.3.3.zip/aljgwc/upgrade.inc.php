<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql ="ALTER TABLE  ".DB::table('aljbd_goods_order')." ADD  `give_integral` INT NOT NULL ,
ADD  `pay_integral` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljgwc_payorderlog')." (
`id` int(11) NOT NULL AUTO_INCREMENT,
  `error` text NOT NULL,
  `time` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
)";
if(DB::query($sql,'SILENT')){print('create table `aljgwc_payorderlog` succeed!<br>');}
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljgwc_refund')." (
  `orderid` char(32) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `pid` int(11) NOT NULL,
  `payment` tinyint(4) NOT NULL,
  `gid` int(11) NOT NULL,
  `addtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `refund_type` int(11) NOT NULL,
  `content` text NOT NULL,
  `imgs` text NOT NULL,
  `state` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `guid` int(11) NOT NULL,
  `goodsname` varchar(255) NOT NULL,
  PRIMARY KEY (`orderid`),
  UNIQUE KEY `orderid` (`orderid`),
  KEY `guid` (`guid`),
  KEY `uid` (`uid`)
);";
if(DB::query($sql,'SILENT')){print('create table `aljgwc_refund` succeed!<br>');}
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljbd_comment_goods')." (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `gid` int(10) NOT NULL,
  `orderid` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `overall_ticket` int(10) NOT NULL DEFAULT '0',
  `descriptiongrade` int(10) NOT NULL DEFAULT '0',
  `environmentgrade` int(10) NOT NULL DEFAULT '0',
  `attitudegrade` int(10) NOT NULL,
  `deliveryspeed` int(10) NOT NULL,
  `displayorder` varchar(255) NOT NULL DEFAULT '0',
  `dateline` varchar(255) NOT NULL,
  `upid` int(10) NOT NULL,
  `uusername` varchar(255) NOT NULL,
  `subcatid` varchar(255) NOT NULL,
  `uuid` int(11) NOT NULL,
  `imgs` text NOT NULL,
  `bid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `upid` (`upid`),
  KEY `gid` (`gid`)
);";

if(DB::query($sql,'SILENT')){print('create table `aljbd_comment_goods` succeed!<br>');}

$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljgwc_statistics')." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `total` decimal(10,2) NOT NULL,
  `withdrawals` decimal(10,2) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `addtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `pid` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `pid` (`pid`)
);";
if(DB::query($sql,'SILENT')){print('create table `aljgwc_statistics` succeed!<br>');}
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljgwc_region')." (
  `id` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  `level` tinyint(3) NOT NULL,
  `havechild` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `upid` (`upid`)
);";
if(DB::query($sql,'SILENT')){print('create table `aljgwc_region` succeed!<br>');}
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljbd_address')." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region` int(11) NOT NULL,
  `region1` int(11) NOT NULL,
  `region2` int(11) NOT NULL,
  `addressDetail` varchar(255) NOT NULL,
  `post` int(11) NOT NULL,
  `fullName` varchar(100) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `phoneSection` int(11) NOT NULL,
  `phoneCode` int(11) NOT NULL,
  `phoneExt` int(11) NOT NULL,
  `defaultAddress` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
);";
if(DB::query($sql,'SILENT')){print('create table `aljbd_address` succeed!<br>');}
$sql ="ALTER TABLE  ".DB::table('aljbd_address')." ADD  `province` VARCHAR( 255 ) NOT NULL ,
ADD  `city` VARCHAR( 255 ) NOT NULL ,
ADD  `district` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljgwc_paysetting')." (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY  (`key`)
);";
if(DB::query($sql,'SILENT')){print('create table `aljgwc_paysetting` succeed!<br>');}
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljbd_goods_settle')." (
  `settleid` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `account` varchar(255) NOT NULL,
  `settleprice` varchar(255) NOT NULL,
  `payment` tinyint(3) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `applytime` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `uid` int(10) NOT NULL,
  PRIMARY KEY (`settleid`)
);";
if(DB::query($sql,'SILENT')){print('create table `aljbd_goods_settle` succeed!<br>');}
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljbd_write_off_code')." (
  `password` bigint(12) NOT NULL,
  `orderid` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `shop_id` int(10) NOT NULL,
  `goods_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `endtime` int(10) NOT NULL,
  `status` int(10) NOT NULL,
  `type` tinyint(4) NOT NULL,
  PRIMARY KEY (`password`),
  KEY `orderid` (`orderid`),
  KEY `password` (`password`)
);";
if(DB::query($sql,'SILENT')){print('create table pre_aljbd_write_off_code succeed!<br>');}

if(file_exists("source/plugin/xydz/xydz.inc.php")){
	require_once 'source/plugin/xydz/include/upgrade.php';
}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `cid`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `cid`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `opentime` int(11) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `collage_num` int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `collage_num` int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `collage_order` char(32) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `collage_order` char(32) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `get_to_the_shop` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `get_to_the_shop` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `full` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `reduction` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `discount`  decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `pay_ext`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `pay_ext`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
if(file_exists("source/plugin/dz_3/dz_3.inc.php")){
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `q_ext`  int(10) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `p_pirce` decimal(10,2) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `default_pay`  varchar(255) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `pay_ext`  int(10) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `bili`  int(10) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljgwc')." ADD `pay_ext`  int(10) NOT NULL" ;
    DB::query($sql,'SILENT');
}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `commodity_type` tinyint(3) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_order add commodity_type succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `commodity_type` tinyint(3) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_order_list add commodity_type succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `deliverydate`  int(10) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_order add deliverydate succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljgwc')." ADD `path`  varchar(100) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljgwc add path succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `path`  varchar(100) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_order_list add path succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_address')." CHANGE `phoneSection` `phoneSection` VARCHAR( 11 ) NOT NULL " ;
if(DB::query($sql,'SILENT')){print('aljbd_address CHANGE phoneSection succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." CHANGE `status` `status` TINYINT( 3 ) NOT NULL " ;
if(DB::query($sql,'SILENT')){print('aljgwc CHANGE status succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljgwc')." ADD `fare_desc`  int(10) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljgwc add fare_desc succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `fare_desc`  int(10) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_order add fare_desc succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `proportion`  int(10) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_order add proportion succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `ext`  int(11) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_order add ext succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `fare_desc`  int(10) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_order_list add fare_desc succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljgwc')." ADD `ext` int(11) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljgwc add ext succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_settle')." ADD `pid` tinyint(3) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_settle add pid succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljtg_goods')." ADD `fare` decimal(8,2) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljtg_goods add fare succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `category` tinyint(3) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_order_list add category succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `category` tinyint(3) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_order add category succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljgwc')." ADD `pid` tinyint(3) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljgwc add pid succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `pid` tinyint(3) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_order_list add pid succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `pid` tinyint(3) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_order add pid succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `fare` decimal(8,2) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods add fare succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `fare` decimal(8,2) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_order add fare succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `address` text NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_order add address succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_video')." ADD `rubbish`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `original_price` decimal(8,2) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_order add original_price succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `browser` varchar(255) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_order add browser succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `mobile`  int(10) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljbd_goods_order add mobile succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljgwc')." ADD `browser` varchar(255) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljgwc add browser succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljgwc')." ADD `mobile`  int(10) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('aljgwc add mobile succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `price` DECIMAL( 10, 2 ) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add price succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `orderid` char( 32 ) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add orderid succeed!<br>');}
echo '<br/>repair succeed';
?>