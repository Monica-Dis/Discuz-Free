<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if($_GET['pluginid']){
	$pluginid=$_GET['pluginid'];
}else{
	if(DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljbd'))){
		$pluginid='aljbd';
	}else if(DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljsc'))){
		$pluginid='aljsc';
	}else{
		$pluginid='aljtg';
	}
}
if(!isset($_G['cache']['plugin'])) {
	loadcache('plugin');
}
if($pluginid == 'aljtg'){
	$pid = 1;
	$ggurl = 'plugin.php?id=aljtg&act=view&gid={goods_id}';
	$orderlisturl = 'plugin.php?id=aljtg:member&act=orderlist';
}elseif($pluginid == 'aljsc'){
	$pid = 2;
	$ggurl = 'plugin.php?id=aljsc&act=view&sid={goods_id}';
	$orderlisturl = 'plugin.php?id=aljgwc&plugin=aljsc&act=orderlist';
}else{
	$fare_desc = array('1'=>'&#21253;&#37038;','2'=>'&#21040;&#20184;');
	$ggurl = 'plugin.php?id=aljbd&act=goodview&bid={bid}&gid={goods_id}';
	$orderlisturl = 'plugin.php?id=aljbd&act=orderlist';
}
$biaoshi = '&pluginid='.$pluginid;
require_once 'source/plugin/aljgwc/function/function_core.php';
if($_GET['act'] == 'wuliu'){
	$orderid = addslashes($_GET['orderid']);
	$order=C::t('#aljgwc#aljbd_goods_order')->fetch($orderid);
	if(submitcheck('formhash')){
		C::t('#'.$pluginid.'#'.$pluginid.'_wuliu')->insert(array(
			'orderid' => $_GET['orderid'],
			'type' => 1,
			'companyname' => $_GET['companyname'],
			'worderid' => $_GET['worderid'],
			'dateline' => TIMESTAMP,
		));
		if(!$order['d'] && $order['payment'] == '2'){
			$order['transaction_id'] = $order['buyer'];
			$order['invoice_no'] = $_GET['worderid'];
			$order['logistics_name'] = diconv($_GET['companyname'],CHARSET,'gbk');
			$order['express'] = diconv($_GET['c'],CHARSET,'gbk');
			alipaysend($order);

		}else{
			C::t('#aljgwc#aljbd_goods_order')->update_status_by_orderid($_GET['orderid']);

			//$order = C::t('#aljbd#aljbd_order')->fetch($_GET['orderid']);
			$shop_order=C::t('#aljgwc#aljbd_goods_order_list')->fetch_all_by_orderid($notify['out_trade_no']);
				
			foreach($shop_order as $key => $val){
				notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="'.str_replace(array('{bid}','{goods_id}'),array($val['shop_id'],$val['goods_id']),$ggurl).'">'.$val['name'].'</a>',$_G['cache']['plugin'][$pluginid]['fahuotips'])));
				if($_G['cache']['plugin'][$pluginid]['time']){
					$email_first=C::t("common_member")->fetch($order['uid']);
					$email=$email_first['email'];

					if($email_first['email']){
						$m=str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="'.str_replace(array('{bid}','{goods_id}'),array($val['shop_id'],$val['goods_id']),$ggurl).'">'.$val['name'].'</a>',$_G['cache']['plugin'][$pluginid]['fahuotips']));
						newsendmail_cron($email,$_G['cache']['plugin'][$pluginid]['mailtitle'],$m);
					}
				}
			}
		}
		cpmsg('&#21457;&#36135;&#25104;&#21151;', 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljgwc&pmod=order'.$biaoshi, 'succeed');
		
	}else{
		$wuliu = C::t('#'.$pluginid.'#'.$pluginid.'_wuliu')->fetch($_GET['orderid']);
		include template('aljgwc:awuliu');
	}
} else if($_GET['act'] == 'delete'){
	C::t('#aljgwc#aljbd_goods_order')->delete($_GET['orderid']);
	cpmsg('&#21024;&#38500;&#25104;&#21151;', 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljgwc&pmod=order'.$biaoshi, 'succeed');
}else if($_GET['act']=='receipt'){
	$order = C::t('#aljgwc#aljbd_goods_order') -> fetch($_GET['orderid']);
	if($order['uid'] == $_G['uid']){
		DB::query("update %t set status=4 where orderid = %s",array('aljbd_goods_order',$_GET['orderid']));
	}
	cpmsg('&#30830;&#35748;&#25910;&#36135;&#25104;&#21151;','action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljgwc&pmod=order'.$biaoshi);
} else{
	include template('aljgwc:order_nav');
	$currpage=$_GET['page']?$_GET['page']:1;
	$perpage=10;
	$conn[] ='aljbd_goods_order';
	$where = 'where 1';
	$where .= ' and pid = %d';
	$conn[] = $pid;
	if($_GET['status']){
		$status = intval($_GET['status']);
		if($status == 99){
			$where .= ' and status > %d';
			$conn[] = 1;
		}else{
			$where .= ' and status = %d';
			$conn[] = $status;
		}
		
	}
	if($_GET['payment']){
		$payment = intval($_GET['payment']);
		$where .= ' and payment = %d';
		$conn[] = $payment;
	}
	if($pluginid == 'aljtg' || $pluginid == 'aljsc'){
		$starttime = strtotime($_GET['starttime']);
		$endtime = strtotime($_GET['endtime']);
		if($_GET['starttime']){
			$where .= ' and submitdate >= %s';
			$conn[] = $starttime;
		}
		if($_GET['endtime']){
			$where .= ' and submitdate <= %s';
			$conn[] = $endtime;
		}
		if($_GET['keyword']){
			$keyword = stripsearchkey($_GET['keyword']);
			$keyword = '%'.$keyword.'%';
			
			if($_GET['order_good']){
				
				if($_GET['order_good']=='product_name'){
					$conn[] = $keyword;
					$where.=" and stitle like %s";
				}else if($_GET['order_good']=='order_id'){
					$conn[] = $keyword;
					$where.=" and orderid like %s";
				}else if($_GET['order_good']=='user_name'){
					$conn[] = $keyword;
					$where.=" and username like %s";
				}else if($_GET['order_good']=='shop_id'){
					$conn[] = stripsearchkey($_GET['keyword']);
					$where.=" and shop_id = %d";
				}
					
			}
		}
		
	}else{
		if($_GET['keyword']){
			$keyword = stripsearchkey($_GET['keyword']);
			$keyword = '%'.$keyword.'%';
			$where .= ' and (orderid like %s or shop_id like %s)';
			$conn[] = $keyword;
			$conn[] = $keyword;
		}
	}
	
	
	$num = DB::result_first('select count(*) from %t '.$where,$conn);
	$start=($currpage-1)*$perpage;
	$where .= ' order by submitdate desc';
	$where .= ' limit %d,%d';
	$conn[] = $start;
	$conn[] = $perpage;
	$orderlist = DB::fetch_all('select * from %t '.$where,$conn);
	$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljgwc&pmod=order'.$biaoshi.'&keyword='.$_GET['keyword'].'&order_good='.$_GET['order_good'].'&status='.$_GET['status'].'&payment='.$_GET['payment'].'&starttime='.$_GET['starttime'].'&endtime='.$_GET['endtime'], 0, 11, false, false);
	$regionlist=C::t('#aljgwc#aljgwc_region')->range();
	if($pluginid == 'aljtg'){
		include template('aljgwc:aljtg/adminorder');
	}else if($pluginid == 'aljsc'){
		include template('aljgwc:aljsc/adminorder');
	}else{
		include template('aljgwc:aljbd_adminorder');
	}
}
//From: Dism_taobao_com
?>