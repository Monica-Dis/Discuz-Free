<?php

/*
 * ����: Discuz!�����ƹ�����
 * Ӧ�ø���֧�֣�https://dism.taobao.com/
 * DisM.taobao.Com
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$_GET=dhtmlspecialchars($_GET);

if(submitcheck('formhash')){
	$record = C::t('#aljgwc#aljgwc_paysetting')->fetch('logo');

	foreach($_GET['settingsnew'] as $k=>$v){
		if(!C::t('#aljgwc#aljgwc_paysetting')->fetch($k)){
			C::t('#aljgwc#aljgwc_paysetting')->insert(array('key'=>$k,'value'=>trim($v)));
		}else{
			C::t('#aljgwc#aljgwc_paysetting')->update_value_by_key(trim($v),$k);
		}
	}
	cpmsg('&#37197;&#32622;&#25104;&#21151;&#65281;', 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljgwc&pmod=paysetting', 'succeed');
}else{
	$settings=C::t('#aljgwc#aljgwc_paysetting')->range();
	include template('aljgwc:paysetting');
}
//From: Dism��taobao��com
?>