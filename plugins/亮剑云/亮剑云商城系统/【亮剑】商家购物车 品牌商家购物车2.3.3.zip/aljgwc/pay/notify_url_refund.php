<?php
/**
 * ͨ��֪ͨ�ӿ�
 * ====================================================
 * ֧����ɺ�΢�Ż�����֧�����û���Ϣ���͵��̻��趨��֪ͨURL��
 * �̻����ջص���Ϣ�󣬸�����Ҫ�趨��Ӧ�Ĵ������̡�
 * 
*/

define('DISABLEXSSCHECK',true);
require '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
if(!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
require '../../../../source/plugin/aljgwc/function/function_core.php';
$xml = file_get_contents("php://input");
//$data = xmlToArray($xml);
$check = getSignVeryfy($_GET,$_GET['sign']);

if($check){
	$batch_no_array = DB::fetch_all('select * from %t where batch_no=%s and payment=2',array('aljgwc_refund',$_GET['batch_no']));
	$result_details = explode('#',$_GET['result_details']);
	foreach($result_details as $k => $v){
		$ddd = explode('^',$v);
		$suc[$ddd[0]] = $ddd[2];
	}
	//file_put_contents('../../../../source/plugin/aljgwc/pay/text.txt',count($batch_no_array).'|'.$_GET['success_num'],FILE_APPEND);
	foreach($batch_no_array as $k => $v){
		if($suc[$v['buyer']] == 'SUCCESS' && $v['state']<3){
			DB::update('aljgwc_refund',array('state'=>3,'result_details'=>$_GET['result_details'], 'updatetime' => TIMESTAMP),"orderid='".$v['orderid']."'");
			C::t('#aljgwc#aljbd_goods_order')->update($v['orderid'], array('status' => 6));
			//file_put_contents('../../../../source/plugin/aljgwc/pay/text.txt',$v['price'].'|'.$v['shop_id'].'|'.$v['guid'],FILE_APPEND);
			DB::query('update %t set refund=refund+%i,balance=balance-%i,dateline=%d where uid=%d and bid=%d',array('aljjs_brandsettle',$v['price'],$v['price'],TIMESTAMP,$v['guid'],$v['shop_id']));
		}else{
			if($_G['cache']['plugin']['aljqb']){
                insertlog($suc[$v['buyer']]);
			}
			DB::update('aljgwc_refund',array('state'=>1,'result_details'=>$_GET['result_details']),"orderid='".$v['orderid']."'");
		}
	}

	if(count($batch_no_array) == $_GET['success_num']){
		echo 'success';
		exit;
	}

	
}

function insertlog($error) {
    DB::insert('aljqb_payorderlog',array(
        'error'=> $error,
        'time'=> time(),
    ));
}
//From: Dism��taobao��com
?>
