<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
//start to put your own code 
$sql = <<<EOF
DROP TABLE IF  EXISTS `pre_aljgwc`;
DROP TABLE IF  EXISTS `pre_aljbd_goods_order`;
DROP TABLE IF  EXISTS `pre_aljbd_goods_order_list`;
DROP TABLE IF  EXISTS `pre_aljbd_goods_settle`;
DROP TABLE IF  EXISTS `pre_aljbd_address`;
DROP TABLE IF  EXISTS `pre_aljgwc_statistics`;
DROP TABLE IF  EXISTS `pre_aljgwc_region`;
DROP TABLE IF  EXISTS `pre_aljbd_comment_goods`;
DROP TABLE IF  EXISTS `pre_aljgwc_refund`;
EOF;

runquery($sql);
//finish to put your own code
$finish = TRUE;
?>