<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_aljbd_goods_settle extends discuz_table {

	public function __construct() {
		$this->_table = 'aljbd_goods_settle';
		$this->_pk    = 'settleid';

		parent::__construct();
	}
	public function update_status_by_settleid($settleid=''){
		DB::query('update %t set status=3 where settleid=%s',array($this->_table,$settleid));
	}
}
//From: Dism_taobao_com
?>