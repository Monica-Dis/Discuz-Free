<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljbd_comment_goods extends discuz_table{
	public function __construct() {

			$this->_table = 'aljbd_comment_goods';
			$this->_pk    = 'id';

			parent::__construct();
	}
	public function fetch_by_bid($bid=0){
		return DB::fetch_first('select * from %t where bid=%d and upid=0 and uid!=0',array($this->_table,$bid));
	}
	public function count_by_bid_upid($bid=0,$upid=0,$ask=0){
		return DB::result_first('select count(*) from %t where bid=%d and upid=%d and ask=%d and uid!=0',array($this->_table,$bid,$upid,$ask));
	}
	public function fetch_all_by_bid_upid($bid=0,$upid=0,$ask=0){
		return DB::fetch_all('select * from %t where bid=%d and upid=%d and ask=%d and uid!=0 order by id desc',array($this->_table,$bid,$upid,$ask));
	}
	public function fetch_all_by_upid($upid=0,$nid=0,$overall_ticket=0){
	    if($overall_ticket){
	        $con = ' and overall_ticket = '.intval($overall_ticket);
        }
		return DB::fetch_all('select * from %t where upid=%d and gid=%d '.$con.' order by id desc',array($this->_table,$upid,$nid));
	}
	public function count_by_bid($bid=0){
		return DB::fetch_all('select avg(k) k,avg(h) h,avg(f) f from %t where bid=%d and ask=0',array($this->_table,$bid));
	}
	public function count_avg_by_bid($bid=0){
		return DB::result_first('select (avg(h)+avg(f))/2 from %t where bid=%d and ask=0 and uid!=0',array($this->_table,$bid));
	}
	public function count_by_bid_all($bid=0){
		return DB::result_first('select count(*) from %t where gid=%d',array($this->_table,$bid));
	}
	public function fetch_all_by_bid_page($bid=0,$start=0,$perpage=0){
		return DB::fetch_all('select * from %t where gid=%d order by id desc limit %d,%d ',array($this->_table,$bid,$start,$perpage));
	}
	
}




?>