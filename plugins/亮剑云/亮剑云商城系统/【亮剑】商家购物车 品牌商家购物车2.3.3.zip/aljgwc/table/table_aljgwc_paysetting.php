<?php

/*
 * ����: Discuz!�����ƹ�����
 * Ӧ�ø���֧�֣�https://dism.taobao.com/
 * DisM.taobao.Com
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_aljgwc_paysetting extends discuz_table
{
	public function __construct() {

		$this->_table = 'aljgwc_paysetting';
		$this->_pk    = 'key';

		parent::__construct();
	}
	public function update_value_by_key($value='',$key=''){
		return DB::query('update %t set `value`=%s  where `key`=%s',array($this->_table,$value,$key));
	}

}
//From: Dism_taobao_com
?>