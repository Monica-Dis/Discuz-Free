<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_aljgwc_statistics extends discuz_table {

	public function __construct() {
		$this->_table = 'aljgwc_statistics';
		$this->_pk    = 'id';

		parent::__construct();
	}

	public function update_by_uid($uid=0) {
		return DB::query('UPDATE %t SET %i WHERE %i', array($this->_table, implode(',', $sql), $wheresql));
	}

}
//From: Dism_taobao_com
?>