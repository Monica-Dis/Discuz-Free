<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_aljbd_goods_order_list extends discuz_table {

	public function __construct() {
		$this->_table = 'aljbd_goods_order_list';
		$this->_pk    = 'orderid';

		parent::__construct();
	}
	
	public function fetch_all_by_orderid($orderid=0) {
		return DB::fetch_all("SELECT * FROM %t WHERE orderid=%s", array($this->_table,$orderid));
	}
	public function group_by_shopid($pid=0) {
		return DB::fetch_all("SELECT count(goods_id),shop_id,name,price,goods_id FROM %t WHERE pid=%d group by goods_id order by count(goods_id) desc limit %d,%d", array($this->_table,$pid,0,4));
	}
}
//From: Dism_taobao_com
?>