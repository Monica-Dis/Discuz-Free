<?php

/**
 *
 * @author DisM!Ӧ������[dism.taobao.com]
 * @version 1.0
 * @����̳����� http://docs.liangjianyun.com/
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class aljbzjAction{
    public $page;

    public function __construct($page) {
        $this->page = $page;
        $this->aljbdParameter();
    }
    /**
     *  �ŵ���ɱ�֤��
     *
     *
     * @return void
     */
    public function storeBzj () {
        global $admin_status,$_G;
        $num = DB::result_first('select count(*) from %t where tc_uid=%d',array('aljtsq_store',$_G['uid']));
        $store = DB::fetch_first('select * from %t where tc_id=%d',array('aljtsq_store',$_GET['store_id']));
        $bdlist=C::t('#aljtsq#aljtsq_store')->fetch_all_by_where(array('status'=>1,'uid'=>$_G['uid']));//����
        
        $this->page->assign('store_id', $store_id);
        $this->page->assign('store', $store);
        
        $this->page->assign('num', $num);
        $this->page->assign('bdlist', $bdlist);
        if($store['tc_uid']!=$_G['uid'] && !$admin_status){
            echo "<script>alert('".lang("plugin/aljbzj","aljbzj_php_1")."');window.history.go(-1);</script>";
            exit;
        }
        $bzj_info = DB::fetch_first('select * from %t where uid=%d and store_id=%d',array('aljbzj',$store['tc_uid'],$this->page->get->store_id));

        $th_bzj_info = DB::fetch_first('select * from %t where uid=%d and store_id=%d and status=2',array('aljbzj_log',$store['tc_uid'],$this->page->get->store_id));

        if($this->page->global->cache->plugin->aljbzj->bzj_rule == 1){//û��δ��������
            $fhcount = DB::result_first('select count(*) from %t where store_id=%d and status<3 and pid=0',array('aljbd_goods_order',$store['tc_id']));
            $gobackstatus = $fhcount>0 ? 0 : 1;
        }else if($this->page->global->cache->plugin->aljbzj->bzj_rule == 2){//û��δ����������δ�����˿��
            $fhcount = DB::result_first('select count(*) from %t where store_id=%d and status<3 and pid=0',array('aljbd_goods_order',$store['tc_id']));
            $refund_count = DB::result_first('select count(*) from %t where store_id=%d and state<2 and pid=0',array('aljgwc_refund',$store['tc_id']));
            $gobackstatus = ($fhcount>0 || $refund_count>0)  ? 0 : 1;
        }else if($this->page->global->cache->plugin->aljbzj->bzj_rule == 3){//������ʱ�䣬����ÿ���
            $gobackstatus = ($bzj_info['addtime'] + $this->page->global->cache->plugin->aljbzj->bzj_rule_time) < TIMESTAMP  ? 0 : 1;
        }else if($this->page->global->cache->plugin->aljbzj->bzj_rule == 4){//���̵���
            $gobackstatus = $store['tc_status'] == 3  ? 1 : 0;
        }else if($this->page->global->cache->plugin->aljbzj->bzj_rule == 5){//��ʱ����
            $gobackstatus = 1;
        }
        $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$store['vipid']));
        
        $bzj_price = $vipdata[bzj_price]>0 ? $vipdata[bzj_price] : $this->page->global->cache->plugin->aljbzj->bzj_price;
        $c_url = 'plugin.php?id=aljbzj&c=aljbzj&a=storeBzj&store_id=';
        $this->page->assign('bzj_info', $bzj_info);
        $this->page->assign('c_url', $c_url,true);
        $this->page->assign('gobackstatus', $gobackstatus);
        $this->page->assign('th_bzj_info', $th_bzj_info);
        $this->page->assign('bzj_price', $bzj_price);
        $this->page->assign('navtitle', lang("plugin/aljbzj","aljbzj_php_2"));
        $this->page->display();
    }
    /**
     *  ��ѯ��֤���Ƿ����
     *
     *
     * @return int 0=δ���� 1=�ѽ���
     */
    public function isBzj () {
        global $_G;
        $bzj_info = DB::fetch_first('select * from %t where uid=%d and bid=%d ',array('aljbzj',$_G['uid'],$this->page->get->bid));
        if($bzj_info['price']>0){
            echo 1;
        }else{
            echo 0;
        }
        exit;
    }
    /**
     *  ��֤��
     *
     *
     * @return void
     */
    public function aljbzj () {
        global $admin_status,$_G;
        if(!$_G['cache']['plugin']['aljbd']){
            header("location: plugin.php?id=aljbzj&c=aljbzj&a=storeBzj&store_id=".$_GET[store_id]);
            exit;
        }
        $num=C::t('#aljbd#aljbd')->count_by_status(1,$this->page->global->uid,'','','','',0,'','','','','','');
        if($num == 1 && !$this->page->get->bid){
            $my_bd=C::t('#aljbd#aljbd')->fetch_by_uid($this->page->global->uid);
            if($my_bd){
                header("location: plugin.php?id=aljbzj&bid=".$my_bd[id]);
                exit;
            }
        }
        $bd = C::t('#aljbd#aljbd')->fetch($this->page->get->bid);
        if($bd['uid']!=$_G['uid'] && !$admin_status){
            echo "<script>alert('".lang('plugin/aljbd','noexists')."');window.history.go(-1);</script>";
            exit;
        }
        $bzj_info = DB::fetch_first('select * from %t where uid=%d and bid=%d ',array('aljbzj',$bd['uid'],$this->page->get->bid));

        $th_bzj_info = DB::fetch_first('select * from %t where uid=%d and bid=%d and status=2',array('aljbzj_log',$bd['uid'],$this->page->get->bid));
        $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,0,0,$this->page->global->uid,'','','','','','','','','','','',0);

        if($this->page->global->cache->plugin->aljbzj->bzj_rule == 1){//û��δ��������
            $fhcount = DB::result_first('select count(*) from %t where shop_id=%d and status<3 and pid=0',array('aljbd_goods_order',$bd['id']));
            $gobackstatus = $fhcount>0 ? 0 : 1;
        }else if($this->page->global->cache->plugin->aljbzj->bzj_rule == 2){//û��δ����������δ�����˿��
            $fhcount = DB::result_first('select count(*) from %t where shop_id=%d and status<3 and pid=0',array('aljbd_goods_order',$bd['id']));
            $refund_count = DB::result_first('select count(*) from %t where shop_id=%d and state<2 and pid=0',array('aljgwc_refund',$bd['id']));
            $gobackstatus = ($fhcount>0 || $refund_count>0)  ? 0 : 1;
        }else if($this->page->global->cache->plugin->aljbzj->bzj_rule == 3){//������ʱ�䣬����ÿ���
            $gobackstatus = ($bzj_info['addtime'] + $this->page->global->cache->plugin->aljbzj->bzj_rule_time) < TIMESTAMP  ? 0 : 1;
        }else if($this->page->global->cache->plugin->aljbzj->bzj_rule == 4){//���̵���
            $gobackstatus = $bd['status'] == 2  ? 1 : 0;
        }else if($this->page->global->cache->plugin->aljbzj->bzj_rule == 5){//��ʱ����
            $gobackstatus = 1;
        }
        $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$bd['vipid']));
        $bzj_price = $vipdata[bzj_price]>0 ? $vipdata[bzj_price] : $this->page->global->cache->plugin->aljbzj->bzj_price;
        $c_url = 'plugin.php?id=aljbzj&bid=';
        $this->page->assign('bzj_info', $bzj_info);
        $this->page->assign('c_url', $c_url);
        $this->page->assign('gobackstatus', $gobackstatus);
        $this->page->assign('th_bzj_info', $th_bzj_info);
        $this->page->assign('bzj_price', $bzj_price);
        $this->page->assign('bd', $bd);
        $this->page->assign('num', $num);
        $this->page->assign('bdlist', $bdlist);
        $this->page->assign('navtitle', lang("plugin/aljbzj","aljbzj_php_3"));
        $this->page->display();

    }
    /**
     * �ŵ걣֤�𸶿�
     *
     *
     * @return void
     */
    public function payStore () {
        if($this->page->get->bzj_price <= 0){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljbzj","aljbzj_php_4"))));
            exit;
        }
        if($this->page->get->store_id <= 0){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljbzj","aljbzj_php_5"))));
            exit;
        }
        $store = DB::fetch_first('select * from %t where tc_id=%d',array('aljtsq_store',$_GET['store_id']));
        if(!$store){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljbzj","aljbzj_php_6"))));
            exit;
        }
        $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
        $orderarray=array(
            'orderid' => $orderid,
            'status' => 1,
            'shop_id' => $store['bid'],
            'store_id' => $store['tc_id'],
            'order_type' => 6,//�ŵ걣֤��
            'uid' => $store['tc_uid'],
            'username' => $store['tc_username'],
            'submitdate' => TIMESTAMP,
            'stitle' => $this->page->global->username.lang("plugin/aljbzj","aljbzj_php_7").$store['tc_store_name'].lang("plugin/aljbzj","aljbzj_php_8").$this->page->get->bzj_price.lang("plugin/aljbzj","aljbzj_php_9"),
            'payment' => 7,
            'pid'  => 5,//��֤��
            'browser'  => $_SERVER['HTTP_USER_AGENT'],
        );

        $orderarray['mobile'] = 1;
        $orderarray['price'] = $this->page->get->bzj_price;
        C::t('#aljtsq#aljbd_goods_order')->insert($orderarray);
        require_once 'source/plugin/aljqb/class/Qbapi.class.php';
        $qbapi = new Qbapi();
        $keyurlarray = array(
            'orderid' => $orderid,
            'time' => TIMESTAMP,
            'price' => $this->page->get->bzj_price,
            'keyname' => 'aljbzj',
            'return_url' => rtrim($qbapi->siteurl, '/').'/plugin.php?id=aljbzj&c=aljbzj&a=storeBzj&store_id='.$this->page->get->store_id,
            'key' => $this->page->global->cache->plugin->aljbzj->qb_key,
        );
        $url = $qbapi->createUrl($keyurlarray);
        echo json_encode(T::ajaxPostCharSet(array('code'=>1,'url'=>$url,'text'=>lang("plugin/aljbzj","aljbzj_php_10"))));
        exit;
    }
    /**
     * ��֤�𸶿�
     *
     *
     * @return void
     */
    public function pay () {
        if($this->page->get->bzj_price <= 0){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljbzj","aljbzj_php_11"))));
            exit;
        }
        if($this->page->get->bid <= 0){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljbzj","aljbzj_php_12"))));
            exit;
        }
        $bd = C::t('#aljbd#aljbd')->fetch($this->page->get->bid);
        $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
        $orderarray=array(
            'orderid' => $orderid,
            'status' => 1,
            'shop_id' => $bd['id'],
            'uid' => $bd['uid'],
            'username' => $bd['username'],
            'submitdate' => TIMESTAMP,
            'stitle' => $this->page->global->username.lang("plugin/aljbzj","aljbzj_php_13").$bd['name'].lang("plugin/aljbzj","aljbzj_php_14").$this->page->get->bzj_price.lang("plugin/aljbzj","aljbzj_php_15"),
            'payment' => 7,
            'pid'  => 5,//��֤��
            'browser'  => $_SERVER['HTTP_USER_AGENT'],
        );

        $orderarray['mobile'] = 1;
        $orderarray['price'] = $this->page->get->bzj_price;
        C::t('#aljbdx#aljbd_goods_order')->insert($orderarray);
        require_once 'source/plugin/aljqb/class/Qbapi.class.php';
        $qbapi = new Qbapi();
        $keyurlarray = array(
            'orderid' => $orderid,
            'time' => TIMESTAMP,
            'price' => $this->page->get->bzj_price,
            'keyname' => 'aljbzj',
            'return_url' => rtrim($qbapi->siteurl, '/').'/plugin.php?id=aljbzj&bid='.$this->page->get->bid,
            'key' => $this->page->global->cache->plugin->aljbzj->qb_key,
        );
        $url = $qbapi->createUrl($keyurlarray);
        echo json_encode(T::ajaxPostCharSet(array('code'=>1,'url'=>$url,'text'=>lang("plugin/aljbzj","aljbzj_php_16"))));
        exit;
    }
    /**
     * ��֤���˻�
     *
     *
     * @return void
     */
    public function goBack (){
        global $admin_status,$_G;
        if($_GET['store'] == 'yes'){
            $bzj_info = DB::fetch_first('select * from %t where uid=%d and store_id=%d',array('aljbzj',$this->page->global->uid,$this->page->get->store_id));
            $store_url= '&store=yes';
        }else{
            $bzj_info = DB::fetch_first('select * from %t where uid=%d and bid=%d',array('aljbzj',$this->page->global->uid,$this->page->get->bid));
        }
        
        if($bzj_info['uid'] != $_G['uid']){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljbzj","aljbzj_php_17"))));
            exit;
        }
        if($bzj_info['price'] <=0){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljbzj","aljbzj_php_18"))));
            exit;
        }
        $insertarray = array(
            'uid' => $this->page->global->uid,
            'username' => $this->page->global->username,
            'bid' => $this->page->get->bid,
            'store_id' => $this->page->get->store_id,
            'price' => $bzj_info['price'],
            'addtime' => TIMESTAMP,
            'orderid' => dgmdate(TIMESTAMP, 'YmdHis').random(10),
            'status' => '2',//1 ���ɱ�֤�� 2 �˻ر�֤������ 3�˻سɹ� 4�˻�ʧ��
            'info' => lang("plugin/aljbzj","aljbzj_php_19")
        );
        //
        $inserid = C::t('#aljbzj#aljbzj_log')->insert($insertarray,true);
        $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
        foreach($groupids as $g_uid){
            notification_add($g_uid['uid'], 'system','����һ���µ��˻ر�֤�����룬�뾡�����<a href="plugin.php?id=aljbzj&a=bondLog&c=aljbzj&i=1'.$store_url.'">'.lang("plugin/aljbzj","aljbzj_php_20").'</a>',array('from_idtype'  => 'aljbzj','from_id' => $inserid));
        }
        echo json_encode(T::ajaxPostCharSet(array('code'=>1,'text'=>lang("plugin/aljbzj","aljbzj_php_21"))));
        exit;
    }
    /**
     * ��֤���˻�����б�
     *
     *
     * @return void
     */
    public function bondLog () {
        $do = $this->page->get->do;
        if($do == 'ajax'){
            $currpage = $this->page->get->page ? $this->page->get->page : 1;
            $perpage = 20;
            $start = ($currpage - 1) * $perpage;
            if($this->page->get->status == 99){
                
                $count = DB::result_first('select count(*) from %t where price > 0'.$where,array('aljbzj'));
                $teamList = DB::fetch_all('select * from %t where price > 0 order by id desc limit %d,%d',array('aljbzj',$start,$perpage));
            }else{
                if($this->page->global->groupid ==1 && $this->page->get->i == 1){
                    if(!$this->page->get->status || $this->page->get->status == 1){
                        $this->page->get->status = 2;
                    }
                    $where = 'where status='.$this->page->get->status;
                }else{
                    $where = 'where uid='.$this->page->global->uid;
                }
                $count = DB::result_first('select count(*) from %t '.$where,array('aljbzj_log'));
                $teamList = DB::fetch_all('select * from %t '.$where.' order by id desc limit %d,%d',array('aljbzj_log',$start,$perpage));
            }
            
            foreach ($teamList as $teamk => $teamv) {
                $teamList[$teamk]['userpic'] = avatar($teamv['uid'],'middle','true');
                $teamList[$teamk]['addtime'] = dgmdate($teamv['addtime'],'u');
                if($teamv['store_id'] > 0){
                    $teamList[$teamk]['bname'] = lang("plugin/aljbzj","aljbzj_php_22").DB::result_first('select tc_store_name from %t where tc_id=%d',array('aljtsq_store',$teamv['store_id']));
                    $teamList[$teamk]['bid'] = $teamv['store_id'];
                }else{
                    $teamList[$teamk]['bname'] = lang("plugin/aljbzj","aljbzj_php_23").DB::result_first('select name from %t where id=%d',array('aljbd',$teamv['bid']));
                }
                
                if($teamv['status'] == 3){
                    $teamList[$teamk]['statustext'] = lang("plugin/aljbzj","aljbzj_php_24");
                }else if($teamv['status'] == 4){
                    $teamList[$teamk]['statustext'] = lang("plugin/aljbzj","aljbzj_php_25");
                }else if($teamv['status'] == 2){
                    $teamList[$teamk]['statustext'] = lang("plugin/aljbzj","aljbzj_php_26");
                }else if($teamv['status'] == 1){
                    $teamList[$teamk]['statustext'] = lang("plugin/aljbzj","aljbzj_php_27");
                }
            }
            if($teamList){
                if($this->page->global->mobile){
                    echo json_encode(T::ajaxPostCharSet($teamList));
                }else{

                    T::responseJson(array(
                        'code' => 0,
                        'msg' => "",
                        'count' => $count,
                        'data' => $teamList
                    ));
                }

            }else{
                if($this->page->global->mobile) {
                    echo '1';
                }else{
                    T::responseJson(array(
                        'code' => 0,
                        'msg' => "",
                        'count' => 0,
                        'data' => array()
                    ));
                }
            }
            exit;
        }else {

            if($this->page->global->groupid == 1 && $this->page->get->i == 1){
                $navtitle = lang("plugin/aljbzj","aljbzj_php_28");
            }else{
                $navtitle = lang("plugin/aljbzj","aljbzj_php_29");
            }
            $this->page->assign('navtitle', $navtitle);
            $this->page->display();
        }
    }
    /**
     * ��֤���˻����
     * status =3 ���ͨ�� status=4��˲�ͨ��
     * @return void
     */
    public function bondStatus (){
        if($this->page->get->formhash == FORMHASH) {
            if($this->page->global->groupid !=1 && $this->page->get->i != 1){
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljbzj","aljbzj_php_30"))));
                exit;
            }
            if(!$this->page->get->cashid){
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljbzj","aljbzj_php_31"))));
                exit;
            }
            if(!$this->page->get->status){
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljbzj","aljbzj_php_32"))));
                exit;
            }
            $cashorder = DB::fetch_first('select * from %t where id=%d',array('aljbzj_log',$this->page->get->cashid));
            if(!$cashorder){
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljbzj","aljbzj_php_33"))));
                exit;
            }

            if(strtolower(CHARSET) == 'gbk' && !$this->page->global->mobile && $this->page->get->message){
                $this->page->get->message = diconv($this->page->get->message,'utf-8','gbk');
            }

            if(DB::query('update %t set status=%d,trans_uid=%d,trans_time=%d,info=%s where id=%d and status=2',array('aljbzj_log',$this->page->get->status,$this->page->global->uid,TIMESTAMP,$this->page->get->message,$this->page->get->cashid))){
                if($this->page->get->status == 3){
                    
                    if($cashorder['store_id'] > 0){
                        $n_text = lang("plugin/aljbzj","aljbzj_php_34");
                        $desc = lang("plugin/aljbzj","aljbzj_php_35").DB::result_first('select tc_store_name from %t where tc_id=%d',array('aljtsq_store',$cashorder['store_id'])).lang("plugin/aljbzj","aljbzj_php_36").$cashorder['price'].lang("plugin/aljbzj","aljbzj_php_37");
                    }else{
                        $n_text = lang("plugin/aljbzj","aljbzj_php_38");
                        $desc = lang("plugin/aljbzj","aljbzj_php_39").DB::result_first('select name from %t where id=%d',array('aljbd',$cashorder['bid'])).lang("plugin/aljbzj","aljbzj_php_40").$cashorder['price'].lang("plugin/aljbzj","aljbzj_php_41");
                    }
                    
                    $res = $this->aljqbChargeMoney ($cashorder['uid'],$cashorder['price'],$cashorder['orderid'],$desc);

                    if($res['code'] == 200){
                        DB::query('update %t set price=price-%i,updatetime=%d where uid=%d and bid=%d',array('aljbzj',$cashorder['price'],TIMESTAMP,$cashorder['uid'],$cashorder['bid']));
                    }
                }else{
                    if($cashorder['store_id'] > 0){
                        $n_text = lang("plugin/aljbzj","aljbzj_php_42");
                    }else{
                        $n_text = lang("plugin/aljbzj","aljbzj_php_43");
                    }
                    
                    if($this->page->get->message){
                        $n_text .= lang("plugin/aljbzj","aljbzj_php_44").$this->page->get->message;
                    }

                }
                notification_add($cashorder['uid'], 'system',$n_text.'<a href="plugin.php?id=aljbzj&a=bondLog&c=aljbzj">'.lang("plugin/aljbzj","aljbzj_php_45").'</a>',array('from_idtype'  => 'aljsfx','from_id' => $this->page->get->cashid));
                echo json_encode(T::ajaxPostCharSet(array('code'=>1,'text'=>lang("plugin/aljbzj","aljbzj_php_46"))));
                exit;
            }else{
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljbzj","aljbzj_php_47"))));
                exit;
            }
        }else{
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljbzj","aljbzj_php_48"))));
            exit;
        }
    }
    /**
     * ��֤������ɾ��
     *
     * @return void
     */
    public function bondDelete(){
        DB::delete('aljbzj_log', array('id' => $_GET['qid']));
        T::responseJson();
    }
    /**
     * Ǯ�������
     *
     * @param int $uid �û�id
     * @param int $price �۸�
     * @param string $orderid ������
     * @param string $desc �����Ǯ������
     *
     * @return array
     */
    public function aljqbChargeMoney ($uid=0,$price=0,$orderid='',$desc='') {
        require_once 'source/plugin/aljqb/class/Qbapi.class.php';
        $Qbapi = new Qbapi();
        $queuearray = array(
            'app_name' => 'aljbzj',
            'app_type' => 'aljbzj_txcancel',
            'app_phone' => '123456789',
            'app_ip' => $this->page->global->clientip,
        );
        $balancearray = array(
            'type' => 'charge',
            'uid' => $uid,
            'price' => $price,
            'orderid' => $orderid,
            'desc' => $desc,
        );
        $res = $Qbapi->balance($queuearray, $balancearray);
        return $res;
    }
    /**
     * Ʒ���̼ҹ�������ע��
     *
     *
     * @return void
     */
    public function aljbdParameter(){
        global $Html5Plusapp,
               $_G,
               $immersed,
               $pc_footer_new_top_arr,
               $pc_footer_new_top_tel,
               $pc_footer_new_top_kefu,
               $pc_footer_new_cron_c1_arr,
               $pc_footer_new_cron_c2_arr,
               $pc_footer_new_cron_c3_arr,
               $pc_footer_new_cron_c4_arr,
               $pc_footer_new_cron_c5_arr,
               $pc_footer_new_cron_qrcode_arr,
               $alltype,
               $index_dh_types,
               $ress;
        if($_G['cache']['plugin']['aljbd']){
            $settings=C::t('#aljbd#aljbd_setting')->range();
            $mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_common_footernav']['value']));
            foreach($mobile_common_footernav as $key=>$value){
                $arr=explode('|',$value);
                $mobile_common_footernav_arr[]=$arr;
            }
        }
        $price_unit = '&#65509;';
        $this->page->assign('price_unit', $price_unit,true);
        $this->page->assign('pluginid', 'aljbd');
        $this->page->assign('Html5Plusapp', $Html5Plusapp);
        $this->page->assign('immersed', $immersed);
        $this->page->assign('settings', $settings,true);
        $this->page->assign('mobile_common_footernav_arr', $mobile_common_footernav_arr,true);
        $this->page->assign('common_template_pluginid', 'aljbd');
        $this->page->assign('common_path', 'source/plugin/aljhtx');

        $this->page->assign('pc_footer_new_top_arr', $pc_footer_new_top_arr,true);
        $this->page->assign('pc_footer_new_top_tel', $pc_footer_new_top_tel,true);
        $this->page->assign('pc_footer_new_top_kefu', $pc_footer_new_top_kefu,true);
        $this->page->assign('pc_footer_new_cron_c1_arr', $pc_footer_new_cron_c1_arr,true);
        $this->page->assign('pc_footer_new_cron_c2_arr', $pc_footer_new_cron_c2_arr,true);
        $this->page->assign('pc_footer_new_cron_c3_arr', $pc_footer_new_cron_c3_arr,true);
        $this->page->assign('pc_footer_new_cron_c4_arr', $pc_footer_new_cron_c4_arr,true);
        $this->page->assign('pc_footer_new_cron_c5_arr', $pc_footer_new_cron_c5_arr,true);
        $this->page->assign('pc_footer_new_cron_qrcode_arr', $pc_footer_new_cron_qrcode_arr,true);
        $this->page->assign('alltype', $alltype,true);
        $this->page->assign('index_dh_types', $index_dh_types,true);
        $this->page->assign('ress', $ress,true);
    }
}

