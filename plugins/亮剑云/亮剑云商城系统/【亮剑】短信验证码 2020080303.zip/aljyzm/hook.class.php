<?php

/*
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ����֧��: http://dism.taobao.com
 * �ͷ�QQ: Dism.taobao.com
 */


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_aljyzm{
	function common(){
		global $_G;
		$config = $_G['cache']['plugin']['aljyzm'];
		if($config['istz'] == 1) {
			if($_G['uid']) {
				if($_SERVER['REQUEST_METHOD'] == 'GET') {
                    $mobilecolumn = $config['mobile'];
                    $checkphone = DB::result_first('select '.$mobilecolumn.' from %t where uid = %d',array('common_member_profile',$_G['uid']));
					if(empty($checkphone)) {
						if($_GET['id'] !== 'aljyzm:bind' && !$_G['inajax'] && $_GET['act'] != 'wechatsetting' && $_GET['mod'] != 'seccode'){
                            header("location:home.php?mod=spacecp&ac=plugin&id=aljyzm:bind");
						}	
					}
				}
			}
		}
		if($_GET['mod'] == 'logging' && $_GET['action'] == 'login' && $_GET['viewlostpw'] == 1 && $config['lostpw']){
			include template('aljyzm:viewlostpw');
		}
	}
	function global_usernav_extra1(){
		global $_G;
		$config = $_G['cache']['plugin']['aljyzm'];
		if($_G['uid'] && $config['olduser']){
            $mobilecolumn = $config['mobile'];
            $checkphone = DB::result_first('select '.$mobilecolumn.' from %t where uid = %d',array('common_member_profile',$_G['uid']));
			if(empty($checkphone)) {
				return '<span class="pipe">|</span><a href="plugin.php?id=aljyzm:advanced&act=bindphone" onclick="showWindow(\'bindphone\',this.href)">'.lang('plugin/aljyzm','y10').'</a>';
			}else{
				return '<span class="pipe">|</span><a href="plugin.php?id=aljyzm:advanced&act=bindphone" onclick="showWindow(\'bindphone\',this.href)">&#24050;&#32465;&#23450;&#25163;&#26426;&#21495;</a>';
			}
		}
	}
	function global_footer(){
		global $_G;
		
		$echo_js =  '';
		if($_G['uid'] && $_G['cache']['plugin']['aljyzm']['istz'] == 2 && empty($_G['cookie']['aljyzm_cookie_tip'])) {
			if($_SERVER['REQUEST_METHOD'] == 'GET') {
				$mobilecolumn = $_G['cache']['plugin']['aljyzm']['mobile'];
				$checkphone = DB::result_first('select '.$mobilecolumn.' from %t where uid = %d',array('common_member_profile',$_G['uid']));
				if(empty($checkphone)) {
					if($_GET['id'] !== 'aljyzm:bind' && !$_G['inajax'] && $_GET['act'] != 'wechatsetting' && $_GET['mod'] != 'seccode'){
						$echo_js .= "<script>showDialog('{$_G['cache']['plugin']['aljyzm']['istz_tips']}', 'confirm', '".lang('plugin/aljyzm','y13')."', 'document.location.href = \'home.php?mod=spacecp&ac=plugin&id=aljyzm:bind\';aljyzm_cookie_js();', 1, 'aljyzm_cookie_js()', '', '".lang('plugin/aljyzm','y14')."', '".lang('plugin/aljyzm','y15')."');
function aljyzm_cookie_js(){
	setcookie('aljyzm_cookie_tip', 1, ".intval($_G['cache']['plugin']['aljyzm']['istz_time']).");
}
</script>";
					}	
				}
			}
		}
		if(($_G['cache']['plugin']['aljyzm']['lostpw'] || $_G['cache']['plugin']['aljyzm']['olduser']) && !$_G['cache']['plugin']['aljyzm']['is_jquery']){
			$echo_js .= '<script src="source/plugin/aljyzm/js/jquery.min.js"></script><script>var jQuery = jQuery.noConflict();</script>';
		}
		if($_G[cache][plugin][aljyzm][is_dz_seccode]){
			$echo_js .= '<script src="source/plugin/aljhtx/static/js/layer/layer.js" type="text/javascript" charset="utf-8"></script><link rel="stylesheet" href="source/plugin/aljhtx/static/js/layer/skin/default/layer.css">';
		}
		return $echo_js;
	}
}
class plugin_aljyzm_member extends plugin_aljyzm{
	function logging_member(){
		global $_G;
		$config = $_G['cache']['plugin']['aljyzm'];
		$mobilecolumn = $config['mobile'];
		if(ismobile_liangjian($_GET['username'])){
			$uid = DB::result_first('select uid from %t where '.$mobilecolumn.' = %s',array('common_member_profile',$_GET['username']));
			$user = getuserbyuid($uid);
			$result = mapp_userlogin_aljyzm($user['username'], $_GET['password'],$_GET['questionid'],$_GET['answer']);
			if ($result['status']) {
				if($user){
					require_once libfile('function/member');
					setloginstatus($user, 2592000);
				}
			}
		}
	}
	function register_post(){
		global $_G;
		$config = $_G['cache']['plugin']['aljyzm'];
		if(!$config['isreg']){
			return;
		}
		$mobilecolumn = $config['mobile'];
		if(submitcheck('formhash')){
			$phone = addslashes($_GET['lmobile']);
			if(!ismobile_liangjian($phone)){
				showmessage(lang('plugin/aljyzm','nocorrect'));
			}
			$checkcode = DB::result_first('select code from %t where phone = %s and status=1 and sendtime+36000>%d order by sendtime desc',array('aljyzm_mcode',$_GET['lmobile'],TIMESTAMP));
			
			if(empty($_GET['lmobilecheck']) || $_GET['lmobilecheck'] != $checkcode){
				showmessage(lang('plugin/aljyzm','codenocorrect'));
				//showmessage($checkcode);
			}
			$checkphone = DB::result_first('select count(*) from %t where '.$mobilecolumn.' = %s',array('common_member_profile',$phone));
			if($checkphone){
				showmessage(lang('plugin/aljyzm','numnocorrect'));
			}
		}
	}
	function register_post_message($param){
		global $_G;
		$config = $_G['cache']['plugin']['aljyzm'];
		$mobilecolumn = $config['mobile'];
		if ($param ['param'] [0] == "register_succeed") {
			$mobile = addslashes($_GET['lmobile']);
			if(!DB::result_first('select count(*) from %t where uid=%d',array('aljyzm_user',$param ['param'][2]['uid']))){
				DB::insert('aljyzm_user',array(
					'uid' => $param ['param'][2]['uid'],	
					'username' => $param ['param'][2]['username'],	
					'phone' => $mobile,	
					'dateline' => TIMESTAMP,	
				));
			}else{
				DB::query('update %t set phone = %s where uid=%d',array('aljyzm_user',$mobile,$param ['param'][2]['uid']));
			}
			
			DB::query('update %t set '.$mobilecolumn.' = %s where uid=%d',array('common_member_profile',$mobile,$param ['param'][2]['uid']));
			DB::query('update %t set uid = %d where phone=%s',array('aljyzm_mcode',$param ['param'][2]['uid'],$mobile));
		}
	}
	function connect_input_output() {
		global $_G;
		$config = $_G['cache']['plugin']['aljyzm'];
		if($config['isreg']){
			include template('aljyzm:register');
		}
		$_G['setting']['pluginhooks']['register_input'] .= $return;
		
	}
	function connect_post_message($param){
		global $_G;
		$config = $_G['cache']['plugin']['aljyzm'];
		$mobilecolumn = $config['mobile'];
		if ($param ['param'] [0] == "register_succeed") {
			$mobile = addslashes($_GET['lmobile']);
			if(!DB::result_first('select count(*) from %t where uid=%d',array('aljyzm_user',$param ['param'][2]['uid']))){
				DB::insert('aljyzm_user',array(
					'uid' => $param ['param'][2]['uid'],	
					'username' => $param ['param'][2]['username'],	
					'phone' => $mobile,	
					'dateline' => TIMESTAMP,	
				));
			}else{
				DB::query('update %t set phone = %s where uid=%d',array('aljyzm_user',$mobile,$param ['param'][2]['uid']));
			}
			
			DB::query('update %t set '.$mobilecolumn.' = %s where uid=%d',array('common_member_profile',$mobile,$param ['param'][2]['uid']));
			DB::query('update %t set uid = %d where phone=%s',array('aljyzm_mcode',$param ['param'][2]['uid'],$mobile));
		}
	}
	function connect_post() {
		global $_G;
		$config = $_G['cache']['plugin']['aljyzm'];
		if(!$config['isreg']){
			return;
		}
		$mobilecolumn = $config['mobile'];
		if(submitcheck('formhash')){
			$phone = addslashes($_GET['lmobile']);
			if(!ismobile_liangjian($phone)){
				showmessage(lang('plugin/aljyzm','nocorrect'));
			}
			$checkcode = DB::result_first('select code from %t where phone = %s and status=1 and sendtime+36000>%d order by sendtime desc',array('aljyzm_mcode',$_GET['lmobile'],TIMESTAMP));
			
			if(empty($_GET['lmobilecheck']) || $_GET['lmobilecheck'] != $checkcode){
				showmessage(lang('plugin/aljyzm','codenocorrect'));
				//showmessage($checkcode);
			}
			$checkphone = DB::result_first('select count(*) from %t where '.$mobilecolumn.' = %s',array('common_member_profile',$phone));
			if($checkphone){
				showmessage(lang('plugin/aljyzm','numnocorrect'));
			}
		}

	}
	function register_input_output(){
		global $_G;
		$config = $_G['cache']['plugin']['aljyzm'];
		if($config['isreg']){
			include template('aljyzm:register');
			return $return;
		}
		
	}
}

class mobileplugin_aljyzm{
	function common(){
		global $_G;
		$config = $_G['cache']['plugin']['aljyzm'];
        $_G['connect']['referer'] = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'].($_SERVER['QUERY_STRING'] ? '?'.$_SERVER['QUERY_STRING'] : '') : dreferer();
        $_G['connect']['referer'] = urlencode($_G['connect']['referer'] ? $_G['connect']['referer'] : 'index.php');
		if($config['istz'] == 1) {
			if($_G['uid'] && $_GET['mod'] != 'logging') {
				if($_SERVER['REQUEST_METHOD'] == 'GET') {
                    $mobilecolumn = $config['mobile'];
                    $checkphone = DB::result_first('select '.$mobilecolumn.' from %t where uid = %d',array('common_member_profile',$_G['uid']));
					if(!$checkphone) {
						if($_GET['act'] !== 'mbindphone' && $_GET['mod'] != 'seccode'){
							header("location:plugin.php?id=aljyzm:advanced&act=mbindphone&referer=".$_G['connect']['referer']);
						}	
					}
				}
			}
		}
	}
	function global_footer_mobile(){
		global $_G;
		$config = $_G['cache']['plugin']['aljyzm'];
		if($_GET['mod'] == 'register' && $config['isreg']){
			include template('aljyzm:register');
			return $return;
		}else if($_G['cache']['plugin']['aljyzm']['istz'] == 2 && $_G['uid'] && $_GET['mod'] != 'logging' && $_SERVER['REQUEST_METHOD'] == 'GET' && empty($_G['cookie']['aljyzm_cookie_tip_m'])){
			$mobilecolumn = $_G['cache']['plugin']['aljyzm']['mobile'];
			$checkphone = DB::result_first('select '.$mobilecolumn.' from %t where uid = %d',array('common_member_profile',$_G['uid']));
			if(!$checkphone) {
				if($_GET['act'] !== 'mbindphone' && $_GET['mod'] != 'seccode'){
					include_once template('aljyzm:touch/aljyzm_tips');
					return $data;
				}	
			}
			
		}
	}
}
class mobileplugin_aljyzm_member extends mobileplugin_aljyzm{
	function logging_member(){
		global $_G;
		$config = $_G['cache']['plugin']['aljyzm'];
		$mobilecolumn = $config['mobile'];
		if(ismobile_liangjian($_GET['username'])){
			$uid = DB::result_first('select uid from %t where '.$mobilecolumn.' = %s',array('common_member_profile',$_GET['username']));
			$user = getuserbyuid($uid);
			$result = mapp_userlogin_aljyzm($user['username'], $_GET['password'],$_GET['questionid'],$_GET['answer']);
			if ($result['status']) {
				if($user){
					require_once libfile('function/member');
					setloginstatus($user, 2592000);
				}
			}
		}
	}
	function connect_post_message($param){
		global $_G;
		$config = $_G['cache']['plugin']['aljyzm'];
		$mobilecolumn = $config['mobile'];
		if ($param ['param'] [0] == "register_succeed") {
			$mobile = addslashes($_GET['lmobile']);
			if(!DB::result_first('select count(*) from %t where uid=%d',array('aljyzm_user',$param ['param'][2]['uid']))){
				DB::insert('aljyzm_user',array(
					'uid' => $param ['param'][2]['uid'],	
					'username' => $param ['param'][2]['username'],	
					'phone' => $mobile,	
					'dateline' => TIMESTAMP,	
				));
			}else{
				DB::query('update %t set phone = %s where uid=%d',array('aljyzm_user',$mobile,$param ['param'][2]['uid']));
			}
			
			DB::query('update %t set '.$mobilecolumn.' = %s where uid=%d',array('common_member_profile',$mobile,$param ['param'][2]['uid']));
			DB::query('update %t set uid = %d where phone=%s',array('aljyzm_mcode',$param ['param'][2]['uid'],$mobile));
		}
	}
	function register_post(){
		global $_G;
		$config = $_G['cache']['plugin']['aljyzm'];
		if(!$config['isreg']){
			return;
		}
		$mobilecolumn = $config['mobile'];
		if(submitcheck('formhash')){
			$phone = addslashes($_GET['lmobile']);
			if(!ismobile_liangjian($phone)){
				showmessage(lang('plugin/aljyzm','nocorrect'));
			}
			$checkcode = DB::result_first('select code from %t where phone = %s and status=1 and sendtime+36000>%d order by sendtime desc',array('aljyzm_mcode',$_GET['lmobile'],TIMESTAMP));
			
			if(empty($_GET['lmobilecheck']) || $_GET['lmobilecheck'] != $checkcode){
				showmessage(lang('plugin/aljyzm','codenocorrect'));
				//showmessage($checkcode);
			}
			$checkphone = DB::result_first('select count(*) from %t where '.$mobilecolumn.' = %s',array('common_member_profile',$phone));
			if($checkphone){
				showmessage(lang('plugin/aljyzm','numnocorrect'));
			}
		}
	}
	function connect_input_output() {
		global $_G;
		$config = $_G['cache']['plugin']['aljyzm'];
		if($config['isreg']){
			include template('aljyzm:register');
		}
		$_G['setting']['pluginhooks']['register_input'] .= $return;
		
	}
	function register_post_message($param){
		global $_G;
		$config = $_G['cache']['plugin']['aljyzm'];
		$mobilecolumn = $config['mobile'];
		if ($param ['param'] [0] == "register_succeed") {
			$mobile = addslashes($_GET['lmobile']);
			if(DB::result_first('select count(*) from %t where uid=%d',array('aljyzm_user',$param ['param'][2]['uid']))){
				DB::insert('aljyzm_user',array(
					'uid' => $param ['param'][2]['uid'],	
					'username' => $param ['param'][2]['username'],	
					'phone' => $mobile,	
					'dateline' => TIMESTAMP,	
				));
			}else{
				DB::query('update %t set phone = %s where uid=%d',array('aljyzm_user',$mobile,$param ['param'][2]['uid']));
			}
			DB::query('update %t set '.$mobilecolumn.' = %s where uid=%d',array('common_member_profile',$mobile,$param ['param'][2]['uid']));
			DB::query('update %t set uid = %d where phone=%s',array('aljyzm_mcode',$param ['param'][2]['uid'],$mobile));
		}
	}
}

function ismobile_liangjian($mobile) {
    global $_G;
    if (!is_numeric($mobile)) {
        return false;
    }
    return preg_match($_G['cache']['plugin']['aljyzm']['regular'], $mobile) ? true : false;
}
function mapp_userlogin_aljyzm($username, $password='', $questionid='', $answer='', $loginfield = 'username', $ip = '') {
	$return = array();

	if($loginfield == 'uid' && getglobal('setting/uidlogin')) {
		$isuid = 1;
	} elseif($loginfield == 'email') {
		$isuid = 2;
	} elseif($loginfield == 'auto') {
		$isuid = 3;
	} else {
		$isuid = 0;
	}

	if(!function_exists('uc_user_login')) {
		loaducenter();
	}
	if($isuid == 3) {
		if(!strcmp(dintval($username), $username) && getglobal('setting/uidlogin')) {
			$return['ucresult'] = uc_user_login($username, $password, 1, 0, $questionid, $answer, $ip);
		} elseif(isemail($username)) {
			$return['ucresult'] = uc_user_login($username, $password, 2, 0, $questionid, $answer, $ip);
		}
		if($return['ucresult'][0] <= 0 && $return['ucresult'][0] != -3) {
			$return['ucresult'] = uc_user_login(addslashes($username), $password, 0, 0, $questionid, $answer, $ip);
		}
	} else {
		$return['ucresult'] = uc_user_login(addslashes($username), $password, $isuid, 0, $questionid, $answer, $ip);
	}
	$tmp = array();
	$duplicate = '';
	list($tmp['uid'], $tmp['username'], $tmp['password'], $tmp['email'], $duplicate) = $return['ucresult'];
	$return['ucresult'] = $tmp;
	if($duplicate && $return['ucresult']['uid'] > 0 || $return['ucresult']['uid'] <= 0) {
		$return['status'] = 0;
		return $return;
	}

	$member = getuserbyuid($return['ucresult']['uid'], 1);
	if(!$member || empty($member['uid'])) {
		$return['status'] = -1;
		return $return;
	}
	$return['member'] = $member;
	$return['status'] = 1;
	if($member['_inarchive']) {
		C::t('common_member_archive')->move_to_master($member['uid']);
	}
	if($member['email'] != $return['ucresult']['email']) {
		C::t('common_member')->update($return['ucresult']['uid'], array('email' => $return['ucresult']['email']));
	}

	return $return;
}
//From: Dism��taobao��com
?>