<?php

/*
 * Copyright (c) 2020 by dism.taobao.com
 * εQQ:dism.Taobao.Com
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljyzm_mcode extends discuz_table {

    public function __construct() {

        $this->_table = 'aljyzm_mcode';
        $this->_pk = 'id';

        parent::__construct();
    }
}
//From: Dism_taobao_com
?>