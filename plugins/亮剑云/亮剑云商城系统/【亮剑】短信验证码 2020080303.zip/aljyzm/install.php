<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljyzm_mcode` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `phone` bigint(20) NOT NULL,
  `code` varchar(10) NOT NULL,
  `sendtime` int(10) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `result` varchar(250) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljyzm_user` (
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `dateline` int(10) NOT NULL,
  PRIMARY KEY (`uid`)
);
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>