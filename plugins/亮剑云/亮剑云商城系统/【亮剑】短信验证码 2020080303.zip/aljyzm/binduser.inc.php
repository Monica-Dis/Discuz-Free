<?php

/*
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ����֧��: http://dism.taobao.com
 * ��ϵQQ: dism.Taobao.Com
 * ����˵��:MAPP΢�ź��ӷ�����־
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
$mobilecolumn = $_G['cache']['plugin']['aljyzm']['mobile'];
$act = htmlspecialchars($_GET['act']);
if($act == 'delete'){
	if(is_array($_POST['delete'])) {
		foreach($_POST['delete'] as $id) {
            DB::delete('aljyzm_user', array(
                'uid' => $id,
            ));
            DB::query('update %t set '.$mobilecolumn.' = %s where uid=%d',array('common_member_profile','',$id));
		}
	}
	cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljyzm&pmod=binduser');
}else{
	$currpage = $_GET['page'] ? intval($_GET['page']) : 1;
	$perpage = 30;

	$start = ($currpage - 1) * $perpage;

    $where = ' where 1 ';
    $conn = array('aljyzm_user');
    $search = $_GET['search'];
    if($search){
        $str = '%'.$search.'%';
        $where .= ' and (username like %s or phone like %s)';
        $conn[] = $str;
        $conn[] = $str;
    }
    $num = DB::result_first('select count(*) from %t '.$where, $conn);;
    $where .= ' order by dateline desc limit %d, %d';
    $conn[] = $start;
    $conn[] = $perpage;
    $loglist = DB::fetch_all('select * from %t '.$where, $conn);
	$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljyzm&pmod=binduser', 0, 11, false, false);
	include template('aljyzm:binduser');
}
//From: Dism��taobao��com
?>