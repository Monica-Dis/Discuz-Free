<?php

/*
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ����֧��: http://dism.taobao.com
 * �ͷ�QQ: Dism.taobao.com
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_GET['act'] == 'seccode'){
	if(empty($_GET['seccodeverify']) || empty($_GET['seccodehash'])){
		echo json_encode(array('code' => -1,'data' => 'paramerror'));
		exit;
	}
	if($_G['setting']['seccodedata']['type'] == '1' && strtolower(CHARSET) == 'gbk'){
		$_GET['seccodeverify'] = diconv($_GET['seccodeverify'], 'UTF-8', 'GBK');
	}
	if (!check_seccode($_GET['seccodeverify'], $_GET['seccodehash'])) {
		echo json_encode(array('code' => -1,'data' => 'seccode_invalid'));
		exit;
	}
	echo json_encode(array('code' => 1,'data' => 'ok'));
	exit;
}else if($_GET['act'] == 'seccodehtml'){
	$seccodecheck = 1;
	$sectpl = '<div><sec>:<sec></div><p class="d"><sec></p>';
	$html = '<div class="item item-captcha">
	<div class="input-info">';
	include template('subtemplate:common/seccheck');
	$html .= '</div>
	</div>';
	echo $html;
	exit;
}
$config = $_G['cache']['plugin']['aljyzm'];
$phone = addslashes($_GET['phone']);
if(!ismobile($phone)){
	echo 1;
	exit;
}
if($_GET['formhash'] != formhash()){
	echo 0;
	exit;
}
$check = DB::result_first('select count(*) from %t where phone = %s and sendtime+'.$config['time'].'>%d and status=1 order by sendtime desc',array('aljyzm_mcode',$phone,TIMESTAMP));
$checkip = DB::result_first('select count(*) from %t where ip = %s and sendtime+'.$config['time'].'>%d and status=1 order by sendtime desc',array('aljyzm_mcode',$_G['clientip'],TIMESTAMP));
if($check > $config['times'] || $_GET['formhash'] != FORMHASH || $checkip > $config['iptimes']){
	echo 2;
    exit;
}
if($_GET['from'] != 'viewlostpw' && $_GET['from'] != 'mobilelogin') {
    $checkphone = DB::result_first('select count(*) from %t where ' . $config['mobile'] . ' = %s', array('common_member_profile', $phone));
    if ($checkphone) {
        echo 4;
        exit;
    }
}
$code  = rand(1000,9999);
if($_GET['from'] == 'viewlostpw'){
	$config['sms_param'] = $config['sms_param2'];
	$config['sms_template_code'] = $config['sms_template_code2'];
}else if($_GET['from'] == 'mobilelogin'){
	$config['sms_param'] = $config['sms_param4'];
	$config['sms_template_code'] = $config['sms_template_code4'];
}else if($_GET['from'] == 'bindphone' && $config['sms_param3'] && $config['sms_template_code3']){
    $config['sms_param'] = $config['sms_param3'];
    $config['sms_template_code'] = $config['sms_template_code3'];
}
$config['sms_param'] = str_replace("\r\n", "\n", $config['sms_param']);
$config['sms_param'] = explode("\n", $config['sms_param']);
foreach($config['sms_param'] as $tmp){
	$tmp = explode("|", $tmp);
	if($tmp[0] == 'code'){
		$sms_param['code'] = $code;
	}else{
		$sms_param[$tmp[0]] = $tmp[1];
	}
}
$sms_param = encode_json($sms_param);
if(strtolower(CHARSET) == 'gbk'){
	$sms_param = diconv($sms_param,CHARSET,'utf-8');
}

if($config['isaliyun']){
	$params = array (   //�˴������޸�
            'SignName' => diconv($config['sms_free_sign_name'], CHARSET, 'utf-8'),
            'Format' => 'JSON',
            'Version' => '2017-05-25',
            'AccessKeyId' => $config['app_key'],
            'SignatureVersion' => '1.0',
            'SignatureMethod' => 'HMAC-SHA1',
            'SignatureNonce' => uniqid (),
            'Timestamp' => gmdate ( 'Y-m-d\TH:i:s\Z' ),
            'Action' => 'SendSms',
            'TemplateCode' => $config['sms_template_code'],
            'PhoneNumbers' => $phone,
            'TemplateParam' => $sms_param
    );
	$params ['Signature'] = computeSignature ( $params, $config['app_secret']);
	$url = 'http://dysmsapi.aliyuncs.com/?' . http_build_query ( $params );
    $return = dfsockopen($url);
}else{
	$params = array(
		'sms_type' => 'normal',
		'sms_free_sign_name' => $config['sms_free_sign_name'],
		'sms_param' => $sms_param,
		'rec_num' => $phone,
		'sms_template_code' => $config['sms_template_code'],
		'app_key' => $config['app_key'],
		//'app_key' => '233024',
	);
	if(strtolower(CHARSET) == 'gbk'){
		$params['sms_free_sign_name'] = diconv($params['sms_free_sign_name'],CHARSET,'utf-8');
	}
	$return  = lsendsms($params,$config['app_secret']);
}

$returnarray = json_decode($return,true);
$status = $returnarray['alibaba_aliqin_fc_sms_num_send_response']['result']['success'];

if($status || $returnarray['Code'] == 'OK'){
	$status=1;
}else{
	$status=0;
}

if(strtolower(CHARSET) == 'gbk'){
	$return = diconv($return, 'utf-8', 'gbk');
}

$insertid = DB::insert('aljyzm_mcode',array(
	'code' => $code,
	'phone' => $phone,
	'sendtime' => TIMESTAMP,
	'ip' => $_G['clientip'],
	'uid' => $_G['uid'],
	'status' => $status,
	'result' => $return,
),true);
if($status){
	echo 3;
	exit;
}
function percentEncode($string) {
    $string = urlencode ( $string );
    $string = preg_replace ( '/\+/', '%20', $string );
    $string = preg_replace ( '/\*/', '%2A', $string );
    $string = preg_replace ( '/%7E/', '~', $string );
    return $string;
}
function computeSignature($parameters, $accessKeySecret='') {
	ksort ( $parameters );
	$canonicalizedQueryString = '';
	foreach ( $parameters as $key => $value ) {
	   $canonicalizedQueryString .= '&' . percentEncode ( $key ) . '=' . percentEncode ( $value );
	}
	$stringToSign = 'GET&%2F&' . percentencode ( substr ( $canonicalizedQueryString, 1 ) );
	$signature = base64_encode ( hash_hmac ( 'sha1', $stringToSign, $accessKeySecret . '&', true ) );
	return $signature;
}
function lsendsms($params,$app_secret=''){
	$url = 'http://gw.api.taobao.com/router/rest?';
	$sysparams = array(
		'partner_id' => 'top-apitools',
		'v' => '2.0',
		'sign_method' => 'md5',
		'timestamp' => dgmdate(TIMESTAMP,"Y-m-d H:i:s"),
		'method' => 'alibaba.aliqin.fc.sms.num.send',
		'format' => 'json',
	);
	$newparams = array_merge($params, $sysparams);

	//����ǩ��
	ksort($newparams);
	$stringToBeSigned = $app_secret;
	foreach ($newparams as $k => $v)
	{
		if(is_string($v) && "@" != substr($v, 0, 1))
		{
			$stringToBeSigned .= "$k$v";
		}
	}
	unset($k, $v);
	$stringToBeSigned .= $app_secret;
	//����ǩ��
	$newparams['sign'] = strtoupper(md5($stringToBeSigned));
	return dfsockopen($url,'',$newparams);
	//return '{"alibaba_aliqin_fc_sms_num_send_response":{"result":{"err_code":"0","model":"100943730624^1101398835889","success":true},"request_id":"iv0eh4eqg17c"}}';
}



function ismobile($mobile) {
	global $_G;
    if (!is_numeric($mobile)) {
        return false;
    }
    return preg_match($_G['cache']['plugin']['aljyzm']['regular'], $mobile) ? true : false;
}


function encode_json($str) {
	return urldecode(json_encode(url_encode($str)));
}


function url_encode($str) {
	if(is_array($str)) {
		foreach($str as $key=>$value) {
			$str[urlencode($key)] = url_encode($value);
		}
	} else {
		$str = urlencode($str);
	}

	return $str;
}
//From: Dism_taobao_com
?>
