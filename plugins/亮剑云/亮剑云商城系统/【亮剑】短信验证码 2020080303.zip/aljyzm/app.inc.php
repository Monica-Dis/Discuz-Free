<?php

/*
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ����֧��: http://dism.taobao.com
 * �ͷ�QQ: Dism.taobao.com
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

echo "<script language='javascript'>";
echo "window.location.href='http://addon.discuz.com/?@liangjian'";
echo "</script>";
exit;
?>