<?php

/*
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ����֧��: http://dism.taobao.com
 * �ͷ�QQ: Dism.taobao.com
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_GET['inajax'] !=1 ){
	define('IN_MOBILE', 2);
	$_G['mobile'] = 2;
}
if($_GET[referer]){
    dsetcookie('referer_yzm', $_GET[referer],'60');
}else{
    //debug($_SERVER['HTTP_REFERER']);
    if (empty($_GET['code']) && !$_G['mobile']) {
        dsetcookie('referer_yzm', $_SERVER['HTTP_REFERER'],'60');
    }
}
$referer = $_G['cookie']['referer_yzm'] ? strip_tags($_G['cookie']['referer_yzm']) : $_G['setting']['siteurl'];
$config = $_G['cache']['plugin']['aljyzm'];
$act = addslashes($_GET['act']);
if($act == 'mbindphone') {
	$mobilecolumn = $config['mobile'];
	if($_G['uid']){
		$phone = DB::result_first('select '.$mobilecolumn.' from %t where uid = %d',array('common_member_profile',$_G['uid']));
	}
	include template('aljyzm:mbindphone');
}else if($act == 'changepwd'){
	if(submitcheck('formhash')){
		$mobile = addslashes($_GET['lmobile']);
		$mobilecolumn = $config['mobile'];
		if(!checkmobilenumber($mobile)){
			echo '<script>parent.showError("'.lang('plugin/aljyzm', 'nocorrect').'");</script>';
			exit;
		}
		$checkcode = DB::result_first('select code from %t where phone = %s and status=1 and sendtime+'.$config['time'].'>%d order by sendtime desc',array('aljyzm_mcode',$mobile,TIMESTAMP));
		
		if(empty($_GET['lmobilecheck']) || $_GET['lmobilecheck'] != $checkcode){
			echo '<script>parent.showError("'.lang('plugin/aljyzm', 'codenocorrect').'");</script>';
			exit;
		}


		$password = addslashes($_GET['password']);
		$confirmpassword = addslashes($_GET['confirmpassword']);
		if($_G['setting']['pwlength']) {
			if(strlen($_GET['password']) < $_G['setting']['pwlength']) {
				echo '<script>parent.showError("'.lang('plugin/aljyzm', 'y1').$_G['setting']['pwlength'].lang('plugin/aljyzm', 'y2').'");</script>';
				exit;
			}
		}
		if($password != $confirmpassword){
			echo '<script>parent.showError("'.lang('plugin/aljyzm', 'y3').'");</script>';
			exit;
		}
		if($_G['setting']['strongpw']) {
			$strongpw_str = array();
			if(in_array(1, $_G['setting']['strongpw']) && !preg_match("/\d+/", $password)) {
				$strongpw_str[] = lang('member/template', 'strongpw_1');
			}
			if(in_array(2, $_G['setting']['strongpw']) && !preg_match("/[a-z]+/", $password)) {
				$strongpw_str[] = lang('member/template', 'strongpw_2');
			}
			if(in_array(3, $_G['setting']['strongpw']) && !preg_match("/[A-Z]+/", $password)) {
				$strongpw_str[] = lang('member/template', 'strongpw_3');
			}
			if(in_array(4, $_G['setting']['strongpw']) && !preg_match("/[^a-zA-z0-9]+/", $password)) {
				$strongpw_str[] = lang('member/template', 'strongpw_4');
			}
			if($strongpw_str) {
				echo '<script>parent.showError("'.lang('member/template', 'password_weak').implode(',', $strongpw_str).'");</script>';
				exit;
			}
		}
		if(checkmobilenumber($mobile)){
			$uid = DB::result_first('select uid from %t where '.$mobilecolumn.' = %s',array('common_member_profile',$mobile));
			if($uid){
				$user = getuserbyuid($uid);
				loaducenter();
				uc_user_edit($user['username'],'',$password,'',1,0,'');
				notification_add($uid, 'system',lang('plugin/aljyzm', 'y6').$user['username'].lang('plugin/aljyzm', 'y7'));
				echo '<script>parent.showDialog("'.lang('plugin/aljyzm', 'y5').'","right","",function(){parent.location.href=parent.location.href;});</script>';
				exit;
			}else{
				echo '<script>parent.showError("'.lang('plugin/aljyzm', 'y4').'");</script>';
				exit;
			}
		}else{
			echo '<script>parent.showError("'.lang('plugin/aljyzm','nocorrect').'");</script>';
			exit;
		}
		
	}
	
}else if($act == 'bindphone'){
	$mobile = addslashes($_GET['lmobile']);
	$mobilecolumn = $config['mobile'];
	if(submitcheck('formhash')){
		if(empty($_G['uid'])){
			echo '<script>parent.showError("'.lang('plugin/aljyzm', 'y11').'");</script>';
			exit;
		}
		if(!checkmobilenumber($mobile)){
			echo '<script>parent.showError("'.lang('plugin/aljyzm', 'nocorrect').'");</script>';
			exit;
		}
		$checkphone = DB::result_first('select count(*) from %t where '.$mobilecolumn.' = %s',array('common_member_profile',$mobile));
		if($checkphone){
			echo '<script>parent.showError("'.lang('plugin/aljyzm','numnocorrect').'");</script>';
			exit;
		}
		$checkcode = DB::result_first('select code from %t where phone = %s and status=1 and sendtime+'.$config['time'].'>%d order by sendtime desc',array('aljyzm_mcode',$mobile,TIMESTAMP));
		
		if(empty($_GET['lmobilecheck']) || $_GET['lmobilecheck'] != $checkcode){
			echo '<script>parent.showError("'.lang('plugin/aljyzm', 'codenocorrect').'");</script>';
			exit;
		}
		if(!DB::result_first('select count(*) from %t where uid=%d',array('aljyzm_user',$_G['uid']))){
			DB::insert('aljyzm_user',array(
				'uid' => $_G['uid'],	
				'username' => $_G['username'],	
				'phone' => $mobile,	
				'dateline' => TIMESTAMP,	
			));
		}else{
			DB::query('update %t set phone = %s where uid=%d',array('aljyzm_user',$mobile,$_G['uid']));
		}
		DB::query('update %t set '.$mobilecolumn.' = %s where uid=%d',array('common_member_profile',$mobile,$_G['uid']));
		notification_add($_G['uid'], 'system',lang('plugin/aljyzm', 'y9').$mobile);
        if($_G['mobile']){
            echo '<script>parent.showDialog("'.lang('plugin/aljyzm', 'y8').'", \''.$referer.'\');</script>';
            exit;
        }else{
            echo '<script>parent.showDialog("'.lang('plugin/aljyzm', 'y8').'","right","",function(){parent.location.href=\''.$referer.'\';});</script>';
            exit;
        }
	}else{
		if($_G['uid']){
			$phone = DB::result_first('select '.$mobilecolumn.' from %t where uid = %d',array('common_member_profile',$_G['uid']));
		}else{
			showmessage(lang('plugin/aljyzm', 'y11'));
		}
		include template('aljyzm:bindphone');
	}
}



function checkmobilenumber($mobile) {
	global $_G;
    if (!is_numeric($mobile)) {
        return false;
    }
    return preg_match($_G['cache']['plugin']['aljyzm']['regular'], $mobile) ? true : false;
}
//From: Dism��taobao��com
?>

