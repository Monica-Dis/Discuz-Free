<?php

/*
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ����֧��: http://dism.taobao.com
 * �ͷ�QQ: Dism.taobao.com
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$config = $_G['cache']['plugin']['aljyzm'];
$mobilecolumn = $config['mobile'];
if($_G['uid']){
	$phone = DB::result_first('select '.$mobilecolumn.' from %t where uid = %d',array('common_member_profile',$_G['uid']));
}else{
	showmessage(lang('plugin/aljyzm', 'y11'));
}
//From: Dism��taobao��com
?>