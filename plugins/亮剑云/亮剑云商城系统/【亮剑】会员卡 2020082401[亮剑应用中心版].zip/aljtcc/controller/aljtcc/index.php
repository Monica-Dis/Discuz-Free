<?php

/**
 * �������̳�
 *
 * @author <dism.taobao.com>
 * @version 2019080501
 * @link https://dism.taobao.com/
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class IndexAction{
    public function __construct($page) {
        $this->page = $page;
    }

    /**
     * ��Ա��
     *
     *
     * @return void
     */
    public function index () {
        global $_G;
        $dateline = TIMESTAMP;
        $card_id = intval($_GET['card_id']);
        $user = DB::fetch_first('select * from %t where uid=%d and card_id=%d', array('aljtcc_card_user', $_G['uid'], $card_id));
        if(submitcheck('formhash')){
            $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
            if($_GET['type'] == 1){
                $card_attr = DB::fetch_first('select * from %t where id = %d', array('aljtcc_card_attr', $_GET['card_attr_id']));
                if($card_attr['card_attr_price'] <= 0){
                    echo "<script>parent.tips_pay();</script>";
                    exit;
                }

                DB::insert('aljtcc_card_order', array(
                    'orderid' => $orderid,
                    'uid' => $_G['uid'],
                    'username' => $_G['username'],
                    'type' => $_GET['type'],
                    'card_number' => $_GET['card_number'],
                    'dateline' => $dateline,
                    'card_id' => $card_id,
                    'status' => 1,
                    'card_attr_id' => $_GET['card_attr_id']
                ));

                require_once 'source/plugin/aljqb/class/Qbapi.class.php';
                $qbapi = new Qbapi();
                $keyurlarray = array(
                    'orderid' => $orderid,
                    'time' => TIMESTAMP,
                    'price' => $card_attr['card_attr_price'],
                    'keyname' => 'aljtcc',
                    'return_url' => rtrim($qbapi->siteurl, '/').'/'.'plugin.php?id=aljtcc&c=index&a=index&ajax=yes&card_id='.$card_id,
                    'key' => $_G['cache']['plugin']['aljtcc']['qb_key'],
                );

                $url = $qbapi -> createUrl($keyurlarray);
                echo "<script>parent.location.href='" . $url . "';</script>";
                exit;
            }else{
                $card_service_id = $card_id == 2 ? 3 : 0;
                
                $card = DB::fetch_first('select * from %t where card_service_id = %d and used = 0 and card_day_num>0 and card_day_num_open>0  and card_number = %s and dateline + card_day_num * 86400 > %d', array('aljac_card',$card_service_id, $_GET['card_number'], TIMESTAMP));
                
                if($card){
                    
                    DB::insert('aljtcc_card_order', array(
                        'orderid' => $orderid,
                        'uid' => $_G['uid'],
                        'username' => $_G['username'],
                        'type' => $_GET['type'],
                        'card_number' => $_GET['card_number'],
                        'dateline' => TIMESTAMP,
                        'card_id' => $card_id,
                        'status' => 2
                    ));

                    
                    if(DB::query('update %t set used = 1, used_time=%d, uid=%d, username=%s where card_service_id=%d and card_number=%s', array('aljac_card', TIMESTAMP , $_G['uid'], $_G['username'],$card_service_id, $_GET['card_number']))){
                        DB::query('update %t set unused_card_num = unused_card_num-1,  used_card_num = used_card_num+1 where id=%d', array('aljac_card_type', $card['card_type']));  //��������ʹ��+1 δʹ��-1 
                        if($user){
                            $end_time = $user['end_time'] > TIMESTAMP ? $user['end_time'] : TIMESTAMP;
                            DB::query('update %t set end_time = %d where uid=%d and card_id=%d', array('aljtcc_card_user', $end_time + $card['card_day_num_open'] * 86400, $_G['uid'], $card_id));
                        }else{
                            DB::insert('aljtcc_card_user', array(
                                'uid' => $_G['uid'],
                                'card_id' => $card_id,
                                'username' => $_G['username'],
                                'start_time' => TIMESTAMP,
                                'end_time' => TIMESTAMP+$card['card_day_num_open'] * 86400
                            ));
                        }
                        echo '<script>parent.tips_success()</script>';
                        exit;
                    }else{
                        echo '<script>parent.tips()</script>';
                        exit;
                    }
                }else{
                    echo '<script>parent.tips()</script>';
                    exit;
                }
            }
            
        }else{
            $card = DB::fetch_first('select * from %t where id=%d', array('aljtcc_card', $card_id));
            $card['card_color'] = $card['card_color'] ? $card['card_color'] : '#237ffd';
            $card_attr_list = DB::fetch_all('select * from %t where card_id=%d and is_hide=0', array('aljtcc_card_attr', $card_id));
            define('IN_MOBILE', 2);
            $_G['mobile'] = 2;
            $_G['setting']['hookscript'] = array();
            $this->page->assign('user', $user);
            $this->page->assign('card_id', $card_id);
            $this->page->assign('card', $card, true);
            $this->page->assign('card_attr_list', $card_attr_list);
            $this->page->display();
        }
    }
}

