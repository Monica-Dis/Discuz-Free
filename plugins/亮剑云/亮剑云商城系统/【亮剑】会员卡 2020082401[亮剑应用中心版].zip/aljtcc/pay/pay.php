<?php
	define('DISABLEXSSCHECK',true);
	require '../../../../source/class/class_core.php';
	$discuz = C::app();
	$discuz->init();
  	loadcache('plugin');
	require_once '../../../../source/plugin/aljqb/class/Qbapi.class.php';
	if(file_exists('../../../../source/plugin/aljqb/class/Getdata.class.php')){
		require_once '../../../../source/plugin/aljqb/class/Getdata.class.php';
		$getdata = new Getdata();
    }
    $order['card_attr_id'] = 2;
    $data['out_trade_no'] = $_GET['orderid'];
    $data['transaction_id'] = $_GET['aljorderid'];

    $qbapi = new Qbapi();
	$keyarray = array(
		'aljorderid'=> $_GET['aljorderid'],
		'paytime' => $_GET['paytime'],
		'orderid' => $_GET['orderid'],
	);

    $keyarray['key'] = $_G['cache']['plugin']['aljtcc']['qb_key'];
	$key = $qbapi->createKey($keyarray);
    
    $order = DB::fetch_first('select * from %t where orderid=%s',array('aljtcc_card_order', $data['out_trade_no']));
    $card_id = $order['card_id'];
	
    $orderlurl = rtrim($qbapi->siteurl, '/').'/'.'plugin.php?id=aljtcc&c=index&a=index&ajax=yes&card_id='.$card_id;
    
	$orderlurln = rtrim($qbapi->siteurl, '/').'/'.'plugin.php?id=aljtcc&c=index&a=index&ajax=yes&card_id='.$card_id;
	
	if($_GET['key']) {
		$getkey = $_GET['key'];
	}elseif(file_exists('../../../../source/plugin/aljqb/class/Getdata.class.php')) {
		$appinfo = $getdata->getAppParam();
		$appinfo['posttime']=$_GET['posttime'];
		$key = $getdata->CreateAppSign($appinfo);
		$getkey = $_GET['sign'];
	}
	if($getkey && $getkey && $key == $getkey) {

        
        $dateline = TIMESTAMP;

        
        $card_attr = DB::fetch_first('select * from %t where id = %d', array('aljtcc_card_attr', $order['card_attr_id']));
        if($order['status'] == 1){
            $qborder = DB::fetch_first('select * from %t where aljorderid=%s',array('aljqb_payorder',$_GET['aljorderid']));
            DB::query('update %t set trade_mod = %s, status = 2, buyer = %s, confirmdate=%d  where orderid=%s', array('aljtcc_card_order', $qborder['trade_mod'], $data['transaction_id'], $_GET['paytime'], $data['out_trade_no']));

            $user = DB::fetch_first('select * from %t where uid=%d and card_id=%d', array('aljtcc_card_user', $order['uid'], $card_id));
            
            $card_info = DB::fetch_first('select * from %t where id=%d ',array('aljtcc_card',$order['card_id']));
            if($user){
                $order['stitle'] = lang("plugin/aljtcc","pay_php_1").$order['username'].lang("plugin/aljtcc","pay_php_2").$card_info['card_title'].'-'.$qborder['price'];
                $end_time = $user['end_time'] > TIMESTAMP ? $user['end_time'] : TIMESTAMP;
                DB::query('update %t set end_time = %d where card_no=%d', array('aljtcc_card_user', $end_time + $card_attr['card_attr_day_num'] * 86400, $user['card_no']));
            }else{
                $order['stitle'] = lang("plugin/aljtcc","pay_php_3").$order['username'].lang("plugin/aljtcc","pay_php_4").$card_info['card_title'].'-'.$qborder['price'];
                DB::insert('aljtcc_card_user', array(
                    'uid' => $order['uid'],
                    'card_id' => $card_id,
                    'username' => $order['username'],
                    'start_time' => $dateline,
                    'end_time' => $dateline+$card_attr['card_attr_day_num'] * 86400
                ));
            }
            $order['price'] = $qborder['price'];
            //s ������ѯ���� �ֵ�
            if($_G['cache']['plugin']['aljhhr']['is_aljhhr']){
                $hhr_path = DISCUZ_ROOT . "source/plugin/aljhhr/function/function.php";
                if(is_file($hhr_path)){
                    include_once $hhr_path;
                    hhrDivideInto($order,'aljtcc');
                }
            }
            //e ������ѯ����
            if($_G['cache']['plugin']['aljtsq']){
                //ƽ̨����
                require_once DISCUZ_ROOT . 'source/plugin/aljhtx/class/class_aljhtx.php';
                T::platformRevenue($order,$order['stitle'],$order['price'],'aljtcc');
            }
            
		}
        echo 'success';
        exit;
	}
?>
