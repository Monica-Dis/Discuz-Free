<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql ="ALTER TABLE  ".DB::table('aljtcc_card_attr')." ADD `is_hide` tinyint(4) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtcc_card')." ADD `integral_multiple` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtcc_card')." ADD `card_rights_title` char(50) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtcc_card')." ADD `card_rights_title_color` char(50) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtcc_card')." ADD `card_rights_intro` text NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtcc_card')." ADD `card_authority` text NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtcc_card')." ADD `card_tc_post` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtcc_card')." ADD `card_tsq_post` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');

//finish to put your own code
$finish = TRUE;
?>