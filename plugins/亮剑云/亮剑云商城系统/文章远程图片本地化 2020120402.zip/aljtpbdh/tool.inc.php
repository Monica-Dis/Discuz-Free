<?php

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

if($_G['groupid'] != 1){
    exit();
}


$content = $_GET['content'];
if(submitcheck('formhash')){
    $replace = replaceimg($content);
}

include template('aljtpbdh:tool');

function replaceimg($xstr){
    global $_G;
    loadcache('plugin');
    $d = date('Ymd', time());
    $dir = DISCUZ_ROOT.'source/plugin/aljtpbdh/img/'.$d;
    if(!is_dir($dir)) {
        @mkdir($dir, 0777);
    }
    //匹配图片的src
    preg_match_all('#<img.*?src="([^"]*)"[^>]*>#i', $xstr, $match);
    
    foreach($match[1] as $imgurl){
        $arcurl = $imgurl;
        $img=file_get_contents($arcurl);
        if(!empty($img)) {
            $fileimgname = time()."-".rand(1000,9999).".jpg";
            $filecachs=$dir."/".$fileimgname;
            file_put_contents($filecachs, $img);
            $saveimgfile = 'source/plugin/aljtpbdh/img/'.$d."/".$fileimgname;
            if (file_exists($filecachs)) {
                if($_G['cache']['plugin']['aljoss']['Access_Key']){
                    require_once 'source/plugin/aljhtx/class/class_aljhtx.php';
                    $saveimgfile = T::oss($filecachs, 'aljhtx/setting');
                }
            }
            $xstr=str_replace($imgurl,$saveimgfile,$xstr);
        }
    }
    return $xstr;
}