<?php

/*
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ����֧��: http://t.cn/Aiux1Jx1
 * https://dism.taobao.com
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
echo '<iframe style="width:100%;height:100%;min-height:780px;border:none;" src="//dism.taobao.com/?@3932.developer"></iframe>';
exit;
?>