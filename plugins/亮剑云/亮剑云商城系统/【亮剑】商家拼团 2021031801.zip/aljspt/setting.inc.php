<?php

/*
 * Discuz! x3.4 By DisM.taobao.COM
 * ��ϵQQ:578933760
 *
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$pluginid='aljbd';
$mypluginid = 'aljspt';
$config = array();
foreach($pluginvars as $key => $val) {
	$config[$key] = $val['value'];
}
//$_GET=dhtmlspecialchars($_GET);
if(submitcheck('formhash')){
	
	foreach($_GET['settingsnew'] as $k=>$v){
		if(in_array($k, array('m_groups','lj_groups'))){
			$v = (string)serialize($v);
		}
		if(!C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch($k)){
			C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>$k,'value'=>$v));
		}else{
			C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($v,$k);
		}
	}

	cpmsg('&#26356;&#26032;&#25104;&#21151;&#65281;', 'action=plugins&operation=config&identifier='.$mypluginid.'&pmod=setting', 'succeed');
}else{
	$setting = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->range();
	$settings= $setting;
	include template($mypluginid.':setting');
}
function l_groups($group,$type=0){
	global $_G,$config,$lang,$settings;
	if($type){
        $var['type'] = '<select name="'.$var['variable'].'"><option value="">'.cplang('plugins_empty').'</option>';
    }else{
        $var['description'] = ($var['description'] ? (isset($lang[$var['description']]) ? $lang[$var['description']] : $var['description'])."\n" : '').$lang['plugins_edit_vars_multiselect_comment']."\n".$var['comment'];
        $var['value'] = dunserialize($settings[$group]['value']);
        $var['type'] = '<select name="settingsnew['.$group.'][]" size="10" multiple="multiple"><option value=""'.(@in_array('', $var['value']) ? ' selected' : '').'>'.cplang('plugins_empty').'</option>';
    }

	$var['value'] = is_array($var['value']) ? $var['value'] : array($var['value']);
	
	$query = C::t('common_usergroup')->range_orderby_credit();
	$groupselect = array();
	foreach($query as $group) {
		$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
		$groupselect[$group['type']] .= '<option value="'.$group['groupid'].'"'.(@in_array($group['groupid'], $var['value']) ? ' selected' : '').'>'.$group['grouptitle'].'</option>';
	}
	$var['type'] .= '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
		($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
		($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
		'<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup></select>';
	return $var['type'];
}
?>
