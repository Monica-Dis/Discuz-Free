<?php

/*
 * [DisM!] (C)2001-2099 DisM Inc.
 * ����֧��: http://DisM.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


echo "<script language='javascript'>";
echo "parent.location.href='https://dism.taobao.com/?@liangjian'";
echo "</script>";
exit;