<?php

/**
 *
 * @author DisM!Ӧ������[dism.taobao.com]
 * @version 1.0
 * @����̳����� http://docs.liangjianyun.com/
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class WriteOffAction{
    public $page;

    public function __construct($page) {
        $this->page = $page;
        $this->aljbdParameter();
    }
    /**
     * �����б�
     *
     *
     * @return void
     */
    public function wirteOffList () {
        
        $this->page->assign('navtitle', lang("plugin/aljstg","writeOff_php_1"));
        $this->page->display();
    }
    /**
     * weui�����ʾҳ
     * @param array $info ��ʾ�������
     *
     * @return void
     */
    public function weuiResult ($info=array()){

        $this->page->assign('result_info', $info);
        $this->page->assign('navtitle', lang("plugin/aljstg","writeOff_php_2"));
        $this->page->display($this->page->templatePluginID . ':' . ROOT .'/' . $this ->page->controller. '/result');
    }
    /**
     * �Ź�ȯ�����ɹ���ʾ
     *
     * @return void
     */
    public function writeOffResult (){
        $type = $this->page->get->type;
        if($type == 1){
            $typeurl = '&type='.$type;
        }
        $write_off_url = array('value' => lang("plugin/aljstg","writeOff_php_3"), 'url' => 'plugin.php?id=aljstg&c=writeOff&a=writeOff'.$typeurl);
        $orderurl = array('value' => lang("plugin/aljstg","writeOff_php_4"), 'url' => 'plugin.php?id=aljbd&act=orderlist');
        $result_info = array(
            'icon' => 'weui-icon-success',
            'title' => lang("plugin/aljstg","writeOff_php_5"),
            'desc' => '',
            'btn_primary' => $write_off_url,
            'btn_default' => $orderurl,
        );
        $this->weuiResult($result_info);
    }

    /**
     * �Ź�ȯ����
     *
     * @return void
     */
    public function writeOff (){
        if($this->page->get->formhash == FORMHASH){
            $password = $this->page->get->password;
            $type = $this->page->get->type;
            if(!$password || !$woc = DB::fetch_first('select * from %t where password=%s and type=%d',array('aljbd_write_off_code',$password,$type))){
                $desc = lang("plugin/aljstg","writeOff_php_6");
                $this->page->tips($desc);
            }
            $this -> shopWriteOffResult($password);
        }else{

            $this->page->assign('type', $this->page->get->type);
            $this->page->assign('navtitle', lang("plugin/aljstg","writeOff_php_7"));
            $this->page->display();
        }
    }
    /**
     * �Ź�ȯ������������
     *
     * @param int $pw ������
     * @param int $type ���� 0=�Ź� 1=��ͨ��Ʒ����
     *
     * @return string
     */
    public function shopWriteOffResult ($pw=0,$type=0) {
        global $_G;
        $password = $pw ? $pw : $this->page->get->password;
        $type = $type ? $type : $this->page->get->type;
        if($type == 1){
            $typeurl = '&type='.$type;
        }
        $write_off_url = array('value' => lang("plugin/aljstg","writeOff_php_8"), 'url' => 'plugin.php?id=aljstg&c=writeOff&a=writeOff'.$typeurl);
        $orderurl = array('value' => lang("plugin/aljstg","writeOff_php_9"), 'url' => 'plugin.php?id=aljbd&act=orderlist');
        if(!$password || !$woc = DB::fetch_first('select * from %t where password=%s and type=%d',array('aljbd_write_off_code',$password,$type))){
            $desc = lang("plugin/aljstg","writeOff_php_10");
            if($pw){
                $this->page->tips($desc);
            }else{
                $result_info = array(
                    'icon' => 'weui-icon-warn',
                    'title' => lang("plugin/aljstg","writeOff_php_11"),
                    'desc' => $desc,
                    'btn_primary' => $write_off_url,
                    'btn_default' => $orderurl,
                );
                $this->weuiResult($result_info);
            }
        }

        $orderid = $woc['orderid'];
        $_GET['orderid'] = $woc['orderid'];
        $order = C::t('#aljbdx#aljbd_goods_order') -> fetch($orderid);
        $bids = DB::fetch_all('select id from %t where uid = %d',array('aljbd',$this->page->global->uid));
        foreach($bids as $bid){
            $ids[] = $bid['id'];
        }
        if($this->page->global->cache->plugin->aljtsq->is_aljtsq){
            if($woc['store_id'] > 0){
                $st_type = 2;//�ŵ����
                $shop_id = $woc['store_id'];
            }else{
                $st_type = 1;//�ܵ����
                $shop_id = $woc['shop_id'];
            }
            
            $staffInfo = baseStaff($shop_id,$st_type);
        }
        
        if(!in_array($woc['shop_id'],$ids) && !in_array('staff_ddhx',$staffInfo['st_staff_authority'])){
            $desc = lang("plugin/aljstg","writeOff_php_12");
            if($pw){
                $this->page->tips($desc);
            }else{
                $result_info = array(
                    'icon' => 'weui-icon-warn',
                    'title' => lang("plugin/aljstg","writeOff_php_13"),
                    'desc' => $desc,
                    'btn_primary' => $write_off_url,
                    'btn_default' => $orderurl,
                );
                $this->weuiResult($result_info);
            }
        }
        if($woc['status'] == 1){
            $desc = lang("plugin/aljstg","writeOff_php_14");
            if($pw){
                $this->page->tips($desc);
            }else{
                $result_info = array(
                    'icon' => 'weui-icon-warn',
                    'title' => lang("plugin/aljstg","writeOff_php_15"),
                    'desc' => $desc,
                    'btn_primary' => $write_off_url,
                    'btn_default' => $orderurl,
                );
                $this->weuiResult($result_info);
            }
        }

        if(DB::update('aljbd_write_off_code', array('status' => 1,'hx_uid'=>$_G['uid'],'hx_username'=>$_G['username'],'endtime'=>TIMESTAMP,'price'=>$order['price'],'reason'=>$_GET['reason']), array('password' => $password, 'status' => 0)) && DB::query("update %t set status=4 where orderid = %s",array('aljbd_goods_order',$orderid))){
            if($type == 1){
                $mes = str_replace(array('{goodsname}', '{url}'), array($woc['name'], 'plugin.php?id=aljbd&act=orderlist&orderid='.$woc['orderid']), $this->page->global->cache->plugin->aljstg->pick_up_code_user_tips);
            }else{
                $mes = str_replace(array('{goodsname}', '{url}'), array($woc['name'], 'plugin.php?id=aljbd&act=orderlist&orderid='.$woc['orderid']), $this->page->global->cache->plugin->aljstg->write_off_user_tips);
            }
            Message::sendNotification($woc['uid'], $mes);
            
            if(file_exists("source/plugin/aljhtx/class/class_aljbdx.php")){
                require_once 'source/plugin/aljhtx/class/class_aljbdx.php';
                aljbdx::handle($order);//�ջ���������
            }else{
                $this->receipt($order);
            }
            if($pw){
                $desc = lang("plugin/aljstg","writeOff_php_16");
                $this->page->tips($desc,C_URL.'&a=writeOffResult'.$typeurl);
            }else{
                $result_info = array(
                    'icon' => 'weui-icon-success',
                    'title' => lang("plugin/aljstg","writeOff_php_17"),
                    'desc' => $desc,
                    'btn_primary' => $write_off_url,
                    'btn_default' => $orderurl,
                );
                $this->weuiResult($result_info);
            }
        }else{
            $desc = lang("plugin/aljstg","writeOff_php_18");
            if($pw){
                $this->page->tips($desc);
            }else{
                $result_info = array(
                    'icon' => 'weui-icon-warn',
                    'title' => lang("plugin/aljstg","writeOff_php_19"),
                    'desc' => $desc,
                    'btn_primary' => $write_off_url,
                    'btn_default' => $orderurl,
                );
                $this->weuiResult($result_info);
            }
        }
    }
     /**
     * ���㶩������������������
     *
     * @param array() $order ��������
     * @return void
     */
    public function receipt($order){
        global $_G;
        $brand = C::t('#aljbd#aljbd') -> fetch($order['shop_id']);
        $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$brand['vipid']));

        if($vipdata['fee']>0){
            $fee = sprintf("%.2f",$order['price']*($vipdata['fee']/100));//վ����ɱ���
        }else{
            $fee = sprintf("%.2f",$order['price']*($this->page->global->cache->plugin->aljbdx->fee/100));//վ����ɱ���
        }
        if ($brand && $order['price']>0) {
            //����Ǯ�� +money
            $result = $this->aljqbChargeMoney ($brand['uid'],$order['price'],$orderid,str_replace(array('{username}', '{title}', '{money}'), array(lang('plugin/aljbd','l_danyinghao').$order['username'].lang('plugin/aljbd','r_danyinghao'), $order['stitle'], $order['price']), $this->page->global->cache->plugin->aljbdx->qb_desc_add));
            //����Ǯ��
            if ($result['code'] == 200) {
                
                if ($fee > 0) {
                    sleep(1);
                    //����Ǯ�� -money
                    $this->aljqbTakeMoney ($brand['uid'], $fee,$orderid,str_replace(array('{money}'), array($fee), $this->page->global->cache->plugin->aljbdx->qb_desc_fee));
                    //����Ǯ��
                    //����Ǯ�� +money ����ͳ���ʻ�
                    if ($this->page->global->cache->plugin->aljbdx->money_uid > 0) {
                        sleep(1);
                        $this->aljqbChargeMoney($this->page->global->cache->plugin->aljbdx->money_uid, $fee,$orderid,str_replace(array('{username}', '{name}', '{title}', '{money}'), array(lang('plugin/aljbd','l_danyinghao').$brand['username'].lang('plugin/aljbd','r_danyinghao'), $brand['name'], $order['stitle'], $fee), $this->page->global->cache->plugin->aljbdx->qb_desc_uid_fee));
                    }
                }
                $orderlurln = '/plugin.php?id=aljbd&act=orderlist';
                //s ��ѯ�Ƿ�������
                if ($this->page->global->cache->plugin->aljreg->qb_desc) {
                    $fromuid = DB::result_first('select fromuid from %t where uid=%d ', array('aljreg_invite', $order['uid']));
                    $new_order_num = DB::result_first('select count(*) from %t where uid=%d and status>3 and pid=0', array('aljbd_goods_order', $this->page->global->uid));
                    if ($this->page->global->cache->plugin->aljbdx->new_regfee && $new_order_num <= 1) {
                        $regfee = sprintf("%.2f", $order['price'] * ($this->page->global->cache->plugin->aljbdx->new_regfee / 100));//�׵���ɱ���
                    } else {
                        $regfee = sprintf("%1.2f", $order['price'] * ($this->page->global->cache->plugin->aljbdx->regfee / 100));//
                    }
                    if ($fromuid > 0 && $regfee > 0) {
                        sleep(1);
                        //����Ǯ�� +money
                        $this->aljqbChargeMoney($fromuid, $regfee,$orderid,str_replace(array('{username}', '{money}'), array(lang('plugin/aljbd','l_danyinghao').$order['username'].lang('plugin/aljbd','r_danyinghao'), $regfee), $this->page->global->cache->plugin->aljbdx->qb_desc_regfee));
                    }
                }
                //e��ѯ�Ƿ�������
                //$brand = C::t('#aljbd#aljbd')->fetch($order['shop_id']);
                //s ������Ա������Ϣ
                if ($this->page->global->cache->plugin->aljbdx->receipt_tips) {
                    $groupids = DB::fetch_all('select * from %t where groupid = %d', array('common_member', 1));
                    $mes = str_replace(array('{username}', '{url}', '{shopname}'), array($order['username'], $orderlurln, $brand['name']), $this->page->global->cache->plugin->aljbdx->receipt_tips);
                    foreach ($groupids as $g_uid) {
                        notification_add($g_uid['uid'], 'system', $mes);
                    }
                }
                //s ������Ա������Ϣ
                if ($this->page->global->cache->plugin->aljbdx->receipt_tips_brand) {
                    if($type == 1){
                        $mes_brand = str_replace(array('{username}', '{url}', '{shopname}'), array($order['username'], $orderlurln, $brand['name']), $this->page->global->cache->plugin->aljstg->pick_up_code_shop_tips);
                    }else{
                        $mes_brand = str_replace(array('{username}', '{url}', '{shopname}'), array($order['username'], $orderlurln, $brand['name']), $this->page->global->cache->plugin->aljstg->write_off_user_tips);
                    }
                    notification_add($brand['uid'], 'system', $mes_brand);
                }
                //s ������ѯ���� �ֵ�
                if($_G['cache']['plugin']['aljsfx']['is_aljsfx']){
                    require_once 'source/plugin/aljsfx/include/receipt.php';
                    if($fx_goods_prices>0){
                        sleep(1);
                        $fx_goods_price = substr(sprintf("%.3f",$fx_goods_prices),0,-1);//��Ʒ����Ӷ�����
                        //����Ǯ�� -money
                        $this->aljqbTakeMoney ($brand['uid'], $fx_goods_price,$orderid,str_replace(array('{money}'),array($fx_goods_price),lang("plugin/aljbdx","receipt_php_5")));
                    }
                }
                //e ������ѯ����
            }
        }
    }
    /**
     * Ǯ�������
     *
     * @param int $uid �û�id
     * @param int $price �۸�
     * @param string $orderid ������
     * @param string $desc �����Ǯ������
     *
     * @return array
     */
    public function aljqbChargeMoney ($uid=0,$price=0,$orderid='',$desc='') {
        require_once 'source/plugin/aljqb/class/Qbapi.class.php';
        $Qbapi = new Qbapi();
        $queuearray = array(
            'app_name' => 'aljbdx',
            'app_type' => 'aljbdx_txcancel',
            'app_phone' => '123456789',
            'app_ip' => $this->page->global->clientip,
        );
        $balancearray = array(
            'type' => 'charge',
            'uid' => $uid,
            'price' => $price,
            'orderid' => $orderid,
            'desc' => $desc,
        );
        $res = $Qbapi->balance($queuearray, $balancearray);
        return $res;
    }
    /**
     * Ǯ�������
     *
     * @param int $uid �û�id
     * @param int $price �۸�
     * @param string $orderid ������
     * @param string $desc �����Ǯ������
     *
     * @return array
     */
    public function aljqbTakeMoney ($uid=0,$price=0,$orderid='',$desc='') {
        require_once 'source/plugin/aljqb/class/Qbapi.class.php';
        $Qbapi = new Qbapi();
        $queuearray = array(
            'app_name' => 'aljbdx',
            'app_type' => 'aljbdx_txcancel',
            'app_phone' => '123456789',
            'app_ip' => $this->page->global->clientip,
        );
        $balancearray = array(
            'type' => 'take',
            'uid' => $uid,
            'price' => $price,
            'orderid' => $orderid,
            'desc' => $desc,
        );
        $res = $Qbapi->balance($queuearray, $balancearray);
        return $res;
    }
    /**
     * Ʒ���̼ҹ�������ע��
     *
     *
     * @return void
     */
    public function aljbdParameter(){
        global $Html5Plusapp,$immersed;
        $settings=C::t('#aljbd#aljbd_setting')->range();
        $mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_common_footernav']['value']));
        foreach($mobile_common_footernav as $key=>$value){
            $arr=explode('|',$value);
            $mobile_common_footernav_arr[]=$arr;
        }
        $price_unit = '&#65509;';
        $this->page->assign('price_unit', $price_unit,true);
        $this->page->assign('pluginid', 'aljbd');
        $this->page->assign('Html5Plusapp', $Html5Plusapp);
        $this->page->assign('immersed', $immersed);
        $this->page->assign('settings', $settings);
        $this->page->assign('mobile_common_footernav_arr', $mobile_common_footernav_arr,true);
        $this->page->assign('common_template_pluginid', 'aljbd');
        $this->page->assign('common_path', 'source/plugin/aljhtx');
    }
}

