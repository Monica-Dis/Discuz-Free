<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


if(!isset($_G['cache']['plugin'])) {
	loadcache('plugin');
}


if($_GET['act'] == 'delete_all'){
	
	if($_G['groupid']!=1){
		cpmsg(lang('plugin/aljpay','nopermission'));
	}
	DB::query('delete from %t where status=0',array('aljpay_order'));
	cpmsg(lang('plugin/aljpay','do'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljpay&pmod=adminorderlist'.$url, 'succeed');
} else if($_GET['act'] == 'delete'){
	$orderid = addslashes($_GET['orderid']);
	if($_G['groupid']!=1){
		cpmsg(lang('plugin/aljpay','nopermission'));
	}
	C::t('#aljpay#aljpay_order')->delete($orderid);
	cpmsg(lang('plugin/aljpay','do'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljpay&pmod=adminorderlist'.$url, 'succeed');
} else{
	$pluginid = 'aljpay';
	$starttime = strtotime($_GET['starttime']);
	$endtime = strtotime($_GET['endtime']);
	$currpage=$_GET['page']?$_GET['page']:1;
	$perpage=30;
	$conn[] =$pluginid.'_order';
	$where = 'where 1';
	if($_GET['keyword']){
		$keyword = stripsearchkey($_GET['keyword']);
		$keyword = '%'.$keyword.'%';
		if($_GET['ordertype'] == 1){
			$where .= ' and orderid like %s ';
		}else{
			$where .= ' and username like %s ';
		}
		$conn[] = $keyword;
	}
	if($_GET['starttime']){
		$where .= ' and createtime >= %s';
		$conn[] = $starttime;
	}
	if($_GET['endtime']){
		$where .= ' and createtime <= %s';
		$conn[] = $endtime;
	}
	$ext = DB::result_first('select sum(extnum) from %t '.$where.' and status=1 ',$conn);
	$wext = DB::result_first('select sum(extnum) from %t '.$where.' and status=0 ',$conn);
	$overorder = DB::result_first('select count(*) from %t '.$where.' and status=1 ',$conn);
	$noverorder = DB::result_first('select count(*) from %t '.$where.' and status=0 ',$conn);
	$num = DB::result_first('select count(*) from %t '.$where,$conn);
	$start=($currpage-1)*$perpage;
	$where .= ' order by createtime desc';
	$where .= ' limit %d,%d';
	$conn[] = $start;
	$conn[] = $perpage;
	$orderlist = DB::fetch_all('select * from %t '.$where,$conn);
	$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljpay&pmod=adminorderlist'.$url, 0, 11, false, false);
	include template('aljpay:adminorderlist');
	
}
//From: Dism_taobao_com
?>