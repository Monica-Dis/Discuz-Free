<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljpay_order` (
  `orderid` varchar(255) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `pluginid` varchar(255) NOT NULL,
  `pluginmod` char(50) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `createtime` int(10) NOT NULL,
  `paytime` int(10) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `extnum` int(10) NOT NULL,
  `extcredit` tinyint(3) NOT NULL,
  `body` varchar(255) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `deliver` tinyint(3) NOT NULL,
  `gift_points` int(10) NOT NULL,
  PRIMARY KEY (`orderid`)
)
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>