<?php
	define('DISABLEXSSCHECK',true);
	require '../../../../source/class/class_core.php';
	$discuz = C::app();
	$discuz->init();
	loadcache('plugin');
	$config = $_G['cache']['plugin']['aljpay'];
	require_once '../../../../source/plugin/aljqb/class/Qbapi.class.php';
	$qbapi = new Qbapi();
	$keyarray = array(
		'aljorderid'=> $_GET['aljorderid'],
		'paytime' => $_GET['paytime'],
		'orderid' => $_GET['orderid'],
		'key'=> $config['aljpaykey'],
	);
	$key = $qbapi->createKey($keyarray);
	//file_put_contents('d.txt',$config['aljpaykey']."\r",FILE_APPEND);
	//file_put_contents('d.txt',$_GET['key']."\r",FILE_APPEND);
	if($key == $_GET['key']) {
		$order = DB::fetch_first('select * from %t where orderid=%s',array('aljpay_order',$_GET['orderid']));
		$updatearray = array();
		if(empty($order['transaction_id'])){
			$updatearray['transaction_id'] = $_GET['aljorderid'];
		}
		if($order['status']<1){
			$updatearray['status'] = 1;
		}
		if($order['deliver']<1){
			$updatearray['deliver'] = 1;
			$user = DB::fetch_first('select * from %t where username=%s',array('common_member',$order['username']));
			//updatemembercount($user['uid'], array($order['extcredit'] => $order['extnum']));
			updatemembercount($user[uid], array($order['extcredit'] => $order['extnum']+$order['gift_points']), true, 'AFD', $user[uid]);
		}
		if($order['paytime']<1){
			$updatearray['paytime'] = $_GET['paytime'];
		}
		if(DB::update('aljpay_order',$updatearray,array('orderid' => $order['orderid']))) {
			if($_G['cache']['plugin']['aljhhr']['is_aljhhr']){
				$order['stitle'] = $order['body'];
                $hhr_path = DISCUZ_ROOT . "source/plugin/aljhhr/function/function.php";
                if(is_file($hhr_path)){
                    include_once $hhr_path;
                    hhrDivideInto($order,'aljpay');
                }
			}
			//��ֵ�û�����
			notification_add($user[uid], 'system','<a href="plugin.php?id=aljpay&act=myorder">'.lang('plugin/aljpay','pay_1').($order['gift_points'] ? lang('plugin/aljpay','pay_2') : '').lang('plugin/aljpay','pay_3').'</a>',array(
				'from_idtype'  => 'aljpay',
				'from_id' => $_GET['orderid'],
				'extnum' => ($order['extnum']+$order['gift_points']).$_G['setting']['extcredits'][$order['extcredit']]['title'],
				'gift_points' => $order['gift_points'].$_G['setting']['extcredits'][$order['extcredit']]['title']
			),1);
			if($user[uid] != $order['uid']){
				notification_add($order[uid], 'system','<a href="plugin.php?id=aljpay&act=myorder">'.$order['body'].', '.lang('plugin/aljpay','pay_1').($order['gift_points'] ? lang('plugin/aljpay','pay_2') : '').lang('plugin/aljpay','pay_3').'</a>',array(
					'from_idtype'  => 'aljpay',
					'from_id' => $_GET['orderid'],
					'extnum' => ($order['extnum']+$order['gift_points']).$_G['setting']['extcredits'][$order['extcredit']]['title'],
					'gift_points' => $order['gift_points'].$_G['setting']['extcredits'][$order['extcredit']]['title']
				),1);
			}
			echo 'success';
			exit;
		}
		
	}
//From: Dism��taobao��com
?>