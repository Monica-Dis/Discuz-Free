<?php

/*
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ����֧��: http://dism.Taobao.com/
 * �ͷ�QQ: 467783778
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljpay_order extends discuz_table {

    public function __construct() {

        $this->_table = 'aljpay_order';
        $this->_pk = 'orderid';

        parent::__construct(); /*dism��taobao��com*/
    }
}
//From: Dism_taobao_com
?>