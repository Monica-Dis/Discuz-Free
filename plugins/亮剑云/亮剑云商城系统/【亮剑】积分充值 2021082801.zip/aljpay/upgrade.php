<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql ="ALTER TABLE  ".DB::table('aljpay_order')." ADD  `gift_points` int(11) NOT NULL" ;
DB::query($sql,'SILENT');

$finish = TRUE;
?>