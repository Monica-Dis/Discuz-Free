<?php

/*
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ����֧��: http://dism.Taobao.com/
 * �ͷ�QQ: 467783778
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_GET[referer]){
    dsetcookie('referer_aljpay', $_GET[referer],'60');
}
//���ù�����
require_once 'source/plugin/aljhtx/class/class_aljhtx.php';
if(!$_G['mobile'] && !$_G['cache']['plugin']['aljpay']['is_pc_pay']) {
	include template('aljpay:code');
	exit;
}else{
	if(strtolower(CHARSET) == 'gbk' && !$_G['mobile']){
		$_GET=T::ajaxGetCharSet($_GET);
	}
	$_G['setting']['hookscript'] = array();
	define('IN_MOBILE', 2);
	$_G['mobile'] = 2;
	
}
if(is_file('source/plugin/aljqb/class/Qbapi.class.php')) {
	require_once 'source/plugin/aljqb/class/Qbapi.class.php';
	$qbapi = new Qbapi();
	$is_aljqb = true;
}else {
	$is_aljqb = false;
}
if($_G['cache']['plugin']['aljpay']['discount']){
	$discountlist = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljpay']['discount']));
	foreach($discountlist as $value){
		$arr=explode('+',$value);
		$discount[$arr[0]]=$arr[1];
	}
}
if($_G['cache']['plugin']['aljpay']['discount1']){
	$discountlist = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljpay']['discount1']));
	foreach($discountlist as $value){
		$arr=explode('+',$value);
		$discount1[$arr[0]]=$arr[1];
	}
}
if($_G['cache']['plugin']['aljpay']['discount2']){
	$discountlist = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljpay']['discount2']));
	foreach($discountlist as $value){
		$arr=explode('+',$value);
		$discount2[$arr[0]]=$arr[1];
	}
}
$config = $_G['cache']['plugin']['aljpay'];
$title = $_G['setting']['extcredits'][$config['extcredit']]['title'];
$title1 = $_G['setting']['extcredits'][$config['extcredit1']]['title'];
$title2 = $_G['setting']['extcredits'][$config['extcredit2']]['title'];
$allpre = intval(getuserprofile('extcredits'.$config['extcredit']));
$allpre1 = intval(getuserprofile('extcredits'.$config['extcredit1']));
$allpre2 = intval(getuserprofile('extcredits'.$config['extcredit2']));
if($_GET['extcredit'] > 0){
	if($_GET['extcredit'] == $config['extcredit2']){
		$ext_page_color = 'ext_page_color_'.$config['extcredit2'];
		$page_color = $config['page_color2'];
		$extcredit = $config['extcredit2'];
		$per = $config['per2'];
		$ext_title = $title2;
		$min = $config['min2'];
		$dis_count = $discount2;
	}else if($_GET['extcredit'] == $config['extcredit1']){
		$ext_page_color = 'ext_page_color_'.$config['extcredit1'];
		$page_color = $config['page_color1'];
		$extcredit = $config['extcredit1'];
		$per = $config['per1'];
		$ext_title = $title1;
		$min = $config['min1'];
		$dis_count = $discount1;
	}else{
		$ext_page_color = 'ext_page_color_'.$config['extcredit'];
		$page_color = $config['page_color'];
		$extcredit = $config['extcredit'];
		$per = $config['per'];
		$ext_title = $title;
		$min = $config['min'];
		$dis_count = $discount;
	}
}else{
	$ext_page_color = 'ext_page_color_'.$config['extcredit'];
	$page_color = $config['page_color'];
	$per = $config['per'];
	$extcredit = $config['extcredit'];
	$ext_title = $title;
	$min = $config['min'];
	$dis_count = $discount;
}

$act = htmlspecialchars($_GET['act']);
$navtitle = '&#31215;&#20998;&#20805;&#20540;';
if(empty($_G['uid'])){
	dheader("location: member.php?mod=logging&action=login&referer=plugin.php?id=aljpay%26act=".$act);
	exit;
}
if($act == 'myorder'){
	include template('aljpay:myorder');
}else if($act == 'orderlog') {
	$page=!empty($_GET['page'])?intval($_GET['page']):1;
	$pagesize=8;
	$offset=($page-1)*$pagesize;
	$orderlog = DB::fetch_all('select * from %t where uid=%d order by createtime desc limit %d,%d',array('aljpay_order',$_G['uid'],$offset,$pagesize));
	if(!empty($orderlog)) {
		foreach($orderlog as $tmp_key => $tmp_value) {
			if(!$tmp_value['status']) {
				if($tmp_value['createtime']+900>TIMESTAMP) {
					$tmp_value['status'] = 2;
					$aljqb_params=array(
						'orderid'=> $tmp_value['orderid'],
						'time' => $tmp_value['createtime'],
						'price'=> $tmp_value['price'],
						'keyname' => 'aljpay',
						'key'=> $config['aljpaykey'],
						'return_url'=>$_G['siteurl'].'plugin.php?id=aljpay',
					);
					$tmp_value['url'] = $qbapi->createUrl($aljqb_params);
					$orderlog[$tmp_key] = $tmp_value;
				}
			}
		}
		include template('aljpay:orderlog');
		exit;
	}else {
		echo 1;
		exit;
	}
}else if($act == 'confirmorder') {
	if(!$is_aljqb) {
		$tips = array(
				'status'=> 1,
				'message'=>'&#26410;&#23433;&#35013;&#38065;&#21253;&#25554;&#20214;'
		);
		echo json_encode(ajaxPostCharSet_aljpay($tips));
		exit;
	}
    if(!$_G['mobile']){
        $_GET = u_g_CharSet_aljlogin($_GET);
    }
	$extnum = intval($_GET['extnum']);
	
	$username = addslashes($_GET['username']);
	$price = round($extnum/$per,2);
	if($extnum < $min){
		$tips = array(
			'status'=> 1,
			'message'=>lang('plugin/aljpay','buynumtips').$min.$ext_title
		);
		echo json_encode(ajaxPostCharSet_aljpay($tips));
		exit;
	}
	$checkusername = DB::result_first('select count(*) from %t where username = %s',array('common_member',$username));
	if($checkusername<1){
		$tips = array(
				'status'=> 1,
				'message'=>lang('plugin/aljpay','nousertips').$username
		);
		echo json_encode(ajaxPostCharSet_aljpay($tips));
		exit;
	}
	$subject = lang('plugin/aljpay','give').$username.lang('plugin/aljpay','accountrecharge').$extnum.$ext_title;
	dsetcookie('aljpay_aljqb_subject', $subject,'120');
	$orderid = getorderid();
	if($dis_count){
		foreach($dis_count as $dk=>$dv){
			if($extnum>=$dk){
				$gift_points = $dv;
			}
		}
	}

	$orderparams = array(
		'orderid' => $orderid,
		'uid' => $_G['uid'],
		'username' => $username,
		'pluginid' => 'aljpay',
		'pluginmod' => 'recharge',
		'price' => $price,
		'body' => $subject,
		'extcredit' => $extcredit,
		'extnum' => $extnum,
		'gift_points' => $gift_points,
		'createtime'=>TIMESTAMP
	);
	if(createorder($orderparams)) {
		$aljqb_params=array(
			'orderid'=> $orderparams['orderid'],
			'time' => $orderparams['createtime'],
			'price'=> $orderparams['price'],
			'keyname' => 'aljpay',
			'key'=> $config['aljpaykey'],
			'return_url'=>$_G['cookie']['referer_aljpay'] ? $_G['cookie']['referer_aljpay'] : $_G['siteurl'].'plugin.php?id=aljpay',
		);
		$url = $qbapi->createUrl($aljqb_params);
		$tips = array('status'=>0,'message'=>'0','url'=>$url);
		echo json_encode(ajaxPostCharSet_aljpay($tips));
		exit;
	}
}else{
	include template('aljpay:recharge');
}

function getorderid(){
	$orderid = 'aljpay'.random(7).dgmdate(TIMESTAMP, 'His');
	$check = C::t('#aljpay#aljpay_order') -> fetch($orderid);
	while($check){
		getorderid();
	}
	return $orderid;
}
function createorder($orderparams){
	C::t('#aljpay#aljpay_order') -> insert($orderparams);
	$order = DB::fetch_first('select * from %t where orderid=%s',array('aljpay_order',$orderparams['orderid']));
	if($order) {
		return true;
	}else {
		return false;
	}
	
}
function ajaxPostCharSet_aljpay($arr) {
	if(is_array($arr)){
		if (strtolower(CHARSET) == 'gbk') {
			foreach ($arr as $key => $val) {
				if(is_array($val)){
					$pt_goods[$key] = ajaxPostCharSet_aljpay($val);
				}else{
					$pt_goods[$key] = diconv($val,'gbk','utf-8');
				}

			}
			return $pt_goods;
		}
		return $arr;
	} else {
		if (strtolower(CHARSET) == 'gbk') {
			return diconv($arr,'gbk','utf-8');
		}
		return $arr;
	}
}
function u_g_CharSet_aljlogin($arr) {
    if(is_array($arr)){
        if (strtolower(CHARSET) == 'gbk') {
            foreach ($arr as $key => $val) {
                if(is_array($val)){
                    $pt_goods[$key] = u_g_CharSet_aljlogin($val);
                }else{
                    $pt_goods[$key] = diconv($val,'utf-8','gbk');
                }

            }
            return $pt_goods;
        }
        return $arr;
    } else {
        if (strtolower(CHARSET) == 'gbk') {
            return diconv($arr,'utf-8','gbk');
        }
        return $arr;
    }
}
//From: Dism��taobao��com
?>	