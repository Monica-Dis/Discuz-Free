<?php

/*
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ��ϵDISM.TAOBAO.COM
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}



//updatemembercount(1, array(1 => 10), true, '', 1,'','������Ϣ','������Ϣ���Ļ���');
if(is_file('source/plugin/aljad/aljad.inc.php')) {
	$is_aljad = true;
}else {
	$is_aljad = false;
}
foreach(DB::fetch_all('select * from %t',array('common_plugin')) as $cpv){
    $cparray[$cpv['identifier']] = $cpv;
}
$httpurl = $_G{'setting'}['siteurl'];
$pluginid='aljtc';
$act = $_GET['act'];
$typeid = intval($_GET['typeid']);
$sid = intval($_GET['sid']);
$aljtc_seo = dunserialize($_G['setting']['aljtc_seo']);
if(!$_G['mobile'] && !$_GET['adminedit'] && !$_GET['inajax'] && !$_G['cache']['plugin']['aljtc']['pc_look_mobile']) {
	include template($pluginid.':aljtc_index');
	exit;
}
require_once 'source/plugin/aljhtx/class/class_page.php';
//���ù�����
require_once 'source/plugin/aljhtx/class/class_aljhtx.php';

$price_unit = '&#65509;';
//$load_key = 'aljtc_my_tongji_'.$_G['uid'];//�ҵ�ҳ��ͳ�����ݻ��� KEY


$_COOKIE['changecitystate'] = $_COOKIE['changecitystate']?intval($_COOKIE['changecitystate']):0;

$_GET=dhtmlspecialchars($_GET);
$login_callback = 'member.php?mod=logging&action=login&referer=plugin.php?id='.$pluginid.'%26act='.$_GET['act'];
require_once libfile('function/discuzcode');
include_once 'source/function/function_misc.php';
$actarray = array('user','post','member','hide_l_list','attes');
if(in_array($_GET['act'],$actarray)){
	if(!$_G['uid']){
		dheader("location:".$login_callback);
		exit;
	}
}

require_once 'source/plugin/aljtc/include/common.php';
if($_G['cache']['plugin']['aljtcc']){
    $card_user = DB::fetch_first('select * from %t where uid=%d and end_time>%d and card_id=2',array('aljtcc_card_user',$_G['uid'],TIMESTAMP));
    $card_info = DB::fetch_first('select * from %t where id=%d ',array('aljtcc_card',2));
}

//�����ѡ�񿪹ز�����ȥcookie
if(!$settings['is_more_city']['value'] || $_G['cache']['plugin']['aljtfz']['site_show']){

    GsetCookie("subrid", 0, time()+2592000);
    GsetCookie("rname", 0, time()+2592000);
    GsetCookie('changecitystate',0,time()+31536000);
}
if($settings['domainname']['value'] && !$_COOKIE['subrid'] && !$_COOKIE['rname']) {
	$domainname = explode ("\n", str_replace ("\r", "", $settings['domainname']['value']));
	foreach($domainname as $tmp_key => $tmp_value) {
		$domainname[$tmp_key] = explode('|',$tmp_value);
	}
	foreach($domainname as $tmp_key => $tmp_value) {
		if($tmp_value[2] == $_SERVER['HTTP_HOST']) {;
			$nowregion = DB::fetch_first('select * from %t where subject=%s',array($pluginid.'_region',$tmp_value[1]));
			if(!empty($nowregion)) {
				GsetCookie("subrid", $nowregion['id'], time()+2592000);
				GsetCookie("rname", $nowregion['subject'], time()+2592000);
			}
		}
	}
}

//����
$settings['shengming']['value'] = htmlspecialchars_decode(str_replace ("{sitename}", $_G['setting']['bbname'], $settings['shengming']['value']));
//��������
$pos_all = C::t('#aljtc#'.$pluginid.'_position')->fetch_all_range();
foreach($pos_all as $tmp_key => $tmp_value) {
	$tmp_pos[$tmp_value['id']] = $tmp_value;
}
$pos_all = $tmp_pos;
$lid = intval($_GET['lid']);
if($settings['image_path']['value']){
	$image_path = $settings['image_path']['value'];
}else{
	$image_path = 'source/plugin/'.$pluginid.'/images/logo/';
}
//�ö��ײ�
$top_tz = explode ("\n", str_replace ("\r", "", $settings['top_tz']['value']));
foreach($top_tz as $tmp_key => $tmp_value) {
	$arr = explode('=',$tmp_value);
	$top_tz_arr[$arr[0]]=array(
        'title' =>  '&#32622;&#39030;'.$arr[0].'&#22825;&#65292;&#28040;&#32791;'.$arr[1].$_G[setting][extcredits][$settings[topextcredit][value]][title],
        'day' => $arr[0],
        'num'   => $arr[1],
    );
}
if($_GET['act'] == 'post' || $_GET['act'] == 'edit'){
	$refererurl = ltrim('plugin.php?'.$_SERVER['QUERY_STRING'],'/');
	$referer_url = '&referer='.urlencode($refererurl);
	dsetcookie('referer_aljtc', $refererurl,'600');
}else if($_G['cookie']['referer_aljtc']){
	$referer_url = '&referer='.urlencode($_G['cookie']['referer_aljtc']);
	
}
//���ֳ�ֵ����
if($settings['mobile_integral_recharge']['value']){
	$mobile_integral_recharge = htmlspecialchars_decode($settings['mobile_integral_recharge']['value']).$referer_url;
}

$company = '&#20803;';

//��̨ajax
if($act == 'delimg') {//��̨ɾ��ͼƬ
	$queryData = DB::fetch_first('select * from %t where id=%d',array($pluginid.'_position',$_GET['imgid']));
	if($queryData) {
		unlink($querData['logo']);
		if (DB::update($pluginid.'_position', array('logo' => ''),array('id'=> $_GET['imgid']))){
			echo 1;
		}else {
			echo 0;
		}
		exit;
	}
}else if($act == 'echo_imgsrc'){
	$array = array('code'=>1);

	if($_GET['base']){
		$array['src'] = T::saveimg($_GET['base'],$image_path);
		echo json_encode(aljhtx::ajaxPostCharSet($array));
	}else{
		$array['tips'] = 0;
		$array['tips'] = lang('plugin/aljtc','aljtc_137');
		echo json_encode(aljhtx::ajaxPostCharSet($array));
	}
	exit;
}else if($act == 'myorder'){
	if($_GET['ajax'] == 'yes'){
		
	}else{
		include template($pluginid.':A_Model/my/myorder');
	}
}else if($act == 'logout'){
	if($_GET['formhash'] == formhash()){
		require libfile('function/member');
		clearcookies();
		$_G['groupid'] = $_G['member']['groupid'] = 7;
		$_G['uid'] = $_G['member']['uid'] = 0;
		$_G['username'] = $_G['member']['username'] = $_G['member']['password'] = '';
		$_G['setting']['styleid'] = $_G['setting'];
		echo '1';
		exit;
	}else{
		echo '0';
		exit;
	}
}else if($act == 'mini'){
	if($_G['cache']['plugin']['aljtwx']['wx_url']){
		$miniurl = $_G['cache']['plugin']['aljtwx']['wx_url'];
	}else{
		$miniurl = 'plugin.php?id=aljtc&mobile=2';
	}
	dheader("location: ".$miniurl);
	exit;
}else if($act == 'sh_mini'){
	if($_G['cache']['plugin']['aljtwx']['wx_url']){
		$miniurl = $_G['cache']['plugin']['aljtwx']['wx_url'];
	}else{
		$miniurl = 'plugin.php?id=aljtc&mobile=2';
	}
	dheader("location: ".$miniurl);
	exit;
}else if($act == 'administrators'){
	if($_G['groupid'] != 1){
		echo "<script>alert('".lang('plugin/aljtc','aljtc_111')."');window.history.go(-1);</script>";
		exit;
	}
	$aljtccounts = DB::result_first('select count(*) from %t ',array('aljtc'));
	$dsaljtcnum = DB::result_first('select count(*) from %t where state=1 ',array('aljtc'));
    
	$attesnum=C::t('#'.$pluginid.'#'.$pluginid.'_attestation')->fetch_uid_type();
	$dsattesnum=C::t('#'.$pluginid.'#'.$pluginid.'_attestation')->count_by_status(0);

	if($_G['cache']['plugin']['aljtsq']){
		$aljtsq_count = C::t('#aljtsq#aljtsq_store')->count_by_where(array());
		$aljtsq_ds_count = C::t('#aljtsq#aljtsq_store')->count_by_where(array('status'=>99));
	}
	if($_G['cache']['plugin']['aljwm']){
		$aljwm_goods_count = C::t('#aljtsq#aljbd_goods')->count_by_uid_bid($uid, $tc_bd['bid'], 0, $_GET['kw'],$_GET['sh_status'],array(
			'store_id'=>0,
			'commodity_type'=>4
		));
		$aljwm_count = DB::result_first('select count(*) from %t where 1 and pid = 0 and order_type=3',array('aljbd_goods_order'));
	}
	if($_G['cache']['plugin']['aljtyh']){
		$aljtyh_count = C::t('#aljtyh#aljbd_consume')->count_by_uid_bid($uid, $bid, '', '', $_GET['kw'], 0,$_GET['status'],array('all'=>1));
		$aljtyh_ds_count = C::t('#aljtyh#aljbd_consume')->count_by_uid_bid($uid, $bid, '', '', $_GET['kw'], 0,1);
	}
	if($_G['cache']['plugin']['aljhhr']){
		$aljhhr_count = DB::result_first('select count(*) from %t ',array('aljhhr_shop'));
		$aljhhr_ds_count = DB::result_first('select count(*) from %t where status=0 ',array('aljhhr_shop'));
		$aljhhr_cash_count = DB::result_first('select count(*) from %t ',array('aljhhr_cashorder'));
		$aljhhr_cash_ds_count = DB::result_first('select count(*) from %t where status=0 ',array('aljhhr_cashorder'));
	}
	if($_G['cache']['plugin']['aljthd']){
		$aljthd_count = DB::result_first('select count(*) from %t ',array('aljthd'));
		$aljthd_ds_count = DB::result_first('select count(*) from %t where status = 1',array('aljthd'));
	}
	if($_G['cache']['plugin']['aljtjd']){
		$aljtjd_count = DB::result_first('select count(*) from %t ',array('aljtjd_user'));
		$aljtjd_ds_count = DB::result_first('select count(*) from %t where status=0 ',array('aljtjd_user'));
		$aljtjd_cash_count = DB::result_first('select count(*) from %t ',array('aljtjd_cashorder'));
		$aljtjd_cash_ds_count = DB::result_first('select count(*) from %t where status=0 ',array('aljtjd_cashorder'));
	}
	$navtitle = lang('plugin/aljtc','aljtc_125');
	include template($pluginid.':A_Model/my/administrators');
}else if($act == 'atteslist'){
	if($_G['groupid'] != 1 && !$my_city){
		echo "<script>alert('".lang('plugin/aljtc','aljtc_111')."');window.history.go(-1);</script>";
		exit;
	}
	if($_GET['do'] == 'ajax'){
		$currpage=$_GET['page']?$_GET['page']:1;
		$perpage=10;
		
		$start=($currpage-1)*$perpage;
		if($my_city){
			$fz_id = $my_city['id'];
		}
		$teamList=C::t('#'.$pluginid.'#'.$pluginid.'_attestation')->fetch_all_by_status($_GET['status'],$start,$perpage,$fz_id);
		foreach ($teamList as $teamk => $teamv) {
			if($teamv['type'] == '1'){
				$teamList[$teamk]['typetext'] = lang('plugin/aljtc','aljtc_109');
			} else {
				$teamList[$teamk]['typetext'] = lang('plugin/aljtc','aljtc_110');
			}
			$teamList[$teamk]['userpic'] = avatar($teamv['uid'],'middle','true');

			$teamList[$teamk]['timestamp'] = dgmdate($teamv['timestamp'],'u');
			
			if($teamv['sign'] == 1){
				$teamList[$teamk]['statustext'] = lang('plugin/aljtc','aljtc_112');
			}else if($teamv['sign'] == 2){
				$teamList[$teamk]['statustext'] = lang('plugin/aljtc','aljtc_113');
			}else{
				$teamList[$teamk]['statustext'] = lang('plugin/aljtc','aljtc_114');
			}
		}
		if($teamList){
			echo json_encode(T::ajaxPostCharSet($teamList));
		}else{
			echo '1';
		}
		exit;
	}
	$navtitle = lang('plugin/aljtc','aljtc_115');
	if($my_city){
		$navtitle .= ' - '.$my_city['name'];
	}
	include template($pluginid.':A_Model/my/atteslist');
}else if($act == 'attesstatus'){
	if($_GET['formhash'] == FORMHASH) {
        if($_G['groupid'] != 1 && !$my_city){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang('plugin/aljtc','aljtc_116'))));
            exit;
        }
        if(!$_GET[cashid]){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang('plugin/aljtc','aljtc_117'))));
            exit;
        }

		$goods = DB::fetch_first('select * from %t where id=%d',array($pluginid.'_attestation',$_GET[cashid]));
        if(!$goods){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang('plugin/aljtc','aljtc_118'))));
            exit;
        }
		if($my_city && $my_city['id'] != $goods['fz_id']){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang('plugin/aljtc','aljtc_116'))));
            exit;
        }
        if(strtolower(CHARSET) == 'gbk' && !$_G[mobile] && $_GET[message]){
            $_GET[message] = diconv($_GET[message],'utf-8','gbk');
        }
		
        if(DB::query('update %t set sign=%d,reason=%s  where id = %d and sign = %d',array($pluginid.'_attestation',$_GET[status],$_GET[message],$_GET[cashid],$goods['sign']))){
			if($goods[type] == 1){
				$tourl = 'plugin.php?id=aljtc&act=attes';
			}else{
				$tourl = 'plugin.php?id=aljtc&act=attes&form=gongsi';
			}
            if($_GET[status] == 2){
                $send_goods_tips = lang('plugin/aljtc','aljtc_119').'{reason}'.'<a href="'.$tourl.'">'.lang('plugin/aljtc','aljtc_120').'</a>';
            }else{
                $send_goods_tips = lang('plugin/aljtc','aljtc_121').'{reason}'.'<a href="'.$tourl.'">'.lang('plugin/aljtc','aljtc_120').'</a>';
            }
            $reason = $_GET[message] ? lang('plugin/aljtc','aljtc_122').$_GET[message] : '';
            notification_add(
                $goods['uid'],
                'system',str_replace(array('{reason}'),array($reason), $send_goods_tips),
                array('from_idtype'  => 'aljtc','from_id' => $goods['id'])
            );
            echo json_encode(T::ajaxPostCharSet(array('code'=>1,'text'=>lang('plugin/aljtc','aljtc_123'))));
            exit;
        }else{
			
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang('plugin/aljtc','aljtc_124'))));
            exit;
        }
    }else{
        echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang('plugin/aljtc','aljtc_124'))));
        exit;
    }
}else if($act == 'upimg') {//��̨�ϴ�ͼƬ
	$fn = (isset($_GET['base64']) ? $_GET['base64'] : false);
	$queryData = DB::fetch_first('select * from %t where id=%d',array($pluginid.'_position',$_GET['imgid']));
	unlink($querData['logo']);
	$rand = rand(100, 999);
	$pics = date("YmdHis") . $rand . '.jpg';
	$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
	if (!is_dir($img_dir)) {
		mkdir($img_dir);
	}
	$pic = $img_dir . $pics;
	file_put_contents($pic,file_get_contents($fn));
	if(DB::update($pluginid.'_position',array('logo'=>$pic),array('id'=>$_GET['imgid']))) {
		echo 1;
	}else {
		echo 0;
	}
	exit;
}else if($act == 'openstate') {//��̨����
	$custom_id = intval($_GET['custom_id']);
	$querydata = DB::fetch_first('select * from %t where custom_id=%d',array($pluginid.'_custom',$custom_id));
	if(DB::update($pluginid.'_custom',array('custom_state' => !$querydata['custom_state']),array('custom_id'=> $custom_id))) {
		echo 1;
	}else {
		echo 0;
	}
}else if($act == 'saveregion') {//�������

	if($_GET['cancel'] == 'yes') {
		GsetCookie("subrid", 0, time()+2592000);
		GsetCookie("rname", 0, time()+2592000);
		GsetCookie('changecitystate',0,time()+31536000);
		echo 1;
		exit;
	}else{
		GsetCookie("subrid", $_GET['rid'], time()+2592000);
		GsetCookie("rname", $_GET['rname'], time()+2592000);
		echo 1;
		exit;
	}

}else if($_GET['act'] == 'user'){//�û��б�
	if($_G['cache']['plugin']['aljtc']['is_mytc_to_mysc']){
		header('Location: plugin.php?id=aljbdx&act=user');
		exit;
	}
	//�ҵ�ͳ��
	loadcache('aljtc_my_tongji', 1);
	if(empty($_G['cookie']['aljtc_my_tongji']) || !$_G['cache']['aljtc_my_tongji'][$_G['uid']]) {
		$viewnum = DB::result_first('select sum(views) from %t where uid = %d',array($pluginid,$_G['uid']));
		$issuenum = DB::result_first('select count(*) from %t where uid = %d',array($pluginid,$_G['uid']));
		$collectionnum = DB::result_first('select count(*) from %t where uid=%d',array($pluginid.'_collection',$_G['uid']));
		savecache('aljtc_my_tongji', array($_G['uid']=>array('viewnum'=>$viewnum,'issuenum'=>$issuenum,'collectionnum'=>$collectionnum)));
		dsetcookie('aljtc_my_tongji', 1, 43200);
	}else{
		$viewnum = $_G['cache']['aljtc_my_tongji'][$_G['uid']]['viewnum'];
		$issuenum = $_G['cache']['aljtc_my_tongji'][$_G['uid']]['issuenum'];
		$collectionnum = $_G['cache']['aljtc_my_tongji'][$_G['uid']]['collectionnum'];
	}
	//�ҵĹ����Զ���
    $mobile_user_my_tools = explode ("\n", str_replace ("\r", "", $settings['mobile_user_my_tools']['value']));
    foreach($mobile_user_my_tools as $key=>$value){
        $arr=explode('|',$value);
        $mobile_user_my_tools_arr[]=$arr;
    }
    $navtitle = '&#25105;&#30340;'.'-'.$settings['daohang']['value'];
	$description = $settings['description']['value'];
	//ƽ̨����
	
	$mobile_user_gg_text = explode ("\n", str_replace ("\r", "", $settings ['mobile_user_gg_text']['value']));
    foreach($mobile_user_gg_text as $key=>$value){
        $arr=explode('|',$value);
        $mobile_user_gg_text_types[]=$arr;
	}
	if($_G['cache']['plugin']['aljtsq']){
    	$staff = DB::fetch_first('select * from %t where st_type=%d and st_uid=%d',array('aljtsq_staff',2,$_G['uid']));
	}
	$metakeywords = $settings['daohang']['value'];
	if($aljtc_seo['my']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljtc_seo['my']);
	}
	include template($pluginid.':A_Model/my/user');
}else if($_GET['act'] == 'search'){
	$navtitle = lang('plugin/aljtc','aljtc_133');
	$description = $settings['description']['value'];
	$metakeywords = $settings['daohang']['value'];
	if($aljtc_seo['search']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljtc_seo['search']);
	}
	include template($pluginid.':A_Model/search');
}else if($_GET['act'] == 'getaddress') {//��ȡ�ٶ�api��λ
	
		$Browser_Tencent_map_key = $_G['cache']['plugin']['aljhtx']['Browser_Tencent_map_key'] ? $_G['cache']['plugin']['aljhtx']['Browser_Tencent_map_key'] : 'SA5BZ-HX46G-3CFQP-IY4TP-KKMU7-MLBGO';
		$url='https://apis.map.qq.com/ws/geocoder/v1/?location='.$_GET['latitude'].','.$_GET['longitude'].'&key='.$Browser_Tencent_map_key.'&output=json';
		$json = file_get_contents($url);
		$arr = json_decode($json,true);
		$arr = ajaxGetCharSet_aljtc($arr);
		
		$array = array();
		$array['code'] = 1;
		if($settings['citymod']['value']){
			$city = $arr['result']['address_component']['district'];
			$array['message'] = lang('plugin/aljtc','aljtc_50').$arr['result']['address_component']['city'].$city.lang('plugin/aljtc','aljtc_51');
		}else{
			$city = $arr['result']['address_component']['city'];
			$array['message'] = lang('plugin/aljtc','aljtc_50').$city.lang('plugin/aljtc','aljtc_51');
		}
		if(!$arr['status']) {
			if($city != $_COOKIE['rname']) {
				$nowposition = DB::fetch_first('select * from %t where subject like %s',array($pluginid.'_region','%'.addcslashes($city, '%_').'%'));
				if(!empty($nowposition)) {
					$array['code'] = 0;
					if($settings['citymod']['value']) {
						$array['message'] = lang('plugin/aljtc','aljtc_50').$arr['result']['address_component']['city'].$city.lang('plugin/aljtc','aljtc_52');
					}else{
						$array['message'] = lang('plugin/aljtc','aljtc_50').$city.lang('plugin/aljtc','aljtc_53');
					}
					$array['city'] = $nowposition['subject'];
					$array['cityid'] = $nowposition['id'];
					$_COOKIE['changecitystate'] = 1;
					setcookie('changecitystate',1,time()+31536000);

				}
			}
		}
		echo json_encode(ajaxPostCharSet_aljtc($array));
		exit;
	
}else if($_GET['act'] == 'mobile_index_goods'){//��ҳ���б���Ϣ
	$con = 'where 1 and state=0';
	$where[] = $pluginid;
	if ($_GET['zufangtype']>0) {
		$con .= " and zufangtype = %d";
		$where[] = $_GET['zufangtype'];
	}
	if ($_GET['subtype']) {
		$con .= " and subtype = %d";
		$where[] = $_GET['subtype'];
	}
	if ($_GET['subsubtype']) {
		$con .= " and subsubtype = %d";
		$where[] = $_GET['subsubtype'];
	}
	if ($_GET['uid']) {
		$con .= " and uid = %d";
		$where[] = $_GET['uid'];
	}
	
	if($_GET['fz_id'] && !$_GET['rid'] && !$_GET['subrid'] && !$_GET['subsubrid']){
		
		if($_GET['fz_subrid'] > 0){
			$con .= ' and (fz_id = %d or region1=%d)';
			$where[] = $_GET['fz_id'];
			$where[] = $_GET['fz_subrid'];
		}else if ($_GET['fz_rid'] > 0) {
			$con .= ' and (fz_id = %d or region=%d)';
			$where[] = $_GET['fz_id'];
			$where[] = $_GET['fz_rid'];
		}else{
			$con .= ' and fz_id = %d ';
			$where[] = $_GET['fz_id'];
		}
	}
	
	if($_GET['rid']){
		$rid = intval($_GET['rid']);
		$con .= ' and region = %d';
		$where[] = $rid;
	}
	if($_GET['subrid']){
		$subrid = intval($_GET['subrid']);
		$con .= ' and region1 = %d';
		$where[] = $subrid;
	}
	if($_GET['subsubrid']){
		$subsubrid = intval($_GET['subsubrid']);
		$con .= ' and region2 = %d';
		$where[] = $subsubrid;
	}
	if($_GET['search']){
		$search = '%'.addcslashes($_GET['search'], '%_').'%';
		$con.= " and (title like %s or content like %s)";
		$where[] = $search;
    	$where[] = $search;
	}
	$num = DB::result_first('select count(*) from %t '.$con,$where);
	$field = "*";
	if($_GET['order'] == 'new') {
		$con.= ' order by solve asc,topetime desc,updatetime desc';
	}else if($_GET['order'] == 'hot') {
		$con.= ' order by solve asc,topetime desc,views desc';
	}else if($_GET['order'] == 'notfinish') {
		$con .= ' and solve = %d order by topetime desc,updatetime desc,addtime desc';
		$where[] = 0;
	}else if(($_GET['order'] == 'lbs' || $_GET['zufangtype'] == "lbs") && $_G['cache']['plugin']['aljtsq']){
		//x ���� y γ��
		$latitude    = getcookie('aljtsq_latitude')?getcookie('aljtsq_latitude'):0;//γ��
		$longitude   = getcookie('aljtsq_longitude')?getcookie('aljtsq_longitude'):0;//����
		$lngstr = $longitude > 0 ? " - $longitude" : " + ".abs($longitude);
		$field = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $latitude) * 0.01745329252)) * 6371004 as distance";
		$con.= ' order by distance ASC,solve asc,topetime desc,views desc';
	}else {
		$con.= ' order by solve asc,topetime desc,updatetime desc,addtime desc';
	}
	
	$currpage=$_GET['page']?$_GET['page']:1;
	$perpage=6;
	$start=($currpage-1)*$perpage;
	$max = ceil($num/$perpage);
	$where[] = $start;
	$where[] = $perpage;
	$_GET['getact'] = 'list';
	$goodslist = DB::fetch_all('select '.$field.' from %t '.$con.' limit %d,%d',$where);
	
	if($goodslist){
        $customlist = DB::fetch_all('select * from %t ',array($pluginid.'_custom'));
        foreach($customlist as $ck => $cv){
            $customlist[$cv['custom_id']] = $cv;
		}
		$lids = array();
        foreach($goodslist as $gk => $gv){
            $newarray = unserialize($gv['form']);
            foreach($newarray as $tmp_key => $tmp_value) {
                $newarrayt[$customlist[$tmp_key]['custom_title']] = $tmp_value;
            }
            $goodslist[$gk]['formlist'] = $newarrayt;
			unset($newarrayt);
			$goodslist[$gk]['praiseCount'] = DB::result_first('select count(*) from %t where lid=%d',array('aljtc_praise',$gv['id']));
			if($goodslist[$gk]['praiseCount']>0){
				$goodslist[$gk]['praise'] = DB::fetch_all('select * from %t where lid=%d order by id desc limit 0,5',array('aljtc_praise',$gv['id']));
			}
			if($_G['cache']['plugin']['aljtc']['is_reply']){
				$goodslist[$gk]['commentCount'] = DB::result_first('select count(*) from %t where lid=%d and status=0',array('aljtc_comment',$gv['id']));
				if($goodslist[$gk]['commentCount']>0){
					$goodslist[$gk]['comment'] = DB::fetch_all('select * from %t where lid=%d and status=0 order by id desc limit 0,5',array('aljtc_comment',$gv['id']));
				}
			}
			if(($_GET['order'] == 'lbs' || $_GET['zufangtype'] == "lbs") && $_G['cache']['plugin']['aljtsq']){
				$distance = intval($gv['distance']);
				if($distance<=1000){
					$distance = intval($distance). 'm';
				}else if($distance>1000){
					$distance = round($distance/1000, 1). 'km';
				}
				$goodslist[$gk]['distance'] = $distance;
				unset($distance);
			}
			if(TIMESTAMP>$gv['topetime']&&$gv['topetime']){
				DB::update('aljtc',array('topstime'=>'','topetime'=>''),'id='.$gv[id]);
			}
			if(TIMESTAMP>$gv['expiry_time']&&$gv['expiry_time']){
				DB::update('aljtc',array('solve'=>'1'),'id='.$gv[id]);
			}
			$lids[] = $gv[id];
			$uids[] = $gv[uid];
			$goodslist[$gk]['grrz'] = DB::result_first("select count(*) from %t where uid= %d and sign=1 and type=1",array($pluginid.'_attestation',$gv['uid']));
			$goodslist[$gk]['qyrz'] = DB::result_first("select count(*) from %t where uid= %d and sign=1 and type=2",array($pluginid.'_attestation',$gv['uid']));
			$formsetting = type_settins($gv['zufangtype'],$gv['subtype'],$gv[id]);
			$goodslist[$gk]['open_tel_price'] = $formsetting['formsetting']['open_tel_price'];
			$goodslist[$gk]['is_see_tel'] = $formsetting['is_see_tel'];
			unset($formsetting);
		}
		
		if($lids && count($lids)>0){
			$num = 1;
			if($_G['cache']['plugin']['aljtc']['views_times']>0){
				$num = $_G['cache']['plugin']['aljtc']['views_times'] * $num;
			}
			DB::query("update %t set views=views+%d WHERE id IN (%n)", array('aljtc', $num, $lids));
		}
		include template($pluginid.':A_Model/my/infomanage');
	}else{
		echo 1;
	}

}else if ($_GET['act'] == 'mgetregion') {//����ҳ�������������
    if ($_GET['upid']) {
        $rs = DB::fetch_all('select * from %t where upid=%d',array($pluginid.'_region',$_GET['upid']));
	}
	$op=intval($_GET['op']);
	if($_GET['adminedit'] == 'yes') {
		include template($pluginid.':admin/getregion');
	}else {
		include template($pluginid.':A_Model/post/getregion');
	}

}else if($_GET['act'] == 'mobile_list_region'){//�б�ҳ��ȡ����
	if($_GET['rid']){
		$rlist=DB::fetch_all('select * from %t where upid=%d',array($pluginid.'_region',$_GET['rid']));
	}
	if($_GET['getjson'] == 'yes') {
		echo json_encode(ajaxPostCharSet_aljtc($rlist));
		exit;
	}
	$geturl = array(
		'id' => $pluginid,
		'act' => 'list',
		'search' => $_GET['search'],
		'subsubrid' => $_GET['subsubrid'],
		'pay1' => $_GET['pay1'],
		'pay2' => $_GET['pay2'],
		'wanted' => $_GET['wanted'],
		'zufangtype' => $_GET['zufangtype'],
		'subtype' => $_GET['subtype'],
		'subsubtype' => $_GET['subsubtype'],
		'solve' => $_GET['solve'],
		'view' => $_GET['view'],
		'new' => $_GET['new'],
		'pic' => $_GET['pic'],
		'order'=> $_GET['order'],
	);
	if($_GET['sub']){
		$geturl['rid'] = $_GET['subrid'];
		$geturl['subrid'] = $_GET['rid'];
		include template($pluginid.':A_Model/mobile_list_subregion');
	}else{
		$geturl['rid'] = $_GET['rid'];
		$geturl['subrid'] = $_GET['subrid'];
		include template($pluginid.':A_Model/mobile_list_region');
	}
}else if ($_GET['act'] == 'mobile_list_type') {//�б�ҳ��ȡ����
    if ($_GET['zufangtype']) {
        $rs = C::t('#aljtc#'.$pluginid.'_position')->fetch_all_by_upid($_GET['zufangtype']);
    }
	$geturl = array(
		'id' => $pluginid,
		'act' => 'list',
		'search' => $_GET['search'],
		'rid' => $_GET['subrid'],
		'subrid' => $_GET['rid'],
		'subsubrid' => $_GET['subsubrid'],
		'pay1' => $_GET['pay1'],
		'pay2' => $_GET['pay2'],
		'wanted' => $_GET['wanted'],
		'subsubtype' => $_GET['subsubtype'],
		'solve' => $_GET['solve'],
		'view' => $_GET['view'],
		'new' => $_GET['new'],
		'pic' => $_GET['pic'],
		'order' => $_GET['order'],
	);
    if($_GET['sub']){
		$geturl['zufangtype'] = $_GET['subtype'];
		$geturl['subtype'] = $_GET['zufangtype'];
		include template($pluginid.':A_Model/mobile_list_subtype');
	}else{
		$geturl['zufangtype'] = $_GET['zufangtype'];
		$geturl['subtype'] = $_GET['subtype'];
		include template($pluginid.':A_Model/mobile_list_type');
	}
}else if ($_GET['act'] == 'getpos') {//����ҳ��ȡ����
    if ($_GET['rid']) {
        $rs = C::t('#'.$pluginid.'#'.$pluginid.'_position')->fetch_all_by_upid_1($_GET['rid']);
	}
	
	if(!empty($rs)) {
		
		echo json_encode(ajaxPostCharSet_aljtc($rs));
		exit;
	}else {
		echo json_encode(ajaxPostCharSet_aljtc(array('code'=>400)));
		exit;
	}


}else if($_GET['act'] == 'solve'){//���
	if($_GET['getdata'] == 'yes') {
		$solve = DB::result_first('select solve from %t where id=%d',array($pluginid,$_GET['lid']));
        if($solve == 0) {
            C::t('#'.$pluginid.'#'.$pluginid)->update($_GET['lid'], array('solve'=>'1'));
        }else{
            C::t('#'.$pluginid.'#'.$pluginid)->update($_GET['lid'], array('solve'=>'0'));
        }
        $data['code'] = 200;
        $data['msg'] = lang('plugin/aljtc','aljtc_54');
        $data['url'] = 1;
        echo json_encode(ajaxPostCharSet_aljtc($data));
        exit;
	}
}else if($_GET['act'] == 'sh_mes'){//�����Ϣ
	$lp = C::t('#'.$pluginid.'#'.$pluginid)->fetch($_GET['lid']);
	
	if($_GET['getdata'] == 'yes' && ($_G['groupid'] == 1 || $my_city['id']==$lp['fz_id']) && $_GET['lid']) {
		
		DB::update('aljtc',array('state'=>0),array('id'=>$_GET['lid']));
        $data['code'] = 200;
        $data['msg'] = lang('plugin/aljtc','aljtc_54');
        $data['url'] = 1;
        
	}else{
		$data['code'] = 100;
        $data['msg'] = lang('plugin/aljtc','aljtc_63');
        $data['url'] = 0;
	}
	echo json_encode(ajaxPostCharSet_aljtc($data));
	exit;
}else if($_GET['act'] == 'collection'){ //ajax�ղأ�ȡ��
	if(!$_G['uid']){
		if($_GET['getdata'] == 'yes') {
			$data['code'] = 300;
			$data['msg'] = lang('plugin/aljtc','aljtc_1');
			$data['url'] = 'member.php?mod=logging&action=login&referer=plugin.php?id=aljtc&act=view&lid='.$_GET['lid'];
			echo json_encode(ajaxPostCharSet_aljtc($data));
			exit;
		}
	}
	dsetcookie('aljtc_my_tongji', 0, -1);
	if (empty($_GET['lid'])) {
		if($_GET['getdata'] == 'yes') {
			$data['code'] = 400;
			$data['msg'] = lang('plugin/aljtc','aljtc_6');
			$data['url'] = 0;
			echo json_encode(ajaxPostCharSet_aljtc($data));
			exit;
		}
    }
	$list = DB::fetch_first('select * from %t where lid=%d and uid=%d',array($pluginid.'_collection',$_GET['lid'],$_G['uid']));
	if($list) {
		if($_GET['getdata'] == 'yes') {
			DB::delete($pluginid.'_collection',array('id'=>$list['id']));
			$data['code'] = 200;
			$data['msg'] = lang('plugin/aljtc','aljtc_86');
			$data['url'] = 0;
			echo json_encode(ajaxPostCharSet_aljtc($data));
			exit;
		}
	}else {
		C::t('#'.$pluginid.'#'.$pluginid.'_collection')->insert(array(
			'lid'=>$_GET['lid'],
			'uid'=>$_G['uid'],
			'dateline'=>TIMESTAMP,
		));
		if($_GET['getdata'] == 'yes') {
			$data['code'] = 200;
			$data['msg'] = lang('plugin/aljtc','The_success_of');
			$data['url'] = 0;
			echo json_encode(ajaxPostCharSet_aljtc($data));
			exit;
		}
	}
}else if($_GET['act'] == 'collection_list'){//�ղ�ҳ��
    $navtitle = lang('plugin/aljtc','aljtc_85').$settings['daohang']['value'];
	$description = $settings['description']['value'];
	$metakeywords = $settings['daohang']['value'];
	if($aljtc_seo['collection']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljtc_seo['collection']);
	}
	include template($pluginid.':A_Model/my/collection_list');
}else if($_GET['act'] == 'mypraise'){//�ҵĵ���
    $navtitle = lang('plugin/aljtc','aljtc_128');
	$description = $settings['description']['value'];
	$metakeywords = $settings['daohang']['value'];
	if($aljtc_seo['mypraise']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljtc_seo['mypraise']);
	}
	include template($pluginid.':A_Model/my/mypraise');
}else if($_GET['act'] == 'myreply'){//�ҵ�����
    $navtitle = lang('plugin/aljtc','aljtc_129');
	$description = $settings['description']['value'];
	$metakeywords = $settings['daohang']['value'];
	if($aljtc_seo['myreply']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljtc_seo['myreply']);
	}
	include template($pluginid.':A_Model/my/myreply');
}else if($_GET['act'] == 'praise'){ //ajax���ޣ�ȡ��
	if(!$_G['uid']){
		if($_GET['getdata'] == 'yes') {
			$data['code'] = 300;
			$data['msg'] = lang('plugin/aljtc','aljtc_1');
			$data['url'] = 'member.php?mod=logging&action=login&referer=plugin.php?id=aljtc&act=view&lid='.$_GET['lid'];
			echo json_encode(ajaxPostCharSet_aljtc($data));
			exit;
		}
	}
	if (empty($_GET['lid'])) {
		if($_GET['getdata'] == 'yes') {
			$data['code'] = 400;
			$data['msg'] = lang('plugin/aljtc','aljtc_6');
			$data['url'] = 0;
			echo json_encode(ajaxPostCharSet_aljtc($data));
			exit;
		}
    }
	$list = DB::fetch_first('select * from %t where lid=%d and uid=%d',array($pluginid.'_praise',$_GET['lid'],$_G['uid']));
	if($list) {
		if($_GET['getdata'] == 'yes') {
			$data['code'] = 100;
			$data['msg'] = lang('plugin/aljtc','aljtc_97');
			$data['url'] = 0;
			echo json_encode(ajaxPostCharSet_aljtc($data));
			exit;
		}
	}else {
		C::t('#'.$pluginid.'#'.$pluginid.'_praise')->insert(array(
			'lid'=>$_GET['lid'],
			'uid'=>$_G['uid'],
			'dateline'=>TIMESTAMP,
		));
		if($_GET['getdata'] == 'yes') {
			$data['code'] = 200;
			$data['msg'] = lang('plugin/aljtc','aljtc_98');
			$data['url'] = 0;
			$data['avatar'] = avatar($_G['uid'], 'middle');
			echo json_encode(ajaxPostCharSet_aljtc($data));
			exit;
		}
	}
}else if($_GET['act'] == 'result'){
	$result_info = array();
	if($_GET['type'] == 'warn'){
		$result_info['icon'] = 'weui-icon-warn';
	}else{
		$result_info['icon'] = 'weui-icon-success';
	}
	$result_info['btn_default'] = array('value' => lang('plugin/aljtc','aljtc_93'), 'url' => 'plugin.php?id=aljtc&act=user');
	if($_GET['post'] == 'attes'){
		$navtitle = lang('plugin/aljtc','aljtc_91');
		$result_info['title'] = lang('plugin/aljtc','aljtc_92');
		$result_info['desc'] = lang('plugin/aljtc','aljtc_43');
		$result_info['btn_primary'] = array('value' => lang('plugin/aljtc','aljtc_94'), 'url' => 'plugin.php?id=aljtc&act=attes');
	}else{
		$navtitle = lang('plugin/aljtc','aljtc_92');
		$result_info['title'] = lang('plugin/aljtc','aljtc_92');
		if(!in_array($_G['groupid'],unserialize($settings['m_groups']['value'])) && $settings['isreview']['value']){
			$result_info['desc'] = lang('plugin/aljtc','To_examine');
		}else{
			$result_info['desc'] = lang('plugin/aljtc','aljtc_4');
		}
		$result_info['btn_primary'] = array('value' => lang('plugin/aljtc','aljtc_94'), 'url' => 'plugin.php?id=aljtc&act=view&lid='.$_GET['lid']);
		$result_info['btn_default'] = array('value' => lang('plugin/aljtc','aljtc_95'), 'url' => 'plugin.php?id=aljtc&act=member');
	}
	
	include template('aljhtx:tc_result');
	exit;
}else if($_GET['act'] == 'attes'){//��֤
	if($_GET['adminedit'] == 'yes' && $_GET['uid'] && $admin_status){
		$_G['uid'] = $_GET['uid'];
	}
	
	if (submitcheck('formhash')) {
		$r_pay = explode('|', $settings['r_pay']['value']);
		$insertarray = array(
			'username' => $_G['username'],
			'uid' => $_G['uid'],
			'timestamp' => TIMESTAMP,
		);
		if($_GET['pic']){
			if($_GET['pic'] != 'yes') {
				$insertarray['pic'] = T::saveimg($_GET['pic'],$image_path,'aljtc');
			}
		}else{
			$messge = lang('plugin/aljtc','aljtc_84');
			echo "<script>parent.tips('".$messge."','');</script>";
			exit;
		}

		if($_GET['form'] == 'shenfen') {//������֤
			$rz2 = DB::fetch_all('select * from %t where uid=%d and type=%d',array($pluginid.'_attestation',$_G['uid'],2));
			if($rz2){
				DB::delete($pluginid.'_attestation', array('id'=>$rz2['id']));
			}
			$insertarray['type'] = 1;
			if($_GET['str_idcard']) {
				$insertarray['num'] = $_GET['str_idcard'];
			}else {
				$messge = lang('plugin/aljtc','aljtc_83');
				echo "<script>parent.tips('".$messge."','');</script>";
				exit;
			}
			if($_GET['adminedit'] == 'yes' && $admin_status){
			}else{
				if($settings['r_ext']['value'] && $r_pay['0']){
					if (getuserprofile('extcredits' . $settings['r_ext']['value']) < $r_pay['0']) {
						$messge = $_G['setting']['extcredits'][$settings['r_ext']['value']]['title'].lang('plugin/aljtc','aljtc_81');
						if($mobile_integral_recharge){
							echo "<script>parent.tips('".$messge."','".$mobile_integral_recharge."');</script>";
						}else{
							echo "<script>parent.tips('".$messge."','');</script>";
						}
						exit;
					}
					updatemembercount($_G['uid'], array($settings['r_ext']['value'] => '-' . $r_pay['0']), true, '', 1,'',lang('plugin/aljtc','aljtc_100'),lang('plugin/aljtc','aljtc_101'));
				}
			}
			
			if(DB::result_first('select count(*) from %t where uid=%d and type=%d',array($pluginid.'_attestation',$_G['uid'],1))){
				
				if($_GET['adminedit'] == 'yes' && $admin_status){
					DB::update($pluginid.'_attestation', $insertarray, array("uid"=>$_G['uid'],'type'=>'1'));
				}else{
					$insertarray['sign'] = 0;
					DB::update($pluginid.'_attestation', $insertarray, array("uid"=>$_G['uid'],'type'=>'1'));
					$groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
					foreach($groupids as $g_uid){
						notification_add($g_uid['uid'], 'system','<a href="plugin.php?id=aljtc&act=member&i=1">'.lang('plugin/aljtc','aljtc_126').'</a>',array('from_idtype'  => $pluginid,'from_id' => $insertid));
					}
				}
			}else{
				$insertarray['fz_id'] = $_GET['fz_id'];
				DB::insert($pluginid.'_attestation',$insertarray);
			}
			
		}else {//��˾��֤
			$rz1 = DB::fetch_all('select * from %t where uid=%d and type=%d',array($pluginid.'_attestation',$_G['uid'],1));
			if($rz1){
				DB::delete($pluginid.'_attestation', array('id'=>$rz1['id']));
			}
			$insertarray['type'] = 2;
			if($_GET['gongsiname'] && $_GET['num']) {
				$insertarray['gongsiname'] = addslashes($_GET['gongsiname']);
				$insertarray['num'] = addslashes($_GET['num']);
			}else {
				$messge = lang('plugin/aljtc','aljtc_82');
				echo "<script>parent.tips('".$messge."','');</script>";
				exit;
			}
			if($_GET['adminedit'] == 'yes' && $admin_status){
			}else{
				if($settings['r_ext']['value'] && $r_pay['1']){
					if (getuserprofile('extcredits' . $settings['r_ext']['value']) < $r_pay['1']) {
						$messge = $_G['setting']['extcredits'][$settings['r_ext']['value']]['title'].lang('plugin/aljtc','aljtc_81');
						if($mobile_integral_recharge){
							echo "<script>parent.tips('".$messge."','".$mobile_integral_recharge."');</script>";
						}else{
							echo "<script>parent.tips('".$messge."','');</script>";
						}
						exit;
					}
					updatemembercount($_G['uid'], array($settings['r_ext']['value'] => '-' . $r_pay['1']), true, '', 1,'',lang('plugin/aljtc','aljtc_100'),lang('plugin/aljtc','aljtc_102'));
				}
			}
			if(DB::result_first('select count(*) from %t where uid=%d and type=%d',array($pluginid.'_attestation',$_G['uid'],2))){
				if($_GET['adminedit'] == 'yes' && $admin_status){
					DB::update($pluginid.'_attestation', $insertarray, array("uid"=>$_G['uid'],'type'=>'2'));
				}else{
					$insertarray['sign'] = 0;
					DB::update($pluginid.'_attestation', $insertarray, array("uid"=>$_G['uid'],'type'=>'2'));
					$groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
					foreach($groupids as $g_uid){
						notification_add($g_uid['uid'], 'system','<a href="plugin.php?id=aljtc&act=member&i=1">'.lang('plugin/aljtc','aljtc_127').'</a>',array('from_idtype'  => $pluginid,'from_id' => $insertid));
					}
				}
			}else{
				$insertarray['fz_id'] = $_GET['fz_id'];
				DB::insert($pluginid.'_attestation',$insertarray);
			}
			
		}
		if($_G['cache']['plugin']['aljtc']['is_result']){
			echo "<script>parent.tips('".lang('plugin/aljtc','aljtc_43')."',function(){parent.location.href='plugin.php?id=aljtc&act=result&post=".$_GET['act']."'});</script>";
		}else{
			echo "<script>parent.tips('".lang('plugin/aljtc','aljtc_43')."',function(){parent.location.href='plugin.php?id=aljtc&act=user'});</script>";
		}
		exit;
	}else {
		$tip = explode ("\n", str_replace ("\r", "", $settings['r_tsy']['value']));
		foreach($tip as $key=>$value){
			$tips.="<p>".$value."</p>'+'";
		}
		$rz1 = DB::fetch_first('select * from %t where uid=%d and type=%d',array($pluginid.'_attestation',$_G['uid'],1));
		$rz2= DB::fetch_first('select * from %t where uid=%d and type=%d',array($pluginid.'_attestation',$_G['uid'],2));
        if($_GET['form'] == 'gongsi'){
			$navtitle = lang('plugin/aljtc','aljtc_110');
		}else{
			$navtitle = lang('plugin/aljtc','aljtc_109');
		}
		$description = $settings['description']['value'];
		$metakeywords = $settings['daohang']['value'];
		if($aljtc_seo['attes']['seotitle']){
			$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
			list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljtc_seo['attes']);
		}
		include template($pluginid.':A_Model/attes/attes');
	}

}else if($_GET['act'] == 'posttype') {
    $tip = explode ("\n", str_replace ("\r", "", $settings['mianzeinfo']['value']));
    foreach($tip as $key=>$value){
        $tips.="<p>".$value."</p>";
    }
	$typelist = C::t('#aljtc#'.$pluginid.'_position')->fetch_all_by_upid(0);
    $navtitle = lang('plugin/aljtc','aljtc_79').$settings['daohang']['value'];
	$description = $settings['description']['value'];
	if($_G['cache']['plugin']['aljbd']){
		$bd = DB::result_first('select count(*) from %t where uid=%d',array('aljbd',$_G['uid']));
	}
	if($_G['cache']['plugin']['aljtsq']){
		//$store = DB::result_first('select count(*) from %t where tc_uid=%d',array('aljtsq_store',$_G['uid']));
	}
	
	$metakeywords = $settings['daohang']['value'];
	if($aljtc_seo['posttype']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljtc_seo['posttype']);
	}
	include template($pluginid.':A_Model/post/posttype');
}else if ($_GET['act'] == 'post') {//����
	require_once 'source/plugin/aljtc/include/post.php';

	if($_COOKIE['subrid']) {
		$subridlist = DB::fetch_first('select * from %t where id=%d',array($pluginid.'_region',$_COOKIE['subrid']));
		$rs = DB::fetch_all('select * from %t where upid=%d',array($pluginid.'_region',$_COOKIE['subrid']));
	}else {
		$rs = DB::fetch_all('select * from %t where upid=%d',array($pluginid.'_region',0));
	}
	
	$lp = DB::fetch_first('SELECT contact,lxr FROM %t WHERE uid=%d ORDER BY id DESC LIMIT 1', array('aljtc',$_G['uid']));
	if($_G['cache']['plugin']['aljbd'] && $settings['is_bd_address']['value']==1){
		$def_address = DB::fetch_first('SELECT fullName as lxr,mobile as contact FROM %t WHERE UID=%d and defaultAddress=1',array('aljbd_address', $_G['uid']));
		if($def_address[lxr]){
			$lp = $def_address;
		}
	}
    if($pos_all[$sid]['name']){
    	$t_name = $pos_all[$sid]['subject'];
	}else{
        $t_name = $pos_all[$typeid]['subject'];
	}
	$navtitle = '&#21457;&#24067;'.$t_name.lang('plugin/aljtc','aljtc_61');
	$description = $settings['description']['value'];
	$metakeywords = $settings['daohang']['value'];
	if($aljtc_seo['post']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'cat'=>$pos_all[$typeid]['subject'],'cat1'=>$pos_all[$sid]['subject']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljtc_seo['post']);
	}
	
	
	include template($pluginid.':A_Model/post/post');
} else if ($_GET['act'] == 'edit') {//�༭
	$rs = DB::fetch_all('select * from %t where upid=%d',array($pluginid.'_region',0));
	$lp = C::t('#'.$pluginid.'#'.$pluginid)->fetch($_GET['lid']);
	if($lp['region1']){
		$subridlist = DB::fetch_first('select * from %t where id=%d',array($pluginid.'_region',$lp['region1']));
	}else if($_COOKIE['subrid']) {
		$subridlist = DB::fetch_first('select * from %t where id=%d',array($pluginid.'_region',$_COOKIE['subrid']));
		
	}
	$lid = intval($_GET['lid']);
	require_once 'source/plugin/aljtc/include/post.php';
    
	if($lp['label']) {
		$lp['label'] = unserialize($lp['label']);
	}
	if($lp['form']) {
		$newarray = unserialize($lp['form']);
		foreach($newarray as $tmp_key => $tmp_value) {
			$lp['form[var]['.$tmp_key.']'] = $tmp_value;
		}
		unset($lp['form']);
	}
    if(!empty($lp['pic'])){
        $lp['pic'] = explode("|", $lp['pic']);
    }
	if($lid){
		$attachments = DB::fetch_all('select * from %t where pid = %d order by aid asc ',array($pluginid.'_attachment',$lid));
		$lp['imglist'] = $attachments;

	}
	if ($lp['region']) {
		$two_area = DB::fetch_all('select * from %t where upid=%d',array('aljtc_region',$lp['region']));
	}
	if ($lp['region1']) {
		$third_area = DB::fetch_all('select * from %t where upid=%d',array('aljtc_region',$lp['region1']));
	}
    $navtitle = lang('plugin/aljtc','aljtc_78').$t_name.lang('plugin/aljtc','aljtc_61');
	if($_GET['adminedit'] == 'yes' && $admin_status){
		$typelist = $pos_all;
		$json_typelist = C::t('#aljtc#aljtc_position')->fetch_all_json();
        $typejson = json_encode($json_typelist);
		$default_type = $typelist[$lp['zufangtype']]['subject'].' '. ($typelist[$lp['subtype']]['subject']?$typelist[$lp['subtype']]['subject']:'--').' '.($typelist[$lp['subsubtype']]['subject']?$typelist[$lp['subsubtype']]['subject']:'--');
	}
	$description = $settings['description']['value'];
	$metakeywords = $settings['daohang']['value'];
	if($aljtc_seo['edit']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljtc_seo['edit']);
	}
	
	include template($pluginid.':A_Model/post/post');
}else if($_GET['act'] == 'friendpost') {//����Ȧģʽ�µķ�����Ϣ���༭��Ϣ����
	$lp = C::t('#'.$pluginid.'#'.$pluginid)->fetch($_GET['lid']);
	require_once 'source/plugin/aljtc/include/post.php';
	if (submitcheck('formhash')) {
		if(!$_GET['lid']) {
			if(!in_array($_G['groupid'],unserialize($settings['lj_groups']['value']))){
				$tip = lang('plugin/aljtc','aljtc_77');
				echo "<script>parent.tips('".$tip."','','error');</script>";
				exit;
			}
			if($settings['is_forum_mobile']['value']){//�ֻ�����д
				$profile = DB::fetch_first('select * from %t where uid=%d',array('common_member_profile',$_G['uid']));
				if(empty($profile['mobile'])){
					$tip = lang('plugin/aljtc','aljtc_76');
					echo "<script>parent.tips('".$tip."','home.php?mod=spacecp&ac=profile&op=contact','error');</script>";
					exit;
				}
			}
			//��֤
			$rz = DB::result_first("select count(*) from ".DB::table($pluginid.'_attestation')." where sign=1 and uid=".$_G['uid']);
			date_default_timezone_set('PRC');//�л����񹲺͹�ʱ��
			$todaytimestamp = strtotime(gmdate('Y-m-d 00:00:00',TIMESTAMP+3600*8));
			$post_num = DB :: result_first('select count(*) from %t where uid=%d and addtime>=%d',array($pluginid,$_G['uid'],$todaytimestamp));
			if($settings['is_plugin_rz']['value']){
				if(!$rz){
					$tip = lang('plugin/aljtc','aljtc_75');
					echo "<script>parent.tips('".$tip."','plugin.php?id=aljtc&act=attes','error');</script>";
					exit;
				}
			}else{
				if($settings['no_rz_post_num']['value']&&!$rz){
					if($post_num >= $settings['no_rz_post_num']['value']){
						$tip = lang('plugin/aljtc','aljtc_73').$settings['no_rz_post_num']['value'].lang('plugin/aljtc','aljtc_74');
						echo "<script>parent.tips('".$tip."','','error');</script>";
						exit;
					}
				}
			}
			if($rz){
				if($settings['rz_post_num']['value']){
					if($post_num >= $settings['rz_post_num']['value']){
						$tip = lang('plugin/aljtc','aljtc_73').$settings['rz_post_num']['value'].lang('plugin/aljtc','aljtc_74');
						echo "<script>parent.tips('".$tip."','','error');</script>";
						exit;
					}
				}
			}
		}else if($_GET['adminedit'] != 'yes' && $_G['groupid'] != 1 && $_G['uid'] != $lp['uid']  && ($lp['fz_id'] != $my_city['id'] && $my_city)) {
			$tip = lang('plugin/aljtc','aljtc_99');
			echo "<script>parent.tips('".$tip."','','error');</script>";
			exit;
		}
		if(!$_GET['agreement_checked']){
			$tip = lang('plugin/aljtc','aljtc_135').$_G['cache']['plugin']['aljtc']['agreement_title'].lang('plugin/aljtc','aljtc_136');
			echo "<script>parent.tips('".$tip."','','error');</script>";
			exit;
		}
		$customlist = DB::fetch_all('select * from %t where typeid=%d',array($pluginid.'_custom',$typeid));
		//��֤�Զ�������Ƿ���д
        if($sid) {
            if($customlist_2 = DB::fetch_all('select * from %t where typeid=%d order by custom_order asc',array($pluginid.'_custom',$sid))){
                $customlist = $customlist_2;
			}
        }
		
		foreach($customlist as $tmp_key => $tmp_value) {
			if($tmp_value['custom_state']) {
				if($tmp_value['custom_type'] == 'region'){
					if(!$_GET['region']) {
						$tip = lang('plugin/aljtc','aljtc_72');
						echo "<script>parent.tips('".$tip."','','error');</script>";
						exit;
					}
					if(!$_GET['region1']) {
						$tip = lang('plugin/aljtc','aljtc_71');
						echo "<script>parent.tips('".$tip."','','error');</script>";
						exit;
					}
				}else if($tmp_value['custom_type'] == 'title'){
					$title_id = $tmp_value['custom_id'];
					
				}else if($tmp_value['custom_type'] == 'address'){
					if(!$_GET['region3']) {
						$tip = $tmp_value['custom_title'].lang('plugin/aljtc','aljtc_69');
							echo "<script>parent.tips('".$tip."','','error');</script>";
							exit;
					}
				}else{
					$tmp_name = 'form[var]['.$tmp_value['custom_id'].']';
					if($tmp_value['custom_required']) {
						if(!$_GET['form']['var'][$tmp_value['custom_id']]) {
							$tip = $tmp_value['custom_title'].lang('plugin/aljtc','aljtc_69');
							echo "<script>parent.tips('".$tip."','','error');</script>";
							exit;
						}
					}
				}
			}
		}
		
		if(!$_GET['content']) {
			echo "<script>parent.tips('".lang('plugin/aljtc','aljtc_68')."','','error');</script>";
			exit;
		}
		if(!$formsetting['is_post_lxfs']){
			if(!$_GET['lxr']) {
				echo "<script>parent.tips('".lang('plugin/aljtc','aljtc_67')."','','error');</script>";
				exit;
			}
			if($_GET['contact']) {
				if(!is_mobile_l($_GET['contact'])){
					echo "<script>parent.tips('".lang('plugin/aljtc','aljtc_66')."','','error');</script>";
					exit;
				}
			}else {
				echo "<script>parent.tips('".lang('plugin/aljtc','aljtc_65')."','','error');</script>";
				exit;
			}
		}
		
		if(!$typeid) {
			echo "<script>parent.tips('".lang('plugin/aljtc','aljtc_64')."','','error');</script>";
			exit;
		}
        if($_GET['pic']) {
            $src = array();
            foreach($_GET['pic'] as $tmp_key=> $tmp_value) {
                if (strpos($tmp_value,$oss_domain) !== false) {
                    $src[] = $tmp_value;
                }else if (is_file($tmp_value)) {
                    $src[] = $tmp_value;
                } else {
                    $src[] = T::saveimg($tmp_value,$image_path,'aljtc');
                }
            }
            $srcs = implode('|', $src);
        }
		$insertarray = array(
			'title' => $_GET['form']['var'][$title_id],
            'zufangtype' => $_GET['typeid'],
			'subtype' => $_GET['sid'],
            'subsubtype' => $_GET['cid'],
            'lxr' => $_GET['lxr'],
            'content' => $_GET['content'],
            'region' => $_GET['region'],
            'region1' => $_GET['region1'],
            'region2' => $_GET['region2'],
            'region3' => $_GET['region3'],
            'lat' => $_GET['y']?$_GET['y']:$_GET['lat'],
            'lng' => $_GET['x']?$_GET['x']:$_GET['lng'],
            'contact' => $_GET['contact'],
            'pic'=>$srcs
		);
		if($_G['cache']['plugin']['aljoss']['Access_Key'] && $_G['cache']['plugin']['aljtsp']['is_aljtc']){
            $insertarray['video_path'] = $_GET['video_path'];
            if($lp && ($_GET['del_video'] || $_GET['video_path']!=$lp['video_path'])){
                unlink($lp['video_path']);
                T::delete_oss($lp['video_path']);
                if($_GET['del_video']){
                    $insertarray['video_path'] = '';
                }
            }
        }else if($_G['cache']['plugin']['aljtsp'] && !$_G['cache']['plugin']['aljtsp']['is_aljtc']){
            if($_GET['video_path']){
                T::delete_oss($_GET['video_path']);
            }
            T::delete_oss($lp['video_path']);
            $insertarray['video_path'] = '';
        }
		if($_GET['adminedit'] == 'yes' && $admin_status){
			
			if(TIMESTAMP<strtotime($_GET['topetime'])){
				$insertarray['topstime'] = TIMESTAMP;
				$insertarray['topetime'] = strtotime($_GET['topetime']);
			}else{
				$insertarray['topstime'] = '';
				$insertarray['topetime'] = '';
			}
			$insertarray['expiry_time'] = strtotime($_GET['expiry_time']);
			$insertarray['updatetime'] = TIMESTAMP;
			$insertarray['state'] = $_GET['state'];
			$insertarray['fz_id'] = $_GET['fz_id'];
		}
		
		if($_GET['form']['tagid']) {
			$insertarray['label'] = serialize($_GET['form']['tagid']);
		}
		if($_GET['form']['var']) {
			$insertarray['form'] = serialize($_GET['form']['var']);
		}
		
		if($_GET['lid']) {//�༭
			DB::update($pluginid, $insertarray,array('id'=>$_GET['lid']));
			echo "<script>parent.tips('".lang('plugin/aljtc','aljtc_54')."','plugin.php?id=aljtc&act=view&lid=".$_GET['lid']."');</script>";
			exit;
		}else {
			
			dsetcookie('aljtc_my_tongji', 0, -1);
			if($settings['is_form']['value']){
				if(!valid_token($_GET[$pluginid.'_token'],getcookie($pluginid.'_token'),$pluginid.'_token')){
					echo "<script>parent.tips('".lang('plugin/aljtc','aljtc_55')."','');</script>";
					exit;
				}
			}
			if($settings['isreview']['value'] && !in_array($_G['groupid'],unserialize($settings['m_groups']['value']))){
				$state=1;
			}
			$insertarray['state'] = $state;
			$insertarray['uid'] = $_G['uid'];
			$insertarray['username'] = $_G['username'];
			$insertarray['addtime'] = TIMESTAMP;
			$insertarray['updatetime'] = TIMESTAMP;
			if($formsetting['expiry_time'] > 0){
				$insertarray['expiry_time'] = TIMESTAMP+$formsetting['expiry_time']*86400;
			}else{
				$insertarray['expiry_time'] = TIMESTAMP+$_G['cache']['plugin']['aljtc']['expiry_time']*86400;
			}
			
			if($_G['cookie']['fz_id']){
				$insertarray['fz_id'] = $_G['cookie']['fz_id'];
			}
			$two_formsetting_1 = DB::fetch_all('select * from %t where typeid=%d',array($pluginid.'_typesettings',$sid));
			foreach ($two_formsetting_1 as $pfk => $pfv){
				$two_formsetting[$pfv['type_key']] = $pfv['type_value'];
			}
			$one_formsetting_1 = DB::fetch_all('select * from %t where typeid=%d ',array($pluginid.'_typesettings',$typeid));
			
			foreach ($one_formsetting_1 as $pfk => $pfv){
				$one_formsetting[$pfv['type_key']] = $pfv['type_value'];
			}
			
			if($_G['cache']['plugin']['aljqb'] && ($one_formsetting['price']>0 || $two_formsetting['price']>0)){
				
				$insertarray['state'] = 2;
				
				$insertid = C::t('#'.$pluginid.'#'.$pluginid)->insert($insertarray,true);
				$insertarray['id'] = $insertid;
				
				$url = qb_pay($insertarray);//֧������
				
				echo "<script>parent.tips('".lang('plugin/aljtc','aljtc_130')."','".$url."');</script>";
				exit;
			}else{
				if($one_formsetting['releasepay'] && $one_formsetting['releaseextcredit']){
					$settings['releasepay']['value'] = $one_formsetting['releasepay'];
					$settings['releaseextcredit']['value'] = $one_formsetting['releaseextcredit'];
				}
				if($two_formsetting['releasepay'] && $two_formsetting['releaseextcredit']){
					$settings['releasepay']['value'] = $two_formsetting['releasepay'];
					$settings['releaseextcredit']['value'] = $two_formsetting['releaseextcredit'];
				}
				
				if($_G['cache']['plugin']['aljtcc'] && $card_info['card_tc_post']>0 && $settings['releasepay']['value']>0 && $card_user){
					$settings['releasepay']['value'] = floor($settings['releasepay']['value']*($card_info['card_tc_post']/100));
				}
				
				if($settings['releaseextcredit']['value']) {
					if (getuserprofile('extcredits' . $settings['releaseextcredit']['value']) < $settings['releasepay']['value']) {
						$tip = $_G['setting']['extcredits'][$settings['releaseextcredit']['value']]['title'].lang('plugin/aljtc','top_1');
						if($mobile_integral_recharge){
							echo "<script>parent.tips('".$tip."','".$mobile_integral_recharge."');</script>";
							exit;
						}else{
							echo "<script>parent.tips('".$tip."','');</script>";
							exit;
						}
					}
				}
				updatemembercount($_G['uid'], array($settings['releaseextcredit']['value'] => '-' .$settings['releasepay']['value']), true, '', 1,'',lang('plugin/aljtc','aljtc_103'),lang('plugin/aljtc','aljtc_104'));
			}
			
			$insertid = C::t('#'.$pluginid.'#'.$pluginid)->insert($insertarray,true);
			/*if($_GET['pic']) {
				foreach($_GET['pic'] as $key => $value){
					$updatearray['pid'] = $insertid;
					DB::update($pluginid.'_attachment',$updatearray,array('aid'=>$value));
				}
			}*/
			if(!in_array($_G['groupid'],unserialize($settings['m_groups']['value'])) && $settings['isreview']['value']){
				$groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
				foreach($groupids as $g_uid){
					notification_add($g_uid['uid'], 'system','<a href="plugin.php?id=aljtc&act=member&i=1">'.lang('plugin/aljtc','aljtc_56').'</a>',array('from_idtype'  => $pluginid,'from_id' => $insertid));
				}
				if($_G['cache']['plugin']['aljtc']['is_result']){
					echo "<script>parent.tips('".lang('plugin/aljtc','To_examine')."',function(){parent.location.href='plugin.php?id=aljtc&act=result&post=post&lid=".$insertid."'});</script>";
				}else{
					echo "<script>parent.tips('".str_replace('\\','',lang('plugin/aljtc','To_examine'))."','plugin.php?id=aljtc&act=view&lid=".$insertid."');</script>";
				}
				exit;
			}else{
				if($_G['cache']['plugin']['aljtc']['is_result']){
					echo "<script>parent.tips('".lang('plugin/aljtc','aljtc_4')."',function(){parent.location.href='plugin.php?id=aljtc&act=result&post=post&lid=".$insertid."'});</script>";
				}else{
					echo "<script>parent.tips('".str_replace('\\','',lang('plugin/aljtc','aljtc_4'))."','plugin.php?id=aljtc&act=view&lid=".$insertid."');</script>";
				}
				exit;
			}
		}


	}

} else if ($_GET['act'] == 'reflash') {//ˢ��
    if (getuserprofile('extcredits' . $settings['reflashextcredit']['value']) < $settings['reflashpay']['value']) {
		if($_G['mobile']){
			if($mobile_integral_recharge){
				if($_GET['getdata'] == 'yes') {
					$data['code'] = 300;
					$data['msg'] = $_G['setting']['extcredits'][$settings['reflashextcredit']['value']]['title'].lang('plugin/aljtc','top_1').lang('plugin/aljtc','aljtc_47');
					$data['url'] = $mobile_integral_recharge;
					echo json_encode(ajaxPostCharSet_aljtc($data));
					exit;
				}

			}else{
				if($_GET['getdata'] == 'yes') {
					$data['code'] = 400;
					$data['msg'] = $_G['setting']['extcredits'][$settings['reflashextcredit']['value']]['title'].lang('plugin/aljtc','top_1').lang('plugin/aljtc','aljtc_47');
					$data['url'] = 1;
					echo json_encode(ajaxPostCharSet_aljtc($data));
					exit;
				}

			}
			exit;
		}
	}
	C::t('#'.$pluginid.'#'.$pluginid.'_reflashlog')->insert(array(
	    'lid' => $_GET['lid'],
	    'uid' => $_G['uid'],
	    'username' => $_G['username'],
	    'dateline' => TIMESTAMP,
	    'pay' => $settings['reflashpay']['value'],
	    'extcredit' => $settings['relashextcredit']['value'],
		'title' => $lp['title'],
	    'name' => $lp['username'],
	));
	C::t('#'.$pluginid.'#'.$pluginid)->update_updatetime_by_id($_GET['lid']);
	updatemembercount($_G['uid'], array($settings['reflashextcredit']['value'] => '-' . $settings['reflashpay']['value']), true, '', 1,'',lang('plugin/aljtc','aljtc_105'),lang('plugin/aljtc','aljtc_106'));
	if($_G['mobile']){
		if($_GET['getdata'] == 'yes') {
			$data['code'] = 200;
			$data['msg'] = lang('plugin/aljtc','reflash_1').lang('plugin/aljtc','aljtc_90').$settings['reflashpay']['value'].$_G[setting][extcredits][$settings[reflashextcredit][value]][title];
			$data['url'] = 0;
			echo json_encode(ajaxPostCharSet_aljtc($data));
			exit;
		}
	}
} else if ($_GET['act'] == 'top') {//�ö�
    if ($_GET['formhash'] == formhash()) {
		if($_GET['days']<0){
			if($_G['mobile']){
				if($_GET['getdata'] == 'yes') {
					$data['code'] = 300;
					$data['msg'] = lang('plugin/aljtc','top_3');
					$data['url'] = 0;
					echo json_encode(ajaxPostCharSet_aljtc($data));
					exit;
				}
			}
		}
		$lp=C::t('#'.$pluginid.'#'.$pluginid)->fetch($_GET['lid']);
		$insertarray = array(
			'lid' => $_GET['lid'],
			'uid' => $_G['uid'],
			'username' => $_G['username'],
			'dateline' => TIMESTAMP,
			'endtime' => TIMESTAMP+$_GET['days']*86400,
			'pay' => $_GET['price']>0 ? $_GET['price'] : $_GET['days']*$settings['toppay']['value'],
			'extcredit' => $settings['topextcredit']['value'],
			'title' => $lp['title'],
			'name' => $lp['username'],
		);
		$insertid=C::t('#'.$pluginid.'#'.$pluginid.'_toplog')->insert($insertarray,true);
		if (getuserprofile('extcredits' . $settings['topextcredit']['value']) < $insertarray['pay']) {
			if($_G['mobile']){
				if($mobile_integral_recharge){
					if($_GET['getdata'] == 'yes') {
						$data['code'] = 400;
						$data['msg'] = $_G['setting']['extcredits'][$settings['topextcredit']['value']]['title'] .lang('plugin/aljtc','top_1').lang('plugin/aljtc','aljtc_47');
						$data['url'] = $mobile_integral_recharge;
						echo json_encode(ajaxPostCharSet_aljtc($data));
						exit;
					}
				}else{
					if($_GET['getdata'] == 'yes') {
						$data['code'] = 500;
						$data['msg'] = $_G['setting']['extcredits'][$settings['topextcredit']['value']]['title'].lang('plugin/aljtc','top_1').lang('plugin/aljtc','aljtc_47');
						$data['url'] = 1;
						echo json_encode(ajaxPostCharSet_aljtc($data));
						exit;
					}
				}
			}
		}
		updatemembercount($_G['uid'], array($settings['topextcredit']['value'] => '-' .$insertarray['pay']), true, '', 1,'',lang('plugin/aljtc','aljtc_107'),lang('plugin/aljtc','aljtc_108'));
		if($lp['topetime']&&TIMESTAMP<$lp['topetime']){
			DB::update('aljtc_toplog',array('endtime'=>$lp['topetime']+$_GET['days']*86400),'id='.$insertid);
			DB::update($pluginid,array('topetime'=>$lp['topetime']+$_GET['days']*86400),'id='.$_GET[lid]);
		}else{
			DB::update($pluginid,array('topstime'=>TIMESTAMP,'topetime'=>TIMESTAMP+$_GET['days']*86400),'id='.$_GET[lid]);
		}
		if($_G['mobile']){
			if($_GET['getdata'] == 'yes') {
				$data['code'] = 200;
				$data['msg'] = lang('plugin/aljtc','top_2').lang('plugin/aljtc','aljtc_90').$insertarray['pay'].$_G[setting][extcredits][$settings[topextcredit][value]][title];
				$data['url'] = 1;
				echo json_encode(ajaxPostCharSet_aljtc($data));
				exit;
			}
		}
	}
} else if ($_GET['act'] == 'view') {//����ҳ��
    $regions = C::t('#'.$pluginid.'#'.$pluginid.'_region')->range();
    
    //$pics = array('pic1', 'pic2', 'pic3', 'pic4', 'pic5', 'pic6', 'pic7', 'pic8');
	$lp = C::t('#'.$pluginid.'#'.$pluginid)->fetch($_GET['lid']);
	if(!$lp){
		
		$result_info = array();
		$result_info['icon'] = 'weui-icon-warn';
		
		$result_info['btn_default'] = array('value' => lang('plugin/aljtc','aljtc_93'), 'url' => 'plugin.php?id=aljtc&act=user');
		$navtitle = lang('plugin/aljtc','aljtc_92');
		$result_info['title'] = lang('plugin/aljtc','aljtc_92');
		$result_info['desc'] = lang('plugin/aljtc','aljtc_6');
		$result_info['btn_primary'] = array('value' => lang('plugin/aljtc','aljtc_134'), 'url' => 'plugin.php?id=aljtc');
		include template('aljtc:A_Model/tc_result');
		exit;
		
	}
	C::t('#'.$pluginid.'#'.$pluginid)->update_views_by_id($_GET['lid']);
	if($lp['uid']){
		$grrz = DB::result_first("select count(*) from %t where uid= %d and sign=1 and type=1",array($pluginid.'_attestation',$lp['uid']));
		$qyrz = DB::result_first("select count(*) from %t where uid= %d and sign=1 and type=2",array($pluginid.'_attestation',$lp['uid']));
	}
	$label = unserialize($lp['label']);
	foreach($label as $tmp_key => $tmp_value) {
		if($tmp_value) {
			$newlabel[$tmp_key] = $tmp_value;
		}
	}
	
	if($lp['form']) {
		$newform = unserialize($lp['form']);
		
		foreach($newform as $tmp_key => $tmp_value) {
			$tmp_name = 'form[var]['.$tmp_key.']';
			$form_title = DB::fetch_first('select * from %t where custom_name = %s',array($pluginid.'_custom',$tmp_name));
			
			if($form_title) {
				$new_array[$tmp_key]['custom_type'] = $form_title['custom_type'];
				$new_array[$tmp_key]['title'] = $form_title['custom_title'];
				if($tmp_value) {
					$new_array[$tmp_key]['value'] = $tmp_value.$form_title['custom_unit'];
				}
			}
		}
	}
	
	$customlist_1 = DB::fetch_all('select * from %t where typeid=%d order by custom_order asc',array($pluginid.'_custom',$lp['subtype']));
	if($lp['subtype'] && $customlist_1){
        $customlist_1 = $customlist_1;
    }else{
        $customlist_1 = DB::fetch_all('select * from %t where typeid=%d order by custom_order asc',array($pluginid.'_custom',$lp['zufangtype']));
	}

	$customlist_1 = customedit($customlist_1);
	foreach($customlist_1 as $c_k => $c_v){
		$customlist[$c_v[custom_type]] = $c_v;
	}
	
	if($_G['cache']['plugin']['aljhtx']['is_aljtc'] && $_G['cache']['plugin']['aljbd']){
		if($_GET['bid']){
            $bd = DB::fetch_first('select * from %t where id=%d and rubbish=0 and status=1 limit 1',array('aljbd',$_GET['bid']));
		}else{
            $bd = DB::fetch_first('select * from %t where uid=%d and rubbish=0  and status=1 limit 1',array('aljbd',$lp['uid']));
		}
        if($bd){
            $businesstype = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljbd']['businesstype']));
            foreach($businesstype as $key=>$value){
                $arr=explode('=',$value);
                $businesstypearr[$arr[0]]=$arr[1];
                $busarr[$arr[0]]=diconv($arr[1],CHARSET,'UTF-8');;
            }
            $comment = DB::fetch_first('select avg(k) k,avg(h) h,avg(f) f from %t where rubbish=0 and bid=%d and ask=0',array('aljbd_comment',$bd['id']));
            $businesstype = explode(',',$bd['businesstype']);
            if($bd['businesstype']){
                if($businesstype[0]){
                    $commentkhf[$businesstype[0]] = $comment['k'];
                }
                if($businesstype[1]){
                    $commentkhf[$businesstype[1]] = $comment['h'];
                }
                if($businesstype[2]){
                    $commentkhf[$businesstype[2]] = $comment['f'];
                }
            }
		}
        $view_goods_num = $_G['cache']['plugin']['aljbd']['view_goods_num']?$_G['cache']['plugin']['aljbd']['view_goods_num']:6;//������Ʒ����
        $t=C::t('#aljbd#aljbd_goods')->fetch_all_by_uid_bid_view_new($lp['uid'],$bd['id'],0,$view_goods_num,0);
        foreach($t as $k=>$v){
            $t[$k]['price1']=floatval($v['price1']);
            $t[$k]['price2']=floatval($v['price2']);
        }
	}
    $gtypes_tmp = C::t('#aljtc#'.$pluginid.'_position')->fetch_all_by_upid(0);
	if($pos_all[$lp['zufangtype']]['subject'] || $lp['region1']){
		$posname = lang('plugin/aljtc','aljtc_57').$regions[$lp['region1']]['subject'].$pos_all[$lp['zufangtype']]['subject'].lang('plugin/aljtc','aljtc_58');
	}
	$praiseCount = DB::result_first('select count(*) from %t where lid=%d',array('aljtc_praise',$lp['id']));
	if($praiseCount>0){
		$praise = DB::fetch_all('select * from %t where lid=%d order by id desc',array('aljtc_praise',$lp['id']));
	}
	$collection_num = DB::result_first('select count(*) from %t where lid=%d ',array('aljtc_collection',$_GET['lid']));
    $navtitle = $posname.cutstr(str_replace(array("\n","\r"),'',strip_tags($lp['content']) ),80).'-'.$settings['daohang']['value'];
	$description = $settings['description']['value'];
	$metakeywords = $settings['daohang']['value'];
	
	if($aljtc_seo['view']['seotitle']){
		$seodata = array(
			'bbname' => $_G['setting']['bbname'],
			'subject' => $lp['title'],
			'message' => cutstr(str_replace(array("\n","\r"),'',strip_tags($lp['content']) ),160),
			'cat'=>$pos_all[$lp['zufangtype']][subject],
			'cat1'=>$pos_all[$lp['subtype']][subject],
			'cat2'=>$pos_all[$lp['subsubtype']][subject],
			'region'=>$regions[$lp['region']][subject],
			'region1'=>$regions[$lp['region1']][subject],
			'region2'=>$regions[$lp['region2']][subject],
		);
		
		list($navtitle, $description, $metakeywords) = get_seosetting('', $seodata, $aljtc_seo['view']);
		
	}
	$is_file_path = DISCUZ_ROOT.'./source/plugin/aljtrw/include/task.php';
	if(is_file($is_file_path)){
		$task_id = 1;
		$object_id = $lp['id'];
		include $is_file_path;
	}
	$my_post_num = DB::result_first('select count(*) from %t where uid=%d',array('aljtc',$lp['uid']));
	$typeSettins = type_settins($lp['zufangtype'],$lp['subtype'],$lp['id']);
	$formsetting = $typeSettins['formsetting'];
	include template($pluginid.':A_Model/detail/details');
}else if($_GET['act'] == 'getcommentlist') { //��ȡ�����б�
	$page = $_GET['page']? intval($_GET['page']):1;
	$perpage = 6;
    $start = ($page - 1) * $perpage;
	$commentlist = DB::fetch_all('select * from %t where upid=%d and lid=%d and status=0 order by id desc limit %d,%d',array($pluginid.'_comment',0,$_GET['lid'],$start,$perpage));
	if(empty($commentlist)) {
		echo 1;
		exit;
	}else {
		include template($pluginid.':A_Model/detail/commentlist');
	}

} else if ($_GET['act'] == 'deletecomment') {//ɾ�����ۼ�¼
	$user = DB::fetch_first('select * from %t where id=%d',array($pluginid.'_comment',$_GET['lid']));
	if($user['uid']!=$_G['uid']&&$_G['groupid']!=1){
		$data['code'] = 400;
		$data['msg'] = lang('plugin/aljtc','aljtc_8');
		echo json_encode(ajaxPostCharSet_aljtc($data));
		exit;
	}
	
    if(DB::delete($pluginid.'_comment',array('id'=>$_GET['lid']))) {
		DB::delete($pluginid.'_comment',array('upid'=>$_GET['lid']));
    	if($_GET['getdata'] == 'yes') {
    		$data['code'] = 200;
			$data['msg'] = lang('plugin/aljtc','aljtc_7');
			echo json_encode(ajaxPostCharSet_aljtc($data));
			exit;
    	}
    }else {
    	if($_GET['getdata'] == 'yes') {
	    	$data['code'] = 300;
			$data['msg'] = lang('plugin/aljtc','aljtc_63');
			echo json_encode(ajaxPostCharSet_aljtc($data));
			exit;
		}
    }

}else if ($_GET['act'] == 'delete') {//ɾ����¼
	$user = DB::fetch_first('select * from %t where id=%d',array($pluginid,$_GET['lid']));
	if($user['uid']!=$_G['uid']&&$_G['groupid']!=1 && ($user['fz_id'] != $my_city['id'] && $my_city)){
		$data['code'] = 400;
		$data['msg'] = lang('plugin/aljtc','aljtc_8');
		echo json_encode(ajaxPostCharSet_aljtc($data));
		exit;
	}
	for ($i = 1; $i <= 8; $i++) {
		$pic = 'pic' . $i;
		if ($user[$pic]) {
			@unlink($user[$pic]);
		}
	}
	if($user['tid']){
		DB::update('forum_post', array('invisible'=>'-1'), "tid=".$user['tid']);
		DB::update('forum_thread', array('displayorder'=>'-1'), "tid=".$user['tid']);
	}
    if(DB::delete($pluginid,array('id'=>$_GET['lid']))) {
    	if($_GET['getdata'] == 'yes') {
    		$data['code'] = 200;
			$data['msg'] = lang('plugin/aljtc','aljtc_7');
			echo json_encode(ajaxPostCharSet_aljtc($data));
			exit;
    	}
    }else {
    	if($_GET['getdata'] == 'yes') {
	    	$data['code'] = 300;
			$data['msg'] = lang('plugin/aljtc','aljtc_63');
			echo json_encode(ajaxPostCharSet_aljtc($data));
			exit;
		}
    }

}else if($_GET['act'] == 'ask'){//���ۻظ�
	if($_GET['formhash'] == formhash()){
		if (empty($_G['uid'])) {
			if($_GET['getdata'] == 'yes') {
				$tmp_array['tip'] = lang('plugin/aljtc','aljtc_1');
				$tmp_array['url'] = 0;
				echo json_encode(ajaxPostCharSet_aljtc($tmp_array));
				exit;
			}
		}
		if (empty($_GET['message'])) {
			if($_GET['getdata'] == 'yes') {
				$tmp_array['tip'] = lang('plugin/aljtc','aljtc_9');
				$tmp_array['url'] = 0;
				echo json_encode(ajaxPostCharSet_aljtc($tmp_array));
				exit;
			}
		}
		$insertarray=array(
			'content'=>$_GET['message'],
			'uid'=>$_G['uid'],
			'username'=>$_G['username'],
			'lid'=>$_GET['lid'],
			'dateline'=>TIMESTAMP,
			'upid'=>$_GET['upid'],
			'uusername'=>$_GET['username'],
			'uuid'=>$_GET['uid'],
		);
		if($_G['cache']['plugin']['aljtc']['is_reply_sh']){
			$insertarray['status'] = 1;
		}
		$cid = C::t('#'.$pluginid.'#'.$pluginid.'_comment')->insert($insertarray,true);
		if($settings['is_ping']['value']){
			$lp = DB::fetch_first('select * from %t where id=%d',array($pluginid,$_GET['lid']));
			if(!$_GET['upid']){
				notification_add($lp['uid'], 'system',lang('plugin/aljtc','aljtc_27').lang('plugin/aljtc','aljtc_28').' <a href="plugin.php?id=aljtc&act=view&lid='.$_GET['lid'].'" target="_blank">'.lang('plugin/aljtc','aljtc_29').'</a>',array('from_idtype'  => $pluginid,'from_id' => $_GET['lid']));
			}else if($_GET['uid']){
				notification_add($_GET['uid'], 'system',lang('plugin/aljtc','aljtc_30').lang('plugin/aljtc','aljtc_61').lang('plugin/aljtc','aljtc_31').' <a href="plugin.php?id=aljtc&act=view&lid='.$_GET['lid'].'" target="_blank">'.lang('plugin/aljtc','aljtc_29').'</a>',array('from_idtype'  => $pluginid,'from_id' => $_GET['lid']));
			}
		}
		if($_GET['getdata'] == 'yes') {
			if($_G['cache']['plugin']['aljtc']['is_reply_sh']){
				$tmp_array['tip'] = lang('plugin/aljtc','aljtc_43');
				$tmp_array['url'] = 0;
			}else{
				$tmp_array['tip'] = lang('plugin/aljtc','aljtc_10');
				$tmp_array['url'] = 1;
			}
			
			$tmp_array['uid'] = $_G['uid'];
			$tmp_array['username'] = $_G['username'];
			$tmp_array['content'] = $_GET['message'];
			$tmp_array['cid'] = $cid;
			$tmp_array['status'] = intval($insertarray['status']);
			echo json_encode(ajaxPostCharSet_aljtc($tmp_array));
			exit;
		}
	}
} else if ($_GET['act'] == 'member') {//�ҵķ���
	if($_G['groupid']==1 && $_GET[i] == 1){
		$navtitle = lang('plugin/aljtc','aljtc_96').$settings['daohang']['value'];
	}else{
		$navtitle = lang('plugin/aljtc','aljtc_59').$settings['daohang']['value'];
	}
	$description = $settings['description']['value'];
	
	$metakeywords = $settings['daohang']['value'];
	if($aljtc_seo['member']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljtc_seo['member']);
	}
	
    if($_GET['i'] == 2 && $my_city){
		$navtitle = lang('plugin/aljtc','aljtc_96').$my_city['name'];
	}
	include template($pluginid.':A_Model/my/member');
}else if($_GET['act'] == 'infomanage') {//ajax������ҳ����Ϣ����
	$currpage = $_GET['page'] ? $_GET['page'] : 1;
	if($_GET['getact'] == 'myreply'){
		$perpage = 10;
	}else{
		$perpage = 6;
	}
    $start = ($currpage - 1) * $perpage;
	$conndtion = array();
	
	if($_G['groupid']==1 && $_GET[i] == 1){
		if($_GET['solve'] == 1) {
			$conndtion['state'] = 1;
		}else {
			$conndtion['state'] = 0;
		}
	}else if($my_city && $_GET[i] == 2){
		$conndtion['fz_id'] = $my_city['id'];
		if($_GET['solve'] == 1) {
			$conndtion['state'] = 1;
		}else {
			$conndtion['state'] = 0;
		}
	}else{
		$conndtion = array(
			'uid' => $_G['uid'],
		);
		if($_GET['solve'] == 1) {
			$conndtion['is_solve'] = 1;
		}else {
			if($_GET['solve'] == 3){
				$conndtion['is_solve'] = 1;
				$conndtion['state'] = 1;
			}else if($_GET['solve'] == 4){
				$conndtion['is_solve'] = 1;
				$conndtion['state'] = 2;
			}else if($_GET['solve']>0){
				$conndtion['solve'] = 1;
			}else{
				$conndtion['state'] = 99;
			}
		}
	}
	
	if($_GET['getact'] == 'collection') {
		$goodslist_1 = DB::fetch_all('select b.* from %t a left join %t b on a.lid=b.id where a.uid=%d limit %d,%d',array($pluginid.'_collection',$pluginid,$_G['uid'],$start,$perpage));
		foreach($goodslist_1 as $gk_1 => $gv_1){
			if($gv_1[id]>0){
				$goodslist[] = $gv_1;
			}
		}
	}else if($_GET['getact'] == 'praise') {
		$goodslist_1 = DB::fetch_all('select b.* from %t a left join %t b on a.lid=b.id where a.uid=%d limit %d,%d',array($pluginid.'_praise',$pluginid,$_G['uid'],$start,$perpage));
		foreach($goodslist_1 as $gk_1 => $gv_1){
			if($gv_1[id]>0){
				$goodslist[] = $gv_1;
			}
		}
	}else if($_GET['getact'] == 'myreply') {
		$commentlist = DB::fetch_all('select * from %t where uid=%d and upid=0 order by id desc limit %d,%d',array($pluginid.'_comment',$_G['uid'],$start,$perpage));
		if($commentlist) {
			include template($pluginid.':A_Model/detail/commentlist');
		}else {
			echo 1;
		}
		exit;
	}else {
		$goodslist = C::t('#'.$pluginid.'#'.$pluginid)->fetch_all_by_addtime($start, $perpage, $conndtion);
		foreach($goodslist as $gk => $gv){
			if(TIMESTAMP>$gv['topetime']&&$gv['topetime']){
				DB::update('aljtc',array('topstime'=>'','topetime'=>''),'id='.$gv[id]);
			}
			if(TIMESTAMP>$gv['expiry_time']&&$gv['expiry_time']){
				DB::update('aljtc',array('solve'=>'1'),'id='.$gv[id]);
			}
		}
	}
	if($goodslist) {
		include template($pluginid.':A_Model/my/infomanage');
	}else {
		echo 1;
		exit;
	}

}else if($_GET['act'] == 'pay_url'){
	$lp = DB::fetch_first('select * from %t where id=%d',array($pluginid,$_GET['lid']));
	if($lp){
		$url = qb_pay($lp);
		
		if($url == 1){
			echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang('plugin/aljtc','aljtc_131'))));
			exit;
		}else{
			echo json_encode(T::ajaxPostCharSet(array('code'=>1,'text'=>lang('plugin/aljtc','aljtc_132'),'url'=>$url)));
			exit;
		}
	}else{
		echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang('plugin/aljtc','aljtc_131'))));
		exit;
	}
}else if($_GET['act'] == 'all'){ //����������Ϣ
	$uid = abs(intval($_GET['uid']));
	$userinfo = getuserbyuid($uid);
    $navtitle = $userinfo['username'].lang('plugin/aljtc','aljtc_60').$settings['daohang']['value'];
	$description = $settings['description']['value'];
	$metakeywords = $settings['daohang']['value'];
	if($aljtc_seo['quanbu']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$userinfo['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljtc_seo['quanbu']);
	}
	include template($pluginid.':A_Model/my/userinfo');
}else if($_GET['act'] == 'mobile_deleteattach'){//ɾ��ͼƬ
	$aid = htmlspecialchars(intval($_GET['aid']));
	if($aid && $_GET['formhash'] = formhash()){
		$attach = C::t('#'.$pluginid.'#'.$pluginid.'_attachment') -> fetch($aid);
		C::t('#'.$pluginid.'#'.$pluginid.'_attachment') -> delete($aid);
		@unlink($attach['pic']);
		echo 1;
		exit;
	}
}else if($_GET['act'] == 'mupload'){//�ϴ�ͼƬ
	$fn = (isset($_GET['base64']) ? $_GET['base64'] : false);
	$fn_length = intval($_GET['size']);
	if ($fn && $fn_length == strlen($fn) && $_GET['hash'] == FORMHASH) {
		$rand = rand(100, 999);
		$pics = date("YmdHis") . $rand . '.jpg';
		$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
		if (!is_dir($img_dir)) {
			mkdir($img_dir);
		}
		$pic = $img_dir . $pics;
		file_put_contents($pic,file_get_contents($fn));
		$aid = C::t('#'.$pluginid.'#'.$pluginid.'_attachment') -> insert(array('pic' => $pic),true);
		echo "{\"picid\":\"".$aid."\", \"url\":\"".$pic."\"}";
		exit();
	}
}else if($_GET['act'] == 'list'){//�б�ҳ��
	//����
	$types = $pos_all;
	$gtypes_tmp = C::t('#aljtc#'.$pluginid.'_position')->fetch_all_by_upid(0);
	foreach($gtypes_tmp as $gk => $gtype){
		$gtypes[$gtype['id']] = $gtype;
		$ids_tmp = C::t('#aljtc#'.$pluginid.'_position')->fetch_all_by_upid($gtype['id']);
		foreach($ids_tmp as $id){
			$tmp_subtype = C::t('#'.$pluginid.'#'.$pluginid.'_position') -> fetch_all_by_upid($id['id']);
			$sub3ids[$id['id']] = $tmp_subtype;
			$ids[] = $id['id'];
		}
		$gtypes[$gtype['id']]['subid'] = $ids;
		unset($ids);
	}
	$regions = C::t('#'.$pluginid.'#'.$pluginid.'_region')->range();
	$rs = C::t('#'.$pluginid.'#'.$pluginid.'_region')->fetch_all_by_upid(0);
	$geturl = array(
		'id' => $pluginid,
		'act' => 'list',
		'search' => $_GET['search'],
		'rid' => $_GET['rid'],
		'subrid' => $_GET['subrid'],
		'subsubrid' => $_GET['subsubrid'],
		'pay1' => $_GET['pay1'],
		'pay2' => $_GET['pay2'],
		'wanted' => $_GET['wanted'],
		'zufangtype' => $_GET['zufangtype'],
		'subtype' => $_GET['subtype'],
		'subsubtype' => $_GET['subsubtype'],
		'solve' => $_GET['solve'],
		'view' => $_GET['view'],
		'new' => $_GET['new'],
		'pic' => $_GET['pic'],
		'order'=>$_GET['order']
	);
    $title = '';
	if($_GET['subsubrid']){
		$title .= $regions[$_GET['subsubrid']][subject];
	}else if($_GET['subrid']){
        $title .= $regions[$_GET['subrid']][subject];
	}else if($_GET['rid']){
        $title .= $regions[$_GET['rid']][subject];
	}
	if($_GET['subsubtype']){
        $title .= $pos_all[$_GET['subsubtype']][subject];
	}else if($_GET['subtype']){
        $title .= $pos_all[$_GET['subtype']][subject];
	}else if($_GET['zufangtype']){
		$title .= $pos_all[$_GET['zufangtype']][subject];
	}
	if($_GET['rid'] || $_GET['zufangtype']){
        $title .= lang('plugin/aljtc','aljtc_61');
	}else{
        $title .= lang('plugin/aljtc','aljtc_62');
	}
    $navtitle = $title.'-'.$settings['daohang']['value'];
	$description = $settings['description']['value'];
	$metakeywords = $settings['daohang']['value'];
	
	if($aljtc_seo['list']['seotitle']){
		$seodata = array(
			'bbname' => $_G['setting']['bbname'],
			'cat'=>$pos_all[$_GET['zufangtype']][subject],
			'cat1'=>$pos_all[$_GET['subtype']][subject],
			'cat2'=>$pos_all[$_GET['subsubtype']][subject],
			'region'=>$regions[$_GET['rid']][subject],
			'region1'=>$regions[$_GET['subrid']][subject],
			'region2'=>$regions[$_GET['subsubrid']][subject]
		);
		list($navtitle, $description, $metakeywords) = get_seosetting('', $seodata, $aljtc_seo['list']);
	}
	include template($pluginid.':A_Model/list/list');
} else if($_GET['act']=='admingetregion'){
	if($_GET['upid']){
		$rlist=C::t('#aljtc#aljtc_region')->fetch_all_by_upid_sys($_GET['upid']);
	}
	include template('aljtc:admingetregion');
}else if($_GET['act']=='admingetregion1'){
	if($_GET['upid']){
		$rlist=C::t('#aljtc#aljtc_region')->fetch_all_by_upid_sys($_GET['upid']);
	}
	include template('aljtc:admingetregion1');
}else if($_GET['act'] == 'qb_pay_tel'){
	if(!$_G['cache']['plugin']['aljqb']){
		echo json_encode(ajaxPostCharSet_aljtc(array('code'=>101,'text'=>'�鿴ʧ�ܣ�δ��װǮ��������밲װ���ٿ����鿴�绰�շѹ���')));
		exit;
	}
	$url = qb_pay_tel($_GET['price'],$_GET['lid']);
	if($url != 1){
		echo json_encode(ajaxPostCharSet_aljtc(array('code'=>100,'text'=>'��ת֧��','url'=>$url)));
		exit;
	}else{
		echo json_encode(ajaxPostCharSet_aljtc(array('code'=>101,'text'=>'�鿴ʧ�ܣ�������')));
		exit;
	}
}else {//��ҳ
    if(file_exists("source/plugin/aljdiy/aljdiy.inc.php") && $_G['mobile'] && $no_diy != 1) {
		$page_diy = DB::fetch_first('select * from %t where push_to_page = %s',array('aljdiy_page','aljtc_index'));
		if($page_diy){
			$_GET['c'] = 'index';
			$_GET['a'] = 'index';
			$_GET['ajax'] = 'yes';
			$_GET['page_id'] = $page_diy['id'];
		   
			require_once DISCUZ_ROOT . './source/plugin/aljdiy/aljdiy.inc.php';
			exit;
		}
	}
    //���������ͳ��
	$view_num = DB::result_first('select sum(views) from %t ',array($pluginid));
    $post_num = DB::result_first('select count(*) from %t ',array($pluginid));
	if($_G['cache']['plugin']['aljtc']['index_fictitious']){
		list($index_views_num,$index_post_num) = explode('|',$_G['cache']['plugin']['aljtc']['index_fictitious']);
		if($index_views_num>0){
			$view_num = $view_num + $index_views_num;
		}
		if($index_post_num>0){
			$post_num = $post_num + $index_post_num;
		}
	}
	$view_num = T::num2tring($view_num);
	$post_num = T::num2tring($post_num);
	if($_G['cache']['plugin']['aljhelp']){
		$v_p_num = '<span class="iconfont icon-tuijian mr5"></span>'.lang('plugin/aljtc','aljtc_44').'<span>'.$view_num.'</span>&nbsp;'.lang('plugin/aljtc','aljtc_45').'<span>'.$post_num.'</span>';
		if($_G['cache']['plugin']['aljtsq']['is_aljtsq']){
			$b_post_num = T::num2tring(DB::result_first('select count(*) from %t ',array('aljtsq_store')));
			$v_p_num .= '&nbsp;'.lang('plugin/aljtc','aljtc_46').'<span>'.$b_post_num.'</span>';
		}
	}else{
		$v_p_num = '<span class="iconfont icon-tuijian mr5"></span>'.lang('plugin/aljtc','aljtc_44').'<span>'.$view_num.'</span><i class="c_c_p">-</i>'.lang('plugin/aljtc','aljtc_45').'<span>'.$post_num.'</span>';
		if($_G['cache']['plugin']['aljtsq']['is_aljtsq']){
			$b_post_num = T::num2tring(DB::result_first('select count(*) from %t ',array('aljtsq_store')));
			$v_p_num .= '<i class="c_c_p">-</i>'.lang('plugin/aljtc','aljtc_46').'<span>'.$b_post_num.'</span>';
		}
	}
	
	
    //ͬ���ȵ�
    $mobile_index_hot_text = explode ("\n", str_replace ("\r", "", $settings ['mobile_index_hot_text']['value']));
    foreach($mobile_index_hot_text as $key=>$value){
        $arr=explode('|',$value);
        $mobile_index_hot_text_types[]=$arr;
	}
	//����ĸ�AD
    $row_four_grids = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljtc']['row_four_grids']));
    foreach($row_four_grids as $key=>$value){
        $arr=explode('|',$value);
        $row_four_grids_types[]=$arr;
	}
	
	//ͬ���ȵ����������Ϣ10��
	if($settings['mobile_index_hot_type']['value'] == 1) {
		$mobile_index_hot_type_1 = DB::fetch_all('select * from %t where state=0 order by id desc limit 0,10',array($pluginid));
	}else if($settings['mobile_index_hot_type']['value'] == 2 && $_G['cache']['plugin']['aljtsq']) {
		$mobile_index_hot_type_2 = C::t('#aljtsq#aljtsq_store')->fetch_all_by_new();
	}else if($settings['mobile_index_hot_type']['value'] == 3) {
		$mobile_index_hot_type_1 = DB::fetch_all('select * from %t where state=0 order by id desc limit 0,10',array($pluginid));
		if($_G['cache']['plugin']['aljtsq']){
			$mobile_index_hot_type_2 = C::t('#aljtsq#aljtsq_store')->fetch_all_by_new();
		}
	}
	if($settings['rec_brand']['value'] == 1 || $settings['rec_brand']['value'] == 2){
		if($settings['rec_brand']['value'] == 1 && $_G['cache']['plugin']['aljbd']){
			$recommendlist=C::t('#aljbd#aljbd')->fetch_all_by_recommend(1,0,9);
		}else if($_G['cache']['plugin']['aljtsq']){
			$where[recommend] = 1;
			$field = "*";
			$orderby = 'order by tc_displayorder asc,tc_dateline asc,tc_view desc';
			$where[start] = 0;
        	$where[perpage] = 9;
			$recommendlist = C::t('#aljtsq#aljtsq_store')->fetch_all_by_where($where,$field,$orderby);
		}
		if($recommendlist){
			foreach($recommendlist as $rec_k => $rec_v){
				$recommendlist[$rec_k]['url'] = $settings['rec_brand']['value'] == 1 ? 'plugin.php?id=aljbd&act=view&bid='.$rec_v['id'] : 'plugin.php?id=aljtsq&c=aljtsq&a=view&store_id='.$rec_v['tc_id'];
				$recommendlist[$rec_k]['name'] = $settings['rec_brand']['value'] == 1 ? $rec_v['name'] : $rec_v['tc_store_name'];
				$recommendlist[$rec_k]['logo'] = $settings['rec_brand']['value'] == 1 ? $rec_v['logo'] : $rec_v['tc_logo'];
			}
		}
	}
	
	//��ҳ��Ϣ���Ϸ�����ֲ�
	if($settings['index_list_top_lz_ad']['value']){
		$index_list_top_lz_ad = explode ("\n", str_replace ("\r", "", $settings['index_list_top_lz_ad']['value']));
	}
	//����������
	if($settings['sangead']['value']) {
		$sangead = explode ("\n", str_replace ("\r", "", $settings['sangead']['value']));
	}
	//��ҳ�ֲ��������
	if($settings['lunad']['value']) {
		$lunad = explode ("\n", str_replace ("\r", "", $settings['lunad']['value']));
	}
	
    //�ֻ���ͼ�Ĺ��
    $mobile_index_Photo_Ads = explode ("\n", str_replace ("\r", "", $settings['mobile_index_Photo_Ads']['value']));
    foreach($mobile_index_Photo_Ads as $key=>$value){
        $arr=explode('|',$value);
        $mobile_index_Photo_Ads_arr[]=$arr;
    }
	//�ֻ�����ҳ������ͼ
	$mobile_index_ad = explode ("\n", str_replace ("\r", "", $settings['mobile_index_ad']['value']));
	foreach($mobile_index_ad as $key=>$value){
		$arr=explode('|',$value);
		$mobile_index_ad_arr[]=$arr;
	}
	$regionlist = DB::fetch_all('select * from %t where upid=%d',array($pluginid.'_region',0));
	$gtypes_tmp = C::t('#aljtc#'.$pluginid.'_position')->fetch_all_by_upid(0);
	//�ֻ�����תͼƬ
	if($settings[mobile_index_new_lz]['value']){
		$mobile_lz_moren = $settings[mobile_index_new_lz]['value'];
	}else{
		$mobile_lz_moren ='#|source/plugin/'.$pluginid.'/images/m_lz1.png|&#31934;&#21697;&#25554;&#20214;
#|source/plugin/'.$pluginid.'/images/m_lz2.png|&#36339;&#34468;&#24066;&#22330;';
	}
	$mobile_lz = explode ("\n", str_replace ("\r", "", $mobile_lz_moren));
	foreach($mobile_lz as $key=>$value){
		$arr=explode('|',$value);
		$lz_types[]=$arr;
	}
	//�ֻ�����ת�·�����
	if($settings['mobile_index_new_dh']['value']) {
		$mobile_index_new_dh = explode ("\n", str_replace ("\r", "", $settings['mobile_index_new_dh']['value']));
		foreach($mobile_index_new_dh as $key=>$value){
			$arr=explode('|',$value);
			$mobile_index_new_dh_types[]=$arr;
		}
	}else {
		$mobile_index_new_dh_types = array();
	}
	foreach($gtypes_tmp as $tmp_key => $tmp_value) {
		$gtypes_tmp_array[$tmp_key][0] = 'plugin.php?id=aljtc&act=list&subrid='.intval($_COOKIE['subrid']).'&zufangtype='.intval($tmp_value['id']);
		$gtypes_tmp_array[$tmp_key][1] = $tmp_value['logo'];
		$gtypes_tmp_array[$tmp_key][2] = $tmp_value['subject'];
	}
	$mobile_index_new_dh_types = array_merge ($gtypes_tmp_array,$mobile_index_new_dh_types);
	$navtitle = $settings['daohang']['value'];
	$description = $settings['description']['value'];
	$metakeywords = $settings['daohang']['value'];
	$sharedata[logo] = $settings['share_logo']['value'];
	if($aljtc_seo['index']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'fz_name'=>$city_info['navtitle']?$city_info['navtitle']:$city_info['name']);
		list($navtitle, $description, $metakeywords) = get_seosetting('', $seodata, $aljtc_seo['index']);
	}
	include template($pluginid.':A_Model/index/aljtc');
}
function qb_pay($lp){//����Ǯ��֧������
	global $_G,$card_info,$card_user;
	$typeSettins = type_settins($lp['zufangtype'],$lp['subtype'],$lp['id']);
	$formsetting = $typeSettins['formsetting'];
	$price = $formsetting['price']>0 ? $formsetting['price'] : $formsetting['price'];
	if($_G['cache']['plugin']['aljtcc'] && $card_info['card_tc_post']>0 && $card_user){//��Ա��
		$price = substr(sprintf("%.3f",$price*($card_info['card_tc_post']/100)),0,-1);
	}
	if($price>0){
		$orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
		$orderarray=array(
			'orderid' => $orderid,
			'status' => 1,
			'cid' => $lp['id'],
			'uid' => $lp['uid'],
			'username' => $lp['username'],
			'submitdate' => TIMESTAMP,
			'stitle' => $lp['username'].'&#21457;&#24067;&#21516;&#22478;&#20449;&#24687;'.'&#12300;&#20449;&#24687;'.'id'.'��'.$lp['id'].'&#12301;',
			'payment' => 7,
			'pid'  => 8,//ͬ�Ƿ�����Ϣ�շ�
			'browser'  => $_SERVER['HTTP_USER_AGENT'],
			'fz_id'  => $_GET['fz_id'],
			'order_type' => ($card_info['card_tc_post']>0 && $card_user) ? 4 : 0
		);
		$orderarray['price'] = $price;
		$orderarray['mobile'] = 1;
		DB::insert('aljbd_goods_order',$orderarray);
		require_once 'source/plugin/aljqb/class/Qbapi.class.php';
		$qbapi = new Qbapi();
		$keyurlarray = array(
			'orderid' => $orderid,
			'time' => TIMESTAMP,
			'price' => $price,
			'keyname' => 'aljtc',
			'return_url' => rtrim($qbapi->siteurl, '/').'/plugin.php?id=aljtc&act=member',
			'key' => $_G['cache']['plugin']['aljtc']['qb_key'],
		);
		$url = $qbapi->createUrl($keyurlarray);
		return $url;
	}else{
		return 1;
	}
}
function qb_pay_tel($price,$id){//�鿴�绰����-����Ǯ��֧������
	global $_G,$card_info,$card_user;
	$lp = C::t('#aljtc#aljtc')->fetch($id);
	if($_G['cache']['plugin']['aljtcc'] && $card_info['card_tc_post']>0 && $card_user){//��Ա��
		$price = substr(sprintf("%.3f",$price*($card_info['card_tc_post']/100)),0,-1);
	}
	if($price>0 && $lp){
		$orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
		$orderarray=array(
			'orderid' => $orderid,
			'status' => 1,
			'cid' => $lp['id'],
			'uid' => $_G['uid'],
			'username' => $_G['username'],
			'submitdate' => TIMESTAMP,
			'stitle' => $_G['username'].'&#26597;&#30475;&#21516;&#22478;&#20449;&#24687;&#30005;&#35805;'.$price.'&#20803;&#12300;&#20449;&#24687;'.'id'.'��'.$lp['id'].'&#12301;',
			'payment' => 7,
			'pid'  => 8,//ͬ�Ƿ�����Ϣ�շ�
			'browser'  => $_SERVER['HTTP_USER_AGENT'],
			'fz_id'  => $_GET['fz_id'],
			'd'  => 1,
			'order_type' => ($card_info['card_tc_post']>0 && $card_user) ? 4 : 0
		);
		$orderarray['price'] = $price;
		$orderarray['mobile'] = 1;
		DB::insert('aljbd_goods_order',$orderarray);
		require_once 'source/plugin/aljqb/class/Qbapi.class.php';
		$qbapi = new Qbapi();
		$keyurlarray = array(
			'orderid' => $orderid,
			'time' => TIMESTAMP,
			'price' => $price,
			'keyname' => 'aljtc',
			'return_url' => rtrim($qbapi->siteurl, '/').'/plugin.php?id=aljtc&act=view&lid='.$lp['id'],
			'key' => $_G['cache']['plugin']['aljtc']['qb_key'],
		);
		$url = $qbapi->createUrl($keyurlarray);
		return $url;
	}else{
		return 1;
	}
}
function discuzcode_mobile($message, $smileyoff=0, $bbcodeoff=0, $htmlon = 0, $allowsmilies = 1, $allowbbcode = 1, $allowimgcode = 1, $allowhtml = 0, $jammer = 0, $parsetype = '0', $authorid = '0', $allowmediacode = '0', $pid = 0, $lazyload = 0, $pdateline = 0, $first = 0) {
	global $_G;

	static $authorreplyexist;

	if($pid && strpos($message, '[/password]') !== FALSE) {
		if($authorid != $_G['uid'] && !$_G['forum']['ismoderator']) {
			$message = preg_replace("/\s?\[password\](.+?)\[\/password\]\s?/ie", "parsepassword('\\1', \$pid)", $message);
			if($_G['forum_discuzcode']['passwordlock'][$pid]) {
				return '';
			}
		} else {
			$message = preg_replace("/\s?\[password\](.+?)\[\/password\]\s?/ie", "", $message);
			$_G['forum_discuzcode']['passwordauthor'][$pid] = 1;
		}
	}

	if($parsetype != 1 && !$bbcodeoff && $allowbbcode && (strpos($message, '[/code]') || strpos($message, '[/CODE]')) !== FALSE) {
		$message = preg_replace("/\s?\[code\](.+?)\[\/code\]\s?/ies", "codedisp('\\1')", $message);
	}

	$msglower = strtolower($message);

	$htmlon = $htmlon && $allowhtml ? 1 : 0;

	if(!$htmlon) {
		$message = dhtmlspecialchars($message);
	} else {
		$message = preg_replace("/<script[^\>]*?>(.*?)<\/script>/i", '', $message);
	}

	if($_G['setting']['plugins']['func'][HOOKTYPE]['discuzcode']) {
		$_G['discuzcodemessage'] = & $message;
		$param = func_get_args();
		hookscript('discuzcode', 'global', 'funcs', array('param' => $param, 'caller' => 'discuzcode'), 'discuzcode');
	}

	if(!$smileyoff && $allowsmilies) {
		$message = parsesmiles($message);
	}

	if($_G['setting']['allowattachurl'] && strpos($msglower, 'attach://') !== FALSE) {
		$message = preg_replace("/attach:\/\/(\d+)\.?(\w*)/ie", "parseattachurl('\\1', '\\2', 1)", $message);
	}

	if($allowbbcode) {
		if(strpos($msglower, 'ed2k://') !== FALSE) {
			$message = preg_replace("/ed2k:\/\/(.+?)\//e", "parseed2k('\\1')", $message);
		}
	}

	if(!$bbcodeoff && $allowbbcode) {
		if(strpos($msglower, '[/url]') !== FALSE) {
			$message = preg_replace("/\[url(=((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\/\/|www\.|mailto:)?([^\r\n\[\"']+?))?\](.+?)\[\/url\]/ies", "parseurl('\\1', '\\5', '\\2')", $message);
		}
		if(strpos($msglower, '[/email]') !== FALSE) {
			$message = preg_replace("/\[email(=([a-z0-9\-_.+]+)@([a-z0-9\-_]+[.][a-z0-9\-_.]+))?\](.+?)\[\/email\]/ies", "parseemail('\\1', '\\4')", $message);
		}

		$nest = 0;
		while(strpos($msglower, '[table') !== FALSE && strpos($msglower, '[/table]') !== FALSE){
			$message = preg_replace("/\[table(?:=(\d{1,4}%?)(?:,([\(\)%,#\w ]+))?)?\]\s*(.+?)\s*\[\/table\]/ies", "parsetable('\\1', '\\2', '\\3')", $message);
			if(++$nest > 4) break;
		}

		$message = str_replace(array(
			'[/color]', '[/backcolor]', '[/size]', '[/font]', '[/align]', '[b]', '[/b]', '[s]', '[/s]', '[hr]', '[/p]',
			'[i=s]', '[i]', '[/i]', '[u]', '[/u]', '[list]', '[list=1]', '[list=a]',
			'[list=A]', "\r\n[*]", '[*]', '[/list]', '[indent]', '[/indent]', '[/float]'
			), array(
			'</font>', '</font>', '</font>', '</font>', '</div>', '<strong>', '</strong>', '<strike>', '</strike>', '<hr class="l" />', '</p>', '<i class="pstatus">', '<i>',
			'</i>', '<u>', '</u>', '<ul>', '<ul type="1" class="litype_1">', '<ul type="a" class="litype_2">',
			'<ul type="A" class="litype_3">', '<li>', '<li>', '</ul>', '<blockquote>', '</blockquote>', '</span>'
			), preg_replace(array(
			"/\[color=([#\w]+?)\]/i",
			"/\[color=((rgb|rgba)\([\d\s,]+?\))\]/i",
			"/\[backcolor=([#\w]+?)\]/i",
			"/\[backcolor=((rgb|rgba)\([\d\s,]+?\))\]/i",
			"/\[size=(\d{1,2}?)\]/i",
			"/\[size=(\d{1,2}(\.\d{1,2}+)?(px|pt)+?)\]/i",
			"/\[font=([^\[\<]+?)\]/i",
			"/\[align=(left|center|right)\]/i",
			"/\[p=(\d{1,2}|null), (\d{1,2}|null), (left|center|right)\]/i",
			"/\[float=left\]/i",
			"/\[float=right\]/i"

			), array(
			"<font color=\"\\1\">",
			"<font style=\"color:\\1\">",
			"<font style=\"background-color:\\1\">",
			"<font style=\"background-color:\\1\">",
			"<font size=\"\\1\">",
			"<font style=\"font-size:\\1\">",
			"<font face=\"\\1\">",
			"<div align=\"\\1\">",
			"<p style=\"line-height:\\1px;text-indent:\\2em;text-align:\\3\">",
			"<span style=\"float:left;margin-right:5px\">",
			"<span style=\"float:right;margin-left:5px\">"
			), $message));

		if($pid && !defined('IN_MOBILE')) {
			$message = preg_replace("/\s?\[postbg\]\s*([^\[\<\r\n;'\"\?\(\)]+?)\s*\[\/postbg\]\s?/ies", "parsepostbg('\\1', '$pid')", $message);
		} else {
			$message = preg_replace("/\s?\[postbg\]\s*([^\[\<\r\n;'\"\?\(\)]+?)\s*\[\/postbg\]\s?/is", "", $message);
		}

		if($parsetype != 1) {
			if(strpos($msglower, '[/quote]') !== FALSE) {
				$message = preg_replace("/\s?\[quote\][\n\r]*(.+?)[\n\r]*\[\/quote\]\s?/is", tpl_quote(), $message);
			}
			if(strpos($msglower, '[/free]') !== FALSE) {
				$message = preg_replace("/\s*\[free\][\n\r]*(.+?)[\n\r]*\[\/free\]\s*/is", tpl_free(), $message);
			}
		}
		if(!defined('IN_MOBILE')) {
			if(strpos($msglower, '[/media]') !== FALSE) {
				$message = preg_replace("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/ies", $allowmediacode ? "parsemedia('\\1', '\\2')" : "bbcodeurl('\\2', '<a href=\"{url}\" target=\"_blank\">{url}</a>')", $message);
			}
			if(strpos($msglower, '[/audio]') !== FALSE) {
				$message = preg_replace("/\[audio(=1)*\]\s*([^\[\<\r\n]+?)\s*\[\/audio\]/ies", $allowmediacode ? "parseaudio('\\2', 400)" : "bbcodeurl('\\2', '<a href=\"{url}\" target=\"_blank\">{url}</a>')", $message);
			}
			if(strpos($msglower, '[/flash]') !== FALSE) {
				$message = preg_replace("/\[flash(=(\d+),(\d+))?\]\s*([^\[\<\r\n]+?)\s*\[\/flash\]/ies", $allowmediacode ? "parseflash('\\2', '\\3', '\\4');" : "bbcodeurl('\\4', '<a href=\"{url}\" target=\"_blank\">{url}</a>')", $message);
			}
		} else {
			if(strpos($msglower, '[/media]') !== FALSE) {
				$message = preg_replace("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/is", "[media]\\2[/media]", $message);
			}
			if(strpos($msglower, '[/audio]') !== FALSE) {
				$message = preg_replace("/\[audio(=1)*\]\s*([^\[\<\r\n]+?)\s*\[\/audio\]/is", "[media]\\2[/media]", $message);
			}
			if(strpos($msglower, '[/flash]') !== FALSE) {
				$message = preg_replace("/\[flash(=(\d+),(\d+))?\]\s*([^\[\<\r\n]+?)\s*\[\/flash\]/is", "[media]\\4[/media]", $message);
			}
		}

		if($parsetype != 1 && $allowbbcode < 0 && isset($_G['cache']['bbcodes'][-$allowbbcode])) {
			$message = preg_replace($_G['cache']['bbcodes'][-$allowbbcode]['searcharray'], $_G['cache']['bbcodes'][-$allowbbcode]['replacearray'], $message);
		}
		if($parsetype != 1 && strpos($msglower, '[/hide]') !== FALSE && $pid) {
			if($_G['setting']['hideexpiration'] && $pdateline && (TIMESTAMP - $pdateline) / 86400 > $_G['setting']['hideexpiration']) {
				$message = preg_replace("/\[hide[=]?(d\d+)?[,]?(\d+)?\]\s*(.*?)\s*\[\/hide\]/is", "\\3", $message);
				$msglower = strtolower($message);
			}
			if(strpos($msglower, '[hide=d') !== FALSE) {
				$message = preg_replace("/\[hide=(d\d+)?[,]?(\d+)?\]\s*(.*?)\s*\[\/hide\]/ies", "expirehide('\\1','\\2','\\3', $pdateline)", $message);
				$msglower = strtolower($message);
			}
			if(strpos($msglower, '[hide]') !== FALSE) {
				if($authorreplyexist === null) {
					if(!$_G['forum']['ismoderator']) {
						if($_G['uid']) {
							$authorreplyexist = C::t('forum_post')->fetch_pid_by_tid_authorid($_G['tid'], $_G['uid']);
						}
					} else {
						$authorreplyexist = TRUE;
					}
				}
				if($authorreplyexist) {
					$message = preg_replace("/\[hide\]\s*(.*?)\s*\[\/hide\]/is", tpl_hide_reply(), $message);
				} else {
					$message = preg_replace("/\[hide\](.*?)\[\/hide\]/is", tpl_hide_reply_hidden(), $message);
					$message = '<script type="text/javascript">replyreload += \',\' + '.$pid.';</script>'.$message;
				}
			}
			if(strpos($msglower, '[hide=') !== FALSE) {
				$message = preg_replace("/\[hide=(\d+)\]\s*(.*?)\s*\[\/hide\]/ies", "creditshide(\\1,'\\2', $pid, $authorid)", $message);
			}
		}
	}

	if(!$bbcodeoff) {
		if($parsetype != 1 && strpos($msglower, '[swf]') !== FALSE) {
			$message = preg_replace("/\[swf\]\s*([^\[\<\r\n]+?)\s*\[\/swf\]/ies", "bbcodeurl('\\1', ' <img src=\"'.STATICURL.'image/filetype/flash.gif\" align=\"absmiddle\" alt=\"\" /> <a href=\"{url}\" target=\"_blank\">Flash: {url}</a> ')", $message);
		}

		if(defined('IN_MOBILE') && !defined('TPL_DEFAULT') && !defined('IN_MOBILE_API')) {
			$allowimgcode = 1;
		}

		$attrsrc = !IS_ROBOT && $lazyload ? 'file' : 'src';
		if(strpos($msglower, '[/img]') !== FALSE) {
			$message = preg_replace(array(
				"/\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/ies",
				"/\[img=(\d{1,4})[x|\,](\d{1,4})\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/ies"
			), $allowimgcode ? array(
				"parseimg(0, 0, '\\1', ".intval($lazyload).", ".intval($pid).", 'onmouseover=\"img_onmouseoverfunc(this)\" ".($lazyload ? "lazyloadthumb=\"1\"" : "onload=\"thumbImg(this)\"")."')",
				"parseimg('\\1', '\\2', '\\3', ".intval($lazyload).", ".intval($pid).")"
			) : ($allowbbcode ? array(
				(!defined('IN_MOBILE') ? "bbcodeurl('\\1', '<a href=\"{url}\" target=\"_blank\">{url}</a>')" : "bbcodeurl('\\1', '')"),
				(!defined('IN_MOBILE') ? "bbcodeurl('\\3', '<a href=\"{url}\" target=\"_blank\">{url}</a>')" : "bbcodeurl('\\3', '')"),
			) : array("bbcodeurl('\\1', '{url}')", "bbcodeurl('\\3', '{url}')")), $message);
		}
	}
	//debug($message);
	for($i = 0; $i <= $_G['forum_discuzcode']['pcodecount']; $i++) {
		$message = str_replace("[\tDISCUZ_CODE_$i\t]", $_G['forum_discuzcode']['codehtml'][$i], $message);
	}

	unset($msglower);

	if($jammer) {
		$message = preg_replace("/\r\n|\n|\r/e", "jammer()", $message);
	}

	if($first) {
		if(helper_access::check_module('group')) {
			$message = preg_replace("/\[groupid=(\d+)\](.*)\[\/groupid\]/i", lang('forum/template', 'fromgroup').': <a href="forum.php?mod=forumdisplay&fid=\\1" target="_blank">\\2</a>', $message);
		} else {
			$message = preg_replace("/(\[groupid=\d+\].*\[\/groupid\])/i", '', $message);
		}

	}
	return $htmlon ? $message : nl2br(str_replace(array("\t", '   ', '  '), array('&nbsp; &nbsp; &nbsp; &nbsp; ', '&nbsp; &nbsp;', '&nbsp;&nbsp;'), $message));
}

function create_token($biaoshi) {
	//��ǰʱ���

	$timestamp = TIMESTAMP;
	dsetcookie($biaoshi,$timestamp);
	return md5( $timestamp );
}
function valid_token($alj_token,$getcook,$biaoshi) {
	if(isset($getcook) && isset($alj_token) && $alj_token == md5($getcook))
	{
		//����ȷ�������������ٵ�
		dsetcookie($biaoshi,'');
		return true;
	}
	return false;
}
function is_mobile_l($mobile) {
       return preg_match('#^\d[\d-]{3,20}\d$#', $mobile) ? true : false;
}
function getaljurl($geturl,$param){
	if($param){
		foreach($param as $k => $v){
		$geturl[$k] = $v;
		}
	}
	require_once libfile('function/home');
	return 'plugin.php?'.url_implode($geturl);
}
function ajaxPostCharSet_aljtc($arr) {
	if(is_array($arr)){
		if (strtolower(CHARSET) == 'gbk') {
			foreach ($arr as $key => $val) {
				if(is_array($val)){
					$pt_goods[$key] = ajaxPostCharSet_aljtc($val);
				}else{
					$pt_goods[$key] = diconv($val,'gbk','utf-8');
				}

			}
			return $pt_goods;
		}
		return $arr;
	} else {
		if (strtolower(CHARSET) == 'gbk') {
			return diconv($arr,'gbk','utf-8');
		}
		return $arr;
	}
}
function customedit($data) {
	foreach($data as $tmp_key => $tmp_value) {
		if($tmp_value['custom_type'] == 'select') {
			if($tmp_value['custom_extra']) {
				$tmp_array = explode ("\n", str_replace ("\r", "", $tmp_value['custom_extra']));
				foreach($tmp_array as $tmp_key_first => $tmp_value_first) {
					$tmp_value_first = explode("=",$tmp_value_first);
					$new_array[$tmp_value_first[0]]=$tmp_value_first[1];
				}
				$tmp_value['custom_extra'] = $new_array;
				unset($new_array);
			}
			$data[$tmp_key] = $tmp_value;
		}
	}
	return $data;
}
function type_settins ($typeid,$sid=0,$lid=0){
    global $pluginid,$_G;
    if($sid) {
        $pos = C::t('#aljtc#'.$pluginid.'_position')->fetch_all_by_upid($sid);
        $pos_formsetting_1 = DB::fetch_all('select * from %t where typeid=%d',array($pluginid.'_typesettings',$sid));
        foreach ($pos_formsetting_1 as $pfk => $pfv){
            $pos_formsetting[$pfv['type_key']] = $pfv['type_value'];
        }
    }
    $one_formsetting_1 = DB::fetch_all('select * from %t where typeid=%d ',array($pluginid.'_typesettings',$typeid));
    foreach ($one_formsetting_1 as $pfk => $pfv){
        $one_formsetting[$pfv['type_key']] = $pfv['type_value'];
    }
    if($sid && $pos_formsetting){
        foreach($pos_formsetting as $p_t_k => $p_t_v){
            if($p_t_v){
                $one_formsetting[$p_t_k] = $p_t_v;
            }
        }
        $formsetting = $one_formsetting;
    }else{
        $formsetting = $one_formsetting;
    }
    return array('formsetting'=>$formsetting,'is_see_tel'=>intval(DB::result_first('select count(*) from %t where uid=%d and lid=%d',array('aljtc_see_tel',$_G['uid'],$lid))));
}
function GsetCookie($name, $value, $expire = null){
    //����ʱ��
    if(empty($expire)) $expire = time() + 86400;
    $_COOKIE[$name] = $value;
    //�ж�value�Ƿ�������
    if(is_array($value)){
        foreach ($value as $k => $v){
            if(empty($v)) continue;
            setcookie($name . "[$k]", $v, $expire);
        }
    }else{
        setcookie($name, $value, $expire);
    }
}
function ajaxGetCharSet_aljtc($arr) {
	if(is_array($arr)){
		if (strtolower(CHARSET) == 'gbk') {
			foreach ($arr as $key => $val) {
				if(is_array($val)){
					$pt_goods[$key] = ajaxGetCharSet_aljtc($val);
				}else{
					$pt_goods[$key] = diconv($val,'utf-8','gbk');
				}

			}
			return $pt_goods;
		}
		return $arr;
	} else {
		if (strtolower(CHARSET) == 'gbk') {
			return diconv($arr,'utf-8','gbk');
		}
		return $arr;
	}

}
function saveimg($pic) {
    global $image_path;
    $rand = rand(100, 999);
    $pics = date("YmdHis").$rand.'.png';
    $dir = $image_path.date('Ymd',TIMESTAMP).'/';
    if(!is_dir($dir)) {
        @mkdir($dir, 0777);
    }
    $src = $dir. $pics;
    if(file_put_contents($src,file_get_contents($pic))) {
        return $src;
    }else {
        return '';
    }

}
//From: Dism_taobao-com
?>
