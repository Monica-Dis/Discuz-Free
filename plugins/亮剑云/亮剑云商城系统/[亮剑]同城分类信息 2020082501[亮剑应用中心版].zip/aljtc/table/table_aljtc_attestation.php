<?php

/*
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ��ϵDISM.TAOBAO.COM
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljtc_attestation extends discuz_table {

    public function __construct() {

        $this->_table = 'aljtc_attestation';
        $this->_pk = 'id';

        parent::__construct();
    }

    public function fetch_uid_type($uid=0,$type=0) {
		$con[] = $this->_table;
        $where = 'where 1 ';
		if ($uid) {
            $con[] = $uid;
            $where.=" and uid = %d";
        }
		if ($type) {
            $con[] = $type;
            $where.=" and type = %d";
        }
        return DB::result_first("select count(*) from %t ". $where, $con);
    }
	public function fetch_uid_type_sign($uid=0,$type=0,$sign=0) {
		$con[] = $this->_table;
        $where = 'where 1 ';
		if ($uid) {
            $con[] = $uid;
            $where.=" and uid = %d";
        }
		if ($type) {
            $con[] = $type;
            $where.=" and type = %d";
        }
		if ($sign) {
            $con[] = $sign;
            $where.=" and sign = %d";
        }
        return DB::fetch_first("select * from %t ". $where, $con);
    }
   public function count_by_status($status=0){
        return DB::result_first("select count(*) from %t where sign=%d and type<3 ",array($this->_table,$status));
    }
    public function fetch_all_by_status($status,$start=0,$perpage=0,$fz_id=0){
        if($fz_id>0){
            $where = ' and fz_id='.$fz_id;
        }
        return DB::fetch_all("select * from %t where sign=%d ".$where." and type<3 limit %d,%d",array($this->_table,$status,$start,$perpage));
    }
    public function count_by_status_store($status=0){
        return DB::result_first("select count(*) from %t where sign=%d and type=3 ",array($this->_table,$status));
    }
    public function fetch_all_by_status_store($status,$start=0,$perpage=0,$fz_id=0){
        if($fz_id>0){
            $where = ' and fz_id='.$fz_id;
        }
        return DB::fetch_all("select * from %t where sign=%d ".$where." and type=3 limit %d,%d",array($this->_table,$status,$start,$perpage));
    }
}
//From: Dism_taobao-com
?>