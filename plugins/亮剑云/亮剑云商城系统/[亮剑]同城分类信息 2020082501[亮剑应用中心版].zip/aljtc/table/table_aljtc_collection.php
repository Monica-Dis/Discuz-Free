<?php

/*
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ��ϵDISM.TAOBAO.COM
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljtc_collection extends discuz_table {

    public function __construct() {

        $this->_table = 'aljtc_collection';
        $this->_pk = 'id';

        parent::__construct();
    }
    public function fetch_all_by_dateline(){
        return DB::fetch_all('select b.* from %t a left join %t b on a.lid=b.id where a.dateline>%d-86400',array($this->_table,'aljes',TIMESTAMP));
    }

}
//From: Dism_taobao-com
?>