<?php
	define('DISABLEXSSCHECK',true);
	require '../../../../source/class/class_core.php';
	$discuz = C::app();
	$discuz->init();
  	loadcache('plugin');
    
    require_once DISCUZ_ROOT .'./source/plugin/aljqb/class/Qbapi.class.php';
    
	if(file_exists(DISCUZ_ROOT .'./source/plugin/aljqb/class/Getdata.class.php')){
		require_once DISCUZ_ROOT .'./source/plugin/aljqb/class/Getdata.class.php';
		$getdata = new Getdata();
	}
	//file_put_contents('d.txt',$key."\r",FILE_APPEND);
	//file_put_contents('d.txt',$_GET['key']."\r",FILE_APPEND);
	
	$data['transaction_id'] = $_GET['aljorderid'];
	$qbapi = new Qbapi();
	$keyarray = array(
		'aljorderid'=> $_GET['aljorderid'],
		'paytime' => $_GET['paytime'],
		'orderid' => $_GET['orderid'],
    );
    
	if($_GET['key']) {
		$keyarray['key'] = $_G['cache']['plugin']['aljtc']['qb_key'];
		$key = $qbapi->createKey($keyarray);
		$getkey = $_GET['key'];
	}elseif(file_exists(DISCUZ_ROOT .'./source/plugin/aljqb/class/Getdata.class.php')) {
		$appinfo = $getdata->getAppParam();
		$appinfo['posttime']=$_GET['posttime'];
		$key = $getdata->CreateAppSign($appinfo);
		$getkey = $_GET['sign'];
    }
	if($getkey && $getkey && $key == $getkey) {
        
        $order = DB::fetch_first('select * from %t where orderid=%s',array('aljbd_goods_order',$_GET['orderid']));
        $aljtc = C::t('#aljtc#aljtc') -> fetch($order['cid']);
		if($order['status'] == 1){
            
            $user = getuserbyuid($aljtc['uid']);
            $o_user = getuserbyuid($order['uid']);
            if($order['d'] == 1){
                DB::insert('aljtc_see_tel',array(
                    'uid' => $order['uid'],
                    'username' => $o_user['username'],
                    'lid' => $order['cid'],
                    'addtime' => TIMESTAMP,
                ));
            }else{
                $settings=DB::fetch_all('select * from %t',array('aljtc_setting'));
                foreach($settings as $tmp_key => $tmp_value) {
                    $tmp_settings[$tmp_value['key']] = $tmp_value;
                }
                $settings = $tmp_settings;
                if(!in_array($_G['groupid'],unserialize($settings['m_groups']['value'])) && $settings['isreview']['value']){
                    $status=0;
                    $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
                    foreach($groupids as $g_uid){
                        notification_add($g_uid['uid'], 'system','<a href="plugin.php?id=aljtc&act=member&i=1">'.lang('plugin/aljtc','aljtc_56').'</a>',array('from_idtype'  => $pluginid,'from_id' => $insertid));
                    }
                }else{
                    $status=1;
                }
                
                $updatearray = array('state'=>$status);
                
                C::t('#aljtc#aljtc') -> update($order['cid'],$updatearray);
            }
            
            
            DB::update('aljbd_goods_order',array('admin'=>$qborder['trade_mod'],'status' => 2, 'buyer' => $data['transaction_id'], 'confirmdate' => $_GET['paytime']),array('orderid'=>$_GET['orderid']));
            $fz_path = DISCUZ_ROOT . "source/plugin/aljtfz/include";
            if($_G['cache']['plugin']['aljtfz'] && is_file("$fz_path/fz_statistics.php")){
                include_once "$fz_path/fz_statistics.php";
            }
            //s ������ѯ���� �ֵ�
            if($_G['cache']['plugin']['aljhhr']['is_aljhhr']){
                $hhr_path = DISCUZ_ROOT . "source/plugin/aljhhr/function/function.php";
                if(is_file($hhr_path)){
                    include_once $hhr_path;
                    hhrDivideInto($order,'aljtc');
                }
            }
            //e ������ѯ����
            if($_G['cache']['plugin']['aljtsq']){
                //ƽ̨����
                require_once DISCUZ_ROOT . 'source/plugin/aljhtx/class/class_aljhtx.php';
                T::platformRevenue($order,$order['stitle'],$order['price'],'aljtc');
            }
		}
        echo 'success';
        exit;
    }
?>
