<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljtc_praise` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`lid` int(11) NOT NULL,
	`uid` int(11) NOT NULL,
	`dateline` int(11) NOT NULL,
	PRIMARY KEY (`id`),
	KEY `uid` (`uid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_goods_order` (
	`orderid` char(32) NOT NULL DEFAULT '',
	`status` tinyint(3) NOT NULL,
	`buyer` char(50) NOT NULL DEFAULT '',
	`admin` char(15) NOT NULL DEFAULT '',
	`uid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
	`username` varchar(255) NOT NULL,
	`shop_id` int(11) NOT NULL,
	`stitle` varchar(255) NOT NULL,
	`amount` int(10) UNSIGNED NOT NULL DEFAULT '0',
	`price` float(7,2) UNSIGNED NOT NULL DEFAULT '0.00',
	`original_price` decimal(8,2) UNSIGNED NOT NULL DEFAULT '0.00',
	`submitdate` int(10) UNSIGNED NOT NULL DEFAULT '0',
	`confirmdate` int(10) UNSIGNED NOT NULL DEFAULT '0',
	`email` char(40) NOT NULL DEFAULT '',
	`ip` char(15) NOT NULL DEFAULT '',
	`remarks` varchar(255) NOT NULL,
	`d` tinyint(3) NOT NULL,
	`address` text NOT NULL,
	`payment` char(50) NOT NULL DEFAULT '',
	`fare` decimal(8,2) UNSIGNED NOT NULL DEFAULT '0.00',
	`pid` tinyint(3) NOT NULL,
	`category` tinyint(3) NOT NULL,
	`fare_desc` int(11) NOT NULL,
	`mobile` int(11) NOT NULL,
	`proportion` int(11) NOT NULL,
	`browser` varchar(255) NOT NULL,
	`deliverydate` int(10) UNSIGNED NOT NULL DEFAULT '0',
	`ext` int(11) NOT NULL,
	`pay_ext` int(11) NOT NULL,
	`discount` decimal(8,2) UNSIGNED NOT NULL DEFAULT '0.00',
	`bili` int(10) NOT NULL,
	`commodity_type` tinyint(3) NOT NULL,
	`get_to_the_shop` tinyint(3) NOT NULL,
	`collage_order` char(32) NOT NULL,
	`collage_num` int(10) NOT NULL,
	`cid` int(10) NOT NULL,
	`opentime` int(11) NOT NULL,
	`give_integral` int(11) NOT NULL,
	`pay_integral` decimal(10,2) NOT NULL,
	`store_id` int(11) NOT NULL,
	`store_address` text NOT NULL,
	`order_type` tinyint(4) NOT NULL COMMENT '1=ms 2=fx 3=wm',
	`deduction` decimal(10,2) NOT NULL,
	UNIQUE KEY `orderid` (`orderid`),
	KEY `submitdate` (`submitdate`),
	KEY `uid` (`uid`,`submitdate`)
  );
  CREATE TABLE IF NOT EXISTS `pre_aljtc_see_tel` (
	`id` int(10) NOT NULL AUTO_INCREMENT,
	`uid` int(11) DEFAULT '0',
	`type` int(11) DEFAULT '0',
	`lid` int(11) DEFAULT '0',
	`addtime` int(11) DEFAULT '0',
	`username` varchar(255) DEFAULT NULL,
	PRIMARY KEY (`id`),
	KEY `lid` (`lid`)
  )
EOF;
runquery($sql);
$sql ="ALTER TABLE  ".DB::table('aljtc_comment')." ADD  `uuid` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_comment')." ADD  `uusername` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_comment')." ADD  `status` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods_order')." ADD  `fz_id` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_attestation')." ADD  `fz_id` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc')." ADD  `fz_id` int(11) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE  ".DB::table('aljtc')." ADD  `pic` TEXT NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc')." ADD  `lat` decimal(10,6) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc')." ADD  `lng` decimal(10,6) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE  ".DB::table('aljtc_attestation')." ADD `reason` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE  ".DB::table('aljtc_position')." ADD  `is_open` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$expiry_time = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'expiry_time\'', array('aljtc'), true);
if(!$expiry_time){
    $sql = <<<EOF
ALTER TABLE `pre_aljtc` ADD INDEX(`lat`);
ALTER TABLE `pre_aljtc` ADD INDEX(`lng`);
ALTER TABLE `pre_aljtc` ADD INDEX(`addtime`);
ALTER TABLE `pre_aljtc` ADD INDEX(`updatetime`);
ALTER TABLE `pre_aljtc` ADD INDEX(`displayorder`);
ALTER TABLE `pre_aljtc` ADD INDEX(`uid`);
ALTER TABLE `pre_aljtc` ADD INDEX(`topetime`);
ALTER TABLE `pre_aljtc` ADD INDEX(`fz_id`);
ALTER TABLE `pre_aljtc` ADD `expiry_time` INT(11) NOT NULL;
ALTER TABLE `pre_aljtc` ADD INDEX(`expiry_time`);
EOF;
    runquery($sql);
}
require_once 'source/plugin/aljtc/include/initalData.php';
$finish = TRUE;
?>