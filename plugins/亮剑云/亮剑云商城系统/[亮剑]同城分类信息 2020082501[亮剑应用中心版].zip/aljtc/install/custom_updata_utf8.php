﻿<?php
require_once libfile('function/plugin');
$install_timestamp = TIMESTAMP;
$install_eol = "\\r\\n";
$sql = <<<EOF
replace INTO `pre_aljtc_setting` (`key`, `value`) VALUES
('mobile_index_new_dh', ''),
('mobile_index_ad', ''),
('daohang', '亮剑同城分类信息'),
('mobile_integral_recharge', ''),
('logo', ''),
('new_logo', ''),
('mobile_logo', ''),
('qrcode_logo', ''),
('mhot', ''),
('mhotmore', ''),
('mobile_index_new_lz', ''),
('image_path', ''),
('uploadwidth', ''),
('allbackcolor', '#3FB0E3'),
('mianzeinfo', '免责声明：本平台发布的所有信息（收费、免费）展示，内容本身与平台本身无关，平台不负任何责任。'),
('mobile_label', ''),
('isreview', '1'),
('releaseextcredit', '2'),
('releasepay', '1'),
('is_forum_mobile', '0'),
('is_plugin_rz', '0'),
('no_rz_post_num', '2'),
('rz_post_num', '10'),
('r_tsy', '友情提示：{$install_eol}1、请上传清晰、完整、文字可识别的图片；上传的图片尺寸大于400*400像素；{$install_eol}2、身份证姓名等信息需要与本站一致；{$install_eol}3、如未通过认证，请检查照片上传是否正确，是否有涂改、PS痕迹，请勿上传电子版、复印版名片。{$install_eol}4、个人认证与商家认证申请一个即可，多次提交会覆盖上次提交的信息。（如：个人认证提交后再提交商家认证时，会删除个人认证信息保留商家认证，反之同理）{$install_eol}5、认证通过后，修改提交将重新收费待审核。'),
('r_ext', ''),
('r_pay', ''),
('shengming', '(^_^)联系的时候告诉我是在{sitename}看到的这条消息'),
('is_ping', '0'),
('reflashextcredit', '2'),
('reflashpay', '1'),
('topextcredit', '2'),
('toppay', '1'),
('m_groups', 'a:6:{i:0;s:1:"9";i:1;s:2:"10";i:2;s:2:"11";i:3;s:2:"12";i:4;s:2:"13";i:5;s:2:"14";}'),
('lj_groups', 'a:20:{i:0;s:1:"9";i:1;s:2:"10";i:2;s:2:"11";i:3;s:2:"12";i:4;s:2:"13";i:5;s:2:"14";i:6;s:2:"15";i:7;s:2:"20";i:8;s:2:"16";i:9;s:2:"17";i:10;s:2:"18";i:11;s:2:"19";i:12;s:1:"1";i:13;s:1:"2";i:14;s:1:"3";i:15;s:1:"4";i:16;s:1:"5";i:17;s:1:"6";i:18;s:1:"7";i:19;s:1:"8";}');
EOF;
runquery($sql);
?>