<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$settings=DB::fetch_all('select * from %t',array('aljtc_setting'));
foreach($settings as $tmp_key => $tmp_value) {
	$tmp_settings[$tmp_value['key']] = $tmp_value;
}
$settings = $tmp_settings;

if(($_G['cache']['plugin']['aljtc']['pc_look_mobile'] || $_GET['adminedit'] == 'yes') && $_GET['dzAdmin'] != '1' && !$_G['mobile']){
	if(strtolower(CHARSET) == 'gbk' && !$_GET[noget]){
		$_GET=T::ajaxGetCharSet($_GET);
	}
	define('IS_PC', 1);
}

$_G['setting']['hookscript'] = array();

$_G['setting']['hookscriptmobile'] = array();
if($_GET['dzAdmin'] != '1'){
	define('IN_MOBILE', 2);
	$_G['mobile'] = 2;
}
if(($_G['cache']['plugin']['mapp_share'] || $_G['cache']['plugin']['aljwx'] || $_G['cache']['plugin']['aljtwx']) && strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
    define('IN_MINI', '1');
}
$oss_domain = $_G['cache']['plugin']['aljoss']['cdn_domain'] ? $_G['cache']['plugin']['aljoss']['cdn_domain'] : $_G['cache']['plugin']['aljoss']['domain'];
if($_G['groupid'] == 1){
	$admin_status = 1;
}
$version = '201900911';
//if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false && $settings['mini_hide']['value']==1 && strpos(strtolower($_SERVER['HTTP_USER_AGENT']),"miniprogram") !== false){
if($settings['mini_hide']['value']==1){
	$hide_mini = 1;
}
if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0  || strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false){
	$isappbyme = true;
}
if(strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPPX')>0){
    $ismagapp = true;
}
if(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'qianfan') !== false){
    $isqianfanapp = true;
}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false && strpos(strtolower($_SERVER['HTTP_USER_AGENT']),"miniprogram") !== false){
	$ismini = 1;
}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
	$iswechat = 1;
}
$color = $settings['allbackcolor']['value'];

$fz_path = DISCUZ_ROOT . "source/plugin/aljtfz/include";
if(is_file("$fz_path/fz_cookie.php") && $_G['cache']['plugin']['aljtfz']['site_show']){include_once "$fz_path/fz_cookie.php";}
function tc_message($msg, $type='',$url = ''){
    if($_SERVER['REQUEST_METHOD'] == 'POST') {
        echo "<script>parent.tips('".$msg."','".$url."','".$type."');</script>";
		exit;
    }else{
        return $msg;
    }
    return false;
}
$_G['makehtml'] = 1;//������ͨ�û��鿴 SEO ����
?>