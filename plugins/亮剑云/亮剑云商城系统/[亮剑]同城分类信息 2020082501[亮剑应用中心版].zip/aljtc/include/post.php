<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$typeid = intval($lp['zufangtype']) ? intval($lp['zufangtype']) : intval($_GET['typeid']);
$sid = intval($lp['subtype']) ? intval($lp['subtype']) :intval($_GET['sid']);
$typeSettins = type_settins($typeid,$sid);
$formsetting = $typeSettins['formsetting'];
if($formsetting['statement']) {
    $tip = $formsetting['statement'];
}else {
    $tip = $settings['mianzeinfo']['value'];
}
if($formsetting['expiry_time']>0){
    $expiry_time_day = $formsetting['expiry_time'];
}else{
    $expiry_time_day = $_G['cache']['plugin']['aljtc']['expiry_time'];
}
if($formsetting['releasepay'] && $formsetting['releaseextcredit']){
    $settings['releasepay']['value'] = $formsetting['releasepay'];
    $settings['releaseextcredit']['value'] = $formsetting['releaseextcredit'];
}
if($_G['cache']['plugin']['aljqb']){
    if($formsetting['price']){
        $price = $formsetting['price'];
    }
    if($price > 0){
        $wallet = DB::fetch_first('select * from %t where uid=%d', array('aljqb_wallet', $_G['uid']));
        $my_price = $wallet['balance'] > 0 ? $wallet['balance'] : '0.00';
    }
}

//�Զ����ǩ
$mobile_label = explode ("\n", str_replace ("\r", "", $formsetting['mobile_label']));
if($_GET['act'] != 'view'){
    if($sid){
        $two_custom = DB::fetch_all('select * from %t where typeid=%d order by custom_order asc',array($pluginid.'_custom',$sid));
    }
    if($sid && $two_custom){
        $customlist = $two_custom;
    }else{
        $customlist = DB::fetch_all('select * from %t where typeid=%d order by custom_order asc',array($pluginid.'_custom',$typeid));
    }
    $customlist = customedit($customlist);
}
if($_GET['act'] == 'post'){
    if(!in_array($_G['groupid'],unserialize($settings['lj_groups']['value']))){//������������Ϣ�û�����ʾ
        $on_post_tip = lang('plugin/aljtc','aljtc_77');
        $no_post = 1;
        $no_post_qd_url = '1';
        
    }
    if($settings['is_forum_mobile']['value']){//δ��д�ֻ�����ʾ
        $profile = DB::fetch_first('select * from %t where uid=%d',array('common_member_profile',$_G['uid']));
        if(empty($profile['mobile'])){
            $on_post_tip = lang('plugin/aljtc','aljtc_76');
            $no_post = 1;
            $no_post_qd_url = '1';
            if($settings['forum_mobile_url']['value']){
                $no_post_qd_url = htmlspecialchars_decode($settings['forum_mobile_url']['value']);
            }
            
        }
    }
    //��֤
    $rz = DB::result_first("select count(*) from ".DB::table($pluginid.'_attestation')." where sign=1 and uid=".$_G['uid']);
    date_default_timezone_set('PRC');//�л����񹲺͹�ʱ��
    $todaytimestamp = strtotime(gmdate('Y-m-d 00:00:00',TIMESTAMP+3600*8));
    $post_num = DB :: result_first('select count(*) from %t where uid=%d and addtime>=%d',array($pluginid,$_G['uid'],$todaytimestamp));
    if($settings['is_plugin_rz']['value']){//ǿ����֤
        if(!$rz){//δ��֤��ʾ
            $on_post_tip = lang('plugin/aljtc','aljtc_75');
            $no_post = 1;
            $no_post_qd_url = 'plugin.php?id=aljtc&act=attes';
        }
    }else{
        if($settings['no_rz_post_num']['value']&&!$rz){//δ��֤������������ʾ
            if($post_num >= $settings['no_rz_post_num']['value']){
                $on_post_tip = lang('plugin/aljtc','aljtc_73').$settings['no_rz_post_num']['value'].lang('plugin/aljtc','aljtc_74');
                $no_post = 1;
                $no_post_qd_url = '1';
            }
        }
    }
    if($rz){
        if($settings['rz_post_num']['value']){
            if($post_num >= $settings['rz_post_num']['value']){//����֤������������ʾ
                $on_post_tip = lang('plugin/aljtc','aljtc_73').$settings['rz_post_num']['value'].lang('plugin/aljtc','aljtc_74');
                $no_post = 1;
                $no_post_qd_url = '1';
            }
        }
    }
}
if($card_info['card_tc_post']>0){
    if($price>0){
        $card_releasepay = substr(sprintf("%.3f",$price*($card_info['card_tc_post']/100)),0,-1).lang('plugin/aljtc','yuan');
    }else{
        $card_releasepay = floor($settings['releasepay']['value']*($card_info['card_tc_post']/100)).$_G['setting']['extcredits'][$settings['releaseextcredit']['value']]['title'];
    }
}
$pos = C::t('#aljtc#'.$pluginid.'_position')->fetch_all_by_upid($sid);
?>