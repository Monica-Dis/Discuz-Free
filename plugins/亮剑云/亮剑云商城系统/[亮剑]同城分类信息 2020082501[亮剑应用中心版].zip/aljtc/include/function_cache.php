<?php

/*
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ��ϵDISM.TAOBAO.COM
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function clearSavecacheAljtc () {
    savecache('aljtc_my_tongji', '');
}
//From: Dism_taobao-com
?>