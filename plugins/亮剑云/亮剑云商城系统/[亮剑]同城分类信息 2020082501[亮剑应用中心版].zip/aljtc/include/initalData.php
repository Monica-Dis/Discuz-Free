<?php

/*
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ��ϵDISM.TAOBAO.COM
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');
//Ĭ������
if(!C::t('#aljtc#aljtc_setting')->fetch('description')){
    C::t('#aljtc#aljtc_setting')->insert(array('key'=>'description','value'=>'&#36731;&#26494;&#25171;&#36896;&#26412;&#22320;&#24494;&#20449;&#21516;&#22478;&#20998;&#31867;&#20449;&#24687;&#24179;&#21488;'));
}

//��ҳ��Ϣ�Ϸ����
if(!C::t('#aljtc#aljtc_setting')->fetch('index_list_top_lz_ad')){
    $index_list_top_lz_ad = '<a href="#"><img src="source/plugin/aljtc/images/lz_ad_1.png" /></a>
<a href="#"><img src="source/plugin/aljtc/images/lz_ad_2.png" /></a>';
    C::t('#aljtc#aljtc_setting')->insert(array('key'=>'index_list_top_lz_ad','value'=>$index_list_top_lz_ad));
}
//ͬ���ȵ�����
if(!C::t('#aljtc#aljtc_setting')->fetch('mobile_index_hot_text')){
    $mobile_index_hot_text = '&#26377;&#30097;&#38382;&#32852;&#31995;&#24179;&#21488;&#23458;&#26381;|#
&#29992;&#25143;&#20449;&#24687;&#21457;&#24067;&#21327;&#35758;&#26465;&#27454;|#';
    C::t('#aljtc#aljtc_setting')->insert(array('key'=>'mobile_index_hot_text','value'=>$mobile_index_hot_text));
}
//�ҵ�ҳ��ƽ̨����
if(!C::t('#aljtc#aljtc_setting')->fetch('mobile_user_gg_text')){
    $mobile_user_gg_text = '&#26377;&#30097;&#38382;&#32852;&#31995;&#24179;&#21488;&#23458;&#26381;|#
&#29992;&#25143;&#20449;&#24687;&#21457;&#24067;&#21327;&#35758;&#26465;&#27454;|#';
    C::t('#aljtc#aljtc_setting')->insert(array('key'=>'mobile_user_gg_text','value'=>$mobile_user_gg_text));
}

//�ֻ���ͼ�Ĺ��
if(!C::t('#aljtc#aljtc_setting')->fetch('mobile_index_Photo_Ads')){
    $mobile_index_Photo_Ads = '&#25340;&#22242;|&#22810;&#20154;&#25340;&#22242;&#20215;&#26684;&#23454;&#24800;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_pt.png|#
&#24110;&#21161;&#20013;&#24515;|&#24179;&#21488;&#30334;&#23453;&#31665;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_bc.png|#
&#22242;&#36141;|&#38480;&#26102;&#31186;&#26432;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_tg.png|#
&#22825;&#22825;&#29305;&#24800;|&#39046;&#21048;&#19979;&#21333;&#26356;&#23454;&#24800;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_yh.png|#
&#25105;&#30340;&#24494;&#24215;|&#21160;&#21160;&#25163;&#25351;&#29378;&#36186;&#22806;&#22359;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_fx.png|#
&#38468;&#36817;&#21830;&#23478;|&#30465;&#26102;&#12289;&#30465;&#21147;&#12289;&#30465;&#24515;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_fj.png|#';
    C::t('#aljtc#aljtc_setting')->insert(array('key'=>'mobile_index_Photo_Ads','value'=>$mobile_index_Photo_Ads));
}
if(file_exists("source/plugin/aljqb/aljqb.inc.php")) {
    if(!DB::result_first('select count(*) from %t where pluginname=%s',array('aljqb_secretkey','aljtc'))){
        loadcache('plugin');
        DB::insert('aljqb_secretkey',array('pluginname'=>'aljtc','secretkey'=>'shenmikey123','tokenurl'=>rtrim($_G['siteurl'],'/').'/source/plugin/aljtc/pay/pay.php'));
    }
  }
//From: Dism_taobao-com
?>