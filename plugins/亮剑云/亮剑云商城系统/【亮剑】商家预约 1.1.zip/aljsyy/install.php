<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljbd_appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `qq` bigint(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `state` int(11) NOT NULL,
  `buid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bid` (`bid`)
)
EOF;
runquery($sql);
//�ҵ�ҳ���̼����� ԤԼ����
$mobile_user_business_center = C::t('#aljbd#aljbd_setting')->fetch('mobile_user_business_center');
if($mobile_user_business_center){
    $mobile_user_business_center['value'] .= '
source/plugin/aljht/static/img/aljbd/user/yuyue.png|plugin.php?id=aljsyy&act=appointment_list&mobile=2|&#39044;&#32422;&#31649;&#29702;';
    C::t('#aljbd#aljbd_setting')->update_value_by_key($mobile_user_business_center['value'],'mobile_user_business_center');
}
//finish to put your own code
$finish = TRUE;
?>