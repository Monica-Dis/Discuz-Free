<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pluginidarray = array('aljbd');
$_GET=dhtmlspecialchars($_GET);
$pluginid = 'aljbd';
$aljbdlang['template']['Booking_Management'] = '&#39044;&#32422;&#31649;&#29702;';//ԤԼ����
$pluginid = !in_array($pluginid, $pluginidarray) ? '' : $pluginid;
if(!$pluginid){
	showmessage('&#26080;&#26435;&#25805;&#20316;');
}
$is_plugin = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin',$pluginid));
if(!$is_plugin){
	showmessage('&#26242;&#26410;&#23433;&#35013;&#27492;&#25554;&#20214;&#65281;');
}
if(!$_G['cache']['plugin']['aljsyy'] ['is_yy']){
	showmessage('&#26080;&#26435;&#25805;&#20316;');
}
$settings=C::t('#aljbd#aljbd_setting')->range();
//debug($settings['displaynavs']['value']);
if($settings['displaygoodsnav']['value']){
	$alltype = DB::fetch_all('select * from %t where upid=0 order by displayorder desc limit 0,13',array('aljbd_type_goods'));
}else{
	$alltype = DB::fetch_all('select * from %t where upid=0 order by displayorder desc limit 0,13',array('aljbd_type'));
}
$yindao = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin'][$pluginid] ['yindao']));
foreach($yindao as $key=>$value){
	$arr=explode('|',$value);
	
	$yd_types[]=$arr;
}
$businesstype = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin'][$pluginid] ['businesstype']));
foreach($businesstype as $key=>$value){
	$arr=explode('=',$value);
	$businesstypearr[$arr[0]]=$arr[1];
}

$ress=array(
	'brand_index.html'=>'plugin.php?id=aljbd',
	'brand.html'=>'plugin.php?id=aljbd&act=dianpu',
	'goods.html'=>'plugin.php?id=aljbd&act=goods',
	'notice.html'=>'plugin.php?id=aljbd&act=nlist',
	'consume.html'=>'plugin.php?id=aljbd&act=clist',
);
$index_dh = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin'][$pluginid] ['index_dh']));
foreach($index_dh as $key=>$value){
	$arr=explode('|',$value);
	$index_dh_types[$arr[0]]=$arr[1];
}
if ($_SERVER ['HTTP_X_REWRITE_URL']) {
	$the_uri = isset($_SERVER ['HTTP_X_REWRITE_URL']) ? $_SERVER ['HTTP_X_REWRITE_URL'] : '';
} else {
	$the_uri = isset($_SERVER ['REQUEST_URI']) ? $_SERVER ['REQUEST_URI'] : '';
}
$state = intval($_GET['state']);
$del_confirm =lang('plugin/aljbd','del_confirm');
$path = 'source/plugin/'.$pluginid.'/';
$pluginurl = 'plugin.php?id=aljsyy';
if($_G['cache']['plugin']['aljbd']){
    require_once 'source/plugin/aljbd/include/newparameter.php';
}
if($_GET['act']=='aljbd_appointment'){
    if($_G['mobile']){
        header('location: plugin.php?id=aljbd&act=view&op=appointment&bid='.$_GET['bid']);
        exit;
    }
	$user=C::t('#'.$pluginid.'#'.$pluginid)->fetch($_GET['bid']);
	if (submitcheck('submit')) {
		if($user['uid'] == $_G['uid']){
			if($_G['mobile']){
				echo "<script>parent.tips('&#26080;&#26435;&#25805;&#20316;','');</script>";
				exit;
			}else{
				echo '<script>parent.showDialog("&#26080;&#26435;&#25805;&#20316;","","")</script>';
				exit;
			}
		}
		if (empty($_GET['title'])) {
			if($_G['mobile']){
				echo "<script>parent.tips('&#26631;&#39064;&#24517;&#39035;&#22635;&#20889;','');</script>";
				exit;
			}else{
				echo '<script>parent.showDialog("&#26631;&#39064;&#24517;&#39035;&#22635;&#20889;","","")</script>';
				exit;
			}
        }
		if (empty($_GET['contact_person'])) {
			if($_G['mobile']){
				echo "<script>parent.tips('&#29992;&#25143;&#22995;&#21517;&#24517;&#39035;&#22635;&#20889;','');</script>";
				exit;
			}else{
				echo '<script>parent.showDialog("&#29992;&#25143;&#22995;&#21517;&#24517;&#39035;&#22635;&#20889;","","")</script>';
				exit;
			}
        }
		if (empty($_GET['tel'])) {
			if($_G['mobile']){
				echo "<script>parent.tips('&#32852;&#31995;&#30005;&#35805;&#24517;&#39035;&#22635;&#20889;','');</script>";
				exit;
			}else{
				echo '<script>parent.showDialog("&#32852;&#31995;&#30005;&#35805;&#24517;&#39035;&#22635;&#20889;","","")</script>';
				exit;
			}
        }
		if (empty($_GET['message'])) {
			if($_G['mobile']){
				echo "<script>parent.tips('&#39044;&#32422;&#20869;&#23481;&#24517;&#39035;&#22635;&#20889;','');</script>";
				exit;
			}else{
				echo '<script>parent.showDialog("&#39044;&#32422;&#20869;&#23481;&#24517;&#39035;&#22635;&#20889;","","")</script>';
				exit;
			}
        }
		C::t('#aljsyy#'.$pluginid.'_appointment')->insert(array(
			'bid'=>$_GET['bid'],
			'uid'=>$_G['uid'],
			'buid'=>$user['uid'],
			'name'=>$_G['username'],
			'dateline'=>$_GET['dateline'],
			'tel'=>$_GET['tel'],
			'contact_person'=>$_GET['contact_person'],
			'message'=>$_GET['message'],
			'address'=>$_GET['address'],
			'email'=>$_GET['email'],
			'title'=>$_GET['title'],
			'qq'=>$_GET['qq'],
			'timestamp'=>TIMESTAMP,
		)); 
		$mes_app=str_replace(array('{daohang}','{username}','{url}','{subject}'),array($_G['cache']['plugin'][$pluginid]['aljbd_plugins'],$_G['username'],'<a href="plugin.php?id=aljsyy&act=appointment_list&pluginid='.$pluginid.'" target="_blank">&#28857;&#20987;&#26597;&#30475;</a>',$user['name']),$_G['cache']['plugin']['aljsyy']['mes']);
		notification_add($user['uid'], 'system',$mes_app);
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('&#39044;&#32422;&#25104;&#21151;&#65292;&#35831;&#31561;&#20505;&#21830;&#23478;&#32852;&#31995;',function(){parent.location.href='plugin.php?id=".$pluginid."&act=view&bid=".$_GET['bid']."';});</script>";
			exit;
		}else{
			echo '<script>parent.showDialog("&#39044;&#32422;&#25104;&#21151;&#65292;&#35831;&#31561;&#20505;&#21830;&#23478;&#32852;&#31995;","right","",function(){parent.location.href="plugin.php?id='.$pluginid.'&act=view&bid='.$_GET['bid'].'"},0)</script>';
			exit;
		}
	}else{
		if(!$_G['uid']){
			showmessage('&#35831;&#20808;&#30331;&#24405;&#65281;', '', array(), array('login' => true));
		}

		$ress=array(
			'brand_index.html'=>'plugin.php?id=aljbd',
			'brand.html'=>'plugin.php?id=aljbd&act=dianpu',
			'goods.html'=>'plugin.php?id=aljbd&act=goods',
			'notice.html'=>'plugin.php?id=aljbd&act=nlist',
			'consume.html'=>'plugin.php?id=aljbd&act=clist',
		);
		$index_dh = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin'][$pluginid] ['index_dh']));
		foreach($index_dh as $key=>$value){
			$arr=explode('|',$value);
			$index_dh_types[$arr[0]]=$arr[1];
		}
		if ($_SERVER ['HTTP_X_REWRITE_URL']) {
			$the_uri = isset($_SERVER ['HTTP_X_REWRITE_URL']) ? $_SERVER ['HTTP_X_REWRITE_URL'] : '';
		} else {
			$the_uri = isset($_SERVER ['REQUEST_URI']) ? $_SERVER ['REQUEST_URI'] : '';
		}
		$the_uri=ltrim($the_uri,'/');
		$url_dh=ltrim($_SERVER['PHP_SELF'].'?'.$_SERVER["QUERY_STRING"],'/');
		$bid = intval($_GET['bid']);
		$bd=C::t('#aljbd#aljbd')->fetch($bid);
		$qq=str_replace('{qq}',$bd['qq'],$_G['cache']['plugin'][$pluginid]['qq']);
		$check=C::t('#aljbd#aljbd_username')->fetch_by_uid_bid($_G['uid'],$bid);
		if(empty($check)&&$_G['uid']){
			C::t('#aljbd#aljbd_username')->insert(array('uid'=>$_G['uid'],'username'=>$_G['username'],'bid'=>$bid));
		}
		$khf=C::t('#aljbd#aljbd_comment')->count_by_bid($bid);
		foreach($khf[0] as $k=>$v){
			$khf[0][$k]=intval($v);
		}
		$typelist=C::t('#aljbd#aljbd_type')->range();
		$adv=unserialize($bd['adv']);
		$advurl=unserialize($bd['advurl']);
		$notice=C::t('#aljbd#aljbd_notice')->fetch_all_by_uid_bid($bd['uid'],$_GET['bid'],0,9);
		$bd = dhtmlspecialchars($bd);
		$notice = dhtmlspecialchars($notice);
		$navtitle = '&#39044;&#32422;'.$bd['name'];
		include template('aljsyy:aljbd_appointment');
	}
}else if($_GET['act'] == 'appointment_list'){
	if(!$_G['uid']){
		showmessage('&#35831;&#20808;&#30331;&#24405;&#65281;', '', array(), array('login' => true));
	}
	$currpage = $_GET['page'] ? $_GET['page'] : 1;
    $perpage = 10;
	$start = ($currpage - 1) * $perpage;
	if($_GET['state'] == 2){
		$num = DB::result_first('select count(*) from %t where uid=%d',array($pluginid.'_appointment',$_G['uid']));
		$logs = DB::fetch_all('select * from %t where uid=%d limit %d,%d',array($pluginid.'_appointment',$_G['uid'],$start,$perpage));
	}else{
		if($_GET['state'] == 1){
			$con = ' and state = 1';
		}else{
			$con = ' and state = 0';
		}

		$num = DB::result_first('select count(*) from %t where buid=%d '.$con,array($pluginid.'_appointment',$_G['uid']));
		$logs = DB::fetch_all('select * from %t where buid=%d '.$con.' limit %d,%d',array($pluginid.'_appointment',$_G['uid'],$start,$perpage));
	}
    if($_GET['do'] == 'ajax'){
        require_once $common_path.'class/class_aljhtx.php';
        foreach($logs as $gk => $gv){
            $logs[$gk]['brand'] = C::t('#'.$pluginid.'#'.$pluginid)->fetch($gv['bid']);
            $logs[$gk]['timestamp'] = dgmdate($gv['timestamp'],'u');
        }
        if($logs){
            echo json_encode(aljhtx::ajaxPostCharSet($logs));
        }else{
            echo '1';
        }
        exit;
    }else {
        $paging = helper_page:: multi($num, $perpage, $currpage, 'plugin.php?id=aljsyy&act=appointment_list&pluginid=' . $pluginid, 0, 11, false, false);
        $navtitle = $_G['cache']['plugin'][$pluginid]['title'];
        $metakeywords = $_G['cache']['plugin'][$pluginid]['keywords'];
        $metadescription = $_G['cache']['plugin'][$pluginid]['description'];

        if ($pluginid_seo['appointment']['seotitle']) {
            $seodata = array('bbname' => $_G['setting']['bbname'], 'username' => $_G['username']);
            list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $pluginid_seo['appointment']);
        }
        if ($newtemplate) {
            include template($common_template_pluginid . ':new/user/appointment_list');
        } else {
            include template('aljsyy:appointment_list');
        }
    }
}else if($_GET['act'] == 'appointment_view'){
	if(!$_G['uid']){
		showmessage('&#35831;&#20808;&#30331;&#24405;&#65281;', '', array(), array('login' => true));
	}
	$user=C::t('#aljsyy#'.$pluginid.'_appointment')->fetch($_GET['cid']);
	$lp=C::t('#'.$pluginid.'#'.$pluginid)->fetch($user['bid']);
	$navtitle = $_G['cache']['plugin'][$pluginid]['title'];
	$metakeywords = $_G['cache']['plugin'][$pluginid]['keywords'];
	$metadescription = $_G['cache']['plugin'][$pluginid]['description'];
	
	if($pluginid_seo['appointment']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $pluginid_seo['appointment']);
	}
    if ($newtemplate) {
        include template($common_template_pluginid . ':new/view/appointment_view');
    } else {
        include template('aljsyy:appointment_view');
    }
} else if ($_GET['act'] == 'appointment_del') {
	if(!$_G['uid']){
		showmessage('&#35831;&#20808;&#30331;&#24405;&#65281;', '', array(), array('login' => true));
	}
	$user=C::t('#aljsyy#'.$pluginid.'_appointment')->fetch($_GET['cid']);
	if($user['buid']!=$_G['uid'] || $_GET['formhash']!=formhash()){
		showmessage('&#26080;&#26435;&#25805;&#20316;');
	}
    C::t('#aljsyy#'.$pluginid.'_appointment')->delete($_GET['cid']);
    showmessage('&#21024;&#38500;&#25104;&#21151;', 'plugin.php?id=aljsyy&act=appointment_list&pluginid='.$pluginid.'&state='.$state);
}else if ($_GET['act'] == 'appointment_state') {
	if(!$_G['uid']){
		showmessage('&#35831;&#20808;&#30331;&#24405;&#65281;', '', array(), array('login' => true));
	}
	$user=C::t('#aljsyy#'.$pluginid.'_appointment')->fetch($_GET['cid']);
	if($user['buid']!=$_G['uid'] || $_GET['formhash']!=formhash()){
		showmessage('&#26080;&#26435;&#25805;&#20316;');
	}
    C::t('#aljsyy#'.$pluginid.'_appointment')->update_state_by_id($_GET['cid']);
    showmessage('&#26356;&#26032;&#25104;&#21151;', 'plugin.php?id=aljsyy&act=appointment_list&pluginid='.$pluginid.'&state='.$state);
}
//require DISCUZ_ROOT.'./source/plugin/aljyy/api/aljyy_'.$pluginid.'.php';
?>