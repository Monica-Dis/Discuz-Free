<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljbd_appointment')." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `qq` bigint(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `state` int(11) NOT NULL,
  `buid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bid` (`bid`)
)";
if(DB::query($sql,'SILENT')){print('create table `aljbd_appointment` succeed!<br>');}
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljes_appointment')." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `buid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`)
)";
if(DB::query($sql,'SILENT')){print('create table `aljes_appointment` succeed!<br>');}

$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljesf_appointment')." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `buid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`)
)";
if(DB::query($sql,'SILENT')){print('create table `aljesf_appointment` succeed!<br>');}

$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljesc_appointment')." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `buid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`)
)";
if(DB::query($sql,'SILENT')){print('create table `aljesc_appointment` succeed!<br>');}

$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljlp_appointment')." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `buid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`)
)";
if(DB::query($sql,'SILENT')){print('create table `aljlp_appointment` succeed!<br>');}

$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljzp_appointment')." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `buid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`)
)";
if(DB::query($sql,'SILENT')){print('create table `aljzp_appointment` succeed!<br>');}

$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljzc_appointment')." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `buid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`)
)";
if(DB::query($sql,'SILENT')){print('create table `aljzc_appointment` succeed!<br>');}

$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljcw_appointment')." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `buid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`)
)";
if(DB::query($sql,'SILENT')){print('create table `aljcw_appointment` succeed!<br>');}
echo '<br/>repair succeed';
?>