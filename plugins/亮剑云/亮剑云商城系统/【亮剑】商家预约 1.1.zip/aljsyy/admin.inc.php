<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$config = array();
foreach($pluginvars as $key => $val) {
	$config[$key] = $val['value'];	
}
$pluginid='aljsyy';
$pluginid_1='aljbd';
$state = intval($_GET['state']);
$mes_app=str_replace(array('{daohang}','{username}','{url}','{subject}'),array($_G['cache']['plugin'][$pluginid]['aljbd_plugins'],$user['username'],'<a href="plugin.php?id=aljsyy&act=appointment_list&pluginid='.$pluginid.'" target="_blank">&#28857;&#20987;&#26597;&#30475;</a>',$user['name']),$_G['cache']['plugin']['aljsyy']['mes']);
if($_GET['act'] == 'appointment_view'){
	$user=C::t('#aljsyy#'.$pluginid_1.'_appointment')->fetch($_GET['cid']);
	$lp=C::t('#'.$pluginid_1.'#'.$pluginid_1)->fetch($user['bid']);
	include template('aljsyy:admin_appointment_view');
} else if ($_GET['act'] == 'appointment_del') {
	if($_GET['formhash']!=formhash()){
		cpmsg('&#26080;&#26435;&#25805;&#20316;');
	}
    C::t('#aljsyy#'.$pluginid_1.'_appointment')->delete($_GET['cid']);
    cpmsg('&#21024;&#38500;&#25104;&#21151;', 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=admin&act=appointment_list&state='.$state);
}else if ($_GET['act'] == 'appointment_state') {
	if($_GET['formhash']!=formhash()){
		cpmsg('&#26080;&#26435;&#25805;&#20316;');
	}
    C::t('#aljsyy#'.$pluginid_1.'_appointment')->update_state_by_id($_GET['cid']);
    cpmsg('&#26356;&#26032;&#25104;&#21151;', 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=admin&state='.$state);
}else{
		if(!submitcheck('submit')) {
			if($_GET['state'] == 1){
				$sz = 'style="color:red;"';
			}else{
				$wz = 'style="color:red;"';
			}
			showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=admin&state='.$_GET['state'].'&page='.$_GET['page']);
			showtableheader('<input type="text" name="search" value="'.$_GET['search'].'"><input type="submit" >&nbsp;|&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=admin&state=0&cid='.$row[id].'" '.$wz.'>&#26410;&#32852;&#31995;</a>&nbsp;|&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=admin&state=1&cid='.$row[id].'" '.$sz.'>&#24050;&#32852;&#31995;</a>');
			showsubtitle(array('','&#39044;&#32422;&#26631;&#39064;','&#29992;&#25143;&#22995;&#21517;','&#30005;&#35805;', '&#30041;&#35328;','&#21019;&#24314;&#26102;&#38388;','&#29366;&#24577;','&#25805;&#20316;'));
			echo '<script>disallowfloat = "newthread";</script>';
			$currpage=$_GET['page']?$_GET['page']:1;
			$perpage=10;
			$start=($currpage-1)*$perpage;
			$con=" where 1";
			if($_GET['search']){
				$search='%' . addcslashes($_GET['search'], '%_') . '%';
				$con.=" and title like '$search'";
			}
			if($_GET['state'] == 1){
				$con.=" and state = 1";
			}else{
				$con.=" and state = 0";
			}
			$num = DB::result_first('select count(*) from %t',array('aljbd_appointment'));
			$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT."?action=plugins&operation=config&do=".$_GET['do']."&identifier=".$pluginid."&pmod=admin&state=".$_GET['state']."&search=".$_GET['search'], 0, 10, false, false);
			$query = DB::query("SELECT * FROM ".DB::table('aljbd_appointment')." $con ORDER BY id desc limit $start,$perpage");
			while($row = DB::fetch($query)) {
				$lp=C::t('#aljbd#aljbd')->fetch($row['bid']);
				if($row['state']){
					$rowstate = '<span style="color:green;">&#24050;&#32852;&#31995;</span>';
				}else{
					$rowstate = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=admin&act=appointment_state&cid='.$row[id].'&formhash='.FORMHASH.'" style="color:red;">&#26410;&#32852;&#31995;</a>';
				}
				showtablerow('', array('', 'class="td_m"', 'class="td_k"','class="td_l"', 'class="td_l"','class="td_l"','class="td_l"'), array(
								"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$row[id]\"><input type=\"hidden\" value=\"$row[id]\" name=\"myid[]\" >",	
								$row['title'],
								$row['contact_person'],
								$row['tel'],	
								cutstr($row['message'],60,'...'),		
								dgmdate($row['timestamp']),	
								$rowstate,
								'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljsyy&pmod=admin&act=appointment_view&cid='.$row[id].'" >&#35814;&#24773;</a>',		
								));
				
			}
			
			showsubmit('submit', 'submit', 'del','',$paging);
			showtablefooter();
			showformfooter();
		}else{
			//debug($_POST);
			if(is_array($_POST['delete'])) {
				foreach($_POST['delete'] as $id) {
					C::t('#aljsyy#'.$pluginid_1.'_appointment')->delete($id);
				}
			}
			
			cpmsg('&#26356;&#26032;&#25104;&#21151;', 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=admin&state='.$_GET['state'].'&page='.$_GET['page'], 'succeed');
		}
	
}
//From: Dism��taobao��com
?>