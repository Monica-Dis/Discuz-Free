<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_GET['act'] == 'conversion'){
    $html=file_get_contents('http://api.map.baidu.com/geoconv/v1/?coords='.$_GET['lng'].','.$_GET['lat'].'&from=1&to=5&ak=Mz8y6VOGZv8AbIfQas83nf1B');
    echo $html;
    exit;
}
function returnSquarePoint($lng, $lat,$distance = 0.5) {
	$dlng =  2 * asin(sin($distance / (2 * 6371)) / cos(deg2rad($lat)));
	$dlng = rad2deg($dlng);
	$dlat = $distance/6371;
	$dlat = rad2deg($dlat);
	return array(
				'left-top'=>array('lat'=>$lat + $dlat,'lng'=>$lng-$dlng),
				'right-top'=>array('lat'=>$lat + $dlat, 'lng'=>$lng + $dlng),
				'left-bottom'=>array('lat'=>$lat - $dlat, 'lng'=>$lng - $dlng),
				'right-bottom'=>array('lat'=>$lat - $dlat, 'lng'=>$lng + $dlng)
				);
}
function getdistance($lng1,$lat1,$lng2,$lat2) {
	$radLat1=deg2rad($lat1);
	$radLat2=deg2rad($lat2);
	$radLng1=deg2rad($lng1);
	$radLng2=deg2rad($lng2);
	$a=$radLat1-$radLat2;
	$b=$radLng1-$radLng2;
	$s=2*asin(sqrt(pow(sin($a/2),2)+cos($radLat1)*cos($radLat2)*pow(sin($b/2),2)))*6378.137*1000;
	return $s;
}

if($_GET['lng'] && $_GET['lat']) {
	$squares = returnSquarePoint($_GET['lng'], $_GET['lat'], $_G['cache']['plugin']['aljlbs']['range']);
	//$x=$squares['left-top']['lng'].','.$squares['right-bottom']['lng'];
	//$y=$squares['right-bottom']['lat'].','.$squares['left-top']['lat'];
    //x ���� y γ��
    $y = $_GET['lat'];//γ��
    $x = $_GET['lng'];//����
	$lbsurl='&lng='.$_GET['lng'].'&lat='.$_GET['lat'];
}
//From: Dism��taobao��com
?>