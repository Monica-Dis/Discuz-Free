<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljhelp_type extends discuz_table{
	public function __construct() {

			$this->_table = 'aljhelp_type';
			$this->_pk    = 'id';

			parent::__construct();
	}
	

}




?>