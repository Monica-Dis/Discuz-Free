<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljhelp extends discuz_table{
	public function __construct() {

			$this->_table = 'aljhelp';
			$this->_pk    = 'id';

			parent::__construct();
	}
	

}




?>