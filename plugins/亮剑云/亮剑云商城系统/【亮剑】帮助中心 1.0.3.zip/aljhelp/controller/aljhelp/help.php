<?php

/**
 *
 * @author DisM!Ӧ������ dism.taobao.com
 * @version 1.0
 * @link http://docs.liangjianyun.com/
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class helpAction{
    public $page;

    public function __construct($page) {
        $this->page = $page;
        $this->aljbdParameter();
    }
    /**
     * ��������
     *
     *
     * @return void
     */
    public function help () {
        $do = $this->page->get->do;
        if($do == 'ajax'){
            $currpage = $this->page->get->page ? $this->page->get->page : 1;
            $perpage = 12;
            $start = ($currpage - 1) * $perpage;
            if(!$this->page->get->type){
                $where = 'where rubbish = 0 ';
            }else{
                $where = 'where rubbish = 0 and typeid = '.$this->page->get->type;
            }

            $couponList = DB::fetch_all('select * from %t '.$where.' order by id desc limit %d,%d',
                array('aljhelp',$start,$perpage));

            foreach($couponList as $ck => $cv){

                $couponList[$ck]['dateline'] = dgmdate($cv['dateline'],'u');
                $couponList[$ck]['desc'] = cutstr(strip_tags(preg_replace('/\<img.*?\>/is', '', $cv['content'])),200);

            }
            if($couponList){
                echo json_encode(T::ajaxPostCharSet($couponList));
            }else{
                echo '1';
            }
            exit;
        }else{
            $helplist = DB::fetch_all('select * from %t ',array('aljhelp_type'));
            $where = 'where rubbish = 0';
            $con[] = 'aljhelp';
            if($this->page->get->typeid){
                $where .= ' and typeid=%d';
                $con[] = $this->page->get->typeid;
            }
            $helpinfolist = DB::fetch_all('select * from %t '.$where,$con);
            $typename = DB::result_first('select name from %t where id=%d',array('aljhelp_type',$this->page->get->typeid));
            $this->page->assign('helplist', $helplist);
            $this->page->assign('typename', $typename);
            $this->page->assign('helpinfolist', $helpinfolist,true);

            $this->page->assign('navtitle', lang("plugin/aljhelp","help_php_1"));

            $this->page->display();
        }
    }
    /**
     * ��������
     *
     *
     * @return void
     */
    public function view () {
        DB::query('update %t set view=view+1 where id=%d',array('aljhelp',$this->page->get->hid));
        $helpinfo = DB::fetch_first('select * from %t where id=%d',array('aljhelp',$this->page->get->hid));
        $helplist = DB::fetch_all('select * from %t ',array('aljhelp_type'));
        $where = 'where 1';
        $con[] = 'aljhelp';
        if($this->page->get->typeid){
            $where .= ' and typeid=%d';
            $con[] = $this->page->get->typeid;
        }
        $helpinfolist = DB::fetch_all('select * from %t '.$where,$con);
        $typename = DB::result_first('select name from %t where id=%d',array('aljhelp_type',$this->page->get->typeid));
        $this->page->assign('helplist', $helplist);
        $this->page->assign('typename', $typename);
        $this->page->assign('helpinfolist', $helpinfolist);
        $this->page->assign('helpinfo', $helpinfo,true);
        $prev = DB::fetch_first('select * from %t where id<%d limit 1',array('aljhelp',$this->page->get->hid));
        $next = DB::fetch_first('select * from %t where id>%d limit 1',array('aljhelp',$this->page->get->hid));
        $this->page->assign('prev', $prev);
        $this->page->assign('next', $next);
        $this->page->assign('navtitle', lang("plugin/aljhelp","help_php_2"));

        $this->page->display();

    }
    /**
     * Ʒ���̼ҹ�������ע��
     *
     *
     * @return void
     */
    public function aljbdParameter(){
        global $Html5Plusapp,
               $immersed,
               $pc_footer_new_top_arr,
               $pc_footer_new_top_tel,
               $pc_footer_new_top_kefu,
               $pc_footer_new_cron_c1_arr,
               $pc_footer_new_cron_c2_arr,
               $pc_footer_new_cron_c3_arr,
               $pc_footer_new_cron_c4_arr,
               $pc_footer_new_cron_c5_arr,
               $pc_footer_new_cron_qrcode_arr,
               $alltype,
               $index_dh_types,
               $ress;

        $settings=C::t('#aljbd#aljbd_setting')->range();
        $mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_common_footernav']['value']));
        foreach($mobile_common_footernav as $key=>$value){
            $arr=explode('|',$value);
            $mobile_common_footernav_arr[]=$arr;
        }
        $price_unit = '&#65509;';
        $this->page->assign('price_unit', $price_unit,true);
        $this->page->assign('pluginid', 'aljbd');
        $this->page->assign('Html5Plusapp', $Html5Plusapp);
        $this->page->assign('immersed', $immersed);
        $this->page->assign('settings', $settings,true);
        $this->page->assign('mobile_common_footernav_arr', $mobile_common_footernav_arr,true);
        $this->page->assign('common_template_pluginid', 'aljbd');
        $this->page->assign('common_path', 'source/plugin/aljhtx/');

        $this->page->assign('pc_footer_new_top_arr', $pc_footer_new_top_arr,true);
        $this->page->assign('pc_footer_new_top_tel', $pc_footer_new_top_tel,true);
        $this->page->assign('pc_footer_new_top_kefu', $pc_footer_new_top_kefu,true);
        $this->page->assign('pc_footer_new_cron_c1_arr', $pc_footer_new_cron_c1_arr,true);
        $this->page->assign('pc_footer_new_cron_c2_arr', $pc_footer_new_cron_c2_arr,true);
        $this->page->assign('pc_footer_new_cron_c3_arr', $pc_footer_new_cron_c3_arr,true);
        $this->page->assign('pc_footer_new_cron_c4_arr', $pc_footer_new_cron_c4_arr,true);
        $this->page->assign('pc_footer_new_cron_c5_arr', $pc_footer_new_cron_c5_arr,true);
        $this->page->assign('pc_footer_new_cron_qrcode_arr', $pc_footer_new_cron_qrcode_arr,true);
        $this->page->assign('alltype', $alltype,true);
        $this->page->assign('index_dh_types', $index_dh_types,true);
        $this->page->assign('ress', $ress,true);
    }
}

