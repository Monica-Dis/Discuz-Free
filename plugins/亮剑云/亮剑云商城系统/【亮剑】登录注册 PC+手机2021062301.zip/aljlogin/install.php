<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljlogin_globalsetting` (
  `mykey` char(50) NOT NULL,
  `myvalue` varchar(255) NOT NULL,
  PRIMARY KEY (`mykey`)
);
CREATE TABLE IF NOT EXISTS `pre_aljlogin_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mykey` char(50) NOT NULL,
  `myvalue` varchar(255) NOT NULL,
  `pluginid` char(50) NOT NULL,
  PRIMARY KEY (`id`)
);
INSERT INTO `pre_aljlogin_globalsetting` (`mykey`, `myvalue`) VALUES
('qqurl', '#'),
('wxurl', '#'),
('tzurl', 'forum.php'),
('namecolor', '#63AEFF'),
('minlogo', '1'),
('wsq_allow', '0'),
('dxyz', '1'),
('mail', '0'),
('wburl', '#');
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>