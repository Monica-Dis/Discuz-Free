<?php
/*
 * Copyright 2001-2099 DisM!应用中心.
 * 技术支持: http://dism.taobao.com
 * 联系QQ: DisM.Taobao.Com
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if($_GET['act'] == 'loginsetting'){
	$pluginid = htmlspecialchars($_GET['pluginid']);
	if($_GET['formhash'] == FORMHASH){
		foreach($_GET['setting'] as $key => $val){
			if(DB::result_first('select count(*) from %t where mykey=%s and pluginid=%s',array('aljlogin_setting',$key,$pluginid))){
				DB::query('update %t set myvalue = %s where mykey=%s and pluginid=%s',array('aljlogin_setting',$val,$key,$pluginid));
			}else{
				DB::insert('aljlogin_setting',array(
					'mykey' => $key,
					'myvalue' => $val,
					'pluginid' => $pluginid,
				));
			}
		}
		
		//debug($_FILES);
		$checkname=$_GET['checkname'];
		$picname = $_FILES['logo']['name'];
		$logosetting=DB::fetch_first('select * from %t where mykey=%s and pluginid=%s',array('aljlogin_setting','logo',$pluginid));
		if($checkname){
				@unlink($logosetting['myvalue']);
				DB::query('delete from %t where mykey =%s and pluginid=%s',array('aljlogin_setting','logo',$pluginid));
			}else{
		if ($picname != "") {
			$type = strstr($picname, '.');
			if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
				cpmsg("&#22270;&#29255;&#26684;&#24335;&#19981;&#27491;&#30830;&#65281;");
			}
			$logoname = date("YmdHis").$type;
			$logo = "source/plugin/aljlogin/static/images/logo/". $logoname;
			if(@copy($_FILES['logo']['tmp_name'], $logo) || @move_uploaded_file($_FILES['logo']['tmp_name'], $logo)){
				@unlink($_FILES['logo']['tmp_name']);
			}
			$logosetting=DB::fetch_first('select * from %t where mykey=%s and pluginid=%s',array('aljlogin_setting','logo',$pluginid));
			if($logosetting){
				@unlink($logosetting['myvalue']);
				DB::query('update %t set myvalue=%s where mykey=%s and pluginid=%s',array('aljlogin_setting',$logo,'logo',$pluginid));
			}else{
			DB::insert('aljlogin_setting',array(
				'mykey' => 'logo',
				'myvalue' => $logo,
				'pluginid' => $pluginid,
			));
			}
			}
			}
		
		cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&identifier=aljlogin&pmod=setting');
	}else{
		$settingrecord = DB::fetch_all('select * from %t where pluginid=%s',array('aljlogin_setting',$pluginid));
		foreach($settingrecord as $val){
			$setting[$val['mykey']] = $val['myvalue'];
		}
		$colorname = $setting['namecolor']?$setting['namecolor']:'#63AEFF';
		$logo = $setting['logo']?$setting['logo']:'source/plugin/aljlogin/static/images/login.png';
		include template('aljlogin:loginsetting');
	}
}else{
	/*$pluginlist = C::t('common_plugin')->range('','','desc');
	*/
	$pluginlist=DB::fetch_all('select * from %t order by pluginid desc',array('common_plugin'));
	include template('aljlogin:pluginlist');
}
//From: Dism·taobao·com
?>