<?php

/*
 * Copyright 2001-2099 DisM!Ӧ������.
 * ����֧��: http://dism.taobao.com
 * ��ϵQQ: DisM.Taobao.Com
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
 
if($_GET['formhash'] == FORMHASH){
	$pluginid = htmlspecialchars($_GET['pluginid']);
	foreach($_GET['setting'] as $key => $val){
		if(DB::result_first('select count(*) from %t where mykey=%s',array('aljlogin_globalsetting',$key))){
			DB::query('update %t set myvalue = %s where mykey=%s',array('aljlogin_globalsetting',$val,$key));
		}else{
			DB::insert('aljlogin_globalsetting',array(
				'mykey' => $key,
				'myvalue' => $val,
			));
		}
	}
	$checkname=$_GET['checkname'];
	$picname = $_FILES['logo']['name'];
	$logosetting=DB::fetch_first('select * from %t where mykey=%s',array('aljlogin_globalsetting','logo'));
	if($checkname){
		@unlink($logosetting['myvalue']);
		DB::query('delete from %t where mykey =%s',array('aljlogin_globalsetting','logo'));
	}else{
		if ($picname != "") {
            $logo = uploaded_logo ($_FILES['logo']);
            if($logosetting){
                @unlink($logosetting['myvalue']);
                DB::query('update %t set myvalue=%s where mykey=%s',array('aljlogin_globalsetting',$logo,'logo'));
            }else{
                DB::insert('aljlogin_globalsetting',array(
                    'mykey' => 'logo',
                    'myvalue' => $logo,
                ));
            }
		}
	}

    $qq_icon=DB::fetch_first('select * from %t where mykey=%s',array('aljlogin_globalsetting','qq_icon'));

    if ($_FILES['qq_icon']['name'] != "") {
        $qq_logo = uploaded_logo ($_FILES['qq_icon']);
        if($qq_icon){
            @unlink($qq_icon['myvalue']);
            DB::query('update %t set myvalue=%s where mykey=%s',array('aljlogin_globalsetting',$qq_logo,'qq_icon'));
        }else{
            DB::insert('aljlogin_globalsetting',array(
                'mykey' => 'qq_icon',
                'myvalue' => $qq_logo,
            ));
        }
    }

    $wx_icon=DB::fetch_first('select * from %t where mykey=%s',array('aljlogin_globalsetting','wx_icon'));

    if ($_FILES['wx_icon']['name'] != "") {
        $wx_logo = uploaded_logo ($_FILES['wx_icon']);
        if($wx_icon){
            @unlink($wx_icon['myvalue']);
            DB::query('update %t set myvalue=%s where mykey=%s',array('aljlogin_globalsetting',$wx_logo,'wx_icon'));
        }else{
            DB::insert('aljlogin_globalsetting',array(
                'mykey' => 'wx_icon',
                'myvalue' => $wx_logo,
            ));
        }
    }

    $wb_icon=DB::fetch_first('select * from %t where mykey=%s',array('aljlogin_globalsetting','wb_icon'));

    if ($_FILES['wb_icon']['name'] != "") {
        $wb_logo = uploaded_logo ($_FILES['wb_icon']);
        if($wb_icon){
            @unlink($wb_icon['myvalue']);
            DB::query('update %t set myvalue=%s where mykey=%s',array('aljlogin_globalsetting',$wb_logo,'wb_icon'));
        }else{
            DB::insert('aljlogin_globalsetting',array(
                'mykey' => 'wb_icon',
                'myvalue' => $wb_logo,
            ));
        }
    }
    
    $apple_icon=DB::fetch_first('select * from %t where mykey=%s',array('aljlogin_globalsetting','apple_icon'));
    if ($_FILES['apple_icon']['name'] != "") {
        $apple_logo = uploaded_logo ($_FILES['apple_icon']);
        if($apple_icon){
            @unlink($apple_icon['myvalue']);
            DB::query('update %t set myvalue=%s where mykey=%s',array('aljlogin_globalsetting',$apple_icon,'apple_icon'));
        }else{
            DB::insert('aljlogin_globalsetting',array(
                'mykey' => 'apple_icon',
                'myvalue' => $apple_logo,
            ));
        }
    }

    $login_icon=DB::fetch_first('select * from %t where mykey=%s',array('aljlogin_globalsetting','login_icon'));

    if ($_FILES['login_icon']['name'] != "") {
        $login_logo = uploaded_logo ($_FILES['login_icon']);
        if($login_icon){
            @unlink($login_icon['myvalue']);
            DB::query('update %t set myvalue=%s where mykey=%s',array('aljlogin_globalsetting',$login_logo,'login_icon'));
        }else{
            DB::insert('aljlogin_globalsetting',array(
                'mykey' => 'login_icon',
                'myvalue' => $login_logo,
            ));
        }
    }

    $register_icon=DB::fetch_first('select * from %t where mykey=%s',array('aljlogin_globalsetting','register_icon'));

    if ($_FILES['register_icon']['name'] != "") {
        $register_logo = uploaded_logo ($_FILES['register_icon']);
        if($register_icon){
            @unlink($register_icon['myvalue']);
            DB::query('update %t set myvalue=%s where mykey=%s',array('aljlogin_globalsetting',$register_logo,'register_icon'));
        }else{
            DB::insert('aljlogin_globalsetting',array(
                'mykey' => 'register_icon',
                'myvalue' => $register_logo,
            ));
        }
    }

	cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&identifier=aljlogin&pmod=globalsetting');

}else{
	$settingrecord = DB::fetch_all('select * from %t',array('aljlogin_globalsetting'));
	foreach($settingrecord as  $val){
		$setting[$val['mykey']] = $val['myvalue'];
	}
	$colorname = $setting['namecolor']?$setting['namecolor']:'#63AEFF';
	$dxyz_colorname = $setting['dxyz_color']?$setting['dxyz_color']:'#75C65D';
	$logo = $setting['logo']?$setting['logo']:'source/plugin/aljlogin/static/images/login.png';
	$qq_icon = $setting['qq_icon']?$setting['qq_icon']:'source/plugin/aljlogin/static/images/QQ.png';
	$wx_icon = $setting['wx_icon']?$setting['wx_icon']:'source/plugin/aljlogin/static/images/wx.png';
	$wb_icon = $setting['wb_icon']?$setting['wb_icon']:'source/plugin/aljlogin/static/images/wb.png';
	$login_icon = $setting['login_icon']?$setting['login_icon']:'source/plugin/aljlogin/static/images/re.png';
	$apple_icon = $setting['apple_icon']?$setting['apple_icon']:'source/plugin/aljlogin/static/images/apple.png';
	$register_icon = $setting['register_icon']?$setting['register_icon']:'source/plugin/aljlogin/static/images/re.png';
	//debug($setting);
	include template('aljlogin:globalsetting');
}
function uploaded_logo ($picname){
    $type = strstr($picname['name'], '.');

    if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
        cpmsg("&#22270;&#29255;&#26684;&#24335;&#19981;&#27491;&#30830;&#65281;");
    }

    $rand = rand(100, 999);
    $pics = date("YmdHis") . $rand . $type;
    $img_dir = "source/plugin/aljlogin/static/images/logo/".date('Ymd',TIMESTAMP).'/';
    if (!is_dir($img_dir)) {
        mkdir($img_dir);
    }
    $logo = $img_dir.$pics;
    if(@copy($picname['tmp_name'], $logo) || @move_uploaded_file($picname['tmp_name'], $logo)){
        @unlink($picname['tmp_name']);
    }
    return $logo;
}
//From: Dism_taobao_com	
?>