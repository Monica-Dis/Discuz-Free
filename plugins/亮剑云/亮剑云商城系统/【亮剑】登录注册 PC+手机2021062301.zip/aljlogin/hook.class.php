<?php

/*
 * Copyright 2001-2099 DisM!Ӧ������.
 * ����֧��: http://dism.taobao.com
 * �ͷ�QQ: DisM.Taobao.Com
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Deined');
}
class plugin_aljlogin {
    function common() {
        global $_G;
        $referer = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'].($_SERVER['QUERY_STRING'] ? '?'.$_SERVER['QUERY_STRING'] : '') : dreferer();
        $referer = urlencode($referer ? $referer : 'index.php');
        if($_G['cache']['plugin']['aljlogin']['is_pclogin']){
            if($_GET['mod'] == 'logging' && $_GET['action'] != 'logout' && empty($_GET['formhash']) && $_GET['loginsubmit']!='yes'){

                if($_G['inajax']){
                    include template('common/header');
                    echo '<script>parent.location.href="plugin.php?id=aljlogin&referer='.$referer.'&pluginid='.strip_tags($_GET[pluginid]).'"</script>';
                    include template('common/footer');
                    exit;
                }else{
                    //debug(urlencode($_GET[referer]));
                    header('Location: plugin.php?id=aljlogin&referer='.$referer.'&pluginid='.strip_tags($_GET[pluginid]));
                }
            }else if($_GET['mod'] == $_G[setting][regname] && empty($_GET['formhash']) && !$_G['inajax'] && $_GET['action'] != 'logout'){
                header('Location: plugin.php?id=aljlogin&act=register&referer='.$referer.'&pluginid='.strip_tags($_GET[pluginid]));

            }
        }
    }
}
class mobileplugin_aljlogin {
    function common() {
        global $_G;
        if(defined('IN_MAGMOBILE_API')) {
            return;
        }
        $referer = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'].($_SERVER['QUERY_STRING'] ? '?'.$_SERVER['QUERY_STRING'] : '') : dreferer();
        $referer = urlencode($referer ? $referer : 'index.php');
        if($_GET['mod'] == 'logging' && !$_G['inajax'] && $_GET['action'] != 'logout' && empty($_GET['formhash'])){
            //debug(urlencode($_GET[referer]));
            header('Location: plugin.php?id=aljlogin&referer='.$referer.'&pluginid='.strip_tags($_GET[pluginid]));
        }else if($_GET['mod'] == $_G[setting][regname] && empty($_GET['formhash'])){
            header('Location: plugin.php?id=aljlogin&act=register&pluginid='.strip_tags($_GET[pluginid]).'&referer='.$referer);
        }

    }

}
?>