<?php

/*
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ����֧��: http://dism.taobao.com
 * DISM.TAOBAO.COM
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$plugin = DB::fetch_first('select * from %t where identifier = %s', array('common_plugin', 'aljayy'));

if(empty($plugin)){
    cpmsg('&#35831;&#20808;&#23433;&#35013;&#36816;&#33829;&#31649;&#23478;&#25554;&#20214;');
}

$plugin = DB::fetch_first('select * from %t where identifier = %s and available=1', array('common_plugin', 'aljayy'));

if(empty($plugin)){
    cpmsg('&#35831;&#20808;&#21551;&#29992;&#36816;&#33829;&#31649;&#23478;&#25554;&#20214;');
}

if($plugin['version'] < 2019081401){
    cpmsg('&#35831;&#20808;&#26356;&#26032;&#36816;&#33829;&#31649;&#23478;&#25554;&#20214;&#21040;&#26368;&#26032;&#29256;&#26412;&#65281;');
}

echo '<iframe style="width:100%;height:100%;min-height:780px;border:none;" src="plugin.php?id=aljayy&c=type&a=type&ajax=yes"></iframe>';
exit;
?>