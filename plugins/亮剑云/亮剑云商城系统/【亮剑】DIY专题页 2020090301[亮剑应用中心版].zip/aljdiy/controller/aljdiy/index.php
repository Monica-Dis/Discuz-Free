<?php

/**
 * �������̳�
 *
 * @author <dism.taobao.com>
 * @version 2019080501
 * @link https://dism.taobao.com/
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class IndexAction{
    public function __construct($page) {
        global $_G;
        $this->page = $page;
        $this->page->assign('noimg', 'source/plugin/aljbd/images/sj/noimg.gif');

        //������Ĭ��ͼƬ
        if($_G['cache']['plugin']['aljbd']['lazyloadlogo']){
            $loading = $_G['cache']['plugin']['aljbd']['lazyloadlogo'];
        }else{
            $loading = 'source/plugin/aljbd/images/loading.gif';
        }
        $this->page->assign('loading', $loading);
    }
    public function getaljurl($geturl,$param){
        if($param){
            foreach($param as $k => $v){
                $geturl[$k] = $v;
            }
        }
        require_once libfile('function/home');
        return 'plugin.php?'.url_implode($geturl);
    }
    /**
     * ������ҳ
     *
     *
     * @return void
     */
    public function index () {
        global $_G, $newscount, $settings,$color,$loading,$city_info;
        if($city_info){
            $this->page->assign('city_info', $city_info); 
        }
        if($loading){
            $this->page->assign('loading', $loading);
        }
        if($settings){
            $this->page->assign('settings', $settings, true);
        }
        $this->page->assign('newscount', $newscount);
        $this->page->assign('color', $color);
        $page_id = intval($_GET['page_id']);
        if($_G['uid'] && $_G['cache']['plugin']['aljsfx']['is_aljsfx'] && IS_PC!=1){
            $fx_shopdata = DB::fetch_first('select * from %t where uid=%d and status=1',array('aljsfx_shop',$_G['uid']));
            if(!$_GET['d'] && $fx_shopdata && !$_GET['page']){
                dheader("location: ".PAGE_URL."&d=".$fx_shopdata['uid']);
                exit;
            }
        }
        $page = DB::fetch_first('select * from %t where id=%d', array('aljdiy_page', $page_id));
        if(!$page){
            $this->aljbdParameter();
            $desc = lang("plugin/aljdiy","index_php_1");
            $info = array('desc' => $desc);
            $info['btn_primary'] = array('value' => lang("plugin/aljdiy","index_php_2"), 'url' => 'plugin.php?id=aljbd');
            $info['btn_default'] = array('value' => lang("plugin/aljdiy","index_php_3"), 'url' => 'plugin.php?id=aljbd&act=user');
            $this->page->weuiResult($info,lang("plugin/aljdiy","index_php_4"));
        }
        $push_to_page_arr_url = array(
            'aljtc_index'=>'plugin.php?id=aljtc',
            'aljtsc_index'=>'plugin.php?id=aljtsc',
            'aljtsq_index'=>'plugin.php?id=aljtsq',
        );
        
        if($push_to_page_arr_url[$page['push_to_page']]){
            $this->page->assign('fz_to_url', '&r_url='.$push_to_page_arr_url[$page['push_to_page']]);
        }
        if($page['bid'] > 0){
            $this->page->assign('bid', $page['bid']);
            $bd = C::t('#aljbd#aljbd')->fetch($page['bid']);
            $this->page->assign('bd', $bd,true);
            $this->aljbdParameter();
            $geturl = array(
                'id' => 'aljbd',
                'act' => 'mobile_index_goods',
                'keywords' => $_GET['keywords'],
                'btypeid' => $_GET['btypeid'],
                'bsubtypeid' => $_GET['bsubtypeid'],
                'bid' => $page['bid'],
                'mobilediy' => $_GET['mobilediy'],
                'mobiledemomode' => $_GET['mobiledemomode'],
            );
            $posturl = self::getaljurl($geturl,array());
            $this->page->assign('posturl', $posturl,'true');
            $avg=C::t('#aljbd#aljbd_comment')->count_avg_by_bid($page['bid']);
            $avg=intval($avg);
            $this->page->assign('avg', $avg,'true');
            if($bd['brand_bg']){
                $top_bg = $bd['brand_bg'];
            }elseif($_G['cache']['plugin']['aljbd']['def_brand_bg']){
                $top_bg = $_G['cache']['plugin']['aljbd']['def_brand_bg'];
            }else{
                $top_bg = 'source/plugin/aljbd/images/shop-bg.png';
            }
            $this->page->assign('top_bg', $top_bg,'true');
            if($bd['vipid']){
                $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$bd['vipid']));
                $this->page->assign('vipdata', $vipdata,'true');
            }
            $dp_bid_url = '&dd=1&bid='.$page['bid'];
            $this->page->assign('dp_bid_url', $dp_bid_url,'true');
        }
        define('IN_MOBILE', 2);
        $_G['mobile'] = 2;
        $_G['setting']['hookscript'] = array();
        if($_G['cache']['plugin']['aljhtx'] && file_exists('source/plugin/aljhtx/template/admin/diy/index/mobile_index_Photo_Ads_auto.htm')){
            
            
            
            $save_array = array();
            loadcache('aljdiy', 1);
            if(!$_G['cache']['aljdiy'][$page_id] || empty($_G['cookie']['aljdiy_auto_time_'.$page_id])) {
                //������������ DIY ģ��
                $diyListData = DB::fetch_all('select * from %t where page_id=%d and module!=%s order by displayorder asc', array('aljdiy_diy', $page_id, 'gg_icon'));
                savecache('aljdiy', array($page_id=>$diyListData));
                
            }else{
                $diyListData = $_G['cache']['aljdiy'][$page_id];
            }
            loadcache('aljdiy_list');
            
            if(!$_G['cache']['aljdiy_list'][$page_id] || empty($_G['cookie']['aljdiy_auto_time_'.$page_id]) || $_GET['getmore'] == 'yes') {
                foreach($diyListData as $k => $diy){
                    if($diy['module'] == 'activity_recommend_goods'){
                        if($diy['data']){
                            $diy['data'] = DB::fetch_all('select * from %t where id in (%i)', array('aljbd_goods', $diy['data']));
                        }
                    }else if($diy['module'] == 'activity_recommend_brand'){
                        if($diy['data']){
                            $diy['set_up'] = unserialize($diy['set_up']);
                            if($diy['set_up'][diy_brand_type] == 1){
                                $diy['data'] = C::t('#aljbd#aljbd')->fetch_all_by_recommend(1,0,10);
                            }else{
                                $diy['data'] = DB::fetch_all('select * from %t where id in (%i)', array('aljbd', $diy['data']));
                            }
                            
                        }
                    }else if($diy['module'] == 'activity_recommend_store'){
                        if($diy['data']){
                            $diy['data'] = DB::fetch_all('select * from %t where tc_id in (%i)', array('aljtsq_store', $diy['data']));
                        }
                    }else{
                        if($diy['module'] != 'custom'){
                            
                            $diy['data'] = T::stringSettingToArray($diy['data']);
                            
                            if($diy['module'] == 'so'){
                                $check_so_position = $diy['data'][0][7];
                                if($_GET['getmore'] != 'yes'){
                                    $save_array[$page_id]['check_so_position'] = $check_so_position;
                                }
                            }else if($diy['module'] == 'brand_so'){
                                
                                $check_brand_so_position = $diy['data'][0][7];
                                if($_GET['getmore'] != 'yes'){
                                    $save_array[$page_id]['check_brand_so_position'] = $check_brand_so_position;
                                }
                                
                            }else if($diy['module'] == 'aljtc_so'){
                                $check_aljtc_so_lbs = $diy['data'][0][4] ? 0 : 1;
                                if($_GET['getmore'] != 'yes'){
                                    $save_array[$page_id]['check_aljtc_so_lbs'] = $check_aljtc_so_lbs;
                                }
                            }else if($diy['module'] == 'mobile_common_footernav'){
                                $check_footernav_position = 1;
                                foreach($diy['data'] as $k => $v){
                                    $diy['data'][$k][99] = parse_url($v[3]);
                                    if($diy['data'][$k][99]['query']){
                                        parse_str($diy['data'][$k][99]['query'], $diy['data'][$k][99]['query']);
                                    }
                                }
                                if($_GET['getmore'] != 'yes'){
                                    $save_array[$page_id]['check_footernav_position'] = $check_footernav_position;
                                }
                            }else if($diy['module'] == 'aljshd_toutiao'){
                                if($diy['data'][0][0] == 1){
                                    $toutiao = DB::fetch_all('select a.*,b.name from %t a left join %t b on a.bid=b.id where a.rubbish=0 and a.status=0 order by a.id desc limit 5',array('aljbd_notice','aljbd'));
                                }else if($diy['data'][0][0] == 2){
                                    $nids = explode(',',$diy['data'][0][1]);
                                    if(is_array($nids) && $nids){
                                        $toutiao = DB::fetch_all('select a.*,b.name from %t a left join %t b on a.bid=b.id where a.id in(%n) limit 5',array('aljbd_notice','aljbd',$nids));
                                    }
                                }else{
                                    $toutiao = DB::fetch_all('select a.*,b.name from %t a left join %t b on a.bid=b.id where a.rubbish=0 and a.status=0 and a.sign=1 order by a.id desc limit 5',array('aljbd_notice','aljbd'));
                                }
                                
                                $diy['data'] = $toutiao;
                                
                            }else if($diy['module'] == 'article'){
                                if($diy['data']){
                                    $per = 8;
                                    $pagenum = $this->page->get->page>0 ? $this->page->get->page :1;
                                    $start = ($pagenum - 1) * $per;
            
                                    $conn = array('portal_article_title', 'portal_article_content', 'portal_article_count');
                                    $where = ' where a.status=0';
                                    if($diy['data'][0][2]){
                                        $diy['data'][0][2] = str_replace(array(lang("plugin/aljdiy","index_php_5"), lang("plugin/aljdiy","index_php_6")), ',', $diy['data'][0][2]);
                                        $diy['data'][0][2] = explode(',', $diy['data'][0][2]);
                                        foreach($diy['data'][0][2] as $k => $v){
                                            $checkData[] = intval($v);
                                        }
                                        $diy['data'][0][2] = implode(',', $checkData);
                                        $where .= ' and a.aid in (%i)';
                                        $conn[] = $diy['data'][0][2];
                                    }else{
                                        if($diy['data'][0][0]){
                                            $where .= ' and a.catid = %d';
                                            $conn[] = $diy['data'][0][0];
                                        }
                                    }
                                    
            
                                    $count = DB::result_first('select count(*) from %t a left join %t b on a.aid=b.aid  left join %t c on b.aid=c.aid' . $where, $conn);
                                    $conn[] = $start;
                                    if(count($checkData) > 0){
                                        $conn[] = count($checkData);
                                    }else{
                                        $conn[] = $per;
                                    }
                                    
                                
                                    if($diy['data'][0][1]){
                                        if($diy['data'][0][1] == 1){
                                            $order = 'c.viewnum';
                                        }else if($diy['data'][0][1] == 2){
                                            $order = 'c.commentnum';
                                        }else{
                                            $order = 'a.aid';
                                        }
                                    }else{
                                        $order = 'a.aid';
                                    }
                                    
                                    $article_list = DB::fetch_all('select a.*, b.content, c.* from %t a left join %t b on a.aid=b.aid  left join %t c on b.aid=c.aid '.$where.' order by ' .$order. ' desc limit %d, %d', $conn);
                                    
                                    foreach($article_list as $k => $article){
                                        $imgs = array();
                                        
                                        preg_match_all('/<img.*?src=\"?(.*?\.(jpg|jpeg|gif|bmp|bnp|png))\".*?>/i', $article['content'], $match);
                                        
                                        foreach($match[1] as $key => $val){
                                            if($key > 2){
                                                break;
                                            }
                                            if(strpos($val,'http') !== false || strpos($val,'https') !== false){
                                                $siteurl = '';
                                            }else{
                                                $siteurl = $_G['siteurl'].'/';
                                            }
                                            $imgs[] = $siteurl.$val;
                                        }
                                        $article_list[$k]['imgs'] = $imgs;
                                    }
                                    if($_GET['getmore'] != 'yes'){
                                        $save_array[$page_id]['article_list'] = $article_list;
                                    }
                                    
                                    if($_GET['getmore'] == 'yes'){
                                        include template(APP_ID.':aljdiy/index/diy/article_getmore');
                                        exit;
                                    }
                                }
                            }else if($diy['module'] == 'thread'){
                                if($diy['data']){
                                    $per = 8;
                                    $pagenum = $this->page->get->page>0 ? $this->page->get->page :1;
                                    $start = ($pagenum - 1) * $per;
            
                                    $conn = array('forum_thread', 'forum_post');
                                    $where = ' where a.displayorder<>-1 AND a.displayorder<>-2 AND a.displayorder<>-3 AND a.displayorder<>-4 AND b.first=1';
                                    
                                    if($diy['data'][0][2]){
                                        $diy['data'][0][2] = str_replace(array(lang("plugin/aljdiy","index_php_7"), lang("plugin/aljdiy","index_php_8")), ',', $diy['data'][0][2]);
                                        $diy['data'][0][2] = explode(',', $diy['data'][0][2]);
                                        foreach($diy['data'][0][2] as $k => $v){
                                            $checkData[] = intval($v);
                                        }
                                        $diy['data'][0][2] = implode(',', $checkData);
                                        $where .= ' and a.tid in (%i)';
                                        $conn[] = $diy['data'][0][2];
                                    }else{
                                        if($diy['data'][0][0]){
                                            $where .= ' and a.fid = %d';
                                            $conn[] = $diy['data'][0][0];
                                        }
                                    }
                                    
            
                                    $count = DB::result_first('select count(*) from %t a left join %t b on a.tid=b.tid' . $where, $conn);
                                    $conn[] = $start;
                                
                                    if(count($checkData) > 0){
                                        $conn[] = count($checkData);
                                    }else{
                                        $conn[] = $per;
                                    }
            
                                    if($diy['data'][0][1]){
                                        if($diy['data'][0][1] == 1){
                                            $order = 'a.views';
                                        }else if($diy['data'][0][1] == 2){
                                            $order = 'a.replies';
                                        }else if($diy['data'][0][1] == 3){
                                            $order = 'a.lastpost';
                                        }else if($diy['data'][0][1] == 4){
                                            $order = 'a.favtimes';
                                        }else if($diy['data'][0][1] == 5){
                                            $order = 'a.recommends';
                                        }else{
                                            $order = 'a.tid';
                                        }
                                    }else{
                                        $order = 'a.tid';
                                    }
                                    
                                    $thread_list = DB::fetch_all('select * from %t a left join %t b on a.tid=b.tid '.$where.' order by ' .$order. ' desc limit %d, %d', $conn);
                                    
                                    require_once libfile('function/discuzcode');
                                    foreach($thread_list as $k => $thread){
                                        $imgs = array();
                                        $dataAttachFirst = DB::fetch_first('select * from %t where pid=%d',array('forum_attachment', $thread['pid']));
                                        if($dataAttachFirst){
                                            $dataAttachData = DB::fetch_all('select * from %t where pid=%d',array('forum_attachment_'.$dataAttachFirst['tableid'], $thread['pid']));
                                        }
                                        
                                        foreach($dataAttachData as $attach){
                                            if($attach['isimage']){
                                                $file = 'data/attachment/forum/'.$attach['attachment'];
                                                $image_size = getimagesize($file);//�ļ���С e����:$image_size[0]; �߶�:$image_size[1];
                                                $width=$image_size[0];
                                                $height=$image_size[1];
                                                $thread['message'] = preg_replace('/\[attach\]'.$attach['aid'].'\[\/attach\]/is', '[img='.$width.','.$height.']'.$_G['siteurl'].'/data/attachment/forum/'.$attach['attachment'].'[/img]', $thread['message']);
                                            }
                                        }
                                        
                                        if($thread['htmlon']){
                                            $thread['message'] = discuzcode($thread['message'], false, false, 1, '', '', 1, 1);
                                        }else{
                                            $thread['message'] = discuzcode($thread['message'], false, false, 1);
                                        }
                                        
                                        preg_match_all('/<img.*?src=\"?(.*?\.(jpg|jpeg|gif|bmp|bnp|png))\".*?>/i', $thread['message'], $match);
                                        
                                        foreach($match[1] as $key => $val){
                                            if($key > 2){
                                                break;
                                            }
                                            if(strpos($val,'http') !== false || strpos($val,'https') !== false){
                                                $siteurl = '';
                                            }else{
                                                $siteurl = $_G['siteurl'].'/';
                                            }
                                            $imgs[] = $siteurl.$val;
                                        }
                                        $thread_list[$k]['imgs'] = $imgs;
                                    }
                                    
                                    if($_GET['getmore'] != 'yes'){
                                        $save_array[$page_id]['thread_list'] = $thread_list;
                                    }
                                    if($_GET['getmore'] == 'yes'){
                                        include template(APP_ID.':aljdiy/index/diy/thread_getmore');
                                        exit;
                                    }
                                }
                            }else if($diy['module'] == 'goods_type'){
                                if($diy['data']){
                                    $per = 8;
                                    $pagenum = $this->page->get->page>0 ? $this->page->get->page :1;
                                    $start = ($pagenum - 1) * $per;
            
                                    $conn = array('aljbd_goods');
                                    $where = ' where rubbish = 0 and state = 0 ';
            
                                    if($diy['data'][0][0]){
                                        $where .= ' and type = %d';
                                        $conn[] = $diy['data'][0][0];
                                    }
                            
                                    if($diy['data'][0][1]){
                                        $where .= ' and subtype = %d';
                                        $conn[] = $diy['data'][0][1];
                                    }
                            
                                    if($diy['data'][0][2]){
                                        $where .= ' and subtype3 = %d';
                                        $conn[] = $diy['data'][0][2];
                                    }
                                    if($_GET['type']){
                                        $where .= ' and type = %d';
                                        $conn[] = $_GET['type'];
                                    }
                                    if($_GET['subtype']){
                                        $where .= ' and subtype = %d';
                                        $conn[] = $_GET['subtype'];
                                    }
                            
                                    if($_GET['subtype3']){
                                        $where .= ' and subtype3 = %d';
                                        $conn[] = $_GET['subtype3'];
                                    }
                                    if($diy['data'][0][6]){
                                        $where .= ' and store_id > 0 AND commodity_type <4';
                                    }else{
                                        $where .= ' and store_id = 0';
                                    }
                                    $count = DB::result_first('select count(*) from %t ' . $where, $conn);
                                    $conn[] = $start;
                                    $conn[] = $per;
            
                                    if($diy['data'][0][3]){
                                        if($diy['data'][0][3] == 1){
                                            $order = 'buyamount';
                                        }else if($diy['data'][0][3] == 2){
                                            $order = 'view';
                                        }else{
                                            $order = 'id';
                                        }
                                    }else{
                                        $order = 'id';
                                    }
                                    
                                    $goods_list = DB::fetch_all('select * from %t '.$where.' order by ' .$order. ' desc limit %d, %d', $conn);
                                    if($_GET['getmore'] != 'yes'){
                                        $save_array[$page_id]['goods_list'] = $goods_list;
                                    }
                                    if($_GET['getmore'] == 'yes'){
                                        include template(APP_ID.':aljdiy/index/diy/goods_type_getmore');
                                        exit;
                                    }
                                }
                            }else if($diy['module'] == 'activity_type'){
                                if($diy['data']){
                                    $per = 8;
                                    $pagenum = $this->page->get->page>0 ? $this->page->get->page :1;
                                    $start = ($pagenum - 1) * $per;
            
                                    $conn = array('aljbd_goods', 'aljayy_goods');
                                    $where = ' where a.rubbish = 0 and a.state = 0 ';
                            
                                    if($diy['data'][0][1]){
                                        $where .= ' and FIND_IN_SET(%s,b.type_id_list)';
                                        $conn[] = $diy['data'][0][1];
                                    }
            
                                    $count = DB::result_first('select count(*) from %t a left join %t b on a.id = b.goods_id ' . $where, $conn);
                                    $conn[] = $start;
                                    $conn[] = $per;
            
                                    if($diy['data'][0][3]){
                                        if($diy['data'][0][3] == 1){
                                            $order = 'a.buyamount';
                                        }else if($diy['data'][0][3] == 2){
                                            $order = 'a.view';
                                        }else{
                                            $order = 'a.id';
                                        }
                                    }else{
                                        $order = 'a.id';
                                    }
                                    
                                    $activity_goods_list = DB::fetch_all('select * from %t a left join %t b on a.id = b.goods_id '.$where.' order by ' .$order. ' desc limit %d, %d', $conn);
                                    if($_GET['getmore'] != 'yes'){
                                        $save_array[$page_id]['activity_goods_list'] = $activity_goods_list;
                                    }
                                    if($_GET['getmore'] == 'yes'){
                                        $goods_list = $activity_goods_list;
                                        include template(APP_ID.':aljdiy/index/diy/goods_type_getmore');
                                        exit;
                                    }
                                }
                            }
                        }else{
                            //$diy['data'] = str_replace(PHP_EOL, '<br/>', $diy['data']);
                        }
                    }
                    if($diy['module'] == 'gg'){
                        $diy['data']['gg_icon'] = DB::result_first('select data from %t where module=%s and page_id=%d', array('aljdiy_diy', 'gg_icon', $page_id));
                        $diy['data']['gg_icon'] = str_replace('|', '', $diy['data']['gg_icon']);
                        if($_GET['getmore'] != 'yes'){
                            $save_array[$page_id]['gg_icon'] = $diy['data']['gg_icon'];
                        }
                    }
                    $diyList[] = $diy;
                }
                
            
            
                if($_GET['getmore'] != 'yes' && $diyList){
                    $save_array[$page_id]['diyList'] = $diyList;
                    $save_array[$page_id]['save_time'] = TIMESTAMP;
                    savecache('aljdiy_list', $save_array);
                    dsetcookie('aljdiy_auto_time_'.$page_id, 1, 3600);
                }
            }else{
                $diyList = $_G['cache']['aljdiy_list'][$page_id]['diyList'];
                $article_list = $_G['cache']['aljdiy_list'][$page_id]['article_list'];
                $thread_list = $_G['cache']['aljdiy_list'][$page_id]['thread_list'];
                $goods_list = $_G['cache']['aljdiy_list'][$page_id]['goods_list'];
                $activity_goods_list = $_G['cache']['aljdiy_list'][$page_id]['activity_goods_list'];
                $check_so_position = $_G['cache']['aljdiy_list'][$page_id]['check_so_position'];
                $check_brand_so_position = $_G['cache']['aljdiy_list'][$page_id]['check_brand_so_position'];
                $check_aljtc_so_lbs = $_G['cache']['aljdiy_list'][$page_id]['check_aljtc_so_lbs'];
                $check_footernav_position = $_G['cache']['aljdiy_list'][$page_id]['check_footernav_position'];
                $save_time = $_G['cache']['aljdiy_list'][$page_id]['save_time'];
                if($save_time>0){
                    $save_time = dgmdate($save_time,'Y-m-d H:i:s');
                    $this->page->assign('save_time', $save_time, true);
                }
            }
        }
        //debug($diyList);
        $curPage = $this->page->curPage ? $this->page->curPage : 1;
        $perpage = 10;
        $start = ($curPage - 1) * $perpage;

        if($page['groupid'] > 0){
            $group = DB::fetch_first('select * from %t where id=%d', array('aljdiy_group', $page['groupid']));
            $this->page->assign('group', $group);
            if($group['open'] == 'on'){
                $page_list = DB::fetch_all('select * from %t where groupid=%d order by displayorder asc,id desc', array('aljdiy_page', $page['groupid']));
            }
        }


        /*if($_GET['tab'] == 'yes'){
            foreach ($diyList as $kk => $diy) {
                if($diy['template']){
                    include template(APP_ID.':aljdiy/index/diy/'.$diy['template']);
                }
            }
            exit;
        }*/

        
        
        $this->page->assign('article_list', $article_list, true);
        $this->page->assign('thread_list', $thread_list, true);
        $this->page->assign('diyList', $diyList, true);
        $this->page->assign('navtitle', $page['title']);
        $this->page->assign('metakeywords', $page['intro']);
        $this->page->assign('logo', $page['logo']);
        $this->page->assign('page_id', $page['id']);
        $this->page->assign('page', $page);
        $this->page->assign('goods_list', $goods_list);
        $this->page->assign('activity_goods_list', $activity_goods_list);
        $this->page->assign('check_so_position', $check_so_position);
        require_once libfile('function/discuzcode');
        $this->page->assign('check_brand_so_position', $check_brand_so_position);
        $this->page->assign('check_aljtc_so_lbs', $check_aljtc_so_lbs);
        $this->page->assign('check_footernav_position', $check_footernav_position);
        $this->page->assign('page_list', $page_list);
        $this->page->display();
    }
    /**
     * Ʒ���̼ҹ�������ע��
     *
     *
     * @return void
     */
    public function aljbdParameter(){
        global $Html5Plusapp,$immersed;
        $settings=C::t('#aljbd#aljbd_setting')->range();
        
        $mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_common_footernav']['value']));
        foreach($mobile_common_footernav as $key=>$value){
            $arr=explode('|',$value);
            $mobile_common_footernav_arr[]=$arr;
        }
        $lazyloadlogo = $settings['lazyloadlogo']['value'];
        if ($lazyloadlogo) {
            $loading = $lazyloadlogo;
        } else {
            $loading = 'source/plugin/aljbd/images/loading.gif';
        }
        $price_unit = '&#65509;';
        $this->page->assign('loading', $loading);
        $this->page->assign('noimg', 'source/plugin/aljbd/images/sj/noimg.gif');
        $this->page->assign('price_unit', $price_unit,true);
        $this->page->assign('pluginid', 'aljbd');
        $this->page->assign('Html5Plusapp', $Html5Plusapp);
        $this->page->assign('immersed', $immersed);
        $this->page->assign('settings', $settings);
        $this->page->assign('mobile_common_footernav_arr', $mobile_common_footernav_arr,true);
        $this->page->assign('common_template_pluginid', 'aljbd');
        $this->page->assign('common_path', 'source/plugin/aljhtx/');
    }
}

