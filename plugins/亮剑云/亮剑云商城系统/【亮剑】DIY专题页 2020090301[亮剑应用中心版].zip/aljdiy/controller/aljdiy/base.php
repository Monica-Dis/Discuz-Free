<?php

/**
 * �������̳�
 *
 * @author <dism.taobao.com>
 * @version 2019080501
 * @link https://dism.taobao.com/
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class Base{
    public $page;
    public $admin_id;
    public $brand_id;
    public function __construct() {
        global $requestPage, $_G;
        $this->page = $requestPage;
        $this->admin_id = intval($_GET['admin_id']);
        $this->brand_id = intval($_GET['brand_id']);
        $this->page->assign('brand_id', $this->brand_id);
        if (empty($this->page->global->uid)) {
            dheader("location:" . LOGIN_URL);
            exit;
        } else if($this -> admin_id){
            $user = DB::fetch_first('select * from %t where username=%s and admin_id = %d', array('aljam_user', $_G['username'], $this->admin_id));
            $user_role = DB::fetch_first('select * from %t where id=%s', array('aljam_role', $user['role_id']));
            $nav_list = DB::fetch_all('select * from %t where id in (%i)', array('aljam_nav', $user_role['nav_id_list']));
            foreach($nav_list as $nav){
                    $url = parse_url($nav['url']);
                    parse_str($url['query'], $url_param);
                    if($_GET['c'] == $url_param['c']){
                        $allow = true;
                        break;
                    }
            }
        }else if($_GET['brand_id']>0){
            $branddiy = DB::fetch_first('select a.*,b.title,b.store_authority from %t a left join %t b on a.vipid=b.id where a.id=%d ',array('aljbd','aljbd_vip',$this->brand_id));
            if($branddiy){
                $branddiy['store_authority'] = explode(',',$branddiy['store_authority']);
                $this->page->assign('branddiy', $branddiy);
                $this->page->assign('com_url', '&brand_id='.$this->brand_id,true);
            }
            if(!in_array('brand_diy',$branddiy['store_authority'])){
                $this->page->showmessage("aljdiy:base_php_1");
                exit;
            }
            
        } else if (empty($allow) && !in_array($this->page->loginUser->groupid, $this->page->config->{PLUGIN_ID}->gids)) {
            $this->page->showmessage("aljdiy:base_php_2");
            exit;
        }
        
    }
}

