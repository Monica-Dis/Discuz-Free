<?php

/**
 * �������̳�
 *
 * @author <dism.taobao.com>
 * @version 2019080501
 * @link https://dism.taobao.com/
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class DiyAction extends Base{
    public $page;
    public $page_id;

    public function __construct($page) {
        $this->page = $page;
        $this->table = 'aljbd_goods';
        //$this->bid = $this->page->get->bid;
        parent::__construct();
        $this->page_id = intval($_GET['page_id']);
        if($this->page_id > 0){
            DB::query('update %t set updatetime=%d where id=%d', array('aljdiy_page', TIMESTAMP, $this->page_id));
        }
        $this->page->assign('noimg', 'source/plugin/aljbd/images/sj/noimg.gif');
    }
    /**
     * Ʒ���̼�-��Ʒ������ȡ
     *
     * @return void
     */
    public function select_goods(){

        $yid = intval($_GET['yid']);
        $per = 8;
        $page = $this->page->get->page>0 ? $this->page->get->page :1;
        $start = ($page - 1) * $per;

        $where = ' where rubbish = 0 and state = 0 ';
        $conn = array($this->table);
        if($_GET['search']){
            $search = '%'.stripsearchkey($_GET['search']).'%';
            $where .= ' and name like %s';
            $conn[] = $search;
        }

        if($_GET['first_type']){
            $where .= ' and type = %d';
            $conn[] = $_GET['first_type'];
        }

        if($_GET['second_type']){
            $where .= ' and subtype = %d';
            $conn[] = $_GET['second_type'];
        }

        if($_GET['third_type']){
            $where .= ' and subtype3 = %d';
            $conn[] = $_GET['third_type'];
        }
        if($_GET['goodstype']){
            $where .= ' and store_id > 0 AND commodity_type <4';
        }else{
            $where .= ' and store_id = 0';
        }
        $count = DB::result_first('select count(*) from %t ' . $where, $conn);
        
        
        
        $conn[] = $start;
        $conn[] = $per;
        $data = DB::fetch_all('select * from %t '. $where .' order by id desc limit %d, %d', $conn);
        $diy = DB::fetch_first('select * from %t where id=%d', array('aljdiy_diy', $yid));
        if($diy['data']){
            $select_goods = DB::fetch_all('select * from %t where id in (%i)', array('aljbd_goods', $diy['data']));
        }
        $diy['data'] = explode(',', $diy['data']);
        foreach($data as $k => $goods){
            if(in_array($goods['id'], $diy['data'])){
                $data[$k]['check'] = 1;
            }else{
                $data[$k]['check'] = 0;
            }
        }

        

        if($_GET['op'] == 'get_goods_list'){
            $new_data = array('data' => T::ajaxPostCharSet($data), 'count' => $count);
            echo json_encode($new_data);
            exit;
        }else{
            $this->page->assign('count', $count);
            $this->page->assign('yid', $yid);
            $this->page->assign('select_goods', $select_goods);
            $this->page->assign('first_type', intval($_GET['first_type']));
            $this->page->assign('second_type', intval($_GET['second_type']));
            $this->page->assign('third_type', intval($_GET['third_type']));
            $this->page->display();
        }
    }
    /**
     * Ʒ���̼�-�̼�������ȡ
     *
     * @return void
     */
    public function select_brand(){

        $yid = intval($_GET['yid']);
        $per = 8;
        $page = $this->page->get->page>0 ? $this->page->get->page :1;
        $start = ($page - 1) * $per;

        $where = ' where rubbish = 0 and status=1';
        $conn = array('aljbd');
        if($_GET['search']){
            $search = '%'.stripsearchkey($_GET['search']).'%';
            $where .= ' and name like %s';
            $conn[] = $search;
        }

        if($_GET['first_type']){
            $where .= ' and type = %d';
            $conn[] = $_GET['first_type'];
        }

        if($_GET['second_type']){
            $where .= ' and subtype = %d';
            $conn[] = $_GET['second_type'];
        }

        if($_GET['third_type']){
            $where .= ' and subtype3 = %d';
            $conn[] = $_GET['third_type'];
        }

        $count = DB::result_first('select count(*) from %t ' . $where, $conn);
        
        
        
        $conn[] = $start;
        $conn[] = $per;
        $data = DB::fetch_all('select * from %t '. $where .' order by id desc limit %d, %d', $conn);
        $diy = DB::fetch_first('select * from %t where id=%d', array('aljdiy_diy', $yid));
        
 
        if($diy['data']){
            $select_brand = DB::fetch_all('select * from %t where id in (%i)', array('aljbd', $diy['data']));
        }
        
        $diy['data'] = explode(',', $diy['data']);
        foreach($data as $k => $goods){
            if(in_array($goods['id'], $diy['data'])){
                $data[$k]['check'] = 1;
            }else{
                $data[$k]['check'] = 0;
            }
        }

        if($_GET['op'] == 'get_brand_list'){
            $new_data = array('data' => T::ajaxPostCharSet($data), 'count' => $count);
            echo json_encode($new_data);
            exit;
        }else{
            $this->page->assign('count', $count);
            $this->page->assign('yid', $yid);
            $this->page->assign('select_brand', $select_brand);
            $this->page->assign('first_type', intval($_GET['first_type']));
            $this->page->assign('second_type', intval($_GET['second_type']));
            $this->page->assign('third_type', intval($_GET['third_type']));
            $this->page->display();
        }
    }
    /**
     * ͬ���ŵ�-�ŵ�������ȡ
     *
     * @return void
     */
    public function select_store(){

        $yid = intval($_GET['yid']);
        $per = 8;
        $page = $this->page->get->page>0 ? $this->page->get->page :1;
        $start = ($page - 1) * $per;

        $where = ' where tc_rubbish = 0 and tc_status=1';
        $conn = array('aljtsq_store');
        if($_GET['search']){
            $search = '%'.stripsearchkey($_GET['search']).'%';
            $where .= ' and tc_store_name like %s';
            $conn[] = $search;
        }

        if($_GET['first_type']){
            $where .= ' and tc_type = %d';
            $conn[] = $_GET['first_type'];
        }

        if($_GET['second_type']){
            $where .= ' and tc_subtype = %d';
            $conn[] = $_GET['second_type'];
        }

        if($_GET['third_type']){
            $where .= ' and tc_subtype3 = %d';
            $conn[] = $_GET['third_type'];
        }

        $count = DB::result_first('select count(*) from %t ' . $where, $conn);
        
        
        
        $conn[] = $start;
        $conn[] = $per;
        $data = DB::fetch_all('select * from %t '. $where .' order by tc_id desc limit %d, %d', $conn);
        $diy = DB::fetch_first('select * from %t where id=%d', array('aljdiy_diy', $yid));
        
 
        if($diy['data']){
            $select_store = DB::fetch_all('select * from %t where tc_id in (%i)', array('aljtsq_store', $diy['data']));
            foreach($select_store as $ss_k =>$ss_v){
                $select_store[$ss_k][id] = $ss_v['tc_id'];
                $select_store[$ss_k][name] = $ss_v['tc_store_name'];
                $select_store[$ss_k][logo] = $ss_v['tc_logo'];
            }
        }
        
        $diy['data'] = explode(',', $diy['data']);
        foreach($data as $k => $goods){
            if(in_array($goods['tc_id'], $diy['data'])){
                $data[$k]['check'] = 1;
            }else{
                $data[$k]['check'] = 0;
            }
        }

        if($_GET['op'] == 'get_store_list'){
            $new_data = array('data' => T::ajaxPostCharSet($data), 'count' => $count);
            echo json_encode($new_data);
            exit;
        }else{
            $this->page->assign('count', $count);
            $this->page->assign('yid', $yid);
            $this->page->assign('select_store', $select_store);
            $this->page->assign('first_type', intval($_GET['first_type']));
            $this->page->assign('second_type', intval($_GET['second_type']));
            $this->page->assign('third_type', intval($_GET['third_type']));
            $this->page->display();
        }
    }
    /**
     * ����ģ��
     *
     * @return void
     */
    public function addmod(){
        $atime = 0;
        $page_id = $_GET['page_id'];
        if($_GET['diyid']){
            $curDiyModule = DB::fetch_first('select * from %t where auto_module = %s', array('aljdiy_diy', $_GET['diyid']));
            if($curDiyModule['displayorder'] > 0){
                $atime = $curDiyModule['displayorder'] + 1;
                $diss = DB::fetch_all('select * from %t where page_id=%d and displayorder>%i and module != %s order by displayorder asc',array('aljdiy_diy',$curDiyModule['page_id'],$curDiyModule['displayorder'],'gg_icon'));
                $atii = $atime;
                foreach($diss as $dis_v){
                    $atii++;
                    DB::query('update %t set displayorder = %d where id=%d', array('aljdiy_diy',$atii, $dis_v['id']));
                }
            }
        }
        $data = array(
            'page_id' => $_GET['page_id'],
            'module' => $_GET['module'],
            'auto_module' => $_GET['module'].'_'.random(16),
            'template' => $_GET['module'],
            'displayorder' => $atime
        );
        
        if($_GET['module'] == 'banner'){
            $data['data'] = 'https://oss.liangjianyun.com/markdown/2019-03-26-113449.jpg';
        }else if($_GET['module'] == 'mobile_index_tad'){
            $data['data'] = 'https://oss.liangjianyun.com/markdown/2019-08-01-040510.jpg|https://dism.taobao.com?/aljbd/
            https://oss.liangjianyun.com/markdown/2019-08-01-040558.jpg|https://dism.taobao.com?/aljbd/
            https://oss.liangjianyun.com/markdown/2019-08-01-040704.jpg|https://dism.taobao.com?/aljbd/';
        }else if($_GET['module'] == 'mobile_index_fad'){
            $data['data'] = 'https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/Four_ads_left_1.jpg|https://dism.taobao.com?/aljbd/
            https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/Four_ads_left_2.jpg|https://dism.taobao.com?/aljbd/
https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/Four_ads_right_1.jpg|https://dism.taobao.com?/aljbd/
https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/Four_ads_right_2.jpg|https://dism.taobao.com?/aljbd/';
        }else if($_GET['module'] == 'swiper_container'){
            $data['data'] = 'https://liangjianyun.oss-cn-shanghai.aliyuncs.com/markdown/2018-09-14-061126.png|https://dism.taobao.com?/aljbd/|1
            https://liangjianyun.oss-cn-shanghai.aliyuncs.com/markdown/2018-09-14-061512.png|https://dism.taobao.com?/aljbd/|2
            https://liangjianyun.oss-cn-shanghai.aliyuncs.com/markdown/2018-09-14-061640.png|https://dism.taobao.com?/aljbd/|3';
        }else if($_GET['module'] == 'swiper_container_horizontal'){
            $data['data'] = '&#32534;&#30721;&#36716;&#25442;|#|https://oss.dzx30.com/aljhtx/setting/20190425/1556178118867.png
            &#34092;&#32;&#32;&#33756;|#|https://oss.dzx30.com/aljhtx/setting/20190425/1556178146213.png
            &#32905;&#40060;&#31165;&#34507;|#|https://oss.dzx30.com/aljhtx/setting/20190425/1556178156942.png
            &#31918;&#27833;&#35843;&#21619;|#|https://oss.dzx30.com/aljhtx/setting/20190425/1556178168295.png
            &#29087;&#39135;&#38754;&#28857;|#|https://oss.dzx30.com/aljhtx/setting/20190425/1556178182234.png
            &#29275;&#22902;&#38754;&#21253;|#|https://oss.dzx30.com/aljhtx/setting/20190425/1556178193563.png
            &#37202;&#27700;&#20914;&#39278;|#|https://oss.dzx30.com/aljhtx/setting/20190425/1556178203104.png
            &#20919;&#34255;&#20919;&#20923;|#|https://oss.dzx30.com/aljhtx/setting/20190425/1556178215426.png
            &#20241;&#38386;&#38646;&#39135;|#|https://oss.dzx30.com/aljhtx/setting/20190425/1556178231963.png
            &#26085;&#29992;&#28165;&#27905;|#|https://oss.dzx30.com/aljhtx/setting/20190425/1556178134810.png';
        }else if($_GET['module'] == 'mobile_common_footernav'){
            $data['data'] = 'https://oss.dzx30.com/aljhtx/setting/20190507/1557225564703.png|https://oss.dzx30.com/aljhtx/setting/20190507/1557225564852.png|��ҳ|#|#f42424|0
            https://oss.dzx30.com/aljhtx/setting/20190507/1557225592859.png|https://oss.dzx30.com/aljhtx/setting/20190507/1557225592840.png|����|#|#f42424|0
            https://oss.dzx30.com/aljhtx/setting/20190507/1557225446492.png|https://oss.dzx30.com/aljhtx/setting/20190507/1557225446191.png|��Ϣ|#|#f42424|0
            https://oss.dzx30.com/aljhtx/setting/20190621/1561110239753.png|https://oss.dzx30.com/aljhtx/setting/20190621/1561110239162.png|ƴ��|#|#f42424|0
            https://oss.dzx30.com/aljhtx/setting/20190507/1557225632505.png|https://oss.dzx30.com/aljhtx/setting/20190507/1557225632701.png|�ҵ�|#|#f42424|0';
        }else if($_GET['module'] == 'mobile_index_Photo_Ads'){
            $data['data'] = '&#25340;&#22242;|&#22810;&#20154;&#25340;&#22242;&#20215;&#26684;&#23454;&#24800;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_pt.png|plugin.php?id=aljbd&act=goods&commodity_type=2
            &#24110;&#21161;&#20013;&#24515;|&#24179;&#21488;&#30334;&#23453;&#31665;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_bc.png|plugin.php?id=aljhelp&a=help&c=help
            &#22242;&#36141;|&#38480;&#26102;&#31186;&#26432;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_tg.png|plugin.php?id=aljbd&act=goods&commodity_type=1
            &#22825;&#22825;&#29305;&#24800;|&#39046;&#21048;&#19979;&#21333;&#26356;&#23454;&#24800;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_yh.png|plugin.php?id=aljbd&act=clist
            &#25105;&#30340;&#24494;&#24215;|&#21160;&#21160;&#25163;&#25351;&#29378;&#36186;&#22806;&#22359;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_fx.png|plugin.php?id=aljsfx&c=distribution&a=user
            &#38468;&#36817;&#21830;&#23478;|&#30465;&#26102;&#12289;&#30465;&#21147;&#12289;&#30465;&#24515;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_fj.png|plugin.php?id=aljbd&act=dianpu&lbs=yes';
        }else if($_GET['module'] == 'adv'){
            $data['data'] = 'https://oss.liangjianyun.com/markdown/2019-09-09-063634.jpg|#
            https://oss.liangjianyun.com/markdown/2019-09-09-063634.jpg|#
            https://oss.liangjianyun.com/markdown/2019-09-09-063634.jpg|#
            https://oss.liangjianyun.com/markdown/2019-09-09-063634.jpg|#';
        }else if($_GET['module'] == 'gg'){
            $data['data'] = 'test1|#
            test2|#';
        }else if($_GET['module'] == 'aljtc_hot'){
            $data['data'] = lang("plugin/aljdiy","diy_php_1").'|#FF2D2D
test1|#
test2|#';
        }else if($_GET['module'] == 'row_four_grids'){
            $data['data'] = 'https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljhtx/setting/20200208/1581133615843.png|#
https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljhtx/setting/20200208/1581133668516.png|#
https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljhtx/setting/20200208/1581133679480.png|#
https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljhtx/setting/20200208/1581133688644.png|#';
        }else if($_GET['module'] == 'aljtc_ckad'){
            $data['data'] = lang("plugin/aljdiy","diy_php_2").'|'.lang("plugin/aljdiy","diy_php_3").'|source/plugin/aljtc/static/img/ck1.png|plugin.php?id=aljtyh|#9096FD
'.lang("plugin/aljdiy","diy_php_4").'|'.lang("plugin/aljdiy","diy_php_5").'|source/plugin/aljtc/static/img/ck2.png|plugin.php?id=aljtyh|#F8B452';
        }else if($_GET['module'] == 'aljtc_left_bottom'){
            $data['data'] = lang("plugin/aljdiy","diy_php_6").'|https://liangjianyun.oss-cn-shanghai.aliyuncs.com/markdown/2019-03-12-080732.jpg
'.lang("plugin/aljdiy","diy_php_7").'|https://liangjianyun.oss-cn-shanghai.aliyuncs.com/markdown/2019-03-12-080732.jpg';
        }else if($_GET['module'] == 'poster'){
            $data['data'] = 'https://oss.liangjianyun.com/aljhtx/setting/20190807/1565183450685.png|164|164|125|104|'.lang("plugin/aljdiy","diy_php_8").'|'.lang("plugin/aljdiy","diy_php_9").'|#63AEFF|'.lang("plugin/aljdiy","diy_php_10").'|'.lang("plugin/aljdiy","diy_php_11");
        }else if($_GET['module'] == 'common_follow'){
            $data['data'] = 'https://oss.liangjianyun.com/aljhtx/setting/20190809/1565320354689.png|'.lang("plugin/aljdiy","diy_php_12").'|'.lang("plugin/aljdiy","diy_php_13").'|'.lang("plugin/aljdiy","diy_php_14").'|#cd2525|1|'.lang("plugin/aljdiy","diy_php_15").'|���ѹ�ע|86400';
        }else if($_GET['module'] == 'pop'){
            $data['data'] = 'https://oss.liangjianyun.com/markdown/2019-08-10-112321.gif|86400';
        }else if($_GET['module'] == 'so'){
            $data['data'] = 'source/plugin/aljdiy/static/images/btype.png|source/plugin/aljdiy/static/images/badd.png|'.lang("plugin/aljdiy","diy_php_16").'|plugin.php?id=aljbd&act=search|plugin.php?id=aljbd&act=type|plugin.php?id=aljbd&act=attend|#63AEFF|0';
        }else if($_GET['module'] == 'brand_so'){
            $data['data'] = 'source/plugin/aljbd/template/touch/view/bdeta_06.png|source/plugin/aljbd/template/touch/view/bdian.png|'.lang("plugin/aljdiy","diy_php_17").'|plugin.php?id=aljbd&act=view&op=search|javascript:;||#f42424|0|#f42424';
        }else if($_GET['module'] == 'aljtc_statistics'){
            $data['data'] = 'https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljhtx/setting/20200208/1581147798591.png|#f42424|'.lang("plugin/aljdiy","diy_php_18").'|#';
        }else if($_GET['module'] == 'brand_nav'){
            $data['data'] = 'source/plugin/aljbd/images/sj/shang.png|plugin.php?id=aljbd&act=view|'.lang("plugin/aljdiy","diy_php_19").'
source/plugin/aljbd/template/touch/view/images/aljtc.png|plugin.php?id=aljbd&act=view&op=aljtc|'.lang("plugin/aljdiy","diy_php_20").'
source/plugin/aljbd/images/sj/consume.png|plugin.php?id=aljbd&act=view&op=consume|'.lang("plugin/aljdiy","diy_php_21").'
source/plugin/aljbd/images/sj/hd.png|plugin.php?id=aljbd&act=view&op=notice|'.lang("plugin/aljdiy","diy_php_22").'
source/plugin/aljbd/images/sj/v_r.png|plugin.php?id=aljbd&act=view&op=reply|'.lang("plugin/aljdiy","diy_php_23").'
source/plugin/aljbd/images/sj/shipin.png|plugin.php?id=aljbd&act=view&op=video|'.lang("plugin/aljdiy","diy_php_24").'
source/plugin/aljbd/images/sj/xx.png|plugin.php?id=aljbd&act=view&op=details|'.lang("plugin/aljdiy","diy_php_25").'
source/plugin/aljbd/images/sj/goods.png|plugin.php?id=aljbd&act=view&op=goods|'.lang("plugin/aljdiy","diy_php_26").'
source/plugin/aljbd/images/sj/album.png|plugin.php?id=aljbd&act=view&op=album|'.lang("plugin/aljdiy","diy_php_27");
            $data['set_up'] = serialize(array('diy_border_radius'=>'10','diy_margin'=>array('top'=>'-20','right'=>'10','bottom'=>'10','left'=>'10'),'diy_padding'=>array('top'=>'0','right'=>'0','bottom'=>'0','left'=>'0'),'diy_sel_color'=>'#f42424'));
        }else if($_GET['module'] == 'brand_footer'){
            $data['data'] = 'source/plugin/aljbd/images/footer/mobile/brand_footer_info.png|plugin.php?id=aljbd&act=view_about|'.lang("plugin/aljdiy","diy_php_28").'
source/plugin/aljbd/images/footer/mobile/brand_footer_type.png|plugin.php?id=aljbd&act=view&op=btype|'.lang("plugin/aljdiy","diy_php_29").'
source/plugin/aljbd/images/footer/mobile/brand_footer_share.png|javascript::takeScreenshot()|'.lang("plugin/aljdiy","diy_php_30").'
source/plugin/aljbd/images/footer/mobile/brand_footer_kefu.png|plugin.php?id=aljol&act=talk&friendid=|'.lang("plugin/aljdiy","diy_php_31");
        }else if($_GET['module'] == 'aljtsq_store_add'){
            $data['set_up'] = serialize(array('diy_border_radius'=>'20','diy_margin'=>array('top'=>'0','right'=>'10','bottom'=>'0','left'=>'10'),'diy_padding'=>array('top'=>'0','right'=>'0','bottom'=>'0','left'=>'0')));
        }else if($_GET['module'] == 'sky_mod'){
            $data['data'] = 'https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljhtx/setting/20200828/1598609006535.png|'.lang("plugin/aljdiy","diy_php_32").'|#9096FD|#ffffff|#';
        }else if($_GET['module'] == 'wechat_group'){
            $data['data'] = 'https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljhtx/setting/20200829/1598671809552.png|https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljhtx/setting/20200829/1598671809898.png|#9096FD|#ffffff|'.lang("plugin/aljdiy","diy_php_33").'|'.lang("plugin/aljdiy","diy_php_34").'|'.lang("plugin/aljdiy","diy_php_35").'|'.lang("plugin/aljdiy","diy_php_36").'|'.lang("plugin/aljdiy","diy_php_37").'|'.lang("plugin/aljdiy","diy_php_38");
        }else if(strpos($_GET['module'],"brand_") !== false && !in_array($_GET['module'],array('brand_goods','brand_info'))){//δ���⴦���ĵ���ģ���������༰Բ��
            $data['set_up'] = serialize(array('diy_border_radius'=>'10','diy_margin'=>array('top'=>'0','right'=>'10','bottom'=>'10','left'=>'10'),'diy_padding'=>array('top'=>'0','right'=>'0','bottom'=>'0','left'=>'0')));
        }
        
        $mod_array = array(
            'mobile_common_footernav', 
            'gg', 'video', 
            'common_follow', 
            'poster', 
            'pop', 
            'so', 
            'ms', 
            'global_bottom',
            'aljtc_global_bottom',
            'aljtsc_global_bottom',
            'brand_gg',
            'brand_so',
            'brand_footer',
        );
        $mod_list_array = array(
            'thread', 
            'article', 
            'goods_type', 
            'guess_goods',
            'activity_type',
            'aljtc_list',
            'brand_goods',
            'aljtsc_goods',
            'aljtsq_store_list',
        );
        if((in_array($_GET['module'], $mod_array) 
        && DB::result_first('select count(*) from %t where page_id=%d and module=%s', array('aljdiy_diy', $this->page_id, $_GET['module'])) > 0) 
        || (in_array($_GET['module'], $mod_list_array) && DB::result_first('select count(*) from %t where page_id=%d and module IN (%n)', array('aljdiy_diy', $this->page_id, $mod_list_array)) > 0)
        ){
            echo 1;
            exit;
        }else{
            DB::insert('aljdiy_diy', $data);
            if($_GET['module'] == 'gg'){
                DB::insert('aljdiy_diy', array(
                    'page_id' => $_GET['page_id'],
                    'module' => 'gg_icon',
                    'auto_module' => 'gg_icon',
                    'template' => '',
                    'data' => 'https://oss.liangjianyun.com/markdown/2019-08-01-190252.png',
                    'displayorder' => $atime,
                ));
            }
            self::clearSavecache ($page_id);
            echo $data['auto_module'];
        }
        exit;
        
    }
    /**
     * ����ģ�� ����
     *
     * @return void
     */
    public function modCopy(){
        $skey = $this->page->get->skey;
        $template = 'tpl_'.TIMESTAMP;
        DB::insert('aljdiy_diy', array(
            'page' => 'index',
            'type' => 'auto',
            'module' => $skey,
            'auto_module' => $skey.'_'.$template,
            'template' => $template,
            'displayorder' => DB::result_first('select max(displayorder) from %t', array('aljdiy_diy'))+1,
            'data' => $this->page->config->aljbd->$skey
        ));
    }
    /**
     * ɾ��ģ��
     *
     * @return void
     */
    public function modDelete(){
        $skey = $this->page->get->skey;
        $diy = DB::fetch_first('select * from %t where auto_module=%s', array('aljdiy_diy', $this->page->get->skey));
        DB::delete('aljdiy_diy', array(
            'auto_module' => $this->page->get->skey,
        ));
        if($diy['module'] == 'gg'){
            DB::delete('aljdiy_diy', array(
                'auto_module' => 'gg_icon',
                'page_id' => $diy['page_id']
            ));
        }
        self::clearSavecache ($diy['page_id']);
    }
    /**
     * ģ�����������ƶ�
     *
     * @return void
     */
    public function modUp(){
        $diy = DB::fetch_first('select * from %t where auto_module=%s', array('aljdiy_diy', $this->page->get->skey));
        $upDiy =  DB::fetch_first('select * from %t where displayorder<%i and module!=%s and page_id=%d order by displayorder desc', array('aljdiy_diy', $diy['displayorder'], 'gg_icon', $diy['page_id']));
        
        if($diy && $upDiy){
            DB::update('aljdiy_diy', array(
                'displayorder' => $diy['displayorder']
            ), array(
                'id' => $upDiy['id']
            ));

            DB::update('aljdiy_diy', array(
                'displayorder' => $upDiy['displayorder']
            ), array(
                'id' => $diy['id']
            ));
            self::clearSavecache ($diy['page_id']);
        }
    }
    /**
     * ģ�����������ƶ�
     *
     * @return void
     */
    public function modDown(){
        $diy = DB::fetch_first('select * from %t where auto_module=%s and page_id=%d', array('aljdiy_diy', $this->page->get->skey, $this->page_id));
        $downDiy =  DB::fetch_first('select * from %t where displayorder>%i and page_id=%d and module!=%s order by displayorder asc', array('aljdiy_diy', $diy['displayorder'], $this->page_id, 'gg_icon'));
        if($diy && $downDiy){
            DB::update('aljdiy_diy', array(
                'displayorder' => $diy['displayorder']
            ), array(
                'id' => $downDiy['id']
            ));

            DB::update('aljdiy_diy', array(
                'displayorder' => $downDiy['displayorder']
            ), array(
                'id' => $diy['id']
            ));
            self::clearSavecache ($diy['page_id']);
        }
    }

    /**
     * �������������ƶ�
     *
     * @return void
     */
    public function faArrowDown(){
        $skey = $this->page->get->skey;
        $diy = DB::fetch_first('select * from %t where auto_module=%s and page_id=%d', array('aljdiy_diy', $skey, $this->page_id));
        $lz_types = T::stringSettingToArray($diy['data']);
        $tmp = $lz_types[$this->page->get->displayorder];
        $lz_types[$this->page->get->displayorder] = $lz_types[$this->page->get->displayorder+1];
        $lz_types[$this->page->get->displayorder+1] = $tmp;
        $lz_types = T::arrayToStringSetting($lz_types);
        DB::update('aljdiy_diy', array('data' => $lz_types), array(
            'auto_module' => $skey,
            'page_id' => $this->page_id,
        ));
        self::clearSavecache ($diy['page_id']);
        T::responseJson();

    }

    /**
     * �������������ƶ�
     *
     * @return void
     */
    public function faArrowUp(){
        $skey = $this->page->get->skey;
        $diy = DB::fetch_first('select * from %t where auto_module=%s and page_id=%d', array('aljdiy_diy', $skey, $this->page_id));
        $lz_types = T::stringSettingToArray($diy['data']);
        $tmp = $lz_types[$this->page->get->displayorder];
        $lz_types[$this->page->get->displayorder] = $lz_types[$this->page->get->displayorder-1];
        $lz_types[$this->page->get->displayorder-1] = $tmp;
        $lz_types = T::arrayToStringSetting($lz_types);
        DB::update('aljdiy_diy', array('data' => $lz_types), array(
            'auto_module' => $skey,
            'page_id' => $this->page_id
        ));
        self::clearSavecache ($diy['page_id']);
        T::responseJson();

    }
    /**
     * ��Ʒ������ȡ
     *
     * @return void
     */
    public function get_type(){

        $data = C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($_GET['upid']);

        if(strtolower(CHARSET) == 'gbk'){
            foreach($data as $k => $v){
                $data[$k]['subject'] = diconv($data[$k]['subject'], 'gbk', 'utf-8');
            }
        }
        
        echo json_encode($data);
        exit;
    }
    /**
     * �������ȡ
     *
     * @return void
     */
    public function get_type_activity(){
        $data = DB::fetch_all('select * from %t where upid=%d', array('aljayy_type', $_GET['upid']));

        if(strtolower(CHARSET) == 'gbk'){
            foreach($data as $k => $v){
                $data[$k]['subject'] = diconv($data[$k]['subject'], 'gbk', 'utf-8');
            }
        }
        
        echo json_encode($data);
        exit;
    }
    /**
     * �̼�/�ŵ������ȡ
     *
     * @return void
     */
    public function get_type_brand(){
        $data = C::t('#aljbd#aljbd_type')->fetch_all_by_upid($_GET['upid']);

        if(strtolower(CHARSET) == 'gbk'){
            foreach($data as $k => $v){
                $data[$k]['subject'] = diconv($data[$k]['subject'], 'gbk', 'utf-8');
            }
        }
        
        echo json_encode($data);
        exit;
    }
    /**
     * ��ջ���
     *
     *
     * @return void
     */
    public function clearSavecache ($page_id) {
        savecache('aljdiy_list', array($page_id=>''));//ģ�����ݻ��� ���
        savecache('aljdiy', array($page_id=>''));//ҳ������ģ�黺�� ���
    }
    
    /**
     * DIY��ҳ
     *
     *
     * @return void
     */
    public function index()
    {
        
        global $_G;
        $page_id = intval($_GET['page_id']);
        $skey = $this->page->get->skey;
        $diy = DB::fetch_first('select * from %t where auto_module=%s and page_id=%d', array('aljdiy_diy', $skey, $page_id));
        if ($this->page->get->deletesubmit) {
            if($diy['module'] == 'global_bottom'){
                $settings=C::t('#aljbd#aljbd_setting')->range();
                $mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_common_footernav']['value']));
                foreach($mobile_common_footernav as $key=>$value){
                    $arr=explode('|',$value);
                    $mobile_common_footernav_arr[]=$arr;
                }
                $lz_types = $mobile_common_footernav_arr;
                unset($lz_types[$this->page->get->displayorder]);
                $lz_types = array_values($lz_types);
                $lz_types = T::arrayToStringSetting($lz_types);
                C::t('#aljbd#aljbd_setting')->update_value_by_key($lz_types,'mobile_common_footernav');
                savecache('aljbd_settings', '');
            }else{
                $lz_types = T::stringSettingToArray($diy['data']);
                unset($lz_types[$this->page->get->displayorder]);
                $lz_types = array_values($lz_types);
                $lz_types = T::arrayToStringSetting($lz_types);
                DB::update('aljdiy_diy', array('data' => $lz_types), array(
                    'auto_module' => $skey,
                    'page_id' => $page_id,
                ));
            }
            
            self::clearSavecache ($page_id);
            $this->page->tips(2, $skey . '_' . $this->page->get->displayorder);
            exit;
        }
        
        if (submitcheck('formhash')) {
            self::clearSavecache ($page_id);
            if($_GET['mpb'] == 1){//����߾ദ������
                
                DB::update('aljdiy_diy', array('set_up' => serialize($_GET['diy_from'])), array(
                    'auto_module' => $skey,
                    'page_id' => $page_id,
                ));
                $this->page->tips();
                exit;
            }
            if($diy['module'] == 'custom'){
                DB::update('aljdiy_diy', array('data' => $_GET[$skey]), array(
                    'auto_module' => $skey,
                    'page_id' => $page_id,
                ));
                $this->page->tips();
                exit;
            }else if($diy['module'] == 'activity_recommend_goods'){
                DB::update('aljdiy_diy', array('data' => implode(',', $_GET['activity_recommend_goods'])), array(
                    'auto_module' => $skey,
                    'page_id' => $page_id,
                ));
                $this->page->tips();
                exit;
            }else if($diy['module'] == 'activity_recommend_brand'){
                DB::update('aljdiy_diy', array('data' => implode(',', $_GET['activity_recommend_brand'])), array(
                    'auto_module' => $skey,
                    'page_id' => $page_id,
                ));
                $this->page->tips();
                exit;
            }else if($diy['module'] == 'activity_recommend_store'){
                DB::update('aljdiy_diy', array('data' => implode(',', $_GET['activity_recommend_store'])), array(
                    'auto_module' => $skey,
                    'page_id' => $page_id,
                ));
                $this->page->tips();
                exit;
            }else if($diy['module'] == 'global_bottom'){
                $settings=C::t('#aljbd#aljbd_setting')->range();
                $mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_common_footernav']['value']));
                foreach($mobile_common_footernav as $key=>$value){
                    $arr=explode('|',$value);
                    $mobile_common_footernav_arr[]=$arr;
                }
                $lz_types = $mobile_common_footernav_arr;
                
            }else if($diy['module'] == 'aljtc_global_bottom'){
                $settings=C::t('#aljtc#aljtc_setting')->range();
                $mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_footer_nav']['value']));
                foreach($mobile_common_footernav as $key=>$value){
                    $arr=explode('|',$value);
                    $mobile_common_footernav_arr[]=$arr;
                }
                $lz_types = $mobile_common_footernav_arr;
                
            }else{
                $lz_types = T::stringSettingToArray($diy['data']);
            }
            
            $displayorder = $this->page->get->displayorder;
            $pic = T::getPhotoFilePath();
            
            if ($this->page->get->uploadPhoto && $this->page->get->size == strlen($this->page->get->uploadPhoto)) {
                file_put_contents($pic, file_get_contents($this->page->get->uploadPhoto));
                if (file_exists($pic)) {
                    if($this->page->config->aljoss->Access_Key){
                        $pic = T::oss($pic, 'aljhtx/setting');
                    }
                    if($diy['module'] == 'mobile_index_Photo_Ads' || $diy['module'] == 'swiper_container_horizontal' || $diy['module'] == 'aljtc_ckad'){
                        $lz_types[$displayorder][2] = $pic;
                    }else{
                        $lz_types[$displayorder][0] = $pic;
                    }

                }
            }
            
            $pic_two = T::getPhotoFilePath();
            if ($this->page->get->uploadPhoto_two && $this->page->get->size_two == strlen($this->page->get->uploadPhoto_two)) {
                file_put_contents($pic_two,file_get_contents($this->page->get->uploadPhoto_two));
                if (file_exists($pic_two)) {
                    if($this->page->config->aljoss->Access_Key){
                        $pic_two = T::oss($pic_two, 'aljhtx/setting');
                    }
                    $lz_types[$displayorder][1] = $pic_two;
                    
                }
            }


            if($diy['module'] == 'mobile_index_Photo_Ads'){
                $lz_types[$displayorder][0] = $this->page->get->title;
                $lz_types[$displayorder][1] = $this->page->get->desc;
                $lz_types[$displayorder][3] = $this->page->get->url;
            }else if($diy['module'] == 'mobile_common_footernav'){
                if(empty($lz_types[$displayorder][0])){
                    $lz_types[$displayorder][0] = '';
                }
                if(empty($lz_types[$displayorder][1])){
                    $lz_types[$displayorder][1] = '';
                }
                $lz_types[$displayorder][2] = $this->page->get->title;
                $lz_types[$displayorder][3] = $this->page->get->url;
                $lz_types[$displayorder][4] = $this->page->get->color;
                $lz_types[$displayorder][5] = $this->page->get->is_tq;
                
            }else if($diy['module'] == 'global_bottom'){
                
                if(empty($lz_types[$displayorder][0])){
                    $lz_types[$displayorder][0] = '';
                }
                if(empty($lz_types[$displayorder][1])){
                    $lz_types[$displayorder][1] = '';
                }
                $lz_types[$displayorder][2] = $this->page->get->title;
                $lz_types[$displayorder][3] = $this->page->get->url;
                
                $lz_types[$displayorder][4] = $this->page->get->is_tq;
                $lz_types = T::arrayToStringSetting($lz_types);
                
                C::t('#aljbd#aljbd_setting')->update_value_by_key($lz_types,'mobile_common_footernav');
                savecache('aljbd_settings', '');
                
                $this->page->tips();
                exit;
            }else if($diy['module'] == 'aljtc_global_bottom'){
                
                if(empty($lz_types[$displayorder][0])){
                    $lz_types[$displayorder][0] = '';
                }
                if(empty($lz_types[$displayorder][1])){
                    $lz_types[$displayorder][1] = '';
                }
                $lz_types[$displayorder][2] = $this->page->get->title;
                $lz_types[$displayorder][3] = $this->page->get->url;
                
                $lz_types[$displayorder][4] = $this->page->get->is_tq;
                
                $lz_types = T::arrayToStringSetting($lz_types);
                
                C::t('#aljtc#aljtc_setting')->update_value_by_key($lz_types,'mobile_footer_nav');
                
                $this->page->tips();
                exit;
            }else if($diy['module'] == 'swiper_container_horizontal'){
                $lz_types[$displayorder][0] = $this->page->get->title;
                $lz_types[$displayorder][1] = $this->page->get->url;
                $lz_types[$displayorder][3] = $this->page->get->label;
            }else if($diy['module'] == 'video'){
                $lz_types[$displayorder][0] = $this->page->get->height;
                $lz_types[$displayorder][1] = $this->page->get->video_path;
            }else if($diy['module'] == 'sep'){
                $lz_types[$displayorder][0] = $this->page->get->height;
                $lz_types[$displayorder][1] = $this->page->get->color;
            }else if($diy['module'] == 'poster'){
                $lz_types[$displayorder][1] = $this->page->get->t1;
                $lz_types[$displayorder][2] = $this->page->get->t2;
                $lz_types[$displayorder][3] = $this->page->get->t3;
                $lz_types[$displayorder][4] = $this->page->get->t4;
                $lz_types[$displayorder][5] = $this->page->get->t5;
                $lz_types[$displayorder][6] = $this->page->get->t6;
                $lz_types[$displayorder][7] = $this->page->get->t7;
                $lz_types[$displayorder][8] = $this->page->get->t8;
                $lz_types[$displayorder][9] = $this->page->get->t9;
            }else if($diy['module'] == 'common_follow'){
                $lz_types[$displayorder][1] = $this->page->get->t1;
                $lz_types[$displayorder][2] = $this->page->get->t2;
                $lz_types[$displayorder][3] = $this->page->get->t3;
                $lz_types[$displayorder][4] = $this->page->get->t4;
                $lz_types[$displayorder][5] = $this->page->get->t5;
                $lz_types[$displayorder][6] = $this->page->get->t6;
                $lz_types[$displayorder][7] = $this->page->get->t7;
                $lz_types[$displayorder][8] = $this->page->get->t8;
                $lz_types[$displayorder][9] = $this->page->get->t9;
            }else if($diy['module'] == 'pop'){
                $lz_types[$displayorder][1] = $this->page->get->t1;
                $lz_types[$displayorder][2] = $this->page->get->t2;
            }else if($diy['module'] == 'so'){
                $lz_types[$displayorder][2] = $this->page->get->t2;
                $lz_types[$displayorder][3] = $this->page->get->t3;
                $lz_types[$displayorder][4] = $this->page->get->t4;
                $lz_types[$displayorder][5] = $this->page->get->t5;
                $lz_types[$displayorder][6] = $this->page->get->t6;
                $lz_types[$displayorder][7] = $this->page->get->t7;
            }else if($diy['module'] == 'brand_so'){
                $lz_types[$displayorder][2] = $this->page->get->t2;
                $lz_types[$displayorder][3] = $this->page->get->t3;
                $lz_types[$displayorder][4] = $this->page->get->t4;
                $lz_types[$displayorder][5] = $this->page->get->t5;
                $lz_types[$displayorder][6] = $this->page->get->t6;
                $lz_types[$displayorder][7] = $this->page->get->t7;
                $lz_types[$displayorder][8] = $this->page->get->t8;
            }else if($diy['module'] == 'aljtc_statistics'){
                $lz_types[$displayorder][1] = $this->page->get->t1;
                $lz_types[$displayorder][2] = $this->page->get->t2;
                $lz_types[$displayorder][3] = $this->page->get->t3;
            }else if($diy['module'] == 'aljtc_so'){
                $lz_types[$displayorder][0] = $this->page->get->t0;
                $lz_types[$displayorder][1] = $this->page->get->t1;
                $lz_types[$displayorder][2] = $this->page->get->t2;
                $lz_types[$displayorder][3] = $this->page->get->t3;
                $lz_types[$displayorder][4] = $this->page->get->t4;
                $lz_types[$displayorder][5] = $this->page->get->t5;
                $lz_types[$displayorder][6] = $this->page->get->t6;
                $lz_types[$displayorder][7] = $this->page->get->t7;
                $lz_types[$displayorder][8] = $this->page->get->t8;
                $lz_types[$displayorder][9] = $this->page->get->t9;
                $lz_types[$displayorder][10] = $this->page->get->t10;
            }else if($diy['module'] == 'aljtc_ckad'){
                $lz_types[$displayorder][0] = $this->page->get->t0;
                $lz_types[$displayorder][1] = $this->page->get->t1;
                $lz_types[$displayorder][3] = $this->page->get->t3;
                $lz_types[$displayorder][4] = $this->page->get->t4;
            }else if($diy['module'] == 'aljtc_left_bottom'){
                $lz_types[$displayorder][0] = $this->page->get->url;
            }else if($diy['module'] == 'aljtc_list'){
                $lz_types[$displayorder][0] = $this->page->get->t0;
            }else if($diy['module'] == 'aljtsq_store_list'){
                $lz_types[$displayorder][0] = $this->page->get->t0;
                $lz_types[$displayorder][1] = $this->page->get->t1;
            }else if($diy['module'] == 'goods_type'){
                $lz_types[$displayorder][0] = $this->page->get->t0;
                $lz_types[$displayorder][1] = $this->page->get->t1;
                $lz_types[$displayorder][2] = $this->page->get->t2;
                $lz_types[$displayorder][3] = $this->page->get->t3;
                $lz_types[$displayorder][4] = $this->page->get->t4;
                $lz_types[$displayorder][5] = $this->page->get->t5;
                $lz_types[$displayorder][6] = $this->page->get->t6;
            }else if($diy['module'] == 'activity_type'){
                $lz_types[$displayorder][0] = $this->page->get->t0;
                $lz_types[$displayorder][1] = $this->page->get->t1;
                $lz_types[$displayorder][2] = $this->page->get->t2;
            }else if($diy['module'] == 'guess_goods'){
                $lz_types[$displayorder][0] = $this->page->get->t0;
            }else if($diy['module'] == 'aljtsc_goods'){
                $lz_types[$displayorder][0] = $this->page->get->t0;
                $lz_types[$displayorder][1] = $this->page->get->t1;
            }else if($diy['module'] == 'ms'){
                $lz_types[$displayorder][0] = $this->page->get->t1;
                
            }else if($diy['module'] == 'aljtsq_store_add'){
                $lz_types[$displayorder][0] = $this->page->get->t1;
                
            }else if($diy['module'] == 'sky_mod'){
                $lz_types[$displayorder][1] = $this->page->get->t1;
                $lz_types[$displayorder][2] = $this->page->get->t2;
                $lz_types[$displayorder][3] = $this->page->get->t3;
                $lz_types[$displayorder][4] = $this->page->get->t4;
            }else if($diy['module'] == 'wechat_group'){
                
                $lz_types[$displayorder][2] = $this->page->get->t2;
                $lz_types[$displayorder][3] = $this->page->get->t3;
                $lz_types[$displayorder][4] = $this->page->get->t4;
                $lz_types[$displayorder][5] = $this->page->get->t5;
                $lz_types[$displayorder][6] = $this->page->get->t6;
                $lz_types[$displayorder][7] = $this->page->get->t7;
                $lz_types[$displayorder][8] = $this->page->get->t8;
                $lz_types[$displayorder][9] = $this->page->get->t9;
            }else if($diy['module'] == 'gg'){
                $lz_types[$displayorder][0] = $this->page->get->title;
                $lz_types[$displayorder][1] = $this->page->get->url;
            }else if($diy['module'] == 'aljtc_hot'){
                $lz_types[$displayorder][0] = $this->page->get->title;
                $lz_types[$displayorder][1] = $this->page->get->url;
            }else if($diy['module'] == 'thread'){
                $lz_types[$displayorder][0] = $this->page->get->t0;
                $lz_types[$displayorder][1] = $this->page->get->t1;
                $lz_types[$displayorder][2] = $this->page->get->t2;
            }else if($diy['module'] == 'article'){
                $lz_types[$displayorder][0] = $this->page->get->t0;
                $lz_types[$displayorder][1] = $this->page->get->t1;
                $lz_types[$displayorder][2] = $this->page->get->t2;
            }else if($diy['module'] == 'banner'){
                $lz_types[$displayorder][1] = $this->page->get->url;
                $lz_types[$displayorder][2] = $this->page->get->t2;
                $lz_types[$displayorder][3] = $this->page->get->t3;
                $lz_types[$displayorder][4] = $this->page->get->t4;
            }else if($diy['module'] == 'brand_info'){
                if(empty($lz_types[$displayorder][0])){
                    $lz_types[$displayorder][0] = '';
                }
                $lz_types[$displayorder][1] = $this->page->get->t1;
                $lz_types[$displayorder][2] = $this->page->get->t2;
                $lz_types[$displayorder][3] = $this->page->get->t3;
            }else if($diy['module'] == 'brand_goods'){
                $lz_types[$displayorder][0] = $this->page->get->t0;
                $lz_types[$displayorder][1] = $this->page->get->t1;
            }else if($diy['module'] == 'swiper_container'){
                if($this->page->get->is_on){
                    $lz_types[$displayorder][0] = $this->page->get->is_on;
                    $lz_types[$displayorder][1] = $this->page->get->is_on_page;
                    $lz_types[$displayorder][2] = $this->page->get->is_on_color;
                }else{
                    $lz_types[$displayorder][1] = $this->page->get->url;
                    $lz_types[$displayorder][2] = $this->page->get->title;
                }
            }else if($diy['module'] == 'aljshd_toutiao'){
                $lz_types[$displayorder][0] = $this->page->get->t1;
                $lz_types[$displayorder][1] = $this->page->get->t2;
            }else{
                $lz_types[$displayorder][1] = $this->page->get->url;
                if($this->page->get->title){
                    $lz_types[$displayorder][2] = $this->page->get->title;
                }
            }
            
            ksort($lz_types[$displayorder]);
            $lz_types = T::arrayToStringSetting($lz_types);
            
            DB::update('aljdiy_diy', array('data' => $lz_types), array(
                'auto_module' => $skey,
                'page_id' => $page_id,
            ));
            
            $this->page->tips();
        } else {
            $diyListData = DB::fetch_all('select * from %t where page_id=%d and module!=%s order by displayorder asc', array('aljdiy_diy', $page_id, 'gg_icon'));
            if($diyListData){
                $diyAutoList = array();
                foreach ($diyListData as $k => $diy) {
                    DB::query('update %t set displayorder = %d where id=%d', array('aljdiy_diy',$k+1, $diy['id']));
                    if($diy['module'] == 'activity_recommend_goods'){
                        if($diy['data']){
                            $diy['data'] = DB::fetch_all('select * from %t where id in (%i)', array('aljbd_goods', $diy['data']));
                        }
                    }else if($diy['module'] == 'activity_recommend_brand'){
                        if($diy['data']){
                            $diy['data'] = DB::fetch_all('select * from %t where id in (%i)', array('aljbd', $diy['data']));
                        }
                    }else if($diy['module'] == 'activity_recommend_store'){
                        if($diy['data']){
                            $diy['data'] = DB::fetch_all('select * from %t where tc_id in (%i)', array('aljtsq_store', $diy['data']));
                        }
                    }else if($diy['module'] == 'global_bottom'){
                        $settings=C::t('#aljbd#aljbd_setting')->range();
                        $mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_common_footernav']['value']));
                        foreach($mobile_common_footernav as $key=>$value){
                            $arr=explode('|',$value);
                            $mobile_common_footernav_arr[]=$arr;
                        }
                        $diy['data'] = $mobile_common_footernav_arr;
                    }else if($diy['module'] == 'aljtc_global_bottom'){
                        $settings=C::t('#aljtc#aljtc_setting')->range();
                        if($settings['mobile_footer_nav']['value']){
                            $mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_footer_nav']['value']));
                        
                            foreach($mobile_common_footernav as $key=>$value){
                                $arr=explode('|',$value);
                                $mobile_common_footernav_arr[]=$arr;
                            }
                            $diy['data'] = $mobile_common_footernav_arr;
                        }
                        
                    }else{
                        if($diy['module'] != 'custom'){
                            $diy['data'] = T::stringSettingToArray($diy['data']);
                        }
                    }
                    
                    if($diy['module'] == 'gg'){
                        $diy['data']['gg_icon'] = DB::result_first('select data from %t where module=%s and page_id=%d', array('aljdiy_diy', 'gg_icon', $page_id));
                        $diy['data']['gg_icon'] = str_replace('|', '', $diy['data']['gg_icon']);
                    }
                    $diyAutoList[] = $diy;
                }
            }
            $page = DB::fetch_first('select * from %t where id=%d', array('aljdiy_page', $page_id));
            
            
            if($_GET['diyajax'] == 'yes'){
                
                foreach ($diyAutoList as $kk => $diy) {
                    if($diy['template']){
                        include template(APP_ID.':aljdiy/diy/index/'.$diy['template']);
                    }
                }
                
                exit;
            }
            
            $mod_list = array(
                'swiper_container' => lang("plugin/aljdiy","diy_php_39"),
                'gg' => lang("plugin/aljdiy","diy_php_40"),
                'mobile_index_tad' => lang("plugin/aljdiy","diy_php_41"),
                'mobile_index_fad' => lang("plugin/aljdiy","diy_php_42"),
                'adv' => lang("plugin/aljdiy","diy_php_43"),
                'banner' => lang("plugin/aljdiy","diy_php_44"),
                'swiper_container_horizontal' => lang("plugin/aljdiy","diy_php_45"),
                'mobile_index_Photo_Ads' => lang("plugin/aljdiy","diy_php_46"),
                'mobile_common_footernav' => lang("plugin/aljdiy","diy_php_47"),
                'common_follow' => lang("plugin/aljdiy","diy_php_48"),
                'pop' => lang("plugin/aljdiy","diy_php_49"),
                'sep' => lang("plugin/aljdiy","diy_php_50"),
                'custom' => lang("plugin/aljdiy","diy_php_51")
            );
            
            $mod_list_2 = array(
                'poster' => lang("plugin/aljdiy","diy_php_52"),
                'video' => lang("plugin/aljdiy","diy_php_53"),
            );
            if($page['type'] == 0){
                $mod_list_2['so'] = lang("plugin/aljdiy","diy_php_54");
                $mod_list_2['activity_recommend_brand'] = lang("plugin/aljdiy","diy_php_55");
                $mod_list_2['ms'] = lang("plugin/aljdiy","diy_php_56");
                $mod_list_2['global_bottom'] = lang("plugin/aljdiy","diy_php_57");
                $mod_list_2['guess_goods'] = lang("plugin/aljdiy","diy_php_58");
                $mod_list_2['goods_type'] = lang("plugin/aljdiy","diy_php_59");
                $mod_list_2['activity_type'] = lang("plugin/aljdiy","diy_php_60");
                $mod_list_2['activity_recommend_goods'] = lang("plugin/aljdiy","diy_php_61");
                $mod_list_2['thread'] = lang("plugin/aljdiy","diy_php_62");
                $mod_list_2['article'] = lang("plugin/aljdiy","diy_php_63");
                if($_G['cache']['plugin']['aljshd']){
                    $mod_list_2['aljshd_toutiao'] = lang("plugin/aljdiy","diy_php_64");
                }
                $mod_list_3 = array(
                    'aljtc_hot' => lang("plugin/aljdiy","diy_php_65"),
                    'aljtc_left_bottom' => lang("plugin/aljdiy","diy_php_66"),
                    'row_four_grids' => lang("plugin/aljdiy","diy_php_67"),
                    'aljtc_ckad' => lang("plugin/aljdiy","diy_php_68"),
                );
                if($_G['cache']['plugin']['aljtc']){
                    $mod_list_3['aljtc_statistics'] = lang("plugin/aljdiy","diy_php_69");
                    $mod_list_3['aljtc_so'] = lang("plugin/aljdiy","diy_php_70");
                    $mod_list_3['aljtc_list'] = lang("plugin/aljdiy","diy_php_71");
                    $mod_list_3['aljtc_global_bottom'] = lang("plugin/aljdiy","diy_php_72");
                }
                if($_G['cache']['plugin']['aljtsq']){
                    $mod_list_3['activity_recommend_store'] = lang("plugin/aljdiy","diy_php_73");
                    $mod_list_3['aljtsq_store_add'] = lang("plugin/aljdiy","diy_php_74");
                    $mod_list_3['aljtsq_store_list'] = lang("plugin/aljdiy","diy_php_75");
                    $mod_list_3['aljtsq_global_bottom'] = lang("plugin/aljdiy","diy_php_76");
                    $mod_list_3['sky_mod'] = lang("plugin/aljdiy","diy_php_77");
                    $mod_list_3['wechat_group'] = lang("plugin/aljdiy","diy_php_78");
                }
                if($_G['cache']['plugin']['aljtsc']){
                    $mod_list_3['aljtsc_goods'] = lang("plugin/aljdiy","diy_php_79");
                    $mod_list_3['aljtsc_global_bottom'] = lang("plugin/aljdiy","diy_php_80");
                }
                $mod_list_3_title = lang("plugin/aljdiy","diy_php_81");
            }else if($_G['cache']['plugin']['aljdd']['is_aljdd']){
                $mod_list_3 = array(
                    'brand_so' => lang("plugin/aljdiy","diy_php_82"),
                    'brand_info' => lang("plugin/aljdiy","diy_php_83"),
                    'brand_nav' => lang("plugin/aljdiy","diy_php_84"),
                    'brand_gg' => lang("plugin/aljdiy","diy_php_85"),
                    'brand_swiper' => lang("plugin/aljdiy","diy_php_86"),
                    'brand_goods' => lang("plugin/aljdiy","diy_php_87"),
                    'brand_footer' => lang("plugin/aljdiy","diy_php_88"),
                );
                $mod_list_3_title = lang("plugin/aljdiy","diy_php_89");
            }
            $type = $page['type'];
            $this->page->assign('type', $type);
            $this->page->assign('com_url', '&type='.$type.'&brand_id='.$this->brand_id,true);
            //debug(DB::fetch_all('select * from %t', array('aljdiy_diy_bak')));
            $this->page->assign('mod_list', $mod_list);
            $this->page->assign('mod_list_2', $mod_list_2);
            $this->page->assign('mod_list_3', $mod_list_3);
            $this->page->assign('mod_list_3_title', $mod_list_3_title);
            $this->page->assign('page_id', $page_id);
            $this->page->assign('page', $page);
            
            $this->page->assign('diyAutoList', $diyAutoList, true); //ͼ�Ĺ�渴�ƹ���
            
            $this->page->display();
        }
    }

    public function msectime() {
        list($msec, $sec) = explode(' ', microtime());
        $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
        return $msectime;
    }
}

