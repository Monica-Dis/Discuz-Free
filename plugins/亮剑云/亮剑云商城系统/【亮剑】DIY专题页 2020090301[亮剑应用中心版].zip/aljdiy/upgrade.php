<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljdiy_diy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `module` varchar(255) NOT NULL,
  `auto_module` varchar(255) NOT NULL,
  `displayorder` bigint(20) NOT NULL,
  `template` varchar(255) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljdiy_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `page_num` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `open` char(50) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljdiy_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `mod_num` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `groupid` int(11) NOT NULL,
  `intro` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `push_to_page` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
);
EOF;
runquery($sql);
$sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `group_bg_color` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `scroll_group_bg_color` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `scroll_text_color` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `scroll_sel_text_color` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `group_title` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `displayorder` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `page_bg_img` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `page_bg_color` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `text_color` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `sel_text_color` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `push_to_page` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `page_url` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `intro` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `logo` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');


$sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `groupid` int(11) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `admin_id` int(11) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `station_id` int(11) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE  ".DB::table('aljdiy_group')." ADD `admin_id` int(11) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljdiy_page')." ADD `type` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljdiy_page')." ADD `bid` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljdiy_diy')." ADD `set_up` text NOT NULL" ;
DB::query($sql,'SILENT');
//finish to put your own code
$finish = TRUE;
?>
