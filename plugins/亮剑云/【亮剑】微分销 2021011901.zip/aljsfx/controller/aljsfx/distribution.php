<?php

/**
 *
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * @version 1.0
 * @link http://docs.liangjianyun.com/
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class distributionAction{
    public $page;

    public function __construct($page) {
        global $_G;
        $this->page = $page;
        $this->aljbdParameter();
        if(strtolower(CHARSET) == 'gbk' && !$this->page->global->mobile && $this->page->get->message){
            $this->page->get->message = diconv($this->page->get->message,'utf-8','gbk');
        }

        //DB::query('update %t set third_leader_uid=0 where first_leader_uid=third_leader_uid',array('aljsfx_user'));
        if(!$this->page->global->cache->plugin->aljsfx->is_aljsfx){
            $desc = lang("plugin/aljsfx","distribution_php_1");
            $write_off_url = array('value' => lang("plugin/aljsfx","distribution_php_2"), 'url' => 'plugin.php?id=aljsfx&a=add&c=distribution');
            $orderurl = array('value' => lang("plugin/aljsfx","distribution_php_3"), 'url' => 'plugin.php?id=aljbd&act=user');
            $result_info = array(
                'icon' => 'weui-icon-warn',
                'title' => lang("plugin/aljsfx","distribution_php_4"),
                'desc' => $desc,
                'btn_primary' => $write_off_url,
                'btn_default' => $orderurl,
            );
            $this->weuiResult($result_info);
        }
        $status_arr = array('cashstatus','shopstatus','add');
        if(!$this->page->global->mobile && !in_array($this->page->get->a,$status_arr)){
            if($this->page->get->a == 'team'){
                $navtitle = lang("plugin/aljsfx","distribution_php_5");
                $title = lang("plugin/aljsfx","distribution_php_6");
                $url = $this->page->global->siteurl.'plugin.php?id=aljsfx&a=team&c=distribution';
            }else if($this->page->get->a == 'order'){
                $navtitle = lang("plugin/aljsfx","distribution_php_7");
                $title = lang("plugin/aljsfx","distribution_php_8");
                $url = $this->page->global->siteurl.'plugin.php?id=aljsfx&a=order&c=distribution';
            }else if($this->page->get->a == 'cashlog'){
                $navtitle = lang("plugin/aljsfx","distribution_php_9");
                $title = lang("plugin/aljsfx","distribution_php_10");
                $url = $this->page->global->siteurl.'plugin.php?id=aljsfx&a=cashlog&c=distribution';
            }else{
                $navtitle = lang("plugin/aljsfx","distribution_php_11");
                $title = lang("plugin/aljsfx","distribution_php_12");
                $url = $this->page->global->siteurl.'plugin.php?id=aljsfx&a=user&c=distribution';
            }
            $this -> pcQrcode($navtitle,$title,$url);
        }
        if($_G['cache']['plugin']['aljsfx']['is_aljsfx'] && !discuz_process::islocked('autoFxOrderStatus','30')){
            
            self::order_auto();
        }
    }
    public function order_auto () {
        global $_G;
        //�޸Ĺ��ڷ����̵���״̬Ϊδ֧��
        DB::query('update %t set status=2 where rankendtime>0 and rankendtime<%d and status=1',array('aljsfx_shop',TIMESTAMP));
        $fx_orderlist = DB::fetch_all('select * from %t where status = 1 and (timestamp+payment_days*86400) < %d limit 0,20',array('aljsfx_order',TIMESTAMP));
        if($fx_orderlist){
            foreach($fx_orderlist as $fx_kev => $fx_val){
                if(DB::update('aljsfx_order',array('status'=>2),array('status'=>1,'id'=>$fx_val['id']))){
                    //DB::update('aljsfx_shop',array('account_commissions'=>),array());
                    //DB::query('update %t set account_commissions=account_commissions+%i where uid=%d',array('aljsfx_shop',$fx_val['money'],$fx_val['beneficiary_uid']));
                    if($_G['cache']['plugin']['aljsfx']['auto_aljqb'] && $fx_val['type'] !=4){//�Զ�����Ǯ��
                        if(DB::query('update %t set account_commissions=account_commissions+%i,extraction_commission=extraction_commission+%i where uid=%d',array('aljsfx_shop',$fx_val['money'],$fx_val['money'],$fx_val['beneficiary_uid']))){
                            $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
                            $cashinsert = array(
                                'orderid' => $orderid,
                                'uid' => $fx_val['beneficiary_uid'],
                                'username' => $fx_val['beneficiary_username'],
                                'time' => TIMESTAMP,
                                'rmb' => $fx_val['money'],
                                'status' => 1,
                                'admindesc' => lang("plugin/aljsfx","distribution_php_137")
                            );
                            $inserid = DB::insert('aljsfx_cashorder',$cashinsert,true);
                            
                            $n_text = lang("plugin/aljsfx","distribution_php_138");
                            $desc = lang("plugin/aljsfx","distribution_php_139").$fx_val['money'].lang("plugin/aljsfx","distribution_php_108");
                            $this->aljqbChargeMoney ($fx_val['beneficiary_uid'],$fx_val['money'],$orderid,$desc);
                            notification_add($fx_val['beneficiary_uid'], 'system',$n_text.'<a href="plugin.php?id=aljsfx&a=cashlog&c=distribution">'.lang("plugin/aljsfx","distribution_php_36").'</a>',array('from_idtype'  => 'aljsfx','from_id' => $inserid));
                        
                        }else{
                            DB::update('aljsfx_order',array('status'=>1),array('status'=>2,'id'=>$fx_val['id']));
                        }
                    }else{
                        if(DB::query('update %t set account_commissions=account_commissions+%i where uid=%d',array('aljsfx_shop',$fx_val['money'],$fx_val['beneficiary_uid']))){
                            
                            $n_text = lang("plugin/aljsfx","distribution_php_140");
                            notification_add($fx_val['beneficiary_uid'], 'system',$n_text.'<a href="plugin.php?id=aljsfx&c=distribution&a=user">'.lang("plugin/aljsfx","distribution_php_141").'</a>',array('from_idtype'  => 'aljsfx','from_id' => $inserid));
                        }else{
                            DB::update('aljsfx_order',array('status'=>1),array('status'=>2,'id'=>$fx_val['id']));
                        }
                    }
                    
                }
            }
        }
    }
    /**
     * PC��ά����ʾҳ
     *
     * @param string $navtitle SEO����
     * @param string $title ����
     * @param string $url ���ɶ�ά������
     *
     * @return void
     */
    public function pcQrcode ($navtitle,$title='',$url=''){
        $this->page->assign('navtitle', $navtitle);
        $this->page->assign('title', $title);
        $this->page->assign('url', $url,true);
        $this->page->display('aljhtx:qrcode');
    }
    /**
     * ��ʾ
     *
     * @param string $text ��ʾ��
     * @param string $url ��ת����
     *
     * @return void
     */
    public function tips ($text,$url=''){
        if($url){
            echo "<script>parent.tips('".$text."',function(){parent.location.href='".$url."';});</script>";
        }else{
            echo "<script>parent.tips('".$text."','');</script>";
        }
        exit;
    }
    /**
     * weui�����ʾҳ
     * @param array $info ��ʾ�������
     *
     * @return void
     */
    public function weuiResult ($info=array()){

        $this->page->assign('result_info', $info);
        $this->page->assign('navtitle', lang("plugin/aljsfx","distribution_php_13"));
        $this->page->display($this->page->templatePluginID . ':' . ROOT .'/' . $this ->page->controller. '/result');
    }
    /**
     * ��֤������
     *
     * @return void
     */
    public function inviteCode () {
        global $bindtime,$_G;
        if($this->page->get->formhash == FORMHASH){
            $duid = $this->page->get->duid;
            if($this->page->global->uid && $duid>0){
                //��¼����Ϣ
                $benuser = DB::fetch_first('select * from %t where uid=%d',array('common_member',$this->page->global->uid));
                //ע��ʱ��С��60��û���ϼ���ϵ��
                if($benuser['regdate']+$bindtime > TIMESTAMP ){
                    $fromuid = $duid;
                    //�ж����û��󶨱��Ƿ�������
                    if($fromuid && !DB::fetch_first('select * from %t where uid=%d ', array('aljsfx_user', $this->page->global->uid))){
                        $fromdata = DB::fetch_first('select * from %t where uid=%d ', array('aljsfx_user', $fromuid));
                        if($fx_shop=DB::fetch_first('select * from %t where uid=%d and status=1',array('aljsfx_shop',$fromuid))){
                            $fx_user_insertarray = array(
                                'first_leader_uid' => $fromuid,
                                'uid' => $this->page->global->uid,
                                'username' => $this->page->global->username,
                                'timestamp' => TIMESTAMP,
                                'second_leader_uid' => $fromdata['first_leader_uid']!=$fromuid ? $fromdata['first_leader_uid'] : '',
                                'third_leader_uid' => $fromdata['second_leader_uid']!=$fromuid ? $fromdata['second_leader_uid'] : '',
                            );
                            if($_G['cache']['plugin']['aljsfx_rt']['is_new_reward']){
                                $fx_rankdata = DB::fetch_first('select * from %t where id=%d', array('aljsfx_rank', $fx_shop['rankid']));
                                if($fx_rankdata['new_reward']>0){
                                    $fx_user_insertarray['is_reward'] = 1;
                                    $fx_user_insertarray['new_reward'] = $fx_rankdata['new_reward'];
                                }
                            }
                            if(DB::fetch_first('select * from %t where uid=%d ',array('aljsfx_shop',$this->page->global->uid))){
                                $fx_user_insertarray['is_distribution'] = 1;
                            }
                            DB::insert('aljsfx_user', $fx_user_insertarray);
                           

                            
                            notification_add($fromuid, 'system',lang("plugin/aljsfx","distribution_php_14").$this->page->global->username.lang("plugin/aljsfx","distribution_php_15").'<a href="plugin.php?id=aljsfx&a=team&c=distribution">'.lang("plugin/aljsfx","distribution_php_16").'</a>',array('from_idtype'  => 'aljsfx','from_id' => $this->page->global->uid));
                            $tipstext = lang("plugin/aljsfx","distribution_php_17");
                            $this->page->tips($tipstext,'plugin.php?id=aljbd&act=user');
                        }else{
                            $tipstext = lang("plugin/aljsfx","distribution_php_18");
                            $this->page->tips($tipstext);
                        }
                    }else{
                        $tipstext = lang("plugin/aljsfx","distribution_php_19");
                        $this->page->tips($tipstext);
                    }
                }else{
                    $tipstext = lang("plugin/aljsfx","distribution_php_20");
                    $this->page->tips($tipstext);
                }
            }else{
                $tipstext = lang("plugin/aljsfx","distribution_php_21");
                $this->page->tips($tipstext);
            }

        }else{

            $fx_user_count = DB::fetch_first('select * from %t where uid=%d',array('aljsfx_user',$this->page->global->uid));
            if($fx_user_count){
                $fx_userinfo = getuserbyuid($fx_user_count['first_leader_uid']);
                $desc = lang("plugin/aljsfx","distribution_php_22").$fx_userinfo['username'];
                $write_off_url = array('value' => lang("plugin/aljsfx","distribution_php_23"), 'url' => 'plugin.php?id=aljsfx&a=add&c=distribution');
                $orderurl = array('value' => lang("plugin/aljsfx","distribution_php_24"), 'url' => 'plugin.php?id=aljbd&act=user');
                $result_info = array(
                    'icon' => 'weui-icon-warn',
                    'title' => lang("plugin/aljsfx","distribution_php_25"),
                    'desc' => $desc,
                    'btn_primary' => $write_off_url,
                    'btn_default' => $orderurl,
                );
                $this->weuiResult($result_info);
            }
            $this->page->assign('navtitle', lang("plugin/aljsfx","distribution_php_26"));
            $this->page->display();
        }
    }
    /**
     * �������
     * status =1 ���ͨ�� status=2��˲�ͨ��
     * @return void
     */
    public function cashstatus (){
        if($this->page->get->formhash == FORMHASH) {
            if($this->page->global->groupid !=1 && $this->page->get->i != 1){
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_27"))));
                exit;
            }
            if(!$this->page->get->cashid){
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_28"))));
                exit;
            }
            if(!$this->page->get->status){
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_29"))));
                exit;
            }
            $cashorder = DB::fetch_first('select * from %t where id=%d',array('aljsfx_cashorder',$this->page->get->cashid));
            if(!$cashorder){
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_30"))));
                exit;
            }

            if(DB::query('update %t set status=%d,trans_uid=%d,trans_time=%d,admindesc=%s where id=%d and status=0',array('aljsfx_cashorder',$this->page->get->status,$this->page->global->uid,TIMESTAMP,$this->page->get->message,$this->page->get->cashid))){
                if($this->page->get->status == 1){
                    $n_text = lang("plugin/aljsfx","distribution_php_31");
                    $desc = lang("plugin/aljsfx","distribution_php_32").$cashorder['rmb'].lang("plugin/aljsfx","distribution_php_33");
                    $this->aljqbChargeMoney ($cashorder['uid'],$cashorder['rmb'],$cashorder['orderid'],$desc);
                }else{
                    $n_text = lang("plugin/aljsfx","distribution_php_34");
                    if($this->page->get->message){
                        $n_text .= lang("plugin/aljsfx","distribution_php_35").$this->page->get->message;
                    }
                    DB::query('update %t set extraction_commission=extraction_commission-%i where uid=%d',array('aljsfx_shop',$cashorder['rmb'],$cashorder['uid']));
                }
                notification_add($cashorder['uid'], 'system',$n_text.'<a href="plugin.php?id=aljsfx&a=cashlog&c=distribution">'.lang("plugin/aljsfx","distribution_php_36").'</a>',array('from_idtype'  => 'aljsfx','from_id' => $this->page->get->cashid));
                echo json_encode(T::ajaxPostCharSet(array('code'=>1,'text'=>lang("plugin/aljsfx","distribution_php_37"))));
                exit;
            }else{
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_38"))));
                exit;
            }
        }else{
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_39"))));
            exit;
        }
    }
    /**
     * �����б�
     *
     * @return void
     */
    public function cashlog (){
        $do = $this->page->get->do;
        if($do == 'ajax'){
            $currpage = $this->page->get->page ? $this->page->get->page : 1;
            $perpage = 20;
            $start = ($currpage - 1) * $perpage;

            $where = 'where status=%d';
            if($this->page->global->groupid ==1 && $this->page->get->i == 1){
            }else{
                $where .= ' and uid='.$this->page->global->uid;
            }
            $teamList = DB::fetch_all('select * from %t '.$where.' order by id desc limit %d,%d',array('aljsfx_cashorder',$this->page->get->status,$start,$perpage));
            foreach ($teamList as $teamk => $teamv) {
                $teamList[$teamk]['userpic'] = avatar($teamv['uid'],'middle','true');
                $teamList[$teamk]['time'] = dgmdate($teamv['time'],'u');
                if($teamv['status'] == 1){
                    $teamList[$teamk]['statustext'] = lang("plugin/aljsfx","distribution_php_40");
                }else if($teamv['status'] == 2){
                    $teamList[$teamk]['statustext'] = lang("plugin/aljsfx","distribution_php_41");
                }else{
                    $teamList[$teamk]['statustext'] = lang("plugin/aljsfx","distribution_php_42");
                }
            }
            if($teamList){
                echo json_encode(T::ajaxPostCharSet($teamList));
            }else{
                echo '1';
            }
            exit;
        }else {

            if($this->page->global->groupid == 1 && $this->page->get->i == 1){
                $navtitle = lang("plugin/aljsfx","distribution_php_43");
                if(!$this->page->global->mobile){
                    $headerurl = 'plugin.php?id=aljht&act=admin&op=distribution&do=cashlog';
                    dheader("location:".$headerurl);
                    exit;
                }
            }else{
                $navtitle = lang("plugin/aljsfx","distribution_php_44");
            }
            $this->page->assign('navtitle', $navtitle);
            $this->page->display();
        }
    }
    /**
     * �������
     * status =1 ���ͨ�� status=3��˲�ͨ��
     * @return void
     */
    public function shopstatus (){
        if($this->page->get->formhash == FORMHASH) {
            if($this->page->global->groupid !=1){
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_45"))));
                exit;
            }
            if(!$this->page->get->cashid){
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_46"))));
                exit;
            }
            if(!$this->page->get->status){
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_47"))));
                exit;
            }
            $shop = DB::fetch_first('select * from %t where id=%d',array('aljsfx_shop',$this->page->get->cashid));
            if(!$shop){
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_48"))));
                exit;
            }
            if($this->page->get->status == 1 && $shop['status'] == 3){
                $status = 3;//����
            }else{
                $status = 0;
            }
            if(DB::query('update %t set status=%d,admindesc=%s where id=%d and status=%d',array('aljsfx_shop',$this->page->get->status,$this->page->get->message,$this->page->get->cashid,$status))){
                if($this->page->get->status == 1){
                    $n_text = lang("plugin/aljsfx","distribution_php_49");
                }else{
                    $n_text = lang("plugin/aljsfx","distribution_php_50");
                    if($this->page->get->message){
                        $n_text .= lang("plugin/aljsfx","distribution_php_51").$this->page->get->message;
                    }
                }
                notification_add($shop['uid'], 'system',$n_text.'<a href="plugin.php?id=aljsfx&a=user&c=distribution">'.lang("plugin/aljsfx","distribution_php_52").'</a>',array('from_idtype'  => 'aljsfx','from_id' => $this->page->get->cashid));
                echo json_encode(T::ajaxPostCharSet(array('code'=>1,'text'=>lang("plugin/aljsfx","distribution_php_53"))));
                exit;
            }else{
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_54"))));
                exit;
            }
        }else{
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_55"))));
            exit;
        }
    }
    /**
     * ��˵����б�
     *
     * @return void
     */
    public function shoplist (){
        $do = $this->page->get->do;
        if($this->page->global->groupid !=1){
            $desc = lang("plugin/aljsfx","distribution_php_56");
            $write_off_url = array('value' => lang("plugin/aljsfx","distribution_php_57"), 'url' => 'plugin.php?id=aljsfx&a=add&c=distribution');
            $orderurl = array('value' => lang("plugin/aljsfx","distribution_php_58"), 'url' => 'plugin.php?id=aljbd&act=user');
            $result_info = array(
                'icon' => 'weui-icon-warn',
                'title' => lang("plugin/aljsfx","distribution_php_59"),
                'desc' => $desc,
                'btn_primary' => $write_off_url,
                'btn_default' => $orderurl,
            );
            $this->weuiResult($result_info);
        }
        if($do == 'ajax'){
            $currpage = $this->page->get->page ? $this->page->get->page : 1;
            $perpage = 20;
            $start = ($currpage - 1) * $perpage;

            $where = 'where a.status=%d';
            //$teamList = DB::fetch_all('select a.*,b.name,b.price,b.num,b.goods_id,b.dis_commission from %t a left join %t b on a.orderid=b.orderid '.$where.' order by a.timestamp desc limit %d,%d',array('aljsfx_order','aljbd_goods_order_list',$this->page->global->uid,$start,$perpage));
            $teamList = DB::fetch_all('select a.*,b.title from %t a left join %t b on a.rankid=b.id '.$where.' order by a.id desc limit %d,%d',array('aljsfx_shop','aljsfx_rank',$this->page->get->status,$start,$perpage));
            foreach ($teamList as $teamk => $teamv) {
                if($teamv['shop_img']){
                    $teamList[$teamk]['userpic'] = $teamv['shop_img'];
                }else{
                    $teamList[$teamk]['userpic'] = avatar($teamv['uid'],'middle','true');
                }

                $teamList[$teamk]['timestamp'] = dgmdate($teamv['timestamp'],'u');
                if($teamv['rankendtime']){
                    if($teamv['rankendtime'] > TIMESTAMP){
                        $teamList[$teamk]['rankendtimes'] = dgmdate($teamv['rankendtime'],'Y-m-d H:i:s').lang('plugin/aljbd','member_php_1');
                    }else{
                        $teamList[$teamk]['rankendtimes'] = lang('plugin/aljbd','member_php_2');
                    }

                }else if($teamv['rankid'] && $teamv['rankendtime']==0){
                    $teamList[$teamk]['rankendtimes'] = lang('plugin/aljbd','member_php_3');
                }
                if($teamv['status'] == 1){
                    $teamList[$teamk]['statustext'] = lang("plugin/aljsfx","distribution_php_60");
                }else if($teamv['status'] == 2){
                    $teamList[$teamk]['statustext'] = lang("plugin/aljsfx","distribution_php_61");
                }else if($teamv['status'] == 3){
                    $teamList[$teamk]['statustext'] = lang("plugin/aljsfx","distribution_php_62");
                }else{
                    $teamList[$teamk]['statustext'] = lang("plugin/aljsfx","distribution_php_63");
                }
            }
            if($teamList){
                echo json_encode(T::ajaxPostCharSet($teamList));
            }else{
                echo '1';
            }
            exit;
        }else {
            if(!$this->page->global->mobile){
                $headerurl = 'plugin.php?id=aljht&act=admin&op=distribution&do=shoplist';
                dheader("location:".$headerurl);
                exit;
            }
            $this->page->assign('navtitle', lang("plugin/aljsfx","distribution_php_64"));
            $this->page->display();
        }
    }
    /**
     * ��������
     *
     * @return void
     */
    public function cash () {
        if($this->page->get->formhash == FORMHASH) {
            $shopdata = DB::fetch_first('select * from %t where uid=%d', array('aljsfx_shop', $this->page->global->uid));
            if (!$shopdata) {
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_65"))));
                exit;
            }
            if ($shopdata['status'] < 1) {
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_66"))));
                exit;
            }
            if ($shopdata['status'] >= 2) {
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_67"))));
                exit;
            }
            $rmb = $this->page->get->price + 0;
            $rmb = substr(sprintf("%.3f",$rmb),0,-1);
            if ($rmb <= 0) {
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_68").'0')));
                exit;
            }
            $rankdata = DB::fetch_first('select * from %t where id=%d', array('aljsfx_rank', $shopdata['rankid']));
            $commission = ($shopdata['account_commissions']*100 - $shopdata['extraction_commission']*100)/100;

            //��С���ֽ����ڿ����ֽ��
            if ($rankdata['mincashmoney'] > 0 && ($rankdata['mincashmoney'] > $commission || $rankdata['mincashmoney'] > $rmb)) {
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_69") . $rankdata[mincashmoney] . lang("plugin/aljsfx","distribution_php_70"))));
                exit;
            }

            if($commission < $rmb){
                echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_71"))));
                exit;
            }
            $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
            $cashinsert = array(
                'orderid' => $orderid,
                'uid' => $this->page->global->uid,
                'username' => $this->page->global->username,
                'time' => TIMESTAMP,
                'rmb' => $rmb,
            );
            $inserid = DB::insert('aljsfx_cashorder',$cashinsert,true);
            if($inserid){
                DB::query('update %t set extraction_commission=extraction_commission+%i where uid=%d',array('aljsfx_shop',$rmb,$this->page->global->uid));
                $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
                foreach($groupids as $g_uid){
                    notification_add($g_uid['uid'], 'system',lang("plugin/aljsfx","distribution_php_72").lang("plugin/aljsfx","distribution_php_73").'</a>',array('from_idtype'  => 'aljsfx','from_id' => $inserid));
                }
            }
            echo json_encode(T::ajaxPostCharSet(array('code'=>1,'text'=>lang("plugin/aljsfx","distribution_php_74"))));
            exit;
        }else{
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljsfx","distribution_php_75"))));
            exit;
        }
    }
    /**
     * ��Ʒ������ʾԤ��Ӷ��
     *
     * @return void
     */
    public function commission () {
        global $_G;
        $gid = intval($_GET['gid']);
        $g=C::t('#aljbd#aljbd_goods')->fetch($gid);
        if($g['is_distribution']>0 && $g['dis_commission']>0){
            $sku_price = T::skuminprice($g['attr_sku'],$g['commodity_type'],1);
            
            if($sku_price['max_price'] > 0){
                $g['price1'] = $sku_price['max_price'];
            }
            $shopdata = DB::fetch_first('select a.*,b.price,b.first_scale from %t a left join %t b on a.rankid = b.id where a.uid=%d',array('aljsfx_shop','aljsfx_rank',$this->page->global->uid));
            if($shopdata){
                $fx_fee = substr(sprintf("%.3f",$g['price1']*$g['dis_commission']*$shopdata['first_scale']/10000),0,-1);
            }else{
                $fx_fee = substr(sprintf("%.3f",$g['price1']*$g['dis_commission']/100),0,-1);
            }
        }
        if($fx_fee > 0){
            echo $fx_fee;
        }else{
            echo 0;
        }
        exit;
    }
    /**
     * ��������/����
     *
     * @return void
     */
    public function pay (){
        $shopdata = DB::fetch_first('select a.*,b.price from %t a left join %t b on a.rankid = b.id where a.uid=%d',array('aljsfx_shop','aljsfx_rank',$this->page->global->uid));
        $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
        $orderarray=array(
            'orderid' => $orderid,
            'status' => 1,
            'shop_id' => $shopdata['id'],
            'uid' => $this->page->global->uid,
            'username' => $this->page->global->username,
            'submitdate' => TIMESTAMP,
            'stitle' => lang("plugin/aljsfx","distribution_php_76").$shopdata['name'],
            'payment' => 7,
            'pid'  => 4,
            'browser'  => $_SERVER['HTTP_USER_AGENT'],
        );

        $orderarray['mobile'] = 1;

        $rankdata = DB::fetch_first('select * from %t where id=%d',array('aljsfx_rank',$this->page->get->rankid));
        if($shopdata['rankid'] == $this->page->get->rankid && $rankdata['day'] == 0){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>'&#27704;&#20037;&#31561;&#32423;&#26080;&#38656;&#21319;&#32423;')));
            exit;
        }
        if($rankdata['price'] < $shopdata['price'] && $shopdata['rankid'] != $this->page->get->rankid){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>'&#39640;&#20215;&#26684;&#19981;&#33021;&#36716;&#20026;&#20302;&#20215;&#26684;&#21734;')));
            exit;
        }
        //�����ȼ�
        if($rankdata) {
            $orderarray['remarks'] = $rankdata['day'] . '/' . $rankdata['price'];
            $orderarray['fare_desc'] = $this->page->get->rankid;
            $orderarray['price'] = $rankdata['price'];

            $vipendtime = ($shopdata['rankid'] == $this->page->get->rankid) ? max($shopdata['rankendtime'], TIMESTAMP) : TIMESTAMP;
            if ($rankdata['price'] > 0) {
                $orderarray['opentime'] = $vipendtime;//���ѿ�ʼʱ��
                C::t('#aljbdx#aljbd_goods_order')->insert($orderarray);
                require_once 'source/plugin/aljqb/class/Qbapi.class.php';
                $qbapi = new Qbapi();
                $keyurlarray = array(
                    'orderid' => $orderid,
                    'time' => TIMESTAMP,
                    'price' => $rankdata['price'],
                    'keyname' => 'aljsfx',
                    'return_url' => rtrim($qbapi->siteurl, '/').'/'.C_URL.'&a=user',
                    'key' => $this->page->global->cache->plugin->aljsfx->qb_key,
                );
                $url = $qbapi->createUrl($keyurlarray);
                echo json_encode(T::ajaxPostCharSet(array('code'=>1,'url'=>$url,'text'=>lang("plugin/aljsfx","distribution_php_77"))));
                exit;
            } else {
                $status=($this->page->global->cache->plugin->aljsfx->is_sh && !in_array($this->page->global->groupid,unserialize($this->page->global->cache->plugin->aljsfx->mgroups))) ? 0 : 1;

                $updatearray = array('status'=>$status);
                if ($rankdata['day'] == 0) {
                    $updatearray['rankendtime'] = 0;
                } else {
                    $updatearray['rankendtime'] = $vipendtime + ($rankdata['day'] * 86400);
                }
                $updatearray['rankid'] = ($shopdata['rankid'] == $this->page->get->rankid) ? $shopdata['vipid'] : $this->page->get->rankid;
                C::t('#aljbdx#aljbd_goods_order')->insert($orderarray);

                DB::update('aljsfx_shop',$updatearray,array('uid'=>$this->page->global->uid));
                $fxinfo = DB::fetch_first('select * from %t where uid=%d ', array('aljsfx_user', $this->page->global->uid));

                if($fxinfo){
                    DB::update('aljsfx_user',array('is_distribution'=>1),array('uid'=>$this->page->global->uid));
                }
                echo json_encode(T::ajaxPostCharSet(array('code'=>1,'url'=>C_URL.'&a=user','text'=>lang("plugin/aljsfx","distribution_php_78"))));
                exit;
            }
        }
    }
    
    /**
     * �����������
     *
     * @return void
     */
    public function add (){
        global $_G;
        $oss_domain = $_G['cache']['plugin']['aljoss']['cdn_domain'] ? $_G['cache']['plugin']['aljoss']['cdn_domain'] : $_G['cache']['plugin']['aljoss']['domain'];
        $aljsfx_rank=DB::fetch_all('select * from %t where status=1 order by displayorder desc,id asc',array('aljsfx_rank'));
        $shopdata = DB::fetch_first('select * from %t where uid=%d',array('aljsfx_shop',$this->page->global->uid));
        if($this->page->get->formhash == FORMHASH){
            if(!$_GET['agreement_checked'] && $_G['cache']['plugin']['aljsfx']['agreement']){
                $tip = lang("plugin/aljsfx","distribution_php_135").$_G['cache']['plugin']['aljsfx']['agreement_title'].lang("plugin/aljsfx","distribution_php_136");
                echo "<script>parent.tips('".$tip."','','error');</script>";
                exit;
            }
            if($_G['cache']['plugin']['aljsfx']['add_text']){
                if($_G['cache']['plugin']['aljsfx']['add_text'] == 1){
                    if(!$this->page->get->tel){
                        $tipstext = lang("plugin/aljsfx","distribution_php_81");
                        $this->tips($tipstext);
                    }else{
                        if(!T::isMobile($this->page->get->tel)){
                            $tipstext = lang("plugin/aljsfx","distribution_php_82");
                            $this->tips($tipstext);
                        }
                    }
                }else if($_G['cache']['plugin']['aljsfx']['add_text'] == 2){
                    if(!$this->page->get->name){
                        $tipstext = lang("plugin/aljsfx","distribution_php_80");
                        $this->tips($tipstext);
                    }
                    if(!$this->page->get->tel){
                        $tipstext = lang("plugin/aljsfx","distribution_php_81");
                        $this->tips($tipstext);
                    }else{
                        if(!T::isMobile($this->page->get->tel)){
                            $tipstext = lang("plugin/aljsfx","distribution_php_82");
                            $this->tips($tipstext);
                        }
                    }
                }else{
                    if(!$this->page->get->shop_name){
                        $tipstext = lang("plugin/aljsfx","distribution_php_79");
                        $this->tips($tipstext);
                    }
                    if(!$this->page->get->name){
                        $tipstext = lang("plugin/aljsfx","distribution_php_80");
                        $this->tips($tipstext);
                    }
                    if(!$this->page->get->tel){
                        $tipstext = lang("plugin/aljsfx","distribution_php_81");
                        $this->tips($tipstext);
                    }else{
                        if(!T::isMobile($this->page->get->tel)){
                            $tipstext = lang("plugin/aljsfx","distribution_php_82");
                            $this->tips($tipstext);
                        }
                    }
                }
            }
            

            $insertarray = array(
                'shop_name' => $this->page->get->shop_name,
                'name' => $this->page->get->name,
                'tel' => $this->page->get->tel,
            );
            if($shopdata){
                $idpicarray = array('shop_img','shop_weixin','shop_logo');
                foreach ($idpicarray as $pic1){
                    if ($this->page->get->$pic1) {
                        if(strpos($this->page->get->$pic1,$oss_domain) !== false){
                            $insertarray[$pic1] = $this->page->get->$pic1;
                        }else if (is_file($this->page->get->$pic1)) {
                            $insertarray[$pic1] = $this->page->get->$pic1;
                        } else {
                            unlink($shopdata[$this->page->get->$pic1]);
                            if($pic1 == 'shop_logo'){
                                $img_url = 'plugin.php?id=aljsfx&c=distribution&a=shop&shop_id='.$shopdata[id].'&d='.$shopdata[uid];
                                $imgpath = DISCUZ_ROOT.'source/plugin/aljwx/static/miniqrcode/'.md5($img_url).'.jpg';
                                
                                unlink($imgpath);
                            }
                            $insertarray[$pic1] = T::saveimg($this->page->get->$pic1,APP_PATH.'static/cache/');
                        }

                    }
                }
                if($shopdata['status'] == 3){
                    $insertarray['status'] = ($this->page->global->cache->plugin->aljsfx->is_sh && !in_array($this->page->global->groupid,unserialize($this->page->global->cache->plugin->aljsfx->mgroups))) ? 0 : 1;
                }
                DB::update('aljsfx_shop',$insertarray,array('uid'=>$this->page->global->uid));
                $tipstext = lang("plugin/aljsfx","distribution_php_83");
                $this->tips($tipstext,C_URL.'&a=user');
            }else{
                $rankid = $this->page->get->rankid;
                if(!$rankid){
                    $tipstext = lang("plugin/aljsfx","distribution_php_84");
                    $this->tips($tipstext);
                }
                $insertarray['rankid'] = $rankid;
                $insertarray['timestamp'] = TIMESTAMP;
                $insertarray['uid'] = $this->page->global->uid;
                $insertarray['username'] = $this->page->global->username;
                $insertarray['status'] = ($this->page->global->cache->plugin->aljsfx->is_sh && !in_array($this->page->global->groupid,unserialize($this->page->global->cache->plugin->aljsfx->mgroups))) ? 0 : 1;
                $fxinfo = DB::fetch_first('select * from %t where uid=%d ', array('aljsfx_user', $this->page->global->uid));
                if($fxinfo['first_leader_uid']>0){
                    $insertarray['subid'] = DB::result_first('select id from %t where uid=%d',array('aljsfx_shop',$fxinfo['first_leader_uid']));
                }
                $rankdata = DB::fetch_first('select * from %t where id=%d',array('aljsfx_rank',$rankid));
                if($rankdata){
                    $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
                    $orderarray=array(
                        'orderid' => $orderid,
                        'status' => 1,
                        'uid' => $this->page->global->uid,
                        'username' => $this->page->global->username,
                        'price' => $rankdata['price'],
                        'submitdate' => TIMESTAMP,
                        'remarks' => $rankdata['day'].'/'.$rankdata['price'],
                        'stitle' => lang("plugin/aljsfx","distribution_php_85").'-'.$_GET['name'],
                        'payment' => 7,
                        'pid'  => 4,//����
                        'browser'  => $_SERVER['HTTP_USER_AGENT'],
                    );
                    $orderarray['fare_desc'] = $rankid;
                    if($this->page->global->mobile){//1���ֻ���2��PC
                        $orderarray['mobile'] = 1;
                    }else{
                        $orderarray['mobile'] = 2;
                    }

                    if($rankdata['price']>0){
                        $insertarray['status'] = 2;
                        if($rankdata['day'] == 0){
                            $insertarray['rankendtime'] = 0;
                        }else{
                            $insertarray['rankendtime'] = TIMESTAMP + ($rankdata['day'] * 86400);
                        }
                        $insertid = DB::insert('aljsfx_shop',$insertarray, true);
                        $orderarray['shop_id'] = $insertid;
                        C::t('#aljgwc#aljbd_goods_order')->insert($orderarray);
                        //$url = 'plugin.php?id=aljbdx&act=pay&bid='.$insertid;
                        require_once 'source/plugin/aljqb/class/Qbapi.class.php';
                        $qbapi = new Qbapi();
                        $keyurlarray = array(
                            'orderid' => $orderid,
                            'time' => TIMESTAMP,
                            'price' => $rankdata['price'],
                            'keyname' => 'aljsfx',
                            'return_url' => rtrim($qbapi->siteurl, '/').'/'.C_URL.'&a=user',
                            'key' => $this->page->global->cache->plugin->aljsfx->qb_key,
                        );
                        $url = $qbapi -> createUrl($keyurlarray);
                        echo "<script>parent.location.href='" .$url . "';</script>";
                        exit;
                    }else{

                        if($rankdata['donation_amount'] > 0){//�������ͽ��
                            $first_insert = array(
                                'timestamp' => TIMESTAMP,
                                'beneficiary_uid' => $_G['uid'],
                                'beneficiary_username' => $_G['username'],
                                'payment_days' => $rankdata['payment_days'],
                                'uid' => $_G['uid'],
                                'username' => $_G['username'],
                                'money' => $rankdata['donation_amount'],
                                'status' => 1,
                                'name' => lang("plugin/aljsfx","pay_php_6").$rankdata['donation_amount'].lang("plugin/aljsfx","pay_php_5"),
                                'num' => 1,
                                'type' => 4,//�������ͽ��
                            );
                            DB::insert('aljsfx_order',$first_insert);
                            $insertarray['total_commission'] = $rankdata['donation_amount'];
                        }
                        if($rankdata['day'] == 0){
                            $insertarray['rankendtime'] = 0;
                        }else{
                            $insertarray['rankendtime'] = TIMESTAMP + ($rankdata['day'] * 86400);
                        }

                        $insertid = DB::insert('aljsfx_shop',$insertarray, true);
                        $orderarray['shop_id'] = $insertid;
                        $orderarray['status'] = 2;
                        if($fxinfo){
                            DB::update('aljsfx_user',array('is_distribution'=>1),array('uid'=>$this->page->global->uid));
                        }
                        C::t('#aljgwc#aljbd_goods_order')->insert($orderarray);
                    }
                }
                if($this->page->global->cache->plugin->aljsfx->is_sh && !in_array($this->page->global->groupid,unserialize($this->page->global->cache->plugin->aljsfx->mgroups))){
                    $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
                    foreach($groupids as $g_uid){
                        notification_add($g_uid['uid'], 'system',lang("plugin/aljsfx","distribution_php_86").lang("plugin/aljsfx","distribution_php_87").'</a>',array('from_idtype'  => 'aljsfx','from_id' => $order['shop_id']));
                    }
                }
                $tipstext = lang("plugin/aljsfx","distribution_php_88");
                $this->tips($tipstext,C_URL.'&a=user');
            }
        }else{

            $this->page->assign('shopdata', $shopdata);
            $this->page->assign('aljsfx_rank', $aljsfx_rank);

            if($shopdata){
                $this->page->assign('navtitle', lang("plugin/aljsfx","distribution_php_89"));
            }else{
                $this->page->assign('navtitle', lang("plugin/aljsfx","distribution_php_90"));
            }
            $this->page->display();
        }
    }
    /**
     * ��������
     *
     * @return void
     */
    public function user (){
        global $_G;
        $shopdata = DB::fetch_first('select * from %t where uid=%d',array('aljsfx_shop',$this->page->global->uid));
        
        if(!$shopdata){
            dheader("location: plugin.php?id=aljsfx&a=add&c=distribution&mobile=2");
            exit;
        }
        if($shopdata['status'] < 1){
            $desc = lang("plugin/aljsfx","distribution_php_91");
            $write_off_url = array('value' => lang("plugin/aljsfx","distribution_php_92"), 'url' => 'plugin.php?id=aljsfx&a=add&c=distribution');
            $orderurl = array('value' => lang("plugin/aljsfx","distribution_php_93"), 'url' => 'plugin.php?id=aljbd&act=user');
            $result_info = array(
                'icon' => 'weui-icon-warn',
                'title' => lang("plugin/aljsfx","distribution_php_94"),
                'desc' => $desc,
                'btn_primary' => $write_off_url,
                'btn_default' => $orderurl,
            );
            $this->weuiResult($result_info);
        }
        if($shopdata['status'] == 2){
            $desc = lang("plugin/aljsfx","distribution_php_95");
            $write_off_url = array('value' => lang("plugin/aljsfx","distribution_php_96"), 'url' => 'javascript:;');
            $orderurl = array('value' => lang("plugin/aljsfx","distribution_php_97"), 'url' => 'plugin.php?id=aljbd&act=user');
            $result_info = array(
                'icon' => 'weui-icon-warn',
                'title' => lang("plugin/aljsfx","distribution_php_98"),
                'desc' => $desc,
                'btn_primary' => $write_off_url,
                'btn_default' => $orderurl,
                'popup' => 'fxvip',
            );
            $this->weuiResult($result_info);
        }
        if($shopdata['status'] > 2){
            $desc = lang("plugin/aljsfx","distribution_php_99").$shopdata['admindesc'];
            $write_off_url = array('value' => lang("plugin/aljsfx","distribution_php_100"), 'url' => 'plugin.php?id=aljsfx&a=add&c=distribution');
            $orderurl = array('value' => lang("plugin/aljsfx","distribution_php_101"), 'url' => 'plugin.php?id=aljbd&act=user');
            $result_info = array(
                'icon' => 'weui-icon-warn',
                'title' => lang("plugin/aljsfx","distribution_php_102"),
                'desc' => $desc,
                'btn_primary' => $write_off_url,
                'btn_default' => $orderurl,
            );
            $this->weuiResult($result_info);
        }
        $rankdata = DB::fetch_first('select * from %t where id=%d',array('aljsfx_rank',$shopdata['rankid']));
        $fx_users = DB::fetch_all('select * from %t where first_leader_uid=%d',array('aljsfx_user',$_G['uid']));
        
        if($fx_users){
            foreach($fx_users as $f_uid){
                $fx_uids[] = $f_uid['uid'];
            }
        }
        if($rankdata['open_mypay']){
            $fx_uids[] = $_G['uid'];
        }
        
        if($fx_uids){
            if(count($fx_uids)>1){
                //��;����
                $zt_order  = DB::fetch_all('SELECT * FROM %t WHERE pid = 0 and store_id=0 and is_distribution=1 and dis_commission>0 and status>1 and status<4 and uid IN (%n)', array('aljbd_goods_order_list', $fx_uids));
            }else{
                $zt_order  = DB::fetch_all('SELECT * FROM %t WHERE pid = 0 and store_id=0 and is_distribution=1 and dis_commission>0 and status>1 and status<4 and uid = %d', array('aljbd_goods_order_list', $fx_uids[0]));
            }
        }
        
        if($zt_order){
            foreach($zt_order as $z_o_v){
                $zt_price_sum += ($z_o_v['price'] * $z_o_v['num'] * ($z_o_v['dis_commission']/100))*($rankdata['first_scale']/100);//��Ʒ����Ӷ��
            }
            
            if($zt_price_sum>0 && $rankdata['first_scale']>0){
                $zt_price = substr(sprintf("%.3f",$zt_price_sum),0,-1);
            }else{
                $zt_price = 0;
            }
            $this->page->assign('zt_price', $zt_price);
            
        }
        
        $this->page->assign('zt_order_count', count($zt_order)>0?count($zt_order):0);
        //debug($zt_price);
        if(!$rankdata){
            $desc = lang("plugin/aljsfx","distribution_php_103");
            $write_off_url = array('value' => lang("plugin/aljsfx","distribution_php_104"), 'url' => 'javascript:;');
            $orderurl = array('value' => lang("plugin/aljsfx","distribution_php_105"), 'url' => 'plugin.php?id=aljbd&act=user');
            $result_info = array(
                'icon' => 'weui-icon-warn',
                'title' => lang("plugin/aljsfx","distribution_php_106"),
                'desc' => $desc,
                'btn_primary' => $write_off_url,
                'btn_default' => $orderurl,
                'popup' => 'fxvip',
            );
            $this->weuiResult($result_info);
        }
        $mincashmoney = $rankdata['mincashmoney']>0 ? $rankdata['mincashmoney'] : $shopdata['account_commissions'] - $shopdata['extraction_commission'];
        $mincashtext = $rankdata['mincashmoney']>0 ? lang("plugin/aljsfx","distribution_php_107").$rankdata['mincashmoney'].lang("plugin/aljsfx","distribution_php_108") : '';

        $this->page->assign('mincashmoney', $mincashmoney);
        $this->page->assign('mincashtext', $mincashtext);

        $this->page->assign('shopdata', $shopdata);
        $this->page->assign('rankdata', $rankdata);
        $fx_userinfo = DB::fetch_first('select * from %t where uid=%d ', array('aljsfx_user', $_G['uid']));
        if($fx_userinfo['first_leader_uid'] && $_G['cache']['plugin']['aljsfx']['is_referee']){
            $fx_user = getuserbyuid($fx_userinfo['first_leader_uid']);
            $first_leader_uid_username = '<span style="font-size:12px;">&nbsp;(&nbsp;'.lang('plugin/aljsfx','distribution_php_134').$fx_user['username'].'&nbsp;)</span>';
        }
        $this->page->assign('first_leader_uid_username', $first_leader_uid_username , true);
        $this->page->assign('navtitle', lang("plugin/aljsfx","distribution_php_109"));
        $this->page->display();
    }
    /**
     * �ҵķ�������
     *
     * @return void
     */
    public function zt_order (){
        global $_G;
        $shopdata = DB::fetch_first('select * from %t where uid=%d',array('aljsfx_shop',$this->page->global->uid));
        $rankdata = DB::fetch_first('select * from %t where id=%d',array('aljsfx_rank',$shopdata['rankid']));
        $do = $this->page->get->do;
        if($do == 'ajax'){
            $currpage = $this->page->get->page ? $this->page->get->page : 1;
            $perpage = 20;
            $start = ($currpage - 1) * $perpage;
            $fx_users = DB::fetch_all('select * from %t where first_leader_uid=%d',array('aljsfx_user',$_G['uid']));
            
            if($fx_users){
                foreach($fx_users as $f_uid){
                    $fx_uids[] = $f_uid['uid'];
                }
            }
            if($rankdata['open_mypay']){
                $fx_uids[] = $_G['uid'];
            }
            if($fx_uids){
                if(count($fx_uids)>1){
                    //��;����
                    $teamList  = DB::fetch_all('SELECT * FROM %t WHERE pid = 0 and store_id=0 and is_distribution=1 and dis_commission>0 and status>1 and status<4 and uid IN (%n) order by dateline desc limit %d,%d', array('aljbd_goods_order_list', $fx_uids, $start ,$perpage));
                }else{
                    $teamList  = DB::fetch_all('SELECT * FROM %t WHERE pid = 0 and store_id=0 and is_distribution=1 and dis_commission>0 and status>1 and status<4 and uid = %d order by dateline desc limit %d,%d', array('aljbd_goods_order_list', $fx_uids[0], $start ,$perpage));
                }
            }
            //debug($teamList);
            if($teamList){
                foreach ($teamList as $teamk => $teamv) {
                    $user = getuserbyuid($teamv['uid']);
                    
                    $teamList[$teamk]['username'] = $user['username'];
                    $teamv['username'] = $user['username'];
                    if($teamv['goods_id']){
                        $teamList[$teamk]['scale'] = substr(sprintf("%.3f",$teamv['dis_commission']*$rankdata['first_scale']/100),0,-1);
                        $teamList[$teamk]['gpic'] = DB::result_first('select pic1 from %t where id=%d',array('aljbd_goods',$teamv['goods_id']));
                    }else{
                        $teamList[$teamk]['scale'] = substr(sprintf("%.3f",$teamv['shop_scale']*$rankdata['first_scale']/100),0,-1);
                        $teamList[$teamk]['gpic'] = avatar($teamv['uid'],'middle','true');
                        $teamList[$teamk]['name'] = $teamv['username'].lang("plugin/aljsfx","distribution_php_128").DB::result_first('select price from %t where orderid=%d',array('aljbd_goods_order',$teamv['orderid'])).lang("plugin/aljsfx","distribution_php_129");
                    }
                    $teamList[$teamk]['money'] = substr(sprintf("%.3f",($teamv['price'] * $teamv['num'] * ($teamv['dis_commission']/100))*($rankdata['first_scale']/100)),0,-1);//��Ʒ����Ӷ��
                    $teamList[$teamk]['dateline'] = dgmdate($teamv['dateline'],'u');
                    unset($user);
                }
            }
            

            if($teamList){
                echo json_encode(T::ajaxPostCharSet($teamList));
            }else{
                echo '1';
            }
            exit;
        }else {

            $this->page->assign('navtitle', lang('plugin/aljsfx','distribution_php_133'));
            $this->page->display();
        }
    }
    /**
     * ��������
     *
     * @return void
     */
    public function shop (){
        $shopdata = DB::fetch_first('select * from %t where id=%d',array('aljsfx_shop',$this->page->get->shop_id));

        if(!$shopdata){
            dheader("location: plugin.php?id=aljsfx&a=add&c=distribution");
            exit;
        }

        if(!$this->page->get->d){
            dheader("location: plugin.php?id=aljsfx&a=shop&c=distribution&shop_id=".$this->page->get->shop_id."&d=".$shopdata['uid']);
            exit;
        }

        DB::query('update %t set view=view+1 where id=%d',array('aljsfx_shop',$this->page->get->shop_id));
        if($this->page->global->uid == $shopdata['uid']){
            if($shopdata['status'] < 1){
                $desc = lang("plugin/aljsfx","distribution_php_110");
                $write_off_url = array('value' => lang("plugin/aljsfx","distribution_php_111"), 'url' => 'plugin.php?id=aljsfx&a=add&c=distribution');
                $orderurl = array('value' => lang("plugin/aljsfx","distribution_php_112"), 'url' => 'plugin.php?id=aljbd&act=user');
                $result_info = array(
                    'icon' => 'weui-icon-warn',
                    'title' => lang("plugin/aljsfx","distribution_php_113"),
                    'desc' => $desc,
                    'btn_primary' => $write_off_url,
                    'btn_default' => $orderurl,
                );
                $this->weuiResult($result_info);
            }
            if($shopdata['status'] == 2){
                $desc = lang("plugin/aljsfx","distribution_php_114");
                $write_off_url = array('value' => lang("plugin/aljsfx","distribution_php_115"), 'url' => 'javascript:;');
                $orderurl = array('value' => lang("plugin/aljsfx","distribution_php_116"), 'url' => 'plugin.php?id=aljbd&act=user');
                $result_info = array(
                    'icon' => 'weui-icon-warn',
                    'title' => lang("plugin/aljsfx","distribution_php_117"),
                    'desc' => $desc,
                    'btn_primary' => $write_off_url,
                    'btn_default' => $orderurl,
                    'popup' => 'fxvip',
                );
                $this->weuiResult($result_info);
            }
            if($shopdata['status'] > 2){
                $desc = lang("plugin/aljsfx","distribution_php_118").$shopdata['admindesc'];
                $write_off_url = array('value' => lang("plugin/aljsfx","distribution_php_119"), 'url' => 'plugin.php?id=aljsfx&a=add&c=distribution');
                $orderurl = array('value' => lang("plugin/aljsfx","distribution_php_120"), 'url' => 'plugin.php?id=aljbd&act=user');
                $result_info = array(
                    'icon' => 'weui-icon-warn',
                    'title' => lang("plugin/aljsfx","distribution_php_121"),
                    'desc' => $desc,
                    'btn_primary' => $write_off_url,
                    'btn_default' => $orderurl,
                );
                $this->weuiResult($result_info);
            }
        }else{
            if($shopdata['status'] != 1){
                $desc = lang("plugin/aljsfx","distribution_php_122");
                $write_off_url = array('value' => lang("plugin/aljsfx","distribution_php_123"), 'url' => 'plugin.php?id=aljsfx&a=add&c=distribution');
                $orderurl = array('value' => lang("plugin/aljsfx","distribution_php_124"), 'url' => 'plugin.php?id=aljbd&act=user');
                $result_info = array(
                    'icon' => 'weui-icon-warn',
                    'title' => lang("plugin/aljsfx","distribution_php_125"),
                    'desc' => $desc,
                    'btn_primary' => $write_off_url,
                    'btn_default' => $orderurl,
                );
                $this->weuiResult($result_info);
            }
        }

        $rankdata = DB::fetch_first('select * from %t where id=%d',array('aljsfx_rank',$shopdata['rankid']));
        $alltype = C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid(0);
        $this->page->assign('alltype', $alltype);
        $this->page->assign('shopdata', $shopdata);
        $this->page->assign('rankdata', $rankdata);

        $this->page->assign('navtitle', $shopdata['shop_name']);
        if($this->page->global->cache->plugin->aljsfx->description){
            $this->page->assign('description', $this->page->global->cache->plugin->aljsfx->description);
        }else{
            $this->page->assign('description', lang("plugin/aljsfx","distribution_php_126"));
        }
        $this->page->display();

    }
    /**
     * �ҵ��Ŷ�
     *
     * @return void
     */
    public function team (){
        $do = $this->page->get->do;
        $shopdata = DB::fetch_first('select * from %t where uid=%d',array('aljsfx_shop',$this->page->global->uid));
        $rankdata = DB::fetch_first('select * from %t where id=%d',array('aljsfx_rank',$shopdata['rankid']));
        if($do == 'ajax'){
            $currpage = $this->page->get->page ? $this->page->get->page : 1;
            $perpage = 20;
            $start = ($currpage - 1) * $perpage;
            $con[] = 'aljsfx_user';
            
            if($this->page->get->status == 2){
                $where = 'where second_leader_uid='.$this->page->global->uid;
            }else if($this->page->get->status == 3){
                $where = 'where third_leader_uid='.$this->page->global->uid;
            }else{
                $where = 'where first_leader_uid='.$this->page->global->uid;
            }
            
            
            if($_GET['kw']){
                $search = '%'.addcslashes($_GET['kw'], '%_').'%';
                $where.= " and username like %s";
                $con[] = $search;
            }
            $con[] = $start;
            $con[] = $perpage;
            $teamList = DB::fetch_all('select * from %t '.$where.' order by id desc limit %d,%d',$con);
            foreach ($teamList as $teamk => $teamv) {
                $teamList[$teamk]['userpic'] = avatar($teamv['uid'],'middle','true');
                $teamList[$teamk]['timestamp'] = dgmdate($teamv['timestamp'],'u');
            }
            if($teamList){
                echo json_encode(T::ajaxPostCharSet($teamList));
            }else{
                echo '1';
            }
            exit;
        }else {
            $this->page->assign('rankdata', $rankdata);
            $this->page->assign('navtitle', lang("plugin/aljsfx","distribution_php_127"));
            $this->page->display();
        }
    }
    /**
     * �ҵķ�������
     *
     * @return void
     */
    public function order (){
        $do = $this->page->get->do;
        if($do == 'ajax'){
            $currpage = $this->page->get->page ? $this->page->get->page : 1;
            $perpage = 20;
            $start = ($currpage - 1) * $perpage;
            $con[]='aljsfx_order';
            if($this->page->get->status == 1){
                $where = 'where status=1';
            }else if($this->page->get->status == 2){
                $where = 'where status=2';
            }else{
                $where = 'where 1';
            }
            
            if($this->page->global->groupid ==1 && $this->page->get->i == 1){
            }else{
                $where .= ' and beneficiary_uid='.$this->page->global->uid;
            }
            if($_GET['kw']){
                $keyword = '%'.addcslashes($_GET['kw'], '%_').'%';
                $con[] ='%' . $keyword . '%';
                $con[] ='%' . $keyword . '%';
                $con[] ='%' . $keyword . '%';
                $where.=" and (beneficiary_username like %s or orderid like %s or username like %s)";
            }
            $where.= ' order by id desc limit %d,%d';
            $con[] = $start;
            $con[] = $perpage;
            $teamList = DB::fetch_all('select * from %t '.$where,$con);
            foreach ($teamList as $teamk => $teamv) {
                if(!$teamv['name']){
                    $order_g = DB::fetch_first('select * from %t where orderid=%s',array('aljbd_goods_order_list',$teamv['orderid']));
                    $teamList[$teamk]['name'] = $order_g['name'];
                    $teamList[$teamk]['price'] = $order_g['price'];
                    $teamList[$teamk]['num'] = $order_g['num'];
                    $teamList[$teamk]['goods_id'] = $order_g['goods_id'];
                    $teamv['goods_id'] = $order_g['goods_id'];
                    $teamList[$teamk]['dis_commission'] = $order_g['dis_commission'];
                    $teamv['dis_commission'] = $order_g['dis_commission'];
                }
                if($teamv['goods_id']){
                    $teamList[$teamk]['scale'] = substr(sprintf("%.3f",$teamv['dis_commission']*$teamv['scale']/100),0,-1);
                    $teamList[$teamk]['gpic'] = DB::result_first('select pic1 from %t where id=%d',array('aljbd_goods',$teamv['goods_id']));
                }else{
                    $teamList[$teamk]['scale'] = substr(sprintf("%.3f",$teamv['shop_scale']*$teamv['scale']/100),0,-1);
                    $teamList[$teamk]['gpic'] = avatar($teamv['uid'],'middle','true');
                    if($teamv['type'] != 4){
                        $teamList[$teamk]['name'] = $teamv['username'].lang("plugin/aljsfx","distribution_php_128").DB::result_first('select price from %t where orderid=%d',array('aljbd_goods_order',$teamv['orderid'])).lang("plugin/aljsfx","distribution_php_129");
                    }
                }

                $teamList[$teamk]['timestamp'] = dgmdate($teamv['timestamp'],'u');
            }

            if($teamList){
                echo json_encode(T::ajaxPostCharSet($teamList));
            }else{
                echo '1';
            }
            exit;
        }else {

            $this->page->assign('navtitle', lang("plugin/aljsfx","distribution_php_130"));
            $this->page->display();
        }
    }
    /**
     * ������Ʒ�б�
     *
     * @return void
     */
    public function shopGoods () {
        $pluginid = 'aljbd';
        $con = 'where state=0 and rubbish=0 and is_distribution = 1';
        $where[] = $pluginid.'_goods';


        if ($_GET['typeid']) {
            $con .= " and typeid=%d";
            $where[] = $_GET['typeid'];
        }
        if ($_GET['subtypeid']) {
            $con .= " and subtypeid=%d";
            $where[] = $_GET['subtypeid'];
        }

        if($_GET['type']){
            $con .= " and type=%d";
            $where[] = $_GET['type'];
        }
        if($_GET['keywords']){
            $search = '%'.addcslashes($_GET['keywords'], '%_').'%';
            $con.= " and name like %s";
            $where[] = $search;
        }

        $currpage=$_GET['page']?$_GET['page']:1;
        $perpage=10;
        $start=($currpage-1)*$perpage;
        $num = DB::result_first('select count(*) from %t '.$con,$where);
        $max = ceil($num/$perpage);

        if($currpage == 1){
            $max_page ='<input type="hidden" id="max-page" value="'.$max.'">';
        }

        if($currpage == $max){
            $mes = '<div class="c_click_see" id="more" style="background: none;float: left;">- '.lang("plugin/aljsfx","distribution_php_131").' -</div>';
        }
        if($_GET['orderby'] == '1'){
            $con .= ' order by buyamount desc ';
        }else if($_GET['orderby'] == '2'){
            $con .= ' order by id desc ';
        }else if($_GET['orderby'] == '3'){
            $con .= ' order by price1 desc ';
        }else if($_GET['orderby'] == '4'){
            $con .= ' order by price1 asc ';
        }else{
            $con .= ' order by sign desc,displayorder desc,id desc,view desc ';
        }
        $con .= ' limit %d,%d ';
        $where[] = $start;
        $where[] = $perpage;
        $goodslist = DB::fetch_all('select * from %t '.$con,$where);
        if($goodslist){
            foreach($goodslist as $k=>$v){
                $sku_price = T::skuminprice($v['attr_sku'],$v['commodity_type'],1);
            
                if($sku_price['max_price'] > 0){
                    $v['price1'] = $sku_price['max_price'];
                }
                $goodslist[$k]['price1']=floatval($v['price1']);
                $goodslist[$k]['price2']=floatval($v['price2']);
                if($v['selling_point']){
                    $selling_point = str_replace(lang("plugin/aljsfx","distribution_php_132"),',',$v['selling_point']);
                    $goodslist[$k]['selling_point'] = explode(',',$selling_point);
                }
            }

            $goodslist = dhtmlspecialchars($goodslist);
        }else{
            $goodslist = 0;
        }

        $this->page->assign('goodslist', $goodslist);

        $shopdata = DB::fetch_first('select a.uid,b.* from %t a left join %t b on a.rankid=b.id where a.id=%d and a.status=1',array('aljsfx_shop','aljsfx_rank',$this->page->get->shop_id));

        $this->page->assign('shopdata', $shopdata);
        $this->page->assign('max_page', $max_page,true);
        $this->page->assign('mes', $mes,true);
        $this->page->assign('currpage', $currpage);
        $this->page->display();
    }
    /**
     * ����ͼƬ
     *
     * @param string $pic base64
     *
     * @return void
     */
    public function saveimg($pic) {
        $image_path = APP_PATH.'static/';
        $rand = rand(100, 999);
        $pics = date("YmdHis") . $rand . '.jpg';
        $dir = $image_path.'cache/'.date('Ymd',TIMESTAMP).'/';
        if(!is_dir($dir)) {
            @mkdir($dir, 0777);
        }
        $src = $dir. $pics;
        if(IN_MINI == 1){
            require_once DISCUZ_ROOT.'source/plugin/aljwx/class/wechatclient.lib.class.php';
            $wechat_client = new WeChatClient($this->page->global->cache->plugin->aljwx->g_appid,$this->page->global->cache->plugin->aljwx->g_AppSecret);
            $return = $wechat_client -> download($pic);
            if(file_put_contents(DISCUZ_ROOT.'./'.$src, $return) !== false){
                return $src;
            }else {
                return '';
            }
        }else{
            if(file_put_contents($src,file_get_contents($pic))) {
                return $src;
            }else {
                return '';
            }
        }
    }
    /**
     * Ǯ�������
     *
     * @param int $uid �û�id
     * @param int $price �۸�
     * @param string $orderid ������
     * @param string $desc �����Ǯ������
     *
     * @return array
     */
    public function aljqbChargeMoney ($uid=0,$price=0,$orderid='',$desc='') {
        require_once 'source/plugin/aljqb/class/Qbapi.class.php';
        $Qbapi = new Qbapi();
        $queuearray = array(
            'app_name' => 'aljsfx',
            'app_type' => 'aljsfx_txcancel',
            'app_phone' => '123456789',
            'app_ip' => $this->page->global->clientip,
        );
        $balancearray = array(
            'type' => 'charge',
            'uid' => $uid,
            'price' => $price,
            'orderid' => $orderid,
            'desc' => $desc,
        );
        $res = $Qbapi->balance($queuearray, $balancearray);
        return $res;
    }
    /**
     * Ʒ���̼ҹ�������ע��
     *
     *
     * @return void
     */
    public function aljbdParameter(){
        global $Html5Plusapp,$immersed;
        $settings=C::t('#aljbd#aljbd_setting')->range();
        $mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_common_footernav']['value']));
        foreach($mobile_common_footernav as $key=>$value){
            $arr=explode('|',$value);
            $mobile_common_footernav_arr[]=$arr;
        }
        $lazyloadlogo = $settings['lazyloadlogo']['value'];
        if ($lazyloadlogo) {
            $loading = $lazyloadlogo;
        } else {
            $loading = 'source/plugin/aljbd/images/loading.gif';
        }
        $price_unit = '&#65509;';
        $this->page->assign('loading', $loading);
        $this->page->assign('noimg', 'source/plugin/aljbd/images/sj/noimg.gif');
        $this->page->assign('price_unit', $price_unit,true);
        $this->page->assign('pluginid', 'aljbd');
        $this->page->assign('Html5Plusapp', $Html5Plusapp);
        $this->page->assign('immersed', $immersed);
        $this->page->assign('settings', $settings);
        $this->page->assign('mobile_common_footernav_arr', $mobile_common_footernav_arr,true);
        $this->page->assign('common_template_pluginid', 'aljbd');
        $this->page->assign('common_path', 'source/plugin/aljhtx');
    }
}

