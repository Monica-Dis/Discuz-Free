<?php
	define('DISABLEXSSCHECK',true);
	require '../../../../source/class/class_core.php';
	$discuz = C::app();
	$discuz->init();
  	loadcache('plugin');

	require_once '../../../../source/plugin/aljqb/class/Qbapi.class.php';
	if(file_exists('../../../../source/plugin/aljqb/class/Getdata.class.php')){
		require_once '../../../../source/plugin/aljqb/class/Getdata.class.php';
		$getdata = new Getdata();
	}
	//file_put_contents('d.txt',$key."\r",FILE_APPEND);
	//file_put_contents('d.txt',$_GET['key']."\r",FILE_APPEND);
	$pluginid = 'aljbd';
	$orderlurl = $_G['siteurl'].'/plugin.php?id='.$pluginid.'&act=orderlist';
	$orderlurln = '/plugin.php?id='.$pluginid.'&act=orderlist';
	$data['transaction_id'] = $_GET['aljorderid'];
    require '../../../../source/plugin/aljbdx/function/function_core.php';
	$qbapi = new Qbapi();
	$keyarray = array(
		'aljorderid'=> $_GET['aljorderid'],
		'paytime' => $_GET['paytime'],
		'orderid' => $_GET['orderid'],
	);
	if($_GET['key']) {
		$keyarray['key'] = $_G['cache']['plugin']['aljsfx']['qb_key'];
		$key = $qbapi->createKey($keyarray);
		$getkey = $_GET['key'];
	}elseif(file_exists('../../../../source/plugin/aljqb/class/Getdata.class.php')) {
		$appinfo = $getdata->getAppParam();
		$appinfo['posttime']=$_GET['posttime'];
		$key = $getdata->CreateAppSign($appinfo);
		$getkey = $_GET['sign'];
	}
	if($key == $getkey) {
        $order = C::t('#aljgwc#aljbd_goods_order') -> fetch($_GET['orderid']);
		if($order['status'] == 1){
            $user = getuserbyuid($order['uid']);
            if(($_G['cache']['plugin']['aljsfx']['is_sh'] && in_array($user['groupid'],unserialize($_G['cache']['plugin']['aljsfx']['mgroups']))) || !$_G['cache']['plugin']['aljsfx']['is_sh']){
                $status=1;
            }else{
                $status=0;
                $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
                foreach($groupids as $g_uid){
                    notification_add($g_uid['uid'], 'system',lang("plugin/aljsfx","pay_php_1").lang("plugin/aljsfx","pay_php_2").'</a>',array('from_idtype'  => 'aljsfx','from_id' => $order['shop_id']));
                }
            }
            $updatearray = array('status'=>$status);

            $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljsfx_rank',$order['fare_desc']));
            if($vipdata){
                if($vipdata['day'] == 0){
                    $vipendtime = 0;
                }else{
                    //����VIP
                    if($order['opentime']){
                        $vipendtime = $order['opentime'] + ($vipdata['day'] * 86400);
                    }else{
                        $vipendtime = TIMESTAMP + ($vipdata['day'] * 86400);
                    }
                }
                $updatearray['rankendtime'] = $vipendtime;
			}

            //vipid ����VIP
            if($order['fare_desc']){
                $updatearray['rankid'] = $order['fare_desc'];
            }
            if(!$order['opentime']){
                if($vipdata['donation_amount'] > 0){//�������ͽ��
                    $first_insert = array(
                        'timestamp' => TIMESTAMP,
                        'beneficiary_uid' => $order['uid'],
                        'beneficiary_username' => $order['username'],
                        'payment_days' => $vipdata['payment_days'],
                        'uid' => $order['uid'],
                        'username' => $order['username'],
                        'money' => $vipdata['donation_amount'],
                        'status' => 1,
                        'name' => lang("plugin/aljsfx","pay_php_6").$vipdata['donation_amount'].lang("plugin/aljsfx","pay_php_5"),
                        'num' => 1,
                        'type' => 4,//�������ͽ��
                    );
                    DB::insert('aljsfx_order',$first_insert);
                    $updatearray['total_commission'] = $vipdata['donation_amount'];
                }
            }
            
            DB::update('aljsfx_shop',$updatearray,array('id'=>$order['shop_id']));
            $fxinfo = DB::fetch_first('select * from %t where uid=%d ', array('aljsfx_user', $order['uid']));

            if($fxinfo){
                DB::update('aljsfx_user',array('is_distribution'=>1),array('uid'=>$order['uid']));
            }

            $qborder = DB::fetch_first('select * from %t where aljorderid=%s',array('aljqb_payorder',$_GET['aljorderid']));
            C::t('#aljgwc#aljbd_goods_order')->update($_GET['orderid'], array('admin'=>$qborder['trade_mod'],'status' => 2, 'buyer' => $data['transaction_id'], 'confirmdate' => $_GET['paytime']));

            //s ������ѯ���� �ֵ�
            if($_G['cache']['plugin']['aljsfx']['is_aljsfx']){
                $fxinfo = DB::fetch_first('select * from %t where uid=%d ', array('aljsfx_user', $order['uid']));
                if($fxinfo){
                    if($fxinfo['first_leader_uid']>0){//һ����ID
                        //��������������
                        $first_shopdata = DB::fetch_first('select a.username,b.* from %t a left join %t b on a.rankid=b.id where a.uid=%d and a.status=1',array('aljsfx_shop','aljsfx_rank',$fxinfo['first_leader_uid']));

                        $fx_goods_price = substr(sprintf("%.3f",$order['price'] * ($first_shopdata['f_shop_scale']/100)),0,-1);//�̼���פ����Ӷ��
                        if($first_shopdata && $first_shopdata['first_scale']>0){
                            $first_fee = substr(sprintf("%.3f",$fx_goods_price*($first_shopdata['first_scale']/100)),0,-1);//һ�������̽������
                            if($first_fee>0){
                                $first_insert = array(
                                    'orderid' => $_GET['orderid'],
                                    'timestamp' => TIMESTAMP,
                                    'beneficiary_uid' => $fxinfo['first_leader_uid'],
                                    'beneficiary_username' => $first_shopdata['username'],
                                    'payment_days' => $first_shopdata['payment_days'],
                                    'uid' => $order['uid'],
                                    'username' => $order['username'],
                                    'money' => $first_fee,
                                    'scale' => $first_shopdata['first_scale'],
                                    'shop_scale' => $first_shopdata['f_shop_scale'],
                                    'status' => 1,
                                    'type' => 2,
                                );
                                DB::insert('aljsfx_order',$first_insert);
                                DB::query('update %t set total_commission=total_commission+%i where uid=%d',array('aljsfx_shop',$first_fee,$fxinfo['first_leader_uid']));
                            }
                        }
                    }
                    if($fxinfo['second_leader_uid']>0 && $fxinfo['first_leader_uid'] != $fxinfo['second_leader_uid']){//��������ID
                        //��������������
                        $second_shopdata = DB::fetch_first('select a.username,b.* from %t a left join %t b on a.rankid=b.id where a.uid=%d and a.status=1',array('aljsfx_shop','aljsfx_rank',$fxinfo['second_leader_uid']));
                        $fx_goods_price = substr(sprintf("%.3f",$order['price'] * ($second_shopdata['f_shop_scale']/100)),0,-1);//�̼���פ����Ӷ��
                        if($second_shopdata && $second_shopdata['second_scale']>0){
                            $second_fee = substr(sprintf("%.3f",$fx_goods_price*($second_shopdata['second_scale']/100)),0,-1);//���������̽������
                            if($second_fee>0){
                                $second_insert = array(
                                    'orderid' => $_GET['orderid'],
                                    'timestamp' => TIMESTAMP,
                                    'beneficiary_uid' => $fxinfo['second_leader_uid'],
                                    'beneficiary_username' => $second_shopdata['username'],
                                    'payment_days' => $second_shopdata['payment_days'],
                                    'uid' => $order['uid'],
                                    'username' => $order['username'],
                                    'money' => $second_fee,
                                    'scale' => $second_shopdata['second_scale'],
                                    'shop_scale' => $second_shopdata['f_shop_scale'],
                                    'status' => 1,
                                    'level' => 1,
                                    'type' => 2,
                                );
                                DB::insert('aljsfx_order',$second_insert);
                                DB::query('update %t set total_commission=total_commission+%i where uid=%d',array('aljsfx_shop',$second_fee,$fxinfo['second_leader_uid']));
                            }
                        }
                    }
                    if($fxinfo['third_leader_uid']>0){//��������ID
                        //��������������
                        $third_shopdata = DB::fetch_first('select a.username,b.* from %t a left join %t b on a.rankid=b.id where a.uid=%d and a.status=1',array('aljsfx_shop','aljsfx_rank',$fxinfo['third_leader_uid']));
                        $fx_goods_price = substr(sprintf("%.3f",$order['price'] * ($third_shopdata['f_shop_scale']/100)),0,-1);//�̼���פ����Ӷ��
                        if($third_shopdata && $third_shopdata['second_scale']>0){
                            $third_fee = substr(sprintf("%.3f",$fx_goods_price*($third_shopdata['third_scale']/100)),0,-1);//���������̽������
                            if($third_fee>0){
                                $third_insert = array(
                                    'orderid' => $_GET['orderid'],
                                    'timestamp' => TIMESTAMP,
                                    'beneficiary_uid' => $fxinfo['third_leader_uid'],
                                    'beneficiary_username' => $third_shopdata['username'],
                                    'payment_days' => $third_shopdata['payment_days'],
                                    'uid' => $order['uid'],
                                    'username' => $order['username'],
                                    'money' => $third_fee,
                                    'scale' => $third_shopdata['third_scale'],
                                    'shop_scale' => $third_shopdata['f_shop_scale'],
                                    'status' => 1,
                                    'level' => 2,
                                    'type' => 2,
                                );
                                DB::insert('aljsfx_order',$third_insert);
                                DB::query('update %t set total_commission=total_commission+%i where uid=%d',array('aljsfx_shop',$third_fee,$fxinfo['third_leader_uid']));
                            }
                        }
                    }
                }
            }
            //e ������ѯ����
            //����Ǯ�� +money ����ͳ���ʻ�
            if($_G['cache']['plugin']['aljbdx']['money_uid']>0){
                $usermoney = getuserbyuid($_G['cache']['plugin']['aljbdx']['money_uid']);
                $queuearray = array(
                    'app_name' => 'aljsfx',
                    'app_type' => 'aljsfx_rz',
                    'app_phone' => '123456789',
                    'app_ip' => $_G['clientip'],
                );
                $fxtips = lang("plugin/aljsfx","pay_php_3").'{username}'.lang("plugin/aljsfx","pay_php_4").'{money}'.lang("plugin/aljsfx","pay_php_5");
                $balancearray = array(
                    'type'=> 'charge',
                    'uid'=>$_G['cache']['plugin']['aljbdx']['money_uid'],
                    'price' => $order['price'],
                    'orderid'=> $_GET['orderid'],
                    'desc'=> str_replace(array('{username}','{money}'),array($order['username'],$order['price']),$fxtips),
                );
                $result_money_uid = $qbapi -> balance($queuearray,$balancearray);
            }
		}
        echo 'success';
        exit;
	}
//From: Dism��taobao��com
?>
