<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$fxinfo = DB::fetch_first('select * from %t where uid=%d ', array('aljsfx_user', $order['uid']));
$shopdata = DB::fetch_first('select * from %t where uid=%d',array('aljsfx_shop',$order['uid']));
if($shopdata && ($shopdata['rankendtime'] == 0 || $shopdata['rankendtime'] > TIMESTAMP)){
    $rankdata = DB::fetch_first('select * from %t where id=%d',array('aljsfx_rank',$shopdata['rankid']));
    if($rankdata['open_mypay']){
        if($fxinfo['first_leader_uid']>0){//һ����ID
            if($fxinfo['second_leader_uid']>0 && $fxinfo['first_leader_uid'] != $fxinfo['second_leader_uid']){//ԭ��������ID��Ϊ������ID
                $fxinfo['second_leader_uid'] = $fxinfo['second_leader_uid'];
            }
            $fxinfo['second_leader_uid'] = $fxinfo['first_leader_uid'];//ԭ1������ID��Ϊ2����ID
        }
        $fxinfo['first_leader_uid'] = $order['uid'];//1����Ϊ������
    }
}

$fx_gs = DB::fetch_all('select * from %t where orderid=%s',array('aljbd_goods_order_list',$order['orderid']));
foreach($fx_gs as $f_k => $fx_goods){
    if($fxinfo && $fx_goods['is_distribution'] && $fx_goods['dis_commission']>0){
        $fx_goods_price = substr(sprintf("%.3f",$fx_goods['price'] * $fx_goods['num'] * ($fx_goods['dis_commission']/100)),0,-1);//��Ʒ����Ӷ�����
        if($fxinfo['first_leader_uid']>0){//һ����ID
            //��������������
            $first_shopdata = DB::fetch_first('select a.username,b.* from %t a left join %t b on a.rankid=b.id where a.uid=%d and a.status=1',array('aljsfx_shop','aljsfx_rank',$fxinfo['first_leader_uid']));
            if($first_shopdata && $first_shopdata['first_scale']>0){
                $first_fee = substr(sprintf("%.3f",$fx_goods_price*($first_shopdata['first_scale']/100)),0,-1);//һ�������̽������
                if($first_fee>0){
                    $first_insert = array(
                        'orderid' => $order['orderid'],
                        'timestamp' => TIMESTAMP,
                        'beneficiary_uid' => $fxinfo['first_leader_uid'],
                        'beneficiary_username' => $first_shopdata['username'],
                        'payment_days' => $first_shopdata['payment_days'],
                        'uid' => $order['uid'],
                        'username' => $order['username'],
                        'money' => $first_fee,
                        'scale' => $first_shopdata['first_scale'],
                        'status' => 1,
                        'name' => $fx_goods['name'],
                        'price' => $fx_goods['price'],
                        'num' => $fx_goods['num'],
                        'goods_id' => $fx_goods['goods_id'],
                        'dis_commission' => $fx_goods['dis_commission'],
                    );
                    DB::insert('aljsfx_order',$first_insert);
                    DB::query('update %t set total_commission=total_commission+%i where uid=%d',array('aljsfx_shop',$first_fee,$fxinfo['first_leader_uid']));
                    notification_add($fxinfo['first_leader_uid'], 'system',lang("plugin/aljsfx","receipt_php_1").$order['username'].lang("plugin/aljsfx","receipt_php_2").$order['stitle'].lang("plugin/aljsfx","receipt_php_3").$first_fee.lang("plugin/aljsfx","receipt_php_4").'<a href="plugin.php?id=aljsfx&a=order&c=distribution">'.lang("plugin/aljsfx","receipt_php_5").'</a>',array('from_idtype'  => 'aljsfx','from_id' =>$fxinfo['first_leader_uid']));
                }
            }
        }
        if($fxinfo['second_leader_uid']>0 && $fxinfo['first_leader_uid'] != $fxinfo['second_leader_uid']){//��������ID
            //��������������
            $second_shopdata = DB::fetch_first('select a.username,b.* from %t a left join %t b on a.rankid=b.id where a.uid=%d and a.status=1',array('aljsfx_shop','aljsfx_rank',$fxinfo['second_leader_uid']));
            if($second_shopdata && $second_shopdata['second_scale']>0){
                $second_fee = substr(sprintf("%.3f",$fx_goods_price*($second_shopdata['second_scale']/100)),0,-1);//���������̽������
                if($second_fee>0){
                    $second_insert = array(
                        'orderid' => $order['orderid'],
                        'timestamp' => TIMESTAMP,
                        'beneficiary_uid' => $fxinfo['second_leader_uid'],
                        'beneficiary_username' => $second_shopdata['username'],
                        'payment_days' => $second_shopdata['payment_days'],
                        'uid' => $order['uid'],
                        'username' => $order['username'],
                        'money' => $second_fee,
                        'scale' => $second_shopdata['second_scale'],
                        'status' => 1,
                        'level' => 1,
                        'name' => $fx_goods['name'],
                        'price' => $fx_goods['price'],
                        'num' => $fx_goods['num'],
                        'goods_id' => $fx_goods['goods_id'],
                        'dis_commission' => $fx_goods['dis_commission'],
                    );
                    DB::insert('aljsfx_order',$second_insert);
                    DB::query('update %t set total_commission=total_commission+%i where uid=%d',array('aljsfx_shop',$second_fee,$fxinfo['second_leader_uid']));
                    notification_add($fxinfo['second_leader_uid'], 'system',lang("plugin/aljsfx","receipt_php_6").$order['username'].lang("plugin/aljsfx","receipt_php_7").$order['stitle'].lang("plugin/aljsfx","receipt_php_8").$second_fee.lang("plugin/aljsfx","receipt_php_9").'<a href="plugin.php?id=aljsfx&a=order&c=distribution">'.lang("plugin/aljsfx","receipt_php_10").'</a>',array('from_idtype'  => 'aljsfx','from_id' =>$fxinfo['second_leader_uid']));
                }
            }
        }
        if($fxinfo['third_leader_uid']>0){//��������ID
            //��������������
            $third_shopdata = DB::fetch_first('select a.username,b.* from %t a left join %t b on a.rankid=b.id where a.uid=%d and a.status=1',array('aljsfx_shop','aljsfx_rank',$fxinfo['third_leader_uid']));
            if($third_shopdata && $third_shopdata['second_scale']>0){
                $third_fee = substr(sprintf("%.3f",$fx_goods_price*($third_shopdata['third_scale']/100)),0,-1);//���������̽������
                if($third_fee>0){
                    $third_insert = array(
                        'orderid' => $order['orderid'],
                        'timestamp' => TIMESTAMP,
                        'beneficiary_uid' => $fxinfo['third_leader_uid'],
                        'beneficiary_username' => $third_shopdata['username'],
                        'payment_days' => $third_shopdata['payment_days'],
                        'uid' => $order['uid'],
                        'username' => $order['username'],
                        'money' => $third_fee,
                        'scale' => $third_shopdata['third_scale'],
                        'status' => 1,
                        'level' => 2,
                        'name' => $fx_goods['name'],
                        'price' => $fx_goods['price'],
                        'num' => $fx_goods['num'],
                        'goods_id' => $fx_goods['goods_id'],
                        'dis_commission' => $fx_goods['dis_commission'],
                    );
                    DB::insert('aljsfx_order',$third_insert);
                    DB::query('update %t set total_commission=total_commission+%i where uid=%d',array('aljsfx_shop',$third_fee,$fxinfo['third_leader_uid']));
                    notification_add($fxinfo['third_leader_uid'], 'system',lang("plugin/aljsfx","receipt_php_11").$order['username'].lang("plugin/aljsfx","receipt_php_12").$order['stitle'].lang("plugin/aljsfx","receipt_php_13").$third_fee.lang("plugin/aljsfx","receipt_php_14").'<a href="plugin.php?id=aljsfx&a=order&c=distribution">'.lang("plugin/aljsfx","receipt_php_15").'</a>',array('from_idtype'  => 'aljsfx','from_id' =>$fxinfo['third_leader_uid']));
                }
            }
        }
    }
    if($fx_goods['is_distribution'] && $fx_goods['dis_commission']>0){
        $fx_goods_prices += $fx_goods['price'] * $fx_goods['num'] * ($fx_goods['dis_commission']/100);//��Ʒ����Ӷ�����
    }
    unset($third_fee);
    unset($second_fee);
    unset($first_fee);
}
//From: Dism��taobao��com
?>