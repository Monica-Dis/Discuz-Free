<?php

/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com/
 * (C) dism-Taobao-com
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class mobileplugin_aljsfx{
	function common(){
        global $_G,$bindtime;
        //����ID
        $duid = intval($_GET['d']);
        if($duid>0){
            dsetcookie('duid', $duid, 86400);
        }
        $fromuid_fx = !empty($_G['cookie']['duid']) ? intval($_G['cookie']['duid']) : 0;
        //�ж����û��󶨱��Ƿ�������
        if($fromuid_fx  && $_G['uid'] != $fromuid_fx && $_G['uid'] && !DB::fetch_first('select * from %t where uid=%d ', array('aljsfx_user', $_G['uid']))){
            //��¼����Ϣ
            $benuser = DB::fetch_first('select * from %t where uid=%d',array('common_member',$_G['uid']));
            $bindtime = $_G['cache']['plugin']['aljsfx']['bindtime'] ? $_G['cache']['plugin']['aljsfx']['bindtime']*60*60 :'86400';
            //ע��ʱ��С��60��û���ϼ���ϵ��
            if($benuser['regdate']+$bindtime > TIMESTAMP) {
                $fromdata = DB::fetch_first('select * from %t where uid=%d ', array('aljsfx_user', $fromuid_fx));
                if ($fx_shop=DB::fetch_first('select * from %t where uid=%d and status=1', array('aljsfx_shop', $fromuid_fx))) {
                    $fx_user_insertarray = array(
                        'first_leader_uid' => $fromuid_fx,
                        'uid' => $_G['uid'],
                        'username' => $_G['username'],
                        'timestamp' => TIMESTAMP,
                        'second_leader_uid' => $fromdata['first_leader_uid'] !=$fromuid_fx ? $fromdata['first_leader_uid'] : '',
                        'third_leader_uid' => $fromdata['second_leader_uid'] !=$fromuid_fx ? $fromdata['second_leader_uid'] : '',
                    );
                    if($_G['cache']['plugin']['aljsfx_rt']['is_new_reward']){
                        $fx_rankdata = DB::fetch_first('select * from %t where id=%d', array('aljsfx_rank', $fx_shop['rankid']));
                        if($fx_rankdata['new_reward']>0){
                            $fx_user_insertarray['is_reward'] = 1;
                            $fx_user_insertarray['new_reward'] = $fx_rankdata['new_reward'];
                        }
                    }
                    if(DB::fetch_first('select * from %t where uid=%d ',array('aljsfx_shop',$_G['uid']))){
                        $fx_user_insertarray['is_distribution'] = 1;
                    }
                    DB::insert('aljsfx_user', $fx_user_insertarray);
                    notification_add($fromuid_fx, 'system', lang("plugin/aljsfx","hook_class_php_1") . $_G['username'] . lang("plugin/aljsfx","hook_class_php_2") . ' <a href="plugin.php?id=aljsfx&a=team&c=distribution">' . lang("plugin/aljsfx","hook_class_php_3") . '</a>', array('from_idtype' => 'aljsfx', 'from_id' => $_G['uid']));
                }
            }
        }
    }
}
class mobileplugin_aljsfx_member extends mobileplugin_aljsfx {
    function register_post_message($param){
        global $_G;

    }
}
//From: Dism��taobao��com
?>
