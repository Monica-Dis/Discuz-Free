<?php

/**
 *
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * @version 1.0
 * @link http://docs.liangjianyun.com/
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class aljstgAction{
    public $page;
    public $onetype;
    public function __construct($page) {
        global $aljtsq_post_goods;
        $this->page = $page;
        $this->page->assign('aljtsq_post_goods', $aljtsq_post_goods,true);
        if($aljtsq_post_goods){
            $this->onetype = C::t('#aljtsc#aljtsc_type')->fetch_all_by_upid(0);
        }else{
            $this->onetype = C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid(0);
        }
        $this->aljbdParameter();
        if(!$this->page->global->mobile){
            if($this->page->global->cache->plugin->aljstg->is_pc_list){
                $headerurl = 'plugin.php?id=aljbd&act=goods&commodity_type=1';
                dheader("location:".$headerurl);
                exit;
            }else{
                $navtitle = $this->page->global->cache->plugin->aljstg->aljstg_name;
                $title = lang('plugin/aljstg','aljstg_php_1').$this->page->global->cache->plugin->aljstg->aljstg_name;
                $url = $this->page->global->siteurl.'plugin.php?id=aljstg';
                $this->page -> pcQrcode($navtitle,$title,$url);
            }
        }
        
    }
    /**
     *  �Ź���ҳ
     *
     * @return void
     */
    public function index (){
        global $_G,$aljtsq_post_goods;
        //�ֻ���ҳת��
        $mobile_index_banner = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljstg']['mobile_index_banner']));
        foreach($mobile_index_banner as $key=>$value){
            $arr=explode('|',$value);
            $mobile_index_banner_types[]=$arr;
        }
        
        //�ֻ���ҳͼ�굼��
        $mobile_index_nav = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljstg']['mobile_index_nav']));
        foreach($mobile_index_nav as $key=>$value){
            $arr=explode('|',$value);
            $mobile_index_nav_types[]=$arr;
        }
        $onetype = $this->onetype;
        $this->page->assign('onetype', $onetype);
        $this->page->assign('mobile_index_banner_types', $mobile_index_banner_types);
        $this->page->assign('mobile_index_nav_types', $mobile_index_nav_types);
        $this->page->assign('navtitle', $this->page->global->cache->plugin->aljstg->aljstg_name);
        $this->page->assign('metadescription', $_G['cache']['plugin']['aljstg']['description']);
        $this->page->display();
    }
    /**
     * ������
     *
     * @return void
     */
    public function newPeople (){
        global $_G,$aljtsq_post_goods;
        //������ת��
        $mobile_newpeople_banner = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljstg']['mobile_newpeople_banner']));
        foreach($mobile_newpeople_banner as $key=>$value){
            $arr=explode('|',$value);
            $mobile_newpeople_banner_types[]=$arr;
        }
        $onetype = $this->onetype;
        $this->page->assign('onetype', $onetype);
        $this->page->assign('mobile_newpeople_banner_types', $mobile_newpeople_banner_types);
        $this->page->assign('navtitle', lang('plugin/aljstg','aljstg_php_2'));
        $this->page->assign('metadescription', $_G['cache']['plugin']['aljstg']['description']);
        $this->page->display();
    }
    /**
     * 9.9����
     *
     * @return void
     */
    public function nineFreeShipping (){
        global $_G,$aljtsq_post_goods;
        //9.9����ת��
        $mobile_nine_banner = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljstg']['mobile_nine_banner']));
        foreach($mobile_nine_banner as $key=>$value){
            $arr=explode('|',$value);
            $mobile_nine_banner_types[]=$arr;
        }
        
        $onetype = $this->onetype;
        $this->page->assign('onetype', $onetype);
        $this->page->assign('mobile_nine_banner_types', $mobile_nine_banner_types);
        $this->page->assign('navtitle', '9.9'.lang('plugin/aljstg','aljstg_php_3'));
        $this->page->assign('metadescription', $_G['cache']['plugin']['aljstg']['description']);
        $this->page->display();
    }
    /**
     * ������
     *
     * @return void
     */
    public function hot (){
        global $_G,$aljtsq_post_goods;
        //����ת��
        $mobile_hot_banner = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljstg']['mobile_hot_banner']));
        foreach($mobile_hot_banner as $key=>$value){
            $arr=explode('|',$value);
            $mobile_hot_banner_types[]=$arr;
        }
        $onetype = $this->onetype;
        $this->page->assign('onetype', $onetype);
        $this->page->assign('mobile_hot_banner_types', $mobile_hot_banner_types);
        $this->page->assign('navtitle', lang('plugin/aljstg','aljstg_php_4'));
        $this->page->assign('metadescription', $_G['cache']['plugin']['aljstg']['description']);
        $this->page->display();
    }
    
    /**
     * �����Ƽ��Ź���Ʒ
     *
     * @return void
     */
    public function ptList (){
        global $aljtsq_post_goods;
        if($aljtsq_post_goods){
            $sql = ' AND store_id>0';
        }else{
            $sql = ' AND store_id=0';
        }
        
        $currpage=$this->page->get->page?$this->page->get->page:1;
        $perpage=5;
        $start=($currpage-1)*$perpage;
        $array = array('sh_status'=>0);
        if($_GET['t'] == 'newPeople'){
            $array = array('new_people'=>1);
        }
        if($_GET['t'] == 'nineFreeShipping'){
            $array = array('pt_nine'=>1);
        }
        if($_GET['t'] == 'hot'){
            $_GET['order'] = 'hot';
        }
        $bdlist=C::t('#aljbd#aljbd_goods')->fetch_all_by_status_new('',$start,$perpage,'',$_GET['type'],$_GET['subtype'],$_GET['region'],$_GET['subregion'],$_GET['order'],$_GET['kw'],$_GET['subtype3'],0,1,$array,$sql);

        foreach($bdlist as $k=>$v){
            $bdlist[$k]['price1']=skuminprice($v['attr_sku'],$v['commodity_type'],2)>0 ? skuminprice($v['attr_sku'],$v['commodity_type'],2) : floatval($v['price1']);
            if($_GET['t'] == 'newPeople'){
                $bdlist[$k]['price1']=skuminprice($v['attr_sku'],$v['commodity_type'],3)>0 ? skuminprice($v['attr_sku'],$v['commodity_type'],3) : floatval($v['new_price']);
            }
            $bdlist[$k]['pic1'] = $v['cover_image'] ? $v['cover_image'] : $v['pic1'];
            if($v['selling_point']){
                $selling_point = str_replace(lang("plugin/aljstg","aljstg_php_17"),',',$v['selling_point']);
                $bdlist[$k]['selling_point'] = explode(',',$selling_point);
            }
            if(TIMESTAMP < $v['endtime'] || TIMESTAMP < $v['starttime']){
                if(TIMESTAMP < $v['starttime']){
                    $bdlist[$k]['tg_time_title'] = lang('plugin/aljstg','aljstg_php_5').'<span class="endtime" value="'.$v['endtime'].'" date-val="0"></span>';
                    $v['tg_time_title'] = lang('plugin/aljstg','aljstg_php_5').'<span class="endtime" value="'.$v['endtime'].'" date-val="0"></span>';
                    $bdlist[$k]['tg_time_status'] = 1;
                    $v['tg_time_status'] = 1;
                } else {
                    $bdlist[$k]['tg_time_title'] = lang('plugin/aljstg','aljstg_php_6').':&nbsp;<span class="endtime" value="'.$v['endtime'].'" date-val="1"></span>';
                    $v['tg_time_title'] = lang('plugin/aljstg','aljstg_php_6').':&nbsp;<span class="endtime" value="'.$v['endtime'].'" date-val="1"></span>';
                }
            }else{
                if($v['endtime']<=0){
                    $bdlist[$k]['tg_time_title'] = lang('plugin/aljstg','aljstg_php_7').'<span class="endtime" value="'.$v['endtime'].'" date-val="0"></span>';
                    $v['tg_time_title'] = lang('plugin/aljstg','aljstg_php_7').'<span class="endtime" value="'.$v['endtime'].'" date-val="0"></span>';
                } else {
                    $bdlist[$k]['tg_time_status'] = 2;
                    $bdlist[$k]['tg_time_title'] = lang('plugin/aljstg','aljstg_php_8').'<span class="endtime" value="'.$v['endtime'].'" date-val="0"></span>';
                    $v['tg_time_title'] = lang('plugin/aljstg','aljstg_php_8').'<span class="endtime" value="'.$v['endtime'].'" date-val="0"></span>';
                    $v['tg_time_status'] = 2;
                }
            }
            if($v['amount']<=0){
                $bdlist[$k]['tg_time_status'] = 3; 
                $v['tg_time_status'] = 3;
            }
            if($_GET['t'] == 'nineFreeShipping'){
                if($bdlist[$k]['price1'] <= 9.9){
                    $v['price1'] = $bdlist[$k]['price1'];
                    $v['selling_point'] = $bdlist[$k]['selling_point'];
                    $pt_list[] = $v;
                }
            }
            
        }
        if($_GET['t'] == 'nineFreeShipping'){
            $bdlist = $pt_list;
        }
        if($this->page->get->m == 'index'){
            $array = array();
            if($bdlist){
                $array['bdlist'] = $bdlist;
            }else{
                $array['bdlist'] = 1;
            }
            if($_GET['type'] > 0){
                if($aljtsq_post_goods){
                    $type = C::t('#aljtsc#aljtsc_type')->fetch_all_by_upid($_GET['type']);
                }else{
                    $type = C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid_orderkey($_GET['type']);
                }
            }
            if($type){
                $array['type'] = $type;
            }else{
                $array['type'] = 1;
            }
            echo json_encode(T::ajaxPostCharSet($array));
        }else{
            if($bdlist){
                echo json_encode(T::ajaxPostCharSet($bdlist));
            }else{
                echo '1';
            }
        }
        exit;
    }
    /**
     * Ʒ���̼ҹ�������ע��
     *
     *
     * @return void
     */
    public function aljbdParameter(){
        global $Html5Plusapp,$immersed,$newscount;
        $settings=C::t('#aljbd#aljbd_setting')->range();
        $mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_common_footernav']['value']));
        foreach($mobile_common_footernav as $key=>$value){
            $arr=explode('|',$value);
            $mobile_common_footernav_arr[]=$arr;
        }
        $price_unit = '&#65509;';
        $this->page->assign('price_unit', $price_unit,true);
        $this->page->assign('pluginid', 'aljbd');
        $this->page->assign('newscount', $newscount);
        $this->page->assign('Html5Plusapp', $Html5Plusapp);
        $this->page->assign('immersed', $immersed);
        $this->page->assign('settings', $settings);
        $this->page->assign('mobile_common_footernav_arr', $mobile_common_footernav_arr,true);
        $this->page->assign('common_template_pluginid', 'aljbd');
        $this->page->assign('common_path', 'source/plugin/aljhtx');
    }
}

