<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `get_to_the_shop` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `get_to_the_shop` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljbd_write_off_code` (
`password` bigint(12) NOT NULL,
  `orderid` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `shop_id` int(10) NOT NULL,
  `goods_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `endtime` int(10) NOT NULL,
  `status` int(10) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `reason` varchar(255) NOT NULL,
  PRIMARY KEY (`password`),
  KEY `orderid` (`orderid`),
  KEY `password` (`password`)
)
EOF;
runquery($sql);
//�ҵ�ҳ���̼����� �Ź�����
$mobile_user_business_center = C::t('#aljbd#aljbd_setting')->fetch('mobile_user_business_center');
if($mobile_user_business_center){
    $mobile_user_business_center['value'] .= '
source/plugin/aljht/static/img/aljbd/user/hexiao.png|plugin.php?id=aljstg&c=writeOff&a=wirteOffList&mobile=2|&#26680;&#38144;&#20837;&#21475;';
    C::t('#aljbd#aljbd_setting')->update_value_by_key($mobile_user_business_center['value'],'mobile_user_business_center');
}
//��ҳͼ�Ĺ�� �Ź�
$mobile_index_Photo_Ads = C::t('#aljbd#aljbd_setting')->fetch('mobile_index_Photo_Ads');
if($mobile_index_Photo_Ads){
    $mobile_index_Photo_Ads['value'] .= '
&#22242;&#36141;|&#38480;&#26102;&#31186;&#26432;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_tg.png|#';
    C::t('#aljbd#aljbd_setting')->update_value_by_key($mobile_index_Photo_Ads['value'],'mobile_index_Photo_Ads');
}
//finish to put your own code
$finish = TRUE;
?>
