<?php
/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ��ϵQQ: DISM.TAOBAO.COM
 * ����˵��:MAPP΢�ź��Ӻ������
 */

if (!defined('IN_MAPP_API')) {
    exit('Access Denied');
}

global $_G;
$mapp_wechat_config = $_G['cache']['plugin']['mapp_wechat'];
if (($postObj['type'] == 'event' && $postObj['event'] == 'scan') || ($postObj['event'] == 'subscribe' && intval($postObj['key']))) {
	$scene_id = $postObj['key'];
	$checkopenid = DB::fetch_first('SELECT * FROM %t WHERE openid=%s and uid>0', array('aljwsq_mapp_user', $postObj['from']));
    require_once DISCUZ_ROOT . './source/plugin/aljwsq/function_core.php';
    require_once DISCUZ_ROOT . './source/plugin/aljwsq/mapp_wechatclient.lib.class.php';
    $aljwsq_config = array();
    $plugin_aljwsq = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljwsq'));
    $tmp_aljwsq_config = DB::fetch_all('select * from %t where  pluginid = %s',array('common_pluginvar',$plugin_aljwsq['pluginid']));
    foreach($tmp_aljwsq_config as $value){
        $aljwsq_config[$value['variable']] = $value['value'];
    }
    $wechat_client = new WeChatClient($aljwsq_config['appid'], $aljwsq_config['appsecret']);
    $wuser = $wechat_client -> getUserInfoById($postObj['from']);


	//appbyme
	$is_plugin = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','appbyme_app'));
    $is_magmobileapi = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','magmobileapi'));
	if($is_plugin){
		if($wuser['unionid']){
			$appbymeuser = DB::fetch_first("select * from %t where param=%s and param!=''",array('appbyme_connection',$wuser['unionid']));
		}
	}

    if($is_magmobileapi){
        if($wuser['unionid']){
            $mag_user = DB::fetch_first("select * from %t where unionid=%s and unionid!=''",array('user_weixin_relations', $wuser['unionid']));
            if($mag_user['userid']){
                $mag_user['uid'] = $mag_user['userid'];
            }
        }
    }

	//appbyme
	if(strlen($scene_id) == 9){
		$binduid = DB::result_first('select uid from %t where scene_id = %d',array('aljwsq_mapp_wechat_scene',$scene_id));
		$user = DB::fetch_first('SELECT * FROM %t WHERE uid=%s', array('common_member', $binduid));
        if(function_exists('qianfan_login')) {
            qianfan_login($user, $wuser);
        }
		if($binduid && $user){
			$checkuid = DB::fetch_first('SELECT * FROM %t WHERE uid=%s', array('aljwsq_mapp_user', $binduid));
			$checkwxbind = DB::result_first('SELECT count(*) FROM %t WHERE openid=%s and uid>0', array('aljwsq_mapp_user', $postObj['from']));
			if (!$checkuid && $user && !$checkwxbind) {
				$checkopenid = DB::fetch_first('SELECT * FROM %t WHERE openid=%s', array('aljwsq_mapp_user', $postObj['from']));

				//appbyme
				if($is_plugin){
					$appbymeuser = DB::fetch_first('select * from %t where uid=%d',array('appbyme_connection',$binduid));
					if($appbymeuser){
						if(empty($appbymeuser['unionid'])){
							DB::query('update %t set param=%s where uid=%d',array('appbyme_connection',$wuser['unionid'],$binduid));
						}
					}else{
						DB::query('INSERT INTO ' . DB::table('appbyme_connection') . " (uid,openid,status,type,param)values(" . $binduid . ",'',1,1,'" . $wuser['unionid'] . "') ");
					}
				}
				if($is_magmobileapi){
                    $mag_user = DB::fetch_first('select * from %t where userid=%d',array('user_weixin_relations',$binduid));
                    if($mag_user['userid']){
                        $mag_user['uid'] = $mag_user['userid'];
                    }
                    if($mag_user['uid']){
                        if(empty($mag_user['unionid'])){
                            DB::query('update %t set unionid=%s where userid=%d',array('user_weixin_relations',$wuser['unionid'],$binduid));
                        }
                    }else{
                    	DB::insert('user_weixin_relations', array(
                    		'userid' => $user['uid'],
                            'name' => $user['username'],
                            'unionid' => $wuser['unionid'],
                            'create_time' => TIMESTAMP,
                            'openid' => '',
						));
                    }
				}
				//appbyme
				if($checkopenid){
					C::t('#aljwsq#aljwsq_mapp_user')->update($postObj['from'], array(
						'username' => $user['username'],
						'uid' => $binduid,
						'bindtime' => TIMESTAMP,
						'lasttime' => TIMESTAMP,
            			'unionid' =>$wuser['unionid'],
                        'subscribe_time' => $wuser['subscribe_time'],
					));
				}else{
					C::t('#aljwsq#aljwsq_mapp_user')->insert(array(
						'uid' => $binduid,
						'username' => $user['username'],
						'openid' => $postObj['from'],
						'bindtime' => TIMESTAMP,
						'subscribe_time' => $wuser['subscribe_time'],
						'lasttime' => TIMESTAMP,
            			'unionid' =>$wuser['unionid']
					));
				}
				$mapp_wechat_config['bstips'] = str_replace('{username}',$user['username'],$mapp_wechat_config['bstips']);
				sendbindextcredit($user['uid']);

				echo self::getXml4Txt($mapp_wechat_config['bstips']);
				exit;
			}else{
                C::t('#aljwsq#aljwsq_mapp_user')->update($postObj['from'], array(
                    'username' => $user['username'],
                    'uid' => $binduid,
                    'lasttime' => TIMESTAMP,
                    'unionid' =>$wuser['unionid'],
                    'subscribe_time' => $wuser['subscribe_time'],
                ));
                $mapp_wechat_config['bstips'] = str_replace('{username}',$user['username'],$mapp_wechat_config['bstips']);
				echo self::getXml4Txt($mapp_wechat_config['bstips']);
				exit;
			}
		}else{
            if(function_exists('qianfan_login')) {
                $user = qianfan_login('', $wuser);
            }
			if($checkopenid || $appbymeuser['uid'] || $mag_user['uid'] || $user){
				if($checkopenid){
					$uid = $checkopenid['uid'];
                    if(function_exists('qianfan_login')) {
                        qianfan_login(getuserbyuid($uid), $wuser);
                    }
                    //appbyme
                    if($is_plugin){
                        $appbymeuser = DB::fetch_first('select * from %t where uid=%d',array('appbyme_connection',$binduid));
                        if($appbymeuser){
                            if(empty($appbymeuser['unionid'])){
                                DB::query('update %t set param=%s where uid=%d',array('appbyme_connection',$wuser['unionid'],$binduid));
                            }
                        }else{
                            DB::query('INSERT INTO ' . DB::table('appbyme_connection') . " (uid,openid,status,type,param)values(" . $binduid . ",'',1,1,'" . $wuser['unionid'] . "') ");
                        }
                    }
                    if($is_magmobileapi){
                        $mag_user = DB::fetch_first('select * from %t where userid=%d',array('user_weixin_relations',$binduid));
                        if($mag_user['userid']){
                            $mag_user['uid'] = $mag_user['userid'];
                        }
                        if($mag_user['uid']){
                            if(empty($mag_user['unionid'])){
                                DB::query('update %t set unionid=%s where userid=%d',array('user_weixin_relations',$wuser['unionid'],$checkopenid['uid']));
                            }
                        }else{
                            DB::insert('user_weixin_relations', array(
                                'userid' => $checkopenid['uid'],
                                'name' => $checkopenid['username'],
                                'unionid' => $wuser['unionid'],
                                'create_time' => TIMESTAMP,
                                'openid' => '',
                            ));
                        }
                    }
                    //appbyme
				}else{
					if($mag_user['uid']){
                        $uid = $mag_user['uid'];
					}elseif ($user){
                        $uid = $user['uid'];
					}else{
                        $uid = $appbymeuser['uid'];
					}
					$forumuser = C::t('common_member') -> fetch($uid);
					$checkopenid = DB::fetch_first('SELECT * FROM %t WHERE openid=%s', array('aljwsq_mapp_user', $postObj['from']));

					if($checkopenid){
						C::t('#aljwsq#aljwsq_mapp_user')->update($postObj['from'], array(
							'username' => $forumuser['username'],
							'uid' => $forumuser['uid'],
							'bindtime' => TIMESTAMP,
                            'subscribe_time' => $wuser['subscribe_time'],
              				'unionid' =>$wuser['unionid']
						));
					}else{
						C::t('#aljwsq#aljwsq_mapp_user')->insert(array(
							'uid' => $forumuser['uid'],
							'username' => $forumuser['username'],
							'openid' => $postObj['from'],
							'bindtime' => TIMESTAMP,
                            'subscribe_time' => $wuser['subscribe_time'],
							'lasttime' => TIMESTAMP,
              				'unionid' =>$wuser['unionid']
						));
					}
				}
				DB::query('update %t set status = 1,openid=%s,uid=%d where scene_id = %d',array('aljwsq_mapp_wechat_scene',$postObj['from'],$uid,$scene_id));
				echo self::getXml4Txt($mapp_wechat_config['stips']);
				exit;
			}else{
				if($_G['cache']['plugin']['mapp_wechat']['close_register']){
                    echo  self::getXml4Txt($_G['cache']['plugin']['mapp_wechat']['close_register_tips']);
                    exit;
				}
				require_once libfile('function/member');
				loaducenter();
				$wxuser = lgetwuserinfo($postObj['from']);
				if($wxuser['nickname']){
					if(function_exists('removeEmoji')) {
                        $wxuser['nickname'] = removeEmoji($wxuser['nickname']);
                    }
                    if(strtolower(CHARSET) == 'gbk'){
                        $nickname = diconv($wxuser['nickname'],'UTF-8','GBK');
                    }else{
                        $nickname = $wxuser['nickname'];
                    }
                    $nickname = preg_replace('/\d+/', '', $nickname);
                    $nickname = preg_replace('# #','',$nickname);
				}

				if($nickname){
					$usernamelen = dstrlen($nickname);
					if($usernamelen < 4 || uc_user_checkname($nickname)<0) {
						$username = random(6);
					}else{
						$username = cutstr($nickname,14,'');
					}
				}else{
					$username = random(6);
				}
				while(DB::result_first('select count(*) from %t where username = %s',array('common_member',$username))){
					$username = random(6);
				}
				$defaultpassword = 'PW'.random(6);
				$group['fid'] = $mapp_wechat_config['reggroup'];
				$return = lwechat_register($username,'',$mapp_wechat_config['reggroup'],$defaultpassword,$group);
				if(!is_array($return)){
					echo  self::getXml4Txt($return);
					exit;
				}
				$tpl = str_replace('{username}',$return['username'],$mapp_wechat_config['rstips']);
				$tpl = str_replace('{password}',$return['password'],$tpl);
				$user = DB::fetch_first('select * from %t where username = %s',array('common_member',$return['username']));
				if($wxuser['headimgurl']){
					lcreate_avatar($user['uid'],$wxuser['headimgurl']);
				}
				$checkopenid = DB::fetch_first('SELECT * FROM %t WHERE openid=%s', array('aljwsq_mapp_user', $postObj['from']));
				//appbyme
				if($is_plugin){
					$appbymeuser = DB::fetch_first('select * from %t where uid=%d',array('appbyme_connection',$user['uid']));
					if($appbymeuser['uid']){
						if(empty($appbymeuser['unionid'])){
							DB::query('update %t set param=%s where uid=%d',array('appbyme_connection',$wuser['unionid'],$user['uid']));
						}
					}else{
						if($user['uid']){
							DB::query('INSERT INTO ' . DB::table('appbyme_connection') . " (uid,openid,status,type,param)values(" . $user['uid'] . ",'',1,1,'" . $wuser['unionid'] . "') ");
						}
					}
				}

                if($is_magmobileapi){
                    $mag_user = DB::fetch_first('select * from %t where userid=%d',array('user_weixin_relations',$user['uid']));
                    if($mag_user['userid']){
                        $mag_user['uid'] = $mag_user['userid'];
                    }
                    if($mag_user['userid']){
                        if(empty($mag_user['unionid'])){
                            DB::query('update %t set unionid=%s where userid=%d',array('user_weixin_relations',$wuser['unionid'],$user['uid']));
                        }
                    }else{
                        if($user['uid']) {
                            DB::insert('user_weixin_relations', array(
                                'userid' => $user['uid'],
                                'name' => $user['username'],
                                'unionid' => $wuser['unionid'],
                                'create_time' => TIMESTAMP,
                                'openid' => '',
                            ));
                        }
                    }
                }
				//appbyme
				if($checkopenid){
					C::t('#aljwsq#aljwsq_mapp_user')->update($postObj['from'], array(
						'username' => $return['username'],
						'uid' => $user['uid'],
						'bindtime' => TIMESTAMP,
                        'subscribe_time' => $wuser['subscribe_time'],
            			'unionid' =>$wuser['unionid']
					));
				}else{
					C::t('#aljwsq#aljwsq_mapp_user')->insert(array(
						'uid' => $user['uid'],
						'username' => $return['username'],
						'openid' => $postObj['from'],
						'bindtime' => TIMESTAMP,
                        'subscribe_time' => $wuser['subscribe_time'],
						'lasttime' => TIMESTAMP,
            			'unionid' =>$wuser['unionid']
					));
				}
                if(function_exists('qianfan_login')) {
                    qianfan_login($user, $wuser);
                }
				DB::query('update %t set status = 1,openid=%s,uid=%d where scene_id = %d',array('aljwsq_mapp_wechat_scene',$postObj['from'],$user['uid'],$scene_id));
				sendbindextcredit($user['uid']);

				echo self::getXml4Txt($tpl);
				exit;
			}
		}

	}
}
?>
