<?php

/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 */

if (! defined ('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit ('Access Denied');
}

$aljwsq_config = array();
$plugin_aljwsq = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljwsq'));
$tmp_aljwsq_config = DB::fetch_all('select * from %t where  pluginid = %s',array('common_pluginvar',$plugin_aljwsq['pluginid']));

foreach($tmp_aljwsq_config as $value){
	$aljwsq_config[$value['variable']] = $value['value'];
}

echo '&#24494;&#20449;&#25480;&#26435;&#85;&#82;&#76;&#21482;&#25903;&#25345;&#35748;&#35777;&#30340;&#26381;&#21153;&#21495;&#21644;&#37096;&#20998;&#35746;&#38405;&#21495;&#65292;&#24744;&#21487;&#20197;&#21040;&#20844;&#20247;&#21495;&#24320;&#21457;&#32773;&#20013;&#24515;&#30830;&#35748;&#33258;&#24049;&#30340;&#20844;&#20247;&#21495;&#26159;&#21542;&#25317;&#26377;&#34;&#32593;&#39029;&#25480;&#26435;&#33719;&#21462;&#29992;&#25143;&#22522;&#26412;&#20449;&#24687;&#34;&#30340;&#26435;&#38480;';
	echo '<br><br>'."<b>&#33258;&#21160;&#30331;&#24405;&#25480;&#25509;&#65306;</b>https://open.weixin.qq.com/connect/oauth2/authorize?appid=".$aljwsq_config['appid']."&redirect_uri=".$_G['siteurl']."plugin.php?id=mapp_wechat:logging&scope=snsapi_userinfo&state=1#wechat_redirect".'<br>';
	debug("<b>&#32465;&#23450;&#35770;&#22363;&#24080;&#21495;&#65306;</b>https://open.weixin.qq.com/connect/oauth2/authorize?appid=".$aljwsq_config['appid']."&redirect_uri=".$_G['siteurl']."plugin.php?id=mapp_wechat&scope=snsapi_userinfo&state=1#wechat_redirect");
?>