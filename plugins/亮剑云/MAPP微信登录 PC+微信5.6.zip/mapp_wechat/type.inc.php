<?php

/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if ($_GET['kid']) {
    $reply = C::t('#mapp_wechat#aljwsq_mapp_wechat_keyword')->fetch($_GET['kid']);
}

if($_GET['upid']){
	$upid = intval($_GET['upid']);
	$news = C::t('#mapp_wechat#aljwsq_mapp_wechat_keyword') -> fetch($upid);
	$newslist = DB::fetch_all('select * from %t where upid=%d and id!=%d order by displayorder desc',array('aljwsq_mapp_wechat_keyword',$upid,$_GET['kid']));
}
include template('mapp_wechat:text');

