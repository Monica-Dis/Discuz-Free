<?php

/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ��ϵQQ: DISM.TAOBAO.COM
 * ����˵��:MAPP΢�ź��Ӻ���API
 */

function mapp_wechat($postObj){
	global $_G;
	$mapp_wechat_config = $_G['cache']['plugin']['mapp_wechat'];
	$config = array();
	$plugin_aljwsq = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','mapp_wechat'));
	$tmp_aljwsq_config = DB::fetch_all('select * from %t where  pluginid = %s',array('common_pluginvar',$plugin_aljwsq['pluginid']));

	foreach($tmp_aljwsq_config as $value){
		$config[$value['variable']] = $value['value'];
	}
	$_G['defaultpic'] = $_G[siteurl].'source/plugin/mapp_wechat/images/default.jpg';
	$content = trim($postObj['content']);
	$news = DB::fetch_first('select * from %t where mykeyword = %s and status>0 order by displayorder desc',array('aljwsq_mapp_wechat_keyword',$content));
	//return  mappapi::getXml4Txt($news['mykeyword']);
	if($news['threadnum']>9 || empty($news['threadnum'])){
		$news['threadnum'] = 9;
	}
	if($news['type'] == 'bind'){
		$checkopenid = DB::fetch_first('SELECT * FROM %t WHERE openid=%s and uid>0', array('aljwsq_mapp_user', $postObj['from']));
		if($checkopenid){
			return mappapi::getXml4Txt($mapp_wechat_config['bftips']);
		}
		$items = DB::fetch_all('select * from %t where upid = %d',array('aljwsq_mapp_wechat_keyword',$news['id']));
		if($items){
			foreach($items as $k => $item){
				if($item){
					$items[$k]['picurl'] = $_G['siteurl'].$item['picurl'];
				}
			}
		}
		if($news['picurl']){
			$news['picurl'] = $_G['siteurl'].$news['picurl'];
		}
		if($news['url']){
			$news['url'] = $_G['siteurl'].$news['url'].'&dateline='.TIMESTAMP.'&openid='.$postObj['from'];
		}
		$items[] = $news;
		$items = array_reverse($items);
	}else if($news['type'] == 'unbind'){
		$is_plugin = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','appbyme_app'));
		if($is_plugin){
			require_once DISCUZ_ROOT . './source/plugin/aljwsq/mapp_wechatclient.lib.class.php';
			$aljwsq_config = array();
			$plugin_aljwsq = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljwsq'));
			$tmp_aljwsq_config = DB::fetch_all('select * from %t where  pluginid = %s',array('common_pluginvar',$plugin_aljwsq['pluginid']));
			foreach($tmp_aljwsq_config as $value){
				$aljwsq_config[$value['variable']] = $value['value'];
			}
			$wechat_client = new WeChatClient($aljwsq_config['appid'], $aljwsq_config['appsecret']);
			$wuser = $wechat_client -> getUserInfoById($postObj['from']);
			$appbymeuser = DB::fetch_first('select * from %t where param=%s',array('appbyme_connection',$wuser['unionid']));
			if($appbymeuser){
				DB::query('delete from %t where param=%s',array('appbyme_connection',$wuser['unionid']));
			}
		}
		$user=DB::fetch_first('SELECT * FROM %t WHERE openid=%s and uid>0', array('aljwsq_mapp_user', $postObj['from']));
		if($user){
			DB::query('delete FROM %t WHERE openid=%s', array('aljwsq_mapp_user', $postObj['from']));
			include_once 'source/function/function_member.php';
			clearcookies();
			return  mappapi::getXml4Txt($news['title']);
		}else{
			return  mappapi::getXml4Txt($news['description']);
			//echo $this->responsetext($postObj, $user['openid'].'123');
		}
	}else if($news['type'] == 'logging'){
		$param['openid']=$postObj['from'];
		$param['key']=$config['key'];
		$param['dateline']=TIMESTAMP;
		$params = '';
		foreach($param as $k => $v) {
		$params .= '&'.$k.'='.rawurlencode($v);
		}
		$md5hash = md5(substr($params, 1).$config['key']);

		$news['url'] = $_G['siteurl'].$news['url'].'&goto='.$news['id'].$params.'&hash='.$md5hash;
		$news['description'] = $news['description'] . '<a href="' .$news['url']. '">' . $news['title'] . '</a>';
		return  mappapi::getXml4Txt($news['description']);
	}
	if($items){
		DB::query("update %t set resnum=resnum+1 where mykeyword=%s",array('aljwsq_mapp_wechat_keyword',$content));
		if($postObj['getdata']){
			return  $items;
		}else{
			return  mappapi::getXml4RichMsgByArray2($items);
		}
		
		//return  mappapi::getXml4Txt($news['fid']);
	}else{
		return false;
	}
}
//From: d'.'is'.'m.ta'.'obao.com
?>