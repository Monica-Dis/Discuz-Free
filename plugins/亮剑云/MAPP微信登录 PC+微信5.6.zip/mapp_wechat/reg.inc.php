<?php

/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


echo "<script language='javascript'>";
echo "window.location.href='".ADMINSCRIPT."?action=plugins&operation=config&identifier=aljwsq&pmod=reg&appid=".$_GET['identifier']."'";
echo "</script>";
exit;
?>