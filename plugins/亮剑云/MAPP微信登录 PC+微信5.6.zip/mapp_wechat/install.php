<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljwsq_mapp_wechat_keyword` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `upid` int(10) NOT NULL,
  `mykeyword` varchar(255) NOT NULL,
  `bindkeyword` varchar(255) NOT NULL,
  `type` char(50) NOT NULL,
  `msgtype` char(50) NOT NULL,
  `returnmsgtype` char(50) NOT NULL,
  `event` char(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `fid` int(10) NOT NULL,
  `tid` int(10) NOT NULL,
  `forumnum` int(10) NOT NULL,
  `threadnum` int(10) NOT NULL,
  `picurl` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `addline` int(10) NOT NULL,
  `updatetime` int(10) NOT NULL,
  `resnum` int(10) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `displayorder` int(10) NOT NULL,
  `description` varchar(255) NOT NULL,
  `massmessage` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljwsq_mapp_wechat_scene` (
  `scene_id` bigint(20) NOT NULL,
  `dateline` int(10) NOT NULL,
  `status` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `expire_seconds` int(10) NOT NULL,
  `openid` varchar(255) NOT NULL,
  PRIMARY KEY (`scene_id`)
);
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>