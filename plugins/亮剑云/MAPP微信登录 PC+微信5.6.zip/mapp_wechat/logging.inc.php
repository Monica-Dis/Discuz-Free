<?php

/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Deined');
}

$config = $_G['cache']['plugin']['mapp_wechat'];
$aljwsq_config=$_G['cache']['plugin']['aljwsq'];
require_once DISCUZ_ROOT . './source/plugin/aljwsq/mapp_wechatclient.lib.class.php';
$wechat_client = new WeChatClient($aljwsq_config['appid'], $aljwsq_config['appsecret']);
$code = addslashes($_GET['code']);
if($config['key'] && !$code){
	$openid = addslashes($_GET['openid']);
	$param['openid']=(string)$openid;
	$param['key']=$config['key'];
	$param['dateline']=intval($_GET['dateline']);
	if($param['dateline']+300<TIMESTAMP){
		showmessage('&#35831;&#27714;&#19981;&#21512;&#27861;&#65292;&#38142;&#25509;&#24050;&#36807;&#26399;&#65281;');
	}
	$params = '';
	foreach($param as $k => $v) {
	$params .= '&'.$k.'='.rawurlencode($v);
	}
	$md5hash = md5(substr($params, 1).$config['key']);
	if($md5hash!=$_GET['hash']){
		showmessage('&#35831;&#27714;&#21442;&#25968;&#19981;&#23436;&#25972;&#65281;');
	}
}

if($config['enabled']){
	if($code && $aljwsq_config['appid'] && $aljwsq_config['appsecret']){
		$tokentime = getcookie('tokentime');
		$openid = getcookie('openid');
		if(getcookie('token123') && $openid && TIMESTAMP - $tokentime<7200){
			$access_token = getcookie('token123');
			$openid = getcookie('openid');
		}else{
			$url="https://api.weixin.qq.com/sns/oauth2/access_token?appid=".$aljwsq_config['appid']."&secret=".$aljwsq_config['appsecret']."&code=$code&grant_type=authorization_code";
			$result = WeChatClient :: get($url);
			$jsoninfo = json_decode($result, true);
			$access_token = $jsoninfo["access_token"];
			$openid = $jsoninfo["openid"];
			dsetcookie('token123',$access_token);
			dsetcookie('openid',$openid);
			dsetcookie('tokentime',TIMESTAMP);
		}
	}
}

//debug($openid);
if ($openid) {
	$binduser = C::t('#aljwsq#aljwsq_mapp_user')->fetch($openid);
	if ($binduser['username']) {
		$user = C::t('common_member')->fetch_by_username($binduser['username']);
		require_once libfile('function/member');
		setloginstatus($user, 2592000);
	}else{
		$param['openid']=$openid;
		$param['key']=$config['key'];
		$param['dateline']=TIMESTAMP;
		$params = '';
		foreach($param as $k => $v) {
		$params .= '&'.$k.'='.rawurlencode($v);
		}
		$md5hash = md5(substr($params, 1).$config['key']);
		//debug($_G['siteurl'].'plugin.php?id=mapp_wechat&openid='.$openid.'&dateline='.$param['dateline'].'&hash='.$md5hash);
		header('Location: '.$_G['siteurl'].'plugin.php?id=mapp_wechat&openid='.$openid.'&dateline='.$param['dateline'].'&hash='.$md5hash);
		exit;
	}
}
if($_GET['goto']){
	$news = DB::fetch_first('select * from %t where id = %d and status>0 order by displayorder desc',array('aljwsq_mapp_wechat_keyword',$_GET['goto']));
}else{
	$news = DB::fetch_first('select * from %t where type = %s and status>0 order by displayorder desc',array('aljwsq_mapp_wechat_keyword','logging'));
}

if($news['bindkeyword']){	
	if(strpos($news['bindkeyword'],'http') !== false){
		$news['bindkeyword'] = $news['bindkeyword'];
	}else{
		$news['bindkeyword'] = $_G['siteurl'].$news['bindkeyword'];
	}
}

$news['bindkeyword'] = $news['bindkeyword']?$news['bindkeyword']:$_G['siteurl'].'forum.php';
header('Location: '.htmlspecialchars($news['bindkeyword']));		
?>