<?php

/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 */


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_mapp_wechat{
	function common(){
		global $_G;
		if($_GET['mod'] == 'register' && !submitcheck('formhash') && $_G['cache']['plugin']['mapp_wechat']['goregister'] && $_GET['from'] != 'wechat'){
			header('Location: plugin.php?id=mapp_wechat:m&act=qrcode');
		}
	}
	function global_usernav_extra1() {
		global $_G;
		require_once 'source/plugin/aljwsq/function_core.php';
		if($_G['uid']){
			if(!DB::result_first('SELECT count(*) FROM %t WHERE uid=%d', array('aljwsq_mapp_user', $_G['uid']))){
				return '<span class="pipe">|</span><a href="plugin.php?id=mapp_wechat:m&act=qrcode&op=bind" onclick="showWindow(\'bindaccount\',this.href);"><img src="source/plugin/mapp_wechat/images/wechat_bind.png" class="qq_bind" align="absmiddle" /></a>';
			}else{
				if(!lgetuseraction($_G['uid'],'mapp_wechat','changeusername') && lgetuseraction($_G['uid'],'mapp_wechat','register')){
					return '<span class="pipe">|</span><a href="plugin.php?id=mapp_wechat:m&act=wechatsetting" onclick="showWindow(\'bindaccount\',this.href);" style="color:red;">&#20462;&#25913;&#29992;&#25143;&#21517;</a>';
				}
			}
		}
	}
	function global_footer(){
		global $_G;
		$mapp_wechat = unserialize($_G['setting']['mapp_wechat']);
		if($mapp_wechat['addqrcodeurl'] && !DB::result_first('SELECT count(*) FROM %t WHERE uid=%d and uid>0', array('aljwsq_mapp_user', $_G['uid'])) && !getcookie('wechatfqrc')){
			include template('mapp_wechat:floatqrcode');
		}
		$ucsynlogin = '';
		if($_G['setting']['allowsynlogin']) {
			if(!($member = getuserbyuid($_G['uid'], 1))) {
				//return false;
			} else {
				if(isset($member['_inarchive'])) {
					C::t('common_member_archive')->move_to_master($member['uid']);
				}
			}
			loaducenter();
			$ucsynlogin = uc_user_synlogin($_G['uid']);
		}
		return $ucsynlogin.$return;

	}
	function global_login_extra() {
		include template('mapp_wechat:wechat');
		return $return;
	}
	/**������ʾ΢�ŵ�¼��ť**/
	function global_login_text() {
		global $_G;
		return '&nbsp;<a rel="nofollow" target="_top" href="plugin.php?id=mapp_wechat:m&act=qrcode"><img class="vm" src="source/plugin/mapp_wechat/images/wechat_login.png"></a>';
	}
}
class plugin_mapp_wechat_member extends plugin_mapp_wechat{
	/**��¼ҳ��ʾ��¼��ť**/
	function logging_method(){
		global $_G;
		return '<a rel="nofollow" target="_top" href="plugin.php?id=mapp_wechat:m&act=qrcode"><img class="vm" src="source/plugin/mapp_wechat/images/wechat_login.png"></a>';

	}
	/**ע��ҳ��ʾ��¼��ť**/
	function register_logging_method(){
		return '<a rel="nofollow" target="_top" href="plugin.php?id=mapp_wechat:m&act=qrcode"><img class="vm" src="source/plugin/mapp_wechat/images/wechat_login.png"></a>';
	}
}
class plugin_mapp_wechat_forum extends plugin_mapp_wechat {
	/**��̳�����ٷ�������ʾ΢�ŵ�¼**/
	function global_login_text(){
		return '&nbsp;<a rel="nofollow" target="_top" href="plugin.php?id=mapp_wechat:m&act=qrcode"><img class="vm" src="source/plugin/mapp_wechat/images/wechat_login.png"></a>';
	}
	function viewthread_sidetop_output() {
		global $_G,$postlist;
		foreach($postlist as $pk => $post){
			$checkbind = DB::result_first('SELECT count(*) FROM %t WHERE uid=%d', array('aljwsq_mapp_user',$post['authorid']));
			if($checkbind){
				$postlist[$pk]['author'] = $post['author'].'&nbsp;<img src="source/plugin/mapp_wechat/images/wechatmedal.png" class="vm" alt="&#31038;&#21306;&#24494;&#20449;&#36798;&#20154;" title="&#31038;&#21306;&#24494;&#20449;&#36798;&#20154;">';
			}else{
				$postlist[$pk]['author'] = $post['author'].'&nbsp;<img src="source/plugin/mapp_wechat/images/defaultwechatmedal.png" class="vm" alt="&#26410;&#32465;&#23450;&#24494;&#20449;" title="&#26410;&#32465;&#23450;&#24494;&#20449;">';
			}
		}
	}
}
//From: d'.'is'.'m.ta'.'obao.com
?>