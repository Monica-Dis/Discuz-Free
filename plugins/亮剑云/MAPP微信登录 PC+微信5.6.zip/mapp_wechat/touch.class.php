<?php

/*
 * ����: �����������缼�����޹�˾����Discuz!�����Ŷ�
 * ����֧��: http://t.cn/Aiux1Jx1
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Deined');
}

class mobileplugin_mapp_wechat {

    function index_top_mobile() {
        global $_G;
    }

    function common() {
		global $_G;
        $referer = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'].($_SERVER['QUERY_STRING'] ? '?'.$_SERVER['QUERY_STRING'] : '') : dreferer();
        $referer = urlencode($referer ? $referer : 'index.php');
        $mapp_wechat = unserialize($_G['setting']['mapp_wechat']);
        $wxurl = $mapp_wechat['wxurl']?rtrim(trim($mapp_wechat['wxurl']), '/').'/':$_G['siteurl'];
        //fxid
        if($_GET['d']>0){
            dsetcookie('duid', intval($_GET['d']), 86400);
        }
        if(isset($_SERVER["HTTP_X_REQUESTED_WITH"]) && strtolower($_SERVER["HTTP_X_REQUESTED_WITH"])=="xmlhttprequest"){
            // ajax ����Ĵ�����ʽ
        }else {
            // ��������Ĵ�����ʽ
            if (empty($_G['uid']) && $_GET['mod'] == 'register' && !$_G['cache']['plugin']['mapp_wechat']['close_register'] && $_G['cache']['plugin']['mapp_wechat']['goregister'] && $_GET['from'] != 'wechat' && (!$_GET['ajax'] || ($_GET['ajax']=='yes' && $_GET['id'] == 'aljdiy'))) {
                if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false && !$_G['uid'] && !$_G['inajax'] && $_GET['action'] != 'logout') {
                    dsetcookie('mapp_referer', $referer,120);
                    header('location:  '.$wxurl.'/plugin.php?id=mapp_wechat:m&act=wechatlogin&referer=' . $referer);
                }
            }
            if (empty($_G['uid']) && !$_G['cache']['plugin']['mapp_wechat']['close_register'] && (!$_GET['ajax'] || ($_GET['ajax']=='yes' && $_GET['id'] == 'aljdiy'))) {
                if (($_G['cache']['plugin']['mapp_wechat']['fast_login'] && ($_G['mod'] == 'logging' || $_GET['id'] == 'aljlogin')) || ($_G['cache']['plugin']['mapp_wechat']['global_login'] && $_GET['act'] != 'wechatlogin' && $_GET['id'] != 'mapp_wechat')) {
                    if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false && !$_G['uid'] && $_GET['action'] != 'logout' && !$_G['inajax'] && $_GET['act'] != 'paymoney') {

                        if (getcookie('wechat_openid')) {
                            $binduser = DB::fetch_first('SELECT * FROM %t WHERE openid=%s and uid>0', array('aljwsq_mapp_user', getcookie('wechat_openid')));
                        }
                        
                        if (($binduser['last_logintime'] + $_G['cache']['plugin']['mapp_wechat']['switch_time'] < TIMESTAMP)) {
                            dsetcookie('mapp_referer', $referer,120);
                            header('location:  '.$wxurl.'/plugin.php?id=mapp_wechat:m&act=wechatlogin&last=1&referer=' . $referer);
                        }
                    }
                }
            }
        }
    }

    function global_footer_mobile(){
        global $_G;
        if($_G['uid']){
          if($_G['cache']['plugin']['mapp_wechat']['follow_enabled'] || $_G['cache']['plugin']['mapp_wechat']['bind_enabled']){

            $binduser = DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array('aljwsq_mapp_user', $_G['uid']));
            if($_G['cache']['plugin']['mapp_wechat']['follow_enabled'] && $binduser){
                $binduser = DB::fetch_first('SELECT * FROM %t WHERE uid=%d and subscribe_time>0', array('aljwsq_mapp_user', $_G['uid']));
            }

            $config = $_G['cache']['plugin']['mapp_wechat'];
            if(!$binduser){
                include template('mapp_wechat:touch/follow');
                return $return;
            }
          }
        }
    }
}
class mobileplugin_mapp_wechat_member extends mobileplugin_mapp_wechat{
    function logging_bottom_mobile()
    {
        global $_G;
        if(empty($_G['uid'])){
          $referer = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'].($_SERVER['QUERY_STRING'] ? '?'.$_SERVER['QUERY_STRING'] : '') : dreferer();
          $referer = urlencode($referer ? $referer : 'index.php');
          return '<style type="text/css">
			.btn_wechatlogin a, .btn_wechatlogin a:hover {
				color: #ffffff;
				text-align: center;
				font-size: 14px;
				height: 40px;
				line-height: 40px;
				background: #3cb134 url(source/plugin/mapp_wechat/images/wechatlogo.png) 20% center no-repeat;
				background-size:contain;
				border: 1px solid #3cb134;
				border-radius: 5px;
				display:block;
				width: 287px;
                height: 43px;
                margin: 10px auto;
                border-radius: 8px;
			}
        </style><div class="btn_wechatlogin"><a href="plugin.php?id=mapp_wechat:m&act=wechatlogin&referer='.$referer.'">&#24494;&#20449;&#30331;&#24405;</a></div>';
    }

    }
}
//From: d'.'is'.'m.ta'.'obao.com
?>
