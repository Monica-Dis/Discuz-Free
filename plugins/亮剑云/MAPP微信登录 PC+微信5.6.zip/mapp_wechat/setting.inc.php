<?php

/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

// �����б�
$creditlist = array();
foreach ($_G['setting']['extcredits'] as $key => $credit) {
	$creditlist[] = array($key, 'extcredits'.$key.' ('.$credit['title'].')');
}

// ����
$mapp_wechat = unserialize($_G['setting']['mapp_wechat']);

if (!submitcheck('submit')) {

	showformheader('plugins&operation=config&identifier=mapp_wechat&pmod=setting');
	showtableheader();
	showtablerow('', 'class="partition" colspan="10"', '&#21151;&#33021;&#35774;&#32622;');
	showsetting('&#24320;&#21551;&#32465;&#23450;&#36865;&#31215;&#20998;', 'settingnew[allowed]', $mapp_wechat['allowed'], 'radio', '', 0, '&#20851;&#38381;&#21518;&#32465;&#23450;&#24494;&#20449;&#23558;&#19981;&#20877;&#36192;&#36865;&#31215;&#20998;');
	showtablefooter(); /*dism��taobao��com*/

	showtableheader();
	showsetting('&#36192;&#36865;&#31215;&#20998;&#31867;&#21035;', array('settingnew[rewardcredit]', $creditlist), $mapp_wechat['rewardcredit'], 'select', '', 0, $qqlang['rewardcredit_comment']);
	showsetting('&#36186;&#36865;&#31215;&#20998;&#25968;&#37327;', 'settingnew[addcreditnum]', $mapp_wechat['addcreditnum'], 'text', '', 0);
	showtablefooter(); /*dism��taobao��com*/

	showtableheader();
	showsetting('&#39318;&#39029;&#24748;&#28014;&#20108;&#32500;&#30721;&#25551;&#36848;', 'settingnew[addqrcodetitle]', $mapp_wechat['addqrcodetitle'], 'text', '', 0);
	showsetting('&#39318;&#39029;&#24748;&#28014;&#20108;&#32500;&#30721;&#38142;&#25509;', 'settingnew[addqrcodeurl]', $mapp_wechat['addqrcodeurl'], 'text', '', 0);
	showsetting('&#32593;&#39029;&#25480;&#26435;&#35748;&#35777;&#22495;&#21517;(http://www.x.com/)', 'settingnew[wxurl]', $mapp_wechat['wxurl'], 'text', '', 0);
	showtablefooter(); /*dism��taobao��com*/


	showtableheader('', 'notop');
	showsubmit('submit');
	showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*dis'.'m.tao'.'bao.com*/
	exit;

} else {
	$_POST['settingnew']['feed'] = trim(strip_tags($_POST['settingnew']['feed']));
	$_POST['settingnew']['rewardcredit'] = $_POST['settingnew']['rewardcredit'] ? intval(trim($_POST['settingnew']['rewardcredit'])) : '';
	$_POST['settingnew']['addcreditnum'] = $_POST['settingnew']['addcreditnum'] ? intval(trim($_POST['settingnew']['addcreditnum'])) : '';
	$_POST['settingnew']['addqrcodetitle'] = $_POST['settingnew']['addqrcodetitle'] ? addslashes(trim($_POST['settingnew']['addqrcodetitle'])) : '';
	$_POST['settingnew']['addqrcodeurl'] = $_POST['settingnew']['addqrcodeurl'] ? addslashes(trim($_POST['settingnew']['addqrcodeurl'])) : '';
	$_POST['settingnew']['wxurl'] = $_POST['settingnew']['wxurl'] ? addslashes(trim($_POST['settingnew']['wxurl'])) : '';
    
	$settingnew = array(
		'allowed' => intval(trim($_POST['settingnew']['allowed'])),
		'rewardcredit' => $_POST['settingnew']['rewardcredit'],
		'addcreditnum' => $_POST['settingnew']['addcreditnum'],
		'addqrcodetitle' => $_POST['settingnew']['addqrcodetitle'],
		'addqrcodeurl' => $_POST['settingnew']['addqrcodeurl'],
		'addqrcodesize' => $_POST['settingnew']['addqrcodesize'],
		'wxurl' => $_POST['settingnew']['wxurl'],
	);

	
	C::t('common_setting')->update_batch(array('mapp_wechat' => $settingnew));

	updatecache('setting');
	cpmsg('setting_update_succeed', 'action=plugins&operation=config&identifier=mapp_wechat&pmod=setting', 'succeed');
}
//d'.'is'.'m.tao'.'ba'.'o.com
?>