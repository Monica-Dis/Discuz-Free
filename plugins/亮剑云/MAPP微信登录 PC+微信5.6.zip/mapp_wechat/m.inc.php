<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(checkrobot()){
    debug('&#27492;&#39029;&#38754;&#19981;&#20801;&#35768;&#25628;&#32034;&#24341;&#25370;&#35775;&#38382;&#65281;');
}

if($_G['mobile'] && $_G['cache']['plugin']['aljhtx']['force_mobile']){
    include_once "source/plugin/aljhtx/api/common.php";
}

$mapp_wechat = unserialize($_G['setting']['mapp_wechat']);
$wxurl = $mapp_wechat['wxurl']?rtrim(trim($mapp_wechat['wxurl']), '/').'/':$_G['siteurl'];
require_once 'source/plugin/aljwsq/function_core.php';
$config = $_G['cache']['plugin']['mapp_wechat'];
if($_GET['act'] == 'qrcode'){
    $aljwsq_config = array();
    $plugin_aljwsq = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljwsq'));
    $tmp_aljwsq_config = DB::fetch_all('select * from %t where  pluginid = %s',array('common_pluginvar',$plugin_aljwsq['pluginid']));
    foreach($tmp_aljwsq_config as $value){
        $aljwsq_config[$value['variable']] = $value['value'];
    }
    $appid = $aljwsq_config['appid'];
    $appsecret = $aljwsq_config['appsecret'];
    $qrcodename = random(9,1);
    $count = DB::result_first('select count(*) from %t where scene_id = %d',array('aljwsq_mapp_wechat_scene',$qrcodename));
    while($count||strlen(intval($qrcodename))!=9){
        $qrcodename = random(9,1);
        $count = DB::result_first('select count(*) from %t where scene_id = %d',array('aljwsq_mapp_wechat_scene',$qrcodename));
    }

    require_once DISCUZ_ROOT . './source/plugin/aljwsq/mapp_wechatclient.lib.class.php';
    $wechat_client = new WeChatClient($aljwsq_config['appid'], $aljwsq_config['appsecret']);
    $ticket = $wechat_client -> getQrcodeTicket(array('expire' => '600','scene_id' => $qrcodename));
    if(!$ticket){
        $wechat_client -> getAccessToken(1,1);
        $ticket = $wechat_client -> getQrcodeTicket(array('expire' => '600','scene_id' => $qrcodename));
    }
    DB::insert('aljwsq_mapp_wechat_scene',array(
        'scene_id' => $qrcodename,
        'dateline' => TIMESTAMP,
        'expire_seconds' => 600,
        'status' => 0,
        'uid' => $_G['uid'],
    ));
    if($_GET['op'] == 'bind'){
        include template('mapp_wechat:bindaccount');
    }else if($_GET['op'] == 'bindurl'){
        echo WeChatClient::getQrcodeImgUrlByTicket($ticket);
        exit;
    }else{
        if($_G['uid']){
            header('Location: forum.php');
        }
        include template('mapp_wechat:qrcode');
    }
}else if ($_GET['act'] == 'bindcheck') {//����Ƿ��
    $binduser = DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array('aljwsq_mapp_user', $_G['uid']));
    if($_G['cache']['plugin']['mapp_wechat']['follow_enabled'] && $binduser){
        $binduser = DB::fetch_first('SELECT * FROM %t WHERE uid=%d and subscribe_time>0', array('aljwsq_mapp_user', $_G['uid']));
    }
    if($binduser) {
        $tips = array('status'=>1);
        echo json_encode($tips);
        exit;
    }else{
        $tips = array('status'=>0);
        echo json_encode($tips);
        exit;
    }
}else if($_GET['act'] == 'checkscene'){
    $checkscene = DB::fetch_first('select * from %t where scene_id = %d and dateline+expire_seconds>%d',array('aljwsq_mapp_wechat_scene',$_GET['uuid'],TIMESTAMP));
    if($checkscene['status']){
        $openid = $checkscene['openid'];
        if ($openid) {
            $binduser = C::t('#aljwsq#aljwsq_mapp_user')->fetch($openid);
            if ($binduser) {
                $user = getuserbyuid($binduser['uid']);
                require_once libfile('function/member');
                setloginstatus($user, 2592000);
            }
        }
        echo 1;
    }

}else if($_GET['act'] == 'wechatlogin'){

    require_once libfile('function/member');
    if(empty($_GET['newreferer'])){
        $referer = !empty($_GET['referer']) ? $_GET['referer'] : dreferer();

        if(strpos($referer,'referer')===false && strpos($referer,'logging') !== false && strpos($referer,'wechatlogin') !== false){
            $referer = 'index.php';
        }
        //debug(getcookie('referer'));
        $referer = urlencode($referer);
        $referer = getcookie('mapp_referer') ? getcookie('mapp_referer') : $referer;
        if(strpos(urldecode(urldecode($referer)),'aljlogin') !== false && strpos($referer,'referer')!==false){
            $referer = str_replace('plugin.php?id=aljlogin&referer=','',urldecode(urldecode($referer)));
            $referer = urlencode($referer);
        }
        if(strpos($wxurl, 'https://') !== false && strpos(urldecode(urldecode($referer)), 'https://') === false && (strpos(urldecode(urldecode($referer)), 'http:') !== false || strpos(urldecode($referer), 'http%3A') !== false)){
            $referer = str_replace('http','https',urldecode($referer));
            $referer = urlencode($referer);
        }
        $myreferer = $referer;
    }else{
        $referer = urlencode($_GET['newreferer']);
        dsetcookie('mapp_referer', $referer);
    }

    if($_GET['openid']){
        $openid = addslashes($_GET['openid']);
        $jsoninfo['access_token'] = getcookie('access_token');
    }else{

        if($_GET['last']){
            $last = '&last=1';
        }
        $jsoninfo = lgetoauth2openid($wxurl.'plugin.php?id=mapp_wechat:m&act=wechatlogin&username='.urlencode($_GET['username']).'&referer='.$referer.$last);
        if($jsoninfo['errcode']){
            unset($_GET['code']);
            $jsoninfo = lgetoauth2openid($wxurl.'plugin.php?id=mapp_wechat:m&act=wechatlogin&username='.urlencode($_GET['username']).'&referer='.$referer.$last);
        }

        $openid = $jsoninfo['openid'];
        dsetcookie('wechat_openid',$openid);
        dsetcookie('access_token',$jsoninfo['access_token']);

    }


    if(empty($openid)){
        showmessage('&#31995;&#32479;&#24537;&#65292;&#20877;&#35797;&#19968;&#27425;&#21591;&#65281;');
    }


    $wuser = lgetwuserinfo($openid);
    if($wuser['subscribe'] == 0){
        $wuser = lgetwechatuserinfo($openid, $jsoninfo['access_token']);
    }
    
    $wxuser = $wuser;

    if(empty($_G['uid'])){
        require_once libfile('function/member');
        loaducenter();

        if ($openid) {
            if($wuser['unionid']){
                $binduser = DB::fetch_first('SELECT * FROM %t WHERE unionid=%s and uid>0', array('aljwsq_mapp_user',$wuser['unionid']));
            }
            if(!$binduser){
                $binduser = DB::fetch_first('SELECT * FROM %t WHERE openid=%s and uid>0', array('aljwsq_mapp_user',$openid));
            }

            if($binduser){
                if($binduser['from'] == 'app' && $wuser['unionid'] && empty($binduser['app_openid']) && $binduser['openid'] != $openid){
                    DB::query('update %t set app_openid=%s where unionid = %s', array('aljwsq_mapp_user', $binduser['openid'], $wuser['unionid']));
                    DB::query('update %t set openid=%s where unionid = %s', array('aljwsq_mapp_user', $openid, $wuser['unionid']));
                }
                if(($binduser['last_logintime']+$_G['cache']['plugin']['mapp_wechat']['switch_time'] > TIMESTAMP) && $_GET['last']){

                    header('Location: member.php?mod=logging&action=login&referer='.$referer);
                    exit;
                }
                $user = DB::fetch_first('SELECT * FROM %t WHERE uid=%s', array('common_member', $binduser['uid']));
            }
            $user = getuserbyuid($binduser['uid']);
            //appbyme
            $is_plugin = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','appbyme_app'));
            $is_magmobileapi = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','magmobileapi'));
            if(function_exists('qianfan_login')){
                $user = qianfan_login($user, $wuser);
            }
            if($is_plugin && empty($binduser)){
                if($wuser['unionid']){
                    $appbymeuser = DB::fetch_first("select * from %t where param=%s and param!=''",array('appbyme_connection',$wuser['unionid']));
                }
                if($appbymeuser['uid']){
                    $binduser['uid'] = $appbymeuser['uid'];
                    $forumuser = C::t('common_member') -> fetch($binduser['uid']);
                    $user = $forumuser;
                    addBindUser($openid,$forumuser,$wuser);
                }

            }

            if($is_magmobileapi && empty($binduser)){
                if($wuser['unionid']){
                    $mag_user = DB::fetch_first("select * from %t where unionid=%s and unionid!=''",array('user_weixin_relations',$wuser['unionid']));
                    if($mag_user['userid']){
                        $mag_user['uid'] = $mag_user['userid'];
                    }
                }
                if($mag_user['uid']){
                    $binduser['uid'] = $mag_user['uid'];
                    $forumuser = C::t('common_member') -> fetch($binduser['uid']);
                    $user = $forumuser;
                    addBindUser($openid,$forumuser,$wuser);
                }
            }

            if($is_plugin){
                $appbymeuser = DB::fetch_first('select * from %t where uid=%d',array('appbyme_connection',$user['uid']));
                if($appbymeuser){
                    if(empty($appbymeuser['unionid'])){
                        DB::query('update %t set param=%s where uid=%d',array('appbyme_connection',$wuser['unionid'],$user['uid']));
                    }
                }else{
                    if($user['uid']) {
                        DB::insert('appbyme_connection', array(
                            'uid' => $user['uid'],
                            'openid' => '',
                            'status' => 1,
                            'type' => 1,
                            'param' => $wuser['unionid']
                        ));
                    }
                }
            }

            if($is_magmobileapi){
                $mag_user = DB::fetch_first('select * from %t where userid=%d',array('user_weixin_relations',$user['uid']));
                if($mag_user['userid']){
                    $mag_user['uid'] = $mag_user['userid'];
                }
                if($mag_user['uid']){
                    if(empty($mag_user['unionid'])){
                        DB::query('update %t set unionid=%s where userid=%d',array('user_weixin_relations',$wuser['unionid'],$user['uid']));
                    }
                }else{
                    if($user['uid']){
                        DB::insert('user_weixin_relations', array(
                            'userid' => $user['uid'],
                            'name' => $user['username'],
                            'unionid' => $wuser['unionid'],
                            'create_time' => TIMESTAMP,
                            'openid' => '',
                        ));
                    }
                }
            }
            //appbyme
            if ($user) {
                if($openid){
                    C::t('#aljwsq#aljwsq_mapp_user')->update($openid, array(
                        'last_logintime' => TIMESTAMP
                    ));
                }
                require_once libfile('function/member');
                setloginstatus($user, 2592000);
                header('Location: '.urldecode(urldecode($referer)));
                exit;
            }
        }
        if($_G['cache']['plugin']['mapp_wechat']['close_register']){
            showmessage($_G['cache']['plugin']['mapp_wechat']['close_register_tips']);
            exit;
        }
        if($_GET['username']){

            if(strtolower(CHARSET) == 'gbk'){
                $nickname = preg_replace('# #','',$_GET['username']);
            }else{
                if(function_exists('removeEmoji')) {
                    $_GET['username'] = removeEmoji($_GET['username']);
                }
                $nickname = preg_replace('# #','',$_GET['username']);
            }

        }else{
            if(function_exists('removeEmoji')) {
                $wxuser['nickname'] = removeEmoji($wxuser['nickname']);
            }
            if(strtolower(CHARSET) == 'gbk'){
                $nickname = diconv($wxuser['nickname'],'UTF-8','GBK');
            }else{
                $nickname = $wxuser['nickname'];
            }
            $nickname = preg_replace('/\d+/', '', $nickname);
            $nickname = preg_replace('# #','',$nickname);
        }

        if($nickname){
            $usernamelen = dstrlen($nickname);
            if($usernamelen > 15){
                $nickname = cutstr($nickname,14,'');
            }
            if(empty($_GET['openid']) && !$_G['cache']['plugin']['mapp_wechat']['global_login_fast']){
                include template('mapp_wechat:confirm');
                exit;
            }else if($usernamelen < 4 || uc_user_checkname($nickname)<0) {
                $username = $nickname.random(2);
            }else{
                $username = cutstr($nickname,14,'');
            }
        }else{
            include template('mapp_wechat:confirm');
            exit;
        }
        while(DB::result_first('select count(*) from %t where username = %s',array('common_member',$username))){
            if($_G['cache']['plugin']['mapp_wechat']['global_login_fast']){
                $username = $nickname.random(2);
            }else{
                include template('mapp_wechat:confirm');
                exit;
            }
        }
        $defaultpassword = 'PW'.random(6);
        $group['fid'] = $config['reggroup'];
        $return = lwechat_register($username,'',$config['reggroup'],$defaultpassword,$group);
        if(!is_array($return)){
            echo  $return;
            exit;
        }
        $tpl = str_replace('{username}',$return['username'],$config['rstips']);
        $tpl = str_replace('{password}',$return['password'],$tpl);
        $user = DB::fetch_first('select * from %t where username = %s',array('common_member',$return['username']));



        sendbindextcredit($user['uid']);
        if($wxuser['headimgurl']){
            if($config['is_remote_uc']){
                if(function_exists('AljSyncAvatar')){
                    AljSyncAvatar($user['uid'],$wxuser['headimgurl']);
                }
            }else{
                lcreate_avatar($user['uid'], $wxuser['headimgurl']);
            }
        }
        $checkopenid = DB::fetch_first('SELECT * FROM %t WHERE openid=%s', array('aljwsq_mapp_user', $openid));
        if(function_exists('qianfan_login')) {
            qianfan_login($user, $wuser);
        }
        //appbyme
        if($is_plugin){
            $appbymeuser = DB::fetch_first('select * from %t where uid=%d',array('appbyme_connection',$user['uid']));
            if($appbymeuser){
                if(empty($appbymeuser['unionid'])){
                    DB::query('update %t set param=%s where uid=%d',array('appbyme_connection',$wuser['unionid'],$user['uid']));
                }
            }else{
                DB::insert('appbyme_connection', array(
                    'uid' => $user['uid'],
                    'openid' => '',
                    'status' => 1,
                    'type' => 1,
                    'param' => $wuser['unionid']
                ));
            }
        }

        if($is_magmobileapi){
            $mag_user = DB::fetch_first('select * from %t where userid=%d',array('user_weixin_relations',$user['uid']));
            if($mag_user['userid']){
                $mag_user['uid'] = $mag_user['userid'];
            }
            if($mag_user['uid']){
                if(empty($mag_user['unionid'])){
                    DB::query('update %t set unionid=%s where userid=%d',array('user_weixin_relations',$wuser['unionid'],$user['uid']));
                }
            }else{
                DB::insert('user_weixin_relations', array(
                    'userid' => $user['uid'],
                    'name' => $user['username'],
                    'unionid' => $wuser['unionid'],
                    'create_time' => TIMESTAMP,
                    'openid' => '',
                ));
            }
        }
        addBindUser($openid,$user,$wuser);

        if($openid){
            C::t('#aljwsq#aljwsq_mapp_user')->update($openid, array(
                'last_logintime' => TIMESTAMP
            ));
        }
        require_once libfile('function/member');
        setloginstatus($user, 2592000);
        notification_add($user['uid'], 'system',$tpl);

        
        header('Location: '.urldecode(urldecode($referer)));
        eixt;
    }else{
        $binduser = DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array('aljwsq_mapp_user', $_G['uid']));
        if(!$binduser){
            if(DB::fetch_first('SELECT * FROM %t WHERE openid=%s', array('aljwsq_mapp_user', $openid))){
                DB::update('aljwsq_mapp_user', array('uid' => $_G['uid'],'subscribe' => $wuser['subscribe'],'unionid' =>$wuser['unionid'],'nickname' => strtolower(CHARSET) == 'gbk' ? diconv($wuser['nickname'],'UTF-8','GBK') : $wuser['nickname']),  array('openid' => $openid));
            }else{
                C::t('#aljwsq#aljwsq_mapp_user')->insert(array(
                    'uid' => $_G['uid'],
                    'username' => $_G['username'],
                    'openid' => $openid,
                    'bindtime' => TIMESTAMP,
                    'subscribe' => $wuser['subscribe'],
                    'subscribe_time' => $wuser['subscribe_time'],
                    'nickname' => strtolower(CHARSET) == 'gbk' ? diconv($wuser['nickname'],'UTF-8','GBK') : $wuser['nickname'],
                    'unionid' =>$wuser['unionid']
                ));
            }

        }

        $referer = urldecode($referer);
        header('Location: '.urldecode($referer));
        eixt;
    }
}else if($_GET['act'] == 'wechatsetting'){
    if(submitcheck('formhash')){
        loaducenter();
        $newusername = addslashes($_GET['newusername']);
        $password = addslashes($_GET['password']);
        $confirmpassword = addslashes($_GET['confirmpassword']);
        if($password != $confirmpassword){
            echo '<script>parent.showError("'.lang('message', 'profile_passwd_notmatch').'");</script>';
            exit;
        }
        if($_G['setting']['pwlength']) {
            if(strlen($_GET['password']) < $_G['setting']['pwlength']) {
                echo '<script>parent.showError("'.str_replace('{pwlength}',$_G['setting']['pwlength'],lang('message', 'profile_password_tooshort')).'");</script>';
                exit;
            }
        }
        if($_G['setting']['strongpw']) {
            $strongpw_str = array();
            if(in_array(1, $_G['setting']['strongpw']) && !preg_match("/\d+/", $password)) {
                $strongpw_str[] = lang('member/template', 'strongpw_1');
            }
            if(in_array(2, $_G['setting']['strongpw']) && !preg_match("/[a-z]+/", $password)) {
                $strongpw_str[] = lang('member/template', 'strongpw_2');
            }
            if(in_array(3, $_G['setting']['strongpw']) && !preg_match("/[A-Z]+/", $password)) {
                $strongpw_str[] = lang('member/template', 'strongpw_3');
            }
            if(in_array(4, $_G['setting']['strongpw']) && !preg_match("/[^a-zA-z0-9]+/", $password)) {
                $strongpw_str[] = lang('member/template', 'strongpw_4');
            }
            if($strongpw_str) {
                echo '<script>parent.showError("'.lang('member/template', 'password_weak').implode(',', $strongpw_str).'");</script>';
                exit;
            }
        }
        if($_G['uid'] && checkusername($newusername) && !lgetuseraction($_G['uid'],'mapp_wechat','changeusername') && lgetuseraction($_G['uid'],'mapp_wechat','register')){
            luseractionlog($_G['uid'],'mapp_wechat','changeusername');
            DB::query('UPDATE %t SET username = %s WHERE username = %s', array('aljwsq_mapp_user', $newusername, $_G['member']['username']));
            DB::query('UPDATE %t SET username = %s WHERE username = %s', array('common_member', $newusername, $_G['member']['username']));
            DB::query("UPDATE ".UC_DBTABLEPRE."members SET username='$newusername' WHERE username='{$_G[member][username]}'");
            C::t('common_member')->update_cache($_G['uid'], array('username' => $newusername));
            uc_user_edit($_G[member][username],'',$password,'',1,0,'');
            echo '<script>parent.showDialog("'.lang('message', 'do_success').'","right","",function(){parent.location.href=parent.location.href;});</script>';
            exit;
        }else{
            echo '<script>parent.showError("'.lang('message', 'message_can_not_send_12').'");</script>';
            exit;
        }
    }else{
        include template('mapp_wechat:wechatsetting');
    }

}

function checkusername($username) {
    global $_G;
    $username = trim($username);
    $usernamelen = dstrlen($username);
    if($usernamelen < 4) {
        echo '<script>parent.showError("'.lang('message', 'profile_username_tooshort').'");</script>';
        exit;
    } elseif($usernamelen > 15) {
        echo '<script>parent.showError("'.lang('message', 'profile_username_toolong').'");</script>';
        exit;
    }
    $ucresult = uc_user_checkname($username);
    if($ucresult == -1) {
        echo '<script>parent.showError("'.lang('message', 'profile_username_duplicate').'");</script>';
        exit;
    } elseif($ucresult == -2) {
        echo '<script>parent.showError("'.lang('message', 'profile_username_protect').'");</script>';
        exit;
    } elseif($ucresult == -3) {
        if(C::t('common_member')->fetch_by_username($username) || C::t('common_member_archive')->fetch_by_username($username)) {
            echo '<script>parent.showError("'.lang('message', 'profile_passwd_notmatch').'");</script>';
            exit;
        } else {
            echo '<script>parent.showError("'.lang('message', 'register_activation').'");</script>';
            exit;
        }
    }
    $censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';
    if($_G['setting']['censoruser'] && @preg_match($censorexp, $username)) {
        echo '<script>parent.showError("'.lang('message', 'profile_username_protect').'");</script>';
        exit;
    }
    return true;
}
function addBindUser($openid,$forumuser,$wuser){
    $checkopenid = DB::fetch_first('SELECT * FROM %t WHERE openid=%s', array('aljwsq_mapp_user', $openid));
    if($checkopenid){
        C::t('#aljwsq#aljwsq_mapp_user')->update($openid, array(
            'username' => $forumuser['username'],
            'uid' => $forumuser['uid'],
            'bindtime' => TIMESTAMP,
            'subscribe' => $wuser['subscribe'],
            'subscribe_time' => $wuser['subscribe_time'],
            'nickname' => strtolower(CHARSET) == 'gbk' ? diconv($wuser['nickname'],'UTF-8','GBK') : $wuser['nickname'],
            'unionid' =>$wuser['unionid']
        ));
    }else{
        C::t('#aljwsq#aljwsq_mapp_user')->insert(array(
            'uid' => $forumuser['uid'],
            'username' => $forumuser['username'],
            'openid' => $openid,
            'bindtime' => TIMESTAMP,
            'subscribe' => $wuser['subscribe'],
            'subscribe_time' => $wuser['subscribe_time'],
            'lasttime' => TIMESTAMP,
            'nickname' => strtolower(CHARSET) == 'gbk' ? diconv($wuser['nickname'],'UTF-8','GBK') : $wuser['nickname'],
            'unionid' =>$wuser['unionid']
        ));
    }
}
?>
