<?php

/*
 * ���ߣ�����
 * ��ϵQQ:190360183
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$sjlz = explode ("\n", str_replace ("\r", "", $config ['sj_img_1']));
foreach($sjlz as $key=>$value){
    $arr=explode('|',$value);
    $lz_types[$arr[0]]=$arr;
}
$index_lz = explode ("\n", str_replace ("\r", "", $config ['index_lz']));
foreach($index_lz as $key=>$value){
    $arr=explode('|',$value);
    $index_lz_types[$arr[0]]=$arr[1];
}
$sj_index_dh = explode ("\n", str_replace ("\r", "", $config ['sj_index_dh']));
foreach($sj_index_dh as $key=>$value){
    $arr=explode('|',$value);
    $sj_index_dh_types[]=$arr;
}
$gg = explode ("\n", str_replace ("\r", "", $config ['gg']));
foreach($gg as $key=>$value){
    $arr=explode('|',$value);
    $gg_types[$arr[0]]=$arr[1];
}
$gg_types=dhtmlspecialchars($gg_types);
$mobile_index_img_s = explode ("\n", str_replace ("\r", "", $settings['mobile_index_img_s']['value']));
foreach($mobile_index_img_s as $key=>$value){
    $arr=explode('|',$value);
    $index_img_s_types[]=$arr;
}

$navtitle = $config['title'];
$metakeywords =  $config['keywords'];
$metadescription = $config['description'];

if($aljbd_seo['index']['seotitle']){
    $seodata = array('bbname' => $_G['setting']['bbname']);
    list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljbd_seo['index']);
}
if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
    $aljbd=C::t('#aljbd#aljbd')->fetch_by_uid($_G['uid']);
    $config=$_G['cache']['plugin']['aljbd'];
    $timelistnum = $settings['timelistnum']['value']?$settings['timelistnum']['value']:6;
    $viewslistnum = $settings['viewslistnum']['value']?$settings['viewslistnum']['value']:6;
    $recommendlistnum = $settings['recommendlistnum']['value']?$settings['recommendlistnum']['value']:6;
    $viewslist=C::t('#aljbd#aljbd')->fetch_all_by_view(1,0,$viewslistnum,'view');
    $viewslist = dhtmlspecialchars($viewslist);
    $timelist=C::t('#aljbd#aljbd')->fetch_all_by_view(1,0,$timelistnum,'dateline');
    $timelist = dhtmlspecialchars($timelist);
    $recommendlist=C::t('#aljbd#aljbd')->fetch_all_by_recommend(1,0,$recommendlistnum);
    $recommendlist = dhtmlspecialchars($recommendlist);
    $mobile_index_tad = explode ("\n", str_replace ("\r", "", $settings['mobile_index_tad']['value']));
    foreach($mobile_index_tad as $key=>$value){
        $arr=explode('|',$value);
        $mobile_index_tad_arr[]=$arr;
    }
    $mobile_index_fad = explode ("\n", str_replace ("\r", "", $settings['mobile_index_fad']['value']));
    foreach($mobile_index_fad as $key=>$value){
        $arr=explode('|',$value);
        $mobile_index_fad_arr[]=$arr;
    }
    $mobile_index_siad = explode ("\n", str_replace ("\r", "", $settings['mobile_index_siad']['value']));
    foreach($mobile_index_siad as $key=>$value){
        $arr=explode('|',$value);
        $mobile_index_siad_arr[]=$arr;
    }
    $onetype = DB::fetch_all('select * from %t where upid=0 order by displayorder asc ',array('aljbd_type_goods'));
}
$recommendlist_goods_index=C::t('#aljbd#aljbd_goods')->fetch_all_by_recommend_new(1,0,$config['recgnum']);
foreach($recommendlist_goods_index as $k=>$v){
    $recommendlist_goods_index[$k]['price1']=floatval($v['price1']);
    $recommendlist_goods_index[$k]['price2']=floatval($v['price2']);
}
$recommendlist_goods_index = dhtmlspecialchars($recommendlist_goods_index);
$recommendlist_consume_index=C::t('#aljbd#aljbd_consume')->fetch_all_by_recommend(1,0,5);
$recommendlist_consume_index = dhtmlspecialchars($recommendlist_consume_index);
if(!$_G['mobile'] || !$_G['setting']['mobile']['allowmobile']){
    $khf=C::t('#aljbd#aljbd_comment')->count_by_bid($bid);
    $typecount=C::t('#aljbd#aljbd')->count_by_type();
    foreach($typecount as $tc){
        $tcs[$tc['type']]=$tc['num'];
    }
    if($_GET['type']){
        $subtypecount=C::t('#aljbd#aljbd')->count_by_type($_GET['type']);
    }
    $typelist=C::t('#aljbd#aljbd_type')->range();
    //$aljbd_index=C::t('#aljbd#aljbd')->range();
    //$aljbd_index = dhtmlspecialchars($aljbd_index);
    $tlist=C::t('#aljbd#aljbd_type')->fetch_all_by_upid(0,'','','');
    $rlist=C::t('#aljbd#aljbd_region')->fetch_all_by_upid(0,'','');
    $listall=C::t('#aljbd#aljbd_region')->range();
    $timelist_index=C::t('#aljbd#aljbd')->fetch_all_by_view(1,0,$config['newnum'],'dateline');
    $timelist_index = dhtmlspecialchars($timelist_index);
    $recommendlist_goods=C::t('#aljbd#aljbd_goods')->fetch_all_by_recommend_new(1,0,10);
    foreach($recommendlist_goods as $k=>$v){
        $recommendlist_goods[$k]['price1']=floatval($v['price1']);
        $recommendlist_goods[$k]['price2']=floatval($v['price2']);
    }
    $recommendlist_goods = dhtmlspecialchars($recommendlist_goods);
    $recommendlist_1=C::t('#aljbd#aljbd')->fetch_all_by_recommend(1,0,$config['recnum']);
    $recommendlist_1 = dhtmlspecialchars($recommendlist_1);
    $recommendlist_notice_index=C::t('#aljbd#aljbd_notice')->fetch_all_by_recommend(1,0,10);
    $recommendlist_notice_index = dhtmlspecialchars($recommendlist_notice_index);
    $notice=C::t('#aljbd#aljbd_notice')->fetch_all_by_uid_bid('','',0,9,'','','','',0);
    $notice = dhtmlspecialchars($notice);
    $glist=C::t('#aljbd#aljbd_goods')->fetch_all_by_status_new('',0,$config['newgnum'],'','','','','','id','','',0);
    foreach($glist as $k=>$v){
        $glist[$k]['price1']=floatval($v['price1']);
        $glist[$k]['price2']=floatval($v['price2']);
    }
    $glist = dhtmlspecialchars($glist);
    $dianping=C::t('#aljbd#aljbd_comment')->fetch_all_by_dianping(0,20);
    $dianping=dhtmlspecialchars($dianping);
    $dianpinguser=DB::fetch_all(" select count(id) n,uid from %t where rubbish=0 and status=1 group by uid order by n desc limit 0,20",array('aljbd'));
}
if(file_exists('source/plugin/mapp_share/api/api.php')){
    $shareurl = $_G[siteurl].'plugin.php?id=aljbd';
    require_once 'source/plugin/mapp_share/api/api.php';
}
if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
    include template('aljbd:aljbd_list');
} else {
    include template('diy:aljbd_list', null, 'source/plugin/aljbd/template');
}
?>