<?php

/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_GET['act'] == 'unbind'){
    if($_G['uid'] && $_G['cache']['plugin']['mapp_wechat']['is_unbind']){
        DB::delete('aljwsq_mapp_user',array('uid'=>$_G['uid']));
        $is_plugin = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','appbyme_app'));
        if($is_plugin){
            DB::delete('appbyme_connection',array('uid'=>$_G['uid']));
        }
        $is_magmobileapi = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','magmobileapi'));
        if($is_magmobileapi){
            DB::delete('user_weixin_relations',array('userid'=>$_G['uid']));
        }
        $is_qfapp = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','qianfan'));
        if($is_qfapp){
            DB::delete('thirdbind',array('uid'=>$_G['uid']));
        }
        echo 1;
        exit;
    }else{
        echo 0;
        exit;
    }
}

$referer = $_GET['referer'] ? $_GET['referer'] : dreferer();
if($referer && strpos($referer, '%') === false){
    $referer = urlencode($referer);
}

$config = $_G['cache']['plugin']['mapp_wechat'];
$aljwsq_config=$_G['cache']['plugin']['aljwsq'];
$mapp_wechat = unserialize($_G['setting']['mapp_wechat']);
$wxurl = $mapp_wechat['wxurl']?rtrim(trim($mapp_wechat['wxurl']), '/').'/':$_G['siteurl'];
$openid = (string)$_GET['openid'];
$openid = addslashes($openid);
$username = addslashes($_GET['username']);
$password = addslashes($_GET['password']);
require_once DISCUZ_ROOT . './source/plugin/aljwsq/function_core.php';
require_once DISCUZ_ROOT . './source/plugin/aljwsq/mapp_wechatclient.lib.class.php';
$wechat_client = new WeChatClient($aljwsq_config['appid'], $aljwsq_config['appsecret']);
if (submitcheck('formhash')) {
    if($config['key']){
        $param['openid']=(string)$_GET['openid'];
        $param['key']=$config['key'];
        $param['dateline']=intval($_GET['dateline']);
        if($param['dateline']+300<TIMESTAMP){
            showmessage('&#35831;&#27714;&#19981;&#21512;&#27861;&#65292;&#38142;&#25509;&#24050;&#36807;&#26399;&#65281;');
        }
        $params = '';
        foreach($param as $k => $v) {
            $params .= '&'.$k.'='.rawurlencode($v);
        }
        $md5hash = md5(substr($params, 1).$config['key']);
        if($md5hash!=$_GET['hash']){
            showmessage('&#35831;&#27714;&#21442;&#25968;&#19981;&#23436;&#25972;&#65281;');
        }
    }
    $check = C::t('common_member')->fetch_by_username($username);
    if (empty($check)) {
        showmessage(lang('plugin/mapp_wechat', 'bind2'));
    }
    if (empty($openid)) {
        showmessage(lang('plugin/mapp_wechat', 'bind5'));
    }
    $user = C::t('#aljwsq#aljwsq_mapp_user')->fetch($openid);
    $checkuid = DB::fetch_first('SELECT * FROM %t WHERE uid=%s', array('aljwsq_mapp_user', $check['uid']));
    $checkwxbind = DB::result_first('SELECT count(*) FROM %t WHERE openid=%s and uid>0', array('aljwsq_mapp_user', $openid));
    if ($user['username'] || $checkuid || $checkwxbind) {
        showmessage(lang('plugin/mapp_wechat', 'bind3'));
    }
    require_once libfile('function/member');
    $result = mapp_userlogin($username, $password);
    if (empty($result['status'])) {
        showmessage(lang('plugin/mapp_wechat', 'bind4'));
    }
    if($openid){
        sendbindextcredit($check['uid']);
        require_once DISCUZ_ROOT . './source/plugin/aljwsq/mapp_wechatclient.lib.class.php';
        $aljwsq_config = array();
        $plugin_aljwsq = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljwsq'));
        $tmp_aljwsq_config = DB::fetch_all('select * from %t where  pluginid = %s',array('common_pluginvar',$plugin_aljwsq['pluginid']));
        foreach($tmp_aljwsq_config as $value){
            $aljwsq_config[$value['variable']] = $value['value'];
        }
        $wechat_client = new WeChatClient($aljwsq_config['appid'], $aljwsq_config['appsecret']);
        $wuser = $wechat_client -> getUserInfoById($openid);
        //appbyme
        $is_plugin = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','appbyme_app'));
        if($is_plugin){
            $appbymeuser = DB::fetch_first('select * from %t where uid=%d',array('appbyme_connection',$check['uid']));
            if($appbymeuser){
                if(empty($appbymeuser['unionid'])){
                    DB::query('update %t set param=%s where uid=%d',array('appbyme_connection',$wuser['unionid'],$check['uid']));
                }
            }else{
                DB::query('INSERT INTO ' . DB::table('appbyme_connection') . " (uid,openid,status,type,param)values(" . $check['uid'] . ",'',1,1,'" . $wuser['unionid'] . "') ");
            }
        }
        $is_magmobileapi = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','magmobileapi'));
        if(function_exists('qianfan_login')){
            $user = qianfan_login($user, $wuser);
        }
        if($is_magmobileapi){
            $mag_user = DB::fetch_first('select * from %t where userid=%d',array('user_weixin_relations',$user['uid']));
            if($mag_user['userid']){
                $mag_user['uid'] = $mag_user['userid'];
            }
            if($mag_user['uid']){
                if(empty($mag_user['unionid'])){
                    DB::query('update %t set unionid=%s where userid=%d',array('user_weixin_relations',$wuser['unionid'],$user['uid']));
                }
            }else{
                DB::insert('user_weixin_relations', array(
                    'userid' => $user['uid'],
                    'name' => $user['username'],
                    'unionid' => $wuser['unionid'],
                    'create_time' => TIMESTAMP,
                    'openid' => '',
                ));
            }
        }
        //appbyme
        if (!$user && $openid) {
            C::t('#aljwsq#aljwsq_mapp_user')->insert(array(
                'uid' => $check['uid'],
                'username' => $username,
                'openid' => $openid,
                'bindtime' => TIMESTAMP,
                'subscribe' => $wuser['subscribe'],
                'subscribe_time' => $wuser['subscribe_time'],
                'nickname' => strtolower(CHARSET) == 'gbk' ? diconv($wuser['nickname'],'UTF-8','GBK') : $wuser['nickname'],
                'unionid' =>$wuser['unionid']
            ));
        } else {
            C::t('#aljwsq#aljwsq_mapp_user')->update($openid, array(
                'username' => $username,
                'uid' => $check['uid'],
                'bindtime' => TIMESTAMP,
                'subscribe' => $wuser['subscribe'],
                'unionid' =>$wuser['unionid'],
                'nickname' => strtolower(CHARSET) == 'gbk' ? diconv($wuser['nickname'],'UTF-8','GBK') : $wuser['nickname']
            ));
        }
    }
    $user = C::t('common_member')->fetch_by_username($username);
    if($user){
        require_once libfile('function/member');
        setloginstatus($user, 2592000);
    }
    $param['openid']=$openid;
    $param['key']=$config['key'];
    $param['dateline']=intval($_GET['dateline']);
    if($param['dateline']+300<TIMESTAMP){
        return;
    }
    $params = '';
    foreach($param as $k => $v) {
        $params .= '&'.$k.'='.rawurlencode($v);
    }
    $md5hash = md5(substr($params, 1).$config['key']);
    //showmessage(lang('plugin/mapp_wechat', 'bind6'), urldecode($referer));
    header('Location: '.urldecode($referer));
    exit;
} else {
    require_once libfile('function/member');

    if($aljwsq_config['appid'] && $aljwsq_config['appsecret']){
        $jsoninfo = lgetoauth2openid($wxurl.'plugin.php?id=mapp_wechat&referer='.$referer);
        if($jsoninfo['errcode']){
            unset($_GET['code']);
           $jsoninfo = lgetoauth2openid($wxurl.'plugin.php?id=mapp_wechat&referer='.$referer);
        }
        $access_token = $jsoninfo["access_token"];
        $openid = $jsoninfo["openid"];
    }

    if(!$openid){
        $openid = addslashes($_GET['openid']);
    }
    $openid = (string)$openid;
    $binduser = DB::fetch_first('SELECT * FROM %t WHERE openid=%s', array('aljwsq_mapp_user', $openid));
    if($binduser && $binduser['uid'] && $openid){
        $user = C::t('common_member')->fetch_by_username($binduser['username']);
        if($user){
            setloginstatus($user, 2592000);
        }
        showmessage("&#27492;&#24494;&#20449;&#24050;&#32465;&#23450;&#24080;&#21495;&#65306;".$binduser['username'],"forum.php?mobile=2");
    }
    $dateline = TIMESTAMP;
    $param['openid']=$openid;
    $param['key']=$config['key'];
    $param['dateline']=$dateline;
    $params = '';
    foreach($param as $k => $v) {
        $params .= '&'.$k.'='.rawurlencode($v);
    }
    $md5hash = md5(substr($params, 1).$config['key']);
    include template('mapp_wechat:bind');
}

function mapp_userlogin($username, $password, $questionid = '', $answer = '', $loginfield = 'username', $ip = '') {
    $return = array();

    if($loginfield == 'uid' && getglobal('setting/uidlogin')) {
        $isuid = 1;
    } elseif($loginfield == 'email') {
        $isuid = 2;
    } elseif($loginfield == 'auto') {
        $isuid = 3;
    } else {
        $isuid = 0;
    }

    if(!function_exists('uc_user_login')) {
        loaducenter();
    }
    if($isuid == 3) {
        if(!strcmp(dintval($username), $username) && getglobal('setting/uidlogin')) {
            $return['ucresult'] = uc_user_login($username, $password, 1, 0, $questionid, $answer, $ip);
        } elseif(isemail($username)) {
            $return['ucresult'] = uc_user_login($username, $password, 2, 0, $questionid, $answer, $ip);
        }
        if($return['ucresult'][0] <= 0 && $return['ucresult'][0] != -3) {
            $return['ucresult'] = uc_user_login(addslashes($username), $password, 0, 0, $questionid, $answer, $ip);
        }
    } else {
        $return['ucresult'] = uc_user_login(addslashes($username), $password, $isuid, 0, $questionid, $answer, $ip);
    }
    $tmp = array();
    $duplicate = '';
    list($tmp['uid'], $tmp['username'], $tmp['password'], $tmp['email'], $duplicate) = $return['ucresult'];
    $return['ucresult'] = $tmp;
    if($duplicate && $return['ucresult']['uid'] > 0 || $return['ucresult']['uid'] <= 0) {
        $return['status'] = 0;
        return $return;
    }

    $member = getuserbyuid($return['ucresult']['uid'], 1);
    if(!$member || empty($member['uid'])) {
        $return['status'] = -1;
        return $return;
    }
    $return['member'] = $member;
    $return['status'] = 1;
    if($member['_inarchive']) {
        C::t('common_member_archive')->move_to_master($member['uid']);
    }
    if($member['email'] != $return['ucresult']['email']) {
        C::t('common_member')->update($return['ucresult']['uid'], array('email' => $return['ucresult']['email']));
    }

    return $return;
}

function g2u($a) {
    return is_array($a) ? array_map('g2u', $a) : diconv($a, CHARSET, 'UTF-8');
}

function u2g($a) {
    return is_array($a) ? array_map('u2g', $a) : diconv($a, 'UTF-8', CHARSET);
}
