<?php
/*
	Copyright (c) 2021 by dism.taobao.com
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
//start to put your own code 
$sql = <<<EOF
DROP TABLE IF  EXISTS `pre_aljlogin_globalsetting`;
DROP TABLE IF  EXISTS `pre_aljlogin_setting`;
EOF;

runquery($sql);
//finish to put your own code
$finish = TRUE;
?>