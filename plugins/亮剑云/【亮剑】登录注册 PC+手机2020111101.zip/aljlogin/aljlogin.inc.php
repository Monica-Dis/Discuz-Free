<?php

/*
 * Copyright (c) 2021 by dism.taobao.com�̳�
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * (From) dism-Taobao-com
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'source/plugin/aljhtx/class/class_aljhtx.php';

if(strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false){
    preg_match('/Immersed\/(\d+)/i', $_SERVER["HTTP_USER_AGENT"], $matches);
    $immersed = $matches[1];
}
$pluginid = htmlspecialchars($_GET['pluginid']);
$settingrecord = DB::fetch_all('select * from %t',array('aljlogin_globalsetting'));
foreach($settingrecord as  $val){
	$setting_aljlogin[$val['mykey']] = $val['myvalue'];
}
$setting_aljlogin['tzurl'] = $setting_aljlogin['tzurl'] ? $setting_aljlogin['tzurl'] : 'forum.php';
if($_GET['pluginid']){
	$pluginsettingrecord = DB::fetch_all('select * from %t where pluginid = %s',array('aljlogin_setting',$pluginid));
	foreach($pluginsettingrecord as  $val){
		$pluginsetting[$val['mykey']] = $val['myvalue'];

	}
}

$colorname = $setting_aljlogin['namecolor']?$setting_aljlogin['namecolor']:'#63AEFF';
$logo = $setting_aljlogin['logo']?$setting_aljlogin['logo']:'source/plugin/aljlogin/static/images/login.png';
$minlogo = $setting_aljlogin['minlogo']?$setting_aljlogin['minlogo']:1;
$colorname = $pluginsetting['namecolor']?$pluginsetting['namecolor']:$colorname;
$logo = $pluginsetting['logo']?$pluginsetting['logo']:$logo;
$minlogo = $pluginsetting['minlogo']?$pluginsetting['minlogo']:$minlogo;
$referer = strip_tags($_GET['referer']);
$urlreferer = urlencode($referer);

if($_G['uid']){
	$referer = !empty($referer) ? $referer : $_SERVER['HTTP_REFERER'];
	$referer = $referer ? $referer : $setting_aljlogin['tzurl'];
	if(strpos($referer, 'aljlogin') !== false){
		$referer = $setting_aljlogin['tzurl'];
	}
	header('Location: ' . $referer);
	exit;
}
//debug($referer);
//ע��
if($_GET['act'] == 'mobilelogin'){
	if(submitcheck('formhash') || $_GET['ticket']){
		if($_G[cache][plugin][aljhtx][verify_appid]){
            $verify_result = T::verify();
            if($verify_result['response'] != 1){
                mall_parenttips($verify_result['err_msg']);
                exit;
            }
        }
		$config = $_G['cache']['plugin']['aljyzm'];
		$mobilecolumn = $config['mobile'];
		$phone = addslashes($_GET['lmobile']);
		if(!ismobile_aljlogin($phone)){
			mall_parenttips(lang('plugin/aljyzm','nocorrect'));
		}
		$checkcode = DB::result_first('select code from %t where phone = %s and status=1 and sendtime+36000>%d order by sendtime desc',array('aljyzm_mcode',$_GET['lmobile'],TIMESTAMP));

		if(empty($_GET['lmobilecheck']) || $_GET['lmobilecheck'] != $checkcode){
			mall_parenttips(lang('plugin/aljyzm','codenocorrect'));
			echo '<script>parent.alert("'.lang('plugin/aljyzm','codenocorrect').'");</script>';
			exit;
		}
		$uid = DB::result_first('select uid from %t where '.$mobilecolumn.' = %s',array('common_member_profile',$phone));
		$user = getuserbyuid($uid);
		
		if($user){
			require_once libfile('function/member');
			setloginstatus($user, 2592000);
			$referer = !empty($referer) ? $referer : $_SERVER['HTTP_REFERER'];
			$referer = $referer ? $referer : $setting_aljlogin['tzurl'];
			if(strpos($referer, 'aljlogin') !== false){
				$referer = $setting_aljlogin['tzurl'];
			}
			mall_parenttips("\u767b\u5f55\u6210\u529f\uff01",$referer);
		}else{
			mall_parenttips("&#24744;&#36755;&#20837;&#30340;&#25163;&#26426;&#21495;&#36824;&#26410;&#27880;&#20876;&#21734;&#65292;&#35831;&#20808;&#27880;&#20876;&#21518;&#20877;&#30331;&#24405;&#65281;");
		}
		

	}else{
		include template('aljlogin:mobilelogin');
	}
}else if($_GET['act'] == 'register'){
	if(submitcheck('formhash') || $_GET['ticket']){

        if($_G[cache][plugin][aljhtx][verify_appid]){
            $verify_result = T::verify();
            if($verify_result['response'] != 1){
                mall_parenttips($verify_result['err_msg']);
                exit;
            }
        }
		if($_GET['password']!=$_GET['confirmpassword']){
			mall_parenttips("\u5bc6\u7801\u4e0d\u4e00\u81f4");
		}else if(empty($_GET['confirmpassword']) || empty($_GET['password']) || empty($_GET['username'])){
            mall_parenttips("\u7528\u6237\u540d\u548c\u5bc6\u7801\u4e0d\u80fd\u4e3a\u7a7a");
		}else{
			if($setting_aljlogin['mail']){
				$_GET['email']=$_GET['email'];
			}else{
				$_GET['email']='wechat_'.strtolower(random(15)).'@null.null';
			}
		//�ֻ�������֤��ʼ
		if($setting_aljlogin['dxyz']){
			$config = $_G['cache']['plugin']['aljyzm'];
			$mobilecolumn = $config['mobile'];
			$phone = addslashes($_GET['lmobile']);
			if(!ismobile_aljlogin($phone)){
				mall_parenttips(lang('plugin/aljyzm','nocorrect'));
			}
			$checkcode = DB::result_first('select code from %t where phone = %s and status=1 and sendtime+36000>%d order by sendtime desc',array('aljyzm_mcode',$_GET['lmobile'],TIMESTAMP));

			if(empty($_GET['lmobilecheck']) || $_GET['lmobilecheck'] != $checkcode){
				mall_parenttips(lang('plugin/aljyzm','codenocorrect'));
				echo '<script>parent.alert("'.lang('plugin/aljyzm','codenocorrect').'");</script>';
				exit;
			}
			$checkphone = DB::result_first('select count(*) from %t where '.$mobilecolumn.' = %s',array('common_member_profile',$phone));
			if($checkphone){
				mall_parenttips(lang('plugin/aljyzm','numnocorrect'));
			}
		}
		//�ֻ�������֤����

		$groupid = $_G['cache']['plugin']['aljlogin']['groupid'];
		$result = myregister($_GET['username'],'',$groupid,$_GET['password'],$_GET['email']);
		if(is_array($result)){
			//�ֻ�����⿪ʼ
			if($setting_aljlogin['dxyz']){
				$mobile = addslashes($_GET['lmobile']);
				if(DB::result_first('select count(*) from %t where uid=%d',array('aljyzm_user',$result['uid']))){
					DB::insert('aljyzm_user',array(
						'uid' => $result['uid'],
						'username' => $result['username'],
						'phone' => $mobile,
						'dateline' => TIMESTAMP,
					));
				}else{
					DB::query('update %t set phone = %s where uid=%d',array('aljyzm_user',$mobile,$result['uid']));
				}
				DB::query('update %t set '.$mobilecolumn.' = %s where uid=%d',array('common_member_profile',$mobile,$result['uid']));
				DB::query('update %t set uid = %d where phone=%s',array('aljyzm_mcode',$result['uid'],$mobile));
			}
		//�ֻ���������
			$referer = !empty($referer) ? $referer : $_SERVER['HTTP_REFERER'];
			$referer = $referer ? $referer : $setting_aljlogin['tzurl'];
            $user = $user = C::t('common_member')->fetch_by_username($result['username']);;
            if($user){
                //�Զ���¼
                require_once libfile('function/member');
                setloginstatus($user, 2592000);
                mall_parenttips('\u6ce8\u518c\u6210\u529f\uff01',$referer);
            }
			mall_parenttips("\u6ce8\u518c\u6210\u529f\uff01","plugin.php?id=aljlogin&referer='.$referer.'&pluginid=".$pluginid);
		}else{
			mall_parenttips($result);
		}
	}
	}else{
		if($_G['uid']){
			header('Location: '.$setting_aljlogin['tzurl']);
		}
        if($setting_aljlogin['wsq_allow']){
            header('Location: plugin.php?id=aljlogin&referer='.strip_tags(urlencode($_GET[referer])).'&pluginid='.strip_tags($_GET[pluginid]));
        }
		include template('aljlogin:register');
	}
}else if($_GET['act'] == 'forgot'){
	$config = $_G['cache']['plugin']['aljyzm'];
	if(submitcheck('formhash') || $_GET['ticket']){
        if($_G[cache][plugin][aljhtx][verify_appid]){
            $verify_result = T::verify();
            if($verify_result['response'] != 1){
                mall_parenttips($verify_result['err_msg']);
                exit;
            }
        }
		$mobile = addslashes($_GET['lmobile']);
		$mobilecolumn = $config['mobile'];
		if(!ismobile_aljlogin($mobile)){
			mall_parenttips(lang('plugin/aljyzm', 'nocorrect'));
		}
		$checkcode = DB::result_first('select code from %t where phone = %s and status=1 and sendtime+'.$config['time'].'>%d order by sendtime desc',array('aljyzm_mcode',$mobile,TIMESTAMP));

		if(empty($_GET['lmobilecheck']) || $_GET['lmobilecheck'] != $checkcode){
			mall_parenttips(lang('plugin/aljyzm', 'codenocorrect'));
		}


		$password = addslashes($_GET['password']);
		$confirmpassword = addslashes($_GET['confirmpassword']);
		if($_G['setting']['pwlength']) {
			if(strlen($_GET['password']) < $_G['setting']['pwlength']) {
				mall_parenttips(lang('plugin/aljyzm', 'y1').$_G['setting']['pwlength'].lang('plugin/aljyzm', 'y2'));
			}
		}
		if($password != $confirmpassword){
			mall_parenttips(lang('plugin/aljyzm', 'y3'));
		}
		if($_G['setting']['strongpw']) {
			$strongpw_str = array();
			if(in_array(1, $_G['setting']['strongpw']) && !preg_match("/\d+/", $password)) {
				$strongpw_str[] = lang('member/template', 'strongpw_1');
			}
			if(in_array(2, $_G['setting']['strongpw']) && !preg_match("/[a-z]+/", $password)) {
				$strongpw_str[] = lang('member/template', 'strongpw_2');
			}
			if(in_array(3, $_G['setting']['strongpw']) && !preg_match("/[A-Z]+/", $password)) {
				$strongpw_str[] = lang('member/template', 'strongpw_3');
			}
			if(in_array(4, $_G['setting']['strongpw']) && !preg_match("/[^a-zA-z0-9]+/", $password)) {
				$strongpw_str[] = lang('member/template', 'strongpw_4');
			}
			if($strongpw_str) {
				mall_parenttips(lang('member/template', 'password_weak').implode(',', $strongpw_str));
			}
		}
		if(ismobile_aljlogin($mobile)){
			$uid = DB::result_first('select uid from %t where '.$mobilecolumn.' = %s',array('common_member_profile',$mobile));
			if($uid){
				$user = getuserbyuid($uid);
				loaducenter();
				uc_user_edit($user['username'],'',$password,'',1,0,'');
				notification_add($uid, 'system',lang('plugin/aljyzm', 'y6').$user['username'].lang('plugin/aljyzm', 'y7'));

                $url= "plugin.php?id=aljlogin&pluginid=".$pluginid;
				mall_parenttips(lang('plugin/aljyzm', 'y5'),$url);
			}else{
				mall_parenttips(lang('plugin/aljyzm', 'y4'));
			}
		}else{
			mall_parenttips(lang('plugin/aljyzm', 'nocorrect'));
		}
	}else{
		include template('aljlogin:forgot');
	}

}
else {//��¼
	if(submitcheck('formhash') || $_GET['ticket']){
		if($_G[cache][plugin][aljhtx][verify_appid]){
            
            $verify_result = T::verify();
            if($verify_result['response'] != 1){
                mall_parenttips($verify_result['err_msg']);
                exit;
            }
		}
		//�ֻ��ŵ�¼�ж�
		$config = $_G['cache']['plugin']['aljyzm'];
		$mobilecolumn = $config['mobile'];
		if(ismobile_aljlogin($_GET['username']) && $setting_aljlogin['dxyz']){
			$uid = DB::result_first('select uid from %t where '.$mobilecolumn.' = %s',array('common_member_profile',$_GET['username']));
			$user = getuserbyuid($uid);
			$result = mapp_userlogin($user['username'], $_GET['password'],$_GET['questionid'],$_GET['answer']);
			if ($result['status']) {
				if($user){
					require_once libfile('function/member');
					setloginstatus($user, 2592000);
                    $referer = !empty($referer) ? $referer : $_SERVER['HTTP_REFERER'];
                    $referer = $referer ? $referer : $setting_aljlogin['tzurl'];
					mall_parenttips("\u767b\u5f55\u6210\u529f\uff01",$referer);
				}
			}else{
				T::log('['.$_GET['username'].']&#30331;&#24405;&#22833;&#36133;&#65281;');
				mall_parenttips("\u767b\u5f55\u5931\u8d25\uff01");
			}

		}

		//�ֻ��ŵ�¼�жϽ���
		//�û���¼�ж�
		$result = mapp_userlogin($_GET['username'],$_GET['password']);
		if (empty($result['status'])) {
			T::log('['.$_GET['username'].']&#30331;&#24405;&#22833;&#36133;&#65281;');
			mall_parenttips("\u767b\u5f55\u5931\u8d25\uff01");
		}else{
			$user = C::t('common_member')->fetch_by_username($_GET['username']);
			if($user){
				//�Զ���¼
				require_once libfile('function/member');
				setloginstatus($user, 2592000);
				$referer = !empty($referer) ? $referer : $_SERVER['HTTP_REFERER'];
				$referer = $referer ? $referer : $setting_aljlogin['tzurl'];
				mall_parenttips("\u767b\u5f55\u6210\u529f\uff01",$referer);
			}
		}
	}
		//�ֻ��ŵ�¼�жϽ���
	else{
		if($_G['uid']){
			header('Location: '.$setting_aljlogin['tzurl']);
		}

		include template('aljlogin:login');
	}
}

//��֤��¼
function mapp_userlogin($username, $password='', $questionid='', $answer='', $loginfield = 'username', $ip = '') {
	$return = array();

	if($loginfield == 'uid' && getglobal('setting/uidlogin')) {
		$isuid = 1;
	} elseif($loginfield == 'email') {
		$isuid = 2;
	} elseif($loginfield == 'auto') {
		$isuid = 3;
	} else {
		$isuid = 0;
	}

	if(!function_exists('uc_user_login')) {
		loaducenter();
	}
	if($isuid == 3) {
		if(!strcmp(dintval($username), $username) && getglobal('setting/uidlogin')) {
			$return['ucresult'] = uc_user_login($username, $password, 1, 0, $questionid, $answer, $ip);
		} elseif(isemail($username)) {
			$return['ucresult'] = uc_user_login($username, $password, 2, 0, $questionid, $answer, $ip);
		}
		if($return['ucresult'][0] <= 0 && $return['ucresult'][0] != -3) {
			$return['ucresult'] = uc_user_login(addslashes($username), $password, 0, 0, $questionid, $answer, $ip);
		}
	} else {
		$return['ucresult'] = uc_user_login(addslashes($username), $password, $isuid, 0, $questionid, $answer, $ip);
	}
	$tmp = array();
	$duplicate = '';
	list($tmp['uid'], $tmp['username'], $tmp['password'], $tmp['email'], $duplicate) = $return['ucresult'];
	$return['ucresult'] = $tmp;
    if($return['ucresult']['uid'] == '-2'){
    	T::log('['.$username.']&#23494;&#30721;&#38169;&#35823;');
        mall_parenttips("\u5bc6\u7801\u9519\u8bef");
    }
    if($return['ucresult']['uid'] == '-1'){
    	T::log('['.$username.']&#29992;&#25143;&#19981;&#23384;&#22312;');
        mall_parenttips("\u7528\u6237\u4E0D\u5B58\u5728");
    }
	if($duplicate && $return['ucresult']['uid'] > 0 || $return['ucresult']['uid'] <= 0) {
		$return['status'] = 0;
		return $return;
	}

	$member = getuserbyuid($return['ucresult']['uid'], 1);
	if(!$member || empty($member['uid'])) {
		$return['status'] = -1;
		return $return;
	}
	$return['member'] = $member;
	$return['status'] = 1;
	if($member['_inarchive']) {
		C::t('common_member_archive')->move_to_master($member['uid']);
	}
	if($member['email'] != $return['ucresult']['email']) {
		C::t('common_member')->update($return['ucresult']['uid'], array('email' => $return['ucresult']['email']));
	}

	return $return;
}

//��֤ע��
function myregister($username, $return = 0, $groupid = 0,$defaultpassword='',$email='') {
	global $_G;
	if(!$username) {
		return;
	}
    $username = removeEmoji($username);
	loaducenter();
	$pwd = 'PW'.random(6);
	if($defaultpassword){
		$pwd = $defaultpassword;
	}
	$password = md5($pwd);

	$usernamelen = dstrlen($username);

	$censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';

	if($_G['setting']['censoruser'] && @preg_match($censorexp, $username)) {
		if(!$return) {
			return lang('message', 'profile_username_protect');
		} else {
			return 'Registration failed. Please try again!';
		}
	}



	loadcache('ipctrl');
	if($_G['cache']['ipctrl']['ipregctrl']) {
		foreach(explode("\n", $_G['cache']['ipctrl']['ipregctrl']) as $ctrlip) {
			if(preg_match("/^(".preg_quote(($ctrlip = trim($ctrlip)), '/').")/", $_G['clientip'])) {
				$ctrlip = $ctrlip.'%';
				$_G['setting']['regctrl'] = $_G['setting']['ipregctrltime'];
				break;
			} else {
				$ctrlip = $_G['clientip'];
			}
		}
	} else {
		$ctrlip = $_G['clientip'];
	}

	if($_G['setting']['regctrl']) {
		if(C::t('common_regip')->count_by_ip_dateline($ctrlip, $_G['timestamp']-$_G['setting']['regctrl']*3600)) {
			if(!$return) {
				return str_replace('{regctrl}',$_G['setting']['ipregctrltime'],lang('message', 'register_ctrl'));
			} else {
				return 'Registration failed. Please try again!';
			}
		}
	}

	$setregip = null;
	if($_G['setting']['regfloodctrl']) {
		$regip = C::t('common_regip')->fetch_by_ip_dateline($_G['clientip'], $_G['timestamp']-86400);
		if($regip) {
			if($regip['count'] >= $_G['setting']['regfloodctrl']) {
				if(!$return) {
					return lang('message', 'register_flood_ctrl');
				} else {
					return;
				}
			} else {
				$setregip = 1;
			}
		} else {
			$setregip = 2;
		}
	}

	if($setregip !== null) {
		if($setregip == 1) {
			C::t('common_regip')->update_count_by_ip($_G['clientip']);
		} else {
			C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => 1, 'dateline' => $_G['timestamp']));
		}
	}
	$uid = uc_user_register(addslashes($username), $pwd, $email, '', '', $_G['clientip']);

	if($uid <= 0) {
		if(!$return) {
			if($uid == -1) {
				return lang('message', 'profile_username_illegal');
			} elseif($uid == -2) {
				return lang('message', 'profile_username_protect');
			} elseif($uid == -3) {
				return lang('message', 'profile_username_duplicate');
			} elseif($uid == -4) {
				return lang('message', 'profile_email_illegal');
			} elseif($uid == -5) {
				return lang('message', 'profile_email_domain_illegal');
			} elseif($uid == -6) {
				return lang('message', 'profile_email_duplicate');
			} else {
				return lang('message', 'undefined_action');
			}
		} else {
			return 'Registration failed. Please try again!';
		}
	}

	$init_arr = array('credits' => explode(',', $_G['setting']['initcredits']));
	C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);
	//������̳��ҳ  ��ӭ���û�
	require_once libfile('cache/userstats', 'function');
	build_cache_userstats();
	if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
		C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72)*3600);
		if($_G['setting']['regctrl']) {
			C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
		}
	}

	if($_G['setting']['regverify'] == 2) {
		C::t('common_member_validate')->insert(array(
			'uid' => $uid,
			'submitdate' => $_G['timestamp'],
			'moddate' => 0,
			'admin' => '',
			'submittimes' => 1,
			'status' => 0,
			'message' => '',
			'remark' => '',
		), false, true);
		manage_addnotify('verifyuser');
	}

	//ͳ��
	include_once libfile('function/stat');
	updatestat('register');
	return array(
		'uid' => $uid,
		'username' => $username,
		'password' => $pwd,
		'groupid' => $groupid,
	);
}
function removeEmoji($text) {
	//$text = preg_replace("#(\\\ue[0-9a-f]{3})#ie","",$text);
    //return $text;
	if(strtolower(CHARSET) == 'gbk'){
		$text = diconv($text,CHARSET,'UTF-8');
	}
	$clean_text = "";
	// Match Emoticons
	$regexEmoticons = '/[\x{1F600}-\x{1F64F}]/u';
	$clean_text = preg_replace($regexEmoticons, '', $text);
	// Match Miscellaneous Symbols and Pictographs
	$regexSymbols = '/[\x{1F300}-\x{1F5FF}]/u';
	$clean_text = preg_replace($regexSymbols, '', $clean_text);
	// Match Transport And Map Symbols
	$regexTransport = '/[\x{1F680}-\x{1F6FF}]/u';
	$clean_text = preg_replace($regexTransport, '', $clean_text);
	// Match Miscellaneous Symbols
	$regexMisc = '/[\x{2600}-\x{26FF}]/u';
	$clean_text = preg_replace($regexMisc, '', $clean_text);
	// Match Dingbats
	$regexDingbats = '/[\x{2700}-\x{27BF}]/u';
	$clean_text = preg_replace($regexDingbats, '', $clean_text);
	if(strtolower(CHARSET) == 'gbk'){
		$clean_text = diconv($clean_text,'UTF-8',CHARSET);
	}
	return $clean_text;
}
function ismobile_aljlogin($mobile) {
	global $_G;
    if (!is_numeric($mobile)) {
        return false;
    }
    if($_G['cache']['plugin']['aljhtx']['regular']){
        $regular = $_G['cache']['plugin']['aljhtx']['regular'];
    }else{
        $regular = '#^13[\d]{9}$|^14[5,7]{1}\d{8}$|^15[^4]{1}\d{8}$|^16[6]{1}\d{8}$|^17[0,1,3,5,6,7,8]{1}\d{8}$|^18[\d]{9}$|^19[8,9]{1}\d{8}$#';
    }
    return preg_match($regular, $mobile) ? true : false;
}
function mall_parenttips($tips,$url=''){
	echo "<script>parent.tips('".$tips."','".$url."');</script>";
	exit;
}
