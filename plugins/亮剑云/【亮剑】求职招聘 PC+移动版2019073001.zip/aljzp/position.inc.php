<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$pluginid='aljzp';
$act = $_GET['act'];
if($act == 'del' && $_GET['formhash'] == formhash()) {
	$tid = intval($_GET['tid']);
	if($tid) {
		$upcid = C::t('#aljzp#aljzp_position')->fetch_upid_by_id($tid);
		if($upcid) {
			$subid = C::t('#aljzp#aljzp_position')->fetch_subid_by_id($upcid);
			$subarr = explode(",", $subid);
			foreach($subarr as $key=>$value) {
				if($value == $tid) {
					unset($subarr[$key]);
					break;
				}
			}
			C::t('#aljzp#aljzp_position')->update($upcid,array('subid'=>implode(",", $subarr)));
		}
		C::t('#aljzp#aljzp_position')->delete($tid);
	}
	cpmsg(lang('plugin/aljzp','aljzp_7'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljzp&pmod=position', 'succeed');	
}

if(!submitcheck('editsubmit')) {	

?>
<script type="text/JavaScript">
var rowtypedata = [
	[[1,'<input type="text" class="txt" name="newcatorder[]" value="0" />', 'td25'], [2, '<input name="newcat[]" value="" size="20" type="text" class="txt" />']],
	[[1,'<input type="text" class="txt" name="newsuborder[{1}][]" value="0" />', 'td25'], [2, '<div class="board"><input name="newsubcat[{1}][]" value="" size="20" type="text" class="txt" /></div>']],
	
	];

function del(id) {
	if(confirm('<?php echo lang('plugin/aljzp','position_1');?>')) {
		window.location = '<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=aljzp&pmod=position&act=del&tid='+id+'&formhash=<?php echo FORMHASH;?>';
	} else {
		return false;
	}
}
</script>
<?php
	showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier=aljzp&pmod=position&page='.$_GET['page']);
	showtableheader('');
	showsubtitle(array(lang('plugin/aljzp','position_2'),lang('plugin/aljzp','position_3'),lang('plugin/aljzp','position_4')));
	$currpage = $_GET['page'] ? $_GET['page'] : 1;
    $perpage = 10;
	$start = ($currpage - 1) * $perpage;
	$num=C::t('#'.$pluginid.'#'.$pluginid.'_position')->count_by_upid(0,$search);
	$position = C::t('#'.$pluginid.'#'.$pluginid.'_position')->fetch_all_by_upid(0,$start,$perpage,$search);
	foreach($position as $key=>$value){

		$bt = C::t('#aljzp#aljzp_position')->fetch_all_by_upid($key);
		foreach($bt as $k=>$v){
			$position[$key]['subtype'][$k] = $v;
		}
	}
	if($position) {
		foreach($position as $id=>$type) {
			$show = '<tr class="hover"><td class="td25"><input type="text" class="txt" name="order['.$id.']" value="'.$type['displayorder'].'" /></td><td><div class="parentboard"><input type="text" class="txt" name="name['.$id.']" value="'.$type['subject'].'"></div></td>';
			if(!$type['subid']) {
				$show .= '<td><a  onclick="del('.$id.')" href="###">'.lang('plugin/aljzp','position_5').'</td></tr>';
			} else {
				$show .= '<td>&nbsp;</td></tr>';
			}
			echo $show;
			if($type['subtype']) {
				foreach($type['subtype'] as $subid=>$stype) {
					echo '<tr class="hover"><td class="td25"><input type="text" class="txt" name="order['.$subid.']" value="'.$stype['displayorder'].'" /></td><td><div class="board"><input type="text" class="txt" name="name['.$subid.']" value="'.$stype['subject'].'"></div></td><td><a  onclick="del('.$subid.')" href="###">'.lang('plugin/aljzp','position_5').'</td></tr>';
				}
				
			}
			echo '<tr class="hover"><td class="td25">&nbsp;</td><td colspan="2" ><div class="lastboard"><a href="###" onclick="addrow(this, 1,'.$id.' )" class="addtr">'.lang('plugin/aljzp','position_8').'</a></div></td></tr>';
		}	
	}
	echo '<tr class="hover"><td class="td25">&nbsp;</td><td colspan="2" ><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.lang('plugin/aljzp','position_6').'</a></div></td></tr>';
	
	$paging = helper_page :: multi($num, $perpage, $currpage, "admin.php?action=plugins&operation=config&do=".$_GET['do']."&identifier=".$pluginid."&pmod=position", 0, 10, false, false);
	showsubmit('editsubmit','&#25552;&#20132;','','',$paging);
	showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*dis'.'m.tao'.'bao.com*/

} else {
	$order = $_GET['order'];
	$name = $_GET['name'];
	$newsubcat = $_GET['newsubcat'];
	$newcat = $_GET['newcat'];
	$newsuborder = $_GET['newsuborder'];
	$newcatorder = $_GET['newcatorder'];
	if(is_array($order)) {
		foreach($order as $id=>$value) {
			C::t('#aljzp#aljzp_position')->update($id,array('displayorder'=>$value,'subject'=>$name[$id]));
		}
	}

	if(is_array($newcat)) {
		foreach($newcat as $key=>$name) {
			if(empty($name)) {
				continue;
			}
			$cid=C::t('#aljzp#aljzp_position')->insert(array('upid' => '0', 'subject' => $name, 'displayorder' => $newcatorder[$key]),1);
		}
	}

	if(is_array($newsubcat)) {
		foreach($newsubcat as $cid=>$subcat) {
			$sub=C::t('#aljzp#aljzp_position')->fetch($cid);
			$subtype =$sub['subid'];
			foreach($subcat as $key=>$name) {
				$subid=C::t('#aljzp#aljzp_position')->insert(array('upid' => $cid, 'subject' => $name, 'displayorder' => $newsuborder[$cid][$key]),1);
				$subtype .= $subtype ? ','.$subid : $subid;
			}
			C::t('#aljzp#aljzp_position')->update($cid,array('subid'=>$subtype));
		}
	}

	cpmsg(lang('plugin/aljzp','position_7'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljzp&pmod=position&page='.$_GET['page'], 'succeed');	
}
//From: DisM. taobao. Com
?>


