<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$pluginid='aljzp';
require_once 'source/plugin/'.$pluginid.'/lang/lang.php';
$login_callback = 'member.php?mod=logging&action=login&referer=plugin.php?id='.$pluginid.'%26act='.$_GET['act'];
$_GET=dhtmlspecialchars($_GET);
require_once libfile('function/discuzcode');
require_once 'source/plugin/aljzp/function/function_core.php';
include_once libfile('function/editor');
require_once DISCUZ_ROOT.'source/plugin/aljzp/class/qrcode.class.php';
if (file_exists("source/plugin/aljzp/template/com/qrcode.php")) {
    if (!file_exists("source/plugin/aljzp/images/qrcode/aljzp_qrcode.jpg")) {
        include 'source/plugin/aljzp/template/com/qrcode.php';
    }
}
if(!function_exists('sendmail')) {
	include libfile('function/mail');
}
$actarray = array('view','ask','list','upload','mupload','mobile_deleteattach','mobile_list_region','mobile_list_region_r','mobile_list_type','mobile_list_type_r','mobile_index_goods','search','companylist','company','resumes','all');
if($_GET['act'] && !in_array($_GET['act'],$actarray)){
	if(!$_G['uid']){
		//showmessage(lang('plugin/aljzp','aljzp_1'), $login_callback);
		dheader("location:".$login_callback);
	}
}

if ($_G['uid']) {
    if (!C::t('#aljzp#aljzp_user')->fetch($_G['uid'])) {
        C::t('#aljzp#aljzp_user')->insert(array('uid' => $_G['uid'], 'username' => $_G['username'], 'dateline' => TIMESTAMP, 'last' => TIMESTAMP));
    } else {
        C::t('#aljzp#aljzp_user')->update_last_by_uid($_G['uid']);
    }
}

if (!C::t('#aljzp#aljzp_log')->fetch(gmdate('Ymd', TIMESTAMP))) {
    C::t('#aljzp#aljzp_log')->insert(array('day' => gmdate('Ymd', TIMESTAMP), 'views' => 1));
} else {
    C::t('#aljzp#aljzp_log')->update_views_by_day(gmdate('Ymd', TIMESTAMP));
}
$aljzp_seo = dunserialize($_G['setting']['aljzp_seo']);
$settings=C::t('#aljzp#aljzp_setting')->range();
if($settings['iswatermark']['value']){
	require_once DISCUZ_ROOT.'source/plugin/aljzp/class/class_image.php';
	$image = new aljbd_image;
}

$config = $_G['cache']['plugin']['aljzp'];
$pc_top_dh = explode ("\n", str_replace ("\r", "", $settings['pc_top_dh']['value']));

$index_dh = explode ("\n", str_replace ("\r", "", $config ['index_dh']));
foreach($index_dh as $key=>$value){
	$arr=explode('|',$value);
	$index_dh_types[$arr[0]]=$arr[1];
}
$typelist = explode ("\n", str_replace ("\r", "", $config ['pinpai']));
foreach($typelist as $key=>$value){
	$arr=explode('=',$value);
	$types[$arr[0]]=$arr[1];
}
$zufangtype = $types;
$new_list = explode ("\n", str_replace ("\r", "", $config ['new']));
foreach($new_list as $key=>$value){
	$new_arr=explode('=',$value);
	$new_types[$new_arr[0]]=$new_arr[1];
}
$xuelilist = explode ("\n", str_replace ("\r", "", $config ['xueli']));
foreach($xuelilist as $key=>$value){
	$arr=explode('=',$value);
	$xl_types[$arr[0]]=$arr[1];
}
$work_nxlist = explode ("\n", str_replace ("\r", "", $config ['work_nx']));
foreach($work_nxlist as $key=>$value){
	$arr=explode('=',$value);
	$nx_types[$arr[0]]=$arr[1];
}

$work_timelist = explode ("\n", str_replace ("\r", "", $config ['work_time']));
foreach($work_timelist as $key=>$value){
	$arr=explode('=',$value);
	$wtime_types[$arr[0]]=$arr[1];
}
$paylist = explode ("\n", str_replace ("\r", "", $config ['pays']));
foreach($paylist as $key=>$value){
	$arr=explode('=',$value);
	$pay_types[$arr[0]]=$arr[1];
}
$respaylist = explode ("\n", str_replace ("\r", "", $config ['pay']));
foreach($respaylist as $key=>$value){
	$arr=explode('=',$value);
	$respay_types[$arr[0]]=$arr[1];
}
$lblist = explode ("\n", str_replace ("\r", "", $config ['lb']));
foreach($lblist as $key=>$value){
	$arr=explode('=',$value);
	$lb_types[$arr[0]]=$arr[1];
}
$shengming=str_replace ("{sitename}", $_G['setting']['bbname'], $config ['shengming']);
$list_daohang=explode('|',$config['list_daohang']);
$pos_zw = C::t('#aljzp#aljzp_position')->range();
$sshylist = explode ("\n", str_replace ("\r", "", $config ['suoshuhangye']));
foreach($sshylist as $key=>$value){
	$arr=explode('=',$value);
	$suoshuhangye[$arr[0]]=$arr[1];
}
$gsxzlist = explode ("\n", str_replace ("\r", "", $config ['gongsixingzhi']));
foreach($gsxzlist as $key=>$value){
	$arr=explode('=',$value);
	$gongsixingzhi[$arr[0]]=$arr[1];
}
$gsgmlist = explode ("\n", str_replace ("\r", "", $config ['gongsiguimo']));
foreach($gsgmlist as $key=>$value){
	$arr=explode('=',$value);
	$gongsiguimo[$arr[0]]=$arr[1];
}

$regions = C::t('#aljzp#aljzp_region')->range();
if($settings['image_path']['value']){
	$image_path = $settings['image_path']['value'];
}else{
	$image_path = 'source/plugin/'.$pluginid.'/images/logo/';
}
if($settings['pc_integral_recharge']['value']){
	$pc_integral_recharge = '<a href="'.str_replace(':','&#58;',$settings['pc_integral_recharge']['value']).'">'.$aljzplang['php']['To_recharge'].'</a>';
}
if($settings['mobile_integral_recharge']['value']){
	$mobile_integral_recharge = htmlspecialchars_decode($settings['mobile_integral_recharge']['value']);
}
$lid = intval($_GET['lid']);
if($_GET['act'] == 'user'){
	include template('aljzp:user');
}else if($_GET['act'] == 'search'){
	include template($pluginid.':search');
}else if ($_GET['act'] == 'mgetregion') {

    if ($_GET['upid']) {
        $rs = C::t('#'.$pluginid.'#'.$pluginid.'_region')->fetch_all_by_upid($_GET['upid']);
    }

    include template($pluginid.':getregion');
}else if($_GET['act']=='mobile_delete'){
	$user=C::t('#aljzp#aljzp')->fetch($_GET['lid']);
	$url='plugin.php?id=aljzp&act=delete&lid='.$_GET['lid'];
	include template('aljzp:state');
}else if($_GET['act']=='admingetregion'){
	if($_GET['upid']){
		$rlist=C::t('#aljzp#aljzp_region')->fetch_all_by_upid_sys($_GET['upid']);
	}
	include template('aljzp:admingetregion');
}else if($_GET['act']=='admingetregion1'){
	if($_GET['upid']){
		$rlist=C::t('#aljzp#aljzp_region')->fetch_all_by_upid_sys($_GET['upid']);
	}
	include template('aljzp:admingetregion1');
}else if($_GET['act'] == 'collection'){
	if(!$_G['uid']){
		showmessage(lang('plugin/aljzp','aljzp_1'), '', array(), array('login' => true));
	}
	if (empty($_GET['lid'])) {
        showmessage(lang('plugin/aljzp','aljzp_6'));
    }
	C::t('#aljzp#aljzp_collection')->insert(array(
		'lid'=>$_GET['lid'],
		'uid'=>$_G['uid'],
		'dateline'=>TIMESTAMP,
	));
	showmessage(lang('plugin/aljzp','The_success_of'),'plugin.php?id=aljzp&act=view&lid='.$_GET['lid']);
}else if($_GET['act'] == 'collection_list'){
	if(!$_G['uid']){
		showmessage(lang('plugin/aljzp','aljzp_1'), '', array(), array('login' => true));
	}
	$currpage = $_GET['page'] ? $_GET['page'] : 1;
    $perpage = $config['page'];
    $num = DB::result_first('select count(*) from %t where uid=%d',array('aljzp_collection',$_G['uid']));
    $start = ($currpage - 1) * $perpage;

    $logs = DB::fetch_all('select * from %t where uid=%d limit %d,%d',array('aljzp_collection',$_G['uid'],$start,$perpage));
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljzp&act=collection_list', 0, 11, false, false);
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljzp_seo['collection']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzp_seo['collection']);
	}
	include template('aljzp:collection_list');
} else if ($_GET['act'] == 'collection_del') {
	$user=C::t('#aljzp#aljzp_collection')->fetch($_GET['cid']);
	if($user['uid']!=$_G['uid']&&$_G['groupid']!=1){
		showmessage(lang('plugin/aljzp','aljzp_8'));
	}
    C::t('#aljzp#aljzp_collection')->delete($_GET['cid']);
    showmessage(lang('plugin/aljzp','aljzp_7'), 'plugin.php?id=aljzp&act=collection_list');
}else if($_GET['act'] == 'solve'){
	if (empty($_GET['lid'])) {
        showmessage(lang('plugin/aljzp','aljzp_10'));
    }

	if($_GET['formhash'] == formhash()){
		$user=C::t('#aljzp#aljzp')->fetch($_GET['lid']);
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			if (submitcheck('submit')) {
				if($_GET['solve']=='re'){
					C::t('#aljzp#aljzp')->update($_GET['lid'], array('solve'=>'0'));
					showmessage(lang('plugin/aljzp','The_re_release_of_success'),'plugin.php?id=aljzp&act=member');
				}else{
					C::t('#aljzp#aljzp')->update($_GET['lid'], array('solve'=>'1'));
					showmessage(lang('plugin/aljzp','To_get_success!'),'plugin.php?id=aljzp&act=member');
				}
			}else{
				if($_GET['re']=='1'){
					$url='plugin.php?id=aljzp&act=solve&lid='.$_GET['lid'].'&solve=re';
				}else{
					$url='plugin.php?id=aljzp&act=solve&lid='.$_GET['lid'];
				}
				include template('aljzp:state');
			}
		}else{
			if($_GET['solve']=='re'){
				C::t('#aljzp#aljzp')->update($_GET['lid'], array('solve'=>'0'));
				showmessage(lang('plugin/aljzp','The_re_release_of_success'),'plugin.php?id=aljzp&act=member');
			}else{
				C::t('#aljzp#aljzp')->update($_GET['lid'], array('solve'=>'1'));
				showmessage(lang('plugin/aljzp','To_get_success!'),'plugin.php?id=aljzp&act=member');
			}
		}
	}
}else if($_GET['act'] == 'posts'){
	$currpage = $_GET['page'] ? $_GET['page'] : 1;
	$perpage = 10;

	$start = ($currpage - 1) * $perpage;
	if($_G['uid']){

		$conndtion = array(
			'uid' => $_G['uid'],
		);
		$num = C::t('#aljzp#aljzp')->count_by_status($conndtion);
		$lplist = C::t('#aljzp#aljzp')->fetch_all_by_addtime($start, $perpage, $conndtion);
		foreach($lplist as $k=>$v){
			$lplist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
		}
		$lplist = dhtmlspecialchars($lplist);
	}

	$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljzp&act=posts', 0, 11, false, false);
	include template('aljzp:posts');
}else if ($_GET['act'] == 'post') {
    if (submitcheck('formhash')) {
        if (empty($_GET['title'])) {
			if($_GET['sj']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_2')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','aljzp_2'));
			}
        }
		if (empty($_GET['pos'])) {
			if($_GET['sj']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_22')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','aljzp_22'));
			}
        }

		if (empty($_GET['region'])) {
			if($_GET['sj']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_24')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','aljzp_24'));
			}
        }
		if(!is_mobile_l($_GET['contact']) && !file_exists("source/plugin/nydz/nydz.inc.php")){
			if($_GET['sj']){
				echo "<script>parent.tips('&#30005;&#35805;&#26684;&#24335;&#19981;&#23545;','');</script>";
				exit;
			}else{
				showerror('&#30005;&#35805;&#26684;&#24335;&#19981;&#23545;');
			}
		}
		if (empty($_GET['contact'])) {
			if($_GET['sj']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_25')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','aljzp_25'));
			}
        }
		if($settings['is_form']['value']){
			if(DB::result_first('select count(*) from %t where title = %s',array($pluginid,$_GET['title']))){
				if($_GET['sj']){
					echo "<script>parent.tips('&#27492;&#25307;&#32856;&#24050;&#23384;&#22312;','');</script>";
					exit;
				}else{
					showerror('&#27492;&#25307;&#32856;&#24050;&#23384;&#22312;');
				}
			}
			if(!valid_token($_GET['aljzp_token'],getcookie('aljzp_token'),'aljzp_token')){
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#27491;&#22312;&#21069;&#24448;&#20449;&#24687;&#31649;&#29702;&#46;&#46;&#46;',function(){parent.location.href='plugin.php?id=aljzp&act=member';});</script>";
					exit;
				}else{
					showerror('&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#35831;&#37325;&#26032;&#21047;&#26032;&#39029;&#38754;&#22635;&#20889;&#34920;&#21333;&#25110;<a href="plugin.php?id=aljzp&act=member">&#36820;&#22238;&#20449;&#24687;&#31649;&#29702;&#26597;&#30475;&#20449;&#24687;</a>');
				}
			}
		}
		if($config['isnewupload']){
			$aids = addslashes($_GET['aid']);
			if($aids){
				if($aids){
					$attachments = DB::fetch_all('select * from %t where aid in (%i) order by aid asc',array('aljzp_attachment',$aids));
				}
				$pic = 1;
				foreach($attachments as $i => $attach){
					$c = $i+1;
					if($i>8){
						break;
					}
					$pic = 'pic' . $c;
					$$pic = $attach['pic'];
				}
			}
		}else{
			for ($i = 1; $i <= 8; $i++) {
				$pic = 'pic' . $i;
				if ($_FILES[$pic]['tmp_name']) {
					$picname = $_FILES[$pic]['name'];
					$picsize = $_FILES[$pic]['size'];
					if ($picsize/1024>$config['img_size']) {
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_11').$config['img_size']."K','');</script>";
							exit;
						}else{
							showerror(lang('plugin/aljzp','aljzp_11').$config['img_size'].'K');
						}
					}
					if ($picname != "") {
						$type = strtolower(strrchr($picname, '.'));
						if ($type != ".gif" && $type != ".jpg" && $type != ".png" && $type != ".jpeg") {
							if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
								echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_3')."','');</script>";
								exit;
							}else{
								showerror(lang('plugin/aljzp','aljzp_3'));
							}
						}
						$rand = rand(100, 999);
						$pics = date("YmdHis") . $rand . $type;
						$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
						if (!is_dir($img_dir)) {
							if(!mkdir($img_dir)){
								if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
									echo "<script>parent.tips('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;','');</script>";
									exit;
								}else{
									showerror('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;');
								}
							}
						}
						$$pic = $img_dir . $pics;
						if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
							$imageinfo = getimagesize($$pic);
							if($settings['iswatermark']['value']){
								$image->Watermark(DISCUZ_ROOT.'./'.$$pic,'', 'forum');
							}
							$w64 = $imageinfo[0] < 64 ? $imageinfo[0] : 64;
							$h64 = $imageinfo[1] < 64 ? $imageinfo[1] : 64;
							$w100 = $imageinfo[0] < 100 ? $imageinfo[0] : 100;
							$h100 = $imageinfo[1] < 100 ? $imageinfo[1] : 100;
							$w640 = $imageinfo[0] < 640 ? $imageinfo[0] : 640;
							$h480 = $imageinfo[1] < 480 ? $imageinfo[1] : 480;
							img2thumb($$pic, $$pic . '.100x100.jpg', $w100, $h100);
							img2thumb($$pic, $$pic . '.64x64.jpg', $w64, $h64);
							img2thumb($$pic, $$pic . '.640x480.jpg', $w640, $h480);
							@unlink($_FILES[$pic]['tmp_name']);
						}
					}
				}
			}
		}

		if($config['isreview']  && !in_array($_G['groupid'],unserialize($config['mian_groups']))){
			$state=1;
		}
        $insertarray = array(
            'wanted' => $_GET['wanted'],
            'title' => $_GET['title'],
            'zufangtype' => $_GET['zufangtype'],
            'qq' => $_GET['qq'],
            'new' => $_GET['new'],
            'content' => $_GET['content'],
            'lxr' => $_GET['lxr'],
            'region' => $_GET['region'],
            'region1' => $_GET['region1'],
            'region2' => $_GET['region2'],
            'region3' => $_GET['region3'],
            'contact' => $_GET['contact'],
            'pos' => $_GET['pos'],
            'pos1' => $_GET['pos1'],
            'work_nx' => $_GET['work_nx'],
            'xueli' => $_GET['xueli'],
            'sex' => $_GET['sex'],
            'work_time' => $_GET['work_time'],
            'renshu' => $_GET['renshu'],
            'email' => $_GET['email'],
            'gongsi' => $_GET['gongsi'],
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'addtime' => TIMESTAMP,
            'updatetime' => TIMESTAMP,
			'phone' =>  $_G['mobile'],
			'state' =>  $state,
			'clientip' => $_G['clientip'],
        );
		if(file_exists("source/plugin/nydz/nydz.inc.php")){
			include 'source/plugin/nydz/include/post.php';
		}else{
			$insertarray['pay'] = $_GET['zujin'];
		}

        for ($i = 1; $i <= 8; $i++) {
            $pic = 'pic' . $i;
            if ($$pic) {
                $insertarray[$pic] = $$pic;
            }
        }
		if (file_exists("source/plugin/aljzp/template/com/release.php") && $config['releaseextcredit']) {
			include 'source/plugin/aljzp/template/com/release.php';
		}
        $insertid = C::t('#aljzp#aljzp')->insert($insertarray, true);
		if($config['isnewupload']){
			foreach($attachments as $attach){
				$updatearray['pid'] = $insertid;
				$updatearray['pic'] = $attach['pic'];
				C::t('#aljzp#aljzp_attachment') -> update($attach['aid'],$updatearray);
			}
		}
		if ((file_exists("source/plugin/aljzp/template/com/tongbu.php")&&!$config['isreview'])  || (file_exists("source/plugin/aljzp/template/com/tongbu.php")&&in_array($_G['groupid'],unserialize($config['mian_groups'])))) {
			include 'source/plugin/aljzp/template/com/tongbu.php';
		}
        C::t('#aljzp#aljzp_user')->update_count_by_uid($_G['uid']);

		if($config['isreview'] && !in_array($_G['groupid'],unserialize($config['mian_groups']))){
			$groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
			foreach($groupids as $g_uid){
				notification_add($g_uid['uid'], 'system','&#24744;&#26377;&#19968;&#26465;&#25307;&#32856;&#26032;&#30340;&#23457;&#26680;&#20449;&#24687;&#65292;&#35831;&#21040;&#21518;&#21488;&#23613;&#24555;&#23457;&#26680;&#12290;',array('from_idtype'  => 'aljzp','from_id' => $insertid));
			}
			if($_GET['sj']){
				echo "<script>parent.tips('".lang('plugin/aljzp','To_examine')."',function(){parent.location.href='plugin.php?id=aljzp&act=view&lid=".$insertid."';});</script>";
			}else{
				showmsg(lang('plugin/aljzp','To_examine'), 2, $insertid);
			}
		}else{
			if($_GET['sj']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_4')."',function(){parent.location.href='plugin.php?id=aljzp&act=view&lid=".$insertid."';});</script>";
			}else{
				showmsg(lang('plugin/aljzp','aljzp_4'), 2, $insertid);
			}
		}

    } else {
		if(!$_G['uid']){
			showmessage(lang('plugin/aljzp','aljzp_1'), '', array(), array('login' => true));
		}
		//���������û���
		if(!in_array($_G['groupid'],unserialize($config['lj_groups']))){
				showmessage($config['lj_tsy']);
		}
		//����̳�ֻ���
		if($settings['is_forum_mobile']['value']){
			$profile = DB::fetch_first('select * from %t where uid=%d',array('common_member_profile',$_G['uid']));
			if(empty($profile['mobile'])){
				showmessage('&#35831;&#20808;&#32465;&#23450;&#35770;&#22363;&#25163;&#26426;&#21495;&#21518;&#25165;&#33021;&#21457;&#24067;&#20449;&#24687;','home.php?mod=spacecp&ac=profile&op=contact');
			}
		}
		//��֤
		$rz = DB::result_first("select count(*) from ".DB::table($pluginid.'_attestation')." where sign=1 and uid=".$_G['uid']);
		date_default_timezone_set('PRC');//�л����񹲺͹�ʱ��
		$todaytimestamp = strtotime(gmdate('Y-m-d 00:00:00',TIMESTAMP+3600*8));
		$post_num = DB :: result_first('select count(*) from %t where uid=%d and addtime>=%d',array($pluginid,$_G['uid'],$todaytimestamp));
		if(file_exists("source/plugin/aljzp/template/com/attestation.php")){//��
			if($config['isrenzheng']){
				if(!DB::result_first("select count(*) from ".DB::table('aljzp_attestation')." where sign=1 and uid=".$_G['uid'])){
					showmessage(lang('plugin/aljzp','aljzp_12'),'plugin.php?id=aljzp&act=attestation');
				}
			}else{
				if($settings['no_rz_post_num']['value']&&!$rz){

					if($post_num >= $settings['no_rz_post_num']['value']){
						showmessage('&#27599;&#22825;&#21482;&#20801;&#35768;&#21457;&#24067;'.$settings['no_rz_post_num']['value'].'&#26465;&#20449;&#24687;');
					}
				}
			}
		}
		if($rz){
			if($settings['rz_post_num']['value']){
				if($post_num >= $settings['rz_post_num']['value']){
					showmessage('&#27599;&#22825;&#21482;&#20801;&#35768;&#21457;&#24067;'.$settings['rz_post_num']['value'].'&#26465;&#20449;&#24687;');
				}
			}
		}
		if (file_exists("source/plugin/aljzp/template/com/release.php")) {
			if (getuserprofile('extcredits' . $config['releaseextcredit']) < $config['releasepay'] && $config['releaseextcredit']) {
				if($_G['mobile']){
					showmessage($_G['setting']['extcredits'][$config['releaseextcredit']]['title'] . lang('plugin/aljzp','top_1'),$mobile_integral_recharge);
				}else{
					showmessage($_G['setting']['extcredits'][$config['releaseextcredit']]['title'] . lang('plugin/aljzp','top_1').$pc_integral_recharge);
				}
			}
		}

        $rs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid(0);
		$pos = C::t('#aljzp#aljzp_position')->fetch_all_by_upid(0);
		if($config['isnewupload']){
			require_once libfile('function/upload');
			$swfconfig = getuploadconfig($_G['uid'], 0, false);
		}
		$navtitle = $config['title'];
		$metakeywords = $config['keywords'];
		$metadescription = $config['description'];
		if($aljzp_seo['post']['seotitle']){
			$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
			list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzp_seo['post']);
		}
        include template('aljzp:post');
    }
} else if ($_GET['act'] == 'edit') {
    if (submitcheck('formhash')) {
        if (empty($_GET['title'])) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_2')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','aljzp_2'));
			}
        }
		$lid = intval($_GET['lid']);
		if(empty($lid)){
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljzp','edittips')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','edittips'));
			}
		}
		$lp = C::t('#aljzp#aljzp')->fetch($lid);
		if($settings['is_form']['value'] && $lp['title'] != trim($_GET['title'])){
			if(DB::result_first('select count(*) from %t where title = %s',array($pluginid,$_GET['title']))){
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('&#26631;&#39064;&#24050;&#23384;&#22312;','');</script>";
					exit;
				}else{
					showerror('&#26631;&#39064;&#24050;&#23384;&#22312;');
				}
			}
		}
		if($config['isnewupload']){
			//DB::query("update %t set pic1='',pic2='',pic3='',pic4='',pic5='',pic6='',pic7='',pic8='' where id=%d",array('aljzp',$lid));
			$aids = addslashes($_GET['aid']);
			if($aids){
				$attachments = DB::fetch_all('select * from %t where aid in (%i) order by aid asc',array('aljzp_attachment',$aids));
			}
			$pic = 1;
			foreach($attachments as $i => $attach){
				$c = $i+1;
				if($i>8){
					break;
				}
				$pic = 'pic' . $c;
				$$pic = $attach['pic'];
			}
		}else{
			for ($i = 1; $i <= 8; $i++) {
				$pic = 'pic' . $i;
				if ($_FILES[$pic]['tmp_name']) {
					$picname = $_FILES[$pic]['name'];
					$picsize = $_FILES[$pic]['size'];

					if ($picsize/1024>$config['img_size']) {
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_11').$config['img_size'].'K'."','');</script>";
							exit;
						}else{
							showerror(lang('plugin/aljzp','aljzp_11').$config['img_size'].'K');
						}

					}
					if ($picname != "") {
						$type = strtolower(strrchr($picname, '.'));
						if ($type != ".gif" && $type != ".jpg" && $type != ".png" && $type != ".jpeg") {

							if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
								echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_3')."','');</script>";
								exit;
							}else{
								showerror(lang('plugin/aljzp','aljzp_3'));
							}
						}
						$rand = rand(100, 999);
						$pics = date("YmdHis") . $rand . $type;
						$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
						if (!is_dir($img_dir)) {
							if(!mkdir($img_dir)){
								if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
									echo "<script>parent.tips('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;','');</script>";
									exit;
								}else{
									showerror('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;');
								}
							}
						}
						$$pic = $img_dir . $pics;
						if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
							$imageinfo = getimagesize($$pic);
							if($settings['iswatermark']['value']){
								$image->Watermark(DISCUZ_ROOT.'./'.$$pic,'', 'forum');
							}
							$w64 = $imageinfo[0] < 64 ? $imageinfo[0] : 64;
							$h64 = $imageinfo[1] < 64 ? $imageinfo[1] : 64;
							$w100 = $imageinfo[0] < 100 ? $imageinfo[0] : 100;
							$h100 = $imageinfo[1] < 100 ? $imageinfo[1] : 100;
							$w640 = $imageinfo[0] < 640 ? $imageinfo[0] : 640;
							$h480 = $imageinfo[1] < 480 ? $imageinfo[1] : 480;
							img2thumb($$pic, $$pic . '.100x100.jpg', $w100, $h100);
							img2thumb($$pic, $$pic . '.64x64.jpg', $w64, $h64);
							img2thumb($$pic, $$pic . '.640x480.jpg', $w640, $h480);
							@unlink($_FILES[$pic]['tmp_name']);
						}
					}
				}
			}
		}


        $insertarray = array(
            'wanted' => $_GET['wanted'],
            'title' => $_GET['title'],
            'zufangtype' => $_GET['zufangtype'],
            'qq' => $_GET['qq'],
            'new' => $_GET['new'],
            'content' => $_GET['content'],
            'lxr' => $_GET['lxr'],
            'region' => $_GET['region'],
            'region1' => $_GET['region1'],
            'region2' => $_GET['region2'],
            'region3' => $_GET['region3'],
            'contact' => $_GET['contact'],
            'pos' => $_GET['pos'],
            'pos1' => $_GET['pos1'],
            'work_nx' => $_GET['work_nx'],
            'xueli' => $_GET['xueli'],
            'sex' => $_GET['sex'],
            'work_time' => $_GET['work_time'],
            'renshu' => $_GET['renshu'],
            'email' => $_GET['email'],
            'gongsi' => $_GET['gongsi'],
        );
		if(file_exists("source/plugin/nydz/nydz.inc.php")){
			include 'source/plugin/nydz/include/post.php';
		}else{
			$insertarray['pay'] = $_GET['zujin'];
		}
        for ($i = 1; $i <= 8; $i++) {
            $pic = 'pic' . $i;
			$del_logo = 'del_logo_'.$i;
			if($_GET[$del_logo]){
				unlink($lp[$pic]);
				unlink($lp[$pic]. '.640x480.jpg');
				unlink($lp[$pic]. '.64x64.jpg');
				unlink($lp[$pic]. '.100x100.jpg');
				$insertarray[$pic] = '';
			}
            if ($$pic) {
                if (empty($$pic)) {
                    $$pic = $_GET[$pic];
                }
				if(!$config['isnewupload']){
					unlink($lp[$pic]);
					unlink($lp[$pic]. '.640x480.jpg');
					unlink($lp[$pic]. '.64x64.jpg');
					unlink($lp[$pic]. '.100x100.jpg');
				}
                $insertarray[$pic] = $$pic;
            }
        }

        C::t('#aljzp#aljzp')->update($_GET['lid'], $insertarray);
		if($config['isnewupload']){
			foreach($attachments as $attach){
				$updatearray['pid'] = $_GET['lid'];
				$updatearray['pic'] = $attach['pic'];
				C::t('#aljzp#aljzp_attachment') -> update($attach['aid'],$updatearray);
			}
		}
        C::t('#aljzp#aljzp_user')->update_updatecount_by_uid($_G['uid']);
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".str_replace('\\','',lang('plugin/aljzp','aljzp_5'))."',function(){parent.location.href='plugin.php?id=aljzp&act=view&lid=".$_GET['lid']."';});</script>";
		}else{
			showmsg(str_replace('\\','',lang('plugin/aljzp','aljzp_5')), 2, $_GET['lid']);
		}
    } else {
		$lid = intval($_GET['lid']);
        $rs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid(0);
		if($lid){
			$attachments = DB::fetch_all('select * from %t where pid = %d  order by aid asc',array('aljzp_attachment',$lid));
			foreach($attachments as $at){
				$taids[] = $at['aid'];
			}
			$taids = implode(',',$taids);
			$lp = C::t('#aljzp#aljzp')->fetch($lid);
		}
        //debug($attachments);
		if($lp['uid']!=$_G['uid']&&$_G['groupid']!=1){
			showmessage(lang('plugin/aljzp','aljzp_8'));
		}
        $ps = explode(',', $lp['peizhi']);
        if ($lp['region']) {
            $rrs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid($lp['region']);
        }
		$pos = C::t('#aljzp#aljzp_position')->fetch_all_by_upid(0);
		if ($lp['pos']) {
            $prs = C::t('#aljzp#aljzp_position')->fetch_all_by_upid($lp['pos']);
        }
		if($config['isnewupload']){
			require_once libfile('function/upload');
			$swfconfig = getuploadconfig($_G['uid'], 0, false);
		}
		$navtitle = $config['title'];
		$metakeywords = $config['keywords'];
		$metadescription = $config['description'];
		if($aljzp_seo['edit']['seotitle']){
			$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
			list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzp_seo['edit']);
		}
        include template('aljzp:post');
    }
}else if($_GET['act'] == 'myresume'){

	if (submitcheck('formhash')) {
		if (empty($_GET['title'])) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_2')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','aljzp_2'));
			}
        }
		if (empty($_GET['name'])) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_2')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','aljzp_2'));
			}
        }
		if (empty($_GET['pos'])) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('&#24847;&#21521;&#32844;&#20301;&#24517;&#39035;&#36873;&#25321;','');</script>";
				exit;
			}else{
				showerror('&#24847;&#21521;&#32844;&#20301;&#24517;&#39035;&#36873;&#25321;');
			}
        }
		if (empty($_GET['sex'])) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_26')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','aljzp_26'));
			}
        }
		if(!is_mobile_l($_GET['tel'])){
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('&#30005;&#35805;&#26684;&#24335;&#19981;&#23545;','');</script>";
				exit;
			}else{
				showerror('&#30005;&#35805;&#26684;&#24335;&#19981;&#23545;');
			}
		}
		if (empty($_GET['ymd'])) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_27')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','aljzp_27'));
			}
        }
		$agecha = date('Y',TIMESTAMP)-18;

		if ((TIMESTAMP - strtotime($_GET['ymd']))/86400/365 < 18 || !strtotime($_GET['ymd'])) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('&#20986;&#29983;&#24180;&#35831;&#36873;&#25321;".$agecha."&#20043;&#21069;','');</script>";
				exit;
			}else{
				showerror('&#20986;&#29983;&#24180;&#35831;&#36873;&#25321;'.$agecha.'&#20043;&#21069;');
			}
        }
		if (empty($_GET['region'])) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_28')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','aljzp_28'));
			}
        }
		if ($_FILES['pic']['tmp_name']) {
			$picname = $_FILES['pic']['name'];
			$picsize = $_FILES['pic']['size'];
			if ($picsize/1024>$config['img_size']) {
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_11').$config['img_size']."K','');</script>";
					exit;
				}else{
					showerror(lang('plugin/aljzp','aljzp_11').$config['img_size'].'K');
				}
			}
			if ($picname != "") {
				$type = strtolower(strrchr($picname, '.'));
				if ($type != ".gif" && $type != ".jpg" && $type != ".png" && $type != ".jpeg") {

					if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
						echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_3')."','');</script>";
						exit;
					}else{
						showerror(lang('plugin/aljzp','aljzp_3'));
					}
				}
				$rand = rand(100, 999);
				$pics = date("YmdHis") . $rand . $type;
				$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
				if (!is_dir($img_dir)) {
					if(!mkdir($img_dir)){
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;','');</script>";
							exit;
						}else{
							showerror('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;');
						}
					}
				}
				$$pic = $img_dir . $pics;
				if (@copy($_FILES['pic']['tmp_name'], $$pic) || @move_uploaded_file($_FILES['pic']['tmp_name'], $$pic)) {
					$imageinfo = getimagesize($$pic);
					$w64 = $imageinfo[0] < 180 ? $imageinfo[0] : 180;
					$h64 = $imageinfo[1] < 180 ? $imageinfo[1] : 180;
					img2thumb($$pic, $$pic . '.180x180.jpg', $w64, $h64);
					@unlink($_FILES['pic']['tmp_name']);
				}
			}
		}

		if($_FILES['resfile']['tmp_name']) {
			$picname = $_FILES['resfile']['name'];
			$picsize = $_FILES['resfile']['size'];
			$file_size = $settings['file_size']['value'] ? $settings['file_size']['value'] : 1024;
			$file_format = $settings['file_format']['value'] ? $settings['file_format']['value'] : '.doc,.docx';
			if ($picsize/1024>$file_size) {

				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('&#19978;&#20256;&#31616;&#21382;&#38468;&#20214;&#19981;&#33021;&#36229;&#36807;".$file_size."K','');</script>";
					exit;
				}else{
					showerror('&#19978;&#20256;&#31616;&#21382;&#38468;&#20214;&#19981;&#33021;&#36229;&#36807;'.$file_size.'K');
				}
			}
			if ($picname != "") {
				$type = strtolower(strrchr($picname, '.'));
				$filetype = explode(",",$file_format);
				if (!in_array($type, $filetype)) {

					if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
						echo "<script>parent.tips('&#35831;&#19978;&#20256;&#21518;&#32512;&#25991;&#20214;&#20026;".$file_format."','');</script>";
						exit;
					}else{
						showerror('&#35831;&#19978;&#20256;&#21518;&#32512;&#25991;&#20214;&#20026;'.$file_format);
					}
				}
				$rand = rand(100, 999);
				$filepath = date("YmdHis") . $rand . $type;
				$resfile = "source/plugin/".$pluginid."/images/file/". $filepath;
				if(@copy($_FILES['resfile']['tmp_name'], $resfile)||@move_uploaded_file($_FILES['resfile']['tmp_name'], $resfile)){
					@unlink($_FILES['resfile']['tmp_name']);


				}
			}
		}
		if(empty($resfile)){
			$resfile = $_GET['resfile'];
		}

        $insertarray = array(
			'uid' => $_G['uid'],
            'username' => $_G['username'],
            'pos' => $_GET['pos'],
            'pos1' => $_GET['pos1'],
            'pos2' => $_GET['pos2'],
            'name' => $_GET['name'],
            'title' => $_GET['title'],
            'sex' => $_GET['sex'],
            'ymd' => $_GET['ymd'],
            'xueli' => $_GET['xueli'],
            'work_nx' => $_GET['work_nx'],
            'salary' => $_GET['salary'],
            'region' => $_GET['region'],
            'region1' => $_GET['region1'],
            'work_jl' => $_GET['work_jl'],
            'my_introduction' => $_GET['my_introduction'],
            'email' => $_GET['email'],
            'tel' => $_GET['tel'],
            'state' => $_GET['state'],
            'privacy' => $_GET['privacy'],
            'timestamp' => TIMESTAMP,
            'resfile' => $resfile,
        );
		if($$pic){
			$insertarray['pic'] = $$pic;
		}
		if($resfile){
			$lp	=C::t('#aljzp#aljzp_resume')->fetch($_G['uid']);
			if(file_exists($lp['resfile'])){
				unlink($lp['resfile']);
			}
		}

		if(!C::t('#aljzp#aljzp_resume')->fetch($_G['uid'])){
			$insertid = C::t('#aljzp#aljzp_resume')->insert($insertarray);
		}else{
			C::t('#aljzp#aljzp_resume')->update($_G['uid'], $insertarray);
		}
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".str_replace('\\','',lang('plugin/aljzp','aljzp_4'))."',function(){parent.location.href='plugin.php?id=aljzp&act=myresume';});</script>";
		}else{
			showmsg(lang('plugin/aljzp','aljzp_4'));
		}
    } else {
		if(!$_G['uid']){
			showmessage(lang('plugin/aljzp','aljzp_1'), '', array(), array('login' => true));
		}
		$pos = C::t('#aljzp#aljzp_position')->fetch_all_by_upid(0);
		$rs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid(0);
		$lp	=C::t('#aljzp#aljzp_resume')->fetch($_G['uid']);

		if ($lp['pos']) {
            $prs = C::t('#aljzp#aljzp_position')->fetch_all_by_upid($lp['pos']);
        }
		if ($lp['region']) {
            $rrs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid($lp['region']);
        }
		$navtitle = $config['title'];
		$metakeywords = $config['keywords'];
		$metadescription = $config['description'];
		if($aljzp_seo['myresume']['seotitle']){
			$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
			list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzp_seo['myresume']);
		}
		include template('aljzp:myresume');
	}
}else if($_GET['act'] == 'resumeadd'){
	if (submitcheck('formhash')) {
        if (empty($_GET['name'])) {
			if($_GET['sj']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_2')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','aljzp_2'));
			}
        }
		if (empty($_GET['sex'])) {
			if($_GET['sj']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_26')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','aljzp_26'));
			}
        }
		if (empty($_GET['ymd'])&&!$_GET['sj']) {
			showerror(lang('plugin/aljzp','aljzp_28'));
        }
		if (empty($_GET['region'])) {
			if($_GET['sj']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_28')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','aljzp_28'));
			}
        }
		if ($_FILES['pic']['tmp_name']) {
			$picname = $_FILES['pic']['name'];
			$picsize = $_FILES['pic']['size'];
			if ($picsize/1024>$config['img_size']) {
				showerror(lang('plugin/aljzp','aljzp_11').$config['img_size'].'K');
			}
			if ($picname != "") {
				$type = strtolower(strrchr($picname, '.'));
				if ($type != ".gif" && $type != ".jpg" && $type != ".png") {
					showerror(lang('plugin/aljzp','aljzp_3'));
				}
				$rand = rand(100, 999);
				$pics = date("YmdHis") . $rand . $type;
				$img_dir = 'source/plugin/aljzp/images/logo/'.date('Ymd',TIMESTAMP).'/';
				if (!is_dir($img_dir)) {
					if(!mkdir($img_dir)){
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;','');</script>";
							exit;
						}else{
							showerror('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;');
						}
					}
				}
				$$pic = $img_dir . $pics;
				if (@copy($_FILES['pic']['tmp_name'], $$pic) || @move_uploaded_file($_FILES['pic']['tmp_name'], $$pic)) {
					$imageinfo = getimagesize($$pic);
					$w64 = $imageinfo[0] < 180 ? $imageinfo[0] : 180;
					$h64 = $imageinfo[1] < 180 ? $imageinfo[1] : 180;
					img2thumb($$pic, $$pic . '.180x180.jpg', $w64, $h64);
					@unlink($_FILES['pic']['tmp_name']);
				}
			}
		}


        $insertarray = array(
			'uid' => $_G['uid'],
            'username' => $_G['username'],
            'pos' => $_GET['pos'],
            'pos1' => $_GET['pos1'],
            'name' => $_GET['name'],
            'sex' => $_GET['sex'],
            'ymd' => $_GET['ymd'],
            'xueli' => $_GET['xueli'],
            'work_nx' => $_GET['work_nx'],
            'salary' => $_GET['salary'],
            'region' => $_GET['region'],
            'region1' => $_GET['region1'],
            'work_jl' => $_GET['work_jl'],
            'my_introduction' => $_GET['my_introduction'],
            'email' => $_GET['email'],
            'tel' => $_GET['tel'],
            'timestamp' => TIMESTAMP,
        );
		if($$pic){
			$insertarray['pic'] = $$pic;
		}
		if(!C::t('#aljzp#aljzp_resume')->fetch($_G['uid'])){
			C::t('#aljzp#aljzp_resume')->insert($insertarray);
		}else{
			C::t('#aljzp#aljzp_resume')->update($_G['uid'], $insertarray);
		}
		$lp = C::t('#aljzp#aljzp')->fetch($_GET['lid']);
		$sid=C::t('#aljzp#aljzp_sentresume')->insert(array(
			'uid'=>$_G['uid'],
			'username' => $_G['username'],
			'Position_name' => $lp['title'],
			'gongsi' => $lp['gongsi'],
			'timestamp' => TIMESTAMP,
			'lid' => $_GET['lid'],
		),true);
		C::t('#aljzp#aljzp_getresume')->insert(array(
			'uid'=>$_G['uid'],
			'getuid'=>$lp['uid'],
			'Position_name' => $lp['title'],
			'timestamp' => TIMESTAMP,
			'lid' => $_GET['lid'],
			'sid' => $sid,
		));
		notification_add($lp['uid'], 'system',lang('plugin/aljzp','aljzp_13').' <a target="_blank" href="plugin.php?id=aljzp&act=view&lid='.$_GET['lid'].'">'.$lp['title'].'</a> <a href="plugin.php?id=aljzp&act=getresume" target="_blank">'.lang('plugin/aljzp','aljzp_14').'</a>',array('from_idtype'  => 'aljzp','from_id' => $_GET['lid']));
		if(function_exists('sendmail') && !$settings['is_email']['value']) {
			sendmail($lp['email'],$_GET['name'].lang('plugin/aljzp','aljzp_15').$lp['title'],lang('plugin/aljzp','aljzp_16').$_GET['name'].'<br/>'.lang('plugin/aljzp','aljzp_17').$_GET['sex'].'<br/>'.lang('plugin/aljzp','aljzp_18').$_GET['xueli'].'<br/>'.lang('plugin/aljzp','aljzp_20').$_GET['work_jl'].'<br/>'.lang('plugin/aljzp','aljzp_21').$_GET['tel']);
		}

		if($_GET['sj']){
			echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_19')."',function(){parent.location.href='plugin.php?id=aljzp&act=view&lid=".$_GET['lid']."';});</script>";
		}else{
			showmsg(lang('plugin/aljzp','aljzp_19'));
		}
    } else {
		if(!$_G['uid']){
			showmessage(lang('plugin/aljzp','aljzp_1'), '', array(), array('login' => true));
		}
		$pos = C::t('#aljzp#aljzp_position')->fetch_all_by_upid(0);
		$rs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid(0);
		$lp	=C::t('#aljzp#aljzp_resume')->fetch($_G['uid']);
		if ($lp['pos']) {
			$prs = C::t('#aljzp#aljzp_position')->fetch_all_by_upid($lp['pos']);
		}
		if ($lp['region']) {
			$rrs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid($lp['region']);
		}
		include template('aljzp:add');
	}
}else if($_GET['act']=='resumes'){
	if($config['isjlrz']){
		if(!DB::result_first("select count(*) from ".DB::table('aljzp_attestation')." where sign=1 and uid=".$_G['uid'])){
			showmessage(lang('plugin/aljzp','aljzp_30'));
		}
	}
	if (file_exists("source/plugin/aljzp/template/com/resumes.php")) {
        include 'source/plugin/aljzp/template/com/resumes.php';
    }
}else if($_GET['act']=='all'){
	
	dheader('Location: plugin.php?id=aljzp&act=company&uid='.intval($_GET['uid']));
	$pics = array('pic1', 'pic2', 'pic3', 'pic4', 'pic5', 'pic6', 'pic7', 'pic8');

	if (file_exists("source/plugin/aljzp/template/com/qita.php")) {
		include 'source/plugin/aljzp/template/com/qita.php';
	}
}else if($_GET['act'] == 'companylist'){

    $regions = C::t('#aljzp#aljzp_region')->range();
    $rs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid(0);
    $rrs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid($_GET['rid']);
	$subrrs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid($_GET['subrid']);
    $currpage = intval($_GET['page']) ? intval($_GET['page']) : 1;
    $perpage = 10;
	if($_GET['mobile']=='1'||$_GET['mobile']=='2'){
		if($_G['charset']=='gbk'){ $_GET['sex']=diconv($_GET['sex'],'utf-8','gbk');}
	}
	if($_G['charset']=='gbk'&&!defined('IN_MOBILE')&&$config['is_header']||defined('IN_MOBILE')&&!$_GET['sj']){
		$_GET['search']=diconv($_GET['search'],'utf-8','gbk');
	}
    $start = ($currpage - 1) * $perpage;
    $conndtion = array(
        'search' => $_GET['search'],
        'rid' => $_GET['region']?$_GET['region']:$_GET['rid'],
        'subrid' => $_GET['region1']?$_GET['region1']:$_GET['subrid'],
        'subsubrid' => $_GET['region2']?$_GET['region2']:$_GET['subsubrid'],
        'btntrade' => $_GET['btntrade'],
        'property' => $_GET['property'],
        'employee' => $_GET['employee'],
    );

	$num = C::t('#aljzp#aljzp_attestation')->count_by_sign($conndtion);

    $lplist = C::t('#aljzp#aljzp_attestation')->fetch_all_by_addtime($start, $perpage, $conndtion);

    $lplist = dhtmlspecialchars($lplist);
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljzp&act=companylist&search='.$_GET['search'].'&rid='.$_GET['rid'].'&subrid='.$_GET['subrid'].'&btntrade='.$_GET['btntrade'].'&property='.$_GET['property'].'&employee='.$_GET['employee'], 0, 11, false, false);
	$tuijian = DB::fetch_all("SELECT * FROM ".DB::table('aljzp')." where state=0 and tuijian=1 ORDER BY id desc limit 0,9");
	foreach($tuijian as $k=>$v){
		$tuijian[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
	}
    $urllist = '&act=companylist';
	$navtitle = $config['title'];
    $metakeywords = $config['keywords'];
    $metadescription = $config['description'];
	if($aljzp_seo['companylist']['seotitle']){
		if($_GET['rid']){
			$title=$regions[$_GET['rid']]['subject'];
			$title1 = $title;
		}
		if($_GET['subrid']){
			$title=$regions[$_GET['subrid']]['subject'];
			$title2=$title;

		}

		if($_GET['btntrade']){
			$btntrade=$suoshuhangye[$_GET['btntrade']];
		}
		if($_GET['property']){
			$property=$gongsixingzhi[$_GET['property']];
		}
		if($_GET['employee']){
			$employee=$gongsiguimo[$_GET['employee']];
		}
		$seodata = array('bbname' => $_G['setting']['bbname'],'number'=>$employee,'nature'=>$property,'btntrade'=>$btntrade,'region'=>$title1,'region2'=>$title2);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzp_seo['companylist']);
	}
	if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
		include template('aljzp:companylist');
	}else{
		include template('diy:companylist', null, 'source/plugin/aljzp/template');
	}
}else if($_GET['act'] == 'company'){
	if(empty($_GET['uid'])){
		showmessage('&#20844;&#21496;&#19981;&#23384;&#22312;');
	}
	$pics = array('pic1', 'pic2', 'pic3', 'pic4', 'pic5', 'pic6', 'pic7', 'pic8');
	$currpage = $_GET['page'] ? $_GET['page'] : 1;
	$perpage = 10;

	$start = ($currpage - 1) * $perpage;
	if($_GET['uid']){

		$conndtion = array(
			'uid' => $_GET['uid'],
		);
		$num = C::t('#aljzp#aljzp')->count_by_status($conndtion);
		$lplist = C::t('#aljzp#aljzp')->fetch_all_by_addtime($start, $perpage, $conndtion);
		foreach($lplist as $k=>$v){
			$lplist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
		}
		$lplist = dhtmlspecialchars($lplist);
		$user=getuserbyuid($_GET['uid']);
	}
	$attes=DB::fetch_first("select * from ".DB::table('aljzp_attestation')." where sign=1 and uid=".$_GET['uid']);
	$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljzp&act=all&uid='.$_GET['uid'], 0, 11, false, false);
	$lp	=C::t('#aljzp#aljzp_resume')->fetch($_G['uid']);
	$day = date('d');
	$mon = date('m');
	$year = date('Y');
	$today = date('N');
	$s_time = date('Y-m-d', mktime(0, 0, 0, $mon, $day - $today + 1, $year));
	$end = date('Y-m-d H:i:s', mktime(23, 59, 59, $mon, $day - $today + 14, $year));
	$chuli_s=DB::result_first("select count(*) from ".DB::table('aljzp_getresume')." where getuid=".intval($_GET['uid'])." and sign=1 and timestamp>='" . strtotime($s_time) . "' and timestamp<='" . strtotime($end) . "'");
	$chuli_c=DB::result_first("select count(*) from ".DB::table('aljzp_getresume')." where getuid=".intval($_GET['uid'])." and timestamp>='" . strtotime($s_time) . "' and timestamp<='" . strtotime($end) . "'");

	$chuli = intval($chuli_s/$chuli_c*100);
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljzp_seo['quanbu']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$user['username'],'qiyename'=>$attes['qiyename']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzp_seo['quanbu']);
	}
	include template('aljzp:company');
}else if($_GET['act'] == 'follow'){

	if($_GET['formhash'] != formhash() || empty($_G['uid'])){
		$state = 0;
	}else{

		if(DB::result_first('select count(*) from %t where uid=%d and cid=%d',array('aljzp_company_follow',$_G['uid'],$_GET['uid']))){
			$follow = DB::result_first('select follow from %t where uid=%d',array('aljzp_attestation',$_GET['uid']));
			if($follow>0){
				DB::query('update %t set follow=follow-1 where uid = %d',array('aljzp_attestation',$_GET['uid']));
			}else{
				DB::query('update %t set follow=0 where uid = %d',array('aljzp_attestation',$_GET['uid']));
			}
			DB::query('delete from %t where uid = %d and cid=%d',array('aljzp_company_follow',$_G['uid'],$_GET['uid']));
			$state = 2;
		}else{

			C::t('#aljzp#aljzp_company_follow')->insert(array(
				'uid' => $_G['uid'],
				'cid' => $_GET['uid'],
				'username' => $_G['username'],
				'timestamp' => TIMESTAMP,
			));

			DB::query('update %t set follow=follow+1 where uid = %d',array('aljzp_attestation',$_GET['uid']));
			$state = 1;
		}
		$cf = DB::result_first('select follow from %t where uid=%d',array('aljzp_attestation',$_GET['uid']));
	}

	$datearray = array('state' => $state,'cf' => $cf);
	echo json_encode($datearray);
	exit;
}else if($_GET['act'] == 'addresume'){//��������д����ְλ
	if(!$_G['uid']){
		showmessage(lang('plugin/aljzp','aljzp_1'), '', array(), array('login' => true));
	}
	$lp = C::t('#aljzp#aljzp')->fetch($_GET['lid']);
	$sid=C::t('#aljzp#aljzp_sentresume')->insert(array(
		'uid'=>$_G['uid'],
		'username' => $_G['username'],
		'Position_name' => $lp['title'],
		'gongsi' => $lp['gongsi'],
		'timestamp' => TIMESTAMP,
		'lid' => $_GET['lid'],
	),true);
	C::t('#aljzp#aljzp_getresume')->insert(array(
		'uid'=>$_G['uid'],
		'getuid'=>$lp['uid'],
		'Position_name' => $lp['title'],
		'timestamp' => TIMESTAMP,
		'lid' => $_GET['lid'],
		'sid' => $sid,
	));

	$resume = C::t('#aljzp#aljzp_resume')->fetch($_G['uid']);

	notification_add($lp['uid'], 'system',lang('plugin/aljzp','aljzp_13').' <a target="_blank" href="plugin.php?id=aljzp&act=view&lid='.$_GET['lid'].'">'.$lp['title'].'</a> <a href="plugin.php?id=aljzp&act=getresume" target="_blank">'.lang('plugin/aljzp','aljzp_14').'</a>',array('from_idtype'  => 'aljzp','from_id' => $_GET['lid']));
	//'2859894452@qq.com'
	if(function_exists('sendmail') && !$settings['is_email']['value']) {
		sendmail($lp['email'],$resume['name'].lang('plugin/aljzp','aljzp_15').$lp['title'],lang('plugin/aljzp','aljzp_16').$resume['name'].'<br/>'.lang('plugin/aljzp','aljzp_17').$resume['sex'].'<br/>'.lang('plugin/aljzp','aljzp_18').$xl_types[$resume['xueli']].'<br/>'.lang('plugin/aljzp','aljzp_20').discuzcode($resume['work_jl']).'<br/>'.'</a> <a href="plugin.php?id=aljzp&act=getresume" target="_blank">'.lang('plugin/aljzp','aljzp_14').'</a>');
	}
	if($_GET['mobile']=='1'||$_GET['mobile']=='2'||$_GET['sj']){
		echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_19')."',function(){parent.location.href='plugin.php?id=aljzp&act=view&lid=".$_GET['lid']."';});</script>";
	}else{
		showmsg(lang('plugin/aljzp','aljzp_19'));
	}
}else if($_GET['act'] == 'getresumedel'){//
	if(!$_G['uid']){
		showmessage(lang('plugin/aljzp','aljzp_1'), '', array(), array('login' => true));
	}
	if($_GET['formhash']!=formhash()){
		showmessage(lang('plugin/aljzp','aljzp_8'));
	}
	$user=C::t('#aljzp#aljzp_getresume')->fetch($_GET['gid']);
	if($user['uid']!=$_G['uid']&&$user['getuid']!=$_G['uid']&&$_G['groupid']!=1){
		showmessage(lang('plugin/aljzp','aljzp_8'));
	}
	C::t('#aljzp#aljzp_getresume')->delete($_GET['gid']);
	showmessage(lang('plugin/aljzp','aljzp_7'),'plugin.php?id=aljzp&act=getresume');
}else if($_GET['act'] == 'sentResume'){//Ͷ����ʷ
	if(!$_G['uid']){
		showmessage(lang('plugin/aljzp','aljzp_1'), '', array(), array('login' => true));
	}
	$currpage = intval($_GET['page']) ? intval($_GET['page']) : 1;
    $perpage = $config['page'];
    $num = DB::result_first("select count(*) from ".DB::TABLE('aljzp_sentresume')." where uid=".$_G['uid']);
    $start = ($currpage - 1) * $perpage;
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljzp&act=sentResume', 0, 11, false, false);
	$sentResume=DB::fetch_all("select * from ".DB::TABLE('aljzp_sentresume')." where uid=".$_G['uid']." order by timestamp desc limit $start,$perpage");
	//debug($sentResume);
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljzp_seo['sentResume']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzp_seo['sentResume']);
	}
	include template('aljzp:sentResume');
}else if($_GET['act'] == 'getresume'){//�յ�����
	if(!$_G['uid']){
		showmessage(lang('plugin/aljzp','aljzp_1'), '', array(), array('login' => true));
	}
	$regions = C::t('#aljzp#aljzp_region')->range();
	$currpage = intval($_GET['page']) ? intval($_GET['page']) : 1;
    $perpage = $config['page'];
    $num = DB::result_first("select count(*) from ".DB::TABLE('aljzp_getresume')." where getuid=".$_G['uid']);
    $start = ($currpage - 1) * $perpage;
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljzp&act=getresume', 0, 11, false, false);
	$sentResume=DB::fetch_all("select * from ".DB::TABLE('aljzp_getresume')." where getuid=".$_G['uid']." order by timestamp desc limit $start,$perpage");
	//debug($sentResume);
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljzp_seo['getresume']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzp_seo['getresume']);
	}
	include template('aljzp:getresume');
}else if($_GET['act'] == 'touid'){
	if(!$_G['uid']){
		showmessage(lang('plugin/aljzp','aljzp_1'), '', array(), array('login' => true));
	}
	if(empty($_GET['gid'])){
		showmessage(lang('plugin/aljzp','aljzp_8'));
	}
	if(empty($_GET['sid'])){
		showmessage(lang('plugin/aljzp','aljzp_8'));
	}
	if(!DB::result_first("select sign from %t where id=%d",array('aljzp_getresume',intval($_GET['gid'])))){
		DB::update('aljzp_getresume',array('sign'=>1),'id='.intval($_GET[gid]));
		DB::update('aljzp_sentresume',array('sign'=>1),'id='.intval($_GET[sid]));
	}
	$regions = C::t('#aljzp#aljzp_region')->range();
    $pos = C::t('#aljzp#aljzp_position')->range();
	$lp	=C::t('#aljzp#aljzp_resume')->fetch($_GET['uid']);
	include template('aljzp:touid');
}else if ($_GET['act'] == 'reflash') {
    if (file_exists("source/plugin/aljzp/template/com/reflash.php")) {
        include 'source/plugin/aljzp/template/com/reflash.php';
    }
}else if ($_GET['act'] == 'reslog') {
	$currpage = intval($_GET['page']) ? intval($_GET['page']) : 1;
    $perpage = $config['page'];
	if($_G['groupid']!=1){
		$con=" where uid=".$_G['uid'];
	}
    $num = DB::result_first("select count(*) from ".DB::TABLE('aljzp_resume_log').$con);
    $start = ($currpage - 1) * $perpage;
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljzp&act=reslog', 0, 11, false, false);
	$reslog=DB::fetch_all("select * from ".DB::TABLE('aljzp_resume_log')." $con order by timestamp desc limit $start,$perpage");
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljzp_seo['reslog']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzp_seo['reslog']);
	}
    include template('aljzp:reslog');
}else if ($_GET['act'] == 'res_tel') {
	if (submitcheck('formhash')) {
		if(empty($_GET['uid'])){
			showmessage(lang('plugin/aljzp','aljzp_8'));
		}
		$lp=C::t('#aljzp#aljzp_resume')->fetch($_GET['uid']);

		$insertid=C::t('#aljzp#aljzp_resume_log')->insert(array(
			'uid' => $_G['uid'],
			'username' => $_G['username'],
			'timestamp' => TIMESTAMP,
			'money' => $config['respay'],
			'extcredit' => $config['rescredit'],
			'res_tel' => $lp['tel'],
			'res_name' => $lp['name'],
			'res_uid' => $_GET['uid'],
		),true);
		if (getuserprofile('extcredits' . $config['rescredit']) < $config['respay']) {
			if($_G['mobile']){
				if($mobile_integral_recharge){
					echo "<script>parent.tips('".$_G['setting']['extcredits'][$config['rescredit']]['title'] . lang('plugin/aljzp','top_1').$aljzplang['php']['Jumping_up_page']."',function(){parent.location.href='".$mobile_integral_recharge."';});</script>";
				}else{
					echo "<script>parent.tips('".$_G['setting']['extcredits'][$config['rescredit']]['title'] . lang('plugin/aljzp','top_1')."','');</script>";
				}
				exit;
			}else{
				showmsg($_G['setting']['extcredits'][$config['rescredit']]['title'] . lang('plugin/aljzp','top_1').$pc_integral_recharge);
			}
		}
		updatemembercount($_G['uid'], array($config['rescredit'] => '-' .$config['respay']));
		//DB::update('aljzp_resume',array('xiazaicishu'=>1),'uid='.$_GET['uid']);
		C::t('#aljzp#aljzp_resume')->update_xiazaicishu_by_uid($_GET['uid']);
		if($_G['mobile']){
			echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_29')."',function(){parent.location.href='plugin.php?id=aljzp&act=resumes&uid={$_GET['uid']}"."';});</script>";
			exit;
		}else{
			showmsg(lang('plugin/aljzp','aljzp_29'));
		}

	}else{
		if (getuserprofile('extcredits' . $config['rescredit']) < $config['respay']) {
			showmessage($_G['setting']['extcredits'][$config['rescredit']]['title'] . lang('plugin/aljzp','top_1').$pc_integral_recharge);
		}

		include template('aljzp:res_tel');
	}
}else if ($_GET['act'] == 'top') {
    if (file_exists("source/plugin/aljzp/template/com/top.php")) {
        include 'source/plugin/aljzp/template/com/top.php';
    }
} else if ($_GET['act'] == 'untop'){

	$lp=C::t('#aljzp#aljzp')->fetch($_GET['lid']);

	if (($_GET['formhash'] != formhash() || $lp['uid']!=$_G['uid'] || empty($_GET['lid'])) && $_G['groupid']!=1) {

		if($_G['mobile']){
			echo "<script>parent.tips('&#26080;&#26435;&#25805;&#20316;','');</script>";
			exit;
		}else{
			showmsg('&#26080;&#26435;&#25805;&#20316;');
		}
	}
	DB::update('aljzp',array('topetime'=>TIMESTAMP),'id='.$_GET[lid]);
	DB::update('aljzp_toplog',array('status'=>1),'lid='.$_GET[lid]);

	if($_G['mobile']){
		echo "<script>parent.tips('&#21462;&#28040;&#32622;&#39030;&#25104;&#21151;',function(){parent.location.href='plugin.php?id=aljzp&act=member"."';});</script>";
		exit;
	}else{
		showmsg('&#21462;&#28040;&#32622;&#39030;&#25104;&#21151;', 'plugin.php?id=aljzp&act=member');
	}
} else if ($_GET['act'] == 'view') {
    if (empty($_GET['lid'])) {
        showmessage(lang('plugin/aljzp','aljzp_6'));
    }

	$lp = C::t('#aljzp#aljzp')->fetch($_GET['lid']);
	if (empty($lp)) {
        showmessage(lang('plugin/aljzp','aljzp_6'));
    }
    C::t('#aljzp#aljzp')->update_views_by_id($_GET['lid']);
    $pics = array('pic1', 'pic2', 'pic3', 'pic4', 'pic5', 'pic6', 'pic7', 'pic8');
    $pics1 = array('pic1', 'pic2', 'pic3', 'pic4', 'pic5', 'pic6', 'pic7', 'pic8');
    $regions = C::t('#aljzp#aljzp_region')->range();
    $pos = C::t('#aljzp#aljzp_position')->range();


    $lp = dhtmlspecialchars($lp);
	if($config['isyouke']){
		$tel=hidtel($lp['contact']);
	}
	$cod=$regions[$lp['region']]['subject'].$regions[$lp['region1']]['subject'].$regions[$lp['region2']]['subject'].$lp['region3'];
	if($_G['charset']=='gbk'){
		$cod=diconv($cod,'gbk','utf-8');
	}
	$url=urlencode($cod);
	$qita = DB::fetch_all("SELECT * FROM ".DB::table('aljzp')." where state=0 and uid=".$lp[uid]." ORDER BY id desc limit 0,".$config['qita_num']);
	foreach($qita as $k=>$v){
		$qita[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
	}
	$commentlist=C::t('#aljzp#aljzp_comment')->fetch_all_by_upid(0,$_GET['lid']);
	$commentlist=dhtmlspecialchars($commentlist);
	foreach($pics as $p => $pic){
		if(file_exists($lp[$pic])){
			$html.="<li class=\"img clone\" ><a href=\"javascript:void(0);\"><img src=\"".$lp[$pic].".640x480.jpg\" onclick=\"testMessageBox(event,\'".$lp[$pic]."\');\"></a></li>";
		}
	}
	if(file_exists('source/plugin/mapp_share/api/api.php')){
		$shareid = $_GET['lid'];
		$sharetype = 7;
		require_once 'source/plugin/mapp_share/api/api.php';
	}
    $navtitle = $lp['title'] . '-' . $config['title'];
    $metakeywords = $lp['title'];
    $metadescription = $lp['title'];
	if($aljzp_seo['view']['seotitle']){
		if($lp['region']){
			$title=$regions[$lp['region']]['subject'];
			$title1 = $title;
		}
		if($lp['region1']){
			$title=$regions[$lp['region1']]['subject'];
			$title2=$title;

		}
		if($lp['region2']){
			$title=$regions[$lp['region2']]['subject'];
			$title3=$title;
		}

		if($lp['pos']){
			$cat=$pos_zw[$lp['pos']]['subject'];
		}
		if($lp['pos1']){
			$cat2=$pos_zw[$lp['pos1']]['subject'];
		}
		$seodata = array('bbname' => $_G['setting']['bbname'],'subject'=>$lp['title'],'message'=>cutstr(stripBBCode(strip_tags(preg_replace('/\<img.*?\>/is', '', $lp['content']))),80,''),'cat'=>$cat,'cat2'=>$cat2,'zujin'=>$pay_types[$lp['pay']],'region'=>$title1,'region2'=>$title2,'region3'=>$title3);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzp_seo['view']);
	}
	if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
		include template('aljzp:view');
	}else{
		include template('diy:aljzp_view', null, 'source/plugin/aljzp/template');
	}
} else if ($_GET['act'] == 'delete') {
	$lid = intval($_GET['lid']);
	if(empty($lid)){
		showmessage(lang('plugin/aljzp','edittips'));
	}
	if($config['isnewupload']){
		DB::query('delete from %t where pid=%d',array('aljzp_attachment',$lid));
	}
	$user=C::t('#aljzp#aljzp')->fetch($lid);
	if($user['uid']!=$_G['uid']&&$_G['groupid']!=1){
		showmessage(lang('plugin/aljzp','aljzp_8'));
	}
	for ($i = 1; $i <= 8; $i++) {
		$pic = 'pic' . $i;
		if ($user[$pic]) {
			unlink($user[$pic]);
			unlink($user[$pic].'.64x64.jpg');
			unlink($user[$pic].'.100x100.jpg');
			unlink($user[$pic].'.640x480.jpg');
		}
	}
	if($user['tid']){
		DB::update('forum_post', array('invisible'=>'-1'), "tid=".$user['tid']);
		DB::update('forum_thread', array('displayorder'=>'-1'), "tid=".$user['tid']);
	}
    C::t('#aljzp#aljzp')->delete($_GET['lid']);
    showmessage(lang('plugin/aljzp','aljzp_7'), 'plugin.php?id=aljzp&act=member');
}else if($_GET['act'] == 'ask'){
	if(submitcheck('formhash')){
		if (empty($_G['uid'])) {
			//showerror(lang('plugin/aljzp','aljzp_1'));
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_1')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','aljzp_1'));
			}
		}
		if (empty($_GET['message'])) {
			//showerror(lang('plugin/aljzp','aljzp_9'));
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_9')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','aljzp_9'));
			}
		}
		$insertarray=array(
			'content'=>$_GET['message'],
			'uid'=>$_G['uid'],
			'username'=>$_G['username'],
			'lid'=>$_GET['lid'],
			'dateline'=>TIMESTAMP,
		);
		C::t('#aljzp#aljzp_comment')->insert($insertarray);
		if($config['is_ping']){
			$lp=C::t('#aljzp#aljzp')->fetch($_GET['lid']);
			notification_add($lp['uid'], 'system',lang('plugin/aljzp','tongzhi_1').' <a target="_blank" href="plugin.php?id=aljzp&act=view&lid='.$_GET['lid'].'">'.$lp['title'].'</a> '.lang('plugin/aljzp','tongzhi_2').' <a href="plugin.php?id=aljzp&act=view&lid='.$_GET['lid'].'" target="_blank">'.lang('plugin/aljzp','tongzhi_3').'</a>',array('from_idtype'  => 'aljzp','from_id' => $_GET['lid']));
		}
		//showmsg(lang('plugin/aljzp','aljzp_10'));
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".str_replace('\\','',lang('plugin/aljzp','aljzp_10'))."',function(){parent.location.href='plugin.php?id=aljzp&act=view&lid=".$_GET['lid']."';});</script>";
		}else{
			showmsg(str_replace('\\','',lang('plugin/aljzp','aljzp_10')), 2, $_GET['lid']);
		}
	}
}else if($_GET['act'] == 'reply'){
	if(submitcheck('formhash')){
		if (empty($_G['uid'])) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_1')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','aljzp_1'));
			}
		}
		if (empty($_GET['message'])) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_9')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','aljzp_9'));
			}
		}
		$insertarray=array(
			'content'=>$_GET['message'],
			'uid'=>$_G['uid'],
			'username'=>$_G['username'],
			'lid'=>$_GET['lid'],
			'dateline'=>TIMESTAMP,
			'upid'=>$_GET['upid'],
		);
		C::t('#aljzp#aljzp_comment')->insert($insertarray);
		if($config['is_ping']){
			$lp=C::t('#aljzp#aljzp_comment')->fetch($_GET['upid']);
			notification_add($lp['uid'], 'system',lang('plugin/aljzp','tongzhi_4').$config['daohang'].lang('plugin/aljzp','tongzhi_5').' <a href="plugin.php?id=aljzp&act=view&lid='.$_GET['lid'].'" target="_blank">'.lang('plugin/aljzp','tongzhi_3').'</a>',array('from_idtype'  => 'aljzp','from_id' => $_GET['lid']));
		}
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".str_replace('\\','',lang('plugin/aljzp','aljzp_10'))."',function(){parent.location.href='plugin.php?id=aljzp&act=view&lid=".$_GET['lid']."';});</script>";
		}else{
			showmsg(str_replace('\\','',lang('plugin/aljzp','aljzp_10')), 2, $_GET['lid']);
		}
	}
}else if($_GET['act'] == 'commentdel'){
	if($_GET['formhash']==formhash()){
		if (empty($_G['uid'])) {
			showerror(lang('plugin/aljzp','aljzp_1'));
		}
		$upid=DB::fetch_all(" select * from %t where upid=%d",array('aljzp_comment',$_GET['cid']));
		if($upid){
			foreach($upid as $id){
				C::t('#aljzp#aljzp_comment')->delete($id['id']);
			}
		}
		C::t('#aljzp#aljzp_comment')->delete($_GET['cid']);
		showmessage(lang('plugin/aljzp','aljzp_7'),'plugin.php?id=aljzp&act=view&lid='.$_GET['lid']);
	}
}else if ($_GET['act'] == 'getregion') {
    if ($_GET['rid']) {
        $rs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid($_GET['rid']);
    }

    include template('aljzp:getregion');
}else if($_GET['act']=='getregion1'){
	if($_GET['upid']){
		$rlist=C::t('#aljzp#aljzp_region')->fetch_all_by_upid($_GET['upid']);
	}
	include template('aljzp:getregion1');
}else if ($_GET['act'] == 'getpos') {
    if ($_GET['rid']) {
        $rs = C::t('#aljzp#aljzp_position')->fetch_all_by_upid($_GET['rid']);
    }
    include template('aljzp:getpos');
} else if ($_GET['act'] == 'member') {
    $currpage = intval($_GET['page']) ? intval($_GET['page']) : 1;
    $perpage = $config['page'];

    $start = ($currpage - 1) * $perpage;
	if($_G['groupid']!=1){
		$conndtion = array(
			'uid' => $_G['uid'],
		);
	}
    $num = C::t('#aljzp#aljzp')->count_by_status($conndtion);
    $lplist = C::t('#aljzp#aljzp')->fetch_all_by_addtime($start, $perpage, $conndtion);
	//debug($lplist);
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljzp&act=member', 0, 11, false, false);
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljzp_seo['member']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzp_seo['member']);
	}
    include template('aljzp:member');
} else if ($_GET['act'] == 'attestation') {
	if (file_exists("source/plugin/aljzp/template/com/attestation.php")) {
        include 'source/plugin/aljzp/template/com/attestation.php';
    }
}  else if ($_GET['act'] == 'adminlp') {
    if (file_exists("source/plugin/aljzp/template/com/admin.php")) {
        include 'source/plugin/aljzp/template/com/admin.php';
    }
} else if ($_GET['act'] == 'adminuser') {
    if (file_exists("source/plugin/aljzp/template/com/user.php")) {
        include 'source/plugin/aljzp/template/com/user.php';
    }
} else if ($_GET['act'] == 'adminreflash') {
    $currpage = intval($_GET['page']) ? intval($_GET['page']) : 1;
    $perpage = $config['page'];
    $num = C::t('#aljzp#aljzp_reflashlog')->count();
    $start = ($currpage - 1) * $perpage;

    $logs = C::t('#aljzp#aljzp_reflashlog')->range($start, $perpage, 'desc');
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljzp&act=adminreflash', 0, 11, false, false);
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljzp_seo['adminreflash']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzp_seo['adminreflash']);
	}
    include template('aljzp:adminreflash');
} else if ($_GET['act'] == 'admintop') {
    $currpage = intval($_GET['page']) ? intval($_GET['page']) : 1;
    $perpage = $config['page'];
    $num = C::t('#aljzp#aljzp_toplog')->count();
    $start = ($currpage - 1) * $perpage;

    $logs = C::t('#aljzp#aljzp_toplog')->range($start, $perpage, 'desc');
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljzp&act=admintop', 0, 11, false, false);
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljzp_seo['admintop']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzp_seo['admintop']);
	}
    include template('aljzp:admintop');
}else if($_GET['act'] == 'mobile_list_region'){
	if($_GET['rid']){
		$rlist=C::t('#'.$pluginid.'#'.$pluginid.'_region')->fetch_all_by_upid($_GET['rid']);
	}
	$geturl = array(
		'id' => $pluginid,
		'act' => 'list',
		'search' => $_GET['search'],
		'rid' => $_GET['region']?$_GET['region']:$_GET['rid'],
        'subrid' => $_GET['region1']?$_GET['region1']:$_GET['subrid'],
        'subsubrid' => $_GET['region2']?$_GET['region2']:$_GET['subsubrid'],
		'pay' => $_GET['pay'],
		'wanted' => $_GET['wanted'],
		'pid' => $_GET['pid'],
		'subpid' => $_GET['subpid'],
		'solve' => $_GET['solve'],
		'view' => $_GET['view'],
		'sex' => $_GET['sex'],
		'pic' => $_GET['pic'],
	);
	if($_GET['sub']){
		$geturl['rid'] = $_GET['subrid'];
		$geturl['subrid'] = $_GET['rid'];
		include template('aljzp:mobile_list_subregion');
	}else{
		$geturl['rid'] = $_GET['rid'];
		$geturl['subrid'] = $_GET['subrid'];
		include template('aljzp:mobile_list_region');
	}
}else if ($_GET['act'] == 'mobile_list_type') {
    if ($_GET['pid']) {
        $rs = C::t('#aljzp#aljzp_position')->fetch_all_by_upid($_GET['pid']);
    }
	$geturl = array(
		'id' => $pluginid,
		'act' => 'list',
		'search' => $_GET['search'],
		'rid' => $_GET['region']?$_GET['region']:$_GET['rid'],
        'subrid' => $_GET['region1']?$_GET['region1']:$_GET['subrid'],
        'subsubrid' => $_GET['region2']?$_GET['region2']:$_GET['subsubrid'],
		'pay' => $_GET['pay'],
		'wanted' => $_GET['wanted'],
		'pid' => $_GET['pid'],
		'subpid' => $_GET['subpid'],
		'solve' => $_GET['solve'],
		'view' => $_GET['view'],
		'sex' => $_GET['sex'],
		'pic' => $_GET['pic'],
	);

	$geturl['pid'] = $_GET['pid'];
	$geturl['subpid'] = $_GET['subpid'];
	include template('aljzp:mobile_list_type');
}else if($_GET['act'] == 'mobile_list_region_r'){
	if($_GET['rid']){
		$rlist=C::t('#'.$pluginid.'#'.$pluginid.'_region')->fetch_all_by_upid($_GET['rid']);
	}
	$geturl = array(
		'id' => $pluginid,
		'act' => 'resumes',
		'search' => $_GET['search'],
		'rid' => $_GET['region']?$_GET['region']:$_GET['rid'],
        'subrid' => $_GET['region1']?$_GET['region1']:$_GET['subrid'],
        'subsubrid' => $_GET['region2']?$_GET['region2']:$_GET['subsubrid'],
		'pay' => $_GET['pay'],
		'wanted' => $_GET['wanted'],
		'pid' => $_GET['pid'],
		'subpid' => $_GET['subpid'],
		'solve' => $_GET['solve'],
		'view' => $_GET['view'],
		'sex' => $_GET['sex'],
		'pic' => $_GET['pic'],
	);

	$geturl['rid'] = $_GET['rid'];
	$geturl['subrid'] = $_GET['subrid'];
	include template('aljzp:mobile_list_region_r');

}else if ($_GET['act'] == 'mobile_list_type_r') {
    if ($_GET['pid']) {
        $rs = C::t('#aljzp#aljzp_position')->fetch_all_by_upid($_GET['pid']);
    }
	$geturl = array(
		'id' => $pluginid,
		'act' => 'resumes',
		'search' => $_GET['search'],
		'rid' => $_GET['region']?$_GET['region']:$_GET['rid'],
        'subrid' => $_GET['region1']?$_GET['region1']:$_GET['subrid'],
        'subsubrid' => $_GET['region2']?$_GET['region2']:$_GET['subsubrid'],
		'pay' => $_GET['pay'],
		'wanted' => $_GET['wanted'],
		'pid' => $_GET['pid'],
		'subpid' => $_GET['subpid'],
		'solve' => $_GET['solve'],
		'view' => $_GET['view'],
		'sex' => $_GET['sex'],
		'pic' => $_GET['pic'],
	);

	$geturl['pid'] = $_GET['pid'];
	$geturl['subpid'] = $_GET['subpid'];
	include template('aljzp:mobile_list_type_r');
} else if ($_GET['act'] == 'list') {
    $todayviews = C::t('#aljzp#aljzp_log')->fetch_all_by_day();
    $regions = C::t('#aljzp#aljzp_region')->range();
    $rs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid(0);
    $rrs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid($_GET['rid']);
	$subrrs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid($_GET['subrid']);
	$pos = C::t('#aljzp#aljzp_position')->fetch_all_by_upid(0);
	$prs = C::t('#aljzp#aljzp_position')->fetch_all_by_upid($_GET['pid']);
    $currpage = intval($_GET['page']) ? intval($_GET['page']) : 1;
    $perpage = $config['page'];
	if($_GET['mobile']=='1'||$_GET['mobile']=='2'){
		//if($_G['charset']=='gbk'){ $_GET['sex']=diconv($_GET['sex'],'utf-8','gbk');}
	}
	if(($_G['charset']=='gbk'&&!defined('IN_MOBILE')&&$config['is_header'])){
		$_GET['search']=diconv($_GET['search'],'utf-8','gbk');
	}

    $start = ($currpage - 1) * $perpage;
    $conndtion = array(
        'search' => $_GET['search'],
        'rid' => $_GET['region']?$_GET['region']:$_GET['rid'],
        'subrid' => $_GET['region1']?$_GET['region1']:$_GET['subrid'],
        'subsubrid' => $_GET['region2']?$_GET['region2']:$_GET['subsubrid'],
        'sex' => $_GET['sex'],
        'pay' => $_GET['pay'],
        'pos' => $_GET['pid'],
        'pos1' => $_GET['subpid'],
        'wanted' => $_GET['wanted'],
		'solve' => $_GET['solve'],
    );
	if($config['is_solve']){
		$conndtion['is_solve']=1;
	}
	$num = C::t('#aljzp#aljzp')->count_by_status($conndtion);
	$urllist = '&act=list';
    $lplist = C::t('#aljzp#aljzp')->fetch_all_by_addtime($start, $perpage, $conndtion);
	foreach($lplist as $k=>$v){
		if(TIMESTAMP>$v['topetime']&&$v['topetime']){
			DB::update('aljzp',array('topstime'=>'','topetime'=>''),'id='.$v[id]);
		}
		$lplist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
	}
    $lplist = dhtmlspecialchars($lplist);
	$geturl = array(
		'id' => $pluginid,
		'act' => 'list',
		'search' => $_GET['search'],
		'rid' => $_GET['region']?$_GET['region']:$_GET['rid'],
        'subrid' => $_GET['region1']?$_GET['region1']:$_GET['subrid'],
        'subsubrid' => $_GET['region2']?$_GET['region2']:$_GET['subsubrid'],
		'pay' => $_GET['pay'],
		'wanted' => $_GET['wanted'],
		'pid' => $_GET['pid'],
		'subpid' => $_GET['subpid'],
		'solve' => $_GET['solve'],
		'view' => $_GET['view'],
		'sex' => $_GET['sex'],
		'pic' => $_GET['pic'],
	);
	$pagingurl = getaljurl($geturl,'');
    $paging = helper_page :: multi($num, $perpage, $currpage, $pagingurl, 0, 11, false, false);
	$tuijian = DB::fetch_all("SELECT * FROM ".DB::table('aljzp')." where state=0 and tuijian=1 ORDER BY id desc limit 0,9");
	foreach($tuijian as $k=>$v){
		$tuijian[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
	}
    $toplist = C::t('#aljzp#aljzp_toplog')->fetch_all_by_dateline();
	foreach($toplist as $k=>$v){
		$toplist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
	}
	$navtitle = $config['title'];
    $metakeywords = $config['keywords'];
    $metadescription = $config['description'];
	if($aljzp_seo['list']['seotitle']){
		if($_GET['rid']){
			$title=$regions[$_GET['rid']]['subject'];
			$title1 = $title;
		}
		if($_GET['subrid']){
			$title=$regions[$_GET['subrid']]['subject'];
			$title2=$title;

		}
		if($_GET['subsubrid']){
			$title=$regions[$_GET['subsubrid']]['subject'];
			$title3=$title;
		}
		if($_GET['pay']){
			$zujin=$pay_types[$_GET['pay']];
		}
		if($_GET['pid']){
			$cat=$pos_zw[$_GET['pid']]['subject'];
		}
		if($_GET['subpid']){
			$cat2=$pos_zw[$_GET['subpid']]['subject'];
		}
		$seodata = array('bbname' => $_G['setting']['bbname'],'cat'=>$cat,'cat2'=>$cat2,'zujin'=>$zujin,'region'=>$title1,'region2'=>$title2,'region3'=>$title3);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzp_seo['list']);
	}
	if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
		include template('aljzp:index');
	}else{
		include template('diy:aljzp_list', null, 'source/plugin/aljzp/template');
	}
} else if($_GET['act'] == 'upload') {
	$_G['uid'] = intval($_GET['uid']);
	if(empty($_G['uid'])){
		$errorcode = $_G['uid'];
		echo "{\"picid\":\"".$aid."\", \"url\":\"".$pic."\", \"errorcode\":".$errorcode."}";
		exit;
	}
	if($_GET['hash'] != md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid'])){
		$errorcode = 2;
		echo "{\"picid\":\"".$aid."\", \"url\":\"".$pic."\", \"errorcode\":".$errorcode."}";
		exit;
	}
	if ($_FILES['Filedata']['tmp_name']) {
		$picname = $_FILES['Filedata']['name'];
		$picsize = $_FILES['Filedata']['size'];
		if ($picname != "") {
			$type = strtolower(strrchr($picname, '.'));

			$rand = rand(100, 999);
			$pics = date("YmdHis") . $rand . $type;
			$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
			if (!is_dir($img_dir)) {
				if(!mkdir($img_dir)){
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;','');</script>";
							exit;
						}else{
							showerror('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;');
						}
					}
			}
			$pic = $img_dir . $pics;
			if (@copy($_FILES['Filedata']['tmp_name'], $pic) || @move_uploaded_file($_FILES['Filedata']['tmp_name'], $pic)) {
				$imageinfo = getimagesize($pic);
				if($settings['iswatermark']['value']){
					$image->Watermark(DISCUZ_ROOT.'./'.$pic,'', 'forum');
				}
				$w64 = $imageinfo[0] < 64 ? $imageinfo[0] : 64;
				$h64 = $imageinfo[1] < 64 ? $imageinfo[1] : 64;
				$w100 = $imageinfo[0] < 100 ? $imageinfo[0] : 100;
				$h100 = $imageinfo[1] < 100 ? $imageinfo[1] : 100;
				$w640 = $imageinfo[0] < 640 ? $imageinfo[0] : 640;
				$h480 = $imageinfo[1] < 480 ? $imageinfo[1] : 480;
				img2thumb($pic, $pic . '.100x100.jpg', $w100, $h100);
				img2thumb($pic, $pic . '.64x64.jpg', $w64, $h64);
				img2thumb($pic, $pic . '.640x480.jpg', $w640, $h480);
				@unlink($_FILES['Filedata']['tmp_name']);
			}
		}
	}
	$aid = C::t('#aljzp#aljzp_attachment') -> insert(array('pic' => $pic),true);
	echo "{\"picid\":\"".$aid."\", \"url\":\"".$pic."\"}";
} else if($_GET['act'] == 'deleteattach'){
	$aid = htmlspecialchars(intval($_GET['aid']));
	if($aid){
		$attach = C::t('#aljzp#aljzp_attachment') -> fetch($aid);
		C::t('#aljzp#aljzp_attachment') -> delete($aid);
		@unlink($attach['pic']);
		@unlink($attach['pic'].'.100x100.jpg');
		@unlink($attach['pic'].'.64x64.jpg');
		@unlink($attach['pic'].'.640x480.jpg');
		


		if(empty($_GET['m'])){
			include template('common/header_ajax');
			echo '<script type="text/javascript">$("td_'.$_GET['aid'].'").remove()</script>';
			include template('common/footer_ajax');
		}
	}
}  else if($_GET['act'] == 'mobile_deleteattach'){
	$aid = htmlspecialchars(intval($_GET['aid']));
	if($aid && $_GET['formhash'] = formhash()){
		$attach = C::t('#aljzp#aljzp_attachment') -> fetch($aid);
		C::t('#aljzp#aljzp_attachment') -> delete($aid);
		@unlink($attach['pic']);
		@unlink($attach['pic'].'.100x100.jpg');
		@unlink($attach['pic'].'.64x64.jpg');
		@unlink($attach['pic'].'.640x480.jpg');


		echo 1;

	}
} else if($_GET['act'] == 'mupload'){
	$fn = (isset($_GET['base64']) ? $_GET['base64'] : false);
	$fn_length = intval($_GET['size']);
	//debug($fn_length);
	if ($fn && $fn_length == strlen($fn) && $_GET['hash'] == FORMHASH) {
		$rand = rand(100, 999);
		$pics = date("YmdHis") . $rand . '.jpg';
		$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
		if (!is_dir($img_dir)) {
			if(!mkdir($img_dir)){
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;','');</script>";
							exit;
						}else{
							showerror('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;');
						}
					}
		}
		$pic = $img_dir . $pics;
		file_put_contents($pic,file_get_contents($fn));
		if (file_exists($pic)) {
			$imageinfo = getimagesize($pic);
			if($settings['iswatermark']['value']){
				$image->Watermark(DISCUZ_ROOT.'./'.$pic,'', 'forum');
			}
			$w64 = $imageinfo[0] < 64 ? $imageinfo[0] : 64;
			$h64 = $imageinfo[1] < 64 ? $imageinfo[1] : 64;

			$w640 = $imageinfo[0] < 640 ? $imageinfo[0] : 640;
			$h480 = $imageinfo[1] < 480 ? $imageinfo[1] : 480;
			$w140 = $imageinfo[0] < 100 ? $imageinfo[0] : 100;
			$h100 = $imageinfo[1] < 100 ? $imageinfo[1] : 100;

			img2thumb($pic, $pic . '.100x100.jpg', $w140, $h100);
			img2thumb($pic, $pic . '.64x64.jpg', $w64, $h64);
			img2thumb($pic, $pic . '.640x480.jpg', $w640, $h480);
		}
		$aid = C::t('#aljzp#aljzp_attachment') -> insert(array('pic' => $pic),true);
		echo "{\"picid\":\"".$aid."\", \"url\":\"".$pic."\"}";
		//echo $aid;
		exit();
	}
} else {
	if($settings['is_new_index']['value']){
		$todayviews = C::t('#aljzp#aljzp_log')->fetch_all_by_day();
		$regions = C::t('#aljzp#aljzp_region')->range();
		$rs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid(0);
		$rrs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid($_GET['rid']);
		$subrrs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid($_GET['subrid']);
		$pos = C::t('#aljzp#aljzp_position')->fetch_all_by_upid(0);
		$prs = C::t('#aljzp#aljzp_position')->fetch_all_by_upid($_GET['pid']);
		$currpage = intval($_GET['page']) ? intval($_GET['page']) : 1;
		$perpage = $config['page'];
		if($_GET['mobile']=='1'||$_GET['mobile']=='2'){
			if($_G['charset']=='gbk'){ $_GET['sex']=diconv($_GET['sex'],'utf-8','gbk');}
		}
		if(($_G['charset']=='gbk'&&!defined('IN_MOBILE')&&$config['is_header'])){
			$_GET['search']=diconv($_GET['search'],'utf-8','gbk');
		}

		$start = ($currpage - 1) * $perpage;
		$conndtion = array(
			'search' => $_GET['search'],
			'rid' => $_GET['region']?$_GET['region']:$_GET['rid'],
			'subrid' => $_GET['region1']?$_GET['region1']:$_GET['subrid'],
			'subsubrid' => $_GET['region2']?$_GET['region2']:$_GET['subsubrid'],
			'sex' => $_GET['sex'],
			'pay' => $_GET['pay'],
			'pos' => $_GET['pid'],
			'pos1' => $_GET['subpid'],
			'wanted' => $_GET['wanted'],
			'solve' => $_GET['solve'],
		);
		if($config['is_solve']){
			$conndtion['is_solve']=1;
		}
		$num = C::t('#aljzp#aljzp')->count_by_status($conndtion);
		$urllist = '&act=list';
		$lplist = C::t('#aljzp#aljzp')->fetch_all_by_addtime($start, $perpage, $conndtion);
		foreach($lplist as $k=>$v){
			if(TIMESTAMP>$v['topetime']&&$v['topetime']){
				DB::update('aljzp',array('topstime'=>'','topetime'=>''),'id='.$v[id]);
			}
			$lplist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
		}
		$lplist = dhtmlspecialchars($lplist);
		$geturl = array(
			'id' => $pluginid,
			'search' => $_GET['search'],
			'rid' => $_GET['rid'],
			'subrid' => $_GET['subrid'],
			'subsubrid' => $_GET['subsubrid'],
			'pay' => $_GET['pay'],
			'wanted' => $_GET['wanted'],
			'pid' => $_GET['pid'],
			'subpid' => $_GET['subpid'],
			'solve' => $_GET['solve'],
			'view' => $_GET['view'],
			'sex' => $_GET['sex'],
			'pic' => $_GET['pic'],
		);
		$pagingurl = getaljurl($geturl,'');
		$paging = helper_page :: multi($num, $perpage, $currpage, $pagingurl, 0, 11, false, false);
		$tuijian = DB::fetch_all("SELECT * FROM ".DB::table('aljzp')." where state=0 and tuijian=1 ORDER BY id desc limit 0,9");
		foreach($tuijian as $k=>$v){
			$tuijian[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
		}
		$toplist = C::t('#aljzp#aljzp_toplog')->fetch_all_by_dateline();
		foreach($toplist as $k=>$v){
			$toplist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
		}
		$navtitle = $config['title'];
		$metakeywords = $config['keywords'];
		$metadescription = $config['description'];
		if($aljzp_seo['list']['seotitle']){
			if($_GET['rid']){
				$title=$regions[$_GET['rid']]['subject'];
				$title1 = $title;
			}
			if($_GET['subrid']){
				$title=$regions[$_GET['subrid']]['subject'];
				$title2=$title;

			}
			if($_GET['subsubrid']){
				$title=$regions[$_GET['subsubrid']]['subject'];
				$title3=$title;
			}
			if($_GET['pay']){
				$zujin=$pay_types[$_GET['pay']];
			}
			if($_GET['pid']){
				$cat=$pos_zw[$_GET['pid']]['subject'];
			}
			if($_GET['subpid']){
				$cat2=$pos_zw[$_GET['subpid']]['subject'];
			}
			$seodata = array('bbname' => $_G['setting']['bbname'],'cat'=>$cat,'cat2'=>$cat2,'zujin'=>$zujin,'region'=>$title1,'region2'=>$title2,'region3'=>$title3);
			list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzp_seo['list']);
		}
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
			include template('aljzp:index');
		}else{
			include template('diy:aljzp_list', null, 'source/plugin/aljzp/template');
		}
	}else{
		$index_lz = explode ("\n", str_replace ("\r", "", $config ['index_lz']));
		foreach($index_lz as $key=>$value){
			$arr=explode('|',$value);
			$lz_types[$arr[0]]=$arr[1];
		}
		$index_gg = explode ("\n", str_replace ("\r", "", $config ['index_gg']));
		foreach($index_gg as $key=>$value){
			$arr=explode('|',$value);
			$gg_types[$arr[0]]=$arr[1];
		}
		$pos = C::t('#aljzp#aljzp_position')->fetch_all_by_upid(0);
		$navtitle = $config['title'];
		$metakeywords = $config['keywords'];
		$metadescription = $config['description'];

		if($settings[mobile_index_new_lz]['value']){
			$mobile_lz_moren = $settings[mobile_index_new_lz]['value'];
		}else{
			$mobile_lz_moren ='#|source/plugin/'.$pluginid.'/images/m_lz2.jpg|&#31934;&#21697;&#25554;&#20214;
	#|source/plugin/'.$pluginid.'/images/m_lz1.jpg|&#27714;&#32844;&#25307;&#32856;';
		}
		$mobile_lz = explode ("\n", str_replace ("\r", "", $mobile_lz_moren));
		foreach($mobile_lz as $key=>$value){
			$arr=explode('|',$value);
			$m_lz_types[]=$arr;
		}
		$mobile_index_new_dh = explode ("\n", str_replace ("\r", "", $settings['mobile_index_new_dh']['value']));
		foreach($mobile_index_new_dh as $key=>$value){
			$arr=explode('|',$value);
			$mobile_index_new_dh_types[]=$arr;
		}
		$mobile_index_ad = explode ("\n", str_replace ("\r", "", $settings['mobile_index_ad']['value']));
		foreach($mobile_index_ad as $key=>$value){
			$arr=explode('|',$value);
			$mobile_index_ad_arr[]=$arr;
		}
		$mobile_index_page=explode('|',$settings['mobile_index_page']['value']);
		if($mobile_index_page[0]){
			$page_r = $mobile_index_page[0];
		}else{
			$page_r = 5;
		}
		if($mobile_index_page[1]){
			$page_c = $mobile_index_page[1];
		}else{
			$page_c = 5;
		}
		if($mobile_index_page[2]){
			$page_h = $mobile_index_page[2];
		}else{
			$page_h = 5;
		}
		$tuijian = DB::fetch_all("SELECT * FROM ".DB::table('aljzp')." where state=0 and tuijian=1 ORDER BY id desc limit 0,$page_h");
		if($tuijian){
			foreach($tuijian as $k=>$v){
				$tuijian[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
			}
			$lplist = $tuijian;
		}else{
			$lplist = C::t('#aljzp#aljzp')->fetch_all_by_addtime(0, $page_h, $conndtion);
			foreach($lplist as $k=>$v){
				if(TIMESTAMP>$v['topetime']&&$v['topetime']){
					DB::update('aljzp',array('topstime'=>'','topetime'=>''),'id='.$v[id]);
				}
				$lplist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
			}
		}

		$lplist = dhtmlspecialchars($lplist);
		$rzlplist = DB::fetch_all("SELECT * FROM ".DB::table('aljzp_attestation')." where sign=1 and tuijian=1 ORDER BY timestamp desc limit 0,$page_c");
		if(!$rzlplist){
			$rzlplist = C::t('#aljzp#aljzp_attestation')->fetch_all_by_addtime(0, $page_c, $conndtion);
		}
		$rzlplist = dhtmlspecialchars($rzlplist);
		$reslplist = DB::fetch_all("SELECT * FROM ".DB::table('aljzp_resume')." where privacy =0 and tuijian=1 ORDER BY timestamp desc limit 0,$page_r");
		if(!$reslplist){
			$reslplist = C::t('#aljzp#aljzp_resume')->fetch_all_by_addtime(0, $page_r, $conndtion);
		}
		foreach($reslplist as $k=>$v){

			$reslplist[$k]['rewrite']=str_replace ("{uid}", $v['uid'], $config ['res_view']);
		}
		$reslplist = dhtmlspecialchars($reslplist);
		if($aljzp_seo['index']['seotitle']){
			$seodata = array('bbname' => $_G['setting']['bbname']);
			list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzp_seo['index']);
		}
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
			include template('aljzp:aljzp_index');
		}else{
			include template('diy:aljzp_index', null, 'source/plugin/aljzp/template');
		}
	}
}

function showmsg($msg, $close, $id) {
    if ($close == 1) {
        $str = "parent.hideWindow('$close');";
    } else if ($close == 2) {
        $str = "parent.location.href='plugin.php?id=aljzp&act=view&lid=" . $id . "'";
    } else {
        $str = "parent.location=parent.location;";
    }
    include template('aljzp:showmsg');
    exit;
}

function showerror($msg) {
    include template('aljzp:showerror');
    exit;
}

function img2thumb($src_img, $dst_img, $width = 75, $height = 75, $cut = 0, $proportion = 0) {
    if (!is_file($src_img)) {
        return false;
    }
    $ot = fileext($dst_img);
    $otfunc = 'image' . ($ot == 'jpg' ? 'jpeg' : $ot);
    $srcinfo = getimagesize($src_img);
    $src_w = $srcinfo[0];
    $src_h = $srcinfo[1];
    $type = strtolower(substr(image_type_to_extension($srcinfo[2]), 1));
    $createfun = 'imagecreatefrom' . ($type == 'jpg' ? 'jpeg' : $type);

    $dst_h = $height;
    $dst_w = $width;
    $x = $y = 0;

    if (($width > $src_w && $height > $src_h) || ($height > $src_h && $width == 0) || ($width > $src_w && $height == 0)) {
        $proportion = 1;
    }
    if ($width > $src_w) {
        $dst_w = $width = $src_w;
    }
    if ($height > $src_h) {
        $dst_h = $height = $src_h;
    }

    if (!$width && !$height && !$proportion) {
        return false;
    }
    if (!$proportion) {
        if ($cut == 0) {
            if ($dst_w && $dst_h) {
                if ($dst_w / $src_w > $dst_h / $src_h) {
                    $dst_w = $src_w * ($dst_h / $src_h);
                    $x = 0 - ($dst_w - $width) / 2;
                } else {
                    $dst_h = $src_h * ($dst_w / $src_w);
                    $y = 0 - ($dst_h - $height) / 2;
                }
            } else if ($dst_w xor $dst_h) {
                if ($dst_w && !$dst_h) {
                    $propor = $dst_w / $src_w;
                    $height = $dst_h = $src_h * $propor;
                } else if (!$dst_w && $dst_h) {
                    $propor = $dst_h / $src_h;
                    $width = $dst_w = $src_w * $propor;
                }
            }
        } else {
            if (!$dst_h) {
                $height = $dst_h = $dst_w;
            }
            if (!$dst_w) {
                $width = $dst_w = $dst_h;
            }
            $propor = min(max($dst_w / $src_w, $dst_h / $src_h), 1);
            $dst_w = (int) round($src_w * $propor);
            $dst_h = (int) round($src_h * $propor);
            $x = ($width - $dst_w) / 2;
            $y = ($height - $dst_h) / 2;
        }
    } else {
        $proportion = min($proportion, 1);
        $height = $dst_h = $src_h * $proportion;
        $width = $dst_w = $src_w * $proportion;
    }

    $src = $createfun($src_img);
    $dst = imagecreatetruecolor($width ? $width : $dst_w, $height ? $height : $dst_h);
    $white = imagecolorallocate($dst, 255, 255, 255);
    imagefill($dst, 0, 0, $white);

    if (function_exists('imagecopyresampled')) {
        imagecopyresampled($dst, $src, $x, $y, 0, 0, $dst_w, $dst_h, $src_w, $src_h);
    } else {
        imagecopyresized($dst, $src, $x, $y, 0, 0, $dst_w, $dst_h, $src_w, $src_h);
    }
    $otfunc($dst, $dst_img);
    imagedestroy($dst);
    imagedestroy($src);
    return true;
}
function hidtel($phone)
{
    $IsWhat = preg_match('/([0-9][0-9]{2,3}[\-]?[1-9][0-9]{6,7}[\-]?[0-9]?)/i',$phone); //�̶��绰

    if($IsWhat == 1)
    {
        return preg_replace('/([0-9][0-9]{2,3}[\-]?[1-9])[0-9]{3,4}([0-9]{3}[\-]?[0-9]?)/i','$1****$2',$phone);
    }
    else
    {
        return  preg_replace('/([0-9][0-9]{1}[0-9])[0-9]{4}([0-9]{4})/i','$1****$2',$phone);
    }
}
function stripBBCode($text_to_search) {
	 $pattern = '|[[\/\!]*?[^\[\]]*?]|si';
	 $replace = '';
	 return preg_replace($pattern, $replace, $text_to_search);
}
function discuzcode_mobile($message, $smileyoff, $bbcodeoff, $htmlon = 0, $allowsmilies = 1, $allowbbcode = 1, $allowimgcode = 1, $allowhtml = 0, $jammer = 0, $parsetype = '0', $authorid = '0', $allowmediacode = '0', $pid = 0, $lazyload = 0, $pdateline = 0, $first = 0) {
	global $_G;

	static $authorreplyexist;

	if($pid && strpos($message, '[/password]') !== FALSE) {
		if($authorid != $_G['uid'] && !$_G['forum']['ismoderator']) {
			$message = preg_replace("/\s?\[password\](.+?)\[\/password\]\s?/ie", "parsepassword('\\1', \$pid)", $message);
			if($_G['forum_discuzcode']['passwordlock'][$pid]) {
				return '';
			}
		} else {
			$message = preg_replace("/\s?\[password\](.+?)\[\/password\]\s?/ie", "", $message);
			$_G['forum_discuzcode']['passwordauthor'][$pid] = 1;
		}
	}

	if($parsetype != 1 && !$bbcodeoff && $allowbbcode && (strpos($message, '[/code]') || strpos($message, '[/CODE]')) !== FALSE) {
		$message = preg_replace("/\s?\[code\](.+?)\[\/code\]\s?/ies", "codedisp('\\1')", $message);
	}

	$msglower = strtolower($message);

	$htmlon = $htmlon && $allowhtml ? 1 : 0;

	if(!$htmlon) {
		$message = dhtmlspecialchars($message);
	} else {
		$message = preg_replace("/<script[^\>]*?>(.*?)<\/script>/i", '', $message);
	}

	if($_G['setting']['plugins']['func'][HOOKTYPE]['discuzcode']) {
		$_G['discuzcodemessage'] = & $message;
		$param = func_get_args();
		hookscript('discuzcode', 'global', 'funcs', array('param' => $param, 'caller' => 'discuzcode'), 'discuzcode');
	}

	if(!$smileyoff && $allowsmilies) {
		$message = parsesmiles($message);
	}

	if($_G['setting']['allowattachurl'] && strpos($msglower, 'attach://') !== FALSE) {
		$message = preg_replace("/attach:\/\/(\d+)\.?(\w*)/ie", "parseattachurl('\\1', '\\2', 1)", $message);
	}

	if($allowbbcode) {
		if(strpos($msglower, 'ed2k://') !== FALSE) {
			$message = preg_replace("/ed2k:\/\/(.+?)\//e", "parseed2k('\\1')", $message);
		}
	}

	if(!$bbcodeoff && $allowbbcode) {
		if(strpos($msglower, '[/url]') !== FALSE) {
			$message = preg_replace("/\[url(=((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\/\/|www\.|mailto:)?([^\r\n\[\"']+?))?\](.+?)\[\/url\]/ies", "parseurl('\\1', '\\5', '\\2')", $message);
		}
		if(strpos($msglower, '[/email]') !== FALSE) {
			$message = preg_replace("/\[email(=([a-z0-9\-_.+]+)@([a-z0-9\-_]+[.][a-z0-9\-_.]+))?\](.+?)\[\/email\]/ies", "parseemail('\\1', '\\4')", $message);
		}

		$nest = 0;
		while(strpos($msglower, '[table') !== FALSE && strpos($msglower, '[/table]') !== FALSE){
			$message = preg_replace("/\[table(?:=(\d{1,4}%?)(?:,([\(\)%,#\w ]+))?)?\]\s*(.+?)\s*\[\/table\]/ies", "parsetable('\\1', '\\2', '\\3')", $message);
			if(++$nest > 4) break;
		}

		$message = str_replace(array(
			'[/color]', '[/backcolor]', '[/size]', '[/font]', '[/align]', '[b]', '[/b]', '[s]', '[/s]', '[hr]', '[/p]',
			'[i=s]', '[i]', '[/i]', '[u]', '[/u]', '[list]', '[list=1]', '[list=a]',
			'[list=A]', "\r\n[*]", '[*]', '[/list]', '[indent]', '[/indent]', '[/float]'
			), array(
			'</font>', '</font>', '</font>', '</font>', '</div>', '<strong>', '</strong>', '<strike>', '</strike>', '<hr class="l" />', '</p>', '<i class="pstatus">', '<i>',
			'</i>', '<u>', '</u>', '<ul>', '<ul type="1" class="litype_1">', '<ul type="a" class="litype_2">',
			'<ul type="A" class="litype_3">', '<li>', '<li>', '</ul>', '<blockquote>', '</blockquote>', '</span>'
			), preg_replace(array(
			"/\[color=([#\w]+?)\]/i",
			"/\[color=((rgb|rgba)\([\d\s,]+?\))\]/i",
			"/\[backcolor=([#\w]+?)\]/i",
			"/\[backcolor=((rgb|rgba)\([\d\s,]+?\))\]/i",
			"/\[size=(\d{1,2}?)\]/i",
			"/\[size=(\d{1,2}(\.\d{1,2}+)?(px|pt)+?)\]/i",
			"/\[font=([^\[\<]+?)\]/i",
			"/\[align=(left|center|right)\]/i",
			"/\[p=(\d{1,2}|null), (\d{1,2}|null), (left|center|right)\]/i",
			"/\[float=left\]/i",
			"/\[float=right\]/i"

			), array(
			"<font color=\"\\1\">",
			"<font style=\"color:\\1\">",
			"<font style=\"background-color:\\1\">",
			"<font style=\"background-color:\\1\">",
			"<font size=\"\\1\">",
			"<font style=\"font-size:\\1\">",
			"<font face=\"\\1\">",
			"<div align=\"\\1\">",
			"<p style=\"line-height:\\1px;text-indent:\\2em;text-align:\\3\">",
			"<span style=\"float:left;margin-right:5px\">",
			"<span style=\"float:right;margin-left:5px\">"
			), $message));

		if($pid && !defined('IN_MOBILE')) {
			$message = preg_replace("/\s?\[postbg\]\s*([^\[\<\r\n;'\"\?\(\)]+?)\s*\[\/postbg\]\s?/ies", "parsepostbg('\\1', '$pid')", $message);
		} else {
			$message = preg_replace("/\s?\[postbg\]\s*([^\[\<\r\n;'\"\?\(\)]+?)\s*\[\/postbg\]\s?/is", "", $message);
		}

		if($parsetype != 1) {
			if(strpos($msglower, '[/quote]') !== FALSE) {
				$message = preg_replace("/\s?\[quote\][\n\r]*(.+?)[\n\r]*\[\/quote\]\s?/is", tpl_quote(), $message);
			}
			if(strpos($msglower, '[/free]') !== FALSE) {
				$message = preg_replace("/\s*\[free\][\n\r]*(.+?)[\n\r]*\[\/free\]\s*/is", tpl_free(), $message);
			}
		}
		if(!defined('IN_MOBILE')) {
			if(strpos($msglower, '[/media]') !== FALSE) {
				$message = preg_replace("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/ies", $allowmediacode ? "parsemedia('\\1', '\\2')" : "bbcodeurl('\\2', '<a href=\"{url}\" target=\"_blank\">{url}</a>')", $message);
			}
			if(strpos($msglower, '[/audio]') !== FALSE) {
				$message = preg_replace("/\[audio(=1)*\]\s*([^\[\<\r\n]+?)\s*\[\/audio\]/ies", $allowmediacode ? "parseaudio('\\2', 400)" : "bbcodeurl('\\2', '<a href=\"{url}\" target=\"_blank\">{url}</a>')", $message);
			}
			if(strpos($msglower, '[/flash]') !== FALSE) {
				$message = preg_replace("/\[flash(=(\d+),(\d+))?\]\s*([^\[\<\r\n]+?)\s*\[\/flash\]/ies", $allowmediacode ? "parseflash('\\2', '\\3', '\\4');" : "bbcodeurl('\\4', '<a href=\"{url}\" target=\"_blank\">{url}</a>')", $message);
			}
		} else {
			if(strpos($msglower, '[/media]') !== FALSE) {
				$message = preg_replace("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/is", "[media]\\2[/media]", $message);
			}
			if(strpos($msglower, '[/audio]') !== FALSE) {
				$message = preg_replace("/\[audio(=1)*\]\s*([^\[\<\r\n]+?)\s*\[\/audio\]/is", "[media]\\2[/media]", $message);
			}
			if(strpos($msglower, '[/flash]') !== FALSE) {
				$message = preg_replace("/\[flash(=(\d+),(\d+))?\]\s*([^\[\<\r\n]+?)\s*\[\/flash\]/is", "[media]\\4[/media]", $message);
			}
		}

		if($parsetype != 1 && $allowbbcode < 0 && isset($_G['cache']['bbcodes'][-$allowbbcode])) {
			$message = preg_replace($_G['cache']['bbcodes'][-$allowbbcode]['searcharray'], $_G['cache']['bbcodes'][-$allowbbcode]['replacearray'], $message);
		}
		if($parsetype != 1 && strpos($msglower, '[/hide]') !== FALSE && $pid) {
			if($_G['setting']['hideexpiration'] && $pdateline && (TIMESTAMP - $pdateline) / 86400 > $_G['setting']['hideexpiration']) {
				$message = preg_replace("/\[hide[=]?(d\d+)?[,]?(\d+)?\]\s*(.*?)\s*\[\/hide\]/is", "\\3", $message);
				$msglower = strtolower($message);
			}
			if(strpos($msglower, '[hide=d') !== FALSE) {
				$message = preg_replace("/\[hide=(d\d+)?[,]?(\d+)?\]\s*(.*?)\s*\[\/hide\]/ies", "expirehide('\\1','\\2','\\3', $pdateline)", $message);
				$msglower = strtolower($message);
			}
			if(strpos($msglower, '[hide]') !== FALSE) {
				if($authorreplyexist === null) {
					if(!$_G['forum']['ismoderator']) {
						if($_G['uid']) {
							$authorreplyexist = C::t('forum_post')->fetch_pid_by_tid_authorid($_G['tid'], $_G['uid']);
						}
					} else {
						$authorreplyexist = TRUE;
					}
				}
				if($authorreplyexist) {
					$message = preg_replace("/\[hide\]\s*(.*?)\s*\[\/hide\]/is", tpl_hide_reply(), $message);
				} else {
					$message = preg_replace("/\[hide\](.*?)\[\/hide\]/is", tpl_hide_reply_hidden(), $message);
					$message = '<script type="text/javascript">replyreload += \',\' + '.$pid.';</script>'.$message;
				}
			}
			if(strpos($msglower, '[hide=') !== FALSE) {
				$message = preg_replace("/\[hide=(\d+)\]\s*(.*?)\s*\[\/hide\]/ies", "creditshide(\\1,'\\2', $pid, $authorid)", $message);
			}
		}
	}

	if(!$bbcodeoff) {
		if($parsetype != 1 && strpos($msglower, '[swf]') !== FALSE) {
			$message = preg_replace("/\[swf\]\s*([^\[\<\r\n]+?)\s*\[\/swf\]/ies", "bbcodeurl('\\1', ' <img src=\"'.STATICURL.'image/filetype/flash.gif\" align=\"absmiddle\" alt=\"\" /> <a href=\"{url}\" target=\"_blank\">Flash: {url}</a> ')", $message);
		}

		if(defined('IN_MOBILE') && !defined('TPL_DEFAULT') && !defined('IN_MOBILE_API')) {
			$allowimgcode = 1;
		}

		$attrsrc = !IS_ROBOT && $lazyload ? 'file' : 'src';
		if(strpos($msglower, '[/img]') !== FALSE) {
			$message = preg_replace(array(
				"/\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/ies",
				"/\[img=(\d{1,4})[x|\,](\d{1,4})\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/ies"
			), $allowimgcode ? array(
				"parseimg(0, 0, '\\1', ".intval($lazyload).", ".intval($pid).", 'onmouseover=\"img_onmouseoverfunc(this)\" ".($lazyload ? "lazyloadthumb=\"1\"" : "onload=\"thumbImg(this)\"")."')",
				"parseimg('\\1', '\\2', '\\3', ".intval($lazyload).", ".intval($pid).")"
			) : ($allowbbcode ? array(
				(!defined('IN_MOBILE') ? "bbcodeurl('\\1', '<a href=\"{url}\" target=\"_blank\">{url}</a>')" : "bbcodeurl('\\1', '')"),
				(!defined('IN_MOBILE') ? "bbcodeurl('\\3', '<a href=\"{url}\" target=\"_blank\">{url}</a>')" : "bbcodeurl('\\3', '')"),
			) : array("bbcodeurl('\\1', '{url}')", "bbcodeurl('\\3', '{url}')")), $message);
		}
	}
	//debug($message);
	for($i = 0; $i <= $_G['forum_discuzcode']['pcodecount']; $i++) {
		$message = str_replace("[\tDISCUZ_CODE_$i\t]", $_G['forum_discuzcode']['codehtml'][$i], $message);
	}

	unset($msglower);

	if($jammer) {
		$message = preg_replace("/\r\n|\n|\r/e", "jammer()", $message);
	}

	if($first) {
		if(helper_access::check_module('group')) {
			$message = preg_replace("/\[groupid=(\d+)\](.*)\[\/groupid\]/i", lang('forum/template', 'fromgroup').': <a href="forum.php?mod=forumdisplay&fid=\\1" target="_blank">\\2</a>', $message);
		} else {
			$message = preg_replace("/(\[groupid=\d+\].*\[\/groupid\])/i", '', $message);
		}

	}
	return $htmlon ? $message : nl2br(str_replace(array("\t", '   ', '  '), array('&nbsp; &nbsp; &nbsp; &nbsp; ', '&nbsp; &nbsp;', '&nbsp;&nbsp;'), $message));
}
function create_token($biaoshi) {
	//��ǰʱ���

	$timestamp = TIMESTAMP;
	dsetcookie($biaoshi,$timestamp);
	return md5( $timestamp );
}
function valid_token($aljbd_token,$getcook,$biaoshi) {
	if(isset($getcook) && isset($aljbd_token) && $aljbd_token == md5($getcook))
	{
		//����ȷ�������������ٵ�
		dsetcookie($biaoshi,'');
		return true;
	}
	return false;
}
function substr_cut($user_name){
    $strlen     = dstrlen($user_name);
    $firstStr     = substr($user_name, 0, 1);
    $lastStr     = substr($user_name, -1, 1);
    return $strlen == 2 ? $firstStr . str_repeat('*', dstrlen($user_name) - 1) : $firstStr . str_repeat("*", $strlen - 2) . $lastStr;
}
function is_mobile_l($mobile) {
       return preg_match('#^\d[\d-]{3,20}\d$#', $mobile) ? true : false;
}
function getaljurl($geturl,$param){
	if($param){
		foreach($param as $k => $v){
		$geturl[$k] = $v;
		}
	}
	require_once libfile('function/home');
	return 'plugin.php?'.url_implode($geturl);
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>
