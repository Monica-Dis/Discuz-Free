<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljzp` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `addtime` int(10) NOT NULL,
  `updatetime` int(10) NOT NULL,
  `wanted` tinyint(3) NOT NULL,
  `title` varchar(255) NOT NULL,
  `zufangtype` tinyint(3) NOT NULL,
  `zujin` int(10) NOT NULL,
  `content` mediumtext NOT NULL,
  `pic1` varchar(255) NOT NULL,
  `pic2` varchar(255) NOT NULL,
  `pic3` varchar(255) NOT NULL,
  `pic4` varchar(255) NOT NULL,
  `pic5` varchar(255) NOT NULL,
  `pic6` varchar(255) NOT NULL,
  `pic7` varchar(255) NOT NULL,
  `pic8` varchar(255) NOT NULL,
  `region` int(11) NOT NULL,
  `region1` int(10) NOT NULL,
  `region2` varchar(255) NOT NULL,
  `region3` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `views` mediumint(9) NOT NULL,
  `qq` bigint(20) NOT NULL,
  `new` int(11) NOT NULL,
  `tuijian` int(11) NOT NULL,
  `displayorder` int(11) NOT NULL,
  `lxr` varchar(255) NOT NULL,
  `work_time` int(11) NOT NULL,
  `sex` varchar(255) NOT NULL,
  `xueli` int(11) NOT NULL,
  `work_nx` int(11) NOT NULL,
  `renshu` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gongsi` varchar(255) NOT NULL,
  `pos` int(11) NOT NULL,
  `pos1` int(11) NOT NULL,
  `topstime` int(11) NOT NULL,
  `topetime` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `pay` int(11) NOT NULL,
  `qrcode` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `clientip` varchar(255) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `solve` tinyint(3) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `topetime` (`topetime`),
  KEY `updatetime` (`updatetime`),
  KEY `displayorder` (`displayorder`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_attestation` (
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `id_card` bigint(20) NOT NULL,
  `id_pic` varchar(255) NOT NULL,
  `qiyename` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `tel` VARCHAR( 255 ) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `sign` tinyint(4) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `jieshao` mediumtext NOT NULL,
  `pic1` varchar(255) NOT NULL,
  `pic2` varchar(255) NOT NULL,
  `pic3` varchar(255) NOT NULL,
  `pic4` varchar(255) NOT NULL,
  `pic5` varchar(255) NOT NULL,
  `pic6` varchar(255) NOT NULL,
  `pic7` varchar(255) NOT NULL,
  `pic8` varchar(255) NOT NULL,
  `property` int(11) NOT NULL,
  `employee` int(11) NOT NULL,
  `region` int(11) NOT NULL,
  `region1` int(11) NOT NULL,
  `region2` varchar(255) NOT NULL,
  `weal` varchar(255) NOT NULL,
  `linkman` varchar(255) NOT NULL,
  `linkmanjob` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `btntrade` int(11) NOT NULL,
  `pic9` varchar(255) NOT NULL,
  `pic10` varchar(255) NOT NULL,
  `follow` int(11) NOT NULL,
  `views` int(11) NOT NULL,
  `tuijian` tinyint(3),
  PRIMARY KEY  (`uid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_setting` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `a` varchar(255) NOT NULL,
  `b` varchar(255) NOT NULL,
  `c` text NOT NULL,
  `d` int(11) NOT NULL,
  `e` int(11) NOT NULL,
  PRIMARY KEY (`key`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_getresume` (
  `id` int(11) NOT NULL auto_increment,
  `getuid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `Position_name` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `sign` tinyint(4) NOT NULL,
  `lid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_log` (
  `day` int(11) NOT NULL,
  `views` mediumint(9) NOT NULL,
  PRIMARY KEY  (`day`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_position` (
  `id` mediumint(9) unsigned NOT NULL auto_increment,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_reflashlog` (
  `id` int(11) NOT NULL auto_increment,
  `lid` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `pay` int(10) NOT NULL,
  `extcredit` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_region` (
  `id` mediumint(9) unsigned NOT NULL auto_increment,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  `level` tinyint(3) NOT NULL,
  `havechild` tinyint(3) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_resume` (
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `pos` int(11) NOT NULL,
  `pos1` int(11) NOT NULL,
  `pos2` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sex` varchar(255) NOT NULL,
  `ymd` varchar(255) NOT NULL,
  `xueli` int(11) NOT NULL,
  `work_nx` int(11) NOT NULL,
  `salary` int(11) NOT NULL,
  `work_jl` mediumtext NOT NULL,
  `my_introduction` mediumtext NOT NULL,
  `region` int(11) NOT NULL,
  `region1` int(11) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `tel` VARCHAR( 255 ) NOT NULL,
  `email` varchar(255) NOT NULL,
  `resfile` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `view` int(11) NOT NULL,
  `xiazaicishu` int(11) NOT NULL,
  `toudicishu` int(11) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `tuijian` tinyint(3),
  `privacy` tinyint(3),
  PRIMARY KEY  (`uid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_sentresume` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `Position_name` varchar(255) NOT NULL,
  `gongsi` varchar(255) NOT NULL,
  `lid` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `sign` tinyint(4) NOT NULL,
  `rid` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_toplog` (
  `id` int(10) NOT NULL auto_increment,
  `lid` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `pay` int(10) NOT NULL,
  `extcredit` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `endtime` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` TINYINT(3) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_user` (
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `count` int(10) NOT NULL default '0',
  `updatecount` int(10) NOT NULL default '0',
  `top` int(10) NOT NULL default '0',
  `last` int(10) NOT NULL,
  PRIMARY KEY  (`uid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_comment` (
  `id` int(11) NOT NULL auto_increment,
  `upid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `lid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `content` mediumtext NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `upid` (`upid`),
  KEY `dateline` (`dateline`),
  KEY `lid` (`lid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_resume_log` (
  `uid` int(11) NOT NULL,
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(255) NOT NULL,
  `res_uid` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `sign` tinyint(4) NOT NULL,
  `money` int(11) NOT NULL,
  `res_name` varchar(255) NOT NULL,
  `res_tel` varchar(255) NOT NULL,
  `extcredit` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_attachment` (
  `aid` int(10) NOT NULL AUTO_INCREMENT,
  `pic` varchar(255) NOT NULL,
  `pid` int(10) NOT NULL,
  PRIMARY KEY (`aid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_company_follow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `cid` (`cid`)
)
EOF;
runquery($sql);
if(file_exists( DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php')&&file_exists( DISCUZ_ROOT . './source/plugin/aljzp/template/touch/index.htm')){
	$pluginid = 'aljzp';
	$Hooks = array(
		'forumdisplay_topBar',
	);
	$data = array();
	foreach ($Hooks as $Hook) {
		$data[] = array($Hook => array('plugin' => $pluginid, 'include' => 'api.class.php', 'class' => $pluginid . '_api', 'method' => $Hook));
	}
	require_once DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';
	WeChatHook::updateAPIHook($data);
}

$finish = TRUE;
?>