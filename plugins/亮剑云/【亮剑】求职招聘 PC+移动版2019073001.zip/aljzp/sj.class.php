<?php
	if(!defined('IN_DISCUZ')) {
	exit('Access Deined');
}
class mobileplugin_aljzp {
	function index_top_mobile() {
		global $_G;
		$config = $_G ['cache'] ['plugin'] ['aljzp'];
		if(!$config['sjurl']){
			return;
		}
		if (!file_exists(DISCUZ_ROOT . './source/plugin/aljzp/template/mobile/index.htm')) {
			return;
		}
		if($_GET['mobile']=='1'){
			$xian='<span class="pipe">|</span>';
		}else{
			$xian='&nbsp;&nbsp;&nbsp;';
		}
		return $xian.'<a href="plugin.php?id=aljzp">'.$config['daohang'].'</a>';
		
	}
}
class mobileplugin_aljzp_forum extends mobileplugin_aljzp {
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>