<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(!file_exists("source/plugin/aljzp/template/com/attestation.php")){
	echo lang('plugin/aljzp','admin_10');
	include_once DISCUZ_ROOT . './source/plugin/aljzp/com_array.inc.php';
	include template('aljzp:com');
	exit;
}
$config = array();
foreach($pluginvars as $key => $val) {
	$config[$key] = $val['value'];	
}
$pluginid='aljzp';
if($_GET['act']=='edit'){
	if(submitcheck('submit')) {
		$insertarray = array(
			'name' => $_GET['name'],
			'id_card' => $_GET['id_card'],
			'qiyename' => $_GET['qiyename'],
			'email' => $_GET['email'],
			'tel' => $_GET['tel'],
			'jieshao' => $_GET['jieshao'],
			'timestamp' => TIMESTAMP,
		);
		if ($_FILES['pic']['tmp_name']) {
			$picname = $_FILES['pic']['name'];
			$picsize = $_FILES['pic']['size'];
			if ($picsize/1024>$config['img_size']) {
				cpmsg(lang('plugin/aljzp','aljzp_11').$config['img_size'].'K');
			}
			if ($picname != "") {
				$type = strstr($picname, '.');
				if ($type != ".gif" && $type != ".jpg" && $type != ".png") {
					showerror(lang('plugin/aljzp','aljzp_3'));
				}
				$rand = rand(100, 999);
				$pics = date("YmdHis") . $rand . $type;
				$img_dir = 'source/plugin/aljzp/images/logo/';
				if (!is_dir($img_dir)) {
					mkdir($img_dir);
				}
				$$pic = $img_dir . $pics;
				if (@copy($_FILES['pic']['tmp_name'], $$pic) || @move_uploaded_file($_FILES['pic']['tmp_name'], $$pic)) {
					@unlink($_FILES['pic']['tmp_name']);
				}
			}
		}
		
		if($$pic){
			$insertarray['pic'] = $$pic;
		}
		unset($$pic);
		if ($_FILES['id_pic']['tmp_name']) {
			$picname = $_FILES['id_pic']['name'];
			$picsize = $_FILES['id_pic']['size'];

			if ($picname != "") {
				$type = strstr($picname, '.');
				if ($type != ".gif" && $type != ".jpg" && $type != ".png") {
					cpmsg(lang('plugin/aljzp','aljzp_3'));
				}
				$rand = rand(100, 999);
				$pics = date("YmdHis") . $rand . $type;
				$img_dir = 'source/plugin/aljzp/images/logo/';
				if (!is_dir($img_dir)) {
					mkdir($img_dir);
				}
				$$pic = $img_dir . $pics;
				if (@copy($_FILES['id_pic']['tmp_name'], $$pic) || @move_uploaded_file($_FILES['id_pic']['tmp_name'], $$pic)) {
					
					@unlink($_FILES['id_pic']['tmp_name']);
				}
			}
		}
		
		if($$pic){
			$insertarray['id_pic'] = $$pic;
		}
		C::t('#aljzp#aljzp_attestation')->update($_GET['uid'], $insertarray);
		cpmsg(lang('plugin/aljzp','admin_1'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=attestation', 'succeed');
	}else{
		$lp	=C::t('#aljzp#aljzp_attestation')->fetch($_GET['uid']);
		include template('aljzp:aedit');
	}
}else if($_GET['act']=='yes'){
	if(!submitcheck('submit')) {
		$currpage=$_GET['page']?$_GET['page']:1;
		$perpage=$config['page'];
		$num=C::t('#aljzp#aljzp_attestation')->count_by_status(1);
		$start=($currpage-1)*$perpage;
		$atlist=C::t('#aljzp#aljzp_attestation')->fetch_all_by_status(1,$start,$perpage);
		$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljzp&pmod=attestation&act=yes', 0, 11, false, false);
		include template('aljzp:admin');
	}else{
		
		if(is_array($_POST['delete'])) {
			foreach($_POST['delete'] as $id) {
				C::t('#aljzp#aljzp_attestation')->delete($id);
			}
		}
		foreach($_POST['myid'] as $id) {
			DB::update('aljzp_attestation',array('tuijian'=>$_POST['tuijian'][$id]),'uid='.$id);
		}
		cpmsg(lang('plugin/aljzp','admin_1'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=attestation&act=yes', 'succeed');
		
	}
}else{
	
	if(!submitcheck('sh_submit')&&!submitcheck('del_submit')) {
		$currpage=$_GET['page']?$_GET['page']:1;
		$perpage=$config['page'];
		
		$num=C::t('#aljzp#aljzp_attestation')->count_by_status(0);
		$start=($currpage-1)*$perpage;
		$atlist=C::t('#aljzp#aljzp_attestation')->fetch_all_by_status(0,$start,$perpage);
		$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljzp&pmod=attestation', 0, 11, false, false);	
		include template('aljzp:admin');
		
	}else{
		
		if(submitcheck('del_submit')){
			
			if(is_array($_POST['delete'])) {
				foreach($_POST['delete'] as $id) {
					C::t('#aljzp#aljzp_attestation')->delete($id);
				}
			}
		}
		if(submitcheck('sh_submit')){
			if(is_array($_POST['delete'])) {
				foreach($_POST['delete'] as $id) {
					DB::update('aljzp_attestation',array('sign'=>1),'uid='.$id);
				}
			}
		}
		
		cpmsg(lang('plugin/aljzp','admin_1'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=attestation', 'succeed');
	}
}
function showmsg($msg,$close){
	if($close){
		$str="parent.hideWindow('$close');";
	}else{
		$str="parent.location=parent.location;";
	}
	include template('aljzp:showmsg');
	exit;
}
function showerror($msg){
	include template('aljzp:showerror');
	exit;
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>