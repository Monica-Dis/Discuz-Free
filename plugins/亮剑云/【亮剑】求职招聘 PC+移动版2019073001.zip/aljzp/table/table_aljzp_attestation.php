<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljzp_attestation extends discuz_table {

    public function __construct() {

        $this->_table = 'aljzp_attestation';
        $this->_pk = 'uid';

        parent::__construct(); /*dism �� taobao �� com*/
    }
	public function count_by_status($status){
		return DB::result_first("select count(*) from %t where sign=%d",array($this->_table,$status));
	}
    public function fetch_all_by_status($status,$start,$perpage){
		return DB::fetch_all("select * from %t where sign=%d limit %d,%d",array($this->_table,$status,$start,$perpage));
	}
	public function count_by_sign($conndtion) {
        $con[] = $this->_table;
        $where = 'where sign=1 ';
        if ($conndtion['search']) {
            $con[] = '%' . addcslashes($conndtion['search'], '%_') . '%';
            $where.=" and qiyename like %s";
        }
        if ($conndtion['rid']) {
            $con[] = $conndtion['rid'];
            $where.=" and region = %d";
        }
        if ($conndtion['subrid']) {
            $con[] = $conndtion['subrid'];
            $where.=" and region1 = %d";
        }
		if ($conndtion['subsubrid']) {
            $con[] = $conndtion['subsubrid'];
            $where.=" and region2 = %d";
        }
        if ($conndtion['btntrade']) {
            $con[] = $conndtion['btntrade'];
            $where.=" and btntrade = %d";
        }
        if ($conndtion['property']) {
			$con[] = $conndtion['property'];
			$where.=" and property = %d";
        }
		if ($conndtion['employee']) {
            $con[] = $conndtion['employee'];
			$where.=" and employee = %d";
        }
		
        return DB::result_first('select count(*) from %t ' . $where, $con);
    }

    public function fetch_all_by_addtime($start, $perpage, $conndtion) {
        $con[] = $this->_table;
        $where = 'where sign=1 ';
        if ($conndtion['search']) {
            $con[] = '%' . addcslashes($conndtion['search'], '%_') . '%';
            $where.=" and qiyename like %s";
        }
        if ($conndtion['rid']) {
            $con[] = $conndtion['rid'];
            $where.=" and region = %d";
        }
        if ($conndtion['subrid']) {
            $con[] = $conndtion['subrid'];
            $where.=" and region1 = %d";
        }
		if ($conndtion['subsubrid']) {
            $con[] = $conndtion['subsubrid'];
            $where.=" and region2 = %d";
        }
        if ($conndtion['btntrade']) {
            $con[] = $conndtion['btntrade'];
            $where.=" and btntrade = %d";
        }
        if ($conndtion['property']) {
			$con[] = $conndtion['property'];
			$where.=" and property = %d";
        }
		if ($conndtion['employee']) {
            $con[] = $conndtion['employee'];
			$where.=" and employee = %d";
        }
        $con[] = $start;
        $con[] = $perpage;
		
        return DB::fetch_all('select * from %t ' . $where . ' order by timestamp desc limit %d,%d', $con);
    }
}
//From: DisM. taobao. Com
?>