<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljzp_resume extends discuz_table {

    public function __construct() {

        $this->_table = 'aljzp_resume';
        $this->_pk = 'uid';

        parent::__construct(); /*dism �� taobao �� com*/
    }
	public function count_by_status($conndtion) {
        $con[] = $this->_table;
        $where = 'where privacy = 0 ';
        if ($conndtion['uid']) {
            $con[] = $conndtion['uid'];
            $where.=" and uid = %d";
        }
        if ($conndtion['search']) {
            $con[] = '%' . addcslashes($conndtion['search'], '%_') . '%';
            $where.=" and title like %s";
        }
        if ($conndtion['rid']) {
            $con[] = $conndtion['rid'];
            $where.=" and region = %d";
        }
        if ($conndtion['subrid']) {
            $con[] = $conndtion['subrid'];
            $where.=" and region1 = %d";
        }
        if ($conndtion['sex']) {
            $con[] = $conndtion['sex'];
            $where.=" and sex = %s";
        }
		if ($conndtion['pos']) {
            $con[] = $conndtion['pos'];
			$where.=" and pos = %d";
        }
		if ($conndtion['pos1']) {
            $con[] = $conndtion['pos1'];
            $where.=" and pos1 = %d ";
        }
		if ($conndtion['xueli']) {
            $con[] = $conndtion['xueli'];
            $where.=" and xueli = %d ";
        }
		if ($conndtion['work']) {
            $con[] = $conndtion['work'];
            $where.=" and work_nx = %d ";
        }
		if ($conndtion['state']) {
            $con[] = $conndtion['state'];
            $where.=" and state = %d ";
        }
        if ($conndtion['pay1']) {
			if(!$conndtion['pay2']){
				$con[] = $conndtion['pay1'];
				$where.=" and salary <= %d";
			}else{
				$con[] = $conndtion['pay1'];
				$where.=" and salary >= %d";
			}
        }
        if ($conndtion['pay2']) {
            if(!$conndtion['pay1']){
				$con[] = $conndtion['pay2'];
				$where.=" and salary >= %d";
			}else{
				$con[] = $conndtion['pay2'];
				$where.=" and salary <= %d";
			}
        }
		
        return DB::result_first('select count(*) from %t ' . $where, $con);
    }

    public function fetch_all_by_addtime($start, $perpage, $conndtion) {
        $con[] = $this->_table;
        $where = 'where privacy = 0 ';
        if ($conndtion['search']) {
            $con[] = '%' . addcslashes($conndtion['search'], '%_') . '%';

            $where.=" and title like %s";
        }
        if ($conndtion['rid']) {
            $con[] = $conndtion['rid'];
            $where.=" and region = %d";
        }
        if ($conndtion['subrid']) {
            $con[] = $conndtion['subrid'];
            $where.=" and region1 = %d";
        }
        if ($conndtion['sex']) {
            $con[] = $conndtion['sex'];
            $where.=" and sex = %s";
        }
		if ($conndtion['uid']) {
            $con[] = $conndtion['uid'];
            $where.=" and uid = %s";
        }
		if ($conndtion['pos']) {
            $con[] = $conndtion['pos'];
			$where.=" and pos = %d";
        }
		if ($conndtion['pos1']) {
            $con[] = $conndtion['pos1'];
            $where.=" and pos1 = %d ";
        }
		if ($conndtion['xueli']) {
            $con[] = $conndtion['xueli'];
            $where.=" and xueli = %d ";
        }
		if ($conndtion['work']) {
            $con[] = $conndtion['work'];
            $where.=" and work_nx = %d ";
        }
		if ($conndtion['state']) {
            $con[] = $conndtion['state'];
            $where.=" and state = %d ";
        }
        if ($conndtion['pay1']) {
			if(!$conndtion['pay2']){
				$con[] = $conndtion['pay1'];
				$where.=" and salary <= %d";
			}else{
				$con[] = $conndtion['pay1'];
				$where.=" and salary >= %d";
			}
        }
        if ($conndtion['pay2']) {
			if(!$conndtion['pay1']){
				$con[] = $conndtion['pay2'];
				$where.=" and salary >= %d";
			}else{
				$con[] = $conndtion['pay2'];
				$where.=" and salary <= %d";
			}
        }
		
        $con[] = $start;
        $con[] = $perpage;
		
        return DB::fetch_all('select * from %t ' . $where . ' order by timestamp desc limit %d,%d', $con);
    }
    public function update_view_by_uid($uid){
        return DB::query('update %t set view=view+1 where uid=%d',array($this->_table,$uid));
    }
	public function update_xiazaicishu_by_uid($uid){
        return DB::query('update %t set xiazaicishu=xiazaicishu+1 where uid=%d',array($this->_table,$uid));
    }
}
//From: DisM. taobao. Com
?>