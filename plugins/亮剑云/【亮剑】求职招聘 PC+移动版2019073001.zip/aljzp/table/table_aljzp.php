<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljzp extends discuz_table {

    public function __construct() {

        $this->_table = 'aljzp';
        $this->_pk = 'id';

        parent::__construct(); /*dism �� taobao �� com*/
    }

    public function update_views_by_id($id) {
        DB::query('update %t set views=views+1 where id=%d', array($this->_table, $id));
    }

    public function count_by_status($conndtion) {
        $con[] = $this->_table;
        $where = 'where state=0 ';
        if ($conndtion['uid']) {
            $con[] = $conndtion['uid'];
            $where.=" and uid = %d";
        }
        if ($conndtion['search']) {
            $con[] = '%' . addcslashes($conndtion['search'], '%_') . '%';
            $con[] = '%' . addcslashes($conndtion['search'], '%_') . '%';
            $con[] = '%' . addcslashes($conndtion['search'], '%_') . '%';
            $where.=" and (title like %s or pos1 like %s or gongsi like %s)";
        }
        if ($conndtion['rid']) {
            $con[] = $conndtion['rid'];
            $where.=" and region = %d";
        }
        if ($conndtion['subrid']) {
            $con[] = $conndtion['subrid'];
            $where.=" and region1 = %d";
        }
		if ($conndtion['subsubrid']) {
            $con[] = $conndtion['subsubrid'];
            $where.=" and region2 = %d";
        }
        if ($conndtion['sex']) {
            $con[] = $conndtion['sex'];
            $where.=" and sex = %s";
        }
        if ($conndtion['pay']) {
			$con[] = $conndtion['pay'];
			$where.=" and pay = %d";
        }
		if ($conndtion['pos']) {
            $con[] = $conndtion['pos'];
			$where.=" and pos = %d";
        }
		if ($conndtion['pos1']) {
            $con[] = $conndtion['pos1'];
            $where.=" and pos1 = %d ";
        }
		if ($conndtion['wanted']) {
            $con[] = $conndtion['wanted'];
            $where.=" and wanted = %d ";
        }
		if ($conndtion['solve'] || $conndtion['is_solve']) {
            
			if($conndtion['is_solve'] && !$conndtion['solve']){
				$con[] = 1;
				$where.=" and solve != %d ";
			}else{
				$con[] = $conndtion['solve'];
				$where.=" and solve = %d ";
			}
        }
        return DB::result_first('select count(*) from %t ' . $where, $con);
    }

    public function fetch_all_by_addtime($start, $perpage, $conndtion) {
        $con[] = $this->_table;
        $where = 'where state=0 ';
        if ($conndtion['search']) {
            $con[] = '%' . addcslashes($conndtion['search'], '%_') . '%';
            $con[] = '%' . addcslashes($conndtion['search'], '%_') . '%';
            $con[] = '%' . addcslashes($conndtion['search'], '%_') . '%';
            $where.=" and (title like %s or pos1 like %s or gongsi like %s)";
        }
        if ($conndtion['rid']) {
            $con[] = $conndtion['rid'];
            $where.=" and region = %d";
        }
        if ($conndtion['subrid']) {
            $con[] = $conndtion['subrid'];
            $where.=" and region1 = %d";
        }
		if ($conndtion['subsubrid']) {
            $con[] = $conndtion['subsubrid'];
            $where.=" and region2 = %d";
        }
        if ($conndtion['sex']) {
            $con[] = $conndtion['sex'];
            $where.=" and sex = %s";
        }
        if ($conndtion['pay']) {
			$con[] = $conndtion['pay'];
			$where.=" and pay = %d";
        }
		if ($conndtion['uid']) {
            $con[] = $conndtion['uid'];
            $where.=" and uid = %s";
        }
		if ($conndtion['pos']) {
            $con[] = $conndtion['pos'];
			$where.=" and pos = %d";
        }
		if ($conndtion['pos1']) {
            $con[] = $conndtion['pos1'];
            $where.=" and pos1 = %d ";
        }
		if ($conndtion['wanted']) {
            $con[] = $conndtion['wanted'];
            $where.=" and wanted = %d ";
        }
		if ($conndtion['solve'] || $conndtion['is_solve']) {
            
			if($conndtion['is_solve'] && !$conndtion['solve']){
				$con[] = 1;
				$where.=" and solve != %d ";
			}else{
				$con[] = $conndtion['solve'];
				$where.=" and solve = %d ";
			}
        }
        $con[] = $start;
        $con[] = $perpage;
		
        return DB::fetch_all('select * from %t ' . $where . ' order by topetime desc, updatetime desc,addtime desc limit %d,%d', $con);
    }
    public function update_updatetime_by_id($id){
        return DB::query('update %t set updatetime=%d where id=%d',array($this->_table,TIMESTAMP,$id));
    }

}
//From: DisM. taobao. Com
?>