<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$comarray=array(
	1=>array('id'=>1,'file'=>'source/plugin/aljzp/template/com/moneyso.htm','name'=>lang('plugin/aljzp','com_array_1'),'desc'=>lang('plugin/aljzp','com_array_2'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37855'),
	2=>array('id'=>2,'file'=>'source/plugin/aljzp/template/com/so.htm','name'=>lang('plugin/aljzp','com_array_3'),'desc'=>lang('plugin/aljzp','com_array_4'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37856'),
	3=>array('id'=>3,'file'=>'source/plugin/aljzp/template/com/viewadv.htm','name'=>lang('plugin/aljzp','com_array_5'),'desc'=>lang('plugin/aljzp','com_array_6'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37857'),
	4=>array('id'=>4,'file'=>'source/plugin/aljzp/template/com/viewadv1.htm','name'=>lang('plugin/aljzp','com_array_7'),'desc'=>lang('plugin/aljzp','com_array_8'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37858'),
	5=>array('id'=>5,'file'=>'source/plugin/aljzp/template/com/renqi.htm','name'=>lang('plugin/aljzp','com_array_9'),'desc'=>lang('plugin/aljzp','com_array_10'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37859'),
	6=>array('id'=>6,'file'=>'source/plugin/aljzp/template/com/gg.htm','name'=>lang('plugin/aljzp','com_array_11'),'desc'=>lang('plugin/aljzp','com_array_12'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37860'),
	7=>array('id'=>7,'file'=>'source/plugin/aljzp/template/com/fenxiang.htm','name'=>lang('plugin/aljzp','com_array_13'),'desc'=>lang('plugin/aljzp','com_array_14'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37861'),
	8=>array('id'=>8,'file'=>'source/plugin/aljzp/template/com/sixin.htm','name'=>lang('plugin/aljzp','com_array_15'),'desc'=>lang('plugin/aljzp','com_array_16'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37862'),
	9=>array('id'=>9,'file'=>'source/plugin/aljzp/template/com/guanzhu.htm','name'=>lang('plugin/aljzp','com_array_17'),'desc'=>lang('plugin/aljzp','com_array_18'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37863'),
	10=>array('id'=>10,'file'=>'source/plugin/aljzp/template/com/qita.htm','name'=>lang('plugin/aljzp','com_array_19'),'desc'=>lang('plugin/aljzp','com_array_20'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37854'),
	11=>array('id'=>11,'file'=>'source/plugin/aljzp/template/com/commen.htm','name'=>lang('plugin/aljzp','com_array_21'),'desc'=>lang('plugin/aljzp','com_array_22'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37864'),
	12=>array('id'=>12,'file'=>'source/plugin/aljzp/template/com/reflash.php','name'=>lang('plugin/aljzp','com_array_23'),'desc'=>lang('plugin/aljzp','com_array_24'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37865'),
	13=>array('id'=>13,'file'=>'source/plugin/aljzp/template/com/top.php','name'=>lang('plugin/aljzp','com_array_25'),'desc'=>lang('plugin/aljzp','com_array_26'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37866'),
	14=>array('id'=>14,'file'=>'source/plugin/aljzp/template/com/resume.php','name'=>lang('plugin/aljzp','com_array_27'),'desc'=>lang('plugin/aljzp','com_array_28'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37867'),
	15=>array('id'=>15,'file'=>'source/plugin/aljzp/template/com/attestation.php','name'=>lang('plugin/aljzp','com_array_29'),'desc'=>lang('plugin/aljzp','com_array_30'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37868'),
	16=>array('id'=>16,'file'=>'source/plugin/aljzp/template/com/user.php','name'=>lang('plugin/aljzp','com_array_31'),'desc'=>lang('plugin/aljzp','com_array_32'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37869'),
	17=>array('id'=>17,'file'=>'source/plugin/aljzp/template/com/admin.php','name'=>lang('plugin/aljzp','com_array_33'),'desc'=>lang('plugin/aljzp','com_array_34'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37870'),
	18=>array('id'=>18,'file'=>'source/plugin/aljzp/template/com/tongbu.php','name'=>lang('plugin/aljzp','com_array_35'),'desc'=>lang('plugin/aljzp','com_array_36'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.38094'),
	19=>array('id'=>19,'file'=>'source/plugin/aljzp/template/com/resumes.php','name'=>lang('plugin/aljzp','com_array_37'),'desc'=>lang('plugin/aljzp','com_array_38'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.39209'),
	20=>array('id'=>20,'file'=>'source/plugin/aljzp/template/com/qita.php','name'=>lang('plugin/aljzp','com_array_39'),'desc'=>lang('plugin/aljzp','com_array_40'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.39432'),
	21=>array('id'=>21,'file'=>'source/plugin/aljzp/template/touch','name'=>lang('plugin/aljzp','com_array_43'),'desc'=>lang('plugin/aljzp','com_array_44'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.37871'),
	22=>array('id'=>22,'file'=>'source/plugin/aljzp/template/com/qrcode.php','name'=>lang('plugin/aljzp','com_array_41'),'desc'=>lang('plugin/aljzp','com_array_42'),'url'=>'http://addon.discuz.com/?@aljzp.plugin.39433'),
);
?>