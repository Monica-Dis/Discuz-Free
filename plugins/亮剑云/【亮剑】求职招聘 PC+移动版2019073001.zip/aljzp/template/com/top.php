<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (submitcheck('formhash')) {
	if(empty($_GET['lid'])){
		showmessage(lang('plugin/aljzp','aljzp_8'));
	}
	if(intval($_GET['days']) < 0){
		if($_G['mobile']){
			echo "<script>parent.tips('".lang('plugin/aljzp','top_3')."','');</script>";
			exit;
		}else{
			showerror(lang('plugin/aljzp','top_3'));
		}
	}
	$lp=C::t('#aljzp#aljzp')->fetch($_GET['lid']);
	$insertid=C::t('#aljzp#aljzp_toplog')->insert(array(
		'lid' => $_GET['lid'],
		'uid' => $_G['uid'],
		'username' => $_G['username'],
		'dateline' => TIMESTAMP,
		'endtime' => TIMESTAMP + intval($_GET['days']) * 86400,
		'pay' => intval($_GET['days']) * $config['toppay'],
		'extcredit' => $config['topextcredit'],
		'title' => $lp['title'],
		'name' => $lp['username'],
	),true);
	if (getuserprofile('extcredits' . $config['topextcredit']) < (intval($_GET['days']) * $config['toppay'])) {
		if($_G['mobile']){
			if($mobile_integral_recharge){
				echo "<script>parent.tips('".$_G['setting']['extcredits'][$config['topextcredit']]['title'] . lang('plugin/aljzp','top_1').$aljzplang['php']['Jumping_up_page']."',function(){parent.location.href='".$mobile_integral_recharge."';});</script>";
			}else{
				echo "<script>parent.tips('".$_G['setting']['extcredits'][$config['topextcredit']]['title'] . lang('plugin/aljzp','top_1')."','');</script>";
			}
			
			exit;
		}else{
			showerror($_G['setting']['extcredits'][$config['topextcredit']]['title'] . lang('plugin/aljzp','top_1').$pc_integral_recharge);
		}
	}
	updatemembercount($_G['uid'], array($config['topextcredit'] => '-' .intval($_GET['days']) * $config['toppay']));
	if($lp['topetime']&&TIMESTAMP<$lp['topetime']){
		DB::update('aljzp_toplog',array('endtime'=>$lp['topetime']+ intval($_GET['days']) * 86400),'id='.$insertid);
		DB::update('aljzp',array('topetime'=>$lp['topetime'] + intval($_GET['days']) * 86400),'id='.intval($_GET[lid]));
	}else{
		DB::update('aljzp',array('topstime'=>TIMESTAMP,'topetime'=>TIMESTAMP + intval($_GET['days']) * 86400),'id='.intval($_GET[lid]));
	}
	C::t('#aljzp#aljzp')->update_updatetime_by_id($_GET['lid']);
	C::t('#aljzp#aljzp_user')->update_top_by_uid($_G['uid']);
	if($_G['mobile']){
		echo "<script>parent.tips('".lang('plugin/aljzp','top_2')."',function(){parent.location.href='plugin.php?id=aljzp&act=member"."';});</script>";
		exit;
	}else{
		showmsg(lang('plugin/aljzp','top_2'), 'plugin.php?id=aljzp&act=member');
	}
}else{
	if (getuserprofile('extcredits' . $config['topextcredit']) < $config['toppay']) {
		showmessage($_G['setting']['extcredits'][$config['topextcredit']]['title'] . lang('plugin/aljzp','top_1').$pc_integral_recharge);
	}
	if(empty($_GET['lid'])){
		showmessage(lang('plugin/aljzp','aljzp_8'));
	}
	$lp=C::t('#aljzp#aljzp')->fetch($_GET['lid']);
	
	if($_G['mobile']){
		$url='plugin.php?id=aljzp&act=top&lid='.$_GET['lid'];
		include template('aljzp:state');
	}else{
		include template('aljzp:addtop');
	}
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>