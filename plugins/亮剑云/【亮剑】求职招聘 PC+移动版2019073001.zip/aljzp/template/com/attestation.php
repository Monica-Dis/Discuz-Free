<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_GET['table'] == 'details'){
	$sign=DB::result_first("select sign from ".DB::table('aljzp_attestation')." where sign=1 and uid=".$_G['uid']);
	if(!$sign){
		//showmessage(lang('plugin/aljzp','attestation_8'));
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".lang('plugin/aljzp','attestation_8')."','');</script>";
			exit;
		}else{
			showerror(lang('plugin/aljzp','attestation_8'));
		}
	}
}
if (submitcheck('formhash')) {
	
	if($_GET['img']=='1'){
		for ($i = 1; $i <= 10; $i++) {
			$pic = 'pic' . $i;
			if($_G['mobile']){
				if($_GET[$pic]){
					$rand = rand(100, 999);
					$pics = date("YmdHis") . $rand . '.jpg';
					$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
					if (!is_dir($img_dir)) {
						if(!mkdir($img_dir)){
							if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
								echo "<script>parent.tips('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;','');</script>";
								exit;
							}else{
								showerror('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;');
							}
						}
					}
					$$pic = $img_dir . $pics;
					
					$logo = file_put_contents($$pic,file_get_contents($_GET[$pic]));
					
					if ($logo) {
						$imageinfo = getimagesize($$pic);
						if($settings['iswatermark']['value']){
							$image->Watermark(DISCUZ_ROOT.'./'.$$pic,'', 'forum');
						}
						if($i!=10){
							$w64 = $imageinfo[0] < 64 ? $imageinfo[0] : 64;
							$h64 = $imageinfo[1] < 64 ? $imageinfo[1] : 64;
							$w100 = $imageinfo[0] < 100 ? $imageinfo[0] : 100;
							$h100 = $imageinfo[1] < 100 ? $imageinfo[1] : 100;
							$w640 = $imageinfo[0] < 640 ? $imageinfo[0] : 640;
							$h480 = $imageinfo[1] < 480 ? $imageinfo[1] : 480;
							img2thumb($$pic, $$pic . '.100x100.jpg', $w100, $h100);
							img2thumb($$pic, $$pic . '.64x64.jpg', $w64, $h64);
							img2thumb($$pic, $$pic . '.640x480.jpg', $w640, $h480);
						}
					}
				}
			}else{
				if ($_FILES[$pic]['tmp_name']) {
					$picname = $_FILES[$pic]['name'];
					$picsize = $_FILES[$pic]['size'];
					if ($picsize/1024>$config['img_size']) {
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('&#19978;&#20256;&#22270;&#29255;&#19981;&#33021;&#36229;&#36807;".$config['img_size']."K','');</script>";
							exit;
						}else{
							showerror('&#19978;&#20256;&#22270;&#29255;&#19981;&#33021;&#36229;&#36807;'.$config['img_size'].'K');
						}
					}
					if ($picname != "") {
						$type = strtolower(strrchr($picname, '.'));
						if ($type != ".gif" && $type != ".jpg" && $type != ".png" && $type != ".jpeg") {
							if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
								echo "<script>parent.tips('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#103;&#105;&#102;&#32;&#46;&#112;&#110;&#103;&#26684;&#24335;&#30340;&#22270;&#29255;','');</script>";
								exit;
							}else{
								showerror('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#103;&#105;&#102;&#32;&#46;&#112;&#110;&#103;&#26684;&#24335;&#30340;&#22270;&#29255;');
							}
						}
						$rand = rand(100, 999);
						$pics = date("YmdHis") . $rand . $type;
						$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
						if (!is_dir($img_dir)) {
							if(!mkdir($img_dir)){
								if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
									echo "<script>parent.tips('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;','');</script>";
									exit;
								}else{
									showerror('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;');
								}
							}
						}
						$$pic = $img_dir . $pics;
						if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
							$imageinfo = getimagesize($$pic);
							if($settings['iswatermark']['value']){
								$image->Watermark(DISCUZ_ROOT.'./'.$$pic,'', 'forum');
							}
							if($i!=10){
								$w64 = $imageinfo[0] < 64 ? $imageinfo[0] : 64;
								$h64 = $imageinfo[1] < 64 ? $imageinfo[1] : 64;
								$w100 = $imageinfo[0] < 100 ? $imageinfo[0] : 100;
								$h100 = $imageinfo[1] < 100 ? $imageinfo[1] : 100;
								$w640 = $imageinfo[0] < 640 ? $imageinfo[0] : 640;
								$h480 = $imageinfo[1] < 480 ? $imageinfo[1] : 480;
								img2thumb($$pic, $$pic . '.100x100.jpg', $w100, $h100);
								img2thumb($$pic, $$pic . '.64x64.jpg', $w64, $h64);
								img2thumb($$pic, $$pic . '.640x480.jpg', $w640, $h480);
								@unlink($_FILES[$pic]['tmp_name']);
							}
						}
					}
				}
			}
		}
		$insertarray=array(
			'uid' => $_G['uid'],
			'username' => $_G['username'],
			'jieshao' => $_GET['jieshao'],
			'email' => $_GET['email'],
			'btntrade' => $_GET['btntrade'],
			'property' => $_GET['property'],
			'employee' => $_GET['employee'],
			'region' => $_GET['region'],
			'region1' => $_GET['region1'],
			'region2' => $_GET['region2'],
			'weal' => implode(',', $_GET['weal']),
			'linkman' => $_GET['linkman'],
			'linkmanjob' => $_GET['linkmanjob'],
			'fax' => $_GET['fax'],
			'website' => $_GET['website'],
			'address' => $_GET['address'],
			'timestamp' => TIMESTAMP,
			'qiyename' => $_GET['qiyename'],
			'tel' => $_GET['tel'],
		);
		for ($i = 1; $i <= 10; $i++) {
			$pic = 'pic' . $i;
			if ($$pic) {
				$insertarray[$pic] = $$pic;
			}
		}
		if(!C::t('#aljzp#aljzp_attestation')->fetch($_G['uid'])){
			C::t('#aljzp#aljzp_attestation')->insert($insertarray);
		}else{
			C::t('#aljzp#aljzp_attestation')->update($_G['uid'], $insertarray);
		}
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('&#20445;&#23384;&#25104;&#21151;',function(){parent.location=parent.location;});</script>";
		}else{
			showmsg('&#20445;&#23384;&#25104;&#21151;');
		}
	}else{
		//if($config['is_attes_name']){
			if (empty($_GET['name'])) {
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('".lang('plugin/aljzp','aljzp_2')."','');</script>";
					exit;
				}else{
					showerror(lang('plugin/aljzp','aljzp_2'));
				}
			}
			if (empty($_GET['id_card'])) {
				//showerror(lang('plugin/aljzp','attestation_2'));
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('".lang('plugin/aljzp','attestation_2')."','');</script>";
					exit;
				}else{
					showerror(lang('plugin/aljzp','attestation_2'));
				}
			}
		//}
		if (empty($_GET['qiyename'])) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljzp','attestation_3')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzp','attestation_3'));
			}
		}
		if (empty($_GET['tel'])) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('&#30005;&#35805;&#24517;&#39035;&#22635;&#20889;','');</script>";
				exit;
			}else{
				showerror('&#30005;&#35805;&#24517;&#39035;&#22635;&#20889;');
			}
		}
		$insertarray = array(
			'uid' => $_G['uid'],
			'username' => $_G['username'],
			'name' => $_GET['name'],
			'id_card' => $_GET['id_card'],
			'qiyename' => $_GET['qiyename'],
			'jieshao' => $_GET['jieshao'],
			'tel' => $_GET['tel'],
			'timestamp' => TIMESTAMP,
			'linkman' => $_GET['linkman'],
		);
		if($_G['mobile']){
			if($_GET['pic'] && $_G['mobile']){
				$rand = rand(100, 999);
				$pics = date("YmdHis") . $rand . '.jpg';
				$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
				if (!is_dir($img_dir)) {
					if(!mkdir($img_dir)){
							if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
								echo "<script>parent.tips('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;','');</script>";
								exit;
							}else{
								showerror('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;');
							}
						}
				}
				$pic = $img_dir . $pics;
				
				$logo = file_put_contents($pic,file_get_contents($_GET['pic']));
				
				if ($logo) {
					$imageinfo = getimagesize($pic);
					if($settings['iswatermark']['value']){
						$image->Watermark(DISCUZ_ROOT.'./'.$pic,'', 'forum');
					}
				}
				if($pic){
					$insertarray['pic'] = $pic;
				}
			}
			if($_GET['id_pic'] && $_G['mobile']){
				$rand = rand(100, 999);
				$pics = date("YmdHis") . $rand . '.jpg';
				$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
				if (!is_dir($img_dir)) {
					if(!mkdir($img_dir)){
							if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
								echo "<script>parent.tips('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;','');</script>";
								exit;
							}else{
								showerror('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;');
							}
						}
				}
				$$pic = $img_dir . $pics;
				
				$logo = file_put_contents($$pic,file_get_contents($_GET['id_pic']));
				
				if ($logo) {
					$imageinfo = getimagesize($$pic);
					if($settings['iswatermark']['value']){
						$image->Watermark(DISCUZ_ROOT.'./'.$$pic,'', 'forum');
					}
				}
				if($$pic){
					$insertarray['id_pic'] = $$pic;
				}
			}
		}else{
			if ($_FILES['pic']['tmp_name']) {
				$picname = $_FILES['pic']['name'];
				$picsize = $_FILES['pic']['size'];
				if ($picsize/1024>$config['img_size']) {
					if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
						echo "<script>parent.tips('&#19978;&#20256;&#22270;&#29255;&#19981;&#33021;&#36229;&#36807;".$config['img_size']."K','');</script>";
						exit;
					}else{
						showerror('&#19978;&#20256;&#22270;&#29255;&#19981;&#33021;&#36229;&#36807;'.$config['img_size'].'K');
					}
				}
				if ($picname != "") {
					$type = strtolower(strrchr($picname, '.'));
					if ($type != ".gif" && $type != ".jpg" && $type != ".png" && $type != ".jpeg") {
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#103;&#105;&#102;&#32;&#46;&#112;&#110;&#103;&#26684;&#24335;&#30340;&#22270;&#29255;','');</script>";
							exit;
						}else{
							showerror('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#103;&#105;&#102;&#32;&#46;&#112;&#110;&#103;&#26684;&#24335;&#30340;&#22270;&#29255;');
						}
					}
					$rand = rand(100, 999);
					$pics = date("YmdHis") . $rand . $type;
					$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
					if (!is_dir($img_dir)) {
						if(!mkdir($img_dir)){
							if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
								echo "<script>parent.tips('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;','');</script>";
								exit;
							}else{
								showerror('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;');
							}
						}
					}
					$$pic = $img_dir . $pics;
					if (@copy($_FILES['pic']['tmp_name'], $$pic) || @move_uploaded_file($_FILES['pic']['tmp_name'], $$pic)) {
						@unlink($_FILES['pic']['tmp_name']);
					}
				}
			}
			
			if($$pic){
				$insertarray['pic'] = $$pic;
			}
			unset($$pic);
			unset($picsize);
			unset($type);
			if ($_FILES['id_pic']['tmp_name']) {
				$picname = $_FILES['id_pic']['name'];
				$picsize = $_FILES['id_pic']['size'];
				if ($picsize/1024>$config['img_size']) {
					if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
						echo "<script>parent.tips('&#19978;&#20256;&#22270;&#29255;&#19981;&#33021;&#36229;&#36807;".$config['img_size']."K','');</script>";
						exit;
					}else{
						showerror('&#19978;&#20256;&#22270;&#29255;&#19981;&#33021;&#36229;&#36807;'.$config['img_size'].'K');
					}
				}
				if ($picname != "") {
					$type = strtolower(strrchr($picname, '.'));
					if ($type != ".gif" && $type != ".jpg" && $type != ".png" && $type != ".jpeg") {
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#103;&#105;&#102;&#32;&#46;&#112;&#110;&#103;&#26684;&#24335;&#30340;&#22270;&#29255;','');</script>";
							exit;
						}else{
							showerror('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#103;&#105;&#102;&#32;&#46;&#112;&#110;&#103;&#26684;&#24335;&#30340;&#22270;&#29255;');
						}
					}
					$rand = rand(100, 999);
					$pics = date("YmdHis") . $rand . $type;
					$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
					if (!is_dir($img_dir)) {
						if(!mkdir($img_dir)){
							if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
								echo "<script>parent.tips('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;','');</script>";
								exit;
							}else{
								showerror('&#30446;&#24405;&#21019;&#24314;&#22833;&#36133;');
							}
						}
					}
					$$pic = $img_dir . $pics;
					if (@copy($_FILES['id_pic']['tmp_name'], $$pic) || @move_uploaded_file($_FILES['id_pic']['tmp_name'], $$pic)) {
						
						@unlink($_FILES['id_pic']['tmp_name']);
					}
				}
			}
			
			if($$pic){
				$insertarray['id_pic'] = $$pic;
			}
		}
		
		if(!C::t('#aljzp#aljzp_attestation')->fetch($_G['uid'])){
			C::t('#aljzp#aljzp_attestation')->insert($insertarray);
		}else{
			C::t('#aljzp#aljzp_attestation')->update($_G['uid'], $insertarray);
		}
		foreach(DB::fetch_all('select uid from '.DB::table('common_member').' where groupid =1') as $u){
			notification_add($u['uid'], 'system',lang('plugin/aljzp','attestation_6'));
		}
		
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('&#25552;&#20132;&#25104;&#21151;&#65292;&#35831;&#31561;&#24453;&#23457;&#26680;&#65281;',function(){parent.location=parent.location;});</script>";
		}else{
			showmsg('&#25552;&#20132;&#25104;&#21151;&#65292;&#35831;&#31561;&#24453;&#23457;&#26680;&#65281;');
		}
	}
} else {
	if(!$_G['uid']){
		showmessage(lang('plugin/aljzp','aljzp_1'), '', array(), array('login' => true));
	}
	if($_GET['uid']){
		$_G['uid']=$_GET['uid'];
	}
	$lp	=C::t('#aljzp#aljzp_attestation')->fetch($_G['uid']);
	$rs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid(0);
	if ($lp['region']) {
		$rrs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid($lp['region']);
	}
	$pos = C::t('#aljzp#aljzp_position')->fetch_all_by_upid(0);
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljzp_seo['attes']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzp_seo['attes']);
	}
	include template('aljzp:attestation');
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>