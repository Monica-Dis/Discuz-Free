<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_GET['uid']){
	$day = date('d');
	$mon = date('m');
	$year = date('Y');
	$today = date('N');
	$start = date('Y-m-d', mktime(0, 0, 0, $mon, $day - $today + 1, $year));
	$end = date('Y-m-d H:i:s', mktime(23, 59, 59, $mon, $day - $today + 14, $year));
	$toudi=DB::result_first("select count(*) from ".DB::table('aljzp_sentresume')." where uid=".intval($_GET['uid'])." and timestamp>='" . strtotime($start) . "' and timestamp<='" . strtotime($end) . "'");
	//DB::update('aljzp_resume',array('view'=>1),'uid='.$_GET['uid']);
	C::t('#aljzp#aljzp_resume')->update_view_by_uid($_GET['uid']);
	$lp	=C::t('#aljzp#aljzp_resume')->fetch($_GET['uid']);
	$nianlin=date('Y',TIMESTAMP)-cutstr($lp['ymd'],4,'');
	$navtitle = $lp['name'].'-'.$config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	include template('aljzp:toresumes');
}else{
	$todayviews = C::t('#aljzp#aljzp_log')->fetch_all_by_day();
	$regions = C::t('#aljzp#aljzp_region')->range();
	$rs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid(0);
	$rrs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid($_GET['rid']);
	$pos = C::t('#aljzp#aljzp_position')->fetch_all_by_upid(0);
	$prs = C::t('#aljzp#aljzp_position')->fetch_all_by_upid($_GET['pid']);
	$currpage = intval($_GET['page']) ? intval($_GET['page']) : 1;
	$perpage = 18;
	if($_GET['mobile']=='1'||$_GET['mobile']=='2'){
		if($_G['charset']=='gbk'){ $_GET['sex']=diconv($_GET['sex'],'utf-8','gbk');}
	}
	if($_G['charset']=='gbk'&&!defined('IN_MOBILE')&&$config['is_header']||defined('IN_MOBILE')&&!$_GET['sj']){
		$_GET['search']=diconv($_GET['search'],'utf-8','gbk');
	}
	$start = ($currpage - 1) * $perpage;
	$conndtion = array(
		'search' => $_GET['search'],
		'rid' => $_GET['rid'],
		'subrid' => $_GET['subrid'],
		'sex' => $_GET['sex'],
		'pay1' => $_GET['pay1'],
		'pay2' => $_GET['pay2'],
		'pos' => $_GET['pid'],
		'pos1' => $_GET['subpid'],
		'xueli' => $_GET['xueli'],
		'work' => $_GET['work'],
		'state' => $_GET['state'],
	);
	
	$num = C::t('#aljzp#aljzp_resume')->count_by_status($conndtion);
	
	$lplist = C::t('#aljzp#aljzp_resume')->fetch_all_by_addtime($start, $perpage, $conndtion);
	foreach($lplist as $k=>$v){
		
		$lplist[$k]['rewrite']=str_replace ("{uid}", $v['uid'], $config ['res_view']);
	}
	$lplist = dhtmlspecialchars($lplist);
	$geturl = array(
		'id' => $pluginid,
		'act' => 'resumes',
		'search' => $_GET['search'],
		'rid' => $_GET['region']?$_GET['region']:$_GET['rid'],
        'subrid' => $_GET['region1']?$_GET['region1']:$_GET['subrid'],
        'subsubrid' => $_GET['region2']?$_GET['region2']:$_GET['subsubrid'],
		'pay1' => $_GET['pay1'],
		'pay2' => $_GET['pay2'],
		'pid' => $_GET['pid'],
		'subpid' => $_GET['subpid'],
		'view' => $_GET['view'],
		'sex' => $_GET['sex'],
		'pic' => $_GET['pic'],
		'work' => $_GET['work'],
		'state' => $_GET['state'],
	);
	$pagingurl = getaljurl($geturl,'');
	$paging = helper_page :: multi($num, $perpage, $currpage, $pagingurl, 0, 11, false, false);
	//$tuijian = DB::fetch_all("SELECT * FROM ".DB::table('aljzp_resume')." where privacy =0 tuijian=1 ORDER BY id desc limit 0,9");
	//foreach($tuijian as $k=>$v){
		//$tuijian[$k]['rewrite']=str_replace ("{uid}", $v['uid'], $config ['res_view']);;
	//}
	//$toplist = C::t('#aljzp#aljzp_toplog')->fetch_all_by_dateline();
	//foreach($toplist as $k=>$v){
		//$toplist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
	//}
	
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	include template('aljzp:resumes');
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>