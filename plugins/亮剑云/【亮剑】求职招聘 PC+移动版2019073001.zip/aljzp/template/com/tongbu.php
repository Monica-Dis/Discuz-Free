<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($config['zp_fid']){
	if($config['isrewrite']){
		$re_url=str_replace ("{id}",$insertid, $config ['re_view']);
	}else{
		$re_url='plugin.php?id=aljzp&act=view&lid='.$insertid;
	}
	if(file_exists("source/plugin/nydz/nydz.inc.php")){
		include 'source/plugin/nydz/include/tongbu.php';
	}else{
		$str.='[size=4][url='.$re_url.']'.$_GET['title'].'[/url] [url='.$re_url.'][color=red]'.lang('plugin/aljzp','thread_15').'[/color][/url]<br/>';
		$str.=str_replace('{daohang}',$config['daohang'],str_replace('{tel}',$_GET['contact'],str_replace('{pos1}',$_GET['pos1']?$pos_zw[$_GET['pos1']]['subject']:($_GET['pos']?$pos_zw[$_GET['pos']]['subject']:'-'),str_replace('{zujin}',$_GET['zujin']>0?$pay_types[$_GET['zujin']]:'-',lang('plugin/aljzp','thread_2')))));
	}
	if($_GET['qq']){
		$str.=str_replace('{qq}',$_GET['qq'],lang('plugin/aljzp','thread_3'));
	}
	if($_GET['lxr']){
		$str.=str_replace('{lxr}',$_GET['lxr'],lang('plugin/aljzp','thread_4'));
	}
	if($_GET['renshu']){
		$str.=str_replace('{renshu}',$_GET['renshu'],lang('plugin/aljzp','thread_5'));
	}
	if($_GET['work_time']){
		$str.=str_replace('{work_time}',$wtime_types[$_GET['work_time']],lang('plugin/aljzp','thread_6'));
	}
	if($_GET['sex']){
		$str.=str_replace('{sex}',$_GET['sex'],lang('plugin/aljzp','thread_7'));
	}
	if($_GET['xueli']){
		$str.=str_replace('{xueli}',$xl_types[$_GET['xueli']],lang('plugin/aljzp','thread_8'));
	}
	if($_GET['gongsi']){
		$str.=str_replace('{gongsi}',$_GET['gongsi'],lang('plugin/aljzp','thread_9'));
	}
	$attes=DB::fetch_first("select * from ".DB::table('aljzp_attestation')." where sign=1 and uid=".$_G['uid']);
	if($attes){
		$str.=str_replace('{jieshao}',discuzcode($attes['jieshao']),lang('plugin/aljzp','thread_10'));
	}
	if($_GET['region1']||$_GET['region']||$_GET['region2']){
		if($_GET['region2']&&$_GET['region1']&&$_GET['region']){
			$str.=str_replace('{region2}',$regions[$_GET['region2']]['subject'],str_replace('{region1}',$regions[$_GET['region1']]['subject'],str_replace('{region}',$regions[$_GET['region']]['subject'],lang('plugin/aljzp','thread_11'))));
		}else if($_GET['region1']&&$_GET['region']&&!$_GET['region2']){
			$str.=str_replace('{region1}',$regions[$_GET['region1']]['subject'],str_replace('{region}',$regions[$_GET['region']]['subject'],lang('plugin/aljzp','thread_12')));
		}else if($_GET['region']&&!$_GET['region2']&&!$_GET['region1']){
			$str.=str_replace('{region}',$regions[$_GET['region']]['subject'],lang('plugin/aljzp','thread_13'));
		}
		
	}
	$str.=str_replace('{shengming}',$shengming,lang('plugin/aljzp','thread_14'));
	if($_GET['content']){
		$str.=str_replace('{content}',discuzcode($_GET['content']),'{content}');	
	}
	if($settings['is_tongbu_img']['value']==1){
		if($insertarray){
			for ($i = 1; $i <= 8; $i++) {
				$pic = 'pic' . $i;
				if ($$pic) {
					$imgs[] = '<br/><img src="'.$$pic.'">';
				}
			}
		}else{
			for ($i = 1; $i <= 8; $i++) {
				$pic = 'pic' . $i;
				if ($user[$pic]) {
					$imgs[] = '<br/><img src="'.$user[$pic].'">';
				}
			}
		}
		
		$str.=implode('',$imgs);
	}
	$str.='[/size]';
	
	$cont=str_replace('&amp;','&',html2bbcode($str));
	if($config['is_tongbu_daohang']){
		$title_daohang='['.$config['daohang'].']';
	}
	$tid = generatethread($title_daohang.$_GET['title'], $cont, $_G['clientip'], $_G['uid'], '', $config['zp_fid'],$config['threadtypes']);
	C::t('#aljzp#aljzp')->update($insertid,array('tid'=>$tid));
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>