<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(!file_exists("source/plugin/aljzp/template/com/resume.php")){
	echo lang('plugin/aljzp','admin_9');
	include_once DISCUZ_ROOT . './source/plugin/aljzp/com_array.inc.php';
	include template('aljzp:com');
	exit;
}
$config = array();
foreach($pluginvars as $key => $val) {
	$config[$key] = $val['value'];	
}
$pluginid='aljzp';
$typelist = explode ("\n", str_replace ("\r", "", $config ['pinpai']));
foreach($typelist as $key=>$value){
	$arr=explode('=',$value);
	$types[$arr[0]]=$arr[1];
}
$zufangtype = $types;
$new_list = explode ("\n", str_replace ("\r", "", $config ['new']));
foreach($new_list as $key=>$value){
	$new_arr=explode('=',$value);
	$new_types[$new_arr[0]]=$new_arr[1];
}
$xuelilist = explode ("\n", str_replace ("\r", "", $config ['xueli']));
foreach($xuelilist as $key=>$value){
	$arr=explode('=',$value);
	$xl_types[$arr[0]]=$arr[1];
}
$work_nxlist = explode ("\n", str_replace ("\r", "", $config ['work_nx']));
foreach($work_nxlist as $key=>$value){
	$arr=explode('=',$value);
	$nx_types[$arr[0]]=$arr[1];
}
$work_timelist = explode ("\n", str_replace ("\r", "", $config ['work_time']));
foreach($work_timelist as $key=>$value){
	$arr=explode('=',$value);
	$wtime_types[$arr[0]]=$arr[1];
}
$regions = C::t('#aljzp#aljzp_region')->range();
$pos = C::t('#aljzp#aljzp_position')->range();
if($_GET['act']=='edit'){
	if(submitcheck('formhash')){
		if ($_FILES['pic']['tmp_name']) {
			$picname = $_FILES['pic']['name'];
			$picsize = $_FILES['pic']['size'];
			if ($picsize/1024>$config['img_size']) {
				cpmsg(lang('plugin/aljzp','aljzp_11').$config['img_size'].'K');
			}
			if ($picname != "") {
				$type = strstr($picname, '.');
				if ($type != ".gif" && $type != ".jpg" && $type != ".png") {
					cpmsg(lang('plugin/aljzp','aljzp_3'));
				}
				$rand = rand(100, 999);
				$pics = date("YmdHis") . $rand . $type;
				$img_dir = 'source/plugin/aljzp/images/logo/';
				if (!is_dir($img_dir)) {
					mkdir($img_dir);
				}
				$$pic = $img_dir . $pics;
				if (@copy($_FILES['pic']['tmp_name'], $$pic) || @move_uploaded_file($_FILES['pic']['tmp_name'], $$pic)) {
					$imageinfo = getimagesize($$pic);
					$w64 = $imageinfo[0] < 180 ? $imageinfo[0] : 180;
					$h64 = $imageinfo[1] < 180 ? $imageinfo[1] : 180;
					img2thumb($$pic, $$pic . '.180x180.jpg', $w64, $h64);
					@unlink($_FILES['pic']['tmp_name']);
				}
			}
		}
		if($_FILES['resfile']['tmp_name']) {
			$picname = $_FILES['resfile']['name'];
			$picsize = $_FILES['resfile']['size'];
			$file_size = $settings['file_size']['value'] ? $settings['file_size']['value'] : 1024;
			$file_format = $settings['file_format']['value'] ? $settings['file_format']['value'] : '.rar,.RAR,.zip,.ZIP,.7z,.7Z,.doc,.docx';
			if ($picsize/1024>$file_size) {
				showerror('&#19978;&#20256;&#31616;&#21382;&#38468;&#20214;&#19981;&#33021;&#36229;&#36807;'.$file_size.'K');
			}
			if ($picname != "") {
				$type = strtolower(strrchr($picname, '.'));
				$filetype = explode(",",$file_format);
				if (!in_array($type, $filetype)) {
					showerror('&#35831;&#19978;&#20256;&#21518;&#32512;&#25991;&#20214;&#20026;'.$file_format);
				}
				$rand = rand(100, 999);
				$filepath = date("YmdHis") . $rand . $type;
				$resfile = "source/plugin/".$pluginid."/images/file/". $filepath;
				if(@copy($_FILES['resfile']['tmp_name'], $resfile)||@move_uploaded_file($_FILES['resfile']['tmp_name'], $resfile)){
					@unlink($_FILES['resfile']['tmp_name']);
					

				}
			}
		}
		if(empty($resfile)){
			$resfile = $_GET['resfile'];
		}

        $insertarray = array(
            'pos' => $_GET['pos'],
            'pos1' => $_GET['pos1'],
			'pos2' => $_GET['pos2'],
            'name' => $_GET['name'],
            'sex' => $_GET['sex'],
            'ymd' => $_GET['ymd'],
            'xueli' => $_GET['xueli'],
            'work_nx' => $_GET['work_nx'],
            'salary' => $_GET['salary'],
            'region' => $_GET['region'],
            'region1' => $_GET['region1'],
            'work_jl' => $_GET['work_jl'],
            'my_introduction' => $_GET['my_introduction'],
            'email' => $_GET['email'],
            'tel' => $_GET['tel'],
			'privacy' => $_GET['privacy'],
			'state' => $_GET['state'],
			'title' => $_GET['title'],
			'resfile' => $resfile,
        );
		if($$pic){
			$insertarray['pic'] = $$pic;
		}
		
		C::t('#aljzp#aljzp_resume')->update($_GET['uid'], $insertarray);
       
		cpmsg(lang('plugin/aljzp','admin_1'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=resume', 'succeed');
	}else{
		$pos = C::t('#aljzp#aljzp_position')->fetch_all_by_upid(0);
		$rs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid(0);
		$lp	=C::t('#aljzp#aljzp_resume')->fetch($_GET['uid']);
		if ($lp['pos']) {
            $prs = C::t('#aljzp#aljzp_position')->fetch_all_by_upid($lp['pos']);
        }
		if ($lp['region']) {
            $rrs = C::t('#aljzp#aljzp_region')->fetch_all_by_upid($lp['region']);
        }
		include template('aljzp:redit');
	}
}else{
	if(!submitcheck('submit')) {
		showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=resume&page='.$_GET['page']);
		showtableheader(); /*di'.'sm.t'.'aoba'.'o.com*/
		showsubtitle(array('','&#21457;&#24067;&#20154;',lang('plugin/aljzp','resume_1'),lang('plugin/aljzp','resume_2'),lang('plugin/aljzp','resume_3'),lang('plugin/aljzp','resume_4'),lang('plugin/aljzp','resume_5'),lang('plugin/aljzp','resume_6'),lang('plugin/aljzp','resume_7'),'&#25512;&#33616;&nbsp;&nbsp;&nbsp;'.lang('plugin/aljzp','resume_8')));
		$currpage=$_GET['page']?$_GET['page']:1;
		$perpage=10;
		$start=($currpage-1)*$perpage;
		$num=DB::result_first("SELECT count(*) FROM ".DB::table('aljzp_resume'));
		$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT."?action=plugins&operation=config&do=".$_GET['do']."&identifier=".$pluginid."&pmod=resume", 0, 10, false, false);
		$query = DB::query("SELECT * FROM ".DB::table('aljzp_resume')." ORDER BY timestamp desc limit $start,$perpage");
		while($row = DB::fetch($query)) {
			if($row[tuijian]){
				$che[$row[uid]]='checked="checked"';
			}
			$nianlin=date('Y',TIMESTAMP)-cutstr($row['ymd'],4,'');
			showtablerow('', array('', 'class="td_m"', 'class="td_k"', 'class="td_l"','class="td_l"','class="td_l"'), array(
							"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$row[uid]\"><input type=\"hidden\" value=\"$row[uid]\" name=\"myid[]\" >",
							$row['username'],
							$row['name'],	
							$row['sex'],	
							$nianlin,		
							$xl_types[$row['xueli']],		
							$row['salary']>0?$row['salary']:lang('plugin/aljzp','resume_9'),	
							$row['tel'],	
							$regions[$row['region']]['subject'].$regions[$row['region1']]['subject'],	
							'<input class="checkbox" type="checkbox" name="tuijian['.$row[uid].']" '.$che[$row[uid]].' value="1">&nbsp;&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=resume&act=edit&uid='.$row[uid].'">'.lang('plugin/aljzp','admin_7').'</a>',		
							));
			
		}
		
		showsubmit('submit', 'submit', 'del','',$paging);
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*dis'.'m.tao'.'bao.com*/
		
		
	}else{
		//debug($_POST);
		if(is_array($_POST['delete'])) {
			foreach($_POST['delete'] as $id) {
				$user=C::t('#aljzp#aljzp_resume')->fetch($id);
				if ($user['pic']) {
					unlink($user['pic']);
					unlink($user['pic'].'.180x180.jpg');
				}
				C::t('#aljzp#aljzp_resume')->delete($id);
			}
		}
		foreach($_POST['myid'] as $id) {
			DB::update('aljzp_resume',array('tuijian'=>$_POST['tuijian'][$id]),'uid='.$id);
		}
		cpmsg(lang('plugin/aljzp','admin_1'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=resume&page='.$_GET['page'], 'succeed');
	}
}
function showmsg($msg,$close){
	if($close){
		$str="parent.hideWindow('$close');";
	}else{
		$str="parent.location=parent.location;";
	}
	include template('aljzp:showmsg');
	exit;
}
function showerror($msg){
	include template('aljzp:showerror');
	exit;
}
function img2thumb($src_img, $dst_img, $width = 75, $height = 75, $cut = 0, $proportion = 0)
{
    if(!is_file($src_img))
    {
        return false;
    }
    $ot = fileext($dst_img);
    $otfunc = 'image' . ($ot == 'jpg' ? 'jpeg' : $ot);
    $srcinfo = getimagesize($src_img);
    $src_w = $srcinfo[0];
    $src_h = $srcinfo[1];
    $type  = strtolower(substr(image_type_to_extension($srcinfo[2]), 1));
    $createfun = 'imagecreatefrom' . ($type == 'jpg' ? 'jpeg' : $type);

    $dst_h = $height;
    $dst_w = $width;
    $x = $y = 0;

    if(($width> $src_w && $height> $src_h) || ($height> $src_h && $width == 0) || ($width> $src_w && $height == 0))
    {
        $proportion = 1;
    }
    if($width> $src_w)
    {
        $dst_w = $width = $src_w;
    }
    if($height> $src_h)
    {
        $dst_h = $height = $src_h;
    }

    if(!$width && !$height && !$proportion)
    {
        return false;
    }
    if(!$proportion)
    {
        if($cut == 0)
        {
            if($dst_w && $dst_h)
            {
                if($dst_w/$src_w> $dst_h/$src_h)
                {
                    $dst_w = $src_w * ($dst_h / $src_h);
                    $x = 0 - ($dst_w - $width) / 2;
                }
                else
                {
                    $dst_h = $src_h * ($dst_w / $src_w);
                    $y = 0 - ($dst_h - $height) / 2;
                }
            }
            else if($dst_w xor $dst_h)
            {
                if($dst_w && !$dst_h)  
                {
                    $propor = $dst_w / $src_w;
                    $height = $dst_h  = $src_h * $propor;
                }
                else if(!$dst_w && $dst_h)  
                {
                    $propor = $dst_h / $src_h;
                    $width  = $dst_w = $src_w * $propor;
                }
            }
        }
        else
        {
            if(!$dst_h)  
            {
                $height = $dst_h = $dst_w;
            }
            if(!$dst_w)  
            {
                $width = $dst_w = $dst_h;
            }
            $propor = min(max($dst_w / $src_w, $dst_h / $src_h), 1);
            $dst_w = (int)round($src_w * $propor);
            $dst_h = (int)round($src_h * $propor);
            $x = ($width - $dst_w) / 2;
            $y = ($height - $dst_h) / 2;
        }
    }
    else
    {
        $proportion = min($proportion, 1);
        $height = $dst_h = $src_h * $proportion;
        $width  = $dst_w = $src_w * $proportion;
    }

    $src = $createfun($src_img);
    $dst = imagecreatetruecolor($width ? $width : $dst_w, $height ? $height : $dst_h);
    $white = imagecolorallocate($dst, 255, 255, 255);
    imagefill($dst, 0, 0, $white);

    if(function_exists('imagecopyresampled'))
    {
        imagecopyresampled($dst, $src, $x, $y, 0, 0, $dst_w, $dst_h, $src_w, $src_h);
    }
    else
    {
        imagecopyresized($dst, $src, $x, $y, 0, 0, $dst_w, $dst_h, $src_w, $src_h);
    }
    $otfunc($dst, $dst_img);
    imagedestroy($dst);
    imagedestroy($src);
    return true;
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>