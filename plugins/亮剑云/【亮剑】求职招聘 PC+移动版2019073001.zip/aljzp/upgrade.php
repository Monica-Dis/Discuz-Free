<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$sql ="ALTER TABLE ".DB::table('aljzp_toplog')." ADD `status` TINYINT( 3 ) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_attestation')." ADD `pic10` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_resume')." ADD `privacy` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljzp_attestation')." ADD `tuijian` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_resume')." ADD `tuijian` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljzp_attestation')." ADD `follow` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_attestation')." ADD `views` int NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljzp_resume')." ADD `title` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_resume')." ADD `resfile` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljzp_resume')." ADD `pos2` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp')." ADD `region3` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_resume')." ADD `state` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp')." ADD `solve` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_region')." ADD `level` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_region')." ADD `havechild` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp')." ADD `state` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp')." ADD `clientip` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp')." ADD `phone` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp')." ADD `pay` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_attestation')." ADD `pic9` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_attestation')." ADD `btntrade` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_attestation')." ADD `property` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_attestation')." ADD `employee` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_attestation')." ADD `region` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_attestation')." ADD `region1` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_attestation')." ADD `region2` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_attestation')." ADD `weal` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_attestation')." ADD `linkman` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_attestation')." ADD `linkmanjob` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_attestation')." ADD `fax` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_attestation')." ADD `website` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljzp_attestation')." ADD `address` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE `pre_aljzp` ADD `qrcode` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE `pre_aljzp_resume` ADD `view` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE `pre_aljzp_resume` ADD `xiazaicishu` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE `pre_aljzp_resume` ADD `toudicishu` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE `pre_aljzp` ADD `tid` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE `pre_aljzp_resume` CHANGE `tel` `tel` VARCHAR( 255 ) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE `pre_aljzp_attestation` CHANGE `tel` `tel` VARCHAR( 255 ) NOT NULL " ;
DB::query($sql,'SILENT');
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljzp_resume_log` (
  `uid` int(11) NOT NULL,
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(255) NOT NULL,
  `res_uid` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `sign` tinyint(4) NOT NULL,
  `money` int(11) NOT NULL,
  `res_name` varchar(255) NOT NULL,
  `res_tel` varchar(255) NOT NULL,
  `extcredit` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_attachment` (
  `aid` int(10) NOT NULL AUTO_INCREMENT,
  `pic` varchar(255) NOT NULL,
  `pid` int(10) NOT NULL,
  PRIMARY KEY (`aid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_setting` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `a` varchar(255) NOT NULL,
  `b` varchar(255) NOT NULL,
  `c` text NOT NULL,
  `d` int(11) NOT NULL,
  `e` int(11) NOT NULL,
  PRIMARY KEY (`key`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_company_follow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `cid` (`cid`)
)
EOF;
runquery($sql);
if(file_exists( DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php')&&file_exists( DISCUZ_ROOT . './source/plugin/aljzp/template/touch/index.htm')){
	$pluginid = 'aljzp';
	$Hooks = array(
		'forumdisplay_topBar',
	);
	$data = array();
	foreach ($Hooks as $Hook) {
		$data[] = array($Hook => array('plugin' => $pluginid, 'include' => 'api.class.php', 'class' => $pluginid . '_api', 'method' => $Hook));
	}
	require_once DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';
	WeChatHook::updateAPIHook($data);
}
$finish = TRUE;
?>