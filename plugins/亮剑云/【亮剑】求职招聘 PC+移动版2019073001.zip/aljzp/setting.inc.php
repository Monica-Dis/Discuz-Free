<?php



if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$_GET=dhtmlspecialchars($_GET);
$pluginid='aljzp';
if(submitcheck('formhash')){
	if($_FILES['logo']['tmp_name']) {
		$picname = $_FILES['logo']['name'];
		$picsize = $_FILES['logo']['size'];
		if ($picname != "") {
			$type = strtolower(strrchr($picname, '.'));
			if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
				cpmsg('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#112;&#110;&#103;&#32;&#46;&#103;&#105;&#102;&#22270;&#29255;');
			}
			$rand = rand(100, 999);
			$pics = date("YmdHis") . $rand . $type;
			$logo = "source/plugin/".$pluginid."/images/logo/". $pics;
			if(@copy($_FILES['logo']['tmp_name'], $logo)||@move_uploaded_file($_FILES['logo']['tmp_name'], $logo)){
				@unlink($_FILES['logo']['tmp_name']);
			}
		}
	}
	if(empty($logo)){
		$logo = $_GET['logo'];
	}
	$record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('logo');
	if($_GET['deletelogo']){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting') -> delete('logo');
		if($record['value']){
			unlink($record['value']);
		}
	}
	if(!$record){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>'logo','value'=>$logo));
	}else{
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($logo,'logo');
	}
	unset($logo);

	if($_FILES['mobile_logo']['tmp_name']) {
		$picname = $_FILES['mobile_logo']['name'];
		$picsize = $_FILES['mobile_logo']['size'];
	
		if ($picname != "") {
			$type = strtolower(strrchr($picname, '.'));
			if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
				cpmsg('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#112;&#110;&#103;&#32;&#46;&#103;&#105;&#102;&#22270;&#29255;');
			}
			$rand = rand(100, 999);
			$mobile_pics = date("YmdHis") . $rand . $type;
			$mobile_logo = "source/plugin/".$pluginid."/images/logo/". $mobile_pics;
			if(@copy($_FILES['mobile_logo']['tmp_name'], $mobile_logo)||@move_uploaded_file($_FILES['mobile_logo']['tmp_name'], $mobile_logo)){
				@unlink($_FILES['mobile_logo']['tmp_name']);
			}
		}
	}

	if(empty($mobile_logo)){
		$mobile_logo = $_GET['mobile_logo'];
	}

	
	$mobile_record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('mobile_logo');

	if($_GET['deletemobile_logo']){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting') -> delete('mobile_logo');
		if($mobile_record['value']){
			unlink($mobile_record['value']);
		}
	}

	if(!$mobile_record){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>'mobile_logo','value'=>$logo));
	}else{
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($mobile_logo,'mobile_logo');
	}
	unset($mobile_logo);
	
	if($_FILES['header_logo']['tmp_name']) {
		$picname = $_FILES['header_logo']['name'];
		$picsize = $_FILES['header_logo']['size'];
	
		if ($picname != "") {
			$type = strtolower(strrchr($picname, '.'));
			if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
				cpmsg('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#112;&#110;&#103;&#32;&#46;&#103;&#105;&#102;&#22270;&#29255;');
			}
			$rand = rand(100, 999);
			$header_pics = date("YmdHis") . $rand . $type;
			$header_logo = "source/plugin/".$pluginid."/images/logo/". $header_pics;
			if(@copy($_FILES['header_logo']['tmp_name'], $header_logo)||@move_uploaded_file($_FILES['header_logo']['tmp_name'], $header_logo)){
				@unlink($_FILES['header_logo']['tmp_name']);
			}
		}
	}

	if(empty($header_logo)){
		$header_logo = $_GET['header_logo'];
	}

	
	$header_record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('header_logo');

	if($_GET['deleteheader_logo']){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting') -> delete('header_logo');
		if($header_record['value']){
			unlink($header_record['value']);
		}
	}

	if(!$header_record){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>'header_logo','value'=>$logo));
	}else{
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($header_logo,'header_logo');
	}
	unset($header_logo);

	if($_FILES['qrcode_logo']['tmp_name']) {
		$picname = $_FILES['qrcode_logo']['name'];
		$picsize = $_FILES['qrcode_logo']['size'];
	
		if ($picname != "") {
			$type = strtolower(strrchr($picname, '.'));
			if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
				cpmsg('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#112;&#110;&#103;&#32;&#46;&#103;&#105;&#102;&#22270;&#29255;');
			}
			$rand = rand(100, 999);
			$qrcode_pics = date("YmdHis") . $rand . $type;
			$qrcode_logo = "source/plugin/".$pluginid."/images/logo/". $qrcode_pics;
			if(@copy($_FILES['qrcode_logo']['tmp_name'], $qrcode_logo)||@move_uploaded_file($_FILES['qrcode_logo']['tmp_name'], $qrcode_logo)){
				@unlink($_FILES['qrcode_logo']['tmp_name']);
			}
		}
	}

	if(empty($qrcode_logo)){
		$qrcode_logo = $_GET['qrcode_logo'];
	}

	
	$qrcode_record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('qrcode_logo');

	if($_GET['deleteqrcode_logo']){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting') -> delete('qrcode_logo');
		if($qrcode_record['value']){
			unlink($qrcode_record['value']);
		}
	}

	if(!$qrcode_record){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>'qrcode_logo','value'=>$logo));
	}else{
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($qrcode_logo,'qrcode_logo');
	}

	if(!C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('mhot')){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>'mhot','value'=>$_GET['mhot']));
	}else{
		if($_GET['mhot']){
			C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($_GET['mhot'],'mhot');
		}
	}

	if(!C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('mhotmore')){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>'mhotmore','value'=>$_GET['mhotmore']));
	}else{
		if($_GET['mhotmore']){
			C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($_GET['mhotmore'],'mhotmore');
		}
	}
	
	foreach($_GET['settingsnew'] as $k=>$v){
		if(!C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch($k)){
			C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>$k,'value'=>$v));
		}else{
			C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($v,$k);
		}
	}

	cpmsg('&#26356;&#26032;&#25104;&#21151;&#65281;', 'action=plugins&operation=config&identifier='.$pluginid.'&pmod=setting', 'succeed');
}else{
	if(!C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('pluginfooter')){
		$pluginfooter = '<p class="links">
<a href="#">&#32852;&#31995;&#25105;&#20204;</a> - 
<a href="#">&#20813;&#36131;&#30003;&#26126;</a> - 
<a href="#">&#20132;&#26131;&#39035;&#30693;</a> - 
<a href="#">&#38544;&#31169;&#20445;&#25252;</a> - 
<a href="#">&#27880;&#20876;&#26465;&#27454;</a> - 
<a href="plugin.php?id='.$pluginid.'">&#36820;&#22238;&#39318;&#39029;</a>
</p>
<p>
<span style="line-height:1.5;">
<a target="_blank" href="plugin.php?id='.$pluginid.'">'.$config['daohang'].'</a> 
&copy;  &nbsp;&nbsp;</span>
<span style="line-height:1.5;">&#26381;&#21153;&#28909;&#32447;:&nbsp;0000-88888888</span>&nbsp;
</p>';
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>'pluginfooter','value'=>$pluginfooter));
	}
	if(!C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('mobile_index_new_dh')){
		$mobile_index_new_dh = 'plugin.php?id=aljzp&act=myresume|source/plugin/aljzp/images/q.png|&#25105;&#30340;&#31616;&#21382;
plugin.php?id=aljzp&act=resumes|source/plugin/aljzp/images/z.png|&#31616;&#21382;&#24211;
plugin.php?id=aljzp&act=post|source/plugin/aljzp/images/zz.png|&#21457;&#24067;&#20449;&#24687;
plugin.php?id=aljzp&act=user|source/plugin/aljzp/images/p.png|&#29992;&#25143;&#20013;&#24515;';
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>'mobile_index_new_dh','value'=>$mobile_index_new_dh));
	}
	$record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('logo');
	$logo = $record['value'];
	
	$mobile_record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('mobile_logo');
	$mobile_logo = $mobile_record['value'];
	
	$header_record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('header_logo');

	$header_logo = $header_record['value'];

	$qrcode_record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('qrcode_logo');
	$qrcode_logo = $qrcode_record['value'];
	$setting = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->range();
	$settings= $setting;
	include template($pluginid.':setting');
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>