<?php

/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ��ϵQQ: DISM.TAOBAO.COM
 * ����˵��:MAPP΢�ŷ����ӿ�
 */

if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}


$user_agent = $_SERVER['HTTP_USER_AGENT'];
$sharethread = DB::fetch_first('select * from %t where tid=%d and type=%d',array('aljwsq_mapp_share_adminthread',$shareid,$sharetype));

if($sharetype == 1){
	$sharedata = DB::fetch_first('select * from %t where id=%d',array($pluginid,$shareid));
    if($pluginid == 't_brand'){
        $shareurl = $_G[siteurl].'plugin.php?id=t_brand&act=view&bid='.$shareid;
    }elseif($pluginid == 't_shop'){
        $shareurl = $_G[siteurl].'plugin.php?id=t_shop&act=view&bid='.$shareid;
    }else{
        $shareurl = $_G[siteurl].'plugin.php?id=aljbd&act=view&bid='.$shareid;
    }
    $sharedata['name'] = strip_tags($sharedata['name']);
	$sharedata['intro'] = $sharedata['intro'] ? strip_tags(str_replace(array("\r\n", "\r", "\n","&nbsp;"), "", $sharedata['intro'])) : strip_tags($sharedata['name']);
}else if($sharetype == 2){

	$sharedata = DB::fetch_first('select * from %t where id=%d',array($pluginid.'_goods',$shareid));
    if($pluginid == 't_brand'){
        $shareurl = $_G[siteurl].'plugin.php?id=t_brand&act=goodview&bid='.$sharedata['bid'].'&gid='.$shareid;
    }elseif($pluginid == 't_shop'){
        $shareurl = $_G[siteurl].'plugin.php?id=t_shop&act=goodview&bid='.$sharedata['bid'].'&gid='.$shareid;
    }else{
        $shareurl = $_G[siteurl].'plugin.php?id=aljbd&act=goodview&bid='.$sharedata['bid'].'&gid='.$shareid;
    }
	$sharedata['logo'] = $sharedata['pic1'];
    $sharedata['name'] = strip_tags($sharedata['name']);
	$sharedata['intro'] = $sharedata['intro'] ? strip_tags(str_replace(array("\r\n", "\r", "\n","&nbsp;"), "", $sharedata['intro'])) : strip_tags($sharedata['name']);

}else if($sharetype == 3){

	$sharedata = DB::fetch_first('select * from %t where id=%d',array($pluginid.'_consume',$shareid));
    if($pluginid == 't_brand'){
        $shareurl = $_G[siteurl].'plugin.php?id=t_brand&act=consumeview&bid='.$sharedata['bid'].'&cid='.$shareid;
    }elseif($pluginid == 't_shop'){
        $shareurl = $_G[siteurl].'plugin.php?id=t_shop&act=consumeview&bid='.$sharedata['bid'].'&cid='.$shareid;
    }else{
        $shareurl = $_G[siteurl].'plugin.php?id=aljbd&act=consumeview&bid='.$sharedata['bid'].'&cid='.$shareid;
    }
	$sharedata['logo'] = $sharedata['pic'];
	$sharedata['name'] = strip_tags($sharedata['subject']);
	$sharedata['intro'] = $sharedata['jieshao'] ? strip_tags(str_replace(array("\r\n", "\r", "\n","&nbsp;"), "", $sharedata['jieshao'])) : strip_tags($sharedata['subject']);
}else if($sharetype == 4){
	$sharedata = DB::fetch_first('select * from %t where id=%d',array('aljyg',$shareid));
	$shareurl = $_G[siteurl].'plugin.php?id=aljyg&act=goodsview&yid='.$shareid.'&tid='.$sharedata['tableid'].'&pid='.$sharedata['level'];
	$sharedata['name'] = strip_tags($sharedata['title']);
	$sharedata['intro'] = $sharedata['intro'] ? strip_tags(str_replace(array("\r\n", "\r", "\n","&nbsp;"), "", $sharedata['intro'])) : strip_tags($sharedata['title']);
}else if($sharetype == 5){
	$sharedata = DB::fetch_first('select * from %t where id=%d',array('aljsc',$shareid));
	$shareurl = $_G[siteurl].'plugin.php?id=aljsc&act=view&sid='.$shareid;
	$sharedata['name'] = strip_tags($sharedata['title']);
	$sharedata['intro'] = $sharedata['desc'] ? strip_tags(str_replace(array("\r\n", "\r", "\n","&nbsp;"), "", $sharedata['desc'])) : strip_tags($sharedata['title']);
}else if($sharetype == 6){
	$sharedata = DB::fetch_first('select * from %t where id=%d',array('aljtg',$shareid));
	$shareurl = $_G[siteurl].'plugin.php?id=aljtg&act=view&gid='.$shareid;
	$sharedata['name'] = strip_tags($sharedata['name']);
	$sharedata['intro'] = $sharedata['intro'] ? strip_tags(str_replace(array("\r\n", "\r", "\n"), "", $sharedata['intro'])) : strip_tags($sharedata['name']);
}else if($sharetype == 7){
	$sharedata = DB::fetch_first('select * from %t where id=%d',array('aljzp',$shareid));
	$shareurl = $_G[siteurl].'plugin.php?id=aljzp&act=view&lid='.$shareid;
	$sharedata['logo'] = $sharedata['pic1'];
    $lblist = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljzp']['lb']));
    foreach($lblist as $key=>$value){
        $arr=explode('=',$value);
        $lb_types[$arr[0]]=$arr[1];
    }
	//$sharedata['name'] = '��'.$lb_types[$sharedata['wanted']].'��'.strip_tags($sharedata['title']);
	$sharedata['intro'] = $sharedata['content'] ? strip_tags(str_replace(array("\r\n", "\r", "\n"), "", $sharedata['content'])) : strip_tags($sharedata['title']);
}else if($sharetype == 8){
	$sharedata = DB::fetch_first('select * from %t where id=%d',array('aljes',$shareid));
    $wanted_list = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljes']['gongqiu']));
    foreach($wanted_list as $key=>$value){
        $new_arr=explode('=',$value);
        $wanted_types[$new_arr[0]]=$new_arr[1];
    }
	$shareurl = $_G[siteurl].'plugin.php?id=aljes&act=view&lid='.$shareid;
	$sharedata['logo'] = $sharedata['pic1'];
	//$sharedata['name'] = '��'.$wanted_types[$sharedata['wanted']].'��'.strip_tags($sharedata['title']);
	$sharedata['intro'] = $sharedata['content'] ? strip_tags(str_replace(array("\r\n", "\r", "\n"), "", $sharedata['content'])) : strip_tags($sharedata['title']);

}else if($sharetype == 9){
	$sharedata = DB::fetch_first('select * from %t where id=%d',array('aljcw',$shareid));
	$shareurl = $_G[siteurl].'plugin.php?id=aljcw&act=view&lid='.$shareid;
	$sharedata['logo'] = $sharedata['pic1'];
	//$sharedata['name'] = strip_tags($sharedata['title']);
    $sharedata['intro'] = $sharedata['content'] ? strip_tags(str_replace(array("\r\n", "\r", "\n"), "", $sharedata['content'])) : strip_tags($sharedata['title']);
}else if($sharetype == 10){
	$sharedata = DB::fetch_first('select * from %t where id=%d',array('aljpc',$shareid));
	$shareurl = $_G[siteurl].'plugin.php?id=aljpc&act=view&lid='.$shareid;
	$sharedata['logo'] = $sharedata['pic1'];
	//$sharedata['name'] = strip_tags($sharedata['title']);
    $sharedata['intro'] = $sharedata['content'] ? strip_tags(str_replace(array("\r\n", "\r", "\n"), "", $sharedata['content'])) : strip_tags($sharedata['title']);
}else if($sharetype == 11){
	$sharedata = DB::fetch_first('select * from %t where id=%d',array('aljesc',$shareid));

    $wanted = $sharedata['wanted'] == 1 ? '������' : '���󹺡�';
	$shareurl = $_G[siteurl].'plugin.php?id=aljesc&act=view&lid='.$shareid;
	$sharedata['logo'] = $sharedata['pic1'];
	//$sharedata['name'] = strip_tags($sharedata['title']);
    $sharedata['intro'] = $sharedata['content'] ? strip_tags(str_replace(array("\r\n", "\r", "\n"), "", $sharedata['content'])) : strip_tags($sharedata['title']);
}else if($sharetype == 12){
	$sharedata = DB::fetch_first('select * from %t where id=%d',array('aljzc',$shareid));
	$shareurl = $_G[siteurl].'plugin.php?id=aljzc&act=view&lid='.$shareid;
	$sharedata['logo'] = $sharedata['pic1'];
	//$sharedata['name'] = strip_tags($sharedata['title']);
    $sharedata['intro'] = $sharedata['content'] ? strip_tags(str_replace(array("\r\n", "\r", "\n"), "", $sharedata['content'])) : strip_tags($sharedata['title']);
}else if($sharetype == 13){
	$sharedata = DB::fetch_first('select * from %t where id=%d',array('aljlp',$shareid));
	$shareurl = $_G[siteurl].'plugin.php?id=aljlp&act=view&lid='.$shareid;
	$sharedata['logo'] = $sharedata['pic1'];
	//$sharedata['name'] = strip_tags($sharedata['title']);
    $sharedata['intro'] = $sharedata['content'] ? strip_tags(str_replace(array("\r\n", "\r", "\n"), "", $sharedata['content'])) : strip_tags($sharedata['title']);
}else if($sharetype == 14){
	$sharedata = DB::fetch_first('select * from %t where id=%d',array('aljesf',$shareid));
	$shareurl = $_G[siteurl].'plugin.php?id=aljesf&act=view&lid='.$shareid;
	$sharedata['logo'] = $sharedata['pic1'];
	//$sharedata['name'] = strip_tags($sharedata['title']);
	$sharedata['intro'] = strip_tags(str_replace(array("\r\n", "\r", "\n"), "", $sharedata['content']));
}else if($sharetype == 15){
	$sharedata = DB::fetch_first('select * from %t where id=%d',array('aljpx',$shareid));
	$shareurl = $_G[siteurl].'plugin.php?id=aljpx&act=view&lid='.$shareid;
	$sharedata['logo'] = $sharedata['pic1'];
	//$sharedata['name'] = strip_tags($sharedata['title']);
    $sharedata['intro'] = $sharedata['content'] ? strip_tags(str_replace(array("\r\n", "\r", "\n"), "", $sharedata['content'])) : strip_tags($sharedata['title']);
}else if($sharetype == 16){
	$sharedata = DB::fetch_first('select * from %t where id=%d',array($pluginid.'_notice',$shareid));
	if($pluginid == 't_brand'){
		$shareurl = $_G[siteurl].'plugin.php?id=t_brand&act=noticeview&bid='.$sharedata['bid'].'&nid='.$shareid;
	}elseif($pluginid == 't_shop'){
		$shareurl = $_G[siteurl].'plugin.php?id=t_shop&act=noticeview&bid='.$sharedata['bid'].'&nid='.$shareid;
	}else{
		$shareurl = $_G[siteurl].'plugin.php?id=aljbd&act=noticeview&bid='.$sharedata['bid'].'&nid='.$shareid;
	}
	
	$sharedata['logo'] = $sharedata['pic'];
	$sharedata['name'] = strip_tags($sharedata['subject']);
	$sharedata['intro'] = $sharedata['content'] ? strip_tags(str_replace(array("\r\n", "\r", "\n"), "", $sharedata['content'])) : strip_tags($sharedata['subject']);
}else{
	$shareurl = $shareurl;
	$sharedata['name'] = $navtitle;
	$sharedata['intro'] = $metadescription;
}
if($sharethread){
	if(!strpos($user_agent, 'MicroMessenger') === false && !empty($sharethread) && !empty($shareid) && !empty($sharetype)){
	require_once 'source/plugin/aljwsq/function_core.php';
	if($_G['uid']){
		$binduser = DB::fetch_first('SELECT * FROM %t WHERE  uid=%d', array('aljwsq_mapp_user', $_G['uid']));
		$openid = $binduser['openid'];
		$user = C::t('common_member')->fetch_by_username($binduser['username']);
		$check = !lgetuseraction($_G['uid'],'mapp_share',$sharetype.'sendshareextcredit'.$shareid);
	}elseif(DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','mapp_wechat'))){
		$jsoninfo = lgetoauth2openid($shareurl);
		if($jsoninfo['errcode']){
			unset($_GET['code']);
			$jsoninfo = lgetoauth2openid($shareurl);
		}
		$openid = $jsoninfo['openid'];
		if($openid){
			$binduser = DB::fetch_first('SELECT * FROM %t WHERE openid=%s and uid>0', array('aljwsq_mapp_user', $openid));
			$user = C::t('common_member')->fetch_by_username($binduser['username']);
			if($user){
				require_once 'source/plugin/aljwsq/function_core.php';
				$check = !lgetuseraction($_G['uid'],'mapp_share',$sharetype.'sendshareextcredit'.$shareid);
				require_once libfile('function/member');
				setloginstatus($user, 2592000);
			}
		}
	}
}
}

$share_config = $_G['cache']['plugin']['mapp_share'];
$sharedata[other] = $sharedata[other]?' - '.$sharedata[other]:'';
$sharedata['name'] = $sharethread[title] ? $sharethread[title] : $sharedata['name'].$sharedata[other];
$sharedata['intro'] = $sharethread[desc] ? $sharethread[desc] : $sharedata['intro'];
$sharedata['logo'] = $_G['siteurl'].($sharethread[logo] ? $sharethread[logo] : ($sharedata[logo] ? $sharedata[logo] : $share_config[defaultsharelogo]));
$shareurl = ($sharethread[url] ? $sharethread[url] : ($shareurl ? $shareurl : $_G[siteurl].'forum.php?mod=viewthread&tid='.$_G[tid]));

/*$aljwsq_config = $_G['cache']['plugin']['aljwsq'];
if($aljwsq_config['appid'] && $aljwsq_config['appsecret']){
	require_once DISCUZ_ROOT.'source/plugin/aljwsq/mapp_wechatclient.lib.class.php';
	$wechat_client = new WeChatClient($aljwsq_config['appid'], $aljwsq_config['appsecret']);
	$signPackage = $wechat_client -> getJsApiSignPackage();
}*/