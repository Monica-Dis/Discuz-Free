<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$config = array();
foreach($pluginvars as $key => $val) {
	$config[$key] = $val['value'];	
}
// �����б�
$creditlist = array();
foreach ($_G['setting']['extcredits'] as $key => $credit) {
	$creditlist[] = array($key, 'extcredits'.$key.' ('.$credit['title'].')');
}

//Ӧ���б�
$applist = array(
	"0" => '&#35770;&#22363;&#36148;&#23376;',//��̳����
	"1" => '&#21830;&#23478;&#24215;&#38138;',//�̼ҵ���
	"2" => '&#21830;&#23478;&#21830;&#21697;',//�̼���Ʒ
	"16" => '&#21830;&#23478;&#27963;&#21160;',//�̼һ
	"3" => '&#21830;&#23478;&#20248;&#24800;&#21048;',//�̼��Ż�ȯ
	"4" => '&#22842;&#23453;&#21830;&#22478;',//�ᱦ�̳�
	"5" => '&#31215;&#20998;&#21830;&#22478;',//�����̳�
	"6" => '&#22242;&#36141;&#21830;&#22478;',//�Ź��̳�
	"7" => '&#25307;&#32856;&#20449;&#24687;',//��Ƹ��Ϣ
	"8" => '&#20108;&#25163;&#24066;&#22330;',//�����г�
	"9" => '&#23456;&#29289;',//����
	"10" => '&#25340;&#36710;',//ƴ��
	"11" => '&#20108;&#25163;&#36710;',//���ֳ�
	"12" => '&#31199;&#36710;',//�⳵
	"13" => '&#25151;&#23627;&#20986;&#31199;',//���ݳ���
	"14" => '&#20108;&#25163;&#25151;',//���ַ�
	"15" => '&#25945;&#32946;&#22521;&#35757;',//������ѵ
);
$act = htmlspecialchars($_GET['act']);
$fid = intval($_GET['fid']);
if($_GET['act']=='addthread'){
	if (submitcheck('formhash')) {
        $pic = 'logo';
        if ($_FILES[$pic]['tmp_name']) {
            $picname = $_FILES[$pic]['name'];
            $picsize = $_FILES[$pic]['size'];

            if ($picname != "") {
               $type = strtolower(strrchr($picname, '.'));
                if ($type != ".gif" && $type != ".jpg" && $type != ".png" && $type != ".jpeg") {
                    cpmsg('&#22270;&#29255;&#26684;&#24335;&#19981;&#27491;&#30830;&#65281;');
                }
                $rand = rand(100, 999);
                $pics = date("YmdHis") . $rand . $type;
                $img_dir = 'source/plugin/mapp_share/images/';
                if (!is_dir($img_dir)) {
                    mkdir($img_dir);
                }
                $$pic = $img_dir . $pics;
                if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
                    @unlink($_FILES[$pic]['tmp_name']);
                }
            }
        }
        C::t('#mapp_share#aljwsq_mapp_share_adminthread')->insert(array(
            'title' => $_GET['title'],
            'type' => $_GET['type'],
            'logo' => $$pic,
            'url' => $_GET['url'],
            'desc' => $_GET['desc'],
            'tid' => $_GET['tid'],
            'rewardcredit' => $_GET['rewardcredit'],
            'addcreditnum' => $_GET['addcreditnum'],
            'dateline' => TIMESTAMP,
			'stips' => $_GET['stips'],
        ));
        cpmsg('&#28155;&#21152;&#25104;&#21151;&#65281;', 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=mapp_share&pmod=adminthread', 'succeed');
	}else{
		include template('mapp_share:addthread');
	}
}else if($_GET['act']=='editthread'){
	if ($_GET['id']) {
        $thread = C::t('#mapp_share#aljwsq_mapp_share_adminthread')->fetch($_GET['id']);
    }
	$id = intval($_GET['id']);
    if (submitcheck('formhash')) {
        $pic = 'logo';
        if ($_FILES[$pic]['tmp_name']) {
            $picname = $_FILES[$pic]['name'];
            $picsize = $_FILES[$pic]['size'];

            if ($picname != "") {
                $type = strtolower(strrchr($picname, '.'));
                if ($type != ".gif" && $type != ".jpg" && $type != ".png" && $type != ".jpeg") {
                    cpmsg('&#22270;&#29255;&#26684;&#24335;&#19981;&#27491;&#30830;&#65281;');
                }
                $rand = rand(100, 999);
                $pics = date("YmdHis") . $rand . $type;
                $img_dir = 'source/plugin/mapp_share/images/';
                if (!is_dir($img_dir)) {
                    mkdir($img_dir);
                }
                $$pic = $img_dir . $pics;
                if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
                    @unlink($_FILES[$pic]['tmp_name']);
                }
            }
        }
        $updatearray = array(
            'title' => $_GET['title'],
			'type' => $_GET['type'],
            'url' => $_GET['url'],
            'desc' => $_GET['desc'],
            'tid' => $_GET['tid'],
            'stips' => $_GET['stips'],
            'rewardcredit' => $_GET['rewardcredit'],
            'addcreditnum' => $_GET['addcreditnum'],
            'dateline' => TIMESTAMP,
        );
        if ($$pic) {
            $updatearray['logo'] = $$pic;
        }
        C::t('#mapp_share#aljwsq_mapp_share_adminthread')->update($id, $updatearray);
        cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;', 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=mapp_share&pmod=adminthread', 'succeed');
    } else {
        include template('mapp_share:addthread');
    }
}else if ($_GET['act'] == 'deletethread') {
    if($_GET['formhash']==formhash()){
        if ($_GET['id']) {
			$reply = C::t('#mapp_share#aljwsq_mapp_share_adminthread')->fetch($_GET['id']);
            C::t('#mapp_share#aljwsq_mapp_share_adminthread')->delete($_GET['id']);
			@unlink($reply['logo']);
        }
        cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;', 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=mapp_share&pmod=adminthread', 'succeed');
    }
}else{
	$currpage=$_GET['page']?$_GET['page']:1;
	$perpage=20;
	$num=C::t('#mapp_share#aljwsq_mapp_share_adminthread')->count();
	$start=($currpage-1)*$perpage;
	$threadlist = C::t('#mapp_share#aljwsq_mapp_share_adminthread')->range($start,$perpage,'desc');
	$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier=mapp_share&pmod=adminthread'.$url, 0, 11, false, false);
	include template('mapp_share:adminthread');
}
//From: d'.'is'.'m.ta'.'obao.com
?>