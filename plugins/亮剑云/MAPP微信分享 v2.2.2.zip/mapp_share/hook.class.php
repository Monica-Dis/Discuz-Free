<?php
/*
 * Copyright (c) 2021 by dism.taobao.com
 * 技术支持: https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 功能说明:MAPP微信分享
 */

if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

class plugin_mapp_share {
	
}


class plugin_mapp_share_forum extends plugin_mapp_share
{
	function viewthread_postbottom (){
		global $_G;
		$config = $_G['cache']['plugin']['mapp_share'];
		if($_G['tid'] && $config['showqrcode']){
			require_once DISCUZ_ROOT.'source/plugin/mapp_share/qrcode.class.php';
			$file = 'source/plugin/mapp_share/images/'.$_G['tid'].'.jpg';
			if(!file_exists($file)){
				QRcode_mapp_share::png($_G['siteurl'].'forum.php?mod=viewthread&tid='.$_G['tid'].'&from=qrcode&mobile=2',$file);
			}
			return array('<img style="display: block !important;
    margin: 5px auto;" src="'.$file.'">');
		}
		
	}
}
class mobileplugin_mapp_share{
	function common(){
	}
    function global_footer_mobile(){
        global $_G;
        $user_agent = $_SERVER['HTTP_USER_AGENT'];


        if(strpos($user_agent, 'MicroMessenger') === false || $_GET['mod'] == 'post'  || $_GET['mod'] == 'logging' || $_GET['mod'] == 'space' || $_G['inajax'] || !$_G['cache']['plugin']['mapp_share']['is_share_thread']){
            return false;
        }
        $config = $_G['cache']['plugin']['mapp_share'];
        if($_G['tid']){
            $sharethread = DB::fetch_first('select * from %t where tid=%d and type=0',array('aljwsq_mapp_share_adminthread',$_G['tid']));
            require_once 'source/plugin/aljwsq/function_core.php';
            if($_G['uid']){
                $binduser = DB::fetch_first('SELECT * FROM %t WHERE  uid=%d', array('aljwsq_mapp_user', $_G['uid']));
                $openid = $binduser['openid'];
                $user = C::t('common_member')->fetch_by_username($binduser['username']);
                $check = !lgetuseraction($_G['uid'],'mapp_share','sendshareextcredit'.$_G['tid']);
            }elseif(DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','mapp_wechat'))){
                $jsoninfo = lgetoauth2openid($_G[siteurl].'forum.php?mod=viewthread&tid='.$_G['tid']);
                if($jsoninfo['errcode']){
                    unset($_GET['code']);
                    $jsoninfo = lgetoauth2openid($_G[siteurl].'forum.php?mod=viewthread&tid='.$_G['tid']);
                }
                $openid = $jsoninfo['openid'];
                if($openid){
                    $binduser = DB::fetch_first('SELECT * FROM %t WHERE openid=%s and uid>0', array('aljwsq_mapp_user', $openid));
                    $user = C::t('common_member')->fetch_by_username($binduser['username']);
                    if($user){
                        //require_once 'source/plugin/aljwsq/function_core.php';
                        $check = !lgetuseraction($_G['uid'],'mapp_share','sendshareextcredit'.$_G['tid']);
                        require_once libfile('function/member');
                        setloginstatus($user, 2592000);
                    }
                }
            }
            $thread = C::t('forum_post')->fetch_threadpost_by_tid_invisible($_G['tid']);
			if($thread[message]){
				require_once libfile('function/discuzcode'); 
				$thread[message] = str_replace(array("\r\n", "\r", "\n"), "", $thread[message]);
				$thread[message] = discuzcode($thread[message], 0, 0, 0, 1, 1, 0, 0, 0, 0, 0);
				$thread[message] = str_replace(PHP_EOL, '', $thread[message]);
				
				$thread[message] = preg_replace('/\[attach\].+\[\/attach\]/is', '', $thread[message]);
				$thread[message] = preg_replace('/\[hide\].*?\[\/hide\]/is', '', $thread[message]);
				$thread[message] = preg_replace('/\{\:soso_e(\d+)\:\}/is', '', $thread[message]);
				$search_space = array('(((\s)*\-(\s)*)+)', '(((\s)*\,(\s)*)+)', '(((\s)*\|(\s)*)+)', '(((\s)*\t(\s)*)+)', '(((\s)*_(\s)*)+)');
				$replace_space = array('$3-$3', '$3,$3', '$3|$3', '$3 $3', '$3_$3');
				$thread[message] = trim(preg_replace($search_space, $replace_space, $thread[message]), ' ,-|_');
				$thread[message] = cutstr(strip_tags(preg_replace('/\<img.*?\>/is', '', $thread[message])),100);
			}
            $threadimage = DB::result_first('select attachment from %t where tid=%d',array('forum_threadimage',$_G['tid']));
            $sharedata['name'] = $sharethread[title] ? $sharethread[title] : $thread[subject];
            $sharedata['intro'] = $sharethread[desc] ? $sharethread[desc] : ($thread[message]?$thread[message]:$thread[subject]);
            $sharedata['logo'] = $_G['siteurl'].($sharethread[logo] ? $sharethread[logo] : ($threadimage ? 'data/attachment/forum/'.$threadimage : $config[defaultsharelogo]));
            $shareurl = $sharethread[url] ? $sharethread[url] : $_G[siteurl].'forum.php?mod=viewthread&tid='.$_G[tid];
        }




        include template('mapp_share:share');
        return $return_mapp_share;
    }
}
class mobileplugin_mapp_share_forum extends mobileplugin_mapp_share{

	function viewthread_bottom_mobile(){
		global $_G;
		/*$user_agent = $_SERVER['HTTP_USER_AGENT'];
		$sharethread = DB::fetch_first('select * from %t where tid=%d and type=0',array('aljwsq_mapp_share_adminthread',$_G['tid']));

		if(strpos($user_agent, 'MicroMessenger') === false){
			return false;
		}
		require_once 'source/plugin/aljwsq/function_core.php';
		if($_G['uid']){
			$binduser = DB::fetch_first('SELECT * FROM %t WHERE  uid=%d', array('aljwsq_mapp_user', $_G['uid']));
			$openid = $binduser['openid'];
			$user = C::t('common_member')->fetch_by_username($binduser['username']);
			$check = !lgetuseraction($_G['uid'],'mapp_share','sendshareextcredit'.$_G['tid']);
		}elseif(DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','mapp_wechat'))){
			$jsoninfo = lgetoauth2openid($_G[siteurl].'forum.php?mod=viewthread&tid='.$_G['tid']);
			if($jsoninfo['errcode']){
				unset($_GET['code']);
				$jsoninfo = lgetoauth2openid($_G[siteurl].'forum.php?mod=viewthread&tid='.$_G['tid']);
			}
			$openid = $jsoninfo['openid'];
			if($openid){
				$binduser = DB::fetch_first('SELECT * FROM %t WHERE openid=%s and uid>0', array('aljwsq_mapp_user', $openid));
				$user = C::t('common_member')->fetch_by_username($binduser['username']);
				if($user){
					require_once 'source/plugin/aljwsq/function_core.php';
					$check = !lgetuseraction($_G['uid'],'mapp_share','sendshareextcredit'.$_G['tid']);
					require_once libfile('function/member');
					setloginstatus($user, 2592000);
				}
			}
		}
		
		$config = $_G['cache']['plugin']['mapp_share'];
		$aljwsq_config = $_G['cache']['plugin']['aljwsq'];
		if($aljwsq_config['appid'] && $aljwsq_config['appsecret']){
			require_once DISCUZ_ROOT.'source/plugin/aljwsq/mapp_wechatclient.lib.class.php';
			$wechat_client = new WeChatClient($aljwsq_config['appid'], $aljwsq_config['appsecret']);
			$signPackage = $wechat_client -> getJsApiSignPackage();
		}
		$thread = DB::fetch_first('select * from %t where tid=%d',array('forum_thread',$_G['tid']));
		$threadimage = DB::result_first('select attachment from %t where tid=%d',array('forum_threadimage',$_G['tid']));
        $sharedata['name'] = $sharethread[title] ? $sharethread[title] : $thread[subject];
        $sharedata['intro'] = $sharethread[desc] ? $sharethread[desc] : $thread[subject];
        $sharedata['logo'] = $_G['siteurl'].($sharethread[logo] ? $sharethread[logo] : ($threadimage ? 'data/attachment/forum/'.$threadimage : $config[defaultsharelogo]));
        $shareurl = $sharethread[url] ? $sharethread[url] : $_G[siteurl].'forum.php?mod=viewthread&tid='.$_G[tid].'&openid='.$openid;

		include template('mapp_share:share');
		return $return_mapp_share;*/
	}
}