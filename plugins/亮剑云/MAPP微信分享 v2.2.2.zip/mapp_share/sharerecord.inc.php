<?php

/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ��ϵQQ: DISM.TAOBAO.COM
 * ����˵��:MAPP΢�ź��ӷ�����־
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$act = htmlspecialchars($_GET['act']);
if($act == 'delete'){
	if(is_array($_POST['delete'])) {
		foreach($_POST['delete'] as $id) {
			DB::query('delete from %t where id=%d',array('aljwsq_mapp_action_log',$id));
		}
	}
	cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=mapp_share&pmod=sharerecord');
}else{
	
	$currpage = $_GET['page'] ? intval($_GET['page']) : 1;
	$perpage = 11;
	$num = DB::result_first("select count(*) from %t where appid='mapp_share'",array('aljwsq_mapp_action_log'));
	$start = ($currpage - 1) * $perpage;
	$loglist = DB::fetch_all("select * from %t where appid='mapp_share' order by id desc limit %d,%d",array('aljwsq_mapp_action_log',$start,$perpage));
	$paging = helper_page :: multi($num, $perpage, $currpage, 'admin.php?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=mapp_share&pmod=sharerecord', 0, 11, false, false);
	include template('mapp_share:sharerecord');
}
//From: d'.'is'.'m.ta'.'obao.com
?>