<?php

/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ��ϵQQ: DISM.TAOBAO.COM
 * ����˵��:MAPP΢�ŷ���
 */

if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

//Ӧ���б�
$applist = array(
	"0" => '&#35770;&#22363;&#36148;&#23376;',//��̳����
	"1" => '&#21830;&#23478;&#24215;&#38138;',//�̼ҵ���
	"2" => '&#21830;&#23478;&#21830;&#21697;',//�̼���Ʒ
	"3" => '&#21830;&#23478;&#20248;&#24800;&#21048;',//�̼��Ż�ȯ
	"16" => '&#21830;&#23478;&#27963;&#21160;',//�̼һ
	"4" => '&#22842;&#23453;&#21830;&#22478;',//�ᱦ�̳�
	"5" => '&#31215;&#20998;&#21830;&#22478;',//�����̳�
	"6" => '&#22242;&#36141;&#21830;&#22478;',//�Ź��̳�
	"7" => '&#25307;&#32856;&#20449;&#24687;',//��Ƹ��Ϣ
	"8" => '&#20108;&#25163;&#24066;&#22330;',//�����г�
	"9" => '&#23456;&#29289;',//����
	"10" => '&#25340;&#36710;',//ƴ��
	"11" => '&#20108;&#25163;&#36710;',//���ֳ�
	"12" => '&#31199;&#36710;',//�⳵
	"13" => '&#25151;&#23627;&#20986;&#31199;',//���ݳ���
	"14" => '&#20108;&#25163;&#25151;',//���ַ�
	"15" => '&#25945;&#32946;&#22521;&#35757;',//������ѵ
);
$_GET['type'] = intval($_GET['type']);
$_GET['tid'] = intval($_GET['tid']);
if($_GET['act'] == 'showqrcode'){
	include template('mapp_share:showqrcode');
}else if($_GET['act'] == 'getSignature'){
	require_once DISCUZ_ROOT.'source/plugin/mapp_share/class/wechatclient.lib.class.php';
	$wechat_client = new WeChatClient($_G['cache']['plugin']['aljwsq']['appid'], $_G['cache']['plugin']['aljwsq']['appsecret']);
    $signPackage = $wechat_client -> getJsApiSignPackage($_GET['urlstr']);
    echo json_encode($signPackage);
    exit;
}else{
	require_once 'source/plugin/aljwsq/function_core.php';
	$binduser = DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array('aljwsq_mapp_user', $_G['uid']));
	$uid = $binduser['uid'];
	$actionname = addslashes($_GET['type'].'sendshareextcredit'.intval($_GET['tid']));

	if(!lgetuseraction($uid,'mapp_share',$actionname) && $_GET['openid']){
		$sharethread = DB::fetch_first('select * from %t where tid=%d and type=%d',array('aljwsq_mapp_share_adminthread',$_GET['tid'],$_GET['type']));
		if($uid>0 && $sharethread){
			$desc = $_G['setting']['extcredits'][$sharethread['rewardcredit']]['title'].'('.$applist[$_GET['type']].$_GET['tid'].')';
			luseractionlog($uid,'mapp_share',$actionname,$sharethread['addcreditnum'],$desc);
			updatemembercount($uid, array($sharethread['rewardcredit'] => $sharethread['addcreditnum']),'','','','','&#36148;&#23376;&#20998;&#20139;&#21040;&#24494;&#20449;','&#23436;&#25104;&#20998;&#20139;&#21040;&#24494;&#20449;&#20219;&#21153;&#22870;&#21169;&#31215;&#20998;');
		}
	}else{
		if($_GET['tid'] && $_GET['type']){
			luseractionlog($uid,'mapp_share',$actionname,0,$applist[$_GET['type']].'('.$_GET['tid'].')');
		}

	}
	echo 1;
}
function ajaxGetCharSet_mapp_share($arr) {
    if(is_array($arr)){
        if (strtolower(CHARSET) == 'gbk') {
            foreach ($arr as $key => $val) {
                if(is_array($val)){
                    $pt_goods[$key] = ajaxGetCharSet_mapp_share($val);
                }else{
                    $pt_goods[$key] = diconv($val,'utf-8','gbk');
                }

            }
            return $pt_goods;
        }
        return $arr;
    } else {
        if (strtolower(CHARSET) == 'gbk') {
            return diconv($arr,'utf-8','gbk');
        }
        return $arr;
    }

}
