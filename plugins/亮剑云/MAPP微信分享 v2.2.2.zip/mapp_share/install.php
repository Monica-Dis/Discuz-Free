<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljwsq_mapp_share_adminthread` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tid` bigint(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `desc` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `url` varchar(255) NOT NULL,
  `rewardcredit` tinyint(3) NOT NULL,
  `addcreditnum` tinyint(3) NOT NULL,
  `stips` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
);
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>