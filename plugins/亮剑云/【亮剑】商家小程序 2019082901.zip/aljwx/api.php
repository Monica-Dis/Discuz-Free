<?php
define('DISABLEXSSCHECK',true);

require '../../../source/class/class_core.php';

$discuz = C::app();
$discuz->init();

loadcache('plugin');
require '../../../source/plugin/aljwx/wxBizDataCrypt.php';
$appid = $_G['cache']['plugin']['aljwx']['appid'];
$secret = $_G['cache']['plugin']['aljwx']['AppSecret'];
$js_code = $_GET['code'];
$params = array(
    'appid' => $appid,
    'secret' => $secret,
    'js_code' => $_GET['code'],
    'grant_type' => 'authorization_code'
);
if($_GET['act'] != 'paymoney'){
    //https://api.weixin.qq.com/sns/jscode2session?appid=APPID&secret=SECRET&js_code=JSCODE&grant_type=authorization_code
    $apiurl = 'https://api.weixin.qq.com/sns/jscode2session';
    $res = wx_makeRequest($apiurl, $params);
//debug($res);
    if ($res['code'] !== 200 || !isset($res['result']) || !isset($res['result'])) {
        echo json_encode(ret_message('requestTokenFailed'), true);
        exit;
    }
    if($res['code'] == 200){
        insertLog('mini_wxpay '.$res['result']);
    }
    $reqData = json_decode($res['result'], true);
}

if($_GET['act'] == 'login'){
  if (!isset($reqData['session_key'])) {
      echo json_encode(ret_message('requestTokenFailed'), true);
      exit;
  }
  $sessionKey = $reqData['session_key'];
  $signature2 = sha1(htmlspecialchars_decode($_GET['rawData']) . $sessionKey);
  if ($signature2 !== $_GET['signature']){
      echo ret_message("signNotMatch");
      exit;
  }

  $pc = new WXBizDataCrypt($appid, $sessionKey);
  $errCode = $pc->decryptData($_GET['encryptedData'], $_GET['iv'], $data);

  if ($errCode !== 0) {
      echo json_encode(ret_message(array(-8, "encryptDataNotMatch")), true);
      exit;
  }

  $wxuser = DB::result_first('select * from %t where openid=%s', array('aljwx_user', $reqData['openid']));

  if(!$wxuser){
      if(empty($_GET['username']) || empty($_GET['password'])){
          $rawData = json_decode(htmlspecialchars_decode($_GET['rawData']), true);
          $user = lwechat_register(diconv($rawData['nickName'], 'utf-8', 'gbk'), 0, 0, '', '');
  		$user['userhead'] = $rawData['avatarUrl'];
      }else{
          $result = wx_mapp_userlogin($_GET['username'], $_GET['password']);
          if($result['status'] != 1){
              echo json_encode(wx_ajaxPostCharSet(ret_message(array(-9, '�ʺŻ����벻��ȷ��'))), true);
              exit;
          }

          $username = addslashes($_GET['username']);
          $user = $result['member'];
  		$user['userhead'] = avatar($user['uid'], 'middle', true);;
      }

      DB::insert('aljwx_user', array(
          'openid' => $reqData['openid'],
          'unionid' => $reqData['unionid'],
  		'userhead' => $user['userhead'],
          'uid' => $user['uid'],
          'username' => $user['username'],
          'dateline' => TIMESTAMP
      ));
  }


  $data = json_decode($data, true);
  $session3rd = wx_randomFromDev(16);
  $data['session3rd'] = $session3rd;
  DB::insert('aljwx_session3rd', array(
      'openid' => $data['openId'],
      '3rd_key' => $session3rd,
      '3rd_value' => $sessionKey.$data['openId'],
      'dateline' => TIMESTAMP
  ));
  //cache($session3rd, $data['openId'] . $sessionKey);
  echo json_encode($data, true);
  exit;
}else if($_GET['act'] == 'paymoney') {//�ֻ���֧��
    require_once '../../../source/plugin/aljqb/class/Payment.class.php';
    require_once '../../../source/plugin/aljqb/class/Queue.class.php';
    require_once '../../../source/plugin/aljqb/class/Qbapi.class.php';
    require_once '../../../source/plugin/aljqb/class/mapp_wechatclient.lib.class.php';

    $queue = new Queue();
    $payment = new Payment();
    $qbapi = new Qbapi();
    require_once '../../../source/plugin/aljqb/function/function_core.php';
    if($_G['mobile']) {
        if($_GET["session3rd"]){
            $openid = $_GET["session3rd"];
        }else{
            $openid = getcookie('openid');
        }
    }

    $updatearray = array();
    $aljorderid = addslashes($_GET['aljorderid']);
    $order = DB::fetch_first('select * from %t where aljorderid = %s',array('aljqb_payorder',$aljorderid));
    $order['subject'] = cutstr($order['subject'],'40');
    if($order['price']+0<=0) {
        $tips = array('status'=>1,'message'=>'&#37329;&#39069;&#19981;&#24471;&#23567;&#20110;&#48;');
        echo json_encode(wx_ajaxPostCharSet($tips));
        exit;
    }
    $order['trade_mod'] = addslashes($_GET['trade_mod']);
    if(TIMESTAMP < $order['overtime']) {
        if(!$order['status']) {
            if($order['trade_mod'] == 'magapp') {//����
                $subject = $order['subject'];
                $magapp_price = $order['price'];
                $secret    = $config['magapp_secret'];
                $params_ma = array(
                    'trade_no' => $order['aljorderid'],
                    'callback' => $config['OAuth'].'source/plugin/aljqb/pay/notify_magapp.php',
                    'amount'   => $magapp_price,
                    'title'   => diconv($order['subject'],CHARSET,'UTF-8'),
                    'user_id' => $_G['uid'],
                    'to_user_id' => 0,
                    'des'    => diconv($order['subject'],CHARSET,'UTF-8'),
                    'remark' => diconv($order['subject'],CHARSET,'UTF-8'),
                    'secret' => $secret,
                );

                $ret= magapppay($params_ma);
                $unionOrderNum = $ret['data']['unionOrderNum'];
                if($unionOrderNum){
                    $updatearray['trade_mod'] = $order['trade_mod'];
                    $updatearray['transaction_id'] = $unionOrderNum;
                    $payment-> updatePayOrder($updatearray,$aljorderid);
                    $magapp_pay_config = array(
                        'money'=>$magapp_price,
                        'title'=>$subject,
                        'des'=>$subject,
                        'payWay'=>array(
                            'wallet'=>1,
                            'weixin'=>1,
                            'alipay'=>1,
                        ),
                        'orderNum'=>$order['aljorderid'],
                        'unionOrderNum'=>$unionOrderNum,
                        'type'=>"aljqb"
                    );
                    $pay_s_url = $_G['siteurl'].'plugin.php?id=aljqb&act=success'.'&out_trade_no='.$aljorderid;
                    $pay_f_url = $order['rurl'];
                    $tips = array('status'=>0,'type'=>'magapp','pay_s_url'=>$pay_s_url,'pay_f_url'=>$pay_f_url,'magapp_pay_config'=>$magapp_pay_config);
                    echo json_encode(wx_ajaxPostCharSet($tips));
                    exit;
                }
                $tips = array('status'=>0,'type'=>'magapp','url'=>$alipayurl,'unionOrderNum'=>0,'ret'=>diconv($ret["msg"],'utf-8'));
                echo json_encode(wx_ajaxPostCharSet($tips));
                exit;
            }else if($order['trade_mod'] == 'alipay') {//֧����
                $order['trade_type'] = 'mobileweb';
                $params = $payment->getPayparams($order,$_G['siteurl'],$notify_url);
                $updatearray['trade_type'] = $order['trade_type'];
                $updatearray['trade_mod'] = $order['trade_mod'];
                $payment-> updatePayOrder($updatearray,$aljorderid);
                $alipayurl = alipay($params);
                $tips = array('status'=>0,'type'=>'alipay','url'=>$alipayurl);
                echo json_encode(wx_ajaxPostCharSet($tips));
                exit;
            }else if($order['trade_mod'] == 'wxpay'){//΢��
                if($_G['mobile']) {
                    if($iswechat){
                        $order['openid'] = $openid;
                        $updatearray['openid'] = $order['openid'];
                        $updatearray['trade_type'] = $trade_type;
                        $updatearray['trade_mod'] = $order['trade_mod'];
                        $payment-> updatePayOrder($updatearray,$aljorderid);
                        $params = $payment->getPayparams($order,$_G['siteurl'],$notify_url);
                        $jsapiparameters = wxpay($params);
                        $jswxpay = json_decode($jsapiparameters,true);
                        $url = $_G['siteurl'].'plugin.php?id=aljqb&act=success'.'&out_trade_no='.$aljorderid;
                        $tips = array('status'=>0,'type'=>'wxpay','json'=>$jswxpay,'url'=>$url);
                        echo json_encode(wx_ajaxPostCharSet($tips));
                        exit;
                    }else {
                        $updatearray['trade_type'] = 'MWEB';
                        $updatearray['trade_mod'] = $order['trade_mod'];
                        $payment-> updatePayOrder($updatearray,$aljorderid);
                        $params = $payment->getPayparams($order,$_G['siteurl'],$notify_url);
                        $wxh5 = getWxh5pay($params);
                        $url = $_G['siteurl'].'plugin.php?id=aljqb&act=success'.'&out_trade_no='.$aljorderid;
                        $tips = array('status'=>0,'type'=>'wxh5pay','wxpayurl'=>$wxh5,'url'=>$url);
                        echo json_encode(wx_ajaxPostCharSet($tips));
                        exit;
                    }
                }else {
                    $updatearray['trade_type'] = 'NATIVE';
                    $updatearray['trade_mod'] = $order['trade_mod'];
                    $payment-> updatePayOrder($updatearray,$aljorderid);
                    $params = $payment->getPayparams($order,$_G['siteurl'],$notify_url);
                    $pcwxpay = getcodeurl($params);
                    $tips = array('status'=>0,'type'=>'wxpay','wxpayurl'=>$pcwxpay);
                    echo json_encode(wx_ajaxPostCharSet($tips));
                    exit;
                }

            }else if($order['trade_mod'] == 'mywallet') {//���֧��
                $queuearray = array(
                    'app_name' => $order['pluginname'],
                    'app_type' => 'yuezhifu',
                    'app_phone' => '123456789',
                    'app_ip' => '123456789',
                );
                $balancearray = array(
                    'type'=> 'take',
                    'uid'=>$_G['uid'],
                    'price' => $order['price'],
                    'orderid'=> $order['orderid'],
                    'desc'=> $str['un5'].$order['price'].$str['un7'],
                );
                $result = $qbapi->balance($queuearray,$balancearray);
                if($result['code'] == '200') {
                    if($order['status']<1){
                        $updatearray['status'] = 1;
                    }
                    if($order['paytime']<1){
                        $updatearray['paytime'] = TIMESTAMP;
                    }
                    $updatearray['trade_mod'] = $order['trade_mod'];
                    $payment->updatePayOrder($updatearray,$aljorderid);
                    $keyarray = array(
                        'aljorderid'=> $aljorderid,
                        'paytime' => $updatearray['paytime'],
                        'orderid' => $order['orderid'],
                        'key'=> $aljqbkey[$order['pluginname']][1],
                    );
                    $json = json_encode($keyarray);
                    $key = $qbapi->createKey($keyarray);
                    $postdata = array(
                        'aljorderid'=> $aljorderid,
                        'paytime' => $updatearray['paytime'],
                        'orderid' => $order['orderid'],
                        'key' => $key,
                    );
                    $status = $qbapi->postDatacurl($postdata,$order['nurl']);
                    $url = $_G['siteurl'].'plugin.php?id=aljqb&act=success'.'&out_trade_no='.$aljorderid;
                    $tips = array('status'=>0,'type'=>'mywallet','url'=>$url);
                    echo json_encode(wx_ajaxPostCharSet($tips));
                    exit;
                }else {
                    if($result['code'] == 500) {
                        $tips = array('status'=>1,'message'=>'&#20313;&#39069;&#19981;&#36275;');
                        echo json_encode(wx_ajaxPostCharSet($tips));
                    }else {
                        $tips = array('status'=>1,'message'=>$result['message']);
                        echo json_encode(wx_ajaxPostCharSet($tips));
                    }
                    exit;
                }
            }
        } else {
            $tips = array('status'=>2,'message'=>$aljmalllang['php']['tips15'],'url' => $order['rul']);
            echo json_encode(wx_ajaxPostCharSet($tips));
            exit;
        }
    }else {
        $tips = array('status'=>1,'message'=>$aljmalllang['php']['tips16']);
        echo json_encode(wx_ajaxPostCharSet($tips));
        exit;
    }
}else{
  $dataarray['code'] = $reqData['openid']?'100':'200';
  $dataarray['openId'] = $reqData['openid'];
  echo json_encode(wx_ajaxPostCharSet($dataarray));
  exit;
}

function lwechat_register($username, $return = 0, $groupid = 0,$defaultpassword,$news) {
	global $_G;
	if(!$username) {
		return;
	}
    $username = removeEmoji($username);
	loaducenter();
	$groupid = $news['fid'];
	$pwd = 'PW'.random(6);
	if($defaultpassword){
		$pwd = $defaultpassword;
	}
	$password = md5($pwd);
	$email = 'wechat_'.strtolower(random(10)).'@qq.com';

	$usernamelen = dstrlen($username);
	if($usernamelen < 4  || uc_user_checkname($username)<0) {
		$username = random(6);
	}
	if($usernamelen > 15) {
		$username = random(6);
	}

	$censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';

	if($_G['setting']['censoruser'] && @preg_match($censorexp, $username)) {
		if(!$return) {
			return lang('message', 'profile_username_protect');
		} else {
			return 'Registration failed. Please try again!';
		}
	}



	loadcache('ipctrl');
	if($_G['cache']['ipctrl']['ipregctrl']) {
		foreach(explode("\n", $_G['cache']['ipctrl']['ipregctrl']) as $ctrlip) {
			if(preg_match("/^(".preg_quote(($ctrlip = trim($ctrlip)), '/').")/", $_G['clientip'])) {
				$ctrlip = $ctrlip.'%';
				$_G['setting']['regctrl'] = $_G['setting']['ipregctrltime'];
				break;
			} else {
				$ctrlip = $_G['clientip'];
			}
		}
	} else {
		$ctrlip = $_G['clientip'];
	}

	if($_G['setting']['regctrl']) {
		if(C::t('common_regip')->count_by_ip_dateline($ctrlip, $_G['timestamp']-$_G['setting']['regctrl']*3600)) {
			if(!$return) {
				//return str_replace('{regctrl}',$_G['setting']['ipregctrltime'],lang('message', 'register_ctrl'));
			} else {
				return 'Registration failed. Please try again!';
			}
		}
	}

	$setregip = null;
	if($_G['setting']['regfloodctrl']) {
		$regip = C::t('common_regip')->fetch_by_ip_dateline($_G['clientip'], $_G['timestamp']-86400);
		if($regip) {
			if($regip['count'] >= $_G['setting']['regfloodctrl']) {
				if(!$return) {
					//return lang('message', 'register_flood_ctrl');
				} else {
					return;
				}
			} else {
				$setregip = 1;
			}
		} else {
			$setregip = 2;
		}
	}

	if($setregip !== null) {
		if($setregip == 1) {
			C::t('common_regip')->update_count_by_ip($_G['clientip']);
		} else {
			C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => 1, 'dateline' => $_G['timestamp']));
		}
	}

	$uid = uc_user_register(addslashes($username), $pwd, $email, '', '', $_G['clientip']);
	if($uid <= 0) {
		if(!$return) {
			if($uid == -1) {
				return lang('message', 'profile_username_illegal');
			} elseif($uid == -2) {
				return lang('message', 'profile_username_protect');
			} elseif($uid == -3) {
				return lang('message', 'profile_username_duplicate');
			} elseif($uid == -4) {
				return lang('message', 'profile_email_illegal');
			} elseif($uid == -5) {
				return lang('message', 'profile_email_domain_illegal');
			} elseif($uid == -6) {
				return lang('message', 'profile_email_duplicate');
			} else {
				return lang('message', 'undefined_action');
			}
		} else {
			return 'Registration failed. Please try again!';
		}
	}

	$init_arr = array('credits' => explode(',', $_G['setting']['initcredits']));
	C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);

	if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
		C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72)*3600);
		if($_G['setting']['regctrl']) {
			C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
		}
	}

	if($_G['setting']['regverify'] == 2) {
		C::t('common_member_validate')->insert(array(
			'uid' => $uid,
			'submitdate' => $_G['timestamp'],
			'moddate' => 0,
			'admin' => '',
			'submittimes' => 1,
			'status' => 0,
			'message' => '',
			'remark' => '',
		), false, true);
		manage_addnotify('verifyuser');
	}

	//ͳ��
	include_once libfile('function/stat');
	updatestat('register');
	return array(
		'uid' => $uid,
		'username' => $username,
		'password' => $pwd,
		'groupid' => $groupid,
	);
}
function removeEmoji($text) {
	//$text = preg_replace("#(\\\ue[0-9a-f]{3})#ie","",$text);
    //return $text;
	if(strtolower(CHARSET) == 'gbk'){
		$text = diconv($text,CHARSET,'UTF-8');
	}
	$clean_text = "";
	// Match Emoticons
	$regexEmoticons = '/[\x{1F600}-\x{1F64F}]/u';
	$clean_text = preg_replace($regexEmoticons, '', $text);
	// Match Miscellaneous Symbols and Pictographs
	$regexSymbols = '/[\x{1F300}-\x{1F5FF}]/u';
	$clean_text = preg_replace($regexSymbols, '', $clean_text);
	// Match Transport And Map Symbols
	$regexTransport = '/[\x{1F680}-\x{1F6FF}]/u';
	$clean_text = preg_replace($regexTransport, '', $clean_text);
	// Match Miscellaneous Symbols
	$regexMisc = '/[\x{2600}-\x{26FF}]/u';
	$clean_text = preg_replace($regexMisc, '', $clean_text);
	// Match Dingbats
	$regexDingbats = '/[\x{2700}-\x{27BF}]/u';
	$clean_text = preg_replace($regexDingbats, '', $clean_text);
	if(strtolower(CHARSET) == 'gbk'){
		$clean_text = diconv($clean_text,'UTF-8',CHARSET);
	}
	return $clean_text;
}
//��֤��¼
function wx_mapp_userlogin($username, $password, $questionid='', $answer='', $loginfield = 'username', $ip = '') {
	$return = array();

	if($loginfield == 'uid' && getglobal('setting/uidlogin')) {
		$isuid = 1;
	} elseif($loginfield == 'email') {
		$isuid = 2;
	} elseif($loginfield == 'auto') {
		$isuid = 3;
	} else {
		$isuid = 0;
	}

	if(!function_exists('uc_user_login')) {
		loaducenter();
	}
	if($isuid == 3) {
		if(!strcmp(dintval($username), $username) && getglobal('setting/uidlogin')) {
			$return['ucresult'] = uc_user_login($username, $password, 1, 0, $questionid, $answer, $ip);
		} elseif(isemail($username)) {
			$return['ucresult'] = uc_user_login($username, $password, 2, 0, $questionid, $answer, $ip);
		}
		if($return['ucresult'][0] <= 0 && $return['ucresult'][0] != -3) {
			$return['ucresult'] = uc_user_login(addslashes($username), $password, 0, 0, $questionid, $answer, $ip);
		}
	} else {

		$return['ucresult'] = uc_user_login(addslashes($username), $password, $isuid, 0, $questionid, $answer, $ip);

	}
	$tmp = array();
	$duplicate = '';
	list($tmp['uid'], $tmp['username'], $tmp['password'], $tmp['email'], $duplicate) = $return['ucresult'];
	$return['ucresult'] = $tmp;
	if($duplicate && $return['ucresult']['uid'] > 0 || $return['ucresult']['uid'] <= 0) {
		$return['status'] = 0;
		return $return;
	}

	$member = getuserbyuid($return['ucresult']['uid'], 1);
	if(!$member || empty($member['uid'])) {
		$return['status'] = -1;
		return $return;
	}
	$return['member'] = $member;
	$return['status'] = 1;
	if($member['_inarchive']) {
		C::t('common_member_archive')->move_to_master($member['uid']);
	}
	if($member['email'] != $return['ucresult']['email']) {
		C::t('common_member')->update($return['ucresult']['uid'], array('email' => $return['ucresult']['email']));
	}

	return $return;
}

/**
 * ����http����
 * @param string $url ����·��
 * @param array $params ���������������1������ʾΪPOST
 * @param int $expire ����ʱʱ��
 * @param array $extend ����α���ͷ����
 * @param string $hostIp HOST�ĵ�ַ
 * @return array    ���ص�Ϊһ������״̬��һ������
 */
function wx_makeRequest($url, $params = array(), $expire = 0, $extend = array(), $hostIp = '')
{
    if (empty($url)) {
        return array('code' => '100');
    }

    $_curl = curl_init();
    $_header = array(
        'Accept-Language: zh-CN',
        'Connection: Keep-Alive',
        'Cache-Control: no-cache'
    );
    // ����ֱ�ӷ���Ҫ����host�ĵ�ַ
    if (!empty($hostIp)) {
        $urlInfo = parse_url($url);
        if (empty($urlInfo['host'])) {
            $urlInfo['host'] = substr(DOMAIN, 7, -1);
            $url = "http://{$hostIp}{$url}";
        } else {
            $url = str_replace($urlInfo['host'], $hostIp, $url);
        }
        $_header[] = "Host: {$urlInfo['host']}";
    }

    // ֻҪ�ڶ�����������ֵ֮�󣬾���POST��
    if (!empty($params)) {
        curl_setopt($_curl, CURLOPT_POSTFIELDS, http_build_query($params));
        curl_setopt($_curl, CURLOPT_POST, true);
    }

    if (substr($url, 0, 8) == 'https://') {
        curl_setopt($_curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($_curl, CURLOPT_SSL_VERIFYHOST, FALSE);
    }
    curl_setopt($_curl, CURLOPT_URL, $url);
    curl_setopt($_curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($_curl, CURLOPT_USERAGENT, 'API PHP CURL');
    curl_setopt($_curl, CURLOPT_HTTPHEADER, $_header);

    if ($expire > 0) {
        curl_setopt($_curl, CURLOPT_TIMEOUT, $expire); // ������ʱʱ��
        curl_setopt($_curl, CURLOPT_CONNECTTIMEOUT, $expire); // �������ӳ�ʱʱ��
    }

    // ���������
    if (!empty($extend)) {
        curl_setopt_array($_curl, $extend);
    }

    $result['result'] = curl_exec($_curl);
    $result['code'] = curl_getinfo($_curl, CURLINFO_HTTP_CODE);
    $result['info'] = curl_getinfo($_curl);
    if ($result['result'] === false) {
        $result['result'] = curl_error($_curl);
        $result['code'] = -curl_errno($_curl);
    }

    curl_close($_curl);
    return $result;
}
function wx_ajaxGetCharSet($arr) {
    if(is_array($arr)){
        if (strtolower(CHARSET) == 'gbk') {
            foreach ($arr as $key => $val) {
                if(is_array($val)){
                    $pt_goods[$key] = wx_ajaxGetCharSet($val);
                }else{
                    $pt_goods[$key] = diconv($val,'utf-8','gbk');
                }

            }
            return $pt_goods;
        }
        return $arr;
    } else {
        if (strtolower(CHARSET) == 'gbk') {
            return diconv($arr,'utf-8','gbk');
        }
        return $arr;
    }

}
function wx_ajaxPostCharSet($arr) {
	if(is_array($arr)){
		if (strtolower(CHARSET) == 'gbk') {
			foreach ($arr as $key => $val) {
				if(is_array($val)){
					$pt_goods[$key] = wx_ajaxPostCharSet($val);
				}else{
					$pt_goods[$key] = diconv($val,'gbk','utf-8');
				}

			}
			return $pt_goods;
		}
		return $arr;
	} else {
		if (strtolower(CHARSET) == 'gbk') {
			return diconv($arr,'gbk','utf-8');
		}
		return $arr;
	}

}

function wx_randomFromDev($len) {
    $fp = @fopen('/dev/urandom','rb');
    $result = '';
    if ($fp !== FALSE) {
        $result .= @fread($fp, $len);
        @fclose($fp);
    }
    else
    {
        trigger_error('Can not open /dev/urandom.');
    }
    // convert from binary to string
    $result = base64_encode($result);
    // remove none url chars
    $result = strtr($result, '+/', '-_');

    return substr($result, 0, $len);
}

/**
 * ������Ϣ
 * @param $message
 * @return array
 */
function ret_message($message = "") {
    if ($message == "") return array('result'=>0, 'message'=>'');
    $ret = $message;

    if (count($ret) != 2) {
        return array('result'=>-1,'message'=>'δ֪����');
    }
    return array(
        'result'  => $ret[0],
        'message' => $ret[1]
    );
}
function insertlog($error) {
    DB::insert('aljqb_payorderlog',array(
        'error'=> $error,
        'time'=> time(),
    ));
}