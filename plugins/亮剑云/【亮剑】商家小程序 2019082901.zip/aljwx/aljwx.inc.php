<?php
/*
	Copyright (c) 2021 by dism.taobao.com
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if($_GET['act'] == 'parameter'){
    require_once DISCUZ_ROOT.'source/plugin/aljwx/class/wechatclient.lib.class.php';
    $wechat_client = new WeChatClient($_G['cache']['plugin']['aljwx']['g_appid'],$_G['cache']['plugin']['aljwx']['g_AppSecret']);
    $signPackage = $wechat_client -> getJsApiSignPackage($_GET['url']);
    echo json_encode(ajaxPostCharSet_aljwx($signPackage));
    exit;
}
function ajaxPostCharSet_aljwx($arr) {
    if(is_array($arr)){
        if (strtolower(CHARSET) == 'gbk') {
            foreach ($arr as $key => $val) {
                if(is_array($val)){
                    $pt_goods[$key] = ajaxPostCharSet_aljwx($val);
                }else{
                    $pt_goods[$key] = diconv($val,'gbk','utf-8');
                }

            }
            return $pt_goods;
        }
        return $arr;
    } else {
        if (strtolower(CHARSET) == 'gbk') {
            return diconv($arr,'gbk','utf-8');
        }
        return $arr;
    }
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>