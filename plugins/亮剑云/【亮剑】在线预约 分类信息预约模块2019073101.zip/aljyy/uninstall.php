<?php
/*
	Copyright (c) 2021 by dism.taobao.com
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//start to put your own code 
$sql = <<<EOF
DROP TABLE IF  EXISTS `pre_aljes_appointment`;
DROP TABLE IF  EXISTS `pre_aljesf_appointment`;
DROP TABLE IF  EXISTS `pre_aljesc_appointment`;
DROP TABLE IF  EXISTS `pre_aljlp_appointment`;
DROP TABLE IF  EXISTS `pre_aljcw_appointment`;
DROP TABLE IF  EXISTS `pre_aljzp_appointment`;
DROP TABLE IF  EXISTS `pre_aljzc_appointment`;
EOF;

runquery($sql);
//finish to put your own code
$finish = TRUE;
?>