<?php
/*
	Copyright (c) 2021 by dism.taobao.com
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$finish = TRUE;
?>