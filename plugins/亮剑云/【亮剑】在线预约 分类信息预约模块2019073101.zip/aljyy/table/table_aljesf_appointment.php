<?php
/*
 * 作�?：亮�?
 * 联系DISM.TAOBAO.COM
 *
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_aljesf_appointment extends discuz_table
{
	public function __construct() {

		$this->_table = 'aljesf_appointment';
		$this->_pk    = 'id';

		parent::__construct(); /*dism �� taobao �� com*/
	}
	public function update_state_by_id($id) {
        DB::query('update %t set state=1 where id=%d', array($this->_table, $id));
    }
}
//From: DisM. taobao. Com
?>