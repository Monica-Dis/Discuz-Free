<?php
/*
	Copyright (c) 2021 by dism.taobao.com
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljesf_appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `buid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljesc_appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `buid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljes_appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `buid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljlp_appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `buid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljcw_appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `buid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzp_appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `buid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljzc_appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `buid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`)
);
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>