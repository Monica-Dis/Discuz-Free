<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pluginidarray = array('aljes','aljlp','aljesf','aljesc','aljpx','aljzp','aljzc','aljpc','aljcw','aljbd');
$_GET=dhtmlspecialchars($_GET);
$pluginid = isset($_GET['pluginid']) ? $_GET['pluginid'] : '';
$pluginid = !in_array($pluginid, $pluginidarray) ? '' : $pluginid;
if(!$pluginid){
	showmessage(lang('plugin/aljyy','This_page_does_not_exist'));
}
$is_plugin = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin',$pluginid));
if(!$is_plugin){
	showmessage('&#26242;&#26410;&#23433;&#35013;&#27492;&#25554;&#20214;&#65281;');
}
$settings=C::t('#'.$pluginid.'#'.$pluginid.'_setting')->range();
if($_GET['act']=='appointment'){
	$user=C::t('#'.$pluginid.'#'.$pluginid)->fetch($_GET['lid']);
	if (submitcheck('submit')) {
		if (empty($_GET['dateline'])) {
			if($_G['mobile']){
				echo "<script>parent.tips('".lang('plugin/aljyy','Time_must_choose')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljyy','Time_must_choose'));
			}
        }
		if (empty($_GET['contact_person'])) {
			if($_G['mobile']){
				echo "<script>parent.tips('".lang('plugin/aljyy','Contacts_must_be_filled_out')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljyy','Contacts_must_be_filled_out'));
			}
        }
		if (empty($_GET['tel'])) {
			if($_G['mobile']){
				echo "<script>parent.tips('".lang('plugin/aljyy','Phone_number_to_fill_in')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljyy','Phone_number_to_fill_in'));
			}
        }
		
		C::t('#aljyy#'.$pluginid.'_appointment')->insert(array(
			'lid'=>$_GET['lid'],
			'uid'=>$_G['uid'],
			'buid'=>$user['uid'],
			'name'=>$_G['username'],
			'dateline'=>$_GET['dateline'],
			'tel'=>$_GET['tel'],
			'contact_person'=>$_GET['contact_person'],
			'message'=>$_GET['message'],
			'sex'=>$_GET['sex'],
			'title'=>$user['title'],
			'timestamp'=>TIMESTAMP,
		));
		$mes_app='&#24744;&#26377;&#19968;&#26465;'.$_G['cache']['plugin'][$pluginid]['daohang'].'&#30340;&#39044;&#32422;&#20449;&#24687;&#44;&#35831;&#23613;&#24555;&#26597;&#25910;&#32;<a href="plugin.php?id=aljgl&act=appointment_list&pluginid='.$pluginid.'" target="_blank">&#28857;&#20987;&#26597;&#30475;</a>';
		notification_add($user['uid'], 'system',$mes_app);
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".lang('plugin/aljyy','Appointment_success')."',function(){parent.location.href='plugin.php?id=".$pluginid."&act=view&lid=".$_GET['lid']."';});</script>";
			exit;
		}else{
			echo '<script>parent.showDialog("'.lang('plugin/aljyy','Appointment_success').'","right","",function(){parent.location.href=parent.location.href},0)</script>';
			exit;
		}
	}else{
		if(!$_G['uid']){
			showmessage(lang('plugin/aljyy','aljyy_1'), '', array(), array('login' => true));
		}
		if($user['uid'] == $_G['uid']){
			showmessage(lang('plugin/aljyy','Can_not_apply_for'));
		}
		
		include template('aljyy:appointment');
	}
	
}
//require DISCUZ_ROOT.'./source/plugin/aljyy/api/aljyy_'.$pluginid.'.php';
?>