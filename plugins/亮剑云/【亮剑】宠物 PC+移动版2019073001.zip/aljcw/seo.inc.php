<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$pluginid='aljcw';
$lang = array_merge($lang, $scriptlang[$pluginid]);

if(empty($_GET['ac'])) {

	if(!submitcheck('seosubmit')) {
		echo '<script type="text/javascript">
		function insertContent(obj, text) {
			var obj = obj.parentNode.parentNode.firstChild.lastChild;
			selection = document.selection;
			obj.focus();
			if(!isUndefined(obj.selectionStart)) {
				var opn = obj.selectionStart + 0;
				obj.value = obj.value.substr(0, obj.selectionStart) + text + obj.value.substr(obj.selectionEnd);
			} else if(selection && selection.createRange) {
				var sel = selection.createRange();
				sel.text = text;
				sel.moveStart(\'character\', -strlen(text));
			} else {
				obj.value += text;
			}
		}
		</script>';

		$aljcw_seo = dunserialize($_G['setting']['aljcw_seo']);
		$page = array(
			'index' => array('bbname'),
			'list' => array('bbname', 'pay','cat','cat1','region','region2','region3','wanted','identity'),
			'view' => array('bbname', 'subject', 'message','pay','cat','cat1','region','region2','region3','wanted'),
			'quanbu' => array('bbname', 'username'),
			'post' => array('bbname'),
			'edit' => array('bbname'),
			'member' => array('bbname', 'username'),
			'collection' => array('bbname', 'username'),
			'adminlp' => array('bbname', 'username'),
			'adminuser' => array('bbname', 'username'),
			'adminreflash' => array('bbname', 'username'),
			'admintop' => array('bbname', 'username'),
			'attes' => array('bbname', 'username'),
			'appointment' => array('bbname', 'username'),
		);
		showformheader('plugins&operation=config&identifier='.$pluginid.'&pmod=seo');
		showtableheader();
		foreach($page as $key => $value) {
			$code = cplang('code');
			foreach($value as $v) {
				$code .= '<a onclick="insertContent(this, \'{'.$v.'}\');return false;" href="javascript:;" title="'.cplang($v).'">{'.cplang($v).'}</a>';
			}
			showtitle('page_'.$key);
			showsetting('seotitle', 'aljcw_seo['.$key.'][seotitle]', $aljcw_seo[$key]['seotitle'], 'text', '', 0, $code);
			showsetting('seokeywords', 'aljcw_seo['.$key.'][seokeywords]', $aljcw_seo[$key]['seokeywords'], 'text', '', 0, $code);
			showsetting('seodescription', 'aljcw_seo['.$key.'][seodescription]', $aljcw_seo[$key]['seodescription'], 'text', '', 0, $code);
		}
		showsubmit('seosubmit');
		showtablefooter();/*Dism-taobao��com*/
		showformfooter();
		
	} else {
		$aljcw_seo = serialize($_GET['aljcw_seo']);
		DB::query("REPLACE INTO ".DB::table('common_setting')." (skey, svalue) VALUES ('aljcw_seo', '$aljcw_seo')");
		updatecache('setting');

		cpmsg('seo_update_succeed', 'action=plugins&operation=config&identifier='.$pluginid.'&pmod=seo', 'succeed');
	}
}
//From: Dism_taobao_com
?>