<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(!file_exists("source/plugin/aljcw/template/com/admin.php")){
	echo lang('plugin/aljcw','admin_8');
	exit;
}
require_once libfile('function/discuzcode');
require_once 'source/plugin/aljcw/function/function_core.php';
include_once libfile('function/editor');
$config = array();
foreach($pluginvars as $key => $val) {
	$config[$key] = $val['value'];	
}
$pluginid='aljcw';
$typelist = explode ("\n", str_replace ("\r", "", $config ['pinpai']));
foreach($typelist as $key=>$value){
	$arr=explode('=',$value);
	$types[$arr[0]]=$arr[1];
}
$wanted = explode ("\n", str_replace ("\r", "", $config ['gongqiu']));
foreach($wanted as $key=>$value){
	$arr=explode('=',$value);
	$gq_wanted[$arr[0]]=$arr[1];
}
$sex=array('1'=>lang('plugin/aljcw','sex_1'),'2'=>lang('plugin/aljcw','sex_2'),'3'=>lang('plugin/aljcw','sex_3'));
$regions = C::t('#aljcw#aljcw_region')->range();
$shengming=str_replace ("{sitename}", $_G['setting']['bbname'], $config ['shengming']);
$vaccine=array('1'=>'&#49;&#38024;','2'=>'&#50;&#38024;','3'=>'&#51;&#38024;','4'=>'&#27809;&#25171;&#30123;&#33495;');
$identity=array('1'=>'&#20010;&#20154;','2'=>'&#21830;&#23478;');
$insect=array('1'=>'&#24050;&#39537;&#34411;','2'=>'&#26410;&#39537;&#34411;');
$settings=C::t('#aljcw#aljcw_setting')->range();
if($_GET['act']=='edit'){
	if(submitcheck('formhash')){
		
		if (empty($_GET['title'])) {
            showerror(lang('plugin/aljcw','aljcw_2'));
        }
        for ($i = 1; $i <= 8; $i++) {
            $pic = 'pic' . $i;
            if ($_FILES[$pic]['tmp_name']) {
                $picname = $_FILES[$pic]['name'];
                $picsize = $_FILES[$pic]['size'];
				if ($picsize/1024>$config['img_size']) {
					showerror(lang('plugin/aljcw','aljcw_26').$config['img_size'].'K');
				}
                if ($picname != "") {
                    $type = strtolower(strrchr($picname, '.'));
                    if ($type != ".gif" && $type != ".jpg" && $type != ".png") {
                        showerror(lang('plugin/aljcw','aljcw_3'));
                    }
                    $rand = rand(100, 999);
                    $pics = date("YmdHis") . $rand . $type;
                    $img_dir = 'source/plugin/aljcw/images/logo/';
                    if (!is_dir($img_dir)) {
                        mkdir($img_dir);
                    }
                    $$pic = $img_dir . $pics;
                    if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
                        $imageinfo = getimagesize($$pic);
                        $w64 = $imageinfo[0] < 64 ? $imageinfo[0] : 64;
                        $h64 = $imageinfo[1] < 64 ? $imageinfo[1] : 64;

                        $w640 = $imageinfo[0] < 640 ? $imageinfo[0] : 640;
                        $h480 = $imageinfo[1] < 480 ? $imageinfo[1] : 480;

						$w140 = $imageinfo[0] < 140 ? $imageinfo[0] : 140;
                        $h100 = $imageinfo[1] < 100 ? $imageinfo[1] : 100;

						img2thumb($$pic, $$pic . '.140x100.jpg', $w140, $h100);
                        img2thumb($$pic, $$pic . '.64x64.jpg', $w64, $h64);
                        img2thumb($$pic, $$pic . '.640x480.jpg', $w640, $h480);
                        @unlink($_FILES[$pic]['tmp_name']);
                    }
                }
            }
        }


        $insertarray = array(
            'sex' => $_GET['sex'],
            'title' => $_GET['title'],
            'pos' => $_GET['pos'],
            'pos1' => $_GET['pos1'],
            'qq' => $_GET['qq'],
            'wanted' => $_GET['wanted'],
            'lxr' => $_GET['lxr'],
            'zujin' => $_GET['zujin'],
            'content' => $_GET['content'],
            
            'region' => $_GET['region'],
            'region1' => $_GET['region1'],
            'region2' => $_GET['region2'],
            'region3' => $_GET['region3'],
            'contact' => $_GET['contact'],
            'age' => $_GET['age'],
            'identity' => $_GET['identity'],
            'vaccine' => $_GET['vaccine'],
            'insect' => $_GET['insect'],
            'weight' => $_GET['weight'],
            'number' => $_GET['number'],
            
            'updatetime' => TIMESTAMP,
        );
        for ($i = 1; $i <= 8; $i++) {
            $pic = 'pic' . $i;
            if ($$pic) {
                if (empty($$pic)) {
                    $$pic = $_GET[$pic];
                }
                $insertarray[$pic] = $$pic;
            }
        }
        C::t('#aljcw#aljcw')->update($_GET['lid'], $insertarray);
        C::t('#aljcw#aljcw_user')->update_updatecount_by_uid($_G['uid']);
       
		cpmsg(lang('plugin/aljcw','admin_1'), 'action=plugins&operation=config&identifier='.$pluginid.'&do='.$_GET['do'].'&pmod=admin', 'succeed');
	}else{
		$rs = C::t('#aljcw#aljcw_region')->fetch_all_by_upid(0);
        $lp = C::t('#aljcw#aljcw')->fetch($_GET['lid']);
        $pos = C::t('#aljcw#aljcw_position')->fetch_all_by_upid(0);
		if ($lp['pos']) {
            $prs = C::t('#aljcw#aljcw_position')->fetch_all_by_upid($lp['pos']);
        }
        if ($lp['region']) {
            $rrs = C::t('#aljcw#aljcw_region')->fetch_all_by_upid($lp['region']);
        }
		include template('aljcw:edit');
	}
}else if($_GET['act']=='commentlist'){
		$currpage=$_GET['page']?$_GET['page']:1;
		$perpage=10;
		$start=($currpage-1)*$perpage;
		$num=C::t('#aljcw#aljcw_comment')->count_by_bid_all($_GET['lid']);
		$commentlist=C::t('#aljcw#aljcw_comment')->fetch_all_by_bid_page($_GET['lid'],$start,$perpage);
		$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&identifier=aljcw&do='.$_GET['do'].'&pmod=admin&act=commentlist&lid='.$_GET['lid'], 0, 11, false, false);
		include template('aljcw:admincommentlist');
}else if($_GET['act']=='deletecomment'){
		C::t('#aljcw#aljcw_comment')->delete($_GET['cid']);
		$currpage=$_GET['page']?$_GET['page']:1;
		$perpage=10;
		$num=C::t('#aljcw#aljcw_comment')->count_by_bid_all($_GET['lid']);
		$commentlist=C::t('#aljcw#aljcw_comment')->fetch_all_by_bid_page($_GET['lid'],$start,$perpage);
		$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&identifier=aljcw&do='.$_GET['do'].'&pmod=admin&act=commentlist&lid='.$_GET['lid'], 0, 11, false, false);
		include template('aljcw:admincommentlist');
}else{
	if($config['isreview']){
		include template('aljcw:admin_nav');
	}else{
		$_GET['state']='audited';
	}
	
	if($_GET['state']=='audited'){
		if(!submitcheck('submit')) {
			showformheader('plugins&operation=config&identifier='.$pluginid.'&do='.$_GET['do'].'&pmod=admin&page='.$_GET['page']."&search=".$_GET['search']."&state=".$_GET['state']);
			showtableheader('<input type="text" name="search" value="'.$_GET['search'].'"><input type="submit" >');
			showsubtitle(array('',lang('plugin/aljcw','admin_2'),lang('plugin/aljcw','admin_3'), lang('plugin/aljcw','admin_4'),lang('plugin/aljcw','admin_5'),lang('plugin/aljcw','admin_6')));
			echo '<script>disallowfloat = "newthread";</script>';
			$currpage=$_GET['page']?$_GET['page']:1;
			$perpage=10;
			$start=($currpage-1)*$perpage;
			$con=" where state=0";
			if($_GET['search']){
				$search='%' . addcslashes($_GET['search'], '%_') . '%';
				$con.=" and title like '$search'";
			}
			$num=DB::result_first("SELECT count(*) FROM ".DB::table('aljcw')." $con");
			
			$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT."?action=plugins&operation=config&identifier=".$pluginid."&do=".$_GET['do']."&pmod=admin&state=audited&search=".$_GET['search'], 0, 10, false, false);
			$query = DB::query("SELECT * FROM ".DB::table('aljcw')." $con ORDER BY id desc limit $start,$perpage");
			while($row = DB::fetch($query)) {
				if($row[tuijian]){
					$che[$row[id]]='checked="checked"';
				}
				$start=date('Y-m-d H:i:s',$row['addtime']);
				$end=date('Y-m-d H:i:s',$row['updatetime']);
				showtablerow('', array('', 'class="td_m"', 'class="td_k"', 'class="td_l"','class="td_l"','class="td_l"'), array(
								"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$row[id]\"><input type=\"hidden\" value=\"$row[id]\" name=\"myid[]\" >",	
								'<a href="plugin.php?id=aljcw&act=view&lid='.$row[id].'" target="_blank">'.$row['title'].'</a>',	
								$start,	
								$end,		
								$row['zujin']>0?$row['zujin']:lang('plugin/aljcw','aljcw_23'),			
								'<input class="checkbox" type="checkbox" name="tuijian['.$row[id].']" '.$che[$row[id]].' value="1">&nbsp;&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$pluginid.'&do='.$_GET['do'].'&pmod=admin&act=edit&lid='.$row[id].'&uid='.$row[uid].'">'.lang('plugin/aljcw','admin_7').'</a> <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=aljcw&do='.$_GET['do'].'&pmod=admin&act=commentlist&lid='.$row[id].'" onclick="showWindow(\'edit\',this.href)">'.lang('plugin/aljcw','aljcw_32').'</a>',		
								));
				
			}
			
			showsubmit('submit', 'submit', 'del','',$paging);
			showtablefooter();/*Dism-taobao��com*/
			showformfooter();
			
			
		}else{
			//debug($_POST);
			if(is_array($_POST['delete'])) {
				foreach($_POST['delete'] as $id) {
					$user=C::t('#aljcw#aljcw')->fetch($id);
					for ($i = 1; $i <= 8; $i++) {
						$pic = 'pic' . $i;
						if ($user[$pic]) {
							unlink($user[$pic]);
							unlink($user[$pic].'.64x64.jpg');
							unlink($user[$pic].'.640x480.jpg');
						}
					}
					C::t('#aljcw#aljcw')->delete($id);
				}
			}
			
			foreach($_POST['myid'] as $id) {
				DB::update('aljcw',array('tuijian'=>$_POST['tuijian'][$id]),'id='.$id);
			}
			
			cpmsg(lang('plugin/aljcw','admin_1'), 'action=plugins&operation=config&identifier='.$pluginid.'&do='.$_GET['do'].'&pmod=admin&page='.$_GET['page']."&state=".$_GET['state'], 'succeed');
		}
	}else{
		if(!submitcheck('submit')&&!submitcheck('del_submit')) {
			showformheader('plugins&operation=config&identifier='.$pluginid.'&do='.$_GET['do'].'&pmod=admin&page='.$_GET['page']."&search=".$_GET['search']);
			showtableheader('<input type="text" name="search" value="'.$_GET['search'].'"><input type="submit" >');
			showsubtitle(array('',lang('plugin/aljcw','admin_2'),lang('plugin/aljcw','admin_3'), lang('plugin/aljcw','admin_4'),lang('plugin/aljcw','admin_5'),lang('plugin/aljcw','admin_15')));
			echo '<script>disallowfloat = "newthread";</script>';
			$currpage=$_GET['page']?$_GET['page']:1;
			$perpage=10;
			$start=($currpage-1)*$perpage;
			$con=" where state=1";
			if($_GET['search']){
				$search='%' . addcslashes($_GET['search'], '%_') . '%';
				$con=" and title like '$search'";
			}
			$num=DB::result_first("SELECT count(*) FROM ".DB::table('aljcw')." $con");
			
			$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT."?action=plugins&operation=config&identifier=".$pluginid."&do=".$_GET['do']."&pmod=admin&search=".$_GET['search'], 0, 10, false, false);
			$query = DB::query("SELECT * FROM ".DB::table('aljcw')." $con ORDER BY id desc limit $start,$perpage");
			while($row = DB::fetch($query)) {
				if($row[tuijian]){
					$che[$row[id]]='checked="checked"';
				}
				$start=date('Y-m-d H:i:s',$row['addtime']);
				$end=date('Y-m-d H:i:s',$row['updatetime']);
				showtablerow('', array('', 'class="td_m"', 'class="td_k"', 'class="td_l"','class="td_l"','class="td_l"'), array(
								"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$row[id]\"><input type=\"hidden\" value=\"$row[id]\" name=\"myid[]\" >",	
								'<a href="plugin.php?id=aljcw&act=view&lid='.$row[id].'" target="_blank">'.$row['title'].'</a>',	
								$start,	
								$end,		
								$row['zujin']>0?$row['zujin']:lang('plugin/aljcw','aljcw_23'),			
								'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$pluginid.'&do='.$_GET['do'].'&pmod=admin&act=edit&lid='.$row[id].'&uid='.$row[uid].'">'.lang('plugin/aljcw','admin_7').'</a>',		
								));
				
			}
			
			showsubmit('submit', lang('plugin/aljcw','admin_16'), '<input type="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" class="checkbox" id="chkallGnMF" name="chkall"><label for="chkallGnMF">'.lang('plugin/aljcw','admin_17').'</label>','<input type="submit" value="'.lang('plugin/aljcw','admin_18').'" name="del_submit" class="btn"/>','',$paging);
			showtablefooter();/*Dism-taobao��com*/
			showformfooter();
			
			
		}else{
			//debug($_POST);
			if(is_array($_POST['delete'])) {
				foreach($_POST['delete'] as $id) {
					$user=C::t('#aljcw#aljcw')->fetch($id);
					if(submitcheck('del_submit')){
						for ($i = 1; $i <= 8; $i++) {
							$pic = 'pic' . $i;
							if ($user[$pic]) {
								unlink($user[$pic]);
								unlink($user[$pic].'.64x64.jpg');
								unlink($user[$pic].'.640x480.jpg');
							}
						}
						if($user['tid']){
							DB::update('forum_post', array('invisible'=>'-1'), "tid=".$user['tid']);
							DB::update('forum_thread', array('displayorder'=>'-1'), "tid=".$user['tid']);
						}
						C::t('#aljcw#aljcw')->delete($id);
					}else{
						if (file_exists("source/plugin/aljcw/template/com/tongbu.php")&&$config['isreview']) {
							$_GET['wanted']=$user['wanted'];
							$_GET['title']=$user['title'];
							$_GET['zufangtype']=$user['zufangtype'];
							$_GET['new']=$user['new'];
							$_GET['contact']=$user['contact'];
							$_GET['zujin']=$user['zujin'];
							$_GET['qq']=$user['qq'];
							$_GET['lxr']=$user['lxr'];
							$_GET['region1']=$user['region1'];
							$_GET['region']=$user['region'];
							$_GET['region2']=$user['region2'];
							$_GET['content']=$user['content'];
							$_G['uid']=$user['uid'];
							$_G['clientip']=$user['clientip'];
							$insertid=$user['id'];
							include 'source/plugin/aljcw/template/com/tongbu.php';
						}
						DB::update('aljcw',array('state'=>0),'id='.$id);
						unset($str);
						unset($imgs);
					}
				}
			}
			cpmsg(lang('plugin/aljcw','admin_1'), 'action=plugins&operation=config&identifier='.$pluginid.'&do='.$_GET['do'].'&pmod=admin&page='.$_GET['page'], 'succeed');
		}
	}
}
function showmsg($msg,$close){
	if($close){
		$str="parent.hideWindow('$close');";
	}else{
		$str="parent.location=parent.location;";
	}
	include template('aljcw:showmsg');
	exit;
}
function showerror($msg){
	include template('aljcw:showerror');
	exit;
}
function img2thumb($src_img, $dst_img, $width = 75, $height = 75, $cut = 0, $proportion = 0)
{
    if(!is_file($src_img))
    {
        return false;
    }
    $ot = fileext($dst_img);
    $otfunc = 'image' . ($ot == 'jpg' ? 'jpeg' : $ot);
    $srcinfo = getimagesize($src_img);
    $src_w = $srcinfo[0];
    $src_h = $srcinfo[1];
    $type  = strtolower(substr(image_type_to_extension($srcinfo[2]), 1));
    $createfun = 'imagecreatefrom' . ($type == 'jpg' ? 'jpeg' : $type);

    $dst_h = $height;
    $dst_w = $width;
    $x = $y = 0;

    if(($width> $src_w && $height> $src_h) || ($height> $src_h && $width == 0) || ($width> $src_w && $height == 0))
    {
        $proportion = 1;
    }
    if($width> $src_w)
    {
        $dst_w = $width = $src_w;
    }
    if($height> $src_h)
    {
        $dst_h = $height = $src_h;
    }

    if(!$width && !$height && !$proportion)
    {
        return false;
    }
    if(!$proportion)
    {
        if($cut == 0)
        {
            if($dst_w && $dst_h)
            {
                if($dst_w/$src_w> $dst_h/$src_h)
                {
                    $dst_w = $src_w * ($dst_h / $src_h);
                    $x = 0 - ($dst_w - $width) / 2;
                }
                else
                {
                    $dst_h = $src_h * ($dst_w / $src_w);
                    $y = 0 - ($dst_h - $height) / 2;
                }
            }
            else if($dst_w xor $dst_h)
            {
                if($dst_w && !$dst_h)  
                {
                    $propor = $dst_w / $src_w;
                    $height = $dst_h  = $src_h * $propor;
                }
                else if(!$dst_w && $dst_h)  
                {
                    $propor = $dst_h / $src_h;
                    $width  = $dst_w = $src_w * $propor;
                }
            }
        }
        else
        {
            if(!$dst_h)  
            {
                $height = $dst_h = $dst_w;
            }
            if(!$dst_w)  
            {
                $width = $dst_w = $dst_h;
            }
            $propor = min(max($dst_w / $src_w, $dst_h / $src_h), 1);
            $dst_w = (int)round($src_w * $propor);
            $dst_h = (int)round($src_h * $propor);
            $x = ($width - $dst_w) / 2;
            $y = ($height - $dst_h) / 2;
        }
    }
    else
    {
        $proportion = min($proportion, 1);
        $height = $dst_h = $src_h * $proportion;
        $width  = $dst_w = $src_w * $proportion;
    }

    $src = $createfun($src_img);
    $dst = imagecreatetruecolor($width ? $width : $dst_w, $height ? $height : $dst_h);
    $white = imagecolorallocate($dst, 255, 255, 255);
    imagefill($dst, 0, 0, $white);

    if(function_exists('imagecopyresampled'))
    {
        imagecopyresampled($dst, $src, $x, $y, 0, 0, $dst_w, $dst_h, $src_w, $src_h);
    }
    else
    {
        imagecopyresized($dst, $src, $x, $y, 0, 0, $dst_w, $dst_h, $src_w, $src_h);
    }
    $otfunc($dst, $dst_img);
    imagedestroy($dst);
    imagedestroy($src);
    return true;
}
//From: Dism��taobao��com
?>