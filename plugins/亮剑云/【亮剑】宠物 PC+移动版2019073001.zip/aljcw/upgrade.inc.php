<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql ="ALTER TABLE ".DB::table('aljcw')." CHANGE `wanted` `wanted` TINYINT( 3 ) NOT NULL " ;
if(DB::query($sql,'SILENT')){print('CHANGE `wanted` `wanted` succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljcw_toplog')." ADD `status` TINYINT( 3 ) NOT NULL " ;
if(DB::query($sql,'SILENT')){print('add status succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljcw')." ADD `age` int NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add age succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljcw')." ADD `identity` int NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add identity succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljcw')." ADD `vaccine` int NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add vaccine succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljcw')." ADD `insect` int NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add insect succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljcw')." ADD `weight` DECIMAL( 10, 2 ) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add weight succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljcw')." ADD `number` int NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add number succeed!<br>');}
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljcw_setting')." (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `a` varchar(255) NOT NULL,
  `b` varchar(255) NOT NULL,
  `c` text NOT NULL,
  `d` int(11) NOT NULL,
  `e` int(11) NOT NULL,
  PRIMARY KEY (`key`)
)";
if(DB::query($sql,'SILENT')){print('create table `aljcw_setting` succeed!<br>');}
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljcw_collection')." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
);";
if(DB::query($sql,'SILENT')){print('create table `aljcw_collection` succeed!<br>');}
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljcw_attestation')." (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `gongsiname` varchar(255) NOT NULL,
  `mendianname` varchar(255) NOT NULL,
  `num` bigint(20) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `sign` tinyint(4) NOT NULL,
  PRIMARY KEY  (`id`)
);";
if(DB::query($sql,'SILENT')){print('create table `aljcw_attestation` succeed!<br>');}
echo '<br/>repair succeed';
?>