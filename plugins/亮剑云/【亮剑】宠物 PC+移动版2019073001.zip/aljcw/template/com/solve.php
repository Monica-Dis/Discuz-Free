<?php

/*
 * DisM!Ӧ������(dism.taobao.com)
 * QQȺ: 778390776
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (empty($_GET['lid'])) {
	tips_mes(lang('plugin/aljcw','aljcw_10'));
}

if($_GET['formhash'] == formhash()){
	$user=C::t('#aljcw#aljcw')->fetch($_GET['lid']);
	if($_G['mobile']){
		if (submitcheck('submit')) {
			if($_GET['solve']=='re'){
				C::t('#aljcw#aljcw')->update($_GET['lid'], array('solve'=>'0'));
				tips_mes(lang('plugin/aljcw','The_re_release_of_success'),'plugin.php?id=aljcw&act=member');
			}else{
				C::t('#aljcw#aljcw')->update($_GET['lid'], array('solve'=>'1'));
				tips_mes(lang('plugin/aljcw','To_get_success!'),'plugin.php?id=aljcw&act=member');
			}
		}else{
			if($_GET['re']=='1'){
				$url='plugin.php?id=aljcw&act=solve&lid='.$_GET['lid'].'&solve=re';
			}else{
				$url='plugin.php?id=aljcw&act=solve&lid='.$_GET['lid'];
			}
			include template('aljcw:state');
		}
	}else{
		if($_GET['solve']=='re'){
			C::t('#aljcw#aljcw')->update($_GET['lid'], array('solve'=>'0'));
			tips_mes(lang('plugin/aljcw','The_re_release_of_success'),'plugin.php?id=aljcw&act=member');
		}else{
			C::t('#aljcw#aljcw')->update($_GET['lid'], array('solve'=>'1'));
			tips_mes(lang('plugin/aljcw','To_get_success!'),'plugin.php?id=aljcw&act=member');
		}
	}
}
//From: Dism��taobao��com
?>