<?php

/*
 * DisM!Ӧ������(dism.taobao.com)
 * QQȺ: 778390776
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (getuserprofile('extcredits' . $config['releaseextcredit']) < $config['releasepay'] && $config['releaseextcredit']) {
	if($_G['mobile']){
		if($mobile_integral_recharge){
			echo "<script>parent.tips('".'&#26412;&#27425;&#25805;&#20316;&#38656;&#35201;&#28040;&#32791;'.$config['releasepay'].$_G['setting']['extcredits'][$config['releaseextcredit']]['title'].','.$_G['setting']['extcredits'][$config['releaseextcredit']]['title'] . lang('plugin/aljcw','top_1').$aljcwlang['php']['Jumping_up_page']."',function(){parent.location.href='".$mobile_integral_recharge."';});</script>";
		}else{
			echo "<script>parent.tips('".'&#26412;&#27425;&#25805;&#20316;&#38656;&#35201;&#28040;&#32791;'.$config['releasepay'].$_G['setting']['extcredits'][$config['releaseextcredit']]['title'].','.$_G['setting']['extcredits'][$config['releaseextcredit']]['title'] . lang('plugin/aljcw','top_1')."','');</script>";
		}
		exit;
	}else{
		showerror('&#26412;&#27425;&#25805;&#20316;&#38656;&#35201;&#28040;&#32791;'.$config['releasepay'].$_G['setting']['extcredits'][$config['releaseextcredit']]['title'].','.$_G['setting']['extcredits'][$config['releaseextcredit']]['title'] . lang('plugin/aljcw','top_1').$pc_integral_recharge);
	}
}
updatemembercount($_G['uid'], array($config['releaseextcredit'] => '-' .$config['releasepay']));
?>