<?php
$r_pay=explode('|',$config['r_pay']);
if (submitcheck('formhash')) {
	
	if ($_FILES['pic']['tmp_name']) {
		$picname = $_FILES['pic']['name'];
		$picsize = $_FILES['pic']['size'];
		if ($picsize/1024>$config['img_size']) {
			//showerror('&#19978;&#20256;&#22270;&#29255;&#19981;&#33021;&#36229;&#36807;'.$config['img_size'].'K');
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('&#19978;&#20256;&#22270;&#29255;&#19981;&#33021;&#36229;&#36807;".$config['img_size']."K','');</script>";
				exit;
			}else{
				showerror('&#19978;&#20256;&#22270;&#29255;&#19981;&#33021;&#36229;&#36807;'.$config['img_size'].'K');
			}
		}
		if ($picname != "") {
			$type = strtolower(strrchr($picname, '.'));
			if ($type != ".gif" && $type != ".jpg" && $type != ".png"  && $type != ".jpeg") {
				//showerror('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#103;&#105;&#102;&#32;&#46;&#112;&#110;&#103;&#26684;&#24335;&#30340;&#22270;&#29255;');
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#103;&#105;&#102;&#32;&#46;&#112;&#110;&#103;&#26684;&#24335;&#30340;&#22270;&#29255;','');</script>";
					exit;
				}else{
					showerror('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#103;&#105;&#102;&#32;&#46;&#112;&#110;&#103;&#26684;&#24335;&#30340;&#22270;&#29255;');
				}
			}
			$rand = rand(100, 999);
			$pics = date("YmdHis") . $rand . $type;
			$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
			if (!is_dir($img_dir)) {
				mkdir($img_dir);
			}
			$$pic = $img_dir . $pics;
			if (@copy($_FILES['pic']['tmp_name'], $$pic) || @move_uploaded_file($_FILES['pic']['tmp_name'], $$pic)) {
				$imageinfo = getimagesize($$pic);
				@unlink($_FILES['pic']['tmp_name']);
			}
		}
	}
}
if($_GET['pic'] && $_G['mobile']){
	$rand = rand(100, 999);
	$pics = date("YmdHis") . $rand . '.jpg';
	$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
	if (!is_dir($img_dir)) {
		mkdir($img_dir);
	}
	$$pic = $img_dir . $pics;
	
	$logo = file_put_contents($$pic,file_get_contents($_GET['pic']));
	
	if ($logo) {
		$imageinfo = getimagesize($$pic);
		if($settings['iswatermark']['value']){
			$image->Watermark(DISCUZ_ROOT.'./'.$$pic,'', 'forum');
		}
	}
}
if($_G['mobile'] && $_GET['pic1']){
	$rand = rand(100, 999);
	$pics = date("YmdHis") . $rand . '.jpg';
	$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
	if (!is_dir($img_dir)) {
		mkdir($img_dir);
	}
	$$pic = $img_dir . $pics;
	
	$logo = file_put_contents($$pic,file_get_contents($_GET['pic1']));
	
	if ($logo) {
		$imageinfo = getimagesize($$pic);
		if($settings['iswatermark']['value']){
			$image->Watermark(DISCUZ_ROOT.'./'.$$pic,'', 'forum');
		}
	}
}
if($_GET['form']=='shenfen'){
	if (submitcheck('formhash')) {
		$rz2=C::t('#aljcw#aljcw_attestation')->fetch_uid_type_sign($_G['uid'],'2');
		if($rz2){
			C::t('#aljcw#aljcw_attestation')->delete($rz2['id']);
		}
		$insertarray = array(
			'type' => '1',
			'username' => $_G['username'],
			'uid' => $_G['uid'],
			'timestamp' => TIMESTAMP,
			'num' => $_GET['str_idcard'],
		);
		if ($$pic) {
			$insertarray['pic'] = $$pic;
		}
		if($config['r_ext']&&$r_pay['0']){
			if (getuserprofile('extcredits' . $config['r_ext']) < $r_pay['0']) {
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					if($mobile_integral_recharge){
						echo "<script>parent.tips('".'&#26412;&#27425;&#25805;&#20316;&#38656;&#35201;&#28040;&#32791;'.$r_pay['0'].$_G['setting']['extcredits'][$config['r_ext']]['title'].','.$_G['setting']['extcredits'][$config['r_ext']]['title'] . lang('plugin/aljcw','top_1').$aljcwlang['php']['Jumping_up_page']."',function(){parent.location.href='".$mobile_integral_recharge."';});</script>";
					}else{
						echo "<script>parent.tips('".$_G['setting']['extcredits'][$config['r_ext']]['title'] . "&#19981;&#36275;','');</script>";
					}
					
					exit;
				}else{
					showerror('&#26412;&#27425;&#25805;&#20316;&#38656;&#35201;&#28040;&#32791;'.$r_pay['0'].$_G['setting']['extcredits'][$config['r_ext']]['title'].','.$_G['setting']['extcredits'][$config['r_ext']]['title'] . '&#19981;&#36275;'.$pc_integral_recharge);
				}
			}
			updatemembercount($_G['uid'], array($config['r_ext'] => '-' . $r_pay['0']));
		}
		if(C::t('#aljcw#aljcw_attestation')->fetch_uid_type($_G['uid'],'1')){
			$insertarray['sign'] = 0;
			DB::update('aljcw_attestation', $insertarray, array("uid"=>$_G['uid'],'type'=>'1'));
		}else{
			if(!$$pic){
				//showerror('&#35831;&#19978;&#20256;&#29031;&#29255;&#65281;');
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('&#35831;&#19978;&#20256;&#29031;&#29255;&#65281;','');</script>";
					exit;
				}else{
					showerror('&#35831;&#19978;&#20256;&#29031;&#29255;&#65281;');
				}
			}
			C::t('#aljcw#aljcw_attestation')->insert($insertarray);
		}
		//showmsg('&#25552;&#20132;&#25104;&#21151;&#65292;&#35831;&#31561;&#24453;&#23457;&#26680;&#65281;');
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('&#25552;&#20132;&#25104;&#21151;&#65292;&#35831;&#31561;&#24453;&#23457;&#26680;&#65281;',function(){parent.location=parent.location;});</script>";
		}else{
			showmsg('&#25552;&#20132;&#25104;&#21151;&#65292;&#35831;&#31561;&#24453;&#23457;&#26680;&#65281;');
		}
	}
}else if($_GET['form']=='gongsi'){
	if (submitcheck('formhash')) {
		$rz1=C::t('#aljcw#aljcw_attestation')->fetch_uid_type_sign($_G['uid'],'1');
		if($rz1){
			C::t('#aljcw#aljcw_attestation')->delete($rz1['id']);
		}
		$insertarray = array(
			'type' => '2',
			'username' => $_G['username'],
			'uid' => $_G['uid'],
			'timestamp' => TIMESTAMP,
			'num' => $_GET['num'],
			'gongsiname' => $_GET['gongsiname'],
		);
		if ($$pic) {
			$insertarray['pic'] = $$pic;
		}
		if($config['r_ext']&&$r_pay['1']){
			if (getuserprofile('extcredits' . $config['r_ext']) < $r_pay['1']) {
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					if($mobile_integral_recharge){
						echo "<script>parent.tips('".'&#26412;&#27425;&#25805;&#20316;&#38656;&#35201;&#28040;&#32791;'.$r_pay['1'].$_G['setting']['extcredits'][$config['r_ext']]['title'].','.$_G['setting']['extcredits'][$config['r_ext']]['title'] . lang('plugin/aljcw','top_1').$aljcwlang['php']['Jumping_up_page']."',function(){parent.location.href='".$mobile_integral_recharge."';});</script>";
					}else{
						echo "<script>parent.tips('".$_G['setting']['extcredits'][$config['r_ext']]['title'] . "&#19981;&#36275;','');</script>";
					}
					exit;
				}else{
					showerror('&#26412;&#27425;&#25805;&#20316;&#38656;&#35201;&#28040;&#32791;'.$r_pay['1'].$_G['setting']['extcredits'][$config['r_ext']]['title'].','.$_G['setting']['extcredits'][$config['r_ext']]['title'] . '&#19981;&#36275;'.$pc_integral_recharge);
				}
			}
			updatemembercount($_G['uid'], array($config['r_ext'] => '-' . $r_pay['1']));
		}
		if(C::t('#aljcw#aljcw_attestation')->fetch_uid_type($_G['uid'],'2')){
			$insertarray['sign'] = 0;
			DB::update('aljcw_attestation', $insertarray, array("uid"=>$_G['uid'],'type'=>'2'));
		}else{
			if(!$$pic){
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('&#35831;&#19978;&#20256;&#29031;&#29255;&#65281;','');</script>";
					exit;
				}else{
					showerror('&#35831;&#19978;&#20256;&#29031;&#29255;&#65281;');
				}
			}
			C::t('#aljcw#aljcw_attestation')->insert($insertarray);
		}
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('&#25552;&#20132;&#25104;&#21151;&#65292;&#35831;&#31561;&#24453;&#23457;&#26680;&#65281;',function(){parent.location=parent.location;});</script>";
		}else{
			showmsg('&#25552;&#20132;&#25104;&#21151;&#65292;&#35831;&#31561;&#24453;&#23457;&#26680;&#65281;');
		}
	}
}else{
	$rz1=C::t('#aljcw#aljcw_attestation')->fetch_uid_type_sign($_G['uid'],'1');
	$rz2=C::t('#aljcw#aljcw_attestation')->fetch_uid_type_sign($_G['uid'],'2');
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljcw_seo['admintop']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljcw_seo['admintop']);
	}
	include template('aljcw:attestation');
}
//From: Dism��taobao��com
?>