<?php

/*
 * DisM!Ӧ������(dism.taobao.com)
 * QQȺ: 778390776
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (getuserprofile('extcredits' . $config['reflashextcredit']) < $config['reflashpay']) {
    
	if($_G['mobile']){
        if($mobile_integral_recharge){
            $data['code'] = 300;
            $data['msg'] = '&#26412;&#27425;&#25805;&#20316;&#38656;&#35201;&#28040;&#32791;'.$config['reflashpay'].$_G['setting']['extcredits'][$config['reflashextcredit']]['title'].','.$_G['setting']['extcredits'][$config['reflashextcredit']]['title'] . lang('plugin/aljcw','top_1').$aljcwlang['php']['Jumping_up_page'];
            $data['url'] = $mobile_integral_recharge;
            echo json_encode(ajaxPostCharSet_aljcw($data));
            exit;
        }else{
            $data['code'] = 400;
            $data['msg'] = '&#26412;&#27425;&#25805;&#20316;&#38656;&#35201;&#28040;&#32791;'.$config['reflashpay'].$_G['setting']['extcredits'][$config['reflashextcredit']]['title'].','.$_G['setting']['extcredits'][$config['reflashextcredit']]['title'] . lang('plugin/aljcw','top_1');
            $data['url'] = 0;
            echo json_encode(ajaxPostCharSet_aljcw($data));
            exit;
        }
		exit;
	}else{
		showerror('&#26412;&#27425;&#25805;&#20316;&#38656;&#35201;&#28040;&#32791;'.$config['reflashpay'].$_G['setting']['extcredits'][$config['reflashextcredit']]['title'].','.$_G['setting']['extcredits'][$config['reflashextcredit']]['title'] . lang('plugin/aljcw','top_1').$pc_integral_recharge);
	}
}
C::t('#aljcw#aljcw_reflashlog')->insert(array(
    'lid' => $_GET['lid'],
    'uid' => $_G['uid'],
    'username' => $_G['username'],
    'dateline' => TIMESTAMP,
    'pay' => $config['reflashpay'],
    'extcredit' => $config['relashextcredit'],
	'title' => $lp['title'],
    'name' => $lp['username'],
));
C::t('#aljcw#aljcw')->update_updatetime_by_id($_GET['lid']);
updatemembercount($_G['uid'], array($config['reflashextcredit'] => '-' . $config['reflashpay']));
C::t('#aljcw#aljcw_user')->update_updatecount_by_uid($_G['uid']);
if($_G['mobile']){
    $data['code'] = 200;
    $data['msg'] = lang('plugin/aljcw','reflash_1');
    $data['url'] = 0;
    echo json_encode(ajaxPostCharSet_aljcw($data));
    exit;
}else{
	showmsg(lang('plugin/aljcw','reflash_1'), 'plugin.php?id=aljcw&act=member');
}
//From: Dism��taobao��com
?>