<?php

/*
 * DisM!Ӧ������(dism.taobao.com)
 * QQȺ: 778390776
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$file = 'aljcw_qrcode.jpg';	 QRcode::png($_G['siteurl'].'plugin.php?id=aljcw', 'source/plugin/aljcw/images/qrcode/'.$file, QR_MODE_STRUCTURE, 8);
?>