<?php

/*
 * DisM!Ӧ������(dism.taobao.com)
 * QQȺ: 778390776
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($config['es_fid']){
	if($config['isrewrite']){
		$re_url=str_replace ("{id}",$insertid, $config ['re_view']);
	}else{
		$re_url='plugin.php?id=aljcw&act=view&lid='.$insertid;
	}
	foreach($_GET['service_content'] as $k => $v){
		$service_c.=$types[$v].',';
	}
	//$s_c=trim($service_c,',');
	$str.='[size=4][url='.$re_url.']'.$_GET['title'].'[/url] [url='.$re_url.'][color=red]'.lang('plugin/aljcw','thread_10').'[/color][/url]<br/>';
	$str.=str_replace('{tel}',$_GET['contact'],str_replace('{zf_type}',$_GET['pos1']?$pos_zw[$_GET['pos1']]['subject']:($_GET['pos']?$pos_zw[$_GET['pos']]['subject']:'-'),str_replace('{zujin}',$_GET['zujin']>0?intval($_GET['zujin']):lang('plugin/aljcw','aljcw_23'),lang('plugin/aljcw','thread_2'))));		
	
	if($_GET['qq']){
		$str.=str_replace('{qq}',$_GET['qq'],lang('plugin/aljcw','thread_4'));
	}
	if($_GET['lxr']){
		$str.=str_replace('{lxr}',$_GET['lxr'],lang('plugin/aljcw','thread_5'));
	}
	if($_GET['region1']||$_GET['region']||$_GET['region2']){
		if($_GET['region2']&&$_GET['region1']&&$_GET['region']){
			$str.=str_replace('{region2}',$regions[$_GET['region2']]['subject'],str_replace('{region1}',$regions[$_GET['region1']]['subject'],str_replace('{region}',$regions[$_GET['region']]['subject'],lang('plugin/aljcw','thread_6'))));
		}else if($_GET['region1']&&$_GET['region']&&!$_GET['region2']){
			$str.=str_replace('{region1}',$regions[$_GET['region1']]['subject'],str_replace('{region}',$regions[$_GET['region']]['subject'],lang('plugin/aljcw','thread_7')));
		}else if($_GET['region']&&!$_GET['region2']&&!$_GET['region1']){
			$str.=str_replace('{region}',$regions[$_GET['region']]['subject'],lang('plugin/aljcw','thread_8'));
		}
	}
	$str.=str_replace('{shengming}',$shengming,lang('plugin/aljcw','thread_9'));
	if($_GET['content']){
		$str.=str_replace('{content}',discuzcode($_GET['content']),'{content}');	
	}
	if($settings['is_tongbu_img']['value']==1){
		if($insertarray){
			for ($i = 1; $i <= 8; $i++) {
				$pic = 'pic' . $i;
				if ($$pic) {
					$imgs[] = '<br/><img src="'.$$pic.'">';
				}
			}
		}else{
			for ($i = 1; $i <= 8; $i++) {
				$pic = 'pic' . $i;
				if ($user[$pic]) {
					$imgs[] = '<br/><img src="'.$user[$pic].'">';
				}
			}
		}
		
		$str.=implode('',$imgs);
	}
	$str.='[/size]';
	$cont=str_replace('&amp;','&',html2bbcode(htmlspecialchars_decode($str)));
	$tid = generatethread('['.$config['daohang'].']'.$_GET['title'], $cont, $_G['clientip'], $_G['uid'], '', $config['es_fid'],$config['threadtypes']);
	C::t('#aljcw#aljcw')->update($insertid,array('tid'=>$tid));
}
//From: Dism��taobao��com
?>