<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$comarray=array(
	1=>array('id'=>1,'file'=>'source/plugin/aljcw/template/com/moneyso.htm','name'=>lang('plugin/aljcw','com_array_1'),'desc'=>lang('plugin/aljcw','com_array_2'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48611'),
	2=>array('id'=>2,'file'=>'source/plugin/aljcw/template/com/so.htm','name'=>lang('plugin/aljcw','com_array_3'),'desc'=>lang('plugin/aljcw','com_array_4'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48612'),
	3=>array('id'=>3,'file'=>'source/plugin/aljcw/template/com/viewadv.htm','name'=>lang('plugin/aljcw','com_array_5'),'desc'=>lang('plugin/aljcw','com_array_6'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48613'),
	4=>array('id'=>4,'file'=>'source/plugin/aljcw/template/com/viewadv1.htm','name'=>lang('plugin/aljcw','com_array_7'),'desc'=>lang('plugin/aljcw','com_array_8'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48614'),
	5=>array('id'=>5,'file'=>'source/plugin/aljcw/template/com/renqi.htm','name'=>lang('plugin/aljcw','com_array_9'),'desc'=>lang('plugin/aljcw','com_array_10'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48615'),
	6=>array('id'=>6,'file'=>'source/plugin/aljcw/template/com/gg.htm','name'=>lang('plugin/aljcw','com_array_11'),'desc'=>lang('plugin/aljcw','com_array_12'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48616'),
	7=>array('id'=>7,'file'=>'source/plugin/aljcw/template/com/fenxiang.htm','name'=>lang('plugin/aljcw','com_array_13'),'desc'=>lang('plugin/aljcw','com_array_14'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48617'),
	8=>array('id'=>8,'file'=>'source/plugin/aljcw/template/com/sixin.htm','name'=>lang('plugin/aljcw','com_array_15'),'desc'=>lang('plugin/aljcw','com_array_16'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48618'),
	9=>array('id'=>9,'file'=>'source/plugin/aljcw/template/com/guanzhu.htm','name'=>lang('plugin/aljcw','com_array_17'),'desc'=>lang('plugin/aljcw','com_array_18'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48619'),
	10=>array('id'=>10,'file'=>'source/plugin/aljcw/template/com/qita.htm','name'=>lang('plugin/aljcw','com_array_19'),'desc'=>lang('plugin/aljcw','com_array_20'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48620'),
	11=>array('id'=>11,'file'=>'source/plugin/aljcw/template/com/commen.htm','name'=>lang('plugin/aljcw','com_array_21'),'desc'=>lang('plugin/aljcw','com_array_22'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48621'),
	12=>array('id'=>12,'file'=>'source/plugin/aljcw/template/com/reflash.php','name'=>lang('plugin/aljcw','com_array_23'),'desc'=>lang('plugin/aljcw','com_array_24'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48622'),
	13=>array('id'=>13,'file'=>'source/plugin/aljcw/template/com/top.php','name'=>lang('plugin/aljcw','com_array_25'),'desc'=>lang('plugin/aljcw','com_array_26'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48623'),
	16=>array('id'=>16,'file'=>'source/plugin/aljcw/template/com/user.php','name'=>lang('plugin/aljcw','com_array_31'),'desc'=>lang('plugin/aljcw','com_array_32'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48624'),
	17=>array('id'=>17,'file'=>'source/plugin/aljcw/template/com/admin.php','name'=>lang('plugin/aljcw','com_array_33'),'desc'=>lang('plugin/aljcw','com_array_34'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48625'),
	18=>array('id'=>18,'file'=>'source/plugin/aljcw/template/com/tongbu.php','name'=>lang('plugin/aljcw','com_array_35'),'desc'=>lang('plugin/aljcw','com_array_36'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48626'),
	19=>array('id'=>19,'file'=>'source/plugin/aljcw/template/com/qrcode.php','name'=>lang('plugin/aljcw','com_array_37'),'desc'=>lang('plugin/aljcw','com_array_38'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48627'),
	21=>array('id'=>21,'file'=>'source/plugin/aljcw/template/com/color.htm','name'=>lang('plugin/aljcw','com_array_41'),'desc'=>lang('plugin/aljcw','com_array_42'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48628'),
	22=>array('id'=>22,'file'=>'source/plugin/aljcw/template/mobile/index.htm','name'=>lang('plugin/aljcw','com_array_43'),'desc'=>lang('plugin/aljcw','com_array_44'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48632'),
	23=>array('id'=>23,'file'=>'source/plugin/aljcw/template/com/qita.php','name'=>lang('plugin/aljcw','com_array_45'),'desc'=>lang('plugin/aljcw','com_array_46'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48629'),
	24=>array('id'=>24,'file'=>'source/plugin/aljcw/template/com/release.php','name'=>lang('plugin/aljcw','com_array_47'),'desc'=>lang('plugin/aljcw','com_array_48'),'url'=>'http://DisM.taobao.com/?@aljcw.plugin.48630'),

);
?>