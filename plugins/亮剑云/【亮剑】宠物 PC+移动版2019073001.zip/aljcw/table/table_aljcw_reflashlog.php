<?php
/*
 * DisM!Ӧ������(dism.taobao.com)
 * QQȺ: 778390776
 *
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljcw_reflashlog extends discuz_table{
	public function __construct() {

			$this->_table = 'aljcw_reflashlog';
			$this->_pk    = 'id';

			parent::__construct();
	}
       

}




?>