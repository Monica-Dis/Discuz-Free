<?php
/*
 * DisM!Ӧ������(dism.taobao.com)
 * QQȺ: 778390776
 *
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljcw_position extends discuz_table{
	public function __construct() {

			$this->_table = 'aljcw_position';
			$this->_pk    = 'id';

			parent::__construct();
	}
	public function fetch_upid_by_id($id=0){
		return DB::result_first('SELECT upid FROM %t WHERE id=%d',array($this->_table,$id));
	}
	public function fetch_subid_by_id($id=0){
		return DB::result_first('SELECT subid FROM %t WHERE id=%d',array($this->_table,$id));
	}
	
	public function fetch_all_by_upid($upid=0,$start=0,$perpage=0,$search=''){
		if($perpage){
			if($search){
				return DB::fetch_all('SELECT * FROM %t WHERE upid=%d and subject like %s ORDER BY displayorder ASC limit %d,%d',array($this->_table,$upid,$search,$start,$perpage),'id');
			}else{
				return DB::fetch_all('SELECT * FROM %t WHERE upid=%d ORDER BY displayorder ASC limit %d,%d',array($this->_table,$upid,$start,$perpage),'id');
			}
		}else{
			return DB::fetch_all('SELECT * FROM %t WHERE upid=%d ORDER BY displayorder ASC',array($this->_table,$upid),'id');
		}
	}
	public function count_by_upid($upid=0,$search=''){
		if($search){
			return DB::result_first('select count(*) from %t where upid=%d and subject like %s',array($this->_table,$upid,$search));
		}else{
			return DB::result_first('select count(*) from %t where upid=%d ',array($this->_table,$upid));
		}
	}
	public function fetch_all_by_type($type=0){
		return DB::fetch_all('select * from %t where id=%d ORDER BY displayorder ASC',array($this->_table,$type));
	}

}




?>