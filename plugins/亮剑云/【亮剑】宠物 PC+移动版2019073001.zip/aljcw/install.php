<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//start to put your own code 


$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljcw` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `addtime` int(10) NOT NULL,
  `updatetime` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `zujin` int(10) NOT NULL,
  `content` mediumtext NOT NULL,
  `pic1` varchar(255) NOT NULL,
  `pic2` varchar(255) NOT NULL,
  `pic3` varchar(255) NOT NULL,
  `pic4` varchar(255) NOT NULL,
  `pic5` varchar(255) NOT NULL,
  `pic6` varchar(255) NOT NULL,
  `pic7` varchar(255) NOT NULL,
  `pic8` varchar(255) NOT NULL,
  `region` int(11) NOT NULL,
  `region1` int(10) NOT NULL,
  `region2` varchar(255) NOT NULL,
  `region3` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `views` mediumint(9) NOT NULL,
  `qq` bigint(20) NOT NULL,
  `tuijian` int(11) NOT NULL,
  `displayorder` int(11) NOT NULL,
  `lxr` varchar(255) NOT NULL,
  `qrcode` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `topstime` int(11) NOT NULL,
  `topetime` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `clientip` varchar(255) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `solve` tinyint(3) NOT NULL,
  `wanted` tinyint(3) NOT NULL,
  `pos` int(10) NOT NULL,
  `pos1` int(10) NOT NULL,
  `sex` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `identity` int(11) NOT NULL,
  `vaccine` int(11) NOT NULL,
  `insect` int(11) NOT NULL,
  `weight` decimal(10,2) NOT NULL,
  `number` int(11) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljcw_log` (
  `day` int(11) NOT NULL,
  `views` mediumint(9) NOT NULL,
  PRIMARY KEY  (`day`)
);
CREATE TABLE IF NOT EXISTS `pre_aljcw_position` (
  `id` mediumint(9) unsigned NOT NULL auto_increment,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljcw_reflashlog` (
  `id` int(11) NOT NULL auto_increment,
  `lid` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `pay` int(10) NOT NULL,
  `extcredit` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljcw_region` (
  `id` mediumint(9) unsigned NOT NULL auto_increment,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  `level` tinyint(3) NOT NULL,
  `havechild` tinyint(3) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljcw_toplog` (
  `id` int(10) NOT NULL auto_increment,
  `lid` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `pay` int(10) NOT NULL,
  `extcredit` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `endtime` int(11) NOT NULL,
  `status` TINYINT(3) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljcw_user` (
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `count` int(10) NOT NULL default '0',
  `updatecount` int(10) NOT NULL default '0',
  `top` int(10) NOT NULL default '0',
  `last` int(10) NOT NULL,
  PRIMARY KEY  (`uid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljcw_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljcw_setting` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `a` varchar(255) NOT NULL,
  `b` varchar(255) NOT NULL,
  `c` text NOT NULL,
  `d` int(11) NOT NULL,
  `e` int(11) NOT NULL,
  PRIMARY KEY (`key`)
);
CREATE TABLE IF NOT EXISTS `pre_aljcw_attestation` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `gongsiname` varchar(255) NOT NULL,
  `mendianname` varchar(255) NOT NULL,
  `num` bigint(20) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `sign` tinyint(4) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljcw_comment` (
  `id` int(11) NOT NULL auto_increment,
  `upid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `lid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `content` mediumtext NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `upid` (`upid`),
  KEY `dateline` (`dateline`),
  KEY `lid` (`lid`)
);
INSERT INTO `pre_aljcw_position` (`id`, `upid`, `subid`, `subject`, `displayorder`) VALUES
(1, 0, '4,5,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59', '$installlang[install1]', 0),
(2, 0, '6,7,60,61,62,63,64,65,66,67', '$installlang[install64]', 0),
(3, 0, '', '$installlang[install65]', 0),
(4, 1, '', '$installlang[install2]', 0),
(5, 1, '', '$installlang[install3]', 0),
(6, 2, '', '$installlang[install66]', 0),
(7, 2, '', '$installlang[install67]', 0),
(8, 1, '', '$installlang[install4]', 0),
(9, 1, '', '$installlang[install5]', 0),
(10, 1, '', '$installlang[install6]', 0),
(11, 1, '', '$installlang[install7]', 0),
(12, 1, '', '$installlang[install8]', 0),
(13, 1, '', '$installlang[install9]', 0),
(14, 1, '', '$installlang[install10]', 0),
(15, 1, '', '$installlang[install11]', 0),
(16, 1, '', '$installlang[install12]', 0),
(17, 1, '', '$installlang[install13]', 0),
(18, 1, '', '$installlang[install14]', 0),
(19, 1, '', '$installlang[install15]', 0),
(20, 1, '', '$installlang[install16]', 0),
(21, 1, '', '$installlang[install17]', 0),
(22, 1, '', '$installlang[install18]', 0),
(23, 1, '', '$installlang[install19]', 0),
(24, 1, '', '$installlang[install20]', 0),
(25, 1, '', '$installlang[install21]', 0),
(26, 1, '', '$installlang[install22]', 0),
(27, 1, '', '$installlang[install23]', 0),
(28, 1, '', '$installlang[install24]', 0),
(29, 1, '', '$installlang[install25]', 0),
(30, 1, '', '$installlang[install26]', 0),
(31, 1, '', '$installlang[install27]', 0),
(32, 1, '', '$installlang[install28]', 0),
(33, 1, '', '$installlang[install29]', 0),
(34, 1, '', '$installlang[install30]', 0),
(35, 1, '', '$installlang[install31]', 0),
(36, 1, '', '$installlang[install32]', 0),
(37, 1, '', '$installlang[install33]', 0),
(38, 1, '', '$installlang[install34]', 0),
(39, 1, '', '$installlang[install35]', 0),
(40, 1, '', '$installlang[install36]', 0),
(41, 1, '', '$installlang[install37]', 0),
(42, 1, '', '$installlang[install38]', 0),
(43, 1, '', '$installlang[install39]', 0),
(44, 1, '', '$installlang[install40]', 0),
(45, 1, '', '$installlang[install41]', 0),
(46, 1, '', '$installlang[install42]', 0),
(47, 1, '', '$installlang[install43]', 0),
(48, 1, '', '$installlang[install44]', 0),
(49, 1, '', '$installlang[install45]', 0),
(50, 1, '', '$installlang[install46]', 0),
(51, 1, '', '$installlang[install47]', 0),
(52, 1, '', '$installlang[install48]', 0),
(53, 1, '', '$installlang[install49]', 0),
(54, 1, '', '$installlang[install50]', 0),
(55, 1, '', '$installlang[install51]', 0),
(56, 1, '', '$installlang[install52]', 0),
(57, 1, '', '$installlang[install53]', 0),
(58, 1, '', '$installlang[install54]', 0),
(59, 1, '', '$installlang[install55]', 0),
(60, 2, '', '$installlang[install56]', 0),
(61, 2, '', '$installlang[install57]', 0),
(62, 2, '', '$installlang[install58]', 0),
(63, 2, '', '$installlang[install59]', 0),
(64, 2, '', '$installlang[install60]', 0),
(65, 2, '', '$installlang[install61]', 0),
(66, 2, '', '$installlang[install62]', 0),
(67, 2, '', '$installlang[install63]', 0);
EOF;

runquery($sql);
//finish to put your own code
$finish = TRUE;
?>