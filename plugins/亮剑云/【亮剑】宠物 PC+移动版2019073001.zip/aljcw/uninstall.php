<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//start to put your own code 
$sql = <<<EOF
DROP TABLE IF  EXISTS `pre_aljcw`;
DROP TABLE IF  EXISTS `pre_aljcw_log`;
DROP TABLE IF  EXISTS `pre_aljcw_reflashlog`;
DROP TABLE IF  EXISTS `pre_aljcw_region`;
DROP TABLE IF  EXISTS `pre_aljcw_toplog`;
DROP TABLE IF  EXISTS `pre_aljcw_user`;
DROP TABLE IF  EXISTS `pre_aljcw_comment`;
DROP TABLE IF  EXISTS `pre_aljcw_attestation`;
DROP TABLE IF  EXISTS `pre_aljcw_collection`;
DROP TABLE IF  EXISTS `pre_aljcw_setting`;
DROP TABLE IF  EXISTS `pre_aljcw_position`;
EOF;

runquery($sql);
//finish to put your own code
$finish = TRUE;
?>