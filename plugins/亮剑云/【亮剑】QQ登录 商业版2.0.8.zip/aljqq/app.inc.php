<?php

/*
 * lang("plugin/aljwb","aljwb_inc_php_1"): Discuz!lang("plugin/aljwb","aljwb_inc_php_2")
 * lang("plugin/aljwb","aljwb_inc_php_3"): http://www.dzx30.com
 * lang("plugin/aljwb","aljwb_inc_php_4")QQ: 190360183
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


echo "<script language='javascript'>";
echo "window.location.href='https://dism.taobao.com/?@liangjian'";
echo "</script>";
exit;