<?php

/*
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1/
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class plugin_aljqq{
    function common(){
        global $_G;
        $_G['connect']['referer'] = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'].($_SERVER['QUERY_STRING'] ? '?'.$_SERVER['QUERY_STRING'] : '') : dreferer();
        $_G['connect']['referer'] = urlencode($_G['connect']['referer'] ? $_G['connect']['referer'] : 'index.php');
    }
    function global_usernav_extra1() {
        global $_G;
        if($_G['uid']){
            $connectUser = DB::fetch_first('select * from %t where uid=%d',array('aljqq_user',$_G['uid']));
            if($connectUser){
                return;
            }
            return '<span class="pipe">|</span><a href="plugin.php?id=aljqq&referer='.$_G['connect']['referer'].'"><img src="static/image/common/qq_login.gif" class="qq_bind" align="absmiddle" /></a>';
        }
    }
    function global_login_extra() {
        global $_G;
        include template('aljqq:qq');
        return $return;
    }
    function global_login_text() {
        global $_G;
        return '&nbsp;<a rel="nofollow" target="_top" href="plugin.php?id=aljqq&referer='.$_G['connect']['referer'].'"><img class="vm" src="static/image/common/qq_login.gif"></a>';
    }
}

class plugin_aljqq_member extends plugin_aljqq{
    function logging_method(){
        global $_G;
        return '<a rel="nofollow" target="_top" href="plugin.php?id=aljqq&referer='.$_G['connect']['referer'].'"><img class="vm" src="static/image/common/qq_login.gif"></a>';
    }

    function register_logging_method(){
        global $_G;
        return '<a rel="nofollow" target="_top" href="plugin.php?id=aljqq&referer='.$_G['connect']['referer'].'"><img class="vm" src="static/image/common/qq_login.gif"></a>';
    }
}
class plugin_aljqq_forum extends plugin_aljqq {
    function global_login_text(){
        global $_G;
        return '&nbsp;<a rel="nofollow" target="_top" href="plugin.php?id=aljqq&referer='.$_G['connect']['referer'].'"><img class="vm" src="static/image/common/qq_login.gif"></a>';
    }
}
class mobileplugin_aljqq{
    function common(){
        global $_G;
        $_G['connect']['referer'] = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'].($_SERVER['QUERY_STRING'] ? '?'.$_SERVER['QUERY_STRING'] : '') : dreferer();
        $_G['connect']['referer'] = $_G['connect']['referer'] ? $_G['connect']['referer'] : 'index.php';
        if($_GET['mod'] == 'logging'){
            if ($_G['connect']['referer']) {
                if (empty($_GET['code'])) {
                    if(strpos($_SERVER['HTTP_REFERER'],"graph.qq.com") === false && strpos($_SERVER['HTTP_REFERER'],"code") === false){

                        dsetcookie('referer_qq', $_G['connect']['referer'],'60');
                    }
                }
            }
        }else if($_GET['mod'] == 'register' && empty($_GET['formhash'])){
            if ($_G['connect']['referer']) {
                if (empty($_GET['code'])) {
                    if(strpos($_SERVER['HTTP_REFERER'],"graph.qq.com") === false && strpos($_SERVER['HTTP_REFERER'],"code") === false){

                        dsetcookie('referer_qq', $_G['connect']['referer'],'60');
                    }
                }
            }

        }
    }
}
class mobileplugin_aljqq_member extends mobileplugin_aljqq{
    function logging_bottom_mobile()
    {
        global $_G;
        if(empty($_G['uid'])){
            $_G['connect']['referer'] = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'].($_SERVER['QUERY_STRING'] ? '?'.$_SERVER['QUERY_STRING'] : '') : dreferer();
            $_G['connect']['referer'] = urlencode($_G['connect']['referer'] ? $_G['connect']['referer'] : 'index.php');
            return '<style type="text/css">
			.btn_aljqqlogin a, .btn_aljqqlogin a:hover {
				color: #ffffff;
				text-align: center;
				font-size: 14px;
				line-height: 43px;
				background: #009CDE url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAACXElEQVRYR8WXTYiOURTHf/+MhYwSyUJKKAvlIzVlSikrxU5mqQg1UspXCDOzmFAzhUExm7GzsVDKBln4ygIpyYZYKaV85DNHZ3pfPfN6n+fe+zyP5m7exXvO//zuOffecx4xyUuTHJ9kADNbBWwC1gKLgDmNTdwDhiRdTdlUNICZTQeGge1QCH4b2CbpVQxIFICZzQJuAitiRIHPwJaYbAQBzKwDeAB46lPWL6Bb0qMipxiAfuBYSuSMrZdhsaTfef6FAGY2E3gLdJYEcDcvxeWyAPuBUxWCu+stSevKAvjVWl0RwM9Cp6Tv7XRCJfgBTK0I4O4rJT1JAmjU/0MNwV1ivaQbqQDHgb6aAPwar5Hk5ZiwcktgZi+AJTUBuMwySc9SAB4nvHwxnF3tHqW2GTAzv/evgdkxypE2vZIuRGXAzEaAXZHCsWbfgOWSXmYd/slAo936+x18pmMjZ+zuSPI2/ndNCGJmU4CnwNIS4rEuC7OtuhVgI3AtVqmk3Q5Jl5q+rQAngQMlhWPdhiXtzQMY9WkG+Aq8AxbEqgbs/ODNB6YBFyXtzAM4BAwCRwA/DwM1AewBfCY4A+yTNJQH4HOfG3spZgBvKs4CHue9DyXAR8Db+3lJPrKNr1A33AxcqZiFDZKu52mEAA4CJyoCnPWdJ88DZtYLnKsYvOk+Iml3O62ibvgQ6KoJ4IufKUnWqlcEcDRwC34CpwH/3QrMLYC9L6k7NQMO59fRb0WzK/pc533CP1LGmk+qmfn/h4EeYF4jkL8jz4G7PthK+pQEUFPqgzL/o+MFg2YN/gDNS64hTWYdLgAAAABJRU5ErkJggg==) 35% center no-repeat;
				background-size:22px;
				border: 1px solid #009CDE;
				display:block;
                width: 287px;
                height: 43px;
                margin: 10px auto;
                border-radius: 8px;
			}	
        </style><div class="btn_aljqqlogin"><a href="plugin.php?id=aljqq&referer='.$_G['connect']['referer'].'">&#81;&#81;&#30331;&#24405;</a></div>';
        }

    }
}