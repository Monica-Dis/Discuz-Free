<?php

/*
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1/
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$config =$_G['cache']['plugin']['aljqq'];
$act=$_GET['act'];
$username=addslashes($_GET['username']);
if($_GET[referer]){
    dsetcookie('referer_qq', $_GET[referer],'60');
}else{
    //debug($_SERVER['HTTP_REFERER']);
    if (empty($_GET['code']) && !$_G['mobile']) {
        if(strpos($_SERVER['HTTP_REFERER'],"graph.qq.com") === false && strpos($_SERVER['HTTP_REFERER'],"code") === false){
 
            dsetcookie('referer_qq', $_SERVER['HTTP_REFERER'],'60');
        }
    }
}

if($act == 'jiechu') {
	if(submitcheck('formhash')){
		DB::query('delete from %t where uid=%d and username=%s',array('aljqq_user',$_G['uid'],$_G['username']));
		aljqq_mall_parenttips(1,lang("plugin/aljqq","aljqq_inc_php_1"),'forum.php');
	}
}else if($act == 'unbinding') {
	include template('aljqq:unbind');
}else if($act == 'pcverifyusername') {
	$username=aljqq_ajaxGetCharSet($username);
	$arr = aljqq_CheckUsername($username);
	echo json_encode($arr);
}else if($act == 'verifyusername') {
	$arr = aljqq_CheckUsername($username);
	echo json_encode($arr);
}else if($act == 'register') {
	if(submitcheck('formhash')){
		if(dstrlen($username)>=4 && dstrlen($username)<15){
			$user = DB::fetch_first('select * from %t where username=%s',array('common_member',$username));
			if($user) {
				aljqq_mall_parenttips(1,lang("plugin/aljqq","aljqq_inc_php_2"));
			}else{
				loaducenter();
				$usern = aljqq_removeEmoji($username);
				if(uc_user_checkname($usern) <0) {
					aljqq_mall_parenttips(1,lang("plugin/aljqq","aljqq_inc_php_3"));
				}else{
					$groupid = $_G['cache']['plugin']['aljqq']['groupid'];
					$email =  'wechat_'.strtolower(random(10)).'@null.null';
					$password=aljqq_generate_password();
					$result = aljqq_myregister($username,'',$groupid,$password,$email);
					if(!empty($result) && is_array($result)) {
						DB::insert('aljqq_user',array(
									'uid' => $result['uid'],
									'username' => $username,
									'openid' => addslashes($_GET['openid']),
                          			'unionid' => addslashes($_GET['unionid']),
									'dateline' => TIMESTAMP,
									'refresh_token' => addslashes($_GET['refresh_token']),
									'access_token' => addslashes($_GET['access_token']),
									'expires_in' => addslashes($_GET['expires_in']),
									'dateline' => TIMESTAMP,
									'qlogo' => addslashes($_GET['qlogo']),
									'qzlogo' => addslashes($_GET['qzlogo']),
									'ret' => $_GET['ret'],
									'msg' => $_GET['msg'],
									'is_lost' => $_GET['is_lost'],
									'nickname' => addslashes($_GET['nickname']),
									'gender' => $_GET['gender'],
									'city' => addslashes($_GET['city']),
									'year' => intval($_GET['year']),
									'is_yellow_vip' => $_GET['is_yellow_vip'],
									'vip' => $_GET['vip'],
									'yellow_vip_level' => $_GET['yellow_vip_level'],
									'level' => $_GET['level'],
									'is_yellow_year_vip' => $_GET['is_yellow_year_vip'],
								));
						if($_GET['use_qlogo']){
							aljqq_lcreate_avatar($result['uid'],$_GET['qlogo']);
						}
						require_once libfile('function/member');
						$user = getuserbyuid($result['uid']);
						setloginstatus($user, 2592000);
						notification_add($result['uid'], 'system',lang("plugin/aljqq","aljqq_inc_php_4").$result['password']);

            $referer = !empty($_GET['referer']) ? strip_tags($_GET['referer']) : $_SERVER['HTTP_REFERER'];
            $referer = $referer ? $referer : 'forum.php';
            $referer = $_G['cookie']['referer_qq'] ? strip_tags($_G['cookie']['referer_qq']) : $referer;
            aljqq_mall_parenttips(1,lang("plugin/aljqq","aljqq_inc_php_5"),$referer);

				  }else{
                        $result = str_replace('{regctrl}',$_G['setting']['ipregctrltime'],$result);
                        $result = str_replace('{regfloodctrl}',$_G['setting']['regfloodctrl'],$result);
                        aljqq_mall_parenttips(1, $result);
                }
			}
		}
	}else {
		aljqq_mall_parenttips(1,lang("plugin/aljqq","aljqq_inc_php_6"));
	}
  }
}else if($act == 'bingding') {
	if(submitcheck('formhash')){
		$result = aljqq_mapp_userlogin($username,$_GET['password']);
		if (empty($result['status'])) {
			aljqq_mall_parenttips(1,lang("plugin/aljqq","aljqq_inc_php_7"));
		}else {
			DB::insert('aljqq_user',array(
					'uid' => $result['member']['uid'],
					'username' => addslashes($result['member']['username']),
					'openid' => addslashes($_GET['openid']),
              		'unionid' => addslashes($_GET['unionid']),
					'dateline' => TIMESTAMP,
					'refresh_token' => addslashes($_GET['refresh_token']),
					'access_token' => addslashes($_GET['access_token']),
					'expires_in' => addslashes($_GET['expires_in']),
					'dateline' => TIMESTAMP,
					'qlogo' => addslashes($_GET['qlogo']),
					'qzlogo' => addslashes($_GET['qzlogo']),
					'ret' => $_GET['ret'],
					'msg' => $_GET['msg'],
					'is_lost' => $_GET['is_lost'],
					'nickname' => addslashes($_GET['nickname']),
					'gender' => $_GET['gender'],
					'city' => addslashes($_GET['city']),
					'year' => intval($_GET['year']),
					'is_yellow_vip' => $_GET['is_yellow_vip'],
					'vip' => $_GET['vip'],
					'yellow_vip_level' => $_GET['yellow_vip_level'],
					'level' => $_GET['level'],
					'is_yellow_year_vip' => $_GET['is_yellow_year_vip'],
				));
			if($_GET['use_qlogo']){
				aljqq_lcreate_avatar($result['member']['uid'],$_GET['qlogo']);
			}
			require_once libfile('function/member');
			$user = getuserbyuid($result['member']['uid']);
			setloginstatus($user, 2592000);
      $referer = !empty($_GET['referer']) ? strip_tags($_GET['referer']) : $_SERVER['HTTP_REFERER'];
      $referer = $referer ? $referer : 'index.php';
      $referer = $_G['cookie']['referer_qq'] ? strip_tags($_G['cookie']['referer_qq']) : $referer;
      aljqq_mall_parenttips(1,lang("plugin/aljqq","aljqq_inc_php_8"),$referer);
		}
	}
}else{
	//include template('aljqq:binding');
					//exit;
  	if($_GET['access_token']){
  		if($config['is_unionid']){
  			$callback = aljqq_aljGetOpenId_app($_GET['access_token']);
  		}else{
  			$callback = aljqq_aljGetOpenId($_GET['access_token']);
  		}

      		if (preg_match('/\"openid\":\"(\w+)\"/i', $callback, $match)) {

			$openid = $match[1];
          	if (preg_match('/\"unionid\":\"(\w+)\"/i', $callback, $match)) {
            	$unionid = $match[1];
            }

        	if($_GET['app'] == 'yes'){
        		$quser = aljqq_aljGetUserInfo_app($_GET['access_token'],$openid);
        	}else{
        		$quser = aljqq_aljGetUserInfo($_GET['access_token'],$openid);
        	}
			
            //debug($quser);
			$quser = json_decode($quser,true);
			$quser = aljqq_ajaxGetCharSet($quser);
			//debug($quser);
			$referer = !empty($_GET['referer']) ? strip_tags($_GET['referer']) : $_SERVER['HTTP_REFERER'];
            $referer = $referer ? $referer : 'index.php';
            $referer = $_G['cookie']['referer_qq'] ? strip_tags($_G['cookie']['referer_qq']) : $referer;
          	if($unionid){
              	$connectUser = DB::fetch_first('select * from %t where unionid=%s',array('aljqq_user',$unionid));
            }
          	if(!$connectUser){
              	$connectUser = DB::fetch_first('select * from %t where openid=%s',array('aljqq_user',$openid));
            }
			if($connectUser){
				$user = getuserbyuid($connectUser['uid']);
				require_once libfile('function/member');
				setloginstatus($user, 2592000);
				header('Location: '.$referer);
				exit;
			}else{
				if($_G['uid']){
					DB::insert('aljqq_user',array(
						'uid' => $_G['uid'],
						'username' => $_G['username'],
						'openid' => $openid,
                      	'unionid' => $unionid,
						'dateline' => TIMESTAMP,
						'refresh_token' => $accessTokenArray['refresh_token'],
						'access_token' => $accessTokenArray['access_token'],
						'expires_in' => $accessTokenArray['expires_in'],
						'dateline' => TIMESTAMP,
						'qlogo' => $quser['figureurl_qq_2'],
						'qzlogo' => $quser['figureurl_2'],
						'ret' => $quser['ret'],
						'msg' => $quser['msg'],
						'is_lost' => $quser['is_lost'],
						'nickname' => $quser['nickname'],
						'gender' => $quser['gender'],
						'city' => $quser['city'],
						'year' => $quser['year'],
						'is_yellow_vip' => $quser['is_yellow_vip'],
						'vip' => $quser['vip'],
						'yellow_vip_level' => $quser['yellow_vip_level'],
						'level' => $quser['level'],
						'is_yellow_year_vip' => $quser['is_yellow_year_vip'],
					));

					header('Location: '.$referer);
				}else{
					include template('aljqq:binding');
					exit;
				}
			}
			//debug(aljqq_aljGetUserInfo($accessTokenArray['access_token'],$openid));
		}else{
			showmessage($_GET['access_token']);
		}
		exit;
    }
	if (empty($_GET['code'])) {

		header('Location: ' .aljqq_aljCreateOauthUrlForCode(1));
	} else {
		
		parse_str(aljqq_aljGetAccessToken($_GET['code']),$accessTokenArray);//access_token,expires_in,refresh_token
        if($config['is_unionid']){
			$callback = aljqq_aljGetOpenId_app($accessTokenArray['access_token']);
		}else{
			$callback = aljqq_aljGetOpenId($accessTokenArray['access_token']);
		}
		
      
		if (preg_match('/\"openid\":\"(\w+)\"/i', $callback, $match)) {
			
			$openid = $match[1];
          	if (preg_match('/\"unionid\":\"(\w+)\"/i', $callback, $match)) {
            	$unionid = $match[1];
            }

        	if($_GET['app'] == 'yes'){
        		$quser = aljqq_aljGetUserInfo_app($accessTokenArray['access_token'],$openid);
        	}else{
        		$quser = aljqq_aljGetUserInfo($accessTokenArray['access_token'],$openid);
        	}
			
			$quser = json_decode($quser,true);
			$quser = aljqq_ajaxGetCharSet($quser);
			$referer = !empty($_GET['referer']) ? strip_tags($_GET['referer']) : $_SERVER['HTTP_REFERER'];
            $referer = $referer ? $referer : 'forum.php';
            $referer = $_G['cookie']['referer_qq'] ? strip_tags($_G['cookie']['referer_qq']) : $referer;
          	if($unionid){
              	$connectUser = DB::fetch_first('select * from %t where unionid=%s',array('aljqq_user',$unionid));
            }
          	if(!$connectUser){
              	$connectUser = DB::fetch_first('select * from %t where openid=%s',array('aljqq_user',$openid));
            }
			

			if($connectUser){
				$user = getuserbyuid($connectUser['uid']);
				require_once libfile('function/member');
				setloginstatus($user, 2592000);
				showmessage(lang("plugin/aljqq","aljqq_inc_php_9"),$referer);
			}else{
				if($_G['uid']){
					DB::insert('aljqq_user',array(
						'uid' => $_G['uid'],
						'username' => $_G['username'],
						'openid' => $openid,
                      	'unionid' => $unionid,
						'dateline' => TIMESTAMP,
						'refresh_token' => $accessTokenArray['refresh_token'],
						'access_token' => $accessTokenArray['access_token'],
						'expires_in' => $accessTokenArray['expires_in'],
						'dateline' => TIMESTAMP,
						'qlogo' => $quser['figureurl_qq_2'],
						'qzlogo' => $quser['figureurl_2'],
						'ret' => $quser['ret'],
						'msg' => $quser['msg'],
						'is_lost' => $quser['is_lost'],
						'nickname' => $quser['nickname'],
						'gender' => $quser['gender'],
						'city' => $quser['city'],
						'year' => $quser['year'],
						'is_yellow_vip' => $quser['is_yellow_vip'],
						'vip' => $quser['vip'],
						'yellow_vip_level' => $quser['yellow_vip_level'],
						'level' => $quser['level'],
						'is_yellow_year_vip' => $quser['is_yellow_year_vip'],
					));

					showmessage(lang("plugin/aljqq","aljqq_inc_php_10"),$referer);
				}else{
					include template('aljqq:binding');
				}
			}
			//debug(aljqq_aljGetUserInfo($accessTokenArray['access_token'],$openid));
		}
	}
}





function aljqq_aljCreateOauthUrlForCode($redirectUrl) {
    global $_G,$config;
    $urlObj["client_id"] = $config['appid'];
    if($_GET['app'] == 'yes'){
    	$urlObj["redirect_uri"] = urlencode($config['url']."plugin.php?id=aljqq&app=yes");
    }else{
    	$urlObj["redirect_uri"] = urlencode($config['url']."plugin.php?id=aljqq");
    }
    
    $urlObj["response_type"] = "code";
    $urlObj["scope"] = "get_user_info";
    $urlObj["state"] = "STATE"."#qq_redirect";
    $bizString = aljqq_aljFormatBizQueryParaMap($urlObj, false);

    return "https://graph.qq.com/oauth2.0/authorize?".$bizString;
}
function aljqq_aljFormatBizQueryParaMap($paraMap, $urlencode='')
{
    $buff = "";
    ksort($paraMap);
    foreach ($paraMap as $k => $v) {
        if ($urlencode) {
            $v = urlencode($v);
        }
        $buff .= $k . "=" . $v . "&";
    }
    if (strlen($buff) > 0) {
        $reqPar = substr($buff, 0, strlen($buff) - 1);
    }
    return $reqPar;
}
function aljqq_aljGetAccessToken($code){
    global $_G,$config;
    $url = 'https://graph.qq.com/oauth2.0/token?';
    $urlObj["grant_type"] = 'authorization_code';
    $urlObj["client_id"] = $config['appid'];
    $urlObj["client_secret"] = $config['appkey'];
    $urlObj["code"] = $code;
    $urlObj["redirect_uri"] = urlencode($config['url']."plugin.php?id=aljqq");
    $bizString = aljqq_aljFormatBizQueryParaMap($urlObj, false);
    $url = $url.$bizString;
    return dfsockopen($url);
}
function aljqq_aljGetOpenId($accessToken){
    global $_G;
    $url = 'https://graph.qq.com/oauth2.0/me?';
    $url = $url.'access_token='.$accessToken;
    return dfsockopen($url);
}
function aljqq_aljGetOpenId_app($accessToken){
    global $_G;
    $url = 'https://graph.qq.com/oauth2.0/me?';
    $url = $url.'access_token='.$accessToken.'&unionid=1';
    return dfsockopen($url);
}
function aljqq_aljGetUserInfo($access_token,$openid){
    global $config;
    $url = "https://graph.qq.com/user/get_user_info?access_token={$access_token}&oauth_consumer_key={$config['appid']}&openid={$openid}";

    //debug($url);
    return dfsockopen($url);
}
function aljqq_aljGetUserInfo_app($access_token,$openid){
    global $config;
    $url = "https://graph.qq.com/user/get_user_info?access_token={$access_token}&oauth_consumer_key={$config['appid_app']}&openid={$openid}";

    //debug($url);
    return dfsockopen($url);
}

function aljqq_ajaxGetCharSet($arr) {
    if(is_array($arr)){
        if (strtolower(CHARSET) == 'gbk') {
            foreach ($arr as $key => $val) {
                if(is_array($val)){
                    $pt_goods[$key] = aljqq_ajaxGetCharSet($val);
                }else{
                    $pt_goods[$key] = diconv($val,'utf-8','gbk');
                }

            }
            return $pt_goods;
        }
        return $arr;
    } else {
        if (strtolower(CHARSET) == 'gbk') {
            return diconv($arr,'utf-8','gbk');
        }
        return $arr;
    }

}
function aljqq_ajaxPostCharSet($arr) {
	if(is_array($arr)){
		if (strtolower(CHARSET) == 'gbk') {
			foreach ($arr as $key => $val) {
				if(is_array($val)){
					$pt_goods[$key] = aljqq_ajaxPostCharSet($val);
				}else{
					$pt_goods[$key] = diconv($val,'gbk','utf-8');
				}

			}
			return $pt_goods;
		}
		return $arr;
	} else {
		if (strtolower(CHARSET) == 'gbk') {
			return diconv($arr,'gbk','utf-8');
		}
		return $arr;
	}

}

function aljqq_myregister($username, $return = 0, $groupid = 0,$defaultpassword='',$email='') {
	global $_G;

	if(!$username) {
		return;
	}
    $username = aljqq_removeEmoji($username);
	loaducenter();
	$pwd = 'PW'.random(6);
	if($defaultpassword){
		$pwd = $defaultpassword;
	}
	$password = md5($pwd);
	$usernamelen = dstrlen($username);
	if($usernamelen < 4  || uc_user_checkname($username)<0) {
		$username = random(6);
	}
	if($usernamelen > 15) {
		$username = random(6);
	}

	$censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';

	if($_G['setting']['censoruser'] && @preg_match($censorexp, $username)) {
		if(!$return) {
			return lang('message', 'profile_username_protect');
		} else {
			return 'Registration failed. Please try again!';
		}
	}



	loadcache('ipctrl');
	if($_G['cache']['ipctrl']['ipregctrl']) {
		foreach(explode("\n", $_G['cache']['ipctrl']['ipregctrl']) as $ctrlip) {
			if(preg_match("/^(".preg_quote(($ctrlip = trim($ctrlip)), '/').")/", $_G['clientip'])) {
				$ctrlip = $ctrlip.'%';
				$_G['setting']['regctrl'] = $_G['setting']['ipregctrltime'];
				break;
			} else {
				$ctrlip = $_G['clientip'];
			}
		}
	} else {
		$ctrlip = $_G['clientip'];
	}

	if($_G['setting']['regctrl']) {
		if(C::t('common_regip')->count_by_ip_dateline($ctrlip, $_G['timestamp']-$_G['setting']['regctrl']*3600)) {
			if(!$return) {
				return str_replace('{regctrl}',$_G['setting']['ipregctrltime'],lang('message', 'register_ctrl'));
			} else {
				return 'Registration failed. Please try again!';
			}
		}
	}

	$setregip = null;
	if($_G['setting']['regfloodctrl']) {
		$regip = C::t('common_regip')->fetch_by_ip_dateline($_G['clientip'], $_G['timestamp']-86400);
		if($regip) {
			if($regip['count'] >= $_G['setting']['regfloodctrl']) {
				if(!$return) {
					return lang('message', 'register_flood_ctrl');
				} else {
					return;
				}
			} else {
				$setregip = 1;
			}
		} else {
			$setregip = 2;
		}
	}

	if($setregip !== null) {
		if($setregip == 1) {
			C::t('common_regip')->update_count_by_ip($_G['clientip']);
		} else {
			C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => 1, 'dateline' => $_G['timestamp']));
		}
	}
	$uid = uc_user_register(addslashes($username), $pwd, $email, '', '', $_G['clientip']);

	if($uid <= 0) {
		if(!$return) {
			if($uid == -1) {
				return lang('message', 'profile_username_illegal');
			} elseif($uid == -2) {
				return lang('message', 'profile_username_protect');
			} elseif($uid == -3) {
				return lang('message', 'profile_username_duplicate');
			} elseif($uid == -4) {
				return lang('message', 'profile_email_illegal');
			} elseif($uid == -5) {
				return lang('message', 'profile_email_domain_illegal');
			} elseif($uid == -6) {
				return lang('message', 'profile_email_duplicate');
			} else {
				return lang('message', 'undefined_action');
			}
		} else {
			return 'Registration failed. Please try again!';
		}
	}

	$init_arr = array('credits' => explode(',', $_G['setting']['initcredits']));
	C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);

	if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
		C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72)*3600);
		if($_G['setting']['regctrl']) {
			C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
		}
	}

	if($_G['setting']['regverify'] == 2) {
		C::t('common_member_validate')->insert(array(
			'uid' => $uid,
			'submitdate' => $_G['timestamp'],
			'moddate' => 0,
			'admin' => '',
			'submittimes' => 1,
			'status' => 0,
			'message' => '',
			'remark' => '',
		), false, true);
		manage_addnotify('verifyuser');
	}


	include_once libfile('function/stat');
	updatestat('register');
	return array(
		'uid' => $uid,
		'username' => $username,
		'password' => $pwd,
		'groupid' => $groupid,
	);
}
function aljqq_removeEmoji($text) {

    //return $text;
	if(strtolower(CHARSET) == 'gbk'){
		$text = diconv($text,CHARSET,'UTF-8');
	}
	$clean_text = "";

	$regexEmoticons = '/[\x{1F600}-\x{1F64F}]/u';
	$clean_text = preg_replace($regexEmoticons, '', $text);

	$regexSymbols = '/[\x{1F300}-\x{1F5FF}]/u';
	$clean_text = preg_replace($regexSymbols, '', $clean_text);

	$regexTransport = '/[\x{1F680}-\x{1F6FF}]/u';
	$clean_text = preg_replace($regexTransport, '', $clean_text);

	$regexMisc = '/[\x{2600}-\x{26FF}]/u';
	$clean_text = preg_replace($regexMisc, '', $clean_text);

	$regexDingbats = '/[\x{2700}-\x{27BF}]/u';
	$clean_text = preg_replace($regexDingbats, '', $clean_text);
	if(strtolower(CHARSET) == 'gbk'){
		$clean_text = diconv($clean_text,'UTF-8',CHARSET);
	}

	return $clean_text;

}

function aljqq_generate_password( $length = 8 ) {
 $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
 $password = '';
 for ( $i = 0; $i < $length; $i++ )
 {
  $password .= $chars[ mt_rand(0, strlen($chars) - 1) ];
 }

 return $password;
}

function aljqq_lcreate_avatar($uid,$src=''){
	$uid = sprintf("%09d", $uid);
	$dir = aljqq_lmkdir_by_uid($uid);
	$a = dfsockopen($src);
	file_put_contents($dir.substr($uid,-2).'_avatar_big.jpg', $a);
	file_put_contents($dir.substr($uid,-2).'_avatar_middle.jpg', $a);
	file_put_contents($dir.substr($uid,-2).'_avatar_small.jpg', $a);
	DB::update('common_member',array('avatarstatus'=>1),array('uid'=>$uid));
}
function aljqq_lmkdir_by_uid($uid, $dir = './uc_server/data/avatar/') {
	$uid = sprintf("%09d", $uid);
	$dir1 = substr($uid, 0, 3);
	$dir2 = substr($uid, 3, 2);
	$dir3 = substr($uid, 5, 2);
	!is_dir($dir.'/'.$dir1) && mkdir($dir.'/'.$dir1, 0777);
	!is_dir($dir.'/'.$dir1.'/'.$dir2) && mkdir($dir.'/'.$dir1.'/'.$dir2, 0777);
	!is_dir($dir.'/'.$dir1.'/'.$dir2.'/'.$dir3) && mkdir($dir.'/'.$dir1.'/'.$dir2.'/'.$dir3, 0777);
	return $dir.'/'.$dir1.'/'.$dir2.'/'.$dir3.'/';
}


function aljqq_mall_parenttips($type,$tips='',$url=''){
    global $_G;
    if($_G['mobile']){
        echo "<script>parent.tips(1,'".$tips."','".$url."');</script>";
    }else{
        echo "<script>parent.tips( '".$tips."','".$url."');</script>";
    }

	if($type == 1) {
		exit;
	}

}


function aljqq_mapp_userlogin($username, $password='', $questionid='', $answer='', $loginfield = 'username', $ip = '') {
	$return = array();

	if($loginfield == 'uid' && getglobal('setting/uidlogin')) {
		$isuid = 1;
	} elseif($loginfield == 'email') {
		$isuid = 2;
	} elseif($loginfield == 'auto') {
		$isuid = 3;
	} else {
		$isuid = 0;
	}

	if(!function_exists('uc_user_login')) {
		loaducenter();
	}
	if($isuid == 3) {
		if(!strcmp(dintval($username), $username) && getglobal('setting/uidlogin')) {
			$return['ucresult'] = uc_user_login($username, $password, 1, 0, $questionid, $answer, $ip);
		} elseif(isemail($username)) {
			$return['ucresult'] = uc_user_login($username, $password, 2, 0, $questionid, $answer, $ip);
		}
		if($return['ucresult'][0] <= 0 && $return['ucresult'][0] != -3) {
			$return['ucresult'] = uc_user_login(addslashes($username), $password, 0, 0, $questionid, $answer, $ip);
		}
	} else {
		$return['ucresult'] = uc_user_login(addslashes($username), $password, $isuid, 0, $questionid, $answer, $ip);
	}
	$tmp = array();
	$duplicate = '';
	list($tmp['uid'], $tmp['username'], $tmp['password'], $tmp['email'], $duplicate) = $return['ucresult'];
	$return['ucresult'] = $tmp;
	if($duplicate && $return['ucresult']['uid'] > 0 || $return['ucresult']['uid'] <= 0) {
		$return['status'] = 0;
		return $return;
	}

	$member = getuserbyuid($return['ucresult']['uid'], 1);
	if(!$member || empty($member['uid'])) {
		$return['status'] = -1;
		return $return;
	}
	$return['member'] = $member;
	$return['status'] = 1;
	if($member['_inarchive']) {
		C::t('common_member_archive')->move_to_master($member['uid']);
	}
	if($member['email'] != $return['ucresult']['email']) {
		C::t('common_member')->update($return['ucresult']['uid'], array('email' => $return['ucresult']['email']));
	}

	return $return;
}
function aljqq_CheckUsername($username) {
	global $_G;
	if(!$username) {
		$tmp_array=array('state' =>1);
	}else{
		$user = DB::fetch_first('select * from %t where username=%s',array('common_member',$username));
		if(!empty($user)) {
			$tmp_array=array('state' =>2);
		}else{
			loaducenter();
			$usern = aljqq_removeEmoji($username);
			if(uc_user_checkname($usern) <0) {
				 $tmp_array=array('state' =>3);
			}else{
				$tmp_array=array('state' =>4);
			}
		}
	}
	return $tmp_array;
}
