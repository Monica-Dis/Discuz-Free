<?php
if($_GET['act'] == 'delete') {
	if(submitcheck('formhash')){
		if(is_array($_POST['delete'])) {
			foreach($_POST['delete'] as $id) {
				DB::query('delete from %t where uid=%d',array('aljqq_user',$id));
			}
		}
		aljqq_mall_parenttips(1,ADMINSCRIPT.'?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljqq&pmod=userlist');
	}
}else{
	$currpage = $_GET['page'] ? intval($_GET['page']) : 1;
	$perpage = 12;
	$start = ($currpage - 1) * $perpage;
	$num = DB::result_first('select count(*) from %t',array('aljqq_user'));
	$userlist = DB::fetch_all('select * from %t order by dateline desc limit %d,%d',array('aljqq_user',$start,$perpage));
	$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljqq&pmod=userlist', 0, 11, false, false);
	include template('aljqq:userlist');
}
function aljqq_mall_parenttips($type,$url=''){
	echo "<script>parent.tips('".$type."','".$url."');</script>";
	if($type == 1) {
		exit;
	}	
}
//d'.'i'.'sm.ta'.'o'.'bao.com	
?>