<?php
/*
	Copyright (c) 2021 by dism.taobao.com
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljqq_user` (
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `openid` varchar(255) NOT NULL,
  `unionid` varchar(255) NOT NULL,
  `refresh_token` varchar(255) NOT NULL,
  `access_token` varchar(255) NOT NULL,
  `expires_in` int(10) NOT NULL,
  `qlogo` varchar(255) NOT NULL,
  `qzlogo` varchar(255) NOT NULL,
  `ret` int(10) NOT NULL,
  `msg` varchar(255) NOT NULL,
  `is_lost` int(10) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `province` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `is_yellow_vip` int(10) NOT NULL,
  `vip` int(10) NOT NULL,
  `yellow_vip_level` int(10) NOT NULL,
  `level` int(10) NOT NULL,
  `is_yellow_year_vip` int(10) NOT NULL,
  `dateline` int(10) NOT NULL,
  PRIMARY KEY (`uid`)
);
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>