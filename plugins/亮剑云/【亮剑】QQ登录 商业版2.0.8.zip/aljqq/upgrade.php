<?php
/*
	Copyright (c) 2021 by dism.taobao.com
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql ="ALTER TABLE ".DB::table('aljqq_user')." ADD `unionid` varchar(255) NOT NULL " ;
DB::query($sql,'SILENT');
$finish = TRUE;
?>