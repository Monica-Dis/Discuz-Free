<?php

/*
 * User: DisM!Ӧ������
 * ���²����http://t.cn/Aiux1Jx1
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (file_exists("source/plugin/aljibu/include/ibu_wx.php")) {
	require_once 'source/plugin/aljibu/include/ibu_wx.php';
}
$common_path = 'source/plugin/aljhtx/';
$version = '2018122011';
$mall_pluginid  = 'aljfl';
foreach(DB::fetch_all('select * from %t',array('common_plugin')) as $cpv){
    $cparray[$cpv['identifier']] = $cpv;
}
if (file_exists("source/plugin/".$mall_pluginid ."/public.php") && $cparray[$mall_pluginid]['available'] == 1) {
    
    require_once 'source/plugin/'.$mall_pluginid .'/public.php';
}
//From: DisM. taobao. Com
?>