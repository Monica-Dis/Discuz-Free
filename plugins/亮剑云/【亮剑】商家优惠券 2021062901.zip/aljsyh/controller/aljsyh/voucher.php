<?php

/**
 *
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * @version 1.0
 * @link http://docs.liangjianyun.com/
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class voucherAction{
    public $page;

    public function __construct($page) {
        $this->page = $page;
        $this->aljbdParameter();
        
    }
    /**
     * ��ȡ�Ż�ȯ
     *
     * @return void
     */
    public function voucher (){
        if($this->page->get->formhash == FORMHASH){
            $consume = DB::fetch_first('select * from %t where id=%d',array('aljbd_consume',$this->page->get->cid));
            $consumeLog = DB::result_first('select count(*) from %t where cid=%d and uid=%d',array('aljsyh_consume_log',$this->page->get->cid,$this->page->global->uid));
            $consumecount = DB::result_first('select count(*) from %t where cid=%d ',array('aljsyh_consume_log',$this->page->get->cid));
            if($consume['coupon_num'] <= $consumecount){
                $tips = array(
                    'code' => 400,
                    'tip' => lang("plugin/aljsyh","voucher_php_4")
                );
                echo json_encode(T::ajaxPostCharSet($tips));
                exit;
            }
            if($consume['coupon_limit'] && $consume['coupon_limit'] <= $consumeLog){
                $tips = array(
                    'code' => 400,
                    'tip' => lang("plugin/aljsyh","voucher_php_5").$consume['coupon_limit'].lang("plugin/aljsyh","voucher_php_6")
                );
                echo json_encode(T::ajaxPostCharSet($tips));
                exit;
            }
            if($consume['start'] && $consume['start'] > TIMESTAMP){
                $tips = array(
                    'code' => 400,
                    'tip' => lang("plugin/aljsyh","voucher_php_7").dgmdate($consume['start'],'Y-m-d H:i:s')
                );
                echo json_encode(T::ajaxPostCharSet($tips));
                exit;
            }
            if($consume['end'] && $consume['end'] < TIMESTAMP){
                $tips = array(
                    'code' => 400,
                    'tip' => lang("plugin/aljsyh","voucher_php_8")
                );
                echo json_encode(T::ajaxPostCharSet($tips));
                exit;
            }
            if($consume['rubbish']!=0 || $consume['draw_channel'] == 1){
                $tips = array(
                    'code' => 400,
                    'tip' => lang("plugin/aljsyh","voucher_php_9")
                );
                echo json_encode(T::ajaxPostCharSet($tips));
                exit;
            }
            $consumeLogInfo = DB::result_first('select count(*) from %t where cid=%d and uid=%d and status=1',array('aljsyh_consume_log',$this->page->get->cid,$this->page->global->uid));
            if($consumeLogInfo){
                $tips = array(
                    'code' => 400,
                    'tip' => lang("plugin/aljsyh","voucher_php_10")
                );
                echo json_encode(T::ajaxPostCharSet($tips));
                exit;
            }
            $insertArray = array(
                'uid'=>$this->page->global->uid,
                'username'=>$this->page->global->username,
                'receive_time'=>TIMESTAMP,
                'cid'=>$this->page->get->cid,
                'status'=>1,
            );
            DB::insert('aljsyh_consume_log',$insertArray);
            DB::query('update %t set downnum=downnum+1 where id=%d',array('aljbd_consume',$this->page->get->cid));
            $tips = array(
                'code' => 100,
                'tip' => lang("plugin/aljsyh","voucher_php_11")
            );
            echo json_encode(T::ajaxPostCharSet($tips));
            exit;
        }else{
            $tips = array(
                'code' => 400,
                'tip' => lang("plugin/aljsyh","voucher_php_12")
            );
            echo json_encode(T::ajaxPostCharSet($tips));
            exit;
        }
    }
    /**
     * �����Ż�ȯ
     * 
     * @return void
    */
    public function giftCoupons (){
        global $_G,$admin_status;
        
        $cid = $_GET['cid'];
        $consume = DB::fetch_first('select * from %t where id=%d',array('aljbd_consume',$cid));
        $uid = $consume['uid'];
        if(submitcheck('formhash')) {
            if (!$_GET['uid'] && !$_GET['username']) {
                echo "<script>parent.tips('".lang("plugin/aljsyh","voucher_php_1")."','');</script>";
                exit;
            }
            if($_GET['uid']){
                $username = DB::result_first('select username from %t WHERE uid=%d', array(
                    'common_member',
                    $_GET['uid']
                ));
                $uid = $_GET['uid'];
                $tips_text = 'uid'.lang("plugin/aljsyh","voucher_php_13");
            }else{
                $uid = DB::result_first('select uid from %t WHERE username=%s', array(
                    'common_member',
                    $_GET['username']
                ));
                $username = $_GET['username'];
                $tips_text = lang("plugin/aljsyh","voucher_php_14");
            }
            if(!$uid || !$username){
                echo "<script>parent.tips('".$tips_text."','');</script>";
                exit;
            }
            
            
            if(!$consume){
                echo "<script>parent.tips('".lang("plugin/aljsyh","voucher_php_2")."','');</script>";
                exit;
            }
            
            $insertArray = array(
                'uid'=>$uid,
                'username'=>$username,
                'receive_time'=>TIMESTAMP,
                'cid'=>$cid,
                'status'=>1,
            );
            DB::insert('aljsyh_consume_log',$insertArray);
            DB::query('update %t set downnum=downnum+1 where id=%d',array('aljbd_consume',$cid));
            $sendconsumetips = str_replace(array('{subject}'),array($consume['subject']),lang("plugin/aljsyh","voucher_php_15")); 
            $msm = '<a href="plugin.php?id=aljsyh&a=couponList&c=voucher">'.$sendconsumetips.'</a>';
            notification_add($uid, 'system',$msm,array('from_idtype'  => 'aljsyh'));
            echo "<script>parent.tips('".lang("plugin/aljsyh","voucher_php_3")."',function(){parent.location.href='plugin.php?id=aljbd&act=consumelist'});</script>";
            exit;
        }else{
            if(!$consume || $rubbish==1 || ($uid != $_G['uid'] && !$admin_status)){
                $this->page->WeuiResult(array('desc' => lang("plugin/aljsyh","voucher_php_16")));
            }
            $this->page->assign('consume', $consume);
            $this->page->assign('cid', $this->page->get->cid);
            $this->page->assign('navtitle', lang("plugin/aljsyh","voucher_php_17"));
            $this->page->assign('description', $this->description);
            
            $this->page->display();
        }
    }
    /**
     * ��ȯ��¼
     *
     *
     * 
     * @return void
     */
    public function adminCouponList () {
        if($_GET['cid'] > 0){
            $where = ' and cid='.intval($_GET['cid']);
        }
        
        $countStatus[0] = DB::result_first('select count(*) from %t a left join %t b on a.cid=b.id where 1'.$where,
            array('aljsyh_consume_log','aljbd_consume'));
        $countStatus[1] = DB::result_first('select count(*) from %t a left join %t b on a.cid=b.id where a.status = 1 and b.end>0 and b.end > '.TIMESTAMP.$where,
            array('aljsyh_consume_log','aljbd_consume'));
        $countStatus[2] = DB::result_first('select count(*) from %t a left join %t b on a.cid=b.id where a.status = 2 '.$where,
            array('aljsyh_consume_log','aljbd_consume'));
        $countStatus[3] = DB::result_first('select count(*) from %t a left join %t b on a.cid=b.id where a.status !=2 and b.end>0 and b.end < '.TIMESTAMP.$where,
            array('aljsyh_consume_log','aljbd_consume'));

        $this->page->assign('countStatus', $countStatus);
        $this->page->assign('navtitle', lang("plugin/aljsyh","voucher_php_18"));
        $this->page->display();
    }
    /**
     * �ҵ��Ż�ȯ
     *
     *
     * 
     * @return void
     */
    public function couponList () {
        global $_G,$admin_status;
        $do = $this->page->get->do;
        $currpage = $this->page->get->page ? $this->page->get->page : 1;
        $perpage = $_GET['limit'] ? intval($_GET['limit']) : 12;
        $start = ($currpage - 1) * $perpage;
        $conn = array('aljsyh_consume_log','aljbd_consume');
        if($admin_status && $_GET['i'] == 1){
            $where = 'where 1 ';
        }else{
            $where = 'where a.uid=%d';
            $conn[] = $this->page->global->uid;
        }
        
        if($this->page->get->status == 2){
            $where .= ' and a.status = '.$this->page->get->status;
        }else if($this->page->get->status == 3){
            $where .= ' and a.status !=2 and b.end>0 and b.end < '.TIMESTAMP;
        }else if($this->page->get->status == 1){
            $where .= ' and a.status = 1 and b.end>0 and b.end > '.TIMESTAMP;
        }
        if($_GET['dzAdmin'] == 1){
            $_GET['keyword']=T::ajaxGetCharSet($_GET['keyword']);
        }
        if($_GET['cid']>0){
            $where.=" and a.cid = %d ";
            $conn[] = $_GET['cid'];
        }
        if($_GET['keyword']){
            if($_GET['search_type'] == 1){
                $where.=" and a.cid = %d ";
                $conn[] = $_GET['keyword'];
                
            }else if($_GET['search_type'] == 2){
                $where.=" and a.uid = %d ";
                $conn[] = $_GET['keyword'];
            }else if($_GET['search_type'] == 3){
                $keyword = stripsearchkey($_GET['keyword']);
                $keyword = '%'.$keyword.'%';
                $where.=" and a.username like %s ";
                $conn[] = $keyword;
            }else{
                $keyword = stripsearchkey($_GET['keyword']);
                $keyword = '%'.$keyword.'%';

                $where.=" and b.subject like %s ";
                $conn[] = $keyword;
            }
        }
        
        $num = DB::result_first('select count(*) from %t a left join %t b on a.cid=b.id '.$where,$conn);
        
        $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljsyh&a=couponList&c=voucher&op=coupons&status='.$_GET['status'].'&keyword='.$_GET['keyword'].$urlmod, 0, 11, false, false);
        $this->page->assign('paging', $paging,true);
        $conn[] = $start;
        $conn[] = $perpage;
        $couponList = DB::fetch_all('select a.status sh_status,a.uid a_uid,a.username a_username,a.*,b.* from %t a left join %t b on a.cid=b.id '.$where.' order by a.id desc limit %d,%d',$conn);
        
        $goodstypename = array('0'=>lang("plugin/aljsyh","voucher_php_19"),'1'=>lang("plugin/aljsyh","voucher_php_20"),'2'=>lang("plugin/aljsyh","voucher_php_21"));

        foreach($couponList as $ck => $cv){
            $couponList[$ck]['clog'] = DB::result_first('select count(*) from %t where cid=%d and status=1',array('aljsyh_consume_log',$cv['id']));
            $couponList[$ck]['bdname'] = cutstr(DB::result_first('select name from %t where id=%d',array('aljbd',$cv['bid'])),20,'');
            $couponList[$ck]['start'] = dgmdate($cv['start'],'Y.m.d');
            $couponList[$ck]['status'] = $cv['sh_status'];
            $couponList[$ck]['reduction'] = floatval($cv['reduction']);
            $couponList[$ck]['full'] = floatval($cv['full']);
            if($cv['end'] < TIMESTAMP){
                $couponList[$ck]['status'] = 3;
            }
            if($couponList[$ck]['status'] == 1){
                $couponList[$ck]['status_text'] = lang("plugin/aljsyh","voucher_php_22");
            }else if($couponList[$ck]['status'] == 2){
                $couponList[$ck]['status_text'] = lang("plugin/aljsyh","voucher_php_23");
            }else if($couponList[$ck]['status'] == 3){
                $couponList[$ck]['status_text'] = lang("plugin/aljsyh","voucher_php_24");
            }
            $couponList[$ck]['end'] = dgmdate($cv['end'],'Y.m.d');
            $couponList[$ck]['receive_time'] = dgmdate($cv['receive_time'],'u');
            $couponList[$ck]['use_time'] = $cv['use_time'] ? dgmdate($cv['use_time'],'u') : '--';
            if($cv['available_goods'] == 1){
                $goodstype = explode(',',$cv['goodstype']);
                $goodstypenamestr = '';
                foreach($goodstype as $gtv){
                    $goodstypenamestr .=  $goodstypename[$gtv].',';
                }
                $couponList[$ck]['goodstypename'] = trim($goodstypenamestr,',');
            }else{
                $couponList[$ck]['goodstypename'] = '';
            }
            if($cv['coupon_type'] >= 9){
                if($cv['coupon_type'] == 9){
                    $couponList[$ck]['dataUrl'] = 'plugin.php?id=aljbd&act=attend';
                }else{
                    $couponList[$ck]['dataUrl'] = 'plugin.php?id=aljtcc&c=index&a=index&ajax=yes&card_id=1';
                }
            }else{
                $couponList[$ck]['dataUrl'] = 'plugin.php?id=aljbd&act=view&bid='.$cv['bid'].'&op=goods';
            }
            if($cv['coupon_type'] == 1){
                $couponList[$ck]['coupon_type_text'] = lang("plugin/aljsyh","voucher_php_25");
            }else if($cv['coupon_type'] == 2){
                $couponList[$ck]['coupon_type_text'] = lang("plugin/aljsyh","voucher_php_26");
            }else if($cv['coupon_type'] == 3){
                $couponList[$ck]['coupon_type_text'] = lang("plugin/aljsyh","voucher_php_27");
            }else if($cv['coupon_type'] == 4){
                $couponList[$ck]['coupon_type_text'] = 'ͬ�Ǵ���ȯ ';
            }else if($cv['coupon_type'] == 5){
                $couponList[$ck]['coupon_type_text'] = lang("plugin/aljsyh","voucher_php_28");
            }else if($cv['coupon_type'] == 7){
                $couponList[$ck]['coupon_type_text'] = lang("plugin/aljsyh","voucher_php_29");
            }else if($cv['coupon_type'] == 9){
                $couponList[$ck]['coupon_type_text'] = lang("plugin/aljsyh","voucher_php_30");
            }else if($cv['coupon_type'] == 10){
                $couponList[$ck]['coupon_type_text'] = lang("plugin/aljsyh","voucher_php_31");
            }
        }
        $this->page->assign('couponList', $couponList);
        if($do == 'ajax'){
            
            if($couponList){
                if($this->page->global->mobile && $_GET['dzAdmin'] != 1){
                    echo json_encode(T::ajaxPostCharSet($couponList));
                }else{
                    
                    T::responseJson(array(
                        'code' => 0,
                        'msg' => "",
                        'count' => $num,
                        'data' => $couponList
                    ));
                }
                
            }else{
                if($this->page->global->mobile && $_GET['dzAdmin'] != 1) {
                    echo '1';
                }else{
                    T::responseJson(array(
                        'code' => 0,
                        'msg' => "",
                        'count' => 0,
                        'data' => array()
                    ));
                }
            }
            exit;
        }else{
            $countStatus[1] = DB::result_first('select count(*) from %t a left join %t b on a.cid=b.id where a.uid=%d and a.status = 1 and b.end>0 and b.end > '.TIMESTAMP,
                array('aljsyh_consume_log','aljbd_consume',$this->page->global->uid));
            $countStatus[2] = DB::result_first('select count(*) from %t a left join %t b on a.cid=b.id where a.uid=%d and a.status = 2 ',
                array('aljsyh_consume_log','aljbd_consume',$this->page->global->uid));
            $countStatus[3] = DB::result_first('select count(*) from %t a left join %t b on a.cid=b.id where a.uid=%d and b.end>0 and b.end < '.TIMESTAMP,
                array('aljsyh_consume_log','aljbd_consume',$this->page->global->uid));

            $this->page->assign('countStatus', $countStatus);

            $this->page->assign('navtitle', lang("plugin/aljsyh","voucher_php_32"));
            
            $this->page->display();
        }
    }
    /**
     * Ʒ���̼ҹ�������ע��
     *
     *
     * @return void
     */
    public function aljbdParameter(){
        global $Html5Plusapp,
               $immersed,
               $pc_footer_new_top_arr,
               $pc_footer_new_top_tel,
               $pc_footer_new_top_kefu,
               $pc_footer_new_cron_c1_arr,
               $pc_footer_new_cron_c2_arr,
               $pc_footer_new_cron_c3_arr,
               $pc_footer_new_cron_c4_arr,
               $pc_footer_new_cron_c5_arr,
               $pc_footer_new_cron_qrcode_arr,
               $alltype,
               $index_dh_types,
               $ress;
        
        $settings=C::t('#aljbd#aljbd_setting')->range();
        $mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_common_footernav']['value']));
        foreach($mobile_common_footernav as $key=>$value){
            $arr=explode('|',$value);
            $mobile_common_footernav_arr[]=$arr;
        }
        $this->page->assign('pluginid', 'aljbd');
        $this->page->assign('Html5Plusapp', $Html5Plusapp);
        $this->page->assign('immersed', $immersed);
        $this->page->assign('settings', $settings,true);
        $this->page->assign('mobile_common_footernav_arr', $mobile_common_footernav_arr,true);
        $this->page->assign('common_template_pluginid', 'aljbd');
        $this->page->assign('common_path', 'source/plugin/aljhtx/');

        $this->page->assign('pc_footer_new_top_arr', $pc_footer_new_top_arr,true);
        $this->page->assign('pc_footer_new_top_tel', $pc_footer_new_top_tel,true);
        $this->page->assign('pc_footer_new_top_kefu', $pc_footer_new_top_kefu,true);
        $this->page->assign('pc_footer_new_cron_c1_arr', $pc_footer_new_cron_c1_arr,true);
        $this->page->assign('pc_footer_new_cron_c2_arr', $pc_footer_new_cron_c2_arr,true);
        $this->page->assign('pc_footer_new_cron_c3_arr', $pc_footer_new_cron_c3_arr,true);
        $this->page->assign('pc_footer_new_cron_c4_arr', $pc_footer_new_cron_c4_arr,true);
        $this->page->assign('pc_footer_new_cron_c5_arr', $pc_footer_new_cron_c5_arr,true);
        $this->page->assign('pc_footer_new_cron_qrcode_arr', $pc_footer_new_cron_qrcode_arr,true);
        $this->page->assign('alltype', $alltype,true);
        $this->page->assign('index_dh_types', $index_dh_types,true);
        $this->page->assign('ress', $ress,true);
        
        
        $price_unit = '&#65509;';
        $this->page->assign('price_unit', $price_unit,true);
    }
}

