<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
if($_G['cache']['plugin']['aljbdx']['is_aljqb'] || $_G['cache']['plugin']['aljgwc']['aljbd']){
    if($_G['cache']['plugin']['aljbdx']['is_aljqb']){
        $tips = '&#35831;&#21069;&#24448;&#38065;&#21253;&#35774;&#32622; <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=aljqb&pmod=paysetting" style="color:red;" target="_blank">&#28857;&#20987;&#21069;&#24448;</a>';
    }else{
        $tips = '&#35831;&#21069;&#24448;&#36141;&#29289;&#36710;&#35774;&#32622; <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=aljgwc&pmod=paysetting" style="color:red;" target="_blank">&#28857;&#20987;&#21069;&#24448;</a>';
    }
    echo '<table class="tb tb2 nobdb">
<tbody><tr><th colspan="15" class="partition">'.$tips.'</th></tr>';
    exit;
}
$_GET=dhtmlspecialchars($_GET);
if(submitcheck('formhash')){
	foreach($_GET['settingsnew'] as $k=>$v){
		if(!C::t('#aljbd#aljbd_setting')->fetch($k)){
			C::t('#aljbd#aljbd_setting')->insert(array('key'=>$k,'value'=>trim($v)));
		}else{
			C::t('#aljbd#aljbd_setting')->update_value_by_key(trim($v),$k);
		}
	}
	cpmsg(lang('plugin/aljbd','tg18'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljbd&pmod=alipaysetting', 'succeed');
}else{
	$settings=C::t('#aljbd#aljbd_setting')->range();
	include template('aljbd:alipaysetting');
}
//From: Dism��taobao��com
?>