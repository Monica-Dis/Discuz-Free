<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
$plugin = DB::fetch_first('select * from %t where identifier = %s', array('common_plugin', 'aljhtx'));
if(empty($plugin)){
    cpmsg('&#35831;&#20808;&#23433;&#35013;&#21830;&#23478;&#21161;&#25163;&#25554;&#20214;');
}
$plugin = DB::fetch_first('select * from %t where identifier = %s and available=1', array('common_plugin', 'aljhtx'));
if(empty($plugin)){
    cpmsg('&#35831;&#20808;&#21551;&#29992;&#21830;&#23478;&#21161;&#25163;&#25554;&#20214;');
}
if($_G['cache']['plugin']['aljht']['on']){
    echo '<iframe style="width:100%;height:100%;min-height:760px;border:none;" src="plugin.php?id=aljhtx&c=aljbd&a=order&ajax=yes&type=10&dzAdmin=1"></iframe>';
    exit;
}
//$_GET=dhtmlspecialchars($_GET);

if(submitcheck('formhash')){
	if($_FILES['logo']['tmp_name']) {
		$picname = $_FILES['logo']['name'];
		$picsize = $_FILES['logo']['size'];
	
		if ($picname != "") {
			$type = strtolower(strrchr($picname, '.'));
			if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
				showerror(lang('plugin/aljbd','s19'));
			}
			$rand = rand(100, 999);
			$pics = date("YmdHis") . $rand . $type;
			$logo = "source/plugin/aljbd/images/logo/". $pics;
			if(@copy($_FILES['logo']['tmp_name'], $logo)||@move_uploaded_file($_FILES['logo']['tmp_name'], $logo)){
				@unlink($_FILES['logo']['tmp_name']);
			}
		}
	}

	if(empty($logo)){
		$logo = $_GET['logo'];
	}

	
	$record = C::t('#aljbd#aljbd_setting')->fetch('logo');

	if($_GET['deletelogo']){
		C::t('#aljbd#aljbd_setting') -> delete('logo');
		if($record['value']){
			unlink($record['value']);
		}
	}
    if($logo){
        if(!$record){
            C::t('#aljbd#aljbd_setting')->insert(array('key'=>'logo','value'=>$logo));
        }else{
            C::t('#aljbd#aljbd_setting')->update_value_by_key($logo,'logo');
        }
    }

	
	if($_FILES['lazyloadlogo']['tmp_name']) {
		$picname = $_FILES['lazyloadlogo']['name'];
		$picsize = $_FILES['lazyloadlogo']['size'];
	
		if ($picname != "") {
			$type = strtolower(strrchr($picname, '.'));
			if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
				showerror(lang('plugin/aljbd','s19'));
			}
			$rand = rand(100, 999);
			$pics = date("YmdHis") . $rand . $type;
			$logo1 = "source/plugin/aljbd/images/logo/". $pics;
			if(@copy($_FILES['lazyloadlogo']['tmp_name'], $logo1)||@move_uploaded_file($_FILES['lazyloadlogo']['tmp_name'], $logo1)){
				@unlink($_FILES['lazyloadlogo']['tmp_name']);
			}
		}
	}

	if(empty($logo1)){
		$logo1 = $_GET['lazyloadlogo'];
	}

	
	$record1 = C::t('#aljbd#aljbd_setting')->fetch('lazyloadlogo');

	if($_GET['deletelazyloadlogo']){
		C::t('#aljbd#aljbd_setting') -> delete('lazyloadlogo');
		if($record1['value']){
			unlink($record1['value']);
		}
	}
    if($logo1){
        if(!$record1){
            C::t('#aljbd#aljbd_setting')->insert(array('key'=>'lazyloadlogo','value'=>$logo1));
        }else{
            C::t('#aljbd#aljbd_setting')->update_value_by_key($logo1,'lazyloadlogo');
        }
    }

	if(!C::t('#aljbd#aljbd_setting')->fetch('mhot')){
		C::t('#aljbd#aljbd_setting')->insert(array('key'=>'mhot','value'=>$_GET['mhot']));
	}else{
		if($_GET['mhot']){
			C::t('#aljbd#aljbd_setting')->update_value_by_key($_GET['mhot'],'mhot');
		}
	}

	if(!C::t('#aljbd#aljbd_setting')->fetch('mhotmore')){
		C::t('#aljbd#aljbd_setting')->insert(array('key'=>'mhotmore','value'=>$_GET['mhotmore']));
	}else{
		if($_GET['mhotmore']){
			C::t('#aljbd#aljbd_setting')->update_value_by_key($_GET['mhotmore'],'mhotmore');
		}
	}

	foreach($_GET['settingsnew'] as $k=>$v){
		if(in_array($k, array('mgroups','managegroups'))){
			$v = (string)serialize($v);
		}
		if(!C::t('#aljbd#aljbd_setting')->fetch($k)){
			C::t('#aljbd#aljbd_setting')->insert(array('key'=>$k,'value'=>$v));
		}else{
			C::t('#aljbd#aljbd_setting')->update_value_by_key($v,$k);
		}
	}
	savecache('aljbd_settings', '');
	cpmsg(lang('plugin/aljbd','s11'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljbd&pmod=setting&act='.$_GET['act'].'&b='.$_GET['b'], 'succeed');
}else{
    require_once 'source/plugin/aljbd/include/initalData.php';
	$record = C::t('#aljbd#aljbd_setting')->fetch('logo');
	$logo = $record['value'];
	$record1 = C::t('#aljbd#aljbd_setting')->fetch('lazyloadlogo');
	$lazyloadlogo = $record1['value'];
	$setting = C::t('#aljbd#aljbd_setting')->range();
	$settings= $setting;
	include template('aljbd:setting');
}
function l_groups($group,$type=0){
	global $_G,$config,$lang,$settings;
	if($type){
        $var['type'] = '<select name="'.$group.'"><option value="">'.cplang('plugins_empty').'</option>';
        $var['value'] = $_GET['groupid'];
    }else{
        $var['description'] = ($var['description'] ? (isset($lang[$var['description']]) ? $lang[$var['description']] : $var['description'])."\n" : '').$lang['plugins_edit_vars_multiselect_comment']."\n".$var['comment'];
        $var['value'] = dunserialize($settings[$group]['value']);
        $var['type'] = '<select name="settingsnew['.$group.'][]" size="10" multiple="multiple"><option value=""'.(@in_array('', $var['value']) ? ' selected' : '').'>'.cplang('plugins_empty').'</option>';
    }

	$var['value'] = is_array($var['value']) ? $var['value'] : array($var['value']);
	
	$query = C::t('common_usergroup')->range_orderby_credit();
	$groupselect = array();
	foreach($query as $group) {
		$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
		$groupselect[$group['type']] .= '<option value="'.$group['groupid'].'"'.(@in_array($group['groupid'], $var['value']) ? ' selected' : '').'>'.$group['grouptitle'].'</option>';
	}
	$var['type'] .= '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
		($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
		($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
		'<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup></select>';
	return $var['type'];
}
//From: Dism��taobao��com
?>