<?php
/**
 * ͨ��֪ͨ�ӿ�
 * ====================================================
 * ֧����ɺ�΢�Ż�����֧�����û���Ϣ���͵��̻��趨��֪ͨURL��
 * �̻����ջص���Ϣ�󣬸�����Ҫ�趨��Ӧ�Ĵ������̡�
 *
*/
define('DISABLEXSSCHECK', true);
require '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
if(!isset($_G['cache']['plugin'])) {
	loadcache('plugin');
}
$settings=C::t('#aljbd#aljbd_setting')->range();
//�洢΢�ŵĻص�
$xml = file_get_contents("php://input");
$data = xmlToArray($xml);
$data['out_trade_no'] = $data['out_trade_no']?$data['out_trade_no']:$_GET['out_trade_no'];
$data['transaction_id'] = $data['transaction_id']?$data['transaction_id']:$_GET['trade_no'];
$order = C::t('#aljbd#aljbd_order') -> fetch($data['out_trade_no']);
$good = C::t('#aljbd#aljbd_goods') -> fetch($order['sid']);
$returnsign = $data['sign'];
$tmpdata = $data;
unset($tmpdata['sign']);
if($order['payment'] == '1'){
	$checkSign = getSign($tmpdata,$settings['key']['value']);
	$check = $checkSign == $returnsign?true:false;
	$wechat = 1;
	$pay = 1;
}else if($order['payment'] == '3'){
	$checkSign = getSign($tmpdata,$settings['key']['value']);
	$check = $checkSign == $returnsign?true:false;
	$wechat = 1;//΢��
	$pay = 1;
}else{
	$check = getSignVeryfy($_GET,$_GET['sign'],$order['mobile']);
	//file_put_contents('test.txt',$check.'=>'.$_GET['sign'].',',FILE_APPEND);
	if($_GET['trade_status'] == 'TRADE_SUCCESS' || $_GET['trade_status'] == 'WAIT_SELLER_SEND_GOODS'){
		$pay = 1;//֧����
	}else if($_GET['trade_status'] == 'WAIT_BUYER_CONFIRM_GOODS'){
		$pay = 2;//֧����
	}else if($_GET['trade_status'] == 'TRADE_FINISHED'){
		$pay = 3;//֧����
	}
}
$_G['siteurl'] = 'http%3a//'.$_SERVER['HTTP_HOST'];
if($check){
		if($wechat){
			$returnParameters["return_code"]="SUCCESS";
		}else{
			$return = 'success';//֧����
		}

		if ($order['status'] == 1 && $pay == 1){

				$status = 2;
				C::t('#aljbd#aljbd_order')->update($data['out_trade_no'], array('status' => $status, 'buyer' => "$data[trade_no]", 'confirmdate' => $_G['timestamp']));
				C::t('#aljbd#aljbd_goods')->update_num2_by_id($good['id'],$order['amount']);

				notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&gid='.$good['id'].'">'.$good['name'].'</a>',$_G['cache']['plugin']['aljbd']['suctips'])));
				$brand = C::t('#aljbd#aljbd') -> fetch($good['bid']);
				notification_add($good['uid'], 'system',str_replace('{orderid}','<a href="plugin.php?id=aljbd&act=orderlist">'.$data['out_trade_no'].'</a>',str_replace('{username}',$brand['username'],str_replace('{name}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&gid='.$good['id'].'">'.$good['name'].'</a>',$_G['cache']['plugin']['aljbd']['notify_merchant'])))));
				if($_G['cache']['plugin']['aljbd']['time']){
					$_G['siteurl'] = 'http://'.$_SERVER['HTTP_HOST'];
					$email_first = C::t("common_member")->fetch($order['uid']);
					$email = $email_first['email'];
					if($email_first['email']){
						$m=str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="'.$_G['siteurl'].'/plugin.php?id=aljbd&act=goodview&gid='.$good['id'].'">'.$good['name'].'</a>',$_G['cache']['plugin']['aljbd']['suctips']));
						require_once libfile('function/mail');
						sendmail_cron($email,$_G['cache']['plugin']['aljbd']['mailtitle'].'@'.gmdate('Y-m-d H:i:s',$_G['timestamp']+8*3600),$m);
					}
					$email_f = C::t("common_member")->fetch($good['uid']);
					$e = $email_f['email'];
					if($email_f['email']){
						$me=str_replace('{orderid}','<a href="'.$_G['siteurl'].'/plugin.php?id=aljbd&act=orderlist">'.$data['out_trade_no'].'</a>',str_replace('{username}',$brand['username'],str_replace('{name}',$order['username'],str_replace('{shopname}','<a href="'.$_G['siteurl'].'/plugin.php?id=aljbd&act=goodview&gid='.$good['id'].'">'.$good['name'].'</a>',$_G['cache']['plugin']['aljbd']['notify_merchant']))));
						$t=str_replace('{orderid}',$data['out_trade_no'],$_G['cache']['plugin']['aljbd']['notify_merchant_title']);
						require_once libfile('function/mail');
						sendmail_cron($e,$t,$me);
					}
			}
	}
}else{
	if($wechat){
		$returnParameters["return_code"]="FAIL";
		$returnParameters["return_msg"]="sign faild";
	}else{
		$return = 'fail';//֧����
	}
}
if($wechat){
	$returnXml = arrayToXml($returnParameters);
	echo $returnXml;
}else{//֧����
	echo $return;
	exit;
}
function xmlToArray($xml){
    //��XMLתΪarray
    //��ֹ�����ⲿxmlʵ��
    libxml_disable_entity_loader(true);
	$array_data = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
	return $array_data;
}
function getSign($Obj,$apikey=''){
	foreach ($Obj as $k => $v)
	{
		$parameters[$k] = $v;
	}
	ksort($parameters);
	$string = formatBizQueryParaMap($parameters, false);
	$string = $string."&key=$apikey";
	$string = md5($string);
	$result_ = strtoupper($string);
	return $result_;
}
function formatBizQueryParaMap($paraMap, $urlencode=false){
	$buff = "";
	ksort($paraMap);
	foreach ($paraMap as $k => $v)
	{
		if($urlencode)
		{
		   $v = urlencode($v);
		}
		$buff .= $k . "=" . $v . "&";
	}
	$reqPar;
	if (strlen($buff) > 0)
	{
		$reqPar = substr($buff, 0, strlen($buff)-1);
	}
	return $reqPar;
}
function getSignVeryfy($parameters,$sign='',$mobile=''){
	global $_G,$config,$settings;
	if(empty($parameters)) {
		return false;
	}

	ksort($parameters);

	$string = getAlipaySign($parameters,$settings['ec_securitycode']['value']);

	$veryfy_url = 'http://notify.alipay.com/trade/notify_query.do?'."partner=" .$settings['ec_partner']['value']. "&notify_id=" . $parameters['notify_id'];
	if($string == $sign && postdata($veryfy_url)){
		return true;
	}
	return false;
}
function getAlipaySign($Obj,$apikey=''){
	foreach ($Obj as $k => $v){
		if($k == "sign" || $k == "sign_type" || $v == ""){
			continue;
		}else{
			$parameters[$k] = $v;
		}
	}
	ksort($parameters);
	$string = formatBizQueryParaMap($parameters);
	$string = $string.$apikey;
	$string = md5($string);
	return $string;
}
/**/
function postdata($url, $para='', $input_charset = '', $follow=0) {
	//global $_G;
    if (trim($input_charset) != '') {
        $url = $url."_input_charset=".$input_charset;
    }
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_HEADER, 0 );
    curl_setopt($curl,CURLOPT_RETURNTRANSFER, 1);
	//curl_setopt ($ch,CURLOPT_REFERER,$_G['siteurl']);
	if($para){
		curl_setopt($curl,CURLOPT_POST,true);
		curl_setopt($curl,CURLOPT_POSTFIELDS,$para);
	}
    if($follow) {
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($curl, CURLOPT_MAXREDIRS, 3);
    }
    $responseText = curl_exec($curl);
    $headers = curl_getinfo($curl);
    curl_close($curl);
    if($para&& $headers && $headers['url'] && $follow) {
         header('Location: '.$headers['url']);
    }
    //var_dump( curl_error($curl) );
    return $responseText;
}
?>
