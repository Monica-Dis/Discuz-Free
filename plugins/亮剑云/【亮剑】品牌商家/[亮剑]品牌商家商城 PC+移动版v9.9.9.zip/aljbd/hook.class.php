<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Deined');
} 
class plugin_aljbd {
	function __construct() {
	
	}
	function global_footer(){
		global $_G;
		$config = $_G ['cache'] ['plugin'] ['aljbd'];
		$time = $config['time'];
		if(!isset($_G['cookie']['emailaljbd'])&&$time){
			return '<script src="plugin.php?id=aljbd:misc_sendmail"></script>';
		}
	}
}
class plugin_aljbd_forum extends plugin_aljbd {
	
	/**���ڸ�����Ϣ��ʾ����**/
	function viewthread_sidetop_output() {
		global $_G,$postlist;
		$config = $_G['cache']['plugin']['aljbd'];
		
		if(!$config['ista']||!file_exists('source/plugin/aljbd/com/ta.php')){
			return;
		}
		$i = 0;
		foreach($postlist as $key=>$value){
			if(!$value['authorid']){
				continue;
			}
			$check = DB::result_first(" select * from ".DB::table('aljbd')." where uid=".$value['authorid']." and status=1");
			if (!$check) {
				$i++;
				continue;
				//$sharecode[]='<p style="background: url(\'../source/plugin/aljbd/images/button.gif\') no-repeat!important;overflow: hidden;text-align: center;width: 110px;"><a style="color: #FFFFFF;font-size: 14px;"  href="plugin.php?id=aljbd&amp;act=attend" >'.lang('plugin/aljbd','hook_1').'</a></p>';
			}else{
				$sharecode[$i]='<p style="background: url(\'source/plugin/aljbd/images/button.gif\') no-repeat!important;background-position: right 0%!important;overflow: hidden;text-align: center;width: 110px;"><a  style="color: #FFFFFF;font-size: 14px;" onclick="showWindow(\'aljbd\',\'plugin.php?id=aljbd&act=glmsg&formhash='.FORMHASH.'&username='.$value['username'].'&uid='.$value['authorid'].'\');" href="javascript:;">'.lang('plugin/aljbd','hook_2').'</a></p>';
			}
			$i++;
		}
		return $sharecode;
	}
} 
//From: dis'.'m.tao'.'bao.com
?>