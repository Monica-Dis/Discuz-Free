<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
exit('Access Denied');
if(!$_GET['aaid']){
    showmessage(lang('plugin/aljbd','aljbd_6'));
}
if(empty($_G['uid'])){
    showmessage(lang('plugin/aljbd','s39'));
}
if($_GET['formhash']!=formhash()){
    showmessage(lang('plugin/aljbd','aljbd_7'));
}
$al=C::t('#aljbd#aljbd_album_attachments')->fetch($_GET['aaid']);
if($al){
    unlink($al['pic']);
    unlink($al['pic'].'.72x72.jpg');
    unlink($al['pic'].'.100x100.jpg');
    unlink($al['pic'].'.550x550.jpg');
    C::t('#aljbd#aljbd_album_attachments')->delete($_GET['aaid']);
}

DB::query("UPDATE ".DB::table('aljbd_album')." SET picnum=picnum-1 WHERE id='".$_GET['aid']."'", 'UNBUFFERED');
if(!DB::result_first("select count(*) from ".DB::table('aljbd_album_attachments')." where aid=".$_GET['aid'])){
    DB::query("UPDATE ".DB::table('aljbd_album')." SET subjectimage='' WHERE id='".$_GET['aid']."'", 'UNBUFFERED');
    DB::query("UPDATE ".DB::table('aljbd_album')." SET picnum=0 WHERE id='".$_GET['aid']."'", 'UNBUFFERED');
}
showmessage(lang('plugin/aljbd','admin_8'),'plugin.php?id=aljbd&act=albumall&aid='.$_GET['aid']);
?>