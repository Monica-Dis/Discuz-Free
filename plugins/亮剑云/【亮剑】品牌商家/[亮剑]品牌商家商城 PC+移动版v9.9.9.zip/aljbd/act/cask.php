<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('formhash')){

    if(empty($_GET['commentmessage_2'])){
        showerror(lang('plugin/aljbd','s33'));
    }
    if(empty($_G['uid'])){
        showerror(lang('plugin/aljbd','s21'));
    }
    if($_G['cache']['plugin']['aljht']){
        $status = 1;
    }
    $insertarray=array(
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'content'=>$_GET['commentmessage_2'],
        'bid'=>$bid,
        'dateline'=>TIMESTAMP,
        'upid'=>0,
        'cid'=>$_GET['cid'],
        'status'=>$status,
    );
    C::t('#aljbd#aljbd_comment_consume')->insert($insertarray);
    if($_G['cache']['plugin']['aljht'] && file_exists("source/plugin/aljht/include/aljbd/creplytips.php")){
        include 'source/plugin/aljht/include/aljbd/creplytips.php';
    }else{
        $replytips = lang('plugin/aljbd','s34');
    }
    showmsg($replytips);
}
//From: Dism��taobao��com
?>