<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($bd['vipid']) {
    $vipdata = DB::fetch_first('select * from %t where id=%d', array('aljbd_vip', $bd['vipid']));
}

if(submitcheck('formhash')){
    if(empty($bid)){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','s51')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','s51'));
        }
    }
    if($settings['is_attes']['value']){
        $sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
        if(!$sign){
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('&#24215;&#38138;&#24517;&#39035;&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#30456;&#20876;','');</script>";
                exit;
            }else{
                showerror('&#24215;&#38138;&#24517;&#39035;&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#30456;&#20876;');
            }
        }
    }
    if(empty($_GET['albumname'])){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','album_1')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','album_1'));
        }
    }
    $insertarray = array(
        'bid'=>$bid,
        'albumname'=>$_GET['albumname'],
        'description'=>$_GET['description'],
    );

    if ($_GET['pic']) {
        foreach ($_GET['pic'] as $tmp_key => $tmp_value) {
            if (strpos($tmp_value,$oss_domain) !== false) {
                $insertarray['subjectimage'] = $tmp_value;
            }else if (is_file($tmp_value)) {
                $insertarray['subjectimage'] = $tmp_value;
            } else {
                unlink($a['pic']);
                $insertarray['subjectimage'] = T::saveimg($tmp_value,$image_path.'album/');
            }
        }
    }

    if($a){
        C::t('#aljbd#aljbd_album')->update($_GET['aid'],$insertarray);
    }else{
        $insertarray[uid] = $bd['uid'];
        $insertarray[username] = $bd['username'];
        $insertarray[dateline] = TIMESTAMP;
        $insertarray[displayorder] = 100;

        if($vipdata['is_album'] >0 && file_exists("source/plugin/aljht/include/aljbd/addalbum_send.php") && !in_array($_G['groupid'],$admingroups)){
            require_once 'source/plugin/aljht/include/aljbd/addalbum_send.php';
        }
        C::t('#aljbd#aljbd_album')->insert($insertarray);
    }
    $sh_tips = $sh_tips ? $sh_tips : lang('plugin/aljbd','s53');
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('".$sh_tips."',function(){parent.location.href='plugin.php?id=aljbd&act=albumlist&bid=".$bid."';});</script>";
        exit;
    }else{
        showmsg($sh_tips);
    }
}else{
    if(empty($_G['uid'])){
        dheader("location:".$login_callback);
    }
    if(empty($bid)){
        $info = array('desc' => lang('plugin/aljbd','s51'));
        $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
        aljbdShowTips($info);
    }

    if($admin_status){
        $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','','');//����Ա
    }else{
        if($staff && $bid){//���̵�ԱȨ��
            $bdlist = DB::fetch_all('select * from %t where id = %d',array('aljbd',$staff['store_id']));
        }else{
            $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','',$_G['uid']);//����
        }
    }
    
    if($bd['vipid']){
        $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$bd['vipid']));
        $brandnum['album']=$vipdata['album'];
        $bnum = C::t('#aljbd#aljbd_album')->count_by_uid_bid($_G['uid'], '', 0);
        if ($brandnum['album']) {
            if ($brandnum['album'] == $checksign) {
                $info = array('desc' => lang('plugin/aljbd', 'noauth') . $albumtips);
                $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                aljbdShowTips($info);
            }
            if ($bnum >= $brandnum['album']) {
                $info = array('desc' => lang('plugin/aljbd', 'groups_1') . $brandnum['album'] . lang('plugin/aljbd', 'groups_6') . $albumtips);
                $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                aljbdShowTips($info);
            }
        }
    }
    if($yhzqx) {
        $brandnum = C::t('#aljbd#aljbd_usergroup')->fetch($_G['groupid']);
        $bnum = C::t('#aljbd#aljbd_album')->count_by_uid_bid($_G['uid'], '', 0);
        if ($brandnum['album'] && file_exists('source/plugin/aljbd/com/yhzqx.php')) {
            if ($brandnum['album'] == $checksign) {
                $info = array('desc' => lang('plugin/aljbd', 'noauth') . $albumtips);
                $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                aljbdShowTips($info);
            }
            if ($bnum >= $brandnum['album']) {
                $info = array('desc' => lang('plugin/aljbd', 'groups_1') . $brandnum['album'] . lang('plugin/aljbd', 'groups_6') . $albumtips);
                $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                aljbdShowTips($info);
            }
        }
    }
    if($settings['is_attes']['value'] && $bid && $_GET['act'] == 'addalbum'){
        $sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
        if(!$sign){
            $info = array('desc' => lang('plugin/aljbd','aljbd_php_20'));
            if($_G['mobile']){
                $toUrl = 'plugin.php?id=aljbd&act=attestation&bid='.$bid;
            }else{
                $toUrl = 'plugin.php?id=aljht&act=admin&op=attestation&do=addattestation&bid='.$bid.'&mod=my';
            }
            $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_16'), 'url' => $toUrl);
            $info['btn_default'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
            aljbdShowTips($info);
        }
    }
    $navtitle = '&#28155;&#21152;&#30456;&#20876;';
    $metakeywords = $bd['other'] ? $bd['other'] : $config['keywords'];
    $metadescription = $config['description'];
    if($newtemplate){
        include template($common_template_pluginid.':new/post/addalbum');
    }else {
        include template('aljbd:addalbum');
    }
}
//From: Dism��taobao��com
?>