<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if(!$aljbd && !$admin_status && !$staff){
    echo "<script>alert('".lang('plugin/aljbd','aljbd_7')."');location.href='plugin.php?id=aljbd&act=attend';</script>";
    exit;
}

if($_GET['do'] == 'delete_all'){
    if(!$_GET['delete'] && $_GET['formhash'] != FORMHASH && $a['uid'] != $_G['uid'] && !$admin_status  && !in_array('staff_xcgl',$staff['st_staff_authority'])){
        echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>'����ʧ�ܣ�')));
        exit;
    }
    $delete = explode(',',$_GET['delete']);
    foreach ($delete as $id){
        
        DB::update('aljbd_album_attachments', array('rubbish' => '1'), array('id' => $id));
    }
    echo json_encode(T::ajaxPostCharSet(array('code'=>1,'text'=>'�����ɹ���')));
    exit;
}
$num = C::t('#aljbd#aljbd_album_attachments')->count_by_uid_bid($_G['uid'], $_GET['aid'], 0);
$currpage = intval($_GET['page']) ? intval($_GET['page']) : 1;
$perpage = 9;
$allpage = ceil($num / $perpage);
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start = ($currpage - 1) * $perpage;
if($staff && $bid){//���̵�ԱȨ��
    $uid = 0;
}else{
    $uid = $_G['uid'];
}
$alist = C::t('#aljbd#aljbd_album_attachments')->fetch_all_by_uid_bid($uid, $_GET['aid'], $start, $perpage, 0);
$alist = dhtmlspecialchars($alist);
if($_GET['do'] == 'ajax'){
    require_once $common_path.'class/class_aljhtx.php';
    if($alist){
        echo json_encode(aljhtx::ajaxPostCharSet($alist));
    }else{
        echo '1';
    }
    exit;
}else {
    $a = C::t('#aljbd#aljbd_album')->range();
    $a = dhtmlspecialchars($a);

    $paging = helper_page:: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=albumall&aid=' . $_GET['aid'], 0, 11, false, false);
    $navtitle = '&#30456;&#20876;&#31649;&#29702;';
    $metakeywords = $bd['other'] ? $bd['other'] : $config['keywords'];
    $metadescription = $config['description'];
    if ($newtemplate) {
        include template($common_template_pluginid . ':new/user/albumall');
    } else {
        include template('aljbd:albumall');
    }
}
//From: Dism��taobao��com
?>