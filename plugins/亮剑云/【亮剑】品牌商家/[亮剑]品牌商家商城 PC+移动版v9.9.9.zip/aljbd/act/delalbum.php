<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
exit('Access Denied');
if(!$_GET['aid']){
    showmessage(lang('plugin/aljbd','aljbd_6'));
}
if(empty($_G['uid'])){
    showmessage(lang('plugin/aljbd','s39'));
}
if($_GET['formhash']!=formhash()){
    showmessage(lang('plugin/aljbd','aljbd_7'));
}
DB::update('aljbd_album_attachments',array('rubbish'=>'1'),array('aid'=>$_GET['aid']));
C::t('#aljbd#aljbd_album')->update($_GET['aid'],array('rubbish'=>1));
showmessage(lang('plugin/aljbd','admin_8'),'plugin.php?id=aljbd&act=albumlist');
?>