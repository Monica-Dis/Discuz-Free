<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$num = DB::result_first('SELECT count(*) FROM %t WHERE  upid=%d',array($pluginid.'_comment_goods',$_GET['upid']));
$currpage=$_GET['page']?$_GET['page']:1;
$perpage=10;
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start=($currpage-1)*$perpage;
$reply = DB::fetch_all('SELECT * FROM %t WHERE upid=%d order by dateline desc limit %d,%d',array($pluginid.'_comment_goods',$_GET['upid'],$start,$perpage));

$max = ceil($num/$perpage);

if($currpage == 1){
    $max_page ='<input type="hidden" id="max-page" value="'.$max.'">';
}

if($currpage == $max || empty($max)){
    $mes = '<div class="c_click_see" id="more" style="background: none;float: left;">'.lang('plugin/aljbd','No_more_data').'</div>';
}
include template($pluginid.':touch/view/expose_detail_reply');
?>