<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('formhash')){
    if(empty($bid)){
        showerror(lang('plugin/aljbd','s51'));
    }
    if(empty($_GET['subject'])){
        showerror(lang('plugin/aljbd','aljbd_1'));
    }
    if(empty($_GET['intro'])){
        showerror(lang('plugin/aljbd','aljbd_2'));
    }
    $updatearray=array(
        'bid'=>$bid,
        'subject'=>$_GET['subject'],
        'content'=>$_GET['intro'],
        'type'=>$_GET['type'],
        'subtype'=>$_GET['subtype'],
        'displayorder'=>$_GET['displayorder'],
    );
    C::t('#aljbd#aljbd_page')->update($_GET['nid'],$updatearray);
    showmsg(lang('plugin/aljbd','s54'));
}else{
    if(empty($_G['uid'])){
        //showmessage(lang('plugin/aljbd','s21'), $login_callback);
        dheader("location:".$login_callback);
    }
    if($bid){
        $bd=C::t('#aljbd#aljbd')->fetch($bid);
    }
    //$bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','',$_G['uid'],'','','','','','','','','','','',0);
    $n=C::t('#aljbd#aljbd_page')->fetch($_GET['nid']);
    include template('aljbd:addpage');
}
//From: Dism��taobao��com
?>