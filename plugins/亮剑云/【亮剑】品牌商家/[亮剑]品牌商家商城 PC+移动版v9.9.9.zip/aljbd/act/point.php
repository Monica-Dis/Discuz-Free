<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
    showmessage(lang('plugin/aljbd','s39'));
}

$num=C::t('#aljbd#aljbd_point')->count_by_buid($_G['uid']);
$currpage=intval($_GET['page'])?intval($_GET['page']):1;
$perpage=10;
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start=($currpage-1)*$perpage;
$pointlist=C::t('#aljbd#aljbd_point')->fetch_all_by_buid($_G['uid'],$start,$perpage);
$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=point', 0, 11, false, false);
$navtitle = '&#32416;&#27491;&#26631;&#27880;&#31649;&#29702;-'.$config['title'];
$metakeywords =  $bd['other']?$bd['other']:$config['keywords'];
$metadescription = $config['description'];
include template('aljbd:point');
?>