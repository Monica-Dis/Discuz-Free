<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$_GET = dhtmlspecialchars($_GET);
$config=$_G['cache']['plugin']['aljbd'];
$tlist=C::t('#aljbd#aljbd_type')->fetch_all_by_upid(0,'','','');
$rlist=C::t('#aljbd#aljbd_region')->fetch_all_by_upid('','','');

$typelist=C::t('#aljbd#aljbd_type')->range();
$titlelist=C::t('#aljbd#aljbd_region')->range();
if (!$_G['mobile'] || !$_G['setting']['mobile']['allowmobile']){
    $khf=C::t('#aljbd#aljbd_comment')->count_by_bid($bid);
    $khf = dhtmlspecialchars($khf);
    $typecount=C::t('#aljbd#aljbd')->count_by_type();
    foreach($typecount as $tc){
        $tcs[$tc['type']]=$tc['num'];
    }
    if($_GET['type']){
        $subtypecount=C::t('#aljbd#aljbd')->count_by_type($_GET['type']);
    }
    $recommendlist=C::t('#aljbd#aljbd')->fetch_all_by_recommend(1,0,6);
    $recommendlist = dhtmlspecialchars($recommendlist);
    if(!$card_user && !$admin_status){  
        $sql = ' AND is_aljtcc=0';
    }
    if($_G['cache']['plugin']['aljsqtg']['hide_aljsqtg_goods']){
        $sql .= ' AND commodity_type!=8';
    }
    $recommendlist_goods=C::t('#aljbd#aljbd_goods')->fetch_all_by_recommend_new(1,0,10,$sql);
    $recommendlist_goods = dhtmlspecialchars($recommendlist_goods);
    $notice=C::t('#aljbd#aljbd_notice')->fetch_all_by_uid_bid('','',0,9,'','','','',0);
    $notice = dhtmlspecialchars($notice);
    if($_G['charset']=='gbk'&&!defined('IN_MOBILE')&&$config['is_daohang']&&!$_GET['page']){
        $_GET['kw']=diconv($_GET['kw'],'utf-8','gbk');
    }

    if($_G['cache']['plugin']['aljlbs']['brand']){
        //require_once DISCUZ_ROOT.'source/plugin/aljlbs/aljlbs.inc.php';
    }
    $num=C::t('#aljbd#aljbd')->count_by_status(1,'',$_GET['type'],$_GET['subtype'],$_GET['region'],$_GET['subregion'],$_GET['kw'],'',$_GET['region1'],$_GET['subtype3'],$y,$x,0);
    $currpage=intval($_GET['page'])?intval($_GET['page']):1;
    $perpage=$config['page'];
    if(@ceil($num/$perpage) < $currpage && $no_max_page){
        $currpage=1;
    }
    $start=($currpage-1)*$perpage;
    if($config['isrewrite']&&!$_GET['page']&&(!$_G['mobile'] || !$_G['setting']['mobile']['allowmobile'])){
        if($_GET['order']=='1'){
            $_GET['order']='view';
        }else if($_GET['order']=='2'){
            $_GET['order']='dateline';
        }else if($_GET['order']=='0'){
            $_GET['order']='comment';
        }else{
            $_GET['order']='';
        }
        if($_GET['view']=='3'){
            $_GET['view']="pic";
        }else if($_GET['view']=='4'){
            $_GET['view']="list";
        }else{
            $_GET['view']='';
        }
    }
    if(!$_GET['order']){
        if($_G['cache']['plugin']['aljbd']['paixu'] == 1){
            $_GET['order']='view';
        }else if($_G['cache']['plugin']['aljbd']['paixu'] == 2){
            $_GET['order']='dateline';
        }

    }else{
        $orderby = array('view','dateline','comment');
        if(!in_array($_GET['order'],$orderby)){
            $_GET['order']='';
        }
    }
    $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,$start,$perpage,'',$_GET['type'],$_GET['subtype'],$_GET['region'],$_GET['subregion'],$_GET['order'],$_GET['kw'],'',$_GET['region1'],$_GET['subtype3'],0,0,0);
    $bdlist = dhtmlspecialchars($bdlist);
    foreach($bdlist as $k=>$v){
        $bdlist[$k]['c']=C::t('#aljbd#aljbd_comment')->fetch_by_bid($v['id']);
        $bdlist[$k]['q']=str_replace('{qq}',$v['qq'],$config['qq']);
        $bdlist[$k]['intro']=preg_replace("/\<img src=.*? alt=.*?\/\>/is","",preg_replace('/\[img.*?\].*?\[\/img\]/is','',htmlspecialchars_decode($v['intro'])));
        if($_GET['lng'] && $_GET['lat']){
            //$bdlist[$k]['distance'] = intval(getdistance($_GET['lng'],$_GET['lat'],$v['x'],$v['y']));
            //$distances[] = $bdlist[$k]['distance'];
        }
    }
    if($_GET['lng'] && $_GET['lat']) {
        array_multisort($distances, SORT_ASC, $bdlist);
    }
}else{
    if(!$_GET['order']){
        if($_G['cache']['plugin']['aljbd']['paixu'] == 1){
            $_GET['order']='view';
        }else if($_G['cache']['plugin']['aljbd']['paixu'] == 2){
            $_GET['order']='dateline';
        }

    }else{
        $orderby = array('view','dateline','comment');
        if(!in_array($_GET['order'],$orderby)){
            $_GET['order']='';
        }
    }
}

$geturl = array(
    'id' => 'aljbd',
    'act' => 'dianpu',
    'type' => $_GET['type'],
    'subtype' => $_GET['subtype'],
    'subtype3' => $_GET['subtype3'],
    'region' => $_GET['region'],
    'subregion' => $_GET['subregion'],
    'region1' => $_GET['region1'],
    'order' => $_GET['order'],
    'view' => $_GET['view'],
    'lng' => $_GET['lng'],
    'lat' => $_GET['lat'],
    'kw' => $_GET['kw']
);
//$pagingurl = 'plugin.php?'.url_implode($geturl);
$pagingurl = getaljurl($geturl,'');
$paging = helper_page :: multi($num, $perpage, $currpage,$pagingurl, 0, 11, false, false);
if($_GET['lbs']){
    $lbs = 1;
}else{
    $lbs = 0;
}
if($_GET['region']){
    $title=$titlelist[$_GET['region']]['name'];
    $title1 = $title;
}
if($_GET['subregion']){
    $title=$titlelist[$_GET['subregion']]['name'];
    $title2=$title;

}
if($_GET['region1']){
    $title=$titlelist[$_GET['region1']]['name'];
    $title3=$title;
}
if($_GET['type']){
    $cat=$typelist[$_GET['type']]['subject'];
    $cat1=$cat;
}

if($_GET['subtype']){
    $cat=$typelist[$_GET['subtype']]['subject'];
    $cat2=$cat;
}
if($_GET['subtype3']){
    $cat=$typelist[$_GET['subtype3']]['subject'];
    $cat3=$cat;
}
$navtitle = $title.lang('plugin/aljbd','s44').$config['title'];
$metakeywords =  $config['keywords'];
$metadescription = $config['description'];
if($aljbd_seo['list']['seotitle']){
    $seodata = array('bbname' => $_G['setting']['bbname'],'cat'=>$cat1,'cat2'=>$cat2,'cat3'=>$cat3,'region'=>$title1,'region2'=>$title2,'region3'=>$title3);
    list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljbd_seo['list']);
}

include template('aljbd:dianpu');
?>