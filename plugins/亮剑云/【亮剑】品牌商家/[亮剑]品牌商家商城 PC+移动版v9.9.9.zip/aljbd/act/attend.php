<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_GET['map'] == 'yes'){
    $province = $_GET['province'];
    $city = $_GET['city'];
    $district = $_GET['district'];
    $region = DB::result_first('select catid from %t where name like %s',array('aljbd_region','%'.addcslashes($province, '%_').'%'));
    $subregion = DB::result_first('select catid from %t where name like %s',array('aljbd_region','%'.addcslashes($city, '%_').'%'));
    $region1 = DB::result_first('select catid from %t where name like %s',array('aljbd_region','%'.addcslashes($district, '%_').'%'));
    $array = array('region'=>intval($region),'subregion'=>intval($subregion),'region1'=>intval($region1));
    require_once $common_path.'class/class_aljhtx.php';
    echo json_encode(aljhtx::ajaxPostCharSet($array));
    exit;
}else if($_GET['map'] == 'pois'){
    $Browser_Tencent_map_key = $_G['cache']['plugin']['aljhtx']['Browser_Tencent_map_key'] ? $_G['cache']['plugin']['aljhtx']['Browser_Tencent_map_key'] : 'SA5BZ-HX46G-3CFQP-IY4TP-KKMU7-MLBGO';
    $ret = file_get_contents("http://apis.map.qq.com/ws/geocoder/v1/?location=$_GET[lat],$_GET[lng]&coord_type=5&get_poi=1&key=".$Browser_Tencent_map_key);
    $ret = json_decode($ret, true);
    if($ret['status'] == 0){
        echo json_encode($ret);
        exit;
    }else{
        echo json_encode($ret['message']);
        exit;
    }


}
if($_GET['act'] == 'attend' && $_G['uid']){
    if($settings['is_one_brand']['value']==1 && !$admin_status) {
        $bnum=C::t('#aljbd#aljbd')->count_by_status('',$_G['uid'],'','','','','','','','','','','');
        if($bnum>=1){
            $onebrandtips = lang('plugin/aljbd','No_attend_tips');
            if(submitcheck('submit')) {
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('".$onebrandtips."','');</script>";
                    exit;
                }else{
                    showerror($onebrandtips);
                }
            }else{
                if($bnum == 1){
                    echo "<script>alert('".$onebrandtips."');location.href='plugin.php?id=aljbd&act=edit&bid=".$aljbd['id']."';</script>";
                    exit;
                }else{
                    echo "<script>alert('".$onebrandtips."');window.history.go(-1);</script>";
                    exit;
                }
            }
        }
    }
    if($yhzqx){
        $brandnum=C::t('#aljbd#aljbd_usergroup')->fetch($_G['groupid']);
        $bnum=C::t('#aljbd#aljbd')->count_by_status('',$_G['uid'],'','','','','','','','','','','');
        if($brandnum['brand']){
            if($brandnum['brand'] == $checksign){
                if(submitcheck('submit')) {
                    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                        echo "<script>parent.tips('".lang('plugin/aljbd','noauth').$brandtips."','');</script>";
                        exit;
                    }else{
                        showerror(lang('plugin/aljbd','noauth').$brandtips);
                    }
                }else{
                    $info = array('desc' => lang('plugin/aljbd','noauth').$brandtips);
                    $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                    aljbdShowTips($info);
                }
            }
            if($bnum>=$brandnum['brand']&&file_exists('source/plugin/aljbd/com/yhzqx.php')){
                if(submitcheck('submit')) {
                    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                        echo "<script>parent.tips('".lang('plugin/aljbd', 'groups_1') . $brandnum['brand'] . lang('plugin/aljbd', 'groups_2') . $brandtips."','');</script>";
                        exit;
                    }else{
                        showerror(lang('plugin/aljbd', 'groups_1') . $brandnum['brand'] . lang('plugin/aljbd', 'groups_2') . $brandtips);
                    }
                }else {
                    $info = array('desc' => lang('plugin/aljbd', 'groups_1') . $brandnum['brand'] . lang('plugin/aljbd', 'groups_2') . $brandtips);
                    $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                    aljbdShowTips($info);
                }
            }
        }
    }
}else if($_G['uid']){
    if(empty($bid)){
        $info = array('desc' => lang('plugin/aljbd','noinfo'));
        $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
        aljbdShowTips($info);
    }
    $bd=C::t('#aljbd#aljbd')->fetch($bid);
}
if(submitcheck('formhash')){
    //$bd=C::t('#aljbd#aljbd')->fetch_by_uid($_G['uid']);
    /*if($bd&&$_G['groupid']!=1){
        showerror(lang('plugin/aljbd','s18'));
    }*/
    if(!$_GET['agreement'] && $_G['cache']['plugin']['aljbd']['is_agreement']){
        $tip = lang('plugin/aljbd','attend_php_2').strip_tags($_G['cache']['plugin']['aljbd']['agreement']).lang('plugin/aljbd','attend_php_3');
        echo "<script>parent.tips('".$tip."','','error');</script>";
        exit;
    }
    if($settings['is_agreement']['value']==1 && empty($_GET['agreement'])){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".$aljbdlang['php']['agreement']."','');</script>";
            exit;
        }else{
            showerror($aljbdlang['php']['agreement']);
        }
    }
    if(!$_GET['name']){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_3')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','aljbd_3'));
        }

    }
    if(!$_GET['tel']){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','adddp_tel')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','adddp_tel'));
        }

    }
    if(!$_GET['addr']){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','adddp_addr')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','adddp_addr'));
        }

    }
    if(!$_GET['type']){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_4')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','aljbd_4'));
        }
    }
    if(!$_GET['region']){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_5')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','aljbd_5'));
        }
    }
    if($config['islogo']){
        if((!$_GET['logo'] && !$_GET['pic']) || ($_GET['compress'] && !$_FILES['logo']['tmp_name'] && !$_GET['logo'] && !$_GET['pic'])) {
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('".lang('plugin/aljbd','logo')."','');</script>";
                exit;
            }else{
                showerror(lang('plugin/aljbd','logo'));
            }
        }
    }
    if($_GET['vipid'] == 'jhm'){
        $_GET['card_number'] = $_GET['activation_code'];
        $card = DB::fetch_first('select * from %t where card_number=%s and card_service_id = 1 and used = 0 and dateline+card_day_num*86400>%d', array('aljac_card', $_GET['card_number'], TIMESTAMP)); //�ж��û�����ļ������Ƿ���Ч
        if(!$card){
            echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_php_10')."','');</script>";
            exit;
        }
    }
    if($_GET['act'] != 'edit'){
        if($settings['is_form']['value']){
            if(DB::result_first('select * from %t where name = %s',array('aljbd',$_GET['name']))){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#24215;&#38138;&#24050;&#23384;&#22312;','');</script>";
                    exit;
                }else{
                    showerror('&#24215;&#38138;&#24050;&#23384;&#22312;');
                }
            }
            if(!valid_token($_GET['aljbd_token'],getcookie('aljbd_token'),'aljbd_token')){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#35831;&#21047;&#26032;&#21518;&#37325;&#26032;&#21457;&#24067;&#25110;&#36820;&#22238;&#24215;&#38138;&#31649;&#29702;&#26597;&#30475;&#24215;&#38138;',function(){parent.location.href='plugin.php?id=aljbd&act=member';});</script>";
                    exit;
                }else{
                    showerror('&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#35831;&#21047;&#26032;&#21518;&#37325;&#26032;&#21457;&#24067;&#25110;<a href="plugin.php?id=aljbd&act=member">&#36820;&#22238;&#24215;&#38138;&#31649;&#29702;&#26597;&#30475;&#24215;&#38138;</a>');
                }
            }
        }
    }
    if($_GET['fare_type'] == 3 && $_GET['postal_amount']<=0){
        echo '<script>parent.tips("&#35746;&#21333;&#21253;&#37038;&#37329;&#39069;&#24517;&#39035;&#22635;&#20889;");</script>';
        exit;
    }
    if($_GET['compress'] == '1'){
        if($_FILES['logo']['tmp_name']) {
            $picname = $_FILES['logo']['name'];
            $picsize = $_FILES['logo']['size'];

            if ($picname != "") {
                $type = strtolower(strrchr($picname, '.'));
                if ($type!= ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
                    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                        echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
                        exit;
                    }else{
                        showerror(lang('plugin/aljbd','s19'));
                    }
                }
                if (($picsize/1024)>$config['img_size']) {
                    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                        echo "<script>parent.tips('".lang('plugin/aljbd','img1').$config['img_size'].'KB'."','');</script>";
                        exit;
                    }else{
                        showerror(lang('plugin/aljbd','img1').$config['img_size'].'KB');
                    }
                }
                $rand = rand(100, 999);
                $pics = date("YmdHis") . $rand . $type;
                $img_dir = $image_path."logo/".date('Ymd',TIMESTAMP).'/';
                if (!is_dir($img_dir)) {
                    mkdir($img_dir);
                }
                $logo = $img_dir. $pics;
                if(@copy($_FILES['logo']['tmp_name'], $logo)||@move_uploaded_file($_FILES['logo']['tmp_name'], $logo)){
                    if($_G['cache']['plugin']['aljbd']['iswatermark']){
                        $image->Watermark(DISCUZ_ROOT.'./'.$logo,'', 'forum','');
                    }
                    @unlink($_FILES['logo']['tmp_name']);
                }
            }
        }
    }else{
        
        if ($_GET['pic']) {
            $b_logo_a = array('logo','brand_bg');
            
            foreach ($_GET['pic'] as $tmp_key => $tmp_value) {
                if (strpos($tmp_value,$oss_domain) !== false) {
                    $b_logo[$b_logo_a[$tmp_key]] = $tmp_value;
                }else if (is_file($tmp_value)) {
                    $b_logo[$b_logo_a[$tmp_key]] = $tmp_value;
                } else {
                    unlink($bd[$b_logo_a[$tmp_key]]);
                    if($b_logo_a[$tmp_key] == 'logo'){
                        unlink('source/plugin/aljwx/static/miniqrcode/'.md5('plugin.php?id=aljbd&act=view&bid='.$bd['id']).'.jpg');
                    }
                    T::delete_oss($bd[$b_logo_a[$tmp_key]]);
                    $b_logo[$b_logo_a[$tmp_key]] = T::saveimg($tmp_value,$image_path.'logo/');
                }
            }
            
            $logo = $b_logo['logo'];
            $brand_bg = $b_logo['brand_bg'];
        }else if($_GET['logo']){
            if (strpos($_GET['logo'],$oss_domain) !== false) {
                $logo = $_GET['logo'];
            }else if (is_file($_GET['logo'])) {
                $logo = $_GET['logo'];
            } else {
                unlink($bd['logo']);
                T::delete_oss($bd['logo']);
                $logo = T::saveimg($_GET['logo'],$image_path.'logo/');
            }
        }
    }
    if(in_array($_G['groupid'],unserialize($config['mgroups']))){
        $status=1;
    }
    if($config['yushe']){
        $_GET['intro']=str_replace ("\r\n", "<br/>", $_GET['intro']);
    }
    $insertarray=array(
        'name'=>$_GET['name'],
        'tel'=>$_GET['tel'],
        'addr'=>$_GET['addr'],
        'intro'=>$_GET['intro'],
        'qq'=>$_GET['qq'],
        'wurl'=>$_GET['wurl'],
        'other'=>$_GET['other'],
        'type'=>$_GET['type'],
        'subtype'=>$_GET['subtype'],
        'subtype3'=>$_GET['subtype3'],
        'region'=>$_GET['region'],
        'region1'=>$_GET['region1'],
        'subregion'=>$_GET['subregion'],
        'business_hours'=>$_GET['business_hours'],
        'bus_routes'=>$_GET['bus_routes'],
        'wangwang'=>$_GET['wangwang'],
        'weixin_id'=>$_GET['weixin_id'],
        'fare_type'=>$_GET['fare_type'],
        'postal_amount'=>$_GET['postal_amount'],
        'businesstype'=>implode(',', $_GET['businesstype']),
        'y'=>$_GET['y'],
        'x'=>$_GET['x'],
        'gg'=>$_GET['gg'],
    );
    if($_G['cache']['plugin']['aljpps']['is_aljbd']){
        $insertarray['platform_distribution'] = $_GET['platform_distribution'];
    }
    if(file_exists("source/plugin/dcdz/dcdz.inc.php")){
        $insertarray['curl'] = serialize($_GET['curl']);
    }

    if($_GET['act'] == 'attend'){

        $insertarray['username'] = $_G['username'];
        $insertarray['uid'] = $_G['uid'];
        $insertarray['dateline'] = TIMESTAMP;
        $insertarray['status'] = $status;
        $insertarray['logo'] = $logo;
        $insertarray['brand_bg'] = $brand_bg;
        if($_GET['vipid'] == 'jhm'){
            
            
            $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$card['card_vip_id']));
            
            if(!$vipdata){
                echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_php_10')."','');</script>";
                exit;
            }
            if(DB::query('update %t set used = 1, used_time=%d,uid=%d,username=%s where id = %d', array('aljac_card', TIMESTAMP, $_G['uid'], $_G['username'], $card['id']))){//����������Ϊ��ʹ�ò�����ʹ��ʱ��
                DB::query('update %t set unused_card_num = unused_card_num-1,  used_card_num = used_card_num+1 where id=%d', array('aljac_card_type', $card['card_type']));  //��������ʹ��+1 δʹ��-1
                if($vipdata['day'] == 0){
                    $insertarray['vipendtime'] = 0;
                }else{
                    $insertarray['vipendtime'] = TIMESTAMP + ($vipdata['day'] * 86400);
                }
                $insertarray['vipid'] = $vipdata['id'];
                $insertid =C::t('#aljbd#aljbd')->insert($insertarray, true);
                $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
                $orderarray=array(
                    'orderid' => $orderid,
                    'status' => 2,
                    'uid' => $_G['uid'],
                    'username' => $_G['username'],
                    'price' => $vipdata['price'],
                    'submitdate' => $_G['timestamp'],
                    'remarks' => $vipdata['day'].'/'.$vipdata['price'].'_'.$_GET['activation_code'],
                    'stitle' => $card['id'].'_'.lang('plugin/aljbd','aljbd_php_11').'-'.$_GET['name'],
                    'payment' => 7,
                    'pid'  => 3,//�̼�
                    'browser'  => $_SERVER['HTTP_USER_AGENT'],
                );
                $orderarray['fare_desc'] = $vipdata['id'];
                if($_G['mobile']){//1���ֻ���2��PC
                    $orderarray['mobile'] = 1;
                }else{
                    $orderarray['mobile'] = 2;
                }
                $orderarray['shop_id'] = $insertid;
                $orderarray['status'] = 2;
                
                C::t('#aljbdx#aljbd_goods_order')->insert($orderarray);
            }else{
                echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_php_10')."','');</script>";
                exit;
            }
            if($settings['post_brand_type']['value'] > 0){
                $return_url =  'plugin.php?id=aljbd&act=attestation&bid='.$insertid;
            }else{
                $return_url = 'plugin.php?id=aljbd&act=edit&bid='.$insertid;
            }
        }else{
            $vipid = intval($_GET['vipid']);
            $insertarray['vipid'] = $vipid;
            $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$vipid));
            if($vipdata && $_G['cache']['plugin']['aljbdx']['is_aljqb']){
                $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
                $orderarray=array(
                    'orderid' => $orderid,
                    'status' => 1,
                    'uid' => $_G['uid'],
                    'username' => $_G['username'],
                    'price' => $vipdata['price'],
                    'submitdate' => $_G['timestamp'],
                    'remarks' => $vipdata['day'].'/'.$vipdata['price'],
                    'stitle' => lang('plugin/aljbd','attend_php_1').'-'.$_GET['name'],
                    'payment' => 7,
                    'pid'  => 3,//����
                    'browser'  => $_SERVER['HTTP_USER_AGENT'],
                );
                $orderarray['fare_desc'] = $vipid;
                if($_G['mobile']){//1���ֻ���2��PC
                    $orderarray['mobile'] = 1;
                }else{
                    $orderarray['mobile'] = 2;
                }
                if($_GET['couponid'] && $_G['cache']['plugin']['aljsyh']['is_aljsyh']){
                    $clogdata = DB::fetch_first('select * from %t a left join %t b on a.cid=b.id where a.status=1 and a.uid=%d and a.id=%d',array('aljsyh_consume_log','aljbd_consume',$_G['uid'],intval($_GET['couponid'])));

                    if($clogdata){
                        $vipdata['price'] = $vipdata['price']-$clogdata['reduction'];
                    }
                    if(DB::update('aljsyh_consume_log',array('status'=>2),array('id'=>intval($_GET['couponid']),'status'=>1))){
                        $orderarray['cid']=intval($_GET['couponid']);
                        $orderarray['discount']=$clogdata['reduction'];
                    }
                }

                if($vipdata['price']>0){
                    $insertarray['status'] = 2;
                    $insertarray['price'] = $vipdata['price'];
                    //$insertarray['orderid'] = $orderid;
                    $insertid =C::t('#aljbd#aljbd')->insert($insertarray, true);
                    $orderarray['shop_id'] = $insertid;
                    C::t('#aljbdx#aljbd_goods_order')->insert($orderarray);
                    //$url = 'plugin.php?id=aljbdx&act=pay&bid='.$insertid;
                    require_once 'source/plugin/aljqb/class/Qbapi.class.php';
                    $qbapi = new Qbapi();
                    if($settings['post_brand_type']['value'] > 0){
                        $return_url =  rtrim($qbapi->siteurl, '/').'/'.'plugin.php?id=aljbd&act=attestation&bid='.$insertid;
                    }else{
                        $return_url = rtrim($qbapi->siteurl, '/').'/'.'plugin.php?id=aljbd&act=edit&bid='.$insertid;
                    }
                    $keyurlarray = array(
                        'orderid' => $orderid,
                        'time' => TIMESTAMP,
                        'price' => $vipdata['price'],
                        'keyname' => 'aljbdx_rz',
                        'return_url' => $return_url,
                        'key' => $_G['cache']['plugin']['aljbdx']['qb_key'],
                    );
                    $url = $qbapi -> createUrl($keyurlarray);
                    echo "<script>parent.location.href='".$url . "';</script>";
                    exit;
                }else{
                    if($vipdata['day'] == 0){
                        $insertarray['vipendtime'] = 0;
                    }else{
                        $insertarray['vipendtime'] = TIMESTAMP + ($vipdata['day'] * 86400);
                    }
                    
                    
                    $insertid =C::t('#aljbd#aljbd')->insert($insertarray, true);
                    $orderarray['shop_id'] = $insertid;
                    $orderarray['status'] = 2;
                    C::t('#aljbdx#aljbd_goods_order')->insert($orderarray);
                    if($settings['post_brand_type']['value'] > 0){
                        $return_url =  'plugin.php?id=aljbd&act=attestation&bid='.$insertid;
                    }else{
                        $return_url = 'plugin.php?id=aljbd&act=edit&bid='.$insertid;
                    }
                }
            }else{
                if($_G['cache']['plugin']['aljbdx']['is_aljqb'] && $_G['cache']['plugin']['aljbdx']['adddp_price']){
                    $insertarray['status'] = 2;
                    $insertarray['price'] = $_G['cache']['plugin']['aljbdx']['adddp_price'];
                    $insertid =C::t('#aljbd#aljbd')->insert($insertarray, true);
                    $url = 'plugin.php?id=aljbdx&act=pay&bid='.$insertid;
                    require_once 'source/plugin/aljqb/class/Qbapi.class.php';
                    $qbapi = new Qbapi();
                    echo "<script>parent.location.href='".$url . "';</script>";
                    exit;
                }else{
                    $insertid =C::t('#aljbd#aljbd')->insert($insertarray, true);
                    if($config['money']&&$config['money_lx']&& !$_G['cache']['plugin']['aljbdx']['is_aljqb']){
                        updatemembercount($_G['uid'], array($config['money_lx'] => '-' . $config['money']));
                    }
                }
            }
        }
        if(!in_array($_G['groupid'],unserialize($config['mgroups']))){
            $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
            if($_G['cache']['plugin']['aljbdx']['is_aljqb'] || $_G['cache']['plugin']['aljgwc']['aljbd']){
                $n_add_tips_url = '<a href="plugin.php?id=aljhtx&c=aljbd&a=order&type=5&do=no">'.lang('plugin/aljbd','n_add_tips').'</a>';
            }else{
                $n_add_tips_url = $n_add_tips_url = lang('plugin/aljbd','n_add_tips');
            }
            foreach($groupids as $g_uid){
                notification_add($g_uid['uid'], 'system',$n_add_tips_url,array('from_idtype'  => 'aljbd','from_id' => $insertid));
            }
        }
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            if(in_array($_G['groupid'],unserialize($config['mgroups']))){
                echo "<script>parent.tips('".lang('plugin/aljbd','mgroups')."',function(){parent.location.href='" . $return_url . "';});</script>";
                exit;
            }else{
                echo "<script>parent.tips('".lang('plugin/aljbd','s20')."',function(){parent.location.href='" . $return_url . "';});</script>";
                exit;
            }

        }else{
            if(in_array($_G['groupid'],unserialize($config['mgroups']))){
                showmsg(lang('plugin/aljbd','mgroups'));
            }else{
                showmsg(lang('plugin/aljbd','s20'));
            }
        }
    }else{
        if($logo){
            $insertarray['logo']=$logo;
        }
        if($brand_bg){
            $insertarray['brand_bg']=$brand_bg;
        }
        
        if($u20181224){
            if($_GET['madv']){
                foreach($_GET['madv'] as $tmp_key=> $tmp_value) {
                    if (strpos($tmp_value,$oss_domain) !== false) {
                        $src_slt[$tmp_key+1] = $tmp_value;
                    }else if (is_file($tmp_value)) {
                        $src_slt[$tmp_key+1] = $tmp_value;
                    } else {
                        $src_slt[$tmp_key+1] = T::saveimg($tmp_value,$image_path.'adv/');
                    }
                }
                $insertarray['madv']=serialize($src_slt);
            }else{
                $insertarray['madv']='';
                $insertarray['madvurl']='';
            }
            if($_GET['madvurl']){
                foreach($_GET['madvurl'] as $tmp_key=> $tmp_value) {
                    $src_slt_text[$tmp_key+1] = $tmp_value;
                }
                $insertarray['madvurl']=serialize($src_slt_text);
            }
        }
        if ($bd['status'] == 3){
            $insertarray['status'] = 0;
        }
        C::t('#aljbd#aljbd')->update($bid,$insertarray);
        savecache('aljbd_rec_brand', '');//�Ƽ��̼� �����ÿ�
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','s30')."',function(){parent.location.href='plugin.php?id=aljbd&act=view&bid=" . $bid . "';});</script>";
            exit;
        }else{
            showmsg(lang('plugin/aljbd','s30'));
        }
    }
}else{
    if(empty($_G['uid'])){
        //showmessage(lang('plugin/aljbd','s21'), $login_callback);
        dheader("location:".$login_callback);
    }
    
    if($_GET['act'] == 'attend') {
        if ($config['money'] && $config['money_lx'] && !$_G['cache']['plugin']['aljbdx']['is_aljqb']) {
            if($_G['cache']['plugin']['aljpay']){
                $ext_pay_url = '<a href="plugin.php?id=aljpay">&#62;&#62;&#62;&#21435;&#20805;&#20540;</a>';
                $ext_pay = 'plugin.php?id=aljpay';
            }
            if (getuserprofile('extcredits' . $config['money_lx']) < $config['money']) {
                $info = array('desc' => $_G['setting']['extcredits'][$config['money_lx']]['title'] . lang('plugin/aljbd', 'index_4'));
                $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_19'), 'url' => $ext_pay);
                $info['btn_default'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                aljbdShowTips($info);
            }
        }
        if($_G['cache']['plugin']['aljbdx']['is_aljqb']){
            $aljbd_groups=C::t('#aljbd#aljbd_vip')->fetch_all_by_user();
        }
        if($_G['cache']['plugin']['aljsyh']['is_aljsyh']){
            $discount = DB::fetch_all('select a.id,b.full,b.reduction,b.coupon_type from %t a left join %t b on a.cid=b.id where (b.end>%s || b.end=0) and b.coupon_type=9 and a.status=%d and a.uid=%d order by b.reduction desc',array('aljsyh_consume_log','aljbd_consume', TIMESTAMP,1,$_G['uid']));
            foreach($discount as $dk => $kv){
                $discount[$dk]['full'] = floatval($kv['full']);
                $discount[$dk]['reduction'] = floatval($kv['reduction']);
            }
        }
        $navtitle = lang('plugin/aljbd','attend_php_1');
    }else{
        $navtitle = lang('plugin/aljbd','view_php_12');
    }
    
    $metakeywords =  $config['keywords'];
    $metadescription = $config['description'];
    if($newtemplate){
        $madv=unserialize($bd['madv']);
        $madvurl=unserialize($bd['madvurl']);
        $json_regionlist = C::t('#aljbd#aljbd_region')->fetch_all_json();
        $cityjson = json_encode($json_regionlist);
        if($bd['region']){
            $region = $bd['region'];
            $subregion = $bd['subregion'];
            $region1 = $bd['region1'];
            $default = $rlist[$bd['region']]['name'].' '. ($rlist[$bd['subregion']]['name'] ? $rlist[$bd['subregion']]['name'] : '--').' '.($rlist[$bd['region1']]['name'] ? $rlist[$bd['region1']]['name'] : '--');
        }else{
            $region = $json_regionlist[0]['code'];
            $subregion = $json_regionlist[0]['sub'][0]['code'];
            $region1 = $json_regionlist[0]['sub'][0]['sub'][0]['code'];
            $default = diconv($json_regionlist[0]['name'].' '. $json_regionlist[0]['sub'][0]['name'].' '.$json_regionlist[0]['sub'][0]['sub'][0]['name'], 'utf-8', CHARSET);
        }

        $json_typelist = C::t('#aljbd#aljbd_type')->fetch_all_json();
        if($bd['type']){
            $default_type = $typelist[$bd['type']]['subject'].' '. ($typelist[$bd['subtype']]['subject']?$typelist[$bd['subtype']]['subject']:'--').' '.($typelist[$bd['subtype3']]['subject']?$typelist[$bd['subtype3']]['subject']:'--');
            $type = $bd['type'];
            $subtype = $bd['subtype'];
            $subtype3 = $bd['subtype3'];
        }else{
            $default_type = diconv($json_typelist[0]['name'].' '. $json_typelist[0]['sub'][0]['name'].' '.$json_typelist[0]['sub'][0]['sub'][0]['name'], 'utf-8', CHARSET);
            $type = $json_typelist[0]['code'];
            $subtype = $json_typelist[0]['sub'][0]['code'];
            $subtype3 = $json_typelist[0]['sub'][0]['sub'][0]['code'];
        }
        $typejson = json_encode($json_typelist);
        include template($common_template_pluginid.':new/post/attend');
    }else{
        $typelist=C::t('#aljbd#aljbd_type')->fetch_all_by_upid(0,'','','');
        $rlist=C::t('#aljbd#aljbd_region')->fetch_all_by_upid('','','');
        include template('aljbd:adddp');
    }
}
//From: Dism��taobao��com
?>