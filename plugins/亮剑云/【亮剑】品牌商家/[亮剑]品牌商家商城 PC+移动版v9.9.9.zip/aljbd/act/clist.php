<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$currpage = intval($_GET['page']) ? intval($_GET['page']) : 1;
$perpage = 12;
$start = ($currpage - 1) * $perpage;
if($_GET['do'] == 'ajax'){
    require_once $common_path.'class/class_aljhtx.php';
    if($_GET['type'] == 'recommend'){
        $clist = C::t('#aljbd#aljbd_consume')->fetch_all_by_recommend(1,$start, $perpage);
    }else if($_GET['type'] == 'enter' || $_GET['type'] == 'aljtcc' || $_GET['type'] == 'aljpyh'){
        if($_GET['type'] == 'aljtcc'){
            $coupon_type = 10;
        }else if($_GET['type'] == 'aljpyh'){
            $coupon_type = 7;
        }else{
            $coupon_type = 9;
        }
        $clist = DB::fetch_all('select * from %t where coupon_type=%d and rubbish=0 and status=0 limit %d,%d',array('aljbd_consume',$coupon_type,$start, $perpage));
    }else{
        $clist = C::t('#aljbd#aljbd_consume')->fetch_all_by_uid_bid('', '', $start, $perpage, $_GET['type'], $_GET['subtype'], $_GET['kw'], 0);
    }
    foreach($clist as $ck => $cv){
        if($_G['cache']['plugin']['aljsyh']['is_aljsyh']) {
            $clist[$ck]['clog'] = DB::result_first('select count(*) from %t where cid=%d and status=1 and uid=%d', array('aljsyh_consume_log', $cv['id'],$_G['uid']));
        }
        $clist[$ck]['bdname'] = cutstr(DB::result_first('select name from %t where id=%d',array('aljbd',$cv['bid'])),20,'');
    }
    $clist = dhtmlspecialchars($clist);
    if($clist){
        echo json_encode(aljhtx::ajaxPostCharSet($clist));
    }else{
        echo '1';
    }
    exit;
}else {
    require_once libfile('function/discuzcode');
    $navtitle = lang('plugin/aljbd', 'index_1') . $config['title'];
    $metakeywords = $config['keywords'];
    $metadescription = $config['description'];
    $tlist = C::t('#aljbd#aljbd_type_consume')->fetch_all_by_upid(0);
   
    $tlist = dhtmlspecialchars($tlist);
    if (!$_G['mobile'] || !$_G['setting']['mobile']['allowmobile']) {
        $typecount = C::t('#aljbd#aljbd_consume')->count_by_type();
        foreach ($typecount as $tc) {
            $tcs[$tc['type']] = $tc['num'];
        }
        if ($_GET['type']) {
            $subtypecount = C::t('#aljbd#aljbd_consume')->count_by_type($_GET['type']);
        }
        //$aljbd=C::t('#aljbd#aljbd')->range();
        //$aljbd = dhtmlspecialchars($aljbd);
        $typelist = C::t('#aljbd#aljbd_type_consume')->range();
        $typelist = dhtmlspecialchars($typelist);
        $notice = C::t('#aljbd#aljbd_notice')->fetch_all_by_uid_bid('', '', 0, 9, '', '', '', '', '');
        $notice = dhtmlspecialchars($notice);
        $nlist = dhtmlspecialchars($nlist);
        $recommendlist = C::t('#aljbd#aljbd')->fetch_all_by_recommend(1, 0, 10);
        $recommendlist = dhtmlspecialchars($recommendlist);
        $recommendlist_goods = C::t('#aljbd#aljbd_goods')->fetch_all_by_recommend_new(1, 0, 10);
        $recommendlist_goods = dhtmlspecialchars($recommendlist_goods);
    }
    $config = $_G['cache']['plugin']['aljbd'];
    
    if ($_G['charset'] == 'gbk' && !defined('IN_MOBILE') && $config['is_daohang'] && !$_GET['page']) {
        $_GET['kw'] = diconv($_GET['kw'], 'utf-8', 'gbk');
    }
    $num = C::t('#aljbd#aljbd_consume')->count_by_uid_bid('', '', $_GET['type'], $_GET['subtype'], $_GET['kw'], 0);
    $currpage = intval($_GET['page']) ? intval($_GET['page']) : 1;
    $perpage = 12;
    if(@ceil($num/$perpage) < $currpage && $no_max_page){
        $currpage=1;
    }
    $start = ($currpage - 1) * $perpage;

    if ($config['isrewrite']) {
        if ($_GET['order'] == '1') {
            $_GET['order'] = 'view';
        } else if ($_GET['order'] == '2') {
            $_GET['order'] = 'price1';
        } else {
            $_GET['order'] = '';
        }
        if ($_GET['view'] == '3') {
            $_GET['view'] = "pic";
        } else if ($_GET['view'] == '4') {
            $_GET['view'] = "list";
        } else {
            $_GET['view'] = '';
        }
    }

    $clist = C::t('#aljbd#aljbd_consume')->fetch_all_by_uid_bid('', '', $start, $perpage, $_GET['type'], $_GET['subtype'], $_GET['kw'], 0);
    $clist = dhtmlspecialchars($clist);

    $paging = helper_page:: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=clist&type=' . $_GET['type'] . '&subtype=' . $_GET['subtype'] . '&kw=' . $_GET['kw'], 0, 11, false, false);
    if ($aljbd_seo['consume_list']['seotitle']) {
        if ($_GET['type']) {
            $cat = $typelist[$_GET['type']]['subject'];
        }
        if ($_GET['subtype']) {
            $cat = $typelist[$_GET['subtype']]['subject'];
        }
        $seodata = array('bbname' => $_G['setting']['bbname'], 'cat' => $cat);
        list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljbd_seo['consume_list']);
    }
    $title = lang('plugin/aljbd','view_php_2');
    include template('aljbd:list_consume');
}
//From: Dism��taobao��com
?>