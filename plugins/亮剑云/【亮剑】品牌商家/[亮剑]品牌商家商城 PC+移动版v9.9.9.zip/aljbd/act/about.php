<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_G['cache']['plugin']['aljapp']['about'] && strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false){
    $_G['cache']['plugin']['aljbdx']['about'] = $_G['cache']['plugin']['aljapp']['about'];
}
$about = str_replace('{siteurl}',$_G['siteurl'],$_G['cache']['plugin']['aljbdx']['about']);
$navtitle = lang('plugin/aljbd','aljbd_php_21');
$metakeywords =  $config['keywords'];
$metadescription = $config['description'];
include template($common_template_pluginid.':new/user/about');
?>