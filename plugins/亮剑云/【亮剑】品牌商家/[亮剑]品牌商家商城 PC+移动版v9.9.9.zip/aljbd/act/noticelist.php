<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
    //showmessage(lang('plugin/aljbd','s21'), $login_callback);
    dheader("location:".$login_callback);
}
if(!$aljbd && !$admin_status && !$staff){
    echo "<script>alert('".lang('plugin/aljbd','aljbd_7')."');location.href='plugin.php?id=aljbd&act=attend';</script>";
    exit;
}

if(in_array($_G['groupid'],$admingroups) && $_GET['i'] == 1){
    $uid = 0;
    $sh_status = 1;
}else{
    if($staff && $bid){//���̵�ԱȨ��
        $uid = 0;
    }else{
        $uid = $_G['uid'];
    }
    $sh_status = 0;
}
$num = C::t('#aljbd#aljbd_notice')->count_by_uid_bid($uid, $bid, '', '', $_GET['kw'], 0,$_GET['status']);
$currpage = intval($_GET['page']) ? intval($_GET['page']) : 1;
$perpage = 10;
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start = ($currpage - 1) * $perpage;
$nlist = C::t('#aljbd#aljbd_notice')->fetch_all_by_uid_bid($uid, $bid, $start, $perpage, '', '', '', $_GET['kw'], 0,$_GET['status']);
$nlist = dhtmlspecialchars($nlist);
foreach($nlist as $k=>$v){
    $nlist[$k]['bdinfo']=C::t('#aljbd#aljbd')->fetch($v['bid']);
    if($v['status'] == 1){
        $nlist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_1');
    }else if($v['status'] == 2){
        $nlist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_2');
    }else{
        $nlist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_3');
    }
}
if($_GET['do'] == 'ajax'){
    require_once $common_path.'class/class_aljhtx.php';
    if($nlist){
        echo json_encode(aljhtx::ajaxPostCharSet($nlist));
    }else{
        echo '1';
    }
    exit;
}else {
    
    $paging = helper_page:: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=noticelist', 0, 11, false, false);
    if($_G['cache']['plugin']['aljshd']['aljshd_name']){
        require_once 'source/plugin/aljshd/include/noticelist.php';
    }else{
        $navtitle = '&#27963;&#21160;&#31649;&#29702;-' . $config['title'];
    }
    $metakeywords = $bd['other'] ? $bd['other'] : $config['keywords'];
    $metadescription = $config['description'];
    if($newtemplate){
        include template($common_template_pluginid.':new/user/noticelist');
    }else {
        include template('aljbd:noticelist');
    }
}
//From: Dism��taobao��com
?>