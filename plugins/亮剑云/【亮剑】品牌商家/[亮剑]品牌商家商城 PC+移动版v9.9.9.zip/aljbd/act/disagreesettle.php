<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if (!in_array($_G['groupid'],$admingroups)){
    showmessage(lang('plugin/aljbd','tg45'));
}

if($_G['cache']['plugin']['aljgwc'][$pluginid] && $_GET['cart'] != 'old'){
    require DISCUZ_ROOT.'./source/plugin/aljgwc/include/aljbd_disagreesettle.php';
}else{
    if($_G['cache']['plugin']['aljgwc']['aljbd_old_settle']){
        showmessage('&#26087;&#30340;&#32467;&#31639;&#24050;&#20851;&#38381;');
    }
    if ($_GET['settleid']){
        DB::query('update %t set status = 2,dateline = %d where settleid = %s',array('aljbd_settle',TIMESTAMP,$_GET['settleid']));
    }
}
if($_GET['cart']){
    $url='&cart='.$_GET['cart'];
}
showmessage(lang('plugin/aljbd','tg46'),'plugin.php?id=aljbd&act=settlelist');
?>