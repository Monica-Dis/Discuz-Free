<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once $common_path.'class/class_aljhtx.php';
if($_G['cache']['plugin']['aljlbs']['brand']){
    require_once DISCUZ_ROOT.'source/plugin/aljlbs/aljlbs.inc.php';
}

if($config['isrewrite']&&!$_GET['page']&&(!$_G['mobile'] || !$_G['setting']['mobile']['allowmobile'])){
    if($_GET['order']=='1'){
        $_GET['order']='view';
    }else if($_GET['order']=='2'){
        $_GET['order']='dateline';
    }else{
        $_GET['order']='';
    }
    if($_GET['view']=='3'){
        $_GET['view']="pic";
    }else if($_GET['view']=='4'){
        $_GET['view']="list";
    }else{
        $_GET['view']='';
    }
}
if(!$_GET['order']){
    if($_G['cache']['plugin']['aljbd']['paixu'] == 1){
        $_GET['order']='view';
    }else if($_G['cache']['plugin']['aljbd']['paixu'] == 2){
        $_GET['order']='dateline';
    }
}else{
    $orderby = array('view','dateline','comment');
    if(!in_array($_GET['order'],$orderby)){
        $_GET['order']='';
    }
}

$num=C::t('#aljbd#aljbd')->count_by_status(1,'',$_GET['type'],$_GET['subtype'],$_GET['region'],$_GET['subregion'],$_GET['kw'],'',$_GET['region1'],$_GET['subtype3'],$y,$x,0);
$currpage=$_GET['page']?$_GET['page']:1;

$perpage=10;
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start=($currpage-1)*$perpage;
$max = ceil($num/$perpage);

if($currpage == 1){
    $max_page ='<input type="hidden" id="max-page" value="'.$max.'">';
}

if($currpage == $max){
    $mes = '<div class="c_click_see" id="more" >'.$aljbdlang['php']['No_more_data'].'</div>';
}

$bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,$start,$perpage,'',$_GET['type'],$_GET['subtype'],$_GET['region'],$_GET['subregion'],$_GET['order'],$_GET['kw'],'',$_GET['region1'],$_GET['subtype3'],$y,$x,0);

if(file_exists("source/plugin/dcdz/dcdz.inc.php")){
    foreach($bdlist as $k=>$v){
        $bdlist[$k]['c']=C::t('#aljbd#aljbd_comment')->fetch_by_bid($v['id']);
        $bdlist[$k]['q']=str_replace('{qq}',$v['qq'],$config['qq']);
        $bdlist[$k]['intro']=preg_replace("/\<img src=.*? alt=.*?\/\>/is","",preg_replace('/\[img.*?\].*?\[\/img\]/is','',$v['intro']));
    }
    $bdlist = dhtmlspecialchars($bdlist);
    include template($pluginid.':mobile_list_brand');
}else{
    if($bdlist){

        $commentkhf = array();
        foreach($bdlist as $k=>$v){
            if($_G['cache']['plugin']['aljhb']){
                if($_G['cache']['plugin']['aljhb']['is_expire']){
                    $hb_count = DB::result_first('select count(*) from %t where hid=%d and pluginid=%s and module=%s and sign=0 and status=0',array('aljhb_count',$v['id'],'aljbd','brand'));
                }else{
                    $hb_count = DB::result_first('select count(*) from %t where hid=%d and pluginid=%s and module=%s and sign=0',array('aljhb_count',$v['id'],'aljbd','brand'));
                }
                if($hb_count){
                    $bdlist[$k]['hb_status']=1;
                }
                unset($hb_count);
            }
            //$comment = DB::fetch_first('select avg(k) k,avg(h) h,avg(f) f from %t where rubbish=0 and bid=%d and ask=0',array('aljbd_comment',$v['id']));
            $avg=C::t('#aljbd#aljbd_comment')->count_avg_by_bid($v['id']);
            $avg=intval($avg);
            /*$businesstype = explode(',',$v['businesstype']);
            $bdlist[$k]['comment'] = $comment;
            if($v['businesstype']){
                if($businesstype[0]){
                    $commentkhf[$businesstype[0]] = $comment['k'];
                }
                if($businesstype[1]){
                    $commentkhf[$businesstype[1]] = $comment['h'];
                }
                if($businesstype[2]){
                    $commentkhf[$businesstype[2]] = $comment['f'];
                }
            }
            $bdlist[$k]['c'] = $commentkhf;*/
            $bdlist[$k]['avg'] = $avg ? $avg*20 : 100;
            unset($avg);
            $sign=DB::result_first("select sign from ".DB::table('aljbd_attestation')." where sign=1 and bid=".$v['id']);
            if($sign){
                $bdlist[$k]['v'] = 1;
            }
            if($_G['cache']['plugin']['aljbzj']['is_aljbzj']){
                $bzj_info = DB::fetch_first('select * from %t where uid=%d and bid=%d ',array('aljbzj',$v['uid'],$v['id']));
                if($bzj_info['price']>0){
                    $bdlist[$k]['bond'] = 1;
                }
            }

            $glist = DB::fetch_all('select * from %t where state =0 and rubbish=0 and bid=%d AND store_id=0 order by view desc limit %d,%d',array('aljbd_goods',$v['id'],0,10));
            foreach($glist as $gk=>$gv){
                $glist[$gk]['price1']=T::skuminprice($gv['attr_sku'],$gv['commodity_type'])>0 ? T::skuminprice($gv['attr_sku'],$gv['commodity_type']) : floatval($gv['price1']);

                $glist[$gk]['price2']=floatval($gv['price2']);
                if($gv['collage_price']>0){
                    $glist[$gk]['collage_price']=T::skuminprice($gv['attr_sku'],$gv['commodity_type'])>0 ? T::skuminprice($gv['attr_sku'],$gv['commodity_type']) : floatval($gv['collage_price']);
                }
            }
            $bdlist[$k]['glist'] = $glist?$glist:'';

            unset($commentkhf);
            unset($sign);
            unset($bzj_info);
        }
        $bdlist = dhtmlspecialchars($bdlist);
        //debug($bdlist);
        $json_list['max_page'] = $max_page;
        $json_list['bdlist'] = $bdlist;
        $json_list['mes'] = $mes;
        //debug($json_list);
        echo json_encode(aljhtx::ajaxPostCharSet($json_list));
        exit;
    }else{
        echo 0;
        exit;
    }
}
//From: Dism��taobao��com
?>
