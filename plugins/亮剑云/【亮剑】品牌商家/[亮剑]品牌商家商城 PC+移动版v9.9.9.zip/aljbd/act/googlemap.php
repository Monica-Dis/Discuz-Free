<?php
$bd=C::t('#aljbd#aljbd')->fetch($_GET['bid']);
include template('aljbd:new/map/googlemap');
?>