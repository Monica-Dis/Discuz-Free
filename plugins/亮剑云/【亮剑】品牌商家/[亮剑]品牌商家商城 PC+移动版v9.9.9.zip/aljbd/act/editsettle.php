<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$settleid = htmlspecialchars($_GET['settleid']);
if($_G['cache']['plugin']['aljgwc'][$pluginid] && $_GET['cart'] != 'old'){

    require DISCUZ_ROOT.'./source/plugin/aljgwc/include/aljbd_editsettle.php';
}else{
    if($_G['cache']['plugin']['aljgwc']['aljbd_old_settle']){
        showmessage('&#26087;&#30340;&#32467;&#31639;&#24050;&#20851;&#38381;');
    }
    $cur = DB::result_first('select sum(a.amount*a.price) from %t a left join %t b on a.sid = b.id where b.uid = %d and a.status >= 2 group by b.uid',array('aljbd_order','aljbd_goods',$_G['uid'])) * (1-$config['per']);

    $cur = $cur - DB::result_first('select sum(settleprice) from %t where uid = %d and status < 2 and settleid != %s group by uid',array('aljbd_settle',$_G['uid'],$settleid));

    if (submitcheck('formhash')){
        if (empty($settleid)) {
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('".lang('plugin/aljbd','tg34')."','');</script>";
                exit;
            }else{
                showerror(lang('plugin/aljbd','tg34'));
                exit;
            }
        }
        $settle = C::t('#aljbd#aljbd_settle') -> fetch($_GET['settleid']);
        if ($settle['uid'] != $_G['uid'] && !in_array($_G['groupid'],$admingroups)) {
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('".lang('plugin/aljbd','tg35')."','');</script>";
                exit;
            }else{
                showerror(lang('plugin/aljbd','tg35'));
                exit;
            }
        }
        if ($settle['status'] != 0) {
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('".lang('plugin/aljbd','tg36')."','');</script>";
                exit;
            }else{
                showerror(lang('plugin/aljbd','tg36'));
                exit;
            }
        }
        if ($cur < $config['min']) {
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('".lang('plugin/aljbd','tg37')."','');</script>";
                exit;
            }else{
                showerror(lang('plugin/aljbd','tg37'));
                exit;
            }
        }

        C::t('#aljbd#aljbd_settle') -> update($_GET['settleid'],array(
            'settleprice' => $_GET['settleprice'],
            'username' => $_GET['username'],
            'account' => $_GET['account'],
            'payment' => $config['payment'],
            'status' => 0,
            'applytime' => TIMESTAMP,
        ));
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','tg38')."','');</script>";
            exit;
        }else{
            showmsg(lang('plugin/aljbd','tg38'));
        }

    } else{
        if (empty($settleid)){
            showmessage(lang('plugin/aljbd','tg39'));
        }
        $settle = C::t('#aljbd#aljbd_settle') -> fetch($_GET['settleid']);
        if ($settle['uid'] != $_G['uid'] && !in_array($_G['groupid'],$admingroups)) {
            showmessage(lang('plugin/aljbd','tg40'));
            exit;
        }
        include template('aljbd:settle');
    }
}
//From: Dism��taobao��com
?>