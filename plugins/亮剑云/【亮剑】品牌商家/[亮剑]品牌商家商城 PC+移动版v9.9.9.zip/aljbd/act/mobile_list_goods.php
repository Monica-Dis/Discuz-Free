<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once $common_path.'class/class_aljhtx.php';
if($config['isrewrite']&&!$_GET['page']&&(!$_G['mobile'] || !$_G['setting']['mobile']['allowmobile'])){
    if($_GET['order']=='1'){
        $_GET['order']='view';
    }else if($_GET['order']=='2'){
        $_GET['order']='price1';
    }else{
        $_GET['order']='';
    }
    if($_GET['view']=='3'){
        $_GET['view']="pic";
    }else if($_GET['view']=='4'){
        $_GET['view']="list";
    }else{
        $_GET['view']='';
    }
}
if($_GET['order'] == 'comment'){
    $_GET['order']='';
}else{
    $orderby = array('view','dateline','price1','buyamount','hot','favorate','totalpriceup','totalpricedown');
    if(!in_array($_GET['order'],$orderby)){
        $_GET['order']='';
    }
}

if(($_G['charset']=='gbk'&&!defined('IN_MOBILE')&&$config['is_daohang']&&!$_GET[page])){

    $_GET['kw']=diconv($_GET['kw'],'utf-8','gbk');
}


if($_GET['commodity_type']){
    $commodity_type = intval($_GET['commodity_type']);
}
$array = array();
if($_GET['v']){
    $array['video_path'] = 1;
}
if($aljtsq_post_goods){
    $sql = ' AND store_id>0 AND commodity_type != 4';
    if($_GET['fz_id'] > 0 || !$_G['cache']['plugin']['aljtsc']['is_aljtfz_showall']){
        $sql .= ' and fz_id='.intval($_GET['fz_id']);
    }
}else{
    $sql = ' AND store_id=0';
}
if($_GET['form'] == 'aljsqtg'){
    $commodity_type = 8;
    $sql .= ' AND category=0';
}
if(!$card_user && !$admin_status){  
    $sql .= ' AND is_aljtcc=0';
}
if($_G['cache']['plugin']['aljsqtg']['hide_aljsqtg_goods'] && $_GET['form'] != 'aljsqtg'){
	$sql .= ' AND commodity_type!=8';
}
$num=C::t('#aljbd#aljbd_goods')->count_by_status_new('','',$_GET['type'],$_GET['subtype'],$_GET['region'],$_GET['subregion'],$_GET['kw'],$_GET['subtype3'],0,$commodity_type,$array,$sql);
$currpage=$_GET['page']?$_GET['page']:1;
$perpage=10;
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start=($currpage-1)*$perpage;
$max = ceil($num/$perpage);

if($currpage == 1){
    $max_page ='<input type="hidden" id="max-page" value="'.$max.'">';
}

if($currpage == $max){
    $mes = '<div class="c_click_see" id="more" >'.$aljbdlang['php']['No_more_data'].'</div>';
}

$bdlist=C::t('#aljbd#aljbd_goods')->fetch_all_by_status_new('',$start,$perpage,'',$_GET['type'],$_GET['subtype'],$_GET['region'],$_GET['subregion'],$_GET['order'],$_GET['kw'],$_GET['subtype3'],0,$commodity_type,$array,$sql);
if($_GET['kw'] && $settings['is_self_support']['value']!=1){
    $sbdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,$start,$perpage,'','','','','','',$_GET['kw'],'','','','','',0);
}
if($bdlist || $sbdlist){
    $json_list['bdlist'] = 0;
    if($bdlist){
        foreach($bdlist as $k=>$v){
            if($_G['cache']['plugin']['aljhb']){
                if($_G['cache']['plugin']['aljhb']['is_expire']){
                    $hb_count = DB::result_first('select count(*) from %t where hid=%d and pluginid=%s and module=%s and sign=0 and status=0',array('aljhb_count',$v['id'],'aljbd','goods'));
                }else{
                    $hb_count = DB::result_first('select count(*) from %t where hid=%d and pluginid=%s and module=%s and sign=0',array('aljhb_count',$v['id'],'aljbd','goods'));
                }
                
                if($hb_count){
                    $bdlist[$k]['hb_status']=1;
                }
                unset($hb_count);
            }
            if($v['selling_point']){
                $v['selling_point'] = str_replace(array(lang('plugin/aljbd','aljbd_php_22'),lang('plugin/aljbd','aljbd_php_23')),array(',',':'),$v['selling_point']);
                $selling_point = $v['selling_point'];
                $bdlist[$k]['selling_point'] = explode(',',$selling_point);
                if(strpos($v['selling_point'],':') !== false){
                    foreach($bdlist[$k]['selling_point'] as $s_k => $sv){
                        if(strpos($sv,':') !== false){
                            $selling_point2 = explode(':',$sv);
                        }else{
                            $selling_point2 = array('*',$sv);
                        }
                        $bdlist[$k]['selling_point_types'][]=$selling_point2;
                    }
                }else{
                    $bdlist[$k]['selling_point_types'] = 1;
                }
            }
            $bdlist[$k]['price1']=T::skuminprice($v['attr_sku'],$v['commodity_type'])>0 ? T::skuminprice($v['attr_sku'],$v['commodity_type']) : floatval($v['price1']);
            $bdlist[$k]['collage_price']=T::skuminprice($v['attr_sku'],$v['commodity_type'])>0 ? T::skuminprice($v['attr_sku'],$v['commodity_type']) : floatval($v['collage_price']);
            $bdlist[$k]['price2'] = floatval($v['price2']);
            if($v['video_path']){
                $bdlist[$k]['video_status'] = 1;
            }else{
                $bdlist[$k]['video_status'] = 0;
            }
            foreach($pics as $p_v){
                $bdlist[$k][$p_v] = $v[$p_v].$oss_img_url;
            }
            if($_GET['form'] == 'aljsqtg'){
                $gwc_num = DB::result_first('select sum(num) from %t where goods_id=%d and uid=%d and pid=%d and type=8',array('aljgwc',$v['id'], $_G['uid'],0));
                $bdlist[$k]['gwc_num'] = $gwc_num ? $gwc_num : 0;
                $bdlist[$k]['gattrkey'] = unserialize($v['attr_key']);
            }
            if($settings['is_card_price']['value']==1 && $v['card_price'] > 0 && $card_user){
                if($_GET['form'] == 'aljsqtg'){
                    
                }else{
                    if($v['commodity_type'] == 2){
                        $bdlist[$k]['collage_price'] = floatval($v['card_price']).'<i class="c_p_t">'.$card_price_label.'</i>';
                    }else{
                        $bdlist[$k]['price1'] = floatval($v['card_price']).'<i class="c_p_t">'.$card_price_label.'</i>';
                    }
                }
            }
            $bdlist[$k]['name'] = dhtmlspecialchars($v['name']);
            $bdlist[$k]['selling_point'] = dhtmlspecialchars($bdlist[$k]['selling_point']);
            if(TIMESTAMP < $v['endtime'] || TIMESTAMP < $v['starttime']){
                if(TIMESTAMP < $v['starttime']){
                    $bdlist[$k]['goods_status'] = 1;
                }
            }else if($v['endtime']>0){
                $bdlist[$k]['goods_status'] = 2;
            }
            if($v['amount'] <=0){
                $bdlist[$k]['goods_status'] = 3;
            }
            $bdlist[$k]['ms_text'] = 1;
            if($_G['cache']['plugin']['aljms']['is_aljms']){
                $ms_info_notice_text='';
                $ms_date = dgmdate(TIMESTAMP, "Ymd");
                $ms_info = DB::fetch_first('select * from %t where ms_status = 0 and ms_gid=%d and ms_date=%d and ms_start_time<=%d and ms_end_time>%d and ms_sale_num<ms_num',array('aljhtx_activity_ms_enter',$v['id'],$ms_date,TIMESTAMP,TIMESTAMP));
                if($ms_info){
                    //$ms_info_notice_text = '<i style="border:1px solid #f42424;border-radius: 5px;padding:0px 2px;color:#f42424;margin-right:3px;font-size:.35rem">��ɱ��</i>'.$price_unit.$ms_info['ms_price'];
                    if($v['commodity_type'] == 2){
                        $bdlist[$k]['collage_price'] = floatval($ms_info['ms_price']).'<i style="border:1px solid #f42424;border-radius: 5px;padding:0px 2px;color:#f42424;margin-left:3px;font-size:.5rem">&#31186;&#26432;&#20215;</i>';
                    }else{
                        $bdlist[$k]['price1'] = floatval($ms_info['ms_price']).'<i style="border:1px solid #f42424;border-radius: 5px;padding:0px 2px;color:#f42424;margin-left:3px;font-size:.5rem">&#31186;&#26432;&#20215;</i>';
                    }
                }else{
                    $ms_info_notice = DB::fetch_first('select a.*,b.title from %t a left join %t b on a.ms_activity=b.id where a.ms_status = 0 and a.ms_gid=%d and a.ms_start_time>%d and a.ms_sale_num<ms_num order by a.ms_date asc limit 1',array('aljhtx_activity_ms_enter','aljhtx_activity_ms',$v['id'],TIMESTAMP));
                    
                    if($ms_info_notice){
                        $ms_info_notice_text = '<i style="border:1px solid #f42424;border-radius: 5px;padding:0px 2px;color:#f42424;margin-right:3px;font-size:.45rem">&#31186;&#26432;&#39044;&#21578;</i>'.dgmdate($ms_info_notice['ms_start_time'],'m&#26376;d&#26085; H:i').' &#31186;&#26432;&#20215; '.$price_unit.'<i style="font-size:18px;">'.floatval($ms_info_notice['ms_price']).'</i>';
                    }
                }
                $bdlist[$k]['ms_text'] = $ms_info_notice_text ? $ms_info_notice_text : 1;
                unset($ms_info_notice_text);
            }
            $other = unserialize($v['other']);
            if($other['jiaobiao_img']){
                $bdlist[$k]['jiaobiao_img'] = $other['jiaobiao_img'];
            }else{
                $bdlist[$k]['jiaobiao_img'] = 1;
            }
        }
        //$bdlist = dhtmlspecialchars($bdlist);
        //debug($bdlist);
        //include template($pluginid.':mobile_list_goods');
        $json_list['max_page'] = $max_page;
        $json_list['bdlist'] = $bdlist;
    }
    $json_list['mes'] = $mes;
    $json_list['sbdlist'] = $sbdlist;
    echo json_encode(aljhtx::ajaxPostCharSet($json_list));
}else{
    echo 0;
}
//From: Dism��taobao��com
?>