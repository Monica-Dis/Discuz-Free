<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
    dheader("location:".$login_callback);
}
if($_G['cache']['plugin']['aljgwc']['aljbd'] || $_G['cache']['plugin']['aljbdx']['is_aljqb']){
    if($_G['cache']['plugin']['aljbdx']['is_aljqb'] && file_exists('source/plugin/aljbdx/template/touch/user/user_new.htm')){
        dheader('Location: plugin.php?id=aljbdx&act=user&pluginid='.$pluginid);
    }else{
        dheader('Location: plugin.php?id=aljgwc&act=user&pluginid='.$pluginid);
    }
    exit;
}
$navtitle = $aljbdlang['php']['User_center'];
include template('aljbd:user');
?>