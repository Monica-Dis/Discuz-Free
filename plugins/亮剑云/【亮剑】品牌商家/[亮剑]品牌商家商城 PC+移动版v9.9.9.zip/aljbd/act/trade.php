<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
    //showmessage(lang('plugin/aljbd','s21'), $login_callback);
    dheader("location:".$login_callback);
}

if($gid){
    $good = C::t('#aljbd#aljbd_goods') -> fetch($gid);
    $g = $good;
}else{
    showmessage(lang('plugin/aljbd','nogoodsexists'));
}
$user = C::t('#aljbd#aljbd_user') -> fetch($_G['uid']);
$attrs = DB::fetch_all('select * from %t where tid = %d',array('aljbd_attr',$gid));
foreach($attrs as $attr){
    $goodattrs[$attr['name']][$attr['mid']]['mid'] = $attr['mid'];
    $goodattrs[$attr['name']][$attr['mid']]['content'] = $attr['content'];
}
if($config['isextcredit'] && $config['extcredit']){
    $is_url = 'plugin.php?id=aljbd&act=tradesubmit&sid='.$gid;
}else{
    if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) {
        $is_url = 'plugin.php?id=aljbd&act=wxpay&sid='.$gid;
    }else{
        $is_url = 'plugin.php?id=aljbd:mtrade&sid='.$gid;
    }
}

include template('aljbd:trade');
?>