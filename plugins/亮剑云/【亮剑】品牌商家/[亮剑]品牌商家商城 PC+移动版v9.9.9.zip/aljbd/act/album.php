<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(file_exists('source/plugin/aljbd/com/album.php')){
    if(empty($bid)){
        showmessage(lang('plugin/aljbd','nopage'));
    }
    if($_G['mobile']){
        header('location: plugin.php?id=aljbd&act=view&bid='.$_GET['bid'].'&op=album');
        exit;
    }
    $pagelist = DB::fetch_all('select * from %t where bid = %d',array('aljbd_page',$bid));
    $pagelist = dhtmlspecialchars($pagelist);
    include_once 'source/plugin/aljbd/com/album.php';
}
//From: Dism��taobao��com
?>