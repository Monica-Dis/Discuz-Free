<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$tid = intval($_GET['tid']);

$config['atypes'] = str_replace('\r', '\n', $config['atypes']);
$atypes = explode("\n", $config['atypes']);
foreach ($atypes as $k => $type) {
    $type = explode('|', $type);
    $typename[$type[0]] = trim($type[1]);
}

include template('aljbd:addattr');
?>