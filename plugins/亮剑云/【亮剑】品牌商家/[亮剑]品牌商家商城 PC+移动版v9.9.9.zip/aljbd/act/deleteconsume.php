<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
    if(submitcheck('formhash')){


        if($_GET['cid']){
            C::t('#aljbd#aljbd_consume')->update($_GET['cid'],array('rubbish'=>1));
        }

        echo 1;
        exit;
    }else{
        $url='plugin.php?id=aljbd&act=deleteconsume&cid='.$_GET['cid'];
        include template('aljbd:state');
    }
}else{
    if($_GET['formhash']!=FORMHASH){
        exit('Access Denied!');
    }
    if(empty($_G['uid'])){
        showmessage(lang('plugin/aljbd','s39'));
    }
    if($_GET['cid']){
        C::t('#aljbd#aljbd_consume')->update($_GET['cid'],array('rubbish'=>1));
    }
    showmsg(lang('plugin/aljbd','s55'));
}
//From: Dism��taobao��com
?>