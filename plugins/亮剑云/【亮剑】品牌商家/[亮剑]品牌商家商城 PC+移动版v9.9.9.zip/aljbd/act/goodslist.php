<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
    //showmessage(lang('plugin/aljbd','s21'), $login_callback);
    dheader("location:".$login_callback);
    exit;
}
if(!$aljbd && !$admin_status && !$staff){
    if($aljtsq_post_goods){//�ŵ���Ʒ
        echo "<script>alert('".lang('plugin/aljbd','aljbd_7')."');location.href='plugin.php?id=aljtsq&a=addStore&c=aljtsq';</script>";
    }else{
        echo "<script>alert('".lang('plugin/aljbd','aljbd_7')."');location.href='plugin.php?id=aljbd&act=attend';</script>";
    }
    exit;
}
$where = ' AND commodity_type !=4 AND commodity_type !=99';
if(in_array($_G['groupid'],$admingroups) && $_GET['i'] == 1){
    $uid = 0;
    $sh_status = 1;
    if($aljtsq_post_goods){//�ŵ���Ʒ
        $where .= ' AND store_id >0';
    }
}else{
    if(($staff && $bid) || $admin_status){//���̵�ԱȨ��
        $uid = 0;
    }else{
        $uid = $_G['uid'];
    }
    $sh_status = 0;
    if($aljtsq_post_goods){//�ŵ���Ʒ
        $t_array = array(
            'store_id'=>$store_id
        );
    }
}

$num = C::t('#aljbd#aljbd_goods')->count_by_uid_bid($uid, $bid, 0, $_GET['kw'],$_GET['sh_status'],$t_array,$where);
$currpage = intval($_GET['page']) ? intval($_GET['page']) : 1;
$perpage = 10;
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start = ($currpage - 1) * $perpage;

$glist = C::t('#aljbd#aljbd_goods')->fetch_all_by_uid_bid($uid, $bid, $start, $perpage, 0, $_GET['kw'],$_GET['sh_status'],$t_array,$where);


foreach($glist as $k=>$v){
    if($aljtsq_post_goods){//�ŵ���Ʒ
        $glist[$k]['bdinfo']=C::t('#aljtsq#aljtsq_store')->fetch($v['store_id']);
        $glist[$k]['bdinfo']['name'] = $glist[$k]['bdinfo']['tc_store_name'];
        $glist[$k]['bdinfo']['username'] = $glist[$k]['bdinfo']['tc_username'];
    }else{
        $glist[$k]['bdinfo']=C::t('#aljbd#aljbd')->fetch($v['bid']);
    }
    $glist[$k]['price1']=floatval($v['price1']);
    if(unserialize($v['attr_key'])){
        $glist[$k]['sku_yes'] = 1;
    }else{
        $glist[$k]['sku_yes'] = 0;
    }
    if($v['sh_status'] == 1){
        $glist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_1');
    }else if($v['sh_status'] == 2){
        $glist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_2');
    }else{
        $glist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_3');
    }
    if($v['state'] == 1){
        $glist[$k]['state_text'] = lang('plugin/aljbd','goodslist_php_4');
    }else{
        $glist[$k]['state_text'] = lang('plugin/aljbd','goodslist_php_5');
    }
}
$glist = dhtmlspecialchars($glist);
if($_GET['do'] == 'ajax'){
    if($glist){
        echo json_encode(aljhtx::ajaxPostCharSet($glist));
    }else{
        echo '1';
    }
    exit;
}else {
    //$bdlist = dhtmlspecialchars($bdlist);
    
    $paging = helper_page:: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=goodslist', 0, 11, false, false);
    $navtitle = '&#21830;&#21697;&#31649;&#29702;-' . $config['title'];
    $metakeywords = $bd['other'] ? $bd['other'] : $config['keywords'];
    $metadescription = $config['description'];
    if($newtemplate){
        include template($common_template_pluginid.':new/user/goodslist');
    }else {
        include template('aljbd:goodslist');
    }
}
//From: Dism��taobao��com
?>