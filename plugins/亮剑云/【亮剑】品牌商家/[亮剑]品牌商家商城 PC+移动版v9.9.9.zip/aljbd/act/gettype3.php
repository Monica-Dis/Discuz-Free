<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_GET['upid']){
    $typelist=C::t('#aljbd#aljbd_type')->fetch_all_by_upid($_GET['upid'],'','','');
}
include template('aljbd:gettype3');
?>