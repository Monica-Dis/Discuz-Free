<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
    showerror(lang('plugin/aljbd','s42'));
}
C::t('#aljbd#aljbd_point')->delete($_GET['pid']);
showmsg(lang('plugin/aljbd','s43'));
?>