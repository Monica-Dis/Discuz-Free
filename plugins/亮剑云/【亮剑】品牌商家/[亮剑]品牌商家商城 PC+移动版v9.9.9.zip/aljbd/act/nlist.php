<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_G['cache']['plugin']['aljshd']['is_aljshd'] && $_G['mobile']){
    header('Location: plugin.php?id=aljshd');
    exit;
}
$navtitle = lang('plugin/aljbd','index_2').$config['title'];
$metakeywords =  $config['keywords'];
$metadescription = $config['description'];
if(!$_G['mobile'] || !$_G['setting']['mobile']['allowmobile']){
    $typecount=C::t('#aljbd#aljbd_notice')->count_by_type();
    foreach($typecount as $tc){
        $tcs[$tc['type']]=$tc['num'];
    }
    if($_GET['type']){
        $subtypecount=C::t('#aljbd#aljbd_notice')->count_by_type($_GET['type']);
    }
    //$aljbd=C::t('#aljbd#aljbd')->range();
    //$aljbd = dhtmlspecialchars($aljbd);
    $typelist=C::t('#aljbd#aljbd_type_notice')->range();
    $typelist = dhtmlspecialchars($typelist);
    $recommendlist=C::t('#aljbd#aljbd')->fetch_all_by_recommend(1,0,10);
    $recommendlist = dhtmlspecialchars($recommendlist);
    if(!$card_user && !$admin_status){  
        $sql = ' AND is_aljtcc=0';
    }
    if($_G['cache']['plugin']['aljsqtg']['hide_aljsqtg_goods']){
        $sql .= ' AND commodity_type!=8';
    }
    $recommendlist_goods=C::t('#aljbd#aljbd_goods')->fetch_all_by_recommend_new(1,0,10,$sql);
    $recommendlist_goods = dhtmlspecialchars($recommendlist_goods);
}
$tlist=C::t('#aljbd#aljbd_type_notice')->fetch_all_by_upid(0);
$tlist = dhtmlspecialchars($tlist);
$config=$_G['cache']['plugin']['aljbd'];
$currpage=intval($_GET['page'])?intval($_GET['page']):1;
$perpage=12;
if($_G['charset']=='gbk'&&!defined('IN_MOBILE')&&$config['is_daohang']&&!$_GET['page']){
    $_GET['kw']=diconv($_GET['kw'],'utf-8','gbk');
}
$num=C::t('#aljbd#aljbd_notice')->count_by_uid_bid('','',$_GET['type'],$_GET['subtype'],$_GET['kw'],0);
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start=($currpage-1)*$perpage;

$day = date('d');
$mon = date('m');
$year = date('Y');
$today = date('N');
$qiday = date('Y-m-d', mktime(0, 0, 0, $mon, $day - $today + 1, $year));

$san = date('Y-m-d H:i:s', mktime(23, 59, 59, $mon, $day - $today + 3, $year));

if($_GET['order']=='1'){
    $order='view';
}else if($_GET['order']=='2'){
    $order=' and dateline >='.strtotime(date('Y-m-d 00:00:00'));
}else if($_GET['order']=='3'){
    $order=' and dateline >='.strtotime($san);
}else if($_GET['order']=='4'){
    $order=' and dateline >='.strtotime($qiday);
}

$nlist=C::t('#aljbd#aljbd_notice')->fetch_all_by_uid_bid('','',$start,$perpage,$_GET['type'],$_GET['subtype'],$order,$_GET['kw'],0);


foreach($nlist as $k=>$v){
    
    if($v['cover_pic']){
        $nlist[$k]['imgs'] = unserialize($v['cover_pic']);
    }else{
        $imgs = array();
                            
        preg_match_all('/<img.*?src=\"?(.*?\.(jpg|jpeg|gif|bmp|bnp|png))\".*?>/i', $v['content'], $match);
        
        
        foreach($match[1] as $key => $val){
            if($key > 2){
                break;
            }
            
            if(strpos($val,'http') !== false || strpos($val,'https') !== false){
                $siteurl = '';
            }else{
                $siteurl = $_G['siteurl'].'/';
            }
            list($width, $height, $type, $attr) = getimagesize($siteurl.$val);
            if($width<100){
                continue;
            }
            $imgs[] = $siteurl.$val;
        }
        $nlist[$k]['imgs'] = $imgs;
        if($imgs){
            DB::update('aljbd_notice',array('cover_pic'=>serialize($imgs)),array('id'=>$v['id']));
        }
    }
    $nlist[$k]['subject'] = dhtmlspecialchars($v[subject]);
    $nlist[$k]['pic']=$nlist[$k]['imgs'][0];

}


$notice=C::t('#aljbd#aljbd_notice')->fetch_all_by_uid_bid('','',0,9,'','','','',0);
$notice = dhtmlspecialchars($notice);
$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=nlist&type='.$_GET['type'].'&subtype='.$_GET['subtype'].'&order='.$_GET['order'], 0, 11, false, false);
if($aljbd_seo['notice_list']['seotitle']){
    if($_GET['type']){
        $cat=$typelist[$_GET['type']]['subject'];
    }
    if($_GET['subtype']){
        $cat=$typelist[$_GET['subtype']]['subject'];
    }
    $seodata = array('bbname' => $_G['setting']['bbname'],'cat'=>$cat);
    list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljbd_seo['notice_list']);
}
include template('aljbd:list_notice');
?>