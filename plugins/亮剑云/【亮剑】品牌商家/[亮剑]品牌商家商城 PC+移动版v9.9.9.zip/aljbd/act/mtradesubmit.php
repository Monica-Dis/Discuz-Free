<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_GET['formhash'] == FORMHASH){
    $num = intval($_GET['num']);
    $shop=C::t('#aljbd#aljbd_goods')->fetch($_GET['sid']);
    $good=$shop;
    if(C::t('#aljbd#aljbd_order')->fetch($orderid)) {
        echo "<script>parent.tips('".lang('credits_addfunds_order_invalid')."',function(){});</script>";
        exit;
    }
    if(empty($_G['uid'])){
        echo "<script>parent.tips('".lang('plugin/aljbd','sc2')."',function(){});</script>";
        exit;
    }
    if (empty($num)) {
        echo "<script>parent.tips('".lang('plugin/aljbd','sc16')."',function(){});</script>";
        exit;
    }
    if ($shop['amount'] < $num) {
        echo "<script>parent.tips('".lang('plugin/aljbd','sc17')."',function(){});</script>";
        exit;
    }
    if ($money < $shop['price1'] * $num) {
        echo "<script>parent.tips('".$_G['setting']['extcredits'][$config['extcredit']]['title'].lang('plugin/aljbd','index_4')."');</script>";
        exit;

    }
    if (TIMESTAMP > $shop['endtime'] && !empty($shop['endtime'])) {
        echo "<script>parent.tips('".lang('plugin/aljbd','sc19')."',function(){});</script>";
        exit;
    }
    $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(18);
    C::t('#aljbd#aljbd_goods')->update_num_by_id($_GET['sid'],$num);
    C::t('#aljbd#aljbd_order')->insert(array(
        'orderid' => $orderid,
        'status' => '1',
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'sid' => $_GET['sid'],
        'stitle' => $shop['name'],
        'amount' => $num,
        'price' => $shop['price1'],
        'submitdate' => $_G['timestamp'],
        'remarks' => $_GET['remarks'],
    ));
    $order = C::t('#aljbd#aljbd_order') -> fetch($orderid);
    if ($order['status'] == 1){
        $status = 2;
        C::t('#aljbd#aljbd_order')->update($orderid, array('status' => $status,'confirmdate' => $_G['timestamp']));
        C::t('#aljbd#aljbd_goods')->update_num2_by_id($good['id'],$order['amount']);
        $brand = C::t('#aljbd#aljbd') -> fetch($good['bid']);
        notification_add($good['uid'], 'system',str_replace('{orderid}','<a href="plugin.php?id=aljbd&act=orderlist">'.$notify->data['out_trade_no'].'</a>',str_replace('{username}',$brand['username'],str_replace('{name}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&gid='.$good['id'].'">'.$good['name'].'</a>',$_G['cache']['plugin']['aljbd']['notify_merchant'])))));
        notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&gid='.$good['id'].'">'.$good['name'].'</a>',$config['suctips'])));
        if($config['time']){
            $email_first = C::t("common_member")->fetch($order['uid']);
            $email = $email_first['email'];
            if($email_first['email']){
                $m=str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&gid='.$good['id'].'">'.$good['name'].'</a>',$config['suctips']));
                require_once libfile('function/mail');
                sendmail_cron($email,$config['mailtitle'],$m);
            }
        }
        $email_f = C::t("common_member")->fetch($good['uid']);
        $e = $email_f['email'];
        if($email_f['email']){
            $me=str_replace('{orderid}','<a href="'.$_G['siteurl'].'/plugin.php?id=aljbd&act=orderlist">'.$orderid.'</a>',str_replace('{username}',$brand['username'],str_replace('{name}',$order['username'],str_replace('{shopname}','<a href="'.$_G['siteurl'].'/plugin.php?id=aljbd&act=goodview&gid='.$good['id'].'">'.$good['name'].'</a>',$_G['cache']['plugin']['aljbd']['notify_merchant']))));
            $t=str_replace('{orderid}',$orderid,$_G['cache']['plugin']['aljbd']['notify_merchant_title']);
            require_once libfile('function/mail');
            sendmail_cron($e,$t,$me);
        }
        updatemembercount($_G['uid'], array($config['extcredit'] => '-' . $num * $good['price1']));

        echo "<script>parent.tips('".lang('plugin/aljbd','tg15')."',function(){parent.location.href='plugin.php?id=aljbd&act=orderlist';});</script>";
        exit;

    }
}
//From: Dism��taobao��com
?>