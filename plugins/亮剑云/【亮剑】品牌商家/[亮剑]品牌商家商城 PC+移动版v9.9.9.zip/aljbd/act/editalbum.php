<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$a=C::t('#aljbd#aljbd_album')->fetch($_GET['aid']);
if(submitcheck('formhash')){
    if(empty($bid)){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','s51')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','s51'));
        }
    }
    if(empty($_GET['albumname'])){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','album_1')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','album_1'));
        }
    }
    $updatearray=array(
        'bid'=>$bid,
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'albumname'=>$_GET['albumname'],
        'description'=>$_GET['description'],
        'dateline'=>TIMESTAMP,
        'displayorder'=>'100',
    );
    C::t('#aljbd#aljbd_album')->update($_GET['aid'],$updatearray);
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('".lang('plugin/aljbd','s53')."',function(){parent.location.href='plugin.php?id=aljbd&act=albumlist';});</script>";
        exit;
    }else{
        showmsg(lang('plugin/aljbd','s53'));
    }
}else{
    if(empty($_G['uid'])){
        showmessage(lang('plugin/aljbd','s39'));
    }
    if($bid){
        $bd=C::t('#aljbd#aljbd')->fetch($bid);
    }
    $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','',$_G['uid'],'','','','','','','','','','','',0);

    include template('aljbd:addalbum');
}
//From: Dism��taobao��com
?>