<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_GET['do'] == 'ajax'){
    if($_GET['op'] == 'mb'){
        $yfmb = DB::fetch_all('select * from %t where uid=%d and template_num>0 order by id desc',array('aljmb_fee',$bd['uid']));
        if($yfmb){
            echo json_encode(aljhtx::ajaxPostCharSet($yfmb));
        }else{
            echo '1';
        }
    }else{
        if($aljtsq_post_goods){//�ŵ귢����Ʒ
            $typelist=DB::fetch_all('SELECT * FROM %t WHERE store_id=%d and type=0',array('aljbd_type_brand',$store_id),'id');;
            if($typelist_brand){
                $json_typelist = C::t('#aljtsq#aljbd_type_brand')->fetch_all_json($store_id,0);
                echo json_encode($json_typelist_brand);
            }else{
                echo '1';
            }
        }else{
            $typelist_brand=DB::fetch_all('SELECT * FROM %t WHERE bid=%d ',array('aljbd_type_brand',$bid),'id');;
            if($typelist_brand){
                $json_typelist_brand = C::t('#aljbd#aljbd_type_brand')->fetch_all_json(0,$bid);
                echo json_encode($json_typelist_brand);
            }else{
                echo '1';
            }
        }
    }
    exit;
}
if($_GET['act'] == 'editgoods'){
    if(empty($gid)){
        $info = array('desc' => lang('plugin/aljbd','noinfo'));
        $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
        aljbdShowTips($info);
    }
    $g=C::t('#aljbd#aljbd_goods')->fetch($gid);
}
if($g['other']){
    $other = unserialize($g['other']);
}
if($bd['vipid']) {
    $vipdata = DB::fetch_first('select * from %t where id=%d', array('aljbd_vip', $bd['vipid']));
    if($vipdata){
        $vipdata['store_authority'] = explode(',',$vipdata['store_authority']);
        if($aljtsq_post_goods){//�ŵ귢����Ʒ
            $vipdata['goods_intro_video'] = $vipdata['store_authority'] && in_array('store_goods_intro_video',$vipdata['store_goods_intro_video']) ? 1 : 0;
            $vipdata['is_goods'] = $vipdata['store_authority'] && in_array('store_goods_issh',$vipdata['store_goods_issh']) ? 1 : 0;
            $vipdata['is_video'] = $vipdata['store_authority'] && in_array('store_goods_video',$vipdata['store_goods_video']) ? 1 : 0;
        }else{
            $vipdata['goods_intro_video'] = $vipdata['store_authority'] && in_array('goods_intro_video',$vipdata['store_authority']) ? 1 : 0;
        }
    }
}
if(submitcheck('formhash')){
    if($_G['cache']['plugin']['aljbzj']['is_force_pay'] && $bzj_info['price'] <= 0 && $bid && file_exists("source/plugin/aljbzj/template/force_pay_tips.htm") && !$admin_status){
        include template('aljbzj:force_pay_tips');
        exit;
    }
    if($vipdata && file_exists("source/plugin/aljht/include/aljbd/viptips.php")){//���ֵ��֡����ͻ�����ʾ
        include 'source/plugin/aljht/include/aljbd/viptips.php';
    }
    
    if(empty($_GET['name'])){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','s52')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','s52'));
        }
    }
    if(!empty($_GET['price1'])){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            if(!is_numeric($_GET['price1'])) {
                echo "<script>parent.tips('&#35831;&#22635;&#20889;&#25968;&#23383;','');</script>";
                exit;
            }
        }else{
            if(!is_numeric($_GET['price1'])) {
                showerror('&#35831;&#22635;&#20889;&#25968;&#23383;');
            }

        }
    }
    if(!empty($_GET['price2'])){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            if(!is_numeric($_GET['price2'])) {
                echo "<script>parent.tips('&#35831;&#22635;&#20889;&#25968;&#23383;','');</script>";
                exit;
            }
        }else{
            if(!is_numeric($_GET['price2'])) {
                showerror('&#35831;&#22635;&#20889;&#25968;&#23383;');
            }

        }
    }
    if($_GET['price1'] > $_GET['price2'] && $_GET['price2']>0){
        echo "<script>parent.tips('".lang('plugin/aljbd','addgoods_php_1')."','');</script>";
        exit;
    }
    if($_G['cache']['plugin']['aljbd']['is_goods_postcensor']){
        
        $censor_arr = array('name'=>'&#21830;&#21697;&#21517;&#31216;','commodity_code'=>'&#21830;&#21697;&#36135;&#21495;','brief'=>'&#21830;&#21697;&#31616;&#21333;&#25551;&#36848;','selling_point'=>'&#21830;&#21697;&#21334;&#28857;','gwurl'=>'&#21830;&#21697;&#22806;&#38142;','intro'=>'&#21830;&#21697;&#20171;&#32461;');
        foreach($censor_arr as $c_k => $c_v){
            if($_GET[$c_k]){
                $censor = & discuz_censor::instance();
                $censor->check($_GET[$c_k]);
                if($censor->modbanned() || $censor->modmoderated()) {
                    echo "<script>parent.tips('".$c_v.'&#21253;&#21547;&#25935;&#24863;&#35789;&#65292;&#35831;&#37325;&#26032;&#36755;&#20837;'."','');</script>";
                    exit;
                }
            }
        }
    }
    /*if(empty($_GET['endtime'])){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','mendtime')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','mendtime'));
        }
    }*/
    $insertarray = array(
        'bid'=>$bid,
        'uid'=>$bd['uid'],
        'name'=>$_GET['name'],
        'price1'=>$_GET['price1'],
        'price2'=>$_GET['price2'],
        'new_price'=>$_GET['new_price'],
        'gwurl'=>$_GET['gwurl'],
        'type'=>$_GET['type'],
        'subtype'=>$_GET['subtype'],
        'subtype3'=>$_GET['subtype3'],
        'btypeid'=>$_GET['btypeid'],
        'bsubtypeid'=>$_GET['bsubtypeid'],
        'amount'=>$_GET['amount'],
        'state'=>$_GET['state'],
        'endtime'=>strtotime($_GET['endtime']),
        'selling_point'=>$_GET['selling_point'],
        'category'=>$_GET['category'],
        'commodity_type'=>$_GET['commodity_type'],
        'starttime'=>strtotime($_GET['starttime']),
        'brief'=>$_GET['brief'],
        'region'=>$bd['region'],
        'region1'=>$bd['region1'],
        'subregion'=>$bd['subregion'],
        'give_integral'=>$_GET['give_integral'],
        'pay_integral'=>$_GET['pay_integral'],
        'limit_amount'=>$_GET['limit_amount'],
        'is_pt_sku'=>$_GET['is_pt_sku'],
        'weight'=>$_GET['weight'],
        'service_label'=>implode(',', $_GET['service_label']),
    );
    if($aljtsq_post_goods){//�ŵ귢����Ʒ
        $insertarray['store_id'] = $store_id;
        $insertarray['uid'] = $bd['tc_uid'];
        $insertarray['bid'] = $bd['bid'];
        if(empty($store_id)){
            echo "<script>parent.tips('".lang('plugin/aljbd','addgoods_php_2')."','');</script>";
            exit;
        }
        if($_G['cache']['plugin']['aljtfz']){
            $insertarray['fz_id'] = $_G['cookie']['fz_id'];
        }
    }else{
        if(empty($bid)){
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('".lang('plugin/aljbd','s51')."','');</script>";
                exit;
            }else{
                showerror(lang('plugin/aljbd','s51'));
            }
        }
    }
    if($_G['cache']['plugin']['aljtcc']){
        if($_GET['card_price'] >= 100 && $_GET['card_price']>0 && !$settings['is_card_price']['value']){
            $hy_tips = lang("plugin/aljht","goods_php_28").'100%';
            echo "<script>parent.tips('".$hy_tips."','');</script>";
            exit;
        }
        $insertarray['card_price'] = $_GET['card_price'];
        $insertarray['is_aljtcc'] = $_GET['is_aljtcc'];
    }else{
        $insertarray['card_price'] = '0';//��Ա���ر��ۿ۹�0
    }
    $other = array();
    if($_G['cache']['plugin']['aljsqtg']['is_aljsqtg'] && $_GET['dzAdmin'] != 1){
        $insertarray['limit_type'] = $_GET['limit_type'];
        $insertarray['qg_type'] = $_GET['qg_type'];
        if($_GET['qg_type'] == 2){
            if(!$_GET['start_time'] || !$_GET['end_time']){
                echo "<script>parent.tips('&#27599;&#26085;&#25250;&#36141;&#24320;&#22987;&#36319;&#32467;&#26463;&#26102;&#38388;&#24517;&#39035;&#36873;&#25321;','');</script>";
                exit;
            }
            $other['start_time'] = $_GET['start_time'];
            $other['end_time'] = $_GET['end_time'];
        }
    }
    $other['unified_inventory'] = $_GET['unified_inventory'];
    if($_G['cache']['plugin']['aljkj']['is_aljkj']){
        $other['kj_min_price'] = $_GET['kj_min_price'];
        $other['kj_max_price'] = $_GET['kj_max_price'];
        if($_GET['commodity_type'] == 7){
            if(!$_GET['kj_min_price'] || !$_GET['kj_max_price']){
                echo "<script>parent.tips('&#30733;&#20215;&#21830;&#21697;&#30733;&#20215;&#26368;&#23567;&#20540;&#36319;&#26368;&#22823;&#20540;&#24517;&#39035;&#22635;&#20889;','');</script>";
                exit;
            }
            if($_GET['price2']<=0){
                echo "<script>parent.tips('&#30733;&#20215;&#21830;&#21697;&#24066;&#22330;&#20215;&#26684;&#24517;&#39035;&#22635;&#20889;','');</script>";
                exit;
            }
        }
    }
    if($_G['cache']['plugin']['aljsdj']['is_aljsdj']){
        include 'source/plugin/aljsdj/include/addgoods.php';
    }
    if($other){
        $insertarray['other'] = serialize($other);
    }
    if ($_GET['cover_image']) {
        if(strpos($_GET['cover_image'],$oss_domain) !== false){
            $insertarray['cover_image'] = $_GET['cover_image'];
        }else if (is_file($_GET['cover_image'])) {
            $insertarray['cover_image'] = $_GET['cover_image'];
        } else {
            unlink($g['cover_image']);
            T::delete_oss($g['cover_image']);
            $insertarray['cover_image'] = T::saveimg($_GET['cover_image'],$image_path.'logo/');
        }
    }
    
    if($_GET['commodity_type'] == 3){
        if(!$_GET['starttime']){
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('&#38480;&#26102;&#25250;&#36141;&#24320;&#22987;&#26102;&#38388;&#24517;&#39035;&#36873;&#25321;','');</script>";
                exit;
            }else{
                showerror('&#38480;&#26102;&#25250;&#36141;&#24320;&#22987;&#26102;&#38388;&#24517;&#39035;&#36873;&#25321;');
            }
        }
    }
    if($_GET['commodity_type'] == 2){
        if($_GET['collage_price']<=0){
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('&#25340;&#22242;&#20215;&#26684;&#24517;&#39035;&#22635;&#20889;','');</script>";
                exit;
            }else{
                showerror('&#25340;&#22242;&#20215;&#26684;&#24517;&#39035;&#22635;&#20889;');
            }
        }
        $insertarray['collage_price'] = $_GET['collage_price'];
        if($_GET['collage_num']<=0){
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('&#25340;&#22242;&#20154;&#25968;&#24517;&#39035;&#22635;&#20889;','');</script>";
                exit;
            }else{
                showerror('&#25340;&#22242;&#20154;&#25968;&#24517;&#39035;&#22635;&#20889;');
            }
        }
        $insertarray['collage_num'] = $_GET['collage_num'];
    }
    if($_G['cache']['plugin']['aljsfx']['is_aljsfx']){
        $insertarray['is_distribution'] = $_GET['is_distribution'];
        if($_GET['is_distribution']>0 && $_GET['dis_commission']<1){
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('&#24320;&#21551;&#20998;&#38144;&#20998;&#38144;&#20323;&#37329;&#27604;&#20363;&#24517;&#39035;&#22823;&#20110;&#48;','');</script>";
                exit;
            }else{
                showerror('&#24320;&#21551;&#20998;&#38144;&#20998;&#38144;&#20323;&#37329;&#27604;&#20363;&#24517;&#39035;&#22823;&#20110;&#48;');
            }
        }
        if($_G['cache']['plugin']['aljsfx']['fx_goods_bili']>0){
            $fx_goods_bili = $_G['cache']['plugin']['aljsfx']['fx_goods_bili'];
            if($_GET['is_distribution']>0 && $_GET['dis_commission']<$fx_goods_bili){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#20998;&#38144;&#20323;&#37329;&#27604;&#20363;&#24517;&#39035;&#22823;&#20110;".$fx_goods_bili."%','');</script>";
                    exit;
                }else{
                    showerror('&#20998;&#38144;&#20323;&#37329;&#27604;&#20363;&#24517;&#39035;&#22823;&#20110;'.$fx_goods_bili.'%');
                }
            }
        }

        if($_GET['is_distribution'] == 0){
            $insertarray['dis_commission'] = 0;
        }else{
            $insertarray['dis_commission'] = $_GET['dis_commission'];
        }
        if($vipdata['is_distribution'] == 0){
            $insertarray['dis_commission'] = 0;
            $insertarray['is_distribution'] = 0;
        }
    }
    
    if($_G['cache']['plugin']['aljgwc']['aljbd']){
        if($_GET['fare_desc'] == '999999' || $_GET['fare_desc'] == '3'){
            $insertarray['fare'] = $_GET['fare'];
        }else{
            $insertarray['fare'] = 0;
        }
        $insertarray['fare_desc'] = $_GET['fare_desc'];
        if($_GET['fare_desc'] == '3'){
            if($_GET['fare']<=0){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_php_8')."','');</script>";
                    exit;
                }else{
                    
                    showerror(lang('plugin/aljbd','aljbd_php_8'));
                }
            }
            $mb_info = DB::fetch_first('select * from %t where mid=%d and type=%s',array('aljmb_fee_template',$_GET['fare'],'byweight'));
            if($_GET['weight'] <=0 && $mb_info){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_php_9')."','');</script>";
                    exit;
                }else{
                    showerror(lang('plugin/aljbd','aljbd_php_9'));
                }
            }
        }
    }

    if($u20181224){
        if($_G['cache']['plugin']['aljsp']['is_sp']){
            $insertarray['vr_url'] = $_GET['vr_url'];
            $insertarray['video_url'] = $_GET['video_url'];
            $pattern="/(\\w+(-\\w+)*)(\\.(\\w+(-\\w+)*))*(\\?\\S*)?/";//�������ʽ
            if($_GET['vr_url'] && !in_array(strtolower(substr($_GET['vr_url'], 0, 6)), array('http:/', 'https:', 'ftp://')))
            {
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#35831;&#36755;&#20837;&#27491;&#30830;&#30340;&#86;&#82;&#35270;&#39057;&#32593;&#22336;','');</script>";
                    exit;
                }else{
                    showerror('&#35831;&#36755;&#20837;&#27491;&#30830;&#30340;&#86;&#82;&#35270;&#39057;&#32593;&#22336;');
                }
            }
            if($_GET['video_url'] && !in_array(strtolower(substr($_GET['video_url'], 0, 6)), array('http:/', 'https:', 'ftp://')))
            {
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#35831;&#36755;&#20837;&#27491;&#30830;&#30340;&#35270;&#39057;&#32593;&#22336;','');</script>";
                    exit;
                }else{
                    showerror('&#35831;&#36755;&#20837;&#27491;&#30830;&#30340;&#35270;&#39057;&#32593;&#22336;');
                }
            }
        }
        if($_G['cache']['plugin']['aljoss']['Access_Key']){
            $insertarray['video_path'] = $_GET['video_path'];
            if($g && $_GET['del_video'] && $_GET['copy'] != '1'){
                
                T::delete_oss($g['video_path']);
                if($_GET['del_video']){
                    $insertarray['video_path'] = '';
                }
            }
            $insertarray['intro_video_path'] = $_GET['intro_video_path'];
            if($g && !$_GET['intro_video_path'] && $_GET['copy'] != '1'){
                
                T::delete_oss($g['intro_video_path']);
            }
        }
        if($vipdata['is_video'] == 0 && $_GET['copy'] != '1'){
            $insertarray['vr_url'] = '';
            $insertarray['video_url'] = '';
            if($_GET['video_path']){
                T::delete_oss($_GET['video_path']);
            }
            T::delete_oss($g['video_path']);
            $insertarray['video_path'] = '';
        }
        if($vipdata['goods_intro_video'] == 0 && $_GET['copy'] != '1'){
            
            T::delete_oss($g['intro_video_path']);
            $insertarray['intro_video_path'] = '';
        }
    }
    if($_GET['m_intro_img']){
        foreach($_GET['m_intro_img'] as $tmp_key=> $tmp_value) {
            if(strpos($tmp_value,$oss_domain) !== false){
                $src_slt[] = $tmp_value;
            }else if (is_file($tmp_value)) {
                $src_slt[] = $tmp_value;
            }else {
                $src_slt[] = T::saveimg($tmp_value,$path);
            }
        }
        $insertarray['m_intro_img'] = implode('|', $src_slt);
    }else{
        $insertarray['m_intro_img'] = '';
    }
    if($_GET['m_intro_text']){
        foreach($_GET['m_intro_text'] as $tmp_key=> $tmp_value) {
            $src_slt_text[] = $tmp_value;
        }
        $insertarray['m_intro_text'] = implode('|', $src_slt_text);
    }else{
        $insertarray['m_intro_text'] = '';
    }
    if($_GET['commodity_code'] && $settings['is_commodity_code']['value']==1){
        if($_GET['act'] != 'editgoods'){
            $mod = DB::result_first('select count(*) from %t where commodity_code=%s',array('aljbd_goods',$_GET['commodity_code']));
            if($mod){
                echo "<script>parent.tips('".lang('plugin/aljbd','addgoods_php_3')."','');</script>";
                exit;
            }
        } else {
            $mod = DB::result_first('select count(*) from %t where commodity_code=%s',array('aljbd_goods',$_GET['commodity_code']));
            if($mod && $goods['commodity_code'] != $_GET['commodity_code']){
                echo "<script>parent.tips('".lang('plugin/aljbd','addgoods_php_3')."','');</script>";
                exit;
            }
        }
    }
    
    $insertarray['commodity_code'] = $_GET['commodity_code'] ? $_GET['commodity_code'] : createOrderSn();
    if($_GET['act'] != 'editgoods'){

        if($settings['is_attes']['value']){
            if($aljtsq_post_goods){//�ŵ귢����Ʒ
                $sign = DB::result_first("select sign from ".DB::table('aljtc_attestation')." where type=3 and store_id=".$store_id);
            }else{
                $sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
            }
            
            if(!$sign){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#24215;&#38138;&#24517;&#39035;&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#21830;&#21697;','');</script>";
                    exit;
                }else{
                    showerror('&#24215;&#38138;&#24517;&#39035;&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#21830;&#21697;');
                }
            }
        }
        if($settings['is_form']['value']){
            if(DB::result_first('select * from %t where name = %s and bid=%d',array('aljbd_goods',$_GET['name'],$bid))){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#21830;&#21697;&#24050;&#23384;&#22312;','');</script>";
                    exit;
                }else{
                    showerror('&#21830;&#21697;&#24050;&#23384;&#22312;');
                }
            }
            if(!valid_token($_GET['aljbd_goods_token'],getcookie('aljbd_goods_token'),'aljbd_goods_token')){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#27491;&#22312;&#21069;&#24448;&#21830;&#21697;&#31649;&#29702;',function(){parent.location.href='plugin.php?id=aljbd&act=goodslist';});</script>";
                    exit;
                }else{
                    showerror('&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#35831;&#21047;&#26032;&#21518;&#37325;&#26032;&#21457;&#24067;&#25110;<a href="plugin.php?id=aljbd&act=goodslist">&#36820;&#22238;&#21830;&#21697;&#31649;&#29702;&#26597;&#30475;&#21830;&#21697;</a>');
                }
            }
        }
    }
    $path = $image_path.'logo/';
    if($_G['cache']['plugin']['aljhtx'] && $_G['mobile']) {
        if ($_GET['pic']) {
            

            for ($pi = 1; $pi <= $imgnum; $pi++) {
                if($_GET['pic'][$pi-1]){
                    if(strpos($_GET['pic'][$pi-1],$oss_domain) !== false){
                        $insertarray['pic'.$pi] = $_GET['pic'][$pi-1];
                    }else if (is_file($_GET['pic'][$pi-1])) {
                        $insertarray['pic'.$pi] = $_GET['pic'][$pi-1];
                    } else {
                        unlink($g['pic'.$pi]);
                        unlink($g['pic'.$pi].'.60x60.jpg');
                        unlink($g['pic'.$pi].'.205x205.jpg');
                        unlink($g['pic'.$pi].'.470x470.jpg');
                        T::delete_oss($g['pic'.$pi]);
                        $insertarray['pic'.$pi] = T::saveimg($_GET['pic'][$pi-1],$path);
                    }
                }
            }
        }else{
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('&#26368;&#23569;&#19978;&#20256;&#19968;&#24352;&#22270;&#29255;','');</script>";
                exit;
            }else{
                showerror('&#26368;&#23569;&#19978;&#20256;&#19968;&#24352;&#22270;&#29255;');
            }
        }
    }else{
        if($_GET['compress'] == '1'){
            if(!$_FILES['pic1']['tmp_name'] && !$_GET['pic1']) {
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('".lang('plugin/aljbd','s56')."','');</script>";
                    exit;
                }else{
                    showerror(lang('plugin/aljbd','s56'));
                }
            }
            for ($i = 1; $i <= $imgnum; $i++) {
                $pic = 'pic' . $i;
                if ($_FILES[$pic]['tmp_name']) {
                    $picname = $_FILES[$pic]['name'];
                    $picsize = $_FILES[$pic]['size'];
                    if ($picname != "") {
                        $type = strtolower(strrchr($picname, '.'));
                        if ($type != ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
                            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                                echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
                                exit;
                            }else{
                                showerror(lang('plugin/aljbd','s19'));
                            }
                        }
                        if (($picsize/1024)>$config['img_size']) {

                            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                                echo "<script>parent.tips('".lang('plugin/aljbd','img1').$config['img_size'].'KB'."','');</script>";
                                exit;
                            }else{
                                showerror(lang('plugin/aljbd','img1').$config['img_size'].'KB');
                            }
                        }
                        $rand = rand(100, 999);
                        $pics = date("YmdHis") . $rand . $type;
                        $img_dir = $image_path.'logo/'.date('Ymd',TIMESTAMP).'/';
                        if (!is_dir($img_dir)) {
                            mkdir($img_dir);
                        }
                        $$pic = $img_dir . $pics;
                        if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {

                            if($_G['cache']['plugin']['aljbd']['iswatermark']){
                                $image->Watermark(DISCUZ_ROOT.'./'.$$pic,'', 'forum','');
                            }
                        }

                    }
                }
            }
        }else{
            if(!$_GET['pic1']) {
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('".lang('plugin/aljbd','s56')."','');</script>";
                    exit;
                }else{
                    showerror(lang('plugin/aljbd','s56'));
                }
            }
            for ($i = 1; $i <= $imgnum; $i++) {
                $pic = 'pic' . $i;
                if (!is_file($_GET[$pic])) {
                    $rand = rand(100, 999);
                    $pics = date("YmdHis") . $rand . '.jpg';
                    $img_dir = $image_path.'logo/'.date('Ymd',TIMESTAMP).'/';
                    if (!is_dir($img_dir)) {
                        mkdir($img_dir);
                    }
                    $$pic = $img_dir . $pics;

                    $logo = file_put_contents($$pic,file_get_contents($_GET[$pic]));

                }
            }
        }
        for ($i = 1; $i <= $imgnum; $i++) {
            $pic = 'pic' . $i;
            if ($$pic) {
                unlink($g[$pic]);
                unlink($g[$pic].'.60x60.jpg');
                unlink($g[$pic].'.205x205.jpg');
                unlink($g[$pic].'.470x470.jpg');
                T::delete_oss($g[$pic]);
                $insertarray[$pic] = $$pic;
            }
        }
    }

    $insertarray['is_volume'] = $_GET['is_volume'];
    if($_GET['is_volume'] == 1){
        if($_GET['v_id']){
            foreach ($_GET['v_id'] as $v_id_key => $v_id_val){
                if($v_id_val && $_GET['volume_price'][$v_id_key] > 0 && $_GET['volume_number'][$v_id_key]>1){
                    DB::update('aljbd_goods_volume_price',array('volume_number'=>$_GET['volume_number'][$v_id_key],'volume_price'=>$_GET['volume_price'][$v_id_key],'volume_price_pt'=>$_GET['volume_price_pt'][$v_id_key]),array('id' => $v_id_val));
                }
            }
        }

        if($_GET['volume_number']){
            foreach ($_GET['volume_number'] as $v_n_key => $v_n_val){

                if($_GET['volume_price'][$v_n_key] && $v_n_val>1 && !$_GET['v_id'][$v_n_key]){
                    DB::insert('aljbd_goods_volume_price',array('price_type'=>1,'volume_number'=>$v_n_val,'volume_price'=>$_GET['volume_price'][$v_n_key],'volume_price_pt'=>$_GET['volume_price_pt'][$v_n_key],'goods_id'=>$gid));
                }
            }
        }
    }
    if($_GET['act'] == 'addgoods'){
        $insertarray['dateline'] = TIMESTAMP;
        if(file_exists("source/plugin/dz_1/dz_1.inc.php")){
            $insertarray['sccj'] = $_GET['sccj'];
            $insertarray['cpgg'] = $_GET['cpgg'];
            $insertarray['fyts'] = $_GET['fyts'];
            $insertarray['ysqz'] = $_GET['ysqz'];
            $insertarray['hdtj'] = $_GET['hdtj'];
            $insertarray['ext_num'] = $_GET['ext_num'];
        }
        if(file_exists("source/plugin/dz_3/dz_3.inc.php")){
            require_once 'source/plugin/dz_3/include/addgoods.php';
        }
        $insertarray['intro'] = $_GET['intro'];
        if($vipdata['is_goods'] >0 && file_exists("source/plugin/aljht/include/aljbd/addgoods_send.php") && !in_array($_G['groupid'],$admingroups)){//�����ʾ
            require_once 'source/plugin/aljht/include/aljbd/addgoods_send.php';
        }
        $insertid = C::t('#aljbd#aljbd_goods')->insert($insertarray, true);
        $sh_tips = $sh_tips ? $sh_tips : lang('plugin/aljbd','s53');
        $gourl = $_G['cache']['plugin']['aljht']['on'] ? 'plugin.php?id=aljht&act=admin&op=goods&do=attr&mod=my&gid='.$insertid.$aljtsq_post_goods_url : "plugin.php?id=aljbd&act=goodview&bid=".$bid."&gid=" . $insertid;
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){

            echo "<script>parent.tips('".$sh_tips."',function(){parent.location.href='".$gourl."';});</script>";
            exit;
        }else{
            showmsg($sh_tips);
        }
    }else{
        if($_G['cache']['plugin']['aljhtx'] && $_G['mobile']) {
            for ($i = 1; $i <= $imgnum; $i++) {
                $pic = 'pic' . $i;
                if (!$insertarray[$pic]) {
                    unlink($g[$pic]);
                    unlink($g[$pic] . '.60x60.jpg');
                    unlink($g[$pic] . '.205x205.jpg');
                    unlink($g[$pic] . '.470x470.jpg');
                    T::delete_oss($g[$pic]);
                }
            }
        }
        if(file_exists("source/plugin/dz_3/dz_3.inc.php")){
            require_once 'source/plugin/dz_3/include/editgoods.php';
        }
        if($_GET['intro']){
            $insertarray['intro'] = $_GET['intro'];
        }
        C::t('#aljbd#aljbd_goods')->update($gid,$insertarray);
        DB::insert('aljbd_goods_log',array(
            'gid' => $gid,
            'addtime' => TIMESTAMP,
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'goodsinfo' => serialize(C::t('#aljbd#aljbd_goods')->fetch($gid)),
            'url' => ltrim('plugin.php?'.$_SERVER['QUERY_STRING'],'/')
        ));
        savecache('aljbd_rec_goods', '');//�Ƽ���Ʒ �������
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){

            echo "<script>parent.tips('".lang('plugin/aljbd','s54')."',function(){parent.location.href='plugin.php?id=aljbd&act=goodview&bid=".$bid."&gid=" . $gid . "';});</script>";
            exit;
        }else{
            showmsg(lang('plugin/aljbd','s54'));
        }
    }

}else{
    if(empty($_G['uid'])){
        dheader("location:".$login_callback);
    }
    if($aljtsq_post_goods){//�ŵ귢����Ʒ
        if($admin_status){
            $bdlist=C::t('#aljtsq#aljtsq_store')->fetch_all_by_where(array('status'=>1));//����Ա
        }else{
            if($store_id>0){
                $staff = DB::fetch_first('select * from %t where store_id = %d and st_type=%d and st_uid=%d',array('aljtsq_staff',$store_id,2,$_G['uid']));
            }
            if($staff){
                
                $bdlist = DB::fetch_all('select * from %t where tc_id = %d',array('aljtsq_store',$store_id));
            }else{
                $bdlist=C::t('#aljtsq#aljtsq_store')->fetch_all_by_where(array('status'=>1,'uid'=>$_G['uid']));//����
            }
        }
        if($bdlist){
            foreach($bdlist as $bk=>$bv){
                
                if($bv['vipid']){
                    $v_data = DB::fetch_first('select * from %t where id=%d and type=1',array('aljbd_vip',$bv['vipid']));
                    if($v_data){
                        $v_data['store_authority'] = explode(',',$v_data['store_authority']);
                        $v_data['goods_intro_video'] = $v_data['store_authority'] && in_array('goods_intro_video',$v_data['store_authority']) ? 1 : 0;
                    }
                    $bdlist[$bk]['vipdata'] = $v_data;
                }
                unset($v_data);
            }
        }
        if(empty($store_id)){
            $store_id = $bdlist[0][tc_id];
            //showmessage(lang('plugin/aljbd','s51'));
        }
        $post_url = 'plugin.php?id=aljbd&act='.$_GET[act].'&op='.$op.'&do=ajax'.$aljtsq_post_goods_url;
        $post_param_name = 'store_id';
        if($_GET['act'] == 'addgoods'){
            if($bd['vipid']){
                $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$bd['vipid']));
                $brandnum['good']=$vipdata['good'];
                $bnum=C::t('#aljbd#aljbd_goods')->count_by_status('',$_G['uid'],'','','','','','','',array('store_id'=>$store_id));
                if($brandnum['good']){
                    if($brandnum['good'] == $checksign){
                        $info = array('desc' => lang('plugin/aljbd','noauth').$goodstips);
                        $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                        aljbdShowTips($info);
                    }
                    if($bnum>=$brandnum['good']){
                        $info = array('desc' => lang('plugin/aljbd','groups_1').$brandnum['good'].lang('plugin/aljbd','groups_3').$goodstips);
                        $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                        aljbdShowTips($info);
                    }
                }
            }
        }
    }else{
        if($admin_status){
            $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','','');//����Ա
        }else{
            if($staff && $bid){//���̵�ԱȨ��
                $bdlist = DB::fetch_all('select * from %t where id = %d',array('aljbd',$staff['store_id']));
            }else{
                $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','',$_G['uid']);//����
            }
        }
        if($bdlist){
            foreach($bdlist as $bk=>$bv){
                
                if($bv['vipid']){
                    $v_data = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$bv['vipid']));
                    if($v_data){
                        $v_data['store_authority'] = explode(',',$v_data['store_authority']);
                        $v_data['goods_intro_video'] = $v_data['store_authority'] && in_array('goods_intro_video',$v_data['store_authority']) ? 1 : 0;
                    }
                    $bdlist[$bk]['vipdata'] = $v_data;
                }
                unset($v_data);
            }
        }
        if(empty($bid)){
            $bid = $bdlist[0][id];
            //showmessage(lang('plugin/aljbd','s51'));
        }
        $post_url = 'plugin.php?id=aljbd&act='.$_GET[act].'&op='.$op.'&do=ajax';
        $post_param_name = 'bid';
        if($_GET['act'] == 'addgoods'){
            if($bd['vipid']){
                $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$bd['vipid']));
                $brandnum['good']=$vipdata['good'];
                $bnum=C::t('#aljbd#aljbd_goods')->count_by_status('',$_G['uid'],'','','','','','');
                if($brandnum['good']){
                    if($brandnum['good'] == $checksign){
                        $info = array('desc' => lang('plugin/aljbd','noauth').$goodstips);
                        $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                        aljbdShowTips($info);
                    }
                    if($bnum>=$brandnum['good']){
                        $info = array('desc' => lang('plugin/aljbd','groups_1').$brandnum['good'].lang('plugin/aljbd','groups_3').$goodstips);
                        $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                        aljbdShowTips($info);
                    }
                }
            }
            if($yhzqx){
                $brandnum=C::t('#aljbd#aljbd_usergroup')->fetch($_G['groupid']);
                $bnum=C::t('#aljbd#aljbd_goods')->count_by_status('',$_G['uid'],'','','','','','');
                if($brandnum['good']&&file_exists('source/plugin/aljbd/com/yhzqx.php')){
                    if($brandnum['good'] == $checksign){
                        $info = array('desc' => lang('plugin/aljbd','noauth').$goodstips);
                        $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                        aljbdShowTips($info);
                    }
                    if($bnum>=$brandnum['good']){
                        $info = array('desc' => lang('plugin/aljbd','groups_1').$brandnum['good'].lang('plugin/aljbd','groups_3').$goodstips);
                        $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                        aljbdShowTips($info);
                    }
                }
            }
            if($settings['is_attes']['value'] && $bid){
                $sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
                if(!$sign){
                    $info = array('desc' => lang('plugin/aljbd','aljbd_php_15'));
                    if($_G['mobile']){
                        $toUrl = 'plugin.php?id=aljbd&act=attestation&bid='.$bid;
                    }else{
                        $toUrl = 'plugin.php?id=aljht&act=admin&op=attestation&do=addattestation&bid='.$bid.'&mod=my';
                    }
                    $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_16'), 'url' => $toUrl);
                    $info['btn_default'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                    aljbdShowTips($info);
                }
            }
        }
    }
    

    

    $navtitle = lang('plugin/aljbd','index_7').'-'.$config['title'];
    $metakeywords =  $bd['other']?$bd['other']:$config['keywords'];
    $metadescription = $config['description'];
    $title = lang('plugin/aljbd','index_7');
    if($g['is_volume'] == 1) {
        // price_type 1=������� 2=����� 3=����
        $volume_price = DB::fetch_all('select * from %t where goods_id=%d and price_type=1', array('aljbd_goods_volume_price', $gid));
    }
    if($newtemplate){
        if($aljtsq_post_goods){//�ŵ귢����Ʒ
            $typelist=C::t('#aljtsc#aljtsc_type')->range();
            $json_typelist = C::t('#aljtsc#aljtsc_type')->fetch_all_json();
        }else{
            $typelist=C::t('#aljbd#aljbd_type_goods')->range();
            $json_typelist = C::t('#aljbd#aljbd_type_goods')->fetch_all_json();
        }
        
        $typejson = json_encode($json_typelist);
        if($g['type']){
            $default_type = trim(preg_replace('# #','',$typelist[$g['type']]['subject'])).' '. ($typelist[$g['subtype']]['subject']?trim(preg_replace('# #','',$typelist[$g['subtype']]['subject'])):'--').' '.($typelist[$g['subtype3']]['subject']?trim(preg_replace('# #','',$typelist[$g['subtype3']]['subject'])):'--');
            $type = $g['type'];
            $subtype = $g['subtype'];
            $subtype3 = $g['subtype3'];
        }else{
            $default_type = diconv($json_typelist[0]['name'].' '. $json_typelist[0]['sub'][0]['name'].' '.$json_typelist[0]['sub'][0]['sub'][0]['name'], 'utf-8', CHARSET);
            $type = $json_typelist[0]['code'];
            $subtype = $json_typelist[0]['sub'][0]['code'];
            $subtype3 = $json_typelist[0]['sub'][0]['sub'][0]['code'];
        }
        if($_G['cache']['plugin']['aljht']['on']){
            $service_label = DB::fetch_all('select * from %t where type=1 order by displayorder desc,id asc',array('aljbd_ather'));
        }
        if(!empty($g['m_intro_img'])){
            $post['poster_slt'] = explode("|", $g['m_intro_img']);
        }
        if(!empty($g['m_intro_text'])){
            $post['poster_slt_text'] = explode("|", $g['m_intro_text']);
        }
        if($aljtsq_post_goods){//�ŵ귢����Ʒ
            $typelist_brand=DB::fetch_all('SELECT * FROM %t WHERE store_id=%d AND type=0 ',array('aljbd_type_brand',$store_id),'id');;

            $json_typelist_brand = C::t('#aljtsq#aljbd_type_brand')->fetch_all_json($store_id,0,0);

            
        }else{
            $typelist_brand=DB::fetch_all('SELECT * FROM %t WHERE bid=%d ',array('aljbd_type_brand',$bid),'id');;
            
            $json_typelist_brand = C::t('#aljbd#aljbd_type_brand')->fetch_all_json(0,$bid);
        }
        
        if($typelist_brand){
            $typejson_brand = json_encode($json_typelist_brand);

            if($g['btypeid']){
                $default_type_brand = trim(preg_replace('# #','',$typelist_brand[$g['btypeid']]['subject'])).' '. ($typelist_brand[$g['bsubtypeid']]['subject'] ? trim(preg_replace('# #','',$typelist_brand[$g['bsubtypeid']]['subject'])) : '--');
                $type_brand = $g['btypeid'];
                $subtype_brand = $g['bsubtypeid'];
            }else{
                $default_type_brand = diconv($json_typelist_brand[0]['name'].' '. $json_typelist_brand[0]['sub'][0]['name'], 'utf-8', CHARSET);
                $type_brand = $json_typelist_brand[0]['code'];
                $subtype_brand = $json_typelist_brand[0]['sub'][0]['code'];
            }
        }
        
        
        include template($common_template_pluginid.':new/post/addgoods');
    }else {
        $typelist=C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid(0,'','','');
        //$rlist=C::t('#aljbd#aljbd_region')->fetch_all_by_upid();
        //$bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','',$_G['uid'],'','','','','','','','','','','',0);
        include template('aljbd:addgoods');
    }
}
//From: Dism��taobao��com
?>
