<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($bid)){
    showmessage(lang('plugin/aljbd','noexists'));
}
$bd=C::t('#aljbd#aljbd')->fetch($bid);
if(empty($bd) || $bd['rubbish']==1){
    showmessage(lang('plugin/aljbd','noexists'));
}
if($_G['mobile']){
    if($bd['brand_bg']){
        $top_bg = $bd['brand_bg'];
    }elseif($_G['cache']['plugin']['aljbd']['def_brand_bg']){
        $top_bg = $_G['cache']['plugin']['aljbd']['def_brand_bg'];
    }else{
        $top_bg = 'source/plugin/aljbd/images/shop-bg.png';
    }
}
$sign=DB::fetch_first("select * from ".DB::table('aljbd_attestation')." where sign=1 and bid=".$bid);
$navtitle = $bd['name'];
$metakeywords =  $bd['other']?$bd['other']:$config['keywords'];
$metadescription = $config['description'];
if($aljbd_seo['view']['seotitle']){
    $seodata = array('bbname' => $_G['setting']['bbname'],'subject'=>$bd['name'],'message'=>cutstr(strip_tags(preg_replace('/\<img.*?\>/is', '', $bd['intro'])),80),'cat' => $typelist[$bd['type']]['subject'],'cat2' => $typelist[$bd['subtype']]['subject'],'cat3' => $typelist[$bd['subtype3']]['subject'],'region' => $rlist[$bd['region']]['name'],'region2' => $rlist[$bd['subregion']]['name'],'region3' => $rlist[$bd['region1']]['name'],'view_keyword' => $bd['other']);
    list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljbd_seo['view']);
}
if($_GET['op'] == 'view_business_license'){
    include template('aljht:aljbd/view/view_business_license');
    exit;
}
$avg=C::t('#aljbd#aljbd_comment')->count_avg_by_bid($bd['id']);
$avg=intval($avg);
$gg=explode("\n",str_replace(array("\r\n","\r"),array("\n","\n"),$bd['gg']));

$adv=unserialize($bd['adv']);

$advurl=unserialize($bd['advurl']);
$madv=unserialize($bd['madv']);
$madvurl=unserialize($bd['madvurl']);
if(file_exists("source/plugin/dcdz/dcdz.inc.php")){
    $bd['curl'] = unserialize($bd['curl']);
}

$commentcount=C::t('#aljbd#aljbd_comment')->count_by_bid_upid($bid,0,0);
require_once libfile('function/discuzcode');
$askcount=C::t('#aljbd#aljbd_comment')->count_by_bid_upid($bid,0,1);
$commentlist=C::t('#aljbd#aljbd_comment')->fetch_all_by_bid_upid($bid,0,0);
$commentlist=dhtmlspecialchars($commentlist);
$tell=str_replace('{qq}',$bd['qq'],str_replace('{tel}',$bd['tel'],$config['tel']));
$qq=str_replace('{qq}',$bd['qq'],$config['qq']);
if(file_exists('source/plugin/mapp_share/api/api.php')){
    $shareid = $bid;
    $sharetype = 1;
    require_once 'source/plugin/mapp_share/api/api.php';
}
$geturl = array(
    'id' => $pluginid,
    'act' => 'mobile_index_goods',
    'keywords' => $_GET['keywords'],
    'btypeid' => $_GET['btypeid'],
    'bsubtypeid' => $_GET['bsubtypeid'],
    'bid' => $bid,
    'mobilediy' => $_GET['mobilediy'],
    'mobiledemomode' => $_GET['mobiledemomode'],
);
include template('aljht:aljbd/view/view_about');
?>