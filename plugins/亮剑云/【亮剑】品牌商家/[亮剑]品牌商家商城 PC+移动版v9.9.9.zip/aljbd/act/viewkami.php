<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$orderid= $_GET['orderid'];
if($orderid){
    
    $num=DB::result_first('select count(*) from %t where orderid = %s',array('aljbd_kami',$orderid));
    $currpage=intval($_GET['page'])?intval($_GET['page']):1;
    $perpage=10;
    
    if(@ceil($num/$perpage) < $currpage && $no_max_page){
        $currpage=1;
    }
    $start=($currpage-1)*$perpage;
    $kamilist=DB::fetch_all('select * from %t where orderid = %s order by mid desc',array('aljbd_kami',$orderid));
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=viewkami&orderid='.$orderid, 0, 11, false, false);
    include template('aljbd:viewkami');
}
//From: Dism��taobao��com
?>