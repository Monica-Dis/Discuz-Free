<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$navtitle = '��Ϣ-'.$config['title'];
$metakeywords =  $config['keywords'];
$metadescription = $config['description'];
include template($common_template_pluginid.':new/user/new');
?>