<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

C::t('#aljbd#aljbd_comment')->delete($_GET['cid']);

$num=C::t('#aljbd#aljbd_comment')->count_by_bid_all($bid);
$currpage=intval($_GET['page'])?intval($_GET['page']):1;
$perpage=10;
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start=($currpage-1)*$perpage;
$commentlist=C::t('#aljbd#aljbd_comment')->fetch_all_by_bid_page($bid,$start,$perpage);
$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=commentlist&bid='.$bid, 0, 11, false, false);
include template('aljbd:commentlist');
?>