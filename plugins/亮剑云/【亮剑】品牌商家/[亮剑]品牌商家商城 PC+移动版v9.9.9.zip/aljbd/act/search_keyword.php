<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_GET['insert'] == 'yes'){
    if($_G['charset']=='gbk'&&!defined('IN_MOBILE')){
        $_GET['keyword']=diconv($_GET['keyword'],'utf-8','gbk');
    }
    DB::insert('aljbd_search_keyword',array('keyword'=>$_GET['keyword'],'uid'=>$_G['uid'],'username'=>$_G['username'],'timestamp'=>TIMESTAMP),true);
    
    if($_G['cache']['plugin']['aljbd']['iscensor']){
        
        
        $censor = & discuz_censor::instance();
        $censor->check($_GET['keyword']);
        if($censor->modbanned() || $censor->modmoderated()) {
            echo 2;
            exit;
        }
    }
    if($_G['cache']['plugin']['aljbd_ss']['search_keyword']){
        $search_keyword = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljbd_ss']['search_keyword']));
        foreach($search_keyword as $key=>$value){
            $arr=explode('|',$value);
            $search_keyword_arr[$arr[0]]=$arr[1];
        }
    }
    $search_url = '';
    if(!$settings['close_goods']['value']){
        if($search_keyword_arr[$_GET['keyword']]){
            $search_url = $search_keyword_arr[$_GET['keyword']];
        }
    }
    if($search_url){
        echo $search_url;
    }else{
        echo 1;
    }
    exit;
}else{
    if($_G['cache']['plugin']['aljbd']['iscensor']){
        
        
        $censor = & discuz_censor::instance();
        $censor->check($_GET['keyword']);
        if($censor->modbanned() || $censor->modmoderated()) {
            echo 2;
            exit;
        }
    }
    $keyword = '%' . addcslashes($_GET['keyword'], '%_') . '%';
    $keywordarray = DB::fetch_all('select distinct keyword from %t where keyword like %s limit 0,10',array('aljbd_search_keyword',$keyword));
    if($keywordarray){
        foreach($keywordarray as $k => $v){
            $json_list[] = diconv($v['keyword'],CHARSET,'UTF-8');
        }
        echo json_encode($json_list);
        exit;
    }
}
//From: Dism��taobao��com
?>