<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('formhash')){

    if(empty($_GET['commentmessage_1'])){
        showerror(lang('plugin/aljbd','s35'));
    }
    if(empty($_G['uid'])){
        showerror(lang('plugin/aljbd','s21'));
    }
    if($_G['cache']['plugin']['aljht']['on']){
        $status = 1;
    }
    $insertarray=array(
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'content'=>$_GET['commentmessage_1'],
        'bid'=>$bid,
        'displayorder'=>$_GET['isprivate'],
        'dateline'=>TIMESTAMP,
        'upid'=>$_GET['upid'],
        'status'=>$status,
    );
    C::t('#aljbd#aljbd_comment')->insert($insertarray);
    if($_G['cache']['plugin']['aljht']['on'] && file_exists("source/plugin/aljht/include/aljbd/replytips.php")){
        include 'source/plugin/aljht/include/aljbd/replytips.php';
    }else{
        $replytips = lang('plugin/aljbd','s36');
    }
    showmsg($replytips);
}
//From: Dism��taobao��com
?>