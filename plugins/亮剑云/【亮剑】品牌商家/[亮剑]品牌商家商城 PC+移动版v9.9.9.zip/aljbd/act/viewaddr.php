<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$order = C::t('#aljbd#aljbd_order') -> fetch($_GET['orderid']);
$uid = $order['uid'];
$user = C::t('#aljbd#aljbd_user')->fetch($uid);
include template('aljbd:viewaddr');
?>