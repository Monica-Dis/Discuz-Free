<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
    //showmessage(lang('plugin/aljbd','s21'), $login_callback);
    dheader("location:".$login_callback);
}
$uid = $_G['uid'];

if (submitcheck('submit')) {
    if (C::t('#aljbd#aljbd_user')->fetch($uid)) {
        $updatearray = array(
            'username' => $_GET['name'],
            'qq' => $_GET['qq'],
            'tel' => $_GET['tel'],
            'addr' => $_GET['addr'],
        );
        C::t('#aljbd#aljbd_user')->update($uid, $updatearray);
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            if($gid){
                echo "<script>parent.tips('".lang('plugin/aljbd','tg18')."',function(){parent.location.href='plugin.php?id=aljbd&act=trade&gid=".$gid."';});</script>";
            }else{
                echo "<script>parent.tips('".lang('plugin/aljbd','tg18')."','');</script>";
            }
            exit;
        }else{
            echo "<script>parent.showDialog('".lang('plugin/aljbd','tg18')."','right','',function(){parent.location.href=parent.location.href;});</script>";
            exit;
        }

    } else {
        $insertarray = array(
            'uid' => $uid,
            'username' => $_GET['name'],
            'qq' => $_GET['qq'],
            'tel' => $_GET['tel'],
            'addr' => $_GET['addr'],
        );
        C::t('#aljbd#aljbd_user')->insert($insertarray);

        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            if($gid){
                echo "<script>parent.tips('".lang('plugin/aljbd','tg19')."',function(){parent.location.href='plugin.php?id=aljbd&act=trade&gid=".$gid."';});</script>";
            }else{
                echo "<script>parent.tips('".lang('plugin/aljbd','tg19')."','');</script>";
            }
            exit;
        }else{
            echo "<script>parent.showDialog('".lang('plugin/aljbd','tg19')."','right','',function(){parent.location.href=parent.location.href;});</script>";
            exit;
        }
    }
} else {
    $user = C::t('#aljbd#aljbd_user')->fetch($uid);
    include template('aljbd:addr');
}
//From: Dism��taobao��com
?>