<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('formhash')){
    if(empty($bid)){
        showerror(lang('plugin/aljbd','s51'));
    }
    if($settings['is_attes']['value']){
        $sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
        if(!$sign){
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('&#24215;&#38138;&#24517;&#39035;&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#24215;&#38138;&#23548;&#33322;','');</script>";
                exit;
            }else{
                showerror('&#24215;&#38138;&#24517;&#39035;&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#24215;&#38138;&#23548;&#33322;');
            }
        }
    }
    if(empty($_GET['subject'])){
        showerror(lang('plugin/aljbd','aljbd_1'));
    }
    if(empty($_GET['intro'])){
        showerror(lang('plugin/aljbd','aljbd_2'));
    }
    C::t('#aljbd#aljbd_page')->insert(array(
        'bid'=>$bid,
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'subject'=>$_GET['subject'],
        'content'=>$_GET['intro'],
        'dateline'=>TIMESTAMP,
        'type'=>$_GET['type'],
        'subtype'=>$_GET['subtype'],
        'displayorder'=>$_GET['displayorder'],
    ));
    showmsg(lang('plugin/aljbd','s53'));
}else{
    if(empty($_G['uid'])){
        //showmessage(lang('plugin/aljbd','s21'), $login_callback);
        dheader("location:".$login_callback);
    }
    if(empty($bid)){
        $info = array('desc' => lang('plugin/aljbd','s51'));
        $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
        aljbdShowTips($info);
    }
    if($bid){
        $bd=C::t('#aljbd#aljbd')->fetch($bid);
    }
    //$bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','',$_G['uid'],'','','','','','','','','','','',0);

    include template('aljbd:addpage');
}
//From: Dism��taobao��com
?>