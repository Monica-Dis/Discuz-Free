<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(file_exists('source/plugin/aljbd/com/mark.php')){
    include_once 'source/plugin/aljbd/com/mark.php';
}
//From: Dism��taobao��com
?>