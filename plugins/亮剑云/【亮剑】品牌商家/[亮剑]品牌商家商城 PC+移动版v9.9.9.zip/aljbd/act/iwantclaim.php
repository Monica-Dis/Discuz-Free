<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('formhash')){
    if(empty($_GET['name'])){
        showerror(lang('plugin/aljbd','s47'));
    }
    $user=C::t('common_member')->fetch_by_username($_GET['name']);
    if(empty($user)){
        showerror(lang('plugin/aljbd','s48'));
    }
    C::t('#aljbd#aljbd')->update($bid,array('uid'=>$user['uid'],'username'=>$_GET['name']));
    DB::update('aljbd_album',array('uid'=>$user['uid'],'username'=>$_GET['name']),'bid='.$bid);
    DB::update('aljbd_consume',array('uid'=>$user['uid'],'username'=>$_GET['name']),'bid='.$bid);
    DB::update('aljbd_notice',array('uid'=>$user['uid'],'username'=>$_GET['name']),'bid='.$bid);
    DB::update('aljbd_goods',array('uid'=>$user['uid']),'bid='.$bid);
    DB::update('aljbd_album_attachments',array('uid'=>$user['uid']),'bid='.$bid);

    showmsg(lang('plugin/aljbd','s49'));
}else{
    include template('aljbd:iwantclaim');
}
//From: Dism��taobao��com
?>