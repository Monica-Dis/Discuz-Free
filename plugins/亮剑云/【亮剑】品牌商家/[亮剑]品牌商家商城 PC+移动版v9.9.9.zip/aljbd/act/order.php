<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$navtitle = lang('plugin/aljbd','sj_6').$config['title'];
$metakeywords =  $config['keywords'];
$metadescription = $config['description'];
include template('aljbd:order');
?>