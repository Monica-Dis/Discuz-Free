<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_G['cache']['plugin']['aljwx']['wx_url']){
    $miniurl = $_G['cache']['plugin']['aljwx']['wx_url'];
}else{
    $miniurl = 'plugin.php?id=aljbd&mobile=2';
}
dheader("location: ".$miniurl);
exit;
?>
