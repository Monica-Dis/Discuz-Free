<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$num=DB::result_first('select count(*) from %t where rubbish=0',array('aljbd_album'));
$currpage=intval($_GET['page'])?intval($_GET['page']):1;
$perpage=20;
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$total_page = ceil($num/$perpage);
for($i=1;$i<$total_page;$i++){
    if($currpage==$i){
        $class='class="p_curpage"';
    }else{
        $class='class="p_num"';
    }
    $url.='<a '.$class.' href="plugin.php?id=aljbd&act=ajax&page='.$i.'">'.$i.'</a>&nbsp;';
}
$allpage=ceil($num/$perpage);
$start=($currpage-1)*$perpage;
$alist=DB::fetch_all('select * from %t where rubbish=0 order by id desc limit %d,%d',array('aljbd_album',$start,$perpage));
include template('aljbd:ajax');
?>