<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$n=C::t('#aljbd#aljbd_notice')->fetch($_GET['nid']);
$num=DB::result_first(" select count(*) from ".DB::table('aljbd_comment_notice')." where nid=".$n['id']." and bid=".$n['bid']);

$total_page = ceil($num/$perpage);

if($total_page>1){
    if($currpage > 1){
        $shangyiye='<a href="plugin.php?id=aljbd&act=replynotice&nid='.$n['id'].'&bid='.$n['bid'].'&page='.($currpage-1).'">'.lang('plugin/aljbd','sj_3').'</a>&nbsp;&nbsp;';
    }else{
        $shangyiye='<span>'.lang('plugin/aljbd','sj_3').'</span>';
    }

    if($currpage < $total_page){
        //debug(123);
        $xiayiye= '<a href="plugin.php?id=aljbd&act=replynotice&nid='.$n['id'].'&bid='.$n['bid'].'&page='.($currpage+1).'">'.lang('plugin/aljbd','sj_2').'</a>&nbsp;&nbsp;';
        //debug($xiayiye);
    }else{
        $xiayiye='<span>'.lang('plugin/aljbd','sj_2').'</span>';
    }
}
$allpage=ceil($num/$perpage);
$start=($currpage-1)*$perpage;
$nask=DB::fetch_all(" select * from ".DB::table('aljbd_comment_notice')." where nid=".$n['id']." and bid=".$n['bid']);
include template('aljbd:replynotice');
?>