<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_GET['type'] == 'attend' || $_GET['type'] == 'addgoods'  || $_GET['type'] == 'edit'  || $_GET['type'] == 'editgoods' || $_GET['type'] == 'attestation'){
    $position = 'logo';
}elseif($_GET['type'] == 'addconsume' || $_GET['type'] == 'editconsume'){
    $position = 'consume';
}elseif($_GET['type'] == 'addalbumimg'){
    $position = 'album';
}

$fn = (isset($_GET['base64']) ? $_GET['base64'] : false);
$logo_name = isset($_GET['name']) ? $_GET['name'] : 'logo';
$fn_length = intval($_GET['size']);

if ($fn && $fn_length == strlen($fn) && $_GET['hash'] == FORMHASH) {

    $rand = rand(100, 999);
    $pics = date("YmdHis") . $rand . '.jpg';
    $img_dir = $image_path.$position.'/'.date('Ymd',TIMESTAMP).'/';
    if (!is_dir($img_dir)) {
        mkdir($img_dir);
    }
    $pic = $img_dir . $pics;

    file_put_contents($pic,file_get_contents($fn));

    if (file_exists($pic)) {
        if($_G['cache']['plugin']['aljbd']['iswatermark']){
            $image->Watermark(DISCUZ_ROOT.'./'.$pic,'', 'forum','');
        }
        if($_GET['type'] == 'addgoods' || $_GET['type'] == 'editgoods'){
            $imageinfo = getimagesize($pic);
            $w60=$imageinfo[0]<60?$imageinfo[0]:60;
            $h60=$imageinfo[1]<60?$imageinfo[1]:60;
            $w205=$imageinfo[0]<205?$imageinfo[0]:205;
            $h205=$imageinfo[1]<205?$imageinfo[1]:205;
            $w470=$imageinfo[0]<470?$imageinfo[0]:470;
            $h470=$imageinfo[1]<470?$imageinfo[1]:470;

            img2thumb($pic, $pic . '.60x60.jpg', $w60, $h60);
            img2thumb($pic, $pic . '.205x205.jpg', $w205, $h205);
            img2thumb($pic, $pic . '.470x470.jpg', $w470, $h470);
        }elseif($_GET['type'] == 'addalbumimg'){
            $imageinfo=getimagesize($pic);
            $w60=$imageinfo[0]<72?$imageinfo[0]:72;
            $h60=$imageinfo[1]<72?$imageinfo[1]:72;
            $w205=$imageinfo[0]<100?$imageinfo[0]:100;
            $h205=$imageinfo[1]<100?$imageinfo[1]:100;
            $w470=$imageinfo[0]<550?$imageinfo[0]:550;
            $h470=$imageinfo[1]<550?$imageinfo[1]:550;
            img2thumb($pic,$pic.'.72x72.jpg',$w60,$h60);
            img2thumb($pic,$pic.'.100x100.jpg',$w205,$h205);
            img2thumb($pic,$pic.'.550x550.jpg',$w470,$h470);
        }
    }

    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo '<br/><br/><img src="'.$pic.'" width="100px" height="100px"><input type="hidden" name="'.$logo_name.'" value="'.$pic.'">';
    }else{
        if($_GET['type']){
            echo '<img src="'.$pic.'" width="100px" height="100px"><input type="hidden" name="'.$logo_name.'" value="'.$pic.'">';
        }
    }


    exit();
}
//From: Dism��taobao��com
?>