<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
    showmessage(lang('plugin/aljbd','s39'));
}

if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
    if(submitcheck('formhash')){

        if($_GET['nid']){
            C::t('#aljbd#aljbd_notice')->update($_GET['nid'],array('rubbish'=>1));
        }
        echo 1;
        exit;
    }else{
        $url='plugin.php?id=aljbd&act=deletenotice&nid='.$_GET['nid'];
        include template('aljbd:state');
    }
}else{
    if($_GET['formhash']!=FORMHASH){
        exit('Access Denied!');
    }
    //unlink($bdlist['pic']);
    if($_GET['nid']){
        C::t('#aljbd#aljbd_notice')->update($_GET['nid'],array('rubbish'=>1));
    }
    showmsg(lang('plugin/aljbd','s55'));
}
//From: Dism��taobao��com
?>