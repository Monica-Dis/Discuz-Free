<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('formhash')){
    for($i=1;$i<=3;$i++){

        if($_FILES['madv']['tmp_name'][$i]) {
            $picname = $_FILES['madv']['name'][$i];
            $picsize = $_FILES['madv']['size'][$i];

            if ($picname != "") {
                $type = strtolower(strrchr($picname, '.'));
                if ($type != ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
                    showerror(lang('plugin/aljbd','s25'));
                }
                if (($picsize/1024)>$config['img_size']) {
                    showerror(lang('plugin/aljbd','img1').$config['img_size'].'KB');
                }
                $rand = rand(100, 999);
                $pics = date("YmdHis") . $rand . $type;

                $dir=$image_path.'adv/'.date('Ymd',TIMESTAMP).'/';
                if(!is_dir($dir)) {
                    @mkdir($dir, 0777);
                }
                $madv[$i] = $dir. $pics;
                if(@copy($_FILES['madv']['tmp_name'][$i], $madv[$i])||@move_uploaded_file($_FILES['madv']['tmp_name'][$i], $madv[$i])){
                    @unlink($_FILES['madv']['tmp_name'][$i]);
                }
            }
        }
    }
    $bd=C::t('#aljbd#aljbd')->fetch($bid);
    $mbadv=unserialize($bd['madv']);

    $mbadvurl=unserialize($bd['madvurl']);
    if($_GET['madvdelete']){
        foreach($_GET['madvdelete'] as $k=>$d){
            unlink($mbadv[$k]);
            unset($mbadv[$k]);

        }
    }
    if($mbadv){
        for($i=1;$i<=3;$i++){
            if($madv[$i]){
                $mbadv[$i]=$madv[$i];
            }
        }
        $madv=$mbadv;
    }


    C::t('#aljbd#aljbd')->update($bid,array('madvurl'=>serialize($_GET['madvurl']),'madv'=>serialize($madv)));
    showmsg(lang('plugin/aljbd','s27'),'edit');
}
$bd=C::t('#aljbd#aljbd')->fetch($bid);
$madv=unserialize($bd['madv']);
$madvurl=unserialize($bd['madvurl']);

include template('aljbd:madv');
?>