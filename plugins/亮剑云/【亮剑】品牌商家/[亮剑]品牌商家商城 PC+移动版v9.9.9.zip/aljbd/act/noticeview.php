<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$nid = intval($_GET['nid']);
if(empty($nid)){
    showmessage('&#26597;&#30475;&#30340;&#27963;&#21160;&#19981;&#23384;&#22312;&#25110;&#32773;&#24050;&#21024;&#38500;&#65281;');
}
if($_G['cache']['plugin']['aljshd']['is_aljshd'] && $_G['mobile']){
    header('Location: plugin.php?id=aljshd&c=aljshd&a=view&nid='.$nid);
    exit;
}
C::t('#aljbd#aljbd_notice')->update_view_by_gid($_GET['nid']);
//$check=C::t('#aljbd#aljbd_user')->fetch($_G['uid']);
$check=C::t('#aljbd#aljbd_username')->fetch_by_uid_bid($_G['uid'],$bid);
if(empty($check)&&$_G['uid']){
    C::t('#aljbd#aljbd_username')->insert(array('uid'=>$_G['uid'],'username'=>$_G['username'],'bid'=>$bid));
}
C::t('#aljbd#aljbd')->update_view_by_bid($bid);
$khf=C::t('#aljbd#aljbd_comment')->count_by_bid($bid);
foreach($khf[0] as $k=>$v){
    $khf[0][$k]=intval($v);
}
if($_G['uid'] && $_G['cache']['plugin']['aljsfx']['is_aljsfx'] && $_G['mobile']){
    $fx_shopdata = DB::fetch_first('select * from %t where uid=%d and status=1',array('aljsfx_shop',$_G['uid']));
    if(!$_GET['d'] && $fx_shopdata && !$_GET['page']){
        dheader("location: plugin.php?id=aljbd&act=noticeview&nid=".$nid."&d=".$fx_shopdata['uid']);
        exit;
    }
}
$commentcount=C::t('#aljbd#aljbd_comment')->count_by_bid_upid($bid,0,0);
$askcount=C::t('#aljbd#aljbd_comment')->count_by_bid_upid($bid,0,1);
$commentlist=C::t('#aljbd#aljbd_comment')->fetch_all_by_bid_upid($bid,0,0);
$commentlist = dhtmlspecialchars($commentlist);
$asklist=C::t('#aljbd#aljbd_comment')->fetch_all_by_bid_upid($bid,0,1);
$asklist = dhtmlspecialchars($asklist);
$bd=C::t('#aljbd#aljbd')->fetch($bid);
require_once 'source/plugin/aljbd/include/brand_tips.php';
require_once libfile('function/discuzcode');
if(!file_exists('source/plugin/aljbd/com/intro.php')){
    $bd['intro']=discuzcode($bd['intro']);
}
$avg=C::t('#aljbd#aljbd_comment')->count_avg_by_bid($bd['id']);
$avg=intval($avg);

$adv=unserialize($bd['adv']);
$advurl=unserialize($bd['advurl']);

$n=C::t('#aljbd#aljbd_notice')->fetch($_GET['nid']);
if(empty($n) || $n['rubbish'] == 1){
    showmessage('&#26597;&#30475;&#30340;&#27963;&#21160;&#19981;&#23384;&#22312;&#25110;&#32773;&#24050;&#21024;&#38500;&#65281;');
}

if($n['rec_gids']){
    $reg_goods = DB::fetch_all('select * from %t where id in(%n)',array('aljbd_goods',explode(' ',$n['rec_gids'])));
}
$n[subject] = dhtmlspecialchars($n[subject]);
$t=C::t('#aljbd#aljbd_goods')->fetch_all_by_uid_bid_view_new($g['uid'],$bid,0,6,0);
$t = dhtmlspecialchars($t);
$notice=C::t('#aljbd#aljbd_notice')->fetch_all_by_uid_bid($bd['uid'],$bid,0,9,'','','','',0);
$notice = dhtmlspecialchars($notice);
$bd = dhtmlspecialchars($bd);
$navtitle = $n['subject'].'-'.$bd['name'].'-'.$config['title'];
$metakeywords =  $config['keywords'];
$metadescription = $config['description'];
if($aljbd_seo['notice_view']['seotitle']){
    $seodata = array('bbname' => $_G['setting']['bbname'],'bdname'=>$bd['name'],'message'=>mb_substr(strip_tags(preg_replace('/\<img.*?\>/is', '', $n['intro'])),0,80,$_G['charset']),'subject'=>$n['subject']);
    list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljbd_seo['notice_view']);
}

include template('aljbd:noticeview');
?>