<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$currpage=intval($_GET['page'])?intval($_GET['page']):1;
$perpage=1;

$num=C::t('#aljbd#aljbd_winfo')->count_by_bid($bid);
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start=($currpage-1)*$perpage;
$winfolist=C::t('#aljbd#aljbd_winfo')->fetch_all_by_bid($bid,$start,$perpage);
$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=winfolist&bid='.$bid, 0, 11, false, false);
include template('aljbd:winfolist');
?>