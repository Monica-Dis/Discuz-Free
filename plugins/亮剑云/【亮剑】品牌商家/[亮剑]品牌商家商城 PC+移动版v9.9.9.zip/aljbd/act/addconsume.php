<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($bd['vipid']) {
    $vipdata = DB::fetch_first('select * from %t where id=%d', array('aljbd_vip', $bd['vipid']));
}

if(submitcheck('formhash')){
    if($_GET['coupon_type'] < 7){
        $yes_coupon_type = 1;
    }
    if($yes_coupon_type) {
        if(empty($bid)){
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('".lang('plugin/aljbd','s51')."','');</script>";
                exit;
            }else{
                showerror(lang('plugin/aljbd','s51'));
            }
        }
    }
    if($settings['is_attes']['value'] && $yes_coupon_type){
        $sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
        if(!$sign){
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('&#24215;&#38138;&#24517;&#39035;&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#20248;&#24800;&#21048;','');</script>";
                exit;
            }else{
                showerror('&#24215;&#38138;&#24517;&#39035;&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#20248;&#24800;&#21048;');
            }
        }
    }
    if((!$_GET['logo'] && !$_GET['pic']) || (!$_FILES['logo']['tmp_name'] && $_GET['compress'])){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','logo')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','logo'));
        }

    }
    if($settings['is_form']['value'] && $_GET['act'] == 'addconsume'){
        if(DB::result_first('select * from %t where subject = %s and bid=%d',array('aljbd_consume',$_GET['name'],$bid))){
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('&#20248;&#24800;&#21048;&#24050;&#23384;&#22312;','');</script>";
                exit;
            }else{
                showerror('&#20248;&#24800;&#21048;&#24050;&#23384;&#22312;');
            }
        }
        if(!valid_token($_GET['aljbd_consume_token'],getcookie('aljbd_consume_token'),'aljbd_consume_token')){
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#27491;&#22312;&#21069;&#24448;&#20248;&#24800;&#21048;&#31649;&#29702;',function(){parent.location.href='plugin.php?id=aljbd&act=consumelist';});</script>";
                exit;
            }else{
                showerror('&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#35831;&#21047;&#26032;&#21518;&#37325;&#26032;&#21457;&#24067;&#25110;<a href="plugin.php?id=aljbd&act=consumelist">&#36820;&#22238;&#20248;&#24800;&#21048;&#31649;&#29702;&#26597;&#30475;&#20248;&#24800;&#21048;</a>');
            }
        }
    }
    if($_GET['compress'] == '1'){
        if($_FILES['logo']['tmp_name']) {
            $picname = $_FILES['logo']['name'];
            $picsize = $_FILES['logo']['size'];

            if ($picname != "") {
                $type = strtolower(strrchr($picname, '.'));
                if ($type != ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
                    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                        echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
                        exit;
                    }else{
                        showerror(lang('plugin/aljbd','s19'));
                    }
                }
                if (($picsize/1024)>$config['img_size']) {
                    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                        echo "<script>parent.tips('".lang('plugin/aljbd','img1').$config['img_size'].'KB'."','');</script>";
                        exit;
                    }else{
                        showerror(lang('plugin/aljbd','img1').$config['img_size'].'KB');
                    }
                }
                $rand = rand(100, 999);
                $pics = date("YmdHis") . $rand . $type;
                $img_dir = $image_path."consume/".date('Ymd',TIMESTAMP).'/';
                if (!is_dir($img_dir)) {
                    mkdir($img_dir);
                }
                $logo = $img_dir.$pics;
                if(@copy($_FILES['logo']['tmp_name'], $logo)||@move_uploaded_file($_FILES['logo']['tmp_name'], $logo)){
                    if($_G['cache']['plugin']['aljbd']['iswatermark']){
                        $image->Watermark(DISCUZ_ROOT.'./'.$logo,'', 'forum','');
                    }
                    @unlink($_FILES['logo']['tmp_name']);
                }
            }
        }
    }else{
        if ($_GET['pic']) {
            foreach ($_GET['pic'] as $tmp_key => $tmp_value) {
                if (strpos($tmp_value,$oss_domain) !== false) {
                    $logo = $tmp_value;
                }else if (is_file($tmp_value)) {
                    $logo = $tmp_value;
                } else {
                    unlink($c['pic']);
                    T::delete_oss($c['pic']);
                    $logo = T::saveimg($tmp_value,$image_path.'consume/');

                }
            }
        }else if($_GET['logo']){
            $logo = T::saveimg($_GET['logo'],$image_path.'consume/');
        }
    }

    $insertarray=array(
        'subject'=>$_GET['name'],
        'bid'=>$bid,
        'jieshao'=>$_GET['jieshao'],
        'xianzhi'=>$_GET['xianzhi'],
        'end'=>strtotime($_GET['end'])-1*3600,
        'mianze'=>$_GET['mianze'],
        'type'=>$_GET['type'],
        'subtype'=>$_GET['subtype'],
        'region'=>$bd['region'],
        'region1'=>$bd['region1'],
        'subregion'=>$bd['subregion'],
    );
    if($_G['cache']['plugin']['aljgwc']['aljbd']){
        if($_G['cache']['plugin']['aljsyh']['is_aljsyh']) {
            require_once 'source/plugin/aljsyh/include/addconsume.php';
        }else {
            $insertarray['full'] = $_GET['full'];
            $insertarray['reduction'] = $_GET['reduction'];
        }
    }
    if($_GET['act'] == 'addconsume'){
        if($yes_coupon_type) {
            $insertarray['uid'] = $bd['uid'];
            $insertarray['username'] = $bd['username'];
        }else{
            $insertarray['uid'] = $_G['uid'];
            $insertarray['username'] = $_G['username'];
        }
        
        $insertarray['dateline'] = TIMESTAMP;
        $insertarray['start'] = TIMESTAMP;
        $insertarray['pic'] = $logo;
        if($vipdata['is_consume'] >0 && file_exists("source/plugin/aljht/include/aljbd/addconsume_send.php") && !in_array($_G['groupid'],$admingroups)){
            require_once 'source/plugin/aljht/include/aljbd/addconsume_send.php';
        }
        $insertid=C::t('#aljbd#aljbd_consume')->insert($insertarray,true);
        $sh_tips = $sh_tips ? $sh_tips : lang('plugin/aljbd','s53');
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".$sh_tips."',function(){parent.location.href='plugin.php?id=aljbd&act=consumelist&bid=".$bid."';});</script>";
            exit;
        }else{
            showmsg($sh_tips);
        }
    }else{
        $insertarray['pic']=$logo;
        C::t('#aljbd#aljbd_consume')->update($_GET['cid'],$insertarray);
        savecache('aljbd_rec_consume', '');//�Ƽ��Ż�ȯ ��ջ���
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            if($_GET['i'] == 1 && $admin_status){
                $to_url = 'plugin.php?id=aljbd&act=consumelist&i=1';
            }else{
                $to_url = 'plugin.php?id=aljbd&act=consumelist&bid='.$bid;
            }
            echo "<script>parent.tips('".lang('plugin/aljbd','s54')."',function(){parent.location.href='".$to_url."';});</script>";
            exit;
        }else{
            showmsg(lang('plugin/aljbd','s54'));
        }
    }
}else{
    if(empty($_G['uid'])){
        dheader("location:".$login_callback);
    }

    if($admin_status){
        $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','','');//����Ա
    }else{
        if($staff && $bid){//���̵�ԱȨ��
            $bdlist = DB::fetch_all('select * from %t where id = %d',array('aljbd',$staff['store_id']));
        }else{
            $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','',$_G['uid']);//����
        }
    }

    if($_GET['act'] == 'addcosume'){
        if($bd['vipid']){
            $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$bd['vipid']));
            $brandnum['consume'] = $vipdata['consume'];
            $bnum = C::t('#aljbd#aljbd_consume')->count_by_uid_bid($_G['uid'],'','','','',0);
            if ($brandnum['consume']) {
                if ($brandnum['consume'] == $checksign) {
                    $info = array('desc' => lang('plugin/aljbd','noauth').$consumetips);
                    $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                    aljbdShowTips($info);
                }
                if ($bnum >= $brandnum['consume']) {
                    $info = array('desc' => lang('plugin/aljbd','groups_1').$brandnum['consume'].lang('plugin/aljbd','groups_4').$consumetips);
                    $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                    aljbdShowTips($info);
                }
            }
        }
        if($yhzqx) {
            $brandnum=C::t('#aljbd#aljbd_usergroup')->fetch($_G['groupid']);
            $bnum = C::t('#aljbd#aljbd_consume')->count_by_uid_bid($_G['uid'],'','','','',0);
            if($brandnum['consume']&&file_exists('source/plugin/aljbd/com/yhzqx.php')){
                if($brandnum['consume'] == $checksign){
                    $info = array('desc' => lang('plugin/aljbd','noauth').$consumetips);
                    $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                    aljbdShowTips($info);
                }
                if($bnum >= $brandnum['consume']){
                    $info = array('desc' => lang('plugin/aljbd','groups_1').$brandnum['consume'].lang('plugin/aljbd','groups_4').$consumetips);
                    $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                    aljbdShowTips($info);
                }
            }
        }
        if($settings['is_attes']['value'] && $bid){
            $sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
            if(!$sign){
                $info = array('desc' => lang('plugin/aljbd','aljbd_php_17'));
                if($_G['mobile']){
                    $toUrl = 'plugin.php?id=aljbd&act=attestation&bid='.$bid;
                }else{
                    $toUrl = 'plugin.php?id=aljht&act=admin&op=attestation&do=addattestation&bid='.$bid.'&mod=my';
                }
                $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_16'), 'url' => $toUrl);
                $info['btn_default'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                aljbdShowTips($info);
            }
        }
    }
    $navtitle = '&#28155;&#21152;&#20248;&#24800;&#21048;-'.$config['title'];
    $title = '&#28155;&#21152;&#20248;&#24800;&#21048;';
    $metakeywords =  $bd['other']?$bd['other']:$config['keywords'];
    $metadescription = $config['description'];
    if($newtemplate){
        $typelist=C::t('#aljbd#aljbd_type_consume')->range();
        $json_typelist = C::t('#aljbd#aljbd_type_consume')->fetch_all_json();
        $typejson = json_encode($json_typelist);
        if($n['type']){
            $default_type = $typelist[$n['type']]['subject'].' '. ($typelist[$n['subtype']]['subject'] ? $typelist[$n['subtype']]['subject'] : '--');
            $type = $n['type'];
            $subtype = $n['subtype'];
        }else{
            $default_type = diconv($json_typelist[0]['name'].' '. $json_typelist[0]['sub'][0]['name'], 'utf-8', CHARSET);
            $type = $json_typelist[0]['code'];
            $subtype = $json_typelist[0]['sub'][0]['code'];
        }
        include template($common_template_pluginid.':new/post/addconsume');
    }else {
        $typelist=C::t('#aljbd#aljbd_type_consume')->fetch_all_by_upid(0);
        include template('aljbd:addconsume');
    }
}
//From: Dism��taobao��com
?>