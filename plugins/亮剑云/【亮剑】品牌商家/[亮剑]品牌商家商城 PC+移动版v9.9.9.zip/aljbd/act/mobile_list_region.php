<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_GET['region']){
    $rlist=C::t('#aljbd#aljbd_region')->fetch_all_by_upid('','',$_GET['region']);
}
$geturl = array(
    'id' => $pluginid,
    'act' => 'dianpu',
    'type' => $_GET['type'],
    'subtype' => $_GET['subtype'],
    'subtype3' => $_GET['subtype3'],
    'region' => $_GET['region'],
    'subregion' => $_GET['subregion'],
    'region1' => $_GET['region1'],
    'order' => $_GET['order'],
    'kw' => $_GET['kw'],
    'view' => $_GET['view'],
    'lng' => $_GET['lng'],
    'lat' => $_GET['lat'],
    'commodity_type' => $_GET['commodity_type'],
);
if($_GET['brand'] == 'goods'){
    $geturl['act'] = 'goods';
}
if($_GET['sub']){
    $geturl['region'] = $_GET['subregion'];
    $geturl['subregion'] = $_GET['region'];
    include template($pluginid.':mobile_list_subregion');
}else{
    $geturl['region'] = $_GET['region'];
    $geturl['subregion'] = $_GET['subregion'];
    include template($pluginid.':mobile_list_region');
}
//From: Dism��taobao��com
?>