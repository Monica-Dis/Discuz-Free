<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$order = C::t('#aljbd#aljbd_order') -> fetch($_GET['orderid']);
if($order['uid'] == $_G['uid']){
    if(DB::query("update %t set status=4 where orderid = %s and status = 3",array('aljbd_order',$_GET['orderid']))){
        $goods = C::t('#aljbd#aljbd_goods')->fetch($order['sid']);
        if($goods['uid']>0){
            updatemembercount($goods['uid'], array($config['extcredit'] => $order['price']));
        }
        //updatemembercount($_G['uid'], array($config['extcredit'] => '-' . $num * $good['price1']));
    }
}
showmessage('&#30830;&#35748;&#25910;&#36135;&#25104;&#21151;','plugin.php?id=aljbd&act=orderlist');
?>