<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('formhash')){
    if(empty($_GET['aid'])){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd', 'album_2')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','album_2'));
        }
    }
    if($_G['cache']['plugin']['aljhtx']) {
        if ($_GET['pic']) {
            $img_dir = $image_path . "album/";
            $pics = array();
            foreach ($_GET['pic'] as $tmp_key => $tmp_value) {
                if(strpos($tmp_value,$oss_domain) !== false){
                    $pics[] = $tmp_value;
                }else if (is_file($tmp_value)) {
                    $pics[] = $tmp_value;
                } else {
                    $pics[] = T::saveimg($tmp_value,$img_dir);
                }
            }
        }else{
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('".lang('plugin/aljbd', 'album_3')."','');</script>";
                exit;
            }else{
                showerror(lang('plugin/aljbd', 'album_3'));
            }
        }

        if(is_array($pics) && $pics){
            foreach ($pics as $pk => $pv){
                if(!$apic['subjectimage'] && $pk == 0){
                    DB::query("UPDATE ".DB::table('aljbd_album')." SET subjectimage='".$pv."' WHERE id='".$_GET['aid']."'", 'UNBUFFERED');
                }
                DB::query("UPDATE ".DB::table('aljbd_album')." SET picnum=picnum+1 WHERE id='".$_GET['aid']."'", 'UNBUFFERED');
                DB::query("UPDATE ".DB::table('aljbd_album')." SET lastpost=".$_G['timestamp']." WHERE id='".$_GET['aid']."'", 'UNBUFFERED');
                C::t('#aljbd#aljbd_album_attachments')->insert(array(
                    'bid'=>$bid,
                    'uid'=>$bd['uid'],
                    'aid'=>$_GET['aid'],
                    'pic'=>$pv,
                    'dateline'=>TIMESTAMP,
                    'displayorder'=>'100',
                    'alt'=>$_GET['alt'],
                ));
            }
        }
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','s53')."',function(){parent.location.href='plugin.php?id=aljbd&act=albumall&aid=".$_GET['aid']."&bid=".$_GET['bid']."';});</script>";
            exit;
        }else{
            showmsg(lang('plugin/aljbd','s53'));
        }
    }else {
        if ($_GET['compress'] == '1') {
            if (!$_FILES['pic']['tmp_name']) {
                showerror(lang('plugin/aljbd', 'album_3'));
            }
            if ($_FILES['pic']['tmp_name']) {
                $picname = $_FILES['pic']['name'];
                $picsize = $_FILES['pic']['size'];

                if ($picname != "") {
                    $type = strtolower(strrchr($picname, '.'));
                    if ($type != ".gif" && $type != ".jpg" && $type != ".png" && $type != ".jpeg") {
                        showerror(lang('plugin/aljbd', 's19'));
                    }
                    if (($picsize / 1024) > $config['img_size']) {
                        showerror(lang('plugin/aljbd', 'img1') . $config['img_size'] . 'KB');
                    }
                    if (($picsize / 1024) > $config['img_size']) {
                        showerror(lang('plugin/aljbd', 'img1') . $config['img_size'] . 'KB');
                    }
                    $rand = rand(100, 999);
                    $pics = date("YmdHis") . $rand . $type;

                    $img_dir = $image_path . "album/" . date('Ymd', TIMESTAMP) . '/';
                    if (!is_dir($img_dir)) {
                        mkdir($img_dir);
                    }
                    $pic1 = $img_dir . $pics;
                    if (@copy($_FILES['pic']['tmp_name'], $pic1) || @move_uploaded_file($_FILES['pic']['tmp_name'], $pic1)) {
                        if ($_G['cache']['plugin']['aljbd']['iswatermark']) {
                            $image->Watermark(DISCUZ_ROOT . './' . $pic1, '', 'forum', '');
                        }
                        $imageinfo = getimagesize($pic1);
                        $w60 = $imageinfo[0] < 72 ? $imageinfo[0] : 72;
                        $h60 = $imageinfo[1] < 72 ? $imageinfo[1] : 72;
                        $w205 = $imageinfo[0] < 100 ? $imageinfo[0] : 100;
                        $h205 = $imageinfo[1] < 100 ? $imageinfo[1] : 100;
                        $w470 = $imageinfo[0] < 550 ? $imageinfo[0] : 550;
                        $h470 = $imageinfo[1] < 550 ? $imageinfo[1] : 550;
                        img2thumb($pic1, $pic1 . '.72x72.jpg', $w60, $h60);
                        img2thumb($pic1, $pic1 . '.100x100.jpg', $w205, $h205);
                        img2thumb($pic1, $pic1 . '.550x550.jpg', $w470, $h470);
                        @unlink($_FILES['pic']['tmp_name']);
                    }
                }
            }
        } else {
            if (!$_GET['pic']) {
                showerror(lang('plugin/aljbd', 'album_3'));
            }

            if ($_GET['pic']) {
                $rand = rand(100, 999);
                $pics = date("YmdHis") . $rand . '.jpg';
                $img_dir = $image_path . "album/" . date('Ymd', TIMESTAMP) . '/';
                if (!is_dir($img_dir)) {
                    mkdir($img_dir);
                }
                $$pic = $img_dir . $pics;

                $logo = file_put_contents($$pic, file_get_contents($_GET['pic']));

                if ($logo) {
                    $imageinfo = getimagesize($$pic);
                    if ($_G['cache']['plugin']['aljbd']['iswatermark']) {
                        $image->Watermark(DISCUZ_ROOT . './' . $pic1, '', 'forum', '');
                    }
                    $w60 = $imageinfo[0] < 72 ? $imageinfo[0] : 72;
                    $h60 = $imageinfo[1] < 72 ? $imageinfo[1] : 72;
                    $w205 = $imageinfo[0] < 100 ? $imageinfo[0] : 100;
                    $h205 = $imageinfo[1] < 100 ? $imageinfo[1] : 100;
                    $w470 = $imageinfo[0] < 550 ? $imageinfo[0] : 550;
                    $h470 = $imageinfo[1] < 550 ? $imageinfo[1] : 550;
                    img2thumb($$pic, $$pic . '.72x72.jpg', $w60, $h60);
                    img2thumb($$pic, $$pic . '.100x100.jpg', $w205, $h205);
                    img2thumb($$pic, $$pic . '.550x550.jpg', $w470, $h470);
                    @unlink($_FILES['pic']['tmp_name']);
                }
            }
            $pic1 = $$pic;
        }

        if(!$apic['subjectimage']){
            DB::query("UPDATE ".DB::table('aljbd_album')." SET subjectimage='".$pic1."' WHERE id='".$_GET['aid']."'", 'UNBUFFERED');
        }
        DB::query("UPDATE ".DB::table('aljbd_album')." SET picnum=picnum+1 WHERE id='".$_GET['aid']."'", 'UNBUFFERED');
        DB::query("UPDATE ".DB::table('aljbd_album')." SET lastpost=".$_G['timestamp']." WHERE id='".$_GET['aid']."'", 'UNBUFFERED');
        C::t('#aljbd#aljbd_album_attachments')->insert(array(
            'bid'=>$bid,
            'uid'=>$_G['uid'],
            'aid'=>$_GET['aid'],
            'pic'=>$pic1,
            'dateline'=>TIMESTAMP,
            'displayorder'=>'100',
            'alt'=>$_GET['alt'],
        ));
        showmsg(lang('plugin/aljbd','s53'));
    }


}else{

    $alist=C::t('#aljbd#aljbd_album')->range();
    $alist = dhtmlspecialchars($alist);
    $num=C::t('#aljbd#aljbd_album_attachments')->count_by_uid_bid($bd['uid'],$_GET['aid'],0);

    if($num>=$config['albumnum']&&$config['albumnum']){
        $info = array('desc' => lang('plugin/aljbd','album_4').$config['albumnum'].lang('plugin/aljbd','album_5'));
        $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
        aljbdShowTips($info);
    }
    $navtitle = '&#28155;&#21152;&#22270;&#29255;';
    $metakeywords = $bd['other'] ? $bd['other'] : $config['keywords'];
    $metadescription = $config['description'];
    if($newtemplate){
        include template($common_template_pluginid.':new/post/addalbumimg');
    }else {
        include template('aljbd:addalbumimg');
    }
}
//From: Dism��taobao��com
?>