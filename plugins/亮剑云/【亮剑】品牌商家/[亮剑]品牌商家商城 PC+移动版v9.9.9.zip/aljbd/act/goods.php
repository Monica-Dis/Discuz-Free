<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_GET['ac']=='fl'){
    $navtitle = lang('plugin/aljbd','sj_8').$config['title'];
    $metakeywords =  $config['keywords'];
    $metadescription = $config['description'];
    include template('aljbd:fenlei_goods');
}else if($_GET['ac']=='order'){
    $navtitle = lang('plugin/aljbd','sj_9').$config['title'];
    $metakeywords =  $config['keywords'];
    $metadescription = $config['description'];
    include template('aljbd:order_goods');
}else{
    $navtitle = lang('plugin/aljbd','s57').$config['title'];
    $metakeywords =  $config['keywords'];
    $metadescription = $config['description'];
    $config=$_G['cache']['plugin']['aljbd'];
    
    $kw = $_GET['kw'];
    if(($_G['charset']=='gbk'&&!defined('IN_MOBILE')&&$config['is_daohang']&&!$_GET[page]) && $_G['cookie']['mobile_search']!=1){
        
        $_GET['kw']=diconv($_GET['kw'],'utf-8','gbk');
    }else{
        dsetcookie('mobile_search', 0,-1);
    }
    if($_G['cache']['plugin']['aljbd']['iscensor']){
        
        
        $censor = & discuz_censor::instance();
        $censor->check($_GET['kw']);
        if($censor->modbanned() || $censor->modmoderated()) {
            $tips_1 = '\u641c\u7d22\u8bcd\u5305\u542b\u654f\u611f\u8bcd';
            echo "<script>alert('".$tips_1."');window.history.go(-1);</script>";
            exit;
        }
    }
    $tlist=C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid(0,'','','');
    $tlist = dhtmlspecialchars($tlist);
    
    $typelist=C::t('#aljbd#aljbd_type_goods')->range();
    $titlelist=C::t('#aljbd#aljbd_region')->range();
    $typelist = dhtmlspecialchars($typelist);
    if(!$_G['mobile'] || !$_G['setting']['mobile']['allowmobile']){
        $array = array(
            'btypeid'=>intval($_GET['btypeid']),
            'bsubtypeid'=>intval($_GET['bsubtypeid']),
            'region1'=>intval($_GET['region1']),
        );
        $sql = ' AND store_id=0';
        if(!$card_user && !$admin_status){  
            $sql .= ' AND is_aljtcc=0';
        }
        if($_G['cache']['plugin']['aljsqtg']['hide_aljsqtg_goods']){
            $sql .= ' AND commodity_type!=8';
        }
        $num=C::t('#aljbd#aljbd_goods')->count_by_status_new('','',$_GET['type'],$_GET['subtype'],$_GET['region'],$_GET['subregion'],$_GET['kw'],$_GET['subtype3'],0,$_GET['commodity_type'],$array,$sql);
        $currpage=intval($_GET['page'])?intval($_GET['page']):1;
        
        $perpage=$config['page'];
        if(@ceil($num/$perpage) < $currpage && $no_max_page){
            $currpage=1;
        }
        $start=($currpage-1)*$perpage;
        $typecount=C::t('#aljbd#aljbd_goods')->count_by_type();
        foreach($typecount as $tc){
            $tcs[$tc['type']]=$tc['num'];
        }
        if($_GET['type']){
            $subtypecount=C::t('#aljbd#aljbd_goods')->count_by_type($_GET['type']);
        }
        //$aljbd=C::t('#aljbd#aljbd')->range();
        //$aljbd = dhtmlspecialchars($aljbd);

        $recommendlist=C::t('#aljbd#aljbd')->fetch_all_by_recommend(1,0,10);
        $recommendlist = dhtmlspecialchars($recommendlist);
        $recommendlist_goods=C::t('#aljbd#aljbd_goods')->fetch_all_by_recommend_new(1,0,10,$sql);
        $recommendlist_goods = dhtmlspecialchars($recommendlist_goods);
        $notice=C::t('#aljbd#aljbd_notice')->fetch_all_by_uid_bid('','',0,9,'','','','',0);
        $notice = dhtmlspecialchars($notice);
        $clist=dhtmlspecialchars($clist);


        if($config['isrewrite']&&!$_GET['page']&&(!$_G['mobile'] || !$_G['setting']['mobile']['allowmobile'])){
            if($_GET['order']=='1'){
                $_GET['order']='view';
            }else if($_GET['order']=='2'){
                $_GET['order']='price1';
            }else{
                $_GET['order']='';
            }
            if($_GET['view']=='3'){
                $_GET['view']="pic";
            }else if($_GET['view']=='4'){
                $_GET['view']="list";
            }else{
                $_GET['view']='';
            }
        }
        if($_GET['order'] == 'comment'){
            $_GET['order']='';
        }else{
            $orderby = array('view','dateline','price1','buyamount');
            if(!in_array($_GET['order'],$orderby)){
                $_GET['order']='';
            }
        }
        $bdlist=C::t('#aljbd#aljbd_goods')->fetch_all_by_status_new(
            ''
            ,$start
            ,$perpage
            ,''
            ,$_GET['type']
            ,$_GET['subtype']
            ,$_GET['region']
            ,$_GET['subregion']
            ,$_GET['order']
            ,$_GET['kw']
            ,$_GET['subtype3']
            ,0
            ,$_GET['commodity_type']
            ,$array
            ,$sql
        );
        require_once libfile('function/search');
        foreach($bdlist as $k=>$v){
            $bdlist[$k]['c']=C::t('#aljbd#aljbd_comment')->fetch_by_bid($v['id']);
            $bdlist[$k]['q']=str_replace('{qq}',$v['qq'],$config['qq']);
            $bdlist[$k]['price1']=T::skuminprice($v['attr_sku'],$v['commodity_type'])>0 ? T::skuminprice($v['attr_sku'],$v['commodity_type']) : floatval($v['price1']);
            $bdlist[$k]['collage_price']=T::skuminprice($v['attr_sku'],$v['commodity_type'])>0 ? T::skuminprice($v['attr_sku'],$v['commodity_type']) : floatval($v['collage_price']);
            $bdlist[$k]['price2']=floatval($v['price2']);
            if($v['selling_point']){
                $selling_point = str_replace('��',',',$v['selling_point']);
                $bdlist[$k]['selling_point'] = explode(',',$selling_point);
            }
            foreach($pics as $p_v){
                $bdlist[$k][$p_v] = $v[$p_v].$oss_img_url;
            }
            if($settings['is_card_price']['value']==1 && $v['card_price'] > 0 && $card_user){
                
                if($v['commodity_type'] == 2){
                    $bdlist[$k]['collage_price'] = floatval($v['card_price']).'<i class="c_p_t">'.$card_price_label.'</i>';
                }else{
                    $bdlist[$k]['price1'] = floatval($v['card_price']).'<i class="c_p_t">'.$card_price_label.'</i>';
                }
            }
            $bdlist[$k]['name'] = dhtmlspecialchars($v['name']);
            $bdlist[$k]['search_name'] = bat_highlight($v['name'],$_GET['kw']);
            $bdlist[$k]['selling_point'] = dhtmlspecialchars($v['selling_point']);
        }

    }

    //$bdlist=dhtmlspecialchars($bdlist);
    $geturl = array(
        'id' => $pluginid,
        'act' => 'goods',
        'type' => $_GET['type'],
        'subtype' => $_GET['subtype'],
        'subtype3' => $_GET['subtype3'],
        'region' => $_GET['region'],
        'subregion' => $_GET['subregion'],
        'region1' => $_GET['region1'],
        'order' => $_GET['order'],
        'view' => $_GET['view'],
        'lng' => $_GET['lng'],
        'lat' => $_GET['lat'],
        'commodity_type' => $_GET['commodity_type'],
        'v' => $_GET['v'],
        'kw' => $_GET['kw']
    );
    $pagingurl = getaljurl($geturl,'');
    $paging = helper_page :: multi($num, $perpage, $currpage, $pagingurl, 0, 11, false, false);
    if($aljbd_seo['good_list']['seotitle']){
        if($_GET['type']){
            $cat=$typelist[$_GET['type']]['subject'];
            $cat1=$cat;
        }
        if($_GET['subtype']){
            $cat=$typelist[$_GET['subtype']]['subject'];
            $cat2=$cat;
        }
        if($_GET['subtype3']){
            $cat=$typelist[$_GET['subtype3']]['subject'];
            $cat3=$cat;
        }
        $seodata = array('bbname' => $_G['setting']['bbname'],'cat'=>$cat1,'cat2'=>$cat2,'cat3'=>$cat3);
        list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljbd_seo['good_list']);
    }
    include template('aljbd:list_goods');
}
//From: Dism��taobao��com
?>