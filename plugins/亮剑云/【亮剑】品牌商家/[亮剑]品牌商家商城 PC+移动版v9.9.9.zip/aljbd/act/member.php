<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
    //showmessage(lang('plugin/aljbd','s21'), $login_callback);
    dheader("location:".$login_callback);
    exit;
}
if(!$aljbd && !$admin_status){
    echo "<script>alert('".lang('plugin/aljbd','aljbd_7')."');location.href='plugin.php?id=aljbd&act=attend';</script>";
    exit;
}

if($_G['cache']['plugin']['aljbdx']['is_aljqb']){
    $aljbd_groups=C::t('#aljbd#aljbd_vip')->fetch_all_by_user();
}
if($_G['cache']['plugin']['aljsyh']['is_aljsyh']){
    $discount = DB::fetch_all('select a.id,b.full,b.reduction,b.coupon_type from %t a left join %t b on a.cid=b.id where (b.end>%s || b.end=0) and b.coupon_type=9 and a.status=%d and a.uid=%d order by b.reduction desc',array('aljsyh_consume_log','aljbd_consume', TIMESTAMP,1,$_G['uid']));
    foreach($discount as $dk => $kv){
        $discount[$dk]['full'] = floatval($kv['full']);
        $discount[$dk]['reduction'] = floatval($kv['reduction']);
    }
}
if(in_array($_G['groupid'],$admingroups) && $_GET['i'] == 1){
    $uid = 0;
    $sh_status = 0;
    $admin = 1;

}else{
    $uid = $_G['uid'];
    $sh_status = 1;
}
$num=C::t('#aljbd#aljbd')->count_by_status(1,$uid,'','','','',$_GET['search_m'],'','','','','','');
$currpage=intval($_GET['page'])?intval($_GET['page']):1;
$perpage=10;
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start=($currpage-1)*$perpage;
if($_GET['do'] == 'ajax'){

    $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status($_GET['status'],$start,$perpage,$uid,'','','','','id',$_GET['search_m'],'','','','','',0);

    foreach ($bdlist as $bk => $bv){
        if($bv['status'] == 1){
            if($bv['vipendtime']){
                if($bv['vipendtime'] > TIMESTAMP){
                    $bdlist[$bk]['vipendtimes'] = dgmdate($bv['vipendtime'],'Y-m-d H:i:s').lang('plugin/aljbd','member_php_1');
                }else{
                    $bdlist[$bk]['vipendtimes'] = lang('plugin/aljbd','member_php_2');
                }

            }else if($bv['vipid'] && $bv['vipendtime']==0){
                $bdlist[$bk]['vipendtimes'] = lang('plugin/aljbd','member_php_3');
            }
            if($bv['vipid']){
                $bdlist[$bk]['grouptitle'] = DB::result_first('select title from %t where id=%d',array('aljbd_vip',$bv['vipid']));
            }
        }else if($bv['status'] == 2){
            if($bv['vipid']){
                $bdlist[$bk]['grouptitle'] = DB::result_first('select title from %t where id=%d',array('aljbd_vip',$bv['vipid']));
                $bdlist[$bk]['vipendtimes'] = lang('plugin/aljbd','member_php_5');
            }

        }else{
            if($bv['vipid']){
                $bdlist[$bk]['grouptitle'] = DB::result_first('select title from %t where id=%d',array('aljbd_vip',$bv['vipid']));
                $bdlist[$bk]['vipendtimes'] = lang('plugin/aljbd','member_php_4');
            }

        }
        $sign=DB::result_first("select sign from ".DB::table('aljbd_attestation')." where sign=1 and bid=".$bv['id']);
        if($sign){
            $bdlist[$bk]['v'] = 1;
        }
        if($_G['cache']['plugin']['aljbzj']['is_aljbzj']){
            $bzj_info = DB::fetch_first('select * from %t where uid=%d and bid=%d ',array('aljbzj',$bv['uid'],$bv['id']));
            if($bzj_info['price']>0){
                $bdlist[$bk]['bond'] = 1;
            }
        }
        if($typelist[$bv['subtype3']]['subject']){
            $bdlist[$bk]['typename'] = $typelist[$bv['subtype3']]['subject'];
        }else if($typelist[$bv['subtype']]['subject']){
            $bdlist[$bk]['typename'] = $typelist[$bv['subtype']]['subject'];
        }else{
            $bdlist[$bk]['typename'] = $typelist[$bv['type']]['subject'];
        }
        if($bv['status'] == 0){
            $bdlist[$bk]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_1');
        }else if($bv['status'] == 3){
            $bdlist[$bk]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_2');
        }else if($bv['status'] == 4){
            $bdlist[$bk]['sh_status_text'] = '&#24050;&#20851;&#38381;';
        }else{
            $bdlist[$bk]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_3');
        }
        $u_name = getuserbyuid($bv['uid']);
        $bdlist[$bk]['username'] = $u_name['username'];
        unset($u_name);
        unset($sign);
        unset($bzj_info);
    }
    $bdlist = dhtmlspecialchars($bdlist);
    if($bdlist){
        echo json_encode(aljhtx::ajaxPostCharSet($bdlist));
    }else{
        echo '1';
    }
    exit;
}else{
    
    $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,$start,$perpage,$uid,'','','','','',$_GET['search_m'],'','','','','',0);

    if($num == 1 && $_G['mobile'] && $admin!=1 && ($_G['cache']['plugin']['aljbdx'] || $_G['cache']['plugin']['aljgwc'])){
        dheader("location: plugin.php?id=aljbd&act=member_view&bid=".$bdlist[0]['id']);
        exit;
    }
    $bdlist = dhtmlspecialchars($bdlist);
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=member&search_m='.$_GET['search_m'], 0, 11, false, false);
    $navtitle = '&#24215;&#38138;&#31649;&#29702;-'.$config['title'];
    $metakeywords =  $bd['other']?$bd['other']:$config['keywords'];
    $metadescription = $config['description'];
    if($newtemplate){
        if($_G['cache']['plugin']['aljbdx']['is_aljqb'] && file_exists('source/plugin/aljht/template/touch/aljbd/member/member.htm')){
            include template('aljht:aljbd/member/member');
        }else{
            include template($common_template_pluginid.':new/user/member');
        }
    }else{
        include template('aljbd:member');
    }
}
//From: Dism��taobao��com
?>