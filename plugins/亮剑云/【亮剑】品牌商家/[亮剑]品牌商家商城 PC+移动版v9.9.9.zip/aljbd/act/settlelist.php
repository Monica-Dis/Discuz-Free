<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$page = intval($_GET['page']);
$currpage = $page?$page:1;
$perpage = 10;
$start = ($currpage-1)*$perpage;

if($_G['cache']['plugin']['aljgwc'][$pluginid] && $_GET['cart'] != 'old'){
    require DISCUZ_ROOT.'./source/plugin/aljgwc/include/aljbd_settlelist.php';
}else{
    if($_G['cache']['plugin']['aljgwc']['aljbd_old_settle']){
        showmessage('&#26087;&#30340;&#32467;&#31639;&#24050;&#20851;&#38381;');
    }
    if(in_array($_G['groupid'],$admingroups)){
        $num = DB::result_first('select count(*) from %t',array('aljbd_settle'));
        if(@ceil($num/$perpage) < $currpage && $no_max_page){
            $currpage=1;
        }
        $start = ($currpage-1)*$perpage;
        $settlelist = DB::fetch_all('select * from %t order by applytime desc limit %d,%d',array('aljbd_settle',$start,$perpage));
    }else{
        $num = DB::result_first('select count(*) from %t where uid = %d',array('aljbd_settle',$_G['uid']));
        if(@ceil($num/$perpage) < $currpage && $no_max_page){
            $currpage=1;
        }
        $start = ($currpage-1)*$perpage;
        $settlelist = DB::fetch_all('select * from %t where uid = %d order by applytime desc limit %d,%d',array('aljbd_settle',$_G['uid'],$start,$perpage));
    }
}
if($_GET['cart']){
    $url='&cart='.$_GET['cart'];
}
$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=settlelist'.$url, 0, 11, false, false);
$navtitle = '&#32467;&#31639;&#31649;&#29702;-'.$config['title'];
$metakeywords =  $bd['other']?$bd['other']:$config['keywords'];
$metadescription = $config['description'];
include template('aljbd:settlelist');
?>