<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) || $_GET['dzAdmin'] == 1){
    if(submitcheck('formhash')){
        C::t('#aljbd#aljbd_goods')->update($gid,array('rubbish'=>'1'));//�������վ
        //����
        if($_G['cache']['plugin']['aljbdx']){
            DB::update('aljbd_comment_goods',array('rubbish'=>0), array('gid'=>$gid));
        }
        echo 1;
        exit;
    }else{
        $url='plugin.php?id=aljbd&act=deletegoods&gid='.$gid;
        include template('aljbd:state');
    }
}else{
    if($_GET['formhash']!=FORMHASH()){
        exit('Access Denied!');
    }
    if($gid){
        for ($i = 1; $i <= 5; $i++) {
            $pic = 'pic' . $i;
            unlink($goods[$pic]);
            unlink($goods[$pic].'.60x60.jpg');
            unlink($goods[$pic].'.205x205.jpg');
            unlink($goods[$pic].'.470x470.jpg');
        }
        C::t('#aljbd#aljbd_goods')->delete($gid);
    }
    showmessage(lang('plugin/aljbd','s50'),'plugin.php?id=aljbd&act=goodslist');
}
//From: Dism��taobao��com
?>