<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if(strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false && $_GET['from'] == 'app' && $_G['cache']['plugin']['aljapp']['url']){
    
    $miniurl = $_G['cache']['plugin']['aljapp']['url'];
    
    dheader("location: ".$miniurl);
    exit;
}
if(file_exists("source/plugin/aljdiy/aljdiy.inc.php") && $_G['mobile']) {
    $page_diy = DB::fetch_first('select * from %t where push_to_page = %s',array('aljdiy_page','aljbd_index'));
    if($page_diy){
        $_GET['c'] = 'index';
        $_GET['a'] = 'index';
        $_GET['ajax'] = 'yes';
        $_GET['page_id'] = $page_diy['id'];
       
        require_once DISCUZ_ROOT . './source/plugin/aljdiy/aljdiy.inc.php';
        exit;
    }
}
//����
$gg = explode ("\n", str_replace ("\r", "", $config ['gg']));
foreach($gg as $key=>$value){
    $arr=explode('|',$value);
    $gg_types[$arr[0]]=$arr[1];
}
$gg_types=dhtmlspecialchars($gg_types);
if($_G['cache']['plugin']['aljhelp']['is_help']){
    //���������Ƽ�������
    loadcache('aljhelp', 1);
    if(!$_G['cache']['aljhelp']) {
        $helpList = DB::fetch_all('SELECT * FROM %t where is_gg=1 and rubbish=0 ORDER BY displayorder desc,id desc ',array('aljhelp'));
        savecache('aljhelp', $helpList);
    }else{
        $helpList = $_G['cache']['aljhelp'];
    }
    
    foreach ($helpList as  $helpvalue){
        $help_gg[$helpvalue['subject']] = 'plugin.php?id=aljhelp&c=help&a=view&hid='.$helpvalue['id'];
    }
    if($config ['gg'] && $helpList){
        $gg_types = array_merge($help_gg, $gg_types);
    }else if($helpList){
        $gg_types = $help_gg;
    }

}

$navtitle = $config['title'];
$metakeywords =  $config['keywords'];
$metadescription = $config['description'];
$sharedata[logo] = $config['share_logo'];
if($aljbd_seo['index']['seotitle']){
    $seodata = array('bbname' => $_G['setting']['bbname']);
    list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljbd_seo['index']);
}
if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
    $config=$_G['cache']['plugin']['aljbd'];
    $timelistnum = $settings['timelistnum']['value']?$settings['timelistnum']['value']:6;
    $viewslistnum = $settings['viewslistnum']['value']?$settings['viewslistnum']['value']:6;
    $recommendlistnum = $settings['recommendlistnum']['value']?$settings['recommendlistnum']['value']:6;
    if($settings['is_mobile_index_resdp']['value']){
        loadcache('aljbd_rec_brand', 1);
        //�Ƽ��̼�
        if(!$_G['cache']['aljbd_rec_brand']) {
            $viewslist=C::t('#aljbd#aljbd')->fetch_all_by_view(1,0,$viewslistnum,'view');
            $timelist=C::t('#aljbd#aljbd')->fetch_all_by_view(1,0,$timelistnum,'dateline');
            $recommendlist=C::t('#aljbd#aljbd')->fetch_all_by_recommend(1,0,$recommendlistnum);
            savecache('aljbd_rec_brand', array('viewslist'=>$viewslist,'timelist'=>$timelist,'recommendlist'=>$recommendlist));
        }else{
            $viewslist = $_G['cache']['aljbd_rec_brand']['viewslist'];
            $timelist = $_G['cache']['aljbd_rec_brand']['timelist'];
            $recommendlist = $_G['cache']['aljbd_rec_brand']['recommendlist'];
        }
        $viewslist = dhtmlspecialchars($viewslist);
        $timelist = dhtmlspecialchars($timelist);
        $recommendlist = dhtmlspecialchars($recommendlist);
    }else{
        loadcache('aljbd_rec_brand', 1);
        if(!$_G['cache']['aljbd_rec_brand']) {
            $recommendlist=C::t('#aljbd#aljbd')->fetch_all_by_recommend(1,0,$recommendlistnum);
            savecache('aljbd_rec_brand', array('recommendlist'=>$recommendlist));
        }else{
            $recommendlist = $_G['cache']['aljbd_rec_brand']['recommendlist'];
        }
        $recommendlist = dhtmlspecialchars($recommendlist);
    }
    
    //�ֻ�����ҳ��������ͼ��
    $mobile_index_img_s = explode ("\n", str_replace ("\r", "", $settings['mobile_index_img_s']['value']));
    foreach($mobile_index_img_s as $key=>$value){
        $arr=explode('|',$value);
        $index_img_s_types[]=$arr;
    }
    //�ֻ���ҳת��
    $sjlz = explode ("\n", str_replace ("\r", "", $config ['sj_img_1']));
    foreach($sjlz as $key=>$value){
        $arr=explode('|',$value);
        $lz_types[$arr[0]]=$arr;
    }
    //�ֻ���ҳͼ�굼��
    $sj_index_dh = explode ("\n", str_replace ("\r", "", $config ['sj_index_dh']));
    foreach($sj_index_dh as $key=>$value){
        $arr=explode('|',$value);
        $sj_index_dh_types[]=$arr;
    }
    //�ֻ�������
    $mobile_index_tad = explode ("\n", str_replace ("\r", "", $settings['mobile_index_tad']['value']));
    foreach($mobile_index_tad as $key=>$value){
        $arr=explode('|',$value);
        $mobile_index_tad_arr[]=$arr;
    }
    //�ֻ��ĸ���
    $mobile_index_fad = explode ("\n", str_replace ("\r", "", $settings['mobile_index_fad']['value']));
    foreach($mobile_index_fad as $key=>$value){
        $arr=explode('|',$value);
        $mobile_index_fad_arr[]=$arr;
    }
    //�ֻ�����ҳ�����ĸ���
    $mobile_index_siad = explode ("\n", str_replace ("\r", "", $settings['mobile_index_siad']['value']));
    foreach($mobile_index_siad as $key=>$value){
        $arr=explode('|',$value);
        $mobile_index_siad_arr[]=$arr;
    }
    //�ֻ���ͼ�Ĺ��
    $mobile_index_Photo_Ads = explode ("\n", str_replace ("\r", "", $settings['mobile_index_Photo_Ads']['value']));
    foreach($mobile_index_Photo_Ads as $key=>$value){
        $arr=explode('|',$value);
        $mobile_index_Photo_Ads_arr[]=$arr;
    }
}
//�Ƽ���Ʒ
loadcache('aljbd_rec_goods', 1);
if(!$_G['cache']['aljbd_rec_goods']) {
    $recommendlist_goods_index = C::t('#aljbd#aljbd_goods')->fetch_all_by_recommend_new(1,0,$config['recgnum']);
    savecache('aljbd_rec_goods', $recommendlist_goods_index);
}else{
    $recommendlist_goods_index = $_G['cache']['aljbd_rec_goods'];
}

foreach($recommendlist_goods_index as $k=>$v){
    $recommendlist_goods_index[$k]['price1']=floatval($v['price1']);
    $recommendlist_goods_index[$k]['price2']=floatval($v['price2']);
}
$recommendlist_goods_index = dhtmlspecialchars($recommendlist_goods_index);
//�Ƽ��Ż�ȯ
loadcache('aljbd_rec_consume', 1);
if(!$_G['cache']['aljbd_rec_consume']) {
    $recommendlist_consume_index=C::t('#aljbd#aljbd_consume')->fetch_all_by_recommend(1,0,5);
    savecache('aljbd_rec_consume', $recommendlist_consume_index);
}else{
    $recommendlist_consume_index = $_G['cache']['aljbd_rec_consume'];
}
$recommendlist_consume_index = dhtmlspecialchars($recommendlist_consume_index);
if(!$_G['mobile'] || !$_G['setting']['mobile']['allowmobile']){

    loadcache('aljbd_rec_brand', 1);
    if(!$_G['cache']['aljbd_rec_brand']) {
        $recommendlist_1=C::t('#aljbd#aljbd')->fetch_all_by_recommend(1,0,$_G['cache']['plugin']['aljbd']['recnum']);
        savecache('aljbd_rec_brand', array('recommendlist'=>$recommendlist_1));
    }else{
        $recommendlist_1 = $_G['cache']['aljbd_rec_brand']['recommendlist'];
    }
    $recommendlist_1 = dhtmlspecialchars($recommendlist_1);
    //PC��ҳת��
    $index_lz = explode ("\n", str_replace ("\r", "", $config ['index_lz']));
    foreach($index_lz as $key=>$value){
        $arr=explode('|',$value);
        $index_lz_types[$arr[0]]=$arr[1];
    }
    //pc��ҳ������
    $HomePageShortcut = explode ("\n", str_replace ("\r", "", $settings['HomePageShortcut']['value']));
    foreach($HomePageShortcut as $key=>$value){
        $arr=explode('|',$value);
        $HomePageShortcut_arr[]=$arr;
    }
    //pc��ҳģ��1���� ���Ż
    $HomePageModuleContent_1 = explode ("\n", str_replace ("\r", "", $settings['HomePageModuleContent_1']['value']));
    foreach($HomePageModuleContent_1 as $key=>$value){
        $arr=explode('|',$value);
        $HomePageModuleContent_1_arr[]=$arr;
    }
    //pc��ҳģ��2���� ��ɫ�Ƽ�
    $HomePageModuleContent_2 = explode ("\n", str_replace ("\r", "", $settings['HomePageModuleContent_2']['value']));
    foreach($HomePageModuleContent_2 as $key=>$value){
        $arr=explode('|',$value);
        $HomePageModuleContent_2_arr[]=$arr;
    }
    //pc��ҳģ��3���� ���ֺû�
    $HomePageModuleContent_3 = explode ("\n", str_replace ("\r", "", $settings['HomePageModuleContent_3']['value']));
    foreach($HomePageModuleContent_3 as $key=>$value){
        $arr=explode('|',$value);
        $HomePageModuleContent_3_arr[]=$arr;
    }
}
if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
    if($_G['cache']['plugin']['aljms']['is_aljms']){
        $ms_date = dgmdate(TIMESTAMP, "Ymd");
        $activity_list_select = DB::fetch_all('select * from %t', array('aljhtx_activity_ms'));
        
        $today = array();
        $tomorrow = array();
        foreach($activity_list_select as $k => $v){
            $activity_list_order_by_id[$v['id']] = $v;
            if(strtotime($v['end_time']) > TIMESTAMP){
                $today[$v[id]] = $v;
            }else{
                $tomorrow[$v[id]] = $v;
            }
        }

        $activity_list = array_merge($today, $tomorrow);



        //$first_activity = $activity_list[0];
        $first_activity_id = $activity_list[0]['id'];
        $now_activity_id = $_GET['now_activity_id'] ? $_GET['now_activity_id'] : $first_activity_id;
        $now_activity = $activity_list_order_by_id[$now_activity_id];

        if($first_activity_id == $now_activity_id){
            $times = strtotime($now_activity['end_time']) - TIMESTAMP;
        }else{
            $times = strtotime($now_activity['start_time']) - TIMESTAMP;
        }


        if(strtotime($now_activity['end_time'])<TIMESTAMP){
            $ms_date = dgmdate(strtotime("+1 day"), "Ymd");
            $times = strtotime($now_activity['start_time'])+86400 - TIMESTAMP;
        }



        $ms_goods_list = DB::fetch_all('select a.id ms_enter_id, a.*,b.* from %t a left join %t b on  a.ms_gid=b.id where a.ms_status = 0 and a.ms_date=%d and a.ms_activity=%d order by b.amount desc', array('aljhtx_activity_ms_enter', 'aljbd_goods', $ms_date, $now_activity_id));
        foreach ($ms_goods_list as $k => $v){
            $ms_goods_list[$k]['price1'] = $_G['cache']['plugin']['aljms']['is_hx_price'] ? floatval($v['price1']) : (floatval($v['price2'])>0?floatval($v['price2']):floatval($v['price1']));
            $ms_goods_list[$k]['ms_price']=floatval($v['ms_price']);
        }
    }

    if($_G['cache']['plugin']['aljhtx'] && file_exists('source/plugin/aljhtx/template/admin/diy/index/mobile_index_Photo_Ads_auto.htm')){
        $diyListData = DB::fetch_all('select * from %t where page=%s order by displayorder asc', array('aljhtx_diy', 'index'));
        foreach($diyListData as $k => $diy){
            if($diy['type'] == 'auto'){
                include_once 'source/plugin/aljhtx/class/class_aljhtx.php';
                $templateName = $diy['module'].'_'.$diy['type'];
                $diy['module'] = $templateName;
                $diy['data'] = T::stringSettingToArray($diy['data']);
                $diyList[$diy['auto_module']] = $diy;
            }else{
                $diyList[$diy['module']] = $diy;
            }

        }

        if($settings['aljad_index_sangead']['value']){
            unset($diyList['mobile_index_tad']);
        }else{
            unset($diyList['aljad_index_sangead']);
        }
        if($settings['aljad_index_four_lattice']['value']){
            unset($diyList['mobile_index_fad']);
        }else{
            unset($diyList['aljad_index_four_lattice']);
        }
    }
    //debug($mobile_index_tad_arr);
    //debug($diyList);
    include template('aljbd:aljbd_list');
} else {
    include template('diy:aljbd_list', null, 'source/plugin/aljbd/template');
}
//From: Dism��taobao��com
?>