<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$navtitle = lang('plugin/aljbd','sj_7').$config['title'];
$metakeywords =  $config['keywords'];
$metadescription = $config['description'];
$bd=C::t('#aljbd#aljbd')->fetch($bid);
if($newtemplate) {
    include template($common_template_pluginid.':new/post/dianping');
}else{
    include template('aljbd:dianping');
}
//From: Dism��taobao��com
?>