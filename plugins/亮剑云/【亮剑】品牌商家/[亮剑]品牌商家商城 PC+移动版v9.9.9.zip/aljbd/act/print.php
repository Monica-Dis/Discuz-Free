<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$cid = intval($_GET['cid']);
$c=C::t('#aljbd#aljbd_consume')->fetch($cid);
DB::query('UPDATE '.DB::table('aljbd_consume').' SET downnum=downnum+1 WHERE id=\''.$cid.'\'');
echo '<body onload="window.print()"><img src="'.$c['pic'].'"></body>';
exit();
?>