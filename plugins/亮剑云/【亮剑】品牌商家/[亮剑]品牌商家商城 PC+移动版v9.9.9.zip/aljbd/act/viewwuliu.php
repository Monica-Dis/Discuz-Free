<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$wuliu = C::t('#aljbd#aljbd_wuliu')->fetch($_GET['orderid']);
include template('aljbd:viewwuliu');
?>