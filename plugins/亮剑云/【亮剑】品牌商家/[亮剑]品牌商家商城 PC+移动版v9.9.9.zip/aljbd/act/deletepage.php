<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_GET['formhash']!=FORMHASH){
    exit('Access Denied!');
}
if(empty($_G['uid'])){
    showmessage(lang('plugin/aljbd','s39'));
}
$bdlist=C::t('#aljbd#aljbd_page')->fetch($_GET['nid']);
if($bdlist['uid']!=$_G['uid']){
    showmessage(lang('plugin/aljbd','aljbd_7'));
}
//unlink($bdlist['pic']);
if($_GET['nid']){
    C::t('#aljbd#aljbd_page')->delete($_GET['nid']);
}
showmessage(lang('plugin/aljbd','s55'),'plugin.php?id=aljbd&act=pagelist');
?>