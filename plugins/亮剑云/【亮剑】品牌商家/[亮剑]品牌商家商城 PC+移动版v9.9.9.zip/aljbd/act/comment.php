<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('formhash')){

    if(empty($_GET['commentmessage_1'])){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','s31')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','s31'));
        }
    }
    if(empty($_G['uid'])){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','s21')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','s21'));
        }

    }
    if($_G['cache']['plugin']['aljht']['on']){
        $status = 1;
    }
    $insertarray=array(
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'content'=>$_GET['commentmessage_1'],
        'bid'=>$bid,
        'displayorder'=>$_GET['isprivate'],
        'dateline'=>TIMESTAMP,
        'upid'=>0,
        'status'=>$status,
    );
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        $insertarray['k']=$_GET['k'];
        $insertarray['h']=$_GET['h'];
        $insertarray['f']=$_GET['f'];
    }else{
        $cs=explode('@',$_GET['commentscorestr']);
        
        foreach($cs as $k=>$v){
            if($v==11){
                $insertarray['k']=$cs[$k+1];
            }elseif($v==12){
                $insertarray['h']=$cs[$k+1];
            }elseif($v==13){
                $insertarray['f']=$cs[$k+1];
            }
        }
    }
    $insertarray['k']=$insertarray['k'] ? $insertarray['k'] :5;
    $insertarray['h']=$insertarray['h'] ? $insertarray['h'] :5;
    $insertarray['f']=$insertarray['f'] ? $insertarray['f'] :5;
    if($insertarray['k']){
        $insertarray['avg']=$insertarray['k'];
    }
    if($insertarray['k']&&$insertarray['h']){
        $insertarray['avg']=intval(($insertarray['k']+$insertarray['h'])/2);
    }
    if($insertarray['h']&&$insertarray['f']){
        $insertarray['avg']=intval(($insertarray['h']+$insertarray['f'])/2);
    }
    if($insertarray['k']&&$insertarray['h']&&$insertarray['f']){
        $insertarray['avg']=intval(($insertarray['k']+$insertarray['h']+$insertarray['f'])/3);
    }

    //$insertarray['avg']=intval(($insertarray['k']+$insertarray['h']+$insertarray['f'])/3);
    C::t('#aljbd#aljbd')->update_comment_by_bid($bid);
    C::t('#aljbd#aljbd_comment')->insert($insertarray);
    if($_G['cache']['plugin']['aljht']['on'] && file_exists("source/plugin/aljht/include/aljbd/replytips.php")){
        include 'source/plugin/aljht/include/aljbd/replytips.php';
    }else{
        $replytips = lang('plugin/aljbd','s32');
    }
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('".$replytips."',function(){parent.location.href='plugin.php?id=aljbd&act=view&bid=" . $bid . "&op=reply';});</script>";
    }else{
        showmsg($replytips);
    }
}
//From: Dism��taobao��com
?>