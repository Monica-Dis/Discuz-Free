<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$bd=C::t('#aljbd#aljbd')->fetch($bid);

$navtitle = $bd['name'].'-'.$config['title'];
$metakeywords =  $config['keywords'];
$metadescription = $config['description'];
include template('aljbd:map');
?>