<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_GET['do'] == 'yes'){
    if($_G['cache']['plugin']['aljbd_ss']['search_keyword']){
        $search_keyword = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljbd_ss']['search_keyword']));
        foreach($search_keyword as $key=>$value){
            $arr=explode('|',$value);
            $search_keyword_arr[$arr[0]]=$arr[1];
        }
    }
    $keyword = array_reverse(explode(',',$_GET['keyword']));
    $search_url = '';
    if($settings['close_goods']['value']){
        $searchUrl = 'plugin.php?id='.$pluginid.'&act=dianpu&kw=';
    }else{
        $searchUrl = 'plugin.php?id='.$pluginid.'&act=goods&kw=';
    }
    foreach($keyword as $k_k => $k_v){
        if($search_keyword_arr[$k_v]){
            $search_url .= '<a href="'.$search_keyword_arr[$k_v].'">'.$k_v.'</a>';
        }else{
            $search_url .= '<a href="'.$searchUrl.$k_v.'">'.$k_v.'</a>';
        }
    }
    echo $search_url;
    exit;
}

$navtitle = '&#25628;&#32034;&#32;&#45;&#32;'.$config['title'];
$metakeywords =  $config['keywords'];
$metadescription = $config['description'];
include template($pluginid.':search/search');
?>