<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('formhash')){
    for($i=1;$i<=3;$i++){
        if($_FILES['adv']['tmp_name'][$i]) {
            $picname = $_FILES['adv']['name'][$i];
            $picsize = $_FILES['adv']['size'][$i];

            if ($picname != "") {
                $type = strtolower(strrchr($picname, '.'));
                if ($type != ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
                    showerror(lang('plugin/aljbd','s25'));
                }
                if (($picsize/1024)>$config['img_size']) {
                    showerror(lang('plugin/aljbd','img1').$config['img_size'].'KB');
                }
                $rand = rand(100, 999);
                $pics = date("YmdHis") . $rand . $type;

                $dir=$image_path.'adv/'.date('Ymd',TIMESTAMP).'/';
                if(!is_dir($dir)) {
                    @mkdir($dir, 0777);
                }
                $adv[$i] = $dir. $pics;
                if(@copy($_FILES['adv']['tmp_name'][$i], $adv[$i])||@move_uploaded_file($_FILES['adv']['tmp_name'][$i], $adv[$i])){
                    @unlink($_FILES['adv']['tmp_name'][$i]);
                }
            }
        }
    }
    $bd=C::t('#aljbd#aljbd')->fetch($bid);
    $badv=unserialize($bd['adv']);

    $badvurl=unserialize($bd['advurl']);
    if($_GET['advdelete']){
        foreach($_GET['advdelete'] as $k=>$d){
            unlink($badv[$k]);
            unset($badv[$k]);

        }
    }
    if($badv){
        for($i=1;$i<=3;$i++){
            if($adv[$i]){
                $badv[$i]=$adv[$i];
            }
        }
        $adv=$badv;
    }


    C::t('#aljbd#aljbd')->update($bid,array('advurl'=>serialize($_GET['advurl']),'adv'=>serialize($adv)));
    showmsg(lang('plugin/aljbd','s27'),'edit');
}
$bd=C::t('#aljbd#aljbd')->fetch($bid);
$adv=unserialize($bd['adv']);
$advurl=unserialize($bd['advurl']);
include template('aljbd:adv');
?>