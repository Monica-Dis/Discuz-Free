<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($gid)){
    $info = array('desc' => lang('plugin/aljbd','nogoodsexists'));
    aljbdShowTips($info);
}

C::t('#aljbd#aljbd_goods')->update_view_by_gid($gid);
$g=C::t('#aljbd#aljbd_goods')->fetch($gid);

    
if(!$card_user && !$admin_status && $g['uid']!=$_G['uid'] && $g['is_aljtcc'] == 1){  
    $info = array('desc' => lang('plugin/aljbd','nogoodsexists'));
    aljbdShowTips($info);
}
if($g['other']){
    $other = unserialize($g['other']);
}//$other[unified_inventory]
if($_G['cache']['plugin']['aljvc']['on']){
    include 'source/plugin/aljvc/aljbd_script/aljvc.php';
}
if($settings['is_go_w_goods']['value'] && $g['gwurl']){
    header('Location: '.$g['gwurl']);
    exit;
}
if(empty($g) || $g['rubbish'] == 1){
    
    $info = array('desc' => lang('plugin/aljbd','nogoodsexists'));
    aljbdShowTips($info);
}
if($g['commodity_type'] == 4){
    dheader("location: plugin.php?id=aljwm&c=food&a=view&store_id=".$g['store_id']);
    exit;
}
if(($g['commodity_type'] == 8 || $g['commodity_type'] == 7) && !$_G['mobile']){
    
    if(strtolower(CHARSET) == 'gbk'){
		$_GET=T::ajaxGetCharSet($_GET);
    }
    define('IN_MOBILE', 2);
	$_G['mobile'] = 2;
}
if($_G['uid'] && !$_GET['fromuid'] && !$_GET['op'] && !$_GET['s'] && !$_GET['page'] && !$_GET['ajax']){
    
    //header("location: plugin.php?id=aljbd&act=goodview&bid=".$bid."&gid=".$gid."&fromuid=".$_G['uid'].'&d='.$_GET['d']);
    //exit;
}
$g['name'] = dhtmlspecialchars($g['name']);
$g['gwurl'] = dhtmlspecialchars($g['gwurl']);
$g['price1'] = floatval($g['price1']);
$g['price2'] = floatval($g['price2']);
if(!empty($g['m_intro_img'])){
    $post['poster_slt'] = explode("|", $g['m_intro_img']);
}
if(!empty($g['m_intro_text'])){
    $post['poster_slt_text'] = explode("|", $g['m_intro_text']);
}
//fxshop
if($_G['uid'] && $_G['cache']['plugin']['aljsfx']['is_aljsfx'] && $_G['mobile'] && !$_GET['ajax']){
    //$fx_shopdata = DB::fetch_first('select * from %t where uid=%d and status=1',array('aljsfx_shop',$_G['uid']));
    if(!$_GET['d'] && $g['is_distribution']>0 && $g['dis_commission']>0 && $fx_shopdata && !$_GET['op'] && !$_GET['s'] && !$_GET['page']){
        //dheader("location: plugin.php?id=aljbd&act=goodview&bid=".$bid."&gid=".$gid."&d=".$fx_shopdata['uid'].'&fromuid='.$_GET['fromuid']);
        //exit;
    }
}

$cgood = $g;

if($cgood['state'] && !$_G['cache']['plugin']['aljgwc']['aljbd'] && !$_G['cache']['plugin']['aljbdx']['is_aljqb']){
    $info = array('desc' => '&#21830;&#21697;&#24050;&#19979;&#26550;');
    aljbdShowTips($info);
}
$gattrkey = unserialize($g['attr_key']);
if(!$gattrkey){
    $gattrkey = 0;
}
$gattrkeyc = count($gattrkey);
$gattrvalue = unserialize($g['attr_value']);
foreach ($gattrvalue as $gvk => $gvv) {
    $def_gattrvalue[$gvv['kid']] = $gvv;
}
$g['attr_sku'] = unserialize($g['attr_sku']);
//ms
if($_G['cache']['plugin']['aljms']['is_aljms']){
    $ms_date = dgmdate(TIMESTAMP, "Ymd");
    $ms_info = DB::fetch_first('select * from %t where ms_status = 0 and ms_gid=%d and ms_date=%d and ms_start_time<=%d and ms_end_time>%d and ms_sale_num<ms_num',array('aljhtx_activity_ms_enter',$gid,$ms_date,TIMESTAMP,TIMESTAMP));
    
    if($ms_info){
        if($ms_info['ms_price'] >0 && $g['commodity_type'] != 2){
            //$g['price1'] = $ms_info['ms_price'];��ɱ��ȡ����ֵ
        }else{
            $g['collage_price'] = $ms_info['ms_price'];
        }
        if($_GET['ajax'] == 'notice_ms'){
            echo 1;
            exit;
        }
    }else{
        if($_GET['ajax'] == 'notice_ms' || !$_G['mobile']){
            $ms_info_notice = DB::fetch_first('select a.*,b.title from %t a left join %t b on a.ms_activity=b.id where a.ms_status = 0 and a.ms_gid=%d and a.ms_start_time>%d and a.ms_sale_num<ms_num order by a.ms_date asc limit 1',array('aljhtx_activity_ms_enter','aljhtx_activity_ms',$gid,TIMESTAMP));
            if($ms_info_notice){
                $ms_info_notice_text = '<i style="border:1px solid #f42424;border-radius: 5px;padding:0px 2px;color:#f42424;margin-right:3px;font-size:.35rem">&#31186;&#26432;&#39044;&#21578;</i>'.dgmdate($ms_info_notice['ms_start_time'],'m&#26376;d&#26085;').' '.$ms_info_notice['title'].'&#22330;&#31186;&#26432;&#20215; '.$price_unit.'<i style="font-size:18px;">'.floatval($ms_info_notice['ms_price']).'</i>';
            }
            
            if($_GET['ajax'] == 'notice_ms'){
                if($ms_info_notice_text){
                    echo json_encode(T::ajaxPostCharSet($ms_info_notice_text));
                    exit;
                }else{
                    echo 1;
                    exit;
                }
            }
        }
    }
    
}
$ii = 1;

if($_G['cache']['plugin']['aljtcc']){
    if($ms_info){//��ɱ�Ƿ�֧�ֻ�Ա���ۿ�
        
        if($_G['cache']['plugin']['aljms']['is_aljtcc_zk']){
            $yes_tcc = 1;
        }else{
            $yes_tcc = 0;
        }

    }else if($g['commodity_type'] == 3){//��ʱ�����Ƿ�֧�ֻ�Ա���ۿ�
        if($_G['cache']['plugin']['aljsqg']['is_aljtcc_zk']){
            $yes_tcc = 1;
        }else{
            $yes_tcc = 0;
        }
    }else if($g['commodity_type'] == 2){//ƴ���Ƿ�֧�ֻ�Ա���ۿ�
        if($_G['cache']['plugin']['aljspt']['is_aljtcc_zk']){
            $yes_tcc = 1;
        }else{
            $yes_tcc = 0;
        }
    }else{
        $yes_tcc = 1;
    }
}

foreach($g['attr_sku'] as $k => $v){
    $attr_sku_ms[$v['path']] = $v;
    
    
    //ms marketprice
    if($_G['cache']['plugin']['aljms']['is_aljms']){
        if($ms_info['ms_start_time'] < TIMESTAMP && $ms_info['ms_end_time'] > TIMESTAMP && ($v['path'] == $ms_info['ms_sku'] || $ms_info['ms_sku']==0)){
            if($g['commodity_type'] == 2){
                $v['marketprice'] = $ms_info['ms_price'];
            }else{
                $v['saleprice'] = $ms_info['ms_price'];
            }
            $ms_path = $v['path'];
        }
    }
    if($yes_tcc && $card_user){
            
        if($settings['is_card_price']['value']==1){
            //��Ա���۸�
            if($v['card_price']>0){
                if($g['commodity_type'] == 2){
                    $v['marketprice'] = $v['card_price'];
                }else{
                    $v['saleprice'] = $v['card_price'];
                }
            }
            
        }else{
            //��Ա���ۿ�
            if($g['card_price']>0){
                if($g['commodity_type'] == 2){
                    $v['marketprice'] = substr(sprintf("%.3f",$v['marketprice']*($g['card_price']/100)),0,-1);
                }
                $v['saleprice'] = substr(sprintf("%.3f",$v['saleprice']*($g['card_price']/100)),0,-1);
            }
        }
        
    }
    $gattrsku[$v['path']] = $v;
        
    
    $init_sku[] = $v;
    if($v['def'] == 1){
        $def_sku_id = explode(',',$v['path']);
    }else if($ii == 1 && $v['saleprice']>0 && $v['stock']>0){
        $def_sku_id = explode(',',$v['path']);
        $ii++;
    }
}

if($ms_path){
    $ms_paths = explode(',',$ms_path);
}

$gattrsku = json_encode($gattrsku);
$init_sku = json_encode($init_sku);

require_once libfile('function/discuzcode');
if(!file_exists('source/plugin/aljbd/com/intro.php')){
    $bd['intro']=discuzcode($bd['intro']);
}
require_once 'source/plugin/aljbd/include/brand_tips.php';
if($_G['cache']['plugin']['aljgwc']['aljbd'] || $_G['cache']['plugin']['aljbdx']['is_aljqb']){
    $payuser = DB::fetch_all('select a.uid,a.username from %t a left join %t b on a.orderid=b.orderid where a.status>1 and a.status<6 and a.confirmdate+%d > %i and a.pid=0 and b.goods_id=%d limit 0,10',array('aljbd_goods_order','aljbd_goods_order_list',31356000,TIMESTAMP,$gid));
    if($payuser){
        foreach($payuser as $mkey => $mval){
            $myTodaySignRecord_2[$mkey]['avatar'] = avatar($mval['uid'],'middle',true);
            $myTodaySignRecord_2[$mkey]['username'] = aljhtx::substr_cut($mval['username'],CHARSET);
        }
        $payuser_json = json_encode(aljhtx::ajaxPostCharSet($myTodaySignRecord_2));
    }
}

if($_GET['op'] == 'content'){
    require_once $common_path.'class/class_aljhtx.php';
    $navtitle = $aljbdlang['php']['Product_details'].' - '.$g['name'].'-'.$config['title'];
    //include template('aljbd:view/view_content');
    //echo json_encode(diconv($g['intro'],CHARSET,'UTF-8'));
    echo json_encode(aljhtx::ajaxPostCharSet($g['intro']));
    exit;
}elseif($_GET['op'] == 'expose_list'){
    if(!$_G['mobile']){
        dheader("location: plugin.php?id=aljbd&act=goodview&bid=".$bid."&gid=".$gid);
        exit;
    }
    $where = ' where a.upid=0 and a.rubbish=0 ';
    $conn[] = 'aljbd_comment_goods';
    $conn[] = 'aljbd_goods';
    if($gid){
        $where .= ' and a.gid=%d';
        $conn[] = $gid;
    }
    $overallTicketNum = DB::fetch_all('select overall_ticket,count(*) from %t a left join %t b on a.gid=b.id '.$where.' group by a.overall_ticket',$conn);
    foreach($overallTicketNum as $ov){
        $overallTicketCount[$ov['overall_ticket']] = $ov['count(*)'];
    }
    
    $reply_num = DB::result_first('SELECT count(*) FROM %t a left join %t b on a.gid=b.id '.$where,$conn);
    $imgNum = DB::result_first('select count(*) from %t a left join %t b on a.gid=b.id '.$where.' and a.imgs!=\'\' ',$conn);
    $videoNum = DB::result_first('select count(*) from %t a left join %t b on a.gid=b.id '.$where.' and a.video_path!=\'\' ',$conn);
    $navtitle = $aljbdlang['php']['Commodity_review'].' - '.$g['name'];
    include template($pluginid.':view/view_expose_list');
}else if($_GET['op'] == 'expose_detail'){
    if(!$_G['mobile']){
        dheader("location: plugin.php?id=aljbd&act=goodview&bid=".$bid."&gid=".$gid);
        exit;
    }
    $upid = intval($_GET['upid']);
    $reply = DB::fetch_first('SELECT * FROM %t WHERE id=%d',array($pluginid.'_comment_goods',$upid));
    $navtitle = $aljbdlang['php']['Comment_details'].' - '.$g['name'];
    include template($pluginid.':view/view_expose_detail');

}else{
    C::t('#aljbd#aljbd')->update_view_by_bid($bid);
    //$check=C::t('#aljbd#aljbd_user')->fetch($_G['uid']);
    if($bid){
        //$check=C::t('#aljbd#aljbd_username')->fetch_by_uid_bid($_G['uid'],$bid);
    }
    //$attrs = DB::fetch_all('select * from %t where tid = %d',array('aljbd_attr',$gid));
    /*foreach($attrs as $attr){
        $goodattrs[$attr['name']][$attr['mid']]['mid'] = $attr['mid'];
        $goodattrs[$attr['name']][$attr['mid']]['content'] = $attr['content'];
    }
    if(empty($check)&&$_G['uid']){
        C::t('#aljbd#aljbd_username')->insert(array('uid'=>$_G['uid'],'username'=>$_G['username'],'bid'=>$bid));
    }
    
    $khf=C::t('#aljbd#aljbd_comment')->count_by_bid($bid);
    foreach($khf[0] as $k=>$v){
        $khf[0][$k]=intval($v);
    }*/

    $typelist_goods=C::t('#aljbd#aljbd_type_goods')->range();
    
    //$commentcount=C::t('#aljbd#aljbd_comment')->count_by_bid_upid($bid,0,0);
    //$askcount=C::t('#aljbd#aljbd_comment')->count_by_bid_upid($bid,0,1);
    //$commentlist=C::t('#aljbd#aljbd_comment')->fetch_all_by_bid_upid($bid,0,0);
    //$asklist=C::t('#aljbd#aljbd_comment')->fetch_all_by_bid_upid($bid,0,1);
    
    //$avg=C::t('#aljbd#aljbd_comment')->count_avg_by_bid($bd['id']);
    //$avg=intval($avg);
    
    $qq=str_replace('{qq}',$bd['qq'],$config['qq']);
    $adv=unserialize($bd['adv']);
    $advurl=unserialize($bd['advurl']);
    //$comment = DB::fetch_first('select avg(k) k,avg(h) h,avg(f) f from %t where rubbish=0 and status=0 and bid=%d and ask=0',array('aljbd_comment',$bd['id']));
    //$businesstype = explode(',',$bd['businesstype']);
    /*if($bd['businesstype']){
        if($businesstype[0]){
            $commentkhf[$businesstype[0]] = $comment['k'];
        }
        if($businesstype[1]){
            $commentkhf[$businesstype[1]] = $comment['h'];
        }
        if($businesstype[2]){
            $commentkhf[$businesstype[2]] = $comment['f'];
        }
    }*/
    
    if(empty($g)){
        $info = array('desc' => lang('plugin/aljbd','nogoodsexists'));
        aljbdShowTips($info);
    }
    if($_GET['ajax'] == 'rec_goods' || !$_G['mobile']){
        $view_goods_num = $config['view_goods_num']?$config['view_goods_num']:6;//������Ʒ����

        $t=C::t('#aljbd#aljbd_goods')->fetch_all_by_uid_bid_view_new($g['uid'],$bid,0,$view_goods_num,0);
        foreach($t as $k=>$v){
            $t[$k]['price1']=T::skuminprice($v['attr_sku'],$v['commodity_type'])>0 ? T::skuminprice($v['attr_sku'],$v['commodity_type']) : floatval($v['price1']);
            $t[$k]['collage_price']=T::skuminprice($v['attr_sku'],$v['commodity_type'])>0 ? T::skuminprice($v['attr_sku'],$v['commodity_type']) : floatval($v['collage_price']);
            $t[$k]['price2']=floatval($v['price2']);
            if($settings['is_card_price']['value']==1 && $v['card_price'] > 0 && $card_user){
                if($v['commodity_type'] == 2){
                    $t[$k]['collage_price'] = floatval($v['card_price']).'<i class="c_p_t">'.$card_price_label.'</i>';
                }else{
                    $t[$k]['price1'] = floatval($v['card_price']).'<i class="c_p_t">'.$card_price_label.'</i>';
                }
            }
        }
        if($_GET['ajax'] == 'rec_goods'){
            if($t){
                include template('aljbd:view/view_tbrand');
                exit;
            }else{
                echo 1;
                exit;
            }
        }
    }
    

    if($imgnum == 12){
        $pics = array('pic1','pic2','pic3','pic4','pic5','pic6','pic7','pic8','pic9','pic10','pic11','pic12');
    }else{
        $pics = array('pic1','pic2', 'pic3', 'pic4', 'pic5');
    }
    if($u20181224){
        if($_G['cache']['plugin']['aljsp']['is_sp']){
            require_once 'source/plugin/aljsp/function/video_function_code.php';
            if($g['video_url']){
                $g['video_url'] = videourl($g['video_url']);
                $html_pc = "<div class=\"swiper-slide\" >".$g['video_url']."</div>";
                $html = "<div class=\"swiper-slide\" >".$g['video_url']."</div>";
            }
            if($g['vr_url']){
                $html_pc = "<div class=\"swiper-slide\" ><iframe src=\"".$g[vr_url]."\" class=\"vr_iframe\"  frameborder=\"0\" allowfullscreen width=\"100%\" height=\"100%\"></iframe></div>";;
                $html = "<div class=\"swiper-slide\" ><iframe src=\"".$g[vr_url]."\" class=\"vr_iframe\"  frameborder=\"0\" allowfullscreen width=\"100%\" height=\"100%\"></iframe></div>";
            }
            if(($g['video_url'] || $g['vr_url']) && strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
                $version = substr(T::getVersion($_SERVER['HTTP_USER_AGENT'],'micromessenger/') , 0 , 1);
                if(T::get_device_type() == 'ios'){
                    if($version<7){
                        $html_pc = "";
                        $html = "";
                    }else{
                        if(strpos($_SERVER['HTTP_USER_AGENT'],"miniProgram") !== false ){//miniProgram
                            $html_pc = "";
                            $html = "";
                        }
                    }
                }
            }
        }
        if($g['video_path']){
            $html_pc = 1;
            $html = "<div class=\"swiper-slide video-play\" ><div class=\"video_li\"></div><img class=\"video_img\" style=\"display:none;\"  src=\"".$g[video_path]."?x-oss-process=video/snapshot,t_5000,m_fast,w_800,h_800,f_jpg&crazycache=1\" /><video id=\"video\"    x5-playsinline  playsinline=\"\" poster=\"".$g[video_path]."?x-oss-process=video/snapshot,t_5000,m_fast,f_jpg&crazycache=1\"  preload=\"auto\" class=\"vr_iframe\"><source src=\"".$g['video_path']."\" type=\"video/mp4\"></video></div>";
        }
    }
    //<video controls=\"controls\" class=\"vr_iframe\"><source src=\"".$g['video_path']."\" type=\"video/mp4\"></video>
    if($_G['cache']['plugin']['aljoss']['cdn_domain']){
        if(strpos($g['pic1'],$_G['cache']['plugin']['aljoss']['domain']) !== false){
            $g['pic1'] = str_replace($_G['cache']['plugin']['aljoss']['domain'],$_G['cache']['plugin']['aljoss']['cdn_domain'],$g['pic1']);
        }
    }
    if($_G['cache']['plugin']['aljbd_bq']['is_aljbd_bq'] && !$_GET['ajax']){
        if($g['product_label']){
            $biaoqian = DB::fetch_all('select * from %t where id IN (%n)',array('aljbd_bq',explode(',',$g['product_label'])));
            $jiaobiao = $zhuanti = $dapeishangpin = $autohtml = array();
            foreach($biaoqian as $bq_k => $bq_v){
                if($bq_v['type'] == 1){
                    $jiaobiao = $bq_v;
                }else if($bq_v['type'] == 2){
                    $zhuanti = $bq_v;
                }else if($bq_v['type'] == 3){
                    $dapeishangpin = $bq_v;
                }else if($bq_v['type'] == 4){
                    $autohtml = $bq_v;
                }
            }
            if($dapeishangpin){
                //������⣬�ٵ�����ʾ
                $bq_goods = DB::fetch_all('select * from %t where qid=%d',array('aljbd_bq_goods',$dapeishangpin['id']));
                
                if($bq_goods){
                    
                    DB::query('delete from %t where uid=%d ',array('aljbd_bq_goods_check',$_G['uid']));
                    
                    $g_required = array();
                    foreach($bq_goods as $bq_k => $bq_v){
                        
                        DB::insert('aljbd_bq_goods_check',array(
                            'uid' => $_G['uid'],
                            'gid' => $bq_v['gid'],
                            'g_check' => $bq_v['required'] ? 1 : 0,
                            'bqid' => $bq_v['id'],
                            'qid' => $dapeishangpin['id'],
                        ));
                        
                        $g_required[$bq_v['gid']] = $bq_v['required'];
                    }
                    $bq_goods = DB::fetch_all('select a.*,b.price1,b.attr_sku,b.commodity_type,b.collage_price,b.price2,b.name,b.pic1 from %t a left join %t b on a.gid=b.id where a.qid=%d and a.uid=%d order by a.g_check desc',array('aljbd_bq_goods_check','aljbd_goods',$dapeishangpin['id'],$_G['uid']));
                    foreach($bq_goods as $bq_k => $bq_v){
                        $bq_goods[$bq_k]['required'] = $g_required[$bq_v['gid']];
                        $bq_goods[$bq_k]['price1']=T::skuminprice($bq_v['attr_sku'],$bq_v['commodity_type'])>0 ? T::skuminprice($bq_v['attr_sku'],$bq_v['commodity_type']) : floatval($bq_v['price1']);
                        $bq_goods[$bq_k]['collage_price']=T::skuminprice($bq_v['attr_sku'],$bq_v['commodity_type'])>0 ? T::skuminprice($bq_v['attr_sku'],$bq_v['commodity_type']) : floatval($bq_v['collage_price']);
                        $bq_goods[$bq_k]['price2']=floatval($bq_v['price2']);
                    }
                }
            }
        }
    }
    if($zhuanti){
        
        $zhuanti_text = explode ("\n", str_replace ("\r", "", $zhuanti[text]));
        $zhuanti_text_arr = array();
        foreach($zhuanti_text as $key=>$value){
            $arr=explode('|',$value);
            $zhuanti_text_arr[] =$arr;
        }
        $zhuanti[text] = $zhuanti_text_arr;
    }
    //foreach($pics as $p => $pic){
        //$html.="<div class=\"swiper-slide\" ><a class=\"aljsqImg\" href=\"javascript:void(0);\"><img src=".$g[$pic]." /></a></div>";
    //}
    if($html_pc){
        $html.= '<div class="swiper-slide" ><div class="swiper-container " id="img_swiper" style="max-height:400px;"><div class="swiper-wrapper slides" >';
        
        
    }
    if($jiaobiao){
        $html .= '<img class="g_biaoqian" src="'.$jiaobiao['text'].'" />';
    }
    $intro_lz = '';
    //$oss_domain = $_G['cache']['plugin']['aljoss']['cdn_domain'] ? $_G['cache']['plugin']['aljoss']['cdn_domain'] : $_G['cache']['plugin']['aljoss']['domain'];
    $p_i = 0;
    foreach($pics as $p => $pic){
        if($g[$pic]){
            $html.="<a class=\"aljsqImg swiper-slide\" href=\"javascript:void(0);\"><img src=".$g[$pic].$oss_img_url." /></a>";
            if($p_i != 0){
                if($_G['mobile']){
                    $intro_lz.="<a class=\"aljsqImg\" href=\"javascript:void(0);\"><img class=\"lazy\" data-original=\"".$g[$pic].$oss_img_url."\" /></a>";
                }else{
                    $intro_lz.="<a class=\"aljsqImg\" href=\"javascript:void(0);\"><img class=\"lazy\" src=\"".$g[$pic].$oss_img_url."\" /></a>";
                }
            }
        }
        $p_i++ ;
    }
    
    if($html_pc){
        $html.= '</div><div class=" swiper-pagination pagination-img"></div></div></div>';
    }

    if($_G['cache']['plugin']['aljsyh']['is_aljsyh'] && $g['store_id'] == 0 && ($_GET['ajax'] == 'goods_yh' || !$_G['mobile'])){
        $discount = DB::fetch_all('select *,(coupon_num - downnum) as d_value from %t where bid=%d and draw_channel=0 and rubbish=0 and status=0 and coupon_type<9 and (end>%s || end=0) and ((FIND_IN_SET(%d,goodstype) and available_goods=1) or available_goods=0) and (reduction>0 or (reduction=0 and coupon_type=2)) order by d_value desc',array('aljbd_consume',$bid,TIMESTAMP,$g['commodity_type']));
        foreach($discount as $ck => $cv){
            $discount[$ck]['clog'] = DB::result_first('select count(*) from %t where cid=%d and status=1 and uid=%d',array('aljsyh_consume_log',$cv['id'],$_G['uid']));
            $discount[$ck]['bdname'] = cutstr(DB::result_first('select name from %t where id=%d',array('aljbd',$cv['bid'])),20,'');
            $discount[$ck]['start'] = dgmdate($cv['start'],'Y.m.d');
            $discount[$ck]['end'] = dgmdate($cv['end'],'Y.m.d');
        }
        if($_GET['ajax'] == 'goods_yh'){
            if($discount){
                include template('aljsyh:goods/couponbtn');
                exit;
            }else{
                echo 1;
                exit;
            }
        }
    }

    $notice=C::t('#aljbd#aljbd_notice')->fetch_all_by_uid_bid($bd['uid'],$bid,0,9,'','','','',0);
    $notice = dhtmlspecialchars($notice);

    $navtitle = $g['name'].'-'.$bd['name'].'-'.$config['title'];
    $metakeywords =  $config['keywords'];
    $metadescription = $config['description'];
    if($aljbd_seo['good_view']['seotitle']){
        if($g['commodity_type'] == 2 && $g['collage_price'] > 0){
            $seo_price = $g['collage_price'];
        }else{
            $seo_price = $g['price1']>0?$g['price1']:lang('plugin/aljbd','goodsview_1');
        }
        
        $seodata = array('bbname' => $_G['setting']['bbname'],'bdname'=>$bd['name'],'message'=>cutstr(strip_tags(preg_replace('/\<img.*?\>/is', '', $g['intro'])),80),'subject'=>$g['name'],'price'=>$seo_price,'cat' => $typelist_goods[$g['type']]['subject'],'cat2' => $typelist_goods[$g['subtype']]['subject'],'cat3' => $typelist_goods[$g['subtype3']]['subject']);
        list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljbd_seo['good_view']);
    }
    $bd = dhtmlspecialchars($bd);

    if($_G['cache']['plugin']['aljspt']['is_aljspt'] && $g['commodity_type'] == 2 && $_GET['ajax'] == 'pt_goods'){
        function pt_overtime($var){
            global $_G;
            $grouptime=$_G['cache']['plugin']['aljspt']['grouptime']?intval($_G['cache']['plugin']['aljspt']['grouptime'])*3600 : 86400;
            $time =$var+$grouptime;
            $nowtime = TIMESTAMP;
            if ($time>=$nowtime){
                $overtime = $time-$nowtime;
            }else{
                $overtime=0;
            }
            return $overtime;
        }
        $pt_grouporder=DB::fetch_all('select * from %t where goodsid=%d and grouporderstatus=1',array('aljspt_collage_order', $gid));
        if($pt_grouporder){
            foreach($pt_grouporder as $tmp_key => $tmp_value){
                $pt_grouporder[$tmp_key]['overtime']=pt_overtime($tmp_value['groupopentime']);
            }
            include template('aljspt:goods/pt_list_ajax');
            exit;
        }else{
            echo 1;
            exit;
        }
    }
    
    if(($_G['cache']['plugin']['aljgwc']['aljbd'] || $_G['cache']['plugin']['aljbdx']['is_aljqb']) && ($_GET['ajax'] == 'goods_reply_list' || !$_G['mobile'])){
        
        if($_G['cache']['plugin']['aljbdx']['is_aljqb']){
            $tableName = 'aljbdx';
        }else{
            $tableName = 'aljgwc';
        }
        
        $replyNum = C::t('#'.$tableName.'#aljbd_comment_goods')->count_by_bid_all($g['id']);
        
        if($_G['cache']['plugin']['aljsd'] && $settings['is_reply_type']['value']==1){
            $where = ' where a.upid=0 and a.rubbish=0 ';
            $conn[] = 'aljbd_comment_goods';
            $conn[] = 'aljbd_goods';
            
            if($g['type']){
                $where .= ' and b.type=%d';
                $conn[] = $g['type'];
            }
            if($g['subtype']){
                $where .= ' and b.subtype=%d';
                $conn[] = $g['subtype'];
            }
            if(!$_G['mobile']){
                if($app_dowm){
                    $gid = 0;
                    $overallTicketNum = DB::fetch_all('select overall_ticket,count(*) from %t where rubbish=0 group by overall_ticket',array('aljbd_comment_goods'));
                }else{
                    $overallTicketNum = DB::fetch_all('select a.overall_ticket,count(*) from %t a left join %t b on a.gid=b.id '.$where.' group by a.overall_ticket',$conn);
                }
                foreach($overallTicketNum as $ov){
                    $overallTicketCount[$ov['overall_ticket']] = $ov['count(*)'];
                }
            }
            if($_G['mobile']){
                $img_where = ' and a.imgs!=\'\'';
                $img_Num = DB::result_first('SELECT count(*) FROM %t a left join %t b on a.gid=b.id'.$where.$img_where,$conn);
                if($img_Num<=0){//�ж��Ƿ��д�ͼ����
                    $num = $replyNum = DB::result_first('SELECT count(*) FROM %t a left join %t b on a.gid=b.id'.$where,$conn);
                }else{
                    $num = $replyNum = DB::result_first('SELECT count(*) FROM %t a left join %t b on a.gid=b.id'.$where,$conn);
                    $img_reply = 1;//��ͼ���۱�ʶ
                    $where .= $img_where;
                }
            }else{
                $num = $replyNum = DB::result_first('SELECT count(*) FROM %t a left join %t b on a.gid=b.id'.$where,$conn);
            }
            if($replyNum){
                $replyNumtext = '&nbsp;<font >( '.$replyNum.' )</font>';
            }
            $where .= ' order by a.dateline desc limit %d,%d';
            if(!$_G['mobile']){
                $currpage=$_GET['page']?$_GET['page']:1;
                $perpage=10;
                if(@ceil($num/$perpage) < $currpage && $no_max_page){
                    $currpage=1;
                }
                $start=($currpage-1)*$perpage;
                $conn[] = $start;
                $conn[] = $perpage;
            }else{
                $conn[] = 0;
                $conn[] = 5;
            }
            $goods_comment = $want_show_list_all = DB::fetch_all('SELECT a.*,b.type,b.subtype,b.subtype3,b.pic1 FROM %t a left join %t b on a.gid=b.id'.$where,$conn);
            $r_tourl = 'plugin.php?id=aljsd&type='.$g['type'].'&subtype='.$g['subtype'];
            if($app_dowm){
                foreach($goods_comment as $gck => $gcv){
                    $goods_comment[$gck]['gname'] = DB::result_first('select name from %t where id=%d',array('aljbd_goods',$gcv['gid']));
                }
            }else{
                foreach($goods_comment as $gck => $gcv){
                    $goods_comment[$gck]['orderlist_g'] = DB::fetch_first('select * from %t where goods_id=%d and orderid=%s ',array('aljbd_goods_order_list',$gcv['gid'],$gcv['orderid']));
                }
            }
            if(!$_G['mobile']){
                $paging = helper_page:: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=goodview&bid='.$g['bid'].'&gid='.$g['id'].'&overall_ticket='.$_GET['overall_ticket'].'#gm-messages', 0, 11, false, false);
            }
        }else{
            
            if(!$_G['mobile']){
                if($app_dowm){
                    $gid = 0;
                    $overallTicketNum = DB::fetch_all('select overall_ticket,count(*) from %t where rubbish=0 group by overall_ticket',array('aljbd_comment_goods'));
                }else{
                    $gid = $g['id'];
                    $overallTicketNum = DB::fetch_all('select overall_ticket,count(*) from %t where rubbish=0 and gid=%d group by overall_ticket',array('aljbd_comment_goods',$gid));
                }
                foreach($overallTicketNum as $ov){
                    $overallTicketCount[$ov['overall_ticket']] = $ov['count(*)'];
                }
                
                $num = C::t('#'.$tableName.'#aljbd_comment_goods')->count_by_upid('',$gid,$_GET['overall_ticket']);
                $currpage=$_GET['page']?$_GET['page']:1;
                $perpage=10;
                if(@ceil($num/$perpage) < $currpage){
                    $currpage=1;
                }
                $start=($currpage-1)*$perpage;
                $goods_comment = C::t('#'.$tableName.'#aljbd_comment_goods')->fetch_all_by_upid('',$gid,$_GET['overall_ticket'],$start,$perpage);
                if($app_dowm){
                    foreach($goods_comment as $gck => $gcv){
                        $goods_comment[$gck]['gname'] = DB::result_first('select name from %t where id=%d',array('aljbd_goods',$gcv['gid']));
                    }
                }
                
                $paging = helper_page:: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=goodview&bid='.$g['bid'].'&gid='.$g['id'].'&overall_ticket='.$_GET['overall_ticket'].'#gm-messages', 0, 11, false, false);
            }else{
                $want_show_list_all = DB::fetch_all('SELECT * FROM %t WHERE gid=%d  and upid=0 order by dateline desc limit %d,%d',array($pluginid.'_comment_goods',$gid,0,5));
                if($replyNum){
                    $replyNumtext = '&nbsp;<font >( '.$replyNum.' )</font>';
                }
                $r_tourl = 'plugin.php?id=aljbd&act=goodview&bid='.$g[bid].'&gid='.$g[id].'&op=expose_list';
            }
        }
        if($want_show_list_all){
            foreach($want_show_list_all as $wk => $wv){
                 if($wv['overall_ticket'] == 1){ 
                     $want_show_list_all[$wk]['reply_start_per'] = '100%';
                 }else if($wv['overall_ticket'] == 2){
                     $want_show_list_all[$wk]['reply_start_per'] = '60%';
                 }else if($wv['overall_ticket'] == 3){
                     $want_show_list_all[$wk]['reply_start_per'] = '20%';
                 }else{
                     $want_show_list_all[$wk]['reply_start_per'] = '0%';
                 }
                 $want_show_list[$wk]['orderlist_g'] = DB::fetch_first('select * from %t where goods_id=%d and orderid=%s ',array('aljbd_goods_order_list',$wv['gid'],$wv['orderid']));
            } 
        }
        if(!$_G['mobile']){
            $correlationClassification = C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($g['type']);//��ط���
            $btype = DB::fetch_all('select * from %t where bid=%d  and upid=0 ',array('aljbd_type_brand',$bid));//���̷���
            $buyamountarr=C::t('#aljbd#aljbd_goods')->fetch_all_by_uid_bid_view_new_buyamount($g['uid'],$bid,0,10,0,0,' AND store_id=0');//����
            foreach($buyamountarr as $b_k => $b_v){
                $buyamountarr[$b_k]['price1'] = floatval($b_v['price1']);
                if($settings['is_card_price']['value']==1 && $b_v['card_price'] > 0 && $card_user){
                    if($b_v['commodity_type'] == 2){
                        $buyamountarr[$b_k]['collage_price'] = floatval($b_v['card_price']).'<i class="c_p_t">'.$card_price_label.'</i>';
                    }else{
                        $buyamountarr[$b_k]['price1'] = floatval($b_v['card_price']).'<i class="c_p_t">'.$card_price_label.'</i>';
                    }
                }
            }
            
            $newarr=C::t('#aljbd#aljbd_goods')->fetch_all_by_uid_bid_view_new_displayorder($g['uid'],$bid,0,10,0,' AND store_id=0');//��Ʒ
            foreach($newarr as $b_k => $b_v){
                $newarr[$b_k]['price1'] = floatval($b_v['price1']);
                if($settings['is_card_price']['value']==1 && $b_v['card_price'] > 0 && $card_user){
                    if($b_v['commodity_type'] == 2){
                        $newarr[$b_k]['collage_price'] = floatval($b_v['card_price']).'<i class="c_p_t">'.$card_price_label.'</i>';
                    }else{
                        $newarr[$b_k]['price1'] = floatval($b_v['card_price']).'<i class="c_p_t">'.$card_price_label.'</i>';
                    }
                }
            }
        }
        if($_GET['ajax'] == 'goods_reply_list'){
            if($want_show_list_all){
                include template('aljbd:view/view_dianping_ajax');
                exit;
            }else{
                echo 1;
                exit;
            }
        }
    }
    if($_GET['ajax'] == 'goods_service'){
        include template('aljbdx:goods/service_btn');
        exit;
    }
    if($_GET['ajax'] == 'goods_volume' || !$_G['mobile']){
        $volume_label = DB::fetch_all('select * from %t where goods_id=%d and price_type=%d',array('aljbd_goods_volume_price',$gid,$g['is_volume']));
        $volume_label_num = $_G['cache']['plugin']['aljbd']['goods_label_num'] ? $_G['cache']['plugin']['aljbd']['goods_label_num'] : 2;
        if($volume_label){
            foreach($volume_label as $vk => $vv){
                $path_all .= $vv['path'].',';
            }
            $sku_name = C::t('#aljht#aljht_attr_value')->fetch_all(explode(',',trim($path_all,',')));
            foreach($volume_label as $sku_k => $sku_v){
                if($sku_v['path']){
                    $path_ex = explode(',',trim($sku_v['path'],','));
                    foreach($path_ex as $ex_v){
                        $ex_name .= $sku_name[$ex_v]['value'].',';
                    }
                    $volume_label[$sku_k]['path'] = trim($ex_name,',');
                    unset($path_ex);
                    unset($ex_name);
                }
            }
        }
        if($_GET['ajax'] == 'goods_volume'){
            if($volume_label){
                include template('aljht:aljbd/goods/volume_btn');
                exit;
            }else{
                echo 1;
                exit;
            }
        }
    }
    $sku_price_s = T::skuminprice(serialize($g['attr_sku']),$g['commodity_type'],1);
    
    
    /*if($_G['cache']['plugin']['aljbdx']['is_aljqb']){
        $bdx_where = ' and store_id=0';
    }
    $cartnum = DB::result_first('select count(*) from %t where uid=%d and pid=0 '.$bdx_where,array('aljgwc',$_G['uid']));
    */
    $fare = $g['fare'];
    if($g['fare_desc'] == 3 && $_G['cache']['plugin']['aljmb']['is_aljmb']){
        $province = $def_address['province'];
        if($province){
            $fare = T::mbminprice($g['fare'],0,$province);
        }else{
            $fare = T::mbminprice($g['fare'],1);
        }
    }
    if($bd['platform_distribution'] == 1 && $_G['cache']['plugin']['aljpps']['is_aljbd'] && !$aljtsq_post_goods){
        $fare = $_G['cache']['plugin']['aljpps']['aljbd_fare'];
    }
    if($_G['cache']['plugin']['aljtcc'] && $yes_tcc && $g['card_price']>0){
        
        if($g['collage_price']>0 && $_G['cache']['plugin']['aljspt']['is_aljspt'] && $g['commodity_type'] == 2){
            $card_price = $settings['is_card_price']['value']==1 ? $g['card_price'] : substr(sprintf("%.3f",$g['collage_price']*($g['card_price']/100)),0,-1);
        }else{
            $card_price = $settings['is_card_price']['value']==1 ? $g['card_price'] : substr(sprintf("%.3f",$g['price1']*($g['card_price']/100)),0,-1);
        }
        if($settings['is_card_price']['value']==1 && $card_price > 0 && $card_user){
            if($g['commodity_type'] == 2){
                $g['collage_price'] = $card_price;
            }else{
                $g['price1'] = $card_price;
            }
        }
        if(is_array($sku_price_s)){
            if($settings['is_card_price']['value']==1){
                $card_price_sku = $price_unit.$sku_price_s['card_pricemin'];
                if($sku_price_s['card_pricemax']>$sku_price_s['card_pricemin']){
                    $card_price_sku .= '<em style="font-size: 12px">~</em>'.$sku_price_s['card_pricemax'];
                }
            }else{
                $card_price_sku = $price_unit.substr(sprintf("%.3f",$sku_price_s['min_price']*($g['card_price']/100)),0,-1);
                if($sku_price_s['max_price']>$sku_price_s['min_price']){
                    $card_price_sku .= '<em style="font-size: 12px">~</em>'.substr(sprintf("%.3f",$sku_price_s['max_price']*($g['card_price']/100)),0,-1);
                }
            }
        }
    }
    if($_G['cache']['plugin']['aljvd']){
        $vd = DB::fetch_first('select * from %t where start = 1 and bid=%d and (dateline+hours * 3600)  > %d  order by vid desc', array('aljvd', $bid, TIMESTAMP));
    }
    if($g['pic1']){
        $sharedata[logo] = $g['pic1'];
    }
    $is_file_path = DISCUZ_ROOT.'./source/plugin/aljtrw/include/task.php';
    if(is_file($is_file_path)){
        if($g['commodity_type'] == 2){
            $task_id = 8;
        }else{
            $task_id = 7;
        }
        $object_id = $g['id'];
        include $is_file_path;
    }
    if($g['store_id']>0){
        $page_url = '&store=yes';
    }
    
    
    if($g['intro'] && $_G['mobile']){
        $g['intro'] = preg_replace('/<img(.*?) src=\"/',"<img \${1} class='lazy' data-original=\"",$g['intro']);
    }
    //����ҳ�滻�ֻ���ײ�����
    if($settings['mobile_goodsview_nav']['value']){
        $mobile_common_footernav_arr = array();
        $mobile_goodsview_nav = explode ("\n", str_replace ("\r", "", $settings['mobile_goodsview_nav']['value']));
        foreach($mobile_goodsview_nav as $key=>$value){
            $arr=explode('|',$value);
            $mobile_common_footernav_arr[]=$arr;
        }
    }
    //����ײ�����mobile_goodsview_bottom_nav
    if($settings['mobile_goodsview_bottom_nav']['value']){
        $mobile_goodsview_bottom_nav = explode ("\n", str_replace (array("\r",'{bid}'), array("",$bid), $settings['mobile_goodsview_bottom_nav']['value']));
        foreach($mobile_goodsview_bottom_nav as $key=>$value){
            $arr=explode('|',$value);
            $mobile_goodsview_bottom_nav_arr[]=$arr;
        }
    }
    
    include template('aljbd:goodview');
}
//From: Dism��taobao��com
?>