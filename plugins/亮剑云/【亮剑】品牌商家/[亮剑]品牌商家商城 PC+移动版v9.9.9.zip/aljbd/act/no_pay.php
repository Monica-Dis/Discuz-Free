<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
    //showmessage(lang('plugin/aljbd','s21'), $login_callback);
    dheader("location:".$login_callback);
}

$currpage=intval($_GET['page'])?intval($_GET['page']):1;
$perpage=$config['page'];
$num=C::t('#aljbd#aljbd')->count_by_status(2,$_G['uid'],'','','','','','','','','','','');
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start=($currpage-1)*$perpage;
$bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(2,$start,$perpage,$_G['uid'],'','','','','','','','','','','',0);
$bdlist = dhtmlspecialchars($bdlist);
$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=member&act=yes', 0, 11, false, false);
$navtitle = '&#24215;&#38138;&#31649;&#29702;-'.$config['title'];
$metakeywords =  $bd['other']?$bd['other']:$config['keywords'];
$metadescription = $config['description'];
include template('aljbd:member');
?>