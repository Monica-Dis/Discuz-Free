<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$uid = intval($_GET['uid']);
$user=getuserbyuid($uid);
$username = $user['username'];
$num=C::t('#aljbd#aljbd')->count_by_status(1,$_GET['uid'],'','','','','','','','','','','');
$currpage=intval($_GET['page'])?intval($_GET['page']):1;
$perpage=$config['page'];
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start=($currpage-1)*$perpage;
$bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,$start,$perpage,$_GET['uid'],'','','','','','','','','','','',0);
$paging = helper_page :: multi($num, $perpage, $currpage, "plugin.php?id=aljbd&act=glmsg&username=$username&uid=$uid&formhash=".FORMHASH, 0, 11, false, false);
include template('aljbd:glmsg');
?>