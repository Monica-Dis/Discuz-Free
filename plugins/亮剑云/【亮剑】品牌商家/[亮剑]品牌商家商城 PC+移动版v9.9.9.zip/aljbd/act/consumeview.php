<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$cid = intval($_GET['cid']);
if(empty($cid)){
    showmessage('&#26597;&#30475;&#30340;&#20248;&#24800;&#21048;&#19981;&#23384;&#22312;&#25110;&#24050;&#21024;&#38500;&#65281;');
}
if($_G['uid'] && $_G['cache']['plugin']['aljsfx']['is_aljsfx']){
    $fx_shopdata = DB::fetch_first('select * from %t where uid=%d and status=1',array('aljsfx_shop',$_G['uid']));
}
C::t('#aljbd#aljbd_consume')->update_view_by_gid($_GET['cid']);
//$check=C::t('#aljbd#aljbd_user')->fetch($_G['uid']);
$check=C::t('#aljbd#aljbd_username')->fetch_by_uid_bid($_G['uid'],$bid);
if(empty($check)&&$_G['uid']){
    C::t('#aljbd#aljbd_username')->insert(array('uid'=>$_G['uid'],'username'=>$_G['username'],'bid'=>$bid));
}
C::t('#aljbd#aljbd')->update_view_by_bid($bid);
$khf=C::t('#aljbd#aljbd_comment')->count_by_bid($bid);
foreach($khf[0] as $k=>$v){
    $khf[0][$k]=intval($v);
}

$commentcount=C::t('#aljbd#aljbd_comment')->count_by_bid_upid($bid,0,0);
$askcount=C::t('#aljbd#aljbd_comment')->count_by_bid_upid($bid,0,1);
$commentlist=C::t('#aljbd#aljbd_comment')->fetch_all_by_bid_upid($bid,0,0);
$commentlist = dhtmlspecialchars($commentlist);
$asklist=C::t('#aljbd#aljbd_comment')->fetch_all_by_bid_upid($bid,0,1);
$asklist = dhtmlspecialchars($asklist);
$bd=C::t('#aljbd#aljbd')->fetch($bid);

require_once libfile('function/discuzcode');
if(!file_exists('source/plugin/aljbd/com/intro.php')){
    $bd['intro']=discuzcode($bd['intro']);
}
$tell=str_replace('{qq}',$bd['qq'],str_replace('{tel}',$bd['tel'],$config['tel']));
$qq=str_replace('{qq}',$bd['qq'],$config['qq']);
$avg=C::t('#aljbd#aljbd_comment')->count_avg_by_bid($bd['id']);
$avg=intval($avg);

$adv=unserialize($bd['adv']);
$advurl=unserialize($bd['advurl']);

$c=C::t('#aljbd#aljbd_consume')->fetch($_GET['cid']);
if(empty($c) || $c['rubbish'] == 1){
    showmessage('&#26597;&#30475;&#30340;&#20248;&#24800;&#21048;&#19981;&#23384;&#22312;&#25110;&#24050;&#21024;&#38500;&#65281;');
}
if($c['coupon_type'] != 9){
    require_once 'source/plugin/aljbd/include/brand_tips.php';
}
$c['subject'] = dhtmlspecialchars($c['subject']);
$c['xianzhi']=discuzcode($c['xianzhi']);
//$t=C::t('#aljbd#aljbd_goods')->fetch_all_by_uid_bid_view($g['uid'],$bid,0,6);
$notice=C::t('#aljbd#aljbd_notice')->fetch_all_by_uid_bid($bd['uid'],$bid,0,9,'','','','',0);
$notice = dhtmlspecialchars($notice);
$bd = dhtmlspecialchars($bd);
$navtitle = $c['subject'].'-'.$bd['name'].'-'.$config['title'];
$metakeywords =  $config['keywords'];
$metadescription = $config['description'];
if($aljbd_seo['consume_view']['seotitle']){
    $seodata = array('bbname' => $_G['setting']['bbname'],'bdname'=>$bd['name'],'message'=>mb_substr(strip_tags(preg_replace('/\<img.*?\>/is', '', $c['jieshao'])),0,80,$_G['charset']),'subject'=>$c['subject']);
    list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljbd_seo['consume_view']);
}
if(file_exists('source/plugin/mapp_share/api/api.php')){
    $shareid = $cid;
    $sharetype = 3;
    require_once 'source/plugin/mapp_share/api/api.php';
}
if($_G['cache']['plugin']['aljsyh']['is_aljsyh']){
    include template('aljsyh:consume/consumeview');
}else{
    include template('aljbd:consumeview');
}
//From: Dism��taobao��com
?>