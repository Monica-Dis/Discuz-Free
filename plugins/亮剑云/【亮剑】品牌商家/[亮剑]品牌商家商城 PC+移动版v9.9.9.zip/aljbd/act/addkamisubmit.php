<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('formhash')){
    if($_GET['message']){
        $messages = explode ("\n", str_replace ("\r", "", $_GET['message']));
        foreach($messages as $message){
            C::t('#aljbd#aljbd_kami') -> insert(array(
                'sid' => $_GET['sid'],
                'message' => $message,
                'addtime' => TIMESTAMP,
            ));
        }
    }
    showmessage('&#28155;&#21152;&#25104;&#21151;&#65281;','plugin.php?id=aljbd&act=goodslist');
}
//From: Dism��taobao��com
?>