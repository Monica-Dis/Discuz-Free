<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
    //showmessage(lang('plugin/aljbd','s21'), $login_callback);
    dheader("location:".$login_callback);
}
if(!$aljbd && !$admin_status && !$staff){
    echo "<script>alert('".lang('plugin/aljbd','aljbd_7')."');location.href='plugin.php?id=aljbd&act=attend';</script>";
    exit;
}

if(in_array($_G['groupid'],$admingroups) && $_GET['i'] == 1){
    $uid = 0;
    $sh_status = 1;
}else{
    if($staff && $bid){//���̵�ԱȨ��
        $uid = 0;
    }else{
        $uid = $_G['uid'];
    }
    $sh_status = 0;
}
$num = C::t('#aljbd#aljbd_album')->count_by_uid_bid($uid, $bid, 0,$_GET['status'],$_GET['kw']);
$currpage = intval($_GET['page']) ? intval($_GET['page']) : 1;
$perpage = 10;
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start = ($currpage - 1) * $perpage;
$alist = C::t('#aljbd#aljbd_album')->fetch_all_by_uid_bid($uid, $bid, $start, $perpage, 0,$_GET['status'],$_GET['kw']);
$alist = dhtmlspecialchars($alist);
foreach($alist as $k=>$v){
    $alist[$k]['bdinfo']=C::t('#aljbd#aljbd')->fetch($v['bid']);
    if($alist['status'] == 1){
        $alist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_1');
    }else if($v['status'] == 2){
        $alist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_2');
    }else{
        $alist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_3');
    }
}
if($_GET['do'] == 'ajax'){
    require_once $common_path.'class/class_aljhtx.php';
    if($alist){
        echo json_encode(aljhtx::ajaxPostCharSet($alist));
    }else{
        echo '1';
    }
    exit;
}else {
    

    $paging = helper_page:: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=albumlist&bid=' . $bid, 0, 11, false, false);
    $navtitle = '&#30456;&#20876;&#31649;&#29702;';
    $metakeywords = $bd['other'] ? $bd['other'] : $config['keywords'];
    $metadescription = $config['description'];
    if($newtemplate){
        include template($common_template_pluginid.':new/user/albumlist');
    }else {
        include template('aljbd:albumlist');
    }
}
//From: Dism��taobao��com
?>