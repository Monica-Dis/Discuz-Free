<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_GET['upid']){
    if($_GET['type'] == 'goods' || $_GET['type'] == 'consume' || $_GET['type'] == 'notice' || $_GET['type'] == 'brand'){
        if($_GET['type'] == 'goods' || $_GET['type'] == 'consume' || $_GET['type'] == 'notice'){
            $tablename = '#'.$pluginid.'#'.$pluginid.'_type_'.$_GET['type'];
        }else{
            $tablename = '#'.$pluginid.'#'.$pluginid.'_type';
        }
        $rlist=C::t($tablename)->fetch_all_by_upid($_GET['upid']);
        $trid = 'id';
        $trname = 'subject';
    }else{
        $rlist=C::t('#'.$pluginid.'#'.$pluginid.'_region')->fetch_all_by_upid('','',$_GET['upid']);
        $trid = 'catid';
        $trname = 'name';
    }
    if(is_array($rlist)){
        foreach($rlist as $key => $val){
            $returnarray[$val[$trid]] = diconv($val[$trname],CHARSET,'utf-8');
        }
        echo json_encode($returnarray);
        exit;
    }
}
//From: Dism��taobao��com
?>