<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
    //showmessage(lang('plugin/aljbd','s21'), $login_callback);
    dheader("location:".$login_callback);
}
if($settings['deliverytime']['value']){
    $deliverytime = $settings['deliverytime']['value']*24*60*60;
}else{
    $deliverytime = 10*24*60*60;
}
if($_G['cache']['plugin']['aljbdx']['is_aljqb']  && file_exists('source/plugin/aljbdx/include/aljbd_orderlist.php')){
    require DISCUZ_ROOT.'./source/plugin/aljbdx/include/aljbd_orderlist.php';
}elseif($_G['cache']['plugin']['aljgwc'][$pluginid] && $_GET['cart'] != 'old'){
    require DISCUZ_ROOT.'./source/plugin/aljgwc/include/aljbd_orderlist.php';
}else{
    $page = intval($_GET['page']);
    $currpage = $page?$page:1;
    $perpage = 10;
    
    $bids = DB::fetch_all('select id from %t where uid = %d',array('aljbd_goods',$_G['uid']));
    foreach($bids as $bid){
        $ids[] = $bid['id'];
    }
    $bids = implode(',',$ids);
    if(in_array($_G['groupid'],$admingroups)){
        $num = DB::result_first('select count(*) from %t',array('aljbd_order'));
        if(@ceil($num/$perpage) < $currpage && $no_max_page){
            $currpage=1;
        }
        $start = ($currpage-1)*$perpage;
        $orderlist = DB::fetch_all('select * from %t order by submitdate desc limit %d,%d',array('aljbd_order',$start,$perpage));
    }else if($bids){
        //$num = DB::result_first('select count(*) from %t a left join %t b on a.id = b.sid where a.bid in(%i) or b.uid = %d',array('aljbd_goods','aljbd_order',$bids,$_G['uid']));
        //$orderlist = DB::fetch_all('select * from %t a left join %t b on a.id = b.sid where a.bid in(%i) or b.uid = %d order by b.submitdate desc limit %d,%d',array('aljbd_goods','aljbd_order',$bids,$_G['uid'],$start,$perpage));
        $num = DB::result_first('select count(*) from %t where sid in(%i) or uid = %d',array('aljbd_order',$bids,$_G['uid']));
        if(@ceil($num/$perpage) < $currpage && $no_max_page){
            $currpage=1;
        }
        $start = ($currpage-1)*$perpage;
        $orderlist = DB::fetch_all('select * from %t where sid in(%i) or uid = %d order by submitdate desc limit %d,%d',array('aljbd_order',$bids,$_G['uid'],$start,$perpage));
    }else{
        $num = DB::result_first('select count(*) from %t where uid = %d',array('aljbd_order',$_G['uid']));
        if(@ceil($num/$perpage) < $currpage && $no_max_page){
            $currpage=1;
        }
        $start = ($currpage-1)*$perpage;
        $orderlist = DB::fetch_all('select * from %t where uid = %d order by submitdate desc limit %d,%d',array('aljbd_order',$_G['uid'],$start,$perpage));
    }
    if($_G['cache']['plugin']['aljgwc'][$pluginid]){
        $paurl='&cart=old';
    }
    //debug($orderlist);
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=orderlist'.$paurl, 0, 11, false, false);
    $navtitle = '&#35746;&#21333;&#31649;&#29702;-'.$config['title'];
    $metakeywords =  $bd['other']?$bd['other']:$config['keywords'];
    $metadescription = $config['description'];
    include template('aljbd:orderlist');
}
//From: Dism��taobao��com
?>