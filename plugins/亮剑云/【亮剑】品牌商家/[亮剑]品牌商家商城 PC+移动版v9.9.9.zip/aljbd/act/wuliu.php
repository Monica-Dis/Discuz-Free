<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('formhash')){
    if($_G['cache']['plugin']['aljgwc'][$pluginid]){
        require DISCUZ_ROOT.'./source/plugin/aljgwc/include/aljbd_wuliu.php';
    }else{
        if(C::t('#aljbd#aljbd_wuliu')->fetch($_GET['orderid'])){
            C::t('#aljbd#aljbd_wuliu')->update($_GET['orderid'],array(
                'companyname' => $_GET['companyname'],
                'worderid' => $_GET['worderid'],
                'updatetime' => TIMESTAMP,
            ));


            $order = C::t('#aljbd#aljbd_order')->fetch($_GET['orderid']);
            notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&gid='.$order['sid'].'">'.$order['stitle'].'</a>',$config['fahuotips'])));
            if($config['time']){
                $email_first=C::t("common_member")->fetch($order['uid']);
                $email=$email_first['email'];

                if($email_first['email']){
                    $m=str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&gid='.$order['sid'].'">'.$order['stitle'].'</a>',$config['fahuotips']));
                    newsendmail_cron($email,$config['mailtitle'],$m);
                }
            }
            C::t('#aljbd#aljbd_order')->update_status_by_orderid($_GET['orderid']);
            showmessage(lang('plugin/aljbd','s9'), 'plugin.php?id=aljbd&act=orderlist');
        }else{
            C::t('#aljbd#aljbd_wuliu')->insert(array(
                'orderid' => $_GET['orderid'],
                'type' => 1,
                'companyname' => $_GET['companyname'],
                'worderid' => $_GET['worderid'],
                'dateline' => TIMESTAMP,
            ));
            C::t('#aljbd#aljbd_order')->update_status_by_orderid($_GET['orderid']);

            $order = C::t('#aljbd#aljbd_order')->fetch($_GET['orderid']);
            notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&gid='.$order['sid'].'">'.$order['stitle'].'</a>',$config['fahuotips'])));
            if($config['time']){
                $email_first=C::t("common_member")->fetch($order['uid']);
                $email=$email_first['email'];

                if($email_first['email']){
                    $m=str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&gid='.$order['sid'].'">'.$order['stitle'].'</a>',$config['fahuotips']));
                    newsendmail_cron($email,$config['mailtitle'],$m);
                }
            }
            showmessage(lang('plugin/aljbd','tg44'), 'plugin.php?id=aljbd&act=orderlist');
        }
    }
}else{
    $wuliu = C::t('#aljbd#aljbd_wuliu')->fetch($_GET['orderid']);
    $_GET['type'] = 2;
    include template('aljbd:wuliu');
}
//From: Dism��taobao��com
?>