<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
    showmessage(lang('plugin/aljbd','sc2'), '', array(), array('login' => true));
}

$_GET=dhtmlspecialchars($_GET);
$num = intval($_GET['num']);
$gid = intval($_GET['sid']);
$shop=C::t('#aljbd#aljbd_goods')->fetch($gid);

$orderid = dgmdate(TIMESTAMP, 'YmdHis').random(18);
if(C::t('#aljbd#aljbd_order')->fetch($orderid)) {
    showmessage('credits_addfunds_order_invalid', '', array(), array('showdialog' => 1, 'showmsg' => true, 'closetime' => true));
}
$shop = C::t('#aljbd#aljbd_goods')->fetch($_GET['sid']);

if (empty($num)) {
    showmessage(lang('plugin/aljbd','sc16'));
}
if ($shop['amount'] < $num) {
    showmessage(lang('plugin/aljbd','sc17'));
}

if (TIMESTAMP > $shop['endtime'] && !empty($shop['endtime'])) {
    echo showmessage(lang('plugin/aljbd','sc19'));
    exit;
}

C::t('#aljbd#aljbd_goods')->update_num_by_id($_GET['sid'],$num);

$allattrs = C::t('#aljbd#aljbd_attr') -> range();
foreach($_GET['typename'] as $v){
    $attrs[]=$allattrs[$v]['content'];
}
$attrs = implode(',',$attrs);
//΢��֧��Ϊpayment=1
C::t('#aljbd#aljbd_order')->insert(array(
    'orderid' => $orderid,
    'status' => '1',
    'uid' => $_G['uid'],
    'username' => $_G['username'],
    'sid' => $_GET['sid'],
    'stitle' => $shop['name'],
    'amount' => $num,
    'price' => $shop['price1'],
    'submitdate' => $_G['timestamp'],
    'remarks' => $attrs.$_GET['remarks'],
    'payment' => 1,
));
showmessage('&#19979;&#21333;&#25104;&#21151;', 'plugin.php?id=aljbd:wxpay&orderid='.$orderid, array(), array('header' => true));
?>