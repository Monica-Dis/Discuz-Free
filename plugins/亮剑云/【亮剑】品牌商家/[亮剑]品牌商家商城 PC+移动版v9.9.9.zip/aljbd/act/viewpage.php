<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$nid = intval($_GET['nid']);
if(empty($nid)){
    showmessage(lang('plugin/aljbd','nopage'));
}

$page = DB::fetch_first('select * from %t where id = %d',array('aljbd_page',$nid));
$bd = C::t('#aljbd#aljbd') ->fetch($page['bid']);
$bd = dhtmlspecialchars($bd);
$adv=unserialize($bd['adv']);
$advurl=unserialize($bd['advurl']);
$qq=str_replace('{qq}',$bd['qq'],$config['qq']);
$pagelist = DB::fetch_all('select * from %t where bid = %d order by displayorder desc',array('aljbd_page',$page['bid']));
$pagelist = dhtmlspecialchars($pagelist);
include template('aljbd:viewpage');
?>