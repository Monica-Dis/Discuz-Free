<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($bd['vipid']) {
    $vipdata = DB::fetch_first('select * from %t where id=%d', array('aljbd_vip', $bd['vipid']));
}

if(submitcheck('formhash')){

    if(empty($bid)){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','s51')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','s51'));
        }
    }
    if(empty($_GET['subject'])){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_1')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','aljbd_1'));
        }
    }
    if(empty($_GET['intro'])){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_2')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','aljbd_2'));
        }
    }
    
    $insertarray = array(
        'bid'=>$bid,
        'subject'=>$_GET['subject'],
        'content'=>$_GET['intro'],
        'type'=>$_GET['type'],
        'subtype'=>$_GET['subtype'],
        'region'=>$bd['region'],
        'region1'=>$bd['region1'],
        'subregion'=>$bd['subregion'],
    );
    if($_G['cache']['plugin']['aljshd']['is_aljshd']){
        $imgs = array();
                                        
        preg_match_all('/<img.*?src=\"?(.*?\.(jpg|jpeg|gif|bmp|bnp|png))\".*?>/i', $_GET['intro'], $match);
        
        
        foreach($match[1] as $key => $val){
            if($key > 2){
                break;
            }
            
            if(strpos($val,'http') !== false || strpos($val,'https') !== false){
                $siteurl = '';
            }else{
                $siteurl = $_G['siteurl'].'/';
            }
            list($width, $height, $type, $attr) = getimagesize($siteurl.$val);
            if($width<100){
                continue;
            }
            $imgs[] = $siteurl.$val;
        }
        if($imgs){
            $insertarray['cover_pic'] = serialize($imgs);
        }
        $insertarray['rec_gids'] = $_GET['rec_gids'];
    }
    if($_GET['act'] == 'addnotice'){
        if($settings['is_attes']['value']){
            $sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
            if(!$sign){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#24215;&#38138;&#24517;&#39035;&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#27963;&#21160;','');</script>";
                    exit;
                }else{
                    showerror('&#24215;&#38138;&#24517;&#39035;&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#27963;&#21160;');
                }
            }
        }
        if($settings['is_form']['value']){
            if(DB::result_first('select * from %t where subject = %s and bid=%d',array('aljbd_notice',$_GET['subject'],$bid))){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#27963;&#21160;&#24050;&#23384;&#22312;','');</script>";
                    exit;
                }else{
                    showerror('&#27963;&#21160;&#24050;&#23384;&#22312;');
                }
            }
            if(!valid_token($_GET['aljbd_notice_token'],getcookie('aljbd_notice_token'),'aljbd_notice_token')){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#27491;&#22312;&#21069;&#24448;&#27963;&#21160;&#31649;&#29702;',function(){parent.location.href='plugin.php?id=aljbd&act=noticelist';});</script>";
                    exit;
                }else{
                    showerror('&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#35831;&#21047;&#26032;&#21518;&#37325;&#26032;&#21457;&#24067;&#25110;<a href="plugin.php?id=aljbd&act=noticelist">&#36820;&#22238;&#27963;&#21160;&#31649;&#29702;&#26597;&#30475;&#27963;&#21160;</a>');
                }
            }
        }
        $insertarray['uid'] = $bd['uid'];
        $insertarray['username'] = $bd['username'];
        $insertarray['dateline'] = TIMESTAMP;
        if($vipdata['is_notice'] >0 && file_exists("source/plugin/aljht/include/aljbd/addnotice_send.php") && !in_array($_G['groupid'],$admingroups)){
            require_once 'source/plugin/aljht/include/aljbd/addnotice_send.php';
        }
        $insertid=C::t('#aljbd#aljbd_notice')->insert($insertarray,true);
        $sh_tips = $sh_tips ? $sh_tips : lang('plugin/aljbd','s53');
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".$sh_tips."',function(){parent.location.href='plugin.php?id=aljbd&act=noticelist&bid=".$bid."';});</script>";
            exit;
        }else{
            showmsg($sh_tips);
        }
    }else{
        C::t('#aljbd#aljbd_notice')->update($_GET['nid'],$insertarray);
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','s54')."',function(){parent.location.href='plugin.php?id=aljbd&act=noticelist&bid=".$bid."';});</script>";
            exit;
        }else{
            showmsg(lang('plugin/aljbd','s54'));
        }
    }

}else{
    if(empty($_G['uid'])){
        //showmessage(lang('plugin/aljbd','s21'), $login_callback);
        dheader("location:".$login_callback);
    }
    if($admin_status){
        $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','','');//����Ա
    }else{
        if($staff && $bid){//���̵�ԱȨ��
            $bdlist = DB::fetch_all('select * from %t where id = %d',array('aljbd',$staff['store_id']));
        }else{
            $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','',$_G['uid']);//����
        }
    }

    if($_GET['act'] == 'addnotice') {
        if($bd['vipid']){
            $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$bd['vipid']));
            $brandnum['notice']=$vipdata['notice'];
            $bnum = C::t('#aljbd#aljbd_notice')->count_by_uid_bid($_G['uid'], '', '', '', '', 0);
            if ($brandnum['notice']) {
                if ($brandnum['notice'] == $checksign) {
                    $info = array('desc' => lang('plugin/aljbd', 'noauth') . $noticetips);
                    $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                    aljbdShowTips($info);
                }
                if ($bnum >= $brandnum['notice']) {
                    $info = array('desc' => lang('plugin/aljbd', 'groups_1') . $brandnum['notice'] . lang('plugin/aljbd', 'groups_5') . $noticetips);
                    $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                    aljbdShowTips($info);
                }
            }
        }
        if($yhzqx) {
            $brandnum = C::t('#aljbd#aljbd_usergroup')->fetch($_G['groupid']);
            $bnum = C::t('#aljbd#aljbd_notice')->count_by_uid_bid($_G['uid'], '', '', '', '', 0);
            if ($brandnum['notice'] && file_exists('source/plugin/aljbd/com/yhzqx.php')) {
                if ($brandnum['notice'] == $checksign) {
                    $info = array('desc' => lang('plugin/aljbd', 'noauth') . $noticetips);
                    $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                    aljbdShowTips($info);
                }
                if ($bnum >= $brandnum['notice']) {
                    $info = array('desc' => lang('plugin/aljbd', 'groups_1') . $brandnum['notice'] . lang('plugin/aljbd', 'groups_5') . $noticetips);
                    $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                    aljbdShowTips($info);
                }
            }
        }
        if ($settings['is_attes']['value'] && $bid) {
            $sign = DB::result_first("select sign from " . DB::table('aljbd_attestation') . " where bid=" . $bid);
            if (!$sign) {
                $info = array('desc' => lang('plugin/aljbd','aljbd_php_17'));
                if($_G['mobile']){
                    $toUrl = 'plugin.php?id=aljbd&act=attestation&bid='.$bid;
                }else{
                    $toUrl = 'plugin.php?id=aljht&act=admin&op=attestation&do=addattestation&bid='.$bid.'&mod=my';
                }
                $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_18'), 'url' => $toUrl);
                $info['btn_default'] = array('value' => lang('plugin/aljbd','aljbd_php_14'), 'url' => 'javascript:history.back(-1)');
                aljbdShowTips($info);
            }
        }
    }
    if($_G['cache']['plugin']['aljshd']['aljshd_name']){
        require_once 'source/plugin/aljshd/include/addnotice.php';
    }else{
        $navtitle = lang('plugin/aljbd','index_6');
    }
    
    $metakeywords =  $bd['other']?$bd['other']:$config['keywords'];
    $metadescription = $config['description'];
    if($newtemplate){
        $typelist=C::t('#aljbd#aljbd_type_notice')->range();
        $json_typelist = C::t('#aljbd#aljbd_type_notice')->fetch_all_json();
        $typejson = json_encode($json_typelist);
        if($n['type']){
            $default_type = $typelist[$n['type']]['subject'].' '. ($typelist[$n['subtype']]['subject'] ? $typelist[$n['subtype']]['subject'] : '--');
            $type = $n['type'];
            $subtype = $n['subtype'];
        }else{
            $default_type = diconv($json_typelist[0]['name'].' '. $json_typelist[0]['sub'][0]['name'], 'utf-8', CHARSET);
            $type = $json_typelist[0]['code'];
            $subtype = $json_typelist[0]['sub'][0]['code'];
        }
        include template($common_template_pluginid.':new/post/addnotice');
    }else{
        $typelist=C::t('#aljbd#aljbd_type_notice')->fetch_all_by_upid(0);
        $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','',$_G['uid'],'','','','','','','','','','','',0);
        include template('aljbd:addnotice');
    }
}
//From: Dism��taobao��com
?>