<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
    //showmessage(lang('plugin/aljbd','s21'), $login_callback);
    dheader("location:".$login_callback);
    exit;
}
if(!$aljbd && !$admin_status && !$staff){
    echo "<script>alert('".lang('plugin/aljbd','aljbd_7')."');location.href='plugin.php?id=aljbd&act=attend';</script>";
    exit;
}

if(in_array($_G['groupid'],$admingroups) && $_GET['i'] == 1){
    $uid = 0;
    $sh_status = 1;
}else{
    if($staff && $bid){//���̵�ԱȨ��
        $uid = 0;
    }else{
        $uid = $_G['uid'];
    }
    $sh_status = 0;
}
$num = C::t('#aljbd#aljbd_consume')->count_by_uid_bid($uid, $bid, '', '', $_GET['kw'], 0,$_GET['status']);
$currpage = intval($_GET['page']) ? intval($_GET['page']) : 1;
$perpage = 10;
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start = ($currpage - 1) * $perpage;
$nlist = C::t('#aljbd#aljbd_consume')->fetch_all_by_uid_bid($uid, $bid, $start, $perpage, '', '', $_GET['kw'], 0,$_GET['status']);
$nlist = dhtmlspecialchars($nlist);
foreach($nlist as $k=>$v){
    $nlist[$k]['bdinfo']=C::t('#aljbd#aljbd')->fetch($v['bid']);
    $nlist[$k]['reduction']=floatval($v['reduction']);
    $nlist[$k]['full']=floatval($v['full']);
    if($v['status'] == 1){
        $nlist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_1');
    }else if($v['status'] == 2){
        $nlist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_2');
    }else{
        $nlist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_3');
    }
    if($v['end'] && $v['end']<TIMESTAMP){
        $nlist[$k]['expire'] = '<span style="color:red;font-size:12px;">&#12300;&#24050;&#36807;&#26399;&#12301;</span>';
    }else{
        $nlist[$k]['expire'] = '';
    }
    if($v['draw_channel'] == 1){
        $nlist[$k]['draw_channel_text'] = '<span style="color:red;font-size:12px;">&#12300;&#19981;&#20844;&#24320;&#12301;</span>';
    }else{
        $nlist[$k]['draw_channel_text'] = '';
    }
}
if($_GET['do'] == 'ajax'){
    require_once $common_path.'class/class_aljhtx.php';
    if($nlist){
        echo json_encode(aljhtx::ajaxPostCharSet($nlist));
    }else{
        echo '1';
    }
    exit;
}else {
    
    $paging = helper_page:: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=consumelist', 0, 11, false, false);
    $navtitle = '&#20248;&#24800;&#21048;&#31649;&#29702;-' . $config['title'];
    $metakeywords = $bd['other'] ? $bd['other'] : $config['keywords'];
    $metadescription = $config['description'];
    if($newtemplate){
        include template($common_template_pluginid.':new/user/consumelist');
    }else {
        include template('aljbd:consumelist');
    }
}
//From: Dism��taobao��com
?>