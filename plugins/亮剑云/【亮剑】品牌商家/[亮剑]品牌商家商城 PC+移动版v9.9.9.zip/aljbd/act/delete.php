<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
    showmessage(lang('plugin/aljbd','s39'));
}
$bdlist=C::t('#aljbd#aljbd')->fetch($bid);
if($bdlist['uid']!=$_G['uid'] && !$admin_status){
    showmessage(lang('plugin/aljbd','aljbd_7'));
}
if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
    if(submitcheck('formhash')){

        if($bid){

            del_brand_all($bid);

        }
        echo 1;
        exit;
    }else{
        $url='plugin.php?id=aljbd&act=delete&bid='.$bid;
        include template('aljbd:state');
    }
}else{
    if($bid){
        del_brand_all($bid);
    }
    showmessage(lang('plugin/aljbd','s50'),'plugin.php?id=aljbd&act=member');
}
//From: Dism��taobao��com
?>