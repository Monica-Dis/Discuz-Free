<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_G['cache']['plugin']['aljgwc'][$pluginid] && $_GET['cart'] != 'old'){
    require DISCUZ_ROOT.'./source/plugin/aljgwc/include/aljbd_settle.php';
}else{
    if($_G['cache']['plugin']['aljgwc']['aljbd_old_settle']){
        showmessage('&#26087;&#30340;&#32467;&#31639;&#24050;&#20851;&#38381;');
    }
    $cur = DB::result_first('select sum(a.amount*a.price) from %t a left join %t b on a.sid = b.id where b.uid = %d and a.status >= 2 group by b.uid',array('aljbd_order','aljbd_goods',$_G['uid'])) * (1-$config['per']);

    $cur = $cur - DB::result_first('select sum(settleprice) from %t where uid = %d and status < 2 group by uid',array('aljbd_settle',$_G['uid']));
    $cur = sprintf("%.3f",$cur);
    if (submitcheck('formhash')){
        if ($cur < $config['min']) {
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('".lang('plugin/aljbd','tg32')."','');</script>";
                exit;
            }else{
                showerror(lang('plugin/aljbd','tg32'));
                exit;
            }
        }
        $settleid = dgmdate(TIMESTAMP, 'YmdHis').random(18);
        C::t('#aljbd#aljbd_settle') -> insert(array(
            'uid' => $_G['uid'],
            'settleid' => $settleid,
            'settleprice' => $_GET['settleprice'],
            'username' => $_GET['username'],
            'account' => $_GET['account'],
            'payment' => $config['payment'],
            'status' => 0,
            'applytime' => TIMESTAMP,
        ));
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','tg33')."',function(){parent.location.href='plugin.php?id=aljbd&act=settlelist&cart=".$_GET['cart']."';});</script>";
            exit;
        }else{
            showmsg(lang('plugin/aljbd','tg33'));
        }
    } else{
        if($_G['cache']['plugin']['aljgwc'][$pluginid] && $_GET['cart'] != 'old'){
            $formurl='&cart=old';
        }
        include template('aljbd:settle');
    }
}
//From: Dism��taobao��com
?>