<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if(!$_GET['op'] && $_G['cache']['plugin']['aljdd']['is_aljdd']){
    if(file_exists("source/plugin/aljdiy/aljdiy.inc.php") && $_G['mobile']) {
        $page_diy = DB::fetch_first('select * from %t where push_to_page = %s and type=1 and bid=%d',array('aljdiy_page','aljbd_view',$bid));
        if($page_diy){
            $_GET['c'] = 'index';
            $_GET['a'] = 'index';
            $_GET['ajax'] = 'yes';
            $_GET['page_id'] = $page_diy['id'];
           
            require_once DISCUZ_ROOT . './source/plugin/aljdiy/aljdiy.inc.php';
            exit;
        }
    }
}
$bd=C::t('#aljbd#aljbd')->fetch($bid);
if(empty($bd) || $bd['rubbish']==1){
    $desc = lang('plugin/aljbd','view_php_16');
    $info = array('desc' => $desc);
    $info['title'] = $navtitle;
    $info['icon'] = 'weui-icon-warn';
    $info['btn_primary'] = array('value' => lang('plugin/aljbd','view_php_13'), 'url' => 'plugin.php?id=aljbd&act=dianpu');
    $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljbd');
    include template('aljbd:new/common/tips');
    exit;
}

require_once 'source/plugin/aljbd/include/brand_tips.php';
$avg=C::t('#aljbd#aljbd_comment')->count_avg_by_bid($bd['id']);
$avg=intval($avg);
$gg=explode("\n",str_replace(array("\r\n","\r"),array("\n","\n"),$bd['gg']));

$adv=unserialize($bd['adv']);

$advurl=unserialize($bd['advurl']);
$madv=unserialize($bd['madv']);

$madvurl=unserialize($bd['madvurl']);
if(file_exists("source/plugin/dcdz/dcdz.inc.php")){
    $bd['curl'] = unserialize($bd['curl']);
}

$commentcount = C::t('#aljbd#aljbd_comment')->count_by_bid_upid($bid,0,0);
//$goodscommentcount = DB::result_first('select count(*) from %t where bid=%d and upid=0',array('aljbd_comment_goods',$bid));
//$commentcount = $commentcount + $goodscommentcount;
require_once libfile('function/discuzcode');
$askcount=C::t('#aljbd#aljbd_comment')->count_by_bid_upid($bid,0,1);
$commentlist=C::t('#aljbd#aljbd_comment')->fetch_all_by_bid_upid($bid,0,0);
$commentlist=dhtmlspecialchars($commentlist);
$tell=str_replace('{qq}',$bd['qq'],str_replace('{tel}',$bd['tel'],$config['tel']));
$qq=str_replace('{qq}',$bd['qq'],$config['qq']);

$geturl = array(
    'id' => $pluginid,
    'act' => 'mobile_index_goods',
    'keywords' => $_GET['keywords'],
    'btypeid' => $_GET['btypeid'],
    'bsubtypeid' => $_GET['bsubtypeid'],
    'bid' => $bid,
    'mobilediy' => $_GET['mobilediy'],
    'mobiledemomode' => $_GET['mobiledemomode'],
);

//ͼ�굼��
$mobile_view_imgnav = explode ("\n", str_replace (array("\r",'{bid}'), array("",$bid), $_G['cache']['plugin']['aljbd']['mobile_view_imgnav']));
foreach($mobile_view_imgnav as $key=>$value){
    $arr=explode('|',$value);
    $mobile_view_imgnav_types[]=$arr;
}
if($_G['mobile']){
    if($bd['brand_bg']){
        $top_bg = $bd['brand_bg'];
    }elseif($_G['cache']['plugin']['aljbd']['def_brand_bg']){
        $top_bg = $_G['cache']['plugin']['aljbd']['def_brand_bg'];
    }else{
        $top_bg = 'source/plugin/aljbd/images/shop-bg.png';
    }
}
$bd=C::t('#aljbd#aljbd')->fetch($bid);
if(file_exists("source/plugin/dcdz/dcdz.inc.php")){
    $bd['curl'] = unserialize($bd['curl']);
}
if($bd['vipid']){
    $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$bd['vipid']));
}
if($_GET['op'] == 'aljtc'){
    $navtitle = lang('plugin/aljbd','view_php_1').' - '.$bd['name'];
    include template($pluginid.':view/view_aljtc');
}else if($_GET['op'] == 'aljsh' && $_G['cache']['plugin']['aljsh']){
    $navtitle = '&#26194;&#36135;'.' - '.$bd['name'];
    include template('aljsh:aljsh/aljsh/view/view_aljsh');
}else if($_GET['op'] == 'appointment'){
    if(!$_G['mobile']){
        header('location: plugin.php?id=aljsyy&act=aljbd_appointment&bid='.$bid);
        exit;
    }
    $navtitle = '&#39044;&#32422;'.$bd['name'];
    include template($pluginid.':view/view_appointment');
}else if($_GET['op'] == 'about'){
    include template($pluginid.':new/view/view_about');
}else if($_GET['op'] == 'consume'){
    if(!$_G['mobile']){
        header('location: plugin.php?id=aljbd&act=consume&bid='.$bid);
        exit;
    }
    $currpage=$_GET['page']?$_GET['page']:1;
    $perpage=9;
    $num=C::t('#aljbd#aljbd_consume')->count_by_uid_bid($bd['uid'],$bid,'','','',0);
    $allpage=ceil($num/$perpage);
    if(@ceil($num/$perpage) < $currpage && $no_max_page){
        $currpage=1;
    }
    $start=($currpage-1)*$perpage;
    $c=C::t('#aljbd#aljbd_consume')->fetch_all_by_uid_bid_view($bd['uid'],$bid,$start,$perpage,0);
    $c=dhtmlspecialchars($c);
    foreach($c as $k=>$v){
        $c[$k]['jieshao'] = htmlspecialchars_decode($v[jieshao]);
    }
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=view&op=consume&bid='.$bid, 0, 11, false, false);
    if($aljbd_seo['brand_consume_list']['seotitle']){
        $seodata = array('bbname' => $_G['setting']['bbname'],'bdname'=>$bd['name']);
        list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljbd_seo['brand_consume_list']);
    }
    $navtitle = lang('plugin/aljbd','view_php_2').' - '.$bd['name'];
    include template($pluginid.':view/view_consume');
}elseif($_GET['op'] == 'notice'){
    if(!$_G['mobile']){
        header('location: plugin.php?id=aljbd&act=notice&bid='.$bid);
        exit;
    }
    $currpage=$_GET['page']?$_GET['page']:1;
    $perpage=9;
    $num=C::t('#aljbd#aljbd_notice')->count_by_uid_bid($bd['uid'],$bid,'','','',0);
    $allpage=ceil($num/$perpage);
    if(@ceil($num/$perpage) < $currpage && $no_max_page){
        $currpage=1;
    }
    $start=($currpage-1)*$perpage;
    $n=C::t('#aljbd#aljbd_notice')->fetch_all_by_uid_bid_view($bd['uid'],$bid,$start,$perpage,0);
    $n=dhtmlspecialchars($n);
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=view&op=notice&bid='.$bid, 0, 11, false, false);
    if($aljbd_seo['brand_notice_list']['seotitle']){
        $seodata = array('bbname' => $_G['setting']['bbname'],'bdname'=>$bd['name']);
        list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljbd_seo['brand_notice_list']);
    }
    $navtitle = lang('plugin/aljbd','view_php_3').' - '.$bd['name'];
    include template($pluginid.':view/view_notice');
}elseif($_GET['op'] == 'album'){
    if(!$_G['mobile']){
        header('location: plugin.php?id=aljbd&act=album&bid='.$bid);
        exit;
    }
    if($_GET['do'] == 'ajax'){
        $alist=C::t('#aljbd#aljbd_album_attachments')->fetch_all_by_uid_bid($bd['uid'],$_GET['aid'],$start,$perpage,0);
        require_once $common_path.'class/class_aljhtx.php';
        echo json_encode(aljhtx::ajaxPostCharSet($alist));
        exit;
    }else{
        $navtitle = '&#30456;&#20876;&#21015;&#34920; - '.$bd['name'];
        include template($pluginid.':view/view_album');
    }
}elseif($_GET['op'] == 'video'){
    if(!$_G['mobile']){
        header('location: plugin.php?id=aljsp&act=video&bid='.$bid);
        exit;
    }
    $navtitle = lang('plugin/aljbd','view_php_4').' - '.$bd['name'];
    include template($pluginid.':view/view_video');
}elseif($_GET['op'] == 'details'){
    $navtitle = lang('plugin/aljbd','view_php_5').' - '.$bd['name'];
    include template($pluginid.':view/view_details');
}elseif($_GET['op'] == 'reply'){
    if(!$_G['mobile']){
        header('location: plugin.php?id=aljbd&act=view&bid='.$bid);
        exit;
    }
    $navtitle = lang('plugin/aljbd','view_php_6').' - '.$bd['name'];
    include template($pluginid.':view/view_reply');
}elseif($_GET['op'] == 'goods'){
    if(!$_G['mobile']){
        header('location: plugin.php?id=aljbd&act=good&bid='.$bid);
        exit;
    }
    $navtitle = lang('plugin/aljbd','view_php_7').' - '.$bd['name'];
    if($aljbd_seo['brand_good_list']['seotitle']){
        $seodata = array('bbname' => $_G['setting']['bbname'],'bdname'=>$bd['name'],'cat' => $typelist[$bd['type']]['subject'],'cat2' => $typelist[$bd['subtype']]['subject'],'cat3' => $typelist[$bd['subtype3']]['subject']);
        list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljbd_seo['brand_good_list']);
    }
    include template($pluginid.':view/view_goods');
}elseif($_GET['op'] == 'btype'){
    if(!$_G['mobile']){
        header('location: plugin.php?id=aljbd&act=view&bid='.$bid);
        exit;
    }
    $btype = DB::fetch_all('select * from %t where bid=%d  and upid=0 and type=0',array('aljbd_type_brand',$bid));
    $navtitle = lang('plugin/aljbd','view_php_8').' - '.$bd['name'];
    include template($pluginid.':view/view_btype');
}elseif($_GET['op'] == 'search'){
    if(!$_G['mobile']){
        header('location: plugin.php?id=aljbd&act=view&bid='.$bid);
        exit;
    }
    $navtitle = lang('plugin/aljbd','view_php_9').' - '.$bd['name'];
    include template($pluginid.':view/view_search');
}else{

    $check=C::t('#aljbd#aljbd_username')->fetch_by_uid_bid($_G['uid'],$bid);
    //$check=C::t('#aljbd#aljbd_user')->fetch($_G['uid']);
    if(empty($check)&&$_G['uid']){
        C::t('#aljbd#aljbd_username')->insert(array('uid'=>$_G['uid'],'username'=>$_G['username'],'bid'=>$bid));
    }
    C::t('#aljbd#aljbd')->update_view_by_bid($bid);
    $khf=C::t('#aljbd#aljbd_comment')->count_by_bid($bid);
    foreach($khf[0] as $k=>$v){
        $khf[0][$k]=intval($v);
    }

    if(!file_exists('source/plugin/aljbd/com/intro.php')){
        $bd['intro']=discuzcode($bd['intro']);
    }



    $asklist=C::t('#aljbd#aljbd_comment')->fetch_all_by_bid_upid($bid,0,1);
    $asklist=dhtmlspecialchars($asklist);



    if($_G['mobile'] && $settings['is_gobrand']['value'] && $bd['wurl']){
        header('Location: '.$bd['wurl']);
        exit;
    }else if($config['isgo'] && $bd['wurl']){
        header('Location: '.$bd['wurl']);
        exit;
    }
    //$bustype=explode(',',$bd['businesstype']);
    //debug($bustype[0]);

    if($config['mhot']){
        $mhotnum = $config['mhot'];
    }else{
        $mhotnum = 3;
    }
    $t=C::t('#aljbd#aljbd_goods')->fetch_all_by_uid_bid_view_new($bd['uid'],$bid,0,$mhotnum);
    foreach($t as $k=>$v){
        $t[$k]['price1']=T::skuminprice($v['attr_sku'],$v['commodity_type'])>0 ? T::skuminprice($v['attr_sku'],$v['commodity_type']) : floatval($v['price1']);
        $t[$k]['collage_price']=T::skuminprice($v['attr_sku'],$v['commodity_type'])>0 ? T::skuminprice($v['attr_sku'],$v['commodity_type']) : floatval($v['collage_price']);
    }
    $notice=C::t('#aljbd#aljbd_notice')->fetch_all_by_uid_bid($bd['uid'],$bid,0,9,'','','','',0);
    $notice=dhtmlspecialchars($notice);
    $navtitle = $bd['name'].'-'.$config['title'];
    $metakeywords =  $bd['other']?$bd['other']:$config['keywords'];
    $metadescription = $config['description'];




    


    if($aljbd_seo['view']['seotitle']){
        $seodata = array('bbname' => $_G['setting']['bbname'],'subject'=>$bd['name'],'message'=>cutstr(strip_tags(preg_replace('/\<img.*?\>/is', '', $bd['intro'])),80),'cat' => $typelist[$bd['type']]['subject'],'cat2' => $typelist[$bd['subtype']]['subject'],'cat3' => $typelist[$bd['subtype3']]['subject'],'region' => $rlist[$bd['region']]['name'],'region2' => $rlist[$bd['subregion']]['name'],'region3' => $rlist[$bd['region1']]['name'],'view_keyword' => $bd['other']);
        list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljbd_seo['view']);
    }
    $pagelist = DB::fetch_all('select * from %t where bid = %d',array('aljbd_page',$bid));
    $pagelist=dhtmlspecialchars($pagelist);
    $bd = dhtmlspecialchars($bd);
    if(!$settings['is_mobile_b_d']['value'] && !$settings['close_goods']['value']){
        $currpage=$_GET['page']?$_GET['page']:1;
        if($settings['view_goods_list_num']['value']){
            $perpage=$settings['view_goods_list_num']['value'];
        }else{
            $perpage=12;
        }

        $array = array('btypeid'=>intval($_GET['btypeid']),'bsubtypeid'=>intval($_GET['bsubtypeid']));
        $sql = ' AND store_id=0';
        if(!$card_user && !$admin_status && $bd['uid'] != $_G[uid]){ 
            $sql .= ' AND is_aljtcc=0';
        }
        if($_G['cache']['plugin']['aljsqtg']['hide_aljsqtg_goods']){
            $sql .= ' AND commodity_type!=8';
        }
        $num=C::t('#aljbd#aljbd_goods')->count_by_uid_bid_new($bd['uid'],$_GET['bid'],0,$array,$sql);

        $allpage=ceil($num/$perpage);

        $start=($currpage-1)*$perpage;
        
        $glist=C::t('#aljbd#aljbd_goods')->fetch_all_by_uid_bid_new($bd['uid'],$_GET['bid'],$start,$perpage,0,$array,$sql);
        foreach($glist as $k=>$v){
            $glist[$k]['price1']=T::skuminprice($v['attr_sku'],$v['commodity_type'])>0 ? T::skuminprice($v['attr_sku'],$v['commodity_type']) : floatval($v['price1']);
            $glist[$k]['collage_price']=T::skuminprice($v['attr_sku'],$v['commodity_type'])>0 ? T::skuminprice($v['attr_sku'],$v['commodity_type']) : floatval($v['collage_price']);
            $glist[$k]['price2']=floatval($v['price2']);
            if($v['selling_point']){
                $selling_point = str_replace('��',',',$v['selling_point']);
                $glist[$k]['selling_point'] = explode(',',$selling_point);
            }
            foreach($pics as $p_v){
                $glist[$k][$p_v] = $v[$p_v].$oss_img_url;
            }
            if($settings['is_card_price']['value']==1 && $v['card_price'] > 0 && $card_user){
                
                if($v['commodity_type'] == 2){
                    $glist[$k]['collage_price'] = floatval($v['card_price']).'<i class="c_p_t">'.$card_price_label.'</i>';
                }else{
                    $glist[$k]['price1'] = floatval($v['card_price']).'<i class="c_p_t">'.$card_price_label.'</i>';
                }
            }
            $glist[$k]['name'] = dhtmlspecialchars($v['name']);
            $glist[$k]['selling_point'] = dhtmlspecialchars($v['selling_point']);
        }
        
        
        $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=good&bid='.$_GET['bid'].'&btypeid='.$_GET['btypeid'].'&bsubtypeid='.$_GET['bsubtypeid'], 0, 11, false, false);
    }
    $is_file_path = DISCUZ_ROOT.'./source/plugin/aljtrw/include/task.php';
    if(is_file($is_file_path)){
        $task_id = 4;
        $object_id = $bid;
        include $is_file_path;
    }   
    include template('aljbd:view');
}
//From: Dism_taobao_com
?>
