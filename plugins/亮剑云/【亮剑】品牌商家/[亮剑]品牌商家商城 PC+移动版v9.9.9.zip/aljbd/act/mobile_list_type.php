<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if ($_GET['type']) {
    if($_GET['brand'] == 'goods'){
        $geturl = array(
            'id' => $pluginid,
            'act' => 'goods',
            'type' => $_GET['type'],
            'subtype' => $_GET['subtype'],
            'subtype3' => $_GET['subtype3'],
            'region' => $_GET['region'],
            'subregion' => $_GET['subregion'],
            'region1' => $_GET['region1'],
            'order' => $_GET['order'],
            'view' => $_GET['view'],
            'lng' => $_GET['lng'],
            'lat' => $_GET['lat'],
            'v' => $_GET['v'],
            'commodity_type' => $_GET['commodity_type'],
        );
        $rs = C::t('#'.$pluginid.'#'.$pluginid.'_type_goods')->fetch_all_by_upid($_GET['type']);
        $tablename = '_goods';
        if($aljtsq_post_goods){
            $geturl['id'] = 'aljtsc';
            $geturl['c'] = 'aljtsc';
            $geturl['a'] = 'goods';
        }
    }else{
        $geturl = array(
            'id' => $pluginid,
            'act' => 'dianpu',
            'type' => $_GET['type'],
            'subtype' => $_GET['subtype'],
            'subtype3' => $_GET['subtype3'],
            'region' => $_GET['region'],
            'subregion' => $_GET['subregion'],
            'region1' => $_GET['region1'],
            'order' => $_GET['order'],
            'view' => $_GET['view'],
            'lng' => $_GET['lng'],
            'lat' => $_GET['lat'],
            'commodity_type' => $_GET['commodity_type'],
        );
        $rs = C::t('#'.$pluginid.'#'.$pluginid.'_type')->fetch_all_by_upid($_GET['type']);
    }
}

if($_GET['sub']){
    $geturl['type'] = $_GET['subtype'];
    $geturl['subtype'] = $_GET['type'];
    include template($pluginid.':mobile_list_subtype');
}else{
    $geturl['type'] = $_GET['type'];
    $geturl['subtype'] = $_GET['subtype'];
    include template($pluginid.':mobile_list_type');
}
//From: Dism��taobao��com
?>