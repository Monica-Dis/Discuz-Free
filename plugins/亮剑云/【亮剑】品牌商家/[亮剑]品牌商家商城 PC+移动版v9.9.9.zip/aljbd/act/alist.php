<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$navtitle = lang('plugin/aljbd','index_9').$config['title'];
$metakeywords =  $config['keywords'];
$metadescription = $config['description'];
if(!$_G['mobile'] || !$_G['setting']['mobile']['allowmobile']){
    $typecount=C::t('#aljbd#aljbd_notice')->count_by_type();
    foreach($typecount as $tc){
        $tcs[$tc['type']]=$tc['num'];
    }
    if($_GET['type']){
        $subtypecount=C::t('#aljbd#aljbd_notice')->count_by_type($_GET['type']);
    }
    //$aljbd=C::t('#aljbd#aljbd')->range();
    $typelist=C::t('#aljbd#aljbd_type_notice')->range();
    $tlist=C::t('#aljbd#aljbd_type_notice')->fetch_all_by_upid(0);
    $recommendlist=C::t('#aljbd#aljbd')->fetch_all_by_recommend(1,0,10);
    $recommendlist_goods=C::t('#aljbd#aljbd_goods')->fetch_all_by_recommend_new(1,0,10);
    $notice=C::t('#aljbd#aljbd_notice')->fetch_all_by_uid_bid('','',0,9,'','','','',0);
}
$config=$_G['cache']['plugin']['aljbd'];
if($_G['charset']=='gbk'&&!defined('IN_MOBILE')&&$config['is_daohang']||defined('IN_MOBILE')&&!$_GET['sj']){
    $_GET['kw']=diconv($_GET['kw'],'utf-8','gbk');
}


//$num=C::t('#aljbd#aljbd_album')->count();
$num=DB::result_first('select count(*) from %t where rubbish=0',array('aljbd_album'));
$currpage=intval($_GET['page'])?intval($_GET['page']):1;
$perpage=20;
$total_page = floor($num/$perpage);
$allpage=ceil($num/$perpage);
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start=($currpage-1)*$perpage;
//$alist=C::t('#aljbd#aljbd_album')->range($start,$perpage,'desc');
$alist=DB::fetch_all('select * from %t where rubbish=0 order by id desc limit %d,%d',array('aljbd_album',$start,$perpage));

$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=alist&type='.$_GET['type'].'&subtype='.$_GET['subtype'].'&order='.$_GET['order'], 0, 11, false, false);
include template('aljbd:list_album');
?>