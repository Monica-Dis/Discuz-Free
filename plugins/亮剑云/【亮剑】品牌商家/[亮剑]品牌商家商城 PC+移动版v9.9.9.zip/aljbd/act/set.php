<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if(empty($_G['uid'])){
    //showmessage(lang('plugin/aljbd','s21'), $login_callback);
    dheader("location:".$login_callback);
}
$navtitle = '&#35774;&#32622;';
$metakeywords =  $config['keywords'];
$metadescription = $config['description'];
include template($common_template_pluginid.':new/user/set');
?>