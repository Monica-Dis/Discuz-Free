<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$array = array('code'=>1);

if($_GET['base']){
    $array['src'] = T::saveimg($_GET['base'],$path);
    echo json_encode(aljhtx::ajaxPostCharSet($array));
}else{
    $array['tips'] = 0;
    $array['tips'] = 'ͼƬ�ϴ�����������';
    echo json_encode(aljhtx::ajaxPostCharSet($array));
}
exit;
?>