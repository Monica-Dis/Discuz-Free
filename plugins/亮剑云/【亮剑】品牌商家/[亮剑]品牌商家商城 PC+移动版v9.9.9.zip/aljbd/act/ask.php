<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('formhash')){

    if(empty($_GET['commentmessage_2'])){
        showerror(lang('plugin/aljbd','s33'));
    }
    if(empty($_G['uid'])){
        showerror(lang('plugin/aljbd','s21'));
    }
    $insertarray=array(
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'content'=>$_GET['commentmessage_2'],
        'bid'=>$bid,
        'displayorder'=>$_GET['isprivate'],
        'dateline'=>TIMESTAMP,
        'upid'=>0,
        'ask'=>$_GET['ask']
    );
    C::t('#aljbd#aljbd_comment')->insert($insertarray);
    showmsg(lang('plugin/aljbd','s34'));
}
//From: Dism��taobao��com
?>