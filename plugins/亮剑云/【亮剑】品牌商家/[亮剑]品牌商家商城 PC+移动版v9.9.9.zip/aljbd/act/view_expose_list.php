<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$where = ' where a.upid=0 and a.rubbish=0 ';
$conn[] = 'aljbd_comment_goods';
$conn[] = 'aljbd_goods';
if($gid){
    $where .= ' and a.gid=%d';
    $conn[] = $gid;
}
if($_GET['status'] == 1){
    $where .= ' and a.imgs!=\'\'';
}else if($_GET['status'] == 2){
    $where .= ' and a.overall_ticket = 1';
}else if($_GET['status'] == 3){
    $where .= ' and a.overall_ticket = 3';
}else if($_GET['status'] == 4){
    $where .= ' and a.overall_ticket = 2';
}else if($_GET['status'] == 5){
    $where .= ' and a.video_path!=\'\'';
}
$num = DB::result_first('SELECT count(*) FROM %t a left join %t b on a.gid=b.id '.$where,$conn);
$currpage=$_GET['page']?$_GET['page']:1;
$perpage=10;
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start=($currpage-1)*$perpage;
$where .= ' order by dateline desc limit %d,%d';
$conn[] = $start;
$conn[] = $perpage;
$want_show_list = DB::fetch_all('SELECT a.*,b.type,b.subtype,b.subtype3,b.pic1 FROM %t a left join %t b on a.gid=b.id '.$where,$conn);
foreach ($want_show_list as $wk => $wv) {
    $want_show_list[$wk]['dateline'] = dgmdate($wv['dateline']);
    $want_show_list[$wk]['avatar'] = avatar($wv['uid'],'middle');
    if($wv['imgs']){
        $want_show_list[$wk]['imgs'] = explode('|',$wv['imgs']);;
    }
    $want_show_list[$wk]['username'] = T::substr_cut($wv['username'],CHARSET);
    $want_show_list[$wk]['view_url'] = 'plugin.php?id=aljbd&act=goodview&op=expose_detail&bid='.$wv['bid'].'&gid='.$wv['gid'].'&upid='.$wv['id'];
    if($wv['subtype'] && !$_GET['subtype']){
        $want_show_list[$wk]['type_url'] = 'plugin.php?id=aljsd&type='.$wv['type'].'&subtype='.$wv['subtype'].'&subtype3='.$wv['subtype3'];
    }else{
        $want_show_list[$wk]['type_url'] = 1;
    }
    $want_show_list[$wk]['orderlist_g'] = DB::fetch_first('select * from %t where goods_id=%d and orderid=%s ',array('aljbd_goods_order_list',$wv['gid'],$wv['orderid']));
    $want_show_list[$wk]['reply_num'] = DB::result_first('SELECT count(*) FROM %t WHERE upid=%d',array('aljbd_comment_goods',$wv['id']));
    if($wv['overall_ticket'] == 1){ 
        $want_show_list[$wk]['reply_start_per'] = '100%';
    }else if($wv['overall_ticket'] == 2){
        $want_show_list[$wk]['reply_start_per'] = '60%';
    }else if($wv['overall_ticket'] == 3){
        $want_show_list[$wk]['reply_start_per'] = '20%';
    }else{
        $want_show_list[$wk]['reply_start_per'] = '0%';
    }
}
$max = ceil($num/$perpage);
if($currpage == 1){
    $max_page ='<input type="hidden" id="max-page" value="'.$max.'">';
}
if($currpage == $max){
    $mes = '<div class="c_click_see" id="more" >'.lang('plugin/aljbd','No_more_data').'</div>';
}
include template($pluginid.':view/view_expose_list_ajax');
?>