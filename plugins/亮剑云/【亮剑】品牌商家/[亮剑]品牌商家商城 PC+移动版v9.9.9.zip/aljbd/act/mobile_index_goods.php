<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$array = array();

if($bid){
    $array['bid'] = $bid;
}
if (file_exists("source/plugin/aljht/aljht.inc.php")) {
    if ($_GET['btypeid']) {
        $array['btypeid'] = $_GET['btypeid'];
    }
    if ($_GET['bsubtypeid']) {
        $array['bsubtypeid'] = $_GET['bsubtypeid'];
    }
}
if($_GET['typeid']){
    if($_GET['typeid'] == 'recommend'){
        $status = 1;
        $_GET['typeid'] = 0;
    }
}else if ($settings['is_mobile_index_love_rec']['value']==1 && !$bid && !$aljtsq_post_goods){
    $status = 1;
}
if($aljtsq_post_goods){
    $sql = ' AND store_id>0 AND commodity_type !=4 ';
    if($_GET['fz_id'] > 0 || !$_G['cache']['plugin']['aljtsc']['is_aljtfz_showall']){
        if($city_info['associated_sites']){
            $city_info['associated_sites'] = $city_info['associated_sites'].','.$_GET['fz_id'];
            $sql .= ' and fz_id in ('.$city_info['associated_sites'].') ';
        }else{
            $sql .= ' and fz_id='.intval($_GET['fz_id']);
        }
    }
    
}else{
    $sql = ' AND store_id=0';
}
if($_GET['g_o'] == '2'){
    $_GET['commodity_type'] = 8;
    $sql .= ' AND category=0';
}
if(!$card_user && !$admin_status){
    if($bd && $bd['uid'] == $_G[uid]){
    }else{
        $sql .= ' AND is_aljtcc=0';
    }
}
if($_G['cache']['plugin']['aljsqtg']['hide_aljsqtg_goods'] && $_GET['g_o'] != '2'){
	$sql .= ' AND commodity_type!=8';
}
$num=C::t('#aljbd#aljbd_goods')->count_by_status_new($status,'',$_GET['typeid'],$_GET['subtype'],$_GET['region'],$_GET['subregion'],$_GET['keywords'],$_GET['subtype3'],0,$_GET['commodity_type'],$array,$sql);
$currpage=$_GET['page']?$_GET['page']:1;
$perpage=10;
if(@ceil($num/$perpage) < $currpage && $no_max_page){
    $currpage=1;
}
$start=($currpage-1)*$perpage;
$max = ceil($num/$perpage);

if($currpage == 1){
    $max_page ='<input type="hidden" id="max-page" value="'.$max.'">';
}

if($currpage == $max){
    $mes = '<div class="c_click_see" id="more" style="background: none;float: left;">'.lang('plugin/aljbd','No_more_data').'</div>';
}

$goodslist=C::t('#aljbd#aljbd_goods')->fetch_all_by_status_new(
    $status
    ,$start
    ,$perpage
    ,''
    ,$_GET['typeid']
    ,$_GET['subtype']
    ,$_GET['region']
    ,$_GET['subregion']
    ,$_GET['order']
    ,$_GET['keywords']
    ,$_GET['subtype3']
    ,0
    ,$_GET['commodity_type']
    ,$array
    ,$sql
);
foreach($goodslist as $k=>$v){
    $goodslist[$k]['price1']=T::skuminprice($v['attr_sku'],$v['commodity_type'])>0 ? T::skuminprice($v['attr_sku'],$v['commodity_type']) : floatval($v['price1']);
    $goodslist[$k]['collage_price']=T::skuminprice($v['attr_sku'],$v['commodity_type'])>0 ? T::skuminprice($v['attr_sku'],$v['commodity_type']) : floatval($v['collage_price']);
    $goodslist[$k]['price2']=floatval($v['price2']);
    if($v['selling_point']){
        $v['selling_point'] = str_replace(array(lang('plugin/aljbd','aljbd_php_22'),lang('plugin/aljbd','aljbd_php_23')),array(',',':'),$v['selling_point']);
        $selling_point = $v['selling_point'];
        $goodslist[$k]['selling_point'] = explode(',',$selling_point);
        if(strpos($v['selling_point'],':') !== false){
            foreach($goodslist[$k]['selling_point'] as $s_k => $sv){
                if(strpos($sv,':') !== false){
                    $selling_point2 = explode(':',$sv);
                }else{
                    $selling_point2 = array('*',$sv);
                }
                $goodslist[$k]['selling_point_types'][]=$selling_point2;
            }
        }else{
            $goodslist[$k]['selling_point_types'] = 1;
        }
    }
    foreach($pics as $p_v){
        $goodslist[$k][$p_v] = $v[$p_v].$oss_img_url;
    }
    if($_GET['g_o'] == '2'){
        $gwc_num = DB::result_first('select sum(num) from %t where goods_id=%d and uid=%d and pid=%d and type=8',array('aljgwc',$v['id'], $_G['uid'],0));
        $goodslist[$k]['gwc_num'] = $gwc_num ? $gwc_num : 0;
        $goodslist[$k]['gattrkey'] = unserialize($v['attr_key']);
    }
    if($settings['is_card_price']['value']==1 && $v['card_price'] > 0 && $card_user){
        if($_GET['g_o'] == '2'){
                    
        }else{   
            if($v['commodity_type'] == 2){
                $goodslist[$k]['collage_price'] = floatval($v['card_price']).'<i class="c_p_t">'.$card_price_label.'</i>';
            }else{
                $goodslist[$k]['price1'] = floatval($v['card_price']).'<i class="c_p_t">'.$card_price_label.'</i>';
            }
        }
    }
    $goodslist[$k]['name'] = dhtmlspecialchars($v['name']);
    $goodslist[$k]['selling_point'] = dhtmlspecialchars($goodslist[$k]['selling_point']);
    if(TIMESTAMP < $v['endtime'] || TIMESTAMP < $v['starttime']){
        if(TIMESTAMP < $v['starttime']){
            $goodslist[$k]['goods_status'] = 1;
        }
    }else if($v['endtime']>0){
        $goodslist[$k]['goods_status'] = 2;
    }
    if($v['amount'] <=0){
        $goodslist[$k]['goods_status'] = 3;
    }
    if($_G['cache']['plugin']['aljms']['is_aljms']){
        $ms_date = dgmdate(TIMESTAMP, "Ymd");
        $ms_info = DB::fetch_first('select * from %t where ms_status = 0 and ms_gid=%d and ms_date=%d and ms_start_time<=%d and ms_end_time>%d and ms_sale_num<ms_num',array('aljhtx_activity_ms_enter',$v['id'],$ms_date,TIMESTAMP,TIMESTAMP));
        if($ms_info){
            //$ms_info_notice_text = '<i style="border:1px solid #f42424;border-radius: 5px;padding:0px 2px;color:#f42424;margin-right:3px;font-size:.35rem">��ɱ��</i>'.$price_unit.$ms_info['ms_price'];
            if($v['commodity_type'] == 2){
                $goodslist[$k]['collage_price'] = floatval($ms_info['ms_price']).'<i style="border:1px solid #f42424;border-radius: 5px;padding:0px 2px;color:#f42424;margin-left:3px;font-size:.5rem">&#31186;&#26432;&#20215;</i>';
            }else{
                $goodslist[$k]['price1'] = floatval($ms_info['ms_price']).'<i style="border:1px solid #f42424;border-radius: 5px;padding:0px 2px;color:#f42424;margin-left:3px;font-size:.5rem">&#31186;&#26432;&#20215;</i>';
            }
        }else{
            $ms_info_notice = DB::fetch_first('select a.*,b.title from %t a left join %t b on a.ms_activity=b.id where a.ms_status = 0 and a.ms_gid=%d and a.ms_start_time>%d and a.ms_sale_num<ms_num order by a.ms_date asc limit 1',array('aljhtx_activity_ms_enter','aljhtx_activity_ms',$v['id'],TIMESTAMP));
            
            if($ms_info_notice){
                $ms_info_notice_text = '<i style="border:1px solid #f42424;border-radius: 5px;padding:0px 2px;color:#f42424;margin-right:3px;font-size:.45rem">&#31186;&#26432;&#39044;&#21578;</i>'.dgmdate($ms_info_notice['ms_start_time'],'m&#26376;d&#26085; H:i').' &#31186;&#26432;&#20215; '.$price_unit.'<i style="font-size:18px;">'.floatval($ms_info_notice['ms_price']).'</i>';
            }
        }
        $goodslist[$k]['ms_text'] = $ms_info_notice_text;
        unset($ms_info_notice_text);
    }
    $other = unserialize($v['other']);
    if($other['jiaobiao_img']){
        $goodslist[$k]['jiaobiao_img'] = $other['jiaobiao_img'];
    }
}

//$goodslist = dhtmlspecialchars($goodslist);
include template(($pluginid.':view/mobile_index_goods'));
?>