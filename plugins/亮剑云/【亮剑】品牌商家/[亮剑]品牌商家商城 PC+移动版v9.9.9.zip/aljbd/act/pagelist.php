<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
    //showmessage(lang('plugin/aljbd','s21'), $login_callback);
    dheader("location:".$login_callback);
}

$nlist=C::t('#aljbd#aljbd_page')->fetch_all_by_uid_bid($_G['uid'],$bid);
$nlist = dhtmlspecialchars($nlist);
$navtitle = '&#24215;&#38138;&#23548;&#33322;&#31649;&#29702;-'.$config['title'];
$metakeywords =  $bd['other']?$bd['other']:$config['keywords'];
$metadescription = $config['description'];
include template('aljbd:pagelist');
?>