<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$tid= intval($_GET['tid']);
$mid= intval($_GET['mid']);
if($mid && $tid){
    $thisgood = C::t('#aljbd#aljbd_goods')->fetch($tid);
    C::t('#aljbd#aljbd_attr') -> delete($mid);
    $type = C::t('#aljbd#aljbd_type_goods')->fetch($tid);
    
    $num=DB::result_first('select count(*) from %t where tid = %d',array('aljbd_attr',$tid));
    $currpage=intval($_GET['page'])?intval($_GET['page']):1;
    $perpage=10;
    if(@ceil($num/$perpage) < $currpage && $no_max_page){
        $currpage=1;
    }
    $start=($currpage-1)*$perpage;
    $attrlist=DB::fetch_all('select * from %t where tid = %d order by mid desc limit %d,%d',array('aljbd_attr',$tid,$start,$perpage));
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=attrlist&tid='.$tid, 0, 11, false, false);
    $config['atypes'] = str_replace('\r', '\n', $config['atypes']);
    $atypes = explode("\n", $config['atypes']);
    foreach ($atypes as $k => $type) {
        $type = explode('|', $type);
        $goodtypename[$type[0]] = trim($type[1]);
    }
    include template('aljbd:attrlist');
}
//From: Dism��taobao��com
?>