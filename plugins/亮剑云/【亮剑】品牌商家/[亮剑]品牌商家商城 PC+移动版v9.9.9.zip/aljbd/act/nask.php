<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('formhash')){

    if(empty($_GET['commentmessage_2'])){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','s33')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','s33'));
        }
    }
    if(empty($_G['uid'])){
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang('plugin/aljbd','s21')."','');</script>";
            exit;
        }else{
            showerror(lang('plugin/aljbd','s21'));
        }
    }
    if($_G['cache']['plugin']['aljht']){
        $status = 1;
    }
    $insertarray=array(
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'content'=>$_GET['commentmessage_2'],
        'bid'=>$bid,
        'dateline'=>TIMESTAMP,
        'upid'=>0,
        'nid'=>$_GET['nid'],
        'status'=>$status,
    );
    C::t('#aljbd#aljbd_comment_notice')->insert($insertarray);
    if($_G['cache']['plugin']['aljht'] && file_exists("source/plugin/aljht/include/aljbd/nreplytips.php")){
        include 'source/plugin/aljht/include/aljbd/nreplytips.php';
    }else{
        $replytips = lang('plugin/aljbd','s34');
    }
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('".$replytips."',function(){parent.location.href=parent.location.href;});</script>";
        exit;
    }else{
        showmsg($replytips);
    }
}
//From: Dism��taobao��com
?>