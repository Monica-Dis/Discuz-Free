<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_GET['m'] == 'tsc'){
    define('IN_MOBILE', 2);
    $_G['mobile'] = 2;
}
if($_GET['do']=='getdata'){
    $tid = intval($_GET['tid']);
    $kkk2=C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($_GET['tid']);
    $tlist=C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid(0);
    $brand_id = C::t('#aljbd#aljbd_type_goods')->fetch($tid);
    $brand_ids = explode(',',str_replace('��',',',$brand_id['brand_id']));
    $ppq=C::t('#aljbd#aljbd')->fetch_all($brand_ids);
    $type_ad = explode ("\n", str_replace ("\r", "", $brand_id ['type_ad']));
    foreach($type_ad as $key=>$value){
        $arr=explode('|',$value);
        $type_ad_types[$arr[0]]=$arr;
    }
    include template($pluginid.':type/getdata');
}else{
    $kkk=DB::fetch_all('SELECT * FROM %t WHERE upid=%d and is_open=0 ORDER BY displayorder ASC',array('aljbd_type_goods',0));
    $tid = $kkk[0][id];
    $kkk2=C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid($tid);
    $tlist=C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid(0);
    $brand_id = C::t('#aljbd#aljbd_type_goods')->fetch($tid);
    $brand_ids = explode(',',str_replace('��',',',$brand_id['brand_id']));
    $ppq=C::t('#aljbd#aljbd')->fetch_all($brand_ids);
    $type_ad = explode ("\n", str_replace ("\r", "", $brand_id ['type_ad']));
    foreach($type_ad as $key=>$value){
        $arr=explode('|',$value);
        $type_ad_types[$arr[0]]=$arr;
    }
    $navtitle = lang('plugin/aljbd','type_php_1');
    if(!$_G['mobile']){
        header('location: plugin.php?id=aljbd&act=goods');
        exit;
    }
    include template($pluginid.':type/type');
}
//From: Dism��taobao��com
?>