<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
    //showmessage(lang('plugin/aljbd','s21'), $login_callback);
    dheader("location:".$login_callback);
    exit;
}
if(!$bid){
    echo "<script>alert('".lang('plugin/aljbd','noexists')."');window.history.go(-1);</script>";
    exit;
}
if($_GET['do'] == 'setuid'){
    if($_G['cache']['plugin']['aljht'] && file_exists("source/plugin/aljht/include/aljbd/member_view.php")){
        include 'source/plugin/aljht/include/aljbd/member_view.php';
    }
}
$num=C::t('#aljbd#aljbd')->count_by_status(1,$_G['uid'],'','','','',$_GET['search_m'],'','','','','','');

if($bd['vipid']){
    $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$bd['vipid']));
    if($vipdata){
        $vipdata['store_authority'] = explode(',',$vipdata['store_authority']);
    }
}
if($_GET['do'] == 'addmaidan'){
            
    if($vipdata['pay_integral']>0 && $vipdata['pay_integral']<$_GET['pay_integral']){
        $vptips1 = lang("plugin/aljht","viptips_php_1");
        $vptips2 = lang("plugin/aljht","viptips_php_2");
        echo "<script>parent.tips('".$vptips1.$vipdata['pay_integral']."%".$vptips2."','');</script>";
        exit;
    }
    $s_give_integral = $vipdata['give_integral'];
    $tips_s = lang("plugin/aljht","goods_php_44");
    $tips_e = '%';
    
    if($vipdata['give_integral']>0 && $s_give_integral<$_GET['give_integral']){
        echo "<script>parent.tips('".$tips_s.$s_give_integral.$tips_e."','');</script>";
        exit;
    }
    $others = array();
    $others['pay_integral'] = $_GET['pay_integral'];
    $others['give_integral'] = $_GET['give_integral'];
    
    C::t('#aljbd#aljbd')->update($bd['id'],array('others' => serialize($others)));
    echo "<script>parent.tips('".lang('plugin/aljbd','tg18')."',function(){location.href='plugin.php?id=aljbd&act=member_view&bid=".$bid."'});</script>";
    exit;
}
$bd['others'] = unserialize($bd['others']);
if($_G['cache']['plugin']['aljbdx']['is_aljqb']){
    $aljbd_groups=C::t('#aljbd#aljbd_vip')->fetch_all_by_user();
}
if($_G['cache']['plugin']['aljsyh']['is_aljsyh']){
    $discount = DB::fetch_all('select a.id,b.full,b.reduction,b.coupon_type from %t a left join %t b on a.cid=b.id where (b.end>%s || b.end=0) and b.coupon_type=9 and a.status=%d and a.uid=%d order by b.reduction desc',array('aljsyh_consume_log','aljbd_consume', TIMESTAMP,1,$_G['uid']));
    foreach($discount as $dk => $kv){
        $discount[$dk]['full'] = floatval($kv['full']);
        $discount[$dk]['reduction'] = floatval($kv['reduction']);
    }
}
$navtitle = $bd['name'];
$metakeywords =  $bd['other']?$bd['other']:$config['keywords'];
$metadescription = $config['description'];
include template('aljht:aljbd/member/member_view');

?>