<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('formhash')){
    if($_GET['content']){
        $contents = explode ("\n", str_replace ("\r", "", $_GET['content']));
        foreach($contents as $content){
            C::t('#aljbd#aljbd_attr') -> insert(array(
                'tid' => $_GET['tid'],
                'name' => $_GET['name'],
                'content' => $content,
                'addtime' => TIMESTAMP,
            ));
        }
    }
    echo '<script>alert("'.lang('plugin/aljbd','s9').'");</script>';
    exit;
}
//From: Dism��taobao��com
?>