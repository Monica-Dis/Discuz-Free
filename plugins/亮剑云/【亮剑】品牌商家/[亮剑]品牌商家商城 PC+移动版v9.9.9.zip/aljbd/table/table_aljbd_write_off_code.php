<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljbd_write_off_code extends discuz_table {

    public function __construct() {

        $this->_table = 'aljbd_write_off_code';
        $this->_pk = 'password';

        parent::__construct(); /*dism��taobao��com*/
    }
}
//From: Dism_taobao_com
?>