<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljbd_type_brand extends discuz_table{
	public function __construct() {

			$this->_table = 'aljbd_type_brand';
			$this->_pk    = 'id';

			parent::__construct(); /*dism��taobao��com*/
	}
    public function fetch_all_json($store_id=0,$bid=0)
    {
        $result = $this->fetch_all_by_upid_json(0,$store_id,$bid);
        array_unshift($result,array('name'=>'--','code'=>0,'id'=>-1));
        foreach ($result as $index => $item) {
            $result[$index]['name'] = diconv($item['name'], CHARSET, 'utf-8');
            $subregion = $this->fetch_all_by_upid_json($item['id'],$store_id,$bid);
            if($subregion){
                array_unshift($subregion,array('name'=>'--','code'=>0));
                foreach ($subregion as $subk => $subv){
                    $subregion[$subk]['name'] = diconv($subv['name'], CHARSET, 'utf-8');
                }
            }else{
                $subregion[0]['name'] = '--';
                $subregion[0]['code'] = '0';
            }
            $result[$index]['sub'] = $subregion;
        }
        
        return $result;
    }
    public function fetch_all_by_upid_json($upid,$store_id=0,$bid=0){
	    if($bid>0){
	        $con = ' and bid = '.$bid;
        }
        return DB::fetch_all('SELECT subject as name,upid,id,id as code FROM %t WHERE upid=%d and store_id=%d '.$con.' ORDER BY displayorder ASC',array($this->_table,$upid,$store_id));
    }
	public function fetch_upid_by_id($id=0){
		return DB::result_first('SELECT upid FROM %t WHERE id=%d',array($this->_table,$id));
	}
	public function fetch_subid_by_id($id=0){
		return DB::result_first('SELECT subid FROM %t WHERE id=%d',array($this->_table,$id));
	}
	public function fetch_all_by_upid($upid=0){
		return DB::fetch_all('SELECT * FROM %t WHERE upid=%d ORDER BY displayorder ASC',array($this->_table,$upid),'id');
	}
	public function fetch_all_by_type($type=0){
		return DB::fetch_all('select * from %t where id=%d ORDER BY displayorder ASC',array($this->_table,$type));
	}

}




?>