<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljbd_comment extends discuz_table{
	public function __construct() {

			$this->_table = 'aljbd_comment';
			$this->_pk    = 'id';

			parent::__construct(); /*dism��taobao��com*/
	}
	public function fetch_by_bid($bid=0){
		return DB::fetch_first('select * from %t where status=0 and rubbish=0 and bid=%d and upid=0 and uid!=0',array($this->_table,$bid));
	}
	public function count_by_bid_upid($bid=0,$upid=0,$ask=0){
		return DB::result_first('select count(*) from %t where status=0 and rubbish=0 and bid=%d and upid=%d and ask=%d and uid!=0',array($this->_table,$bid,$upid,$ask));
	}
	public function fetch_all_by_bid_upid($bid=0,$upid=0,$ask=0){
		return DB::fetch_all('select * from %t where status=0 and rubbish=0 and bid=%d and upid=%d and ask=%d and uid!=0 order by id desc',array($this->_table,$bid,$upid,$ask));
	}
	public function fetch_all_by_upid($upid=0){
		return DB::fetch_all('select * from %t where status=0 and rubbish=0 and upid=%d order by id desc',array($this->_table,$upid));
	}
	public function count_by_bid($bid=0){
		return DB::fetch_all('select avg(k) k,avg(h) h,avg(f) f from %t where status=0 and rubbish=0 and bid=%d and ask=0',array($this->_table,$bid));
	}
	public function count_avg_by_bid($bid=0){
		return DB::result_first('select avg(avg) from %t where status=0 and rubbish=0 and bid=%d and ask=0 and uid!=0 and upid=0',array($this->_table,$bid));
	}
	public function count_by_bid_all($bid=0){
		return DB::result_first('select count(*) from %t where status=0 and rubbish=0 and bid=%d',array($this->_table,$bid));
	}
	public function fetch_all_by_bid_page($bid=0,$start=0,$perpage=0){
		return DB::fetch_all('select * from %t where status=0 and rubbish=0 and bid=%d order by id desc limit %d,%d ',array($this->_table,$bid,$start,$perpage));
	}
	public function fetch_all_by_dianping($start=0,$perpage=0){
		return DB::fetch_all('select * from %t where status=0 and rubbish=0 order by id desc limit %d,%d ',array($this->_table,$start,$perpage));
	}
}




?>