<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljbd_order extends discuz_table {

    public function __construct() {

        $this->_table = 'aljbd_order';
        $this->_pk = 'orderid';

        parent::__construct(); /*dism��taobao��com*/
    }
	public function fetch_all_by_uid($uid=0){
		return DB::fetch_all('select * from %t where uid=%d order by submitdate desc',array($this->_table,$uid));
	}
	public function fetch_all_by_sid($sid=0,$start=0,$perpage=0){
		return DB::fetch_all('select * from %t where sid=%d group by uid  order by submitdate desc limit %d,%d',array($this->_table,$sid,$start,$perpage));
	}
	public function update_status_by_orderid($orderid=0){
		DB::query('update %t set status=3 where orderid=%s',array($this->_table,$orderid));
	}
}
//From: Dism_taobao_com
?>