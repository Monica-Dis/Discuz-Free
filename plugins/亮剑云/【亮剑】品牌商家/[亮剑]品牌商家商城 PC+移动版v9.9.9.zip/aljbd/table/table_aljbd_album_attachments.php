<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljbd_album_attachments extends discuz_table{
	public function __construct() {

			$this->_table = 'aljbd_album_attachments';
			$this->_pk    = 'id';

			parent::__construct(); /*dism��taobao��com*/
	}
	public function count_by_uid_bid($uid=0,$bid=0,$rubbish=0){
		$conn=' where 1';
		$where[]=$this->_table;
		$where[]=$rubbish;
		$conn.=' and rubbish=%d';
		if($uid){
			$where[]=$uid;
			$conn.=' and uid=%d';
		}
		if($bid){
			$where[]=$bid;
			$conn.=' and aid=%d';
		}
		return DB::result_first('select count(*) from %t '.$conn,$where);
	}
	public function fetch_all_by_uid_bid($uid=0,$bid=0,$start=0,$perpage=0,$rubbish=0){
		$conn=' where 1';
		$where[]=$this->_table;
		$where[]=$rubbish;
		$conn.=' and rubbish=%d';
		if($uid){
			$where[]=$uid;
			$conn.=' and uid=%d';
		}
		if($bid){
			$where[]=$bid;
			$conn.=' and aid=%d';
		}
		$conn.=' order by id DESC';
		if(isset($start)&&isset($perpage)){
			$where[]=$start;
			$where[]=$perpage;
			$conn.=' limit %d,%d';
		}
		return DB::fetch_all('select * from %t '.$conn,$where);
	}
	public function fetch_all_by_uid_bid_view($uid=0,$bid=0,$start=0,$perpage=0,$rubbish=0){
		$conn=' where 1';
		$where[]=$this->_table;
		$where[]=$rubbish;
		$conn.=' and rubbish=%d';
		if($uid){
			$where[]=$uid;
			$conn.=' and uid=%d';
		}
		if($bid){
			$where[]=$bid;
			$conn.=' and bid=%d';
		}
		$conn.=' order by view desc';
		if(isset($start)&&isset($perpage)){
			$where[]=$start;
			$where[]=$perpage;
			$conn.=' limit %d,%d';
		}
		return DB::fetch_all('select * from %t '.$conn,$where);
	}
	public function update_view_by_gid($gid=0){
		return DB::query('update %t set view=view+1 where id=%d',array($this->_table,$gid));
	}
	public function fetch_all_by_status($con=''){
		return DB::fetch_all("select * from %t $con ",array($this->_table));
	}
	public function conut_by_aid($aid=0){
		return DB::result_first("select count(*) from %t where aid=%d ",array($this->_table,$aid));
	}
}




?>