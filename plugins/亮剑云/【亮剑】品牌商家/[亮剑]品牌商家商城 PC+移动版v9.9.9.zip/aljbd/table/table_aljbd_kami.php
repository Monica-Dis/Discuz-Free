<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljbd_kami extends discuz_table {

    public function __construct() {

        $this->_table = 'aljbd_kami';
        $this->_pk = 'mid';

        parent::__construct(); /*dism��taobao��com*/
    }
}
//From: Dism_taobao_com
?>