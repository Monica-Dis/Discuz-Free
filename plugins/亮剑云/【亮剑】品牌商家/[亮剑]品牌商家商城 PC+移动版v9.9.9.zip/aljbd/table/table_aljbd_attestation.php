<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljbd_attestation extends discuz_table {

    public function __construct() {

        $this->_table = 'aljbd_attestation';
        $this->_pk = 'bid';

        parent::__construct(); /*dism��taobao��com*/
    }
	public function count_by_status($status=0,$search=''){
		if($search){
			$con='%'.addcslashes($search, '%_').'%';
			
			$where.=" and name like %s";
		}
		return DB::result_first("select count(*) from %t where sign=%d $where",array($this->_table,$status,$con));
	}
    public function fetch_all_by_status($status=0,$start=0,$perpage=0,$search=''){
		if($search){
			$con='%'.addcslashes($search, '%_').'%';
			
			$where.=" and name like %s";
		}
		if($con){
			return DB::fetch_all("select * from %t where sign=%d $where limit %d,%d",array($this->_table,$status,$con,$start,$perpage));
		}else{
			return DB::fetch_all("select * from %t where sign=%d  limit %d,%d",array($this->_table,$status,$start,$perpage));
		}
		
	}

}
//From: Dism_taobao_com
?>