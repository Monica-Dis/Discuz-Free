<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljbd_goods extends discuz_table{
	public function __construct() {

			$this->_table = 'aljbd_goods';
			$this->_pk    = 'id';

			parent::__construct(); /*dism��taobao��com*/
	}
	public function count_by_status($status=0,$uid=0,$type=0,$subtype=0,$region=0,$subregion=0,$search='',$rubbish=0,$sh_status=0,$array = array()){
		$con[]=$this->_table;
		$where='where 1 ';
		$con[]=$rubbish;
		$where.=' and rubbish=%d';
        $con[]=$sh_status;
		$where.=' and sh_status=%d';
		if(is_array($array)){
            foreach ($array as $ak => $av){
				if($av){
					if($ak == 'video_path'){
						$where.=' and '.$ak.'!=\'\'';
					}else if($ak == 'new_people'){
						$where.=' and new_price > 0';
					}else if($ak == 'nine'){
						$where.=' and price1 <= 9.9 and fare_desc = 1';
					}else if($ak == 'pt_nine'){
						$where.=' and collage_price <= 9.9 and fare_desc = 1';
					}else{
						$con[]=$av;
						$where.=' and '.$ak.'=%d';
					}
				}
            }
        }
		if($uid){
			$con[]=$uid;
			$where.=' and uid=%d';
		}
		if($status){
			$con[]=$status;
			$where.=' and sign=%d';
		}
		if($type){
			$con[]=$type;
			$where.=' and type=%d';
		}
		if($subtype){
			$con[]=$subtype;
			$where.=' and subtype=%d';
		}
		if($region){
			$con[]=$region;
			$where.=' and region=%d';
		}
		if($subregion){
			$con[]=$subregion;
			$where.=' and subregion=%d';
		}
		if($search){
			$con[]='%'.addcslashes($search, '%_').'%';
			
			$where.=" and name like %s";
		}//debug('select count(*) from %t '.$where);
		return DB::result_first('select count(*) from %t '.$where,$con);
	}
	public function count_by_status_new($status=0,$uid=0,$type=0,$subtype=0,$region=0,$subregion=0,$search='',$subtype3=0,$rubbish=0,$commodity_type=0,$array=array('sh_status'=>0),$sql=''){
		global $settings;
		$con[]=$this->_table;
		$where='where state =0';
		$con[]=$rubbish;
		$where.=' and rubbish=%d';
        $con[]=$array['sh_status'];
        $where.=' and sh_status=%d';
		if($uid){
			$con[]=$uid;
			$where.=' and uid=%d';
		}
        if($array['btypeid']){
            $con[]=$array['btypeid'];
            $where.=' and btypeid=%d';
        }
        if($array['bsubtypeid']){
            $con[]=$array['bsubtypeid'];
            $where.=' and bsubtypeid=%d';
        }
        if($array['video_path'] == 1){
            $where.=' and video_path!=\'\'';
		}
		if($array['new_people'] == 1){
            $where.=' and new_price > 0';
        }
        if($commodity_type){
            if($commodity_type == 99){
                $con[]=0;
            }else{
                $con[]=$commodity_type;
            }
            $where.=' and commodity_type=%d';
        }
		if($status){
			$con[]=$status;
			$where.=' and sign=%d';
		}
		if($type){
			$con[]=$type;
			$where.=' and type=%d';
		}
		if($subtype){
			$con[]=$subtype;
			$where.=' and subtype=%d';
		}
		if($subtype3){
			$con[]=$subtype3;
			$where.=' and subtype3=%d';
		}
		if($region){
			$con[]=$region;
			$where.=' and region=%d';
		}
		if($subregion){
			$con[]=$subregion;
			$where.=' and subregion=%d';
		}
		if($settings['displayexpiredgoods']['value']){
			$con[]=TIMESTAMP;
			$where.=' and (endtime>%d or endtime=0)';
		}
		if($search){
			if(1){
				require_once libfile('function/search');
				$srcharr = searchkey($search,"name LIKE '%{text}%'", true);
				$srchtxt = $srcharr[0];
				$sqlsrch .= $srcharr[1];
				$sql.=" $sqlsrch ";
			}else{
				$con[]='%'.addcslashes($search, '%_').'%';
			
				$where.=" and name like %s";
			}
		}//debug('select count(*) from %t '.$where);
		$con[]=$sql;
		$where.=' %i';
		return DB::result_first('select count(*) from %t '.$where,$con);
	}
	public function fetch_all_by_status($status=0,$start=0,$perpage=0,$uid=0,$type=0,$subtype=0,$region=0,$subregion=0,$order='',$search='',$rubbish=0,$sh_status=0){
		$con[]=$this->_table;
		$where='where 1 ';
		$con[]=$rubbish;
		$where.=' and rubbish=%d';
        $con[]=$sh_status;
        $where.=' and sh_status=%d';
		if($status){
			$con[]=$status;
			$where.=' and sign=%d';
		}
		if($uid){
			$con[]=$uid;
			$where.=' and uid=%d';
		}
		if($type){
			$con[]=$type;
			$where.=' and type=%d';
		}
		if($subtype){
			$con[]=$subtype;
			$where.=' and subtype=%d';
		}
		if($region){
			$con[]=$region;
			$where.=' and region=%d';
		}
		if($subregion){
			$con[]=$subregion;
			$where.=' and subregion=%d';
		}
		if($search){
			$con[]='%'.addcslashes($search, '%_').'%';
			
			$where.=" and name like %s";
		}
		if($order){
			if($order=='price1'){
				$where.=' order by '.addslashes($order).' asc';
			}else{
				$where.=' order by '.addslashes($order).' desc';
			}
			
		}else{
			$where.=' order by displayorder desc,dateline desc,view desc';
		}
		if(!empty($perpage)){
			$con[]=$start;
			$con[]=$perpage;
			$where.=' limit %d,%d';
		}
		return DB::fetch_all('select * from %t '.$where,$con);
	}
	public function fetch_all_by_status_new($status=0,$start=0,$perpage=0,$uid=0,$type=0,$subtype=0,$region=0,$subregion=0,$order='',$search='',$subtype3=0,$rubbish=0,$commodity_type=0,$array=array('sh_status'=>0),$sql=''){
		global $settings;
		$con[]=$this->_table;
		$where='where state =0';
		$con[]=$rubbish;
		$where.=' and rubbish=%d';

		$con[]=$array['sh_status'];
		$where.=' and sh_status=%d';
		if($status){
			$con[]=$status;
			$where.=' and sign=%d';
		}
        if($commodity_type){
            if($commodity_type == 99){
                $con[]=0;
            }else{
                $con[]=$commodity_type;
            }
            $where.=' and commodity_type=%d';
        }
        if(is_array($array)){
            foreach ($array as $ak => $av){
                if($av && $ak != 'sh_status'){
                    if($ak == 'video_path'){
                        $where.=' and '.$ak.'!=\'\'';
                    }else if($ak == 'new_people'){
						$where.=' and new_price > 0';
					}else if($ak == 'new_people_001'){
						$where.=' and new_price > 0 and new_price < 0.02';
					}else if($ak == 'nine'){
						$where.=' and price1 < 9.91 and fare_desc = 1';
					}else if($ak == 'pt_nine'){
						$where.=' and collage_price < 9.91 and fare_desc = 1';
					}else{
                        $con[]=$av;
                        $where.=' and '.$ak.'=%d';
                    }
                }
            }
        }

		if($uid){
			$con[]=$uid;
			$where.=' and uid=%d';
		}
		if($type){
			$con[]=$type;
			$where.=' and type=%d';
		}
		if($subtype){
			$con[]=$subtype;
			$where.=' and subtype=%d';
		}
		if($subtype3){
			$con[]=$subtype3;
			$where.=' and subtype3=%d';
		}
		if($region){
			$con[]=$region;
			$where.=' and region=%d';
		}
		if($subregion){
			$con[]=$subregion;
			$where.=' and subregion=%d';
		}
		if($settings['displayexpiredgoods']['value']){
			$con[]=TIMESTAMP;
			$where.=' and (endtime>%d or endtime=0)';
		}
		if($search){
			if(1){
				require_once libfile('function/search');
				$srcharr = searchkey($search,"name LIKE '%{text}%'", true);
				$srchtxt = $srcharr[0];
				$sqlsrch .= $srcharr[1];
				$sql.=" $sqlsrch ";
			}else{
				$con[]='%'.addcslashes($search, '%_').'%';
			
				$where.=" and name like %s";
			}
		}
		$con[]=$sql;
		$where.=' %i';
		
		if($order){
			if($order=='price1'){
				$where.=' order by '.addslashes($order).' asc';
			}else if($order=='hot'){
				$where.=' order by buyamount desc,view desc';
			}else if($order=='addtime'){
				$where.=' order by displayorder desc,id desc';
			}else if($order == 'publictime'){
				$where.= ' order by sign desc';
			}else if($order == 'favorate'){
				$where.= ' order by buyamount desc';
			}else if($order == 'totalpriceup'){
				$where.= ' order by price1 asc';
			}else if($order == 'totalpricedown'){
				$where.= ' order by price1 desc';
			}else{
				$where.=' order by '.addslashes($order).' desc';
			}
			
		}else{
			$where.=' order by displayorder desc,id desc,view desc';
		}
		if(!empty($perpage)){
			$con[]=$start;
			$con[]=$perpage;
			$where.=' limit %d,%d';
		}
		
		return DB::fetch_all('select * from %t '.$where,$con);
	}
	public function count_by_type(){
		return DB::fetch_all('select type,count(*) num from %t group by type',array($this->_table));
	}
	public function count_by_uid_bid($uid=0,$bid=0,$rubbish=0,$search='',$sh_status=0,$array=array(),$sql=''){
		$conn=' where 1';
		$where[]=$this->_table;
		$where[]=$rubbish;
		$conn.=' and rubbish=%d';
        $where[]=$sh_status;
		$conn.=' and sh_status=%d';
		if(is_array($array)){
            foreach ($array as $ak => $av){
                if($av){
                    if($ak == 'video_path'){
                        $conn.=' and '.$ak.'!=\'\'';
                    }else if($ak == 'new_people'){
						$conn.=' and new_price > 0';
					}else if($ak == 'nine'){
						$conn.=' and price1 < 9.91 and fare_desc = 1';
					}else if($ak == 'pt_nine'){
						$conn.=' and collage_price < 9.91 and fare_desc = 1';
					}else{
                        $where[]=$av;
                        $conn.=' and '.$ak.'=%d';
                    }
                }
            }
        }
		if($uid){
			$where[]=$uid;
			$conn.=' and uid=%d';
		}
		if($bid){
			$where[]=$bid;
			$conn.=' and bid=%d';
		}
        if($search){
            $where[]='%'.addcslashes($search, '%_').'%';

            $conn.=" and name like %s";
		}
		$where[] = $sql;
		return DB::result_first('select count(*) from %t '.$conn." %i",$where);
	}
    public function fetch_all_by_uid_bid($uid=0,$bid=0,$start=0,$perpage=0,$rubbish=0,$search='',$sh_status=0,$array=array(),$sql=''){
        $conn=' where 1';
        $where[]=$this->_table;
        $where[]=$rubbish;
        $conn.=' and rubbish=%d';
        $where[]=$sh_status;
        $conn.=' and sh_status=%d';
        if($uid){
            $where[]=$uid;
            $conn.=' and uid=%d';
        }
		if($_GET['admin'] !=1){
			$where[]=$array['store_id'];
        	$conn.=' and store_id=%d';
		}
        

        if(is_array($array)){
            foreach ($array as $ak => $av){
				if($av && $ak != 'store_id'){
					if($ak == 'video_path'){
						$conn.=' and '.$ak.'!=\'\'';
					}else if($ak == 'new_people'){
						$conn.=' and new_price > 0';
					}else if($ak == 'nine'){
						$conn.=' and price1 <= 9.9 and fare_desc = 1';
					}else if($ak == 'pt_nine'){
						$conn.=' and collage_price <= 9.9 and fare_desc = 1';
					}else{
						$where[]=$av;
						$conn.=' and '.$ak.'=%d';
					}
				}
            }
        }
        if($bid){
            $where[]=$bid;
            $conn.=' and bid=%d';
        }

        if($search){
            if(1){
				require_once libfile('function/search');
				$srcharr = searchkey($search,"name LIKE '%{text}%'", true);
				$srchtxt = $srcharr[0];
				$sqlsrch .= $srcharr[1];
				$sql.=" $sqlsrch ";
			}else{
				$con[]='%'.addcslashes($search, '%_').'%';
			
				$where.=" and name like %s";
			}
		}
		$conn.=" %i";
		$where[] = $sql;
        $conn.=' order by displayorder desc,id desc';
        if($perpage>0){
            $where[]=$start;
            $where[]=$perpage;
            $conn.=' limit %d,%d';
        }
		
        return DB::fetch_all('select * from %t '.$conn,$where);
    }
	public function count_by_uid_bid_new($uid=0,$bid=0,$rubbish=0,$array=array('sh_status'=>0),$sql=''){
		global $settings;
		$conn=' where state =0';
		$where[]=$this->_table;
		$where[]=$rubbish;
		$conn.=' and rubbish=%d';
        $where[]=$array['sh_status'];
        $conn.=' and sh_status=%d';
        if($array['btypeid']){
            $where[]=$array['btypeid'];
            $conn.=' and btypeid=%d';
        }

        if($array['bsubtypeid']){
            $where[]=$array['bsubtypeid'];
            $conn.=' and bsubtypeid=%d';
        }

		if($uid){
			$where[]=$uid;
			$conn.=' and uid=%d';
		}

		if($bid){
			$where[]=$bid;
			$conn.=' and bid=%d';
		}
		if($settings['displayexpiredgoods']['value']){
			$where[]=TIMESTAMP;
			$conn.=' and (endtime>%d or endtime=0)';
		}
		$where[]=$sql;
		$conn.=' %i';
		return DB::result_first('select count(*) from %t '.$conn,$where);
	}

	public function fetch_all_by_uid_bid_new($uid=0,$bid=0,$start=0,$perpage=0,$rubbish=0,$array=array('sh_status'=>0),$sql=''){
		global $settings;
		$conn=' where state =0';
		$where[]=$this->_table;
		$where[]=$rubbish;
		$conn.=' and rubbish=%d';
        $where[]=$array['sh_status'];
        $conn.=' and sh_status=%d';
        if($array['btypeid']){
            $where[]=$array['btypeid'];
            $conn.=' and btypeid=%d';
        }

        if($array['bsubtypeid']){
            $where[]=$array['bsubtypeid'];
            $conn.=' and bsubtypeid=%d';
        }
		if($uid){
			$where[]=$uid;
			$conn.=' and uid=%d';
		}
		if($bid){
			$where[]=$bid;
			$conn.=' and bid=%d';
		}
		if($settings['displayexpiredgoods']['value']){
			$where[]=TIMESTAMP;
			$conn.=' and (endtime>%d or endtime=0)';
		}
		$where[]=$sql;
		$conn.=' %i';
		$conn.=' order by displayorder desc,id desc';
		if(isset($start)&&isset($perpage)){
			$where[]=$start;
			$where[]=$perpage;
			$conn.=' limit %d,%d';
		}

		return DB::fetch_all('select * from %t '.$conn,$where);
	}
	public function fetch_all_by_uid_bid_view($uid=0,$bid=0,$start=0,$perpage=0,$rubbish=0,$sh_status=0){
		$conn=' where 1';
		$where[]=$this->_table;
		$where[]=$rubbish;
		$conn.=' and rubbish=%d';
        $where[]=$sh_status;
        $conn.=' and sh_status=%d';
		if($uid){
			$where[]=$uid;
			$conn.=' and uid=%d';
		}
		if($bid){
			$where[]=$bid;
			$conn.=' and bid=%d';
		}
		$conn.=' order by view desc';
		if(isset($start)&&isset($perpage)){
			$where[]=$start;
			$where[]=$perpage;
			$conn.=' limit %d,%d';
		}
		return DB::fetch_all('select * from %t '.$conn,$where);
	}
	public function fetch_all_by_uid_bid_view_new($uid=0,$bid=0,$start=0,$perpage=0,$rubbish=0,$sh_status=0){
		global $settings;
		$conn=' where state =0';
		$where[]=$this->_table;
		$where[]=$rubbish;
		$conn.=' and rubbish=%d';
        $where[]=$sh_status;
        $conn.=' and sh_status=%d';
		if($uid){
			$where[]=$uid;
			$conn.=' and uid=%d';
		}
		if($bid){
			$where[]=$bid;
			$conn.=' and bid=%d';
		}
		if($settings['displayexpiredgoods']['value']){
			$where[]=TIMESTAMP;
			$conn.=' and (endtime>%d or endtime=0)';
		}
		$conn.=' order by view desc';
		if(isset($start)&&isset($perpage)){
			$where[]=$start;
			$where[]=$perpage;
			$conn.=' limit %d,%d';
		}
		return DB::fetch_all('select * from %t '.$conn,$where);
	}

    public function fetch_all_by_uid_bid_view_new_buyamount($uid=0,$bid=0,$start=0,$perpage=0,$rubbish=0,$sh_status=0,$sql=''){
        global $settings;
        $conn=' where state =0';
        $where[]=$this->_table;
        $where[]=$rubbish;
        $conn.=' and rubbish=%d';
        $where[]=$sh_status;
        $conn.=' and sh_status=%d';
        if($uid){
            $where[]=$uid;
            $conn.=' and uid=%d';
        }
        if($bid){
            $where[]=$bid;
            $conn.=' and bid=%d';
        }
        if($settings['displayexpiredgoods']['value']){
            $where[]=TIMESTAMP;
            $conn.=' and (endtime>%d or endtime=0)';
		}
		$where[]=$sql;
		$conn.=' %i';
        $conn.=' order by buyamount desc,view desc';
        if(isset($start)&&isset($perpage)){
            $where[]=$start;
            $where[]=$perpage;
            $conn.=' limit %d,%d';
        }
        return DB::fetch_all('select * from %t '.$conn,$where);
    }
    public function fetch_all_by_uid_bid_view_new_displayorder($uid=0,$bid=0,$start=0,$perpage=0,$rubbish=0,$sh_status=0,$sql=''){
        global $settings;
        $conn=' where state =0';
        $where[]=$this->_table;
        $where[]=$rubbish;
        $conn.=' and rubbish=%d';
        $where[]=$sh_status;
        $conn.=' and sh_status=%d';
        if($uid){
            $where[]=$uid;
            $conn.=' and uid=%d';
        }
        if($bid){
            $where[]=$bid;
            $conn.=' and bid=%d';
        }
        if($settings['displayexpiredgoods']['value']){
            $where[]=TIMESTAMP;
            $conn.=' and (endtime>%d or endtime=0)';
		}
		$where[]=$sql;
		$conn.=' %i';
        $conn.=' order by displayorder desc,id desc';
        if(isset($start)&&isset($perpage)){
            $where[]=$start;
            $where[]=$perpage;
            $conn.=' limit %d,%d';
        }
        return DB::fetch_all('select * from %t '.$conn,$where);
    }
	public function update_view_by_gid($gid=0){
		return DB::query('update %t set view=view+1 where id=%d',array($this->_table,$gid));
	}
	public function fetch_thread_all_block($con='',$sc='',$items=0){
		return DB::fetch_all("select * from %t $con $sc limit 0,%d",array($this->_table,$items));
	}
	public function fetch_all_by_recommend($recommend=0,$start=0,$perpage=0){
		return DB::fetch_all('select * from %t where sign=%d and rubbish=0 order by displayorder desc limit %d,%d',array($this->_table,$recommend,$start,$perpage));
	}
	public function fetch_all_by_recommend_new($recommend=0,$start=0,$perpage=0,$sql=''){
		global $settings;
		if($settings['displayexpiredgoods']['value']){
			return DB::fetch_all('select * from %t where sign=%d and rubbish=0 and (endtime>%d or endtime=0) %i order by displayorder desc,id desc limit %d,%d',array($this->_table,$recommend,TIMESTAMP,$sql,$start,$perpage));
		}else{
			return DB::fetch_all('select * from %t where sign=%d and rubbish=0 %i order by displayorder desc,id desc limit %d,%d',array($this->_table,$recommend,$sql,$start,$perpage));
		}
		
	}
	public function update_num_by_id($id=0,$num=0) {
		if(is_file(DISCUZ_ROOT.'source/plugin/aljayy/controller/aljayy/goods.php')){
			$aljayy = DB::fetch_first('select * from %t where goods_id = %d', array('aljayy_goods', $id));
			if($aljayy['reduction_method'] == 'bypayment' && ($_GET['act'] == 'cartsubmit' || $_GET['act'] == 'buysubmit')){
				return false;
			}
		}		 
        return DB::query('update %t set amount=amount-%d where id=%d', array($this->_table,$num,$id));
    }
    public function update_num2_by_id($id=0,$num=0) {
        return DB::query('update %t set buyamount=buyamount+%d where id=%d', array($this->_table,$num,$id));
    }
	public function update_displayorder_by_id($id=0,$displayorder=0){
		return DB::query('update %t set displayorder=%d where id=%d',array($this->_table,$displayorder,$id));
	}
}




?>