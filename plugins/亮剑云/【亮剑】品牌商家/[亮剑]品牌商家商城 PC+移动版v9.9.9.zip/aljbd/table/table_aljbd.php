<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljbd extends discuz_table{
	public function __construct() {

			$this->_table = 'aljbd';
			$this->_pk    = 'id';

			parent::__construct(); /*dism��taobao��com*/
	}
	public function count_by_status_rec($status=0,$uid=0,$type=0,$subtype=0,$region=0,$subregion=0,$search='',$so=0,$region1=0,$rubbish=0){

		$con[]=$this->_table;
		if($so){
			$where='where 1 and recommend = 1 and x != 0 and y != 0 ';
		}else{
			$where='where 1 and recommend = 1';
		}
		$con[]=$rubbish;
		$where.=' and rubbish=%d';
		if($uid){
			$con[]=$uid;
			$where.=' and uid=%d';
		}
		if($status||$status=='0'){
			$con[]=$status;
			$where.=' and status=%d';
		}
		if($type){
			$con[]=$type;
			$where.=' and type=%d';
		}
		if($subtype){
			$con[]=$subtype;
			$where.=' and subtype=%d';
		}
		if($region){
			$con[]=$region;
			$where.=' and region=%d';
		}
		if($region1){
			$con[]=$region1;
			$where.=' and region1=%d';
		}
		if($subregion){
			$con[]=$subregion;
			$where.=' and subregion=%d';
		}

		if($search){
			$con[]='%'.addcslashes($search, '%_').'%';

			$where.=" and name like %s";
		}
		return DB::result_first('select count(*) from %t '.$where,$con);
	}
	public function count_by_status($status=0,$uid=0,$type=0,$subtype=0,$region=0,$subregion=0,$search=0,$so=0,$region1=0,$subtype3=0,$y='',$x='',$rubbish=0){

		$con[]=$this->_table;

		if($so){
			$where='where 1 and x != 0 and y != 0 ';
		}else{
			$where='where 1 ';
		}
		$con[]=$rubbish;
		$where.=' and rubbish=%d';

		if($uid){
			$con[]=$uid;
			$where.=' and uid=%d';
		}
		if($status||$status=='0'){
			$con[]=$status;
			$where.=' and status=%d';
		}
		if($type){
			$con[]=$type;
			$where.=' and type=%d';
		}
		if($subtype){
			$con[]=$subtype;
			$where.=' and subtype=%d';
		}
		if($subtype3){
			$con[]=$subtype3;
			$where.=' and subtype3=%d';
		}
		if($region){
			$con[]=$region;
			$where.=' and region=%d';
		}
		if($region1){
			$con[]=$region1;
			$where.=' and region1=%d';
		}
		if($subregion){
			$con[]=$subregion;
			$where.=' and subregion=%d';
		}

		if($search){
			$con[]='%'.addcslashes($search, '%_').'%';
			$con[]='%'.addcslashes($search, '%_').'%';
			$con[]='%'.addcslashes($search, '%_').'%';
			$where.=" and (name like %s or addr like %s or other like %s)";
		}
		return DB::result_first('select count(*) from %t '.$where,$con);
	}
	public function fetch_all_by_recommend($recommend=0,$start=0,$perpage=0){
		return DB::fetch_all('select * from %t where recommend=%d and rubbish=0 and status=1 order by displayorder desc limit %d,%d',array($this->_table,$recommend,$start,$perpage));
	}
	public function fetch_all_by_view($recommend=0,$start=0,$perpage=0,$order=''){
		return DB::fetch_all('select * from %t where status=%d  and rubbish=0 order by '.addslashes($order).' desc limit %d,%d',array($this->_table,$recommend,$start,$perpage));
	}

	public function fetch_all_by_status($status=0,$start=0,$perpage=0,$uid=0,$type=0,$subtype=0,$region=0,$subregion=0,$order=0,$search='',$so=0,$region1=0,$subtype3=0,$y='',$x='',$rubbish=0){
		global $_G;
		$con[]=$this->_table;
		if($so){
			$where='where 1 and x != 0 and y != 0 ';
		}else{
			$where='where 1 ';
		}
		$con[]=$rubbish;
		$where.=' and rubbish=%d';

		if(isset($status)){
			$con[]=$status;
			$where.=' and status=%d';
		}
		if($uid){
			$con[]=$uid;
			$where.=' and uid=%d';
		}
		if($type){
			$con[]=$type;
			$where.=' and type=%d';
		}
		if($subtype){
			$con[]=$subtype;
			$where.=' and subtype=%d';
		}
		if($subtype3){
			$con[]=$subtype3;
			$where.=' and subtype3=%d';
		}
		if($region){
			$con[]=$region;
			$where.=' and region=%d';
		}
		if($region1){
			$con[]=$region1;
			$where.=' and region1=%d';
		}
		if($subregion){
			$con[]=$subregion;
			$where.=' and subregion=%d';
		}
		if($search){
			$con[]='%'.addcslashes($search, '%_').'%';
			$con[]='%'.addcslashes($search, '%_').'%';
			$con[]='%'.addcslashes($search, '%_').'%';
			$where.=" and (name like %s or addr like %s or other like %s)";
		}

        if($y && $x) {
            //x ���� y γ��
            $latitude    = $y;//γ��
            $longitude   = $x;//����
            $lngstr = $longitude > 0 ? " - $longitude" : " + ".abs($longitude);
            $field = " *, acos(cos((x $lngstr) * 0.01745329252) * cos((y - $latitude) * 0.01745329252)) * 6371004 as distance";

            $where .= " having distance <= ".($_G['cache']['plugin']['aljlbs']['range']*1000)." order by distance ASC,displayorder asc,dateline asc,view desc";
		}else{
            $field = "*";
            if($order && $order!='comment'){
                $where.=' order by '.addslashes($order).' desc';
            }else{
                if($_G['cache']['plugin']['aljbd']['brandlistorder']){
                    $where .= ' ORDER BY recommend desc,displayorder desc,dateline desc,comment desc,view desc';
                }else{
                    $where.=' order by recommend desc,displayorder asc,dateline asc,comment desc,view desc';
                }
            }
        }
		if(!empty($perpage)){
			$con[]=$start;
			$con[]=$perpage;
			$where.=' limit %d,%d';
		}

		return DB::fetch_all('select '.$field.' from %t '.$where,$con);
	}
	public function fetch_all_by_status_rec($status=0,$start=0,$perpage=0,$uid=0,$type=0,$subtype=0,$region=0,$subregion=0,$order=0,$search='',$so=0,$region1=0,$rubbish=0){
        global $_G;
		$con[]=$this->_table;
		if($so){
			$where='where 1 and recommend = 1 and x != 0 and y != 0 ';
		}else{
			$where='where 1 and recommend = 1 ';
		}
		$con[]=$rubbish;
		$where.=' and rubbish=%d';
		if(isset($status)){
			$con[]=$status;
			$where.=' and status=%d';
		}
		if($uid){
			$con[]=$uid;
			$where.=' and uid=%d';
		}
		if($type){
			$con[]=$type;
			$where.=' and type=%d';
		}
		if($subtype){
			$con[]=$subtype;
			$where.=' and subtype=%d';
		}
		if($region){
			$con[]=$region;
			$where.=' and region=%d';
		}
		if($region1){
			$con[]=$region1;
			$where.=' and region1=%d';
		}
		if($subregion){
			$con[]=$subregion;
			$where.=' and subregion=%d';
		}
		if($search){
			$con[]='%'.addcslashes($search, '%_').'%';

			$where.=" and name like %s";
		}
		if($order && $order!='comment'){
			$where.=' order by '.addslashes($order).' desc';
		}else{

            if($_G['cache']['plugin']['aljbd']['brandlistorder']){
                $where .= ' ORDER BY recommend desc,displayorder desc,dateline asc,comment desc,view desc';
            }else{
                $where.=' order by recommend desc,displayorder asc,dateline asc,comment desc,view desc';
            }
		}
		if(!empty($perpage)){
			$con[]=$start;
			$con[]=$perpage;
			$where.=' limit %d,%d';
		}
		return DB::fetch_all('select * from %t '.$where,$con);
	}
	public function update_status_by_id($id=0,$status=0){
		return DB::query('update %t set status=%d where id=%d',array($this->_table,$status,$id));
	}
	public function update_displayorder_by_id($id=0,$displayorder=0){
		return DB::query('update %t set displayorder=%d where id=%d',array($this->_table,$displayorder,$id));
	}
	public function update_recommend_by_id($id=0,$recommend=0){
		return DB::query('update %t set recommend=%d where id=%d',array($this->_table,$recommend,$id));
	}
	public function fetch_by_uid($uid=0){
		return DB::fetch_first('select * from %t where uid=%d  and rubbish=0',array($this->_table,$uid));
	}
	public function update_view_by_bid($bid=0){
		return DB::query('update %t set view=view+1 where id=%d',array($this->_table,$bid));
	}
	public function update_comment_by_bid($bid=0){
		return DB::query('update %t set comment=comment+1 where id=%d',array($this->_table,$bid));
	}
	public function count_by_type(){
		return DB::fetch_all('select type,count(*) num from %t where status=1 and rubbish=0 group by type',array($this->_table));
	}
	public function count_by_subtype($type=0){
		return DB::fetch_all('select subtype,count(*) num from %t where status=1 and rubbish=0 and type=%d group by subtype',array($this->_table,$type));
	}
	public function count_by_region(){
		return DB::fetch_all('select region,count(*) num from %t where status=1 and rubbish=0 group by region',array($this->_table));
	}
	public function search_by_subject(){
		return DB::fetch_all('select region,count(*) num from %t where status=1 and rubbish=0 group by region',array($this->_table));
	}
	public function fetch_thread_all_block($con='',$sc='',$items=0){
		return DB::fetch_all("select * from %t $con $sc limit 0,%d",array($this->_table,$items));
	}
}




?>
