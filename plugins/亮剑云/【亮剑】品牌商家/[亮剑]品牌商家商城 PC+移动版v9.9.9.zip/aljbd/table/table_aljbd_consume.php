<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljbd_consume extends discuz_table{
	public function __construct() {

			$this->_table = 'aljbd_consume';
			$this->_pk    = 'id';

			parent::__construct(); /*dism��taobao��com*/
	}
	public function count_by_uid_bid($uid=0,$bid=0,$type=0,$subtype=0,$search='',$rubbish=0,$status=0){
		global $_G;
		if($_G['cache']['plugin']['aljtyh']){
			$conn=' where store_id=0';
		}else{
			$conn=' where 1';
		}
		
		$where[]=$this->_table;
		$where[]=$rubbish;
		$conn.=' and rubbish=%d';
        $where[]=$status;
		$conn.=' and status=%d';
		if($_G['cache']['plugin']['aljsyh']['is_aljsyh'] && $_GET['act'] != 'consumelist'){
			$conn.=' and draw_channel=0';
		}
		if($uid){
			$where[]=$uid;
			$conn.=' and uid=%d';
		}
		if($bid){
			$where[]=$bid;
			$conn.=' and bid=%d';
		}
		if($type){
			$where[]=$type;
			$conn.=' and type=%d';
		}
		if($subtype){
			$where[]=$subtype;
			$conn.=' and subtype=%d';
		}
		if($search){
			$where[]='%'.addcslashes($search, '%_').'%';
			
			$conn.=" and subject like %s";
		}

		if($_G['cache']['plugin']['aljsyh']['is_adddp'] && $_GET['act'] != 'consumelist'){
            $where[]=9;
			$conn.=' and coupon_type!=%d';
		}
		if($_G['cache']['plugin']['aljsyh']['is_aljtcc'] && $_GET['act'] != 'consumelist'){
            $where[]=10;
            $conn.=' and coupon_type!=%d';
		}
		if($_G['cache']['plugin']['aljsyh']['is_aljpyh'] && $_GET['act'] != 'consumelist'){
            $where[]=7;
            $conn.=' and coupon_type!=%d';
        }
        if($_G['cache']['plugin']['aljsyh']['is_endtime'] && $_GET['act'] != 'consumelist'){
            $where[]=TIMESTAMP;

            $conn.=' and (end>%d or end=0)';
        }
		return DB::result_first('select count(*) from %t '.$conn,$where);
	}
	public function fetch_all_by_uid_bid($uid=0,$bid=0,$start=0,$perpage=0,$type=0,$subtype=0,$search='',$rubbish=0,$status=0){
        global $_G;
		if($_G['cache']['plugin']['aljtyh']){
			$conn=' where store_id=0';
		}else{
			$conn=' where 1';
		}
		$where[]=$this->_table;
		$where[]=$rubbish;
		$conn.=' and rubbish=%d';
        $where[]=$status;
		$conn.=' and status=%d';
		if($_G['cache']['plugin']['aljsyh']['is_aljsyh'] && $_GET['act'] != 'consumelist' && $_GET['act'] != 'getconsume' && $_GET['adminact'] != 'getconsume'){
			$conn.=' and draw_channel=0';
		}
		if($uid){
			$where[]=$uid;
			$conn.=' and uid=%d';
		}
		if($bid){
			$where[]=$bid;
			$conn.=' and bid=%d';
		}
		if($type){
			$where[]=$type;
			$conn.=' and type=%d';
		}
		if($subtype){
			$where[]=$subtype;
			$conn.=' and subtype=%d';
		}
		if($search){
			$where[]='%'.addcslashes($search, '%_').'%';
			
			$conn.=" and subject like %s";
		}
        if($_G['cache']['plugin']['aljsyh']['is_adddp'] && $_GET['act'] != 'consumelist'){
            $where[]=9;
            $conn.=' and coupon_type!=%d';
		}
		if($_G['cache']['plugin']['aljsyh']['is_aljtcc'] && $_GET['act'] != 'consumelist'){
            $where[]=10;
            $conn.=' and coupon_type!=%d';
		}
		if($_G['cache']['plugin']['aljsyh']['is_aljpyh'] && $_GET['act'] != 'consumelist'){
            $where[]=7;
            $conn.=' and coupon_type!=%d';
        }
        if($_G['cache']['plugin']['aljsyh']['is_endtime'] && $_GET['act'] != 'consumelist'){
            $where[]=TIMESTAMP;

            $conn.=' and (end>%d or end=0)';
        }
		$conn.=' order by id desc';
		if($start&&$perpage){
			$where[]=$start;
			$where[]=$perpage;
			$conn.=' limit %d,%d';
		}
		
		return DB::fetch_all('select * from %t '.$conn,$where);
	}
	public function fetch_all_by_uid_bid_view($uid=0,$bid=0,$start=0,$perpage=0,$rubbish=0,$status=0){
		$conn=' where 1';
		$where[]=$this->_table;
		$where[]=$rubbish;
        $conn.=' and rubbish=%d';
        $where[]=$status;
		$conn.=' and status=%d';
		if($_G['cache']['plugin']['aljsyh']['is_aljsyh']){
			$conn.=' and draw_channel=0';
		}
		if($uid){
			$where[]=$uid;
			$conn.=' and uid=%d';
		}
		if($bid){
			$where[]=$bid;
			$conn.=' and bid=%d';
		}
		$conn.=' order by view desc';
		if($start&&$perpage){
			$where[]=$start;
			$where[]=$perpage;
			$conn.=' limit %d,%d';
		}
		return DB::fetch_all('select * from %t '.$conn,$where);
	}
	public function update_view_by_gid($gid=0){
		return DB::query('update %t set view=view+1 where id=%d',array($this->_table,$gid));
	}
	public function fetch_thread_all_block($con='',$sc='',$items=0){
		return DB::fetch_all("select * from %t $con $sc limit 0,%d",array($this->_table,$items));
	}
	public function count_by_type(){
        global $_G;
        $conn=' where 1';
        $where[]=$this->_table;
        $where[]=0;
		$conn.=' and rubbish=%d';
		if($_G['cache']['plugin']['aljsyh']['is_aljsyh']){
			$conn.=' and draw_channel=0';
		}
        if($_G['cache']['plugin']['aljsyh']['is_adddp']){
            $where[]=9;
            $conn.=' and coupon_type!=%d';
		}
		if($_G['cache']['plugin']['aljsyh']['is_aljtcc'] && $_GET['act'] != 'consumelist'){
            $where[]=10;
            $conn.=' and coupon_type!=%d';
		}
		if($_G['cache']['plugin']['aljsyh']['is_aljpyh'] && $_GET['act'] != 'consumelist'){
            $where[]=7;
            $conn.=' and coupon_type!=%d';
        }
        if($_G['cache']['plugin']['aljsyh']['is_endtime']){
            $where[]=TIMESTAMP;

            $conn.=' and (end>%d or end=0)';
        }
		return DB::fetch_all('select type,count(*) num from %t '.$conn.' group by type',$where);
	}
	public function fetch_all_by_recommend($recommend=0,$start=0,$perpage=0){
        global $_G;
		if($_G['cache']['plugin']['aljtyh']){
			$conn=' where store_id=0';
		}else{
			$conn=' where 1';
		}
        $where[]=$this->_table;
        $where[]=0;
        $conn.=' and rubbish=%d';
        $where[]=$recommend;
        $conn.=' and sign=%d';
        $where[]=0;
		$conn.=' and status=%d';
		if($_G['cache']['plugin']['aljsyh']['is_aljsyh']){
			$conn.=' and draw_channel=0';
		}
        if($_G['cache']['plugin']['aljsyh']['is_adddp']){
            $where[]=9;
            $conn.=' and coupon_type!=%d';
		}
		if($_G['cache']['plugin']['aljsyh']['is_aljtcc'] && $_GET['act'] != 'consumelist'){
            $where[]=10;
            $conn.=' and coupon_type!=%d';
		}
		if($_G['cache']['plugin']['aljsyh']['is_aljpyh'] && $_GET['act'] != 'consumelist'){
            $where[]=7;
            $conn.=' and coupon_type!=%d';
        }
        if($_G['cache']['plugin']['aljsyh']['is_endtime']){
            $where[]=TIMESTAMP;
            $conn.=' and (end>%d or end=0)';
        }
        $conn.=' order by view desc';
        if($start&&$perpage){
            $where[]=$start;
            $where[]=$perpage;
            $conn.=' limit %d,%d';
        }
		return DB::fetch_all('select * from %t '.$conn,$where);
	}
}




?>