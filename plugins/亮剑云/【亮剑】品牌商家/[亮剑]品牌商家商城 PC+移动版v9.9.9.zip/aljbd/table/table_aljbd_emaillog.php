<?php
/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_plugin_lj_exam.php liangjian $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljbd_emaillog extends discuz_table
{
	public function __construct() {

		$this->_table = 'aljbd_emaillog';
		$this->_pk    = 'id';

		parent::__construct(); /*dism��taobao��com*/
	}
}




?>