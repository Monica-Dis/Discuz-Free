
function b() {
    h = lj_jq(window).height();
    t = lj_jq(document).scrollTop();
    if (t > h) {
        lj_jq('#gotop').show();
    } else {
        lj_jq('#gotop').hide();
    }
}
lj_jq(document).ready(function (e) {

    lj_jq(".city").hover(
  function () {
      lj_jq(".citymain").css('display', 'block')
      lj_jq(this).addClass("W_arrowhov");
  },
  function () {
      lj_jq(".citymain").css('display', 'none')
      lj_jq(this).removeClass("W_arrowhov");
  }
);
    lj_jq(".search-item").hover(
  function () {
      lj_jq(".search-list").css('display', 'block')
      lj_jq(this).addClass("W_arrowhov");
  },
  function () {
      lj_jq(".search-list").css('display', 'none')
      lj_jq(this).removeClass("W_arrowhov");
  }
);

  lj_jq(".search-list li a").click(function () {
      lj_jq("#typevalue").html(lj_jq(this).html());
      lj_jq(".search-list").css('display', 'none')
      lj_jq(this).removeClass("W_arrowhov");
    });


    lj_jq("body").append('<div id="tbox"><a id="gotop" title="\u56de\u9876\u90e8" href="javascript:void(0)"></a></div>');
    b();
    lj_jq('#gotop').click(function () {
        lj_jq(document).scrollTop(0);
    })
});
lj_jq(window).scroll(function (e) {
    b();
})
