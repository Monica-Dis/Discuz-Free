<?php

/*
 * 主页：http://t.cn/Aiux14ti
 * 联系QQ:467783778
 *
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
	showmessage(lang('plugin/aljbd','sc2'), '', array(), array('login' => true));
}

$_GET=dhtmlspecialchars($_GET);
$num = intval($_GET['num']);
$settings=C::t('#aljbd#aljbd_setting')->range();
$shop=C::t('#aljbd#aljbd_goods')->fetch($_GET['sid']);

$orderid = dgmdate(TIMESTAMP, 'YmdHis').random(18);
if(C::t('#aljbd#aljbd_order')->fetch($orderid)) {
	showmessage('credits_addfunds_order_invalid', '', array(), array('showdialog' => 1, 'showmsg' => true, 'closetime' => true));
}

if(empty($_G['uid'])){
	showmessage(lang('plugin/aljbd','sc2'), '', array(), array('login' => true));
}

if ($_GET['formhash'] != formhash() || !submitcheck('formhash', 1) || preg_replace("/https?:\/\/([^\:\/]+).*/i", "\\1", $_SERVER['HTTP_REFERER']) != preg_replace("/([^\:]+).*/", "\\1", $_SERVER['HTTP_HOST'])) {
	debug('Access Denied!');
}

$shop = C::t('#aljbd#aljbd_goods')->fetch($_GET['sid']);

if (empty($num)) {
	showmessage(lang('plugin/aljbd','sc16'));
}
if ($shop['amount'] < $num) {
	showmessage(lang('plugin/aljbd','sc17'));
}

if (TIMESTAMP > $shop['endtime'] && !empty($shop['endtime'])) {
	echo showmessage(lang('plugin/aljbd','sc19'));
	exit;
}

C::t('#aljbd#aljbd_goods')->update_num_by_id($_GET['sid'],$num);

$allattrs = C::t('#aljbd#aljbd_attr') -> range();
foreach($_GET['typename'] as $v){
	$attrs[]=$allattrs[$v]['content'];
}
$attrs = implode(',',$attrs);
//手机支付宝支付为payment=2
C::t('#aljbd#aljbd_order')->insert(array(
	'orderid' => $orderid,
	'status' => '1',
	'uid' => $_G['uid'],
	'username' => $_G['username'],
	'sid' => $_GET['sid'],
	'stitle' => $shop['name'],
	'amount' => $num,
	'price' => $shop['price1'],
	'submitdate' => $_G['timestamp'],
	'remarks' => $attrs.$_GET['remarks'],
	'payment' => 2,
));

$subject = $shop['name'];
$subject = g2u($subject);
$notify_url = $_G['siteurl'].'source/plugin/aljbd/pay/notify.php';
$params = array(
    'body' => $subject,
    'subject' => $subject,
    'out_trade_no' => $orderid,
    'total_fee' => $shop['price1']*$num,
    'notify_url' => $notify_url,
);
$params['return_url'] = $_G['siteurl'].'/plugin.php?id=aljbd&act=orderlist';
$params['show_url'] = $_G['siteurl'].'/plugin.php?id=aljbd&act=orderlist';
$alipayurl = alipay($params);
//dheader("location: ".$alipayurl);
echo '<script>location.href="'.$alipayurl.'";</script>';
exit;
function g2u($a) {
   return is_array($a) ? array_map('g2u', $a) : diconv($a, CHARSET, 'UTF-8');
}

function u2g($a) {
	return is_array($a) ? array_map('u2g', $a) : diconv($a, 'UTF-8', CHARSET);
}
function alipay($parameter){
    global $_G,$config,$settings;
    if($_G['mobile']) {
        $parameter['service'] = "alipay.wap.create.direct.pay.by.user";
    }else {
        $parameter['service'] = "create_direct_pay_by_user";
    }
    $parameter['partner'] = trim($settings['ec_partner']['value']);
    $parameter['seller_id'] = trim($settings['ec_partner']['value']);
    $parameter['payment_type'] = 1;
    $parameter['_input_charset'] = 'utf8';
    ksort($parameter);
    reset($parameter);
    $parameter['sign'] = getAlipaySign($parameter,$settings['ec_securitycode']['value']);
    $parameter['sign_type'] = 'MD5';

    return  'https://mapi.alipay.com/gateway.do?'.formatBizQueryParaMap($parameter,true);
}
function getAlipaySign($Obj,$apikey=''){
    foreach ($Obj as $k => $v){
        if($k == "sign" || $k == "sign_type" || $v == ""){
            continue;
        }else{
            $parameters[$k] = $v;
        }
    }
    ksort($parameters);
    $string = formatBizQueryParaMap($parameters);
    $string = $string.$apikey;
    $string = md5($string);
    return $string;
}
function formatBizQueryParaMap($paraMap, $urlencode=false){
    $buff = "";
    ksort($paraMap);
    foreach ($paraMap as $k => $v)
    {
        if($urlencode)
        {
            $v = urlencode($v);
        }
        $buff .= $k . "=" . $v . "&";
    }
    $reqPar='';
    if (strlen($buff) > 0)
    {
        $reqPar = substr($buff, 0, strlen($buff)-1);
    }
    return $reqPar;
}
?>
