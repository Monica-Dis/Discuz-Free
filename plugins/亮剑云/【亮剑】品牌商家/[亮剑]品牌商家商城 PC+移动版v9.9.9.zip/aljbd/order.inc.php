<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$pluginid='aljbd';
if(!isset($_G['cache']['plugin'])) {
	loadcache('plugin');
}
$plugin = DB::fetch_first('select * from %t where identifier = %s', array('common_plugin', 'aljhtx'));
if(empty($plugin)){
    cpmsg('&#35831;&#20808;&#23433;&#35013;&#21830;&#23478;&#21161;&#25163;&#25554;&#20214;');
}
$plugin = DB::fetch_first('select * from %t where identifier = %s and available=1', array('common_plugin', 'aljhtx'));
if(empty($plugin)){
    cpmsg('&#35831;&#20808;&#21551;&#29992;&#21830;&#23478;&#21161;&#25163;&#25554;&#20214;');
}
if($_G['cache']['plugin']['aljht']['on']){
	echo '<iframe style="width:100%;height:100%;min-height:760px;border:none;" src="plugin.php?id=aljhtx&c=aljbd&a=order&type=4&ajax=yes&dzAdmin=1"></iframe>';
	exit;
}
if($_GET['cart']){
	$url='&cart='.$_GET['cart'];
}
if($_GET['act'] == 'wuliu'){
	if(submitcheck('formhash')){
		
			if(C::t('#aljbd#aljbd_wuliu')->fetch($_GET['orderid'])){
				C::t('#aljbd#aljbd_wuliu')->update($_GET['orderid'],array(
					'companyname' => $_GET['companyname'],
					'worderid' => $_GET['worderid'],
					'updatetime' => TIMESTAMP,
				));
				C::t('#aljbd#aljbd_order')->update_status_by_orderid($_GET['orderid']);
				cpmsg(lang('plugin/aljbd','sc1'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljbd&pmod=order'.$url, 'succeed');
			}else{
				C::t('#aljbd#aljbd_wuliu')->insert(array(
					'orderid' => $_GET['orderid'],
					'type' => 1,
					'companyname' => $_GET['companyname'],
					'worderid' => $_GET['worderid'],
					'dateline' => TIMESTAMP,
				));
				C::t('#aljbd#aljbd_order')->update_status_by_orderid($_GET['orderid']);
				cpmsg(lang('plugin/aljbd','sc1'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljbd&pmod=order'.$url, 'succeed');
			}
		
	}else{
		$wuliu = C::t('#aljbd#aljbd_wuliu')->fetch($_GET['orderid']);
		include template('aljbd:wuliu');
	}
} else if($_GET['act'] == 'delete'){
	
	C::t('#aljbd#aljbd_order')->delete($_GET['orderid']);
	
	cpmsg(lang('plugin/aljbd','sc7'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljbd&pmod=order'.$url, 'succeed');
} else{
	
	if($_G['cache']['plugin']['aljgwc'][$pluginid]){
		$tips = '&#36141;&#29289;&#36710;&#26032;&#35746;&#21333;&#21069;&#24448;&#36141;&#29289;&#36710;&#26597;&#30475; <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljgwc&pmod=order" style="color:red;">&#28857;&#20987;&#21069;&#24448;</a>';
	}
	$currpage=$_GET['page']?$_GET['page']:1;
	$perpage=10;
	$num=C::t('#aljbd#aljbd_order')->count();
	$start=($currpage-1)*$perpage;
	$orderlist=C::t('#aljbd#aljbd_order')->range($start,$perpage,'desc');
	$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljbd&pmod=order'.$url, 0, 11, false, false);
	include template('aljbd:adminorder');
}
//From: Dism_taobao_com
?>