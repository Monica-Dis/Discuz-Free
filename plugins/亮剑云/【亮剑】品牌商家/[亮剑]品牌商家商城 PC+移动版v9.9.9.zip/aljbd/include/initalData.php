<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');
foreach(DB::fetch_all('select * from %t',array('common_plugin')) as $cpv){
    $cparray[$cpv['identifier']] = $cpv;
}
//PC������ʽ
if(!C::t('#aljbd#aljbd_setting')->fetch('pc_header_css')){
    $pc_header_css = '<style>body{font: 12px/1.5 Tahoma,Helvetica,"SimSun",sans-serif;}</style>';

    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'pc_header_css','value'=>$pc_header_css));
}
//pc��ҳ������
if(!C::t('#aljbd#aljbd_setting')->fetch('HomePageShortcut')){
    $HomePageShortcut = 'source/plugin/aljbd/template/index/img/order.png|plugin.php?id=aljbd&act=orderlist|&#25105;&#30340;&#35746;&#21333;
source/plugin/aljbd/template/index/img/address.png|#|&#33258;&#23450;&#20041;
source/plugin/aljbd/template/index/img/rz.png|plugin.php?id=aljbd&act=attend|&#30003;&#35831;&#20837;&#39547;
source/plugin/aljbd/images/sj/footer/cart.png|plugin.php?id=aljbd&act=goods|&#21830;&#21697;
source/plugin/aljbd/template/index/img/consume.png|#|&#33258;&#23450;&#20041;
source/plugin/aljbd/template/index/img/notice.png|#|&#33258;&#23450;&#20041;';

    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'HomePageShortcut','value'=>$HomePageShortcut));
}
//PC��ҳģ��1����
if(!C::t('#aljbd#aljbd_setting')->fetch('HomePageModuleTitle_1')){
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'HomePageModuleTitle_1','value'=>'&#28909;&#38376;&#27963;&#21160;'));
}
//PC��ҳģ��1����
if(!C::t('#aljbd#aljbd_setting')->fetch('HomePageModuleContent_1')){
    $HomePageModuleContent_1 = '&#26426;&#19981;&#31163;&#25163;&#32;&#183;&#32;|&#25163;&#26426;&#24515;&#27700;&#23574;&#36135;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_1.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_2.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_3.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_4.jpg|//dism.taobao.com/?@aljbd.plugin
&#32477;&#39280;&#20339;&#20154;&#32;&#183;&#32;|&#25105;&#30340;&#39280;&#30028;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_5.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_6.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_7.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_8.jpg|//dism.taobao.com/?@aljbd.plugin
&#34892;&#36208;&#19975;&#37324;&#32;&#183;&#32;|&#25143;&#22806;&#35013;&#22791;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_9.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_10.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_11.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_12.jpg|//dism.taobao.com/?@aljbd.plugin
&#30246;&#25104;&#38378;&#30005;&#32;&#183;&#32;|&#36816;&#21160;&#20581;&#32654;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_13.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_14.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_15.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_16.jpg|//dism.taobao.com/?@aljbd.plugin
&#32477;&#22320;&#27714;&#29983;&#32;&#183;&#32;|&#24102;&#20320;&#21507;&#40481;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_17.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_18.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_19.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_20.jpg|//dism.taobao.com/?@aljbd.plugin
&#21150;&#20844;&#21161;&#25163;&#32;&#183;&#32;|&#21150;&#20844;&#23460;&#22909;&#29289;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_21.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_22.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_23.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod1_24.jpg|//dism.taobao.com/?@aljbd.plugin';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'HomePageModuleContent_1','value'=>$HomePageModuleContent_1));
}
//PC��ҳģ��2����
if(!C::t('#aljbd#aljbd_setting')->fetch('HomePageModuleTitle_2')){
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'HomePageModuleTitle_2','value'=>'&#29305;&#33394;&#25512;&#33616;'));
}
//PC��ҳģ��2����
if(!C::t('#aljbd#aljbd_setting')->fetch('HomePageModuleContent_2')){
    $HomePageModuleContent_2 = '&#32431;&#26825;&#36136;&#21697;|&#25226;&#22909;&#36135;&#24102;&#22238;&#23478;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mb1.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mb1.png|ȥ��ʶ|#7bd1f6|//dism.taobao.com/?@aljbd.plugin
&#22242;&#36141;&#28909;&#21334;|&#27599;&#19968;&#27454;&#37117;&#26159;&#22909;&#36135;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mb2.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mb2.png|ȥ��ʶ|#f75674|//dism.taobao.com/?@aljbd.plugin
&#25340;&#22242;&#28909;&#21334;|&#37117;&#26159;&#22909;&#36135;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mb3.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mb3.png|ȥ��ʶ|#f46750|//dism.taobao.com/?@aljbd.plugin
&#33298;&#36866;&#31461;&#38795;|&#24110;&#23453;&#23453;&#23398;&#36208;&#36335;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mb4.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mb4.png|ȥ��ʶ|#cd51eb|//dism.taobao.com/?@aljbd.plugin
&#21452;&#21313;&#20108;&#36816;&#21160;&#38795;|&#21697;&#29260;&#30452;&#38477;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mb5.jpg|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mb5.png|ȥ��ʶ|#43dd72|//dism.taobao.com/?@aljbd.plugin';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'HomePageModuleContent_2','value'=>$HomePageModuleContent_2));
}
//PC��ҳģ��3����
if(!C::t('#aljbd#aljbd_setting')->fetch('HomePageModuleTitle_3')){
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'HomePageModuleTitle_3','value'=>'&#21457;&#29616;&#22909;&#36135;'));
}
//PC��ҳģ��3����
if(!C::t('#aljbd#aljbd_setting')->fetch('HomePageModuleContent_3')){
    $HomePageModuleContent_3 = '&#31934;&#36873;&#29983;&#40092;|&#24180;&#36135;&#24102;&#22238;&#23478;&#32;&#28385;&#49;&#57;&#57;&#20943;&#54;&#48;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod3_1.png|//dism.taobao.com/?@aljbd.plugin
&#27597;&#23156;&#20581;&#24247;|&#22791;&#23381;&#20248;&#23381;&#26816;&#27979;&#20202;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod3_2.png|//dism.taobao.com/?@aljbd.plugin
&#26234;&#33021;&#29983;&#27963;|&#26234;&#33021;&#29190;&#27454;&#50;&#57;&#46;&#57;&#20803;&#36215;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod3_3.png|//dism.taobao.com/?@aljbd.plugin
&#20225;&#19994;&#37319;&#36141;&#23395;|&#29983;&#27963;&#30005;&#22120;&#26368;&#39640;&#20943;&#57;&#48;&#48;&#20803;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod3_4.png|//dism.taobao.com/?@aljbd.plugin
&#20108;&#25163;&#20248;&#21697;|&#105;&#80;&#104;&#111;&#110;&#101;&#32;&#55;&#80;&#32;&#49;&#50;&#26399;&#20813;&#24687;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod3_5.png|//dism.taobao.com/?@aljbd.plugin
&#23569;&#22899;&#32654;&#22918;|&#38754;&#33180;&#21270;&#22918;&#21697;&#20302;&#33267;&#49;&#25240;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/mod3_6.png|//dism.taobao.com/?@aljbd.plugin';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'HomePageModuleContent_3','value'=>$HomePageModuleContent_3));
}

//PC�����б��������
if(!C::t('#aljbd#aljbd_setting')->fetch('shopListBannerAds')){
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'shopListBannerAds','value'=>"<a href='plugin.php?id=aljbd&act=attend' target='_blank'><img height='200'  src='source/plugin/aljbd/template/index/images/mrad.jpg' /></a>"));
}

//PC�ײ������ǩ
if(!C::t('#aljbd#aljbd_setting')->fetch('pc_footer_new_top')){
    $pc_footer_new_top = 'source/plugin/aljbd/images/footer/qitian.png|&#19971;&#22825;&#21253;&#36864;
source/plugin/aljbd/images/footer/zhengpin.png|&#27491;&#21697;&#20445;&#38556;
source/plugin/aljbd/images/footer/haoping.png|&#22909;&#35780;&#22914;&#28526;
source/plugin/aljbd/images/footer/shandian.png|&#38378;&#30005;&#21457;&#36135;
source/plugin/aljbd/images/footer/quanwei.png|&#26435;&#23041;&#33635;&#35465;';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'pc_footer_new_top','value'=>$pc_footer_new_top));
}
//PC�ײ������ǩ�Ե绰
if(!C::t('#aljbd#aljbd_setting')->fetch('pc_footer_new_top_tel')){
    $pc_footer_new_top_tel = 'source/plugin/aljbd/images/footer/dianhua.png|0591-88888888';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'pc_footer_new_top_tel','value'=>$pc_footer_new_top_tel));
}
//PC�ײ��绰�Կͷ�
if(!C::t('#aljbd#aljbd_setting')->fetch('pc_footer_new_top_kefu')){
    $pc_footer_new_top_kefu = 'source/plugin/aljbd/images/footer/dianhua.png|javascript:;|&#21672;&#35810;&#23458;&#26381;';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'pc_footer_new_top_kefu','value'=>$pc_footer_new_top_kefu));
}
//PC�ײ�����˵��1����
if(!C::t('#aljbd#aljbd_setting')->fetch('pc_footer_new_cron_t1')){
    $pc_footer_new_cron_t1 = '&#37197;&#36865;&#19982;&#25903;&#20184;';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'pc_footer_new_cron_t1','value'=>$pc_footer_new_cron_t1));
}
//PC�ײ�����˵��1����
if(!C::t('#aljbd#aljbd_setting')->fetch('pc_footer_new_cron_c1')){
    $pc_footer_new_cron_c1 = '&#19978;&#38376;&#33258;&#25552;|#
&#25903;&#20184;&#26041;&#24335;&#35828;&#26126;|#
&#37197;&#36865;&#26041;&#24335;|#';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'pc_footer_new_cron_c1','value'=>$pc_footer_new_cron_c1));
}
//PC�ײ�����˵��2����
if(!C::t('#aljbd#aljbd_setting')->fetch('pc_footer_new_cron_t2')){
    $pc_footer_new_cron_t2 = '&#26032;&#25163;&#19978;&#36335;';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'pc_footer_new_cron_t2','value'=>$pc_footer_new_cron_t2));
}
//PC�ײ�����˵��2����
if(!C::t('#aljbd#aljbd_setting')->fetch('pc_footer_new_cron_c2')){
    $pc_footer_new_cron_c2 = '&#38544;&#31169;&#22768;&#26126;|#
&#35746;&#36141;&#26041;&#24335;|#
&#36141;&#29289;&#27969;&#31243;|#';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'pc_footer_new_cron_c2','value'=>$pc_footer_new_cron_c2));
}
//PC�ײ�����˵��3����
if(!C::t('#aljbd#aljbd_setting')->fetch('pc_footer_new_cron_t3')){
    $pc_footer_new_cron_t3 = '&#32852;&#31995;&#25105;&#20204;';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'pc_footer_new_cron_t3','value'=>$pc_footer_new_cron_t3));
}
//PC�ײ�����˵��3����
if(!C::t('#aljbd#aljbd_setting')->fetch('pc_footer_new_cron_c3')){
    $pc_footer_new_cron_c3 = '&#25237;&#35785;&#19982;&#24314;&#35758;|#
&#36141;&#20080;&#21672;&#35810;|#
&#32593;&#31449;&#25925;&#38556;&#25253;&#21578;|#';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'pc_footer_new_cron_c3','value'=>$pc_footer_new_cron_c3));
}
//PC�ײ�����˵��4����
if(!C::t('#aljbd#aljbd_setting')->fetch('pc_footer_new_cron_t4')){
    $pc_footer_new_cron_t4 = '&#26381;&#21153;&#20445;&#35777;';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'pc_footer_new_cron_t4','value'=>$pc_footer_new_cron_t4));
}
//PC�ײ�����˵��4����
if(!C::t('#aljbd#aljbd_setting')->fetch('pc_footer_new_cron_c4')){
    $pc_footer_new_cron_c4 = '&#20135;&#21697;&#36136;&#37327;&#20445;&#35777;|#
&#21806;&#21518;&#26381;&#21153;&#20445;&#35777;|#
&#36864;&#25442;&#36135;&#21407;&#21017;|#';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'pc_footer_new_cron_c4','value'=>$pc_footer_new_cron_c4));
}
//PC�ײ�����˵��5����
if(!C::t('#aljbd#aljbd_setting')->fetch('pc_footer_new_cron_t5')){
    $pc_footer_new_cron_t5 = '&#20250;&#21592;&#20013;&#24515;';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'pc_footer_new_cron_t5','value'=>$pc_footer_new_cron_t5));
}
//PC�ײ�����˵��5����
if(!C::t('#aljbd#aljbd_setting')->fetch('pc_footer_new_cron_c5')){
    $pc_footer_new_cron_c5 = '&#25105;&#30340;&#35746;&#21333;|plugin.php?id=aljbd&act=orderlist
&#21830;&#21697;&#21015;&#34920;|plugin.php?id=aljbd&act=goods
&#25105;&#35201;&#24320;&#24215;|plugin.php?id=aljbd&act=attend';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'pc_footer_new_cron_c5','value'=>$pc_footer_new_cron_c5));
}
//�ײ�����˵���Ա߶�ά��
if(!C::t('#aljbd#aljbd_setting')->fetch('pc_footer_new_cron_qrcode')){
    $pc_footer_new_cron_qrcode = 'source/plugin/aljbd/images/qrcode/aljbd_qrcode.jpg|&#25163;&#26426;&#29256;
source/plugin/aljbd/images/qrcode/aljbd_qrcode.jpg|&#24494;&#21830;&#22478;';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'pc_footer_new_cron_qrcode','value'=>$pc_footer_new_cron_qrcode));
}
//�ײ�������
if(!C::t('#aljbd#aljbd_setting')->fetch('pc_footer_new_bot')){
    $pc_footer_new_bot = '&#169; 2013-2018 &#21697;&#29260;&#21830;&#23478;<a href="//www.miitbeian.gov.cn/" target="_blank">&#38397;&#73;&#67;&#80;&#22791;&#56;&#56;&#56;&#56;&#56;&#56;&#56;&#56;&#21495;&#45;&#49;</a>';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'pc_footer_new_bot','value'=>$pc_footer_new_bot));
}

//�ֻ���ͼ�Ĺ��
if(!C::t('#aljbd#aljbd_setting')->fetch('mobile_index_Photo_Ads')){
    $mobile_index_Photo_Ads = '&#24110;&#21161;&#20013;&#24515;|&#24179;&#21488;&#30334;&#23453;&#31665;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_bc.png|#
&#22825;&#22825;&#29305;&#24800;|&#39046;&#21048;&#19979;&#21333;&#26356;&#23454;&#24800;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_yh.png|#
&#25105;&#30340;&#24494;&#24215;|&#21160;&#21160;&#25163;&#25351;&#29378;&#36186;&#22806;&#22359;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_fx.png|#
&#38468;&#36817;&#21830;&#23478;|&#30465;&#26102;&#12289;&#30465;&#21147;&#12289;&#30465;&#24515;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_fj.png|#';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'mobile_index_Photo_Ads','value'=>$mobile_index_Photo_Ads));
}
//�ֻ����������ͼ
if(!C::t('#aljbd#aljbd_setting')->fetch('mobile_index_tad_title')){
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'mobile_index_tad_title','value'=>'https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/Three_ads_title.jpg'));
}
//�ֻ���������
if(!C::t('#aljbd#aljbd_setting')->fetch('mobile_index_tad')){
    $mobile_index_tad = 'source/plugin/aljbd/template/touch/three_lattice_ad/images/t1.jpg|//dism.taobao.com/?@aljbd.plugin
source/plugin/aljbd/template/touch/three_lattice_ad/images/t2.jpg|//dism.taobao.com/?@aljbd.plugin
source/plugin/aljbd/template/touch/three_lattice_ad/images/t3.jpg|//dism.taobao.com/?@aljbd.plugin';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'mobile_index_tad','value'=>$mobile_index_tad));
}
//�ֻ����ĸ����ͼ
if(!C::t('#aljbd#aljbd_setting')->fetch('mobile_index_fad_title')){
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'mobile_index_fad_title','value'=>'https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/mobile_index_fad_title.jpg'));
}
//�ֻ����ĸ���
if(!C::t('#aljbd#aljbd_setting')->fetch('mobile_index_fad')){
    $mobile_index_fad = 'https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/Four_ads_left_1.jpg|//dism.taobao.com/?@aljbd.plugin
https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/Four_ads_left_2.jpg|//dism.taobao.com/?@aljbd.plugin
https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/Four_ads_right_1.jpg|//dism.taobao.com/?@aljbd.plugin
https://liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/Four_ads_right_2.jpg|//dism.taobao.com/?@aljbd.plugin';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'mobile_index_fad','value'=>$mobile_index_fad));
}
//�ֻ���ײ�
if(!C::t('#aljbd#aljbd_setting')->fetch('mobile_common_footernav')){

    $mobile_common_footernav = 'source/plugin/aljbd/images/footer/mobile/index1.png|source/plugin/aljbd/images/footer/mobile/index.png|&#39318;&#39029;|plugin.php?id=aljbd
source/plugin/aljbd/images/footer/mobile/type1.png|source/plugin/aljbd/images/footer/mobile/type.png|&#20998;&#31867;|plugin.php?id=aljbd&act=type
source/plugin/aljbd/images/footer/mobile/search1.png|source/plugin/aljbd/images/footer/mobile/search.png|&#25628;&#32034;|plugin.php?id=aljbd&act=search
source/plugin/aljbd/images/footer/mobile/my1.png|source/plugin/aljbd/images/footer/mobile/my.png|&#25105;&#30340;|plugin.php?id=aljbd&act=user';

    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'mobile_common_footernav','value'=>$mobile_common_footernav));
}
//PC��Ĭ�Ͽ���
if(!C::t('#aljbd#aljbd_setting')->fetch('templatepx')){
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'templatepx','value'=>'1'));
}
//PC��Ĭ�Ͽ������ർ��
if(!C::t('#aljbd#aljbd_setting')->fetch('displaynavs')){
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'displaynavs','value'=>'1'));
}
//PC��Ĭ�Ϸ��ർ��Ϊ��Ʒ
if(!C::t('#aljbd#aljbd_setting')->fetch('displaygoodsnav')){
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'displaygoodsnav','value'=>'1'));
}
//����ͼ��
if(!C::t('#aljbd#aljbd_setting')->fetch('gg_icon')){
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'gg_icon','value'=>'source/plugin/aljbd/template/touch/round_robin/hot.png'));
}
//Ĭ�Ͽ������̲������
if(!C::t('#aljbd#aljbd_setting')->fetch('is_view_dh')){
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'is_view_dh','value'=>'1'));
}


//�ҵ�ҳ��ȫ������
if(!C::t('#aljbd#aljbd_setting')->fetch('mobile_user_order')){

    $mobile_user_order = 'source/plugin/aljht/static/img/aljbd//order.png|plugin.php?id=aljbd&act=orderlist|&#20840;&#37096;&#35746;&#21333;
source/plugin/aljht/static/img/aljbd/user/order-pay.png|plugin.php?id=aljbd&act=orderlist&status=1|&#24453;&#20184;&#27454;
source/plugin/aljht/static/img/aljbd/user/order-send.png|plugin.php?id=aljbd&act=orderlist&status=2|&#24453;&#21457;&#36135;
source/plugin/aljht/static/img/aljbd/user/order-deliver.png|plugin.php?id=aljbd&act=orderlist&status=3|&#24453;&#25910;&#36135;
source/plugin/aljht/static/img/aljbd/user/order-evaluate.png|plugin.php?id=aljbd&act=orderlist&status=4|&#24453;&#35780;&#20215;
source/plugin/aljht/static/img/aljbd/user/order-refund.png|plugin.php?id=aljbd&act=orderlist&status=5|&#24050;&#35780;&#20215;';

    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'mobile_user_order','value'=>$mobile_user_order));
}
//�ҵ�ҳ�泣�����
if(!C::t('#aljbd#aljbd_setting')->fetch('mobile_user_common_entrance')){

    $mobile_user_common_entrance = 'source/plugin/aljht/static/img/aljbd/user/rz.png|plugin.php?id=aljbd&act=attend&mobile=2|&#30003;&#35831;&#20837;&#39547;';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'mobile_user_common_entrance','value'=>$mobile_user_common_entrance));
}
//�ҵ�ҳ���̼�����
if(!C::t('#aljbd#aljbd_setting')->fetch('mobile_user_business_center')){
    $mobile_user_business_center = 'source/plugin/aljht/static/img/aljbd/user/order.png|plugin.php?id=aljbd&act=orderlist&ord=dianp&mobile=2|&#24215;&#38138;&#35746;&#21333;
source/plugin/aljht/static/img/aljbd/user/brand.png|plugin.php?id=aljbd&act=member&mobile=2|&#24215;&#38138;&#31649;&#29702;
source/plugin/aljht/static/img/aljbd/user/goods.png|plugin.php?id=aljbd&act=goodslist&mobile=2|&#21830;&#21697;&#31649;&#29702;
source/plugin/aljht/static/img/aljbd/user/notice.png|plugin.php?id=aljbd&act=noticelist&mobile=2|&#27963;&#21160;&#31649;&#29702;
source/plugin/aljht/static/img/aljbd/user/consume.png|plugin.php?id=aljbd&act=consumelist&mobile=2|&#20248;&#24800;&#21048;&#31649;&#29702;';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'mobile_user_business_center','value'=>$mobile_user_business_center));
}
//�ҵ�ҳ��ͬ����Ϣ
if(!C::t('#aljbd#aljbd_setting')->fetch('mobile_user_city_wide')){

    $mobile_user_city_wide = 'source/plugin/aljht/static/img/aljbd/user/rz.png|plugin.php?id=aljtc&act=posttype&mobile=2|&#21457;&#24067;&#20449;&#24687;
source/plugin/aljht/static/img/aljbd/user/fabu.png|plugin.php?id=aljtc&act=member|&#25105;&#30340;&#21457;&#24067;
source/plugin/aljht/static/img/aljbd/user/star.png|plugin.php?id=aljtc&act=collection_list|&#25105;&#30340;&#25910;&#34255;
source/plugin/aljht/static/img/aljbd/user/renzheng.png|plugin.php?id=aljtc&act=attes|&#25105;&#30340;&#35748;&#35777;';

    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'mobile_user_city_wide','value'=>$mobile_user_city_wide));
}

//��������ҳͼ�굼��
if(!C::t('#aljbd#aljbd_setting')->fetch('mobile_view_imgnav')){
    $mobile_view_imgnav = 'source/plugin/aljbd/images/sj/shang.png|plugin.php?id=aljbd&act=view&bid={bid}&mobile=2|&#39318;&#39029;';
    $mobile_view_imgnav .= '
source/plugin/aljbd/images/sj/consume.png|plugin.php?id=aljbd&act=view&bid={bid}&op=consume&mobile=2|&#20248;&#24800;&#21048;
source/plugin/aljbd/images/sj/hd.png|plugin.php?id=aljbd&act=view&bid={bid}&op=notice&mobile=2|&#27963;&#21160;
source/plugin/aljbd/images/sj/v_r.png|plugin.php?id=aljbd&act=view&bid={bid}&op=reply&mobile=2|&#28857;&#35780;';
    $mobile_view_imgnav .= '
source/plugin/aljbd/images/sj/xx.png|plugin.php?id=aljbd&act=view&bid={bid}&op=details&mobile=2|&#35814;&#24773;';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'mobile_view_imgnav','value'=>$mobile_view_imgnav));
}
//�ֻ�ȫ�ֵײ�������Ϣ�����ʾλ��
if(!C::t('#aljbd#aljbd_setting')->fetch('footer_red_dot')){
    $footer_red_dot = 'act=user';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'footer_red_dot','value'=>$footer_red_dot));
}
//ȫ����֤ͼ��
if(!C::t('#aljbd#aljbd_setting')->fetch('attes_logo')){
    $attes_logo = 'source/plugin/aljbd/images/vip.gif';
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'attes_logo','value'=>$attes_logo));
}
//�ֻ��浼��������ɫ
if(!C::t('#aljbd#aljbd_setting')->fetch('mobilenavbackcolor')){
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'mobilenavbackcolor','value'=>'#f42424'));
}
//��������������ɫ
if(!C::t('#aljbd#aljbd_setting')->fetch('header_font_color')){
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'header_font_color','value'=>'#FFFFFF'));
}
//��Ʒ������ť
if(!C::t('#aljbd#aljbd_setting')->fetch('is_post_btn')){
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'is_post_btn','value'=>'1'));
}
//��פЭ��Ĭ��ѡ�п���
if(!C::t('#aljbd#aljbd_setting')->fetch('agreement_checked')){
    C::t('#aljbd#aljbd_setting')->insert(array('key'=>'agreement_checked','value'=>'1'));
}
//From: Dism_taobao_com
?>