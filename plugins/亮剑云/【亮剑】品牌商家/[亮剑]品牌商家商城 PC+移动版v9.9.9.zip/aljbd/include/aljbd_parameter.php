<?php
/**
 * Created by PhpStorm.
 * User: lixinyuan
 * Date: 2017/6/20
 * Time: ����11:11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$bid = intval($_GET['bid']);
$gid = intval($_GET['gid']);
$ggurl = 'plugin.php?id=aljbd&act=goodview&bid={bid}&gid={goods_id}';
$orderlisturl = 'plugin.php?id=aljbd&act=orderlist';
$aljbdlang['template']  = array(
    'home_page'=>'&#39318;&#39029;',//��ҳ
    'My'=>'&#25105;&#30340;',//�ҵ�
    'search'=>'&#25628;&#32034;',//����
    'goods'=>'&#21830;&#21697;',//��Ʒ
    'whole'=>'&#20840;&#37096;',//ȫ��
    'business'=>'&#21830;&#23478;',//�̼�
    'Buy_immediately'=>'&#31435;&#21363;&#36141;&#20080;',//��������
    'Confirm_the_payment'=>'&#30830;&#35748;&#20184;&#27454;',//ȷ�ϸ���
);
//���ñ�
loadcache('aljbd_settings', 1);
if(!$_G['cache']['aljbd_settings']) {
    $settings=C::t('#aljbd#aljbd_setting')->range();
    savecache('aljbd_settings', $settings);
}else{
    $settings = $_G['cache']['aljbd_settings'];
}

$is_openarray = array('iswatermark','is_daohang','alipay','malipay','isextcredit','pic','isgo','isnews','isyouh','ispd','isrewrite','islogo','isqq','ista','sjurl','sj_index_lz','time');
foreach($settings as $k => $v){
    if(in_array($k,$is_openarray)){//�����ж�
        if($v['value'] == 1){
            $_G['cache']['plugin']['aljbd'][$k] = 1;
        }elseif($v['value'] == 2){
            $_G['cache']['plugin']['aljbd'][$k] = 0;
        }
    }else{
        if($v['value']){
            $_G['cache']['plugin']['aljbd'][$k] = htmlspecialchars_decode($v['value']);//ͬ����������ֵ���������б���
        }
    }
}
$fare_desc = array('1'=>'&#21253;&#37038;','2'=>'&#21040;&#20184;');
$admingroups = unserialize($_G['cache']['plugin'][$pluginid]['managegroups']);
if(in_array($_G['groupid'],$admingroups)){
    $admin_status = 1;
}
$user = C::t('#aljbd#aljbd_user') -> fetch($_G['uid']);
//������
loadcache('aljbd_region', 1);
if(!$_G['cache']['aljbd_region']) {
    $rlist=C::t('#aljbd#aljbd_region')->range();
    savecache('aljbd_region', $rlist);
}else{
    $rlist = $_G['cache']['aljbd_region'];
}
//�̼ҷ����
loadcache('aljbd_type', 1);
if(!$_G['cache']['aljbd_type']) {
    $typelist=C::t('#aljbd#aljbd_type')->range();
    savecache('aljbd_type', $typelist);
}else{
    $typelist = $_G['cache']['aljbd_type'];
}

//debug($settings['displaynavs']['value']);
if($settings['displaygoodsnav']['value']){
    $alltype = DB::fetch_all('select * from %t where upid=0 and is_open=0 order by displayorder asc limit 0,13',array('aljbd_type_goods'));
}else{
    $alltype = DB::fetch_all('select * from %t where upid=0 and is_open=0 order by displayorder desc limit 0,13',array('aljbd_type'));
}
$yindao = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin'][$pluginid] ['yindao']));
foreach($yindao as $key=>$value){
    $arr=explode('|',$value);

    $yd_types[]=$arr;
}

$businesstype = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin'][$pluginid] ['businesstype']));
foreach($businesstype as $key=>$value){
	$arr=explode('=',$value);
	$businesstypearr[$arr[0]]=$arr[1];
	$busarr[$arr[0]]=diconv($arr[1],CHARSET,'UTF-8');;
}
$busarr = json_encode($busarr);
$mobile_user_9 = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin'][$pluginid] ['mobile_user_9']));
foreach($mobile_user_9 as $key=>$value){
    $arr=explode('|',$value);

    $custom_types[]=$arr;
}
$ress=array(
    'brand_index.html'=>'plugin.php?id=aljbd',
    'brand.html'=>'plugin.php?id=aljbd&act=dianpu',
    'goods.html'=>'plugin.php?id=aljbd&act=goods',
    'notice.html'=>'plugin.php?id=aljbd&act=nlist',
    'consume.html'=>'plugin.php?id=aljbd&act=clist',
);
$index_dh = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin'][$pluginid] ['index_dh']));
foreach($index_dh as $key=>$value){
    $arr=explode('|',$value);
    $index_dh_types[$arr[0]]=$arr[1];
}
if ($_SERVER ['HTTP_X_REWRITE_URL']) {
    $the_uri = isset($_SERVER ['HTTP_X_REWRITE_URL']) ? $_SERVER ['HTTP_X_REWRITE_URL'] : '';
} else {
    $the_uri = isset($_SERVER ['REQUEST_URI']) ? $_SERVER ['REQUEST_URI'] : '';
}
$the_uri=ltrim($the_uri,'/');
$url_dh=ltrim($_SERVER['PHP_SELF'].'?'.$_SERVER["QUERY_STRING"],'/');

//������Ĭ��ͼƬ
if($_G['cache']['plugin'][$pluginid]['lazyloadlogo']){
    $loading = $_G['cache']['plugin'][$pluginid]['lazyloadlogo'];
}else{
    $loading = 'source/plugin/aljbd/images/loading.gif';
}
if($settings['image_path']['value']){
    $image_path = $settings['image_path']['value'];
}else{
    $image_path = 'source/plugin/aljbd/images/';
}
if($settings['del_noimg']['value']) {
    $noimg = $settings['del_noimg']['value'];
}else{
    $noimg = 'source/plugin/aljbd/images/sj/noimg.gif';
}
if($_G['cache']['plugin']['aljgwc']){
    if($_G['cache']['plugin']['aljpps']['is_aljbd']){
        $a_type=1;
    }
    $addrlist = C::t('#aljbdx#aljbd_address')->fetch_all_by_uid_desc($_G['uid'],$a_type);
}
//1΢��2֧����5����6����
$paymentarr = array('1' => '&#24494;&#20449;&#25903;&#20184;','2' => '&#25903;&#20184;&#23453;&#25903;&#20184;','3' => '&#65;&#80;&#80;&#24494;&#20449;&#25903;&#20184;','5'=>'&#31215;&#20998;&#25903;&#20184;','6'=>'&#36135;&#21040;&#20184;&#27454;','7'=>'&#38065;&#21253;&#25903;&#20184;');

if($_G['cache']['plugin']['aljbd'] && file_exists("source/plugin/aljbd/include/newparameter.php")){
    require_once 'source/plugin/aljbd/include/newparameter.php';
}
if($_G['cache']['plugin']['aljtsc']){
    $fz_path = DISCUZ_ROOT . "source/plugin/aljtfz/include";
    if(is_file("$fz_path/fz_cookie.php")){include_once "$fz_path/fz_cookie.php";}
}
?>