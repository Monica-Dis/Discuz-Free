<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$sql = "ALTER TABLE ".DB::table('aljbd')." ADD `total_commission` decimal(10,2) NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljbd')." ADD `account_commissions` decimal(10,2) NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljbd')." ADD `not_account_commissions` decimal(10,2) NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljbd')." ADD `extraction_commission` decimal(10,2) NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljbd')." ADD `not_extraction_commission` decimal(10,2) NOT NULL";
DB::query($sql,'SILENT');

$sql = "ALTER TABLE ".DB::table('aljbd_vip')." ADD `payment_days` int(11) NOT NULL";
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_notice')." ADD `rec_gids` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_notice')." ADD `displayorder` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_notice')." ADD `cover_pic` text NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_vip')." ADD `is_hide` tinyint(4) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd')." ADD `others` TEXT NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd')." ADD `postal_amount` DECIMAL(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd')." ADD  `brand_bg` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd')." ADD  `fare_type` TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods')." ADD  `is_aljtcc` TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE  ".DB::table('aljbd')." ADD  `platform_distribution` TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE  ".DB::table('aljbd')." ADD  `hide_tel` TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods')." ADD  `weight` decimal(10,3) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_type')." ADD `type_url`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_type')." ADD `is_open`  TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_type_goods')." ADD `type_url`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_type_goods')." ADD `is_open`  TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_type_consume')." ADD `type_url`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_type_consume')." ADD `is_open`  TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_type_notice')." ADD `type_url`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_type_notice')." ADD `is_open`  TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');
if(file_exists("source/plugin/aljsp/aljsp.inc.php")){
  $sql ="ALTER TABLE ".DB::table('aljbd_type_video')." ADD `type_url`  varchar(255) NOT NULL" ;
  DB::query($sql,'SILENT');
  $sql ="ALTER TABLE ".DB::table('aljbd_type_video')." ADD `is_open`  TINYINT(3) NOT NULL" ;
  DB::query($sql,'SILENT');
}
$sql ="ALTER TABLE  ".DB::table('aljbd_goods')." ADD `new_price` DECIMAL(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods')." ADD `card_price` DECIMAL(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." CHANGE `card_price` `card_price` DECIMAL( 10, 2 ) NOT NULL " ;
DB::query($sql,'SILENT');
/*
$sql ="ALTER TABLE  ".DB::table('aljbd_goods')." ADD INDEX(`displayorder`)" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods')." ADD INDEX(`sign`)" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods')." ADD INDEX(`rubbish`)" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods')." ADD INDEX(`sh_status`)" ;
DB::query($sql,'SILENT');
*/
$sql ="ALTER TABLE  ".DB::table('aljbd_goods')." ADD  `is_volume` tinyint(4) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods')." ADD  `unit` char(20) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods')." ADD  `store_id` INT NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `draw_channel` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_consume')." ADD  `status` TINYINT( 3 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_consume')." ADD  `reason` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_notice')." ADD  `status` TINYINT( 3 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_notice')." ADD  `reason` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_album')." ADD  `status` TINYINT( 3 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_album')." ADD  `reason` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods')." ADD  `reason` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd')." ADD  `reason` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_attestation')." ADD `business_license_id` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_attestation')." ADD `license_comp_adress` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_attestation')." ADD `license_adress` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_attestation')." ADD `registered_capital` int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_attestation')." ADD `company_located` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_attestation')." ADD `company_adress` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_attestation')." ADD `reason` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_wuliu')." ADD  `info` text NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_wuliu')." CHANGE `e` `e` TEXT NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE  ".DB::table('aljbd')." ADD  `kf_uid` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd')." CHANGE  `adv`  `adv` TEXT NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd')." CHANGE  `advurl`  `advurl` TEXT NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd')." CHANGE  `madv`  `madv` TEXT NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd')." CHANGE  `madvurl`  `madvurl` TEXT NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `limit_amount`  int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `m_intro_img`  text NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `m_intro_text`  text NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `is_pt_sku` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `vr_url` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `video_url` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `video_path` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');


if(file_exists("source/plugin/dz_1/dz_1.inc.php")){
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `sccj`  varchar(255) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `cpgg`  varchar(255) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `fyts`  varchar(255) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `ysqz`  varchar(255) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `hdtj`  varchar(255) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `ext_num`  int(11) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `ext_num`  int(10) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `ext_num`  int(10) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljgwc')." ADD `ext_num`  int(10) NOT NULL" ;
    DB::query($sql,'SILENT');
}
if(file_exists("source/plugin/aljhelp/aljhelp.inc.php")){
    $sql ="ALTER TABLE ".DB::table('aljhelp')." ADD `is_gg`  tinyint(3) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljhelp')." ADD `is_common`  tinyint(3) NOT NULL" ;
    DB::query($sql,'SILENT');
}

$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljbd_vip')." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `good` int(11) NOT NULL,
  `notice` int(11) NOT NULL,
  `album` int(11) NOT NULL,
  `consume` int(11) NOT NULL,
  `video` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `day` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `fee` int(11) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `displayorder` int(11) NOT NULL,
  `give_integral` INT NOT NULL,
  `pay_integral` INT NOT NULL,
  `is_distribution` tinyint(3) NOT NULL,
  `is_video` tinyint(3) NOT NULL,
  `is_bvideo` tinyint(3) NOT NULL,
  `is_consume` tinyint(3) NOT NULL,
  `is_notice` tinyint(3) NOT NULL,
  `is_album` tinyint(3) NOT NULL,
  `is_goods` tinyint(3) NOT NULL,
  `bzj_price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
);";
DB::query($sql,'SILENT');
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljbd_goods_log')." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gid` int(11) NOT NULL,
  `addtime` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `goodsinfo` text NOT NULL,
  `url` varchar(300) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gid` (`gid`),
  KEY `uid` (`uid`)
)";
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_vip')." ADD  `give_integral` INT NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_vip')." ADD  `pay_integral` INT NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_vip')." ADD  `is_video` TINYINT( 3 ) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_vip')." ADD  `bzj_price` decimal(10,2) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_vip')." ADD  `is_distribution` TINYINT( 3 ) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_vip')." ADD  `is_goods` TINYINT( 3 ) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_vip')." ADD  `is_album` TINYINT( 3 ) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_vip')." ADD  `is_notice` TINYINT( 3 ) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_vip')." ADD  `is_consume` TINYINT( 3 ) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_vip')." ADD  `is_bvideo` TINYINT( 3 ) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_vip')." ADD  `type` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_vip')." ADD  `store_authority` text NOT NULL" ;
DB::query($sql,'SILENT');
if(file_exists("source/plugin/aljstg/aljstg.inc.php")){
  $sql ="ALTER TABLE ".DB::table('aljbd_write_off_code')." ADD `price` decimal(10,2) NOT NULL" ;
  DB::query($sql,'SILENT');
  $sql ="ALTER TABLE ".DB::table('aljbd_write_off_code')." ADD `reason` varchar(255) NOT NULL" ;
  DB::query($sql,'SILENT');
}
if(file_exists("source/plugin/aljsfx/aljsfx.inc.php")){
    //fx s
    $sql ="ALTER TABLE ".DB::table('aljsfx_rank')." ADD `open_mypay` tinyint(4) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljsfx_rank')." ADD `type` tinyint(4) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `is_distribution` tinyint(4) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `dis_commission` int(11) NOT NULL" ;
    DB::query($sql,'SILENT');

    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `is_distribution` tinyint(4) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `dis_commission` int(11) NOT NULL" ;
    DB::query($sql,'SILENT');

    $sql ="ALTER TABLE ".DB::table('aljbd_vip')." ADD `is_distribution` tinyint(4) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljsfx_shop')." ADD `shop_logo` varchar(255) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljsfx_rank')." ADD `f_shop_scale` int(11) NOT NULL" ;
    DB::query($sql,'SILENT');

    $sql ="ALTER TABLE ".DB::table('aljsfx_order')." ADD `name` varchar(255) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljsfx_order')." ADD `price` decimal(10,2) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljsfx_order')." ADD `num` int(11) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljsfx_order')." ADD `goods_id` int(11) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljsfx_order')." ADD `dis_commission` int(11) NOT NULL" ;
    DB::query($sql,'SILENT');
}
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `goodstype` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `available_goods` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `full` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `reduction` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `coupon_type` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `coupon_num` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `coupon_limit` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `start` int NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `btypeid`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `bsubtypeid`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `attr_key` text NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `attr_value` text NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `attr_sku` text NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." CHANGE `price2` `price2` DECIMAL( 10, 2 ) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." CHANGE `price1` `price1` DECIMAL( 10, 2 ) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `rubbish`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods')." ADD  `service_label` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods')." ADD  `give_integral` INT NOT NULL ,
ADD  `pay_integral` INT NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `vipid`  int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `label` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `vipendtime`  int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `rubbish`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `madv`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `madvurl`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `wangwang`  varchar(100) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `weixin_id`  varchar(100) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `collection`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_notice')." ADD `rubbish`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `rubbish`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_album')." ADD `rubbish`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_album_attachments')." ADD `rubbish`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_page')." ADD `rubbish`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_comment')." ADD `rubbish`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_comment_consume')." ADD `rubbish`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_comment_notice')." ADD `rubbish`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_comment_goods')." ADD `rubbish`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
if(file_exists("source/plugin/aljsp/aljsp.inc.php")){
    $sql ="ALTER TABLE ".DB::table('aljbd_video')." ADD `rubbish`  int(10) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE  ".DB::table('aljbd_video')." ADD  `status` TINYINT( 3 ) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE  ".DB::table('aljbd_video')." ADD  `reason` VARCHAR( 255 ) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE  ".DB::table('aljbd_video')." ADD  `video_path` VARCHAR( 255 ) NOT NULL" ;
    DB::query($sql,'SILENT');
}

$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `fare_desc`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `collection`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_notice')." ADD `collection`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `collection`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `state`  tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `fare` decimal(8,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_type_goods')." ADD `logo` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_type_goods')." ADD `brand_id` text NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_type_goods')." ADD `type_ad` text NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_type_goods')." ADD `pclabel` text NOT NULL ;" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `selling_point`  VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `category`  tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `commodity_type`  tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `starttime`  int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `collage_price` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `collage_num` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `brief` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljbd_platform_revenue')." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `desca` varchar(1000) NOT NULL,
  `orderid` char(32) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `fee` decimal(3,2) NOT NULL,
  `pluginid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pluginid` (`pluginid`,`store_id`,`fee`) USING BTREE,
  KEY `fee` (`fee`,`bid`,`pluginid`) USING BTREE,
  KEY `time` (`time`)
)";
DB::query($sql,'SILENT');

$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljbd_type_brand')." (
`id` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  `bid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bid` (`bid`),
  KEY `upid` (`upid`)
);";
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_type_brand')." ADD  `store_id` INT NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_type_brand')." ADD  `type` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljbd_search_keyword')." (
`id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `keyword` (`keyword`)
);";
DB::query($sql,'SILENT');
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljbd_goods_settle')." (
  `settleid` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `account` varchar(255) NOT NULL,
  `settleprice` varchar(255) NOT NULL,
  `payment` tinyint(3) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `applytime` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `uid` int(10) NOT NULL,
  PRIMARY KEY (`settleid`)
);";
DB::query($sql,'SILENT');

$sql ="ALTER TABLE  ".DB::table('aljbd_goods')." ADD  `sh_status` TINYINT( 3 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_comment_notice')." ADD  `status` TINYINT( 3 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_comment_consume')." ADD  `status` TINYINT( 3 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_comment')." ADD  `status` TINYINT( 3 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." CHANGE `x` `x` DECIMAL( 10, 6 ) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." CHANGE `y` `y` DECIMAL( 10, 6 ) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_order')." ADD `payment` char(50) NOT NULL" ;
DB::query($sql,'SILENT');
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljbd_attr')." (
  `mid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(10) unsigned NOT NULL,
  `name` int(10) NOT NULL,
  `content` text,
  `addtime` int(10) unsigned NOT NULL,
  `typeid` int(10) NOT NULL,
  PRIMARY KEY (`mid`)
);";
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `subtype3`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `subtype3`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `displayorder`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_user')." ADD `addr`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_user')." ADD `qq`  BIGINT NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_user')." ADD `tel`  BIGINT NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_order')." ADD `d`  tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljbd_kami')." (
  `mid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` int(10) unsigned NOT NULL,
  `message` text,
  `uid` mediumint(8) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `dateline` int(10) unsigned NOT NULL,
  `orderid` varchar(255) NOT NULL,
  PRIMARY KEY (`mid`)
);";
DB::query($sql,'SILENT');
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljbd_emaillog')." (
  `id` int(10) NOT NULL auto_increment,
  `sendemail` varchar(255) NOT NULL,
  `sendtype` tinyint(3) NOT NULL,
  `sendtime` int(10) NOT NULL,
  `success` tinyint(3) NOT NULL,
  PRIMARY KEY  (`id`)
);";
DB::query($sql,'SILENT');
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljbd_write_off_code')." (
  `password` bigint(12) NOT NULL,
  `orderid` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `shop_id` int(10) NOT NULL,
  `goods_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `endtime` int(10) NOT NULL,
  `status` int(10) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `hx_uid` int(10) NOT NULL,
  `store_id` int(10) NOT NULL,
  `hx_username` varchar(255) NOT NULL,
  PRIMARY KEY (`password`),
  KEY `orderid` (`orderid`),
  KEY `password` (`password`)
);";
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_write_off_code')." ADD `cid` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljhtx_system_setting')." (
`skey` varchar(255) NOT NULL,
  `svalue` text NOT NULL,
  PRIMARY KEY (`skey`)
);";
DB::query($sql,'SILENT');
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljbd_goods_volume_price')." (
`id` int(11) NOT NULL AUTO_INCREMENT,
  `price_type` tinyint(4) NOT NULL,
  `goods_id` int(11) NOT NULL,
  `volume_number` int(11) NOT NULL,
  `volume_price` decimal(10,2) NOT NULL,
  `path` varchar(255) NOT NULL,
  `volume_price_pt` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
);";
DB::query($sql,'SILENT');

$sql ="ALTER TABLE  ".DB::table('aljbd_write_off_code')." ADD  `hx_uid` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_write_off_code')." ADD  `store_id` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_write_off_code')." ADD  `hx_username` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_order')." ADD `remarks`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `business_hours`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `bus_routes`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_region')." ADD `displayorder`  int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `businesstype`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `draw`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `amount` INT NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `buyamount` INT NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `endtime` INT NOT NULL ;" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `sign` INT NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_notice')." ADD `subtype` INT NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_notice')." ADD `type` INT NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `subtype` INT NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `type` INT NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." CHANGE `jieshao` `jieshao` MEDIUMTEXT  NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `region1`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `qrcode`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_attestation')." CHANGE `tel` `tel` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `subtype` INT NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `type` INT NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `sign` INT NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `wurl` varchar(255) NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `gwurl` varchar(255) NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `commodity_code` varchar(255) NOT NULL ;" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `cover_image` varchar(255) NOT NULL ;" ;
DB::query($sql,'SILENT');

//finish to put your own code
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `qq`  BIGINT NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `displayorder` INT NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `price` DECIMAL( 10, 2 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd')." ADD `orderid` char( 32 ) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `region` int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `subregion` int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `region1` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_notice')." ADD `region` int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_notice')." ADD `subregion` int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_notice')." ADD `region1` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `region` int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `subregion` int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `region1` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `pic6`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `pic7`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `pic8`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `pic9`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `pic10`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `pic11`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `pic12`  varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_consume')." ADD `coupon_validity` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_address')." ADD  `type` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_address')." ADD  `province` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_address')." ADD  `city` VARCHAR( 255 ) NOT NULL " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_address')." ADD  `district` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_order')." CHANGE  `price`  `price` FLOAT( 10, 2 ) UNSIGNED NOT NULL DEFAULT  '0.00'" ;
DB::query($sql,'SILENT');
if(file_exists("source/plugin/aljbdx/aljbdx.inc.php")) {
    $sql = "ALTER TABLE " . DB::table('aljbd_goods_order') . " ADD `order_type` tinyint(3) NOT NULL";
    DB::query($sql, 'SILENT');
    $sql = "ALTER TABLE " . DB::table('aljbd_goods_order') . " ADD `other` text NOT NULL";
    DB::query($sql, 'SILENT');
    $sql ="ALTER TABLE  ".DB::table('aljbd_goods_order')." ADD  `store_id` int(11) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql = "ALTER TABLE " . DB::table('aljbd_goods_order_list') . " ADD `order_type` tinyint(3) NOT NULL";
    DB::query($sql, 'SILENT');
    $sql = "ALTER TABLE " . DB::table('aljbd_goods_order_list') . " ADD `status` tinyint(3) NOT NULL";
    DB::query($sql, 'SILENT');
    $sql = "ALTER TABLE " . DB::table('aljbd_goods_order_list') . " ADD `ms_enter_id` int(10) NOT NULL";
    DB::query($sql, 'SILENT');
    $sql ="ALTER TABLE  ".DB::table('aljgwc')." ADD  `store_id` INT NOT NULL " ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_comment_goods')." ADD `video_path` varchar(255) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql = "ALTER TABLE " . DB::table('aljbd_goods_order_list') . " ADD `confirmdate` int(11) NOT NULL";
    DB::query($sql, 'SILENT');
    $sql ="ALTER TABLE  ".DB::table('aljbd_goods_order_list')." ADD  `store_id` int(11) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljgwc_refund')." ADD `store_id`  int(11) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljgwc_refund')." ADD `bd_info` TEXT NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql = "ALTER TABLE " . DB::table('aljgwc_refund') . " ADD `type` tinyint(4) NOT NULL";
      DB::query($sql, 'SILENT');
    $sql ="ALTER TABLE  ".DB::table('aljbd_goods_order_list')." ADD  `goodsinfo` TEXT NOT NULL" ;
    DB::query($sql,'SILENT');
}
if(file_exists("source/plugin/aljht/aljht.inc.php")) {
    $sql = "ALTER TABLE " . DB::table('aljht_attr_sku') . " ADD `sku_logo` VARCHAR( 255 ) NOT NULL";
    DB::query($sql, 'SILENT');
    $sql = "ALTER TABLE " . DB::table('aljht_attr_sku') . " ADD `newprice` DECIMAL(10,2) NOT NULL";
    DB::query($sql, 'SILENT');
    $sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljht_iframe_nav')." (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `name` varchar(100) NOT NULL,
      `displayorder` int(11) NOT NULL,
      `url` varchar(255) NOT NULL,
      `addtime` int(11) NOT NULL,
      `upid` int(11) NOT NULL,
      `hide` tinyint(3) NOT NULL,
      PRIMARY KEY (`id`)
    )";
    DB::query($sql,'SILENT');
}
if(file_exists("source/plugin/aljhtx/aljhtx.inc.php")) {
    $sql ="ALTER TABLE  ".DB::table('aljhtx_notification')." ADD  `news_type` TINYINT( 3 ) NOT NULL" ;
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE  ".DB::table('aljhtx_notification')." ADD  `logo` varchar(255) NOT NULL" ;
    DB::query($sql,'SILENT');
}
if(file_exists("source/plugin/aljatt/aljatt.inc.php")) {
  $sql ="ALTER TABLE  ".DB::table('aljhtx_cron_script')." ADD `name` VARCHAR(255) NOT NULL" ;
  DB::query($sql,'SILENT');
  $sql ="ALTER TABLE  ".DB::table('aljhtx_cron_script')." ADD `type` tinyint(3) NOT NULL" ;
  DB::query($sql,'SILENT');
  $sql ="ALTER TABLE  ".DB::table('aljhtx_cron_script')." ADD `intro` text NOT NULL" ;
  DB::query($sql,'SILENT');
  $sql ="ALTER TABLE  ".DB::table('aljhtx_cron_script')." CHANGE `name` `name` VARCHAR(255) NOT NULL" ;
  DB::query($sql,'SILENT');
  if(!DB::fetch_first('select * from %t where file=%s',array('aljhtx_cron_script','source/plugin/aljhtx/api/auto.php'))){
    DB::insert('aljhtx_cron_script',array('name'=>'&#25340;&#22242;&#33258;&#21160;&#36864;&#27454;&#21450;&#35746;&#21333;&#33258;&#21160;&#25910;&#36135;','file'=>'source/plugin/aljhtx/api/auto.php','cycle'=>'5','open'=>'on'));
  }
}
if(file_exists("source/plugin/aljtcc/aljtcc.inc.php")) {
  $sql ="ALTER TABLE  ".DB::table('aljtcc_card')." ADD `integral_multiple` int(11) NOT NULL" ;
  DB::query($sql,'SILENT');
}

if(file_exists("source/plugin/aljms/aljms.inc.php")) {
  $sql ="ALTER TABLE ".DB::table('aljhtx_activity_ms_enter')." ADD `ms_status` tinyint(3) NOT NULL" ;
  DB::query($sql,'SILENT');
  $sql ="ALTER TABLE ".DB::table('aljhtx_activity_ms_enter')." ADD `ms_uid` int(11) NOT NULL" ;
  DB::query($sql,'SILENT');
}
if(file_exists("source/plugin/aljdiy/aljdiy.inc.php")) {
  $sql ="ALTER TABLE  ".DB::table('aljdiy_page')." ADD `push_to_page` varchar(255) NOT NULL" ;
  DB::query($sql,'SILENT');
}
$intro_video_path = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'intro_video_path\'', array('aljbd_goods'), true);
if(!$intro_video_path){
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `intro_video_path`  varchar(255) NOT NULL";
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD INDEX(`video_path`)";
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD INDEX(`buyamount`)";
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD INDEX(`price1`)";
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD INDEX(`view`)";
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD INDEX(`endtime`)";
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD INDEX(`type`)";
    DB::query($sql,'SILENT');
    $sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD INDEX(`region`)";
    DB::query($sql,'SILENT');
}

if (!function_exists('runquery')) {
  require_once libfile('function/plugin');
}

$aljbd_fz_id = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'fz_id\'', array('aljbd'), true);
if(!$aljbd_fz_id){
$sql = <<<EOF
ALTER TABLE `pre_aljbd` ADD `fz_id` INT NOT NULL;
ALTER TABLE `pre_aljbd` ADD INDEX(`fz_id`);
ALTER TABLE `pre_aljbd` ADD INDEX(`name`);
ALTER TABLE `pre_aljbd` ADD INDEX(`type`);
ALTER TABLE `pre_aljbd` ADD INDEX(`uid`);
ALTER TABLE `pre_aljbd` ADD INDEX(`displayorder`);
ALTER TABLE `pre_aljbd` ADD INDEX(`region`);
ALTER TABLE `pre_aljbd` ADD INDEX(`view`);
ALTER TABLE `pre_aljbd` ADD INDEX(`x`);
ALTER TABLE `pre_aljbd` ADD INDEX(`y`);
EOF;
runquery($sql);
}
$aljbd_goods_fz_id = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'fz_id\'', array('aljbd_goods'), true);
if(!$aljbd_goods_fz_id){
$sql = <<<EOF
ALTER TABLE `pre_aljbd_goods` ADD `fz_id` INT NOT NULL;
ALTER TABLE `pre_aljbd_goods` ADD INDEX(`fz_id`);
EOF;
runquery($sql);
}
$aljbd_consume_fz_id = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'fz_id\'', array('aljbd_consume'), true);
if(!$aljbd_consume_fz_id){
$sql = <<<EOF
ALTER TABLE `pre_aljbd_consume` ADD `fz_id` INT NOT NULL;
ALTER TABLE `pre_aljbd_consume` ADD INDEX(`fz_id`);
ALTER TABLE `pre_aljbd_consume` ADD INDEX(`start`);
ALTER TABLE `pre_aljbd_consume` ADD INDEX(`end`);
ALTER TABLE `pre_aljbd_consume` ADD INDEX(`bid`);
EOF;
runquery($sql);
}
$aljbd_notice_fz_id = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'fz_id\'', array('aljbd_notice'), true);
if(!$aljbd_notice_fz_id){
$sql = <<<EOF
ALTER TABLE `pre_aljbd_notice` ADD `fz_id` INT NOT NULL;
ALTER TABLE `pre_aljbd_notice` ADD INDEX(`fz_id`);
ALTER TABLE `pre_aljbd_notice` ADD INDEX(`bid`);
ALTER TABLE `pre_aljbd_notice` ADD INDEX(`subject`);
ALTER TABLE `pre_aljbd_notice` ADD INDEX(`view`);
EOF;
runquery($sql);
}
$aljbd_album_fz_id = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'fz_id\'', array('aljbd_album'), true);
if(!$aljbd_album_fz_id){
$sql = <<<EOF
ALTER TABLE `pre_aljbd_album` ADD `fz_id` INT NOT NULL;
ALTER TABLE `pre_aljbd_album` ADD INDEX(`fz_id`);
ALTER TABLE `pre_aljbd_album` ADD INDEX(`bid`);
ALTER TABLE `pre_aljbd_album` ADD INDEX(`albumname`);
ALTER TABLE `pre_aljbd_album` ADD INDEX(`view`);
ALTER TABLE `pre_aljbd_album` ADD INDEX(`displayorder`);
EOF;
runquery($sql);
}
if(file_exists("source/plugin/aljbdx/aljbdx.inc.php")) {
$aljbd_goods_order_list_id = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'id\'', array('aljbd_goods_order_list'), true);
if(!$aljbd_goods_order_list_id){
$sql = <<<EOF
ALTER TABLE `pre_aljbd_goods_order_list` ADD `id` INT NOT NULL AUTO_INCREMENT FIRST, ADD PRIMARY KEY (`id`);
EOF;
runquery($sql);
$order_fee = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'fee\'', array('aljbd_goods_order'), true);
if(!$order_fee){
$sql = <<<EOF
ALTER TABLE `pre_aljbd_goods_order` ADD `fee` decimal(10,2) NOT NULL;
ALTER TABLE `pre_aljbd_goods_order` ADD INDEX(`fee`);
ALTER TABLE `pre_aljbd_goods_order` ADD INDEX(`confirmdate`);
ALTER TABLE `pre_aljbd_goods_order` ADD INDEX(`status`);
ALTER TABLE `pre_aljbd_goods_order` ADD INDEX(`price`);
EOF;
runquery($sql);
}
}
$aljbd_goods_order_id = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'id\'', array('aljbd_goods_order'), true);
if(!$aljbd_goods_order_id){
$sql = <<<EOF
ALTER TABLE `pre_aljbd_goods_order` ADD `id` INT NOT NULL AUTO_INCREMENT FIRST, ADD PRIMARY KEY (`id`);
ALTER TABLE `pre_aljbd_goods_order` ADD INDEX(`stitle`);
EOF;
runquery($sql);
}
}
$aljbd_bdisplayorder = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'bdisplayorder\'', array('aljbd_goods'), true);
if(!$aljbd_bdisplayorder){
$sql = <<<EOF
ALTER TABLE `pre_aljbd_goods` ADD `bdisplayorder` INT NOT NULL;
ALTER TABLE `pre_aljbd_goods` ADD `other` text NOT NULL;
ALTER TABLE `pre_aljbd_goods` ADD INDEX(`bdisplayorder`);
EOF;
runquery($sql);
}
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `qg_type`  TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `limit_type`  TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD  `product_label` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
?>