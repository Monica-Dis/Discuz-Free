<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once 'source/plugin/aljhtx/class/class_aljhtx.php';
if($_G['mobile'] && $_G['cache']['plugin']['aljhtx']['force_mobile']){
    include_once "source/plugin/aljhtx/api/common.php";
}
$_G['makehtml'] = 1;//������ͨ�û��鿴 SEO ����
$li = 4;
$aljbd=C::t('#aljbd#aljbd')->fetch_by_uid($_G['uid']);
$aljbd = dhtmlspecialchars($aljbd);
/*if(strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false){
    preg_match('/Immersed\/(\d+)/i', $_SERVER["HTTP_USER_AGENT"], $matches);
    $immersed = $matches[1];
}*/
if($_GET['mobilediy'] == 'yes' || $_GET['mobiledemomode'] == 'yes' || $_GET['mobile'] == 2 || strpos($_SERVER['HTTP_USER_AGENT'],'iPad') !== false){
    define('IN_MOBILE', 2);
    $_G['mobile'] = 2;
}

foreach($_G['setting']['hookscript'] as $hook_k => $hook_v){
    foreach($hook_v as $glo_k => $glo_v){
      if($glo_k != 'avatar'){
        $_G['setting']['hookscript'][$hook_k][$glo_k] = array();
      }
    }
}


foreach($_G['setting']['hookscriptmobile'] as $h_m_k => $h_m_v){
  foreach($h_m_v as $m_v_k => $m_v_v){
    if($m_v_k != 'avatar'){
      $_G['setting']['hookscriptmobile'][$h_m_k][$m_v_k] = array();
    }
  }
}

$common_path = 'source/plugin/aljhtx/';
$common_template_pluginid = 'aljbd';
$version = '20181220';

//�ֻ���ײ�����
$mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_common_footernav']['value']));
foreach($mobile_common_footernav as $key=>$value){
    $arr=explode('|',$value);
    $mobile_common_footernav_arr[]=$arr;
}

$miniProgram = $hidegoback = strpos($_SERVER['HTTP_USER_AGENT'],"miniProgram") !== false ?  1 : 0;
$isappbyme = (strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0 || strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false) ?  1 : 0;
$ismagapp = strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPPX')>0 ? 1 : 0;
$isqianfanapp = strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'qianfan') !== false ? 1 : 0;

//��������ʱ��
$overtime = $_G['cache']['plugin']['aljbdx']['overtime']?$_G['cache']['plugin']['aljbdx']['overtime']*60:900;

if($_G['cache']['plugin']['aljbdx']['is_aljqb']){
    //�޸Ĺ����̼�״̬Ϊδ֧��
    DB::query('update %t set status=2 where vipendtime>0 and vipendtime<%d and status=1',array('aljbd',TIMESTAMP));
}

$Html5Plusapp = strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false ? 1 : 0;
$baiduswan = false !== strpos($_SERVER['HTTP_USER_AGENT'],'swan') ? 1 : 0;
$bindtime = $_G['cache']['plugin']['aljsfx']['bindtime'] ? $_G['cache']['plugin']['aljsfx']['bindtime']*60*60 : 60;


//PC�ײ������ǩ
$pc_footer_new_top = explode ("\n", str_replace ("\r", "", $settings['pc_footer_new_top']['value']));
foreach($pc_footer_new_top as $key=>$value){
    $arr=explode('|',$value);
    $pc_footer_new_top_arr[]=$arr;
}

//PC�ײ������ǩ�Ե绰
$pc_footer_new_top_tel=explode('|',$settings['pc_footer_new_top_tel']['value']);

//PC�ײ��绰�Կͷ�
$pc_footer_new_top_kefu=explode('|',$settings['pc_footer_new_top_kefu']['value']);


//PC�ײ�����˵��1����
$pc_footer_new_cron_c1 = explode ("\n", str_replace ("\r", "", $settings['pc_footer_new_cron_c1']['value']));
foreach($pc_footer_new_cron_c1 as $key=>$value){
    $arr=explode('|',$value);
    $pc_footer_new_cron_c1_arr[]=$arr;
}

//PC�ײ�����˵��2����
$pc_footer_new_cron_c2 = explode ("\n", str_replace ("\r", "", $settings['pc_footer_new_cron_c2']['value']));
foreach($pc_footer_new_cron_c2 as $key=>$value){
    $arr=explode('|',$value);
    $pc_footer_new_cron_c2_arr[]=$arr;
}

//PC�ײ�����˵��3����
$pc_footer_new_cron_c3 = explode ("\n", str_replace ("\r", "", $settings['pc_footer_new_cron_c3']['value']));
foreach($pc_footer_new_cron_c3 as $key=>$value){
    $arr=explode('|',$value);
    $pc_footer_new_cron_c3_arr[]=$arr;
}

//PC�ײ�����˵��4����
$pc_footer_new_cron_c4 = explode ("\n", str_replace ("\r", "", $settings['pc_footer_new_cron_c4']['value']));
foreach($pc_footer_new_cron_c4 as $key=>$value){
    $arr=explode('|',$value);
    $pc_footer_new_cron_c4_arr[]=$arr;
}

//PC�ײ�����˵��5����
$pc_footer_new_cron_c5 = explode ("\n", str_replace ("\r", "", $settings['pc_footer_new_cron_c5']['value']));
foreach($pc_footer_new_cron_c5 as $key=>$value){
    $arr=explode('|',$value);
    $pc_footer_new_cron_c5_arr[]=$arr;
}

//�ײ�����˵���Ա߶�ά��
$pc_footer_new_cron_qrcode = explode ("\n", str_replace ("\r", "", $settings['pc_footer_new_cron_qrcode']['value']));
foreach($pc_footer_new_cron_qrcode as $key=>$value){
    $arr=explode('|',$value);
    $pc_footer_new_cron_qrcode_arr[]=$arr;
}

//�������
if($_G['cache']['plugin']['aljhtx']){
    //��ݱ�
    loadcache('express_company', 1);
    if(!$_G['cache']['express_company']) {
        $express_company_list = DB::result_first('select svalue from %t where skey=%s', array('aljhtx_system_setting', 'express_company'));
        savecache('express_company', $express_company_list);
    }else{
        $express_company_list = $_G['cache']['express_company'];
    }
    
    $express_company = unserialize($express_company_list) ? unserialize($express_company_list) : include('source/plugin/aljhtx/config/express_company.php');
    $expressCompanyList = $express_company;
}

//�������ļ��ж�
$u20181224 = 1;
if((stripos($_SERVER['HTTP_USER_AGENT'], 'iPhone')!==false || stripos($_SERVER['HTTP_USER_AGENT'], 'iPad')!==false || stripos($_SERVER['HTTP_USER_AGENT'], 'Android')!==false) && strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
    $yes_wx = 1;
}
if(($_G['cache']['plugin']['aljwx'] || $_G['cache']['plugin']['aljwsq']) && $yes_wx){
    define('IN_MINI', '1');
}

//��������δ������
if($_G['cache']['plugin']['aljol'] && $_G['uid']){
    if(is_file("source/plugin/aljol/table/table_aljol_talk.php")){
        $tableid = '_'.($_G['uid']%10);
        $newscount = DB::result_first('select count(*) from %t where friendid=%d and talkstate=1',array('aljol_talk'.$tableid,$_G['uid']));
    }else{
        $newscount = DB::result_first('select count(*) from %t where friendid=%d and talkstate=1',array('aljol_talk',$_G['uid']));
    }
    $new_noti = DB::result_first('select count(*) from %t where uid=%d and status=0 and news_type=1',array('aljhtx_notification',$_G['uid']));
    $newscount = $newscount + $new_noti;
}
//Ǯ��֧������
$qb_pay_type = array('mywallet'=>lang('plugin/aljbd','aljbd_php_1'),'alipay'=>lang('plugin/aljbd','aljbd_php_2'),'wxpay'=>lang('plugin/aljbd','aljbd_php_3'),'qianfanapp'=>lang('plugin/aljbd','aljbd_php_4'),'magapp'=>lang('plugin/aljbd','aljbd_php_4'),'APP'=>'APP'.lang('plugin/aljbd','aljbd_php_3'));
$oss_domain = $_G['cache']['plugin']['aljoss']['cdn_domain'] ? $_G['cache']['plugin']['aljoss']['cdn_domain'] : $_G['cache']['plugin']['aljoss']['domain'];

if($image_path){
    $path = $image_path;
}else{
    $path = 'source/plugin/aljbd/images/';
}
$pluginurl = 'plugin.php?id=aljbd';
//���� sku �۸� $max=0 ����������ͨ��С�۸� $max = 1 ��������۸� $max = 2 ����Ĭ����ͨ�۸� $max = 3 ��������ר���۸�
function skuminprice($sku,$type=0,$max=0){
    global $_G;
    $sku = unserialize($sku);

    foreach ($sku as $key => $val) {
        if($type == 2){
            $del_min[] = $val['saleprice'];
            $min[] = $val['marketprice'];
        }else{
            $min[] = $val['saleprice'];
        }
        if($val['newprice']>0){
            $newprice[] = $val['newprice'];
        }
    }
    
    $newpricemin = min($newprice);
    $newpricemax = max($newprice);
    $min_price = min($min);
    $max_price = max($min);
    $del_min_price = min($del_min);
    $del_max_price = max($del_min);
    if($max == 1 && $min_price>0 && $max_price>0){
        if($_G['mobile']){
            return array('min_price'=>floatval($min_price),'max_price'=>floatval($max_price),'del_min_price'=>floatval($del_min_price),'del_max_price'=>floatval($del_max_price),'newpricemin'=>$newpricemin,'newpricemax'=>$newpricemax);
        }else{
            return array('min_price'=>$min_price,'max_price'=>$max_price,'del_min_price'=>floatval($del_min_price),'del_max_price'=>floatval($del_max_price),'newpricemin'=>$newpricemin,'newpricemax'=>$newpricemax);
        }
    }else{
        if($min_price>0){
            if($max == 2 && $del_min_price>0){
                return floatval($del_min_price);
            }else if($max == 3 && $newpricemin>0){
                return floatval($newpricemin);
            }else{
                return floatval($min_price);
            }
        }else{
            return 0;
        }
    }
}
//��֤���Ƿ����
if($_G['cache']['plugin']['aljbzj']['is_force_pay']){
    //$bzj_info = DB::fetch_first('select * from %t where uid=%d and bid=%d ',array('aljbzj',$_G['uid'],$bid));
    $bzj_info = DB::fetch_first('select * from %t where bid=%d ',array('aljbzj',$bid));
}
$price_unit = '&#65509;';
$price_symbol = '&#20803;';

function aljbdShowTips($info=array()){
    global $_G,
    $Html5Plusapp,
    $immersed,
    $pc_footer_new_top_arr,
    $pc_footer_new_top_tel,
    $pc_footer_new_top_kefu,
    $pc_footer_new_cron_c1_arr,
    $pc_footer_new_cron_c2_arr,
    $pc_footer_new_cron_c3_arr,
    $pc_footer_new_cron_c4_arr,
    $pc_footer_new_cron_c5_arr,
    $pc_footer_new_cron_qrcode_arr,
    $alltype,
    $index_dh_types,
    $ress,
    $newtemplate,
    $pluginid,
    $common_path,
    $version,
    $common_template_pluginid,
    $settings,
    $mobile_common_footernav_arr;
    if(!$info['desc']){
        $info['desc'] = lang('plugin/aljbd','aljbd_php_13');
    }
    if(!$info['title']){
        $info['title'] = lang('plugin/aljbd','view_php_10');
    }
    if(!$info['icon']){
        $info['icon'] = 'weui-icon-warn';
    }
    if($info['btn_primary']){
        $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_12'), 'url' => 'plugin.php?id=aljbd&act=attend');
    }
    if(!$info['btn_default']){
        $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljbd');
    }
    
    $nosearch = 1;
    $navtitle = $info['title'];
    include template('aljbd:new/common/tips');
    exit;
}
if(file_exists('source/plugin/aljhy/function/function_app.php')){

    require_once DISCUZ_ROOT.'source/plugin/aljhy/function/function_app.php';
    $down_array = download_app();

    $app_dowm = 1;
}

if($_G['cache']['plugin']['aljbdx'] || $_G['cache']['plugin']['aljgwc']){
    //�Ƿ�δ�¹���������
    if($_GET['id'] == 'aljsqtg'){
       $new_price_order_num = DB::result_first('select count(*) from %t where uid=%d and status>1 and status<7 and pid=0 and order_type=7',array('aljbd_goods_order',$_G['uid'])); 
    }else{
        $new_price_order_num = DB::result_first('select count(*) from %t where uid=%d and status>1 and status<7 and pid=0',array('aljbd_goods_order',$_G['uid']));
    }
    if(!$address_id){
        $def_address = DB::fetch_first('SELECT * FROM %t WHERE UID=%d and defaultAddress=1',array('aljbd_address', $_G['uid']));
    }
}
$admingroups = unserialize($_G['cache']['plugin']['aljbd']['managegroups']);
if(in_array($_G['groupid'],$admingroups)){
    $admin_status = 1;
}
$allow_visit = unserialize($_G['cache']['plugin']['aljbd']['allow_visit']);
//���������̳ǵ��û���
if(!in_array($_G['groupid'],$allow_visit) && $allow_visit[0] && $_GET['id'] != 'aljht'){
    
    $no_allow_visit_btn = explode ("\n", str_replace ("\r", "", $settings['no_allow_visit_btn']['value']));
    foreach($no_allow_visit_btn as $key=>$value){
        $arr=explode('|',$value);
        $no_allow_visit_btn_arr[]=$arr;
    }
    
    $desc = $_G['cache']['plugin']['aljbd']['no_allow_visit'];
    $info = array('desc' => $desc);
    if($settings['no_allow_visit_btn']['value']){
        $info['btn_primary'] = array('value' => $no_allow_visit_btn_arr[0][0], 'url' => $no_allow_visit_btn_arr[0][1]);
        $info['btn_default'] = array('value' => $no_allow_visit_btn_arr[1][0], 'url' => $no_allow_visit_btn_arr[1][1]);
    }
    aljbdShowTips($info);
}
$fare_type = array('0'=>lang('plugin/aljbd','aljbd_php_5'),'1'=>lang('plugin/aljbd','aljbd_php_6'),'2'=>lang('plugin/aljbd','aljbd_php_7'),'3'=>'&#35746;&#21333;&#28385;&#22810;&#23569;&#21253;&#37038;');
$bid = intval($_GET['bid']);
$gid = intval($_GET['gid']);
if($gid>0){
    $goods = C::t('#aljbd#aljbd_goods')->fetch($gid);
    $bid = $bid ? $bid : $goods['bid'];
    $store_id = $store_id ? $store_id : $goods['store_id'];
}
$nid = intval($_GET['nid']);
if($nid>0){
    $n=C::t('#aljbd#aljbd_notice')->fetch($nid);
    $bid = $bid ? $bid : $n['bid'];
}
$cid = intval($_GET['cid']);
if($cid>0){
    $n = $c =C::t('#aljbd#aljbd_consume')->fetch($_GET['cid']);
    $bid = $bid ? $bid : $c['bid'];
}
$aid = intval($_GET['aid']);
if($aid>0){
    $apic = $a = C::t('#aljbd#aljbd_album')->fetch($aid);
    $bid = $bid ? $bid : $a['bid'];
}
$vid = intval($_GET['vid']);
if($vid>0){
    $c = $v = C::t('#aljsp#aljbd_video')->fetch($vid);
    $bid = $bid ? $bid : $v['bid'];
}
if($bid>0){
    $bd = C::t('#aljbd#aljbd')->fetch($bid);
}
if($_G['cache']['plugin']['aljtsq']){
    /**
     * ���ص�ǰ�û���Ա��Ϣ
     *
     * @param int $store_id ���� ID
     * @param int $type ���� 1=���� 2=�ŵ�
     *
     * @return array
     */
    function baseStaff ($store_id,$type=1) {
        global $_G;
        if($store_id>0){
            $staff = DB::fetch_first('select * from %t where store_id = %d and st_type=%d and st_uid=%d',array('aljtsq_staff',$store_id,$type,$_G['uid']));
            if($staff){
                $staff['st_staff_authority'] = explode(',',$staff['st_staff_authority']);
            }
        }else{
            $staff = DB::fetch_all('select * from %t where st_type=%d and st_uid=%d',array('aljtsq_staff',$type,$_G['uid']));
        }
        return $staff;
    }
    $staff = baseStaff($bid);
}else{
    function baseStaff ($store_id,$type=1) {}
}
    
$qx_actarray = array(
    'edit',//�༭�̼�
    'goodslist',//��Ʒ�б�
    'addgoods',//������Ʒ
    'editgoods',//�༭��Ʒ
    'deletegoods',//ɾ����Ʒ
    'addnotice',//���ӻ
    'editnotice',//�༭�
    'noticelist',//�����
    'deletenotice',//ɾ���
    'consumelist',//�Ż�ȯ����
    'addconsume',//�����Ż�ȯ
    'editconsume',//�༭�Ż�ȯ
    'deleteconsume',//ɾ���Ż�ȯ
    'addalbum',//�������
    'editalbum',//�༭���
    'albumlist',//������
    'deletealbum',//ɾ�����
    'albumall',//�������ͼƬ
    'addalbumimg',//����ͼƬ
    'addvideo',//������Ƶ
    'editvideo',//�༭��Ƶ
    'videolist',//��Ƶ����
    'deletevideo',//ɾ����Ƶ
    'orderlist',//��������
);
$sj_array = array(
    'edit',//�༭�̼�
);
if(in_array($_GET['act'],$sj_array)){
    $in_a = 'staff_bjdp';
}
$sp_array = array(
    'goodslist',//��Ʒ�б�
    'addgoods',//������Ʒ
    'editgoods',//�༭��Ʒ
    'attr',//��Ʒ���
    'deletegoods',//ɾ����Ʒ
    'btype',//���ӵ�����Ʒ����
);
if(in_array($_GET['act'],$sp_array) || in_array($_GET['do'],$sp_array)){
    $in_a = 'staff_spgl';
}
$qx_doarray = array(
    'attr',//��Ʒ���
    'btype',//���ӵ�����Ʒ����
);
$hd_array = array(
    'addnotice',//���ӻ
    'editnotice',//�༭�
    'noticelist',//�����
    'deletenotice',//ɾ���
);
if(in_array($_GET['act'],$hd_array)){
    $in_a = 'staff_hdgl';
}
$yhj_array = array(
    'addconsume',//�����Ż�ȯ
    'editconsume',//�༭�Ż�ȯ
    'consumelist',//�Ż�ȯ����
    'deleteconsume',//ɾ���Ż�ȯ
);
if(in_array($_GET['act'],$yhj_array)){
    $in_a = 'staff_yhjgl';
}
$xc_array = array(
    'addalbum',//�������
    'editalbum',//�༭���
    'albumlist',//������
    'deletealbum',//ɾ�����
    'albumall',//�������ͼƬ
    'addalbumimg',//����ͼƬ
);
if(in_array($_GET['act'],$xc_array)){
    $in_a = 'staff_xcgl';
}
$video_array = array(
    'addvideo',//������Ƶ
    'editvideo',//�༭��Ƶ
    'videolist',//��Ƶ����
    'deletevideo',//ɾ����Ƶ
);
if(in_array($_GET['act'],$video_array)){
    $in_a = 'staff_videogl';
}
$dj_array = array(
    'dianp',//���̶���
);
if(in_array($_GET['ord'],$dj_array)){
    $in_a = 'staff_ddgl';
}

if(in_array($_GET['act'],$qx_actarray) || in_array($_GET['do'],$qx_doarray) || in_array($_GET['ord'],$dj_array)){
    if($bd && $bd['uid'] != $_G['uid'] && !$admin_status && !in_array($in_a,$staff['st_staff_authority']) && $_GET['do'] != 'ajax'){
        $desc = lang('plugin/aljbd','aljbd_7');
        $info = array('desc' => $desc);
        $info['btn_primary'] = array('value' => lang('plugin/aljbd','aljbd_php_12'), 'url' => 'plugin.php?id=aljbd&act=attend');
        $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljbd');
        aljbdShowTips($info);
    }
}
//PC ��ҳ����ж�
if(!$_G['mobile']){
    $no_max_page = 1;
}
if($_G['cache']['plugin']['aljoss']){
    $oss_img_url = '?x-oss-process=image/auto-orient,1';
}
if($imgnum == 12){
    $pics = array('pic1','pic2','pic3','pic4','pic5','pic6','pic7','pic8','pic9','pic10','pic11','pic12');
}else{
    $pics = array('pic1','pic2', 'pic3', 'pic4', 'pic5');
}
function bd_message($msg, $type='',$url = ''){
    if($_SERVER['REQUEST_METHOD'] == 'POST') {
        echo "<script>parent.tips('".$msg."','".$url."','".$type."');</script>";
		exit;
    }else{
        return $msg;
    }
    return false;
}
$aljtsq_post_goods = $_GET['store'] == 'yes' && $_G['cache']['plugin']['aljtsc']['is_aljtsc'] ? 1 : 0;//�ŵ귢����Ʒ
$store_id = $store_id>0 ? $store_id : intval($_GET['store_id']);

if($store_id>0){
    $bd = C::t('#aljtsq#aljtsq_store')->fetch($store_id);
    $bd[status] = $bd['tc_status'];
    $store_id_url = '&store_id='.$store_id;
    
}

if($aljtsq_post_goods){
    $aljtsq_post_goods_url = '&store=yes';
    
    $pluginurl = $pluginurl.$aljtsq_post_goods_url;
    $aljbd = DB::result_first('select count(*) from %t where tc_uid=%d',array('aljtsq_store',$_G['uid']));
}

if((($store_id>0 && $_GET[act] == 'goodview') || $aljtsq_post_goods) && $_GET['dzAdmin'] != 1 && !$_G['mobile']){
    
    if(strtolower(CHARSET) == 'gbk'){
		$_GET=T::ajaxGetCharSet($_GET);
    }
    define('IN_MOBILE', 2);
	$_G['mobile'] = 2;
}

if($_G['cache']['plugin']['aljtcc']){
    $card_user = DB::fetch_first('select * from %t where uid=%d and end_time>%d and card_id=1',array('aljtcc_card_user',$_G['uid'],TIMESTAMP));
    $card_info = DB::fetch_first('select * from %t where id=%d ',array('aljtcc_card',1));
}

$card_price_label = $settings['card_price_label']['value'] ? $settings['card_price_label']['value'] : lang('plugin/aljbd','card_price');
if($_GET['dd'] == 1 && $bid>0){
    //$dp_bid_url = '&dd=1&bid='.$bid;
}

if($_GET['mtype'] == 'pt' || $_GET['act'] == 'search'){
    if(!$_G['mobile']){
        dsetcookie('mobile_search', 1,86400);
    }
    if(strtolower(CHARSET) == 'gbk' && $_GET['act'] != 'search'){
		$_GET=T::ajaxGetCharSet($_GET);
    }
    define('IN_MOBILE', 2);
    $_G['mobile'] = 2;
}

function createOrderSn(){  
    $sn = 'LJ_'.date('ymds').mt_rand(1000,9999);
    $mod = DB::result_first('select count(*) from %t where commodity_code=%s',array('aljbd_goods',$sn));
    return $mod?createOrderSn():$sn;//�����Ʒ�����ظ�����������  
}
//һ����Ʒ����
if($aljtsq_post_goods){
    $onetype = C::t('#aljtsc#aljtsc_type')->fetch_all_by_upid(0);
}else{
    $onetype = DB::fetch_all('select * from %t where upid=0 and is_open=0 order by displayorder asc ',array('aljbd_type_goods'));
}
$newtemplate = $_G['cache']['plugin']['aljhtx'] && $_G['mobile'] ? true : false;
?>