<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($bd['status']!=1 && !$admin_status){
    
    if($bd['status'] == 0){
        $desc = lang('plugin/aljbd','view_php_11');
        $info = array('desc' => $desc);
        $info['title'] = $navtitle;
        $info['icon'] = 'weui-icon-warn';
        if($_G['uid'] == $bd['uid'] || $_G['groupid'] == 1){
            $info['btn_primary'] = array('value' => lang('plugin/aljbd','view_php_12'), 'url' => 'plugin.php?id=aljbd&act=edit&bid='.$bd['id']);
        }else{
            $info['btn_primary'] = array('value' => lang('plugin/aljbd','view_php_13'), 'url' => 'plugin.php?id=aljbd&act=dianpu');
        }
    }elseif($bd['status'] == 2){
        $desc = lang('plugin/aljbd','view_php_14');
        $info = array('desc' => $desc);
        $info['title'] = $navtitle;
        $info['icon'] = 'weui-icon-warn';
        if($_G['uid'] == $bd['uid'] || $_G['groupid'] == 1){
            $info['btn_primary'] = array('value' => lang('plugin/aljbd','view_php_15'), 'url' => 'plugin.php?id=aljbdx&act=pay&bid='.$bd['id'].'&vipid='.$bd['vipid']);
        }else{
            $info['btn_primary'] = array('value' => lang('plugin/aljbd','view_php_13'), 'url' => 'plugin.php?id=aljbd&act=dianpu');
        }
    }elseif($bd['status'] >2){
        $desc = lang('plugin/aljbd','view_php_16');
        $info = array('desc' => $desc);
        $info['title'] = $navtitle;
        $info['icon'] = 'weui-icon-warn';
        $info['btn_primary'] = array('value' => lang('plugin/aljbd','view_php_13'), 'url' => 'plugin.php?id=aljbd&act=dianpu');
    }
    
    $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljbd');
    aljbdShowTips($info);
}
?>