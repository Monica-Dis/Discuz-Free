<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
$plugin = DB::fetch_first('select * from %t where identifier = %s', array('common_plugin', 'aljhtx'));
if(empty($plugin)){
    cpmsg('&#35831;&#20808;&#23433;&#35013;&#21830;&#23478;&#21161;&#25163;&#25554;&#20214;');
}
$plugin = DB::fetch_first('select * from %t where identifier = %s and available=1', array('common_plugin', 'aljhtx'));
if(empty($plugin)){
    cpmsg('&#35831;&#20808;&#21551;&#29992;&#21830;&#23478;&#21161;&#25163;&#25554;&#20214;');
}
if($_G['cache']['plugin']['aljht']['on']){
	echo '<iframe style="width:100%;height:100%;min-height:760px;border:none;" src="plugin.php?id=aljhtx&c=aljbd&a=order&type=5&twok=12&ajax=yes&dzAdmin=1"></iframe>';
	exit;
}
$pluginid='aljbd';
include template('aljbd:type_nav');

/**
 * @param $gotable ��Դ��
 * @param $totable �����
 */
function tableGoTo($gotable,$totable){
    $sql = 'insert into '.DB::table($totable).'(id,upid,subid,subject,displayorder) select id,upid,subid,subject,displayorder from '.DB::table($gotable);
    DB::query($sql);
}
if($_GET['act'] == 'emptytable'){
    $totable = $_GET['totable'];
    if(!$_GET['totable']){
        cpmsg('&#34920;&#19981;&#33021;&#20026;&#31354;');
    }
    $sql='TRUNCATE TABLE '.DB::table($totable);
    DB::query($sql);
    cpmsg(lang('plugin/aljbd','s10'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljbd&pmod=brandtype&lj='.$_GET['lj']);
}if($_GET['act'] == 'import'){
    if(!$_GET['gotable'] || !$_GET['totable']){
        cpmsg('&#34920;&#19981;&#33021;&#20026;&#31354;');
    }
    $gotable = $_GET['gotable'];
    $totable = $_GET['totable'];
    if(DB::result_first('select count(*) from %t ',array($totable))){
        cpmsg('&#23548;&#20837;&#20998;&#31867;&#38656;&#35201;&#20808;&#28165;&#31354;&#26412;&#20998;&#31867;&#25968;&#25454;');
    }
    tableGoTo($gotable,$totable);
    cpmsg(lang('plugin/aljbd','s10'), 'action=plugins&operation=config&identifier=aljbd&pmod=brandtype&lj='.$_GET['lj'], 'succeed');
}else if($_GET['act'] == 'uploadimg'){
    $_GET['op'] = intval($_GET['op']);
    $FILES = $_FILES['sublogo_'.$_GET['op']];
    $config['img_size'] = '2048';
    $img_size = $config['img_size'];
    $newpics = date("YmdHis");
    $route = "source/plugin/aljbd/images/typelogo/". $newpics;
    if (!is_dir($route)) {
        mkdir($route);
    }
    $picname = $FILES['name'];
    $picsize = $FILES['size'];

    if ($picname != "") {
        $type = strtolower(strrchr($picname, '.'));
        if ($type != ".gif" && $type != ".jpg" && $type != ".png" && $type != ".jpeg") {
            cpmsg('&#26684;&#24335;&#19981;&#23545;');

        }
        if (($picsize/1024)>$img_size) {
            cpmsg('&#19978;&#20256;&#22270;&#29255;&#19981;&#33021;&#36229;&#36807;'.$config['img_size'].'K');
        }
        $rand = rand(100, 999);
        $pics = date("YmdHis") . $rand . $type;
        $logo = $route . $pics;
        if(@copy($FILES['tmp_name'], $logo)||@move_uploaded_file($FILES['tmp_name'], $logo)){
            @unlink($FILES['tmp_name']);
        }
        if($logo){
            $updatearray['logo'] = $logo;
            C::t('#aljbd#aljbd_type_goods')->update($_GET['op'],$updatearray);
        }
    }
    echo "<script>parent.stopSend('$logo','".$_GET['op']."')</script>";
    exit;
}else if($_GET['lj']=='noticetype'){
	$act = $_GET['act'];
	if($act == 'del') {
		$tid = intval($_GET['tid']);
		if($tid) {
			$upcid = C::t('#aljbd#aljbd_type_notice')->fetch_upid_by_id($tid);
			if($upcid) {
				$subid = C::t('#aljbd#aljbd_type_notice')->fetch_subid_by_id($upcid);
				$subarr = explode(",", $subid);
				foreach($subarr as $key=>$value) {
					if($value == $tid) {
						unset($subarr[$key]);
						break;
					}
				}
				C::t('#aljbd#aljbd_type_notice')->update($upcid,array('subid'=>implode(",", $subarr)));
			}
			C::t('#aljbd#aljbd_type_notice')->delete($tid);
		}
		cpmsg(lang('plugin/aljbd','s1'), 'action=plugins&operation=config&identifier=aljbd&pmod=brandtype&lj=noticetype', 'succeed');	
	}

	if(!submitcheck('editsubmit')) {	

	?>
	<script type="text/JavaScript">
	var rowtypedata = [
		[[1,'&nbsp;', 'td25'],[1,'<input type="text" class="txt" name="newcatorder[]" value="0" />', 'td25'], [2, '<input name="newcat[]" value="" size="20" type="text" class="txt" />']],
		[[1,'&nbsp;', 'td25'],[1,'<input type="text" class="txt" name="newsuborder[{1}][]" value="0" />', 'td25'], [2, '<div class="board"><input name="newsubcat[{1}][]" value="" size="20" type="text" class="txt" /></div>']],
		
		];

	function del(id) {
		if(confirm('<?php echo lang('plugin/brand', 'del_confirm');?>')) {
			window.location = '<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=aljbd&pmod=brandtype&lj=noticetype&act=del&tid='+id;
		} else {
			return false;
		}
	}
	</script>
	<?php
		showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier=aljbd&pmod=brandtype&lj=noticetype');
		showtableheader('');
		showsubtitle(array(lang('plugin/aljbd','s2'),lang('plugin/aljbd','s3'),  lang('plugin/aljbd','s4')));

		$brandtype = C::t('#aljbd#aljbd_type_notice')->fetch_all_by_upid(0);
		foreach($brandtype as $key=>$value){

			$bt = C::t('#aljbd#aljbd_type_notice')->fetch_all_by_upid($key);
			foreach($bt as $k=>$v){
				$brandtype[$key]['subtype'][$k] = $v;
			}
		}
		if($brandtype) {
			foreach($brandtype as $id=>$type) {
				$show = '<tr class="hover"><td  class="td25" onclick="toggle_group(\'group_'.$id.'\', $(\'a_group_'.$id.'\'))"><a id="a_group_'.$id.'" href="javascript:;">[-]</a></td><td class="td25"><input type="text" class="txt" name="order['.$id.']" value="'.$type['displayorder'].'" /></td><td><div class="parentboard"><input type="text" class="txt" name="name['.$id.']" value="'.$type['subject'].'"></div></td>';
				if(!$type['subid']) {
					$show .= '<td><a  onclick="del('.$id.')" href="###">'.lang('plugin/aljbd','s5').'</td></tr><tbody id="group_'.$id.'">';
				} else {
					$show .= '<td>&nbsp;</td></tr><tbody id="group_'.$id.'">';
				}
				echo $show;
				if($type['subtype']) {
					foreach($type['subtype'] as $subid=>$stype) {
						echo '<tr class="hover"><td  class="td25">&nbsp;</td><td class="td25"><input type="text" class="txt" name="order['.$subid.']" value="'.$stype['displayorder'].'" /></td><td><div class="board"><input type="text" class="txt" name="name['.$subid.']" value="'.$stype['subject'].'"></div></td><td><a  onclick="del('.$subid.')" href="###">'.lang('plugin/aljbd','s6').'</td></tr>';
					}
					
				}
				echo '<tr class="hover" ><td class="td25">&nbsp;</td><td colspan="2" ><div class="lastboard"><a href="###" onclick="addrow(this, 1,'.$id.' )" class="addtr">'.lang('plugin/aljbd','s7').'</a></div></td></tr></tbody>';
			}	
		}
		echo '<tr class="hover"><td class="td25">&nbsp;</td><td colspan="2" ><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.lang('plugin/aljbd','s8').'</a></div></td></tr>';
		

		showsubmit('editsubmit');
		showtablefooter(); /*dism _taobao _com*/
		showformfooter(); /*dism_taobao_com*/

	} else {
		$order = $_GET['order'];
		$name = $_GET['name'];
		$newsubcat = $_GET['newsubcat'];
		$newcat = $_GET['newcat'];
		$newsuborder = $_GET['newsuborder'];
		$newcatorder = $_GET['newcatorder'];
		if(is_array($order)) {
			foreach($order as $id=>$value) {
				C::t('#aljbd#aljbd_type_notice')->update($id,array('displayorder'=>$value,'subject'=>$name[$id]));
			}
		}

		if(is_array($newcat)) {
			foreach($newcat as $key=>$name) {
				if(empty($name)) {
					continue;
				}
				$cid=C::t('#aljbd#aljbd_type_notice')->insert(array('upid' => '0', 'subject' => $name, 'displayorder' => $newcatorder[$key]),1);
			}
		}

		if(is_array($newsubcat)) {
			foreach($newsubcat as $cid=>$subcat) {
				$sub=C::t('#aljbd#aljbd_type_notice')->fetch($cid);
				$subtype =$sub['subid'];
				foreach($subcat as $key=>$name) {
					$subid=C::t('#aljbd#aljbd_type_notice')->insert(array('upid' => $cid, 'subject' => $name, 'displayorder' => $newsuborder[$cid][$key]),1);
					$subtype .= $subtype ? ','.$subid : $subid;
				}
				C::t('#aljbd#aljbd_type_notice')->update($cid,array('subid'=>$subtype));
			}
		}

		cpmsg(lang('plugin/aljbd','s9'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljbd&pmod=brandtype&lj=noticetype', 'succeed');	
	}
}else if($_GET['lj']=='consumetype'){
	$act = $_GET['act'];
	if($act == 'del') {
		$tid = intval($_GET['tid']);
		if($tid) {
			$upcid = C::t('#aljbd#aljbd_type_consume')->fetch_upid_by_id($tid);
			if($upcid) {
				$subid = C::t('#aljbd#aljbd_type_consume')->fetch_subid_by_id($upcid);
				$subarr = explode(",", $subid);
				foreach($subarr as $key=>$value) {
					if($value == $tid) {
						unset($subarr[$key]);
						break;
					}
				}
				C::t('#aljbd#aljbd_type_consume')->update($upcid,array('subid'=>implode(",", $subarr)));
			}
			C::t('#aljbd#aljbd_type_consume')->delete($tid);
		}
		cpmsg(lang('plugin/aljbd','s1'), 'action=plugins&operation=config&identifier=aljbd&pmod=brandtype&lj=consumetype', 'succeed');	
	}

	if(!submitcheck('editsubmit')) {	

	?>
	<script type="text/JavaScript">
	var rowtypedata = [
		[[1,'&nbsp;', 'td25'],[1,'<input type="text" class="txt" name="newcatorder[]" value="0" />', 'td25'], [2, '<input name="newcat[]" value="" size="20" type="text" class="txt" />']],
		[[1,'&nbsp;', 'td25'],[1,'<input type="text" class="txt" name="newsuborder[{1}][]" value="0" />', 'td25'], [2, '<div class="board"><input name="newsubcat[{1}][]" value="" size="20" type="text" class="txt" /></div>']],
		
		];

	function del(id) {
		if(confirm('<?php echo lang('plugin/brand', 'del_confirm');?>')) {
			window.location = '<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=aljbd&pmod=brandtype&lj=consumetype&act=del&tid='+id;
		} else {
			return false;
		}
	}
	</script>
	<?php
		showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier=aljbd&pmod=brandtype&lj=consumetype');
		showtableheader('');
		showsubtitle(array(lang('plugin/aljbd','s2'),lang('plugin/aljbd','s3'),  lang('plugin/aljbd','s4')));

		$brandtype = C::t('#aljbd#aljbd_type_consume')->fetch_all_by_upid(0);
		foreach($brandtype as $key=>$value){

			$bt = C::t('#aljbd#aljbd_type_consume')->fetch_all_by_upid($key);
			foreach($bt as $k=>$v){
				$brandtype[$key]['subtype'][$k] = $v;
			}
		}
		if($brandtype) {
			foreach($brandtype as $id=>$type) {
				$show = '<tr class="hover"><td  class="td25" onclick="toggle_group(\'group_'.$id.'\', $(\'a_group_'.$id.'\'))"><a id="a_group_'.$id.'" href="javascript:;">[-]</a></td><td class="td25"><input type="text" class="txt" name="order['.$id.']" value="'.$type['displayorder'].'" /></td><td><div class="parentboard"><input type="text" class="txt" name="name['.$id.']" value="'.$type['subject'].'"></div></td>';
				if(!$type['subid']) {
					$show .= '<td><a  onclick="del('.$id.')" href="###">'.lang('plugin/aljbd','s5').'</td></tr><tbody id="group_'.$id.'">';
				} else {
					$show .= '<td>&nbsp;</td></tr><tbody id="group_'.$id.'">';
				}
				echo $show;
				if($type['subtype']) {
					foreach($type['subtype'] as $subid=>$stype) {
						echo '<tr class="hover"><td  class="td25">&nbsp;</td><td class="td25"><input type="text" class="txt" name="order['.$subid.']" value="'.$stype['displayorder'].'" /></td><td><div class="board"><input type="text" class="txt" name="name['.$subid.']" value="'.$stype['subject'].'"></div></td><td><a  onclick="del('.$subid.')" href="###">'.lang('plugin/aljbd','s6').'</td></tr>';
					}
					
				}
				echo '<tr class="hover"><td class="td25">&nbsp;</td><td colspan="2" ><div class="lastboard"><a href="###" onclick="addrow(this, 1,'.$id.' )" class="addtr">'.lang('plugin/aljbd','s7').'</a></div></td></tr></tbody>';
			}	
		}
		echo '<tr class="hover"><td class="td25">&nbsp;</td><td colspan="2" ><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.lang('plugin/aljbd','s8').'</a></div></td></tr>';
		

		showsubmit('editsubmit');
		showtablefooter(); /*dism _taobao _com*/
		showformfooter(); /*dism_taobao_com*/

	} else {
		$order = $_GET['order'];
		$name = $_GET['name'];
		$newsubcat = $_GET['newsubcat'];
		$newcat = $_GET['newcat'];
		$newsuborder = $_GET['newsuborder'];
		$newcatorder = $_GET['newcatorder'];
		if(is_array($order)) {
			foreach($order as $id=>$value) {
				C::t('#aljbd#aljbd_type_consume')->update($id,array('displayorder'=>$value,'subject'=>$name[$id]));
			}
		}

		if(is_array($newcat)) {
			foreach($newcat as $key=>$name) {
				if(empty($name)) {
					continue;
				}
				$cid=C::t('#aljbd#aljbd_type_consume')->insert(array('upid' => '0', 'subject' => $name, 'displayorder' => $newcatorder[$key]),1);
			}
		}

		if(is_array($newsubcat)) {
			foreach($newsubcat as $cid=>$subcat) {
				$sub=C::t('#aljbd#aljbd_type_consume')->fetch($cid);
				$subtype =$sub['subid'];
				foreach($subcat as $key=>$name) {
					$subid=C::t('#aljbd#aljbd_type_consume')->insert(array('upid' => $cid, 'subject' => $name, 'displayorder' => $newsuborder[$cid][$key]),1);
					$subtype .= $subtype ? ','.$subid : $subid;
				}
				C::t('#aljbd#aljbd_type_consume')->update($cid,array('subid'=>$subtype));
			}
		}

		cpmsg(lang('plugin/aljbd','s9'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljbd&pmod=brandtype&lj=consumetype', 'succeed');	
	}
}else if($_GET['lj']=='goodstype'){
	$act = $_GET['act'];
	if($act == 'del') {
		$tid = intval($_GET['tid']);
		if($tid) {
			$upcid = C::t('#aljbd#aljbd_type_goods')->fetch_upid_by_id($tid);
			if($upcid) {
				$subid = C::t('#aljbd#aljbd_type_goods')->fetch_subid_by_id($upcid);
				$subarr = explode(",", $subid);
				foreach($subarr as $key=>$value) {
					if($value == $tid) {
						unset($subarr[$key]);
						break;
					}
				}
				C::t('#aljbd#aljbd_type_goods')->update($upcid,array('subid'=>implode(",", $subarr)));
			}
			C::t('#aljbd#aljbd_type_goods')->delete($tid);
			$upids = C::t('#'.$pluginid.'#'.$pluginid.'_type_goods')->fetch_all_by_upid($tid,$start,$perpage,$search);
			if($upids){
                foreach($upids as $uk => $uv){
                    $uupids = C::t('#'.$pluginid.'#'.$pluginid.'_type_goods')->fetch_all_by_upid($uv['id'],$start,$perpage,$search);
                    if($uupids){
                        foreach($uupids as $uuk => $uuv){
                            C::t('#aljbd#aljbd_type_goods')->delete($uuv['id']);
                        }
                    }
                    C::t('#aljbd#aljbd_type_goods')->delete($uv['id']);
                }
            }
		}
		cpmsg(lang('plugin/aljbd','s1'), 'action=plugins&operation=config&identifier=aljbd&pmod=brandtype&lj=goodstype', 'succeed');	
	}

	if(!submitcheck('editsubmit')) {	

	?>

	<script type="text/JavaScript">
	var rowtypedata = [
		[[1,'<input type="text" class="txt" name="newcatorder[]" value="0" />', 'td25'], [2, '<input name="newcat[]" value="" size="20" type="text" class="txt" />']],
		[[1,'<input type="text" class="txt" name="newsuborder[{1}][]" value="0" />', 'td25'], [2, '<div ><input name="newsubcat[{1}][]" value="" size="20" type="text" class="txt" /></div>']],
		[[1,'<input type="text" class="txt" name="newsuborder[{1}][]" value="0" />', 'td25'], [1, '<div ><input name="newsubcat[{1}][]" value="" size="20" type="text" class="txt" /></div>'], [2, '<input name="newsublogo[{1}][]" value=""  type="file"  />']],
		];

	function del(id,tip) {
		if(confirm(tip)) {
			window.location = '<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $_GET['do'];?>&identifier=aljbd&pmod=brandtype&lj=goodstype&act=del&tid='+id;
		} else {
			return false;
		}
	}


	</script>
	<?php
		showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier=aljbd&pmod=brandtype&lj=goodstype&page='.$_GET['page'].'&two='.$_GET['two'].'&upid='.$_GET['upid'],'enctype');
		if($goods_type = C::t('#'.$pluginid.'#'.$pluginid.'_type_goods')->fetch($_GET['upid'])){
		    if(!$_GET['two']){
		        $upidu = '&upid='.$goods_type['upid'];
		        $two1 = '&two=yes';
            }else{
                $two = '&two='.$_GET['two'];
            }
            $tips = '&#19978;&#32423;&#30446;&#24405;&#26159;&nbsp;'.$goods_type['subject'].'&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljbd&pmod=brandtype&lj=goodstype'.$two1.$upidu.'">&#36820;&#22238;&#19978;&#19968;&#32423;</a>&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljbd&pmod=brandtype&lj=goodstype'.$two.'&upid='.$_GET['upid'].'">&#21047;&#26032;&#26412;&#39029;</a>';
        }
		showtableheader($tips);
		showsubtitle(array(lang('plugin/aljbd','s2'),lang('plugin/aljbd','s3'),'LOGO' ,'&#112;&#99;&#25512;&#33616;&#26631;&#31614;','&#25512;&#33616;&#21697;&#29260;','&#36718;&#36716;&#24191;&#21578;',  lang('plugin/aljbd','s4')));
		$currpage = $_GET['page'] ? $_GET['page'] : 1;
		$perpage = 10;
		$start = ($currpage - 1) * $perpage;
		$num=C::t('#'.$pluginid.'#'.$pluginid.'_type_goods')->count_by_upid($_GET['upid'],$search);
		$brandtype = C::t('#'.$pluginid.'#'.$pluginid.'_type_goods')->fetch_all_by_upid($_GET['upid'],$start,$perpage,$search);
        if(!$_GET['upid']){
            $addrow = 0;
            $tip = '&#24744;&#30830;&#23450;&#35201;&#21024;&#38500;&#21527;&#65311;&#30830;&#35748;&#21024;&#38500;&#23558;&#20108;&#32423;&#19982;&#19977;&#32423;&#20998;&#31867;&#19968;&#36215;&#21024;&#38500;&#65281;&#21024;&#38500;&#21518;&#19981;&#21487;&#24674;&#22797;&#65281;';
        }elseif($_GET['two']){
            $addrow = 1;
            $tip = '&#24744;&#30830;&#23450;&#35201;&#21024;&#38500;&#21527;&#65311;&#30830;&#35748;&#21024;&#38500;&#23558;&#19977;&#32423;&#20998;&#31867;&#19968;&#36215;&#21024;&#38500;&#65281;&#21024;&#38500;&#21518;&#19981;&#21487;&#24674;&#22797;&#65281;';
        }else{
            $addrow = 2;
            $tip = '&#24744;&#30830;&#23450;&#35201;&#21024;&#38500;&#21527;&#65311;&#21024;&#38500;&#21518;&#19981;&#21487;&#24674;&#22797;&#65281;';
        }
        if($brandtype) {
            foreach($brandtype as $id=>$type) {
                $show = '<tr class="hover"><td class="td25"><input type="text" class="txt" name="order['.$id.']" value="'.$type['displayorder'].'" /></td><td><div class="parentboard"><input type="text" class="txt" name="name['.$id.']" value="'.$type['subject'].'"></div></td>';
                if(!$_GET['upid']){
                    if($type['logo']){
                        $typelogo='<img src="'.$type['logo'].'" style="width:30px;" />&nbsp;&nbsp;<input name="sublogo['.$id.']"   type="file"  style="width:100px"/>';
                    }else{
                        $typelogo='&nbsp;&nbsp;<input name="sublogo['.$id.']"   type="file" style="width:100px"/></td>';
                    }
                    $pclabel = '<textarea class="" cols="30"  name="pclabel['.$id.']" onkeydown="textareakey(this, event)" id="varsnew[pclabel]"  ondblclick="textareasize(this, 1)" rows="4" placeholder="&#26684;&#24335;&#65306;&#25991;&#23383;&#124;&#38142;&#25509;&#65292;&#19968;&#34892;&#19968;&#20010;">'.$type['pclabel'].'</textarea>';
                    $textarea = '<textarea class="" cols="30"  name="brand_id['.$id.']" onkeydown="textareakey(this, event)" id="varsnew[brand_id]"  ondblclick="textareasize(this, 1)" rows="4" placeholder="&#22635;&#20889;&#21830;&#23478;&#73;&#68;&#44;&#22810;&#20010;&#20197;&#33521;&#25991;&#36887;&#21495;&#20998;&#38548;&#44;&#20998;&#31867;&#19979;&#26041;&#35843;&#29992;&#26174;&#31034;">'.$type['brand_id'].'</textarea>';
                    $textarea_ad = '<textarea class="" cols="30"  name="type_ad['.$id.']" onkeydown="textareakey(this, event)" id="varsnew[type_ad]"  ondblclick="textareasize(this, 1)" rows="4" placeholder="&#26684;&#24335;&#65306;&#22270;&#29255;&#36335;&#24452;&#124;&#22270;&#29255;&#38142;&#25509;&#124;&#22270;&#29255;&#25551;&#36848;&#65292;&#19968;&#34892;&#19968;&#20010;">'.$type['type_ad'].'</textarea>';
                    $text = '&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljbd&pmod=brandtype&lj=goodstype&two=yes&upid='.$id.'">&#26597;&#30475;&#20108;&#32423;&#20998;&#31867;</a>';
                }elseif($_GET['two']){
                    $text = '&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljbd&pmod=brandtype&lj=goodstype&upid='.$id.'">&#26597;&#30475;&#19977;&#32423;&#20998;&#31867;</a>';
                }else{
                    if($type['logo']){
                        $typelogo='<img src="'.$type['logo'].'" style="width:30px;" />&nbsp;&nbsp;<input name="sublogo['.$id.']"   type="file" style="width:100px" />';
                    }else{
                        $typelogo='&nbsp;&nbsp;<input name="sublogo['.$id.']"   type="file" style="width:100px"/></td>';
                    }
                }

                $show .= '<td>'.$typelogo.'</td><td>'.$pclabel.'</td><td>'.$textarea.'</td><td>'.$textarea_ad.'</td><td><a  onclick="del('.$id.',\''.$tip.'\')" href="###">'.lang('plugin/aljbd','s5').'</a>'.$text.'</td></tr>';

                echo $show;
            }
        }
        if(!$_GET['upid']){
            $_GET['upid'] = 0;
        }
        echo '<tr class="hover"><td class="td25">&nbsp;</td><td colspan="2" ><div><a href="###" onclick="addrow(this,'.$addrow.','.$_GET['upid'].')" class="addtr">'.lang('plugin/aljbd','s8').'</a></div></td></tr>';

		$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT."?action=plugins&operation=config&do=".$_GET['do']."&identifier=".$pluginid."&pmod=brandtype&lj=goodstype&two=".$_GET['two']."&upid=".$_GET['upid'], 0, 10, false, false);
		showsubmit('editsubmit','&#25552;&#20132;','','',$paging);
		showtablefooter(); /*dism _taobao _com*/
		showformfooter(); /*dism_taobao_com*/

	} else {
		$order = $_GET['order'];
		$name = $_GET['name'];
		$newsubcat = $_GET['newsubcat'];
		$newcat = $_GET['newcat'];
		$newsuborder = $_GET['newsuborder'];
		$newcatorder = $_GET['newcatorder'];

		if(is_array($order)) {
			foreach($order as $id=>$value) {
				C::t('#aljbd#aljbd_type_goods')->update($id,array('displayorder'=>$value,'subject'=>$name[$id],'pclabel'=>$_GET['pclabel'][$id],'brand_id'=>$_GET['brand_id'][$id],'type_ad'=>$_GET['type_ad'][$id]));

                if($_FILES['sublogo']['tmp_name'][$id]){
                    $picname = $_FILES['sublogo']['name'][$id];
                    $picsize = $_FILES['sublogo']['size'][$id];

                    if ($picname != "") {
                        $type = strtolower(strrchr($picname, '.'));
                        if ($type!= ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {

                            continue;

                        }

                        $rand = rand(100, 999);
                        $pics = date("YmdHis") . $rand . $type;
                        $route = "source/plugin/aljbd/images/typelogo/".date("Ymd")."/";
                        if (!is_dir($route)) {
                            mkdir($route);
                        }
                        $logo = $route. $pics;
                        if(@copy($_FILES['sublogo']['tmp_name'][$id], $logo)||@move_uploaded_file($_FILES['sublogo']['tmp_name'][$id], $logo)){

                            @unlink($_FILES['sublogo']['tmp_name'][$id]);
                        }
                    }
                }

                if($logo){
                    $updatearray['logo'] = $logo;
                    C::t('#aljbd#aljbd_type_goods')->update($id,$updatearray);
                }
                unset($logo);
			}
		}

		if(is_array($newcat)) {
			foreach($newcat as $key=>$name) {
				if(empty($name)) {
					continue;
				}
				$cid=C::t('#aljbd#aljbd_type_goods')->insert(array('upid' => '0', 'subject' => $name, 'displayorder' => $newcatorder[$key]),1);
			}
		}

		if(is_array($newsubcat)) {
			foreach($newsubcat as $cid=>$subcat) {
				$sub=C::t('#aljbd#aljbd_type_goods')->fetch($cid);
				$subtype =$sub['subid'];
				foreach($subcat as $key=>$name) {
                    if(empty($name)) {
                        continue;
                    }
                    if($_FILES['newsublogo']['tmp_name'][$cid][$key]){
                        $newpicname = $_FILES['newsublogo']['name'][$cid][$key];
                        $newpicsize = $_FILES['newsublogo']['size'][$cid][$key];

                        if ($newpicname != "") {
                            $newtype = strtolower(strrchr($newpicname, '.'));
                            if ($newtype!= ".gif" && $newtype != ".jpg"&& $newtype != ".png"&& $newtype != ".jpeg") {

                                continue;

                            }

                            $newrand = rand(100, 999);
                            $newpics = date("YmdHis") . $newrand . $newtype;
                            $route = "source/plugin/aljbd/images/typelogo/".date("Ymd")."/";
                            if (!is_dir($route)) {
                                mkdir($route);
                            }
                            $newlogo = $route. $newpics;
                            if(@copy($_FILES['newsublogo']['tmp_name'][$cid][$key], $newlogo)||@move_uploaded_file($_FILES['newsublogo']['tmp_name'][$cid][$key], $newlogo)){

                                @unlink($_FILES['newsublogo']['tmp_name'][$cid][$key]);
                            }
                        }
                    }
					$subid=C::t('#aljbd#aljbd_type_goods')->insert(array('upid' => $cid, 'subject' => $name, 'displayorder' => $newsuborder[$cid][$key], 'logo' => $newlogo),1);
					$subtype .= $subtype ? ','.$subid : $subid;
                    unset($newlogo);
				}
				C::t('#aljbd#aljbd_type_goods')->update($cid,array('subid'=>$subtype));
			}
		}
		cpmsg(lang('plugin/aljbd','s9'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljbd&pmod=brandtype&lj=goodstype&page='.$_GET['page'].'&two='.$_GET['two'].'&upid='.$_GET['upid'], 'succeed');
	}
}else{
	$act = $_GET['act'];
	if($act == 'del') {
		$tid = intval($_GET['tid']);
		if($tid) {
			$upcid = C::t('#aljbd#aljbd_type')->fetch_upid_by_id($tid);
			if($upcid) {
				$subid = C::t('#aljbd#aljbd_type')->fetch_subid_by_id($upcid);
				$subarr = explode(",", $subid);
				foreach($subarr as $key=>$value) {
					if($value == $tid) {
						unset($subarr[$key]);
						break;
					}
				}
				C::t('#aljbd#aljbd_type')->update($upcid,array('subid'=>implode(",", $subarr)));
			}
			C::t('#aljbd#aljbd_type')->delete($tid);
		}
		cpmsg(lang('plugin/aljbd','s1'), 'action=plugins&operation=config&do=82&identifier=aljbd&pmod=brandtype', 'succeed');	
	}

	if(!submitcheck('editsubmit')) {	

	?>
	<script type="text/JavaScript">
	var rowtypedata = [
		[[1,'&nbsp;', 'td25'],[1,'<input type="text" class="txt" name="newcatorder[]" value="0" />', 'td25'], [2, '<input name="newcat[]" value="" size="20" type="text" class="txt" />']],
		[[1,'&nbsp;', 'td25'],[1,'<input type="text" class="txt" name="newsuborder[{1}][]" value="0" />', 'td25'], [2, '<div class="board"><input name="newsubcat[{1}][]" value="" size="20" type="text" class="txt" /></div>']],
		[[1,'&nbsp;', 'td25'],[1,'<input type="text" class="txt" name="newsuborder[{1}][]" value="0" />', 'td25'], [2, '<div class="childboard"><input name="newsubcat[{1}][]" value="" size="20" type="text" class="txt" /></div>']],
		];

	function del(id) {
		if(confirm('<?php echo lang("plugin/brand", "del_confirm");?>')) {
			window.location = '<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=aljbd&pmod=brandtype&act=del&tid='+id;
		} else {
			return false;
		}
	}
	</script>
	<?php
		showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier=aljbd&pmod=brandtype&page='.$_GET['page']);
		showtableheader('');
		showsubtitle(array('',lang('plugin/aljbd','s2'),lang('plugin/aljbd','s3'),  lang('plugin/aljbd','s4')));
		$currpage = $_GET['page'] ? $_GET['page'] : 1;
		$perpage = 10;
		$start = ($currpage - 1) * $perpage;
		$num=C::t('#'.$pluginid.'#'.$pluginid.'_type')->count_by_upid(0,$search);
		$brandtype = C::t('#'.$pluginid.'#'.$pluginid.'_type')->fetch_all_by_upid(0,$start,$perpage,$search);
		//$brandtype = C::t('#aljbd#aljbd_type')->fetch_all_by_upid(0);
		foreach($brandtype as $key=>$value){

			$bt = C::t('#aljbd#aljbd_type')->fetch_all_by_upid($key);
			foreach($bt as $k=>$v){
				$brandtype[$key]['subtype'][$k] = $v;
				$brandtype3 = C::t('#aljbd#aljbd_type')->fetch_all_by_upid($v['id']);
				if($brandtype3){
					foreach($brandtype3 as $k3=>$v3){
						$brandtype[$key]['subtype'][$k]['subtype3'][$k3] = $v3;
					}
				}
			}
		}
		if($brandtype) {
			foreach($brandtype as $id=>$type) {
				$show = '<tr class="hover"><td  class="td25" onclick="toggle_group(\'group_'.$id.'\', $(\'a_group_'.$id.'\'))"><a id="a_group_'.$id.'" href="javascript:;">[-]</a></td><td class="td25"><input type="text" class="txt" name="order['.$id.']" value="'.$type['displayorder'].'" /></td><td><div class="parentboard"><input type="text" class="txt" name="name['.$id.']" value="'.$type['subject'].'"></div></td>';
				if(!$type['subid']) {
					$show .= '<td><a  onclick="del('.$id.')" href="###">'.lang('plugin/aljbd','s5').'</td></tr><tbody id="group_'.$id.'">';
				} else {
					$show .= '<td>&nbsp;</td></tr><tbody id="group_'.$id.'">';
				}
				echo $show;
				if($type['subtype']) {
					foreach($type['subtype'] as $subid=>$stype) {
						echo '<tr class="hover"><td  class="td25">&nbsp;</td><td class="td25"><input type="text" class="txt" name="order['.$subid.']" value="'.$stype['displayorder'].'" /></td><td><div class="board"><input type="text" class="txt" name="name['.$subid.']" value="'.$stype['subject'].'">
						<a class="addchildboard" onclick="addrowdirect = 1;addrow(this, 2, '.$stype['id'].')" href="###">&#28155;&#21152;&#31532;&#19977;&#32423;&#20998;&#31867;</a>
						</div></td><td><a  onclick="del('.$subid.')" href="###">'.lang('plugin/aljbd','s6').'</td></tr>';
						if($stype['subtype3']){
							foreach($stype['subtype3'] as $subid3=>$stype3){
								echo '<tr class="hover"><td  class="td25">&nbsp;</td><td class="td25"><input type="text" class="txt" name="order['.$subid3.']" value="'.$stype3['displayorder'].'" /></td><td><div class="childboard"><input type="text" class="txt" name="name['.$subid3.']" value="'.$stype3['subject'].'">
								</div></td><td><a  onclick="del('.$subid3.')" href="###">'.lang('plugin/aljbd','s5').'</td></tr>';
							}
						}
					}
					
				}
				echo '<tr class="hover"><td class="td25">&nbsp;</td><td colspan="2" ><div class="lastboard"><a href="###" onclick="addrow(this, 1,'.$id.' )" class="addtr">'.lang('plugin/aljbd','s7').'</a></div></td></tr></tbody>';
			}	
		}
		echo '<tr class="hover"><td class="td25">&nbsp;</td><td colspan="2" ><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.lang('plugin/aljbd','s8').'</a></div></td></tr>';
		
		$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT."?action=plugins&operation=config&do=".$_GET['do']."&identifier=".$pluginid."&pmod=brandtype", 0, 10, false, false);
		showsubmit('editsubmit','&#25552;&#20132;','','',$paging);
		showtablefooter(); /*dism _taobao _com*/
		showformfooter(); /*dism_taobao_com*/

	} else {
		$order = $_GET['order'];
		$name = $_GET['name'];
		$newsubcat = $_GET['newsubcat'];
		$newcat = $_GET['newcat'];
		$newsuborder = $_GET['newsuborder'];
		$newcatorder = $_GET['newcatorder'];
		if(is_array($order)) {
			foreach($order as $id=>$value) {
				C::t('#aljbd#aljbd_type')->update($id,array('displayorder'=>$value,'subject'=>$name[$id]));
			}
		}

		if(is_array($newcat)) {
			foreach($newcat as $key=>$name) {
				if(empty($name)) {
					continue;
				}
				$cid=C::t('#aljbd#aljbd_type')->insert(array('upid' => '0', 'subject' => $name, 'displayorder' => $newcatorder[$key]),1);
			}
		}

		if(is_array($newsubcat)) {
			foreach($newsubcat as $cid=>$subcat) {
				$sub=C::t('#aljbd#aljbd_type')->fetch($cid);
				$subtype =$sub['subid'];
				foreach($subcat as $key=>$name) {
					$subid=C::t('#aljbd#aljbd_type')->insert(array('upid' => $cid, 'subject' => $name, 'displayorder' => $newsuborder[$cid][$key]),1);
					$subtype .= $subtype ? ','.$subid : $subid;
				}
				C::t('#aljbd#aljbd_type')->update($cid,array('subid'=>$subtype));
			}
		}

		cpmsg(lang('plugin/aljbd','s9'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljbd&pmod=brandtype', 'succeed');	
	}
}
//From: Dism��taobao��com
?>


