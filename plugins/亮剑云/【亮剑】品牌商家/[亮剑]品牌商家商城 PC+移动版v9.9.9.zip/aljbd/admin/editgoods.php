<?php
	if(empty($_GET['bid'])){
		cpmsg(lang('plugin/aljbd','s51'));
	}
	$bd=C::t('#aljbd#aljbd')->fetch($_GET['bid']);
	if(submitcheck('formhash')){

		if(empty($_GET['name'])){
			cpmsg(lang('plugin/aljbd','s52'));
		}
		for ($i = 1; $i <= 5; $i++) {
			$pic = 'pic' . $i;
			if ($_FILES[$pic]['tmp_name']) {
				$picname = $_FILES[$pic]['name'];
				$picsize = $_FILES[$pic]['size'];
				if ($picname != "") {
					$type = strtolower(strrchr($picname, '.'));
					if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
						cpmsg(lang('plugin/aljbd','s19'));
					}
					if (($picsize/1024)>$config['img_size']) {
						cpmsg(lang('plugin/aljbd','img1').$config['img_size'].'KB');
					}
					$rand = rand(100, 999);
					$pics = date("YmdHis") . $rand . $type;
					$img_dir = $image_path.'logo/';
					if (!is_dir($img_dir)) {
						mkdir($img_dir);
					}
					$$pic = $img_dir . $pics;
					if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {

						if($_G['cache']['plugin']['aljbd']['iswatermark']){
							$image->Watermark(DISCUZ_ROOT.'./'.$$pic,'', 'forum');
						}
						$imageinfo = getimagesize($$pic);
						$w60=$imageinfo[0]<60?$imageinfo[0]:60;
						$h60=$imageinfo[1]<60?$imageinfo[1]:60;
						$w205=$imageinfo[0]<205?$imageinfo[0]:205;
						$h205=$imageinfo[1]<205?$imageinfo[1]:205;
						$w470=$imageinfo[0]<470?$imageinfo[0]:470;
						$h470=$imageinfo[1]<470?$imageinfo[1]:470;

						img2thumb($$pic, $$pic . '.60x60.jpg', $w60, $h60);
						img2thumb($$pic, $$pic . '.205x205.jpg', $w205, $h205);
						img2thumb($$pic, $$pic . '.470x470.jpg', $w470, $h470);
						@unlink($_FILES[$pic]['tmp_name']);
					}

				}
			}
		}

		$updatearray=array(
			'bid'=>$_GET['bid'],
			'uid'=>$bd['uid'],
			'name'=>$_GET['name'],
			'price1'=>$_GET['price1'],
			'price2'=>$_GET['price2'],
			'intro'=>$_GET['intro'],
			'gwurl'=>$_GET['gwurl'],
			'type'=>$_GET['type'],
			'subtype'=>$_GET['subtype'],
			'subtype3'=>$_GET['subtype3'],
			'amount'=>$_GET['amount'],
			'state'=>$_GET['state'],
			'endtime'=>strtotime($_GET['endtime']),
            'region'=>$bd['region'],
            'region1'=>$bd['region1'],
            'subregion'=>$bd['subregion'],
		);
		if($_G['cache']['plugin']['aljgwc'][$pluginid]){
			if($_GET['fare_desc'] == '999999'){
				$updatearray['fare'] = $_GET['fare'];
			}else{
				$updatearray['fare'] = 0;
			}
			$updatearray['fare_desc'] = $_GET['fare_desc'];
		}
		for ($i = 1; $i <= 5; $i++) {
            $pic = 'pic' . $i;
            if ($$pic) {
				unlink($g[$pic]);
				unlink($g[$pic].'.60x60.jpg');
				unlink($g[$pic].'.205x205.jpg');
				unlink($g[$pic].'.470x470.jpg');
                $updatearray[$pic] = $$pic;
            }
        }
        if(file_exists("source/plugin/dz_1/dz_1.inc.php")){
            $updatearray['sccj'] = $_GET['sccj'];
            $updatearray['cpgg'] = $_GET['cpgg'];
            $updatearray['fyts'] = $_GET['fyts'];
            $updatearray['ysqz'] = $_GET['ysqz'];
            $updatearray['hdtj'] = $_GET['hdtj'];
						$updatearray['ext_num'] = $_GET['ext_num'];
        }
		C::t('#aljbd#aljbd_goods')->update($_GET['gid'],$updatearray);
		cpmsg(lang('plugin/aljbd','s54'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljbd&pmod=admin&brand=goods', 'succeed');
	}else{
		//$bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','','','','','','','','','','','','','',0);
		$typelist=C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid(0,'','','');
		$g=C::t('#aljbd#aljbd_goods')->fetch($_GET['gid']);
		include template('aljbd:admin/editgoods');
	}
//From: Dism��taobao��com
?>
