<?php
	if(empty($_GET['bid'])){
		cpmsg(lang('plugin/aljbd','s51'));
	}
	$bd=C::t('#aljbd#aljbd')->fetch($_GET['bid']);
	if(submitcheck('formhash')){
		
		if($_FILES['logo']['tmp_name']) {
			$picname = $_FILES['logo']['name'];
			$picsize = $_FILES['logo']['size'];
		
			if ($picname != "") {
				$type = strstr($picname, '.');
				if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
					showerror(lang('plugin/aljbd','s29'));
				}
				$rand = rand(100, 999);
				$pics = date("YmdHis") . $rand . $type;
				$logo = $image_path."consume/". $pics;
				if(@copy($_FILES['logo']['tmp_name'], $logo)||@move_uploaded_file($_FILES['logo']['tmp_name'], $logo)){
					if($_G['cache']['plugin']['aljbd']['iswatermark']){
						$image->Watermark(DISCUZ_ROOT.'./'.$logo,'', 'forum');
					}
					@unlink($_FILES['logo']['tmp_name']);
				}
			}
		}
		$updatearray=array(
			'username'=>$bd['username'],
			'uid'=>$bd['uid'],
			'subject'=>$_GET['name'],
			'bid'=>$_GET['bid'],
			'jieshao'=>$_GET['jieshao'],
			'xianzhi'=>$_GET['xianzhi'],
			'end'=>strtotime($_GET['end']),
			'mianze'=>$_GET['mianze'],
			'type'=>$_GET['type'],
			'subtype'=>$_GET['subtype'],
            'region'=>$bd['region'],
            'region1'=>$bd['region1'],
            'subregion'=>$bd['subregion'],
		);
		if($logo){
			$c=C::t('#aljbd#aljbd_consume')->fetch($_GET['cid']);
			unlink($c['pic']);
			$updatearray['pic']=$logo;
		}
		C::t('#aljbd#aljbd_consume')->update($_GET['cid'],$updatearray);
		showmsg(lang('plugin/aljbd','s54'));
	}else{
		$typelist=C::t('#aljbd#aljbd_type_consume')->fetch_all_by_upid(0);
		//$bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','','','','','','','','','','','','','',0);
		$n=C::t('#aljbd#aljbd_consume')->fetch($_GET['cid']);
		include template('aljbd:admin/admin_consume');
	}
//From: Dism��taobao��com
?>