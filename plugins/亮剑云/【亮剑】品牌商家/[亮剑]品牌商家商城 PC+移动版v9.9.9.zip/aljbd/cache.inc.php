<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if(!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
$plugin = DB::fetch_first('select * from %t where identifier = %s', array('common_plugin', 'aljhtx'));
if(empty($plugin)){
    cpmsg('&#35831;&#20808;&#23433;&#35013;&#21830;&#23478;&#21161;&#25163;&#25554;&#20214;');
}
$plugin = DB::fetch_first('select * from %t where identifier = %s and available=1', array('common_plugin', 'aljhtx'));
if(empty($plugin)){
    cpmsg('&#35831;&#20808;&#21551;&#29992;&#21830;&#23478;&#21161;&#25163;&#25554;&#20214;');
}
if($_G['cache']['plugin']['aljht']['on']){
	echo '<iframe style="width:100%;height:100%;min-height:760px;border:none;" src="plugin.php?id=aljhtx&c=aljbd&a=order&type=10&twok=3&onek=1&ajax=yes&dzAdmin=1"></iframe>';
	exit;
}
$pluginid='aljbd';
$table='aljbd_syscache';
echo '<table class="tb tb2 " id="tips">
	<tr>
		<th  class="partition">'.lang('plugin/'.$pluginid.'','daka24').'</th>
	</tr>
	<tr>
		<td class="tipsblock" s="1">
			<ul id="tipslis">
				<li>'.lang('plugin/'.$pluginid.'','daka25').'</li>
				<li>'.lang('plugin/'.$pluginid.'','daka26').'</li>
				<li>'.lang('plugin/'.$pluginid.'','daka27').'</li>
				<li>'.lang('plugin/'.$pluginid.'','daka43').'</li>
				<li>'.lang('plugin/'.$pluginid.'','daka53').'</li>
			</ul>
		</td>
	</tr>
</table><br>';
require_once libfile('class/xml');
include template('aljbd:nav');
$lj_plugin = DB::fetch_first("SELECT * FROM ".DB::table('common_plugin')." WHERE identifier='".$pluginid."'");
$lj_dir = substr($lj_plugin['directory'], 0, -1);
$lj_modules = unserialize($lj_plugin['modules']);
if($_GET['cache']=='p_s'){
    if(!submitcheck('addsubmit')) {
        $cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_template'");
        $data=unserialize($cache);

        /*if(!C::t('#'.$pluginid.'#'.$table)->fetch_count('2')||C::t('#'.$pluginid.'#'.$table)->fetch_count('2')<count($data[$pluginid])){

            foreach($data[$pluginid] as $k=>$s){
                if(!C::t('#'.$pluginid.'#'.$table)->fetch_count_sign($k,'2')){
                    C::t('#'.$pluginid.'#'.$table)->insert(array(
                        'plugin_b'=>$k,
                        'plugin_w'=>$s,
                        'plugin_sign'=>'2',
                    ));
                }
            }
        }*/
        //ģ��ԭʼ����  ���ڻָ�ԭʼ����
        if(!C::t('#'.$pluginid.'#'.$table)->fetch_count('4')||C::t('#'.$pluginid.'#'.$table)->fetch_count('4')<count($data[$pluginid])){

            foreach($data[$pluginid] as $k=>$s){
                if(!C::t('#'.$pluginid.'#'.$table)->fetch_count_sign($k,'4')){
                    C::t('#'.$pluginid.'#'.$table)->insert(array(
                        'plugin_b'=>$k,
                        'plugin_w'=>$s,
                        'plugin_sign'=>'4',
                    ));
                }
            }
        }
        //ģ�嶯̬����  ���ڻָ��޸�����
        if(!C::t('#'.$pluginid.'#'.$table)->fetch_count('6')||C::t('#'.$pluginid.'#'.$table)->fetch_count('6')<count($data[$pluginid])){

            foreach($data[$pluginid] as $k=>$s){
                if(!C::t('#'.$pluginid.'#'.$table)->fetch_count_sign($k,'6')){
                    C::t('#'.$pluginid.'#'.$table)->insert(array(
                        'plugin_b'=>$k,
                        'plugin_w'=>$s,
                        'plugin_sign'=>'6',
                    ));
                }
            }
        }
        $plugin_bw_3=C::t('#'.$pluginid.'#'.$table)->fetch_all_by_sign('4');
        $plugin_bw_3=dhtmlspecialchars($plugin_bw_3);
        foreach($plugin_bw_3 as $ss){
            $lang_qian[$ss['plugin_b']]=$ss['plugin_w'];
        }
        $plugin_bw=$data[$pluginid];
        $url=ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache&cache=p_s';
        include template($pluginid.':scache');
    }else{
        if(!$_GET['delete']){
            cpmsg('&#35831;&#25171;&#21246;&#35201;&#20462;&#25913;&#30340;&#35821;&#35328;&#21253;&#21518;&#20877;&#25552;&#20132;');
        }
        if(is_array($_GET['delete'])){
            foreach($_GET['delete'] as $b){
                if($b){
                    //DB::update($table,array('plugin_w'=>$w),array('plugin_b'=>$b,'plugin_sign'=>'1'));
                    DB::update($table,array('plugin_w'=>$_GET['plugin_all'][$b]),array('plugin_b'=>$b,'plugin_sign'=>'6'));
                    $plugin_data[$b] = $_GET['plugin_all'][$b];
                }
            }
            $cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_template'");
            $data=unserialize($cache);
            $result = array_merge($data[$pluginid], $plugin_data);
            $data[$pluginid]=$result;
            savecache('pluginlanguage_template', $data);
            cleartemplatecache();
            $file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';
            //debug($file);
            if(file_exists($file)) {
                $importtxt = @implode('', file($file));
                $data = $GLOBALS['importtxt'];
                //debug($GLOBALS);
                $xmldata = xml2array($data);
                $xmldata['Data']['language']['templatelang']=$result;
                //debug($xmldata);
                $handle=fopen($file,"w");
                if(!$handle){
                    cpmsg(lang('plugin/'.$pluginid.'','daka28'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache&cache=p_s', 'error');
                }
                if(fwrite($handle,array2xml($xmldata,1))){
                    fclose($handle);
                    updatecache(array('plugin'));
                    cleartemplatecache();
                    cpmsg(lang('plugin/'.$pluginid.'','daka29'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache&cache=p_s', 'succeed');
                }
                fclose($handle);
                cpmsg(lang('plugin/'.$pluginid.'','daka28'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache&cache=p_s', 'error');
            }
        }
        cpmsg(lang('plugin/'.$pluginid.'','daka21'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache&cache=p_s');
    }
}else if($_GET['cache']=='gl'){
    include template($pluginid.':gl');
}else if($_GET['cache']=='geshihua3'){//��ʼ���ű�
    if($_GET['formhash']==formhash()){
        $plugin_bw=C::t('#'.$pluginid.'#'.$table)->fetch_all_by_sign('3');
        foreach($plugin_bw as $w){
            //DB::update($table,array('plugin_w'=>$w['plugin_w']),array('plugin_b'=>$w['plugin_b'],'plugin_sign'=>'1'));
            $plugin_data[$w['plugin_b']]=$w['plugin_w'];
        }

        $cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_script'");
        $data=unserialize($cache);
        $result = array_merge($data[$pluginid], $plugin_data);

        $data[$pluginid]=$result;
        savecache('pluginlanguage_script', $data);
        cleartemplatecache();
        $file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';
        //debug($file);
        if(file_exists($file)) {
            $importtxt = @implode('', file($file));
            $data = $GLOBALS['importtxt'];
            //debug($GLOBALS);
            $xmldata = xml2array($data);
            $xmldata['Data']['language']['scriptlang']=$result;
            //debug($xmldata);
            $handle=fopen($file,"w");
            if(!$handle){
                cpmsg(lang('plugin/'.$pluginid.'','daka31'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache', 'error');
            }
            if(fwrite($handle,array2xml($xmldata,1))){
                fclose($handle);
                updatecache(array('plugin'));
                cleartemplatecache();
                cpmsg(lang('plugin/'.$pluginid.'','daka32'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache', 'succeed');
            }
            fclose($handle);
            cpmsg(lang('plugin/'.$pluginid.'','daka31'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache', 'error');
        }
        cpmsg(lang('plugin/'.$pluginid.'','daka41'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache');
    }

}else if($_GET['cache']=='geshihua4'){//��ʼ��ģ��
    if($_GET['formhash']==formhash()){
        $plugin_bw=C::t('#'.$pluginid.'#'.$table)->fetch_all_by_sign('4');
        foreach($plugin_bw as $w){
            //DB::update($table,array('plugin_w'=>$w['plugin_w']),array('plugin_b'=>$w['plugin_b'],'plugin_sign'=>'2'));
            $plugin_data[$w['plugin_b']]=$w['plugin_w'];
        }
        $cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_template'");
        $data=unserialize($cache);
        $result = array_merge($data[$pluginid], $plugin_data);

        $data[$pluginid]=$result;
        savecache('pluginlanguage_template', $data);
        cleartemplatecache();
        $file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';
        //debug($file);
        if(file_exists($file)) {
            $importtxt = @implode('', file($file));
            $data = $GLOBALS['importtxt'];
            //debug($GLOBALS);
            $xmldata = xml2array($data);
            $xmldata['Data']['language']['templatelang']=$result;
            //debug($xmldata);
            $handle=fopen($file,"w");
            if(!$handle){
                cpmsg(lang('plugin/'.$pluginid.'','daka35'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache&cache=p_s', 'error');
            }
            if(fwrite($handle,array2xml($xmldata,1))){
                fclose($handle);
                updatecache(array('plugin'));
                cleartemplatecache();
                cpmsg(lang('plugin/'.$pluginid.'','daka36'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache&cache=p_s', 'succeed');
            }
            fclose($handle);
            cpmsg(lang('plugin/'.$pluginid.'','daka35'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache&cache=p_s', 'error');
        }
        cpmsg(lang('plugin/'.$pluginid.'','daka41'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache&cache=p_s');
    }
}else if($_GET['cache']=='huifu5'){//�ָ��ű�
    if($_GET['formhash']==formhash()){
        $plugin_bw=C::t('#'.$pluginid.'#'.$table)->fetch_all_by_sign('5');
        foreach($plugin_bw as $w){
            //DB::update($table,array('plugin_w'=>$w['plugin_w']),array('plugin_b'=>$w['plugin_b'],'plugin_sign'=>'1'));
            $plugin_data[$w['plugin_b']]=$w['plugin_w'];
        }
        $cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_script'");
        $data=unserialize($cache);
        $result = array_merge($data[$pluginid], $plugin_data);

        $data[$pluginid]=$result;
        savecache('pluginlanguage_script', $data);
        cleartemplatecache();
        $file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';
        //debug($file);
        if(file_exists($file)) {
            $importtxt = @implode('', file($file));
            $data = $GLOBALS['importtxt'];
            //debug($GLOBALS);
            $xmldata = xml2array($data);
            $xmldata['Data']['language']['scriptlang']=$result;
            //debug($xmldata);
            $handle=fopen($file,"w");
            if(!$handle){
                cpmsg(lang('plugin/'.$pluginid.'','daka39'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache', 'error');
            }
            if(fwrite($handle,array2xml($xmldata,1))){
                fclose($handle);
                updatecache(array('plugin'));
                cleartemplatecache();
                cpmsg(lang('plugin/'.$pluginid.'','daka40'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache', 'succeed');
            }
            fclose($handle);
            cpmsg(lang('plugin/'.$pluginid.'','daka39'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache', 'error');
        }
        cpmsg(lang('plugin/'.$pluginid.'','daka42'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache');
    }
}else if($_GET['cache']=='huifu6'){//�ָ�ģ��
    if($_GET['formhash']==formhash()){
        $plugin_bw=C::t('#'.$pluginid.'#'.$table)->fetch_all_by_sign('6');
        foreach($plugin_bw as $w){
            //DB::update($table,array('plugin_w'=>$w['plugin_w']),array('plugin_b'=>$w['plugin_b'],'plugin_sign'=>'2'));
            $plugin_data[$w['plugin_b']]=$w['plugin_w'];
        }
        $cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_template'");
        $data=unserialize($cache);
        //debug($data);
        $result = array_merge($data[$pluginid], $plugin_data);

        $data[$pluginid]=$result;

        savecache('pluginlanguage_template', $data);
        cleartemplatecache();
        $file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';
        //debug($file);
        if(file_exists($file)) {
            $importtxt = @implode('', file($file));
            $data = $GLOBALS['importtxt'];
            //debug($GLOBALS);
            $xmldata = xml2array($data);
            $xmldata['Data']['language']['templatelang']=$result;
            //debug($xmldata);
            $handle=fopen($file,"w");
            if(!$handle){
                cpmsg(lang('plugin/'.$pluginid.'','daka37'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache&cache=p_s', 'error');
            }
            if(fwrite($handle,array2xml($xmldata,1))){
                fclose($handle);
                updatecache(array('plugin'));
                cleartemplatecache();
                cpmsg(lang('plugin/'.$pluginid.'','daka38'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache&cache=p_s', 'succeed');
            }
            fclose($handle);
            cpmsg(lang('plugin/'.$pluginid.'','daka37'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache&cache=p_s', 'error');
        }
        cpmsg(lang('plugin/'.$pluginid.'','daka42'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache&cache=p_s');
    }
}else{//�ű�
    if(!submitcheck('addsubmit')) {
        $cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_script'");
        $data=unserialize($cache);
        /*if(!C::t('#'.$pluginid.'#'.$table)->fetch_count('1')||C::t('#'.$pluginid.'#'.$table)->fetch_count('1')<count($data[$pluginid])){

            foreach($data[$pluginid] as $k=>$s){
                if(!C::t('#'.$pluginid.'#'.$table)->fetch_count_sign($k,'1')){
                    C::t('#'.$pluginid.'#'.$table)->insert(array(
                        'plugin_b'=>$k,
                        'plugin_w'=>$s,
                        'plugin_sign'=>'1',
                    ));
                }
            }
        }*/
        //�ű�ԭʼ����  ���ڻָ�ԭʼ����
        if(!C::t('#'.$pluginid.'#'.$table)->fetch_count('3')||C::t('#'.$pluginid.'#'.$table)->fetch_count('3')<count($data[$pluginid])){

            foreach($data[$pluginid] as $k=>$s){
                if(!C::t('#'.$pluginid.'#'.$table)->fetch_count_sign($k,'3')){
                    C::t('#'.$pluginid.'#'.$table)->insert(array(
                        'plugin_b'=>$k,
                        'plugin_w'=>$s,
                        'plugin_sign'=>'3',
                    ));
                }
            }
        }
        //�ű���̬���� ���ڻָ��޸ĺ������
        if(!C::t('#'.$pluginid.'#'.$table)->fetch_count('5')||C::t('#'.$pluginid.'#'.$table)->fetch_count('5')<count($data[$pluginid])){

            foreach($data[$pluginid] as $k=>$s){
                if(!C::t('#'.$pluginid.'#'.$table)->fetch_count_sign($k,'5')){
                    C::t('#'.$pluginid.'#'.$table)->insert(array(
                        'plugin_b'=>$k,
                        'plugin_w'=>$s,
                        'plugin_sign'=>'5',
                    ));
                }
            }
        }

        $plugin_bw_3=C::t('#'.$pluginid.'#'.$table)->fetch_all_by_sign('3');

        $plugin_bw_3=dhtmlspecialchars($plugin_bw_3);
        foreach($plugin_bw_3 as $ss){
            $lang_qian[$ss['plugin_b']]=$ss['plugin_w'];
        }

        $plugin_bw=$data[$pluginid];
        //debug($plugin_bw_3);
        $url=ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache';
        include template($pluginid.':scache');
    }else{
        //debug($_GET['plugin_all'][$_GET['delete'][0]]);
        if(!$_GET['delete']){
            cpmsg('&#35831;&#25171;&#21246;&#35201;&#20462;&#25913;&#30340;&#35821;&#35328;&#21253;&#21518;&#20877;&#25552;&#20132;');
        }
        if(is_array($_GET['delete'])){
            foreach($_GET['delete'] as $b){
                if($b){
                    //DB::update($table,array('plugin_w'=>$w),array('plugin_b'=>$b,'plugin_sign'=>'1'));
                    DB::update($table,array('plugin_w'=>$_GET['plugin_all'][$b]),array('plugin_b'=>$b,'plugin_sign'=>'5'));
                    $plugin_data[$b] = $_GET['plugin_all'][$b];
                }
            }

            $cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_script'");
            $data=unserialize($cache);
            $result = array_merge($data[$pluginid], $plugin_data);

            $data[$pluginid]=$result;
            //debug($data[$pluginid]);
            savecache('pluginlanguage_script', $data);
            cleartemplatecache();
            $file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';
            //debug($file);
            if(file_exists($file)) {
                $importtxt = @implode('', file($file));
                $data = $GLOBALS['importtxt'];
                //debug($GLOBALS);
                $xmldata = xml2array($data);
                $xmldata['Data']['language']['scriptlang']=$result;
                //debug($xmldata);
                $handle=fopen($file,"w");
                if(!$handle){
                    cpmsg(lang('plugin/'.$pluginid.'','daka33'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache', 'error');
                }
                if(fwrite($handle,array2xml($xmldata,1))){
                    fclose($handle);
                    updatecache(array('plugin'));
                    cleartemplatecache();
                    cpmsg(lang('plugin/'.$pluginid.'','daka34'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache', 'succeed');
                }
                fclose($handle);
                cpmsg(lang('plugin/'.$pluginid.'','daka33'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache', 'error');
            }
        }
        cpmsg(lang('plugin/'.$pluginid.'','daka21'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=cache');
    }
}
//From: Dism��taobao��com
?>
