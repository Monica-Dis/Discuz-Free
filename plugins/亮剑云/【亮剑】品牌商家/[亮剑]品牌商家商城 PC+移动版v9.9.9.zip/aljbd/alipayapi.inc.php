<?php
/*
 * 主页：http://t.cn/Aiux14ti
 * 联系QQ:467783778
 *
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


require_once("source/plugin/aljbd/alipay.config.php");
require_once("source/plugin/aljbd/lib/alipay_submit.class.php");
$pluginid='aljbd';
if($_G['cache']['plugin']['aljgwc']['aljbd']){
	$orderid=C::t('#aljgwc#aljbd_goods_order')->fetch($_GET[orderid]);
}else{
	$orderid=C::t('#aljbd#aljbd_order')->fetch($_GET[orderid]);
}
if(empty($orderid)){
	showmessage('&#20132;&#26131;&#19981;&#23384;&#22312;&#65281;');
}
if(empty($_GET[companyname])){
	showmessage('&#29289;&#27969;&#20449;&#24687;&#24517;&#39035;&#22635;&#20889;');
}
if(empty($_GET[worderid])){
	showmessage('&#29289;&#27969;&#20449;&#24687;&#24517;&#39035;&#22635;&#20889;');
}
$_POST['WIDtrade_no'] = $orderid[buyer];
$_POST['WIDlogistics_name'] = g2u($_GET[companyname]);
$_POST['WIDinvoice_no'] = $_GET[worderid];
$_POST['WIDtransport_type'] = g2u($_GET[c]);
/**************************请求参数**************************/

        //支付宝交易号
        $trade_no = $_POST['WIDtrade_no'];
        //必填
        //物流公司名称
        $logistics_name = $_POST['WIDlogistics_name'];
        //必填
        //物流发货单号
        $invoice_no = $_POST['WIDinvoice_no'];
        //物流运输类型
        $transport_type = $_POST['WIDtransport_type'];
        //三个值可选：POST（平邮）、EXPRESS（快递）、EMS（EMS）


/************************************************************/

//构造要请求的参数数组，无需改动
$parameter = array(
		"service" => "send_goods_confirm_by_platform",
		"partner" => trim($alipay_config['partner']),
		"trade_no"	=> $trade_no,
		"logistics_name"	=> $logistics_name,
		"invoice_no"	=> $invoice_no,
		"transport_type"	=> $transport_type,
		"_input_charset"	=> trim(strtolower($alipay_config['input_charset']))
);

//建立请求
$alipaySubmit = new AlipaySubmit($alipay_config);
$html_text = $alipaySubmit->buildRequestHttp($parameter);
//解析XML
//注意：该功能PHP5环境及以上支持，需开通curl、SSL等PHP配置环境。建议本地调试时使用PHP开发软件
$doc = new DOMDocument();
$doc->loadXML($html_text);

//请在这里加上商户的业务逻辑程序代码
if($doc->getElementsByTagName( "is_success" )->item(0)->nodeValue == 'T'){
	if($_G['cache']['plugin']['aljgwc']['aljbd']){
		require DISCUZ_ROOT.'./source/plugin/aljgwc/include/aljbd_wuliu.php';
	}else{
		if(C::t('#aljbd#aljbd_wuliu')->fetch($_GET['orderid'])){
			C::t('#aljbd#aljbd_wuliu')->update($_GET['orderid'],array(
				'companyname' => $_GET['companyname'],
				'worderid' => $_GET['worderid'],
				'updatetime' => TIMESTAMP,
			));


			$order = C::t('#aljbd#aljbd_order')->fetch($_GET['orderid']);
			notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&gid='.$order['sid'].'">'.$order['stitle'].'</a>',$_G['cache']['plugin']['aljbd']['fahuotips'])));
			if($_G['cache']['plugin']['aljbd']['time']){
				$email_first=C::t("common_member")->fetch($order['uid']);
				$email=$email_first['email'];

				if($email_first['email']){
					$m=str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&gid='.$order['sid'].'">'.$order['stitle'].'</a>',$_G['cache']['plugin']['aljbd']['fahuotips']));
					newsendmail_cron($email,$_G['cache']['plugin']['aljbd']['mailtitle'],$m);
				}
			}
			C::t('#aljbd#aljbd_order')->update_status_by_orderid($_GET['orderid']);
			showmessage(lang('plugin/aljbd','s9'), 'plugin.php?id=aljbd&act=orderlist');
		}else{
			C::t('#aljbd#aljbd_wuliu')->insert(array(
				'orderid' => $_GET['orderid'],
				'type' => 1,
				'companyname' => $_GET['companyname'],
				'worderid' => $_GET['worderid'],
				'dateline' => TIMESTAMP,
			));
			C::t('#aljbd#aljbd_order')->update_status_by_orderid($_GET['orderid']);

			$order = C::t('#aljbd#aljbd_order')->fetch($_GET['orderid']);
			notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&gid='.$order['sid'].'">'.$order['stitle'].'</a>',$_G['cache']['plugin']['aljbd']['fahuotips'])));
			if($_G['cache']['plugin']['aljbd']['time']){
				$email_first=C::t("common_member")->fetch($order['uid']);
				$email=$email_first['email'];

				if($email_first['email']){
					$m=str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljbd&act=goodview&gid='.$order['sid'].'">'.$order['stitle'].'</a>',$_G['cache']['plugin']['aljbd']['fahuotips']));
					newsendmail_cron($email,$_G['cache']['plugin']['aljbd']['mailtitle'],$m);
				}
			}
			showmessage(lang('plugin/aljbd','tg44'), 'plugin.php?id=aljbd&act=orderlist');
		}
	}
}
if($doc->getElementsByTagName( "is_success" )->item(0)->nodeValue == 'F'){
	showmessage('&#21457;&#36135;&#22833;&#36133;&#35831;&#37325;&#35797;&#65281;');
}
//——请根据您的业务逻辑来编写程序（以下代码仅作参考）——

//获取支付宝的通知返回参数，可参考技术文档中页面跳转同步通知参数列表
//解析XML
if( ! empty($doc->getElementsByTagName( "alipay" )->item(0)->nodeValue) ) {
	$alipay = $doc->getElementsByTagName( "alipay" )->item(0)->nodeValue;
	echo $alipay;
}

//——请根据您的业务逻辑来编写程序（以上代码仅作参考）——
function g2u($a) {
   return is_array($a) ? array_map('g2u', $a) : diconv($a, CHARSET, 'UTF-8');
}

function u2g($a) {
	return is_array($a) ? array_map('u2g', $a) : diconv($a, 'UTF-8', CHARSET);
}
//From: Dism·taobao·com
?>