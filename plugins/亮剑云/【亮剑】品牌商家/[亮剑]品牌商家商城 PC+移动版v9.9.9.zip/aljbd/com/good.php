<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$check=C::t('#aljbd#aljbd_username')->fetch_by_uid_bid($_G['uid'],$_GET['bid']);
if(empty($check)&&$_G['uid']){
	C::t('#aljbd#aljbd_username')->insert(array('uid'=>$_G['uid'],'username'=>$_G['username'],'bid'=>$_GET['bid']));
}
C::t('#aljbd#aljbd')->update_view_by_bid($_GET['bid']);
$khf=C::t('#aljbd#aljbd_comment')->count_by_bid($_GET['bid']);
foreach($khf[0] as $k=>$v){
	$khf[0][$k]=intval($v);
}
$commentcount=C::t('#aljbd#aljbd_comment')->count_by_bid_upid($_GET['bid'],0,0);
$askcount=C::t('#aljbd#aljbd_comment')->count_by_bid_upid($_GET['bid'],0,1);
$commentlist=C::t('#aljbd#aljbd_comment')->fetch_all_by_bid_upid($_GET['bid'],0,0);
$commentlist = dhtmlspecialchars($commentlist);
$asklist=C::t('#aljbd#aljbd_comment')->fetch_all_by_bid_upid($_GET['bid'],0,1);
$asklist = dhtmlspecialchars($asklist);
$bd=C::t('#aljbd#aljbd')->fetch($_GET['bid']);

$qq=str_replace('{qq}',$bd['qq'],$config['qq']);
require_once libfile('function/discuzcode');
if(!file_exists('source/plugin/aljbd/com/intro.php')){
	$bd['intro']=discuzcode($bd['intro']);
}
$avg=C::t('#aljbd#aljbd_comment')->count_avg_by_bid($bd['id']);
$avg=intval($avg);
$adv=unserialize($bd['adv']);
$advurl=unserialize($bd['advurl']);
$navtitle = $bd['name'].'-'.$config['title'];
$metakeywords =  $config['keywords'];
$metadescription = $config['description'];
$currpage=$_GET['page']?$_GET['page']:1;

if($settings['view_goods_list_num']['value']){
	$perpage=$settings['view_goods_list_num']['value'];
}else{
	$perpage=12;
}
$array = array('btypeid'=>intval($_GET['btypeid']),'bsubtypeid'=>intval($_GET['bsubtypeid']));
$sql = ' AND store_id=0';
if(!$card_user && !$admin_status){  
	$sql .= ' AND is_aljtcc=0';
}
if($_G['cache']['plugin']['aljsqtg']['hide_aljsqtg_goods']){
	$sql .= ' AND commodity_type!=8';
}
$num=C::t('#aljbd#aljbd_goods')->count_by_uid_bid_new($bd['uid'],$_GET['bid'],0,$array,$sql);

$allpage=ceil($num/$perpage);
$start=($currpage-1)*$perpage;
$glist=C::t('#aljbd#aljbd_goods')->fetch_all_by_uid_bid_new($bd['uid'],$_GET['bid'],$start,$perpage,0,$array,$sql);
foreach($glist as $k=>$v){
    $glist[$k]['price1']=T::skuminprice($v['attr_sku'],$v['commodity_type'])>0 ? T::skuminprice($v['attr_sku'],$v['commodity_type']) : floatval($v['price1']);
    $glist[$k]['collage_price']=T::skuminprice($v['attr_sku'],$v['commodity_type'])>0 ? T::skuminprice($v['attr_sku'],$v['commodity_type']) : floatval($v['collage_price']);
	$glist[$k]['price2']=floatval($v['price2']);
    if($v['selling_point']){
        $selling_point = str_replace('��',',',$v['selling_point']);
        $glist[$k]['selling_point'] = explode(',',$selling_point);
	}
	foreach($pics as $p_v){
		$glist[$k][$p_v] = $v[$p_v].$oss_img_url;
	}
}
$glist = dhtmlspecialchars($glist);
$notice=C::t('#aljbd#aljbd_notice')->fetch_all_by_uid_bid($bd['uid'],$_GET['bid'],0,9,'','','','',0);
$notice = dhtmlspecialchars($notice);
$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=good&bid='.$_GET['bid'].'&btypeid='.$_GET['btypeid'].'&bsubtypeid='.$_GET['bsubtypeid'], 0, 11, false, false);
$bd = dhtmlspecialchars($bd);
if($aljbd_seo['brand_good_list']['seotitle']){
	$seodata = array('bbname' => $_G['setting']['bbname'],'bdname'=>$bd['name'],'cat' => $typelist[$bd['type']]['subject'],'cat2' => $typelist[$bd['subtype']]['subject'],'cat3' => $typelist[$bd['subtype3']]['subject']);
	list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljbd_seo['brand_good_list']);
}
include template('aljbd:good');
?>