<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Deined');
}
$currpage=$_GET['page']?$_GET['page']:1;
$perpage=7;
$start=($currpage-1)*$perpage;
if($_GET['do'] == 'ajax'){
    require_once $common_path.'class/class_aljhtx.php';
    $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,$start,$perpage,'',$_GET['type'],$_GET['subtype'],$_GET['region'],$_GET['subregion'],$_GET['order'],$_GET['kw'],1,'','','','',0);
    foreach($bdlist as $bd){
        if($bd['x']!=0 && $bd['y']!=0){
            $maplist[]=array('id'=>$bd['id'],'name'=>$bd['name'],'lat'=>$bd['y'],'lng'=>$bd['x'],'logo'=>$bd['logo'],'addr'=>$bd['addr'],'tel'=>$bd['tel']);
        }

    }
    $bdlist=$maplist;
    if($bdlist){
        echo json_encode(aljhtx::ajaxPostCharSet($bdlist));
        exit;
    }else{
        echo '1';
        exit;
    }
}else{
    $navtitle = lang('plugin/aljbd','index_3').$config['title'];
    $metakeywords =  $config['keywords'];
    $metadescription = $config['description'];
    $config=$_G['cache']['plugin']['aljbd'];
    $typelist=C::t('#aljbd#aljbd_type')->fetch_all_by_upid(0,'','','');

    if($_GET['subtype']){
        $subtypelist=C::t('#aljbd#aljbd_type')->fetch_all_by_upid($_GET['type'],'','','');
    }


    $num=C::t('#aljbd#aljbd')->count_by_status(1,'',$_GET['type'],$_GET['subtype'],$_GET['region'],$_GET['subregion'],$_GET['kw'],1,'','','','',0);
    if(!$_G['mobile']){
        $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,$start,$perpage,'',$_GET['type'],$_GET['subtype'],$_GET['region'],$_GET['subregion'],$_GET['order'],$_GET['kw'],1,'','','','',0);
        $bdlist = dhtmlspecialchars($bdlist);

        foreach($bdlist as $bd){
        if($bd['x']!=0 && $bd['y']!=0){
            $maplist[]=array('id'=>$bd['id'],'name'=>$bd['name'],'lat'=>$bd['y'],'lng'=>$bd['x'],'logo'=>$bd['logo'],'addr'=>$bd['addr'],'tel'=>$bd['tel']);
        }

        }
        $bdlist=$maplist;

        $maplist=json_encode(g2u($maplist));
        $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd:so&type='.$_GET['type'].'&subtype='.$_GET['subtype'].'&region='.$_GET['region'].'&subregion='.$_GET['subregion'].'&order='.$_GET['order'].'&kw='.$_GET['kw'].'&view='.$_GET['view'], 0, 5, false, false);
    }

    if($aljbd_seo['map_index']['seotitle']){
        $seodata = array('bbname' => $_G['setting']['bbname']);
        list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljbd_seo['map_index']);
    }
    include template('aljbd:so');
}

function g2u($a) {
   return is_array($a) ? array_map('g2u', $a) : diconv($a, CHARSET, 'UTF-8');
}

function u2g($a) {
   return is_array($a) ? array_map('u2g', $a) : diconv($a, 'UTF-8', CHARSET);
}
//From: Dism��taobao��com
?>