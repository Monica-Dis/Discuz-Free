<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$check=C::t('#aljbd#aljbd_username')->fetch_by_uid_bid($_G['uid'],$_GET['bid']);
if(empty($check)&&$_G['uid']){
	C::t('#aljbd#aljbd_username')->insert(array('uid'=>$_G['uid'],'username'=>$_G['username'],'bid'=>$_GET['bid']));
}
C::t('#aljbd#aljbd')->update_view_by_bid($_GET['bid']);
$khf=C::t('#aljbd#aljbd_comment')->count_by_bid($_GET['bid']);
foreach($khf[0] as $k=>$v){
	$khf[0][$k]=intval($v);
}
$commentcount=C::t('#aljbd#aljbd_comment')->count_by_bid_upid($_GET['bid'],0,0);
$askcount=C::t('#aljbd#aljbd_comment')->count_by_bid_upid($_GET['bid'],0,1);
$commentlist=C::t('#aljbd#aljbd_comment')->fetch_all_by_bid_upid($_GET['bid'],0,0);
$commentlist = dhtmlspecialchars($commentlist);
$asklist=C::t('#aljbd#aljbd_comment')->fetch_all_by_bid_upid($_GET['bid'],0,1);
$asklist = dhtmlspecialchars($asklist);
$bd=C::t('#aljbd#aljbd')->fetch($_GET['bid']);

$qq=str_replace('{qq}',$bd['qq'],$config['qq']);
require_once libfile('function/discuzcode');
if(!file_exists('source/plugin/aljbd/com/intro.php')){
	$bd['intro']=discuzcode($bd['intro']);
}
$avg=C::t('#aljbd#aljbd_comment')->count_avg_by_bid($bd['id']);
$avg=intval($avg);
$adv=unserialize($bd['adv']);
$advurl=unserialize($bd['advurl']);
$navtitle = $bd['name'].'-'.$config['title'];
$metakeywords =  $config['keywords'];
$metadescription = $config['description'];

$currpage=$_GET['page']?$_GET['page']:1;
$perpage=9;
$num=C::t('#aljbd#aljbd_consume')->count_by_uid_bid($bd['uid'],$_GET['bid'],'','','',0);
$allpage=ceil($num/$perpage);
$start=($currpage-1)*$perpage;
$nlist=C::t('#aljbd#aljbd_consume')->fetch_all_by_uid_bid($bd['uid'],$_GET['bid'],$start,$perpage,'','','',0);
$nlist = dhtmlspecialchars($nlist);
$notice=C::t('#aljbd#aljbd_notice')->fetch_all_by_uid_bid($bd['uid'],$_GET['bid'],0,9,'','','','',0);
$notice = dhtmlspecialchars($notice);
$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=consume&bid='.$_GET['bid'], 0, 11, false, false);
$bd = dhtmlspecialchars($bd);
if($aljbd_seo['brand_consume_list']['seotitle']){
	$seodata = array('bbname' => $_G['setting']['bbname'],'bdname'=>$bd['name']);
	list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljbd_seo['brand_consume_list']);
}
if($_G['cache']['plugin']['aljsyh']['is_aljsyh']){
    include template('aljsyh:consume/consume');
}else {
    include template('aljbd:consume');
}
//From: Dism��taobao��com
?>