<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$bd=C::t('#aljbd#aljbd')->fetch($_GET['bid']);
if (submitcheck('formhash')) {
	
	if(!$_GET['name']) {
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_2')."','');</script>";
			exit;
		}else{
			showerror(lang('plugin/aljbd','aljbd_2'));
		}
	}
	if(!$_GET['id_card']) {
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".lang('plugin/aljbd','attestation_2')."','');</script>";
			exit;
		}else{
			showerror(lang('plugin/aljbd','attestation_2'));
		}
	}
	if(!$_GET['qiyename']) {
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".lang('plugin/aljbd','attestation_3')."','');</script>";
			exit;
		}else{
			showerror(lang('plugin/aljbd','attestation_3'));
		}
	}
	if(!$_GET['email']) {
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".lang('plugin/aljbd','attestation_4')."','');</script>";
			exit;
		}else{
			showerror(lang('plugin/aljbd','attestation_4'));
		}
	}
	if(!$_GET['tel']) {
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".lang('plugin/aljbd','attestation_5')."','');</script>";
			exit;
		}else{
			showerror(lang('plugin/aljbd','attestation_5'));
		}
	}
	
	$insertarray = array(
		'uid' => $bd['uid'],
		'username' => $bd['username'],
		'name' => $_GET['name'],
		'id_card' => $_GET['id_card'],
		'qiyename' => $_GET['qiyename'],
		'email' => $_GET['email'],
		'tel' => $_GET['tel'],
		'jieshao' => $_GET['jieshao'],
		'bid' => $_GET['bid'],
		'timestamp' => TIMESTAMP,
	);

    $attes = C::t('#aljbd#aljbd_attestation')->fetch($_GET['bid']);
	$idpicarray = array('1'=>'id_pic','2'=>'ban_pic','3'=>'id_pic1','4'=>'pic');
	for ($i = 1; $i <= 4; $i++) {
		
		$pic1 = $idpicarray[$i];
		if ($_GET[$pic1]) {
            if(strpos($_GET[$pic1],$oss_domain) !== false){
                $insertarray[$pic1] = $_GET[$pic1];
            }else if (is_file($_GET[$pic1])) {
                $insertarray[$pic1] = $_GET[$pic1];
            } else {
                unlink($attes[$_GET[$pic1]]);
                $insertarray[$pic1] = T::saveimg($_GET[$pic1],$image_path.'logo/');
            }

		}
	}
	if($_G['cache']['plugin']['aljbzj']['is_aljbzj']){
        $insertarray['business_license_id'] = $_GET['business_license_id'];
        $insertarray['license_comp_adress'] = $_GET['license_comp_adress'];
        $insertarray['license_adress'] = $_GET['license_adress'];
        $insertarray['registered_capital'] = $_GET['registered_capital'];
        $insertarray['company_located'] = $_GET['company_located'];
        $insertarray['company_adress'] = $_GET['company_adress'];
	}
	if($_G['cache']['plugin']['aljrz']['is_file']){
		$insertarray['fujian'] = $_GET['fujian'];
	}
	if(!$attes){
		C::t('#aljbd#aljbd_attestation')->insert($insertarray);
        if($settings['post_brand_type']['value'] == 2 && $_G['cache']['plugin']['aljbzj']['is_aljbzj'] && $_G['cache']['plugin']['aljbzj']['bzj_price']>0){
            $return_url =  'plugin.php?id=aljbzj&bid='.$_GET['bid'];
        }else{
            if($_G['cache']['plugin']['aljbdx'] || $_G['cache']['plugin']['aljgwc']){
                $return_url = 'plugin.php?id=aljbd&act=member_view&bid='.$_GET['bid'];
            }else{
                $return_url = 'plugin.php?id=aljbd&act=member';
            }
        }
	}else{
		$insertarray['sign'] = 0;
		C::t('#aljbd#aljbd_attestation')->update($_GET['bid'], $insertarray);
        if($_G['cache']['plugin']['aljbdx'] || $_G['cache']['plugin']['aljgwc']){
            $return_url = 'plugin.php?id=aljbd&act=member_view&bid='.$_GET['bid'];
        }else{
            $return_url = 'plugin.php?id=aljbd&act=member';
        }
	}
	foreach(DB::fetch_all('select uid from '.DB::table('common_member').' where groupid =1') as $u){
		notification_add($u['uid'], 'system','<a href="plugin.php?id=aljhtx&c=aljbd&a=order&type=5&frames=yes&do=no&twok=3" target="_blank">'.lang('plugin/aljbd','attestation_6').'</a>',array('from_idtype'  => 'aljbd_attestation','from_id' => $bd['id']));
	}

	if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
		echo "<script>parent.tips('".lang('plugin/aljbd','attestation_7')."',function(){parent.location.href='".$return_url."';});</script>";
		exit;
	}else{
		showmsg(lang('plugin/aljbd','attestation_7'));
	}
} else {
	if(!$_G['uid']){
		showmessage(lang('plugin/aljbd','aljbd_1'), '', array(), array('login' => true));
	}
    if($_G['cache']['plugin']['aljbzj']['is_aljbzj']){
        $num=C::t('#aljbd#aljbd')->count_by_status(1,$_G['uid'],'','','','',0,'','','','','','');
        if($num == 1 && !$_GET['bid']){
            $my_bd=C::t('#aljbd#aljbd')->fetch_by_uid($_G['uid']);
            if($my_bd){
                dheader("location: plugin.php?id=aljbd&act=attestation&bid=".$my_bd[id]);
                exit;
            }
        }
        $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,0,0,$_G['uid'],'','','','','','','','','','','',0);
        $c_url = 'plugin.php?id=aljbd&act=attestation&bid=';
    }
	
	if($bd['uid']!=$_G['uid'] && !$admin_status){
		showmessage(lang('plugin/aljbd','aljbd_7'));
	}
	$lp	=C::t('#aljbd#aljbd_attestation')->fetch($_GET['bid']);
	$navtitle = '&#21830;&#23478;&#35748;&#35777;';

    if($newtemplate){
        include template($common_template_pluginid.':new/post/attestation');
    }else {
        include template('aljbd:attestation');
    }
}
//From: Dism��taobao��com
?>