<?php

/*
 * ��ҳ��http://t.cn/Aiux14ti
 * ��ϵQQ:467783778
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$file = 'aljbd_qrcode.jpg';	 QRcode::png($_G['siteurl'].'plugin.php?id=aljbd', 'source/plugin/aljbd/images/qrcode/'.$file, QR_MODE_STRUCTURE, 8);
?>