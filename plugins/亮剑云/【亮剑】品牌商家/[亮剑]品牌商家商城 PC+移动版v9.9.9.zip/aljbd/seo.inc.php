<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
$plugin = DB::fetch_first('select * from %t where identifier = %s', array('common_plugin', 'aljhtx'));
if(empty($plugin)){
    cpmsg('&#35831;&#20808;&#23433;&#35013;&#21830;&#23478;&#21161;&#25163;&#25554;&#20214;');
}
$plugin = DB::fetch_first('select * from %t where identifier = %s and available=1', array('common_plugin', 'aljhtx'));
if(empty($plugin)){
    cpmsg('&#35831;&#20808;&#21551;&#29992;&#21830;&#23478;&#21161;&#25163;&#25554;&#20214;');
}
if($_G['cache']['plugin']['aljht']['on']){
	echo '<iframe style="width:100%;height:100%;min-height:760px;border:none;" src="plugin.php?id=aljhtx&c=aljbd&a=order&type=10&twok=0&onek=3&ajax=yes&dzAdmin=1"></iframe>';
	exit;
}
$pluginid='aljbd';
$lang = array_merge($lang, $scriptlang[$pluginid]);

if(empty($_GET['ac'])) {

	if(!submitcheck('seosubmit')) {
		echo '<script type="text/javascript">
		function insertContent(obj, text) {
			var obj = obj.parentNode.parentNode.firstChild.lastChild;
			selection = document.selection;
			obj.focus();
			if(!isUndefined(obj.selectionStart)) {
				var opn = obj.selectionStart + 0;
				obj.value = obj.value.substr(0, obj.selectionStart) + text + obj.value.substr(obj.selectionEnd);
			} else if(selection && selection.createRange) {
				var sel = selection.createRange();
				sel.text = text;
				sel.moveStart(\'character\', -strlen(text));
			} else {
				obj.value += text;
			}
		}
		</script>';

		$aljbd_seo = dunserialize($_G['setting']['aljbd_seo']);

		$page = array(
			'index' => array('bbname'),
			'list' => array('bbname', 'cat','cat2','cat3','region','region2','region3'),
			'view' => array('bbname', 'subject', 'message', 'cat','cat2','cat3','region','region2','region3','view_keyword'),
			'good_list' => array('bbname','cat','cat2','cat3'),
			'brand_good_list' => array('bbname', 'bdname','cat','cat2','cat3'),
			'good_view' => array('bbname', 'subject', 'message','bdname'),
			'notice_list' => array('bbname', 'cat'),
			'brand_notice_list' => array('bbname', 'bdname'),
			'notice_view' => array('bbname', 'subject', 'message','bdname'),
			'consume_list' => array('bbname', 'cat'),
			'brand_consume_list' => array('bbname', 'bdname'),
			'consume_view' => array('bbname', 'subject', 'message','bdname'),
			'brand_album_list' => array('bbname', 'bdname'),
			'album_view' => array('bbname', 'subject','bdname'),
			'map_index' => array('bbname'),
		);
		showformheader('plugins&operation=config&identifier='.$pluginid.'&pmod=seo');
		showtableheader();
		foreach($page as $key => $value) {
			$code = cplang('code');
			foreach($value as $v) {
				$code .= '<a onclick="insertContent(this, \'{'.$v.'}\');return false;" href="javascript:;" title="'.cplang($v).'">{'.cplang($v).'}</a>';
			}
			showtitle('page_'.$key);
			showsetting('seotitle', 'aljbd_seo['.$key.'][seotitle]', $aljbd_seo[$key]['seotitle'], 'text', '', 0, $code);
			showsetting('seokeywords', 'aljbd_seo['.$key.'][seokeywords]', $aljbd_seo[$key]['seokeywords'], 'text', '', 0, $code);
			showsetting('seodescription', 'aljbd_seo['.$key.'][seodescription]', $aljbd_seo[$key]['seodescription'], 'text', '', 0, $code);
		}
		showsubmit('seosubmit');
		showtablefooter(); /*dism _taobao _com*/
		showformfooter(); /*dism_taobao_com*/

	} else {
		$aljbd_seo = serialize($_GET['aljbd_seo']);
		DB::query("REPLACE INTO ".DB::table('common_setting')." (skey, svalue) VALUES ('aljbd_seo', '$aljbd_seo')");
		updatecache('setting');

		cpmsg('seo_update_succeed', 'action=plugins&operation=config&identifier='.$pluginid.'&pmod=seo', 'succeed');
	}
}
//From: Dism_taobao_com
?>