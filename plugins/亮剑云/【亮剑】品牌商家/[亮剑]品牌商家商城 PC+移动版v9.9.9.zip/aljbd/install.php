<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljbd_search_keyword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `keyword` (`keyword`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_attr` (
  `mid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(10) unsigned NOT NULL,
  `name` int(10) NOT NULL,
  `content` text,
  `addtime` int(10) unsigned NOT NULL,
  `typeid` int(10) NOT NULL,
  PRIMARY KEY (`mid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_kami` (
  `mid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` int(10) unsigned NOT NULL,
  `message` text,
  `uid` mediumint(8) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `dateline` int(10) unsigned NOT NULL,
  `orderid` varchar(255) NOT NULL,
  PRIMARY KEY (`mid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `tel` varchar( 255 ) NOT NULL,
  `addr` varchar(255) NOT NULL,
  `type` int(10) NOT NULL,
  `subtype` int(10) NOT NULL,
  `subtype3` int(10) NOT NULL,
  `region` int(10) NOT NULL,
  `qq` BIGINT NOT NULL,
  `displayorder` int(10) NOT NULL,
  `subregion` int(10) NOT NULL,
  `intro` mediumtext NOT NULL,
  `other` mediumtext NOT NULL,
  `logo` varchar(255) NOT NULL,
  `view` int(10) NOT NULL,
  `dateline` int(10) NOT NULL,
  `x` decimal(10,6) NOT NULL,
  `y` decimal(10,6) NOT NULL,
  `star` tinyint(3) NOT NULL,
  `comment` int(10) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `recommend` tinyint(3) NOT NULL,
  `gg` varchar(255) NOT NULL,
  `adv` TEXT NOT NULL,
  `others` TEXT NOT NULL,
  `advurl` TEXT NOT NULL,
  `wurl` varchar(255) NOT NULL,
  `qrcode` varchar(255) NOT NULL,
  `region1` varchar(255) NOT NULL,
  `business_hours` varchar(255) NOT NULL,
  `bus_routes` varchar(255) NOT NULL,
  `businesstype` varchar(255) NOT NULL,
  `collection` int(10) NOT NULL,
  `wangwang` varchar(100) NOT NULL,
  `weixin_id` varchar(100) NOT NULL,
  `madv` TEXT NOT NULL,
  `madvurl` TEXT NOT NULL,
  `rubbish` int(10) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `orderid` char(32) NOT NULL,
  `vipid` int(11) NOT NULL,
  `vipendtime` int(11) NOT NULL,
  `kf_uid` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `label` VARCHAR( 255 ) NOT NULL,
  `fare_type` tinyint(3) NOT NULL,
  `hide_tel` tinyint(3) NOT NULL,
  `brand_bg` varchar(255) NOT NULL,
  `postal_amount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `name` (`name`),
  KEY `type` (`type`),
  KEY `displayorder` (`displayorder`),
  KEY `region` (`region`),
  KEY `view` (`view`),
  KEY `x` (`x`),
  KEY `y` (`y`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_comment` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `bid` int(10) NOT NULL,
  `content` varchar(255) NOT NULL,
  `k` int(255) NOT NULL default '0',
  `h` int(255) NOT NULL default '0',
  `f` int(255) NOT NULL default '0',
  `displayorder` varchar(255) NOT NULL default '0',
  `dateline` varchar(255) NOT NULL,
  `upid` int(10) NOT NULL,
  `avg` float NOT NULL,
  `ask` tinyint(3) NOT NULL default '0',
  `rubbish` int(10) NOT NULL,
  `status` TINYINT( 3 ) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_point` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `bid` int(10) NOT NULL,
  `buid` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `x` float NOT NULL,
  `y` float NOT NULL,
  `dateline` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_region` (
  `catid` int(11) NOT NULL auto_increment,
  `upid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `subcatid` varchar(255) NOT NULL,
  `havechild` int(255) NOT NULL,
  `level` int(11) NOT NULL,
  `displayorder` int(11) NOT NULL,
  PRIMARY KEY  (`catid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_type` (
  `id` mediumint(9) unsigned NOT NULL auto_increment,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `type_url` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_type_brand` (
  `id` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  `bid` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `type` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bid` (`bid`),
  KEY `upid` (`upid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_type_goods` (
  `id` mediumint(9) unsigned NOT NULL auto_increment,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  `logo` varchar(255) NOT NULL,
  `brand_id` text NOT NULL,
  `type_ad` text NOT NULL,
  `pclabel` text NOT NULL,
  `type_url` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_username` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `bid` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_winfo` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `winfo` varchar(255) NOT NULL,
  `bid` varchar(255) NOT NULL,
  `dateline` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
);
 CREATE TABLE IF NOT EXISTS `pre_aljbd_goods` (
  `id` int(10) NOT NULL auto_increment,
  `bid` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price1` decimal(10,2) NOT NULL,
  `new_price` decimal(10,2) NOT NULL,
  `price2` decimal(10,2) NOT NULL,
  `view` int(10) NOT NULL,
  `pic1` varchar(255) NOT NULL,
  `pic2` varchar(255) NOT NULL,
  `pic3` varchar(255) NOT NULL,
  `pic4` varchar(255) NOT NULL,
  `pic5` varchar(255) NOT NULL,
  `pic6` varchar(255) NOT NULL,
  `pic7` varchar(255) NOT NULL,
  `pic8` varchar(255) NOT NULL,
  `pic9` varchar(255) NOT NULL,
  `pic10` varchar(255) NOT NULL,
  `pic11` varchar(255) NOT NULL,
  `pic12` varchar(255) NOT NULL,
  `gwurl` varchar(255) NOT NULL,
  `intro` longtext NOT NULL,
  `dateline` int(10) NOT NULL,
  `subtype3` int(10) NOT NULL,
  `subtype` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `sign` int(11) NOT NULL,
  `amount` int(10) NOT NULL,
  `buyamount` int(10) NOT NULL,
  `endtime` int(10) NOT NULL,
  `displayorder` int(10) NOT NULL,
  `state`  tinyint(3) NOT NULL,
  `fare` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `fare_desc` int(10) NOT NULL,
  `collection` int(10) NOT NULL,
  `rubbish` int(10) NOT NULL,
  `attr_key` text NOT NULL,
  `attr_value` text NOT NULL,
  `attr_sku` text NOT NULL,
  `btypeid` int(10) NOT NULL,
  `bsubtypeid` int(10) NOT NULL,
  `selling_point` varchar(255) NOT NULL,
  `category` tinyint(3) NOT NULL,
  `commodity_type` tinyint(3) NOT NULL,
  `starttime` int(11) NOT NULL,
  `collage_price` decimal(10,2) NOT NULL,
  `collage_num` int(11) NOT NULL,
  `brief` varchar(255) NOT NULL,
  `region` int(10) NOT NULL,
  `subregion` int(10) NOT NULL,
  `limit_amount` int(11) NOT NULL,
  `region1` varchar(255) NOT NULL,
  `give_integral` INT NOT NULL,
  `pay_integral` INT NOT NULL,
  `service_label` VARCHAR( 255 ) NOT NULL,
  `sh_status` tinyint(3) NOT NULL,
  `is_pt_sku` tinyint(3) NOT NULL,
  `is_aljtcc` tinyint(3) NOT NULL,
  `m_intro_img` text NOT NULL,
  `m_intro_text` text NOT NULL,
  `vr_url` varchar(255) NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `video_path` varchar(255) NOT NULL,
  `commodity_code` varchar(255) NOT NULL,
  `cover_image` varchar(255) NOT NULL,
  `intro_video_path` varchar(255) NOT NULL,
  `is_volume` tinyint(3) NOT NULL,
  `unit` char(20) NOT NULL,
  `store_id` int(11) NOT NULL,
  `weight` decimal(10,3) NOT NULL,
  `card_price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `displayorder` (`displayorder`),
  KEY `sign` (`sign`),
  KEY `rubbish` (`rubbish`),
  KEY `sh_status` (`sh_status`),
  KEY `video_path` (`video_path`),
  KEY `buyamount` (`buyamount`),
  KEY `price1` (`price1`),
  KEY `view` (`view`),
  KEY `endtime` (`endtime`),
  KEY `type` (`type`),
  KEY `region` (`region`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_ather` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `desc` text NOT NULL,
  `addtime` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `displayorder` int(11) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_syscache` (
  `id` int(11) NOT NULL auto_increment,
  `plugin_b` varchar(255) NOT NULL,
  `plugin_w` mediumtext NOT NULL,
  `plugin_sign` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_comment_notice` (
  `id` int(11) NOT NULL auto_increment,
  `upid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `bid` int(11) NOT NULL,
  `nid` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `content` mediumtext NOT NULL,
  `rubbish` int(10) NOT NULL,
  `status` TINYINT( 3 ) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_notice` (
  `id` int(11) NOT NULL auto_increment,
  `bid` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `dateline` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `view` int(11) NOT NULL,
  `sign` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `subtype` int(11) NOT NULL,
  `collection` int(10) NOT NULL,
  `rubbish` int(10) NOT NULL,
  `region` int(10) NOT NULL,
  `subregion` int(10) NOT NULL,
  `region1` varchar(255) NOT NULL,
  `status` TINYINT( 3 ) NOT NULL,
  `reason` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bid` (`bid`),
  KEY `subject` (`subject`),
  KEY `view` (`view`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_album` (
  `id` int(11) NOT NULL auto_increment,
  `bid` int(11) NOT NULL,
  `albumname` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `dateline` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `view` int(11) NOT NULL,
  `sign` int(11) NOT NULL,
  `picnum` int(11) NOT NULL,
  `lastpost` int(11) NOT NULL,
  `displayorder` int(11) NOT NULL,
  `subjectimage` varchar(255) NOT NULL,
  `rubbish` int(10) NOT NULL,
  `status` TINYINT( 3 ) NOT NULL,
  `reason` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bid` (`bid`),
  KEY `albumname` (`albumname`),
  KEY `view` (`view`),
  KEY `displayorder` (`displayorder`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_album_attachments` (
  `id` int(11) NOT NULL auto_increment,
  `bid` int(11) NOT NULL,
  `aid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `displayorder` int(11) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `rubbish` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_comment_consume` (
  `id` int(11) NOT NULL auto_increment,
  `upid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `bid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `content` mediumtext NOT NULL,
  `rubbish` int(10) NOT NULL,
  `status` TINYINT( 3 ) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_consume` (
  `id` int(11) NOT NULL auto_increment,
  `bid` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `jieshao` MEDIUMTEXT NOT NULL,
  `xianzhi` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `start` int(11) NOT NULL,
  `end` int(11) NOT NULL,
  `mianze` varchar(255) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `view` int(11) NOT NULL,
  `downnum` int(11) NOT NULL,
  `sign` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `subtype` int(11) NOT NULL,
  `collection` int(10) NOT NULL,
  `rubbish` int(10) NOT NULL,
  `full` decimal(10,2) NOT NULL,
  `reduction` decimal(10,2) NOT NULL,
  `region` int(10) NOT NULL,
  `subregion` int(10) NOT NULL,
  `region1` varchar(255) NOT NULL,
  `status` TINYINT( 3 ) NOT NULL,
  `reason` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `start` (`start`),
  KEY `end` (`end`),  
  KEY `bid` (`bid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_attestation` (
  `bid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `id_card` bigint(20) NOT NULL,
  `id_pic` varchar(255) NOT NULL,
  `qiyename` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `sign` tinyint(4) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `jieshao` mediumtext NOT NULL,
  `ban_pic` varchar(255) NOT NULL,
  `id_pic1` varchar(255) NOT NULL,
  `business_license_id` varchar(255) NOT NULL,
  `license_comp_adress` varchar(255) NOT NULL,
  `license_adress` varchar(255) NOT NULL,
  `registered_capital` int(10) NOT NULL,
  `company_located` varchar(255) NOT NULL,
  `company_adress` varchar(255) NOT NULL,
  `reason` varchar(255) NOT NULL,
  PRIMARY KEY  (`bid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_usergroup` (
  `groupid` int(11) NOT NULL,
  `brand` int(11) NOT NULL,
  `good` int(11) NOT NULL,
  `notice` int(11) NOT NULL,
  `album` int(11) NOT NULL,
  `consume` int(11) NOT NULL,
  `grouptitle` varchar(255) NOT NULL,
  PRIMARY KEY  (`groupid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_vip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `good` int(11) NOT NULL,
  `notice` int(11) NOT NULL,
  `album` int(11) NOT NULL,
  `consume` int(11) NOT NULL,
  `video` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `day` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `fee` int(11) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `displayorder` int(11) NOT NULL,
  `give_integral` INT NOT NULL,
  `pay_integral` INT NOT NULL,
  `is_distribution` tinyint(3) NOT NULL,
  `is_video` tinyint(3) NOT NULL,
  `is_bvideo` tinyint(3) NOT NULL,
  `is_consume` tinyint(3) NOT NULL,
  `is_notice` tinyint(3) NOT NULL,
  `is_album` tinyint(3) NOT NULL,
  `is_goods` tinyint(3) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `bzj_price` decimal(10,2) NOT NULL,
  `store_authority` text NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_type_consume` (
  `id` mediumint(9) unsigned NOT NULL auto_increment,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `type_url` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_type_notice` (
  `id` mediumint(9) unsigned NOT NULL auto_increment,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `type_url` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_order` (
  `orderid` char(32) NOT NULL DEFAULT '',
  `status` char(3) NOT NULL DEFAULT '',
  `buyer` char(50) NOT NULL DEFAULT '',
  `admin` char(15) NOT NULL DEFAULT '',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL,
  `sid` int(11) NOT NULL,
  `stitle` varchar(255) NOT NULL,
  `amount` int(10) unsigned NOT NULL DEFAULT '0',
  `price` float(10,2) unsigned NOT NULL DEFAULT '0.00',
  `submitdate` int(10) unsigned NOT NULL DEFAULT '0',
  `confirmdate` int(10) unsigned NOT NULL DEFAULT '0',
  `email` char(40) NOT NULL DEFAULT '',
  `ip` char(15) NOT NULL DEFAULT '',
  `remarks` varchar(255) NOT NULL,
  `d` tinyint(3) NOT NULL,
  `payment` char(50) NOT NULL DEFAULT '',
  UNIQUE KEY `orderid` (`orderid`),
  KEY `submitdate` (`submitdate`),
  KEY `uid` (`uid`,`submitdate`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_setting` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `a` varchar(255) NOT NULL,
  `b` varchar(255) NOT NULL,
  `c` text NOT NULL,
  `d` int(11) NOT NULL,
  `e` int(11) NOT NULL,
  PRIMARY KEY (`key`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_settle` (
  `settleid` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `account` varchar(255) NOT NULL,
  `settleprice` varchar(255) NOT NULL,
  `payment` tinyint(3) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `applytime` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `uid` int(10) NOT NULL,
  PRIMARY KEY (`settleid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_user` (
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `bid` int(10) NOT NULL,
  `qq` int(10) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `addr` varchar(255) NOT NULL,
  PRIMARY KEY (`uid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_wuliu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(255) NOT NULL,
  `type` int(10) NOT NULL,
  `companyname` varchar(255) NOT NULL,
  `worderid` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `updatetime` int(10) NOT NULL,
  `a` int(10) NOT NULL,
  `b` int(10) NOT NULL,
  `c` varchar(255) NOT NULL,
  `d` varchar(255) NOT NULL,
  `e` varchar(255) NOT NULL,
  `info` text NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `dateline` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `view` int(11) NOT NULL,
  `sign` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `subtype` int(11) NOT NULL,
  `displayorder` int(11) NOT NULL,
  `rubbish` int(10) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_emaillog` (
  `id` int(10) NOT NULL auto_increment,
  `sendemail` varchar(255) NOT NULL,
  `sendtype` tinyint(3) NOT NULL,
  `sendtime` int(10) NOT NULL,
  `success` tinyint(3) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_write_off_code` (
`password` bigint(12) NOT NULL,
  `orderid` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `shop_id` int(10) NOT NULL,
  `goods_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `endtime` int(10) NOT NULL,
  `status` int(10) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `hx_uid` int(10) NOT NULL,
  `store_id` int(10) NOT NULL,
  `cid` int(10) NOT NULL,
  `hx_username` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`password`),
  KEY `orderid` (`orderid`),
  KEY `password` (`password`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_goods_volume_price` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price_type` tinyint(4) NOT NULL,
  `goods_id` int(11) NOT NULL,
  `volume_number` int(11) NOT NULL,
  `volume_price` decimal(10,2) NOT NULL,
  `path` varchar(255) NOT NULL,
  `volume_price_pt` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_platform_revenue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `desca` varchar(1000) NOT NULL,
  `orderid` char(32) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `fee` decimal(3,2) NOT NULL,
  `pluginid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pluginid` (`pluginid`,`store_id`,`fee`) USING BTREE,
  KEY `fee` (`fee`,`bid`,`pluginid`) USING BTREE,
  KEY `time` (`time`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_goods_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gid` int(11) NOT NULL,
  `addtime` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `goodsinfo` text NOT NULL,
  `url` varchar(300) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gid` (`gid`),
  KEY `uid` (`uid`)
)
EOF;
runquery($sql);
$aljbd_bdisplayorder = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'bdisplayorder\'', array('aljbd_goods'), true);
if(!$aljbd_bdisplayorder){
$sql = <<<EOF
ALTER TABLE `pre_aljbd_goods` ADD `bdisplayorder` INT NOT NULL;
ALTER TABLE `pre_aljbd_goods` ADD `other` text NOT NULL;
ALTER TABLE `pre_aljbd_goods` ADD INDEX(`bdisplayorder`);
EOF;
runquery($sql);
}
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `qg_type`  TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `limit_type`  TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD  `product_label` VARCHAR( 255 ) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_type')." ADD `is_open`  TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_type_goods')." ADD `is_open`  TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_type_consume')." ADD `is_open`  TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljbd_type_notice')." ADD `is_open`  TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_vip')." ADD `is_hide` tinyint(4) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_notice')." ADD `rec_gids` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_notice')." ADD `displayorder` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_notice')." ADD `cover_pic` text NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods')." ADD  `is_aljtcc` TINYINT(3) NOT NULL" ;
DB::query($sql,'SILENT');
require_once 'source/plugin/aljbd/include/initalData.php';
require_once 'source/plugin/aljbd/include/installData.php';
//finish to put your own code
$finish = TRUE;
?>