<?php

/*
 * ������
 * QQ:467783778
 *
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$imgnum = 12;
$yhzqx = 0;
foreach(DB::fetch_all('select * from %t',array('common_plugin')) as $cpv){
    $cparray[$cpv['identifier']] = $cpv;
}

$nobbname = true;

$_GET['kw'] = dhtmlspecialchars($_GET['kw']);

if (file_exists("source/plugin/aljgz/lang/lang.php")) {
	require_once 'source/plugin/aljgz/lang/lang.php';
}

require_once libfile('function/home');
$pluginid="aljbd";
require_once libfile('function/mail');
$aljbd_seo = dunserialize($_G['setting']['aljbd_seo']);
$checksign = 99999999;

if(empty($config['is_daohang'])){
	$_G['setting']['switchwidthauto']=0;
	$_G['setting']['allowwidthauto']=1;
}

require_once 'source/plugin/aljbd/include/aljbd_parameter.php';

require_once 'source/plugin/aljbd/lang/lang.php';
$config = $_G['cache']['plugin']['aljbd'];
//debug($config);
//$keyword = T::participle('iphone00');
//debug($keyword);

if (file_exists("source/plugin/aljbd/act/gmap.php")) {
    require_once 'source/plugin/aljbd/act/gmap.php';
}


if($settings['is_self_support']['value']==1 && $_GET['map'] != 'pois') {
    
    $ss_act = array('attend','dianpu','view');
    if(in_array($_GET['act'],$ss_act)){
        header('location: plugin.php?id=aljbd');
        exit;
    }
}


if($_G['cache']['plugin']['aljht']['on'] && $_GET['map'] != 'pois' && (empty($_G['mobile']) || !$_G['setting']['mobile']['allowmobile']) && ($cparray['aljgwc'] || $cparray['aljbdx'])){
    $my_bd = DB::result_first('select count(*) from %t where uid=%d',array('aljbd',$_G['uid']));
    $urlbrand = 'plugin.php?id=aljht&act=admin&op=brand&mod=my';
    $urlattend = 'plugin.php?id=aljht&act=admin&op=brand&do=adddp&mod=my';
    $urlgoods = 'plugin.php?id=aljht&act=admin&op=goods&mod=my';
    $urlnotice = 'plugin.php?id=aljht&act=admin&op=notice&mod=my';
    $urlconsume = 'plugin.php?id=aljht&act=admin&op=consume&mod=my';
    $urlalbum = 'plugin.php?id=aljht&act=admin&op=album&mod=my';
	if($_GET['ord'] == 'admin'){
        $urlorder = 'plugin.php?id=aljhtx&c=aljbd&a=order&type=4';
		$urlattes = 'plugin.php?id=aljhtx&c=aljbd&a=order&type=5&frames=yes&onek=0&twok=3';
    }else if($my_bd && $_GET['ord'] == 'dianp'){
		$urlorder = 'plugin.php?id=aljht&act=admin&op=orderlist&mod=my&ord=dianpu';
		$urlattes = 'plugin.php?id=aljht&act=admin&op=attestation&mod=my';
	}else{
		$urlorder = 'plugin.php?id=aljht&act=admin&op=orderlist&mod=my&ord=ge';
        $urlattes = 'plugin.php?id=aljht&act=admin&op=attestation&mod=ge';
	}

	if($_GET['act'] == 'member'){
		dheader("location: ".$urlbrand);
        exit;
	}elseif($_GET['act'] == 'orderlist'){
		dheader("location: ".$urlorder);
        exit;
	}elseif($_GET['act'] == 'attend'){
		dheader("location: ".$urlattend);
        exit;
	}elseif($_GET['act'] == 'goodslist'){
		dheader("location: ".$urlgoods);
        exit;
	}elseif($_GET['act'] == 'noticelist'){
		dheader("location: ".$urlnotice);
        exit;
	}elseif($_GET['act'] == 'consumelist'){
		dheader("location: ".$urlconsume);
		exit;
	}elseif($_GET['act'] == 'attestation'){
		dheader("location: ".$urlattes);
		exit;
	}elseif($_GET['act'] == 'albumlist' || $_GET['act'] == 'albumall'){
        dheader("location: ".$urlalbum);
        exit;
    }elseif($_GET['act'] == 'edit'){
        dheader("location: plugin.php?id=aljht&act=admin&op=brand&do=edit&bid=".$bid."&mod=my");
        exit;
    }
    if(!$_G['mobile'] && $_G['cache']['plugin']['aljtc']){
        if($_GET['act'] == 'addgoods' && !$_GET['do']){
            dheader("location: plugin.php?id=aljht&act=admin&op=goods&do=addgoods&mod=my&commodity_type=".$_GET['commodity_type']);
            exit;
        }elseif($_GET['act'] == 'addnotice'){
            dheader("location: plugin.php?id=aljht&act=admin&op=goods&do=addnotice&mod=my");
            exit;
        }elseif($_GET['act'] == 'addconsume'){
            dheader("location: plugin.php?id=aljht&act=admin&op=goods&do=addconsume&mod=my");
            exit;
        }elseif($_GET['act'] == 'addvideo'){
            dheader("location: plugin.php?id=aljht&act=admin&op=goods&do=addvideo&mod=my");
            exit;
        }
    }
}

if($_G['cache']['plugin']['aljbd']['iswatermark']){
	require_once DISCUZ_ROOT.'source/plugin/aljbd/class/class_image.php';
	$image = new aljbd_image;
}
require_once DISCUZ_ROOT.'source/plugin/aljbd/class/qrcode.class.php';
if (file_exists("source/plugin/aljbd/com/qrcode.php")) {
	if (!file_exists("source/plugin/aljbd/images/qrcode/aljbd_qrcode.jpg")) {
		include 'source/plugin/aljbd/com/qrcode.php';
	}
}
if(!$_G['mobile'] && file_exists("source/plugin/dz_1/dz_1.inc.php")){
    include template('aljbd:qrcode');
    exit;
}
$customurl = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['dcdz']['customurl']));

$m_hot_search = explode ("\n", str_replace ("\r", "", $config ['m_hot_search']));
foreach($m_hot_search as $key=>$value){
	$arr=explode('|',$value);

	$m_hot_search_types[]=$arr;
}

$config['atypes'] = str_replace('\r', '\n', $config['atypes']);
$atypes = explode("\n", $config['atypes']);
foreach ($atypes as $k => $type) {
	$type = explode('|', $type);
	$typename[$type[0]] = trim($type[1]);
}



$act = $_GET['act'];


$mygroup=C::t('#aljbd#aljbd_usergroup')->fetch($_G['groupid']);



$ext_symbol = $_G['setting']['extcredits'][$config['extcredit']]['title'];
if ($_G['uid'] && $config['extcredit']) {
	$money = DB::result_first("select extcredits%d from %t where uid=%d",array($config['extcredit'],'common_member_count',$_G['uid']));
}
$imgmes = lang('plugin/aljbd','s12');
$login_callback = 'member.php?mod=logging&action=login&referer=plugin.php?id=aljbd%26act='.$act;




//��Ʒ����
if($settings['close_goods']['value']){
	if($_GET['act'] == 'goodslist' || $_GET['act'] == 'addgoods' || $_GET['act'] == 'editgoods' || $_GET['act'] == 'goods' || $_GET['act'] == 'goodview' || $_GET['act'] == 'good'){
		showmessage($aljbdlang['php']['aljbd_1']);
	}
}
//�Ż�ȯ����
if($settings['close_consume']['value']){
	if($_GET['act'] == 'clist' || $_GET['act'] == 'consumeview' || $_GET['act'] == 'consume' || $_GET['act'] == 'consumelist' || $_GET['act'] == 'editconsume' || $_GET['act'] == 'addconsume'){
		showmessage($aljbdlang['php']['aljbd_2']);
	}
}
//���鿪��
if($settings['close_notice']['value']){
	if($_GET['act'] == 'notice' || $_GET['act'] == 'noticeview' || $_GET['act'] == 'nlist' || $_GET['act'] == 'noticelist' || $_GET['act'] == 'editnotice' || $_GET['act'] == 'addnotice'){
		showmessage($aljbdlang['php']['aljbd_3']);
	}
}
//��Ὺ��
if($settings['close_album']['value']){
	if($_GET['act'] == 'album' || $_GET['act'] == 'albumview' || $_GET['act'] == 'albumlist' || $_GET['act'] == 'addalbum' || $_GET['act'] == 'editalbum' || $_GET['act'] == 'addalbumimg'){
		showmessage($aljbdlang['php']['aljbd_4']);
	}
}
if($cparray['aljbgp']){
	$brandtips = htmlspecialchars_decode($settings['aljbgp_brandtips']['value']);
	$goodstips = htmlspecialchars_decode($settings['aljbgp_goodstips']['value']);
	$noticetips = htmlspecialchars_decode($settings['aljbgp_noticetips']['value']);
	$consumetips = htmlspecialchars_decode($settings['aljbgp_consumetips']['value']);
	$albumtips = htmlspecialchars_decode($settings['aljbgp_albumtips']['value']);
}


//��ҳ�ֲ��������
if($settings['aljad_index_lz']['value']) {
    $aljad_index_lz = explode ("\n", str_replace ("\r", "", htmlspecialchars_decode($settings['aljad_index_lz']['value'])));
}
//��ҳ��ת�·��������
if($settings['aljad_index_lz_lower']['value']){
    $aljad_index_lz_lower = htmlspecialchars_decode($settings['aljad_index_lz_lower']['value']);
}
//����������
if($settings['aljad_index_sangead']['value']) {
    $aljad_index_sangead = explode ("\n", str_replace ("\r", "", htmlspecialchars_decode($settings['aljad_index_sangead']['value'])));
}
//�����ĸ���
if($settings['aljad_index_four_lattice']['value']) {
    $aljad_index_four_lattice = explode ("\n", str_replace ("\r", "", htmlspecialchars_decode($settings['aljad_index_four_lattice']['value'])));
}



if(file_exists("source/plugin/aljqb/pay/autotx_balance_toApp.php")){
    require_once 'source/plugin/aljqb/pay/autotx_balance_toApp.php';
}

$actarray = array(
    'googlemap',
    'type',
    'search',
    'search_keyword',
    'linkage',
    'cpd_img',
    'user',
    'receipt',
    'fl',
    'dq',
    'order',
    'dianping',
    'mobile_list_region',
    'mobile_list_type',
    'mobile_list_brand',
    'dianpu',
    'mobile_list_goods',
    'goods',
    'clist',
    'nlist',
    'ajax',
    'alist',
    'attend',
    'edit',
    'glmsg',
    'member',
    'yes',
    'no_pay',
    'attestation',
    'gg',
    'intro',
    'adv',
    'madv',
    'winfo',
    'winfolist',
    'commentlist',
    'deletecomment',
    'gettype',
    'gettype3',
    'getgoodstype',
    'getgoodstype3',
    'admingetregion',
    'admingetregion1',
    'getregion',
    'getregion1',
    'mobile_index_goods',
    'view',
    'comment',
    'ask',
    'reply',
    'map',
    'mark',
    'point',
    'pointok',
    'pointdel',
    'iwantclaim',
    'delete',
    'goodslist',
    'good',
    'view_expose_list',
    'expose_detail_reply',
    'goodview',
    'addgoods',
    'editgoods',
    'deletegoods',
    'consume',
    'consumeview',
    'print',
    'consumelist',
    'cask',
    'creply',
    'addconsume',
    'editconsume',
    'deleteconsume',
    'deletenotice',
    'deletealbum',
    'noticeview',
    'noticelist',
    'viewpage',
    'addnotice',
    'editnotice',
    'notice',
    'replynotice',
    'pagelist',
    'addpage',
    'editpage',
    'deletepage',
    'nask',
    'nreply',
    'albumlist',
    'album',
    'addalbum',
    'delalbum',
    'delalbum_1',
    'editalbum',
    'albumall',
    'addalbumimg',
    'albumview',
    'orderlist',
    'deleteorder',
    'trade',
    'tradesubmit',
    'mtradesubmit',
    'addr',
    'viewaddr',
    'settle',
    'editsettle',
    'settlelist',
    'deletesettle',
    'agreesettle',
    'disagreesettle',
    'viewwuliu',
    'wuliu',
    'addkami',
    'addkamisubmit',
    'kamilist',
    'deletekami',
    'viewkami',
    'addattr',
    'addattrsubmit',
    'attrlist',
    'deleteattr',
    'wxpay',
    'set',
    'new',
    'mini',
    'mini_sh',
    'logout',
    'member_view',
    'view_about',
    'echo_imgsrc',
    'about'
    );
if(in_array($_GET['act'],$actarray)){
    if($_GET['act'] == 'attend' || $_GET['act'] == 'edit'){
        require_once 'source/plugin/'.$pluginid.'/act/attend.php';
    }else if($_GET['act'] == 'addgoods' || $_GET['act'] == 'editgoods'){
        require_once 'source/plugin/'.$pluginid.'/act/addgoods.php';
    }else if($_GET['act'] == 'addnotice' || $_GET['act'] == 'editnotice'){
        require_once 'source/plugin/'.$pluginid.'/act/addnotice.php';
    }else if($_GET['act'] == 'addconsume' || $_GET['act'] == 'editconsume'){
        require_once 'source/plugin/'.$pluginid.'/act/addconsume.php';
    }else if($_GET['act'] == 'addalbum' || $_GET['act'] == 'editalbum'){
        require_once 'source/plugin/'.$pluginid.'/act/addalbum.php';
    }else{
        require_once 'source/plugin/'.$pluginid.'/act/'.$_GET['act'].'.php';
    }
}else{
    require_once 'source/plugin/'.$pluginid.'/act/index.php';
}
function del_brand_all($bid){
    global $cparray;
	//�̼�
	C::t('#aljbd#aljbd')->update($bid,array('rubbish'=>'1'));
	//�̼�����
	DB::update('aljbd_comment',array('rubbish'=>'1'), array('bid'=>$bid));
	//��Ʒ
	DB::update('aljbd_goods',array('rubbish'=>'1'), array('bid'=>$bid));
	//����
	$is_plugin_gwc = $cparray['aljgwc'];
	if($is_plugin_gwc){
		DB::update('aljbd_comment_goods',array('rubbish'=>'1'), array('bid'=>$bid));
	}
	//����
	DB::update('aljbd_notice',array('rubbish'=>'1'), array('bid'=>$bid));
	//����
	DB::update('aljbd_comment_notice',array('rubbish'=>'1'), array('bid'=>$bid));
	//�Ż�ȯ
	DB::update('aljbd_consume',array('rubbish'=>'1'), array('bid'=>$bid));
	//����
	DB::update('aljbd_comment_consume',array('rubbish'=>'1'), array('bid'=>$bid));
	//���
	DB::update('aljbd_album',array('rubbish'=>'1'), array('bid'=>$bid));
	DB::update('aljbd_album_attachments',array('rubbish'=>'1'), array('bid'=>$bid));
	//���̵���
	DB::update('aljbd_page',array('rubbish'=>'1'), array('bid'=>$bid));
	//�̼���Ƶ
	$is_plugin = $cparray['aljsp'];
	if($is_plugin){
		DB::update('aljbd_video',array('rubbish'=>'1'), array('bid'=>$bid));
	}
}
function showmsg($msg,$close=''){
	if($close){
		$str="parent.hideWindow('$close');";
	}else{
		$str="parent.location=parent.location;";
	}
	include template('aljbd:showmsg');
	exit;
}
function showerror($msg){
	include template('aljbd:showerror');
	exit;
}
function img2thumb($src_img, $dst_img, $width = 75, $height = 75, $cut = 0, $proportion = 0)
{
    if(!is_file($src_img))
    {
        return false;
    }
    $ot = fileext($dst_img);
    $otfunc = 'image' . ($ot == 'jpg' ? 'jpeg' : $ot);
    $srcinfo = getimagesize($src_img);
    $src_w = $srcinfo[0];
    $src_h = $srcinfo[1];
    $type  = strtolower(substr(image_type_to_extension($srcinfo[2]), 1));
    $createfun = 'imagecreatefrom' . ($type == 'jpg' ? 'jpeg' : $type);

    $dst_h = $height;
    $dst_w = $width;
    $x = $y = 0;

    if(($width> $src_w && $height> $src_h) || ($height> $src_h && $width == 0) || ($width> $src_w && $height == 0))
    {
        $proportion = 1;
    }
    if($width> $src_w)
    {
        $dst_w = $width = $src_w;
    }
    if($height> $src_h)
    {
        $dst_h = $height = $src_h;
    }

    if(!$width && !$height && !$proportion)
    {
        return false;
    }
    if(!$proportion)
    {
        if($cut == 0)
        {
            if($dst_w && $dst_h)
            {
                if($dst_w/$src_w> $dst_h/$src_h)
                {
                    $dst_w = $src_w * ($dst_h / $src_h);
                    $x = 0 - ($dst_w - $width) / 2;
                }
                else
                {
                    $dst_h = $src_h * ($dst_w / $src_w);
                    $y = 0 - ($dst_h - $height) / 2;
                }
            }
            else if($dst_w xor $dst_h)
            {
                if($dst_w && !$dst_h)  
                {
                    $propor = $dst_w / $src_w;
                    $height = $dst_h  = $src_h * $propor;
                }
                else if(!$dst_w && $dst_h)  
                {
                    $propor = $dst_h / $src_h;
                    $width  = $dst_w = $src_w * $propor;
                }
            }
        }
        else
        {
            if(!$dst_h)  
            {
                $height = $dst_h = $dst_w;
            }
            if(!$dst_w)  
            {
                $width = $dst_w = $dst_h;
            }
            $propor = min(max($dst_w / $src_w, $dst_h / $src_h), 1);
            $dst_w = (int)round($src_w * $propor);
            $dst_h = (int)round($src_h * $propor);
            $x = ($width - $dst_w) / 2;
            $y = ($height - $dst_h) / 2;
        }
    }
    else
    {
        $proportion = min($proportion, 1);
        $height = $dst_h = $src_h * $proportion;
        $width  = $dst_w = $src_w * $proportion;
    }

    $src = $createfun($src_img);
    $dst = imagecreatetruecolor($width ? $width : $dst_w, $height ? $height : $dst_h);
    $white = imagecolorallocate($dst, 255, 255, 255);
    imagefill($dst, 0, 0, $white);

    if(function_exists('imagecopyresampled'))
    {
        imagecopyresampled($dst, $src, $x, $y, 0, 0, $dst_w, $dst_h, $src_w, $src_h);
    }
    else
    {
        imagecopyresized($dst, $src, $x, $y, 0, 0, $dst_w, $dst_h, $src_w, $src_h);
    }
    $otfunc($dst, $dst_img);
    imagedestroy($dst);
    imagedestroy($src);
    return true;
}

function newsendmail_cron($toemail, $subject, $message) {
    global $_G;
	$toemail = addslashes($toemail);

	$value = C::t('common_mailcron')->fetch_all_by_email($toemail, 0, 1);
	$value = $value[0];
	if($value) {
		$cid = $value['cid'];
	} else {
		$cid = C::t('common_mailcron')->insert(array('email' => $toemail), true);
	}
	//$message = preg_replace("/href\=\"(?!(http|https)\:\/\/)(.+?)\"/i", 'href="'.$_G['siteurl'].'\\1"', $message);
	$setarr = array(
		'cid' => $cid,
		'subject' => $subject,
		'message' => $message,
		'dateline' => $_G['timestamp']
	);
	C::t('common_mailqueue')->insert($setarr);

	return true;
}
function create_token($biaoshi) {
	$timestamp = TIMESTAMP;
	dsetcookie($biaoshi,$timestamp);
	return md5( $timestamp );
}
function valid_token($aljbd_token,$getcook,$biaoshi) {
	if(isset($getcook) && isset($aljbd_token) && $aljbd_token == md5($getcook))
	{
		dsetcookie($biaoshi,'');
		return true;
	}
	return false;
}
function getaljurl($geturl,$param){
	if($param){
		foreach($param as $k => $v){
		$geturl[$k] = $v;
		}
	}
	require_once libfile('function/home');
	return 'plugin.php?'.url_implode($geturl);
}
function encode_json($str) {
	return urldecode(json_encode(url_encode($str)));	
}


function url_encode($str) {
	if(is_array($str)) {
		foreach($str as $key=>$value) {
			$str[urlencode($key)] = url_encode($value);
		}
	} else {
		$str = urlencode($str);
	}
	
	return $str;
}
//From: Dism��taobao��com
?>