<?php
	$blockclass = array(
		'name' => '亮剑品牌类', //为此目录定义一个名字
	);
?>