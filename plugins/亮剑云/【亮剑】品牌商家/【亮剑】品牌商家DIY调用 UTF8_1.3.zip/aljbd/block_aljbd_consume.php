<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class block_aljbd_consume  {

	/**
	 * 必须！
	 * 返回本数据调用类的显示名称（显示在创建模块时选择“模块数据”的下拉列表里）
	 * @return <type>
	 */
	function name() {
		return '品牌优惠券';
	}

	/**
	 * 必须！
	 * 返回一个数组： 第一个值为本数据类所在的模块分类；第二个值为模块分类显示的名称（显示在 DIY 模块面板）
	 * @return <type>
	 */
	function blockclass() {
		return array('consume', '品牌优惠券');
	}

	/**
	 * 必须！
	 * 返回数据类中可供“模块样式”使用的字段。
	 * 格式见示例：
	 * name 为该字段的显示名称
	 * formtype 决定编辑单条数据时该字段的显示方式： 类型有： text, textarea, date, title, summary, pic； 详见 portalcp_block.htm 模板（搜 $field[formtype] ）
	 * datatype 决定该字段的数据展示，类型有： string, int, date, title, summary, pic； 详见 function_block.php 中 block_template 函数
	 * @return <type>
	 */
	function fields() {
		return array(
			'title' => array('name' => '标题', 'formtype' => 'title', 'datatype' => 'title'),
			'id' => array('name' => 'ID', 'formtype' => 'text', 'datatype' => 'int'),
			'pic' => array('name' => '图片', 'formtype' => 'text', 'datatype' => 'pic'),
			'url' => array('name' => 'URL', 'formtype' => 'text', 'datatype' => 'string'),
			'uid' => array('name' => '发布人', 'formtype' => 'text', 'datatype' => 'int'),
			'start' => array('name' => '开始时间', 'formtype' => 'date', 'datatype' => 'date'),
			'view' => array('name' => '浏览量', 'formtype' => 'text', 'datatype' => 'int'),
			'name' => array('name' => '所属商家', 'formtype' => 'text', 'datatype' => 'text'),
			'end' => array('name' => '有效期', 'formtype' => 'date', 'datatype' => 'date'),
		);
	}

	/**
	 * 必须！
	 * 返回使用本数据类调用数据时的设置项
	 * 格式见示例：
	 * title 为显示的名称
	 * type 为表单类型， 有： text, password, number, textarea, radio, select, mselect, mradio, mcheckbox, calendar； 详见 function_block.php 中 block_makeform() 函数
	 * @return <type>
	 */
	function getsetting() {
		global $_G;
		$config = $_G ['cache'] ['plugin'] ['aljbd'];
		$group_list_1[]=array('0','全部分类');
		$pos_11 = C::t('#aljbd#aljbd_type_consume')->fetch_all_by_upid(0);
		foreach($pos_11 as $k=>$v){
				$pos_all[]=$v;
				if($v['subid']){
					foreach(DB::fetch_all("select * from ".DB::table('aljbd_type_consume')." where id IN (".$v['subid'].")") as $kk=>$vv){
						$pos_all[]=array('id'=>$vv['id'],'subject'=>'-->'.$vv['subject']);
					}
				}
			
				
		}
		foreach($pos_all as $value) {
			$group_list_1[] = array($value['id'], $value['subject']);	
		}
		return array(
			'param4' => array(
				'title' => '分类',
				'type' => 'select',
				'value' => $group_list_1,
				'default' => '0'
			),
			'param7' => array(
				'title' => '指定用户ID <img tip="设置要调用的用户UID，多个UID请用半角逗号“,”隔开。" onmouseover="showTip(this)" style="margin: 0;" class="vm" alt="Tip" src="static/image/common/faq.gif" id="tip_0.30557941180678716" initialized="true">',
				'type' => 'text',
			),
			'param6' => array(
				'title' => '必须含图片 <img tip="设置是否只显示含有图片的商家" onmouseover="showTip(this)" style="margin: 0;" class="vm" alt="Tip" src="static/image/common/faq.gif">',
				'type' => 'radio',
				'value' => array(
					array('1', '是'),
					array('0', '否'),
				),
				'default' => '0'
			),
			'param1' => array(
				'title' => '显示条件',
				'type' => 'mradio',
				'value' => array(
					array('0', '最新优惠券'),
					array('1', '推荐优惠券'),
				),
				'default' => '0'
			),
			'param2' => array(
				'title' => '优惠券排序',
				'type' => 'mradio',
				'value' => array(
					array('0', '优惠券ID'),
					array('1', '浏览量'),
					array('2', '创建时间'),
				),
				'default' => '0'
			),
			'param3' => array(
				'title' => '排序',
				'type' => 'mradio',
				'value' => array(
					array('0', '降序'),
					array('1', '升序'),
				),
				'default' => '0'
			),
			'param5' => array(
				'title' => '标题最大字节数 <img tip="设置当标题名长度超过本设定时，是否将标题名自动缩减到本设定中的字节数，0 为不自动缩减"  onmouseover="showTip(this)" style="margin: 0;" class="vm" alt="Tip" src="static/image/common/faq.gif" id="tip_0.2672196314724442" initialized="true">',
				'type' => 'text',
				'value' => '',
				'default' => '40'
			),
		);
	}

	/**
	 * 必须！
	 * 处理设置参数，返回数据
	 * 返回数据有两种：
	 * 一种是返回 html，放到模块 summary 字段，直接显示； 返回格式为： array('html'=>'返回内容', 'data'=>null)
	 * 一种是返回 data，通过模块样式渲染后展示，返回的数据应该包含 fields() 函数中指定的所有字段； 返回格式为： array('html'=>'', 'data'=>array(array('title'=>'value1'), array('title'=>'value2')))
	 * 特别的：
	 * parameter 参数包含 getsetting() 提交后的内容； 并附加了字段：
	 * items ，为用户指定显示的模块数据条数；
	 * bannedids ，为用户选择屏蔽某数据时记录在模块中的该数据 id。 应该在获取数据时屏蔽该数据；
	 *
	 * 如果返回的数据给 data， 那么应该包含 fields() 函数指定的所有字段。并附加以下字段：
	 * id 标志该数据的 id，如果用户屏蔽某数据时，会将该数据的 id 添加到 parameter[bannedids] 里
	 * idtype 标志该数据的 idtype
	 *
	 * @param <type> $style 模块样式（见 common_block_style 表）。 可以根据模块样式中用到的字段来选择性的获取/不获取某些数据
	 * @param <type> $parameter 用户对 getsetting() 给出的表单提交后的内容。
	 * @return <type>
	 */
	function getdata($style, $parameter) {
		global $_G;
		$config = $_G ['cache'] ['plugin'] ['aljbd'];
		$aljbd=C::t('#aljbd#aljbd')->range();
		// 返回summary
		//return array('html' => '<p>这是一个演示模块数据类</p>', 'data' => null);

		// 返回数据
		// 需要注意： 除 id，idtype， title， url， pic， picflag， summary 几个字段外，其它字段需要放到 fields 数组里。 可以参考系统内置模块类 source/class/block/block_thread.php
		$parameter=daddslashes($parameter);
		$con=" where 1 ";
		$bannedids = !empty($parameter['bannedids']) ? explode(',', $parameter['bannedids']) : array();
		if($bannedids){
			$con .= ' AND id NOT IN ('.dimplode($bannedids).')';
		}
		if($parameter[param7]){
			$uids=explode(',', $parameter[param7]);
			$con.=" and uid IN (".dimplode($uids).")";
		}
		if($parameter[param4]){
			$con.=" and (type = ".$parameter[param4]." or subtype =".$parameter[param4].")";
		}
		if($parameter[param6]){
			$con.=" and pic !='' ";
		}
		if($parameter[param1]){
			
			$con.=" and sign =1";
		}
		if($parameter[param2]=='1'){
			$con.=" order by view";
		}else if($parameter[param2]=='2'){
			$con.=" order by dateline";
		}else{
			$con.=" order by id";
		}
		if($parameter[param3]=='1'){
			$sc=" desc";
		}else{
			$sc=" asc";
		}
		$arr=DB::fetch_all("select * from %t $con $sc limit 0,%d",array('aljbd_consume',$parameter[items]));;
		
		foreach($arr as $value) {
			if($config['isrewrite']){
				$url="brand_consume_".$value['bid']."_".$value['id'].".html";
			}else{
				$url="plugin.php?id=aljbd&act=consumeview&bid=".$value['bid']."&cid=".$value['id'];
			}
			$datalist[] = array(
				'id' => $value['id'],
				'idtype' => 'cid',				
				'title' => $parameter[param5]?cutstr($value['subject'],$parameter[param5],''):$value['subject'], 
				'url' => $url,
				'pic' => $value['pic'],
				'picflag' => 0,
				'summary' => '',
				'fields' => array(
					'id' => $value['id'],
					'pic' => $value['pic'],
					'fulltitle' => $parameter[param5]?cutstr($value['subject'],$parameter[param5],''):$value['subject'],
					'view' => $value['view'],
					'start' => $value['start'],
					'end' => $value['end']?$value['end']:'长期',
					'uid' => $value['uid'],
					'name' => $aljbd[$value['bid']]['name'],
					'url' => $url,
				)
			);
		}
		return array('html'=>'', 'data' =>$datalist);
	}

}

?>