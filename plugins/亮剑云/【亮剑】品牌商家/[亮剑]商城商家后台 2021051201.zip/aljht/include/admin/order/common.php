<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($settings['deliverytime']['value']){
    $deliverytime = $settings['deliverytime']['value']*24*60*60;
}else{
    $deliverytime = 10*24*60*60;
}
$status = intval($_GET['status']);
if($_G['cache']['plugin']['aljbdx']){
    $regionlist=C::t('#aljbdx#aljgwc_region')->range();
}else{
    $regionlist=C::t('#aljgwc#aljgwc_region')->range();
}


//1΢��2֧����5����6����
$paymentarr = array('1' => lang("plugin/aljht","common_php_1"),'2' => lang("plugin/aljht","common_php_2"),'3' => 'APP'.lang("plugin/aljht","common_php_3"),'5'=>lang("plugin/aljht","common_php_4").'('.$_G['setting']['extcredits'][$config['ext_aljbd']]['title'].')','6'=>lang("plugin/aljht","common_php_5"),'7'=>lang("plugin/aljht","common_php_6"));
//debug($regionlist);
//DB::query("update %t set status=7 WHERE status=1 and submitdate+900 < %i ",array('aljbd_goods_order',TIMESTAMP));//�������ڶ���
$queryorder = DB::fetch_all('select * from %t where status=1 and submitdate+%d < %i and pid=0',array('aljbd_goods_order',$overtime,TIMESTAMP));
foreach ($queryorder as $qok => $qov){
    //�������ڶ���
    if(DB::query("update %t set status=7 WHERE status=1 and orderid=%s ",array('aljbd_goods_order',$qov['orderid']))){
        if($_G['cache']['plugin']['aljbdx']){
            DB::query("update %t set status=7 WHERE status=1 and orderid=%s ",array('aljbd_goods_order_list',$qov['orderid']));
        }
        if($qov['pay_integral']>0 && $qov['pay_ext']>0){
            $exttype = $order_cart['ext'] > 0 ? $order_cart['ext'] : $_G['cache']['plugin']['aljbdx']['exttype'];
            updatemembercount(
                $qov['uid'],
                array($exttype => $qov['pay_ext']),
                '',
                '',
                '',
                '',
                lang("plugin/aljht","common_php_7"),
                lang("plugin/aljht","common_php_8") . $qov['pay_ext'] . $_G['setting']['extcredits'][$exttype]['title'] . lang("plugin/aljht","common_php_9") . $qov['orderid']);
        }
        gaddnum($qov);
	}
}
if($_G['cache']['plugin']['aljspt']['is_aljspt'] && file_exists("source/plugin/aljht/function/pt_order.php")){
    if(!discuz_process::islocked('autoPtOrderRefund','30')){
        require_once DISCUZ_ROOT . './source/plugin/aljht/function/pt_order.php';
        pt_grouporderstate_auto();
        pt_orderstate_auto();
    }
}
function gaddnum($order){
	$orderlist = DB::fetch_all('select * from %t where orderid=%s',array('aljbd_goods_order_list',$order['orderid']));
	foreach($orderlist as $k => $v){
		DB::query('update %t set amount=amount+%d where id=%d', array('aljbd_goods',$v['num'],$v['goods_id']));
		$goods=C::t('#aljbd#aljbd_goods')->fetch($v['goods_id']);
		if($goods['attr_sku']){
			$attr_sku = unserialize($goods['attr_sku']);
			foreach($attr_sku as $sk => $sv){
				if($v['path'] == $sv['path']){
					$attr_sku[$sk]['stock'] = $attr_sku[$sk]['stock']+$v['num'];
				}
			}
			C::t('#aljbd#aljbd_goods')->update($v['goods_id'],array('attr_sku'=>serialize($attr_sku)));
			unset($attr_sku);
			unset($goods);
		}
    }
    if($order['cid'] > 0 && $order['discount'] > 0){
        DB::update('aljsyh_consume_log',array('status'=>1),array('id'=>intval($order['cid']),'status'=>2));
    }
}
//From: Dism_taobao-com
?>