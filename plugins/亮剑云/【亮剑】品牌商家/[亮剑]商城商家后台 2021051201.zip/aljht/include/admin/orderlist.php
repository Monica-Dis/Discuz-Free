<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$bids = DB::fetch_all('select id from %t where uid = %d',array('aljbd',$_G['uid']));
foreach($bids as $bid){
	$ids[] = $bid['id'];
}
$bids = implode(',',$ids);
require_once DISCUZ_ROOT . './source/plugin/aljht/include/admin/order/common.php';
if($do == 'orderview'){
	$order_cart=C::t('#aljgwc#aljbd_goods_order')->fetch($_GET[orderid]);
	include template('aljht:admin/orderlist/orderview');
}elseif($do == 'pt_view'){
    $orderlist = DB::fetch_all('select * from %t where collage_order=%s ',array('aljbd_goods_order',$_GET[collage_order]));
    include template('aljht:admin/orderlist/orderptview');
}elseif($do == 'uidorder'){
    $page = intval($_GET['page']);
	$currpage = $page?$page:1;
	$perpage = 10;
	$start = ($currpage-1)*$perpage;
    $num = DB::result_first('select count(*) from %t where uid=%d and pid = 0 and (store_id = 0 or (store_id > 0 and order_type=7))',array('aljbd_goods_order',$_GET[uid]));
    $orderlist = DB::fetch_all('select * from %t where uid=%d and pid = 0 and (store_id = 0 or (store_id > 0 and order_type=7)) order by submitdate desc limit %d,%d',array('aljbd_goods_order',$_GET[uid],$start,$perpage));
    $geturl['uid'] = $_GET['uid'];
    
    $pagingurl = getaljurl($geturl,'');

    $paging = _mall_paging($currpage,$num,$perpage,$pagingurl.$urlmod.'&page=');
    include template('aljht:admin/orderlist/orderuidorder');
}elseif($do == 'editaddress'){
    $order_cart=C::t('#aljgwc#aljbd_goods_order')->fetch($_GET[orderid]);
    $address = unserialize($order_cart['address']);
    if(!$_G['mobile'] && $order_cart['wm_platform_distribution'] == 1){
        $_GET = T::ajaxGetCharSet($_GET);
    }
    if(submitcheck('formhash')) {
        if(((in_array($order_cart[shop_id],$ids) && $ord=='dianpu') || in_array($_G['groupid'],$admingroups)) && ($order_cart[status]==2 || $order_cart[status]==3)){
        }else{
            echo '<script>parent.tips("'.lang("plugin/aljht","orderlist_php_1").'");</script>';
            exit;
        }
        
        if($_G['mobile']){
            $citypicker = array_filter(explode(' ', trim($_GET['citypicker'])));
        }else{
            $citypicker = array_filter(explode('/', trim($_GET['citypicker'])));
        }
        $address['province'] = $citypicker[0];
        $address['city'] = $citypicker[1];
        $address['district'] = $citypicker[2];
        $address['addressDetail'] = $_GET['addressDetail'];
        $address['fullName'] = $_GET['fullName'];
        $address['mobile'] = $_GET['mobile_p'];
        if($_G['cache']['plugin']['aljpps']['is_aljbd'] && $order_cart['wm_platform_distribution'] == 1){
            $address['address'] = $_GET['citypicker'];
            $address['province'] = $_GET['province'];
            $address['city'] = $_GET['city'];
            $address['district'] = $_GET['district'];
            $address['lat'] = $_GET['lat'];
            $address['lng'] = $_GET['lng'];
            $address['type'] = 1;
        }
        
        $address = serialize($address);
        
        DB::update('aljbd_goods_order',array('address'=>$address), array('orderid'=>$_GET[orderid]));
        echo '<script>parent.tips("0");</script>';
        exit;
    }else{
        if($order_cart['wm_platform_distribution'] == 1){
            define('IN_MOBILE', 2);
            $_G['mobile'] = 2;
            $order_edit_url = 'plugin.php?id=aljht&act=admin&op=orderlist&do=editaddress'.$urlmod.'&ord='.$ord.'&orderid='.$_GET[orderid];
            include template('aljbdx:address/editaddress');
        }else{
            include template('aljht:admin/orderlist/editaddress');
        }
    }
}elseif($do == 'delorder'){
	if($_GET['orderid'] && $_GET['formhash'] == FORMHASH){
        $order = C::t('#aljgwc#aljbd_goods_order') -> fetch($_GET['orderid']);
        if($order['store_id']>0){
            $bd = C::t('#aljtsq#aljtsq_store')->fetch($order['store_id']);
            $bd['uid'] = $bd['tc_uid'];
            $bd['tel'] = $bd['tc_tel'];
            $staff = baseStaff($order['store_id'],2);
        }else{
            $bd = DB::fetch_first('select * from %t where id = %d',array('aljbd',$order[shop_id]));
            $staff = baseStaff($order['shop_id'],1);
        }
		
		if($order['uid'] == $_G['uid'] || $bd['uid'] == $_G['uid'] || $administrators || in_array('staff_ddgl',$staff['st_staff_authority'])){
            C::t('#aljgwc#aljbd_goods_order') -> delete($_GET['orderid']);
            if($_G['cache']['plugin']['aljbdx']){
                C::t('#aljgwc#aljbd_goods_order_list') -> delete($_GET['orderid']);
            }
			//gaddnum($order);
			echo '1';
			exit;
		}
	}
}elseif($do == 'buorder'){
	if($_GET['orderid'] && $_GET['formhash'] == FORMHASH){
        $order = C::t('#aljgwc#aljbd_goods_order') -> fetch($_GET['orderid']);
		$pay_order = DB::fetch_first('select * from %t where orderid=%s',array('aljqb_payorder',$_GET['orderid']));
		if($administrators && $order && $pay_order){
            if(DB::query("update %t set status=2,buyer=%s,confirmdate=%d,admin=%s where orderid = %s",array('aljbd_goods_order',$pay_order['transaction_id'].'_budan',TIMESTAMP,$pay_order['trade_mod']?$pay_order['trade_mod']:'budan',$_GET['orderid']))
            && DB::query("update %t set status=2 where orderid = %s",array('aljbd_goods_order_list',$_GET['orderid']))){
            
                DB::update('aljqb_payorder',array('status'=>1, 'overtime' => TIMESTAMP,'trade_mod'=>$pay_order['trade_mod']?$pay_order['trade_mod']:'budan'), array('orderid' => $_GET['orderid'],'status'=>0));
                echo '1';
                exit;
            }
			echo '0';
			exit;
		}
	}
}elseif($do == 'canorder'){
    if($_GET['orderid'] && $_GET['formhash'] == FORMHASH){
        $order = C::t('#aljgwc#aljbd_goods_order') -> fetch($_GET['orderid']);
        if($order['store_id']>0){
            $bd = C::t('#aljtsq#aljtsq_store')->fetch($order['store_id']);
            $bd['uid'] = $bd['tc_uid'];
            $bd['tel'] = $bd['tc_tel'];
            $staff = baseStaff($order['store_id'],2);
        }else{
            $bd = DB::fetch_first('select * from %t where id = %d',array('aljbd',$order[shop_id]));
            $staff = baseStaff($order['shop_id'],1);
        }

        if(($order['uid'] == $_G['uid'] || $bd['uid'] == $_G['uid'] || $administrators || in_array('staff_ddgl',$staff['st_staff_authority'])) && ($order['status'] == 1 || ($order['status']<3 && $order['payment']==6))){
            if(DB::query("update %t set status=7 where orderid = %s",array('aljbd_goods_order',$_GET['orderid']))){
                if($_G['cache']['plugin']['aljbdx']){
                    DB::query("update %t set status=7 WHERE orderid=%s ",array('aljbd_goods_order_list',$_GET['orderid']));
                }
                if($order['pay_integral']>0 && $order['pay_ext']>0){
                    updatemembercount(
                        $order['uid'],
                        array($_G['cache']['plugin']['aljbdx']['exttype'] => $order['pay_ext']),
                        '',
                        '',
                        '',
                        '',
                        '&#21462;&#28040;&#35746;&#21333;&#36864;&#36824;&#31215;&#20998;',
                        '&#21462;&#28040;&#35746;&#21333;&#36864;&#36824;&#25269;&#29616;&#31215;&#20998;' . $order['pay_ext'] . $_G['setting']['extcredits'][$_G['cache']['plugin']['aljbdx']['exttype']]['title'] . '&#44;&#35746;&#21333;&#21495;&#65306;' . $order['orderid']);
                }
                gaddnum($order);
			}

            echo '1';
            exit;
        }
    }
}elseif($do == 'receipt'){
    $order = C::t('#aljgwc#aljbd_goods_order') -> fetch($_GET['orderid']);
    
	if($order['uid'] == $_G['uid'] || $administrators || $order['qs_uid'] == $_G['uid'] || ($order['deliverydate'] && $order['deliverydate']+$deliverytime < TIMESTAMP)){
        if(file_exists("source/plugin/aljhtx/class/class_aljbdx.php")){
            require_once 'source/plugin/aljhtx/class/class_aljbdx.php';
            aljbdx::receipt($order);//�ջ�
            
            echo '1';
            exit;
        }else{
            if(file_exists("source/plugin/aljbdx/include/receipt.php") && $_G['cache']['plugin']['aljbdx']['is_aljqb'] && $order['payment'] == 7){
                require_once 'source/plugin/aljbdx/include/receipt.php';
            }else {
                if(DB::query("update %t set status=4 where orderid = %s", array('aljbd_goods_order', $_GET['orderid']))){
                    if($order['give_integral']>0){
                        if($_G['cache']['plugin']['aljtcc']){
                            $card_user = DB::fetch_first('select * from %t where uid=%d and end_time>%d',array('aljtcc_card_user',$order['uid'],TIMESTAMP));
                            $card_info = DB::fetch_first('select * from %t where id=%d ',array('aljtcc_card',1));
                            if($card_info['integral_multiple'] > 0){
                                $order['give_integral'] = $order['give_integral']*$card_info['integral_multiple'];
                            }
                        }
                        updatemembercount(
                            $order['uid'],
                            array($_G['cache']['plugin']['aljbdx']['exttype'] => intval($order['give_integral'])),
                            '',
                            '',
                            '',
                            '',
                            lang("plugin/aljbdx","receipt_php_1"),
                            lang("plugin/aljbdx","receipt_php_2") . $order['give_integral'] . $_G['setting']['extcredits'][$_G['cache']['plugin']['aljbdx']['exttype']]['title'] . lang("plugin/aljbdx","receipt_php_3") . $orderid);
                    }
                    $brand = C::t('#aljbd#aljbd') -> fetch($order['shop_id']);
                    
                    //s ������Ա������Ϣ
                    if($_G['cache']['plugin']['aljbdx']['receipt_tips']){
                        $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
                        $mes = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],$orderlurln,$brand['name']),$_G['cache']['plugin']['aljbdx']['receipt_tips']);
                        foreach($groupids as $g_uid){
                            notification_add($g_uid['uid'], 'system',$mes);
                        }
                    }
                    //s ���̼ҷ�����Ϣ
                    if($_G['cache']['plugin']['aljbdx']['receipt_tips_brand']){

                        $mes_brand = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],$orderlurln,$brand['name']),$_G['cache']['plugin']['aljbdx']['receipt_tips_brand']);
                        notification_add($brand['uid'], 'system',$mes_brand);
                    }
                }
                if(file_exists("source/plugin/dz_1/dz_1.inc.php")){
                    require_once 'source/plugin/dz_1/include/receipt.php';
                }
                echo '1';
                exit;
            }
        }
	}else{
        echo 0;
        exit;
    }
}elseif($do == 'qhm_code'){
    $order = C::t('#aljgwc#aljbd_goods_order') -> fetch($_GET['orderid']);
    $goods_id = DB::result_first('select goods_id from %t where orderid=%s',array('aljbd_goods_order_list',$_GET['orderid']));
    if($_GET['formhash'] == FORMHASH && $order && $goods_id){
        include_once DISCUZ_ROOT .'source/plugin/aljbdx/function/new_function.php';
        if ($order['get_to_the_shop'] == 1) {
            $type = 1;
            $replacetext = $_G['cache']['plugin']['aljstg']['pick_up_code_tips'];
        } else {
            $type = 0;
            $replacetext = $_G['cache']['plugin']['aljstg']['code_tips'];
        }
        $res = randcode ($type,$replacetext,$order,$goods_id);
		if($res){
            //C::t('#aljgwc#aljbd_goods_order')->update_status_by_orderid($_GET['orderid']);
            C::t('#aljgwc#aljbd_goods_order')->update($_GET['orderid'], array('status' => 3));
            if($_G['cache']['plugin']['aljbdx']){
                DB::query("update %t set status=3 WHERE orderid=%s ",array('aljbd_goods_order_list',$_GET['orderid']));
            }
            echo '1';
            exit;
		}else{
            echo '0';
            exit;
		}
    }else{
        echo '0';
        exit;
	}
}elseif($do == 'change_price'){
	if($_GET['orderid'] && $_GET['formhash'] == FORMHASH){
		$order = $order_cart = C::t('#aljgwc#aljbd_goods_order')->fetch($_GET[orderid]);
		if(empty($order_cart) || empty($_GET['price'])){
			echo 0;
			exit;
		}
		if($order['order_type'] == 3 && $order['store_id']>0){
            $bd = C::t('#aljtsq#aljtsq_store')->fetch($order_cart['store_id']);
            $bd['uid'] = $bd['tc_uid'];
            $bd['tel'] = $bd['tc_tel'];
            $staff = baseStaff($order['store_id'],2);
        }else{
            $bd = DB::fetch_first('select * from %t where id = %d',array('aljbd',$order[shop_id]));
            $staff = baseStaff($order['shop_id'],1);
        }

		if(($bd['uid'] != $_G['uid'] && !$administrators && !in_array('staff_ddgl',$staff['st_staff_authority'])) || $order_cart[buyer]){
			echo 0;
			exit;
		}
		$original_price = floatval($order_cart['original_price']);

		if(empty($original_price)){
			C::t('#aljgwc#aljbd_goods_order')->update($_GET[orderid],array('original_price'=>$order_cart['price']));
		}
		C::t('#aljgwc#aljbd_goods_order')->update($_GET[orderid],array('price'=>$_GET['price']));
		
		echo 1;
		exit;
	}
}elseif($do == 'edit_remarks'){
    if(!$_G['mobile']){
        $_GET = T::ajaxGetCharSet($_GET);
    }
	if($_GET['orderid'] && $_GET['formhash'] == FORMHASH){
		$order = $order_cart = C::t('#aljgwc#aljbd_goods_order')->fetch($_GET[orderid]);
		if(empty($order_cart)){
			echo 0;
			exit;
		}
		if($order['order_type'] == 3 && $order['store_id']>0){
            $bd = C::t('#aljtsq#aljtsq_store')->fetch($order_cart['store_id']);
            $bd['uid'] = $bd['tc_uid'];
            $bd['tel'] = $bd['tc_tel'];
            $staff = baseStaff($order['store_id'],2);
        }else{
            $bd = DB::fetch_first('select * from %t where id = %d',array('aljbd',$order[shop_id]));
            $staff = baseStaff($order['shop_id'],1);
        }

		if($bd['uid'] != $_G['uid'] && !$administrators && !in_array('staff_ddgl',$staff['st_staff_authority'])){
			echo 0;
			exit;
		}
		
		C::t('#aljgwc#aljbd_goods_order')->update($_GET[orderid],array('remarks'=>$_GET['remarks']));
		
		echo 1;
		exit;
	}
}elseif($do == 'comment'){
	$gid = intval($_GET['gid']);
	if($_GET['formhash'] == FORMHASH) {
        if(empty($gid)){
            echo 0;
            exit;
        }
        $good = C::t('#aljbd#aljbd_goods')->fetch($_GET['gid']);
		if($_G['mobile']){
            $content = $_GET['content'];
		}else{
            $content = diconv($_GET['content'], 'UTF-8', CHARSET);
		}
        //debug($content);
        $orderid = $_GET['orderid'];
        //��
        $overall_ticket = intval($_GET['overall_ticket']);
        //*1
        $descriptiongrade = intval($_GET['descriptiongrade']);
        $environmentgrade = intval($_GET['environmentgrade']);
        $attitudegrade = intval($_GET['attitudegrade']);
        //*2
        $deliveryspeed = intval($_GET['deliveryspeed']);

        if(empty($orderid) || empty($content) || empty($overall_ticket) || empty($descriptiongrade) ||  empty($deliveryspeed)){
            echo 0;
            exit;
        }
        $check = DB::result_first('select count(*) from %t where orderid=%s and uid=%d',array('aljbd_goods_order',$orderid,$_G['uid']));

        if(empty($check) && $_G['groupid'] !=1 ){
            echo 0;
            exit;
        }
        $check = DB::result_first('select count(*) from %t where gid=%d and orderid=%s',array('aljbd_comment_goods',$gid,$orderid));
        if($check){
            echo 0;
            exit;
        }
        $insertarray = array(
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'gid' => $gid,
            'bid' => $good['bid'],
            'orderid' => $orderid,
            'content' => $content,
            'overall_ticket' => $overall_ticket,
            'descriptiongrade' => $descriptiongrade,
            'environmentgrade' => $environmentgrade,
            'attitudegrade' => $attitudegrade,
            'deliveryspeed' => $deliveryspeed,
            'displayorder' => 1,
            'video_path' => $_GET['video_path'],
            'dateline' => TIMESTAMP,
        );
        list($yg_orderid, $oid) = explode('_', $orderid);
        if($oid>0){
            $aljyg_cj_order_info = DB::fetch_first('select * from %t where id=%d',array('aljyg_order',$oid));
            $insertarray['yid'] = $aljyg_cj_order_info['yid'];
            $insertarray['pid'] = $aljyg_cj_order_info['pid'];
        }
        if($_GET['pic'] && $u20181224) {
            $src = array();
            foreach($_GET['pic'] as $tmp_key=> $tmp_value) {
                if(strpos($tmp_value,$_G['cache']['plugin']['aljoss']['domain']) !== false){
                    $src[] = $tmp_value;
                }else if (is_file($tmp_value)) {
                    $src[] = $tmp_value;
                } else {

                    $src[] = T::saveimg($tmp_value,$image_path.'logo/');
                }
            }
            $srcs = implode('|', $src);
            $insertarray['imgs'] = $srcs;
        }

        C::t('#aljbdx#aljbd_comment_goods')->insert($insertarray);
        DB::query('update %t set status = 5 where orderid = %s',array('aljbd_goods_order',$orderid));
        
        DB::query("update %t set status=5 WHERE orderid=%s ",array('aljbd_goods_order_list',$orderid));
        
        if($_G['cache']['plugin']['aljbd']['goods_reply_type'] && $_G['cache']['plugin']['aljbd']['goods_reply_num']){
            updatemembercount(
                $_G['uid'],
                array($_G['cache']['plugin']['aljbd']['goods_reply_type'] => intval($_G['cache']['plugin']['aljbd']['goods_reply_num'])),
                '',
                '',
                '',
                '',
                lang("plugin/aljht","orderlist_php_6"),
                lang("plugin/aljht","orderlist_php_7").$good['name'].lang("plugin/aljht","orderlist_php_8") . intval($_G['cache']['plugin']['aljbd']['goods_reply_num']) . $_G['setting']['extcredits'][$_G['cache']['plugin']['aljbd']['goods_reply_type']]['title'] . lang("plugin/aljht","orderlist_php_9") . $orderid);
            notification_add($_G['uid'], 'system',lang("plugin/aljht","orderlist_php_10").$good['name'].lang("plugin/aljht","orderlist_php_11") . intval($_G['cache']['plugin']['aljbd']['goods_reply_num']) . $_G['setting']['extcredits'][$_G['cache']['plugin']['aljbd']['goods_reply_type']]['title'] . lang("plugin/aljht","orderlist_php_12") . '<a href="plugin.php?id=aljbd&act=orderlist&status=5&mod=my&ord=ge">'.$orderid.'</a>');
        }
        echo 1;
        exit;
	}else{
		if(empty($gid)){
			alert($aljgwclang['php']['Commodity_does_not_exist']);
			exit;
		}
		$good = C::t('#aljbd#aljbd_goods') -> fetch($gid);
		$navtitle = $aljgwclang['php']['Comment_commodity'];
		include template('aljht:admin/orderlist/comment');
	}
}elseif($do == 'fahuo' || $do == 'editfahuo'){
	$orderid = addslashes($_GET['orderid']);
    $order=C::t('#aljgwc#aljbd_goods_order')->fetch($orderid);
    if($order['store_id']>0){
        $bd = C::t('#aljtsq#aljtsq_store')->fetch($order['store_id']);
        $bd['uid'] = $bd['tc_uid'];
        $bd['tel'] = $bd['tc_tel'];
        $staff = baseStaff($order['store_id'],2);
    }else{
        $bd = DB::fetch_first('select * from %t where id = %d',array('aljbd',$order[shop_id]));
        $staff = baseStaff($order['shop_id'],1);
    }
    
	if(submitcheck('formhash')) {
        if(($bd['uid'] != $_G['uid'] && !$administrators && !in_array('staff_ddgl',$staff['st_staff_authority']))){
            echo '<script>parent.tips("'.lang("plugin/aljht","orderlist_php_2").'");</script>';
            exit;
        }
		if($do == 'editfahuo'){
            if($_GET['category'] == 1 || $_GET['wl_type'] > 2){
                if(!$_GET['e']){
                    echo '<script>parent.tips("'.lang("plugin/aljht","orderlist_php_3").'");</script>';
                    exit;
                }
                C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_wuliu')->update($_GET['orderid'],array(
                    'type' => $_GET['wl_type']>2 ? $_GET['wl_type'] : 2,
                    'e' => $_GET['e'],
                ));
            }else{
                if(!$_GET['worderid']){
                    echo '<script>parent.tips("&#29289;&#27969;&#21333;&#21495;&#24517;&#39035;&#22635;&#20889;");</script>';
                    exit;
                }
                if(!$_GET['companyname']){
                    echo '<script>parent.tips("&#29289;&#27969;&#21517;&#31216;&#24517;&#39035;&#22635;&#20889;");</script>';
                    exit;
                }
                C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_wuliu')->update($_GET['orderid'],array(
                    'type' => 1,
                    'companyname' => $_GET['companyname'],
                    'worderid' => $_GET['worderid'],
                ));
            }
		}else{
            if(DB::result_first('select count(*) from %t where orderid=%s',array($pluginid_aljbd.'_wuliu',$orderid))){
                echo '<script>parent.tips("'.lang("plugin/aljht","orderlist_php_4").'");</script>';
                exit;
            }
            if($_GET['category'] == 1 || $_GET['wl_type'] > 2){
                if(!$_GET['e']){
                    echo '<script>parent.tips("'.lang("plugin/aljht","orderlist_php_5").'");</script>';
                    exit;
                }
                C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_wuliu')->insert(array(
                    'orderid' => $_GET['orderid'],
                    'type' => $_GET['wl_type']>2 ? $_GET['wl_type'] : 2,
                    'e' => $_GET['e'],
                    'dateline' => TIMESTAMP,
                ));
            }else{
                if(!$_GET['worderid']){
                    echo '<script>parent.tips("&#29289;&#27969;&#21333;&#21495;&#24517;&#39035;&#22635;&#20889;");</script>';
                    exit;
                }
                if(!$_GET['companyname']){
                    echo '<script>parent.tips("&#29289;&#27969;&#21517;&#31216;&#24517;&#39035;&#22635;&#20889;");</script>';
                    exit;
                }
                C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_wuliu')->insert(array(
                    'orderid' => $_GET['orderid'],
                    'type' => 1,
                    'companyname' => $_GET['companyname'],
                    'worderid' => $_GET['worderid'],
                    'c' => $_GET['c'],
                    'dateline' => TIMESTAMP,
                ));
            }
            if(!$order['d'] && $order['payment'] == '2'){
                $order['transaction_id'] = $order['buyer'];
                $order['invoice_no'] = $_GET['worderid'];
                $order['logistics_name'] = diconv($_GET['companyname'],CHARSET,'gbk');
                $order['express'] = diconv($_GET['c'],CHARSET,'gbk');
                alipaysend($order);

            }else{

                C::t('#aljgwc#aljbd_goods_order')->update_status_by_orderid($_GET['orderid']);
                if($_G['cache']['plugin']['aljbdx']){
                    DB::query("update %t set status=3 WHERE orderid=%s ",array('aljbd_goods_order_list',$_GET['orderid']));
                }
                if($is_aljdx){
                    $oaddress = unserialize($order['address']);
                    $orderidau = $_G['cache']['plugin']['aljbd']['is_dx_var'] ? 'orderidau' : 'orderid_au';
                    $username_au = $_G['cache']['plugin']['aljbd']['is_dx_var'] ? 'usernameau' : 'username_au';
                    if(preg_match('#^\d[\d-]{3,20}\d$#', $oaddress['mobile'])){
                        sendsmsbyvar($oaddress['mobile'],'aljbd','fahuo',array($username_au =>$order['username'] ,$orderidau => $_G['cache']['plugin']['aljbd']['is_dx_order']?'**'.substr($order['orderid'],-4):$order['orderid']));
                    }
                }
                //$order = C::t('#aljbd#aljbd_order')->fetch($_GET['orderid']);
                $shop_order=C::t('#aljgwc#aljbd_goods_order_list')->fetch_all_by_orderid($_GET['orderid']);
                $f_goods_info = C::t('#aljbd#aljbd_goods')->fetch($shop_order[0]['goods_id']);
                if($_G['cache']['plugin']['mapp_template'] && $_G['cache']['plugin']['aljhtx'] && DB::fetch_first('select * from %t where type=%s', array('aljhtx_wechat_bindtemplate', 'deliveryNotificationUser'))){
                    $address = unserialize($order['address']);
                    if($regionlist[$address['region']][name]){
                        $addresstext = $regionlist[$address['region']][name].$regionlist[$address['region1']][name].$regionlist[$address['region2']][name].$address['addressDetail'];
                    }else{
                        $addresstext = $address['province'].$address['city'].$address['district'].$address['addressDetail'];
                    }
                    $param = array(
                        'order_subject' => lang("plugin/aljht","orderlist_php_13").$order['stitle'].lang("plugin/aljht","orderlist_php_14"),
                        'order_id' => $order['orderid'],
                        'fh_time' => dgmdate(TIMESTAMP,'Y-m-d H:i:s'),
                        'kd' => $express_company[$_GET['companyname']],
                        'kd_order' => $_GET['worderid'],
                        'sh_address' => $addresstext,
                        'order_content' => lang("plugin/aljht","orderlist_php_15"),
                        'type' => 'deliveryNotificationUser',
                        'news_type' => 1,
                        'logo' => $f_goods_info['pic1']
                    );
                    if($_GET['category'] == 1 || $_GET['wl_type'] > 2){
                        $wuliutype = array(2=>lang('plugin/aljht','orderlist_php_16'),3=>lang('plugin/aljht','orderlist_php_17'),4=>lang('plugin/aljht','orderlist_php_18'));
                        $param[kd] = $wuliutype[$_GET['wl_type']];
                        $param[kd_order] = $_GET['c'];
                    }
                    T::aljbd_notification($order['uid'],$param,'plugin.php?id=aljht&act=admin&op=orderlist&do=logistics_details&kgs=' . $_GET['companyname'] . '&number=' . $_GET['worderid'] . '&orderid=' . $_GET['orderid']);
                }else {
                    foreach ($shop_order as $key => $val) {
                        notification_add($order['uid'], 'system', str_replace('{username}', $order['username'], str_replace('{shopname}', '<a href="plugin.php?id=aljht&act=admin&op=orderlist&do=logistics_details&kgs=' . $_GET['companyname'] . '&number=' . $_GET['worderid'] . '&orderid=' . $_GET['orderid'] . '">' . $val['name'] . '</a>', $_G['cache']['plugin'][$pluginid_aljbd]['fahuotips'])));
                        if ($_G['cache']['plugin'][$pluginid_aljbd]['time']) {
                            $email_first = C::t("common_member")->fetch($order['uid']);
                            $email = $email_first['email'];

                            if ($email_first['email']) {
                                $m = str_replace('{username}', $order['username'], str_replace('{shopname}', '<a href="' . $_G['siteurl'] . '/plugin.php?id=aljht&act=admin&op=orderlist&do=logistics_details&kgs=' . $_GET['companyname'] . '&number=' . $_GET['worderid'] . '&orderid=' . $_GET['orderid'] . '">' . $val['name'] . '</a>', $_G['cache']['plugin'][$pluginid_aljbd]['fahuotips']));
                                sendmail_cron($email, $_G['cache']['plugin'][$pluginid_aljbd]['mailtitle'], $m);
                            }
                        }
                    }
                }
                if(file_exists('source/plugin/aljbdx/include/fahuo.php')){
                    require_once 'source/plugin/aljbdx/include/fahuo.php';
                }
            }
		}
		echo '<script>parent.tips(0);</script>';
		exit;
	}
}elseif($do == 'logistics_details'){
    if($_G['mobile']){
        header('location: plugin.php?id=aljbdx&act=logistics_details&kgs='.$_GET['kgs'].'&number='.$_GET['number'].'&orderid='.$_GET['orderid']);
        exit;
    }
    $orderid = addslashes($_GET['orderid']);
    $order=C::t('#aljgwc#aljbd_goods_order')->fetch($orderid);
    $wuliulist=C::t('#aljbd#aljbd_wuliu')->fetch($_GET['orderid']);
    include template('aljht:admin/orderlist/logistics_details');
}else{
    $timeoffset = getglobal('setting/timeoffset');
    $nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$timeoffset),dgmdate($_G['timestamp'], 'j',$timeoffset),dgmdate($_G['timestamp'], 'Y',$timeoffset)) - $timeoffset*3600;

    $nowWeekTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$timeoffset),dgmdate($_G['timestamp'], 'j',$timeoffset)-7,dgmdate($_G['timestamp'], 'Y',$timeoffset)) - $timeoffset*3600;
    $nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$timeoffset),1,dgmdate($_G['timestamp'], 'Y',$timeoffset)) - $timeoffset*3600;
    $bids = DB::fetch_all('select id from %t where uid = %d',array('aljbd',$_G['uid']));
	foreach($bids as $bid){
		$ids[] = $bid['id'];
	}
    $bids = implode(',',$ids);
    if(($ids && $ord=='dianpu') || $administrators){
        $conn_c[] ='aljbd_goods_order';
        if($_GET['dzAdmin'] == 1){
            $where_c = 'where 1 and pid = 0 and store_id > 0 AND order_type !=3 ';
            if(!$administrators){
                $where_c .= 'and pid = 0 and uid = %d ';
                $conn_c[] = $_G['uid'];
            }
        }else{
            $where_c = 'where 1 and pid = 0 and (store_id = 0 or (store_id > 0 and order_type=7)) ';
            if(!$administrators){
                if($_GET['ord'] == 'dianpu' && $bids){
                    $where_c .= 'and pid = 0 and shop_id in(%i) ';
                    $conn_c[] = $bids;
                }else{
                    $where_c .= 'and pid = 0 and uid = %d ';
                    $conn_c[] = $_G['uid'];
                }
            }
        }
        $sumprice_all = DB::fetch_all('select count(*) num,sum(price) price,status from %t '.$where_c.' group by status order by status asc',$conn_c);
        $sumprice = 0;
        $countnum = 0;
        foreach($sumprice_all as $s_v){
            if($s_v['status'] > 1 && $s_v['status'] < 6){
                $sumprice += $s_v['price'];
                $countnum += $s_v['num'];
            }
        }
        
        $where_c .= 'and submitdate >= %d ';

        $week_where = $where_c;
        $week_conn = $conn_c;
        $week_conn[] = $nowWeekTime;

        $month_where = $where_c;
        $month_conn = $conn_c;
        $month_conn[] = $nowMonthTime;
        $yesterday_conn = $conn_c;
        $yesterdayTime = $nowDayTime-86400;
        $yesterday_conn[] = $yesterdayTime;
        
        $conn_c[] = $nowDayTime;

        
        $yesterday_where = $where_c;
        $yesterday_where .= 'and submitdate < %d ';
        
        $yesterday_conn[] = $nowDayTime;
        $yesterdaysumprice_all = DB::fetch_all('select count(*) num,sum(price) price,status from %t '.$yesterday_where.' group by status order by status asc',$yesterday_conn);
        $yesterdaysumprice = 0;
        $yesterdaycountnum = 0;
        foreach($yesterdaysumprice_all as $s_v){
            if($s_v['status'] > 1 && $s_v['status'] < 6){
                $yesterdaysumprice += $s_v['price'];
                $yesterdaycountnum += $s_v['num'];
            }
        }
        
        $todaysumprice_all = DB::fetch_all('select count(*) num,sum(price) price,status from %t '.$where_c.' group by status order by status asc',$conn_c);
        $todaysumprice = 0;
        $todaycountnum = 0;
        foreach($todaysumprice_all as $s_v){
            if($s_v['status'] > 1 && $s_v['status'] < 6){
                $todaysumprice += $s_v['price'];
                $todaycountnum += $s_v['num'];
            }
        }
        $where_c .= 'and submitdate >= %d ';
        $conn_c[] = $nowDayTime;
        $weeksumprice_all = DB::fetch_all('select count(*) num,sum(price) price,status from %t '.$week_where.' group by status order by status asc',$week_conn);
        $weeksumprice = 0;
        $weekcountnum = 0;
        foreach($weeksumprice_all as $s_v){
            if($s_v['status'] > 1 && $s_v['status'] < 6){
                $weeksumprice += $s_v['price'];
                $weekcountnum += $s_v['num'];
            }
        }
        
        $monthsumprice_all = DB::fetch_all('select count(*) num,sum(price) price,status from %t '.$month_where.' group by status order by status asc',$month_conn);
        $monthsumprice = 0;
        $monthcountnum = 0;
        foreach($monthsumprice_all as $s_v){
            if($s_v['status'] > 1 && $s_v['status'] < 6){
                $monthsumprice += $s_v['price'];
                $monthcountnum += $s_v['num'];
            }
        }
    }
    
	$keyword = addcslashes($_GET['search'], '%_');
	$payment = intval($_GET['payment']);


	$page = intval($_GET['page']);
	$currpage = $page?$page:1;
	$perpage = 10;
	$start = ($currpage-1)*$perpage;
	
    $conn[] ='aljbd_goods_order';
    if($_GET['dzAdmin'] == 1){
        $where = 'where 1 and pid = 0 and store_id > 0 AND order_type !=3 ';
        if(!$administrators){
            $where .= 'and pid = 0 and uid = %d ';
            $conn[] = $_G['uid'];
        }
    }else{
        $where = 'where 1 and pid = 0 and (store_id = 0 or (store_id > 0 and order_type=7)) ';
        if(!$administrators){
            if($_GET['ord'] == 'dianpu' && $bids){
                $where .= 'and pid = 0 and shop_id in(%i) ';
                $conn[] = $bids;
            }else{
                $where .= 'and pid = 0 and uid = %d ';
                $conn[] = $_G['uid'];
            }
        }
    }
    
    
	if($_GET['status']){
        if($_GET['status'] == 99){
            $where .= ' and status > %d and status < %d';
            $conn[] = 1;
            $conn[] = 6;
        }else{
            $where .= ' and status = %d';
            $conn[] = $status;
        }
    }
    if($_GET['o_type']){
        if($_GET['o_type'] == 1){
            $where .= ' and commodity_type = %d and order_type != 7';
            $conn[] = 0;
        }else if($_GET['o_type'] == 2){
            $where .= ' and order_type = 7';
        }else if($_GET['o_type'] == 3){
            $where .= ' and commodity_type = %d ';
            $conn[] = 7;
        }else if($_GET['o_type'] == 4){
            $where .= ' and commodity_type = %d ';
            $conn[] = 1;
        }else if($_GET['o_type'] == 5){
            $where .= ' and commodity_type = %d ';
            $conn[] = 2;
        }
    }
	if($_GET['payment']){
        if($_G['cache']['plugin']['aljbdx']['is_aljqb']){
            if($_GET['payment'] == 'apppay'){
                $where .= ' and admin in (%n)';
		        $conn[] = array('qianfanapp','magapp');
            }else{
                $where .= ' and admin = %s';
		        $conn[] = $_GET['payment'];
            }
        }else{
            $where .= ' and payment = %d';
		    $conn[] = $payment;
        }
	}
	if($_GET['start']){
		$conn[] =strtotime($_GET['start']);
		$where.=" and submitdate >= %d";
	}
	if($_GET['end']){
		$conn[] =strtotime($_GET['end']);
		$where.=" and submitdate <= %d";
	}
	if($_GET['search']){
		if($_GET['ordertype']){
			if($_GET['ordertype'] == 1){
				$conn[] ='%'. $keyword .'%';
				$where.=" and orderid like %s";
			}elseif($_GET['ordertype'] == 2){
				$conn[] ='%'. $keyword .'%';
				$where.=" and stitle like %s";
			}else if($_GET['ordertype'] == 3){
				$conn[] =$keyword;
				$where.=" and shop_id = %d";
			}else if($_GET['ordertype'] == 4){
                $conn[] ='%' . $keyword . '%';
                $conn[] ='%' . $keyword . '%';
                $where.=" and (uid like %s or username like %s)";
            }else if($_GET['ordertype'] == 5){
                $conn[] ='%' . $keyword . '%';
                $where.=" and remarks like %s";
            }else if($_GET['ordertype'] == 6){
                $conn[] ='%' . $keyword . '%';
                $where.=" and buyer like %s";
            }else if($_GET['ordertype'] == 7){
                $conn[] ='%' . $keyword . '%';
                $where.=" and address like %s";
            }
		}else{
			$conn[] ='%' . $keyword . '%';
			$conn[] ='%' . $keyword . '%';
			$where.=" and (orderid like %s or stitle like %s)";
		}
	}
	if($_G['cache']['plugin']['aljbdx']['is_aljqb']){
		
        $count_all = DB::fetch_all('select count(*) num,sum(price) price,status from %t '.$where.' group by status order by status asc',$conn);
        $sumprice = 0;
        $countnum = 0;
        if($count_all){
            $search_sumprice = '&#25628;&#32034;&#32479;&#35745;&#65306;';
            foreach($count_all as $s_v){
                if($s_v['status'] > 1 && $s_v['status'] < 6){
                    $sumprice += $s_v['price'];
                    $countnum += $s_v['num'];
                }
                if($s_v['status'] == 1){
                    $search_sumprice .= '&#24453;&#20184;&#27454;'.'('.$s_v['num'].')'.'&#65306;'.'<span class="price">'.$s_v['price'].'</span> &#20803;&#65292;';
                }else if($s_v['status'] == 2){
                    $search_sumprice .= '&#24050;&#20184;&#27454;'.'('.$s_v['num'].')'.'&#65306;'.'<span class="price">'.$s_v['price'].'</span> &#20803;&#65292;';
                }else if($s_v['status'] == 3){
                    $search_sumprice .= '&#24050;&#21457;&#36135;'.'('.$s_v['num'].')'.'&#65306;'.'<span class="price">'.$s_v['price'].'</span> &#20803;&#65292;';
                }else if($s_v['status'] == 4){
                    $search_sumprice .= '&#24050;&#25910;&#36135;'.'('.$s_v['num'].')'.'&#65306;'.'<span class="price">'.$s_v['price'].'</span> &#20803;&#65292;';
                }else if($s_v['status'] == 5){
                    $search_sumprice .= '&#24050;&#35780;&#20215;'.'('.$s_v['num'].')'.'&#65306;'.'<span class="price">'.$s_v['price'].'</span> &#20803;&#65292;';
                }else if($s_v['status'] == 6){
                    $search_sumprice .= '&#24050;&#36864;&#27454;'.'('.$s_v['num'].')'.'&#65306;'.'<span class="price">'.$s_v['price'].'</span> &#20803;&#65292;';
                }else if($s_v['status'] == 7){
                    $search_sumprice .= '&#24050;&#21462;&#28040;'.'('.$s_v['num'].')'.'&#65306;'.'<span class="price">'.$s_v['price'].'</span> &#20803;&#65292;';
                }
            }
            $search_sumprice .= '&#24635;&#25910;&#20837;'.'('.$countnum.')'.'&#65306;'.'<span class="price">'.$sumprice.'</span> &#20803;';
        }
	}else{
        $wxcount = DB::result_first('select sum(price) from %t '.$where.' and status>1 and status<=5 and payment=1',$conn);
        $wwxcount = DB::result_first('select sum(price) from %t '.$where.' and status=7 and payment=1',$conn);
        $wxcountapp = DB::result_first('select sum(price) from %t '.$where.' and status>1 and status<=5 and payment=3',$conn);
        $wwxcountapp = DB::result_first('select sum(price) from %t '.$where.' and status=7 and payment=3',$conn);
        $alipay = DB::result_first('select sum(price) from %t '.$where.' and status>1  and status<=5 and payment=2',$conn);
        $walipay = DB::result_first('select sum(price) from %t '.$where.' and status=7 and payment=2',$conn);
	}

	$num = DB::result_first('select count(*) from %t '.$where,$conn);
	$start=($currpage-1)*$perpage;
	$where .= ' order by submitdate desc';
	$where .= ' limit %d,%d';
	$conn[] = $start;
	$conn[] = $perpage;

	$orderlist = DB::fetch_all('select * from %t '.$where,$conn);

    $geturl['status'] = $_GET['status'];
    $geturl['ordertype'] = $_GET['ordertype'];
    $geturl['payment'] = $_GET['payment'];
    $geturl['start'] = $_GET['start'];
    $geturl['end'] = $_GET['end'];
    $geturl['ord'] = $_GET['ord'];
    $geturl['o_type'] = $_GET['o_type'];
    
    $pagingurl = getaljurl($geturl,'');

    $paging = _mall_paging($currpage,$num,$perpage,$pagingurl.$urlmod.'&page=');
	//$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=orderlist&ord='.$_GET['ord'].'&status='.$_GET['status'].'&keyword='.$_GET['search'].$urlmod, 0, 11, false, false);
	$navtitle = '&#35746;&#21333;&#31649;&#29702;-'.$_G['cache']['plugin']['aljbd']['title'];
	$metakeywords =  $bd['other']?$bd['other']:$_G['cache']['plugin']['aljbd']['keywords'];
	$metadescription = $_G['cache']['plugin']['aljbd']['description'];
	include template('aljht:admin/orderlist/orderlist');
}
//dis'.'m.t'.'ao'.'bao.com
?>
