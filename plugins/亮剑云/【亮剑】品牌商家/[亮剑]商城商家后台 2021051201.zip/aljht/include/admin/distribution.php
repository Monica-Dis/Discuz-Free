<?php
$gid = intval($_GET['gid']);
 if($do == 'userlist'){
     if(submitcheck('formhash')) {
         $gs=dhtmlspecialchars($_GET['yhz']);
         if($_GET['sign'] == 2){
             if(is_array($_GET['delete'])) {
                 foreach($_GET['delete'] as $k => $id) {
                     DB::query('delete from %t where id=%d',array('aljsfx_user',$id));//ɾ��
                 }
             }
         }else{
             foreach($gs as $k => $v){
                 $updatearray = array(
                     'first_leader_uid'=>$v['first_leader_uid'],
                     'second_leader_uid'=>$v['second_leader_uid'],
                     'third_leader_uid'=>$v['third_leader_uid'],
                 );
                 DB::update('aljsfx_user',$updatearray,array('id'=>$k));
                 unset($updatearray);
             }
         }
         echo '<script>parent.tips(0);</script>';
         exit;
     }else{
         $currpage=$_GET['page']?intval($_GET['page']):1;
         $perpage=20;
         $start=($currpage-1)*$perpage;
         $where = ' where 1';
         $con[] = 'aljsfx_user';
         $keyword = addcslashes($_GET['search'], '%_');
         if($_GET['search']){
             $con[] ='%' . $keyword . '%';
             $con[] ='%' . $keyword . '%';
             $con[] ='%' . $keyword . '%';
             $con[] ='%' . $keyword . '%';
             $where.=" and (uid like %s or first_leader_uid like %s or second_leader_uid like %s or third_leader_uid like %s)";
         }
         $num = DB::result_first('select count(*) from %t '.$where,$con);
         $con[] = $start;
         $con[] = $perpage;
         $teamList = DB::fetch_all('select * from %t '.$where.' order by id desc limit %d,%d',$con);
         foreach ($teamList as $teamk => $teamv) {
             $teamList[$teamk]['timestamp'] = dgmdate($teamv['timestamp'],'u');
             $teamList[$teamk]['userpic'] = avatar($teamv['uid'],'middle','true');

             if(DB::fetch_first('select * from %t where uid=%d and status = 1', array('aljsfx_shop', $teamv['uid']))){
                 DB::update('aljsfx_user',array('is_distribution'=>1),array('uid'=>$teamv['uid']));
             }else{
                 DB::update('aljsfx_user',array('is_distribution'=>0),array('uid'=>$teamv['uid']));
             }
         }

         $geturl['status'] = $status;
         $pagingurl = getaljurl($geturl,'');
         $paging = _mall_paging($currpage,$num,$perpage,$pagingurl.$urlmod.'&page=');
         include template('aljht:admin/distribution/userlist');
     }
 }else if($do == 'viptime'){
    $shop_id = intval($_GET[shop_id]);
    $shopdata = DB::fetch_first('select * from %t where id=%d',array('aljsfx_shop',$shop_id));
    if($shopdata['rankid']){
        $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljsfx_rank',$shopdata['rankid']));
    }
    
    if(submitcheck('formhash')) {
        if(strtotime($_GET['rankendtime']) > TIMESTAMP){
            DB::query('update %t set rankendtime=%d where id = %d',array('aljsfx_shop',strtotime($_GET['rankendtime']),$shop_id));
        }
        echo '<script>parent.tips("'.lang("plugin/aljht","distribution_php_1").'");</script>';
		exit;
    }else{
        include template($pluginid.':admin/distribution/viptime');
    }
}else if($do == 'shoplist'){
    if(submitcheck('formhash')) {
        if ($_GET['sign'] == 3) {
            if (is_array($_GET['delete'])) {
                foreach ($_GET['delete'] as $k => $id) {
                    C::t('#aljsfx#aljsfx_shop')->update($id, array('status' => '1'));//ͨ��
                }
            }
        } else if ($_GET['sign'] == 4) {
            if (is_array($_GET['delete'])) {
                foreach ($_GET['delete'] as $k => $id) {
                    C::t('#aljsfx#aljsfx_shop')->update($id, array('status' => '3'));//��ͨ��
                }
            }
        }else if($_GET['sign'] == 5){
            if(is_array($_GET['delete'])) {
                foreach($_GET['delete'] as $k => $id) {
                    C::t('#aljsfx#aljsfx_shop')->delete($id);//ɾ��
                }
            }
        }
        echo '<script>parent.tips(0);</script>';
        exit;
    }else{
        $currpage=$_GET['page']?intval($_GET['page']):1;
        $perpage=20;
        $start=($currpage-1)*$perpage;
        $status = intval($_GET['status']);
        $where = 'where a.status=%d';
        $conn = array('aljsfx_shop','aljsfx_rank',$status);
        $keyword = addcslashes($_GET['search'], '%_');
        if($_GET['search']){
            if($_GET['search_type'] == 1){
                $conn[] ='%' . $keyword . '%';
                $where.=" and name like %s";
            }else if($_GET['search_type'] == 2){
                $conn[] ='%' . $keyword . '%';
                $where.=" and username like %s";
            }else if($_GET['search_type'] == 3){
                $conn[] =$_GET['search'];
                $where.=" and uid = %d";
            }else{
                $conn[] ='%' . $keyword . '%';
                $where.=" and shop_name like %s";
            }
        }
        
        //$teamList = DB::fetch_all('select a.*,b.name,b.price,b.num,b.goods_id,b.dis_commission from %t a left join %t b on a.orderid=b.orderid '.$where.' order by a.timestamp desc limit %d,%d',array('aljsfx_order','aljbd_goods_order_list',$this->page->global->uid,$start,$perpage));
        $num = DB::result_first('select count(*) from %t a left join %t b on a.rankid=b.id '.$where,$conn);
        $conn[] = $start;
        $conn[] = $perpage;
        $teamList = DB::fetch_all('select a.*,b.title from %t a left join %t b on a.rankid=b.id '.$where.' order by a.id desc limit %d,%d',$conn);
        foreach ($teamList as $teamk => $teamv) {
            if($teamv['shop_img']){
                $teamList[$teamk]['userpic'] = $teamv['shop_img'];
            }else{
                $teamList[$teamk]['userpic'] = avatar($teamv['uid'],'middle','true');
            }

            $teamList[$teamk]['timestamp'] = dgmdate($teamv['timestamp'],'u');
            if($teamv['rankendtime']){
                if($teamv['rankendtime'] > TIMESTAMP){
                    $teamList[$teamk]['rankendtimes'] = dgmdate($teamv['rankendtime'],'Y-m-d H:i:s').lang('plugin/aljbd','member_php_1');
                }else{
                    $teamList[$teamk]['rankendtimes'] = lang('plugin/aljbd','member_php_2');
                }
                $teamList[$teamk]['rankendtimes'] .= '<a href="javascript:;" onclick="layer_iframe_viptime(\'plugin.php?id=aljht&act=admin&op=distribution&do=viptime'.$urlmod.'&shop_id='.$teamv['id'].'\',\''.lang("plugin/aljht","distribution_php_2").'\');">'.lang("plugin/aljht","distribution_php_3").'</a>';
            }else if($teamv['rankid'] && $teamv['rankendtime']==0){
                $teamList[$teamk]['rankendtimes'] = lang('plugin/aljbd','member_php_3');
                $teamList[$teamk]['rankendtimes'] .= '<a href="javascript:;" onclick="layer_iframe_viptime(\'plugin.php?id=aljht&act=admin&op=distribution&do=viptime'.$urlmod.'&shop_id='.$teamv['id'].'\',\''.lang("plugin/aljht","distribution_php_4").'\');">'.lang("plugin/aljht","distribution_php_5").'</a>';
            }
            if($teamv['status'] == 1){
                $teamList[$teamk]['statustext'] = lang("plugin/aljht","distribution_php_6");
            }else if($teamv['status'] == 2){
                $teamList[$teamk]['statustext'] = lang("plugin/aljht","distribution_php_7");
            }else if($teamv['status'] == 3){
                $teamList[$teamk]['statustext'] = lang("plugin/aljht","distribution_php_8");
            }else{
                $teamList[$teamk]['statustext'] = lang("plugin/aljht","distribution_php_9");
            }
        }

        $geturl['status'] = $status;
        $geturl['search'] = $_GET['search'];
        $pagingurl = getaljurl($geturl,'');
        $paging = _mall_paging($currpage,$num,$perpage,$pagingurl.$urlmod.'&page=');
        include template('aljht:admin/distribution/shoplist');
    }
}else if($do == 'cashlog'){
    if(0) {
        if ($_GET['sign'] == 3) {
            if (is_array($_GET['delete'])) {
                foreach ($_GET['delete'] as $k => $id) {
                    C::t('#aljsfx#aljsfx_cashorder')->update($id, array('status' => '1'));//ͨ��
                }
            }
        } else if ($_GET['sign'] == 4) {
            if (is_array($_GET['delete'])) {
                foreach ($_GET['delete'] as $k => $id) {
                    C::t('#aljsfx#aljsfx_cashorder')->update($id, array('status' => '3'));//��ͨ��
                }
            }
        }
        echo '<script>parent.tips(0);</script>';
        exit;
    }else {
        $currpage = $_GET['page'] ? intval($_GET['page']) : 1;
        $perpage = 20;
        $start = ($currpage - 1) * $perpage;
        $status = intval($_GET['status']);
        $where = 'where status=%d';
        $num = DB::result_first('select count(*) from %t ' . $where , array('aljsfx_cashorder', $status));
        $teamList = DB::fetch_all('select * from %t ' . $where . ' order by id desc limit %d,%d', array('aljsfx_cashorder', $status, $start, $perpage));
        foreach ($teamList as $teamk => $teamv) {
            $teamList[$teamk]['userpic'] = avatar($teamv['uid'], 'middle', 'true');
            $teamList[$teamk]['time'] = dgmdate($teamv['time'], 'u');
            if ($teamv['status'] == 1) {
                $teamList[$teamk]['statustext'] = lang("plugin/aljht","distribution_php_10");
            } else if ($teamv['status'] == 2) {
                $teamList[$teamk]['statustext'] = lang("plugin/aljht","distribution_php_11");
            } else {
                $teamList[$teamk]['statustext'] = lang("plugin/aljht","distribution_php_12");
            }
        }
        $geturl['status'] = $status;
        $pagingurl = getaljurl($geturl,'');
        $paging = _mall_paging($currpage,$num,$perpage,$pagingurl.$urlmod.'&page=');
        include template('aljht:admin/distribution/cashlog');
    }
}else if($do == 'user'){
    if(0) {
        if ($_GET['sign'] == 3) {
            if (is_array($_GET['delete'])) {
                foreach ($_GET['delete'] as $k => $id) {
                    C::t('#aljsfx#aljsfx_cashorder')->update($id, array('status' => '1'));//ͨ��
                }
            }
        } else if ($_GET['sign'] == 4) {
            if (is_array($_GET['delete'])) {
                foreach ($_GET['delete'] as $k => $id) {
                    C::t('#aljsfx#aljsfx_cashorder')->update($id, array('status' => '3'));//��ͨ��
                }
            }
        }
        echo '<script>parent.tips(0);</script>';
        exit;
    }else {
        $currpage = $_GET['page'] ? intval($_GET['page']) : 1;
        $perpage = 20;
        $start = ($currpage - 1) * $perpage;
        $status = intval($_GET['status']);
        $shop_uid = intval($_GET['shop_uid']);
        if($status == 2){
            $where = 'where second_leader_uid=%d';
        }else if($status == 3){
            $where = 'where third_leader_uid=%d';
        }else{
            $where = 'where first_leader_uid=%d';
        }
        $num = DB::result_first('select count(*) from %t ' . $where , array('aljsfx_user', $shop_uid));
        $teamList = DB::fetch_all('select * from %t ' . $where . ' order by id desc limit %d,%d', array('aljsfx_user', $shop_uid, $start, $perpage));
        foreach ($teamList as $teamk => $teamv) {
            $teamList[$teamk]['userpic'] = avatar($teamv['uid'],'middle','true');
            $teamList[$teamk]['timestamp'] = dgmdate($teamv['timestamp'],'u');
        }
        $geturl['status'] = $status;
        $geturl['shop_uid'] = $shop_uid;
        $pagingurl = getaljurl($geturl,'');
        $paging = _mall_paging($currpage,$num,$perpage,$pagingurl.$urlmod.'&page=');
        include template('aljht:admin/distribution/user');
    }
}else if($do == 'order'){
    if(0) {
        if ($_GET['sign'] == 3) {
            if (is_array($_GET['delete'])) {
                foreach ($_GET['delete'] as $k => $id) {
                    C::t('#aljsfx#aljsfx_order')->update($id, array('status' => '1'));//ͨ��
                }
            }
        } else if ($_GET['sign'] == 4) {
            if (is_array($_GET['delete'])) {
                foreach ($_GET['delete'] as $k => $id) {
                    C::t('#aljsfx#aljsfx_order')->update($id, array('status' => '3'));//��ͨ��
                }
            }
        }
        echo '<script>parent.tips(0);</script>';
        exit;
    }else {
        $keyword = addcslashes($_GET['search'], '%_');
        $currpage = $_GET['page'] ? intval($_GET['page']) : 1;
        $perpage = 20;
        $start = ($currpage - 1) * $perpage;
        $status = intval($_GET['status']);
        $con[]='aljsfx_order';
        
        if($status == 1){
            $where = 'where status=1';
        }else if($status == 2){
            $where = 'where status=2';
        }else{
            $where = 'where 1';
        }
        
        if($_GET['search']){
            $con[] ='%' . $keyword . '%';
            $con[] ='%' . $keyword . '%';
            $con[] ='%' . $keyword . '%';
            $where.=" and (beneficiary_username like %s or orderid like %s or username like %s)";
        }
        $num = DB::result_first('select count(*) from %t '.$where,$con);
        $where.= ' order by id desc limit %d,%d';
        $con[] = $start;
        $con[] = $perpage;
        $teamList = DB::fetch_all('select * from %t '.$where,$con);

        foreach ($teamList as $teamk => $teamv) {
            if(!$teamv['name']){
                $order_g = DB::fetch_first('select * from %t where orderid=%s',array('aljbd_goods_order_list',$teamv['orderid']));
                $teamList[$teamk]['name'] = $order_g['name'];
                $teamList[$teamk]['price'] = $order_g['price'];
                $teamList[$teamk]['num'] = $order_g['num'];
                $teamList[$teamk]['goods_id'] = $order_g['goods_id'];
                $teamv['goods_id'] = $order_g['goods_id'];
                $teamList[$teamk]['dis_commission'] = $order_g['dis_commission'];
                $teamv['dis_commission'] = $order_g['dis_commission'];
            }
            if($teamv['goods_id']){
                $teamList[$teamk]['scale'] = floatval(substr(sprintf("%.3f",$teamv['dis_commission']*$teamv['scale']/100),0,-1));
                $teamList[$teamk]['gpic'] = DB::result_first('select pic1 from %t where id=%d',array('aljbd_goods',$teamv['goods_id']));
            }else{
                $teamList[$teamk]['scale'] = floatval(substr(sprintf("%.3f",$teamv['shop_scale']*$teamv['scale']/100),0,-1));
                $teamList[$teamk]['gpic'] = avatar($teamv['uid'],'middle','true');
                if($teamv['type'] == 2){
                    $teamList[$teamk]['name'] = $teamv['username'].lang("plugin/aljht","distribution_php_13").DB::result_first('select price from %t where orderid=%d',array('aljbd_goods_order',$teamv['orderid'])).lang("plugin/aljht","distribution_php_14");
                }else if($teamv['type'] == 3){
                    $teamList[$teamk]['name'] = lang("plugin/aljht","distribution_php_15").$teamv['username'].lang("plugin/aljht","distribution_php_16");
                }else{
                    $teamList[$teamk]['name'] = $teamv['username'].lang("plugin/aljht","distribution_php_17").DB::result_first('select price from %t where orderid=%d',array('aljbd_goods_order',$teamv['orderid'])).lang("plugin/aljht","distribution_php_18");
                }

            }

            $teamList[$teamk]['timestamp'] = dgmdate($teamv['timestamp'],'u');
        }

        $geturl['status'] = $status;
        $pagingurl = getaljurl($geturl,'');
        $paging = _mall_paging($currpage,$num,$perpage,$pagingurl.$urlmod.'&page=');
        include template('aljht:admin/distribution/order');
    }
}else if($do == 'adddistribution' || $do == 'editdistribution'){
    $gvip = C::t('#aljsfx#aljsfx_rank') -> fetch($gid);
    if(submitcheck('formhash')){

        $updatearray = array(
            'shop_scale'=>$_GET['shop_scale'],
            'f_shop_scale'=>$_GET['f_shop_scale'],
            'first_scale'=>$_GET['first_scale'],
            'second_scale'=>$_GET['second_scale'],
            'third_scale'=>$_GET['third_scale'],
            'title'=>$_GET['title'],
            'day'=>$_GET['day'],
            'price'=>$_GET['price'],
            'payment_days'=>$_GET['payment_days'],
            'status'=>$_GET['status'],
            'mincashmoney'=>$_GET['mincashmoney'],
            'open_mypay'=>$_GET['open_mypay'],
            'donation_amount'=>$_GET['donation_amount'],
            'fx_jf_type'=>$_GET['fx_jf_type'],
            'fx_ext'=>$_GET['fx_ext'],
        );
        if($gvip){

            $updatearray['updatetime'] = TIMESTAMP;
            C::t('#aljsfx#aljsfx_rank')->update($gid,$updatearray);
        }else{
            $updatearray['timestamp'] = TIMESTAMP;
            $updatearray['updatetime'] = TIMESTAMP;
            C::t('#aljsfx#aljsfx_rank')->insert($updatearray);
        }

        echo "<script>parent.tips('".lang('plugin/aljbd','s53')."','plugin.php?id=aljht&act=admin&op=".$op.$urlmod."');</script>";
        exit;

    }else{
        include template('aljht:admin/distribution/adddistribution');
    }
}else if($do == 'isopen'){
    $status = intval($_GET['status']);

    if(C::t('#aljsfx#aljsfx_rank')->update($gid,array('status'=>$status))){
        echo 1;
    }else{
        echo 0;
    }
    exit;
}else if($do == 'add'){
    $shop_id = $_GET['shop_id'];
    $aljsfx_rank=DB::fetch_all('select * from %t where status=1 order by displayorder desc,id asc',array('aljsfx_rank'));
    $shopdata = DB::fetch_first('select * from %t where id=%d',array('aljsfx_shop',$shop_id));
    if(submitcheck('formhash')){
        if(!$_GET['shop_name']){
            $tipstext = lang("plugin/aljsfx","distribution_php_79");
            echo "<script>parent.tips('".$tipstext."','');</script>";
            exit;
        }
        if(!$_GET['name']){
            $tipstext = lang("plugin/aljsfx","distribution_php_80");
            echo "<script>parent.tips('".$tipstext."','');</script>";
            exit;
        }
        if(!$_GET['tel']){
            $tipstext = lang("plugin/aljsfx","distribution_php_81");
            echo "<script>parent.tips('".$tipstext."','');</script>";
            exit;
        }else{
            if(!T::isMobile($_GET['tel'])){
                $tipstext = lang("plugin/aljsfx","distribution_php_82");
                echo "<script>parent.tips('".$tipstext."','');</script>";
                exit;
            }
        }

        $insertarray = array(
            'shop_name' => $_GET['shop_name'],
            'name' => $_GET['name'],
            'tel' => $_GET['tel'],
        );
        if($shopdata){
            $rankid = $_GET['rankid'];
            $insertarray['rankid'] = $rankid;
            
            $rankdata = DB::fetch_first('select * from %t where id=%d',array('aljsfx_rank',$rankid));
            if($rankdata){
                $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
                $orderarray=array(
                    'orderid' => $orderid,
                    'status' => 1,
                    'uid' => $shopdata['uid'],
                    'username' => $shopdata['username'],
                    'price' => $rankdata['price'],
                    'submitdate' => TIMESTAMP,
                    'remarks' => $rankdata['day'].'/'.$rankdata['price'],
                    'stitle' => lang("plugin/aljht","distribution_php_19").'-'.$_GET['name'],
                    'payment' => 7,
                    'pid'  => 4,//����
                    'browser'  => $_SERVER['HTTP_USER_AGENT'],
                );
                $orderarray['fare_desc'] = $rankid;
                if($_G['mobile']){//1���ֻ���2��PC
                    $orderarray['mobile'] = 1;
                }else{
                    $orderarray['mobile'] = 2;
                }

                if($rankdata['day'] == 0){
                    $insertarray['rankendtime'] = 0;
                }else{
                    $insertarray['rankendtime'] = TIMESTAMP + ($rankdata['day'] * 86400);
                }

                //$insertid = DB::insert('aljsfx_shop',$insertarray, true);
                $orderarray['shop_id'] = $shop_id;
                $orderarray['status'] = 2;
                $fxinfo = DB::fetch_first('select * from %t where uid=%d ', array('aljsfx_user', $shopdata['uid']));
                if($fxinfo['first_leader_uid']>0){
                    $insertarray['subid'] = DB::result_first('select id from %t where uid=%d',array('aljsfx_shop',$fxinfo['first_leader_uid']));
                }
                if($fxinfo){
                    DB::update('aljsfx_user',array('is_distribution'=>1),array('uid'=>$shopdata['uid']));
                }
                C::t('#aljgwc#aljbd_goods_order')->insert($orderarray);
            }
            $idpicarray = array('shop_img','shop_weixin','shop_logo');
            foreach ($idpicarray as $pic1){
                if ($_GET[$pic1]) {
                    if (strpos($_GET[$pic1],"base64") === false) {
                        $insertarray[$pic1] = $_GET[$pic1];
                    } else {
                        unlink($shopdata[$_GET[$pic1]]);
                        T::delete_oss($shopdata[$_GET[$pic1]]);
                        
                        $insertarray[$pic1] = T::saveimg($_GET[$pic1],'source/plugin/aljsfx/static/cache/');
                    }

                }
            }
            
            $insertarray['status'] = $_GET['status'];
            
            DB::update('aljsfx_shop',$insertarray,array('id'=>$shop_id));
            $tipstext = lang("plugin/aljht","distribution_php_20");
            echo "<script>parent.tips('".$tipstext."','plugin.php?id=aljht&act=admin&do=shoplist&op=".$op.$urlmod."',1);</script>";
            exit;
        }
    }else{
        include template('aljht:admin/distribution/add');
    }
}else{
    if(submitcheck('formhash')){

        $gs=dhtmlspecialchars($_GET['yhz']);
        if($_GET['sign'] == 2){
            if(is_array($_GET['delete'])) {
                foreach($_GET['delete'] as $k => $id) {
                    C::t('#aljsfx#aljsfx_rank')->delete($id);//ɾ��
                }
            }
        }else if($_GET['sign'] == 3){
            if(is_array($_GET['delete'])) {
                foreach($_GET['delete'] as $k => $id) {
                    C::t('#aljsfx#aljsfx_rank')->update($id,array('status'=>'1'));//����
                }
            }
        }else if($_GET['sign'] == 4){
            if(is_array($_GET['delete'])) {
                foreach($_GET['delete'] as $k => $id) {
                    C::t('#aljsfx#aljsfx_rank')->update($id,array('status'=>'0'));//�ر�
                }
            }
        }else{
            foreach($gs as $k => $v){
                if(C::t('#aljsfx#aljsfx_rank')->fetch($k)){
                    $updatearray = array(
                        'shop_scale'=>$v['shop_scale'],
                        'f_shop_scale'=>$v['f_shop_scale'],
                        'first_scale'=>$v['first_scale'],
                        'second_scale'=>$v['second_scale'],
                        'third_scale'=>$v['third_scale'],
                        'payment_days'=>$v['payment_days'],
                        'title'=>$v['title'],
                        'day'=>$v['day'],
                        'price'=>$v['price'],
                        'displayorder'=>$v['displayorder'],
                        'mincashmoney'=>$v['mincashmoney'],
                    );
                    if($_G['cache']['plugin']['aljsfx_rt']['is_new_reward']){
                        $updatearray['new_reward'] = $v['new_reward'];
                    }
                    $updatearray['updatetime'] = TIMESTAMP;
                    C::t('#aljsfx#aljsfx_rank')->update($k,$updatearray);
                }else{
                    $insertarray = array(
                        'shop_scale'=>$v['shop_scale'],
                        'f_shop_scale'=>$v['f_shop_scale'],
                        'first_scale'=>$v['first_scale'],
                        'second_scale'=>$v['second_scale'],
                        'third_scale'=>$v['third_scale'],
                        'payment_days'=>$v['payment_days'],
                        'title'=>$v['title'],
                        'day'=>$v['day'],
                        'price'=>$v['price'],
                        'displayorder'=>$v['displayorder'],
                        'mincashmoney'=>$v['mincashmoney'],
                    );
                    if($_G['cache']['plugin']['aljsfx_rt']['is_new_reward']){
                        $insertarray['new_reward'] = $v['new_reward'];
                    }
                    $insertarray['timestamp'] = TIMESTAMP;
                    $insertarray['updatetime'] = TIMESTAMP;
                    C::t('#aljsfx#aljsfx_rank')->insert($insertarray);
                }
                unset($insertarray);
                unset($updatearray);
            }
        }
        echo '<script>parent.tips(0);</script>';
        exit;
    }else{

        //$aljbd_groups=C::t('#aljsfx#aljsfx_rank')->range();
        $aljbd_groups=DB::fetch_all('select * from %t order by displayorder desc,id asc',array('aljsfx_rank'));
        include template('aljht:admin/distribution/distribution');
    }
}
//From: Dism_taobao-com
?>