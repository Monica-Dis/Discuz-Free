<?php
if($do == 'editpagelist' || $do == 'addpagelist'){
	$pagelist=C::t('#aljbd#aljbd_page')->fetch($paid);
	if(submitcheck('formhash')){
		if(empty($bid)){
			echo '<script>parent.tips("'.lang('plugin/aljbd','s51').'");</script>';
			exit;
		}
		if($settings['is_attes']['value']){
			$sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
			if(!$sign){
				echo "<script>parent.tips('".lang("plugin/aljht","pagelist_php_1")."');</script>";
				exit;
			}
		}
		if(empty($_GET['subject'])){
			echo '<script>parent.tips("'.lang('plugin/aljbd','aljbd_1').'");</script>';
			exit;
		}
		if(empty($_GET['intro'])){
			echo '<script>parent.tips("'.lang('plugin/aljbd','aljbd_2').'");</script>';
			exit;
		}
		$insertarray = array(
				'bid'=>$bid,
				'subject'=>$_GET['subject'],
				'content'=>$_GET['intro'],
				'dateline'=>TIMESTAMP,
				'type'=>$_GET['type'],
				'subtype'=>$_GET['subtype'],
				'displayorder'=>$_GET['displayorder'],
		);
		$bd=C::t('#aljbd#aljbd')->fetch($bid);
		$insertarray['uid'] = $bd['uid'];
		$insertarray['username'] = $bd['username'];
		if($pagelist){
			C::t('#aljbd#aljbd_page')->update($paid,$insertarray);
		}else{
			
			C::t('#aljbd#aljbd_page')->insert($insertarray);
		}
		echo '<script>parent.tips("'.lang('plugin/aljbd','s53').'","plugin.php?id=aljht&act=admin&op=pagelist'.$urlmod.'");</script>';
		exit;
	}else{
		if($bid){
			$bd=C::t('#aljbd#aljbd')->fetch($bid);
		}
		$bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','',$_G['uid']);
		include template('aljht:admin/pagelist/addpagelist');
	}
}else{
	$keyword = addcslashes($_GET['search'], '%_');
	if(submitcheck('formhash') && empty($keyword)){
		if($_GET['sign'] == 2){
			if(is_array($_GET['delete'])) {
				foreach($_GET['delete'] as $k => $id) {
					DB::query('delete from %t where id = %d',array('aljbd_page',$id));
				}
			}
		}
		echo '<script>parent.tips(0);</script>';
		exit;
	}
	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	$con[]='aljbd_page';
	
	$where=" where rubbish=0 and uid = %d";
	$con[] = $_G['uid'];
	
	if($_GET['search']){
		$con[] ='%' . $keyword . '%';
		$where.=" and subject like %s";
	}
	
	$num = DB::result_first('select count(*) from %t'.$where,$con);
	$con[]=$start;
	$con[]=$perpage;
	$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY id desc limit %d,%d',$con);
	
	$bdlist = dhtmlspecialchars($bdlist);
	$navtitle = lang("plugin/aljht","pagelist_php_2").'-'.$config['title'];
	$metakeywords =  $bd['other']?$bd['other']:$config['keywords'];
	$metadescription = $config['description'];
	include template('aljht:admin/pagelist/pagelist');
}
//From: Dism_taobao-com
?>