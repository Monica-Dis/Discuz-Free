<?php
$gid = intval($_GET['gid']);
if($do == 'difference'){

    if($_GET['formhash'] == FORMHASH){
        if(!C::t('#aljbd#aljbd_setting')->fetch('difference')){
            C::t('#aljbd#aljbd_setting')->insert(array('key'=>'difference','value'=>$_GET['message']));
        }else{
            if($_GET['message']){
                C::t('#aljbd#aljbd_setting')->update_value_by_key($_GET['message'],'difference');
            }
        }
        savecache('aljbd_settings', '');
        echo '<script>parent.tips(0);</script>';
        exit;
    }else{
        echo '<script>parent.tips("'.lang("plugin/aljht","vip_php_1").'");</script>';
        exit;
    }
}else if($do == 'isopen'){
    $status = intval($_GET['status']);

    if(C::t('#aljbd#aljbd_vip')->update($gid,array('status'=>$status))){
        echo 1;
    }else{
        echo 0;
    }
    exit;
}else if($do == 'addvip' || $do == 'editvip'){
    $store_authority = array();
    if($_G['cache']['plugin']['aljvd']){
        $store_authority['brand_live'] = lang("plugin/aljht","vip_php_2");
    }
    $store_authority['goods_intro_video'] = lang("plugin/aljht","vip_php_3");
    if($_G['cache']['plugin']['aljtbk']['on'] && 0){
        $store_authority['import_tbk'] = lang("plugin/aljht","vip_php_4");
    }
    if($_G['cache']['plugin']['aljdd']){
        $store_authority['brand_diy'] = lang('plugin/aljht','vip_php_5');
    }
    $gvip = C::t('#aljbd#aljbd_vip') -> fetch($gid);
    if($gvip){
        $gvip['store_authority'] = explode(',',$gvip['store_authority']);
    }
    if(submitcheck('formhash')){
        $updatearray = array(
            'notice'=>$_GET['notice'],
            'album'=>$_GET['album'],
            'good'=>$_GET['good'],
            'consume'=>$_GET['consume'],
            'title'=>$_GET['grouptitle'],
            'day'=>$_GET['day'],
            'price'=>$_GET['price'],
            'fee'=>$_GET['fee'],
            'status'=>$_GET['status'],
            'is_hide'=>$_GET['is_hide'],
            'give_integral'=>$_GET['give_integral'],
            'pay_integral'=>$_GET['pay_integral']
        );
        if($_G['cache']['plugin']['aljsr']['is_aljsr']){
            $updatearray[payment_days] = $_GET['payment_days'];
        }
        if($_GET['copy'] == '1' && $_GET['logo']){//������ƷͼƬ����
            if (strpos($_GET['logo'],$_G['cache']['plugin']['aljoss']['domain']) === false) {
                $rand = rand(100, 999);
                $pics = date("YmdHis") . $rand . '.jpg';
                $img_dir = $image_path . 'logo/' . date('Ymd', TIMESTAMP) . '/';
                if (!is_dir($img_dir)) {
                    mkdir($img_dir);
                }
                $pic = $img_dir . $pics;
                if (@copy($_GET['logo'], $pic) || @move_uploaded_file($_GET['logo'], $pic)) {
                    if (file_exists($pic)) {
                        if($_G['cache']['plugin']['aljoss']['Access_Key']) {
                            $pic = T::oss($pic, $pluginid);
                        }
                    }
                }
                $updatearray['logo'] = $pic;
            }else{
                $updatearray['logo'] = T::saveimg($_GET['logo'],$image_path.'logo/');
            }
        }else{
            if($_GET['compress'] == '1'){
                if($_FILES['logo']['tmp_name']) {
                    $picname = $_FILES['logo']['name'];
                    $picsize = $_FILES['logo']['size'];
    
                    if ($picname != "") {
                        $type = strtolower(strrchr($picname, '.'));
                        if ($type != ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
                            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                                echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
                                exit;
                            }else{
                                echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
                                exit;
                            }
                        }
                        if (($picsize/1024)>$_G['cache']['plugin']['aljbd']['img_size']) {
                            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                                echo "<script>parent.tips('".lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB'."','');</script>";
                                exit;
                            }else{
                                echo "<script>parent.tips('".lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB'."','');</script>";
                                exit;
                            }
                        }
                        $rand = rand(100, 999);
                        $pics = date("YmdHis") . $rand . $type;
                        $img_dir = $image_path.'logo/'.date('Ymd',TIMESTAMP).'/';
                        if (!is_dir($img_dir)) {
                            mkdir($img_dir);
                        }
                        $logo = $img_dir.$pics;
                        if(@copy($_FILES['logo']['tmp_name'], $logo)||@move_uploaded_file($_FILES['logo']['tmp_name'], $logo)){
                            @unlink($_FILES['logo']['tmp_name']);
                        }
                    }
                    if($logo){
                        unlink($gvip['logo']);
                        $updatearray['logo']=$logo;
                    }
                }
            }else{
                
                if (strpos($_GET['logo'],"base64") === false) {
                    $updatearray['logo'] = $_GET['logo'];
                } else {
                    unlink($gvip['logo']);
                    T::delete_oss($gvip['logo']);
                    $updatearray['logo'] = T::saveimg($_GET['logo'],$image_path.'logo/');
                }
            }
        }
        $updatearray['store_authority'] = implode(',',$_GET['store_authority']);
        if($_G['cache']['plugin']['aljsfx']['is_aljsfx']){
            $updatearray['is_distribution'] = $_GET['is_distribution'];
        }
        $updatearray['is_goods'] = $_GET['is_goods'];
        $updatearray['is_album'] = $_GET['is_album'];
        $updatearray['is_notice'] = $_GET['is_notice'];
        $updatearray['is_consume'] = $_GET['is_consume'];
        $updatearray['video'] = $_GET['video'];
        $updatearray['is_bvideo'] = $_GET['is_bvideo'];

        $updatearray['is_video'] = $_GET['is_video'];
        $updatearray['bzj_price'] = $_GET['bzj_price'];
        if($gvip && !$_GET['copy']){
            $updatearray['updatetime'] = TIMESTAMP;
            C::t('#aljbd#aljbd_vip')->update($gid,$updatearray);
        }else{
            $updatearray['addtime'] = TIMESTAMP;
            $updatearray['updatetime'] = TIMESTAMP;
            C::t('#aljbd#aljbd_vip')->insert($updatearray);
        }

        echo "<script>parent.tips('".lang('plugin/aljbd','s53')."','plugin.php?id=aljht&act=admin&op=".$op.$urlmod."');</script>";
        exit;

    }else{
        include template('aljht:admin/vip/addvip');
    }
}else{
    if(submitcheck('formhash')){

        $gs=dhtmlspecialchars($_GET['yhz']);
        if($_GET['sign'] == 2){
            if(is_array($_GET['delete'])) {
                foreach($_GET['delete'] as $k => $id) {
                    C::t('#aljbd#aljbd_vip')->delete($id);//ɾ��
                }
            }
        }else if($_GET['sign'] == 3){
            if(is_array($_GET['delete'])) {
                foreach($_GET['delete'] as $k => $id) {
                    C::t('#aljbd#aljbd_vip')->update($id,array('status'=>'1'));//����
                }
            }
        }else if($_GET['sign'] == 4){
            if(is_array($_GET['delete'])) {
                foreach($_GET['delete'] as $k => $id) {
                    C::t('#aljbd#aljbd_vip')->update($id,array('status'=>'0'));//�ر�
                }
            }
        }else{
            foreach($gs as $k => $v){

                if ($v['logo']) {
                    $rand = rand(100, 999);
                    $pics = date("YmdHis") . $rand . '.jpg';
                    $img_dir = $image_path.'logo/'.date('Ymd',TIMESTAMP).'/';
                    if (!is_dir($img_dir)) {
                        mkdir($img_dir);
                    }
                    $pic = $img_dir . $pics;

                    file_put_contents($pic,file_get_contents($v['logo']));

                }
                if(C::t('#aljbd#aljbd_vip')->fetch($k)){
                    $updatearray = array(
                        'notice'=>$v['notice'],
                        'album'=>$v['album'],
                        'good'=>$v['good'],
                        'consume'=>$v['consume'],
                        'title'=>$v['grouptitle'],
                        'day'=>$v['day'],
                        'price'=>$v['price'],
                        'fee'=>$v['fee'],
                        'displayorder'=>$v['displayorder'],
                    );
                    if($pic){
                        $updatearray['logo'] = $pic;
                    }
                    $updatearray['updatetime'] = TIMESTAMP;
                    C::t('#aljbd#aljbd_vip')->update($k,$updatearray);
                }else{
                    $insertarray = array(
                        'notice'=>$v['notice'],
                        'album'=>$v['album'],
                        'good'=>$v['good'],
                        'consume'=>$v['consume'],
                        'title'=>$v['grouptitle'],
                        'day'=>$v['day'],
                        'price'=>$v['price'],
                        'fee'=>$v['fee'],
                        'displayorder'=>$v['displayorder'],
                    );
                    if($pic){
                        $insertarray['logo'] = $pic;
                    }
                    $insertarray['addtime'] = TIMESTAMP;
                    $insertarray['updatetime'] = TIMESTAMP;
                    C::t('#aljbd#aljbd_vip')->insert($insertarray);
                }
                unset($pic);
                unset($insertarray);
                unset($updatearray);
            }
        }
        echo '<script>parent.tips(0);</script>';
        exit;
    }else{

        if($_G['cache']['plugin']['aljtsq']){
            $where = ' where type=0';
        }
        $aljbd_groups=DB::fetch_all('select * from %t '.$where.' order by displayorder desc,id asc',array('aljbd_vip'));
        include template('aljht:admin/vip/vip');
    }
}
//From: Dism_taobao-com
?>