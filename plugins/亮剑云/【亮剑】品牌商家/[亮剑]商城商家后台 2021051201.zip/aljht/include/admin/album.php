<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($bid){
    $bd=C::t('#aljbd#aljbd')->fetch($bid);
}
if($do == 'sh_status'){
    if($_GET['formhash'] == FORMHASH) {
        if(!$administrators && $_GET[i] != 1){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","album_php_3"))));
            exit;
        }
        if(!$_GET[cashid]){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","album_php_4"))));
            exit;
        }

        $goods = C::t('#aljbd#aljbd_album')->fetch($_GET[cashid]);
        if(!$goods){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","album_php_5"))));
            exit;
        }

        if(strtolower(CHARSET) == 'gbk' && !$_G[mobile] && $_GET[message]){
            $_GET[message] = diconv($_GET[message],'utf-8','gbk');
        }

        if(DB::query('update %t set status=%d,reason=%s  where id = %d and status = %d',array('aljbd_album',$_GET[status],$_GET[message],$_GET[cashid],$goods['status']))){
            if($_GET[status] == 2){
                $send_goods_tips = lang("plugin/aljht","album_php_6").'{shopname}'.lang("plugin/aljht","album_php_7").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=album&mod=my">'.lang("plugin/aljht","album_php_8").'</a>';
            }else{
                $send_goods_tips = lang("plugin/aljht","album_php_9").'{shopname}'.lang("plugin/aljht","album_php_10").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=album&mod=my">'.lang("plugin/aljht","album_php_11").'</a>';
            }
            $reason = $_GET[message] ? lang("plugin/aljht","album_php_12").$_GET[message] : '';
            notification_add(
                $goods['uid'],
                'system',str_replace(array('{shopname}','{reason}'),array($goods['albumname'],$reason), $send_goods_tips),
                array('from_idtype'  => 'aljbd_album','from_id' => $goods['id'])
            );
            echo json_encode(T::ajaxPostCharSet(array('code'=>1,'text'=>lang("plugin/aljht","album_php_13"))));
            exit;
        }else{
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","album_php_14"))));
            exit;
        }
    }else{
        echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","album_php_15"))));
        exit;
    }
}else if($do == 'editalbum' || $do == 'addalbum'){

	$album = C::t('#aljbd#aljbd_album') -> fetch($aid);
    if($_G['cache']['plugin']['aljbzj']['is_force_pay'] && $bzj_info['price'] <= 0 && $bid && file_exists("source/plugin/aljbzj/template/force_pay_tips.htm") && !$administrators){
        if(submitcheck('formhash')) {
            $post = 1;
            include template('aljbzj:force_pay_tips');
            exit;
        }
    }
    if($do == 'addalbum'){
        if($bd['vipid']){
            $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$bd['vipid']));

            $brandnum['album']=$vipdata['album'];
            $bnum = C::t('#aljbd#aljbd_album')->count_by_uid_bid($_G['uid']);
            if ($brandnum['album'] && !$administrators) {
                if ($brandnum['album'] == $checksign) {
                    if(submitcheck('formhash')){
                        echo "<script>parent.tips('".lang('plugin/aljbd','noauth')."','');</script>";
                    }else {
                        $aljht_tips = lang('plugin/aljbd', 'noauth') . $albumtips;
                        include template('aljht:admin/pogressbar');
                    }
                    exit;
                }
                if ($bnum >= $brandnum['album']) {
                    if(submitcheck('formhash')){
                        echo "<script>parent.tips('".lang('plugin/aljbd', 'groups_1') . $brandnum['album'] . lang('plugin/aljbd', 'groups_6')."','');</script>";
                    }else {
                        $aljht_tips = lang('plugin/aljbd', 'groups_1') . $brandnum['album'] . lang('plugin/aljbd', 'groups_6') . $albumtips;
                        include template('aljht:admin/pogressbar');
                    }
                    exit;
                }
            }
        }
        if($yhzqx) {
            $bnum = C::t('#aljbd#aljbd_album')->count_by_uid_bid($_G['uid']);
            if ($brandnum['album'] && !$administrators) {
                if ($brandnum['album'] == $checksign) {
                    if(submitcheck('formhash')){
                        echo "<script>parent.tips('".lang('plugin/aljbd','noauth')."','');</script>";
                    }else {
                        $aljht_tips = lang('plugin/aljbd', 'noauth') . $albumtips;
                        include template('aljht:admin/pogressbar');
                    }
                    exit;
                }
                if ($bnum >= $brandnum['album']) {
                    if(submitcheck('formhash')){
                        echo "<script>parent.tips('".lang('plugin/aljbd', 'groups_1') . $brandnum['album'] . lang('plugin/aljbd', 'groups_6')."','');</script>";
                    }else {
                        $aljht_tips = lang('plugin/aljbd', 'groups_1') . $brandnum['album'] . lang('plugin/aljbd', 'groups_6') . $albumtips;
                        include template('aljht:admin/pogressbar');
                    }
                    exit;
                }
            }
        }
    }
	if(submitcheck('formhash')){
		if(empty($bid)){
			echo "<script>parent.tips('".lang('plugin/aljbd','s51')."','');</script>";
			exit;
		}
		if($settings['is_attes']['value']){
			$sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
			if(!$sign){
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('".lang("plugin/aljht","album_php_1")."','');</script>";
					exit;
				}else{
					echo "<script>parent.tips('".lang("plugin/aljht","album_php_2")."','');</script>";
					exit;
				}
			}
		}
		if(empty($_GET['albumname'])){
			echo "<script>parent.tips('".lang('plugin/aljbd','album_1')."','');</script>";
			exit;
		}
		$insertarray = array(
			'bid'=>$bid,
			'albumname'=>$_GET['albumname'],
			'description'=>$_GET['description'],
			'displayorder'=>'100',
		);
        if($_GET['compress'] == '1'){
            if($_FILES['logo']['tmp_name']) {
                $picname = $_FILES['logo']['name'];
                $picsize = $_FILES['logo']['size'];

                if ($picname != "") {
                    $type = strtolower(strrchr($picname, '.'));
                    if ($type!= ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
                        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                            echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
                            exit;
                        }else{
                            echo '<script>parent.tips("'.lang('plugin/aljbd','s19').'");</script>';
                            exit;
                        }
                    }
                    if (($picsize/1024)>$_G['cache']['plugin']['aljbd']['img_size']) {
                        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                            echo "<script>parent.tips('".lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB'."','');</script>";
                            exit;
                        }else{
                            echo '<script>parent.tips("'.lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB'.'");</script>';
                            exit;
                        }
                    }
                    $rand = rand(100, 999);
                    $pics = date("YmdHis") . $rand . $type;
                    $img_dir = $image_path."album/".date('Ymd',TIMESTAMP).'/';
                    if (!is_dir($img_dir)) {
                        mkdir($img_dir);
                    }
                    $logo = $img_dir. $pics;
                    if(@copy($_FILES['logo']['tmp_name'], $logo)||@move_uploaded_file($_FILES['logo']['tmp_name'], $logo)){
                        if($_G['cache']['plugin']['aljbd']['iswatermark']){
                            $image->Watermark(DISCUZ_ROOT.'./'.$logo,'', 'forum');
                        }
                        @unlink($_FILES['logo']['tmp_name']);
                    }
                }
            }
        }else{
            if ($_GET['logo']) {
                if (strpos($_GET['logo'],"base64") === false) {
                    $logo = $_GET['logo'];
                } else {
                    unlink($album['logo']);
                    $logo = T::saveimg($_GET['logo'],$image_path.'album/');
                }
            }
        }
		$insertarray['uid'] = $bd['uid'];
		$insertarray['username'] = $bd['username'];
		if($album){
            if($logo){
                $insertarray['subjectimage']=$logo;
            }
			C::t('#aljbd#aljbd_album')->update($aid,$insertarray);
		}else{
            $insertarray['subjectimage']=$logo;
			$insertarray['dateline'] = TIMESTAMP;

            if($vipdata['is_album'] >0 && !$administrators){

                require_once 'source/plugin/aljht/include/aljbd/addalbum_send.php';
            }
			$insertid=C::t('#aljbd#aljbd_album')->insert($insertarray,true);
		}
        $sh_tips = $sh_tips ? $sh_tips : lang('plugin/aljbd','s53');
		echo "<script>parent.tips('".$sh_tips."','plugin.php?id=aljht&act=admin&op=album".$urlmod."');</script>";
		exit;
	}else{

        if($settings['is_attes']['value'] && !$settings['is_post_btn']['value']){
            $sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
            if(!$sign){
                $aljht_tips = lang("plugin/aljht","album_php_16");
                include template('aljht:admin/pogressbar');
                exit;
            }
        }
		$typelist=C::t('#aljbd#aljbd_type_consume')->fetch_all_by_upid(0);
		if($administrators){
			$bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','','');//����Ա
		}else{
			$bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','',$_G['uid']);//����
		}
		if($bid){
			$bd=C::t('#aljbd#aljbd')->fetch($bid);
		}
		include template('aljht:admin/album/addalbum');
	}
}else if($do == 'addalbumimg'){
	if($bid){
		$bd=C::t('#aljbd#aljbd')->fetch($bid);
		$bd = dhtmlspecialchars($bd);
	}
    if($_G['cache']['plugin']['aljbzj']['is_force_pay'] && $bzj_info['price'] <= 0 && $bid && file_exists("source/plugin/aljbzj/template/force_pay_tips.htm") && !$administrators){
        if(submitcheck('formhash')) {
            $post = 1;
            include template('aljbzj:force_pay_tips');
            exit;
        }
    }
	if(submitcheck('formhash')){
		if(empty($aid)){
			echo "<script>parent.tips('".lang('plugin/aljbd','album_2')."','');</script>";
			exit;
		}
		if($_GET['compress'] == '1'){
			if(!$_FILES['pic']['tmp_name']){
				echo "<script>parent.tips('".lang('plugin/aljbd','album_3')."','');</script>";
				exit;
			}
			if($_FILES['pic']['tmp_name']) {
				$picname = $_FILES['pic']['name'];
				$picsize = $_FILES['pic']['size'];
			
				if ($picname != "") {
					$type = strtolower(strrchr($picname, '.'));
					if ($type != ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
						echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
						exit;
					}
					if (($picsize/1024)>$_G['cache']['plugin']['aljbd']['img_size']) {
						echo "<script>parent.tips('".lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB'."','');</script>";
						exit;
					}
					$rand = rand(100, 999);
					$pics = date("YmdHis") . $rand . $type;
					
					$img_dir = $image_path."album/".date('Ymd',TIMESTAMP).'/';
					if (!is_dir($img_dir)) {
						mkdir($img_dir);
					}
					$pic1 = $img_dir. $pics;
					if(@copy($_FILES['pic']['tmp_name'], $pic1)||@move_uploaded_file($_FILES['pic']['tmp_name'], $pic1)){
						if($_G['cache']['plugin']['aljbd']['iswatermark']){
							$image->Watermark(DISCUZ_ROOT.'./'.$pic1,'', 'forum');
						}
						$imageinfo=getimagesize($pic1);
						
						@unlink($_FILES['pic']['tmp_name']);
					}
				}
			}
		}else{
			if(!$_GET['pic']){
				echo "<script>parent.tips('".lang('plugin/aljbd','album_2')."','');</script>";
				exit;
			}
			
			if ($_GET['pic']) {
				$rand = rand(100, 999);
				$pics = date("YmdHis") . $rand . '.jpg';
				$img_dir = $image_path."album/".date('Ymd',TIMESTAMP).'/';
				if (!is_dir($img_dir)) {
					mkdir($img_dir);
				}
				$$pic = $img_dir . $pics;
				
				$logo = file_put_contents($$pic,file_get_contents($_GET['pic']));
				
				if ($logo) {
					$imageinfo = getimagesize($$pic);
					if($_G['cache']['plugin']['aljbd']['iswatermark']){
						$image->Watermark(DISCUZ_ROOT.'./'.$pic1,'', 'forum');
					}
					
					@unlink($_FILES['pic']['tmp_name']);
				}
			}
			$pic1 = $$pic;
		}
		
		$apic=C::t('#aljbd#aljbd_album')->fetch($_GET['aid']);
		
		if(!$apic['subjectimage']){
			DB::query("UPDATE ".DB::table('aljbd_album')." SET subjectimage='".$pic1."' WHERE id='".$_GET['aid']."'", 'UNBUFFERED');
		}
		DB::query("UPDATE ".DB::table('aljbd_album')." SET picnum=picnum+1 WHERE id='".$_GET['aid']."'", 'UNBUFFERED');
		DB::query("UPDATE ".DB::table('aljbd_album')." SET lastpost=".$_G['timestamp']." WHERE id='".$_GET['aid']."'", 'UNBUFFERED');
		C::t('#aljbd#aljbd_album_attachments')->insert(array(
				'bid'=>$bid,
				'uid'=>$bd['uid'],
				'aid'=>$_GET['aid'],
				'pic'=>$pic1,
				'dateline'=>TIMESTAMP,
				'displayorder'=>'100',
				'alt'=>$_GET['alt'],
		));
		echo "<script>parent.tips('".lang('plugin/aljbd','s53')."','plugin.php?id=aljht&act=admin&op=album".$urlmod."');</script>";
		exit;
	}else{
		
		$alist=C::t('#aljbd#aljbd_album')->range();
		$alist = dhtmlspecialchars($alist);
		$num=C::t('#aljbd#aljbd_album_attachments')->count_by_uid_bid($bd['uid'],$_GET['aid']);
		
		if($num>=$_G['cache']['plugin']['aljbd']['albumnum']&&$_G['cache']['plugin']['aljbd']['albumnum']){
            $aljht_tips = lang('plugin/aljbd','album_4').$_G['cache']['plugin']['aljbd']['albumnum'].lang('plugin/aljbd','album_5');
            include template('aljht:admin/pogressbar');
            exit;
		}
		include template('aljht:admin/album/addalbumimg');
	}
}else if($do == 'cover'){
	$apic=C::t('#aljbd#aljbd_album_attachments')->fetch($_GET['atid']);
	DB::query("UPDATE ".DB::table('aljbd_album')." SET subjectimage='".$apic['pic']."' WHERE id='".$_GET['aid']."'", 'UNBUFFERED');
	echo '<script>parent.tips(0);</script>';
	exit;
}elseif($do == 'gallery'){
	if(submitcheck('formhash')){
		if($_GET['sign'] == 2){
			if(is_array($_GET['delete'])) {
				foreach($_GET['delete'] as $k => $id) {
                    $a_v=C::t('#aljbd#aljbd_album_attachments')->fetch($id);
					DB::query('delete from %t where id = %d',array('aljbd_album_attachments',$id));
					unlink($a_v['pic']);
					unset($a_v);
				}
			}
		}
		echo '<script>parent.tips(0);</script>';
		exit;
	}
	$a=C::t('#aljbd#aljbd_album')->range();
	$a = dhtmlspecialchars($a);
	$currpage=$_GET['page']?$_GET['page']:1;
	$perpage=20;
	$allpage=ceil($num/$perpage);
	$start=($currpage-1)*$perpage;
	$num=C::t('#aljbd#aljbd_album_attachments')->count_by_uid_bid('',$_GET['aid']);
	$bdlist=C::t('#aljbd#aljbd_album_attachments')->fetch_all_by_uid_bid('',$_GET['aid'],$start,$perpage);
	$bdlist = dhtmlspecialchars($bdlist);
	include template('aljht:admin/album/gallery');
}else{
    if($_G[mobile]){
        dheader("location: plugin.php?id=aljbd&act=albumlist");
        exit;
    }
	$keyword = addcslashes($_GET['search'], '%_');
	if(submitcheck('formhash') && empty($keyword)){
        if($administrators){
            if($_GET['sign'] == 2){
                if (is_array($_GET['delete'])) {
                    foreach ($_GET['delete'] as $k => $id) {
                        DB::update('aljbd_album_attachments', array('rubbish' => '1'), array('aid' => $id));
                        C::t('#aljbd#aljbd_album')->update($id, array('rubbish' => '1'));
                    }
                }
            }else if($_GET['sign'] == 6){
                if(is_array($_GET['delete'])) {
                    foreach($_GET['delete'] as $k => $id) {
                        DB::query('update %t set status=0  where id = %d',array('aljbd_album',$id));
                    }
                }
            }else if($_GET['sign'] == 7){
                if(is_array($_GET['delete'])) {
                    foreach($_GET['delete'] as $k => $id) {
                        DB::query('update %t set status=3  where id = %d',array('aljbd_album',$id));
                    }
                }
            }else if($_GET['sign'] == 1){
                $send_goods_tips = lang("plugin/aljht","album_php_17").'{shopname}'.lang("plugin/aljht","album_php_18").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=album&mod=my">'.lang("plugin/aljht","album_php_19").'</a>';
                if(is_array($_GET['delete'])) {
                    foreach($_GET['delete'] as $k => $id) {
                        DB::query('update %t set status=2,reason=%s  where id = %d',array('aljbd_album',$_GET['reason'][$id],$id));
                        $brand = C::t('#aljbd#aljbd_album')->fetch($id);
                        $reason = $_GET['reason'][$id] ? lang("plugin/aljht","album_php_20").$_GET['reason'][$id] : '';
                        notification_add($brand['uid'], 'system',str_replace(array('{shopname}','{reason}'),array($brand['albumname'],$reason),$send_goods_tips),array('from_idtype'  => 'aljbd_album','from_id' => $brand['id']));
                        unset($reason);
                    }
                }
            }else{
                if(is_array($_GET['delete'])) {
                    $send_goods_tips = lang("plugin/aljht","album_php_21").'{shopname}'.lang("plugin/aljht","album_php_22").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=album&mod=my">'.lang("plugin/aljht","album_php_23").'</a>';
                    foreach($_GET['delete'] as $k => $id) {
                        DB::query('update %t set status=0,reason=%s  where id = %d',array('aljbd_album',$_GET['reason'][$id],$id));
                        $brand = C::t('#aljbd#aljbd_album')->fetch($id);
                        $reason = $_GET['reason'][$id] ? lang("plugin/aljht","album_php_24").$_GET['reason'][$id] : '';
                        notification_add($brand['uid'], 'system',str_replace(array('{shopname}','{reason}'),array($brand['albumname'],$reason),$send_goods_tips),array('from_idtype'  => 'aljbd_album','from_id' => $brand['id']));
                        unset($reason);
                    }
                }
            }
        }else {
            if ($_GET['sign'] == 2) {
                if (is_array($_GET['delete'])) {
                    foreach ($_GET['delete'] as $k => $id) {
                        DB::update('aljbd_album_attachments', array('rubbish' => '1'), array('aid' => $id));
                        C::t('#aljbd#aljbd_album')->update($id, array('rubbish' => '1'));
                    }
                }
            }
        }
		echo '<script>parent.tips(0);</script>';
		exit;
	}

	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=20;
	$start=($currpage-1)*$perpage;
	$con[]='aljbd_album';
	if($administrators){
		$where=" where rubbish=0";
	}else{
		$where=" where rubbish=0 and uid = %d";
		$con[] = $_G['uid'];
	}
    if($_GET['bid']){
        $con[]=$_GET['bid'];
        $where.=' and bid=%d';
    }
	if($_GET['search']){
		$con[] ='%' . $keyword . '%';
		$where.=" and albumname like %s";
	}
    if($do == 'no'){
        $where.=' and status=1';
    }else if($do == 'lose'){
        $where.=' and status=2';
    }else if($do == 'close'){
        $where.=' and status=3';
    }else{
        $where.=' and status=0';
    }
	$num = DB::result_first('select count(*) from %t'.$where,$con);
	$con[]=$start;
	$con[]=$perpage;
	$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY id desc limit %d,%d',$con);
	$bdlist = dhtmlspecialchars($bdlist);
	include template('aljht:admin/album/album');
}
//From: Dism_taobao-com
?>