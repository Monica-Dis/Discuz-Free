<?php
if($_G['cache']['plugin']['aljbdx']){
	$addresstable = 'aljbdx';
	$rlist = C::t('#aljbdx#aljgwc_region')->fetch_all_by_upid();
    $regionlist=C::t('#aljbdx#aljgwc_region')->range();
}else{
	$alj_lang=lang('plugin/aljgwc');
    $rlist = C::t('#aljgwc#aljgwc_region')->fetch_all_by_upid();
    $regionlist=C::t('#aljgwc#aljgwc_region')->range();
    $addresstable = 'aljgwc';
}
$address = C::t('#'.$addresstable.'#aljbd_address')->fetch($address_id);
if($do == 'deladdress'){
	if($address['uid'] != $_G['uid'] && $_GET['formhash'] != FORMHASH && !$adminoparray){
		echo '0';
		exit;
	}
	C::t('#'.$addresstable.'#aljbd_address')->delete($address_id);
	echo '1';
	exit;
}elseif($do == 'updateaddress'){
	if($address['uid'] != $_G['uid'] && $_GET['formhash'] != FORMHASH){
		echo '0';
		exit;
	}
    DB::query('UPDATE %t SET defaultAddress=0 WHERE uid=%d', array('aljbd_address', $_G['uid']));
	DB::query("update %t set defaultAddress=1 where id = %d",array('aljbd_address',$address_id));
	echo '1';
	exit;
}else{

	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=20;
	$start=($currpage-1)*$perpage;
	$con[]='aljbd_address';
	$keyword = addcslashes($_GET['search'], '%_');
	$where = ' where 1 ';
	if($_GET['search']){
		$con[] ='%' . $keyword . '%';
		$where.=" and username like %s";
	}
	$num = DB::result_first('select count(*) from %t'.$where,$con);
	$con[]=$start;
	$con[]=$perpage;
	$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY id desc limit %d,%d',$con);
	
	$bdlist = dhtmlspecialchars($bdlist);
	$addrlist = $bdlist;
	$pagingurl = getaljurl($geturl,'');
    $paging = _mall_paging($currpage,$num,$perpage,$pagingurl.'&page=');
	$navtitle = $_G['cache']['plugin'][$pluginid]['title'];
	$metakeywords = $_G['cache']['plugin'][$pluginid]['keywords'];
	$metadescription = $_G['cache']['plugin'][$pluginid]['description'];
	include template('aljht:admin/listaddress/listaddress');
}
//From: Dism_taobao-com
?>