<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');
require_once 'source/language/lang_admincp.php';
//debug($scriptlang[$op]);
loadcache('pluginlanguage_script');
$scriptlang = $_G['cache']['pluginlanguage_script'];
$lang = array_merge($lang, $scriptlang[$op]);
if($ord == 'empty'){
    $sql='TRUNCATE TABLE '.DB::table('aljbd_region');
    DB::query($sql);
    savecache('aljbd_region', '');
    echo '<script>parent.tips(0);</script>';
    exit;
}else if($ord == 'importall'){

    if(C::t('#aljbd#aljbd_region')->count()){
        echo '<script>parent.tips("'.lang('plugin/aljbd','importtips').'");</script>';
        exit;
    }
    $level_3=DB::fetch_all('select * from %t where level<=3',array('common_district'));
    foreach($level_3 as $rid => $r){
        if($r['level']>3){
            break;
        }
        C::t('#aljbd#aljbd_region')->insert(array(
            'catid'=>$r['id'],
            'name'=>$r['name'],
            'upid'=>$r['upid'],
            'subcatid'=>$r['id'],
            'level'=>$r['level']-1,
        ));
    }
    savecache('aljbd_region', '');
    echo '<script>parent.tips(0);</script>';
    exit;
}else if($ord == 'import'){

    if(!submitcheck('formhash')){

        $rlist=C::t('#aljbd#aljbd_region')->fetch_all_by_upid_sys(0);
        foreach($rlist as $rid => $r){
            $str.='<option value="'.$r['id'].'" >'.$r['name'].'</option>';
        }
        $districthtml = '<select name="birthprovince" id="region"  class="form-control" data-id="1" onchange="getregion(this,\'u\')">
							<option value="">&#45;&#30465;&#20221;&#45;</option>
							'.$str.'
						</select>';
        $districthtml.='<span name="subregion" id="subregion"></span><span name="region1" id="region1"></span>';
        $html= '<iframe style="display:none;" name="submitiframe"></iframe>
                <form name="cpform" id="admingoodssubmit" method="post" autocomplete="off" action="'.$dourl.'&ord=import" target="submitiframe">
                <input type="hidden" name="formhash" value="'.FORMHASH.'">
                <div style="height:auto;width:530px;padding:30px">
                <h3 class="flb mn">'. lang('plugin/aljbd','region_import').'</h3>
                <div style="margin-left:10px;">'.$districthtml.'<p style="padding:10px; color:#3333CC; line-height:20px;">
                <ul id="tipslis">
                    <li>&#20351;&#29992;&#23548;&#20837;&#31995;&#32479;&#22320;&#21306;&#34920;&#30340;&#21151;&#33021;&#26102;&#65292;&#35831;&#20808;<a href="'.$dourl.'&ord=empty" target="submitiframe">&#28165;&#31354;&#25554;&#20214;&#22320;&#21306;&#34920;</a>&#20877;&#23548;&#20837;&#65292;&#36991;&#20813;&#23548;&#20837;&#37325;&#22797;&#22320;&#21306;</li>
                    <li>&#23548;&#20837;&#31995;&#32479;&#22320;&#21306;&#34920;&#21040;&#25554;&#20214;&#34920;&#26102;&#35831;&#36873;&#25321;&#19968;&#20010;&#30465;&#20221;&#23548;&#20837;&#65292;&#25554;&#20214;&#20250;&#25226;&#31995;&#32479;&#22320;&#21306;&#34920;&#20013;&#35813;&#30465;&#20221;&#23545;&#24212;&#30340;&#22478;&#12289;&#38215;&#12289;&#20065;&#23548;&#20837;&#21040;&#25554;&#20214;&#34920;&#65288;&#20197;&#27492;&#31867;&#25512;&#65289;</li>
                </ul></p>
                </div>
                <div class="form-group">
                <input type="submit" class="btn btn-submit btn-primary" value="&#25552;&#20132;">
                </div>
                </div>
                </form>';
        $tips = array('message'=>$html);
        echo json_encode(aljhtx::ajaxPostCharSet($tips));
        exit;
    }else{
        $regionarr = array();
        $regionarr['birthprovince'] = dhtmlspecialchars(trim($_GET['birthprovince']));
        if(!$regionarr['birthprovince']){
            echo '<script>parent.tips('.lang('plugin/aljbd','Please_select_a_province').');</script>';
            exit;
        }
        $regionarr['subregion'] = dhtmlspecialchars(trim($_GET['subregion']));
        $regionarr['region1'] = dhtmlspecialchars(trim($_GET['region1']));
        $regionarr['birthcommunity'] = dhtmlspecialchars(trim($_GET['birthcommunity']));
        $upid = 0;
        if ($regionarr['birthprovince']) {
            $upid = $regionarr['birthprovince'];
            if ($regionarr['subregion']) {
                $upid = $regionarr['subregion'];
                if($regionarr['region1']){
                    $upid = $regionarr['region1'];
                }
            }
        }
        if(!$upid){
            echo '<script>parent.tips('.lang('plugin/aljbd','Please_select_a_province').');</script>';
            exit;
        }
        foreach(C::t('#aljbd#aljbd_region')->fetch_all_by_upid_sys($upid) as $data) {
            $insertarray=array('name'=>$data['name'],'upid'=>'');
            $insertid=C::t('#aljbd#aljbd_region')->insert($insertarray,true);
            DB::update('aljbd_region', array('subcatid'=>$insertid), "catid='$insertid'");
            if(C::t('#aljbd#aljbd_region')->fetch_all_by_upid_sys($data['id'])){
                foreach(C::t('#aljbd#aljbd_region')->fetch_all_by_upid_sys($data['id']) as $data_1) {

                    $insertarray=array('name'=>$data_1['name'],'upid'=>$insertid);
                    $insertid_1=C::t('#aljbd#aljbd_region')->insert($insertarray,true);
                    DB::update('aljbd_region', array('subcatid'=>$insertid_1), "catid='$insertid_1'");
                    $region=C::t('#aljbd#aljbd_region')->fetch($insertid);
                    $region['subcatid']=trim(($region['subcatid'].','.$insertid_1),',');
                    $level=$region['level']+1;
                    $region['havechild']=1;
                    C::t('#aljbd#aljbd_region')->update($region['catid'],$region);
                    DB::update('aljbd_region', array('level'=>$level), "catid='$insertid_1'");
                    if(C::t('#aljbd#aljbd_region')->fetch_all_by_upid_sys($data_1['id'])){
                        foreach(C::t('#aljbd#aljbd_region')->fetch_all_by_upid_sys($data_1['id']) as $data_2) {
                            $insertarray=array('name'=>$data_2['name'],'upid'=>$insertid_1);
                            $insertid_2=C::t('#aljbd#aljbd_region')->insert($insertarray,true);
                            DB::update('aljbd_region', array('subcatid'=>$insertid_2), "catid='$insertid_2'");
                            $region_1=C::t('#aljbd#aljbd_region')->fetch($insertid_1);
                            $region_1['subcatid']=trim(($region_1['subcatid'].','.$insertid_2),',');

                            $level_1=$region_1['level']+1;
                            $region_1['havechild']=1;
                            C::t('#aljbd#aljbd_region')->update($region_1['catid'],$region_1);
                            DB::update('aljbd_region', array('level'=>$level_1), "catid='$insertid_2'");
                        }
                    }
                }
            }
        }
        savecache('aljbd_region', '');
        echo '<script>parent.tips(0);</script>';
        exit;
    }
}else{
    if(!submitcheck('formhash')){
        if($_GET['upid']){
            $upid_data=C::t('#aljbd#aljbd_region')->fetch($_GET['upid']);

        }
        $currpage=$_GET['page']?$_GET['page']:1;
        $perpage=20;
        $num=C::t('#aljbd#aljbd_region')->count_by_upid($_GET['upid']);
        $start=($currpage-1)*$perpage;
        $region=C::t('#aljbd#aljbd_region')->fetch_all_by_upid($start,$perpage,$_GET['upid']);
        $url = $dourl.'&page=';
        $type_paging=_mall_paging($currpage,$num,$perpage,$url);
        include template($pluginid.':admin/'.$op.'/'.$do);
    }else{

        if($_GET['delete']){
            foreach($_GET['delete'] as $key=>$value){
                C::t('#aljbd#aljbd_region')->delete($value);
            }
        }else if($_GET['name']){
            foreach($_GET['name'] as $key=>$value){
                C::t('#aljbd#aljbd_region')->update($key,array('name'=>$value));
            }
            if($_GET['displayorder']){
                foreach($_GET['displayorder'] as $key=>$value){
                    C::t('#aljbd#aljbd_region')->update($key,array('displayorder'=>$value));
                }
            }
        }
        foreach($_GET['newregion'] as $key=>$value){
            if($value){
                $insertarray=array('name'=>$value,'upid'=>$_GET['upid'],'displayorder'=>$_GET['newdisplayorder'][$key]);
                $insertid=C::t('#aljbd#aljbd_region')->insert($insertarray,true);
                DB::update('aljbd_region', array('subcatid'=>$insertid), "catid='$insertid'");
                if($_GET['upid']){
                    $region=C::t('#aljbd#aljbd_region')->fetch($_GET['upid']);
                    $region['subcatid']=trim(($region['subcatid'].','.$insertid),',');
                    $level=$region['level']+1;
                    $region['havechild']=1;
                    C::t('#aljbd#aljbd_region')->update($region['catid'],$region);
                    DB::update('aljbd_region', array('level'=>$level), "catid='$insertid'");
                }
            }
        }
        savecache('aljbd_region', '');
        echo '<script>parent.tips(0);</script>';
        exit;
    }
}
//dis'.'m.t'.'ao'.'bao.com
?>