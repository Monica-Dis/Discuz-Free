<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');

require_once 'source/language/lang_admincp.php';
//debug($scriptlang[$op]);
loadcache('pluginlanguage_script');
$scriptlang = $_G['cache']['pluginlanguage_script'];
$lang = array_merge($lang, $scriptlang[$op]);
if(!submitcheck('formhash')) {
    $aljbd_seo = dunserialize($_G['setting']['aljbd_seo']);
    $page = array(
        'index' => array('bbname'),
        'list' => array('bbname', 'cat','cat2','cat3','region','region2','region3'),
        'view' => array('bbname', 'subject', 'message', 'cat','cat2','cat3','region','region2','region3','view_keyword'),
        'good_list' => array('bbname','cat','cat2','cat3'),
        'brand_good_list' => array('bbname', 'bdname','cat','cat2','cat3'),
        'good_view' => array('bbname', 'subject', 'message','bdname','price'),
        'notice_list' => array('bbname', 'cat'),
        'brand_notice_list' => array('bbname', 'bdname'),
        'notice_view' => array('bbname', 'subject', 'message','bdname'),
        'consume_list' => array('bbname', 'cat'),
        'brand_consume_list' => array('bbname', 'bdname'),
        'consume_view' => array('bbname', 'subject', 'message','bdname'),
        'brand_album_list' => array('bbname', 'bdname'),
        'album_view' => array('bbname', 'subject','bdname'),
        'map_index' => array('bbname'),
    );
    include template($pluginid.':admin/'.$op.'/'.$do);
} else {

    $aljbd_seo = serialize($_GET['aljbd_seo']);
    DB::query("REPLACE INTO ".DB::table('common_setting')." (skey, svalue) VALUES ('aljbd_seo', '$aljbd_seo')");
    require_once libfile('function/cache');
    updatecache('setting');

    echo '<script>parent.tips(0);</script>';
    exit;
}
//dis'.'m.t'.'ao'.'bao.com
?>