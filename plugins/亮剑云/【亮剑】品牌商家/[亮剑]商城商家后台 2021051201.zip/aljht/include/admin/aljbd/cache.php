<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');
$config = $_G['cache']['plugin'][$op];
require_once libfile('class/xml');
$table='aljbd_syscache';
$lj_plugin = DB::fetch_first("SELECT * FROM ".DB::table('common_plugin')." WHERE identifier='".$op."'");
$lj_dir = substr($lj_plugin['directory'], 0, -1);
$lj_modules = unserialize($lj_plugin['modules']);
require_once libfile('function/cache');
if($_GET['cache']=='p_s'){
    if(!submitcheck('formhash')) {
        $cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_template'");
        $data=unserialize($cache);

        //ģ��ԭʼ����  ���ڻָ�ԭʼ����
        if(!C::t('#'.$op.'#'.$table)->fetch_count('4')||C::t('#'.$op.'#'.$table)->fetch_count('4')<count($data[$op])){

            foreach($data[$op] as $k=>$s){
                if(!C::t('#'.$op.'#'.$table)->fetch_count_sign($k,'4')){
                    C::t('#'.$op.'#'.$table)->insert(array(
                        'plugin_b'=>$k,
                        'plugin_w'=>$s,
                        'plugin_sign'=>'4',
                    ));
                }
            }
        }
        //ģ�嶯̬����  ���ڻָ��޸�����
        if(!C::t('#'.$op.'#'.$table)->fetch_count('6')||C::t('#'.$op.'#'.$table)->fetch_count('6')<count($data[$op])){

            foreach($data[$op] as $k=>$s){
                if(!C::t('#'.$op.'#'.$table)->fetch_count_sign($k,'6')){
                    C::t('#'.$op.'#'.$table)->insert(array(
                        'plugin_b'=>$k,
                        'plugin_w'=>$s,
                        'plugin_sign'=>'6',
                    ));
                }
            }
        }
        $plugin_bw_3=C::t('#'.$op.'#'.$table)->fetch_all_by_sign('4');
        $plugin_bw_3=dhtmlspecialchars($plugin_bw_3);
        foreach($plugin_bw_3 as $ss){
            $lang_qian[$ss['plugin_b']]=$ss['plugin_w'];
        }
        $plugin_bw=$data[$op];
        include template($pluginid.':admin/'.$op.'/'.$do);
    }else{
        if(!$_GET['delete']){
            echo '<script>parent.tips("&#35831;&#25171;&#21246;&#35201;&#20462;&#25913;&#30340;&#35821;&#35328;&#21253;&#21518;&#20877;&#25552;&#20132;");</script>';
            exit;
        }
        if(is_array($_GET['delete'])){
            foreach($_GET['delete'] as $b){
                if($b){

                    DB::update($table,array('plugin_w'=>$_GET['plugin_all'][$b]),array('plugin_b'=>$b,'plugin_sign'=>'6'));
                    $plugin_data[$b] = $_GET['plugin_all'][$b];
                }
            }
            $cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_template'");
            $data=unserialize($cache);
            $result = array_merge($data[$op], $plugin_data);
            $data[$op]=$result;
            savecache('pluginlanguage_template', $data);
            cleartemplatecache();
            $file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';
            //debug($file);
            if(file_exists($file)) {
                $importtxt = @implode('', file($file));
                $data = $GLOBALS['importtxt'];
                //debug($GLOBALS);
                $xmldata = xml2array($data);
                $xmldata['Data']['language']['templatelang']=$_GET['plugin_all'];
                //debug($xmldata);
                $handle=fopen($file,"w");
                if(!$handle){
                    //cpmsg(lang('plugin/'.$op.'','daka28'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache&cache=p_s', 'error');
                    echo '<script>parent.tips(0);</script>';
                    exit;
                }
                if(fwrite($handle,array2xml($xmldata,1))){
                    fclose($handle);
                    updatecache(array('plugin'));
                    cleartemplatecache();
                    //cpmsg(lang('plugin/'.$op.'','daka29'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache&cache=p_s', 'succeed');
                    echo '<script>parent.tips(0);</script>';
                    exit;
                }
                fclose($handle);
                //cpmsg(lang('plugin/'.$op.'','daka28'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache&cache=p_s', 'error');
                echo '<script>parent.tips(0);</script>';
                exit;
            }
        }
        //cpmsg(lang('plugin/'.$op.'','daka21'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache&cache=p_s');
        echo '<script>parent.tips(0);</script>';
        exit;
    }
}else if($_GET['cache']=='gl'){
    include template($pluginid.':admin/'.$op.'/'.$do);
}else if($_GET['cache']=='geshihua3'){//��ʼ���ű�
    if($_GET['formhash']==formhash()){
        $plugin_bw=C::t('#'.$op.'#'.$table)->fetch_all_by_sign('3');
        foreach($plugin_bw as $w){
            $plugin_data[$w['plugin_b']]=$w['plugin_w'];
        }

        $cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_script'");
        $data=unserialize($cache);
        $result = array_merge($data[$op], $plugin_data);

        $data[$op]=$result;
        savecache('pluginlanguage_script', $data);
        cleartemplatecache();
        $file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';
        //debug($file);
        if(file_exists($file)) {
            $importtxt = @implode('', file($file));
            $data = $GLOBALS['importtxt'];
            //debug($GLOBALS);
            $xmldata = xml2array($data);
            $xmldata['Data']['language']['scriptlang']=$result;
            //debug($xmldata);
            $handle=fopen($file,"w");
            if(!$handle){
                //cpmsg(lang('plugin/'.$op.'','daka31'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache', 'error');
                echo '<script>parent.tips(0);</script>';
                exit;
            }
            if(fwrite($handle,array2xml($xmldata,1))){
                fclose($handle);
                updatecache(array('plugin'));
                cleartemplatecache();
                //cpmsg(lang('plugin/'.$op.'','daka32'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache', 'succeed');
                echo '<script>parent.tips(0);</script>';
                exit;
            }
            fclose($handle);
            //cpmsg(lang('plugin/'.$op.'','daka31'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache', 'error');
            echo '<script>parent.tips(0);</script>';
            exit;
        }
        //cpmsg(lang('plugin/'.$op.'','daka41'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache');
        echo '<script>parent.tips(0);</script>';
        exit;
    }

}else if($_GET['cache']=='geshihua4'){//��ʼ��ģ��
    if($_GET['formhash']==formhash()){
        $plugin_bw=C::t('#'.$op.'#'.$table)->fetch_all_by_sign('4');
        foreach($plugin_bw as $w){

            $plugin_data[$w['plugin_b']]=$w['plugin_w'];
        }
        $cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_template'");
        $data=unserialize($cache);
        $result = array_merge($data[$op], $plugin_data);

        $data[$op]=$result;
        savecache('pluginlanguage_template', $data);
        cleartemplatecache();
        $file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';
        //debug($file);
        if(file_exists($file)) {
            $importtxt = @implode('', file($file));
            $data = $GLOBALS['importtxt'];
            //debug($GLOBALS);
            $xmldata = xml2array($data);
            $xmldata['Data']['language']['templatelang']=$result;
            //debug($xmldata);
            $handle=fopen($file,"w");
            if(!$handle){
                //cpmsg(lang('plugin/'.$op.'','daka35'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache&cache=p_s', 'error');
                echo '<script>parent.tips(0);</script>';
                exit;
            }
            if(fwrite($handle,array2xml($xmldata,1))){
                fclose($handle);
                updatecache(array('plugin'));
                cleartemplatecache();
                //cpmsg(lang('plugin/'.$op.'','daka36'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache&cache=p_s', 'succeed');
                echo '<script>parent.tips(0);</script>';
                exit;
            }
            fclose($handle);
            //cpmsg(lang('plugin/'.$op.'','daka35'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache&cache=p_s', 'error');
            echo '<script>parent.tips(0);</script>';
            exit;
        }
        //cpmsg(lang('plugin/'.$op.'','daka41'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache&cache=p_s');
        echo '<script>parent.tips(0);</script>';
        exit;
    }
}else if($_GET['cache']=='huifu5'){//�ָ��ű�
    if($_GET['formhash']==formhash()){
        $plugin_bw=C::t('#'.$op.'#'.$table)->fetch_all_by_sign('5');
        foreach($plugin_bw as $w){
            $plugin_data[$w['plugin_b']]=$w['plugin_w'];
        }
        $cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_script'");
        $data=unserialize($cache);
        $result = array_merge($data[$op], $plugin_data);

        $data[$op]=$result;
        savecache('pluginlanguage_script', $data);
        cleartemplatecache();
        $file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';
        //debug($file);
        if(file_exists($file)) {
            $importtxt = @implode('', file($file));
            $data = $GLOBALS['importtxt'];
            //debug($GLOBALS);
            $xmldata = xml2array($data);
            $xmldata['Data']['language']['scriptlang']=$result;
            //debug($xmldata);
            $handle=fopen($file,"w");
            if(!$handle){
                //cpmsg(lang('plugin/'.$op.'','daka39'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache', 'error');
                echo '<script>parent.tips(0);</script>';
                exit;
            }
            if(fwrite($handle,array2xml($xmldata,1))){
                fclose($handle);
                updatecache(array('plugin'));
                cleartemplatecache();
                //cpmsg(lang('plugin/'.$op.'','daka40'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache', 'succeed');
                echo '<script>parent.tips(0);</script>';
                exit;
            }
            fclose($handle);
            //cpmsg(lang('plugin/'.$op.'','daka39'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache', 'error');
            echo '<script>parent.tips(0);</script>';
            exit;
        }
        //cpmsg(lang('plugin/'.$op.'','daka42'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache');
        echo '<script>parent.tips(0);</script>';
        exit;
    }
}else if($_GET['cache']=='huifu6'){//�ָ�ģ��
    if($_GET['formhash']==formhash()){
        $plugin_bw=C::t('#'.$op.'#'.$table)->fetch_all_by_sign('6');
        foreach($plugin_bw as $w){
            $plugin_data[$w['plugin_b']]=$w['plugin_w'];
        }
        $cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_template'");
        $data=unserialize($cache);
        //debug($data);
        $result = array_merge($data[$op], $plugin_data);

        $data[$op]=$result;

        savecache('pluginlanguage_template', $data);
        cleartemplatecache();
        $file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';
        //debug($file);
        if(file_exists($file)) {
            $importtxt = @implode('', file($file));
            $data = $GLOBALS['importtxt'];
            //debug($GLOBALS);
            $xmldata = xml2array($data);
            $xmldata['Data']['language']['templatelang']=$result;
            //debug($xmldata);
            $handle=fopen($file,"w");
            if(!$handle){
                //cpmsg(lang('plugin/'.$op.'','daka37'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache&cache=p_s', 'error');
                echo '<script>parent.tips(0);</script>';
                exit;
            }
            if(fwrite($handle,array2xml($xmldata,1))){
                fclose($handle);
                updatecache(array('plugin'));
                cleartemplatecache();
                //cpmsg(lang('plugin/'.$op.'','daka38'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache&cache=p_s', 'succeed');
                echo '<script>parent.tips(0);</script>';
                exit;
            }
            fclose($handle);
            //cpmsg(lang('plugin/'.$op.'','daka37'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache&cache=p_s', 'error');
            echo '<script>parent.tips(0);</script>';
            exit;
        }
        //cpmsg(lang('plugin/'.$op.'','daka42'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache&cache=p_s');
        echo '<script>parent.tips(0);</script>';
        exit;
    }
}else{
    if(!submitcheck('formhash')) {
        $cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_script'");
        $data=unserialize($cache);
        //�ű�ԭʼ����  ���ڻָ�ԭʼ����
        if(!C::t('#'.$op.'#'.$table)->fetch_count('3')||C::t('#'.$op.'#'.$table)->fetch_count('3')<count($data[$op])){

            foreach($data[$op] as $k=>$s){
                if(!C::t('#'.$op.'#'.$table)->fetch_count_sign($k,'3')){
                    C::t('#'.$op.'#'.$table)->insert(array(
                        'plugin_b'=>$k,
                        'plugin_w'=>$s,
                        'plugin_sign'=>'3',
                    ));
                }
            }
        }
        //�ű���̬���� ���ڻָ��޸ĺ������
        if(!C::t('#'.$op.'#'.$table)->fetch_count('5')||C::t('#'.$op.'#'.$table)->fetch_count('5')<count($data[$op])){

            foreach($data[$op] as $k=>$s){
                if(!C::t('#'.$op.'#'.$table)->fetch_count_sign($k,'5')){
                    C::t('#'.$op.'#'.$table)->insert(array(
                        'plugin_b'=>$k,
                        'plugin_w'=>$s,
                        'plugin_sign'=>'5',
                    ));
                }
            }
        }

        $plugin_bw_3=C::t('#'.$op.'#'.$table)->fetch_all_by_sign('3');
        $plugin_bw_3=dhtmlspecialchars($plugin_bw_3);
        foreach($plugin_bw_3 as $ss){
            $lang_qian[$ss['plugin_b']]=$ss['plugin_w'];
        }

        $plugin_bw=$data[$op];
        //debug($plugin_bw_3);

        include template($pluginid.':admin/'.$op.'/'.$do);
    }else{
        if(!$_GET['delete']){
            echo '<script>parent.tips("&#35831;&#25171;&#21246;&#35201;&#20462;&#25913;&#30340;&#35821;&#35328;&#21253;&#21518;&#20877;&#25552;&#20132;");</script>';
            exit;
        }
        if(is_array($_GET['delete'])){
            foreach($_GET['delete'] as $b){
                if($b){
                    DB::update($table,array('plugin_w'=>$_GET['plugin_all'][$b]),array('plugin_b'=>$b,'plugin_sign'=>'5'));
                    $plugin_data[$b] = $_GET['plugin_all'][$b];
                }
            }
            $cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_script'");
            $data=unserialize($cache);
            $result = array_merge($data[$op], $plugin_data);
            $data[$op]=$result;
            //debug($data[$op]);
            savecache('pluginlanguage_script', $data);
            cleartemplatecache();
            $file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';

            if(file_exists($file)) {
                $importtxt = @implode('', file($file));
                $data = $GLOBALS['importtxt'];
                //debug($GLOBALS);
                $xmldata = xml2array($data);
                $xmldata['Data']['language']['scriptlang']=$_GET['plugin_all'];
                //debug($xmldata);
                $handle=fopen($file,"w");
                if(!$handle){
                    //cpmsg(lang('plugin/'.$op.'','daka33'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache', 'error');
                    echo '<script>parent.tips(0);</script>';
                    exit;
                }
                if(fwrite($handle,array2xml($xmldata,1))){
                    fclose($handle);
                    updatecache(array('plugin'));
                    cleartemplatecache();
                    //cpmsg(lang('plugin/'.$op.'','daka34'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache', 'succeed');
                    echo '<script>parent.tips(0);</script>';
                    exit;
                }
                fclose($handle);
                //cpmsg(lang('plugin/'.$op.'','daka33'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache', 'error');
                echo '<script>parent.tips(0);</script>';
                exit;
            }
        }
        //cpmsg(lang('plugin/'.$op.'','daka21'),'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$op.'&pmod=cache');
        echo '<script>parent.tips(0);</script>';
        exit;
    }
}
//From: Dism_taobao-com
?>