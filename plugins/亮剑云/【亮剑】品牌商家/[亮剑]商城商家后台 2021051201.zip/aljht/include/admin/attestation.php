<?php

if($do == 'delete'){
    if($_GET['bid']){
        $bdlist=C::t('#aljbd#aljbd_attestation')->fetch($_GET['bid']);
    }
    if(submitcheck('formhash')){
        if($bdlist['uid']!=$_G['uid'] && !$administrators){
            echo 0;
            exit;
        }

        if($_GET['bid']){
            DB::query('delete from %t where bid = %d',array('aljbd_attestation',$_GET['bid']));
        }

        echo 1;
        exit;
    }else{
        echo 0;
        exit;
    }
}else if($do == 'sh_status'){
    if($_GET['formhash'] == FORMHASH) {
        if(!$administrators){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","attestation_php_3"))));
            exit;
        }
        if(!$_GET[cashid]){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","attestation_php_4"))));
            exit;
        }

        $goods = C::t('#aljbd#aljbd_attestation')->fetch($_GET[cashid]);
        $bd = C::t('#aljbd#aljbd')->fetch($_GET[cashid]);
        if(!$goods){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","attestation_php_5"))));
            exit;
        }

        if(strtolower(CHARSET) == 'gbk' && !$_G[mobile] && $_GET[message]){
            $_GET[message] = diconv($_GET[message],'utf-8','gbk');
        }

        if(DB::query('update %t set sign=%d,reason=%s  where bid = %d and sign = %d',array('aljbd_attestation',$_GET[status],$_GET[message],$_GET[cashid],$goods['sign']))){
            if($_GET[status] == 2){
                $send_goods_tips = lang("plugin/aljht","attestation_php_6").'{shopname}'.lang("plugin/aljht","attestation_php_7").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=attestation&mod=my">'.lang("plugin/aljht","attestation_php_8").'</a>';
            }else{
                $send_goods_tips = lang("plugin/aljht","attestation_php_9").'{shopname}'.lang("plugin/aljht","attestation_php_10").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=attestation&mod=my">'.lang("plugin/aljht","attestation_php_11").'</a>';
            }
            $reason = $_GET[message] ? lang("plugin/aljht","attestation_php_12").$_GET[message] : '';
            notification_add(
                $bd['uid'],
                'system',str_replace(array('{shopname}','{reason}'),array($bd['name'],$reason), $send_goods_tips),
                array('from_idtype'  => 'aljbd_attestation','from_id' => $bd['id'])
            );
            echo json_encode(T::ajaxPostCharSet(array('code'=>1,'text'=>lang("plugin/aljht","attestation_php_13"))));
            exit;
        }else{
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","attestation_php_14"))));
            exit;
        }
    }else{
        echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","attestation_php_15"))));
        exit;
    }
}else if($do == 'editattestation' || $do == 'addattestation'){
	$attestation = C::t('#aljbd#aljbd_attestation') -> fetch($bid);
	$bd=C::t('#aljbd#aljbd')->fetch($bid);
	if(submitcheck('formhash')){
		
		if(!$_GET['name']) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_2')."','');</script>";
				exit;
			}else{
				echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_2')."','');</script>";
				exit;
			}
		}
		if(!$_GET['id_card']) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljbd','attestation_2')."','');</script>";
				exit;
			}else{
				echo "<script>parent.tips('".lang('plugin/aljbd','attestation_2')."','');</script>";
				exit;
			}
		}
		if(!$_GET['qiyename']) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljbd','attestation_3')."','');</script>";
				exit;
			}else{
				echo "<script>parent.tips('".lang('plugin/aljbd','attestation_3')."','');</script>";
				exit;
			}
		}
		if(!$_GET['email']) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljbd','attestation_4')."','');</script>";
				exit;
			}else{
				echo "<script>parent.tips('".lang('plugin/aljbd','attestation_4')."','');</script>";
				exit;
			}
		}
		if(!$_GET['tel']) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljbd','attestation_5')."','');</script>";
				exit;
			}else{
				echo "<script>parent.tips('".lang('plugin/aljbd','attestation_5')."','');</script>";
				exit;
			}
		}
		
		$insertarray = array(
			'uid' => $bd['uid'],
			'username' => $bd['username'],
			'name' => $_GET['name'],
			'id_card' => $_GET['id_card'],
			'qiyename' => $_GET['qiyename'],
			'email' => $_GET['email'],
			'tel' => $_GET['tel'],
			'jieshao' => $_GET['jieshao'],
			'bid' => $_GET['bid'],
			'timestamp' => TIMESTAMP,
		);
		
		
		$idpicarray = array('1'=>'id_pic','2'=>'ban_pic','3'=>'id_pic1','4'=>'pic');
		for ($i = 1; $i <= 4; $i++) {
			
			$pic1 = $idpicarray[$i];
			
			if ($_GET[$pic1]) {
				$rand = rand(100, 999);
				$pics = date("YmdHis") . $rand . '.jpg';
				$img_dir = $image_path.'logo/'.date('Ymd',TIMESTAMP).'/';
				if (!is_dir($img_dir)) {
					mkdir($img_dir);
				}
				
				$$pic1 = $img_dir . $pics;
				
				$logo = file_put_contents($$pic1,file_get_contents($_GET[$pic1]));
				
				if ($logo) {
					$imageinfo = getimagesize($$pic1);
					if($_G['cache']['plugin']['aljbd']['iswatermark']){
						$image->Watermark(DISCUZ_ROOT.'./'.$$pic1,'', 'forum');
					}
				}
			}
		}
		
		for ($i = 1; $i <= 4; $i++) {
			$pic1 = $idpicarray[$i];
			if ($$pic1) {
				$insertarray[$pic1] = $$pic1;
			}
		}
        if($_G['cache']['plugin']['aljbzj']['is_aljbzj']){
            $insertarray['business_license_id'] = $_GET['business_license_id'];
            $insertarray['license_comp_adress'] = str_replace('/',' ',$_GET['license_comp_adress']);
            $insertarray['license_adress'] = $_GET['license_adress'];
            $insertarray['registered_capital'] = $_GET['registered_capital'];
            $insertarray['company_located'] = str_replace('/',' ',$_GET['company_located']);
            $insertarray['company_adress'] = $_GET['company_adress'];
        }
        if($_G['cache']['plugin']['aljrz']['is_file']){
            $insertarray['fujian'] = $_GET['fujian'];
        }
		if(!$administrators){
			foreach(DB::fetch_all('select uid from '.DB::table('common_member').' where groupid =1') as $u){
				notification_add($u['uid'], 'system','<a href="plugin.php?id=aljhtx&c=aljbd&a=order&type=5&frames=yes&do=no&twok=3" target="_blank">'.lang('plugin/aljbd','attestation_6').'</a>',array('from_idtype'  => 'aljbd_attestation','from_id' => $bd['id']));
			}
		}
		if(!$attestation){
            $return_url = 'plugin.php?id=aljht&act=admin&op=brand'.$urlmod;
            if($settings['post_brand_type']['value'] == 2 && $_G['cache']['plugin']['aljbzj']['is_aljbzj'] && $_G['cache']['plugin']['aljbzj']['bzj_price']>0){
                $return_url .=  '&bzj=yes&bid='.$_GET['bid'];
            }
			if($administrators){

				$insertarray['sign'] = 1;
                $return_url = "plugin.php?id=aljht&act=admin&op=attestation".$urlmod;
			}
			C::t('#aljbd#aljbd_attestation')->insert($insertarray);

			echo "<script>parent.tips('".lang("plugin/aljht","attestation_php_1")."','".$return_url."');</script>";
			exit;
		}else{
			if(!$administrators){
				$insertarray['sign'] = 0;
            }
            
			C::t('#aljbd#aljbd_attestation')->update($bid, $insertarray);
			if($administrators){
                $return_url = "plugin.php?id=aljht&act=admin&op=attestation".$urlmod;
            }else{
                $return_url = 'plugin.php?id=aljht&act=admin&op=brand'.$urlmod;
            }

			echo "<script>parent.tips('".lang("plugin/aljht","attestation_php_2")."','".$return_url."');</script>";
			exit;
		}
	}else{
		//debug($bd['uid']);
		if($bd['uid']!=$_G['uid'] && !$administrators && !$settings['is_post_btn']['value']){
            $aljht_tips = lang('plugin/aljbd','aljbd_7');
            include template('aljht:admin/pogressbar');
			exit;
		}
		//$bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','','');
        if($administrators){
            $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','','');//����Ա
        }else{
            $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','',$_G['uid']);//����
        }
        if($bdlist && $do == 'addattestation' && !$attestation){
            $attesarray = array();
            foreach ($bdlist as $bkey => $bval){
                if(!DB::result_first("select sign from ".DB::table('aljbd_attestation')." where sign=1 and bid=".$bval['id'])){
                    $attesarray[$bval['id']] = $bval;
                }
            }
            $bdlist = $attesarray;
        }

		include template('aljht:admin/attestation/addattestation');
	}
}else{
	$keyword = addcslashes($_GET['search'], '%_');
	if(submitcheck('formhash') && empty($keyword)){
		
		if($_GET['sign'] == 2){
			if(is_array($_GET['delete'])) {
				foreach($_GET['delete'] as $k => $id) {
					DB::query('delete from %t where bid = %d',array('aljbd_attestation',$id));
				}
			}
		}else if($_GET['sign'] == 1){
            if(is_array($_GET['delete'])) {
                $send_goods_tips = lang("plugin/aljht","attestation_php_16").'{shopname}'.lang("plugin/aljht","attestation_php_17").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=attestation&mod=my">'.lang("plugin/aljht","attestation_php_18").'</a>';
                foreach($_GET['delete'] as $k => $id) {
                    DB::query('update %t set sign=2,reason=%s  where bid = %d',array('aljbd_attestation',$_GET['reason'][$id],$id));
                    $brand = C::t('#aljbd#aljbd')->fetch($id);
                    $reason = $_GET['reason'][$id] ? lang("plugin/aljht","attestation_php_19").$_GET['reason'][$id] : '';
                    notification_add($brand['uid'], 'system',str_replace(array('{shopname}','{reason}'),array($brand['name'],$reason),$send_goods_tips),array('from_idtype'  => 'aljbd_attestation','from_id' => $brand['id']));
                    unset($reason);
                }
            }
        }else{
			if(is_array($_GET['delete'])) {
                $send_goods_tips = lang("plugin/aljht","attestation_php_20").'{shopname}'.lang("plugin/aljht","attestation_php_21").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=attestation&mod=my">'.lang("plugin/aljht","attestation_php_22").'</a>';
				foreach($_GET['delete'] as $k => $id) {
					DB::query('update %t set sign=1,reason=%s  where bid = %d',array('aljbd_attestation',$_GET['reason'][$id],$id));
                    $brand = C::t('#aljbd#aljbd')->fetch($id);
                    $reason = $_GET['reason'][$id] ? lang("plugin/aljht","attestation_php_23").$_GET['reason'][$id] : '';
                    notification_add($brand['uid'], 'system',str_replace(array('{shopname}','{reason}'),array($brand['name'],$reason),$send_goods_tips),array('from_idtype'  => 'aljbd_attestation','from_id' => $brand['id']));
                    unset($reason);
				}
			}
		}
		echo '<script>parent.tips(0);</script>';
		exit;
	}

	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	$con[]='aljbd_attestation';
	if($administrators){
		$where=" where 1";
	}else{
		$where=" where uid = %d";
		$con[] = $_G['uid'];
	}
	if($_GET['search']){
		$con[] ='%' . $keyword . '%';
		$where.=" and name like %s";
	}
    if($do == 'ajax') {
        if($_GET['status'] == '1'){
            $where.=' and sign=1';
        }else if($_GET['status'] == '2'){
            $where.=' and sign=2';
        }else{
            $where.=' and sign=0';
        }
    }else{
        if($do == 'no'){
            $where.=' and sign=0';
        }else if($do == 'lose'){
            $where.=' and sign=2';
        }else{
            $where.=' and sign=1';
        }
    }

	$num = DB::result_first('select count(*) from %t'.$where,$con);
	$con[]=$start;
	$con[]=$perpage;
    $bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY timestamp desc limit %d,%d',$con);
    $bdlist = dhtmlspecialchars($bdlist);
    foreach($bdlist as $k=>$v){
        $bdlist[$k]['bdinfo']=C::t('#aljbd#aljbd')->fetch($v['bid']);
        if($v['sign'] == 1){
            $bdlist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_3');
        }else if($v['sign'] == 2){
            $bdlist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_2');
        }else{
            $bdlist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_1');
        }
    }
    if($administrators){
        $sh_status = 0;
    }else{
        $sh_status = 1;
    }
    $navtitle = lang("plugin/aljht","attestation_php_24");
    $metakeywords = $bd['other'] ? $bd['other'] : $config['keywords'];
    $metadescription = $config['description'];
	if($do == 'ajax'){

        if($bdlist){
            echo json_encode(aljhtx::ajaxPostCharSet($bdlist));
        }else{
            echo '1';
        }
        exit;
    }else{
        include template('aljht:admin/attestation/attestation');
    }
}
//From: Dism_taobao-com
?>