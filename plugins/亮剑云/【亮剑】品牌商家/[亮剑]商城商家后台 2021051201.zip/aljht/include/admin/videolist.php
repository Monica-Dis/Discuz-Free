<?php
if($bid){
    $bd=C::t('#aljbd#aljbd')->fetch($bid);
}
if($do == 'sh_status'){
    if($_GET['formhash'] == FORMHASH) {
        if(!$administrators && $_GET[i] != 1){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","videolist_php_2"))));
            exit;
        }
        if(!$_GET[cashid]){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","videolist_php_3"))));
            exit;
        }

        $goods = C::t('#aljsp#aljbd_video')->fetch($_GET[cashid]);
        if(!$goods){
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","videolist_php_4"))));
            exit;
        }

        if(strtolower(CHARSET) == 'gbk' && !$_G[mobile] && $_GET[message]){
            $_GET[message] = diconv($_GET[message],'utf-8','gbk');
        }

        if(DB::query('update %t set status=%d,reason=%s  where id = %d and status = %d',array('aljbd_video',$_GET[status],$_GET[message],$_GET[cashid],$goods['status']))){
            if($_GET[status] == 2){
                $send_goods_tips = lang("plugin/aljht","videolist_php_5").'{shopname}'.lang("plugin/aljht","videolist_php_6").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=videolist&mod=my">'.lang("plugin/aljht","videolist_php_7").'</a>';
            }else{
                $send_goods_tips = lang("plugin/aljht","videolist_php_8").'{shopname}'.lang("plugin/aljht","videolist_php_9").'{reason}'.'<a href="plugin.php?id=aljht&act=admin&op=videolist&mod=my">'.lang("plugin/aljht","videolist_php_10").'</a>';
            }
            $reason = $_GET[message] ? lang("plugin/aljht","videolist_php_11").$_GET[message] : '';
            notification_add(
                $goods['uid'],
                'system',str_replace(array('{shopname}','{reason}'),array($goods['subject'],$reason), $send_goods_tips),
                array('from_idtype'  => 'aljbd_notice','from_id' => $goods['id'])
            );
            echo json_encode(T::ajaxPostCharSet(array('code'=>1,'text'=>lang("plugin/aljht","videolist_php_12"))));
            exit;
        }else{
            echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","videolist_php_13"))));
            exit;
        }
    }else{
        echo json_encode(T::ajaxPostCharSet(array('code'=>0,'text'=>lang("plugin/aljht","videolist_php_14"))));
        exit;
    }
}else if($do == 'editvideo' || $do == 'addvideo'){
	$video=C::t('#aljsp#aljbd_video')->fetch($vid);
    if($_G['cache']['plugin']['aljbzj']['is_force_pay'] && $bzj_info['price'] <= 0 && $bid && file_exists("source/plugin/aljbzj/template/force_pay_tips.htm") && !$administrators){
        if(submitcheck('formhash')) {
            $post = 1;
            include template('aljbzj:force_pay_tips');
            exit;
        }
    }
	if(submitcheck('formhash')){
	    if($do == 'addvideo'){
            if($bd['vipid']){
                $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$bd['vipid']));
                $brandnum['video']=$vipdata['video'];
                $bnum = C::t('#aljbd#aljbd_video')->count_by_uid_bid($_G['uid']);
                if ($brandnum['video'] && !$administrators) {
                    if ($brandnum['video'] == $checksign) {
                        if(submitcheck('formhash')) {
                            echo "<script>parent.tips('" . lang('plugin/aljbd', 'noauth') . "','');</script>";
                        }else{
                            $aljht_tips = lang('plugin/aljbd', 'noauth') . $noticetips;
                            include template('aljht:admin/pogressbar');
                        }
                        exit;
                    }
                    if ($bnum >= $brandnum['video']) {
                        if(submitcheck('formhash')) {
                            $v_tip1 = lang("plugin/aljht","videolist_php_15");
                            $v_tip2 = lang("plugin/aljht","videolist_php_16");
                            echo "<script>parent.tips('" . $v_tip1 . $brandnum['video'] . $v_tip2 . "','');</script>";
                        }else {
                            $aljht_tips = $v_tip1 . $brandnum['video'] . $v_tip2 . $noticetips;
                            include template('aljht:admin/pogressbar');
                        }
                        exit;
                    }
                }
            }
        }
		if(empty($bid)){
			echo '<script>parent.tips("'.lang('plugin/aljbd','s51').'");</script>';
			exit;
		}
		if($settings['is_attes']['value']){
			$sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
			if(!$sign){
				echo "<script>parent.tips('".lang("plugin/aljht","videolist_php_1")."');</script>";
				exit;
			}
		}
		if(empty($_GET['name'])){
			echo '<script>parent.tips("'.lang('plugin/aljbd','aljbd_1').'");</script>';
			exit;
		}
		
		if((!$_GET['logo'] || (!$_FILES['logo']['tmp_name'] && $_GET['compress'])) && $do != 'editvideo' && !$_GET['video_path']){
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljbd','logo')."','');</script>";
				exit;
			}else{
				echo "<script>parent.tips('".lang('plugin/aljbd','logo')."','');</script>";
				exit;
			}
			
		}
		if($_GET['compress'] == '1'){
			if($_FILES['logo']['tmp_name']) {
				$picname = $_FILES['logo']['name'];
				$picsize = $_FILES['logo']['size'];
			
				if ($picname != "") {
					$type = strtolower(strrchr($picname, '.'));
					if ($type != ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
							exit;
						}else{
							echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
							exit;
						}
					}
					if (($picsize/1024)>$_G['cache']['plugin']['aljbd']['img_size']) {
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('".lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB'."','');</script>";
							exit;
						}else{
							echo "<script>parent.tips('".lang('plugin/aljbd','img1').$_G['cache']['plugin']['aljbd']['img_size'].'KB'."','');</script>";
							exit;
						}
					}
					$rand = rand(100, 999);
					$pics = date("YmdHis") . $rand . $type;
					$img_dir = "source/plugin/aljsp/images/logo/".date('Ymd',TIMESTAMP).'/';
					if (!is_dir($img_dir)) {
						mkdir($img_dir);
					}
					$logo = $img_dir.$pics;
					if(@copy($_FILES['logo']['tmp_name'], $logo)||@move_uploaded_file($_FILES['logo']['tmp_name'], $logo)){
						if($_G['cache']['plugin']['aljbd']['iswatermark']){
							$image->Watermark(DISCUZ_ROOT.'./'.$logo,'', 'forum');
						}
						@unlink($_FILES['logo']['tmp_name']);
					}
				}
			}
		}else{
			if ($_GET['logo']) {
                $image_path = "source/plugin/aljsp/images/logo/";
                if (strpos($_GET['logo'],"base64") === false) {
                    $logo = $_GET['logo'];
                } else {
                    unlink($video['logo']);
                    T::delete_oss($video['logo']);
                    $logo = T::saveimg($_GET['logo'],$image_path);
                }
			}
		}


		$insertarray=array(
			'subject'=>$_GET['name'],
			'bid'=>$_GET['bid'],
			'jieshao'=>$_GET['jieshao'],
			'timestamp'=>TIMESTAMP,
			'videourl'=>$_GET['videourl'],
			'type'=>$_GET['type'],
			'subtype'=>$_GET['subtype'],
			'subtype3'=>$_GET['subtype3'],
		);
		$insertarray['uid'] = $bd['uid'];
        $insertarray['username'] = $bd['username'];
        if($_G['cache']['plugin']['aljoss']['Access_Key']){
            $insertarray['video_path'] = $_GET['video_path'];

            if($c && $_GET['del_video']){
                unlink($c['video_path']);
                T::delete_oss($c['video_path']);
                $insertarray['video_path'] = '';
            }
        }
		if($video){
			if($logo){
                if($_GET['compress'] == '1'){
                    unlink($video['logo']);
                    T::delete_oss($video['logo']);
                }
				$insertarray['logo']=$logo;
			}
			C::t('#aljsp#aljbd_video')->update($vid,$insertarray);
		}else{
			
			$insertarray['logo']=$logo;
            if($vipdata['is_bvideo'] >0 && !$administrators){
                require_once 'source/plugin/aljht/include/aljbd/addvideo_send.php';
            }
			C::t('#aljsp#aljbd_video')->insert($insertarray);
		}
        $sh_tips = $sh_tips ? $sh_tips : lang('plugin/aljbd','s53');
		echo '<script>parent.tips("'.$sh_tips.'","plugin.php?id=aljht&act=admin&op=videolist'.$urlmod.'");</script>';
		exit;
	}else{
		if($bid){
			$bd=C::t('#aljbd#aljbd')->fetch($bid);
		}
        if($settings['is_attes']['value'] && !$settings['is_post_btn']['value']){
            $sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
            if(!$sign){
                $aljht_tips = lang("plugin/aljht","videolist_php_17");
                include template('aljht:admin/pogressbar');
                exit;
            }
        }
        $typelist=C::t('#aljsp#'.$pluginid_aljbd.'_type_video')->fetch_all_by_upid(0);
        if($administrators){
            $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','','');//����Ա
        }else{
            $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','',$_G['uid']);//����
        }
		include template('aljht:admin/videolist/addvideo');
	}
}else{
	$keyword = addcslashes($_GET['search'], '%_');
	if(submitcheck('formhash') && empty($keyword)){
        if($administrators) {

            if ($_GET['sign'] == 2) {
                if (is_array($_GET['delete'])) {
                    foreach ($_GET['delete'] as $k => $id) {
                        C::t('#aljsp#aljbd_video')->update($id, array('rubbish' => '1'));
                    }
                }
            } else if ($_GET['sign'] == 6) {
                if (is_array($_GET['delete'])) {
                    foreach ($_GET['delete'] as $k => $id) {
                        DB::query('update %t set status=0  where id = %d', array('aljbd_video', $id));
                    }
                }
            } else if ($_GET['sign'] == 7) {
                if (is_array($_GET['delete'])) {
                    foreach ($_GET['delete'] as $k => $id) {
                        DB::query('update %t set status=3  where id = %d', array('aljbd_video', $id));
                    }
                }
            } else if ($_GET['sign'] == 1) {
                $send_goods_tips = lang("plugin/aljht","videolist_php_18") . '{shopname}' . lang("plugin/aljht","videolist_php_19") . '{reason}' . '<a href="plugin.php?id=aljht&act=admin&op=videolist&mod=my">' . lang("plugin/aljht","videolist_php_20") . '</a>';

                if (is_array($_GET['delete'])) {

                    foreach ($_GET['delete'] as $k => $id) {
                        DB::query('update %t set status=2,reason=%s  where id = %d', array('aljbd_video', $_GET['reason'][$id], $id));
                        $brand = C::t('#aljsp#aljbd_video')->fetch($id);
                        $reason = $_GET['reason'][$id] ? lang("plugin/aljht","videolist_php_21") . $_GET['reason'][$id] : '';
                        notification_add($brand['uid'], 'system', str_replace(array('{shopname}', '{reason}'), array($brand['subject'], $reason), $send_goods_tips), array('from_idtype' => 'aljbd_video', 'from_id' => $brand['id']));
                        unset($reason);
                    }
                }
            } else {
                if (is_array($_GET['delete'])) {
                    $send_goods_tips = lang("plugin/aljht","videolist_php_22") . '{shopname}' . lang("plugin/aljht","videolist_php_23") . '{reason}' . '<a href="plugin.php?id=aljht&act=admin&op=videolist&mod=my">' . lang("plugin/aljht","videolist_php_24") . '</a>';
                    foreach ($_GET['delete'] as $k => $id) {
                        DB::query('update %t set status=0,reason=%s  where id = %d', array('aljbd_video', $_GET['reason'][$id], $id));
                        $brand = C::t('#aljsp#aljbd_video')->fetch($id);
                        $reason = $_GET['reason'][$id] ? lang("plugin/aljht","videolist_php_25") . $_GET['reason'][$id] : '';
                        notification_add($brand['uid'], 'system', str_replace(array('{shopname}', '{reason}'), array($brand['subject'], $reason), $send_goods_tips), array('from_idtype' => 'aljbd_video', 'from_id' => $brand['id']));
                        unset($reason);
                    }
                }
            }
        }else{
            if ($_GET['sign'] == 2) {
                if (is_array($_GET['delete'])) {
                    foreach ($_GET['delete'] as $k => $id) {
                        C::t('#aljsp#aljbd_video')->update($id, array('rubbish' => '1'));
                    }
                }
            } else if ($_GET['sign'] == 6) {
                if (is_array($_GET['delete'])) {
                    foreach ($_GET['delete'] as $k => $id) {
                        DB::query('update %t set status=0  where id = %d', array('aljbd_video', $id));
                    }
                }
            } else if ($_GET['sign'] == 7) {
                if (is_array($_GET['delete'])) {
                    foreach ($_GET['delete'] as $k => $id) {
                        DB::query('update %t set status=3  where id = %d', array('aljbd_video', $id));
                    }
                }
            }
        }
		echo '<script>parent.tips(0);</script>';
		exit;
	}
	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	$con[]='aljbd_video';
	if($administrators){
		$where=" where rubbish=0";
	}else{
		$where=" where rubbish=0 and uid = %d";
		$con[] = $_G['uid'];
	}

    if($_GET['bid']){
        $con[]=$_GET['bid'];
        $where.=' and bid=%d';
    }
	if($_GET['search']){
		$con[] ='%' . $keyword . '%';
		$where.=" and subject like %s";
	}
    if($do == 'rec'){
        $where.=' and status=0 and sign=1';
    }else if($do == 'no'){
        $where.=' and status=1';
    }else if($do == 'lose'){
        $where.=' and status=2';
    }else if($do == 'close'){
        $where.=' and status=3';
    }else{
        $where.=' and status=0';
    }
	$num = DB::result_first('select count(*) from %t'.$where,$con);
	$con[]=$start;
	$con[]=$perpage;
	$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY id desc limit %d,%d',$con);
	
	$bdlist = dhtmlspecialchars($bdlist);
	$navtitle = $_G['cache']['plugin'][$pluginid]['title'];
	$metakeywords = $_G['cache']['plugin'][$pluginid]['keywords'];
	$metadescription = $_G['cache']['plugin'][$pluginid]['description'];
	include template('aljht:admin/videolist/videolist');
}
//From: Dism_taobao-com
?>