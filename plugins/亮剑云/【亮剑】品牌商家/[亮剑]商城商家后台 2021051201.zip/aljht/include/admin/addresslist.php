<?php
if($_G['cache']['plugin']['aljbdx']){
	$addresstable = 'aljbdx';
	$rlist = C::t('#aljbdx#aljgwc_region')->fetch_all_by_upid();
    $regionlist=C::t('#aljbdx#aljgwc_region')->range();
}else{
	$alj_lang=lang('plugin/aljgwc');
    $rlist = C::t('#aljgwc#aljgwc_region')->fetch_all_by_upid();
    $regionlist=C::t('#aljgwc#aljgwc_region')->range();
    $addresstable = 'aljgwc';
}
$address = C::t('#'.$addresstable.'#aljbd_address')->fetch($address_id);
if($do == 'deladdress'){
	if($address['uid'] != $_G['uid'] && $_GET['formhash'] != FORMHASH){
		echo '0';
		exit;
	}
	C::t('#'.$addresstable.'#aljbd_address')->delete($address_id);
	echo '1';
	exit;
}elseif($do == 'updateaddress'){
	if($address['uid'] != $_G['uid'] && $_GET['formhash'] != FORMHASH){
		echo '0';
		exit;
	}
    DB::query('UPDATE %t SET defaultAddress=0 WHERE uid=%d', array('aljbd_address', $_G['uid']));
	DB::query("update %t set defaultAddress=1 where id = %d",array('aljbd_address',$address_id));
	echo '1';
	exit;
}else{

	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	$con[]='aljbd_address';
	
	$where=" where uid = %d";
	$con[] = $_G['uid'];
	
	$num = DB::result_first('select count(*) from %t'.$where,$con);
	$con[]=$start;
	$con[]=$perpage;
	$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY id desc limit %d,%d',$con);
	
	$bdlist = dhtmlspecialchars($bdlist);
	$addrlist = $bdlist;
	if(submitcheck('formhash')){
		if(empty($_GET['region']) && empty($_GET['citypicker'])){
			echo '<script>parent.tips("'.lang("plugin/aljht","addresslist_php_1").'","");</script>';
			exit;
		}
		if(empty($_GET['addressDetail'])){
			echo '<script>parent.tips("'.lang("plugin/aljht","addresslist_php_2").'","");</script>';
			exit;
		}
		if(empty($_GET['fullName'])){
			echo '<script>parent.tips("'.lang("plugin/aljht","addresslist_php_3").'","");</script>';
			exit;
		}
		if(empty($_GET['mobile']) && empty($_GET['phoneCode'])){
			echo '<script>parent.tips("'.lang("plugin/aljht","addresslist_php_4").'","");</script>';
			exit;
		}
        if($_G['mobile']){
            $citypicker = array_filter(explode(' ', trim($_GET['citypicker'])));
        }else{
            $citypicker = array_filter(explode('/', trim($_GET['citypicker'])));
        }
		$insertarray = array(
            'province' => $citypicker[0],
            'city' => $citypicker[1],
            'district' => $citypicker[2],
			'region' => $_GET['region'],
			'region1' => $_GET['subregion'],
			'region2' => $_GET['region1'],
			'addressDetail' => $_GET['addressDetail'],
			'post' => $_GET['post'],
			'fullName' => $_GET['fullName'],
			'mobile' => $_GET['mobile'],
			'phoneSection' => $_GET['phoneSection'],
			'phoneCode' => $_GET['phoneCode'],
			'phoneExt' => $_GET['phoneExt'],
			'defaultAddress' => $_GET['defaultAddress'],
			'dateline' => TIMESTAMP,
			'uid' => $_G['uid'],
			'username' => $_G['username'],
		);
		if($_GET['defaultAddress']){
			C::t('#'.$addresstable.'#aljbd_address')->update_by_uid_defaultAddress($_G['uid']);
		}
		if($address){
			if($address['uid'] != $_G['uid']){
				echo '<script>parent.tips("'.lang("plugin/aljht","addresslist_php_5").'","");</script>';
				exit;
			}
			C::t('#'.$addresstable.'#aljbd_address')->update($address_id,$insertarray);
		}else{
			if($num >20){
				echo '<script>parent.tips("'.lang("plugin/aljht","addresslist_php_6").'","");</script>';
				exit;
			}
			C::t('#'.$addresstable.'#aljbd_address')->insert($insertarray);
		}
		echo '<script>parent.tips("'.lang('plugin/aljbd','s53').'","plugin.php?id=aljht&act=admin&op=addresslist'.$urlmod.'");</script>';
		exit;
	}
	
	$navtitle = $_G['cache']['plugin'][$pluginid]['title'];
	$metakeywords = $_G['cache']['plugin'][$pluginid]['keywords'];
	$metadescription = $_G['cache']['plugin'][$pluginid]['description'];
	include template('aljht:admin/addresslist/addresslist');
}
//From: Dism_taobao-com
?>