<?php
$cashmoney_type = array('1'=>lang("plugin/aljht","transferorder_php_10"),'2'=>lang("plugin/aljht","transferorder_php_11"),'3'=>lang("plugin/aljht","transferorder_php_12"));
$accountid = intval($_GET['accountid']);
$accountuser = DB::fetch_first('select * from %t where uid=%d and cashmoney_default=%d',array('aljjs_accountsettle',$_G['uid'],1));//Ĭ���ʻ�
$addaccount = C::t('#aljjs#aljjs_accountsettle')->fetch($accountid);
if($do == 'delaccount'){
	if($_GET['formhash'] == formhash()){
		if($_G['uid'] == $addaccount['uid']){
			C::t('#aljjs#aljjs_accountsettle')->delete($accountid);
		}
		echo '<script>parent.tips("'.lang("plugin/aljht","transferorder_php_1").'");</script>';
		exit;
	}
}else if($do == 'addaccount'){
	
	if(submitcheck('formhash')){
		if(empty($_GET['cashmoney_type'])){
			echo '<script>parent.tips("'.lang("plugin/aljht","transferorder_php_2").'");</script>';
			exit;
		}
		if(empty($_GET['cashmoney_name'])){
			echo '<script>parent.tips("'.lang("plugin/aljht","transferorder_php_3").'");</script>';
			exit;
		}
		if(empty($_GET['cashmoney_account'])){
			echo '<script>parent.tips("'.lang("plugin/aljht","transferorder_php_4").'");</script>';
			exit;
		}
		$insertarray = array(
			'cashmoney_type' => $_GET['cashmoney_type'],
			'cashmoney_account' => $_GET['cashmoney_account'],
			'cashmoney_name' => $_GET['cashmoney_name'],
			'cashmoney_default' => $_GET['cashmoney_default'],
		);
		if($_GET['cashmoney_default']){
			DB::query('update %t set cashmoney_default=%d where uid = %d',array('aljjs_accountsettle','0',$_G['uid']));
		}
		if($addaccount){
			C::t('#aljjs#aljjs_accountsettle')->update($accountid,$insertarray);
		}else{
			$insertarray['dateline'] = TIMESTAMP;
			$insertarray['uid'] = $_G['uid'];
			C::t('#aljjs#aljjs_accountsettle')->insert($insertarray);
		}
		echo '<script>parent.tips("'.lang("plugin/aljht","transferorder_php_5").'");</script>';
		exit;
	}else{
		include template('aljht:admin/transferorder/addaccount');
	}
}else if($do == 'edittransferorder' || $do == 'addtransferorder'){
	$transferorder=C::t('#aljjs#aljjs_transfer')->fetch($orderid);
	$account = DB::fetch_first('select * from %t where uid=%d and bid=%d',array('aljjs_brandsettle',$_G['uid'],$bid));
	if(submitcheck('formhash')){
		$cashmoney = sprintf("%1.2f",$_GET['cashmoney']);
		if(empty($bid)){
			echo '<script>parent.tips("'.lang('plugin/aljbd','s51').'");</script>';
			exit;
		}
		if($account['balance'] < $_GET['cashmoney'] || $account['balance'] < $_G['cache']['plugin']['aljjs']['min']){
			echo '<script>parent.tips("'.lang("plugin/aljht","transferorder_php_6").'");</script>';
			exit;
		}
		if(empty($_GET['cashmoney'])){
			echo '<script>parent.tips("'.lang("plugin/aljht","transferorder_php_7").'");</script>';
			exit;
		}
		if(empty($addaccount)){
			echo '<script>parent.tips("'.lang("plugin/aljht","transferorder_php_8").'");</script>';
			exit;
		}
		$fee = sprintf("%1.2f",$cashmoney*$_G['cache']['plugin']['aljjs']['per']);
		$insertarray = array(
			'amount' => $cashmoney,
			'toaccountmoney' => $cashmoney-$fee,
			'fee' => $fee,
			'cashmoney_type' => $addaccount['cashmoney_type'],
			'cashmoney_account' => $addaccount['cashmoney_account'],
			'cashmoney_name' => $addaccount['cashmoney_name'],
		);
		
		if($transferorder){
			//C::t('#aljjs#aljjs_transfer')->update($orderid,$insertarray);
		}else{
			$orderid = $config['mchid'].dgmdate(TIMESTAMP,'Ymd').TIMESTAMP;
			$insertarray['uid'] = $_G['uid'];
			$insertarray['username'] = $_G['username'];
			$insertarray['orderid'] = $orderid;
			$insertarray['bid'] = $bid;
			$insertarray['spbill_create_ip'] = $_G['clientip'];
			$insertarray['desc'] = $_G['cache']['plugin']['aljjs']['mycashtips'];
			$insertarray['dateline'] = TIMESTAMP;
			DB::query('update %t set balance=balance-%i,times=times+1,cash=cash+%i,dateline=%d where bid=%d',array('aljjs_brandsettle',$cashmoney,$cashmoney,TIMESTAMP,$bid));
            $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
            $mes = '&#29992;&#25143;&#12300;'.$_G['username'].'&#12301;&#30340;&#24215;&#38138;&#25552;&#20132;&#20102;&#25552;&#29616;&#30003;&#35831;&#65292;&#35831;&#21450;&#26102;&#22788;&#29702; <a href="plugin.php?id=aljht&act=admin&op=transferorder">&#28857;&#20987;&#26597;&#30475;</a>';
            foreach($groupids as $g_uid){
                notification_add($g_uid['uid'], 'system',$mes);
            }
			C::t('#aljjs#aljjs_transfer')->insert($insertarray);
		}
		echo '<script>parent.tips("'.lang('plugin/aljbd','s53').'","plugin.php?id=aljht&act=admin&op=transferorder'.$urlmod.'");</script>';
		exit;
	}else{
		if(!$account){
			echo '<script>alert("'.lang("plugin/aljht","transferorder_php_9").'");location.href="plugin.php?id=aljht&act=admin&op=assets'.$urlmod.'"</script>';
			exit;
		}
		$accountarr = DB::fetch_all('select * from %t where uid=%d',array('aljjs_accountsettle',$_G['uid']));
		include template('aljht:admin/transferorder/addtransferorder');
	}
}else{
	$keyword = addcslashes($_GET['search'], '%_');
	if(submitcheck('formhash') && empty($keyword)){
		if($_GET['sign'] == 2){
			if(is_array($_GET['delete'])) {
				foreach($_GET['delete'] as $k => $id) {
					$transfer = C::t('#aljjs#aljjs_transfer')->fetch($id);
					if($transfer){
						DB::query('update %t set status=%d,payment_time=%d,remarks=%s  where orderid = %s and status=0',array('aljjs_transfer','2',TIMESTAMP,$_GET['remarks'][$id],$id));
						DB::query('update %t set balance=balance+%i,cash=cash-%i,dateline=%d where bid=%d',array('aljjs_brandsettle',$transfer['amount'],$transfer['amount'],TIMESTAMP,$transfer['bid']));
					}
					unset($transfer);
				}
			}
		}else{
			if(is_array($_GET['delete'])) {
				foreach($_GET['delete'] as $k => $id) {
					DB::query('update %t set status=%d,payment_time=%d,remarks=%s  where orderid = %s',array('aljjs_transfer','1',TIMESTAMP,$_GET['remarks'][$id],$id));
				}
			}
		}
		echo '<script>parent.tips(0);</script>';
		exit;
	}
	
	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=20;
	$start=($currpage-1)*$perpage;
	$con[]='aljjs_transfer';
	if($administrators){
		$where=" where 1";
	}else{
		$where=" where uid=%d";
		$con[] = $_G['uid'];
	}
	
	if($_GET['start']){
		$con[] =strtotime($_GET['start']);
		$where.=" and dateline >= %d";
	}
	if($_GET['end']){
		$con[] =strtotime($_GET['end']);
		$where.=" and dateline <= %d";
	}
	if($_GET['status']){
		$con[] =$_GET['status']-1;
		$where.=" and status = %d";
	}
	$num = DB::result_first('select count(*) from %t'.$where,$con);
	$con[]=$start;
	$con[]=$perpage;
	$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY dateline desc limit %d,%d',$con);
	
	$bdlist = dhtmlspecialchars($bdlist);
	$brandlist = DB::fetch_all('select * from %t where uid=%d',array('aljbd',$_G['uid']));
	$platformfee = DB::result_first('select sum(fee) from %t where status=1 ',array('aljjs_transfer'));//ƽ̨����
	$platformamount = DB::result_first('select sum(amount) from %t ',array('aljjs_transfer'));//������
	$platformamount_t = DB::result_first('select sum(amount) from %t where status=1',array('aljjs_transfer'));//�����ֳɹ�
	$platformtoaccountmoney = DB::result_first('select sum(toaccountmoney) from %t where status=1',array('aljjs_transfer'));//��ת��
	$platformamount_f = DB::result_first('select sum(amount) from %t where status=2',array('aljjs_transfer'));//�����ֳɹ�
	$platformamount_d = DB::result_first('select sum(amount) from %t where status=0',array('aljjs_transfer'));//�ܴ�ת��
	//$platformtoaccountmoney = DB::result_first('select sum(toaccountmoney) from %t where status=0',array('aljjs_transfer'));//��ת��
	$navtitle = $config['title'];
	$metakeywords =  $bd['other']?$bd['other']:$config['keywords'];
	$metadescription = $config['description'];
	include template('aljht:admin/transferorder/transferorder');
}
//From: Dism_taobao-com
?>