<?php
$cashmoney_type = array('1'=>lang("plugin/aljht","assets_php_1"),'2'=>lang("plugin/aljht","assets_php_2"),'3'=>lang("plugin/aljht","assets_php_3"));

$keyword = addcslashes($_GET['search'], '%_');
if(submitcheck('formhash') && empty($keyword)){
	if($_GET['sign'] == 2 && $administrators){
		if(is_array($_GET['delete'])) {
			foreach($_GET['delete'] as $k => $id) {
				DB::query('update %t set income=%s,cash=%s,balance=%s where bid = %s',array('aljjs_brandsettle',$_GET['income'][$id],$_GET['cash'][$id],$_GET['balance'][$id],$id));
			}
		}
	}
	echo '<script>parent.tips(0);</script>';
	exit;
}

$currpage=$_GET['page']?intval($_GET['page']):1;
$perpage=10;
$start=($currpage-1)*$perpage;
$con[]='aljjs_brandsettle';
if($administrators){
	$where=" where 1";
}else{
	$where=" where uid=%d";
	$con[] = $_G['uid'];
}

if($_GET['search']){
	$con[] =$keyword;
	$where.=" and bid = %d";
}

$num = DB::result_first('select count(*) from %t'.$where,$con);
$con[]=$start;
$con[]=$perpage;
$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY income desc limit %d,%d',$con);

$bdlist = dhtmlspecialchars($bdlist);
if($administrators){
	$brandlist = DB::fetch_all('select * from %t',array('aljbd'));
}else{
	$brandlist = DB::fetch_all('select * from %t where uid=%d',array('aljbd',$_G['uid']));
}
$countbrand = DB::fetch_first('select sum(income) income,sum(times) times,sum(cash) cash,sum(b_times) b_times,sum(balance) balance,sum(refund) refund from %t',array('aljjs_brandsettle'));

$navtitle = lang("plugin/aljht","assets_php_4").'-'.$config['title'];
$metakeywords =  $bd['other']?$bd['other']:$config['keywords'];
$metadescription = $config['description'];
include template('aljht:admin/assets/assets');
?>