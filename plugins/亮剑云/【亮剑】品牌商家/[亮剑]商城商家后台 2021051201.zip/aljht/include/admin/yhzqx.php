<?php
$groups=C::t('common_usergroup')->range('','','desc');
if(submitcheck('formhash')){
	
	$gs=dhtmlspecialchars($_GET['yhz']);
	
	foreach($gs as $k => $v){
		if(C::t('#aljbd#aljbd_usergroup')->fetch($k)){
			C::t('#aljbd#aljbd_usergroup')->update($k,array(
				'brand'=>$v['brand'],
				'notice'=>$v['notice'],
				'album'=>$v['album'],
				'good'=>$v['good'],
				'consume'=>$v['consume'],
				'grouptitle'=>$groups[$k]['grouptitle'],
			));
		}else{
			C::t('#aljbd#aljbd_usergroup')->insert(array(
				'groupid'=>intval($k),
				'brand'=>$v['brand'],
				'notice'=>$v['notice'],
				'album'=>$v['album'],
				'good'=>$v['good'],
				'consume'=>$v['consume'],
				'grouptitle'=>$groups[$k]['grouptitle'],
			)); 
		}
	}
	echo '<script>parent.tips(0);</script>';
	exit;
}else{
	
	$aljbd_groups=C::t('#aljbd#aljbd_usergroup')->range();
	include template('aljht:admin/yhzqx/yhzqx');
}
//From: Dism_taobao-com
?>