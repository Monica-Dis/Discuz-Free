<?php
$hid = intval($_GET['hid']);
if($do == 'edithelp' || $do == 'addhelp'){
	$help = C::t('#aljhelp#aljhelp') -> fetch($hid);
	if(submitcheck('formhash')){
		if(empty($_GET['subject'])){
            echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_1')."','');</script>";
            exit;
		}
		if(empty($_GET['intro'])){
            echo "<script>parent.tips('".lang('plugin/aljbd','aljbd_2')."','');</script>";
            exit;
		}
		$updatearray=array(
			'status'=>$_GET['status'],
			'subject'=>$_GET['subject'],
			'content'=>$_GET['intro'],
			'typeid'=>$_GET['typeid'],
			'subtypeid'=>$_GET['subtypeid'],
		);
		//$bd=C::t('#aljbd#aljbd')->fetch($bid);
		$updatearray['uid'] = $_G['uid'];
		$updatearray['username'] = $_G['username'];
		if($help){
			C::t('#aljhelp#aljhelp')->update($hid,$updatearray);
		}else{
			$updatearray['dateline'] = TIMESTAMP;
			$insertid=C::t('#aljhelp#aljhelp')->insert($updatearray,true);
		}

        echo "<script>parent.tips('".lang('plugin/aljbd','s53')."','plugin.php?id=aljht&act=admin&op=help".$urlmod."');</script>";
        exit;

	}else{
        $helptype = DB::fetch_all('select * from %t ',array('aljhelp_type'));
		include template('aljht:admin/help/addhelp');
	}
}else if($do == 'helptype'){
    if(submitcheck('formhash')){
        $newkey = $_GET['newkey'];
        $name = $_GET['name'];
        $newvalue = $_GET['newvalue'];
        if(is_array($name)) {
            foreach($name as $id=>$value) {
                C::t('#aljhelp#aljhelp_type')->update($id,array('name'=>$value));
            }
        }
        if(is_array($newkey)) {
            foreach($newkey as $key=>$name) {
                if(empty($name)) {
                    continue;
                }
                C::t('#aljhelp#aljhelp_type')->insert(array('name' => $name),1);
            }
        }
        if(is_array($newvalue)) {
            foreach($newvalue as $cid=>$subcat) {
                foreach($subcat as $key=>$value) {
                    if(empty($value)) {
                        continue;
                    }
                    C::t('#aljhelp#aljhelp_type')->insert(array('upid' => $cid, 'value' => $value),1);
                }
            }
        }
        echo '<script>parent.location.href="plugin.php?id=aljht&act=admin&op='.$op.'&do='.$do.$urlmod.'";</script>';
        exit;
    }else{
        $helptype = DB::fetch_all('select * from %t ',array('aljhelp_type'));
        include template('aljht:admin/help/helptype');
    }
}elseif($do == 'del_helptype'){

    if($_GET['formhash'] == formhash()){
        C::t('#aljhelp#aljhelp_type')->delete($_GET['hid']);
    }
    echo '<script>parent.location.href="plugin.php?id=aljht&act=admin&op='.$op.'&do=helptype'.$urlmod.'";</script>';
    exit;
}else{
	$keyword = addcslashes($_GET['search'], '%_');
	if(submitcheck('formhash') && empty($keyword)){
        savecache('aljhelp', '');//�����������͹����ÿ�
        if(is_array($_GET['displayorder'])) {
            foreach($_GET['displayorder'] as $k => $id) {
                DB::query('update %t set displayorder=%d  where id = %d',array('aljhelp',$id,$k));
            }
        }
        if($_GET['sign'] == 3){
            if(is_array($_GET['delete'])) {
                foreach($_GET['delete'] as $k => $id) {
                    DB::query('update %t set status=0  where id = %d',array('aljhelp',$id));
                }
            }
        }else if($_GET['sign'] == 4){
            if(is_array($_GET['delete'])) {
                foreach($_GET['delete'] as $k => $id) {
                    DB::query('update %t set status=1  where id = %d',array('aljhelp',$id));
                }
            }
        }else if($_GET['sign'] == 2){
            if(is_array($_GET['delete'])) {
                foreach($_GET['delete'] as $k => $id) {
                    C::t('#aljhelp#aljhelp')->update($id,array('rubbish'=>'1'));
                }
            }
        }else if($_GET['sign'] == 5){
            if(is_array($_GET['delete'])) {
                foreach($_GET['delete'] as $k => $id) {
                    DB::query('update %t set is_gg=1  where id = %d',array('aljhelp',$id));
                }
                
            }
        }else if($_GET['sign'] == 6){
            if(is_array($_GET['delete'])) {
                foreach($_GET['delete'] as $k => $id) {
                    DB::query('update %t set is_gg=0  where id = %d',array('aljhelp',$id));
                }
            }
        }

		echo '<script>parent.tips(0);</script>';
		exit;
	}

	$currpage=$_GET['page']?intval($_GET['page']):1;
	$perpage=20;
	$start=($currpage-1)*$perpage;
	$con[]='aljhelp';
	if($administrators){
		$where=" where rubbish=0";
	}else{
		$where=" where rubbish=0 and uid = %d";
		$con[] = $_G['uid'];
	}
	if($_GET['search']){
		$con[] ='%' . $keyword . '%';
		$where.=" and subject like %s";
	}
	$num = DB::result_first('select count(*) from %t'.$where,$con);
	$con[]=$start;
	$con[]=$perpage;
	$bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY displayorder desc,id desc limit %d,%d',$con);
	$bdlist = dhtmlspecialchars($bdlist);
	include template('aljht:admin/help/help');
}
//From: Dism_taobao-com
?>