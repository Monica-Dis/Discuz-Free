<?php

/*
 * ����: Discuz!����������
 * ����֧��: http://www.dzx30.com
 * ��ϵQQ: 578933760
 * ����˵��:������̨-�������̳�
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$pluginid = 'aljbd';
require_once 'source/plugin/aljbd/include/aljbd_parameter.php';
if($op == 'appointment_list'){//�ҵ�ԤԼ
    $iframe_url = 'plugin.php?id=aljht&act=admin&op=appointment_list&state=2&mod=my&ajax=yes&sc_dh=1';
    $navtitle = lang("plugin/aljht","user_php_7").' - '.$_G['cache']['plugin'][$pluginid]['title'];
    $metakeywords = $_G['cache']['plugin'][$pluginid]['keywords'];
    $metadescription = $_G['cache']['plugin'][$pluginid]['description'];
    include template('aljht:user/common/iframe');
}else if($op == 'collection'){//�ҵ��ղ�
    $iframe_url = 'plugin.php?id=aljht&act=admin&op=collection&mod=my&ajax=yes&sc_dh=1';
    if($_GET['frommod']){
        $iframe_url .= '&frommod='.$_GET['frommod'];
    }
    $navtitle = lang("plugin/aljht","user_php_8").' - '.$_G['cache']['plugin'][$pluginid]['title'];
    $metakeywords = $_G['cache']['plugin'][$pluginid]['keywords'];
    $metadescription = $_G['cache']['plugin'][$pluginid]['description'];
    include template('aljht:user/common/iframe');
}else if($op == 'wallet'){//�ҵ�Ǯ��
    $wallet = DB::fetch_first('select * from %t where uid=%d', array('aljqb_wallet', $_G['uid']));
    if (empty($wallet)) {
        $insertarray = array(
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'createtime' => time(),
        );
        DB::insert('aljqb_wallet', $insertarray);
        $wallet = DB::fetch_first('select * from %t where uid=%d', array('aljqb_wallet', $_G['uid']));
    }
    if($do == 'rechargelog'){
        $iframe_url = 'plugin.php?id=aljqb&act=rechargelog';
    }else if($do == 'apply'){
        $iframe_url = 'plugin.php?id=aljqb&act=apply';
    }else if($do == 'ranklist'){
        $iframe_url = 'plugin.php?id=aljqb&act=ranklist';
    }else if($do == 'accountlist'){
        $iframe_url = 'plugin.php?id=aljqb&act=accountlist';
    }else{
        $iframe_url = 'plugin.php?id=aljqb&act=account';
    }
    $navtitle = lang("plugin/aljht","user_php_9").' - '.$_G['cache']['plugin'][$pluginid]['title'];
    $metakeywords = $_G['cache']['plugin'][$pluginid]['keywords'];
    $metadescription = $_G['cache']['plugin'][$pluginid]['description'];
    include template('aljht:user/wallet');
}else if($op == 'commentlist'){//�ҵ�ɹ��
    if($_GET['ajax'] == 'yes'){
        $keyword = addcslashes(T::ajaxGetCharSet($_GET['search']), '%_');
        $replytable = 'aljbd_comment_goods';
        $currpage=intval($_GET['page'])?intval($_GET['page']):1;
        $perpage=10;
        $start=($currpage-1)*$perpage;
        $con[]= $replytable;
        if($_GET['rubbish'] == 1){
            $where = 'where rubbish=1';
        }else{
            $where = 'where rubbish=0';
        }
        $con[] = $_G['uid'];
        $where.=" and uid = %d";
        if($_GET['search']){
            $con[] ='%' . $keyword . '%';
            $where.=" and content like %s";
        }
        
        $num=DB::result_first('select count(*) from %t '.$where,$con);
        $where.=" order by id desc limit %d,%d";
        $con[]= $start;
        $con[]= $perpage;
        $commentlist=DB::fetch_all('select * from %t '.$where,$con);
        foreach($commentlist as $c_k => $c_v){
            $commentlist[$c_k]['goods_name'] = DB::result_first('select name from %t where id=%d',array('aljbd_goods',$c_v['gid']));
            $commentlist[$c_k]['dateline'] = dgmdate($c_v['dateline'],'u');
        }
        if($commentlist){
            T::responseJson(array(
                'code' => 0,
                'msg' => "",
                'count' => $num,
                'data' => $commentlist
            ));
        }else{
            T::responseJson(array(
                'code' => 0,
                'msg' => "",
                'count' => 0,
                'data' => array()
            ));
        }
        exit;
    }else{
        $navtitle = lang("plugin/aljht","user_php_10").' - '.$_G['cache']['plugin'][$pluginid]['title'];
        $metakeywords = $_G['cache']['plugin'][$pluginid]['keywords'];
        $metadescription = $_G['cache']['plugin'][$pluginid]['description'];
        include template('aljht:user/commentlist');
    }
}else if($op == 'replylist'){//�ҵ�����
    $table = 'aljbd_comment';
    $t_name = lang("plugin/aljht","user_php_11");
    if($_GET['tb'] == 'notice'){
        $table .= '_notice';
        $t_name = lang("plugin/aljht","user_php_12");
    }else if($_GET['tb'] == 'consume'){
        $table .= '_consume';
        $t_name = lang("plugin/aljht","user_php_13");
    }
    $replytable = $table;
    if($do == 'del_reply'){
        $_GET['delete'] = explode(',',$_GET['delete']);
        
        if (is_array($_GET['delete'])) {
            
            foreach ($_GET['delete'] as $k => $id) {
                DB::query('update %t set rubbish=1  where id = %d', array($replytable, $id));
            }
        }
        echo '1';
        exit;
    }
    $businesstype = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljbd']['businesstype']));
    foreach($businesstype as $key=>$value){
        $arr=explode('=',$value);
        $businesstypearr[$arr[0]]=$arr[1];
        $busarr[$arr[0]]=diconv($arr[1],CHARSET,'UTF-8');;
    }
    if($_GET['ajax'] == 'yes'){
        $keyword = addcslashes(T::ajaxGetCharSet($_GET['search']), '%_');
        
        $currpage=intval($_GET['page'])?intval($_GET['page']):1;
        $perpage=10;
        $start=($currpage-1)*$perpage;
        $con[]= $replytable;
        
        $where = 'where rubbish=0';
        
        $con[] = $_G['uid'];
        $where.=" and uid = %d";
        if($_GET['search']){
            $con[] ='%' . $keyword . '%';
            $where.=" and content like %s";
        }
        
        $num=DB::result_first('select count(*) from %t '.$where,$con);
        $where.=" order by id desc limit %d,%d";
        $con[]= $start;
        $con[]= $perpage;
        $commentlist=DB::fetch_all('select * from %t '.$where,$con);
        foreach($commentlist as $c_k => $c_v){
            if($_GET['tb'] == 'notice'){
                $bd_name = DB::fetch_first('select * from %t where id=%d',array('aljbd_notice',$c_v['nid']));
                $bd_name['name'] = $bd_name['subject'];
            }else if($_GET['tb'] == 'consume'){
                $bd_name = DB::fetch_first('select * from %t where id=%d',array('aljbd_consume',$c_v['cid']));
                $bd_name['name'] = $bd_name['subject'];
            }else{
                $bd_name = DB::fetch_first('select * from %t where id=%d',array('aljbd',$c_v['bid']));
            }
            $commentlist[$c_k]['name'] = $bd_name['name'];
            $commentlist[$c_k]['url'] = 'plugin.php?id=aljbd&act=view&bid='.$c_v['bid'];
            $commentlist[$c_k]['dateline'] = dgmdate($c_v['dateline'],'u');
            if(!$_GET['tb']){
                if($c_v['upid']>0){
                    $commentlist[$c_k]['fenshu'] = '--';
                }else{
                    $bustype=explode(',',$c_v['businesstype']);
                    if($bd_name[businesstype]){
                        if(count($bustype)==1&&$businesstypearr[$bustype[0]]){
                            $commentlist[$c_k]['fenshu'] = '<span style="display: block">'.$businesstypearr[$bustype[0]].' <font color="red">'.$c_v['k'].'</font>'.lang("plugin/aljht","user_php_14").'</span>';
                        }
                        if(count($bustype)==2&&$businesstypearr[$bustype[1]]){
                            $commentlist[$c_k]['fenshu'] = '<span style="display: block">'.$businesstypearr[$bustype[0]].' <font color="red">'.$c_v['k'].'</font>'.lang("plugin/aljht","user_php_15").'</span>';
                            $commentlist[$c_k]['fenshu'] .= '<span style="display: block">'.$businesstypearr[$bustype[1]].' <font color="red">'.$c_v['h'].'</font>'.lang("plugin/aljht","user_php_16").'</span>';
                        }
                        if(count($bustype)==3&&$businesstypearr[$bustype[2]]){
                            $commentlist[$c_k]['fenshu'] = '<span style="display: block">'.$businesstypearr[$bustype[0]].' <font color="red">'.$c_v['k'].'</font>'.lang("plugin/aljht","user_php_17").'</span>';
                            $commentlist[$c_k]['fenshu'] .= '<span style="display: block">'.$businesstypearr[$bustype[1]].' <font color="red">'.$c_v['h'].'</font>'.lang("plugin/aljht","user_php_18").'</span>';
                            $commentlist[$c_k]['fenshu'] .= '<span style="display: block">'.$businesstypearr[$bustype[2]].' <font color="red">'.$c_v['f'].'</font>'.lang("plugin/aljht","user_php_19").'</span>';
                        }
                    }else{
                        $commentlist[$c_k]['fenshu'] = '<span style="display: block">'.lang("plugin/aljht","user_php_20").' <font color="red">'.$c_v['h'].'</font>'.lang("plugin/aljht","user_php_21").'</span>';
                        $commentlist[$c_k]['fenshu'] .= '<span style="display: block">'.lang("plugin/aljht","user_php_22").' <font color="red">'.$c_v['f'].'</font>'.lang("plugin/aljht","user_php_23").'</span>';
                    }
                }
            }else{
                $commentlist[$c_k]['fenshu'] = '--';
            }
            if($c_v['status'] == 1){
                $commentlist[$c_k]['status_text'] = '<b style="color: red">'.lang("plugin/aljht","user_php_24").'</b>';
            }else{
                $commentlist[$c_k]['status_text'] = lang("plugin/aljht","user_php_25");
            }
            unset($bd_name);
            unset($bustype);
        }
        if($commentlist){
            T::responseJson(array(
                'code' => 0,
                'msg' => "",
                'count' => $num,
                'data' => $commentlist
            ));
        }else{
            T::responseJson(array(
                'code' => 0,
                'msg' => "",
                'count' => 0,
                'data' => array()
            ));
        }
        exit;
    }else{
        $navtitle = lang("plugin/aljht","user_php_26").' - '.$_G['cache']['plugin'][$pluginid]['title'];
        $metakeywords = $_G['cache']['plugin'][$pluginid]['keywords'];
        $metadescription = $_G['cache']['plugin'][$pluginid]['description'];
        include template('aljht:user/replylist');
    }
}else if($op == 'addresslist'){
    if($_G['mobile']){
        dheader("location: plugin.php?id=aljbdx&act=addresslist");
        exit;
    }
    if($_G['cache']['plugin']['aljbdx']){
        $addresstable = 'aljbdx';
        $rlist = C::t('#aljbdx#aljgwc_region')->fetch_all_by_upid();
        $regionlist=C::t('#aljbdx#aljgwc_region')->range();
    }else{
        $alj_lang=lang('plugin/aljgwc');
        $rlist = C::t('#aljgwc#aljgwc_region')->fetch_all_by_upid();
        $regionlist=C::t('#aljgwc#aljgwc_region')->range();
        $addresstable = 'aljgwc';
    }
    $address = C::t('#'.$addresstable.'#aljbd_address')->fetch($address_id);
    if($do == 'deladdress'){
        if($address['uid'] != $_G['uid'] && $_GET['formhash'] != FORMHASH){
            echo '0';
            exit;
        }
        C::t('#'.$addresstable.'#aljbd_address')->delete($address_id);
        echo '1';
        exit;
    }elseif($do == 'updateaddress'){
        if($address['uid'] != $_G['uid'] && $_GET['formhash'] != FORMHASH){
            echo '0';
            exit;
        }
        DB::query('UPDATE %t SET defaultAddress=0 WHERE uid=%d', array('aljbd_address', $_G['uid']));
        DB::query("update %t set defaultAddress=1 where id = %d",array('aljbd_address',$address_id));
        echo '1';
        exit;
    }else{
    
        $currpage=$_GET['page']?intval($_GET['page']):1;
        $perpage=50;
        $start=($currpage-1)*$perpage;
        $con[]='aljbd_address';
        
        $where=" where uid = %d";
        if($_G['cache']['plugin']['aljpps']['is_aljbd']){
            $where .=" and type=1";
        }else if($_G['cache']['plugin']['aljwm']){
            $where .=" and type=0";
        }
        $con[] = $_G['uid'];
        
        $num = DB::result_first('select count(*) from %t'.$where,$con);
        $con[]=$start;
        $con[]=$perpage;
        $bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY id desc limit %d,%d',$con);
        
        $bdlist = dhtmlspecialchars($bdlist);
        $addrlist = $bdlist;
        if(submitcheck('formhash')){
            if(empty($_GET['region']) && empty($_GET['citypicker'])){
                echo '<script>parent.tips("'.lang("plugin/aljht","user_php_1").'","");</script>';
                exit;
            }
            if(empty($_GET['addressDetail'])){
                echo '<script>parent.tips("'.lang("plugin/aljht","user_php_2").'","");</script>';
                exit;
            }
            if(empty($_GET['fullName'])){
                echo '<script>parent.tips("'.lang("plugin/aljht","user_php_3").'","");</script>';
                exit;
            }
            if(empty($_GET['mobile']) && empty($_GET['phoneCode'])){
                echo '<script>parent.tips("'.lang("plugin/aljht","user_php_4").'","");</script>';
                exit;
            }
            if($_G['mobile']){
                $citypicker = array_filter(explode(' ', trim($_GET['citypicker'])));
            }else{
                $citypicker = array_filter(explode('/', trim($_GET['citypicker'])));
            }
            $insertarray = array(
                'province' => $citypicker[0],
                'city' => $citypicker[1],
                'district' => $citypicker[2],
                'region' => $_GET['region'],
                'region1' => $_GET['subregion'],
                'region2' => $_GET['region1'],
                'addressDetail' => $_GET['addressDetail'],
                'post' => $_GET['post'],
                'fullName' => $_GET['fullName'],
                'mobile' => $_GET['mobile'],
                'phoneSection' => $_GET['phoneSection'],
                'phoneCode' => $_GET['phoneCode'],
                'phoneExt' => $_GET['phoneExt'],
                'defaultAddress' => $_GET['defaultAddress'],
                'dateline' => TIMESTAMP,
                'uid' => $_G['uid'],
                'username' => $_G['username'],
            );
            if($_GET['defaultAddress']){
                C::t('#'.$addresstable.'#aljbd_address')->update_by_uid_defaultAddress($_G['uid']);
            }
            if($address){
                if($address['uid'] != $_G['uid']){
                    echo '<script>parent.tips("'.lang("plugin/aljht","user_php_5").'","");</script>';
                    exit;
                }
                C::t('#'.$addresstable.'#aljbd_address')->update($address_id,$insertarray);
            }else{
                if($num >20){
                    echo '<script>parent.tips("'.lang("plugin/aljht","user_php_6").'","");</script>';
                    exit;
                }
                C::t('#'.$addresstable.'#aljbd_address')->insert($insertarray);
            }
            echo '<script>parent.tips("'.lang('plugin/aljbd','s53').'","plugin.php?id=aljht&act=admin&op=addresslist'.$urlmod.'");</script>';
            exit;
        }
        
        $navtitle = lang("plugin/aljht","user_php_27").' - '.$_G['cache']['plugin'][$pluginid]['title'];
        $metakeywords = $_G['cache']['plugin'][$pluginid]['keywords'];
        $metadescription = $_G['cache']['plugin'][$pluginid]['description'];
        include template('aljht:user/addresslist');
    }
}else{
    require_once DISCUZ_ROOT . './source/plugin/aljht/include/admin/order/common.php';
    
    $keyword = addcslashes($_GET['search'], '%_');
	$payment = intval($_GET['payment']);


	$page = intval($_GET['page']);
	$currpage = $page?$page:1;
	$perpage = 10;
	$start = ($currpage-1)*$perpage;
	
    $conn[] ='aljbd_goods_order';
    $where = 'where 1 and pid = 0 ';
	
    $where .= 'and pid = 0 and uid = %d ';
    $conn[] = $_G['uid'];
		
	if($_GET['status']){
		$where .= ' and status = %d';
		$conn[] = $status;
	}
	if($_GET['payment']){
		$where .= ' and payment = %d';
		$conn[] = $payment;
	}
	if($_GET['start']){
		$conn[] =strtotime($_GET['start']);
		$where.=" and submitdate >= %d";
	}
	if($_GET['end']){
		$conn[] =strtotime($_GET['end']);
		$where.=" and submitdate <= %d";
	}
	if($_GET['search']){
		if($_GET['ordertype']){
			if($_GET['ordertype'] == 1){
				$conn[] ='%'. $keyword .'%';
				$where.=" and orderid like %s";
			}elseif($_GET['ordertype'] == 2){
				$conn[] ='%'. $keyword .'%';
				$where.=" and stitle like %s";
			}else if($_GET['ordertype'] == 3){
				$conn[] =$keyword;
				$where.=" and shop_id = %d";
			}else if($_GET['ordertype'] == 4){
                $conn[] ='%' . $keyword . '%';
                $conn[] ='%' . $keyword . '%';
                $where.=" and (uid like %s or username like %s)";
            }
		}else{
			$conn[] ='%' . $keyword . '%';
			$conn[] ='%' . $keyword . '%';
			$conn[] ='%' . $keyword . '%';
			$where.=" and (orderid like %s or stitle like %s or remarks like %s)";
		}
	}

	$num = DB::result_first('select count(*) from %t '.$where,$conn);
	$start=($currpage-1)*$perpage;
	$where .= ' order by submitdate desc';
	$where .= ' limit %d,%d';
	$conn[] = $start;
	$conn[] = $perpage;

	$orderlist = DB::fetch_all('select * from %t '.$where,$conn);


	$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljht&act=user&op=orderlist&ord='.$_GET['ord'].'&status='.$_GET['status'].'&search='.$_GET['search'].$urlmod, 0, 11, false, false);
	$navtitle = '&#35746;&#21333;&#31649;&#29702;-'.$_G['cache']['plugin']['aljbd']['title'];
	$metakeywords =  $bd['other']?$bd['other']:$_G['cache']['plugin']['aljbd']['keywords'];
	$metadescription = $_G['cache']['plugin']['aljbd']['description'];
    include template('aljht:user/orderlist');
}
//dis'.'m.t'.'ao'.'bao.com
?>