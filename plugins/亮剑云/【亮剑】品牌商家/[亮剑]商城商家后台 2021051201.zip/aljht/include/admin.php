<?php

/*
 * ����: Discuz!����������
 * ����֧��: http://www.dzx30.com
 * ��ϵQQ: 578933760
 * ����˵��:������̨-�������̳�
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$atheroparray = array(
    'album',
    'refundlist',
    'collection',
    'addresslist',
    'videolist',
    'appointment_list',
    'pagelist',
    'orderlist',
    'point',
    'attestation',
    'consume',
    'notice',
    'goods',
    'transferorder',
    'assets',
    'cash',
    'staffStoreList'
);
$adminoparray = array(
    'yhzqx',
    'vip',
    'distribution',
    'ather',
    'rubbish',
    'help',
    'aljbd',
    'administrators',
    'listaddress',
);

$oparray = array_merge($atheroparray,$adminoparray);
if(in_array($op,$adminoparray)){
    if(!$administrators){
        $aljht_tips = lang("plugin/aljht","admin_php_1");
        include template('aljht:admin/pogressbar');
        exit;
    }
}
if(in_array($op,$oparray)){
    require_once 'source/plugin/aljht/include/admin/'.$op.'.php';
}else{
    require_once 'source/plugin/aljht/include/admin/brand.php';
}
//From: Dism_taobao-com
?>