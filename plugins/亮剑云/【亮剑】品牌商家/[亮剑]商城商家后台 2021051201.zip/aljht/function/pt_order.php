<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$grouptime=$_G['cache']['plugin']['aljspt']['grouptime']?intval($_G['cache']['plugin']['aljspt']['grouptime'])*3600 : 86400;

$time=TIMESTAMP-$grouptime;

//�����ŵ�δ���Ÿ���Ϊƴ��ʧ��
function pt_grouporderstate_auto(){
    global $time,$_G;
    
    $Gcount=DB::result_first('select count(*) from %t where groupopentime < %d and grouporderstatus=%d',array('aljspt_collage_order',$time,1));
    
    $Limit = mt_rand(0,$Gcount-1);
    $grouporder=DB::fetch_first('select * from %t where groupopentime < %d and grouporderstatus=%d limit %d,%d',array('aljspt_collage_order',$time,1,$Limit,1));
    
    if($grouporder){
        DB::update('aljspt_collage_order',array('grouporderstatus'=>3), array('id' => $grouporder['id'],'grouporderstatus'=>1));
    }
}
/*1=��֧��=default
2=��֧��
3=�ѷ���
4=���ջ�
5=������
6=���˿�
*/
//����δ������֧���Ķ���״̬
function pt_orderstate_auto(){
    global $time,$_G;
    $Ocount=DB::result_first('select count(*) from %t where opentime < %d and commodity_type=%d and status=%d and amount!=1',array('aljbd_goods_order',$time,2,2));
    
    $Limit = mt_rand(0,$Ocount-1);
    $pt_order=DB::fetch_first('select * from %t where opentime < %d and commodity_type=%d and status=%d and amount!=1 limit %d,%d',array('aljbd_goods_order',$time,2,2,$Limit,1));
    
    $pt_group=DB::fetch_first('select * from %t where grouporderid=%s',array('aljspt_collage_order',$pt_order['collage_order']));
    
    if($pt_group['grouporderstatus']==3 
    && DB::update('aljbd_goods_order',array('status'=>6), array('orderid' => $pt_order['orderid'],'status'=>2)) 
    && DB::update('aljqb_payorder',array('status'=>2, 'overtime' => TIMESTAMP), array('orderid' => $pt_order['orderid'],'status'=>1))
    ){
        
        $result = pt_refund_auto($pt_order);
        
        if($result['code'] == 200) {
            if($_G['cache']['plugin']['aljbdx']){
                DB::query("update %t set status=6 WHERE orderid=%s ",array('aljbd_goods_order_list',$pt_order['orderid']));
            }
            pr_gaddnum($pt_order);
            if(file_exists(DISCUZ_ROOT ."source/plugin/aljhtx/include/pt_fail_send_template_auto.php")){
                require_once DISCUZ_ROOT .'source/plugin/aljhtx/include/pt_fail_send_template_auto.php';
            }
        }else{
            DB::update('aljbd_goods_order',array('status'=>2), array('orderid' => $pt_order['orderid'],'status'=>6));
            DB::update('aljqb_payorder',array('status'=>1, 'overtime' => TIMESTAMP), array('orderid' => $pt_order['orderid'],'status'=>2));
        }

    }
}
//ƴ����Ʒ�Զ��˿���
function pr_gaddnum($order){
	$orderlist = DB::fetch_all('select * from %t where orderid=%s',array('aljbd_goods_order_list',$order['orderid']));
	foreach($orderlist as $k => $v){
		DB::query('update %t set amount=amount+%d where id=%d', array('aljbd_goods',$v['num'],$v['goods_id']));
		$goods=C::t('#aljbd#aljbd_goods')->fetch($v['goods_id']);
		if($goods['attr_sku']){
			$attr_sku = unserialize($goods['attr_sku']);
			foreach($attr_sku as $sk => $sv){
				if($v['path'] == $sv['path']){
					$attr_sku[$sk]['stock'] = $attr_sku[$sk]['stock']+$v['num'];
				}
			}
			C::t('#aljbd#aljbd_goods')->update($v['goods_id'],array('attr_sku'=>serialize($attr_sku)));
			unset($attr_sku);
			unset($goods);
		}
	}
}
//�Զ��˿�
function pt_refund_auto($pt_order){
    global $_G,$queue,$config;
    require_once DISCUZ_ROOT .'source/plugin/aljqb/class/Qbapi.class.php';
    
    $qbapi = new Qbapi();
    $queue = $qbapi;
    $pay_order = DB::fetch_first('select * from %t where orderid=%s',array('aljqb_payorder',$pt_order['orderid']));
    $pt_order['buyer'] = $pay_order['transaction_id'];
    $aljqbsettings = $qbapi -> getsettings();
    require_once DISCUZ_ROOT .'source/plugin/aljqb/function/function_core.php';
    if($aljqbsettings['refundstype'] == 1){
        
        if($pt_order['admin'] == 'wxpay' || $pt_order['admin'] == 'APP'){
            $senddata['out_refund_no'] = $pt_order['orderid'];
            if($pt_order['admin'] == 'APP'){
                $senddata['mch_id'] = $config['mchid2'];
                $senddata['appid'] = $config['appid2'];
                $senddata['op_user_id'] = $config['mchid2'];
                $senddata['key'] = $config['key2'];
            }else if($pt_order['admin'] == 'wxpay'){
                $senddata['mch_id'] = $config['mchid'];
                $senddata['appid'] = $config['appid'];
                $senddata['op_user_id'] = $config['mchid'];
                $senddata['key'] = $config['key'];
            }
            $senddata['orderid'] = $pt_order['buyer'];
            $senddata['price'] = $pt_order['price'];
            $senddata['refund_fee'] = $pt_order['price'];
            $wxrefund = wxpayrefund($senddata);
                                    
            $data = xmlToArray($wxrefund);
            
            if($data['result_code'] == 'SUCCESS'){
                $result['code'] = 200;
            }
        }else if($pt_order['admin'] == 'alipay'){
            $alipay_refund = alipayrefund($pt_order);
            $result = json_decode($alipay_refund,true);
            
            if($result['alipay_trade_refund_response']['msg'] == 'Success'){
                $result['code'] = 200;
            }else{
                if(strtolower(CHARSET) == 'gbk') {
                    $error = diconv($alipay_refund,'utf-8','gbk');
                }
                $qbapi ->insertLog('alipay_refund '.$error);
            }
        }else if($pt_order['admin'] == 'qianfanapp'){
            $data = qianfanapp_refund($pay_order['transaction_id'],$pay_order['aljorderid'],$pt_order['price']*100);
            if($data['ret'] == '0'){
                $result['code'] = 200;
            }else{
                if(strtolower(CHARSET) == 'gbk') {
                    $error = diconv($data['text'],'utf-8','gbk');
                }
                $qbapi ->insertLog('qianfanapp_refund '.$error);
            }
        }else {
            $rmb = substr(sprintf("%.3f",$pt_order['price']),0,-1);
            $queuearray = array(
                'app_name' => 'aljbdx',
                'app_type' => 'aljbdxrefund',
                'app_phone' => '123456789',
                'app_ip' => '123456789',
            );
            $balancearray = array(
                'type'=> 'charge',
                'uid'=>$pt_order['uid'],
                'price' => $rmb,
                'orderid'=> $pt_order['orderid'],
                'desc'=> str_replace(array('{title}','{price}'),array($pt_order['stitle'],$rmb),$_G['cache']['plugin']['aljspt']['refund_tips']),
            );
            $result = $qbapi->balance($queuearray,$balancearray);
        }
    }else{
        $rmb = substr(sprintf("%.3f",$pt_order['price']),0,-1);
            $queuearray = array(
                'app_name' => 'aljbdx',
                'app_type' => 'aljbdxrefund',
                'app_phone' => '123456789',
                'app_ip' => '123456789',
            );
            $balancearray = array(
                'type'=> 'charge',
                'uid'=>$pt_order['uid'],
                'price' => $rmb,
                'orderid'=> $pt_order['orderid'],
                'desc'=> str_replace(array('{title}','{price}'),array($pt_order['stitle'],$rmb),$_G['cache']['plugin']['aljspt']['refund_tips']),
            );
            $result = $qbapi->balance($queuearray,$balancearray);
    }
    
    return $result;

}
//From: Dism_taobao-com
?>