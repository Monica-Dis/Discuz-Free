<?php

/*
 * ����: Discuz!����������
 * ����֧��: http://www.dzx30.com
 * ��ϵQQ: 578933760
 * ����˵��:�������̳�
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$_G['setting']['hookscript'] = array();
function htips($aljht_tips, $url = ''){
    define('PLUGIN_ID', 'aljhtx');
    define('PLUGIN_PATH', 'source/plugin/' . PLUGIN_ID . '/');
    include template('aljhtx:showmessage');
}


require_once 'source/plugin/aljht/lang/lang.php';
foreach(DB::fetch_all('select * from %t',array('common_plugin')) as $cpv){
    $cparray[$cpv['identifier']] = $cpv;
}

if(!$cparray['aljbd']){
    $tips = lang("plugin/aljht","aljht_inc_php_10");
    htips($tips, '<a style="color: rgb(30, 159, 255);" target="_blank" href="http://dism.taobao.com/?@aljbd.plugin">' . lang("plugin/aljht","aljht_inc_php_1") . '</a>');
    exit;
}

if(!$cparray['aljgwc']){
    $tips = lang("plugin/aljht","aljht_inc_php_11");
    htips($tips, '<a style="color: rgb(30, 159, 255);" target="_blank" href="http://dism.taobao.com/?@aljgwc.plugin">' . lang("plugin/aljht","aljht_inc_php_2") . '</a>');
    exit;
}

if($_GET['op'] == 'distribution' && !$cparray['aljsfx']){
    $tips = lang("plugin/aljht","aljht_inc_php_12");
    htips($tips, '<a style="color: rgb(30, 159, 255);" target="_blank" href="http://dism.taobao.com/?@aljsfx.plugin">' . lang("plugin/aljht","aljht_inc_php_3") . '</a>');
    exit;
}
if($_GET['op'] == 'help' && !$cparray['aljhelp']){
    $tips = lang("plugin/aljht","aljht_inc_php_13");
    htips($tips, '<a style="color: rgb(30, 159, 255);" target="_blank" href="http://dism.taobao.com/?@aljhelp.plugin">' . lang("plugin/aljht","aljht_inc_php_4") . '</a>');
    exit;
}
if($_GET['op'] == 'videolist' && !$cparray['aljsp']){
    $tips = lang("plugin/aljht","aljht_inc_php_14");
    htips($tips, '<a style="color: rgb(30, 159, 255);" target="_blank" href="http://dism.taobao.com/?@aljsp.plugin">' . lang("plugin/aljht","aljht_inc_php_5") . '</a>');
    exit;
}
if($_GET['op'] == 'appointment_list' && !$cparray['aljsyy']){
    $tips = lang("plugin/aljht","aljht_inc_php_15");
    htips($tips, '<a style="color: rgb(30, 159, 255);" target="_blank" href="http://dism.taobao.com/?@aljsyy.plugin">' . lang("plugin/aljht","aljht_inc_php_6") . '</a>');
    exit;
}
if($_GET['op'] == 'vip' && !$cparray['aljqb']){
    $tips = lang("plugin/aljht","aljht_inc_php_16");
    htips($tips, '<a style="color: rgb(30, 159, 255);" target="_blank" href="http://dism.taobao.com/?@aljqb.plugin">' . lang("plugin/aljht","aljht_inc_php_7") . '</a>');
    exit;
}
if($_GET['op'] == 'vip' && !$cparray['aljbdx']){
    $tips = lang("plugin/aljht","aljht_inc_php_17");
    htips($tips, '<a style="color: rgb(30, 159, 255);" target="_blank" href="http://dism.taobao.com/?@aljbdx.plugin">' . lang("plugin/aljht","aljht_inc_php_8") . '</a>');
    exit;
}
if($_GET['status'] == 'dx' && !$cparray['aljdx']){
    $tips = lang("plugin/aljht","aljht_inc_php_18");
    htips($tips, '<a style="color: rgb(30, 159, 255);" target="_blank" href="http://dism.taobao.com/?@aljdx.plugin">' . lang("plugin/aljht","aljht_inc_php_9") . '</a>');
    exit;
}

$is_plugin = $cparray['aljbd'];
$is_plugin_gwc = $cparray['aljgwc'];
$is_plugin_bdx = $cparray['aljbdx'];

$yhzqx = 0;
if(!$is_plugin || (!$is_plugin_gwc && !$is_plugin_bdx)){
	//echo('&#35831;&#20808;&#36141;&#20080;&#23433;&#35013;&#20027;&#25554;&#20214;&#21697;&#29260;&#21830;&#23478;&#19982;&#23376;&#25554;&#20214;&#36141;&#29289;&#36710;');
    $aljht_tips = '&#35831;&#20808;&#36141;&#20080;&#23433;&#35013;&#20027;&#25554;&#20214;&#21697;&#29260;&#21830;&#23478;&#19982;&#23376;&#25554;&#20214;&#36141;&#29289;&#36710;';
    include template('aljht:admin/pogressbar');
    exit;
}

if (file_exists("source/plugin/aljbd/act/gmap.php")) {
    require_once 'source/plugin/aljbd/act/gmap.php';
}
if($is_plugin_gwc){
    
    require_once 'source/plugin/aljgwc/lang/lang.php';
}

require_once 'source/plugin/aljbd/lang/lang.php';
require_once 'source/plugin/aljht/function/sku.php';
$is_aljdx = $cparray['aljdx'];
if($is_aljdx){
	require_once 'source/plugin/aljdx/function_dx.php';
}
$is_plugin_sp = $cparray['aljsp'];
$is_plugin_syy = $cparray['aljsyy'];
$is_plugin_gz = $cparray['aljgz'];
$is_plugin_js = $cparray['aljjs'];
$settings=C::t('#aljbd#aljbd_setting')->range();
$is_openarray = array('iswatermark','is_daohang','alipay','malipay','isextcredit','pic','isgo','isnews','isyouh','ispd','isrewrite','islogo','isqq','ista','sjurl','sj_index_lz','time');
foreach($settings as $k => $v){
	if(in_array($k,$is_openarray)){//�����ж�
		if($v['value'] == 1){
			$_G['cache']['plugin']['aljbd'][$k] = 1;
		}elseif($v['value'] == 2){
			$_G['cache']['plugin']['aljbd'][$k] = 0;
		}
	}else{
		if($v['value']){
			$_G['cache']['plugin']['aljbd'][$k] = htmlspecialchars_decode($v['value']);//ͬ����������ֵ���������б���
		}
	}
}
$pluginid = 'aljht';
$pluginid_aljbd = 'aljbd';
$act = addslashes($_GET['act']);
$op = addslashes($_GET['op']);
$do = addslashes($_GET['do']);
$mod = addslashes($_GET['mod']);
$ord = addslashes($_GET['ord']);
if($mod){
	$urlmod = '&mod='.$mod;
}
if($_GET['ajax'] == 'yes'){
    $urlmod .= '&ajax=yes';
}
if($_GET['dzAdmin'] == 1){
	$urlmod .= '&dzAdmin=1';
}
if($_GET[b] == 1){
    $urlmod .= '&b=1&bid='.intval($_GET['bid']);
}
if($_GET['sc_dh'] == 1){
	$urlmod .= '&sc_dh=1';
}
if($_GET['wm'] == 'yes'){
	$urlmod .= '&wm=yes';
}
if($_GET['store'] == 'yes'){
	$urlmod .= '&store=yes';
}
$aljht_config = $_G['cache']['plugin']['aljht'];
$typelist=C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type')->range();
$rlist=C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_region')->range();
$bid = intval($_GET['bid']);//�̼�
$gid = intval($_GET['gid']);//��Ʒ
$nid = intval($_GET['nid']);//�
$cid = intval($_GET['cid']);//�Ż�ȯ
$aid = intval($_GET['aid']);//���
$vid = intval($_GET['vid']);//��ƵID
$paid = intval($_GET['paid']);//�˵�
$address_id = intval($_GET['address_id']);//�˵�
$login_callback = 'member.php?mod=logging&action=login&referer=plugin.php?id=aljht%26act='.$act.'%26op='.$op.'%26mod='.$mod.'%26ord='.$ord;
if(empty($_G['uid'])){
	dheader("location:".$login_callback);
	exit;
}
//$bdlistall=C::t('#aljbd#aljbd')->range();
//$bdlistall = dhtmlspecialchars($bdlistall);
$businesstype = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljbd'] ['businesstype']));
foreach($businesstype as $key=>$value){
	$arr=explode('=',$value);
	$businesstypearr[$arr[0]]=$arr[1];
}
if($settings['image_path']['value']){
	$image_path = $settings['image_path']['value'];
}else{
	$image_path = 'source/plugin/'.$pluginid_aljbd.'/images/';
}
$fare_desc = array('1'=>'&#21253;&#37038;','2'=>'&#21040;&#20184;');
$admingroups = unserialize($_G['cache']['plugin']['aljbd']['managegroups']);
if((in_array($_G['groupid'],$admingroups) || in_array($_G['groupid'],unserialize($_G['cache']['plugin']['aljhtx']['gids']))) && (!$mod || $_GET['wm'] == 'yes')){
	$administrators = 1;
}

if($settings['is_self_support']['value']==1 && !$administrators) {
    $ss_act = array('adddp');
    if(in_array($do,$ss_act)){
        header('location: plugin.php?id=aljbd');
        exit;
    }
}
$checksign = 99999999;

$brandnum=C::t('#aljbd#aljbd_usergroup')->fetch($_G['groupid']);
$my_bd = DB::result_first('select count(*) from %t where uid=%d and rubbish=0',array('aljbd',$_G['uid']));
if($_G['cache']['plugin']['aljbd'] && file_exists("source/plugin/aljbd/include/newparameter.php")){
    require_once 'source/plugin/aljbd/include/newparameter.php';
}
if($act == 'admin' && $op == 'orderlist' && $ord == 'ge' && !$do){
	dheader("location: plugin.php?id=aljht&act=user&op=orderlist");
	exit;
}else if($act == 'admin' && $op == 'addresslist' && !$do){
	dheader("location: plugin.php?id=aljht&act=user&op=addresslist");
	exit;
}else if($act == 'admin' && $op == 'collection' && $_GET['ajax'] != 'yes'){
	dheader("location: plugin.php?id=aljht&act=user&op=collection");
	exit;
}else if($act == 'admin' && $op == 'appointment_list' && $_GET['ajax'] != 'yes' && $_GET['state'] == 2){
	dheader("location: plugin.php?id=aljht&act=user&op=appointment_list&state=2");
	exit;
}

if((empty($my_bd) && !$staff && $op != 'orderlist' && $do != 'adddp' && $do != 'attr' && $do != 'del_attr' && !$administrators) && $act != 'getregion' && $act != 'gettype' && $op != 'collection' && $op != 'appointment_list' && $op != 'addresslist' && $op != 'replylist' && $op != 'wallet'){
	if($_G['mobile']){
		dheader("location: plugin.php?id=aljbd&act=orderlist");
	}else{
		dheader("location: plugin.php?id=aljht&act=user&op=orderlist");
	}
    exit;
}

if($administrators){
	$orderurl = 'plugin.php?id=aljht&act=admin&op=orderlist';
}elseif($my_bd){
	$orderurl = 'plugin.php?id=aljht&act=admin&op=orderlist&mod=my&ord=dianpu';
}else{
	$orderurl = 'plugin.php?id=aljht&act=admin&op=orderlist&mod=my&ord=ge';
}
$group_array = C::t('common_usergroup')->range();
$index_url = 'plugin.php?id=aljbd';
$paymentarr = array('1' => lang("plugin/aljht","aljht_inc_php_19"),'2' => lang("plugin/aljht","aljht_inc_php_20"),'3' => 'APP'.lang("plugin/aljht","aljht_inc_php_21"),'5'=>lang("plugin/aljht","aljht_inc_php_22").'('.$_G['setting']['extcredits'][$config['ext_aljbd']]['title'].')','6'=>lang("plugin/aljht","aljht_inc_php_23"),'7'=>lang("plugin/aljht","aljht_inc_php_24"));
$refund_type_array = array('1'=>lang("plugin/aljht","aljht_inc_php_25"),'2'=>lang("plugin/aljht","aljht_inc_php_26"));
if($_G['cache']['plugin']['aljwm']){//refund_reason
	$refund_reason = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljwm']['refund_reason']));
	$r_kk = 3;
	foreach($refund_reason as $r_v){
		$refund_type_array[$r_kk] = $r_v;
		$r_kk++;
	}
}
if($_G['cache']['plugin']['aljbd']['iswatermark']){
	require_once DISCUZ_ROOT.'source/plugin/aljbd/class/class_image.php';
	$image = new aljbd_image;
}
//debug($act);
if(DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljbgp'))){
	$brandtips = htmlspecialchars_decode($settings['aljbgp_brandtips']['value']);
	$goodstips = htmlspecialchars_decode($settings['aljbgp_goodstips']['value']);
	$noticetips = htmlspecialchars_decode($settings['aljbgp_noticetips']['value']);
	$consumetips = htmlspecialchars_decode($settings['aljbgp_consumetips']['value']);
	$albumtips = htmlspecialchars_decode($settings['aljbgp_albumtips']['value']);
}
$price_unit = '&#65509;';
$price_symbol = '&#20803;';
$geturl = array(
    'id' => $pluginid,
    'act' => 'admin',
    'op' => $op,
    'do' => $do,
    'search' => $_GET['search'],
    'ajax' => $_GET['ajax'],
);


require_once $common_path.'class/class_aljhtx.php';
$path = 'source/plugin/'.$pluginid;
$pluginurl = 'plugin.php?id='.$pluginid;
$iframe_nav = DB::fetch_all('select * from %t where hide=0 order by displayorder asc,id asc',array('aljht_iframe_nav'));
if($act == 'admin'){
	include 'source/plugin/aljht/include/admin.php';
}else if($act == 'iframe'){
	include 'source/plugin/aljht/include/iframe.php';
}else if($act == 'user'){
	include 'source/plugin/aljht/include/user.php';
}else if($act == 'getregion'){
	
	if($do == 'address'){
		if($_GET['upid']){
			$r_list=C::t('#aljgwc#aljgwc_region')->fetch_all_by_upid($_GET['upid']);
		}
		if($op == 'subregion'){
			$text = lang("plugin/aljht","aljht_inc_php_27");
			$name = 'region1';
		}else{
			$text = lang("plugin/aljht","aljht_inc_php_28");
			$func = 'onchange="lj_subregion();"';
			$name = 'subregion';
		}
		if($r_list){
			$str .= '<select class="form-control" name="'.$name.'" id="'.$name.'" '.$func.' ><option value="0">'.$text.'</option>';
			foreach($r_list as $rid => $r){
				$str.='<option value="'.$r['id'].'">'.$r['name'].'</option>';
			}
			$str .= '</select>';
		}
	}else{
		if($_GET['upid']){
				$r_list=C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_region')->fetch_all_by_upid('','',$_GET['upid']);
		}
		if($op == 'subregion'){
			$text = lang("plugin/aljht","aljht_inc_php_29");
			$name = 'region1';
		}else{
			$text = lang("plugin/aljht","aljht_inc_php_30");
			$func = 'onchange="lj_subregion();"';
			$name = 'subregion';
		}
		if($r_list){
			$str .= '<select class="form-control" name="'.$name.'" id="'.$name.'" '.$func.' ><option value="0">'.$text.'</option>';
			foreach($r_list as $rid => $r){
				$str.='<option value="'.$r['catid'].'">'.$r['name'].'</option>';
			}
			$str .= '</select>';
		}
	}
	echo $str;
}else if($act == 'gettype'){
	if($_GET['upid']){
		if($do == 'goods'){
			if($_GET['dzAdmin'] == 1){
				$t_list=C::t('#aljtsc#aljtsc_type')->fetch_all_by_upid_admin($_GET['upid']);
			}else{
				$t_list=C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type_goods')->fetch_all_by_upid($_GET['upid']);
			}
		}elseif($do == 'notice'){
			$t_list=C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type_notice')->fetch_all_by_upid($_GET['upid']);
		}elseif($do == 'consume'){
			$t_list=C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type_consume')->fetch_all_by_upid($_GET['upid']);
		}elseif($do == 'video'){
			$t_list=C::t('#aljsp#'.$pluginid_aljbd.'_type_video')->fetch_all_by_upid($_GET['upid']);
		}elseif($do == 'btype'){
			if($_GET['dzAdmin'] == 1){
				$t_list=DB::fetch_all('select * from %t where store_id=%d and upid=%d  and type=0 ',array('aljbd_type_brand',$bid,$_GET['upid']));
			}else{
				$t_list=DB::fetch_all('select * from %t where bid=%d and upid=%d  and type=0 ',array('aljbd_type_brand',$bid,$_GET['upid']));
			}
        }else{
			$t_list=C::t('#'.$pluginid_aljbd.'#'.$pluginid_aljbd.'_type')->fetch_all_by_upid($_GET['upid']);
		}
	}
	if($op == 'subtype'){
		$text = lang("plugin/aljht","aljht_inc_php_31");
		$name = 'subtype3';
	}else{
		$text = lang("plugin/aljht","aljht_inc_php_32");
        if($do == 'btype') {
            $name = 'bsubtypeid';
        }else{
            $func = 'onchange="lj_subtype();"';
            $name = 'subtype';
        }
	}
	if($t_list){
		$str .= '<select class="form-control" name="'.$name.'" id="'.$name.'" '.$func.' ><option value="0">'.$text.'</option>';
		foreach($t_list as $rid => $r){
			$str.='<option value="'.$r['id'].'">'.$r['subject'].'</option>';
		}
		$str .= '</select>';
	}
	echo $str;
}else if ($act == 'regionimport') {
    if ($_GET['upid']) {
        $upid = $_GET['upid'];
        $carray[] = 'common_district';
        if ($upid) {
            $carray[] = $upid;
            $conn = ' where upid=%d';
        } else {
            $conn = ' where upid=0';
        }
        $rlist = DB::fetch_all('select * from %t ' . $conn, $carray, 'id');
        $trid = 'id';
        $trname = 'name';
        if (is_array($rlist)) {
            foreach ($rlist as $key => $val) {
                $returnarray[$val[$trid]] = diconv($val[$trname], CHARSET, 'utf-8');
            }
            echo json_encode($returnarray);
            exit;
        }
    }
}else{
	include 'source/plugin/aljht/include/admin.php';
}
function getaljurl($geturl,$param){
	if($param){
		foreach($param as $k => $v){
		$geturl[$k] = $v;
		}
	}
	require_once libfile('function/home');
	return 'plugin.php?'.url_implode($geturl);
}
function del_brand_all($bid,$rubbish){
    global $_G;
	//�̼�
	C::t('#aljbd#aljbd')->update($bid,array('rubbish'=>$rubbish));
	//�̼�����
	DB::update('aljbd_comment',array('rubbish'=>$rubbish), array('bid'=>$bid));
	//��Ʒ
	if($_G['cache']['plugin']['aljtsq']){
		DB::update('aljbd_goods',array('rubbish'=>$rubbish), array('bid'=>$bid,'store_id'=>0));
	}else{
		DB::update('aljbd_goods',array('rubbish'=>$rubbish), array('bid'=>$bid));
	}
	//����
	if($_G['cache']['plugin']['aljgwc'] || $_G['cache']['plugin']['aljbdx']){
		DB::update('aljbd_comment_goods',array('rubbish'=>$rubbish), array('bid'=>$bid));
	}
	//����
	DB::update('aljbd_notice',array('rubbish'=>$rubbish), array('bid'=>$bid));
	//����
	DB::update('aljbd_comment_notice',array('rubbish'=>$rubbish), array('bid'=>$bid));
	//�Ż�ȯ
	DB::update('aljbd_consume',array('rubbish'=>$rubbish), array('bid'=>$bid));
	//����
	DB::update('aljbd_comment_consume',array('rubbish'=>$rubbish), array('bid'=>$bid));
	//���
	DB::update('aljbd_album',array('rubbish'=>$rubbish), array('bid'=>$bid));
	DB::update('aljbd_album_attachments',array('rubbish'=>$rubbish), array('bid'=>$bid));
	//���̵���
	DB::update('aljbd_page',array('rubbish'=>$rubbish), array('bid'=>$bid));
	//�̼���Ƶ
	$is_plugin = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljsp'));
	if($is_plugin){
		DB::update('aljbd_video',array('rubbish'=>$rubbish), array('bid'=>$bid));
	}
}
function close_brand_all($bid,$rubbish){
    global $_G;
    //�̼�
    C::t('#aljbd#aljbd')->update($bid,array('status'=>$rubbish));
    if($rubbish == 4){//�ر�
        DB::query('update %t set state=1  where bid = %d',array('aljbd_goods',$bid));
        $status = 3;
    }else{
        DB::query('update %t set state=0  where bid = %d',array('aljbd_goods',$bid));
        $status = 0;
    }
    DB::query('update %t set status=%d  where bid = %d',array('aljbd_notice',$status,$bid));
    DB::query('update %t set status=%d  where bid = %d',array('aljbd_consume',$status,$bid));
    DB::query('update %t set status=%d  where bid = %d',array('aljbd_album',$status,$bid));
    //�̼���Ƶ
    $is_plugin = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljsp'));
    if($is_plugin){
        DB::query('update %t set status=%d  where bid = %d', array('aljbd_video',$status, $bid));
    }
}
function del_brand_all_1($bid){
    global $_G;
	//�̼�
	$bdlist=C::t('#aljbd#aljbd')->fetch($bid);
	unlink($bdlist['logo']);
	C::t('#aljbd#aljbd')->delete($bid);
	//�̼�����
	DB::query('DELETE FROM %t WHERE bid=%d',array('aljbd_comment',$bid));
	//��Ʒ
	foreach(C::t('#aljbd#aljbd_goods')->fetch_all_by_uid_bid('',$bid) as $del_g){
		for ($i = 1; $i <= 5; $i++) {
			$pic = 'pic' . $i;
			unlink($del_g[$pic]);
			unlink($del_g[$pic].'.60x60.jpg');
			unlink($del_g[$pic].'.205x205.jpg');
			unlink($del_g[$pic].'.470x470.jpg');
		}
		C::t('#aljbd#aljbd_goods')->delete($del_g['id']);
	}
	//��Ʒ����
	if($_G['cache']['plugin']['aljgwc'] || $_G['cache']['plugin']['aljbdx']){
		DB::query('DELETE FROM %t WHERE bid=%d',array('aljbd_comment_goods',$bid));
	}
	//����
	DB::query('DELETE FROM %t WHERE bid=%d',array('aljbd_notice',$bid));
	//��������
	DB::query('DELETE FROM %t WHERE bid=%d',array('aljbd_comment_notice',$bid));
	//�Ż�ȯ
	foreach(C::t('#aljbd#aljbd_consume')->fetch_all_by_uid_bid('',$bid) as $del_c){
		unlink($del_c['pic']);
		C::t('#aljbd#aljbd_consume')->delete($del_c['id']);
	}
	//�Ż�ȯ����
	DB::query('DELETE FROM %t WHERE bid=%d',array('aljbd_comment_consume',$bid));
	//���
	foreach(C::t('#aljbd#aljbd_album')->fetch_all_by_uid_bid('',$bid) as $del_a){
		C::t('#aljbd#aljbd_album')->delete($del_c['id']);
		if(C::t('#aljbd#aljbd_album_attachments')->conut_by_aid($del_c['id'])){
			foreach(C::t('#aljbd#aljbd_album_attachments')->fetch_all_by_status(' where aid='.$del_c['id']) as $atid){
				unlink($atid['pic']);
				unlink($atid['pic'].'.72x72.jpg');
				unlink($atid['pic'].'.100x100.jpg');
				unlink($atid['pic'].'.550x550.jpg');
				C::t('#aljbd#aljbd_album_attachments')->delete($atid['id']);
			}
		}
	}
	//���̵���
	DB::query('DELETE FROM %t WHERE bid=%d',array('aljbd_page',$bid));
	//�̼���Ƶ
	$is_plugin = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljsp'));
	if($is_plugin){
		foreach(C::t('#aljsp#aljbd_video')->fetch_all_by_uid_bid('',$bid) as $del_v){
			unlink($del_v['logo']);
			C::t('#aljsp#aljbd_video')->delete($del_v['id']);
		}
	}
}
function create_token($biaoshi) {
	$timestamp = TIMESTAMP;
	dsetcookie($biaoshi,$timestamp);
	return md5( $timestamp );
}
function valid_token($aljbd_token,$getcook,$biaoshi) {
	if(isset($getcook) && isset($aljbd_token) && $aljbd_token == md5($getcook))
	{
		dsetcookie($biaoshi,'');
		return true;
	}
	return false;
}
function newsendmail_cron($toemail, $subject, $message) {
    global $_G;
    $toemail = addslashes($toemail);

    $value = C::t('common_mailcron')->fetch_all_by_email($toemail, 0, 1);
    $value = $value[0];
    if($value) {
        $cid = $value['cid'];
    } else {
        $cid = C::t('common_mailcron')->insert(array('email' => $toemail), true);
    }
    //$message = preg_replace("/href\=\"(?!(http|https)\:\/\/)(.+?)\"/i", 'href="'.$_G['siteurl'].'\\1"', $message);
    $setarr = array(
        'cid' => $cid,
        'subject' => $subject,
        'message' => $message,
        'dateline' => $_G['timestamp']
    );
    C::t('common_mailqueue')->insert($setarr);

    return true;
}
function _mall_paging($page,$allnum,$pagesize=10,$url){
    $total=ceil($allnum/$pagesize);
    $prevpage=($page>1)?$page-1:1;
    $nextpage=($page>=$total)?$total:$page+1;
    if($page!=1){
        $prev = '<a href="'.$url.'1" class="btn btn-default btn-sm"><i class="fa fa-chevron-left"></i><i class="fa fa-chevron-left"></i></a>';
        $prev .='<a href="'.$url.$prevpage.'" class="btn btn-default btn-sm"><i class="fa fa-chevron-left"></i></a>';
    }
    if($total > 1){
        $page_str = '<a  class="btn btn-default btn-sm">'.$page.'/'.$total.'</a>';
        $page_input = '<input type="text" style="width:40px;border: 1px solid #ccc;" class="input-sm" onkeydown="if(event.keyCode==13) {window.location=\''.$url.'\'+this.value;}"/>';
        if($page!=$total){
            $next='<a href="'.$url.$nextpage.'" class="btn btn-default btn-sm"><i class="fa fa-chevron-right"></i></a>';
            $next.='<a href="'.$url.$total.'" class="btn btn-default btn-sm"><i class="fa fa-chevron-right"></i><i class="fa fa-chevron-right"></i></a>';
        }

    $tmp_str = '<div class="pull-right">
               '.$allnum.'
			   <div class="btn-group">
                 '.$prev.$page_str.$next.$page_input.'
                 </div>
                </div>';
    }
    return $tmp_str;
}
//From: Dism_taobao-com
?>