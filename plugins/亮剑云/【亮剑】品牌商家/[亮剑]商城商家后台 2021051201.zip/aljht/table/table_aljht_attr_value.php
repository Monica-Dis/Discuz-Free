<?php

/*
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 *
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljht_attr_value extends discuz_table {

    public function __construct() {

        $this->_table = 'aljht_attr_value';
        $this->_pk = 'symbol';

        parent::__construct(); //d'.'is'.'m.ta'.'obao.com
    }
}
//dis'.'m.t'.'ao'.'bao.com
?>