<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_G['groupid'] != 1){
    echo 99;
    exit;
}

if($_GET['api'] == 'getdata'){
    $where = ' where 1';
    $conn = array('aljbd_address');
    if($_GET['act'] == 'default'){
        $where .= ' and defaultAddress = 1'; 
    }

    if($_GET['search']){
        $search = stripsearchkey($_GET['search']);
        $search = diconv($search, 'utf-8', CHARSET);
        $search = '%'.$search.'%';
        $where .= " and (username like %s";
        $where .= " or fullName like %s ";
        $where .= " or mobile like %s ";
        $where .= " or uid like %s ";
        $where .= " or district like %s ";  
        $where .= " or city like %s ";  
        $where .= " or province like %s ";  
        $where .= " or address like %s)";  
        $conn[] = $search;
        $conn[] = $search;
        $conn[] = $search;
        $conn[] = $search;
        $conn[] = $search;
        $conn[] = $search;
        $conn[] = $search;
        $conn[] = $search;
    }
    
    $per = 20;
    $page = $_GET['page'] ? intval($_GET['page']) : 1;
    $start = ($page-1) * $per;
    $count = DB::result_first('select count(*) from %t ' . $where, $conn);
    $conn[] = $start;
    $conn[] = $per;
    $datalist = DB::fetch_all('select * from %t ' . $where. '  order by id desc  limit %d, %d', $conn);
    foreach($datalist as $k => $v){
        $v['addr'] = $v['province'].$v['city'].$v['district'].$v['addressDetail'];
        foreach($v as $kk => $vv){
            
            if($kk == 'dateline'){
                $v[$kk] = dgmdate($vv, 'Y-m-d H:i:s');
            }else{
                $v[$kk] = diconv($vv, CHARSET, 'utf-8');
            }
        }
        $datalist[$k] = $v;
    }
    $response['per'] = $per;
    $response['num'] =intval($count);
    $response['data'] = $datalist;
    $response['formhash'] = FORMHASH;
    echo json_encode($response);
    exit;
}else if($_GET['api'] == 'delete'){
    if($_GET['ids']){
        $dataList = DB::fetch_all('select * from %t where id in (%i)', array('aljbd_address', dimplode($_GET['ids'])));
        DB::query('delete from %t where id in (%i)', array('aljbd_address', dimplode($_GET['ids'])));
    }
    echo 1;
    exit;
}