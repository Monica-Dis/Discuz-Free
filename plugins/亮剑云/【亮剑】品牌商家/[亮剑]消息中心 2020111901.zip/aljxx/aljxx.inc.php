<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if($_GET['act'] == 'list'){//��ҳ���б���Ϣ
	
	

	$where[] = 'home_notification';
	$con = 'where 1 ';

	if(empty($_G['uid'])){
		echo 99;
		exit;
	}

	DB::query('update %t set new = 0 where uid=%d', array('home_notification', $_G['uid']));

	$con.= " and uid = %d and type='system'";
	$where[] = $_G['uid'];
	/*
	if($_GET['keyword']){
		$_GET['keyword'] = diconv($_GET['keyword'], 'utf-8', CHARSET);
		$search = '%'.addcslashes($_GET['keyword'], '%_').'%';
		$con.= " and goods like %s";
		$where[] = $search;
	}*/

	$num = DB::result_first('select count(*) from %t '.$con,$where);
	

	$con.= ' order by id desc';
	
	$currpage=$_GET['page']?$_GET['page']:1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	$max = ceil($num/$perpage);

	$where[] = $start;
	$where[] = $perpage;

	$notification_list = DB::fetch_all('select * from %t '.$con.' limit %d,%d',$where);
	
	foreach($notification_list as $k => $v){

		$notification_list[$k]['dateline'] = dgmdate($notification_list[$k]['dateline'], 'u');
		$plugin_list = s2a($_G['cache']['plugin']['aljxx']['table']);

		if(in_array($notification_list[$k]['from_idtype'], $plugin_list['idk'])){
			$notification_list[$k]['title'] = $plugin_list['idv'][$notification_list[$k]['from_idtype']];
		}else{
			$notification_list[$k]['title'] = $_G['cache']['plugin']['aljxx']['desc'];
		}
		
		$wxurl = $_G['siteurl'];
		if(preg_match_all("/<a(.+?)href=(['\"]?)([^>\s]+)\\2([^>]*)>/i", $notification_list[$k]['note'], $marray)){
			$link = array_pop($marray[3]);
			if($link == 'about:blank'){
				$link = array_pop($marray[3]);
			}
			$tmpurl = ($link ? $link : '/home.php?mod=space&do=notice&view=system');
			if(!in_array(strtolower(substr($tmpurl, 0, 6)), array('http:/', 'https:', 'ftp://'))){
				$notification_list[$k]['url'] = $wxurl.$tmpurl;
			}
		}else{
			$typelist = array('aljpc','aljes','aljzp','aljesc','aljcw','aljlp','aljesf','aljesc','aljzc');
			if(in_array($pm['from_idtype'],$typelist)){
				$notification_list[$k]['url'] = $wxurl.'plugin.php?id='.$pm['from_idtype'].'&act=view&mobile=2&lid='.$pm['from_id'];
			}else if($pm['from_idtype'] == 'aljol'){
				$notification_list[$k]['url'] = $wxurl.'plugin.php?id=aljol&act=talk&friendid='.$pm['from_id'];
			}else if($pm['from_idtype'] == 'aljbd'){
				if($pm['from_id']){
					$notification_list[$k]['url'] = $wxurl.'plugin.php?id=aljbd&act=orderlist';
				}else{
					$notification_list[$k]['url'] = $wxurl.'plugin.php?id=aljbd';
				}
			}else if($pm['type'] == 'friend'){
				$notification_list[$k]['url'] = $wxurl.'plugin.php?id=aljol&act=requestfriendlist';
			}else if($pm['from_idtype'] == 'aljhbx'){
				if($pm['from_id']){
					$notification_list[$k]['url'] = $wxurl.'plugin.php?id=aljhbx&action=view&pid='.$pm['from_id'];
				}else{
					$notification_list[$k]['url'] = $wxurl.'plugin.php?id=aljhbx&action=list';
				}
			}else{
				$notification_list[$k]['url'] = $wxurl;
			}
		}

		$notification_list[$k]['note'] = strip_tags($notification_list[$k]['note']);
			
		
		
		if(strpos($notification_list[$k]['goods']['pic1'], 'http') === false){
			//$notification_list[$k]['goods']['pic1'] = $_G['siteurl'].$notification_list[$k]['goods']['pic1'];
		}
	}
	$data['list'] = json_encode(g2u($notification_list), true);
	$data['num'] = $num;
	echo json_encode($data);
	exit;
	
}else if($_GET['api'] == 'yes'){
	include 'source/plugin/aljxx/api.php';
}else{
	header('Location: source/plugin/aljxx/');
}

function s2a($str, $sep = '='){
	global $_G;
	$str = str_replace("\n", PHP_EOL, $str);
	$arr = explode(PHP_EOL, $str);
	foreach($arr as $k => $v){
		$tmp = explode($sep, $v);
		$idv[$tmp[0]] = trim($tmp[1]);
		$idk[] = $tmp[0];
	}
	$return['idk'] = $idk;
	$return['idv'] = $idv;
	return $return;
}

function g2u($arr) {
	if(is_array($arr)){
		if (strtolower(CHARSET) == 'gbk') {
			foreach ($arr as $key => $val) {
				if(is_array($val)){
					$pt_goods[$key] = g2u($val);
				}else{
					$pt_goods[$key] = diconv($val,'gbk','utf-8');
				}

			}
			return $pt_goods;
		}
		return $arr;
	} else {
		if (strtolower(CHARSET) == 'gbk') {
			return diconv($arr,'gbk','utf-8');
		}
		return $arr;
	}
}


function u2g($arr) {
	if(is_array($arr)){
		if (strtolower(CHARSET) == 'gbk') {
			foreach ($arr as $key => $val) {
				if(is_array($val)){
					$pt_goods[$key] = u2g($val);
				}else{
					$pt_goods[$key] = diconv($val,'utf-8','gbk');
				}

			}
			return $pt_goods;
		}
		return $arr;
	} else {
		if (strtolower(CHARSET) == 'gbk') {
			return diconv($arr,'utf-8','gbk');
		}
		return $arr;
	}

}