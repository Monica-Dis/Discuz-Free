<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(empty($_G['uid'])){
	echo -1;
	exit;
}

$user = DB::fetch_first('select * from %t where uid=%d', array('common_member', $_G['uid']));

if(submitcheck('formhash')){
    $email = $_GET['email'];
    if(!isemail($email)){
        echo -2;
        exit;
    }else{
        if($email != $user['email']){
            DB::query('update %t set email = %s, emailstatus = 0 where uid=%d', array('common_member', $email, $_G['uid']));//emailstatus
            loaducenter();
            DB::query("UPDATE ".UC_DBTABLEPRE.'members'." SET `email` = '$email' WHERE uid ='$_G[uid]';");	
        }
        echo 1;
        exit;
    }
    
}else{
	$config = $_G['cache']['plugin']['aljxx'];
    $response['config'] = $config;
    
    //debug($user);
    $response['user'] = $user;
    $response['formhash'] = FORMHASH;
    $response['aljol'] = $_G['cache']['plugin']['aljol'] ? 1 : 0;
    $response['siteurl'] = $_G['siteurl'];
    
    $systemLast = DB::fetch_first('select * from %t where type=%s and uid=%d order by id desc', array('home_notification', 'system', $_G['uid']));
    if($systemLast){
        $response['systemLast'] = $systemLast;
        $response['systemLast']['dateline'] = dgmdate($systemLast['dateline'], 'u');
        $response['systemLast']['note'] = strip_tags($systemLast['note']);
        $response['systemLast']['num'] = DB::result_first('select count(*) from %t where type=%s and uid=%d and new=1', array('home_notification', 'system', $_G['uid']));
        if($response['systemLast']['num'] > 99){
            $response['systemLast']['num'] = 99;
        }
    }
    
    $wuLiuLast = DB::fetch_first('select * from %t where news_type=%d and uid=%d order by id desc',array('aljhtx_notification',1,$_G['uid']));
    if($wuLiuLast){
        $response['wuLiuLast'] = $wuLiuLast;
        $response['wuLiuLast']['dateline'] = dgmdate($wuLiuLast['dateline'], 'u');
        $response['wuLiuLast']['num'] = DB::result_first('select count(*) from %t where news_type=%d and uid=%d and status = 0',array('aljhtx_notification',1,$_G['uid']));
        if($response['wuLiuLast']['num'] > 99){
            $response['wuLiuLast']['num'] = 99;
        }
    }


    //在线聊天未读数量
    if($_G['cache']['plugin']['aljol'] && $_G['uid']){
        $newscount = DB::result_first('select count(*) from %t where friendid=%d and talkstate=1',array('aljol_talk',$_G['uid']));
        $new_noti = DB::result_first('select count(*) from %t where uid=%d and status=0 and news_type=1',array('aljhtx_notification',$_G['uid']));
        $newscount = $newscount + $new_noti;
        
        $aljolLast = DB::fetch_first('select * from %t where friendid=%d and talk != %s order by id desc',array('aljol_talk',$_G['uid'], ''));
        if($aljolLast){
            $response['aljolLast'] = $aljolLast;
            $response['aljolLast']['dateline'] = dgmdate($aljolLast['datetime'], 'u');
            $response['aljolLast']['num'] = $newscount > 99 ? 99 : $newscount;
        }
        
        foreach(DB::fetch_all('select * from %t where friendid=%d and talkstate=1 and id>%d',array('aljol_talk',$_G['uid'], $_GET['tid'])) as $row){
            $tid = $row[id];
            if($arr[$row['uid']]){
                $arr[$row['uid']]['num'] = $arr[$row['uid']]['num'] + 1;
                $arr[$row['uid']]['time'] = dgmdate($row['datetime'], 'H:i');
            }else{
                $arr[$row['uid']] = array(
                    'tit1' => $row['username'],
                    'tit2' => $row['talk'],
                    'time' => dgmdate($row['datetime'], 'H:i'),
                    'img' => avatar($row['uid'], 'middle', true),
                    'num' => 1,
                    'uid' => $row['uid'],
                    'url' => $_G['siteurl'] . 'plugin.php?id=aljol&act=talk&friendid=' . $row['uid'], 
                    'status' => 1,
                );
            }
            
        }
    }
    
    $response['list'] = array_values($arr);
    $response['list'] = array_reverse($response['list']);
    $response['tid'] = $tid;
	echo json_encode(g2u($response));
	exit;
}