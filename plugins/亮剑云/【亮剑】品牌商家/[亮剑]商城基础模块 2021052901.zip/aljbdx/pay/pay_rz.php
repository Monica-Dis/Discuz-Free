<?php
	define('DISABLEXSSCHECK',true);
	require '../../../../source/class/class_core.php';
	$discuz = C::app();
	$discuz->init();
  	loadcache('plugin');

	require_once '../../../../source/plugin/aljqb/class/Qbapi.class.php';
	if(file_exists('../../../../source/plugin/aljqb/class/Getdata.class.php')){
		require_once '../../../../source/plugin/aljqb/class/Getdata.class.php';
		$getdata = new Getdata();
	}
	//file_put_contents('d.txt',$key."\r",FILE_APPEND);
	//file_put_contents('d.txt',$_GET['key']."\r",FILE_APPEND);
    $pluginid = 'aljbd';
    $_G['siteurl'] = str_replace('source/plugin/aljbdx/pay/', '',$_G['siteurl'] );
	$orderlurl = $_G['siteurl'].'/plugin.php?id='.$pluginid.'&act=orderlist';
	$orderlurln = '/plugin.php?id='.$pluginid.'&act=orderlist';
	$data['transaction_id'] = $_GET['aljorderid'];
    require '../../../../source/plugin/aljbdx/function/function_core.php';
	$qbapi = new Qbapi();
	$keyarray = array(
		'aljorderid'=> $_GET['aljorderid'],
		'paytime' => $_GET['paytime'],
		'orderid' => $_GET['orderid'],
	);
	if($_GET['key']) {
		$keyarray['key'] = $_G['cache']['plugin']['aljbdx']['qb_key'];
		$key = $qbapi->createKey($keyarray);
		$getkey = $_GET['key'];
	}elseif(file_exists('../../../../source/plugin/aljqb/class/Getdata.class.php')) {
		$appinfo = $getdata->getAppParam();
		$appinfo['posttime']=$_GET['posttime'];
		$key = $getdata->CreateAppSign($appinfo);
		$getkey = $_GET['sign'];
	}
	if($getkey && $getkey && $key == $getkey) {
        if($_G['cache']['plugin']['aljbdx']['is_aljqb']){
            $tablename = 'aljbdx';
        }else{
            $tablename = 'aljgwc';
        }
        $order = C::t('#'.$tablename.'#aljbd_goods_order') -> fetch($_GET['orderid']);
        $brand = C::t('#'.$pluginid.'#'.$pluginid) -> fetch($order['shop_id']);
		if($order['status'] == 1){
            $user = getuserbyuid($brand['uid']);
            if(in_array($user['groupid'],unserialize($_G['cache']['plugin']['aljbd']['mgroups']))){
                $status=1;
            }else{
                $status=0;
                $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
                foreach($groupids as $g_uid){
                    notification_add($g_uid['uid'], 'system','<a href="plugin.php?id=aljhtx&c=aljbd&a=order&type=5&do=no">'.lang('plugin/aljbd','n_add_tips').'</a>',array('from_idtype'  => 'aljbd_brand','from_id' => $order['shop_id']));
                }
            }
            $updatearray = array('status'=>$status);

            $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$order['fare_desc']));
            if($vipdata){
                if($vipdata['day'] == 0){
                    $vipendtime = 0;
                }else{
                    //����VIP
                    if($order['opentime']){
                        $vipendtime = $order['opentime'] + ($vipdata['day'] * 86400);
                    }else{
                        $vipendtime = TIMESTAMP + ($vipdata['day'] * 86400);
                    }
                }
                $updatearray['vipendtime'] = $vipendtime;
			}

            //vipid ����VIP
            if($order['fare_desc']){
                $updatearray['vipid'] = $order['fare_desc'];
            }
            DB::update('aljbd',$updatearray,array('id'=>$brand['id']));
            $qborder = DB::fetch_first('select * from %t where aljorderid=%s',array('aljqb_payorder',$_GET['aljorderid']));

            C::t('#'.$tablename.'#aljbd_goods_order')->update($_GET['orderid'], array('admin'=>$qborder['trade_mod'],'status' => 2, 'buyer' => $data['transaction_id'], 'confirmdate' => $_GET['paytime']));

            //s ������ѯ���� �ֵ�
            if($_G['cache']['plugin']['aljsfx']['is_aljsfx']){
                $fxinfo = DB::fetch_first('select * from %t where uid=%d ', array('aljsfx_user', $order['uid']));
                if($fxinfo){
                    if($fxinfo['first_leader_uid']>0){//һ����ID
                        //��������������
                        $first_shopdata = DB::fetch_first('select a.username,b.* from %t a left join %t b on a.rankid=b.id where a.uid=%d and a.status=1',array('aljsfx_shop','aljsfx_rank',$fxinfo['first_leader_uid']));
                        $fx_goods_price = substr(sprintf("%.3f",$order['price'] * ($first_shopdata['shop_scale']/100)),0,-1);//�̼���פ����Ӷ��
                        if($first_shopdata && $first_shopdata['first_scale']>0){
                            $first_fee = substr(sprintf("%.3f",$fx_goods_price*($first_shopdata['first_scale']/100)),0,-1);//һ�������̽������
                            if($first_fee>0){
                                $first_insert = array(
                                    'orderid' => $_GET['orderid'],
                                    'timestamp' => TIMESTAMP,
                                    'beneficiary_uid' => $fxinfo['first_leader_uid'],
                                    'beneficiary_username' => $first_shopdata['username'],
                                    'payment_days' => $first_shopdata['payment_days'],
                                    'uid' => $order['uid'],
                                    'username' => $order['username'],
                                    'money' => $first_fee,
                                    'scale' => $first_shopdata['first_scale'],
                                    'shop_scale' => $first_shopdata['shop_scale'],
                                    'status' => 1,
                                    'type' => 1,
                                );
                                DB::insert('aljsfx_order',$first_insert);
                                DB::query('update %t set total_commission=total_commission+%i where uid=%d',array('aljsfx_shop',$first_fee,$fxinfo['first_leader_uid']));
                            }
                        }
                    }
                    if($fxinfo['second_leader_uid']>0 && $fxinfo['first_leader_uid'] != $fxinfo['second_leader_uid']){//��������ID
                        //��������������
                        $second_shopdata = DB::fetch_first('select a.username,b.* from %t a left join %t b on a.rankid=b.id where a.uid=%d and a.status=1',array('aljsfx_shop','aljsfx_rank',$fxinfo['second_leader_uid']));
                        $fx_goods_price = substr(sprintf("%.3f",$order['price'] * ($second_shopdata['shop_scale']/100)),0,-1);//�̼���פ����Ӷ��
                        if($second_shopdata && $second_shopdata['second_scale']>0){
                            $second_fee = substr(sprintf("%.3f",$fx_goods_price*($second_shopdata['second_scale']/100)),0,-1);//���������̽������
                            if($second_fee>0){
                                $second_insert = array(
                                    'orderid' => $_GET['orderid'],
                                    'timestamp' => TIMESTAMP,
                                    'beneficiary_uid' => $fxinfo['second_leader_uid'],
                                    'beneficiary_username' => $second_shopdata['username'],
                                    'payment_days' => $second_shopdata['payment_days'],
                                    'uid' => $order['uid'],
                                    'username' => $order['username'],
                                    'money' => $second_fee,
                                    'scale' => $second_shopdata['second_scale'],
                                    'shop_scale' => $second_shopdata['shop_scale'],
                                    'status' => 1,
                                    'level' => 1,
                                    'type' => 1,
                                );
                                DB::insert('aljsfx_order',$second_insert);
                                DB::query('update %t set total_commission=total_commission+%i where uid=%d',array('aljsfx_shop',$second_fee,$fxinfo['second_leader_uid']));
                            }
                        }
                    }
                    if($fxinfo['third_leader_uid']>0){//��������ID
                        //��������������
                        $third_shopdata = DB::fetch_first('select a.username,b.* from %t a left join %t b on a.rankid=b.id where a.uid=%d and a.status=1',array('aljsfx_shop','aljsfx_rank',$fxinfo['third_leader_uid']));
                        $fx_goods_price = substr(sprintf("%.3f",$order['price'] * ($third_shopdata['shop_scale']/100)),0,-1);//�̼���פ����Ӷ��
                        if($third_shopdata && $third_shopdata['second_scale']>0){
                            $third_fee = substr(sprintf("%.3f",$fx_goods_price*($third_shopdata['third_scale']/100)),0,-1);//���������̽������
                            if($third_fee>0){
                                $third_insert = array(
                                    'orderid' => $_GET['orderid'],
                                    'timestamp' => TIMESTAMP,
                                    'beneficiary_uid' => $fxinfo['third_leader_uid'],
                                    'beneficiary_username' => $third_shopdata['username'],
                                    'payment_days' => $third_shopdata['payment_days'],
                                    'uid' => $order['uid'],
                                    'username' => $order['username'],
                                    'money' => $third_fee,
                                    'scale' => $third_shopdata['third_scale'],
                                    'shop_scale' => $third_shopdata['shop_scale'],
                                    'status' => 1,
                                    'level' => 2,
                                    'type' => 1,
                                );
                                DB::insert('aljsfx_order',$third_insert);
                                DB::query('update %t set total_commission=total_commission+%i where uid=%d',array('aljsfx_shop',$third_fee,$fxinfo['third_leader_uid']));
                            }
                        }
                    }
                }
            }
            //e ������ѯ����
            //����Ǯ�� +money ����ͳ���ʻ�
            if($_G['cache']['plugin']['aljbdx']['money_uid']>0){
                $usermoney = getuserbyuid($_G['cache']['plugin']['aljbdx']['money_uid']);
                $queuearray = array(
                    'app_name' => 'aljbdx',
                    'app_type' => 'aljbdx_add_rz',
                    'app_phone' => '123456789',
                    'app_ip' => $_G['clientip'],
                );
                $balancearray = array(
                    'type'=> 'charge',
                    'uid'=>$_G['cache']['plugin']['aljbdx']['money_uid'],
                    'price' => $brand['price'],
                    'orderid'=> $_GET['orderid'],
                    'desc'=> str_replace(array('{username}','{name}','{money}'),array($brand['username'],$brand['name'],$brand['price']),$_G['cache']['plugin']['aljbdx']['qb_desc_uid_price']),
                );
                $result_money_uid = $qbapi -> balance($queuearray,$balancearray);
            }
		}
        echo 'success';
        exit;
	}
?>
