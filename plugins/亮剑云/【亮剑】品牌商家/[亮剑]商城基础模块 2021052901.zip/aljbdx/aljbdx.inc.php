<?php
/**
 * Created by PhpStorm.
 * User: lixinyuan
 * Date: 2017/6/20
 * Time: ����11:11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
//debug(json_encode(C::t('#aljbdx#aljgwc_region')->fetch_all_json_jq()));
foreach(DB::fetch_all('select * from %t',array('common_plugin')) as $cpv){
    $cparray[$cpv['identifier']] = $cpv;
}
$timeoffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$timeoffset),dgmdate($_G['timestamp'], 'j',$timeoffset),dgmdate($_G['timestamp'], 'Y',$timeoffset)) - $timeoffset*3600;
//�����ʶ��
define('APP_ID', 'aljbdx');
define('PLUGIN_ID', 'aljhtx');
//������Ŀ¼
define('PLUGIN_ROOT_PATH', 'source/plugin/');
define('APP_ROOT_PATH', 'source/plugin/');
//��ǰ���Ŀ¼
define('APP_PATH', 'source/plugin/' . APP_ID . '/');
define('PLUGIN_PATH', 'source/plugin/' . PLUGIN_ID . '/');
//�����ҳ����
define('APP_URL', 'plugin.php?id=' . APP_ID);
define('PLUGIN_URL', 'plugin.php?id=' . APP_ID);
$act = addslashes($_GET['act']);
$pluginid='aljbd';
$pluginid_aljbdx='aljbdx';
$fare_desc = array('1'=>'&#21253;&#37038;','2'=>'&#21040;&#20184;');
$address_id = intval($_GET['address_id']);
$s_id = intval($_GET['shop_id']);
$goods_id = intval($_GET['goods_id']);
$price_unit = '&#65509;';
$price_symbol = '&#20803;';
$address = C::t('#aljbdx#aljbd_address')->fetch($address_id);
if($_G['cache']['plugin']['aljpps']['is_aljbd']){
    if($address_id){
        $def_address = C::t('#aljbdx#aljbd_address')->fetch_by_uid_addressid($_G['uid'],$address_id,1);
    }else{
        $def_address = C::t('#aljbdx#aljbd_address')->fetch_by_uid($_G['uid'],1);
    }
}else{
    if($address_id){
        $def_address = C::t('#aljbdx#aljbd_address')->fetch_by_uid_addressid($_G['uid'],$address_id);
    }else{
        $def_address = C::t('#aljbdx#aljbd_address')->fetch_by_uid($_G['uid']);
    }
}

if($_G['cache']['plugin']['aljgwc']){
    require_once 'source/plugin/aljgwc/lang/lang.php';
    $alj_lang=lang('plugin/aljgwc');

}

$pid = 0;

require_once 'source/plugin/aljqb/class/Qbapi.class.php';
$qbapi = new Qbapi();
require_once 'source/plugin/aljbd/include/aljbd_parameter.php';
$price_unit = '&#65509;';
$price_symbol = '&#20803;';
require_once $common_path.'class/class_aljhtx.php';
require_once 'source/plugin/aljbdx/function/function_core.php';
if(($_GET['act'] == 'buysubmit' || $_GET['act'] == 'cartsubmit' || $_GET['act'] == 'editaddress') && !$_G['mobile']){
    $_GET = T::ajaxGetCharSet($_GET);
}
if($_G['cache']['plugin']['aljhtx']['regular']){
    $regular = $_G['cache']['plugin']['aljhtx']['regular'];
}else{
    $regular = '#^13[\d]{9}$|^14[5,7]{1}\d{8}$|^15[^4]{1}\d{8}$|^16[6]{1}\d{8}$|^17[0,1,3,5,6,7,8]{1}\d{8}$|^18[\d]{9}$|^19[8,9]{1}\d{8}$#';
}
if($act == 'cart'){//���ﳵ
    
    
    $cart_array = cart_id($_GET['shop_id']);
    
    $goods_id_arr = $cart_array['goods_id_arr'];
    $goods_goodstype_arr = $cart_array['goods_goodstype_arr'];
    $shop_id = $cart_array['shop_id'];
    $goods = C::t('#'.$pluginid.'#'.$pluginid.'_goods')->fetch_all($goods_id_arr);
    if($goods){
        foreach($goods as $g_k => $g_v){
            foreach($pics as $p_v){
                $goods[$g_k][$p_v] = $g_v[$p_v].$oss_img_url;
            }
        }
    }
    
    $shop  = C::t('#'.$pluginid.'#'.$pluginid)->fetch_all($shop_id);
    if($_GET['ajax'] == 'yes' && ($_GET['id'] != 'aljbdx' || $_GET['mobiledemomode'] == 'yes')){
        if(count($cart_array['list']) <= 0){
            echo 1;
            exit;
        }else{
            include template('aljbdx:cart_data');
            exit;
        }
    }
    if(count($cart_array['list']) <= 0){
        $navtitle = $_G['cache']['plugin']['aljbdx']['navtitle'];
        include template($pluginid_aljbdx.':cart_nodata');
        exit;
    }
    if($_GET['shop_id']){
        $totalprice = $cart_array['t_price'][$s_id];
        $total = $cart_array['t_price'][$s_id] + $cart_array['t_fare'][$s_id];
        $fare = $cart_array['t_fare'][$s_id];
        
        $give_integral = $cart_array['t_give_integral'][$s_id];//���ͻ�����
        $pay_integral = $cart_array['t_pay_integral'][$s_id];//���ֵ�����Ʒ�۸�

        //$pay_integral = substr(sprintf("%.3f",$totalprice*($pay_integral/100)),0,-1);
        $res = integralCalculation($pay_integral);

        $doext = $res['doext'];
        $rmb = $res['rmb'];
        $myext = $res['myext'];
        if($_G['cache']['plugin']['aljsyh']['is_aljsyh'] && !$cart_array['t_ms_yes'][$s_id]){
            $discount1 = DB::fetch_all('select a.id,b.full,b.reduction,b.coupon_type from %t a left join %t b on a.cid=b.id where (b.bid=%d or b.coupon_type=7)  and b.coupon_type<9 and ((FIND_IN_SET(0,b.goodstype) and b.available_goods=1) or b.available_goods=0) and (((b.end>%s or b.end=0) and b.coupon_validity=0) or (b.coupon_validity>0 and b.coupon_validity*3600+a.receive_time>%d)) and a.status=%d and a.uid=%d order by b.reduction desc',
                array(
                    'aljsyh_consume_log',
                    'aljbd_consume',
                    intval($_GET['shop_id']),
                    TIMESTAMP,
                    TIMESTAMP,
                    1,
                    $_G['uid']
                ));
                $discount = array();
            foreach($discount1 as $dk => $kv){
                if ($kv['coupon_type'] == 2) {
                    if ($fare > 0) {
                        $kv['full'] = floatval($kv['full']);
                        $kv['reduction'] = floatval($fare);
                    }
                } else {
                    $kv['full'] = floatval($kv['full']);
                    $kv['reduction'] = floatval($kv['reduction']);
                }
                if($kv['full'] <= $totalprice && $kv['reduction'] <=$totalprice) {
                    $discount[] = $kv;
                }
            }
        }
        $bid = intval($_GET['shop_id']);
        $bdinfo = C::t('#aljbd#aljbd')->fetch($_GET['shop_id']);
        if($bdinfo['platform_distribution'] == 1 && $_G['cache']['plugin']['aljpps']['is_aljbd']){
            $fare = $_G['cache']['plugin']['aljpps']['aljbd_fare'];
        }
        if($_GET['ajax'] == 'yes'){
            if($total>0){
                echo json_encode(aljhtx::ajaxPostCharSet(array('price'=>$total,'fare'=>$fare,'discount'=>$discount ? $discount : 1)));
                exit;
            }
        }
        
        
        $navtitle = lang("plugin/aljbdx","aljbdx_inc_php_27");
        
        
        include template($pluginid_aljbdx.':cart_view');
        exit;
    }
    if($_G['cache']['plugin']['aljbd_bq']['is_aljbd_bq']){
        $bq_goods = DB::fetch_all('select * from %t ',array('aljbd_bq_goods'),'gid');
    }
    
    
    $navtitle = $_G['cache']['plugin']['aljbdx']['navtitle'];
    if($_GET['shop_id']){
        $navtitle = lang("plugin/aljbdx","aljbdx_inc_php_27");
    }
    $description = $_G['cache']['plugin']['aljbdx']['description'];
    include template($pluginid_aljbdx.':cart');
}else if($_GET['act'] == 'num'){//���ﳵ��Ʒ����
    if($_GET['formhash'] != $_G['formhash']) {
        showmessage('submit_invalid');
    }
    if($_GET['num_bth'] == 'btnCut'){
        C::t('#aljbdx#aljgwc')->increase($_GET['cart_id'], array('num' => -1));
        $cart = DB::fetch_first('select * from %t where id=%d ',array('aljgwc',$_GET['cart_id']));
        $goods = C::t('#aljbd#aljbd_goods')->fetch($cart['goods_id']);
        if($_G['cache']['plugin']['aljbd_bq']['is_aljbd_bq']){
            $g = $goods;
            if($g['product_label']){
                $biaoqian = DB::fetch_all('select * from %t where id IN (%n)',array('aljbd_bq',explode(',',$g['product_label'])));
                $jiaobiao = $zhuanti = $dapeishangpin = $autohtml = array();
                foreach($biaoqian as $bq_k => $bq_v){
                    if($bq_v['type'] == 1){
                        $jiaobiao = $bq_v;
                    }else if($bq_v['type'] == 2){
                        $zhuanti = $bq_v;
                    }else if($bq_v['type'] == 3){
                        $dapeishangpin = $bq_v;
                    }else if($bq_v['type'] == 4){
                        $autohtml = $bq_v;
                    }
                }
                if($dapeishangpin){
                    //������⣬�ٵ�����ʾ
                    $bq_goods = DB::fetch_all('select a.*,b.price1,b.attr_sku,b.commodity_type,b.collage_price,b.price2,b.name,b.pic1,b.fare,b.fare_desc from %t a left join %t b on a.gid=b.id where a.qid=%d and a.g_check=1 and a.uid=%d',array('aljbd_bq_goods_check','aljbd_goods',$dapeishangpin['id'],$_G['uid']));
                    
                    if($bq_goods){
                        
                        foreach($bq_goods as $bq_k => $bq_v){
                            $num = 1;
                            DB::query('update %t set num=num-%d where goods_id=%d and uid=%d and pid=%d ', array('aljgwc',$num,$bq_v['gid'],$_G['uid'],$pid));
                        }
                        
                    }
                    
                }
            }
        }
    }elseif($_GET['num_bth'] == 'btnAdd'){
        $cart = DB::fetch_first('select * from %t where id=%d ',array('aljgwc',$_GET['cart_id']));
        $goods = C::t('#aljbd#aljbd_goods')->fetch($cart['goods_id']);
        if($new_price_order_num<=0 && $goods['new_price'] > 0){
            if($aljtsq_post_goods){
                $new_price_num = DB::result_first('select count(*) from %t a left join %t b on a.goods_id=b.id where a.uid=%d and a.pid=%d and a.type=1 and b.new_price>0 ',array('aljgwc','aljbd_goods', $_G['uid'],0));
            }else{
                $new_price_num = DB::result_first('select count(*) from %t a left join %t b on a.goods_id=b.id where a.uid=%d and a.pid=%d and a.type=0 and b.new_price>0 ',array('aljgwc','aljbd_goods', $_G['uid'],0));
            }
            if($new_price_num >= 1 && !$cart){
                $tips_1 = '&#26032;&#20154;&#20215;&#21830;&#21697;&#26368;&#22810;&#36873;&#49;&#31181;&#36141;&#20080;';
            }else if($new_price_num >= 1 && $cart){
                $tips_1 = '&#26032;&#20154;&#20215;&#21830;&#21697;&#26368;&#22810;&#36141;&#20080;&#49;&#20221;';
            }
            if($tips_1){
                echo "<script>alert('".$tips_1."');window.history.go(-1);</script>";
                exit;
            }
        }
        C::t('#aljbdx#aljgwc')->increase($_GET['cart_id'], array('num' => 1));
        if($_G['cache']['plugin']['aljbd_bq']['is_aljbd_bq']){
            $g = $goods;
            if($g['product_label']){
                $biaoqian = DB::fetch_all('select * from %t where id IN (%n)',array('aljbd_bq',explode(',',$g['product_label'])));
                $jiaobiao = $zhuanti = $dapeishangpin = $autohtml = array();
                foreach($biaoqian as $bq_k => $bq_v){
                    if($bq_v['type'] == 1){
                        $jiaobiao = $bq_v;
                    }else if($bq_v['type'] == 2){
                        $zhuanti = $bq_v;
                    }else if($bq_v['type'] == 3){
                        $dapeishangpin = $bq_v;
                    }else if($bq_v['type'] == 4){
                        $autohtml = $bq_v;
                    }
                }
                if($dapeishangpin){
                    //������⣬�ٵ�����ʾ
                    $bq_goods = DB::fetch_all('select a.*,b.price1,b.attr_sku,b.commodity_type,b.collage_price,b.price2,b.name,b.pic1,b.fare,b.fare_desc from %t a left join %t b on a.gid=b.id where a.qid=%d and a.g_check=1 and a.uid=%d',array('aljbd_bq_goods_check','aljbd_goods',$dapeishangpin['id'],$_G['uid']));
                    
                    if($bq_goods){
                        
                        foreach($bq_goods as $bq_k => $bq_v){
                            
                                $num = 1;
                                DB::query('update %t set num=num+%d where goods_id=%d and uid=%d and pid=%d ', array('aljgwc',$num,$bq_v['gid'],$_G['uid'],$pid));
                            
                        }
                        
                    }
                    
                }
            }
        }
    }elseif($_GET['num_bth'] == 'btnval'){
        $cart = DB::fetch_first('select * from %t where id=%d ',array('aljgwc',$_GET['cart_id']));
        $goods = C::t('#aljbd#aljbd_goods')->fetch($cart['goods_id']);
        if($new_price_order_num<=0 && $goods['new_price'] > 0){
            if($aljtsq_post_goods){
                $new_price_num = DB::result_first('select count(*) from %t a left join %t b on a.goods_id=b.id where a.uid=%d and a.pid=%d and a.type=1 and b.new_price>0 ',array('aljgwc','aljbd_goods', $_G['uid'],0));
            }else{
                $new_price_num = DB::result_first('select count(*) from %t a left join %t b on a.goods_id=b.id where a.uid=%d and a.pid=%d and a.type=0 and b.new_price>0 ',array('aljgwc','aljbd_goods', $_G['uid'],0));
            }
            if($new_price_num >= 1 && !$cart){
                $tips_1 = '&#26032;&#20154;&#20215;&#21830;&#21697;&#26368;&#22810;&#36873;&#49;&#31181;&#36141;&#20080;';
            }else if($new_price_num >= 1 && $cart){
                $tips_1 = '&#26032;&#20154;&#20215;&#21830;&#21697;&#26368;&#22810;&#36141;&#20080;&#49;&#20221;';
            }
            if($tips_1){
                echo "<script>alert('".$tips_1."');window.history.go(-1);</script>";
                exit;
            }
        }
        C::t('#aljbdx#aljgwc')->update($_GET['cart_id'], array('num' => intval($_GET['num'])));
        if($_G['cache']['plugin']['aljbd_bq']['is_aljbd_bq']){
            $g = $goods;
            if($g['product_label']){
                $biaoqian = DB::fetch_all('select * from %t where id IN (%n)',array('aljbd_bq',explode(',',$g['product_label'])));
                $jiaobiao = $zhuanti = $dapeishangpin = $autohtml = array();
                foreach($biaoqian as $bq_k => $bq_v){
                    if($bq_v['type'] == 1){
                        $jiaobiao = $bq_v;
                    }else if($bq_v['type'] == 2){
                        $zhuanti = $bq_v;
                    }else if($bq_v['type'] == 3){
                        $dapeishangpin = $bq_v;
                    }else if($bq_v['type'] == 4){
                        $autohtml = $bq_v;
                    }
                }
                if($dapeishangpin){
                    //������⣬�ٵ�����ʾ
                    $bq_goods = DB::fetch_all('select a.*,b.price1,b.attr_sku,b.commodity_type,b.collage_price,b.price2,b.name,b.pic1,b.fare,b.fare_desc from %t a left join %t b on a.gid=b.id where a.qid=%d and a.g_check=1 and a.uid=%d',array('aljbd_bq_goods_check','aljbd_goods',$dapeishangpin['id'],$_G['uid']));
                    
                    if($bq_goods){
                        
                        foreach($bq_goods as $bq_k => $bq_v){
                            $num = $_GET['num'];
                            DB::query('update %t set num=%d where goods_id=%d and uid=%d and pid=%d ', array('aljgwc',$num,$bq_v['gid'],$_G['uid'],$pid));
                        }
                        
                    }
                    
                }
            }
        }
    }
    if($aljtsq_post_goods){
        showmessage('operation_done', 'plugin.php?id=aljtsc&c=aljtsc&a=cart', array(), array('header' => true));
    }else{
        showmessage('operation_done', 'plugin.php?id=aljbdx&act=cart&pluginid='.$pluginid, array(), array('header' => true));
    }
}else if($act == 'cartsubmit'){//���ﳵ�µ�
    if(submitcheck('formhash')) {
        if(!$address && (!$_GET['get_to_the_shop'] || ($_GET['get_to_the_shop'] == 1 && $_G['cache']['plugin']['aljstg']['is_address']))){
            echo "<script>parent.tips_gwc('&#35831;&#22635;&#20889;&#25910;&#36135;&#22320;&#22336;','');</script>";
            exit;
        }
        if(!$_GET['payment']){
            echo "<script>parent.tips_gwc('&#35831;&#36873;&#25321;&#20184;&#27454;&#26041;&#24335;','');</script>";
            exit;
        }
        if($aljtsq_post_goods){//�ŵ���Ʒ��������
            $sql = " AND type = 1 ";
            $query = C::t('#aljbdx#aljgwc')->fetch_all_by_uid_store($_G['uid'],$_GET['shop_id'],$pid,$_GET['store_id'],$sql);
            $_G['cache']['plugin']['aljbdx']['exttype'] =  $_G['cache']['plugin']['aljtsq']['exttype'];
            $_G['cache']['plugin']['aljbdx']['proportions'] = $_G['cache']['plugin']['aljtsq']['proportions'];
        }else{
            $query = C::t('#aljbdx#aljgwc')->fetch_all_by_uid($_G['uid'],$_GET['shop_id'],$pid);
        }
        if(!$query){
            $orderurl = 'plugin.php?id='.$pluginid.'&act=orderlist';
            echo "<script>parent.tips_gwc('&#35746;&#21333;&#24050;&#25552;&#20132;',function(){parent.location.href='".$orderurl."';});</script>";
            exit;
        }
        if ($_GET['fare']) {
            $fare = $_GET['fare'];
        }
        if($aljtsq_post_goods){//�ŵ���Ʒ��������
            $bdinfo = C::t('#aljtsq#aljtsq_store')->fetch($_GET['store_id']);
            $cart_array = cart_id_store($_GET['shop_id'],0,$_GET['store_id']);
            $s_id = $_GET['store_id'];
        }else{
            $bdinfo = C::t('#aljbd#aljbd')->fetch($_GET['shop_id']);
            $cart_array = cart_id($_GET['shop_id']);
        }
        
        
        
        //�ύ ����������

        $totalprice = $_GET['totalprice'];
        
        if($_GET['couponid'] && $_G['cache']['plugin']['aljsyh']['is_aljsyh'] && $_GET['dis']){
            $clogdata = DB::fetch_first('select * from %t a left join %t b on a.cid=b.id where a.status=1 and a.uid=%d and a.id=%d', array('aljsyh_consume_log', 'aljbd_consume', $_G['uid'], intval($_GET['couponid'])));
            
            if ($clogdata) {
                
                if((floatval($clogdata['reduction']) != $_GET['dis'] && $clogdata['coupon_type'] != 2) || ($clogdata['coupon_type'] == 2 && $_GET['dis']!=$fare)){
                    echo '<script>parent.tips_gwc("'.lang("plugin/aljbdx","aljbdx_inc_php_2").'","");</script>';
                    exit;
                }
            }else{
                echo '<script>parent.tips_gwc("'.lang("plugin/aljbdx","aljbdx_inc_php_2").'","");</script>';
                exit;
            }
            if($_GET['payment'] == '6' && $clogdata['coupon_type'] == 7 && !$_G['cache']['plugin']['aljpyh']['close_no_pay']){
                echo '<script>parent.tips_gwc("&#36135;&#21040;&#20184;&#27454;&#19981;&#25903;&#25345;&#20351;&#29992;&#24179;&#21488;&#20248;&#21270;&#21048;","");</script>';
                exit;
            }
        }
        //1=������ȡ
        if($_GET['get_to_the_shop'] == 1){
            $fare = 0;
            $goods['fare_desc'] = 1;
            $total = $cart_array['t_price'][$s_id] - $_GET['dis'];
        }else{
            if($bdinfo['platform_distribution'] == 1 && $_G['cache']['plugin']['aljpps']['is_aljbd'] && !$aljtsq_post_goods){
                $fare = $_G['cache']['plugin']['aljpps']['aljbd_fare'];
                $total = $cart_array['t_price'][$s_id] + $fare - $_GET['dis'];
            }else{
                $total = $cart_array['t_price'][$s_id] + $cart_array['t_fare'][$s_id] - $_GET['dis'];
            }
            
            
        }
        $give_integral = $cart_array['t_give_integral'][$s_id];//���ͻ�����
        if($_GET['pay_integral'] && $_GET['pay_ext']){
            $pay_integral = $cart_array['t_pay_integral'][$s_id];//���ֵ�����Ʒ�۸�
            //$pay_integral_totalprice = $cart_array['t_price'][$s_id] - $_GET['dis'];
            //debug($pay_integral_totalprice);
            //$pay_integral = substr(sprintf("%.3f",$pay_integral_totalprice*($pay_integral/100)),0,-1);
            
            $res = integralCalculation($pay_integral);
            
            $doext = $res['doext'];
            $rmb = $res['rmb'];
            $myext = $res['myext'];
            if($_GET['pay_integral'] != $rmb || $_GET['pay_ext'] != $doext){
                echo '<script>parent.tips_gwc("'.$_G['setting']['extcredits'][$_G['cache']['plugin']['aljbdx']['exttype']]['title'].lang("plugin/aljbdx","aljbdx_inc_php_24").'","");</script>';
                exit;
            }
            $total = $total-$rmb;
        }
        
        //�ж��ύ����������ʵ�������Ƿ�һ��
        if(trim($total) != trim($totalprice)){
            echo '<script>parent.tips_gwc("'.lang("plugin/aljbdx","aljbdx_inc_php_3").'","");</script>';
            exit;
        }

        $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
        if(C::t('#aljbdx#aljbd_goods_order')->fetch($orderid)) {
            echo "<script>parent.tips_gwc('".lang("plugin/aljbdx","aljbdx_inc_php_15")."','');</script>";
            exit;
        }
        $status = 1;
        if($_GET['payment'] == '6' || $totalprice<=0){
            $status = 2;
        }
        if($new_price_order_num<=0){
            if($aljtsq_post_goods){//�ŵ���Ʒ��������
                $new_price_num = DB::result_first('select count(*) from %t a left join %t b on a.goods_id=b.id where a.uid=%d and a.pid=%d and a.type=1 and b.new_price>0 ',array('aljgwc','aljbd_goods', $_G['uid'],0));
            }else{
                $new_price_num = DB::result_first('select count(*) from %t a left join %t b on a.goods_id=b.id where a.uid=%d and a.pid=%d and a.type=0 and b.new_price>0 ',array('aljgwc','aljbd_goods', $_G['uid'],0));
            }
            if($new_price_num > 1){
                $tips_1 = '&#26032;&#20154;&#20215;&#21830;&#21697;&#26368;&#22810;&#36873;&#49;&#31181;&#36141;&#20080;';
                echo "<script>parent.tips_gwc('".$tips_1."','');</script>";
                exit;
            }
        }
        foreach($query as $value) {
            $good_1=C::t('#'.$pluginid.'#'.$pluginid.'_goods')->fetch($value['goods_id']);
            if($new_price_order_num<=0 && $good_1['new_price'] > 0){
                    
                if($value['num']>1){
                    $tips_1 = '&#26032;&#20154;&#20215;&#21830;&#21697;&#26368;&#22810;&#36141;&#20080;&#49;&#20221;';
                    echo "<script>parent.tips_gwc('".$good_1['name'].','.$tips_1."','');</script>";
                    exit;
                }
            }
            //ms
            if($_G['cache']['plugin']['aljms']['is_aljms']){
                $ms_date = dgmdate(TIMESTAMP, "Ymd");
                
                $ms_info = DB::fetch_first('select * from %t where ms_status = 0 and ms_gid=%d and ms_date=%d and ms_start_time<=%d and ms_end_time>%d and ms_sale_num<ms_num',array('aljhtx_activity_ms_enter',$value['goods_id'],$ms_date,TIMESTAMP,TIMESTAMP));
                
                if($ms_info){
                    $ms_gwc_num = DB::result_first('select sum(num) from %t where goods_id=%d and uid=%d',array('aljgwc',$value['goods_id'],$_G['uid']));
                    if($ms_info['ms_start_time'] < TIMESTAMP && $ms_info['ms_end_time'] > TIMESTAMP && ($value['path'] == $ms_info['ms_sku'] || $ms_info['ms_sku']==0)){
                        $ms_status = 1;
                        if($ms_info['ms_limit_num']>0){
                            $order_limit_amount = DB::result_first('select sum(a.num) from %t a left join %t b on a.orderid=b.orderid where a.goods_id=%d and b.status<6 and b.uid=%d and a.order_type=1',array('aljbd_goods_order_list','aljbd_goods_order',$good_1['id'],$_G['uid']));

                            if(intval($order_limit_amount) + $ms_gwc_num > $ms_info['ms_limit_num']){
                                echo "<script>parent.tips_gwc('".lang("plugin/aljbdx","aljbdx_inc_php_40").$ms_info['ms_limit_num'].lang("plugin/aljbdx","aljbdx_inc_php_41")."','');</script>";
                                exit;
                            }
                        }
                        if ($ms_info['ms_num'] < $ms_gwc_num+$ms_info['ms_sale_num']) {
                            echo "<script>parent.tips_gwc('".$good_1['name'].lang('plugin/aljbdx','aljbdx_inc_php_61')."','');</script>";
                            exit;
                        }
                    }
                }
            }


            if($good_1['limit_amount']>0){
                if($good_1['limit_type'] == 1){
                    
                    $order_limit_amount = DB::result_first('select sum(a.num) from %t a left join %t b on a.orderid=b.orderid where a.goods_id=%d and b.status<6 and b.uid=%d and b.submitdate>=%d',array('aljbd_goods_order_list','aljbd_goods_order',$good_1['id'],$_G['uid'],$nowDayTime));
                }else{
                    $order_limit_amount = DB::result_first('select sum(a.num) from %t a left join %t b on a.orderid=b.orderid where a.goods_id=%d and b.status<6 and b.uid=%d',array('aljbd_goods_order_list','aljbd_goods_order',$good_1['id'],$_G['uid']));
                }
                if(intval($order_limit_amount)+ $value['num'] > $good_1['limit_amount']){
                    echo "<script>parent.tips_gwc('".$good_1['name'].lang("plugin/aljbdx","aljbdx_inc_php_28").$good_1['limit_amount'].lang("plugin/aljbdx","aljbdx_inc_php_29")."','');</script>";
                    exit;
                }
            }
            $gattrsku = skups($good_1['attr_sku'],$value['path']);//��ϼ۸���
            
            $other = unserialize($good_1['other']);
            //$other[unified_inventory]
            if($other[unified_inventory] == 1){
                if ($good_1['amount'] < $value['num']) {
                    echo "<script>parent.tips_gwc('".$good_1['name'] . $value['content']."&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;','');</script>";
                    exit;
                }
            }else{
                if ($good_1['attr_sku'] && $gattrsku['stock'] < $value['num']) {//��Ͽ��
                    echo "<script>parent.tips_gwc('".$good_1['name'] . $value['content']."&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;','');</script>";
                    exit;
                }else{
                    if ($good_1['amount'] < $value['num']) {
                        echo "<script>parent.tips_gwc('".$good_1['name'] . $value['content']."&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;','');</script>";
                        exit;
                    }
                }
            }
            

            if (TIMESTAMP > $good_1['endtime']  && !empty($good_1['endtime'])) {
                echo "<script>parent.tips_gwc('".$good_1['name']."&#19981;&#22312;&#27963;&#21160;&#26102;&#38388;&#20869;','');</script>";
                exit;
            }
            if ($good_1['state']) {
                echo "<script>parent.tips_gwc('".$good_1['name']."&#21830;&#21697;&#24050;&#19979;&#26550;','');</script>";
                exit;
            }
            
            unset($ms_status);
            unset($ms_info);
        }
        foreach($query as $value) {
            $good_1=C::t('#'.$pluginid.'#'.$pluginid.'_goods')->fetch($value['goods_id']);
            
            $goods_name.=$value['name'].'';

            $insertarray = array(
                'orderid' => $orderid,
                'status' => $status,
                'goods_id' => $value['goods_id'],
                'shop_id'  => $value['shop_id'],
                'store_id'  => $value['store_id'],
                'uid'      => $_G['uid'],
                'num'      => $value['num'],
                'price'	   => $value['price'],
                'ip'	   => $_G['clientip'],
                'dateline' => $_G['timestamp'],
                'content'  => $value['content'],
                'path'  => $value['path'],
                'name'  => $value['name'],
                'fare'  => $_GET['get_to_the_shop'] == 1?0:$value['fare'],
                'fare_desc'  => $_GET['get_to_the_shop'] == 1?1:$value['fare_desc'],
                'order_type'  => $ms_status == 1?1:0,
                'ms_enter_id'  => $ms_info['id'],
                'pid'  => $value['pid'],
                'get_to_the_shop'  => $_GET['get_to_the_shop'],
                'goodsinfo' => serialize($good_1)
            );
            
            if(file_exists("source/plugin/xydz/xydz.inc.php")){
                require_once 'source/plugin/xydz/include/cartsubmit.php';
            }

            if(file_exists("source/plugin/dz_1/dz_1.inc.php")){
                $ext_nums+=$value['ext_num'];
                $insertarray['ext_num'] = $value['ext_num'];
            }
            if($good_1['is_distribution'] > 0 && $good_1['dis_commission'] > 0 && $_G['cache']['plugin']['aljsfx']['is_aljsfx']){
                $insertarray['is_distribution']  = $good_1['is_distribution'];
                $insertarray['dis_commission']  = $good_1['dis_commission'];
                $o_amount = 2;
            }
            C::t('#aljbdx#aljbd_goods_order_list')->insert($insertarray);

            if(is_file(DISCUZ_ROOT.'source/plugin/aljayy/controller/aljayy/goods.php')){
                $aljayy = DB::fetch_first('select * from %t a left join %t b on a.goods_id=b.id where a.goods_id = %d', array('aljayy_goods', 'aljbd_goods', $good_1['id']));
                if($aljayy){
                    if($aljayy['reduction_method'] == 'byorder'){
                        skunum($good_1['attr_sku'],$value['path'],$value['num'],$good_1['id']);//����Ͽ��
                    }
                }else{
                    skunum($good_1['attr_sku'],$value['path'],$value['num'],$good_1['id']);//����Ͽ��
                }
            }else{
                skunum($good_1['attr_sku'],$value['path'],$value['num'],$good_1['id']);//����Ͽ��
            }
            unset($ms_status);
            unset($ms_info);
        }
        if($isappbyme && $_GET['payment'] == 1){
            $_GET['payment'] = 3;
        }
        
        $orderarray=array(
            'orderid' => $orderid,
            'status' => $status,
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'shop_id' => $_GET['shop_id'],
            'price' => $totalprice,
            'submitdate' => $_G['timestamp'],
            'remarks' => $attrs.$_GET['remarks'],
            'stitle' => $goods_name,
            'payment' => $_GET['payment'],
            'fare' => $fare,
            'pid'  => $value['pid'],
            'mobile'  => $value['mobile'],
            'browser'  => $value['browser'],
            'discount' => $_GET['dis'],
            'get_to_the_shop'  => $_GET['get_to_the_shop'],
            'order_type'  => $ms_status == 1?1:0,
        );
        if($_G['cache']['plugin']['aljbdx']['buy_identity_information'] && $_G['cache']['plugin']['aljbdx']['buy_identity_information_type']){
            
            if($_G['cache']['plugin']['aljbdx']['buy_identity_information'] == 1 && !$_GET['news']['id_card']){
                echo "<script>parent.tips_gwc('".lang('plugin/aljbdx','aljbdx_inc_php_65')."','');</script>";
                exit;
            } else if($_G['cache']['plugin']['aljbdx']['buy_identity_information'] == 2){
                if(!$_GET['news']['name'] || !$_GET['news']['tel']){
                    echo "<script>parent.tips_gwc('".lang('plugin/aljbdx','aljbdx_inc_php_66')."','');</script>";
                    exit;
                }else if(!preg_match($regular, $_GET['news']['tel'])){
                    echo "<script>parent.tips_gwc('".lang('plugin/aljbdx','aljbdx_inc_php_67')."','');</script>";
                    exit;
                }
            }else if($_G['cache']['plugin']['aljbdx']['buy_identity_information'] == 3){
                
                if(!$_GET['news']['id_card'] || !$_GET['news']['tel'] || !$_GET['news']['name']){
                    echo "<script>parent.tips_gwc('".lang('plugin/aljbdx','aljbdx_inc_php_68')."','');</script>";
                    exit;
                }else if(!preg_match($regular, $_GET['news']['tel'])){
                    echo "<script>parent.tips_gwc('".lang('plugin/aljbdx','aljbdx_inc_php_67')."','');</script>";
                    exit;
                }
            }
            if($_GET['news']){
                $orderarray['other'] = serialize($_GET['news']);
            }
        }
        if($_GET['payment'] == '6' || $totalprice<=0){
            $orderarray['confirmdate'] = TIMESTAMP;
        }
        if($o_amount == 2){
            $orderarray['amount'] = $o_amount;
        }
        if($_GET['couponid'] && $_G['cache']['plugin']['aljsyh']['is_aljsyh']){
            if(DB::update('aljsyh_consume_log',array('status'=>2,'use_time'=>TIMESTAMP),array('id'=>intval($_GET['couponid']),'status'=>1))){
                $orderarray['cid']=intval($_GET['couponid']);
            }
        }
        if($_G['cache']['plugin']['aljtsq']['is_aljtsq']){
            if($_GET['store_id'] > 0){
                $orderarray['store_id'] = $_GET['store_id'];
                $orderarray['store_address'] = serialize(C::t('#aljtsq#aljtsq_store')->fetch($_GET['store_id']));
            }else{
                
                $orderarray['store_address'] = serialize($bdinfo);
            }
        }
        $orderarray['address'] = serialize($address);
        if($_GET['pay_integral'] && $_GET['pay_ext']){
            $orderarray['pay_integral'] = $rmb;
            $orderarray['pay_ext'] = $doext;
        }
        if($give_integral>0){
            $orderarray['give_integral'] = $give_integral;
        }
        if(($_GET['pay_integral'] && $_GET['pay_ext']) || $give_integral>0){
            $orderarray['ext'] = $aljtsq_post_goods ? $_G['cache']['plugin']['aljtsq']['exttype'] : $_G['cache']['plugin']['aljbdx']['exttype'];
        }
        C::t('#aljbdx#aljbd_goods_order')->insert($orderarray);

        if($_GET['pay_integral'] && $_GET['pay_ext']) {
            $exttype = $aljtsq_post_goods ? $_G['cache']['plugin']['aljtsq']['exttype'] : $_G['cache']['plugin']['aljbdx']['exttype'];
            updatemembercount(
                $_G['uid'],
                array($exttype => -intval($doext)),
                '',
                '',
                '',
                '',
                lang("plugin/aljbdx","aljbdx_inc_php_30"),
                lang("plugin/aljbdx","aljbdx_inc_php_31").$rmb.lang("plugin/aljbdx","aljbdx_inc_php_32") . $doext . $_G['setting']['extcredits'][$exttype]['title'] . lang("plugin/aljbdx","aljbdx_inc_php_45") . $orderid);
        }
        //ɾ��������Ϣ
        C::t('#aljbdx#aljgwc')->delete_by_uid_shop($_G['uid'],$_GET['shop_id'],$_GET['store_id']);
        if($_GET['payment'] == '6'){
            bdx_notice($orderid);
            echo '<script>parent.tips_gwc("'.lang("plugin/aljbdx","aljbdx_inc_php_4").'",function(){parent.location.href="plugin.php?id=' . $pluginid . '&act=orderlist";});</script>';
            exit;
        }else {
            if($totalprice>0){
                $keyurlarray = array(
                    'orderid' => $orderid,
                    'time' => TIMESTAMP,
                    'price' => $totalprice,
                    'keyname' => 'aljbdx',
                    'return_url' => rtrim($qbapi->siteurl, '/').'/'.'plugin.php?id='.$pluginid.'&act=orderlist',
                    'key' => $_G['cache']['plugin']['aljbdx']['qb_key'],
                );
                $url = $qbapi -> createUrl($keyurlarray);

                echo "<script>parent.location.href='" . $url . "';</script>";

            }else {
                bdx_notice($orderid);
                $order = $orderarray;
                if(($order['commodity_type'] == 1 && $order['category'] == 1 && $_G['cache']['plugin']['aljstg']['is_aljstg']) || ($order['get_to_the_shop'] == 1 && $_G['cache']['plugin']['aljstg'] && $order['commodity_type'] == 0)){
                    if ($order['get_to_the_shop'] == 1) {
                        $type = 1;
                        $replacetext = $_G['cache']['plugin']['aljstg']['pick_up_code_tips'];
                    } else {
                        $type = 0;
                        $replacetext = $_G['cache']['plugin']['aljstg']['code_tips'];
                    }
                    include_once DISCUZ_ROOT . 'source/plugin/aljbdx/function/new_function.php';
                    $res = randcode($type, $replacetext, $order, $goods_id);//ȡ������Ź�ȯ����
                    if($res){
                        C::t('#aljgwc#aljbd_goods_order')->update($_GET['orderid'], array('status' => 3));
                    }
                }
                echo '<script>parent.tips_gwc("'.lang("plugin/aljbdx","aljbdx_inc_php_5").'",function(){parent.location.href="plugin.php?id=' . $pluginid . '&act=orderlist";});</script>';
            }

            exit;
            echo "<script>parent.location.href='".rtrim($qbapi->siteurl, '/')."/plugin.php?id=aljgwc&act=cart_pay&orderid=" . $orderid . "';</script>";
            exit;
        }
    }
}else if($_GET['act'] == 'delcart'){
    if($_GET['formhash'] != $_G['formhash']) {
        showmessage('submit_invalid');
    }
    $cart = C::t('#aljbdx#aljgwc')->fetch($_GET['cart_id']);
    if($_G['cache']['plugin']['aljbd_bq']['is_aljbd_bq']){
        $g = C::t('#aljbd#aljbd_goods')->fetch($cart['goods_id']);
        if($g['product_label']){
            $biaoqian = DB::fetch_all('select * from %t where id IN (%n)',array('aljbd_bq',explode(',',$g['product_label'])));
            $jiaobiao = $zhuanti = $dapeishangpin = $autohtml = array();
            foreach($biaoqian as $bq_k => $bq_v){
                if($bq_v['type'] == 1){
                    $jiaobiao = $bq_v;
                }else if($bq_v['type'] == 2){
                    $zhuanti = $bq_v;
                }else if($bq_v['type'] == 3){
                    $dapeishangpin = $bq_v;
                }else if($bq_v['type'] == 4){
                    $autohtml = $bq_v;
                }
            }
            if($dapeishangpin){
                //������⣬�ٵ�����ʾ
                $bq_goods = DB::fetch_all('select * from %t where qid=%d',array('aljbd_bq_goods',$dapeishangpin['id']));
                
                if($bq_goods){
                    $bq_gids = array();
                    foreach($bq_goods as $bq_k => $bq_v){
                        $bq_gids[] = $bq_v['gid'];
                    }
                }
                
                if($bq_gids){
                    $bq_gids[] = $cart['goods_id'];
                    DB::query('delete from %t where uid=%d and goods_id in (%n)',array('aljgwc',$_G['uid'],$bq_gids));
                }else{
                    C::t('#aljbdx#aljgwc')->delete($_GET['cart_id']);
                }
            }else{
                C::t('#aljbdx#aljgwc')->delete($_GET['cart_id']);
            }
        }else{
            C::t('#aljbdx#aljgwc')->delete($_GET['cart_id']);
        }
    }else{
        C::t('#aljbdx#aljgwc')->delete($_GET['cart_id']);
    }
    
    if($aljtsq_post_goods){
        showmessage('operation_done', 'plugin.php?id=aljtsc&c=aljtsc&a=cart', array(), array('header' => true));
    }else{
        showmessage('operation_done', 'plugin.php?id=aljbdx&act=cart&pluginid='.$pluginid, array(), array('header' => true));
    }
}else if($act == 'cartnum'){
    if($aljtsq_post_goods){//�ŵ���Ʒ��������
        
        $store_id_con = ' and type=1';
        
        $cartnum = DB::result_first('select count(*) from %t where uid=%d and pid=0 '.$store_id_con,array('aljgwc',$_G['uid']));
    }else{
        if($_G['cache']['plugin']['aljtsq']['is_aljtsq']){
            $store_id_con = ' and store_id=0';
        }
        $cartnum = DB::result_first('select count(*) from %t where uid=%d and pid=0 '.$store_id_con,array('aljgwc',$_G['uid']));
    }
    
    echo $cartnum;
    exit;
}else if($act == 'addcart'){
    if($_GET['formhash'] != $_G['formhash']) {
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('submit_invalid','');</script>";
            exit;
        }else{
            echo '<script>parent.showDialog("submit_invalid","")</script>';
            exit;
        }
    }
    if(empty($_GET['gid'])) {
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".$alj_lang['The_goods_do_not_exist']."','');</script>";
            exit;
        }else{
            echo '<script>parent.showDialog("'.$alj_lang['The_goods_do_not_exist'].'","")</script>';
            exit;
        }
    }
    $goods = $g = C::t('#'.$pluginid.'#'.$pluginid.'_goods')->fetch($_GET['gid']);
    if($goods['store_id'] > 0){
        define('IN_MOBILE', 2);
        $_G['mobile'] = 2;
    }
    if($goods['limit_amount']>0){
        if($goods['limit_type'] == 1){
            
            $order_limit_amount = DB::result_first('select sum(a.num) from %t a left join %t b on a.orderid=b.orderid where a.goods_id=%d and b.status<6 and b.uid=%d and b.submitdate>=%d',array('aljbd_goods_order_list','aljbd_goods_order',$goods['id'],$_G['uid'],$nowDayTime));
        }else{
            $order_limit_amount = DB::result_first('select sum(a.num) from %t a left join %t b on a.orderid=b.orderid where a.goods_id=%d and b.status<6 and b.uid=%d',array('aljbd_goods_order_list','aljbd_goods_order',$goods['id'],$_G['uid']));
        }
        if(intval($order_limit_amount) + $num > $goods['limit_amount']){
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('".lang("plugin/aljbdx","aljbdx_inc_php_33").$goods['limit_amount'].lang("plugin/aljbdx","aljbdx_inc_php_34")."','');</script>";
                exit;
            }else{
                echo '<script>parent.showDialog("'.lang("plugin/aljbdx","aljbdx_inc_php_35").$goods['limit_amount'].lang("plugin/aljbdx","aljbdx_inc_php_36").'","")</script>';
                exit;
            }
        }
    }

    $price = $goods['price1'];
    $title = $goods['name'];
    $shop_id = $goods['bid'];
    
    
    $goods['attr_value'] = unserialize($goods['attr_value']);
    foreach($goods['attr_value'] as $k => $v){
        $gattrvalue[$v['symbol']] = $v;
    }
    $goods['attr_sku'] = unserialize($goods['attr_sku']);
    foreach($goods['attr_sku'] as $k => $v){
        $gattrsku[$v['path']] = $v;
    }
    if($_GET['typename']){
        foreach($_GET['typename'] as $v){
            if($v){
                $attrs[]=$gattrvalue[$v]['value'];
                $attrsid[]=$v;
            }
        }
        $attrs = implode(',',$attrs);
        $attrsid = implode(',',$attrsid);
    }
    if($gattrsku[$attrsid]['saleprice']){
        $price = $gattrsku[$attrsid]['saleprice'];//��ϼ۸�
        $stock = $gattrsku[$attrsid]['stock'];//��ϼ۸�
    }
    //$gattrsku_1 = skups($goods['attr_sku'],$attrsid);//��ϼ۸���
    if($price<=0){
        
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".lang("plugin/aljbdx","aljbdx_inc_php_3")."','');</script>";
            exit;
        }else{
            echo '<script>parent.showDialog("'.lang("plugin/aljbdx","aljbdx_inc_php_3").'","")</script>';
            exit;
        }
    }
    $other = unserialize($goods['other']);
    //$other[unified_inventory]
    if($other[unified_inventory] == 1){
        if ($goods['amount'] < $_GET['num']) {
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('".$alj_lang['The_goods_sold']."','');</script>";
                    exit;
                }else{
                    echo '<script>parent.showDialog("'.$alj_lang['The_goods_sold'].'","")</script>';
                    exit;
                }
        }
    }else{
        if($goods['attr_sku'] && $attrsid){

            if($stock < $_GET['num']){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('".$alj_lang['The_goods_sold']."','');</script>";
                    exit;
                }else{
                    echo '<script>parent.showDialog("'.$alj_lang['The_goods_sold'].'","")</script>';
                    exit;
                }
            }
        }else{
            if($goods[amount]<=0){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('".$alj_lang['The_goods_sold']."','');</script>";
                    exit;
                }else{
                    echo '<script>parent.showDialog("'.$alj_lang['The_goods_sold'].'","")</script>';
                    exit;
                }
            }
        }
    }
    $cart = DB::result_first('select count(*) from %t where goods_id=%d and uid=%d and pid=%d and path=%s',array('aljgwc',$_GET['gid'], $_G['uid'],$pid,$attrsid));
    if($new_price_order_num<=0 && $goods['new_price'] > 0){
        if($goods['store_id'] > 0){
            $new_price_num = DB::result_first('select count(*) from %t a left join %t b on a.goods_id=b.id where a.uid=%d and a.pid=%d and a.type=1 and b.new_price>0 ',array('aljgwc','aljbd_goods', $_G['uid'],0));
        }else{
            $new_price_num = DB::result_first('select count(*) from %t a left join %t b on a.goods_id=b.id where a.uid=%d and a.pid=%d and a.type=0 and b.new_price>0 ',array('aljgwc','aljbd_goods', $_G['uid'],0));
        }
        if($new_price_num >= 1 && !$cart){
            $tips_1 = '���˼���Ʒ���ѡ'.$_G['cache']['plugin']['aljsqtg']['new_price_num'].'�ֹ���';
        }else if($new_price_num >= 1 && $cart){
            $tips_1 = '&#26032;&#20154;&#20215;&#21830;&#21697;&#26368;&#22810;&#36141;&#20080;&#49;&#20221;';
        }
        if($tips_1){
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('".$tips_1."','');</script>";
                exit;
            }else{
                echo '<script>parent.showDialog("'.$tips_1.'","")</script>';
                exit;
            }
        }
    }
    if($cart){
        $num = $_GET['num']?$_GET['num']:1;
        DB::query('update %t set num=num+%d where goods_id=%d and uid=%d and pid=%d and path=%s', array('aljgwc',$num,$_GET['gid'],$_G['uid'],$pid,$attrsid));
    } else {
        $setarr = array(
            'goods_id' => $_GET['gid'],
            'shop_id' => $shop_id,
            'name' => $title,
            'num' => $_GET['num']?$_GET['num']:1,
            'price' => $price,
            'fare' => $goods['fare'],
            'fare_desc' => $goods['fare_desc'],
            'uid' => $_G['uid'],
            'content' => $attrs,
            'path' => $attrsid,
            'username' => $_G['username'],
            'dateline' => $_G['timestamp'],
            'ip' => $_G['clientip'],
            'pid' => $pid,
            'ext' => $goods['extcredit'],
            'browser' => $_SERVER['HTTP_USER_AGENT'],
        );
        if($_G['cache']['plugin']['aljtsq']['is_aljtsq']){
            $store_id = $goods['store_id'];
            $setarr['store_id'] = $goods['store_id'];
            if($goods['store_id'] > 0){
                $setarr['type'] = 1;
            }
        }
        if($_G['mobile']){//1���ֻ���2��PC
            $setarr['mobile'] = 1;
        }else{
            $setarr['mobile'] = 2;
        }
        C::t('#aljbdx#aljgwc')->insert($setarr);
    }
    if($_G['cache']['plugin']['aljbd_bq']['is_aljbd_bq']){
        $g = $goods;
        if($g['product_label']){
            $biaoqian = DB::fetch_all('select * from %t where id IN (%n)',array('aljbd_bq',explode(',',$g['product_label'])));
            $jiaobiao = $zhuanti = $dapeishangpin = $autohtml = array();
            foreach($biaoqian as $bq_k => $bq_v){
                if($bq_v['type'] == 1){
                    $jiaobiao = $bq_v;
                }else if($bq_v['type'] == 2){
                    $zhuanti = $bq_v;
                }else if($bq_v['type'] == 3){
                    $dapeishangpin = $bq_v;
                }else if($bq_v['type'] == 4){
                    $autohtml = $bq_v;
                }
            }
            if($dapeishangpin){
                //������⣬�ٵ�����ʾ
                $bq_goods = DB::fetch_all('select a.*,b.price1,b.attr_sku,b.commodity_type,b.collage_price,b.price2,b.name,b.pic1,b.fare,b.fare_desc from %t a left join %t b on a.gid=b.id where a.qid=%d and a.g_check=1 and a.uid=%d',array('aljbd_bq_goods_check','aljbd_goods',$dapeishangpin['id'],$_G['uid']));
                
                if($bq_goods){
                    
                    foreach($bq_goods as $bq_k => $bq_v){
                        $cart = DB::result_first('select count(*) from %t where goods_id=%d and uid=%d and pid=%d',array('aljgwc',$bq_v['gid'], $_G['uid'],$pid));
                    
                        if($cart){
                            $num = 1;
                            DB::query('update %t set num=num+%d where goods_id=%d and uid=%d and pid=%d ', array('aljgwc',$num,$bq_v['gid'],$_G['uid'],$pid));
                        } else {
                            $setarr = array(
                                'goods_id' => $bq_v['gid'],
                                'shop_id' => $shop_id,
                                'name' => $bq_v['name'],
                                'num' => 1,
                                'price' => $bq_v['price'],
                                'fare' => $bq_v['fare'],
                                'fare_desc' => $bq_v['fare_desc'],
                                'uid' => $_G['uid'],
                                'username' => $_G['username'],
                                'dateline' => $_G['timestamp'],
                                'ip' => $_G['clientip'],
                                'pid' => $pid,
                                'browser' => $_SERVER['HTTP_USER_AGENT'],
                            );
                            if($_G['mobile']){//1���ֻ���2��PC
                                $setarr['mobile'] = 1;
                            }else{
                                $setarr['mobile'] = 2;
                            }
                            C::t('#aljbdx#aljgwc')->insert($setarr);
                        }
                    }
                    
                }
                if($_G['cache']['plugin']['aljbd_bq']['add_gwc_type_header'] == 2){
                    echo "<script>parent.tips('".$alj_lang['Join_success']."',function(){parent.location.href='plugin.php?id=aljbdx&act=cart&pluginid=aljbd&shop_id=".$shop_id."';});</script>";
                    exit;
                }else if($_G['cache']['plugin']['aljbd_bq']['add_gwc_type_header'] == 1){
                    echo "<script>parent.tips('".$alj_lang['Join_success']."',function(){parent.location.href='plugin.php?id=aljbdx&act=cart&pluginid=aljbd';});</script>";
                    exit;
                }
            }
        }
    }
    if($_G['mobile']){
        
        if($goods['store_id']>0){
            echo "<script>parent.cartnum('plugin.php?id=aljbdx&act=cartnum&store=yes');parent.tips('".$alj_lang['Join_success']."','');</script>";
        }else{
            echo "<script>parent.cartnum('plugin.php?id=aljbdx&act=cartnum');parent.tips('".$alj_lang['Join_success']."','');</script>";
        }
        
        exit;
    }else{
        echo"<script language='JavaScript'> ";
        echo"parent.window.showWindow('tips','plugin.php?id=aljgwc&act=tips&pluginid=".$pluginid."');";
        echo"</script>";
    }
}else if($_GET['act'] == 'buy'){

    $num = intval($_GET['num'])>0 ? intval($_GET['num']) : 1;

    $goods_id = $_GET['goods_id'];
    $goods=C::t('#'.$pluginid.'#'.$pluginid.'_goods')->fetch($_GET['goods_id']);
    if($goods['store_id'] > 0){
        define('IN_MOBILE', 2);
        $_G['mobile'] = 2;
    }
    if($goods['store_id'] >0){
        $_G['cache']['plugin']['aljbdx']['exttype'] =  $_G['cache']['plugin']['aljtsq']['exttype'];
        $_G['cache']['plugin']['aljbdx']['proportions'] = $_G['cache']['plugin']['aljtsq']['proportions'];
        $_GET['store_id'] = $goods['store_id'];
        $bdinfo = C::t('#aljtsq#aljtsq_store')->fetch($_GET['store_id']);
    }else{
        $bid = $goods['bid'];
        $bdinfo = C::t('#aljbd#aljbd')->fetch($bid);
    }
    
    if($goods['other']){
        $other = unserialize($goods['other']);
    }
    if($goods['limit_amount']>0 && $_GET['ajax'] != 'yes'){
        if($goods['limit_type'] == 1){
            
            $order_limit_amount = DB::result_first('select sum(a.num) from %t a left join %t b on a.orderid=b.orderid where a.goods_id=%d and b.status<6 and b.uid=%d and b.submitdate>=%d',array('aljbd_goods_order_list','aljbd_goods_order',$goods['id'],$_G['uid'],$nowDayTime));
        }else{
            $order_limit_amount = DB::result_first('select sum(a.num) from %t a left join %t b on a.orderid=b.orderid where a.goods_id=%d and b.status<6 and b.uid=%d',array('aljbd_goods_order_list','aljbd_goods_order',$goods['id'],$_G['uid']));
        }
        if(intval($order_limit_amount) + $num > $goods['limit_amount']){
            echo "<script>alert('".lang("plugin/aljbdx","aljbdx_inc_php_37").$goods['limit_amount'].lang("plugin/aljbdx","aljbdx_inc_php_38")."');window.history.go(-1);</script>";
            exit;
        }
    }


    $goods['attr_value'] = unserialize($goods['attr_value']);
    foreach($goods['attr_value'] as $k => $v){
        $gattrvalue[$v['symbol']] = $v;
    }
    $goods['attr_sku'] = unserialize($goods['attr_sku']);
    foreach($goods['attr_sku'] as $k => $v){
        $gattrsku[$v['path']] = $v;
    }
    if($_GET['typename']){
        foreach($_GET['typename'] as $v){
            if($v){
                $attrs[]=$gattrvalue[$v]['value'];
                $attrsid[]=$v;
            }
        }
        $attrs = implode(',',$attrs);
        $attrsid = implode(',',$attrsid);
    }else if($_GET['attrsid']){
        $attrs = $_GET['attrs'];
        $attrsid = $_GET['attrsid'];
    }

    if($gattrsku[$attrsid]['saleprice'] && $attrsid){
        $goods['price1'] = $gattrsku[$attrsid]['saleprice'];//��ϼ۸�
    }
    if($_GET['commodity_type'] == 2 && $goods['collage_price']>0){
        $goods['price1'] = $goods['collage_price'];//ƴ�ż۸�
        if($gattrsku[$attrsid]['saleprice'] && $attrsid){
            $goods['price1'] = $gattrsku[$attrsid]['marketprice'];//��ϼ۸�
        }
    }
    if($goods['commodity_type'] == 7 && $_GET['ajax'] != 'yes'){
        $kj_info = DB::fetch_first('select * from %t where id=%d',array('aljkj',$_GET['kid']));
        if(!$kj_info || $kj_info['status'] != 1 || $kj_info['uid'] != $_G['uid']){
            $navtitle = lang('plugin/aljbd','view_php_10');
            if($kj_info['status'] > 1 && $kj_info['status'] < 7){
                $desc = '������Ʒ�Ѿ����������¿���';
            }else{
                $desc = '������Ʒ����ֱ�ӹ���';
            }
            
            $info = array('desc' => $desc);
            $info['title'] = $navtitle;
            $info['icon'] = 'weui-icon-warn';
            $info['btn_primary'] = array('value' => 'ȥ����', 'url' => 'plugin.php?id=aljbd&act=goodview&gid='.$goods['gid']);
            $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljkj');
            include template('aljbd:new/common/tips');
            exit;
        }
        //$goods['price1'] = $kj_info['price'];
    }else{
        if($goods['price1']<=0){
            echo "<script>alert('".lang("plugin/aljbdx","aljbdx_inc_php_3")."');window.history.go(-1);</script>";
            exit;
        }
    }
    
    if($goods['new_price']>0){
        //�Ƿ�δ�¹���������
        $new_order_num = DB::result_first('select count(*) from %t where uid=%d and status>1 and status<7 and pid=0',array('aljbd_goods_order',$_G['uid']));
        if($new_order_num<=0){
            $goods['price1'] = $goods['new_price'];//����ר���۸�
            if($gattrsku[$attrsid]['newprice'] && $attrsid && $gattrsku[$attrsid]['newprice']>0){
                $goods['price1'] = $gattrsku[$attrsid]['newprice'];//��ϼ۸�
            }
        }
    }
    
    if($goods['is_volume'] == 2 && $attrsid){
        $volume_label = DB::fetch_first('select * from %t where goods_id=%d and price_type=%d and path=%s and volume_number<=%d order by id desc limit 1',array('aljbd_goods_volume_price',$goods_id,$goods['is_volume'],$attrsid,$num));

    }else if($goods['is_volume'] == 1){
        $volume_label = DB::fetch_first('select * from %t where goods_id=%d and price_type=%d and volume_number<=%d order by id desc limit 1',array('aljbd_goods_volume_price',$goods_id,$goods['is_volume'],$num));
    }
    if($_GET['commodity_type'] == 2 && $goods['collage_price']>0 && $volume_label['volume_price_pt']>0) {
        $goods['price1'] = $volume_label['volume_price_pt'];//ƴ����Ʒ���ݼ۸�
    }else if($volume_label['volume_price']>0){
        $goods['price1'] = $volume_label['volume_price'];//��ͨ��Ʒ���ݼ۸�
    }
    if($goods['pic1']){
        $goods['pic1'] = $goods['pic1'].$oss_img_url;
    }
    //ms
    if($_G['cache']['plugin']['aljms']['is_aljms']){
        $ms_date = dgmdate(TIMESTAMP, "Ymd");
        
        $ms_info = DB::fetch_first('select * from %t where ms_status = 0 and ms_gid=%d and ms_date=%d and ms_start_time<=%d and ms_end_time>%d and ms_sale_num<ms_num',array('aljhtx_activity_ms_enter',$goods_id,$ms_date,TIMESTAMP,TIMESTAMP));
        
        if($ms_info){
            if($ms_info['ms_start_time'] < TIMESTAMP && $ms_info['ms_end_time'] > TIMESTAMP && ($attrsid == $ms_info['ms_sku'] || $ms_info['ms_sku']==0)){
                $goods['price1'] = $ms_info['ms_price'];
                if($_G['cache']['plugin']['aljms']['ms_no_coupons']){
                    $ms_yes = 1;
                }
            }
            if($ms_info['ms_limit_num']>0 && $_GET['ajax'] != 'yes'){
                $order_limit_amount = DB::result_first('select sum(a.num) from %t a left join %t b on a.orderid=b.orderid where a.goods_id=%d and b.status<6 and b.uid=%d and a.order_type=1',array('aljbd_goods_order_list','aljbd_goods_order',$goods['id'],$_G['uid']));

                if(intval($order_limit_amount) + $num > $ms_info['ms_limit_num']){
                    echo "<script>alert('".lang("plugin/aljbdx","aljbdx_inc_php_40").$ms_info['ms_limit_num'].lang("plugin/aljbdx","aljbdx_inc_php_41")."');window.history.go(-1);</script>";
                    exit;
                }
            }
            if ($ms_info['ms_num'] < $num+$ms_info['ms_sale_num'] && $_GET['ajax'] != 'yes') {
                echo "<script>alert('".$goods['name'].lang('plugin/aljbdx','aljbdx_inc_php_61')."');window.history.go(-1);</script>";
                exit;
            }
        }
    }
    if($_G['cache']['plugin']['aljtcc']){
        $card_user = DB::fetch_first('select * from %t where uid=%d and end_time>%d and card_id=1',array('aljtcc_card_user',$_G['uid'],TIMESTAMP));
        if($goods['card_price']>0 && $card_user){
            if($settings['is_card_price']['value']==1){
                //��Ա��
                if($attrsid){
                    $goods['price1'] = $gattrsku[$attrsid]['card_price']>0 ? $gattrsku[$attrsid]['card_price'] : $goods['price1'];//��ϼ۸�
                }else{
                    $goods['price1'] = $goods['card_price'];
                }
            }else{
                //��Ա���ۿ�
                $card_price =  substr(sprintf("%.3f",$goods['price1']*($goods['card_price']/100)),0,-1);
            
                if($card_price > 0){
                    $goods['price1'] = $card_price;
                }
            }
        }
    }
    $navtitle = lang("plugin/aljbdx","aljbdx_inc_php_39");
    
    $totalprice = $num * $goods[price1];//��Ʒ�ܼ�
    if($goods[fare]>0){
        
        $fare_price = farePrice($goods,$def_address,$bdinfo,$num);
        
        $fare = ($bdinfo['fare_type'] == 3 && $bdinfo['postal_amount']<=$totalprice) ? 0 : $fare_price['fare'];
       
    }else{
        $fare = 0;
    }
    $total = $num * $goods[price1] + $fare;//����۸�
    $pay_integral = sprintf("%.3f",$totalprice*($goods['pay_integral']/100));
    $res = integralCalculation($pay_integral);

    $doext = $res['doext'];
    $rmb = $res['rmb'];
    $myext = $res['myext'];
    
    if($app_dowm){
        $balance_deduction = card_balance($total);
    }
    
    if($goods['fare_desc'] == 1 || $goods['fare_desc'] == 2){
        $fare_d = $fare_desc[$goods['fare_desc']];
    }else{
        if($goods[fare]>0){
            $fare_d = $fare;
        }else{
            $fare_d = '&#21253;&#37038;';
        }
    }
    if($goods['store_id'] <= 0 && $bdinfo['platform_distribution'] == 1 && $_G['cache']['plugin']['aljpps']['is_aljbd'] && $goods['commodity_type'] == 0){
        $fare = $_G['cache']['plugin']['aljpps']['aljbd_fare'];
        
        if($fare>0){
            $fare_d = $fare;
        }else{
            $fare_d = '&#21253;&#37038;';
        }
    }
    
    if($_G['cache']['plugin']['aljsyh']['is_aljsyh'] && !$ms_yes){
        $discount_1 = DB::fetch_all('select a.id,b.full,b.reduction,b.coupon_type from %t a left join %t b on a.cid=b.id where (b.bid=%d or b.coupon_type=7) and ((FIND_IN_SET(%d,b.goodstype) and b.available_goods=1) or b.available_goods=0) and (((b.end>%s or b.end=0) and b.coupon_validity=0) or (b.coupon_validity>0 and b.coupon_validity*3600+a.receive_time>%d)) and b.coupon_type<9 and a.status=%d and a.uid=%d order by b.reduction desc',array(
            'aljsyh_consume_log',
            'aljbd_consume',
            intval($goods['bid']),
            intval($goods['commodity_type']), 
            TIMESTAMP,
            TIMESTAMP,
            1,
            $_G['uid']
        ));
        
        foreach($discount_1 as $dk => $kv){
            if($kv['coupon_type'] == 2){
                if($fare>0) {
                    $kv['full'] = floatval($kv['full']);
                    $kv['reduction'] = floatval($fare);
                }
            }else {
                $kv['full'] = floatval($kv['full']);
                $kv['reduction'] = floatval($kv['reduction']);
            }
            if ($kv['full'] <= $totalprice && $kv['reduction'] <= $totalprice) {
                $discount[] = $kv;
            }
        }
    }
    
    if($_GET['ajax'] == 'yes'){
        if($goods['price1']>0 || $goods['commodity_type'] == 7){
            echo json_encode(aljhtx::ajaxPostCharSet(array('price'=>$goods['price1'],'fare'=>$fare,'discount'=>$discount?$discount:1)));
            exit;
        }
    }
    include template('aljbdx:buy');
}else if($_GET['act'] == 'buysubmit'){
    if(submitcheck('formhash')) {
        
        $goods_id = $_GET['goods_id'];
        $num = intval($_GET['num']);
        
        if($down_array['status'] == 4 && $app_dowm){
            echo "<script>parent.tips_gwc('&#24050;&#26377;&#25480;&#26435;&#65292;&#35831;&#21247;&#37325;&#22797;&#36141;&#20080;&#65281;','');</script>";
            exit;
        }
        if ($num < 1) {
            echo "<script>parent.tips_gwc('&#21830;&#21697;&#25968;&#37327;&#24517;&#39035;&#22823;&#20110;&#48;','');</script>";
            exit;
        }

        if(!$_GET['payment']){
            echo "<script>parent.tips_gwc('&#35831;&#36873;&#25321;&#20184;&#27454;&#26041;&#24335;','');</script>";
            exit;
        }
        
        

        $totalprice = $_GET['totalprice'];

        if ($_GET['fare']) {
            $fare = $_GET['fare'];
        }

        $goods=C::t('#'.$pluginid.'#'.$pluginid.'_goods')->fetch($_GET['goods_id']);
        if($goods['commodity_type'] == 7){
            $kj_info = DB::fetch_first('select * from %t where id=%d',array('aljkj',$_GET['kid']));
            if(!$kj_info || $kj_info['status'] != 1 || $kj_info['uid'] != $_G['uid']){
                
                if($kj_info['status'] > 1 && $kj_info['status'] < 7){
                    $desc = '������Ʒ�Ѿ����������¿���';
                }else{
                    $desc = '������Ʒ����ֱ�ӹ���';
                }
                
                echo "<script>parent.tips_gwc('".$desc."','');</script>";
                exit;
            }
            //$goods['price1'] = $kj_info['price'];
        }
        if($goods['store_id'] > 0){
            if(strtolower(CHARSET) == 'gbk' && !$_G['mobile']){
                $_GET=T::ajaxGetCharSet($_GET);
            }
            define('IN_MOBILE', 2);
            $_G['mobile'] = 2;
        }
        $goods['give_integral_price'] = $goods['price1'];

        if(!$address && $goods['category'] == 0 && (!$_GET['get_to_the_shop'] || ($_GET['get_to_the_shop'] == 1 && $_G['cache']['plugin']['aljstg']['is_address']))){
            echo "<script>parent.tips_gwc('&#35831;&#22635;&#20889;&#25910;&#36135;&#22320;&#22336;','');</script>";
            exit;
        }
        if ($goods['state']) {
            echo "<script>parent.tips_gwc('".$goods['name']."&#21830;&#21697;&#24050;&#19979;&#26550;','');</script>";
            exit;
        }
        if(unserialize($goods['attr_sku']) && !$_GET['path']){
            echo "<script>parent.tips_gwc('&#35831;&#36820;&#22238;&#36873;&#25321;&#21830;&#21697;&#35268;&#26684;&#21518;&#20877;&#19979;&#21333;&#65281;','');</script>";
            exit;
        }
        $shop_id = $goods['bid'];
        $_GET['store_id'] = $_GET['store_id']>0 ? $_GET['store_id'] : $goods['store_id'];
        if($_GET['store_id']>0){
            $_G['cache']['plugin']['aljbdx']['exttype'] =  $_G['cache']['plugin']['aljtsq']['exttype'];
            $_G['cache']['plugin']['aljbdx']['proportions'] = $_G['cache']['plugin']['aljtsq']['proportions'];
            $bdinfo = C::t('#aljtsq#aljtsq_store')->fetch($_GET['store_id']);
        }else{
            $bdinfo = C::t('#aljbd#aljbd')->fetch($shop_id);
        }
        if($goods['other']){
            $other = unserialize($goods['other']);
        }//$other[unified_inventory]
        $gattrsku = skups($goods['attr_sku'],$_GET['path']);//��ϼ۸���
        if($goods['attr_sku'] && $_GET['path']){
            $goods['price1'] = $gattrsku['saleprice'];
            if(!$other[unified_inventory]){
                $goods['amount'] = $gattrsku['stock'];
            }
        }

        if($_GET['couponid'] && $_G['cache']['plugin']['aljsyh']['is_aljsyh'] && $_GET['dis']){
            $clogdata = DB::fetch_first('select * from %t a left join %t b on a.cid=b.id where a.status=1 and a.uid=%d and a.id=%d', array('aljsyh_consume_log', 'aljbd_consume', $_G['uid'], intval($_GET['couponid'])));
            if ($clogdata) {
                if((floatval($clogdata['reduction']) != $_GET['dis'] && $clogdata['coupon_type'] != 2) || ($clogdata['coupon_type'] == 2 && $_GET['dis']!=$fare)){
                    echo '<script>parent.tips_gwc("'.lang("plugin/aljbdx","aljbdx_inc_php_6").'","");</script>';
                    exit;
                }
            }else{
                echo '<script>parent.tips_gwc("'.lang("plugin/aljbdx","aljbdx_inc_php_6").'","");</script>';
                exit;
            }
            if($_GET['payment'] == '6' && $clogdata['coupon_type'] == 7 && !$_G['cache']['plugin']['aljpyh']['close_no_pay']){
                echo '<script>parent.tips_gwc("&#36135;&#21040;&#20184;&#27454;&#19981;&#25903;&#25345;&#20351;&#29992;&#24179;&#21488;&#20248;&#21270;&#21048;","");</script>';
                exit;
            }
        }
        //ƴ��
        if($_GET['commodity_type'] == 2){
            $goods['price1'] = $goods['collage_price'];
            if($goods['attr_sku'] && $_GET['path']){
                $goods['price1'] = $gattrsku['marketprice'];
            }
        }
        
        
        
        //���ݼ۸�
        if($goods['is_volume'] == 2 && $_GET['path']){
            $volume_label = DB::fetch_first('select * from %t where goods_id=%d and price_type=%d and path=%s and volume_number<=%d order by id desc limit 1',array('aljbd_goods_volume_price',$goods_id,$goods['is_volume'],$_GET['path'],$num));
            if($volume_label['volume_price_pt']>0 && $_GET['commodity_type'] == 2){
                $goods['price1'] = $volume_label['volume_price_pt'];//���ݼ۸�
            }else if($volume_label['volume_price'] > 0){
                $goods['price1'] = $volume_label['volume_price'];//���ݼ۸�
            }
        }else if($goods['is_volume'] == 1){
            $volume_label = DB::fetch_first('select * from %t where goods_id=%d and price_type=%d and volume_number<=%d order by id desc limit 1',array('aljbd_goods_volume_price',$goods_id,$goods['is_volume'],$num));
            if($volume_label['volume_price']>0){
                $goods['price1'] = $volume_label['volume_price'];//���ݼ۸�
            }
        }


        //ms
        if($_G['cache']['plugin']['aljms']['is_aljms']){
            $ms_date = dgmdate(TIMESTAMP, "Ymd");
            
            $ms_info = DB::fetch_first('select * from %t where ms_status = 0 and ms_gid=%d and ms_date=%d and ms_start_time<=%d and ms_end_time>%d and ms_sale_num<ms_num',array('aljhtx_activity_ms_enter',$goods_id,$ms_date,TIMESTAMP,TIMESTAMP));
            
            if($ms_info){
                if($ms_info['ms_start_time'] < TIMESTAMP && $ms_info['ms_end_time'] > TIMESTAMP && ($_GET['path'] == $ms_info['ms_sku'] || $ms_info['ms_sku']==0)){
                    $goods['price1'] = $ms_info['ms_price'];
                    $ms_status = 1;
                    if($ms_info['ms_limit_num']>0){
                        $order_limit_amount = DB::result_first('select sum(a.num) from %t a left join %t b on a.orderid=b.orderid where a.goods_id=%d and b.status<6 and b.uid=%d and a.order_type=1',array('aljbd_goods_order_list','aljbd_goods_order',$goods['id'],$_G['uid']));

                        if(intval($order_limit_amount) + $num > $ms_info['ms_limit_num']){
                            echo "<script>parent.tips_gwc('".lang("plugin/aljbdx","aljbdx_inc_php_40").$ms_info['ms_limit_num'].lang("plugin/aljbdx","aljbdx_inc_php_41")."','');</script>";
                            exit;
                        }
                    }
                    if ($ms_info['ms_num'] < $num+$ms_info['ms_sale_num']) {
                        echo "<script>parent.tips_gwc('".$goods['name'].lang('plugin/aljbdx','aljbdx_inc_php_61')."','');</script>";
                        exit;
                    }
                }
            }
        }
        if($goods['new_price']>0 && !$ms_info){
            //�Ƿ�δ�¹���������
            $new_order_num = DB::result_first('select count(*) from %t where uid=%d and status>1 and status<7 and pid=0',array('aljbd_goods_order',$_G['uid']));
            
            if($new_order_num<=0){
                if($num > 1){
                    echo "<script>parent.tips_gwc('".lang("plugin/aljbdx","aljbdx_inc_php_40").'1'.lang("plugin/aljbdx","aljbdx_inc_php_41")."','');</script>";
                    exit;
                }
                $goods['price1'] = $goods['new_price'];//����ר���۸�
                
                if($goods['attr_sku'] && $_GET['path'] && $gattrsku['newprice']>0){
                    $goods['price1'] = $gattrsku['newprice'];//��ϼ۸�
                }
                
            }
        }
        if($goods['card_price']>0 && $_G['cache']['plugin']['aljtcc']){
            $card_user = DB::fetch_first('select * from %t where uid=%d and end_time>%d and card_id=1',array('aljtcc_card_user',$_G['uid'],TIMESTAMP));
            if($card_user){
                if($settings['is_card_price']['value'] == 1){
                    //��Ա��
                    
                    
                    if($goods['attr_sku'] && $_GET['path']){
                        $goods['price1'] = $gattrsku['card_price']>0 ? $gattrsku['card_price'] : $goods['price1'];//��ϼ۸�
                    }else{
                        $goods['price1'] = $goods['card_price'];
                    }
                    
                    if($goods['card_price'] > 0 || $gattrsku['card_price']>0){
                        $card_status = 1;
                    }
                }else{
                    //��Ա���ۿ�
                    $card_price = substr(sprintf("%.3f",$goods['price1']*($goods['card_price']/100)),0,-1);
                    if($card_price > 0){
                        $goods['price1'] = $card_price;
                        $card_status = 1;
                    }
                }
            }
        }
        
        //��Ʒ�޹�
        if($goods['limit_amount']>0){

            if($goods['limit_type'] == 1){
                
                $order_limit_amount = DB::result_first('select sum(a.num) from %t a left join %t b on a.orderid=b.orderid where a.goods_id=%d and b.status<6 and b.uid=%d and b.submitdate>=%d',array('aljbd_goods_order_list','aljbd_goods_order',$goods['id'],$_G['uid'],$nowDayTime));
            }else{
                $order_limit_amount = DB::result_first('select sum(a.num) from %t a left join %t b on a.orderid=b.orderid where a.goods_id=%d and b.status<6 and b.uid=%d',array('aljbd_goods_order_list','aljbd_goods_order',$goods['id'],$_G['uid']));
            }
            if(intval($order_limit_amount) + $num > $goods['limit_amount']){
                echo "<script>parent.tips_gwc('".lang("plugin/aljbdx","aljbdx_inc_php_40").$goods['limit_amount'].lang("plugin/aljbdx","aljbdx_inc_php_41")."','');</script>";
                exit;
            }
        }
        //1=������ȡ
        if($_GET['get_to_the_shop'] == 1){
            $goods['fare'] = 0;
            $goods['fare_desc'] = 1;
            $fare = 0;
            $yuantotalprice = floatval($goods['price1']*$num - $_GET['dis']);

        }else{
            
            $fare_price = farePrice($goods,$def_address,$bdinfo,$num);
            $fare = ($bdinfo['fare_type'] == 3 && $bdinfo['postal_amount']<=($goods['price1']*$num)) ? 0 : $fare_price['fare'];
            if($goods['store_id'] <= 0 && $bdinfo['platform_distribution'] == 1 && $_G['cache']['plugin']['aljpps']['is_aljbd'] && $goods['commodity_type'] == 0){
                $fare = $_G['cache']['plugin']['aljpps']['aljbd_fare'];
            }
            $yuantotalprice = floatval($goods['price1']*$num+$fare - $_GET['dis']);
        }

        if($_GET['pay_integral'] && $_GET['pay_ext']){
            if($clogdata['coupon_type'] == 2){
                $pay_integral_totalprice = floatval($goods['price1']*$num);
            }else{
                $pay_integral_totalprice = floatval($goods['price1']*$num - $_GET['dis']);
            }
            
            $pay_integral = sprintf("%.3f",$pay_integral_totalprice*($goods['pay_integral']/100));
            $res = integralCalculation($pay_integral);
            $doext = $res['doext'];
            $rmb = $res['rmb'];
            $myext = $res['myext'];
            if($_GET['pay_integral'] != $rmb || $_GET['pay_ext'] != $doext){
                echo '<script>parent.tips_gwc("'.$_G['setting']['extcredits'][$_G['cache']['plugin']['aljbdx']['exttype']]['title'].lang("plugin/aljbdx","aljbdx_inc_php_25").'","");</script>';
                exit;
            }
            $yuantotalprice = $yuantotalprice-$rmb;
        }
        if($_GET['deduction']>0 && $app_dowm){
            $balance_deduction = card_balance($yuantotalprice);
            $yuantotalprice = $yuantotalprice-$balance_deduction['deduction'];
        }
        //�ж��ύ����������ʵ�������Ƿ�һ��
        
        if(trim($yuantotalprice) != trim($totalprice)){
            echo "<script>parent.tips_gwc('&#35746;&#21333;&#24322;&#24120;&#35831;&#37325;&#35797;','');</script>";
            exit;
        }
        if(!$goods){
            echo "<script>parent.tips_gwc('".$alj_lang['The_goods_do_not_exist']."','');</script>";
            exit;
        }
        $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
        if(C::t('#aljbdx#aljbd_goods_order')->fetch($orderid)) {
            echo "<script>parent.tips_gwc('&#35746;&#21333;&#24050;&#23384;&#22312;','');</script>";
            exit;
        }

        
        if ($goods['amount'] < $num) {
            echo "<script>parent.tips_gwc('".$goods['name']."&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;','');</script>";
            exit;
        }
        if (TIMESTAMP < $goods['starttime']  && !empty($goods['starttime']) && $_G['cache']['plugin']['aljstg']) {
            echo "<script>parent.tips_gwc('".$goods['name'].$_G['cache']['plugin']['aljstg']['aljstg_name']."&#26242;&#26410;&#24320;&#22987;','');</script>";
            exit;
        }
        if (TIMESTAMP < $goods['starttime']  && !empty($goods['starttime']) && $_G['cache']['plugin']['aljsqg']) {
            echo "<script>parent.tips_gwc('".$goods['name'].$_G['cache']['plugin']['aljsqg']['aljsqg_name']."&#26242;&#26410;&#24320;&#22987;','');</script>";
            exit;
        }
        if (TIMESTAMP > $goods['endtime']  && !empty($goods['endtime'])) {
            echo "<script>parent.tips_gwc('".$goods['name']."&#19981;&#22312;&#27963;&#21160;&#26102;&#38388;&#20869;','');</script>";
            exit;
        }
        if($isappbyme && $_GET['payment'] == 1){
            $_GET['payment'] = 3;
        }
        $status = 1;
        if($_GET['payment'] == '6' || $totalprice<=0){
            $status = 2;
        }
        $goods_name.=$goods['name'];
        $insertarray = array(
            'orderid' => $orderid,
            'status' => $status,
            'goods_id' => $goods['id'],
            'shop_id'  => $shop_id,
            'uid'      => $_G['uid'],
            'num'      => $num,
            'price'	   => $goods['price1'],
            'ip'	   => $_G['clientip'],
            'dateline' => $_G['timestamp'],
            'content'  => $_GET['content'],
            'path'  => $_GET['path'],
            'name'  => $goods['name'],
            'fare'  => $goods['fare'],
            'fare_desc'  => $goods['fare_desc'],
            'pid'  => $pid,
            'category'  => $goods['category'],
            'commodity_type'  => ($_GET['commodity_type'] == 2 || $goods['commodity_type'] == 1 || $goods['commodity_type'] == 3 || $goods['commodity_type'] == 7)?$goods['commodity_type']:0,
            'collage_num'  => $_GET['commodity_type'] == 2?$goods['collage_num']:0,
            'get_to_the_shop'  => $_GET['get_to_the_shop'],
            'goodsinfo' => serialize($goods)
        );
        
        if(!$other[is_aljsqtg_stock]){
            if(is_file(DISCUZ_ROOT.'source/plugin/aljayy/controller/aljayy/goods.php')){
                $aljayy = DB::fetch_first('select * from %t a left join %t b on a.goods_id=b.id where a.goods_id = %d', array('aljayy_goods', 'aljbd_goods', $goods['id']));
                if($aljayy){//�µ������
                    if($aljayy['reduction_method'] == 'byorder'){
                        skunum($goods['attr_sku'],$_GET['path'],$num,$goods['id']);//����Ͽ��
                    }
                }else{
                    skunum($goods['attr_sku'],$_GET['path'],$num,$goods['id']);//����Ͽ��
                }
            }else{
                skunum($goods['attr_sku'],$_GET['path'],$num,$goods['id']);//����Ͽ��
            }
        }
        
        $orderarray=array(
            'orderid' => $orderid,
            'status' => $status,
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'shop_id' => $shop_id,
            'price' => $totalprice,
            'submitdate' => $_G['timestamp'],
            'remarks' => $_GET['content'].$_GET['remarks'],
            'stitle' => $goods_name,
            'payment' => $_GET['payment'],
            'fare' => $fare,
            'pid'  => $pid,
            'category'  => $goods['category'],
            'commodity_type'  => ($_GET['commodity_type'] == 2 || $goods['commodity_type'] == 1 || $goods['commodity_type'] == 3 || $goods['commodity_type'] == 7)?$goods['commodity_type']:0,
            'collage_num'  => $_GET['commodity_type'] == 2?$goods['collage_num']:0,
            'browser'  => $_SERVER['HTTP_USER_AGENT'],
            'discount' => $_GET['dis'],
            'get_to_the_shop'  => $_GET['get_to_the_shop'],
        );
        if($_GET['payment'] == '6' || $totalprice<=0){
            $orderarray['confirmdate'] = TIMESTAMP;
        }
        
        if($_G['cache']['plugin']['aljbdx']['buy_identity_information'] && (($goods['category'] == 1 && !$_G['cache']['plugin']['aljbdx']['buy_identity_information_type']) || $_G['cache']['plugin']['aljbdx']['buy_identity_information_type'])){
            
            if($_G['cache']['plugin']['aljbdx']['buy_identity_information'] == 1 && !$_GET['news']['id_card']){
                echo "<script>parent.tips_gwc('".lang('plugin/aljbdx','aljbdx_inc_php_65')."','');</script>";
                exit;
            } else if($_G['cache']['plugin']['aljbdx']['buy_identity_information'] == 2){
                if(!$_GET['news']['name'] || !$_GET['news']['tel']){
                    echo "<script>parent.tips_gwc('".lang('plugin/aljbdx','aljbdx_inc_php_66')."','');</script>";
                    exit;
                }else if(!preg_match($regular, $_GET['news']['tel'])){
                    echo "<script>parent.tips_gwc('".lang('plugin/aljbdx','aljbdx_inc_php_67')."','');</script>";
                    exit;
                }
            }else if($_G['cache']['plugin']['aljbdx']['buy_identity_information'] == 3){
                
                if(!$_GET['news']['id_card'] || !$_GET['news']['tel'] || !$_GET['news']['name']){
                    echo "<script>parent.tips_gwc('".lang('plugin/aljbdx','aljbdx_inc_php_68')."','');</script>";
                    exit;
                }else if(!preg_match($regular, $_GET['news']['tel'])){
                    echo "<script>parent.tips_gwc('".lang('plugin/aljbdx','aljbdx_inc_php_67')."','');</script>";
                    exit;
                }
            }
            if($_GET['news']){
                $orderarray['other'] = serialize($_GET['news']);
            }
        }
        if($_G['cache']['plugin']['aljtsq']['is_aljtsq']){
            if($_GET['store_id'] > 0){
                $orderarray['store_id'] = $_GET['store_id'];
                $orderarray['store_address'] = serialize(C::t('#aljtsq#aljtsq_store')->fetch($_GET['store_id']));
            }else{
                
                $orderarray['store_address'] = serialize($bdinfo);
            }
        }

        if($_G['mobile']){//1���ֻ���2��PC
            $orderarray['mobile'] = 1;
        }else{
            $orderarray['mobile'] = 2;
        }
        if($ms_status == 1){
            $orderarray['order_type'] = 1;
            $insertarray['order_type'] = 1;
            $insertarray['ms_enter_id'] = $ms_info['id'];
        }
        if($card_status == 1){
            $orderarray['order_type'] = 4;//��Ա��������ʶ
            $insertarray['order_type'] = 4;
        }
        if($goods['commodity_type'] == 7){
            $orderarray['opentime'] = $_GET['kid'];
            $insertarray['kid'] = $_GET['kid'];
        }
        //$orderarray['proportion'] = $config['proportion_aljbd'];
        
        $orderarray['address'] = serialize($address);
        $groupid = $_GET['grouporderid'];
        
        if($groupid && $_G['cache']['plugin']['aljspt']['is_aljspt']){//ƴ��
            $pt_grouporder=DB::fetch_first('select * from %t where grouporderid=%s',array('aljspt_collage_order', $groupid));
            $my_pt_order=DB::fetch_first('select * from %t where collage_order=%s and uid=%d  and status <6 ',array('aljbd_goods_order', $groupid,$_G['uid']));
            
            if($pt_grouporder['groupnumed']+1 > $pt_grouporder['groupnum']) {
                //�����Ѿ�������
                echo "<script>parent.tips_gwc('&#35813;&#22242;&#24050;&#32463;&#28385;&#20154;&#20102;','');</script>";
                exit;
            }else if($my_pt_order && $_G['cache']['plugin']['aljspt']['is_repeat']){
                //���Ѿ��μӹ�����ƴ����
                echo "<script>parent.tips_gwc('&#20320;&#24050;&#32463;&#21442;&#21152;&#36807;&#26412;&#27425;&#25340;&#22242;&#20102;','');</script>";
                exit;
            }else {
                $insertarray['collage_order']=$pt_grouporder['grouporderid'];
                $orderarray['collage_order']=$pt_grouporder['grouporderid'];
                $orderarray['opentime']=$pt_grouporder['groupopentime'];
            }
        }
        
        if($_GET['couponid'] && $_G['cache']['plugin']['aljsyh']['is_aljsyh']){
            if(DB::update('aljsyh_consume_log',array('status'=>2,'use_time'=>TIMESTAMP),array('id'=>intval($_GET['couponid']),'status'=>1))){
                $orderarray['cid']=$clogdata['cid'];
            }
        }
        if($_GET['pay_integral'] && $_GET['pay_ext']){
            $orderarray['pay_integral'] = $rmb;
            $orderarray['pay_ext'] = $doext;
        }
        if($goods['give_integral']>0){
            if($_G['cache']['plugin']['aljbd']['is_give_integral']==1 || $_GET['store_id']>0){
                if($_G['cache']['plugin']['aljbd']['send_give_integral_proportions']==1 && !$_GET['store_id']){
                    $orderarray['give_integral'] = floor($goods['price1']*($goods['give_integral']/100)*$_G['cache']['plugin']['aljbdx']['proportions'])*$num;
                }else{
                    $orderarray['give_integral'] = floor($goods['price1']*($goods['give_integral']/100))*$num;
                }
            }else{
                $orderarray['give_integral'] = $goods['give_integral']*$num;
            }
        }
        if(($_GET['pay_integral'] && $_GET['pay_ext']) || $goods['give_integral']>0){
            $orderarray['ext'] = $_GET['store_id']>0 ? $_G['cache']['plugin']['aljtsq']['exttype'] : $_G['cache']['plugin']['aljbdx']['exttype'];
        }
        if($goods['is_distribution'] > 0 && $goods['dis_commission'] > 0 && $_G['cache']['plugin']['aljsfx']['is_aljsfx']){
            $insertarray['is_distribution']  = $goods['is_distribution'];
            $insertarray['dis_commission']  = $goods['dis_commission'];
            $orderarray['amount'] = 2;
        }
        if($_GET['deduction']>0 && $app_dowm){
            $orderarray['deduction'] = $_GET['deduction'];
        }
        C::t('#aljbdx#aljbd_goods_order_list')->insert($insertarray);
        C::t('#aljbdx#aljbd_goods_order')->insert($orderarray);
        if($_GET['pay_integral'] && $_GET['pay_ext']) {
            $exttype = $_GET['store_id']>0 ? $_G['cache']['plugin']['aljtsq']['exttype'] : $_G['cache']['plugin']['aljbdx']['exttype'];
            if($exttype>0){
                updatemembercount(
                    $_G['uid'],
                    array($exttype => -intval($doext)),
                    '',
                    '',
                    '',
                    '',
                    lang("plugin/aljbdx","aljbdx_inc_php_30"),
                    lang("plugin/aljbdx","aljbdx_inc_php_31").$rmb.lang("plugin/aljbdx","aljbdx_inc_php_44") . $doext . $_G['setting']['extcredits'][$exttype]['title'] . lang("plugin/aljbdx","aljbdx_inc_php_45") . $orderid);
            }
        }
        if($_GET['payment'] == '6'){
            bdx_notice($orderid);
            echo "<script>parent.tips_gwc('&#19979;&#21333;&#25104;&#21151;&#65281;',function(){parent.location.href='plugin.php?id=" . $pluginid . "&act=orderlist';});</script>";
            exit;
        }else{

            //echo "<script>parent.location.href='".rtrim($qbapi->siteurl, '/')."/plugin.php?id=aljgwc&act=cart_pay&orderid=" . $orderid . "';</script>";
            //exit;
            if($totalprice>0){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile'] && $_GET['commodity_type'] == 2) {
                    $oURL = '&orderid='.$orderid.'&pay=yes';
                }
                $keyurlarray = array(
                    'orderid' => $orderid,
                    'time' => TIMESTAMP,
                    'price' => $totalprice,
                    'keyname' => 'aljbdx',
                    'return_url' => rtrim($qbapi->siteurl, '/').'/'.'plugin.php?id='.$pluginid.'&act=orderlist'.$oURL,
                    'key' => $_G['cache']['plugin']['aljbdx']['qb_key'],
                );
                $url = $qbapi -> createUrl($keyurlarray);

                echo "<script>parent.location.href='" . $url . "';</script>";
                exit;
            }else{
                bdx_notice($orderid);
                if($_GET['pay_integral'] && $_GET['pay_ext'] && $_G['cache']['plugin']['aljspt']['is_aljspt'] && $_GET['commodity_type'] == 2){
                    pt_goods_status($orderarray,$goods['id']);
                }
                $order = $orderarray;
                if(($order['commodity_type'] == 0 || $order['commodity_type'] == 7) && $order['get_to_the_shop'] != 1 && $address['lat'] !=0 && $address['lng'] != 0 && (($bdinfo['platform_distribution'] == 1  && $_G['cache']['plugin']['aljpps']['is_aljbd']) || $_G['cache']['plugin']['aljsqtg']['platform_distribution'] == 1) && $_G['cache']['plugin']['aljpps']['aljbd_auto_order']){
                    $_GET['orderid'] = $orderid;
                    require DISCUZ_ROOT .'/source/plugin/aljpps/include/pay.php';
                    C::t('#aljgwc#aljbd_goods_order')->update($orderid, $updatearray);
                    if($status !=2){
                        DB::update('aljbd_goods_order_list',array('status'=>$status), array('orderid'=>$orderid));
                    }
                }
                echo '<script>parent.tips_gwc("'.lang("plugin/aljbdx","aljbdx_inc_php_7").'",function(){parent.location.href="plugin.php?id=' . $pluginid . '&act=orderlist'.$oURL.'";});</script>';
            }
            exit;
        }
    }
}else if($_GET['act'] == 'mobile_goodsview_pay'){//���ﵯ��
    define('IN_MOBILE', 2);
    $_G['mobile'] = 2;
    $shop = C::t('#aljbd#aljbd_goods')->fetch($_GET['gid']);
    if($shop['other']){
        $other = unserialize($shop['other']);
    }//$other[unified_inventory]
    $gattrkey = unserialize($shop['attr_key']);
    if(!$gattrkey){
        $gattrkey = 0;
    }
    $gattrkeyc = count($gattrkey);
    $gattrvalue = unserialize($shop['attr_value']);
    
    if($shop['is_pt_sku']){
        if($_GET['path']){
            $path = explode(',',$_GET['path']);
            foreach ($path as $pk => $pv){
                $path[$pv] = $pv;
            }
            foreach($gattrvalue as $k => $v){
                if($path[$v['symbol']]){
                    $pt_gattrvalue[$v['kid']] = $v;
                }
            }
            if($pt_gattrvalue){
                $gattrvalue = $pt_gattrvalue;
            }
        }
    }

    if($_G['cache']['plugin']['aljtcc']){
        if($_GET['wm'] == 'yes'){
            $card_user = DB::fetch_first('select * from %t where uid=%d and end_time>%d and card_id=2',array('aljtcc_card_user',$_G['uid'],TIMESTAMP));
            $card_info = DB::fetch_first('select * from %t where id=%d ',array('aljtcc_card',2));
        }else{
            $card_user = DB::fetch_first('select * from %t where uid=%d and end_time>%d and card_id=1',array('aljtcc_card_user',$_G['uid'],TIMESTAMP));
            $card_info = DB::fetch_first('select * from %t where id=%d ',array('aljtcc_card',1));
        }
    }
    
    $shop['attr_sku'] = unserialize($shop['attr_sku']);
    //debug($gattrvalue);
    $ii = 1;
    foreach($shop['attr_sku'] as $k => $v){
        
        //ms marketprice
        if($_G['cache']['plugin']['aljms']['is_aljms']){
            $ms_date = dgmdate(TIMESTAMP, "Ymd");
            $ms_info = DB::fetch_first('select * from %t where ms_status = 0 and ms_gid=%d and ms_date=%d and ms_start_time<=%d and ms_end_time>%d and ms_sale_num<ms_num',array('aljhtx_activity_ms_enter',$gid,$ms_date,TIMESTAMP,TIMESTAMP));
            
            if($ms_info['ms_start_time'] < TIMESTAMP && $ms_info['ms_end_time'] > TIMESTAMP && ($v['path'] == $ms_info['ms_sku'] || $ms_info['ms_sku']==0)){
                if($shop['commodity_type'] == 2){
                    $v['marketprice'] = $ms_info['ms_price'];
                }else{
                    $v['saleprice'] = $ms_info['ms_price'];
                }
                if($v['path'] == $ms_info['ms_sku']){
                    $ms_path = $v['path'];
                }
                
            }
        }
        //debug($v['marketprice']);
        if($card_user){
            
            if($settings['is_card_price']['value']==1){
                //��Ա���۸�
                /*if($v['card_price']>0){
                    if($shop['commodity_type'] == 2){
                        $v['marketprice'] = $v['card_price'];
                    }else{
                        $v['saleprice'] = $v['card_price'];
                    }
                }*/
            }else{
                //��Ա���ۿ�
                if($shop['card_price']>0){
                    if($shop['commodity_type'] == 2){
                        $v['card_price'] =  substr(sprintf("%.3f",$v['marketprice']*($shop['card_price']/100)),0,-1);
                        //$v['marketprice'] = substr(sprintf("%.3f",$v['marketprice']*($shop['card_price']/100)),0,-1);
                    }else{
                        $v['card_price'] =  substr(sprintf("%.3f",$v['saleprice']*($shop['card_price']/100)),0,-1);
                    }
                    if($_GET['wm'] == 'yes'){
                        $v['saleprice'] = substr(sprintf("%.3f",$v['saleprice']*($shop['card_price']/100)),0,-1);
                    }
                }
            }
        }else if($_G['cache']['plugin']['aljtcc'] && !$settings['is_card_price']['value']){
            
            //��Ա���ۿ�
            if($shop['card_price']>0){
                if($shop['commodity_type'] == 2){
                    $v['card_price'] =  substr(sprintf("%.3f",$v['marketprice']*($shop['card_price']/100)),0,-1);
                }else{
                    $v['card_price'] =  substr(sprintf("%.3f",$v['saleprice']*($shop['card_price']/100)),0,-1);
                }
            }
        }
        
        if($v['saleprice']>0 && ($v['stock']>0 || ($other[unified_inventory]== 1 && $shop['amount']>0))){
            $gattrsku[] = $v;
        }
        $init_sku[] = $v;
        if($v['def'] == 1){
            $def_sku_id = explode(',',$v['path']);
        }else if($ii == 1 && $v['saleprice']>0 && ($v['stock']>0 || ($other[unified_inventory]== 1 && $shop['amount']>0))){
            $def_sku_id = explode(',',$v['path']);
            $ii++;
        }
    }

    if($ms_path){
        $ms_paths = explode(',',$ms_path);
    }
    
    
    $gattrsku = json_encode($gattrsku);
    $init_sku = json_encode($init_sku);
    if($_GET['btngwc'] == 'yes'){
        $btngwc = 1;
    }
    if($_G['cache']['plugin']['aljbd_bq']['is_aljbd_bq']){
        $g = $shop;
        if($g['product_label']){
            $biaoqian = DB::fetch_all('select * from %t where id IN (%n)',array('aljbd_bq',explode(',',$g['product_label'])));
            $jiaobiao = $zhuanti = $dapeishangpin = $autohtml = array();
            foreach($biaoqian as $bq_k => $bq_v){
                if($bq_v['type'] == 1){
                    $jiaobiao = $bq_v;
                }else if($bq_v['type'] == 2){
                    $zhuanti = $bq_v;
                }else if($bq_v['type'] == 3){
                    $dapeishangpin = $bq_v;
                }else if($bq_v['type'] == 4){
                    $autohtml = $bq_v;
                }
            }
        }
    }
    /*if($_GET['cart'] == 'yes'){
        $formurl = 'plugin.php?id=aljgwc&act=addcart&gid='.$shop['id'].'&pluginid=aljbd';
    }else{
        $formurl = 'plugin.php?id=aljgwc&act=buy&pluginid=aljbd&goods_id='.$shop['id'];
    }*/
    include template($pluginid_aljbdx.':touch/confirm');
}else if($_GET['act'] == 'cart_pay'){
    $orderid = $_GET['orderid']?$_GET['orderid']:'';
    if(!$orderid){
        $navtitle = lang('plugin/aljbd','view_php_10');
        $desc = '&#35746;&#21333;&#19981;&#23384;&#22312;';
        $info = array('desc' => $desc);
        $info['title'] = $navtitle;
        $info['icon'] = 'weui-icon-warn';
        $info['btn_primary'] = array('value' => lang('plugin/aljbd','tips_pay_error'), 'url' => 'plugin.php?id='.$pluginid.'&act=orderlist');
        $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljbd');
        include template('aljbd:new/common/tips');
        exit;
    }
    
    $order=C::t('#aljbdx#aljbd_goods_order')->fetch($orderid);
    
    if(!$order){
        $navtitle = lang('plugin/aljbd','view_php_10');
        $desc = '&#35746;&#21333;&#24322;&#24120;&#36820;&#22238;&#35746;&#21333;&#21015;&#34920;';
        $info = array('desc' => $desc);
        $info['title'] = $navtitle;
        $info['icon'] = 'weui-icon-warn';
        $info['btn_primary'] = array('value' => lang('plugin/aljbd','tips_pay_error'), 'url' => 'plugin.php?id='.$pluginid.'&act=orderlist');
        $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljbd');
        include template('aljbd:new/common/tips');
        exit;
    }
    if($order['status'] == 7){
        $navtitle = lang('plugin/aljbd','view_php_10');
        $desc = '&#35746;&#21333;&#24050;&#21462;&#28040;';
        $info = array('desc' => $desc);
        $info['title'] = $navtitle;
        $info['icon'] = 'weui-icon-warn';
        $info['btn_primary'] = array('value' => lang('plugin/aljbd','tips_pay_error'), 'url' => 'plugin.php?id='.$pluginid.'&act=orderlist');
        $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljbd');
        include template('aljbd:new/common/tips');
        exit;
    }
    
    $shop_order_info = DB::fetch_first('select * from %t where shop_id=%d order by dateline desc limit 1',array('aljbd_goods_order_list',$order['shop_id']));
    if($order[original_price] <=0 && $shop_order_info['uid']!=$order['uid']){
        $shop_order=C::t('#aljbdx#aljbd_goods_order_list')->fetch_all_by_orderid($orderid);
        foreach($shop_order as $sk => $value){
            
            $good_1 = C::t('#'.$pluginid.'#'.$pluginid.'_goods')->fetch($value['goods_id']);
            
            
            //ms
            if($_G['cache']['plugin']['aljms']['is_aljms']){
                $ms_date = dgmdate(TIMESTAMP, "Ymd");
                
                $ms_info = DB::fetch_first('select * from %t where ms_status = 0 and ms_gid=%d and ms_date=%d and ms_start_time<=%d and ms_end_time>%d and ms_sale_num<ms_num',array('aljhtx_activity_ms_enter',$value['goods_id'],$ms_date,TIMESTAMP,TIMESTAMP));
                
                if($ms_info){
                    $ms_gwc_num = DB::result_first('select sum(num) from %t where goods_id=%d and uid=%d',array('aljgwc',$value['goods_id'],$_G['uid']));
                    if($ms_info['ms_start_time'] < TIMESTAMP && $ms_info['ms_end_time'] > TIMESTAMP && ($value['path'] == $ms_info['ms_sku'] || $ms_info['ms_sku']==0)){
                        $ms_status = 1;
                        if($ms_info['ms_limit_num']>0){
                            $order_limit_amount = DB::result_first('select sum(a.num) from %t a left join %t b on a.orderid=b.orderid where a.goods_id=%d and b.status<6 and b.uid=%d and a.order_type=1',array('aljbd_goods_order_list','aljbd_goods_order',$good_1['id'],$_G['uid']));

                            if(intval($order_limit_amount) + $ms_gwc_num > $ms_info['ms_limit_num']){
                                
                                $navtitle = lang('plugin/aljbd','view_php_10');
                                $desc = $good_1['name'].lang("plugin/aljbdx","aljbdx_inc_php_40").$ms_info['ms_limit_num'].lang("plugin/aljbdx","aljbdx_inc_php_41");
                                $info = array('desc' => $desc);
                                $info['title'] = $navtitle;
                                $info['icon'] = 'weui-icon-warn';
                                $info['btn_primary'] = array('value' => lang('plugin/aljbd','tips_pay_error'), 'url' => 'plugin.php?id=aljbd&act=view&bid='.$good_1['bid']);
                                $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljbd');
                                include template('aljbd:new/common/tips');
                                exit;
                            }
                        }
                        if ($ms_info['ms_num'] < $ms_gwc_num+$ms_info['ms_sale_num']) {
                            $navtitle = lang('plugin/aljbd','view_php_10');
                            $desc = $good_1['name'].lang('plugin/aljbdx','aljbdx_inc_php_61');
                            $info = array('desc' => $desc);
                            $info['title'] = $navtitle;
                            $info['icon'] = 'weui-icon-warn';
                            $info['btn_primary'] = array('value' => lang('plugin/aljbd','tips_pay_error'), 'url' => 'plugin.php?id=aljbd&act=view&bid='.$good_1['bid']);
                            $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljbd');
                            include template('aljbd:new/common/tips');
                            exit;
                        }
                    }
                }
            }


            if($good_1['limit_amount']>0){
                
                if($good_1['limit_type'] == 1){
                    $order_limit_amount = DB::result_first('select sum(a.num) from %t a left join %t b on a.orderid=b.orderid where a.goods_id=%d and b.status<6 and b.uid=%d and b.submitdate>=%d',array('aljbd_goods_order_list','aljbd_goods_order',$good_1['id'],$_G['uid'],$nowDayTime));
                }else{
                    $order_limit_amount = DB::result_first('select sum(a.num) from %t a left join %t b on a.orderid=b.orderid where a.goods_id=%d and b.status<6 and b.uid=%d',array('aljbd_goods_order_list','aljbd_goods_order',$good_1['id'],$_G['uid']));
                }
                
                if(intval($order_limit_amount) > $good_1['limit_amount']){
                    
                    $navtitle = lang('plugin/aljbd','view_php_10');
                    $desc = $good_1['name'].lang("plugin/aljbdx","aljbdx_inc_php_28").$good_1['limit_amount'].lang("plugin/aljbdx","aljbdx_inc_php_29");
                    $info = array('desc' => $desc);
                    $info['title'] = $navtitle;
                    $info['icon'] = 'weui-icon-warn';
                    $info['btn_primary'] = array('value' => lang('plugin/aljbd','tips_pay_error'), 'url' => 'plugin.php?id=aljbd&act=view&bid='.$good_1['bid']);
                    $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljbd');
                    include template('aljbd:new/common/tips');
                    exit;
                }
            }
            $gattrsku = skups($good_1['attr_sku'],$value['path']);//��ϼ۸���
            $other = unserialize($good_1['other']);
            if($other[unified_inventory] == 1){
                    if ($good_1['amount'] < $value['num']) {
                        
                        $navtitle = lang('plugin/aljbd','view_php_10');
                        $desc = $good_1['name'] . $value['content']."&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;";
                        $info = array('desc' => $desc);
                        $info['title'] = $navtitle;
                        $info['icon'] = 'weui-icon-warn';
                        $info['btn_primary'] = array('value' => lang('plugin/aljbd','tips_pay_error'), 'url' => 'plugin.php?id=aljbd&act=view&bid='.$good_1['bid']);
                        $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljbd');
                        include template('aljbd:new/common/tips');
                        exit;
                    }
            }else{
                if ($good_1['attr_sku'] && $gattrsku['stock'] < $value['num']) {//��Ͽ��
                    
                    $navtitle = lang('plugin/aljbd','view_php_10');
                    $desc = $good_1['name'] . $value['content']."&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;";
                    $info = array('desc' => $desc);
                    $info['title'] = $navtitle;
                    $info['icon'] = 'weui-icon-warn';
                    $info['btn_primary'] = array('value' => lang('plugin/aljbd','tips_pay_error'), 'url' => 'plugin.php?id=aljbd&act=view&bid='.$good_1['bid']);
                    $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljbd');
                    include template('aljbd:new/common/tips');
                    exit;
                }else{
                    if ($good_1['amount'] < $value['num']) {
                        $navtitle = lang('plugin/aljbd','view_php_10');
                        $desc = $good_1['name'] . $value['content']."&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;";
                        $info = array('desc' => $desc);
                        $info['title'] = $navtitle;
                        $info['icon'] = 'weui-icon-warn';
                        $info['btn_primary'] = array('value' => lang('plugin/aljbd','tips_pay_error'), 'url' => 'plugin.php?id=aljbd&act=view&bid='.$good_1['bid']);
                        $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljbd');
                        include template('aljbd:new/common/tips');
                        exit;
                    }
                }
            }
            if($good_1['new_price']>0){
                //�Ƿ�δ�¹���������
                $new_order_num = DB::result_first('select count(*) from %t where uid=%d and status>1 and status<7 and pid=0',array('aljbd_goods_order',$_G['uid']));
                
                if($new_order_num>0){
                    if(($value['price'] == $gattrsku['newprice'] && $good_1['attr_sku'] && $gattrsku['newprice']>0) || $value['price'] == $good_1['new_price']) {
                        $navtitle = lang('plugin/aljbd','view_php_10');
                        $desc = $good_1['name'].lang('plugin/aljbd','tips_pay_error_newprice');
                        $info = array('desc' => $desc);
                        $info['title'] = $navtitle;
                        $info['icon'] = 'weui-icon-warn';
                        $info['btn_primary'] = array('value' => lang('plugin/aljbd','tips_pay_error'), 'url' => 'plugin.php?id=aljbd&act=view&bid='.$good_1['bid']);
                        $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljbd');
                        include template('aljbd:new/common/tips');
                        exit;
                    }
                }
            }
            if (TIMESTAMP > $good_1['endtime']  && !empty($good_1['endtime'])) {
                
                $navtitle = lang('plugin/aljbd','view_php_10');
                $desc = $good_1['name']."&#19981;&#22312;&#27963;&#21160;&#26102;&#38388;&#20869;";
                $info = array('desc' => $desc);
                $info['title'] = $navtitle;
                $info['icon'] = 'weui-icon-warn';
                $info['btn_primary'] = array('value' => lang('plugin/aljbd','tips_pay_error'), 'url' => 'plugin.php?id=aljbd&act=view&bid='.$good_1['bid']);
                $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljbd');
                include template('aljbd:new/common/tips');
                exit;
            }
            if ($good_1['state']) {
                $navtitle = lang('plugin/aljbd','view_php_10');
                $desc = $good_1['name']."&#21830;&#21697;&#24050;&#19979;&#26550;";
                $info = array('desc' => $desc);
                $info['title'] = $navtitle;
                $info['icon'] = 'weui-icon-warn';
                $info['btn_primary'] = array('value' => lang('plugin/aljbd','tips_pay_error'), 'url' => 'plugin.php?id=aljbd&act=view&bid='.$good_1['bid']);
                $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljbd');
                include template('aljbd:new/common/tips');
                exit;
            }

        }
    }
    
    $orderpaytime = $order['submitdate']+$overtime;
    
    $time = $orderpaytime - TIMESTAMP;

    if($time<=0) {
        $time = 0;
        $navtitle = lang('plugin/aljbd','view_php_10');
        $desc = '&#35746;&#21333;&#24050;&#36229;&#26102;';
        $info = array('desc' => $desc);
        $info['title'] = $navtitle;
        $info['icon'] = 'weui-icon-warn';
        $info['btn_primary'] = array('value' => lang('plugin/aljbd','tips_pay_error'), 'url' => 'plugin.php?id='.$pluginid.'&act=orderlist');
        $info['btn_default'] = array('value' => lang('plugin/aljbd','view_php_17'), 'url' => 'plugin.php?id=aljbd');
        include template('aljbd:new/common/tips');
        exit;
    }
    $m = $time/60%60;
    
    $m= str_pad($m,2,0,STR_PAD_LEFT);
    $s = $time%60;
    $s = str_pad($s,2,0,STR_PAD_LEFT);

    
    $keyurlarray = array(
        'orderid' => $order['orderid'],
        'time' => $time >0 ? $orderpaytime-900 : TIMESTAMP,
        'price' => $order['price'],
        'keyname' => 'aljbdx',
        'return_url' => rtrim($qbapi->siteurl, '/').'/'.'plugin.php?id='.$pluginid.'&act=orderlist',
        'key' => $_G['cache']['plugin']['aljbdx']['qb_key'],
    );
    
    $url = $qbapi -> createUrl($keyurlarray);
    header('location: '.$url);
    exit;
    $navtitle ="&#30830;&#35748;&#20184;&#27454;";
    
    include template($pluginid_aljbdx.':cart_pay');
}else if($_GET['act'] == 'pay'){
    $bid = $_GET['bid']?$_GET['bid']:'';
    $vipid = $_GET['vipid'];
    if(!$bid){
        showmessage('&#24215;&#38138;&#19981;&#23384;&#22312;');
    }

    $brand=C::t('#aljbd#aljbd')->fetch($bid);

    if(!$brand){
        showmessage('&#24215;&#38138;&#19981;&#23384;&#22312;','plugin.php?id=aljht&act=admin&op=brand');
    }
    if($_G['mobile']){
        $return_url =  rtrim($qbapi->siteurl, '/').'/'.'plugin.php?id=aljbd&act=member';
    }else{
        $return_url = rtrim($qbapi->siteurl, '/').'/'.'plugin.php?id=aljht&act=admin&op=brand';
    }
    if($_GET['vipid'] == 'jhm'){
        $_GET['card_number'] = $_GET['activation_code'];
        $card = DB::fetch_first('select * from %t where card_number=%s and card_service_id = 1 and  used = 0 and dateline+card_day_num*86400>%d', array('aljac_card', $_GET['card_number'], TIMESTAMP)); //�ж��û�����ļ������Ƿ���Ч
        
        if(!$card){
            echo "<script>alert('".lang('plugin/aljbdx','aljbdx_inc_php_62')."');window.history.go(-1);</script>";
            exit;
        }
        
        $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$card['card_vip_id']));
        
        if(!$vipdata){
            echo "<script>alert('".lang('plugin/aljbdx','aljbdx_inc_php_62')."');window.history.go(-1);</script>";
            exit;
        }
        if($brand['vipid'] == $vipdata['id'] && $vipdata['day'] == 0){
            echo "<script>alert('".lang('plugin/aljbdx','aljbdx_inc_php_63')."');window.history.go(-1);</script>";
            exit;
        }
        if(DB::query('update %t set used = 1, used_time=%d,uid=%d,username=%s where id = %d', array('aljac_card', TIMESTAMP, $_G['uid'], $_G['username'], $card['id']))){//����������Ϊ��ʹ�ò�����ʹ��ʱ��
            DB::query('update %t set unused_card_num = unused_card_num-1,  used_card_num = used_card_num+1 where id=%d', array('aljac_card_type', $card['card_type']));  //��������ʹ��+1 δʹ��-1
            
            $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
            $orderarray=array(
                'orderid' => $orderid,
                'status' => 2,
                'store_id' => $bid,
                'uid' => $_G['uid'],
                'username' => $_G['username'],
                'price' => $vipdata['price'],
                'submitdate' => $_G['timestamp'],
                'remarks' => $vipdata['day'].'/'.$vipdata['price'].'_'.$_GET['activation_code'],
                'stitle' => $card['id'].'_'.lang('plugin/aljbdx','aljbdx_inc_php_64').'-'.$brand['name'],
                'payment' => 7,
                'pid'  => 3,//�̼�
                'browser'  => $_SERVER['HTTP_USER_AGENT'],
            );
            $orderarray['fare_desc'] = $vipdata['id'];
            if($_G['mobile']){//1���ֻ���2��PC
                $orderarray['mobile'] = 1;
            }else{
                $orderarray['mobile'] = 2;
            }
           
        }else{
            echo "<script>alert('".lang('plugin/aljbdx','aljbdx_inc_php_62')."');window.history.go(-1);</script>";
            exit;
        }
        if(in_array($_G['groupid'],unserialize($_G['cache']['plugin']['aljbd']['mgroups']))){
            $status=1;
        }
        $updatearray = array('status'=>$status);
        $vipendtime = ($brand['vipid'] == $vipdata['id']) ? max($brand['vipendtime'], TIMESTAMP) : TIMESTAMP;
        if ($vipdata['day'] == 0) {
            $updatearray['vipendtime'] = 0;
        } else {
            $updatearray['vipendtime'] = $vipendtime + ($vipdata['day'] * 86400);
        }
        $updatearray['vipid'] = ($vipdata['id'] == $brand['vipid']) ? $brand['vipid'] : $vipdata['id'];
        C::t('#aljbdx#aljbd_goods_order')->insert($orderarray);
        DB::update('aljbd',$updatearray,array('id'=>$brand['id']));
        echo "<script>alert('".lang('plugin/aljbd','s11')."');window.history.go(-1);</script>";
        exit;
    }else{
        $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
        $orderarray=array(
            'orderid' => $orderid,
            'status' => 1,
            'shop_id' => $bid,
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'submitdate' => $_G['timestamp'],
            'stitle' => lang("plugin/aljbdx","aljbdx_inc_php_46").' - '.$brand['name'],
            'payment' => 7,
            'pid'  => 3,
            'browser'  => $_SERVER['HTTP_USER_AGENT'],
        );
        if ($_G['mobile']) {//1���ֻ���2��PC
            $orderarray['mobile'] = 1;
        } else {
            $orderarray['mobile'] = 2;
        }
        $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$vipid));
        if($brand['vipid'] == $vipdata['id'] && $vipdata['day'] == 0){
            echo "<script>alert('".lang('plugin/aljbdx','aljbdx_inc_php_63')."');window.history.go(-1);</script>";
            exit;
        }
        //�̼�VIP
        if($vipdata && $_G['cache']['plugin']['aljbdx']['is_aljqb']) {
            $orderarray['remarks'] = $vipdata['day'] . '/' . $vipdata['price'];
            $orderarray['fare_desc'] = $vipid;
            $orderarray['price'] = $vipdata['price'];

            if ($_GET['couponid'] && $_G['cache']['plugin']['aljsyh']['is_aljsyh']) {
                $clogdata = DB::fetch_first('select * from %t a left join %t b on a.cid=b.id where a.status=1 and a.uid=%d and a.id=%d', array('aljsyh_consume_log', 'aljbd_consume', $_G['uid'], intval($_GET['couponid'])));

                if ($clogdata) {
                    $vipdata['price'] = $vipdata['price'] - $clogdata['reduction'];
                }
                if (DB::update('aljsyh_consume_log', array('status' => 2,'use_time'=>TIMESTAMP), array('id' => intval($_GET['couponid']), 'status' => 1))) {
                    $orderarray['cid'] = intval($_GET['couponid']);
                    $orderarray['discount'] = $clogdata['reduction'];
                }
            }
            $vipendtime = ($vipid == $brand['vipid']) ? max($brand['vipendtime'], TIMESTAMP) : TIMESTAMP;
            if ($vipdata['price'] > 0) {
                $orderarray['opentime'] = $vipendtime;//���ѿ�ʼʱ��
                C::t('#aljbdx#aljbd_goods_order')->insert($orderarray);
                require_once 'source/plugin/aljqb/class/Qbapi.class.php';
                $qbapi = new Qbapi();
                $keyurlarray = array(
                    'orderid' => $orderid,
                    'time' => TIMESTAMP,
                    'price' => $vipdata['price'],
                    'keyname' => 'aljbdx_rz',
                    'return_url' => $return_url,
                    'key' => $_G['cache']['plugin']['aljbdx']['qb_key'],
                );
                $url = $qbapi->createUrl($keyurlarray);
                echo "<script>location.href='" . $url . "';</script>";
                exit;
            } else {
                if(in_array($_G['groupid'],unserialize($_G['cache']['plugin']['aljbd']['mgroups']))){
                    $status=1;
                }
                $updatearray = array('status'=>$status);
                if ($vipdata['day'] == 0) {
                    $updatearray['vipendtime'] = 0;
                } else {
                    $updatearray['vipendtime'] = $vipendtime + ($vipdata['day'] * 86400);
                }
                $updatearray['vipid'] = ($vipid == $brand['vipid']) ? $brand['vipid'] : $vipid;
                C::t('#aljbdx#aljbd_goods_order')->insert($orderarray);
                DB::update('aljbd',$updatearray,array('id'=>$brand['id']));
                echo "<script>alert('".lang('plugin/aljbd','s11')."');window.history.go(-1);</script>";
                exit;
            }
        
        }else{
            $orderarray['price'] = $_G['cache']['plugin']['aljbdx']['adddp_price'];
            C::t('#aljbdx#aljbd_goods_order')->insert($orderarray);
        }
        //DB::update('aljbd',array('orderid'=>$orderid),array('id'=>$bid));

        $keyurlarray = array(
            'orderid' => $orderid,
            'time' => TIMESTAMP,
            'price' => $orderarray['price'],
            'keyname' => 'aljbdx_rz',
            'return_url' => $return_url,
            'key' => $_G['cache']['plugin']['aljbdx']['qb_key'],
        );
        $url = $qbapi -> createUrl($keyurlarray);
        echo "<script>location.href='" . $url . "';</script>";
        exit;
    }
}else if($_GET['act']=='receipt'){
    $order = C::t('#aljbdx#aljbd_goods_order') -> fetch($_GET['orderid']);
    if($order['uid'] == $_G['uid']){
        DB::query("update %t set status=4 where orderid = %s",array('aljbd_goods_order',$_GET['orderid']));
        if(file_exists("source/plugin/dz_1/dz_1.inc.php")){
            require_once 'source/plugin/dz_1/include/receipt.php';
        }
    }
    showmessage('&#30830;&#35748;&#25910;&#36135;&#25104;&#21151;',$orderlisturl.'&ord='.$_GET['ord']);
}else if($_GET['act']=='ajaxaddresslist'){
    require_once $common_path.'class/class_aljhtx.php';
    if($addrlist){
        foreach ($addrlist as $key => $value){
            if($value['address']){
                $addrlist[$key]['addresstext'] = $value['address'].$value['addressDetail'];
            }else if($regionlist[$value['region']][name]){
                $addrlist[$key]['addresstext'] = $regionlist[$value['region']][name].$regionlist[$value['region1']][name].$regionlist[$value['region2']][name].$value['addressDetail'];
            }else{
                $addrlist[$key]['addresstext'] = $value['province'].$value['city'].$value['district'].$value['addressDetail'];
            }
        }
        echo json_encode(aljhtx::ajaxPostCharSet($addrlist));
    }else{
        echo '0';
    }
    exit;
}else if($_GET['act']=='ajaxaddaddress'){

    if(empty($_GET['citypicker'])){
        echo json_encode(aljhtx::ajaxPostCharSet(array('code'=>'400','data'=>lang("plugin/aljbdx","aljbdx_inc_php_47"))));
        exit;
    }
    if(empty($_GET['addressDetail'])){
        echo json_encode(aljhtx::ajaxPostCharSet(array('code'=>'400','data'=>lang("plugin/aljbdx","aljbdx_inc_php_48"))));
        exit;
    }
    if(empty($_GET['fullName'])){
        echo json_encode(aljhtx::ajaxPostCharSet(array('code'=>'400','data'=>lang("plugin/aljbdx","aljbdx_inc_php_49"))));
        exit;
    }
    if(empty($_GET['mobile_p'])){
        echo json_encode(aljhtx::ajaxPostCharSet(array('code'=>'400','data'=>lang("plugin/aljbdx","aljbdx_inc_php_50"))));
        exit;
    }

    if(!preg_match($regular, $_GET['mobile_p'])){
        echo json_encode(aljhtx::ajaxPostCharSet(array('code'=>'400','data'=>lang("plugin/aljbdx","aljbdx_inc_php_51"))));
        exit;
    }
    $citypicker = array_filter(explode(' ', trim($_GET['citypicker'])));
    
    $insertarray = array(
        'province' => $citypicker[0],
        'city' => $citypicker[1],
        'district' => $citypicker[2],
        'addressDetail' => $_GET['addressDetail'],
        'post' => $_GET['post'],
        'fullName' => $_GET['fullName'],
        'mobile' => $_GET['mobile_p'],
        'phoneSection' => $_GET['phoneSection'],
        'phoneCode' => $_GET['phoneCode'],
        'phoneExt' => $_GET['phoneExt'],
        'defaultAddress' => $_GET['defaultAddress'],
        'dateline' => TIMESTAMP,
        'uid' => $_G['uid'],
        'username' => $_G['username'],
    );
    if($_G['cache']['plugin']['aljpps']['is_aljbd']){
        $insertarray['address'] = $_GET['citypicker'];
        $insertarray['province'] = $_GET['province'];
        $insertarray['city'] = $_GET['city'];
        $insertarray['district'] = $_GET['district'];
        if($_GET['form'] == 'aljsqtg'){
            
            $peisong = DB::fetch_all("select * from %t where status=1 and lbs_name like %s",array('aljsqtg_distribution_area','%'.stripsearchkey($_GET['district']).'%'));
            if(!$peisong){
                $peisong = DB::fetch_all("select * from %t where status=1 and lbs_name like %s",array('aljsqtg_distribution_area','%'.stripsearchkey($_GET['city']).'%'));
            }
            
            if(!$peisong){
                echo json_encode(aljhtx::ajaxPostCharSet(array('code'=>'400','data'=>$_G['cache']['plugin']['aljsqtg']['out_of_range_tips'])));
                exit;
            }
            $did = array();
            foreach($peisong as $ps_k => $ps_v){
                $did[] = $ps_v['id'];
            }
            $peisong_area = DB::fetch_all('select * from %t where did in (%n)',array('aljsqtg_distribution_area_coordinate',$did));
            
            if(!$peisong_area){
                echo json_encode(aljhtx::ajaxPostCharSet(array('code'=>'400','data'=>$_G['cache']['plugin']['aljsqtg']['out_of_range_tips'])));
                exit;
            }
            $point = array(
                'lng'=>$_GET['lng'],
                'lat'=>$_GET['lat']
            );
            $peisong_id = 0;
            foreach($peisong_area as $q_k => $q_v){
                $paths = unserialize($q_v['coordinate']);
                
                foreach($paths as $p_k => $p_v){
                    $lat_lng = explode(',',$p_v);
                    $paths[$p_k] = array('lat'=>$lat_lng[0],'lng'=>$lat_lng[1]);
                }
                if(is_point_in_polygon($point, $paths)){
                    $peisong_id = $q_v['did'];
                    break;
                }
            }
            if($peisong_id<=0){
                echo json_encode(aljhtx::ajaxPostCharSet(array('code'=>'400','data'=>$_G['cache']['plugin']['aljsqtg']['out_of_range_tips'])));
                exit;
            }
        }
        $insertarray['lat'] = $_GET['lat'];
        $insertarray['lng'] = $_GET['lng'];
        $insertarray['type'] = 1;
    }
    if($_GET['defaultAddress']){
        C::t('#aljbdx#aljbd_address')->update_by_uid_defaultAddress($_G['uid'],$insertarray['type']);
    }
    if($address){
        if($address['uid'] != $_G['uid']){
            echo json_encode(aljhtx::ajaxPostCharSet(array('code'=>'400','data'=>lang("plugin/aljbdx","aljbdx_inc_php_52"))));
            exit;
        }
        C::t('#aljbdx#aljbd_address')->update($address_id,$insertarray);
    }else{
        if($address_num >20){
            echo json_encode(aljhtx::ajaxPostCharSet(array('code'=>'400','data'=>lang("plugin/aljbdx","aljbdx_inc_php_53"))));
            exit;
        }
        $address_id = C::t('#aljbdx#aljbd_address')->insert($insertarray,true);
    }

    if($address_id){
        $dataarray = array('code'=>100,'data_id'=>$address_id,'data_fullname'=>$_GET['fullName'],'data_mobile'=>$_GET['mobile_p'],'data_address'=>$_GET['citypicker'].$_GET['addressDetail']);
        echo json_encode(aljhtx::ajaxPostCharSet($dataarray));
    }else{
        echo '0';
    }
    exit;
}else if($_GET['act'] == 'editaddress'){
    $num_goods = intval($_GET['num']);
    if(submitcheck('formhash')) {
        if(empty($_GET['citypicker']) && empty($_GET['region'])){

                echo '<script>parent.tips("'.lang("plugin/aljbdx","aljbdx_inc_php_8").'","");</script>';
                exit;

        }
        if(empty($_GET['addressDetail'])){

                echo '<script>parent.tips("'.lang("plugin/aljbdx","aljbdx_inc_php_9").'","");</script>';
                exit;

        }
        if(empty($_GET['fullName'])){

                echo '<script>parent.tips("'.lang("plugin/aljbdx","aljbdx_inc_php_10").'","");</script>';
                exit;

        }
        if(empty($_GET['mobile_p'])){

                echo '<script>parent.tips("'.lang("plugin/aljbdx","aljbdx_inc_php_11").'","");</script>';
                exit;

        }

        if(!preg_match($regular, $_GET['mobile_p']) && $_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo '<script>parent.tips("'.lang("plugin/aljbdx","aljbdx_inc_php_12").'","");</script>';
            exit;
        }
        if(strpos($_GET['citypicker'],'/')!==false){
            $citypicker = array_filter(explode('/', trim($_GET['citypicker'])));
        }else{
            $citypicker = array_filter(explode(' ', trim($_GET['citypicker'])));
        }
        $insertarray = array(
            'province' => $citypicker[0],
            'city' => $citypicker[1],
            'district' => $citypicker[2],
            'region' => $_GET['region'],
            'region1' => $_GET['subregion'],
            'region2' => $_GET['region1'],
            'addressDetail' => $_GET['addressDetail'],
            'post' => $_GET['post'],
            'fullName' => $_GET['fullName'],
            'mobile' => $_GET['mobile_p'],
            'phoneSection' => $_GET['phoneSection'],
            'phoneCode' => $_GET['phoneCode'],
            'phoneExt' => $_GET['phoneExt'],
            'defaultAddress' => $_GET['defaultAddress'],
            'dateline' => TIMESTAMP,
            'uid' => $_G['uid'],
            'username' => $_G['username'],
        );
        if($_G['cache']['plugin']['aljpps']['is_aljbd']){
            $insertarray['address'] = $_GET['citypicker'];
            $insertarray['province'] = $_GET['province'];
            $insertarray['city'] = $_GET['city'];
            $insertarray['district'] = $_GET['district'];
            $insertarray['lat'] = $_GET['lat'];
            $insertarray['lng'] = $_GET['lng'];
            $insertarray['type'] = 1;
        }
        
        if($_GET['defaultAddress']){
            C::t('#aljbdx#aljbd_address')->update_by_uid_defaultAddress($_G['uid']);
        }
        if($address){
            if($address['uid'] != $_G['uid']){

                    echo '<script>parent.tips("'.lang("plugin/aljbdx","aljbdx_inc_php_13").'","");</script>';
                    exit;

            }
            C::t('#aljbdx#aljbd_address')->update($address_id,$insertarray);
        }else{
            if($address_num >20){

                    echo '<script>parent.tips("'.lang("plugin/aljbdx","aljbdx_inc_php_14").'","");</script>';
                    exit;

            }
            $address_id = C::t('#aljbdx#aljbd_address')->insert($insertarray,true);
        }
        if(empty($s_id) && empty($goods_id)){
            $heaurl = 'plugin.php?id=aljbdx&act=addresslist'.$biaoshi;
        }else{
            $attrs = $_GET['attrs'];
            $attrsid = $_GET['attrsid'];

            $tiaojianurl = '&commodity_type='.intval($_GET['commodity_type']).'&grouporderid='.$_GET['grouporderid'];
            if($s_id){
                $heaurl = 'plugin.php?id=aljbdx&act=cart&pluginid='.$pluginid.'&shop_id='.$s_id.'&address_id='.$address_id;
            }else{
                $heaurl = 'plugin.php?id=aljbdx&act=cart&pluginid='.$pluginid.'&act=buy&goods_id='.$goods_id.'&address_id='.$address_id.'&num='.$num_goods.'&attrs='.$attrs.'&attrsid='.$attrsid.$tiaojianurl;
            }
        }

            echo "<script>parent.location.href='" . $heaurl . "'</script>";
            exit;

    }else{
        if($address){
            $navtitle = lang("plugin/aljbdx","aljbdx_inc_php_54");
        }else{
            $navtitle = lang("plugin/aljbdx","aljbdx_inc_php_55");
        }
        if($_G['cache']['plugin']['aljbdx']['is_address']){
            $json_regionlist = C::t('#aljbdx#aljgwc_region')->fetch_all_json();
            $cityjson = json_encode($json_regionlist);
            if($address['province']){
                $default=$address['province'].' '.$address['city'].' '.$address['district'];
            }else{
                $default = diconv($json_regionlist[0]['name'].' '. $json_regionlist[0]['sub'][0]['name'].' '.$json_regionlist[0]['sub'][0]['sub'][0]['name'], 'utf-8', CHARSET);
            }
        }else if($address['province']){
            $default=$address['province'].' '.$address['city'].' '.$address['district'];
        }
        $rlist = C::t('#aljbdx#aljgwc_region')->fetch_all_by_upid();
        include template($pluginid_aljbdx.':address/editaddress');
    }
}else if($_GET['act'] == 'addresslist'){
    if(!$_G['mobile']){
        dheader("location: plugin.php?id=aljht&act=user&op=addresslist");
        exit;
    }
    $addrlist = C::t('#aljbdx#aljbd_address')->fetch_all_by_uid($_G['uid']);
    $navtitle = lang("plugin/aljbdx","aljbdx_inc_php_56");
    include template($pluginid_aljbdx.':address/addresslist');
} else if ($_GET['act'] == 'comment') {
    $gid = intval($_GET['gid']);
    if(empty($_G['uid'])){
        $login_callback = 'member.php?mod=logging&action=login&referer=plugin.php?id=aljbdx%26act='.$_GET['act'].'%26orderid='.$_GET['orderid'].'%26gid='.$gid.'%26form='.$_GET['form'];
        dheader("location:".$login_callback);
        exit;
    }
    if($_GET['formhash'] == FORMHASH) {
        if(empty($gid)){
            echo 0;
            exit;
        }
        $good = C::t('#aljbd#aljbd_goods')->fetch($_GET['gid']);
        //debug($_GET['content']);
        //$content = diconv($_GET['content'], 'UTF-8', CHARSET);
        $content = $_GET['content'];
        $orderid = $_GET['orderid'];
        //��
        $overall_ticket = intval($_GET['overall_ticket']);
        //*1
        $descriptiongrade = intval($_GET['descriptiongrade']);
        $environmentgrade = intval($_GET['environmentgrade']);
        $attitudegrade = intval($_GET['attitudegrade']);
        //*2
        $deliveryspeed = intval($_GET['deliveryspeed']);

        if(empty($orderid) || empty($content) || empty($overall_ticket) || empty($descriptiongrade) ||  empty($deliveryspeed)){
            echo 0;
            exit;
        }
        $check = DB::result_first('select count(*) from %t where orderid=%s and uid=%d',array('aljbd_goods_order',$orderid,$_G['uid']));

        if(empty($check) && $_G['groupid'] !=1 ){
            echo 0;
            exit;
        }
        $check = DB::result_first('select count(*) from %t where gid=%d and orderid=%s',array('aljbd_comment_goods',$gid,$orderid));
        if($check){
            echo 0;
            exit;
        }
        $insertarray = array(
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'gid' => $gid,
            'bid' => $good['bid'],
            'orderid' => $orderid,
            'content' => $content,
            'overall_ticket' => $overall_ticket,
            'descriptiongrade' => $descriptiongrade,
            'environmentgrade' => $environmentgrade,
            'attitudegrade' => $attitudegrade,
            'deliveryspeed' => $deliveryspeed,
            'displayorder' => 1,
            'dateline' => TIMESTAMP,
        );

        if($_GET['pic'] && $u20181224) {
            $src = array();
            foreach($_GET['pic'] as $tmp_key=> $tmp_value) {
                if(strpos($tmp_value,$_G['cache']['plugin']['aljoss']['domain']) !== false){
                    $src[] = $tmp_value;
                }else if (is_file($tmp_value)) {
                    $src[] = $tmp_value;
                } else {

                    $src[] = T::saveimg($tmp_value,$image_path.'logo/');
                }
            }
            $srcs = implode('|', $src);
            $insertarray['imgs'] = $srcs;
        }

        C::t('#aljbdx#aljbd_comment_goods')->insert($insertarray);
        DB::query('update %t set status = 5 where orderid = %s',array('aljbd_goods_order',$orderid));
        DB::query('update %t set status = 5 where orderid = %s',array('aljbd_goods_order_list',$orderid));
        echo 1;
    }else{
        if(empty($gid)){
            showmessage("aljbdx:aljbdx_inc_php_1");
        }
        $good = C::t('#aljbd#aljbd_goods') -> fetch($gid);
        $navtitle = lang("plugin/aljbdx","aljbdx_inc_php_57");
        if($_GET['form'] == 'aljsqtg'){
            $to_url = 'plugin.php?id=aljsqtg&a=orderList';
        }else{
            $to_url = 'plugin.php?id=aljbd&act=orderlist';
        }
        if($_G['cache']['plugin']['aljhtx'] && $u20181224){
            include template('aljbdx:goods/comment');
        }else{
            include template('aljbdx:goods/comment_1');
        }

    }
}else if($_GET['act']=='greply'){
    if(submitcheck('formhash')){

        if(empty($_GET['commentmessage_1'])){
            if($_G['mobile']){
                if($_GET['do'] == 'ajax'){
                    echo json_encode(aljhtx::ajaxPostCharSet(array('code'=>400,'text'=>lang('plugin/aljbd','s35'))));
                    exit;
                }else{
                    echo "<script>parent.tips('".lang('plugin/aljbd','s35')."','');</script>";
                    exit;
                }
            }else{
                echo "<script>parent.showDialog('".lang('plugin/aljbd','s35')."','right','','');</script>";
                exit;
            }
        }
        if(empty($_G['uid'])){
            if($_GET['do'] == 'ajax'){
                echo json_encode(aljhtx::ajaxPostCharSet(array('code'=>400,'text'=>lang('plugin/aljbd','s21'))));
                exit;
            }else {
                echo "<script>parent.showDialog('" . lang('plugin/aljbd', 's21') . "','right','','');</script>";
                exit;
            }
        }
        $ucom = C::t('#aljgwc#aljbd_comment_goods')->fetch($_GET['upid']);
        if($_GET['uuid'] && $_GET['uusername']){
            $ucom['uid'] = $_GET['uuid'];
            $ucom['username'] = $_GET['uusername'];
        }else{
            if($ucom['uid'] == $_G['uid']){
                if($_G['mobile']){
                    echo "<script>parent.tips('".$aljgwclang['php']['Can_not_comment']."','');</script>";
                    exit;
                }else{
                    echo "<script>parent.showDialog('".$aljgwclang['php']['Can_not_comment']."','right','','');</script>";
                    exit;
                }
            }
        }
        $insertarray=array(
            'uid'=>$_G['uid'],
            'username'=>$_G['username'],
            'content'=>$_GET['commentmessage_1'],
            'gid'=>$_GET['gid'],
            'dateline'=>TIMESTAMP,
            'upid'=>$_GET['upid'],
            'uusername'=>$ucom['username'],
            'uuid'=>$ucom['uid'],
            'subcatid'=>$_GET['subcatid'],
            'bid'=>$_GET['bid'],
        );
        $insertid = C::t('#aljgwc#aljbd_comment_goods')->insert($insertarray,true);
        if($_G['mobile']){
            if($_GET['do'] == 'ajax'){
                echo json_encode(aljhtx::ajaxPostCharSet(array('code'=>100,'text'=>lang('plugin/aljbd', 's36'))));
                exit;
            }else {
                echo "<script>parent.tips('" . lang('plugin/aljbd', 's36') . "',function(){parent.location.href=parent.location.href;});</script>";
                exit;
            }
        }else{
            echo "<script>parent.showDialog('".lang('plugin/aljbd','s36')."','right','',function(){parent.location.href=parent.location.href;});</script>";
            exit;
        }
    }
}else if($_GET['act'] == 'logistics_details'){
    $navtitle = lang("plugin/aljbdx","aljbdx_inc_php_58");
    $orderid = addslashes($_GET['orderid']);
    $order=C::t('#aljgwc#aljbd_goods_order')->fetch($orderid);
    $wuliulist=C::t('#aljbd#aljbd_wuliu')->fetch($_GET['orderid']);
    include template('aljbdx:wuliu/logistics_details');
}elseif($_GET['act'] == 'refund'){
    if(empty($_G['uid'])){
        dheader("location:".$login_callback);
    }
    $orderid = addslashes($_GET['orderid']);
    $order = C::t('#aljbdx#aljbd_goods_order') -> fetch($orderid);
    $shop_id = $order['shop_id'];
    $store_id = $order['store_id'];
    if($pid==2){
        $shops['uid'] = 1;
    }elseif($store_id>0){
        $shops=C::t('#aljtsq#aljtsq_store')->fetch($store_id);
        $shops['uid'] = $shops['tc_uid'];
        $shops['name'] = $shops['tc_store_name'];
        $refund_seturl = 'plugin.php?id=aljht&act=admin&op=refundlist&ajax=yes&store_id='.$store_id.'&store=yes';
    }else{
        $shops=C::t('#aljbd#aljbd')->fetch($shop_id);
        $refund_seturl = 'plugin.php?id=aljht&act=admin&op=refundlist&ajax=yes&bid='.$shop_id;
    }
    $r_refund = C::t('#aljbdx#aljgwc_refund')->fetch($orderid);
    if(submitcheck('formhash')){
        
        if(!$order){
            echo "<script>parent.tips('".lang("plugin/aljbdx","aljbdx_inc_php_16")."');</script>";
            exit;
        }
        if($order['status']>3 || $order['status']<2){
            echo "<script>parent.tips('".lang("plugin/aljbdx","aljbdx_inc_php_17")."');</script>";
            exit;
        }
        if($order['uid'] != $_G['uid']){
            echo "<script>parent.tips('".lang("plugin/aljbdx","aljbdx_inc_php_18")."');</script>";
            exit;
        }
        if(empty($_GET['refund_type'])){
            echo "<script>parent.tips('".lang("plugin/aljbdx","aljbdx_inc_php_19")."');</script>";
            exit;
        }
        if(empty($_GET['content'])){
            echo "<script>parent.tips('".lang("plugin/aljbdx","aljbdx_inc_php_20")."');</script>";
            exit;
        }
        $imagesarray = explode(',',$_GET['images']);

        if(count($imagesarray) > 5){
            echo "<script>parent.tips('".lang("plugin/aljbdx","aljbdx_inc_php_21")."','');</script>";
            exit;
        }

        foreach($imagesarray as $key => $val){
            if(empty($val)){
                continue;
            }
            $position = 'refund';
            $rand = rand(100, 999);
            $pics = date("YmdHis") . $rand . '.jpg';
            $img_dir = 'source/plugin/aljbdx/static/img/'.$position.'/'.date('Ymd',TIMESTAMP).'/';
            if (!is_dir($img_dir)) {
                mkdir($img_dir);
            }
            $pic = $img_dir . $pics;


            $logo = file_put_contents($pic,base64_decode($val));

            if($logo){
                $imgs .= $pic.',';
            }
        }
        $insertarray = array(
            'orderid' => $orderid,
            'shop_id' => $shop_id,
            'pid' => $pid,
            'payment' => $order['payment'],
            'price' => $order['price'],
            'goodsname' => $order['stitle'],
            'buyer' => $order['buyer'],
            'uid' => $_G['uid'],
            'guid' => $shops['uid'],
            'username' => $_G['username'],
            'imgs' => trim($imgs,','),
            'content' => $_GET['content'],
            'refund_type' => $_GET['refund_type'],
            'addtime' => TIMESTAMP,
            'bd_info' => serialize($shops),
        );
        if($_G['cache']['plugin']['aljtsc']['is_aljtsc']){
            $insertarray['store_id'] = $store_id;
        }
        if($r_refund){
            echo "<script>parent.tips('".lang("plugin/aljbdx","aljbdx_inc_php_22")."',function(){parent.location.href='".$orderlisturl."';});</script>";
            exit;
        }else{
            C::t('#aljbdx#aljgwc_refund')->insert($insertarray);
        }
        if($_G['cache']['plugin']['aljbdx']['refund_template']){
            $refundtemplate = $_G['cache']['plugin']['aljbdx']['refund_template'];
        }else{
            $refundtemplate = $_G['cache']['plugin']['aljgwc']['refund_template'];
        }
        if($store_id>0 && $_G['cache']['plugin']['aljtsc']['refund_template']){
            $refundtemplate = $_G['cache']['plugin']['aljtsc']['refund_template'];
        }
        $mes = str_replace('{username}',$order['username'],str_replace('{name}',$shops['name'],str_replace('{orderid}',$orderid,$refundtemplate))).' <a href="'.$refund_seturl.'">'.lang("plugin/aljbdx","aljbdx_inc_php_59").'</a>';
        notification_add($shops['uid'],'system',$mes);
        $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
        foreach($groupids as $g_uid){
            notification_add($g_uid['uid'], 'system', $mes);
        }
        echo "<script>parent.tips('".lang("plugin/aljbdx","aljbdx_inc_php_23")."',function(){parent.location.href='".$orderlisturl."';});</script>";
        exit;

    }else{
        $navtitle = '&#36864;&#27454;&#30003;&#35831;';
        include template('aljbdx:refund/refund');
    }
} else if($_GET['act'] == 'user'){
    if(empty($_G['uid'])){
        $login_callback = 'member.php?mod=logging&action=login&referer=plugin.php?id=aljbdx%26act='.$_GET['act'];
        dheader("location:".$login_callback);
        exit;
    }

    if($cparray['aljbd']){
        $settings_aljbd=C::t('#aljbd#aljbd_setting')->range();
    }
    $group_array = C::t('common_usergroup')->range();

    if(!in_array($_G['groupid'],$admingroups)) {
        if (C::t('#aljbd#aljbd')->fetch_by_uid($_G['uid'])) {
            $ddo = '&do=bus';
        } else {
            $ddo = '&do=per';
        }
    }else{
        $ddo = '&do=admin';
    }
    $conn[] ='aljbd_goods_order';
    $where = 'where pid = 0 and status < 5 and order_type !=3 ';
    /*if(!$_GET['do']){
        dheader('Location: plugin.php?id=aljgwc&act=user'.$ddo.'&pluginid='.$pluginid);
    }else*/
    if($_GET['do'] == 'bus'){
        $do = '&do=per';
        $ord = '&ord=dianp';
        $userimg = 'source/plugin/aljht/static/img/aljbd/user/myuser.png';
        $bids = DB::fetch_all('select id from %t where uid = %d',array('aljbd',$_G['uid']));
        foreach($bids as $bid){
            $ids[] = $bid['id'];
        }
        $bids = implode(',',$ids);
        $where .= ' and shop_id in(%i)';
        if($bids){
            $conn[] = $bids;
        }else{
            $conn[] = 0;
        }
    }elseif($_GET['do'] == 'admin'){
        $do_per = '&do=per';
        $do_bus = '&do=bus';
        $ord = '&ord=admin';
        $userimg_myuser = 'source/plugin/aljht/static/img/aljbd/user/myuser.png';
        $userimg = 'source/plugin/aljht/static/img/aljbd/user/mybrand.png';
    }else{
        $do = '&do=bus';
        $ord = '&ord=ge';
        $userimg = 'source/plugin/aljht/static/img/aljbd/user/mybrand.png';
        if(!$_G['cache']['plugin']['aljbdx']['user_order_type'] || ($_G['cache']['plugin']['aljbdx']['user_order_type'] == 1 && !in_array($_G['groupid'],$admingroups))){
            $where .= ' and uid = %d';
            $conn[] = $_G['uid'];
        }
        
        $dourl = '&do='.$_GET['do'];
    }
    $where .= ' group by status';
    $num = DB::fetch_all('select status,count(*) a from %t '.$where,$conn);
    //�ҵ�ȫ������
    $mobile_user_order = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljbd']['mobile_user_order']));
    foreach($mobile_user_order as $key=>$value){
        $arr=explode('|',$value);
        $mobile_user_order_types[]=$arr;
    }
    //�ҵ�ҳ�泣�����
    $mobile_user_common_entrance = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljbd']['mobile_user_common_entrance']));
    foreach($mobile_user_common_entrance as $key=>$value){
        $arr=explode('|',$value);
        $mobile_user_common_entrance_types[]=$arr;
    }
    //�ҵ�ҳ���̼�����
    $mobile_user_business_center = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljbd']['mobile_user_business_center']));
    foreach($mobile_user_business_center as $key=>$value){
        $arr=explode('|',$value);
        $mobile_user_business_center_types[]=$arr;
    }
    //�ҵ�ҳ��ͬ����Ϣ
    $mobile_user_city_wide = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljbd']['mobile_user_city_wide']));
    foreach($mobile_user_city_wide as $key=>$value){
        $arr=explode('|',$value);
        $mobile_user_city_wide_types[]=$arr;
    }
    foreach($num as $k => $v){
        if($v['status'] == '1'){
            $order_pay = $v['a'];
        }elseif($v['status'] == '2'){
            $order_send = $v['a'];
        }elseif($v['status'] == '3'){
            $order_deliver = $v['a'];
        }elseif($v['status'] == '4'){
            $order_evaluate = $v['a'];
        }
    }
    $navtitle = lang("plugin/aljbdx","aljbdx_inc_php_60");
    if(!$_G['mobile']){
        header('location: plugin.php?id=aljht');
        exit;
    }
    if($_G['cache']['plugin']['aljsfx'] && $_G['cache']['plugin']['aljsfx']['is_referee']){
        $fx_userinfo = DB::fetch_first('select * from %t where uid=%d ', array('aljsfx_user', $_G['uid']));
        if($fx_userinfo['first_leader_uid']){
            $fx_user = getuserbyuid($fx_userinfo['first_leader_uid']);
            $first_leader_uid_username = '<span class="bind_phone" style="margin-left:5px;">&#25512;&#33616;&#20154;&#65306;'.$fx_user['username'].'</span>';
        }
    }
    if($card_user && $card_info['card_title'] && $_G['cache']['plugin']['aljbdx']['is_show_vip']){
        $viptitle = '<a class="viptitlel" href="plugin.php?id=aljtcc&c=index&a=index&ajax=yes&card_id=1">'.$card_info['card_title'].'</a>';
    }
    
    if($_G['cache']['plugin']['aljbdx']['user_type'] == 1){
        //ƽ̨����
        $mobile_user_gg_text = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljbdx']['mobile_user_gg_text']));
        foreach($mobile_user_gg_text as $key=>$value){
            $arr=explode('|',$value);
            $mobile_user_gg_text_types[]=$arr;
        }
        include template('aljbdx:user/newuser');
    }else{
        include template('aljbdx:user/user_new');
    }

}else{
    dheader("location: plugin.php?id=aljbdx&act=cart");
    exit;
}
?>