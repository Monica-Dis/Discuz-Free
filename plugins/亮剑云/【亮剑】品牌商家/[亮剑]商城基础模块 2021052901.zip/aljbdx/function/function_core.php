<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljbd'))){
    $settings_aljbd=C::t('#aljbd#aljbd_setting')->range();
    $is_openarray = array('iswatermark','is_daohang','alipay','malipay','isextcredit','pic','isgo','isnews','isyouh','ispd','isrewrite','islogo','isqq','ista','sjurl','sj_index_lz','time');
    foreach($settings_aljbd as $k => $v){
        if(in_array($k,$is_openarray)){//�����ж�
            if($v['value'] == 1){
                $_G['cache']['plugin']['aljbd'][$k] = 1;
            }elseif($v['value'] == 2){
                $_G['cache']['plugin']['aljbd'][$k] = 0;
            }
        }else{
            if($v['value']){
                $_G['cache']['plugin']['aljbd'][$k] = htmlspecialchars_decode($v['value']);//ͬ����������ֵ���������б���
            }
        }
    }
}
/*$point=[
    'lng'=>121.427417,
    'lat'=>31.20357
];
$arr=[
    [
        'lng'=>121.23036,
        'lat'=>31.218609
    ],
    [
        'lng'=>121.233666,
        'lat'=>31.210579
    ],
    [
        'lng'=>121.247177,
        'lat'=>31.206749
    ],
    [
        'lng'=>121.276353,
        'lat'=>31.190811
    ],
    [
        'lng'=>121.267442,
        'lat'=>31.237383
    ],
];
*/
//$a= is_point_in_polygon($point, $arr);
//var_dump($a);


/**
* �ж�һ�������Ƿ���һ��������ڣ��ɶ������Χ�ɵģ�
* ����˼�����������߷����������������θ��ߵĽ��㣬�����ż��������ڶ�����⣬����
* �ڶ�����ڡ����ῼ��һЩ�������������ڶ���ζ����ϣ����ڶ���α��ϵ����������
* @param $point ָ��������
* @param $pts ��������� ˳ʱ�뷽��
*/
function is_point_in_polygon($point, $pts) {
  $N = count($pts);
  $boundOrVertex = true; //�����λ�ڶ���εĶ������ϣ�Ҳ�������ڶ�����ڣ�ֱ�ӷ���true
  $intersectCount = 0;//cross points count of x 
  $precision = 2e-10; //�������ͼ���ʱ����0�Ƚ�ʱ����ݲ�
  $p1 = 0;//neighbour bound vertices
  $p2 = 0;
  $p = $point; //���Ե�

  $p1 = $pts[0];//left vertex        
  for ($i = 1; $i <= $N; ++$i) {//check all rays
      // dump($p1);
      if ($p['lng'] == $p1['lng'] && $p['lat'] == $p1['lat']) {
          return $boundOrVertex;//p is an vertex
      }
       
      $p2 = $pts[$i % $N];//right vertex            
      if ($p['lat'] < min($p1['lat'], $p2['lat']) || $p['lat'] > max($p1['lat'], $p2['lat'])) {//ray is outside of our interests
          $p1 = $p2; 
          continue;//next ray left point
      }
       
      if ($p['lat'] > min($p1['lat'], $p2['lat']) && $p['lat'] < max($p1['lat'], $p2['lat'])) {//ray is crossing over by the algorithm (common part of)
          if($p['lng'] <= max($p1['lng'], $p2['lng'])){//x is before of ray
              if ($p1['lat'] == $p2['lat'] && $p['lng'] >= min($p1['lng'], $p2['lng'])) {//overlies on a horizontal ray
                  return $boundOrVertex;
              }
               
              if ($p1['lng'] == $p2['lng']) {//ray is vertical                        
                  if ($p1['lng'] == $p['lng']) {//overlies on a vertical ray
                      return $boundOrVertex;
                  } else {//before ray
                      ++$intersectCount;
                  }
              } else {//cross point on the left side
                  $xinters = ($p['lat'] - $p1['lat']) * ($p2['lng'] - $p1['lng']) / ($p2['lat'] - $p1['lat']) + $p1['lng'];//cross point of lng
                  if (abs($p['lng'] - $xinters) < $precision) {//overlies on a ray
                      return $boundOrVertex;
                  }
                   
                  if ($p['lng'] < $xinters) {//before ray
                      ++$intersectCount;
                  } 
              }
          }
      } else {//special case when ray is crossing through the vertex
          if ($p['lat'] == $p2['lat'] && $p['lng'] <= $p2['lng']) {//p crossing over p2
              $p3 = $pts[($i+1) % $N]; //next vertex
              if ($p['lat'] >= min($p1['lat'], $p3['lat']) && $p['lat'] <= max($p1['lat'], $p3['lat'])) { //p.lat lies between p1.lat & p3.lat
                  ++$intersectCount;
              } else {
                  $intersectCount += 2;
              }
          }
      }
      $p1 = $p2;//next ray left point
  }

  if ($intersectCount % 2 == 0) {//ż���ڶ������
      return false;
  } else { //�����ڶ������
      return true;
  }
}
/*
 * ���ع��۸�
 */
function skups($attr_sku,$path){
    $attr_sku = unserialize($attr_sku);

    foreach($attr_sku as $k => $v){
        $gattrsku[$v['path']] = $v;
    }
    return array('saleprice'=>$gattrsku[$path]['saleprice'],'stock'=>$gattrsku[$path]['stock'],'marketprice'=>$gattrsku[$path]['marketprice'],'newprice'=>$gattrsku[$path]['newprice'],'card_price'=>$gattrsku[$path]['card_price']);
}
/*
 * �������
 */
function skunum($attr_sku,$path,$num,$gid){
    C::t('#aljbd#aljbd_goods') -> update_num_by_id($gid, $num);
    if($attr_sku){
        $attr_sku = unserialize($attr_sku);
        foreach($attr_sku as $k => $v){
            if($v['path'] == $path){
                $attr_sku[$k]['stock'] = $attr_sku[$k]['stock']-$num;
            }
        }
        C::t('#aljbd#aljbd_goods')->update($gid,array('attr_sku'=>serialize($attr_sku)));
    }
}
/*
 * ���ع��ﳵ�ŵ���Ʒ�Ľ��
 */
function cart_id_store($bid,$pid=0,$store_id=0){
    global $pluginid,$_G,$fare_desc,$price_unit,$def_address,$oss_img_url,$new_price_order_num;
    
    if($_G['cache']['plugin']['aljtcc']){
        $card_user = DB::fetch_first('select * from %t where uid=%d and end_time>%d and card_id=1',array('aljtcc_card_user',$_G['uid'],TIMESTAMP));
        $card_info = DB::fetch_first('select * from %t where id=%d ',array('aljtcc_card',1));
    }
    $ggurl = 'plugin.php?id=aljbd&act=goodview&bid={bid}&gid={goods_id}';
    
    $sql = " AND type = 1 ";
    $query = C::t('#aljbdx#aljgwc')->fetch_all_by_uid_store($_G['uid'],$bid,$pid,$store_id,$sql);
    
    
    
    $t_fare = $t_price = $t_give_integral = $t_pay_integral = $mun_ids = $weight_ids = array();
    
    foreach($query as $key => $val){
        $bdinfo = C::t('#aljtsq#aljtsq_store')->fetch($val['store_id']);
        $baobei = DB::fetch_first('select * from %t where id=%d',array($pluginid.'_goods',$val['goods_id']));
        if(empty($baobei) || $baobei['rubbish'] == 1 || $baobei['state'] == 1){
            C::t('#aljbdx#aljgwc')->delete($val['id']);
            $gwcid[] = $val['id'];
            unset($query[$key]);
            continue;
        }
        $query[$key]['url'] = str_replace(array('{bid}','{goods_id}'),array($val['shop_id'],$val['goods_id']),$ggurl);
        $query[$key]['pic'] = $baobei['pic1'].$oss_img_url;
        $gattrsku = skups($baobei['attr_sku'],$val['path']);
        if($baobei['attr_sku']){
            $query[$key]['price'] = $gattrsku['saleprice'];
            if($gattrsku['saleprice']<=0){
                C::t('#aljgwc#aljgwc')->delete($val['id']);
                $gwcid[] = $val['id'];
                unset($query[$key]);
                continue;
            }
        }else{
            $query[$key]['price'] = $baobei['price1'];
        }
        if($baobei['new_price']>0){
            //�Ƿ�δ�¹���������
            if($new_price_order_num<=0){
                $query[$key]['price'] = $baobei['new_price'];//����ר���۸�
                if($gattrsku['newprice']>0){
                    $query[$key]['price'] = $gattrsku['newprice'];//��ϼ۸�
                }
            }
        }
        if($baobei['is_volume'] == 2 && $val['path']){
            $volume_label = DB::fetch_first('select * from %t where goods_id=%d and price_type=%d and path=%s and volume_number<=%d order by id desc limit 1',array('aljbd_goods_volume_price',$val['goods_id'],$baobei['is_volume'],$val['path'],$val['num']));

        }else if($baobei['is_volume'] == 1){
            $volume_label = DB::fetch_first('select * from %t where goods_id=%d and price_type=%d and volume_number<=%d order by id desc limit 1',array('aljbd_goods_volume_price',$val['goods_id'],$baobei['is_volume'],$val['num']));

        }
        if($volume_label['volume_price']>0){
            $query[$key]['price'] = $volume_label['volume_price'];//���ݼ۸�
        }
        
        if($card_user && $baobei['card_price']>0){
            if($_G['cache']['plugin']['aljbd']['is_card_price']){
                $query[$key]['price'] = $gattrsku['card_price'] > 0 && $baobei['attr_sku'] ? $gattrsku['card_price'] : $baobei['card_price'];
            }else{
                $query[$key]['price'] = substr(sprintf("%.3f",$query[$key]['price']*($baobei['card_price']/100)),0,-1);
            }
        }
        //ms
        if($_G['cache']['plugin']['aljms']['is_aljms']){
            $ms_date = dgmdate(TIMESTAMP, "Ymd");
            $ms_info = DB::fetch_first('select * from %t where ms_status = 0 and ms_gid=%d and ms_date=%d and ms_start_time<=%d and ms_end_time>%d  and ms_sale_num<ms_num',array('aljhtx_activity_ms_enter',$val['goods_id'],$ms_date,TIMESTAMP,TIMESTAMP));
            if($ms_info['ms_start_time'] < TIMESTAMP && $ms_info['ms_end_time'] > TIMESTAMP && ($val['path'] == $ms_info['ms_sku'] || $ms_info['ms_sku']==0)){
                $query[$key]['price'] = $ms_info['ms_price'];
            }
        }
        if($baobei['fare_desc'] == 1 || $baobei['fare_desc'] == 2){
            $query[$key]['fare_info'] = $fare_desc[$baobei['fare_desc']];
            $t_fare[$val['store_id']] += 0;
        }else{
            $query[$key]['fare_info'] = $price_unit.$baobei['fare'];
            if($bdinfo['fare_type'] == 1){
                $t_fare[$val['store_id']] += $baobei['fare']*$val['num'];
            }else if($bdinfo['fare_type'] == 2){
                
                $t_fare[$val['store_id']] = $baobei['fare']>$t_fare[$val['store_id']] ? $baobei['fare'] : $t_fare[$val['store_id']];
            }else{
                $t_fare[$val['store_id']] += $baobei['fare'];
            } 
        }
        if($query[$key]['price'] != $val['price']){
            C::t('#aljbdx#aljgwc')->update($val['id'], array('price' => $query[$key]['price']));
        }
        
        
        $t_give_integral[$val['store_id']] += floor($query[$key]['price']*($baobei['give_integral']/100)*$val['num']);
        
        $t_pay_integral[$val['store_id']] += sprintf("%.3f",$query[$key]['price']*($baobei['pay_integral']/100))*$val['num'];
        $weight_ids[$val['goods_id']] += $baobei['weight'];
        unset($volume_label);
        unset($baobei);
        unset($ms_date);
        unset($ms_info);
    }
    
    foreach($query as $value) {
        $list[$value['store_id']][] = $value;
        $t_price[$value['store_id']] += $value['price']*$value['num'];
        $goods_id_arr[] = $value['goods_id'];
        $goods_goodstype_arr[] = $value['goodstype'];
        $store_ids[] = $value['store_id'];
        $mun_ids[$value['goods_id']] += $value['num'];
    }
    if($store_id>0){
        $bdinfo = C::t('#aljtsq#aljtsq_store')->fetch($store_id);
        $fare_price = farePrice($goods_id_arr,$def_address,$bdinfo,$mun_ids,2);
        $t_fare[$store_id] = ($bdinfo['fare_type'] == 3 && $bdinfo['postal_amount']<=$t_price[$bid]) ? 0 : $fare_price['fare'];
    }
    $ret = array(
        'list'=>$list,
        'goods_id_arr'=>$goods_id_arr,
        'goods_goodstype_arr'=>$goods_goodstype_arr,
        'store_ids'=>$store_ids,
        't_price'=>$t_price,
        't_fare'=>$t_fare,
        't_give_integral'=>$t_give_integral,
        't_pay_integral'=>$t_pay_integral,
    );
    return $ret;
}
/*
 * ���ع��ﳵ��Ʒ�Ľ��
 */
function cart_id($bid,$pid=0,$store_id=0){
    global $pluginid,$_G,$fare_desc,$price_unit,$def_address,$oss_img_url,$new_price_order_num;
    
    if($_G['cache']['plugin']['aljtcc']){
        $card_user = DB::fetch_first('select * from %t where uid=%d and end_time>%d and card_id=1',array('aljtcc_card_user',$_G['uid'],TIMESTAMP));
        $card_info = DB::fetch_first('select * from %t where id=%d ',array('aljtcc_card',1));
    }
    $ggurl = 'plugin.php?id=aljbd&act=goodview&bid={bid}&gid={goods_id}';
    $query = C::t('#aljbdx#aljgwc')->fetch_all_by_uid($_G['uid'],$bid,$pid,$store_id,' AND type != 8 ');
    
    $t_fare = $t_price = $t_give_integral = $t_pay_integral = $mun_ids = $weight_ids = $t_ms_yes = array();
    
    foreach($query as $key => $val){
        $bdinfo = C::t('#aljbd#aljbd')->fetch($val['shop_id']);
        $baobei = DB::fetch_first('select * from %t where id=%d',array($pluginid.'_goods',$val['goods_id']));
        if(empty($baobei) || $baobei['rubbish'] == 1 || $baobei['state'] == 1){
            C::t('#aljbdx#aljgwc')->delete($val['id']);
            $gwcid[] = $val['id'];
            unset($query[$key]);
            continue;
        }
        $query[$key]['url'] = str_replace(array('{bid}','{goods_id}'),array($val['shop_id'],$val['goods_id']),$ggurl);
        $query[$key]['pic'] = $baobei['pic1'].$oss_img_url;
        $gattrsku = skups($baobei['attr_sku'],$val['path']);
        
        if($baobei['attr_sku']){
            $query[$key]['price'] = $gattrsku['saleprice'];
            if($gattrsku['saleprice']<=0){
                C::t('#aljgwc#aljgwc')->delete($val['id']);
                $gwcid[] = $val['id'];
                unset($query[$key]);
                continue;
            }
        }else{
            $query[$key]['price'] = $baobei['price1'];
        }
        if($baobei['new_price']>0){
            //�Ƿ�δ�¹���������
            if($new_price_order_num<=0){
                $query[$key]['price'] = $baobei['new_price'];//����ר���۸�
                if($gattrsku['newprice']>0){
                    $query[$key]['price'] = $gattrsku['newprice'];//��ϼ۸�
                }
            }
        }
        if($baobei['is_volume'] == 2 && $val['path']){
            $volume_label = DB::fetch_first('select * from %t where goods_id=%d and price_type=%d and path=%s and volume_number<=%d order by id desc limit 1',array('aljbd_goods_volume_price',$val['goods_id'],$baobei['is_volume'],$val['path'],$val['num']));

        }else if($baobei['is_volume'] == 1){
            $volume_label = DB::fetch_first('select * from %t where goods_id=%d and price_type=%d and volume_number<=%d order by id desc limit 1',array('aljbd_goods_volume_price',$val['goods_id'],$baobei['is_volume'],$val['num']));

        }
        if($volume_label['volume_price']>0){
            $query[$key]['price'] = $volume_label['volume_price'];//���ݼ۸�
        }
        
        //ms
        if($_G['cache']['plugin']['aljms']['is_aljms']){
            $ms_date = dgmdate(TIMESTAMP, "Ymd");
            $ms_info = DB::fetch_first('select * from %t where ms_status = 0 and ms_gid=%d and ms_date=%d and ms_start_time<=%d and ms_end_time>%d and ms_sale_num<ms_num',array('aljhtx_activity_ms_enter',$val['goods_id'],$ms_date,TIMESTAMP,TIMESTAMP));
            if($ms_info['ms_start_time'] < TIMESTAMP && $ms_info['ms_end_time'] > TIMESTAMP && ($val['path'] == $ms_info['ms_sku'] || $ms_info['ms_sku']==0)){
                
                $query[$key]['price'] = $ms_info['ms_price'];
                if($_G['cache']['plugin']['aljms']['ms_no_coupons']){
                    $t_ms_yes[$val['shop_id']] =  1;
                }
            }
        }
        if($card_user && $baobei['card_price']>0){
            if($_G['cache']['plugin']['aljbd']['is_card_price']){
                $query[$key]['price'] = $gattrsku['card_price'] > 0 && $baobei['attr_sku'] ? $gattrsku['card_price'] : $baobei['card_price'];
            }else{
                $query[$key]['price'] = substr(sprintf("%.3f",$query[$key]['price']*($baobei['card_price']/100)),0,-1);
            }
        }
        if($baobei['fare_desc'] == 1 || $baobei['fare_desc'] == 2){
            $query[$key]['fare_info'] = $fare_desc[$baobei['fare_desc']];
            $t_fare[$val['shop_id']] += 0;
        }else{
            $query[$key]['fare_info'] = $price_unit.$baobei['fare'];
            if($bdinfo['fare_type'] == 1){
                $t_fare[$val['shop_id']] += $baobei['fare']*$val['num'];
            }else if($bdinfo['fare_type'] == 2){
                
                $t_fare[$val['shop_id']] = $baobei['fare']>$t_fare[$val['shop_id']] ? $baobei['fare'] : $t_fare[$val['shop_id']];
            }else{
                $t_fare[$val['shop_id']] += $baobei['fare'];
            } 
        }
        if($query[$key]['price'] != $val['price']){
            C::t('#aljbdx#aljgwc')->update($val['id'], array('price' => $query[$key]['price']));
        }
        if($_G['cache']['plugin']['aljbd']['is_give_integral']==1){
            if($_G['cache']['plugin']['aljbd']['send_give_integral_proportions']==1){
                $t_give_integral[$val['shop_id']] += floor($query[$key]['price']*($baobei['give_integral']/100)*$_G['cache']['plugin']['aljbdx']['proportions'])*$val['num'];
            }else{
                $t_give_integral[$val['shop_id']] += floor($query[$key]['price']*($baobei['give_integral']/100))*$val['num'];
            }
        }else{
            $t_give_integral[$val['shop_id']] += $baobei['give_integral']*$val['num'];
        }
        
        $t_pay_integral[$val['shop_id']] += sprintf("%.2f",$query[$key]['price']*($baobei['pay_integral']/100))*$val['num'];
        $weight_ids[$val['goods_id']] += $baobei['weight'];
        
        unset($volume_label);
        unset($baobei);
        unset($ms_date);
        unset($ms_info);
    }
    foreach($query as $value) {
        $list[$value['shop_id']][] = $value;
        $t_price[$value['shop_id']] += $value['price']*$value['num'];
        $goods_id_arr[] = $value['goods_id'];
        $goods_goodstype_arr[] = $value['goodstype'];
        $shop_id[] = $value['shop_id'];
        $mun_ids[$value['goods_id']] += $value['num'];
    }
    if($bid>0){
        $bdinfo = C::t('#aljbd#aljbd')->fetch($bid);
        $fare_price = farePrice($goods_id_arr,$def_address,$bdinfo,$mun_ids,2);
        $t_fare[$bid] = ($bdinfo['fare_type'] == 3 && $bdinfo['postal_amount']<=$t_price[$bid]) ? 0 : $fare_price['fare'];
    }
    $ret = array(
        'list'=>$list,
        'goods_id_arr'=>$goods_id_arr,
        'goods_goodstype_arr'=>$goods_goodstype_arr,
        'shop_id'=>$shop_id,
        't_price'=>$t_price,
        't_fare'=>$t_fare,
        't_ms_yes'=>$t_ms_yes,
        't_give_integral'=>$t_give_integral,
        't_pay_integral'=>$t_pay_integral,
    );
    return $ret;
}
function pt_goods_status ($order,$goods_id) {
    global $_G;
    if($order['collage_order']){//����
        $res = DB::query('update %t set groupnumed=groupnumed+1 where grouporderid=%s and groupnumed<groupnum',array('aljspt_collage_order',$order['collage_order']));

        if($res) {
            $group=DB::fetch_first('select * from %t where grouporderid=%s ',array('aljspt_collage_order', $order['collage_order']));
            if($group['groupnum'] == $group['groupnumed']){
                //�޸Ķ���Ϊ�Ѹ���
                C::t('#aljgwc#aljbd_goods_order')->update($order['orderid'], array('status' => 2));
                //�޸��ŵ�Ϊ�ɹ�
                DB::update('aljspt_collage_order',array('grouporderstatus'=>2),array('grouporderid'=>$order['collage_order']));
                //ȡ�������ŵ����޸�Ϊƴ�ųɹ�
                $grouplist =DB::fetch_all('select * from %t where collage_order=%s and status = %d',array('aljbd_goods_order', $order['collage_order'], 2));
                foreach($grouplist as $tmp_key => $tmp_value){
                    DB::query('update %t set amount=%d where orderid=%s',array('aljbd_goods_order', 1, $tmp_value['orderid']));
                }
            }
        }else {
            if($order['pay_integral'] && $order['pay_ext']){
                updatemembercount(
                    $order['uid'],
                    array($_G['cache']['plugin']['aljbdx']['exttype'] => intval($order['pay_ext'])),
                    '',
                    '',
                    '',
                    '',
                    '&#36141;&#20080;&#21830;&#21697;&#22833;&#36133;&#65292;&#31215;&#20998;&#36864;&#22238;',
                    '&#36141;&#20080;&#21830;&#21697;&#22833;&#36133;&#65292;&#31215;&#20998;&#36864;&#22238;' . $order['pay_ext'] . $_G['setting']['extcredits'][$_G['cache']['plugin']['aljbdx']['exttype']]['title'] . lang("plugin/aljbdx","aljbdx_inc_php_45") . $order['orderid']);
            }
        }
    }else{//����
        $pt_orderid = random(10).dgmdate(TIMESTAMP, 'YmdHis');
        $pt_grouporder=array(
            'grouporderid'=>$pt_orderid,
            'groupheadusername'=>$order['username'],
            'groupheaduid'=>$order['uid'],
            'groupopentime'=>TIMESTAMP,
            'grouporderprice'=>$order['price'],
            'groupnum'=>$order['collage_num'],
            'groupnumed'=>1,
            'grouporderstatus'=>$order['collage_num'] == 1 ? 2 : 1,
            'orderid'=>$order['orderid'],
            'goodsid'=>$goods_id,
            'create_time'=>TIMESTAMP,
            'update_time'=>TIMESTAMP,
        );

        DB::insert('aljspt_collage_order',$pt_grouporder);
        $ago_array = array('collage_order' => $pt_orderid);
        if($order['collage_num'] == 1){
            $ago_array['amount'] = 1;
        }
        //�ŵ����붩����
        C::t('#aljgwc#aljbd_goods_order')->update($order['orderid'], $ago_array);
        C::t('#aljgwc#aljbd_goods_order_list')->update($order['orderid'], array('collage_order' => $pt_orderid));
    }
}
/*
 * �ж���Ʒ���Ͳ�����
 */
function orderStatus($order){
    global $_G;
    $data['out_trade_no'] = $order['orderid'];
    $goods_id = DB::result_first('select goods_id from %t where orderid=%s',array('aljbd_goods_order_list',$data['out_trade_no']));

    if(($order['commodity_type'] == 1 && $order['category'] == 1 && $_G['cache']['plugin']['aljstg']['is_aljstg']) || ($order['get_to_the_shop'] == 1 && $_G['cache']['plugin']['aljstg'] && $order['commodity_type'] == 0)){
        if($order['get_to_the_shop'] == 1){
            $type = 1;
            $replacetext = $_G['cache']['plugin']['aljstg']['pick_up_code_tips'];
        }else{
            $type = 0;
            $replacetext = $_G['cache']['plugin']['aljstg']['code_tips'];
        }
        include_once DISCUZ_ROOT .'source/plugin/aljbdx/function/new_function.php';
        randcode($type,$replacetext,$order,$goods_id);//ȡ������Ź�ȯ����
        return 3;
    }else if($order['commodity_type'] == 2){//ƴ��
        if($order['collage_order']){//����
            $res = DB::query('update %t set groupnumed=groupnumed+1 where grouporderid=%s and groupnumed<groupnum',array('aljspt_collage_order',$order['collage_order']));

            if($res) {
                $status = 2;
                $group=DB::fetch_first('select * from %t where grouporderid=%s ',array('aljspt_collage_order', $order['collage_order']));
                if($group['groupnum'] == $group['groupnumed']){
                    $qborder = DB::fetch_first('select * from %t where aljorderid=%s',array('aljqb_payorder',$_GET['aljorderid']));
                    //�޸Ķ���Ϊ�Ѹ���
                    C::t('#aljgwc#aljbd_goods_order')->update($data['out_trade_no'], array('status' => 2,'admin'=>$qborder['trade_mod'], 'buyer' => $_GET['aljorderid'], 'confirmdate' => $_GET['paytime']));
                    //�޸��ŵ�Ϊ�ɹ�
                    DB::update('aljspt_collage_order',array('grouporderstatus'=>2),array('grouporderid'=>$order['collage_order']));

                    $goods = C::t('#aljbd#aljbd_goods')->fetch($goods_id);
                    if($goods['other']){
                        $other = unserialize($goods['other']);
                    }
                    
                    $order_old = $order;
                    //ȡ�������ŵ����޸�Ϊƴ�ųɹ�
                    $grouplist =DB::fetch_all('select * from %t where collage_order=%s and status = %d',array('aljbd_goods_order', $order['collage_order'], 2));
                    if($other[is_aljsqtg_stock] && $other['aljsqtg_goods_id'] > 0){
                        $goods = C::t('#aljbd#aljbd_goods')->fetch($other['aljsqtg_goods_id']);
                        if(count($grouplist) > $goods['amount']){
                            
                            foreach($grouplist as $tmp_key => $tmp_value){
                                if($tmp_value['price']>0){
                                    $order = $tmp_value;
                                    require_once DISCUZ_ROOT .'source/plugin/aljht/function/pt_order.php';
                                    $result = pt_refund_auto($order);
                                    if($result['code'] == 200){
                                        DB::update('aljbd_goods_order',array('status'=>6), array('orderid'=>$tmp_value['orderid']));
                                        DB::update('aljbd_goods_order_list',array('status'=>6), array('orderid'=>$tmp_value['orderid']));
                                        DB::update('aljqb_payorder',array('status'=>2, 'overtime' => TIMESTAMP),"orderid='".$tmp_value['orderid']."'");
                                        
                                        if(file_exists(DISCUZ_ROOT ."source/plugin/aljhtx/include/pt_fail_send_template.php")){
                                            require_once DISCUZ_ROOT .'source/plugin/aljhtx/include/pt_fail_send_template.php';
                                        }
                                        
                                    }
                                    //����Ǯ��
                                }
                            }
                            DB::update('aljspt_collage_order',array('grouporderstatus'=>3),array('grouporderid'=>$order['collage_order']));
                            echo 'success';
                            exit;
                        }
                    }
                    foreach($grouplist as $tmp_key => $tmp_value){
                        DB::query('update %t set amount=%d where orderid=%s',array('aljbd_goods_order', 1, $tmp_value['orderid']));
                        if($order_old['uid'] != $tmp_value['uid']){
                            $tmp_value['amount'] = 1;
                            notify_consumers($tmp_value,$goods);
                        }
                        
                        if($other[is_aljsqtg_stock] && $other['aljsqtg_goods_id'] > 0){
                            $num = 1;
                            if($other['aljsqtg_goods_stock_num'] > 0){
                                $num = $other['aljsqtg_goods_stock_num'];
                            }
                            skunum('','',$num,$other['aljsqtg_goods_id']);//����Ͽ��
                            C::t('#aljbd#aljbd_goods')->update_num2_by_id($other['aljsqtg_goods_id'],$num);//������
                            
                        }
                        $address = unserialize($tmp_value['address']);
                        $bdinfo = C::t('#aljbd#aljbd')->fetch($tmp_value['shop_id']);
                        if($other['goodsview_type'] == 1 && $order['get_to_the_shop'] != 1 && $address['lat'] !=0 && $address['lng'] != 0 && (($bdinfo['platform_distribution'] == 1  && $_G['cache']['plugin']['aljpps']['is_aljbd']) || $_G['cache']['plugin']['aljsqtg']['platform_distribution'] == 1) && $_G['cache']['plugin']['aljpps']['aljbd_auto_order']){
                            
                            $status = 2;
                            $_GET['orderid'] = $tmp_value['orderid'];
                            $updatearray = array();
                            require DISCUZ_ROOT .'/source/plugin/aljpps/include/pay.php';
                            C::t('#aljgwc#aljbd_goods_order')->update($tmp_value['orderid'], $updatearray);
                            if($status !=2){
                                DB::update('aljbd_goods_order_list',array('status'=>$status), array('orderid'=>$tmp_value['orderid']));
                            }
                        }
                    }
                    
                }
                return $status;
            }else {
                if($order['price']>0){
                    require_once DISCUZ_ROOT .'source/plugin/aljht/function/pt_order.php';
                    $qborder = DB::fetch_first('select * from %t where aljorderid=%s',array('aljqb_payorder',$_GET['aljorderid']));
                    //�޸Ķ���Ϊ�Ѹ���
                    C::t('#aljgwc#aljbd_goods_order')->update($data['out_trade_no'], array('status' => 2,'admin'=>$qborder['trade_mod'], 'buyer' => $_GET['aljorderid'], 'confirmdate' => $_GET['paytime']));
                    $order['admin'] = $qborder['trade_mod'];
                    $result = pt_refund_auto($order);
                    if($result['code'] == 200){
                        DB::update('aljbd_goods_order',array('status'=>6), array('orderid'=>$data['out_trade_no']));
                        DB::update('aljbd_goods_order_list',array('status'=>6), array('orderid'=>$data['out_trade_no']));
                        DB::update('aljqb_payorder',array('status'=>2, 'overtime' => TIMESTAMP),"orderid='".$order['orderid']."'");
                        gaddnum($order);
                        if(file_exists(DISCUZ_ROOT ."source/plugin/aljhtx/include/pt_fail_send_template.php")){
                            require_once DISCUZ_ROOT .'source/plugin/aljhtx/include/pt_fail_send_template.php';
                        }
                        echo 'success';
                        exit;
                    }
                    //����Ǯ��
                }
            }
        }else{//����
            $pt_orderid = random(10).dgmdate(TIMESTAMP, 'YmdHis');
            $pt_grouporder=array(
                'grouporderid'=>$pt_orderid,
                'groupheadusername'=>$order['username'],
                'groupheaduid'=>$order['uid'],
                'groupopentime'=>$_GET['paytime'],
                'grouporderprice'=>$order['price'],
                'groupnum'=>$order['collage_num'],
                'groupnumed'=>1,
                'grouporderstatus'=>$order['collage_num'] == 1 ? 2 : 1,
                'orderid'=>$data['out_trade_no'],
                'goodsid'=>$goods_id,
                'create_time'=>TIMESTAMP,
                'update_time'=>TIMESTAMP,
            );

            DB::insert('aljspt_collage_order',$pt_grouporder);
            $ago_array = array('collage_order' => $pt_orderid);
            if($order['collage_num'] == 1){
                $ago_array['amount'] = 1;
            }
            //�ŵ����붩����
            C::t('#aljgwc#aljbd_goods_order')->update($data['out_trade_no'], $ago_array);
            C::t('#aljgwc#aljbd_goods_order_list')->update($data['out_trade_no'], array('collage_order' => $pt_orderid));

            return 2;
        }
    }else{
        //app sn
        if(file_exists(DISCUZ_ROOT ."source/plugin/aljhy/function/function_app.php")){
            require_once DISCUZ_ROOT .'source/plugin/aljhy/include/app_pay_status.php';
        }else {
            return 2;
        }
    }
}
/*
 * �����˷�����Ϣ����
 */
function notify_consumers($order,$f_goods_info){
    global $pluginid,$_G,$shop_order;
    require_once DISCUZ_ROOT .'source/plugin/aljhtx/class/class_aljhtx.php';
    $orderid = $order['orderid'];
    $orderlurln = '/plugin.php?id='.$pluginid.'&act=orderlist';
    if(file_exists(DISCUZ_ROOT ."source/plugin/aljhtx/include/purchaser_send_template.php")){
        require_once DISCUZ_ROOT .'source/plugin/aljhtx/include/purchaser_send_template.php';
    }
}
/*
 * ���������Ѳ�������
 */
function bdx_notice($orderid){
    global $pluginid,$_G,$shop_order;
    require_once DISCUZ_ROOT .'source/plugin/aljhtx/class/class_aljhtx.php';
    $shop_order=C::t('#aljgwc#aljbd_goods_order_list')->fetch_all_by_orderid($orderid);
    foreach($shop_order as $key => $val){
        $goods = unserialize($val['goodsinfo']);
        if($goods['other']){
            $other = unserialize($goods['other']);
        }
        if(!$other[is_aljsqtg_stock]){
            if(is_file(DISCUZ_ROOT.'source/plugin/aljayy/controller/aljayy/goods.php')){
                $aljayy = DB::fetch_first('select * from %t a left join %t b on a.goods_id=b.id where a.goods_id = %d', array('aljayy_goods', 'aljbd_goods', $val['goods_id']));
                if($aljayy['reduction_method'] == 'bypayment'){
                    skunum($aljayy['attr_sku'],$val['path'],$val['num'],$val['goods_id']);//����Ͽ��
                }
            }
        }
        C::t('#'.$pluginid.'#'.$pluginid.'_goods')->update_num2_by_id($val['goods_id'],$val['num']);//������
        //ms
        if($_G['cache']['plugin']['aljms']['is_aljms'] && $val['ms_enter_id']>0){
            DB::query('update %t set ms_sale_num=ms_sale_num+%d where id=%d',array('aljhtx_activity_ms_enter',$val['num'],$val['ms_enter_id']));
        }
        //app sn
        if(file_exists(DISCUZ_ROOT ."source/plugin/aljhy/function/function_app.php")){
            require_once DISCUZ_ROOT .'source/plugin/aljhy/include/app_sn.php';
        }
        if($_G['cache']['plugin']['aljpyh']['is_aljpyh']){
            require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/sendconsume_goods.php';
        }
    }
    $f_goods_info = C::t('#'.$pluginid.'#'.$pluginid.'_goods')->fetch($shop_order[0]['goods_id']);
    $order = C::t('#aljgwc#aljbd_goods_order') -> fetch($orderid);
    if($_G['cache']['plugin']['aljpyh']['is_aljpyh']){
        require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/sendconsume.php';
        require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/use_sendconsume.php';
    }
    if($order['deduction']>0 && file_exists(DISCUZ_ROOT ."source/plugin/aljhy/function/function_app.php")){
        require_once DISCUZ_ROOT .'source/plugin/aljhy/include/app_deduction.php';
    }
    $orderlurl = $_G['siteurl'].'/plugin.php?id='.$pluginid.'&act=orderlist';
    $orderlurln = '/plugin.php?id='.$pluginid.'&act=orderlist';
    $brand = C::t('#'.$pluginid.'#'.$pluginid) -> fetch($order['shop_id']);
    
    //s ��ѯ�Ƿ�������
    if($_G['cache']['plugin']['aljreg']['qb_desc'] && $_G['cache']['plugin']['aljbdx']['reg_pay_tips']){
        $fromuid = DB::result_first('select fromuid from %t where uid=%d ', array('aljreg_invite', $order['uid']));
        $regfee = sprintf("%1.2f",$order['price']*($_G['cache']['plugin']['aljbdx']['regfee']/100));
        if($fromuid>0 && $regfee>0){
            $ggurl = 'plugin.php?id=aljbd&act=goodview&bid={bid}&gid={goods_id}';
            $regmes = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],str_replace(array('{bid}','{goods_id}'),array($order['shop_id'],$shop_order[0]['goods_id']),$ggurl),$brand['name']),$_G['cache']['plugin']['aljbdx']['reg_pay_tips']);
            notification_add($fromuid,'system',$regmes);
        }
    }
    if($order['commodity_type'] == 7){//���۶���
        DB::query("update %t set status=2,updatetime=%d WHERE id=%d",array('aljkj',TIMESTAMP,$order['opentime']));
    }
    //e��ѯ�Ƿ�������
    if($order['order_type'] == 7){
        $orderlurln = 'plugin.php?id=aljsqtg&a=orderList';
        //s ���û�������Ϣ
        if(file_exists(DISCUZ_ROOT ."source/plugin/aljsqtg/include/purchaser_send_template.php")){
            require_once DISCUZ_ROOT .'source/plugin/aljsqtg/include/purchaser_send_template.php';
        }
        //s ������Ա������Ϣ
        if(file_exists(DISCUZ_ROOT ."source/plugin/aljsqtg/include/admin_send_template_aljsqtg.php")){
            require_once DISCUZ_ROOT .'source/plugin/aljsqtg/include/admin_send_template_aljsqtg.php';
        }
        //s ������Ա������Ϣ
        if($_G['cache']['plugin']['aljdx'] && !$aljstg_tips){
            include_once DISCUZ_ROOT .'source/plugin/aljdx/function_dx.php';
            $oaddress = unserialize($order['address']);
            $time = 'time';
            $phone = 'phone';
            if(preg_match('#^\d[\d-]{3,20}\d$#', $oaddress['mobile'])){
                sendsmsbyvar($oaddress['mobile'],'aljsqtg','peisongtixing',array($time =>date("Y-m-d", strtotime ("+1 day")) ,$phone => $_G['cache']['plugin']['aljsqtg']['tel_brand']));
            }
        }
    }else{
        if(($order['commodity_type'] == 1 && $order['category'] == 1 && $_G['cache']['plugin']['aljstg']['is_aljstg']) || ($order['get_to_the_shop'] == 1 && $_G['cache']['plugin']['aljstg'])) {
            $aljstg_tips = 1;
        }else{
            //�����˷�����Ϣ����
            notify_consumers($order,$f_goods_info);
        }
        //s ������Ա������Ϣ
        if(file_exists(DISCUZ_ROOT ."source/plugin/aljhtx/include/admin_send_template.php")){
            require_once DISCUZ_ROOT .'source/plugin/aljhtx/include/admin_send_template.php';
        }
        //s ������Ա������Ϣ

        if($_G['cache']['plugin']['aljdx'] && !$aljstg_tips){
            include_once DISCUZ_ROOT .'source/plugin/aljdx/function_dx.php';
            $oaddress = unserialize($order['address']);
            $orderidau = $_G['cache']['plugin']['aljbd']['is_dx_var'] ? 'orderidau' : 'orderid_au';
            $username_au = $_G['cache']['plugin']['aljbd']['is_dx_var'] ? 'usernameau' : 'username_au';
            if(preg_match('#^\d[\d-]{3,20}\d$#', $oaddress['mobile'])){
                sendsmsbyvar($oaddress['mobile'],'aljbd','tips_user',array($username_au =>$order['username'] ,$orderidau => $_G['cache']['plugin']['aljbd']['is_dx_order']?'**'.substr($order['orderid'],-4):$order['orderid']));
            }
            if(preg_match('#^\d[\d-]{3,20}\d$#', $brand['tel'])){
                sendsmsbyvar($brand['tel'],'aljbd','tips_business',array($orderidau => $_G['cache']['plugin']['aljbd']['is_dx_order']?'**'.substr($order['orderid'],-4):$order['orderid']));
            }
        }
        //�̼ҷ�������
        if(file_exists(DISCUZ_ROOT ."source/plugin/aljhtx/include/brand_send_template.php")){
            require_once DISCUZ_ROOT .'source/plugin/aljhtx/include/brand_send_template.php';
        }
        if($_G['cache']['plugin'][$pluginid]['time'] && $_G['cache']['plugin'][$pluginid]['notify_merchant']){

            $email_first = C::t("common_member")->fetch($order['uid']);
            $email = $email_first['email'];
            require_once libfile('function/mail');
            if($email_first['email']){
                $m=str_replace('{username}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['suctips'])).'&nbsp;<a href="'.$orderlurl.'">'.lang('plugin/aljgwc','View_orders').'</a>';
                sendmail_cron($email,$_G['cache']['plugin'][$pluginid]['mailtitle'].'@'.gmdate('Y-m-d H:i:s',$_G['timestamp']+8*3600),$m);
            }
            $email_f = C::t("common_member")->fetch($brand['uid']);
            $e = $email_f['email'];
            if($email_f['email']){
                $me=str_replace('{orderid}','<a href="'.$orderlurl.'">'.$orderid.'</a>',str_replace('{username}',$brand['username'],str_replace('{name}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['notify_merchant']))));
                $t=str_replace('{orderid}',$orderid,$_G['cache']['plugin'][$pluginid]['notify_merchant_title']);
                sendmail_cron($e,$t,$me);
            }
        }
    }
    
    if($_G['cache']['plugin']['aljsfx']['is_aljsfx']){
        $fxinfo = DB::fetch_first('select * from %t where uid=%d ', array('aljsfx_user', $order['uid']));
        if($fxinfo['first_leader_uid']>0) {//һ����ID
            notification_add($fxinfo['first_leader_uid'], 'system',lang("plugin/aljbdx","function_core_php_7").$order['username'].lang("plugin/aljbdx","function_core_php_1").'<a href="plugin.php?id=aljsfx&a=team&c=distribution">'.$order['stitle'].'</a>'.lang("plugin/aljbdx","function_core_php_2"),array('from_idtype'  => 'aljsfx','from_id' => $order['uid']));
        }
        if($fxinfo['second_leader_uid']>0) {//��������ID
            notification_add($fxinfo['second_leader_uid'], 'system',lang("plugin/aljbdx","function_core_php_7").$order['username'].lang("plugin/aljbdx","function_core_php_3").'<a href="plugin.php?id=aljsfx&a=team&c=distribution">'.$order['stitle'].'</a>'.lang("plugin/aljbdx","function_core_php_4"),array('from_idtype'  => 'aljsfx','from_id' => $order['uid']));
        }
        if($fxinfo['third_leader_uid']>0) {//��������ID
            notification_add($fxinfo['third_leader_uid'], 'system',lang("plugin/aljbdx","function_core_php_7").$order['username'].lang("plugin/aljbdx","function_core_php_5").'<a href="plugin.php?id=aljsfx&a=team&c=distribution">'.$order['stitle'].'</a>'.lang("plugin/aljbdx","function_core_php_6"),array('from_idtype'  => 'aljsfx','from_id' => $order['uid']));
        }
    }
}
/*
 * ȡ�����˿���ӿ��
 */
function gaddnum($order){
    $orderlist = DB::fetch_all('select * from %t where orderid=%s',array('aljbd_goods_order_list',$order['orderid']));
    foreach($orderlist as $k => $v){
        DB::query('update %t set amount=amount+%d where id=%d', array('aljbd_goods',$v['num'],$v['goods_id']));
        $goods=C::t('#aljbd#aljbd_goods')->fetch($v['goods_id']);
        if($goods['attr_sku']){
            $attr_sku = unserialize($goods['attr_sku']);
            foreach($attr_sku as $sk => $sv){
                if($v['path'] == $sv['path']){
                    $attr_sku[$sk]['stock'] = $attr_sku[$sk]['stock']+$v['num'];
                }
            }
            C::t('#aljbd#aljbd_goods')->update($v['goods_id'],array('attr_sku'=>serialize($attr_sku)));
            unset($attr_sku);
            unset($goods);
        }
    }
}
/**
 * ���ֻ��ּ���
 * @param int $pay_integral ���ֽ��
 *
 * @return array()
 */
function integralCalculation($pay_integral=0){
    global $_G;
    $myext = getuserprofile('extcredits'.$_G['cache']['plugin']['aljbdx']['exttype']);
    if($myext<=0){
        return array();
    }
    //��ߵ��ֻ�����
    $allext = $pay_integral*$_G['cache']['plugin']['aljbdx']['proportions'];
    if($myext>$allext){
        $doext = $allext;
        $rmb = sprintf("%.2f",$pay_integral);
    }else{
        //���û���
        $doext = $myext;
        //���ֽ��
        $rmb = sprintf("%.2f",$myext/$_G['cache']['plugin']['aljbdx']['proportions']);
    }
    return array('doext'=>round($doext),'rmb'=>$rmb,'myext'=>$myext);
}
/*
 * �����˷�
 * @param array $goods  type = 1 ��Ʒ��Ϣ type=2 ���ﳵȫ����Ʒid
 * @param array $def_address  Ĭ���ջ���ַ
 * @param array $bdinfo  �̼���Ϣ
 * @param int $num type = 1 ������Ʒ����/���� type =2 ������Ʒ����/��������
 * @param int $type  ���� 1 = �������� 2=���ﳵ
 *
 * @return array()
 */
function farePrice ($goods=array(),$def_address=array(),$bdinfo=array(),$num=1,$type=1) {
    global $_G;
    $province = $def_address['province'];
    
    if($type == 2){//���ﳵ
        $goods_arr = C::t('#aljbd#aljbd_goods')->fetch_all($goods);
        //debug($goods_arr);
        $mb_ids = array();
        //������ͬ�˷�ģ����Ʒ����/����
        foreach($goods_arr as $g_k => $g_v){
            if($g_v['fare_desc'] == 3){
                if($province){
                    $mb_info = DB::fetch_first('select * from %t where mid=%d and area like %s order by start_price desc limit 1',array('aljmb_fee_template',$g_v['fare'],'%' . $province . '%'));
                    if($mb_info){
                        if($mb_info['type'] == 'bynum'){//����
                            $mb_ids[$g_v['fare']] += $num[$g_v['id']];
                        }else{
                            $mb_ids[$g_v['fare']] += $g_v['weight']*$num[$g_v['id']];
                        }
                    }else{
                        $mb_ids[$g_v['fare']] += 0;
                    }
                }else{
                    $mb_ids[$g_v['fare']] += 0;
                }
            }else if($g_v['fare_desc'] == '999999'){//�Զ����˷�
                if($bdinfo['fare_type'] == 1){
                    $mb_ids['desc_fare'] += $g_v['fare']*$num[$g_v['id']];
                    
                }else if($bdinfo['fare_type'] == 2){
                    $mb_ids['desc_fare'] = ($g_v['fare']*$num[$g_v['id']]) > $mb_ids['desc_fare'] ? ($g_v['fare']*$num[$g_v['id']]) : $mb_ids['desc_fare'];
                }else{
                    $mb_ids['desc_fare'] += $g_v['fare'];
                }
            }else{
                $mb_ids['desc_fare'] += 0;
            }
        }
        if($_G['uid'] == 1){
            //debug($mb_ids);
        }
        
        //������ͬ�˷�ģ���׼�/�ؼ����Ѽ۸�
        foreach($mb_ids as $mb_k => $mb_v){
            
            if($mb_k == 'desc_fare'){//�Զ����˷�
                $fare += $mb_v;
            }else if($province){
                $mb_info = DB::fetch_first('select * from %t where mid=%d and area like %s order by start_price desc limit 1',array('aljmb_fee_template',$mb_k,'%' . $province . '%'));
                
                if($mb_info['start_price'] > 0){
                    if($mb_info['per_start_num']>0 && $mb_v>$mb_info['start_num'] && $mb_info['per_start_price']>0){
                        $per_fare = ceil(($mb_v-$mb_info['start_num'])/$mb_info['per_start_num'])*$mb_info['per_start_price'];
                    }
                    $fare += $mb_info['start_price']+$per_fare;
                }else{
                    $fare += 0;
                }
            }else{
                $fare += 0;
            }
            unset($mb_info);
            unset($per_fare);
        }
        //debug($fare);
    }else{//��������
        if($goods['fare_desc'] == 3){
            if($province){
                $mb_info = DB::fetch_first('select * from %t where mid=%d and area like %s order by start_price desc limit 1',array('aljmb_fee_template',$goods['fare'],'%' . $province . '%'));
                
                if($mb_info['start_price'] > 0){
                    if($mb_info['type'] == 'byweight'){//������
                        $num = $num*$goods['weight'];
                    }
                    if($mb_info['per_start_num']>0 && $num>$mb_info['start_num'] && $mb_info['per_start_price']>0){
                        $per_fare = ceil(($num-$mb_info['start_num'])/$mb_info['per_start_num'])*$mb_info['per_start_price'];
                    }
                    $fare = $mb_info['start_price']+$per_fare;
                }else{
                    $fare = 0;
                }
            }else{
                $fare = 0;
            }
            
        }else{
            if($bdinfo['fare_type'] == 1){
                $fare = $goods[fare]*$num;
            }else{
                $fare = $goods[fare];
            }
        }
    }
    
    return array('fare'=>$fare);
}
//di'.'sm.t'.'aoba'.'o.com
?>