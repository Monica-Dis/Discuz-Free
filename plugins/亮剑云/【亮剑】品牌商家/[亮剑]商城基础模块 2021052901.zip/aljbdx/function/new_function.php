<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
/*
 * �Ź�ȯȡ��������
 */
function randcode ($type,$replacetext='',$order=array(),$goods_id='') {
    global $_G;
    require_once DISCUZ_ROOT .'source/plugin/aljhtx/class/class_aljhtx.php';
    $f_goods_info = C::t('#aljbd#aljbd_goods')->fetch($goods_id);
    $check = DB::result_first('select count(*) from %t where orderid = %s and type=%d',array('aljbd_write_off_code',$order['orderid'],$type));
    if(empty($check)){
        $grouponpw = substr(mt_rand(100000,999999).dgmdate(TIMESTAMP, 'His').$order['uid'],-12);
        $insertarray = array(
            'password' => $grouponpw,
            'orderid' => $order['orderid'],
            'shop_id' => $order['shop_id'],
            'goods_id' => $goods_id,
            'uid' => $order['uid'],
            'name' => $order['stitle'],
            'type' => $type,
            'dateline' => TIMESTAMP
        );
        if($_G['cache']['plugin']['aljtsq']['is_aljtsq'] && $order['store_id']>0){
            $insertarray['store_id'] = $order['store_id'];
            $brand = C::t('#aljtsq#aljtsq_store') -> fetch($order['store_id']);
            $brand['tel'] = $brand['tc_tel'];
        }else{
            $brand = C::t('#aljbd#aljbd') -> fetch($order['shop_id']);
        }
        C::t('#aljbd#aljbd_write_off_code')->insert($insertarray);
        //��������
        if(file_exists(DISCUZ_ROOT ."source/plugin/aljhtx/include/randcode_send_template.php")){
            require_once DISCUZ_ROOT .'source/plugin/aljhtx/include/randcode_send_template.php';
        }
        if($_G['cache']['plugin']['aljdx']){
            include_once DISCUZ_ROOT .'source/plugin/aljdx/function_dx.php';
            $oaddress = unserialize($order['address']);

            if(!$oaddress['mobile']){
                $checkphone = DB::result_first('select mobile from %t where uid = %d',array('common_member_profile',$order['uid']));
                $oaddress['mobile'] = $checkphone;
            }
            if(preg_match('#^\d[\d-]{3,20}\d$#', $oaddress['mobile'])){
                if($type == 1){
                    sendsmsbyvar($oaddress['mobile'],'aljbd','tips_ddcode',array('goodsname' =>cutstr($order['stitle'],20,'...'),'code' => $grouponpw,'tel'=>$brand['tel']));
                }else{
                    sendsmsbyvar($oaddress['mobile'],'aljbd','tips_tgcode',array('goodsname' =>cutstr($order['stitle'],20,'...'),'code' => $grouponpw,'tel'=>$brand['tel']));
                }
            }
        }
        return $grouponpw;
    }
}
?>