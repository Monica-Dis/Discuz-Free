<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_aljbd_goods_order extends discuz_table {

	public function __construct() {
		$this->_table = 'aljbd_goods_order';
		$this->_pk    = 'orderid';

		parent::__construct(); /*dism��taobao��com*/
	}
	public function update_status_by_orderid($orderid=''){
		DB::query('update %t set status=3,deliverydate=%d where orderid=%s',array($this->_table,TIMESTAMP,$orderid));
	}
}
//From: dis'.'m.tao'.'bao.com
?>