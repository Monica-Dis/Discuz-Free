<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_aljgwc extends discuz_table {

	public function __construct() {
		$this->_table = 'aljgwc';
		$this->_pk    = 'id';

		parent::__construct(); /*dism��taobao��com*/
	}

	public function delete_by_uid_shop($uid=0, $shop_id=0,$store_id=0) {
		return DB::query('DELETE FROM %t WHERE uid=%d AND shop_id=%d AND store_id=%d', array($this->_table, $uid, $shop_id,$store_id));
	}

	public function count_by_search($uid='',$store_id=0) {
		$wheresql = 'WHERE 1';
		$wheresql .= $uid ? ' AND '.DB::field('uid', $uid) : '';
		$wheresql .= ' AND '.DB::field('store_id', $store_id);
		return DB::result_first('SELECT COUNT(*) FROM %t %i', array($this->_table, $wheresql));
	}
	public function count_by_uid($uid='',$pid=0,$store_id=0) {
		$wheresql = 'WHERE 1';
		$wheresql .= $uid ? ' AND '.DB::field('uid', $uid) : '';
		$wheresql .= ' AND '.DB::field('store_id', $store_id);
		return DB::result_first('SELECT COUNT(*) FROM %t %i AND pid=%d', array($this->_table, $wheresql,$pid));
	}		
	public function fetch_all_by_displayorder() {
		return DB::fetch_all("SELECT * FROM %t ORDER BY displayorder", array($this->_table), $this->_pk);
	}

	public function fetch_all_by_uid_shop($uid=0, $shop_id=0,$pid=0) {
		return DB::fetch_all("SELECT * FROM %t WHERE uid=%d AND id=%d AND pid=%d and store_id=0", array($this->_table, $uid, $shop_id,$pid));
	}

	public function fetch_all_by_uid($uid=0,$bid='',$pid=0,$store_id=0,$sql='') {
		if($bid){
			$where = $bid ? ' AND '.DB::field('shop_id', $bid) : '';
		}
        
        $where .= ' AND '.DB::field('store_id', $store_id);
        
		$where .= $sql;
		return DB::fetch_all('SELECT * FROM %t WHERE '.DB::field('uid', $uid).' AND pid=%d %i ORDER BY id', array($this->_table,$pid,$where));
	}
	public function fetch_all_by_uid_store($uid=0,$bid='',$pid=0,$store_id=0,$sql='') {
		if($bid){
			$where = $bid ? ' AND '.DB::field('shop_id', $bid) : '';
		}
        if($store_id){
			$where .= $store_id ? ' AND '.DB::field('store_id', $store_id) : '';
		}
		$where .= $sql;
		return DB::fetch_all('SELECT * FROM %t WHERE '.DB::field('uid', $uid).' AND pid=%d %i ORDER BY id', array($this->_table,$pid,$where));
	}

	public function fetch_all_by_goods_id($goods_id=0, $uid=0,$pid=0) {
		return DB::fetch_all('SELECT * FROM %t WHERE '.DB::field('goods_id', $goods_id).' AND '.DB::field('uid', $uid).' AND '.DB::field('pid', $pid), array($this->_table));
	}

	public function fetch_all() {
		return DB::fetch_all("SELECT * FROM %t ORDER BY displayorder", array($this->_table), $this->_pk);
	}

	public function increase($cart_id=0, $setarr='') {
		$sql = array();
		$allowkey = array('num');
		foreach($setarr as $key => $value) {
			if(($value = intval($value)) && in_array($key, $allowkey)) {
				$sql[] = "`$key`=`$key`+'$value'";
			}
		}
		$wheresql = DB::field('id', $cart_id);
		if(!empty($sql)){
			return DB::query('UPDATE %t SET %i WHERE %i', array($this->_table, implode(',', $sql), $wheresql));
		}
	}
}
//From: dis'.'m.tao'.'bao.com
?>