<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_aljgwc_refund extends discuz_table {

	public function __construct() {
		$this->_table = 'aljgwc_refund';
		$this->_pk    = 'orderid';

		parent::__construct(); /*dism��taobao��com*/
	}

	public function update_by_uid($uid=0) {
		return DB::query('UPDATE %t SET %i WHERE %i', array($this->_table, implode(',', $sql), $wheresql));
	}

}
//From: dis'.'m.tao'.'bao.com
?>