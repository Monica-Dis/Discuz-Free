<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_aljbd_address extends discuz_table {

	public function __construct() {
		$this->_table = 'aljbd_address';
		$this->_pk    = 'id';

		parent::__construct(); /*dism��taobao��com*/
	}
	public function count_by_uid($uid=0) {
		return DB::result_first('SELECT count(*) FROM %t WHERE UID=%d',array($this->_table, $uid));
	}
	public function fetch_all_by_uid($uid=0) {
		return DB::fetch_all('SELECT * FROM %t WHERE UID=%d order by defaultAddress desc',array($this->_table, $uid));
	}
	public function fetch_all_by_uid_desc($uid=0,$type=0) {
		return DB::fetch_all('SELECT * FROM %t WHERE UID=%d and type=%d order by defaultAddress desc',array($this->_table, $uid,$type));
	}
	public function update_by_uid_defaultAddress($uid=0,$type=0) {
		return DB::query('UPDATE %t SET defaultAddress=0 WHERE uid=%d and type=%d', array($this->_table, $uid,$type));
	}
	public function fetch_by_uid($uid=0,$type=0) {
		return DB::fetch_first('SELECT * FROM %t WHERE UID=%d and defaultAddress=1 and type=%d',array($this->_table, $uid,$type));
	}
	public function fetch_by_uid_addressid($uid=0,$addreesid=0,$type=0) {
		return DB::fetch_first('SELECT * FROM %t WHERE UID=%d and id=%d and type=%d',array($this->_table, $uid,$addreesid,$type));
	}
	public function delete_by_uid_shop($uid=0, $shop_id=0) {
		return DB::query('DELETE FROM %t WHERE uid=%d AND shop_id=%d', array($this->_table, $uid, $shop_id));
	}

	
}
//From: dis'.'m.tao'.'bao.com
?>