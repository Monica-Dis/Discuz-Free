 <?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$subscribe = 1;
if($_G['cache']['plugin']['aljwsq'] && $_G['cache']['plugin']['aljbd']['order_is_follow'] && strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false && $u20181224){
    require_once 'source/plugin/aljwsq/function_core.php';
    $settings_aljqb=C::t('#aljqb#aljqb_paysetting')->range();
    $subscribe = getcookie('subscribe')?intval(getcookie('subscribe')):0;
    if(!$subscribe) {
        $geturl = ltrim('plugin.php?'.$_SERVER['QUERY_STRING'],'/');
        if(!getcookie('wechat_openid')){
            $openidreturnurl = $geturl;
            //$openid = getopenid($settings_aljqb['OAuth']['value'].$openidreturnurl);
            $jsoninfo = lgetoauth2openid($settings_aljqb['OAuth']['value'].$openidreturnurl);
            if($jsoninfo['errcode']){
                unset($_GET['code']);
                $jsoninfo = lgetoauth2openid($settings_aljqb['OAuth']['value'].$openidreturnurl);
            }

            $openid = $jsoninfo['openid'];
            dsetcookie('wechat_openid',$openid);
        }else{
            $openid = getcookie('wechat_openid');
        }

        require_once DISCUZ_ROOT . './source/plugin/aljwsq/mapp_wechatclient.lib.class.php';
        $wechat_client = new WeChatClient($_G['cache']['plugin']['aljwsq']['appid'], $_G['cache']['plugin']['aljwsq']['appsecret']);
        $wechatdata = $wechat_client -> getUserInfoById($openid);

        $wuser = T::ajaxGetCharSet($wechatdata);
        $subscribe = intval($wuser['subscribe']);
        dsetcookie('subscribe',$wuser['subscribe'],86400);
        $ticket = $wechat_client -> getQrcodeTicket(array('expire' => '600','scene_id' => $qrcodename));
        if(!$ticket){
            $wechat_client -> getAccessToken(1,1);
            $ticket = $wechat_client -> getQrcodeTicket(array('expire' => '600','scene_id' => $qrcodename));
        }
        $wx_img_src = WeChatClient::getQrcodeImgUrlByTicket($ticket);
    }
}

if($_G['cache']['plugin']['aljspt']['is_aljspt'] && file_exists("source/plugin/aljht/function/pt_order.php")){
    if(!discuz_process::islocked('autoPtOrderRefund','30')){
        require_once DISCUZ_ROOT . './source/plugin/aljht/function/pt_order.php';
        pt_grouporderstate_auto();
        pt_orderstate_auto();
    }
}
if($_G['cache']['plugin']['aljgwc']){
    $regionlist=C::t('#aljgwc#aljgwc_region')->range();
}

$page = intval($_GET['page']);
$currpage = $page?$page:1;
$perpage = 10;
$start = ($currpage-1)*$perpage;
if($_GET['ord'] == 'store'){
    $bids = DB::fetch_all('select tc_id from %t where tc_uid = %d',array('aljtsq_store',$_G['uid']));
    foreach($bids as $b_id){
        $ids[] = $b_id['tc_id'];
    }
    $bids = implode(',',$ids);
}else{
    $bids = DB::fetch_all('select id from %t where uid = %d',array('aljbd',$_G['uid']));
    foreach($bids as $b_id){
        $ids[] = $b_id['id'];
    }
    $bids = implode(',',$ids);
}
//DB::query("update %t set status=7 WHERE status=1 and submitdate+900 < %i ",array('aljbd_goods_order',TIMESTAMP));//�������ڶ���
$queryorder = DB::fetch_all('select * from %t where status=1 and submitdate+%d < %i and pid=0',array('aljbd_goods_order',$overtime,TIMESTAMP));
foreach ($queryorder as $qok => $qov){
    //�������ڶ���
    if(DB::query("update %t set status=7 WHERE status=1 and orderid=%s ",array('aljbd_goods_order',$qov['orderid']))){
        $exttype = $order_cart['ext'] > 0 ? $order_cart['ext'] : $_G['cache']['plugin']['aljbdx']['exttype'];
        if($qov['pay_integral']>0 && $qov['pay_ext']>0){
            updatemembercount(
                $qov['uid'],
                array($exttype => $qov['pay_ext']),
                '',
                '',
                '',
                '',
                '&#21462;&#28040;&#35746;&#21333;&#36864;&#36824;&#31215;&#20998;',
                '&#21462;&#28040;&#35746;&#21333;&#36864;&#36824;&#25269;&#29616;&#31215;&#20998;' . $qov['pay_ext'] . $_G['setting']['extcredits'][$exttype]['title'] . '&#44;&#35746;&#21333;&#21495;&#65306;' . $qov['orderid']);
        }
        gaddnum($qov);
    }

}
$conn[] ='aljbd_goods_order';

$where = 'where 1 and pid = 0 ';
if($_GET['mtype'] == 'pt'){
    $where .= ' and commodity_type = 2 ';
    if($_GET['status'] == 2){
        $where .= ' and amount != 1 ';
    }else if($_GET['status'] == 20){
        $where .= ' and amount = 1 ';
        $_GET['status'] = 2;
    }
}
if($_GET['ol'] == 'yes'){
    $where .= ' and uid = %d';
    $conn[] = $_GET['uid'] && $_GET['ol'] == 'yes' ? $_GET['uid'] : $_G['uid'];
}else{
    if($_GET['ord'] == 'dianp'){
        if(is_array($ids) && !$_GET['bid']){
            $where .= ' and shop_id in(%i) and store_id=0';
            $conn[] = $bids;
        }else{
            $where .= ' and shop_id = %d and store_id=0';
            $conn[] = $_GET['bid'];
        }
    }elseif($_GET['ord'] == 'ge'){
        $where .= ' and uid = %d';
        $conn[] = $_G['uid'];
    }elseif($_GET['ord'] == 'store'){
        if(is_array($ids) && !$_GET['store_id']){
            $where .= ' and store_id in(%i) and order_type != 3';
            $conn[] = $bids;
        }else{
            $where .= ' and store_id = %d  and order_type != 3';
            $conn[] = $_GET['store_id'];
        }
    }else{
        if(!in_array($_G['groupid'],$admingroups)){
            if($_GET['ord'] == 'dianp'){
                $where .= ' and shop_id in(%i) and store_id=0';
                $conn[] = $bids;
            }else{
                $where .= ' and uid = %d';
                $conn[] = $_G['uid'];
            }
        }else if(!$_G['cache']['plugin']['aljbdx']['user_order_type'] && $_GET['ord'] != 'admin'){
            $where .= ' and uid = %d';
            $conn[] = $_G['uid'];
        }
    }
}


if($_GET['status']){
	
	$status = intval($_GET['status']);
	if($status == 99){
			$where .= ' and status > %d';
			$conn[] = 1;
	}else{
		$where .= ' and status = %d';
		$conn[] = $status;
	}
}
$keyword = stripsearchkey($_GET['keyword']);
$keyword = '%'.$keyword.'%';

if($_GET['order_good'] == 'order_id'){
	if($_GET['keyword']){
		$where .= ' and orderid like %s';
		$conn[] = $keyword;
	}
}elseif($_GET['order_good'] == 'product_name'){
	if($_GET['keyword']){
		$where .= ' and stitle like %s';
		$conn[] = $keyword;
	}
}elseif($_GET['order_good'] == 'user_name'){
	if($_GET['keyword']){
		$where.=" and username like %s";
		$conn[] = $keyword;
	}
}elseif($_GET['order_good'] == 'shop_id'){
	if($_GET['keyword']){
		$conn[] = stripsearchkey($_GET['keyword']);
		$where.=" and shop_id = %d";
	}
}else if($_GET['order_good'] == 'remarks'){
    $conn[] ='%' . $keyword . '%';
    $where.=" and remarks like %s";
}else if($_GET['order_good'] == 'buyer'){
    $conn[] ='%' . $keyword . '%';
    $where.=" and buyer like %s";
}else if($_GET['order_good'] == 'address'){
    $conn[] ='%' . $keyword . '%';
    $where.=" and address like %s";
}else{
	if($_GET['keyword']){
        if(is_numeric($_GET['keyword'])){
            $where.=" and uid = %d ";
            $conn[] = intval($_GET['keyword']);
        }else{
            $where.=" and (orderid like %s or stitle like %s  or username like %s )";
            $conn[] = $keyword;
            $conn[] = $keyword;
            $conn[] = $keyword;
        }
	}
}


$num = DB::result_first('select count(*) from %t '.$where,$conn);
$start=($currpage-1)*$perpage;
$where .= ' order by submitdate desc';
$where .= ' limit %d,%d';
$conn[] = $start;
$conn[] = $perpage;

$orderlist = DB::fetch_all('select * from %t '.$where,$conn);

$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=orderlist&ord='.$_GET['ord'].'&status='.$_GET['status'].'&keyword='.$_GET['keyword'].'&order_good='.$_GET['order_good'], 0, 11, false, false);

$navtitle = '&#35746;&#21333;&#31649;&#29702;';
$metakeywords =  $bd['other']?$bd['other']:$_G['cache']['plugin']['aljbd']['keywords'];
$metadescription = $_G['cache']['plugin']['aljbd']['description'];
if($_GET['ajax'] == 'yes'){
    $max = ceil($num/$perpage);

    if($currpage == 1){
        $max_page ='<input type="hidden" id="max-page" value="'.$max.'">';
    }

    if($currpage == $max){
        $mes = '<div class="c_click_see" id="more" style="background: none;float: left;">'.$aljbdlang['php']['No_more_data'].'</div>';
    }
    include template('aljbdx:order/ajaxOrderList');
}else{
    include template('aljbdx:order/orderlist_new');
}

function gaddnum($order){
    global $_G;
    $orderlist = DB::fetch_all('select * from %t where orderid=%s',array('aljbd_goods_order_list',$order['orderid']));
    foreach($orderlist as $k => $v){
        DB::query('update %t set amount=amount+%d where id=%d', array('aljbd_goods',$v['num'],$v['goods_id']));
        $goods=C::t('#aljbd#aljbd_goods')->fetch($v['goods_id']);
        if($goods['attr_sku']){
            $attr_sku = unserialize($goods['attr_sku']);
            foreach($attr_sku as $sk => $sv){
                if($v['path'] == $sv['path']){
                    $attr_sku[$sk]['stock'] = $attr_sku[$sk]['stock']+$v['num'];
                }
            }
            C::t('#aljbd#aljbd_goods')->update($v['goods_id'],array('attr_sku'=>serialize($attr_sku)));
            unset($attr_sku);
            unset($goods);
        }
    }
    if($order['cid'] > 0 && $order['discount'] > 0){
        DB::update('aljsyh_consume_log',array('status'=>1),array('id'=>intval($order['cid']),'status'=>2));
    }
}
//di'.'sm.t'.'aoba'.'o.com
?>