<?php
/**
 * Created by PhpStorm.
 * User: lixinyuan
 * Date: 2017/6/20
 * Time: ����11:11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$ggurl = 'plugin.php?id=aljbd&act=goodview&bid={bid}&gid={goods_id}';
$orderlisturl = 'plugin.php?id=aljbd&act=orderlist';
$aljbdlang['template']  = array(
    'home_page'=>'&#39318;&#39029;',//��ҳ
    'My'=>'&#25105;&#30340;',//�ҵ�
    'search'=>'&#25628;&#32034;',//����
    'goods'=>'&#21830;&#21697;',//��Ʒ
    'whole'=>'&#20840;&#37096;',//ȫ��
    'business'=>'&#21830;&#23478;',//�̼�
    'Buy_immediately'=>'&#31435;&#21363;&#36141;&#20080;',//��������
    'Confirm_the_payment'=>'&#30830;&#35748;&#20184;&#27454;',//ȷ�ϸ���
);
$settings=C::t('#aljbd#aljbd_setting')->range();
$is_openarray = array('iswatermark','is_daohang','alipay','malipay','isextcredit','pic','isgo','isnews','isyouh','ispd','isrewrite','islogo','isqq','ista','sjurl','sj_index_lz','time');
foreach($settings as $k => $v){
    if(in_array($k,$is_openarray)){//�����ж�
        if($v['value'] == 1){
            $_G['cache']['plugin']['aljbd'][$k] = 1;
        }elseif($v['value'] == 2){
            $_G['cache']['plugin']['aljbd'][$k] = 0;
        }
    }else{
        if($v['value']){
            $_G['cache']['plugin']['aljbd'][$k] = htmlspecialchars_decode($v['value']);//ͬ����������ֵ���������б���
        }
    }
}
$fare_desc = array('1'=>'&#21253;&#37038;','2'=>'&#21040;&#20184;');
$admingroups = unserialize($_G['cache']['plugin'][$pluginid]['managegroups']);
$user = C::t('#aljbd#aljbd_user') -> fetch($_G['uid']);

//debug($settings['displaynavs']['value']);
if($settings['displaygoodsnav']['value']){
    $alltype = DB::fetch_all('select * from %t where upid=0 order by displayorder asc limit 0,13',array('aljbd_type_goods'));
}else{
    $alltype = DB::fetch_all('select * from %t where upid=0 order by displayorder asc limit 0,13',array('aljbd_type'));
}
$yindao = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin'][$pluginid] ['yindao']));
foreach($yindao as $key=>$value){
    $arr=explode('|',$value);

    $yd_types[]=$arr;
}
$businesstype = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin'][$pluginid] ['businesstype']));
foreach($businesstype as $key=>$value){
    $arr=explode('=',$value);
    $businesstypearr[$arr[0]]=$arr[1];
}
$mobile_user_9 = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin'][$pluginid] ['mobile_user_9']));
foreach($mobile_user_9 as $key=>$value){
    $arr=explode('|',$value);

    $custom_types[]=$arr;
}
$ress=array(
    'brand_index.html'=>'plugin.php?id=aljbd',
    'brand.html'=>'plugin.php?id=aljbd&act=dianpu',
    'goods.html'=>'plugin.php?id=aljbd&act=goods',
    'notice.html'=>'plugin.php?id=aljbd&act=nlist',
    'consume.html'=>'plugin.php?id=aljbd&act=clist',
);
$index_dh = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin'][$pluginid] ['index_dh']));
foreach($index_dh as $key=>$value){
    $arr=explode('|',$value);
    $index_dh_types[$arr[0]]=$arr[1];
}
if ($_SERVER ['HTTP_X_REWRITE_URL']) {
    $the_uri = isset($_SERVER ['HTTP_X_REWRITE_URL']) ? $_SERVER ['HTTP_X_REWRITE_URL'] : '';
} else {
    $the_uri = isset($_SERVER ['REQUEST_URI']) ? $_SERVER ['REQUEST_URI'] : '';
}
$record1 = C::t('#aljbd#aljbd_setting')->fetch('lazyloadlogo');
$lazyloadlogo = $record1['value'];
if($lazyloadlogo){
    $loading = $lazyloadlogo;
}else{
    $loading = 'source/plugin/aljbd/images/loading.gif';
}

$addrlist = C::t('#aljbdx#aljbd_address')->fetch_all_by_uid_desc($_G['uid']);
if($_G['cache']['plugin']['aljgwc']){
    $regionlist=C::t('#aljgwc#aljgwc_region')->range();
}
//1΢��2֧����5����6����
$paymentarr = array('1' => '&#24494;&#20449;&#25903;&#20184;','2' => '&#25903;&#20184;&#23453;&#25903;&#20184;','3' => '&#65;&#80;&#80;&#24494;&#20449;&#25903;&#20184;','5'=>'&#31215;&#20998;&#25903;&#20184;('.$_G['setting']['extcredits'][$config['ext_aljbd']]['title'].')','6'=>'&#36135;&#21040;&#20184;&#27454;','7'=>'&#38065;&#21253;&#25903;&#20184;');
if($_G['cache']['plugin']['aljbd'] && file_exists("source/plugin/aljbd/include/newparameter.php")){
    require_once 'source/plugin/aljbd/include/newparameter.php';
}
?>