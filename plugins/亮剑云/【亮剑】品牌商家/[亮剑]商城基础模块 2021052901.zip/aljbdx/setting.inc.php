<?php

/*
 * Discuz! x3.4 By DisM.taobao.COM
 * ��ϵQQ:578933760
 *
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$_GET=dhtmlspecialchars($_GET);
$pluginid='aljbdx';
$logoarray = array('logo');
if(submitcheck('formhash')){
	if($_FILES['new_logo']['tmp_name']) {
		$picname = $_FILES['new_logo']['name'];
		$picsize = $_FILES['new_logo']['size'];
	
		if ($picname != "") {
			$type = strtolower(strrchr($picname, '.'));
			if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
				showerror('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#112;&#110;&#103;&#32;&#46;&#103;&#105;&#102;&#22270;&#29255;');
			}
			$rand = rand(100, 999);
			$pics = date("YmdHis") . $rand . $type;
			$new_logo = "source/plugin/".$pluginid."/static/img/". $pics;
			if(@copy($_FILES['new_logo']['tmp_name'], $new_logo)||@move_uploaded_file($_FILES['new_logo']['tmp_name'], $new_logo)){
				@unlink($_FILES['new_logo']['tmp_name']);
			}
		}
	}

	if(empty($new_logo)){
		$new_logo = $_GET['new_logo'];
	}

	
	$record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('new_logo');

	if($_GET['deletenew_logo']){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting') -> delete('new_logo');
		if($record['value']){
			unlink($record['value']);
		}
	}

	if(!$record){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>'new_logo','value'=>$new_logo));
	}else{
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($new_logo,'new_logo');
	}
	unset($new_logo);


	foreach($_GET['settingsnew'] as $k=>$v){
		if(!C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch($k)){
			C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>$k,'value'=>$v));
		}else{
			C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($v,$k);
		}
	}

	cpmsg('&#26356;&#26032;&#25104;&#21151;&#65281;', 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=setting', 'succeed');
}else{
	$new_record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('new_logo');
	$new_logo = $new_record['value'];

	$settings = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->range();
	include template($pluginid.':setting');
}
?>