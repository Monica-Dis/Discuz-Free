<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//start to put your own code 
$sql = <<<EOF
DROP TABLE IF  EXISTS `pre_aljwsq_mapp`;
DROP TABLE IF  EXISTS `pre_aljwsq_mapp_keyword`;
DROP TABLE IF  EXISTS `pre_aljwsq_mapp_log`;
DROP TABLE IF  EXISTS `pre_aljwsq_mapp_user`;
DROP TABLE IF  EXISTS `pre_aljwsq_menu`;
DROP TABLE IF  EXISTS `pre_aljwsq_mapp_action_log`;
EOF;

runquery($sql);
//finish to put your own code
$finish = TRUE;
?>