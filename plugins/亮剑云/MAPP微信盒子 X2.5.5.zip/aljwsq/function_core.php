<?php

/*
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����˵��:MAPP΢�ź��Ӻ��ĺ�����
 */


function sendbindextcredit($uid){
	global $_G;
	$mapp_wechat = unserialize($_G['setting']['mapp_wechat']);
	if($mapp_wechat['allowed']){
		if($mapp_wechat['rewardcredit'] && $mapp_wechat['addcreditnum'] && $uid && !lgetuseraction($uid,'mapp_wechat','sendbindextcredit')){
			luseractionlog($uid,'mapp_wechat','sendbindextcredit',$mapp_wechat['addcreditnum'],$_G['setting']['extcredits'][$mapp_wechat['rewardcredit']]['title']);
			updatemembercount($uid, array($mapp_wechat['rewardcredit'] => $mapp_wechat['addcreditnum']),'','','','','&#32465;&#23450;&#24494;&#20449;','&#39318;&#27425;&#23436;&#25104;&#32465;&#23450;&#24494;&#20449;&#20219;&#21153;&#22870;&#21169;&#31215;&#20998;');
		}

	}
}
function lgetuseraction($uid,$appid = '',$action = ''){
	 return DB::fetch_first('select * from %t where uid = %d and appid = %s and action = %s',array('aljwsq_mapp_action_log',$uid,$appid,$action));
}
function luseractionlog($uid,$appid = '',$action = '',$ext = '',$desc = ''){
	DB::insert('aljwsq_mapp_action_log',array(
		'uid' => $uid,
		'appid' => $appid,
		'action' => $action,
		'dateline' => TIMESTAMP,
		'ext' => $ext,
		'desc' => $desc,
	));
}
function lcreate_avatar($uid,$src){
	$uid = sprintf("%09d", $uid);
	$dir = lmkdir_by_uid($uid);
	$a = dfsockopen($src);
	$tmppic = 'data/attachment/temp/'.random(5).TIMESTAMP.'.jpg';
	file_put_contents($tmppic, $a);
	lthumb($tmppic,$dir.substr($uid,-2).'_avatar_big.jpg','200');
	lthumb($dir.substr($uid,-2).'_avatar_big.jpg',$dir.substr($uid,-2).'_avatar_middle.jpg','120');
	lthumb($dir.substr($uid,-2).'_avatar_middle.jpg',$dir.substr($uid,-2).'_avatar_small.jpg','48');
	@unlink($tmppic);
	DB::update('common_member',array('avatarstatus'=>1),array('uid'=>$uid));
}

function AljSyncAvatar($uid, $avatar) {
	if(!$uid || !$avatar) {
		return false;
	}
	if(!$content = dfsockopen($avatar)) {
		return false;
	}
    
	$tmpFile = DISCUZ_ROOT.'./data/avatar/'.TIMESTAMP.random(6);
	file_put_contents($tmpFile, $content);

	if(!is_file($tmpFile)) {
		return false;
	}
    
	$result = AljuploadUcAvatar::upload($uid, $tmpFile);
	
	
	unlink($tmpFile);

	C::t('common_member')->update($uid, array('avatarstatus'=>'1'));

	return $result;
}

function lthumb($img,$dir,$size){
	$image_size = getimagesize($img);
	$from=imagecreatefromjpeg($img);
	if($image_size[0]>$image_size[1]){
		$w=$size*$image_size[1]/$image_size[0];
		$h=$size;
	}elseif($image_size[0]<$image_size[1]){
		$w=$size;
		$h=$size*$image_size[0]/$image_size[1];
	}else{
		$w=$size;
		$h=$size;
	}
	$new=imagecreatetruecolor($w,$h);
	imagecopyresized($new,$from,0,0,0,0,$w,$h,$image_size[0],$image_size[1]);
	imagejpeg($new,$dir);
}

function lmkdir_by_uid($uid, $dir = './uc_server/data/avatar/') {
	$uid = sprintf("%09d", $uid);
	$dir1 = substr($uid, 0, 3);
	$dir2 = substr($uid, 3, 2);
	$dir3 = substr($uid, 5, 2);
	!is_dir($dir.'/'.$dir1) && mkdir($dir.'/'.$dir1, 0777);
	!is_dir($dir.'/'.$dir1.'/'.$dir2) && mkdir($dir.'/'.$dir1.'/'.$dir2, 0777);
	!is_dir($dir.'/'.$dir1.'/'.$dir2.'/'.$dir3) && mkdir($dir.'/'.$dir1.'/'.$dir2.'/'.$dir3, 0777);
	return $dir.'/'.$dir1.'/'.$dir2.'/'.$dir3.'/';
}
function lgetoauth2openid($redirectUrl){
	global $_G;
	$config = $_G['cache']['plugin']['aljwsq'];
	if (!isset($_GET['code'])){
		$url = lcreateOauthUrlForCodeNew($redirectUrl.'&rand='.TIMESTAMP);
		header("Location: $url");
//debug($url);
	}else{
		$code = $_GET['code'];
	}
	$url="https://api.weixin.qq.com/sns/oauth2/access_token?appid=".$config['appid']."&secret=".$config['appsecret']."&code=$code&grant_type=authorization_code";
	$result = dfsockopen($url);
	$jsoninfo = json_decode($result, true);
	return $jsoninfo;

}
function lcreateOauthUrlForCodeNew($redirectUrl){
	global $_G;
	$config = $_G['cache']['plugin']['aljwsq'];
	$urlObj["appid"] = $config['appid'];
	$urlObj["redirect_uri"] = "$redirectUrl";
	$urlObj["response_type"] = "code";
	$urlObj["scope"] = "snsapi_userinfo";
	$urlObj["state"] = "STATE"."#wechat_redirect";
	$bizString = lformatBizQueryParaMapNew($urlObj, true);

	return "https://open.weixin.qq.com/connect/oauth2/authorize?".$bizString;
}
function lformatBizQueryParaMapNew($paraMap, $urlencode = ''){
	$buff = "";
	ksort($paraMap);
	foreach ($paraMap as $k => $v)
	{
		if($urlencode)
		{
		   $v = urlencode($v);
		}
		$buff .= $k . "=" . $v . "&";
	}
	return $buff;
}
function lgetwechatuserinfo($openid, $access_token) {
    $url = "https://api.weixin.qq.com/sns/userinfo?access_token=$access_token&openid=$openid&lang=zh_CN";
    $result = dfsockopen($url);
    $wuser = json_decode($result, true);
    return $wuser;
}
function lgetwuserinfo($openid) {
    $aljwsq_config = array();
	$plugin_aljwsq = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljwsq'));
	$tmp_aljwsq_config = DB::fetch_all('select * from %t where  pluginid = %s',array('common_pluginvar',$plugin_aljwsq['pluginid']));
	foreach($tmp_aljwsq_config as $value){
		$aljwsq_config[$value['variable']] = $value['value'];
	}
	require_once DISCUZ_ROOT . './source/plugin/aljwsq/mapp_wechatclient.lib.class.php';
	$wechat_client = new WeChatClient($aljwsq_config['appid'], $aljwsq_config['appsecret']);
	$wuser = $wechat_client -> getUserInfoById($openid);
    return $wuser;
}
function lwechat_register($username, $return = 0, $groupid = 0,$defaultpassword = '',$news = '') {
	global $_G;
	if(!$username) {
		return;
	}
	loaducenter();
	$groupid = $news['fid'];
	$pwd = 'PW'.random(6);
	if($defaultpassword){
		$pwd = $defaultpassword;
	}
	$password = md5($pwd);
	$email = 'wechat_'.strtolower(random(10)).'@null.null';

	$usernamelen = dstrlen($username);
	if($usernamelen < 4  || uc_user_checkname($username)<0) {
		$username = random(6);
	}
	if($usernamelen > 15) {
		$username = random(6);
	}

	$censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';

	if($_G['setting']['censoruser'] && @preg_match($censorexp, $username)) {
		if(!$return) {
			return lang('message', 'profile_username_protect');
		} else {
			return 'Registration failed. Please try again!';
		}
	}



	loadcache('ipctrl');
	if($_G['cache']['ipctrl']['ipregctrl']) {
		foreach(explode("\n", $_G['cache']['ipctrl']['ipregctrl']) as $ctrlip) {
			if(preg_match("/^(".preg_quote(($ctrlip = trim($ctrlip)), '/').")/", $_G['clientip'])) {
				$ctrlip = $ctrlip.'%';
				$_G['setting']['regctrl'] = $_G['setting']['ipregctrltime'];
				break;
			} else {
				$ctrlip = $_G['clientip'];
			}
		}
	} else {
		$ctrlip = $_G['clientip'];
	}

	if($_G['setting']['regctrl']) {
		if(C::t('common_regip')->count_by_ip_dateline($ctrlip, $_G['timestamp']-$_G['setting']['regctrl']*3600)) {
			if(!$return) {
				//return str_replace('{regctrl}',$_G['setting']['ipregctrltime'],lang('message', 'register_ctrl'));
			} else {
				return 'Registration failed. Please try again!';
			}
		}
	}

	$setregip = null;
	if($_G['setting']['regfloodctrl']) {
		$regip = C::t('common_regip')->fetch_by_ip_dateline($_G['clientip'], $_G['timestamp']-86400);
		if($regip) {
			if($regip['count'] >= $_G['setting']['regfloodctrl']) {
				if(!$return) {
					//return lang('message', 'register_flood_ctrl');
				} else {
					return;
				}
			} else {
				$setregip = 1;
			}
		} else {
			$setregip = 2;
		}
	}

	if($setregip !== null) {
		if($setregip == 1) {
			C::t('common_regip')->update_count_by_ip($_G['clientip']);
		} else {
			C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => 1, 'dateline' => $_G['timestamp']));
		}
	}

	$uid = uc_user_register(addslashes($username), $pwd, $email, '', '', $_G['clientip']);
	if($uid <= 0) {
		if(!$return) {
			if($uid == -1) {
				return lang('message', 'profile_username_illegal');
			} elseif($uid == -2) {
				return lang('message', 'profile_username_protect');
			} elseif($uid == -3) {
				return lang('message', 'profile_username_duplicate');
			} elseif($uid == -4) {
				return lang('message', 'profile_email_illegal');
			} elseif($uid == -5) {
				return lang('message', 'profile_email_domain_illegal');
			} elseif($uid == -6) {
				return lang('message', 'profile_email_duplicate');
			} else {
				return lang('message', 'undefined_action');
			}
		} else {
			return 'Registration failed. Please try again!';
		}
	}

	$init_arr = array('credits' => explode(',', $_G['setting']['initcredits']));
	C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);

	if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
		C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72)*3600);
		if($_G['setting']['regctrl']) {
			C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
		}
	}

	if($_G['setting']['regverify'] == 2) {
		C::t('common_member_validate')->insert(array(
			'uid' => $uid,
			'submitdate' => $_G['timestamp'],
			'moddate' => 0,
			'admin' => '',
			'submittimes' => 1,
			'status' => 0,
			'message' => '',
			'remark' => '',
		), false, true);
		manage_addnotify('verifyuser');
	}

	//ͳ��
	include_once libfile('function/stat');
	updatestat('register');
	luseractionlog($uid,'mapp_wechat','register');
	return array(
		'uid' => $uid,
		'username' => $username,
		'password' => $pwd,
		'groupid' => $groupid,
	);
}
function match_emoji(array $match) {
    return strlen($match[0]) >= 4 ? '' : $match[0];
}
function removeEmoji($text) {
    $str = preg_replace_callback( '/./u', 'match_emoji', $text);
    $str = diconv($str, 'utf-8', 'gbk');
    $str = diconv($str, 'gbk', 'utf-8');
    $str = str_replace('%20','',$str);
    $str = str_replace('%27','',$str);
    $str = str_replace('%2527','',$str);
    $str = str_replace('*','',$str);
    $str = str_replace('"','&quot;',$str);
    $str = str_replace("'",'',$str);
    $str = str_replace('"','',$str);
    $str = str_replace(';','',$str);
    $str = str_replace('<','&lt;',$str);
    $str = str_replace('>','&gt;',$str);
    $str = str_replace("{",'',$str);
    $str = str_replace('}','',$str);
    $str = str_replace('\\','',$str);
    $str = preg_replace('# #','',$str);
    return $str;
}
function qianfan_login($user = array(), $wuser = array()){
    if(DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','qianfan')) && $wuser['unionid']){
        $qianfan_user = DB::fetch_first('SELECT * FROM %t WHERE unionid=%s', array('thirdbind', $wuser['unionid']));
        $common_member_user = getuserbyuid($qianfan_user['uid']);
        if($qianfan_user){
            if(DB::fetch_first('SELECT * FROM %t WHERE openid=%s', array('aljwsq_mapp_user', $wuser['openid']))){
                C::t('#aljwsq#aljwsq_mapp_user')->update($wuser['openid'], array(
                    'username' => $common_member_user['username'],
                    'uid' => $common_member_user['uid'],
                    'bindtime' => TIMESTAMP,
                    'subscribe' => $wuser['subscribe'],
                    'subscribe_time' => $wuser['subscribe_time'],
                    'unionid' =>$wuser['unionid']
                ));
            }else{
                C::t('#aljwsq#aljwsq_mapp_user')->insert(array(
                    'uid' => $common_member_user['uid'],
                    'username' => $common_member_user['username'],
                    'openid' => $wuser['openid'],
                    'bindtime' => TIMESTAMP,
                    'subscribe' => $wuser['subscribe'],
                    'subscribe_time' => $wuser['subscribe_time'],
                    'lasttime' => TIMESTAMP,
                    'unionid' =>$wuser['unionid']
                ));
            }
        }else{
            if($user){
                $qianfan_user = DB::fetch_first('select * from %t where uid=%d',array('thirdbind',$user['uid']));
                if($qianfan_user['uid']){
                    if(empty($qianfan_user['unionid'])){
                        DB::query('update %t set unionid=%s where uid=%d',array('thirdbind',$wuser['unionid'],$user['uid']));
                    }
                }else{
                    DB::insert('thirdbind', array(
                        'uid' => $user['uid'],
                        'nickname' => $wuser['nickname'],
                        'unionid' => $wuser['unionid'],
                        'weibotype' => 'wechat',
                        'dateline' => TIMESTAMP,
                        'openid' => '',
                    ));
                }
            }
        }
    }
    return $user;
}

class AljuploadUcAvatar {

	public static function upload($uid, $localFile) {

		global $_G;
		if(!$uid || !$localFile) {
			return false;
		}

		list($width, $height, $type, $attr) = getimagesize($localFile);
		if(!$width) {
			return false;
		}

		if($width < 10 || $height < 10 || $type == 4) {
			return false;
		}

		$imageType = array(1 => '.gif', 2 => '.jpg', 3 => '.png');
		$fileType = $imgType[$type];
		if(!$fileType) {
			$fileType = '.jpg';
		}
		$avatarPath = $_G['setting']['attachdir'];
		$tmpAvatar = $avatarPath.'./temp/upload'.$uid.$fileType;
		file_exists($tmpAvatar) && @unlink($tmpAvatar);
		file_put_contents($tmpAvatar, file_get_contents($localFile));

		if(!is_file($tmpAvatar)) {
			return false;
		}

		$tmpAvatarBig = './temp/upload'.$uid.'big'.$fileType;
		$tmpAvatarMiddle = './temp/upload'.$uid.'middle'.$fileType;
		$tmpAvatarSmall = './temp/upload'.$uid.'small'.$fileType;
        require_once('./source/class/class_image.php');
		$image = new image;
		if($image->Thumb($tmpAvatar, $tmpAvatarBig, 200, 250, 1) <= 0) {
			return false;
		}
		if($image->Thumb($tmpAvatar, $tmpAvatarMiddle, 120, 120, 1) <= 0) {
			return false;
		}
		if($image->Thumb($tmpAvatar, $tmpAvatarSmall, 48, 48, 2) <= 0) {
			return false;
		}

		$tmpAvatarBig = $avatarPath.$tmpAvatarBig;
		$tmpAvatarMiddle = $avatarPath.$tmpAvatarMiddle;
		$tmpAvatarSmall = $avatarPath.$tmpAvatarSmall;

		$avatar1 = self::byte2hex(file_get_contents($tmpAvatarBig));
		$avatar2 = self::byte2hex(file_get_contents($tmpAvatarMiddle));
		$avatar3 = self::byte2hex(file_get_contents($tmpAvatarSmall));

		$extra = '&avatar1='.$avatar1.'&avatar2='.$avatar2.'&avatar3='.$avatar3;
		$result = self::uc_api_post_ex('user', 'rectavatar', array('uid' => $uid), $extra);
		@unlink($tmpAvatar);
		@unlink($tmpAvatarBig);
		@unlink($tmpAvatarMiddle);
		@unlink($tmpAvatarSmall);

		return true;
	}

	public static function byte2hex($string) {
		$buffer = '';
		$value = unpack('H*', $string);
		$value = str_split($value[1], 2);
		$b = '';
		foreach($value as $k => $v) {
			$b .= strtoupper($v);
		}

		return $b;
	}

	public static function uc_api_post_ex($module, $action, $arg = array(), $extra = '') {
		$s = $sep = '';
		foreach($arg as $k => $v) {
			$k = urlencode($k);
			if(is_array($v)) {
				$s2 = $sep2 = '';
				foreach($v as $k2 => $v2) {
					$k2 = urlencode($k2);
					$s2 .= "$sep2{$k}[$k2]=".urlencode(uc_stripslashes($v2));
					$sep2 = '&';
				}
				$s .= $sep.$s2;
			} else {
				$s .= "$sep$k=".urlencode(uc_stripslashes($v));
			}
			$sep = '&';
		}
		$postdata = uc_api_requestdata($module, $action, $s, $extra);
		
		return uc_fopen2(UC_API.'/index.php', 500000, $postdata, '', TRUE, UC_IP, 20);
	}
}
//d'.'is'.'m.ta'.'obao.com
?>
