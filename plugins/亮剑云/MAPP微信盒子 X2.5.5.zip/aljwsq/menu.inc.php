<?php

/*
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


$config = array();
foreach ($pluginvars as $key => $val) {
    $config[$key] = $val['value'];
}
if ($_GET['act'] == 'update' && $_GET['formhash'] == formhash()) {
    $appid = $config['appid'];
    $appsecret = $config['appsecret'];
    $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$appid&secret=$appsecret";
    $result = https_request($url);
    //debug((Array)json_decode($result));

    $jsoninfo = json_decode($result, true);
    $access_token = $jsoninfo["access_token"];
    $i = 0;
    $umenus = C::t('#aljwsq#aljwsq_menu')->fetch_all_by_upid_close(0);
    foreach ($umenus as $m) {
        $menus = C::t('#aljwsq#aljwsq_menu')->fetch_all_by_upid_close($m['id']);
        if ($menus) {
            $jsonmenu['button'][$i]['name'] = urlencode(diconv($m['name'], CHARSET, 'UTF-8'));
            foreach ($menus as $menu) {
                if ($menu['type'] == 'click') {
                    $keyurl = 'key';
                } else if($menu['type'] == 'miniprogram'){
                    $keyurl = 'url';
                } else {
                    $keyurl = 'url';
                    if (strpos($menu['keyurl'], 'http://') === false && strpos($menu['keyurl'], 'https://') === false) {
                        $menu['keyurl'] = $_G['siteurl'] . $menu['keyurl'];
                    }
                }
                $jsonmenuarray = array('type' => $menu['type'], 'name' => urlencode(diconv($menu['name'], CHARSET, 'UTF-8')), $keyurl => urlencode(diconv($menu['keyurl'], CHARSET, 'UTF-8')));
                if($menu['type'] == 'miniprogram'){
                    $jsonmenuarray['appid'] = $menu['appid'];
                    $pagepatharray = explode('webVUrl=', $menu['pagepath']);

                    if($pagepatharray['1']){
                        $jsonmenuarray['pagepath'] = $pagepatharray[0].'webVUrl='.urlencode(urlencode($pagepatharray['1']));
                    }else{
                        $jsonmenuarray['pagepath'] = $menu['pagepath'];
                    }
                    unset($pagepatharray);
                }
                $jsonmenu['button'][$i]['sub_button'][] = $jsonmenuarray;
            }
        } else {
            if ($m['type'] == 'click') {
                $keyurl = 'key';
            } else if($m['type'] == 'miniprogram'){
                $keyurl = 'url';
            } else {
                $keyurl = 'url';
                if (strpos($m['keyurl'], 'http://') === false && strpos($m['keyurl'], 'https://') === false) {
                    $m['keyurl'] = $_G['siteurl'] . $m['keyurl'];

                }
            }

            $jsonmenuarray = array('type' => $m['type'], 'name' => urlencode(diconv($m['name'], CHARSET, 'UTF-8')), $keyurl => urlencode(diconv($m['keyurl'], CHARSET, 'UTF-8')));
            if($m['type'] == 'miniprogram'){
                $jsonmenuarray['appid'] = $m['appid'];
                $pagepatharray = explode('webVUrl=', $m['pagepath']);

                if($pagepatharray['1']){
                    $jsonmenuarray['pagepath'] = $pagepatharray[0].'webVUrl='.urlencode(urlencode($pagepatharray['1']));
                }else{
                    $jsonmenuarray['pagepath'] = $m['pagepath'];
                }
                unset($pagepatharray);
            }
            $jsonmenu['button'][$i] = $jsonmenuarray;
        }
        $i++;
    }
    $jsonmenu = stripslashes(urldecode(json_encode($jsonmenu)));
    $url = "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=" . $access_token;
    $result = https_request($url, $jsonmenu);
    $result=(Array)json_decode($result);
    if($result['errmsg']=='ok'){
        cpmsg(lang('plugin/aljwsq', 'menu1'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljwsq&pmod=menu', 'succeed');
    }else{
        cpmsg(lang('plugin/aljwsq', 'menu2').str_replace(':', '-', $result['errmsg']));
    }
} else if ($_GET['act'] == 'add') {
    if (submitcheck('formhash')) {
		$count=C::t('#aljwsq#aljwsq_menu')->count_by_upid($_GET['upid']);
		if($_GET['upid']){
            if($count>=5){
                cpmsg(lang('plugin/aljwsq', 'menu11'),'','error');
            }
        }else{
            if($count>=3){
                cpmsg('&#26368;&#22810;&#21482;&#33021;&#28155;&#21152;&#51;&#20010;&#19968;&#32423;&#33756;&#21333;','','error');
            }
        }

		C::t('#aljwsq#aljwsq_menu')->insert(array(
			'displayorder' => $_GET['displayorder'],
			'upid' => $_GET['upid'],
			'type' => $_GET['type'],
			'name' => $_GET['name'],
            'appid' => $_GET['appid'],
            'pagepath' => $_GET['pagepath'],
			'keyurl' => trim($_GET['keyurl']),
			'dateline' => TIMESTAMP
		));
		cpmsg(lang('plugin/aljwsq', 'menu12'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljwsq&pmod=menu', 'succeed');
	} else {
		$menus = C::t('#aljwsq#aljwsq_menu')->fetch_all_by_upid(0);
		include template('aljwsq:add');
	}
} else if ($_GET['act'] == 'edit') {
    $count=C::t('#aljwsq#aljwsq_menu')->count_by_upid($_GET['upid']);
    $menu = C::t('#aljwsq#aljwsq_menu')->fetch($_GET['mid']);
    if (submitcheck('formhash')) {
        if($_GET['upid']){
            if($count>5){
                cpmsg(lang('plugin/aljwsq', 'menu11'),'','error');
            }
        }else{
            if($count>3){
                cpmsg('&#26368;&#22810;&#21482;&#33021;&#28155;&#21152;&#51;&#20010;&#19968;&#32423;&#33756;&#21333;','','error');
            }
        }
        C::t('#aljwsq#aljwsq_menu')->update($_GET['mid'], array(
            'displayorder' => $_GET['displayorder'],
            'upid' => $_GET['upid'],
            'type' => $_GET['type'],
            'name' => $_GET['name'],
            'appid' => $_GET['appid'],
            'pagepath' => $_GET['pagepath'],
            'keyurl' => trim($_GET['keyurl']),
        ));
        cpmsg(lang('plugin/aljwsq', 'menu3'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljwsq&pmod=menu', 'succeed');
    } else {
        $menus = C::t('#aljwsq#aljwsq_menu')->fetch_all_by_upid(0);
        include template('aljwsq:add');
    }
} else if ($_GET['act'] == 'delete') {
    if($_GET['formhash']==formhash()){
        if ($_GET['mid']) {
            C::t('#aljwsq#aljwsq_menu')->delete($_GET['mid']);
        }
        cpmsg(lang('plugin/aljwsq', 'menu4'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljwsq&pmod=menu', 'succeed');
    }
} else if ($_GET['act'] == 'close') {
    if($_GET['formhash']==formhash()){
        if ($_GET['mid']) {
            $menu = C::t('#aljwsq#aljwsq_menu')->fetch($_GET['mid']);
            if($menu['close']){
                C::t('#aljwsq#aljwsq_menu')->update(array('id' => $_GET['mid']), array('close' => 0));
            }else{
                C::t('#aljwsq#aljwsq_menu')->update(array('id' => $_GET['mid']), array('close' => 1));
            }
        }
        cpmsg('&#25805;&#20316;&#25104;&#21151;', 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljwsq&pmod=menu', 'succeed');
    }
} else {
    $umenus = C::t('#aljwsq#aljwsq_menu')->fetch_all_by_upid(0);
    $menus_tmp = C::t('#aljwsq#aljwsq_menu')->fetch_all();

    foreach($menus_tmp as $k => $v){
        $menus[$v['upid']][] = $v;
    }
    include template('aljwsq:menu');
}
function https_request($url, $data = null) {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
    if (!empty($data)) {
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    }
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($curl);
    curl_close($curl);
    return $output;
}
