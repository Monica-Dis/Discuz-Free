<?php

/*
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljwsq_menu extends discuz_table {

    public function __construct() {

        $this->_table = 'aljwsq_menu';
        $this->_pk = 'id';
        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function count_by_upid($upid) {
        return DB::result_first('select count(*) from %t where upid=%d and upid!=0 order by displayorder desc', array($this->_table, $upid));
    }

    public function fetch_all_by_upid($upid) {
        return DB::fetch_all('select * from %t where upid=%d order by displayorder desc', array($this->_table, $upid));
    }
    public function fetch_all() {
        return DB::fetch_all('select * from %t  order by displayorder desc', array($this->_table));
    }
    
    public function count_by_upid_close($upid) {
        return DB::result_first('select count(*) from %t where close=0 and upid=%d and upid!=0 order by displayorder desc', array($this->_table, $upid));
    }

    public function fetch_all_by_upid_close($upid) {
        return DB::fetch_all('select * from %t where close=0 and upid=%d order by displayorder desc', array($this->_table, $upid));
    }
    public function fetch_all_close() {
        return DB::fetch_all('select * from %t where close=0  order by displayorder desc', array($this->_table));
    }

}
//d'.'is'.'m.ta'.'obao.com
?>