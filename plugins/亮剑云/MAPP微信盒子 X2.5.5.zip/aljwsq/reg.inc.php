<?php

/*
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ���²����http://t.cn/Aiux1Jx1
 * �ͷ�QQ: 190360183
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


if($_GET['appid']){
	$msgtypes = array(
		'mapp_vote' => 'text',
		'mapp_base' => 'text',
		'mapp_template' => 'text',
		'mapp_wechat' => 'text',
		'mapp_liangjian' => 'text',
		'mapp_forum' => 'text',
		'mapp_robot' => 'text',
		'mcard' => 'text',
		'mes' => 'text',
		'mform' => 'text',
		'aljbd' => 'text',
		'm2' => 'text',
	);
	$pluginid = addslashes($_GET['appid']);
	$check = DB::result_first("SELECT count(*) FROM %t WHERE appid=%s",array('aljwsq_mapp',$pluginid));
	if($pluginid && !$check){
		$plugin = DB::fetch_first("SELECT * FROM %t WHERE identifier=%s",array('common_plugin',$pluginid));
		$msgtypes[$pluginid] = $msgtypes[$pluginid]?$msgtypes[$pluginid]:'text';
		C::t('#aljwsq#aljwsq_mapp') -> insert(array(
			'appid' => $pluginid,
			'appname' => $plugin['name'],
			'appid' => $pluginid,
			'msgtypes' => $msgtypes[$pluginid],
			'registertime' => TIMESTAMP,
			'enabled' => 1,
		));
	}
	cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&identifier=aljwsq&pmod=app');
}else{
	include template('aljwsq:reg');
}



?>