<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljwsq_mapp` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `appid` varchar(255) NOT NULL,
  `appname` varchar(255) NOT NULL,
  `msgtypes` char(50) NOT NULL,
  `kwnum` int(10) NOT NULL,
  `registertime` int(10) NOT NULL,
  `resnum` int(10) NOT NULL,
  `enabled` tinyint(3) NOT NULL,
  `displayorder` int(10) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljwsq_mapp_keyword` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `msgtype` varchar(255) NOT NULL,
  `event` char(50) NOT NULL,
  `appid` varchar(255) NOT NULL,
  `appname` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `displayorder` int(10) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljwsq_mapp_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL,
  `msgtype` char(50) NOT NULL,
  `appid` char(50) NOT NULL,
  `openid` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `dateline` int(11) NOT NULL,
  `status` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljwsq_mapp_user` (
  `openid` varchar(255) NOT NULL,
  `app_openid` varchar(255) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `groupid` int(10) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `bindtime` int(10) NOT NULL,
  `sex` tinyint(3) NOT NULL,
  `subscribe` tinyint(3) NOT NULL,
  `city` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `province` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `headimgurl` varchar(255) NOT NULL,
  `unionid` varchar(255) NOT NULL,
  `from` varchar(255) NOT NULL,
  `subscribe_time` int(10) NOT NULL,
  `lasttime` int(10) NOT NULL,
  `last_logintime` int(10) NOT NULL,
  PRIMARY KEY (`openid`),
  KEY `uid` (`uid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljwsq_menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `upid` int(10) NOT NULL,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `appid` varchar(255) NOT NULL,
  `pagepath` varchar(255) NOT NULL,
  `keyurl` varchar(255) NOT NULL,
  `dateline` int(11) NOT NULL,
  `displayorder` int(10) NOT NULL,
  `close` TINYINT(3) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljwsq_mapp_action_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `appid` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `ext` int(10) NOT NULL,
  `desc` varchar(255) NOT NULL,
  `uid` int(10) NOT NULL,
  PRIMARY KEY (`id`)
);
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>