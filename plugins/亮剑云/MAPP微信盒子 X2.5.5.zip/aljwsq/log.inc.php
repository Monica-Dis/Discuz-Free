<?php

/*
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ���²����http://t.cn/Aiux1Jx1
 * ��ϵQQ: 578933760
 * ����˵��:MAPP΢�ź��ӷ�����־
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$act = htmlspecialchars($_GET['act']);
if($act == 'delete'){
	if(is_array($_POST['delete'])) {
		foreach($_POST['delete'] as $id) {
			C::t('#aljwsq#aljwsq_mapp_log')->delete($id);
		}
	}
	cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljwsq&pmod=log');
}else{
	$currpage = $_GET['page'] ? intval($_GET['page']) : 1;
	$perpage = 11;
	$num = C::t('#aljwsq#aljwsq_mapp_log')->count();
	$start = ($currpage - 1) * $perpage;
	$loglist = DB::fetch_all('select * from %t order by id desc limit %d,%d',array('aljwsq_mapp_log',$start,$perpage));
	$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljwsq&pmod=log', 0, 11, false, false);
	include template('aljwsq:log');
}
//From: Dism_taobao-com
?>