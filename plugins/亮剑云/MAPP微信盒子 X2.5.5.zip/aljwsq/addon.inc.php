<?php

/*
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * From: DisM.taobao.Com
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$plugin = DB::fetch_first('select * from %t where identifier = %s', array('common_plugin', 'aljhtx'));
if(empty($plugin)){
    cpmsg('&#35831;&#20808;&#23433;&#35013;&#21830;&#23478;&#21161;&#25163;&#25554;&#20214;');
}
$plugin = DB::fetch_first('select * from %t where identifier = %s and available=1', array('common_plugin', 'aljhtx'));
if(empty($plugin)){
    cpmsg('&#35831;&#20808;&#21551;&#29992;&#21830;&#23478;&#21161;&#25163;&#25554;&#20214;');
}

echo '<iframe style="width:100%;height:100%;min-height:780px;border:none;" src="//dism.taobao.com/?aljwsq/"></iframe>';
exit;
?>