<?php

/*
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ���²����http://t.cn/Aiux1Jx1
 * ��ϵQQ: 578933760
 * ����˵��:MAPP΢�ź�������ƥ��ҳ��
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$act = htmlspecialchars($_GET['act']);
if($act == 'displayorder'){
	if(is_array($_POST['delete'])) {
		foreach($_POST['delete'] as $id) {
			C::t('#aljwsq#aljwsq_mapp_keyword')->delete($id);
		}
	}
	$displayorders = $_GET['displayorder'];
	foreach($displayorders as $k => $displayorder){
		DB::query('update %t set displayorder = %d where id = %d',array('aljwsq_mapp_keyword',$displayorder,$k));
	}
	cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljwsq&pmod=adminkeyword');
}else if($act == 'follow'){
	$kid = intval($_GET['kid']);
	DB::query('update %t set event = %s where id = %d',array('aljwsq_mapp_keyword','subscribe',$kid));
	cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljwsq&pmod=adminkeyword');
}else if($act == 'location'){
	$kid = intval($_GET['kid']);
	DB::query('update %t set event = %s where id = %d',array('aljwsq_mapp_keyword','location',$kid));
	cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljwsq&pmod=adminkeyword');
}else if($act == 'nofollow'){
	$kid = intval($_GET['kid']);
	DB::query("update %t set event = '' where id = %d",array('aljwsq_mapp_keyword',$kid));
	cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljwsq&pmod=adminkeyword');
}else{
	$currpage = $_GET['page'] ? intval($_GET['page']) : 1;
	$perpage = 11;
	$num = C::t('#aljwsq#aljwsq_mapp_keyword')->count();
	$start = ($currpage - 1) * $perpage;
	$keywordlist = DB::fetch_all('select * from %t order by displayorder desc limit %d,%d',array('aljwsq_mapp_keyword',$start,$perpage));
	$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljwsq&pmod=adminkeyword', 0, 11, false, false);
	include template('aljwsq:adminkeyword');
}
//From: Dism_taobao-com
?>