<?php

/*
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ���²����http://t.cn/Aiux1Jx1
 * �ͷ�QQ: 190360183
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$act = htmlspecialchars($_GET['act']);
if($act == 'displayorder'){
	if(is_array($_GET['delete'])) {
		foreach($_GET['delete'] as $id) {
			C::t('#aljwsq#aljwsq_mapp')->delete($id);
		}
	}
	$displayorders = $_GET['displayorder'];
	foreach($displayorders as $k => $displayorder){
		DB::query('update %t set displayorder = %d where id = %d',array('aljwsq_mapp',$displayorder,$k));
	}
	cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljwsq&pmod=app');
}else if($act == 'setenabled'){
	$aid = intval($_GET['aid']);
	if($aid){
		$app = C::t('#aljwsq#aljwsq_mapp') -> fetch($aid);
		if($app['enabled']){
			$value = 0;
		}else{
			$value = 1;
		}
		DB::query('update %t set enabled = %d where id = %d',array('aljwsq_mapp',$value,$aid));
	}
	cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljwsq&pmod=app');
}else{
	$currpage = $_GET['page'] ? intval($_GET['page']) : 1;
	$perpage = 11;
	$num = C::t('#aljwsq#aljwsq_mapp')->count();
	$start = ($currpage - 1) * $perpage;
	$applist = DB::fetch_all('select * from %t order by displayorder desc limit %d,%d',array('aljwsq_mapp',$start,$perpage));
	$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljwsq&pmod=app', 0, 11, false, false);
	include template('aljwsq:app');
}
//From: Dism_taobao-com
?>