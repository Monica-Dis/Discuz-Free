<?php

/*
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ���²����http://t.cn/Aiux1Jx1
 * ��ϵQQ: 578933760
 * ����˵��:MAPP΢�ź��Ӻ������
 */

if (!defined('IN_MAPP_API')) {
    exit('Access Denied');
}


$config = $_G['cache']['plugin']['aljwsq'];
$wechatObj = new mappapi($config['token'],$config);
require_once 'source/plugin/aljwsq/function_core.php';
if (isset($_GET['echostr'])) {
    $wechatObj->valid();
} else {
    $wechatObj->responsemsg();
}

class mappapi {
	private $_token;
	private static $_from_id;
	private static $_my_id;
	private static $_mapp_config;
	public function __construct($token,$config) {
		$this->_token = $token;
		$this->_mapp_config = $config;
	}
    public function valid() {
        $echoStr = $_GET["echostr"];
        //valid signature , option
        if ($this->_checkSignature()) {
            echo $echoStr;
            exit;
        }
    }

    public function responsemsg() {
	    global $_G;
		$config = $this->_mapp_config;
		if (!$this->_checkSignature()) {
			return;
		}
        $postdata = file_get_contents("php://input");

        if($config['key']){
            require_once('source/plugin/aljwsq/wxBizMsgCrypt.php');
            $pc = new WXBizMsgCrypt($this->_token, $config['key'], $config['appid']);
            $decryptMsg = "";  //���ܺ������
            $errCode = $pc->DecryptMsg($_GET['msg_signature'], $_GET['timestamp'], $_GET["nonce"], $postdata, $decryptMsg);
            $postdata = $decryptMsg;
        }
        if (!empty($postdata)) {
            $postObj = simplexml_load_string($postdata, 'SimpleXMLElement', LIBXML_NOCDATA);

            $postObj = $this->_handlePostObj($postObj);
			$content = $postObj['content'];
            if (($postObj['type'] == 'event' && $postObj['event'] == 'scan' && intval($postObj['key'])) || ($postObj['event'] == 'subscribe' && intval($postObj['key']))) {
                if(file_exists('source/plugin/aljhtx/controller/admin/wechat.php')){
                    DB::query('update %t set num = num+1 where scene_id=%d',array('aljhtx_qrcode_wechat',$postObj['key']));
                    $qrcode_wechat = DB::fetch_first('select * from %t where scene_id=%d', array('aljhtx_qrcode_wechat', $postObj['key']));
                    if($qrcode_wechat['mykeyword']){
                        $postObj['content'] = $qrcode_wechat['mykeyword'];
                        $content = $qrcode_wechat['mykeyword'];
                        $postObj['type'] = 'text';
                    }
                }
            }

            if($postObj['type'] == 'event' && ($postObj['event'] == 'scan' || $postObj['event'] == 'subscribe') && strpos($postObj['key'], 'gid') !== false){
				$oss_domain = $_G['cache']['plugin']['aljoss']['cdn_domain'] ? $_G['cache']['plugin']['aljoss']['cdn_domain'] : $_G['cache']['plugin']['aljoss']['domain'];
				$siteurl = $_G['setting']['siteurl'] ? $_G['setting']['siteurl'] : $_G['siteurl'];
				$siteurl = trim($siteurl, '/').'/';
				
                $gids = explode('_',$postObj['key']);
                if($gids[2]>0){
                    $gid = $gids[1].'&d='.$gids[2];
                }else{
                    $gid = str_replace('gid_', '', $postObj['key']);
                }
                if(intval($gid) > 0){
                    DB::query('update %t set num = num+1 where gid=%d', array('aljhtx_qrcode_goods', $gid));
                    
					$goods = DB::fetch_first('select * from %t where id=%d', array('aljbd_goods', $gid));
					if(strpos($goods['pic1'],$oss_domain) !== false){
						$gpic = $goods['pic1'];
					}else{
						$gpic = $siteurl . $goods['pic1'];
					}
                    $news = array(
                        'title' => $goods['name'],
                        'description' => $goods['brief'] ? $goods['brief'] : $config['goods_desc'],
                        'pic' => $gpic,
                        'url' => $siteurl . 'plugin.php?id=aljbd&act=goodview&gid=' . $gid,
                    );
                    $items[] = $news;
                    echo mappapi::getXml4RichMsgByArray($items);
                    exit;
                }
            }

			if(file_exists('source/plugin/mapp_advanced/include/common.inc.php')){
				include 'source/plugin/mapp_advanced/include/common.inc.php';
			}
			if(file_exists('source/plugin/mapp_wechat/include/common.inc.php')){
				include 'source/plugin/mapp_wechat/include/common.inc.php';
			}
			if(file_exists('source/plugin/mapp_template/include/common.inc.php')){
				include 'source/plugin/mapp_template/include/common.inc.php';
			}
			include 'source/plugin/aljwsq/include/common.inc.php';
			if(!$keyword){
				if($postObj['event']){
					$keyword  = DB::fetch_first("select * from %t where event = %s order by displayorder desc",array('aljwsq_mapp_keyword',$postObj['event']));
					if($keyword['name']){
						$postObj['content'] = $keyword['name'];
					}
				}else{
					$keyword  = DB::fetch_first("select * from %t where name = %s order by displayorder desc",array('aljwsq_mapp_keyword',$postObj['content']));
				}
			}
			
			if($postObj['type'] == 'text'){
				C::t('#aljwsq#aljwsq_mapp_log') -> insert(array(
					'content'  => $postObj['content'],
					'dateline' => TIMESTAMP,
					'openid' => self::$_from_id,
					'msgtype' => $MsgType,
				));
			}else if ($postObj['type'] == 'event' && $postObj['event'] == 'subscribe') {
                require_once DISCUZ_ROOT . './source/plugin/aljwsq/mapp_wechatclient.lib.class.php';
                $aljwsq_config = array();
                $plugin_aljwsq = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljwsq'));
                $tmp_aljwsq_config = DB::fetch_all('select * from %t where  pluginid = %s',array('common_pluginvar',$plugin_aljwsq['pluginid']));
                foreach($tmp_aljwsq_config as $value){
                    $aljwsq_config[$value['variable']] = $value['value'];
                }
			    $wechat_client = new WeChatClient($aljwsq_config['appid'], $aljwsq_config['appsecret']);
                $wuser = $wechat_client -> getUserInfoById($postObj['from']);
                $groupid = $wechat_client -> getGroupidByUserid($_GET['openid']);
                $user = C::t('#aljwsq#aljwsq_mapp_user')->fetch($postObj['from']);
                if (!$user) {
                    C::t('#aljwsq#aljwsq_mapp_user')->insert(array(
                        'nickname' => diconv($wuser['nickname'], 'utf-8', CHARSET),
                        'groupid' => $groupid,
                        'sex' => $wuser['sex'],
                        'city' => diconv($wuser['city'], 'utf-8', CHARSET),
                        'unionid' => diconv($wuser['unionid'], 'utf-8', CHARSET),
                        'country' => diconv($wuser['country'], 'utf-8', CHARSET),
                        'province' => diconv($wuser['province'], 'utf-8', CHARSET),
                        'language' => $wuser['language'],
                        'headimgurl' => $wuser['headimgurl'],
                        'openid' => $postObj['from'],
                        'subscribe' => $wuser['subscribe'],
                        'subscribe_time' => $wuser['subscribe_time'],
                        'lasttime' => TIMESTAMP,
                    ));
                }else{
                    C::t('#aljwsq#aljwsq_mapp_user')->update($postObj['from'], array(
                        'nickname' => diconv($wuser['nickname'], 'utf-8', CHARSET),
                        'groupid' => $groupid,
                        'sex' => $wuser['sex'],
                        'city' => diconv($wuser['city'], 'utf-8', CHARSET),
                        'unionid' => diconv($wuser['unionid'], 'utf-8', CHARSET),
                        'country' => diconv($wuser['country'], 'utf-8', CHARSET),
                        'province' => diconv($wuser['province'], 'utf-8', CHARSET),
                        'language' => $wuser['language'],
                        'headimgurl' => $wuser['headimgurl'],
                        'subscribe' => $wuser['subscribe'],
                        'subscribe_time' => $wuser['subscribe_time'],
                        'lasttime' => TIMESTAMP,
                    ));
                }
				C::t('#aljwsq#aljwsq_mapp_log') -> insert(array(
					'content'  => 'subscribe',
					'dateline' => TIMESTAMP,
					'openid' => self::$_from_id,
					'msgtype' => $MsgType,
				));
			}else if($postObj['type'] == 'event' && $postObj['event'] == 'unsubscribe'){
			    DB::query('update %t set subscribe = 0, subscribe_time=0 where openid=%s', array('aljwsq_mapp_user', self::$_from_id));
            }
			
			if($keyword){
				include 'source/plugin/'.$keyword['appid'].'/api/'.$keyword['appid'].'.php';
				$returndata = call_user_func($keyword['appid'],$postObj,$keyword);
			}
			if(empty($returndata)){
				$applist  = DB::fetch_all("select * from %t where FIND_IN_SET(%s,msgtypes) order by displayorder desc",array('aljwsq_mapp',$postObj['type']));
				foreach($applist as $app){
					include 'source/plugin/'.$app['appid'].'/api/'.$app['appid'].'.php';
					$returndata = call_user_func($app['appid'],$postObj);
					if($returndata){
						DB::query("update %t set resnum=resnum+1 where appid=%s",array('aljwsq_mapp',$app['appid']));
						break;
					}
				}
			}
			
			
			if(empty($returndata)){
				if(empty($postObj['event'])){
				    if($config['content']){
                        echo self::getXml4Txt($config['content']);
                        exit;
                    }
				}
			}else{
				echo $returndata;
			}
		}
	}
			
			
            
   private function _handlePostObj($postObj) {
		$MsgType = strtolower((string) $postObj->MsgType);
		$result = array(
		    'from' => self::$_from_id = (string) htmlspecialchars($postObj->FromUserName),
		    'to' => self::$_my_id = (string) htmlspecialchars($postObj->ToUserName),
		    'time' => (int) $postObj->CreateTime,
		    'type' => (string) $MsgType
		);

		if (property_exists($postObj, 'MsgId')) {
			$result['id'] = $postObj->MsgId;
		}

		switch ($result['type']) {
			case 'text':
				$result['content'] = (string) $postObj->Content; // Content ��Ϣ����
				$result['content'] = diconv($result['content'], 'UTF-8', CHARSET);
				break;
			case 'location':
				$result['X'] = (float) $postObj->Location_X; // Location_X ����λ��γ��
				$result['Y'] = (float) $postObj->Location_Y; // Location_Y ����λ�þ���
				$result['S'] = (float) $postObj->Scale;      // Scale ��ͼ���Ŵ�С
				$result['I'] = (string) $postObj->Label;     // Label ����λ����Ϣ
				break;

			case 'image':
				$result['url'] = (string) $postObj->PicUrl;  // PicUrl ͼƬ���ӣ������߿�����HTTP GET��ȡ
				$result['mid'] = (string) $postObj->MediaId; // MediaId ͼƬ��Ϣý��id�����Ե��ö�ý���ļ����ؽӿ���ȡ���ݡ�
				break;

			case 'video':
				$result['mid'] = (string) $postObj->MediaId;      // MediaId ͼƬ��Ϣý��id�����Ե��ö�ý���ļ����ؽӿ���ȡ���ݡ�
				$result['thumbmid'] = (string) $postObj->ThumbMediaId; // ThumbMediaId ��Ƶ��Ϣ����ͼ��ý��id�����Ե��ö�ý���ļ����ؽӿ���ȡ���ݡ�
				break;

			case 'link':
				$result['title'] = (string) $postObj->Title;       // ��Ϣ����
				$result['desc'] = (string) $postObj->Description; // ��Ϣ����
				$result['url'] = (string) $postObj->Url;  // ��Ϣ����
				break;

			case 'voice':
				$result['mid'] = (string) $postObj->MediaId;     // ������Ϣý��id�����Ե��ö�ý���ļ����ؽӿ���ȡ��ý��
				$result['format'] = (string) $postObj->Format;      // ������ʽ��amr
				if (property_exists($postObj, Recognition)) {
					$result['txt'] = (string) $postObj->Recognition; // ����ʶ������UTF8����
				}
				break;

			case 'event':
				$result['event'] = strtolower((string) $postObj->Event);    // �¼����ͣ�subscribe(����)��unsubscribe(ȡ������)��CLICK(�Զ���˵������???
				switch ($result['event']) {

					// case 'unsubscribe': // ȡ������
					case 'subscribe': // ����
					case 'scan': // ɨ���ά��
						if (property_exists($postObj, EventKey)) {
							// ɨ���������ά���¼�
							$result['key'] = str_replace(
								'qrscene_', '', (string) $postObj->EventKey
							); // �¼�KEYֵ��qrscene_Ϊǰ׺������Ϊ��ά��Ĳ���ֵ
							$result['ticket'] = (string) $postObj->Ticket;
						}
						break;

					case 'location': // �ϱ�����λ���¼�
						$result['la'] = (string) $postObj->Latitude;  // ����λ��γ��
						$result['lo'] = (string) $postObj->Longitude; // ����λ�þ���
						$result['p'] = (string) $postObj->Precision; // ����λ�þ���
						break;

					case 'click': // �Զ���˵��¼�
						$result['key'] = (string) $postObj->EventKey; // �¼�KEYֵ�����Զ���˵��ӿ���KEYֵ��Ӧ
						$result['content'] = diconv($result['key'], 'UTF-8', CHARSET);
						$result['type'] = 'text';
						break;
					case 'masssendjobfinish':
						$result['msg_id'] = (string) $postObj->MsgID;
						$result['res_status'] = (string) $postObj->Status;
						$result['res_totalcount'] = (string) $postObj->TotalCount;
						$result['res_filtercount'] = (string) $postObj->FilterCount;
						$result['res_sentcount'] = (string) $postObj->SentCount;
						$result['res_errorcount'] = (string) $postObj->ErrorCount;
						$updatedata = array(
							'res_status' => $result['res_status'],
							'res_totalcount' => $result['res_totalcount'],
							'res_filtercount' => $result['res_filtercount'],
							'res_sentcount' => $result['res_sentcount'],
							'res_errorcount' => $result['res_errorcount'],
							'res_finish_at' => TIMESTAMP
						);
						DB::update('aljwsq_mapp_advanced_masssend', $updatedata, "msg_id='$result[msg_id]'");
				}
		}

		return $result;
	}
   private static function _format2xml($nodes) {
       global $config;
		$xml = '<xml>'
			. '<ToUserName><![CDATA[%s]]></ToUserName>'
			. '<FromUserName><![CDATA[%s]]></FromUserName>'
			. '<CreateTime>%s</CreateTime>'
			. '%s'
			. '</xml>';
		$return = sprintf(
			$xml, self::$_from_id, self::$_my_id, time(), $nodes
		);
		$return = diconv($return, CHARSET, 'UTF-8');
       if($config['key']){
           require_once('source/plugin/aljwsq/wxBizMsgCrypt.php');
           $encryptMsg = ''; //���ܺ������
           $pc = new WXBizMsgCrypt($config['token'], $config['key'], $config['appid']);
           $errCode = $pc->encryptMsg($return, $_GET['timestamp'], $_GET["nonce"], $encryptMsg);
           $return = $encryptMsg;
       }
		return $return;
   }	
   public static function getXml4Txt($txt) {
		$xml = '<MsgType><![CDATA[text]]></MsgType>'
			. '<Content><![CDATA[%s]]></Content>';
		return self::_format2xml(
				sprintf(
					$xml, $txt
				)
		);
	}

	public static function getXml4ImgByMid($mid) {
		$xml = '<MsgType><![CDATA[image]]></MsgType>'
			. '<Image>'
			. '<MediaId><![CDATA[%s]]></MediaId>'
			. '</Image>';
		return self::_format2xml(
				sprintf(
					$xml, $mid
				)
		);
	}

	public static function getXml4VoiceByMid($mid) {
		$xml = '<MsgType><![CDATA[voice]]></MsgType>'
			. '<Voice>'
			. '<MediaId><![CDATA[%s]]></MediaId>'
			. '</Voice>';
		return self::_format2xml(
				sprintf(
					$xml, $mid
				)
		);
	}

	public static function getXml4Customer($kfaccount) {
		$xml = '<MsgType><![CDATA[transfer_customer_service]]></MsgType>';
		if($kfaccount){
			$xml .= '<TransInfo>'
			. '<KfAccount><![CDATA[%s]]></KfAccount>'
			. '</TransInfo>';
			return self::_format2xml(
				sprintf(
					$xml, $kfaccount
				)
			);
		}
		return self::_format2xml(
				sprintf(
					$xml
				)
		);
	}

	public static function getXml4VideoByMid($mid, $title, $desc = '') {
		$desc = '' !== $desc ? $desc : $title;
		$xml = '<MsgType><![CDATA[video]]></MsgType>'
			. '<Video>'
			. '<MediaId><![CDATA[%s]]></MediaId>'
			. '<Title><![CDATA[%s]]></Title>'
			. '<Description><![CDATA[%s]]></Description>'
			. '</Video>';

		return self::_format2xml(
				sprintf(
					$xml, $mid, $title, $desc
				)
		);
	}

	public static function getXml4MusicByUrl($url, $thumbmid, $title, $desc = '', $hqurl = '') {
		$xml = '<MsgType><![CDATA[music]]></MsgType>'
			. '<Music>'
			. '<Title><![CDATA[%s]]></Title>'
			. '<Description><![CDATA[%s]]></Description>'
			. '<MusicUrl><![CDATA[%s]]></MusicUrl>'
			. '<HQMusicUrl><![CDATA[%s]]></HQMusicUrl>'
			//. '<ThumbMediaId><![CDATA[%s]]></ThumbMediaId>'
			. '</Music>';

		return self::_format2xml(
				sprintf(
					$xml, $title, '' === $desc ? $title : $desc, $url, $hqurl ? $hqurl : $url, $thumbmid
				)
		);
	}

	public static function getXml4RichMsgByArray($list) {
		$max = 10;
		$i = 0;
		$ii = count($list);
		$list_xml = '';
		while ($i < $ii && $i < $max) {
			$item = $list[$i++];
			$list_xml .=
				sprintf(
				'<item>'
				. '<Title><![CDATA[%s]]></Title> '
				. '<Description><![CDATA[%s]]></Description>'
				. '<PicUrl><![CDATA[%s]]></PicUrl>'
				. '<Url><![CDATA[%s]]></Url>'
				. '</item>', $item['title'], $item['description'], $item['pic'], $item['url']
			);
		}

		$xml = '<MsgType><![CDATA[news]]></MsgType>'
			. '<ArticleCount>%s</ArticleCount>'
			. '<Articles>%s</Articles>';

		return self::_format2xml(
				sprintf(
					$xml, $i, $list_xml
				)
		);
	}
	public static function getXml4RichMsgByArray2($list) {
		$max = 10;
		$i = 0;
		$ii = count($list);
		$list_xml = '';
		while ($i < $ii && $i < $max) {
			$item = $list[$i++];
			$list_xml .=
				sprintf(
				'<item>'
				. '<Title><![CDATA[%s]]></Title> '
				. '<Description><![CDATA[%s]]></Description>'
				. '<PicUrl><![CDATA[%s]]></PicUrl>'
				. '<Url><![CDATA[%s]]></Url>'
				. '</item>', $item['title'], $item['description'], $item['picurl'], $item['url']
			);
		}

		$xml = '<MsgType><![CDATA[news]]></MsgType>'
			. '<ArticleCount>%s</ArticleCount>'
			. '<Articles>%s</Articles>';

		return self::_format2xml(
				sprintf(
					$xml, $i, $list_xml
				)
		);
	}
	private function _checkSignature() {
		$signature = $_GET["signature"];
		$timestamp = $_GET["timestamp"];
		$nonce = $_GET["nonce"];

		$token = $this->_token;
		$tmpArr = array($token, $timestamp, $nonce);
		sort($tmpArr, SORT_STRING);
		$tmpStr = implode($tmpArr);
		$tmpStr = sha1($tmpStr);

		return $tmpStr == $signature;
	}

}
//d'.'is'.'m.ta'.'obao.com
?>