<?php
	define('DISABLEXSSCHECK',true);
	require '../../../../source/class/class_core.php';
	$discuz = C::app();
	$discuz->init();
  	loadcache('plugin');

	require_once '../../../../source/plugin/aljqb/class/Qbapi.class.php';
	if(file_exists('../../../../source/plugin/aljqb/class/Getdata.class.php')){
		require_once '../../../../source/plugin/aljqb/class/Getdata.class.php';
		$getdata = new Getdata();
	}
	//file_put_contents('d.txt',$key."\r",FILE_APPEND);
	//file_put_contents('d.txt',$_GET['key']."\r",FILE_APPEND);
	$pluginid = 'aljbd';

	$qbapi = new Qbapi();
	$keyarray = array(
		'aljorderid'=> $_GET['aljorderid'],
		'paytime' => $_GET['paytime'],
		'orderid' => $_GET['orderid'],
	);
	if($_GET['key']) {
		$keyarray['key'] = $_G['cache']['plugin']['aljbzj']['qb_key'];
		$key = $qbapi->createKey($keyarray);
		$getkey = $_GET['key'];
	}elseif(file_exists('../../../../source/plugin/aljqb/class/Getdata.class.php')) {
		$appinfo = $getdata->getAppParam();
		$appinfo['posttime']=$_GET['posttime'];
		$key = $getdata->CreateAppSign($appinfo);
		$getkey = $_GET['sign'];
	}
	if($key == $getkey) {
        
        $order = DB::fetch_first('select * from %t where orderid=%s',array('aljbd_goods_order',$_GET['orderid']));
		if($order['status'] == 1){

            $qborder = DB::fetch_first('select * from %t where aljorderid=%s',array('aljqb_payorder',$_GET['aljorderid']));
            if($order['store_id'] > 0){
                C::t('#aljtsq#aljbd_goods_order')->update($_GET['orderid'], array('admin'=>$qborder['trade_mod'],'status' => 2, 'buyer' => $_GET['aljorderid'], 'confirmdate' => $_GET['paytime']));
                C::t('#aljbzj#aljbzj_log')->insert(array(
                    'uid' => $order['uid'],
                    'username' => $order['username'],
                    'store_id' => $order['store_id'],
                    'price' => $order['price'],
                    'addtime' => TIMESTAMP,
                    'paytime' => $_GET['paytime'],
                    'trade_mod' => $qborder['trade_mod'],
                    'orderid' => $_GET['orderid'],
                    'buyer' => $_GET['aljorderid'],
                    'status' => '1',//1 ���ɱ�֤�� 2 �˻ر�֤������ 3�˻سɹ� 4�˻�ʧ��
                ));
                if(DB::fetch_first('select * from %t where uid=%d and store_id=%d',array('aljbzj',$order['uid'],$order['store_id']))){
                    DB::query('update %t set price=price+%i,updatetime=%d where uid=%d and store_id=%d',array('aljbzj',$order['price'],TIMESTAMP,$order['uid'],$order['store_id']));
                }else{
                    C::t('#aljbzj#aljbzj')->insert(array(
                        'uid' => $order['uid'],
                        'username' => $order['username'],
                        'price' => $order['price'],
                        'addtime' => TIMESTAMP,
                        'store_id' => $order['store_id'],
                        'status' => '1'
                    ));
                }
                if($_G['cache']['plugin']['aljtsq']){
                    //ƽ̨����
                    require_once DISCUZ_ROOT . 'source/plugin/aljhtx/class/class_aljhtx.php';
                    T::platformRevenue($order,$order['stitle'],$order['price'],'aljbzj');
                }
            }else{
                C::t('#aljgwc#aljbd_goods_order')->update($_GET['orderid'], array('admin'=>$qborder['trade_mod'],'status' => 2, 'buyer' => $_GET['aljorderid'], 'confirmdate' => $_GET['paytime']));
                C::t('#aljbzj#aljbzj_log')->insert(array(
                    'uid' => $order['uid'],
                    'username' => $order['username'],
                    'bid' => $order['shop_id'],
                    'price' => $order['price'],
                    'addtime' => TIMESTAMP,
                    'paytime' => $_GET['paytime'],
                    'trade_mod' => $qborder['trade_mod'],
                    'orderid' => $_GET['orderid'],
                    'buyer' => $_GET['aljorderid'],
                    'status' => '1',//1 ���ɱ�֤�� 2 �˻ر�֤������ 3�˻سɹ� 4�˻�ʧ��
                ));
                if(DB::fetch_first('select * from %t where uid=%d and bid=%d ',array('aljbzj',$order['uid'],$order['shop_id']))){
                    DB::query('update %t set price=price+%i,updatetime=%d where uid=%d and bid=%d ',array('aljbzj',$order['price'],TIMESTAMP,$order['uid'],$order['shop_id']));
                }else{
                    C::t('#aljbzj#aljbzj')->insert(array(
                        'uid' => $order['uid'],
                        'username' => $order['username'],
                        'bid' => $order['shop_id'],
                        'price' => $order['price'],
                        'addtime' => TIMESTAMP,
                        'status' => '1'
                    ));
                }
                //����Ǯ�� +money ����ͳ���ʻ�
                if($_G['cache']['plugin']['aljbdx']['money_uid']>0){
                    $usermoney = getuserbyuid($_G['cache']['plugin']['aljbdx']['money_uid']);
                    $queuearray = array(
                        'app_name' => 'aljbzj',
                        'app_type' => 'aljbzj_add',
                        'app_phone' => '123456789',
                        'app_ip' => $_G['clientip'],
                    );
                    $fxtips = lang("plugin/aljbzj","pay_php_1").'{username}'.lang("plugin/aljbzj","pay_php_2").'{shopname}'.lang("plugin/aljbzj","pay_php_3").'{money}'.lang("plugin/aljbzj","pay_php_4");
                    $bd = C::t('#aljbd#aljbd')->fetch($order['shop_id']);
                    $balancearray = array(
                        'type'=> 'charge',
                        'uid'=>$_G['cache']['plugin']['aljbdx']['money_uid'],
                        'price' => $order['price'],
                        'orderid'=> $_GET['orderid'],
                        'desc'=> str_replace(array('{username}','{shopname}','{money}'),array($order['username'],$bd['name'],$order['price']),$fxtips),
                    );
                    $result_money_uid = $qbapi -> balance($queuearray,$balancearray);
                }
            }
		}
        echo 'success';
        exit;
	}
//From: Dism��taobao��com
?>
