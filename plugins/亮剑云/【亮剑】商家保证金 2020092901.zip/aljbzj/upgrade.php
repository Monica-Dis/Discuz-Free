<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljbzj` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bid` (`bid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbzj_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL,
  `paytime` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `status` int(11) NOT NULL,
  `info` varchar(255) NOT NULL,
  `orderid` char(32) NOT NULL,
  `trade_mod` char(16) NOT NULL,
  `buyer` char(32) NOT NULL,
  `trans_uid` int(11) NOT NULL,
  `trans_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bid` (`bid`)
)
EOF;
runquery($sql);
$aljbzj_store_id = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'store_id\'', array('aljbzj'), true);
if(!$aljbzj_store_id){
$sql = <<<EOF
ALTER TABLE `pre_aljbzj` ADD `store_id` int(11) NOT NULL;
ALTER TABLE `pre_aljbzj` ADD INDEX(`store_id`);
ALTER TABLE `pre_aljbzj_log` ADD `store_id` int(11) NOT NULL;
ALTER TABLE `pre_aljbzj_log` ADD INDEX(`store_id`);
EOF;
runquery($sql);
}
$finish = TRUE;
?>
