<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljbzj_log extends discuz_table{
	public function __construct() {

			$this->_table = 'aljbzj_log';
			$this->_pk    = 'id';

			parent::__construct(); /*Dism_taobao-com*/
	}
	

}




?>