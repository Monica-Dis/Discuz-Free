<?php

/*
 * ���ߣ�����
 * ��ϵQQ:578933760
 *
 */

if (! defined ('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit ('Access Denied');
}

$returnmsgtypes = array(
	'text' => '&#25991;&#26412;&#28040;&#24687;',
	'news' => '&#22270;&#25991;&#28040;&#24687;',
	'image' => '&#22270;&#29255;&#28040;&#24687;',
	'music' => '&#38899;&#20048;&#28040;&#24687;',
	'voice' => '&#35821;&#38899;&#28040;&#24687;',
	'shortvideo' => '&#23567;&#35270;&#39057;&#28040;&#24687;',
	'location' => '&#22320;&#29702;&#20301;&#32622;&#28040;&#24687;',
	'url' => '&#38142;&#25509;&#28040;&#24687;',
);
$msgtypes = array(
    'text' => array(
		'type' => 'text',
		'description' => '&#25991;&#26412;&#28040;&#24687;',
		'msgtype' => 'text',
		'returnmsgtype' => 'text',
		'event' => '',
	),
	'url' => array(
		'type' => 'url',
		'description' => '&#38142;&#25509;&#28040;&#24687;',
		'msgtype' => 'text',
		'returnmsgtype' => 'url',
		'event' => '',
	),
	'music' => array(
		'type' => 'url',
		'description' => '&#38899;&#20048;&#28040;&#24687;',
		'msgtype' => 'text',
		'returnmsgtype' => 'music',
		'event' => '',
	),
	'news' => array(
		'type' => 'url',
		'description' => '&#22270;&#25991;&#28040;&#24687;',
		'msgtype' => 'news',
		'returnmsgtype' => 'news',
		'event' => '',
	),
    'image' => array(
        'type' => 'image',
        'description' => '&#22270;&#29255;&#28040;&#24687;',
        'msgtype' => 'image',
        'returnmsgtype' => 'image',
        'event' => '',
    ),
);
?>