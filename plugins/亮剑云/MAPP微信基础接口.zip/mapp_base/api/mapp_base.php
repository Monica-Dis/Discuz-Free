<?php

/*
 * ����: Discuz!����������
 * ����֧��: http://www.dzx30.com
 * ��ϵQQ: 578933760
 * ����˵��:MAPP΢�ź��Ӻ���API
 */

function mapp_base($postObj){
	global $_G;
	$_G['defaultpic'] = $_G[siteurl].'source/plugin/mapp_base/images/default.jpg';
	$content = trim($postObj['content']);
	$news = DB::fetch_first('select * from %t where mykeyword = %s and status>0 order by displayorder desc',array('aljwsq_mapp_base_keyword',$content));
	if($news['threadnum']>9 || empty($news['threadnum'])){
		$news['threadnum'] = 9;
	}
	if($news['type'] == 'text'){
		return  mappapi::getXml4Txt($news['description']);
	}else if($news['type'] == 'image'){
        return  mappapi::getXml4ImgByMid($news['url']);
    }else if($news['type'] == 'url'){
		$news['description'] = $news['description'] . '<a href="' . $news['url'] . '">' . $news['title'] . '</a>';
		return  mappapi::getXml4Txt($news['description']);
	}else if($news['type'] == 'music'){
		$news['bindkeyword'] = trim($news['bindkeyword']);
		$news['url'] = trim($news['url']);
		//return  mappapi::getXml4Txt($news['url']);
		return  mappapi::getXml4MusicByUrl($news['bindkeyword'],'',$news['title'],$news['description'],$news['url']);
	}else if($news['type'] == 'news'){
		$items = DB::fetch_all('select * from %t where upid = %d',array('aljwsq_mapp_base_keyword',$news['id']));
		if($items){
			foreach($items as $k => $item){
				if($item){
					$items[$k]['picurl'] = $_G['siteurl'].$item['picurl'];
				}
			}
		}
		if($news['picurl']){
			$news['picurl'] = $_G['siteurl'].$news['picurl'];
		}
		$items[] = $news;
		$items = array_reverse($items);
	}
	if($items){
		DB::query("update %t set resnum=resnum+1 where mykeyword=%s",array('aljwsq_mapp_base_keyword',$content));
		if($postObj['getdata']){
			return  $items;
		}else{
			return  mappapi::getXml4RichMsgByArray2($items);
		}
		
		//return  mappapi::getXml4Txt($news['fid']);
	}else{
		return false;
	}
}
?>