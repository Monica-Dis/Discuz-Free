<?php

/*
 * ���ߣ�����
 * ��ϵQQ:578933760
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if ($_GET['kid']) {
    $reply = C::t('#mapp_base#aljwsq_mapp_base_keyword')->fetch($_GET['kid']);
}

if($_GET['upid']){
	$upid = intval($_GET['upid']);
	$news = C::t('#mapp_base#aljwsq_mapp_base_keyword') -> fetch($upid);
	$newslist = DB::fetch_all('select * from %t where upid=%d and id!=%d order by displayorder desc',array('aljwsq_mapp_base_keyword',$upid,$_GET['kid']));
}
include template('mapp_base:text');

