<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_aljbd_collection extends discuz_table{
	public function __construct() {

			$this->_table = 'aljbd_collection';
			$this->_pk    = 'id';

			parent::__construct(); /*Dism_taobao-com*/
	}
	public function update_status_by_id($id,$status){
		return DB::query('update %t set status=%d where id=%d',array($this->_table,$status,$id));
	}
	public function fetch_all_by_status($start,$perpage,$status,$fs,$search){
		if($perpage){
			if($search){
				return DB::fetch_all('select * from %t where status %i %d and (title like %s or tel like %s) order by displayorder desc,id desc limit %d,%d',array($this->_table,$fs,$status,$search,$search,$start,$perpage));
			}else{
				return DB::fetch_all('select * from %t where status %i %d order by displayorder desc,id desc limit %d,%d',array($this->_table,$fs,$status,$start,$perpage));
			}
			
		}else{
			return DB::fetch_all('select * from %t where status %i %d  order by displayorder desc,id desc',array($this->_table,$fs,$status));
		}		
	}
	public function count_by_status($status,$fs,$search){
		if($search){
			return DB::result_first('select count(*) from %t where status %i %d and (title like %s or tel like %s)',array($this->_table,$fs,$status,$search,$search));
		}else{
			return DB::result_first('select count(*) from %t where status %i %d',array($this->_table,$fs,$status));
		}
	}
	public function fetch_all_by_typeid_status($start,$perpage,$typeid,$status){
		if($start && $perpage){
			return DB::fetch_all('select * from %t where a=%d and status=%d order by id desc limit %d,%d',array($this->_table,$typeid,$status,$start,$perpage));
		}else{
			return DB::fetch_all('select * from %t where a=%d and status=%d',array($this->_table,$typeid,$status));
		}		
	} 
	public function count_by_typeid_status($typeid,$status){
		return DB::result_first('select count(*) from %t where typeid=%d and status >= %d',array($this->_table,$typeid,$status));
	}
}




?>