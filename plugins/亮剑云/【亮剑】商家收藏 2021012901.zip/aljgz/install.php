<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljbd_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `collection` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `frommod` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `tid` (`tid`)
);
EOF;
runquery($sql);
if(file_exists("source/plugin/aljbd/aljbd.inc.php")) {
  //�ҵ�ҳ�泣����� �ҵ��ղ�
  $mobile_user_common_entrance = C::t('#aljbd#aljbd_setting')->fetch('mobile_user_common_entrance');
  if($mobile_user_common_entrance){
      $mobile_user_common_entrance['value'] .= '
  source/plugin/aljht/static/img/aljbd/user/shoucang.png|plugin.php?id=aljgz&act=collection_list&frommod=aljbd&mobile=2|&#25910;&#34255;&#31649;&#29702;';
      C::t('#aljbd#aljbd_setting')->update_value_by_key($mobile_user_common_entrance['value'],'mobile_user_common_entrance');
  }
}
//finish to put your own code
$finish = TRUE;
?>