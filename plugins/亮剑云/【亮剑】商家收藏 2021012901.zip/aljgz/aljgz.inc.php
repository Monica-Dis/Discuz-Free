<?php
/*
 * ���ߣ�����
 * ��ϵQQ:578933760
 *
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$_GET=dhtmlspecialchars($_GET);
$pluginid = 'aljbd';
$aljbdlang['template']['Collection_management'] = '&#25910;&#34255;&#31649;&#29702;';
require_once 'source/plugin/aljgz/lang/lang.php';
require_once 'source/plugin/aljbd/include/aljbd_parameter.php';
require_once $common_path.'class/class_aljhtx.php';
if($_GET['act'] == 'collection'){
	
	if(!$_G['uid']){
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('&#35831;&#20808;&#30331;&#24405;&#65281;');</script>";
			exit;
		}else{
			showmsg('&#35831;&#20808;&#30331;&#24405;&#65281;');
		}
		
	}
	if($_GET['formhash'] == formhash()){
		if(!DB::result_first('SELECT count(*) FROM %t WHERE uid=%d AND tid=%d and frommod=%s',array('aljbd_collection',$_G['uid'],$_GET['tid'],$_GET['frommod']))){
			$insertarray = array(
				'uid' => $_G['uid'],
				'username' => $_G['username'],
				'tid' => $_GET['tid'],
				'timestamp' => TIMESTAMP,
				'collection' => 1,
				'frommod' => $_GET['frommod']
			);
            if($_GET['frommod'] == 'aljbd'){
                $table_name = 'aljbd';
                $key_id = 'id';
            }else if($_GET['frommod'] == 'aljtsq' || $_GET['frommod'] == 'aljwm'){
                $table_name = 'aljtsq_store';
                $key_id = 'tc_id';
            }else{
                $table_name = 'aljbd_'.$_GET['frommod'];
                $key_id = 'id';
            }
			
			C::t('#aljgz#aljbd_collection')->insert($insertarray);
			DB::query('update %t set collection=collection+1 where '.$key_id.'=%d',array($table_name,$_GET['tid']));
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".$aljgzlang['php']['Collection_success']."',function(){parent.location.href=parent.location.href;});</script>";
				exit;
			}else{
				showmsg($aljgzlang['php']['Collection_success']);
			}
		}else{
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".$aljgzlang['php']['Already_collect']."',function(){parent.location.href=parent.location.href;});</script>";
				exit;
			}else{
				showerror($aljgzlang['php']['Already_collect']);
			}
		}
	}
}else if($_GET['act'] == 'collection_no'){
	if(!$_G['uid']){
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('&#35831;&#20808;&#30331;&#24405;&#65281;');</script>";
			exit;
		}else{
			showmsg('&#35831;&#20808;&#30331;&#24405;&#65281;');
		}
		
	}
	if($_GET['formhash'] == formhash()){
		if(DB::result_first('SELECT count(*) FROM %t WHERE uid=%d AND tid=%d and frommod=%s',array('aljbd_collection',$_G['uid'],$_GET['tid'],$_GET['frommod']))){
			DB::query('DELETE FROM %t WHERE uid=%d AND tid=%d and frommod=%s',array('aljbd_collection',$_G['uid'],$_GET['tid'],$_GET['frommod']));
			if($_GET['frommod'] == 'aljbd'){
				$table_name = 'aljbd';
				$key_id = 'id';
			}else if($_GET['frommod'] == 'aljtsq' || $_GET['frommod'] == 'aljwm'){
                $table_name = 'aljtsq_store';
                $key_id = 'tc_id';
            }else{
				$table_name = 'aljbd_'.$_GET['frommod'];
                $key_id = 'id';
			}
			DB::query('update %t set collection=collection-1 where '.$key_id.'=%d',array($table_name,$_GET['tid']));
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".$aljgzlang['php']['Successfull_cancellation']."',function(){parent.location.href=parent.location.href;});</script>";
				exit;
			}else{
				showmsg($aljgzlang['php']['Successfull_cancellation']);
			}
		}
	}
}else if($_GET['act'] == 'collection_list'){
	if(!$_G['uid']){
		showmessage($aljgzlang['php']['Please_login_first'], '', array(), array('login' => true));
	}
	if($_GET['do'] == 'ajax'){
        $currpage = $_GET['page'] ? intval($_GET['page']) : 1;
        $perpage = 20;
        //$num = DB::result_first('select count(*) from %t where uid=%d and frommod=%s',array('aljbd_collection',$_G['uid'],$_GET['frommod']));
        $start = ($currpage - 1) * $perpage;

        $logs = DB::fetch_all('select * from %t where uid=%d and frommod=%s order by id desc limit %d,%d',array('aljbd_collection',$_G['uid'],$_GET['frommod'],$start,$perpage));
        foreach($logs as $l => $log){
            if($log['frommod'] == 'aljbd'){
                $bd = C::t('#aljbd#aljbd') -> fetch($log['tid']);
                $logs[$l]['title'] = $bd['name'];
                $logs[$l]['logo'] = $bd['logo'];

                $logs[$l]['url'] = 'plugin.php?id=aljbd&act=view&bid='.$log['tid'];
            }else if($log['frommod'] == 'goods'){
                $bd = C::t('#aljbd#aljbd_goods') -> fetch($log['tid']);
                $logs[$l]['title'] = $bd['name'];
                $logs[$l]['logo'] = $bd['pic1'];

                $logs[$l]['url'] = 'plugin.php?id=aljbd&act=goodview&gid='.$log['tid'].'&bid='.$bd['bid'];
            }else if($log['frommod'] == 'consume'){
                $bd = C::t('#aljbd#aljbd_consume') -> fetch($log['tid']);
                $logs[$l]['title'] = $bd['subject'];
                $logs[$l]['logo'] = $bd['pic'];

                $logs[$l]['url'] = 'plugin.php?id=aljbd&act=consumeview&cid='.$log['tid'].'&bid='.$bd['bid'];
            }else if($log['frommod'] == 'notice'){
                $bd = C::t('#aljbd#aljbd_notice') -> fetch($log['tid']);
                $logs[$l]['title'] = $bd['subject'];
                $logs[$l]['logo'] = '';

                $logs[$l]['url'] = 'plugin.php?id=aljbd&act=noticeview&nid='.$log['tid'].'&bid='.$bd['bid'];
            }else if($log['frommod'] == 'aljtsq'){
                $bd = C::t('#aljtsq#aljtsq_store') -> fetch($log['tid']);
                $logs[$l]['title'] = $bd['tc_store_name'];
                $logs[$l]['logo'] = $bd['tc_logo'];

                $logs[$l]['url'] = 'plugin.php?id=aljtsq&c=aljtsq&a=view&store_id='.$bd['tc_id'];
            }else if($log['frommod'] == 'aljwm'){
                $bd = C::t('#aljtsq#aljtsq_store') -> fetch($log['tid']);
                $logs[$l]['title'] = $bd['tc_store_name'];
                $logs[$l]['logo'] = $bd['tc_logo'];

                $logs[$l]['url'] = 'plugin.php?id=aljwm&c=food&a=view&store_id='.$bd['tc_id'];
            }
            $logs[$l]['dateline'] = dgmdate($log['timestamp'],'u');
        }
        if($logs){
            echo json_encode(aljhtx::ajaxPostCharSet($logs));
        }else{
            echo '1';
        }
        exit;
    }
    $navtitle = '&#25910;&#34255;&#31649;&#29702;';
	include template('aljgz:collection_list');
}else if($_GET['act'] == 'collection_del'){
	if($_GET['formhash'] == FORMHASH){
		$cid = intval($_GET['cid']);
		$sc = C::t('#aljgz#aljbd_collection') ->fetch($cid);
		if($sc['uid']!=$_G['uid']){
			showmessage('&#26080;&#26435;&#25805;&#20316;');
		}
		$frommod = htmlspecialchars($_GET['frommod']);
		C::t('#aljgz#aljbd_collection') -> delete($cid);
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo 1;
            exit;
        }else {
            showmessage($aljgzlang['php']['Delete_success'], 'plugin.php?id=aljgz&act=collection_list&frommod=' . $frommod);
        }
	}
}
function showmsg($msg,$close=''){
	if($close){
		$str="parent.hideWindow('$close');";
	}else{
		$str="parent.location=parent.location;";
	}
	include template('aljbd:showmsg');
	exit;
}
function showerror($msg){
	include template('aljbd:showerror');
	exit;
}
//From: Dism��taobao��com
?>