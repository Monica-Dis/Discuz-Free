<?php
class block_aljzp{

	/**
	 * 必须！
	 * 返回本数据调用类的显示名称（显示在创建模块时选择“模块数据”的下拉列表里）
	 * @return <type>
	 */
	function name() {
		return '亮剑求职招聘';
	}

	/**
	 * 必须！
	 * 返回一个数组： 第一个值为本数据类所在的模块分类；第二个值为模块分类显示的名称（显示在 DIY 模块面板）
	 * @return <type>
	 */
	function blockclass() {
		return array('sample', '求职招聘');
	}

	/**
	 * 必须！
	 * 返回数据类中可供“模块样式”使用的字段。
	 * 格式见示例：
	 * name 为该字段的显示名称
	 * formtype 决定编辑单条数据时该字段的显示方式： 类型有： text, textarea, date, title, summary, pic； 详见 portalcp_block.htm 模板（搜 $field[formtype] ）
	 * datatype 决定该字段的数据展示，类型有： string, int, date, title, summary, pic； 详见 function_block.php 中 block_template 函数
	 * @return <type>
	 */
	function fields() {
		return array(
			'title' => array('name' => '标题', 'formtype' => 'title', 'datatype' => 'title'),
			'lid' => array('name' => '数据id', 'formtype' => 'text', 'datatype' => 'int'),
			'url' => array('name' => '链接地址', 'formtype' => 'text', 'datatype' => 'string'),
			'dateline' => array('name' => '发表时间', 'formtype' => 'date', 'datatype' => 'date'),
			'username' => array('name' => '发布人', 'formtype' => 'text', 'datatype' => 'string'),
			'zujin' => array('name' => '薪资', 'formtype' => 'text', 'datatype' => 'text'),
			'zhiwei' => array('name' => '职位', 'formtype' => 'text', 'datatype' => 'text'),
			'views' => array('name' => '浏览量', 'formtype' => 'text', 'datatype' => 'int'),
			'pic' => array('name' => '图片', 'formtype' => 'text', 'datatype' => 'pic'),
			'sex' => array('name' => '性别', 'formtype' => 'text', 'datatype' => 'text'),
			'xueli' => array('name' => '学历', 'formtype' => 'text', 'datatype' => 'text'),
			'region' => array('name' => '一级地区', 'formtype' => 'text', 'datatype' => 'text'),
			'region1' => array('name' => '二级地区', 'formtype' => 'text', 'datatype' => 'text'),
			'region2' => array('name' => '三级地区', 'formtype' => 'text', 'datatype' => 'text'),
			'renshu' => array('name' => '招聘人数', 'formtype' => 'text', 'datatype' => 'text'),
			'gongsi' => array('name' => '公司名称', 'formtype' => 'text', 'datatype' => 'text'),
			'tel' => array('name' => '电话', 'formtype' => 'text', 'datatype' => 'text'),
			'qq' => array('name' => 'qq', 'formtype' => 'text', 'datatype' => 'text'),
			'worktime' => array('name' => '工作时间', 'formtype' => 'text', 'datatype' => 'text'),
		);
	}

	/**
	 * 必须！
	 * 返回使用本数据类调用数据时的设置项
	 * 格式见示例：
	 * title 为显示的名称
	 * type 为表单类型， 有： text, password, number, textarea, radio, select, mselect, mradio, mcheckbox, calendar； 详见 function_block.php 中 block_makeform() 函数
	 * @return <type>
	 */
	function getsetting() {
		global $_G;
		$config = $_G ['cache'] ['plugin'] ['aljzp'];
		if(!$config){
			$pluginid = DB::result_first('select pluginid from %t where identifier = %s',array('common_plugin','aljzp'));
			$pluginvars = DB::fetch_all('select * from %t where pluginid = %d',array('common_pluginvar',$pluginid));
			foreach($pluginvars as $pluginvar){
				$config[$pluginvar['variable']] = $pluginvar['value'];
			}
		}
		$pos_11 = C::t('#aljzp#aljzp_position')->fetch_all_by_upid(0);
		foreach($pos_11 as $k=>$v){
			$pos_all[]=$v;
			if($v['subid']){
				foreach(DB::fetch_all("select * from ".DB::table('aljzp_position')." where id IN (".$v['subid'].")") as $kk=>$vv){
					$pos_all[]=array('id'=>$vv['id'],'subject'=>'-->'.$vv['subject']);
				}
			}	
		}
		
		$group_list[]=array('0','不限');
		foreach($pos_all as $k=>$value) {
			$group_list[] = array($value['id'], $value['subject']);	
		}	
		$pay_types=array('0'=>'不限');
		$paylist = explode ("\n", str_replace ("\r", "", $config ['pays']));
		foreach($paylist as $key=>$value){
			$arr=explode('=',$value);
			$pay_types[$arr[0]]=$arr[1];
		}
		//$jiage=array('0'=>'不限','1'=>'1800以下','2'=>'1800-3000','3'=>'3000-4800','4'=>'4800以上');
		
		foreach($pay_types as $k=>$value) {
			$group_list_1[] = array($k, $value);	
		}
		
		return array(
			'param4' => array(
				'title' => '职位类型',
				'type' => 'select',
				'value' => $group_list,
				'default' => '0'
			),
			'param5' => array(
				'title' => '薪资',
				'type' => 'select',
				'value' => $group_list_1,
				'default' => '0'
			),
			'param6' => array(
				'title' => '必须含图',
				'type' => 'radio',
				
				'default' => '0'
			),
			'param1' => array(
				'title' => '显示条件',
				'type' => 'mradio',
				'value' => array(
					array('0', '最新招聘'),
					array('1', '推荐招聘'),
				),
				'default' => '0'
			),
			'param7' => array(
				'title' => '指定用户ID <img tip="设置要调用的用户UID，多个UID请用半角逗号“,”隔开。" onmouseover="showTip(this)" style="margin: 0;" class="vm" alt="Tip" src="static/image/common/faq.gif" id="tip_0.30557941180678716" initialized="true">',
				'type' => 'text',
			),
			'param10' => array(
				'title' => '过虑已搞定信息',
				'type' => 'radio',
				
				'default' => '0'
			),
			'param3' => array(
				'title' => '排序方式',
				'type' => 'mradio',
				'value' => array(
					array('1', '按发布时间倒序排序'),
					array('2', '按最后刷新时间倒序排序'),
					array('3', '按置顶时间倒序排序'),
				),
				'default' => '1'
			),
			'param2' => array(
				'title' => '标题最大字节数 <img tip="设置当标题长度超过本设定时，是否将标题自动缩减到本设定中的字节数，0 为不自动缩减"  onmouseover="showTip(this)" style="margin: 0;" class="vm" alt="Tip" src="static/image/common/faq.gif" id="tip_0.2672196314724442" initialized="true">',
				'type' => 'text',
				'value' => '',
				'default' => '40'
			),
		);
	}

	/**
	 * 必须！
	 * 处理设置参数，返回数据
	 * 返回数据有两种：
	 * 一种是返回 html，放到模块 summary 字段，直接显示； 返回格式为： array('html'=>'返回内容', 'data'=>null)
	 * 一种是返回 data，通过模块样式渲染后展示，返回的数据应该包含 fields() 函数中指定的所有字段； 返回格式为： array('html'=>'', 'data'=>array(array('title'=>'value1'), array('title'=>'value2')))
	 * 特别的：
	 * parameter 参数包含 getsetting() 提交后的内容； 并附加了字段：
	 * items ，为用户指定显示的模块数据条数；
	 * bannedids ，为用户选择屏蔽某数据时记录在模块中的该数据 id。 应该在获取数据时屏蔽该数据；
	 *
	 * 如果返回的数据给 data， 那么应该包含 fields() 函数指定的所有字段。并附加以下字段：
	 * id 标志该数据的 id，如果用户屏蔽某数据时，会将该数据的 id 添加到 parameter[bannedids] 里
	 * idtype 标志该数据的 idtype
	 *
	 * @param <type> $style 模块样式（见 common_block_style 表）。 可以根据模块样式中用到的字段来选择性的获取/不获取某些数据
	 * @param <type> $parameter 用户对 getsetting() 给出的表单提交后的内容。
	 * @return <type>
	 */
	function getdata($style, $parameter) {
		global $_G;
		// 返回summary
		//return array('html' => '<p>这是一个演示模块数据类</p>', 'data' => null);

		// 返回数据
		// 需要注意： 除 id，idtype， title， url， pic， picflag， summary 几个字段外，其它字段需要放到 fields 数组里。 可以参考系统内置模块类 source/class/block/block_thread.php
		$config = $_G ['cache'] ['plugin'] ['aljzp'];
		if(!$config){
			$pluginid = DB::result_first('select pluginid from %t where identifier = %s',array('common_plugin','aljzp'));
			$pluginvars = DB::fetch_all('select * from %t where pluginid = %d',array('common_pluginvar',$pluginid));
			foreach($pluginvars as $pluginvar){
				$config[$pluginvar['variable']] = $pluginvar['value'];
			}
		}
		$xuelilist = explode ("\n", str_replace ("\r", "", $config ['xueli']));
		foreach($xuelilist as $key=>$value){
			$arr=explode('=',$value);
			$xl_types[$arr[0]]=$arr[1];
		}
		$work_timelist = explode ("\n", str_replace ("\r", "", $config ['work_time']));
		foreach($work_timelist as $key=>$value){
			$arr=explode('=',$value);
			$wtime_types[$arr[0]]=$arr[1];
		}
		$paylist = explode ("\n", str_replace ("\r", "", $config ['pays']));
		foreach($paylist as $key=>$value){
			$arr=explode('=',$value);
			$pay_types[$arr[0]]=$arr[1];
		}
		$pos_zw = C::t('#aljzp#aljzp_position')->range();
		$regions = C::t('#aljzp#aljzp_region')->range();
		$parameter=daddslashes($parameter);
		$con=" where state=0";
		$bannedids = !empty($parameter['bannedids']) ? explode(',', $parameter['bannedids']) : array();
		if($bannedids){
			$con .= ' AND id NOT IN ('.dimplode($bannedids).')';
		}
		if($parameter[param1]){
			
			$con.=" and tuijian =1";
		}
		if($parameter[param4]){
			$con.=" and (pos=".$parameter[param4]." or pos1=".$parameter[param4].')';
		}
		if($parameter[param5]){
			$con.=" and pay = ".$parameter[param5];
		}
		if($parameter[param6]){
			$con.=" and pic1 !='' ";
		}
		if($parameter[param10]){
			$con.=" and solve=0 ";
		}
		if($parameter[param7]){
			$uids=explode(',', $parameter[param7]);
			$con.=" and uid IN (".dimplode($uids).")";
		}
		if($parameter[param3]=='1'){
			$con.=" order by addtime desc";
		}else if($parameter[param3]=='2'){
			$con.=" order by updatetime desc";
		}else if($parameter[param3]=='3'){
			$con.=" order by topetime desc";
		}
		
		$arr=DB::fetch_all ( " select * from ".DB::table('aljzp')." $con");
		foreach($arr as $k=>$v){
			if($config['isrewrite']){
				$arr[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
			}else{
				$arr[$k]['rewrite']='plugin.php?id=aljzp&act=view&lid='.$v['id'];
			}
		}
		//debug($arr);
		$datalist=array();
		foreach($arr as $value) {
			if($value['pic1']){
				$pic=$_G['siteurl'].$value['pic1'].'.640x480.jpg';
			}else{
				$pic=$_G['siteurl'].$config['mr_src'];
			}
			if($value['pos1']){
				$pos1='<a href="plugin.php?id=aljzp&act=list&pid='.$value['pos'].'&subpid='.$value['pos1'].'" class="tag" >'.$pos_zw[$value['pos1']]['subject'].'</a>';
			}
			$datalist[] = array(
				'id' => $value['id'],
				'idtype' => 'lid',				
				'title' => $parameter[param2]?cutstr($value['title'],$parameter[param2],''):$value['title'], 
				'url' => $value['rewrite'],
				'pic' => $pic,
				'picflag' => 0,
				'summary' => '',
				'fields' => array(
					'id' => $value['id'],
					'fulltitle' => $parameter[param2]?cutstr($value['title'],$parameter[param2],''):$value['title'],
					'views' => $value['views'],
					'dateline' => $value['addtime'],
					'zujin' => $value['pay']?$pay_types[$value['pay']]:($value['zujin']>0?$value['zujin'].'元':'面议'),
					'username' => $value['username'],
					'pic' => $pic,
					'zhiwei' => $pos1,
					'sex' => $value['sex'],
					'gongsi' => $value['gongsi'],
					'qq' => $value['qq']>0?$value['qq']:'未填写',
					'tel' => $value['contact'],
					'renshu' => $value['renshu']>0?$value['renshu']:'不限',
					'worktime' => $wtime_types[$value['work_time']],
					'xueli' => $xl_types[$value['xueli']],
					'region' => $regions[$value['region']]['subject'],
					'region1' => $regions[$value['region1']]['subject'],
					'region2' => $regions[$value['region2']]['subject'],
				)
			);
		}
		return array('html'=>'', 'data' =>$datalist);
	}
}

?>