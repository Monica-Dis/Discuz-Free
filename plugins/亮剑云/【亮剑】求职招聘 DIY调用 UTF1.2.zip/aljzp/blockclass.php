<?php
	$blockclass = array(
		'name' => '亮剑求职招聘', //为此目录定义一个名字
	);
?>