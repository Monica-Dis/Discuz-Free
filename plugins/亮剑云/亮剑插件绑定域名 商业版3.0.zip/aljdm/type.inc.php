<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = $_GET['act'];
if($act == 'del' && $_GET['formhash'] == FORMHASH) {
	$tid = intval($_GET['tid']);
	if($tid) {
		$upcid = C::t('#aljdm#aljdm_type')->fetch_upid_by_id($tid);
		if($upcid) {
			$subid = C::t('#aljdm#aljdm_type')->fetch_subid_by_id($upcid);
			$subarr = explode(",", $subid);
			foreach($subarr as $key=>$value) {
				if($value == $tid) {
					unset($subarr[$key]);
					break;
				}
			}
			C::t('#aljdm#aljdm_type')->update($upcid,array('subid'=>implode(",", $subarr)));
		}
		C::t('#aljdm#aljdm_type')->delete($tid);
	}
	cpmsg("&#21024;&#38500;&#25104;&#21151;&#65281;", 'action=plugins&operation=config&identifier=aljdm&pmod=type', 'succeed');	
}

if(!submitcheck('editsubmit')) {	

?>
<table id="tips" class="tb tb2 ">
<tbody><tr><th class="partition">&#25216;&#24039;&#25552;&#31034;</th></tr>
<tr><td s="1" class="tipsblock"><ul id="tipslis">
<li>&#35831;&#22635;&#20889;&#23436;&#25972;&#30340;&#25554;&#20214;&#39029;&#38754;&#38142;&#25509;&#65292;&#27604;&#22914;&#65306;&#104;&#116;&#116;&#112;&#58;&#47;&#47;&#100;&#111;&#109;&#97;&#105;&#110;&#46;&#99;&#111;&#109;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#46;&#112;&#104;&#112;&#63;&#105;&#100;&#61;&#97;&#108;&#106;&#98;&#100;</li>
<li>&#22495;&#21517;&#38656;&#35201;&#35299;&#26512;&#21040;&#35770;&#22363;&#65292;&#24182;&#33021;&#27491;&#24120;&#35775;&#38382;&#65292;&#37197;&#32622;&#21518;&#25165;&#20250;&#29983;&#25928;&#65292;&#22914;&#36824;&#26377;&#30097;&#38382;&#65292;&#35831;&#32852;&#31995;&#20142;&#21073;&#25216;&#26415;&#81;&#81;&#50;&#56;&#49;&#48;&#57;&#55;&#49;&#56;&#48;&#21327;&#21161;&#37197;&#32622;</li>
<li>&#35831;&#22312;&#32593;&#31449;&#26681;&#30446;&#24405;&#30340;&#105;&#110;&#100;&#101;&#120;&#46;&#112;&#104;&#112;&#25991;&#20214;&#20013;&#30340;&#31532;&#19968;&#20010;&#105;&#102;&#40;&#31532;&#49;&#48;&#34892;&#24038;&#21491;&#41;&#21069;&#19968;&#34892;&#21152;&#19978;&#24341;&#29992;&#25991;&#20214;&#32;&#64;&#105;&#110;&#99;&#108;&#117;&#100;&#101;&#32;&#39;&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#97;&#108;&#106;&#100;&#109;&#47;&#97;&#108;&#106;&#100;&#109;&#46;&#112;&#104;&#112;&#39;&#59;&#32;&#20174;&#64;&#24320;&#22987;&#20998;&#21495;&#32467;&#23614;</li>
</ul></td></tr></tbody>
</table>
<script type="text/JavaScript">
var rowtypedata = [
	[[1,'<input type="text" class="txt" name="newcatorder[]" value="0" />', 'td25'], [1, '<input style="width:180px;" name="newcat[]" value="" type="text" class="txt" />'], [2, '<input style="width:380px;" name="newbindlink[]" value="" type="text" class="txt" />']],
	];

function del(id) {
	if(confirm('<?php echo lang('plugin/aljdm','do6');?>')) {
		window.location = '<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=aljdm&pmod=type&act=del&formhash=<?php echo FORMHASH;?>&tid='+id;
	} else {
		return false;
	}
}
</script>
<?php
	showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier=aljdm&pmod=type');
	showtableheader('');
	showsubtitle(array("&#25490;&#24207;","&#22495;&#21517;","&#23436;&#25972;&#30340;&#25554;&#20214;&#39029;&#38754;&#38142;&#25509;","&#25805;&#20316;"));

	$typelist = C::t('#aljdm#aljdm_type')->fetch_all_by_upid(0);
	foreach($typelist as $key=>$value){

		$bt = C::t('#aljdm#aljdm_type')->fetch_all_by_upid($key);
		foreach($bt as $k=>$v){
			$typelist[$key]['subtype'][$k] = $v;
		}
	}
	if($typelist) {
		foreach($typelist as $id=>$type) {
			$show = '<tr class="hover"><td class="td25"><input type="text" class="txt" name="order['.$id.']" value="'.$type['displayorder'].'" /></td><td><div class="parentboard"><input style="width:180px;" type="text" class="txt" name="name['.$id.']" value="'.$type['subject'].'"/></div><td><input type="text"  name="bindlink['.$id.']" value="'.$type['bindlink'].'"  style="width:380px;" /></td>';
			if(!$type['subid']) {
				$show .= '<td><a  onclick="del('.$id.')" href="###">'."&#21024;&#38500;".'</td></tr>';
			} else {
				$show .= '<td>&nbsp;</td></tr>';
			}
			echo $show;
		}	
	}
	echo '<tr class="hover"><td class="td25">&nbsp;</td><td colspan="2" ><div><a href="###" onclick="addrow(this, 0)" class="addtr">'."&#28155;&#21152;&#26032;&#22495;&#21517;".'</a></div></td></tr>';
	

	showsubmit('editsubmit');
	showtablefooter();
	showformfooter();

} else {
	$order = $_GET['order'];
	$name = $_GET['name'];
	$bindlink = $_GET['bindlink'];
	$newbindlink = $_GET['newbindlink'];
	$newcat = $_GET['newcat'];
	if(is_array($order)) {
		foreach($order as $id=>$value) {
			C::t('#aljdm#aljdm_type')->update($id,array('displayorder'=>$value,'subject'=>$name[$id], 'bindlink' => trim($bindlink[$id])));
		}
	}

	if(is_array($newcat)) {
		foreach($newcat as $key=>$name) {
			if(empty($name)) {
				continue;
			}
			$cid=C::t('#aljdm#aljdm_type')->insert(array('upid' => '0', 'subject' => $name, 'bindlink' => trim($newbindlink[$key]), 'displayorder' => $newcatorder[$key]),1);
		}
	}
	require_once './source/function/function_cache.php';
	$aljdm = C::t('#aljdm#aljdm_type') -> range();
	writetocache('aljdm', getcachevars(array('aljdm' => $aljdm)));  

	
	cpmsg("&#26356;&#26032;&#25104;&#21151;&#65281;", 'action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljdm&pmod=type', 'succeed');	
}
//From: Dism_taobao_com
?>


