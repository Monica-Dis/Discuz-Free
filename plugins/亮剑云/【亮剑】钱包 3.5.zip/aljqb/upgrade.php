<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
/*
 * 作�?: Discuz!亮剑工作�?
 * 技术支�?: https://dism.taobao.com
 * 客服QQ: 190360183
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = "ALTER TABLE ".DB::table('aljqb_payorder')." ADD `rubbish` tinyint(4) NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljqb_payorderlog')." CHANGE `error` `error` TEXT NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljqb_payorderlog')." CHANGE `price` `price` DOUBLE(15,2) NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljqb_accountchangelog')." CHANGE `credit` `credit` DOUBLE(15,2) NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljqb_accountchangelog')." ADD `app_name` varchar(255) NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljqb_cashtype')." ADD `real_name` varchar(255) NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljqb_order')." ADD `cashid` int(10) NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljqb_order')." ADD `fee` decimal(10,2) NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljqb_order')." ADD `trans_type` varchar(255) NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljqb_order')." ADD `admindesc` varchar(255) NOT NULL";
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljqb_wallet')." ADD `pullblack` INT(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljqb_wallet')." ADD `password` VARCHAR(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljqb_wallet')." ADD `phone` BIGINT(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljqb_wallet')." ADD `openid` varchar(255) NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljqb_wallet')." ADD `nickname` char(50) NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljqb_wallet')." ADD `sex` int(10) NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljqb_wallet')." ADD `city` varchar(255) NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljqb_wallet')." ADD `unionid` varchar(255) NOT NULL";
DB::query($sql,'SILENT');
$sql = "ALTER TABLE ".DB::table('aljqb_wallet')." ADD `subscribe` int(10) NOT NULL";
DB::query($sql,'SILENT');
$sqls = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljqb_secretkey` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pluginname` varchar(255) NOT NULL,
  `secretkey` varchar(255) NOT NULL,
  `tokenurl` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pluginname` (`pluginname`)
);
EOF;
runquery($sqls);

if(file_exists("source/plugin/aljqb/static/sql/sql.php")){
  require_once 'source/plugin/aljqb/static/sql/sql.php';
  @unlink(DISCUZ_ROOT . './source/plugin/aljqb/static/sql/sql.php');
}
//finish to put your own code
$finish = TRUE;
?>