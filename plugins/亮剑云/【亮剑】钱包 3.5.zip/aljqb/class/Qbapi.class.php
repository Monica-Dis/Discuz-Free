<?php
	Class Qbapi{
		public $siteurl;
		private $host;
		private $ip;
		//��ȡ����
		public function __construct() {
			$settings = self::getsettings();
			$this->siteurl = $settings['OAuth'];
			$this->host =$_SERVER['HTTP_HOST'];
			$this->ip = gethostbyname($this->host);
		}
		static function getsettings() {
			$settings = DB::fetch_all('select * from %t',array('aljqb_paysetting'));
			foreach($settings as $tmp_key => $tmp_value) {
				$newsettings[$tmp_value['key']] = $tmp_value['value'];
			}
			return $newsettings;
		}
		//��ȡ��Կ
		private function getSecret() {
			$secret = DB::fetch_all('select * from %t',array('aljqb_secretkey'));
			foreach($secret as $tmp_key => $tmp_value) {
				$secretlist[$tmp_value['pluginname']] = $tmp_value['secretkey'];
			}
			return $secretlist;
		} 
		//����Ǯ��˽����Կ
		public function createQbKey($params=array()) {
			$secret = $this->getSecret();
			$params['key'] =  $secret['aljqb'];
			$key = '';
			ksort($params);
			foreach($params as $tmp_key => $tmp_value) {
				if($tmp_key == 'price') {
					$tmp_value = substr(sprintf("%.3f",$tmp_value),0,-1);
					$key = $key.$tmp_value;
				}
				if($tmp_key != 'desc' && $tmp_key != 'price') {
					$key = $key.$tmp_value;
				}
			}
			return md5($key);
		}
		//������Կ
		public function createKey($params=array()) {
			$key = '';
			ksort($params);
			foreach($params as $tmp_key => $tmp_value) {
				if($tmp_key == 'price') {
					$tmp_value = substr(sprintf("%.3f",$tmp_value),0,-1);
					$key = $key.$tmp_value;
				}else {
					$key = $key.$tmp_value;
				}
				
			}
			return md5($key);
		}
		//����֧������
		public function createUrl($params=array()) {
			$url ='';
            unset($params['subject']);
			foreach($params as $tmp_key => $tmp_value) {
				if($tmp_key != 'key') {
					if($tmp_key != 'return_url') {
						$url = $url.'&'.$tmp_key.'='.rawurlencode($tmp_value);
					}else {
						$url = $url.'&'.$tmp_key.'='.base64_encode($tmp_value);
					}	
				}	
			}

			$key = $this->createKey($params);
			$siteurl = rtrim($this->siteurl, '/').'/';
			return $siteurl.'plugin.php?id=aljqb&act=confirmorder'.$url.'&key='.$key;
		}
		//���ɶ���,���Ҳ������
		public function balance ($queuearray=array(),$balancearray=array()) {
			$result = $this-> getQueueid ($queuearray);
			if($result['code'] == 200) {
				$balancearray['queueid'] = $result['queue']['queueid'];
				$balancearray['app_name'] = $result['queue']['app_name'];
				$data = $this -> editbalance($balancearray);
				return $data;
			}else {
				return $result;
			}	
		}
		//��ȡ����id
		public function getQueueid ($queuearray=array()) {
			$queuearray['key'] = $this->createQbKey($queuearray);
			$queuearray['host'] =  base64_encode($this->host);
			$queuearray['ip'] =  base64_encode($this->ip);
			$siteurl = $this->siteurl;
			$url = $siteurl.'source/plugin/aljqb/pay/getqueue.php';

			$result = $this -> postDatacurl($queuearray,$url);

			$result = json_decode($result,true);

			if(isset($result['code']) && $result['code']!=200) {
				$this->insertLog($result['message']);
			}
			return $result;
		}
		//�������
		public function editbalance ($balancearray=array()) {
			$balancearray['key'] = $this->createQbKey($balancearray);
			$balancearray['host'] =  base64_encode($this->host);
			$balancearray['ip'] =  base64_encode($this->ip);
			$siteurl = $this->siteurl;
			$url = $siteurl.'source/plugin/aljqb/pay/editbalance.php';

			$result = $this -> postDatacurl($balancearray,$url);
			$result = json_decode($result,true);
			return $result;
		}
		public function insertLog($error) {
			DB::insert('aljqb_payorderlog',array(
				'error'=> $error,
				'time'=> time(),
			));
		}
		//post��ʽcurl
		public function postDatacurl($data=array(),$url='',$second=30){
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_TIMEOUT, $second);
			curl_setopt($ch,CURLOPT_URL, $url);
			curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
			curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
			curl_setopt($ch, CURLOPT_HEADER, FALSE);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
			curl_setopt($ch, CURLOPT_POST, TRUE);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
			$result = curl_exec($ch);
            if(curl_exec($ch) === false)
            {
                $this->insertLog('Curl error: ' . curl_error($ch));
            }
			curl_close($ch);
			if($result){
				curl_close($ch);
				return $result;
			}else {
				$this->insertLog('&#35775;&#38382;'.$url.'&#22833;&#36133;');
			}
		}
	
	}
?>