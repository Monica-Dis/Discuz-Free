<?php
	class Queue{
		//���ɶ���id
		public function createQueueid () {
			$queueid = 'queue'.random(7).dgmdate(TIMESTAMP, 'His');
			$check = DB::result_first('select count(*) from %t where queueid=%s',array('aljqb_queue',$queueid));
			while($check){
				$this->createQueueid();
			}
			return $queueid;
		}
		//����һ�����м�¼,����id
		public function createFirstQueueLog ($logarray=array()) {
			if(!$logarray['app_name']) {
				$this->insertLog('app_name &#19981;&#23384;&#22312;');
				return false;
			}
			if(!$logarray['app_type']) {
				$this->insertLog($logarray['app_name'].'app_type &#19981;&#23384;&#22312;');
				return false;
			}
			if(!$logarray['app_ip']) {
				$this->insertLog($logarray['app_name'].'app_ip &#19981;&#23384;&#22312;');
				return false;
			}
			if(!$logarray['app_phone']) {
				$this->insertLog($logarray['app_name'].'app_phone &#19981;&#23384;&#22312;');
				return false;
			}
			$insertarray['app_name'] = $logarray['app_name'];
			$insertarray['app_type'] = $logarray['app_type'];
			$insertarray['queueid'] = $this->createQueueid();
			$insertarray['createtime'] = time();
			DB::insert('aljqb_queue',$insertarray);
			$insert_id = DB::result_first('select count(*) from %t where queueid=%s',array('aljqb_queue',$insertarray['queueid']));
			if($insert_id) {
				return $insertarray;
			}else {
				$this->insertLog('&#25554;&#20837;&#38431;&#21015;&#22833;&#36133;');
				return false;
			}	
		}
		public function insertLog($error) {
			DB::insert('aljqb_payorderlog',array(
				'error'=> $error,
				'time'=> time(),
			));
		}
	}
?>