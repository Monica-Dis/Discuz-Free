<?php
class Payment{
	static function getsettings() {
		$settings = DB::fetch_all('select * from %t',array('aljqb_paysetting'));
		foreach($settings as $tmp_key => $tmp_value) {
			$newsettings[$tmp_value['key']] = $tmp_value['value'];
		}
		return $newsettings;
	}
	//��ֵ
	//���ɳ�ֵ����
	public function createOrder($orderparams=array()) {
		if(!empty($orderparams)) {
			$orderparams['createtime'] = TIMESTAMP;
			$orderparams['orderid'] = $this->createOrderid();
			if(DB::insert('aljqb_rechargeorder',$orderparams)) {
				return $orderparams;
			}
		}
	}
	//��鶩����
	public function createOrderid() {
		$orderid = 'alj'.random(7).dgmdate(TIMESTAMP, 'His');
		$check = DB::result_first('select count(*) from %t where orderid=%s',array('aljqb_rechargeorder',$orderid));
		while($check){
			$this->createOrderid();
		}
		return $orderid;
	}

	//֧��
	//����֧������
	public function createPayOrder ($orderparams=array()) {
		if(!empty($orderparams)) {
			$order = DB::fetch_first('select * from %t where orderid=%s',array('aljqb_payorder',$orderparams['orderid']));
			if(empty($order)) {
				$orderparams['createtime'] = TIMESTAMP;
				$orderparams['aljorderid'] = $this->createPayOrderid();
				if(DB::insert('aljqb_payorder',$orderparams)) {
					return $orderparams;
				}
			}else {
				if($_GET['wxh5']){
					$updatearray = array('rurl'=>$orderparams['rurl'],'overtime'=>$orderparams['overtime']);
				}else{
					$updatearray = array('rurl'=>$orderparams['rurl'],'overtime'=>$orderparams['overtime'],'aljorderid'=>$this->createPayOrderid());
				}
				if($order['price'] != $orderparams['price']){
					$updatearray['price'] = $orderparams['price'];
                    DB::update('aljqb_payorder',$updatearray,array('orderid'=>$orderparams['orderid']));
                    
				}else{
                    DB::update('aljqb_payorder',$updatearray,array('orderid'=>$orderparams['orderid']));
				}
				$order = DB::fetch_first('select * from %t where orderid=%s',array('aljqb_payorder',$orderparams['orderid']));
				return $order;
			}
		}
	}
	//����֧������id
	public function createPayOrderid() {
		$settings = self::getsettings();
		$orderid = ($settings['qianfanapp_hostname'] ? $settings['qianfanapp_hostname'].'lj' : '').'wx'.random(7).dgmdate(TIMESTAMP, 'His');
		$check = DB::result_first('select count(*) from %t where aljorderid=%s',array('aljqb_payorder',$orderid));
		while($check){
			$this->createPayOrderid();
		}
		return $orderid;
	}
	public function getPayparams ($order=array(),$url='',$notify_url='') {
		$params = array(
			'body' => diconv($order['subject'],CHARSET,'UTF-8'),
			'out_trade_no' => $order['aljorderid'],
			'total_fee' => $order['price'],
			'notify_url' => $notify_url,
		);
		
		if($order['trade_mod'] == 'alipay'){
			$params['subject'] = diconv($order['subject'],CHARSET,'UTF-8');
			$params['return_url'] = $url.'plugin.php?id=aljqb&act=success';
			$params['show_url'] = $url.'plugin.php?id=aljqb&act=fail&out_trade_no='.$order['aljorderid'];
		}else if($order['trade_mod'] == 'wxpay'){
			$params['total_fee'] = $params['total_fee']*100;
			if($order['openid']){
				$params['openid'] = $order['openid'];
			}
		}
		return $params;
	}
	//����֧������
	public function updatePayOrder ($updatearray=array(),$orderid) {
		DB::update('aljqb_payorder', $updatearray,array('aljorderid'=>$orderid));
	}
	//��ѯһ��֧��������Ϣ
	public function fetchOrder($orderid='') {
		return DB::fetch_first('select * from %t where aljorderid=%s',array('aljqb_payorder',$orderid));
	}
	//����
	//�������ֶ���id
	public function createTxOrderid() {
		$orderid = 'tx'.random(7).dgmdate(TIMESTAMP, 'His');
		$check = DB::result_first('select count(*) from %t where orderid=%s',array('aljqb_order',$orderid));
		while($check){
			$this->createTxOrderid();
		}
		return $orderid;
	}
	//�������ֶ���
	public function createTxOrder($orderparams=array()) {
		if(!empty($orderparams)) {
			$orderparams['orderid'] = $this->createTxOrderid();
			if(DB::insert('aljqb_order',$orderparams)) {
				return $orderparams;
			}
		}
	}
	//����һ���˵���¼
	public function createFirstlog($insertarray) {
		$insertarray['time'] = time();
		return DB::insert('aljqb_accountchangelog',$insertarray,true);
	}

}
?>
