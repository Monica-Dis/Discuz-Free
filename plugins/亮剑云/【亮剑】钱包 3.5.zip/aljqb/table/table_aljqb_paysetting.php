<?php

/*
 * ����: Discuz!�����ƹ�����
 * ����֧��: https://dism.taobao.com?/
 * ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_aljqb_paysetting extends discuz_table
{
	public function __construct() {

		$this->_table = 'aljqb_paysetting';
		$this->_pk    = 'key';

		parent::__construct(); /*dism _taobao _com*/
	}
	public function update_value_by_key($value,$key){
		return DB::query('update %t set `value`=%s  where `key`=%s',array($this->_table,$value,$key));
	}

}
//From: Dism_taobao-com
?>