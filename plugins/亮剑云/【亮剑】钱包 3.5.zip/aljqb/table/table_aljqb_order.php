<?php

/*
 * ���ߣ�����
 * ��ϵQQ:578933760
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljqb_order extends discuz_table {

    public function __construct() {

        $this->_table = 'aljqb_order';
        $this->_pk = 'orderid';

        parent::__construct(); /*dism _taobao _com*/
    }
}
//From: Dism_taobao-com
?>