<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if($_G['groupid']!=1){
	exit;
}

loadcache('plugin');
if($_GET['act'] == 'deletediary'){
    if(is_array($_POST['delete'])) {
        foreach($_POST['delete'] as $id) {
            DB::query('delete from %t where id=%d',array('aljqb_accountchangelog',$id));
        }
    }
    cpmsg("aljqb:diary_inc_php_1",'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljqb&pmod=diary');
}else{
	$orderid = addslashes($_GET['orderid']);
	$username = addslashes($_GET['username']);
	$app_name = addslashes($_GET['app_name']);
  	$currpage = $_GET['page'] ? intval($_GET['page']) : 1;
  	$perpage = 16;
  	$start = ($currpage - 1) * $perpage;
	$where  = 'where 1 ';
    if(file_exists('source/plugin/aljqb/dz.php')){
        $conn=array('aljqb_accountchangelog','common_member');
        if($_GET['orderid']){
            $where .= ' and a.orderid=%s ';
            $conn[] = $orderid;
        }
        if($_GET['app_name']){
            $where .= ' and a.app_name=%s ';
            $conn[] = $app_name;
        }
        if($_GET['username']){
            $where .= ' and a.username like %i ';
            $conn[] = "'%".$username."%'";
        }
        if($_GET['date_s']){
            $date_s = strtotime($_GET['date_s']);
            //debug($date);
            $where .= ' and a.time>=%d ';
            $conn[] = $date_s;
        }
        if($_GET['date_e']){
            $date_e = strtotime($_GET['date_e']);
            $where .= ' and a.time<%d ';
            $conn[] = $date_e;
        }
        if($_GET['groupid']){

            $where .= ' and b.groupid=%d ';
            $conn[] = $_GET['groupid'];
        }
        //debug($where);
        $charge_price = DB::result_first('select sum(a.credit) from %t a left join %t b on a.uid = b.uid '.$where.' and a.type=\'charge\'', $conn);
        $take_price = DB::result_first('select sum(a.credit) from %t  a left join %t b on a.uid = b.uid '.$where.' and a.type=\'take\'', $conn);
        //$balance_price = DB::result_first('select sum(balance) from %t ',array('aljqb_wallet'));
        $balance = DB::fetch_all('SELECT a.uid, MAX(`id`) id FROM  %t  a left join %t b on a.uid = b.uid '.$where.' GROUP BY a.uid',$conn);

        //$balance_price = DB::result_first('select sum(balance) from %t '.$where,$conn);
        $num = DB::result_first('select count(*) from %t  a left join %t b on a.uid = b.uid '.$where,$conn);
        //$n_orderlist = DB::fetch_all('select a.*,b.groupid from %t  a left join %t b on a.uid = b.uid '.$where,$conn);
        $where .=  'order by id desc limit %d,%d';
        $conn[] = $start;
        $conn[] = $perpage;
        $orderlist = DB::fetch_all('select a.*,b.groupid from %t  a left join %t b on a.uid = b.uid '.$where,$conn);
    }else{
        $conn=array('aljqb_accountchangelog');
        if($_GET['orderid']){
            $where .= ' and orderid=%s ';
            $conn[] = $orderid;
        }
        if($_GET['app_name']){
            $where .= ' and app_name=%s ';
            $conn[] = $app_name;
        }
        if($_GET['uid']){
            $where .= ' and uid=%d ';
            $conn[] = $_GET['uid'];
        }
        if($_GET['username']){
            $where .= ' and username like %i ';
            $conn[] = "'%".$username."%'";
        }
        if($_GET['date_s']){
            $date_s = strtotime($_GET['date_s']);
            //debug($date);
            $where .= ' and time>=%d ';
            $conn[] = $date_s;
        }
        if($_GET['date_e']){
            $date_e = strtotime($_GET['date_e']);
            $where .= ' and time<%d ';
            $conn[] = $date_e;
        }
        $charge_price = DB::result_first('select sum(credit) from %t '.$where.' and type=\'charge\'', $conn);
        $take_price = DB::result_first('select sum(credit) from %t '.$where.' and type=\'take\'', $conn);
        //$balance_price = DB::result_first('select sum(balance) from %t ',array('aljqb_wallet'));
        $balance = DB::fetch_all('SELECT uid, MAX(`id`) id FROM  %t '.$where.' GROUP BY uid',$conn);

        //$balance_price = DB::result_first('select sum(balance) from %t '.$where,$conn);
        $num = DB::result_first('select count(*) from %t '.$where,$conn);
        //$n_orderlist = DB::fetch_all('select * from %t '.$where,$conn);
        $where .=  'order by id desc limit %d,%d';
        $conn[] = $start;
        $conn[] = $perpage;
        $orderlist = DB::fetch_all('select * from %t '.$where,$conn);
    }

	/*foreach ($n_orderlist as $key => $value) {
		 $n_orderlist[$value['id']] = $value;
	}*/
	$balance_price = 0;
	foreach ($balance as $key => $val) {
		 $balance_price = $balance_price+$n_orderlist[$val['id']]['balance'];
	}
	$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljqb&pmod=diary&orderid='.$_GET['orderid'].'&uid='.$_GET['uid'].'&username='.$username.'&date_s='.$_GET['date_s'].'&date_e='.$_GET['date_e'].'&app_name='.$app_name, 0, 11, false, false);
	include template('aljqb:diary');
}
function l_groups($group,$type=0){
    global $_G,$config,$lang,$settings;
    if($type){
        $var['type'] = '<select name="'.$group.'"><option value="">'.cplang('plugins_empty').'</option>';
        $var['value'] = $_GET['groupid'];
    }else{
        $var['description'] = ($var['description'] ? (isset($lang[$var['description']]) ? $lang[$var['description']] : $var['description'])."\n" : '').$lang['plugins_edit_vars_multiselect_comment']."\n".$var['comment'];
        $var['value'] = dunserialize($settings[$group]['value']);
        $var['type'] = '<select name="settingsnew['.$group.'][]" size="10" multiple="multiple"><option value=""'.(@in_array('', $var['value']) ? ' selected' : '').'>'.cplang('plugins_empty').'</option>';
    }

    $var['value'] = is_array($var['value']) ? $var['value'] : array($var['value']);

    $query = C::t('common_usergroup')->range_orderby_credit();
    $groupselect = array();
    foreach($query as $group) {
        $group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
        $groupselect[$group['type']] .= '<option value="'.$group['groupid'].'"'.(@in_array($group['groupid'], $var['value']) ? ' selected' : '').'>'.$group['grouptitle'].'</option>';
    }
    $var['type'] .= '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
        ($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
        ($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
        '<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup></select>';
    return $var['type'];
}
?>
