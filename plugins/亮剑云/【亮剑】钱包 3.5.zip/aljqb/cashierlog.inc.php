<?php
/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(submitcheck('del_submit')){
	if(is_array($_POST['delete'])) {
		foreach($_POST['delete'] as $id) {
			DB::update('aljqb_payorder',array('rubbish'=>1), array('aljorderid'=>$id));
		}
		cpmsg("aljqb:rechargelog_inc_php_1",'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljqb&pmod=cashierlog');
	}
}
$pluginname = $_GET['pluginname'];
$aljorderid = $_GET['aljorderid'];
$orderid = $_GET['orderid'];
$username = $_GET['username'];
$currpage = $_GET['page'] ? intval($_GET['page']) : 1;
$perpage = 16;
$start = ($currpage - 1) * $perpage;
$where  = 'where rubbish=0 ';
$conn = array('aljqb_payorder');
if($_GET['pluginname']){
	if(strpos($_GET['pluginname'],',') !== false){
		$where .= ' and pluginname in (%n)';
		$conn[] = explode(',',$_GET['pluginname']);
	}else{
		$where .= ' and pluginname=%s ';
		$conn[] = $pluginname;
	}
}
if($_GET['orderid']){
	$where .= ' and orderid=%s ';
	$conn[] = $orderid;
}
if($_GET['aljorderid']){
	$where .= ' and aljorderid=%s ';
	$conn[] = $aljorderid;
}
if($_GET['transaction_id']){
	$where .= ' and transaction_id=%s ';
	$conn[] = $transaction_id;
}
if($_GET['username']){
	$where .= ' and username like %i ';
	$conn[] = "'%".$username."%'";
}
if($_GET['uid']){
	$where .= ' and uid = %d ';
	$conn[] = $_GET['uid'];
}
if($_GET['date_s']){
	$date_s = strtotime($_GET['date_s']);
	$where .= ' and createtime>=%d ';
	$conn[] = $date_s;
}
if($_GET['date_e']){
	$date_e = strtotime($_GET['date_e']);
	$where .= ' and createtime<%d ';
	$conn[] = $date_e;
}
if($_GET['trade_mod']){
	
	if($_GET['trade_mod'] == 1){
		
		$where .= ' and trade_mod=%s ';
		$conn[] = 'mywallet';
	}else if($_GET['trade_mod'] == 2){
		$where .= ' and trade_mod in (%n) ';
		$conn[] = array('wxpay','alipay','magapp','qianfanapp','APP');
	}else if($_GET['trade_mod'] == 5){
		$where .= ' and trade_mod in (%n) ';
		$conn[] = array('magapp','qianfanapp','APP');
	}else if($_GET['trade_mod'] == 3){
		
		$where .= ' and trade_mod=%s ';
		$conn[] = 'alipay';
	}else if($_GET['trade_mod'] == 4){
		
		$where .= ' and trade_mod=%s ';
		$conn[] = 'wxpay';
	}
	
}
if($_GET['status']){
	
	$status = $_GET['status'] == 99 ? 0 : $_GET['status'];
	
	$where .= ' and status = %d ';
	$conn[] = $status;
}

$num = DB::result_first('select count(*) from %t '.$where,$conn);
$search_sumprice_all = DB::fetch_all('select count(*) num,sum(price) price,status from %t '.$where.' group by status order by status asc',$conn);
$sumprice = 0;
$countnum = 0;
//debug($sumprice_all);
if($search_sumprice_all){
	$search_sumprice = '&#25628;&#32034;&#32479;&#35745;&#65306;';
	foreach($search_sumprice_all as $s_v){
		
			$sumprice += $s_v['price'];
			$countnum += $s_v['num'];
		
		
		if($s_v['status'] == 0){
			$search_sumprice .= '&#24453;&#20184;&#27454;'.'('.$s_v['num'].')'.'&#65306;'.'<span class="price">'.$s_v['price'].'</span> '.'&#20803;&#65292;';
		}else if($s_v['status'] == 1){
			$search_sumprice .= '&#24050;&#25903;&#20184;'.'('.$s_v['num'].')'.'&#65306;'.'<span class="price">'.$s_v['price'].'</span> '.'&#20803;&#65292;';
		}else if($s_v['status'] == 2){
			$search_sumprice .= '&#24050;&#36864;&#27454;'.'('.$s_v['num'].')'.'&#65306;'.'<span class="price">'.$s_v['price'].'</span> '.'&#20803;&#65292;';
			
		}
	}
	$search_sumprice .= '&#24635;'.'('.$countnum.')'.'&#65306;'.'<span class="price">'.$sumprice.'</span> '.'&#20803;';
}

//$price = DB::result_first('SELECT sum(price) id FROM  %t '.$where.' and status = 1',$conn);
$where .=  'order by createtime desc limit %d,%d';
$conn[] = $start;
$conn[] = $perpage;
$orderlist = DB::fetch_all('select * from %t '.$where,$conn);
$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljqb&pmod=cashierlog&orderid='.$orderid.'&username='.$username.'&aljorderid='.$aljorderid.'&pluginname='.$pluginname.'&uid='.$_GET['uid'].'&date_s='.$_GET['date_s'].'&date_e='.$_GET['date_e'].'&trade_mod='.$_GET['trade_mod'].'&status='.$_GET['status'], 0, 11, false, false);
$timeoffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$timeoffset),dgmdate($_G['timestamp'], 'j',$timeoffset),dgmdate($_G['timestamp'], 'Y',$timeoffset)) - $timeoffset*3600;

$nowWeekTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$timeoffset),dgmdate($_G['timestamp'], 'j',$timeoffset)-7,dgmdate($_G['timestamp'], 'Y',$timeoffset)) - $timeoffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$timeoffset),1,dgmdate($_G['timestamp'], 'Y',$timeoffset)) - $timeoffset*3600;
$sumprice_all = DB::fetch_all('select count(*) num,sum(price) price,status from %t where rubbish=0 group by status order by status asc',array('aljqb_payorder'));
$sumprice = 0;
$countnum = 0;
foreach($sumprice_all as $s_v){
	if($s_v['status'] = 1){
		$sumprice += $s_v['price'];
		$countnum += $s_v['num'];
	}
}

$todaysumprice_all = DB::fetch_all('select count(*) num,sum(price) price,status from %t where rubbish=0 and createtime>=%d group by status order by status asc',array('aljqb_payorder',$nowDayTime));
$todaysumprice = 0;
$todaycountnum = 0;
foreach($todaysumprice_all as $s_v){
	if($s_v['status'] = 1){
		$todaysumprice += $s_v['price'];
		$todaycountnum += $s_v['num'];
	}
}

$weeksumprice_all = DB::fetch_all('select count(*) num,sum(price) price,status from %t where  rubbish=0 and createtime>=%d group by status order by status asc',array('aljqb_payorder',$nowWeekTime));
$weeksumprice = 0;
$weekcountnum = 0;
foreach($weeksumprice_all as $s_v){
	if($s_v['status'] = 1){
		$weeksumprice += $s_v['price'];
		$weekcountnum += $s_v['num'];
	}
}

$monthsumprice_all = DB::fetch_all('select count(*) num,sum(price) price,status from %t where  rubbish=0 and createtime>=%d group by status order by status asc',array('aljqb_payorder',$nowMonthTime));
$monthsumprice = 0;
$monthcountnum = 0;
foreach($monthsumprice_all as $s_v){
	if($s_v['status'] = 1){
		$monthsumprice += $s_v['price'];
		$monthcountnum += $s_v['num'];
	}
}

include template('aljqb:cashierlog');
?>
