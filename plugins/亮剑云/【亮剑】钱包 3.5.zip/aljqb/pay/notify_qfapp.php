<?php
define('DISABLEXSSCHECK',true);
require '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
require_once '../../../../source/plugin/aljqb/class/Payment.class.php';
require_once '../../../../source/plugin/aljqb/class/Qbapi.class.php';
$qbapi = new Qbapi();
$payment = new Payment();
loadcache('plugin');
require '../../../../source/plugin/aljqb/function/function_core.php';
$order = $payment->fetchOrder($_GET['out_trade_no']);
if($_GET['order_id'] && $order['trade_mod'] == 'qianfanapp'){
    $transaction_id = $_GET['order_id'];
  $result = qianfanapp_query($transaction_id);

  if($result['data'][$transaction_id]['result']==1 || $result['data'][$transaction_id]['result']==2){
        if($result['data'][$transaction_id]['info']['cash_cost'] != $order['price']*100 || $_GET['out_trade_no'] != $result['data'][$transaction_id]['info']['out_trade_no']){
            $tip = '&#25903;&#20184;&#22833;&#36133;&#65292;&#37329;&#39069;&#24322;&#24120;';
            $navtitle = '&#25903;&#20184;&#20449;&#24687;';
            $face = 0;
            $url = $order['rurl'];
            include template('aljqb:tip');
            exit;
        }
        $updatearray['transaction_id'] = $transaction_id;
        if ($order['status'] < 1) {
                $updatearray['status'] = 1;
        }
        if ($order['paytime'] < 1) {
                $updatearray['paytime'] = TIMESTAMP;
        }
        $payment->updatePayOrder($updatearray, $_GET['out_trade_no']);
        $neworder = $payment->fetchOrder($_GET['out_trade_no']);
        if ($neworder['status']) {
                $keyarray = array(
                        'aljorderid' => $neworder['aljorderid'],
                        'paytime' => $neworder['paytime'],
                        'orderid' => $neworder['orderid'],
                        'key' => $aljqbkey[$neworder['pluginname']][1],
                );
                //file_put_contents('test.txt',$aljqbkey[$neworder['pluginname']][1]."\r",FILE_APPEND);
                $json = json_encode($keyarray);
                $key = $qbapi->createKey($keyarray);
                $postdata = array(
                        'aljorderid' => $neworder['aljorderid'],
                        'paytime' => $neworder['paytime'],
                        'orderid' => $neworder['orderid'],
                        'key' => $key,
                );
                //file_put_contents('test.txt',$key."\r",FILE_APPEND);
                $status = postXmlCurl($postdata, $order['nurl']);
                $status = strtolower($status);
                if ($status != 'success') {
                    $qbapi->insertLog($order['nurl'] . lang("plugin/aljqb","notify_qfapp_php_1").' success');
                }
        }
        echo 'SUCCESS';
        EXIT;
  }
}
