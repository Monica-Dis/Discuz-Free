<?php
	define('DISABLEXSSCHECK',true);
	require '../../../../source/class/class_core.php';
	require_once '../../../../source/plugin/aljqb/class/Qbapi.class.php';
	$discuz = C::app();
	$discuz->init();
	loadcache('plugin');
	$qbapi = new Qbapi();
	$getdata = array(
		'queueid' => $_GET['queueid'],
		'app_name' => $_GET['app_name'],
		'uid' => intval($_GET['uid']),
		'desc'=> $_GET['desc'],
		'orderid'=> $_GET['orderid'],
		'price' => $_GET['price']+0,
		'type' => $_GET['type'],
	);
	$curlinfo = array(
		'host' => base64_decode($_GET['host']),
		'ip' => base64_decode($_GET['ip']),
	);
	$key = $qbapi->createQbKey($getdata);
	//file_put_contents('edit.txt',$key."\r",FILE_APPEND);
	//file_put_contents('edit.txt',$_GET['key']."\r",FILE_APPEND);
	if($curlinfo['ip'] != gethostbyname($_SERVER['HTTP_HOST'])) {
		$qbapi->insertLog($curlinfo['host'].'&#47;'.$curlinfo['ip'].'&#47;'.$getdata['app_name'].' &#35775;&#38382;&#20102; getqueue.php &#25991;&#20214;');
	}
	if($_GET['key'] != $key) {
		$returnnews = array('code'=>400,'message'=>'key parameter error');
		insertlog($curlinfo['host'].'&#47; '.$getdata['app_name'].' key error');
		echo json_encode($returnnews);
		exit;
	}
	$getdata['price'] = substr(sprintf("%.3f",$getdata['price']),0,-1);
	if($getdata['uid']<=0) {
		$returnnews = array('code'=>100,'message'=>'uid parameter error');//uid ��������
		insertlog('uid &#21442;&#25968;&#38169;&#35823;'.$getdata['app_name']);
		echo json_encode($returnnews);
		exit;
	}
	if($getdata['price']<=0) {
		$returnnews = array('code'=>100,'message'=>'price parameter error');//price ��������
		insertlog('price &#21442;&#25968;&#38169;&#35823;');
		echo json_encode($returnnews);
		exit;
	}
	if(!$getdata['app_name']) {
		$returnnews = array('code'=>100,'message'=>'app_name parameter error');//app_name ��������
		insertlog('app_name &#21442;&#25968;&#38169;&#35823;');
		echo json_encode($returnnews);
		exit;
	}
	if(!$getdata['queueid']) {
		$returnnews = array('code'=>100,'message'=>'queueid parameter error');//queueid ��������
		insertlog('queueid &#21442;&#25968;&#38169;&#35823;');
		echo json_encode($returnnews);
		exit;
	}
	if(!$getdata['desc']) {
		$returnnews = array('code'=>100,'message'=>'desc parameter error');//desc ��������
		insertlog('desc &#21442;&#25968;&#38169;&#35823;');
		insertlog($returnnews['message']);
		echo json_encode($returnnews);
		exit;
	}
	if(!$getdata['orderid']) {
		$returnnews = array('code'=>100,'message'=>'orderid parameter error');//orderid ��������
		insertlog('orderid &#21442;&#25968;&#38169;&#35823;');
		echo json_encode($returnnews);
		exit;
	}
	if(!$getdata['type']) {
		$returnnews = array('code'=>100,'message'=>'type parameter error');//type ��������
		insertlog('type &#21442;&#25968;&#38169;&#35823;');
		echo json_encode($returnnews);
		exit;
	}
	$userinfo = DB::fetch_first('select * from %t where uid=%d',array('common_member',$getdata['uid']));
	if(!empty($userinfo)) {
		$queuedata = DB::fetch_first('select * from %t where queueid=%s',array('aljqb_queue',$getdata['queueid']));
		if(!empty($queuedata)) {
			$wallet = DB::fetch_first('select * from %t where uid=%d',array('aljqb_wallet',$getdata['uid']));
			if(DB::update('aljqb_queue',array('queuestate'=>1),array('queuestate'=>0,'queueid'=>$queuedata['queueid']))) {
				$logarray = array(
					'uid' => $userinfo['uid'],
					'username'=> $userinfo['username'],
					'type' => $getdata['type'],
					'time' => time(),
					'orderid' => $getdata['orderid'],
					'queueid' => $getdata['queueid'],
					'app_name'=> $getdata['app_name'],
					'desc'=> $getdata['desc'],
				);
				if(!empty($wallet)) {
					$balance = $wallet['balance'];
				}else {
					$walletarray= array(
						'uid'=> $userinfo['uid'],
						'username' => $userinfo['username'],
						'createtime' => time(),
						'updatetime'=>time(),
					);
					DB::insert('aljqb_wallet',$walletarray);
					$balance = 0;
				}
				if($getdata['type'] == 'charge') {
					$logarray['credit'] = $getdata['price'];
					$logarray['balance'] = $balance + $getdata['price'];
					if(DB::insert('aljqb_accountchangelog',$logarray,true)) {
						if (DB::update('aljqb_queue',array('queuestate'=>2),array('queuestate'=>1,'queueid'=>$queuedata['queueid']))) {
							$res = DB::update('aljqb_wallet',array('balance'=>$logarray['balance'],'updatetime'=>time()),array('uid'=>$userinfo['uid']));
							if($res) {
								$returnnews = array('code'=>200,'message'=>'add balance success');//�����ɹ�

								$keyname = 'aljqb';
                                if ($_G['cache']['plugin']['mapp_template'] && $_G['cache']['plugin']['aljhtx']
                                    && DB::fetch_first('select * from %t where type=%s', array('aljhtx_wechat_bindtemplate', 'transactionReminder'))) {
                                    require_once DISCUZ_ROOT .'source/plugin/aljhtx/class/class_aljhtx.php';
                                    $param = array(
                                        'order_subject' => $getdata['desc'],
                                        'trade_time' => dgmdate(time(),'Y-m-d H:i:s'),
                                        'trade_price' => $getdata['price'].lang("plugin/aljqb","editbalance_php_1"),
                                        'trade_orderid' => $getdata['orderid'],
                                        'order_content' => lang("plugin/aljqb","editbalance_php_2"),
                                        'type' => 'transactionReminder',
                                    );
                                    T::aljbd_notification($userinfo['uid'],$param,'plugin.php?id=aljqb');
                                }else{
                                    notification_add($userinfo['uid'], 'system','<a href="plugin.php?id=aljqb">'.$getdata['desc'].'</a>',array('from_idtype'=>$keyname));
								}
								echo json_encode($returnnews);
								exit;
							}else {
								$returnnews = array('code'=>100,'message'=>'add balance fail');//����ʧ��  �������ʧ�ܣ�����ʧ��
								insertlog('uid:'.$userinfo['uid'].'&#22686;&#21152;&#20313;&#39069;&#22833;&#36133;&#65292;&#26356;&#26032;&#22833;&#36133;');
								echo json_encode($returnnews);
								exit;
							}

						}else {
							$returnnews = array('code'=>100,'message'=>'add balance fail');//����ʧ��  �������ʧ�ܣ�����ʧ��
							insertlog('&#26356;&#26032;&#38431;&#21015;&#22833;&#36133;&#65292;uid:'.$userinfo['uid'].'&#22686;&#21152;&#20313;&#39069;&#22833;&#36133;&#65292;&#26356;&#26032;&#22833;&#36133;');
							echo json_encode($returnnews);
							exit;
						}
					}else {
						$returnnews = array('code'=>100,'message'=>'add log fail');//�����ռ�ʧ��
						insertlog('uid:'.$userinfo['uid'].'+&#25554;&#20837;&#25910;&#38134;&#26085;&#35760;&#22833;&#36133;');
						echo json_encode($returnnews);
						exit;
					}
				}else if($getdata['type'] == 'take') {
					$logarray['credit'] = $getdata['price'];
					$logarray['balance'] = $balance - $getdata['price'];
					if(!empty($wallet)) {
						if($wallet['balance'] >= $getdata['price']) {
							if(DB::insert('aljqb_accountchangelog',$logarray)) {
								if (DB::update('aljqb_queue',array('queuestate'=>2),array('queuestate'=>1))) {
									$res = DB::update('aljqb_wallet',array('balance'=>$logarray['balance'],'updatetime'=>time()),array('uid'=>$userinfo['uid']));
									if($res) {
										$returnnews = array('code'=>200,'message'=>'reduce balance success');//�����ɹ�

										$keyname = 'aljqb';
                                        if ($_G['cache']['plugin']['mapp_template'] && $_G['cache']['plugin']['aljhtx']
                                            && DB::fetch_first('select * from %t where type=%s', array('aljhtx_wechat_bindtemplate', 'transactionReminder'))) {
                                            require_once DISCUZ_ROOT .'source/plugin/aljhtx/class/class_aljhtx.php';
                                            $param = array(
                                                'order_subject' => $getdata['desc'],
                                                'trade_time' => dgmdate(time(),'Y-m-d H:i:s'),
                                                'trade_price' => $getdata['price'].lang("plugin/aljqb","editbalance_php_3"),
                                                'trade_orderid' => $getdata['orderid'],
                                                'order_content' => lang("plugin/aljqb","editbalance_php_4"),
                                                'type' => 'transactionReminder',
                                            );
                                            T::aljbd_notification($userinfo['uid'],$param,'plugin.php?id=aljqb');
                                        }else {
                                            notification_add($userinfo['uid'], 'system', '<a href="plugin.php?id=aljqb">' . $getdata['desc'] . '</a>', array('from_idtype' => $keyname));
                                        }
										echo json_encode($returnnews);
										exit;
									}else {
										$returnnews = array('code'=>100,'message'=>'reduce balance fail');//����ʧ��
										insertlog('uid:'.$userinfo['uid'].'&#20943;&#23569;&#20313;&#39069;&#22833;&#36133;&#65292;&#26356;&#26032;&#25968;&#25454;&#24211;&#22833;&#36133;');//�������ʧ�ܣ��������ݿ�ʧ��
										echo json_encode($returnnews);
										exit;
									}

								}else {
									$returnnews = array('code'=>100,'message'=>'reduce balance fail');//����ʧ��
									insertlog('&#26356;&#26032;&#38431;&#21015;&#22833;&#36133;&#65292;uid:'.$userinfo['uid'].'&#20943;&#23569;&#20313;&#39069;&#22833;&#36133;&#65292;&#26356;&#26032;&#25968;&#25454;&#24211;&#22833;&#36133;');
									echo json_encode($returnnews);
									exit;
								}
							}else {
								$returnnews = array('code'=>100,'message'=>'add log fail');//�����ռ�ʧ��
								insertlog('uid:'.$userinfo['uid'].'-&#25554;&#20837;&#25910;&#38134;&#26085;&#35760;&#22833;&#36133;');
								echo json_encode($returnnews);
								exit;
							}

						}else {
							$returnnews = array('code'=>500,'message'=>'balance not enough');//����
							insertlog('uid:'.$userinfo['uid'].'&#20313;&#39069;&#19981;&#36275;');
							echo json_encode($returnnews);
							exit;
						}

					}else {
						$returnnews = array('code'=>500,'message'=>'balance not enough');//����
						insertlog('uid:'.$userinfo['uid'].'&#20313;&#39069;&#19981;&#36275;');
						echo json_encode($returnnews);
						exit;
					}

				}
			}
		}else {
			$returnnews = array('code'=>100,'message'=>'queueid not exist');//queueid������
			insertlog('uid:'.$userinfo['uid'].'queueid &#19981;&#23384;&#22312;');
			echo json_encode($returnnews);
			exit;
		}
	}else {
		$returnnews = array('code'=>100,'message'=>'user not exist');//�û�������
		insertlog('&#29992;&#25143;&#19981;&#23384;&#22312;');
		echo json_encode($returnnews);
		exit;
	}

function insertlog($error) {
	DB::insert('aljqb_payorderlog',array(
		'error'=> $error,
		'time'=> time(),
	));
}
?>
