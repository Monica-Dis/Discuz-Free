<?php
	define('DISABLEXSSCHECK',true);
	require '../../../../source/class/class_core.php';
	require_once '../../../../source/plugin/aljqb/class/Queue.class.php';
	require_once '../../../../source/plugin/aljqb/class/Qbapi.class.php';
	$discuz = C::app();
	$discuz->init();
	$queue = new Queue();
	$qbapi = new Qbapi();
	$queuearray = array(
		'app_name' => addslashes($_GET['app_name']),
		'app_type' => addslashes($_GET['app_type']),
		'app_phone' => intval($_GET['app_phone']),
		'app_ip' => addslashes($_GET['app_ip']),
	);
	$curlinfo = array(
		'host' => base64_decode($_GET['host']),
		'ip' => base64_decode($_GET['ip']),
	);
	//file_put_contents('d.txt',$curlinfo['ip']."\r",FILE_APPEND);
	//file_put_contents('d.txt',gethostbyname($_SERVER['HTTP_HOST'])."\r",FILE_APPEND);
	if($curlinfo['ip'] != gethostbyname($_SERVER['HTTP_HOST'])) {
		$qbapi->insertLog($curlinfo['host'].'&#47;'.$curlinfo['ip'].'&#47;'.$getdata['app_name'].' &#35775;&#38382;&#20102; getqueue.php &#25991;&#20214;');
	}
	$key = $qbapi->createQbKey($queuearray);
	//file_put_contents('d.txt',$key."\r",FILE_APPEND);
	//file_put_contents('d.txt',$_GET['key']."\r",FILE_APPEND);
	if($_GET['key'] != $key) {
		$returnnews = array('code'=>400,'message'=>$curlinfo['host'].$queuearray['app_name'].'key error');
		echo json_encode($returnnews);
		exit;
	}
	$result = $queue-> createFirstQueueLog($queuearray);
	if($result) {
		$returnnews = array('code'=>200,'message'=>'success','queue'=>$result);
		echo json_encode($returnnews);
		exit;
	}else {
		$returnnews = array('code'=>400,'message'=>'getqueue error');
		echo json_encode($returnnews);
		exit;
	}
?>