<?php
/**
 * ͨ��֪ͨ�ӿ�
 * ====================================================
 * ֧����ɺ�΢�Ż�����֧�����û���Ϣ���͵��̻��趨��֪ͨURL��
 * �̻����ջص���Ϣ�󣬸�����Ҫ�趨��Ӧ�Ĵ������̡�
 *
*/
define('DISABLEXSSCHECK',true);
require '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
require_once '../../../../source/plugin/aljqb/class/Payment.class.php';
require_once '../../../../source/plugin/aljqb/class/Qbapi.class.php';
$qbapi = new Qbapi();
$payment = new Payment();
loadcache('plugin');
require '../../../../source/plugin/aljqb/function/function_core.php';
//�洢΢�ŵĻص�
$xml = file_get_contents("php://input");
$data = xmlToArray($xml);
if($_GET['tpOrderId']){//�ٶ�Ǯ��
	$baidu_param = $data;
	$data['out_trade_no'] = $_GET['tpOrderId'];
	$data['transaction_id'] = $_GET['orderId'];
}else{
	$data['out_trade_no'] = $data['out_trade_no']?$data['out_trade_no']:$_GET['out_trade_no'];
	$data['transaction_id'] = $data['transaction_id']?$data['transaction_id']:$_GET['trade_no'];
}

$order = $payment->fetchOrder($data['out_trade_no']);
$returnsign = $data['sign'];
$tmpdata = $data;
unset($tmpdata['sign']);
if($order['trade_type'] == 'JSAPI' || $order['trade_type'] == 'MWEB' || $order['trade_type'] == 'NATIVE'){
	$checkSign = getSign($tmpdata,$config['key']);
	$check = $checkSign == $returnsign?true:false;
	$wechat = 1;
}else if($order['trade_type'] == 'baiduboxapp'){
	$baidu = 1;
	//require_once DISCUZ_ROOT.'source/plugin/aljqb/class/baidu.class.php';
	require_once DISCUZ_ROOT.'source/plugin/aljbmm/class/baidu.class.php';
	//$rsaPriviateKeyFilePath = DISCUZ_ROOT.'source/plugin/aljqb/function/cert/baidu/rsa_private_key.pem';
	$rsaPublicKeyFilePath = DISCUZ_ROOT.'source/plugin/aljqb/function/cert/baidu/rsa_public_key.pem';
	$rsaPublicKeyStr = file_get_contents($rsaPublicKeyFilePath);
	$check = NuomiRsaSign::checkSignWithRsa($_GET, $rsaPublicKeyStr);
	//$check = true;
}else if($order['trade_type'] == 'APP'){
	$checkSign = getSign($tmpdata,$config['key2']);
	$check = $checkSign == $returnsign?true:false;
	$wechat = 1;//΢��
}else if($order['trade_type'] == 'mobileweb'){
	$check = getSignVeryfy($_GET,$_GET['sign']);
	//file_put_contents('test.txt',$check.'=>'.$_GET['sign'].',',FILE_APPEND);
	$aljqb = 1;//֧����
}else if($order['trade_type'] == 'mobileapp'){
	$check = rsaCheckV2($_POST);
	$aljqb = 1;//֧����APP֧��
}else if($order['trade_type'] == 'pcweb'){
	$check = getSignVeryfy($_GET,$_GET['sign']);
	//file_put_contents('test.txt',$check.'=>'.$_GET['sign'].',',FILE_APPEND);
	$aljqb = 1;//֧����
}
if($check){
	if($wechat){
		$returnParameters["return_code"]="SUCCESS";
	}else if($baidu){
		$returnJson = array(
			'errno' => 0,
			'msg' => 'success',
			'data'=> array(
				'isConsumed' => 2
			)
		);
	}else{
		$return = 'success';//֧����
	}
	$updatearray = array();
	if(empty($order['transaction_id'])){
		$updatearray['transaction_id'] = $data['transaction_id'];
	}
	if($order['status']<1){
		$updatearray['status'] = 1;
	}
	if($order['paytime']<1){
		$updatearray['paytime'] = TIMESTAMP;
	}
	$payment->updatePayOrder($updatearray,$data['out_trade_no']);
}else{
	if($wechat){
		$returnParameters["return_code"]="FAIL";
		$returnParameters["return_msg"]="sign faild";
	}elseif($baidu){
		$returnJson = array(
			'errno' => 0,
			'msg' => 'success',
			'data'=> array(
				'isConsumed' => 2
			)
		);
	}else{
		$return = 'fail';//֧����
	}
}
$neworder = $payment->fetchOrder($data['out_trade_no']);
if($neworder['status']) {
	$keyarray = array(
		'aljorderid'=> $neworder['aljorderid'],
		'paytime' => $neworder['paytime'],
		'orderid' => $neworder['orderid'],
		'key'=> $aljqbkey[$neworder['pluginname']][1],
	);
	//file_put_contents('test.txt',$aljqbkey[$neworder['pluginname']][1]."\r",FILE_APPEND);
	$json = json_encode($keyarray);
	$key = $qbapi->createKey($keyarray);
	$postdata = array(
		'aljorderid'=> $neworder['aljorderid'],
		'paytime' => $neworder['paytime'],
		'orderid' => $neworder['orderid'],
		'key' => $key,
	);
	//file_put_contents('test.txt',$key."\r",FILE_APPEND);
	$status = postXmlCurl($postdata,$order['nurl']);
	$status = strtolower($status);
	if($status == 'success') {
		if($wechat){
			$returnXml = arrayToXml($returnParameters);
			echo $returnXml;
			exit;
		}else{//֧����
			echo $return;
			exit;
		}
	}else {
		insertlog($order['nurl'].'&#26410;&#36820;&#22238; success');
	}
}
function insertlog($error) {
	DB::insert('aljqb_payorderlog',array(
		'error'=> $error,
		'time'=> time(),
	));
}
?>
