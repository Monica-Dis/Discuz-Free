<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/11/23
 * Time: 9:49
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_G['uid'] && ($isqianfanapp || $ismagapp)){
    if($_GET['id'] != 'aljqb'){
        require_once 'source/plugin/aljqb/class/Payment.class.php';
        require_once 'source/plugin/aljqb/class/Queue.class.php';
        require_once 'source/plugin/aljqb/class/Qbapi.class.php';
        $queue = new Queue();
        $payment = new Payment();
        $qbapi = new Qbapi();
        require 'source/plugin/aljqb/function/function_core.php';
    }
    $wallet = DB::fetch_first('select * from %t where uid=%d',array('aljqb_wallet',$_G['uid']));

    if ($wallet['balance'] > 0) {
        $tipsurl = '<a href="plugin.php?id=aljqb&act=apply" >'.lang('plugin/aljqb','aljqb_inc_php_49').'</a>';
        if (($config['autoBalanceToApp']==2&&$isqianfanapp) && $config['qianfanapp_txtype'] && $config['qianfanapp_hostname'] && $config['qianfanapp_secert']) {
            if (!discuz_process::islocked('qfBalance_' . $_G['uid'], 30)) {
                $insertarray = array(
                    'uid' => $_G['uid'],
                    'username'=> $_G['username'],
                    'account' => 'qfApp',
                    'time'=> time(),
                    'rmb' => $wallet['balance'],
                    'trans_type'=>'qfapp',
                );
                $orderparams = $payment->createTxOrder($insertarray);
                $queuearray = array(
                    'app_name' => 'aljqb',
                    'app_type' => 'tx',
                    'app_phone' => '123456789',
                    'app_ip' => '123456789',
                );
                $balancearray = array(
                    'type'=> 'take',
                    'uid'=>$_G['uid'],
                    'price' => $wallet['balance'],
                    'orderid'=> $orderparams['orderid'],
                    'desc'=> lang("plugin/aljqb","autotx_balance_toApp_php_1").$wallet['balance'].lang("plugin/aljqb","autotx_balance_toApp_php_2"),
                );
                $result = $qbapi->balance($queuearray,$balancearray);
                if($result['code'] == 200) {
                    $ret_qf = qianfanapp_auto_balance($wallet['balance']);
                    if ($ret_qf = json_decode($ret_qf, true)) {
                        if (($ret_qf['ret'] == 0 && $ret_qf['data']['balance'] > 0) || $ret_qf['code'] == 0) {
                            $updatearray = array(
                                'state' => 1,
                                'trans_orderid' => $ret_qf['data']['record_id'] ? : ($ret_qf['data']['order_id'] ? $ret_qf['data']['order_id'] : 'qf_app_'.$ret_qf[time]),
                                'trans_time'=> time(),
                                'desca' => lang("plugin/aljqb","autotx_balance_toApp_php_3"),
                            );
                            DB::update('aljqb_order',$updatearray,array('orderid' => $orderparams['orderid']));
                            notification_add($_G['uid'], 'system',lang("plugin/aljqb","autotx_balance_toApp_php_4").$orderparams['orderid'].lang("plugin/aljqb","autotx_balance_toApp_php_5").$rmb.lang("plugin/aljqb","autotx_balance_toApp_php_6").$tipsurl,array('from_idtype'=>'aljqb'));
                        }
                    }
                    $result_log = diconv(var_export($_retma, true), 'utf-8', CHARSET);
                    $queue->insertLog($result_log);
                }
            }
        } elseif ($config['autoBalanceToApp']==1 && $ismagapp && $config['magapp_url'] && $config['magapp_secret']) {
            if (!discuz_process::islocked('mgBalance_' . $_G['uid'], 30)) {
                $insertarray = array(
                    'uid' => $_G['uid'],
                    'username'=> $_G['username'],
                    'account' => 'magApp',
                    'time'=> time(),
                    'rmb' => $wallet['balance'],
                    'trans_type'=>'magapp',
                );
                $orderparams = $payment->createTxOrder($insertarray);
                $queuearray = array(
                    'app_name' => 'aljqb',
                    'app_type' => 'tx',
                    'app_phone' => '123456789',
                    'app_ip' => '123456789',
                );
                $balancearray = array(
                    'type'=> 'take',
                    'uid'=>$_G['uid'],
                    'price' => $wallet['balance'],
                    'orderid'=> $orderparams['orderid'],
                    'desc'=> lang("plugin/aljqb","autotx_balance_toApp_php_7").$wallet['balance'].lang("plugin/aljqb","autotx_balance_toApp_php_8"),
                );
                $result = $qbapi->balance($queuearray,$balancearray);
                if($result['code'] == 200) {
                    $ret_mag = magapp_auto_balance($wallet['balance'],$orderparams['orderid']);
                    $ret_mag = json_decode($ret_mag, true);
                    if ($ret_mag['success']) {
                        $updatearray = array(
                            'state' => 1,
                            'trans_orderid' => '',
                            'trans_time'=> time(),
                            'desca' => lang("plugin/aljqb","autotx_balance_toApp_php_9"),
                        );
                        DB::update('aljqb_order',$updatearray,array('orderid' => $orderparams['orderid']));
                        notification_add($_G['uid'], 'system',lang("plugin/aljqb","autotx_balance_toApp_php_10").$orderparams['orderid'].lang("plugin/aljqb","autotx_balance_toApp_php_11").$rmb.lang("plugin/aljqb","autotx_balance_toApp_php_12").$tipsurl,array('from_idtype'=>'aljqb'));
                    }
                    $result_log = diconv(var_export($ret_mag, true), 'utf-8', CHARSET);
                    $queue->insertLog($result_log);
                }
            }
        }
    }
}