<?php
	define('DISABLEXSSCHECK',true);
	require '../../../../source/class/class_core.php';
	$discuz = C::app();
	$discuz->init();
	loadcache('plugin');
	$config = $_G['cache']['plugin']['aljqb'];
	require_once '../../../../source/plugin/aljqb/class/Qbapi.class.php';
	$qbapi = new Qbapi();
	$keyarray = array(
		'aljorderid'=> $_GET['aljorderid'],
		'paytime' => $_GET['paytime'],
		'orderid' => $_GET['orderid'],
		'key'=> $config['qbkey'],
	);
	$key = $qbapi->createKey($keyarray);
	//file_put_contents('d.txt',$key."\r",FILE_APPEND);
	//file_put_contents('d.txt',$_GET['key']."\r",FILE_APPEND);
	if($key == $_GET['key']) {
		$rechargeorder = DB::fetch_first('select * from %t where orderid=%s',array('aljqb_rechargeorder',$_GET['orderid']));
		if($rechargeorder['status'] != 0){
		    $error = '&#27492;&#35746;&#21333;&#24050;&#32463;&#20805;&#20540;&#36807;'.$_GET['orderid'];
            insertlog(unescape($error));
            echo 'success';
            exit;
        }
		$queuearray = array(
			'app_name' => 'aljqb',
			'app_type' => 'qbcharge',
			'app_phone' => '123456789',
			'app_ip' => '123456789',
		);
		$price = substr(sprintf("%.3f",$rechargeorder['price']),0,-1);
		$desc = '&#29992;&#25143;'.$rechargeorder['username'].'&#20805;&#20540;'.$price.'&#20803;';
		$balancearray = array(
			'type'=> 'charge',
			'uid'=>$rechargeorder['uid'],
			'price' => $price,
			'orderid'=> $rechargeorder['orderid'],
			'desc'=> unescape($desc),
		);
		$result = $qbapi->balance($queuearray,$balancearray);
		if($result['code'] == 200) {
			$updatearray =array(
				'paytime' => $_GET['paytime'],
				'aljqb_orderid' => $_GET['aljorderid'],
				'status'=>1,
			);
			DB::update('aljqb_rechargeorder',$updatearray,array('orderid'=> $_GET['orderid']));
			DB::query('update %t set rechargenumber=rechargenumber+1',array('aljqb_wallet'));
			if($_G['cache']['plugin']['aljhhr']['is_aljhhr']){
				$order = array(
					'uid'=>$rechargeorder['uid'],
					'username'=>$rechargeorder['username'],
					'orderid'=>$rechargeorder['orderid'],
					'price'=>$price,
					'stitle'=>unescape($desc)
				);
                $hhr_path = DISCUZ_ROOT . "source/plugin/aljhhr/function/function.php";
                if(is_file($hhr_path)){
                    include_once $hhr_path;
                    hhrDivideInto($order,'aljqb');
                }
            }
			echo 'success';
			exit;
		}
		
	}
function unescape($str) {
	if(is_array($str)) {
		foreach($str as $tmp_key=> $tmp_value) {
			$str[$tmp_key] = unicode_decode($tmp_value);
		}
		return $str;
	}else {
		return unicode_decode($str);
	}  
}
function unicode_decode($str) {
	$str = rawurldecode($str);
	preg_match_all("/(?:%u.{4})|&#x.{4};|&#\d+;|.+/U",$str,$r);
	$ar = $r[0];
	foreach($ar as $k=>$v) {
		if(substr($v,0,2) == "%u"){
			if(strtolower(CHARSET) == 'gbk'){
				$ar[$k] = iconv("UCS-2BE","gbk",pack("H4",substr($v,-4)));
			}else {
				$ar[$k] = iconv("UCS-2BE","UTF-8",pack("H4",substr($v,-4)));
			}
			
		}
		elseif(substr($v,0,3) == "&#x"){
			if(strtolower(CHARSET) == 'gbk'){
				$ar[$k] = iconv("UCS-2BE","gbk",pack("H4",substr($v,3,-1)));
			}else{
				$ar[$k] = iconv("UCS-2BE","UTF-8",pack("H4",substr($v,3,-1)));
			}
		}
		elseif(substr($v,0,2) == "&#") {
			if(strtolower(CHARSET) == 'gbk'){
				$ar[$k] = iconv("UCS-2BE","gbk",pack("n",substr($v,2,-1)));
			}else{
				$ar[$k] = iconv("UCS-2BE","UTF-8",pack("n",substr($v,2,-1)));
			}	
		}
	}
	return join("",$ar);
}
function insertlog($error) {
    DB::insert('aljqb_payorderlog',array(
        'error'=> $error,
        'time'=> time(),
    ));
}
?>