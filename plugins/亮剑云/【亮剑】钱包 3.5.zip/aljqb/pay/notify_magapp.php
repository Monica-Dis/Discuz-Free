<?php
define('DISABLEXSSCHECK',true);
require '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
require_once '../../../../source/plugin/aljqb/class/Payment.class.php';
require_once '../../../../source/plugin/aljqb/class/Qbapi.class.php';
$qbapi = new Qbapi();
$payment = new Payment();
loadcache('plugin');
require '../../../../source/plugin/aljqb/function/function_core.php';
$order = $payment->fetchOrder($_GET['out_trade_no']);
if($order['trade_mod'] == 'magapp' && $_GET['sign'] == md5($_GET['out_trade_no'].$_GET['paytime'].$_GET['orderid'].$config['magapp_secret'])){
    $unionOrderNum = $order['transaction_id'];
    if($unionOrderNum && $order['status'] == 0) {
        $ret = magapppay_query($unionOrderNum);
        if($ret['paycode'] == 2 || $ret['paycode'] == 1) {
            if ($order['status'] < 1) {
                $updatearray['status'] = 1;
            }
            if ($order['paytime'] < 1) {
                $updatearray['paytime'] = TIMESTAMP;
            }
            $payment->updatePayOrder($updatearray, $_GET['out_trade_no']);
            $neworder = $payment->fetchOrder($_GET['out_trade_no']);
            if ($neworder['status']) {
                $keyarray = array(
                    'aljorderid' => $neworder['aljorderid'],
                    'paytime' => $neworder['paytime'],
                    'orderid' => $neworder['orderid'],
                    'key' => $aljqbkey[$neworder['pluginname']][1],
                );
                //file_put_contents('test.txt',$aljqbkey[$neworder['pluginname']][1]."\r",FILE_APPEND);
                $json = json_encode($keyarray);
                $key = $qbapi->createKey($keyarray);
                $postdata = array(
                    'aljorderid' => $neworder['aljorderid'],
                    'paytime' => $neworder['paytime'],
                    'orderid' => $neworder['orderid'],
                    'key' => $key,
                );
                //file_put_contents('test.txt',$key."\r",FILE_APPEND);
                $status = postXmlCurl($postdata, $order['nurl']);
                $status = strtolower($status);
                if ($status != 'success') {
                    $qbapi->insertLog($order['nurl'] . lang("plugin/aljqb","aljqb_inc_php_115").' success');
                }
            }
        }
    }
}
echo 'SUCCESS';
EXIT;