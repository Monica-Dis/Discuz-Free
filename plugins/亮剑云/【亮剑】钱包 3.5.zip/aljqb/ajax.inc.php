<?php
/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_G['groupid']!=1){
	exit;
}
require_once 'source/plugin/aljqb/class/Qbapi.class.php';
require_once 'source/plugin/aljqb/class/Queue.class.php';
$queue = new Queue();
$qbapi = new Qbapi();

require_once 'source/plugin/aljqb/function/function_core.php';
//���ܲ�ͨ���ı�stateΪ1
if($_GET['act'] == 'pass'){
    $order=DB::fetch_first('select * from %t where orderid=%s',array('aljqb_order',$_GET['orderid']));
	$wallet = DB::fetch_first('select * from %t where uid=%d',array('aljqb_wallet',$order['uid']));
	if($order){
        if(strtolower(CHARSET) == 'gbk'){
            $_GET['desc'] = diconv($_GET['desc'],'utf-8','gbk');
        }
		if($config['openauto']) {
            $tipsurl = '<a href="plugin.php?id=aljqb&act=apply" > '.lang('plugin/aljqb','aljqb_inc_php_49').'</a>';
            if($order['trans_type'] == 'qfapp'){
                $ret_qf = qianfanapp_auto_balance($order['rmb'],$order['uid']);
                if ($ret_qf = json_decode($ret_qf, true)) {
                    if (($ret_qf['ret'] == 0 && $ret_qf['data']['balance'] > 0) || $ret_qf['code'] == 0) {
                        $updatearray = array(
                            'state' => 1,
                            'trans_orderid' => $ret_qf['data']['record_id'] ? : ($ret_qf['data']['order_id'] ? $ret_qf['data']['order_id'] : 'qf_app_'.$ret_qf[time]),
                            'trans_time'=> time(),
                            'desca' => lang("plugin/aljqb","ajax_inc_php_1"),
                        );
                        DB::update('aljqb_order',$updatearray,array('orderid' => $order['orderid']));
                        notification_add($_G['uid'], 'system',lang("plugin/aljqb","ajax_inc_php_2").$order['orderid'].lang("plugin/aljqb","ajax_inc_php_3").$rmb.lang("plugin/aljqb","ajax_inc_php_4").$tipsurl,array('from_idtype'=>'aljqb'));
                    }
                }
                $result_log = diconv(var_export($ret_qf, true), 'utf-8', CHARSET);
                insertLog($result_log);
            }else if($order['trans_type'] == 'magapp'){
                $ret_mag = magapp_auto_balance($order['rmb'],$order['orderid'],$order['uid']);
                $ret_mag = json_decode($ret_mag, true);
                if ($ret_mag['success']) {
                    $updatearray = array(
                        'state' => 1,
                        'trans_orderid' => '',
                        'trans_time'=> time(),
                        'desca' => lang("plugin/aljqb","ajax_inc_php_5"),
                    );
                    DB::update('aljqb_order',$updatearray,array('orderid' => $order['orderid']));
                    notification_add($_G['uid'], 'system',lang("plugin/aljqb","ajax_inc_php_6").$order['orderid'].lang("plugin/aljqb","ajax_inc_php_7").$rmb.lang("plugin/aljqb","ajax_inc_php_8").$tipsurl,array('from_idtype'=>'aljqb'));
                }
                $result_log = diconv(var_export($ret_mag, true), 'utf-8', CHARSET);
                insertLog($result_log);
            }else{
                if(!$config['wxtrans']) { //֧�����Զ�ת�˹���ʵ��
                    if($order['cashid']) {
                        $useracount=DB::fetch_first('select * from %t where cashid=%d',array('aljqb_cashtype',$order['cashid']));
                    }else {
                        $useracount['real_name'] = '';
                    }
                    $message = unescape_aljqb('&#23457;&#26680;&#25104;&#21151;&#44;&#33258;&#21160;&#36716;&#36134;');
                    $result = alipaytrans($order['orderid'], $order['account'], $order['rmb'],$config['zhifubeizhu'],$config['fukuanname'],$useracount['real_name']);
                    if(strtolower(CHARSET) == 'gbk'){
                        $result_log =  diconv($result, 'utf-8', 'gbk');
                    }else {
                        $result_log = $result;
                    }
                    insertLog($result_log);
                    $result = json_decode($result,true);
                    $result = $result['alipay_fund_trans_toaccount_transfer_response'];
                    if($result['code'] == 10000) {
                        $updatearray = array(
                            'state' => 1,
                            'trans_orderid' => $result['order_id'],
                            'trans_time'=> $result['pay_date'],
                            'desca' => $_GET['desc'],
                        );
                        DB::update('aljqb_order',$updatearray,array('orderid' => $result['out_biz_no']));
                        notification_add($order['uid'], 'system','&#35746;&#21333;'.$order['order_id'].'&#24050;&#36890;&#36807;&#23457;&#26680;&#44;&#36716;&#36134;'.$order['rmb'].'&#20803;&#25104;&#21151;',array('from_idtype'=>'aljqb'));
                        $tips = array('status'=>1);
                        echo json_encode(ajaxPostCharSet_aljqb($tips));
                        exit;
                    }else {
                        $tips = array('status'=>0);
                        echo json_encode(ajaxPostCharSet_aljqb($tips));
                        exit;
                    }
                }else {//΢���Զ�ת��
                    $wxdata = array(
                        'amount'=>$order['rmb'],
                        'openid'=>$wallet['openid'],
                        'orderid'=>$order['orderid'],
                        'desc'=>$config['fukuanname'].$config['zhifubeizhu'],
                    );
                    if(!$wallet['openid']){
                        insertLog('openid '.lang("plugin/aljqb","ajax_inc_php_9"));
                        $tips = array('status'=>0);
                        echo json_encode(ajaxPostCharSet_aljqb($tips));
                        exit;
                    }
                    $result = ajaxGetCharSet_aljqb(wxchattransfers($wxdata));

                    if($result['result_code'] == 'SUCCESS') {
                        $updatearray = array(
                            'state' => 1,
                            'trans_orderid' => $result['payment_no'],
                            'trans_time'=> $result['payment_time'],
                            'desca' => $_GET['desc'],
                        );
                        DB::update('aljqb_order',$updatearray,array('orderid' => $result['partner_trade_no']));
                        notification_add($order['uid'], 'system','&#35746;&#21333;'.$order['order_id'].'&#24050;&#36890;&#36807;&#23457;&#26680;&#44;&#36716;&#36134;'.$order['rmb'].'&#20803;&#25104;&#21151;',array('from_idtype'=>'aljqb'));
                        $tips = array('status'=>1);
                        echo json_encode(ajaxPostCharSet_aljqb($tips));
                        exit;
                    }else {
                        $result_log = dimplode($result);
                        insertLog($result_log);
                        $tips = array('status'=>0);
                        echo json_encode(ajaxPostCharSet_aljqb($tips));
                        exit;
                    }
                }
            }

		}else {
			$updatearray = array(
				'state' => 1,
				'desca' => $_GET['desc'],
			);
			DB::update('aljqb_order',$updatearray,array('orderid' => $_GET['orderid']));
			notification_add($order['uid'], 'system','&#35746;&#21333;'.$order['order_id'].'&#24050;&#36890;&#36807;&#23457;&#26680;&#44;&#36716;&#36134;'.$order['rmb'].'&#20803;&#25104;&#21151;',array('from_idtype'=>'aljqb'));
			$tips = array('status'=>1);
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
	}else{
        $tips = array('status'=>0);
		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
    }
}//��ͨ���ı�stateΪ2
else if($_GET['act'] == 'fail'){
	$userorder=DB::fetch_first('select * from %t where orderid=%s',array('aljqb_order',$_GET['orderid']));
	if($userorder){
        if(strtolower(CHARSET) == 'gbk'){
            $_GET['desc'] = diconv($_GET['desc'],'utf-8','gbk');
        }
		$queuearray = array(
			'app_name' => 'aljqb',
			'app_type' => 'txfail',
			'app_phone' => '123456789',
			'app_ip' => '123456789',
		);
		$balancearray = array(
			'type'=> 'charge',
			'uid'=>$userorder['uid'],
			'price' => $userorder['rmb']+$userorder['fee'],
			'orderid'=> $userorder['orderid'],
			'desc'=> unescape_aljqb('&#23457;&#26680;&#26410;&#36890;&#36807;&#44;&#35299;&#20923;&#20313;&#39069;'),
		);
		if(DB::update('aljqb_order',array('state'=>2,'desca'=>$_GET['desc']),array('orderid'=>$userorder['orderid']))) {
			$result = $qbapi->balance($queuearray,$balancearray);
			if($result['code'] == '200') {
				notification_add($userorder['uid'], 'system','&#35746;&#21333;'.$userorder['orderid'].'&#23457;&#26680;&#26410;&#36890;&#36807;&#44;&#35299;&#20923;&#20313;&#39069;'.($userorder['rmb']+$userorder['fee']).'&#20803;&#65292;&#22791;&#27880;&#58;'.$_GET['desc'],array('from_idtype'=>'aljqb'));
				$tips = array('status'=>1);
				echo json_encode(ajaxPostCharSet_aljqb($tips));
				exit;
			}else {
				DB::update('aljqb_order',array('state'=>0,'desca'=>''),array('orderid'=>$userorder['orderid']));
				$tips = array('status'=>0,'message'=>$result['message']);
				echo json_encode(ajaxPostCharSet_aljqb($tips));
				exit;
			}
		}else {
			$tips = array('status'=>0);
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
       
    }else{
        $tips = array('status'=>0);
		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
    }
}else if($_GET['act']  == 'editbalance') {
	$uid = intval($_GET['uid']);
	$type = $_GET['type'];
	$price = $_GET['price'] + 0;
	$price = substr(sprintf("%.3f",$price),0,-1);
	if($price<=0) {
		$tips = array('status'=>1,'message'=>'&#37329;&#39069;&#19981;&#24471;&#23567;&#20110;&#31561;&#20110;0');//����С��0
		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
	}
	if(strtolower(CHARSET) == 'gbk'){
		$_GET['liyou'] = diconv($_GET['liyou'],'utf-8','gbk');
	}
	if($type == 'charge') {
		$desc = '&#31649;&#29702;&#21592;&#58;'.$_G['username'].'&#40;'.$_G['uid'].'&#41;&#32473;&#35813;&#29992;&#25143;&#22686;&#21152;&#20313;&#39069;'.$price.'&#20803;';
		if($_GET['liyou']){
			$desc .= '-'.$_GET['liyou'];
		}
		$queuearray = array(
			'app_name' => 'system',
			'app_type' => 'systemadd',
			'app_phone' => '123456789',
			'app_ip' => '123456789',
		);
		$balancearray = array(
			'type'=> 'charge',
			'uid'=>$uid,
			'price' => $price,
			'orderid'=> 'GM'.time().'rd'.random(6),
			'desc'=> unescape_aljqb($desc),
		);
		$result = $qbapi->balance($queuearray,$balancearray);
		if($result['code'] == 200) {
			$tips = array('status'=>1,'message'=>'&#22686;&#21152;&#20313;&#39069;&#25104;&#21151;');
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}else {
			$tips = array('status'=>0,'message'=>'&#22686;&#21152;&#20313;&#39069;&#22833;&#36133;');
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
	}else {
		$wallet = DB::fetch_first('select * from %t where uid=%d',array('aljqb_wallet',$uid));
		if($wallet['balance'] < $price) {
			$tips = array('status'=>1,'message'=>'&#20313;&#39069;&#19981;&#36275;');//����
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
		$desc = '&#31649;&#29702;&#21592;&#58;'.$_G['username'].'&#40;'.$_G['uid'].'&#41;&#32473;&#35813;&#29992;&#25143;&#20943;&#23569;&#20313;&#39069;'.$price.'&#20803;';
		if($_GET['liyou']){
			$desc .= '-'.$_GET['liyou'];
		}
		$queuearray = array(
			'app_name' => 'system',
			'app_type' => 'systemreduce',
			'app_phone' => '123456789',
			'app_ip' => '123456789',
		);
		$balancearray = array(
			'type'=> 'take',
			'uid'=>$uid,
			'price' => $price,
			'orderid'=> 'GM'.time().'rd'.random(6),
			'desc'=> unescape_aljqb($desc),
		);
		$result = $qbapi->balance($queuearray,$balancearray);
		if($result['code'] == 200) {
			$tips = array('status'=>1,'message'=>'&#25187;&#38500;&#20313;&#39069;&#25104;&#21151;');
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}else {
			$tips = array('status'=>0,'message'=>'&#25187;&#38500;&#20313;&#39069;&#22833;&#36133;');
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
	}
}else if($_GET['act'] == 'setpassword'){
    $password = intval($_GET['password']);
    if(!$password) {
        $tips = array('status'=>0,'message'=>lang("plugin/aljqb","ajax_inc_php_10"));
        echo json_encode(ajaxPostCharSet_aljqb($tips));
        exit;
    }
    if(!is_numeric($password)) {
        $tips = array(
            'status'=>0,
            'message'=>lang("plugin/aljqb","ajax_inc_php_11")
        );
        echo json_encode(ajaxPostCharSet_aljqb($tips));
        exit;
    }else {
        $len = strlen($password);
        if($len !=6) {
            $tips = array(
                'status'=>0,
                'message'=>lang("plugin/aljqb","ajax_inc_php_12")
            );
            echo json_encode(ajaxPostCharSet_aljqb($tips));
            exit;
        }
    }
    $updataarray['password'] = md5($password);
    $uid = intval($_GET['uid']);

    if(DB::update('aljqb_wallet',$updataarray,array('uid'=> $uid))){
        $tips = array(
            'status'=>1,
            'message'=>lang("plugin/aljqb","ajax_inc_php_13"),
        );
        echo json_encode(ajaxPostCharSet_aljqb($tips));
        exit;
    }else {
        $tips = array(
            'status'=>0,
            'message'=>lang("plugin/aljqb","ajax_inc_php_14")
        );
        echo json_encode(ajaxPostCharSet_aljqb($tips));
        exit;
    }
}else if($_GET['act'] == 'setmobile'){
	$phone = intval($_GET['phone']);
    if(!$phone) {
        $tips = array('status'=>0,'message'=>lang("plugin/aljqb","ajax_inc_php_15"));
        echo json_encode(ajaxPostCharSet_aljqb($tips));
        exit;
    }
    if(!is_numeric($phone)) {
        $tips = array(
            'status'=>0,
            'message'=>lang("plugin/aljqb","ajax_inc_php_16")
        );
        echo json_encode(ajaxPostCharSet_aljqb($tips));
        exit;
    }else {
        $len = strlen($phone);
        if($len !=11) {
            $tips = array(
                'status'=>0,
                'message'=>lang("plugin/aljqb","ajax_inc_php_17")
            );
            echo json_encode(ajaxPostCharSet_aljqb($tips));
            exit;
        }
    }
    $updataarray['phone'] = $phone;
    $uid = intval($_GET['uid']);

    if(DB::update('aljqb_wallet',$updataarray,array('uid'=> $uid))){
        $tips = array(
            'status'=>1,
            'message'=>lang("plugin/aljqb","diary_inc_php_1"),
        );
        echo json_encode(ajaxPostCharSet_aljqb($tips));
        exit;
    }else {
        $tips = array(
            'status'=>0,
            'message'=>lang("plugin/aljqb","ajax_inc_php_18")
        );
        echo json_encode(ajaxPostCharSet_aljqb($tips));
        exit;
    }
}
//תΪ��ǰ����������
function ajaxGetCharSet_aljqb($arr) {
	if(is_array($arr)){
		if (strtolower(CHARSET) == 'gbk') {
			foreach ($arr as $key => $val) {
				if(is_array($val)){
					$pt_goods[$key] = ajaxGetCharSet_aljqb($val);
				}else{
					$pt_goods[$key] = diconv($val,'utf-8','gbk');
				}

			}
			return $pt_goods;
		}
		return $arr;
	} else {
		if (strtolower(CHARSET) == 'gbk') {
			return diconv($arr,'utf-8','gbk');
		}
		return $arr;
	}

}

function ajaxPostCharSet_aljqb($arr) {
	if(is_array($arr)){
		if (strtolower(CHARSET) == 'gbk') {
			foreach ($arr as $key => $val) {
				if(is_array($val)){
					$pt_goods[$key] = ajaxPostCharSet_aljqb($val);
				}else{
					$pt_goods[$key] = diconv($val,'gbk','utf-8');
				}

			}
			return $pt_goods;
		}
		return $arr;
	} else {
		if (strtolower(CHARSET) == 'gbk') {
			return diconv($arr,'gbk','utf-8');
		}
		return $arr;
	}

}
function unescape_aljqb($str) {
	if(is_array($str)) {
		foreach($str as $tmp_key=> $tmp_value) {
			$str[$tmp_key] = unicode_decode_aljqb($tmp_value);
		}
		return $str;
	}else {
		return unicode_decode_aljqb($str);
	}  
}
function unicode_decode_aljqb($str) {
	$str = rawurldecode($str);
	preg_match_all("/(?:%u.{4})|&#x.{4};|&#\d+;|.+/U",$str,$r);
	$ar = $r[0];
	foreach($ar as $k=>$v) {
		if(substr($v,0,2) == "%u"){
			if(strtolower(CHARSET) == 'gbk'){
				$ar[$k] = iconv("UCS-2BE","gbk",pack("H4",substr($v,-4)));
			}else {
				$ar[$k] = iconv("UCS-2BE","UTF-8",pack("H4",substr($v,-4)));
			}
			
		}
		elseif(substr($v,0,3) == "&#x"){
			if(strtolower(CHARSET) == 'gbk'){
				$ar[$k] = iconv("UCS-2BE","gbk",pack("H4",substr($v,3,-1)));
			}else{
				$ar[$k] = iconv("UCS-2BE","UTF-8",pack("H4",substr($v,3,-1)));
			}
		}
		elseif(substr($v,0,2) == "&#") {
			if(strtolower(CHARSET) == 'gbk'){
				$ar[$k] = iconv("UCS-2BE","gbk",pack("n",substr($v,2,-1)));
			}else{
				$ar[$k] = iconv("UCS-2BE","UTF-8",pack("n",substr($v,2,-1)));
			}	
		}
	}
	return join("",$ar);
}
function insertlog($error) {
	DB::insert('aljqb_payorderlog',array(
		'error'=> $error,
		'time'=> time(),
	));
}
?>