<?php
/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_G['groupid']!=1){
	exit;
}
if($_GET['act'] == 'blacklist'){
	if(submitcheck('formhash')){
		if(submitcheck('pullblack')) {
			if(is_array($_GET['blacklist'])) {
				foreach($_GET['blacklist'] as $id) {
					DB::update('aljqb_wallet',array('pullblack'=>1),array('id'=>$id));
				}
			}
		}else {
			if(is_array($_GET['blacklist'])) {
				foreach($_GET['blacklist'] as $id) {
					DB::update('aljqb_wallet',array('pullblack'=>0),array('id'=>$id));
				}
			}
		}

		cpmsg("aljqb:walletuser_inc_php_1",'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljqb&pmod=walletuser&page='.$_GET['page'].'&username='.$_GET['username'].'&phone='.$_GET['phone']);
	}
}else{
	$usernum = DB::result_first('select count(*) from %t',array('aljqb_wallet'));
	$blacknum = DB::result_first('select count(*) from %t where pullblack=1',array('aljqb_wallet'));
	$currpage = $_GET['page'] ? intval($_GET['page']) : 1;
	$perpage = 20;
	$start = ($currpage - 1) * $perpage;
	$where  = 'where 1 ';
	$conn = array('aljqb_wallet');
	if($_GET['black']){
		$where .= ' and pullblack=%d ';
		$conn[] = 1;
	}else{
		$where .= ' and pullblack=%d ';
		$conn[] = 0;
	}
	if($_GET['phone']){
		$where .= ' and phone=%d ';
		$conn[] = $_GET['phone'];
	}
	if($_GET['balance']){
		$where .= ' and balance>=%i ';
		$conn[] = $_GET['balance'];
	}
	if($_GET['uid']){
		$where .= ' and uid=%d ';
		$conn[] = $_GET['uid'];
	}
	if($_GET['username']){
		$where .= ' and username like %i ';
		$conn[] = "'%".$_GET['username']."%'";
	}
	$num = DB::result_first('select count(*) from %t '.$where,$conn);
	$balance = DB::result_first('select sum(balance) from %t '.$where,$conn);
	$today = strtotime(date('Y-m-d', time()));
	$tadduser = DB::result_first('select count(*) from %t where createtime>=%i',array('aljqb_wallet',$today));
	$twoadduser = DB::result_first('select count(*) from %t where createtime>=%i and createtime<%i',array('aljqb_wallet',$today-86400,$today));
	$oneactnum = DB::result_first('select count(*) from %t where updatetime>=%i',array('aljqb_wallet',$today));
	$onebalance = DB::result_first('select sum(balance) from %t where updatetime>=%i',array('aljqb_wallet',$today));
	$sanactnum = DB::result_first('select count(*) from %t where updatetime>=%i',array('aljqb_wallet',$today-172800));
	$sanbalance = DB::result_first('select sum(balance) from %t where updatetime>=%i',array('aljqb_wallet',$today-172800));
	$qiactnum = DB::result_first('select count(*) from %t where updatetime>=%i',array('aljqb_wallet',$today-518400));
	$qibalance = DB::result_first('select sum(balance) from %t where updatetime>=%i',array('aljqb_wallet',$today-518400));
	$where .=  'order by id desc limit %d,%d';
	$conn[] = $start;
	$conn[] = $perpage;
	$walletlist = DB::fetch_all('select * from %t '.$where,$conn);
	$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljqb&pmod=walletuser&username='.$_GET['username'].'&phone='.$_GET['phone'].'&balance='.$_GET['balance'].'&black='.$_GET['black'], 0, 11, false, false);
	include template('aljqb:walletuser');
}
//From: Dism_taobao-com
?>
