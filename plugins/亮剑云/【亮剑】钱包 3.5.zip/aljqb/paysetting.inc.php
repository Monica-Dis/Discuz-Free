<?php

/*
 * ����: Discuz!�����ƹ�����
 * ����֧��: https://dism.taobao.com?/
 * ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$_GET=dhtmlspecialchars($_GET);

if(submitcheck('formhash')){
	$record = C::t('#aljqb#aljqb_paysetting')->fetch('logo');
	
	foreach($_GET['settingsnew'] as $k=>$v){
		if(!C::t('#aljqb#aljqb_paysetting')->fetch($k)){
			C::t('#aljqb#aljqb_paysetting')->insert(array('key'=>$k,'value'=>trim($v)));
		}else{
			C::t('#aljqb#aljqb_paysetting')->update_value_by_key(trim($v),$k);
		}
	}
	cpmsg("aljqb:paysetting_inc_php_1", 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljqb&pmod=paysetting', 'succeed');
}else{
	$settings=C::t('#aljqb#aljqb_paysetting')->range();
	include template('aljqb:paysetting');
}
?>