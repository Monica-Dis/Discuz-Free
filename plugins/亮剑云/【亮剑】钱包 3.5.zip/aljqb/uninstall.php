<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
/*
 * Copyright (c) 2021 by dism.taobao.com
 * 技术支持: https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//start to put your own code 
$sql = <<<EOF
DROP TABLE IF  EXISTS `pre_aljqb_accountchangelog`;
DROP TABLE IF  EXISTS `pre_aljqb_cashtype`;
DROP TABLE IF  EXISTS `pre_aljqb_order`;
DROP TABLE IF  EXISTS `pre_aljqb_paysetting`;
DROP TABLE IF  EXISTS `pre_aljqb_queue`;
DROP TABLE IF  EXISTS `pre_aljqb_rechargeorder`;
DROP TABLE IF  EXISTS `pre_aljqb_wallet`;
DROP TABLE IF  EXISTS `pre_aljqb_payorderlog`;
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>