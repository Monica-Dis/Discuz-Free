<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
/*
 * 作�?: Discuz!亮剑工作�?
 * 技术支�?: https://dism.taobao.com
 * 客服QQ: 190360183
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljqb_accountchangelog` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `credit` double(15,2) NOT NULL,
  `time` char(50) NOT NULL,
  `orderid` varchar(255) NOT NULL,
  `queueid` varchar(255) NOT NULL,
  `balance` double(15,2) NOT NULL,
  `type` varchar(255) NOT NULL,
  `desc` text NOT NULL,
  `app_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `credit` (`credit`),
  KEY `orderid` (`orderid`),
  KEY `app_name` (`app_name`),
  KEY `type` (`type`)
);
CREATE TABLE IF NOT EXISTS `pre_aljqb_cashtype` (
  `cashid` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `cashtype` varchar(255) NOT NULL,
  `account` varchar(255) NOT NULL,
  `real_name` varchar(255) NOT NULL,
  PRIMARY KEY (`cashid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljqb_order` (
  `orderid` varchar(255) NOT NULL,
  `trans_orderid` varchar(255) NOT NULL,
  `trans_time` varchar(255) NOT NULL,
  `uid` int(8) unsigned NOT NULL,
  `username` char(50) NOT NULL,
  `account` char(50) NOT NULL,
  `cashid` int(10) NOT NULL,
  `time` char(50) NOT NULL,
  `rmb` double(15,2) NOT NULL,
  `state` int(8) NOT NULL,
  `admindesc` varchar(255) NOT NULL,
  `desca` varchar(255) NOT NULL,
  `trans_type` varchar(255) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  PRIMARY KEY (`orderid`),
  KEY `time` (`time`)
);
CREATE TABLE IF NOT EXISTS `pre_aljqb_payorder` (
  `aljorderid` varchar(255) NOT NULL,
  `orderid` varchar(255) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `pluginname` varchar(255) NOT NULL,
  `openid` varchar(255) NOT NULL,
  `createtime` int(10) NOT NULL,
  `overtime` varchar(255) NOT NULL,
  `paytime` int(10) NOT NULL,
  `trade_mod` char(50) NOT NULL,
  `trade_type` char(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `rurl` varchar(255) NOT NULL,
  `nurl` varchar(255) NOT NULL,
  `status` tinyint(3) NOT NULL,
  PRIMARY KEY (`aljorderid`),
  KEY `createtime` (`createtime`)
);
CREATE TABLE IF NOT EXISTS `pre_aljqb_paysetting` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`key`)
);
CREATE TABLE IF NOT EXISTS `pre_aljqb_queue` (
  `queueid` varchar(255) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `app_type` varchar(255) NOT NULL,
  `createtime` varchar(255) NOT NULL,
  `queuestate` int(11) NOT NULL,
  PRIMARY KEY (`queueid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljqb_rechargeorder` (
  `orderid` varchar(255) NOT NULL,
  `aljqb_orderid` varchar(255) NOT NULL,
  `ordertype` varchar(255) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `createtime` varchar(255) NOT NULL,
  `paytime` varchar(255) NOT NULL,
  `price` double(15,2) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` varchar(255) NOT NULL,
  `status` tinyint(3) NOT NULL,
  PRIMARY KEY (`orderid`),
  KEY `createtime` (`createtime`)
);
CREATE TABLE IF NOT EXISTS `pre_aljqb_wallet` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` bigint(11) NOT NULL,
  `balance` double(10,2) NOT NULL,
  `openid` varchar(255) NOT NULL,
  `nickname` char(50) NOT NULL,
  `subscribe` int(10) NOT NULL,
  `sex` int(10) NOT NULL,
  `city` varchar(255) NOT NULL,
  `unionid` varchar(255) NOT NULL,
  `createtime` varchar(255) NOT NULL,
  `updatetime` varchar(255) NOT NULL,
  `rechargenumber` int(10) NOT NULL,
  `pullblack` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljqb_secretkey` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pluginname` varchar(255) NOT NULL,
  `secretkey` varchar(255) NOT NULL,
  `tokenurl` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pluginname` (`pluginname`)
);
CREATE TABLE IF NOT EXISTS `pre_aljqb_payorderlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `error` text NOT NULL,
  `time` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
);
EOF;
runquery($sql);
$sql = "ALTER TABLE ".DB::table('aljqb_payorder')." ADD `rubbish` tinyint(4) NOT NULL";
DB::query($sql,'SILENT');
loadcache('plugin');
$siteurl = ltrim($_G['setting'][siteurl],'/') ? ltrim($_G['setting'][siteurl],'/') : ltrim($_G[siteurl],'/');
$config['aljqbkey'] = 'aljqb|shenmikey123|'.$siteurl.'/source/plugin/aljqb/pay/pay.php
aljhb|shenmikey123|'.$siteurl.'/source/plugin/aljhb/pay/pay.php
aljds|shenmikey123|'.$siteurl.'/source/plugin/aljds/pay/pay.php
aljpay|shenmikey123|'.$siteurl.'/source/plugin/aljpay/pay/pay.php
aljbgp|shenmikey123|'.$siteurl.'/source/plugin/aljbgp/pay/pay.php
aljad|shenmikey123|'.$siteurl.'/source/plugin/aljad/pay/pay.php
aljbdx|shenmikey123|'.$siteurl.'/source/plugin/aljbdx/pay/pay.php
aljbdx_rz|shenmikey123|'.$siteurl.'/source/plugin/aljbdx/pay/pay_rz.php
aljqdx|shenmikey123|'.$siteurl.'/source/plugin/aljqdx/pay/pay.php
aljskm|shenmikey123|'.$siteurl.'/source/plugin/aljskm/pay/pay.php
aljtcc|shenmikey123|'.$siteurl.'/source/plugin/aljtcc/pay/pay.php
aljwm|shenmikey123|'.$siteurl.'/source/plugin/aljwm/pay/pay.php
aljtsq|shenmikey123|'.$siteurl.'/source/plugin/aljtsq/pay/pay.php
aljtyh|shenmikey123|'.$siteurl.'/source/plugin/aljtyh/pay/pay.php
aljsfx|shenmikey123|'.$siteurl.'/source/plugin/aljsfx/pay/pay.php';
if($config['aljqbkey']) {
    $aljqbkeys = explode ("\n", str_replace ("\r", "", $config['aljqbkey']));
    foreach($aljqbkeys as $key=>$value){
        $arr=explode('|',$value);
        $aljqbkey[$arr[0]]=$arr;
    }
    $keynum = DB::result_first('select count(*) from %t',array('aljqb_secretkey'));
    if($keynum<=0) {
        foreach($aljqbkey as $tmp_key) {
            DB::insert('aljqb_secretkey',array('pluginname'=>$tmp_key[0],'secretkey'=>$tmp_key[1],'tokenurl'=>$tmp_key[2]));
        }
    }
}
if(file_exists("source/plugin/aljbd/aljbd.inc.php")) {
    //我的页面常用入口 我的钱包
    $mobile_user_common_entrance = C::t('#aljbd#aljbd_setting')->fetch('mobile_user_common_entrance');
    if($mobile_user_common_entrance){
        $mobile_user_common_entrance['value'] .= '
source/plugin/aljht/static/img/aljbd/user/money.png|plugin.php?id=aljqb&mobile=2|&#25105;&#30340;&#38065;&#21253;';
        C::t('#aljbd#aljbd_setting')->update_value_by_key($mobile_user_common_entrance['value'],'mobile_user_common_entrance');
    }
}
//finish to put your own code
$finish = TRUE;
?>