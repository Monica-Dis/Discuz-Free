<?php
/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false){
    preg_match('/Immersed\/(\d+)/i', $_SERVER["HTTP_USER_AGENT"], $matches);
    $immersed = $matches[1];
}

if($_G['mobile'] && $_G['cache']['plugin']['aljhtx']['force_mobile']){
	include_once "source/plugin/aljhtx/api/common.php";
}
$act = addslashes($_GET['act']);

$actarray= array('confirmorder','checkpassword','checkorder','paymoney','success','fail');

if(!$_G['mobile'] && !in_array($act,$actarray)) {
	if(strtolower(CHARSET) == 'gbk'){
		$_GET=ajaxGetCharSet_aljqb($_GET);
	}
	$pc_yes = 1;
	define('IN_MOBILE', 2);
	$_G['mobile'] = 2;
	$_G['setting']['hookscript'] = array();
}
require_once 'source/plugin/aljqb/class/Payment.class.php';
require_once 'source/plugin/aljqb/class/Queue.class.php';
require_once 'source/plugin/aljqb/class/Qbapi.class.php';
require_once 'source/plugin/aljqb/class/mapp_wechatclient.lib.class.php';
$queue = new Queue();
$payment = new Payment();
$qbapi = new Qbapi();
require_once 'source/plugin/aljqb/function/function_core.php';
if(!$_GET['session3rd'] && $_GET['act'] != 'paymoney') {
    if (!$_G['uid']) {
        $loginreturnurl = str_replace("&", "%26", $geturl);
        header('location:member.php?mod=logging&action=login&referer=' . $loginreturnurl);
        exit;
    } else {
        $wallet = DB::fetch_first('select * from %t where uid=%d', array('aljqb_wallet', $_G['uid']));
        if (empty($wallet)) {
            $insertarray = array(
                'uid' => $_G['uid'],
                'username' => $_G['username'],
                'createtime' => time(),
            );
            DB::insert('aljqb_wallet', $insertarray);
            $wallet = DB::fetch_first('select * from %t where uid=%d', array('aljqb_wallet', $_G['uid']));
        }
    }
}
require_once 'source/plugin/aljqb/pay/autotx_balance_toApp.php';
if(($isqianfanapp || $ismagapp) && $config['autoBalanceToApp'] && !$_GET['act']){
    include template('aljqb:common_app_tips');
    exit;
}
//$config['txfee'] = 0;
if($wallet['pullblack']) {
	$tip=lang("plugin/aljqb","aljqb_inc_php_1");
    $navtitle = lang("plugin/aljqb","aljqb_inc_php_2");
	include template('aljqb:touch/confirmtips');
	exit;
}
if($config['yanzheng']) {//�ж��Ƿ����ֻ���֤����
	if(is_file('source/plugin/aljdx/function_dx.php')) {
	require_once 'source/plugin/aljdx/function_dx.php';
	$is_dxpz = true;
	}else {
		$is_dxpz = false;
	}
}else {
	$is_dxpz = false;
}
if($act == 'settings') {//֧����������
	$return_url = $_GET['rurl'];
	if($wallet['password']) {
		header('location:plugin.php?id=aljqb');
		exit;
	}else {
		if($reset){
			$navtitle = lang("plugin/aljqb","aljqb_inc_php_3");
		}else{
            $navtitle = lang("plugin/aljqb","aljqb_inc_php_4");
		}
        $navtitle .= lang("plugin/aljqb","aljqb_inc_php_5");
		include template('aljqb:settings');
	}

}else if($act == 'settingslist'){
	$navtitle = lang("plugin/aljqb","aljqb_inc_php_6");
	include template('aljqb:settingslist');
}else if ($act == 'reset') {
	$reset = 1;
	$return_url = $_GET['rurl'];
	include template('aljqb:settings');
}else if($act == 'getphonecode') {
	if(submitcheck('formhash')) {//��ȡ�ֻ���֤��
		$phone = $_GET['phone'];
		if($is_dxpz) {
			if(ismobile_aljqb($phone)) {
				if(!getsmstemplate('aljqb','zhifu')){
					setsmstemplate('aljqb','zhifu',lang("plugin/aljqb","aljqb_inc_php_7"),array('code' => ''),'');
				}
				$code  = rand(100000,999999);
				$config['codetime'] = $config['codetime']?intval($config['codetime']):120;
				GsetCookie('zhifucode',$code,$config['codetime']);
				$status = sendsmsbyvar($phone,'aljqb','zhifu',array('code' => $code));
				if($status) {
					$tips = array(
								'status'=>1,
								'message'=>lang("plugin/aljqb","aljqb_inc_php_8")
							);
					echo json_encode(ajaxPostCharSet_aljqb($tips));
					exit;
				}else {
					$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_9"));
					echo json_encode(ajaxPostCharSet_aljqb($tips));
					exit;
				}
			}
		}
	}

}else if ($act == 'setpaypassword') {//��������
	$password = $_GET['password'];
	$confirmpassword = $_GET['confirmpassword'];
	$zhifucode = intval($_GET['zhifucode']);
	$phone = floor(floatval($_GET['phone']));
	$type = intval($_GET['type']);
	$return = base64_decode($_GET['return_url']);
	$updataarray = array();
	if(!$type) {
		if($wallet['password']) {
			$tips = array(
					'status'=>1,
					'message'=>lang("plugin/aljqb","aljqb_inc_php_10")
				);
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
	}
	if($is_dxpz) {
		if(!$phone){
			$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_11"));
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}else {
			if(!$type) {
				$phonecount = DB::result_first('select count(*) from %t where phone=%d and uid!=%d',array('aljqb_wallet',$phone,$_G['uid']));
				if($phonecount>=1) {
					$tips = array(
						'status'=>1,
						'message'=>lang("plugin/aljqb","aljqb_inc_php_12")
						);
					echo json_encode(ajaxPostCharSet_aljqb($tips));
					exit;
				}
			}

		}
		if(!$zhifucode){
			$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_13"));
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
		if(!$_COOKIE['zhifucode']) {
			$tips = array(
				'status'=>1,
				'message'=>lang("plugin/aljqb","aljqb_inc_php_14")
			);
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
		if($zhifucode != $_COOKIE['zhifucode']) {
			$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_15"));
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
		$updataarray['phone'] = $phone;
	}
	if(!$password) {
		$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_16"));
		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
	}
	if(!$confirmpassword) {
		$tips = array(
			'status'=>1,
			'message'=>lang("plugin/aljqb","aljqb_inc_php_17")
		);
		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
	}
	if(!is_numeric($password)) {
		$tips = array(
			'status'=>1,
			'message'=>lang("plugin/aljqb","aljqb_inc_php_18")
		);
		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
	}else {
		$len = strlen($password);
		if($len !=6) {
			$tips = array(
				'status'=>1,
				'message'=>lang("plugin/aljqb","aljqb_inc_php_19")
			);
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
	}
	if($password != $confirmpassword) {
		$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_20"));
		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
	} else {
		$updataarray['password'] = md5($password);
	}

	if(DB::update('aljqb_wallet',$updataarray,array('uid'=> $_G['uid']))){
		if($return) {
			$tips = array(
				'status'=>1,
				'message'=>lang("plugin/aljqb","aljqb_inc_php_21"),
				'url'=>$return
			);
		}else {
			$tips = array(
				'status'=>1,
				'message'=>lang("plugin/aljqb","aljqb_inc_php_22"),
				'url'=>'plugin.php?id=aljqb'
			);
		}

		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
	}else {
		$tips = array(
			'status'=>1,
			'message'=>lang("plugin/aljqb","aljqb_inc_php_23")
		);
		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
	}
}else if($act == 'checkpassword') {//��֤����
	if(submitcheck('formhash')) {
		$password = addslashes($_GET['password']);
		$return = $_GET['return_url'];
		if($wallet['password']) {
			if($wallet['password'] == $password) {
				$tips = array('status'=>1);
				echo json_encode(ajaxPostCharSet_aljqb($tips));
				exit;
			}else {
				$tips = array('status'=>0,'message'=>lang("plugin/aljqb","aljqb_inc_php_24"));
				echo json_encode(ajaxPostCharSet_aljqb($tips));
				exit;
			}
		}else {
			$tips = array(
				'status'=>0,
				'message'=>lang("plugin/aljqb","aljqb_inc_php_25"),
				'url'=>'plugin.php?id=aljqb&act=settings&rurl='.$return
			);
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
	}
}
//���°�΢���˺�
else if($act == 'rebindwx') {
	$return = base64_decode($_GET['return_url']);
	$openidreturnurl = str_replace("&","%26",$geturl);
	$openid = getopenid($openidreturnurl);
	$wechat_client = new WeChatClient_aljqb($config['appid'], $config['appsecret']);
	$wechatdata = $wechat_client -> getUserInfoById($openid);
	if(isset($wechatdata['errcode'])) {
		$qbapi->insertLog(ajaxGetCharSet_aljqb(json_encode($wechatdata)));
	}
	$wuser = ajaxGetCharSet_aljqb($wechatdata);
	if($wuser['subscribe']>0) {
		$walletupdate=array(
			'openid'=>$wuser['openid'],
			'nickname'=>$wuser['nickname'],
			'city'=>$wuser['city'],
			'sex'=>$wuser['sex'],
			'unionid'=>$wuser['unionid'],
			'subscribe'=>$wuser['subscribe'],
		);
		DB::update('aljqb_wallet',$walletupdate,array('id'=>$wallet['id']));
	}
	dsetcookie('subscribe',$wuser['subscribe'],86400);
	header('Location:'.$return);
	exit;
}
//����
else if($_GET['act'] == 'cash'){
	if($_GET['ajax'] == 'yes'){
		$is_txcash = $_GET['price']*($config['txfee']/100);
		
		echo json_encode(ajaxPostCharSet_aljqb(array('fee'=>sprintf("%.2f", $is_txcash),'t_price_all'=>sprintf("%.2f", $_GET['price']+$is_txcash))));
		exit;
	}
	$subscribe = getcookie('subscribe')?intval(getcookie('subscribe')):0;
	if($config['opentx']) {
		$tip=lang("plugin/aljqb","aljqb_inc_php_26");
        $navtitle = lang("plugin/aljqb","aljqb_inc_php_27");
		include template('aljqb:touch/confirmtips');
	}else {
		$mincash = $config['mincash']>=0.1?$config['mincash']:0.1;
		if(!$config['wxtrans']) { //֧�����Զ�ת�˹���ʵ��
			$cashacountlist=DB::fetch_all('select * from %t where uid=%s ',array('aljqb_cashtype',$_G['uid']));
			if(empty($cashacountlist)){
				//��ת����
				header('Location: plugin.php?id=aljqb&act=addaccount');
				exit;
			}
		}else{
			if(!$subscribe) {
				if(!$iswechat && $config['wxtrans']){
					if($config['is_follow']) {
						$followtip = explode("|", $config['is_follow']);
						$tip = $followtip[0];
						$followimg = $followtip[1];
					}else {
						$tip=lang("plugin/aljqb","aljqb_inc_php_28");
					}
                    $navtitle = lang("plugin/aljqb","aljqb_inc_php_29");
					include template('aljqb:touch/confirmtips');
					exit;
				}
				if(empty($wallet['openid'])){
                    $openidreturnurl = str_replace("&","%26",$geturl);
                    $openid = getopenid($openidreturnurl);
				}else{
					
                    $openid = $wallet['openid'];
				}

				$wechat_client = new WeChatClient_aljqb($config['appid'], $config['appsecret']);
				$wechatdata = $wechat_client -> getUserInfoById($openid);
				if(isset($wechatdata['errcode'])) {
					$qbapi->insertLog(ajaxGetCharSet_aljqb(json_encode($wechatdata)));
				}
				$wuser = ajaxGetCharSet_aljqb($wechatdata);
				dsetcookie('subscribe',$wuser['subscribe'],86400);
				if($wuser['subscribe']<=0) {
					if($config['is_follow']) {
						$followtip = explode("|", $config['is_follow']);
						$tip = $followtip[0];
						$followimg = $followtip[1];
					}else {
						$tip=lang("plugin/aljqb","aljqb_inc_php_28");
					}
					if($_G['cache']['plugin']['aljwsq'] && $wallet['openid']){
						$binduser = DB::fetch_first('SELECT * FROM %t WHERE openid=%s and uid>0', array('aljwsq_mapp_user',$wallet['openid']));
						if(!$binduser){
							$tip .= '<a href="plugin.php?id=aljqb&act=rebindwx&return_url='.base64_encode($geturl).'">&#37325;&#26032;&#32465;&#23450;&#24494;&#20449;</a>';
						}
					}
                    $navtitle = lang("plugin/aljqb","aljqb_inc_php_29");
					include template('aljqb:touch/confirmtips');
					exit;
				}
			}
			if(empty($wallet['openid']) || $wallet['subscribe']<=0) {
				$walletupdate=array(
					'openid'=>$wuser['openid'],
					'nickname'=>$wuser['nickname'],
					'city'=>$wuser['city'],
					'sex'=>$wuser['sex'],
					'unionid'=>$wuser['unionid'],
					'subscribe'=>$wuser['subscribe'],
				);
				DB::update('aljqb_wallet',$walletupdate,array('id'=>$wallet['id']));
			}
		}
		if(!$wallet['password']) {
			header('Location: plugin.php?id=aljqb&act=settings&rurl='.base64_encode($geturl));
			exit;
		}else {
			$return = base64_encode($geturl);
			
			
			
			$is_txcash = $wallet['balance']/((100+$config['txfee'])/100);
			$is_txcash = sprintf("%.2f", $is_txcash);
			$navtitle = lang("plugin/aljqb","aljqb_inc_php_30");
			include template('aljqb:cash');
		}

	}

}//���ֲ���,�Զ�ת��
else if($act == 'cashtx') {
	/*if($config['opentx']) {
        $tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_31"));
        echo json_encode(ajaxPostCharSet_aljqb($tips));
        exit;
	}*/
	if(submitcheck('formhash')){

		$rmb = $_GET['money'] + 0;
		$rmb = substr(sprintf("%.3f",$rmb),0,-1);
		if($rmb<=0) {
			$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_32"));
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
		$mincash = $config['mincash']>=0.1?$config['mincash']:0.1;
		if (!$config['wxtrans']) { //֧�����Զ�ת���ж�
			$cashid = intval($_GET['account']);
			$useracount=DB::fetch_first('select * from %t where cashid=%d',array('aljqb_cashtype',$cashid));
			$account=$useracount['account'];
			if(!$rmb || !$account) {
				$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_33"));
				echo json_encode(ajaxPostCharSet_aljqb($tips));
				exit;
			}
		}else {//΢���Զ�ת���ж�
			if(!$rmb) {
				$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_34"));
				echo json_encode(ajaxPostCharSet_aljqb($tips));
				exit;
			}
		}
		if($mincash > $rmb) {
			$tips = array(
				'status'=>1,
				'message'=>lang("plugin/aljqb","aljqb_inc_php_35").$mincash. lang("plugin/aljqb","aljqb_inc_php_36")
			);
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
		if($config['txfee']) {
			$txfee = $rmb * $config['txfee']/100;
			if($txfee<0.01) {
				$txfee = 0.01;
			}else {
				$txfee = sprintf("%.2f", $txfee);
			}
			$tx_rmb = $rmb+$txfee;
			$txfee_tips = lang("plugin/aljqb","aljqb_inc_php_37").$txfee.lang("plugin/aljqb","aljqb_inc_php_38");
			$txfee_tips_1 = lang("plugin/aljqb","aljqb_inc_php_39").$rmb.lang("plugin/aljqb","aljqb_inc_php_40");
		} else {
			$tx_rmb = $rmb;
			$txfee_tips = '';
			
		}
		if($wallet['balance'] < $tx_rmb) {
			$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_41").$tx_rmb.lang("plugin/aljqb","aljqb_inc_php_42").$txfee_tips.lang("plugin/aljqb","aljqb_inc_php_43").$wallet['balance'].lang("plugin/aljqb","aljqb_inc_php_44"));
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}

		

		if($config['orderlimit']) {
			$today = mktime(0,0,0,date("m"),date("d"),date("Y"));
			$tomorrow =  mktime(0,0,0,date("m"),date("d",strtotime("+1day")),date("Y"));
			$todayordernum = DB::result_first('select count(*) from %t as a where a.time >= %d and a.time<=%d and uid=%d',array('aljqb_order',$today,$tomorrow,$_G['uid']));
			if($todayordernum > $config['orderlimit']) {
				$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_45"));
				echo json_encode(ajaxPostCharSet_aljqb($tips));
				exit;
			}
		}
		if (!$config['wxtrans']) { //֧�����Զ�ת�˶�������
			$checkaccount = DB::result_first('select count(*) from %t as a where uid!=%d and account=%s',array('aljqb_order',$_G['uid'],$account));
			$insertarray = array(
				'uid' => $_G['uid'],
				'username'=> $_G['username'],
				'account' => $account,
				'time'=> time(),
				'cashid'=>$cashid,
				'rmb' => $rmb,
			);
			if($checkaccount>=1) {
				$insertarray['admindesc'] = lang("plugin/aljqb","aljqb_inc_php_46");
			}
		}else {//΢���Զ�ת�˶�������
			$insertarray = array(
				'uid' => $_G['uid'],
				'username'=> $_G['username'],
				'time'=> time(),
				'account' => $wallet['nickname'],
				'rmb' => $rmb,
				'trans_type'=>'wechat',
			);
		}
		if($config['txfee']) {
			$insertarray['fee'] = $txfee;
		}
		

		$orderparams = $payment->createTxOrder($insertarray);
		$queuearray = array(
			'app_name' => 'aljqb',
			'app_type' => 'tx',
			'app_phone' => '123456789',
			'app_ip' => '123456789',
		);
		$balancearray = array(
			'type'=> 'take',
			'uid'=>$_G['uid'],
			'price' => $tx_rmb,
			'orderid'=> $orderparams['orderid'],
			'desc'=> lang("plugin/aljqb","aljqb_inc_php_47").$tx_rmb.lang("plugin/aljqb","aljqb_inc_php_48").$txfee_tips.$txfee_tips_1,
		);
		$result = $qbapi->balance($queuearray,$balancearray);
		$tipsurl = '<a href="plugin.php?id=aljqb&act=apply" >'.lang("plugin/aljqb","aljqb_inc_php_49").'</a>';
		
		$administratorNotification = lang("plugin/aljqb","aljqb_inc_php_50").$orderparams['username'].lang("plugin/aljqb","aljqb_inc_php_51").$rmb.lang("plugin/aljqb","aljqb_inc_php_52").$orderparams['orderid'].lang("plugin/aljqb","aljqb_inc_php_53");
		$autoAdministratorNotification = lang("plugin/aljqb","aljqb_inc_php_54").$orderparams['username'].lang("plugin/aljqb","aljqb_inc_php_55").$rmb.lang("plugin/aljqb","aljqb_inc_php_56").$orderparams['orderid'].lang("plugin/aljqb","aljqb_inc_php_57");
		
		
        $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
		if($result['code'] == 200) {
			
			if(!$checkaccount) {
				if($config['autocash'] && $config['prevauto']) {//�Զ�ת��
					if($config['autocash']>=$rmb) {
						if(!$config['wxtrans']) { //֧�����Զ�ת�˹���ʵ��
							$result = alipaytrans($orderparams['orderid'], $account, $rmb,$config['zhifubeizhu'],$config['fukuanname'],$useracount['real_name']);
							if(strtolower(CHARSET) == 'gbk'){
								 $result_log =  diconv($result, 'utf-8', 'gbk');
							}else {
								 $result_log = $result;
							}
							$queue->insertLog($result_log);
							$result = json_decode($result,true);
							$result = $result['alipay_fund_trans_toaccount_transfer_response'];
							if($result['code'] == 10000) {
								$updatearray = array(
									'state' => 1,
									'trans_orderid' => $result['order_id'],
									'trans_time'=> $result['pay_date'],
									'desca' => $config['tips'],
								);
								DB::update('aljqb_order',$updatearray,array('orderid' => $result['out_biz_no']));
								notification_add($_G['uid'], 'system',lang("plugin/aljqb","aljqb_inc_php_58").$orderparams['orderid'].lang("plugin/aljqb","aljqb_inc_php_59").$rmb.lang("plugin/aljqb","aljqb_inc_php_60").$tipsurl,array('from_idtype'=>'aljqb'));
								foreach($groupids as $g_uid){
									notification_add($g_uid['uid'], 'system',$autoAdministratorNotification,array('from_idtype'=>'aljqb'));
								}
								$tips = array('status'=>0,'message'=>lang("plugin/aljqb","aljqb_inc_php_61"),'url'=>'plugin.php?id=aljqb');
								echo json_encode(ajaxPostCharSet_aljqb($tips));
								exit;
							}else {
								$tips = array('status'=>0,'message'=>lang("plugin/aljqb","aljqb_inc_php_62"),'url'=>'plugin.php?id=aljqb');
								echo json_encode(ajaxPostCharSet_aljqb($tips));
								exit;
							}
						}else{//΢���Զ�ת��
							$wxdata = array(
								'amount'=>$rmb,
								'openid'=>$wallet['openid'],
								'orderid'=>$orderparams['orderid'],
								'desc'=>$config['fukuanname'].$config['zhifubeizhu'],
							);
							$result = ajaxGetCharSet_aljqb(wxchattransfers($wxdata));
							if($result['result_code'] == 'SUCCESS') {
								$updatearray = array(
									'state' => 1,
									'trans_orderid' => $result['payment_no'],
									'trans_time'=> $result['payment_time'],
									'desca' => $config['tips'],
								);
								DB::update('aljqb_order',$updatearray,array('orderid' => $result['partner_trade_no']));
								notification_add($_G['uid'], 'system',lang("plugin/aljqb","aljqb_inc_php_63").$orderparams['orderid'].lang("plugin/aljqb","aljqb_inc_php_64").$rmb.lang("plugin/aljqb","aljqb_inc_php_65").$tipsurl,array('from_idtype'=>'aljqb'));
                                foreach($groupids as $g_uid){
                                    notification_add($g_uid['uid'], 'system',$autoAdministratorNotification,array('from_idtype'=>'aljqb'));
                                }
								$tips = array('status'=>0,'message'=>lang("plugin/aljqb","aljqb_inc_php_66"),'url'=>'plugin.php?id=aljqb');
								echo json_encode(ajaxPostCharSet_aljqb($tips));
								exit;
							}else {
								$result_log = dimplode($result);
								$queue->insertLog($result_log);
								$tips = array('status'=>0,'message'=>lang("plugin/aljqb","aljqb_inc_php_67"),'url'=>'plugin.php?id=aljqb');
								echo json_encode(ajaxPostCharSet_aljqb($tips));
								exit;
							}
						}
					}else {
                        foreach($groupids as $g_uid){
                            notification_add($g_uid['uid'], 'system',$administratorNotification,array('from_idtype'=>'aljqb'));
                        }
						$tips = array('status'=>0,'message'=>lang("plugin/aljqb","aljqb_inc_php_68"),'url'=>'plugin.php?id=aljqb');
						echo json_encode(ajaxPostCharSet_aljqb($tips));
						exit;
					}
				}else {
                    foreach($groupids as $g_uid){
                        notification_add($g_uid['uid'], 'system',$administratorNotification,array('from_idtype'=>'aljqb'));
                    }
					$tips = array('status'=>0,'message'=>lang("plugin/aljqb","aljqb_inc_php_69"),'url'=>'plugin.php?id=aljqb');
					echo json_encode(ajaxPostCharSet_aljqb($tips));
					exit;
				}
			}else {
                foreach($groupids as $g_uid){
                    notification_add($g_uid['uid'], 'system',$administratorNotification,array('from_idtype'=>'aljqb'));
                }
				$tips = array('status'=>0,'message'=>lang("plugin/aljqb","aljqb_inc_php_70"),'url'=>'plugin.php?id=aljqb');
				echo json_encode(ajaxPostCharSet_aljqb($tips));
				exit;
			}
		}else {
			DB::delete('aljqb_order',array('orderid'=>$orderparams['orderid']));
			$tips = array('status'=>0,'message'=>lang("plugin/aljqb","aljqb_inc_php_71"),'url'=>'plugin.php?id=aljqb');
			echo json_encode(ajaxPostCharSet_aljqb($result));
			exit;
		}
	}
}
//�˻��б�
else if($_GET['act'] == 'accountlist'){
    $accountlist=DB::fetch_all('select * from %t where uid=%s',array('aljqb_cashtype',$_G['uid']));
    $navtitle = lang("plugin/aljqb","aljqb_inc_php_72");
    include template('aljqb:accountlist');
}//ɾ���˺�
else if($_GET['act'] == 'accountdelete'){
	if(submitcheck('formhash')) {
		$cashid = intval($_GET['cashid']);
		if(DB::delete('aljqb_cashtype',array('cashid'=>$cashid))){
			$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_73"));
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}else{
			$tips = array('status'=>0,'message'=>lang("plugin/aljqb","aljqb_inc_php_74"));
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
	}
}
//�����˻�
else if ($_GET['act'] == 'addaccount'){
    if(submitcheck('formhash')){
		if($_GET['account']){
			if(!check_email($_GET['account'])) {
				if(!check_phone($_GET['account'])) {
					$tips = array(
						'status'=>1,
						'message'=>lang("plugin/aljqb","aljqb_inc_php_75")
					);
					echo json_encode(ajaxPostCharSet_aljqb($tips));
					exit;
				}
			}
			$accountnum = DB::result_first('select count(*) from %t where account=%s',array('aljqb_cashtype',$_GET['account']));
			if($accountnum >= 1) {
				$tips = array(
					'status'=>1,
					'message'=>lang("plugin/aljqb","aljqb_inc_php_76")
				);
				echo json_encode(ajaxPostCharSet_aljqb($tips));
				exit;
			}else {
				$insertarray = array(
					'uid'=> $_G['uid'],
					'account'=>$_GET['account'],
					'real_name'=>$_GET['real_name'],
					'cashtype'=>lang("plugin/aljqb","aljqb_inc_php_77"),
				);
				if(DB::insert('aljqb_cashtype',$insertarray)){
					$tips = array('status'=>0,'message'=>lang("plugin/aljqb","aljqb_inc_php_78"),'url' => 'plugin.php?id=aljqb');
					echo json_encode(ajaxPostCharSet_aljqb($tips));
					exit;
				}else{
					$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_79"));
					echo json_encode(ajaxPostCharSet_aljqb($tips));
					exit;
				}
			}

		}else{
			$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_80"));
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
	}else{
		$accounttips=$config['accounttip'];
		$navtitle = lang("plugin/aljqb","aljqb_inc_php_81");
		include template('aljqb:addaccount');
	}
}
//�˻���ϸ
else if($_GET['act'] == 'account'){
	$navtitle = lang("plugin/aljqb","aljqb_inc_php_82");
	include template('aljqb:account');
}//�˻���ϸajax
else if($act == 'getlog') {
	$page=!empty($_GET['page'])?intval($_GET['page']):1;
	$pagesize=10;
	$offset=($page-1)*$pagesize;
	$mylog=DB::fetch_all('select *from %t where uid=%s order by time desc,id desc limit %d,%d',array('aljqb_accountchangelog',$_G['uid'],$offset,$pagesize));
	if(!empty($mylog)) {
		include template('aljqb:loglist');
		exit;
	}else {
		echo 1;
		exit;
	}
}//���������¼
else if($_GET['act'] == 'apply'){
	$navtitle = lang("plugin/aljqb","aljqb_inc_php_83");
	include template('aljqb:Apply');
}//����ajax
else if($act == 'applylist') {
	$page=!empty($_GET['page'])?intval($_GET['page']):1;
    $pagesize=6;
    $offset=($page-1)*$pagesize;
	$myorder=DB::fetch_all('select *from %t where uid=%s order by time desc limit %d,%d',array('aljqb_order',$_G['uid'],$offset,$pagesize));
	if(!empty($myorder)) {
		include template('aljqb:applylog');
		exit;
	}else {
		echo 1;
		exit;
	}
}
else if($_GET['act'] == 'applydelete' && $_GET['formhash']==FORMHASH && $_G['uid']){//����ȡ��
	$orderid = addslashes($_GET['orderid']);
	$userorder=DB::fetch_first('select * from %t where orderid=%s',array('aljqb_order',$orderid));
	$queuearray = array(
			'app_name' => 'aljqb',
			'app_type' => 'txcancel',
			'app_phone' => '123456789',
			'app_ip' => '123456789',
		);
	$balancearray = array(
		'type'=> 'charge',
		'uid'=>$_G['uid'],
		'price' => $userorder['rmb']+$userorder['fee'],
		'orderid'=> $orderid,
		'desc'=> lang("plugin/aljqb","aljqb_inc_php_84").($userorder['rmb']+$userorder['fee']).lang("plugin/aljqb","aljqb_inc_php_85"),
	);
	if(DB::update('aljqb_order',array('state'=>3),array('orderid'=>$orderid))) {
		$result = $qbapi->balance($queuearray,$balancearray);
		if($result['code'] == '200') {
			$tips = array('status'=>0,'message'=>lang("plugin/aljqb","aljqb_inc_php_86"));
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}else {
			DB::update('aljqb_order',array('state'=>0),array('orderid'=>$orderid));
			$tips = array('status'=>1,'message'=>$result['message']);
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
	}else {
		$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_87"));
		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
	}

}else if($act == 'recharge') {//��ֵ
	if($config['opencharge']) {
		$tip=lang("plugin/aljqb","aljqb_inc_php_88");
		$navtitle = lang("plugin/aljqb","aljqb_inc_php_89");
		include template('aljqb:touch/confirmtips');
	}else {
		$navtitle = lang("plugin/aljqb","aljqb_inc_php_90");
		include template('aljqb:recharge');
	}
}else if($act == 'rechargelog') {//��ֵ��¼
	if($_GET['getdata'] == 'yes') {
		$page=!empty($_GET['page'])?intval($_GET['page']):1;
		$pagesize=8;
		$offset=($page-1)*$pagesize;
		$rechargelog = DB::fetch_all('select * from %t where uid=%d order by createtime desc limit %d,%d',array('aljqb_rechargeorder',$_G['uid'],$offset,$pagesize));
		foreach($rechargelog as $tmp_key => $tmp_value) {
			if(!$tmp_value['status']) {
				if($tmp_value['createtime']+900>TIMESTAMP) {
					$tmp_value['status'] = 2;
					$aljqb_params=array(
						'orderid'=> $tmp_value['orderid'],
						'time' => $tmp_value['createtime'],
						'price'=> $tmp_value['price'],
						'keyname' => 'aljqb',
						'key'=> $config['qbkey'],
						'return_url'=>$_G['siteurl'].'plugin.php?id=aljqb&act=rechargelog',
					);
					$tmp_value['url'] = $qbapi->createUrl($aljqb_params);
					$rechargelog[$tmp_key] = $tmp_value;
				}
			}
		}
		if(!empty($rechargelog)) {
			include template('aljqb:rechargelist');
			exit;
		}else {
			echo 1;
			exit;
		}
	}else {
        $navtitle = lang("plugin/aljqb","aljqb_inc_php_91");
		include template('aljqb:rechargelog');
	}

}else if($act == 'payment') {//�µ�
	$price = $_GET['price'] + 0;
	if($price<=0) {

		$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_92"));
		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
	}
	$price = substr(sprintf("%.3f",$price),0,-1);
	$subject = $_G['username'].lang("plugin/aljqb","aljqb_inc_php_93").$price.lang("plugin/aljqb","aljqb_inc_php_94");
	$body = $_G['username'].lang("plugin/aljqb","aljqb_inc_php_95").$price.lang("plugin/aljqb","aljqb_inc_php_96");
	$orderparams = array(
		'uid' => $_G['uid'],
		'username' => $_G['username'],
		'price' => $price,
		'ordertype'=> 'recharge',
		'subject' => $subject,
		'body' => $body,
	);
	$order = $payment->createOrder($orderparams);
	if(!empty($order)) {
		$aljqb_params=array(
			'orderid'=> $order['orderid'],
			'time' => $order['createtime'],
			'price'=> $order['price'],
			'keyname' => 'aljqb',
			'key'=> $config['qbkey'],
			'return_url'=>$_G['siteurl'].'plugin.php?id=aljqb',
		);
		$url = $qbapi->createUrl($aljqb_params);
		$tips = array('status'=>0,'message'=>'0','url'=>$url);
		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
	}else {

		$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_97"));
		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
	}
}else if($act == 'confirmorder') {//����̨
	if($_G['mobile']) { // �ֻ���֤΢�Ż���
		if($iswechat && $config['iswx']) {
			$openidreturnurl = str_replace("&","%26",$geturl);
			$openid = getcookie('openid');
			if(!$openid){
				$openid = getopenid($openidreturnurl);
				dsetcookie('openid',$openid);
			}
		}
	}

	$keyname = rawurldecode($_GET['keyname']);
	$_GET['price'] = rawurldecode($_GET['price']) +0;
	$_GET['price'] = substr(sprintf("%.3f",$_GET['price']),0,-1);
	$orderid = rawurldecode($_GET['orderid']);
	$params=array(
		'orderid'=> $orderid,
		'time' => rawurldecode($_GET['time']),
		'price'=> $_GET['price'],
		'keyname' => $keyname,
		'key'=> $aljqbkey[$keyname][1],
		'return_url'=>base64_decode($_GET['return_url']),
	);
    if(file_exists('source/plugin/aljbdx/include/aljqb_subject.php')) {
        require_once 'source/plugin/aljbdx/include/aljqb_subject.php';
	}
	if(file_exists('source/plugin/xn_raise/pay/aljqb_subject.php')) {
        require_once 'source/plugin/xn_raise/pay/aljqb_subject.php';
    }
	$subject = $_G['cookie'][$keyname.'_aljqb_subject'] ? $_G['cookie'][$keyname.'_aljqb_subject'] : $subject;
	
	if($_GET['price']>0) {
		$key = $qbapi->createKey($params);
		if($key == $_GET['key']) {
			$orderpaytime = $params['time']+900;
			if(TIMESTAMP < $orderpaytime) {
				$payparams=array(
					'orderid'=> $orderid,
					'overtime' => $orderpaytime,
					'price'=> rawurldecode($_GET['price']),
					'rurl'=>base64_decode($_GET['return_url']),
					'nurl'=> $aljqbkey[$keyname][2],
					'uid' => $_G['uid'],
					'username' => $_G['username'],
					'subject' => $subject ? $subject : lang("plugin/aljqb","aljqb_inc_php_98").rawurldecode($_GET['price']).lang("plugin/aljqb","aljqb_inc_php_99"),
					'pluginname' => $keyname,
				);
				$time = $orderpaytime - TIMESTAMP;
				if($time<=0) {
					$time = 0;
				}
				$m = $time/60%60;
				$m= str_pad($m,2,0,STR_PAD_LEFT);
				$s = $time%60;
				$s = str_pad($s,2,0,STR_PAD_LEFT);
				$order = $payment->createPayOrder($payparams);
				$return_url = base64_encode($geturl);
				if($_G['mobile']) {
					$navtitle = lang("plugin/aljqb","aljqb_inc_php_100");
					include template('aljqb:confirmorder');
				}else {
					$navtitle = lang("plugin/aljqb","aljqb_inc_php_101");
					include template('aljqb:cashier');
				}
			}else {
				$tip = lang("plugin/aljqb","aljqb_inc_php_102");
                $navtitle = lang("plugin/aljqb","aljqb_inc_php_103");
				include template('aljqb:tip');
			}
		}else {
			$tip = lang("plugin/aljqb","aljqb_inc_php_104");
            $navtitle = lang("plugin/aljqb","aljqb_inc_php_105");
			include template('aljqb:tip');
		}
	}else {
		$tip = lang("plugin/aljqb","aljqb_inc_php_106");
        $navtitle = lang("plugin/aljqb","aljqb_inc_php_107");
		include template('aljqb:tip');
	}
}else if($act == 'paymoney') {//�ֻ���֧��
	if($_G['mobile']) {
        if($_GET["session3rd"]){
            $openid = $_GET["session3rd"];
        }else{
            $openid = getcookie('openid');
        }
	}
	$updatearray = array();
	$aljorderid = addslashes($_GET['aljorderid']);
	$order = DB::fetch_first('select * from %t where aljorderid = %s',array('aljqb_payorder',$aljorderid));
	$order['subject'] = strip_tags($order['subject']);
	$order['subject'] = str_replace(array('(',')'),'',$order['subject']);
    $order['subject'] = cutstr($order['subject'],'40');
	if($order['price']+0<=0) {
		$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_108"));
		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
	}
	$order['trade_mod'] = addslashes($_GET['trade_mod']);
	if(TIMESTAMP < $order['overtime']) {
		if(!$order['status']) {
			if($order['trade_mod'] == 'qianfanapp'){
				$updatearray['trade_mod'] = $order['trade_mod'];
				$payment-> updatePayOrder($updatearray,$aljorderid);
				$qianfanapp_pay_config = array("title"=>$order['subject'], "cash_cost"=>$order['price']);
				$pay_s_url = $_G['siteurl'].'plugin.php?id=aljqb&act=success'.'&out_trade_no='.$aljorderid;
				$pay_f_url = $order['rurl'];
				$tips = array('status'=>0,'type'=>'qianfanapp','pay_s_url'=>$pay_s_url,'pay_f_url'=>$pay_f_url,'qianfanapp_pay_config'=>$qianfanapp_pay_config);
				echo json_encode(ajaxPostCharSet_aljqb($tips));
				exit;
			}else if($order['trade_mod'] == 'magapp') {//����
                $subject = $order['subject'];
                $magapp_price = $order['price'];
                $secret    = $config['magapp_secret'];
				$sign = md5($order['aljorderid'].$order['paytime'].$order['orderid'].$secret);
                $params_ma = array(
                    'trade_no' => $order['aljorderid'],
                    'callback' => $config['OAuth'].'source/plugin/aljqb/pay/notify_magapp.php?out_trade_no='.$order['aljorderid'].'&paytime='.$order['paytime'].'&orderid='.$order['orderid'].'&sign='.$sign,
                    'amount'   => $magapp_price,
                    'title'   => diconv($order['subject'],CHARSET,'UTF-8'),
                    'user_id' => $_G['uid'],
                    'to_user_id' => 0,
                    'des'    => diconv($order['subject'],CHARSET,'UTF-8'),
                    'remark' => diconv($order['subject'],CHARSET,'UTF-8'),
                    'secret' => $secret,
                );

				$ret= magapppay($params_ma);
				$unionOrderNum = $ret['data']['unionOrderNum'];
				if($unionOrderNum){
					$updatearray['trade_mod'] = $order['trade_mod'];
					$updatearray['transaction_id'] = $unionOrderNum;
					$payment-> updatePayOrder($updatearray,$aljorderid);
                    $magapp_pay_config = array(
                        'money'=>$magapp_price,
                        'title'=>$subject,
                        'des'=>$subject,
                        'payWay'=>array(
                            'wallet'=>1,
                            'weixin'=>1,
                            'alipay'=>1,
                        ),
                        'orderNum'=>$order['aljorderid'],
                        'unionOrderNum'=>$unionOrderNum,
                        'type'=>lang('plugin/aljqb','aljqb_inc_php_109')
                    );
                    $pay_s_url = $_G['siteurl'].'plugin.php?id=aljqb&act=success'.'&out_trade_no='.$aljorderid;
                    $pay_f_url = $order['rurl'];
                    $tips = array('status'=>0,'type'=>'magapp','pay_s_url'=>$pay_s_url,'pay_f_url'=>$pay_f_url,'magapp_pay_config'=>$magapp_pay_config);
                    echo json_encode(ajaxPostCharSet_aljqb($tips));
                    exit;
				}
                $tips = array('status'=>0,'type'=>'magapp','url'=>$alipayurl,'unionOrderNum'=>0,'ret'=>diconv($ret["msg"],'utf-8'));
                echo json_encode(ajaxPostCharSet_aljqb($tips));
                exit;
            }else if($order['trade_mod'] == 'alipay') {//֧����
            	if($trade_type == 'APP' && $_GET['version'] > 1.1){
            		$order['trade_type'] = 'mobileapp';
					$params = $payment->getPayparams($order,$_G['siteurl'],$notify_url);
					$updatearray['trade_type'] = $order['trade_type'];
					$updatearray['trade_mod'] = $order['trade_mod'];
					$payment-> updatePayOrder($updatearray,$aljorderid);
					$return_url = $_G['siteurl'].'plugin.php?id=aljqb&act=success'.'&out_trade_no='.$aljorderid;
					
            		echo alipayPlus($aljorderid, $order['subject'], $order['price'], $notify_url);
            		exit;
            	}else{
            		$order['trade_type'] = 'mobileweb';
					$params = $payment->getPayparams($order,$_G['siteurl'],$notify_url);
					$updatearray['trade_type'] = $order['trade_type'];
					$updatearray['trade_mod'] = $order['trade_mod'];
					$payment-> updatePayOrder($updatearray,$aljorderid);
					$alipayurl = alipay($params);
					$tips = array('status'=>0,'type'=>'alipay','url'=>$alipayurl);
					echo json_encode(ajaxPostCharSet_aljqb($tips));
					exit;
            	}
				
			}else if($order['trade_mod'] == 'wxpay'){//΢��
				if($_G['mobile']) {
					if($iswechat){
						$order['openid'] = $openid;
						$updatearray['openid'] = $order['openid'];
						$updatearray['trade_type'] = $trade_type;
						$updatearray['trade_mod'] = $order['trade_mod'];
						$payment-> updatePayOrder($updatearray,$aljorderid);
						$params = $payment->getPayparams($order,$_G['siteurl'],$notify_url);
						$jsapiparameters = wxpay($params);
						$jswxpay = json_decode($jsapiparameters,true);
						$url = $_G['siteurl'].'plugin.php?id=aljqb&act=success'.'&out_trade_no='.$aljorderid;
						$tips = array('status'=>0,'type'=>'wxpay','json'=>$jswxpay,'url'=>$url);
						echo json_encode(ajaxPostCharSet_aljqb($tips));
						exit;
					}else {
						$updatearray['trade_type'] = 'MWEB';
						$updatearray['trade_mod'] = $order['trade_mod'];
						$payment-> updatePayOrder($updatearray,$aljorderid);
						$params = $payment->getPayparams($order,$_G['siteurl'],$notify_url);
						$wxh5 = getWxh5pay($params);
						$url = $_G['siteurl'].'plugin.php?id=aljqb&act=success'.'&out_trade_no='.$aljorderid;
						$tips = array('status'=>0,'type'=>'wxh5pay','wxpayurl'=>$wxh5,'url'=>$url);
						echo json_encode(ajaxPostCharSet_aljqb($tips));
						exit;
					}
				}else {
					$updatearray['trade_type'] = 'NATIVE';
					$updatearray['trade_mod'] = $order['trade_mod'];
					$payment-> updatePayOrder($updatearray,$aljorderid);
					$params = $payment->getPayparams($order,$_G['siteurl'],$notify_url);
					$pcwxpay = getcodeurl($params);
					$tips = array('status'=>0,'type'=>'wxpay','wxpayurl'=>$pcwxpay);
					echo json_encode(ajaxPostCharSet_aljqb($tips));
					exit;
				}

			}else if($order['trade_mod'] == 'APP') {
                $updatearray['trade_type'] = $trade_type;
                $updatearray['trade_mod'] = $order['trade_mod'];
                $payment-> updatePayOrder($updatearray,$aljorderid);
                $params = $payment->getPayparams($order,$_G['siteurl'],$notify_url);
                $params['total_fee'] = $params['total_fee']*100;
                $jsapiparameters = apppay($params);
                $url = $_G['siteurl'].'plugin.php?id=aljqb&act=success'.'&out_trade_no='.$aljorderid;
                $tips = array('status'=>0,'type'=>'APP','json'=>$jsapiparameters,'url'=>$url);
                if(strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false){
                    echo json_encode($jsapiparameters);
                    exit;
                }else{
                    echo json_encode(ajaxPostCharSet_aljqb($tips));
                    exit;
                }
			}else if($order['trade_mod'] == 'mywallet') {//���֧��
				$queuearray = array(
					'app_name' => $order['pluginname'],
					'app_type' => 'yuezhifu',
					'app_phone' => '123456789',
					'app_ip' => '123456789',
				);
				$balancearray = array(
					'type'=> 'take',
					'uid'=>$_G['uid'],
					'price' => $order['price'],
					'orderid'=> $order['orderid'],
					'desc'=> lang("plugin/aljqb","aljqb_inc_php_109").$order['price'].lang("plugin/aljqb","aljqb_inc_php_110"),
				);
				$result = $qbapi->balance($queuearray,$balancearray);

				if($result['code'] == '200') {
					if($order['status']<1){
						$updatearray['status'] = 1;
					}
					if($order['paytime']<1){
						$updatearray['paytime'] = TIMESTAMP;
					}
					$updatearray['trade_mod'] = $order['trade_mod'];
					$payment->updatePayOrder($updatearray,$aljorderid);
					$keyarray = array(
						'aljorderid'=> $aljorderid,
						'paytime' => $updatearray['paytime'],
						'orderid' => $order['orderid'],
						'key'=> $aljqbkey[$order['pluginname']][1],
					);
					$json = json_encode($keyarray);
					$key = $qbapi->createKey($keyarray);
					$postdata = array(
						'aljorderid'=> $aljorderid,
						'paytime' => $updatearray['paytime'],
						'orderid' => $order['orderid'],
						'key' => $key,
					);
					$status = $qbapi->postDatacurl($postdata,$order['nurl']);
					$url = $_G['siteurl'].'plugin.php?id=aljqb&act=success'.'&out_trade_no='.$aljorderid;
					$tips = array('status'=>0,'type'=>'mywallet','url'=>$url);
					echo json_encode(ajaxPostCharSet_aljqb($tips));
					exit;
				}else {
					if($result['code'] == 500) {
						$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_111"));
						echo json_encode(ajaxPostCharSet_aljqb($tips));
					}else {
						$tips = array('status'=>1,'message'=>$result['message']);
						echo json_encode(ajaxPostCharSet_aljqb($tips));
					}
					exit;
				}
			}
		} else {
			$tips = array('status'=>2,'message'=>lang("plugin/aljqb","aljqb_inc_php_112"),'url' => $order['rul']);
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
	}else {
		$tips = array('status'=>1,'message'=>lang("plugin/aljqb","aljqb_inc_php_113"));
		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
	}
}else if($act == 'qf_oid'){
	if($_GET['ajax'] == 'yes'){
		$aljorderid = addslashes($_GET['out_trade_no']);
		$order = DB::fetch_first('select * from %t where aljorderid = %s',array('aljqb_payorder',$aljorderid));
		if($order['transaction_id']){
			echo $order['transaction_id'];
		}else{
			echo 0;
		}
		exit;
	}else{
		$updatearray['transaction_id'] = $_GET['orderid'];
		if(DB::update('aljqb_payorder', $updatearray,array('aljorderid'=>$_GET['out_trade_no']))){
			echo 1;
		}else{
			echo 0;
		}
		exit;
	}
	
}else if($act == 'success') {//֧���ɹ�
	$order = $payment->fetchOrder($_GET['out_trade_no']);
	if(!$_G['mobile']){
        $keyname = $order['pluginname'];
        if($keyname == 'aljbdx' || $keyname == 'aljbdx_rz' || $keyname == 'aljsfx'){
            $pluginid = 'aljbd';
            require_once 'source/plugin/aljbd/include/aljbd_parameter.php';
        }
	}

	if($order['trade_mod'] == 'qianfanapp'){
		$transaction_id = $order['transaction_id'];

      $result = qianfanapp_query($transaction_id);

      if($result['data'][$transaction_id]['result']==1 || $result['data'][$transaction_id]['result']==2){
      		if($result['data'][$transaction_id]['info']['cash_cost'] != $order['price']*100 || $_GET['out_trade_no'] != $result['data'][$transaction_id]['info']['out_trade_no']){
                $tip = '&#25903;&#20184;&#22833;&#36133;&#65292;&#37329;&#39069;&#24322;&#24120;';
                $navtitle = '&#25903;&#20184;&#20449;&#24687;';
                $face = 0;
                $url = $order['rurl'];
                include template('aljqb:tip');
                exit;
			}
			//$updatearray['transaction_id'] = $transaction_id;
			if ($order['status'] < 1) {
					$updatearray['status'] = 1;
			}
			if ($order['paytime'] < 1) {
					$updatearray['paytime'] = TIMESTAMP;
			}
			$payment->updatePayOrder($updatearray, $_GET['out_trade_no']);
			$neworder = $payment->fetchOrder($_GET['out_trade_no']);
			if ($neworder['status']) {
					$keyarray = array(
							'aljorderid' => $neworder['aljorderid'],
							'paytime' => $neworder['paytime'],
							'orderid' => $neworder['orderid'],
							'key' => $aljqbkey[$neworder['pluginname']][1],
					);
					//file_put_contents('test.txt',$aljqbkey[$neworder['pluginname']][1]."\r",FILE_APPEND);
					$json = json_encode($keyarray);
					$key = $qbapi->createKey($keyarray);
					$postdata = array(
							'aljorderid' => $neworder['aljorderid'],
							'paytime' => $neworder['paytime'],
							'orderid' => $neworder['orderid'],
							'key' => $key,
					);
					//file_put_contents('test.txt',$key."\r",FILE_APPEND);
					$status = postXmlCurl($postdata, $order['nurl']);
					$status = strtolower($status);
					if ($status != 'success') {
						$qbapi->insertLog($order['nurl'] . lang("plugin/aljqb","aljqb_inc_php_114").' success');
					}
			}
      }
    }else if($order['trade_mod'] == 'magapp'){
        $unionOrderNum = $order['transaction_id'];
        if($unionOrderNum && $order['status'] == 0) {
            $ret = magapppay_query($unionOrderNum);
            if($ret['paycode'] == 1) {
                if ($order['status'] < 1) {
                    $updatearray['status'] = 1;
                }
                if ($order['paytime'] < 1) {
                    $updatearray['paytime'] = TIMESTAMP;
                }
                $payment->updatePayOrder($updatearray, $_GET['out_trade_no']);
                $neworder = $payment->fetchOrder($_GET['out_trade_no']);
                if ($neworder['status']) {
                    $keyarray = array(
                        'aljorderid' => $neworder['aljorderid'],
                        'paytime' => $neworder['paytime'],
                        'orderid' => $neworder['orderid'],
                        'key' => $aljqbkey[$neworder['pluginname']][1],
                    );
                    //file_put_contents('test.txt',$aljqbkey[$neworder['pluginname']][1]."\r",FILE_APPEND);
                    $json = json_encode($keyarray);
                    $key = $qbapi->createKey($keyarray);
                    $postdata = array(
                        'aljorderid' => $neworder['aljorderid'],
                        'paytime' => $neworder['paytime'],
                        'orderid' => $neworder['orderid'],
                        'key' => $key,
                    );
                    //file_put_contents('test.txt',$key."\r",FILE_APPEND);
                    $status = postXmlCurl($postdata, $order['nurl']);
                    $status = strtolower($status);
                    if ($status != 'success') {
                        $qbapi->insertLog($order['nurl'] . lang("plugin/aljqb","aljqb_inc_php_115").' success');
                    }
                }
            }
        }
	}
	$tip = lang("plugin/aljqb","aljqb_inc_php_116");
    $navtitle = lang("plugin/aljqb","aljqb_inc_php_117");
	$face = 1;
	$url = $order['rurl'];
	if($_G['mobile']){
       //header("Refresh:2;url=".$url);
	}
	include template('aljqb:tip');
}else if($act == 'fail') {//֧��ʧ��
	$order = $payment->fetchOrder($_GET['out_trade_no']);
	$aljqb_params=array(
		'orderid'=> $order['orderid'],
		'time' => $order['createtime'],
		'price'=> $order['price'],
		'keyname' => $order['pluginname'],
		'key'=> $aljqbkey[$order['pluginname']][1],
		'return_url'=>$order['rurl'],
	);
	$url = $qbapi->createUrl($aljqb_params);
	//header("Refresh:2;url=".$url);
	$tip = lang("plugin/aljqb","aljqb_inc_php_118");
	$navtitle = lang("plugin/aljqb","aljqb_inc_php_119");
	include template('aljqb:tip');
}else if ($act == 'checkorder') {//��鶩��״̬
	$order = DB::fetch_first('select * from %t where orderid=%s and pluginname=%s',array('aljqb_payorder',$_GET['orderid'],$_GET['pluginname']));
	if(!empty($order)) {
		if($order['status']) {
			$url = $_G['siteurl'].'plugin.php?id=aljqb&act=success'.'&out_trade_no='.$order['aljorderid'];
			$tips = array('status'=>0,'url'=>$url);
			echo json_encode(ajaxPostCharSet_aljqb($tips));
			exit;
		}
	}
}else if ($act == 'checkpayorder') {//��ѯ֧������״̬
	$orderid = $_POST['orderid'];
	$pluginname = $_POST['pluginname'];
	if(!isset($_POST['orderid'])) {
		header('Location:'.$_G['siteurl']);
		exit;
	}
	$order = DB::fetch_first('select * from %t where orderid=%s and pluginname=%s',array('aljqb_payorder',$orderid,$pluginname));
	if(!empty($order)) {
		echo json_encode(ajaxPostCharSet_aljqb($order));
		exit;
	}else {
		$tips = array('code'=>400);
		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
	}
}else if($act == 'getranklist') { //���а�����
	$page=!empty($_GET['page'])?intval($_GET['page']):1;
	if($page<=10) {
		$pagesize=10;
		$offset=($page-1)*$pagesize;
		$ranklist = DB::fetch_all('select sum(credit) as income,username,uid from %t where type=%s and app_name!=%s GROUP BY uid order by income desc limit %d,%d',array('aljqb_accountchangelog','charge','aljqb',$offset,$pagesize));
		if(!empty($ranklist)) {
			include template('aljqb:ranklog');
			exit;
		}else {
			echo 1;
			exit;
		}
	}else {
		echo 1;
		exit;
	}
}else if($act == 'ranklist'){
	if(!$_G['cache']['plugin']['aljqb']['is_ranklist']){
		header('Location: plugin.php?id=aljqb');
		exit;
	}
	$ranklist = DB::fetch_all('select sum(credit) as income,username,uid from %t where type=%s and app_name!=%s GROUP BY uid order by income desc',array('aljqb_accountchangelog','charge','aljqb'));
	$navtitle = lang("plugin/aljqb","aljqb_inc_php_120");
	include template('aljqb:ranklist');
}else if ($act == 'gettxdata') {
	$newdata = DB::fetch_all('select * from %t where state=1 order by time desc limit %d,%d',array('aljqb_order',0,50));
	if($newdata) {
		$data = array();
		foreach($newdata as $tmp_key => $tmp_value) {
			$arr['head'] = avatar($tmp_value['uid'], 'middle', true);
			$arr['desc'] = $tmp_value['username'].lang("plugin/aljqb","aljqb_inc_php_121").$tmp_value['rmb'].lang("plugin/aljqb","aljqb_inc_php_122");
			$data[] = $arr;
			unset($arr);
		}
		$tips = array('state'=>0,'data'=>$data);
		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
	}else {
		$tips = array('state'=>1);
		echo json_encode(ajaxPostCharSet_aljqb($tips));
		exit;
	}
}else{
	$navtitle = lang("plugin/aljqb","aljqb_inc_php_123");
	include template('aljqb:wallet');
}
function randColor(){
	 $colors = array();
	 for($i = 0;$i<6;$i++){
		 $colors[] = dechex(rand(0,15));
	 }
	 return implode('',$colors);
}
//תΪ��ǰ����������
function ajaxGetCharSet_aljqb($arr) {
	if(is_array($arr)){
		if (strtolower(CHARSET) == 'gbk') {
			foreach ($arr as $key => $val) {
				if(is_array($val)){
					$pt_goods[$key] = ajaxGetCharSet_aljqb($val);
				}else{
					$pt_goods[$key] = diconv($val,'utf-8','gbk');
				}

			}
			return $pt_goods;
		}
		return $arr;
	} else {
		if (strtolower(CHARSET) == 'gbk') {
			return diconv($arr,'utf-8','gbk');
		}
		return $arr;
	}

}
//תΪjson����
function ajaxPostCharSet_aljqb($arr) {
	if(is_array($arr)){
		if (strtolower(CHARSET) == 'gbk') {
			foreach ($arr as $key => $val) {
				if(is_array($val)){
					$pt_goods[$key] = ajaxPostCharSet_aljqb($val);
				}else{
					$pt_goods[$key] = diconv($val,'gbk','utf-8');
				}

			}
			return $pt_goods;
		}
		return $arr;
	} else {
		if (strtolower(CHARSET) == 'gbk') {
			return diconv($arr,'gbk','utf-8');
		}
		return $arr;
	}
}
function unescape_aljqb($str) {
	if(is_array($str)) {
		foreach($str as $tmp_key=> $tmp_value) {
			$str[$tmp_key] = unicode_decode_aljqb($tmp_value);
		}
		return $str;
	}else {
		return unicode_decode_aljqb($str);
	}
}
function unicode_decode_aljqb($str) {
	$str = rawurldecode($str);
	preg_match_all("/(?:%u.{4})|&#x.{4};|&#\d+;|.+/U",$str,$r);
	$ar = $r[0];
	foreach($ar as $k=>$v) {
		if(substr($v,0,2) == "%u"){
			if(strtolower(CHARSET) == 'gbk'){
				$ar[$k] = iconv("UCS-2BE","gbk",pack("H4",substr($v,-4)));
			}else {
				$ar[$k] = iconv("UCS-2BE","UTF-8",pack("H4",substr($v,-4)));
			}

		}
		elseif(substr($v,0,3) == "&#x"){
			if(strtolower(CHARSET) == 'gbk'){
				$ar[$k] = iconv("UCS-2BE","gbk",pack("H4",substr($v,3,-1)));
			}else{
				$ar[$k] = iconv("UCS-2BE","UTF-8",pack("H4",substr($v,3,-1)));
			}
		}
		elseif(substr($v,0,2) == "&#") {
			if(strtolower(CHARSET) == 'gbk'){
				$ar[$k] = iconv("UCS-2BE","gbk",pack("n",substr($v,2,-1)));
			}else{
				$ar[$k] = iconv("UCS-2BE","UTF-8",pack("n",substr($v,2,-1)));
			}
		}
	}
	return join("",$ar);
}
function ismobile_aljqb($mobile) {
		global $_G;
    if (!is_numeric($mobile)) {
        return false;
    }
		$zengze = $_G['cache']['plugin']['aljhtx']['regular'] ? $_G['cache']['plugin']['aljhtx']['regular'] : '#^13[\d]{9}$|^14[5,7]{1}\d{8}$|^15[^4]{1}\d{8}$|^17[0,1,3,5,6,7,8]{1}\d{8}$|^18[\d]{9}$|^19[8,9]{1}\d{8}$#';
    return preg_match($zengze, $mobile) ? true : false;
}
function GsetCookie($name, $value, $expire = null){
    //����ʱ��
    if(empty($expire)) {
		$expire = time() + 86400;
	}else {
		$expire = time() + $expire;
	}
    $_COOKIE[$name] = $value;
    //�ж�value�Ƿ�������
    if(is_array($value)){
        foreach ($value as $k => $v){
            if(empty($v)) continue;
            setcookie($name . "[$k]", $v, $expire);
        }
    }else{
        setcookie($name, $value, $expire);
    }
}
//�������
function check_email($email){
	$pattern = "/^([0-9A-Za-z\\-_\\.]+)@([0-9a-z]+\\.[a-z]{2,3}(\\.[a-z]{2})?)$/i";
	if( preg_match($pattern,$email)){
		return true;
	}else{
		return false;
	}
}
//����ֻ�
function check_phone($phonenumber) {
	if(preg_match("/^1[34578]{1}\d{9}$/",$phonenumber)){
		return true;
	}else{
		return false;
	}
}
?>
