<?php

/*
 * ����: Discuz!�����ƹ�����
 * ����֧��: https://dism.taobao.com?/
 * ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$geturl = ltrim('plugin.php?'.$_SERVER['QUERY_STRING'],'/');
if((strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0  || strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false) && strpos($_SERVER['HTTP_USER_AGENT'],"bsl") === false){
	$isappbyme = true;
	$trade_type = 'APP';
}
foreach($_G['cache']['plugin']['aljqb'] as $k => $v){
    $config[$k] = $v;//ͳһ�����ע���������Ҫ��ͻ
}
$config['cashtype'] = str_replace("\r\n", "\n", $config['cashtype']);
$config['cashtype'] = explode("\n", $config['cashtype']);
foreach($config['cashtype'] as $tmp){
	$tmp = explode("=", $tmp);
	$cashtypelist[$tmp[0]] = $tmp[1];
}
$settings_aljbd=C::t('#aljqb#aljqb_paysetting')->range();
foreach($settings_aljbd as $k => $v){
	$config[$k] = $v['value'];//ͳһ�����ע���������Ҫ��ͻ
}

$notify_url = $config['OAuth'].'source/plugin/aljqb/pay/notify_url.php';
$keynum = DB::result_first('select count(*) from %t',array('aljqb_secretkey'));
if($keynum<=0) {
	$aljqbkeys = explode ("\n", str_replace ("\r", "", $config['aljqbkey']));
	foreach($aljqbkeys as $key=>$value){
		$arr=explode('|',$value);
		$aljqbkey[$arr[0]]=$arr;
	}
}else{
	$aljqbkeys = DB::fetch_all('select * from %t',array('aljqb_secretkey'));
	foreach($aljqbkeys as $tmp_key => $tmp_value) {
		$arr[0] = $tmp_value['pluginname'];
		$arr[1] = $tmp_value['secretkey'];
		$arr[2] = $tmp_value['tokenurl'];
		$aljqbkey[$tmp_value['pluginname']]=$arr;
		unset($arr);
	}
}


if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
	$iswechat = true;
	$trade_type = 'JSAPI';
}
if(strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPPX')>0 && strpos($_SERVER['HTTP_USER_AGENT'],"bsl") === false){
    $ismagapp = true;
    $trade_type = 'magapp';
}
if(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'qianfan') !== false && strpos($_SERVER['HTTP_USER_AGENT'],"bsl") === false){
    $isqianfanapp = true;
    $trade_type = 'qianfanapp';
}
//ǧ��app����ַ�������
function qianfanapp_nonce($length = 32){
    $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    $str ="";
    for ( $i = 0; $i < $length; $i++ )  {
        $str .= substr($chars, mt_rand(0, strlen($chars)-1), 1);
    }
    return $str;
}
//ǧ��appǩ���㷨
function qianfanapp_sign($params, $secret) {
    ksort($params);
    $sparams = array();
    foreach ($params as $k => $v) {
        if ("@" != substr($v, 0, 1)) {
            $sparams[] = "$k=$v";
        }
    }
    $sparams[] = "secret=" . $secret;
    return strtoupper(md5(implode("&", $sparams)));
}
//ǧ��app������ѯ
function qianfanapp_query($orderid){
    global $_G,$config;
    $nonce = qianfanapp_nonce();
    $data = array(
        'order_id' => $orderid,
        'nonce' => $nonce,
    );

    $data['sign']  = qianfanapp_sign($data, $config['qianfanapp_secert']);
	$url = str_replace('{hostname}', $config['qianfanapp_hostname']?$config['qianfanapp_hostname']:'pethome', 'http://{hostname}.qianfanapi.com/api1_2/orders/query?'.http_build_query($data));
		
    $result = json_decode(dfsockopen($url),true);
    
    return $result;
}
//ǧ���˿�ӿ�
function qianfanapp_refund($orderid,$out_trade_no,$cash){
	global $_G,$config;
	if($config['qianfanapp_api_type'] == 1){
		return qianfanapp_refund_new($orderid,$out_trade_no,$cash);
	}else{
		$nonce = qianfanapp_nonce();
		$data = array(
			'order_id' => $orderid,
			'out_trade_no' => $out_trade_no,
			'nonce' => $nonce,
			'cash' => $cash,
		);
		//http://{hostname}.qianfanapi.com/api1_2/orders/query
		$data['sign']  = qianfanapp_sign($data, $config['qianfanapp_secert']);

		$url = str_replace('{hostname}', $config['qianfanapp_hostname'], 'http://{hostname}.qianfanapi.com/api1_2/orders/refund');
			
		$result = json_decode(dfsockopen($url,0,$data),true);
		return $result;
	}
}
//Ǯ������Զ����ֵ�ǧ��APP���
function qianfanapp_auto_balance ($balance,$uid=0) {
	global $_G,$config;
	if($config['qianfanapp_api_type'] == 1){
		return qianfanapp_auto_balance_new ($balance,$uid);
	}else{
		$qfurl = "http://{hostname}.qianfanapi.com/api1_2/balance/add";
		$qfurl = str_replace('{hostname}', $config['qianfanapp_hostname'], $qfurl);
		$data = array(
			'uid' => $uid>0 ? $uid : $_G['uid'],
			'type' => $config['qianfanapp_txtype'],
			'amount' => $balance * 100,
		);
		$data['sign'] = qianfanapp_sign($data, $config['qianfanapp_secert']);
		$result = dfsockopen($qfurl, 0, $data);
		return $result;
	}
}
//ǧ��app������ѯ NEW
function qianfanapp_query_new($orderid){
	global $_G,$config;
	//http://https://api.pethome.cn//openapi/payments/{����ID}

	$url = str_replace('{hostname}', $config['qianfanapp_hostname']?$config['qianfanapp_hostname']:'pethome', 'https://api.{hostname}.cn/openapi/payments/'.$orderid.'/info');
	

	$result = json_decode(qianfanapp_curl($url),true);
    
    return $result;
}
//ǧ���˿�ӿ� NEW
function qianfanapp_refund_new($orderid,$out_trade_no,$cash){
	global $_G,$config;


    $data = array(
        'target' => 0,
        'app_trade_no' => $out_trade_no,
		'cash' => $cash,
    );
    $url = str_replace('{hostname}', $config['qianfanapp_hostname'], 'https://api.{hostname}.cn/openapi/payments/'.$orderid.'/refund');
	
    $result = json_decode(qianfanapp_curl($url,$data),true);
    return $result;
}
//Ǯ������Զ����ֵ�ǧ��APP��� 
function qianfanapp_auto_balance_new ($balance,$uid=0) {
    global $_G,$config;
	$qfurl = "https://api.{hostname}.cn/openapi/wallets/{uid}";
	$qfurl = str_replace(array('{hostname}','{uid}'), array($config['qianfanapp_hostname'],$uid>0 ? $uid : $_G['uid']), $qfurl);
    $data = array(
        'reason' => 'TOAPP',
        'type' => $config['qianfanapp_txtype'],
        'cash' => '+'.$balance,
	);
	$result = qianfanapp_curl($qfurl,$data);
	
    return $result;
}
//ǧ���½ӿ� CURL PUT
function qianfanapp_curl($url,$data=''){
	global $_G,$config;
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_MUTE, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

	//curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST,"PUT"); //��������ʽ
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Authorization: Bearer '.$config['qianfanapp_token'],"X-HTTP-Method-Override: PUT"));
	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
	
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$output = curl_exec($ch);
	curl_close($ch);
	return $output;
}
//Ǯ������Զ����ֵ�����APP���
function magapp_auto_balance ($balance,$txorderid='',$uid=0) {
    global $_G,$config;
    $ma_server = rtrim($config['magapp_url'], '/');
    $secret = $config['magapp_secret'];
	$remark = "TOAPP";
	$uid = $uid>0 ? $uid : $_G['uid'];
    $result = dfsockopen( "$ma_server/core/pay/pay/accountTransfer?secret=$secret&user_id={$uid}&amount={$balance}&remark=$remark&out_trade_code=$txorderid");
    return $result;
}
//�������ɶ���
function magapppay($params_ma){
    global $_G,$config;
    $ma_server = rtrim($config['magapp_url'], '/');
    $url = "$ma_server/core/pay/pay/unifiedOrder?";
    $result = json_decode(postdata($url,$params_ma),true);
    return $result;
}
//���׶�����ѯ
function magapppay_query($unionOrderNum){
    global $_G,$config;
    $ma_server = rtrim($config['magapp_url'], '/');
    $secret    = $config['magapp_secret'];
    $params_ma = array(
        'unionOrderNum' => $unionOrderNum,
        'secret' => $secret,
    );
    $url = "$ma_server/core/pay/pay/orderStatusQuery?";
    $result = json_decode(postdata($url,$params_ma),true);
    return $result;
}
//֧����ת��
function alipaytrans($out_biz_no, $payee_account, $amount=0, $remark='', $payer_show_name='',$payee_real_name=''){
	global $_G,$config;
	$apiurl = 'https://openapi.alipay.com/gateway.do';
	$biz_content = array(
		'out_biz_no' => $out_biz_no,
		'payee_type' => 'ALIPAY_LOGONID',
		'payee_account' => $payee_account,
		'amount' => $amount,
	);
	if($remark) {
		$biz_content['remark'] = diconv($remark, CHARSET, 'utf-8');
	}
	if($payer_show_name) {
		$biz_content['payer_show_name'] = diconv($payer_show_name, CHARSET, 'utf-8');
	}
	if($payee_real_name) {
		$biz_content['payee_real_name'] = diconv($payee_real_name, CHARSET, 'utf-8');
	}
	$args = array(
		'app_id' => $config['trans_appid'],
		'method' => 'alipay.fund.trans.toaccount.transfer',
		'format' => 'JSON',
		'charset' => 'utf-8',
		'sign_type' => 'RSA2',
		'timestamp' => dgmdate(TIMESTAMP,'Y-m-d H:i:s'),
		'version' => '1.0',
		'biz_content' => json_encode($biz_content),
	);
	$args['sign'] = alonersaSign(formatBizQueryParaMap($args), getcwd().'/source/plugin/aljqb/function/cert/rsa_private_key.pem', 'RSA2', true);//��װ����ǩ������

	$args = getSignContentUrlencode($args);

	return postdata($apiurl, $args);
}
//֧�����˿�
function alipayrefund($params){
	global $_G,$config;
	$apiurl = 'https://openapi.alipay.com/gateway.do';
	$biz_content = array(
		'trade_no' => $params['buyer'],//֧�������׺�
		'refund_amount' => $params['price'],//�˿�Ľ��
	);
	if($params['refund_reason']) {
		$biz_content['refund_reason'] = diconv($refund_reason, CHARSET, 'utf-8');
	}
	
	$args['app_id'] = $config['trans_appid'];
	$args['method'] = 'alipay.trade.refund';
	$args['format'] = 'JSON';
	$args['charset'] = 'utf-8';
	$args['sign_type'] = 'RSA2';
	
	$args['timestamp'] = dgmdate(TIMESTAMP,'Y-m-d H:i:s');
	$args['version'] = '1.0';
	$args['biz_content'] = json_encode($biz_content);
	$args['sign'] = alonersaSign(formatBizQueryParaMap($args), getcwd().'/source/plugin/aljqb/function/cert/rsa_private_key.pem', 'RSA2', true);//��װ����ǩ������
	$args = getSignContentUrlencode($args);

	return postdata($apiurl, $args);
}
function getSignContentUrlencode($params) {
	ksort($params);

	$stringToBeSigned = "";
	$i = 0;
	foreach ($params as $k => $v) {
		if ("@" != substr($v, 0, 1)) {
			if ($i == 0) {
				$stringToBeSigned .= "$k" . "=" . urlencode($v);
			} else {
				$stringToBeSigned .= "&" . "$k" . "=" . urlencode($v);
			}
			$i++;
		}
	}
	unset ($k, $v);
	return $stringToBeSigned;
}
function alonersaSign($data,$privatekey='',$signType = "RSA",$keyfromfile=false) {
	global $queue;
	if(!$keyfromfile){
		$priKey=$privatekey;

		$res = "-----BEGIN RSA PRIVATE KEY-----\n" .
			wordwrap($priKey, 64, "\n", true) .
			"\n-----END RSA PRIVATE KEY-----";
	}
	else{
		$priKey = file_get_contents($privatekey);
		$res = openssl_get_privatekey($priKey);
	}
	if(!$res) {
	    $queue->insertLog('res error'.$privatekey);
	}

	($res) or die('error');
	if ("RSA2" == $signType) {
		openssl_sign($data, $sign, $res, OPENSSL_ALGO_SHA256);
	} else {
		openssl_sign($data, $sign, $res);
	}

	if($keyfromfile){
		openssl_free_key($res);
	}
	$sign = base64_encode($sign);
	return $sign;
}

//debug($config);
function alipaysend($order){
	global $_G,$config;
	$logistics_name = $order['logistics_name']?$order['logistics_name']:diconv($_G['setting']['bbname'],CHARSET,'UTF-8');
	$params = array(
		'service' => 'send_goods_confirm_by_platform',
		'partner' => $config['pcpartner'],
		'_input_charset' => 'utf-8',
		'trade_no' => $order['transaction_id'],
		'logistics_name' => $logistics_name,
		'transport_type' => 'EXPRESS',
	);
	if($order['invoice_no']){
		$params['invoice_no'] = $order['invoice_no'];
	}
	$params['sign'] = getAlipaySign($params,$config['pckey']);
	$params['sign_type'] = 'MD5';
	postdata('https://mapi.alipay.com/gateway.do?',$params);
}
function pcalipay($args) {
	global $_G,$config;
	//$args['price'] = $args['price'] - 0.01;
	$args['service'] = $config['service'];
	$args['partner'] = $config['pcpartner'];
	$args['_input_charset'] = 'utf-8';
	$args['quantity'] = 1;
	$args['seller_email'] = $config['pcaccount'];
	$args['extend_param'] = 'liangjian';
	$args['payment_type'] = 1;
	if($config['service'] != 'create_direct_pay_by_user') {
		$args['logistics_type'] = 'EXPRESS';//POSTƽ�� EXPRESS�������  EMS
		$args['logistics_fee'] = '0.00';
		$args['logistics_payment'] = 'SELLER_PAY';//BUYER_PAY
	}
	$args['sign'] = getAlipaySign($args,$config['pckey']);
	$args['sign_type'] = 'MD5';
	ksort($args);
	return  'https://www.alipay.com/cooperate/gateway.do?'.formatBizQueryParaMap($args,true);
}
function alipay($parameter){
	global $_G,$config;
	if($_G['mobile']) {
		$parameter['service'] = "alipay.wap.create.direct.pay.by.user";
	}else {
		$parameter['service'] = "create_direct_pay_by_user";
	}
	$parameter['partner'] = $config['mpartner'];
	$parameter['seller_id'] = $config['mpartner'];
	$parameter['payment_type'] = 1;
	$parameter['_input_charset'] = 'utf8';
	ksort($parameter);
	reset($parameter);
	$parameter['sign'] = getAlipaySign($parameter,$config['mkey']);
	$parameter['sign_type'] = 'MD5';

	return  'https://mapi.alipay.com/gateway.do?'.formatBizQueryParaMap($parameter,true);
}
function alipayPlus($out_trade_no, $subject, $total_amount, $notify_url){
	global $_G,$config;
	$apiurl = 'https://openapi.alipay.com/gateway.do';
	if(strtolower(CHARSET) == 'gbk'){
		$subject = diconv($subject, 'gbk', 'utf-8');
	}
	$biz_content = array(
		'out_trade_no' => $out_trade_no,
		'subject' => $subject,
		'total_amount' => $total_amount,
	);
	
	$args = array(
		'app_id' => $config['trans_appid'],
		'method' => 'alipay.trade.app.pay',
		'format' => 'JSON',
		'notify_url' => $notify_url, 
		'charset' => 'utf-8',
		'sign_type' => 'RSA2',
		'timestamp' => dgmdate(TIMESTAMP,'Y-m-d H:i:s'),
		'version' => '1.0',
		'biz_content' => json_encode($biz_content),
	);

	$args['sign'] = alonersaSign(formatBizQueryParaMap($args), getcwd().'/source/plugin/aljqb/function/cert/rsa_private_key.pem', 'RSA2', true);//��װ����ǩ������

	$args = getSignContentUrlencode($args);
	return $args;
	//return postdata($apiurl, $args);
}

function rsaCheckV2($params, $signType='RSA2') {
	//file_put_contents('444555.txt',getSignContent($params),FILE_APPEND);
	$sign = $params['sign'];
	$params['sign'] = null;
	$params['sign_type'] = null;
	return verifyAlipayPlus(getSignContent($params), $sign, DISCUZ_ROOT.'/source/plugin/aljqb/function/cert/rsa_public_key.pem', $signType);
}

function verifyAlipayPlus($data, $sign, $rsaPublicKeyFilePath, $signType = 'RSA2') {
	
	//��ȡ��Կ�ļ�
	$pubKey = file_get_contents($rsaPublicKeyFilePath);
	//ת��Ϊopenssl��ʽ��Կ
	$res = openssl_get_publickey($pubKey);

	($res) or die('error');  
	//debug($res);
	//����openssl���÷�����ǩ������boolֵ
	
	//if ("RSA2" == $signType) {
	if(1){
		$result = (bool)openssl_verify($data, base64_decode($sign), $res, OPENSSL_ALGO_SHA256);
	} else {
		$result = (bool)openssl_verify($data, base64_decode($sign), $res);
	}

	openssl_free_key($res);
	return $result;
}
/**
 * ��֤ǩ��
 * @param $prestr ��Ҫǩ�����ַ���
 * @param $sign ǩ�����
 * return ǩ�����
 */
function rsaVerify($prestr, $sign) {
    $sign = base64_decode($sign);
    $public_key= file_get_contents(DISCUZ_ROOT.'/source/plugin/aljqb/function/cert/rsa_public_key.pem');
    $pkeyid = openssl_get_publickey($public_key);
    if ($pkeyid) {
        $verify = openssl_verify($prestr, $sign, $pkeyid, OPENSSL_ALGO_SHA256);
        openssl_free_key($pkeyid);
    }
    if($verify == 1){
        return true;
    }else{
        return false;
    }
}
/**
 * ǩ���ַ���
 * @param $prestr ��Ҫǩ�����ַ���
 * return ǩ�����
 */
function rsaSign($prestr) {
    $public_key= file_get_contents('rsa_private_key.pem');
    $pkeyid = openssl_get_privatekey($public_key);
    openssl_sign($prestr, $sign, $pkeyid);
    openssl_free_key($pkeyid);
    $sign = base64_encode($sign);
    return $sign;
}
function getSignContent($params) {
	ksort($params);

	$stringToBeSigned = "";
	$i = 0;
	foreach ($params as $k => $v) {
		if (false === checkEmpty($v) && "@" != substr($v, 0, 1)) {

			if ($i == 0) {
				$stringToBeSigned .= "$k" . "=" . $v;
			} else {
				$stringToBeSigned .= "&" . "$k" . "=" . $v;
			}
			$i++;
		}
	}

	unset ($k, $v);
	return $stringToBeSigned;
}
/**
 * У��$value�Ƿ�ǿ�
 * if not set ,return true;
 * if is null , return true;
**/
function checkEmpty($value) {
	if (!isset($value))
		return true;
	if ($value === null)
		return true;
	if (trim($value) === "")
		return true;

	return false;
}

function getAlipaySign($Obj,$apikey=''){
	foreach ($Obj as $k => $v){
		if($k == "sign" || $k == "sign_type" || $v == ""){
			continue;
		}else{
			$parameters[$k] = $v;
		}
	}
	ksort($parameters);
	$string = formatBizQueryParaMap($parameters);
	$string = $string.$apikey;
	$string = md5($string);
	return $string;
}
function getSignVeryfy($parameters,$sign=''){
	global $_G,$config;
	if(empty($parameters)) {
		return false;
	}
	ksort($parameters);

	$string = getAlipaySign($parameters,$config['mkey']);

	$veryfy_url = 'http://notify.alipay.com/trade/notify_query.do?'."partner=" .$config['mpartner']. "&notify_id=" . $parameters['notify_id'];
	if($string == $sign && postdata($veryfy_url)){
		return true;
	}
	return false;
}
function postdata($url, $para = '', $input_charset = '', $follow=0) {
    if (trim($input_charset) != '') {
        $url = $url."_input_charset=".$input_charset;
    }
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_HEADER, 0 );
    curl_setopt($curl,CURLOPT_RETURNTRANSFER, 1);
	//curl_setopt ($ch,CURLOPT_REFERER,$_G['siteurl']);
	if($para){
		curl_setopt($curl,CURLOPT_POST,true);
		curl_setopt($curl,CURLOPT_POSTFIELDS,$para);
	}
    if($follow) {
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($curl, CURLOPT_MAXREDIRS, 3);
    }
    $responseText = curl_exec($curl);
    $headers = curl_getinfo($curl);
    curl_close($curl);
    if($para&& $headers && $headers['url'] && $follow) {
         header('Location: '.$headers['url']);
    }
    //var_dump( curl_error($curl) );
    return $responseText;
}
function wxpay($parameters){
	global $_G,$config;
	$timestamp = $_G['timestamp'];
    if($_GET['session3rd']){
		if($_GET['minitype'] == 'tc'){
			$config['appid'] =  $_G['cache']['plugin']['aljtwx']['appid'];
		}else if($_GET['minitype'] == 'sqtg'){
			$config['appid'] =  $_G['cache']['plugin']['aljswx']['appid'];
		}else{
			$config['appid'] =  $_G['cache']['plugin']['aljwx']['appid'];
		}
    }
	$jsApiObj["appId"] = $config['appid'];
	$jsApiObj["timeStamp"] = "$timestamp";
	$jsApiObj["nonceStr"] = createNoncestr();
	$jsApiObj["package"] = "prepay_id=".getPrepayId1($parameters);
	$jsApiObj["signType"] = "MD5";
	$jsApiObj["paySign"] = getSign($jsApiObj,$config['key']);
	return json_encode($jsApiObj);
}

function apppay($parameters){
	global $_G,$config;
	$timestamp = $_G['timestamp'];
	$apppay = array();
	$apppay['appid'] = $config["appid2"];
	$apppay['partnerid'] = $config["mchid2"];
	$apppay['prepayid'] = getPrepayId2($parameters);
	$apppay['noncestr'] = createNoncestr();
	$apppay['timestamp'] = "$timestamp";
	$apppay['package'] = "Sign=WXPay";
	$apppay['sign'] = getSign($apppay,$config['key2']);
	return $apppay;
}

function getPrepayId1($parameters){
	global $_G,$config,$queue;
	$parameters["trade_type"] = 'JSAPI';
    if($_GET['session3rd']){
        if($_GET['minitype'] == 'tc'){
			$config['appid'] =  $_G['cache']['plugin']['aljtwx']['appid'];
		}else if($_GET['minitype'] == 'sqtg'){
			$config['appid'] =  $_G['cache']['plugin']['aljswx']['appid'];
		}else{
			$config['appid'] =  $_G['cache']['plugin']['aljwx']['appid'];
		}
    }
	$parameters["appid"] = $config['appid'];
	$parameters["mch_id"] = $config['mchid'];
	$parameters["spbill_create_ip"] = $_G['clientip'];
	$parameters["nonce_str"] = createNoncestr();
	$parameters["sign"] = getSign($parameters,$config['key']);
	$prepaystr = postXmlCurl(arrayToXml($parameters),"https://api.mch.weixin.qq.com/pay/unifiedorder");
	$postObj = xmlToArray($prepaystr);
	if($postObj['return_code'] != 'SUCCESS'){
		$error = json_encode($postObj);
		if(strtolower(CHARSET) == 'gbk') {
			$error = diconv($error,'utf-8','gbk');
		}
		$queue->insertLog('wxpay '.$error);
	}

	return $postObj['prepay_id'];
}
function getPrepayId2($parameters){
	global $_G,$config,$queue;
	$parameters["trade_type"] = 'APP';
	$parameters["appid"] = $config['appid2'];
	$parameters["mch_id"] = $config['mchid2'];
	$parameters["spbill_create_ip"] = $_G['clientip'];
	$parameters["nonce_str"] = createNoncestr();
	$parameters["sign"] = getSign($parameters,$config['key2']);

	$prepaystr = postXmlCurl(arrayToXml($parameters),"https://api.mch.weixin.qq.com/pay/unifiedorder");
	$postObj = xmlToArray($prepaystr);
    if($postObj['return_code'] != 'SUCCESS'){
        $error = json_encode($postObj);
        if(strtolower(CHARSET) == 'gbk') {
            $error = diconv($error,'utf-8','gbk');
        }
        $queue->insertLog('wxpay '.$error);
    }
	return $postObj['prepay_id'];
}
function postxml($url,$data=''){
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_MUTE, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: text/xml'));
	curl_setopt($ch, CURLOPT_POSTFIELDS, "$data");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$output = curl_exec($ch);
	curl_close($ch);
	return $output;
}
function createNoncestr( $length = 32 ){
	$chars = "abcdefghijklmnopqrstuvwxyz0123456789";
	$str ="";
	for ( $i = 0; $i < $length; $i++ )  {
		$str.= substr($chars, mt_rand(0, strlen($chars)-1), 1);
	}
	return $str;
}
function getSign($Obj,$apikey=''){
	foreach ($Obj as $k => $v)
	{
		$parameters[$k] = $v;
	}
	ksort($parameters);
	$string = formatBizQueryParaMap($parameters, false);
	$string = $string."&key=$apikey";
	$string = md5($string);
	$result_ = strtoupper($string);
	return $result_;
}
function formatBizQueryParaMap($paraMap, $urlencode=false){
	$buff = "";
	ksort($paraMap);
	foreach ($paraMap as $k => $v)
	{
		if($urlencode)
		{
		   $v = urlencode($v);
		}
		$buff .= $k . "=" . $v . "&";
	}
	$reqPar;
	if (strlen($buff) > 0)
	{
		$reqPar = substr($buff, 0, strlen($buff)-1);
	}
	return $reqPar;
}
function arrayToXml($arr){
	$xml = "<xml>";
	foreach ($arr as $key=>$val)
	{
		 if (is_numeric($val))
		 {
			$xml.="<".$key.">".$val."</".$key.">";

		 }
		 else
			$xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
	}
	$xml.="</xml>";
	return $xml;
}
function xmlToArray($xml){
    //��XMLתΪarray
    //��ֹ�����ⲿxmlʵ��
    if(function_exists(libxml_disable_entity_loader)){
        libxml_disable_entity_loader(true);
    }
	$array_data = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
	return $array_data;
}
function postXmlCurl($xml,$url,$second=30){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_TIMEOUT, $second);
	curl_setopt($ch,CURLOPT_URL, $url);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
	curl_setopt($ch, CURLOPT_HEADER, FALSE);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	curl_setopt($ch, CURLOPT_POST, TRUE);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
	$data = curl_exec($ch);
	curl_close($ch);
	if($data){
		curl_close($ch);
		return $data;
	}
}
function createOauthUrlForCode($redirectUrl){
	global $config;
	$urlObj["appid"] = $config['appid'];
	$urlObj["redirect_uri"] = "$redirectUrl";
	$urlObj["response_type"] = "code";
	$urlObj["scope"] = "snsapi_base";
	$urlObj["state"] = "STATE"."#wechat_redirect";
	$bizString = formatBizQueryParaMap($urlObj, false);
	return "https://open.weixin.qq.com/connect/oauth2/authorize?".$bizString;
}
//��ȡOpenid
function getopenid($geturl){
	global $_G,$config,$queue;
	if (!isset($_GET['code'])){
        $url = createOauthUrlForCode($config['OAuth'].$geturl);
		Header("Location:".$url);
		exit;
	}else{
		$code = $_GET['code'];
	}

	$url="https://api.weixin.qq.com/sns/oauth2/access_token?appid=".$config['appid']."&secret=".$config['appsecret']."&code=$code&grant_type=authorization_code";
	$result = postXmlCurl('',$url);
	$jsoninfo = json_decode($result, true);
	if(isset($jsoninfo['errcode'])) {
		if(strtolower(CHARSET) == 'gbk') {
			$error = diconv($result,'utf-8','gbk');
		}else {
			$error = $result;
		}
		$queue->insertLog('wxopenid '.$error);
	}
	return $jsoninfo["openid"];
}
//��ȡ��������
function getaccess_token($geturl){
	global $_G,$config,$queue;
	if (!isset($_GET['code'])){
		$url = createOauthUrlForCode($config['OAuth'].$geturl);
		Header("Location:".$url);
		exit;
	}else{
		$code = $_GET['code'];
	}

	$url="https://api.weixin.qq.com/sns/oauth2/access_token?appid=".$config['appid']."&secret=".$config['appsecret']."&code=$code&grant_type=authorization_code";
	$result = postXmlCurl('',$url);
	if(strtolower(CHARSET) == 'gbk') {
		$error = diconv($result,'utf-8','gbk');
	}else {
		$error = $result;
	}
	$queue->insertLog('wxopenid '.$error);
	$jsoninfo = json_decode($result, true);
	return $jsoninfo;
}
function getWxh5pay($parameters){
	global $_G,$config;
	$parameters["trade_type"] = 'MWEB';
	$parameters["appid"] = $config['appid'];
	$parameters["mch_id"] = $config['mchid'];
	$parameters["spbill_create_ip"] = $_G['clientip'];
	$parameters["nonce_str"] = createNoncestr();
	$parameters["sign"] = getSign($parameters,$config['key']);
	$prepaystr = postXmlCurl(arrayToXml($parameters),"https://api.mch.weixin.qq.com/pay/unifiedorder ");
	$postObj = xmlToArray($prepaystr);
	//debug(diconv($postObj['return_msg'], 'utf-8', 'gbk'));
	return $postObj['mweb_url'];
}
//΢��ת��
function wxchattransfers($senddata){
    global $_G,$config;
    if(empty($senddata['amount']) || empty($senddata['openid'])){
        return;
    }
    $url = 'https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers';
    $sendredpack['nonce_str'] = createNoncestr();
    $sendredpack['mchid'] = $config['mchid'];
    $sendredpack['mch_appid'] = $config['appid'];
    $sendredpack['partner_trade_no'] = $senddata['orderid'];
    $sendredpack['openid'] = $senddata['openid'];
    $sendredpack['check_name'] = 'NO_CHECK';
    $sendredpack['amount'] = $senddata['amount']*100;
    $sendredpack['desc'] = $senddata['desc']?diconv($senddata['desc'],CHARSET,'utf-8'):diconv('test',CHARSET,'utf-8');
    $sendredpack['spbill_create_ip'] = $_G['clientip'];
    $sendredpack['sign'] = getSign($sendredpack,$config['key']);
    $result = wxpostXmlCurl(arrayToXml($sendredpack),$url,30,true);
    //$result = diconv($result,'utf-8',CHARSET);
    $result = xmlToArray($result);
    return $result;
}
function wxpostXmlCurl($xml,$url,$second=30,$pem=''){
	global $queue;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_TIMEOUT, $second);
	curl_setopt($ch,CURLOPT_URL, $url);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
	curl_setopt($ch, CURLOPT_HEADER, FALSE);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	curl_setopt($ch, CURLOPT_POST, TRUE);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
    if($pem){
        curl_setopt($ch,CURLOPT_SSLCERT,DISCUZ_ROOT .'/source/plugin/aljqb/function/cert/apiclient_cert.pem');
        curl_setopt($ch,CURLOPT_SSLKEY,DISCUZ_ROOT .'/source/plugin/aljqb/function/cert/apiclient_key.pem');
        //curl_setopt($ch,CURLOPT_CAINFO,getcwd().'/source/plugin/aljqb/function/cert/rootca.pem');
	}
	
	$data = curl_exec($ch);
	if($data === false)
	{
		$queue->insertLog('Curl error: ' . curl_error($ch));
	}

	curl_close($ch);
	if($data){
		curl_close($ch);
		return $data;
	}
}
function getcodeurl($parameters){
	global $_G,$config,$queue;
	$parameters["trade_type"] = 'NATIVE';
	$parameters["appid"] = $config['appid'];
	$parameters["mch_id"] = $config['mchid'];
	$parameters["spbill_create_ip"] = $_G['clientip'];
	$parameters["nonce_str"] = createNoncestr();
	$parameters["sign"] = getSign($parameters,$config['key']);
	$prepaystr = postXmlCurl(arrayToXml($parameters),"https://api.mch.weixin.qq.com/pay/unifiedorder");
	$postObj = xmlToArray($prepaystr);
	if($postObj['return_code'] == 'FAIL'){
		$error = json_encode($postObj);
		if(strtolower(CHARSET) == 'gbk') {
			$error = diconv($error,'utf-8','gbk');
		}
		$queue->insertLog('pccode '.$error);
	}
	return $postObj['code_url'];
}
/*΢���˿�*/
function wxpayrefund($senddata){
	global $_G,$config,$queue;
    $url = 'https://api.mch.weixin.qq.com/secapi/pay/refund';
    $sendredpack['nonce_str'] = createNoncestr();
    $sendredpack['mch_id'] = $senddata['mch_id'];
    $sendredpack['appid'] = $senddata['appid'];
    $sendredpack['op_user_id'] = $senddata['mch_id'];
    $sendredpack['transaction_id'] = $senddata['orderid'];
    $sendredpack['total_fee'] = $senddata['price']*100;
    $sendredpack['refund_fee'] = $senddata['refund_fee']?$senddata['refund_fee']*100:$senddata['price']*100;
    $sendredpack['out_refund_no'] = $senddata['out_refund_no'];
    if(!$senddata['location']){
        //$queue->insertLog('wxpayrefund &#36864;&#27454;&#35777;&#20070;&#26410;&#37197;&#32622;');
	}
	
    //$sendredpack['refund_account'] = 'REFUND_SOURCE_RECHARGE_FUNDS';
    $sendredpack['sign'] = getSign($sendredpack,$senddata['key']);
	//$result = postXmlCurl(arrayToXml($sendredpack),$url,30,true,$senddata['location']);
	$result = wxpostXmlCurl(arrayToXml($sendredpack),$url,30,true);
	$data = xmlToArray($result);
	if($data['result_code'] == 'FAIL' && $data['err_code'] == 'NOTENOUGH'){
		$sendredpack['refund_account'] = 'REFUND_SOURCE_RECHARGE_FUNDS';
		$sendredpack['sign'] = getSign($sendredpack,$senddata['key']);
		//$result = postXmlCurl(arrayToXml($sendredpack),$url,30,true,$senddata['location']);
		$result = wxpostXmlCurl(arrayToXml($sendredpack),$url,30,true);
		$data = xmlToArray($result);
	}
    if($data['result_code'] == 'FAIL' || $data['return_code'] == 'FAIL'){
		$error = json_encode($data);
		if(strtolower(CHARSET) == 'gbk') {
			$error = diconv($error,'utf-8','gbk');
		}
		$queue->insertLog('wxpayrefund '.$error);
    }
    //debug(diconv($result,'utf-8','gbk'));
    return $result;
}
function wxpayrefundquery($senddata){
    global $_G,$config,$queue;;
    $url = 'https://api.mch.weixin.qq.com/pay/refundquery';
    $sendredpack['nonce_str'] = createNoncestr();
    $sendredpack['mch_id'] = $senddata['mch_id'];
    $sendredpack['appid'] = $senddata['appid'];
    $sendredpack['transaction_id'] = $senddata['orderid'];
    $sendredpack['sign'] = getSign($sendredpack,$senddata['key']);
	//debug($sendredpack);
	//$result = postXmlCurl(arrayToXml($sendredpack),$url,30,true,$senddata['location']);
	$result = wxpostXmlCurl(arrayToXml($sendredpack),$url,30,true);
    //debug(diconv($result,'utf-8','gbk'));
    return $result;
}
?>
