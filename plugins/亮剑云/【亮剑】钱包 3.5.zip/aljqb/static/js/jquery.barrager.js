/*!
 *@name     jquery.barrager.js
 *@author   yaseng@uauc.net
 *@url      https://github.com/yaseng/jquery.barrager.js
 */
(function($) {

	$.fn.barrager = function(barrage) {
		barrage = $.extend({
			close:true,
			bottom: 0,
			max: 10,
			speed: 6,
			color: '#fff',
			background:'rgba(0,0,0,.5)',
			old_ie_color : '#000000'
		}, barrage || {});

		var time = new Date().getTime();
		var barrager_id = 'barrage_' + time;
		var id = '#' + barrager_id;
		var div_barrager = $("<div class='barrage' id='" + barrager_id + "'></div>").appendTo($(this));
		var window_height = $(window).height() - 100;
		div_barrager_boxs = $("<div class='barrage_box cl'></div>");
		div_barrager_boxs.css("background-color",barrage.background);
		div_barrager_box = div_barrager_boxs.appendTo(div_barrager);
		if(barrage.img){

			div_barrager_box.append("<a class='portrait z' href='javascript:;'></a>");
			var img = $("<img src='' >").appendTo(id + " .barrage_box .portrait");
			img.attr('src', barrage.img);
		}
		
		div_barrager_box.append(" <div class='z p'></div>");
		if(barrage.close){

			div_barrager_box.append(" <div class='close z'></div>");

		}
		
		var content = $("<a title='' href='' target='_blank'></a>").appendTo(id + " .barrage_box .p");
		content.attr({
			'href': barrage.href,
			'id': barrage.id
		}).empty().append(barrage.info);
		if(navigator.userAgent.indexOf("MSIE 6.0")>0  ||  navigator.userAgent.indexOf("MSIE 7.0")>0 ||  navigator.userAgent.indexOf("MSIE 8.0")>0  ){
			content.css('color', barrage.old_ie_color);
		}else{
			content.css('color', barrage.color);
		}
		
		/*var i = -150;
		div_barrager.css('right', i);
		var looper = setInterval(barrager, barrage.speed);
		function barrager() {
			if (i < 150) {
				i += 1;
				$(id).css('right', i);
			} else {
				$(id).remove();
 				return false;
			}

		}*/
		var i = -150;
		div_barrager.css('right', -150);
		div_barrager.css('margin-right', i);
		var looper = setInterval(barrager, barrage.speed);
		function barrager() {
			var window_width = $(window).width() + 150;
			if (i < window_width) {
				i += 1;
				$(id).css('margin-right', i);
			} else {
				$(id).remove();
 				return false;
			}
		}

		/*
		div_barrager_box.mouseover(function() {
			clearInterval(looper);
		});

		div_barrager_box.mouseout(function() {
			looper = setInterval(barrager, barrage.speed);
		});

		$(id+'.barrage .barrage_box .close').click(function(){

			$(id).remove();

		})
		*/
	}
 
	$.fn.barrager.removeAll=function(){

		 $('.barrage').remove();

	}

})(jQuery);