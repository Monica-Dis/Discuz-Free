<?php
/*
 * Copyright (c) 2021 by dism.taobao.com
 * ����֧��: https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if($_G['groupid']!=1){
	exit;
}

loadcache('plugin');
$config = $_G['cache']['plugin']['aljqb'];
if($_GET['act'] == 'delete'){
    if(is_array($_GET['delete'])) {
        foreach($_GET['delete'] as $id) {
			DB::query('delete from %t where orderid=%s',array('aljqb_rechargeorder',$id));
        }
    }
    cpmsg("aljqb:rechargelog_inc_php_1",'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljqb&pmod=rechargelog');
}else{
	$orderid = addslashes($_GET['orderid']);
	$username = addslashes($_GET['username']);
    $currpage = $_GET['page'] ? intval($_GET['page']) : 1;
    $perpage = 16;
    $start = ($currpage - 1) * $perpage;
	$where  = 'where 1 ';
	$conn = array('aljqb_rechargeorder');
	if($_GET['orderid']){
		$where .= ' and orderid=%s ';
		$conn[] = $_GET['orderid'];
	}

	if($_GET['username']){
		$where .= ' and username like %i ';
		$conn[] = "'%".$username."%'";
	}
	if($_GET['uid']){
		$where .= ' and uid=%d ';
		$conn[] = $_GET['uid'];
	}
	$num = DB::result_first('select count(*) from %t '.$where,$conn);
	$price = DB::result_first('SELECT sum(price) id FROM  %t '.$where,$conn);
	$where .=  'order by createtime desc limit %d,%d';
	$conn[] = $start;
	$conn[] = $perpage;
	$orderlist = DB::fetch_all('select * from %t '.$where,$conn);
    $paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljqb&pmod=rechargelog&orderid='.$_GET['orderid'].'&uid='.$_GET['uid'].'&username='.$username, 0, 11, false, false);
	include template('aljqb:rechargelog');
}
//From: Dism_taobao-com
?>
