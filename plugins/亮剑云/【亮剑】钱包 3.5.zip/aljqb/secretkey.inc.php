<?php
	$act = $_GET['act'];
	if($act == 'settings'){
		if(submitcheck('formhash')){
			if(submitcheck('delsubmit')){
				$deletearray = $_GET['delete'];
				if(!empty($deletearray)) {
					foreach($deletearray as $tmp_key => $tmp_value) {
						DB::delete('aljqb_secretkey',array('id'=>$tmp_value));
					}
				}
			}
			if(submitcheck('addsubmit')) {
				$newsettings=$_GET['newsettings'];
				if(!empty($newsettings)) {
					foreach($newsettings as $tmp_key => $tmp_value) {
						if(!empty($tmp_value[0])) {
							$tmp_val = DB::result_first('select count(*) from %t where pluginname=%s',array('aljqb_secretkey',$tmp_value[0]));
							if($tmp_val>0) {
								echo '<script>parent.alert("'.lang("plugin/aljqb","secretkey_inc_php_1").'")</script>';
								exit;
							}else {
								DB::insert('aljqb_secretkey',array('pluginname'=>$tmp_value[0],'secretkey'=>$tmp_value[1],'tokenurl'=>$tmp_value[2]));
							}
						}
					}
				}
				
			}
			if(submitcheck('editsubmit')) {
				$oldsettings=$_GET['oldsettings'];
				if(!empty($oldsettings)) {
					foreach($oldsettings as $tmp_key => $tmp_value) {
						DB::update('aljqb_secretkey',array('pluginname'=>$tmp_value[0],'secretkey'=>$tmp_value[1],'tokenurl'=>$tmp_value[2]),array('id'=>$tmp_key));
					}
				}
			}
			echo '<script>parent.alert("'.lang("plugin/aljqb","secretkey_inc_php_2").'");parent.location.reload();</script>';
			exit;
		}
	}else {
		loadcache('plugin');
		$siteurl = ltrim($_G['setting'][siteurl],'/') ? ltrim($_G['setting'][siteurl],'/') : ltrim($_G[siteurl],'/');
        $config['aljqbkey'] = 'aljqb|shenmikey123|'.$siteurl.'/source/plugin/aljqb/pay/pay.php
aljhb|shenmikey123|'.$siteurl.'/source/plugin/aljhb/pay/pay.php
aljds|shenmikey123|'.$siteurl.'/source/plugin/aljds/pay/pay.php
aljpay|shenmikey123|'.$siteurl.'/source/plugin/aljpay/pay/pay.php
aljbgp|shenmikey123|'.$siteurl.'/source/plugin/aljbgp/pay/pay.php
aljad|shenmikey123|'.$siteurl.'/source/plugin/aljad/pay/pay.php
aljbdx|shenmikey123|'.$siteurl.'/source/plugin/aljbdx/pay/pay.php
aljbdx_rz|shenmikey123|'.$siteurl.'/source/plugin/aljbdx/pay/pay_rz.php
aljqdx|shenmikey123|'.$siteurl.'/source/plugin/aljqdx/pay/pay.php
aljskm|shenmikey123|'.$siteurl.'/source/plugin/aljskm/pay/pay.php
aljsfx|shenmikey123|'.$siteurl.'/source/plugin/aljsfx/pay/pay.php';
		if($config['aljqbkey']) {
			$aljqbkeys = explode ("\n", str_replace ("\r", "", $config['aljqbkey']));
			foreach($aljqbkeys as $key=>$value){
				$arr=explode('|',$value);
				$aljqbkey[$arr[0]]=$arr;
			}
			$keynum = DB::result_first('select count(*) from %t',array('aljqb_secretkey'));
			if($keynum<=0) {
				foreach($aljqbkey as $tmp_key) {
					DB::insert('aljqb_secretkey',array('pluginname'=>$tmp_key[0],'secretkey'=>$tmp_key[1],'tokenurl'=>$tmp_key[2]));	
				}
			}
		}
		$currpage = $_GET['page'] ? intval($_GET['page']) : 1;
		$perpage = 40;
		$start = ($currpage - 1) * $perpage;
		$num = DB::result_first('select count(*) from %t',array('aljqb_secretkey'));
		$settingslist = DB::fetch_all('select * from %t limit %d,%d',array('aljqb_secretkey',$start,$perpage));
		$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljqb&pmod=secretkey', 0, 11, false, false);
		include template('aljqb:secretkey');
	}
?>