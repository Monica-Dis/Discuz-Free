<?php

/**
 *
 * @author yuxinqi<yuxinqi@vip.qq.com>
 * @version 1.0
 * @link http://docs.liangjianyun.com/
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class helpAction{
    public $page;

    public function __construct($page) {
        $this->page = $page;
        $this->aljbdParameter();
        
    }
    /**
     * ��������
     *
     *
     * @return void
     */
    public function btype () {
        
        $t_list=DB::fetch_all('select * from %t where upid=%d',array('aljhelp_type',$_GET['upid']));
        $text = lang("plugin/aljhelp","help_php_4");
        
        $name = 'subtypeid';
        
        if($t_list){
            $str .= '<select class="form-control" name="'.$name.'" id="'.$name.'" '.$func.' ><option value="0">'.$text.'</option>';
            foreach($t_list as $rid => $r){
                $str.='<option value="'.$r['id'].'">'.$r['name'].'</option>';
            }
            $str .= '</select>';
        }
        echo $str;
        exit;
    }
    /**
     * ��������
     *
     *
     * @return void
     */
    public function adminhelp () {
        global $_G;
        if((in_array($_G['groupid'],unserialize($_G['cache']['plugin']['aljbd']['managegroups'])) || in_array($_G['groupid'],unserialize($_G['cache']['plugin']['aljhtx']['gids']))) && !$mod){
            $administrators = 1;
        }
        $hid = intval($_GET['hid']);
        $do = $_GET['do'];
        $this->page->assign('do', $do);
        if($do == 'edithelp' || $do == 'addhelp'){
            $help = C::t('#aljhelp#aljhelp') -> fetch($hid);
           
            if(submitcheck('formhash')){
                if(empty($_GET['subject'])){
                    echo "<script>parent.tips('".lang("plugin/aljhelp","help_php_1")."','');</script>";
                    exit;
                }
                if(empty($_GET['intro'])){
                    echo "<script>parent.tips('".lang("plugin/aljhelp","help_php_2")."','');</script>";
                    exit;
                }
                $updatearray=array(
                    'status'=>$_GET['status'],
                    'is_common'=>$_GET['is_common'],
                    'subject'=>$_GET['subject'],
                    'content'=>$_GET['intro'],
                    'typeid'=>$_GET['typeid'],
                    'subtypeid'=>$_GET['subtypeid'],
                );
                //$bd=C::t('#aljbd#aljbd')->fetch($bid);
                $updatearray['uid'] = $_G['uid'];
                $updatearray['username'] = $_G['username'];
                if($help){
                    C::t('#aljhelp#aljhelp')->update($hid,$updatearray);
                }else{
                    $updatearray['dateline'] = TIMESTAMP;
                    $insertid=C::t('#aljhelp#aljhelp')->insert($updatearray,true);
                }

                echo "<script>parent.tips('".lang("plugin/aljhelp","help_php_3")."','".A_URL."');</script>";
                exit;

            }else{
                $helptype = DB::fetch_all('select * from %t where upid=0',array('aljhelp_type'));
                $this->page->assign('helptype', $helptype);
                $this->page->assign('help', $help);
                $this->page->assign('hid', $hid);
                $this->page->display('aljhelp:aljhelp/help/addhelp');
            }
        }else if($do == 'helptype'){
            if(submitcheck('formhash')){
                $newkey = $_GET['newkey'];
                $name = $_GET['name'];
                $newvalue = $_GET['newvalue'];
                
                if(is_array($name)) {
                    foreach($name as $id=>$value) {
                        C::t('#aljhelp#aljhelp_type')->update($id,array('name'=>$value,'displayorder'=>$_GET[displayorder][$id]));
                    }
                }
                if(is_array($newkey)) {
                    foreach($newkey as $key=>$name) {
                        if(empty($name)) {
                            continue;
                        }
                        C::t('#aljhelp#aljhelp_type')->insert(array('name' => $name),1);
                    }
                }
                
                if(is_array($newvalue)) {
                    foreach($newvalue as $cid=>$subcat) {
                        foreach($subcat as $key=>$value) {
                            
                            if(empty($value)) {
                                continue;
                            }
                            C::t('#aljhelp#aljhelp_type')->insert(array('upid' => $cid, 'name' => $value),1);
                        }
                    }
                }
                echo '<script>parent.location.href="'.A_URL.'&do='.$do.'";</script>';
                exit;
            }else{
                $helptype = DB::fetch_all('select * from %t where upid=0 order by displayorder asc,id desc',array('aljhelp_type'));
                $this->page->assign('helptype', $helptype);
                $this->page->display('aljhelp:aljhelp/help/helptype');
            }
        }elseif($do == 'del_helptype'){

            if($_GET['formhash'] == formhash()){
                C::t('#aljhelp#aljhelp_type')->delete($_GET['hid']);
            }
            echo '<script>parent.location.href="'.A_URL.'&do=helptype";</script>';
            exit;
        }else{
            $keyword = addcslashes($_GET['search'], '%_');
            if(submitcheck('formhash') && empty($keyword)){
                if(is_array($_GET['displayorder'])) {
                    foreach($_GET['displayorder'] as $k => $id) {
                        DB::query('update %t set displayorder=%d  where id = %d',array('aljhelp',$id,$k));
                    }
                }
                if($_GET['sign'] == 3){
                    if(is_array($_GET['delete'])) {
                        foreach($_GET['delete'] as $k => $id) {
                            DB::query('update %t set status=0  where id = %d',array('aljhelp',$id));
                        }
                    }
                }else if($_GET['sign'] == 4){
                    if(is_array($_GET['delete'])) {
                        foreach($_GET['delete'] as $k => $id) {
                            DB::query('update %t set status=1  where id = %d',array('aljhelp',$id));
                        }
                    }
                }else if($_GET['sign'] == 2){
                    if(is_array($_GET['delete'])) {
                        foreach($_GET['delete'] as $k => $id) {
                            C::t('#aljhelp#aljhelp')->update($id,array('rubbish'=>'1'));
                        }
                    }
                }else if($_GET['sign'] == 5){
                    if(is_array($_GET['delete'])) {
                        foreach($_GET['delete'] as $k => $id) {
                            DB::query('update %t set is_gg=1  where id = %d',array('aljhelp',$id));
                        }
                    }
                }else if($_GET['sign'] == 6){
                    if(is_array($_GET['delete'])) {
                        foreach($_GET['delete'] as $k => $id) {
                            DB::query('update %t set is_gg=0  where id = %d',array('aljhelp',$id));
                        }
                    }
                }

                echo '<script>parent.tips(0);</script>';
                exit;
            }

            $currpage=$_GET['page']?intval($_GET['page']):1;
            $perpage=20;
            $start=($currpage-1)*$perpage;
            $con[]='aljhelp';
            if($administrators){
                $where=" where rubbish=0";
            }else{
                $where=" where rubbish=0 and uid = %d";
                $con[] = $_G['uid'];
            }
            if($_GET['search']){
                $con[] ='%' . $keyword . '%';
                $where.=" and subject like %s";
            }
            $num = DB::result_first('select count(*) from %t'.$where,$con);
            $con[]=$start;
            $con[]=$perpage;
            $bdlist = DB::fetch_all('SELECT * FROM %t '.$where.' ORDER BY displayorder desc,id desc limit %d,%d',$con);
            $bdlist = dhtmlspecialchars($bdlist);
            $this->page->assign('start', $start);
            $this->page->assign('perpage', $perpage);
            $this->page->assign('currpage', $currpage);
            $this->page->assign('num', $num);
            
            $this->page->assign('bdlist', $bdlist);
            
            $this->page->display();
        }
    }
    /**
     * ��������
     *
     *
     * @return void
     */
    public function help () {
        global $_G;
        $do = $this->page->get->do;
        $where = 'where rubbish = 0';
        $con[] = 'aljhelp';
        if($this->page->get->typeid){
            $where .= ' and typeid=%d';
            $con[] = $this->page->get->typeid;
        }else if($_G['cache']['plugin']['aljhelp']['data_type'] == 1 && !$_GET['search']){
            $where .= ' and is_common=%d';
            $con[] = 1;
        }
        if($this->page->get->subtypeid){
            $where .= ' and subtypeid=%d';
            $con[] = $this->page->get->subtypeid;
        }
        $keyword = addcslashes($_GET['search'], '%_');
        if($_GET['search']){
            $con[] ='%' . $keyword . '%';
            $con[] ='%' . $keyword . '%';
            $where.=" and (subject like %s or content like %s)";
        }
        $num = DB::result_first('select count(*) from %t '.$where,$con);
        $currpage = $this->page->get->page ? $this->page->get->page : 1;
        if($do == 'ajax'){
            $perpage = 10;
        }else{
            $perpage = 20;
        }
        if(@ceil($num/$perpage) < $currpage && !$_G['mobile']){
            $currpage=1;
        }
        $start = ($currpage - 1) * $perpage;
        $where .= ' order by displayorder desc,id desc limit %d,%d';
        $con[] = $start;
        $con[] = $perpage;
        if($do == 'ajax'){
            
            $couponList = DB::fetch_all('select * from %t '.$where,$con);

            foreach($couponList as $ck => $cv){

                $couponList[$ck]['dateline'] = dgmdate($cv['dateline'],'u');
                $couponList[$ck]['desc'] = cutstr(strip_tags(preg_replace('/\<img.*?\>/is', '', $cv['content'])),200);

            }
            if($this->page->get->typeid){
                $helplist = DB::fetch_all('select * from %t where upid=%d order by displayorder asc,id desc',array('aljhelp_type',$this->page->get->typeid));
            }
            $array = array();
            if($couponList){
                $array['couponList'] = $couponList;
            }else{
                $array['couponList'] = 1;
            }
            if($helplist){
                $array['helplist'] = $helplist;
            }else{
                $array['helplist'] = 1;
            }
            echo json_encode(T::ajaxPostCharSet($array));
            exit;
        }else{
            $helplist = DB::fetch_all('select * from %t where upid=0 order by displayorder asc,id desc',array('aljhelp_type'));
            $paging = helper_page :: multi($num, $perpage, $currpage,A_URL.'&typeid='.$this->page->get->typeid.'&subtypeid='.$this->page->get->subtypeid.'&search='.$this->page->get->search, 0, 11, false, false);
            $this->page->assign('paging', $paging,true);
            $helpinfolist = DB::fetch_all('select * from %t '.$where,$con);
            $typename = DB::result_first('select name from %t where id=%d',array('aljhelp_type',$this->page->get->typeid));
            $subtypename = DB::result_first('select name from %t where id=%d',array('aljhelp_type',$this->page->get->subtypeid));
            $this->page->assign('helplist', $helplist);
            $this->page->assign('typename', $typename);
            $this->page->assign('subtypename', $subtypename);
            $this->page->assign('helpinfolist', $helpinfolist,true);

            $this->page->assign('navtitle', lang("plugin/aljhelp","help_php_5"));
            $mobile_banner = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljhelp']['mobile_banner']));
            
            foreach($mobile_banner as $key=>$value){
                $arr=explode('|',$value);
                $mobile_banner_types[]=$arr;
            }
            $this->page->assign('mobile_banner_types', $mobile_banner_types);
            $this->page->display();
            
        }
    }
    /**
     * ��������
     *
     *
     * @return void
     */
    public function view () {
        DB::query('update %t set view=view+1 where id=%d',array('aljhelp',$this->page->get->hid));
        $helpinfo = DB::fetch_first('select * from %t where id=%d',array('aljhelp',$this->page->get->hid));
        $helplist = DB::fetch_all('select * from %t where upid=0',array('aljhelp_type'));
        $where = 'where 1';
        $con[] = 'aljhelp';
        if($this->page->get->typeid){
            $where .= ' and typeid=%d';
            $con[] = $this->page->get->typeid;
        }
        $helpinfolist = DB::fetch_all('select * from %t '.$where,$con);
        $typename = DB::result_first('select name from %t where id=%d',array('aljhelp_type',$this->page->get->typeid));
        $this->page->assign('helplist', $helplist);
        $this->page->assign('typename', $typename);
        $this->page->assign('helpinfolist', $helpinfolist);
        $this->page->assign('helpinfo', $helpinfo,true);
        $prev = DB::fetch_first('select * from %t where rubbish = 0 and id<%d limit 1',array('aljhelp',$this->page->get->hid));
        $next = DB::fetch_first('select * from %t where rubbish = 0 and id>%d limit 1',array('aljhelp',$this->page->get->hid));
        $this->page->assign('prev', $prev);
        $this->page->assign('next', $next);
        $this->page->assign('navtitle', lang("plugin/aljhelp","help_php_6"));
        
        $this->page->display();
        
    }
    /**
     * Ʒ���̼ҹ�������ע��
     *
     *
     * @return void
     */
    public function aljbdParameter(){
        global $Html5Plusapp,
               $immersed,
               $pc_footer_new_top_arr,
               $pc_footer_new_top_tel,
               $pc_footer_new_top_kefu,
               $pc_footer_new_cron_c1_arr,
               $pc_footer_new_cron_c2_arr,
               $pc_footer_new_cron_c3_arr,
               $pc_footer_new_cron_c4_arr,
               $pc_footer_new_cron_c5_arr,
               $pc_footer_new_cron_qrcode_arr,
               $alltype,
               $index_dh_types,
               $ress;
        if($this->page->global->cache->plugin->aljbd){
            $settings=C::t('#aljbd#aljbd_setting')->range();
            $mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_common_footernav']['value']));
            foreach($mobile_common_footernav as $key=>$value){
                $arr=explode('|',$value);
                $mobile_common_footernav_arr[]=$arr;
            }
            $this->page->assign('pluginid', 'aljbd');
            $this->page->assign('Html5Plusapp', $Html5Plusapp);
            $this->page->assign('immersed', $immersed);
            $this->page->assign('settings', $settings,true);
            $this->page->assign('mobile_common_footernav_arr', $mobile_common_footernav_arr,true);
            $this->page->assign('common_template_pluginid', 'aljbd');
            $this->page->assign('common_path', 'source/plugin/aljhtx/');
    
            $this->page->assign('pc_footer_new_top_arr', $pc_footer_new_top_arr,true);
            $this->page->assign('pc_footer_new_top_tel', $pc_footer_new_top_tel,true);
            $this->page->assign('pc_footer_new_top_kefu', $pc_footer_new_top_kefu,true);
            $this->page->assign('pc_footer_new_cron_c1_arr', $pc_footer_new_cron_c1_arr,true);
            $this->page->assign('pc_footer_new_cron_c2_arr', $pc_footer_new_cron_c2_arr,true);
            $this->page->assign('pc_footer_new_cron_c3_arr', $pc_footer_new_cron_c3_arr,true);
            $this->page->assign('pc_footer_new_cron_c4_arr', $pc_footer_new_cron_c4_arr,true);
            $this->page->assign('pc_footer_new_cron_c5_arr', $pc_footer_new_cron_c5_arr,true);
            $this->page->assign('pc_footer_new_cron_qrcode_arr', $pc_footer_new_cron_qrcode_arr,true);
            $this->page->assign('alltype', $alltype,true);
            $this->page->assign('index_dh_types', $index_dh_types,true);
            $this->page->assign('ress', $ress,true);
        }else if($_GET['a'] != 'adminhelp'){
            define('IN_MOBILE', 2);
            $_G['mobile'] = 2;
        }
        if($this->page->global->cache->plugin->aljtc){
            $color = C::t('#aljtc#aljtc_setting')->fetch('allbackcolor');
            $this->page->assign('color', $color['value']);
        }
        $price_unit = '&#65509;';
        $this->page->assign('price_unit', $price_unit,true);
       
    }
}

