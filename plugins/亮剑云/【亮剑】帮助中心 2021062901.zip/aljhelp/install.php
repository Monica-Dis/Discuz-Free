<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljhelp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `displayorder` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `dateline` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `view` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `is_gg` tinyint(4) NOT NULL,
  `is_common` tinyint(4) NOT NULL,
  `rubbish` int(10) NOT NULL,
  `typeid` int(11) NOT NULL,
  `subtypeid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljhelp_type` (
  `id` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `upid` mediumint(9) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  PRIMARY KEY (`id`)
)
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>
