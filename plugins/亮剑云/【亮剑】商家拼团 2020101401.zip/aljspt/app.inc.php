<?php

/*
 * Copyright (c) 2021 by dism.taobao.com
 * Support: DisM!Ӧ������
 * (From) dism-Taobao-com
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


echo "<script language='javascript'>";
echo "parent.location.href='https://dism.taobao.com/?@liangjian'";
echo "</script>";
exit;