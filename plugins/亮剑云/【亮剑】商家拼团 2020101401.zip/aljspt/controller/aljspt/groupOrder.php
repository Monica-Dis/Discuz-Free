<?php

/**
 *
 * [DisM!] (C)2019-2021 DISM.Taobao.COM.
 * @version 1.0
 * ���²����http://t.cn/Aiux1Jx1
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class groupOrderAction{
    public $page;
    public $onetype;
    public function __construct($page) {
        global $aljtsq_post_goods;
        $this->page = $page;
        $this->aljbdParameter();
        $this->page->assign('aljtsq_post_goods', $aljtsq_post_goods,true);
        if($aljtsq_post_goods){
            $this->onetype = C::t('#aljtsc#aljtsc_type')->fetch_all_by_upid(0);
        }else{
            $this->onetype = C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid(0);
        }
        if(!$this->page->global->mobile){
            if($this->page->global->cache->plugin->aljspt->is_pc_list){
                $headerurl = 'plugin.php?id=aljbd&act=goods&commodity_type=2';
                dheader("location:".$headerurl);
                exit;
            }else{
                $navtitle = lang("plugin/aljspt","groupOrder_php_1");
                $title = lang("plugin/aljspt","groupOrder_php_2");
                $url = $this->page->global->siteurl.'plugin.php?id=aljspt';
                $this->page -> pcQrcode($navtitle,$title,$url);
            }
        }
        if($_GET[a] == 'groupOrder'){
            $payuser = DB::fetch_all('select * from %t where grouporderstatus = 1 and grouporderid != %s and groupopentime+%d > %i limit 0,10',array('aljspt_collage_order',$_GET['grouporderid'],31356000,TIMESTAMP));
        }else{
            $payuser = DB::fetch_all('select * from %t where grouporderstatus = 1 and groupopentime+%d > %i limit 0,10',array('aljspt_collage_order',31356000,TIMESTAMP));
        }
        if($payuser){
            foreach($payuser as $mkey => $mval){
                $myTodaySignRecord_2[$mkey]['avatar'] = avatar($mval['groupheaduid'],'middle',true);
                $myTodaySignRecord_2[$mkey]['username'] = aljhtx::substr_cut($mval['groupheadusername'],CHARSET);
                $myTodaySignRecord_2[$mkey]['grouporderid'] = $mval['grouporderid'];
            }
            $payuser_json = json_encode(aljhtx::ajaxPostCharSet($myTodaySignRecord_2));
            $this->page->assign('payuser', $payuser);
            $this->page->assign('payuser_json', $payuser_json,true);
        }
        
    }
    /**
     * ƴ����ҳ
     *
     * @return void
     */
    public function index (){
        global $_G,$aljtsq_post_goods;
        //�ֻ���ҳת��
        $mobile_index_banner = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljspt']['mobile_index_banner']));
        foreach($mobile_index_banner as $key=>$value){
            $arr=explode('|',$value);
            $mobile_index_banner_types[]=$arr;
        }
        
        //�ֻ���ҳͼ�굼��
        $mobile_index_nav = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljspt']['mobile_index_nav']));
        foreach($mobile_index_nav as $key=>$value){
            $arr=explode('|',$value);
            $mobile_index_nav_types[]=$arr;
        }
        $onetype = $this->onetype;
        $this->page->assign('onetype', $onetype);
        $this->page->assign('mobile_index_banner_types', $mobile_index_banner_types);
        $this->page->assign('mobile_index_nav_types', $mobile_index_nav_types);
        $this->page->assign('navtitle', lang("plugin/aljspt","groupOrder_php_3"));
        $this->page->assign('metadescription', $_G['cache']['plugin']['aljspt']['description']);
        $this->page->display();
    }
    /**
     * ����ƴ��
     *
     * @return void
     */
    public function newPeople (){
        global $_G,$aljtsq_post_goods;
        //������ת��
        $mobile_newpeople_banner = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljspt']['mobile_newpeople_banner']));
        foreach($mobile_newpeople_banner as $key=>$value){
            $arr=explode('|',$value);
            $mobile_newpeople_banner_types[]=$arr;
        }
        $onetype = $this->onetype;
        $this->page->assign('onetype', $onetype);
        $this->page->assign('mobile_newpeople_banner_types', $mobile_newpeople_banner_types);
        $this->page->assign('navtitle', lang("plugin/aljspt","groupOrder_php_4"));
        $this->page->assign('metadescription', $_G['cache']['plugin']['aljspt']['description']);
        $this->page->display();
    }
    /**
     * 9.9����
     *
     * @return void
     */
    public function nineFreeShipping (){
        global $_G,$aljtsq_post_goods;
        //9.9����ת��
        $mobile_nine_banner = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljspt']['mobile_nine_banner']));
        foreach($mobile_nine_banner as $key=>$value){
            $arr=explode('|',$value);
            $mobile_nine_banner_types[]=$arr;
        }
        $onetype = $this->onetype;
        $this->page->assign('onetype', $onetype);
        $this->page->assign('mobile_nine_banner_types', $mobile_nine_banner_types);
        $this->page->assign('navtitle', '9.9'.lang("plugin/aljspt","groupOrder_php_5"));
        $this->page->assign('metadescription', $_G['cache']['plugin']['aljspt']['description']);
        $this->page->display();
    }
    /**
     * ����ƴ��
     *
     * @return void
     */
    public function hot (){
        global $_G,$aljtsq_post_goods;
        //����ת��
        $mobile_hot_banner = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljspt']['mobile_hot_banner']));
        foreach($mobile_hot_banner as $key=>$value){
            $arr=explode('|',$value);
            $mobile_hot_banner_types[]=$arr;
        }
        $onetype = $this->onetype;
        $this->page->assign('onetype', $onetype);
        $this->page->assign('mobile_nine_banner_types', $mobile_nine_banner_types);
        $this->page->assign('navtitle', lang("plugin/aljspt","groupOrder_php_6"));
        $this->page->assign('metadescription', $_G['cache']['plugin']['aljspt']['description']);
        $this->page->display();
    }
    /**
     * �ҵ�ƴ��
     *
     * @return void
     */
    public function  ptOrder () {
        $this->page->assign('navtitle', lang("plugin/aljspt","groupOrder_php_7"));
        $this->page->assign('metadescription', $_G['cache']['plugin']['aljspt']['description']);
        $this->page->display('aljspt:order/orderlist_new');
    }
    /**
     * ƴ������
     *
     * @return void
     */
    public function groupOrder () {
        global $_G;
        $groupid=$this->page->get->grouporderid;
        
        $pt_grouporder=DB::fetch_first('select * from %t where grouporderid=%s',array('aljspt_collage_order', $groupid));
        $pt_order=DB::fetch_first('select * from %t where orderid=%s',array('aljbd_goods_order',$pt_grouporder['orderid']));
        if(!$groupid || !$pt_grouporder || !$pt_order){
            $desc = lang("plugin/aljspt","groupOrder_php_8");
            $info = array('desc' => $desc);
            $info['btn_primary'] = array('value' => lang("plugin/aljspt","groupOrder_php_9"), 'url' => 'plugin.php?id=aljspt');
            $info['btn_default'] = array('value' => lang("plugin/aljspt","groupOrder_php_10"), 'url' => 'plugin.php?id=aljbd&act=user');
            $this->page->weuiResult($info,lang("plugin/aljspt","groupOrder_php_11"));
        }

        $pt_ordergroup_tmp=DB::fetch_all('select * from %t where collage_order=%s and status=%d order by confirmdate asc',array('aljbd_goods_order',$pt_grouporder['grouporderid'],2));
        foreach($pt_ordergroup_tmp as $tmp_key => $tmp_value){
            $pt_ordergroup[$tmp_key]['username']=$tmp_value['username'];
            $pt_ordergroup[$tmp_key]['placeordertime']=$tmp_value['placeordertime'];
            $pt_ordergroup[$tmp_key]['uid']=$tmp_value['uid'];
        }

        $pt_ordergroupnum=DB::result_first('select count(*) from %t where collage_order=%s and status=%d',array('aljbd_goods_order',$pt_grouporder['grouporderid'],2));
        $pt_goods=DB::fetch_first('select * from %t where id=%d',array('aljbd_goods',$pt_grouporder['goodsid']));
        if($_G['cache']['plugin']['aljoss']['cdn_domain']){
            if(strpos($pt_goods['pic1'],$_G['cache']['plugin']['aljoss']['domain']) !== false){
                $pt_goods['pic1'] = str_replace($_G['cache']['plugin']['aljoss']['domain'],$_G['cache']['plugin']['aljoss']['cdn_domain'],$pt_goods['pic1']);
            }
        }
        if(file_exists("source/plugin/dz_4/dz_4.inc.php")){
            $pics = array('pic1','pic2','pic3','pic4','pic5','pic6','pic7','pic8','pic9','pic10','pic11','pic12');
        }else{
            $pics = array('pic1','pic2', 'pic3', 'pic4', 'pic5');
        }

        $html = '';
        foreach($pics as $p => $pic){
            if(file_exists($pt_goods[$pic]) || strpos($pt_goods[$pic],$_G['cache']['plugin']['aljoss']['cdn_domain']) !== false  || strpos($pt_goods[$pic],$_G['cache']['plugin']['aljoss']['domain']) !== false){
                $html.="<div class=\" swiper-slide\" ><a href=\"plugin.php?id=aljbd&act=goodview&bid=".$pt_goods['bid']."&gid=".$pt_goods['id']."\"><img src=".$pt_goods[$pic]." /></a></div>";
            }
        }
        $path = DB::result_first('select path from %t where orderid=%s',array('aljbd_goods_order_list',$pt_grouporder['orderid']));
        $sku_price_s = skuminprice($pt_goods['attr_sku'],$pt_goods['commodity_type'],1);

        if(is_array($sku_price_s)){
            $max_price = $sku_price_s['max_price']>$sku_price_s['min_price']?'<i style="font-size: 20px">~</i>'.$sku_price_s['max_price']:'';
            $pt_goods['collage_price'] = $sku_price_s['min_price'].$max_price;
        }
        //ms
        if($_G['cache']['plugin']['aljms']['is_aljms']){
            $ms_date = dgmdate(TIMESTAMP, "Ymd");
            $ms_info = DB::fetch_first('select * from %t where ms_status = 0 and ms_gid=%d and ms_date=%d and ms_start_time<=%d and ms_end_time>%d ',array('aljhtx_activity_ms_enter',$pt_grouporder['goodsid'],$ms_date,TIMESTAMP,TIMESTAMP));
            if($ms_info['ms_price'] >0){
                $pt_goods['collage_price'] = $ms_info['ms_price'];
            }
        }
        $this->page->assign('groupid', $groupid);
        $this->page->assign('html', $html,true);
        $this->page->assign('pt_grouporder', $pt_grouporder);
        $this->page->assign('pt_ordergroup', $pt_ordergroup);
        $this->page->assign('pt_ordergroupnum', $pt_ordergroupnum);

        $this->page->assign('path', $path);
        $this->page->assign('pt_goods', $pt_goods,true);
        $this->page->assign('overtime', $this->pt_overtime($pt_grouporder['groupopentime']));

        $this->page->assign('navtitle', lang("plugin/aljspt","groupOrder_php_12"));
        $this->page->assign('metadescription', lang("plugin/aljspt","groupOrder_php_13").'['.$pt_order['stitle'].']'.lang("plugin/aljspt","groupOrder_php_14"));
        $this->page->display();
    }
    /**
     * ƴ�Ź���
     *
     * @return void
     */
    public function rule () {
        global $_G;

        $this->page->assign('navtitle', lang("plugin/aljspt","groupOrder_php_15"));
        $this->page->assign('metadescription', $_G['cache']['plugin']['aljspt']['description']);
        $this->page->display();
    }
    /**
     * ƴ�Ź���
     *
     * @return void
     */
    public function ptRule () {
        global $_G;

        $this->page->assign('navtitle', lang("plugin/aljspt","groupOrder_php_16"));
        $this->page->assign('metadescription', $_G['cache']['plugin']['aljspt']['description']);
        $this->page->display();
    }
    /**
     * �����Ƽ�ƴ����Ʒ
     *
     * @return void
     */
    public function ptList (){
        global $aljtsq_post_goods;
        if($aljtsq_post_goods){
            $sql = ' AND store_id>0';
        }else{
            $sql = ' AND store_id=0';
        }
        
        $currpage=$this->page->get->page?$this->page->get->page:1;
        $perpage=5;
        $start=($currpage-1)*$perpage;
        $array = array('sh_status'=>0);
        if($_GET['t'] == 'newPeople'){
            $array = array('new_people'=>1);
        }
        if($_GET['t'] == 'nineFreeShipping'){
            $array = array('pt_nine'=>1);
        }
        if($_GET['t'] == 'hot'){
            $_GET['order'] = 'hot';
        }
        $bdlist=C::t('#aljbd#aljbd_goods')->fetch_all_by_status_new('',$start,$perpage,'',$_GET['type'],$_GET['subtype'],$_GET['region'],$_GET['subregion'],$_GET['order'],$_GET['kw'],$_GET['subtype3'],0,2,$array,$sql);

        foreach($bdlist as $k=>$v){
            $bdlist[$k]['price1']=skuminprice($v['attr_sku'],$v['commodity_type'],2)>0 ? skuminprice($v['attr_sku'],$v['commodity_type'],2) : floatval($v['price1']);
            if($_GET['t'] == 'newPeople'){
                $bdlist[$k]['collage_price']=skuminprice($v['attr_sku'],$v['commodity_type'],3)>0 ? skuminprice($v['attr_sku'],$v['commodity_type'],3) : floatval($v['new_price']);
            }else{
                $bdlist[$k]['collage_price']=skuminprice($v['attr_sku'],$v['commodity_type'])>0 ? skuminprice($v['attr_sku'],$v['commodity_type']) : floatval($v['collage_price']);
            }
            
            if($v['selling_point']){
                $selling_point = str_replace(lang("plugin/aljspt","groupOrder_php_17"),',',$v['selling_point']);
                $bdlist[$k]['selling_point'] = explode(',',$selling_point);
            }
            if(TIMESTAMP < $v['endtime'] || TIMESTAMP < $v['starttime']){
                if(TIMESTAMP < $v['starttime']){
                    $bdlist[$k]['tg_time_title'] = lang('plugin/aljspt','aljspt_php_5').'<span class="endtime" value="'.$v['endtime'].'" date-val="0"></span>';
                    $v['tg_time_title'] = lang('plugin/aljspt','aljspt_php_5').'<span class="endtime" value="'.$v['endtime'].'" date-val="0"></span>';
                    $bdlist[$k]['tg_time_status'] = 1;
                    $v['tg_time_status'] = 1;
                } else {
                    $bdlist[$k]['tg_time_title'] = lang('plugin/aljspt','aljspt_php_6').':&nbsp;<span class="endtime" value="'.$v['endtime'].'" date-val="1"></span>';
                    $v['tg_time_title'] = lang('plugin/aljspt','aljspt_php_6').':&nbsp;<span class="endtime" value="'.$v['endtime'].'" date-val="1"></span>';
                }
            }else{
                if($v['endtime']<=0){
                    $bdlist[$k]['tg_time_title'] = lang('plugin/aljspt','aljspt_php_7').'<span class="endtime" value="'.$v['endtime'].'" date-val="0"></span>';
                    $v['tg_time_title'] = lang('plugin/aljspt','aljspt_php_7').'<span class="endtime" value="'.$v['endtime'].'" date-val="0"></span>';
                } else {
                    $bdlist[$k]['tg_time_status'] = 2;
                    $bdlist[$k]['tg_time_title'] = lang('plugin/aljspt','aljspt_php_8').'<span class="endtime" value="'.$v['endtime'].'" date-val="0"></span>';
                    $v['tg_time_title'] = lang('plugin/aljspt','aljspt_php_8').'<span class="endtime" value="'.$v['endtime'].'" date-val="0"></span>';
                    $v['tg_time_status'] = 2;
                }
            }
            if($v['amount']<=0){
                $bdlist[$k]['tg_time_status'] = 3; 
                $v['tg_time_status'] = 3;
            }
            if($_GET['t'] == 'nineFreeShipping'){
                if($bdlist[$k]['collage_price'] <= 9.9){
                    $v['price1'] = $bdlist[$k]['price1'];
                    $v['collage_price'] = $bdlist[$k]['collage_price'];
                    $v['selling_point'] = $bdlist[$k]['selling_point'];
                    $pt_list[] = $v;
                }
            }
        }
        if($_GET['t'] == 'nineFreeShipping'){
            $bdlist = $pt_list;
        }
        if($this->page->get->m == 'index'){
            $array = array();
            if($bdlist){
                $array['bdlist'] = $bdlist;
            }else{
                $array['bdlist'] = 1;
            }
            if($_GET['type'] > 0){
                if($aljtsq_post_goods){
                    $type = C::t('#aljtsc#aljtsc_type')->fetch_all_by_upid($_GET['type']);
                }else{
                    $type = C::t('#aljbd#aljbd_type_goods')->fetch_all_by_upid_orderkey($_GET['type']);
                }
            }
            if($type){
                $array['type'] = $type;
            }else{
                $array['type'] = 1;
            }
            echo json_encode(T::ajaxPostCharSet($array));
        }else{
            if($bdlist){
                echo json_encode(T::ajaxPostCharSet($bdlist));
            }else{
                echo '1';
            }
        }
        exit;
    }
    /**
     * ����ʱ����
     * @param $var int ����ʱ��
     * @return int
     */
    public function pt_overtime($var){
        global $_G;
        $grouptime=$_G['cache']['plugin']['aljspt']['grouptime']?intval($_G['cache']['plugin']['aljspt']['grouptime'])*3600 : 86400;
        $time =$var+$grouptime;
        $nowtime = TIMESTAMP;
        if ($time>=$nowtime){
            $overtime = $time-$nowtime;
        }else{
            $overtime=0;
        }
        return $overtime;
    }
    /**
     * ����ת����
     * @param $max int ת�������
     * @return array
     */
    public function getNumberArray($max){
        for($i=0;$i<$max;$i++){
            $returnarray[]=$i;
        }
        return $returnarray;
    }
    /**
     * Ʒ���̼ҹ�������ע��
     *
     *
     * @return void
     */
    public function aljbdParameter(){
        global $Html5Plusapp,$immersed,$newscount;
        $settings=C::t('#aljbd#aljbd_setting')->range();
        $mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_common_footernav']['value']));
        foreach($mobile_common_footernav as $key=>$value){
            $arr=explode('|',$value);
            $mobile_common_footernav_arr[]=$arr;
        }
        $price_unit = '&#65509;';
        $this->page->assign('price_unit', $price_unit,true);
        $this->page->assign('pluginid', 'aljbd');
        $this->page->assign('newscount', $newscount);
        $this->page->assign('Html5Plusapp', $Html5Plusapp);
        $this->page->assign('immersed', $immersed);
        $this->page->assign('settings', $settings);
        $this->page->assign('mobile_common_footernav_arr', $mobile_common_footernav_arr,true);
        $this->page->assign('common_template_pluginid', 'aljbd');
        $this->page->assign('common_path', 'source/plugin/aljhtx');
    }
}

