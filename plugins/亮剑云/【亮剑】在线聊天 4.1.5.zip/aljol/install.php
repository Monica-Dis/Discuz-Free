<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljol_news` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `friendid` int(10) NOT NULL,
  `datetime` varchar(255) NOT NULL,
  `lastnews` text NOT NULL,
  `type` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljol_picture` (
  `pid` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `friendid` int(10) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `datetime` varchar(255) NOT NULL,
  PRIMARY KEY (`pid`),
  KEY `datetime` (`datetime`)
);
CREATE TABLE IF NOT EXISTS `pre_aljol_talk` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `friendid` int(10) NOT NULL,
  `talk` text NOT NULL,
  `datetime` varchar(255) NOT NULL,
  `talkstate` int(10) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `time` int(10) NOT NULL,
  `gid` int(11) NOT NULL,
  `is_read` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `friendid` (`friendid`),
  KEY `picture` (`picture`)
);
CREATE TABLE IF NOT EXISTS `pre_aljol_talk_0` (
  `id` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `friendid` int(10) NOT NULL,
  `talk` text NOT NULL,
  `datetime` varchar(255) NOT NULL,
  `talkstate` int(10) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `time` int(10) NOT NULL,
  `gid` int(11) NOT NULL,
  `is_read` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `friendid` (`friendid`),
  KEY `picture` (`picture`)
);
CREATE TABLE IF NOT EXISTS `pre_aljol_talk_1` (
  `id` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `friendid` int(10) NOT NULL,
  `talk` text NOT NULL,
  `datetime` varchar(255) NOT NULL,
  `talkstate` int(10) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `time` int(10) NOT NULL,
  `gid` int(11) NOT NULL,
  `is_read` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `friendid` (`friendid`),
  KEY `picture` (`picture`)
);
CREATE TABLE IF NOT EXISTS `pre_aljol_talk_2` (
  `id` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `friendid` int(10) NOT NULL,
  `talk` text NOT NULL,
  `datetime` varchar(255) NOT NULL,
  `talkstate` int(10) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `time` int(10) NOT NULL,
  `gid` int(11) NOT NULL,
  `is_read` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `friendid` (`friendid`),
  KEY `picture` (`picture`)
);
CREATE TABLE IF NOT EXISTS `pre_aljol_talk_3` (
  `id` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `friendid` int(10) NOT NULL,
  `talk` text NOT NULL,
  `datetime` varchar(255) NOT NULL,
  `talkstate` int(10) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `time` int(10) NOT NULL,
  `gid` int(11) NOT NULL,
  `is_read` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `friendid` (`friendid`),
  KEY `picture` (`picture`)
);
CREATE TABLE IF NOT EXISTS `pre_aljol_talk_4` (
  `id` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `friendid` int(10) NOT NULL,
  `talk` text NOT NULL,
  `datetime` varchar(255) NOT NULL,
  `talkstate` int(10) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `time` int(10) NOT NULL,
  `gid` int(11) NOT NULL,
  `is_read` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `friendid` (`friendid`),
  KEY `picture` (`picture`)
);
CREATE TABLE IF NOT EXISTS `pre_aljol_talk_5` (
  `id` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `friendid` int(10) NOT NULL,
  `talk` text NOT NULL,
  `datetime` varchar(255) NOT NULL,
  `talkstate` int(10) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `time` int(10) NOT NULL,
  `gid` int(11) NOT NULL,
  `is_read` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `friendid` (`friendid`),
  KEY `picture` (`picture`)
);
CREATE TABLE IF NOT EXISTS `pre_aljol_talk_6` (
  `id` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `friendid` int(10) NOT NULL,
  `talk` text NOT NULL,
  `datetime` varchar(255) NOT NULL,
  `talkstate` int(10) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `time` int(10) NOT NULL,
  `gid` int(11) NOT NULL,
  `is_read` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `friendid` (`friendid`),
  KEY `picture` (`picture`)
);
CREATE TABLE IF NOT EXISTS `pre_aljol_talk_7` (
  `id` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `friendid` int(10) NOT NULL,
  `talk` text NOT NULL,
  `datetime` varchar(255) NOT NULL,
  `talkstate` int(10) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `time` int(10) NOT NULL,
  `gid` int(11) NOT NULL,
  `is_read` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `friendid` (`friendid`),
  KEY `picture` (`picture`)
);
CREATE TABLE IF NOT EXISTS `pre_aljol_talk_8` (
  `id` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `friendid` int(10) NOT NULL,
  `talk` text NOT NULL,
  `datetime` varchar(255) NOT NULL,
  `talkstate` int(10) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `time` int(10) NOT NULL,
  `gid` int(11) NOT NULL,
  `is_read` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `friendid` (`friendid`),
  KEY `picture` (`picture`)
);
CREATE TABLE IF NOT EXISTS `pre_aljol_talk_9` (
  `id` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `friendid` int(10) NOT NULL,
  `talk` text NOT NULL,
  `datetime` varchar(255) NOT NULL,
  `talkstate` int(10) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `time` int(10) NOT NULL,
  `gid` int(11) NOT NULL,
  `is_read` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `friendid` (`friendid`),
  KEY `picture` (`picture`)
);
EOF;
runquery($sql);
//finish to put your own code
if(file_exists("source/plugin/aljatt/aljatt.inc.php")) {
  $sql ="ALTER TABLE  ".DB::table('aljhtx_cron_script')." CHANGE `name` `name` VARCHAR(255) NOT NULL" ;
  DB::query($sql,'SILENT');
  if(!DB::fetch_first('select * from %t where file=%s',array('aljhtx_cron_script','source/plugin/aljol/api/deletePictureAuto.php'))){
    DB::insert('aljhtx_cron_script',array('name'=>'&#33258;&#21160;&#21024;&#38500;&#51;&#48;&#22825;&#20043;&#21069;&#30340;&#22270;&#29255;','file'=>'source/plugin/aljol/api/deletePictureAuto.php','cycle'=>'3600','open'=>'on'));
  }
  if(!DB::fetch_first('select * from %t where file=%s',array('aljhtx_cron_script','source/plugin/aljol/api/regularCleaning.php'))){
    DB::insert('aljhtx_cron_script',array('name'=>'&#33258;&#21160;&#28165;&#29702;&#32842;&#22825;&#20869;&#23481;','file'=>'source/plugin/aljol/api/regularCleaning.php','cycle'=>'86400','open'=>'on'));
  }
}
$finish = TRUE;
?>