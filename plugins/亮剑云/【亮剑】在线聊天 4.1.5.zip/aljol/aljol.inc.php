<?php

/*
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����˵��:��������
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_G['mobile'] && $_G['cache']['plugin']['aljhtx']['force_mobile']){
    include_once "source/plugin/aljhtx/api/common.php";
}
$dataline = TIMESTAMP;
require_once 'source/plugin/aljhtx/class/class_aljhtx.php';
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
    $iswechat = true;
}
if(strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false){
    preg_match('/Immersed\/(\d+)/i', $_SERVER["HTTP_USER_AGENT"], $matches);
    $immersed = $matches[1];
}
if(($_G['cache']['plugin']['aljwx'] || $_G['cache']['plugin']['mapp_share']) && strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
    define('IN_MINI', '1');
}
$version = '20200203';
//debug($_G['uid']);
if(!$_G['mobile']) {
    //include template('aljol:aljol');
    //exit;
}
$price_unit = '&#65509;';
if(!$_G['uid']) {
    $_G['connect']['referer'] = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'].($_SERVER['QUERY_STRING'] ? '?'.$_SERVER['QUERY_STRING'] : '') : dreferer();
    $_G['connect']['referer'] = urlencode($_G['connect']['referer'] ? $_G['connect']['referer'] : 'index.php');
    header('Location:member.php?mod=logging&action=login&referer='.$_G['connect']['referer']);
    exit;
}
if($_G['groupid'] == '5'){
    showmessage("aljol:aljol_inc_php_1");
}
$act = addslashes($_GET['act']);
$chat = addslashes($_GET['chat']);

if(!$_G['mobile'] || !$_G['setting']['mobile']['allowmobile']){
    $chat = ajaxGetCharSet($chat);
    $_GET['searchkey'] = ajaxGetCharSet($_GET['searchkey']);
}
$friendid = intval($_GET['friendid']);
$tableid = '_'.($friendid<=0 ? 0 : $friendid%10);
$token = base64_encode(authcode($_G['uid']."\t".$friendid."\t".TIMESTAMP, 'ENCODE', $_G['config']['security']['authkey']));
if($friendid == 0){
    $hb_friendid = 1;
}else{
    $hb_friendid = $friendid;
}
$beginToday = mktime(0,0,0,date('m'),date('d'),date('Y'));
$endToday = mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
$requesttable = 'home_friend_request';
$friendtable = 'home_friend';
$fanstable = 'home_follow';
$signtable = 'common_member_field_forum';
$usertable = 'common_member';
$a = lang("plugin/aljol","aljol_inc_php_2");
list($off_logo,$off_name,$off_desc,$off_uid)=explode('|',$_G['cache']['plugin']['aljol']['official_uid']);
$t_act = array('chat','sendgoods','sendvoice','upload');
if($_G['cache']['plugin']['aljbd'] && $_G['uid'] && in_array($act,$t_act)){
    $bd = DB::fetch_first('SELECT * FROM %t WHERE kf_uid=%d LIMIT 1',array('aljbd',$_G['uid']));
}
$no_play = lang("plugin/aljol","aljol_inc_php_3");
//�����Զ�ɾ��30����ǰ��ͼƬ����
//DeletePicture_Auto();

//ajax��ʼ
if($act == 'chat') {//������Ϣ
    
    if($_G['groupid'] == '4'){//��ֹ����
        $tmp_array=array(
            'code'=>4,
        );
        echo json_encode(ajaxPostCharSet($tmp_array));
        exit;
    }
    if($_G['groupid'] == '5'){//��ֹ����
        $tmp_array=array(
            'code'=>5,
        );
        echo json_encode(ajaxPostCharSet($tmp_array));
        exit;
    }
    
    //$checkWord = DB::fetch_all('select * from %t', array('common_word'));
    //foreach($checkWord as $k => $v){
        //$chat = str_replace($v['find'], '***', $chat);
        //$chat = preg_replace('/'.$v['find'].'/i', '***', $chat);
    //}
    $censor = & discuz_censor::instance();
    $censor->highlight = '#FF0000';
    $censor->check($chat);
    if($censor->modbanned() || $censor->modmoderated()) {
        $tmp_array=array(
            'code'=>6,
        );
        echo json_encode(ajaxPostCharSet($tmp_array));
        exit;
    }
    
    $talkid=DB::insert('aljol_talk',array(
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'friendid'=>$friendid,
        'talk'=>$chat,
        'datetime'=>$dataline,
        'talkstate'=>1,
    ),true);
    
    DB::insert('aljol_talk'.$tableid,array(
        'id' => $talkid,
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'friendid'=>$friendid,
        'talk'=>$chat,
        'datetime'=>$dataline,
        'talkstate'=>1,
    ),true);
    
    if($talkid){
        $frienduser = getuserbyuid($friendid);
        notification_add($friendid, 'system',lang("plugin/aljol","aljol_inc_php_4").$_G['username'].lang("plugin/aljol","aljol_inc_php_5").'<a href="plugin.php?id=aljol&act=talk&friendid='.$_G['uid'].'">'.lang("plugin/aljol","aljol_inc_php_6").'</a>',array('from_idtype'=>'aljol', 'from_id' => $_G['uid']));
        news($friendid,$chat);
        $tmp_array=array(
            'uid'=>$_G['uid'],
            'friendid'=>$friendid,
            'code'=>200,
            'chat'=>ubbReplace($chat),
            'username'=>$_G['username'],
            'head'=> avatar($_G['uid']),
            'datetime' => dgmdate($dataline, 'm-d H:i:s')
        );
        
        if($off_uid && $off_uid == $_G['uid']){
            $tmp_array['username'] = $off_name;
            $tmp_array['head'] = $off_logo ? '<img src="'.$off_logo.'" />' : '';
        }
        if($bd['name'] && $bd['kf_uid'] == $_G['uid']){
            $tmp_array['username'] = $bd['name'];
            $tmp_array['head'] = $bd['logo'] ? '<img src="'.$bd['logo'].'" />' : '';
        }
    }else{
        $tmp_array=array(
            'code'=>400,
        );
    }
    echo json_encode(ajaxPostCharSet($tmp_array));
}else if($act == 'sendgoods') {//������Ʒ��Ϣ
    if($_G['groupid'] == '4'){//��ֹ����
        $tmp_array=array(
            'code'=>4,
        );
        echo json_encode(ajaxPostCharSet($tmp_array));
        exit;
    }
    if($_G['groupid'] == '5'){//��ֹ����
        $tmp_array=array(
            'code'=>5,
        );
        echo json_encode(ajaxPostCharSet($tmp_array));
        exit;
    }
    if($_GET['gid']){
        $gid = intval($_GET['gid']);
        $g=C::t('#aljbd#aljbd_goods')->fetch($gid);
        if(!$g){
            $tmp_array=array(
                'code'=>6,
            );
            echo json_encode(ajaxPostCharSet($tmp_array));
            exit;
        }
    }
    $checkWord = DB::fetch_all('select * from %t', array('common_word'));
    foreach($checkWord as $k => $v){
        $chat = str_replace($v['find'], '***', $chat);
    }
    
    $talkid=DB::insert('aljol_talk',array(
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'friendid'=>$friendid,
        'talk'=>$chat,
        'datetime'=>$dataline,
        'talkstate'=>1,
        'type'=>4,
        'gid'=>$_GET['gid'],
    ),true);
    
    DB::insert('aljol_talk'.$tableid,array(
        'id' => $talkid,
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'friendid'=>$friendid,
        'talk'=>$chat,
        'datetime'=>$dataline,
        'talkstate'=>1,
        'type'=>4,
        'gid'=>$_GET['gid'],
    ),true);
    if($talkid){
        $frienduser = getuserbyuid($friendid);
        notification_add($friendid, 'system',lang("plugin/aljol","aljol_inc_php_7").$_G['username'].lang("plugin/aljol","aljol_inc_php_8").'<a href="plugin.php?id=aljol&act=talk&friendid='.$_G['uid'].'">'.lang("plugin/aljol","aljol_inc_php_9").'</a>',array('from_idtype'=>'aljol', 'from_id' => $_G['uid']));
        news($friendid,lang("plugin/aljol","aljol_inc_php_10"));
        $chathtml = chathtml($g);
        $tmp_array=array(
            'code'=>200,
            'talk'=>$chathtml,
            'uid'=>$_G['uid'],
            'friendid'=>$friendid,
            'username'=>$_G['username'],
            'head'=> avatar($_G['uid']),
            'datetime' => dgmdate($dataline, 'm-d H:i:s')
        );
        if($off_uid && $off_uid == $_G['uid']){
            $tmp_array['username'] = $off_name;
            $tmp_array['head'] = $off_logo ? '<img src="'.$off_logo.'" />' : '';
        }
        if($bd['name'] && $bd['kf_uid'] == $_G['uid']){
            $tmp_array['username'] = $bd['name'];
            $tmp_array['head'] = $bd['logo'] ? '<img src="'.$bd['logo'].'" />' : '';
        }
    }else{
        $tmp_array=array(
            'code'=>400,
        );
    }
    echo json_encode(ajaxPostCharSet($tmp_array));
}else if($act == 'sendvoice') {//������Ϣ
    if($_G['groupid'] == '4'){//��ֹ����
        $tmp_array=array(
            'code'=>4,
        );
        echo json_encode(ajaxPostCharSet($tmp_array));
        exit;
    }
    if($_G['groupid'] == '5'){//��ֹ����
        $tmp_array=array(
            'code'=>5,
        );
        echo json_encode(ajaxPostCharSet($tmp_array));
        exit;
    }
    $checkWord = DB::fetch_all('select * from %t', array('common_word'));
    foreach($checkWord as $k => $v){
        $chat = str_replace($v['find'], '***', $chat);
    }
    
    $talkid=DB::insert('aljol_talk',array(
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'friendid'=>$friendid,
        'talk'=>$chat,
        'datetime'=>$dataline,
        'talkstate'=>1,
        'type'=>3,
        'time'=>$_GET['time'],
    ),true);
    
    DB::insert('aljol_talk'.$tableid,array(
        'id' => $talkid,
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'friendid'=>$friendid,
        'talk'=>$chat,
        'datetime'=>$dataline,
        'talkstate'=>1,
        'type'=>3,
        'time'=>$_GET['time'],
    ),true);
    if($talkid){
        $frienduser = getuserbyuid($friendid);
        notification_add($friendid, 'system',lang("plugin/aljol","aljol_inc_php_11").$_G['username'].lang("plugin/aljol","aljol_inc_php_12").'<a href="plugin.php?id=aljol&act=talk&friendid='.$_G['uid'].'">'.lang("plugin/aljol","aljol_inc_php_13").'</a>',array('from_idtype'=>'aljol', 'from_id' => $_G['uid']));
        news($friendid,lang("plugin/aljol","aljol_inc_php_14"));
        $tmp_array=array(
            'code'=>200,
            'chat'=>ubbReplace($chat),
            'uid'=>$_G['uid'],
            'friendid'=>$friendid,
            'username'=>$_G['username'],
            'head'=> avatar($_G['uid']),
            'type'=>3,
            'datetime' => dgmdate($dataline, 'm-d H:i:s')
        );
        if($off_uid && $off_uid == $_G['uid']){
            $tmp_array['username'] = $off_name;
            $tmp_array['head'] = $off_logo ? '<img src="'.$off_logo.'" />' : '';
        }
        if($bd['name'] && $bd['kf_uid'] == $_G['uid']){
            $tmp_array['username'] = $bd['name'];
            $tmp_array['head'] = $bd['logo'] ? '<img src="'.$bd['logo'].'" />' : '';
        }
    }else{
        $tmp_array=array(
            'code'=>400,
        );
    }
    echo json_encode(ajaxPostCharSet($tmp_array));
}else if($act == 'sendvideo') {//������Ƶ��Ϣ
    if($_G['groupid'] == '4'){//��ֹ����
        $tmp_array=array(
            'code'=>4,
        );
        echo json_encode(ajaxPostCharSet($tmp_array));
        exit;
    }
    if($_G['groupid'] == '5'){//��ֹ����
        $tmp_array=array(
            'code'=>5,
        );
        echo json_encode(ajaxPostCharSet($tmp_array));
        exit;
    }

    $talkid=DB::insert('aljol_talk',array(
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'friendid'=>$friendid,
        'talk'=>$chat,
        'datetime'=>$dataline,
        'talkstate'=>1,
        'type'=>5,
        'time'=>$_GET['time'],
    ),true);
    
    DB::insert('aljol_talk'.$tableid,array(
        'id' => $talkid,
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'friendid'=>$friendid,
        'talk'=>$chat,
        'datetime'=>$dataline,
        'talkstate'=>1,
        'type'=>5,
        'time'=>$_GET['time'],
    ),true);
    
    if($talkid){
        $frienduser = getuserbyuid($friendid);
        notification_add($friendid, 'system',lang("plugin/aljol","aljol_inc_php_15").$_G['username'].lang("plugin/aljol","aljol_inc_php_16").'<a href="plugin.php?id=aljol&act=talk&friendid='.$_G['uid'].'">'.lang("plugin/aljol","aljol_inc_php_17").'</a>',array('from_idtype'=>'aljol', 'from_id' => $_G['uid']));
        news($friendid,lang("plugin/aljol","aljol_inc_php_18"));
        $tmp_array=array(
            'code'=>200,
            'uid'=>$_G['uid'],
            'friendid'=>$friendid,
            'username'=>$_G['username'],
            'head'=> avatar($_G['uid']),
            'datetime' => dgmdate($dataline, 'm-d H:i:s')
        );
        if($_G['mobile']){
            $tmp_array['chat'] = '<div style="position: relative;" class="sd-video-play pointer"><div class="sd_video_li"></div><video data-width="640" data-height="1280" width="100%" height="auto" src="'.$chat.'" poster="'.$chat.'?x-oss-process=video/snapshot,t_5000,m_fast,f_jpg&crazycache=1"  preload="none" class="video_iframe" webkit-playsinline="true" playsinline=""  muted="muted">'.$no_play.'</video></div>';
            $tmp_array['chat_mobile'] = '<div style="position: relative;" class="sd-video-play pointer"><div class="sd_video_li"></div><video data-width="640" data-height="1280" width="100%" height="auto" src="'.$chat.'" poster="'.$chat.'?x-oss-process=video/snapshot,t_5000,m_fast,f_jpg&crazycache=1"  preload="none" class="video_iframe" webkit-playsinline="true" playsinline=""  muted="muted">'.$no_play.'</video></div>';
            $tmp_array['chat_pc'] = '<video data-width="720" id="video_common" data-height="1280" width="100%" height="auto" style="max-height:300px;" src="'.$chat.'" webkit-playsinline="true"  playsinline="" preload="true" muted="muted" controls="controls" >'.$no_play.'</video>';
        }else{
            $tmp_array['chat'] = '<video data-width="720" id="video_common" data-height="1280" width="100%" height="auto" style="max-height:300px;" src="'.$chat.'" webkit-playsinline="true"  playsinline="" preload="true" muted="muted" controls="controls" >'.$no_play.'</video>';
            $tmp_array['chat_pc'] = '<video data-width="720" id="video_common" data-height="1280" width="100%" height="auto" style="max-height:300px;" src="'.$chat.'" webkit-playsinline="true"  playsinline="" preload="true" muted="muted" controls="controls" >'.$no_play.'</video>';
            $tmp_array['chat_mobile'] = '<div style="position: relative;" class="sd-video-play pointer"><div class="sd_video_li"></div><video data-width="640" data-height="1280" width="100%" height="auto" src="'.$chat.'" poster="'.$chat.'?x-oss-process=video/snapshot,t_5000,m_fast,f_jpg&crazycache=1"  preload="none" class="video_iframe" webkit-playsinline="true" playsinline=""  muted="muted">'.$no_play.'</video></div>';
        }
        if($off_uid && $off_uid == $_G['uid']){
            $tmp_array['username'] = $off_name;
            $tmp_array['head'] = $off_logo ? '<img src="'.$off_logo.'" />' : '';
        }
        if($bd['name'] && $bd['kf_uid'] == $_G['uid']){
            $tmp_array['username'] = $bd['name'];
            $tmp_array['head'] = $bd['logo'] ? '<img src="'.$bd['logo'].'" />' : '';
        }
    }else{
        $tmp_array=array(
            'code'=>400,
        );
    }
    echo json_encode(ajaxPostCharSet($tmp_array));
}else if($act == 'friendchat') {//������Ϣ
    $tableid = '_'.($friendid <= 0 ? 0 :$_G['uid']%10);
    if(!$friendid){
        $friendtalk=DB::fetch_first('select a.*,b.picture from %t a left join %t b on a.picture=b.pid where a.id>%d and a.friendid=0 and a.uid!=%d order by a.id asc',array('aljol_talk'.$tableid,'aljol_picture', $_GET['chatid'], $_G['uid'], 1));
    }elseif($friendid<0){
        $friendtalk=DB::fetch_first('select a.*,b.picture from %t a left join %t b on a.picture=b.pid where a.id>%d and a.friendid=%d and a.uid!=%d order by a.id asc',array('aljol_talk'.$tableid,'aljol_picture', $_GET['chatid'],$friendid, $_G['uid'], 1));
    }else{
        $friendtalk=DB::fetch_first('select a.*,b.picture from %t a left join %t b on a.picture=b.pid where a.uid=%d and a.friendid=%d and a.talkstate=%d order by a.datetime asc',array('aljol_talk'.$tableid,'aljol_picture',$friendid,$_G['uid'],1));
    }

    if(!empty($friendtalk)){
        if($friendtalk['type'] == 4){
            $g=C::t('#aljbd#aljbd_goods')->fetch($friendtalk['gid']);
            $chat = chathtml($g);
        }else if($friendtalk['type'] == 5){
            if($_G['mobile']){
                $chat = '<div style="position: relative;" class="sd-video-play pointer"><div class="sd_video_li"></div><video data-width="640" data-height="1280" width="100%" height="auto" src="'.$friendtalk['talk'].'" poster="'.$friendtalk['talk'].'?x-oss-process=video/snapshot,t_5000,m_fast,f_jpg&crazycache=1"  preload="none" class="video_iframe" webkit-playsinline="true" playsinline=""  muted="muted">'.$no_play.'</video></div>';
            }else{
                $chat = '<video data-width="720" id="video_common" data-height="1280" width="100%" height="auto" style="max-height:300px;" src="'.$friendtalk['talk'].'" webkit-playsinline="true"  playsinline="" preload="true" muted="muted" controls="controls" >'.$no_play.'</video>';
            }

        }else{
            $chat = ubbReplace($friendtalk['talk']);
        }
        if($friendid<=0) {
            $model = 'group';
        }else{
            $model = 'per';
        }
        $tmp_array=array(
            'code' => 200,
            'chat' => $chat,
            'username' => $friendtalk['username'],
            'uid' => $friendtalk['uid'],
            'id' => $friendtalk['id'],
            'datetime' => date('H:i',$friendtalk['datetime']),
            'picture' => $friendtalk['picture'],
            'type' => $friendtalk['type'],
            'aljhb_img' => $_G['cache']['plugin']['aljol']['aljhb_img'],
            'model' => $model,
            'head' => avatar($friendtalk['uid']),
        );
        if($_G['cache']['plugin']['aljbd'] && $friendtalk['uid']){
            $bd = DB::fetch_first('SELECT * FROM %t WHERE kf_uid=%d LIMIT 1',array('aljbd',$friendtalk['uid']));
        }
        if($bd['name'] && $bd['kf_uid'] == $friendtalk['uid']){
            $tmp_array['username'] = $bd['name'];
            $tmp_array['head'] = $bd['logo'] ? '<img src="'.$bd['logo'].'" />' : '';
        }
        if($off_uid && $off_uid == $friendtalk['uid']){
            $tmp_array['username'] = $off_name;
            $tmp_array['head'] = $off_logo ? '<img src="'.$off_logo.'" />' : '';
        }
        DB::query('update %t set talkstate=%d where id=%d',array('aljol_talk',2,$friendtalk['id']));
        DB::query('update %t set talkstate=%d where id=%d',array('aljol_talk'.$tableid,2,$friendtalk['id']));
    }else {
        $tmp_array=array(
            'code'=>400,
        );
    }
    //debug($friendtalk);
    echo json_encode(ajaxPostCharSet($tmp_array));
    exit;
}else if ($act == 'news') {//ǰ̨��Ϣ����ģ��
    $time = TIMESTAMP-1800;
    $news_del = DB::fetch_all('select * from %t where friendid=%d and datetime>%d',array('aljol_news',$_G['uid'],$time));
    if(!empty($news_del)) {
        foreach ($news_del as $tmp_key => $tmp_value) {
            if($_G['cache']['plugin']['aljol']['is_qun'] && $tmp_value['uid'] == 0){
                continue;
            }
            if($_G['cache']['plugin']['aljol']['is_groupqun'] && $tmp_value['uid'] < 0 && $tmp_value['uid'] != '-10001'){
                continue;
            }
            $tmp_value['lastnews'] = ubbReplace($tmp_value['lastnews']);
            if($tmp_value['datetime']>$beginToday && $tmp_value['datetime']<$endToday){
                $tmp_value['time'] = date('H:i',$tmp_value['datetime']);
            }else {
                $tmp_value['time'] = date('Y-m-d',$tmp_value['datetime']);
            }
            $tmp_value['head'] = avatar($tmp_value['uid']);
            $userinfo = getuserbyuid($tmp_value['uid']);
            $tmp_value['username'] = $userinfo['username'];
            if($tmp_value['uid'] > 0){
                if($_G['cache']['plugin']['aljbd']){
                    $bd = DB::fetch_first('SELECT * FROM %t WHERE kf_uid=%d LIMIT 1',array('aljbd',$tmp_value['uid']));
                }
                if($bd['name'] && $bd['kf_uid'] == $tmp_value['uid']){
                    $tmp_value['username'] = $bd['name'];
                    $tmp_value['head'] = $bd['logo'] ? '<img src="'.$bd['logo'].'" />' : '';
                }
            }else{
                $tmp_value['username'] = $_G['cache']['plugin']['aljol']['q_name'];
            }
            if($off_uid && $off_uid == $tmp_value['uid']){
                $tmp_value['username'] = $off_name;
                $tmp_value['head'] = $off_logo ? '<img src="'.$off_logo.'" />' : '';
            }
            //��������������Ϣ
            if($tmp_value['uid'] < 0 && $tmp_value['type'] == 1){
                $tmp_value['username'] = lang("plugin/aljol","aljol_inc_php_26");
                $tmp_value['fidicon'] = '<img src="source/plugin/aljol/static/img/wuliu.png" />';
                $tmp_value['newscount'] = DB::result_first('select count(*) from %t where uid=%d and status=0 and news_type=1',array('aljhtx_notification',$tmp_value['friendid']));
            }else{
                $tableid = '_'.($tmp_value['friendid']<=0 ? 0 : $tmp_value['friendid']%10);
                $tmp_value['newscount'] = DB::result_first('select count(*) from %t where uid=%d and friendid=%d and talkstate=1',array('aljol_talk'.$tableid,$tmp_value['uid'],$tmp_value['friendid']));
            }
            $news[$tmp_key] = $tmp_value;
        }
        echo json_encode(ajaxPostCharSet($news));
    }
}else if($act == 'newsnum'){
    $time = TIMESTAMP-1800;
    $tableid = '_'.($_G['uid']%10);
    $newsCount = DB::result_first('select count(*) from %t where friendid=%d and talkstate=1',array('aljol_talk'.$tableid,$_G['uid']));
    //$newsNum = DB::result_first('select count(*) from %t where friendid=%d and talkstate=1 and is_read=0 and datetime>%d',array('aljol_talk',$_G['uid'],$time));
    //��������������Ϣ
    $new_noti = DB::result_first('select count(*) from %t where uid=%d and status=0 and news_type=1',array('aljhtx_notification',$_G['uid']));
    $newscount = $newscount + $new_noti;
    $tmp_array['newscount'] = $newsCount;
    if(DB::query('update %t set is_read=%d where friendid=%d and talkstate=1 and is_read=0 and datetime>%d',array('aljol_talk',1,$_G['uid'],$time))){
        $tmp_array['newscnum'] = 1;
    }else{
        $tmp_array['newscnum'] = 0;
    }
    echo json_encode(ajaxPostCharSet($tmp_array));
}else if($act == 'deletenews') {//ɾ����Ϣ����
    if(DB::delete('aljol_news', array('uid' => $friendid,'friendid'=>$_G['uid']))) {
        $tmp_array=array(
            'code'=>200,
        );
    }else {
        $tmp_array=array(
            'code'=>400,
        );
    }
    echo json_encode(ajaxPostCharSet($tmp_array));
}else if($act == 'upload') {//�ϴ�ͼƬ
    if($_G['groupid'] == '4'){//��ֹ����
        $tmp_array=array(
            'code'=>4,
        );
        echo json_encode(ajaxPostCharSet($tmp_array));
        exit;
    }
    if($_G['groupid'] == '5'){//��ֹ����
        $tmp_array=array(
            'code'=>5,
        );
        echo json_encode(ajaxPostCharSet($tmp_array));
        exit;
    }
    $type = addslashes($_GET['type']);
    $rand = rand(100, 999);
    $pics = date("YmdHis") . $rand.'.'.$type;
    $dir='source/plugin/aljol/static/img/file/'.date('Ymd',TIMESTAMP).'/';
    if(!is_dir($dir)) {
        @mkdir($dir, 0777);
    }
    $src = $dir. $pics;
    $type_image['src']=$src;

    if($type == 'gif') {
        if(@copy($_FILES['picture']['tmp_name'], $src)||@move_uploaded_file($_FILES['picture']['tmp_name'], $src)){
            if (file_exists($src)) {
                if($_G['cache']['plugin']['aljoss']['Access_Key']){

                    $src = T::oss($src, 'aljol');
                    $type_image['src']=$src;
                }
            }
            @unlink($_FILES['picture']['tmp_name']);
        }
    }else {
        if(IN_MINI == 1){
            if($_G['cache']['plugin']['aljwsq']['appid']){
                require_once DISCUZ_ROOT.'source/plugin/aljwsq/mapp_wechatclient.lib.class.php';
            }else if($_G['cache']['plugin']['aljwx']['g_appid']){
                require_once DISCUZ_ROOT.'source/plugin/aljwx/class/wechatclient.lib.class.php';
            }
            $g_appid = $_G['cache']['plugin']['aljwsq']['appid'] ? trim($_G['cache']['plugin']['aljwsq']['appid']) : trim($_G['cache']['plugin']['aljwx']['g_appid']);
            $g_AppSecret = $_G['cache']['plugin']['aljwsq']['appsecret'] ? trim($_G['cache']['plugin']['aljwsq']['appsecret']) : trim($_G['cache']['plugin']['aljwx']['g_AppSecret']);
            $wechat_client = new WeChatClient($g_appid,$g_AppSecret);
            $return = $wechat_client -> download($_GET['picpath']);
            if(file_put_contents(DISCUZ_ROOT.'./'.$src, $return) !== false){

                if (file_exists($src)) {
                    if ($_G['cache']['plugin']['aljoss']['Access_Key']) {

                        $src = T::oss($src, 'aljol');
                        $type_image['src'] = $src;
                    }
                }
            }
        }else {
            file_put_contents($src, file_get_contents($_GET['picpath']));
            if (file_exists($src)) {
                if ($_G['cache']['plugin']['aljoss']['Access_Key']) {

                    $src = T::oss($src, 'aljol');
                    $type_image['src'] = $src;
                }
            }
        }
    }
    
    $picture = DB::insert('aljol_picture',array(
        'uid'=>$_G['uid'],
        'friendid'=>$friendid,
        'picture'=>$type_image['src'],
        'datetime'=>$dataline,
    ),true);
    $talkid = DB::insert('aljol_talk',array(
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'friendid'=>$friendid,
        'datetime'=>$dataline,
        'talkstate'=>1,
        'picture'=>$picture,
    ),true);
    if($talkid) {
        $chat = lang("plugin/aljol","aljol_inc_php_19");
        news($friendid,$chat);
        $tmp_array = array(
            'code' => 200,
            'uid'=>$_G['uid'],
            'friendid'=>$friendid,
            'username'=>$_G['username'],
            'src' => $type_image['src'],
            'picture'=>$type_image['src'],
            'head' => avatar($_G['uid']),
            'datetime' => dgmdate($dataline, 'm-d H:i:s')
        );
        if($off_uid && $off_uid == $_G['uid']){
            $tmp_array['username'] = $off_name;
            $tmp_array['head'] = $off_logo ? '<img src="'.$off_logo.'" />' : '';
        }
        if($bd['name'] && $bd['kf_uid'] == $_G['uid']){
            $tmp_array['username'] = $bd['name'];
            $tmp_array['head'] = $bd['logo'] ? '<img src="'.$bd['logo'].'" />' : '';
        }
    }else {
        $tmp_array=array(
            'code'=>400,
        );
    }
   echo json_encode(ajaxPostCharSet($tmp_array));
}else if ($act == 'friendlist') {
    $listtype = intval($_GET['listtype']);
    $page = $_GET['page']?intval($_GET['page']):1;
    $paging = 10;
    $offset = ($page-1)*$paging;
    if($listtype == 1) {//�ҵ�����
        $friend = DB::fetch_all('select a.*, b.sightml from %t a left join %t b on a.fuid = b.uid where a.uid=%d limit %d,%d',array($friendtable,$signtable,$_G['uid'],$offset,$paging));
        if(!empty($friend)) {
            foreach ($friend as $tmp_key => $tmp_value) {
                if(empty($tmp_value['sightml'])) {
                    $tmp_value['sightml'] = $a;
                }
                $userinfo = getuserbyuid($tmp_value['fuid']);
                $tmp_value['fusername'] = $userinfo['username'];
                $tmp_array[]=array(
                    'code' => 200,
                    'head' => avatar($tmp_value['fuid']),
                    'friendname' => $tmp_value['fusername'],
                    'friendid' => $tmp_value['fuid'],
                    'sign' => SignReplace($tmp_value['sightml']),
                );
            }
        }
    }else if($listtype == 2) {//�ҹ�ע��
        $fans = DB::fetch_all('select a.*, b.sightml from %t a left join %t b on a.followuid = b.uid where a.uid=%d limit %d,%d',array($fanstable,$signtable,$_G['uid'],$offset,$paging));
        if(!empty($fans)) {
            foreach ($fans as $tmp_key => $tmp_value) {
                if(empty($tmp_value['sightml'])) {
                    $tmp_value['sightml'] = $a;
                }
                $tmp_array[]=array(
                    'code' => 200,
                    'head' => avatar($tmp_value['followuid']),
                    'friendname' => $tmp_value['fusername'],
                    'friendid' => $tmp_value['followuid'],
                    'sign' => SignReplace($tmp_value['sightml']),
                );
            }
        }
    }else{//��ע�ҵ�
        $fans = DB::fetch_all('select a.*, b.sightml from %t a left join %t b on a.uid = b.uid where a.followuid=%d limit %d,%d',array($fanstable,$signtable,$_G['uid'],$offset,$paging));
        if(!empty($fans)) {
            foreach ($fans as $tmp_key => $tmp_value) {
                if(empty($tmp_value['sightml'])) {
                    $tmp_value['sightml'] = $a;
                }
                $tmp_array[]=array(
                    'code' => 200,
                    'head' => avatar($tmp_value['uid']),
                    'friendname' => $tmp_value['username'],
                    'friendid' => $tmp_value['uid'],
                    'sign' => SignReplace($tmp_value['sightml']),
                );
            }
        }
    }
    echo json_encode(ajaxPostCharSet($tmp_array));
}else if($act == 'search') {//����
    $searchkey = addslashes($_GET['searchkey']);
    if(!is_numeric($searchkey)){
        $str = '%'.$searchkey.'%';
        $searchkey = DB::result_first('select uid from %t where username like %s', array('common_member', $str));
    }
    if($searchkey == $_G['uid'] || $searchkey == $_G['username']) {
        $tmp_array=array(
                'code'=>500,
        );
    }else{
        $userlist = DB::fetch_first('select a.*, b.sightml from %t a left join %t b on a.uid = b.uid where a.uid=%d',array($usertable,$signtable,$searchkey));
        if(!empty($userlist)) {
            if(empty($userlist['sightml'])) {
                $userlist['sightml'] = $a;
            }else{
                $userlist['sightml'] = SignReplace($userlist['sightml']);
            }
            $tmp_array=$userlist;
            $tmp_array['code']=200;
            $tmp_array['head']=avatar($userlist['uid']);
            $friend = DB::fetch_first('select * from %t where uid=%d and fuid=%d',array($friendtable,$_G['uid'],$searchkey));
            if(!empty($friend)) {//�Ѿ��Ǻ���
                $tmp_array['myfriend'] = 1;
            }else {
                $friendrequest = DB::fetch_first('select * from %t where uid=%d and fuid=%d',array($requesttable,$searchkey,$_G['uid']));
                if(!empty($friendrequest)) {//�ȴ���֤
                    $tmp_array['myfriend'] = 2;
                }else{//�����������
                    $tmp_array['myfriend'] = 3;
                }

            }
        }else{
            $tmp_array=array(
                'code'=>400,
            );
        }
    }
    echo json_encode(ajaxPostCharSet($tmp_array));
}else if($act == 'avatar_addfriend'){
    $friend = DB::fetch_first('select * from %t where uid=%d and fuid=%d',array($friendtable,$_G['uid'],$friendid));
    $user = getuserbyuid($friendid);
    if($_G['uid'] == $friendid){
        $tmp_array=array(
            'code'=>400,
        );
    }else{
        $tmp_array=array(
            'code'=>100,
            'username'=>$user['username'].'('.$friendid.')',
        );
        if($friend){
            $tmp_array['content'] .= '<p onclick="location.href=\'plugin.php?id=aljol&act=talk&friendid='.$friendid.'\';">'.lang("plugin/aljol","aljol_inc_php_20").'</p>';
        }else{
            $tmp_array['content'] .= '<p onclick="addfriend(\''.$friendid.'\')">'.lang("plugin/aljol","aljol_inc_php_21").'</p><p onclick="location.href=\'plugin.php?id=aljol&act=talk&friendid='.$friendid.'\';">'.lang("plugin/aljol","aljol_inc_php_22").'</p>';
        }
        if($_G['cache']['plugin']['aljgwc']['aljol'] || $_G['cache']['plugin']['aljbdx']['aljol']){
            if($_GET['bid']){
                $bd = DB::fetch_first('select * from %t where id=%d and rubbish=0 and status=1 limit 1',array('aljbd',$_GET['bid']));
            }else{
                $bd = DB::fetch_first('select * from %t where uid=%d and rubbish=0  and status=1 limit 1',array('aljbd',$friendid));
            }
            if($bd){
                $tmp_array['content'] .= '<p onclick="location.href=\'plugin.php?id=aljbd&act=view&bid='.$bd['id'].'\';">'.lang("plugin/aljol","aljol_inc_php_23").'</p>';
            }
        }
    }
    echo json_encode(ajaxPostCharSet($tmp_array));
    exit;
}else if($act == 'addfriend') {//���Ӻ���
    $thisfriend = DB::fetch_first('select * from %t where uid=%d and fuid=%d',array($friendtable,$_G['uid'],$friendid));
    if(empty($thisfriend)) {
        DB::insert($requesttable,array(
            'uid'=>$friendid,
            'fuid'=>$_G['uid'],
            'fusername'=>$_G['username'],
            'gid'=>1,
            'dateline'=>TIMESTAMP,
        ));
        $a = lang("plugin/aljol","aljol_inc_php_24").'&nbsp;&nbsp;';
        $b = lang("plugin/aljol","aljol_inc_php_25");
        $c = "showWindow(this.id, this.href,'get',0);";
        $str = '<a href="home.php?mod=space&uid='.$_G['uid'].'">'.$_G['username'].'</a>'.$a.'<a onclick="'.$c.'" class="xw1" id="afr_'.$_G['uid'].'" href="home.php?mod=spacecp&ac=friend&op=add&uid='.$_G['uid'].'&from=notice">'.$b.'</a>';
        DB::insert('home_notification',array(
            'uid' => $friendid,
            'type' => 'friend',
            'new' => 1,
            'authorid' =>$_G['uid'],
            'author' => $_G['username'],
            'note' => $str,
            'dateline' => TIMESTAMP,
            'from_id' => $_G['uid'],
            'from_idtype' => 'friendrequest',
            'category' =>2,
        ));
        $tmp_array=array(
            'code'=>200,
        );
    }else{
        $tmp_array=array(
            'code'=>400,
        );
    }

    echo json_encode(ajaxPostCharSet($tmp_array));
}else if($act == 'yesandno') {//���������Ƿ�ͬ��
    $stateid = intval($_GET['stateid']);
    $firendname = DB::fetch_first('select * from %t where uid=%d',array('common_member',$friendid));
    if($stateid == 1) {//ͬ��
        DB::insert($friendtable,array(
            'uid'=>$_G['uid'],
            'fuid'=>$friendid,
            'fusername'=>$firendname['username'],
            'gid'=>1,
            'dateline'=>TIMESTAMP,
        ));
        DB::insert($friendtable,array(
            'uid'=>$friendid,
            'fuid'=>$_G['uid'],
            'fusername'=>$_G['username'],
            'gid'=>1,
            'dateline'=>TIMESTAMP,
        ));
        notification_add($friendid, 'friend', 'friend_add');
        $tmp_array=array(
            'code'=>200,
        );
    }else{
        $tmp_array=array(
            'code'=>400,
        );
    }
    DB::delete($requesttable, array('uid' => $_G['uid'],'fuid' =>$friendid));
    DB::delete('home_notification', array('uid' => $_G['uid'],'type' => 'friend','authorid' =>$friendid,'author' => $firendname['username'],'from_idtype' => 'friendrequest'));
    echo json_encode(ajaxPostCharSet($tmp_array));
}

//ajax����
else if($act == 'newstype'){
    if(abs($friendid) == 10001){
        $news_type = 1;
        $type = 1;
        $navtitle = lang("plugin/aljol","aljol_inc_php_26");
    }
    $friendrecord = DB::fetch_first('select * from %t where friendid=%d and uid=%d and type=%d',array('aljol_news',$friendid,'-1000'.$type,$type));
    if($friendrecord['username']){
        $navtitle = $friendrecord['username'];
    }
    
    $perpage = 10;
    $morepage = $_GET['page'] ? $_GET['page'] : 1;
    $begincount = ($morepage - 1)*$perpage;
    //��������������Ϣ
    $notificationList = DB::fetch_all('select * from %t where news_type=%d and uid=%d order by id desc limit %d,%d',array('aljhtx_notification',$news_type,$_G['uid'], $begincount , $perpage));
    $bindTemplateConfig = include('source/plugin/aljhtx/config/bind_template.php');
    foreach($notificationList as $nk => $nv){
        $notificationList[$nk]['param'] = unserialize($nv['param']);
        $notificationList[$nk]['type_name'] = $bindTemplateConfig[$nv['type']]['name'];;
        $notificationList[$nk]['dateline'] = dgmdate($nv['dateline'],'u');
    }
    if($_GET['do'] == 'ajax'){
        DB::update('aljhtx_notification',array('status'=>1),array('uid'=>$_G['uid'],'news_type'=>$news_type));
        if($notificationList){
            echo json_encode(ajaxPostCharSet($notificationList));
        }else{
            echo '1';
        }
        exit;
    }else{
        include template('aljol:newstype');
    }
}else if($act == 'talk'){//������棬��ʼ������20������
    if($_G['cache']['plugin']['aljbd']){
        //�������
        if($_G['cache']['plugin']['aljhtx']){
            //��ݱ�
            loadcache('express_company', 1);
            if(!$_G['cache']['express_company']) {
                $express_company_list = DB::result_first('select svalue from %t where skey=%s', array('aljhtx_system_setting', 'express_company'));
                savecache('express_company', $express_company_list);
            }else{
                $express_company_list = $_G['cache']['express_company'];
            }
            
            $express_company = unserialize($express_company_list) ? unserialize($express_company_list) : include('source/plugin/aljhtx/config/express_company.php');
            $expressCompanyList = $express_company;
        }
    }
    
    DB::update('aljol_talk',array('talkstate'=>2),array('uid'=>$friendid,'friendid'=>$_G['uid']));
    
    $tableid = '_'.($friendid <= 0 ? 0 :$_G['uid']%10);
    DB::update('aljol_talk'.$tableid,array('talkstate'=>2),array('uid'=>$friendid,'friendid'=>$_G['uid']));
    
    if($friendid == $_G['uid'] && $friendid>0) {
        header('Location:plugin.php?id=aljol');
        exit;
    }
    if($friendid < -10000){
        header('Location:plugin.php?id=aljol&act=newstype&friendid='.$friendid);
        exit;
    }
    if($friendid<0){
        $firendname = DB::fetch_first('select * from %t where fid=%d',array('forum_forum',abs($friendid)));
        $firendname['username'] = $firendname['name'];
    }else{
        $firendname = DB::fetch_first('select * from %t where uid=%d',array($usertable,$friendid));
    }
    if(!$friendid){
        $selfrecordcount = DB::result_first('select count(*) from %t where friendid=0 order by id asc',array('aljol_talk'));
    }else{
        $selfrecordcount = DB::result_first('select count(*) from %t where (uid=%d and friendid=%d) or (uid=%d and friendid=%d) order by id asc',array('aljol_talk',$_G['uid'],$friendid,$friendid,$_G['uid']));
    }
    //$selfrecordcount = DB::result_first('select count(*) from %t where (uid=%d and friendid=%d) or (uid=%d and friendid=%d) order by datetime asc',array('aljol_talk',$_G['uid'],$friendid,$friendid,$_G['uid']));
    /*
    $begincount = $selfrecordcount-20;
    if($begincount <0) {
        $begincount = 0;
    }*/
    $perpage = 10;
    $morepage = $_GET['morepage'] ? $_GET['morepage'] : 1;
    $begincount = ($morepage - 1)*$perpage;
    if(!$friendid){
        if($morepage>=2){
            $selftalkrecord = DB::fetch_all('select a.*, b.picture as img from %t a left join %t b on a.picture=b.pid where a.id<%d and a.friendid=0 order by a.id desc limit %d,%d',array('aljol_talk','aljol_picture', $_GET['chatid'], $begincount , $perpage));
        }else{
            $selftalkrecord = DB::fetch_all('select a.*, b.picture as img from %t a left join %t b on a.picture=b.pid where a.friendid=0 order by a.id desc limit %d,%d',array('aljol_talk','aljol_picture', $begincount , $perpage));
            $loadchatid = $selftalkrecord[0]['id'];
        }

        if(empty($_GET['ajax'])){
            sort($selftalkrecord);
        }
    }else if($friendid<0){
        if($morepage>=2){
            $selftalkrecord = DB::fetch_all('select a.*, b.picture as img from %t a left join %t b on a.picture=b.pid where a.id<%d and a.friendid=%d order by a.id desc limit %d,%d',array('aljol_talk','aljol_picture', $_GET['chatid'], $friendid, $begincount , $perpage));
        }else{
            $selftalkrecord = DB::fetch_all('select a.*, b.picture as img from %t a left join %t b on a.picture=b.pid where a.friendid=%d order by a.id desc limit %d,%d',array('aljol_talk','aljol_picture',$friendid, $begincount , $perpage));
            $loadchatid = $selftalkrecord[0]['id'];
        }

        if(empty($_GET['ajax'])){
            sort($selftalkrecord);
        }
    }else{
        $selftalkrecord = DB::fetch_all('select a.*, b.picture as img from %t a left join %t b on a.picture=b.pid where (a.uid=%d and a.friendid=%d) or (a.uid=%d and a.friendid=%d) order by a.id desc limit %d,%d',array('aljol_talk','aljol_picture',$_G['uid'],$friendid,$friendid,$_G['uid'],$begincount,$perpage));
        //debug($selftalkrecord);
        if(empty($_GET['ajax'])){
            sort($selftalkrecord);
        }
        //debug($selftalkrecord);
    }
    if(!empty($selftalkrecord)) {
        foreach ($selftalkrecord as $tmp_key => $tmp_value) {
            if($tmp_value['type'] == 5){
                if($_G['mobile']){
                    $tmp_value['talk'] = '<div style="position: relative;" class="sd-video-play pointer"><div class="sd_video_li"></div><video data-width="640" data-height="1280" width="100%" height="auto" src="'.$tmp_value['talk'].'" poster="'.$tmp_value['talk'].'?x-oss-process=video/snapshot,t_5000,m_fast,f_jpg&crazycache=1"  preload="none" class="video_iframe" webkit-playsinline="true" playsinline=""  muted="muted">'.$no_play.'</video></div>';
                }else{
                    $tmp_value['talk'] = '<video data-width="720" id="video_common" data-height="1280" width="100%" height="auto" style="max-height:300px;" src="'.$tmp_value['talk'].'" webkit-playsinline="true"  playsinline="" preload="true" muted="muted" controls="controls" >'.$no_play.'</video>';
                }
            }else{
                $tmp_value['talk'] = ubbReplace($tmp_value['talk']);
            }
            $tmp_value['datetime'] = date('m-d H:i:s',$tmp_value['datetime']);
            if($tmp_value['img']) {
                $tmp_value['picture'] = $tmp_value['img'];
            }
            $tmp_value['fidicon'] = avatar($tmp_value['uid']);
            if($off_uid && $off_uid == $tmp_value['uid']){
                $tmp_value['username'] = $off_name;
                $tmp_value['fidicon'] = $off_logo ? '<img src="'.$off_logo.'" />' : '';
            }
            if($_G['cache']['plugin']['aljbd']){
                $bd = DB::fetch_first('SELECT * FROM %t WHERE kf_uid=%d LIMIT 1',array('aljbd',$tmp_value['uid']));
            }
            if($bd['name'] && $bd['kf_uid'] == $tmp_value['uid']){
                $tmp_value['username'] = $bd['name'];
                $tmp_value['fidicon'] = $bd['logo'] ? '<img src="'.$bd['logo'].'" />' : '';
                
            }
            
            if($tmp_value['type'] == 4){
                $g=C::t('#aljbd#aljbd_goods')->fetch($tmp_value['gid']);
                $tmp_value['talk'] = chathtml($g);
            }
            $selftalkrecord[$tmp_key] = $tmp_value;
            unset($g);
            unset($bd);
        }
    }
    if($_G['cache']['plugin']['aljbd']){
        $brand_kefus = DB::fetch_first('SELECT * FROM %t WHERE kf_uid=%d LIMIT 1',array('aljbd',$_G['uid']));
        $brand_kefu = ($brand_kefus || $off_uid == $_G['uid'] || $_G[groupid] == 1) ? 1 : 0;
    }
    
    if($_GET['ajax']){
        //debug($selftalkrecord);
        if($friendid<=0) {
            $model = 'group';
        }else{
            $model = 'per';
        }
        $tmp_array=array(
            'code'=>200,
            'aljhb_img' => $_G['cache']['plugin']['aljol']['aljhb_img'],
            'model' => $model,
            'data'=>ajaxPostCharSet($selftalkrecord)
        );

        echo json_encode($tmp_array);
        exit;
    }else{
        if($_G['cache']['plugin']['aljwsq']){
            require_once DISCUZ_ROOT.'source/plugin/aljwsq/mapp_wechatclient.lib.class.php';
            $wechat_client = new WeChatClient($_G['cache']['plugin']['aljwsq']['appid'],$_G['cache']['plugin']['aljwsq']['appsecret']);
            $signPackage = $wechat_client -> getJsApiSignPackage();
        }
        if($_GET['gid']){
            $gid = intval($_GET['gid']);
            $g=C::t('#aljbd#aljbd_goods')->fetch($gid);
            if($g['bid']){
                $bd = C::t('#aljbd#aljbd')->fetch($g['bid']);
                $firendname['username'] = $bd['name'];
            }
        }
        if($off_name && $off_uid == $friendid){
            $firendname['username'] = $off_name;
        }
        if($_G['cache']['plugin']['aljbd'] && $friendid){
            $bd = DB::fetch_first('SELECT * FROM %t WHERE kf_uid=%d LIMIT 1',array('aljbd',$friendid));

            if($bd['kf_uid'] == $friendid){
                $firendname['username'] = $bd['name'];
            }
        }
        
        include template('aljol:talk');
    }
}else if($act == 'requestfriendlist') {//����֪ͨ
    $page = $_GET['page']?intval($_GET['page']):1;
    $paging = 10;
    $offset = ($page-1)*$paging;
    $addfriendrequest = DB::fetch_all('select a.*,b.sightml from %t a left join %t b on a.fuid=b.uid where a.uid=%d limit %d,%d',array($requesttable,$signtable,$_G['uid'],$offset,$paging));
    foreach ($addfriendrequest as $tmp_key => $tmp_value) {
        if(empty($tmp_value['sightml'])){
            $tmp_value['sightml'] = $a;
        }else{
            $tmp_value['sightml'] = SignReplace($tmp_value['sightml']);
        }
        $addfriendrequest[$tmp_key] = $tmp_value;

    }
    if($page >=2){
        include template('aljol:requestlist');
    }else{
        include template('aljol:request');
    }
}else if($act == 'ajaxGoods'){
    ajaxGoods();
}else {//�����棬��ʼ���������30�����Ϣ����
    $page = $_GET['page']?intval($_GET['page']):1;
    $paging = 10;
    $offset = ($page-1)*$paging;
    if($_G['cache']['plugin']['aljol']['index_time']){
        $time = TIMESTAMP - $_G['cache']['plugin']['aljol']['index_time']*24*60*60;
        $chatlist_del = DB::fetch_all('select * from %t where friendid=%d and datetime>%d order by datetime desc limit %d,%d',array('aljol_news',$_G['uid'],$time,$offset,$paging));
    }else{
        $chatlist_del = DB::fetch_all('select * from %t where friendid=%d order by datetime desc limit %d,%d',array('aljol_news',$_G['uid'],$offset,$paging));
    }
    if(!empty($chatlist_del)) {
        foreach ($chatlist_del as $tmp_key => $tmp_value) {
            if($_G['cache']['plugin']['aljol']['is_qun'] && $tmp_value['uid'] == 0){
                continue;
            }
            if($_G['cache']['plugin']['aljol']['is_groupqun'] && $tmp_value['uid'] < 0 && $tmp_value['uid'] != '-10001'){
                continue;
            }
            $userinfo = getuserbyuid($tmp_value['uid']);
            $tmp_value['username'] = $userinfo['username'];
            unset($userinfo);
            if($_G['cache']['plugin']['aljol']['official_uid'] && $tmp_value['uid'] == $off_uid){
                $is_off_uid = 1;
                $tmp_value['username'] = $off_name;
                $tmp_value['fidicon'] = $off_logo ? '<img src="'.$off_logo.'" />' : '';
            }
            $tmp_value['lastnews'] = ubbReplace($tmp_value['lastnews']);
            if($tmp_value['datetime']>$beginToday && $tmp_value['datetime']<$endToday){
                $tmp_value['time'] = date('H:i',$tmp_value['datetime']);
            }else {
                $tmp_value['time'] = date('Y-m-d',$tmp_value['datetime']);
            }
            if($tmp_value['uid'] < 0 && $tmp_value['type'] == 0){
                $fnames = DB::fetch_first('select a.name,b.* from %t a left join %t b on a.fid=b.fid where a.fid=%d ',array('forum_forum','forum_forumfield',abs($tmp_value['uid'])));
                $tmp_value['username'] = $fnames['name'];
                $tmp_value['fidicon'] = $fnames['icon'] ? '<img src="data/attachment/group/'.$fnames['icon'].'" />' : '';
            }
            //��������������Ϣ
            if($tmp_value['uid'] < 0 && $tmp_value['type'] == 1){
                $tmp_value['fidicon'] = '<img src="source/plugin/aljol/static/img/wuliu.png" />';
                $tmp_value['username'] = lang("plugin/aljol","aljol_inc_php_26");
                $tmp_value['newscount'] = DB::result_first('select count(*) from %t where uid=%d and status=0  and news_type=1',array('aljhtx_notification',$tmp_value['friendid']));
            }else{
                $tmp_value['newscount'] = DB::result_first('select count(*) from %t where uid=%d and friendid=%d and talkstate=1',array('aljol_talk',$tmp_value['uid'],$tmp_value['friendid']));
            }
            $chatlist[$tmp_key] = $tmp_value;
            $friendidlist[] = $tmp_value['uid'];
            if($tmp_value['uid']>0){
                $kf_uids[] = $tmp_value['uid'];
            }
            $newscount[] = $chatlist[$tmp_key]['newscount'];
            unset($fnames);
        }
    }
    if($newscount){
        //array_multisort($newscount, SORT_DESC, $chatlist);
    }
    if($kf_uids && $_G['cache']['plugin']['aljbd']){
        $bd_kfuids = DB::fetch_all("SELECT kf_uid,name,logo FROM %t WHERE kf_uid IN(%n)", array('aljbd', $kf_uids), 'kf_uid');

        if(!empty($chatlist)) {
            foreach ($chatlist as $tmp_key => $tmp_value) {

                if($bd_kfuids[$tmp_value['uid']]['name']){
                    $tmp_value['username'] = $bd_kfuids[$tmp_value['uid']]['name'];
                    $tmp_value['fidicon'] = $bd_kfuids[$tmp_value['uid']]['logo'] ? '<img src="'.$bd_kfuids[$tmp_value['uid']]['logo'].'" />' : '';
                }
                $chatlist[$tmp_key] = $tmp_value;
            }
        }
    }
    //debug($chatlist);
    if($_G['cache']['plugin']['aljol']['official_uid'] && $off_uid != $_G['uid'] && !$is_off_uid && $page==1){
        $my_chat = DB::fetch_first('select * from %t where friendid=%d and uid=%d',array('aljol_news',$_G['uid'],$off_uid));

        $newscount = DB::result_first('select count(*) from %t where uid=%d and friendid=%d and talkstate=1',array('aljol_talk',$off_uid,$_G['uid']));
        if($my_chat['datetime']>$beginToday && $my_chat['datetime']<$endToday){
            $m_time = date('H:i',$my_chat['datetime'] ? $my_chat['datetime'] : TIMESTAMP);
        }else {
            $m_time = date('Y-m-d',$my_chat['datetime'] ? $my_chat['datetime'] : TIMESTAMP);
        }
        $del_arr = array('0'=>array(
            'uid'=>$off_uid,
            'datetime'=>$my_chat['datetime'] ? $my_chat['datetime'] : TIMESTAMP,
            'time'=>$m_time,
            'username'=>$off_name,
            'lastnews'=>$my_chat['lastnews']  ? $my_chat['lastnews'] :$off_desc,
            'fidicon'=>'<img src="'.$off_logo.'" />',
            'newscount'=>$newscount,
        ));
        if($chatlist){
            $chatlist = array_merge($del_arr, $chatlist);
        }else{
            $chatlist = $del_arr;
        }
    }
    //debug($chatlist);
    if($_GET['do'] == 'ajax'){
        if($chatlist){
            include template('aljol:aljol_list');
        }else{
            echo 1;
        }
        
        exit;
    }
    $fids = DB::fetch_all('select * from %t where uid=%d order by lastupdate desc',array('forum_groupuser',$_G['uid']));
    foreach($fids as $f_k => $f_v){
        $fidname = DB::fetch_first('select a.name,b.* from %t a left join %t b on a.fid=b.fid where a.fid=%d ',array('forum_forum','forum_forumfield',$f_v['fid']));
        $fids[$f_k]['fidicon'] = $fidname['icon'] ? 'data/attachment/group/'.$fidname['icon'] : '';
        $fids[$f_k]['fidname'] = $fidname['name'];
        unset($fidname);
    }
    include template('aljol:aljol');
}

//����
//����
function ubbReplace($str) {
    //$str = str_replace ( ">", '<��', $str );
    //$str = str_replace ( ">", '>��', $str );
    //$str = str_replace ( "\n", '>��br/>��', $str );
    
    if($_GET['act']){
        $str = formatUrlsInText(str_replace('&amp;','&',$str));
    }
    
    $str = preg_replace ( "[\[em_([0-9]*)\]]", "<img src=\"source/plugin/aljol/static/img/face/$1.gif\" / class='Em'>", $str );

    return $str;
}
function formatUrlsInText($str){
    $re = '/(http|https|ftp)?(?::\/\/)?([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:\/~+#-]*[\w@?^=%&\/~+#-])?/';
    //$re = '/(http|https|ftp)?(?::\/\/)?(?:\w+)(?=\.)(?:[\w\.]+)(?:[\w&?+=\/]+)?/';
    $output = preg_replace_callback($re, "preg_replace_callback_php52", $str);
    return $output;
}
function preg_replace_callback_php52($matches) {
    
    if (!empty($matches[1]) && in_array($matches[1], array('http', 'https', 'ftp'))) {
        return sprintf('<a href="%s" target="_blank">%s</a>', $matches[0], $matches[0]);
    } else {
        return sprintf('<a href="%s%s" target="_blank">%s</a>', 'http://', $matches[0], $matches[0]);
    }
}
/*function formatUrlsInText($str){
    global $_G;
    $re = '/(http|https|ftp)?(?::\/\/)?([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:\/~+#-]*[\w@?^=%&\/~+#-])?/';
    //$re = '/(http|https|ftp)?(?::\/\/)?(?:\w+)(?=\.)(?:[\w\.]+)(?:[\w&?+=\/]+)?/';
    $output = preg_replace_callback($re, function($matches) {
        if (!empty($matches[1]) and in_array($matches[1], ['http', 'https', 'ftp'])) {
            return sprintf('<a href="%s">%s</a>', $matches[0], $matches[0]);
        } else {
            return sprintf('<a href="%s%s">%s</a>', 'http://', $matches[0], $matches[0]);
        }
    }, $str);
    return $output;
}*/
function SignReplace($str) {
    $str=str_replace("<br>","",$str);
    $str = str_replace ( "\n", '', $str );
    return strip_tags($str);
}
function ajaxPostCharSet($arr) {
    if(is_array($arr)){
        if (strtolower(CHARSET) == 'gbk') {
            foreach ($arr as $key => $val) {
                if(is_array($val)){
                    $pt_goods[$key] = ajaxPostCharSet($val);
                }else{
                    $pt_goods[$key] = diconv($val,'gbk','utf-8');
                }
            }
            return $pt_goods;
        }
        return $arr;
    } else {
        if (strtolower(CHARSET) == 'gbk') {
            return diconv($arr,'gbk','utf-8');
        }
        return $arr;
    }

}
function ajaxGetCharSet($arr) {
    if(is_array($arr)){
        if (strtolower(CHARSET) == 'gbk') {
            foreach ($arr as $key => $val) {
                if(is_array($val)){
                    $pt_goods[$key] = ajaxGetCharSet($val);
                }else{
                    $pt_goods[$key] = diconv($val,'utf-8','gbk');
                }

            }
            return $pt_goods;
        }
        return $arr;
    } else {
        if (strtolower(CHARSET) == 'gbk') {
            return diconv($arr,'utf-8','gbk');
        }
        return $arr;
    }
}
//������Ϣ����
function news($friendid,$chat) {
    global $_G;
    $talkrecord = DB::fetch_first('select * from %t where uid=%d and friendid=%d',array('aljol_news',$_G['uid'],$friendid));
    $friendrecord = DB::fetch_first('select * from %t where friendid=%d and uid=%d',array('aljol_news',$_G['uid'],$friendid));
    if(empty($talkrecord)) {
        DB::insert('aljol_news',array(
            'uid'=>$_G['uid'],
            'username'=>$_G['username'],
            'friendid'=>$friendid,
            'datetime'=>TIMESTAMP,
            'lastnews'=>$chat,
        ));
    }else {
        DB::update('aljol_news',array('datetime'=>TIMESTAMP,'lastnews'=>$chat),array('id'=>$talkrecord['id']));
    }
    if(empty($friendrecord)) {
        $firendname = DB::fetch_first('select * from %t where uid=%d',array('common_member',$friendid));
        DB::insert('aljol_news',array(
            'uid'=>$friendid,
            'username'=>$firendname['username'],
            'friendid'=>$_G['uid'],
            'datetime'=>TIMESTAMP,
            'lastnews'=>$chat,
        ));
    }else {
        DB::update('aljol_news',array('datetime'=>TIMESTAMP,'lastnews'=>$chat),array('id'=>$friendrecord['id']));
    }
}

//�Զ�ɾ��30��֮ǰ��ͼƬ
function DeletePicture_Auto() {
    $time = TIMESTAMP-2592000;
    $imglistcount = DB::result_first('select count(*) from %t where datetime<%d',array('aljol_picture',$time));
    if($imglistcount){
        $Limit = mt_rand(0,$imglistcount-1);
        $imglist = DB::fetch_all('select * from %t where datetime<%d limit %d,%d ',array('aljol_picture',$time,$Limit,10));
        foreach ($imglist as $tmp_key => $tmp_value) {
            @unlink($tmp_value['picture']);
            T::delete_oss($tmp_value['picture']);
            DB::delete('aljol_picture',array('pid'=>$tmp_value['pid']));
        }
    }
}
//��ʾ��Ʒ��Ϣ
function chathtml($g){
    global $_G;
    if($_G['mobile']){
        $chathtml = '<a href="plugin.php?id=aljbd&act=goodview&bid='.$g['bid'].'&gid='.$g['id'].'" onclick="window.location = \'plugin.php?id=aljbd&act=goodview&bid='.$g['bid'].'&gid='.$g['id'].'\'" style="width:100%;background: #ffffff;padding:10px 0px;">';
    }else{
        $chathtml = '<a href="plugin.php?id=aljbd&act=goodview&bid='.$g['bid'].'&gid='.$g['id'].'"  style="width:100%;background: #ffffff;padding:10px 0px;">';
    }

    $chathtml .= '<div style="float: left;width:20%;margin: 0px 1%">';
    $chathtml .= '<img src="'.$g['pic1'].'" style="width:100%;height:50px;object-fit: cover;" /></div>';
    $chathtml .= '<div style="float: right;width:78%;">'.$g['name'];
    $chathtml .= '<p style="color:#f42424;font-size: 12px">&#65509;<span style="font-size: 16px;">';
    if($g['collage_price']>0){
        $chathtml .= $g['collage_price'];
    }else{
        $chathtml .= $g['price1'];
    }
    if($g['price2']>0){
        $chathtml .= '-'.$g['price2'];
    }
    $chathtml .= '</span></p>';
    $chathtml .= '</div></a>';
    return $chathtml;
}
/**
 *  ��ȡ������Ʒ��Ϣ
 *
 *
 * @return void
 */
function ajaxGoods () {
    global $_G,$admin_status;
    $currpage=intval($_GET['page'])?intval($_GET['page']):1;
    $perpage=10;
    $start=($currpage-1)*$perpage;
    $goods = C::t('#aljbd#aljbd_goods')->fetch_all_by_uid_bid('',$_GET['bid'],$start,$perpage,'',$_GET['search_m']);
    
    $goods = dhtmlspecialchars($goods);
    if($goods){
        echo json_encode(aljhtx::ajaxPostCharSet($goods));
    }else{
        echo '1';
    }
    exit;
}
?>
