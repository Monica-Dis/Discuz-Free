$(function(){
	//document.documentElement.style.fontSize = document.documentElement.clientWidth / 10 + 'px';
	var face=false;
	var topheight= $('header').outerHeight();
	if(typeof topheight == 'undefined'){
		topheight= 0;
	}
	var footheight= $('footer').outerHeight();
	var allheight=$(window).height();
	var mainheight=allheight-topheight-footheight;
	
	//$('main').css("height",mainheight);
	//���鿪
	if($('.Eface').length>0) {
		var i,str,sum=' ';
		for(i=1;i<=30;i++){
			var str='<li onclick="addsmile('+
			"'[em_"+i+"]');"+
			'"><img src="source/plugin/aljol/static/img/face/'+i+'.gif"></li>';
			sum=sum+str;
		}
		$('.Eface').append(sum);
	}
	$('.emotion').click(function(){
		$('.layim-chat-tool').hide();
		$('.talk-foot').css('bottom','0px');
		
		if($('.Emain').is(":hidden")){
			
			$('.Emain').show();
			face=true;
			$(this).css("color","#f65d5b");
		}else{
			$('.Emain').hide();
			$(this).css("color","#5A5151");
			face=false;
			
		}
	});
	$('.Emain').click(function(){
		 $('.Emain').hide();
		 $('.emotion').css("color","#5A5151");
		 $('.talk-foot').css('bottom','0px')
		 face=false;
	});
	//�������

	//����main�߶�
	if($('main').hasClass('talk')) {
		$('.talk').scrollTop($('.talk')[0].scrollHeight);
	}
	//����ɾ��
	/*var time = 0;//��ʼ����ʼʱ??
	$(".friend").on('touchstart',function(e){
		time = setTimeout(function(){
		var id=$(this).attr('data-id');
		var fid = $(this).attr('id');
	    e.stopPropagation();
	        layer.open({
			    content: '\u662f\u5426\u5220\u9664\u8be5\u6d88\u606f'
			    ,btn: ['\u5220\u9664', '\u53d6\u6d88']
			    ,skin: 'footer'
			    ,yes: function(index){
			      deletenews(id,fid);
			    }//�Ƿ�ɾ������??
			  });
	    }, 5000);//�������ó�����Ӧʱ��
	});*/

	//����ɾ������
	//���ͼƬ���ɻõ�??

	$('.closeswiper,.swiper-container1').click(function(){
		$('.swiper-container1').hide();
	})
	//�õ�Ƭ��??
	var focus_status = false;
	var u = navigator.userAgent;  
	var is_iOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
	
	var bfscrolltop = document.body.scrollTop;//��ȡ�����̻���ǰ������������ֵĸ߶�

	/*$("#saytext").focus(function(){//�����input.inputframe�����ҵĵײ�������������򣬵�����ȡ����ʱ������
		var interval_num = 1;
		focus_status = true;
		$('.layim-chat-tool').hide();
		interval = setInterval(function(){//����һ����ʱ����ʱ�������������̵�������ʱ�����
			
			if(interval_num < 5){
				document.body.scrollTop = document.body.scrollHeight;//��ȡ�������������������ݸ߶ȸ���������������ָ߶�
			}else{
				clearInterval(interval);//�����ʱ
			}
			interval_num = interval_num+1;
		},300)
	}).blur(function(){//�趨�����ʧȥ����ʱ����
		clearInterval(interval);//�����ʱ
		setTimeout(function(){
			//document.body.scrollTop = bfscrolltop;//�������̻���ǰ��������������ָ߶����¸����ı��ĸ�
			document.body.scrollTop = document.documentElement.scrollTop = 0;
			//$('.talk').animate({scrollTop:bfscrolltop}, 500);
		},300);
	});*/
	var focus = 0;
    var top = 0;
	$("#saytext").focus(function(){//�����input.inputframe�����ҵĵײ�������������򣬵�����ȡ����ʱ������
		var interval_num = 1;
		focus_status = true;
		
		   $('.layim-chat-tool').hide();
		
		document.querySelector(".talk-foot").scrollIntoView(true)
		focus = 1;
        top = this.getBoundingClientRect().top;
        ios(this,top);
	}).blur(function(){//�趨�����ʧȥ����ʱ����
		
		setTimeout(function(){
			//document.body.scrollTop = bfscrolltop;//�������̻���ǰ��������������ָ߶����¸����ı��ĸ�
			document.body.scrollTop = document.documentElement.scrollTop = 0;
			//$('.talk').animate({scrollTop:bfscrolltop}, 500);
		},300);
		focus = 0;
	});
	//ios�л����뷨��ס�����������
    function ios(dom,top) {
            setTimeout(function(){
                var newTop=dom.getBoundingClientRect().top;
                if(newTop !== top){
                    document.querySelector(".talk-foot").scrollIntoView(true);
                    top=newTop;
                }
                if(focus===1){
                    ios(dom,top);
                }
            },200);
    }
	$(document).on('touchmove','.talk',function(e) {
		$('.layim-send').focus();
		$('.layim-chat-tool').hide();
		if(focus_status){
			focus_status = false;
			setTimeout(function(){
				
				document.body.scrollTop = document.documentElement.scrollTop = 0;
			},200);
		}
	});
	
	/*$("input").blur(function(){
		setTimeout(function(){
			document.body.scrollTop = document.documentElement.scrollTop = 0;
		},300);
	});*/
	
})
//��ȡ����

//ѹ��ͼƬ�ϴ�
function lrz_mobile(id,evt){
        file = evt.files[0];
        var filesize = file.size;
        var size = filesize/1024/1024;
        var type = file.name.split('.')[1];
        if (!file.type.match('image.*')) {
			  layer.open({
			    content: '\u56fe\u7247\u7c7b\u578b\u9519\u8bef'
			    ,skin: 'msg'
			    ,time: 2 //2����Զ��ر�
			  });//ͼƬ���ʹ���
        }
        lrz(file, {
            width:1200,
            before: function() {
                //console.log('start');
            },
            fail: function(err) {
                console.error(err);
            },
            always: function() {
                //console.log('end');
            },
            done: function (results) {
            	if(type == 'gif') {
            		if(size >2){
            			   layer.open({
							    content: '\u52a8\u6001\u56fe\u7247\u6587\u4ef6\u5927\u5c0f\u4e0d\u5f97\u8d85\u8fc7\u0032\u004d'
							    ,skin: 'msg'
							    ,time: 2 //2����Զ��ر�
							  });//��̬ͼƬ���ó�??2M
            		}else {
            			uploadgif(id);
            		}

            	}else {
            		var data={'picpath':results.base64,'friendid':id,'type':type};
					var url='plugin.php?id=aljol&act=upload';
	                $.post(url,data,function(res){
						if(res.code == 4) {
							alert('\u60a8\u5df2\u88ab\u7981\u6b62\u53d1\u8a00\uff01\uff01\uff01');
							return false;
						}
						if(res.code == 5) {
							alert('\u60a8\u5df2\u88ab\u7981\u6b62\u8bbf\u95ee\uff01\uff01\uff01');
							return false;
						}
						if(res.code == 200){
							if(ws_on){
								ws.send(JSON.stringify(res));
							}
							var talkarea=$('.talk ul');
							var datedom = '<li class="layim-chat-li layim-chat-mine">'+
									'<div class="layim-chat-user" data-uid='+res.uid+'>'+
										res.head+
									'<cite>'+res.username+'</cite>'+
									'</div>'+
									'<div class="upload_pic"><img src="'+res.src+'" class="jm" onclick="clickjm(this);"></div>'+
									'</li>';
							talkarea.append(datedom);
							addslide();
							$('.talk').animate({scrollTop:$('.talk')[0].scrollHeight}, 500);
						}
					},'json');
				}
            }})
    }
function uploadgif(id) {
	 $("#picturefile").ajaxSubmit({
            type: "post",
            dataType: "json",
            data:{'type':'gif','friendid':id},
            url: "plugin.php?id=aljol&act=upload",
            success: function (res) {
               if(res.code == 200) {
				if(ws_on){
					ws.send(JSON.stringify(res));
				}
           			var talkarea=$('.talk ul');
						var datedom = '<li class="layim-chat-li layim-chat-mine">'+
								'<div class="layim-chat-user" data-uid='+res.uid+'>'+
									res.head+
								'<cite>'+res.username+'</cite>'+
								'</div>'+
								'<div class="upload_pic"><img src="'+res.src+'" class="jm" onclick="clickjm(this);"></div>'+
								'</li>';
					talkarea.append(datedom);
					addslide();
					$('.talk').animate({scrollTop:$('.talk')[0].scrollHeight}, 500);
               }
            }
    });
}
//delete
function deletenews(id,fid) {
	var url ='plugin.php?id=aljol&act=deletenews';
	var data={'friendid':id};
	$.post(url,data,function(res){
		if(res.code == 200) {
		    layer.open({
			    content: '\u64cd\u4f5c\u6210\u529f'
			    ,skin: 'msg'
			    ,time: 2 //2����Զ��ر�
			    ,end: function(){
			    	$('#'+fid).remove();
			    }//�����ɹ�
			  });
		}
	},'json')
}
function loadmore(a, friendid, uid, loadchatid){
	
	
    
	$('.talk').scroll(function(){
		
		var c_height = $('#loadmore li:first').attr('date-id');
		if(isload){
			
			// �жϴ��ڵĹ������Ƿ�ӽ�ҳ��ײ�
			console.log($('.talk').scrollTop());
			if( $('.talk').scrollTop() <= 0 ) {
				isload = false;
				morepage = parseInt(morepage)+1;
				$(a).html('\u52a0\u8f7d\u4e2d\u002e\u002e\u002e\u002e\u002e\u002e');
				$.post('plugin.php?id=aljol&ajax=1&act=talk&friendid='+friendid+'&morepage='+morepage+'&chatid='+loadchatid, function(res){
					if(res.code == 200) {
						if(res.data == null || res.data == "null" || res.data == ''){
							$(a).html('\u6ca1\u6709\u66f4\u591a\u6570\u636e');
						}else{
							$.each(res.data, function(i, n){
								//alert(parseInt(uid)+'===='+parseInt(n.uid));
								if(parseInt(uid) != parseInt(n.uid)){
									if(n.type == 1){
										$('#loadmore').prepend('<li class="layim-chat-li w" date-id="'+n.id+'"><div style="font-size:12px;color:#999999;text-align:center;padding:20px;">'+n.datetime+'</div><div class="layim-chat-user" data-uid="'+n.uid+'">'+n.fidicon+'<cite>'+n.username+'</cite></div><div class="upload_pic"><img src="'+res.aljhb_img+'" width="180" onclick="show_red_packet(\''+n.id+'\',\'aljol\',\''+res.model+'\')"></div></li>');
									}else if(n.type == 3){
										$('#loadmore').prepend('<li class="layim-chat-li w" date-id="'+n.id+'"><div style="font-size:12px;color:#999999;text-align:center;padding:20px;">'+n.datetime+'</div><div class="layim-chat-user" data-uid="'+n.uid+'">'+n.fidicon+'<cite>'+n.username+'</cite></div><div class="layim-chat-text"><s class="s_voice s_voice_right" data-id="'+n.talk+'" onclick="playvoice(this,\''+n.talk+'\')"></s></div></li>');
									}else{
										if(n.talk != ''){
											var talkhtml = '<li class="layim-chat-li w" date-id="'+n.id+'"><div style="font-size:12px;color:#999999;text-align:center;padding:20px;">'+n.datetime+'</div><div class="layim-chat-user" data-uid="'+n.uid+'">'+n.fidicon+'<cite>'+n.username+'</cite></div>';
											if(n.type == 5){
												talkhtml += '<div class="upload_pic">';
											}else{
												talkhtml += '<div class="layim-chat-text yes-touch">';
											}

											talkhtml += n.talk+'</div></li>';
											$('#loadmore').prepend(talkhtml);
										}else{
											$('#loadmore').prepend('<li class="layim-chat-li w" date-id="'+n.id+'"><div style="font-size:12px;color:#999999;text-align:center;padding:20px;">'+n.datetime+'</div><div class="layim-chat-user" data-uid="'+n.uid+'">'+n.fidicon+'<cite>'+n.username+'</cite></div><div class="upload_pic"><img src="'+n.picture+'" class="jm" onclick="clickjm(this);"></div></li>');
										}
									}

								}else{
									if(n.type == 1){
										$('#loadmore').prepend('<li class="layim-chat-li layim-chat-mine" date-id="'+n.id+'"><div style="font-size:12px;color:#999999;text-align:center;padding:20px;">'+n.datetime+'</div><div class="layim-chat-user" data-uid="'+n.uid+'">'+n.fidicon+'<cite>'+n.username+'</cite></div><div class="upload_pic"><img src="'+res.aljhb_img+'" width="180" onclick="show_red_packet(\''+n.id+'\',\'aljol\',\''+res.model+'\')"></div></li>');
									}else if(n.type == 3){
										$('#loadmore').prepend('<li class="layim-chat-li layim-chat-mine" date-id="'+n.id+'"><div style="font-size:12px;color:#999999;text-align:center;padding:20px;">'+n.datetime+'</div><div class="layim-chat-user" data-uid="'+n.uid+'">'+n.fidicon+'<cite>'+n.username+'</cite></div><div class="layim-chat-text"><s class="s_voice s_voice_left" data-id="'+n.talk+'" onclick="playvoice(this,\''+n.talk+'\')"></s></div></li>');
									}else {
										if (n.talk != '') {
											var talkhtml = '<li class="layim-chat-li layim-chat-mine" date-id="' + n.id + '"><div style="font-size:12px;color:#999999;text-align:center;padding:20px;">' + n.datetime + '</div><div class="layim-chat-user" data-uid="'+n.uid+'">'+n.fidicon+'<cite>' + n.username + '</cite></div>';
											if(n.type == 5){
												talkhtml += '<div class="upload_pic">';
											}else{
												talkhtml += '<div class="layim-chat-text yes-touch">';
											}

											talkhtml += n.talk+'</div></li>';
											$('#loadmore').prepend(talkhtml);
										} else {
											$('#loadmore').prepend('<li class="layim-chat-li layim-chat-mine" date-id="' + n.id + '"><div style="font-size:12px;color:#999999;text-align:center;padding:20px;">' + n.datetime + '</div><div class="layim-chat-user" data-uid="'+n.uid+'">'+n.fidicon+'<cite>' + n.username + '</cite></div><div class="upload_pic"><img src="' + n.picture + '" class="jm" onclick="clickjm(this);"></div></li>');
										}
									}
								}
							});
							isload = true;
							$(a).html('\u52a0\u8f7d\u66f4\u591a');
							var t_a = $("li[date-id='" + c_height+ "']").offset();
							console.log('s'+t_a.top);
							$(".talk").animate({scrollTop: t_a.top-162},0);
							addslide();
						}
					}
				},'json');
			}
		}
	});
}
//ͷ�񵯴���ʾ�Ƿ����Ӻ���
$(document).on('click','.layim-chat-user',function(){
	var friendid = $(this).attr('data-uid');
	$.post('plugin.php?id=aljol&act=avatar_addfriend&friendid='+friendid, function(res){
    	if(res.code == 100){
            layer.open({
                type: 1
                ,title:res.username
                ,content: res.content
                ,style: 'position: absolute;width: 58%;height: auto;border: none;border-radius: 5px;top: 30%;left: 21%;'
                ,shadeClose:false
                ,btn: ['&#25105;&#30693;&#36947;&#20102;']
            });
		}
    },'json');
})
/*function avatar_addfriend(friendid) {
    $.post('plugin.php?id=aljol&act=avatar_addfriend&friendid='+friendid, function(res){
    	if(res.code == 100){
            layer.open({
                type: 1
                ,title:res.username
                ,content: res.content
                ,style: 'position: absolute;width: 58%;height: auto;border: none;border-radius: 5px;top: 30%;left: 21%;'
                ,shadeClose:false
                ,btn: ['&#25105;&#30693;&#36947;&#20102;']
            });
		}
    },'json');
}*/
//�任�б�
function switch_list(num,obj) {
	var header=$('#header-list li');
	var foot = $('#foot-list li');
	if(num == 1) {
		header.eq(0).addClass('active').siblings('li').removeClass('active');
		foot.eq(0).addClass('active').siblings('li').removeClass('active');
		$('#friend').hide();
		$('#information').show();
		$('#informationfid').hide();
	}
	if(num == 2) {
		header.eq(1).addClass('active').siblings('li').removeClass('active');
		foot.eq(1).addClass('active').siblings('li').removeClass('active');
		$('#information').hide();
		$('#friend').show();
        $('#informationfid').hide();
	}
    if(num == 3) {
        header.eq(2).addClass('active').siblings('li').removeClass('active');
        foot.eq(2).addClass('active').siblings('li').removeClass('active');
        $('#information').hide();
        $('#friend').hide();
        $('#informationfid').show();
    }
    closesearch();
}
//���ӱ���
function addsmile(smile){
	var old=$("#saytext").val();
	//$("#saytext").val(old+smile);
	insertContent($('#saytext'), old+smile)
	$('.layim-send').show();
	$('.layim-send').removeClass('layui-disabled');
}
//��������
function addtext(){
	var value = trim($('#saytext').html());
	if(value !='' && value!=null && value!='<br>') {
		$('.addpop').hide();
		$('.layim-send').show();
		$('.layim-send').removeClass('layui-disabled');
	}else{
		$('.addpop').show();
		$('.layim-send').hide();
		
		$('.layim-send').addClass('layui-disabled');
	}
}
function trim(s){
    return s.replace(/(^\s*)|(\s*$)/g, "");
}
//��ת
function friendtalk(id){
	$('#f_'+id).find('.order-numbers').remove();
	var w_url = 'plugin.php?id=aljol&act=talk&friendid='+id;
	if(typeof openWebViewurl != 'undefined'){
		openWebViewurl(w_url);
		return false;
	}
	location.href = w_url;
}

//������??
function send(id,obj){
	if($(obj).hasClass('layui-disabled')){
		return false;
	}else {
		var talk=$('#saytext').html();
		$('.hide_saytext').val(talk);
		
		$('.layim-send').addClass('layui-disabled');
		$('#saytext').html('');
		var url='plugin.php?id=aljol&act=chat&friendid='+id;
		
		$.ajax({
                type: "POST",
                dataType: "json",
                url: url ,
				data: $('#sendtalk').serialize(),
                success: function (res) {
                    if(res.code == 4) {
						alert('\u60a8\u5df2\u88ab\u7981\u6b62\u53d1\u8a00\uff01\uff01\uff01');
						return false;
					}
					if(res.code == 5) {
						alert('\u60a8\u5df2\u88ab\u7981\u6b62\u8bbf\u95ee\uff01\uff01\uff01');
						return false;
					}
					if(res.code == 6) {
						alert('\u62b1\u6b49\uff0c\u4f60\u53d1\u5e03\u7684\u5185\u5bb9\u5305\u542b\u4e0d\u826f\u4fe1\u606f\u65e0\u6cd5\u63d0\u4ea4');
						return false;
					}
					if(ws_on){
						ws.send(JSON.stringify(res));
					}
					var talkarea=$('.talk ul');
					if(res.code == 200) {
						var datedom = '<li class="layim-chat-li layim-chat-mine">'+
										'<div class="layim-chat-user" data-uid='+res.uid+'>'+
										res.head+
										'<cite>'+res.username+'</cite>'+
										'</div>'+
										'<div class="layim-chat-text yes-touch">'+res.chat+'</div>'+
										'</li>';
						$('#saytext').html('');
						$('.layim-send').addClass('layui-disabled');
						$('.addpop').show();
						$('.layim-send').hide();
						talkarea.append(datedom);
						$('.talk').animate({scrollTop:$('.talk')[0].scrollHeight}, 500);
						//$('html, body').animate({scrollTop:0}, 'slow');
					}
                },
                error : function() {
                    alert("\u5f02\u5e38\uff01");
                }
            });
		
	}
}

var lockReconnect = false;//�����ظ�����
var host = window.location.host == 'www.dzx30.com' ? 'addon.liangjianyun.com' : window.location.host;
var wsUrl = 'wss://'+host+'/wss?token='+token;

function createWebSocket(url) {
    try {
        ws = new WebSocket(url);
        initEventHandle();
    } catch (e) {
        reconnect(url);
    }
}

function initEventHandle() {
    ws.onclose = function () {
        reconnect(wsUrl);
    };
    ws.onerror = function () {
        reconnect(wsUrl);
    };
    ws.onopen = function () {
        //�����������
		heartCheck.reset().start();
		console.log("connected successfully");
    };
    ws.onmessage = function (e) {
        //�����ȡ����Ϣ�������������
        //�õ��κ���Ϣ��˵����ǰ������������
		heartCheck.reset().start();
		console.log("123")
		var message = e.data;
        if(message){
			res = JSON.parse(message);
			console.log(res);
	
			var talkarea=$('.talk ul');
			var datedom = '<li class="layim-chat-li w"  date-id="'+res.id+'">'+
			'<div style="font-size:12px;color:#999999;text-align:center;padding:20px;">'+res.datetime+'</div>'+
			'<div class="layim-chat-user" data-uid='+res.uid+'>'+
			res.head+
			'<cite>'+res.username+'</cite>'+
			'</div>';
			if(res.type == 1){
				datedom += '<div class="upload_pic">';
				datedom += '<img src="'+res.aljhb_img+'" width="180" onclick="show_red_packet(\''+res.id+'\',\'aljol\',\''+res.model+'\')">';
			} else if(res.type == 3){
				
				if(typeof wx != 'undefined' ){
					var time = parseInt(40+parseInt(res.time)*2/1000);
					datedom += '<div class="layim-chat-text" style="width:'+time+'px">';
					datedom += '<s class="s_voice s_voice_right" data-id="'+res.chat+'"></s>';
					var serverId=res.chat;
					wx.downloadVoice({
						serverId: serverId, // ��Ҫ���ص���Ƶ�ķ�������ID����uploadVoice�ӿڻ��
						isShowProgressTips: 0, // Ĭ��??1����ʾ������??
						success: function (res) {
							localStorage.setItem(serverId, res.localId);
						
						wx.playVoice({
						localId: localStorage.getItem(localStorage.getItem(serverId)) // ��Ҫ���ŵ���Ƶ�ı���ID����stopRecord�ӿڻ��
						});
						}
					});
				}else{
					var time = parseInt(40+parseInt(res.time)*2/1000);
					datedom += '<div class="layim-chat-text">';
					datedom += '[\u8BED\u97F3\u6D88\u606F]';
				}
			
			}else {
				if (res.chat != null && res.chat != '') {
					if(res.type == 5){
						datedom += '<div class="upload_pic">';
						if(mobile == '_pc'){
							datedom += res.chat_pc;
						}else{
							datedom += res.chat_mobile;
						}
					}else{
						datedom += '<div class="layim-chat-text yes-touch">';
						datedom += res.chat;
					}
					
					
				}else {
					datedom += '<div class="upload_pic">';
					datedom += '<img src="' + res.picture + '" class="jm" onclick="clickjm(this);">';
				}
			}
	datedom+='</div>'+
			'</li>';
	talkarea.append(datedom);
	addslide();
	$('.talk').animate({scrollTop:$('.talk')[0].scrollHeight}, 500);
        }
    }
}

function reconnect(url) {
    if(lockReconnect) return;
    lockReconnect = true;
    //û�����ϻ�һֱ�����������ӳٱ����������
    setTimeout(function () {
        createWebSocket(url);
        lockReconnect = false;
    }, 2000);
}

//�������
var heartCheck = {
    timeout: 290000,//60��
    timeoutObj: null,
    serverTimeoutObj: null,
    reset: function(){
        clearTimeout(this.timeoutObj);
        clearTimeout(this.serverTimeoutObj);
        return this;
    },
    start: function(){
        var self = this;
        this.timeoutObj = setTimeout(function(){
            //���﷢��һ������������յ��󣬷���һ��������Ϣ��
            //onmessage�õ����ص�������˵����������
            ws.send("");
            self.serverTimeoutObj = setTimeout(function(){//�������һ��ʱ�仹û���ã�˵����������Ͽ���
                ws.close();//���onclose��ִ��reconnect������ִ��ws.close()������.���ֱ��ִ��reconnect �ᴥ��onclose������������
            }, self.timeout);
        }, this.timeout);
    }
}


/*
// websocket����
var websocket_connected_count = 0;
var onclose_connected_count = 0;
function newWebSocket(){
    // �жϵ�ǰ�����Ƿ�֧��websocket
    if(window.WebSocket){
		var host = window.location.host == 'www.dzx30.com' ? 'addon.liangjianyun.com' : window.location.host;
		var ws_url ='wss://'+host+'/wss?token='+token;
		ws = new WebSocket(ws_url);
    }else{
        console.log("not support websocket");
    }
 
    // ���ӳɹ������Ļص�����
    ws.onopen = function(e){
        heartCheck.reset().start();   // �ɹ��������Ӻ������������
        console.log("connected successfully")
    }
    // ���ӷ����������Ӵ���ʱ��������Է������ӣ�����5�Σ�
    ws.onerror = function() {
        console.log("onerror���ӷ�������")
        websocket_connected_count++;
        if(websocket_connected_count <= 5){
            newWebSocket()
        }
    }
    // ���ܵ���Ϣ�Ļص�����
    ws.onmessage = function(e){
        console.log("���ܵ���Ϣ��")
        heartCheck.reset().start();    // �����ȡ����Ϣ��˵�������������ģ������������
        var message = e.data;
        if(message){
			res = JSON.parse(message);
			console.log(res);
	
			var talkarea=$('.talk ul');
			var datedom = '<li class="layim-chat-li w"  date-id="'+res.id+'">'+
			'<div style="font-size:12px;color:#999999;text-align:center;padding:20px;">'+res.datetime+'</div>'+
			'<div class="layim-chat-user" data-uid='+res.uid+'>'+
			res.head+
			'<cite>'+res.username+'</cite>'+
			'</div>';
			if(res.type == 1){
				datedom += '<div class="upload_pic">';
				datedom += '<img src="'+res.aljhb_img+'" width="180" onclick="show_red_packet(\''+res.id+'\',\'aljol\',\''+res.model+'\')">';
			} else if(res.type == 3){
				
				if(typeof wx != 'undefined' ){
					var time = parseInt(40+parseInt(res.time)*2/1000);
					datedom += '<div class="layim-chat-text" style="width:'+time+'px">';
					datedom += '<s class="s_voice s_voice_right" data-id="'+res.chat+'"></s>';
					var serverId=res.chat;
					wx.downloadVoice({
						serverId: serverId, // ��Ҫ���ص���Ƶ�ķ�������ID����uploadVoice�ӿڻ��
						isShowProgressTips: 0, // Ĭ��??1����ʾ������??
						success: function (res) {
							localStorage.setItem(serverId, res.localId);
						
						wx.playVoice({
						localId: localStorage.getItem(localStorage.getItem(serverId)) // ��Ҫ���ŵ���Ƶ�ı���ID����stopRecord�ӿڻ��
						});
						}
					});
				}else{
					var time = parseInt(40+parseInt(res.time)*2/1000);
					datedom += '<div class="layim-chat-text">';
					datedom += '[\u8BED\u97F3\u6D88\u606F]';
				}
			
			}else {
				if (res.chat != null && res.chat != '') {
					if(res.type == 5){
						datedom += '<div class="upload_pic">';
						if(mobile == '_pc'){
							datedom += res.chat_pc;
						}else{
							datedom += res.chat_mobile;
						}
					}else{
						datedom += '<div class="layim-chat-text">';
						datedom += res.chat;
					}
					
					
				}else {
					datedom += '<div class="upload_pic">';
					datedom += '<img src="' + res.picture + '" class="jm" onclick="clickjm(this);">';
				}
			}
	datedom+='</div>'+
			'</li>';
	talkarea.append(datedom);
	addslide();
	$('.talk').animate({scrollTop:$('.talk')[0].scrollHeight}, 500);
        }
    }
 
    // ���ܵ�����˹ر�����ʱ�Ļص�����
    ws.onclose = function(){
        console.log("onclose");
    }
    // ���������¼��������ڹر�ʱ�������Ͽ�websocket���ӣ���ֹ����û�Ͽ��͹رմ��ڣ�server�˱���
    window.onbeforeunload = function(){
        ws.close();
    }
 
   //�������
var heartCheck = {
    timeout: 290000,//60��
    timeoutObj: null,
    serverTimeoutObj: null,
    reset: function(){
        clearTimeout(this.timeoutObj);
        clearTimeout(this.serverTimeoutObj);
        return this;
    },
    start: function(){
        var self = this;
        this.timeoutObj = setTimeout(function(){
            //���﷢��һ������������յ��󣬷���һ��������Ϣ��
            //onmessage�õ����ص�������˵����������
            ws.send("ping");
            self.serverTimeoutObj = setTimeout(function(){//�������һ��ʱ�仹û���ã�˵����������Ͽ���
                ws.close();//���onclose��ִ��reconnect������ִ��ws.close()������.���ֱ��ִ��reconnect �ᴥ��onclose������������
            }, self.timeout);
        }, this.timeout);
    }
}
	
}

function open_ws(){
	var host = window.location.host == 'www.dzx30.com' ? 'addon.liangjianyun.com' : window.location.host;
	ws = new WebSocket('wss://'+host+'/wss?uid='+uid+'&friendid='+friendid); //����ip��ַΪʵ��swoole�����ַ�����޸�
ws.onopen = function() {
	//ws.send(uid);
	console.log('connect start��');
	ws.onmessage = function(e) {
		res = JSON.parse(e.data);
		console.log(res);

		var talkarea=$('.talk ul');
		var datedom = '<li class="layim-chat-li w"  date-id="'+res.id+'">'+
		'<div style="font-size:12px;color:#999999;text-align:center;padding:20px;">'+res.datetime+'</div>'+
		'<div class="layim-chat-user" data-uid='+res.uid+'>'+
		res.head+
		'<cite>'+res.username+'</cite>'+
		'</div>';
		if(res.type == 1){
			datedom += '<div class="upload_pic">';
			datedom += '<img src="'+res.aljhb_img+'" width="180" onclick="show_red_packet(\''+res.id+'\',\'aljol\',\''+res.model+'\')">';
		} else if(res.type == 3){
			var time = parseInt(40+parseInt(res.time)*2/1000);
			datedom += '<div class="layim-chat-text" style="width:'+time+'px">';
			datedom += '<s class="s_voice s_voice_right" data-id="'+res.chat+'"></s>';
			var serverId=res.chat;
			if(typeof wx != 'undefined' ){
				wx.downloadVoice({
					serverId: serverId, // ��Ҫ���ص���Ƶ�ķ�������ID����uploadVoice�ӿڻ��
					isShowProgressTips: 0, // Ĭ��??1����ʾ������??
					success: function (res) {
						localStorage.setItem(serverId, res.localId);
					
					wx.playVoice({
					localId: localStorage.getItem(localStorage.getItem(serverId)) // ��Ҫ���ŵ���Ƶ�ı���ID����stopRecord�ӿڻ��
					});
					}
				});
			}
		
		}else {
			if (res.chat != null && res.chat != '') {
				if(res.type == 5){
					datedom += '<div class="upload_pic">';
				}else{
					datedom += '<div class="layim-chat-text">';
				}
				datedom += res.chat;
			}else {
				datedom += '<div class="upload_pic">';
				datedom += '<img src="' + res.picture + '" class="jm" onclick="clickjm(this);">';
			}
		}
datedom+='</div>'+
		'</li>';
talkarea.append(datedom);
addslide();
$('.talk').animate({scrollTop:$('.talk')[0].scrollHeight}, 500);
		
	}
	ws.onclose = function() {
		open_ws();
	}
}
}*/
if (ws_on) {
	//newWebSocket();
	createWebSocket(wsUrl);
}
//���칦��
function chat(id){
	if (ws_on) {	
		
	} else {
		if($('.layim-chat-li').length>30) {
			//$(".layim-chat-li").eq(0).remove();
		}
		var last_id = $('#loadmore').find('li.w').last().attr('date-id');
	
		if (typeof(last_id) == "undefined"){
			last_id = 1000000000000000;
		}
			var url='plugin.php?id=aljol&act=friendchat&friendid='+id+'&chatid='+last_id;
		$.post(url,function(res){
			var talkarea=$('.talk ul');
			if(res.code == 200) {
				var datedom = '<li class="layim-chat-li w"  date-id="'+res.id+'">'+
								'<div style="font-size:12px;color:#999999;text-align:center;padding:20px;">'+res.datetime+'</div>'+
								'<div class="layim-chat-user" data-uid='+res.uid+'>'+
								res.head+
								'<cite>'+res.username+'</cite>'+
								'</div>';
								if(res.type == 1){
									datedom += '<div class="upload_pic">';
									datedom += '<img src="'+res.aljhb_img+'" width="180" onclick="show_red_packet(\''+res.id+'\',\'aljol\',\''+res.model+'\')">';
								} else if(res.type == 3){
									var time = parseInt(40+parseInt(res.time)*2/1000);
									datedom += '<div class="layim-chat-text" style="width:'+time+'px">';
									datedom += '<s class="s_voice s_voice_right" data-id="'+res.chat+'"></s>';
									var serverId=res.chat;
									wx.downloadVoice({
										serverId: serverId, // ��Ҫ���ص���Ƶ�ķ�������ID����uploadVoice�ӿڻ��
										isShowProgressTips: 0, // Ĭ��??1����ʾ������??
										success: function (res) {
											localStorage.setItem(serverId, res.localId);
	
										wx.playVoice({
										localId: localStorage.getItem(localStorage.getItem(serverId)) // ��Ҫ���ŵ���Ƶ�ı���ID����stopRecord�ӿڻ��
										});
										}
									});
								}else {
									if (res.chat != null && res.chat != '') {
										if(res.type == 5){
											datedom += '<div class="upload_pic">';
										}else{
											datedom += '<div class="layim-chat-text yes-touch">';
										}
										datedom += res.chat;
									}else {
										datedom += '<div class="upload_pic">';
										datedom += '<img src="' + res.picture + '" class="jm" onclick="clickjm(this);">';
									}
								}
						datedom+='</div>'+
								'</li>';
				talkarea.append(datedom);
				addslide();
				$('.talk').animate({scrollTop:$('.talk')[0].scrollHeight}, 500);
			}
		},'json');
	}
	
}
//��Ϣ���ѹ���
function news() {
	var url='plugin.php?id=aljol&act=news';
	$.post(url,function(res){
		if(res!=null && res!='') {
			$.each(res,function(k,d){
				var fid=$("#f_"+d.uid);
				var time=parseInt(fid.attr('data-time'));
				if(fid.length == 1) {
					if(d.datetime>time) {
						fid.remove();

						fid.attr('data-time',d.datetime);
                        var datadom =
                            '<div class="friend" onclick="friendtalk('+d.uid+');" id="f_'+d.uid+'" data-time="'+d.datetime+'">'+
                            '<div class="friend-head">'+
                            d.head+
                            '</div>'+
                            '<div class="friend-name">'+
                            '<div class="friend-name-left">'+
                            '<p>'+d.username+'</p>'+
                            '<span>'+d.lastnews+'</span>'+
                            '</div>'+
                            '<div class="friend-name-right">'+
							'<p>'+d.time+'</p>';

							if(d.newscount>0){
								datadom +='<i class="order-numbers">'+d.newscount+'</i>';
							}
                            datadom += '</div>'+
                            '</div>'+
                            '</div>';
                        $('#information').prepend(datadom);
					}else{
						if(d.newscount==0){
							fid.find('i').remove();
						}
					}
				}else{
                    var datadom =
                        '<div class="friend" onclick="friendtalk('+d.uid+');" id="f_'+d.uid+'" data-time="'+d.datetime+'">'+
                        '<div class="friend-head">'+
                        d.head+
                        '</div>'+
                        '<div class="friend-name">'+
                        '<div class="friend-name-left">'+
                        '<p>'+d.username+'</p>'+
                        '<span>'+d.lastnews+'</span>'+
                        '</div>'+
                        '<div class="friend-name-right">'+
                        '<p>'+d.time+'</p>';

                    if(d.newscount>0){
                        datadom +='<i class="order-numbers">'+d.newscount+'</i>';
                    }
                    datadom += '</div>'+
                        '</div>'+
                        '</div>';
					$('#information').prepend(datadom);
				}

			});
		}
	},'json');
	setTimeout(function(){
        news();
    },2000);
}
//����ͼƬ
function addslide() {
	$('.swiper-wrapper').html('');
	var sum = 0;
	$('.jm').each(function(){
		var src = $(this).attr('src');
		$(this).attr('data-id',sum);
		sum=sum+1;
		var datadom='';
		datadom='<div class="swiper-slide" >'+
			'<div class="swiper-zoom-container">'+
				'<img src="'+src+'">'+
			'</div>'+
		'</div>';

		$('.swiper-wrapper').append(datadom);
	});
}
function clickjm(obj){
	var index = $(obj).attr('data-id');
	var swiper = new Swiper('.swiper-container1', {
			zoom: true,
			zoomMax :2,
			initialSlide :index,
			observer:true,
		});
	$('.swiper-container1').show();
}
//���Ӻ���
function opensearch(){
	$('.search').show();
	$('.topBar').hide();
	//$('#friend').hide();
}
function closesearch(){
	$('.search').hide();
    $('.topBar').show();
    //$('#friend').show();
	$('#user').html('');
	$('#searchuser').val('');
}
function search() {
	var value = $('#searchuser').val();
	if(value!=null && value!='') {
		$('#user').html('');
		var url ='plugin.php?id=aljol&act=search';
		var data={'searchkey':value};
		$.post(url,data,function(res){
			if(res.code == 200) {
				if(res.myfriend == 1) {
					var datadom = '<li onclick="friendtalk('+res.uid+');">';
				}else{
					var datadom ='<li>';
				}
				datadom+='<div onclick="friendtalk('+res.uid+');">'+res.head+
				'</div><span onclick="friendtalk('+res.uid+');" >'+
				res.username+
				'</span><p onclick="friendtalk('+res.uid+');">'+
				res.sightml+
				'</p>';
				if(res.myfriend == 3) {
					datadom+='<button class="layui-btn" onclick="addfriend('+res.uid+')">\u52a0\u4e3a\u597d\u53cb</button>';
				}//��Ϊ����
				if(res.myfriend == 2) {
					datadom+='<button class="layui-btn">\u7b49\u5f85\u9a8c\u8bc1</button>';
				}//�ȴ���֤
				datadom+='</li>';
				$('#user').append(datadom);
			}
			if(res.code == 400){
				layer.open({
				    content: '\u8be5\u7528\u6237\u4e0d\u5b58\u5728'
				    ,skin: 'msg'
				    ,time: 2 //2����Զ��ر�
				 });//���û�������
			}
			if(res.code == 500) {
				layer.open({
				    content: '\u65e0\u6cd5\u641c\u7d22\u81ea\u5df1'
				    ,skin: 'msg'
				    ,time: 2 //2����Զ��ر�
				 });//�޷������Լ�
			}
		},'json');
	}else{
		layer.open({
		    content: '\u4e0d\u80fd\u4e3a\u7a7a'
		    ,skin: 'msg'
		    ,time: 2 //2����Զ��ر�
		 });//����Ϊ��
	}
}
function addfriend(id){
	console.log(id);
	var friendid=id;
	var url='plugin.php?id=aljol&act=addfriend';
	var date={'friendid':friendid};
	$.post(url,date,function(res){
		if(res.code == 200) {
			layer.open({
			    content: '\u8bf7\u6c42\u5df2\u53d1\u9001'
			    ,skin: 'msg'
			    ,time: 2 //2����Զ��ر�
			 });//�����ѷ�??
		}else{
			layer.open({
			    content: '\u8be5\u7528\u6237\u5df2\u7ecf\u662f\u4f60\u7684\u597d\u53cb'
			    ,skin: 'msg'
			    ,time: 2 //2����Զ��ر�
			 });//���û��Ѿ�����ĺ���
		}
		$('#user').html('');
	},'json');
}
function requestfriend() {
	location.href='plugin.php?id=aljol&act=requestfriendlist';
}
function sendKeyDown(id){
	if (event.keyCode == 13) {
		send(id, $('.layim-send'));
	}
}
function yesfriend(fid,stateid,obj){
		var url='plugin.php?id=aljol&act=yesandno';
		var data={'friendid':fid,'stateid':stateid};
		$.post(url,data,function(res){
			if(res.code == 200) {
				layer.open({
				   content: '\u5df2\u540c\u610f\u52a0\u4e3a\u597d\u53cb'
				   ,skin: 'msg'
				   ,time: 2 //2����Զ��ر�
				});//��ͬ���Ϊ��??
				$(obj).parent().parent().parent().remove();
			}else{
				layer.open({
				   content: '\u62d2\u7edd\u6210\u529f'
				   ,skin: 'msg'
				   ,time: 2 //2����Զ��ر�
				});//�ܾ��ɹ�
				$(obj).parent().parent().parent().remove();
			}

		},'json');
	}
