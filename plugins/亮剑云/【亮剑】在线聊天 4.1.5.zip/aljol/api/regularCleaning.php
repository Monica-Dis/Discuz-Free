<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$cycle = DB::result_first('select svalue from %t where skey=%s ', array('aljhtx_setting', 'cycle'));
if($cycle['svalue']){
    $cycle_timestamp = $cycle*86400;
    DB::query('delete from %t where datetime<%d', array('aljol_talk', TIMESTAMP-$cycle_timestamp));
    $imglist = DB::fetch_all('select * from %t where datetime<%d', array('aljol_picture', TIMESTAMP-$cycle_timestamp));
    foreach($imglist as $img){
        if($img['picture']){
            @unlink($img['picture']);
        }
    }
    DB::query('delete from %t where datetime<%d', array('aljol_picture', TIMESTAMP-$cycle_timestamp));
}
?>