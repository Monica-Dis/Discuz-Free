<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

//�Զ�ɾ��30��֮ǰ��ͼƬ
function DeletePicture_Auto() {
    $time = TIMESTAMP-2592000;
    $imglistcount = DB::result_first('select count(*) from %t where datetime<%d',array('aljol_picture',$time));
    if($imglistcount){
        $Limit = mt_rand(0,$imglistcount-1);
        $imglist = DB::fetch_all('select * from %t where datetime<%d limit %d,%d ',array('aljol_picture',$time,$Limit,10));
        foreach ($imglist as $tmp_key => $tmp_value) {
            @unlink($tmp_value['picture']);
            T::delete_oss($tmp_value['picture']);
            DB::delete('aljol_picture',array('pid'=>$tmp_value['pid']));
        }
    }
}
DeletePicture_Auto();
?>