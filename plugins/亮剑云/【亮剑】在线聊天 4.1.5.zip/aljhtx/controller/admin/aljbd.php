<?php

/**
 * Controller�Ķ�ά�봦��ģ��
 *
 * @author yuxinqi<yuxinqi@vip.qq.com>
 * @version 1.0
 * @link http://docs.liangjianyun.com/
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class AljbdAction{
    public $page;

    public function __construct() {
        global $requestPage;
        $this->page = $requestPage;

    }

    public function order(){
        $this->page->display();
    }
    /**
     * �����б�
     *
     *
     * @return void
     */
    public function wirteOffList () {
        $this->aljbdParameter();
        $this->page->assign('navtitle', lang("plugin/aljhtx","aljbd_php_2"));
        $this->page->display();
    }
    public function wechat(){
        if($this->page->get->render == 'yes'){
            $per = 20;
            $page = $this->page->get->page>0 ? $this->page->get->page :1;
            $start = ($page - 1) * $per;
            $logList = DB::fetch_all('select * from %t order by dateline desc limit %d, %d', array('aljhtx_qrcode_wechat', $start, $per));
            $count = DB::result_first('select count(*) from %t order by dateline desc', array('aljhtx_qrcode_wechat'));
            foreach($logList as $k => $v){
                $logList[$k]['dateline'] = dgmdate($v['dateline'], 'u');
                if($logList[$k]['type']){
                    $logList[$k]['qrcode'] = 'source/plugin/aljhtx/static/img/qrcode/wechat/'.$logList[$k]['qrcode'];
                }else{
                    $logList[$k]['qrcode'] = 'source/plugin/aljhtx/static/img/qrcode/wechat/tmp/'.$logList[$k]['qrcode'];
                }
            }
            T::responseJson(array(
                'code' => 0,
                'msg' => "",
                'count' => $count,
                'data' => $logList
            ));
        }
        $this->page->display();
    }

    public function wechat_add(){
        if(submitcheck('formhash')){
            $appid = $this->page->config->aljwsq->appid;
            $appsecret = $this->page->config->aljwsq->appsecret;
            if($appid && $appsecret){
                require_once DISCUZ_ROOT . './source/plugin/aljwsq/mapp_wechatclient.lib.class.php';
                $wechat_client = new WeChatClient($appid, $appsecret);
                $access_token = $wechat_client -> getAccessToken();
                $insertid = DB::result_first('select scene_id from %t where type = %d order by id desc',array('aljhtx_qrcode_wechat',$_GET['type']));
                $insertid = intval($insertid)+1;
                $scene_id = array(
                    'scene' => array('scene_id' => $insertid)
                );

                if(empty($_GET['type'])){
                    $postdatas = array(
                        'expire_seconds' => '2592000',
                        'action_name' => 'QR_SCENE',
                        'action_info' => $scene_id
                    );
                }else{
                    $postdatas = array(
                        'action_name' => 'QR_LIMIT_SCENE',
                        'action_info' => $scene_id
                    );
                }
                $postdatas = json_encode($postdatas);
                $qrcode = https_request('https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$access_token, $postdatas);

                $qrcode = json_decode($qrcode,true);
                if(empty($_GET['type'])){
                    $filepath = 'source/plugin/aljhtx/static/img/qrcode/wechat/tmp/'.$insertid;
                }else{
                    $filepath = 'source/plugin/aljhtx/static/img/qrcode/wechat/'.$insertid;
                }
                $returndata = downloadImage('https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.$qrcode['ticket'],$filepath);
                DB::insert('aljhtx_qrcode_wechat', array(
                    'scene_id' => $insertid,
                    'qrcode' => $returndata['filename'],
                    'ticket' => $returndata['ticket'],
                    'type' => $_GET['type'],
                    'mykeyword' => $_GET['mykeyword'],
                    'dateline' => TIMESTAMP,
                ));
            }else{
                $this->page->tips('".lang("plugin/aljhtx","aljbd_php_1")."');
            }
            $this->page->tips();
        }else{
            $this->page->display();
        }
    }

    public function common(){
        if($this->page->get->render == 'yes'){
            $per = 20;
            $page = $this->page->get->page>0 ? $this->page->get->page :1;
            $start = ($page - 1) * $per;
            $logList = DB::fetch_all('select * from %t order by dateline desc limit %d, %d', array('aljhtx_qrcode_common', $start, $per));
            $count = DB::result_first('select count(*) from %t order by dateline desc', array('aljhtx_qrcode_common'));
            foreach($logList as $k => $v){
                $logList[$k]['dateline'] = dgmdate($v['dateline'], 'u');
                $logList[$k]['qrcode'] = 'source/plugin/aljhtx/static/img/qrcode/common/'.$logList[$k]['qrcode'];
            }
            T::responseJson(array(
                'code' => 0,
                'msg' => "",
                'count' => $count,
                'data' => $logList
            ));
        }
        $this->page->display();
    }

    public function common_delete(){
        DB::delete('aljhtx_qrcode_common', array('id' => $_GET['qid']));
        T::responseJson();
    }

    public function common_link(){
        if($_GET['qid']){
            DB::query('update %t set num = num+1 where id=%d',array('aljhtx_qrcode_common',$_GET['qid']));
            $qrcode = DB::fetch_first('select * from %t where id=%d', array('aljhtx_qrcode_common', $_GET['qid']));
            header('Location: '.$qrcode['url']);
            exit;
        }
    }

    public function common_download(){
        $qrcode = DB::fetch_first('select * from %t where id=%d', array('aljhtx_qrcode_common', $_GET['qid']));
        $filename = 'source/plugin/aljhtx/static/img/qrcode/common/'.$qrcode['qrcode'];
        header('Content-Disposition:attachment;filename=' . basename($filename));
        header('Content-Length:' . filesize($filename));
        readfile($filename);
        exit();
    }


    public function common_add(){
        if(submitcheck('formhash')){
            require_once DISCUZ_ROOT.'source/plugin/aljhtx/class/qrcode.class.php';
            $file = dgmdate(TIMESTAMP, 'YmdHis').random(18).'.jpg';
            $insertid = DB::insert('aljhtx_qrcode_common', array(
                'url' => $_GET['url'],
                'qrcode' => $file,
                'dateline' => TIMESTAMP,
            ), true);
            QRcode::png($this->page->global->siteurl.'plugin.php?id=aljhtx&c=qrcode&a=common_link&ajax=yes&qid='.$insertid, 'source/plugin/aljhtx/static/img/qrcode/common/'.$file, QR_MODE_STRUCTURE, 8);
            $this->page->tips();
        }else{
            $this->page->display();
        }
    }



    public function miniprogram(){
        if($this->page->get->render == 'yes'){
            $per = 20;
            $page = $this->page->get->page>0 ? $this->page->get->page :1;
            $start = ($page - 1) * $per;
            $logList = DB::fetch_all('select * from %t order by dateline desc limit %d, %d', array('aljhtx_qrcode_miniprogram', $start, $per));
            $count = DB::result_first('select count(*) from %t order by dateline desc', array('aljhtx_qrcode_miniprogram'));
            foreach($logList as $k => $v){
                $logList[$k]['dateline'] = dgmdate($v['dateline'], 'u');
                $logList[$k]['qrcode'] = 'source/plugin/aljhtx/static/img/qrcode/miniprogram/'.$v['qrcode'];;
            }
            T::responseJson(array(
                'code' => 0,
                'msg' => "",
                'count' => $count,
                'data' => $logList
            ));
        }
        $this->page->display();
    }

    public function miniprogram_delete(){
        DB::delete('aljhtx_qrcode_miniprogram', array('id' => $_GET['qid']));
        T::responseJson();
    }

    public function go(){
        if($_GET['qid']){
            DB::query('update %t set num = num+1 where id=%d',array('aljhtx_qrcode_miniprogram',$_GET['qid']));
            $qrcode = DB::fetch_first('select * from %t where id=%d', array('aljhtx_qrcode_miniprogram', $_GET['qid']));
            header('Location: '.$qrcode['url']);
        }
    }

    public function miniprogram_download(){
        $qrcode = DB::fetch_first('select * from %t where id=%d', array('aljhtx_qrcode_miniprogram', $_GET['qid']));
        $filename = 'source/plugin/aljhtx/static/img/qrcode/miniprogram/'.$qrcode['qrcode'];
        header('Content-Disposition:attachment;filename=' . basename($filename));
        header('Content-Length:' . filesize($filename));
        readfile($filename);
        exit();
    }


    public function miniprogram_add(){
        if(submitcheck('formhash')){
            $filepath = 'source/plugin/aljhtx/static/img/qrcode/miniprogram/'.TIMESTAMP;

            $insertid = DB::insert('aljhtx_qrcode_miniprogram', array(
                'url' => $_GET['url'],
                'dateline' => TIMESTAMP,
            ), true);

            $fileurl = $this->page->global->siteurl.'source/plugin/aljwx/qrcode.php?url='.urlencode('plugin.php?id=aljhtx&c=qrcode&a=go&ajax=yes&qid='.$insertid);
            $returndata = downloadImage($fileurl,$filepath);
            DB::update('aljhtx_qrcode_miniprogram', array('qrcode' => $returndata['filename']), array('id' => $insertid));
            $this->page->tips();
        }else{
            $this->page->display();
        }
    }
    /**
     * Ʒ���̼ҹ�������ע��
     *
     *
     * @return void
     */
    public function aljbdParameter(){
        global $Html5Plusapp,$immersed;
        $settings=C::t('#aljbd#aljbd_setting')->range();
        $mobile_common_footernav = explode ("\n", str_replace ("\r", "", $settings['mobile_common_footernav']['value']));
        foreach($mobile_common_footernav as $key=>$value){
            $arr=explode('|',$value);
            $mobile_common_footernav_arr[]=$arr;
        }
        $price_unit = '&#65509;';
        $this->page->assign('price_unit', $price_unit,true);
        $this->page->assign('pluginid', 'aljbd');
        $this->page->assign('Html5Plusapp', $Html5Plusapp);
        $this->page->assign('immersed', $immersed);
        $this->page->assign('settings', $settings);
        $this->page->assign('mobile_common_footernav_arr', $mobile_common_footernav_arr,true);
        $this->page->assign('common_template_pluginid', 'aljbd');
        $this->page->assign('common_path', 'source/plugin/aljhtx');
    }
}

function https_request($url, $data = null) {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
    if (!empty($data)) {
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    }
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($curl);
    curl_close($curl);
    return $output;
}

function downloadImage($url, $filepath) {
    //���������ص�ͷ��Ϣ
    $responseHeaders = array();
    //ԭʼͼƬ��
    $originalfilename = '';
    //ͼƬ�ĺ�׺��
    $ext = '';
    $ch = curl_init($url);
    //����curl_exec���ص�ֵ����Httpͷ
    curl_setopt($ch, CURLOPT_HEADER, 1);
    //����curl_exec���ص�ֵ����Http����
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    //����ץȡ��ת��http 301��302�����ҳ��
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    //��������HTTP�ض��������
    curl_setopt($ch, CURLOPT_MAXREDIRS, 2);

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//��ֱֹ����ʾ��ȡ������ ��Ҫ

    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //����֤֤����ͬ

    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); //


    //���������ص����ݣ�����httpͷ��Ϣ�����ݣ�
    $html = curl_exec($ch);
    //��ȡ�˴�ץȡ�������Ϣ
    $httpinfo = curl_getinfo($ch);
    curl_close($ch);
    if ($html !== false) {
        //����response��header��body�����ڷ���������ʹ����302��ת�����Դ˴���Ҫ���ַ�������Ϊ 2+��ת���� ���Ӵ�
        $httpArr = explode("\r\n\r\n", $html, 2 + $httpinfo['redirect_count']);
        //�����ڶ����Ƿ��������һ��response��httpͷ
        $header = $httpArr[count($httpArr) - 2];
        //������һ���Ƿ��������һ��response������
        $body = $httpArr[count($httpArr) - 1];
        $header.="\r\n";

        //��ȡ���һ��response��header��Ϣ
        preg_match_all('/([a-z0-9-_]+):\s*([^\r\n]+)\r\n/i', $header, $matches);
        if (!empty($matches) && count($matches) == 3 && !empty($matches[1]) && !empty($matches[1])) {
            for ($i = 0; $i < count($matches[1]); $i++) {
                if (array_key_exists($i, $matches[2])) {
                    $responseHeaders[$matches[1][$i]] = $matches[2][$i];
                }
            }
        }
        //��ȡͼƬ��׺��
        if (0 < preg_match('{(?:[^\/\\\\]+)\.(jpg|jpeg|gif|png|bmp)$}i', $url, $matches)) {
            $originalfilename = $matches[0];
            $ext = $matches[1];
        } else {
            if (array_key_exists('Content-Type', $responseHeaders)) {
                if (0 < preg_match('{image/(\w+)}i', $responseHeaders['Content-Type'], $extmatches)) {
                    $ext = $extmatches[1];
                }
            }
        }
        //�����ļ�
        if (!empty($ext)) {
            $filepath .= ".$ext";
            //���Ŀ¼�����ڣ�����Ҫ����Ŀ¼s
            $local_file = fopen($filepath, 'w');
            if (false !== $local_file) {
                if (false !== fwrite($local_file, $body)) {
                    fclose($local_file);
                    $sizeinfo = getimagesize($filepath);
                    return array('filepath' => realpath($filepath), 'width' => $sizeinfo[0], 'height' => $sizeinfo[1], 'orginalfilename' => $originalfilename, 'filename' => pathinfo($filepath, PATHINFO_BASENAME));

                }
            }
        }
    }
    return false;
}
