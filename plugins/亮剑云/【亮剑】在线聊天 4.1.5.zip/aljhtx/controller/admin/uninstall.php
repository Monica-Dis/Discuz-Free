<?php

/**
 * Controller����������ģ��
 *
 * @author yuxinqi<yuxinqi@vip.qq.com>
 * @version 1.0
 * @link http://docs.liangjianyun.com/
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class uninstallAction{
    public $page;

    public function __construct() {
        global $requestPage;
        $this->page = $requestPage;
    }

    public function uninstallSet(){
        global $_G;
        if($_G['groupid'] != 1){
            $this->page->showMessage(lang("plugin/aljhtx","uninstall_php_1"));
        }
        if(submitcheck('formhash')){
            if(is_array($_GET['settingsnew'])){
                foreach($_GET['settingsnew'] as $k => $v){
                    if(DB::result_first('select svalue from %t where skey=%s', array('aljhtx_system_setting', $k))){
                        DB::update('aljhtx_system_setting', array('svalue' => $v), array('skey' => $k));
                    }else{
                        DB::insert('aljhtx_system_setting', array(
                            'skey' => $k,
                            'svalue' => $v,
                        ));
                    }
                }
            }
            $this->page->tips();
        }else{
            $un_set = DB::fetch_all('select * from %t', array('aljhtx_system_setting'),'skey');
            
            $this->page->assign('un_set', $un_set);
            $this->page->display();
        }
    }
}

