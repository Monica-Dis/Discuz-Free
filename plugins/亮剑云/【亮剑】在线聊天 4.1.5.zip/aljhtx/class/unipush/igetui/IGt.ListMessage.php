<?php 

class IGtListMessage extends IGtMessage{
	
	public function __construct(){
		parent::__construct(); /*dism��taobao��com*/
	}

}