<?php

/**
 *��Ϣ������
 *
 * @author yuxinqi<yuxinqi@vip.qq.com>
 * @version 1.0
 * @link http://docs.liangjianyun.com?/
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class Message{

    public $loginUser;
    public $friendUser;
    public $content;

    public function __construct($loginUser, $content, $friendUser = array()) {
        $this->loginUser = $loginUser;
        $this->friendUser = $friendUser;
        $this->content = $content;
    }

    /**
     * ������Ϣ
     *
     * @param string $type ��Ϣ���
     * @param array $friendUser ��Ϣ���Ͷ���
     * @return void
     */
    public function send($type = 'system', $friendUser = array()){
        if($friendUser){
            if (is_array($friendUser)) {
                $friendUser = (object)$friendUser;
            }
            $this->friendUser = $friendUser;
        }
        
        if($type == 'system'){
            self::sendNotification($this->friendUser->uid, $this->content);
        }else if($type == 'email'){
            self::sendEmail($this->friendUser->email, $this->content);
        }else if($type == 'aljsyh'){
            self::sendConsume($this->friendUser->uid, $this->content);
        }else if($type == 'aljdx'){
            $cron = T::getObject('cron', array(
                'pid' => $this->friendUser->mobile,
                'touid' => $this->friendUser->uid,
                'type' => 'aljdx',
                'content' => $this->content
            ));
            $cron->push();
        }else if($type == 'aljol'){
            $aljol = T::getObject('Aljol', array(
                'loginUser' => $this->loginUser,
                'friendUser' => $this->friendUser
            ));
            $aljol->send($this->content);
        }
    }

    /**
     * ����ϵͳ��Ϣ
     *
     * @param int $uid �û�UID
     * @param string $content ��Ϣ����
     * @return void
     */
    public static function sendNotification($uid, $content){
        notification_add($uid, 'system', $content);
    }

    /**
     * �����Ż�ȯ
     *
     * @param int $uid �û�UID
     * @param string $content �Ż�ȯids
     * @return void
     */
    public static function sendConsume($uid, $content){

        $consumeids = trim($content,',');
        
        if($consumeids){
            $consumes = C::t('#aljbd#aljbd_consume')->fetch_all(explode(',',$consumeids));
            foreach($consumes as $ck => $cv){
                $userinfo = getuserbyuid($uid);
                $insertArray = array(
                    'uid'=>$uid,
                    'username'=>$userinfo['username'],
                    'receive_time'=>TIMESTAMP,
                    'cid'=>$cv[id],
                    'status'=>1,
                );
                DB::insert('aljsyh_consume_log',$insertArray);
                $consume_name .= $cv[subject].';';
            }
            
            $sendconsumetips = lang("plugin/aljhtx","class_message_php_1").count($consumes).lang("plugin/aljhtx","class_message_php_2").$consume_name;
            unset($consume_name);
            unset($consumeids);
            $msm = $sendconsumetips.'<a href="plugin.php?id=aljsyh&a=couponList&c=voucher">'.lang("plugin/aljhtx","class_message_php_3").'</a>';
            notification_add($uid, 'system',$msm,array('from_idtype'  => 'aljpyh'));
        }
    }

    /**
     * �����ʼ�
     *
     * @param string $email �����ַ
     * @param string $content �ʼ�����
     * @return void
     */
    public static function sendEmail($email = '', $content){
        require_once libfile('function/mail');
        sendmail_cron($email, $content, $content);
    }


}