<?php
/*
*�̳��߼�������
*/
if($_G['cache']['plugin']['aljspt']['is_aljspt']){
    require_once DISCUZ_ROOT . './source/plugin/aljht/function/pt_order.php';
}

class aljbdx{
    /**
     * ��ʼִ���Զ�����
     *
     * @return void
     */
    public static function start(){
        global $_G;
        if(!discuz_process::islocked('autoReceipt','30')){
            self::autoReceipt();
            //discuz_process::unlock('autoReceipt');
        }
        if($_G['cache']['plugin']['aljspt']['is_aljspt']){
            if(!discuz_process::islocked('autoPtOrderRefund','30')){
                pt_grouporderstate_auto();
                pt_orderstate_auto();
            }
        }
        if($_G['cache']['plugin']['aljyg_cj']){
            self::cj_refund_init();
            self::cj_dd_refund_init();
        }
    }
    /*
    * �齱�����˿�
    */
    public static function cj_refund_init(){
        $Gcount=DB::result_first('select count(*) from %t where success =0 and refund_status=1 and price>0 ',array('aljyg_order'));
        
        $Limit = mt_rand(0,$Gcount-1);
        $yg_order=DB::fetch_first('select * from %t where success =0 and refund_status=1 and price>0 limit %d,%d',array('aljyg_order',$Limit,1));
        
        if($yg_order && DB::update('aljyg_order',array('refund_status'=>2), array('id' => $yg_order['id'],'refund_status'=>1))){
            
            $result = self::cj_refund_auto($yg_order);
            
            if($result['code'] == 200) {
                DB::update('aljqb_payorder',array('status'=>2, 'overtime' => TIMESTAMP), array('orderid' => $yg_order['orderid'],'status'=>1));
                $msm = '<a href="plugin.php?id=aljyg&act=member&op=records_all">'.$result['msm'].'</a>';
                notification_add($yg_order['uid'], 'system',$msm,array('from_idtype'  => 'aljyg','from_id' => $yg_order['id']));
                self::sendconsume($result['yg_info'],$yg_order);
            }else{
                DB::update('aljyg_order',array('refund_status'=>1), array('id' => $yg_order['id'],'refund_status'=>2));
                
            }
        }
    }
    /*
    * �齱���Ƶ����˿�
    */
    public static function cj_dd_refund_init(){
        global $_G;
        $Gcount=DB::result_first('select count(*) from %t where success =3 and dd_refund_status=1',array('aljyg_order'));
        
        $Limit = mt_rand(0,$Gcount-1);
        $yg_order=DB::fetch_first('select * from %t where success =3 and dd_refund_status=1 limit %d,%d',array('aljyg_order',$Limit,1));
        
        if($yg_order && DB::update('aljyg_order',array('dd_refund_status'=>2), array('id' => $yg_order['id'],'dd_refund_status'=>1))){
            
            $result = self::cj_refund_auto($yg_order);
            
            if($result['code'] == 200) {
                DB::update('aljqb_payorder',array('status'=>2, 'overtime' => TIMESTAMP), array('orderid' => $yg_order['orderid'],'status'=>1));
                $yg_info = $result['yg_info'];
                $pt_order = $yg_order;
                //$dd_tips = str_replace(array('{title}','{price}','{qi}','{username}','{orderid}'),array($yg_info['title'],$pt_order['price'],$pt_order['pid']+$yg_info['virtual_number'],$pt_order['username'],$pt_order['id']),$_G['cache']['plugin']['aljyg_cj']['ddtips']);
                $msm = '<a href="plugin.php?id=aljyg&act=goodsview&yid='.$pt_order['yid'].'&tid='.$yg_info['tableid'].'&pid='.$pt_order['pid'].'">'.$result['msm'].'</a>';
                notification_add($yg_order['uid'], 'system',$msm,array('from_idtype'  => 'aljyg','from_id' => $yg_order['id']));
                
            }else{
                DB::update('aljyg_order',array('dd_refund_status'=>1), array('id' => $yg_order['id'],'dd_refund_status'=>2));
                
            }
        }
    }
    /*
    * �����Ż�ȯ
    */
    public static function sendconsume ($yg_info,$pt_order){
        global $_G;
        $cid = $yg_info['cid'];
        $uid = $pt_order['uid'];
        if($cid>0){
            $consume = DB::fetch_first('select * from %t where id=%d',array('aljbd_consume',$cid));
            if($consume){
                $userinfo = getuserbyuid($uid);
                $insertArray = array(
                    'uid'=>$uid,
                    'username'=>$userinfo['username'],
                    'receive_time'=>TIMESTAMP,
                    'cid'=>$cid,
                    'status'=>1,
                );
                DB::insert('aljsyh_consume_log',$insertArray);
                DB::query('update %t set downnum=downnum+1 where id=%d',array('aljbd_consume',$cid));
                $sendconsumetips = str_replace(array('{title}','{price}','{qi}','{username}','{orderid}','{subject}'),array($yg_info['title'],$pt_order['price'],$pt_order['pid']+$yg_info['virtual_number'],$pt_order['username'],$pt_order['id'],$consume['subject']),$_G['cache']['plugin']['aljyg_cj']['sendconsumetips']); 
                $msm = '<a href="plugin.php?id=aljsyh&a=couponList&c=voucher">'.$sendconsumetips.'</a>';
                notification_add($uid, 'system',$msm,array('from_idtype'  => 'aljyg'));
            }
        } 
    }
    /*
    * �齱�����Զ��˿�
    */
    public static function cj_refund_auto($pt_order){
        global $_G,$config,$qbapi,$queue;
        $yg_info = DB::fetch_first('select * from %t where id=%d',array('aljyg',$pt_order['yid']));
        if($pt_order['dd_refund_status'] == 1){
            $zxtk_tips = $qbye_tips = $jfye_tips = str_replace(array('{title}','{price}','{qi}','{username}','{orderid}'),array($yg_info['title'],$pt_order['price'],$pt_order['pid']+$yg_info['virtual_number'],$pt_order['username'],$pt_order['id']),$_G['cache']['plugin']['aljyg_cj']['ddtips']);
        }else{
            $zxtk_tips = str_replace(array('{title}','{price}','{qi}','{username}','{orderid}'),array($yg_info['title'],$pt_order['price'],$pt_order['pid']+$yg_info['virtual_number'],$pt_order['username'],$pt_order['id']),$_G['cache']['plugin']['aljyg_cj']['zxtk_tips']);
            $qbye_tips = str_replace(array('{title}','{price}','{qi}','{username}','{orderid}'),array($yg_info['title'],$pt_order['price'],$pt_order['pid']+$yg_info['virtual_number'],$pt_order['username'],$pt_order['id']),$_G['cache']['plugin']['aljyg_cj']['qbye_tips']);   
            $jfye_tips = str_replace(array('{title}','{price}','{qi}','{exttype}','{username}','{orderid}'),array($yg_info['title'],intval($pt_order['price']),$pt_order['pid']+$yg_info['virtual_number'],$_G['setting']['extcredits'][$_G['cache']['plugin']['aljyg']]['title'],$pt_order['username'],$pt_order['id']),$_G['cache']['plugin']['aljyg_cj']['jfye_tips']);
        }
        if($pt_order['payment'] == 7){
            
            $pay_order = DB::fetch_first('select * from %t where orderid=%s',array('aljqb_payorder',$pt_order['orderid']));
            $pt_order['buyer'] = $pay_order['transaction_id'];
            if($_G['cache']['plugin']['aljyg_cj']['refundstype'] == 1){
                
                if($pt_order['admin'] == 'wxpay' || $pt_order['admin'] == 'APP'){
                    $senddata['out_refund_no'] = $pt_order['orderid'];
                    if($pt_order['admin'] == 'APP'){
                        $senddata['mch_id'] = $config['mchid2'];
                        $senddata['appid'] = $config['appid2'];
                        $senddata['op_user_id'] = $config['mchid2'];
                        $senddata['key'] = $config['key2'];
                    }else if($pt_order['admin'] == 'wxpay'){
                        $senddata['mch_id'] = $config['mchid'];
                        $senddata['appid'] = $config['appid'];
                        $senddata['op_user_id'] = $config['mchid'];
                        $senddata['key'] = $config['key'];
                    }
                    $senddata['orderid'] = $pt_order['buyer'];
                    $senddata['price'] = $pt_order['price'];
                    $senddata['refund_fee'] = $pt_order['price'];
                    $wxrefund = wxpayrefund($senddata);
                                            
                    $data = xmlToArray($wxrefund);
                    
                    if($data['result_code'] == 'SUCCESS'){
                        $result['code'] = 200;
                        $result['msm'] = $zxtk_tips;
                    }
                }else if($pt_order['admin'] == 'alipay'){
                    $alipay_refund = alipayrefund($pt_order);
                    $result = json_decode($alipay_refund,true);
                    
                    if($result['alipay_trade_refund_response']['msg'] == 'Success'){
                        $result['code'] = 200;
                        $result['msm'] = $zxtk_tips;
                    }else{
                        if(strtolower(CHARSET) == 'gbk') {
                            $error = diconv($alipay_refund,'utf-8','gbk');
                        }
                        $qbapi ->insertLog('alipay_refund '.$error);
                    }
                }else if($pt_order['admin'] == 'qianfanapp'){
                    $data = qianfanapp_refund($pay_order['transaction_id'],$pay_order['aljorderid'],$pt_order['price']*100);
                    if($data['ret'] == '0'){
                        $result['code'] = 200;
                        $result['msm'] = $zxtk_tips;
                    }else{
                        if(strtolower(CHARSET) == 'gbk') {
                            $error = diconv($data['text'],'utf-8','gbk');
                        }
                        $qbapi ->insertLog('qianfanapp_refund '.$error);
                    }
                }else {
                    $rmb = substr(sprintf("%.3f",$pt_order['price']),0,-1);
                    $queuearray = array(
                        'app_name' => 'aljyg_cj',
                        'app_type' => 'aljyg_cjrefund',
                        'app_phone' => '123456789',
                        'app_ip' => '123456789',
                    );
                    $balancearray = array(
                        'type'=> 'charge',
                        'uid'=>$pt_order['uid'],
                        'price' => $rmb,
                        'orderid'=> $pt_order['orderid'],
                        'desc'=> $qbye_tips,
                    );
                    $result = $qbapi->balance($queuearray,$balancearray);
                    $result['msm'] = $qbye_tips;
                }
            }else{
                $rmb = substr(sprintf("%.3f",$pt_order['price']),0,-1);
                $queuearray = array(
                    'app_name' => 'aljyg_cj',
                    'app_type' => 'aljyg_cjrefund',
                    'app_phone' => '123456789',
                    'app_ip' => '123456789',
                );
                $balancearray = array(
                    'type'=> 'charge',
                    'uid'=>$pt_order['uid'],
                    'price' => $rmb,
                    'orderid'=> $pt_order['orderid'],
                    'desc'=> $qbye_tips,
                );
                $result = $qbapi->balance($queuearray,$balancearray);
                $result['msm'] = $qbye_tips;
            }
        }else if($pt_order['payment'] == 4){
            updatemembercount($pt_order['uid'], array($_G['cache']['plugin']['aljyg']['ext'] => $pt_order['price']),'','','','','&#25277;&#22870;&#19981;&#20013;&#36864;&#27454;',$jfye_tips);
            $result['code'] = 200;
            
            $result['msm'] = $jfye_tips;
        }
        $result['yg_info'] = $yg_info;
        return $result;

    }
    /**
     * �Զ��ջ�
     *
     * @return void
     */
    public static function autoReceipt(){
        $d_info = C::t('#aljbd#aljbd_setting')->fetch('deliverytime');
        if($d_info['value']){
            $deliverytime = $d_info['value']*24*60*60-100;
        }else{
            $deliverytime = 10*24*60*60-100;
        }
        $order = DB::fetch_first('select * from %t where status=3 and order_type != 3 and deliverydate>0 and deliverydate+%d<%d limit 1',array('aljbd_goods_order',$deliverytime,TIMESTAMP));
        //debug($order);
        if($order){
            self::receipt($order);
        }
    }
    /**
     * �������-��ά�����⽱��
     *
     * @param array() $order ��������
     * @return void
     */
    public static function jl_qs($order) {
        global $_G;
        if($order['wm_platform_distribution']){
            $shopdata = DB::fetch_first('select * from %t where uid=%d',array('aljtjd_user',$order[qs_uid]));
            C::t('#aljbd#aljbd_wuliu')->update($_GET['orderid'],array(
                'e' => '&#24179;&#21488;&#37197;&#36865;&#21592;&#12300;'.$shopdata['name'].'('.$shopdata['tel'].')'.'&#12301;&#24050;&#25226;&#21830;&#21697;&#23433;&#20840;&#30340;&#36865;&#21040;&#24744;&#30340;&#25163;&#20013;&#65292;&#35746;&#21333;&#24050;&#23436;&#25104;',
            ));
            $others = unserialize($order['other']);
            $others['time_of_service'] = TIMESTAMP;
            DB::query("update %t set other=%s where orderid = %s",array('aljbd_goods_order',serialize($others),$_GET['orderid']));
            //����Ա���
            $first_shopdata = DB::fetch_first('select a.username,b.* from %t a left join %t b on a.rankid=b.id where a.uid=%d and a.status=1',array('aljtjd_user','aljtjd_rank',$order[qs_uid]));

            $first_fee = substr(sprintf("%.3f",$order['fare'] * ($first_shopdata['scale']/100)),0,-1);//����Ա���Ӷ��
            if($first_shopdata && $first_shopdata['scale']>0){
                
                
                if($first_fee>0){
                    $first_insert = array(
                        'orderid' => $order['orderid'],
                        'timestamp' => TIMESTAMP,
                        'beneficiary_uid' => $order[qs_uid],
                        'beneficiary_username' => $first_shopdata['username'],
                        'payment_days' => $first_shopdata['payment_days'],
                        'uid' => $order['uid'],
                        'username' => $order['username'],
                        'money' => $first_fee,
                        'scale' => $first_shopdata['scale'],
                        'dis_commission' => 1,
                        'status' => 1,
                        'type' => 1,
                        'name' => $order['stitle'],
                        'price' => $order['fare'],
                        'num' => 1,
                    );
                    DB::insert('aljtjd_order',$first_insert);
                    DB::query('update %t set total_commission=total_commission+%i,not_account_commissions=not_account_commissions+%i where uid=%d',array('aljtjd_user',$first_fee,$first_fee,$order[qs_uid]));
                }
            }
        }
        if($_G['cache']['plugin']['aljreg']['special_hb'] > 0 && $_G['cache']['plugin']['aljreg']['special_uids']){
            $special_uids = explode(',',$_G['cache']['plugin']['aljreg']['special_uids']);
            $aljreg_info = DB::fetch_first('select * from %t where uid=%d ', array('aljreg_invite', $order['uid']));
            $fromuid = $aljreg_info['fromuid'];
            if(in_array($fromuid,$special_uids)){
                
                require_once DISCUZ_ROOT . './source/plugin/aljqb/class/Qbapi.class.php';
                $payment = new Qbapi();
                //����Ǯ�� +money
                $queuearray = array(
                    'app_name' => 'aljreg',
                    'app_type' => 'aljreg_txcancel',
                    'app_phone' => '123456789',
                    'app_ip' => $_G['clientip'],
                );
                $balancearray = array(
                    'type'=> 'charge',
                    'uid'=>$fromuid,
                    'price' => $_G['cache']['plugin']['aljreg']['special_hb'],
                    'orderid'=> $order['orderid'],
                    'desc'=> str_replace(array('{username}','{title}','{money}','{orderid}','{price}'),array(lang('plugin/aljbd','l_danyinghao').$order['username'].lang('plugin/aljbd','r_danyinghao'),$order['stitle'],$_G['cache']['plugin']['aljreg']['special_hb'],$order['orderid'],$order['price']),$_G['cache']['plugin']['aljreg']['special_hb_tips']),
                );
                $result = $payment -> balance($queuearray,$balancearray);
            }
        }
    }
    /**
     * ȷ���ջ�
     *
     * @param array() $order ��������
     * @return void
     */
    public static function receipt($order){
        global $_G;
        require_once DISCUZ_ROOT . './source/plugin/aljqb/class/Qbapi.class.php';
        $payment = new Qbapi();
        if(DB::query("update %t set status=4 where orderid = %s  and status=3",array('aljbd_goods_order',$order['orderid']))){
            if($order['store_id']>0){
                if($order['order_type'] == 7){
                    self::handleStoreChief($order);
                }else{
                    self::handleStore($order);
                }
            }else{
                if($_G['cache']['plugin']['aljsr']['is_aljsr']){
                    self::handle_aljsr($order);
                }else{
                    self::handle($order);
                }
                self::jl_qs($order);
            }
        }
    }
    /**
     * �ų�ȷ���ջ���������
     *
     * @param array() $order ��������
     * @return void
     */
    public static function handleStoreChief ($order) {
        global $_G;
        require_once DISCUZ_ROOT . './source/plugin/aljqb/class/Qbapi.class.php';
        $payment = new Qbapi();
        DB::query("update %t set status=4 WHERE status=3 and orderid=%s ",array('aljbd_goods_order_list',$order['orderid']));
        if($_G['cache']['plugin']['aljsqtg']['aljsqtg_type'] == 1){
            //�ų����
            $brand = C::t('#aljtsq#aljtsq_store') -> fetch($order['store_id']);

            if($brand['tc_fee']>0){
                $chief_fee = sprintf("%.2f",$order['price']*($brand['tc_fee']/100));//�ų���ɱ���
            }else if($_G['cache']['plugin']['aljsqtg']['fee']>0){
                $chief_fee = sprintf("%.2f",$order['price']*($_G['cache']['plugin']['aljsqtg']['fee']/100));//�ų���ɱ���
            }
            
            if($chief_fee > 0){
                
                $fee_insert = array(
                    'orderid' => $order['orderid'],
                    'timestamp' => TIMESTAMP,
                    'beneficiary_uid' => $brand['tc_uid'],
                    'beneficiary_username' => $brand['tc_username'],
                    'payment_days' => $brand['tc_num'] ? $brand['tc_num'] : $_G['cache']['plugin']['aljsqtg']['payment_days'],
                    'uid' => $order['uid'],
                    'username' => $order['username'],
                    'money' => $chief_fee,
                    'status' => 1,
                    'type' => 3,
                    'price' => $fee,
                    'fx_fee' => $brand['tc_fee']>0 ? $brand['tc_fee'] : $_G['cache']['plugin']['aljsqtg']['fee'],
                    'store_id' => $order['store_id'],
                    'name' => str_replace(array('{username}','{title}','{money}','{name}','{orderid}'),array(lang('plugin/aljbd','l_danyinghao').$order['username'].lang('plugin/aljbd','r_danyinghao'),$order['stitle'],$chief_fee,$_G['cache']['plugin']['aljsqtg']['aljsqtg_name'],$order['orderid']),$_G['cache']['plugin']['aljsqtg']['qb_desc_chief_fee']),
                    'orderinfo' => serialize($order),
                );
                DB::insert('aljsr_order',$fee_insert);
                DB::query('update %t set total_commission=total_commission+%i,not_account_commissions=not_account_commissions+%i where tc_id=%d',array('aljtsq_store',$chief_fee,$chief_fee,$brand['tc_id'])); 
            }
        }
        if($order['give_integral']>0){
            updatemembercount(
                $order['uid'],
                array($_G['cache']['plugin']['aljbdx']['exttype'] => intval($order['give_integral'])),
                '',
                '',
                '',
                '',
                lang("plugin/aljbdx","receipt_php_1"),
                lang("plugin/aljbdx","receipt_php_2") . $order['give_integral'] . $_G['setting']['extcredits'][$_G['cache']['plugin']['aljbdx']['exttype']]['title'] . lang("plugin/aljbdx","receipt_php_3") . $order['orderid']);
        }
        
        if($_G['cache']['plugin']['aljpyh']['is_aljpyh']){
            require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/sendconsume_receipt.php';
            require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/use_sendconsume_receipt.php';
            require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/sendconsume_goods_receipt.php';
        }
        //s ������ѯ���� �ֵ�
        if($_G['cache']['plugin']['aljsfx']['is_aljsfx']){
            $fx_fee = self::fx_receipt_sqtg($order);
            $order['price'] = $order['price'] - $fx_fee;
        }
        if($order['cid'] > 0 && $_G['cache']['plugin']['aljpyh']){
            //require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/butie.php';
        }
        $orderlurln = '/plugin.php?id=aljsqtg&a=orderList';
        //s ��ѯ�Ƿ������� ��ά���ƹ㺣��
        if($_G['cache']['plugin']['aljreg']['qb_desc']){
            sleep(1);
            self::aljreg_fee($order);
        }
        //e��ѯ�Ƿ������� ��ά���ƹ㺣��
        //s ���û�������Ϣ
        if($_G['cache']['plugin']['aljsqtg']['receipt_send_user_tips']){
            
            $mes = str_replace(array('{username}','{url}','{name}','{orderid}'),array($order['username'],$orderlurln,$_G['cache']['plugin']['aljsqtg']['aljsqtg_name'],$order['orderid']),$_G['cache']['plugin']['aljsqtg']['receipt_send_user_tips']);
            notification_add($order['uid'], 'system', $mes);
        }
        //e ���û�������Ϣ
        //s ������Ա������Ϣ
        if($_G['cache']['plugin']['aljsqtg']['receipt_send_admin_tips']){
        
            $mes = str_replace(array('{username}','{url}','{name}','{orderid}'),array($order['username'],$orderlurln.'&store=admin',$_G['cache']['plugin']['aljsqtg']['aljsqtg_name'],$order['orderid']),$_G['cache']['plugin']['aljsqtg']['receipt_send_admin_tips']);
            
            $admin_uids = explode(',',$_G['cache']['plugin']['aljsqtg']['send_tips_admin_uids']);
            $admin_uids = array_unique($admin_uids);
            foreach($admin_uids as $a_u_v){
                notification_add($a_u_v, 'system', $mes);
            }
        }
        //e ������Ա������Ϣ
        
    }
    /**
     * �ŵ�ȷ���ջ���������
     *
     * @param array() $order ��������
     * @return void
     */
    public static function handleStore ($order){
        global $_G;
        require_once DISCUZ_ROOT . './source/plugin/aljqb/class/Qbapi.class.php';
        $payment = new Qbapi();
        $brand = C::t('#aljtsq#aljtsq_store') -> fetch($order['store_id']);

        $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$brand['vipid']));
        if($brand['tc_fee']>0){
            $fee = sprintf("%.2f",$order['price']*($brand['tc_fee']/100));//վ����ɱ���
        }else if($vipdata['fee']>0){
            $fee = sprintf("%.2f",$order['price']*($vipdata['fee']/100));//վ����ɱ���
        }
        $userinfo = DB::fetch_first('select * from %t where uid=%d',array('common_member',$brand['tc_uid']));
        if($brand && $order['price']>0 && $userinfo && $order['payment'] == 7){
            //����Ǯ�� +money
            $queuearray = array(
                'app_name' => 'aljtsc',
                'app_type' => 'aljtsc_txcancel',
                'app_phone' => '123456789',
                'app_ip' => $_G['clientip'],
            );
            $balancearray = array(
                'type'=> 'charge',
                'uid'=>$brand['tc_uid'],
                'price' => $order['price'],
                'orderid'=> $order['orderid'],
                'desc'=> str_replace(array('{username}','{title}','{money}','{name}'),array(lang('plugin/aljbd','l_danyinghao').$order['username'].lang('plugin/aljbd','r_danyinghao'),$order['stitle'],$order['price'],$brand['tc_store_name']),$_G['cache']['plugin']['aljbdx']['qb_desc_add']),
            );
            $result = $payment -> balance($queuearray,$balancearray);

            //����Ǯ��
            if($result['code'] == 200){
                
                DB::query("update %t set status=4 WHERE status=3 and orderid=%s ",array('aljbd_goods_order_list',$order['orderid']));
                
                if($order['give_integral']>0){
                    updatemembercount(
                        $order['uid'],
                        array($_G['cache']['plugin']['aljbdx']['exttype'] => intval($order['give_integral'])),
                        '',
                        '',
                        '',
                        '',
                        lang("plugin/aljbdx","receipt_php_1"),
                        lang("plugin/aljbdx","receipt_php_2") . $order['give_integral'] . $_G['setting']['extcredits'][$_G['cache']['plugin']['aljbdx']['exttype']]['title'] . lang("plugin/aljbdx","receipt_php_3") . $order['orderid']);
                }
                
                
                if($fee>0){
                    sleep(1);
                    //����Ǯ�� -money
                    $queuearray = array(
                        'app_name' => 'aljtsc',
                        'app_type' => 'aljtsc_txcancel',
                        'app_phone' => '123456789',
                        'app_ip' => $_G['clientip'],
                    );
                    $balancearray = array(
                        'type'=> 'take',
                        'uid'=>$brand['tc_uid'],
                        'price' => $fee,
                        'orderid'=> $order['orderid'],
                        'desc'=> str_replace(array('{money}'),array($fee),$_G['cache']['plugin']['aljbdx']['qb_desc_fee']),
                    );
                    $result_take = $payment -> balance($queuearray,$balancearray);
                    if ($fee > 0) {
                        //ƽ̨���� ������
                        $desca = lang("plugin/aljhtx","class_aljbdx_php_1").$brand['tc_store_name'].lang("plugin/aljhtx","class_aljbdx_php_2").$orderprice.lang("plugin/aljhtx","class_aljbdx_php_3").$fee.lang("plugin/aljhtx","class_aljbdx_php_4");
                        //���ù�����
                        require_once 'source/plugin/aljhtx/class/class_aljhtx.php';
                        T::platformRevenue($order,$desca,$fee,'aljtsc');
                    }
                    //����Ǯ��
                    $orderprice = $order['price'];
                    $order['price'] = $fee;
                    $fz_path = DISCUZ_ROOT . "source/plugin/aljtfz/include";
                    if($_G['cache']['plugin']['aljtfz'] && is_file("$fz_path/fz_statistics.php")){
                        include_once "$fz_path/fz_statistics.php";
                    }
                    //s ������ѯ���� �ֵ�
                    if($_G['cache']['plugin']['aljhhr']['is_aljhhr']){
                        $hhr_path = DISCUZ_ROOT . "source/plugin/aljhhr/function/function.php";
                        if(is_file($hhr_path)){
                            include_once $hhr_path;
                            hhrDivideInto($order,'aljtsc');
                            //��˿�ŵ���ˮ�ֳ�
                            $order['uid'] = $brand['tc_uid'];
                            $order['stitle'] = lang("plugin/aljhtx","class_aljbdx_php_5").$brand['tc_username'].lang("plugin/aljhtx","class_aljbdx_php_6").$brand['tc_store_name'].lang("plugin/aljhtx","class_aljbdx_php_7").$orderprice.lang("plugin/aljhtx","class_aljbdx_php_8");
                            hhrDivideInto($order,'aljtsq_store');
                        }
                    }
                    //e ������ѯ����
                    

                }
                $orderlurln = '/plugin.php?id=aljbd&act=orderlist';
                
                //s ������Ա������Ϣ
                if($_G['cache']['plugin']['aljbdx']['receipt_tips']){
                    $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
                    $mes = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],$orderlurln,$brand['tc_store_name']),$_G['cache']['plugin']['aljbdx']['receipt_tips']);
                    foreach($groupids as $g_uid){
                        notification_add($g_uid['uid'], 'system',$mes);
                    }
                }
                //s ������Ա������Ϣ
                if($_G['cache']['plugin']['aljbdx']['receipt_tips_brand']){

                    $mes_brand = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],$orderlurln,$brand['tc_store_name']),$_G['cache']['plugin']['aljbdx']['receipt_tips_brand']);
                    notification_add($brand['uid'], 'system',$mes_brand);
                }
            }else{
                DB::query("update %t set status=3 where orderid = %s and status=4",array('aljbd_goods_order',$order['orderid']));
            }
        }else if($order['payment'] == 6){
            $orderlurln = '/plugin.php?id=aljbd&act=orderlist';
            $brand = C::t('#aljbd#aljbd') -> fetch($order['shop_id']);
            //s ������Ա������Ϣ
            if($_G['cache']['plugin']['aljbdx']['receipt_tips']){
                $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
                $mes = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],$orderlurln,$brand['name']),$_G['cache']['plugin']['aljbdx']['receipt_tips']);
                foreach($groupids as $g_uid){
                    notification_add($g_uid['uid'], 'system',$mes);
                }
            }
            //s ���̼ҷ�����Ϣ
            if($_G['cache']['plugin']['aljbdx']['receipt_tips_brand']){
    
                $mes_brand = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],$orderlurln,$brand['name']),$_G['cache']['plugin']['aljbdx']['receipt_tips_brand']);
                notification_add($brand['uid'], 'system',$mes_brand);
            }
        }
    }
    /**
     * ȷ���ջ���������-����̻����붩��
     *
     * @param array() $order ��������
     * @return void
     */
    public static function handle_aljsr ($order){
        global $_G;
        require_once DISCUZ_ROOT . './source/plugin/aljqb/class/Qbapi.class.php';
        $payment = new Qbapi();
        $brand = C::t('#aljbd#aljbd') -> fetch($order['shop_id']);

        $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$brand['vipid']));
        if($vipdata['fee']>0){
            $fee = sprintf("%.2f",$order['price']*($vipdata['fee']/100));//վ����ɱ���
        }else{
            $fee = sprintf("%.2f",$order['price']*($_G['cache']['plugin']['aljbdx']['fee']/100));//վ����ɱ���
        }
        $userinfo = DB::fetch_first('select * from %t where uid=%d',array('common_member',$brand['uid']));
        
        if($brand && $order['price']>0 && $userinfo && $order['payment'] == 7){
            DB::query("update %t set status=4 WHERE status=3 and orderid=%s ",array('aljbd_goods_order_list',$order['orderid']));
                if($order['give_integral']>0){
                    updatemembercount(
                        $order['uid'],
                        array($_G['cache']['plugin']['aljbdx']['exttype'] => intval($order['give_integral'])),
                        '',
                        '',
                        '',
                        '',
                        lang("plugin/aljbdx","receipt_php_1"),
                        lang("plugin/aljbdx","receipt_php_2") . $order['give_integral'] . $_G['setting']['extcredits'][$_G['cache']['plugin']['aljbdx']['exttype']]['title'] . lang("plugin/aljbdx","receipt_php_3") . $order['orderid']);
                }
                
                if($_G['cache']['plugin']['aljpyh']['is_aljpyh']){
                    require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/sendconsume_receipt.php';
                    require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/use_sendconsume_receipt.php';
                    require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/sendconsume_goods_receipt.php';
                }
                //s ������ѯ���� �ֵ�
                if($_G['cache']['plugin']['aljsfx']['is_aljsfx']){
                    $fx_fee = self::fx_receipt($order,$brand);
                    $order['price'] = $order['price'] - $fx_fee;
                }
                //e ������ѯ����
                if($fee>0){
                    $order['price'] = $order['price'] - $fee;
                    //����Ǯ��
                    
                    //����Ǯ�� +money ����ͳ���ʻ�
                    if($_G['cache']['plugin']['aljbdx']['money_uid']>0){
                        sleep(1);
                        $queuearray = array(
                            'app_name' => 'aljbdx',
                            'app_type' => 'aljbdx_add',
                            'app_phone' => '123456789',
                            'app_ip' => $_G['clientip'],
                        );
                        $balancearray = array(
                            'type'=> 'charge',
                            'uid'=>$_G['cache']['plugin']['aljbdx']['money_uid'],
                            'price' => $fee,
                            'orderid'=> $order['orderid'],
                            'desc'=> str_replace(array('{username}','{name}','{title}','{money}'),array(lang('plugin/aljbd','l_danyinghao').$brand['username'].lang('plugin/aljbd','r_danyinghao'),$brand['name'],$order['stitle'],$fee),$_G['cache']['plugin']['aljbdx']['qb_desc_uid_fee']),
                        );
                        $result_money_uid = $payment -> balance($queuearray,$balancearray);
                    }

                }
                if($order['price'] > 0){
                    $order['price'] = sprintf("%.2f", $order['price']);
                    $fee_insert = array(
                        'orderid' => $order['orderid'],
                        'timestamp' => TIMESTAMP,
                        'beneficiary_uid' => $brand['uid'],
                        'beneficiary_username' => $brand['username'],
                        'payment_days' => $vipdata['payment_days'],
                        'uid' => $order['uid'],
                        'username' => $order['username'],
                        'money' => $order['price'],
                        'status' => 1,
                        'type' => 1,
                        'price' => $fee,
                        'fx_fee' => $fx_fee,
                        'bid' => $order['shop_id'],
                        'name' => str_replace(array('{username}','{title}','{money}','{name}'),array(lang('plugin/aljbd','l_danyinghao').$order['username'].lang('plugin/aljbd','r_danyinghao'),$order['stitle'],$order['price'],$brand['name']),$_G['cache']['plugin']['aljbdx']['qb_desc_add']),
                        'orderinfo' => serialize($order),
                    );
                    DB::insert('aljsr_order',$fee_insert);
                    DB::query('update %t set total_commission=total_commission+%i,not_account_commissions=not_account_commissions+%i where id=%d',array('aljbd',$order['price'],$order['price'],$brand['id'])); 
                }
                if($order['cid'] > 0 && $_G['cache']['plugin']['aljpyh']){
                    require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/butie.php';
                }
                $orderlurln = '/plugin.php?id=aljbd&act=orderlist';
                //s ��ѯ�Ƿ������� ��ά���ƹ㺣��
                if($_G['cache']['plugin']['aljreg']['qb_desc']){
                    sleep(1);
                    self::aljreg_fee($order);
                }
                //e��ѯ�Ƿ������� ��ά���ƹ㺣��
                //$brand = C::t('#aljbd#aljbd') -> fetch($order['shop_id']);
                //s ������Ա������Ϣ
                if($_G['cache']['plugin']['aljbdx']['receipt_tips']){
                    $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
                    $mes = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],$orderlurln,$brand['name']),$_G['cache']['plugin']['aljbdx']['receipt_tips']);
                    foreach($groupids as $g_uid){
                        notification_add($g_uid['uid'], 'system',$mes);
                    }
                }
                //s ������Ա������Ϣ
                if($_G['cache']['plugin']['aljbdx']['receipt_tips_brand']){

                    $mes_brand = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],$orderlurln,$brand['name']),$_G['cache']['plugin']['aljbdx']['receipt_tips_brand']);
                    notification_add($brand['uid'], 'system',$mes_brand);
                }
            
        }else if($order['payment'] == 7 && $order['order_type'] == 7){//�����Ź�����
            self::handleStoreChief($order);
        }else if($order['payment'] == 6){
            DB::query("update %t set status=4 WHERE status=3 and orderid=%s ",array('aljbd_goods_order_list',$order['orderid']));
            $orderlurln = '/plugin.php?id=aljbd&act=orderlist';
            $brand = C::t('#aljbd#aljbd') -> fetch($order['shop_id']);
            if($order['cid'] > 0 && $_G['cache']['plugin']['aljpyh']['close_no_pay']){
                require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/butie.php';
            }
            if($_G['cache']['plugin']['aljpyh']['is_aljpyh']){
                require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/sendconsume_receipt.php';
                require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/use_sendconsume_receipt.php';
                require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/sendconsume_goods_receipt.php';
            }
            //s ������Ա������Ϣ
            if($_G['cache']['plugin']['aljbdx']['receipt_tips']){
                $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
                $mes = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],$orderlurln,$brand['name']),$_G['cache']['plugin']['aljbdx']['receipt_tips']);
                foreach($groupids as $g_uid){
                    notification_add($g_uid['uid'], 'system',$mes);
                }
            }
            //s ���̼ҷ�����Ϣ
            if($_G['cache']['plugin']['aljbdx']['receipt_tips_brand']){
    
                $mes_brand = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],$orderlurln,$brand['name']),$_G['cache']['plugin']['aljbdx']['receipt_tips_brand']);
                notification_add($brand['uid'], 'system',$mes_brand);
            }
        }
    }
    /**
     * ȷ���ջ���������-ʵʱ����̻�Ǯ��
     *
     * @param array() $order ��������
     * @return void
     */
    public static function handle ($order){
        global $_G;
        require_once DISCUZ_ROOT . './source/plugin/aljqb/class/Qbapi.class.php';
        $payment = new Qbapi();
        $brand = C::t('#aljbd#aljbd') -> fetch($order['shop_id']);

        $vipdata = DB::fetch_first('select * from %t where id=%d',array('aljbd_vip',$brand['vipid']));
        if($vipdata['fee']>0){
            $fee = sprintf("%.2f",$order['price']*($vipdata['fee']/100));//վ����ɱ���
        }else{
            $fee = sprintf("%.2f",$order['price']*($_G['cache']['plugin']['aljbdx']['fee']/100));//վ����ɱ���
        }
        $userinfo = DB::fetch_first('select * from %t where uid=%d',array('common_member',$brand['uid']));
        if($brand && $order['price']>0 && $userinfo && $order['payment'] == 7){
            //����Ǯ�� +money
            $queuearray = array(
                'app_name' => 'aljbdx',
                'app_type' => 'aljbdx_txcancel',
                'app_phone' => '123456789',
                'app_ip' => $_G['clientip'],
            );
            $balancearray = array(
                'type'=> 'charge',
                'uid'=>$brand['uid'],
                'price' => $order['price'],
                'orderid'=> $order['orderid'],
                'desc'=> str_replace(array('{username}','{title}','{money}','{name}'),array(lang('plugin/aljbd','l_danyinghao').$order['username'].lang('plugin/aljbd','r_danyinghao'),$order['stitle'],$order['price'],$brand['name']),$_G['cache']['plugin']['aljbdx']['qb_desc_add']),
            );
            $result = $payment -> balance($queuearray,$balancearray);

            //����Ǯ��
            if($result['code'] == 200){
                
                DB::query("update %t set status=4 WHERE status=3 and orderid=%s ",array('aljbd_goods_order_list',$order['orderid']));
                
                if($order['give_integral']>0){
                    updatemembercount(
                        $order['uid'],
                        array($_G['cache']['plugin']['aljbdx']['exttype'] => intval($order['give_integral'])),
                        '',
                        '',
                        '',
                        '',
                        lang("plugin/aljbdx","receipt_php_1"),
                        lang("plugin/aljbdx","receipt_php_2") . $order['give_integral'] . $_G['setting']['extcredits'][$_G['cache']['plugin']['aljbdx']['exttype']]['title'] . lang("plugin/aljbdx","receipt_php_3") . $order['orderid']);
                }
                if($_G['cache']['plugin']['aljpyh']['is_aljpyh']){
                    require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/sendconsume_receipt.php';
                    require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/use_sendconsume_receipt.php';
                    require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/sendconsume_goods_receipt.php';
                }
                if($order['cid'] > 0 && $_G['cache']['plugin']['aljpyh']){
                    require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/butie_aljqb.php';
                }
                sleep(1);
                //s ������ѯ���� �ֵ�
                if($_G['cache']['plugin']['aljsfx']['is_aljsfx']){
                    $fx_fee = self::fx_receipt($order,$brand);
                }
                //e ������ѯ����
                if($fee>0){
                    sleep(1);
                    //����Ǯ�� -money
                    $queuearray = array(
                        'app_name' => 'aljbdx',
                        'app_type' => 'aljbdx_txcancel',
                        'app_phone' => '123456789',
                        'app_ip' => $_G['clientip'],
                    );
                    $balancearray = array(
                        'type'=> 'take',
                        'uid'=>$brand['uid'],
                        'price' => $fee,
                        'orderid'=> $order['orderid'],
                        'desc'=> str_replace(array('{money}'),array($fee),$_G['cache']['plugin']['aljbdx']['qb_desc_fee']),
                    );
                    $result_take = $payment -> balance($queuearray,$balancearray);
                    //����Ǯ��
                    
                    //����Ǯ�� +money ����ͳ���ʻ�
                    if($_G['cache']['plugin']['aljbdx']['money_uid']>0){
                        sleep(1);
                        $queuearray = array(
                            'app_name' => 'aljbdx',
                            'app_type' => 'aljbdx_add',
                            'app_phone' => '123456789',
                            'app_ip' => $_G['clientip'],
                        );
                        $balancearray = array(
                            'type'=> 'charge',
                            'uid'=>$_G['cache']['plugin']['aljbdx']['money_uid'],
                            'price' => $fee,
                            'orderid'=> $order['orderid'],
                            'desc'=> str_replace(array('{username}','{name}','{title}','{money}'),array(lang('plugin/aljbd','l_danyinghao').$brand['username'].lang('plugin/aljbd','r_danyinghao'),$brand['name'],$order['stitle'],$fee),$_G['cache']['plugin']['aljbdx']['qb_desc_uid_fee']),
                        );
                        $result_money_uid = $payment -> balance($queuearray,$balancearray);
                    }

                }
                $orderlurln = '/plugin.php?id=aljbd&act=orderlist';
                //s ��ѯ�Ƿ������� ��ά���ƹ㺣��
                if($_G['cache']['plugin']['aljreg']['qb_desc']){
                    sleep(1);
                    self::aljreg_fee($order);
                }
                //e��ѯ�Ƿ������� ��ά���ƹ㺣��
                //$brand = C::t('#aljbd#aljbd') -> fetch($order['shop_id']);
                //s ������Ա������Ϣ
                if($_G['cache']['plugin']['aljbdx']['receipt_tips']){
                    $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
                    $mes = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],$orderlurln,$brand['name']),$_G['cache']['plugin']['aljbdx']['receipt_tips']);
                    foreach($groupids as $g_uid){
                        notification_add($g_uid['uid'], 'system',$mes);
                    }
                }
                //s ������Ա������Ϣ
                if($_G['cache']['plugin']['aljbdx']['receipt_tips_brand']){

                    $mes_brand = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],$orderlurln,$brand['name']),$_G['cache']['plugin']['aljbdx']['receipt_tips_brand']);
                    notification_add($brand['uid'], 'system',$mes_brand);
                }
            }else{
                DB::query("update %t set status=3 where orderid = %s and status=4",array('aljbd_goods_order',$order['orderid']));
            }
        }else if($order['payment'] == 7 && $order['order_type'] == 7){//�����Ź�����
            self::handleStoreChief($order);
            
        }else if($order['payment'] == 6){
            DB::query("update %t set status=4 WHERE status=3 and orderid=%s ",array('aljbd_goods_order_list',$order['orderid']));
            $orderlurln = '/plugin.php?id=aljbd&act=orderlist';
            $brand = C::t('#aljbd#aljbd') -> fetch($order['shop_id']);
            if($order['give_integral']>0){
                updatemembercount(
                    $order['uid'],
                    array($_G['cache']['plugin']['aljbdx']['exttype'] => intval($order['give_integral'])),
                    '',
                    '',
                    '',
                    '',
                    lang("plugin/aljbdx","receipt_php_1"),
                    lang("plugin/aljbdx","receipt_php_2") . $order['give_integral'] . $_G['setting']['extcredits'][$_G['cache']['plugin']['aljbdx']['exttype']]['title'] . lang("plugin/aljbdx","receipt_php_3") . $order['orderid']);
            }
            if($order['cid'] > 0 && $_G['cache']['plugin']['aljpyh']['close_no_pay']){
                require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/butie_aljqb.php';
            }
            if($_G['cache']['plugin']['aljpyh']['is_aljpyh']){
                require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/sendconsume_receipt.php';
                require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/use_sendconsume_receipt.php';
                require_once DISCUZ_ROOT .'source/plugin/aljpyh/include/sendconsume_goods_receipt.php';
            }
            if($order['give_integral']>0){
                    updatemembercount(
                        $order['uid'],
                        array($_G['cache']['plugin']['aljbdx']['exttype'] => intval($order['give_integral'])),
                        '',
                        '',
                        '',
                        '',
                        lang("plugin/aljbdx","receipt_php_1"),
                        lang("plugin/aljbdx","receipt_php_2") . $order['give_integral'] . $_G['setting']['extcredits'][$_G['cache']['plugin']['aljbdx']['exttype']]['title'] . lang("plugin/aljbdx","receipt_php_3") . $order['orderid']);
                }
            //s ������Ա������Ϣ
            if($_G['cache']['plugin']['aljbdx']['receipt_tips']){
                $groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
                $mes = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],$orderlurln,$brand['name']),$_G['cache']['plugin']['aljbdx']['receipt_tips']);
                foreach($groupids as $g_uid){
                    notification_add($g_uid['uid'], 'system',$mes);
                }
            }
            //s ���̼ҷ�����Ϣ
            if($_G['cache']['plugin']['aljbdx']['receipt_tips_brand']){
    
                $mes_brand = str_replace(array('{username}','{url}','{shopname}'),array($order['username'],$orderlurln,$brand['name']),$_G['cache']['plugin']['aljbdx']['receipt_tips_brand']);
                notification_add($brand['uid'], 'system',$mes_brand);
            }
        }
    }
    /**
     * ȷ���ջ����������ֵ�
     *
     * @param array() $order ��������
     * @param array() $brand ��������
     * @return void
     */
    public static function fx_receipt ($order,$brand=array()) {
        global $_G;
        if(!$brand){
            $brand = C::t('#aljbd#aljbd') -> fetch($order['shop_id']);
        }
        require_once DISCUZ_ROOT . './source/plugin/aljqb/class/Qbapi.class.php';
        $payment = new Qbapi();
        $fxinfo = DB::fetch_first('select * from %t where uid=%d ', array('aljsfx_user', $order['uid']));
        $shopdata = DB::fetch_first('select * from %t where uid=%d',array('aljsfx_shop',$order['uid']));
        if($shopdata && ($shopdata['rankendtime'] == 0 || $shopdata['rankendtime'] > TIMESTAMP)){
            $rankdata = DB::fetch_first('select * from %t where id=%d',array('aljsfx_rank',$shopdata['rankid']));
            if($rankdata['open_mypay']){
                if($fxinfo['first_leader_uid']>0){//һ����ID
                    if($fxinfo['second_leader_uid']>0 && $fxinfo['first_leader_uid'] != $fxinfo['second_leader_uid']){//ԭ��������ID��Ϊ������ID
                        $fxinfo['second_leader_uid'] = $fxinfo['second_leader_uid'];
                    }
                    $fxinfo['second_leader_uid'] = $fxinfo['first_leader_uid'];//ԭ1������ID��Ϊ2����ID
                }
                $fxinfo['first_leader_uid'] = $order['uid'];//1����Ϊ������
            }
        }
        
        $fx_gs = DB::fetch_all('select * from %t where orderid=%s',array('aljbd_goods_order_list',$order['orderid']));
        
        foreach($fx_gs as $f_k => $fx_goods){
            
            if($fxinfo && $fx_goods['is_distribution'] && $fx_goods['dis_commission']>0){
                $fx_goods_price = substr(sprintf("%.3f",$fx_goods['price'] * $fx_goods['num'] * ($fx_goods['dis_commission']/100)),0,-1);//��Ʒ����Ӷ�����
                
                if($fxinfo['first_leader_uid']>0){//һ����ID
                    //��������������
                    $first_shopdata = DB::fetch_first('select a.username,b.* from %t a left join %t b on a.rankid=b.id where a.uid=%d and a.status=1',array('aljsfx_shop','aljsfx_rank',$fxinfo['first_leader_uid']));
                    if($first_shopdata && $first_shopdata['first_scale']>0){
                        $first_fee = substr(sprintf("%.3f",$fx_goods_price*($first_shopdata['first_scale']/100)),0,-1);//һ�������̽������
                        
                        if($first_fee>0){
                            
                            $first_insert = array(
                                'orderid' => $order['orderid'],
                                'timestamp' => TIMESTAMP,
                                'beneficiary_uid' => $fxinfo['first_leader_uid'],
                                'beneficiary_username' => $first_shopdata['username'],
                                'payment_days' => $first_shopdata['payment_days'],
                                'uid' => $order['uid'],
                                'username' => $order['username'],
                                'money' => $first_fee,
                                'scale' => $first_shopdata['first_scale'],
                                'status' => 1,
                                'name' => $fx_goods['name'],
                                'price' => $fx_goods['price'],
                                'num' => $fx_goods['num'],
                                'goods_id' => $fx_goods['goods_id'],
                                'dis_commission' => $fx_goods['dis_commission'],
                            );
                            DB::insert('aljsfx_order',$first_insert);
                            DB::query('update %t set total_commission=total_commission+%i where uid=%d',array('aljsfx_shop',$first_fee,$fxinfo['first_leader_uid']));
                            notification_add($fxinfo['first_leader_uid'], 'system',lang("plugin/aljsfx","receipt_php_1").$order['username'].lang("plugin/aljsfx","receipt_php_2").$order['stitle'].lang("plugin/aljsfx","receipt_php_3").$first_fee.lang("plugin/aljsfx","receipt_php_4").'<a href="plugin.php?id=aljsfx&a=order&c=distribution">'.lang("plugin/aljsfx","receipt_php_5").'</a>',array('from_idtype'  => 'aljsfx','from_id' =>$fxinfo['first_leader_uid']));
                        }
                    }
                }
                if($fxinfo['second_leader_uid']>0 && $fxinfo['first_leader_uid'] != $fxinfo['second_leader_uid']){//��������ID
                    //��������������
                    $second_shopdata = DB::fetch_first('select a.username,b.* from %t a left join %t b on a.rankid=b.id where a.uid=%d and a.status=1',array('aljsfx_shop','aljsfx_rank',$fxinfo['second_leader_uid']));
                    if($second_shopdata && $second_shopdata['second_scale']>0){
                        $second_fee = substr(sprintf("%.3f",$fx_goods_price*($second_shopdata['second_scale']/100)),0,-1);//���������̽������
                        if($second_fee>0){
                            
                            $second_insert = array(
                                'orderid' => $order['orderid'],
                                'timestamp' => TIMESTAMP,
                                'beneficiary_uid' => $fxinfo['second_leader_uid'],
                                'beneficiary_username' => $second_shopdata['username'],
                                'payment_days' => $second_shopdata['payment_days'],
                                'uid' => $order['uid'],
                                'username' => $order['username'],
                                'money' => $second_fee,
                                'scale' => $second_shopdata['second_scale'],
                                'status' => 1,
                                'level' => 1,
                                'name' => $fx_goods['name'],
                                'price' => $fx_goods['price'],
                                'num' => $fx_goods['num'],
                                'goods_id' => $fx_goods['goods_id'],
                                'dis_commission' => $fx_goods['dis_commission'],
                            );
                            DB::insert('aljsfx_order',$second_insert);
                            DB::query('update %t set total_commission=total_commission+%i where uid=%d',array('aljsfx_shop',$second_fee,$fxinfo['second_leader_uid']));
                            notification_add($fxinfo['second_leader_uid'], 'system',lang("plugin/aljsfx","receipt_php_6").$order['username'].lang("plugin/aljsfx","receipt_php_7").$order['stitle'].lang("plugin/aljsfx","receipt_php_8").$second_fee.lang("plugin/aljsfx","receipt_php_9").'<a href="plugin.php?id=aljsfx&a=order&c=distribution">'.lang("plugin/aljsfx","receipt_php_10").'</a>',array('from_idtype'  => 'aljsfx','from_id' =>$fxinfo['second_leader_uid']));
                        }
                    }
                }
                if($fxinfo['third_leader_uid']>0){//��������ID
                    //��������������
                    $third_shopdata = DB::fetch_first('select a.username,b.* from %t a left join %t b on a.rankid=b.id where a.uid=%d and a.status=1',array('aljsfx_shop','aljsfx_rank',$fxinfo['third_leader_uid']));
                    if($third_shopdata && $third_shopdata['second_scale']>0){
                        $third_fee = substr(sprintf("%.3f",$fx_goods_price*($third_shopdata['third_scale']/100)),0,-1);//���������̽������
                        if($third_fee>0){
                            
                            $third_insert = array(
                                'orderid' => $order['orderid'],
                                'timestamp' => TIMESTAMP,
                                'beneficiary_uid' => $fxinfo['third_leader_uid'],
                                'beneficiary_username' => $third_shopdata['username'],
                                'payment_days' => $third_shopdata['payment_days'],
                                'uid' => $order['uid'],
                                'username' => $order['username'],
                                'money' => $third_fee,
                                'scale' => $third_shopdata['third_scale'],
                                'status' => 1,
                                'level' => 2,
                                'name' => $fx_goods['name'],
                                'price' => $fx_goods['price'],
                                'num' => $fx_goods['num'],
                                'goods_id' => $fx_goods['goods_id'],
                                'dis_commission' => $fx_goods['dis_commission'],
                            );
                            DB::insert('aljsfx_order',$third_insert);
                            DB::query('update %t set total_commission=total_commission+%i where uid=%d',array('aljsfx_shop',$third_fee,$fxinfo['third_leader_uid']));
                            notification_add($fxinfo['third_leader_uid'], 'system',lang("plugin/aljsfx","receipt_php_11").$order['username'].lang("plugin/aljsfx","receipt_php_12").$order['stitle'].lang("plugin/aljsfx","receipt_php_13").$third_fee.lang("plugin/aljsfx","receipt_php_14").'<a href="plugin.php?id=aljsfx&a=order&c=distribution">'.lang("plugin/aljsfx","receipt_php_15").'</a>',array('from_idtype'  => 'aljsfx','from_id' =>$fxinfo['third_leader_uid']));
                        }
                    }
                }
            }
            if($fx_goods['is_distribution'] && $fx_goods['dis_commission']>0){
                $fx_goods_prices += $fx_goods['price'] * $fx_goods['num'] * ($fx_goods['dis_commission']/100);//��Ʒ����Ӷ�����
                
            }
            unset($first_shopdata);
            unset($second_shopdata);
            unset($third_shopdata);
            unset($third_fee);
            unset($second_fee);
            unset($first_fee);
            
        }
        
        if($fx_goods_prices>0){
            sleep(1);
            $fx_goods_price = substr(sprintf("%.3f",$fx_goods_prices),0,-1);//��Ʒ����Ӷ�����
            //����Ǯ�� -money
            $queuearray = array(
                'app_name' => 'aljbdx',
                'app_type' => 'aljbdx_txcancel',
                'app_phone' => '123456789',
                'app_ip' => $_G['clientip'],
            );
            $balancearray = array(
                'type'=> 'take',
                'uid'=>$brand['uid'],
                'price' => $fx_goods_price,
                'orderid'=> $order['orderid'],
                'desc'=> str_replace(array('{money}'),array($fx_goods_price),lang("plugin/aljbdx","receipt_php_5")),
            );
            $result_take_fx = $payment -> balance($queuearray,$balancearray);
            //����Ǯ��
            return $fx_goods_prices;
        }
        return 0;
    }
    /**
     * ȷ���ջ����������ֵ�
     *
     * @param array() $order ��������
     * @return void
     */
    public static function fx_receipt_sqtg ($order) {
        global $_G;
        
        $fxinfo = DB::fetch_first('select * from %t where uid=%d ', array('aljsfx_user', $order['uid']));
        $shopdata = DB::fetch_first('select * from %t where uid=%d',array('aljsfx_shop',$order['uid']));
        if($shopdata && ($shopdata['rankendtime'] == 0 || $shopdata['rankendtime'] > TIMESTAMP)){
            $rankdata = DB::fetch_first('select * from %t where id=%d',array('aljsfx_rank',$shopdata['rankid']));
            if($rankdata['open_mypay']){
                if($fxinfo['first_leader_uid']>0){//һ����ID
                    if($fxinfo['second_leader_uid']>0 && $fxinfo['first_leader_uid'] != $fxinfo['second_leader_uid']){//ԭ��������ID��Ϊ������ID
                        $fxinfo['second_leader_uid'] = $fxinfo['second_leader_uid'];
                    }
                    $fxinfo['second_leader_uid'] = $fxinfo['first_leader_uid'];//ԭ1������ID��Ϊ2����ID
                }
                $fxinfo['first_leader_uid'] = $order['uid'];//1����Ϊ������
            }
        }
        
        $fx_gs = DB::fetch_all('select * from %t where orderid=%s',array('aljbd_goods_order_list',$order['orderid']));
        
        foreach($fx_gs as $f_k => $fx_goods){
            
            if($fxinfo && $fx_goods['is_distribution'] && $fx_goods['dis_commission']>0){
                $fx_goods_price = substr(sprintf("%.3f",$fx_goods['price'] * $fx_goods['num'] * ($fx_goods['dis_commission']/100)),0,-1);//��Ʒ����Ӷ�����
                
                if($fxinfo['first_leader_uid']>0){//һ����ID
                    //��������������
                    $first_shopdata = DB::fetch_first('select a.username,b.* from %t a left join %t b on a.rankid=b.id where a.uid=%d and a.status=1',array('aljsfx_shop','aljsfx_rank',$fxinfo['first_leader_uid']));
                    if($first_shopdata && $first_shopdata['first_scale']>0){
                        $first_fee = substr(sprintf("%.3f",$fx_goods_price*($first_shopdata['first_scale']/100)),0,-1);//һ�������̽������
                        
                        if($first_fee>0){
                            
                            $first_insert = array(
                                'orderid' => $order['orderid'],
                                'timestamp' => TIMESTAMP,
                                'beneficiary_uid' => $fxinfo['first_leader_uid'],
                                'beneficiary_username' => $first_shopdata['username'],
                                'payment_days' => $first_shopdata['payment_days'],
                                'uid' => $order['uid'],
                                'username' => $order['username'],
                                'money' => $first_fee,
                                'scale' => $first_shopdata['first_scale'],
                                'status' => 1,
                                'name' => $fx_goods['name'],
                                'price' => $fx_goods['price'],
                                'num' => $fx_goods['num'],
                                'goods_id' => $fx_goods['goods_id'],
                                'dis_commission' => $fx_goods['dis_commission'],
                            );
                            DB::insert('aljsfx_order',$first_insert);
                            DB::query('update %t set total_commission=total_commission+%i where uid=%d',array('aljsfx_shop',$first_fee,$fxinfo['first_leader_uid']));
                            notification_add($fxinfo['first_leader_uid'], 'system',lang("plugin/aljsfx","receipt_php_1").$order['username'].lang("plugin/aljsfx","receipt_php_2").$order['stitle'].lang("plugin/aljsfx","receipt_php_3").$first_fee.lang("plugin/aljsfx","receipt_php_4").'<a href="plugin.php?id=aljsfx&a=order&c=distribution">'.lang("plugin/aljsfx","receipt_php_5").'</a>',array('from_idtype'  => 'aljsfx','from_id' =>$fxinfo['first_leader_uid']));
                        }
                    }
                }
                if($fxinfo['second_leader_uid']>0 && $fxinfo['first_leader_uid'] != $fxinfo['second_leader_uid']){//��������ID
                    //��������������
                    $second_shopdata = DB::fetch_first('select a.username,b.* from %t a left join %t b on a.rankid=b.id where a.uid=%d and a.status=1',array('aljsfx_shop','aljsfx_rank',$fxinfo['second_leader_uid']));
                    if($second_shopdata && $second_shopdata['second_scale']>0){
                        $second_fee = substr(sprintf("%.3f",$fx_goods_price*($second_shopdata['second_scale']/100)),0,-1);//���������̽������
                        if($second_fee>0){
                            
                            $second_insert = array(
                                'orderid' => $order['orderid'],
                                'timestamp' => TIMESTAMP,
                                'beneficiary_uid' => $fxinfo['second_leader_uid'],
                                'beneficiary_username' => $second_shopdata['username'],
                                'payment_days' => $second_shopdata['payment_days'],
                                'uid' => $order['uid'],
                                'username' => $order['username'],
                                'money' => $second_fee,
                                'scale' => $second_shopdata['second_scale'],
                                'status' => 1,
                                'level' => 1,
                                'name' => $fx_goods['name'],
                                'price' => $fx_goods['price'],
                                'num' => $fx_goods['num'],
                                'goods_id' => $fx_goods['goods_id'],
                                'dis_commission' => $fx_goods['dis_commission'],
                            );
                            DB::insert('aljsfx_order',$second_insert);
                            DB::query('update %t set total_commission=total_commission+%i where uid=%d',array('aljsfx_shop',$second_fee,$fxinfo['second_leader_uid']));
                            notification_add($fxinfo['second_leader_uid'], 'system',lang("plugin/aljsfx","receipt_php_6").$order['username'].lang("plugin/aljsfx","receipt_php_7").$order['stitle'].lang("plugin/aljsfx","receipt_php_8").$second_fee.lang("plugin/aljsfx","receipt_php_9").'<a href="plugin.php?id=aljsfx&a=order&c=distribution">'.lang("plugin/aljsfx","receipt_php_10").'</a>',array('from_idtype'  => 'aljsfx','from_id' =>$fxinfo['second_leader_uid']));
                        }
                    }
                }
                if($fxinfo['third_leader_uid']>0){//��������ID
                    //��������������
                    $third_shopdata = DB::fetch_first('select a.username,b.* from %t a left join %t b on a.rankid=b.id where a.uid=%d and a.status=1',array('aljsfx_shop','aljsfx_rank',$fxinfo['third_leader_uid']));
                    if($third_shopdata && $third_shopdata['second_scale']>0){
                        $third_fee = substr(sprintf("%.3f",$fx_goods_price*($third_shopdata['third_scale']/100)),0,-1);//���������̽������
                        if($third_fee>0){
                            
                            $third_insert = array(
                                'orderid' => $order['orderid'],
                                'timestamp' => TIMESTAMP,
                                'beneficiary_uid' => $fxinfo['third_leader_uid'],
                                'beneficiary_username' => $third_shopdata['username'],
                                'payment_days' => $third_shopdata['payment_days'],
                                'uid' => $order['uid'],
                                'username' => $order['username'],
                                'money' => $third_fee,
                                'scale' => $third_shopdata['third_scale'],
                                'status' => 1,
                                'level' => 2,
                                'name' => $fx_goods['name'],
                                'price' => $fx_goods['price'],
                                'num' => $fx_goods['num'],
                                'goods_id' => $fx_goods['goods_id'],
                                'dis_commission' => $fx_goods['dis_commission'],
                            );
                            DB::insert('aljsfx_order',$third_insert);
                            DB::query('update %t set total_commission=total_commission+%i where uid=%d',array('aljsfx_shop',$third_fee,$fxinfo['third_leader_uid']));
                            notification_add($fxinfo['third_leader_uid'], 'system',lang("plugin/aljsfx","receipt_php_11").$order['username'].lang("plugin/aljsfx","receipt_php_12").$order['stitle'].lang("plugin/aljsfx","receipt_php_13").$third_fee.lang("plugin/aljsfx","receipt_php_14").'<a href="plugin.php?id=aljsfx&a=order&c=distribution">'.lang("plugin/aljsfx","receipt_php_15").'</a>',array('from_idtype'  => 'aljsfx','from_id' =>$fxinfo['third_leader_uid']));
                        }
                    }
                }
            }
            if($fx_goods['is_distribution'] && $fx_goods['dis_commission']>0){
                $fx_goods_prices += $fx_goods['price'] * $fx_goods['num'] * ($fx_goods['dis_commission']/100);//��Ʒ����Ӷ�����
                
            }
            unset($first_shopdata);
            unset($second_shopdata);
            unset($third_shopdata);
            unset($third_fee);
            unset($second_fee);
            unset($first_fee);
            
        }
        
        if($fx_goods_prices>0){
            
            return $fx_goods_prices;
        }
        return 0;
    }
    public function aljreg_fee ($order) {
        global $_G;
        $aljreg_info = DB::fetch_first('select * from %t where uid=%d ', array('aljreg_invite', $order['uid']));
        $fromuid = $aljreg_info['fromuid'];
        if($fromuid > 0 && $aljreg_info['order_time']<=0){
            DB::query('update %t set is_order=1,order_time=%d where uid =%d',array('aljreg_invite',$order['confirmdate'], $order['uid']));
        }
        $new_order_num = DB::result_first('select count(*) from %t where uid=%d and status>3 and pid=0',array('aljbd_goods_order',$_G['uid']));
        if($_G['cache']['plugin']['aljbdx']['reg_type'] == 1){
            $order['price'] = $fee;
        }
        if($_G['cache']['plugin']['aljbdx']['new_regfee'] && $new_order_num<=1){
            $regfee = sprintf("%.2f",$order['price']*($_G['cache']['plugin']['aljbdx']['new_regfee']/100));//�׵���ɱ���
        }else {
            $regfee = sprintf("%.2f", $order['price'] * ($_G['cache']['plugin']['aljbdx']['regfee'] / 100));//
        }
        if($fromuid>0 && $regfee>0){
            //����Ǯ�� +money
            $queuearray = array(
                'app_name' => 'aljbdx',
                'app_type' => 'aljbdx_txcancel',
                'app_phone' => '123456789',
                'app_ip' => $_G['clientip'],
            );
            $balancearray = array(
                'type'=> 'charge',
                'uid'=>$fromuid,
                'price' => $regfee,
                'orderid'=> $order['orderid'],
                'desc'=> str_replace(array('{username}','{money}'),array($order['username'].lang('plugin/aljbd','r_danyinghao'),$regfee),$_G['cache']['plugin']['aljbdx']['qb_desc_regfee']),
            );
            $result_reg = $payment -> balance($queuearray,$balancearray);

            //����Ǯ��
            if($result_reg['code'] == '200'){
                //notification_add($fromuid,'system','���ƹ���û� '.$order['username'].' �������Ʒ��ȷ���ջ���������ƹ㽱��'.$regfee.lang("plugin/aljbdx","receipt_php_4"));
            }
        }
    }
}
//class O extends aljbdx {}
?>