<?php

define('DISABLEXSSCHECK', true);

require '../../../../source/class/class_core.php';

$discuz = C::app();

$cachelist = array('plugin');

$discuz->cachelist = $cachelist;
$discuz->init();
loadcache('plugin');

echo $_G['cache']['plugin']['aljtht']['is_aljhtx'];
exit;