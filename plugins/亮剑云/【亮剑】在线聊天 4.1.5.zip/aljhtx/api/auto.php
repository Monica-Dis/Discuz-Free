<?php
if(file_exists('../../../../source/class/class_core.php')) {
    define('DISABLEXSSCHECK', true);
    require_once '../../../../source/class/class_core.php';
    $discuz = C::app();
    $cachelist = array('plugin');
    $discuz->cachelist = $cachelist;
    $discuz->init();
    loadcache('plugin');
    $_G['siteurl'] = str_replace('source/plugin/aljhtx/api', '',$_G['siteurl'] );
}
require_once DISCUZ_ROOT .'source/plugin/aljqb/class/Qbapi.class.php';
            
$qbapi = new Qbapi();
$queue = $qbapi;

$aljqbsettings = $qbapi -> getsettings();

require_once DISCUZ_ROOT .'source/plugin/aljqb/function/function_core.php';
require_once DISCUZ_ROOT . './source/plugin/aljhtx/class/class_aljbdx.php';
aljbdx::start();
