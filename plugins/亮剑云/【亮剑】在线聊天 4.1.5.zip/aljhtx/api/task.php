<?php
if(file_exists('../../../../source/class/class_core.php')) {
    define('DISABLEXSSCHECK', true);
    require_once '../../../../source/class/class_core.php';
    $discuz = C::app();
    $cachelist = array('plugin');
    $discuz->cachelist = $cachelist;
    $discuz->init();
    loadcache('plugin');
    $_G['siteurl'] = str_replace('source/plugin/aljhtx/api', '',$_G['siteurl'] );
}

require_once DISCUZ_ROOT .'source/plugin/aljhtx/class/class_aljhtx.php';
require_once DISCUZ_ROOT .'source/plugin/aljhtx/class/class_cron.php';
Cron::start();
$script_list = DB::fetch_all('select * from %t where open = %s', array('aljhtx_cron_script', 'on'));

foreach($script_list as $script){
    if(is_file(DISCUZ_ROOT . './'.$script['file']) && $script['last']+$script['cycle'] < TIMESTAMP){
        //debug(DISCUZ_ROOT . './'.$script['file']);
        include_once DISCUZ_ROOT . './'.$script['file'];
        DB::query('update %t set last=%d where id=%d', array('aljhtx_cron_script', TIMESTAMP, $script['id']));
    }
}
echo 1;
exit;
