<?php
defined('APP_CRON_PATH') or define('APP_CRON_PATH', dirname(__FILE__).'/task.php');

$cmd = popen('ps -ef | grep "'.APP_CRON_PATH.'" | grep -v grep', 'r');

while(!feof($cmd)) {
 $buffer = fgets($cmd);
 $process[]=$buffer;
}

pclose($cmd);

$line=join("\n", $process);
if(empty($line)){
 $out = popen('/www/server/php/'.substr(str_replace('.', '', PHP_VERSION), 0, 2).'/bin/php '.APP_CRON_PATH, 'r');
 pclose($out);
}
