<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($order['commodity_type'] == 2
    && $_G['cache']['plugin']['mapp_template']
    && $_G['cache']['plugin']['aljhtx']
    && (DB::fetch_first('select * from %t where type=%s', array('aljhtx_wechat_bindtemplate', 'participationInSuccessfulSpellingNotice'))
        || DB::fetch_first('select * from %t where type=%s', array('aljhtx_wechat_bindtemplate', 'successfulSpellingNotice'))
        || DB::fetch_first('select * from %t where type=%s', array('aljhtx_wechat_bindtemplate', 'successfulReminderOfTheStartOfTheMission')))
){
    $group=DB::fetch_first('select * from %t where grouporderid=%s ',array('aljspt_collage_order', $order['collage_order']));
    if($group['groupheaduid'] != $order['uid'] || ($group['groupheaduid'] == $order['uid'] && $order['amount'] == 1)) {//����
        if ($order['amount'] == 1 && $order['status']<6 && DB::fetch_first('select * from %t where type=%s', array('aljhtx_wechat_bindtemplate', 'successfulSpellingNotice'))) {//ƴ���ɹ�֪ͨ
            $pt_ordergroup_tmp=DB::fetch_all('select * from %t where collage_order=%s and status=%d order by confirmdate asc',array('aljbd_goods_order',$order['collage_order'],2));
            $pt_username = array();
            foreach($pt_ordergroup_tmp as $tmp_key => $tmp_value){
                $pt_username[] = $tmp_value['username'];
            }
            $param = array(
                'order_subject' => lang("plugin/aljhtx","purchaser_send_template_php_2"),
                'title' => $order['stitle'],
                'order_member' => implode(lang("plugin/aljhtx","purchaser_send_template_php_1"),$pt_username),
                'order_content' => lang("plugin/aljhtx","purchaser_send_template_php_3"),
                'type' => 'successfulSpellingNotice',
                'news_type' => 1,
                'logo' => $f_goods_info['pic1']
            );
            foreach($pt_ordergroup_tmp as $tmp_key => $tmp_value){
                T::aljbd_notification($tmp_value['uid'],$param,'plugin.php?id=aljspt&c=groupOrder&a=ptOrder');
            }

        }else if (DB::fetch_first('select * from %t where type=%s', array('aljhtx_wechat_bindtemplate', 'participationInSuccessfulSpellingNotice'))) {//�μ�ƴ���ɹ�֪ͨ
            $param = array(
                'order_subject' => lang("plugin/aljhtx","purchaser_send_template_php_4"),
                'title' => $order['stitle'],
                'order_time' => dgmdate($order['confirmdate'],'Y-m-d H:i:s'),
                'order_content' => lang("plugin/aljhtx","purchaser_send_template_php_5"),
                'type' => 'participationInSuccessfulSpellingNotice',
                'news_type' => 1,
                'logo' => $f_goods_info['pic1']
            );
            T::aljbd_notification($order['uid'],$param,'plugin.php?id=aljspt&c=groupOrder&a=ptOrder');
        }
    }else{//����
        if (DB::fetch_first('select * from %t where type=%s', array('aljhtx_wechat_bindtemplate', 'successfulReminderOfTheStartOfTheMission'))) {
            $group=DB::fetch_first('select * from %t where grouporderid=%s ',array('aljspt_collage_order', $order['collage_order']));
            $grouptime=$_G['cache']['plugin']['aljspt']['grouptime']?intval($_G['cache']['plugin']['aljspt']['grouptime'])*3600 : 86400;
            $param = array(
                'order_subject' => lang("plugin/aljhtx","purchaser_send_template_php_6"),
                'title' => $order['stitle'],
                'order_price' => $order['price'],
                'colonel' => $group['groupheadusername'],
                'group_number' => $group['groupnum'],
                'deadline' => dgmdate($group['create_time']+$grouptime,'Y-m-d H:i:s'),
                'order_content' => lang("plugin/aljhtx","purchaser_send_template_php_7"),
                'type' => 'successfulReminderOfTheStartOfTheMission',
                'news_type' => 1,
                'logo' => $f_goods_info['pic1']
            );
            T::aljbd_notification($order['uid'],$param,'plugin.php?id=aljspt&c=groupOrder&a=ptOrder');
        }
    }
}else if($_G['cache']['plugin']['mapp_template'] && $_G['cache']['plugin']['aljhtx'] && DB::fetch_first('select * from %t where type=%s',
        array(
            'aljhtx_wechat_bindtemplate',
            'buyNotificationUser'
        ))){
    $param = array(
        'order_subject' => lang("plugin/aljhtx","purchaser_send_template_php_8"),
        'order_title' => $order['stitle'],
        'order_id' => $orderid,
        'order_price' => $order['price'].lang("plugin/aljhtx","purchaser_send_template_php_9"),
        'order_paytime' => dgmdate($order['confirmdate'],'Y-m-d H:i:s'),
        'order_content' => lang("plugin/aljhtx","purchaser_send_template_php_10"),
        'type' => 'buyNotificationUser',
        'news_type' => 1,
        'logo' => $f_goods_info['pic1']
    );
    if($order['commodity_type'] == 2){
        $param['order_subject'] = lang("plugin/aljhtx","purchaser_send_template_php_11");
        if($order['amount'] == 1 && $order['status']<6){
            $param['order_subject'] .= lang("plugin/aljhtx","purchaser_send_template_php_12");
        }else{
            $param['order_subject'] .= lang("plugin/aljhtx","purchaser_send_template_php_13");
        }
        $orderlurln = 'plugin.php?id=aljspt&c=groupOrder&a=ptOrder';
    }
    
    T::aljbd_notification($order['uid'],$param,$orderlurln);
}else{
    
    notification_add($order['uid'], 'system', str_replace('{username}', $order['username'], str_replace('{shopname}', $order['stitle'], $_G['cache']['plugin'][$pluginid]['suctips'])) . ' <a href="' . $orderlurln . '">' . lang('plugin/aljgwc', 'View_orders') . '</a>');
}
?>