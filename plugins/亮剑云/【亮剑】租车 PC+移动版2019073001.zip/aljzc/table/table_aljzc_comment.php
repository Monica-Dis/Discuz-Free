<?php

/*
 * DisM!Ӧ������(dism.taobao.com)
 * QQȺ: 778390776
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljzc_comment extends discuz_table {

    public function __construct() {

        $this->_table = 'aljzc_comment';
        $this->_pk = 'id';

        parent::__construct();
    }

    public function fetch_all_by_upid($upid=0,$lid=0){
		return DB::fetch_all('select * from %t where upid=%d and lid=%d  order by id desc',array($this->_table,$upid,$lid));
	}
	public function count_by_bid_all($nid=0){
		return DB::result_first('select count(*) from %t where lid=%d',array($this->_table,$nid));
	}
	public function fetch_all_by_bid_page($nid=0,$start=0,$perpage=0){
		return DB::fetch_all('select * from %t where lid=%d order by id desc limit %d,%d ',array($this->_table,$nid,$start,$perpage));
	}

}
//From: Dism_taobao_com
?>