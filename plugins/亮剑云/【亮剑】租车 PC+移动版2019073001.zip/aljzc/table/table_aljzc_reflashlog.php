<?php
/*
 * DisM!Ӧ������(dism.taobao.com)
 * QQȺ: 778390776
 *
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljzc_reflashlog extends discuz_table{
	public function __construct() {

			$this->_table = 'aljzc_reflashlog';
			$this->_pk    = 'id';

			parent::__construct();
	}
       

}




?>