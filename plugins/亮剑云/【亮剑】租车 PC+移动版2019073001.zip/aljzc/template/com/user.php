<?php

/*
 * DisM!Ӧ������(dism.taobao.com)
 * QQȺ: 778390776
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$currpage = $_GET['page'] ? $_GET['page'] : 1;
$perpage = $config['page'];
$num = C::t('#aljzc#aljzc_user')->count();
$start = ($currpage - 1) * $perpage;

$users = C::t('#aljzc#aljzc_user')->range($start, $perpage, 'desc');
$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljzc&act=adminuser', 0, 11, false, false);
$navtitle = $config['title'];
$metakeywords = $config['keywords'];
$metadescription = $config['description'];
if($aljzc_seo['adminuser']['seotitle']){
	$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
	list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzc_seo['adminuser']);
}
include template('aljzc:adminuser');
?>