<?php

/*
 * DisM!Ӧ������(dism.taobao.com)
 * QQȺ: 778390776
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$currpage = $_GET['page'] ? $_GET['page'] : 1;
$perpage = $config['page'];
$conndtion = array(
    'uid' => $_GET['uid'],
    'search' => $_GET['search'],
);
$num = C::t('#aljzc#aljzc')->count_by_status($conndtion);
$start = ($currpage - 1) * $perpage;

$lplist = C::t('#aljzc#aljzc')->fetch_all_by_addtime($start, $perpage, $conndtion);
$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljzc&act=adminlp&search='.$_GET['search'], 0, 11, false, false);
$users = C::t('#aljzc#aljzc_user')->range();
$navtitle = $config['title'];
$metakeywords = $config['keywords'];
$metadescription = $config['description'];
if($aljzc_seo['adminlp']['seotitle']){
	$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
	list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzc_seo['adminlp']);
}
include template('aljzc:adminlp');
?>