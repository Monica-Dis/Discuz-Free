<?php

/*
 * DisM!Ӧ������(dism.taobao.com)
 * QQȺ: 778390776
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (submitcheck('formhash')) {
	if(empty($_GET['lid'])){
		tips_mes(lang('plugin/aljzc','aljzc_8'));
	}
	if($_GET['days']<0){
		 
		if($_G['mobile']){
			echo "<script>parent.tips('".lang('plugin/aljzc','top_3')."','');</script>";
			exit;
		}else{
			showerror(lang('plugin/aljzc','top_3'));
		}
	}
	$lp=C::t('#aljzc#aljzc')->fetch($_GET['lid']);
	$insertid=C::t('#aljzc#aljzc_toplog')->insert(array(
		'lid' => $_GET['lid'],
		'uid' => $_G['uid'],
		'username' => $_G['username'],
		'dateline' => TIMESTAMP,
		'endtime' => TIMESTAMP+$_GET['days']*86400,
		'pay' => $_GET['days']*$config['toppay'],
		'extcredit' => $config['topextcredit'],
		'title' => $lp['title'],
		'name' => $lp['username'],
	),true);
	if (getuserprofile('extcredits' . $config['topextcredit']) < ($_GET['days']*$config['toppay'])) {
		if($_G['mobile']){
			if($mobile_integral_recharge){
				echo "<script>parent.tips('".'&#26412;&#27425;&#25805;&#20316;&#38656;&#35201;&#28040;&#32791;'.$_GET['days']*$config['toppay'].$_G['setting']['extcredits'][$config['topextcredit']]['title'].','.$_G['setting']['extcredits'][$config['topextcredit']]['title'] . lang('plugin/aljzc','top_1').$aljzclang['php']['Jumping_up_page']."',function(){parent.location.href='".$mobile_integral_recharge."';});</script>";
			}else{
				echo "<script>parent.tips('".$_G['setting']['extcredits'][$config['topextcredit']]['title'] . lang('plugin/aljzc','top_1')."','');</script>";
			}
			
			exit;
		}else{
			showerror('&#26412;&#27425;&#25805;&#20316;&#38656;&#35201;&#28040;&#32791;'.$_GET['days']*$config['toppay'].$_G['setting']['extcredits'][$config['topextcredit']]['title'].','.$_G['setting']['extcredits'][$config['topextcredit']]['title'] . lang('plugin/aljzc','top_1').$pc_integral_recharge);
		}
	}
	updatemembercount($_G['uid'], array($config['topextcredit'] => '-' .$_GET['days']*$config['toppay']));
	if($lp['topetime']&&TIMESTAMP<$lp['topetime']){
		DB::update('aljzc_toplog',array('endtime'=>$lp['topetime']+$_GET['days']*86400),'id='.$insertid);
		DB::update('aljzc',array('topetime'=>$lp['topetime']+$_GET['days']*86400),'id='.$_GET[lid]);
	}else{
		DB::update('aljzc',array('topstime'=>TIMESTAMP,'topetime'=>TIMESTAMP+$_GET['days']*86400),'id='.$_GET[lid]);
	}
	C::t('#aljzc#aljzc')->update_updatetime_by_id($_GET['lid']);
	C::t('#aljzc#aljzc_user')->update_top_by_uid($_G['uid']);
	if($_G['mobile']){
		echo "<script>parent.tips('".lang('plugin/aljzc','top_2')."',function(){parent.location.href='plugin.php?id=aljzc&act=member"."';});</script>";
		exit;
	}else{
		showmsg(lang('plugin/aljzc','top_2'), 'plugin.php?id=aljzc&act=member');
	}
}else{
	if (getuserprofile('extcredits' . $config['topextcredit']) < $config['toppay']) {
		//tips_mes($_G['setting']['extcredits'][$config['topextcredit']]['title'] . lang('plugin/aljzc','top_1').$pc_integral_recharge);
	}
	$lp=C::t('#aljzc#aljzc')->fetch($_GET['lid']);
	
	if($_G['mobile']){
		$url='plugin.php?id=aljzc&act=top&lid='.$_GET['lid'];
		include template('aljzc:state');
	}else{
		include template('aljzc:addtop');
	}
}
//From: Dism��taobao��com
?>