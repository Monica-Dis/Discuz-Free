<?php

/*
 * DisM!Ӧ������(dism.taobao.com)
 * QQȺ: 778390776
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$file = 'aljzc_qrcode.jpg';	 QRcode::png($_G['siteurl'].'plugin.php?id=aljzc', 'source/plugin/aljzc/images/qrcode/'.$file, QR_MODE_STRUCTURE, 8);
?>