<?php
	if(!defined('IN_DISCUZ')) {
	exit('Access Deined');
}
class mobileplugin_aljzc {
	function index_top_mobile() {
		global $_G;
		$config = $_G ['cache'] ['plugin'] ['aljzc'];
		if(!$config['sjurl']){
			return;
		}
		if (!file_exists(DISCUZ_ROOT . './source/plugin/aljzc/template/mobile/index.htm')) {
			return;
		}
		if($_GET['mobile']=='1'){
			$xian='<span class="pipe">|</span>';
		}else{
			$xian='&nbsp;&nbsp;&nbsp;';
		}
		return $xian.'<a href="plugin.php?id=aljzc">'.$config['daohang'].'</a>';
		
	}
}
class mobileplugin_aljzc_forum extends mobileplugin_aljzc {
}
//From: Dism��taobao��com
?>