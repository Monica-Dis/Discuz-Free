<?php

/*
 * DisM!Ӧ������(dism.taobao.com)
 * QQȺ: 778390776
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$_GET=dhtmlspecialchars($_GET);
$pluginid='aljzc';
if (file_exists("source/plugin/aljgl/include/common.php")) {
    require_once 'source/plugin/aljgl/include/common.php';
}else{
	tips_mes('&#35831;&#20808;&#23433;&#35013;&#20998;&#31867;&#20449;&#24687;&#31649;&#29702;&#22522;&#30784;&#25554;&#20214;');
	exit;
}
require_once libfile('function/discuzcode');
require_once 'source/plugin/aljzc/function/function_core.php';
include_once libfile('function/editor');
require_once DISCUZ_ROOT.'source/plugin/aljzc/class/qrcode.class.php';
if (file_exists("source/plugin/aljzc/template/com/qrcode.php")) {
    if (!file_exists("source/plugin/aljzc/images/qrcode/aljzc_qrcode.jpg")) {
        include 'source/plugin/aljzc/template/com/qrcode.php';
    }
}

$loading = 'source/plugin/'.$pluginid.'/images/loading1.gif';
require_once 'source/plugin/'.$pluginid.'/lang/lang.php';
$login_callback = 'member.php?mod=logging&action=login&referer=plugin.php?id='.$pluginid.'%26act='.$_GET['act'];
$actarray = array('view','ask','list','upload','mupload','mobile_deleteattach','mobile_list_region','mobile_list_type','mobile_index_goods','search');
if($_GET['act'] && !in_array($_GET['act'],$actarray)){
	if(!$_G['uid']){
		dheader("location:".$login_callback);
		exit;
	}
}
//�û���
if ($_G['uid']) {
    if (!C::t('#aljzc#aljzc_user')->fetch($_G['uid'])) {
        C::t('#aljzc#aljzc_user')->insert(array('uid' => $_G['uid'], 'username' => $_G['username'], 'dateline' => TIMESTAMP, 'last' => TIMESTAMP));
    } else {
        C::t('#aljzc#aljzc_user')->update_last_by_uid($_G['uid']);
    }
}
//�û����ʼ�¼
if (!C::t('#aljzc#aljzc_log')->fetch(gmdate('Ymd', TIMESTAMP))) {
    C::t('#aljzc#aljzc_log')->insert(array('day' => gmdate('Ymd', TIMESTAMP), 'views' => 1));
} else {
    C::t('#aljzc#aljzc_log')->update_views_by_day(gmdate('Ymd', TIMESTAMP));
}
$config = $_G['cache']['plugin']['aljzc'];
$aljzc_seo = dunserialize($_G['setting']['aljzc_seo']);
$settings=C::t('#aljzc#aljzc_setting')->range();
if($settings['iswatermark']['value']){
	require_once DISCUZ_ROOT.'source/plugin/aljzc/class/class_image.php';
	$image = new aljbd_image;
}
if($settings['logo']['value']){
    $noimg = $settings['logo']['value'];
}elseif($config['mr_src']){
    $noimg = $config['mr_src'];
}else{
    $noimg = 'source/plugin/'.$pluginid.'/images/noimg.gif';
}
$typelist = explode ("\n", str_replace ("\r", "", $config ['pinpai']));
foreach($typelist as $key=>$value){
	$arr=explode('=',$value);
	$types[$arr[0]]=$arr[1];
}
$paylist = explode ("\n", str_replace ("\r", "", $config ['jg']));
foreach($paylist as $key=>$value){
	$arr=explode('=',$value);
	$pay_types[$arr[0]]=$arr[1];
}
$regions = C::t('#aljzc#aljzc_region')->range();
$shengming=str_replace ("{sitename}", $_G['setting']['bbname'], $config ['shengming']);
if(!$settings['is_new_view']['value']){
	$_G['setting']['switchwidthauto'] = 0;
	$_G['setting']['allowwidthauto'] = 1;
}
$new_index_dh = explode ("\n", str_replace ("\r", "", $settings['new_index_dh']['value']));
foreach($new_index_dh as $key=>$value){
	$arr=explode('|',$value);
	$new_index_dh_types[]=$arr;
}
$lid = intval($_GET['lid']);
$gtypes_tmp = $types;
if($settings['image_path']['value']){
	$image_path = $settings['image_path']['value'];
}else{
	$image_path = 'source/plugin/'.$pluginid.'/images/logo/';
}
if($settings['pc_integral_recharge']['value']){
	$pc_integral_recharge = '<a href="'.str_replace(':','&#58;',$settings['pc_integral_recharge']['value']).'">'.$aljzclang['php']['To_recharge'].'</a>';
}
if($settings['mobile_integral_recharge']['value']){
	$mobile_integral_recharge = htmlspecialchars_decode($settings['mobile_integral_recharge']['value']);
}
if(!$_G['mobile']){
    $mobile_integral_recharge = htmlspecialchars_decode($settings['pc_integral_recharge']['value']);
}
if($_GET['act'] == 'logout'){
    if($_GET['formhash'] == formhash()){
        if (function_exists('clearcookies')) {
            clearcookies();
        }else{
            require libfile('function/member');
            clearcookies();
        }
        $_G['groupid'] = $_G['member']['groupid'] = 7;
        $_G['uid'] = $_G['member']['uid'] = 0;
        $_G['username'] = $_G['member']['username'] = $_G['member']['password'] = '';
        $_G['setting']['styleid'] = $_G['setting'];
        tips_mes('&#36864;&#20986;&#25104;&#21151;','plugin.php?id='.$pluginid);
        exit;
    }else{
        tips_mes('&#35831;&#27714;&#26469;&#36335;&#19981;&#27491;&#30830;&#65281;','plugin.php?id='.$pluginid);
        exit;
    }
}else if($_GET['act'] == 'user'){
	include template('aljzc:user');
}else if($_GET['act'] == 'search'){
	include template($pluginid.':search');
}else if($_GET['act'] == 'mobile_index_goods'){//��ҳ���б���Ϣ
	$con = 'where 1 and state=0';
	$where[] = $pluginid;

	if ($_GET['identity']) {
		$con .= " and identity = %d";
		$where[] = $_GET['identity'];
	}
	if ($_GET['wanted']) {
		$con .= " and wanted = %d";
		$where[] = $_GET['wanted'];
	}
	if ($_GET['pid']) {
		$con .= " and pos = %d";
		$where[] = $_GET['pid'];
	}
	if ($_GET['uid']) {
		$con .= " and uid = %d";
		$where[] = $_GET['uid'];
	}
	if ($_GET['subpid']) {
		$con .= " and pos1 = %d";
		$where[] = $_GET['subpid'];
	}
	if($_GET['rid']){
		$rid = intval($_GET['rid']);
		$con .= ' and region = %d';
		$where[] = $rid;
	}
	if($_GET['subrid']){
		$subrid = intval($_GET['subrid']);
		$con .= ' and region1 = %d';
		$where[] = $subrid;
	}
	if($_GET['subsubrid']){
		$subsubrid = intval($_GET['subsubrid']);
		$con .= ' and region2 = %d';
		$where[] = $subsubrid;
	}
	if($_GET['search']){
		$search = '%'.addcslashes($_GET['search'], '%_').'%';
		$con.= " and title like %s";
		$where[] = $search;
	}
	if ($_GET['pay1']) {
		if(!$_GET['pay2']){
			$where[] = $_GET['pay1'];
			$con.=" and zujin <= %d";
		}else{
			$where[] = $_GET['pay1'];
			$con.=" and zujin >= %d";
		}
	}
	if ($_GET['pay2']) {
		if(!$_GET['pay1']){
			$where[] = $_GET['pay2'];
			$con.=" and zujin >= %d";
		}else{
			$where[] = $_GET['pay2'];
			$con.=" and zujin <= %d";
		}
	}
	if($_GET['order'] == 'publictime'){
		$con .= ' and identity = %d';
		$where[] = 1;
	}else if($_GET['order'] == 'favorate'){
		$con .= ' and identity = %d';
		$where[] = 2;
	}

	$con.= ' order by topetime desc,updatetime desc,addtime desc';
	$num = DB::result_first('select count(*) from %t '.$con,$where);
	$currpage=$_GET['page']?$_GET['page']:1;
	$perpage=$config['page'];
	$start=($currpage-1)*$perpage;

	$max = ceil($num/$perpage);

	if($currpage == 1){
		$max_page ='<input type="hidden" id="max-page" value="'.$max.'">';
	}

	if($currpage == $max){
		$mes = '<div class="c_click_see" id="more" style="float: left;">'.$aljzclang['php']['aljzc_1'].'</div>';
	}
	$where[] = $start;
	$where[] = $perpage;
	$goodslist = DB::fetch_all('select * from %t '.$con.' limit %d,%d',$where);
	foreach($goodslist as $k=>$v){
		$goodslist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
	}
	include template($pluginid.':mobile_index_goods');
}else if ($_GET['act'] == 'mgetregion') {

    if ($_GET['upid']) {
        $rs = C::t('#'.$pluginid.'#'.$pluginid.'_region')->fetch_all_by_upid($_GET['upid']);
    }

    include template($pluginid.':getregion');
}else if($_GET['act']=='mobile_delete'){
	$user=C::t('#aljzc#aljzc')->fetch($_GET['lid']);
	$url='plugin.php?id=aljzc&act=delete&lid='.$_GET['lid'];
	include template('aljzc:state');
}else if($_GET['act']=='admingetregion'){
	if($_GET['upid']){
		$rlist=C::t('#aljzc#aljzc_region')->fetch_all_by_upid_sys($_GET['upid']);
	}
	include template('aljzc:admingetregion');
}else if($_GET['act']=='admingetregion1'){
	if($_GET['upid']){
		$rlist=C::t('#aljzc#aljzc_region')->fetch_all_by_upid_sys($_GET['upid']);
	}
	include template('aljzc:admingetregion1');
}else if($_GET['act'] == 'solve'){
	if (file_exists("source/plugin/aljzc/template/com/solve.php")) {
        include 'source/plugin/aljzc/template/com/solve.php';
    }
}else if($_GET['act'] == 'collection'){

	if (empty($_GET['lid'])) {
        tips_mes(lang('plugin/aljzc','aljzc_6'));
    }
	C::t('#aljzc#aljzc_collection')->insert(array(
		'lid'=>$_GET['lid'],
		'uid'=>$_G['uid'],
		'dateline'=>TIMESTAMP,
	));
	tips_mes(lang('plugin/aljzc','The_success_of'),'plugin.php?id=aljzc&act=view&lid='.$_GET['lid']);
}else if($_GET['act'] == 'collection_list'){

	$currpage = $_GET['page'] ? $_GET['page'] : 1;
    $perpage = $config['page'];
    $num = DB::result_first('select count(*) from %t where uid=%d',array('aljzc_collection',$_G['uid']));
    $start = ($currpage - 1) * $perpage;

    $logs = DB::fetch_all('select * from %t where uid=%d limit %d,%d',array('aljzc_collection',$_G['uid'],$start,$perpage));
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljzc&act=collection_list', 0, 11, false, false);
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljzc_seo['collection']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzc_seo['collection']);
	}
	include template('aljzc:collection_list');
} else if ($_GET['act'] == 'collection_del') {
	$user=C::t('#aljzc#aljzc_collection')->fetch($_GET['cid']);
	if($user['uid']!=$_G['uid']&&$_G['groupid']!=1){
		tips_mes(lang('plugin/aljzc','aljzc_8'));
	}
    C::t('#aljzc#aljzc_collection')->delete($_GET['cid']);
    tips_mes(lang('plugin/aljzc','aljzc_7'), 'plugin.php?id=aljzc&act=collection_list');
}else if($_GET['act'] == 'attes'){
	if (file_exists("source/plugin/aljzc/template/com/attes.php")) {
        include 'source/plugin/aljzc/template/com/attes.php';
    }
}else if ($_GET['act'] == 'post') {
	//����̳�ֻ���
	if($settings['is_forum_mobile']['value']){
		$profile = DB::fetch_first('select * from %t where uid=%d',array('common_member_profile',$_G['uid']));
		if(empty($profile['mobile'])){
			if (submitcheck('formhash')) {
				if($_GET['sj']){
					echo "<script>parent.tips('&#35831;&#20808;&#32465;&#23450;&#35770;&#22363;&#25163;&#26426;&#21495;&#21518;&#25165;&#33021;&#21457;&#24067;&#20449;&#24687;','');</script>";
					exit;
				}else{
					showerror('&#35831;&#20808;&#32465;&#23450;&#35770;&#22363;&#25163;&#26426;&#21495;&#21518;&#25165;&#33021;&#21457;&#24067;&#20449;&#24687;');
				}
			}else{
				tips_mes('&#35831;&#20808;&#32465;&#23450;&#35770;&#22363;&#25163;&#26426;&#21495;&#21518;&#25165;&#33021;&#21457;&#24067;&#20449;&#24687;','home.php?mod=spacecp&ac=profile&op=contact');
			}
		}
	}
	//��֤
	$rz = DB::result_first("select count(*) from ".DB::table($pluginid.'_attestation')." where sign=1 and uid=".$_G['uid']);
	date_default_timezone_set('PRC');//�л����񹲺͹�ʱ��
	$todaytimestamp = strtotime(gmdate('Y-m-d 00:00:00',TIMESTAMP+3600*8));
	$post_num = DB :: result_first('select count(*) from %t where uid=%d and addtime>=%d',array($pluginid,$_G['uid'],$todaytimestamp));

	if($settings['is_plugin_rz']['value']){
		if(!$rz){
			if (submitcheck('formhash')) {
				if($_GET['sj']){
					echo "<script>parent.tips('&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#20449;&#24687;','');</script>";
					exit;
				}else{
					showerror('&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#20449;&#24687;');
				}
			}else{
				tips_mes('&#35748;&#35777;&#21518;&#25165;&#33021;&#21457;&#24067;&#20449;&#24687;','plugin.php?id='.$pluginid.'&act=attes');
			}
		}
	}else{
		if($settings['no_rz_post_num']['value']&&!$rz){

			if($post_num >= $settings['no_rz_post_num']['value']){
				if (submitcheck('formhash')) {
					if($_GET['sj']){
						echo "<script>parent.tips('&#27599;&#22825;&#21482;&#20801;&#35768;&#21457;&#24067;".$settings['no_rz_post_num']['value']."&#26465;&#20449;&#24687;','');</script>";
						exit;
					}else{
						showerror('&#27599;&#22825;&#21482;&#20801;&#35768;&#21457;&#24067;'.$settings['no_rz_post_num']['value'].'&#26465;&#20449;&#24687;');
					}
				}else{
					tips_mes('&#27599;&#22825;&#21482;&#20801;&#35768;&#21457;&#24067;'.$settings['no_rz_post_num']['value'].'&#26465;&#20449;&#24687;');
				}
			}
		}
	}
	if($rz){
		if($settings['rz_post_num']['value']){
			if($post_num >= $settings['rz_post_num']['value']){
				if (submitcheck('formhash')) {
					if($_GET['sj']){
						echo "<script>parent.tips('&#27599;&#22825;&#21482;&#20801;&#35768;&#21457;&#24067;".$settings['rz_post_num']['value']."&#26465;&#20449;&#24687;','');</script>";
						exit;
					}else{
						showerror('&#27599;&#22825;&#21482;&#20801;&#35768;&#21457;&#24067;'.$settings['rz_post_num']['value'].'&#26465;&#20449;&#24687;');
					}
				}else{
					tips_mes('&#27599;&#22825;&#21482;&#20801;&#35768;&#21457;&#24067;'.$settings['rz_post_num']['value'].'&#26465;&#20449;&#24687;');
				}
			}
		}
	}
    if (submitcheck('formhash')) {
        if (empty($_GET['title'])) {
			if($_GET['sj']){
				echo "<script>parent.tips('".lang('plugin/aljzc','aljzc_2')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzc','aljzc_2'));
			}
        }

		if (empty($_GET['region'])) {
			if($_GET['sj']){
				echo "<script>parent.tips('".lang('plugin/aljzc','aljzc_24')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzc','aljzc_24'));
			}
        }
		if (empty($_GET['contact'])) {
			if($_GET['sj']){
				echo "<script>parent.tips('".lang('plugin/aljzc','aljzc_25')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzc','aljzc_25'));
			}
        }
		if(!is_mobile_l($_GET['contact'])){
			if($_GET['sj']){
				echo "<script>parent.closedialog();parent.tips('&#30005;&#35805;&#26684;&#24335;&#19981;&#23545;','');</script>";
				exit;
			}else{
				showerror('&#30005;&#35805;&#26684;&#24335;&#19981;&#23545;');
			}
		}

		//Image bulk upload s
		if($_G['cache']['plugin']['aljibu'][$pluginid]){
			include 'source/plugin/aljibu/include/ibu_post.php';
		}else{
			for ($i = 1; $i <= 8; $i++) {
				$pic = 'pic' . $i;
				if ($_FILES[$pic]['tmp_name']) {
					$picname = $_FILES[$pic]['name'];
					$picsize = $_FILES[$pic]['size'];
					if ($picsize/1024>$config['img_size']) {
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('".lang('plugin/aljzc','aljzc_26').$config['img_size'].'K'."','');</script>";
							exit;
						}else{
							showerror(lang('plugin/aljzc','aljzc_26').$config['img_size'].'K');
						}
					}
					if ($picname != "") {
						$type = strtolower(strrchr($picname, '.'));
						if ($type != ".gif" && $type != ".jpg" && $type != ".png" && $type != ".jpeg") {
							if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
								echo "<script>parent.tips('".lang('plugin/aljzc','aljzc_3')."','');</script>";
								exit;
							}else{
								showerror(lang('plugin/aljzc','aljzc_3'));
							}
						}
						$rand = rand(100, 999);
						$pics = date("YmdHis") . $rand . $type;
						$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
						if (!is_dir($img_dir)) {
							mkdir($img_dir);
						}
						$$pic = $img_dir . $pics;
						if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
							$imageinfo = getimagesize($$pic);
							if($settings['iswatermark']['value']){
								$image->Watermark(DISCUZ_ROOT.'./'.$$pic,'', 'forum');
							}
							$w64 = $imageinfo[0] < 64 ? $imageinfo[0] : 64;
							$h64 = $imageinfo[1] < 64 ? $imageinfo[1] : 64;

							$w640 = $imageinfo[0] < 640 ? $imageinfo[0] : 640;
							$h480 = $imageinfo[1] < 480 ? $imageinfo[1] : 480;

							$w140 = $imageinfo[0] < 140 ? $imageinfo[0] : 140;
							$h100 = $imageinfo[1] < 100 ? $imageinfo[1] : 100;

							img2thumb($$pic, $$pic . '.140x100.jpg', $w140, $h100);
							img2thumb($$pic, $$pic . '.64x64.jpg', $w64, $h64);
							img2thumb($$pic, $$pic . '.640x480.jpg', $w640, $h480);
							@unlink($_FILES[$pic]['tmp_name']);
						}
					}
				}
			}
		}
		if($settings['is_form']['value']){
			if(DB::result_first('select count(*) from %t where title = %s',array($pluginid,$_GET['title']))){
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('&#26631;&#39064;&#24050;&#23384;&#22312;','');</script>";
					exit;
				}else{
					showerror('&#26631;&#39064;&#24050;&#23384;&#22312;');
				}
			}
			if(!valid_token($_GET[$pluginid.'_token'],getcookie($pluginid.'_token'),$pluginid.'_token')){
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#35831;&#21047;&#26032;&#21518;&#37325;&#26032;&#21457;&#24067;&#25110;&#36820;&#22238;&#31649;&#29702;&#20013;&#24515;&#26597;&#30475;&#21457;&#24067;&#20449;&#24687;',function(){parent.location.href='plugin.php?id=".$pluginid."&act=member';});</script>";
					exit;
				}else{
					showerror('&#34920;&#21333;&#24050;&#25552;&#20132;&#65292;&#35831;&#21047;&#26032;&#21518;&#37325;&#26032;&#21457;&#24067;&#25110;<a href="plugin.php?id=".$pluginid."&act=member">&#36820;&#22238;&#31649;&#29702;&#20013;&#24515;&#26597;&#30475;&#21457;&#24067;&#20449;&#24687;</a>');
				}
			}
		}
		if($config['isreview'] && file_exists("source/plugin/aljzc/template/com/admin.php")  && !in_array($_G['groupid'],unserialize($config['mian_groups']))){
			$state=1;
		}

        $insertarray = array(
            'title' => $_GET['title'],
            'service_content' => implode(',',$_GET['service_content']),
            'qq' => $_GET['qq'],
            'gongsi' => $_GET['gongsi'],
            'zujin' => $_GET['zujin'],
            'content' => $_GET['content'],
            'lxr' => $_GET['lxr'],
            'region' => $_GET['region'],
            'region1' => $_GET['region1'],
            'region2' => $_GET['region2'],
            'region3' => $_GET['region3'],
            'contact' => $_GET['contact'],
            'phone' =>  $_G['mobile'],
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'addtime' => TIMESTAMP,
            'updatetime' => TIMESTAMP,
			'state' =>  $state,
			'clientip' => $_G['clientip'],
        );
        for ($i = 1; $i <= 8; $i++) {
            $pic = 'pic' . $i;
            if ($$pic) {
                $insertarray[$pic] = $$pic;
            }
        }
		if (file_exists("source/plugin/aljzc/template/com/release.php")  && $config['releaseextcredit']) {
			include 'source/plugin/aljzc/template/com/release.php';
		}
        $insertid = C::t('#aljzc#aljzc')->insert($insertarray, true);
		//Image bulk upload s
		if($_G['cache']['plugin']['aljibu'][$pluginid]){
			include 'source/plugin/aljibu/include/ibu_post_id.php';
		}
		//Image bulk upload e
		if ((file_exists("source/plugin/aljzc/template/com/tongbu.php")&&!$config['isreview'])  || (file_exists("source/plugin/aljzc/template/com/tongbu.php")&&in_array($_G['groupid'],unserialize($config['mian_groups'])))) {
			include 'source/plugin/aljzc/template/com/tongbu.php';
		}

        C::t('#aljzc#aljzc_user')->update_count_by_uid($_G['uid']);
		if($config['isreview'] && !in_array($_G['groupid'],unserialize($config['mian_groups']))){
			$groupids=DB::fetch_all('select * from %t where groupid = %d',array('common_member',1));
			foreach($groupids as $g_uid){
				notification_add($g_uid['uid'], 'system',lang('plugin/aljzc','n_add_post'),array('from_idtype'  => $pluginid,'from_id' => $insertid));
			}
			if($_GET['sj']){
				echo "<script>parent.tips('".lang('plugin/aljzc','To_examine')."',function(){parent.location.href='plugin.php?id=aljzc&act=view&lid=".$insertid."';});</script>";
			}else{
				showmsg(lang('plugin/aljzc','To_examine'), 2, $insertid);
			}
		}else{
			if($_GET['sj']){
				echo "<script>parent.tips('".str_replace('\\','',lang('plugin/aljzc','aljzc_4'))."',function(){parent.location.href='plugin.php?id=aljzc&act=view&lid=".$insertid."';});</script>";
			}else{
				showmsg(str_replace('\\','',lang('plugin/aljzc','aljzc_4')), 2, $insertid);
			}
		}
    } else {

		//���������û���
		if(!in_array($_G['groupid'],unserialize($config['lj_groups']))){
				tips_mes($config['lj_tsy']);
		}
		if (file_exists("source/plugin/aljzc/template/com/release.php") && $config['releaseextcredit']) {
			if (getuserprofile('extcredits' . $config['releaseextcredit']) < $config['releasepay']) {
                tips_mes('&#26412;&#27425;&#25805;&#20316;&#38656;&#35201;&#28040;&#32791;'.$config['releasepay'].$_G['setting']['extcredits'][$config['releaseextcredit']]['title'].','.$_G['setting']['extcredits'][$config['releaseextcredit']]['title'] . lang('plugin/aljzc','top_1'),$mobile_integral_recharge);
			}
		}
        $rs = C::t('#aljzc#aljzc_region')->fetch_all_by_upid(0);
		//Image bulk upload s
		if($_G['cache']['plugin']['aljibu'][$pluginid]){
			include 'source/plugin/aljibu/include/ibu_post_view.php';
		}
		//Image bulk upload e
		$navtitle = $config['title'];
		$metakeywords = $config['keywords'];
		$metadescription = $config['description'];
		if($aljzc_seo['post']['seotitle']){
			$seodata = array('bbname' => $_G['setting']['bbname']);
			list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzc_seo['post']);
		}
        include template('aljzc:post');
    }
} else if ($_GET['act'] == 'edit') {
    if (submitcheck('formhash')) {
        if (empty($_GET['title'])) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljzc','aljzc_2')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzc','aljzc_2'));
			}

        }
		$lp = C::t('#aljzc#aljzc')->fetch($_GET['lid']);
		if($settings['is_form']['value'] && $lp['title'] != trim($_GET['title'])){
			if(DB::result_first('select count(*) from %t where title = %s',array($pluginid,$_GET['title']))){
				if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					echo "<script>parent.tips('&#26631;&#39064;&#24050;&#23384;&#22312;','');</script>";
					exit;
				}else{
					showerror('&#26631;&#39064;&#24050;&#23384;&#22312;');
				}
			}
		}
		if($_G['cache']['plugin']['aljibu'][$pluginid]){//�µ�ͼƬ�ϴ���ʽ
			include 'source/plugin/aljibu/include/ibu_edit.php';

		}else{
			for ($i = 1; $i <= 8; $i++) {
				$pic = 'pic' . $i;
				if ($_FILES[$pic]['tmp_name']) {
					$picname = $_FILES[$pic]['name'];
					$picsize = $_FILES[$pic]['size'];
					if ($picsize/1024>$config['img_size']) {
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('".lang('plugin/aljzc','aljzc_26').$config['img_size'].'K'."','');</script>";
							exit;
						}else{
							showerror(lang('plugin/aljzc','aljzc_26').$config['img_size'].'K');
						}

					}
					if ($picname != "") {
						$type = strtolower(strrchr($picname, '.'));
						if ($type != ".gif" && $type != ".jpg" && $type != ".png" && $type != ".jpeg") {
							if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
								echo "<script>parent.tips('".lang('plugin/aljzc','aljzc_3')."','');</script>";
								exit;
							}else{
								showerror(lang('plugin/aljzc','aljzc_3'));
							}

						}
						$rand = rand(100, 999);
						$pics = date("YmdHis") . $rand . $type;
						$img_dir = $image_path.date('Ymd',TIMESTAMP).'/';
						if (!is_dir($img_dir)) {
							mkdir($img_dir);
						}
						$$pic = $img_dir . $pics;
						if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
							$imageinfo = getimagesize($$pic);
							if($settings['iswatermark']['value']){
								$image->Watermark(DISCUZ_ROOT.'./'.$$pic,'', 'forum');
							}
							$w64 = $imageinfo[0] < 64 ? $imageinfo[0] : 64;
							$h64 = $imageinfo[1] < 64 ? $imageinfo[1] : 64;

							$w640 = $imageinfo[0] < 640 ? $imageinfo[0] : 640;
							$h480 = $imageinfo[1] < 480 ? $imageinfo[1] : 480;

							$w140 = $imageinfo[0] < 140 ? $imageinfo[0] : 140;
							$h100 = $imageinfo[1] < 100 ? $imageinfo[1] : 100;

							img2thumb($$pic, $$pic . '.140x100.jpg', $w140, $h100);
							img2thumb($$pic, $$pic . '.64x64.jpg', $w64, $h64);
							img2thumb($$pic, $$pic . '.640x480.jpg', $w640, $h480);
							@unlink($_FILES[$pic]['tmp_name']);
						}
					}
				}
			}
		}


        $insertarray = array(
            'gongsi' => $_GET['gongsi'],
            'title' => $_GET['title'],
            'service_content' => implode(',',$_GET['service_content']),
            'qq' => $_GET['qq'],

            'lxr' => $_GET['lxr'],
            'zujin' => $_GET['zujin'],
            'content' => $_GET['content'],
            'region3' => $_GET['region3'],
            'region' => $_GET['region'],
            'region1' => $_GET['region1'],
            'region2' => $_GET['region2'],
            'contact' => $_GET['contact'],
        );

        for ($i = 1; $i <= 8; $i++) {
            $pic = 'pic' . $i;
			$del_logo = 'del_logo_'.$i;
			if($_GET[$del_logo]){
				unlink($lp[$pic]);
				unlink($lp[$pic]. '.640x480.jpg');
				unlink($lp[$pic]. '.64x64.jpg');
				unlink($lp[$pic]. '.140x100.jpg');
				$insertarray[$pic] = '';
			}
            if ($$pic) {
                if (empty($$pic)) {
                    $$pic = file_exists($_GET[$pic])?$_GET[$pic]:'';
                }
				if(!$_G['cache']['plugin']['aljibu'][$pluginid]){//�µ�ͼƬ�ϴ���ʽ
					unlink($lp[$pic]);
					unlink($lp[$pic]. '.640x480.jpg');
					unlink($lp[$pic]. '.64x64.jpg');
					unlink($lp[$pic]. '.140x100.jpg');
				}
                $insertarray[$pic] = $$pic;

            }

			if(!file_exists($lp[$pic]) && empty($$pic) && $_G['cache']['plugin']['aljibu'][$pluginid]){//ͼƬΪ���ж�

				$insertarray[$pic]='';
			}
        }
        C::t('#aljzc#aljzc')->update($_GET['lid'], $insertarray);
		if($_G['cache']['plugin']['aljibu'][$pluginid]){//��ͼ
			include 'source/plugin/aljibu/include/ibu_edit_id.php';
		}
        C::t('#aljzc#aljzc_user')->update_updatecount_by_uid($_G['uid']);
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".str_replace('\\','',lang('plugin/aljzc','aljzc_5'))."',function(){parent.location.href='plugin.php?id=aljzc&act=view&lid=".$_GET['lid']."';});</script>";
		}else{
			showmsg(str_replace('\\','',lang('plugin/aljzc','aljzc_5')), 2, $_GET['lid']);
		}

    } else {
        $rs = C::t('#aljzc#aljzc_region')->fetch_all_by_upid(0);
        $lp = C::t('#aljzc#aljzc')->fetch($_GET['lid']);
		if($lp['uid']!=$_G['uid']&&$_G['groupid']!=1){
			tips_mes(lang('plugin/aljzcf','aljzc_8'));
		}
        $ps = explode(',', $lp['service_content']);
        if ($lp['region']) {
            $rrs = C::t('#aljzc#aljzc_region')->fetch_all_by_upid($lp['region']);
        }
		//��ͼ s
		if($_G['cache']['plugin']['aljibu'][$pluginid]){//��ͼ
			include 'source/plugin/aljibu/include/ibu_edit_view.php';
		}
		//��ͼ e
		$navtitle = $config['title'];
		$metakeywords = $config['keywords'];
		$metadescription = $config['description'];
		if($aljzc_seo['edit']['seotitle']){
			$seodata = array('bbname' => $_G['setting']['bbname']);
			list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzc_seo['edit']);
		}
        include template('aljzc:post');
    }
} else if($_GET['act'] == 'upload') {
	include 'source/plugin/aljibu/include/ibu_upload.php';
} else if($_GET['act'] == 'deleteattach'){
	include 'source/plugin/aljibu/include/ibu_deleteattach.php';
} else if($_GET['act'] == 'mobile_deleteattach'){
	include 'source/plugin/aljibu/include/ibu_mobile_deleteattach.php';
} else if($_GET['act'] == 'mupload'){
	include 'source/plugin/aljibu/include/ibu_mupload.php';
} else if ($_GET['act'] == 'reflash') {
    if (file_exists("source/plugin/aljzc/template/com/reflash.php")) {
        include 'source/plugin/aljzc/template/com/reflash.php';
    }
} else if ($_GET['act'] == 'top') {
    if (file_exists("source/plugin/aljzc/template/com/top.php")) {
        include 'source/plugin/aljzc/template/com/top.php';
    }
} else if ($_GET['act'] == 'untop'){

	$lp=C::t('#'.$pluginid.'#'.$pluginid)->fetch($_GET['lid']);

	if (($_GET['formhash'] != formhash() || $lp['uid']!=$_G['uid'] || empty($_GET['lid'])) && $_G['groupid']!=1) {

		if($_G['mobile']){
			echo "<script>parent.tips('&#26080;&#26435;&#25805;&#20316;','');</script>";
			exit;
		}else{
			showmsg('&#26080;&#26435;&#25805;&#20316;');
		}
	}
	DB::update($pluginid,array('topetime'=>TIMESTAMP),'id='.$_GET[lid]);
	DB::update($pluginid.'_toplog',array('status'=>1),'lid='.$_GET[lid]);

	if($_G['mobile']){
		echo "<script>parent.tips('&#21462;&#28040;&#32622;&#39030;&#25104;&#21151;',function(){parent.location.href='plugin.php?id=".$pluginid."&act=member"."';});</script>";
		exit;
	}else{
		showmsg('&#21462;&#28040;&#32622;&#39030;&#25104;&#21151;', 'plugin.php?id='.$pluginid.'&act=member');
	}
} else if ($_GET['act'] == 'view') {
    if (empty($_GET['lid'])) {
        tips_mes(lang('plugin/aljzc','aljzc_6'));
    }

    C::t('#aljzc#aljzc')->update_views_by_id($_GET['lid']);
    $pics = array('pic1', 'pic2', 'pic3', 'pic4', 'pic5', 'pic6', 'pic7', 'pic8');
    $regions = C::t('#aljzc#aljzc_region')->range();
    $lp = C::t('#aljzc#aljzc')->fetch($_GET['lid']);
	if (empty($lp)) {
        tips_mes(lang('plugin/aljzc','aljzc_6'));
    }
    $lp = dhtmlspecialchars($lp);
	foreach(explode(',',$lp['service_content']) as $k => $v){
		$service_c.=$types[$v].',';
	}
	$s_c=trim($service_c,',');
	if($config['isyouke']){
		$tel=hidtel($lp['contact']);
	}
	$cod=$regions[$lp['region']]['subject'].$regions[$lp['region1']]['subject'].$regions[$lp['region2']]['subject'].$lp['region3'];
	if($_G['charset']=='gbk'){
		$cod=diconv($cod,'gbk','utf-8');
	}
	$url=urlencode($cod);
	$qita = DB::fetch_all("SELECT * FROM ".DB::table('aljzc')." where state=0 and uid=".$lp[uid]." ORDER BY id desc limit 0,".$config['qitanum']);
	foreach($qita as $k=>$v){
		$qita[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
	}
	$commentlist=C::t('#aljzc#aljzc_comment')->fetch_all_by_upid(0,$_GET['lid']);
	$commentlist=dhtmlspecialchars($commentlist);
	foreach($pics as $p => $pic){
		if(file_exists($lp[$pic]) || strpos($lp[$pic],$oss_domain) !== false){
			$html.="<a href=\"javascript:void(0);\" class=\"aljsqImg swiper-slide\" ><img src=\"".$lp[$pic]."\" ></a>";
		}
	}
	if(file_exists('source/plugin/mapp_share/api/api.php')){
		$shareid = $_GET['lid'];
		$sharetype = 12;
		require_once 'source/plugin/mapp_share/api/api.php';
	}
    $navtitle = $lp['title'] . '-' . $config['title'];
    $metakeywords = $lp['title'];
    $metadescription = $lp['title'];
	if($aljzc_seo['view']['seotitle']){
		if($lp['region']){
			$title=$regions[$lp['region']]['subject'];
			$title1 = $title;
		}
		if($lp['region1']){
			$title=$regions[$lp['region1']]['subject'];
			$title2=$title;

		}
		if($lp['region2']){
			$title=$regions[$lp['region2']]['subject'];
			$title3=$title;
		}
		$seodata = array('bbname' => $_G['setting']['bbname'],'subject'=>$lp['title'],'message'=>cutstr(stripBBCode(strip_tags(preg_replace('/\<img.*?\>/is', '', $lp['content']))),80,''),'cat'=>$s_c,'pay'=>$lp['zujin'].lang('plugin/aljzc','yuan'),'region'=>$title1,'region2'=>$title2,'region3'=>$title3);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzc_seo['view']);
	}
	if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
		include template('aljzc:view');
	} else {
		include template('diy:aljzc_view', null, 'source/plugin/aljzc/template');
	}

} else if ($_GET['act'] == 'delete') {
	$user=C::t('#aljzc#aljzc')->fetch($_GET['lid']);
	if($user['uid']!=$_G['uid']&&$_G['groupid']!=1){
		tips_mes(lang('plugin/aljzc','aljzc_8'));
	}
	for ($i = 1; $i <= 8; $i++) {
		$pic = 'pic' . $i;
		if ($user[$pic]) {
			unlink($user[$pic]);
			unlink($user[$pic].'.64x64.jpg');
			unlink($user[$pic].'.640x480.jpg');
		}
	}
	if($user['tid']){
		DB::update('forum_post', array('invisible'=>'-1'), "tid=".$user['tid']);
		DB::update('forum_thread', array('displayorder'=>'-1'), "tid=".$user['tid']);
	}
    C::t('#aljzc#aljzc')->delete($_GET['lid']);
    tips_mes(lang('plugin/aljzc','aljzc_7'), 'plugin.php?id=aljzc&act=member');
}else if($_GET['act'] == 'ask'){

	if(submitcheck('formhash')){
		if (empty($_G['uid'])) {
			//showerror(lang('plugin/aljzc','aljzc_1'));
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljzc','aljzc_1')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzc','aljzc_1'));
			}
		}
		if (empty($_GET['message'])) {
			//showerror(lang('plugin/aljzc','aljzc_9'));
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljzc','aljzc_9')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzc','aljzc_9'));
			}
		}
		$insertarray=array(
			'content'=>$_GET['message'],
			'uid'=>$_G['uid'],
			'username'=>$_G['username'],
			'lid'=>$_GET['lid'],
			'dateline'=>TIMESTAMP,
		);
		C::t('#aljzc#aljzc_comment')->insert($insertarray);
		if($config['is_ping']){
			$lp=C::t('#aljzc#aljzc')->fetch($_GET['lid']);
			notification_add($lp['uid'], 'system',lang('plugin/aljzc','aljzc_27').' <a target="_blank" href="plugin.php?id=aljzc&act=view&lid='.$_GET['lid'].'">'.$lp['title'].'</a> '.lang('plugin/aljzc','aljzc_28').' <a href="plugin.php?id=aljzc&act=view&lid='.$_GET['lid'].'" target="_blank">'.lang('plugin/aljzc','aljzc_29').'</a>',array('from_idtype'  => $pluginid,'from_id' => $_GET['lid']));
		}
		//showmsg(lang('plugin/aljzc','aljzc_10'));
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".str_replace('\\','',lang('plugin/aljzc','aljzc_10'))."',function(){parent.location.href='plugin.php?id=aljzc&act=view&lid=".$_GET['lid']."';});</script>";
		}else{
			showmsg(str_replace('\\','',lang('plugin/aljzc','aljzc_10')), 2, $_GET['lid']);
		}
	}
}else if($_GET['act'] == 'reply'){
	if(submitcheck('formhash')){
		if (empty($_G['uid'])) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljzc','aljzc_1')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzc','aljzc_1'));
			}
		}
		if (empty($_GET['message'])) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljzc','aljzc_9')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljzc','aljzc_9'));
			}
		}
		$insertarray=array(
			'content'=>$_GET['message'],
			'uid'=>$_G['uid'],
			'username'=>$_G['username'],
			'lid'=>$_GET['lid'],
			'dateline'=>TIMESTAMP,
			'upid'=>$_GET['upid'],
		);
		C::t('#aljzc#aljzc_comment')->insert($insertarray);
		if($config['is_ping']){
			$lp=C::t('#aljzc#aljzc_comment')->fetch($_GET['upid']);
			notification_add($lp['uid'], 'system',lang('plugin/aljzc','aljzc_30').$config['daohang'].lang('plugin/aljzc','aljzc_31').' <a href="plugin.php?id=aljzc&act=view&lid='.$_GET['lid'].'" target="_blank">'.lang('plugin/aljzc','aljzc_29').'</a>',array('from_idtype'  => $pluginid,'from_id' => $_GET['lid']));
		}
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".str_replace('\\','',lang('plugin/aljzc','aljzc_10'))."',function(){parent.location.href='plugin.php?id=aljzc&act=view&lid=".$_GET['lid']."';});</script>";
		}else{
			showmsg(str_replace('\\','',lang('plugin/aljzc','aljzc_10')), 2, $_GET['lid']);
		}
	}
}else if($_GET['act'] == 'commentdel'){
	if($_GET['formhash']==formhash()){
		if (empty($_G['uid'])) {
			showerror(lang('plugin/aljzc','aljzc_1'));
		}
		$upid=DB::fetch_all(" select * from %t where upid=%d",array('aljzc_comment',$_GET['cid']));
		if($upid){
			foreach($upid as $id){
				C::t('#aljzc#aljzc_comment')->delete($id['id']);
			}
		}
		C::t('#aljzc#aljzc_comment')->delete($_GET['cid']);
		tips_mes(lang('plugin/aljzc','aljzc_7'),'plugin.php?id=aljzc&act=view&lid='.$_GET['lid']);
	}
}else if ($_GET['act'] == 'getregion') {
    if ($_GET['rid']) {
        $rs = C::t('#aljzc#aljzc_region')->fetch_all_by_upid($_GET['rid']);
    }

    include template('aljzc:getregion');
}else if($_GET['act']=='getregion1'){
	if($_GET['upid']){
		$rlist=C::t('#aljzc#aljzc_region')->fetch_all_by_upid($_GET['upid']);
	}
	include template('aljzc:getregion1');
} else if ($_GET['act'] == 'member') {
    $currpage = $_GET['page'] ? $_GET['page'] : 1;
    $perpage = $config['page'];

    $start = ($currpage - 1) * $perpage;
	if($_G['groupid']!=1){
		$conndtion = array(
			'uid' => $_G['uid'],
		);
	}
	$conndtion['search'] = $_GET['search_m'];
    $num = C::t('#aljzc#aljzc')->count_by_status($conndtion);
    $lplist = C::t('#aljzc#aljzc')->fetch_all_by_addtime($start, $perpage, $conndtion);
	//debug($lplist);
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljzc&act=member', 0, 11, false, false);
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljzc_seo['member']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzc_seo['member']);
	}
    include template('aljzc:member');
} else if ($_GET['act'] == 'adminlp') {
    if (file_exists("source/plugin/aljzc/template/com/admin.php")) {
        include 'source/plugin/aljzc/template/com/admin.php';
    }
} else if ($_GET['act'] == 'adminuser') {
    if (file_exists("source/plugin/aljzc/template/com/user.php")) {
        include 'source/plugin/aljzc/template/com/user.php';
    }
} else if ($_GET['act'] == 'adminreflash') {
    $currpage = $_GET['page'] ? $_GET['page'] : 1;
    $perpage = 10;
    $num = C::t('#aljzc#aljzc_reflashlog')->count();
    //$num = DB::result_first(" select count(*) from ".DB::table('aljzc_reflashlog')." where title!=null ");
    $start = ($currpage - 1) * $perpage;

    $logs = C::t('#aljzc#aljzc_reflashlog')->range($start, $perpage, 'desc');
    //$logs = DB::fetch_all(" select * from ".DB::table('aljzc_reflashlog')." where title!=null order by id desc limit $start,$perpage");
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljzc&act=adminreflash', 0, 11, false, false);
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljzc_seo['adminreflash']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzc_seo['adminreflash']);
	}
    include template('aljzc:adminreflash');
} else if ($_GET['act'] == 'admintop') {
    $currpage = $_GET['page'] ? $_GET['page'] : 1;
    $perpage = $config['page'];
    $num = C::t('#aljzc#aljzc_toplog')->count();
    $start = ($currpage - 1) * $perpage;

    $logs = C::t('#aljzc#aljzc_toplog')->range($start, $perpage, 'desc');
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljzc&act=admintop', 0, 11, false, false);
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljzc_seo['admintop']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzc_seo['admintop']);
	}
    include template('aljzc:admintop');
}else if($_GET['act'] == 'all'){
	if (file_exists("source/plugin/aljzc/template/com/qita.php")) {
        include 'source/plugin/aljzc/template/com/qita.php';
    }
}else if($_GET['act'] == 'mobile_list_region'){
	if($_GET['rid']){
		$rlist=C::t('#'.$pluginid.'#'.$pluginid.'_region')->fetch_all_by_upid($_GET['rid']);
	}
	$geturl = array(
		'id' => $pluginid,
		'act' => 'list',
		'search' => $_GET['search'],
		'rid' => $_GET['rid'],
		'subrid' => $_GET['subrid'],
		'subsubrid' => $_GET['subsubrid'],
		'pay1' => $_GET['pay1'],
		'pay2' => $_GET['pay2'],
		'service_content' => $_GET['service_content'],
		'solve' => $_GET['solve'],
		'view' => $_GET['view'],
	);
	if($_GET['sub']){
		$geturl['rid'] = $_GET['subrid'];
		$geturl['subrid'] = $_GET['rid'];
		include template($pluginid.':mobile_list_subregion');
	}else{
		$geturl['rid'] = $_GET['rid'];
		$geturl['subrid'] = $_GET['subrid'];
		include template($pluginid.':mobile_list_region');
	}
}else if($_GET['act'] == 'list'){
	if($settings['is_new_index']['value']){
		$urllist = '&act=list';
	}
	$todayviews = C::t('#aljzc#aljzc_log')->fetch_all_by_day();
    $regions = C::t('#aljzc#aljzc_region')->range();
    $rs = C::t('#aljzc#aljzc_region')->fetch_all_by_upid(0);
    $rrs = C::t('#aljzc#aljzc_region')->fetch_all_by_upid($_GET['rid']);
	$subrrs = C::t('#aljzc#aljzc_region')->fetch_all_by_upid($_GET['subrid']);
    $currpage = $_GET['page'] ? $_GET['page'] : 1;
    $perpage = $config['page'];

    $start = ($currpage - 1) * $perpage;
	if($_GET['mobile']=='1'||$_GET['mobile']=='2'){
		//if($_G['charset']=='gbk'){ $_GET['search']=diconv($_GET['search'],'utf-8','gbk');}
	}
    $conndtion = array(
        'search' => $_GET['search'],
        'rid' => $_GET['region']?$_GET['region']:$_GET['rid'],
        'subrid' => $_GET['region1']?$_GET['region1']:$_GET['subrid'],
        'subsubrid' => $_GET['region2']?$_GET['region2']:$_GET['subsubrid'],
        'service_content' => $_GET['service_content'],
        'pay1' => $_GET['pay1'],
        'pay2' => $_GET['pay2'],
		'solve' => $_GET['solve'],
    );
	if($config['is_solve'] && file_exists("source/plugin/aljzc/template/com/solve.php")){
		$conndtion['is_solve']=1;
	}
	$num = C::t('#aljzc#aljzc')->count_by_status($conndtion);

    $lplist = C::t('#aljzc#aljzc')->fetch_all_by_addtime($start, $perpage, $conndtion);
	foreach($lplist as $k=>$v){
		if(TIMESTAMP>$v['topetime']&&$v['topetime']){
			DB::update('aljzc',array('topstime'=>'','topetime'=>''),'id='.$v[id]);
		}
		$lplist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
	}
    $lplist = dhtmlspecialchars($lplist);
	$geturl = array(
		'id' => $pluginid,
		'act' => 'list',
		'search' => $_GET['search'],
		'rid' => $_GET['rid'],
		'subrid' => $_GET['subrid'],
		'subsubrid' => $_GET['subsubrid'],
		'pay1' => $_GET['pay1'],
		'pay2' => $_GET['pay2'],
		'service_content' => $_GET['service_content'],
		'solve' => $_GET['solve'],
		'view' => $_GET['view'],
	);
	$pagingurl = getaljurl($geturl,'');
    $paging = helper_page :: multi($num, $perpage, $currpage, $pagingurl, 0, 11, false, false);
	$tuijian = DB::fetch_all("SELECT * FROM ".DB::table('aljzc')." where state=0 and tuijian=1 ORDER BY id desc limit 0,9");
	foreach($tuijian as $k=>$v){
		$tuijian[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
	}
    $toplist = C::t('#aljzc#aljzc_toplog')->fetch_all_by_dateline();
	foreach($toplist as $k=>$v){
		$toplist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
	}

    $navtitle = $config['title'];
    $metakeywords = $config['keywords'];
    $metadescription = $config['description'];
	if($aljzc_seo['list']['seotitle']){
		if($_GET['rid']){
			$title=$regions[$_GET['rid']]['subject'];
			$title1 = $title;
		}
		if($_GET['subrid']){
			$title=$regions[$_GET['subrid']]['subject'];
			$title2=$title;

		}
		if($_GET['subsubrid']){
			$title=$regions[$_GET['subsubrid']]['subject'];
			$title3=$title;
		}

		if($_GET['service_content']){
			$cat=$types[$_GET['service_content']];
		}

		if($_GET['pay1'] || $_GET['pay2']){
			$zujin_1=$_GET['pay1']?$_GET['pay1'].($_GET['pay2']?lang('plugin/aljzc','yuan_1'):lang('plugin/aljzc','yuan_2')):'';
			$zujin_2=$_GET['pay2']?$_GET['pay2'].(!$_GET[pay1]?lang('plugin/aljzc','yuan_3'):lang('plugin/aljzc','yuan')):'';
			$zujin=$zujin_1.$zujin_2;
		}

		$seodata = array('bbname' => $_G['setting']['bbname'],'cat'=>$cat,'pay'=>$zujin,'region'=>$title1,'region2'=>$title2,'region3'=>$title3);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzc_seo['list']);
	}
	if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
		include template('aljzc:index');
	} else {
		include template('diy:aljzc_index', null, 'source/plugin/aljzc/template');
	}
} else {
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	$tuijian = DB::fetch_all("SELECT * FROM ".DB::table('aljzc')." where state=0 and tuijian=1 ORDER BY id desc limit 0,9");
	foreach($tuijian as $k=>$v){
		$tuijian[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
	}
	if($aljzc_seo['list']['seotitle']){
		if($_GET['rid']){
			$title=$regions[$_GET['rid']]['subject'];
			$title1 = $title;
		}
		if($_GET['subrid']){
			$title=$regions[$_GET['subrid']]['subject'];
			$title2=$title;

		}
		if($_GET['subsubrid']){
			$title=$regions[$_GET['subsubrid']]['subject'];
			$title3=$title;
		}

		if($_GET['service_content']){
			$cat=$types[$_GET['service_content']];
		}

		if($_GET['pay1'] || $_GET['pay2']){
			$zujin_1=$_GET['pay1']?$_GET['pay1'].($_GET['pay2']?lang('plugin/aljzc','yuan_1'):lang('plugin/aljzc','yuan_2')):'';
			$zujin_2=$_GET['pay2']?$_GET['pay2'].(!$_GET[pay1]?lang('plugin/aljzc','yuan_3'):lang('plugin/aljzc','yuan')):'';
			$zujin=$zujin_1.$zujin_2;
		}

		$seodata = array('bbname' => $_G['setting']['bbname'],'cat'=>$cat,'pay'=>$zujin,'region'=>$title1,'region2'=>$title2,'region3'=>$title3);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzc_seo['list']);
	}
	if($settings['is_new_index']['value']){
		if(!$_G['mobile']){
			list($wanted_2_num,$wanted_1_num) = explode('|',$settings['pc_index_wanted_num']['value']);
			$wanted_1_num = $wanted_1_num ? $wanted_1_num : 20;//����������Ϣ����
			$wanted_2_num = $wanted_2_num ? $wanted_2_num : 15;//�����Ƽ���Ϣ����
			
			$wanted_1 = C::t('#'.$pluginid.'#'.$pluginid)->fetch_all_by_addtime(0, $wanted_1_num);//����
			foreach($wanted_1 as $k=>$v){
				if(TIMESTAMP>$v['topetime']&&$v['topetime']){
					DB::update($pluginid,array('topstime'=>'','topetime'=>''),'id='.$v[id]);
				}
				$wanted_1[$k]['rewrite']=$config['isrewrite'] ? str_replace ("{id}", $v['id'], $config ['re_view']) : 'plugin.php?id='.$pluginid.'&act=view&lid='.$v[id];
			}
			$wanted_1 = dhtmlspecialchars($wanted_1);
			$wanted_2 = DB::fetch_all("SELECT * FROM ".DB::table($pluginid)." where state=0 and tuijian=1 ORDER BY id desc limit 0,$wanted_2_num");//�Ƽ�
			foreach($wanted_2 as $k=>$v){
				if(TIMESTAMP>$v['topetime']&&$v['topetime']){
					DB::update($pluginid,array('topstime'=>'','topetime'=>''),'id='.$v[id]);
				}
				$wanted_2[$k]['rewrite']=$config['isrewrite'] ? str_replace ("{id}", $v['id'], $config ['re_view']) : 'plugin.php?id='.$pluginid.'&act=view&lid='.$v[id];
				
			}
			$wanted_2 = dhtmlspecialchars($wanted_2);
			
		}
		if($settings[pc_index_new_lz]['value']){
			$index_lz_moren = $settings[pc_index_new_lz]['value'];
		}else{
			$index_lz_moren ='http://DisM.taobao.com/?@'.$pluginid.'.plugin|source/plugin/'.$pluginid.'/images/pc_lz2.jpg
http://DisM.taobao.com/?@'.$pluginid.'.plugin|source/plugin/'.$pluginid.'/images/pc_lz1.jpg';
		}
		$index_lz = explode ("\n", str_replace ("\r", "", $index_lz_moren));
		foreach($index_lz as $key=>$value){
			$arr=explode('|',$value);
			$index_lz_types[]=$arr;
		}
		$mobile_index_ad = explode ("\n", str_replace ("\r", "", $settings['mobile_index_ad']['value']));
		foreach($mobile_index_ad as $key=>$value){
			$arr=explode('|',$value);
			$mobile_index_ad_arr[]=$arr;
		}
		if($settings[mobile_index_new_lz]['value']){
			$mobile_lz_moren = $settings[mobile_index_new_lz]['value'];
		}else{
			$mobile_lz_moren ='#|source/plugin/'.$pluginid.'/images/m_lz2.jpg|&#31934;&#21697;&#25554;&#20214;
#|source/plugin/'.$pluginid.'/images/m_lz1.jpg|&#31199;&#36710;';
		}
		$mobile_lz = explode ("\n", str_replace ("\r", "", $mobile_lz_moren));
		foreach($mobile_lz as $key=>$value){
			$arr=explode('|',$value);
			$lz_types[]=$arr;
		}
		$mobile_index_new_dh = explode ("\n", str_replace ("\r", "", $settings['mobile_index_new_dh']['value']));
		foreach($mobile_index_new_dh as $key=>$value){
			$arr=explode('|',$value);
			$mobile_index_new_dh_types[]=$arr;
		}
        if($aljzc_seo['index']['seotitle']){
            $seodata = array('bbname' => $_G['setting']['bbname']);
            list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljzc_seo['index']);
        }
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			include template($pluginid.':'.$pluginid.'_index_new');
		}else{
			include template('diy:'.$pluginid.'_index_new', null, 'source/plugin/'.$pluginid.'/template');
		}
	}else{
		$todayviews = C::t('#aljzc#aljzc_log')->fetch_all_by_day();
		$regions = C::t('#aljzc#aljzc_region')->range();
		$rs = C::t('#aljzc#aljzc_region')->fetch_all_by_upid(0);
		$rrs = C::t('#aljzc#aljzc_region')->fetch_all_by_upid($_GET['rid']);
		$subrrs = C::t('#aljzc#aljzc_region')->fetch_all_by_upid($_GET['subrid']);
		$currpage = $_GET['page'] ? $_GET['page'] : 1;
		$perpage = $config['page'];

		$start = ($currpage - 1) * $perpage;
		if($_GET['mobile']=='1'||$_GET['mobile']=='2'){
			//if($_G['charset']=='gbk'){ $_GET['search']=diconv($_GET['search'],'utf-8','gbk');}
		}
		$conndtion = array(
			'search' => $_GET['search'],
			'rid' => $_GET['region']?$_GET['region']:$_GET['rid'],
			'subrid' => $_GET['region1']?$_GET['region1']:$_GET['subrid'],
			'subsubrid' => $_GET['region2']?$_GET['region2']:$_GET['subsubrid'],
			'service_content' => $_GET['service_content'],
			'pay1' => $_GET['pay1'],
			'pay2' => $_GET['pay2'],
			'solve' => $_GET['solve'],
		);
		if($config['is_solve'] && file_exists("source/plugin/aljzc/template/com/solve.php")){
			$conndtion['is_solve']=1;
		}
		$num = C::t('#aljzc#aljzc')->count_by_status($conndtion);

		$lplist = C::t('#aljzc#aljzc')->fetch_all_by_addtime($start, $perpage, $conndtion);
		foreach($lplist as $k=>$v){
			if(TIMESTAMP>$v['topetime']&&$v['topetime']){
				DB::update('aljzc',array('topstime'=>'','topetime'=>''),'id='.$v[id]);
			}
			$lplist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
		}
		$lplist = dhtmlspecialchars($lplist);
		$geturl = array(
			'id' => $pluginid,
			'search' => $_GET['search'],
			'rid' => $_GET['rid'],
			'subrid' => $_GET['subrid'],
			'subsubrid' => $_GET['subsubrid'],
			'pay1' => $_GET['pay1'],
			'pay2' => $_GET['pay2'],
			'service_content' => $_GET['service_content'],
			'solve' => $_GET['solve'],
			'view' => $_GET['view'],
		);
		$pagingurl = getaljurl($geturl,'');
		$paging = helper_page :: multi($num, $perpage, $currpage, $pagingurl, 0, 11, false, false);
		$tuijian = DB::fetch_all("SELECT * FROM ".DB::table('aljzc')." where state=0 and tuijian=1 ORDER BY id desc limit 0,9");
		foreach($tuijian as $k=>$v){
			$tuijian[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
		}
		$toplist = C::t('#aljzc#aljzc_toplog')->fetch_all_by_dateline();
		foreach($toplist as $k=>$v){
			$toplist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
		}


		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
			include template('aljzc:index');
		} else {
			include template('diy:aljzc_index', null, 'source/plugin/aljzc/template');
		}
	}
}

function showmsg($msg, $close=0, $id=0) {
    if ($close == 1) {
        $str = "parent.hideWindow('$close');";
    } else if ($close == 2) {
        $str = "parent.location.href='plugin.php?id=aljzc&act=view&lid=" . $id . "'";
    } else {
        $str = "parent.location=parent.location;";
    }
    include template('aljzc:showmsg');
    exit;
}

function showerror($msg) {
    include template('aljzc:showerror');
    exit;
}

function img2thumb($src_img, $dst_img, $width = 75, $height = 75, $cut = 0, $proportion = 0) {
    if (!is_file($src_img)) {
        return false;
    }
    $ot = fileext($dst_img);
    $otfunc = 'image' . ($ot == 'jpg' ? 'jpeg' : $ot);
    $srcinfo = getimagesize($src_img);
    $src_w = $srcinfo[0];
    $src_h = $srcinfo[1];
    $type = strtolower(substr(image_type_to_extension($srcinfo[2]), 1));
    $createfun = 'imagecreatefrom' . ($type == 'jpg' ? 'jpeg' : $type);

    $dst_h = $height;
    $dst_w = $width;
    $x = $y = 0;

    if (($width > $src_w && $height > $src_h) || ($height > $src_h && $width == 0) || ($width > $src_w && $height == 0)) {
        $proportion = 1;
    }
    if ($width > $src_w) {
        $dst_w = $width = $src_w;
    }
    if ($height > $src_h) {
        $dst_h = $height = $src_h;
    }

    if (!$width && !$height && !$proportion) {
        return false;
    }
    if (!$proportion) {
        if ($cut == 0) {
            if ($dst_w && $dst_h) {
                if ($dst_w / $src_w > $dst_h / $src_h) {
                    $dst_w = $src_w * ($dst_h / $src_h);
                    $x = 0 - ($dst_w - $width) / 2;
                } else {
                    $dst_h = $src_h * ($dst_w / $src_w);
                    $y = 0 - ($dst_h - $height) / 2;
                }
            } else if ($dst_w xor $dst_h) {
                if ($dst_w && !$dst_h) {
                    $propor = $dst_w / $src_w;
                    $height = $dst_h = $src_h * $propor;
                } else if (!$dst_w && $dst_h) {
                    $propor = $dst_h / $src_h;
                    $width = $dst_w = $src_w * $propor;
                }
            }
        } else {
            if (!$dst_h) {
                $height = $dst_h = $dst_w;
            }
            if (!$dst_w) {
                $width = $dst_w = $dst_h;
            }
            $propor = min(max($dst_w / $src_w, $dst_h / $src_h), 1);
            $dst_w = (int) round($src_w * $propor);
            $dst_h = (int) round($src_h * $propor);
            $x = ($width - $dst_w) / 2;
            $y = ($height - $dst_h) / 2;
        }
    } else {
        $proportion = min($proportion, 1);
        $height = $dst_h = $src_h * $proportion;
        $width = $dst_w = $src_w * $proportion;
    }

    $src = $createfun($src_img);
    $dst = imagecreatetruecolor($width ? $width : $dst_w, $height ? $height : $dst_h);
    $white = imagecolorallocate($dst, 255, 255, 255);
    imagefill($dst, 0, 0, $white);

    if (function_exists('imagecopyresampled')) {
        imagecopyresampled($dst, $src, $x, $y, 0, 0, $dst_w, $dst_h, $src_w, $src_h);
    } else {
        imagecopyresized($dst, $src, $x, $y, 0, 0, $dst_w, $dst_h, $src_w, $src_h);
    }
    $otfunc($dst, $dst_img);
    imagedestroy($dst);
    imagedestroy($src);
    return true;
}
function hidtel($phone)
{
    $IsWhat = preg_match('/([0-9][0-9]{2,3}[\-]?[1-9][0-9]{6,7}[\-]?[0-9]?)/i',$phone); //�̶��绰

    if($IsWhat == 1)
    {
        return preg_replace('/([0-9][0-9]{2,3}[\-]?[1-9])[0-9]{3,4}([0-9]{3}[\-]?[0-9]?)/i','$1****$2',$phone);
    }
    else
    {
        return  preg_replace('/([0-9][0-9]{1}[0-9])[0-9]{4}([0-9]{4})/i','$1****$2',$phone);
    }
}
function stripBBCode($text_to_search) {
	$pattern = '|[[\/\!]*?[^\[\]]*?]|si';
	$replace = '';
	return preg_replace($pattern, $replace, $text_to_search);
}
function discuzcode_mobile($message, $smileyoff=0, $bbcodeoff=0, $htmlon = 0, $allowsmilies = 1, $allowbbcode = 1, $allowimgcode = 1, $allowhtml = 0, $jammer = 0, $parsetype = '0', $authorid = '0', $allowmediacode = '0', $pid = 0, $lazyload = 0, $pdateline = 0, $first = 0) {
	global $_G;

	static $authorreplyexist;

	if($pid && strpos($message, '[/password]') !== FALSE) {
		if($authorid != $_G['uid'] && !$_G['forum']['ismoderator']) {
			$message = preg_replace("/\s?\[password\](.+?)\[\/password\]\s?/ie", "parsepassword('\\1', \$pid)", $message);
			if($_G['forum_discuzcode']['passwordlock'][$pid]) {
				return '';
			}
		} else {
			$message = preg_replace("/\s?\[password\](.+?)\[\/password\]\s?/ie", "", $message);
			$_G['forum_discuzcode']['passwordauthor'][$pid] = 1;
		}
	}

	if($parsetype != 1 && !$bbcodeoff && $allowbbcode && (strpos($message, '[/code]') || strpos($message, '[/CODE]')) !== FALSE) {
		$message = preg_replace("/\s?\[code\](.+?)\[\/code\]\s?/ies", "codedisp('\\1')", $message);
	}

	$msglower = strtolower($message);

	$htmlon = $htmlon && $allowhtml ? 1 : 0;

	if(!$htmlon) {
		$message = dhtmlspecialchars($message);
	} else {
		$message = preg_replace("/<script[^\>]*?>(.*?)<\/script>/i", '', $message);
	}

	if($_G['setting']['plugins']['func'][HOOKTYPE]['discuzcode']) {
		$_G['discuzcodemessage'] = & $message;
		$param = func_get_args();
		hookscript('discuzcode', 'global', 'funcs', array('param' => $param, 'caller' => 'discuzcode'), 'discuzcode');
	}

	if(!$smileyoff && $allowsmilies) {
		$message = parsesmiles($message);
	}

	if($_G['setting']['allowattachurl'] && strpos($msglower, 'attach://') !== FALSE) {
		$message = preg_replace("/attach:\/\/(\d+)\.?(\w*)/ie", "parseattachurl('\\1', '\\2', 1)", $message);
	}

	if($allowbbcode) {
		if(strpos($msglower, 'ed2k://') !== FALSE) {
			$message = preg_replace("/ed2k:\/\/(.+?)\//e", "parseed2k('\\1')", $message);
		}
	}

	if(!$bbcodeoff && $allowbbcode) {
		if(strpos($msglower, '[/url]') !== FALSE) {
			$message = preg_replace("/\[url(=((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\/\/|www\.|mailto:)?([^\r\n\[\"']+?))?\](.+?)\[\/url\]/ies", "parseurl('\\1', '\\5', '\\2')", $message);
		}
		if(strpos($msglower, '[/email]') !== FALSE) {
			$message = preg_replace("/\[email(=([a-z0-9\-_.+]+)@([a-z0-9\-_]+[.][a-z0-9\-_.]+))?\](.+?)\[\/email\]/ies", "parseemail('\\1', '\\4')", $message);
		}

		$nest = 0;
		while(strpos($msglower, '[table') !== FALSE && strpos($msglower, '[/table]') !== FALSE){
			$message = preg_replace("/\[table(?:=(\d{1,4}%?)(?:,([\(\)%,#\w ]+))?)?\]\s*(.+?)\s*\[\/table\]/ies", "parsetable('\\1', '\\2', '\\3')", $message);
			if(++$nest > 4) break;
		}

		$message = str_replace(array(
			'[/color]', '[/backcolor]', '[/size]', '[/font]', '[/align]', '[b]', '[/b]', '[s]', '[/s]', '[hr]', '[/p]',
			'[i=s]', '[i]', '[/i]', '[u]', '[/u]', '[list]', '[list=1]', '[list=a]',
			'[list=A]', "\r\n[*]", '[*]', '[/list]', '[indent]', '[/indent]', '[/float]'
			), array(
			'</font>', '</font>', '</font>', '</font>', '</div>', '<strong>', '</strong>', '<strike>', '</strike>', '<hr class="l" />', '</p>', '<i class="pstatus">', '<i>',
			'</i>', '<u>', '</u>', '<ul>', '<ul type="1" class="litype_1">', '<ul type="a" class="litype_2">',
			'<ul type="A" class="litype_3">', '<li>', '<li>', '</ul>', '<blockquote>', '</blockquote>', '</span>'
			), preg_replace(array(
			"/\[color=([#\w]+?)\]/i",
			"/\[color=((rgb|rgba)\([\d\s,]+?\))\]/i",
			"/\[backcolor=([#\w]+?)\]/i",
			"/\[backcolor=((rgb|rgba)\([\d\s,]+?\))\]/i",
			"/\[size=(\d{1,2}?)\]/i",
			"/\[size=(\d{1,2}(\.\d{1,2}+)?(px|pt)+?)\]/i",
			"/\[font=([^\[\<]+?)\]/i",
			"/\[align=(left|center|right)\]/i",
			"/\[p=(\d{1,2}|null), (\d{1,2}|null), (left|center|right)\]/i",
			"/\[float=left\]/i",
			"/\[float=right\]/i"

			), array(
			"<font color=\"\\1\">",
			"<font style=\"color:\\1\">",
			"<font style=\"background-color:\\1\">",
			"<font style=\"background-color:\\1\">",
			"<font size=\"\\1\">",
			"<font style=\"font-size:\\1\">",
			"<font face=\"\\1\">",
			"<div align=\"\\1\">",
			"<p style=\"line-height:\\1px;text-indent:\\2em;text-align:\\3\">",
			"<span style=\"float:left;margin-right:5px\">",
			"<span style=\"float:right;margin-left:5px\">"
			), $message));

		if($pid && !defined('IN_MOBILE')) {
			$message = preg_replace("/\s?\[postbg\]\s*([^\[\<\r\n;'\"\?\(\)]+?)\s*\[\/postbg\]\s?/ies", "parsepostbg('\\1', '$pid')", $message);
		} else {
			$message = preg_replace("/\s?\[postbg\]\s*([^\[\<\r\n;'\"\?\(\)]+?)\s*\[\/postbg\]\s?/is", "", $message);
		}

		if($parsetype != 1) {
			if(strpos($msglower, '[/quote]') !== FALSE) {
				$message = preg_replace("/\s?\[quote\][\n\r]*(.+?)[\n\r]*\[\/quote\]\s?/is", tpl_quote(), $message);
			}
			if(strpos($msglower, '[/free]') !== FALSE) {
				$message = preg_replace("/\s*\[free\][\n\r]*(.+?)[\n\r]*\[\/free\]\s*/is", tpl_free(), $message);
			}
		}
		if(!defined('IN_MOBILE')) {
			if(strpos($msglower, '[/media]') !== FALSE) {
				$message = preg_replace("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/ies", $allowmediacode ? "parsemedia('\\1', '\\2')" : "bbcodeurl('\\2', '<a href=\"{url}\" target=\"_blank\">{url}</a>')", $message);
			}
			if(strpos($msglower, '[/audio]') !== FALSE) {
				$message = preg_replace("/\[audio(=1)*\]\s*([^\[\<\r\n]+?)\s*\[\/audio\]/ies", $allowmediacode ? "parseaudio('\\2', 400)" : "bbcodeurl('\\2', '<a href=\"{url}\" target=\"_blank\">{url}</a>')", $message);
			}
			if(strpos($msglower, '[/flash]') !== FALSE) {
				$message = preg_replace("/\[flash(=(\d+),(\d+))?\]\s*([^\[\<\r\n]+?)\s*\[\/flash\]/ies", $allowmediacode ? "parseflash('\\2', '\\3', '\\4');" : "bbcodeurl('\\4', '<a href=\"{url}\" target=\"_blank\">{url}</a>')", $message);
			}
		} else {
			if(strpos($msglower, '[/media]') !== FALSE) {
				$message = preg_replace("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/is", "[media]\\2[/media]", $message);
			}
			if(strpos($msglower, '[/audio]') !== FALSE) {
				$message = preg_replace("/\[audio(=1)*\]\s*([^\[\<\r\n]+?)\s*\[\/audio\]/is", "[media]\\2[/media]", $message);
			}
			if(strpos($msglower, '[/flash]') !== FALSE) {
				$message = preg_replace("/\[flash(=(\d+),(\d+))?\]\s*([^\[\<\r\n]+?)\s*\[\/flash\]/is", "[media]\\4[/media]", $message);
			}
		}

		if($parsetype != 1 && $allowbbcode < 0 && isset($_G['cache']['bbcodes'][-$allowbbcode])) {
			$message = preg_replace($_G['cache']['bbcodes'][-$allowbbcode]['searcharray'], $_G['cache']['bbcodes'][-$allowbbcode]['replacearray'], $message);
		}
		if($parsetype != 1 && strpos($msglower, '[/hide]') !== FALSE && $pid) {
			if($_G['setting']['hideexpiration'] && $pdateline && (TIMESTAMP - $pdateline) / 86400 > $_G['setting']['hideexpiration']) {
				$message = preg_replace("/\[hide[=]?(d\d+)?[,]?(\d+)?\]\s*(.*?)\s*\[\/hide\]/is", "\\3", $message);
				$msglower = strtolower($message);
			}
			if(strpos($msglower, '[hide=d') !== FALSE) {
				$message = preg_replace("/\[hide=(d\d+)?[,]?(\d+)?\]\s*(.*?)\s*\[\/hide\]/ies", "expirehide('\\1','\\2','\\3', $pdateline)", $message);
				$msglower = strtolower($message);
			}
			if(strpos($msglower, '[hide]') !== FALSE) {
				if($authorreplyexist === null) {
					if(!$_G['forum']['ismoderator']) {
						if($_G['uid']) {
							$authorreplyexist = C::t('forum_post')->fetch_pid_by_tid_authorid($_G['tid'], $_G['uid']);
						}
					} else {
						$authorreplyexist = TRUE;
					}
				}
				if($authorreplyexist) {
					$message = preg_replace("/\[hide\]\s*(.*?)\s*\[\/hide\]/is", tpl_hide_reply(), $message);
				} else {
					$message = preg_replace("/\[hide\](.*?)\[\/hide\]/is", tpl_hide_reply_hidden(), $message);
					$message = '<script type="text/javascript">replyreload += \',\' + '.$pid.';</script>'.$message;
				}
			}
			if(strpos($msglower, '[hide=') !== FALSE) {
				$message = preg_replace("/\[hide=(\d+)\]\s*(.*?)\s*\[\/hide\]/ies", "creditshide(\\1,'\\2', $pid, $authorid)", $message);
			}
		}
	}

	if(!$bbcodeoff) {
		if($parsetype != 1 && strpos($msglower, '[swf]') !== FALSE) {
			$message = preg_replace("/\[swf\]\s*([^\[\<\r\n]+?)\s*\[\/swf\]/ies", "bbcodeurl('\\1', ' <img src=\"'.STATICURL.'image/filetype/flash.gif\" align=\"absmiddle\" alt=\"\" /> <a href=\"{url}\" target=\"_blank\">Flash: {url}</a> ')", $message);
		}

		if(defined('IN_MOBILE') && !defined('TPL_DEFAULT') && !defined('IN_MOBILE_API')) {
			$allowimgcode = 1;
		}

		$attrsrc = !IS_ROBOT && $lazyload ? 'file' : 'src';
		if(strpos($msglower, '[/img]') !== FALSE) {
			$message = preg_replace(array(
				"/\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/ies",
				"/\[img=(\d{1,4})[x|\,](\d{1,4})\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/ies"
			), $allowimgcode ? array(
				"parseimg(0, 0, '\\1', ".intval($lazyload).", ".intval($pid).", 'onmouseover=\"img_onmouseoverfunc(this)\" ".($lazyload ? "lazyloadthumb=\"1\"" : "onload=\"thumbImg(this)\"")."')",
				"parseimg('\\1', '\\2', '\\3', ".intval($lazyload).", ".intval($pid).")"
			) : ($allowbbcode ? array(
				(!defined('IN_MOBILE') ? "bbcodeurl('\\1', '<a href=\"{url}\" target=\"_blank\">{url}</a>')" : "bbcodeurl('\\1', '')"),
				(!defined('IN_MOBILE') ? "bbcodeurl('\\3', '<a href=\"{url}\" target=\"_blank\">{url}</a>')" : "bbcodeurl('\\3', '')"),
			) : array("bbcodeurl('\\1', '{url}')", "bbcodeurl('\\3', '{url}')")), $message);
		}
	}
	//debug($message);
	for($i = 0; $i <= $_G['forum_discuzcode']['pcodecount']; $i++) {
		$message = str_replace("[\tDISCUZ_CODE_$i\t]", $_G['forum_discuzcode']['codehtml'][$i], $message);
	}

	unset($msglower);

	if($jammer) {
		$message = preg_replace("/\r\n|\n|\r/e", "jammer()", $message);
	}

	if($first) {
		if(helper_access::check_module('group')) {
			$message = preg_replace("/\[groupid=(\d+)\](.*)\[\/groupid\]/i", lang('forum/template', 'fromgroup').': <a href="forum.php?mod=forumdisplay&fid=\\1" target="_blank">\\2</a>', $message);
		} else {
			$message = preg_replace("/(\[groupid=\d+\].*\[\/groupid\])/i", '', $message);
		}

	}
	return $htmlon ? $message : nl2br(str_replace(array("\t", '   ', '  '), array('&nbsp; &nbsp; &nbsp; &nbsp; ', '&nbsp; &nbsp;', '&nbsp;&nbsp;'), $message));
}
function substr_cut($user_name){
    $strlen     = dstrlen($user_name);
    $firstStr     = substr($user_name, 0, 1);
    $lastStr     = substr($user_name, -1, 1);
    return $strlen == 2 ? $firstStr . str_repeat('*', dstrlen($user_name) - 1) : $firstStr . str_repeat("*", $strlen - 2) . $lastStr;
}
function create_token($biaoshi) {
	//��ǰʱ���

	$timestamp = TIMESTAMP;
	dsetcookie($biaoshi,$timestamp);
	return md5( $timestamp );
}
function valid_token($alj_token,$getcook,$biaoshi) {
	if(isset($getcook) && isset($alj_token) && $alj_token == md5($getcook))
	{
		//����ȷ�������������ٵ�
		dsetcookie($biaoshi,'');
		return true;
	}
	return false;
}
function is_mobile_l($mobile) {
       return preg_match('#^\d[\d-]{3,20}\d$#', $mobile) ? true : false;
}
function getaljurl($geturl,$param){
	if($param){
		foreach($param as $k => $v){
		$geturl[$k] = $v;
		}
	}
	require_once libfile('function/home');
	return 'plugin.php?'.url_implode($geturl);
}
function tips_mes($tip,$url=''){
    global $_G,$pluginid,$settings,$gtypes_tmp,$aljzclang,$config;
    if($url){
        $face=1;
        header("Refresh:2;url=".$url);
    }
    $mall_pluginid  = 'aljfl';
    if (file_exists("source/plugin/".$mall_pluginid ."/public.php")) {
        include 'source/plugin/'.$mall_pluginid .'/public.php';
    }
    $navtitle = '&#25552;&#31034;&#20449;&#24687;';
    include template($pluginid.':tip');
    exit;
}
function ajaxPostCharSet_aljzc($arr) {
    if(is_array($arr)){
        if (strtolower(CHARSET) == 'gbk') {
            foreach ($arr as $key => $val) {
                if(is_array($val)){
                    $pt_goods[$key] = ajaxPostCharSet_aljzc($val);
                }else{
                    $pt_goods[$key] = diconv($val,'gbk','utf-8');
                }

            }
            return $pt_goods;
        }
        return $arr;
    } else {
        if (strtolower(CHARSET) == 'gbk') {
            return diconv($arr,'gbk','utf-8');
        }
        return $arr;
    }
}
//From: Dism��taobao��com
?>
