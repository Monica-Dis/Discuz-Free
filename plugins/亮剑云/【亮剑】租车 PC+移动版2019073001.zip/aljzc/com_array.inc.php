<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$comarray=array(
	1=>array('id'=>1,'file'=>'source/plugin/aljzc/template/com/moneyso.htm','name'=>lang('plugin/aljzc','com_array_1'),'desc'=>lang('plugin/aljzc','com_array_2'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48288'),
	2=>array('id'=>2,'file'=>'source/plugin/aljzc/template/com/so.htm','name'=>lang('plugin/aljzc','com_array_3'),'desc'=>lang('plugin/aljzc','com_array_4'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48289'),
	3=>array('id'=>3,'file'=>'source/plugin/aljzc/template/com/viewadv.htm','name'=>lang('plugin/aljzc','com_array_5'),'desc'=>lang('plugin/aljzc','com_array_6'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48290'),
	4=>array('id'=>4,'file'=>'source/plugin/aljzc/template/com/viewadv1.htm','name'=>lang('plugin/aljzc','com_array_7'),'desc'=>lang('plugin/aljzc','com_array_8'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48291'),
	5=>array('id'=>5,'file'=>'source/plugin/aljzc/template/com/renqi.htm','name'=>lang('plugin/aljzc','com_array_9'),'desc'=>lang('plugin/aljzc','com_array_10'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48292'),
	6=>array('id'=>6,'file'=>'source/plugin/aljzc/template/com/gg.htm','name'=>lang('plugin/aljzc','com_array_11'),'desc'=>lang('plugin/aljzc','com_array_12'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48311'),
	7=>array('id'=>7,'file'=>'source/plugin/aljzc/template/com/fenxiang.htm','name'=>lang('plugin/aljzc','com_array_13'),'desc'=>lang('plugin/aljzc','com_array_14'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48295'),
	8=>array('id'=>8,'file'=>'source/plugin/aljzc/template/com/sixin.htm','name'=>lang('plugin/aljzc','com_array_15'),'desc'=>lang('plugin/aljzc','com_array_16'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48296'),
	9=>array('id'=>9,'file'=>'source/plugin/aljzc/template/com/guanzhu.htm','name'=>lang('plugin/aljzc','com_array_17'),'desc'=>lang('plugin/aljzc','com_array_18'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48297'),
	10=>array('id'=>10,'file'=>'source/plugin/aljzc/template/com/qita.htm','name'=>lang('plugin/aljzc','com_array_19'),'desc'=>lang('plugin/aljzc','com_array_20'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48298'),
	11=>array('id'=>11,'file'=>'source/plugin/aljzc/template/com/commen.htm','name'=>lang('plugin/aljzc','com_array_21'),'desc'=>lang('plugin/aljzc','com_array_22'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48299'),
	12=>array('id'=>12,'file'=>'source/plugin/aljzc/template/com/reflash.php','name'=>lang('plugin/aljzc','com_array_23'),'desc'=>lang('plugin/aljzc','com_array_24'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48300'),
	13=>array('id'=>13,'file'=>'source/plugin/aljzc/template/com/top.php','name'=>lang('plugin/aljzc','com_array_25'),'desc'=>lang('plugin/aljzc','com_array_26'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48301'),
	16=>array('id'=>16,'file'=>'source/plugin/aljzc/template/com/user.php','name'=>lang('plugin/aljzc','com_array_31'),'desc'=>lang('plugin/aljzc','com_array_32'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48302'),
	17=>array('id'=>17,'file'=>'source/plugin/aljzc/template/com/admin.php','name'=>lang('plugin/aljzc','com_array_33'),'desc'=>lang('plugin/aljzc','com_array_34'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48303'),
	18=>array('id'=>18,'file'=>'source/plugin/aljzc/template/com/tongbu.php','name'=>lang('plugin/aljzc','com_array_35'),'desc'=>lang('plugin/aljzc','com_array_36'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48304'),
	19=>array('id'=>19,'file'=>'source/plugin/aljzc/template/com/qrcode.php','name'=>lang('plugin/aljzc','com_array_37'),'desc'=>lang('plugin/aljzc','com_array_38'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48305'),
	21=>array('id'=>21,'file'=>'source/plugin/aljzc/template/com/color.htm','name'=>lang('plugin/aljzc','com_array_41'),'desc'=>lang('plugin/aljzc','com_array_42'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48306'),
	22=>array('id'=>22,'file'=>'source/plugin/aljzc/template/mobile/index.htm','name'=>lang('plugin/aljzc','com_array_43'),'desc'=>lang('plugin/aljzc','com_array_44'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48307'),
	23=>array('id'=>23,'file'=>'source/plugin/aljzc/template/com/qita.php','name'=>lang('plugin/aljzc','com_array_45'),'desc'=>lang('plugin/aljzc','com_array_46'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48308'),
	24=>array('id'=>24,'file'=>'source/plugin/aljzc/template/com/release.php','name'=>lang('plugin/aljzc','com_array_47'),'desc'=>lang('plugin/aljzc','com_array_48'),'url'=>'http://DisM.taobao.com/?@aljzc.plugin.48309'),

);
?>