<?php

bypayment();

function bypayment(){

    $tmp   = DB::fetch_all('select * from %t', array('aljayy_goods'));
    foreach($tmp as $aljayy){
        $aljayyList[$good['goods_id']] = $good; 
    }

    $goodsList = DB::fetch_all('select * from %t where rubbish = 0', array('aljbd_goods'));

    foreach($goodsList as $good){
        if(empty($aljayyList[$good[id]])){
            DB::insert('aljayy_goods', array(
                'goods_id' => $good[id],
                'reduction_method' => 'bypayment',
                'dateline' => TIMESTAMP,
            ));
        }
    }

    DB::query('update %t set category = %s where reduction_method!=%s', array('aljbd_goods', 'bypayment', 'bypayment'));

}