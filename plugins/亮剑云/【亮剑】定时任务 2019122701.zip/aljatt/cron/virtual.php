<?php

toVirtualGoods();

function toVirtualGoods(){
    DB::query('update %t set category = 1 where category=0', array('aljbd_goods'));
}