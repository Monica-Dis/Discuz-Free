<?php

DB::query('update %t set status = 1 where status = 0 and dateline + 7200  < %d limit 1', array('aljhy_work_order', TIMESTAMP));