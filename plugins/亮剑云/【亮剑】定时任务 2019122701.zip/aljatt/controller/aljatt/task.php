<?php

/**
 * DisM!Ӧ�������̳�
 *
 * [DisM!] (C)2019-2021 DISM.Taobao.COM.
 * @version 2019072701
 * @link https://www.liangjianyun.com/
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class TaskAction{
    public $page;

    public function __construct() {
        global $requestPage;
        $this->page = $requestPage;
    }
    public function list_index(){
        global $_G;
        if($this->page->get->render == 'yes'){
            $per = 5;
            $page = $this->page->get->page>0 ? $this->page->get->page :1;
            $start = ($page - 1) * $per;
            
           
            $logList = DB::fetch_all('select * from %t order by id desc limit %d, %d', array('aljhtx_cron_script', $start, $per));
            $count = DB::result_first('select count(*) from %t', array('aljhtx_cron_script'));
           
            foreach($logList as $k => $v){
                if($v['last'] > 0){
                    $logList[$k]['last'] = dgmdate($v['last'], 'u');
                }else{
                    $logList[$k]['last'] = '--';
                }
                
            }
            T::responseJson(array(
                'code' => 0,
                'msg' => "",
                'count' => $count,
                'data' => $logList
            ));
        }

        if($_G['cache']['plugin']['mapp_template'] && !DB::fetch_first('select * from %t where file=%s', array('aljhtx_cron_script', 'source/plugin/mapp_template/cron/cron.php'))){
            DB::insert('aljhtx_cron_script', array(
                'name' => 'MAPP'.lang("plugin/aljatt","task_php_1"),
                'file' => 'source/plugin/mapp_template/cron/cron.php',
                'cycle' => 5,
                'open' => 'on'
            ));
        }

        if(!DB::fetch_first('select * from %t where file=%s',array('aljhtx_cron_script','source/plugin/aljhtx/api/auto.php'))){
            DB::insert('aljhtx_cron_script',array('name'=>lang("plugin/aljatt","task_php_2"),'file'=>'source/plugin/aljhtx/api/auto.php','cycle'=>'5','open'=>'on'));
        }

        $this->page->display();
    }

    public function list_delete(){
        global $_G;
        DB::delete('aljhtx_cron_script', array('id' => $_GET['tid']));
        T::responseJson();
    }


    public function list_submit(){
        global $_G;
        $tid = intval($_GET['tid']);
        if($tid){
            $task = DB::fetch_first('select * from %t where id=%d', array('aljhtx_cron_script', $tid));
        }
        
        if(submitcheck('formhash')){
            if($tid){
                DB::update('aljhtx_cron_script', array(
                    'name' => $_GET['name'],
                    'file' => $_GET['file'],
                    'cycle' => $_GET['cycle'],
                    'open' => $_GET['open']
                ), array('id' => $tid));
            }else{
                DB::insert('aljhtx_cron_script', array(
                    'name' => $_GET['name'],
                    'file' => $_GET['file'],
                    'cycle' => $_GET['cycle'],
                    'open' => $_GET['open'],
                    'type' => 1
                ));
            }
            $this->page->tips();
        }else{
            $this->page->assign('task', $task);
            $this->page->display();
        }
        
    }
}

