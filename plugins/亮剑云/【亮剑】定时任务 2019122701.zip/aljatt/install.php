<?php
/*
	Copyright (c) 2021 by dism.taobao.com
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljhtx_cron_script` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `intro` text NOT NULL,
  `file` varchar(255) NOT NULL,
  `cycle` int(11) NOT NULL,
  `last` int(11) NOT NULL,
  `open` char(10) NOT NULL,
  `type` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`)
);
EOF;
runquery($sql);
$sql ="ALTER TABLE  ".DB::table('aljhtx_cron_script')." ADD `name` VARCHAR(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljhtx_cron_script')." ADD `type` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljhtx_cron_script')." ADD `intro` text NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljhtx_cron_script')." CHANGE `name` `name` VARCHAR(255) NOT NULL" ;
DB::query($sql,'SILENT');
//finish to put your own code
$finish = TRUE;
?>