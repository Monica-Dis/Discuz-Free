<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
//$langid=$_GET['langid'];updatecache();
require_once libfile('class/xml');
include template('aljpluginlang:nav');
$lj_plugin = DB::fetch_first("SELECT * FROM ".DB::table('common_plugin')." WHERE identifier='".$langid."'");
$lj_dir = substr($lj_plugin['directory'], 0, -1);
$lj_modules = unserialize($lj_plugin['modules']);
if($_GET['cache']=='gl'){
	include template('aljpluginlang:gl');
}else if($_GET['cache']=='p_s'){
	if(!submitcheck('addsubmit')) {
		$cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_template'");
		$data=unserialize($cache);
		if(!$data[$langid]){
			cpmsg(lang('plugin/aljpluginlang','lang7'));
		}
		//debug($data[$langid]);
		if(!C::t('#aljpluginlang#alj_plugin')->fetch_count($langid.'2')||C::t('#aljpluginlang#alj_plugin')->fetch_count($langid.'2')<count($data[$langid])){

			foreach($data[$langid] as $k=>$s){
				if(!C::t('#aljpluginlang#alj_plugin')->fetch_count_sign($k,$langid.'2')){
					C::t('#aljpluginlang#alj_plugin')->insert(array(
						'plugin_b'=>$k,
						'plugin_w'=>$s,
						'plugin_sign'=>$langid.'2',
					));
				}
			}
		}
		if(!C::t('#aljpluginlang#alj_plugin')->fetch_count($langid.'4')||C::t('#aljpluginlang#alj_plugin')->fetch_count($langid.'4')<count($data[$langid])){

			foreach($data[$langid] as $k=>$s){
				if(!C::t('#aljpluginlang#alj_plugin')->fetch_count_sign($k,$langid.'4')){
					C::t('#aljpluginlang#alj_plugin')->insert(array(
						'plugin_b'=>$k,
						'plugin_w'=>$s,
						'plugin_sign'=>$langid.'4',
					));
				}
			}
		}
		if(!C::t('#aljpluginlang#alj_plugin')->fetch_count($langid.'6')||C::t('#aljpluginlang#alj_plugin')->fetch_count($langid.'6')<count($data[$langid])){

			foreach($data[$langid] as $k=>$s){
				if(!C::t('#aljpluginlang#alj_plugin')->fetch_count_sign($k,$langid.'6')){
					C::t('#aljpluginlang#alj_plugin')->insert(array(
						'plugin_b'=>$k,
						'plugin_w'=>$s,
						'plugin_sign'=>$langid.'6',
					));
				}
			}
		}
		$plugin_bw_3=C::t('#aljpluginlang#alj_plugin')->fetch_all_by_sign($langid.'4');
		$plugin_bw_3=dhtmlspecialchars($plugin_bw_3);
		foreach($plugin_bw_3 as $ss){
			$lang_qian[$ss['plugin_b']]=$ss['plugin_w'];
		}
		$plugin_bw=$data[$langid];
		$url=ADMINSCRIPT.'?action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&langid='.$langid.'&cache=p_s&lang=pluginlang';
		include template('aljpluginlang:scache');
	}else{
		if(is_array($_GET['plugin_all'])){
			foreach($_GET['plugin_all'] as $b=>$w){
				if($b){
					DB::update('alj_plugin',array('plugin_w'=>$w),array('plugin_b'=>$b,'plugin_sign'=>$langid.'2'));
					DB::update('alj_plugin',array('plugin_w'=>$w),array('plugin_b'=>$b,'plugin_sign'=>$langid.'6'));
				}
			}
			$cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_template'");
			$data=unserialize($cache);
			$data[$langid]=$_GET['plugin_all'];
			savecache('pluginlanguage_template', $data);
			cleartemplatecache();
			$file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';
			//debug($file);
			if(file_exists($file)) {
				$importtxt = @implode('', file($file));
				$data = $GLOBALS['importtxt'];
				//debug($GLOBALS);
				$xmldata = xml2array($data);
				$xmldata['Data']['language']['templatelang']=$_GET['plugin_all'];
				//debug($xmldata);
				$handle=fopen($file,"w");
				if(!$handle){
					cpmsg(lang('plugin/aljpluginlang','lang28'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=p_s', 'error');
				}
				if(fwrite($handle,array2xml($xmldata,1))){
					fclose($handle);
					updatecache(array('plugin'));
					cleartemplatecache();
					cpmsg(lang('plugin/aljpluginlang','lang29'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=p_s', 'succeed');
				}
				fclose($handle);
				cpmsg(lang('plugin/aljpluginlang','lang28'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=p_s', 'error');
			}
		}
		cpmsg(lang('plugin/aljpluginlang','lang21'),'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=p_s');
	}
}else if($_GET['cache']=='geshihua3'){//��ʽ���ű�
	if($_GET['formhash']==formhash()){
		$plugin_bw=C::t('#aljpluginlang#alj_plugin')->fetch_all_by_sign($langid.'3');
		foreach($plugin_bw as $w){
			DB::update('alj_plugin',array('plugin_w'=>$w['plugin_w']),array('plugin_b'=>$w['plugin_b'],'plugin_sign'=>$langid.'1'));
			$plugin_data[$w['plugin_b']]=$w['plugin_w'];
		}

		$cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_script'");
		$data=unserialize($cache);
		$result = array_merge($data[$langid], $plugin_data);

		$data[$langid]=$result;
		savecache('pluginlanguage_script', $data);
		cleartemplatecache();
		$file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';
		//debug($file);
		if(file_exists($file)) {
			$importtxt = @implode('', file($file));
			$data = $GLOBALS['importtxt'];
			//debug($GLOBALS);
			$xmldata = xml2array($data);
			$xmldata['Data']['language']['scriptlang']=$result;
			//debug($xmldata);
			$handle=fopen($file,"w");
			if(!$handle){
					cpmsg(lang('plugin/aljpluginlang','lang31'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=gl', 'error');
			}
			if(fwrite($handle,array2xml($xmldata,1))){
				fclose($handle);
				updatecache(array('plugin'));
				cleartemplatecache();
				cpmsg(lang('plugin/aljpluginlang','lang32'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=gl', 'succeed');
			}
			fclose($handle);
			cpmsg(lang('plugin/aljpluginlang','lang31'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=gl', 'error');
		}
		cpmsg(lang('plugin/aljpluginlang','lang41'),'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=gl');
	}

}else if($_GET['cache']=='geshihua4'){//��ʽ��ģ��
	if($_GET['formhash']==formhash()){
		$plugin_bw=C::t('#aljpluginlang#alj_plugin')->fetch_all_by_sign($langid.'4');
		foreach($plugin_bw as $w){
			DB::update('alj_plugin',array('plugin_w'=>$w['plugin_w']),array('plugin_b'=>$w['plugin_b'],'plugin_sign'=>$langid.'2'));
			$plugin_data[$w['plugin_b']]=$w['plugin_w'];
		}
		$cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_template'");
		$data=unserialize($cache);

		$result = array_merge($data[$langid], $plugin_data);

		$data[$langid]=$result;
		savecache('pluginlanguage_template', $data);
		cleartemplatecache();
		$file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';
		//debug($file);
		if(file_exists($file)) {
			$importtxt = @implode('', file($file));
			$data_g = $GLOBALS['importtxt'];
			//debug($GLOBALS);
			$xmldata = xml2array($data_g);
			$xmldata['Data']['language']['templatelang']=$result;
			//debug($xmldata);
			$handle=fopen($file,"w");
			if(!$handle){
				cpmsg(lang('plugin/aljpluginlang','lang35'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=gl', 'error');
			}
			if(fwrite($handle,array2xml($xmldata,1))){
				fclose($handle);
				updatecache(array('plugin'));
				cleartemplatecache();
				cpmsg(lang('plugin/aljpluginlang','lang36'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=gl', 'succeed');
			}
			fclose($handle);
			cpmsg(lang('plugin/aljpluginlang','lang35'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=gl', 'error');
		}
		cpmsg(lang('plugin/aljpluginlang','lang41'),'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=gl');
	}
}else if($_GET['cache']=='huifu5'){//�ָ��޸Ľű�
	if($_GET['formhash']==formhash()){
		$plugin_bw=C::t('#aljpluginlang#alj_plugin')->fetch_all_by_sign($langid.'5');
		foreach($plugin_bw as $w){
			DB::update('alj_plugin',array('plugin_w'=>$w['plugin_w']),array('plugin_b'=>$w['plugin_b'],'plugin_sign'=>$langid.'1'));
			$plugin_data[$w['plugin_b']]=$w['plugin_w'];
		}
		$cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_script'");
		$data=unserialize($cache);
		//debug($data);
		$result = array_merge($data[$langid], $plugin_data);

		$data[$langid]=$result;
		savecache('pluginlanguage_script', $data);
		cleartemplatecache();
		$file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';
		//debug($file);
		if(file_exists($file)) {
			$importtxt = @implode('', file($file));
			$data = $GLOBALS['importtxt'];
			//debug($GLOBALS);
			$xmldata = xml2array($data);
			$xmldata['Data']['language']['scriptlang']=$result;
			//debug($xmldata);
			$handle=fopen($file,"w");
			if(!$handle){
					cpmsg(lang('plugin/aljpluginlang','lang39'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=gl', 'error');
			}
			if(fwrite($handle,array2xml($xmldata,1))){
				fclose($handle);
				updatecache(array('plugin'));
				cleartemplatecache();
				cpmsg(lang('plugin/aljpluginlang','lang40'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=gl', 'succeed');
			}
			fclose($handle);
			cpmsg(lang('plugin/aljpluginlang','lang39'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=gl', 'error');
		}
		cpmsg(lang('plugin/aljpluginlang','lang42'),'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=gl');
	}
}else if($_GET['cache']=='huifu6'){//�ָ��޸�ģ��
	if($_GET['formhash']==formhash()){
		$plugin_bw=C::t('#aljpluginlang#alj_plugin')->fetch_all_by_sign($langid.'6');
		foreach($plugin_bw as $w){
			DB::update('alj_plugin',array('plugin_w'=>$w['plugin_w']),array('plugin_b'=>$w['plugin_b'],'plugin_sign'=>$langid.'2'));
			$plugin_data[$w['plugin_b']]=$w['plugin_w'];
		}
		$cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_template'");
		$data=unserialize($cache);

		$result = array_merge($data[$langid], $plugin_data);

		$data[$langid]=$result;
		savecache('pluginlanguage_template', $data);
		cleartemplatecache();
		$file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';
		//debug($file);
		if(file_exists($file)) {
			$importtxt = @implode('', file($file));
			$data = $GLOBALS['importtxt'];
			//debug($GLOBALS);
			$xmldata = xml2array($data);
			$xmldata['Data']['language']['templatelang']=$result;
			//debug($xmldata);
			$handle=fopen($file,"w");
			if(!$handle){
					cpmsg(lang('plugin/aljpluginlang','lang37'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=gl', 'error');
			}
			if(fwrite($handle,array2xml($xmldata,1))){
				fclose($handle);
				updatecache(array('plugin'));
				cleartemplatecache();
				cpmsg(lang('plugin/aljpluginlang','lang38'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=gl', 'succeed');
			}
			fclose($handle);
			cpmsg(lang('plugin/aljpluginlang','lang37'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=gl', 'error');
		}
		cpmsg(lang('plugin/aljpluginlang','lang42'),'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$langid.'&cache=gl');
	}
}else{
	if(!submitcheck('addsubmit')) {
		$cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_script'");
		$data=unserialize($cache);
		if(!$data[$langid]){
			cpmsg(lang('plugin/aljpluginlang','lang7'));
		}

		if(!C::t('#aljpluginlang#alj_plugin')->fetch_count($langid.'1')||C::t('#aljpluginlang#alj_plugin')->fetch_count($langid.'1')<count($data[$langid])){

			foreach($data[$langid] as $k=>$s){
				if(!C::t('#aljpluginlang#alj_plugin')->fetch_count_sign($k,$langid.'1')){
					C::t('#aljpluginlang#alj_plugin')->insert(array(
						'plugin_b'=>$k,
						'plugin_w'=>$s,
						'plugin_sign'=>$langid.'1',
					));
				}
			}
		}
		if(!C::t('#aljpluginlang#alj_plugin')->fetch_count($langid.'3')||C::t('#aljpluginlang#alj_plugin')->fetch_count($langid.'3')<count($data[$langid])){

			foreach($data[$langid] as $k=>$s){
				if(!C::t('#aljpluginlang#alj_plugin')->fetch_count_sign($k,$langid.'3')){
					C::t('#aljpluginlang#alj_plugin')->insert(array(
						'plugin_b'=>$k,
						'plugin_w'=>$s,
						'plugin_sign'=>$langid.'3',
					));
				}
			}
		}
		if(!C::t('#aljpluginlang#alj_plugin')->fetch_count($langid.'5')||C::t('#aljpluginlang#alj_plugin')->fetch_count($langid.'5')<count($data[$langid])){

			foreach($data[$langid] as $k=>$s){
				if(!C::t('#aljpluginlang#alj_plugin')->fetch_count_sign($k,$langid.'5')){
					C::t('#aljpluginlang#alj_plugin')->insert(array(
						'plugin_b'=>$k,
						'plugin_w'=>$s,
						'plugin_sign'=>$langid.'5',
					));
				}
			}
		}
		$plugin_bw_3=C::t('#aljpluginlang#alj_plugin')->fetch_all_by_sign($langid.'3');
		$plugin_bw_3=dhtmlspecialchars($plugin_bw_3);
		foreach($plugin_bw_3 as $ss){
			$lang_qian[$ss['plugin_b']]=$ss['plugin_w'];
		}

		$plugin_bw=$data[$langid];
		//debug($lang_qian);
		//debug($langid);
		$url=ADMINSCRIPT.'?action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&langid='.$langid.'&lang=pluginlang';
		include template('aljpluginlang:scache');
	}else{
		if(is_array($_GET['plugin_all'])){
			foreach($_GET['plugin_all'] as $b=>$w){
				if($b){
					DB::update('alj_plugin',array('plugin_w'=>$w),array('plugin_b'=>$b,'plugin_sign'=>$langid.'1'));
					DB::update('alj_plugin',array('plugin_w'=>$w),array('plugin_b'=>$b,'plugin_sign'=>$langid.'5'));
				}
			}
			$cache=DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_script'");
			$data=unserialize($cache);
			//debug($data);
			$data[$langid]=$_GET['plugin_all'];
			//debug($data[$langid]);
			savecache('pluginlanguage_script', $data);
			cleartemplatecache();
			$file = DISCUZ_ROOT.'./source/plugin/'.$lj_dir.'/discuz_plugin_'.$lj_dir.($lj_modules['extra']['installtype'] ? '_'.$lj_modules['extra']['installtype'] : '').'.xml';
			//debug($file);
			if(file_exists($file)) {
				$importtxt = @implode('', file($file));
				$data = $GLOBALS['importtxt'];
				//debug($GLOBALS);
				$xmldata = xml2array($data);
				$xmldata['Data']['language']['scriptlang']=$_GET['plugin_all'];
				//debug($xmldata);
				$handle=fopen($file,"w");
				if(!$handle){
						cpmsg(lang('plugin/aljpluginlang','lang33'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&langid='.$langid.'&lang=pluginlang', 'error');
				}
				if(fwrite($handle,array2xml($xmldata,1))){
					fclose($handle);
					updatecache(array('plugin'));
					cleartemplatecache();
					cpmsg(lang('plugin/aljpluginlang','lang34'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&langid='.$langid.'&lang=pluginlang', 'succeed');
				}
				fclose($handle);
				cpmsg(lang('plugin/aljpluginlang','lang33'), 'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&langid='.$langid.'&lang=pluginlang', 'error');
			}
		}
		cpmsg(lang('plugin/aljpluginlang','lang21'),'action=plugins&operation=config&identifier=aljpluginlang&pmod=aljpluginlang&langid='.$langid.'&lang=pluginlang');
	}
}
//From: Dism��taobao��com
?>
