<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if( ! defined('IN_DISCUZ') || ! defined('IN_ADMINCP')) {
    exit('Access Denied');
}

//start to put your own code 

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_alj_plugin` (
  `id` int(11) NOT NULL auto_increment,
  `plugin_b` varchar(255) NOT NULL,
  `plugin_w` mediumtext NOT NULL,
  `plugin_sign` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
);
EOF;

runquery($sql);
//finish to put your own code
$finish = TRUE;
?>