<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-09-01
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

echo '<table class="tb tb2 " id="tips">
	<tr>
		<th  class="partition">'.lang('plugin/aljpluginlang','lang24').'</th>
	</tr>
	<tr>
		<td class="tipsblock" s="1">
			<ul id="tipslis">
				<li>'.lang('plugin/aljpluginlang','lang25').'</li>
				<li>'.lang('plugin/aljpluginlang','lang26').'</li>
				<li>'.lang('plugin/aljpluginlang','lang43').'</li>
			</ul>
		</td>
	</tr>
</table><br>';
if($_GET['lang']=='pluginlang'){
	$langid=$_GET['langid'];
	include_once DISCUZ_ROOT.'source/plugin/aljpluginlang/cache.inc.php';
}else{
	if(!submitcheck('submit')) {
		showformheader('');
		showtableheader('');
		showsubtitle(array(lang('plugin/aljpluginlang','lang1'),lang('plugin/aljpluginlang','lang2'),lang('plugin/aljpluginlang','lang3'),lang('plugin/aljpluginlang','lang4'),lang('plugin/aljpluginlang','lang5')));
		$lj_pluginlang = C::t('common_plugin')->range('','','desc');
		//$lj_pluginlang = DB::fetch_all("select * from ".DB::table('common_plugin')." where available=1 order by pluginid desc");
		//debug($lj_pluginlang);
		foreach($lj_pluginlang as $lang){
			showtablerow('', array('', 'class="td_m"', 'class="td_k"', 'class="td_l"','class="td_l"','class="td_l"'), array(
							$lang['name'],
							$lang['copyright'],
							$lang['identifier'],
							$lang['version'],
							'<a href="admin.php?action=plugins&operation=config&do=76&identifier=aljpluginlang&pmod=aljpluginlang&lang=pluginlang&langid='.$lang['identifier'].'">'.lang('plugin/aljpluginlang','lang6').'</a>',
							));
		}
		showsubmit('', '', '','',$paging);
		showtablefooter();/*Dism-taobao��com*/
		showformfooter();
	}
}
//From: Dism��taobao��com
?>
