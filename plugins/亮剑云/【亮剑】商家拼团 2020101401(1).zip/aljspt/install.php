<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `collage_price` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods')." ADD `collage_num` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `opentime` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `collage_num` int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `collage_num` int(10) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `collage_order` char(32) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `collage_order` char(32) NOT NULL" ;
DB::query($sql,'SILENT');
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljspt_collage_order` (
`id` int(10) NOT NULL AUTO_INCREMENT,
  `grouporderid` varchar(255) NOT NULL,
  `groupheadusername` varchar(255) NOT NULL,
  `groupheaduid` int(10) NOT NULL,
  `groupopentime` varchar(255) NOT NULL,
  `grouporderprice` varchar(255) NOT NULL,
  `groupnum` INT(11) NOT NULL,
  `groupnumed` INT(11) NOT NULL,
  `grouporderstatus` int(10) NOT NULL,
  `orderid` varchar(255) NOT NULL,
  `goodsid` varchar(255) NOT NULL,
  `create_time` int(10) NOT NULL,
  `update_time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
)
EOF;
runquery($sql);
//��ҳͼ�Ĺ�� ƴ��
$mobile_index_Photo_Ads = C::t('#aljbd#aljbd_setting')->fetch('mobile_index_Photo_Ads');
if($mobile_index_Photo_Ads){
    $mobile_index_Photo_Ads['value'] .= '
&#25340;&#22242;|&#22810;&#20154;&#25340;&#22242;&#20215;&#26684;&#23454;&#24800;|//liangjianyun.oss-cn-shanghai.aliyuncs.com/aljbd/index/icon_pt.png|#';
    C::t('#aljbd#aljbd_setting')->update_value_by_key($mobile_index_Photo_Ads['value'],'mobile_index_Photo_Ads');
}
//finish to put your own code
$finish = TRUE;
?>
