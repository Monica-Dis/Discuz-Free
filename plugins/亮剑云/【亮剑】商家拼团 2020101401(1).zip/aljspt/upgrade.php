<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljspt_collage_order` (
`id` int(10) NOT NULL AUTO_INCREMENT,
  `grouporderid` varchar(255) NOT NULL,
  `groupheadusername` varchar(255) NOT NULL,
  `groupheaduid` int(10) NOT NULL,
  `groupopentime` varchar(255) NOT NULL,
  `grouporderprice` varchar(255) NOT NULL,
  `groupnum` INT(11) NOT NULL,
  `groupnumed` INT(11) NOT NULL,
  `grouporderstatus` int(10) NOT NULL,
  `orderid` varchar(255) NOT NULL,
  `goodsid` varchar(255) NOT NULL,
  `create_time` int(10) NOT NULL,
  `update_time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
);
EOF;
runquery($sql);
$sql ="ALTER TABLE ".DB::table('aljspt_collage_order')." CHANGE `groupnumed` `groupnumed` INT(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljspt_collage_order')." CHANGE `groupnum` `groupnum` INT(11) NOT NULL" ;
DB::query($sql,'SILENT');

$finish = TRUE;
?>