<?php

/**
 * Controller�����ƺ��Զ��ύ����ģ��
 *
 * @author yuxinqi<yuxinqi@vip.qq.com>
 * @version 1.0
 * @link http://docs.liangjianyun.com/
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class XiongZhangAction{
    public $page;

    public function __construct() {
        global $requestPage;
        $this->page = $requestPage;
    }

    public function list_submit_thread(){
        global $_G;
        $curPage = $this->page->get->curpage ? $this->page->get->curpage : 1;//��ǰҳ
        $nextPage = $curPage + 1;
        $perPageNum = 1;//ÿ�����������ٸ�����
        $userNum = DB::result_first('select count(*) from %t where displayorder>=0 AND closed=0', array('forum_thread'));
        $maxPapge = ceil($userNum/$perPageNum);
        $start = ($curPage-1) * $perPageNum;//��������ʼ����
        //$start = $start ? $start : 1;
        $end  = $start+($perPageNum>=$userNum ? $userNum: $perPageNum);//������������������
        if($curPage > $maxPapge){
            header('Location: plugin.php?id=aljseo&c=xiongzhang&a=showUpdateMessage');
            exit;
        }
        $threadList = DB::fetch_all('select * from %t where displayorder>=0 AND closed=0 limit %d, %d', array('forum_thread', $start, $perPageNum));
        foreach($threadList as $thread){
            if($_G['setting']['rewritestatus']){
                $url = $_G['siteurl'].'thread-'.$thread['tid'].'-1-1.html';
            }else{
                $url = $_G['siteurl'].'forum.php?mod=viewthread&tid='.$thread['tid'];
            }
            if(!DB::result_first('select count(*) from %t where url=%s', array('aljseo_xiongzhang_url', $url))){
                $this->push($url);
            }
        }

        $progressBar = T::getObject('progressbar', array(
            'requestPage' => $this->page,
            'tips' => lang("plugin/aljseo","xiongzhang_php_2").$start.'-'.$end.lang("plugin/aljseo","xiongzhang_php_3"),
            'curPage' => $curPage,
            'maxPage' => $maxPapge ? $maxPapge : 1,
            'url' => 'plugin.php?id=aljseo&c=xiongzhang&a=list_submit_thread&ajax=yes&formhash='.FORMHASH.'&curpage='.$nextPage,
            'goUrl' => 'plugin.php?id=aljseo&c=xiongzhang&a=showupdatemessage',
        ));
        $progressBar->start(); //���ؽ�����ģ��
    }

    public function list_submit_goods(){
        global $_G;
        $curPage = $this->page->get->curpage ? $this->page->get->curpage : 1;//��ǰҳ
        $nextPage = $curPage + 1;
        $perPageNum = 1;//ÿ�����������ٸ���Ʒ
        $userNum = DB::result_first('select count(*) from %t where rubbish=0', array('aljbd_goods'));
        $maxPapge = ceil($userNum/$perPageNum);
        $start = ($curPage-1) * $perPageNum;//��������ʼ��Ʒ
        //$start = $start ? $start : 1;
        $end  = $start+($perPageNum>=$userNum ? $userNum: $perPageNum);//������������Ʒ����
        if($curPage > $maxPapge){
            header('Location: plugin.php?id=aljseo&c=xiongzhang&a=showUpdateMessage');
            exit;
        }
        $goodsList = DB::fetch_all('select * from %t where rubbish=0 limit %d, %d', array('aljbd_goods', $start, $perPageNum));
        foreach($goodsList as $goods){
            $url = $_G['siteurl'].'plugin.php?id=aljbd&act=goodview&bid='.$goods['bid'].'&gid='.$goods['id'];
            if(!DB::result_first('select count(*) from %t where url=%s', array('aljseo_xiongzhang_url', $url))){
                $this->push($url);
            }
        }

        $progressBar = T::getObject('progressbar', array(
            'requestPage' => $this->page,
            'tips' => lang("plugin/aljseo","xiongzhang_php_4").$start.'-'.$end.lang("plugin/aljseo","xiongzhang_php_5"),
            'curPage' => $curPage,
            'maxPage' => $maxPapge ? $maxPapge : 1,
            'url' => 'plugin.php?id=aljseo&c=xiongzhang&a=list_submit_goods&ajax=yes&formhash='.FORMHASH.'&curpage='.$nextPage,
            'goUrl' => 'plugin.php?id=aljseo&c=xiongzhang&a=showupdatemessage',
        ));
        $progressBar->start(); //���ؽ�����ģ��
    }

    /**
     * �����������ʾҳ
     *
     * @return void
     */
    public function showUpdateMessage(){
        $this->page->showMessage(lang("plugin/aljseo","xiongzhang_php_6"), '<a style="color: rgb(30, 159, 255);" href="plugin.php?id=aljseo&c=xiongzhang&a=list">' . lang("plugin/aljseo","xiongzhang_php_1") . '</a>');
    }

    public function list_index(){
        global $_G;
        if($this->page->get->render == 'yes'){
            $per = 20;
            $page = $this->page->get->page>0 ? $this->page->get->page :1;
            $start = ($page - 1) * $per;
            if($_GET['type']){
                $logList = DB::fetch_all('select * from %t where type=%s order by id desc limit %d, %d', array('aljseo_xiongzhang_url', $_GET['type'], $start, $per));
                $count = DB::result_first('select count(*) from %t where type=%s', array('aljseo_xiongzhang_url', $_GET['type']));
            }else{
                $logList = DB::fetch_all('select * from %t order by id desc limit %d, %d', array('aljseo_xiongzhang_url', $start, $per));
                $count = DB::result_first('select count(*) from %t', array('aljseo_xiongzhang_url'));
            }
            foreach($logList as $k => $v){
                $logList[$k]['dateline'] = dgmdate($v['dateline'], 'u');
                $logList[$k]['msg'] = htmlspecialchars($v['msg']);

            }
            T::responseJson(array(
                'code' => 0,
                'msg' => "",
                'count' => $count,
                'data' => $logList
            ));
        }

        loadcache('batch');
        loadcache('realtime');
        $this->page->assign('remain_realtime', $_G['cache']['realtime']['remain_realtime']);
        $this->page->assign('remain_batch', $_G['cache']['batch']['remain_batch']);
        $this->page->display();
    }

    public function list_delete(){
        DB::delete('aljseo_xiongzhang_url', array('id' => $_GET['mid']));
        T::responseJson();
    }


    public function list_submit(){
        global $_G;
        $type = $_GET['type'];
        if(submitcheck('formhash')){
            $urlList = explode("\n", $_GET['url']);
            if($urlList){
                foreach($urlList as $url){
                    $this->push($url, $type);
                }
            }
            $this->page->tips();
        }else{
            $this->page->display();
        }
    }

    public function push($urlList, $type = 'batch'){
        if(is_array($urlList)){
            $urls = $urlList;
        }else{
            $urls = array($urlList);
        }
        $api = 'http://data.zz.baidu.com/urls?appid='.$this->page->config->aljseo->appid.'&token='.$this->page->config->aljseo->token.'&type='.$type;
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        $result = json_decode($result, true);
        if(isset($result['success'])){
            savecache($type, $result);
        }
        if($result['success']){
            $success = 1;
        }else{
            $success = 0;
        }
        DB::insert('aljseo_xiongzhang_url', array(
            'url' => $urlList,
            'day' => date('Ymd'),
            'dateline' => TIMESTAMP,
            'type' => $_GET['type'],
            'success' => $success,
            'msg' => json_encode($result)
        ), true);
    }
}

