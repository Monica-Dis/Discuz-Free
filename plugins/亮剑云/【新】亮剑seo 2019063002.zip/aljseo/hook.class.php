<?php

/**
 *ȫ�ִ�����ʱ����
 *
 * @author yuxinqi<yuxinqi@vip.qq.com>
 * @version 1.0
 * @link http://docs.liangjianyun.com/
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_aljms {

    function common() {
        global $_G;
        $ms_salse_tips_list = DB::fetch_all('select * from %t where ms_date=%d', array('aljhtx_activity_ms_sale_tips', dgmdate(TIMESTAMP, 'Ymd')));
        foreach($ms_salse_tips_list as $ms_salse_tips){
            if(!$ms_salse_tips['ms_start_time']){
                continue;
            }
            if(strtotime($ms_salse_tips['ms_start_time'])+15*60 > TIMESTAMP){
                $content = $_G['cache']['plugin']['aljms']['ms_sale_tips_content'];
                $content = str_replace(array('{title}', '{time}'), array($ms_salse_tips['ms_goods_title'], $ms_salse_tips['ms_start_time']), $content);
                Message::sendNotification($ms_salse_tips['ms_sale_tips_uid'], '<a href="plugin.php?id=aljbd&gid='.$ms_salse_tips['ms_goods_id'].'">'.$content.'</a>');
                DB::delete('aljhtx_activity_ms_salse_tips', array(
                    'ms_sale_tips_id' => $ms_salse_tips['ms_sale_tips_id'],
                ));
            }
        }
    }

}

class mobileplugin_aljms {

    function common() {
        global $_G;

    }

}
