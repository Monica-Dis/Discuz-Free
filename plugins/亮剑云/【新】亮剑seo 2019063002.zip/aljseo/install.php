<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE `pre_aljseo_xiongzhang_url` (
  `id` int(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  `type` char(50) NOT NULL,
  `dateline` int(11) NOT NULL,
  `included` tinyint(3) NOT NULL,
  `day` int(11) NOT NULL,
  `success` tinyint(3) NOT NULL,
  `msg` varchar(255) NOT NULL
);
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>