<?php
/*
	Copyright (c) 2021 by dism.taobao.com
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


$sql ="ALTER TABLE ".DB::table('aljbd_goods_order')." ADD `get_to_the_shop` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_goods_order_list')." ADD `get_to_the_shop` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_write_off_code')." ADD `price` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljbd_write_off_code')." ADD `reason` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$finish = TRUE;
?>