<?php
/*
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//����������
function setsmstemplate($identifier,$variable,$title,$defaultsetting=array(),$defaultcontent=''){  //$defaultvalue = array('code' => '123','product' => '456');
	if(!$defaultcontent){
		foreach($defaultsetting as $tmp_key => $tmp_value){
			$defaultcontent .= '${'.$tmp_key.'}';
		}
	}
	DB::insert('aljdx',array(
		'dx_switch' => 1,
		'dx_identifier'=>addslashes($identifier),
		'dx_variable'=>addslashes($variable),
		'dx_title'=>addslashes($title),
		'dx_setting'=>serialize($defaultsetting),
		'dx_content'=>addslashes($defaultcontent),
	));
}
//�����Ƿ��д��ڸ�����¼
function getsmstemplate($identifier,$variable){
	$count=DB::result_first('select count(*) from %t where dx_identifier=%s and dx_variable=%s',array('aljdx',$identifier,$variable));
	return $count;
}

//���Ͷ���
function sendsmsbyvar($phone,$identifier,$variable,$defaultsetting=array()){
	global $_G;
	loadcache('plugin');
	$config = $_G['cache']['plugin']['aljdx'];
	$setting=DB::fetch_first('select * from %t where dx_identifier=%s and dx_variable=%s',array('aljdx',$identifier,$variable));
	if($setting['dx_switch']){
		$dx_setting=unserialize($setting['dx_setting']);
		foreach($defaultsetting as $tmp_key=>$tmp_value){
				$dx_setting[$tmp_key]=$tmp_value;
		}
		$sms_param=encode_json($dx_setting);
		if(strtolower(CHARSET) == 'gbk'){
			$sms_param = diconv($sms_param,CHARSET,'utf-8');
			$config['sms_free_sign_name'] = diconv($config['sms_free_sign_name'],CHARSET,'utf-8');
		}
		if($config['isaliyun']){
			$params = array (   //�˴������޸�
		            'SignName' => $config['sms_free_sign_name'],
		            'Format' => 'JSON',
		            'Version' => '2017-05-25',
		            'AccessKeyId' => $config['appkey'],
		            'SignatureVersion' => '1.0',
		            'SignatureMethod' => 'HMAC-SHA1',
		            'SignatureNonce' => uniqid (),
		            'Timestamp' => gmdate ( 'Y-m-d\TH:i:s\Z' ),
		            'Action' => 'SendSms',
		            'TemplateCode' => $setting['dx_smsid'],
		            'PhoneNumbers' => $phone,
		            'TemplateParam' => $sms_param
		    );
			$params ['Signature'] = computeSignature ( $params, $config['appsecret']);
			$url = 'http://dysmsapi.aliyuncs.com/?' . http_build_query ( $params );
			$ch = curl_init ();
		    curl_setopt ( $ch, CURLOPT_URL, $url );
		    curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
		    curl_setopt ( $ch, CURLOPT_SSL_VERIFYHOST, FALSE );
		    curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
		    curl_setopt ( $ch, CURLOPT_TIMEOUT, 10 );
		    $return = curl_exec ( $ch );
		    curl_close ( $ch );
		}else{
			$app_secret=$config['appsecret'];
			$params = array(
				'sms_type' => 'normal',
				'sms_free_sign_name' => $config['sms_free_sign_name'],
				'sms_param' => $sms_param,
				'rec_num' => $phone,
				'sms_template_code' => $setting['dx_smsid'],
				'app_key' => $config['appkey'],
			);
			$return  = lsendsms($params,$app_secret);
		}
		$returnarray = json_decode($return,true);
		$status = $returnarray['alibaba_aliqin_fc_sms_num_send_response']['result']['success'];
		if($status || $returnarray['Code'] == 'OK'){
			$status=1;
		}else{
			$status=0;
		}
		foreach($dx_setting as $k => $v){
			$serach[] = '${'.$k.'}';
            $replace[] = $v;
		}
		$dx_content = str_replace($serach, $replace, $setting['dx_content']);
		$insertid = DB::insert('aljdx_log',array(
			'dx_identifier' => addslashes($identifier),
			'dx_variable' => addslashes($variable),
			'dx_phone' => addslashes($phone),
			'dx_sendtime' => TIMESTAMP,
			'dx_ip' => $_G['clientip'],
			'dx_uid' => $_G['uid'],
			'dx_status' => intval($status),
			'dx_result' => addslashes($return),
            'dx_content' => $dx_content
		),true);
	}
	return $status;

}
function percentEncode($string) {
    $string = urlencode ( $string );
    $string = preg_replace ( '/\+/', '%20', $string );
    $string = preg_replace ( '/\*/', '%2A', $string );
    $string = preg_replace ( '/%7E/', '~', $string );
    return $string;
}
function computeSignature($parameters, $accessKeySecret) {
	ksort ( $parameters );
	$canonicalizedQueryString = '';
	foreach ( $parameters as $key => $value ) {
	   $canonicalizedQueryString .= '&' . percentEncode ( $key ) . '=' . percentEncode ( $value );
	}
	$stringToSign = 'GET&%2F&' . percentencode ( substr ( $canonicalizedQueryString, 1 ) );
	$signature = base64_encode ( hash_hmac ( 'sha1', $stringToSign, $accessKeySecret . '&', true ) );
	return $signature;
}
//���ŷ���
function lsendsms($params,$app_secret){
	$url = 'http://gw.api.taobao.com/router/rest?';
	$sysparams = array(
		'partner_id' => 'top-apitools',
		'v' => '2.0',
		'sign_method' => 'md5',
		'timestamp' => dgmdate(TIMESTAMP,"Y-m-d H:i:s"),
		'method' => 'alibaba.aliqin.fc.sms.num.send',
		'format' => 'json',
	);
	$newparams = array_merge($params, $sysparams);

	//����ǩ��
	ksort($newparams);
	$stringToBeSigned = $app_secret;
	foreach ($newparams as $k => $v)
	{
		if(is_string($v) && "@" != substr($v, 0, 1))
		{
			$stringToBeSigned .= "$k$v";
		}
	}
	unset($k, $v);
	$stringToBeSigned .= $app_secret;
	//����ǩ��
	$newparams['sign'] = strtoupper(md5($stringToBeSigned));
	//debug($newparams);
	return dfsockopen($url,'',$newparams);
	//return '{"alibaba_aliqin_fc_sms_num_send_response":{"result":{"err_code":"0","model":"100943730624^1101398835889","success":true},"request_id":"iv0eh4eqg17c"}}';
}
//���⴦��
function encode_json($str) {
	return urldecode(json_encode(url_encode($str)));
}
function url_encode($str) {
	if(is_array($str)) {
		foreach($str as $key=>$value) {
			$str[urlencode($key)] = url_encode($value);
		}
	} else {
		$str = urlencode($str);
	}

	return $str;
}
//From: DisM. taobao. Com
?>
