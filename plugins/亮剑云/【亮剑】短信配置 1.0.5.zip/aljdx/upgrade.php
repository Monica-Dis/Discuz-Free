<?php
/*
	Copyright (c) 2021 by dism.taobao.com
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
//start to put your own code
$sql ="ALTER TABLE ".DB::table('aljdx_log')." ADD `dx_content` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljdx` (
  `dx_id` int(10) NOT NULL AUTO_INCREMENT,
  `dx_identifier` varchar(255) NOT NULL,
  `dx_variable` varchar(255) NOT NULL,
  `dx_title` varchar(255) NOT NULL,
  `dx_content` varchar(255) NOT NULL,
  `dx_setting` varchar(255) NOT NULL,
  `dx_smsid` varchar(255) NOT NULL,
  `dx_switch` tinyint(3) NOT NULL,
  PRIMARY KEY (`dx_id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljdx_log` (
  `dxlog_id` int(10) NOT NULL AUTO_INCREMENT,
  `dx_identifier` varchar(255) NOT NULL,
  `dx_variable` varchar(255) NOT NULL,
  `dx_phone` bigint(11) NOT NULL,
  `dx_sendtime` int(10) NOT NULL,
  `dx_ip` varchar(255) NOT NULL,
  `dx_uid` int(10) NOT NULL,
  `dx_status` int(10) NOT NULL,
  `dx_result` varchar(255) NOT NULL,
  `dx_content` varchar(255) NOT NULL,
  PRIMARY KEY (`dxlog_id`)
);
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>