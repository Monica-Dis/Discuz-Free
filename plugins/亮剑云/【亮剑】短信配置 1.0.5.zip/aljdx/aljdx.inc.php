<?php
/*
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}	
loadcache('plugin');
$id=intval($_GET['id']);
$act=$_GET['act'];
$pluginid=addslashes($_GET['pluginid']);
if($act == 'dxconfig'){//�༭���� 
	$settinglist=DB::fetch_first('select * from %t where dx_id=%d',array('aljdx',$id));
	if(submitcheck('formhash')){
		$setting=serialize($_GET['setting']);
		$content=addslashes($_GET['dx_content']);
		$smsid=addslashes($_GET['smsid']);
		$switch=intval($_GET['dx_switch']);
		if($_GET['setting']){
			DB::query('update %t set dx_content=%s,dx_setting=%s,dx_smsid=%s,dx_switch=%d where dx_id=%d',array('aljdx',$content,$setting,$smsid,$switch,$id));
		}else{
			DB::query('update %t set dx_content=%s,dx_smsid=%s,dx_switch=%d where dx_id=%d',array('aljdx',$content,$smsid,$switch,$id));
		}
		
		cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljdx&pmod=aljdx&act=configlist&pluginid='.$settinglist['dx_identifier'].'');
	}
	$setconfig=unserialize($settinglist['dx_setting']);
	include template('aljdx:dxconfig');
}else if($act == 'configlist'){//��ҳ�б�
    require_once 'source/plugin/aljdx/function_dx.php';
    if(!getsmstemplate('aljhtx', 'send')){
        setsmstemplate('aljhtx', 'send', '&#32676;&#21457;&#30701;&#20449;', array('username' => ''), '');
    }
    if(!getsmstemplate('aljqb', 'zhifu')){
        setsmstemplate('aljqb', 'zhifu','&#25903;&#20184;&#23494;&#30721;&#39564;&#35777;', array('code' => ''),'');
    }
    if(!getsmstemplate('aljbd','fahuo')){
        setsmstemplate('aljbd','fahuo','&#21830;&#21697;&#21457;&#36135;',array('usernameau' =>'' ,'orderidau' => ''),'');
    }
    if(!getsmstemplate('aljbd','tips_user')){
        setsmstemplate('aljbd','tips_user','&#21830;&#21697;&#36141;&#20080;&#25104;&#21151;&#36890;&#30693;&#29992;&#25143;',array('usernameau' =>'' ,'orderidau' => ''),'');
    }
    if(!getsmstemplate('aljbd','tips_business')){
        setsmstemplate('aljbd','tips_business','&#21830;&#21697;&#20986;&#21806;&#36890;&#30693;&#21830;&#23478;',array('orderidau' => ''),'');
    }
    if(!getsmstemplate('aljbd','tips_tgcode')){
        setsmstemplate('aljbd','tips_tgcode','&#21457;&#36865;&#22242;&#36141;&#21048;',array('goodsname'=>'','code' => '','tel' => ''),'');
    }
    if(!getsmstemplate('aljbd','tips_ddcode')){
        setsmstemplate('aljbd','tips_ddcode','&#21457;&#36865;&#21462;&#36135;&#30721;',array('goodsname'=>'','code' => '','tel' => ''),'');
    }
    $perpage = 16;
    $currpage = $_GET['page'] ? intval($_GET['page']) : 1;
    $start = ($currpage - 1) * $perpage;
	$num=DB::result_first('select count(*) from %t',array('aljdx'));
	$configlist=DB::fetch_all('select * from %t where dx_identifier=%s order by dx_id desc limit %d,%d',array('aljdx',$pluginid,$start,$perpage));
	$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljdx&pmod=aljdx&pluginid='.$pluginid, 0, 11, false, false);
	include template('aljdx:configlist');
}else{
	$pluginlist=DB::fetch_all('select * from %t order by pluginid desc',array('common_plugin'));
	include template('aljdx:pluginlist');
}
//From: DisM. taobao. Com
?>