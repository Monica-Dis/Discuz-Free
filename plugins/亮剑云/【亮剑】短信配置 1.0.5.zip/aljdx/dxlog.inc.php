<?php
/*
 * DisM!应用中心：dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 应用更新支持：https://dism.taobao.com
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if($_GET['act'] == 'delete'){
	if(submitcheck('formhash')){
		if(is_array($_POST['delete'])) {
			foreach($_POST['delete'] as $id) {
				DB::query('delete from %t where dxlog_id=%d',array('aljdx_log',$id));
			}
		}
		cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljdx&pmod=dxlog');
	}	
}else{
	$currpage = $_GET['page'] ? intval($_GET['page']) : 1;
    $perpage = 16;
    $start = ($currpage - 1) * $perpage;
    $num = DB::result_first('select count(*) from %t',array('aljdx_log'));
	$loglist=DB::fetch_all('select * from %t order by dx_sendtime desc limit %d,%d',array('aljdx_log',$start,$perpage));
	$paging = helper_page :: multi($num, $perpage, $currpage, 'admin.php?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljdx&pmod=dxlog', 0, 11, false, false);
	include template('aljdx:log');
	
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>