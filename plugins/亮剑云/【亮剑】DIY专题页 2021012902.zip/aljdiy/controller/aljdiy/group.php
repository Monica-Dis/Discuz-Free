<?php

/**
 * Controller���˷�ģ��
 *
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * @version 1.0
 * @link http://docs.liangjianyun.com/
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class GroupAction extends Base{
    public $page;

    public function __construct() {
        global $requestPage;
        $this->page = $requestPage;
    }
    public function list_index(){
        global $_G;

        $admin_id = $_GET['admin_id'];
        $station_id = $_GET['station_id'];
        if($this->page->get->render == 'yes'){
            $per = 20;
            $page = $this->page->get->page>0 ? $this->page->get->page :1;
            $start = ($page - 1) * $per;
            
            $where = 'where 1 ';

            if($admin_id){
                $where .= ' and admin_id='.$admin_id;
            }

            if($station_id){
                $where .= ' and station_id='.$station_id;
            }
            
            $logList = DB::fetch_all('select * from %t '.$where.' order by id desc limit %d, %d', array('aljdiy_group', $start, $per));
            $count = DB::result_first('select count(*) from %t '.$where, array('aljdiy_group'));
            
            foreach($logList as $k => $v){
                $logList[$k]['dateline'] = dgmdate($v['dateline'], 'u');
            }
            T::responseJson(array(
                'code' => 0,
                'msg' => "",
                'count' => $count,
                'data' => $logList
            ));
        }

        $this->page->assign('admin_id', $admin_id);
        $this->page->assign('station_id', $station_id);
        $this->page->display();
    }

    public function list_delete(){
        DB::delete('aljdiy_group', array('id' => $_GET['mid']));
        T::responseJson();
    }


    public function list_submit(){
        global $_G;
        $admin_id = $_GET['admin_id'];
        $station_id = $_GET['station_id'];
        $mid = $_GET['mid'];
        $data = DB::fetch_first('select * from %t where id=%d', array('aljdiy_group', $_GET['mid']));
        if(submitcheck('formhash')){
            if($data){
                DB::update('aljdiy_group', array(
                    'title' => $_GET['title'],
                    'open' => $_GET['open'],
                ), array('id' => $mid));
            }else{
                $insertarray = array(
                    'title' => $_GET['title'],
                    'open' => $_GET['open'],
                    'dateline' => TIMESTAMP
                );
                if($_G['cache']['plugin']['aljam']){
                    $insertarray['admin_id'] = $admin_id;
                    $insertarray['station_id'] = $station_id;
                }
                $mid = DB::insert('aljdiy_group', $insertarray, true);
            }
            $this->page->tips();
        }else{
            $this->page->assign('admin_id', $admin_id);
            $this->page->assign('station_id', $station_id);
            $this->page->assign('data', $data);
            $this->page->display();
        }
    }
}

