<?php

/**
 * �������̳�
 *
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * @version 2019080501
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class PageAction extends Base{
    public $page;
    public $table;
    public function __construct() {
        global $requestPage, $_G;
        $this -> page = $requestPage;
        
        $this -> table = APP_ID . '_' . CONTROLLER;
        
        parent::__construct(); /*Dism_taobao-com*/
    }
    public function daoru() {
        global $_G;
        $data = dfsockopen('https://mall.liangjianyun.com/plugin.php?id=aljdiy:diy&type='.$_GET['type'], '');
        $data = dunserialize($data);
        if($_G['charset']=='gbk'){
            $data = T::ajaxGetCharSet($data);
        }
        
        if($data){
            $page_array = $data['page'];
            unset($page_array[id]);
            unset($page_array[admin_id]);
            unset($page_array[station_id]);
            $page_array['title'] = $page_array['title'];
            $page_array['displayorder'] = 0;
            $page_array['push_to_page'] = '';
            $page_array['createtime'] = TIMESTAMP;
            $page_array['updatetime'] = TIMESTAMP;
            $new_page_id = DB::insert($this -> table,$page_array,true);
            $mod_array = $data['diy'];;
            if($mod_array){
                foreach($mod_array as $m_v){
                    unset($m_v[id]);
                    $m_v[page_id] = $new_page_id;
                    $m_v[auto_module] = $m_v['auto_module'].'_copy_'.TIMESTAMP;
                    DB::insert('aljdiy_diy',$m_v,true); 
                }
            }
            echo 1;
            exit;
        }
        echo 0;
        exit;
    }
    public function list_index(){
        global $_G;
        
        $admin_id = $_GET['admin_id'];
        $station_id = $_GET['station_id'];
        $type = $_GET['type']>0 ? intval($_GET['type']) : 0;
        $this->page->assign('type', $type);
        $this->page->assign('com_url', '&type='.$type.'&brand_id='.$this->brand_id,true);
        if($this->page->get->render == 'yes'){
            $per = 20;
            $page = $this->page->get->page>0 ? $this->page->get->page :1;
            $start = ($page - 1) * $per;
            
            
            $where = 'where type='.$type;
            

            if($_GET['groupid']){
                $where .= ' and groupid='.intval($_GET['groupid']);
            }
            
            if($admin_id){
                $where .= ' and admin_id='.$admin_id;
            }

            if($station_id){
                $where .= ' and station_id='.$station_id;
            }

            if($this->brand_id){
                $where .= ' and bid='.$this->brand_id;
            }
            $conn[] = $this -> table;
            if($_GET['search']){
				$search='%' . addcslashes(T::ajaxGetCharSet($_GET['search']), '%_') . '%';
                $where.=" and (title like %s or intro like %s)";
                $conn[] = $search;
                $conn[] = $search;
            }
            $count = DB::result_first('select count(*) from %t '.$where, $conn);
            $where .= ' order by displayorder asc,id desc limit %d, %d';
            
            $conn[] = $start;
            $conn[] = $per;
            $logList = DB::fetch_all('select * from %t '.$where, $conn);
            
            $glist = DB::fetch_all('select * from %t', array('aljdiy_group'));
            foreach($glist as $group) {
                $group_list[$group['id']] = $group['title'];
            }
            $push_to_page_title = array('aljbd_index'=>lang("plugin/aljdiy","page_php_2"));
            if($_G['cache']['plugin']['aljtc']){
                $push_to_page_title['aljtc_index'] = lang("plugin/aljdiy","page_php_3");
            }
            if($_G['cache']['plugin']['aljtsc']['is_aljtsc']){
                $push_to_page_title['aljtsc_index'] = lang("plugin/aljdiy","page_php_4");
            }
            if($_G['cache']['plugin']['aljtsq']['is_aljtsq']){
                $push_to_page_title['aljtsq_index'] = lang("plugin/aljdiy","page_php_5");
            }
            if($_G['cache']['plugin']['aljzp']['is_aljzp']){
                $push_to_page_title['aljzp_index'] = lang("plugin/aljdiy","page_php_6");
            }
            if($_G['cache']['plugin']['aljsqtg']['is_aljsqtg']){
                $push_to_page_title['aljsqtg_index'] = lang("plugin/aljdiy","page_php_7");
            }
            foreach($logList as $k => $v){
                $logList[$k]['createtime'] = dgmdate($v['createtime'], 'u');
                $logList[$k]['updatetime'] = dgmdate($v['updatetime'], 'u');
                if($v['groupid'] == 0){
                    $logList[$k]['group_title'] = lang("plugin/aljdiy","page_php_8");
                }else{
                    $logList[$k]['group_title'] = $group_list[$v['groupid']];
                }
                if($v['push_to_page']){
                    $logList[$k]['push_to_page_title'] = $push_to_page_title[$v['push_to_page']];
                }else{
                    $logList[$k]['push_to_page_title'] = '--';
                }
            }
            T::responseJson(array(
                'code' => 0,
                'msg' => "",
                'count' => $count,
                'data' => $logList
            ));
        }
        
        $this->page->assign('admin_id', $admin_id);
        $this->page->assign('station_id', $station_id);
        $this->page->assign('url', $_G['siteurl']);
        $this->page->display();
    }

    public function list_delete(){
        DB::delete($this -> table, array('id' => $_GET['mid']));
        $mod_array = DB::fetch_all('select * from %t where page_id=%d', array('aljdiy_diy',$_GET['mid']));
        if($mod_array){
            foreach($mod_array as $m_v){
                DB::delete('aljdiy_diy', array('id' => $m_v[id]));
            }
        }
        T::responseJson();
    }

    public function list_copy(){
        $page_array = DB::fetch_first('select * from %t where id=%d', array($this -> table,$_GET['mid']));
        
        if($page_array){
            unset($page_array[id]);
            $page_array['title'] = $page_array['title'].'_copy';
            $page_array['createtime'] = TIMESTAMP;
            $page_array['updatetime'] = TIMESTAMP;
            $new_page_id = DB::insert($this -> table,$page_array,true);
            $mod_array = DB::fetch_all('select * from %t where page_id=%d', array('aljdiy_diy',$_GET['mid']));
            if($mod_array){
                foreach($mod_array as $m_v){
                    unset($m_v[id]);
                    $m_v[page_id] = $new_page_id;
                    $m_v[auto_module] = $m_v['auto_module'].'_copy_'.TIMESTAMP;
                    DB::insert('aljdiy_diy',$m_v,true);
                }
            }
        }
        
        T::responseJson();
    }

    public function list_submit(){
        global $_G;
        $admin_id = $_GET['admin_id'];
        $station_id = $_GET['station_id'];
        
        $mid = $_GET['mid'];
        $data = DB::fetch_first('select * from %t where id=%d', array($this -> table, $_GET['mid']));
        if($data){
            $type = $data['type']>0 ? intval($data['type']) : 0;
        }else{
            $type = $_GET['type']>0 ? intval($_GET['type']) : 0;
        }
        
        $this->page->assign('type', $type);
        $this->page->assign('com_url', '&type='.$type.'&brand_id='.$this->brand_id,true);
        $group_list = DB::fetch_all('select * from %t', array('aljdiy_group'));
        if($this->brand_id > 0){
            $bdlist=DB::fetch_all('select * from %t where id=%d',array('aljbd',$this->brand_id));
        }else{
            $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','','');//����Ա
        }
       
        $this->page->assign('bdlist', $bdlist);
        if(submitcheck('formhash')){
            if($type == 1 && !$_GET['bid']){
                $this->page->tips('".lang("plugin/aljdiy","page_php_1")."');
            }
            if ($this->page->get->uploadPhoto && $this->page->get->size == strlen($this->page->get->uploadPhoto)) {
                $pic = T::getPhotoFilePath();
                file_put_contents($pic, file_get_contents($this->page->get->uploadPhoto));
                if (file_exists($pic)) {
                    if($this->page->config->aljoss->Access_Key){
                        $pic = T::oss($pic, 'aljhtx/setting');
                    }
                }
            }
            
            if ($this->page->get->uploadPhoto_two && $this->page->get->size_two == strlen($this->page->get->uploadPhoto_two)) {
                $pic_two = T::getPhotoFilePath();
                file_put_contents($pic_two,file_get_contents($this->page->get->uploadPhoto_two));
                if (file_exists($pic_two)) {
                    if($this->page->config->aljoss->Access_Key){
                        $pic_two = T::oss($pic_two, 'aljhtx/setting');
                    } 
                }
            }
            $updatedata = array(
                'title' => $_GET['title'],
                'groupid' => $_GET['groupid'],
                'intro' => $_GET['intro'],
                'displayorder' => $_GET['displayorder'],
                'page_bg_color' => $_GET['page_bg_color'],
                'push_to_page' => $_GET['push_to_page'],
                'text_color' => $_GET['text_color'],
                'sel_text_color' => $_GET['sel_text_color'],
                'group_bg_color' => $_GET['group_bg_color'],
                'scroll_group_bg_color' => $_GET['scroll_group_bg_color'],
                'scroll_text_color' => $_GET['scroll_text_color'],
                'scroll_sel_text_color' => $_GET['scroll_sel_text_color'],
                'group_title' => $_GET['group_title'],
                'updatetime' => TIMESTAMP,
                'type'=>$type,
                'bid'=>$_GET['bid'],
            );
            $updatedata['page_url'] = $_GET['page_url'];
            if($pic){
                $updatedata['logo'] = $pic;
            }
            if($pic_two){
                $updatedata['page_bg_img'] = $pic_two;
            }else if($_GET['page_bg_img_delete']){
                $updatedata['page_bg_img'] = '';
                T::delete_oss($data['page_bg_img']);
            }
            if($data){
                DB::update($this -> table, $updatedata, array('id' => $mid));
            }else{
                $updatedata['createtime'] = TIMESTAMP;
                if($_G['cache']['plugin']['aljam']){
                    $updatedata['admin_id'] = $admin_id;
                    $updatedata['station_id'] = $station_id;
                }
                $mid = DB::insert($this -> table, $updatedata, true);
            }
            $this->page->tips();
        }else{
            $this->page->assign('admin_id', $admin_id);
            $this->page->assign('station_id', $station_id);
            $this->page->assign('data', $data);
            $this->page->assign('group_list', $group_list);
            $this->page->display();
        }
    }

}

