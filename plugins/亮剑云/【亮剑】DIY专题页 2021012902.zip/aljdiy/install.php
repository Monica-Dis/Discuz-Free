<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljdiy_diy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `module` varchar(255) NOT NULL,
  `auto_module` varchar(255) NOT NULL,
  `displayorder` bigint(20) NOT NULL,
  `template` varchar(255) NOT NULL,
  `data` text NOT NULL,
  `set_up` text NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljdiy_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `mod_num` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `station_id` int(11) NOT NULL,
  `groupid` int(11) NOT NULL,
  `intro` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `page_url` varchar(255) NOT NULL,
  `push_to_page` varchar(255) NOT NULL,
  `page_bg_img` varchar(255) NOT NULL,
  `page_bg_color` varchar(255) NOT NULL,
  `text_color` varchar(255) NOT NULL,
  `sel_text_color` varchar(255) NOT NULL,
  `displayorder` int(11) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `bid` int(11) NOT NULL,
  `group_bg_color` varchar(255) NOT NULL,
  `scroll_group_bg_color` varchar(255) NOT NULL,
  `scroll_text_color` varchar(255) NOT NULL,
  `scroll_sel_text_color` varchar(255) NOT NULL,
  `group_title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljdiy_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `page_num` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `station_id` int(11) NOT NULL,
  `open` char(50) NOT NULL,
  PRIMARY KEY (`id`)
);
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>
