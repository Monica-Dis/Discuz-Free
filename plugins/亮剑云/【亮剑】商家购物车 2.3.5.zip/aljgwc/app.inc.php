<?php

/*
 * User: DisM!Ӧ������
 * ���²����http://t.cn/Aiux1Jx1
 *
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

echo "<script language='javascript'>";
echo "window.location.href='http://dism.taobao.com/?@3932.developer'";
echo "</script>";
exit;
?>