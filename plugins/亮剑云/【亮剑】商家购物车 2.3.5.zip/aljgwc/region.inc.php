<?php
/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: region.inc.php liangjian $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$plugins='aljgwc';
if($_GET['act'] == 'empty'){
	$sql='TRUNCATE TABLE '.DB::table($plugins.'_region');
	DB::query($sql);
	cpmsg('&#26356;&#26032;&#25104;&#21151;','action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$plugins.'&pmod=region&upid='.$_GET['upid']);
}else if($_GET['act'] == 'importall'){
	if(C::t('#'.$plugins.'#'.$plugins.'_region')->count()){
		cpmsg('&#35831;&#20808;&#28165;&#31354;&#22320;&#21306;&#34920;&#65281;');
	}
	$level_3=DB::fetch_all('select * from %t where level<=3',array('common_district'));
	foreach($level_3 as $rid => $r){
		if($r['level']>3){
			break;
		}
		C::t('#'.$plugins.'#'.$plugins.'_region')->insert(array(
			'id'=>$r['id'],
			'name'=>$r['name'],
			'upid'=>$r['upid'],
			'subid'=>$r['id'],
			'level'=>$r['level']-1,
		));
	}
	cpmsg('&#26356;&#26032;&#25104;&#21151;','action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$plugins.'&pmod=region&upid='.$_GET['upid']);
}else if($_GET['act']=='admingetregion'){
	if($_GET['upid']){
		$rlist=C::t('#aljbd#aljbd_region')->fetch_all_by_upid_sys($_GET['upid']);
	}
	include template('common/header');
	include_once libfile('function/profile');
	if($rlist){
		$str.= '<select name="subregion" style="width:120px;" id="subregion1" onchange="ajaxget(\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$plugins.'&pmod=region&act=admingetregion1&upid=\'+$(\'subregion1\').value,\'region1\')">
		<option value="">&#45;&#22478;&#24066;&#45;</option>';
		foreach($rlist as $rid => $r){
			$str.='<option value="'.$r['id'].'">'.$r['name'].'</option>';
		}
		$str .= '</select>';
		echo $str;
	}
	include template('common/footer');
}else if($_GET['act']=='admingetregion1'){
	if($_GET['upid']){
		$rlist=C::t('#aljbd#aljbd_region')->fetch_all_by_upid_sys($_GET['upid']);
	}
	include template('common/header');
	include_once libfile('function/profile');
	if($rlist){
		$str.= '<select name="region1" style="width:120px;" >
		<option value="">&#45;&#24030;&#21439;&#45;</option>';
		foreach($rlist as $rid => $r){
			$str.='<option value="'.$r['id'].'">'.$r['name'].'</option>';
		}
		$str .= '</select>';
		echo $str;
	}
	include template('common/footer');
}else if($_GET['act'] == 'import'){
	if(!submitcheck('submit')){
		include template('common/header');
		include_once libfile('function/profile');
		$rlist=C::t('#'.$plugins.'#'.$plugins.'_region')->fetch_all_by_upid_sys();
		foreach($rlist as $rid => $r){
			$str.='<option value="'.$r['id'].'" >'.$r['name'].'</option>';
		}
		$districthtml = '<select name="birthprovince" id="region" style="width:120px;" onchange="ajaxget(\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$plugins.'&pmod=region&act=admingetregion&upid=\'+$(\'region\').value,\'subregion\')">
							<option value="">&#45;&#30465;&#20221;&#45;</option>
							'.$str.'
						</select>';	
		$districthtml.='<span name="subregion" id="subregion"></span><span name="region1" id="region1"></span>';
		showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier='.$plugins.'&pmod=region&act=import');	
		showtableheader('', 'nobottom');
		echo '<div style="height:170px;width:530px;"><h3 class="flb mn"><span><a href="javascript:;" class="flbc" onclick="hideWindow(\'edit\',1,0);" title="Close">Close</a></span>&#23548;&#20837;&#31995;&#32479;&#22320;&#21306;&#34920;&#21040;&#25554;&#20214;&#34920;</h3><div style="margin-left:10px;">'.$districthtml.'<p style="padding:10px; color:#3333CC; line-height:20px;"><ul id="tipslis"><li>&#20351;&#29992;&#23548;&#20837;&#31995;&#32479;&#22320;&#21306;&#34920;&#30340;&#21151;&#33021;&#26102;&#65292;&#35831;&#20808;<a href="admin.php?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$plugins.'&pmod=region&act=empty">&#28165;&#31354;&#25554;&#20214;&#22320;&#21306;&#34920;</a>&#20877;&#23548;&#20837;&#65292;&#36991;&#20813;&#23548;&#20837;&#37325;&#22797;&#22320;&#21306;</li>
<li>&#23548;&#20837;&#31995;&#32479;&#22320;&#21306;&#34920;&#21040;&#25554;&#20214;&#34920;&#26102;&#35831;&#36873;&#25321;&#19968;&#20010;&#30465;&#20221;&#23548;&#20837;&#65292;&#25554;&#20214;&#20250;&#25226;&#31995;&#32479;&#22320;&#21306;&#34920;&#20013;&#35813;&#30465;&#20221;&#23545;&#24212;&#30340;&#22478;&#12289;&#38215;&#12289;&#20065;&#23548;&#20837;&#21040;&#25554;&#20214;&#34920;&#65288;&#20197;&#27492;&#31867;&#25512;&#65289;</li>
</ul></p></div></div>';
		showsubmit('submit', 'import');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*dis'.'m.tao'.'bao.com*/	
		include template('common/footer');
	}else{
		$regionarr = array();
		$regionarr['birthprovince'] = dhtmlspecialchars(trim($_GET['birthprovince']));
		if(!$regionarr['birthprovince']){
			cpmsg('&#35831;&#36873;&#25321;&#19968;&#20010;&#30465;&#20221;&#65281;');
		}
		$regionarr['subregion'] = dhtmlspecialchars(trim($_GET['subregion']));
		$regionarr['region1'] = dhtmlspecialchars(trim($_GET['region1']));
		$regionarr['birthcommunity'] = dhtmlspecialchars(trim($_GET['birthcommunity']));
		$upid = 0;
		if ($regionarr['birthprovince']) {
		   $upid = $regionarr['birthprovince'];
		   if ($regionarr['subregion']) {
				$upid = $regionarr['subregion'];	
				if($regionarr['region1']){
					$upid = $regionarr['region1'];		
				}
		   }
		}
		if(!$upid){
			cpmsg('&#35831;&#36873;&#25321;&#19968;&#20010;&#30465;&#20221;&#65281;');
		}
		foreach(C::t('#'.$plugins.'#'.$plugins.'_region')->fetch_all_by_upid_sys($upid) as $data) {
		    $insertarray=array('name'=>$data['name'],'upid'=>'');
			$insertid=C::t('#'.$plugins.'#'.$plugins.'_region')->insert($insertarray,true);
			DB::update($plugins.'_region', array('subid'=>$insertid), "id='$insertid'");
			if(C::t('#'.$plugins.'#'.$plugins.'_region')->fetch_all_by_upid_sys($data['id'])){
				foreach(C::t('#'.$plugins.'#'.$plugins.'_region')->fetch_all_by_upid_sys($data['id']) as $data_1) {
					
					$insertarray=array('name'=>$data_1['name'],'upid'=>$insertid);
					$insertid_1=C::t('#'.$plugins.'#'.$plugins.'_region')->insert($insertarray,true);
					DB::update($plugins.'_region', array('subid'=>$insertid_1), "id='$insertid_1'");
					$region=C::t('#'.$plugins.'#'.$plugins.'_region')->fetch($insertid);
					$region['subid']=trim(($region['subid'].','.$insertid_1),',');
					$level=$region['level']+1;
					$region['havechild']=1;
					C::t('#'.$plugins.'#'.$plugins.'_region')->update($region['id'],$region);
					DB::update($plugins.'_region', array('level'=>$level), "id='$insertid_1'");
					if(C::t('#'.$plugins.'#'.$plugins.'_region')->fetch_all_by_upid_sys($data_1['id'])){
						foreach(C::t('#'.$plugins.'#'.$plugins.'_region')->fetch_all_by_upid_sys($data_1['id']) as $data_2) {
							$insertarray=array('name'=>$data_2['name'],'upid'=>$insertid_1);
							$insertid_2=C::t('#'.$plugins.'#'.$plugins.'_region')->insert($insertarray,true);
							DB::update($plugins.'_region', array('subid'=>$insertid_2), "id='$insertid_2'");
							$region_1=C::t('#'.$plugins.'#'.$plugins.'_region')->fetch($insertid_1);
							$region_1['subid']=trim(($region_1['subid'].','.$insertid_2),',');
							
							$level_1=$region_1['level']+1;
							$region_1['havechild']=1;
							C::t('#'.$plugins.'#'.$plugins.'_region')->update($region_1['id'],$region_1);
							DB::update($plugins.'_region', array('level'=>$level_1), "id='$insertid_2'");
						}
					}
				}
			}
		}
		
		cpmsg('&#26356;&#26032;&#25104;&#21151;','action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$plugins.'&pmod=region&upid='.$_GET['upid']);
	}
}else{
	if(!submitcheck('submit')){
		if($_GET['upid']){
			$upid_data=C::t('#'.$plugins.'#'.$plugins.'_region')->fetch($_GET['upid']);
			
		}
		$currpage=$_GET['page']?$_GET['page']:1;
		$perpage=20;
		$num=C::t('#'.$plugins.'#'.$plugins.'_region')->count_by_upid($_GET['upid']);
		$start=($currpage-1)*$perpage;
		$region=C::t('#'.$plugins.'#'.$plugins.'_region')->fetch_all_by_upid_admin($start,$perpage,$_GET['upid']);
		
		$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$plugins.'&pmod=region&upid='.$_GET['upid'], 0, 11, false, false);	
		include template($plugins.':region');
	}else{
		
		if($_GET['delete']){
			foreach($_GET['delete'] as $key=>$value){
				C::t('#'.$plugins.'#'.$plugins.'_region')->delete($value);
			}
		}else if($_GET['name']){
			foreach($_GET['name'] as $key=>$value){
				C::t('#'.$plugins.'#'.$plugins.'_region')->update($key,array('name'=>$value));
			}
			if($_GET['displayorder']){
				foreach($_GET['displayorder'] as $key=>$value){
					C::t('#'.$plugins.'#'.$plugins.'_region')->update($key,array('displayorder'=>$value));
				}
			}
		} 
		foreach($_GET['newregion'] as $key=>$value){
			if($value){
				$insertarray=array('name'=>$value,'upid'=>$_GET['upid'],'displayorder'=>$_GET['newdisplayorder'][$key]);
				$insertid=C::t('#'.$plugins.'#'.$plugins.'_region')->insert($insertarray,true);
				DB::update($plugins.'_region', array('subid'=>$insertid), "id='$insertid'");
				if($_GET['upid']){
					$region=C::t('#'.$plugins.'#'.$plugins.'_region')->fetch($_GET['upid']);
					$region['subid']=trim(($region['subid'].','.$insertid),',');
					$level=$region['level']+1;
					$region['havechild']=1;
					C::t('#'.$plugins.'#'.$plugins.'_region')->update($region['id'],$region);
					DB::update($plugins.'_region', array('level'=>$level), "id='$insertid'");
				}
			}
		}
		
		cpmsg('&#26356;&#26032;&#25104;&#21151;','action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$plugins.'&pmod=region&upid='.$_GET['upid']);
	}
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>