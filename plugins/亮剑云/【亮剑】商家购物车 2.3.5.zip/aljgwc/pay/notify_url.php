<?php
/**
 * ͨ��֪ͨ�ӿ�
 * ====================================================
 * ֧����ɺ�΢�Ż�����֧�����û���Ϣ���͵��̻��趨��֪ͨURL��
 * �̻����ջص���Ϣ�󣬸�����Ҫ�趨��Ӧ�Ĵ������̡�
 *
*/
define('DISABLEXSSCHECK',true);
require '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
loadcache('plugin');
require '../../../../source/plugin/aljgwc/function/function_core.php';
//�洢΢�ŵĻص�
$xml = file_get_contents("php://input");
$data = xmlToArray($xml);
$data['out_trade_no'] = $data['out_trade_no']?$data['out_trade_no']:$_GET['out_trade_no'];
$data['transaction_id'] = $data['transaction_id']?$data['transaction_id']:$_GET['trade_no'];
$order = C::t('#aljgwc#aljbd_goods_order') -> fetch($data['out_trade_no']);
$returnsign = $data['sign'];
$tmpdata = $data;
unset($tmpdata['sign']);
if($order['payment'] == '1'){
	$checkSign = getSign($tmpdata,$config['key']);
	$check = $checkSign == $returnsign?true:false;
	$wechat = 1;
	$pay = 1;
}else if($order['payment'] == '3'){
	$checkSign = getSign($tmpdata,$config['key2']);
	$check = $checkSign == $returnsign?true:false;
	$wechat = 1;//΢��
	$pay = 1;
}else{
	$check = getSignVeryfy($_GET,$_GET['sign'],$order['mobile']);
	//file_put_contents('test.txt',$check.'=>'.$_GET['sign'].',',FILE_APPEND);
	if($_GET['trade_status'] == 'TRADE_SUCCESS' || $_GET['trade_status'] == 'WAIT_SELLER_SEND_GOODS'){
		$pay = 1;//֧����
	}else if($_GET['trade_status'] == 'WAIT_BUYER_CONFIRM_GOODS'){
		$pay = 2;//֧����
	}else if($_GET['trade_status'] == 'TRADE_FINISHED'){
		$pay = 3;//֧����
	}
}
$_G['siteurl'] = 'http%3a//'.$_SERVER['HTTP_HOST'];
if($order['pid'] == '1'){
	$pluginid = 'aljtg';
	$orderlurl = $_G['siteurl'].'/plugin.php?id='.$pluginid.'%3amember&act=orderlist';
	$orderlurln = '/plugin.php?id='.$pluginid.'%3amember&act=orderlist';
}else if($order['pid'] == '2'){
	$pluginid = 'aljsc';
	$orderlurl = $_G['siteurl'].'/plugin.php?id=aljgwc&act=orderlist&pluginid='.$pluginid;
	$orderlurln = '/plugin.php?id=aljgwc&act=orderlist&pluginid='.$pluginid;
}else{
	$pluginid = 'aljbd';
	$orderlurl = $_G['siteurl'].'/plugin.php?id='.$pluginid.'&act=orderlist';
	$orderlurln = '/plugin.php?id='.$pluginid.'&act=orderlist';
}
if($check){
	if($wechat){
		$returnParameters["return_code"]="SUCCESS";
	}else{
		$return = 'success';//֧����
	}
	if ($order['status'] == 1 && $pay == 1){
		if($order['category'] == 1 && $order['pid'] == '1'){
			$check = DB::result_first('select count(*) from %t where orderid = %s',array('aljtg_groupon',$data['out_trade_no']));
			if(empty($check)){
				$grouponpw = mt_rand(1000,9999);
				$grouponid = C::t('#aljtg#aljtg_groupon')->insert(array(
					'password' => $grouponpw,
					'orderid' => $data['out_trade_no'],
					'gid' => $order['goods_id'],
					'name' => $order['name'],
					'dateline' => TIMESTAMP
				),true);
				if(file_exists("../../../../source/plugin/aljtg/include/n_mes.php")){
					require_once '../../../../source/plugin/aljtg/include/n_mes.php';
				}
			}
			if($order['payment'] == 2){
				$order['transaction_id'] = $data['transaction_id'];
				alipaysend($order);
				//file_put_contents('../../../../source/plugin/aljgwc/pay/text.txt',$order,FILE_APPEND);
			}
			$status = 3;
		}else{
			$status = 2;
		}
		C::t('#aljgwc#aljbd_goods_order')->update($data['out_trade_no'], array('status' => $status, 'buyer' => $data['transaction_id'], 'confirmdate' => $_G['timestamp']));
		$shop_order=C::t('#aljgwc#aljbd_goods_order_list')->fetch_all_by_orderid($data['out_trade_no']);
		if($order['pid'] == '2'){
			foreach($shop_order as $key => $val){
				C::t('#'.$pluginid.'#'.$pluginid)->update_num2_by_id($val['goods_id'],$val['num']);
			}
			if($order['pay_ext']){
                updatemembercount($order['uid'],array($_G['cache']['plugin']['aljsc']['extcredit'] => -intval($order['pay_ext'])),'','','','','&#29616;&#37329;&#43;&#31215;&#20998;&#36141;&#20080;&#25187;&#38500;&#31215;&#20998;','&#36141;&#20080;&#25104;&#21151;&#65292;&#27492;&#27425;&#36141;&#20080;&#21830;&#21697;&#25187;&#38500;'.intval($order['pay_ext']).$_G['setting']['extcredits'][$_G['cache']['plugin']['aljsc']['extcredit']]['title'].',&#35746;&#21333;&#21495;&#65306;'.$order['orderid']);
			}
            //file_put_contents('../../../../source/plugin/aljgwc/pay/text1.txt',json_encode($_G).'+++'.$order['pay_ext'].'++++'.$pluginid.'++++'.$_G['cache']['plugin']['aljsc']['extcredit'],FILE_APPEND);
			notification_add($order['uid'],'system',str_replace('{username}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['suctips'])).'<a href="'.$orderlurln.'">&nbsp;'.lang('plugin/aljgwc','View_orders').'</a>');
			if($_G['cache']['plugin'][$pluginid]['ismail']){
				$email_first = C::t("common_member")->fetch($_G['uid']);
				$email = $email_first['email'];
                require_once libfile('function/mail');
				sendmail_cron($email,$_G['cache']['plugin'][$pluginid]['mailtitle'],str_replace('{username}',$_G['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['suctips'])).'<a href="'.$orderlurl.'">&nbsp;'.lang('plugin/aljgwc','View_orders').'</a>');
			}
			$groups = unserialize($_G['cache']['plugin'][$pluginid]['groups']);
			foreach(DB::fetch_all('select uid from '.DB::table('common_member').' where groupid in ('.dimplode($groups).')') as $u){
				notification_add($u['uid'],'system',str_replace('{username}',$_G['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['tsy'])).'<a href="'.$orderlurln.'">&nbsp;'.lang('plugin/aljgwc','View_orders').'</a>');
				if($_G['cache']['plugin'][$pluginid]['ismail']){
					$email_first=C::t("common_member")->fetch($u['uid']);
					$email=$email_first['email'];
                    require_once libfile('function/mail');
					sendmail_cron($email,$_G['cache']['plugin'][$pluginid]['mailtitle'].'@'.gmdate('Y-m-d H:i:s',$_G['timestamp']+8*3600),str_replace('{username}',$_G['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['tsy'])).'&nbsp;<a href="'.$orderlurl.'">'.lang('plugin/aljgwc','View_orders').'</a>');
				}
			}
		}else{
			foreach($shop_order as $key => $val){
				C::t('#'.$pluginid.'#'.$pluginid.'_goods')->update_num2_by_id($val['goods_id'],$val['num']);
			}
			$brand = C::t('#'.$pluginid.'#'.$pluginid) -> fetch($order['shop_id']);
			notification_add($order['uid'],'system',str_replace('{username}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['suctips'])).'&nbsp;<a href="'.$orderlurln.'">'.lang('plugin/aljgwc','View_orders').'</a>',array('from_idtype'  => $pluginid,'from_id' => $order['shop_id']));

			if(!$order['pid'] && DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljjs'))){//aljbd����
				$isuerexists = DB::result_first('select uid from %t where uid=%d and bid=%d',array('aljjs_brandsettle',$brand['uid'],$brand['id']));
				if(!$isuerexists){
					DB::insert('aljjs_brandsettle',array('uid' =>$brand['uid'],'bid' => $brand['id'],'income'=>0,'times'=>0,'cash'=>0,'balance'=>0,'dateline'=>TIMESTAMP));
				}

				DB::query('update %t set income=income+%i,b_times=b_times+1,balance=balance+%i,dateline=%d where uid=%d and bid=%d',array('aljjs_brandsettle',$order['price'],$order['price'],TIMESTAMP,$brand['uid'],$brand['id']));
			}
			if(!$order['pid']){//Ʒ���̼�
				//ת��
				if($config['is_trans']){
					//������ $order['orderid']
					//��� $order['price']
					//���ּ�¼
					$account = DB::fetch_first('select * from %t where cashmoney_type=1 and uid=%d', array('aljjs_accountsettle', $brand['uid']));
					$fee = sprintf("%1.2f",$order['price']*$_G['cache']['plugin']['aljjs']['per']);//���ֽ��
					$new_price = $order['price'] - $fee;
					if($account['cashmoney_account'] && $new_price>=0.1){
						$insertarray = array(
							'amount' => $order['price'],
							'toaccountmoney' => $order['price']-$fee,
							'fee' => $fee,
							'cashmoney_type' => 1,//�����ʻ����� 1��֧����
							'cashmoney_account' => $account['cashmoney_account'],//֧�����ʺ�
							'cashmoney_name' => $account['cashmoney_name'],//�տ�������
						);
						$orderid = $config['mchid'].dgmdate(TIMESTAMP,'Ymd').TIMESTAMP;//���ֵ���
						$insertarray['uid'] = $brand['uid'];
						$insertarray['username'] = $brand['username'];
						$insertarray['orderid'] = $orderid;
						$insertarray['bid'] = $brand['id'];
						$insertarray['spbill_create_ip'] = $_G['clientip'];
						$insertarray['desc'] = $_G['cache']['plugin']['aljjs']['mycashtips'];
						$insertarray['dateline'] = TIMESTAMP;
						DB::query('update %t set balance=balance-%i,times=times+1,cash=cash+%i,dateline=%d where bid=%d',array('aljjs_brandsettle',$order['price'],$order['price'],TIMESTAMP,$brand['id']));
						C::t('#aljjs#aljjs_transfer')->insert($insertarray);
						$result = alipaytrans($orderid, $account['cashmoney_account'], $new_price, $order['orderid'], diconv($insertarray['desc'], CHARSET, 'utf-8'));
						$result = json_decode($result, true);
						if($result['alipay_fund_trans_toaccount_transfer_response']['code'] == "10000"){
							DB::query('update %t set status = 1, remarks=%s where orderid=%s', array('aljjs_transfer', $insertarray['desc'].$result['alipay_fund_trans_toaccount_transfer_response']['order_id'], $orderid));
						}
					}

				}
				//ת��
				$is_aljdx = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljdx'));
				if($is_aljdx){
					require_once '../../../../source/plugin/aljdx/function_dx.php';
					$oaddress = unserialize($order['address']);
                    $orderidau = $_G['cache']['plugin']['aljbd']['is_dx_var'] ? 'orderidau' : 'orderid_au';
                    $username_au = $_G['cache']['plugin']['aljbd']['is_dx_var'] ? 'usernameau' : 'username_au';
					if(preg_match('#^\d[\d-]{3,20}\d$#', $oaddress['mobile'])){
						sendsmsbyvar($oaddress['mobile'],'aljbd','tips_user',array($username_au =>$order['username'] ,$orderidau => $_G['cache']['plugin']['aljbd']['is_dx_order']?'**'.substr($order['orderid'],-4):$order['orderid']));
					}
					if(preg_match('#^\d[\d-]{3,20}\d$#', $brand['tel'])){
						sendsmsbyvar($brand['tel'],'aljbd','tips_business',array($orderidau => $_G['cache']['plugin']['aljbd']['is_dx_order']?'**'.substr($order['orderid'],-4):$order['orderid']));
					}
				}
                if(file_exists("../../../../source/plugin/dz_3/dz_3.inc.php")){
                    require_once '../../../../source/plugin/dz_3/include/receipt.php';
                }
			}
			if($_G['cache']['plugin'][$pluginid]['time'] && $_G['cache']['plugin'][$pluginid]['notify_merchant']){
				notification_add($brand['uid'],'system',str_replace('{orderid}','<a href="'.$orderlurln.'">'.$data['out_trade_no'].'</a>',str_replace('{username}',$brand['username'],str_replace('{name}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['notify_merchant'])))),array('from_idtype'  => $pluginid,'from_id' => $order['shop_id']));
				$email_first = C::t("common_member")->fetch($order['uid']);
				$email = $email_first['email'];
                require_once libfile('function/mail');
				if($email_first['email']){
					$m=str_replace('{username}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['suctips'])).'&nbsp;<a href="'.$orderlurl.'">'.lang('plugin/aljgwc','View_orders').'</a>';
					sendmail_cron($email,$_G['cache']['plugin'][$pluginid]['mailtitle'].'@'.gmdate('Y-m-d H:i:s',$_G['timestamp']+8*3600),$m);
				}
				$email_f = C::t("common_member")->fetch($brand['uid']);
				$e = $email_f['email'];
				if($email_f['email']){
					$me=str_replace('{orderid}','<a href="'.$orderlurl.'">'.$data['out_trade_no'].'</a>',str_replace('{username}',$brand['username'],str_replace('{name}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['notify_merchant']))));
					$t=str_replace('{orderid}',$data['out_trade_no'],$_G['cache']['plugin'][$pluginid]['notify_merchant_title']);
					sendmail_cron($e,$t.'@'.gmdate('Y-m-d H:i:s',$_G['timestamp']+8*3600),$me);
				}
			}
		}
	}else if($order['status'] == 2 && $pay == 2){
		C::t('#aljgwc#aljbd_goods_order')->update_status_by_orderid($data['out_trade_no']);
		//$order = C::t('#aljbd#aljbd_order')->fetch($data['out_trade_no']);
		//$shop_order=C::t('#aljgwc#aljbd_goods_order_list')->fetch_all_by_orderid($data['out_trade_no']);
		//foreach($shop_order as $key => $val){
			//C::t('#'.$pluginid.'#'.$pluginid.'_goods')->update_num2_by_id($val['goods_id'],$val['num']);
		//}
		if($order['pid'] == '2'){
			notification_add($order['uid'],'system',str_replace('{username}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['fahuotips'])).'&nbsp;<a href="'.$orderlurln.'">'.lang('plugin/aljgwc','View_orders').'</a>');
			if($config['ismail']){
				$email_first=C::t("common_member")->fetch($order['uid']);
				$email=$email_first['email'];
				sendmail_cron($email,$config['mailtitle'],str_replace('{username}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['fahuotips'])).'&nbsp;<a href="'.$orderlurl.'">'.lang('plugin/aljgwc','View_orders').'</a>');
			}
		}else{
			$brand = C::t('#'.$pluginid.'#'.$pluginid) -> fetch($order['shop_id']);
			notification_add($order['uid'],'system',str_replace('{username}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['suctips'])).'&nbsp;<a href="'.$orderlurln.'">'.lang('plugin/aljgwc','View_orders').'</a>',array('from_idtype'  => $pluginid,'from_id' => $order['shop_id']));
			notification_add($brand['uid'], 'system',str_replace('{orderid}','<a href="'.$orderlurln.'">'.$data['out_trade_no'].'</a>',str_replace('{username}',$brand['username'],str_replace('{name}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['notify_merchant'])))),array('from_idtype'  => $pluginid,'from_id' => $order['shop_id']));
			if($_G['cache']['plugin'][$pluginid]['time']){
				$_G['siteurl'] = 'http://'.$_SERVER['HTTP_HOST'];
				$email_first = C::t("common_member")->fetch($order['uid']);
				$email = $email_first['email'];
				if($email_first['email']){
					$m=str_replace('{username}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['suctips'])).'&nbsp;<a href="'.$orderlurl.'">'.lang('plugin/aljgwc','View_orders').'</a>';
					require_once libfile('function/mail');
					sendmail_cron($email,$_G['cache']['plugin'][$pluginid]['mailtitle'].'@'.gmdate('Y-m-d H:i:s',$_G['timestamp']+8*3600),$m);
				}
				$email_f = C::t("common_member")->fetch($brand['uid']);
				$e = $email_f['email'];
				if($email_f['email']){
					$me=str_replace('{orderid}','<a href="'.$orderlurl.'">'.$data['out_trade_no'].'</a>',str_replace('{username}',$brand['username'],str_replace('{name}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['notify_merchant']))));
					$t=str_replace('{orderid}',$data['out_trade_no'],$_G['cache']['plugin'][$pluginid]['notify_merchant_title']);
					require_once libfile('function/mail');
					sendmail_cron($e,$t,$me);
				}
			}
		}
	}else if($order['status'] == 3 && $pay == 3){
		C::t('#aljgwc#aljbd_goods_order')->update($data['out_trade_no'], array('status' => 4));
	}
}else{
	if($wechat){
		$returnParameters["return_code"]="FAIL";
		$returnParameters["return_msg"]="sign faild";
	}else{
		$return = 'fail';//֧����
	}
}
if($wechat){
	$returnXml = arrayToXml($returnParameters);
	echo $returnXml;
}else{//֧����
	echo $return;
	exit;
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>
