<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'source/plugin/aljgwc/function/function_core.php';
require_once 'source/plugin/aljgwc/lang/lang.php';
foreach(DB::fetch_all('select * from %t',array('common_plugin')) as $cpv){
    $cparray[$cpv['identifier']] = $cpv;
}
$is_aljdx = $cparray['aljdx'];
if($is_aljdx){
	require_once 'source/plugin/aljdx/function_dx.php';
}
$_GET=dhtmlspecialchars($_GET);
$arrayplugin = array('aljbd','aljtg','aljsc');
$alj_lang=lang('plugin/aljgwc');
if($_GET['pluginid']){
	$pluginid = $_GET['pluginid'];
}else{
	if($cparray['aljbd']){
		$pluginid='aljbd';
	}else{
		$pluginid='aljtg';
	}
}
$is_plugin = $cparray[$pluginid];
if(!$is_plugin || !in_array($pluginid,$arrayplugin)){
	showmessage($alj_lang['Not_install_this_plugin']);
}
if(file_exists("source/plugin/aljbdx/include/act_header.php") && $pluginid == 'aljbd' && $_G['cache']['plugin']['aljbdx']['is_aljqb']){
    require_once 'source/plugin/aljbdx/include/act_header.php';
}
$admingroups = unserialize($_G['cache']['plugin'][$pluginid]['groups']);
if($pluginid == 'aljtg'){
	$pid = 1;
	$ggurl = 'plugin.php?id=aljtg&act=view&gid={goods_id}';
	$orderlisturl = 'plugin.php?id=aljtg:member&act=orderlist';
	$alltype = DB::fetch_all('select * from %t where upid=0 order by displayorder asc limit 0,13',array('aljtg_type_goods'));
	//�Զ��嵼��
	foreach (explode("\n", $_G['cache']['plugin'][$pluginid]['nav']) as $k => $nav) {
		$arr = explode('|', $nav);
		$navs[$k]['name'] = $arr[0];
		$navs[$k]['url'] = $arr[1];
		$navs[$k]['blank'] = $arr[2];
	}

	//�Զ��嶥������
	foreach (explode("\n", $_G['cache']['plugin'][$pluginid]['topmenu']) as $k => $nav) {
		$arr = explode('|', $nav);
		$topmenus[$k]['name'] = $arr[0];
		$topmenus[$k]['url'] = $arr[1];
		$topmenus[$k]['blank'] = $arr[2];
	}
	$settings=C::t('#aljtg#aljtg_setting')->range();
	if($settings['templatepx']['value']){
		$templatepx = '1200';
	}else{
		$templatepx = '1000';
	}
	$aljtglang['template']  = array(
		'home_page' => '&#39318;&#39029;',//��ҳ
		'Shopping_Cart' => '&#36141;&#29289;&#36710;',//���ﳵ
		'my' => '&#25105;&#30340;',//�ҵ�
		'list' => '&#21015;&#34920;',//�б�
	);
}elseif($pluginid == 'aljsc'){
	$settings = C::t('#aljsc#aljsc_setting')->range();
	$typelist = explode("\n", str_replace('\r', '\n', $_G['cache']['plugin'][$pluginid]['type']));
	foreach ($typelist as $status) {
		$arr = explode('|', $status);
		$typearr[$arr[0]] = $arr[1];
	}
	$new_index_dh = explode ("\n", str_replace ("\r", "", $settings['new_index_dh']['value']));
	foreach($new_index_dh as $key=>$value){
		$arr=explode('|',$value);
		$new_index_dh_types[]=$arr;
	}
	$pid = 2;
	$ggurl = 'plugin.php?id=aljsc&act=view&sid={goods_id}';
	$orderlisturl = 'plugin.php?id=aljgwc&act=orderlist&pluginid='.$pluginid;
	$aljsclang['template']  = array(
		'home_page' => '&#39318;&#39029;',//��ҳ
		'Shopping_Cart' => '&#36141;&#29289;&#36710;',//���ﳵ
		'my' => '&#25105;&#30340;',//�ҵ�
		'All_goods' => '&#20840;&#37096;&#21830;&#21697;',//ȫ����Ʒ
	);
	$groups = unserialize($_G['cache']['plugin'][$pluginid]['groups']);
    $extcredits_aljsc = getuserprofile('extcredits'.$_G['cache']['plugin']['aljsc']['extcredit']);
}else{
	$ggurl = 'plugin.php?id=aljbd&act=goodview&bid={bid}&gid={goods_id}';
	$orderlisturl = 'plugin.php?id=aljbd&act=orderlist';
	$aljbdlang['template']  = array(
		'home_page'=>'&#39318;&#39029;',//��ҳ
		'My'=>'&#25105;&#30340;',//�ҵ�
		'search'=>'&#25628;&#32034;',//����
		'goods'=>'&#21830;&#21697;',//��Ʒ
		'whole'=>'&#20840;&#37096;',//ȫ��
		'business'=>'&#21830;&#23478;',//�̼�
		'Buy_immediately'=>'&#31435;&#21363;&#36141;&#20080;',//��������
		'Confirm_the_payment'=>'&#30830;&#35748;&#20184;&#27454;',//ȷ�ϸ���
	);
	$settings=C::t('#aljbd#aljbd_setting')->range();
	$is_openarray = array('iswatermark','is_daohang','alipay','malipay','isextcredit','pic','isgo','isnews','isyouh','ispd','isrewrite','islogo','isqq','ista','sjurl','sj_index_lz','time');
	foreach($settings as $k => $v){
		if(in_array($k,$is_openarray)){//�����ж�
			if($v['value'] == 1){
				$_G['cache']['plugin']['aljbd'][$k] = 1;
			}elseif($v['value'] == 2){
				$_G['cache']['plugin']['aljbd'][$k] = 0;
			}
		}else{
			if($v['value']){
				$_G['cache']['plugin']['aljbd'][$k] = htmlspecialchars_decode($v['value']);//ͬ����������ֵ���������б���
			}
		}
	}
	$fare_desc = array('1'=>'&#21253;&#37038;','2'=>'&#21040;&#20184;');
	$admingroups = unserialize($_G['cache']['plugin'][$pluginid]['managegroups']);
	$user = C::t('#aljbd#aljbd_user') -> fetch($_G['uid']);

	//debug($settings['displaynavs']['value']);
	if($settings['displaygoodsnav']['value']){
		$alltype = DB::fetch_all('select * from %t where upid=0 order by displayorder asc limit 0,13',array('aljbd_type_goods'));
	}else{
		$alltype = DB::fetch_all('select * from %t where upid=0 order by displayorder asc limit 0,13',array('aljbd_type'));
	}
	$yindao = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin'][$pluginid] ['yindao']));
	foreach($yindao as $key=>$value){
		$arr=explode('|',$value);

		$yd_types[]=$arr;
	}
	$businesstype = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin'][$pluginid] ['businesstype']));
	foreach($businesstype as $key=>$value){
		$arr=explode('=',$value);
		$businesstypearr[$arr[0]]=$arr[1];
	}
    $mobile_user_9 = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin'][$pluginid] ['mobile_user_9']));
    foreach($mobile_user_9 as $key=>$value){
        $arr=explode('|',$value);

        $custom_types[]=$arr;
    }
	$ress=array(
		'brand_index.html'=>'plugin.php?id=aljbd',
		'brand.html'=>'plugin.php?id=aljbd&act=dianpu',
		'goods.html'=>'plugin.php?id=aljbd&act=goods',
		'notice.html'=>'plugin.php?id=aljbd&act=nlist',
		'consume.html'=>'plugin.php?id=aljbd&act=clist',
	);
	$index_dh = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin'][$pluginid] ['index_dh']));
	foreach($index_dh as $key=>$value){
		$arr=explode('|',$value);
		$index_dh_types[$arr[0]]=$arr[1];
	}
	if ($_SERVER ['HTTP_X_REWRITE_URL']) {
		$the_uri = isset($_SERVER ['HTTP_X_REWRITE_URL']) ? $_SERVER ['HTTP_X_REWRITE_URL'] : '';
	} else {
		$the_uri = isset($_SERVER ['REQUEST_URI']) ? $_SERVER ['REQUEST_URI'] : '';
	}
    $record1 = C::t('#aljbd#aljbd_setting')->fetch('lazyloadlogo');
    $lazyloadlogo = $record1['value'];
    if($lazyloadlogo){
        $loading = $lazyloadlogo;
    }else{
        $loading = 'source/plugin/aljbd/images/loading.gif';
    }
}
$act = htmlspecialchars($_GET['act']);
if($_GET['orderid']){
	$o_url = '%26orderid='.$_GET['orderid'];
}
if($_GET['shop_id']){
	$o_url .= '%26shop_id='.intval($_GET['shop_id']);
}
if($_GET['goods_id']){
	$o_url .= '%26goods_id='.intval($_GET['goods_id']);
}
if($pluginid){
	$o_url .= '%26pluginid='.$pluginid;
}
if($_GET['num']){
	$o_url .= '%26num='.intval($_GET['num']);
}

$login_callback = 'member.php?mod=logging&action=login&referer=plugin.php?id=aljgwc%26act='.$_GET['act'].$o_url;
if(!$_G['uid'])
 {
  dheader("location:".$login_callback);
  exit;
 }
$aljbdlang['template']['User_center'] = '&#29992;&#25143;&#20013;&#24515;';//�û�����
$aljbdlang['template']['Exit_login'] = '&#36864;&#20986;&#30331;&#24405;';//�˳���¼


$address_id = intval($_GET['address_id']);
$s_id = intval($_GET['shop_id']);
$goods_id = intval($_GET['goods_id']);
$address = C::t('#aljgwc#aljbd_address')->fetch($address_id);
if($address_id){
	$def_address = C::t('#aljgwc#aljbd_address')->fetch_by_uid_addressid($_G['uid'],$address_id);
}else{
	$def_address = C::t('#aljgwc#aljbd_address')->fetch_by_uid($_G['uid']);
}
$address_num = C::t('#aljgwc#aljbd_address')->count_by_uid($_G['uid']);//�ջ���ַ����
$regionlist=C::t('#aljgwc#aljgwc_region')->range();
//1΢��2֧����5����6����
$paymentarr = array('1' => '&#24494;&#20449;&#25903;&#20184;','2' => '&#25903;&#20184;&#23453;&#25903;&#20184;','3' => '&#65;&#80;&#80;&#24494;&#20449;&#25903;&#20184;','5'=>'&#31215;&#20998;&#25903;&#20184;('.$_G['setting']['extcredits'][$config['ext_aljbd']]['title'].')','6'=>'&#36135;&#21040;&#20184;&#27454;');
$addrlist = C::t('#aljgwc#aljbd_address')->fetch_all_by_uid_desc($_G['uid']);
$biaoshi = '&pluginid='.$pluginid;
$extcredits = getuserprofile('extcredits'.$config['ext_aljbd']);
$refund_type_array = array('1'=>$aljgwclang['php']['Refund_only'],'2'=>$aljgwclang['php']['Return_refund']);
$price_unit = '&#65509;';
$price_symbol = '&#20803;';
if($_GET['p_type']){
	$p_type = '&p_type='.intval($_GET['p_type']);
}
if($_G['cache']['plugin']['aljbd'] && file_exists("source/plugin/aljbd/include/newparameter.php")){
    require_once 'source/plugin/aljbd/include/newparameter.php';
}
if($_GET['act'] == 'linkage'){
	if($_GET['upid']){

		$rlist=C::t('#aljgwc#aljgwc_region')->fetch_all_by_upid($_GET['upid']);
		$trid = 'id';
		$trname = 'name';
		if(is_array($rlist)){
			foreach($rlist as $key => $val){
				$returnarray[$val[$trid]] = diconv($val[$trname],CHARSET,'utf-8');
			}
			echo json_encode($returnarray);
			exit;
		}
	}
}else if($_GET['act'] == 'cartnum'){
    $cartnum = DB::result_first('select count(*) from %t where uid=%d and pid=0',array('aljgwc',$_G['uid']));
    echo $cartnum;
    exit;
}else if($_GET['act'] == 'mobile_goodsview_pay'){
	$shop = C::t('#aljbd#aljbd_goods')->fetch($_GET['gid']);
	$gattrkey = unserialize($shop['attr_key']);
	if(!$gattrkey){
		$gattrkey = 0;
	}
	$gattrkeyc = count($gattrkey);
	$gattrvalue = unserialize($shop['attr_value']);

	$shop['attr_sku'] = unserialize($shop['attr_sku']);
	foreach($shop['attr_sku'] as $k => $v){
	    if($v['saleprice']>0 && $v['stock']>0){
            $gattrsku[] = $v;
        }
	}

	$gattrsku = json_encode($gattrsku);
	if($_GET['btngwc'] == 'yes'){
		$btngwc = 1;
	}
	if($_GET['cart'] == 'yes'){
		$formurl = 'plugin.php?id=aljgwc&act=addcart&gid='.$shop['id'].'&pluginid=aljbd';
	}else{
		$formurl = 'plugin.php?id=aljgwc&act=buy&pluginid=aljbd&goods_id='.$shop['id'];
	}
	include template('aljgwc:confirm');
}else if($_GET['act'] == 'addcart'){
	if($_GET['formhash'] != $_G['formhash']) {
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
		    if($pluginid == 'aljbd'){
                echo "<script>parent.tips('submit_invalid','');</script>";
                exit;
            }else {
                showmessage('submit_invalid');
            }
		}else{
			echo '<script>parent.showDialog("submit_invalid","")</script>';
			exit;
		}
	}
	if(empty($_GET['gid'])) {
		//showmessage($alj_lang['The_goods_do_not_exist']);
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            if($pluginid == 'aljbd'){
                echo "<script>parent.tips('".$alj_lang['The_goods_do_not_exist']."','');</script>";
                exit;
            }else {
                showmessage($alj_lang['The_goods_do_not_exist']);
            }
		}else{
			echo '<script>parent.showDialog("'.$alj_lang['The_goods_do_not_exist'].'","")</script>';
			exit;
		}
	}
	if($pluginid == 'aljsc'){
		$goods = C::t('#'.$pluginid.'#'.$pluginid)->fetch($_GET['gid']);
		if($goods[num]<=0){

		   if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                showmessage($alj_lang['The_goods_sold']);
			}else{
				echo '<script>parent.showDialog("'.$alj_lang['The_goods_sold'].'","")</script>';
				exit;
			}
		}
		$price = $goods['price'];
		$title = $goods['title'];
		if($goods['price']){
			$shop_id = 1;
		}else{
			$shop_id = 2;
		}
	}else{
		$goods = C::t('#'.$pluginid.'#'.$pluginid.'_goods')->fetch($_GET['gid']);
		if($pluginid == 'aljbd'){
			$gattrsku_1 = skups($goods['attr_sku'],$attrsid);//��ϼ۸���
			if($goods['attr_sku'] && $attrsid){
				if($gattrsku_1['stock'] < $_GET['num']){
					if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                        echo "<script>parent.tips('".$alj_lang['The_goods_sold']."','');</script>";
                        exit;
					}else{
						echo '<script>parent.showDialog("'.$alj_lang['The_goods_sold'].'","")</script>';
						exit;
					}
				}
			}else{
				if($goods[amount]<=0){

				   if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                       echo "<script>parent.tips('".$alj_lang['The_goods_sold']."','');</script>";
                       exit;
					}else{
						echo '<script>parent.showDialog("'.$alj_lang['The_goods_sold'].'","")</script>';
						exit;
					}
				}
			}
		}else{
			if($goods[amount]<=0){

			   if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
					showmessage($alj_lang['The_goods_sold']);
				}else{
					echo '<script>parent.showDialog("'.$alj_lang['The_goods_sold'].'","")</script>';
					exit;
				}
			}
		}
		$price = $goods['price1'];
		$title = $goods['name'];
		$shop_id = $goods['bid'];
	}
	if($pluginid == 'aljsc' || $pluginid == 'aljtg'){
		$allattrs = C::t('#'.$pluginid.'#'.$pluginid.'_attr') -> range();
		if($_GET['typename']){
			foreach($_GET['typename'] as $v){
				if($v){
					$attrs[]=$allattrs[$v]['content'];
				}
			}
			$attrs = implode(',',$attrs);
		}
		$cart = C::t('#aljgwc#aljgwc')->fetch_all_by_goods_id($_GET['gid'], $_G['uid'],$pid);
	}else{
		$goods['attr_value'] = unserialize($goods['attr_value']);
		foreach($goods['attr_value'] as $k => $v){
			$gattrvalue[$v['symbol']] = $v;
		}
		$goods['attr_sku'] = unserialize($goods['attr_sku']);
		foreach($goods['attr_sku'] as $k => $v){
			$gattrsku[$v['path']] = $v;
		}
		if($_GET['typename']){
			foreach($_GET['typename'] as $v){
				if($v){
					$attrs[]=$gattrvalue[$v]['value'];
					$attrsid[]=$v;
				}
			}
			$attrs = implode(',',$attrs);
			$attrsid = implode(',',$attrsid);
		}
		if($gattrsku[$attrsid]['saleprice']){
			$price = $gattrsku[$attrsid]['saleprice'];//��ϼ۸�
		}
		$cart = DB::result_first('select count(*) from %t where goods_id=%d and uid=%d and pid=%d and path=%s',array('aljgwc',$_GET['gid'], $_G['uid'],$pid,$attrsid));
	}

	if($cart){
		//showmessage($alj_lang['Goods_already_exist'],'plugin.php?id=aljgwc&pluginid='.$pluginid);
		$num = $_GET['num']?$_GET['num']:1;
		if($pluginid == 'aljsc' || $pluginid == 'aljtg'){
			DB::query('update %t set num=num+%d where goods_id=%d and uid=%d and pid=%d', array('aljgwc',$num,$_GET['gid'],$_G['uid'],$pid));
		}else{
			DB::query('update %t set num=num+%d where goods_id=%d and uid=%d and pid=%d and path=%s', array('aljgwc',$num,$_GET['gid'],$_G['uid'],$pid,$attrsid));
		}
	} else {
		$setarr = array(
			'goods_id' => $_GET['gid'],
			'shop_id' => $shop_id,
			'name' => $title,
			'num' => $_GET['num']?$_GET['num']:1,
			'price' => $price,
			'fare' => $goods['fare'],
			'fare_desc' => $goods['fare_desc'],
			'uid' => $_G['uid'],
			'content' => $attrs,
			'path' => $attrsid,
			'username' => $_G['username'],
			'dateline' => $_G['timestamp'],
			'ip' => $_G['clientip'],
			'pid' => $pid,
			'ext' => $goods['extcredit'],
			'browser' => $_SERVER['HTTP_USER_AGENT'],
		);
		if($_G['mobile']){//1���ֻ���2��PC
			$setarr['mobile'] = 1;
		}else{
			$setarr['mobile'] = 2;
		}
		if(file_exists("source/plugin/xydz/xydz.inc.php")){
			require_once 'source/plugin/xydz/include/addcart.php';
		}
        if(file_exists("source/plugin/dz_1/dz_1.inc.php")){
            require_once 'source/plugin/dz_1/include/addcart.php';
        }
		C::t('#aljgwc#aljgwc')->insert($setarr);
	}
	if($_G['mobile']){
        if($pluginid == 'aljbd'){
            echo "<script>parent.cartnum();parent.tips('".$alj_lang['Join_success']."','');</script>";
            exit;
        }else {
            showmessage($alj_lang['Join_success'], 'plugin.php?id=aljgwc&pluginid=' . $pluginid, array(), array('header' => true));
        }
	}else{
		echo"<script language='JavaScript'> ";
		echo"parent.window.showWindow('tips','plugin.php?id=aljgwc&act=tips&pluginid=".$pluginid."');";
		echo"</script>";
	}
} else if($act == 'user'){
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljtg','s22'));
	}

	if($cparray['aljbd']){
		$settings_aljbd=C::t('#aljbd#aljbd_setting')->range();
	}
	$group_array = C::t('common_usergroup')->range();
	if($pluginid == 'aljtg'){
		$settings=C::t('#aljtg#aljtg_setting')->range();
	}
	if($settings['is_mobile_template']['value'] || ($_G['cache']['plugin']['aljtg'][tobrand] && $pluginid == 'aljbd' && $_G['cache']['plugin']['aljgwc'][aljbd]) || ($_G['cache']['plugin']['aljgwc'][aljbd] && $pluginid == 'aljbd')){
		if($pluginid == 'aljtg'){
            include template('aljgwc:user_new');
        }else{

            if(!in_array($_G['groupid'],$admingroups)) {
                if (C::t('#aljbd#aljbd')->fetch_by_uid($_G['uid'])) {
                    $ddo = '&do=bus';
                } else {
                    $ddo = '&do=per';
                }
            }else{
                $ddo = '&do=admin';
            }
            $conn[] ='aljbd_goods_order';
            $where = 'where pid = 0 and status < 5';
		    /*if(!$_GET['do']){
                dheader('Location: plugin.php?id=aljgwc&act=user'.$ddo.'&pluginid='.$pluginid);
            }else*/
			if($_GET['do'] == 'bus'){
                $do = '&do=per';
                $ord = '&ord=dianp';
                $userimg = 'source/plugin/aljgwc/template/touch/user/img/myuser.png';
                $bids = DB::fetch_all('select id from %t where uid = %d',array('aljbd',$_G['uid']));
                foreach($bids as $bid){
                    $ids[] = $bid['id'];
                }
                $bids = implode(',',$ids);
                $where .= ' and shop_id in(%i)';
                if($bids){
                    $conn[] = $bids;
                }else{
                    $conn[] = 0;
                }
            }elseif($_GET['do'] == 'admin'){
                $do_per = '&do=per';
                $do_bus = '&do=bus';
                $ord = '&ord=admin';
                $userimg_myuser = 'source/plugin/aljgwc/template/touch/user/img/myuser.png';
                $userimg = 'source/plugin/aljgwc/template/touch/user/img/mybrand.png';
            }else{
                $do = '&do=bus';
                $ord = '&ord=ge';
                $userimg = 'source/plugin/aljgwc/template/touch/user/img/mybrand.png';
                $where .= ' and uid = %d';
                $conn[] = $_G['uid'];
                $dourl = '&do='.$_GET['do'];
            }
            $where .= ' group by status';
            $num = DB::fetch_all('select status,count(*) a from %t '.$where,$conn);
            //�ҵ�ȫ������
            $mobile_user_order = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljbd']['mobile_user_order']));
            foreach($mobile_user_order as $key=>$value){
                $arr=explode('|',$value);
                $mobile_user_order_types[]=$arr;
            }
			//�ҵ�ҳ�泣�����
            $mobile_user_common_entrance = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljbd']['mobile_user_common_entrance']));
            foreach($mobile_user_common_entrance as $key=>$value){
                $arr=explode('|',$value);
                $mobile_user_common_entrance_types[]=$arr;
            }
            //�ҵ�ҳ���̼�����
            $mobile_user_business_center = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljbd']['mobile_user_business_center']));
            foreach($mobile_user_business_center as $key=>$value){
                $arr=explode('|',$value);
                $mobile_user_business_center_types[]=$arr;
            }
            //�ҵ�ҳ��ͬ����Ϣ
            $mobile_user_city_wide = explode ("\n", str_replace ("\r", "", $_G['cache']['plugin']['aljbd']['mobile_user_city_wide']));
            foreach($mobile_user_city_wide as $key=>$value){
                $arr=explode('|',$value);
                $mobile_user_city_wide_types[]=$arr;
            }
            foreach($num as $k => $v){
                if($v['status'] == '1'){
                    $order_pay = $v['a'];
                }elseif($v['status'] == '2'){
                    $order_send = $v['a'];
                }elseif($v['status'] == '3'){
                    $order_deliver = $v['a'];
                }elseif($v['status'] == '4'){
                    $order_evaluate = $v['a'];
                }
            }
            $navtitle = '&#29992;&#25143;&#20013;&#24515;';
            include template('aljgwc:user/user_new');
        }
	}else{
		include template('aljgwc:user');
	}
} else if($_GET['act'] == 'tips'){
	$num = C::t('#aljgwc#aljgwc')->count_by_uid($_G['uid'],$pid);
	$goodslist = C::t('#aljgwc#aljbd_goods_order_list')->group_by_shopid($pid);
	foreach($goodslist as $key => $val){

		$goodslist[$key]['url'] = str_replace(array('{bid}','{goods_id}'),array($val['shop_id'],$val['goods_id']),$ggurl);
		if($pid == 2){
			$goodslist[$key]['pic'] = DB::result_first('select logo from %t where id=%d',array($pluginid,$val['goods_id']));
		}else{
			$goodslist[$key]['pic'] = DB::result_first('select pic1 from %t where id=%d',array($pluginid.'_goods',$val['goods_id']));
		}
	}
	include template('aljgwc:aljtg/tips');
}else if($_GET['act'] == 'num'){
	if($_GET['formhash'] != $_G['formhash']) {
		showmessage('submit_invalid');
	}
	if($_GET['num_bth'] == btnCut){
		C::t('#aljgwc#aljgwc')->increase($_GET['cart_id'], array('num' => -1));
	}elseif($_GET['num_bth'] == btnAdd){
		C::t('#aljgwc#aljgwc')->increase($_GET['cart_id'], array('num' => 1));
	}elseif($_GET['num_bth'] == btnval){
		C::t('#aljgwc#aljgwc')->update($_GET['cart_id'], array('num' => intval($_GET['num'])));
	}
	showmessage('operation_done', 'plugin.php?id=aljgwc&pluginid='.$pluginid, array(), array('header' => true));
}else if($_GET['act'] == 'delcart'){
	if($_GET['formhash'] != $_G['formhash']) {
		showmessage('submit_invalid');
	}
	C::t('#aljgwc#aljgwc')->delete($_GET['cart_id']);
	showmessage('operation_done', 'plugin.php?id=aljgwc&pluginid='.$pluginid, array(), array('header' => true));
}else if($_GET['act'] == 'cartsubmit'){
	if(submitcheck('formhash')) {
		//���� e
		if($pluginid == 'aljsc' && $pid == 2){
			require_once 'source/plugin/aljgwc/include/aljsc/cartsubmit.php';
		}else if($pluginid == 'aljtg' && $pid == 1){
			require_once 'source/plugin/aljgwc/include/aljtg/cartsubmit.php';
		}else{
			require_once 'source/plugin/aljgwc/include/cartsubmit.php';
		}
	}
}else if($_GET['act'] == 'cart_pay'){


	if(empty($_G['uid'])){
		//showmessage('&#35831;&#20808;&#30331;&#24405;&#65281;', 'member.php?mod=logging&action=login&referer=plugin.php?id=aljgwc%26act='.$act.'%26order_id='.$_GET['orderid'], array(), array('header' => true));
		dheader("location:".$login_callback.'%26order_id='.$_GET['orderid']);
	}

	$orderid = $_GET['orderid']?$_GET['orderid']:'';
	if(!$orderid){
		showmessage('&#35746;&#21333;&#19981;&#23384;&#22312;');
	}
    if($extcredits_aljsc < $_GET['totalpriceext'] && $pid == 2){
        showmessage('&#31215;&#20998;&#19981;&#36275;');
    }
	$order=C::t('#aljgwc#aljbd_goods_order')->fetch($orderid);

    $orderpaytime = $order['submitdate']+900;
    $time = $orderpaytime - TIMESTAMP;

    if($time<=0) {
        $time = 0;
    }
    $m = $time/60%60;
    $m= str_pad($m,2,0,STR_PAD_LEFT);
    $s = $time%60;
    $s = str_pad($s,2,0,STR_PAD_LEFT);

	if(!$order){
		if($pid == 1){
			showmessage('&#35746;&#21333;&#24322;&#24120;&#36820;&#22238;&#35746;&#21333;&#21015;&#34920;','plugin.php?id='.$pluginid.':member&act=orderlist');
		}elseif($pid == 2){
			showmessage('&#35746;&#21333;&#24322;&#24120;&#36820;&#22238;&#35746;&#21333;&#21015;&#34920;','plugin.php?id=aljgwc&act=orderlist&pluginid='.$pluginid);
		}else{
			showmessage('&#35746;&#21333;&#24322;&#24120;&#36820;&#22238;&#35746;&#21333;&#21015;&#34920;','plugin.php?id='.$pluginid.'&act=orderlist');
		}
	}
	$order_goodsname=C::t('#aljgwc#aljbd_goods_order_list')->fetch_all_by_orderid($orderid);
	foreach($order_goodsname as $value){
		$goods_name=preg_replace('# #','',$value['name']);
	}
	$order['subject'] = $goods_name;
    //debug($order['subject']);
	$params = array(
		'body' => diconv($order['subject'],CHARSET,'UTF-8'),
		'out_trade_no' => $orderid,
		'total_fee' => $order['price'],
		'notify_url' => $notify_url,
	);

	if($order['payment'] == '1' || $order['payment'] == '3'){
		if($iswechat){
			$openid = getcookie('openid');
			if(!$openid){

				$openid = getopenid($orderid);
				dsetcookie('openid',$openid);
			}
		}
		$params['total_fee'] = $params['total_fee']*100;
		if($isappbyme){
			$apppay = apppay($params);
			$payfunction = 'payWechat';
		}else{
			if($_G['mobile']){
				$params['openid'] = $openid;

				$jsapiparameters = wxpay($params);

			}else{
				$codeurl = getcodeurl($params);
				require_once DISCUZ_ROOT.'source/plugin/'.$pluginid.'/class/qrcode.class.php';
				$file = 'source/plugin/aljgwc/images/qrcode/qrcode_'.$orderid.'.jpg';
				QRcode::png($codeurl,$file);
			}
			if($iswechat){
				$payfunction = 'jsApiCall';
			}elseif($_G['mobile']){
				if($config['h5']){
					unset($params['openid']);
		            $payfunction = 'h5';
		            $wxapiparameters = wxh5pay($params);
					//debug($wxapiparameters);
					$payfunction = 'h5pay';
        		}else{
					unset($params['openid']);
					$codeurl = getcodeurl($params);
					require_once DISCUZ_ROOT.'source/plugin/'.$pluginid.'/class/qrcode.class.php';
					$file = 'source/plugin/aljgwc/images/qrcode/qrcode_'.$orderid.'.jpg';
					QRcode::png($codeurl,$file);
					$payfunction = 'alertmes';
				}
			}else{
				$payfunction = 'jsApiCall';
			}
		}
	}elseif($order['payment'] == '5'){
		$payfunction = 'tipsext';
	}elseif($order['payment'] == '6'){

	}else{
		if(strtolower(CHARSET) == 'gbk'){
			$params['subject'] = diconv($order['subject'],CHARSET,'UTF-8');
		}else{
			$params['subject'] = $order['subject'];
		}
		if($pid == 1){
			$params['return_url'] = $_G['siteurl'].'/plugin.php?id='.$pluginid.':member&act=orderlist';
			$params['show_url'] = $_G['siteurl'].'/plugin.php?id='.$pluginid.':member&act=orderlist';
		}else if($pid == 2){
			$params['return_url'] = $_G['siteurl'].'/plugin.php?id=aljgwc&act=orderlist&pluginid='.$pluginid;
			$params['show_url'] = $_G['siteurl'].'/plugin.php?id=aljgwc&act=orderlist&pluginid='.$pluginid;
		}else{
			$params['return_url'] = $_G['siteurl'].'/plugin.php?id='.$pluginid.'&act=orderlist';
			$params['show_url'] = $_G['siteurl'].'/plugin.php?id='.$pluginid.'&act=orderlist';
		}
		if($_G['mobile']){
			$alipayurl = alipay($params);
		}else{
			unset($params['total_fee']);
			$params['price'] = $order['price'];
			$alipayurl = pcalipay($params,$order['fare']);
		}

		$payfunction = 'alipay';
	}
	$navtitle ="&#30830;&#35748;&#20184;&#27454;";
	include template('aljgwc:cart_pay');
}else if($_GET['act'] == 'ext_pay'){
	$orderid = addslashes($_GET['orderid']);
	$status = 2;
	$orderlurl = $_G['siteurl'].'/plugin.php?id='.$pluginid.'&act=orderlist';
	$orderlurln = '/plugin.php?id='.$pluginid.'&act=orderlist';
	$order = C::t('#aljgwc#aljbd_goods_order') -> fetch($orderid);
	if($extcredits < $order['ext']) {
		showmessage($_G['setting']['extcredits'][$config['ext_aljbd']]['title'].'&#19981;&#36275;&#65292;&#35831;&#20805;&#20540;&#21518;&#20877;&#25903;&#20184;');
	}
	C::t('#aljgwc#aljbd_goods_order')->update($orderid, array('status' => $status,'confirmdate' => $_G['timestamp']));
	updatemembercount($_G['uid'], array($config['ext_aljbd'] => -intval($order['ext'])),'','','','','&#36141;&#20080;&#21830;&#21697;','&#36141;&#20080;&#25104;&#21151;&#65292;&#25187;&#38500;'.$order['ext'].$_G['setting']['extcredits'][$config['ext_aljbd']]['title'].',&#35746;&#21333;&#21495;&#65306;'.$orderid);
	$shop_order=C::t('#aljgwc#aljbd_goods_order_list')->fetch_all_by_orderid($orderid);
	foreach($shop_order as $key => $val){
		C::t('#'.$pluginid.'#'.$pluginid.'_goods')->update_num2_by_id($val['goods_id'],$val['num']);
	}
	$brand = C::t('#'.$pluginid.'#'.$pluginid) -> fetch($order['shop_id']);
	notification_add($order['uid'],'system',str_replace('{username}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['suctips'])).' <a href="'.$orderlurln.'">'.lang('plugin/aljgwc','View_orders').'</a>');
	$order['price'] = $order['price'];
	if(!$order['pid'] && $cparray['aljjs']){//aljbd����
		$isuerexists = DB::result_first('select uid from %t where uid=%d and bid=%d',array('aljjs_brandsettle',$brand['uid'],$brand['id']));
		if(!$isuerexists){
			DB::insert('aljjs_brandsettle',array('uid' =>$brand['uid'],'bid' => $brand['id'],'income'=>0,'times'=>0,'cash'=>0,'balance'=>0,'dateline'=>TIMESTAMP));
		}

		DB::query('update %t set income=income+%i,b_times=b_times+1,balance=balance+%i,dateline=%d where uid=%d and bid=%d',array('aljjs_brandsettle',$order['price'],$order['price'],TIMESTAMP,$brand['uid'],$brand['id']));
	}

	if(!$order['pid']){//Ʒ���̼�
		$is_aljdx = $cparray['aljdx'];
		if($is_aljdx){
			require_once 'source/plugin/aljdx/function_dx.php';
			$oaddress = unserialize($order['address']);
            $orderidau = $_G['cache']['plugin']['aljbd']['is_dx_var'] ? 'orderidau' : 'orderid_au';
            $username_au = $_G['cache']['plugin']['aljbd']['is_dx_var'] ? 'usernameau' : 'username_au';
			if(preg_match('#^\d[\d-]{3,20}\d$#', $oaddress['mobile'])){
				sendsmsbyvar($oaddress['mobile'],'aljbd','tips_user',array($username_au =>$order['username'] ,$orderidau => $_G['cache']['plugin']['aljbd']['is_dx_order']?'**'.substr($order['orderid'],-4):$order['orderid']));
			}
			if(preg_match('#^\d[\d-]{3,20}\d$#', $brand['tel'])){
				sendsmsbyvar($brand['tel'],'aljbd','tips_business',array($orderidau => $_G['cache']['plugin']['aljbd']['is_dx_order']?'**'.substr($order['orderid'],-4):$order['orderid']));
			}
		}
	}

	if($_G['cache']['plugin'][$pluginid]['time'] && $_G['cache']['plugin'][$pluginid]['notify_merchant']){
		notification_add($brand['uid'],'system',str_replace('{orderid}','<a href="'.$orderlurln.'">'.$data['out_trade_no'].'</a>',str_replace('{username}',$brand['username'],str_replace('{name}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['notify_merchant'])))));
		$email_first = C::t("common_member")->fetch($order['uid']);
		$email = $email_first['email'];
        require_once libfile('function/mail');
		if($email_first['email']){
			$m=str_replace('{username}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['suctips'])).'&nbsp;<a href="'.$orderlurl.'">'.lang('plugin/aljgwc','View_orders').'</a>';
			sendmail_cron($email,$_G['cache']['plugin'][$pluginid]['mailtitle'].'@'.gmdate('Y-m-d H:i:s',$_G['timestamp']+8*3600),$m);
		}
		$email_f = C::t("common_member")->fetch($brand['uid']);
		$e = $email_f['email'];
		if($email_f['email']){
			$me=str_replace('{orderid}','<a href="'.$orderlurl.'">'.$data['out_trade_no'].'</a>',str_replace('{username}',$brand['username'],str_replace('{name}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['notify_merchant']))));
			$t=str_replace('{orderid}',$data['out_trade_no'],$_G['cache']['plugin'][$pluginid]['notify_merchant_title']);
			sendmail_cron($e,$t,$me);
		}
	}
	echo 1;
	exit;
}else if($_GET['act'] == 'wxpaywindow'){
	$orderid = addslashes($_GET['orderid']);
	$file = 'source/plugin/aljgwc/images/qrcode/qrcode_'.$orderid.'.jpg';
	include template('aljgwc:wxpaywindow');
}else if($_GET['act'] == 'wxcheck'){
	if($_G['mobile']){
		$orderid = addslashes($_GET['orderid']);
		$order=C::t('#aljgwc#aljbd_goods_order')->fetch($orderid);
		if($order['status'] == 2  || $order['status'] == 3){
			echo '1';
		}else{
			echo '0';
		}

		exit;
	}else{
		$orderid = addslashes($_GET['orderid']);
		$order=C::t('#aljgwc#aljbd_goods_order')->fetch($orderid);
		include template('common/header');
		if($pid == 1){
			if($order['status'] == 2 || $order['status'] == 3){
				echo $alj_lang['Payment_success'].'<script>alert("'.$alj_lang['Payment_success'].'");location.href="plugin.php?id='.$pluginid.':member&act=orderlist";</script>';
			}
		}else if($pid == 2){
			if($order['status'] == 2){
				echo $alj_lang['Payment_success'].'<script>alert("'.$alj_lang['Payment_success'].'");location.href="plugin.php?id=aljgwc&act=orderlist&pluginid='.$pluginid.'";</script>';
			}
		}else{
			if($order['status'] == 2){
				echo $alj_lang['Payment_success'].'<script>alert("'.$alj_lang['Payment_success'].'");location.href="plugin.php?id='.$pluginid.'&act=orderlist";</script>';
			}
		}
		include template('common/footer');
		exit;
	}
}else if($_GET['act'] == 'buy'){
	$num = intval($_GET['num']);
	$goods_id = $_GET['goods_id'];
	if($pid == '2'){
		$goods=C::t('#'.$pluginid.'#'.$pluginid)->fetch($_GET['goods_id']);
		if($goods['price']){
			$goods['price1'] = $goods['price'];
		}else{
			$goods['price1'] = $goods['extcredit'];
		}
		$goods[pic1] = $goods['logo'];
		$goods['name'] = $goods['title'];
		$goods['fare'] = 0;
		$goods['amount'] = $goods['num'];
	}else{
		$goods=C::t('#'.$pluginid.'#'.$pluginid.'_goods')->fetch($_GET['goods_id']);
	}

	if($pluginid == 'aljsc') {
        $allattrs = C::t('#' . $pluginid . '#' . $pluginid . '_attr')->range();
        if ($_GET['typename']) {
            foreach ($_GET['typename'] as $v) {
                if ($v) {
                    $attrs[] = $allattrs[$v]['content'];
                }
            }
            $attrs = implode(',', $attrs);
        } else if ($_GET['attrs']) {
            $attrs = $_GET['attrs'];
        }
        $navtitle = '&#31435;&#21363;&#36141;&#20080;';
        include template('aljgwc:aljsc/buy');
    }elseif($pluginid == 'aljtg'){
        $allattrs = C::t('#' . $pluginid . '#' . $pluginid . '_attr')->range();
        if ($_GET['typename']) {
            foreach ($_GET['typename'] as $v) {
                if ($v) {
                    $attrs[] = $allattrs[$v]['content'];
                }
            }
            $attrs = implode(',', $attrs);
        } else if ($_GET['attrs']) {
            $attrs = $_GET['attrs'];
        }
        $navtitle = '&#31435;&#21363;&#36141;&#20080;';
        include template('aljgwc:aljtg/buy');
	}else{
		$goods['attr_value'] = unserialize($goods['attr_value']);
		foreach($goods['attr_value'] as $k => $v){
			$gattrvalue[$v['symbol']] = $v;
		}
		$goods['attr_sku'] = unserialize($goods['attr_sku']);
		foreach($goods['attr_sku'] as $k => $v){
			$gattrsku[$v['path']] = $v;
		}
		if($_GET['typename']){
			foreach($_GET['typename'] as $v){
				if($v){
					$attrs[]=$gattrvalue[$v]['value'];
					$attrsid[]=$v;
				}
			}
			$attrs = implode(',',$attrs);
			$attrsid = implode(',',$attrsid);
		}else if($_GET['attrs']){
			$attrs = $_GET['attrs'];
			$attrsid = $_GET['attrsid'];
		}
		if($gattrsku[$attrsid]['saleprice'] && $attrsid){
			$goods['price1'] = $gattrsku[$attrsid]['saleprice'];//��ϼ۸�
		}
		$navtitle = '&#31435;&#21363;&#36141;&#20080;';
		if($goods[fare]>0){
			$fare = $goods[fare];
		}
		$totalprice = $num * $goods[price1];//��Ʒ�ܼ�
		$total = $num * $goods[price1] + $fare;//����۸�

		if($goods['fare_desc'] == 1 || $goods['fare_desc'] == 2){
			$fare_d = $fare_desc[$goods['fare_desc']];
		}else{
			if($goods[fare]>0){
				$fare_d = $fare;
			}else{
				$fare_d = '&#21253;&#37038;';
			}
		}
        $discount = DB::fetch_all('select * from %t where bid=%d and (end>%s || end=0) and full>0 and reduction>0 order by reduction desc',array('aljbd_consume',intval($goods['bid']),TIMESTAMP));
		foreach($discount as $dk => $kv){
            $kv['full'] = floatval($kv['full']);
            $kv['reduction'] = floatval($kv['reduction']);
			if($kv['full'] <= $totalprice){
                $firstdis[] = $kv;
			}
		}

		if(file_exists("source/plugin/dz_3/dz_3.inc.php") && ($_GET['p_type'] == 2 || $_GET['p_type'] == 3)){
            include template('dz_3:buy');
		}else{
            include template('aljgwc:buy');
		}
	}

}else if($_GET['act'] == 'buysubmit'){
	if(submitcheck('formhash')) {
		//���ֹ��� s
		if($pluginid == 'aljsc' && $pid == 2){
			require_once 'source/plugin/aljgwc/include/aljsc/buysubmit.php';
		}elseif($pluginid == 'aljtg' && $pid == 1){
			require_once 'source/plugin/aljgwc/include/aljtg/buysubmit.php';
		}else{
			require_once 'source/plugin/aljgwc/include/buysubmit.php';
		}
	}
} else if ($_GET['act'] == 'mesgroupon') {
	$orderid = addslashes($_GET['orderid']);
	$order=C::t('#aljgwc#aljbd_goods_order')->fetch($orderid);
	if(empty($order)){
		showmessage(lang('plugin/aljtg','m1'));
	}
	if(file_exists("source/plugin/aljtg/include/mes.php")){
        require_once 'source/plugin/aljtg/include/mes.php';
	}
	$num = DB::result_first('select count(*) from %t where orderid = %s',array('aljtg_meslog',$_GET['orderid']));
	$tips = lang('plugin/aljtg','m2').$_G['cache']['plugin']['aljtg']['most'].lang('plugin/aljtg','m3');
	if($num >= $_G['cache']['plugin']['aljtg']['most']){
		showmessage($tips);
	}

	if(file_exists('source/plugin/aljtg/com/mes.php') && $num < $_G['cache']['plugin']['aljtg']['most']){
		include 'source/plugin/aljtg/com/mes.php';
		$user = unserialize($order['address']);
		$groupon = DB::fetch_first('select * from %t where orderid = %s',array('aljtg_groupon',$order['orderid']));
		//$good = C::t('#aljtg#aljtg_goods') -> fetch($order['sid']);
		if($_G['cache']['plugin']['aljtg']['tobrand'] && file_exists('source/plugin/aljbd/aljbd.inc.php')){
			$bd = C::t('#aljbd#aljbd') -> fetch($order['shop_id']);
			if(!$bd){
				$bd = C::t('#aljtg#aljtg') -> fetch($order['shop_id']);
			}
		}else{
			$bd = C::t('#aljtg#aljtg') -> fetch($order['shop_id']);
		}
		$config['desc'] = str_replace('{tel}',$bd['tel'],$_G['cache']['plugin']['aljtg']['desc']);
		$desc = g2u($config['desc']);
		$first = g2u($_G['cache']['plugin']['aljtg']['first']);
		$stitle = g2u($order['stitle']);
		$groupon = $groupon['groupon'].' '.$groupon['password'];
		$result = mespost($_G['cache']['plugin']['aljtg']['app_id'],$_G['cache']['plugin']['aljtg']['app_secret'],$user['mobile'],$_G['cache']['plugin']['aljtg']['template_id'],$stitle,$groupon,$desc,$first);
		$result = json_decode($result,true);
		//debug($result);
		C::t('#aljtg#aljtg_meslog') -> insert(array(
			'uid' => $_G['uid'],
			'orderid' => $_GET['orderid'],
			'dateline' => TIMESTAMP,
			'tel' => $user['mobile'],
			'status' => $result['res_code'],
		));
		if($result['res_message'] == 'Success'){
			showmessage(lang('plugin/aljtg','m4'),'plugin.php?id=aljtg:member&act=orderlist');
		}else{
			debug(u2g($result['res_message']));
		}
	}

}else if($_GET['act'] == 'logistics_details'){
	$navtitle = lang('plugin/aljgwc','aljgwc_inc_php_1');
    include template('aljgwc:logistics_details');
}else if($_GET['act'] == 'wuliu'){
	$orderid = addslashes($_GET['orderid']);
	$order=C::t('#aljgwc#aljbd_goods_order')->fetch($orderid);
	if(submitcheck('wuliusubmit')) {
	    if(!$_GET['worderid']){
	        showmessage('&#29289;&#27969;&#21333;&#21495;&#24517;&#39035;&#22635;&#20889;');
        }
        if(!$_GET['companyname']){
            showmessage('&#29289;&#27969;&#21517;&#31216;&#24517;&#39035;&#22635;&#20889;');
        }
		C::t('#'.$pluginid.'#'.$pluginid.'_wuliu')->insert(array(
			'orderid' => $_GET['orderid'],
			'type' => 1,
			'companyname' => $_GET['companyname'],
			'worderid' => $_GET['worderid'],
			'dateline' => TIMESTAMP,
		));

		if(!$order['d'] && $order['payment'] == '2'){
			$order['transaction_id'] = $order['buyer'];
			$order['invoice_no'] = $_GET['worderid'];
			$order['logistics_name'] = diconv($_GET['companyname'],CHARSET,'gbk');
			$order['express'] = diconv($_GET['c'],CHARSET,'gbk');
			alipaysend($order);

		}else{
			C::t('#aljgwc#aljbd_goods_order')->update_status_by_orderid($_GET['orderid']);
			if($is_aljdx){
				$oaddress = unserialize($order['address']);
                $orderidau = $_G['cache']['plugin']['aljbd']['is_dx_var'] ? 'orderidau' : 'orderid_au';
                $username_au = $_G['cache']['plugin']['aljbd']['is_dx_var'] ? 'usernameau' : 'username_au';
				if(preg_match('#^\d[\d-]{3,20}\d$#', $oaddress['mobile'])){
					sendsmsbyvar($oaddress['mobile'],'aljbd','fahuo',array($username_au =>$order['username'] ,$orderidau => $_G['cache']['plugin']['aljbd']['is_dx_order']?'**'.substr($order['orderid'],-4):$order['orderid']));
				}
			}
			//$order = C::t('#aljbd#aljbd_order')->fetch($_GET['orderid']);
			$shop_order=C::t('#aljgwc#aljbd_goods_order_list')->fetch_all_by_orderid($_GET['orderid']);
            require_once libfile('function/mail');
			foreach($shop_order as $key => $val){
				notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="'.str_replace(array('{bid}','{goods_id}'),array($val['shop_id'],$val['goods_id']),$ggurl).'">'.$val['name'].'</a>',$_G['cache']['plugin'][$pluginid]['fahuotips'])));
				if($_G['cache']['plugin'][$pluginid]['time']){
					$email_first=C::t("common_member")->fetch($order['uid']);
					$email=$email_first['email'];

					if($email_first['email']){
						$m=str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="'.str_replace(array('{bid}','{goods_id}'),array($val['shop_id'],$val['goods_id']),$ggurl).'">'.$val['name'].'</a>',$_G['cache']['plugin'][$pluginid]['fahuotips']));
                        sendmail_cron($email,$_G['cache']['plugin'][$pluginid]['mailtitle'],$m);
					}
				}
			}
			if(file_exists('source/plugin/aljbdx/include/fahuo.php')){
                require_once 'source/plugin/aljbdx/include/fahuo.php';
			}
		}
		showmessage(lang('plugin/aljbd','tg44'), $orderlisturl.'&ord='.$_GET['ord']);
	}else{
		include template('aljgwc:wuliu');
	}
}else if($_GET['act']=='receipt'){
	$order = C::t('#aljgwc#aljbd_goods_order') -> fetch($_GET['orderid']);
	if($order['uid'] == $_G['uid']){
		DB::query("update %t set status=4 where orderid = %s",array('aljbd_goods_order',$_GET['orderid']));
        if(file_exists("source/plugin/dz_1/dz_1.inc.php")){
            require_once 'source/plugin/dz_1/include/receipt.php';
        }
	}
	showmessage('&#30830;&#35748;&#25910;&#36135;&#25104;&#21151;',$orderlisturl.'&ord='.$_GET['ord']);
}else if($_GET['act']=='deleteorder'){

	if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){

		$order = C::t('#aljgwc#aljbd_goods_order') -> fetch($_GET['orderid']);
		if(submitcheck('formhash')){

			if($_GET['orderid']){

				if($order['uid'] == $_G['uid'] || in_array($_G['groupid'],$admingroups)){
					C::t('#aljgwc#aljbd_goods_order') -> delete($_GET['orderid']);
				}
			}
			if($pid == 2 && $pluginid == 'aljsc'){
				showmessage('&#25805;&#20316;&#25104;&#21151;&#65281;','plugin.php?id=aljgwc&act=orderlist'.$biaoshi);
			}else{
				showmessage('&#25805;&#20316;&#25104;&#21151;&#65281;',$orderlisturl);
			}
		}else{

			$url='plugin.php?id=aljgwc&act=deleteorder&orderid='.$order['orderid'].$biaoshi;
			include template('aljgwc:state');
		}
	}else{
		if($_GET['orderid'] && $_GET['formhash'] == FORMHASH){
			$order = C::t('#aljgwc#aljbd_goods_order') -> fetch($_GET['orderid']);
			if($order['uid'] == $_G['uid'] || in_array($_G['groupid'],$admingroups)){
				C::t('#aljgwc#aljbd_goods_order') -> delete($_GET['orderid']);
			}

		}
		if($pid == 2 && $pluginid == 'aljsc'){
				showmessage('&#25805;&#20316;&#25104;&#21151;&#65281;','plugin.php?id=aljgwc&act=orderlist'.$biaoshi);
			}else{
				showmessage('&#25805;&#20316;&#25104;&#21151;&#65281;',$orderlisturl);
			}
	}
}else if($_GET['act']=='canorder'){

    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){

        $order = C::t('#aljgwc#aljbd_goods_order') -> fetch($_GET['orderid']);
        if(submitcheck('formhash')){

            if($_GET['orderid']){

                if($order['uid'] == $_G['uid'] || in_array($_G['groupid'],$admingroups)){
                    DB::query("update %t set status=7 where orderid = %s",array('aljbd_goods_order',$_GET['orderid']));
                }
            }
            if($pid == 2 && $pluginid == 'aljsc'){
                showmessage('&#25805;&#20316;&#25104;&#21151;&#65281;','plugin.php?id=aljgwc&act=orderlist'.$biaoshi);
            }else{
                showmessage('&#25805;&#20316;&#25104;&#21151;&#65281;',$orderlisturl);
            }
        }else{

            $url='plugin.php?id=aljgwc&act=canorder&orderid='.$order['orderid'].$biaoshi;
            include template('aljgwc:state');
        }
    }else{
        if($_GET['orderid'] && $_GET['formhash'] == FORMHASH){
            $order = C::t('#aljgwc#aljbd_goods_order') -> fetch($_GET['orderid']);
            if($order['uid'] == $_G['uid'] || in_array($_G['groupid'],$admingroups)){
                C::t('#aljgwc#aljbd_goods_order') -> delete($_GET['orderid']);
            }

        }
        if($pid == 2 && $pluginid == 'aljsc'){
            showmessage('&#25805;&#20316;&#25104;&#21151;&#65281;','plugin.php?id=aljgwc&act=orderlist'.$biaoshi);
        }else{
            showmessage('&#25805;&#20316;&#25104;&#21151;&#65281;',$orderlisturl);
        }
    }
}else if($_GET['act'] == 'settlelist'){
	if(TIMESTAMP > getcookie('aljtg_request')+$_G['cache']['plugin']['aljgwc']['aljtg_cache_time']){
		dsetcookie('aljtg_request',TIMESTAMP);
		$request = 1;
	}else{
		$request = 0;
	}
	$page = intval($_GET['page']);
	$currpage = $page?$page:1;
	$perpage = 10;
	$start = ($currpage-1)*$perpage;
	if(in_array($_G['groupid'],$admingroups)){
		$num = DB::result_first('select count(*) from %t',array('aljbd_goods_settle'));
		$settlelist = DB::fetch_all('select * from %t order by applytime desc limit %d,%d',array('aljbd_goods_settle',$start,$perpage));
	}else{
		$num = DB::result_first('select count(*) from %t where uid = %d',array('aljbd_goods_settle',$_G['uid']));
		$settlelist = DB::fetch_all('select * from %t where uid = %d order by applytime desc limit %d,%d',array('aljbd_goods_settle',$_G['uid'],$start,$perpage));
	}
	$statistics = DB::fetch_first('SELECT * FROM %t WHERE uid=%d and pid=1',array('aljgwc_statistics',$_G['uid']));
	$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljgwc&act=settlelist', 0, 11, false, false);
	include template('aljgwc:aljtg/settlelist');
}else if($_GET['act'] == 'sales'){
	if($_G['cache']['plugin']['aljtg']['tobrand'] && file_exists('source/plugin/aljbd/aljbd.inc.php')){
		$bids_bd = DB::fetch_all('select id from %t where uid = %d',array('aljbd',$_G['uid']));
		$bids_tg = DB::fetch_all('select id from %t where uid = %d',array('aljtg',$_G['uid']));
		$bids = array_merge($bids_bd, $bids_tg);
	}else{
		$bids = DB::fetch_all('select id from %t where uid = %d',array('aljtg',$_G['uid']));
	}
	//$bids = DB::fetch_all('select id from %t where uid = %d',array('aljbd',$_G['uid']));

	foreach($bids as $bid){
		$ids[] = $bid['id'];
	}

	$bids = implode(',',$ids);
	$total = sprintf("%.2f",DB::result_first('select sum(price) from %t where status >= 2 and status<6 and pid=1 and shop_id in(%i)',array('aljbd_goods_order',$bids)));//������
	$withdrawals = sprintf("%.2f",DB::result_first('select sum(settleprice) from %t where uid = %d  and pid=1 and status = 1 group by uid',array('aljbd_goods_settle',$_G['uid'])));//�����ܶ�
	$balance = sprintf("%.2f",$total* (1-$_G['cache']['plugin']['aljtg']['per'])-$withdrawals);
	$expose_detail = array(
		'total' => $total,
		'withdrawals' => $withdrawals,
		'balance' => $balance
	);
	$expose_detail_all = array(
		'total' => $total,
		'withdrawals' => $withdrawals,
		'balance' => $balance,
		'uid' => $_G['uid'],
		'username' => $_G['username'],
		'pid' => 1,
	);
	$res = DB::result_first('SELECT id FROM %t WHERE uid=%d and pid=1',array('aljgwc_statistics',$_G['uid']));
	if($res){
		$expose_detail_all['updatetime'] = TIMESTAMP;
		C::t('#aljgwc#aljgwc_statistics')->update($res,$expose_detail_all);
	}else{
		$expose_detail_all['addtime'] = TIMESTAMP;
		$expose_detail_all['updatetime'] = TIMESTAMP;
		$insertid = C::t('#aljgwc#aljgwc_statistics')->insert($expose_detail_all,true);
	}
	echo json_encode($expose_detail);
	exit;
}else if($_GET['act'] == 'settle'){
	$settle = DB::fetch_first('SELECT * FROM %t WHERE uid=%d and pid=1',array('aljgwc_statistics',$_G['uid']));
	if (submitcheck('formhash')){
		if ($settle['balance'] < $_G['cache']['plugin']['aljtg']['min']) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljtg','tg32')."','');</script>";
				exit;
			}else{
                echo '<script>parent.showDialog("'.lang('plugin/aljtg','tg32').'","")</script>';
                exit;

			}
		}
		$settleid = dgmdate(TIMESTAMP, 'YmdHis').random(18);
		C::t('#aljgwc#aljbd_goods_settle') -> insert(array(
			'uid' => $_G['uid'],
			'settleid' => $settleid,
			'settleprice' => $_GET['settleprice'],
			'username' => $_GET['username'],
			'account' => $_GET['account'],
			'payment' => 1,
			'status' => 0,
			'applytime' => TIMESTAMP,
			'name' => $_G['username'],
			'pid' => 1,
		));

		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".lang('plugin/aljbd','tg33')."',function(){parent.location.href='plugin.php?id=aljgwc&act=settlelist".$biaoshi."';});</script>";
			exit;
		}else{
			echo '<script>parent.showDialog("'.lang('plugin/aljtg','tg33').'","right","",function(){parent.location.href="plugin.php?id=aljgwc&act=settlelist'.$biaoshi.'";})</script>';
			exit;
		}
	} else{
		include template('aljgwc:aljtg/settle');
	}
} else if($act == 'editsettle'){
	$settleid = htmlspecialchars($_GET['settleid']);
	$statistics = DB::fetch_first('SELECT * FROM %t WHERE uid=%d and pid=1',array('aljgwc_statistics',$_G['uid']));
	if (submitcheck('formhash')){
		if (empty($settleid)) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljtg','tg34')."','');</script>";
				exit;
			}else{
				echo '<script>parent.showDialog("'.lang('plugin/aljtg','tg34').'","")</script>';
				exit;
			}
		}
		$settle = C::t('#aljgwc#aljbd_goods_settle') -> fetch($_GET['settleid']);
		if ($settle['uid'] != $_G['uid'] && !in_array($_G['groupid'],$admingroups)) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljtg','tg35')."','');</script>";
				exit;
			}else{
				echo '<script>parent.showDialog("'.lang('plugin/aljtg','tg35').'","")</script>';
				exit;
			}
		}
		if ($settle['status'] != 0) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljtg','tg36')."','');</script>";
				exit;
			}else{
				echo '<script>parent.showDialog("'.lang('plugin/aljtg','tg36').'","")</script>';
				exit;
			}
		}
		if ($statistics['balance'] < $config['min']) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljtg','tg37')."','');</script>";
				exit;
			}else{
				echo '<script>parent.showDialog("'.lang('plugin/aljtg','tg33').'","")</script>';
				exit;
			}
		}
		C::t('#aljtg#aljtg_settle') -> update($_GET['settleid'],array(
			'settleprice' => $_GET['settleprice'],
			'username' => $_GET['username'],
			'account' => $_GET['account'],
			'payment' => 1,
			'status' => 0,
			'applytime' => TIMESTAMP,
		));

		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".lang('plugin/aljtg','tg33')."',function(){parent.location.href='plugin.php?id=aljgwc&act=settlelist".$biaoshi."';});</script>";
			exit;
		}else{
			echo '<script>parent.showDialog("'.lang('plugin/aljtg','tg33').'","right","",function(){parent.location.href="plugin.php?id=aljgwc&act=settlelist'.$biaoshi.'";})</script>';
			exit;
		}
	} else{
		if (empty($settleid)){
			showmessage(lang('plugin/aljtg','tg39'));
		}
		$settle = C::t('#aljgwc#aljbd_goods_settle') -> fetch($_GET['settleid']);
		if ($settle['uid'] != $_G['uid'] && !in_array($_G['groupid'],$admingroups)) {
			showmessage(lang('plugin/aljtg','tg40'));
			exit;
		}
		$settle['balance'] = $statistics['balance'];
		include template('aljgwc:aljtg/settle');
	}
} else if($act == 'deletesettle'){
	if (!in_array($_G['groupid'],$admingroups)){
		showmessage(lang('plugin/aljtg','tg41'));
	}
	if ($_GET['settleid']){
		C::t('#aljgwc#aljbd_goods_settle') -> delete($_GET['settleid']);
	}
	showmessage(lang('plugin/aljtg','tg42'),'plugin.php?id=aljgwc&act=settlelist'.$biaoshi);
} else if($act == 'agreesettle'){
	if (!in_array($_G['groupid'],$admingroups)){
		showmessage(lang('plugin/aljtg','tg43'));
	}
	if ($_GET['settleid']){
		DB::query('update %t set status = 1,dateline = %d where settleid = %s and pid=1',array('aljbd_goods_settle',TIMESTAMP,$_GET['settleid']));
		dsetcookie('aljtg_request','');
	}
	showmessage(lang('plugin/aljtg','tg44'),'plugin.php?id=aljgwc&act=settlelist'.$biaoshi);
} else if($act == 'disagreesettle'){
	if (!in_array($_G['groupid'],$admingroups)){
		showmessage(lang('plugin/aljtg','tg45'));
	}
	if ($_GET['settleid']){
		DB::query('update %t set status = 2,dateline = %d where settleid = %s and pid=1',array('aljbd_goods_settle',TIMESTAMP,$_GET['settleid']));
	}
	showmessage(lang('plugin/aljtg','tg46'),'plugin.php?id=aljgwc&act=settlelist'.$biaoshi);
}elseif($_GET['act'] == 'addresslist'){

	if(submitcheck('formhash')) {
		if(empty($_GET['region'])){
			showmessage($alj_lang['Area_must_choose']);
		}
		if(empty($_GET['addressDetail'])){
			showmessage($alj_lang['Details_must_be_filled_in']);
		}
		if(empty($_GET['fullName'])){
			showmessage($alj_lang['Name_must_be_filled_in']);
		}
		if(empty($_GET['mobile_p']) && empty($_GET['phoneCode'])){
			showmessage($alj_lang['Mobile_phone_number_must_be_filled_in']);
		}
		$insertarray = array(
			'region' => $_GET['region'],
			'region1' => $_GET['subregion'],
			'region2' => $_GET['region1'],
			'addressDetail' => $_GET['addressDetail'],
			'post' => $_GET['post'],
			'fullName' => $_GET['fullName'],
			'mobile' => $_GET['mobile_p'],
			'phoneSection' => $_GET['phoneSection'],
			'phoneCode' => $_GET['phoneCode'],
			'phoneExt' => $_GET['phoneExt'],
			'defaultAddress' => $_GET['defaultAddress'],
			'dateline' => TIMESTAMP,
			'uid' => $_G['uid'],
			'username' => $_G['username'],
		);
		if($_GET['defaultAddress']){
			C::t('#aljgwc#aljbd_address')->update_by_uid_defaultAddress($_G['uid']);
		}
		if($address){
			if($address['uid'] != $_G['uid']){
				showmessage($alj_lang['Unauthorized_operation']);
			}
			C::t('#aljgwc#aljbd_address')->update($address_id,$insertarray);
		}else{
			if($address_num >20){
				showmessage($alj_lang['Up_to_20']);
			}
			C::t('#aljgwc#aljbd_address')->insert($insertarray);
		}
		showmessage($alj_lang['Single_success'],'plugin.php?id=aljgwc&act=addresslist&pluginid='.$pluginid, array(), array('header' => true));
	}else{
		$num_goods = intval($_GET['num']);
		$attrs = $_GET['attrs'];
		$attrsid = $_GET['attrsid'];
		$rlist = C::t('#aljgwc#aljgwc_region')->fetch_all_by_upid();

		$addrlist = C::t('#aljgwc#aljbd_address')->fetch_all_by_uid($_G['uid']);
		$navtitle = $alj_lang['Address_management'];
        if($newtemplate) {
            include template($common_template_pluginid.':new/list/addresslist');
        }else{
            include template('aljgwc:addresslist');
		}
	}
}elseif($_GET['act'] == 'deladdress'){
	if($address['uid'] != $_G['uid'] && $_GET['formhash'] != FORMHASH){
		showmessage($alj_lang['Unauthorized_operation']);
	}
	C::t('#aljgwc#aljbd_address')->delete($address_id);
	showmessage($alj_lang['Delete_success'],'plugin.php?id=aljgwc&act=addresslist&pluginid='.$pluginid);
}elseif($_GET['act'] == 'updateaddress'){
	if($address['uid'] != $_G['uid'] && $_GET['formhash'] != FORMHASH){
		showmessage($alj_lang['Unauthorized_operation']);
	}
	C::t('#aljgwc#aljbd_address')->update_by_uid_defaultAddress($_G['uid']);
	DB::query("update %t set defaultAddress=1 where id = %d",array('aljbd_address',$address_id));
	showmessage($alj_lang['Update_success'],'plugin.php?id=aljgwc&act=addresslist&pluginid='.$pluginid);
}else if($_GET['act'] == 'editaddress'){
	if(submitcheck('formhash')) {
		if(empty($_GET['region'])){
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('".$alj_lang['Area_must_choose']."','');</script>";
                exit;
            }else {
                showmessage($alj_lang['Area_must_choose']);
            }
		}
		if(empty($_GET['addressDetail'])){
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('".$alj_lang['Details_must_be_filled_in']."','');</script>";
                exit;
            }else {
                showmessage($alj_lang['Details_must_be_filled_in']);
            }
		}
		if(empty($_GET['fullName'])){
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('".$alj_lang['Name_must_be_filled_in']."','');</script>";
                exit;
            }else {
                showmessage($alj_lang['Name_must_be_filled_in']);
            }
		}
		if(empty($_GET['mobile_p']) && empty($_GET['phoneCode'])){
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('".$alj_lang['Mobile_phone_number_must_be_filled_in']."','');</script>";
                exit;
            }else {
                showmessage($alj_lang['Mobile_phone_number_must_be_filled_in']);
            }
		}
		$insertarray = array(
			'region' => $_GET['region'],
			'region1' => $_GET['subregion'],
			'region2' => $_GET['region1'],
			'addressDetail' => $_GET['addressDetail'],
			'post' => $_GET['post'],
			'fullName' => $_GET['fullName'],
			'mobile' => $_GET['mobile_p'],
			'phoneSection' => $_GET['phoneSection'],
			'phoneCode' => $_GET['phoneCode'],
			'phoneExt' => $_GET['phoneExt'],
			'defaultAddress' => $_GET['defaultAddress'],
			'dateline' => TIMESTAMP,
			'uid' => $_G['uid'],
			'username' => $_G['username'],
		);
		if($_GET['defaultAddress']){
			C::t('#aljgwc#aljbd_address')->update_by_uid_defaultAddress($_G['uid']);
		}
		if($address){
			if($address['uid'] != $_G['uid']){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('".$alj_lang['Unauthorized_operation']."','');</script>";
                    exit;
                }else {
                    showmessage($alj_lang['Unauthorized_operation']);
                }
			}
			C::t('#aljgwc#aljbd_address')->update($address_id,$insertarray);
		}else{
			if($address_num >20){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('".$alj_lang['Up_to_20']."','');</script>";
                    exit;
                }else {
                    showmessage($alj_lang['Up_to_20']);
                }
			}
			$address_id = C::t('#aljgwc#aljbd_address')->insert($insertarray,true);
		}
		if(empty($s_id) && empty($goods_id)){
			$heaurl = 'plugin.php?id=aljgwc&act=addresslist'.$biaoshi;
		}else{
			$attrs = $_GET['attrs'];
			$attrsid = $_GET['attrsid'];
			$num_goods = intval($_GET['num']);
			$tiaojianurl = '&commodity_type='.intval($_GET['commodity_type']).'&grouporderid='.$_GET['grouporderid'];
			if($s_id){
				$heaurl = 'plugin.php?id=aljgwc&pluginid='.$pluginid.'&shop_id='.$s_id.'&address_id='.$address_id;
			}else{
				$heaurl = 'plugin.php?id=aljgwc&pluginid='.$pluginid.'&act=buy&goods_id='.$goods_id.'&address_id='.$address_id.'&num='.$num_goods.'&attrs='.$attrs.'&attrsid='.$attrsid.$tiaojianurl;
			}
		}
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.location.href='" . $heaurl . "'</script>";
			exit;
        }else {
            showmessage($alj_lang['Single_success'], $heaurl, array(), array('header' => true));
        }
	}else{
		$attrs = $_GET['attrs'];
		$attrsid = $_GET['attrsid'];
		$num_goods = intval($_GET['num']);

		if($address){
			$navtitle = $alj_lang['Edit_address'];
		}else{
			$navtitle = $alj_lang['Add_address'];
		}
        if($newtemplate) {
            $json_regionlist = C::t('#aljgwc#aljgwc_region')->fetch_all_json();
            $cityjson = json_encode($json_regionlist);
            if($address['region']){
                $region = $address['region'];
                $subregion = $address['region1'];
                $region1 = $address['region2'];
                $default = $regionlist[$address['region']]['name'].' '. $regionlist[$address['region1']]['name'].' '.$regionlist[$address['region2']]['name'];
            }else{
                $region = $json_regionlist[0]['code'];
                $subregion = $json_regionlist[0]['sub'][0]['code'];
                $region1 = $json_regionlist[0]['sub'][0]['sub'][0]['code'];
                $default = diconv($json_regionlist[0]['name'].' '. $json_regionlist[0]['sub'][0]['name'].' '.$json_regionlist[0]['sub'][0]['sub'][0]['name'], 'utf-8', CHARSET);
            }
            include template($common_template_pluginid.':new/post/editaddress');
        }else {
            $rlist = C::t('#aljgwc#aljgwc_region')->fetch_all_by_upid();
            include template('aljgwc:editaddress');
        }
	}
}else if($_GET['act']=='getregion'){

	if($_GET['upid']){
		$rlist=C::t('#aljgwc#aljgwc_region')->fetch_all_by_upid($_GET['upid']);
	}

	include template('aljgwc:getregion');
}else if($_GET['act']=='getregion1'){
	if($_GET['upid']){

		$rlist=C::t('#aljgwc#aljgwc_region')->fetch_all_by_upid($_GET['upid']);
	}

	include template('aljgwc:getregion1');
} else if ($act == 'comment') {
	$gid = intval($_GET['gid']);
	if($_GET['formhash'] == FORMHASH) {
		if(empty($gid)){
			echo 0;
			exit;
		}
		$good = C::t('#aljbd#aljbd_goods')->fetch($_GET['gid']);
		$content = diconv($_GET['content'], 'UTF-8', CHARSET);
		$orderid = $_GET['orderid'];
		$overall_ticket = intval($_GET['overall_ticket']);
		$descriptiongrade = intval($_GET['descriptiongrade']);
		$environmentgrade = intval($_GET['environmentgrade']);
		$attitudegrade = intval($_GET['attitudegrade']);
		$deliveryspeed = intval($_GET['deliveryspeed']);

		if(empty($orderid) || empty($content) || empty($overall_ticket) || empty($descriptiongrade) ||  empty($deliveryspeed)){
			echo 0;
			exit;
		}
		$check = DB::result_first('select count(*) from %t where orderid=%s and uid=%d',array('aljbd_goods_order',$orderid,$_G['uid']));

		if(empty($check) && $_G['groupid'] !=1 ){
			echo 0;
			exit;
		}
		$check = DB::result_first('select count(*) from %t where gid=%d and orderid=%s',array('aljbd_comment_goods',$gid,$orderid));
		if($check){
			echo 0;
			exit;
		}
		C::t('#aljgwc#aljbd_comment_goods')->insert(array(
			'uid' => $_G['uid'],
			'username' => $_G['username'],
			'gid' => $gid,
			'bid' => $good['bid'],
			'orderid' => $orderid,
			'content' => $content,
			'overall_ticket' => $overall_ticket,
			'descriptiongrade' => $descriptiongrade,
			'environmentgrade' => $environmentgrade,
			'attitudegrade' => $attitudegrade,
			'deliveryspeed' => $deliveryspeed,
			'displayorder' => 1,
			'dateline' => TIMESTAMP,
		));
		DB::query('update %t set status = 5 where orderid = %s',array('aljbd_goods_order',$orderid));
		echo 1;
	}else{
		if(empty($gid)){
			showmessage($aljgwclang['php']['Commodity_does_not_exist']);
		}
		$good = C::t('#aljbd#aljbd_goods') -> fetch($gid);
		$navtitle = $aljgwclang['php']['Comment_commodity'];
		include template('aljgwc:comment');
	}
}else if($_GET['act']=='greply'){
	if(submitcheck('formhash')){

		if(empty($_GET['commentmessage_1'])){
			if($_G['mobile']){
				echo "<script>parent.tips('".lang('plugin/aljbd','s35')."','');</script>";
				exit;
			}else{
				echo "<script>parent.showDialog('".lang('plugin/aljbd','s35')."','right','','');</script>";
				exit;
			}
		}
		if(empty($_G['uid'])){
			echo "<script>parent.showDialog('".lang('plugin/aljbd','s21')."','right','','');</script>";
		}
		$ucom = C::t('#aljgwc#aljbd_comment_goods')->fetch($_GET['upid']);
		if($_GET['uuid'] && $_GET['uusername']){
            $ucom['uid'] = $_GET['uuid'];
            $ucom['username'] = $_GET['uusername'];
		}else{
            if($ucom['uid'] == $_G['uid']){
                if($_G['mobile']){
                    echo "<script>parent.tips('".$aljgwclang['php']['Can_not_comment']."','');</script>";
                    exit;
                }else{
                    echo "<script>parent.showDialog('".$aljgwclang['php']['Can_not_comment']."','right','','');</script>";
                    exit;
                }
            }
		}
		$insertarray=array(
			'uid'=>$_G['uid'],
			'username'=>$_G['username'],
			'content'=>$_GET['commentmessage_1'],
			'gid'=>$_GET['gid'],
			'dateline'=>TIMESTAMP,
			'upid'=>$_GET['upid'],
			'uusername'=>$ucom['username'],
			'uuid'=>$ucom['uid'],
			'subcatid'=>$_GET['subcatid'],
			'bid'=>$_GET['bid'],
		);
		$insertid = C::t('#aljgwc#aljbd_comment_goods')->insert($insertarray,true);
		if($_G['mobile']){
			echo "<script>parent.tips('".lang('plugin/aljbd','s36')."',function(){parent.location.href=parent.location.href;});</script>";
			exit;
		}else{
			echo "<script>parent.showDialog('".lang('plugin/aljbd','s36')."','right','',function(){parent.location.href=parent.location.href;});</script>";
			exit;
		}
	}
}else if($_GET['act']=='orderlist'){
	//$regionlist=C::t('#aljbd#aljbd_region')->range();
	$search_url = "plugin.php?id=aljgwc&act=orderlist".$biaoshi."&keyword=";
	$page = intval($_GET['page']);
	$currpage = $page?$page:1;
	$perpage = 10;
	$start = ($currpage-1)*$perpage;
	$groups = unserialize($_G['cache']['plugin']['aljsc']['groups']);

	$conn[] ='aljbd_goods_order';
	$where = 'where 1 and pid = 2 ';
	if(!in_array($_G['groupid'],$groups)){
		$uid = intval($_G['uid']);
		$where .= 'and uid = %d ';
		$conn[] = $uid;
	}
	if($_GET['status']){

		$status = intval($_GET['status']);
		$where .= 'and status = %d';
		$conn[] = $status;
	}
	if($_GET['keyword']){
		$keyword = stripsearchkey($_GET['keyword']);
		$keyword = '%'.$keyword.'%';
		$where .= ' and (orderid like %s or stitle like %s)';
		$conn[] = $keyword;
		$conn[] = $keyword;
	}

	$num = DB::result_first('select count(*) from %t '.$where,$conn);
	$start=($currpage-1)*$perpage;
	$where .= ' order by submitdate desc';
	$where .= ' limit %d,%d';
	$conn[] = $start;
	$conn[] = $perpage;

	$orderlist = DB::fetch_all('select * from %t '.$where,$conn);



	$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljgwc&act=orderlist&status='.$_GET['status'].'&keyword='.$_GET['keyword'].$biaoshi, 0, 11, false, false);
	include template('aljgwc:aljsc/orderlist');
}elseif($_GET['act'] == 'refund'){
	if(empty($_G['uid'])){
		dheader("location:".$login_callback);
	}
	$orderid = addslashes($_GET['orderid']);
	$shop_id = intval($_GET['shop_id']);
	if($pid==2){
		$shops['uid'] = 1;
	}else{
		$shops=C::t('#'.$pluginid.'#'.$pluginid)->fetch($shop_id);
	}
	if(submitcheck('formhash')){
		$order = C::t('#aljgwc#aljbd_goods_order') -> fetch($orderid);
		if(!$order){
			echo "<script>parent.tips('".$aljgwclang['php']['Order_does_not_exist']."');</script>";
			exit;
		}
        if($order['status']>3 || $order['status']<2){
            echo "<script>parent.tips('&#35813;&#35746;&#21333;&#19981;&#20801;&#35768;&#36864;&#27454;');</script>";
            exit;
        }
		if($order['uid'] != $_G['uid']){
			echo "<script>parent.tips('".$aljgwclang['php']['Unauthorized_operation']."');</script>";
			exit;
		}
		if(empty($_GET['refund_type'])){
			echo "<script>parent.tips('".$aljgwclang['php']['Type_must_be_selected']."');</script>";
			exit;
		}
		if(empty($_GET['content'])){
			echo "<script>parent.tips('".$aljgwclang['php']['Description_must_be_completed']."');</script>";
			exit;
		}
		$imagesarray = explode(',',$_GET['images']);

		if(count($imagesarray) > 5){
			if($_G['mobile']){
				echo "<script>parent.tips('".$aljgwclang['php']['At_least_two']."','');</script>";
				exit;
			}else{
				echo "<script>parent.tips('".$aljgwclang['php']['At_least_two']."','');</script>";
				exit;
			}
		}

		foreach($imagesarray as $key => $val){
			if(empty($val)){
				continue;
			}
			$position = 'refund';
			$rand = rand(100, 999);
			$pics = date("YmdHis") . $rand . '.jpg';
			$img_dir = 'source/plugin/aljgwc/images/'.$position.'/'.date('Ymd',TIMESTAMP).'/';
			if (!is_dir($img_dir)) {
				mkdir($img_dir);
			}
			$pic = $img_dir . $pics;


			$logo = file_put_contents($pic,base64_decode($val));

			if($logo){
				$imgs .= $pic.',';
			}
		}
		$insertarray = array(
			'orderid' => $orderid,
			'shop_id' => $shop_id,
			'pid' => $pid,
			'payment' => $order['payment'],
			'price' => $order['price'],
			'goodsname' => $order['stitle'],
			'buyer' => $order['buyer'],
			'uid' => $_G['uid'],
			'guid' => $shops['uid'],
			'username' => $_G['username'],
			'imgs' => trim($imgs,','),
			'content' => $_GET['content'],
			'refund_type' => $_GET['refund_type'],
			'addtime' => TIMESTAMP,
		);
		if(C::t('#aljgwc#aljgwc_refund')->fetch($orderid)){
			echo "<script>parent.tips('".$aljgwclang['php']['Submission_of_application']."',function(){parent.location.href='".$orderlisturl."';});</script>";
			exit;
		}
		C::t('#aljgwc#aljgwc_refund')->insert($insertarray);
        notification_add($shops['uid'],'system',str_replace('{username}',$order['username'],str_replace('{name}',$shops['name'],str_replace('{orderid}',$orderid,$_G['cache']['plugin']['aljgwc']['refund_template']))).' <a href="'.$orderlisturl.'">'.lang('plugin/aljgwc','View_orders').'</a>');

		echo "<script>parent.tips('".$aljgwclang['php']['Submit_successfully']."',function(){parent.location.href='".$orderlisturl."';});</script>";
		exit;

	}else{
		include template('aljgwc:refund');
	}
}else if($_GET['act'] == 'refund_query'){
	$order = C::t('#aljgwc#aljgwc_refund')->fetch($_GET['orderid']);
	if($order['payment'] == 3){
		$senddata_query['mch_id'] = $config['mchid2'];
		$senddata_query['appid'] = $config['appid2'];
		$senddata_query['key'] = $config['key2'];
		$senddata_query['orderid'] = $order['buyer'];
	}else if($order['payment'] == 1){
		$senddata_query['mch_id'] = $config['mchid'];
		$senddata_query['appid'] = $config['appid'];
		$senddata_query['key'] = $config['key'];
		$senddata_query['orderid'] = $order['buyer'];
	}
	$senddata_query['location'] = $config['pem_location'];
	$wxrefundquery = wxpayrefundquery($senddata_query);
	$data_query = xmlToArray($wxrefundquery);
	if(strtolower(CHARSET) == 'gbk'){
		$data_query['refund_recv_accout_0'] = diconv($data_query['refund_recv_accout_0'],'utf-8','gbk');
	}
	//debug($data_query);
	echo '<script type="text/javascript">parent.alert("'.$data_query['refund_recv_accout_0'].$data_query['result_code'].'");</script>';
	exit;
	if($data_query['result_code'] == 'SUCCESS'){
		DB::update('aljgwc_refund',array('state'=>3, 'updatetime' => TIMESTAMP),"orderid='".$oid."'");
		C::t('#aljgwc#aljbd_goods_order')->update($oid, array('status' => 6));
	}
}else if($_GET['act'] == 'refund_status'){
	$order = C::t('#aljgwc#aljgwc_refund')->fetch($_GET['orderid']);
	if($order && $_G['groupid'] == 1 && $order['state']<3){
		DB::update('aljgwc_refund',array('state'=>3,'result_details'=>'&#25163;&#21160;', 'updatetime' => TIMESTAMP),"orderid='".$_GET['orderid']."'");
		C::t('#aljgwc#aljbd_goods_order')->update($_GET['orderid'], array('status' => 6));
		DB::query('update %t set refund=refund+%i,balance=balance-%i,dateline=%d where uid=%d and bid=%d',array('aljjs_brandsettle',$order['price'],$order['price'],TIMESTAMP,$order['guid'],$order['shop_id']));
	}
	echo '<script type="text/javascript">parent.alert("\u9000\u6b3e\u6210\u529f");parent.location.href=parent.location.href</script>';
	exit;
}elseif($_GET['act'] == 'refundlist'){
	if(empty($_G['uid'])){
		dheader("location:".$login_callback);
	}
	if(!submitcheck('tsubmit')&&!submitcheck('fsubmit')) {
		$page = intval($_GET['page']);
		$currpage = $page?$page:1;
		$perpage = 30;
		$start = ($currpage-1)*$perpage;
		//$aaa = '2016100721001004820216077829^0.01^SUCCESS#2016100721001004820216408900^0.01^SUCCESS';
		if($_G['groupid'] == 1){

			if(!$_GET['state']){
				$_GET['state'] = 1;
			}

			if($_GET['state'] == 1){
				$con = ' and (state = 1 or state = 0)';
			}elseif($_GET['state'] == 2){
				$con = ' and state = 2';
			}elseif($_GET['state'] == 3){
				$con = ' and state = 3';
			}elseif($_GET['state'] == 4){
				$con = ' and state = 4';
			}
			$num = DB::result_first('select count(*) from %t where 1'.$con,array('aljgwc_refund'));
			$refundlist = DB::fetch_all('select * from %t where 1 '.$con.' limit %d,%d',array('aljgwc_refund',$start,$perpage));
		}else{
			if($_GET['state'] == 1){
				$con = ' and state = 1';
			}elseif($_GET['state'] == 2){
				$con = ' and state = 2';
			}elseif($_GET['state'] == 3){
				$con = ' and state = 3';
			}elseif($_GET['state'] == 4){
				$con = ' and state = 4';
			}else{
				$con = ' and state = 0';
			}
			$num = DB::result_first('select count(*) from %t where guid=%d'.$con,array('aljgwc_refund',$_G['uid']));
			$refundlist = DB::fetch_all('select * from %t where guid=%d '.$con.' limit %d,%d',array('aljgwc_refund',$_G['uid'],$start,$perpage));
		}
		$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljgwc&act=refundlist&state='.$_GET['state'].'&keyword='.$_GET['keyword'].$biaoshi, 0, 11, false, false);

		include template('aljgwc:refundlist');
	}else{
		if(is_array($_POST['check'])) {
			$batch_no = dgmdate(TIMESTAMP,'Ymd').rand(100,99999999);
			$i = 0;
			foreach($_POST['check'] as $oid) {
				$order = C::t('#aljgwc#aljgwc_refund')->fetch($oid);
				//debug($order);
				if($order['payment'] == 3){
					$senddata_query['mch_id'] = $config['mchid2'];
					$senddata_query['appid'] = $config['appid2'];
					$senddata_query['key'] = $config['key2'];
					$senddata_query['orderid'] = $order['buyer'];
					$senddata['out_refund_no'] = $batch_no;
					$senddata['mch_id'] = $config['mchid2'];
					$senddata['appid'] = $config['appid2'];
					$senddata['op_user_id'] = $config['mchid2'];
					$senddata['orderid'] = $order['buyer'];
					$senddata['price'] = $order['price'];
					$senddata['refund_fee'] = $order['price'];
					$senddata['key2'] = $config['key2'];
				}else if($order['payment'] == 1){
					$senddata_query['mch_id'] = $config['mchid'];
					$senddata_query['appid'] = $config['appid'];
					$senddata_query['key'] = $config['key'];
					$senddata_query['orderid'] = $order['buyer'];
					$senddata['out_refund_no'] = $batch_no;
					$senddata['mch_id'] = $config['mchid'];
					$senddata['appid'] = $config['appid'];
					$senddata['op_user_id'] = $config['mchid'];
					$senddata['orderid'] = $order['buyer'];
					$senddata['price'] = $order['price'];
					$senddata['refund_fee'] = $order['price'];
					$senddata['key'] = $config['key'];
				}else{
					$i++;
				}
				$senddata['location'] = $config['pem_location'];
				//debug($senddata);/source/plugin/aljgwc/pay/
				if(($order['state'] == 1 || $order['state'] == 0 || $order['state'] == 2) && $_G['groupid'] == 1){
					if(submitcheck('tsubmit')){
						DB::update('aljgwc_refund',array('state'=>2,'batch_no'=>$batch_no),"orderid='".$oid."'");
						if($order['payment'] == 1 || $order['payment'] == 3){

							$wxrefund = wxpayrefund($senddata);

							$data = xmlToArray($wxrefund);

							if($data['result_code'] == 'SUCCESS'){
								//$wxrefundquery = wxpayrefundquery($senddata_query);
								//$data_query = xmlToArray($wxrefund);
								//if($data_query['return_code'] == 'SUCCESS'){
									DB::update('aljgwc_refund',array('state'=>3, 'updatetime' => TIMESTAMP),"orderid='".$oid."'");
									C::t('#aljgwc#aljbd_goods_order')->update($oid, array('status' => 6));
                                	if(!$pid && $cparray['aljjs']) {
                                        DB::query('update %t set refund=refund+%i,balance=balance-%i,dateline=%d where uid=%d and bid=%d', array('aljjs_brandsettle', $order['price'], $order['price'], TIMESTAMP, $order['guid'], $order['shop_id']));
                                    }
                                    if($pid == 2){
                                        $pay_ext_list = C::t('#aljgwc#aljbd_goods_order')->fetch($oid);
                                        updatemembercount($order['uid'], array($_G['cache']['plugin']['aljsc']['extcredit'] => $pay_ext_list['pay_ext']));
									}
								//}
							}else{
								DB::update('aljgwc_refund',array('state'=>0, 'updatetime' => TIMESTAMP),"orderid='".$oid."'");
                                $error = json_encode($data);
                                if(strtolower(CHARSET) == 'gbk') {
                                    $error = diconv($error,'utf-8','gbk');
                                }
                                insertLog('wxrefund '.$error);
							}
						}else{
							if($order['buyer'] && $order['price']){
								$refundstr .= $order['buyer'].'^'.$order['price'].'^'.'refund#';
							}
						}
					}else{
						DB::update('aljgwc_refund',array('state'=>4),"orderid='".$oid."'");
					}
				}else{
					if($order['state'] == 0){
						if(submitcheck('tsubmit')){
							if($config['refund'] == 'refund_nopwd'){//����
								DB::update('aljgwc_refund',array('state'=>2,'batch_no'=>$batch_no),"orderid='".$oid."'");
								if($order['payment'] == 1 || $order['payment'] == 3){
									//$batch_no = $out_refund_no;

									$wxrefund = wxpayrefund($senddata);
									$data = xmlToArray($wxrefund);
									if($data['result_code'] == 'SUCCESS'){
										//$wxrefundquery = wxpayrefundquery($senddata_query);
										//$data_query = xmlToArray($wxrefund);
										//if($data_query['return_code'] == 'SUCCESS'){
											DB::update('aljgwc_refund',array('state'=>3, 'updatetime' => TIMESTAMP),"orderid='".$oid."'");
											C::t('#aljgwc#aljbd_goods_order')->update($oid, array('status' => 6));
											if(!$pid && $cparray['aljjs']){
                                                DB::query('update %t set refund=refund+%i,balance=balance-%i,dateline=%d where uid=%d and bid=%d',array('aljjs_brandsettle',$order['price'],$order['price'],TIMESTAMP,$order['guid'],$order['shop_id']));
											}
											if($pid == 2){
												$pay_ext_list = C::t('#aljgwc#aljbd_goods_order')->fetch($oid);
												updatemembercount($order['uid'], array($_G['cache']['plugin']['aljsc']['extcredit'] => $pay_ext_list['pay_ext']));
											}
										//}
									}else{
										DB::update('aljgwc_refund',array('state'=>0, 'updatetime' => TIMESTAMP),"orderid='".$oid."'");
                                        $error = json_encode($data);
                                        if(strtolower(CHARSET) == 'gbk') {
                                            $error = diconv($error,'utf-8','gbk');
                                        }
                                        insertLog('wxrefund '.$error);
									}
								}else{
									if($order['buyer'] && $order['price']){
										$refundstr .= $order['buyer'].'^'.$order['price'].'^'.'refund#';
									}
								}
							}else{
								DB::update('aljgwc_refund',array('state'=>1),"orderid='".$oid."'");
							}
						}else{
							DB::update('aljgwc_refund',array('state'=>4),"orderid='".$oid."'");
						}
						//notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$order['sid'].'">'.$order['title'].'</a>',$config['fahuotips'])));
					}
				}
			}
			//debug((trim($refundstr,'#') && $_G['groupid'] == 1) || (trim($refundstr,'#') && $config['refund'] == 'refund_nopwd'));
			if((trim($refundstr,'#') && $_G['groupid'] == 1) || (trim($refundstr,'#') && $config['refund'] == 'refund_nopwd')){
				$refundurl = alipayrefund(array('detail_data'=>trim($refundstr,'#'),'batch_no' => $batch_no,'batch_num' =>$i,'notify_url' => $_G['siteurl'].'/source/plugin/aljgwc/pay/notify_url_refund.php'));
				//debug($refundurl);
				if($config['refund'] == 'refund_pwd' || empty($config['refund'])){
					dheader('Location: '.$refundurl);
				}
				//$data = xmlToArray($refundurl);
			}
		}
		showmessage($aljgwclang['php']['Successful_operation'], 'plugin.php?id=aljgwc&act=refundlist'.$biaoshi);
	}
}elseif($_GET['act'] == 'order_change'){
	if(submitcheck('submit')){
		$order_cart=C::t('#aljgwc#aljbd_goods_order')->fetch($_GET[orderid]);
		if(empty($order_cart) || empty($_GET[orderid]) || empty($_GET['price'])){
			echo '<script>parent.showDialog("&#35746;&#21333;&#19981;&#23384;&#22312;&#25110;&#20215;&#26684;&#38169;&#35823;&#65281;","alert")</script>';
			exit;
		}
		if($pid == 2 && $pluginid == 'aljsc'){
			if(!in_array($_G['groupid'], $groups) || $order_cart[buyer]){
				echo '<script>parent.showDialog("&#26080;&#26435;&#25805;&#20316;","alert")</script>';
				exit;
			}
		}else{
			if($pid == 1 && $pluginid == 'aljtg'){
				if($_G['cache']['plugin']['aljtg']['tobrand'] && file_exists('source/plugin/aljbd/aljbd.inc.php')){
					$bids = DB::fetch_all('select id from %t where uid = %d',array('aljbd',$_G['uid']));
				}else{
					$bids = DB::fetch_all('select id from %t where uid = %d',array('aljtg',$_G['uid']));
				}
			}else{
				$bids = DB::fetch_all('select id from %t where uid = %d',array('aljbd',$_G['uid']));
			}
			foreach($bids as $bid){
				$ids[] = $bid['id'];
			}


			if((!in_array($order_cart[shop_id],$ids) && !in_array($_G['groupid'],$admingroups)) || $order_cart[buyer]){
				echo '<script>parent.showDialog("&#26080;&#26435;&#25805;&#20316;","alert")</script>';
				exit;
			}
		}
		$original_price = floatval($order_cart['original_price']);
		if(empty($original_price)){
			C::t('#aljgwc#aljbd_goods_order')->update($_GET[orderid],array('original_price'=>$order_cart['price']));
		}
		C::t('#aljgwc#aljbd_goods_order')->update($_GET[orderid],array('price'=>$_GET['price']));
		if($order_cart['payment'] == 1 || $order_cart['payment'] == 3){
			$orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
			C::t('#aljgwc#aljbd_goods_order')->update($_GET[orderid],array('orderid'=>$orderid));
			C::t('#aljgwc#aljbd_goods_order_list')->update($_GET[orderid],array('orderid'=>$orderid));
		}
		if($pid == 1){
			$turl = 'plugin.php?id='.$pluginid.':member&act=orderlist';
		}elseif($pid == 2){
			$turl = 'plugin.php?id=aljgwc&act=orderlist&pluginid='.$pluginid;
		}else{
			$turl = 'plugin.php?id='.$pluginid.'&act=orderlist';
		}
		echo '<script>parent.showDialog("&#20462;&#25913;&#25104;&#21151;&#65281;","right","",function(){parent.location.href=\''.$turl.'\'})</script>';
		exit;
	}
}else{

	$query = C::t('#aljgwc#aljgwc')->fetch_all_by_uid($_G['uid'],$_GET['shop_id'],$pid);

	if($pid == 2){//����
		foreach($query as $key => $val){
			$baobei = DB::fetch_first('select * from %t where id=%d',array($pluginid,$val['goods_id']));
			if(empty($baobei) || $baobei['rubbish'] == 1 || $baobei['state'] == 1){
				C::t('#aljgwc#aljgwc')->delete($val['id']);
				$gwcid[] = $val['id'];
			}
			$query[$key]['url'] = str_replace(array('{bid}','{goods_id}'),array($val['shop_id'],$val['goods_id']),$ggurl);

			$query[$key]['pic'] = $baobei['logo'];


		}
		if(count($gwcid)>0){
			echo "<script>location.href=location.href;</script>";
			exit;
		}
		foreach($query as $value) {
			$list[$value['shop_id']][] = $value;
			$count ++;
			$goods_id[] = $value['goods_id'];
			$shop_id[] = $value['shop_id'];
		}

		$goods = C::t('#'.$pluginid.'#'.$pluginid)->fetch_all($goods_id);
		include template('aljgwc:aljsc/cart');
	}else{

		foreach($query as $key => $val){
			$baobei = DB::fetch_first('select * from %t where id=%d',array($pluginid.'_goods',$val['goods_id']));
			if(empty($baobei) || $baobei['rubbish'] == 1 || $baobei['state'] == 1){
				C::t('#aljgwc#aljgwc')->delete($val['id']);
				$gwcid[] = $val['id'];
			}
			$query[$key]['url'] = str_replace(array('{bid}','{goods_id}'),array($val['shop_id'],$val['goods_id']),$ggurl);

			$query[$key]['pic'] = $baobei['pic1'];
			if($pluginid == 'aljbd'){
				$gattrsku = skups($baobei['attr_sku'],$val['path']);

				if($baobei['attr_sku']){

					$query[$key]['price'] = $gattrsku['saleprice'];
					if(empty($gattrsku['saleprice']) || empty($gattrsku['stock'])){
						C::t('#aljgwc#aljgwc')->delete($val['id']);
						$gwcid[] = $val['id'];
					}
				}else{
					$query[$key]['price'] = $baobei['price1'];
				}
			}else{
				$query[$key]['price'] = $baobei['price1'];
			}
		}

		if(count($gwcid)>0){
			echo "<script>location.href=location.href;</script>";
			exit;
		}
		foreach($query as $value) {
			$list[$value['shop_id']][] = $value;
			$count ++;
			$goods_id_arr[] = $value['goods_id'];
			$shop_id[] = $value['shop_id'];
		}

		$goods = C::t('#'.$pluginid.'#'.$pluginid.'_goods')->fetch_all($goods_id_arr);

		$shop  = C::t('#'.$pluginid.'#'.$pluginid)->fetch_all($shop_id);

		if($_GET['shop_id']){
			$tip = ' - &#25552;&#20132;&#35746;&#21333;';
		}
		$navtitle ="&#36141;&#29289;&#36710;".$tip;
        if($pid == 1) {//����
            include template('aljgwc:aljtg/cart');
        }else{
            include template('aljgwc:cart');
        }
	}
}
function g2u($a) {
   return is_array($a) ? array_map('g2u', $a) : diconv($a, CHARSET, 'UTF-8');
}

function u2g($a) {
	return is_array($a) ? array_map('u2g', $a) : diconv($a, 'UTF-8', CHARSET);
}
function skups($attr_sku,$path){
	$attr_sku = unserialize($attr_sku);
	foreach($attr_sku as $k => $v){
		$gattrsku[$v['path']] = $v;
	}
	return array('saleprice'=>$gattrsku[$path]['saleprice'],'stock'=>$gattrsku[$path]['stock']);
}
function skunum($attr_sku,$path,$num,$gid){
	$attr_sku = unserialize($attr_sku);
	foreach($attr_sku as $k => $v){
		if($v['path'] == $path){
			$attr_sku[$k]['stock'] = $attr_sku[$k]['stock']-$num;
		}
	}
	C::t('#aljbd#aljbd_goods')->update($gid,array('attr_sku'=>serialize($attr_sku)));
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>
