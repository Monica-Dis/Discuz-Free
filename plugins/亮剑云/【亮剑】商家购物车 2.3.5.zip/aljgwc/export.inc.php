<?php

/*

 * User: DisM!Ӧ������

 * ��ϵQQ:281097180

 *

 */



if (!defined('IN_DISCUZ')) {

    exit('Access denied.');

}

$lang = array(
	'1'=>'������',
	'2'=>'������',
	'3'=>'΢��֧��',
	'4'=>'֧����֧��',
	'5'=>'΢��APP֧��',
	'6'=>'������',
	'7'=>'���׺�',
	'8'=>'���״���ʱ��',
	'9'=>'����ʱ��',
	'10'=>'�����û�',
	'11'=>'��Ʒ����',
	'12'=>'ʵ����Ԫ��',
	'13'=>'�˷ѣ�Ԫ��',
	'14'=>'����״̬',
	'15'=>'��������',
	'16'=>'�ջ���ַ',
	'17'=>'���׼�¼',
	'18'=>'��Ȩ����',
	'19'=>'���׹ر�',
    '20'=>'���˿�',
    '21'=>'��������',
    '22'=>'Ǯ��֧��',
    '23'=>'����֧��',
    '24'=>'�������',
    '25'=>'���ջ�',
    '26'=>'������',
    '27'=>'������',
);
if(strtolower(CHARSET) != 'gbk'){
    foreach($lang as $k => $l){
        $lang[$k] = diconv($l,'gbk','UTF-8');
    }
}
if($_GET['pluginid']){
	$pluginid=$_GET['pluginid'];
}else{
	if(DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljbd'))){
		$pluginid='aljbd';
	}else if(DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljsc'))){
		$pluginid='aljsc';
	}else{
		$pluginid='aljtg';
	}
}
if($pluginid == 'aljtg'){
	$pid = 1;
}elseif($pluginid == 'aljsc'){
	$pid = 2;
}else{
	$pid = 0;
}
$conn[] ='aljbd_goods_order';
$where = 'where 1';
$where .= ' and pid = %d';
$conn[] = $pid;
if($_GET['status']){
	$status = intval($_GET['status']);
	if($status == 99){
		$where .= ' and status > %d';
		$conn[] = 1;
	}else{
		$where .= ' and status = %d';
		$conn[] = $status;
	}
	
}
if($_GET['payment']){
	$payment = intval($_GET['payment']);
	$where .= ' and payment = %d';
	$conn[] = $payment;
}
if($pluginid == 'aljtg' || $pluginid == 'aljsc'){
	if($_G['groupid']!=1){
		debug($lang['18']);
		exit;
	}
	$starttime = strtotime($_GET['starttime']);
	$endtime = strtotime($_GET['endtime']);
	if($_GET['starttime']){
		$where .= ' and submitdate >= %s';
		$conn[] = $starttime;
	}
	if($_GET['endtime']){
		$where .= ' and submitdate <= %s';
		$conn[] = $endtime;
	}
	if($_GET['search']){
		$keyword = stripsearchkey($_GET['search']);
		$keyword = '%'.$keyword.'%';
		
		if($_GET['order_good']){
			
			if($_GET['order_good']=='product_name'){
				$conn[] = $keyword;
				$where.=" and stitle like %s";
			}else if($_GET['order_good']=='order_id'){
				$conn[] = $keyword;
				$where.=" and orderid like %s";
			}else if($_GET['order_good']=='user_name'){
				$conn[] = $keyword;
				$where.=" and username like %s";
			}else if($_GET['order_good']=='shop_id'){
				$conn[] = stripsearchkey($_GET['keyword']);
				$where.=" and shop_id = %d";
			}
				
		}
	}
}else{
	$bids = DB::fetch_all('select id from %t where uid = %d',array('aljbd',$_G['uid']));
	foreach($bids as $bid){
		$ids[] = $bid['id'];
	}
	$bids = implode(',',$ids);
	
	$admingroups = unserialize($_G['cache']['plugin']['aljbd']['managegroups']);
	if(!in_array($_G['groupid'],$admingroups)){
		if($_GET['ord'] == 'dianpu' && $bids){
			$where .= ' and pid = 0 and shop_id in(%i) ';
			$conn[] = $bids;
		}else{
			debug($lang['18']);
			exit;
		}
	}
	if($_GET['start']){
		$conn[] =strtotime($_GET['start']);
		$where.=" and submitdate >= %d";
	}
	if($_GET['end']){
		$conn[] =strtotime($_GET['end']);
		$where.=" and submitdate <= %d";
	}
	if($_GET['search']){
		$keyword = stripsearchkey($_GET['search']);
		if($_GET['ordertype']){
			if($_GET['ordertype'] == 1){
				$conn[] ='%' . $keyword . '%';
				$where.=" and orderid like %s";
			}elseif($_GET['ordertype'] == 2){
				$conn[] ='%' . $keyword . '%';
				$where.=" and stitle like %s";
			}else if($_GET['ordertype'] == 3){
				$conn[] =$keyword;
				$where.=" and shop_id = %d";
			}else if($_GET['ordertype'] == 4){
                $conn[] ='%' . $keyword . '%';
                $conn[] ='%' . $keyword . '%';
                $where.=" and (uid like %s or username like %s)";
            }
		}else{
			$conn[] ='%' . $keyword . '%';
			$conn[] ='%' . $keyword . '%';
			$where.=" and (orderid like %s or stitle like %s)";
		}
	}
}
$where .= ' order by submitdate desc';
$orderlist = DB::fetch_all('select * from %t '.$where,$conn);

$regionlist=C::t('#aljgwc#aljgwc_region')->range();
foreach($orderlist as $k => $v){
	$orderarray[$k]['orderid'] = $v['orderid'];
	$orderarray[$k]['buyer'] = $v['buyer'];
	$orderarray[$k]['submitdate'] = dgmdate($v['submitdate']);
	$orderarray[$k]['confirmdate'] = $v['confirmdate']?dgmdate($v['confirmdate']):'';
	$orderarray[$k]['username'] = "\"".$v['username']."\"";
	$orderarray[$k]['stitle'] = "\"".$v['stitle']."\"";
	$orderarray[$k]['remarks'] = "\"".$v['remarks']."\"";
	$orderarray[$k]['price'] = $v['price'];
	$orderarray[$k]['fare'] = $v['fare'];
	if($v[status] == '1'){
		$status = $lang['1'];
	}else if($v[status] =='2'){
		$status = $lang['2'];
	}else if($v[status] =='3'){
        $status = $lang['25'];
    }else if($v[status] =='4'){
        $status = $lang['26'];
    }else if($v[status] =='5'){
        $status = $lang['27'];
    }else if($v[status] == '6'){
        $status = $lang['20'];
    }else if($v[status] == '7'){
        $status = $lang['19'];
    }
	$orderarray[$k]['status'] = $status;
	if($v['payment'] == 1){
		$payment = $lang['3'];
	}else if($v['payment'] == 2){
		$payment = $lang['4'];
	}else if($v['payment'] == 3){
		$payment = $lang['5'];
	}else if($v['payment'] == 5){
        $payment = $lang['23'];
    }else if($v['payment'] == 6){
        $payment = $lang['21'];
    }else if($v['payment'] == 7){
        $payment = $lang['22'];
    }
	$orderarray[$k]['payment'] = $payment;
	$address = unserialize($v[address]);
	$orderarray[$k]['address'] = $address['fullName'].' '.$address['mobile'].' '.$regionlist[$address['region']][name].$regionlist[$address['region1']][name].$regionlist[$address['region2']][name].$address['addressDetail'];
	unset($status);
	unset($payment);
	unset($address);
}

$title = array('orderid' => $lang['6'],'buyer' => $lang['7'],'submitdate' => $lang['8'],'confirmdate' => $lang['9'],'username' => $lang['10'],'stitle' => $lang['11'],'remarks' => $lang['24'],'price' => $lang['12'],'fare' => $lang['13'],'status' => $lang['14'],'payment' => $lang['15'],'address' => $lang['16']);
exportexcel($orderarray,$title,'orderlist_'.date('Ymd', TIMESTAMP));

/**

*   ��������Ϊexcel����

*   @param $data    һ����ά����,�ṹ��ͬ�����ݿ�����������

*   @param $title   excel�ĵ�һ�б���,һ������,���Ϊ����û�б���

*   @param $filename ���ص��ļ���

*   @examlpe

    exportexcel($arr,array('id','�˻�','����','�ǳ�'),'�ļ���!');

*/

function exportexcel($data=array(),$title=array(),$filename='report'){
    global $_G;
    ob_end_clean();
    header("Content-type:application/octet-stream");

    header("Accept-Ranges:bytes");

    header("Content-type:application/vnd.ms-excel;");

    header("Content-Disposition:attachment;filename=".$filename.".csv");

    header("Pragma: no-cache");

    header("Expires: 0");

    //����xls ��ʼ

    if (!empty($title)){

        foreach ($title as $k => $v) {

            $title[$k]=$v;

        }

        $title= implode(",", $title);
        if($_G['charset'] != 'gbk') {
            $title = diconv($title, $_G['charset'], 'GBK');
        }
        echo "$title\n";

    }

    if (!empty($data)){

        foreach($data as $key=>$val){

            foreach ($val as $ck => $cv) {

                $data[$key][$ck]=$cv;

            }

            $data[$key]=implode(",", $data[$key]);

             

        }
        $detail = implode("\n",$data);
        if($_G['charset'] != 'gbk') {
            $detail = diconv($detail, $_G['charset'], 'GBK');
        }
        echo $detail;

    }

}
//From: DisM. taobao. Com
?>