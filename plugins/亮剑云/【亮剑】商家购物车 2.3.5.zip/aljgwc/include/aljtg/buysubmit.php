<?php
$goods_id = $_GET['goods_id'];
$num = intval($_GET['num']);
$goods=C::t('#'.$pluginid.'#'.$pluginid.'_goods')->fetch($_GET['goods_id']);
if ($num < 1) {
    showmessage('&#21830;&#21697;&#25968;&#37327;&#24517;&#39035;&#22823;&#20110;&#48;');
}
if(!$address && $goods['goodstype'] == 2){
    showmessage('&#35831;&#22635;&#20889;&#25910;&#36135;&#22320;&#22336;');
}
if(!$_GET['payment']){
    showmessage('&#35831;&#36873;&#25321;&#20184;&#27454;&#26041;&#24335;');
}

if ($_GET['totalprice']) {
    $totalprice = $_GET['totalprice'];
}
if ($_GET['fare']) {
    $fare = $_GET['fare'];
}

if ($goods['state']) {
	showmessage($goods['name'].'&#21830;&#21697;&#24050;&#19979;&#26550;');
}
$shop_id = $goods['bid'];
if(!$goods){
	showmessage($alj_lang['The_goods_do_not_exist']);
}
$orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
if(C::t('#aljgwc#aljbd_goods_order')->fetch($orderid)) {
	showmessage('credits_addfunds_order_invalid', '', array(), array('showdialog' => 1, 'showmsg' => true, 'closetime' => true));
}


if ($goods['amount'] < $num) {
	showmessage($goods['name'].'&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;');
}

if (TIMESTAMP > $goods['endtime']  && !empty($goods['endtime'])) {
	showmessage($goods['name'].'&#19981;&#22312;&#27963;&#21160;&#26102;&#38388;&#20869;');
}


if($goods['goodstype'] == 1){
	$category = 1;
}
$goods_name.=$goods['name'];
$insertarray = array(
	'orderid' => $orderid,
	'goods_id' => $goods['id'],
	'shop_id'  => $shop_id,
	'uid'      => $_G['uid'],
	'num'      => $num,
	'price'	   => $goods['price1'],
	'ip'	   => $_G['clientip'],
	'dateline' => $_G['timestamp'],
	'content'  => $_GET['content'],
	'path'  => $_GET['path'],
	'name'  => $goods['name'],
	'fare'  => $goods['fare'],
	'fare_desc'  => $goods['fare_desc'],
	'pid'  => $pid,
	'category'  => $category,
	
);

C::t('#aljgwc#aljbd_goods_order_list')->insert($insertarray);

C::t('#'.$pluginid.'#'.$pluginid.'_goods')->update_num_by_id($goods['id'],$num);
	
if($isappbyme && $_GET['payment'] == 1){
	$_GET['payment'] = 3;
}
$orderarray=array(
	'orderid' => $orderid,
	'status' => '1',
	'uid' => $_G['uid'],
	'username' => $_G['username'],
	'shop_id' => $shop_id,
	'price' => $totalprice,
	'submitdate' => $_G['timestamp'],
	'remarks' => $_GET['content'].$_GET['remarks'],
	'stitle' => $goods_name,
	'payment' => $_GET['payment'],
	'fare' => $fare,
	'pid'  => $pid,
	'category'  => $category,
	'browser'  => $_SERVER['HTTP_USER_AGENT'],
);
if($_G['mobile']){//1���ֻ���2��PC
	$orderarray['mobile'] = 1;
}else{
	$orderarray['mobile'] = 2;
}

if(($config['service'] == 'create_direct_pay_by_user' && $_GET['payment'] == '2') || ($_GET['payment'] == '2' && $_G['mobile'])){
	$orderarray['d'] = 1;
}
$orderarray['address'] = serialize($address);
C::t('#aljgwc#aljbd_goods_order')->insert($orderarray);
showmessage($alj_lang['Single_success'],'plugin.php?id=aljgwc&act=cart_pay&orderid='.$orderid.'&pluginid='.$pluginid, array(), array('header' => true));
?>