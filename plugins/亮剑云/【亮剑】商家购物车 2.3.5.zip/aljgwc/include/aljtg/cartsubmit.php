<?php
if(!$address){
    showmessage('&#35831;&#22635;&#20889;&#25910;&#36135;&#22320;&#22336;');
}
if(!$_GET['payment']){
    showmessage('&#35831;&#36873;&#25321;&#20184;&#27454;&#26041;&#24335;');
}
$query = C::t('#aljgwc#aljgwc')->fetch_all_by_uid($_G['uid'],$_GET['shop_id'],$pid);
if(!$query){
    if($pid == 1){
        $orderurl = 'plugin.php?id='.$pluginid.':member&act=orderlist';
    }else if($pid == 2){
        $orderurl = 'plugin.php?id=aljgwc&act=orderlist&pluginid='.$pluginid;
    }else{
        $orderurl = 'plugin.php?id='.$pluginid.'&act=orderlist';
    }
    showmessage($alj_lang['The_goods_do_not_exist'], $orderurl, array(), array('header' => true));
}
if ($_GET['totalprice']) {
    $totalprice = $_GET['totalprice'];
}
if ($_GET['fare']) {
    $fare = $_GET['fare'];
}
$orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
if(C::t('#aljgwc#aljbd_goods_order')->fetch($orderid)) {
    showmessage('credits_addfunds_order_invalid', '', array(), array('showdialog' => 1, 'showmsg' => true, 'closetime' => true));
}
foreach($query as $value) {
    $good_1=C::t('#'.$pluginid.'#'.$pluginid.'_goods')->fetch($value['goods_id']);

    if ($good_1['amount'] < $value['num']) {
        showmessage($good_1['name'].'&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;');
    }
    if (TIMESTAMP > $good_1['endtime']  && !empty($good_1['endtime'])) {
        showmessage($good_1['name'].'&#19981;&#22312;&#27963;&#21160;&#26102;&#38388;&#20869;');
    }

    if ($good_1['state']) {
        showmessage($good_1['name'].'&#21830;&#21697;&#24050;&#19979;&#26550;');
    }
}

foreach($query as $value) {
    $good_1=C::t('#'.$pluginid.'#'.$pluginid.'_goods')->fetch($value['goods_id']);

    if ($good_1['amount'] < $value['num']) {
        showmessage($good_1['name'].'&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;');
    }

    if (TIMESTAMP > $good_1['endtime']  && !empty($good_1['endtime'])) {
        showmessage($good_1['name'].'&#19981;&#22312;&#27963;&#21160;&#26102;&#38388;&#20869;');
    }
    $goods_name.=$value['name'].'';
    $insertarray = array(
        'orderid' => $orderid,
        'goods_id' => $value['goods_id'],
        'shop_id'  => $value['shop_id'],
        'uid'      => $_G['uid'],
        'num'      => $value['num'],
        'price'	   => $value['price'],
        'ip'	   => $_G['clientip'],
        'dateline' => $_G['timestamp'],
        'content'  => $value['content'],
        'path'  => $value['path'],
        'name'  => $value['name'],
        'fare'  => $value['fare'],
        'fare_desc'  => $value['fare_desc'],
        'pid'  => $value['pid'],
    );
    C::t('#aljgwc#aljbd_goods_order_list')->insert($insertarray);
    C::t('#'.$pluginid.'#'.$pluginid.'_goods')->update_num_by_id($value['goods_id'],$value['num']);
}
if($isappbyme && $_GET['payment'] == 1){
    $_GET['payment'] = 3;
}
$orderarray=array(
    'orderid' => $orderid,
    'status' => '1',
    'uid' => $_G['uid'],
    'username' => $_G['username'],
    'shop_id' => $_GET['shop_id'],
    'price' => $totalprice,
    'submitdate' => $_G['timestamp'],
    'remarks' => $attrs.$_GET['remarks'],
    'stitle' => $goods_name,
    'payment' => $_GET['payment'],
    'fare' => $fare,
    'pid'  => $value['pid'],
    'mobile'  => $value['mobile'],
    'browser'  => $value['browser'],
);

if(($config['service'] == 'create_direct_pay_by_user' && $_GET['payment'] == '2') || ($_GET['payment'] == '2' && $_G['mobile'])){
    $orderarray['d'] = 1;
}
$orderarray['address'] = serialize($address);
C::t('#aljgwc#aljbd_goods_order')->insert($orderarray);
//ɾ��������Ϣ
C::t('#aljgwc#aljgwc')->delete_by_uid_shop($_G['uid'],$_GET['shop_id']);

showmessage($alj_lang['Single_success'],'plugin.php?id=aljgwc&act=cart_pay&orderid='.$orderid.'&pluginid='.$pluginid, array(), array('header' => true));
?>