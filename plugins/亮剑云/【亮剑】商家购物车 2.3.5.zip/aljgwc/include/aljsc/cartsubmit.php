<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$address){
    showmessage('&#35831;&#22635;&#20889;&#25910;&#36135;&#22320;&#22336;');
}
if(!$_GET['payment']){
    showmessage('&#35831;&#36873;&#25321;&#20184;&#27454;&#26041;&#24335;');
}
$query = C::t('#aljgwc#aljgwc')->fetch_all_by_uid($_G['uid'],$_GET['shop_id'],$pid);
if(!$query){
    if($pid == 1){
        $orderurl = 'plugin.php?id='.$pluginid.':member&act=orderlist';
    }else if($pid == 2){
        $orderurl = 'plugin.php?id=aljgwc&act=orderlist&pluginid='.$pluginid;
    }else{
        $orderurl = 'plugin.php?id='.$pluginid.'&act=orderlist';
    }
    showmessage($alj_lang['The_goods_do_not_exist'], $orderurl, array(), array('header' => true));
}
if ($_GET['totalprice']) {
    $totalprice = $_GET['totalprice'];
}
if ($_GET['fare']) {
    $fare = $_GET['fare'];
}
$orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
if(C::t('#aljgwc#aljbd_goods_order')->fetch($orderid)) {
    showmessage('credits_addfunds_order_invalid', '', array(), array('showdialog' => 1, 'showmsg' => true, 'closetime' => true));
}
foreach($query as $value) {
	$good_1=C::t('#'.$pluginid.'#'.$pluginid)->fetch($value['goods_id']);
	if ($good_1['num'] < $value['num']) {
		showmessage($good_1['title'].lang('plugin/aljsc','sc17'));
		break;
	}

	if (TIMESTAMP > $good_1['endtime']  && !empty($good_1['endtime'])) {
		showmessage($good_1['title'].lang('plugin/aljsc','sc19'));
		break;
	}
	if ($good_1['e']) {
		$limitnum=DB::result_first('select sum(num) from %t where sid=%d and uid=%d',array('aljsc_log',$value['goods_id'],$_G['uid']));
		
		if(($limitnum + $value['num']) > $good_1['e'] || $value['num'] >$good_1['e']){
			$lnum=($good_1['e']-$limitnum)>=0 ? ($good_1['e']-$limitnum):0;
			
			showmessage($good_1['title']."&#27599;&#20154;&#38480;&#25442;".$good_1['e']."&#20010;&#65292;&#24744;&#24050;&#20817;&#25442;".$limitnum."&#20010;&#65292;&#36824;&#21487;&#20197;&#20817;&#25442;".$lnum."&#20010;");
			break;
		}
	}

	if (TIMESTAMP < $good_1['starttime']) {
		showmessage($good_1['title'].lang('plugin/aljsc','sc19'));
		break;
	}
	if (TIMESTAMP > $good_1['endtime']) {
		showmessage($good_1['title'].lang('plugin/aljsc','sc19'));
		break;
	}

    if($value['shop_id'] == 2){
        $eprice = $value['ext'];
    }else{
        $eprice = $value['price'];
    }
    $total += $value[num] * $eprice + $value[fare];
}
if($total !=$totalprice){
    showmessage('&#35746;&#21333;&#24322;&#24120;&#35831;&#37325;&#35797;');
}
$notallowgroups = unserialize($_G['cache']['plugin']['aljsc']['notallowgroups']);
if (in_array($_G['groupid'], $notallowgroups)) {
	showmessage(lang('plugin/aljsc','sc23'));
}


if($_GET['payment'] == 4 && $s_id == 2){
	$money = getuserprofile('extcredits' . $_G['cache']['plugin']['aljsc']['extcredit']);

	if ($money < $totalprice) {
		showmessage($_G['setting']['extcredits'][$_G['cache']['plugin']['aljsc']['extcredit']]['title'].lang('plugin/aljsc','sc18'));
	}
	foreach($query as $value) {
		$good_1=C::t('#'.$pluginid.'#'.$pluginid)->fetch($value['goods_id']);
		if ($good_1['num'] < $value['num']) {
			showmessage($good_1['title'].lang('plugin/aljsc','sc17'));
		}
		
		if (TIMESTAMP > $good_1['endtime']  && !empty($good_1['endtime'])) {
			showmessage($good_1['title'].lang('plugin/aljsc','sc19'));
		}
		if ($good_1['e']) {
			$limitnum=DB::result_first('select sum(num) from %t where sid=%d and uid=%d',array('aljsc_log',$value['goods_id'],$_G['uid']));
			
			if(($limitnum + $value['num']) > $good_1['e'] || $value['num'] >$good_1['e']){
				$lnum=($good_1['e']-$limitnum)>=0 ? ($good_1['e']-$limitnum):0;
				
				showmessage($good_1['title']."&#27599;&#20154;&#38480;&#25442;".$good_1['e']."&#20010;&#65292;&#24744;&#24050;&#20817;&#25442;".$limitnum."&#20010;&#65292;&#36824;&#21487;&#20197;&#20817;&#25442;".$lnum."&#20010;");
				
			}
		}
		
		if (TIMESTAMP < $good_1['starttime']) {
			showmessage($good_1['title'].lang('plugin/aljsc','sc19'));
		}
		if (TIMESTAMP > $good_1['endtime']) {
			showmessage($good_1['title'].lang('plugin/aljsc','sc19'));
		}
		$insertarray = array(
			'uid' => $_G['uid'],
			'username' => $_G['username'],
			'sid' => $good_1['id'],
			'mode' => $good_1['mode'],
			'title' => $good_1['title'],
			'extcredit' => $good_1['extcredit']*$value['num'],
			'num' => $value['num'],
			'dateline' => TIMESTAMP,
			'a' => $value['content'].$_GET['remarks'],
		);
		$insertarray['c'] = serialize($address);
		updatemembercount($_G['uid'], array($_G['cache']['plugin']['aljsc']['extcredit'] => '-' . $value['num'] * $good_1['extcredit']));
		$insertid = C::t('#aljsc#aljsc_log')->insert($insertarray,true);
		C::t('#aljsc#aljsc')->update_num_by_id($value['goods_id'],$value['num']);
		C::t('#aljsc#aljsc')->update_num2_by_id($value['goods_id'],$value['num']);
		$sid = intval($value['goods_id']);
		$kamilist = DB::fetch_all('select * from %t where sid = %d and uid =0 limit %d',array('aljsc_kami',$sid,$value['num']));
		if($kamilist && count($kamilist) == $value['num']){
			DB::query('update %t set status = 1,d = 1 where id=%d',array('aljsc_log',$insertid));
			foreach($kamilist as $kami){
				DB::query('update %t set orderid = %d,dateline = %d,uid =%d,username = %s where mid=%d',array('aljsc_kami',$insertid,TIMESTAMP,$_G['uid'],$_G['username'],$kami['mid']));
			}
			$order = C::t('#aljsc#aljsc_log')->fetch($insertid);
			notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$order['sid'].'">'.$order['title'].'</a>',$_G['cache']['plugin']['aljsc']['fahuotips'])));
			if($_G['cache']['plugin']['aljsc']['ismail']){
				$email_first=C::t("common_member")->fetch($order['uid']);
				$email=$email_first['email'];
				sendmail_cron($email,$_G['cache']['plugin']['aljsc']['mailtitle'],str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=orderlist&sid='.$order['sid'].'">'.$order['title'].'</a>',$_G['cache']['plugin']['aljsc']['fahuotips'])));
			}
			
		}


		notification_add($_G['uid'], 'system',str_replace('{username}',$_G['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$sid.'">'.$good_1['title'].'</a>',$_G['cache']['plugin']['aljsc']['suctips'])));
		if($_G['cache']['plugin']['aljsc']['ismail']){
			$email_first = C::t("common_member")->fetch($_G['uid']);
			$email = $email_first['email'];
			sendmail_cron($email,$_G['cache']['plugin']['aljsc']['mailtitle'],str_replace('{username}',$_G['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$sid.'">'.$good_1['title'].'</a>',$_G['cache']['plugin']['aljsc']['suctips'])));
		}

		foreach(DB::fetch_all('select uid from '.DB::table('common_member').' where groupid in ('.dimplode($groups).')') as $u){
			notification_add($u['uid'], 'system',str_replace('{username}',$_G['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$sid.'">'.$good_1['title'].'</a>',$_G['cache']['plugin']['aljsc']['tsy'])));
			if($_G['cache']['plugin']['aljsc']['ismail']){
				$email_first=C::t("common_member")->fetch($u['uid']);
				$email=$email_first['email'];
				sendmail_cron($email,$_G['cache']['plugin']['aljsc']['mailtitle'],str_replace('{username}',$_G['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$sid.'">'.$good_1['title'].'</a>',$_G['cache']['plugin']['aljsc']['tsy'])));
			}
			
		}

	}
	//ɾ��������Ϣ
	C::t('#aljgwc#aljgwc')->delete_by_uid_shop($_G['uid'],$_GET['shop_id']);
	showmessage(lang('plugin/aljsc','sc20'),"plugin.php?id=aljsc&act=order");
}else{
	foreach($query as $value) {
		$good_1=C::t('#'.$pluginid.'#'.$pluginid)->fetch($value['goods_id']);
		
		if ($good_1['num'] < $value['num']) {
			showmessage($good_1['title'].lang('plugin/aljbd','sc17'));
			break;
		}
		
		if (TIMESTAMP > $good_1['endtime']  && !empty($good_1['endtime'])) {
			showmessage($good_1['title'].lang('plugin/aljbd','sc19'));
			break;
		}
		if ($good_1['e']) {
			$limitnum=DB::result_first('select sum(num) from %t where goods_id=%d and uid=%d',array('aljbd_goods_order_list',$value['goods_id'],$_G['uid']));
			
			if(($limitnum + $value['num']) > $good_1['e'] || $value['num'] >$good_1['e']){
				$lnum=($good_1['e']-$limitnum)>=0 ? ($good_1['e']-$limitnum):0;
				
				showmessage($good_1['title']."&#27599;&#20154;&#38480;&#25442;".$good_1['e']."&#20010;&#65292;&#24744;&#24050;&#20817;&#25442;".$limitnum."&#20010;&#65292;&#36824;&#21487;&#20197;&#20817;&#25442;".$lnum."&#20010;");
				break;
			}
		}
		
		if (TIMESTAMP < $good_1['starttime']) {
			showmessage($good_1['title'].lang('plugin/aljsc','sc19'));
			break;
		}
		if (TIMESTAMP > $good_1['endtime']) {
			showmessage($good_1['title'].lang('plugin/aljsc','sc19'));
			break;
		}
	}
	foreach($query as $value) {
		$good_1=C::t('#'.$pluginid.'#'.$pluginid)->fetch($value['goods_id']);
		
		if ($good_1['num'] < $value['num']) {
			showmessage($good_1['title'].lang('plugin/aljsc','sc17'));
			break;
		}
		
		if (TIMESTAMP > $good_1['endtime']  && !empty($good_1['endtime'])) {
			showmessage($good_1['title'].lang('plugin/aljsc','sc19'));
			break;
		}
		if ($good_1['e']) {
			$limitnum=DB::result_first('select sum(num) from %t where goods_id=%d and uid=%d',array('aljbd_goods_order_list',$value['goods_id'],$_G['uid']));
			
			if(($limitnum + $value['num']) > $good_1['e'] || $value['num'] >$good_1['e']){
				$lnum=($good_1['e']-$limitnum)>=0 ? ($good_1['e']-$limitnum):0;
				
				showmessage($good_1['title']."&#27599;&#20154;&#38480;&#25442;".$good_1['e']."&#20010;&#65292;&#24744;&#24050;&#20817;&#25442;".$limitnum."&#20010;&#65292;&#36824;&#21487;&#20197;&#20817;&#25442;".$lnum."&#20010;");
				break;
			}
		}
		
		if (TIMESTAMP < $good_1['starttime']) {
			showmessage($good_1['title'].lang('plugin/aljsc','sc19'));
			break;
		}
		if (TIMESTAMP > $good_1['endtime']) {
			showmessage($good_1['title'].lang('plugin/aljsc','sc19'));
			break;
		}
		$goods_name.=$value['name'].'';
		C::t('#aljgwc#aljbd_goods_order_list')->insert(array(
			'orderid' => $orderid,
			'goods_id' => $value['goods_id'],
			'shop_id'  => $value['shop_id'],
			'uid'      => $_G['uid'],
			'num'      => $value['num'],
			'price'	   => $value['price'],
			'ip'	   => $_G['clientip'],
			'dateline' => $_G['timestamp'],
			'content'  => $value['content'],
			'name'  => $value['name'],
			'fare'  => $value['fare'],
			'fare_desc'  => $value['fare_desc'],
			'pid'  => $value['pid'],
		));
		C::t('#'.$pluginid.'#'.$pluginid)->update_num_by_id($value['goods_id'],$value['num']);
	}
	if($isappbyme && $_GET['payment'] == 1){
		$_GET['payment'] = 3;
	}
	$orderarray=array(
		'orderid' => $orderid,
		'status' => '1',
		'uid' => $_G['uid'],
		'username' => $_G['username'],
		'shop_id' => $_GET['shop_id'],
		'price' => $totalprice,
		'submitdate' => $_G['timestamp'],
		'remarks' => $attrs.$_GET['remarks'],
		'stitle' => $goods_name,
		'payment' => $_GET['payment'],
		'fare' => $fare,
		'pid'  => $value['pid'],
		'mobile'  => $value['mobile'],
		'browser'  => $value['browser'],
	);

	if(($config['service'] == 'create_direct_pay_by_user' && $_GET['payment'] == '2') || ($_GET['payment'] == '2' && $_G['mobile'])){
		$orderarray['d'] = 1;
	}
	$orderarray['address'] = serialize($address);
	C::t('#aljgwc#aljbd_goods_order')->insert($orderarray);
	//ɾ��������Ϣ
	C::t('#aljgwc#aljgwc')->delete_by_uid_shop($_G['uid'],$_GET['shop_id']);

	showmessage($alj_lang['Single_success'],'plugin.php?id=aljgwc&act=cart_pay&orderid='.$orderid.'&pluginid='.$pluginid, array(), array('header' => true));
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>