<?php
if(!$address){
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('&#35831;&#22635;&#20889;&#25910;&#36135;&#22320;&#22336;','');</script>";
        exit;
    }else {
        showmessage('&#35831;&#22635;&#20889;&#25910;&#36135;&#22320;&#22336;');
    }
}
if(!$_GET['payment']){
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('&#35831;&#36873;&#25321;&#20184;&#27454;&#26041;&#24335;','');</script>";
        exit;
    }else {
        showmessage('&#35831;&#36873;&#25321;&#20184;&#27454;&#26041;&#24335;');
    }
}
$query = C::t('#aljgwc#aljgwc')->fetch_all_by_uid($_G['uid'],$_GET['shop_id'],$pid);
if(!$query){
    if($pid == 1){
        $orderurl = 'plugin.php?id='.$pluginid.':member&act=orderlist';
    }else if($pid == 2){
        $orderurl = 'plugin.php?id=aljgwc&act=orderlist&pluginid='.$pluginid;
    }else{
        $orderurl = 'plugin.php?id='.$pluginid.'&act=orderlist';
    }
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('&#35746;&#21333;&#24050;&#25552;&#20132;',function(){parent.location.href='".$orderurl."';});</script>";
        exit;
    }else {
        showmessage($alj_lang['The_goods_do_not_exist'], $orderurl, array(), array('header' => true));
    }
}
if ($_GET['totalprice']) {
    $totalprice = $_GET['totalprice'];
}
if ($_GET['fare']) {
    $fare = $_GET['fare'];
}
$orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
if(C::t('#aljgwc#aljbd_goods_order')->fetch($orderid)) {
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('&#35746;&#21333;&#24050;&#23384;&#22312;','');</script>";
        exit;
    }else {
        showmessage('credits_addfunds_order_invalid', '', array(), array('showdialog' => 1, 'showmsg' => true, 'closetime' => true));
    }
}
if($_GET['payment'] == 5){
    $exttotalprice = $totalprice*$config['proportion_aljbd'];
    if($extcredits < $exttotalprice) {
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".$_G['setting']['extcredits'][$config['ext_aljbd']]['title']."&#19981;&#36275;&#65292;&#35831;&#36873;&#25321;&#20854;&#23427;&#25903;&#20184;&#26041;&#24335;','');</script>";
            exit;
        }else {
            showmessage($_G['setting']['extcredits'][$config['ext_aljbd']]['title'] . '&#19981;&#36275;&#65292;&#35831;&#36873;&#25321;&#20854;&#23427;&#25903;&#20184;&#26041;&#24335;');
        }
    }
}

foreach($query as $value) {
    $good_1=C::t('#'.$pluginid.'#'.$pluginid.'_goods')->fetch($value['goods_id']);

    $gattrsku = skups($good_1['attr_sku'],$value['path']);//��ϼ۸���
    if ($good_1['attr_sku'] && $gattrsku['stock'] < $value['num']) {//��Ͽ��
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".$good_1['name'] . $value['content']."&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;','');</script>";
            exit;
        }else {
            showmessage($good_1['name'] . $value['content'] . '&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;');
        }
    }else{
        if ($good_1['amount'] < $value['num']) {
            if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                echo "<script>parent.tips('".$good_1['name'] . $value['content']."&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;','');</script>";
                exit;
            }else {
                showmessage($good_1['name'] . $value['content'] . '&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;');
            }
        }
    }

    if (TIMESTAMP > $good_1['endtime']  && !empty($good_1['endtime'])) {
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".$good_1['name']."&#19981;&#22312;&#27963;&#21160;&#26102;&#38388;&#20869;','');</script>";
            exit;
        }else {
            showmessage($good_1['name'] . '&#19981;&#22312;&#27963;&#21160;&#26102;&#38388;&#20869;');
        }
    }
    if ($good_1['state']) {
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".$good_1['name']."&#21830;&#21697;&#24050;&#19979;&#26550;','');</script>";
            exit;
        }else {
            showmessage($good_1['name'] . '&#21830;&#21697;&#24050;&#19979;&#26550;');
        }
    }
    $goods_name.=$value['name'].'';

    $insertarray = array(
        'orderid' => $orderid,
        'goods_id' => $value['goods_id'],
        'shop_id'  => $value['shop_id'],
        'uid'      => $_G['uid'],
        'num'      => $value['num'],
        'price'	   => $value['price'],
        'ip'	   => $_G['clientip'],
        'dateline' => $_G['timestamp'],
        'content'  => $value['content'],
        'path'  => $value['path'],
        'name'  => $value['name'],
        'fare'  => $value['fare'],
        'fare_desc'  => $value['fare_desc'],
        'pid'  => $value['pid'],
    );
    if(file_exists("source/plugin/xydz/xydz.inc.php")){
        require_once 'source/plugin/xydz/include/cartsubmit.php';
    }

    if(file_exists("source/plugin/dz_1/dz_1.inc.php")){
        $ext_nums+=$value['ext_num'];
        $insertarray['ext_num'] = $value['ext_num'];
    }
    C::t('#aljgwc#aljbd_goods_order_list')->insert($insertarray);

    if($good_1['attr_sku']){
        skunum($good_1['attr_sku'],$value['path'],$value['num'],$good_1['id']);//����Ͽ��
        C::t('#'.$pluginid.'#'.$pluginid.'_goods')->update_num_by_id($value['goods_id'],$value['num']);
    }else{
        C::t('#'.$pluginid.'#'.$pluginid.'_goods')->update_num_by_id($value['goods_id'],$value['num']);
    }
    if($good_1[fare]>0 && $good_1['fare_desc'] == 999999){
        $gfare = $good_1[fare];
    }
    $total += $value['num'] * $value['price'] + $gfare;
}
$yuantotalprice = floatval($total - $_GET['dis']);

if($yuantotalprice !=$totalprice){
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('&#35746;&#21333;&#24322;&#24120;&#35831;&#37325;&#35797;','');</script>";
        exit;
    }else {
        showmessage('&#35746;&#21333;&#24322;&#24120;&#35831;&#37325;&#35797;');
    }
}
if($isappbyme && $_GET['payment'] == 1){
    $_GET['payment'] = 3;
}
$status = 1;
if($_GET['payment'] == '6'){
    $status = 2;
}
$orderarray=array(
    'orderid' => $orderid,
    'status' => $status,
    'uid' => $_G['uid'],
    'username' => $_G['username'],
    'shop_id' => $_GET['shop_id'],
    'price' => $totalprice,
    'submitdate' => $_G['timestamp'],
    'remarks' => $attrs.$_GET['remarks'],
    'stitle' => $goods_name,
    'payment' => $_GET['payment'],
    'fare' => $fare,
    'pid'  => $value['pid'],
    'mobile'  => $value['mobile'],
    'browser'  => $value['browser'],
    'discount' => $_GET['dis']
);
if(file_exists("source/plugin/xydz/xydz.inc.php")){
    require_once 'source/plugin/xydz/include/cartsubmit_o.php';
}
if(file_exists("source/plugin/dz_1/dz_1.inc.php")){
    require_once 'source/plugin/dz_1/include/cartsubmit_o.php';
}
if(file_exists("source/plugin/dz_3/dz_3.inc.php")){
    require_once 'source/plugin/dz_3/include/cartsubmit_o.php';
}
if(($config['service'] == 'create_direct_pay_by_user' && $_GET['payment'] == '2') || ($_GET['payment'] == '2' && $_G['mobile'])){
    $orderarray['d'] = 1;
}
$orderarray['proportion'] = $config['proportion_aljbd'];//���ֱ���
$orderarray['ext'] = $exttotalprice;
$orderarray['address'] = serialize($address);
C::t('#aljgwc#aljbd_goods_order')->insert($orderarray);
//ɾ��������Ϣ
C::t('#aljgwc#aljgwc')->delete_by_uid_shop($_G['uid'],$_GET['shop_id']);
if($_GET['payment'] == '6'){
    $order = C::t('#aljgwc#aljbd_goods_order') -> fetch($orderid);
    $orderlurl = $_G['siteurl'].'/plugin.php?id='.$pluginid.'&act=orderlist';
    $orderlurln = '/plugin.php?id='.$pluginid.'&act=orderlist';
    $brand = C::t('#'.$pluginid.'#'.$pluginid) -> fetch($order['shop_id']);
    notification_add($order['uid'],'system',str_replace('{username}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['suctips'])).'&nbsp;<a href="'.$orderlurln.'">'.lang('plugin/aljgwc','View_orders').'</a>');
    if(!$order['pid']){//Ʒ���̼�
        $is_aljdx = $cparray['aljdx'];
        if($is_aljdx){
            require_once 'source/plugin/aljdx/function_dx.php';
            $oaddress = unserialize($order['address']);
            $orderidau = $_G['cache']['plugin']['aljbd']['is_dx_var'] ? 'orderidau' : 'orderid_au';
            $username_au = $_G['cache']['plugin']['aljbd']['is_dx_var'] ? 'usernameau' : 'username_au';
            if(preg_match('#^\d[\d-]{3,20}\d$#', $oaddress['mobile'])){
                sendsmsbyvar($oaddress['mobile'],'aljbd','tips_user',array($username_au =>$order['username'] ,$orderidau => $_G['cache']['plugin']['aljbd']['is_dx_order']?'**'.substr($order['orderid'],-4):$order['orderid']));
            }
            if(preg_match('#^\d[\d-]{3,20}\d$#', $brand['tel'])){
                sendsmsbyvar($brand['tel'],'aljbd','tips_business',array($orderidau => $_G['cache']['plugin']['aljbd']['is_dx_order']?'**'.substr($order['orderid'],-4):$order['orderid']));
            }
        }
    }

    if($_G['cache']['plugin'][$pluginid]['time'] && $_G['cache']['plugin'][$pluginid]['notify_merchant']){
        notification_add($brand['uid'],'system',str_replace('{orderid}','<a href="'.$orderlurln.'">'.$data['out_trade_no'].'</a>',str_replace('{username}',$brand['username'],str_replace('{name}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['notify_merchant'])))));
        $email_first = C::t("common_member")->fetch($order['uid']);
        $email = $email_first['email'];
        require_once libfile('function/mail');
        if($email_first['email']){
            $m=str_replace('{username}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['suctips'])).'&nbsp;<a href="'.$orderlurl.'">'.lang('plugin/aljgwc','View_orders').'</a>';
            sendmail_cron($email,$_G['cache']['plugin'][$pluginid]['mailtitle'].'@'.gmdate('Y-m-d H:i:s',$_G['timestamp']+8*3600),$m);
        }
        $email_f = C::t("common_member")->fetch($brand['uid']);
        $e = $email_f['email'];
        if($email_f['email']){
            $me=str_replace('{orderid}','<a href="'.$orderlurl.'">'.$data['out_trade_no'].'</a>',str_replace('{username}',$brand['username'],str_replace('{name}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['notify_merchant']))));
            $t=str_replace('{orderid}',$data['out_trade_no'],$_G['cache']['plugin'][$pluginid]['notify_merchant_title']);
            sendmail_cron($e,$t,$me);
        }
    }
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('&#19979;&#21333;&#25104;&#21151;&#65281;',function(){parent.location.href='plugin.php?id=" . $pluginid . "&act=orderlist';});</script>";
        exit;
    }else {
        showmessage('&#19979;&#21333;&#25104;&#21151;&#65281;', 'plugin.php?id=' . $pluginid . '&act=orderlist');
    }
}else {
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        if($config['is_aljqb']){
            require_once 'source/plugin/aljqb/class/Qbapi.class.php';
            $qbapi = new Qbapi();
            $keyurlarray = array(
                'orderid' => $orderid,
                'time' => TIMESTAMP,
                'price' => $totalprice,
                'keyname' => 'aljgwc',
                'return_url' => $_G['siteurl'].'/plugin.php?id='.$pluginid.'&act=orderlist',
                'key' => $config['qb_key'],
            );
            $url = $qbapi -> createUrl($keyurlarray);
            echo "<script>parent.location.href='" . $url . "';</script>";
            exit;
        }else{
            echo "<script>parent.location.href='".$config['OAuth']."plugin.php?id=aljgwc&act=cart_pay&orderid=" . $orderid . "&pluginid=" . $pluginid."';</script>";
            exit;
        }
    }else {
        showmessage($alj_lang['Single_success'], $config['OAuth'].'plugin.php?id=aljgwc&act=cart_pay&orderid=' . $orderid . '&pluginid=' . $pluginid, array(), array('header' => true));
    }
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>