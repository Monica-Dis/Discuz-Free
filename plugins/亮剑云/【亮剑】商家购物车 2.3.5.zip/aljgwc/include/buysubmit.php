<?php
$goods_id = $_GET['goods_id'];
$num = intval($_GET['num']);

if ($num < 1) {
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('&#21830;&#21697;&#25968;&#37327;&#24517;&#39035;&#22823;&#20110;&#48;','');</script>";
        exit;
    }else {
        showmessage('&#21830;&#21697;&#25968;&#37327;&#24517;&#39035;&#22823;&#20110;&#48;');
    }
}

if(!$_GET['payment']){
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('&#35831;&#36873;&#25321;&#20184;&#27454;&#26041;&#24335;','');</script>";
        exit;
    }else {
        showmessage('&#35831;&#36873;&#25321;&#20184;&#27454;&#26041;&#24335;');
    }
}

if ($_GET['totalprice']) {
    $totalprice = $_GET['totalprice'];
}
if ($_GET['fare']) {
    $fare = $_GET['fare'];
}
if($_GET['payment'] == 5){
	$exttotalprice = $totalprice*$config['proportion_aljbd'];
	if($extcredits < $exttotalprice) {
        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
            echo "<script>parent.tips('".$_G['setting']['extcredits'][$config['ext_aljbd']]['title']."&#19981;&#36275;&#65292;&#35831;&#36873;&#25321;&#20854;&#23427;&#25903;&#20184;&#26041;&#24335;','');</script>";
            exit;
        }else {
            showmessage($_G['setting']['extcredits'][$config['ext_aljbd']]['title'] . '&#19981;&#36275;&#65292;&#35831;&#36873;&#25321;&#20854;&#23427;&#25903;&#20184;&#26041;&#24335;');
        }
	}
}

$goods=C::t('#'.$pluginid.'#'.$pluginid.'_goods')->fetch($_GET['goods_id']);
if(!$address && $goods['category'] == 0){
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('&#35831;&#22635;&#20889;&#25910;&#36135;&#22320;&#22336;','');</script>";
        exit;
    }else {
        showmessage('&#35831;&#22635;&#20889;&#25910;&#36135;&#22320;&#22336;');
    }
}
if ($goods['state']) {
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('".$goods['name']."&#21830;&#21697;&#24050;&#19979;&#26550;','');</script>";
        exit;
    }else {
        showmessage($goods['name'] . '&#21830;&#21697;&#24050;&#19979;&#26550;');
    }
}
$shop_id = $goods['bid'];

$gattrsku = skups($goods['attr_sku'],$_GET['path']);//��ϼ۸���
if($goods['attr_sku'] && $_GET['path']){
	$goods['price1'] = $gattrsku['saleprice'];
	$goods['amount'] = $gattrsku['stock'];
}
$yuantotalprice = floatval($goods['price1']*$num+$goods['fare'] - $_GET['dis']);
if($yuantotalprice !=$totalprice){
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('&#35746;&#21333;&#24322;&#24120;&#35831;&#37325;&#35797;','');</script>";
        exit;
    }else {
        showmessage('&#35746;&#21333;&#24322;&#24120;&#35831;&#37325;&#35797;');
    }
}
if(!$goods){
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('".$alj_lang['The_goods_do_not_exist']."','');</script>";
        exit;
    }else {
        showmessage($alj_lang['The_goods_do_not_exist']);
    }
}
$orderid = dgmdate(TIMESTAMP, 'YmdHis').random(10);
if(C::t('#aljgwc#aljbd_goods_order')->fetch($orderid)) {
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('&#35746;&#21333;&#24050;&#23384;&#22312;','');</script>";
        exit;
    }else {
        showmessage('credits_addfunds_order_invalid', '', array(), array('showdialog' => 1, 'showmsg' => true, 'closetime' => true));
    }
}


if ($goods['amount'] < $num) {
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('".$goods['name']."&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;','');</script>";
        exit;
    }else {
        showmessage($goods['name'] . '&#35813;&#21830;&#21697;&#27809;&#26377;&#24211;&#23384;&#20102;&#65281;');
    }
}
if (TIMESTAMP > $goods['endtime']  && !empty($goods['endtime'])) {
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('".$goods['name']."&#19981;&#22312;&#27963;&#21160;&#26102;&#38388;&#20869;','');</script>";
        exit;
    }else {
        showmessage($goods['name'] . '&#19981;&#22312;&#27963;&#21160;&#26102;&#38388;&#20869;');
    }
}
$goods_name.=$goods['name'];
$insertarray = array(
	'orderid' => $orderid,
	'goods_id' => $goods['id'],
	'shop_id'  => $shop_id,
	'uid'      => $_G['uid'],
	'num'      => $num,
	'price'	   => $goods['price1'],
	'ip'	   => $_G['clientip'],
	'dateline' => $_G['timestamp'],
	'content'  => $_GET['content'],
	'path'  => $_GET['path'],
	'name'  => $goods['name'],
	'fare'  => $goods['fare'],
	'fare_desc'  => $goods['fare_desc'],
	'pid'  => $pid,
	'category'  => $goods['category'],
	
);
if(file_exists("source/plugin/xydz/xydz.inc.php")){
	require_once 'source/plugin/xydz/include/buysubmit.php';
}
if(file_exists("source/plugin/dz_1/dz_1.inc.php")){
    require_once 'source/plugin/dz_1/include/buysubmit.php';
}
if(file_exists("source/plugin/dz_3/dz_3.inc.php")){
    require_once 'source/plugin/dz_3/include/buysubmit_1.php';
}
C::t('#aljgwc#aljbd_goods_order_list')->insert($insertarray);

if($goods['attr_sku']){
	skunum($goods['attr_sku'],$_GET['path'],$num,$goods['id']);//����Ͽ��
	C::t('#'.$pluginid.'#'.$pluginid.'_goods')->update_num_by_id($goods['id'],$num);
}else{
	C::t('#'.$pluginid.'#'.$pluginid.'_goods')->update_num_by_id($goods['id'],$num);
}
	
if($isappbyme && $_GET['payment'] == 1){
	$_GET['payment'] = 3;
}
$status = 1;
if($_GET['payment'] == '6'){
    $status = 2;
}
$orderarray=array(
	'orderid' => $orderid,
	'status' => $status,
	'uid' => $_G['uid'],
	'username' => $_G['username'],
	'shop_id' => $shop_id,
	'price' => $totalprice,
	'submitdate' => $_G['timestamp'],
	'remarks' => $_GET['content'].$_GET['remarks'],
	'stitle' => $goods_name,
	'payment' => $_GET['payment'],
	'fare' => $fare,
	'pid'  => $pid,
	'category'  => $goods['category'],
	'browser'  => $_SERVER['HTTP_USER_AGENT'],
    'discount' => $_GET['dis']
);
if($_G['mobile']){//1���ֻ���2��PC
	$orderarray['mobile'] = 1;
}else{
	$orderarray['mobile'] = 2;
}
if(file_exists("source/plugin/xydz/xydz.inc.php")){
	require_once 'source/plugin/xydz/include/buysubmit_o.php';
}
if(file_exists("source/plugin/dz_1/dz_1.inc.php")){
    require_once 'source/plugin/dz_1/include/buysubmit_o.php';
}
if(file_exists("source/plugin/dz_3/dz_3.inc.php")){
    require_once 'source/plugin/dz_3/include/buysubmit.php';
}
if(($config['service'] == 'create_direct_pay_by_user' && $_GET['payment'] == '2') || ($_GET['payment'] == '2' && $_G['mobile'])){
	$orderarray['d'] = 1;
}
$orderarray['proportion'] = $config['proportion_aljbd'];
$orderarray['ext'] = $exttotalprice;
$orderarray['address'] = serialize($address);
C::t('#aljgwc#aljbd_goods_order')->insert($orderarray);
if($_GET['payment'] == '6'){
    $order = C::t('#aljgwc#aljbd_goods_order') -> fetch($orderid);
    $orderlurl = $_G['siteurl'].'/plugin.php?id='.$pluginid.'&act=orderlist';
    $orderlurln = '/plugin.php?id='.$pluginid.'&act=orderlist';
    $brand = C::t('#'.$pluginid.'#'.$pluginid) -> fetch($order['shop_id']);
    notification_add($order['uid'],'system',str_replace('{username}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['suctips'])).'&nbsp;<a href="'.$orderlurln.'">'.lang('plugin/aljgwc','View_orders').'</a>');
    if(!$order['pid']){//Ʒ���̼�
        $is_aljdx = $cparray['aljdx'];
        if($is_aljdx){
            require_once 'source/plugin/aljdx/function_dx.php';
            $oaddress = unserialize($order['address']);
            $orderidau = $_G['cache']['plugin']['aljbd']['is_dx_var'] ? 'orderidau' : 'orderid_au';
            $username_au = $_G['cache']['plugin']['aljbd']['is_dx_var'] ? 'usernameau' : 'username_au';
            if(preg_match('#^\d[\d-]{3,20}\d$#', $oaddress['mobile'])){
                sendsmsbyvar($oaddress['mobile'],'aljbd','tips_user',array($username_au =>$order['username'] ,$orderidau => $_G['cache']['plugin']['aljbd']['is_dx_order']?'**'.substr($order['orderid'],-4):$order['orderid']));
            }
            if(preg_match('#^\d[\d-]{3,20}\d$#', $brand['tel'])){
                sendsmsbyvar($brand['tel'],'aljbd','tips_business',array($orderidau => $_G['cache']['plugin']['aljbd']['is_dx_order']?'**'.substr($order['orderid'],-4):$order['orderid']));
            }
        }
    }

    if($_G['cache']['plugin'][$pluginid]['time'] && $_G['cache']['plugin'][$pluginid]['notify_merchant']){
        notification_add($brand['uid'],'system',str_replace('{orderid}','<a href="'.$orderlurln.'">'.$data['out_trade_no'].'</a>',str_replace('{username}',$brand['username'],str_replace('{name}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['notify_merchant'])))));
        $email_first = C::t("common_member")->fetch($order['uid']);
        $email = $email_first['email'];
        require_once libfile('function/mail');
        if($email_first['email']){
            $m=str_replace('{username}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['suctips'])).'&nbsp;<a href="'.$orderlurl.'">'.lang('plugin/aljgwc','View_orders').'</a>';
            sendmail_cron($email,$_G['cache']['plugin'][$pluginid]['mailtitle'].'@'.gmdate('Y-m-d H:i:s',$_G['timestamp']+8*3600),$m);
        }
        $email_f = C::t("common_member")->fetch($brand['uid']);
        $e = $email_f['email'];
        if($email_f['email']){
            $me=str_replace('{orderid}','<a href="'.$orderlurl.'">'.$data['out_trade_no'].'</a>',str_replace('{username}',$brand['username'],str_replace('{name}',$order['username'],str_replace('{shopname}',$order['stitle'],$_G['cache']['plugin'][$pluginid]['notify_merchant']))));
            $t=str_replace('{orderid}',$data['out_trade_no'],$_G['cache']['plugin'][$pluginid]['notify_merchant_title']);
            sendmail_cron($e,$t,$me);
        }
    }
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.tips('&#19979;&#21333;&#25104;&#21151;&#65281;',function(){parent.location.href='plugin.php?id=" . $pluginid . "&act=orderlist';});</script>";
        exit;
    }else {
        showmessage('&#19979;&#21333;&#25104;&#21151;&#65281;', 'plugin.php?id=' . $pluginid . '&act=orderlist');
    }
}else{
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        echo "<script>parent.location.href='".$config['OAuth']."plugin.php?id=aljgwc&act=cart_pay&orderid=" . $orderid . "&pluginid=" . $pluginid."';</script>";
        exit;
    }else {
        showmessage($alj_lang['Single_success'], $config['OAuth'].'plugin.php?id=aljgwc&act=cart_pay&orderid=' . $orderid . '&pluginid=' . $pluginid, array(), array('header' => true));
    }
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>