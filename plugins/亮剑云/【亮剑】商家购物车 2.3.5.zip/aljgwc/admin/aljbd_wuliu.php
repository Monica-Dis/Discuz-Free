<?php
/*
 * User: DisM!Ӧ������
 * ���²����http://t.cn/Aiux1Jx1
 *
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(C::t('#aljbd#aljbd_wuliu')->fetch($_GET['orderid'])){
	C::t('#aljbd#aljbd_wuliu')->update($_GET['orderid'],array(
		'companyname' => $_GET['companyname'],
		'worderid' => $_GET['worderid'],
		'updatetime' => TIMESTAMP,
	));
	C::t('#aljgwc#aljbd_goods_order')->update_status_by_orderid($_GET['orderid']);
	cpmsg(lang('plugin/aljbd','sc1'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljbd&pmod=order', 'succeed');
}else{
	C::t('#aljbd#aljbd_wuliu')->insert(array(
		'orderid' => $_GET['orderid'],
		'type' => 1,
		'companyname' => $_GET['companyname'],
		'worderid' => $_GET['worderid'],
		'dateline' => TIMESTAMP,
	));
	C::t('#aljgwc#aljbd_goods_order')->update_status_by_orderid($_GET['orderid']);
	cpmsg(lang('plugin/aljbd','sc1'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljbd&pmod=order', 'succeed');
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>