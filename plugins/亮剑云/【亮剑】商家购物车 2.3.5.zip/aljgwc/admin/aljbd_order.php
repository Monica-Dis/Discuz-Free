<?php
/*
 * User: DisM!Ӧ������
 * ���²����http://t.cn/Aiux1Jx1
 *
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$currpage=$_GET['page']?$_GET['page']:1;
$perpage=10;
$conn[] ='aljbd_goods_order';
$where = 'where 1 ';
if($_GET['status']){
	$status = intval($_GET['status']);
	$where .= 'and status = %d';
	$conn[] = $status;
}
if($_GET['keyword']){
	$keyword = stripsearchkey($_GET['keyword']);
	$keyword = '%'.$keyword.'%';
	$where .= ' and (orderid like %s or shop_id like %s)';
	$conn[] = $keyword;
	$conn[] = $keyword;
}

$num = DB::result_first('select count(*) from %t '.$where,$conn);
$start=($currpage-1)*$perpage;
$where .= ' order by submitdate desc';
$where .= ' limit %d,%d';
$conn[] = $start;
$conn[] = $perpage;
$orderlist = DB::fetch_all('select * from %t '.$where,$conn);
$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljbd&pmod=order', 0, 11, false, false);
include template('aljgwc:aljbd_adminorder');
?>