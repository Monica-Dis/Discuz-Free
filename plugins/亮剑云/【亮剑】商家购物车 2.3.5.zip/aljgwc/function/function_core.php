<?php

/*
 * ����: Discuz!�����ƹ�����
 * ���²����http://t.cn/Aiux1Jx1/
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$notify_url = $_G['siteurl'].'/source/plugin/aljgwc/pay/notify_url.php';
if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0){
	$isappbyme = true;
	$trade_type = '3';
}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
	$iswechat = true;
	$trade_type = '1';
}
$config = $_G['cache']['plugin']['aljgwc'];
$settings=C::t('#aljgwc#aljgwc_paysetting')->range();
foreach($settings as $k => $v){
	$config[$k] = $v['value'];//ͳһ�����ע���������Ҫ��ͻ
}
if(DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin','aljbd'))){
	$settings_aljbd=C::t('#aljbd#aljbd_setting')->range();
	$is_openarray = array('iswatermark','is_daohang','alipay','malipay','isextcredit','pic','isgo','isnews','isyouh','ispd','isrewrite','islogo','isqq','ista','sjurl','sj_index_lz','time');
	foreach($settings_aljbd as $k => $v){
		if(in_array($k,$is_openarray)){//�����ж�
			if($v['value'] == 1){
				$_G['cache']['plugin']['aljbd'][$k] = 1;
			}elseif($v['value'] == 2){
				$_G['cache']['plugin']['aljbd'][$k] = 0;
			}
		}else{
			if($v['value']){
				$_G['cache']['plugin']['aljbd'][$k] = htmlspecialchars_decode($v['value']);//ͬ����������ֵ���������б���
			}
		}
	}
}
function alipaysend($order){
	global $_G,$config;
	if(strtolower(CHARSET) == 'gbk'){
		$logistics_name = $order['logistics_name']?$order['logistics_name']:diconv($_G['setting']['bbname'],CHARSET,'UTF-8');
	}else{
		$logistics_name = $order['logistics_name']?$order['logistics_name']:$_G['setting']['bbname'];
	}
	$express = $order['express']?$order['express']:'EXPRESS';
	$params = array(
		'service' => 'send_goods_confirm_by_platform',
		'partner' => $config['pcpartner'],
		'_input_charset' => 'utf-8',
		'trade_no' => $order['transaction_id'],
		'logistics_name' => $logistics_name,
		'transport_type' => $express,
	);
	if($order['invoice_no']){
		$params['invoice_no'] = $order['invoice_no'];
	}
	$params['sign'] = getAlipaySign($params,$config['pckey']);
	$params['sign_type'] = 'MD5';
	//debug($params);
	$result=xmlToArray(postdata('https://mapi.alipay.com/gateway.do?',$params));
	//debug($result);
	return $result;

}
//send_goods_confirm_by_platform
//2088121666741802
//utf-8
//Discuz! Board
//EXPRESS
//551c788a189bfaf4d292d76214345624
//MD5
function pcalipay($args,$fare='') {
	global $_G,$config;
	//$args['price'] = $args['price'] - 0.01;
	$args['service'] = $config['service'];
	$args['partner'] = $config['pcpartner'];
	$args['_input_charset'] = 'utf-8';
	$args['quantity'] = 1;
	$args['seller_email'] = $config['pcaccount'];
	$args['extend_param'] = 'liangjian';
	$args['payment_type'] = 1;
	if($config['service'] != 'create_direct_pay_by_user') {
		$args['logistics_type'] = 'EXPRESS';//POSTƽ�� EXPRESS�������  EMS
		$fare = $fare ? $fare :'0.00';
		$args['logistics_fee'] = $fare;
		$args['logistics_payment'] = 'SELLER_PAY';//BUYER_PAY
	}
	$args['sign'] = getAlipaySign($args,$config['pckey']);
	$args['sign_type'] = 'MD5';
	ksort($args);
	return  'https://www.alipay.com/cooperate/gateway.do?'.formatBizQueryParaMap($args,true);
}
function alipayrefund($args){
	global $_G,$config;
	//$args['price'] = $args['price'] - 0.01;
	if($config['refund'] == 'refund_nopwd'){
		$args['service'] = 'refund_fastpay_by_platform_nopwd';
	}else{
		$args['service'] = 'refund_fastpay_by_platform_pwd';
	}
	$args['partner'] = $config['pcpartner'];
	$args['_input_charset'] = 'utf-8';
	$args['quantity'] = 1;
	$args['seller_email'] = $config['pcaccount'];
	$args['refund_date'] = dgmdate(TIMESTAMP,'Y-m-d H:i:s');
	//$args['batch_no'] = dgmdate(TIMESTAMP,'Ymd').rand(100,99999999);
	//$args['batch_num'] = $args['batch_num'];
	$args['sign'] = getAlipaySign($args,$config['pckey']);
	$args['sign_type'] = 'MD5';
	ksort($args);
	if($config['refund'] == 'refund_nopwd'){
		return  postdata('https://mapi.alipay.com/gateway.do?'.formatBizQueryParaMap($args,true));
	}else{
		return 'https://mapi.alipay.com/gateway.do?'.formatBizQueryParaMap($args,true);
	}
}
function alipay($parameter){
	global $_G,$config;
	$parameter['service'] = "alipay.wap.create.direct.pay.by.user";
	$parameter['partner'] = $config['mpartner'];
	$parameter['seller_id'] = $config['mpartner'];
	$parameter['payment_type'] = 1;
	$parameter['_input_charset'] = 'utf8';
	ksort($parameter);
	reset($parameter);
	$parameter['sign'] = getAlipaySign($parameter,$config['mkey']);
	$parameter['sign_type'] = 'MD5';
	return  'https://mapi.alipay.com/gateway.do?'.formatBizQueryParaMap($parameter,true);
}
function alipaytrans($out_biz_no, $payee_account='', $amount='', $remark='', $payer_show_name=''){
	global $_G,$config;
	$apiurl = 'https://openapi.alipay.com/gateway.do';
	$biz_content = array(
		'out_biz_no' => $out_biz_no,
		'payee_type' => 'ALIPAY_LOGONID',
		'payee_account' => $payee_account,
		'amount' => $amount,
		'remark' => $remark,
		'payer_show_name' => $payer_show_name
	);
	$args = array(
		'app_id' => $config['trans_appid'],
		'method' => 'alipay.fund.trans.toaccount.transfer',
		'format' => 'JSON',
		'charset' => 'utf-8',
		'sign_type' => 'RSA2',
		'timestamp' => dgmdate(TIMESTAMP,'Y-m-d H:i:s'),
		'version' => '1.0',
		'biz_content' => json_encode($biz_content),
	);
	$args['sign'] = alonersaSign(formatBizQueryParaMap($args), getcwd().'/cert/rsa_private_key.pem', 'RSA2', true);//��װ����ǩ������
	$args = getSignContentUrlencode($args);
	return postdata($apiurl, $args);
}
//�˷�����value��urlencode
function getSignContentUrlencode($params) {
	ksort($params);

	$stringToBeSigned = "";
	$i = 0;
	foreach ($params as $k => $v) {
		if ("@" != substr($v, 0, 1)) {
			if ($i == 0) {
				$stringToBeSigned .= "$k" . "=" . urlencode($v);
			} else {
				$stringToBeSigned .= "&" . "$k" . "=" . urlencode($v);
			}
			$i++;
		}
	}

	unset ($k, $v);
	return $stringToBeSigned;
}
/**
 * RSA����ǩ��������δ���ַ�������,�ַ���������getSignContent()
 * @param $data ��ǩ���ַ���
 * @param $privatekey �̻�˽Կ������keyfromfile���ж��Ƕ�ȡ�ַ������Ƕ�ȡ�ļ���false:��д˽Կ�ַ���ȥ�س��Ϳո� true:��д˽Կ�ļ�·��
 * @param $signType ǩ����ʽ��RSA:SHA1     RSA2:SHA256
 * @param $keyfromfile ˽Կ��ȡ��ʽ����ȡ�ַ������Ƕ��ļ�
 * @return string
 * @author mengyu.wh
 */
function alonersaSign($data,$privatekey,$signType = "RSA",$keyfromfile=false) {

	if(!$keyfromfile){
		$priKey=$privatekey;
		$res = "-----BEGIN RSA PRIVATE KEY-----\n" .
			wordwrap($priKey, 64, "\n", true) .
			"\n-----END RSA PRIVATE KEY-----";
	}
	else{
		$priKey = file_get_contents($privatekey);
		$res = openssl_get_privatekey($priKey);
	}
    if(!$res) {
        insertLog('res error'.$privatekey);
    }
	($res) or die('error');

	if ("RSA2" == $signType) {
		openssl_sign($data, $sign, $res, OPENSSL_ALGO_SHA256);
	} else {
		openssl_sign($data, $sign, $res);
	}

	if($keyfromfile){
		openssl_free_key($res);
	}
	$sign = base64_encode($sign);
	return $sign;
}
function getAlipaySign($Obj,$apikey=''){
	foreach ($Obj as $k => $v){
		if($k == "sign" || $k == "sign_type" || $v == ""){
			continue;
		}else{
			$parameters[$k] = $v;
		}
	}
	ksort($parameters);
	$string = formatBizQueryParaMap($parameters);
	$string = $string.$apikey;
	$string = md5($string);
	return $string;
}
function getSignVeryfy($parameters,$sign='',$mobile=''){
	global $_G,$config;
	if(empty($parameters)) {
		return false;
	}
	if($mobile == 2){
		$config['mkey'] = $config['pckey'];
	}
	ksort($parameters);

	$string = getAlipaySign($parameters,$config['mkey']);

	$veryfy_url = 'http://notify.alipay.com/trade/notify_query.do?'."partner=" .$config['mpartner']. "&notify_id=" . $parameters['notify_id'];
	if($string == $sign && postdata($veryfy_url)){
		return true;
	}
	return false;
}
/**/
function postdata($url, $para='', $input_charset = '', $follow=0) {
	//global $_G;
    if (trim($input_charset) != '') {
        $url = $url."_input_charset=".$input_charset;
    }
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_HEADER, 0 );
    curl_setopt($curl,CURLOPT_RETURNTRANSFER, 1);
	//curl_setopt ($ch,CURLOPT_REFERER,$_G['siteurl']);
	if($para){
		curl_setopt($curl,CURLOPT_POST,true);
		curl_setopt($curl,CURLOPT_POSTFIELDS,$para);
	}
    if($follow) {
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($curl, CURLOPT_MAXREDIRS, 3);
    }
    $responseText = curl_exec($curl);
    $headers = curl_getinfo($curl);
    curl_close($curl);
    if($para&& $headers && $headers['url'] && $follow) {
         header('Location: '.$headers['url']);
    }
    //var_dump( curl_error($curl) );
    return $responseText;
}
function wxpay($parameters){
	global $_G,$config;
	$timestamp = $_G['timestamp'];
	$jsApiObj["appId"] = $config['appid'];
	$jsApiObj["timeStamp"] = "$timestamp";
	$jsApiObj["nonceStr"] = createNoncestr();
	$jsApiObj["package"] = "prepay_id=".getPrepayId1($parameters);
	$jsApiObj["signType"] = "MD5";
	$jsApiObj["paySign"] = getSign($jsApiObj,$config['key']);

	return json_encode($jsApiObj);
}



function apppay($parameters){
	global $_G,$config;
	$timestamp = $_G['timestamp'];
	$apppay = array();
	$apppay['appid'] = $config["appid2"];
	$apppay['partnerid'] = $config["mchid2"];
	$apppay['prepayid'] = getPrepayId2($parameters);
	$apppay['noncestr'] = createNoncestr();
	$apppay['timestamp'] = "$timestamp";
	$apppay['package'] = "Sign=WXPay";
	$apppay['sign'] = getSign($apppay,$config['key2']);
	return $apppay;
}

function wxh5pay($parameters){
	global $_G,$config;

	return getPrepayId_h5($parameters);
}

function getPrepayId_h5($parameters){
	global $_G,$config;
	$parameters["trade_type"] = 'MWEB';
	$parameters["appid"] = $config['appid'];
	$parameters["mch_id"] = $config['mchid'];
	$parameters["spbill_create_ip"] = $_G['clientip'];
	$parameters["nonce_str"] = createNoncestr();
	$parameters["sign"] = getSign($parameters,$config['key']);
	//debug($parameters);
	$prepaystr = postXmlCurl(arrayToXml($parameters),"https://api.mch.weixin.qq.com/pay/unifiedorder");
	$postObj = xmlToArray($prepaystr);
	//debug(diconv($postObj['return_msg'], 'utf-8', 'gbk'));
	return $postObj['mweb_url'];
}

function getPrepayId1($parameters){
	global $_G,$config;
	$parameters["trade_type"] = 'JSAPI';
	$parameters["appid"] = $config['appid'];
	$parameters["mch_id"] = $config['mchid'];
	$parameters["spbill_create_ip"] = $_G['clientip'];
	$parameters["nonce_str"] = createNoncestr();
	$parameters["sign"] = getSign($parameters,$config['key']);

	$prepaystr = postXmlCurl(arrayToXml($parameters),"https://api.mch.weixin.qq.com/pay/unifiedorder");
	$postObj = xmlToArray($prepaystr);
    if($postObj['return_code'] != 'SUCCESS'){
        $error = json_encode($postObj);
        if(strtolower(CHARSET) == 'gbk') {
            $error = diconv($error,'utf-8','gbk');
        }
        insertLog('wxpay '.$error);
    }
	return $postObj['prepay_id'];
}
function insertLog($error) {
    DB::insert('aljgwc_payorderlog',array(
        'error'=> $error,
        'time'=> time(),
    ));
}
function getPrepayId2($parameters){
	global $_G,$config;
	$parameters["trade_type"] = 'APP';
	$parameters["appid"] = $config['appid2'];
	$parameters["mch_id"] = $config['mchid2'];
	$parameters["spbill_create_ip"] = $_G['clientip'];
	$parameters["nonce_str"] = createNoncestr();
	$parameters["sign"] = getSign($parameters,$config['key2']);
	$prepaystr = postXmlCurl(arrayToXml($parameters),"https://api.mch.weixin.qq.com/pay/unifiedorder");
	$postObj = xmlToArray($prepaystr);
	return $postObj['prepay_id'];
}
function createorder($orderparams){

	$orderparams['createtime'] = TIMESTAMP;
	C::t('#aljgwc#aljgwc_order') -> insert($orderparams);
}

function getorderid(){
	$orderid = 'wx'.random(7).dgmdate(TIMESTAMP, 'His');
	$check = C::t('#aljgwc#aljgwc_order') -> fetch($orderid);
	while($check){
		$orderid = 'wx'.random(7).dgmdate(TIMESTAMP, 'His');
	}
	return $orderid;
}

function mtips($tips){
	echo '<script>parent.alert("'.$tips.'")</script>';
	exit;
}
function postxml($url,$data=array()){
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_MUTE, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: text/xml'));
	curl_setopt($ch, CURLOPT_POSTFIELDS, "$data");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$output = curl_exec($ch);
	curl_close($ch);
	return $output;
}
function createNoncestr( $length = 32 ){
	$chars = "abcdefghijklmnopqrstuvwxyz0123456789";
	$str ="";
	for ( $i = 0; $i < $length; $i++ )  {
		$str.= substr($chars, mt_rand(0, strlen($chars)-1), 1);
	}
	return $str;
}
function getSign($Obj,$apikey=''){
	foreach ($Obj as $k => $v)
	{
		$parameters[$k] = $v;
	}
	ksort($parameters);
	$string = formatBizQueryParaMap($parameters, false);
	$string = $string."&key=$apikey";
	$string = md5($string);
	$result_ = strtoupper($string);
	return $result_;
}
function formatBizQueryParaMap($paraMap, $urlencode=false){
	$buff = "";
	ksort($paraMap);
	foreach ($paraMap as $k => $v)
	{
		if($urlencode)
		{
		   $v = urlencode($v);
		}
		$buff .= $k . "=" . $v . "&";
	}
	$reqPar;
	if (strlen($buff) > 0)
	{
		$reqPar = substr($buff, 0, strlen($buff)-1);
	}
	return $reqPar;
}
function arrayToXml($arr){
	$xml = "<xml>";
	foreach ($arr as $key=>$val)
	{
		 if (is_numeric($val))
		 {
			$xml.="<".$key.">".$val."</".$key.">";

		 }
		 else
			$xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
	}
	$xml.="</xml>";
	return $xml;
}
function xmlToArray($xml){
    //��XMLתΪarray
    //��ֹ�����ⲿxmlʵ��
    libxml_disable_entity_loader(true);
	$array_data = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
	return $array_data;
}
function postXmlCurl($xml,$url,$second=30,$pem='',$location=''){
	$ch = curl_init();
	curl_setopt($ch, CURLOP_TIMEOUT, $second);
	curl_setopt($ch,CURLOPT_URL, $url);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
	curl_setopt($ch, CURLOPT_HEADER, FALSE);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	curl_setopt($ch, CURLOPT_POST, TRUE);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
    if($pem){
        curl_setopt($ch,CURLOPT_SSLCERT,getcwd().$location.'/cert/apiclient_cert.pem');
        curl_setopt($ch,CURLOPT_SSLKEY,getcwd().$location.'/cert/apiclient_key.pem');
        curl_setopt($ch,CURLOPT_CAINFO,getcwd().$location.'/cert/rootca.pem');
    }
	$data = curl_exec($ch);
	curl_close($ch);
	if($data){
		curl_close($ch);
		return $data;
	}
}
function createOauthUrlForCode($redirectUrl){
	global $config;
	$urlObj["appid"] = $config['appid'];
	$urlObj["redirect_uri"] = "$redirectUrl";
	$urlObj["response_type"] = "code";
	$urlObj["scope"] = "snsapi_base";
	$urlObj["state"] = "STATE"."#wechat_redirect";
	$bizString = formatBizQueryParaMap($urlObj, false);

	return "https://open.weixin.qq.com/connect/oauth2/authorize?".$bizString;
}
function getopenid($orderid){
	global $_G,$config;
	if($config['OAuth']){
		$_G[siteurl] = $config['OAuth'];
	}
	if (!isset($_GET['code'])){
		$order=C::t('#aljgwc#aljbd_goods_order')->fetch($orderid);
		if($order['pid'] == 1){
			$biaoshi = '%26pluginid=aljtg';
		}else if($order['pid'] == 2){
			$biaoshi = '%26pluginid=aljsc';
		}else{
			$biaoshi = '%26pluginid=aljbd';
		}
		$url = createOauthUrlForCode($_G['siteurl'].'plugin.php?id=aljgwc%26act=cart_pay%26orderid='.$orderid.$biaoshi);
		Header("Location: $url");
	}else{

		$code = $_GET['code'];
	}
	$url="https://api.weixin.qq.com/sns/oauth2/access_token?appid=".$config['appid']."&secret=".$config['appsecret']."&code=$code&grant_type=authorization_code";
	$result = postXmlCurl('',$url);
	$jsoninfo = json_decode($result, true);
    if(isset($jsoninfo['errcode'])) {
        if(strtolower(CHARSET) == 'gbk') {
            $error = diconv($result,'utf-8','gbk');
        }else {
            $error = $result;
        }
        insertLog('wxopenid '.$error);
    }
	return $jsoninfo["openid"];

}
function getcodeurl($parameters){
	global $_G,$config;
	$parameters["trade_type"] = 'NATIVE';
	$parameters["appid"] = $config['appid'];
	$parameters["mch_id"] = $config['mchid'];
	$parameters["spbill_create_ip"] = $_G['clientip'];
	$parameters["nonce_str"] = createNoncestr();
	$parameters["sign"] = getSign($parameters,$config['key']);
	$prepaystr = postXmlCurl(arrayToXml($parameters),"https://api.mch.weixin.qq.com/pay/unifiedorder");
	$postObj = xmlToArray($prepaystr);
	return $postObj['code_url'];
}
function wxpayrefund($senddata){
    global $_G,$config;
    $url = 'https://api.mch.weixin.qq.com/secapi/pay/refund';
    $sendredpack['nonce_str'] = createNoncestr();
    $sendredpack['mch_id'] = $senddata['mch_id'];
    $sendredpack['appid'] = $senddata['appid'];
    $sendredpack['op_user_id'] = $senddata['mch_id'];
    $sendredpack['transaction_id'] = $senddata['orderid'];
    $sendredpack['total_fee'] = $senddata['price']*100;
    $sendredpack['refund_fee'] = $senddata['refund_fee']?$senddata['refund_fee']*100:$senddata['price']*100;
    $sendredpack['out_refund_no'] = $senddata['out_refund_no'];
    if(!$senddata['location']){
        insertLog('wxpay &#36864;&#27454;&#35777;&#20070;&#26410;&#37197;&#32622;');
    }
    //$sendredpack['refund_account'] = 'REFUND_SOURCE_RECHARGE_FUNDS';
    $sendredpack['sign'] = getSign($sendredpack,$senddata['key']);
    $result = postXmlCurl(arrayToXml($sendredpack),$url,30,true,$senddata['location']);
    $data = xmlToArray($result);
    if($data['return_code'] == 'FAIL'){
        if(strtolower(CHARSET) == 'gbk') {
            $error = diconv($data['return_msg'],'utf-8','gbk');
        }
        insertLog('wxpayrefund '.$error);
    }
    //debug(diconv($result,'utf-8','gbk'));
    return $result;
}
function wxpayrefundquery($senddata){
    global $_G,$config;
    $url = 'https://api.mch.weixin.qq.com/pay/refundquery';
    $sendredpack['nonce_str'] = createNoncestr();
    $sendredpack['mch_id'] = $senddata['mch_id'];
    $sendredpack['appid'] = $senddata['appid'];
    $sendredpack['transaction_id'] = $senddata['orderid'];
    $sendredpack['sign'] = getSign($sendredpack,$senddata['key']);
	//debug($sendredpack);
    $result = postXmlCurl(arrayToXml($sendredpack),$url,30,true,$senddata['location']);
    //debug(diconv($result,'utf-8','gbk'));
    return $result;
}
function mmpaymkttransfers($senddata,$location=''){
    global $_G,$config;
    $result_code = DB::result_first("select result_code from %t where fromorderid=%s and fromorderid is not null and fromorderid !=''",array('aljjs_transfer',$senddata['fromorderid']));
    if($result_code == 'SUCCESS' || empty($senddata['amount']) || empty($senddata['openid']) || empty($senddata['bid'])){
        return;
    }
    $url = 'https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers';
    $sendredpack['nonce_str'] = createNoncestr();
    $sendredpack['mchid'] = $config['mchid'];
    $sendredpack['mch_appid'] = $config['appid'];
    $sendredpack['partner_trade_no'] = $senddata['orderid'];
    $sendredpack['openid'] = $senddata['openid'];
    $sendredpack['check_name'] = 'NO_CHECK';
    $sendredpack['amount'] = $senddata['amount']*100-$senddata['amount']*100*$senddata['per'];
    $sendredpack['desc'] = $senddata['desc']?diconv($senddata['desc'],CHARSET,'utf-8'):diconv('test',CHARSET,'utf-8');
    $sendredpack['spbill_create_ip'] = $_G['clientip'];
	//debug($sendredpack);
    $sendredpack['sign'] = getSign($sendredpack,$config['key']);
    $result = postXmlCurl(arrayToXml($sendredpack),$url,30,true,$location);
    //$result = diconv($result,'utf-8',CHARSET);
    $result = xmlToArray($result);
    if($result['result_code'] == 'FAIL'){
        $return_msg = diconv($result['return_msg'],'utf-8',CHARSET);
    }

    DB::query('update %t set result_code=%s,return_msg=%s,payment_no=%s,payment_time=%s where orderid=%s',array('aljjs_transfer',$result['result_code'],$return_msg,$result['payment_no'],$result['payment_time'],$senddata['orderid']));

    return $result;
}
function insert_aljjs_transfer($openid,$cashmoney='',$bid=''){
	global $_G,$config;
	$orderid = $config['mchid'].dgmdate(TIMESTAMP,'Ymd').TIMESTAMP;
	$fee = sprintf("%1.2f",$cashmoney*$_G['cache']['plugin']['aljjs']['per']);
	$user = DB::fetch_first('select * from %t where openid=%s',array('aljwsq_mapp_user',$openid));
	DB::insert('aljjs_transfer',array(
		'orderid' => $orderid,
		'openid' => $openid,
		'uid' => $user['uid'],
		'bid' => $bid,
		'username' => $user['username'],
		'amount' => $cashmoney,
		'toaccountmoney' => $cashmoney-$fee,
		'fee' => $fee,
		'spbill_create_ip' => $_G['clientip'],
		'desc' => $_G['cache']['plugin']['aljjs']['mycashtips'],
		'dateline' => TIMESTAMP,
	));
	return $orderid;
}
function mapp_userlogin($username, $password, $questionid='', $answer='', $loginfield = 'username', $ip = '') {
    $return = array();

    if($loginfield == 'uid' && getglobal('setting/uidlogin')) {
        $isuid = 1;
    } elseif($loginfield == 'email') {
        $isuid = 2;
    } elseif($loginfield == 'auto') {
        $isuid = 3;
    } else {
        $isuid = 0;
    }

    if(!function_exists('uc_user_login')) {
        loaducenter();
    }
    if($isuid == 3) {
        if(!strcmp(dintval($username), $username) && getglobal('setting/uidlogin')) {
            $return['ucresult'] = uc_user_login($username, $password, 1, 0, $questionid, $answer, $ip);
        } elseif(isemail($username)) {
            $return['ucresult'] = uc_user_login($username, $password, 2, 0, $questionid, $answer, $ip);
        }
        if($return['ucresult'][0] <= 0 && $return['ucresult'][0] != -3) {
            $return['ucresult'] = uc_user_login(addslashes($username), $password, 0, 0, $questionid, $answer, $ip);
        }
    } else {
        $return['ucresult'] = uc_user_login(addslashes($username), $password, $isuid, 0, $questionid, $answer, $ip);
    }
    $tmp = array();
    $duplicate = '';
    list($tmp['uid'], $tmp['username'], $tmp['password'], $tmp['email'], $duplicate) = $return['ucresult'];
    $return['ucresult'] = $tmp;
    if($duplicate && $return['ucresult']['uid'] > 0 || $return['ucresult']['uid'] <= 0) {
        $return['status'] = 0;
        return $return;
    }

    $member = getuserbyuid($return['ucresult']['uid'], 1);
    if(!$member || empty($member['uid'])) {
        $return['status'] = -1;
        return $return;
    }
    $return['member'] = $member;
    $return['status'] = 1;
    if($member['_inarchive']) {
        C::t('common_member_archive')->move_to_master($member['uid']);
    }
    if($member['email'] != $return['ucresult']['email']) {
        C::t('common_member')->update($return['ucresult']['uid'], array('email' => $return['ucresult']['email']));
    }

    return $return;
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>
