<?php
/*
 * User: DisM!Ӧ������
 * ���²����http://t.cn/Aiux1Jx1
 *
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljgwc_region extends discuz_table{
	public function __construct() {

			$this->_table = 'aljgwc_region';
			$this->_pk    = 'id';

			parent::__construct(); /*dism �� taobao �� com*/
	}
    public function fetch_all_json()
    {
        $result = $this->fetch_all_by_upid_json(0);

        foreach ($result as $index => $item) {
            $result[$index]['name'] = diconv($item['name'], CHARSET, 'utf-8');
            $subregion = $this->fetch_all_by_upid_json($item['id']);
            if($subregion){
                foreach ($subregion as $subk => $subv){
                    $subregion[$subk]['name'] = diconv($subv['name'], CHARSET, 'utf-8');
                    $subsubregion = $this->fetch_all_by_upid_json($subv['id']);
                    if($subsubregion){
                        foreach($subsubregion as $subsubk => $subsubv){
                            $subsubregion[$subsubk]['name'] = diconv($subsubv['name'], CHARSET, 'utf-8');
                        }
                        $subregion[$subk]['sub'] = $subsubregion;
                    }else{
                        $subsubregion_1[0]['name'] = '--';
                        $subsubregion_1[0]['code'] = '0';
                        $subregion[$subk]['sub'] = $subsubregion_1;
                    }
                }
            }else{
                $subregion[0]['name'] = '--';
                $subregion[0]['code'] = '0';
                $subsubregion_1[0]['name'] = '--';
                $subsubregion_1[0]['code'] = '0';
                $subregion[0]['sub'] = $subsubregion_1;
            }
            $result[$index]['sub'] = $subregion;
        }
        return $result;
    }
    public function fetch_all_by_upid_json($upid=0){
        $carray[]=$this->_table;
        if($upid){
            $carray[]=$upid;
            $conn=' where upid=%d';
        }else{
            $conn=' where upid=0';
        }
        $conn.= ' order by displayorder asc,id asc ';
        return DB::fetch_all('select `name`,upid,id,id as code from %t '.$conn,$carray);
    }
	public function fetch_upid_by_id($id=0){
		return DB::result_first('SELECT upid FROM %t WHERE id=%d',array($this->_table,$id));
	}
	public function fetch_subid_by_id($id=0){
		return DB::result_first('SELECT subid FROM %t WHERE id=%d',array($this->_table,$id));
	}
	public function fetch_all_by_upid($upid=0){
		return DB::fetch_all('SELECT * FROM %t WHERE upid=%d ORDER BY displayorder ASC',array($this->_table,$upid),'id');
	}
	public function fetch_all_by_type($type=0){
		return DB::fetch_all('select * from %t where id=%d ORDER BY displayorder ASC',array($this->_table,$type));
	}
	public function fetch_all_by_upid_admin($start=0,$limit=0,$upid=0){
		$carray[]=$this->_table;
		if($upid){
			$carray[]=$upid;
			$conn=' where upid=%d';
		}else{
			$conn=' where upid=0';
		}
		$conn.= ' order by displayorder asc ';
		if($start&&$limit){
			$carray[]=$start;
			$carray[]=$limit;
			$conn.='limit %d,%d';
		}
		
		return DB::fetch_all('select * from %t '.$conn,$carray,'catid');
	}
	public function fetch_all_by_upid_sys($upid=0){
		$carray[]='common_district';
		if($upid){
			$carray[]=$upid;
			$conn=' where upid=%d';
		}else{
			$conn=' where upid=0';
		}
		
		return DB::fetch_all('select * from %t '.$conn,$carray,'id');
	}
	public function count_by_upid($upid=0) {
		$carray[]=$this->_table;
		if($upid){
			$carray[]=$upid;
			$conn=' where upid=%d';
		}else{
			$conn=' where upid=0';
		}
		return DB::result_first("SELECT count(*) FROM %t ".$conn,$carray,'catid');
	}
	public function fetch_first_by_name($name='', $upid=0) {
		return DB::fetch_first("SELECT * FROM %t WHERE name = %s and upid=%d", array('common_district',$name, $upid));
	}
	public function fetch_first_by_id($id=0) {
		return DB::fetch_first('SELECT * FROM %t WHERE id=%d', array('common_district', $id));
	}
}



//From: Dism_taobao-com
?>