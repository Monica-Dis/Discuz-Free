<?php
/*
	Copyright (c) 2021 by dism.taobao.com
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
//start to put your own code 
$sql = <<<EOF
DROP TABLE IF  EXISTS `pre_aljgwc`;
DROP TABLE IF  EXISTS `pre_aljbd_goods_order`;
DROP TABLE IF  EXISTS `pre_aljbd_goods_order_list`;
DROP TABLE IF  EXISTS `pre_aljbd_goods_settle`;
DROP TABLE IF  EXISTS `pre_aljbd_address`;
DROP TABLE IF  EXISTS `pre_aljgwc_statistics`;
DROP TABLE IF  EXISTS `pre_aljgwc_region`;
DROP TABLE IF  EXISTS `pre_aljbd_comment_goods`;
DROP TABLE IF  EXISTS `pre_aljgwc_refund`;
EOF;
if(file_exists("source/plugin/aljhtx/aljhtx.inc.php")) {
	$un_set = DB::fetch_all('select * from %t', array('aljhtx_system_setting'),'skey');
	if($un_set['is_del_mysql']['svalue']){
		runquery($sql);	
	}
}
//finish to put your own code
$finish = TRUE;
?>