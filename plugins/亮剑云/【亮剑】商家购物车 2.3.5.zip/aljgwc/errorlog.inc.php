<?php

/*
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$pluginid = 'aljgwc';
$currpage = $_GET['page'] ? intval($_GET['page']) : 1;
$perpage = 16;
$start = ($currpage - 1) * $perpage;
$where  = 'where 1 ';
$conn=array($pluginid.'_payorderlog');
$num = DB::result_first('select count(*) from %t '.$where,$conn);
$where .=  'order by id desc limit %d,%d';
$conn[] = $start;
$conn[] = $perpage;
$errorlist = DB::fetch_all('select * from %t '.$where,$conn);
$paging = helper_page :: multi($num, $perpage, $currpage, 'admin.php?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier='.$pluginid.'&pmod=errorlog', 0, 11, false, false);
include template($pluginid.':errorlog');
?>