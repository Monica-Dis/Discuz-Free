<?php

/*
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 */


if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

define('LOGIN_URL', 'member.php?mod=logging&action=login&referer=plugin.php?id=aljav');

if(empty($_G['uid'])){
    dheader("location:" . LOGIN_URL);
    exit;
}

$version = '2020091901';
$config = $_G['cache']['plugin']['aljav'];
loaducenter();
if($_G['cache']['plugin']['aljwsq'] && $_G['cache']['plugin']['mapp_wechat']){
    if(!aljav_getuseraction($_G['uid'],'mapp_wechat','changeusername') && aljav_getuseraction($_G['uid'],'mapp_wechat','register')){
        $allow_username = true;
    }
}
if(submitcheck('formhash')){
    
    if($_GET['logourl']){
        require_once 'source/plugin/aljhtx/class/class_aljhtx.php';
        $src = T::h5Caesium($_GET['logourl'],'source/plugin/aljav/static/cache/');

        if($config['is_remote_uc']){
            require_once 'source/plugin/aljwsq/function_core.php';
            if(function_exists('AljSyncAvatar')){
                AljSyncAvatar($_G['uid'], $_G['siteurl'].$src);
            }
        }else{
            aljav($_G['uid'], $src);
        }
        
    }
    if($_GET['password']){
        
        aljav_change_password($_GET['password']);
    }
    if($_GET['newusername'] && $allow_username){
        aljav_change_username($_GET['newusername']);
    }
    echo '<script>parent.tips();</script>';
    exit;
}else{
    include template('aljav:aljav');
}

function aljav_getuseraction($uid,$appid = '',$action = ''){
    return DB::fetch_first('select * from %t where uid = %d and appid = %s and action = %s',array('aljwsq_mapp_action_log',$uid,$appid,$action));
}

function aljav_change_username($newusername) {
    global $_G;
    if(aljav_check_username($newusername)){
        luseractionlog($_G['uid'],'mapp_wechat','changeusername');
        DB::query('UPDATE %t SET username = %s WHERE username = %s', array('aljwsq_mapp_user', $newusername, $_G['member']['username']));
        DB::query('UPDATE %t SET username = %s WHERE username = %s', array('common_member', $newusername, $_G['member']['username']));
        DB::query("UPDATE ".UC_DBTABLEPRE."members SET username='$newusername' WHERE username='{$_G[member][username]}'");
        C::t('common_member')->update_cache($_G['uid'], array('username' => $newusername));
    }
    
}
function luseractionlog($uid,$appid = '',$action = '',$ext = '',$desc = ''){
	DB::insert('aljwsq_mapp_action_log',array(
		'uid' => $uid,
		'appid' => $appid,
		'action' => $action,
		'dateline' => TIMESTAMP,
		'ext' => $ext,
		'desc' => $desc,
	));
}
function aljav_check_username($username) {
    global $_G;
    $username = trim($username);
    $usernamelen = dstrlen($username);
    if($usernamelen < 4) {
        echo '<script>parent.error("'.lang('message', 'profile_username_tooshort').'");</script>';
        exit;
    } elseif($usernamelen > 15) {
        echo '<script>parent.error("'.lang('message', 'profile_username_toolong').'");</script>';
        exit;
    }
    $ucresult = uc_user_checkname($username);
    if($ucresult == -1) {
        echo '<script>parent.error("'.lang('message', 'profile_username_duplicate').'");</script>';
        exit;
    } elseif($ucresult == -2) {
        echo '<script>parent.error("'.lang('message', 'profile_username_protect').'");</script>';
        exit;
    } elseif($ucresult == -3) {
        if(C::t('common_member')->fetch_by_username($username) || C::t('common_member_archive')->fetch_by_username($username)) {
            echo '<script>parent.error("'.lang('message', 'register_activation').'");</script>';
            exit;
        } else {
            echo '<script>parent.error("'.lang('message', 'register_activation').'");</script>';
            exit;
        }
    }
    $censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';
    if($_G['setting']['censoruser'] && @preg_match($censorexp, $username)) {
        echo '<script>parent.error("'.lang('message', 'profile_username_protect').'");</script>';
        exit;
    }
    return true;
}

function aljav_change_password($password){
    global $_G;
    if($_G['setting']['pwlength']) {
        if(strlen($password) < $_G['setting']['pwlength']) {
            echo '<script>parent.error("'.str_replace('{pwlength}',$_G['setting']['pwlength'],lang('message', 'profile_password_tooshort')).'");</script>';
            exit;
        }
    }
    if($_G['setting']['strongpw']) {
        $strongpw_str = array();
        if(in_array(1, $_G['setting']['strongpw']) && !preg_match("/\d+/", $password)) {
            $strongpw_str[] = lang('member/template', 'strongpw_1');
        }
        if(in_array(2, $_G['setting']['strongpw']) && !preg_match("/[a-z]+/", $password)) {
            $strongpw_str[] = lang('member/template', 'strongpw_2');
        }
        if(in_array(3, $_G['setting']['strongpw']) && !preg_match("/[A-Z]+/", $password)) {
            $strongpw_str[] = lang('member/template', 'strongpw_3');
        }
        if(in_array(4, $_G['setting']['strongpw']) && !preg_match("/[^a-zA-z0-9]+/", $password)) {
            $strongpw_str[] = lang('member/template', 'strongpw_4');
        }
        if($strongpw_str) {
            echo '<script>parent.error("'.lang('member/template', 'password_weak').implode(',', $strongpw_str).'");</script>';
            exit;
        }
    }
    uc_user_edit($_G['username'],'',$password,'',1,0,'');
}

function aljav($uid,$tmppic){
	$uid = sprintf("%09d", $uid);
    $dir = aljav_mkdir_by_uid($uid);
    @copy($tmppic, $dir.substr($uid,-2).'_avatar_big.jpg');
    @copy($tmppic, $dir.substr($uid,-2).'_avatar_middle.jpg');
    @copy($tmppic, $dir.substr($uid,-2).'_avatar_small.jpg');
	@unlink($tmppic);
	DB::update('common_member',array('avatarstatus'=>1),array('uid'=>$uid));
}

function aljav_mkdir_by_uid($uid, $dir = './uc_server/data/avatar/') {
	$uid = sprintf("%09d", $uid);
	$dir1 = substr($uid, 0, 3);
	$dir2 = substr($uid, 3, 2);
	$dir3 = substr($uid, 5, 2);
	!is_dir($dir.'/'.$dir1) && mkdir($dir.'/'.$dir1, 0777);
	!is_dir($dir.'/'.$dir1.'/'.$dir2) && mkdir($dir.'/'.$dir1.'/'.$dir2, 0777);
	!is_dir($dir.'/'.$dir1.'/'.$dir2.'/'.$dir3) && mkdir($dir.'/'.$dir1.'/'.$dir2.'/'.$dir3, 0777);
	return $dir.'/'.$dir1.'/'.$dir2.'/'.$dir3.'/';
}