<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//start to put your own code

$install_eol = "\\r\\n";
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljtc` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `addtime` int(10) NOT NULL,
  `updatetime` int(10) NOT NULL,
  `zufangtype` int(11) NOT NULL,
  `subtype` int(10) NOT NULL,
  `subsubtype` int(10) NOT NULL,
  `content` mediumtext NOT NULL,
  `region` int(11) NOT NULL,
  `region1` int(10) NOT NULL,
  `region2` varchar(255) NOT NULL,
  `region3` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `views` mediumint(9) NOT NULL,
  `displayorder` int(11) NOT NULL,
  `lxr` varchar(255) NOT NULL,
  `topstime` int(11) NOT NULL,
  `topetime` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `solve` tinyint(3) NOT NULL,
  `label` varchar(255) NOT NULL,
  `form` text NOT NULL,
  `pic` text NOT NULL,
  `lat` decimal(10,6) NOT NULL,
  `lng` decimal(10,6) NOT NULL,
  `fz_id` int(11) NOT NULL,
  `expiry_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `title` (`title`),
  KEY `lat` (`lat`),
  KEY `lng` (`lng`),
  KEY `addtime` (`addtime`),
  KEY `updatetime` (`updatetime`),
  KEY `displayorder` (`displayorder`),
  KEY `uid` (`uid`),
  KEY `topetime` (`topetime`),
  KEY `fz_id` (`fz_id`),
  KEY `expiry_time` (`expiry_time`)
);
CREATE TABLE IF NOT EXISTS `pre_aljtc_typesettings` (
  `id` int(10) NOT NULL auto_increment,
  `typeid` int(10) NOT NULL,
  `type_key` varchar(255) NOT NULL,
  `type_value` text NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljtc_typesettings` (
  `id` int(10) NOT NULL auto_increment,
  `typeid` int(10) NOT NULL,
  `type_key` varchar(255) NOT NULL,
  `type_value` text NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljtc_position` (
  `id` mediumint(9) unsigned NOT NULL auto_increment,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  `is_open` tinyint(3) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljtc_reflashlog` (
  `id` int(11) NOT NULL auto_increment,
  `lid` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `pay` int(10) NOT NULL,
  `extcredit` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljtc_region` (
  `id` mediumint(9) unsigned NOT NULL auto_increment,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  `level` tinyint(3) NOT NULL,
  `havechild` tinyint(3) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljtc_toplog` (
  `id` int(10) NOT NULL auto_increment,
  `lid` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `pay` int(10) NOT NULL,
  `extcredit` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `endtime` int(11) NOT NULL,
  `status` TINYINT(3) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljtc_comment` (
  `id` int(11) NOT NULL auto_increment,
  `upid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `lid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `content` mediumtext NOT NULL,
  `uuid` int(11) NOT NULL,
  `uusername` varchar(255) NOT NULL,
  `status` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `upid` (`upid`),
  KEY `dateline` (`dateline`),
  KEY `lid` (`lid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljtc_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljtc_praise` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljtc_setting` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`key`)
);
CREATE TABLE IF NOT EXISTS `pre_aljtc_attachment` (
  `aid` int(10) NOT NULL AUTO_INCREMENT,
  `pic` varchar(255) NOT NULL,
  `pid` int(10) NOT NULL,
  PRIMARY KEY (`aid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljtc_attestation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `gongsiname` varchar(255) NOT NULL,
  `num` bigint(20) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `sign` tinyint(4) NOT NULL,
  `fz_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljtc_custom` (
  `custom_id` int(10) NOT NULL AUTO_INCREMENT,
  `custom_type` varchar(50) NOT NULL,
  `custom_name` varchar(255) NOT NULL,
  `custom_title` varchar(255) NOT NULL,
  `custom_change` tinyint(4) NOT NULL,
  `custom_required` tinyint(4) NOT NULL,
  `custom_extra` text NOT NULL,
  `custom_order` int(10) NOT NULL,
  `custom_unit` varchar(255) NOT NULL,
  `custom_state` int(10) NOT NULL,
  `typeid` int(10) NOT NULL,
  PRIMARY KEY (`custom_id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_goods_order` (
  `orderid` char(32) NOT NULL DEFAULT '',
  `status` tinyint(3) NOT NULL,
  `buyer` char(50) NOT NULL DEFAULT '',
  `admin` char(15) NOT NULL DEFAULT '',
  `uid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `stitle` varchar(255) NOT NULL,
  `amount` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `price` float(7,2) UNSIGNED NOT NULL DEFAULT '0.00',
  `original_price` decimal(8,2) UNSIGNED NOT NULL DEFAULT '0.00',
  `submitdate` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `confirmdate` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `email` char(40) NOT NULL DEFAULT '',
  `ip` char(15) NOT NULL DEFAULT '',
  `remarks` varchar(255) NOT NULL,
  `d` tinyint(3) NOT NULL,
  `address` text NOT NULL,
  `payment` char(50) NOT NULL DEFAULT '',
  `fare` decimal(8,2) UNSIGNED NOT NULL DEFAULT '0.00',
  `pid` tinyint(3) NOT NULL,
  `category` tinyint(3) NOT NULL,
  `fare_desc` int(11) NOT NULL,
  `mobile` int(11) NOT NULL,
  `proportion` int(11) NOT NULL,
  `browser` varchar(255) NOT NULL,
  `deliverydate` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `ext` int(11) NOT NULL,
  `pay_ext` int(11) NOT NULL,
  `discount` decimal(8,2) UNSIGNED NOT NULL DEFAULT '0.00',
  `bili` int(10) NOT NULL,
  `commodity_type` tinyint(3) NOT NULL,
  `get_to_the_shop` tinyint(3) NOT NULL,
  `collage_order` char(32) NOT NULL,
  `collage_num` int(10) NOT NULL,
  `cid` int(10) NOT NULL,
  `opentime` int(11) NOT NULL,
  `give_integral` int(11) NOT NULL,
  `pay_integral` decimal(10,2) NOT NULL,
  `store_id` int(11) NOT NULL,
  `fz_id` int(11) NOT NULL,
  `store_address` text NOT NULL,
  `order_type` tinyint(4) NOT NULL COMMENT '1=ms 2=fx 3=wm',
  `deduction` decimal(10,2) NOT NULL,
  UNIQUE KEY `orderid` (`orderid`),
  KEY `submitdate` (`submitdate`),
  KEY `uid` (`uid`,`submitdate`)
);
CREATE TABLE IF NOT EXISTS `pre_aljtc_see_tel` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `lid` int(11) DEFAULT '0',
  `addtime` int(11) DEFAULT '0',
  `customid` int(11) DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`)
);
EOF;
runquery($sql);
$sql = <<<EOF
replace INTO `pre_aljtc_position` (`id`, `upid`, `subid`, `subject`, `logo`, `displayorder`) VALUES
(1, 0, '', '$installlang[install_php_1]', 'source/plugin/aljtc/images/nav/sfc.png', 0),
(2, 0, '', '$installlang[install_php_2]', 'source/plugin/aljtc/images/nav/zp.png', 0),
(3, 0, '', '$installlang[install_php_3]', 'source/plugin/aljtc/images/nav/bdfw.png', 0),
(4, 0, '', '$installlang[install_php_4]', 'source/plugin/aljtc/images/nav/fwzc.png', 0),
(5, 0, '', '$installlang[install_php_5]', 'source/plugin/aljtc/images/nav/syzr.png', 0),
(6, 0, '', '$installlang[install_php_6]', 'source/plugin/aljtc/images/nav/qcjy.png', 0),
(7, 0, '', '$installlang[install_php_7]', 'source/plugin/aljtc/images/nav/eswp.png', 0),
(8, 0, '', '$installlang[install_php_8]', 'source/plugin/aljtc/images/nav/yhxx.png', 0),
(9, 0, '', '$installlang[install_php_9]', 'source/plugin/aljtc/images/nav/zhjy.png', 0),
(10, 0, '', '$installlang[install_php_10]', 'source/plugin/aljtc/images/nav/dts.png', 0),
(11, 0, '', '$installlang[install_php_11]', 'source/plugin/aljtc/images/nav/nlmy.png', 0),
(12, 1, '', '$installlang[install_php_12]', '', 0),
(13, 1, '', '$installlang[install_php_13]', '', 0),
(14, 1, '', '$installlang[install_php_14]', '', 0),
(15, 1, '', '$installlang[install_php_15]', '', 0),
(16, 2, '', '$installlang[install_php_16]', '', 0),
(17, 2, '', '$installlang[install_php_17]', '', 0),
(18, 16, '', '$installlang[install_php_18]', '', 0),
(19, 16, '', '$installlang[install_php_19]', '', 0),
(20, 16, '', '$installlang[install_php_20]', '', 0),
(21, 16, '', '$installlang[install_php_21]', '', 0),
(22, 16, '', '$installlang[install_php_22]', '', 0),
(23, 16, '', '$installlang[install_php_23]', '', 0),
(24, 16, '', '$installlang[install_php_24]', '', 0),
(25, 16, '', '$installlang[install_php_25]', '', 0),
(26, 16, '', '$installlang[install_php_26]', '', 0),
(27, 16, '', '$installlang[install_php_27]', '', 0),
(28, 16, '', '$installlang[install_php_28]', '', 0),
(29, 16, '', '$installlang[install_php_29]', '', 0),
(30, 16, '', '$installlang[install_php_30]', '', 0),
(31, 3, '', '$installlang[install_php_31]', '', 0),
(32, 3, '', '$installlang[install_php_32]', '', 0),
(33, 3, '', '$installlang[install_php_33]', '', 0),
(34, 3, '', '$installlang[install_php_34]', '', 0),
(35, 3, '', '$installlang[install_php_35]', '', 0),
(36, 3, '', '$installlang[install_php_36]', '', 0),
(37, 3, '', '$installlang[install_php_37]', '', 0),
(38, 3, '', '$installlang[install_php_38]', '', 0),
(39, 3, '', '$installlang[install_php_39]', '', 0),
(40, 3, '', '$installlang[install_php_40]', '', 0),
(41, 3, '', '$installlang[install_php_41]', '', 0),
(42, 31, '', '$installlang[install_php_42]', '', 0),
(43, 31, '', '$installlang[install_php_43]', '', 0),
(44, 31, '', '$installlang[install_php_44]', '', 0),
(45, 31, '', '$installlang[install_php_45]', '', 0),
(46, 31, '', '$installlang[install_php_46]', '', 0),
(47, 31, '', '$installlang[install_php_47]', '', 0),
(48, 31, '', '$installlang[install_php_48]', '', 0),
(49, 31, '', '$installlang[install_php_49]', '', 0),
(50, 32, '', '$installlang[install_php_50]', '', 0),
(51, 32, '', '$installlang[install_php_51]', '', 0),
(52, 32, '', '$installlang[install_php_52]', '', 0),
(53, 32, '', '$installlang[install_php_53]', '', 0),
(54, 33, '', '$installlang[install_php_54]', '', 0),
(55, 33, '', '$installlang[install_php_55]', '', 0),
(56, 33, '', '$installlang[install_php_56]', '', 0),
(57, 34, '', '$installlang[install_php_57]', '', 0),
(58, 34, '', '$installlang[install_php_58]', '', 0),
(59, 34, '', '$installlang[install_php_59]', '', 0),
(60, 34, '', '$installlang[install_php_60]', '', 0),
(61, 34, '', '$installlang[install_php_61]', '', 0),
(62, 34, '', '$installlang[install_php_62]', '', 0),
(63, 34, '', '$installlang[install_php_63]', '', 0),
(64, 34, '', '$installlang[install_php_64]', '', 0),
(65, 34, '', '$installlang[install_php_65]', '', 0),
(66, 35, '', '$installlang[install_php_66]', '', 0),
(67, 35, '', '$installlang[install_php_67]', '', 0),
(68, 35, '', '$installlang[install_php_68]', '', 0),
(69, 35, '', '$installlang[install_php_69]', '', 0),
(70, 36, '', '$installlang[install_php_70]', '', 0),
(71, 36, '', '$installlang[install_php_71]', '', 0),
(72, 36, '', '$installlang[install_php_72]', '', 0),
(73, 36, '', '$installlang[install_php_73]', '', 0),
(74, 36, '', '$installlang[install_php_74]', '', 0),
(75, 36, '', '$installlang[install_php_75]', '', 0),
(76, 36, '', '$installlang[install_php_76]', '', 0),
(77, 37, '', '$installlang[install_php_77]', '', 0),
(78, 37, '', '$installlang[install_php_78]', '', 0),
(79, 37, '', '$installlang[install_php_79]', '', 0),
(80, 38, '', '$installlang[install_php_80]', '', 0),
(81, 38, '', '$installlang[install_php_81]', '', 0),
(82, 38, '', '$installlang[install_php_82]', '', 0),
(83, 38, '', '$installlang[install_php_83]', '', 0),
(84, 38, '', '$installlang[install_php_84]', '', 0),
(85, 38, '', '$installlang[install_php_85]', '', 0),
(86, 38, '', '$installlang[install_php_86]', '', 0),
(87, 38, '', '$installlang[install_php_87]', '', 0),
(88, 38, '', '$installlang[install_php_88]', '', 0),
(89, 38, '', '$installlang[install_php_89]', '', 0),
(90, 38, '', '$installlang[install_php_90]', '', 0),
(91, 38, '', 'KTV', '', 0),
(92, 39, '', '$installlang[install_php_91]', '', 0),
(93, 39, '', '$installlang[install_php_92]', '', 0),
(94, 39, '', '$installlang[install_php_93]', '', 0),
(95, 40, '', '$installlang[install_php_94]', '', 0),
(96, 40, '', '$installlang[install_php_95]', '', 0),
(97, 41, '', '$installlang[install_php_96]', '', 0),
(98, 41, '', '$installlang[install_php_97]', '', 0),
(99, 4, '', '$installlang[install_php_98]', '', 0),
(100, 4, '', '$installlang[install_php_99]', '', 0),
(101, 4, '', '$installlang[install_php_100]', '', 0),
(102, 4, '', '$installlang[install_php_101]', '', 0),
(103, 5, '', '$installlang[install_php_102]', '', 0),
(104, 5, '', '$installlang[install_php_103]', '', 0),
(105, 5, '', '$installlang[install_php_104]', '', 0),
(106, 5, '', '$installlang[install_php_105]', '', 0),
(107, 5, '', '$installlang[install_php_106]', '', 0),
(108, 5, '', '$installlang[install_php_107]', '', 0),
(109, 5, '', '$installlang[install_php_108]', '', 0),
(110, 5, '', '$installlang[install_php_109]', '', 0),
(111, 5, '', '$installlang[install_php_110]', '', 0),
(112, 5, '', '$installlang[install_php_111]', '', 0),
(113, 5, '', '$installlang[install_php_112]', '', 0),
(114, 6, '', '$installlang[install_php_113]', '', 0),
(115, 6, '', 'SUV', '', 0),
(116, 6, '', 'MPV', '', 0),
(117, 6, '', '$installlang[install_php_114]', '', 0),
(118, 6, '', '$installlang[install_php_115]', '', 0),
(119, 6, '', '$installlang[install_php_116]', '', 0),
(120, 6, '', '$installlang[install_php_117]', '', 0),
(121, 6, '', '$installlang[install_php_118]', '', 0),
(122, 7, '', '$installlang[install_php_119]', '', 0),
(123, 7, '', '$installlang[install_php_120]', '', 0),
(124, 122, '', '$installlang[install_php_121]', '', 0),
(125, 122, '', '$installlang[install_php_122]', '', 0),
(126, 122, '', '$installlang[install_php_123]', '', 0),
(127, 122, '', '$installlang[install_php_124]', '', 0),
(128, 122, '', '$installlang[install_php_125]', '', 0),
(129, 122, '', '$installlang[install_php_126]', '', 0),
(130, 122, '', '$installlang[install_php_127]', '', 0),
(131, 122, '', '$installlang[install_php_128]', '', 0),
(132, 122, '', '$installlang[install_php_129]', '', 0),
(133, 122, '', '$installlang[install_php_130]', '', 0),
(134, 122, '', '$installlang[install_php_131]', '', 0),
(135, 123, '', '$installlang[install_php_132]', '', 0),
(136, 123, '', '$installlang[install_php_133]', '', 0),
(137, 123, '', '$installlang[install_php_134]', '', 0),
(138, 123, '', '$installlang[install_php_135]', '', 0),
(139, 123, '', '$installlang[install_php_136]', '', 0),
(140, 123, '', '$installlang[install_php_137]', '', 0),
(141, 123, '', '$installlang[install_php_138]', '', 0),
(142, 123, '', '$installlang[install_php_139]', '', 0),
(143, 123, '', '$installlang[install_php_140]', '', 0),
(144, 123, '', '$installlang[install_php_141]', '', 0),
(145, 123, '', '$installlang[install_php_142]', '', 0),
(146, 8, '', '$installlang[install_php_143]', '', 0),
(147, 8, '', '$installlang[install_php_144]', '', 0),
(148, 8, '', '$installlang[install_php_145]', '', 0),
(149, 8, '', '$installlang[install_php_146]', '', 0),
(150, 8, '', '$installlang[install_php_147]', '', 0),
(151, 8, '', '$installlang[install_php_148]', '', 0),
(152, 8, '', '$installlang[install_php_149]', '', 0),
(153, 9, '', '$installlang[install_php_150]', '', 0),
(154, 9, '', '$installlang[install_php_151]', '', 0),
(155, 10, '', '$installlang[install_php_152]', '', 0),
(156, 10, '', '$installlang[install_php_153]', '', 0),
(157, 10, '', '$installlang[install_php_154]', '', 0),
(158, 10, '', '$installlang[install_php_155]', '', 0);
INSERT INTO `pre_aljtc_typesettings` (`id`, `typeid`, `type_key`, `type_value`) VALUES
(1, 1, 'statement', '$installlang[install_php_156]'),
(2, 1, 'mobile_label', ''),
(3, 5, 'statement', ''),
(4, 5, 'mobile_label', '$installlang[install_php_157]'),
(5, 12, 'statement', ''),
(6, 12, 'mobile_label', '$installlang[install_php_158]'),
(7, 13, 'statement', ''),
(8, 13, 'mobile_label', '$installlang[install_php_159]'),
(9, 14, 'statement', ''),
(10, 14, 'mobile_label', '$installlang[install_php_160]'),
(11, 15, 'statement', ''),
(12, 15, 'mobile_label', '$installlang[install_php_161]'),
(13, 2, 'statement', '$installlang[install_php_162]'),
(14, 2, 'mobile_label', ''),
(15, 16, 'statement', ''),
(16, 16, 'mobile_label', '$installlang[install_php_163]'),
(17, 17, 'statement', ''),
(18, 17, 'mobile_label', '$installlang[install_php_164]'),
(19, 99, 'statement', ''),
(20, 99, 'mobile_label', '$installlang[install_php_165]'),
(21, 100, 'statement', ''),
(22, 100, 'mobile_label', '$installlang[install_php_166]'),
(23, 101, 'statement', ''),
(24, 101, 'mobile_label', '$installlang[install_php_167]'),
(25, 102, 'statement', ''),
(26, 102, 'mobile_label', '$installlang[install_php_168]'),
(27, 7, 'statement', ''),
(28, 7, 'mobile_label', '$installlang[install_php_169]'),
(29, 12, 'desc_title', ''),
(30, 12, 'desc_content', ''),
(31, 1, 'desc_title', '$installlang[install_php_170]'),
(32, 1, 'desc_content', '$installlang[install_php_171]'),
(33, 16, 'desc_title', '$installlang[install_php_172]'),
(34, 16, 'desc_content', '$installlang[install_php_173]'),
(35, 2, 'desc_title', ''),
(36, 2, 'desc_content', '');
EOF;
runquery($sql);
$sql ="ALTER TABLE  ".DB::table('aljtc')." ADD  `is_anonymous` tinyint(4) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_custom')." ADD  `custom_charge` tinyint(4) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_custom')." ADD  `custom_charge_price` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_custom')." ADD  `jifen_type` tinyint(4) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_custom')." ADD  `jifen` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_see_tel')." ADD  `jifen_type` tinyint(4) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_see_tel')." ADD  `jifen` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_see_tel')." ADD  `price` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_see_tel')." ADD  `orderid` CHAR(32) NOT NULL" ;
DB::query($sql,'SILENT');
if(strtolower(CHARSET) == 'gbk'){
	include 'source/plugin/aljtc/install/custom_updata_gbk.php';
}else{
	include 'source/plugin/aljtc/install/custom_updata_utf8.php';
}
require_once 'source/plugin/aljtc/include/initalData.php';
//finish to put your own code
$finish = TRUE;
?>
