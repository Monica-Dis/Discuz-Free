<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
$pluginid='aljtc';

$act = addslashes($_GET['act']);
$formlist = array(
	'text' => '&#25991;&#26412;&#26694;',
	'textarea' => '&#25991;&#26412;&#22495;',
	'file' => '&#25991;&#20214;&#19978;&#20256;',
	'select' => '&#21333;&#36873;&#26694;',
	'date' => '&#26085;&#26399;',
	'checkbox' => '&#24320;&#20851;',
);
$custom_id = intval($_GET['custom_id']);
$custom_state = intval($_GET['custom_state']);
$custom_order = intval($_GET['custom_order']);
$custom_title = addslashes($_GET['custom_title']);
$custom_change = intval($_GET['custom_change']);
$custom_required = intval($_GET['custom_required']);
$custom_type = addslashes($_GET['custom_type']);
$custom_extra = addslashes($_GET['custom_extra']);
$custom_unit = addslashes($_GET['custom_unit']);
$typeid = intval($_GET['typeid']);
$type_page = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('type_page');
if($act == 'del') {
	$tid = intval($_GET['tid']);
	if($tid) {
		$data = DB::fetch_first('select * from %t where id=%d',array($pluginid.'_position',$tid));
		$twotypedata = DB::fetch_first('select * from %t where upid=%d',array($pluginid.'_position',$tid));
		if($twotypedata) {
			cpmsg('&#35831;&#21024;&#38500;&#23376;&#20998;&#31867;&#44;&#22312;&#36827;&#34892;&#25805;&#20316;', 'action=plugins&operation=config&identifier='.$pluginid.'&pmod=position', 'succeed');
			exit;
		}else {
			if($data['logo']) {
				unlink($data['logo']);
			}
			DB::delete('aljtc_position',array('id'=>$tid));
		}
	}
	cpmsg(lang('plugin/'.$pluginid.'','position_7'), 'action=plugins&operation=config&identifier='.$pluginid.'&pmod=position&page='.$_GET['page'], 'succeed');
}else if($act == 'open'){
	if($_GET['typeid']){
		if($_GET['oid'] == 1){
			$open=1;
			$open_tips = '&#20851;&#38381;&#25104;&#21151;';
		}else{
			$open=0;
			$open_tips = '&#24320;&#21551;&#25104;&#21151;';
		}
		DB::update($pluginid.'_position',array('is_open'=>$open),array('id'=>$_GET['typeid']));
		cpmsg($open_tips, 'action=plugins&operation=config&identifier='.$pluginid.'&pmod=position&page='.$_GET['page'], 'succeed');
	}else{
		cpmsg('&#25805;&#20316;&#22833;&#36133;&#65292;&#35831;&#37325;&#35797;');
	}
}else if($act == 'customlist') {
	if(submitcheck('formhash')) {
		if($_GET['del']) {
			if(!empty($_GET['delete'])) {
				foreach($_GET['delete'] as $tmp_key=>$tmp_value){
					DB::delete('aljtc_custom', array('custom_id'=>$tmp_value));
				}
			}
		}else {
			if(!empty($_GET['displayorder'])) {
				foreach($_GET['displayorder'] as $tmp_key=>$tmp_value){
					DB::update('aljtc_custom', array('custom_order'=>$tmp_value),array('custom_id'=>$tmp_key));
				}
			}
		}
		cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=position&act=customlist&typeid='.$typeid);
	}else{
		$customlist = DB::fetch_all('select * from %t where typeid=%d order by custom_order asc',array($pluginid.'_custom',$typeid));
		include template($pluginid.':admin/custom');
	}
}else if($act == 'addfield') {
	if(submitcheck('formhash')) {
		$order = DB::fetch_first('select max(custom_id) as tmp_id from %t',array($pluginid.'_custom'));
		$custom_info = DB::fetch_first('select * from %t where custom_id=%d',array($pluginid.'_custom',$custom_id));
		$t_num = DB::result_first('select count(*) from %t where typeid=%d and custom_type=%s',array($pluginid.'_custom',$typeid,'title'));
		$a_num = DB::result_first('select count(*) from %t where typeid=%d and custom_type=%s',array($pluginid.'_custom',$typeid,'address'));
		$v_num = DB::result_first('select count(*) from %t where typeid=%d and custom_type=%s',array($pluginid.'_custom',$typeid,'video'));
		if($t_num && $custom_type == 'title' && $custom_info['custom_type'] != $custom_type){
			cpmsg('&#26816;&#32034;&#26631;&#39064;&#21482;&#33021;&#28155;&#21152;&#19968;&#20010;');
		}
		if($a_num && $custom_type == 'address' && $custom_info['custom_type'] != $custom_type){
			cpmsg('&#23450;&#20301;&#20301;&#32622;&#21482;&#33021;&#28155;&#21152;&#19968;&#20010;');
		}
		if($v_num && $custom_type == 'video' && $custom_info['custom_type'] != $custom_type){
			cpmsg('&#19978;&#20256;&#35270;&#39057;&#21482;&#33021;&#28155;&#21152;&#19968;&#20010;');
		}
		if($custom_id) {
			DB::update('aljtc_custom', array(
				'custom_title' => $custom_title,
				'custom_change' => $custom_change,
				'custom_required' => $custom_required,
				'custom_type' => $custom_type,
				'custom_extra' => $custom_extra,
				'custom_unit' => $custom_unit,
				'custom_state' => $custom_state,
				'custom_charge' => $_GET['custom_charge'],
				'custom_charge_price' => $_GET['custom_charge_price'],
				'jifen_type' => $_GET['jifen_type'],
				'jifen' => $_GET['jifen'],
			),array('custom_id'=> $custom_id));
		}else{
			$tmp_id = $order['tmp_id']+1;
			$insertid = DB::insert('aljtc_custom', array(
				'custom_title' => $custom_title,
				'custom_change' => $custom_change,
				'custom_required' => $custom_required,
				'custom_type' => $custom_type,
				'custom_extra' => $custom_extra,
				'custom_unit' => $custom_unit,
				'custom_order' => $tmp_id,
				'custom_state' => $custom_state,
				'typeid' => $typeid,
				'custom_charge' => $_GET['custom_charge'],
				'custom_charge_price' => $_GET['custom_charge_price'],
				'jifen_type' => $_GET['jifen_type'],
				'jifen' => $_GET['jifen'],
			),true);
			$tmp_name = 'form[var]['.$insertid.']';
			DB::update($pluginid.'_custom', array('custom_name' => $tmp_name),array('custom_id' => $insertid));
		}
		cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=position&act=customlist&typeid='.$typeid);
	}else{
		if($custom_id) {
			$customdata = DB::fetch_first('select * from %t where custom_id=%d',array($pluginid.'_custom',$custom_id));
		}
		include template($pluginid.':admin/addfield');
	}

}else if($act == 'settings') {
	if(submitcheck('formhash')) {
		
		foreach($_GET['settingsnew'] as $k=>$v){
			$count = DB::result_first('select count(*) from %t where typeid=%d and type_key=%s',array($pluginid.'_typesettings',$typeid,$k));
			if(!$count){
				DB::insert($pluginid.'_typesettings',array(
					'typeid' => $typeid,
					'type_key' => $k,
					'type_value' => $v,
				));
			}else{
				DB::update('aljtc_typesettings',array('type_value'=>$v),array('type_key'=>$k,'typeid'=>$typeid));
			}
		}
		cpmsg('&#25805;&#20316;&#25104;&#21151;&#65281;','action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=position&act=settings&typeid='.$typeid);
	}else{
		$settings = DB::fetch_all('select * from %t where typeid=%d',array($pluginid.'_typesettings',$typeid));
		foreach($settings as $tmp_key => $tmp_value) {
			$setting[$tmp_value['type_key']] = $tmp_value['type_value'];
		}
		include template($pluginid.':admin/settings');
	}


}else {
	if(!submitcheck('editsubmit')) {
		
		$currpage = $_GET['page'] ? $_GET['page'] : 1;
		$perpage = $type_page['value'] ? $type_page['value'] :8;
		$start = ($currpage - 1) * $perpage;
		$num=DB::result_first('select count(*) from %t where upid=%d',array($pluginid.'_position',0));
		$position = DB::fetch_all('select * from %t where upid=%d order by displayorder asc limit %d,%d',array($pluginid.'_position',0,$start,$perpage));
		$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT."?action=plugins&operation=config&do=".$_GET['do']."&identifier=".$pluginid."&pmod=position", 0, 10, false, false);
		
		include template($pluginid.':admin/position');
	} else {
		$order = $_GET['order'];
		$name = $_GET['name'];
		$newsubcat = $_GET['newsubcat'];
		$newcat = $_GET['newcat'];
		$newsuborder = $_GET['newsuborder'];
		$newcatorder = $_GET['newcatorder'];
		if(is_array($order)) {
			foreach($order as $id=>$value) {
				C::t('#'.$pluginid.'#'.$pluginid.'_position')->update($id,array('displayorder'=>$value,'subject'=>$name[$id]));
			}
		}

		if(is_array($newcat)) {
			foreach($newcat as $key=>$name) {
				if(empty($name)) {
					continue;
				}
				$cid=C::t('#'.$pluginid.'#'.$pluginid.'_position')->insert(array('upid' => '0', 'subject' => $name, 'displayorder' => $newcatorder[$key]),1);
			}
		}

		if(is_array($newsubcat)) {
			foreach($newsubcat as $cid=>$subcat) {
				foreach ($subcat as  $key => $name) {
					DB::insert($pluginid.'_position',array('upid'=> $cid,'subject'=>$name,'displayorder' => $newsuborder[$cid][$key]));
				}
			}
		}

		cpmsg(lang('plugin/'.$pluginid.'','position_7'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=position&page='.$_GET['page'], 'succeed');
	}
}
function getsubtype($upid){
	global $pluginid;
	$position = DB::fetch_all('select * from %t where upid=%d order by displayorder asc,id asc',array('aljtc_position',$upid));
	return $position;
}
//From: Dism��taobao��com
?>
