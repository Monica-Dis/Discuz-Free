<?php

/*
 * ���ߣ�����
 * ��ϵQQ:578933760
 *
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if($_GET['act'] == 'upgrade'){
	require_once 'source/plugin/aljtc/upgrade.inc.php';
}
$pluginid='aljtc';
$config = array();
foreach($pluginvars as $key => $val) {
	$config[$key] = $val['value'];
}
$_GET=dhtmlspecialchars($_GET);
if(submitcheck('formhash')){
	if($_FILES['logo']['tmp_name']) {
		$picname = $_FILES['logo']['name'];
		$picsize = $_FILES['logo']['size'];

		if ($picname != "") {
			$type = strtolower(strrchr($picname, '.'));
			if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
				showerror('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#112;&#110;&#103;&#32;&#46;&#103;&#105;&#102;&#22270;&#29255;');
			}
			$rand = rand(100, 999);
			$pics = date("YmdHis") . $rand . $type;
			$logo = "source/plugin/".$pluginid."/images/cache/". $pics;
			if(@copy($_FILES['logo']['tmp_name'], $logo)||@move_uploaded_file($_FILES['logo']['tmp_name'], $logo)){
				@unlink($_FILES['logo']['tmp_name']);
			}
		}
	}

	if(empty($logo)){
		$logo = $_GET['logo'];
	}


	$record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('logo');

	if($_GET['deletelogo']){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting') -> delete('logo');
		if($record['value']){
			unlink($record['value']);
		}
	}

	if(!$record){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>'logo','value'=>$logo));
	}else{
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($logo,'logo');
	}
	unset($logo);

	if($_FILES['new_logo']['tmp_name']) {
		$picname = $_FILES['new_logo']['name'];
		$picsize = $_FILES['new_logo']['size'];

		if ($picname != "") {
			$type = strtolower(strrchr($picname, '.'));
			if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
				showerror('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#112;&#110;&#103;&#32;&#46;&#103;&#105;&#102;&#22270;&#29255;');
			}
			$rand = rand(100, 999);
			$pics = date("YmdHis") . $rand . $type;
			$new_logo = "source/plugin/".$pluginid."/images/cache/". $pics;
			if(@copy($_FILES['new_logo']['tmp_name'], $new_logo)||@move_uploaded_file($_FILES['new_logo']['tmp_name'], $new_logo)){
				@unlink($_FILES['new_logo']['tmp_name']);
			}
		}
	}

	if(empty($new_logo)){
		$new_logo = $_GET['new_logo'];
	}


	$record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('new_logo');

	if($_GET['deletenew_logo']){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting') -> delete('new_logo');
		if($record['value']){
			unlink($record['value']);
		}
	}

	if(!$record){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>'new_logo','value'=>$new_logo));
	}else{
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($new_logo,'new_logo');
	}
	unset($new_logo);

	if($_FILES['mobile_logo']['tmp_name']) {
		$picname = $_FILES['mobile_logo']['name'];
		$picsize = $_FILES['mobile_logo']['size'];

		if ($picname != "") {
			$type = strtolower(strrchr($picname, '.'));
			if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
				showerror('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#112;&#110;&#103;&#32;&#46;&#103;&#105;&#102;&#22270;&#29255;');
			}
			$rand = rand(100, 999);
			$mobile_pics = date("YmdHis") . $rand . $type;
			$mobile_logo = "source/plugin/".$pluginid."/images/cache/". $mobile_pics;
			if(@copy($_FILES['mobile_logo']['tmp_name'], $mobile_logo)||@move_uploaded_file($_FILES['mobile_logo']['tmp_name'], $mobile_logo)){
				@unlink($_FILES['mobile_logo']['tmp_name']);
			}
		}
	}

	if(empty($mobile_logo)){
		$mobile_logo = $_GET['mobile_logo'];
	}


	$mobile_record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('mobile_logo');

	if($_GET['deletemobile_logo']){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting') -> delete('mobile_logo');
		if($mobile_record['value']){
			unlink($mobile_record['value']);
		}
	}

	if(!$mobile_record){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>'mobile_logo','value'=>$logo));
	}else{
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($mobile_logo,'mobile_logo');
	}
	unset($mobile_logo);
	if($_FILES['share_logo']['tmp_name']) {
		$picname = $_FILES['share_logo']['name'];
		$picsize = $_FILES['share_logo']['size'];

		if ($picname != "") {
			$type = strtolower(strrchr($picname, '.'));
			if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
				showerror('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#112;&#110;&#103;&#32;&#46;&#103;&#105;&#102;&#22270;&#29255;');
			}
			$rand = rand(100, 999);
			$share_pics = date("YmdHis") . $rand . $type;
			$share_logo = "source/plugin/".$pluginid."/images/cache/". $share_pics;
			if(@copy($_FILES['share_logo']['tmp_name'], $share_logo)||@move_uploaded_file($_FILES['share_logo']['tmp_name'], $share_logo)){
				@unlink($_FILES['share_logo']['tmp_name']);
			}
		}
	}

	if(empty($share_logo)){
		$share_logo = $_GET['share_logo'];
	}


	$share_record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('share_logo');

	if($_GET['deleteshare_logo']){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting') -> delete('share_logo');
		if($share_record['value']){
			unlink($share_record['value']);
		}
	}

	if(!$share_record){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>'share_logo','value'=>$share_logo));
	}else{
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($share_logo,'share_logo');
	}

	if(!C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('mhot')){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>'mhot','value'=>$_GET['mhot']));
	}else{
		if($_GET['mhot']){
			C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($_GET['mhot'],'mhot');
		}
	}

	if(!C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('mhotmore')){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>'mhotmore','value'=>$_GET['mhotmore']));
	}else{
		if($_GET['mhotmore']){
			C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($_GET['mhotmore'],'mhotmore');
		}
	}

	foreach($_GET['settingsnew'] as $k=>$v){
		if(in_array($k, array('m_groups','lj_groups'))){
			$v = (string)serialize($v);
		}
		if(!C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch($k)){
			C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>$k,'value'=>$v));
		}else{
			C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($v,$k);
		}
	}

	cpmsg('&#26356;&#26032;&#25104;&#21151;&#65281;', 'action=plugins&operation=config&identifier='.$pluginid.'&pmod=setting', 'succeed');
}else{
    require_once 'source/plugin/aljtc/include/initalData.php';
	$record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('logo');
	$logo = $record['value'];
	$mobile_record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('mobile_logo');
	$mobile_logo = $mobile_record['value'];
	$new_record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('new_logo');
	$new_logo = $new_record['value'];
	$share_record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('share_logo');
	$share_logo = $share_record['value'];
	
	$setting = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->range();
	$settings= $setting;
	include template($pluginid.':setting');
}
function l_groups($group,$type=0){
	global $_G,$config,$lang,$settings;
	if($type){
        $var['type'] = '<select name="'.$var['variable'].'"><option value="">'.cplang('plugins_empty').'</option>';
    }else{
        $var['description'] = ($var['description'] ? (isset($lang[$var['description']]) ? $lang[$var['description']] : $var['description'])."\n" : '').$lang['plugins_edit_vars_multiselect_comment']."\n".$var['comment'];
        $var['value'] = dunserialize($settings[$group]['value']);
        $var['type'] = '<select name="settingsnew['.$group.'][]" size="10" multiple="multiple"><option value=""'.(@in_array('', $var['value']) ? ' selected' : '').'>'.cplang('plugins_empty').'</option>';
    }

	$var['value'] = is_array($var['value']) ? $var['value'] : array($var['value']);
	
	$query = C::t('common_usergroup')->range_orderby_credit();
	$groupselect = array();
	foreach($query as $group) {
		$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
		$groupselect[$group['type']] .= '<option value="'.$group['groupid'].'"'.(@in_array($group['groupid'], $var['value']) ? ' selected' : '').'>'.$group['grouptitle'].'</option>';
	}
	$var['type'] .= '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
		($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
		($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
		'<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup></select>';
	return $var['type'];
}
//From: Dism��taobao��com
?>
