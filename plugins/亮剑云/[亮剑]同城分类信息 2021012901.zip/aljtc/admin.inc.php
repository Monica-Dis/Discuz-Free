<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
$pluginid='aljtc';
$settings=C::t('#'.$pluginid.'#'.$pluginid.'_setting')->range();
if($_GET['act']=='commentlist'){
		$currpage=$_GET['page']?$_GET['page']:1;
		$perpage=10;
		$start=($currpage-1)*$perpage;
		$num=C::t('#'.$pluginid.'#'.$pluginid.'_comment')->count_by_bid_all($_GET['lid']);
		$commentlist=C::t('#aljtc#aljtc_comment')->fetch_all_by_bid_page($_GET['lid'],$start,$perpage);
		$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&identifier=aljtc&do='.$_GET['do'].'&pmod=admin&act=commentlist&lid='.$_GET['lid'], 0, 11, false, false);
		include template($pluginid.':admincommentlist');
}else if($_GET['act']=='deletecomment'){
		C::t('#'.$pluginid.'#'.$pluginid.'_comment')->delete($_GET['cid']);
		$currpage=$_GET['page']?$_GET['page']:1;
		$perpage=10;
		$num=C::t('#'.$pluginid.'#'.$pluginid.'_comment')->count_by_bid_all($_GET['lid']);
		$commentlist=C::t('#'.$pluginid.'#'.$pluginid.'_comment')->fetch_all_by_bid_page($_GET['lid'],$start,$perpage);
		$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&identifier=aljtc&do='.$_GET['do'].'&pmod=admin&act=commentlist&lid='.$_GET['lid'], 0, 11, false, false);
		include template($pluginid.':admincommentlist');
}else if($_GET['act']=='sh_comment'){
	C::t('#'.$pluginid.'#'.$pluginid.'_comment')->update($_GET['cid'],array('status'=>0));
	$currpage=$_GET['page']?$_GET['page']:1;
	$perpage=10;
	$num=C::t('#'.$pluginid.'#'.$pluginid.'_comment')->count_by_bid_all($_GET['lid']);
	$commentlist=C::t('#'.$pluginid.'#'.$pluginid.'_comment')->fetch_all_by_bid_page($_GET['lid'],$start,$perpage);
	$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&identifier=aljtc&do='.$_GET['do'].'&pmod=admin&act=commentlist&lid='.$_GET['lid'], 0, 11, false, false);
	include template($pluginid.':admincommentlist');
}else{
	if(!submitcheck('submit')&&!submitcheck('del_submit')) {//����
        $pos_all = C::t('#aljtc#'.$pluginid.'_position')->range();
		$currpage=$_GET['page']?$_GET['page']:1;
		$perpage=10;
		$start=($currpage-1)*$perpage;
		$con=" where 1";
		if($settings['isreview']['value']) {
			if($_GET['state'] == 'yes') {
				$con.=" and state=0";
				$state = 'yes';
			}else if($_GET['state'] == 'top') {
				$con.=" and state=0 and topetime>".TIMESTAMP;
				$state = 'yes';
			}else if($_GET['state'] == '2'){
				$con.=" and state=2";
				$state = '2';
			}else {
				$con.=" and state=1";
				$state = '1';
			}	
		}else {
			$state = '1';
		}
		if($_GET['search']){
			$search='%' . addcslashes($_GET['search'], '%_') . '%';
			$con.=" and (title like '$search' or content like '$search')";
		}
		$num=DB::result_first("SELECT count(*) FROM ".DB::table('aljtc')." $con");
		$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT."?action=plugins&operation=config&identifier=".$pluginid."&do=".$_GET['do']."&pmod=admin&state=".$state."&search=".$_GET['search'], 0, 10, false, false);
		$query = DB::fetch_all("SELECT * FROM ".DB::table('aljtc')." $con ORDER BY id desc limit $start,$perpage");
		$customlist = DB::fetch_all('select * from %t ',array($pluginid.'_custom'));
        foreach($customlist as $ck => $cv){
            $customlist[$cv['custom_id']] = $cv;
		}
		foreach($query as $gk => $gv){
            $newarray = unserialize($gv['form']);
            foreach($newarray as $tmp_key => $tmp_value) {
				$newarrayt[$customlist[$tmp_key]['custom_title']] = $tmp_value;
            }
            $query[$gk]['formlist'] = $newarrayt;
			unset($newarrayt);
			if(TIMESTAMP>$gv['topetime']&&$gv['topetime']){
				DB::update('aljtc',array('topstime'=>'','topetime'=>''),'id='.$gv[id]);
			}
			if(TIMESTAMP>$gv['expiry_time']&&$gv['expiry_time']){
				DB::update('aljtc',array('solve'=>'1'),'id='.$gv[id]);
			}
		}
		echo '<script>disallowfloat = "newthread";</script>';
		$oss_domain = $_G['cache']['plugin']['aljoss']['cdn_domain'] ? $_G['cache']['plugin']['aljoss']['cdn_domain'] : $_G['cache']['plugin']['aljoss']['domain'];
		include template($pluginid.':admin/datamanage');
	}else {
		if(submitcheck('del_submit')) {
			if(is_array($_POST['delete'])) {
				foreach($_POST['delete'] as $id) {
					$user=C::t('#'.$pluginid.'#'.$pluginid)->fetch($id);
					for ($i = 1; $i <= 8; $i++) {
						$pic = 'pic' . $i;
						if ($user[$pic]) {
							unlink($user[$pic]);
						}
					}
					C::t('#'.$pluginid.'#'.$pluginid)->delete($id);
				}
			}
		}else if(submitcheck('submit')) {
			if(is_array($_POST['delete'])) {
				foreach($_POST['delete'] as $id) {
					DB::update('aljtc',array('state'=>0),array('id'=>$id));
				}
			}
		}
		cpmsg(lang('plugin/aljtc','admin_1'), 'action=plugins&operation=config&identifier='.$pluginid.'&do='.$_GET['do'].'&pmod=admin&page='.$_GET['page'],'succeed');
	}
}
//From: Dism_taobao_com
?>