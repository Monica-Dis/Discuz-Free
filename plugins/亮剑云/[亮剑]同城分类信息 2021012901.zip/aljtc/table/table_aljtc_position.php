<?php
/*
 * ���ߣ�����
 * ��ϵQQ:578933760
 *
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljtc_position extends discuz_table{
	public function __construct() {

			$this->_table = 'aljtc_position';
			$this->_pk    = 'id';

			parent::__construct(); /*Dism_taobao-com*/
	}
	public function fetch_all_json()
    {
        $result = $this->fetch_all_by_upid_json(0);
        foreach ($result as $index => $item) {
            $result[$index]['name'] = diconv(trim(preg_replace('# #','',$item['name'])), CHARSET, 'utf-8');
            $subregion = $this->fetch_all_by_upid_json($item['id']);
            if($subregion){
                foreach ($subregion as $subk => $subv){
                    $subregion[$subk]['name'] = diconv(trim(preg_replace('# #','',$subv['name'])), CHARSET, 'utf-8');
                    $subsubregion = $this->fetch_all_by_upid_json($subv['id']);
                    if($subsubregion){
                        foreach($subsubregion as $subsubk => $subsubv){
                            $subsubregion[$subsubk]['name'] = diconv(trim(preg_replace('# #','',$subsubv['name'])), CHARSET, 'utf-8');
                        }
                        $subregion[$subk]['sub'] = $subsubregion;
                    }else{
                        $subsubregion_1[0]['name'] = '--';
                        $subsubregion_1[0]['code'] = '0';
                        $subregion[$subk]['sub'] = $subsubregion_1;
                    }
                }
            }else{
                $subregion[0]['name'] = '--';
                $subregion[0]['code'] = '0';
                $subsubregion_1[0]['name'] = '--';
                $subsubregion_1[0]['code'] = '0';
                $subregion[0]['sub'] = $subsubregion_1;
            }
            $result[$index]['sub'] = $subregion;
        }
        return $result;
    }
    public function fetch_all_by_upid_json($upid){
        return DB::fetch_all('SELECT subject as name,upid,id,id as code FROM %t WHERE is_open=0 AND upid=%d ORDER BY displayorder ASC',array($this->_table,$upid));
    }
	public function fetch_upid_by_id($id){
		return DB::result_first('SELECT upid FROM %t WHERE id=%d',array($this->_table,$id));
	}
	public function fetch_subid_by_id($id){
		return DB::result_first('SELECT subid FROM %t WHERE id=%d',array($this->_table,$id));
	}
	public function fetch_all_by_upid($upid){
		return DB::fetch_all('SELECT * FROM %t WHERE is_open=0 AND upid=%d ORDER BY displayorder ASC',array($this->_table,$upid),'id');
    }
    public function fetch_all_by_upid_1($upid){
		return DB::fetch_all('SELECT * FROM %t WHERE is_open=0 AND upid=%d ORDER BY displayorder ASC',array($this->_table,$upid));
    }
	public function fetch_all_by_type($type){
		return DB::fetch_all('select * from %t where id=%d ORDER BY displayorder ASC',array($this->_table,$type));
	}
    public function fetch_all_range(){
		return DB::fetch_all('select * from %t ORDER BY displayorder ASC',array($this->_table));
	}
}




?>