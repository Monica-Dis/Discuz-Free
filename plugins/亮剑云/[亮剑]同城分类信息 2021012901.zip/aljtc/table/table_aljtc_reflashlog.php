<?php
/*
 * ���ߣ�����
 * ��ϵQQ:578933760
 *
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljtc_reflashlog extends discuz_table{
	public function __construct() {

			$this->_table = 'aljtc_reflashlog';
			$this->_pk    = 'id';

			parent::__construct(); /*Dism_taobao-com*/
	}
       

}




?>