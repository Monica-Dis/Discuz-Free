<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$pluginid='aljtc';
$lang = array_merge($lang, $scriptlang[$pluginid]);

if(empty($_GET['ac'])) {

	if(!submitcheck('seosubmit')) {
		echo '<script type="text/javascript">
		function insertContent(obj, text) {
			var obj = obj.parentNode.parentNode.firstChild.lastChild;
			selection = document.selection;
			obj.focus();
			if(!isUndefined(obj.selectionStart)) {
				var opn = obj.selectionStart + 0;
				obj.value = obj.value.substr(0, obj.selectionStart) + text + obj.value.substr(obj.selectionEnd);
			} else if(selection && selection.createRange) {
				var sel = selection.createRange();
				sel.text = text;
				sel.moveStart(\'character\', -strlen(text));
			} else {
				obj.value += text;
			}
		}
		</script>';

		$aljtc_seo = dunserialize($_G['setting']['aljtc_seo']);
		$page = array(
            'index' => array('bbname','fz_name'),
			'list' => array('bbname', 'cat','cat1','cat2','region','region1','region2'),
			'view' => array('bbname', 'subject', 'message','cat','cat1','cat2','region','region1','region2'),
			'quanbu' => array('bbname', 'username'),
			'posttype' => array('bbname'),
			'post' => array('bbname','cat','cat1'),
			'edit' => array('bbname'),
			'search' => array('bbname'),
			'member' => array('bbname', 'username'),
			'collection' => array('bbname', 'username'),
			'mypraise' => array('bbname', 'username'),
			'myreply' => array('bbname', 'username'),
			'attes' => array('bbname', 'username'),
			'my' => array('bbname', 'username'),
		);
		showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=seo');
		showtableheader();
		foreach($page as $key => $value) {
			$code = $lang['code'];
			foreach($value as $v) {
				$code .= '<a onclick="insertContent(this, \'{'.$v.'}\');return false;" href="javascript:;" title="'.$lang[$v].'">{'.$lang[$v].'}</a>';
			}
			showtitle($lang['page_'.$key]);
			showsetting($lang['seotitle'], 'aljtc_seo['.$key.'][seotitle]', $aljtc_seo[$key]['seotitle'], 'text', '', 0, $code);
			showsetting($lang['seokeywords'], 'aljtc_seo['.$key.'][seokeywords]', $aljtc_seo[$key]['seokeywords'], 'text', '', 0, $code);
			showsetting($lang['seodescription'], 'aljtc_seo['.$key.'][seodescription]', $aljtc_seo[$key]['seodescription'], 'text', '', 0, $code);
		}
		showsubmit('seosubmit');
		showtablefooter();
		showformfooter();
		
	} else {
		$aljtc_seo = serialize($_GET['aljtc_seo']);
		DB::query("REPLACE INTO ".DB::table('common_setting')." (skey, svalue) VALUES ('aljtc_seo', '$aljtc_seo')");
		updatecache('setting');

		cpmsg('seo_update_succeed', 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=seo', 'succeed');
	}
}
//From: Dism_taobao_com
?>