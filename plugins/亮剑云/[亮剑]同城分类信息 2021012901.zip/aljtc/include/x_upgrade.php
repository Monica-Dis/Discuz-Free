<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql ="ALTER TABLE  ".DB::table('aljtc_position')." ADD  `is_open` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
echo 'success';
exit;
?>