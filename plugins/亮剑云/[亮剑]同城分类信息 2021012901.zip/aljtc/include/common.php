<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$settings=DB::fetch_all('select * from %t',array('aljtc_setting'));
foreach($settings as $tmp_key => $tmp_value) {
	$tmp_settings[$tmp_value['key']] = $tmp_value;
}
$settings = $tmp_settings;

if(($_G['cache']['plugin']['aljtc']['pc_look_mobile'] || $_GET['adminedit'] == 'yes') && $_GET['dzAdmin'] != '1' && !$_G['mobile']){
	if(strtolower(CHARSET) == 'gbk' && !$_GET[noget]){
		$_GET=T::ajaxGetCharSet($_GET);
	}
	define('IS_PC', 1);
}

foreach($_G['setting']['hookscript'] as $hook_k => $hook_v){
    foreach($hook_v as $glo_k => $glo_v){
      if($glo_k != 'avatar'){
        $_G['setting']['hookscript'][$hook_k][$glo_k] = array();
      }
    }
}


foreach($_G['setting']['hookscriptmobile'] as $h_m_k => $h_m_v){
  foreach($h_m_v as $m_v_k => $m_v_v){
    if($m_v_k != 'avatar'){
      $_G['setting']['hookscriptmobile'][$h_m_k][$m_v_k] = array();
    }
  }
}
if($_GET['dzAdmin'] != '1'){
	define('IN_MOBILE', 2);
	$_G['mobile'] = 2;
}
if((stripos($_SERVER['HTTP_USER_AGENT'], 'iPhone')!==false || stripos($_SERVER['HTTP_USER_AGENT'], 'iPad')!==false || stripos($_SERVER['HTTP_USER_AGENT'], 'Android')!==false) && strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
    $yes_wx = 1;
}
if(($_G['cache']['plugin']['mapp_share'] || $_G['cache']['plugin']['aljwx'] || $_G['cache']['plugin']['aljtwx']) && $yes_wx){
    define('IN_MINI', '1');
}
$oss_domain = $_G['cache']['plugin']['aljoss']['cdn_domain'] ? $_G['cache']['plugin']['aljoss']['cdn_domain'] : $_G['cache']['plugin']['aljoss']['domain'];
if($_G['groupid'] == 1){
	$admin_status = 1;
}
$version = '201900911';
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false && $settings['mini_hide']['value']==1 && strpos(strtolower($_SERVER['HTTP_USER_AGENT']),"miniprogram") !== false){
//if($settings['mini_hide']['value']==1){
	$hide_mini = 1;
}
if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0  || strpos($_SERVER['HTTP_USER_AGENT'],"Html5Plus") !== false){
	$isappbyme = true;
}
if(strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPPX')>0){
    $ismagapp = true;
}
if(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'qianfan') !== false){
    $isqianfanapp = true;
}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false && strpos(strtolower($_SERVER['HTTP_USER_AGENT']),"miniprogram") !== false){
	$ismini = 1;
}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
	$iswechat = 1;
}
$color = $settings['allbackcolor']['value'];

$fz_path = DISCUZ_ROOT . "source/plugin/aljtfz/include";
if(is_file("$fz_path/fz_cookie.php") && $_G['cache']['plugin']['aljtfz']['site_show']){include_once "$fz_path/fz_cookie.php";}
function tc_message($msg, $type='',$url = ''){
    if($_SERVER['REQUEST_METHOD'] == 'POST') {
        echo "<script>parent.tips('".$msg."','".$url."','".$type."');</script>";
		exit;
    }else{
        return $msg;
    }
    return false;
}
$_G['makehtml'] = 1;//������ͨ�û��鿴 SEO ����
//��������δ������
if($_G['cache']['plugin']['aljol'] && $_G['uid']){
    $newscount = DB::result_first('select count(*) from %t where friendid=%d and talkstate=1',array('aljol_talk',$_G['uid']));
    $new_noti = DB::result_first('select count(*) from %t where uid=%d and status=0 and news_type=1',array('aljhtx_notification',$_G['uid']));
    $newscount = $newscount + $new_noti;
}
//From: Dism��taobao��com
?>