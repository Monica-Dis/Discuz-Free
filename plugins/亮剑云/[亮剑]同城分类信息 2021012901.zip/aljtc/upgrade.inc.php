<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$expiry_time = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'expiry_time\'', array('aljtc'), true);
if(!$expiry_time){
	$sql ="ALTER TABLE  ".DB::table('aljtc')." ADD  `expiry_time` int(11) NOT NULL" ;
	DB::query($sql,'SILENT');
	$sql ="ALTER TABLE ".DB::table('aljtc')." ADD INDEX(`expiry_time`)";
	DB::query($sql,'SILENT');
}
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljtc_see_tel')." (
`id` int(10) NOT NULL AUTO_INCREMENT,
`uid` int(11) DEFAULT '0',
`type` int(11) DEFAULT '0',
`lid` int(11) DEFAULT '0',
`addtime` int(11) DEFAULT '0',
`username` varchar(255) DEFAULT NULL,
PRIMARY KEY (`id`),
KEY `lid` (`lid`)
)";
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc')." ADD  `is_anonymous` tinyint(4) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_custom')." ADD  `custom_charge` tinyint(4) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_custom')." ADD  `custom_charge_price` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_custom')." ADD  `jifen_type` tinyint(4) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_custom')." ADD  `jifen` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_see_tel')." ADD  `customid` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_see_tel')." ADD  `jifen_type` tinyint(4) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_see_tel')." ADD  `jifen` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_see_tel')." ADD  `price` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_see_tel')." ADD  `orderid` CHAR(32) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE  ".DB::table('aljtc')." ADD  `fz_id` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_attestation')." ADD  `fz_id` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljbd_goods_order')." ADD  `fz_id` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtc_position')." ADD  `is_open` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
cpmsg('success');
exit;
?>