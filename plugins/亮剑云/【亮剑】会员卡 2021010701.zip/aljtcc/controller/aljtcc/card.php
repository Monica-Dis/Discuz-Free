<?php

/**
 * ��Ա��
 *
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * @version 1.0
 * @link http://docs.liangjianyun.com/
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class CardAction{
    public $page;

    public function __construct() {
        global $requestPage;
        $this->page = $requestPage;
    }

    public function list_index(){
        global $_G;
        
        if($this->page->get->render == 'yes'){
            $per = 20;
            $page = $this->page->get->page>0 ? $this->page->get->page :1;
            $start = ($page - 1) * $per;
            
            
            $logList = DB::fetch_all('select * from %t order by id desc limit %d, %d', array('aljtcc_card', $start, $per));
            $count = DB::result_first('select count(*) from %t', array('aljtcc_card'));
            
            foreach($logList as $k => $v){
                $logList[$k]['createtime'] = dgmdate($v['createtime'], 'Y-m-d H:i:s');
                $logList[$k]['updatetime'] = dgmdate($v['updatetime'], 'Y-m-d H:i:s');
            }
            T::responseJson(array(
                'code' => 0,
                'msg' => "",
                'count' => $count,
                'data' => $logList
            ));
        }

       
        $this->page->display();
    }

    public function list_delete(){
        DB::delete('aljtcc_card', array('id' => $_GET['mid']));
        T::responseJson();
    }


    public function list_submit(){
        global $_G;
        $mid = $_GET['mid'];
        $data = DB::fetch_first('select * from %t where id=%d', array('aljtcc_card', $_GET['mid']));
        
        if($data){
            $data['card_authority'] = explode(',',$data['card_authority']);
        }
        if(submitcheck('formhash')){
            if ($this->page->get->uploadPhoto && $this->page->get->size == strlen($this->page->get->uploadPhoto)) {
                $pic = T::getPhotoFilePath();
                file_put_contents($pic, file_get_contents($this->page->get->uploadPhoto));
                if (file_exists($pic)) {
                    if($this->page->config->aljoss->Access_Key){
                        $pic = T::oss($pic, 'aljhtx/setting');
                    }
                }
            }
            $updatedata = array(
                'card_title' => $_GET['card_title'],
                'card_intro' => $_GET['card_intro'],
                'card_color' => $_GET['card_color'],
                'card_rights_title' => $_GET['card_rights_title'],
                'card_rights_title_color' => $_GET['card_rights_title_color'],
                'card_rights_intro' => $_GET['card_rights_intro'],
                'integral_multiple' => $_GET['integral_multiple'],
                'card_tc_post' => $_GET['card_tc_post'],
                'card_tsq_post' => $_GET['card_tsq_post'],
                'card_authority'=>implode(',',$_GET['card_authority']),
                'updatetime' => TIMESTAMP
            );

            if(getcookie('dev')){
                $updatedata['card_type'] = $_GET['card_type'];
            }

            if($pic){
                $updatedata['card_logo'] = $pic;
            }
            if($data){
                DB::update('aljtcc_card', $updatedata, array('id' => $mid));
            }else{
                $updatedata['createtime'] = TIMESTAMP;
                $mid = DB::insert('aljtcc_card', $updatedata, true);
            }
            $this->page->tips();
        }else{
            $this->page->assign('data', $data);
            $this->page->display();
        }
    }

    public function list_template_index(){
        global $_G;
        $card_id = intval($_GET['card_id']);
        if($this->page->get->render == 'yes'){
            $per = $_GET['limit'] ? intval($_GET['limit']) : 20;
            $page = $this->page->get->page>0 ? $this->page->get->page :1;
            $start = ($page - 1) * $per;

            $logList = DB::fetch_all('select * from %t where card_id=%d order by id desc limit %d, %d', array('aljtcc_card_attr', $card_id, $start, $per));
            $count = DB::result_first('select count(*) from %t where card_id=%d', array('aljtcc_card_attr', $card_id));

            foreach($logList as $k => $v){
                $logList[$k]['createtime'] = dgmdate($v['createtime'], 'Y-m-d H:i:s');
                $logList[$k]['updatetime'] = dgmdate($v['updatetime'], 'Y-m-d H:i:s');
                $logList[$k]['is_hide'] = $v['is_hide'] ? lang("plugin/aljtcc","card_php_2") : lang("plugin/aljtcc","card_php_3");
            }
            T::responseJson(array(
                'code' => 0,
                'msg' => "",
                'count' => $count,
                'data' => $logList
            ));
        }

        $this->page->assign('card_id', $card_id);
        $this->page->display();
    }

    public function list_template_user(){
        global $_G;
        $card_id = intval($_GET['card_id']);
        if($this->page->get->render == 'yes'){
            $per = $_GET['limit'] ? intval($_GET['limit']) : 20;
            $page = $this->page->get->page>0 ? $this->page->get->page :1;
            $start = ($page - 1) * $per;

            $logList = DB::fetch_all('select * from %t where card_id=%d order by card_no desc limit %d, %d', array('aljtcc_card_user', $card_id, $start, $per));
            $count = DB::result_first('select count(*) from %t where card_id=%d', array('aljtcc_card_user', $card_id));

            foreach($logList as $k => $v){
                $logList[$k]['start_time'] = dgmdate($v['start_time'], 'Y-m-d H:i:s');
                $logList[$k]['end_time'] = dgmdate($v['end_time'], 'Y-m-d H:i:s');
            }
            T::responseJson(array(
                'code' => 0,
                'msg' => "",
                'count' => $count,
                'data' => $logList
            ));
        }

        $this->page->assign('card_id', $card_id);
        $this->page->display();
    }

    public function list_template_user_submit(){
        global $_G;
        $card_id = $_GET['card_id'];
        
        
        if(submitcheck('formhash')){
            if(is_numeric($_GET['username'])){
                $uid = $_GET['username'];
                $username = DB::result_first('select username from %t where uid=%d', array('common_member', $_GET['username']));
            }else{
                $username = $_GET['username'];
                $uid = DB::result_first('select uid from %t where username=%s', array('common_member', $_GET['username']));
            }
            if($uid<=0){
                $this->page->tips('".lang("plugin/aljtcc","card_php_1")."');
            }
            $user = DB::fetch_first('select * from %t where uid=%d and card_id=%d', array('aljtcc_card_user', $uid, $card_id));
            if($user){
                DB::query('update %t set end_time = end_time+%d where uid=%d and card_id=%d', array('aljtcc_card_user', $_GET['day_num'] * 86400, $uid, $card_id));
            }else{
                DB::insert('aljtcc_card_user', array(
                    'uid' => $uid,
                    'card_id' => $card_id,
                    'username' => $username,
                    'start_time' => TIMESTAMP,
                    'end_time' => TIMESTAMP + $_GET['day_num'] * 86400
                ));
            }
            $this->page->tips();
        }else{
            $this->page->assign('card_id', $card_id);
            $this->page->display();
        }
    }


    public function list_template_user_delete(){
        if($_GET['cid']){
            $cids[] = $_GET['cid'];
        }else{
            $cids = explode(',', $_GET['cids']);
        }
        
        if($cids){
            foreach($cids as $cid){
                DB::delete('aljtcc_card_user', array('card_no' => $cid));
            }
        }
       
        T::responseJson();
    }

    public function list_template_delete(){
        if($_GET['cid']){
            $cids[] = $_GET['cid'];
        }else{
            $cids = explode(',', $_GET['cids']);
        }
        
        if($cids){
            foreach($cids as $cid){
                DB::delete('aljtcc_card_attr', array('id' => $cid));
            }
        }
       
        T::responseJson();
    }


    public function list_template_submit(){
        global $_G;
        $card_id = intval($_GET['card_id']);
        $mid = $_GET['mid'];
        $data = DB::fetch_first('select * from %t where id=%d', array('aljtcc_card_attr', $_GET['mid']));
        if(submitcheck('formhash')){
            if ($this->page->get->uploadPhoto && $this->page->get->size == strlen($this->page->get->uploadPhoto)) {
                $pic = T::getPhotoFilePath();
                file_put_contents($pic, file_get_contents($this->page->get->uploadPhoto));
                if (file_exists($pic)) {
                    if($this->page->config->aljoss->Access_Key){
                        $pic = T::oss($pic, 'aljhtx/setting');
                    }
                }
            }
            $updatedata = array(
                'card_attr_title' => $_GET['card_attr_title'],
                'card_attr_day_num' => $_GET['card_attr_day_num'],
                'card_attr_day_desc' => $_GET['card_attr_day_desc'],
                'card_attr_price' => $_GET['card_attr_price'],
                'card_attr_price_old' => $_GET['card_attr_price_old'],
                'card_attr_price_app' => $_GET['card_attr_price_app'],
                'card_desc' => $_GET['card_desc'],
                'is_hide' => $_GET['is_hide'],
                'updatetime' => TIMESTAMP
            );

            if($pic){
                $updatedata['card_logo'] = $pic;
            }
            if($data && !$_GET['copy']){
                DB::update('aljtcc_card_attr', $updatedata, array('id' => $mid));
            }else{
                $updatedata['createtime'] = TIMESTAMP;
                $updatedata['card_id'] = $card_id;
                
                $mid = DB::insert('aljtcc_card_attr', $updatedata, true);
            }
            $this->page->tips();
        }else{
            $this->page->assign('card_id', $card_id);
            $this->page->assign('data', $data);
            $this->page->display();
        }
    }
}

