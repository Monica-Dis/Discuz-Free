<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljtcc_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_title` varchar(255) NOT NULL,
  `card_intro` varchar(255) NOT NULL,
  `card_logo` varchar(255) NOT NULL,
  `card_type` tinyint(3) NOT NULL,
  `createtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `integral_multiple` int(11) NOT NULL,
  `card_color` varchar(255) NOT NULL,
  `card_rights_title` char(50) NOT NULL,
  `card_rights_title_color` char(50) NOT NULL,
  `card_rights_intro` text NOT NULL,
  `card_authority` text NOT NULL,
  `card_tc_post` decimal(10,2) NOT NULL,
  `card_tsq_post` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljtcc_card_attr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_id` int(11) NOT NULL,
  `card_attr_title` varchar(255) NOT NULL,
  `card_attr_day_num` int(11) NOT NULL,
  `card_attr_day_desc` varchar(255) NOT NULL,
  `card_attr_price` double(15,2) NOT NULL,
  `card_attr_price_old` double(15,2) NOT NULL,
  `card_attr_price_app` double(15,2) NOT NULL,
  `card_desc` varchar(255) NOT NULL,
  `createtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `is_hide` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljtcc_card_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `card_number` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `trade_mod` char(50) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `buyer` varchar(255) NOT NULL,
  `confirmdate` int(11) NOT NULL,
  `card_id` int(11) NOT NULL,
  `card_attr_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljtcc_card_user` (
  `card_no` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `start_time` int(11) NOT NULL,
  `end_time` int(11) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `card_id` int(11) NOT NULL,
  PRIMARY KEY (`card_no`)
);
INSERT INTO `pre_aljtcc_card` (`id`, `card_title`, `card_intro`, `card_logo`, `card_type`, `createtime`, `updatetime`, `card_color`) VALUES
(1, '$installlang[install_php_1]', '$installlang[install_php_2]', 'https://oss.liangjianyun.com/aljhtx/setting/20190911/1568192538742.png', 0, 1567590338, 1568197430, '#237ffd'),
(2, '$installlang[install_php_3]', '$installlang[install_php_4]', '', 1, 1568197510, 1568197510, '#237ffd');
INSERT INTO `pre_aljtcc_card_attr` (`id`, `card_id`, `card_attr_title`, `card_attr_day_num`, `card_attr_day_desc`, `card_attr_price`, `card_attr_price_old`, `card_attr_price_app`, `card_desc`, `createtime`, `updatetime`) VALUES
(1, 1, '$installlang[install_php_5]', 365, '$installlang[install_php_6]', 365.00, 288.00, 88.00, '$installlang[install_php_7]', 1567592961, 1568196275),
(2, 1, '$installlang[install_php_8]', 90, '$installlang[install_php_9]', 88.00, 188.00, 48.00, '$installlang[install_php_10]', 1568106126, 1568106126);
INSERT INTO `pre_aljtcc_card_attr` (`id`, `card_id`, `card_attr_title`, `card_attr_day_num`, `card_attr_day_desc`, `card_attr_price`, `card_attr_price_old`, `card_attr_price_app`, `card_desc`, `createtime`, `updatetime`) VALUES
(3, 2, '$installlang[install_php_11]', 365, '$installlang[install_php_12]', 365.00, 288.00, 88.00, '$installlang[install_php_13]', 1567592961, 1568196275),
(4, 2, '$installlang[install_php_14]', 90, '$installlang[install_php_15]', 88.00, 188.00, 48.00, '$installlang[install_php_16]', 1568106126, 1568106126);
EOF;
runquery($sql);
$sql ="ALTER TABLE  ".DB::table('aljtcc_card_order')." ADD `fz_id` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtcc_card_order')." ADD `cid` int(11) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE  ".DB::table('aljtcc_card_order')." ADD `discount` decimal(10,2) NOT NULL" ;
DB::query($sql,'SILENT');
//finish to put your own code
if(file_exists("source/plugin/aljqb/aljqb.inc.php")) {
  if(!DB::result_first('select count(*) from %t where pluginname=%s',array('aljqb_secretkey','aljtcc'))){
      loadcache('plugin');
      DB::insert('aljqb_secretkey',array('pluginname'=>'aljtcc','secretkey'=>'shenmikey123','tokenurl'=>rtrim($_G['siteurl'],'/').'/source/plugin/aljtcc/pay/pay.php'));
  }
}
$finish = TRUE;
?>