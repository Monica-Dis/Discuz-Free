<?php

/**
 * �������̳�
 *
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * @version 2019080501
 * @link http://docs.liangjianyun.com/
 */


if( ! defined('IN_DISCUZ') || ! defined('IN_ADMINCP')) {
    exit('Access Denied');
}


$sql = <<<EOF
DROP TABLE IF  EXISTS `pre_aljtcc_card`;
DROP TABLE IF  EXISTS `pre_aljtcc_card_attr`;
DROP TABLE IF  EXISTS `pre_aljtcc_card_order`;
DROP TABLE IF  EXISTS `pre_aljtcc_card_user`;
EOF;
if(file_exists("source/plugin/aljhtx/aljhtx.inc.php")) {
	$un_set = DB::fetch_all('select * from %t', array('aljhtx_system_setting'),'skey');
	if($un_set['is_del_mysql']['svalue']){
		runquery($sql);	
	}
}
//From: Dism��taobao��com
?>
