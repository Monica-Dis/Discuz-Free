<?php

/**
 * �̼����ֺ�̨���ҳ
 *
 * @author (C)2019-2021 DISM.Taobao.COM.
 * @version 1.0
 * @link http://t.cn/Aiux1Jx1
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

echo "<script language='javascript'>";
echo "parent.location.href='plugin.php?id=aljhtx'";
echo "</script>";
exit;
?>