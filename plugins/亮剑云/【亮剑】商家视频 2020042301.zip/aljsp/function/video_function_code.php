<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function videourl($url){
    if(strpos($url, 'player.youku.com/') !== FALSE) {//�ſ�flash����
        if(preg_match("/sid\/([^\/]*)/i", $url, $matched)) {
            $videoplayerurl = '//player.youku.com/embed/' . $matched[1];
        }
    }elseif(strpos($url, 'new-play.tudou.com/') !== FALSE || strpos($url, 'video.tudou.com/') !== FALSE || strpos($url, 'compaign.tudou.com/') !== FALSE ) {//������ַ
        if(preg_match("/tudou.com\/v\/(.*).html/i", $url, $matched)) {
            $videoid = trim($matched[1]);
        } elseif(preg_match("v_show/show\/id_(.*).html/i", $url, $matched)) {
            $videoid = trim($matched[1]);
        }
        if(empty($videoid)) {
            return '<a href="' . $url . '">' . $url . '</a>';
        }

        $json = dfsockopen("https://api.youku.com/videos/show.json?video_id=" . $videoid . "&client_id=b10ab8588528b1b1");
        $videoinfo = json_decode($json, true);

        if(empty($videoinfo['id'])) {
            return '<a href="' . $url . '">' . $url . '</a>';
        }

        $videoplayerurl = '//player.youku.com/embed/' . $videoinfo['id'];

    }elseif(strpos($url, 'v.qq.com/iframe/') !== FALSE || strpos($url, 'v.qq.com/x/page/') !== FALSE || strpos($url, 'v.qq.com/x/cover/') !== FALSE || strpos($url, 'm.v.qq.com/play') !== FALSE) {//��Ѷ��ҳ����
        if(preg_match('/\?vid=(.*)&tiny=0/i', $url, $matched)) {
            $videoid = $matched[1];
        } elseif(preg_match('/&vid=(.*)&ptag/i', $url, $matched)) {
            $videoid = $matched[1];
        } else {
            $start = strripos($url, "/") + 1;
            $length = strripos($url, ".html") - $start;
            $videoid = trim(substr($url, $start, $length));
        }

        if(empty($videoid)) {
            return '<a href="' . $url . '">' . $url . '</a>';
        }

        $videoplayerurl = '//v.qq.com/iframe/player.html?vid=' . $videoid . '&tiny=0&auto=0';

    } elseif(strpos($url, 'v.youku.com/v_show/') !== FALSE || strpos($url, 'player.youku.com/embed/') !== FALSE || strpos($url, 'm.youku.com/video/') !== FALSE) {//�ſ���ҳ����
        if(preg_match('/id_(.*).html/i', $url, $matched)) {
            $videoid = $matched[1];
        } else {
            $start = strripos($url, "/") + 1;
            $videoid = trim(substr($url, $start));
        }

        if(empty($videoid)) {
            return '<a href="' . $url . '">' . $url . '</a>';
        }

        $videoplayerurl = '//player.youku.com/embed/' . $videoid;

    } elseif(strpos($url, 'www.iqiyi.com') !== FALSE || strpos($url, 'm.iqiyi.com') !== FALSE) {//��������ҳ����
        if(preg_match('/\?vid=(.*)&tvId=(.*)&accessToken=/i', $url, $matched)) {
            $videoid = $matched[1];
            $videoid2 = $matched[2];
        } elseif(preg_match('/\#curid=(.*)/i', $url, $matched)) {
            list($videoid2, $videoid) = explode('_', $matched[1]);
            $videoid = trim($videoid);
            $videoid2 = trim($videoid2);
        }

        if(empty($videoid) || empty($videoid2)) {
            return '<a href="' . $url . '">' . $url . '</a>';
        }
        $videoplayerurl = '//open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid=' . $videoid . '&tvId=' . $videoid2;
    }
    if($videoplayerurl){
        return '<iframe src="' . $videoplayerurl . '" class="vr_iframe"  frameborder="0" allowfullscreen width="100%" height="100%"></iframe>';
    }else{//���ô���ֱ�ӷ���
        return $url;
    }

}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>