<?php
/*
	Copyright (c) 2021 by dism.taobao.com
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljbd_video` (
  `id` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `bid` mediumint(9) unsigned NOT NULL,
  `timestamp` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  `type` int(11) NOT NULL,
  `subtype` int(11) NOT NULL,
  `subtype3` int(11) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `jieshao` mediumtext NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `videourl` mediumtext NOT NULL,
  `view` int(11) NOT NULL,
  `rubbish` int(10) NOT NULL,
  `status` TINYINT( 3 ) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `video_path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bid` (`bid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljbd_type_video` (
  `id` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `type_url` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  PRIMARY KEY (`id`)
)
EOF;
runquery($sql);
//��������ҳͼ�굼�� ��Ƶ
$mobile_view_imgnav = C::t('#aljbd#aljbd_setting')->fetch('mobile_view_imgnav');
if($mobile_view_imgnav){
    $mobile_view_imgnav_value = $mobile_view_imgnav['value'];
    $mobile_view_imgnav_value .= '
source/plugin/aljbd/images/sj/shipin.png|plugin.php?id=aljbd&act=view&bid={bid}&op=video&mobile=2|&#35270;&#39057;';
    C::t('#aljbd#aljbd_setting')->update_value_by_key($mobile_view_imgnav_value,'mobile_view_imgnav');
}
//finish to put your own code
$finish = TRUE;
?>