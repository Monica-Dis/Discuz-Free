<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(!isset($_G['cache']['plugin'])) {
	loadcache('plugin');
}
$plugin = DB::fetch_first('select * from %t where identifier = %s', array('common_plugin', 'aljhtx'));
if(empty($plugin)){
    cpmsg('&#35831;&#20808;&#23433;&#35013;&#21830;&#23478;&#21161;&#25163;&#25554;&#20214;');
}
$plugin = DB::fetch_first('select * from %t where identifier = %s and available=1', array('common_plugin', 'aljhtx'));
if(empty($plugin)){
    cpmsg('&#35831;&#20808;&#21551;&#29992;&#21830;&#23478;&#21161;&#25163;&#25554;&#20214;');
}
$plugin = DB::fetch_first('select * from %t where identifier = %s', array('common_plugin', 'aljht'));
if($plugin['available']){
	echo '<iframe style="width:100%;height:100%;min-height:780px;border:none;" src="plugin.php?id=aljht&act=admin&op=videolist&ajax=yes"></iframe>';
	exit;
}

if($_G['cache']['plugin']['aljbd']['iswatermark']){
	require_once DISCUZ_ROOT.'source/plugin/aljbd/class/class_image.php';
	$image = new aljbd_image;
}
$pluginid='aljsp';
$pluginid_1='aljbd';
$table_name = 'aljbd_video';
if($_GET['act'] == 'view'){
	if(submitcheck('formhash')){
		
		if($_FILES['logo']['tmp_name']) {
			$picname = $_FILES['logo']['name'];
			$picsize = $_FILES['logo']['size'];
		
			if ($picname != "") {
				$type = strtolower(strrchr($picname, '.'));
				if ($type != ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
					showerror(lang('plugin/aljbd','s29'));
				}
				if (($picsize/1024)>$_G['cache']['plugin'][$pluginid]['img_size']) {
					showerror(lang('plugin/aljbd','img1').$_G['cache']['plugin'][$pluginid]['img_size'].'KB');
				}
				$rand = rand(100, 999);
				$pics = date("YmdHis") . $rand . $type;
				$logo = "source/plugin/aljsp/images/logo/". $pics;
				if(@copy($_FILES['logo']['tmp_name'], $logo)||@move_uploaded_file($_FILES['logo']['tmp_name'], $logo)){
					if($_G['cache']['plugin']['aljbd']['iswatermark']){
						$image->Watermark(DISCUZ_ROOT.'./'.$logo,'', 'forum');
					}
					@unlink($_FILES['logo']['tmp_name']);
				}
			}
		}
		
		$updatearray=array(
			'subject'=>$_GET['name'],
			'bid'=>$_GET['bid'],
			
			'jieshao'=>$_GET['jieshao'],
			'timestamp'=>TIMESTAMP,
			'videourl'=>$_GET['videourl'],
			'type'=>$_GET['type'],
			'subtype'=>$_GET['subtype'],
			'subtype3'=>$_GET['subtype3'],
		);
		$c=C::t('#aljsp#aljbd_video')->fetch($_GET['vid']);
		if($logo){
			unlink($c['logo']);
			$updatearray['logo']=$logo;
		}
		C::t('#aljsp#aljbd_video')->update($_GET['vid'],$updatearray);
		showmsg(lang('plugin/aljbd','s54'));
	}else{
		$typelist=C::t('#aljsp#aljbd_type_video')->fetch_all_by_upid(0);
		$bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','',$_G['uid']);
		$n=C::t('#aljsp#aljbd_video')->fetch($_GET['vid']);
		include template($pluginid.':admin_addvideo');
	}
}else{
		$bdlist=C::t('#aljbd#aljbd')->range();
		$bdlist=dhtmlspecialchars($bdlist);
		if(!submitcheck('submit')) {
			showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=admin&state='.$_GET['state'].'&page='.$_GET['page']);
			showtableheader('<input type="text" name="search" value="'.$_GET['search'].'"><input type="submit" >');
			showsubtitle(array('','&#32534;&#21495;','&#35270;&#39057;&#26631;&#39064;','&#25152;&#23646;&#24215;&#38138;', '&#21457;&#24067;&#20154;','&#21457;&#24067;&#26102;&#38388;','&#25805;&#20316;'));
			echo '<script>disallowfloat = "newthread";</script>';
			$currpage=$_GET['page']?$_GET['page']:1;
			$perpage=20;
			$start=($currpage-1)*$perpage;
			$con=" where rubbish=0";
			if($_GET['search']){
				$search='%' . addcslashes($_GET['search'], '%_') . '%';
				$con.=" and subject like '$search'";
			}
			
			$num = DB::result_first('select count(*) from %t $con',array($table_name));
			$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT."?action=plugins&operation=config&do=".$_GET['do']."&identifier=".$pluginid."&pmod=admin&state=".$_GET['state']."&search=".$_GET['search'], 0, 10, false, false);
			$query = DB::query("SELECT * FROM ".DB::table($table_name)." $con ORDER BY id desc limit $start,$perpage");
			while($row = DB::fetch($query)) {
				showtablerow('', array('', 'class="td_m"', 'class="td_k"','class="td_l"', 'class="td_l"','class="td_l"'), array(
								"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$row[id]\"><input type=\"hidden\" value=\"$row[id]\" name=\"myid[]\" >",	
								$row['id'],
								$row['subject'],
								$bdlist[$row['bid']]['name'],	
								$row['username'],		
								dgmdate($row['timestamp']),	
								'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=admin&act=view&vid='.$row[id].'" >&#32534;&#36753;</a>&nbsp;|&nbsp;<a href="plugin.php?id='.$pluginid.'&act=videoview&bid='.$row['bid'].'&vid='.$row[id].'" target="_blank">&#26597;&#30475;</a>',		
								));
				
			}
			
			showsubmit('submit', 'submit', 'del','',$paging);
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*dis'.'m.tao'.'bao.com*/
		}else{
			
			if(is_array($_POST['delete'])) {
				foreach($_POST['delete'] as $id) {
					C::t('#'.$pluginid.'#'.$table_name)->update($id,array('rubbish'=>1));
				}
			}
			
			cpmsg('&#26356;&#26032;&#25104;&#21151;', 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$pluginid.'&pmod=admin&state='.$_GET['state'].'&page='.$_GET['page'], 'succeed');
		}
	
}
function showmsg($msg,$close){
	if($close){
		$str="parent.hideWindow('$close');";
	}else{
		$str="parent.location=parent.location;";
	}
	include template('aljbd:showmsg');
	exit;
}
function showerror($msg){
	include template('aljbd:showerror');
	exit;
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>