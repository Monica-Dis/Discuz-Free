<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$pluginid = 'aljbd';
$is_plugin = DB::fetch_first('select * from %t where  identifier = %s',array('common_plugin',$pluginid));
if(!$is_plugin){
	showmessage('&#26242;&#26410;&#23433;&#35013;&#27492;&#25554;&#20214;&#65281;');
}

$typelist_video=C::t('#aljsp#aljbd_type_video')->range();

$currpage=intval($_GET['page'])?intval($_GET['page']):1;
$perpage=10;
$start=($currpage-1)*$perpage;

foreach(DB::fetch_all('select * from %t',array('common_plugin')) as $cpv){
    $cparray[$cpv['identifier']] = $cpv;
}

if($_G['cache']['plugin']['aljbd'] && file_exists("source/plugin/aljbd/include/aljbd_parameter.php")){
    require_once 'source/plugin/aljbd/include/aljbd_parameter.php';
}


require_once 'source/plugin/aljsp/function/video_function_code.php';
if (file_exists("source/plugin/aljgz/lang/lang.php")) {
    require_once 'source/plugin/aljgz/lang/lang.php';
}
require_once $common_path.'class/class_aljhtx.php';
if($_GET['act']=='videolist'){
    if($_G['cache']['plugin']['aljht']['on'] && (empty($_G['mobile']) || !$_G['setting']['mobile']['allowmobile']) && ($cparray['aljgwc'] || $cparray['aljbdx'])) {
        $my_bd = DB::result_first('select count(*) from %t where uid=%d', array('aljbd', $_G['uid']));
        if ($my_bd) {
            $urlvideo = 'plugin.php?id=aljht&act=admin&op=videolist&mod=my';
        }else{
            $urlvideo = 'plugin.php?id=aljht&act=admin&op=orderlist&mod=my&ord=ge';
        }
        dheader("location: " . $urlvideo);
        exit;
    }
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljbd','s39'));
	}
    if(in_array($_G['groupid'],$admingroups) && $_GET['i'] == 1){
        $uid = 0;
        $sh_status = 1;
    }else{
        if($staff && $bid){//���̵�ԱȨ��
            $uid = 0;
        }else{
            $uid = $_G['uid'];
        }
        $sh_status = 0;
    }
    $nlist = C::t('#aljsp#aljbd_video')->fetch_all_by_uid_bid($uid, $bid, $start, $perpage,'','',$_GET['kw'],0,$_GET['status']);
    $nlist = dhtmlspecialchars($nlist);
    foreach($nlist as $k=>$v){
        $nlist[$k]['bdinfo']=C::t('#aljbd#aljbd')->fetch($v['bid']);
        if($nlist['status'] == 1){
            $nlist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_1');
        }else if($v['status'] == 2){
            $nlist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_2');
        }else{
            $nlist[$k]['sh_status_text'] = lang('plugin/aljbd','goodslist_php_3');
        }
    }
    if($_GET['do'] == 'ajax'){
        require_once $common_path.'class/class_aljhtx.php';
        if($nlist){
            echo json_encode(aljhtx::ajaxPostCharSet($nlist));
        }else{
            echo '1';
        }
        exit;
    }else {
        $num = C::t('#aljsp#aljbd_video')->count_by_uid_bid($uid, $bid,'','',$_GET['kw'],0,$_GET['status']);

        $paging = helper_page:: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=videolist', 0, 11, false, false);
        $navtitle = '&#30&#35270;&#39057;&#31649;&#29702;';
        $metakeywords = $bd['other'] ? $bd['other'] : $config['keywords'];
        $metadescription = $config['description'];
        if($newtemplate){
            include template('aljsp:new/user/videolist');
        }else {
            include template('aljsp:videolist');
        }
    }
}elseif($_GET['act']=='addvideo' || $_GET['act']=='editvideo'){
    
	if(submitcheck('formhash')){
        if($bd['vipid']) {
            $vipdata = DB::fetch_first('select * from %t where id=%d', array('aljbd_vip', $bd['vipid']));
            
            if($_GET['act']=='addvideo'){
                $brandnum['video']=$vipdata['video'];
                $bnum = C::t('#aljsp#aljbd_video')->count_by_uid_bid($_G['uid']);
                if ($brandnum['video'] && !$administrators) {
                    if ($brandnum['video'] == $checksign) {
                        echo "<script>parent.tips('" . lang('plugin/aljbd', 'noauth') . "','');</script>";
                        exit;
                    }
                    if ($bnum >= $brandnum['video']) {
                        $v_tip1 = lang("plugin/aljsp","aljsp_inc_php_3");
                        $v_tip2 = lang("plugin/aljsp","aljsp_inc_php_4");
                        echo "<script>parent.tips('" . $v_tip1 . $brandnum['video'] . $v_tip2 . "','');</script>";
                        exit;
                    }
                }
            }
        }
        if(!$_GET['videourl'] && !$_GET['video_path']){
            echo "<script>parent.tips('".lang("plugin/aljsp","aljsp_inc_php_1")."','');</script>";
            exit;
        }
        if($settings['is_attes']['value']){
            $sign = DB::result_first("select sign from ".DB::table('aljbd_attestation')." where bid=".$bid);
            if(!$sign){
                echo "<script>parent.tips('".lang("plugin/aljsp","aljsp_inc_php_2")."','');</script>";
                exit;
            }
        }
		if($_G['cache']['plugin']['aljhtx']){
            $image_path = 'source/plugin/aljsp/images/logo/';
            if ($_GET['pic']) {
                foreach ($_GET['pic'] as $tmp_key => $tmp_value) {
                    if (strpos($tmp_value,$oss_domain) !== false) {
                        $logo = $tmp_value;
                    }else if (is_file($tmp_value)) {
                        $logo = $tmp_value;
                    } else {
                        unlink($c['logo']);
                        T::delete_oss($c['logo']);
                        $logo = T::saveimg($tmp_value,$image_path);
                    }
                }
            }
        }else{
            if($_FILES['logo']['tmp_name']) {
                $picname = $_FILES['logo']['name'];
                $picsize = $_FILES['logo']['size'];

                if ($picname != "") {
                    $type = strtolower(strrchr($picname, '.'));
                    if ($type != ".gif" && $type != ".jpg"&& $type != ".png"&& $type != ".jpeg") {
                        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                            echo "<script>parent.tips('".lang('plugin/aljbd','s19')."','');</script>";
                            exit;
                        }else{
                            showerror(lang('plugin/aljbd','s19'));
                        }
                    }
                    if (($picsize/1024)>$_G['cache']['plugin'][$pluginid]['img_size']) {
                        if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                            echo "<script>parent.tips('".lang('plugin/aljbd','img1').$_G['cache']['plugin'][$pluginid]['img_size'].'KB'."','');</script>";
                            exit;
                        }else{
                            showerror(lang('plugin/aljbd','img1').$_G['cache']['plugin'][$pluginid]['img_size'].'KB');
                        }
                    }
                    $rand = rand(100, 999);
                    $pics = date("YmdHis") . $rand . $type;
                    $logo = "source/plugin/aljsp/images/logo/". $pics;
                    if(@copy($_FILES['logo']['tmp_name'], $logo)||@move_uploaded_file($_FILES['logo']['tmp_name'], $logo)){
                        if($_G['cache']['plugin']['aljbd']['iswatermark']){
                            $image->Watermark(DISCUZ_ROOT.'./'.$logo,'', 'forum');
                        }
                        @unlink($_FILES['logo']['tmp_name']);
                    }
                }
            }else if($_GET['act']=='addvideo'){
                if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
                    echo "<script>parent.tips('".lang('plugin/aljbd','logo')."','');</script>";
                    exit;
                }else{
                    echo '<script>parent.showDialog("'.lang('plugin/aljbd','logo').'","","")</script>';
                    exit;
                }

            }
        }


		$insertarray=array(
			'subject'=>$_GET['name'],
			'bid'=>$_GET['bid'],
			'jieshao'=>$_GET['jieshao'],
			'videourl'=>$_GET['videourl'],
			'type'=>$_GET['type'],
			'subtype'=>$_GET['subtype'],
			'subtype3'=>$_GET['subtype3'],
		);
        if($_G['cache']['plugin']['aljoss']['Access_Key']){
            $insertarray['video_path'] = $_GET['video_path'];

            if($c && $_GET['del_video']){
                unlink($c['video_path']);
                T::delete_oss($c['video_path']);
                $insertarray['video_path'] = '';
            }
        }
		if($c){
            if($logo){
                $insertarray['logo']=$logo;
            }
            C::t('#aljsp#aljbd_video')->update($_GET['vid'],$insertarray);
            $insertid = $_GET['vid'];
        }else{
            $insertarray['logo'] = $logo;
            $insertarray['timestamp'] = TIMESTAMP;
            $insertarray['username'] = $bd['username'];
            $insertarray['uid'] = $bd['uid'];
            if($vipdata['is_bvideo'] >0 && file_exists("source/plugin/aljht/include/aljbd/addvideo_send.php") && !in_array($_G['groupid'],$admingroups)){
                require_once 'source/plugin/aljht/include/aljbd/addvideo_send.php';
            }
            $insertid=C::t('#aljsp#aljbd_video')->insert($insertarray,true);
        }
        $sh_tips = $sh_tips ? $sh_tips : lang('plugin/aljbd','s53');
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".$sh_tips."',function(){parent.location.href='plugin.php?id=aljsp&act=videolist&bid=".$bid."';});</script>";
			exit;
		}else{
			echo '<script>parent.showDialog("'.$sh_tips.'","right","",function(){parent.location.href=parent.location.href})</script>';
			exit;
		}
	}else{
        if(!$_G['mobile']){
            dheader("location: plugin.php?id=aljht&act=admin&op=videolist&do=addvideo");
            exit;
        }
		if($admin_status){
            $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','','');//����Ա
        }else{
            if($staff && $bid){//���̵�ԱȨ��
                $bdlist = DB::fetch_all('select * from %t where id = %d',array('aljbd',$staff['store_id']));
            }else{
                $bdlist=C::t('#aljbd#aljbd')->fetch_all_by_status(1,'','',$_G['uid']);//����
            }
        }
        $navtitle = '&#28155;&#21152;&#35270;&#39057;';
        $metakeywords = $bd['other'] ? $bd['other'] : $config['keywords'];
        $metadescription = $config['description'];
        if($newtemplate){
            $typelist=C::t('#aljsp#aljbd_type_video')->range();
            $json_typelist = C::t('#aljsp#aljbd_type_video')->fetch_all_json();
            $typejson = json_encode($json_typelist);
            if($c['type']){
                $default_type = $typelist[$c['type']]['subject'].' '. ($typelist[$c['subtype']]['subject']?$typelist[$c['subtype']]['subject']:'--').' '.($typelist[$c['subtype3']]['subject']?$typelist[$c['subtype3']]['subject']:'--');
                $type = $c['type'];
                $subtype = $c['subtype'];
                $subtype3 = $c['subtype3'];
            }else{
                $default_type = diconv($json_typelist[0]['name'].' '. $json_typelist[0]['sub'][0]['name'].' '.$json_typelist[0]['sub'][0]['sub'][0]['name'], 'utf-8', CHARSET);
                $type = $json_typelist[0]['code'];
                $subtype = $json_typelist[0]['sub'][0]['code'];
                $subtype3 = $json_typelist[0]['sub'][0]['sub'][0]['code'];
            }
            include template('aljsp:new/post/addvideo');
        }else {
            include template('aljsp:addvideo');
        }
	}
}elseif($_GET['act'] == 'video'){
    if($_G['mobile']){
        header('location: plugin.php?id=aljbd&act=view&bid='.$_GET['bid'].'&op=video');
        exit;
    }
	$perpage=9;
	$num=C::t('#aljsp#aljbd_video')->count_by_uid_bid($bd['uid'],$_GET['bid']);
	$nlist=C::t('#aljsp#aljbd_video')->fetch_all_by_uid_bid($bd['uid'],$_GET['bid'],$start,$perpage);
	$nlist = dhtmlspecialchars($nlist);
	$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljbd&act=video&bid='.$_GET['bid'], 0, 11, false, false);
    $bd=C::t('#aljbd#aljbd')->fetch($bid);
    if(empty($bd) || $bd['rubbish']==1){
        showmessage(lang('plugin/aljbd','noexists'));
    }
    $rlist=C::t('#aljbd#aljbd_region')->range();
    $typelist=C::t('#aljbd#aljbd_type')->range();
    $navtitle = $bd['name'].' - '.lang("plugin/aljsp","aljsp_inc_php_5");
	include template('aljsp:video');
}elseif($_GET['act'] == 'videoview'){
	C::t('#aljsp#aljbd_video')->update_view_by_gid($_GET['vid']);
	$c=C::t('#aljsp#aljbd_video')->fetch($_GET['vid']);
    if($bid){
        $bd=C::t('#aljbd#aljbd')->fetch($bid);
        $bd = dhtmlspecialchars($bd);
        $view_goods_num = $_G['cache']['plugin']['aljbd']['view_goods_num']?$_G['cache']['plugin']['aljbd']['view_goods_num']:6;//������Ʒ����
        $t=C::t('#aljbd#aljbd_goods')->fetch_all_by_uid_bid_view_new($c['uid'],$bd['id'],0,$view_goods_num,0);
        foreach($t as $k=>$v){
            $t[$k]['price1']=floatval($v['price1']);
            $t[$k]['price2']=floatval($v['price2']);
        }
    }
	$c['name'] = dhtmlspecialchars($c['name']);
    $c['videourl'] = videourl($c['videourl']);

	if(!strpos($c['videourl'],'iframe')){
		$c['videourl'] = dhtmlspecialchars($c['videourl']);
	}

    if($c['videourl'] && strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){

        $version = substr(T::getVersion($_SERVER['HTTP_USER_AGENT'],'micromessenger/') , 0 , 1);
        if(T::get_device_type() == 'ios'){
            if($version<7){
                $c['videourl'] = "";
            }else{
                if(strpos($_SERVER['HTTP_USER_AGENT'],"miniProgram") !== false){//miniProgram
                    $c['videourl'] = "";
                }
            }
        }
    }
    
    $navtitle = $c['subject'].' - '.$bd['name'];
	include template('aljsp:videoview');
}else if($_GET['act']=='deletevideo'){
	
    if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
        if(submitcheck('formhash')){
            
            if ($_GET['vid']) {
                C::t('#aljsp#aljbd_video')->update($_GET['vid'], array('rubbish' => '1'));
            }
            echo 1;
            exit;
        }else{
            $url='plugin.php?id=aljsp&act=deletevideo&vid='.$_GET['vid'];
            include template('aljbd:state');
        }
    }else {
        if ($_GET['formhash'] != FORMHASH) {
            exit('Access Denied!');
        }
        if (empty($_G['uid'])) {
            showmessage(lang('plugin/aljbd', 's39'));
        }
        
        if ($_GET['vid']) {
            C::t('#aljsp#aljbd_video')->update($_GET['vid'], array('rubbish' => '1'));
        }
        showmsg(lang('plugin/aljbd', 's55'));
    }
}else if($_GET['act']=='gettype'){
	if($_GET['upid']){
		$typelist=C::t('#aljsp#aljbd_type_video')->fetch_all_by_upid($_GET['upid']);
	}
	include template('aljsp:gettype');
}else if($_GET['act']=='gettype3'){
	if($_GET['upid']){
		$typelist=C::t('#aljbd#aljbd_type_video')->fetch_all_by_upid($_GET['upid']);
	}
	include template('aljsp:gettype3');
}else{
	showmessage('&#26080;&#26435;&#26597;&#30475;');
}
function showmsg($msg,$close){
	if($close){
		$str="parent.hideWindow('$close');";
	}else{
		$str="parent.location=parent.location;";
	}
	include template('aljbd:showmsg');
	exit;
}
function showerror($msg){
	include template('aljbd:showerror');
	exit;
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>