<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * 最新插件：http://t.cn/Aiux1Jx1
 * From: DisM.taobao.Com
 * 请支持正版授权产品
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_xinrui_list_pic_base{
    function common_base() {
        global $_G;
        loadcache(array('plugin'));
    }

    function parseforumattach($tid, $aids) {
        global $_G;

        if(($aids = array_unique($aids))) {
            require_once libfile('function/attachment');
            $finds = $replaces = array();

            foreach(C::t('forum_attachment_n')->fetch_all_by_id('tid:'.$tid, 'aid', $aids) as $attach) {
                
                $attach['url'] = ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'forum/';
                $attach['dateline'] = dgmdate($attach['dateline'], 'u');
                $extension = strtolower(fileext($attach['filename']));
                $attach['ext'] = $extension;
                $attach['imgalt'] = $attach['isimage'] ? strip_tags(str_replace('"', '\"', $attach['description'] ? $attach['description'] : $attach['filename'])) : '';
                $attach['attachicon'] = attachtype($extension."\t".$attach['filetype']);
                $attach['attachsize'] = sizecount($attach['filesize']);

                $attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
                $aidencode = packaids($attach);
                //$widthcode = attachwidth($attach['width']);
                $is_archive = $_G['forum_thread']['is_archived'] ? "&fid=".$_G['fid']."&archiveid=".$_G['forum_thread']['archiveid'] : '';
                if($attach['isimage']) {
                    $attachthumb = getimgthumbname($attach['attachment']);
                    if($_G['setting']['thumbstatus'] && $attach['thumb']) {
                        if(defined('IN_MOBILE')) {
                            $replaces[] = "<li><span><img src=\"".($attach['refcheck'] ? "forum.php?mod=attachment{$is_archive}&aid=$aidencode" : $attach['url'].$attachthumb)."\" alt=\"$attach[imgalt]\" title=\"$attach[imgalt]\" w=\"$attach[width]\"  /></span></li>";
                        }else{
                            $replaces[] = "<li><span><img id=\"_aimg_$attach[aid]\" aid=\"$attach[aid]\" onclick=\"zoom(this, this.getAttribute('zoomfile'), 0, 0, '{$_G[forum][showexif]}')\"
                        zoomfile=\"".($attach['refcheck']? "forum.php?mod=attachment{$is_archive}&aid=$aidencode&noupdate=yes&nothumb=yes" : $attach['url'].$attach['attachment'])."\"
                        src=\"".($attach['refcheck'] ? "forum.php?mod=attachment{$is_archive}&aid=$aidencode" : $attach['url'].$attachthumb)."\" alt=\"$attach[imgalt]\" title=\"$attach[imgalt]\" w=\"$attach[width]\" /></span></li>";
                        }
                    } else {
                        if(defined('IN_MOBILE')) {
                            $replaces[] = "<li><span><img src=\"".($attach['refcheck'] ? "forum.php?mod=attachment{$is_archive}&aid=$aidencode&noupdate=yes " : $attach['url'].$attach['attachment'])."\" alt=\"$attach[imgalt]\" title=\"$attach[imgalt]\" w=\"$attach[width]\"/></span></li>";
                        }else{
                            $replaces[] = "<li><span><img id=\"_aimg_$attach[aid]\" aid=\"$attach[aid]\" onclick=\"zoom(this, this.getAttribute('zoomfile'), 0, 0, '{$_G[forum][showexif]}')\"
                        zoomfile=\"".($attach['refcheck'] ? "forum.php?mod=attachment{$is_archive}&aid=$aidencode&noupdate=yes&nothumb=yes" : $attach['url'].$attach['attachment'])."\"
                        src=\"".($attach['refcheck'] ? "forum.php?mod=attachment{$is_archive}&aid=$aidencode&noupdate=yes " : $attach['url'].$attach['attachment'])."\" alt=\"$attach[imgalt]\" title=\"$attach[imgalt]\" w=\"$attach[width]\" /></span></li>";
                        }
                    }
                }

            }
            return $replaces ; 
        }
    }


    
    function messagehtml($message,$tid){

        global $_G;
        
        $xinrui_length = $_G['cache']['plugin']['xinrui_list_pic']['xinrui_length'];
        $src = '';

        $arr = $aids = array();

        if(preg_match_all("/\[attach\](\d+)\[\/attach\]/i", $message, $matchaids)) {
				$aids = $matchaids[1];
		}

        if($aids) {
			$arr = $this->parseforumattach($tid, $aids);
		}else{
			foreach(C::t('forum_attachment')->fetch_all_by_id('tid',$tid) as $attach){
				$aids[] = $attach['aid'];
			}
			$arr = $this->parseforumattach($tid, $aids);
			
		}
        
        if(strpos($message, '[/img]') !== FALSE) {
			preg_match_all('/\[img[^\]]*\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/is', $message, $matches);
            if(isset($matches[1])){
                foreach($matches[1] as $key => $val){
                    if(defined('IN_MOBILE')) {
                        $arr[] = '<li><span><img  src= "'.$val.'"/></span></li>';
                    }else{
                        $arr[] = '<li><span><img id="_aimg_'.$key.'" aid="'.$key.'" onclick="zoom(this, this.getAttribute(\'zoomfile\'), 0, 0, \'\')"
                            zoomfile="'.$val.'"
                            src="'.$val.'" title="Chrysanthemum.jpg"  /></span></li>';
                    }
                    
                }
            }
		}else{
			preg_match_all('/src\\s*=\\s*\"?(.*?)(\"|>|\\s+)/is', $message, $matches);
            if(isset($matches[1])){
                foreach($matches[1] as $key => $val){
                    if(defined('IN_MOBILE')) {
                        $arr[] = '<li><span><img  src= "'.$val.'"/></span></li>';
                    }else{
                        $arr[] = '<li><span><img id="_aimg_'.$key.'" aid="'.$key.'" onclick="zoom(this, this.getAttribute(\'zoomfile\'), 0, 0, \'\')"
                            zoomfile="'.$val.'"
                            src="'.$val.'" title="Chrysanthemum.jpg"  /></span></li>';
                    }
                    
                }
            }
		}

        $src = '';
        if($arr){
            foreach($arr as $k => $v){
                if($_G['cache']['plugin']['xinrui_list_pic']['xinrui_picnum'] == 1){
                    $src .= $v;
                    break;
                }else{
                    if($_G['cache']['plugin']['xinrui_list_pic']['xinrui_picnum'] > $k){
                        $src .= $v;
                    }
                }
            }
        }
        
        if($xinrui_length == '-1'){
            $message = '';
        }else{
            $message = trim(messagecutstr($message,$xinrui_length));
        }

        if($_G['cache']['plugin']['xinrui_list_pic']['xinrui_picnum'] == 1){                    
            $html = '<div class="tl_picList cl cfix"><div class="xinruiOneImg"><ul>'.$src.'</ul></div><div class="xinruiInfo">'.$message.'</div></div>'; //一张图片的HTML
        }else{
            $html = '<div class="tl_picList cl cfix"><div class="xinruiInfo">'.$message.'</div><div class="xinruiPic cl cfix"><ul>'.$src.'</ul></div></div>'; //多张图片的HTML
        }
        return $html ; 
    }

}

class plugin_xinrui_list_pic extends plugin_xinrui_list_pic_base {

    function global_header() {
        global $_G;
        $css = '<style type="text/css">.h_avatar,.xr_tl td.o{vertical-align:top}.xr_tl td.o input{margin-top:10px;}.xinruiOneImg span{display:block;}.tl_picList{margin:5px 0;}.xinruiInfo{color:#999;line-height:22px;font-size:13px;}.xinruiPic li{width:92px;height:92px;float:left; margin-right:10px; margin-top:6px;}.xinruiPic span,.xinruiOneImg li span{display:block;width:90px;height:90px;background:#fff;border:solid 1px #eee; border-radius:3px; overflow:hidden; text-align:center; position:relative; cursor:url(source/plugin/xinrui_list_pic/images/cur_zin.cur),pointer; _cursor:url(source/plugin/xinrui_list_pic/images/cur_zin.cur),pointer;} .xinruiOneImg li img, .xinruiPic li img{position:absolute; top:0;left:50%;max-height:100%; transform: translate(-50%);} .xinruiOneImg,.xinruiOneImg ul{float:left;}.xinruiOneImg li{margin-top:0;margin-right:10px;width:90px;height:90px;float:left;}</style>';   //PC版样式
        return $css ;
    }
}

class plugin_xinrui_list_pic_forum extends plugin_xinrui_list_pic_base {

	function forumdisplay_thread_subject_output($value){
		global $_G;

        $xinrui_forums = (array) dunserialize($_G['cache']['plugin']['xinrui_list_pic']['xinrui_forums']);
        $id = $arrs = $arr =  array();

        if(!in_array($_G['groupid'], unserialize($_G['cache']['plugin']['xinrui_list_pic']['xinrui_groups']))){
            return false; 
        }
        if($_G['forum_threadlist']){
            if(is_array($xinrui_forums) && in_array($_G['fid'], $xinrui_forums)){
                if($_G['cache']['plugin']['xinrui_list_pic']['xinrui_pcview'] == 1){
                    foreach($_G['forum_threadlist'] as $key => $val){
                        $id[] = $val['tid'];
                    }
                    if($id){
                        $ids = implode(',',$id);
                        $rs = DB::fetch_all('SELECT tid,message FROM '.DB::table('forum_post').' WHERE tid in ('.$ids.') and first = 1 ');
                        foreach($rs as $key => $val){
                            $arrs[$val['tid']] = $val ;
                        }
                        require_once libfile('function/post');
                        foreach($_G['forum_threadlist'] as $key => $thread) {
                            $arr[] = $this->messagehtml($arrs[$thread['tid']]['message'],$arrs[$thread['tid']]['tid']);
                        }	
                    }
                }
            }
        }
		return $arr;
	}
}
class mobileplugin_xinrui_list_pic extends plugin_xinrui_list_pic_base {

    function global_header_mobile() {
        global $_G;
        $css = '<style type="text/css">.tl_picList{padding:5px 10px;}.xinruiInfo{font-size:13px;line-height:22px;}.xinruiPic li{display:block;width:33.3%;height:90px;float:left;margin-top:6px;border:none;}.xinruiPic span,.xinruiOneImg span{display:block;margin:0 3px;background:#fff;border:solid 1px #eee;border-radius:3px;height:90px;overflow:hidden;text-align:center;position:relative;} .xinruiOneImg{float:left;margin-right:10px;border:none;} .xinruiOneImg li{width:92px;height:92px; border:none;}.xinruiOneImg span{margin:0;}.xinruiOneImg li img,.xinruiPic li img{position:absolute;top:0;left:50%;max-height:100%;max-width:none;transform: translate(-50%);} .threadlist .threadlist .tl_picList{padding:5px 0 0;}.threadlist .threadlist .xinruiInfo{color:#999;}</style>';   //手机版样式
        return $css ;
	}
    
}

class mobileplugin_xinrui_list_pic_forum extends plugin_xinrui_list_pic_base {

	function forumdisplay_thread_mobile_output($value){
		global $_G;
        $xinrui_forums = (array) dunserialize($_G['cache']['plugin']['xinrui_list_pic']['xinrui_forums']);
        $id = $arrs = $arr = array();

        if(!in_array($_G['groupid'], unserialize($_G['cache']['plugin']['xinrui_list_pic']['xinrui_groups']))){
            return false; 
        }

        if($_G['forum_threadlist']){
            if(is_array($xinrui_forums) && in_array($_G['fid'], $xinrui_forums)){
                if($_G['cache']['plugin']['xinrui_list_pic']['xinrui_mobileview'] == 1){
                    foreach($_G['forum_threadlist'] as $key => $val){
                        $id[] = $val['tid'];
                    }

                    if($id){
                        $ids = implode(',',$id);
                        $rs = DB::fetch_all('SELECT tid,message FROM '.DB::table('forum_post').' WHERE tid in ('.$ids.') and first = 1 ');
                        foreach($rs as $key => $val){
                            $arrs[$val['tid']] = $val ;
                        }
                        require_once libfile('function/post');
                        foreach($_G['forum_threadlist'] as $key => $thread) {
                           $arr[] = $this->messagehtml($arrs[$thread['tid']]['message'],$arrs[$thread['tid']]['tid']);
                        }	
                    }
                }
            }
        }
		return $arr;
	}
}