<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * 最新插件：http://t.cn/Aiux1Jx1
 * From: DisM.taobao.Com
 * 请支持正版授权产品
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
dheader('Location: http://dism.taobao.com/?@xinrui');