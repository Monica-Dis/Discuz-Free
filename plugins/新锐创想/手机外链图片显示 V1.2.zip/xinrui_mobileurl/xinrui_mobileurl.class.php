<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_xinrui_mobileurl_base{
    function common_base() {
        global $_G;
        loadcache(array('plugin'));
    }
}

class mobileplugin_xinrui_mobileurl extends plugin_xinrui_mobileurl_base {

    function global_header_mobile() {
        global $_G;
        return '<style style="text/css">.xinruimobileurl img{max-width:100% !important;max-height:100% !important}</style>';
	}

    function discuzcode($value){
        global $_G;
        $message = $_G['discuzcodemessage'] ;

        if(strpos($message, '[/img]') !== FALSE) {
			$message = preg_replace_callback(array(
				"/\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/",
				"/\[img=(\d{1,4})[x|\,](\d{1,4})\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/"
			), array($this,"bbcodeurl1"), $message);
		}

        if(strpos($message, '[/url]') !== FALSE) {
			$message = preg_replace_callback(array(
                "/\[url=([^\]]+)\]([^\[]+)\[\/url\]/",
			), array($this,"bbcodeurl2"), $message);
		}
        $_G['discuzcodemessage'] = $message ;
    }

    function bbcodeurl1($url){
        if(isset($url[3]) && !empty($url[3])){
            return '<span class="xinruimobileurl"><img src="'.$url[3].'"/></span>';
        }else{
            return '<span class="xinruimobileurl"><img src="'.$url[1].'"/></span>';
        }
    }

    function bbcodeurl2($url){
        return '<a href="'.$url[1].'" target="_blank">'.$url[2].'</a>';
    }

}

//From: Dism_taobao_com
?>
