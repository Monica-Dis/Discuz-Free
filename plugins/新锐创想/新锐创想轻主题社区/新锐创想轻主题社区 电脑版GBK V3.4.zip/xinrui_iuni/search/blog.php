<?php echo 'From: DisM.taobao.com';exit;?>
<!--{subtemplate common/header}-->
<div id="ct" class="w">
	<div class="bp schHd">
		<form class="searchform" method="post" autocomplete="off" action="search.php?mod=blog" onsubmit="if($('scform_srchtxt')) searchFocus($('scform_srchtxt'));">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<!--{subtemplate search/pubsearch}-->
			<!--{hook/blog_top}-->
		</form>
	</div>
	<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
	<div class="bp">
	<!--{subtemplate search/blog_list}-->
	</div>
	<!--{/if}-->

</div>
<!--{hook/blog_bottom}-->

<!--{subtemplate common/footer}-->
