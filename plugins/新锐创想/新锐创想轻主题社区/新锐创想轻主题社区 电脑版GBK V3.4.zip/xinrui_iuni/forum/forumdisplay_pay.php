<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<div id="pt" class="bm cl">
	<div class="z"><a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a> $navigation</div>
</div>

<div id="ct" class="wp cl">
	<div class="mn">
		<div class="nfl"  style="padding:80px 0;">
			<div class="xr_forum_pay bp">
				<h3>{lang youneedpay} $paycredits {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['unit']}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['title']} {lang onlyintoforum}</h3>
				<div class="o ptw mtw cl tc">
					<form method="post" autocomplete="off" action="forum.php?mod=forumdisplay&fid=$_G[fid]&action=paysubmit">
						<input type="hidden" name="formhash" value="{FORMHASH}" />
						<button type="submit" name="loginsubmit" value="true"><strong>{lang confirmyourpay}</strong></button>
						<button class="cancel" type="button" onclick="history.go(-1)"><strong>{lang cancel}</strong></button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<!--{template common/footer}-->

