<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<div id="pt" class="bm cl">
	<div class="z"><a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a> $navigation</div>
</div>

<div id="ct" class="wp cl">
	<div class="mn">
		<div class="nfl" style="padding:80px 0;">
			<div class="xr_passwd bp">
				<h3>{lang forum_password_require}</h3>
				<div class="o">
					<form method="post" autocomplete="off" action="forum.php?mod=forumdisplay&fid=$_G[fid]&action=pwverify">
						<input type="hidden" name="formhash" value="{FORMHASH}" />
						<input type="password" name="pw" class="pwd_txt" size="25" />
						<button type="submit" name="loginsubmit" value="true"><strong>{lang submit}</strong></button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<!--{template common/footer}-->

