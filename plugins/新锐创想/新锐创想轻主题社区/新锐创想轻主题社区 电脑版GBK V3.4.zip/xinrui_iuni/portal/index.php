<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>
<script src="template/xinrui_iuni/js/jquery.SuperSlide.js" type="text/javascript"></script>
<div class="wp cl">
<div class="bp cl">
	<div class="z" style="width:200px;">
		<div class="pg_colu"><!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]--></div>
	</div>
	<div class="y" style="width:955px;">
		<div class="cl">
			<div class="pSlide z"><!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]--></div>
			<div class="pImg y">
				<!--[diy=diy15]--><div id="diy15" class="area"></div><!--[/diy]-->
			</div>
		</div>
		<div class="txtRoll"><!--[diy=diy14]--><div id="diy14" class="area"></div><!--[/diy]--></div>
	</div>
</div>
<div class="col2 y">
	<div class="sdBtn bp">
		<a onclick="showWindow('nav', this.href, 'get', 0)" href="forum.php?mod=misc&amp;action=nav" class="post_btn">��������</a>
		<a href="plugin.php?id=dsu_paulsign:sign" target="_blank" class="signin">����ǩ��</a>
	</div>
	
	<div class="hotAct bp">
		<!--[diy=diy10]--><div id="diy10" class="area"></div><!--[/diy]-->
	</div>
	<div class="fans bp"><!--[diy=diy4]--><div id="diy4" class="area"></div><!--[/diy]--></div>
	<div class="hotTag bp">
		<div class="blocktitle title">���Ż���</div>
		<div class="tagMod cl">
		<!--{eval $xinruiTags = C::t(common_tag)->fetch_all_by_status();}-->
		<!--{eval $num = 1;}-->
		<!--{loop $xinruiTags $tag}-->
			<!--{if $num<=15 }-->
				<a href="misc.php?mod=tag&id=$tag[tagid]" target="_blank">$tag[tagname]</a>
			<!--{/if}-->
			<!--{eval $num++;}-->
		<!--{/loop}-->
		</div>
	</div>
	<div class="mbm"><!--[diy=diy6]--><div id="diy6" class="area"></div><!--[/diy]--></div>
	<div class="mbm"><!--[diy=diy7]--><div id="diy7" class="area"></div><!--[/diy]--></div>
</div>
<div class="col1 z">
	<div class="tFocus bp">
		<!--[diy=diy2]--><div id="diy2" class="area"></div><!--[/diy]-->
	</div>
	<div class="essEnce bp">
		<!--[diy=diy11]--><div id="diy11" class="area"></div><!--[/diy]-->
	</div>
	<div class="news_portal bp">
		<!--[diy=diy9]--><div id="diy9" class="area"></div><!--[/diy]-->
		<div class="jquery_pagnation"></div>
		<script type="text/javascript" src="template/xinrui_iuni/js/jquery.pagnation.js"></script> 
		<script type="text/javascript">
			(function(dfsj_jq){
			var dfsj_items = dfsj_jq('.newMod li');
			var dfsj_items2 = 10;
			var total = dfsj_items.size();
			total>0 && dfsj_jq('.jquery_pagnation').pagination({pagetotal:total,target:dfsj_items,perpage:dfsj_items2});
			})(jQuery);
		</script>
	</div>
</div>

</div>
<div class="cl wp bp xrLinks">
	<!--[diy=diy12]--><div id="diy12" class="area"></div><!--[/diy]-->
</div>
<div class="cl" style="margin-top:15px;">
	<!--[diy=diy13]--><div id="diy13" class="area"></div><!--[/diy]-->	
</div>
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->





