<?php echo 'From: DisM.taobao.com';exit;?>
<div class="tl">
	<div class="schTit">
		<!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}-->
	</div>
	<!--{ad/search/y mtw}-->
	<!--{if empty($articlelist)}-->
		<p class="schEmp">{lang search_nomatch}</p>
	<!--{else}-->
		<div class="schList mtw">
			<ul>
				<!--{loop $articlelist $article}-->
				<li class="cl">
					<div class="schAvt z">
						<a href="home.php?mod=space&uid=$thread[authorid]"><!--{avatar($thread[authorid],small)}--></a>
					</div>
					<div class="schCon z">
						<h3><a href="{echo fetch_article_url($article);}" target="_blank">$article[title]</a></h3>
						<p class="schIntr">$article[summary]</p>
						<p class="schInfo">
							<span class="schTimeIcon">$article[dateline]</span>
							<span class="schAuthorIcon"><a href="home.php?mod=space&uid=$article[uid]" target="_blank">$article[username]</a></span>
						</p>
					</div>
					<div class="schFt y">
						<p><span>$article[commentnum]</span> {lang a_comment}</p>
						<p><span>$article[viewnum]</span> {lang a_visit}</p>
					</div>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs bp cl mtw" style="box-shadow:none;">$multipage</div><!--{/if}-->
</div>