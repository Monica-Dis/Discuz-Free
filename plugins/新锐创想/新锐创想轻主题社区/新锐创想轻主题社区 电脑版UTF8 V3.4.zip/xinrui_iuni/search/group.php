<?php echo 'From: DisM.taobao.com';exit;?>
<!--{subtemplate common/header}-->
<div id="ct" class="w">
  <div class="bp schHd">
    <form class="searchform" method="post" autocomplete="off" action="search.php?mod=group" onsubmit="if($('scform_srchtxt')) searchFocus($('scform_srchtxt'));">
      <input type="hidden" name="formhash" value="{FORMHASH}" />
      <input type="hidden" name="srchfid" value="$srchfid" />
      <!--{subtemplate search/pubsearch}-->
      <!--{hook/group_top}-->
    </form>
  </div>

  <!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
  <div class="bp">
		<!--{if $srchfid}-->
			<!--{subtemplate search/thread_list}-->
		<!--{else}-->
			<!--{subtemplate search/group_list}-->
    <!--{/if}-->
  </div>
	<!--{/if}-->

</div>
<!--{hook/group_bottom}-->

<!--{subtemplate common/footer}-->