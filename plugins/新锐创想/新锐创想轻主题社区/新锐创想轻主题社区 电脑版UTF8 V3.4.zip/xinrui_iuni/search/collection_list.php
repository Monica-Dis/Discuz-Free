<?php echo 'From: DisM.taobao.com';exit;?>
<div class="tl">
	<div class="schTit">
		<h2><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></h2>
	</div>
	<!--{ad/search/y mtw}-->
	<!--{if empty($collectionlist)}-->
	<p class="schEmp">{lang search_nomatch}</p>
	<!--{else}-->
	<div class="schList mtw">
		<ul>
			<!--{loop $collectionlist $key $value}-->
			<li class="cl">
					<div class="schAvt z">
						<a href="home.php?mod=space&uid=$thread[authorid]"><!--{avatar($thread[authorid],small)}--></a>
					</div>
					<div class="schCon z">
						<h3><a href="forum.php?mod=collection&action=view&ctid=$value[ctid]" target="_blank">$value[name]</a></h3>
						<p class="schIntr">$value[desc]</p>
						<p class="schInfo"><span class="schTimeIcon">{lang lastupdate}: $value[lastupdate]</span></P>
					</div>
					<div class="schFt y tLine">
						<p><span>$value[threadnum]</span> {lang threads}</p>
						<p><span>$value[commentnum]</span> {lang comment}</p>
						<p><span>$value[follownum]</span> {lang subscribe}</p>
					</div>
			</li>
			<!--{/loop}-->
		</ul>
	</div>
		<!--{if !empty($multipage)}--><div class="pgs bp cl mtw" style="box-shadow:none;">$multipage</div><!--{/if}-->
	<!--{/if}-->
</div>
