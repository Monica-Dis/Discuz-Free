<?php echo 'From: DisM.taobao.com';exit;?>
<!--{subtemplate common/header}-->
<div id="ct" class="w">
	<div class="bp schHd">
	<form class="searchform" method="post" autocomplete="off" action="search.php?mod=album" onsubmit="if($('scform_srchtxt')) searchFocus($('scform_srchtxt'));">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{subtemplate search/pubsearch}-->
		<!--{hook/album_top}-->
	</form>
	</div>

	<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
	<div class="bp"><!--{subtemplate search/album_list}--></div>
	<!--{/if}-->
	
</div>
<!--{hook/album_bottom}-->
<!--{subtemplate common/footer}-->