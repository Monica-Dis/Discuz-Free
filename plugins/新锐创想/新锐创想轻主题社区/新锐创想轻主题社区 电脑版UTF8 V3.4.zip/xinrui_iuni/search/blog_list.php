<?php echo 'From: DisM.taobao.com';exit;?>
<div class="tl">
	<div class="schTit">
		<h2><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></h2>
	</div>
	<!--{ad/search/y mtw}-->
	<!--{if empty($bloglist)}-->
	<p class="schEmp">{lang search_nomatch}</p>
	<!--{else}-->
		<div class="schList mtw">
			<ul>
				<!--{loop $bloglist $blog}-->
				<li class="cl">
					<div class="schAvt z">
						<a href="home.php?mod=space&uid=$thread[authorid]"><!--{avatar($thread[authorid],small)}--></a>
					</div>
					<div class="schCon z">
						<h3><a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]"{if $blog[magiccolor]} class="magiccolor$blog[magiccolor]"{/if} target="_blank">$blog[subject]</a></h3>
						<p class="schIntr">$blog[message]</p>
						<p class="schInfo">
							<span class="schTimeIcon">$blog[dateline]</span>
							<span class="schAuthorIcon"><a href="home.php?mod=space&uid=$blog[uid]" target="_blank">$blog[username]</a></span>
						</p>
					</div>
					<div class="schFt y tLine">
						<p><span>$blog[replynum]</span> {lang a_comment}</p>
						<p><span>$blog[viewnum]</span> {lang a_visit}</p>
						<p><span>$blog[hot]</span> {lang heat}</p>
					</div>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs bp cl mtw" style="box-shadow:none;">$multipage</div><!--{/if}-->
</div>