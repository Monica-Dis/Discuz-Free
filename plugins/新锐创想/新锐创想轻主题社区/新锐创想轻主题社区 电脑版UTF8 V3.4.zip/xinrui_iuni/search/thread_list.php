<?php echo 'From: DisM.taobao.com';exit;?>
<div class="tl">
	<div class="schTit">
		<!--{if $keyword}-->{lang search_result_keyword} <!--{if $modfid}--><a href="forum.php?mod=modcp&action=thread&fid=$modfid&keywords=$modkeyword&submit=true&do=search&page=$page" target="_blank">{lang goto_memcp}</a><!--{/if}--><!--{else}-->{lang search_result}<!--{/if}-->
	</div>
	<!--{ad/search/y mtw}-->
	<!--{if empty($threadlist)}-->
		<p class="schEmp">{lang search_nomatch}</p>
	<!--{else}-->
		<div class="schList mtw" id="threadlist" {if $modfid} style="position: relative;"{/if}>
			<!--{if $modfid}-->
			<form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$modfid&infloat=yes&nopost=yes">
			<!--{/if}-->
			<ul>
				<!--{loop $threadlist $thread}-->
				<li class="cl" id="$thread[tid]">
					<div class="schAvt z">
						<a href="home.php?mod=space&uid=$thread[authorid]"><!--{avatar($thread[authorid],small)}--></a>
					</div>
					<div class="schCon z">
						<h3>
							<!--{if $modfid}-->
								<!--{if $thread['fid'] == $modfid && ($thread['displayorder'] <= 3 || $_G['adminid'] == 1)}-->
									<input onclick="tmodclick(this)" type="checkbox" name="moderate[]" value="$thread[tid]" />&nbsp;
								<!--{else}-->
									<input type="checkbox" disabled="disabled" />&nbsp;
								<!--{/if}-->
							<!--{/if}-->
							<a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank" $thread[highlight]>$thread[subject]</a>
						</h3>						
						<p class="schIntr"><!--{if !$thread['price'] && !$thread['readperm']}-->$thread[message]<!--{else}-->{lang thread_list_message1}<!--{/if}--></p>
						<p class="schInfo">
							<span class="schForumIcon"><a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank" class="xi1">$thread[forumname]</a></span>
							<span class="schTimeIcon">$thread[dateline]</span>
							<span class="schAuthorIcon">
								<!--{if $thread['authorid'] && $thread['author']}-->
									<a href="home.php?mod=space&uid=$thread[authorid]" target="_blank">$thread[author]</a>
								<!--{else}-->
									<!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&uid=$thread[authorid]" target="_blank">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
								<!--{/if}-->
							</span>
						</p>
					</div>
					<div class="schFt y">
						<p><span>$thread[replies]</span> {lang a_comment_thread}</p>
						<p><span>$thread[views]</span> {lang a_visit}</p>
					</div>
				</li>
				<!--{/loop}-->
			</ul>
		<!--{if $modfid}-->
			</form>
			<script type="text/javascript" src="{$_G[setting][jspath]}forum_moderate.js?{VERHASH}"></script>
			<!--{template forum/topicadmin_modlayer}-->
		<!--{/if}-->
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs bp cl mtw" style="box-shadow:none;">$multipage</div><!--{/if}-->
</div>