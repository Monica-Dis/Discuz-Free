<?php
/**
 *	Powered by Easexun Inc.
 *	Version: 2.20190713
 *	Identifier:minbbs_appdown
 *  Email:minbbs@qq.com
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo dfsockopen('https://www.yixunyun.cc/geturl.php?url='.urlencode($_G['siteurl']).'&pluginname='.$plugin['identifier']);

exit();
?>