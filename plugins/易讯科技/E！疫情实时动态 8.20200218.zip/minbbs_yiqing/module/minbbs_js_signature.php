<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function createNoncestr($length = 16) {
	$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	$str = "";
	for($i = 0; $i < $length; $i ++) {
		$str .= substr ( $chars, mt_rand ( 0, strlen ( $chars ) - 1 ), 1 );
	}
	return $str;
}
if (submitcheck('signaturesubmit')) {
	$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? 'https://' : 'http://';
	$pre_url = $protocol . $_SERVER['HTTP_HOST'];
	if (strpos($_GET['url'], $pre_url) !== 0) {
		showmessage('quickclear_noperm');
	}
	$url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$AppId.'&secret='.$AppSecret;
	$result = json_decode(httpGet($url), true);
	$access_token = $result['access_token'];
	$urls = 'https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token='.$access_token.'&type=jsapi';
	$results = json_decode(httpGet($urls), true);
	$ticket = $results['ticket'];
	$str="ABCDEFGHIJKLMNOPQRSTUVWSYZabcdefghijklmnopqrstuvwsyz";
	str_shuffle($str);
	$nonceStr = createNoncestr();
	$time = time();
	$string = "jsapi_ticket=".$ticket."&noncestr=".$nonceStr."&timestamp=".$time."&url=".$_GET['url'];
	$signature = sha1($string);
	echo json_encode(array('jsapi_ticket' => $ticket, 'noncestr' => $nonceStr ,'timestamp' => $time, 'signature' => $signature));
} else {
	//showmessage('submit_invalid');
}
//From: dis'.'m.tao'.'bao.com
?>