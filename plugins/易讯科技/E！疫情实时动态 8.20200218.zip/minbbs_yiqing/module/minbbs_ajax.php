<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_GET['formhash'] == FORMHASH){
	$url = 'https://mat1.gtimg.com/news/feiyanarea/'.$_GET['area'];
	$json = httpGet($url);
	if(CHARSET == 'gbk'){
		$json = mb_convert_encoding($json, 'gbk','utf-8');
	}
	echo $json;
}
//From: dis'.'m.tao'.'bao.com
?>