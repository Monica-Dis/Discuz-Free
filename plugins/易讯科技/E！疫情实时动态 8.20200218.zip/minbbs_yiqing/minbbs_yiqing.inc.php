<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache('plugin');
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
$minbbs = $_G['cache']['plugin']['minbbs_yiqing'];
$AppId = $minbbs['AppId'];
$AppSecret = $minbbs['AppSecret'];
$Total = $minbbs['Total'];
$Share_imgurl = $minbbs['Share_imgurl'];
$Share_title = $minbbs['Share_title'];
$Share_desc = $minbbs['Share_desc'];

$mod = trim($_GET['mod']);
$mod = in_array($mod, array('index', 'ajax', 'qrcode', 'js_signature')) ? $mod : "index";
function httpGet($url) {
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_TIMEOUT, 500);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($curl, CURLOPT_URL, $url);

	$res = curl_exec($curl);
	curl_close($curl);

	return $res;
}
require_once libfile("minbbs_" . $mod, 'plugin/minbbs_yiqing/module');
?>