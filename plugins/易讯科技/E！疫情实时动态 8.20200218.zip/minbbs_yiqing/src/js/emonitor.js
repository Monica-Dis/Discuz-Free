var isTimingReported = false;
var _MAXTIMEOUT = 10000;
var nativeToString = Object.prototype.toString;
var bossInfo = {
  page: '//btrace.qq.com/kvcollect?BossId=6529&Pwd=1714580587', //页面质量上报
  error: '//btrace.qq.com/kvcollect?BossId=6527&Pwd=1102151080', // 页面错误上报
  slowlog: '//btrace.qq.com/kvcollect?BossId=6523&Pwd=1202531240', //慢日志上报
  cgi: '//btrace.qq.com/kvcollect?BossId=6528&Pwd=96045012', // cgi上报
  resource: '//btrace.qq.com/kvcollect?BossId=6958&Pwd=1123576360', // 素材质量上报
  flowlog: '//btrace.qq.com/kvcollect?BossId=6526&Pwd=878966364' // 流水日志上报
};
var emonitorIns = emonitor.create({
  baseUrl: bossInfo.error,
  name: 'feiyan',
  ptag: bbo.getUrlParam('ADTAG') || '',
  onBeforeSend: function(data) {
    // 在数据上报前调用 可以用作数据过滤，
    // (1)仅有return false 不上报数据；(2)当返回object对象，支持修改's_path', 's_traceid', 's_guid', 'hc_pgv_pvid', 's_omgid','err_desc';
    // data.type 上报类型 console，link，script，ajax，fetch，promise，img，audio，video，cgi
    // data.url 请求链接
    // data.code 请求状态，默认为空
    // data.isErr 是否是异常上报
    // data.source 上报的原始数据
    // 应用场景: 日志管理, 白名单等
    // console.log('report data::::', data);
    // 简单的全日志存储方案
    // 通过返回对象，修改特定上报字段。生产环境，按需使用!。
    // return { s_path: '/test', s_traceid: '1111'}
    // return { err_desc: 'test'};
  },
  // debug: true, 开发环境开启debug=true，window.onerror捕获的错误会展示在控制台
  cgi: {
    baseUrl: bossInfo.cgi,
    sampling: 0.01, // 默认采样率 可根据实际情况调整
    code: 'ret',
    msg: ['info'],
    jsonp: function(dom) {
      return true;
    }
  },
  logs: {
    baseUrl: bossInfo.flowlog
  }
});
setTimeout(function() {
  // 慢日志上报
  if (!isTimingReported) {
    var _resources = emonitor.getRcTiming();
    try {
      if (nativeToString.call(_resources) === '[object Array]') {
        var _resourcesLen = _resources.length;
        var _jsonEntries = [];
        for (var _i = 0; _i < _resourcesLen; _i++) {
          _jsonEntries.push(
            _resources[_i].starttime + '|' + _resources[_i].duration + '|' + _resources[_i].name
          );
        }
        emonitorIns
          .config({
            baseUrl: bossInfo.slowlog
          })
          .send(
            {
              json_entries: JSON.stringify(_jsonEntries)
            },
            true
          );
        emonitorIns.config({
          baseUrl: bossInfo.error
        });
      }
    } catch (err) {
      console.warn('emonitorIns send', err);
    }
  }
}, _MAXTIMEOUT);
window.addEventListener(
  'load',
  function() {
    setTimeout(function() {
      if (!isTimingReported) {
        emonitorIns
          .config({
            baseUrl: bossInfo.page
          })
          .send(emonitor.getPfTiming());
        emonitorIns.config({
          baseUrl: bossInfo.error
        });
        isTimingReported = true;
      }
    }, 0);
  },
  false
);
