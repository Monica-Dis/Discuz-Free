"use strict";

function _typeof(obj) {
  "@babel/helpers - typeof";
  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }
  return _typeof(obj);
}

function _instanceof(left, right) {
  if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) {
    return !!right[Symbol.hasInstance](left);
  } else {
    return left instanceof right;
  }
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }
  return _assertThisInitialized(self);
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return self;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };
  return _setPrototypeOf(o, p);
}

function _classCallCheck(instance, Constructor) {
  if (!_instanceof(instance, Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

! function (A) {
  var g = {};

  function Q(B) {
    if (g[B]) return g[B].exports;
    var I = g[B] = {
      i: B,
      l: !1,
      exports: {}
    };
    return A[B].call(I.exports, I, I.exports, Q), I.l = !0, I.exports;
  }

  Q.m = A, Q.c = g, Q.d = function (A, g, B) {
    Q.o(A, g) || Object.defineProperty(A, g, {
      configurable: !1,
      enumerable: !0,
      get: B
    });
  }, Q.n = function (A) {
    var g = A && A.__esModule ? function () {
      return A["default"];
    } : function () {
      return A;
    };
    return Q.d(g, "a", g), g;
  }, Q.o = function (A, g) {
    return Object.prototype.hasOwnProperty.call(A, g);
  }, Q.p = "https://mat1.gtimg.com/yslp/yyh5/mapview/", Q(Q.s = 2);
}([function (A, g, Q) {
  "use strict";

  g.a =
    /*#__PURE__*/
    function () {
      function _class() {
        _classCallCheck(this, _class);

        var A,
          g = this.lib = {},
          Q = {};
        Q.map2_atlas_ = new createjs.SpriteSheet({
          images: [imagePool.map2_atlas_],
          frames: [
            [492, 505, 437, 340],
            [297, 1484, 102, 130],
            [977, 376, 37, 42],
            [907, 1520, 103, 103],
            [909, 993, 97, 120],
            [0, 883, 312, 278],
            [832, 1257, 173, 132],
            [233, 1358, 172, 124],
            [0, 1490, 132, 115],
            [937, 465, 59, 49],
            [407, 1358, 118, 173],
            [314, 1124, 240, 232],
            [878, 1391, 127, 127],
            [0, 1382, 166, 106],
            [755, 1391, 121, 138],
            [401, 1533, 121, 107],
            [909, 847, 106, 144],
            [832, 1124, 178, 131],
            [168, 1484, 127, 126],
            [0, 472, 490, 409],
            [937, 269, 66, 105],
            [556, 1124, 274, 201],
            [755, 1531, 150, 99],
            [977, 420, 22, 20],
            [937, 0, 80, 165],
            [314, 883, 118, 203],
            [0, 1163, 231, 217],
            [937, 376, 38, 87],
            [931, 516, 25, 44],
            [492, 847, 415, 275],
            [556, 1327, 197, 208],
            [937, 167, 85, 100],
            [0, 0, 600, 470],
            [602, 0, 333, 503]
          ]
        }), (g.CachedTexturedBitmap_755 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(0);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_759 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(1);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_760 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(2);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_761 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(3);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_762 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(4);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_763 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(5);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_764 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(6);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_765 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(7);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_766 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(8);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_767 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(9);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_768 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(10);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_769 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(11);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_770 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(12);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_771 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(13);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_772 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(14);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_773 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(15);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_774 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(16);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_775 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(17);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_776 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(18);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_779 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(19);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_780 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(20);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_781 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(21);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_782 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(22);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_783 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(23);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_784 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(24);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_785 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(25);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_786 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(26);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_798 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(27);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_799 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(28);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_800 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(29);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_801 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(30);
        }).prototype = A = new cjs.Sprite(), (g.CachedTexturedBitmap_802 = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(31);
        }).prototype = A = new cjs.Sprite(), (g.mapline = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(32);
        }).prototype = A = new cjs.Sprite(), (g.small = function () {
          this.initialize(Q.map2_atlas_), this.gotoAndStop(33);
        }).prototype = A = new cjs.Sprite(), (g.small_1 = function (A, Q, B) {
          this.initialize(A, Q, B, {}), this.instance = new g.small(), this.instance.parent = this, this.instance.setTransform(-45, -68, .2702, .2703), this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
        }).prototype = getMCSymbolPrototype(g.small_1, new cjs.Rectangle(-45, -68, 90, 136), null), (g.linesmc = function (A, Q, B) {
          this.initialize(A, Q, B, {}), this.instance = new g.mapline(), this.instance.parent = this, this.instance.setTransform(-274, -227), this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
        }).prototype = getMCSymbolPrototype(g.linesmc, new cjs.Rectangle(-274, -227, 600, 470), null);
      }

      return _class;
    }();
}, function (A, g, Q) {
  "use strict";

  g.a =
    /*#__PURE__*/
    function () {
      function _class2() {
        _classCallCheck(this, _class2);

        var A = navigator.userAgent.toLowerCase();
        return {
          ipad: /ipad/.test(A),
          iphone: /iphone/.test(A),
          android: /android/.test(A),
          qqnews: /qqnews/.test(A),
          weixin: /micromessenger/.test(A),
          qqnews_version: "qqnews" == A.match(/qqnews/i) ? A.split("qqnews/")[1] : ""
        };
      }

      return _class2;
    }();
}, function (A, g, Q) {
  "use strict";

  Object.defineProperty(g, "__esModule", {
    value: !0
  });
  Q(3), Q(17);
}, function (A, g, Q) {
  "use strict";

  var B = Q(4),
    I = Q(5),
    C = Q(6),
    D = Q(13),
    E = Q.n(D),
    F = (Q(14), Q(15)),
    t = Q(16),
    G = Q(1);

  window.Main =
    /*#__PURE__*/
    function (_createjs$MovieClip) {
      _inherits(_class3, _createjs$MovieClip);

      function _class3(A) {
        var _this;

        _classCallCheck(this, _class3);

        _this = _possibleConstructorReturn(this, _getPrototypeOf(_class3).call(this));
        var g = A.data;
        window.mc_symbol_clone = function () {
          var A = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));

          return A.gotoAndStop(this.currentFrame), A.paused = this.paused, A.framerate = this.framerate, A;
        }, window.getMCSymbolPrototype = function (A, g, Q) {
          var B = cjs.extend(A, cjs.MovieClip);
          return B.clone = mc_symbol_clone, B.nominalBounds = g, B.frameBounds = Q, B;
        }, window.imagePool = {}, window.cjs = createjs, window.main = _assertThisInitialized(_this), window.proData = E.a, _this.drawOver = A.drawOver, _this.defaultArea = A.defaultArea, E.a.path = g.path, window.imagePool = {}, window.lib = {}, window.userData = {}, window.ownerData = {}, window.gameData = {}, window.provData = g.mapList, window.provColors = g.colors, userData.select = 1;
        var Q = new G.a();
        gameData.offY = 0, Q.android && (gameData.offY = 2), Q.iphone && (gameData.offY = 2);
        var D = new t.a();
        window.trace = D.log, D.hide(), trace("version 3333"), _this.emitEvent = function (g) {
          A.shareCall(g);
        }, _this.gotoProvPage = function (g) {
          A.gotoProvPage(g);
        }, _this.selectProv = function (A) {
          _this.outCall = A;
        }, new F.a({
          ary: E.a.coverPsd,
          path: E.a.path + "source/plugin/minbbs_yiqing/src/img/",
          call: function call() {
            var A = g.div,
              Q = new I.a({
                w: A.width,
                h: A.height
              });
            Q.divID = A.id, Q.backgroundColor = "#FFFFFF";
            var D = window.stage = new B.a(Q);
            cjs.Ticker.framerate = 30, D.canRender = 20;
            var E = 0;
            cjs.Ticker.addEventListener("tick", function () {
              ++E % D.canRender != 0 && 1 != E || D.update();
            });
            var F = main.handler = new C.a();
            D.addChild(F), main.changeData = F.setColors, main.changeData(provData, "累计确诊"), main.clean = function () {
              F.clean(), tips.hide();
            }, main.selectProv = function (A) {
              F.selectProv(A);
            }, window.minSca = Math.min(D.width / 750, D.height / 1470), window.maxSca = Math.max(D.width / 750, D.height / 1470);
          }
        });
        return _this;
      }

      return _class3;
    }(createjs.MovieClip);
}, function (A, g, Q) {
  "use strict";

  g.a =
    /*#__PURE__*/
    function () {
      function _class4(A) {
        _classCallCheck(this, _class4);

        var g = document.getElementById(A.divID),
          Q = window.canvas = document.createElement("canvas");
        Q.width = A.canvasW, Q.height = A.canvasH, Q.style.width = g.style.width = A.domW + "px", Q.style.height = g.style.height = A.domH + "px", Q.style.position = "absolute", Q.style.top = "0", Q.style.left = "0", g.style.backgroundColor = A.backgroundColor, Q.style.backgroundColor = A.backgroundColor, g.style.position = "absolute", g.style.top = "0", g.style.left = "0", g.appendChild(Q);
        var B = new createjs.Stage(Q);
        return B.width = A.screen.width, B.height = A.screen.height, B.scaleX = B.scaleY = A.stageScale, B.pRatio = A.pRatio, B.enableMouseOver(30), B.mouseEnabled = !0, B.div = g, B.resize = function () {
          A.resize(), Q.width = A.canvasW, Q.height = A.canvasH, Q.style.width = g.style.width = A.domW + "px", Q.style.height = g.style.height = A.domH + "px", B.width = A.screen.width, B.height = A.screen.height, B.scaleX = B.scaleY = A.stageScale, B.pRatio = A.pRatio;
        }, B;
      }

      return _class4;
    }();
}, function (A, g, Q) {
  "use strict";

  g.a =
    /*#__PURE__*/
    function () {
      function _class5(A) {
        _classCallCheck(this, _class5);

        var g,
          Q,
          B,
          I = {
            screen: {}
          },
          C = A.w,
          D = A.h;
        var E = C / 2,
          F = D / 2;
        var t = E / C,
          G = F / D,
          e = 1,
          i = window.devicePixelRatio || 1;
        return i = Math.min(i, 2), g = E, Q = F, B = e = Math.min(t, G), I.resize = function () {
          I.screen.ow = C, I.screen.oh = D, I.screen.width = C, I.screen.height = D, I.scale = t * i, I.xRatio = t, I.pRatio = i, I.canvasW = C * i * e, I.canvasH = D * i * e, I.domW = C * e, I.domH = D * e, I.stageScale = i * e;
        }, I.resize(), I;
      }

      return _class5;
    }();
}, function (A, g, Q) {
  "use strict";

  Q(7), Q(0);
  var B = Q(8),
    I = Q(9),
    C = Q(11),
    D = Q(12);

  g.a =
    /*#__PURE__*/
    function (_createjs$MovieClip2) {
      _inherits(_class6, _createjs$MovieClip2);

      function _class6() {
        var _this2;

        _classCallCheck(this, _class6);

        _this2 = _possibleConstructorReturn(this, _getPrototypeOf(_class6).call(this));
        var A = new cjs.Shape();
        A.graphics.f("rgba(255,255,255,0.01)").dr(0, 0, stage.width, stage.height), _this2.addChild(A), A.addEventListener("mousedown", function (A) {
          H(), tips && tips.hide();
        });
        var g = new cjs.MovieClip(),
          Q = new cjs.MovieClip(),
          E = new cjs.MovieClip();

        _this2.addChild(g, E, Q);

        var F = new new B.a().lib.map2(),
          t = new cjs.Shape();
        t.graphics.f("rgba(255,0,0,0.01)").dc(0, 0, 15), t.change = function () {}, F.addChild(t), F.pool["澳门"] = t, t.setTransform(370, 410);
        var G = new cjs.Shape();
        G.graphics.f("rgba(255,0,0,0.01)").dc(0, 0, 15), G.change = function () {}, F.addChild(G), F.pool["香港"] = G, G.setTransform(400, 400), F.width = 600, F.height = 470, F.regX = 300, F.regY = 235, F.x = stage.width / 2 + 20, F.y = stage.height / 2;
        var e = _this2.sca = stage.width / 600;
        F.scaleX = F.scaleY = e;
        var i = new C.a();
        i.x = 20, i.y = stage.height - i.height - 20;
        var s = [];
        _this2.last = null, _this2.clean = function () {
          H(), stage.update();
        };

        var H = _this2.resetAll = function () {
          _this2.last && (_this2.last.txt.darkColor && (_this2.last.txt.color = _this2.last.txt.darkColor), _this2.last.change(_this2.last.defaultColor));
        };

        var n, a;
        (function () {
          new D.a(_assertThisInitialized(_this2), F);
        })(), _this2.clean = function () {
          H();
        }, g.addChild(F), window.tips = new I.a(), Q.addChild(tips), tips.scaleX = tips.scaleY = 1.18, _this2.selectProv = function (A) {
          main.defaultArea = A, tips.show(F.pool[A].data), tips.x = F.pool[A].x * _this2.sca, tips.y = F.pool[A].y * _this2.sca, n = F.pool[A].x * _this2.sca, a = F.pool[A].y * _this2.sca, console.log(n, a), F.pool[A].change("#FFE766"), _this2.last = F.pool[A], _this2.last.txt.color = "#000000", stage.update();
        };
        var h,
          J,
          o = "";
        _this2.setColors = function (A, g) {
          proData.subStr = g, s = [];

          for (var _g in A) {
            if (A[_g].area && "" != A[_g].area && void 0 != A[_g].area && (h = A[_g], o = h.color, J = F.pool[h.area], h.value >= 1e3 ? (J.txt.darkColor = "#ffffff", J.txt.color = J.txt.darkColor) : (J.txt.darkColor = "#000000", J.txt.color = J.txt.darkColor), void 0 == J || "undefined" == J || (s.push(J), J.data = h, J.defaultColor = o, J.change(o)), h.area == main.defaultArea)) {
              if (!F.pool[main.defaultArea].data) return;
              tips.show(F.pool[main.defaultArea].data), tips.x = F.pool[main.defaultArea].x * _this2.sca, tips.y = F.pool[main.defaultArea].y * _this2.sca, F.pool[main.defaultArea].change("#FFE766"), _this2.last = F.pool[main.defaultArea], _this2.last.txt.color = "#000000", stage.update();
            }
          }
        }, setTimeout(function () {
          main.drawOver();
        }, 100);
        return _this2;
      }

      return _class6;
    }(createjs.MovieClip);
}, function (A, g, Q) {
  "use strict";
}, function (A, g, Q) {
  "use strict";

  var B = Q(0);

  g.a =
    /*#__PURE__*/
    function () {
      function _class7() {
        _classCallCheck(this, _class7);

        var A,
          g = this.lib = {};
        g.ssMetadata = [], (g.zhejiang = function (A, g, Q) {
          var _this3 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this3.shape.graphics.f(A).s().p("ABCD4IgDgGQgBgHgEgDQgBgBgEACQgEACgDAAQgGgCgLADIgZAIQgPAGgFgXQgCgIgIgNQgJgOgDAKIgDAOQgBAFgIACQgDABgEAFIgFAGQgFAFgKgGQgFgDgJACIgMACQgBAAgBAAQAAAAgBAAQgBgBAAAAQAAAAAAgBIABgGQAAgLgDgMQgEgRgJgJQgIgHACgJQADgIAAgFQACgIgBgEQgBgGgLAAIgOADQgCgDgDAEIgBABIgOAAIAAAAQAHgHABgLQABgJgEgFIgDgHQAAgRgIgKQgDgEgYgUQgNgTAIgUIAKgOIgGABIgCgBIACgCIAbgQQAQgJAOgeQAJgQABgGQAEgMgFgMQABgDAAgGIgBgJIAEgFIALADIASgDQAMgCABgGIABgHQABgGADgEQgSAFADgTQACgDAMgBQAIgBABgOQAEgIACgPIAAgBQACgEAAgGIAAgLQACgIAKgBIAJgCIALgBQAGACABAHQAAAFAGAGQAEADANAFQAGABAJgDIAEAEIAFACQADABADAEQADAFACgBIAIgJQAGgFACgEIAEgIQACgFAHAAIAJABQAEAAADAEIAGAKQADAEAEABIAGADIAMAGIAFADQgDABgGAFQgCACAAADQgBAEgGABQgGABgDAFQgDADAAAIQABAIgDACIgHAFQgIAFgEgDIgEgDIgGgCQgFAAgGABQgHACgDACQgEAGgDADQgGAFgDACIgGACIACABQADAAAEgCQAIgCACgFQAFgIAFAAIAIACQAFABAAAEQgBAKABABQADADgBAEQAAABAAAAQAAABAAAAQAAABAAAAQABAAAAABIADAAIABgFIACABQAEAEAFgDQAIgEADAAQAFAAACgEIACgFQACgDACgBIAJgHQADgDAGgCQAFgCAEABQAEAAAIADQAHADACACIAIAJQAHALAGAEQAJAFAJACIAMAEIAEgDQAEgDACADQAEAFADgBIAGgCQABAAAAAAQAAAAABAAQAAABAAAAQABABAAAAQABAFgEAAIgGADQgDACgFACQgDABgDAEQgEADAAACQAAABAAABQABABgBAAQAAABAAAAQAAAAAAABIgDADQgDACgCAGQgCAGgFABIgIAFQgFADgDgBQgEAAgCABQgCABgBAEIgBAGQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAgBABAAQAEgIACABQABABABAAQAAAAABAAQAAAAABAAQAAAAABAAIAFgEIAKgFQAEgCADgHQADgFAFgBIAIAAQAAAAABAAQAAAAABAAQAAABABAAQABAAAAABQABAAAAAAQABABAAAAQAAAAgBABQAAAAgBABIgDAEQgBABgBAAQAAABAAAAQAAABAAABQAAAAABABIAEAGQAAAAABABQAAAAAAABQAAAAAAABQgBAAAAABIgFADIgBACQAAAAAAABQAAAAAAABQABAAAAAAQAAABABAAQACABAEAFQAEAFgBACQgBAGgEADQgLAGAAgGIAAgKQAAgHgCABQgCAAgCgEQgBgGgBAIQgBAHACACIABAGQABAEgEABIgEACQgHAFgCgGIgDgIQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAgBAAIgBABIgDAEQgCADAAADQAAAFgCABIgGAAQAAAAAAAAQgBABAAAAQABABAAAAQAAABABABQACAEABAAIAFgBIAEgCQAHAAABADIAFAFQABABABABQABAAAAAAQAAABAAAAQAAAAgBAAIgCACQAAAAAAAAQAAABAAAAQABAAAAABQAAAAABAAQAEACgBAEQgCAEgEgCIgGgBQAAAAgBAAQgBAAAAAAQgBAAAAgBQgBAAAAgBIgCgBQgFACADADQACADAFgBQAGgBAAAEQAAAAABABQAAAAAAABQABAAAAAAQABABAAAAQABAAAAAAQABAAAAABQAAAAAAABQABAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAAAgBABIgDABIAAADIgBAEIgCABQgBAAgBABQAAAAgBAAQAAAAgBABQAAAAAAAAQgCADgFAAIgEABQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAABIACACQAEACACAFIAEAHQABAFADgDQADgCACACQABAAAAAAQAAABgBAAQAAABgBAAQAAABgBAAQgDACAAAEIACAGIACAGQABABAAABQAAABABAAQAAAAABAAQABAAAAAAQAEgBgBADIgBAFIgBAFQAAAAgBABQAAAAAAAAQgBAAAAAAQAAAAgBAAIgBgDIgBgFQAAAAAAAAQgBgBAAAAQgBAAAAAAQgBAAgBAAIgHgBQgDAAgBAEIAAAFQAAAAAAABQAAABgBAAQAAABAAAAQgBABAAAAQgEAEACADQADACgDADIgCACQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAAAgBgBIgEgDQAAAAgBAAQAAgBgBAAQAAAAAAABQgBAAAAAAQgEAEAEACQABABAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAAAAAABQgBAAAAAAIgEABQgBAAAAABQgBAAAAAAQgBAAAAABQAAAAgBAAQgEAGAAgGIgCgKIAGgGQAAgBAAAAQABgBAAAAQABAAAAAAQABAAABAAQAAAAABAAQABAAAAgBQABAAAAAAQAAAAABgBQAAAAAAAAQABgBgBAAQAAgBAAAAQAAAAgBgBIgDgGQgCgFABgBQAEgBgFgCIgEgDQgBgBgCAFIgDAGQAAAAAAABQAAAAgBAAQAAAAgBAAQgBAAgBAAIgGgBIgBACQAAAAAAAAQAAABAAAAQABAAAAABQABAAAAAAQAIACAAAEQAAADgDAFQgCADgDAAIgDAEIgBAFQACAFgCAEQgDAFgDgBQgGgCgCABQgGACgEgCIgHgCQgFAAAFACIAEAEQADADACAAQAJABAAAEQABAFgFAEQgGAHAAADIgCAEQAAAAAAABQgBAAAAABQgBAAAAAAQAAAAgBAAQgGgEgCACIAGAGIAAADQAAABAAAAQgBABAAABQAAAAAAABQAAAAAAABQACAEgGABQgIABAEADQADABABAEQAAADAEABIADAAQADgCAAAEQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAABQgCACABAEQABAGgFgCIgEgCQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAIgBAFQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABAAABABQAAAAAAABQAAAAAAABQAAABAAAAIgCAGQAAAHgCACIgBAAIgIgBg");
          }, this.shape.setTransform(.017, .025), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.zhejiang, new cjs.Rectangle(-21.2, -24.8, 42.4, 49.7), null), (g.yunnan = function (A, g, Q) {
          var _this4 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this4.shape.graphics.f(A).s().p("AgzIDIgIgFIgGgDQgEgCgDABIgKABQgIAEgDgBQgDAAgCgFQgDgEACgBQAEgFgCgCQgHgDgBgCQgDgHADgBQAFgBAAgDIgCgDQAAgBAAAAQAAgBABAAQAAgBAAAAQAAgBABAAQAAgBABgBQAAAAAAgBQABAAAAgBQAAAAgBAAIgCgDIgEAAIABgEIACgIQAAgFgEgFIAAgBQgDgCgEABIgCABIgLAEQgEACgFgBIgFAAIgDAFIgLAKIgDACQgJAHgCAAIgJABIgGgBQgEgCgBgCIgDgGQgCgDgEABQgJAAgCADIgDAEQAAAAAAABQgBAAAAAAQAAgBgBAAQAAAAgBgBQgCgEgGABQgHAAAAgGQAAgEAFgFQAEgEgCgDIgDgCQgDgBgDAEQgDAEgEgDQgCgBAAgEQAAgEgDgDQgEgDAAgGQAAgGACgCIAFgIQAEgLgJgDQgEgCgBADQgBADgHgGQgFgEgCACQgCACgCAAQgFgFgEgCIgNgEQgCgBgFAAIgJABQgJAAgJgDIgHgDQgFgDAFgFQACgDAGgDQAGgEABgMQABgFADgDIAHgEQADgCABgEIABgHIgDgIQgDgDAAgDQAAgEAFgDIAIgGIADgFQACgEAAgDQgBgFAGAFQAGAFAAgFIgBgIIAAgKQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAgBgBAAIgHgBQgGAAgBgDQgDgDgFADQgCACgFgBIgDgBQgDgCgFAAIgHAAQgFgCABgGQABgEgHABQgHACgEgFQgBgCAEgFQAIgIgHgCQgFAAAEgGQAFgHgJgIQgEgDAAgBQAAgCAFgDQADgCgEgFIgCgNIAAgDQAAgFgIABQgKACAEgKQACgFgBgHQAAgBAAgBQAAAAAAgBQAAAAAAgBQABAAAAAAQACgCAGgBQAEAAACgCIAIgEQABgBABAAQAAAAAAAAQABgBAAAAQAAAAAAgBIAAgEIgBgEIgCABIgDADIgDAAIgKACQgKACgEgEIAAAAIgDgCIgDgCQgEgCgCAAIgLACQgGABgFgDIgIgBIgGAAQgEAAgCACQgFADgDgBIgLABQgIAAgMAIIgKAGQgIAEgDgCIgGgGQgDgDAIgGQAFgEAAgBQABgCAJgGQAFgEABgDQgBgGABgFQABgBAAAAQgBgBAAAAQAAgBAAAAQgBAAgBAAIgDgBIgCgCQgDgEAEgBQAEgBgBgEIgEgHQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAABgBAAQAAAAgBgBQgBAAAAAAIgGgDIABgHIADgIIADgPQABgGAEgCQAGgDABgDQACgDAHACQAGACgBgEQgBgEgBgCIgCgDIgBgDQgBgBADgHQABgCAAgEQAAgDADgBQADgBACgEIACgGIAEgGQABgCAFADQAEADACAAQADAAAEgHIADgDIAEgCQACgBACgEQACgFADgBQAEgCgBgGIgBgDIACgEIAEgJQgBgEAGAEIAIAFQAHAJAFgNQACgDADgDIAFgGIADgHQADgHAGABQAFABAAADQAHAEAEgJQACgEgCgCQgGgFgBgEIgDgLIgBgGQgEgIAKACQAEABABADQABAFADgCQAEgEgBgGIgEgHQgBgDAEgFIAHgMQADgGgBgHIABgHQADgIgBgGQgBgEABgEQACgIgCgEIABgHIABgIIACgFQADgEgFgFQgCgCgBgEIAAgEIADgIIADgJIgCgQIAAgIQgBgFABgDQACgFgCgCQgCgCgDACQgDABgCgEQgBgDgEgCIgGgCQgBgBAAAAQgBAAgBAAQAAAAAAABQgBAAAAABIgBAHQAAAEgDACQgDADgFgCQgEgBgBgEIgBgGIgBgJIgCgFIgBgJQAAgGgCgDQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAIAAgGIgCgEIgDgEQgBgCAAgEIABgDIACgCQACgEAAgEIAHgHQAEgBAAgFIAAgGQAAgIAHAAQAFABACAZQABAMADgBIAGgEQAEgBAOgBQAIgDABgIQACgJgEgNIgCgFQgBgDAAgJIAGgqQABgEACgCIACAAIAJgCQAGAAAAAOIABAIQABADAEAAQADgBAAgGIABgLQABgFACgBIAGgCQAEAAgBgHIgCgMQgBgEAEgCQACgCADABQAGABABgBIABAAQABACgBAFIgCAYQgBAIgDAKQgBAHADAsQABAHAGAGQACACACAGQACAIACACQABABAAAAQABABAAAAQABAAAAAAQAAAAAAgBIACgGQAEgHgBgVQAAgHADgCIAJgCQAFgCACgFQACgIAFgFQAGgHAEgBQABAAABAAQAAAAABABQAAAAAAABQAAAAAAABQAAAKAGAFQAEACAIANQAHAKAFAAQAFgBACAEIAEAJIAEANQADAIgTALQgFADADAIQADAHAGAFQADADADAHQACAFADAAQAIACgEAKQgCAEAGAAQAFgBADgFQAEgJAIAFQAEADACgBQADAAACgFQADgEAFADQAFADgCADQgCACACADQADAEAAADQAAADAFAFQAEAFAAADQAAAEAFAMIAHAQQACACACAIIACAMQACAHAFgCQAJgFgGAPQgDAIAEAHIAGAIIAKAJQAHAHgCAFQgBAGADAAQADAAADgDQADgBACADQABAAAAABQABABAAAAQAAAAgBABQAAAAgBAAIgCACIgCAEIgCAHQgBADgEABQgEACAGAHQAFAGAJAFQAHAFAAAGQAAAFgEADQgCADAAADQAAABABABQAAAAAAABQABAAAAAAQABABABAAIAHABQAGADACALQABAKAJABQAIABAOgCIADAAIAJgNQAEgEAIgGQAIgHAGgCQAMgFAIABIAGABIABAEIgBAGQAAABABAAQAAABAAAAQABAAAAABQABAAABAAQAGABAIgGIATgIQAGgCAAgDIABgJQAGgKgBgCQgEgGAAgEQACgQgCgEIgFgJQgEgFAAgJIAEgPIABgNIACgRQAFgMADAEQAGAGAIgHQAIgHACgGQADgGAEgCIANgMQASgYAAgEIABgGQAAgDgCgDIgFgHQgCgEACgEQADgGAGgFQAGgFAEABQAGAAAIADQADABAFgEIAGgFQAEgDgDgHIgGgIQgEgGABgDQAHgPAEACQAMAGAEgBIAPgDQANgBAFABQAHABAAAEQAAAGgFACQgIACgBAGQgCAKABAHQABAFADAAQAEAAACADIAGAFQADAEgBACQgDAEABADQABAFgEAEIgGAFQgDADACADQAEAHAPAJQAIAGAMgCQALgBAIgIQAIgLAFgCQAJgGACAFQADAGADAAQAGABADADIAEAFQACAEgBACQgEAGABAEIAFAQQAAAGgCAIIgIARQgDAHgFgBQgHgEgFADIgOAIQgHAFgDgDQgFgDgFABQgIADgHgCQgIgCgGgHIgGgGQgFgEgCABQgGADgEAGQgLAQgFgEQgDgDgFgHIgFgJQgHgIgDAEIgMATQgKANgDABQgHACgCAGIgCAGQABAAAAABQAAAAAAABQABAAAAAAQAAAAABAAIAEgDQABAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQAGAMAAACQAAACgDAFQgFAFABAGIADAIQABAGAAACIgBAGIABAFQABAFAGACIAOACIAGAAQABgBABAAQABAAAAAAQABgBAAAAQAAAAAAgBQADgLADgBQADgCAFACQAKAFADgBQAEgBAEgEQAFgEADABQACABABAEIABAEQABABAAAAQAAABAAAAQABAAAAABQABAAAAAAQAHADADAEQAEAGADAKQADAHgFACQgHAFgDAEQgCAEgBAIIgGAMQgDAGgCAGIgEASQgBAIgCABIgJAFQgBAEABAEQACAEAHAHQADAFAAABQAAAGADgBQAHgEABABIACAFIACAKIADAEIADAEQAAADAFADIAGADIAHAEQAAAAABABQAAAAAAABQABAAAAABQAAAAgBABQAAAAAAAAQAAAAAAABQgBAAAAAAQgBAAAAAAQgDgBgDADIgJAKIgBACQAAABAAAAQgBABAAAAQAAABABAAQAAAAAAABQAFAGgFAHQgRAVgBAEQgCAFAAALQABANACAGQADAIAHAHQAHAHACgGIAEgHQACgBAGABIAPAAQAJAAAGAFQAGAFAFAJQADAIABAGIAAAIQABADAFACIAJADQADABABACQAEAGAKgGIAIgEQADgBAEACIADAEQABABAGAAIALABQADAAAFgDQAHgEACAAQADAAAEAEQAKAIACANIACAHIgBAIIgDAPQgCAKgEAEQgHAHgNAAQgMAAgFAFIgHAFQgEADAAAEQgBAFgSAFIgDABQgEgDAAgCIgBgFQAAgBAAAAQAAgBAAAAQgBAAAAAAQAAAAgBABQgDADgCgFQAAgBAAAAQAAgBgBAAQAAAAAAgBQgBAAAAAAIgDgDQgCgFgEAEIgFAGQgBAFgDAAIgHgBIgDgBIgDABIgDABQgDABgGAEIgCACQgGAHgCgCQAAAAAAgBQgBAAAAAAQgBgBAAAAQgBAAAAABIgEADIgEADQgBAAAAABQgBAAAAABQAAAAgBAAQAAABAAAAIACAKIACACQAEAKgFgCQgHgBgEAHIgCABQgEAFgDgBIgGgBQAAABgBAAQAAAAgBAAQAAAAgBgBQAAAAgBgBQAAgBAAAAQgBgBAAAAQgBAAAAAAQgBABgBAAIgFAEQgFAFgDABIgFADIgEAEQgBAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAIgDgCQgDgCgDABQgBABAAgGIgBgFQAAgEADgCQAAgBAAAAQABAAgBgBQAAAAAAAAQAAAAgBAAIgKADIgKADIgCABIgEAGQgEAHAAAGIgCAFIAAAHQABAAAAABQAAAAAAABQAAAAgBABQAAABAAAAIgCACIABAAIgCAAIABAAQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAgBgBAAIgFgHQgFgHgMgKIgGgFIgCgEIgDgGQAAAAAAgBQgBAAAAAAQgBAAAAAAQgBABgBAAQgDACgDAIIgGANQgGAJgFgUQgBgIgHgGQgFgDgEAJIgBACIgCADIgHAGQgGAEAAAFQAAAGgFABQgGABAAADQAAABAAAAQAAABAAAAQAAAAAAABQgBAAAAAAIgGAAQgBAAAAAAQgBAAgBgBQAAAAAAAAQgBgBAAAAQgBgCgDgCQgGgDgBgFQgBgGgEgCIgOgLQgIgFgEABQgEAAgDgEQgCgDgDgBQgEgBAAAGQgBAFgFgBQgGgBADAFQAAABAAAAQAAABAAABQAAAAAAABQAAAAgBABIgLAJIgFAIQgBAEgCAAIgFAAQgGACgCgDQgDgDgHAAQgJgBgFAFQgCACgFgBQgBAAAAAAQAAgBgBAAQAAAAAAgBQgBAAAAgBIgCgGQgBgHgJADQgEABgBACQgCACAAAFQAAADgCAIQgCAFgGAAQgGgBAEAIQAFAHgDAEQgCACADAFQACAEgBAGQAAADADAEIABACQAGAGADAFQABADAAAFIgBAKIABAEQABACADAEQAGAFgLAAQgEAAABAGIAAAGIgCAJQgDAIACAFQABACADABIAFACIACAFQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAQgEAAgBAFQAAADgFABQgCAAgIgFg");
          }, this.shape.setTransform(.003, -.0062), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.yunnan, new cjs.Rectangle(-49.3, -51.9, 98.69999999999999, 103.9), null), (g.xizang = function (A, g, Q) {
          var _this5 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this5.shape.graphics.f(A).s().p("AF9KuIgNgBIgDAAIgZAAIgDgBQgDAAgJgFQgDgCgEAAIgEgBIgFAAQgEAAgKgIQgDgCgEAAIgEgBIgEAAQgFACgTABIgSgCIgIAAQgBAAAAAAQAAAAAAgBQgBgBABAAQAAgBAAgBIACgHQAAgFgBgDIgEgIQgCgMAHgHIAHgGQADgDgDgEIgCgGIgCgGQgCgGgDgBQgCgCgNgCQgJgBgDgBQgGgCgDgDQgEgEACgHIADgJIADgNIAAgCQAAgBgBgBQAAAAAAgBQAAAAgBAAQAAgBAAAAIgEgBQgBAAAAAAQAAAAgBgBQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAQAFAAgCgFIgDgDIgFgCQgDgBgEgIIgFgJQgCgCgFAAQgDgBgCADIgBACQgBAGgHgEIgEgCQAAAAgBAAQAAAAgBABQAAAAAAAAQAAABAAABQgCAKgEgEIgNgIIgSgNIgBgCQgHgLgFACQgFAEgFgDQgIgCgDgEQgBgBgEgCQgEgBgCgCIgFgGQgCgDgFAAQgEAAgBgDQgFgHgBAHQAAABgBABQAAAAAAAAQgBAAAAAAQgBAAgBgBQgCgBgEAAQgDAAgCgDIgDgEIgGgDQgCAAgDgEQgCgDgEAAQgDgBgCAFQgDAEgCgCIgLAAIgIAEQgIADgGAKQgDAFgRAKQgCAAgGAGQgGAGgEAGQgCACgBAIQAAADgFAEQgEAEABAEIAEAJQACAHgGAAIgJAFQgFAEgIgEQgCgCgCgFIgDgJIgDgFIgDgHQgBgCABgGQACgJADgBIAFgGIACgEQAHgNAAgIIgCgQIAAgFQgBgCgCgCQgDgFgEAAQgDAAgCgEQAAgBgBAAQAAgBgBAAQAAAAgBAAQgBABAAAAQgFAAgCAEQgBADgEgBIgHABIgCABQgEAEgGgBQgDAAgCACIgCACIgCACQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgCABgEgEQgBAAgBAAQAAgBgBABQgBAAAAABQgBAAAAABQAAABgBAAQAAABgBAAQgBAAAAAAQgBAAAAAAQgEgEgGAAIgKgDIgDAAIgBgEQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAAAAAAAIgDAAIgLAKQgCAFgEAAQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAAAAAQgBAAAAAAQgCABgCgDQgEgFgCAAQgDgCgCACQgCADgDAAQgBAAgBgBQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAAAAAIgFABQgDABgCgCQgDgDgFABQgDAAgFgCQgDgBgBgBIgCgGQgEgLgEABIgFgBIgDgGIgEgFQgDgCgDAAQgCAAgCgGQgBgGgGAAQgGADgEgGQgBgBgBAAQAAgBgBAAQAAgBgBAAQAAAAAAABIgHANIgFAGQgEADgGgEIgGgFIgJgGQgFgEAEgGIADgHQABgCgDgEQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBAAAAAAIgGAEQgCABgCAFIgBAFIgBAJQgCAGgOgHQgCgBACgFIADgHQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBAAAAAAQgBgBgBAAQAAAAgBgBQAAAAAAgBQAAAAAAAAQAAgKgFgFIgGgKIgBgFQADgJgBgDQgDgFgFAIQgEAIgBAAQgCAAgDgGQgDgJgMACQgMADgEgGQgBgHgKAAQgEAAAAgFIABgKQACgFAGgEQAHgEgCgJQgBgDgFgEQgDgCgFADIgFADIgDACIgEABIgGgBIgFgCIgHgEQgIgEADgGQABgCgEgEIgEgDIgMgGQgFgDgBgCIAAgFQABgHgIgBQgIgBgBgHQgBgDAEgFQADgGgDgDQgBgBgBgFIAAgEIACgMQACgDgCgCIgHgGIgGgEQgBAAAAAAQgBAAAAgBQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAgBAAQgBAAAAAAQgBAAgBAAQgCAAgGgBQgEgBgCAEQgDAFgHgDQgDgBgEACIgGADQgDACgEgHIgHgOQgCgIAAgDQAAgFgBgBIgEgGIgDgHQgCgBAAgEQAAgGgBgBQgBgDgFgBIgJgDQgCgBgEgHQgBgCgHgDIgJgEIgFgFQAAgCgEgBIgFgEQAAAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAAAIAEgCQAAgBABAAQAAAAAAAAQAAgBAAAAQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAgBgBAAQgBAAAAAAIgGgBQgBAAAAAAQgBAAAAgBQAAAAABgBQAAAAABgBQACgCgCgDIgIgMQgFgHgEgCIgEgCIgHgFIgEgDQgFgBAAgCIACgGQABgDgCgEIgFgGQgBgCACgEIADgHQAAgCgEgCIgFgBIgFAAQgDgBgFgGQgCgCgHgDIgHgFIgHgGQgEADgBgCQgBgBAAAAQAAgBgBAAQAAABgBAAQAAABgBABQAAABgBABQAAAAgBABQAAAAgBAAQAAAAgBgBIgHgHQgBgBAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAIgBACIgDALIgFAJQgBADgHAFIgFgEQgBAAAAAAQgBAAAAAAQAAAAgBAAQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAAAAAABQACABAAAIQAAACgJgBIgKgCQgCgBAAgEIgBgDIABgQQAAgGgFgEIgLgIIgPgSQgCgBAAgEQgBgDgCgCQgGgBgDgCIgIgJIgHgEIgCgCQgDgCgDgGQgBgCgFgBIgJgDQgEgBgBgEIAAgEQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBIgBgEIAAgFIAAgCQABgCgCgEIgDgGIgIgSQgEgGgCgBQgDgBgEACQgDABgDgDQgCgBgDgHQgEgIgGgBQgDgBgCABQgDACABADQABADgGAAQgIgCABgEQAAgBAAgBQAAAAAAgBQAAAAAAAAQgBgBAAAAQgBgBgFAAQgKAAgBgLIgBgNIABgHQAAgEgCgDQgBgBAAAAQgBgBAAAAQAAgBAAgBQAAAAABgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgEAAQgEgBgBgDQgBgEAFgIQADgDgDgCQgCgCABgDQABgEAJgDQAEAAAAgHQAAgEgCgCQgEgBAAgHQgDgIABgCIACgGQABgDAEAAQAEgBACgCQADgCgEgEIgDgBQgGgEgBgCIgDgKIgEgGQgFgEABgDQAAgEADgGIAFgKIACgGIAAgHIgBgHQgBAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgEACgBQAIgHAHACQADABACgCIAFgBIAGgCQAFgCACAHQABACgCAEIgCAIIgCALQAAAEAEADQAFAEABADQACAEACAAIAHABIAIACQADAAAAgGQAAgFADABQAEABACgCQACgCADAAQACAAADgCIAEgFIACgEQAAgDABgDQADgJgBgCQgDgFABgDQABgHACgDIgBgFIACgEQABgDgDgHQgDgHADgFIACgDIgBgJIgFgPQgBgDgCgDIgDgFQgBgEgFgHQgCgCAAgEQAAgFgCgCQgDgDADgCQAEgDgEgEQgEgHAEAAQAIgBABgFIAFgVQACgIgCgDIgDgEQgBgDABgEQABgEADACQAEADAGgEIAHgBIAFgBQAJgGAAgBIAEgGQACgDACAAIADgEIAgAFQAgAHAFAAQAIgBAEgDQAGgFAGgOQAGgOADgEIAHgEIAQgPQAOgOAHgBQAIgCABgCQACgBgCgFQgCgEAHgIQAHgIAJAGQARAKADAGQACAEAIACIAMAEQAEABAGgFQAFgEADADQAKAOALAAQAEAAAGAJQAGAJACABQAGACANACQAPABAGgCQANgEAAgJQAAgDAVgDQAGAAADgDIAIgHQAFgGAFAAQAFAAAKAGIANAIQAEACAFgCQALgDABAUQAAAJAGAKQAGAKAFgCQAFgCAJAHIAPALQAMAHALgCIALgDQAFgCAEACIAHADQAEABACAEQADAEAMgBQAKgBAGgEIAFgHQADgEAGAAQAJABAQgCQAPgCAGgCQALgEAMAFIAKABQAEABAEAGQACAEAIADQAFACABAGQAAAEAHgGQAJgJAIABQAdAGAMgXQAJgRADgCQAGgFAWAAQAQAAAOgCQAHgBACACQAEAEAJACQAKACAGgDIAMgEQAIgBADgCQAEgDACAEIAHAIQAEAEAKABIASABQAdADAUgDQAIgBALAFQALAFABAFQACAIADAEQAFAFAGgFQAFgEAEAEIAIAIIAKAIQAFADAFgCQAEgCADAFQAGAIAHAEQAOAIAGAIQAHAJgOgBQgPgCgDABQgCABgDAFQgCAFAEAFQAFAGAGABIANABQAGADgFALIgFASQgBAEgEAAQgDAAACAIQACAIgIABIgOAEQgFACgCAFIgGAHQgCAEACAFIAGANQADAJgEAHQgEAIAFABQACABAKAAQAIAAACAIQABAIgJAFQgHAEACANIADASQACAhgJAEIgSAFQgKAFAKAPQAFAIAKAVQAKAUAGAHQADAEAHAFIAdAdQAQARAZAEQAKABAHAFIANAKQAIAHASASQASARAOAFIAHADIAKAAQAIAAACACIAGAKQAMAMAJADQAIACAOAAQAPAAAEABQAHACALAIIAiAbIAGAEIADAFQADAHAEgHQAGgJAFACQAEABALAIQAJAIAKABQALACALgCIATgIQAGgCAEACQACABADgCQAHgDADABQAGACAGAKQALATAJAAQAGAAAKAEQAMAEgGADIgMAFQgEABAHACQAHABADAFIAFAKQACACAJgBQAGgBgDAJQgCAIgFAKQgEAJAGAKQAIANACABQACACADgDQAEgCAGABQAFABADAEIAEAFQABAAAHgFQAHgFADACQADACAGANQAFANAHAAQAHgBgDgNQgDgQAAgFQABgGAGACQAEABAEgBQADABAFAKQAEAKAIAFIAPAFIALACQADAAgBgLIgGgWQgBgJAHACQANAEAQABQAUACAEgGIAEgSQADgKAEABQAGACADgIQADgIgGgGQgFgGAEgGQAEgGAGADIAKAGQAHADAIAAIAGAAQACAAAXANIANAIQAGADABAHIACAMQABAFAEAGIAIAMQAEAGgBAFQAAAEgDAFQgBAEADAGQALAZAJAKIATAVQAGAGgEAGQgCAEgGADQgEAEgEgGQgCgFgEgBQgEgBgBAEIgCAIQAAAEACADIAFAFQACADACAFQAHAXADAEQAKAMgCAJIgCAIQgCAFACAFQABAEAAAWIgBATQgBAMABADQACAGABALQABAMgCAGIgHAOQgEAKADAGQAGALgDAKQgCAHACAKQAEAOgCABQgBABgGgBQgDgBgCACQgEACABAEIACAMQABAHgEAAIgGACQgCABgBAFIgBALQAAAGgDABQgEAAgBgDIgBgIQAAgOgGAAIgJACIgCAAQgCACgBAEIgGAqQAAAJABADIACAFQAEANgCAJQgBAIgIADQgOABgEABIgGAEQgDABgBgMQgCgZgFgBQgHAAAAAIIAAAGQgBAFgEABIgHADQgBgCgFAAQgGAAgBgBQgCgCgBgDIAAgDQgGgSgFAAIgDADQgHAJgEgYQgBgFgFgBIgKgDQgDgBgCACIgCABIAAAHIgCAKQgQALgBAAQgBAAAAAAQAAAAgBABQAAAAAAAAQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQABAAAAABQACACgEADIgDAFIAAAEIAFAFQACACgBAFIgCAHIAAAGQAAABgBAAQAAAAAAAAQgBAAgBAAQAAAAgBAAQgDAAgCgCQgBgBAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAIgDABIgSAOQgBABgBAAQAAAAgBAAQgBAAAAAAQgBAAAAgBIgCgFQgBgFgFgEIgFgGQAAgBgBAAQAAgBgBAAQAAAAgBAAQgBAAAAAAQgCABgFgCQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBAAAAIgCgFQgDgEgGgBQgEgBgEgHQgDgEgEgBIgHgBIgDgBQgDAAgCgDIgFgBIgIAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBIACgHQAAgIgHgBIgKABIgIABQgFAAgDgCIgFgEQgDgCgFABIgHABIgCgFQAAgBAAAAQgBgBAAAAQgBgBAAAAQAAAAgBAAIgLACIgRAGIgMAGQgGADgDAIIgBADQgCAGgGADQgFACgLADIg2ASIgCABIgKADQgGACgJgBIgRgBQgCAAgEADIgEADQgDAFgIAHIgbAWIgDADQgEAGgCAHQAAAFgDABIgHADIgIADQgFACgGgBIgGABIgHgBg");
          }, this.shape.setTransform(-.0065, -.017), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.xizang, new cjs.Rectangle(-103.6, -68.6, 207.3, 137.3), null), (g.xinjiang = function (A, g, Q) {
          var _this6 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this6.shape.graphics.f(A).s().p("AGvNNIgGgIQgEgEgGAAQgQAAgJgFQgNgHgGgGIgHgEQgEgCgCADIgCAIQgBAEgCACQgIAGgHgBIgSgFQgFgIgQgJQgHgEgFgIQgEgFgEACQgEACgFgDIgKgIIgIgIQgEgEgGAEQgGAFgEgFQgEgEgBgIQgBgFgLgFQgLgFgIABQgVADgdgDIgSgBQgLgBgEgEIgGgIQgDgEgDADQgDACgIABIgNAEQgFADgKgCQgJgCgEgEQgCgCgHABQgOACgQAAQgVAAgHAFQgCACgJARQgNAXgdgGQgHgBgKAJQgHAGAAgEQAAgGgGgCQgHgDgDgEQgDgGgFgBIgJgBQgMgFgMAEQgFACgQACQgPACgJgBQgHAAgCAEIgFAHQgGAEgKABQgNABgCgEQgCgEgEgBIgIgDQgDgCgGACIgKADQgLACgNgHIgOgLQgJgHgFACQgGACgGgKQgFgKgBgJQgBgUgKADQgGACgDgCIgOgIQgKgGgFAAQgEAAgFAGIgIAHQgEADgGAAQgUADAAADQAAAJgOAEQgGACgOgBQgOgCgFgCQgDgBgGgJQgFgJgFAAQgKAAgLgOQgCgDgGAEQgGAFgDgBIgNgEQgIgCgCgEQgDgGgRgKQgIgGgHAIQgHAIACAEQABAFgBABQgCACgIACQgHABgOAOIgQAPIgGAEQgEAEgFAOQgGAOgHAFQgEADgHABQgFAAghgHIghgGIAAgBQgDgFgDAAQgIACAAgKQAAAAAAAAQAAgBgBAAQAAgBgBAAQAAgBgBgBQgFgEAAgCQgBgFgFgDQgBAAAAAAQgBAAAAAAQgBAAgBAAQgBAAAAAAQgDABgCgEIgBgFQgBAAAAgBQAAAAgBAAQAAAAgBAAQAAgBgBAAIgGgBIgDgFQgBgCgDgBQgHgCACgEQADgEgEgEQgDgDACgEQAEgGAAgCIABgDQABgEgBgDIAAgHQABgCAAgDIgBgGIABgEIACgEQACgDgEgCIgCgBIgBgBIAAgSIABgFIABgEIACgEIAHgFIAGgFQAAAAAAAAQABAAAAgBQAAAAAAAAQAAgBAAAAQgBgBgFAAIgEgBQgDAAgCgCQgBgBAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAQgBABAAAAQgBAAAAAAQgBAAAAAAIgEgDIgFgFIgBgBQgBAAAAAAQgBAAAAAAQAAAAgBABQAAAAAAAAIgHABQgEgEgDAAQgFgDgEAAQgLgCgCgFQgBgGgHgBQgHgCgCgBIgEgFIgDgFQgGgGgEABQgCAAgDgEIgFgFIgEgDIgEgFQgCgJgDgDIgFgFQgFgFAFgDQAHgFgDgCQgCgCgEAAQgGACgEAAQgCAAgEAEIgFgCIgGgDIgGgCQgIgCAEgFIADgGQADgDgCgCIAAgGQAAgFgGgBQgHgBAAgFIAAgCIABgFQAAgEADgBIAEgCQABAAAAAAQAAAAAAgBQABAAAAAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQABAAAAAAQAAAAAAgBIAEgBQAFgBgCgEIgCgHQABgCADgEQAFgDAAgFQAAgBAAgBQABAAAAgBQAAgBgBAAQAAgBAAAAIgDgHQgBgDABgCQADgFgBgCIgFgGIgFgGIgFgLQgCgDgEgDQgGgGgDAEIgDAEQAAABgBAAQAAABgBgBQgBAAAAAAQgBgBAAgBQgEgFABgDIACgFIABgNQABgHgGgBIgHgCQgEgDgBgCIgDgFIgHgCIgDAAQAAABgBAAQAAAAgBgBQAAAAAAAAQgBAAAAgBQgGgEgCADIgDADQAAAAgBAAQAAABAAgBQgBAAAAAAQgBAAAAgBIgBgFIABgEQAAgCgEgCQgEgDgBgCQgDgEgBABIgHACQgEABgBgCIgCgFIgBgKQABgIAEgDQAFgEAMAEIARAIIAOAFQAIABAFgCIADgEQACgCAAgEQABgFgCgFIgHgMQgEgIADgGIAOgUIgDgHQgDgFACgDIAEgGQACgFAAgBIgDgFQgBgEAAgCIAAgIIABgGIAGgPIAEgGQAFgIAAgEQgBgCgFgFQgDgDgFgLQgDgFgFgDIgNgGIgBgBQgSgLgMALQgGAFgHgGIgGgGIgCgIIgFgHIgGgLQgBgEACgFQADgLALAAIAIABQACgBABgEIACgFIgDgDQgEgEgBgJIAAgLIgBgHQgDgCgBgFIgBgHQACgFAHgDQAEgDAHgBIAGACIAGACIAGAAIAJgGQAGgEABgEIACgMQAAAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAgBQgDgDAFgGQACgDAGgDIAGgFQADgDACAAQACAAgCgFQAAAAAAgBQgBgBAAAAQABgBAAAAQAAAAABgBIAGgCQAEgDABADQABACAHgBQAIAAACABIAEAFQADADAGgBQAMgEACgCIAIgFIACgBIAEABQADABACgDQADgDADAAQAFAAADADQAFAFABgBIAEgBQAAAAAAgBQAAAAAAgBQAAAAgBgBQAAgBgBgBQgHgLAHgGQADgDADAIQADAHAIACQAFACAEAAIAIABQAFAAAHgDIAIgDQAKgEAEAAQAHgBgDAJQgBAFABAEIADAHQACACgDADIgGAFQgBABAAAAQgBABAAABQAAAAAAABQAAAAAAAAQABABAAAAQABABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAAAABQgBAAAAABQAAAAABAAQAAABAAAAQAAAAABABQAAAAABAAQAAAAABAAIAQgBQAEgBAJABQAHAAACABQAGAFAGgDQAGgCAAAEQgCAKAIgCQADAAAGgDQAEgBAHgIIAHgHQAIgEAAgFQAAgJABAAIAHgDQAFgCACgGIACgFIABgDIABgDQAAAAAAAAQABgBAAAAQAAAAABgBQAAAAABAAIANgCQAOgCACACQAEADAAACQAAAFAIABIAGABIALgBQADABAFAFQAFAEABgBIAJACIAIAAIAIgCIAEgGQACgFACgBQAGgCAIACQAHACACgBIAHgIQAGgHAFgCQAAAAAAAAQABAAAAAAQABABAAAAQABABABAAQADADACgBIAJABIAKgBQAFgCAFABQAFAAACgCQADgEAGgBIACAAIAXgEIAGgDIAHgBIALgBIAEgDQADgCADABQAIAAABgCQADgEAEACIAHADIAJgBQAFgBAFABQAAABABAAQABAAAAAAQABAAAAgBQAAAAABAAIACgEIAQgJQAEgCAEABIACABQAIADABgEIADgFIACgFIAGAAQABABABAAQAAAAABgBQAAAAABAAQAAAAAAgBIABgFIABgHQgBgCABgDIABgFIAAgGQAAAAAAgBQAAgBABAAQAAgBAAAAQABgBAAAAIADgEQACgGgBgDIABgIIAJgOQADgGAIADQADABACAAIAGgCQAEgBAHABQAEAAgEgFIgHgIIgFgFQgBgDAEgDQAEgDADABQAGABABgBIAGgEQAEgCADACQAGAEAEgCQADgBAAgJIAAgGQACgEgEgBQgEgBADgEIAEgEQADgDACgKIgEgcQgCgJAAgFIAAgDQACgMgBgFQgCgGABgGIACgQQAAgGACgEIACgGIADgQQABgJACgFQAEgHAAgIQAAgHgCgCIgHgFIgBgDIAAgHQgBgBAAAAQAAgBAAAAQgBAAAAAAQgBAAAAAAIgFABIgEABIgDgDIgDgDQgBgBAAAAQAAgBAAgBQAAAAAAgBQABAAABgBIADgBIgCgBQgBgBAAAAQgBgBAAAAQAAgBAAAAQgBgBABAAQAAgDADgBQACgCAGADQAHgDADgDIACgBQAAAAABABQAAAAAAAAQABAAAAAAQAAABAAAAIACAEQAAAAAAAAQABAAAAAAQABAAAAgBQABAAABgBIAEgDQAAAAAAAAQABAAAAAAQABABAAAAQABAAAAAAQAGAEADgCIABgBIAFgDQAFAAABACQADADAGgBIAGAAIACgBIAAgCQAAgBAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAQACAAAFAFIAEAEQABAAAAABQABAAAAAAQABAAAAAAQABAAAAgBQAEgCACABQACACAGgCIAJgCQAEgBAEABIAIABIAJABQAFAAAGgEQAFgDAFAAIAFABQAMABACAHQABADAFAEIACAEQACAHAKAAQAHAAAEACIARAJQACABAEgBQAEgCgBgEIgCgJIgCgKQgBgFgCgCIgFgFQgEgFABgJIADgJIAGgJIAEgGIABgHQABgGAEgCQAGgDAAgCQADgCABgFIAFgIIAGgIIAGgIIAHgKIAEgEQAFgFACgEIAFgKIASgfIAOgSIAKgNQAEgIABgBQAIgCAFAJQABAEADAAQAFAAACAEIAIAKIAEABQAAABAAAAQABAAAAABQAAAAAAAAQABABAAAAIAAADQACACAGACIADACIAEADQAJAHABgBQAGgCAGAFQADAFAFgCQAEgCAEAAIAKAEIAFABIAEACQAIAFAHgBIAJAFIAGAKQADADAGgEQAIgGAFgBQAFgBAIABIANABQAHABAGgCQAEgBADgFIAJgHQAGgEgCgIQgBgDABgCIADgFQACgEgEgEQgCgDACgJIAIgwIAAgJQAAgEADgFIAEgIQADgGAEgDIAEgFIAGgIQADgFAJgBIAPACIANAEQADABAFgBQAFgBAJAAQAHgBAFgEQAGgDACgFQABgDAJgFQAFgEAAgEQABgDAEgEQADgDgDgFQgDgEACgEIACgGQABgCADgBQADgBAEgFIAEgDIAFgBQAGAAAJACQAEAAADAEIAMAJQAFAEADgDQADgCAAgCQABgDADgBIAHABIANAAQAEAAgBADIABANQgBAFABACQACAEgFACIgHACQgHAFAEAEIANAPIAFAFQADAEgCADIgGAIQgCAEABABIAKAHIAKAGIAEAFQADAHAEACQAHAEABADIAEAGIgCAHQgBAEAFAHIAGAIIAIAGQAFADACADIAEAHQACADAGABQAEABADADIAFACQACABADgDQAFgEACACQACACAFAAQAFAAADADIACAHQAAAGAEADIAEAFQAAAEAFACQADABAEgBIAEgCQABAAAAgBQABAAAAAAQABAAAAAAQABAAABAAQAAAAABAAQABAAAAAAQAAABABAAQAAAAAAAAIgBAHIAAAHIACADQACADADABQAEABAGAFQAEADAAABIgBAGQABAGACABQACACAAAGIAAAIIABAEIACAEQAAADgCACQgBADABAGIACANIAGALIACAJIAEAFIAHAGIACAEQABAEAAAKIAEAHQADACAAADIgBAGIgEAIQgCADACACQAFAEgHAIIgHAKQgIAIAAAGIACARQACAIgBAGIgCAEIgGAGIgNAJQgFADgFAJIgHANIgDAHIAAAIIACAIIAEAHIACALQgBAEACADQAEAFgDADQgFAFAGAAQAHgBABgBQANAAADAHQADAEACABQAFAAACACQAFAEACgCQAFgEAAAFQACAGACABIAHADQAFADANABIAJAAQAMACACACIAFAFQADAEADAAIAJADIAIADQAGACAJgCIARAAIAJABIAGADQACACAFAAIAHABIAKACIAIADIAHADQADADAEAAIAGACIAEACIACADQABAFAEACIAEAEIAIAGQAGADAEAEIAKAJIAIAIIACAEIAEAFIACAGIAAADIAFACQAEABAEADIAEAGIAHAIQAEAJAEACIAEADIAJAEIAJAGIAIACIAYAAQAFABAAABQAAABgFAFQgDAEgBAFIgCAJQgDAFABABQABACAGABQAKABADANIABAOIAHAdQACAGABAIIABAGIABAJIABAMQACAGAFAGIARAWIAIAKIAFAHIABAGIABAIIgBAKQgJAAgVARIgHAGQgJAHAAACQAAABADADQADADAAACIABAGIADAIQABAEgFADQgEADABAIQACAIgBACIgFAHIgEAJQgCAGgdADIgUADQgPAEgFAIQgFAIgDgDIgEgLQgCgJgKABQgEABgJAFQgKAFgCAFIgEAGIgNAGQgPAFgRALQgVAOgLAPIgJANIgdAeQgDAEgJgBIgPgDQgRABgZgEIgHAAQgKgBgBACIABAHIgBANQAAAGgMAdQgPAigEAPQgIAigdATQgKAGAIAUIACAGQgWAAgHABQgSACgFADQgFACgKABIgjADQgdAFgMAAIgbAAQgIgBgEAFQgIAJgMABQgLAEgGgBIgHAAQgCAAABAFIADANQAAAQAHgGQAHgEAGAAQAHgBgBAGIgHAdQgFAXACAHQADAJADADQACADAGAEQAOAJADAIQAEAKAFAAQALACAAAKQACAUAFAIIAGAKQACADgCAEQgDAIgGgBQgHgBgGAEQgGAGgFABIgLACQgIABgEADQgGAFgDAGQgEAIADAEQACAEAFADIAIADQALAGgCALIgDAQQgDALABAFIABALQAAAEgGAAIgGABQgKAAgFgGg");
          }, this.shape.setTransform(-.0071, .0048), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.xinjiang, new cjs.Rectangle(-109.3, -85.1, 218.7, 170.2), null), (g.tianjin = function (A, g, Q) {
          var _this7 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this7.shape.graphics.f(A).s().p("AgHBoQAAgDgEAAQgDABgEADQgGAGgEgMQgCgEgCgBQAAAAAAAAQgBAAAAABQgBAAgBAAQAAABgBAAQgHAFgCgHQgBgDgEgBIgHgBQgFgDAAgUQABgHADgDQACgCAGgEQAKgEgIgJQgDgDACgGIABgLIgDgHIgBgEQABgDgBgDIgEgEQgBgDAAgHIAAgGIAHgNQAAgBABAAQAAAAAAAAQABAAAAAAQAAABAAAAIADAGQABAFAFgDQAFgDAFAEQAFACAAgOQAAgIACgEQABgCgCgDIgEgGQgBgCACgHIADgNQABgFAIgFQAEgCABgCIADgFQACgDgFgFIADgBIAGABQADACADAHQADAGAIADQACABACAFQAAACAGAFQABAAAAABQAAABAAAAQAAAAgBABQgBAAgBAAIgHABQgFAAgFACQgDABACAJIADAPQABAEADACIAEADQABABAAAAQABABAAAAQAAABAAABQAAAAAAABIACAJQACAFADgCIAGgFQAFgDAGAEQAFACgBAFIgGATQAAADAFACIAKADIAFACQAAAAAAAAQAAABABAAQAAABAAAAQAAABgBAAQAAADgKAEQgHACgGAKQgBADAAAFIABAHQAAAEgDAHIgJAQQgEAHAAAOQAAABAAAAQAAABAAAAQAAABAAAAQAAAAgBAAIgCACQAAABgHABQgIACgDACIgEACQgEAAgBgGg");
          }, this.shape.setTransform(.0083, .0176), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.tianjin, new cjs.Rectangle(-6.2, -10.9, 12.5, 21.9), null), (g.taiwan = function (A, g, Q) {
          var _this8 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this8.shape.graphics.f(A).s().p("AAKDXIgEgEQgBgBAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAAAQgBABAAAAQAAAAAAABIgBAEQAAAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBIgBgEQAAgEgDgDQgDgDACgEQACgEgCgCQgEgEACgEQABgEgEgDQgDgBgEgIQgFgHgGgCQgIgFgGgBQgEgCgMgIQgHgEACgBQABAAAAgBQAAAAAAAAQABAAAAAAQAAABABAAIADACQAAABAAAAQABAAAAAAQAAAAAAAAQABAAAAgBIgCgCIgEgFQgDgDAAgCQAAgBAAgBQAAAAAAgBQAAAAgBgBQAAAAgBAAQgDAAAAgGQAAgDgCgCQgCgCAAgEQAAgDgEgDQgDgDABgGQAAgBAAAAQAAgBAAAAQgBgBAAAAQgBAAgBAAQgCAAgEgBQgBgBgBAAQgBAAAAgBQgBAAAAAAQAAgBAAAAIAAgFQAAAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBQACgBgCgFQgBgCADgMIABgJQgBgEADACQABAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAIgCgDQgCgCABgNIgBgHIgDgHQgBgEABgDQABAAAAgBQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIAAgDQAAgCADgFQADgFAEAAQABAAAAAAQAAAAAAAAQABgBAAAAQAAAAAAAAQAAAAAAgBQgBAAAAAAQAAAAgBgBQAAAAgBAAQAAAAgBgBQAAAAAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBQAAAAABAAIADgFIADgIIADgGIAGgLIAEgIQADgEAAgDIgBgFQgBgBAEgEIAFgIIACgJQABgEAEgDQADgCAAgHQAAgFACgCQACgCABgDQABgCAEAAQADAAABgGQABgFADAAIACgCQACgBAAgHIACgJIACgGIAFgLQAEgIAHgBIAEgCIADgEQADgCAHgBQAEAAAFgEQADgBgCgFQgBgEAJgIQADgCAIgCQAFgBACAIQABAEAEAAQAAAAABAAQAAAAABABQAAAAABABQAAAAAAABQACACADgBQACAAAFACQADABACgBIAFAAQABAAABAAQABABAAAAQABAAAAABQAAAAAAABQgBAIAEABIADACIAAAEIgGAGQgGAGAAAKQgBAIAEALIAEAIQACADgBADIAAAGQABADgCADQgCADgBAEIgDAOIgFAJIgEAGQAAADgDAEIgDADQgBAAAAABQAAAAAAABQAAAAAAABQAAAAAAABIADAEIABAEIgCALIgBAPIAAANIgCAJQgBAHAAAGQABAGgBADIgBAIQAAAEgCAEIgCAGIgCAGQgBAEABACQACAFgDAEIgDAEQgBACAAADQAAAHgDADIgCADIgCADIgBACQgBAEgCACQgDADAAAEQABADgCADIgCAEQAAADgFABQgBAAAAABQgBAAAAAAQgBAAAAABQgBAAAAABIgDAEQgFAEgDALIgDAOQAAAGgCAEQgDAGACAEQADAFgBACQAAADABAFIABAKQABAGgBABQgDAEAAADQAAAFABABQABABAAABQABABAAAAQAAABAAAAQAAABgBAAIgBAAQAAAAgBAAQAAAAgBAAQAAgBAAAAQgBgBAAAAg");
          }, this.shape.setTransform(.02, .0209), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.taiwan, new cjs.Rectangle(-9.5, -21.7, 19.1, 43.5), null), (g.sichuan = function (A, g, Q) {
          var _this9 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this9.shape.graphics.f(A).s().p("AixIdQgIgBgCgKQgCgLgFgDIgJgBQgBAAAAAAQgBgBAAAAQgBAAAAgBQAAgBAAgBQgBgDADgDQADgDABgFQAAgGgHgFQgJgFgGgGQgGgHAFgCQAEgBABgDIABgHIACgEIADgCQAAAAABAAQAAAAAAgBQAAAAAAgBQgBAAAAgBQgDgDgCABQgEADgCAAQgEAAACgGQACgFgHgHIgKgJIgHgIQgEgHAEgIQAGgPgKAFQgEACgCgHIgDgMQgCgIgBgCIgHgQQgFgMAAgEQAAgDgFgFQgEgFgBgDQAAgDgCgEQgCgDABgCQACgDgFgDQgFgDgCAEQgDAFgCAAQgCABgEgDQgJgFgEAJQgCAFgGABQgGAAACgEQAFgKgJgCQgDAAgCgFQgCgHgEgDQgGgFgCgHQgDgIAFgDQATgLgDgIIgFgNIgDgJQgCgEgGABQgFAAgHgKQgIgNgEgCQgFgFAAgKQAAgBAAAAQgBgBAAAAQgBgBAAAAQgBAAgBAAQgEABgGAHQgEAFgDAIQgCAFgEACIgKACQgDACABAHQABAVgEAHIgCAGQgBABAAAAQAAAAgBAAQAAAAAAAAQgBgBAAgBQgCgCgDgIQgCgGgCgCQgGgGgBgHQgDgsABgHQADgKABgIIACgYQABgFgBgCIgCgPQgDgKACgHQADgKgGgLQgDgGAFgKIAHgOQACgGgCgMQgBgKgCgGQgBgDABgMIABgTQAAgWgBgEQgBgFABgFIADgIQACgJgKgMQgDgEgIgXQgBgFgDgDIgEgFQgDgDABgEIACgIQABgEAEABQADABADAFQADAGAEgEQAHgDACgEQAEgGgHgGIgTgVQgIgKgLgZQgDgGABgEQACgFABgEQABgFgEgGIgJgMQgDgGgBgFIgCgMQgCgHgFgDIgNgIQgYgNgCAAIgHgIIgJgKIgJgKQgHgKAAgHQgBgIADgDQACgEAFAAQAFAAADgBQADgBgBgHIgCgKQgBgDAHgGQAGgGACgFQAJgIADgFQACgDgFgDIgLgFQgEgCgCgDIgBgEIgGgKQgBgBAAgQIgBgHQAAgEACgDQABgDAFgBIAIAAQAEgBAKgJQADgCAAgHQAAgFAEgFQAHgGAGAAQAEAAAHAEIAKAGQAKAFAJACIAHAAQAEAAADACQAEADAAAGIgBALQABAIAFAKQAFAHAFADQAEACACANQAAAEAFAJQACAEABAOQAAALAEAJQAFALAIAFIARALQAHAFAEALQACAFAFACIAOAGQAJAFAGAFQAGAEAGgEQACgBABgFIACgHQABgEAHgEIADgDIACgCQADgBAFAKIADADIAEACQAEAFABALIgCAPQAAAEAHACQADABAGgEQAEgIADgBQADgCAFAEQADABAGAHIAEAKIAFAHIADgGQACgEAFgBQAEAAASAEQAFABAPAAQAGAAAEgDQAFgFACgIQABgFgDgDQgDgDgCgEQgBgDACgSQgCgMABgFQABgGAIgBIAMAFQAEADAJAAIAHACIAEAEQAGAFAGgCQAGgCAAgIQAAgCgBgDIgEgFQgCgFAHgEQADgBAIgJQAAgBAAAAQAAAAAAgBQAAAAAAAAQgBgBAAAAIgHAAIABgBQABgGAFgCQAFgCAEABQAEAAAAAGIAAAIQAAAFgEAIQgEAHgFAEQgDADABAEIAGAKQABAEADgBIAEgEQABAAAAgBQAAAAABAAQAAAAABAAQABAAAAAAIAGACQAAAAABAAQAAAAABAAQAAAAAAgBQABAAAAgBIACgFQAAAAAAgBQABAAAAgBQAAAAABAAQAAAAAAAAIAFADQADADACgFIACgJIACgGIADgEQABgCANAAQAHgBABgNQAAgFgCgDIgEgFIgHgSQgCgEgFgRQgBgFAEABIAIgBQAEgBACgGQABgCAFgBIAHAAIAKgCQABgBgCgEQgBgDAEgDIARgKIAMgEQAEgBABADIABAGQABADAHAEIAGAFQACACAAAGQAAAEgCAGQgBACAEAEQABACAAANQABAHACACQAEAEAMAAQADAAACgBIACgCQAEgDAEABQACABABAEIABAIQAAAAAAABQAAAAAAABQAAAAABAAQAAAAABAAIAEgBQAFAAAEADQAEACAFABQAGABANgCQAHAAAJAHQAEAEgBAFQgBACAEAHQADAJAFAFQADAGAFAAIACACQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAAAQAAADgGgCQgEgBABAJQAAALAEAKQABAFAAAEQAAABAAABQgBAAAAABQAAABAAAAQgBAAAAABIgFACQgDABABAHQAAAFACACQABACATAIIAMAKQAFAEAJAEIAFABIADgBQADgBAJADQAEABAGgBQACgBALADQAEACAGgFIAJgFIALgEQAAAAABAAQAAgBAAAAQAAgBABAAQAAgBAAgBIgFgIQgEgIAIgFQAEgDAEAMIAGARQAFAEAFgDQAGgFAEAAQACABADgEIAGgGQABgBAFABQAFABAEgCQADAAAAAGQABAHADACIADAFQAEADALAAQAFABAEAEQADAEAEgCQACgCAKgCQAKgDADgCIADgCQADgCACABQAJADAJgCQACAAAEAFIADAGQAGAJgHAKQgCAEAIADQAHADAFgBQADgCAFgHQAFgHACACQADABABADIAGAMQADAFAQgDQAGAGAGAIIAEAHQADAEACAAQACAAACAEQACADADAAQACAAACgEQABgFAFAAQADAAAHgDQAGgDAEAAIALABQAIgEAHAHIACAFIgCABIgCABIgHAAQgBAAAAABQgBAAAAABQAAAAABABQAAABAAABQADAFgBAEQgBAEgEgBQgHgCgCADQgBAAAAAAQAAABAAAAQAAABAAAAQAAABABABIABAHIABAKQAAACAHAFQANAJAEAEQAHAIgJAGIgPAMQgFAEgDAAQgGAAgDALQgCAHgNALIAAAGQAAAEgDAEQgCAEAAAEIgBAIIgFAIQgEAEABAEQACAIgHAGQgDADgDgCIgFgGIgCgDQgCAEgEACQgDACgLgBQgJgCgCAFIgEAIQgBADABADQADAJgJALIgOAZQgLAUgEADQgMAKgBgCQAAgBgBAAQAAAAgBAAQAAAAgBAAQgBAAgBAAIgHACQgGACgDgBQgHgBgEgKIgEgSQgCgGgJACIgVAKQgKAFgEgGIgGgLQgDgEgGgDIgTgIQgMgFgCAFIgEAKQgCAFgDABIgGABQgCABAAAEQAAACgEAGQgDADAEADIALAJQAFAGgCAHIgDAMQgCAEgDABQgCAAgDAIQgCAGgDAAQgHAAgJAHQgKAIADAIQADAGAHADQAFACABAEIABALQACAFAHAAIAJAAIACAMQACAeAKAEQADAAAFgCQAFgDAHAEIAQAFQAGACAAADQABAGAFAPIABAKQAAAGACAEIADAFQABAAAAABQABAAAAABQAAAAgBABQAAAAgBABQgDABgEgEIgIgIQgEgDgBgDQAAgFgHAAQgEAAgFgLQAAAAAAgBQgBgBAAAAQgBAAAAAAQgBgBAAAAQgEABgDAEQgCACgBAHQgBAEgEAAQgZAAgBALQgBAVADADQAHAJADgGQAEgGAGAKQACADgBAHQAAAGADACQAEACAHgBQAHgBAEgEQAHgGAHADQAHADAHALQAJAOgDAHQgBAEgEAEQgFAFgEAAQgDABgHgDQgFgCgEADQgEADgJgBIgOADQgHAAgHADQgIADgFgFQgJgKgGABQgDAAgFACIgGADIgHABIgEgKQgBgEAEgGQACgCgDgEIgEgFQgDgDgFgBQgEAAgCgGQgCgFgJAGQgFACgIALQgJAIgKABQgNACgIgGQgOgJgFgHQgCgDAEgDIAFgFQAEgEgBgFQAAgDACgEQACgCgEgEIgFgFQgDgDgDAAQgEAAAAgFQgBgHACgKQABgGAHgCQAFgCAAgGQABgEgIgBQgFgBgMABIgQADQgEABgMgGQgDgCgHAPQgBADAEAGIAFAIQADAHgDADQgLAIgDAAQgIgDgGAAQgEgBgHAFQgGAFgDAGQgCAEACAEIAFAHQADADAAADIgBAGQgBAEgSAYIgLAMQgFACgCAGQgCAGgIAHQgJAHgFgGQgEgEgEAMIgCARIgCANIgDAPQgBAJAEAFIAGAJQACAEgDAQQAAAEAEAGQACACgGAKIgBAJQgBADgGACIgTAIQgIAGgGgBQgBAAAAAAQgBAAAAgBQgBAAAAgBQAAAAAAgBIAAgGIgBgEIgGgBQgHgBgMAFQgGACgJAHQgIAGgDAEIgKANIgDAAIgQACIgGgBg");
          }, this.shape.setTransform(.0262, .0167), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.sichuan, new cjs.Rectangle(-57.7, -54.1, 115.5, 108.30000000000001), null), (g.shanxi1 = function (A, g, Q) {
          var _this10 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this10.shape.graphics.f(A).s().p("ABgH4QgCgGgCgDQgIgMgKgGIgKgFIgxggIgCgFQgHgHgHAEIgLgBQgEAAgGADQgHADgDAAQgFAAgBAFQgCAEgCAAQgDAAgCgDQgCgEgCAAQgCAAgDgEIgEgHQgGgIgGgGQgQADgDgFIgGgMQgBgDgDgBQgCgCgFAHQgFAHgDACQgFABgHgDQgIgDACgEQAHgKgGgJIgDgGQgEgFgCAAQgJACgJgDQgCgBgDACIgDACQgDACgKADQgKACgCACQgEACgDgEQgEgEgFgBQgLAAgEgDIgDgFQgDgCgBgHQAAgGgDAAQgEACgFgBQgFgBgBABIgGAGQgDAEgCgBQgEAAgGAFQgFADgFgEIgFgPQgEgMgEABQACgBADACIAKAEQAHACAJgGQAFgDADgJIADgXQAAAAAAAAQAAgBABAAQAAAAAAAAQABAAABAAQAEACgCgEQAAAAAAgBQgBAAAAgBQAAAAAAAAQgBgBAAAAIgPgFQgGgBABgGQACgEAGgCQAAAAABAAQAAgBABAAQAAgBABAAQAAgBAAAAIACgGQADgIACgCQAFgFALgBQADAAADACIAFADQADABAMgCIAMgDQAGAAACAHQAAABABABQAAAAAAAAQABABAAAAQABAAABAAQACAAACgDQAEgFgCgIQgBgEgFgFQgCgCABgIQAAgFgDgGQgDgEAHgKIAMgTQAAAAABgBQAAAAAAgBQAAAAAAAAQgBgBAAAAIgEgCQgEgCAFgFQADgCAIgDQADgBgDgJIgDgFIgDgFIgDgFQAAgDgGgEQgIgBgEgBQgFgDACgCQABgDAHgFIAEgJIAHgIIAFgGQABgCgCgDIgDgHQgCgKABgFQAAgDAKgGQAFgCACABIAJABQAIACADABQAIADAJAKIALALQAAABAAAAQABAAAAAAQABAAAAAAQABAAAAgBIAEgDQACgCAGAAIALABQAKgBADgDQADgCAEABIAJABQAHAAABgFQAAgCgKgPQgHgKAAgCQAAgDADgCQADgBADAAIAOAEQAHACAEgCIAKgFQAEgBAVAFQAKACAHgHQAFgFAEgKQABgEgDgQIgIgaQgBgJAEgDIAJgJQAGgFACgKQACgKgDgRIgCgKQgBgGgDgEQgDgDgEAAIgHACQgBAAAAAAQgBAAgBAAQAAgBgBAAQAAAAAAgBIgDgEIgLgJQgEgEgGgBQgFABgGAAQgEAAgDgFIgFgIIgEgGIgKgHQgIgFgOgCIgEgCIgCgEQgEgEgMgCQgEAAgCgFIgBgGIgDgKIAIgFQAEgFgHgEQgCgBACgEQAAgBABAAQAAgBAAAAQAAgBAAAAQAAgBAAAAIgDgEQgBgFABgKQAAgEACgDIADgFQACgDgBgEQgBgFADgBIADgEIAJgKQAFgEADAAIAHgDQAEgDAEgGIAFgBIAQAHQAJAEABAHQACAJADAEQAEAEADgBQAHgEAKABQAGAAAJgCQAJgCAEAAQATAEgBgTQgDglAHAEIAIAKQAEAHACgGQAGgNgCgFQgDgFgBgGIgCgGIgCgFIADgGIAEgGIAEgHIALgOIAFgFIAJgFQABAAAAAAQABAAAAgBQAAAAABgBQAAAAABgBQABgDgCgDQgBgCAFgGQAEgFAFgEQACgBAGABQAEAAACgGQABgIAGgKQAFgJAFgEIAKgGQADgCgBgDIgDgEQABgDAHABQAUABgCgLQgDgKAAgEQgBgGAKAFQAIADADAGQACACAEgCIAJgDQACAAADAEQAEAIADABQAEADAFgMIAJgRQADgFAHgCQAEgBALgHQAIgEgCAEQgGAVAFABQAAAAAAABQABAAAAABQAAAAAAABQgBABAAABQgBADAEAAQAKAAACADQAEAGgFACIgEACIgDAHIgGATIgLAcIgHARQgEALAAADQAAAFgCAIQgDAKgDACQgDAEgNAHQgHAFgDAIQgJAUAGAKIAMAQQAIALADAHQANAWgLAJIgJAHQgDACADAFIAFAIQAAADgIAKIgPASQgGAIAAADIACAVQAAAKABACQAIASgDALQgBAGAAAOQgBANABAHIAIAkIADAIIADAJIAAAKQgBAEACADQAEALgGAIIgKAOQgIAKgCAJIgJAmIgCAUQgBAOAEADQAEAEAHAAIgDAIQgCAIACADQAOAPgBACIgFAIQgBADAEAEIAMAHQAIADgHAFQgDADAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAABABQAGAGgCACQgFAJAFAFIAIAGQAGAEABADQAFAMAFAEQAKAJADAIQAFAOgDAJQgEALgDAEQgCAEgFABIgKAEIgHAFQgEACgDgCQgHgEAAgEQgBgDgCgCQAAgBgBAAQAAgBgBAAQAAAAgBAAQAAAAgBAAIgHAFQgIADgMAAQgJAAgKgFQgMgGgGAAIgUAAQgNgBgFACIgDADIgDACQgHAFAFABIAYAGQAIAEAAAFIAAAIQgBAEACADIADAFQABAAAAABQABAAAAAAQABAAAAABQABAAABAAIAGgCQADgEAEABQAFACABACQAGAJAEAJQAEAIAAAGQAAAEgEAAIgIADIgEACQgCABgFgCIgdgIQgJgBABAEQAAAKgDADQgIAFgCAFQgCADAAAGQABAFACAEIAIAKQAEAGgCAEIgEAJQgBAEACADQAFAIABAEIABAPQABAJgEABQgFABgSAAQgJgBgBgDg");
          }, this.shape.setTransform(-.0111, .0309), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.shanxi1, new cjs.Rectangle(-29.4, -50.8, 58.8, 101.69999999999999), null), (g.shanxi0 = function (A, g, Q) {
          var _this11 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this11.shape.graphics.f(A).s().p("Ai6GbQgCgDACgIIACgIQgGAAgFgEQgDgDAAgOIACgUIAJgmQADgJAHgKIALgOQAGgJgFgKQgBgDAAgGIAAgKIgCgJIgDgIIgIgkQgBgGAAgNQAAgOACgGQACgLgIgSQgBgCAAgLIgBgUQgBgDAHgIIAOgTQAIgJAAgEIgFgIQgDgEADgDIAKgHQAKgJgMgVQgEgHgIgKIgLgQQgGgLAJgUQADgIAHgEQAMgIAEgDQADgDACgJQADgJAAgEQAAgEAEgLIAHgQIAKgcIAHgUIADgGIAEgDQAFgCgEgGQgCgCgDAAQgFgBgCgFQgBgFACgCIAJACQAIACAFgDQABAAADgOQACgKAOAEQAGgBAMAEQALADACgBQAGgDAAgHIgBgUIAAgpQAAgPAJgMQAHgLAJgCQAFgBALAGQAPAHAGABQAFABAVgEIANABIAIgBQAIAAAAACQABACAGABQAKABAFgFQAEgDADgJQACgGAEgGQAEgGAEgBQAEgCAHAEIAGgFQAEgDAEgBIADgeIAJALIAFAIQADAEACABQABABAAAEQgBAGACAFIAGALQADAEADgBQAEgCAGAEQAGADgHADQgUAIgDADQgIAIgDgCQgGgDACAFQAEALgHgCQgFAAgCACQgDACADAEIADAIQADAFAEAAIAHABQAAAAABAAQAAAAABABQAAAAABABQAAAAABABQABADAEAAIAHgBIAHAAQACABAAAJIABAOQABAFADACIAHAFQACAEgDAJIgGARQgDAGACADQAGAMgGABQgHACgBAGQAAADgDACIgIACQgEABgHgEQgGgEgDACQgRAMgDAIIgCAIQAAAEADADIAFAIQACAEgFAEIgNANQgIAIAAAGQgCARABAIIACAIQABAFAEACIAMADQAIACABAEQAAADADAEQAEAGADAJQADAJAEAGQADAFAAADIAAAIQABADAFABQAFABAAACIAAAKQgBAJgRAfIgCAJQgBAFgEADQgDADgBACQgBACABAIIADAQQABAHgFgCIgFgBIgCAHIgEAHIgIAFQgFADgBAFQgBAEAEACQAGAEAAAJQAAADAEACQAFACACAEIAFAIQABADgBAHIADAJQgBAIgIAnIgGAbQgGAPgMAHIgbAWQgPANgMAAIgogCQgZgCgDAGQgEALgZAPIgVARQgPALgIACQgXAEgcARIgxAbg");
          }, this.shape.setTransform(.0287, .025), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.shanxi0, new cjs.Rectangle(-19.8, -41.3, 39.7, 82.69999999999999), null), (g.shanghai = function (A, g, Q) {
          var _this12 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this12.shape.graphics.f(A).s().p("AgIAyQgMgEgDgFQgCgFgJAEQgEACgBgHIgDgMQgCgFgCgBIgGgEQgEgEACgCIAEgGQABgBAFABQAFADACgGIACgKIADgGQADgFAAgEIgBgHQAAgFAHgGQAHgFAEABQAMADADADIALAFIAIAFIAHAFQAEADAHAIIAOAUQACADAAAGQAAANgIAAIgUAAQgHAAgEADIgGAFQgDACAAACQgBADgFAFIgEAFIgDAAIgDAAg");
          }, this.shape.setTransform(.0167, .0298), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.shanghai, new cjs.Rectangle(-5.5, -5, 11.1, 10.1), null), (g.shandong = function (A, g, Q) {
          var _this13 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this13.shape.graphics.f(A).s().p("AgfD2QgCgCgBgIIgCgIIgCgCQgFgFAAgFQgBgDgKACQgIABgHACQgEACgBAFQgBAGgDABQgDABgEADIgHAGQgEACgGgGQgIgHgDAAQgFgBgBADQgBAFgCADQgEAEgGgBQgDAAgRglQgJgUgLACIgOACQgKABgGADQgHAEgDADQgEAEAAAGQgBADABADIAAAIQAAAHgVAFQgKgGgCABQgLAFgUAAQgDAAgFAEQgEACgKgEQgGgDgCgJQgDgMgBgCQgCgCgIgCQgIgCgCgCIgGgHQgDgFgDgBQgNABgIgDQgKgDADgHQARglAEgGQADgFAJgHIAQgNIALgMIALgNIAdgZQARgPgJABQgLABgFAFIgMAMIgVAVQgMAJAAgOIAAgJIAEgIQADgFABgMQAAgMgBgIQgBgFgIgEQgJgDgBgFQgFgPANgXQAEgHAKgHQAKgHADgDQADgEADgKIAFgPIAIgVQAFgOAEgEQAEgEADgBIALAAQAHgBAAgCQgBgEABgFQAAgHACgBIAKgBQAHgCADgDIAHgMQAIgNAMgNQAIgIAPABIAYACQAKAAABgFQAAgFACgEIAFgIQADgDAHgEQAFgCADgKQADgKACgBIAFgCIAGADIAGADQAAAAABAAQAAAAAAAAQAAABABAAQAAAAAAABQAAADgEABQgBAAAAABQgBAAAAAAQgBABAAAAQAAAAAAABQgBAAAAAAQABAAAAABQABAAAAAAQABAAACAAIAHAAQADAAADAEQAGAHgIACQgFgBAAACIAEABQAEAAABABQABABgEAEQgDACAAADQABADgCADIAAADQAAAAAAAAQAAAAABgBQAAAAAAAAQABgBABgBIADgHQABgEAEgCQAHgFAAgIIAAgHQAAgEADADQAEAEAFABQAGAAADgEQAEgDADAAQAEAAABAEIABAGQAAAAAAAAQAAABABgBQAAAAABAAQABAAABgBIAHgFQADgCAAgEQACgIAFgBQAGgBAAAIQAAAIACAAIAEgFQAFgGACAMQAEAKAEACQAEACADAHIACAFQAAACADACQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAAAAAABQgBABABABQAAABgDADIgGAGQgFALAEAGQADAEgBAEQAAAEgCABIgEABQAAAAAAABQAAAAAAAAQAAABABAAQAAABABABQADADgBAEIgBACQAAAAABABQAAAAAAAAQABABABAAQABAAABAAQAHABACAGQAAAAAAAAQAAABgBAAQAAAAAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQABAAAAAAQABAAAAAAIAFAAQAIABACAEQACAGAFgDIAGAAQAFAAACgBQAJgGAPABQARADAAgIQAAgCAFgGQAGgGgBgCQgIgIABgDQACgEAMgDQAEgBAEgEIAEgFQACgDAJgHIAFgHQACgFgEgBQgIgBgBgDQAAAAAAgBQAAAAAAAAQAAAAAAgBQABAAAAAAIAHgBQAIgBACgEQACgDAHAAQAEAAALgJQAEgEAJAAIAIgBQAFgCAAADIgBAEQAAAAAAABQABAAAAAAQABAAAAAAQABAAABABQAEAAABAEQAAABAAABQABAAAAABQABAAAAAAQABAAABAAQANgFgDAHQgCAEACACIAEAEQADADADAAIAEABQAAAAABAAQAAABAAgBQAAAAABAAQAAAAAAAAQAAgBAAAAQAAAAABAAQAAgBABAAQABAAABAAQAAgBABAAQAAgBABAAQAAgBgBAAQAAgBAAAAQgGgHAKADQADABADACQAAABAAAAQABABgBAAQAAAAAAAAQAAABgBAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAABAAAAQAAABAAAAQAAAAABABQAAAAABABQADABAAADQAAADAEABIAHAEQABAAAAAAQABAAAAAAQABAAAAAAQABgBAAAAQACgDACAAIAFAAIAHACQAAAAABAAQAAAAABAAQAAAAAAgBQAAAAABgBQAAgDAGABQACAAAEgCIADAAQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAABAAIgBgEQgCgFAFgDQACgBAAgDQAAgBAAgBQAAAAABgBQAAAAABAAQAAgBABAAQACAAADACIAFADQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAABQAAAAAAAAQAAAAAAAAQAAABAAAAQgBAAAAAAIgFABQgBAAACAFQABADAFgDQAEgDABADQAFAIAJgDQADgBAEABQADABADgCQAOgJACADQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQAAABgBAAQAAABAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAQgBAAgBAAQAAAAgBABQAAAAgBABIgCADIgBADIgCABQgBgBAAABQAAAAAAAAQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAAAQABABAAAAQAAABABAAIAEAGQABAAAAABQABABAAAAQAAABgBAAQAAAAgBABQgDABABAEQACADgEgBQgCAAAAAAQgBgBgBABQAAAAgBAAQAAAAAAABQgBAFgBgFQAAgBAAAAQAAgBAAAAQgBAAAAAAQAAAAgBABQAAAAgBAAQAAAAAAABQAAAAAAABQAAAAAAABIACAGQAAABAAAAQAAABAAABQAAAAgBAAQAAABAAAAIgEADQgBAAAAABQAAAAAAAAQAAABAAAAQABAAAAAAIACACIABACIABgCQAAgCAEgBIAIgDIACAAQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAgBABIgDAFQgCADADADQAEAEgIADIgJACQgEAAACACQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAQAAAAgBABQAAAAgBAAQgBAAAAAAQgBAAAAAAQgKABgBgBQgEgFAEgCQAHgCgFgBQgIgDADgHIADgFQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAQgCAAgCAEIgCAHQAAAIgFACQgDABgDgCQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQABAAgBgBQAAAAAAgBQAAAAAAgBQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQAAgBgBAAQAAAAAAABQgBAAAAAAIgCAFQAAAAAAABQAAAAAAAAQAAABABAAQAAAAABAAQAJgBgHADQgDACgGAAQgBAAAAAAQAAAAgBAAQAAAAgBABQAAAAgBABQAAAAgBABQAAAAAAABQgBABAAAAQAAABAAAAQAAAGgEACQgKACADAFIADAEQAAAAAAABQAAAAgBAAQAAAAAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCgCQgDgFgDADQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQgBgBAAAAQAAAAgBAAQAAgBABAAQAAAAAAAAIAKgJQABAAAAgBQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQgBAAAAAAQgBAAAAAAQAAAAgBABQgDAAgCADQgCAEgCgFQgBgBAAgBQAAAAgBgBQAAAAgBAAQAAAAgBAAQgBAAAAABQAAAAgBAAQAAABAAABQAAAAABABIADAGQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAIgEACIgCADQgBAFgEAAQgEgBgFAEQAAAAgBAAQAAABgBAAQgBAAAAAAQgBAAAAAAQgBAAgBAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQgBgBAAAAQAAAAgBAAQgCABAAAEQAAAGgEACIgCACQAAAAgBgBQAAAAAAAAQAAAAgBgBQAAAAAAAAIgBgDIgCACQgBAAAAABQAAAAAAABQABAAAAABQAAAAABABQAAAAAAAAQAAABAAAAQAAAAgBABQAAAAgBABQgEACgCgCQgBAAAAAAQgBgBAAAAQAAgBABAAQAAgBABAAQAAgBAAAAQABgBAAAAQAAgBgBAAQAAgBAAAAQgCgBgDAAIgHABQgDABgBAEQgFAMAHgHQAHgHACAGQAAABAAAAQAAABAAAAQABABAAAAQAAAAABABIADgBIADgCQAAAAAAAAQABABgBAAQAAAAAAABQAAAAAAABQgDAEACAEQAAAAAAAAQAAABAAAAQAAAAgBAAQgBAAgBAAQgFAAAEAFQAFAKgGgDQgGgDABgEQAAgDgDgCQAAAAgBAAQAAAAgBgBQgBAAAAAAQgBAAAAABQgFABAAAEIgBAEQgBACABADIAEAGQAAAAAAABQAAABAAAAQAAABgBAAQAAAAgBABQgDABAAADQgBAEADADQAHAJgCACQgDACgIAAQgFgBgFAEQgFAFgEABQgQAEADgIIAFgIQADgFgCgCQgFgEABgCQAAgBAAAAQAAAAAAAAQAAgBgBAAQAAAAgBABQgBAAAAAAQAAAAgBABQAAAAAAAAQAAABAAABIABAFQABADgDACQgBAAgBAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAgBABQgBAAAAAAIgFABQgBgBAAABQgBAAAAAAQAAAAAAAAQgBABABAAIAAAJQgBABABAAQAAABAAAAQAAABAAAAQABABAAABQADADAEAAQAFgBABABQAAAAAAABQAAAAAAAAQAAABgBAAQAAABgBABQgDACABADQAAAAAAABQAAAAABAAQAAAAAAAAQABAAABAAIAGgDQAAgBABAAQABAAAAAAQABAAAAABQAAAAABABIgDAEIgFAGIgCAEIgBgCIABgEQAAAAAAAAQAAgBAAAAQAAAAgBABQAAAAAAAAQgIAGgCAAQgGADADADQADADgCAFQgCAEABADQAAAAAAABQAAAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQgFgFgCAEQAAAAAAAAQAAABAAAAQAAABABAAQAAABABAAQAAAAAAABQABAAAAAAQAAABAAAAQAAAAAAABQgBAAgBABQAAAAAAABQAAAAAAABQABAAABABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQgBACgEABQgDAAgBACIgEADQgBAAgBABQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAgBAAgBQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAgBABQAAAAAAABIgFAEQgGADABACIACAEQAAABABAAQAAABAAAAQAAABAAAAQAAABAAAAIgDAKIAAAFQAAABAAAAQAAABAAAAQAAAAgBAAQAAAAAAAAIgFAAQgBgBAAAAQgBAAAAAAQAAABAAAAQAAAAAAAAQACAEgGAEQgFAEgBAEQgCAGAAADIAAAJQgDAFgEABIgTALQgFADgDAAIgKgBQgGABgBAFIABAJIgBAHIgDAEQgHAFADAJQACAEgEABQgDABgJAAQgLgBgGAXQgCALgLAHQgEACgDAAIgCgBg");
          }, this.shape.setTransform(-.011, -.0107), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.shandong, new cjs.Rectangle(-37.5, -24.7, 75.1, 49.4), null), (g.qinghai = function (A, g, Q) {
          var _this14 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this14.shape.graphics.f(A).s().p("AhIHrQgGgOgDgCQgDgCgHAGQgHAFgBgBIgEgFQgDgEgFgBQgGgBgEADQgDACgCgBQgCgCgIgMQgGgLAEgIQAFgKACgIQADgJgGAAQgJABgCgCIgFgJQgDgFgHgCQgHgBAEgCIAMgFQAGgCgMgEQgKgEgGAAQgJAAgLgUQgGgLgGgCQgDgBgHADQgDACgCgBQgEgBgGACIgTAHQgLADgLgCQgKgCgJgHQgLgIgEgCQgFgCgGAKQgEAGgDgHIgDgFIgGgDIgigcQgLgIgHgBQgEgCgPABQgOAAgIgDQgJgCgMgMIgGgKQgCgCgIAAIgKgBIgHgCQgOgFgSgRQgSgTgIgHIgNgJQgHgFgKgCQgZgEgQgRIgdgdQgHgEgDgEQgGgIgKgTQgKgVgFgIQgKgPAKgGIASgFQAJgDgCgiIgDgSQgCgLAHgFQAJgFgBgIQgCgHgIAAQgKAAgCgBQgFgCAEgHQAEgIgDgIIgGgOQgCgFACgDIAGgHQACgFAFgCIAOgEQAIgCgCgIQgCgHADAAQAEAAABgEIAFgSQAFgMgGgCIgNgCQgGgBgFgFQgEgGACgEQADgGACAAQADgBAPABQANACgGgJIAFAAIAFADQAGACADAAQARAAABgNQAAgIAFAAQAEAAAEAGQAFAFALAGQALAGAFAAQAXAAAFAJQAEAIAJABQAIACAHgFQACgBgBgFIgCgKQgBgEADgHIADgMQABgLgDgFQgDgEgLgFQgLgFADgMQADgKAJgFQAFgCAMgBQAJgBACgDQAIgKAKACQAGACADgHQACgIgFgFQgFgFgDgLQgDgKABgEQABgEgDgFQgEgGgGAAQgEAAgDgIQgEgLgGgDQgMgHgGgGQgJgLAGgXIAIgjQABgIgIABQgEABgIAFQgEACgDgIQAAgMgCgEIgCgHQABgBAIABQAFABAKgEQAQgBAGgJQADgFAHAAIAZABQAPgBATgCIAcgEIAUgCQAKAAACgCQAEgCALgCIAQgCQAWAAAHgDIAGgEQACgBAJABIAVABQANAAAFADIAJABQADAAABAIIgBAUQAAAJAIABQAOABASAEQAVADAAAEQAAACgGAFQgDAFAJAEQAFADAZABQATABACAIIAEAfQAFATAMgCQAQgDANACQAOABAHAHQAHAIAKADQAMAEAHgGQANgKAMATQAFAJANAIQANAJAFgDQAEgCAFgIQAFgGAIADIANAFQABABABgJIAFgPQADgGAEgBIAIgHQAEgFAFAEQAIAFAEgEQAEgFgBgOIgDgXQgBgLADgIIAFgQQACgFALAEQAnANALAPQAJAMAOALQAQANAFgFQAPgRgBgGQgBgFAHACQAGABAFAGQAJAMANgMIAIgKQAEgBAMANIAWAZIAiAqQAFAGANAJQAOAJACADQADADAFACQAEACACgBQABgBgDgGIgEgIIgFgGQgDgGAAgDQABgEAHAEQAMAGADAHQAIAPADADQAJAIAEAAIAHABIAIABQAFACADAEIACAFQAAAAABABQAAAAAAAAQABAAAAABQABAAABAAQAHADgBADIgDAHQgCAGADADIAQAPIAHAHQADADADgBIAKgGQAHgFAEAEIAOATQAIAHAFgEIAEgFQACgCAFACIAJAFIAGAEQAFADACAFIAEAGIACAQQAAASAHAEIALAEIAGACQAEADAAADQAAABAAABQAAAAAAABQAAAAABABQAAAAABAAQAFACABABIAEAJQAEAGgEADIgHACQgBABgBAAQgBABAAAAQgBABAAAAQAAAAAAABQABADAEAFIADANIABAMQAAAIACADQADAEAFACQAJAEgBAGIgBAHIgCAEQgDAHABAFQACAHAGACQAFABADADQAEADgBAJIgBAWIAAASIgBAEQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAgBgBIgIgBQgHgBgBAFIgDAUIACAKQABAEgEAAQgOgEgFACQgEACgDAHIgBAFQAAAAAAABQgBAAAAAAQgBABgBAAQAAAAgBgBQgOgDACAFIAFAQQAEALgIAJQgFAFgNAIQgMAIgEAGQgCADgDAKQgCAGACAGIAEAKQABAEADACQAIAGABAEIAGAMIADAGQABADgEACIgTAJQgFADgGAGQgEAEgDAAIgKAAIgLAAQgEgBgCgDQgGgGgDAAIgLgEIgPgIIgHgFIgcgLQgEgFgGAGQgDADgDAIIgCAJQAAAFAGAKIAKASIADAFQADAEADABQAJAEACAEQAEAIgBACIgDAGQgBABAAAAQAAABAAABQAAAAABABQAAAAABAAQAFAEAGgBIANgCIAHgBQAFACAEAEQADAEAAAGQAAAKAFABIAJABQAFAAgCACQgHAJgDACQgHAEACAFIADAFQACACgBADQAAAHgGADQgFABgGgEIgFgFIgGgCQgJAAgFgDIgLgEQgIABgCAGQgBAEACANQgBASABACQACAFACACQADADgBAFQgBAIgGAGQgDADgHAAQgOAAgFgBQgTgFgEABQgEAAgDAFIgCAGIgFgHIgFgKQgGgIgDgBQgEgDgDABQgDACgFAHQgFAFgEgCQgHgBAAgEIADgQQgCgKgEgFIgDgDIgEgDQgFgKgCABIgDACIgDAEQgHAEgBAEIgBAHQgCAFgCABQgGAEgFgEQgHgGgJgEIgNgGQgGgDgBgEQgEgMgIgEIgQgMQgJgFgEgKQgEgKAAgLQgBgNgCgEQgFgJgBgEQgCgNgDgCQgGgEgEgHQgGgJAAgIIAAgLQAAgHgDgCQgDgCgEAAIgHgBQgJgBgKgGIgLgGQgGgDgEAAQgGAAgHAGQgEAEAAAGQAAAGgDADQgLAJgDAAIgIABQgFABgCACQgBADAAAFIAAAHQAAAPABACIAGAJIACAFQABADAFACIAKAEQAFADgCADQgDAGgIAIQgDAEgGAGQgGAHAAADIACAKQABAGgCABQgEACgEAAQgGAAgCADQgCAEABAHQAAAIAGAJIAJALIAKAJIAHAIIgGABQgIgBgHgDIgKgGQgGgDgEAHQgEAGAFAGQAGAGgDAHQgDAIgGgCQgEgBgDALIgEARQgEAGgUgCQgQgBgNgEQgGgCABAJIAFAWQABALgDABIgKgDIgPgFQgIgEgEgLQgFgKgDAAQgEABgEgCQgGgCgBAHQAAAFADAPQADAOgHAAIAAABQgHAAgFgNg");
          }, this.shape.setTransform(.0475, 9e-4), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.qinghai, new cjs.Rectangle(-68.4, -50.3, 136.9, 100.69999999999999), null), (g.ningxia = function (A, g, Q) {
          var _this15 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this15.shape.graphics.f(A).s().p("AAVEEIgIgOQgCgEgCABIgGADQgCABgBgEIgCgHQgDgFgHgCIgHAAQgEABgDgDIgHgJQgEgGACgEQAAgBAAgBQAAAAgBgBQAAAAgBAAQgBgBgBAAIgLACQgHACgHgIQgGgGgFgLQgDgHAKgOQAFgGAGgDQADgDAAgDIgBgGIgBgJIgDgKIgGgRQgEgGgDgBIgFgDIgDgNQgCgEADgFQADgDAHgDQACgCgCgEIgDgHQgGgHgDgDIgBgFQgCgEgCgBIgKgBQgCAAgIgKIgKgRQgBgBAAAAQgBgBAAAAQgBAAAAAAQgBAAgBABIgGACQgEABgFgEIgFgGIAHgDIADgDQABAAABgBQAAAAAAgBQABAAgBAAQAAgBAAAAIgDgFQAAgCgJgCIgTgCIgDAAIgBgBIAEgEQAFgFAGAAIAYgBQATgBALgGQAjgQAGABQARAGACgHIABgEIAGgDQAGgBAEgLQAFgMgDgJIgDgOQAAgEADgFQAEgEAAgGIgBgNQAAgJACgQQACgQADgFIAMgaQAMgWAGABQAJACAAgJQABgGACgCQABgCAGAAIAIAAQAEgBAEgEQAEgEAEgBIAIABIAEAAQABAAADATQADAKAFAGIAGAFQACADAAADQgCAIgGAIQgMANgFAKQgEAHgDAMIgEAQQgBADgEAEIgEADQgCADABACQABAEANAIQAMAHANAFQAIACAHgCQAHgBAJADQAGABAHALQAIAPACABIATAHQgHAIgDABIgGADQgDAAgFAFIgJAJIgEAFQgCABABAEQABAEgCAEIgDAFQgDADAAADQAAAKABAEIADAEQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQgCAEACABQAHAFgEAFIgJAFIgCgEQgEgDgEABIgJAAIgPgCQgFAAgHACIgLAAQgEgBAAAEIACAGQAAAHgDACIgEAGQgCACACAFIADAHQADAEgDAFIgEAEIgFADQgIAGgGAKQgBADABACIAEADQAEACABAEQACACAAAGIgCAKQAAAGANAAIAGADIANAFQAHADADAGQABAEAAAMIgCAKQgDAGACAHQACAFgDACIgIAGQgEADgFABQgMgEgFAAQgGAAgDAEQgCACADAKIgBAKQAAACADAGQADAEgCAGQgCAIgIAHIgEABQgDAAgCgDg");
          }, this.shape.setTransform(0, -.0033), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.ningxia, new cjs.Rectangle(-16.5, -26.3, 33, 52.6), null), (g.neimenggu = function (A, g, Q) {
          var _this16 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this16.shape.graphics.f(A).s().p("Ap1P8IgNgLQgHgFgMgMQgNgMgFgGQgCgEgNgGQgKgGgCgFQgCgJABgHQACgJAIgBQAMgBgLgcQgEgJAFgEIAMgFQAGgCAOgKQANgKADgEIAHgMQAFgIAHgDQAIgEAAgOQABgLgFgJIgEgKIABgIQABgFgCgCQgBgDgEgEQgHgGgnAKQgOADgNAIQgMAHgFAGQgEAFgFABIgKgBQgFgBgOgGQgPgHgDgEQgDgDgLADQgUAGgKACQgQACABAGQABAEAJAKIADAHQAAACgDAFQgGAKgMAPQgCAEgGgBQgGgDgDAAQgEAAgEgDIgKgIIgJgHQgBgBABgEQABgCgEgEQgEgFgBgFQgBgGgCAAIgFABIgLADQgHABgBgCQgCgFgHgEQgDgCAAgFIADgGIADgeQABgIgKAAIgRgBQgEgCgDgGQgCgGgEgCQgHgFAAgOQAAgEgGgDIgIgEQgQgMgFgHQgFgHgHgBQgKAAgKgCQgMgCAIgEQAFgEAKgCQADgBAHgEQAGgFADAAQAGgBADgIQAEgIAHgFIAKgHQADgDAAgEQABgLAHgPQAGgRAAgEQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBgBAAAAQgEgEgDgFQgIgQgPgEQgKgDgIACQgZANgJAAIgJgBQgDAAgEAJQgEAJgGgDQgDgBgGgIQgHgJgKAUQgDAGgDgDQgDgDAAgHIgBgFIgEAAQgDAAgBADQgCADABADQABACgCAEQgCAEgCACQgCABgDgBQgEAAgEABQgIADAAgLIADgZQACgMgGgIIgJgKQgFgGgJgDQgCAAgMgRIgRgYQAAAAgBgBQAAgBAAAAQgBgBAAAAQAAAAAAgBIAEgDIASgMQAIgDgBgEIgDgLQgDgMgHgTIgKgfIgahVIABAAQAIAAAGAEIAOAGQAKADAGADIAEADIApANIBLAQQALADAEAAQAHAAAIADIANABIAfgDQALgBAHABIAHAAIAMgBQAEgCAEAAIAQABIALAAIAJACIAQAFIASAGIAEACIApAPIAMADQAEAAACABIAEAFIALATIACAFIAFAIQACACAGADQAHAEAIABIASABQAHAAAFACQAIACAEADIATANIANAIIAJAFIAHAFIAKAHIAaALIAMABQAIABAHgBIAdgFIAMgBIAGgBQABAAAAAFIAAARQAAAFABACQACACAGgBIAMgCIAFAAIADABQAEAAACACIAGAIQABAAAGgFIAMgKIALgHIAsgXIANgFQAEAAAMgHIAzgUQAKgFAEAAIAPgCIALgDIALgDIAJgFQADgEAFgBIAFgCIAFAAQADAAAEAEQAGACAEAAIAKAAQAGABAEgBIAIgCIAJgBIAHgCQAFgCAGACQAGACANABIAIACQALADADgBQAJAAAGgEIAJgDQADgBACABIAcAEIADAAIAEgBQAFAAABgCIAWgVQAJgHAGABQAMACAIgFQALgJAIgDQAJgDACgGQABgDAGgGQAHgGABgDQAEgIAGgIQALgMACgGQAGgKAJgEIARgHQAPgLADAAIAGAAQADAAACgDIAOgOQAHgHAFgCQAKgDAAgIQABgEgEgGIgEgIQgBgDgEgEQgGgFgEgBQgEgCgHgHQgHgIAAgCQAAgKgDgEIgFgFQgDgDAAgFQAAgMAIgKQADgFACgLQAAgEAEgMQAFgNAEgHIAJgKQADgEAGgDQAGgCADAAIAGABQAUACAEgBQAKgBAEAKIAGAIQAEAEAIADQAKADAPADQABABAQACIAMABQAJAAABABIAKACQAJAAACgCQACgBAHgJQAHgIAGgCQAKgDAGgIQAIgKAGgFIAJgKQAHgJAAgDIACgHIABgGIAHgFQAGgCACAAQAHgBADADQABAAAFAAQAFAAABACQAEAEAPgGIAMgBQAMgBADgCQASgHABgEQAAgDALgJIAMgLQACgCAFAAQAGgBACgCQAJgLgDgGQgEgJAEgJQADgHAIgMIAIgNQAGgJAEgCQARgLAGABQAdACAIgEQADgCACgHIACgLIACgHQABgDAEABIAFgDQACgBAEAEQAFAIAIgBQAGgBAAgFQABgEATgMIAQgIQACgBAEAAQAFgBADACQADADAMgEQAOAEgBgEQgBgDAEgDQADgCADgBQADAAACADQABABAAAAQABABAAAAQABAAAAAAQABAAAAAAQADgDAFAGIAHAGQAIgCADACQAGADAIgFQADgCAQADIAEABIADgDIACgGQABgBAAAAQAAgBABAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAABAAQAAgBABAAQAAAAABgBQAAAAABgBQAAAAAAgBQABAAAAgBQAAgBAAAAQAAgQgBgCQgBgEgEgDQgEgFgBgKQgBgJgEgEIgCgCIgGgDQgJgEgBgDIgCgCIgGgHQgBgCgHgDQgGgDAAgCQADgEgFgBQgEgBgFgDQgGgDgBgEQAAgLgHAAQgDAAgFgDIgGgDQgGgCgFAAQgDAAgFgGIgKgPIgGgGIgCgBIgFABIgEgBQgCgCgDAAIgFACQAAAAAAAAQgBAAAAAAQgBgBgBAAQAAAAgBgBQgDgBgFABIgDABQgDgBgOADIgIADQgFABgCAEIgLASQgDAIgDABQgEACgEAIQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQgDACgEgEQgFgFgLgIQgNgJgGgCQgQgDgIAEIgIAEQgEADgCgBQgIAAgFgCQgHgCgFAHIgLANIgDAFQgCACgEgDQgRgKgGgHIgGgFQgDgDgBgHIgBgFQABgHgDgDQgDgDAIgGIAAAAIAQgKQADgBgBgFQgGgaAGgJIASgdQAAgCgCgEQgDgEADgHIAuh0QACgFAFADIAJAHIAYANIAGACIALAAQAMgBAJAHQAHAFAFgDIAAAAIAFgEQAEgDADgBIAKgBQAEgCAEgFQANgLABgEIAIgHQADgCAGgKQADgCAGgBIAKgCQANgCAHgGIAMgJIAGgIQAGgHgCgEQgCgGABgCQABgBAAgBQAAAAAAgBQAAAAAAgBQAAgBgBAAQAAgBAAgBQgBAAAAgBQAAAAgBAAQAAAAgBAAIgHAAQgEAAgDgBQgGgDAIgGQAGgEgBgLQgBgIALgJQAGgEAAgXQAAgDAGgHIAHgIQAIgIgDgKQgBgGABgDIAEgEQAHgFAAgGQgBgGABgBQACgBABgGQAEgKABgJQABgKACgCQAFgCADgEQAGgLAEgBQAEgCAFgHIAKgGQAEgCACgDQACgEgDgCQgFgEAEgDQAEgDABgHQABgLgKgEQgFgCAAgFQAAgFACgDQACgCgBgKQABgEgQgHQgHgDgDACQgGAGgGADQgKAEgDgEQgCgEABgEIACgEIAAgCIgEgGQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQACgCAGgCQAJgDAGgRQACgIAGgEQAHgEACgHQAAgEADgDQAEgDADgJQACgCAMgBIAIgBQAOACAIgIIAKABIAQARQAHAGgCAGIgIARIgIARIgMATQgIAKACACQACACAMADQAHAEAHABQAGACAIAKQAIAMAJgJQAHgHACgNQADgOAPAKQAHAGAKAJQACACAFAAIAHABQAFgBAEAFQADAGgEADQgEADAAADIACAPQABAKAKAaIAOAgQACAJAKADIAPAEQAHACAKgDQALgEAFgHQAFgHACgBIAJAEQAFACAHgEQAIgEAEAAIAOADQAFAAACgDQACgFAEgBQAFgCADAEQACACADgFQAEgGADAAQADAAADgEQADgEAAgFQAAgDAEgGQAEgFgBgEQAAgGALAAQALAAAFAFIAYAWQAUAVAJAGQAMAKADAEQACACgIAUQgLAKAEAPQADAGgDAIQgEAJgMAFQgCADABAHIgBAJIgIAeQgHAVAAAKQAAAKAHARQAIATABAKQADAngTgEQgMgDgCAHQgBADAAAOQgKAVgCAXQgCAUAFAOQAFAMgDAMQgCAMgFgGIgQghQgJgVgJAPQgMAJgIASQgIAVgDADIgMAJQgKAHgEAFQgEASgKAJQgUAJgOAQQgSASADASQAEAHAGAGIAMAHIAJAFQAEADAAADIABAIQABAEAEABQABABAAAAQAAABAAAAQABABAAAAQAAABgBAAIgBAGIAAAGQAAACADACQAFADAGAAQAHABAEgEQACgCAEgHQADgFAGAAQADgBABgCIACgHQABgFAGgBQAGgBAAAIQgCAHACACIAFgCQAFgCAAADIABAGIgFAHQgDACgLAGQgLAFgCADQgDADgFABQgGAAgDAEQgFAHAEANQABADAOAOIACABIgCACQgGAFgFAIQgEAGgEADQgKAHgBAJQgBADAEAQQABANgIgEQgIgEgGgGQgFgEgBAAQgCAAgDAEQgEAFgEAAQgIAAgPgIIgNgHQgIgCgCAGQgFAQACALQAAABAAABQABAAAAABQAAAAABAAQAAABABAAQAFAAADABIAMAGQAFAEAEAIIALARQAHAKAAAGQAAAKgFAjQAAAJAMAfQABAFAHAKQAGAKABAFQAAAHAKAFQAJAEAIgGQAGgFAMgPIAPgQQAGgFACAAQAEABAFAHQAHALAIASQAOAXADAHIALAUQAIAOgDAGQgCAEgIAGQgEAEAEACIAPAFQAMADAEADIAAgDQgBAKgBAZIgEARQgBADgEgBQgDgCgGABQgJABgEAIIgDAMQgCAIgEACQgJAFgHACQgKAEgNgDIgVgEQgKgBABAGIADALQACADgJABIgOABQgFABgJAFQgGAFgGAJQgFAJgEACQgFAEgDAAIgJABQgGABgHAFIgLAIIgJAKQgFAHgHAAQgGABgFADQgFAEgDABQgGACgJAHIgLAMQgLARgEACIgPAWQgFAIgDgFIgJgTIgKgTQgCgDABgEQABgDgGgDQgNgEgFgGIgEgHQgCgCgFABQgFABgMAOIgEADQgBACAEAHIAGALIAAAJIABALIgBAKQgCAXADAGQADAEAAAIQABAJgCAGIgMARIgDAAQgHAAgLgFQgKgEgHAAIgcAGQgQADACgLQgDgJgGgJQgFgIgCgFIgEgLQgBgEAFgEIAJgFQABgCgEgIQgCgDgCgMQgBgFgFADQgIAFgFgNQgFgLAAgJQAAgIgEgKQgHgNgJgCQgLgDgLAAQgMABgEAEQgEAJgCADQgCABgFABIgMgBQgJgBgGAIQAAAGgGAJQADAJgIAHQgFAFAHADQAGACgDAHQgDAHgKAIIgPADQgFAAgGgFQgGgGgFAEIgIAMQgIALgDACQgGAGgDgGQgJgPgLAIIgOAIQgKAGgHAKQgIADABAEIACAEQgFAGgEABIgLAAQgLAAgFgBQgIgDgDgKIACgVQAAgLgCgLQgCgPgEgGQgEgHAAAJQAAAIgRACQgOACAEARQgKAEgEAFQgEAEgDALIAAAPQABAMgEAFQgCADgLABQgJABgBAEQgDAIABAIQACAKAFAFIgJAQQgBAGAMAOIAJAbIgDAbQgEAAgEADIgGAGQgHgFgEACQgEABgEAHQgEAFgCAHQgDAJgEADQgFAEgKgBQgGAAgBgCQAAgCgIAAIgIABIgNgBQgVADgFAAQgGgBgPgHQgMgGgFABQgJABgHALQgJAMAAAPIAAApIABAUQAAAHgGADQgDABgKgDQgMgEgGABQgOgDgCAKQgDANgBABQgFADgIgCIgJgCQgCABABAGQACAFAFAAIgHAAQgFAAACgDQAAgBAAgBQABgBAAAAQgBgBAAAAQAAgBgBAAQgEgBAGgVQABgEgHAEQgLAHgEABQgHACgEAFIgIARQgFAMgEgDQgCgBgFgIQgDgEgCAAIgIADQgFACgBgCQgEgGgHgDQgKgFAAAGQAAAEADAKQACALgUgBQgHgBAAADIACAEQACADgEACIgJAGQgGAEgFAJQgFAKgCAIQgBAGgEAAQgGgBgCABQgFAEgFAFQgFAGACACQABADgBADQAAABAAAAQgBABAAAAQgBABAAAAQgBAAAAAAIgKAFIgEAFIgLAOIgEAHIgEAGIgEAGIACAFIACAGQABAGADAFQACAFgFANQgDAGgEgHIgIgKQgGgEACAlQACATgTgEQgEAAgJACQgJACgGAAQgLgBgHAEQgEABgDgEQgEgEgBgJQgCgHgIgEIgRgHIgEABIABgBIgTgHQgCgBgIgPQgHgKgGgCQgJgCgIABQgGACgIgDQgOgEgLgIQgNgIgCgDQgBgCADgDIAEgEQAEgDABgDIAEgQQADgNAEgGQAFgLALgNQAHgIABgIQABgDgDgDIgFgEQgGgGgCgKQgDgUgCAAIgDAAIgIAAQgEAAgEAFQgEAEgEAAIgJAAQgFABgCACQgCACAAAFQgBAKgIgDQgGgBgMAXIgNAZQgDAGgCAQQgDAPABAJIABANQAAAGgEAEQgDAFAAAFIADAOQADAJgFALQgFALgFACIgGACIgBAFQgCAGgSgFQgFgCgjARQgLAFgTABIgYABQgGABgFAEIgEAEIAAABQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAAAABIgCABIgDAAQgEAAgGgDg");
          }, this.shape.setTransform(.0118, .0286), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.neimenggu, new cjs.Rectangle(-122.5, -102.3, 245.1, 204.7), null), (g.liaoning = function (A, g, Q) {
          var _this17 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.shape.setTransform(.01, .0139), this.change = function (A) {
            _this17.shape.graphics.c().f(A).s().p("AhGE7QgFgCACgFIgBgFQgBgDABgCQABAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAIgDgBQAAAAAAAAQgBAAAAAAQAAAAgBgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQABgBAAAAQABgBAFAAQAGgBACgBIAGgDQACgCgBgDIgBgEIACgDQACgCAGAEQADACAJgGQADgCADgGQACgFgBgCQgBgCgEAAQgBAAAAAAQgBAAgBAAQAAAAAAgBQgBAAAAAAQABgFADAAIADgBQAAAAAAgBQAAAAAAAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAABAAQABAAAAAAQAIABACgGIAAgGQABgCAHAAQAEAAAGgFQAEgEgGACQgNAHgEgDQgDgDgBAFQgCAEgIABQgHABgDgEQgDACgDAAIgMgCQgBAAAAAAQAAAAgBAAQAAAAAAgBQAAAAAAgBIAAgCQgBgBAHgEIAIgEQABgBgGAAQgIAAgDgBQAAAAAAgBQAAAAAAAAQgBgBABgBQAAAAAAgBIABgEQgBgDAKgEIAMgFQACgCgGgGQgCgCAAgFQAAgFADgFQADgDAFgCIAGgEQACgCADAAIADgCQAIgIgCgBQgDgEAFgCIADgGIAEgFQADgCAAgFQAAAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAAAIAEgCQACgBABgEQABgEgBgCQgBgCAFgJQAJgNgCgGQgBgCgGgGIgFgHIgBgGQAAgBAAgBQAAAAAAAAQgBAAAAAAQgBAAgBAAQgCACgHgGIgGgFQgCgCABgGQABgFgFgIIgHgJQAAAAgBgBQAAgBAAAAQgBAAAAgBQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAABAAABQAAAAAAABIABAFQAAABgBAAQAAAAAAgBQgBAAAAgBQgBAAAAgBQgBgBAAgBQAAAAgBgBQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAAAAAABQgBAAAAAAQAAABgBAAQgCAFAEAEQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAABAAAAQgBAAAAABQgBAAgBAAIgEAFIgDgBIgBgCQABgBAAAAQAAAAAAgBQgBAAAAAAQAAAAAAAAIgCACQAAABgBAAQAAABAAAAQgBAAgBAAQgBAAgBgBQgDgBgCACQgBABgEAAQgGAAgDgDQgGgFAAABQABAGgDAAIgEAAQgBAAAAgBQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBgBAAQAAAAAAABQAAAAgBAAQAAAAAAABQAAABgBAAQgEAIgEACQgDACgDADQgCAEgIAEQgEACAHADQAFACAAACIgEACIgFADQgEACgCAEQgCAHgJAKIgHAJIgDAGQgDAEAEgBIAEAAQABAAAAABQAAAAgBAAQAAAAgBABQAAABgBAAQgHAGAAAEQAAAJgHACQgMADgFAFIgHAHQgFAFgEABQgJADgBADQgDAHgEACQgHgGgEgMQgEgKgEgCQgEgBgHgVQgHgTgJADQgMAAgGgDQgGgDgFgIQgBgCgEABIgHAAQgUgIADgPQABgEAEgEIAFgGIgCgJQgBgFAHgBIAMgPQAGgKgHAAIAMgQQACgGgBgJQAAgHgDgFQgDgFACgXIABgLIgBgLIAAgJIgGgKQgEgHABgCIAEgEQAMgOAFgBQAFgBACADIAEAHQAFAFANAEQAGAEgBACQgBAFACADIAKATIAJATQADAFAFgIIAPgWQAEgDALgRIALgLQAJgIAGgBQADgBAFgEQAFgEAGAAQAHgBAFgGIAJgLIALgIQAHgFAGAAIAJgBQADgBAFgDQAEgDAFgJQAGgJAGgEQAJgGAFAAIAOgBQAJgBgCgDIgDgLQgBgHAKABIAUAFQANACAKgDQAHgCAJgGQAEgBACgJIADgLQAEgJAJgBQAGgBADADQAEABABgDIAEgRQABgZABgKQABgGAEgBIAEABIAHAGQAIAHAIAEQAHAEAJADQAHADAEAHIAIAOQAEAGgBAHQAAAIALgLQAIgJALgPQAHgJAEAQIAEAYQACAEAFAFIAKAMQAJAKAHAWQADAFAUAPQAEAEABADIAAANIgDAZQgBAIADAFQACAEAHAGQAFAEAEAJIAGANIAKAMQAIAIACAGQAEAHAAAFQgBAFgDAKQgFANAIACIAFAHQABAHgDABIgCAAQAAAAgBAAQAAAAgBAAQAAAAgBABQAAAAgBAAIgMAPIgGADQgGACgEAEQgBABgGACQgFABgCAEQgIANgCABIgKAGIgGAEIgCAFQgCAJgEACQgJAHgCAFIgCAFQgJAIgCAAQAAAAAAABQAAAAAAAAQgBAAAAABQAAABAAAAIABAHQACADgCACIgGAFQgDADgBACIgBAFQgCAEgDADQgJAIgIgEQgHgEgEAEQgGAFgGgCQgGgGgCACIgCAGQgCAFgDAAIgFABIgCAEQgDAGgCgFQgCgEgDACIgEAAQgBAAgBAAQAAAAgBAAQAAAAgBABQAAAAgBAAIgEAFQAAAAAAABQAAAAAAAAQgBAAABABQAAAAAAAAIADAAQAAAAABAAQAAABABAAQAAAAAAAAQAAABAAAAQABABgBAAQAAABAAAAQAAABAAAAQgBAAAAAAIgDABIgFAEQgCACgFgCQgCgCgEACQgFABABADQAAADgBACQgCACgDAAIgFAAQgCAAgCAEIgIAIQgBABgBABQAAABgBAAQgBAAAAAAQAAgBAAAAQgBgHgEALQgBADgCACQgBAAAAAAQAAABgBAAQAAAAAAABQAAAAgBABIgCAEIgEAAQgGgBgFAIQgHAJAAAEQgBAEgHACIgEAEIgDAFQAAAAAAABQAAAAAAAAQAAABAAAAQABAAAAAAIADgBQAGgCgGAGQgEAEgCgCQAAAAgBAAQAAAAAAgBQgBAAAAABQAAAAAAAAIABADQAEAGgFAAQgBAAAAAAQgBAAgBABQAAAAAAABQgBAAAAABQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAIgDAAIgEgCQAAAAAAABQAAAAAAAAQAAAAAAABQABAAAAABQAIAHgFABQgEABgHgJIgEgDQAAAAAAAAQgBAAAAAAQAAABAAAAQAAABAAAAQABAEgGAAQgCAAgEACQgEADAEADIAGABQAEABACAEQACAEgKAAIgFAAQgDAAgBADQgBAGgIgBQgHAAgDADQgCADgEAAQgFAAAAAEQgBAGgCAAIgCgBg");
          }, this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.liaoning, new cjs.Rectangle(-31.8, -31.5, 63.7, 63.1), null), (g.jilin = function (A, g, Q) {
          var _this18 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this18.shape.graphics.c().f(A).s().p("AgDFFQgJgCAFgNQAEgJAAgFQAAgFgDgIQgCgFgIgIIgKgMIgGgOQgEgIgGgFQgHgGgCgEQgCgEAAgIIADgaIABgMQgBgDgFgEQgUgQgDgFQgHgVgIgLIgLgLQgFgFgBgFIgFgYQgDgQgHAKQgLAOgJAJQgLALABgHQAAgHgDgHIgIgOQgEgHgHgDQgKgDgGgDQgIgEgJgHIgGgHIgEAAQgFAAAAAGIgBADQgEgDgMgDIgPgFQgDgCAEgEQAHgGACgEQADgGgHgNIgMgUQgDgHgNgXQgIgSgIgLQgFgHgDgBQgDAAgFAFIgPAQQgNAPgGAFQgHAGgKgEQgJgFgBgHQAAgFgHgKQgHgKgBgFQgLgfAAgJQAFgkAAgKQAAgGgIgKIgLgRQgDgIgGgEIgLgGQgEgBgFAAQAAAAgBgBQAAAAgBAAQAAgBAAAAQAAgBgBgBQgCgLAFgQQACgGAIACIAOAHQAPAIAIAAQAEAAADgFQAEgEABAAQACAAAFAEQAFAGAIAEQAJAEgCgNQgDgQAAgDQACgJAKgHQADgDAFgGQAFgIAFgFQAGgGAGACIAMADQAGAAAKgEQALgEAJgBQAMgCAEAHIAGATQAJAWgCAOQgBAFACADQADADAIAGIASAKQAHAEAAADQABABAAAAQAAABABABQAAAAAAAAQABABAAAAQAFADAXgHQAEgBACgDQACgFAEgEQAFgFAEAEIAIALQAFAFAIgBQAGgCADgDQADgDAFgDQAKgKAGgBQAFgBABACQABACAAAFQgBADADAEIAEAIQAEAHAOAFQAMAEAJgBQAHAAAEgDIAGgGIAHgFIAJgDIAHgBIAGAFIAHAEIAGAAIAJgBQACABADAEIAEAIQACACAAAEIAAAFIgCAEIgCAHQgBAEAFAHIAHAMQADAEADgCIAHgGQAHgDALACQAIADAAADQAAAGADAHQADAHAGAGQAFAFABAFQABAGAEADQAEADADgBQACAAAIAHQAIAFAGgJQAFgJAAgIQABgKABgDQADgHABgEQABgIALgFQAKgEACAIQAFAbAGAKIARAbQAGADAGAKIALAUQAIAMAFgDIAOgGQAIgFgBgHQgCgKABgFQACgGAJgHQAGgFAJgEQAHgDADgDIAHgHQACgDABgDQAAgFAGgBQAGgBADAGQAMAVAFgQQADgNADgCQAEgCAEALIABAIQABAFAEABQAFABADAHIAEAJQADAEAEAAQAEgBACADIAFAFQAGAEAEAAIAEABQABAAAAAAQABAAAAAAQAAABAAAAQABABAAABIACAFQACAAACgDIADgEQAKgIAEAEQAEADAHgCQAGgCABgDIACACQADAEgBAEQAAAGABADIgBAEIgCAFQgCAEACADQACACgBAGQAAAFgDACQgGAGADAEQADAEABAEQACAFgFgCQgFgCgBABQAAABgBAAQAAAAAAABQABAAAAAAQAAAAABABIADADQABADgFABIgFABIgBABQgCADgDgDQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAABQAAAAgBAAQAAABAAAAQAAABAAAAQABAFgFAAQgKABgCACIgHAIQgEACgBADIgCADQAAAAABAAQAAABAAAAQAAAAABAAQAAABABAAQAGACADgFQADgEADAJQAHANgCABQgEACAGAGQACACABADQAAAAAAAAQAAABgBAAQAAABAAAAQgBAAAAABQgBAAAAAAQgBAAAAABQgBAAAAgBQgBAAAAAAQgHgHgBgFIgDgDQAAgBAAAAQgBAAAAAAQAAAAgBABQAAAAAAABQAAABAAAAQAAABAAAAQAAABgBAAQAAABgBAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAAAQAAgBAAAAQgBAAAAgBQABAAgBgBQAAAAAAAAQAAgBgBAAQgBAAgBABIgEgEIgEgGQgJgGADgIQACgJgFgCIgJABQgGAAABgDQABgGgGACQgFABgCgDQAAAAAAgBQgBAAAAAAQgBAAgBAAQAAAAgBABIgEABIgBADIgBAEQgDAEACACQACADgCAGIAAAHIABAHQACACAAAEQAAAFgCADQgCADABAGQABAEABACQACACgCAEQgBAEgEAAQgGgBAAAFQABAGgDABQgCAAgJgGQgIgBgCADQgBADgDADIgDAHQgCAFABADQACAEgDAFQgCAGgDACQgHAEABAEIgBAKQgCAGgWgCQgDAAgGADIgHADQABABgQAFQgKACgLgBQgHAAgBACIgBADQAAABAEACQACABABAEQACAGABAIQAAADAEAEIACADIADACIAGABQADABACADQACAGADACQACAEgDAFQgDAFAAADIgBAGIgEAFQgHADgFgFIgGgBQgGgBgBACQgDAFgGAAIgLACQgCABgEAAQgEgBgCgCIgCgEQAAAAgBAAQAAgBgBAAQAAAAgBABQAAAAgBAAQgGAFgEgBIgGAAQgEAAgCgCQgEgFgFABQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAgBAAgBQAAAAAAAAQAAgBAAAAQABgBAAAAQABAAAAAAQAAgBAAAAQAAgBAAAAQAAgBgBgBQAAAAAAgBQgBAAAAAAQgBAAAAAAQgBAAgBAAQgCAAgEgDQgDgEABgCQACgFgGAAIgGgCQgFgCgBADQAAAJgHgBIgGAAQAAAAAAAAQgBAAAAABQAAAAAAABQgBAAAAABIgBADIgEACQgGAFADAGQACAFgDAEIgCAFIAAAEIgBAEQAAAAAAABQABAAAAABQAAAAABABQAAAAABABQAAABABAAQAAABAAAAQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAgBAAQgDAAgCABQgBAAAAABQgBAAAAABQAAAAgBAAQAAABAAABQABACgFAJIgEALQgBADgEAFIgGAHQAAAAgBAAQAAABAAABQAAAAAAABQgBAAAAABQAAABAAABQAAAAAAABQAAABAAAAQAAAAgBABQgDACAAAHQABAIgJgCQgIgCgCAFQgBADgJABIgFADg");
          }, this.shape.setTransform(.0048, .0368), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.jilin, new cjs.Rectangle(-44.5, -32.8, 89, 65.69999999999999), null), (g.jiangxi = function (A, g, Q) {
          var _this19 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this19.shape.graphics.c().f(A).s().p("AilFkQgJgFgBgHQANgJABgLQABgOALgKQAGgFAOgIQAEgEABgFQABgGgFgEQgDgKgJgGQgGgEgJAHQgMAIgGgBQgHgBgGACIgOADQgCgOgOgLIACgBQABgLgEgLQgDgHAHgNQAJgQAAgEQAAgHAFgGIALgJQAHgGgEgBQgFgCgNADQgLADACgJQAFgQABgLIACgPIgNgFQgLgEgDgHQgCgGADgJQADgIgBgFQgBgEgGgKQgFgJABgFIAGgPQAGgSgUAJQgIADgDgDQgCgDgCgKQgCgKABgGQABgHAHgKQAGgJAAgGIAAgKQAAgGAHgEIAQgGQAIgDAAgGIgCgJQgBgDAHgGIAPgMQAGgHgDgGQgBgDgKgKQgFgFABgDQABgEAAgFQAAgNgMgOIgLgLQADgQAIgJIAHgHQAGgBAGgKQAFgHAXAFQAEgEAIgBQALgBADgCQAIgEAOgWQAIgCAGACQAEACACgBQACgDgFgEQgEgEAEgDQAYAAAEgEQAFgHAJgFQAIgGAHgBQAFAAASADQAQABAEgHIABgFQAJABALgFQASgHAbgXIAOAIQAHAEgBAEQgBADgHAJQgHAJgCAFIgEALQgCAEAFADIAIADQAFAEAFgDIAIgIQALgOAGgEQACgCgCgGQgCgHACgDQADgFAFgCQAFgDABAFIABAHQACADAGAAQAHAAADABQADACAFAJQAGAJACACQADACAKACQAGABARgCQANgBAEAEIAKALQAEAGAFAAIAGgBIgKAPQgIAUANATQAYAUADAEQAIAKAAARIADAHQAEAFgBAKQgBAMgIAGQgEADAGAKQAEALgKADIggAPQgNAEgCACQgKALgEABQgFADgGgHIgJgKQgDgDgGAGIgPAMIgGAJIgGAMQgCAEgJAEQgIAEgBACQgBAFALAKQAJAIgEAUQgDATgOALIgcAPQgNAHAAANQgEAQAGANQAHANgEALQgIgCgCAEQgBAFgCACQgJAHAAAGQAAADAJADQAHACgCAEQgDAFgHAHIgMALQgRADADAPQAEADgIAPQgJASADAQIgMAWQgGAQAIAUQAAAAAAABQABAAAAABQAAAAABAAQAAAAABABQgRgCgBATIADAdQgEAEgLgHQgMgGgGgNQgFgJgLAHQgSALgJABQgdAOgoAIIgHABQgHAAgGgDg");
          }, this.shape.setTransform(.021, -.0083), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.jiangxi, new cjs.Rectangle(-26.4, -35.9, 52.9, 71.8), null), (g.jiangsu = function (A, g, Q) {
          var _this20 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this20.shape.graphics.f(A).s().p("AClEKQgCgBgBgFQAAgBAAgBQgBgBAAAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQAAAAgBgBQgBAAAAAAQgBAAgBAAIgDgBIgEgEQgKADgGgCQgNgEgEgEQgGgGAAgEQgBgIgHgBIgKAAIgJACQgKACgCAHIgBAIIgBAAIAAgJQgCgCgGgBQgUgBACgKQABgEgKABQgJABgFACQgGAEgNACQgRADgDgFIgFgHQAAgCAGgGQAIgGABgMQABgLgGgCIgHgEQgCgCgEACQgEACgDgBQAAAAgBAAQAAgBgBAAQAAgBAAgBQAAAAABgBQABgEgEgDQgEgCgHAAQgHABgIgNQgIgNADgGIAGgNQAEgHAGgCQAHgCAEgLQAFgLgEgFIgLgMQgGgIAGgCQAWgFALAGIARAJQAIADABgLQACgQgEgMQgEgQgNgFQgSgHgEAEQgCACgEASQgEATgagJQgOgFgBgCQABgFgCgLQgDgOgEgFQgEgDgJgCQgJAAgDgEQgDgDgDgJQgCgGAIgSQAIgUAAgIQAAgLgGAAIgUAFQgNADgEgFIgGgSQgEgMgRgCIgbgBQgZgCgBgUQgBgPgUgDQgEgBgIgGIgUgOQgHgEgGgBQgCgNABgFQAAgGAEgEQADgDAHgEQAGgDAKgBIAOgCQALgCAJAUQARAlADAAQAGABAEgEQACgDABgFQABgDAFABQADAAAIAHQAGAGAEgCIAHgGQAEgDADgBQADgBABgGQABgFAEgCQAHgCAIgBQAKgCABADQAAAFAFAFIACACIACAIQABAIACACQACADAHgEQALgHACgLQAGgXAMABQAJAAADgBQAEgBgCgEQgDgJAHgFIADgEIABgHIgBgJQABgFAGgBIAKABQADAAAFgDIANgHIAAABIgBAIIABAKQgDAHAEAEIAJAHIACABIACgDQACgDADADQAEADAEAAQAEAAgBAEQgBAEAEACIAKAFQAFADAAACQAAABAAAAQgBAAAAABQAAAAgBABQAAAAgBABIgFACIgDADQAAAAAAAAQAAABABAAQAAAAAAAAQABAAAAAAQAEABACgDQADgEAEgBQAGgCADADIADACQAAABAAAAQABABAAAAQABAAAAAAQABAAAAgBQADgBAEACIAIACQADAAAEADQAFAEAFAAIAIADQAIACACAGIAEANIADAKIAEAHIAEAGQACACABAEIADAGIADAFIABADQgBACAAABQgBABAAAAQAAABAAAAQABAAAAAAQABgBABAAQABAAAAAAQAAAAABABQAAAAAAABQAAAFACACQAEAFgBACQgCAFACABQAGAEACAHIAHAZQABAFADgBQADAAACACQAEAFgBADQgCAEACACIAGAHQAAABAAAAQAAAAAAABQAAAAAAABQAAAAgBABQAAAEAFgBQAEAAACACQABABAAAFQAAAEADADQADADAAAEQAAAFgEAAQgCAAAAADQAAABAAABQAAABAAAAQAAABABAAQAAAAAAABQADABAAADIACAGQAAABABABQAAABAAABQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAABQAAAAAAAAQAAABAAABIAAACQAAABAAAAQAAAAAAAAQABABAAAAQAAAAABAAQAFgBAEADIADAEQAAAAAAABQABAAAAAAQABAAAAABQABAAABAAQADgBAKACIAVAHIADACQABAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAKABACIgBAGQgCACABADQABAAABABQAAAAABAAQAAAAABAAQAAAAABAAQAAgBAAAAQABAAAAAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAAAABQAAAAAAAAQACAGADAAQAJgBAJAEQAHACAIAFQAGAEABAEQABAFACACQAFAEAAAFQAAAHABABQADAEgBACQgEAFgHgCIgLgDQgNgHgCAAQgEAAgGgDIgKgEIgIgBQgEAAgEACIgGAEQAAAAAAAAQgBAAAAAAQgBABAAAAQgBABgBAAQgDAEgDgBIgDgDQgBAAAAAAQgBgBAAAAQgBAAAAAAQgBAAAAABQgIAEAAgFIABgFQAAgCgEgCQgIgHgEgBIgHgEIgIgDIgFgBQgLgBgDABQgHAFgGAIIgHAHQgBABAHgCIAHgBQAEgBAAgDQABgGADABIAOABQALgDADAEIAHAMQADAEgFAAIgDABQAAABAAAAQAAAAABABQAAAAAAAAQABAAAAABQAEABAEADQACACAHgBQAGgBALAFIAQALQAFADABAFQABAGAGACIgLAFQgOAIAFAKQABACgEAEQgEAEABADQABAKgGACIgMAFQgBACAAAHQABAHgBABQgJAAgEACQgEADACAEIACAHQgCADgFACIgFACQgJAIgBAAIgBAAg");
          }, this.shape.setTransform(.0175, .0263), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.jiangsu, new cjs.Rectangle(-30.2, -26.6, 60.5, 53.3), null), (g.hunan = function (A, g, Q) {
          var _this21 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this21.shape.graphics.f(A).s().p("AAAFYQgFgDABgGIABgNIAAgSQAAgLgFgEQgDgCgEACIgHAFQgBgBAAAAQAAAAAAgBQgBAAAAgBQAAgBAAAAQAAgBAAgBQgBAAAAgBQAAAAgBAAQAAAAgBAAQgJABgGAMQgDAHgKAFQgJAGADgOIADgSQABgDAEgBQAEAAACgDIAEgIIANgTQAJgOAAgHIgBgPQABgFAFgCQAIgCADgHQADgHgIgBIgOADQgHABAAgIQgCgRAFgNQAGgQgVgDIgLgCIgEgFQAAgBgBAAQgBgBAAAAQgBAAAAAAQAAAAgBAAQgBABgDAGQgDAFgIACQgHACgDgEQgEgFgGAAQgIABgFAIQgDAFgJAJQgHAHgBAEQgCAHgEADQgEADgEgGQgDgGgDAAQgCAAgEADQgEADgCgGQgBgGABgEQACgEgKgCQgJgCgBAGQgDAQgGAAQgHAAAEAJIACAHQAAADgFAAQgHAAgDgDQgDgCAEgEQADgEgFgDQgFgEgGACQgFACgFAAIgFgBIAAAAIABgBQAAgFABgBQAFgDgDgDQgGgGAAgJQAAgEgFgBQgJAAgBgBQgHgDAQgXQAFgIgKgJQgEgEABgCQABgDAEAAQADAAADgDQADgDAEgBQAFAAAAgFQAAgFgDgEQgDgHAJgCQADgBgDgFIgFgKQgEgJgMgCQgIgBgMAIQgEADgCgBQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBAAgBQAAgCgIAFQgJAGgFABQgGAAgCgDQgCgDADgCQAHgDAAgIQABgEADgDIAIgFQAGgEAGgLQAEgIAIADQAIACABgHQAAgEAOgIQAFgDgEgHQgCgGgEgDQgEgCgDgMQgFgNADgGQADgFgCgCIgFgDQgCgEAIgOQADgDgCgDQgBgBgGgDQgDgBgBgEIAAgHIABgPIgEgCIAAgCIACgGIACgIQAAgCgGAAQgBgBAAAAQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAgCAEgDQADgCgDgDQgBgCABgGIAGgcQAAgDgGgGQgBAAAEgFQAEgFgBgBIADgHQABgEADgDQAIgIAAgMQABgKAHgFQALgGAIAAQALgNAJgEQAHgEAKAAQAPAAAHAEIAJAJQAFAFABAAQACAAAMgHQAPgIABgEQgKgOgEgJQgGgMAJgBIAMAAQAIABAFgDQALgHANAFQAHADARAKQALAFANACIAfACQARACAOANQAIAHAKANQAFAGAMgBIAQgBQAHABASgDIASgWQAGgHADAGQADAFgBANIAAANIAJAHQAHAFAIgHIAMgSQAJgNANgOIAUAWQAGAIgDAOIgHAYQgCAJAMAMIARANQAJAGAJAKQAMAOAAANQAAAFgCAEQAAADAFAFQAJAKABADQAEAGgHAHIgOAMQgHAGAAADIADAJQAAAGgIADIgRAGQgHAEAAAGIABAKQgBAGgFAJQgHAKgBAHQgCAGACAKQADALACADQADACAIgCQAKgFADACQAEACgDAJIgGAPQgCAFAFAJQAHAKABAEQABAFgDAIQgDAJACAGQACAHAMAEIAMAFIgBAPQgBALgGAQQgCAJALgDQAOgDAEACQAEABgGAGIgMAJQgEAGgBAHQAAAEgIAQQgIANADAHQAFALgCAKIgNAQQgHAFgRAAQgNAAgFgBQgGgCgIgIQgHgHgEAAQgDAAgDAEQgHAHgSAKQgJAFADAEIAKAIQAEAFgBAHIgDARQgCALgNgFQgNgFgCgKQgBgJgMgCIgdgDQgOgBgEAHQgCAEgBALIgKAcQgBACgFAEIgCgEIgMAAIgQgBQgHAAgEAFIgHAKQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAIgEgBg");
          }, this.shape.setTransform(.0148, -.0087), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.hunan, new cjs.Rectangle(-30.2, -34.5, 60.5, 69), null), (g.hubei = function (A, g, Q) {
          var _this22 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this22.shape.graphics.f(A).s().p("ACeDnIAHgYQAEgOgHgIIgTgWQgNAPgJANIgNARQgHAIgHgGIgJgGIAAgNQABgNgDgGQgEgGgFAHIgTAWQgRADgIgBIgQACQgLABgFgGQgJgNgIgHQgOgOgSgBIgfgDQgNgBgMgGQgQgKgHgDQgMgFgMAHQgGAGgPgCQgLgBAEAMIAGALIAHANQAAACgGAEIgJAGQgIAFgEABQgEAAgFgEIgJgKQgHgEgOABQgOAAgEACQgJAEgKAPQgHgCgGAEIgJAGQgFAFgBAEQgBADABAHQABADgFAFQgFAHgCAEQgEANgGAHIgHgFQgEgDgBgEIgBgMQgBgNgOAIQgEADgBgCQgBgCAAgGQAAgEgDgDQgDgEAAgHQAAgIgDgDIgHgGIgHgGIgGgKQgJgRgFANQgEAKgGgCQgDgBgDgJQgDgIAHABQAIABABgEIADgJQACgEgCgFQgBgFADgEQAHgKgLgOIgFgIIgCgKQgBgGAJgBQAKgCACgBQAEgFACAAQADgBABAHQACAGAIgDQAGgDAIgIQAHgHAGAAQAFAAgBAGQAAAFACABQACABAGAAIAJgGQAGgEACAJQACAIACgDIAHgKIAMgIQAIgGAIgJQAPgQASAKQAGADACgDIAFgHQADgDABgFIgBgLQgCgKAEgFQAEgGgDgQQgBgGgHgEIgLgIQgDgDgHgCIgMgCQgFgCAAgEIABgKQAAgFgHgEIgHgEIAAgHIgBgPQgBgEgFgIQgCgDABgEIAEgIQACgFgEgGIgIgJQgCgEgBgGQAAgFACgEQACgEAIgFQADgDAAgKQgBgFAJACIAdAIQAFABACAAIAEgCIAIgEQAEAAAAgEQAAgGgEgHQgEgKgGgJQgBgCgFgBQgEgBgDADIgGACQgBAAAAAAQgBAAgBAAQAAAAgBgBQAAAAgBgBIgDgFQgCgCABgEIAAgIQAAgGgIgDIgYgHQgFgBAHgFIADgCIADgCQAFgDANABIAUABQAGAAAMAGQAKAFAJAAQAMAAAIgDIAHgFQABgBAAAAQABAAAAABQABAAAAAAQABABAAAAQACACABADQAAAEAHAFQADACAEgDIAHgEIAKgFQAFAAACgEIADgFIABAAIABAFQADAFADACQAGAEAIAMQADADACAIQACAHAEAEQAEAEAIACQAHABACADQACAEADALQADAHAFAAQAFgBADACIAOAIIAhATQAKAFAGAAIASgDQARgDARADQAFABAFgCIAIgFQAOgFADADIAHABQAFgBAHAGIAJAJQACABAIgFIANgJIAEgFQAAgBABAAQABgBAAAAQABAAAAAAQABAAAAABQACACAEALQADAMAAAFQgEAJACAGIAGAMQAHALACABIAEAAQABAAABgBQAAAAABAAQAAAAABABQAAAAABAAQABABACAHQABAFACABQACAAAGgHQAFgGACAAQADABAIAFQAIAFADABQADAAAHgCQAGgBAGACQABABgBAIQgCAIABABIAZANQAQAGALgKIAEgIQADgGAEACQADABABAHQABAHACADIAVASQANAKADAGQABAAAAAAQAAAAABgBQAAAAAAgBQABAAAAgBQACgEADABIAJAFQAGAFADgBQAKgBAHAIIANANQAAACgGACQgKACgDACQgDAEAAAEIgCAMQAAAAgBAAQAAAAAAABQgBAAgBAAQAAAAgBAAQgBAAgBABQgBAAAAAAQgBAAAAABQAAAAAAABQAAAFAFAHIAJANQABADAAAHIABAKQABAEAJAGQAHAFACALQAAAHAEAQQAEANgDAGQgGAMgagJIgMABQgMACgEAFQgDAFgNAEQgMAFgEAFIgIAMQgFAGgKACQgIABgNAIQgSAKgLAFQgMAEgOADQgJACgFAEQgDACgWAYQgdgTACgPg");
          }, this.shape.setTransform(.0264, .025), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.hubei, new cjs.Rectangle(-41.6, -26.5, 83.30000000000001, 53.1), null), (g.henan = function (A, g, Q) {
          var _this23 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this23.shape.graphics.f(A).s().p("ADAEwQgCgEgBgHQAAgGgEgBQgDgCgDAGIgFAIQgNAIgRgHQgPgFgHgFQgBgBACgJQABgHgBgBQgCgBgIABQgIABgFgBQgFgBgGgEIgIgGQgCAAgGAHQgGAGgDgBQgCgIgCgEQgDgDgIACQgDgCgGgLQgFgIAAgEQgDgFAEgJQAAgFgDgMQgDgMgCgCQgBAAgBAAQAAAAgBAAQAAAAgBAAQAAABgBAAIgDAGIgOAJQgHAEgCgBIgJgIQgHgGgFABIgHgBQgDgDgOAFIgIAEQgEADgGgCQgRgDgQADIgSAEQgIgBgJgEIgigUIgOgIQgDgBgFAAQgFABgDgHQgDgMgCgDQgCgDgHgCQgIgBgEgEQgEgEgCgIQgCgHgCgDQgJgMgGgEQgDgCgDgFIgBgGIgBAAIAEgJQADgKgFgOQgCgIgKgJQgFgEgFgMQgCgDgFgDIgJgHQgFgFAFgHQACgDgGgGQgBgBAAAAQAAgBAAAAQgBgBAAAAQAAAAAAgBQABgBADgCQAGgFgHgEIgNgHQgEgEABgDIAFgHQABgDgLgMIAxgbQAcgRAWgEQAJgCAPgMIAVgQQAZgPAEgMQACgFAbACIAnACQANAAAPgNIAagXQANgGAFgPIAGgbIAHgfQADgTgCgLQgDgKAjAQIAXAEQAUAEALAGQAbgBANAEQAEABAEgDIAKgJIABgCIACgBIAEAGQABACAEAAQAFAAADgBIAIgFQACABgCAFQgCAFAAACQABACgCAHQgCAKgBAIIAAAGQAAAOANgJIAUgVIAMgNQAFgEALgBQAJgCgRAPIgdAaIgKAMIgLANIgRANQgIAHgEAFQgUAcgBAPQgCAGAJAEQAIADANgBQADABAEAFIAFAHQACACAJACQAHACACACQABACADALQACAKAGADQAKAEAFgCQAFgEACAAQAUAAAMgFQABgBAKAGIgBAEQgBAGABADIAAABIABABIAIAJQAFAHAFABIAKAEQADABADgBQAGgBACADQACACgBAIQAAAHABAEIAFAJIADAIQgBACgIAIQgHAHgMAHIgMAHQgHAIgJgNIgIgLQgDgGAAgEQgBgGgFgDQgHgEgEAHQgCACgFgDQgEgDgCAAQgFADgGAGQgGAIADAEIAEAJQACAEgDAFQgBAAAGANQADAJgOACQgYAEAGAVQADAJgBAJQgBAOgKADIgPAFQgFAAgDgCQgEgFgCABQgDAAABAHIAAAMQAAAFAIACIARAFQAGADAAAHQAAAYAOAEIANAEQAHABACACQAHAEAKgDQAFgCABACIAEgEIAMgLQADgCgDAOIABALIADAOIADAMQAGAngCAHQgEAIgCACQgCABgLABQgMACgNAQQgMAPABAJIABAKIAGAGQgSgIgFgGg");
          }, this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.henan, new cjs.Rectangle(-31.8, -31.8, 63.6, 63.7), null), (g.heilongjiang = function (A, g, Q) {
          var _this24 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this24.shape.graphics.f(A).s().p("ADLI8IgLgUQgGgLgGgDQgCgBgOgZQgHgNgFgYQgCgJgKAFQgKAFgCAHQgBAGgDAFQgBAEgBAKQAAAIgFAIQgGAKgIgGQgIgHgCABQgDABgEgDQgEgDgBgHQgBgFgFgEQgGgGgDgHQgDgHAAgGQAAgEgIgCQgLgDgHAEIgHAFQgDADgDgFIgHgLQgFgHABgEIACgHIACgFQABgHgDgDQgGgMgDgBIgCAAIgGABIgGAAIgHgEIgHgFIgHAAQgGABgDADIgHAEIgGAGQgEADgHABQgJAAgMgEQgOgEgDgIIgFgHQgCgEAAgEQAAgIgHAAQgHACgJAKQgFACgDAEQgCADgHABQgIACgFgFIgIgLQgEgEgFAFIgGAJQgCACgEACQgXAGgFgDIgCgDQgBgEgHgDIgSgKQgJgGgCgDQgCgDABgFQACgOgJgWQgCgVgCgDQgDgJgMACQgJABgNAGQgLAFgGAAQgPAAgJgCQgOgOgBgDQgDgOAFgHQADgEAFAAQAGAAACgDQADgDAKgGQAMgFACgDIAFgGIAAgGQgBgDgFABIgEACQgCgCABgGQABgIgHABQgGABgBAFIgBAGQgBADgEAAQgFAAgEAFQgDAHgDADQgDAEgHgBQgGgBgFgCQgEgCAAgCIABgGIABgGQAAgBAAAAQAAAAAAgBQgBAAAAgBQAAgBAAAAQgFgCgBgDIAAgIQAAgEgEgCIgKgFIgLgIQgHgFgEgIQgCgRARgTQAPgPAUgKQAKgIAEgSQAEgFAJgHIAMgJQAEgEAIgUQAHgTAMgJQAJgOAKAUIAPAhQAGAHACgMQACgMgEgNQgFgNABgVQACgWAKgVQAAgOABgCQADgHAMACQASAEgDgnQgBgJgHgTQgIgRAAgKQAAgLAHgVIAJgeIAAgJQAAgGACgDQALgFAEgJQAEgIgEgGQgDgQAKgJQAIgUgBgCQgDgFgNgJQgIgHgVgUIgXgXQgFgEgMAAQgLAAABAFQAAAFgDAFQgEAFAAADQAAAFgDAEQgDAFgEAAQgCAAgEAGQgDAFgDgDQgDgDgEABQgFACgCAEQgBAEgGgBIgNgCQgFgBgIAFQgGAEgFgDIgJgDQgDAAgFAHQgEAIgMADQgKADgGgCIgPgDQgKgEgDgIIgNghQgLgZgBgLIgBgPQAAgCADgDQAEgEgDgFQgDgGgGABIgHAAQgFgBgCgBQgJgKgIgFQgOgLgDAPQgCAMgHAHQgJAJgJgLQgHgLgGgCQgIgBgHgDQgMgEgBgBQgDgCAIgLIANgSIAIgSIAIgQQACgHgHgGIgQgRIAUgPQAEgEAKAAQALAAADgGQACgDAEgBQAFgCAEADQADACAGgBIAGgCQAHgFAIADQAEABAFgDIAGgEQAGgFAEABQAFABAFgGQAFgIAGAFQAFAFAEgFQAFgEABADQAAABABAAQAAABABAAQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAgBQABAAAAAAQAAgBAAAAQABgFAGAEIALAEIAFAAQAEAAABAFQACAEAHAAIALgBQALAAADAJQACAFAFACQAEADAGgBIAFgCIAIAFQAHAEADgBQACgBADgGQABgEAEgBIAGgBQADgBAGABQAGABACACIAMAGIAOAEQAMABgFAKQgEAJAJgGQAEgCAEABQADACADAFQAEAIAJgDQABAAAAAAQABAAABAAQAAAAABABQAAAAAAABIAAAFQAAAEgDACQgFACAAADQAAAFAJAAQAIABABAEQABAIAJABQADABACAEQADADgCADQgDAFAFgBQAEgBABADQABADgFACQgFACADADQACAEAFAAQAJAAADAHQACACgCADIgEAGQgCACAEAGIAGAHIAGAIQAFAHACAAQADACADADQAEAEgDAEQgCADACACIAFACQAEABADACQACADgCAEQgDAEACACIAHACQAGACgGAFIgEAFQgBAEADADQAHAFAAgLQABgIAFAGQACADgBAFQgDAIAAAGQABAIAMAJIANAKQABADAHAGQAGAFAAACQAAAEAGAHQAFAIgEAGQgEAHAGAEQAEAEABAIQADAKANABQAEAAABAFQAAAFgCAGQgEAHAFAIQADAHgBAGQgBAEAEAEQADACADABQAGABAAAFQAAAEAEACQAFACACACQACADAEAAQAEAAACgCQAFgFADAEQACADADABQAFABACgCQADgCAIgBQAFgBAIgHQADgCAGAAIAKABQAFgBABACIgBAGQgBAFAMgBQAHgBAGAHQAEAEAFAAQAFgBACgDQAAAAABgBQAAAAABAAQAAgBABAAQAAAAABAAIAFABQADABACgCQAAgBAAAAQABAAAAgBQAAAAAAgBQABgBAAAAQAAgFAFgBQAHgCABANQABAEACACQADACADgCQAGgCACAEQADAGADAAQACgBAGAFQAHAFABAEQADAHAGADIALAEIAGACQAHABADgCQAHgGAFAEQAFADAJgHQADgCACAFQABAFgDAEQgCAEAAADQAAAEgBABQgCACAAAEQAAABAAABQAAABAAAAQAAABABAAQAAAAAAAAQAHACAAAHQABAHAIgFQADgCADADQAAAAABABQAAAAABABQAAAAAAABQABAAAAABIgBADIABAEQAEAFAAAFIABAJQAAAHgFAFQgIALASAJQAGADAFAFQAGAGABAEIABAFQACADAHAEQAGADAEgDIAGgGQACgDAEgBIAIgCQAGgEAJAFQAFADABgBQAAAAABAAQAAAAABAAQAAgBABAAQAAgBABgBQABgCAGAAIAIABQAIAAAEgEQADgDAEAAQAFAAAEgDIAHgHQADgCACAAIAHADQAGACAFgHQAEgEgBgHQgDgGABgIQABgFACABIAFACQABAAAAAAQABABAAAAQABAAAAgBQABAAAAAAQAAgBABAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAgFAGgDQAHgCAAgHQAAgGAFAAQAEAAABgDQADgEADABQAFACACgCIAEgBIAJgCQAHgDADgDIADgGIAFgIQAFgFAFgBQAFAAABgCIABgDQACgGAFgBIAHgFQAFgFADAAQAJAAAHgHQAFgEAMADQADADAFgDQAEgCAGgIQAIgGABADIACADQAAACgCADIgRANQgDAEgDAGQABAIgBAIIgDAOQgBAEACADQADAEAEgBQAGgCAAAGQAAAEAIAFQADACACAEQACAFgCADQgCADABAEQAAAEgCADIgGAKQgDAHgEABQgIADgFAEIgFAGQgCADAAAGQABAGACADQADADAAAGQAAAHgDAEQgEAEAAAIQAAAHADAFQACAFgBAUIABAFQgBAEgDAEQgGAFADAJQACAGAHALQACAFgBAFQgBAHgEADQgFACAAAGQgBAFABACQADAFAAAEQgBAFgCAEIgFAIQgBACgFADQgEACACAFQACAFgBACQgDAEADAEQACAEAAAEQAAADgNANQgDAEgCAKIgCAMQgCAJAFAGQAFAFABAFIAAAGIgFAHQgEAFgHABIgIgBIgggDIgngDQgKABgEgGIgDgGQgBAAgBgBQAAAAgBAAQAAAAAAAAQgBABAAAAIgDAMQAAAHgFABQgEAAgBACIAAADIACAEQAAAAAAAAQABABAAAAQAAABgBAAQAAABAAABIgDAFIgIAJQgDACACAEQAAAAAAABQAAAAABABQAAABAAAAQAAABAAAAQAAABgBABQAAAAAAABQAAAAgBAAQAAAAgBAAQgNAAAAAEQAAADgCACQgBAAAAAAQgBABgBAAQAAAAgBgBQAAAAgBAAQgCgCgDABQgBAAgBAAQAAAAgBABQAAAAAAAAQgBAAAAABIABAEQgBADgCABIgEABQAAAAgBABQAAAAAAAAQAAAAAAABQAAAAAAAAQACAFADgBQADAAAGALIAcA8IAEAJQADAEgBADIgEAIIAAAEQACACgBAEQAAAPACABQACADACAHQACAIgBAFIAAADQAAAFADACIADABIABADIABADQgBAEgGACQgHACgEgDQgDgDgEABIgGAFIgDAEQgBABgBAAQAAABgBAAQAAAAgBAAQAAAAAAAAIgDgFQgBgBAAAAQAAgBgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQgBAAAAAAQgGgBgEgDIgFgEQgCgDgEABQgEAAgCgFIgFgJQgDgHgFAAQgEgBgBgFIgBgJQgEgLgEADQgCACgEANQgFASgLgXQgDgGgHABQgFABgBAEQgBAEgCADIgHAHQgDADgHADQgIAEgHAFQgJAGgBAHQgCAEACAKQACAIgJAEIgOAGIgDABQgEAAgGgJg");
          }, this.shape.setTransform(-.0103, .0171), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.heilongjiang, new cjs.Rectangle(-60, -58.1, 120, 116.2), null), (g.heibei = function (A, g, Q) {
          var _this25 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this25.shape.graphics.f(A).s().p("AhbGkQgBgCACgFQADgFgCgBIgIAFQgDACgFAAQgEgBgBgCIgEgGIgCABIgCACIgKAKQgDACgFgBQgNgEgaABQgLgGgUgEIgXgEQgjgPACAKIABANIgDgJQACgHgBgDIgFgIQgDgEgFgCQgDgCAAgDQAAgJgHgEQgDgCAAgEQABgFAGgDIAIgFIAEgHIABgHIAGABQAEACAAgHIgDgQQgBgIABgCQAAgCAEgDQADgDABgFIADgJQAQgfABgKIABgKQgBgCgFgBQgEgBgBgDIgBgIQAAgDgCgFQgFgGgDgJQgDgJgEgGQgDgEAAgDQAAgEgIgCIgMgDQgEgCgCgFIgBgIQgCgIACgRQABgGAIgIIANgNQAEgEgBgEIgGgIQgDgDAAgEIACgIQAEgIARgMQACgCAHAEQAHADADgBIAIgBQADgCABgDQAAgGAIgCQAFgBgGgMQgBgDADgGIAGgQQADgJgDgEIgGgFQgEgCgBgFIAAgOQAAgJgCgBIgHAAIgIABQgDAAgCgDQAAgBgBAAQAAgBgBAAQAAgBgBAAQAAAAgBAAIgHgBQgDAAgDgFIgEgIQgCgEACgCQACgCAFAAQAHACgDgLQgCgFAGADQADACAIgIQACgDAUgIQAHgDgGgDQgFgEgFACQgDABgCgEIgGgLQgDgFABgGQABgEgCgBQgCgBgCgEIgGgIIgJgLIAAADQgGgVgDgGQgLgOABgGIAJgPQgGgGgBgJQgBgIACgIQABgEAKgBQAKgBADgEQADgEAAgNIgBgPQAEgLADgEQAFgFAKgDQgFgSAPgCQAQgCAAgHQABgKAEAHQADAHADAPQACALgBALIgBAVQACAJAJADQAFACALAAIAKAAQAFgBAFgHIgCgEQgCgDAIgEQAIgKAJgFIAPgIQALgJAIAQQAEAFAGgFQADgDAHgKIAJgMQAEgFAHAGQAFAGAFgBIAPgDQALgHADgHQADgHgHgDQgHgDAGgEQAHgHgDgJQAGgJAAgHQAFgHAJAAIAMACQAFgBACgCQADgCAEgKQADgEAMAAQALgBAMADQAJADAGAMQAFALAAAHQAAAJAEALQAGAOAIgGQAEgDABAGQADALACAEQAEAHgCADIgIAFQgFAEAAAEIAFALQABAEAGAJQAGAIACAJQgCAMARgEIAbgGQAHAAALAFQAKAFAHAAQALgCgGAJIgNARQgGABABAFIABAJIgFAGQgEAEgBAEQgDAPAVAIIAGAAQAEgBACACQAFAIAGADQAFADANAAQAJgDAGATQAIAVADABQAEACAEAKQAEAMAHAGIgDACQgVAJgBACQgDADADADQAEAGgIAAQgJAAgEALIgBAKQAAAEgDABQgJACAEACIAFAAQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAABQgDAJABACQABAEgEAGQgGAEgDAMQgEAMgIAGIgHACQgBABAAAAQAAAAgBgBQAAAAABAAQAAgBABAAQAFgEACgDQADgFgFAEQgEAEgDgBIgFADQgBABgFAAQgGABgDgBQgGgFgHAJQgPARgIgFQgGgFgEgIQAAgDgDgBQgEgEgEABQgSADgDADIgIAIQgCADACAGQADALgLANQgGAHgBAOIgBALQgBADAEADQAEADAEAIIACAFIAEAGQANAMgDADIgGAFIgDADQgBAEAHgFQgCACgCAJQgDAKgFACQgHAEgDADIgFAIQgCAEAAAFQgBAFgKAAIgYgCQgPgBgIAIQgMANgIANIgHAMQgCADgHACIgKABQgCABAAAHQgBAFABAEQAAACgHABIgLAAQgDABgEAEQgEAEgFAOIgIAVIgFAPQgDAKgEAEQgCADgKAHQgKAHgEAHQgNAXAFAQQABAFAJADQAIAEABAFQADAPgEAPIgEACQADgJgBgCg");
          }, this.shape.setTransform(-.0071, .0214), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.heibei, new cjs.Rectangle(-29.4, -43.1, 58.8, 86.30000000000001), null), (g.hainan = function (A, g, Q) {
          var _this26 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this26.shape.graphics.f(A).s().p("AgfB6QAAgBABAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQAAgBAAAAQgBAAAAgBQAAAAAAAAQAAgBAAgBQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAAAgBAAQAAAAgBABQAAAAgBAAQgBABAAAAQgBABAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBgBQAAAAAAAAQAAgBABAAQAAgBAAAAQADgEgLgCIgMgCQgGgCgGADQgGACgDgIQgDgFgKACQgGABgCgFQgCgEgGAAQgEAAgEgFQgCgDgJAAIgEAAIgDgDQgEgFADgHIACgEIgBgFQgBgKgDgCQgGgEADgGQACgEAAgFIAAgFIgBgFIgCgIQAAgJAEgCQADgDgDgFQgEgCADgHQADgFAGgBQAEAAAGgGIAJgHQADAAAGgHQADgEAGgDIAKgFQAHgDAEgEQAEgFADABQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQgCgCADgDQABgBAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAIgDABIgDACQgDADgCAAQgBAAgBgBQAAAAgBAAQAAAAgBgBQAAAAAAgBQgDgFAFgDIALgIQAEgDADADIADACIAFgBQAGgBACAEQABAEAEgCIAEgBQACAAgDgFQgBgEAGgFIAJgFQAGgCAEAEQAAABABAAQAAABAAAAQABAAABAAQAAAAABAAQAAAAABAAQABAAAAAAQABABAAAAQAAAAABABQAAABABAAQAAAAAAgBQABAAABgBQAAAAABgBQAAgFABAAQACAAgDAJQAAABAAABQAAAAAAABQAAAAAAAAQAAAAABAAIADgEQADgFAEAAQAEAAABAGIABACIADACQACADAAgFQAAgEADgCQABgBAJABQABAAABAAQAAAAABAAQAAAAAAAAQABgBAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAAAgBAAQgEAAACgCIAFgEQACgBADAAIAHAAQAGABADgEQAEgFAHAFIAIAEQAFACACAEQAAABABAAQAAABAAAAQABAAAAgBQABAAAAgBQABgBgBgHQgBgFAJAAQAFAAAAgFIABgCQAAgBABABQAAAAAAAAQAAAAAAABQABAAAAABQABAHAEACIAIAGQAGADAFgBQAEgBACAFIADAGIADAJQACAEAAAJQgBAHADACQAAAAABABQAAAAABABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQgBAAAAAAQgBAAAAAAQgEgCgCADIgIAIIgEADIgBgEQgDgGAEABQAAAAABAAQAAAAABAAQAAgBAAAAQABgBAAAAIABgCQACgGgEAFQgDADgGAAIgDABQAAAAAAAAQAAAAAAABQAAAAABABQAAAAABABQAEAEABADQAAADgHAEQgEACAAACQAAABAAAAQgBABAAABQAAAAgBAAQAAABgBAAQgCABgBAFQAAADgFAEQgDACgCAJQgCAGgDABIgBACQAAABAAAAQAAABAAABQAAAAABAAQAAABAAAAQABABgEAHQgDACAAAIQAAAEgCACIgDADQAAABgBAAQAAABAAABQgBAAAAAAQgBABAAAAQgBAAAAABQAAAAgBAAQAAAAAAABQAAAAAAABQAAAAAAAAQAAAAABAAQAAAAAAAAQABABAAAAIADABIACAAQACAAAAgGQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAAAAAQABAAAAAAQAAAAAAABQAAAAAAAAQAAABAAABIACAEQABADgHACQgDABgDAJQgBAFgMgBQgGAAgHAFIgMAKQgEAEAAAGQAAAHgFACIgEACIgFgBQgBAAgBAAQAAgBgBAAQAAAAAAgBQAAAAAAgBIADgDQABAAAAgBQABAAAAAAQAAgBAAAAQAAAAAAAAIgFAAQgGACgGAEQgFAFgDgFQgCgDgEAIIgDAIQAAAEgEAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAAAAAABIADABQADABgCAFQgCADgBgEQgCgEgCABIgFABQAAAAgBAAQAAAAAAABQgBAAAAABQAAAAABABQACADgEADIgDABQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAg");
          }, this.shape.setTransform(.025, -.0036), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.hainan, new cjs.Rectangle(-14.7, -12.3, 29.5, 24.700000000000003), null), (g.guizhou = function (A, g, Q) {
          var _this27 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this27.shape.graphics.f(A).s().p("AjzEGQACgEAQgVQAFgHgFgGQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBIABgCIAJgKQADgDADABQABAAAAAAQABAAAAAAQAAAAABgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAgBgBAAIgGgEIgHgDQgFgDAAgDIgDgEIgDgEIgCgKIgBgGQgBgBgHAFQgDABAAgHQAAgBgEgFQgGgHgCgEQgCgEABgEIAJgFQACgBACgIIAEgSQABgGAEgGIAFgMQACgIACgEQACgEAIgFQAEgCgCgHQgEgKgEgGQgCgEgHgDQgBAAAAAAQgBAAAAgBQAAAAgBgBQAAAAAAgBIgBgEQgBgEgCgBQgEgBgFAEQgEAEgEABQgCABgLgFQgFgCgDACQgCABgDALQAAABgBAAQAAABAAAAQgBAAgBAAQAAABgBAAIgGAAIgPgCQgFgCgCgFIAAgFIAAgGQABgCgCgGIgCgHQgBgGAFgFQADgFAAgCQAAgCgHgMQAAAAAAgBQgBAAAAAAQgBAAAAAAQgBAAgBAAIgEADQAAAAAAAAQgBAAAAAAQgBAAAAgBQAAAAAAgBIABgGQADgGAHgCQADgBAJgNIAMgTQAEgEAGAIIAGAJQAEAHAEADQAFAEALgQQAEgGAGgDQACgBAEAEIAGAGQAGAHAJACQAGACAJgDQAFgBAEADQAEADAHgFIANgIQAFgDAIAEQAEABAEgHIAHgRQACgIAAgGIgBgGIAHgBIAGgDQAFgCADAAQAGgBAJAKQAFAFAIgDQAHgDAHAAIAOgDQAJABAEgDQAEgDAFACQAHADADgBQAEAAAFgFQAEgEABgEQADgHgJgOQgHgLgHgDQgHgDgHAGQgEAEgHABQgHABgEgCQgDgCAAgGQABgHgCgDQgGgKgEAGQgDAGgHgJQgDgDABgVQABgLAZAAQAEAAABgEQABgHACgCQADgEAEgBQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAFALAEAAQAHAAAAAFQABADAEADIAIAIQAEAEADgBQABgBABAAQAAgBAAAAQAAgBAAAAQgBgBgBAAIgDgFQACACAHgBQAIgBACgEQACgDgCgGIgCgGQgIgRAHABQAHAAADAGQAFAIgBANQAAANACACQAEAEAEgFIAKgLQAGgFgBgOQAAgFADgBIAIgCQACAAABgEQAAgGAKgCQAJgDAFAHQAHALADAAQAKgCADgKQACgEgBgJIABgLIABgIQABgEADgCQAEgCAGAAIAHAAQAHACAHAGQAEAEADAKQABADAFACIAOgEIARgEIAOgBQACAAABAHIADAIQADAFAAAJIgFANQgBAEADACIAUAKQACAAADAEQACACgFANQgBAEACAMQAAABAAABQAAAAABABQAAAAABAAQAAAAABAAQABAAAAAAQABAAABAAQAAgBABAAQAAAAAAgBQACgBgBgHQAAgEACgCQABgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQADADAAAIQAAADgCAHQgBAGABADQACADAJAAQAJACALgBQAEAAACgFIAFgNQAFgLAFgDQADgBAAgFIADACIgBAPIABAHQAAAEAEABQAFADABABQACADgCADQgIAOACAEIAEADQACACgCAFQgDAGAEANQAEAMADACQAEADADAGQADAHgEADQgOAIgBAEQgBAIgIgDQgHgDgFAJQgFALgGAEIgIAFQgEADAAAEQgBAIgGADQgEACACADQACADAHAAQAEgBAKgGQAHgFAAACQAAABABABQAAAAAAABQAAABABAAQAAAAAAAAQADABAEgDQAMgIAIABQALACAEAJIAGAJQACAFgDABQgJACAEAHQACAEABAFQAAAFgFAAQgEABgDADQgEADgCAAQgFAAgBADQAAACADAEQALAJgGAIQgQAWAHAEQACABAIAAQAGABAAAEQAAAJAGAGQACADgEADIgCAGIgSAcQgFAGgEAAQgIgBgLAAQgMABAAAGIADAOQgBAHgHgCIgQgFQgIgCgDAEQgDACgEAIQgFAIgDABQgFACgIgGQgIgFgFAAIgOADQgGACgDALQgDANgGADQgNAJgTgJQgGgDgFgBIgMgCQgHgCgEgGQgCgCgIgQQgEgKgHgBIgPAAQgIgBgDALIgCAUQgBAMgdABIgNAEQgPAFgFAEQgIAHgXAcQgKANgSgIQgUgNgGgCQgigTgVgHQgOgEgOAQIgVAXIgQALQgKAHgGABQgBgPACgJg");
          }, this.shape.setTransform(.0068, .025), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.guizhou, new cjs.Rectangle(-32.9, -28.6, 65.8, 57.3), null), (g.guangxi = function (A, g, Q) {
          var _this28 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this28.shape.graphics.f(A).s().p("ABbE0IgGgDQAAgBgBAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIADgEQABAAAAAAQAAgBABAAQAAAAAAAAQABAAAAAAQAFABACgGQAAgBgGgDQgIgHgCABQgHAEgDgDQgGgGAAgCQgDgGADgBQAFgEgCAAQgDgBgBgCQgDgGgCADQgGALACACIAHAHIABADQAAAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgFAAgCABQgDACgDgCIgEgDQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAABAAIADgCQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBgBAAQAAAAAAgBQgBAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAgBAAQAAgBgBAAIgFABQgGABgCgCQgCgEABgEIAEgHQABgBAAAAQAAgBAAAAQgBAAAAAAQAAAAgBAAIgDABQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAgBgBAAIgBgFQAAAAAAAAQgBgBAAAAQAAAAAAABQgBAAAAAAIgFAFQgBAAAAABQgBAAAAABQgBAAAAABQAAAAAAABIAGAKIAAADIgCACQAAAAAAAAQgBAAAAAAQAAABABAAQAAAAAAAAIACACQAFgCgBAEQgBAEgEAEQgDAGgEABIgEAAQgBAAAAAAQgBAAAAAAQAAgBABAAQAAAAAAgBQAFgFABgCQABgFgDgBQgDgCgCACQgGAKACgHQABgBAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQgDgFgCAEIgBAPQgEAHgEABQgFAAADgCIACgHIgBgGIAAgCQAAgBAAAAQgBAAAAAAQAAAAAAAAQgBAAAAABQgKAHAFABIADADQAAABAAAAQAAABAAAAQAAAAgBABQAAAAgBAAQgEACgCgCIgBgCIgCAAQgJgCABACQAAABAAAAQAAABAAAAQAAABAAAAQgBAAAAAAIgEgGIgDgBIgFgEIgJgIIgHgBQgGgBgCABIgIAFIgJACIgHAAIgDgCIgDgCQgFgDgCABIgEABQgDAAgEgHIgFgGQAAAAgBAAQAAAAgBAAQAAAAgBABQAAAAgBAAIgDACQgBAAAAABQgBAAgBAAQAAAAAAAAQgBgBAAAAIgMgLIgCgBIgDAAQgEAAgBgDQAAgBABgBQAAgBAAAAQAAgBABAAQAAgBAAAAIACgCQAAgCgDgDQgDgCgDACQgDABgCgCIgCgEQgDgDgFABQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAgBgBAAQgBgBgBAAQAAAAgBABQAAAAgBABQAAABgBABQAAABAAAAQgBAAAAAAQgBAAAAgBIgBgGIAAgZIgBgKQgBgEgGgBIgFgBQAAgBAAAAQAAAAAAgBQgBAAABAAQAAgBAAAAQADgDgFgBQAAgBAAAAQAAAAAAgBQgBAAABgBQAAgBAAAAIABgDIACgGQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAIACgDQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQADgBADABQACABADgFIAEgJIAGgIQAEgFgFAAQgNgFgCgEQgEgGgCgCIgEgCQgBAAAAAAQgBAAAAAAQgBABAAAAQgBAAgBABIgCABQgDAEgMADQgDAAgEgBQgEgCgBgCQgBgEgEgFQgDgDgFAAIgKAAIgGgBQAAAAAAABQgBAAAAAAQAAABAAABQAAAAAAABQABABgBAAQAAABAAAAQAAABgBAAQgBAAgBAAIgGAAIgEAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAAAQgCgFgFgCQgFgCgDgEQgBgDgGgBQgFgBgDABQgEACgBgCIABgJQgBgDgFgFIgCgCIADgBQASgFABgEQAAgEAEgDIAHgGQAFgFAMAAQANAAAHgHQAEgEACgJIADgQIABgIIgCgFQgCgNgKgJQgEgEgDABQgCAAgHAEQgFADgDgBIgLAAQgGAAgBgCIgDgEQgEgCgDACIgIAEQgKAGgEgGQgBgDgDgBIgJgDQgFgCgBgDIAAgIQgBgGgDgIQgFgJgGgFQgGgEgJgBIgPAAQgGgBgCACIgEAHQgCAFgHgHQgHgGgDgIQgBgDgBgIQAGgBAKgHIAPgLIAWgYQAOgQANAEQAWAHAhATQAHADATAMQATAJAKgNQAWgcAJgHQAFgFAPgFIANgEQAdgBABgMIADgTQADgLAIAAIAPAAQAGABAFALQAHAQACACQAEAGAHABIANACQAFABAGADQASAKAOgJQAFgEADgMQADgMAHgBIANgDQAFAAAHAFQAIAFAFgBQAEgCAFgHQAEgIACgDQAEgEAIACIAQAGQAGABABgHIgCgOQgBgGANAAQALgBAIABQAEAAAEgGIASgaIAAAAIAFAAQAFAAAFgBQAGgCAFADQAFADgDAEQgEAEADADQADACAHAAQAFAAAAgDIgCgHQgEgJAHAAQAGAAADgPQABgHAJACQAKACgCAEQgBAFABAFQACAGAEgDQAEgDACAAQADAAADAGQAEAGAEgDQAEgCACgHQABgFAHgHQAJgIADgGQAFgIAIAAQAGAAAEAEQADAEAHgBQAIgCADgGQADgGABAAQABgBAAAAQAAAAABABQAAAAABAAQABABAAABIAEAEIALADQAVADgGAQQgFAMACASQAAAIAHgCIAOgCQAIAAgDAHQgDAHgIADQgFABgBAGIABAOQAAAHgJAPIgNASIgEAJQgCACgEABQgEABgBADIgDASQgDANAJgFQAKgFADgIQAGgMAJgBQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAABAAABQAAAAABABQAAAAAAABQABAAAAAAIAHgEQAEgDADACQAFAEAAAMIAAARIgBANQgBAHAFACQAGADADgDIAHgJQAEgGAHAAIAQABIAMABQADAAAEAXQAEAYgFAKIgNAWQgIALAAAHQAAALgBAFQgDAIgJAIQgMAKgEAFQgIAJgIANQgJAOgBAEQgBAEACANQABASgCAJQgEAOgPAJIgXAMQgIAFgKANQgKANgEAIIgEAJQgEAIgKABIgIAAQgDAAgCADQgGAKABALIACAJQAAAEgGAEQgJAGgXACQgKABgIANQgFAHgLALIgBgFQgCgFgBABQgDAAAAAIIACAEQABABAAABQAAABABAAQAAABgBAAQAAAAAAABQgEACgGgGQgFgFgDgIIgCgFQgBgFACgCQAEgFgBgCQAAAAgBAAQAAgBgBABQAAAAgBAAQAAABgBABIgFADQgBABAAAAQgBAAAAABQgBAAAAAAQAAABgBAAIgCADQAAAAAAABQAAAAABAAQAAAAAAAAQAAABABAAQACAAACADQACACABADIABAGQAAADgDACQgIAGgHAAIgLABQgFACgDgDIgCgDQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQgFAJgCAAIgCABQAAAAgBgBQAAAAAAAAQgBAAgBAAQAAgBgBAAg");
          }, this.shape.setTransform(.0066, .0268), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.guangxi, new cjs.Rectangle(-42.9, -30.9, 85.8, 61.9), null), (g.guangdong = function (A, g, Q) {
          var _this29 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this29.shape.graphics.f(A).s().p("AmRFHIABgFQAAgCgDgEQgGgHAGAAQAGgBACAFIABAEQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIACgHQABgGgCABIgCAAIgDgCIgDgHIgBgBQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAABQACAIgDgDIgCgDQAAgBgBAAQAAgBAAAAQgBAAAAgBQgBAAgBAAQgEAAgBgDIgBgJQAAgDgFgBQAAgBgBAAQAAAAgBAAQAAgBAAAAQAAAAgBgBQAAAAAAgBQAAAAABgBQAAAAABAAQAAgBABAAIAIgCQACAAAAgBQABAAAAgBQABAAAAAAQgBgBAAAAIgGAAQgGACgBgDIgCgDQADgEAAgCQAAgDgFgEIgCAEIgBgCQgCgDgBgEQgBgGACgDQAHgLgDgFIgCgFIABgDQABgBAAAAQAAgBABAAQAAgBAAAAQABAAAAAAQAAgBABAAQAAAAABAAQAAABAAAAQAAAAAAABQABAGABgIIABgGQADgCgCgFIgBgFQAAgBAAAAQAAgBABAAQAAAAABgBQAAAAABAAIAKAAIAGAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAQAAgBABAAQAAgBAAgBQAAAAgBgBQAAgBAAgBQAAAAgBgBQAAAAAAAAQgBAAAAAAQgDACgEAAQgBAAgBAAQgBAAgBAAQAAAAAAgBQgBAAAAgBQABgFgDgCIgBgBQAKgIAHgJQAHgNAKgBQAYgDAJgGQAGgEAAgDIgCgJQgCgMAGgJQADgEADAAIAIABQAJgBAEgJIAEgJQAEgHAKgNQALgOAIgFIAXgMQAPgIAEgOQACgJgCgSQgBgNABgEQABgDAJgPQAHgNAIgIQAFgGAMgKQAJgIACgHQACgFAAgMQAAgIAHgLIAOgVQAEgJgCgTQgCgPgEgLQAFgEABgCIAJgcQACgLACgEQADgHAOABIAdADQAMACACAJQACAKANAFQANAFABgLIAEgRQAAgHgEgFIgKgIQgDgEAJgFQATgKAGgHQAEgEADAAQADAAAIAHQAIAIAFACQAEABANAAQASAAAGgFIAMgOQAOALACAOIAOgDQAGgCAHABQAGABAMgIQAJgHAGAEQAJAGADAKQAFAEgBAGQgBAFgEAEQgOAIgGAFQgLAKgBAOQgBALgNAJQABAHAJAFQAJAFALgDQAogIAdgOQAJgBASgLQALgHAFAJQAGANAMAGQALAHAFgEQgFgaABgGQADgUAbAIIAeAIIAVAHIAUAGQAIADAEAIQAaAuACANQADAQAaAkQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAQAAAAAAgBQAAAAgBgBQgBgIgEAEQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQgBgBAAABQgBAAAAABQgBAAgBABQAAABAAAAQAAAAgBAAQAAABgBAAQAAgBgBAAQAAAAAAAAQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAAAgBAAQgCABAAAEIAAALQAAAHgEAEIgFAFIAAAEQAAABgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAIgKAAQgFAAgEgCIgEgDQAAgBgBAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAABQAAAAAAABQAAAAAAABQADALAFgCIAGgCQADgCACABQAHABABACQACAFACABQABABAAAAQABAAAAABQAAAAAAABQAAAAgBABQgDAEgCgFQgBgCgEABQgFACgBAFQAAAAgBABQAAABAAAAQgBABAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAQAAAAAAgBQAAgBgBAAIAAgGQAAgBAAgBQgBAAAAAAQAAgBgBAAQAAAAgBAAIgHABIgBADIAAACIADAAQABAAABAAQAAAAABAAQABAAAAAAQABAAAAAAQAAAAAAABQABAAAAABQgBAAAAABQAAAAgBABIgDAEQAAAAAAABQgBAAAAABQAAAAABABQAAABAAAAIABAHQADAHgFAAIgEAAQgBAAAAAAQAAAAAAAAQgBABAAAAQAAABAAAAIAAAEQAAABAAAAQAAAAgBAAQAAABgBAAQAAAAgBAAIgJACQgDAAgCgCQgHgGgBAEQAAADgEACQgEADgCADIgGAHQAAABAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAIAEgFQABAAAAgBQAAAAAAgBQAAAAgBAAQAAAAgBAAIgEABIgBgCQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAgBAAIABAIIABACIgCABQgDAAgCACQgEADgFABQgDAAgEAEIgFAEQAAAAAAAAQgBgBAAAAQAAgBAAAAQgBgBAAgBQAAgKgGAAQgFAAgBgBQgBgCACgDQABgBABAAQAAAAABgBQAAAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAABgBAAIgEAFQgCAHgDAAQgDAAgDgDIgDgDQgBAAgBAAQAAABAAAAQgBABAAAAQABABAAAAIABAEQAAABAAAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAABQAAAAAAABQABAAgBABQAAAAAAABQAAAAgBABQAAAAgBABIgDAEQABACAHgBQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAgBABQgCABAAADQAAAFgDgCQgHgEgFABQgGACgCgCQgFgDABgCQAAAAABgBQAAgBAAAAQAAgBAAAAQAAAAgBgBQgEgCgCABIgFACIgBgBQAAAAAAAAQgBAAABgBQAAAAAAAAQAAAAAAAAIAEgEIADgDQABgBAAgBQAAgBAAAAQAAgBAAAAQgBAAAAABIgHADQgGAEAAABQAAAEgDgBQgDgCgDABQgEACgCgCQgDgCAAAEIABAFQACACgCADQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAgBgBAAIgBgEQAAgBAAAAQAAAAgBAAQAAAAgBAAQgBAAgBAAIgFAAIgCAAIABACQAAAAABABQAAAAAAABQABAAABAAQAAAAABAAQACABADAEQABAAABABQAAABAAAAQAAABAAAAQgBABgBAAQgDACAAAFQAAAJgCgEIgBgCQgDgGgFADIgGADQgBAAAAAAQAAAAgBgBQAAAAAAgBQAAgBgBgBQABgKgDgCQgCgCAHgFQAHgCgCgDQgEgFgBAEQgBAEgEAAQgFABgCABQgGAGgGgCQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAgBABIgCAGQgEAEAHgCQAEgBACABQAAAAABAAQAAABAAAAQAAAAAAABQAAAAgBABQgCAEgEABQgEADABABQAAABABAAQAAAAABAAQAAAAABAAQAAAAABgBQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABABAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAgBABQAAAAAAAAQgBABAAAAIgFACIgDACQAAABgBAAQAAABgBAAQAAAAAAABQgBAAAAAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQgBgBAAgBQABgJgEgCIgGgDQgEgDgGADIgHAEQgGAEAFABQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAIADABQABAAAAAAQAAABABAAQAAAAgBABQAAAAgBABIgEABQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAABgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAgBAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBABQAAAAAAAAQAAAAAAABQABAAAAAAQAAAAAAABIACABIAAACQAAAAAAABQAAAAAAAAQAAABABAAQAAAAAAABQABAAAAAAQAAAAAAAAQAAAAABAAQAAgBAAAAQABgEADgBQAEgDAEAAQAEgBACACQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAABQABAAAAAAQAAABAAAAQgBAAAAABQAAAAAAAAQgBABAAAAQAAABAAAAQgBABAAAAQAAABAAAAQACAFgFgCQgIgDgCACQgBAEADACQAEADAAAEIgBAEQAAAAAAAAQAAAAAAAAQAAAAAAAAQgBAAAAgBIgCgEIgBgCIgCAAQAAABAAABQAAAAgBAAQAAAAAAAAQgBgBAAgBIgBgBIgDABQgEADgCgFQgDgHgFABQgJADgDgBQgNAAAGgGQAJgKABACQABAEADgFQACgEgEgBQgHgBgCACQgCADgDABIgDABIABgCQAAgBABAAQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAAAAAAAQgBgBgBAAQgDAAgDgFIgDgGQgDgEAAgCQAAgKgFABQgHADgBgDIgDgDIgCAAIgBgDQgCgHACgCQACgCAAgFQAAAAAAgBQAAAAAAAAQgBAAAAAAQAAAAgBAAIgCADIgDAEQgBAAAAAAQAAAAgBAAQAAAAAAgBQAAAAAAgBIgCgLQgBgEgDgDQAAAAAAAAQgBgBAAAAQAAAAgBABQAAAAAAAAQAAAAgBABQAAAAAAAAQAAABABAAQAAAAAAABQACACABADQABAEgBADQgDAFACADIACAFQABAAAAABQABABAAAAQAAAAABABQAAAAAAAAQAFAAACADQABADgCADQgDACACADQAEACABADQAAAAAAABQAAAAAAABQAAAAgBAAQAAABgBAAQgEABgDgHIgEgGQgDgCgCABQgIgCgEgDQgEgEgBACIACADIADAFIAHACIAHAEIADADQADAEABADIABADIADACQAAAAABAAQAAAAAAAAQAAABAAAAQAAAAAAABIAAAEQAAAEgDAGQgBAFAGADQAEABgCAEIAAADQAAAAAAAAQAAAAAAABQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAABAAAAQAAABAAABQABABAAABIACACIgCABIgBADIgCADQgBACgJABQgDAAgFgHQgFgHAAgCQgEgLgFAAQgFAAAHAGQACABABAGQAAAEAEADQACACAAAEQgBADgCADIgDAGQgDAKgFABIgEACQgDACABgEIACgGQAAgBAAAAQABgBAAAAQAAgBgBAAQAAAAAAAAIgDAAIgEACQgDAAgCgMQAAgEACgCIAEgDQADgDgBgDIAAgCIgCADIgBADIgDABQAAAAgBAAQAAABAAAAQgBAAAAAAQAAAAAAgBIAAgEQABgDgEgKQAAgJgFABQgCABADAHQABACABAMQAAAIgGAIQgDAFACAEIACAHIgBAIIgDAHQgCADgGACQgEABgBgHQAAgFgEgBIgCgBIgEACIgDACIgBACQAAADgHACQgDACgBADIgCAHQAAADgFABQgEAAgDgCQgHgGgCAAQgFgCABgHQAAgCAHgDQABgBAAAAQABgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAABAAAAQgBADgFgBQgDACgCgGQgBgDACgDQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAQgBABAAAAQAAAAgBABQgBABAAAHQAAAEAEAHQACAOAAACIgCADIgDABIgJAFQgEACgCgDIgCgCQAAgBAAAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAgBQADgJgGADQgGAAgEABQgGACgBgDQAAgBAAAAQgBgBAAAAQgBAAAAAAQgBAAgBAAIgEAAQgBAAAAAAQAAAAgBAAQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAABAAQAAABAAAAQABAAAAAAIADADQABAAAAAAQgBABAAAAQAAAAAAABQgBAAAAAAQgFAEAAAEIAAADQAAAAABABQAAAAABAAQAAAAABAAQABAAAAAAQABAAABAAQABAAAAAAQABAAAAAAQABAAAAABIAAACQABADgGABIgEABIgEADQgEADgEAAIgCABQAAgBAAAAQAAAAAAgBQAAAAAAgBQABAAAAgBIADgEQABgBAAAAQAAgBAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAAAAAgBQAAAAABAAQAAAAABABQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAAAAAQABAAAAgBQAAAAgBgBQAAgCgFABQAAAAgBAAQgBgBAAAAQgBAAAAAAQAAgBgBAAQgBgDACgDQABAAAAgBQAAAAgBAAQAAgBgBAAQAAgBgCAAQgEgDgBACQgCACgDAAIgEgBQAAgBgBAAQAAgBAAABQAAAAAAABQABABAAACQACAEADgBIAEAAIACADQAAACgCAEQgBAEgCAAQgIAAAAAGQgBADgFACIgHACQgMABgBgJIgBgDIgCACQgDAEgCAAIgEACIgDAEQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIACgCQADgCACABQABAAAAABQAAAAAAABQgBAAAAABQgBAAgBABIgHAGIgEABQAAAAAAAAQgBAAAAAAQAAAAAAgBQAAAAAAAAQAEgHgDAAIgFgDQgBAAgBAAQgBAAAAAAQgBAAAAAAQAAABAAABIABAEIgJABQgBABgBAAQgBAAAAAAQAAAAAAAAQAAgBAAAAQACgEgEAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAABAAABQABAEgFAAIgHABQgEABgCACQgDAEgGgBQgGgCgCACQgJAFgBAFIgDADQgDAEgCAJIgDAIQgHAIgBgHIgBgEIAAgBIgCgBIgCACQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAAAgBQAAAAgBgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQABgBAAAAQAAAAABAAQAAgBABAAQABAAAAAAIAJAAQAEgBAAgFQAAAAAAgBQAAAAAAgBQAAAAAAAAQgBAAAAAAIgCABQgCADgEgBQgEgBgCADIgBABIgBgBIgBgHQAGgBgDgDIgEgHIgDgGQgBgEgDgBQAAAAgBAAQAAAAAAAAQAAABAAAAQAAABAAABQABAEACADQAAAAABAAQAAABAAAAQAAABAAAAQAAAAAAABIAAABIgCAAQAAAAgBAAQAAAAAAAAQgBABAAAAQAAABAAAAQAAAEADACQADACAAAFQAAAEgEADIgGAEQAAAAgBABQAAAAAAAAQAAAAAAABQAAAAAAAAQABABAAAAQAAAAABAAQAAABABAAQAAAAABAAQADgBADADQABABAGAAQAJgBAAAFIgBAJIgBAEQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAgBgBAAQgEgKgGACIgFACIgGABIgEACQgBAAAAABQAAAAgBAAQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAgBABAAQAAgBAAgBQABAAAAgBIAFgFQAAgBAAAAQABgBgBAAQAAAAAAgBQAAAAgBAAIgCgBIABgDQABAAAAgBQAAAAAAgBQAAAAgBgBQAAAAgBAAQAAgBgBAAQAAAAgBABQgBAAAAAAQgBABAAABIgDAGQgDADgCABQgDACgDgCQAAgBgBAAQAAgBAAAAQgBAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAAAABABQAAABABAAQAFAFAAAGIgBAFQABABAAAAQAAABAAAAQABAAAAAAQAAAAABAAQAFgBABABIAGABQAHAAACADQACADgBAFIAAAEQgBABAAAAQgBAAgBAAQAAAAAAAAQgBAAAAgBIgCgFQgBgBgCAJQgDAEAEACQAEABABgCQABgBAAAAQAAAAABgBQAAAAAAAAQABAAAAABQAAAAABAAQAAAAABABQAAAAAAABQAAAAAAABIACAFQAAAAAAAAQABABAAAAQAAAAABAAQABABAAAAQAHAAACAGQADAIgEAFQgGAGAAACQgBAEgFABQgGACgCACIgDADQAAAAgBABQAAAAgBAAQgBAAAAgBQgBAAgBAAQgEgCgDACQgEAFgHgEIgEgDQgDgCgCABIgHAAQgDAAgCADIgDADIAAAAQgBAAAAAAQAAgBAAAAQgBAAAAgBQAAAAAAgBg");
          }, this.shape.setTransform(.0083, .0286), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.guangdong, new cjs.Rectangle(-43.2, -32.9, 86.4, 65.9), null), (g.gansu = function (A, g, Q) {
          var _this30 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this30.shape.graphics.f(A).s().p("AGbK3QgJgEgDABQgGABgFgBQgIgDgDABIgEABIgEgBQgJgEgGgEIgMgKQgTgIgBgCQgCgCAAgFQgBgHADgBIAFgCQABgBAAAAQAAAAABgBQAAgBAAAAQAAgBAAgBQABgEgCgFQgEgKAAgLQgBgJAEABQAHACAAgDQAAAAAAAAQAAgBgBAAQAAgBAAAAQAAgBgBAAIgCgCQgEAAgEgGQgEgFgEgJQgDgHABgCQABgFgEgEQgKgHgGAAQgOACgGgBIgJgDQgDgDgGAAIgEABQgBAAAAAAQAAAAgBAAQAAgBAAAAQAAgBAAAAIAAgIQgCgEgCgBQgDgBgEADIgDACQgBABgEAAQgLAAgEgEQgCgCgCgHQAAgNgBgCQgEgEABgCQADgGAAgEQAAgGgCgCIgHgFQgHgEAAgDIgCgGQgBgDgDABIgOAEIgQAKQgEADABADQACAEgCABIgKACIgHAAQgFABAAACQgCAGgEABIgJABQgEgBABAFQAFARACAEIAHASIAEAFQADADgBAFQAAANgHABQgNAAgBACIgDAEIgDAGIgBAJQgCAFgDgDIgFgDQgBAAAAAAQAAAAgBAAQAAABAAAAQgBABAAAAIgCAFQAAABAAAAQgBABAAAAQAAAAgBAAQAAAAgBAAIgFgCQgBAAgBAAQAAAAgBAAQAAAAgBAAQAAABAAAAIgEAEQgDABgCgEIgFgKQgCgEADgDQAGgEAEgHQAEgIAAgFIgBgIQAAgGgEAAQgDgBgFACQgGACAAAGIgBABIgFAAQgFgCAAgJQAAgHgDgEQgEgEgFgBIgHAAIgNADQgGAAgFgDQgBgBAAAAQgBAAAAgBQAAgBAAAAQAAgBABgBIADgFQABgDgEgHQgCgFgIgDQgDgCgDgDIgDgFIgKgSQgGgKAAgFIACgKQADgHADgEQAGgFAEAEIAbAMIAHAEIAPAIIALAEQADABAGAGQACACAEACIALgBQAEgBAGACQADAAAEgEQAGgGAFgEIATgJQAEgCgBgDIgDgFIgGgNQgBgDgIgGQgDgCgBgFIgEgJQgCgGACgGQADgLACgDQAEgGAMgHQANgIAFgGQAIgJgEgLIgFgQQgCgEAOADQABAAAAAAQABAAABAAQAAAAABgBQAAAAAAgBIABgFQADgGAEgCQAFgDAOAEQAEAAgBgEIgCgKIADgUQABgEAHABIAIABQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAgBIABgEIAAgSIABgWQABgKgEgDQgDgDgFgBQgGgCgCgGQgBgGADgGIACgEIABgHQABgHgJgDQgFgCgDgFQgCgDAAgIIgBgMIgDgNQgEgEgBgEQAAgCAEgCIAHgCQAEgCgEgGIgEgJQgBgCgFgCQgBAAAAAAQgBAAAAgBQAAAAAAgBQAAgBAAgBQAAgCgEgDIgGgDIgLgEQgHgEAAgSIgCgPQgDgDgBgEQgCgEgFgDIgGgFIgJgFQgFgBgCACIgEAEQgFAEgIgHIgOgRQgEgFgHAFIgKAGQgDACgDgDIgHgIIgQgPQgDgCACgGIADgIQABgDgHgDQgBAAgBAAQAAAAgBAAQAAgBAAAAQgBAAAAgBIgCgEQgDgEgFgCIgHgCIgHAAQgEgBgJgIQgDgDgIgPQgDgHgMgGQgHgDgBAEQAAACADAGIAFAGIAEAIQADAHgBABQgCABgEgCQgFgCgDgEQgCgDgOgJQgNgIgFgHIgigqIgWgYQgMgOgEACIgIAJQgNAMgJgMQgFgGgGgBQgHgBABAEQABAHgPAQQgFAGgQgOQgOgLgJgMQgLgOgngOQgLgEgCAGIgFAQQgDAHABALIADAYQABAOgEAEQgEAEgIgFQgFgDgEAEIgIAHQgEABgDAHIgFAOQgBAJgBAAIgNgFQgIgDgFAFQgFAIgEACQgFADgNgIQgNgIgFgKQgMgSgOAKQgHAFgMgDQgKgEgHgIQgHgGgOgCQgNgBgQADQgMACgFgTIgEgfQgCgJgTgBQgZAAgFgDQgJgFADgFQAGgEAAgDQAAgDgVgEQgSgDgOgBQgIgBAAgJIABgUQgBgJgDAAIgJgBQgFgCgNgBIgVgBQgJgBgCABIgGAFIgHACIgCgGQgHgUAKgGQAcgTAJgiQAEgPAOgiQANgdAAgGIABgNIgBgHQABgCAJABIAHAAQAZAEASgBIAOADQAJABAEgEIAdgeIAJgNQALgPAVgOQAQgLAPgFIANgGIAEgGQADgFAKgFQAJgFAEgBQAKgBACAJIAEALQADADAFgIQAFgIAOgEIAUgDQAdgDACgGIAFgJIAEgHQABgCgBgIQgBgIAEgDQAEgDgBgEIgCgIIgCgGQAAgCgDgDQgDgDABgBQAAgCAJgHIAHgGQAVgRAIAAIABgKIAAgIQAZAAAkACQAKAAAAAIQAAAEgCAEIAaBVIAKAfQAHATADAMIADALQABAEgIADIgSAMIgEADQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAIARAYQAMARACAAQAJADAFAGIAJAKQAGAIgCAMIgDAZQAAALAIgDQAEgBAEAAQADABACgBQACgCACgEQACgEgBgCQgBgDACgDQABgDADAAIAEAAIABAFQAAAHADADQADADADgGQAKgUAHAJQAGAIADABQAGADAEgJQAEgJADAAIAJABQAJAAAZgNQAIgCAKADQAPAEAIAQQADAFAEAEQAAAAAAABQABAAAAABQAAAAAAABQABAAAAABQAAAEgGARQgHAPgBALQAAAEgDADIgKAHQgHAFgEAIQgDAIgGABQgDAAgGAFQgHAEgDABQgKACgFAEQgIAEAMACQAKACAKAAQAHABAFAHQAFAHAQAMIAIAEQAGADAAAEQAAAOAHAFQADACACAGQADAGAEACIARABQAKAAgBAIIgDAeIgDAGQAAAFADACQAHAEACAFQABACAHgBIALgDIAFgBQACAAABAGQABAFAEAFQAEAEgBACQgBAEABABIAJAHIAKAIQAEADAEAAQADAAAGADQAGABACgEQAMgPAGgKQADgFAAgCIgDgHQgJgKgBgEQgBgGAQgCQAKgCAUgGQALgDADADQADAEAPAHQAOAGAFABIAKABQAFgBAEgFQAFgGAMgHQANgIAOgDQAngKAHAGQAEAEABADQACACgBAFIgBAIIAEAKQAFAJgBALQAAAOgIAEQgHADgFAIIgHAMQgDAEgNAKQgOAKgGACIgMAFQgFAEAEAJQALAcgMABQgIABgCAJQgBAHACAIQACAFAKAGQANAGACAEQAFAGANAMQAMAMAHAFIANALQAIAFAFgCIACgBQABgBAGAAIATADQAIACABACIADAFQAAAAAAAAQAAABAAAAQAAAAgBABQAAAAgBABIgEACIgGAEIAEAGQAGAEAEgBIAGgCQAAAAABAAQABAAAAAAQABAAAAABQABAAAAAAIALASQAIAKACAAIAKABQACAAACAFIAAAFQAEADAFAHIAEAGQACAFgCABQgIADgCAEQgDAEACAEIADANIAEADQAEACADAGIAHARIADAJIABAJIABAGQAAAEgDACQgHAEgEAGQgKANADAIQAFALAGAGQAGAHAIgBIALgCQABAAABAAQAAABABAAQAAABAAAAQAAABAAAAQgBAFAEAFIAHAKQACACAEAAIAIAAQAHACACAEIADAHQACAFACgBIAFgDQADgBACAEIAIANQADAGAGgEQAIgHACgHQACgHgDgEQgEgFABgDIABgJQgDgKACgCQACgEAHAAQAEAAAMADQAGAAAEgDIAHgGQAEgDgCgFQgCgHACgGIADgKQAAgLgCgEQgCgHgHgCIgNgFIgGgDQgNAAAAgGIABgKQAAgGgBgCQgCgEgDgDIgEgCQgBgCABgEQAFgKAIgFIAGgEIAEgEQADgEgDgFIgDgHQgCgEABgDIAFgFQADgDAAgGIgCgGQAAgEADAAIAMAAQAHgCAFABIAPACIAIgBQAFAAADADQAFAEABAJIACAGQABAFAFAAQALACAEAEIADAEIADACQAOACAIAFIAKAHIAFAGIAFAIQADAFADAAQAGAAAFgBQAGABAFAEIALAJIADAEQAAABABAAQAAABABAAQABAAAAAAQABAAABAAIAHgCQAEAAADADQACAEABAGIACAKQADARgBAKQgCAKgGAFIgJAJQgFADACAJIAHAbQAEAQgCAEQgDAKgGAFQgGAHgKgCQgXgFgEABIgKAFQgEACgGgCIgPgEQgDAAgCABQgEACABADQAAACAHAKQAJAPAAACQAAAFgIAAIgJgBQgEgBgDACQgDADgJABIgLgBQgGAAgDACIgDADQgBABAAAAQgBAAAAAAQgBAAAAAAQgBAAAAgBIgLgLQgJgKgIgDQgCgBgIgCIgJgBQgCgBgGACQgJAGgBADQAAAFACAKIADAHQABADAAACIgGAGIgGAIIgFAJQgGAFgCADQgCACAGADQADABAJABQAGAEAAADIACAFIAEAFIACAFQAEAJgDABQgJADgCACQgGAFAEACIAFACQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAIgMATQgHAKACAEQADAGAAAFQgBAIACACQAFAFABAEQACAIgDAFQgDADgCAAQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAgBAAgBQgDgHgFAAIgMADQgNACgCgBIgFgDQgEgCgDAAQgKABgFAFQgCACgEAIIgBAGQgBAAAAABQAAABgBAAQAAAAgBABQAAAAgBAAQgGACgCAEQgBAGAGABIAQAFQAAABAAAAQABAAAAABQAAAAAAAAQAAABAAAAQACAEgEgCQgBAAAAAAQgBAAAAAAQAAAAgBABQAAAAAAAAIgCAXQgDAJgGADQgJAGgGgCIgKgEIgDgCQgBAAAAAAQgBAAAAAAQAAAAgBABQAAAAgBAAQgHAEACAFIAEAHIADAEQAAADgDACIgGADIgEABIgJAFQgFAEgEAAIgCAAg");
          }, this.shape.setTransform(-.0107, .0173), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.gansu, new cjs.Rectangle(-77.9, -69.5, 155.8, 139.1), null), (g.fujian = function (A, g, Q) {
          var _this31 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this31.shape.graphics.f(A).s().p("AhfEmQgDgHgKgRQgJgQgBgFQAIgFgMgYIgTghQgEgJgIgDIgUgGIgVgGIgegIIgLgDQgBAAAAAAQgBAAAAgBQAAAAgBgBQAAAAAAgBQgIgTAGgQIAMgXQgDgPAJgTQAIgOgEgDQgDgQARgCIAMgLQAHgHADgEQACgEgHgDQgJgDAAgDQAAgGAJgHQACgBABgFQACgFAIACQAEgLgHgNQgGgNAEgPQAAgNANgHIAcgPQAOgLADgVQAEgTgJgJQgLgKABgFQABgBAIgEQAJgEACgEIAGgMIAGgKIAPgLQAGgGADADIAJAKQAGAGAFgCQAEgCAKgKQACgCANgEIAfgQQAKgDgEgKQgFgKADgDQACgCAEAAIAJAAIAJgCQAHgCAEAAQALAAABAGQABADgCAJQAAAEgDAJQgCAIAIAIQAJAIAEARQADANAAALIgBAGQAAAAAAABQAAAAABAAQAAAAABAAQABAAABAAIAMgCQAJgBAFACQAKAGAFgEIAFgHQAEgFADgBQAIgCABgFIADgOQADgJAJAOQAIAMACAJQAFAWAQgGIAZgHQALgEAGACQADAAAEgCQAEgBABABQAEACABAIIgDgBQgDABgCgBIgEgDIgGAAQgEgBgBAGIABAFQAAABABAAQAAAAAAgBQAAAAABAAQAAgBAAAAQAEgHAFAEQABABAAABQABAAAAABQABAAAAAAQABAAAAgBQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAABQAAAAABAAQAAAAAAABQAAAAAAABQgBAEAEABQABAAABAAQABABAAAAQAAAAABAAQAAABgBAAQgDACgBACQAAACgFABQgCAAgFgDQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABQABAAAAABQADACAAADIAAAFIAAAGQgBAFgCAAIgHAAQgCAAgFAEQgFAEABABQADAJADAAQADAAACAEQABAFgCAAQgDACADAEQACAEgDADQAAAAgBABQAAAAAAAAQgBAAAAgBQgBAAAAgBQgBAAAAAAQAAAAgBAAQAAAAgBAAQgBAAAAAAIgQAOQgBABgBAAQAAAAgBAAQgBAAAAAAQAAAAgBAAQgCgCADgEQADgFAFgDQADgCACgGQADgGACgCQACgCAAgDQAAAAAAgBQAAAAAAAAQgBgBAAAAQAAAAgBAAQgFACgCgBIgDgBQgBABAAAAQAAAAAAAAQAAABAAAAQAAAAAAABQABAEgBACIgCAFQgBABAAABQAAAAgBABQAAAAgBAAQAAAAgBAAIgEgBQgFABACgFQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBIgBgFQACgCAAgDQAAgBAAAAQAAgBgBAAQAAAAgBAAQAAABgBAAQgDACgCAHIgBAEQgBAAAAABQgBAAAAABQAAAAAAABQAAABAAAAQgBADgEgEIgIgGQgBAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAIgBADQgCAHAEAAQAAAAABAAQAAAAABAAQABABAAAAQABAAAAABQABAAAAABQAAAAAAABQAAAAgBABQAAAAAAABQgEADABACQADAEACgDQAEgEAFACQAJACABAGQABAGADACQAEADgEADQgCACgGgCQgFgCgCgCQgBgBgFABQgGABABACQAAABAAABQAAAAABAAQAAAAABAAQABAAABAAQAHgBAAADQgBAEADADIADAFQAAAAAAAAQABABAAgBQABAAAAgBQABAAAAgBQACgEADgDIAEgEQAAAAAAgBQABAAAAAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAAAAAABQABAAAAABQABAGADgCIAGAAQAAAAAAAAQABABgBAAQAAAAAAABQgBAAAAAAQgNAKgDAAQgHgBgCADQgCAFgCABIgDAFQgBAEgDACQgFACgBADQAAAEgCACQgDADAEAAQAHgBACABQADACAFgCQAGgDAAAGQAAAIgDAEIgHAGQgEAEADABQAFABgBAFQgCAGAAACQABAEgFAAIgKAAIgEAFQAAABAAAAQABABAAAAQAAAAABAAQABAAABAAIAEADQACADAEAAQADAAgCAGQgCAFADgBQADgBADADIADADQABABAAAFIgBAEQgBAFgDgGQgBAAAAgBQgBAAAAAAQgBgBAAABQgBAAAAAAQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAAAAAIgDADIgEABQAAAAAAAAQgBAAAAgBQAAAAABgBQAAAAAAgBQAEgGgDgDIgCgEQgDgDgCAAQgGAAgCgEIgCgGQAAgBgBAAQAAAAAAAAQgBgBAAAAQAAABgBAAQAAAAgBAAQAAABAAAAQAAABAAAAQAAABAAABIACAFQAAABAAABQABAAAAABQAAAAAAABQAAAAgBABIgBAEQAAABAAAAQAAABAAAAQAAABAAAAQgBAAAAAAIgEgBQgDgCgGADIgBAAIgCACIgEADIAAABIABADQACADAFABIANADIAIAFQADAEgFAAQgIgBABAEQACAHgFgCQgDgCgDABQgEACgBADQAAABAAABQAAAAAAABQgBAAAAABQAAAAAAAAIgIAEQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQgBgGgEgEIgCgCQAAAAAAgBQAAAAAAgBQAAAAAAAAQABgBAAAAIAFgDIACgCQAAAAAAAAQgBAAAAAAQAAgBAAAAQgBAAAAAAIgGABIgHAEQgCABgBAAQgBABAAAAQAAABAAAAQAAAAABAAQAEAAABACQADAIgBADIABAEQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQgKAAAEADQAFADABACQACAEAEgEQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAQAAgBABABQAAAAAAAAQAAABAAAAQgCAFACACQAAAAAAABQAAAAAAABQAAAAAAABQAAABAAAAIgJgBIgCACQAAABAAAAQAAABABAAQAAABABAAQAAAAABABQAGADgBAAQAAABgHAAQgGgBgBABQgDADgDAAIgFABIgEgBQgCgBgDABQgBAAgBABQAAAAgBABQAAAAAAABQAAAAABABIACADQABAEAKgCQABAAAAAAQABAAAAAAQAAAAABABQAAAAABAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAgBAAQgFAFAAACIgBAEIgDgBQgBAAAAAAQgBAAAAABQgBAAAAAAQAAAAAAAAIgBACIAFAFIgCACIgEAHQgCAGgDAAQgCgBAAgFQACgIgGACIgFAAQgBAAgDgGIgDgGQgBAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAIABAJQAAAAAAABQgBAAAAABQAAAAgBABQAAAAgBAAIgGAAQgDABgCACIgEAEQAAABgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgHgFABgGQAAgDgBgCQgBAAAAAAQgBgBAAABQAAAAgBAAQAAABAAAAQgCAGgCADIgBABQAAAAAAABQAAAAABAAQAAAAAAABQAAAAABAAQAAABABAAQABABAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAABABAAQAAAAABABQAAAAABAAQAGAAgDAGQgCAEgDACQgFADgDgEQgBgDABgEQAEgJgEABIgEAAIgEgBQgBAAAAAAQAAAAgBAAQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAAAABQAAAAAAABQAAAAAAAAIAEABQAGAAAAADIgCAGQAAABgBAAQAAABAAAAQgBAAAAAAQgBAAgBAAIgHgBIgGABQgBABAAAAQgBAAAAABQAAAAABABQAAABABABQADADAFAAIAHgCQAEgCAJAKQACACAAADQAAABAAABQgBAAAAABQAAAAAAABQgBAAAAAAIgGADQAAADgHAFQAAAAgBABQAAAAAAAAQgBAAAAgBQAAAAAAgBQgBgEgEACQgBABAAABQAAABAAAAQgBABABAAQAAABAAAAIABABQAAAAABAAQAAAAAAABQgBAAAAAAQAAAAAAABQgDADABAGQABAGgDABQgEAAgDAEIgFAKIgCACQgBAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAgBIADgHQAEgGgBgBIgDABQAAAAgBAAQgBABAAAAQgBAAAAAAQgBAAAAgBQgDgBgCAEQgCADABACIABADIgBACQgCADABAEQACACAAAFQAAAGgCABIgEAFQAAAAAAABQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAgBAAAAQAAgBABgBIADgFIAAgFQgDgJgDgCQgEgCgGgBIgIgBIgCABQgBABAAAAQAAAAAAAAQABABAAAAQAAAAABAAIAHADQAIABgFAEQgDADgCAEQgCAGgDgDQgCgCgGABQgGABAAACQgBAAAAAAQAAAAAAABQAAAAABABQAAABAAABQACADgBAHQAAABAAAAQABABgBAAQAAABAAABQgBAAAAABIgCAAIAAAAIgCgJQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAAAABQAAAAAAABIABAHQAAAAAAAAQgBABAAAAQAAAAgBAAQAAAAgBAAQgGABgBAEIgDABQgEAAgEgFg");
          }, this.shape.setTransform(-.016, .0196), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.fujian, new cjs.Rectangle(-24.3, -29.9, 48.7, 59.9), null), (g.chongqing = function (A, g, Q) {
          var _this32 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this32.shape.graphics.f(A).s().p("ABvEAQgJAAgCgDQgBgEABgFQACgHAAgEQAAgHgDgDQgBAAAAgBQgBAAAAAAQgBABAAAAQgBAAgBAAQgCACAAAFQABAHgCABQAAAAAAABQgBAAAAAAQgBAAgBABQAAAAgBAAQgBAAAAAAQgBgBAAAAQgBAAAAgBQAAAAAAgBQgCgNABgDQAFgNgCgDQgDgDgCgBIgUgJQgDgCABgFIAFgMQAAgKgDgEIgDgJQgBgGgCAAIgOABIgRAEIgOADQgFgBgBgEQgDgKgDgDQgHgHgHgBIgHgBQgGABgEACQgDABgBAFIgBAHIgBALQABAJgCAFQgDAJgKACQgDABgHgLQgFgHgJACQgKADAAAFQgBAFgCAAIgIABQgDACAAAFQABANgGAFIgKAMQgEAEgEgDQgCgDAAgMQABgOgFgIQgDgFgIgBQgHAAAIAQIACAGQACAHgCACQgCAEgIABQgIABgBgCQgBgCgBgLQgBgLgCAAIgEgRQAAgDgGgBIgQgGQgHgDgFACQgFADgDgBQgKgDgCgfIgCgMIgJAAQgHAAgCgEIgBgLQgBgEgFgDQgHgDgDgGQgDgHAKgIQAJgHAHAAQADAAACgHQADgHACgBQADgBACgEIADgLQACgHgFgGIgLgJQgEgDADgDQAEgFAAgDQAAgEACgBIAGgBQADgBACgEIAEgKQACgFAMAEIATAJQAGADADAEIAGAKQAEAGAKgFIAVgJQAJgDACAGIAEASQAEAKAHABQADAAAGgBIAHgCQABAAABgBQABAAABAAQAAABAAAAQABAAAAAAQABACAMgJQAEgDALgTIAOgaQAJgMgDgIQgBgEABgCIAEgIQACgFAJABQALACADgDQADgCACgEIACADIAFAHQADABADgCQAHgHgCgIQgBgDAEgEIAFgJIABgHQAAgEACgEQADgEAAgFIAAgFQANgMACgGQADgLAGAAQADAAAFgFIAPgLQAJgGgHgJQgEgEgNgJQgHgEAAgDIgBgKIgBgHQAAAAAAgBQgBgBAAAAQAAgBABAAQAAAAAAgBQACgCAHABQAEABABgEQABgDgDgGQAAgBAAAAQgBgBABgBQAAAAAAgBQAAAAABAAIAHgBIACAAIACgBIAxAgIAKAEQAKAHAIALQACADACAGQABAEAJABQASAAAFgCQABAAAAAAQABAAAAgBQABAAAAgBQAAAAAAgBIAHAEQAHAEAAAFIgBAKQAAAEAFACIAMACQAHACADADIALAIQAHAEABAGQADAQgEAHQgEAFACAKIABALQgBAFgDADIgFAHQgCADgGgDQgSgKgPAQQgIAJgIAGIgMAIIgHAKQgCADgCgIQgCgJgGAEIgJAGQgGAAgCgBQgCgBAAgFQABgGgFAAQgGAAgHAHQgIAIgGADQgIADgCgGQgBgHgDABQgCAAgEAFQgCABgKACQgJABABAGIACAKIAFAIQALANgHAKQgDAEABAFQACAFgCAEIgDAJQgBAEgIgBQgHgBADAIQADAJADABQAGACAEgKQAFgNAJARQAEAIACACIAHAFIAHAGQADAEAAAIQAAAHADAEQADADAAAEQAAAGABACQABACAEgDQAOgIABANIABAMQABAEAEADIAHAFQAHAFgBAEIgFAbQgBAHABABQACAEgDABQgEADAAADQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAGAAAAACIgBAIIgCAHQAAAHgDABQgFACgFALIgFAOQgCAEgEABIgHAAIgNgBg");
          }, this.shape.setTransform(.0078, .0167), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.chongqing, new cjs.Rectangle(-25.8, -25.7, 51.7, 51.5), null), (g.beijing = function (A, g, Q) {
          var _this33 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this33.shape.graphics.f(A).s().p("AgGBmIgHgKQgEgGgGACQgDACgLgBQgIAAgDADQgJALgEgHQgFgHgHABQgEABgDgDQgDgDAAgEQgBgCgFgGQgEgFAEgBQAFgBACgEQACgFgEgDQgLgLAFgFQADgEAAgBIAHgGQAIgFAFgCQADAAAFgEQAAAAABgBQABAAAAAAQABAAAAAAQAAAAABABQABACADgGIAFgKQACgCgFgGIgLgMQgFgFACgIQACgHAFgBIAKgBQAIgBADgEIAIgNQAGgIAEAAQATAAgHgIQgNgNALADQAHACgCgGQgBgEADgCQAFgDACgCQAFgHAEAGQAJAPADADIAMAOQAGAGAEgBQADgBAJABIAPACIAMgBQAFgBgCADIgDAIQAAABAAABQgBABAAAAQAAAAgBABQAAAAgBAAQgEgBgEACQgEADAAAEQgBALAFALIALANQAGAGgGAFQgKAHgNAHQgIAEgKgCQgGgCgHAFIABACIAAAJIgCAJQgBAEAFAHQADAFAIABIgBADIgFAMQgDAGgDgCQgGgCgGABQgJAAgDAFIgHAJQgDACABADQACADgFACIgCAAQgDAAgCgCg");
          }, this.shape.setTransform(.0254, -.009), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.beijing, new cjs.Rectangle(-9.2, -10.4, 18.5, 20.8), null), (g.anhui = function (A, g, Q) {
          var _this34 = this;

          this.initialize(A, g, Q, {}), this.shape = new cjs.Shape(), this.change = function (A) {
            _this34.shape.graphics.f(A).s().p("AByE+IgIgJQgFgEgNABQgQACgGgBQgLgCgDgCQgCgCgFgJQgGgJgDgCQgDgBgHAAQgGAAgBgDIgCgHQgBgFgFADQgEACgDAFQgCADACAHQACAGgCACQgFAEgMAOIgIAIQgFADgFgEIgIgDQgEgDABgEIAFgLQABgFAHgJQAHgJABgDQABgEgHgEIgOgIQgaAXgTAHQgKAFgKgBQACgIgDgNQgCgMgFgJQgEgDgEgIQgFgIgDgDQACgLgGgMQgCgFgJgNQgBgeAegGQAAgDgEgDIgHgFQgEgIgGgBIgbgKQgDgBgBAEQAAABgBABQAAAAgBABQAAAAAAAAQgBAAAAAAIgNgNQgLgLgFgEIAOAJIgGgGIgBgKQgBgJANgPQAMgQAMgCQALgBADgCQACgBADgJQACgGgGgmIgCgMIgEgPIgBgKQADgOgDACIgMALIgEAEQgBgCgEACQgLADgGgEQgDgCgGgBIgOgEQgNgFAAgXQAAgHgHgEIgRgEQgIgCAAgFIAAgMQAAgHADAAQACgBADAEQADADAFgBIAQgEQAJgDABgOQABgKgCgIQgGgVAXgEQAOgDgDgIQgFgNAAgBQADgFgCgEIgEgJQgCgFAGgHQAFgGAGgDQABgBAFAEQAEADACgDQAEgGAHADQAFAEABAGQAAAEADAFIAIAMQAJANAHgHIAMgIQAMgHAHgHQAJgIAAgDIgDgHIgEgJQgCgEAAgHQABgIgCgDQgCgCgFABQgEAAgDgBIgJgDQgGgCgFgGIgHgJQgEgCADgHIAEgHIgCAAQAQgOASAMIATANQAJAHAEAAQATADABAPQACAUAZACIAZABQASADAEALIAGATQADAFANgDIAVgGQAGAAAAALQAAAIgJAVQgHASACAGQADAJADADQADADAIABQAKABADAEQAFAEACAPQACALgBAGQABABAPAFQAZAKAEgUQAEgRACgCQAFgEASAHQAMAFAFAPQAFANgCAPQgCAMgJgDIgRgKQgKgGgWAGQgHABAGAIIALANQAEAEgEALQgFALgHACQgFACgFAHIgGANQgCAGAIAMQAIANAGAAQAHgBAEADQAFADgCADQAAABAAABQAAAAAAABQAAABABAAQAAAAABABQADABAEgDQADgCADACIAHAEQAFACgBAMQgBAMgHAGQgHAFABACIAFAIQACAFARgDQAOgDAHgDQAEgDAKgBQAJAAAAAEQgCAKAUAAQAFABACADQACACgCARQgBAUgFAHQgBANgIACQgMACgCACQgCATASgFQgDAEgBAGIgBAHQgBAGgMACIgSADQgCAAgGgCQgFgCgCACIAAAKQABAIgBAEQAFAMgEAMQgCAGgIAQQgOAegRAJIgeASQgDgBgEgGg");
          }, this.shape.setTransform(.0125, -.0093), this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
        }).prototype = getMCSymbolPrototype(g.anhui, new cjs.Rectangle(-25.6, -32.4, 51.2, 64.9), null), (g.map2 = function (A, Q, I) {
          this.initialize(A, Q, I, {});
          var C = new B.a().lib;
          this.instance_1 = new C.linesmc(), this.instance_1.parent = this, this.instance_1.setTransform(275.85, 228.45, 1, 1, 0, 0, 0, .5, -.7), this.instance_1.alpha = 1, this.instance_1.cache(-276, -229, 604, 474), this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));
          var D = this.pool = {};
          this.instance_2 = new g.hainan(), this.instance_2.parent = this, this.instance_2.setTransform(341.6, 443.5), D["海南"] = this.instance_2, this.instance_3 = new g.guangdong(), this.instance_3.parent = this, this.instance_3.setTransform(382.55, 397.05), D["广东"] = this.instance_3, this.instance_4 = new g.guangxi(), this.instance_4.parent = this, this.instance_4.setTransform(323.8, 384.6), D["广西"] = this.instance_4, this.instance_5 = new g.guizhou(), this.instance_5.parent = this, this.instance_5.setTransform(305.35, 346.15), D["贵州"] = this.instance_5, this.instance_6 = new g.yunnan(), this.instance_6.parent = this, this.instance_6.setTransform(250.1, 363), D["云南"] = this.instance_6, this.instance_7 = new g.chongqing(), this.instance_7.parent = this, this.instance_7.setTransform(318.95, 305), D["重庆"] = this.instance_7, this.instance_8 = new g.sichuan(), this.instance_8.parent = this, this.instance_8.setTransform(269.85, 300.25), D["四川"] = this.instance_8, this.instance_9 = new g.hunan(), this.instance_9.parent = this, this.instance_9.setTransform(360.4, 340.7), D["湖南"] = this.instance_9, this.instance_10 = new g.jiangxi(), this.instance_10.parent = this, this.instance_10.setTransform(409.15, 340), D["江西"] = this.instance_10, this.instance_11 = new g.fujian(), this.instance_11.parent = this, this.instance_11.setTransform(434.3, 354.9), D["福建"] = this.instance_11, this.instance_12 = new g.hubei(), this.instance_12.parent = this, this.instance_12.setTransform(366.55, 292.7), D["湖北"] = this.instance_12, this.instance_13 = new g.henan(), this.instance_13.parent = this, this.instance_13.setTransform(378.75, 257.25), D["河南"] = this.instance_13, this.instance_14 = new g.anhui(), this.instance_14.parent = this, this.instance_14.setTransform(418.9, 278.6), D["安徽"] = this.instance_14, this.instance_15 = new g.shanghai(), this.instance_15.parent = this, this.instance_15.setTransform(463.45, 286.2);
          var E = new cjs.Shape();
          E.graphics.f("rgba(0,0,0,0.01)").dc(10, 0, 20), this.instance_15.addChild(E), D["上海"] = this.instance_15, this.instance_16 = new g.zhejiang(), this.instance_16.parent = this, this.instance_16.setTransform(451.85, 311.85), D["浙江"] = this.instance_16, this.instance_17 = new g.jiangsu(), this.instance_17.parent = this, this.instance_17.setTransform(437.65, 264.7), D["江苏"] = this.instance_17, this.instance_18 = new g.taiwan(), this.instance_18.parent = this, this.instance_18.setTransform(469.45, 380.3), D["台湾"] = this.instance_18, this.instance_19 = new g.xizang(), this.instance_19.parent = this, this.instance_19.setTransform(122.25, 262.8), D["西藏"] = this.instance_19, this.instance_20 = new g.xinjiang(), this.instance_20.parent = this, this.instance_20.setTransform(109.7, 126.55), D["新疆"] = this.instance_20, this.instance_21 = new g.qinghai(), this.instance_21.parent = this, this.instance_21.setTransform(204.1, 226.7), D["青海"] = this.instance_21, this.instance_22 = new g.gansu(), this.instance_22.parent = this, this.instance_22.setTransform(251.85, 203.55), D["甘肃"] = this.instance_22, this.instance_23 = new g.ningxia(), this.instance_23.parent = this, this.instance_23.setTransform(303.8, 213.35), D["宁夏"] = this.instance_23, this.instance_24 = new g.shanxi1(), this.instance_24.parent = this, this.instance_24.setTransform(325.6, 235.25), D["陕西"] = this.instance_24, this.instance_25 = new g.shanxi0(), this.instance_25.parent = this, this.instance_25.setTransform(365.4, 209.5), D["山西"] = this.instance_25, this.instance_26 = new g.shandong(), this.instance_26.parent = this, this.instance_26.setTransform(429.2, 223.15), D["山东"] = this.instance_26, this.instance_27 = new g.tianjin(), this.instance_27.parent = this, this.instance_27.setTransform(412.85, 183.8), D["天津"] = this.instance_27;
          var F = new cjs.Shape();
          F.graphics.f("rgba(255,0,0,0.01)").dc(0, 0, 15), this.instance_27.addChild(F), F.x = 10, F.y = 12, this.instance_28 = new g.beijing(), this.instance_28.parent = this, this.instance_28.setTransform(402.95, 173.7), D["北京"] = this.instance_28;
          var t = new cjs.Shape();
          t.graphics.f("rgba(255,0,0,0.01)").dc(0, 0, 15), this.instance_28.addChild(t), this.instance_29 = new g.heibei(), this.instance_29.parent = this, this.instance_29.setTransform(406, 186.1), D["河北"] = this.instance_29, this.instance_30 = new g.neimenggu(), this.instance_30.parent = this, this.instance_30.setTransform(348.5, 108.85), D["内蒙古"] = this.instance_30, this.instance_31 = new g.liaoning(), this.instance_31.parent = this, this.instance_31.setTransform(456.8, 157.4), D["辽宁"] = this.instance_31, this.instance_32 = new g.jilin(), this.instance_32.parent = this, this.instance_32.setTransform(488.55, 123.35), D["吉林"] = this.instance_32, this.instance_33 = new g.heilongjiang(), this.instance_33.parent = this, this.instance_33.setTransform(490.4, 59.5), D["黑龙江"] = this.instance_33, this.timeline.addTween(cjs.Tween.get({}).to({
            state: [{
              t: this.instance_33
            }, {
              t: this.instance_32
            }, {
              t: this.instance_31
            }, {
              t: this.instance_30
            }, {
              t: this.instance_29
            }, {
              t: this.instance_28
            }, {
              t: this.instance_27
            }, {
              t: this.instance_26
            }, {
              t: this.instance_25
            }, {
              t: this.instance_24
            }, {
              t: this.instance_23
            }, {
              t: this.instance_22
            }, {
              t: this.instance_21
            }, {
              t: this.instance_20
            }, {
              t: this.instance_19
            }, {
              t: this.instance_18
            }, {
              t: this.instance_17
            }, {
              t: this.instance_16
            }, {
              t: this.instance_15
            }, {
              t: this.instance_14
            }, {
              t: this.instance_13
            }, {
              t: this.instance_12
            }, {
              t: this.instance_11
            }, {
              t: this.instance_10
            }, {
              t: this.instance_9
            }, {
              t: this.instance_8
            }, {
              t: this.instance_7
            }, {
              t: this.instance_6
            }, {
              t: this.instance_5
            }, {
              t: this.instance_4
            }, {
              t: this.instance_3
            }, {
              t: this.instance_2
            }]
          }).wait(1));
        }).prototype = A = new cjs.MovieClip(), A.nominalBounds = new cjs.Rectangle(300, 235, 300.6, 235.10000000000002);
      }

      return _class7;
    }();
}, function (A, g, Q) {
  "use strict";

  var B = Q(10);

  g.a =
    /*#__PURE__*/
    function (_createjs$MovieClip3) {
      _inherits(_class8, _createjs$MovieClip3);

      function _class8(A) {
        var _this35;

        _classCallCheck(this, _class8);

        _this35 = _possibleConstructorReturn(this, _getPrototypeOf(_class8).call(this));
        var g = new cjs.MovieClip();

        _this35.addChild(g);

        var Q = _assertThisInitialized(_this35);

        g.init = function () {
          var _this36 = this;

          this.width = 360, this.height = 240;
          var A = Q.s = new cjs.Shape();
          A.graphics.f("rgba(0,0,0,0.7)").rr(0, 0, this.width, this.height, 10), this.addChild(A);
          var g = new cjs.Shape();
          g.graphics.f("rgba(255,255,255,0.6)").dr(0, 0, this.width, 1), this.addChild(g), g.x = 0, g.y = 150;
          var I = new cjs.Shape();
          I.graphics.f("rgba(255,255,255,0.6)").dr(0, 0, 1, 30), this.addChild(I), I.x = this.width / 2, I.y = 180;
          var C = new cjs.Text("", "40px Arial", "#ffffff");
          C.textAlign = "center", C.x = .5 * this.width, C.y = 30, this.addChild(C);
          var D = new cjs.Text("", "36px Arial", "#ffffff");
          D.textAlign = "center", D.x = .5 * this.width, D.y = 90, this.addChild(D);
          var E = new cjs.Text("分享", "36px Arial", "#ffffff");
          E.textAlign = "center", E.x = .25 * this.width, E.y = 175, this.addChild(E);
          var F = new cjs.Text("关闭", "36px Arial", "#ffffff");
          F.textAlign = "center", F.x = .72 * this.width, F.y = 175, this.addChild(F);
          var t = new B.a(imagePool.xqicon);
          t.regY = t.height / 2, this.addChild(t), t.x = F.x + F.getBounds().width / 2 + 2, t.y = 195, t.scaleX = t.scaleY = 0;
          var G = new cjs.Shape();
          G.graphics.f("rgba(0,0,0,0.01)").dr(0, 0, this.width / 2, this.height), this.addChild(G), G.x = 0, G.addEventListener("mousedown", function (A) {
            main.emitEvent(_this36.data), main.handler.resetAll(), _this36.visible = !1, stage.update();
          });
          var e = new cjs.Shape();
          e.graphics.f("rgba(0,0,0,0.01)").dr(0, 0, this.width / 2, this.height), this.addChild(e), e.x = this.width / 2, e.addEventListener("mousedown", function (A) {
            main.gotoProvPage(_this36.data), main.handler.resetAll(), _this36.visible = !1, stage.update();
          });

          var i = function i() {
              console.log("special"), e.visible = !1, t.visible = !1, F.visible = !1, I.visible = !1, E.x = .5 * _this36.width, G.scaleX = 2;
            },
            s = function s() {
              e.visible = !0, t.visible = !0, F.visible = !0, I.visible = !0, E.x = .25 * _this36.width, G.scaleX = 1;
            };

          this.change = function (A) {
            this.visible = !0, this.data = A, "香港" == A.area || "澳门" == A.area || "台湾" == A.area ? i() : s(), this.uncache(), C.text = A.area, D.text = proData.subStr + "：" + A.value, this.cache(0, 0, this.width, this.height);
          };
        }, g.init(), g.regX = g.width / 2, g.regY = g.height / 2, _this35.show = function (A) {
          g.change(A), this.visible = !0, stage.update();
        }, _this35.hide = function () {
          this.visible = !1, stage.update();
        }, _this35.hide();
        return _this35;
      }

      return _class8;
    }(createjs.MovieClip);
}, function (A, g, Q) {
  "use strict";

  g.a =
    /*#__PURE__*/
    function () {
      function _class9(A) {
        _classCallCheck(this, _class9);

        var g = new createjs.Graphics(),
          Q = new createjs.Shape(g);
        return Q.changeImg = function (A) {
          g.c().bf(A, "no-repeat").dr(0, 0, A.width, A.height), Q.width = A.width, Q.height = A.height;
        }, Q.changeImg(A), Q.setPivotCenter = function () {
          Q.regX = Q.width / 2, Q.regY = Q.height / 2;
        }, Q;
      }

      return _class9;
    }();
}, function (A, g, Q) {
  "use strict";

  g.a =
    /*#__PURE__*/
    function (_createjs$MovieClip4) {
      _inherits(_class10, _createjs$MovieClip4);

      function _class10() {
        _classCallCheck(this, _class10);

        return _possibleConstructorReturn(this, _getPrototypeOf(_class10).call(this));
      }

      return _class10;
    }(createjs.MovieClip);
}, function (A, g, Q) {
  "use strict";

  g.a =
    /*#__PURE__*/
    function () {
      function _class11(A, g) {
        _classCallCheck(this, _class11);

        var Q;

        var _loop = function _loop(B) {
          var I = new cjs.Text(B, "12px Arial", "#000000");
          I.textAlign = "center", g.txt = I, g.addChild(I), I.x = g.pool[B].x, I.y = g.pool[B].y, g.pool[B].txt = I, "湖南" != B && "江西" != B || (I.y += -10), "广东" == B && (I.y += -15), "河北" == B && (I.x += -10, I.y += 10), "天津" != B && "陕西" != B || (I.x += 5), "江苏" == B && (I.x += 8), "内蒙古" == B && (I.x += 10, I.y += 40), "北京" == B && (I.x += -5, I.y += -10), "甘肃" == B && (I.x += 14, I.y += -10), "山东" == B && (I.x += -10, I.y += -5), "辽宁" == B && (I.x += 6, I.y += -10), "吉林" != B && "海南" != B || (I.y += -6), "黑龙江" == B && (I.x += 6, I.y += 10), (Q = g.pool[B]).change("#ffffff");

          var C = function C(A, g) {
            console.log(A, g);
          };

          Q.addEventListener("mousedown", function (g) {
            g.currentTarget.data && (A.resetAll(), tips.show(g.currentTarget.data), main.defaultArea = g.currentTarget.data.area, tips.x = g.currentTarget.x * A.sca, tips.y = g.currentTarget.y * A.sca, C(tips.x, tips.y), g.currentTarget.change("#FFE766"), g.currentTarget.txt.darkColor && (g.currentTarget.txt.color = "#000000"), A.last = g.currentTarget, stage.update());
          });
        };

        for (var B in g.pool) {
          _loop(B);
        }
      }

      return _class11;
    }();
}, function (A, g) {
  A.exports = {
    coverPsd: [{
      src: "map2_atlas_.png",
      id: "map2_atlas_"
    }, {
      src: "xqicon.png",
      id: "xqicon"
    }]
  };
}, function (A, g, Q) {
  "use strict";

  Q(1);
}, function (A, g, Q) {
  "use strict";

  g.a =
    /*#__PURE__*/
    function (_createjs$MovieClip5) {
      _inherits(_class12, _createjs$MovieClip5);

      function _class12(A) {
        var _this37;

        _classCallCheck(this, _class12);

        _this37 = _possibleConstructorReturn(this, _getPrototypeOf(_class12).call(this));
        var g = _this37.loader = new createjs.LoadQueue(!1, A.path, "Anonymous");
        g.setMaxConnections(3), g.loadManifest(A.ary), g.addEventListener("progress", function (A) {
          Math.floor(100 * A.loaded);
        }), g.addEventListener("fileload", function (A) {
          A && "image" == A.item.type && (imagePool[A.item.id] = A.result);
        }), g.addEventListener("complete", function (g) {
          A.call();
        });
        return _this37;
      }

      return _class12;
    }(createjs.MovieClip);
}, function (A, g, Q) {
  "use strict";

  g.a =
    /*#__PURE__*/
    function () {
      function _class13() {
        _classCallCheck(this, _class13);

        var A = document.createElement("div");
        A.style.position = "absolute", A.style.backgroundColor = "rgba(255,255,255,0.1)", A.style.top = "0px", A.style.left = "0px", A.style.width = "300px", A.style.height = window.innerHeight + "px", document.body.appendChild(A), A.style.zIndex = 9, A.style.overflowY = "scroll";
        var g = document.createElement("div");
        g.style.position = "absolute", g.style.backgroundColor = "rgba(100,100,100,0.2)", g.style.top = "0px", g.style.left = "300px", g.style.width = "80px", g.style.height = "30px", g.style.lineHeight = "30px", g.style.textAlign = "center", g.innerHTML = "open", document.body.appendChild(g);

        var Q = function Q() {
          A.style.left = "-300px", g.style.left = "0px", g.innerHTML = "open";
        };

        Q(), this.hide = function () {
          A.style.left = "-500px", g.style.left = "-500px";
        };
        var B = !1;
        g.addEventListener("mousedown", function (I) {
          (B = !B) ? (A.style.left = "0px", g.style.left = "300px", g.innerHTML = "close") : Q();
        });
        var I = document.createElement("p");
        A.appendChild(I), I.innerHTML = "&nbsp&nbspversion 1.0</br>", this.log = function (A) {
          I.innerHTML += "<span>&nbsp".concat(A, "</span></br>");
        };
      }

      return _class13;
    }();
}, function (A, g, Q) {
  "use strict";

  var B = Q(18);
  Q.n(B);
}, function (A, g) {
  A.exports = {
    getProvenceData: {
      ret: 0,
      data: [{
        day: "1.24",
        time: "00:25",
        country: "中国",
        area: "河北",
        dead: 1,
        confirm: 2,
        suspect: 0
      }, {
        day: "1.24",
        time: "00:59",
        country: "中国",
        area: "江西",
        dead: 0,
        confirm: 7,
        suspect: 0
      }, {
        day: "1.24",
        time: "00:53",
        country: "英国",
        area: "",
        dead: 0,
        confirm: 0,
        suspect: 4
      }, {
        day: "1.24",
        time: "01:30",
        country: "中国",
        area: "广西",
        dead: 0,
        confirm: 13,
        suspect: 0
      }, {
        day: "1.24",
        time: "21:57",
        country: "中国",
        area: "天津",
        dead: 0,
        confirm: 8,
        suspect: 0
      }, {
        day: "1.24",
        time: "21:16",
        country: "中国",
        area: "北京",
        dead: 0,
        confirm: 36,
        suspect: 0
      }, {
        day: "1.24",
        time: "00:00",
        country: "中国",
        area: "云南",
        dead: 0,
        confirm: 2,
        suspect: 0
      }, {
        day: "1.24",
        time: "04:40",
        country: "意大利",
        area: "",
        dead: 0,
        confirm: 0,
        suspect: 1
      }, {
        day: "1.24",
        time: "05:00",
        country: "墨西哥",
        area: "",
        dead: 0,
        confirm: 0,
        suspect: 4
      }, {
        day: "1.24",
        time: "07:57",
        country: "中国",
        area: "上海",
        dead: 0,
        confirm: 20,
        suspect: 34
      }, {
        day: "1.24",
        time: "08:00",
        country: "中国",
        area: "河南",
        dead: 0,
        confirm: 9,
        suspect: 0
      }, {
        day: "1.24",
        time: "08:00",
        country: "中国",
        area: "广东",
        dead: 0,
        confirm: 53,
        suspect: 0
      }, {
        day: "1.24",
        time: "08:00",
        country: "中国",
        area: "安徽",
        dead: 0,
        confirm: 15,
        suspect: 0
      }, {
        day: "1.24",
        time: "09:10",
        country: "中国",
        area: "黑龙江",
        dead: 1,
        confirm: 4,
        suspect: 0
      }, {
        day: "1.24",
        time: "09:16",
        country: "中国",
        area: "湖北",
        dead: 24,
        confirm: 13203,
        suspect: 0
      }, {
        day: "1.24",
        time: "09:21",
        country: "中国",
        area: "浙江",
        dead: 0,
        confirm: 1589,
        suspect: 0
      }, {
        day: "1.24",
        time: "09:28",
        country: "中国",
        area: "四川",
        dead: 0,
        confirm: 506,
        suspect: 0
      }, {
        day: "1.24",
        time: "09:08",
        country: "中国",
        area: "吉林",
        dead: 0,
        confirm: 3,
        suspect: 0
      }, {
        day: "1.24",
        time: "09:08",
        country: "中国",
        area: "香港",
        dead: 0,
        confirm: 3,
        suspect: 0
      }, {
        day: "1.24",
        time: "09:08",
        country: "中国",
        area: "澳门",
        dead: 0,
        confirm: 3,
        suspect: 0
      }, {
        day: "1.24",
        time: "09:30",
        country: "中国",
        area: "重庆",
        dead: 0,
        confirm: 27,
        suspect: 0
      }, {
        day: "1.24",
        time: "09:28",
        country: "韩国",
        area: "",
        dead: 0,
        confirm: 2,
        suspect: 0
      }, {
        day: "1.24",
        time: "09:31",
        country: "中国",
        area: "山东",
        dead: 0,
        confirm: 15,
        suspect: 0
      }, {
        day: "1.24",
        time: "09:37",
        country: "中国",
        area: "江苏",
        dead: 0,
        confirm: 9,
        suspect: 0
      }, {
        day: "1.24",
        time: "20:24",
        country: "中国",
        area: "贵州",
        dead: 0,
        confirm: 4,
        suspect: 0
      }, {
        day: "1.24",
        time: "10:39",
        country: "中国",
        area: "湖南",
        dead: 0,
        confirm: 24,
        suspect: 0
      }, {
        day: "1.24",
        time: "11:00",
        country: "中国",
        area: "海南",
        dead: 0,
        confirm: 8,
        suspect: 0
      }, {
        day: "1.24",
        time: "11:13",
        country: "中国",
        area: "内蒙古",
        dead: 0,
        confirm: 1,
        suspect: 2
      }, {
        day: "1.24",
        time: "11:07",
        country: "中国",
        area: "辽宁",
        dead: 0,
        confirm: 4,
        suspect: 0
      }, {
        day: "1.24",
        time: "15:19",
        country: "中国",
        area: "福建",
        dead: 0,
        confirm: 10,
        suspect: 4
      }, {
        day: "1.24",
        time: "17:46",
        country: "中国",
        area: "青海",
        dead: 0,
        confirm: 0,
        suspect: 1
      }, {
        day: "1.24",
        time: "18:00",
        country: "中国",
        area: "宁夏",
        dead: 0,
        confirm: 2,
        suspect: 0
      }, {
        day: "1.24",
        time: "19:00",
        country: "中国",
        area: "陕西",
        dead: 0,
        confirm: 5,
        suspect: 0
      }, {
        day: "1.24",
        time: "20:09",
        country: "中国",
        area: "台湾",
        dead: 0,
        confirm: 3,
        suspect: 0
      }]
    }
  };
}]);
