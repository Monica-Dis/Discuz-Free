/* eslint-disable */
//AppPlatform.Survey.Digg.init({
//  PrjId: 23311878,
//  SubjId: 13575399,
//  DiggMode: 0,
//  ShowResult: 1,
//  OptIdObject: {
//    '27661344': 0
//  }
//});

var showRtext = [
  '保护自己，关爱他人',
  '￼拒绝食用野生动物',
  '￼出门正确佩戴口罩',
  '￼减少不必要的聚会',
  '用后的口罩科学处理',
  '勤快洗手，病毒赶走',
  '配合查验，多些理解',
  '如有不适，科学就医',
  '共克时艰，同舟共济'
];

if (bbo.isNewsApp()) {
  $('.tail .open-or-download').html('点击关注最新动态');
  $('body').on('touchend', '.open-or-download', function () {
    window.location.href = 'https://view.inews.qq.com/a/TWF20191231026630US';
  });
  if (bbo.isAndroid()) {
    $('.show-text, .show-text-area').text('点击图片分享海报');
  }
  if (bbo.isIOS()) {
    $('.show-text, .show-text-area').text('长按图片分享海报');
  }

  // 底部button端内
  $('.tail .open-or-download')
    .addClass('inapp')
    .find('span')
    .html('点击了解更多疫情动态');
}

$('body').on('click', '.btn-share', function () {
  if (bbo.isMagApp()) {
    $('.bj-fixed-h').hide();
    mag.share('ALL', function (res) {
      mag.toast('分享成功');
    }, function () {
      mag.toast('分享失败');
    });
  } else {
    let height = $(window).height();
    $('.bj-fixed-share')
      .height(height)
      .fadeIn();
  }
});

$('body').on('touchstart', '.tabclose', function () {
  $('.bj-fixed').fadeOut();
});
$('body').on('click', '.bj-fixed-share', function () {
  $('.bj-fixed-share').fadeOut();
});

//磐石计数方法注入
$.ajax({
  url: 'https://panshi.qq.com/v2/vote/23311878?source=1',
  type: 'GET',
  dataType: 'jsonp',
  success: function (res) {
    $('.kon').text(res.data.votedtotal);
  }
});

$('body').on('click', '.ko', function () {
  $('.areaShareLoading').show();
  makeCanvas();
});

// 绘制全国海报
function makeCanvas() {
  jared.cleanMap();
  let canvas = document.getElementById('formap');
  let context = canvas.getContext('2d');

  canvas.width = 750;
  canvas.height = 1284;

  let bgImage = new Image();
  bgImage.crossOrigin = 'Anonymous';
  bgImage.src = 'source/plugin/minbbs_yiqing/src/img/sharebg.png';
  context.clearRect(0, 0, canvas.width, canvas.height);
  context.rect(0, 0, canvas.width, canvas.height);

  context.fillStyle = '#fff';
  context.fill();

  bgImage.onload = () => {
    context.drawImage(bgImage, 0, 0, 750, 1284);
    let mapBase = new Image();
    let _canvas = $('.chmap canvas');
    mapBase.src = _canvas.get(0).toDataURL();
    mapBase.width = 540;
    mapBase.height = 403;
    mapBase.onload = () => {
      context.drawImage(mapBase, 110, 382, 540, 403);
      let bottomTips = new Image(540, 196);
      bottomTips.crossOrigin = 'Anonymous';
      bottomTips.src = 'source/plugin/minbbs_yiqing/src/img/mapLegend_v5.png';
      bottomTips.onload = () => {
        context.drawImage(bottomTips, 80, 645, 540, 151);
        // 绘制截至日期
        context.font = '30px Arial';
        context.fillStyle = '#222222';

        context.fillText('统计截至 ' + $('.topdataWrap .timeNum .bottom .d span').html(), 80, 230);

        // 绘制确诊
        context.font = 'normal normal 600 48px arial';
        context.fillStyle = '#d81d1b';
        context.textAlign = 'center';

        console.log($('.ic-number').text());
        context.fillText($('.recentNumber .confirm .number').html(), 136, 320);

        context.fillStyle = '#f7ab1a';
        context.fillText($('.recentNumber .suspect .number').html(), 300, 320);

        context.fillStyle = '#178b50';
        context.fillText($('.recentNumber .cure .number').html(), 465, 320);

        context.fillStyle = '#66666c';
        context.fillText($('.recentNumber .dead .number').html(), 620, 320);

        context.fillStyle = '#222222';
        context.font = '28px Arial';
        context.fillText('全国确诊', 136, 360);
        context.fillText('疑似病例', 300, 360);
        context.fillText('治愈人数', 465, 360);
        context.fillText('死亡人数', 620, 360);

        let showTxt = showRtext[Math.floor(Math.random() * showRtext.length)];
        context.fillStyle = '#ffffff';
        context.font = '40px Arial';
        context.fillText(showTxt, 370, 955);

        context.font = '26px Arial';
        let kon = $('.kon').text();
        context.fillText(`我是第${kon}位行动者`, 370, 1030);

        let dataString = canvas.toDataURL('image/png');
        $('.previw-img').attr('src', dataString);
        // eslint-disable-next-line no-invalid-this
        //AppPlatform.Survey.Digg.digg(this, 23311878, 13575399, 27661344);
        $('.areaShareLoading').hide();
        let height = $(window).height();
        $('.bj-fixed').height(height).fadeIn();
        if (bbo.isMagApp()) {
          mag.setData({
            shareData: {
              type: 1,
              imageurl: dataString,
              picurl: dataString, //4.0.9起不需要再设置picurl
            }
          });
          mag.share('ALL', function (res) {
            mag.toast('分享成功');
          }, function () {
            mag.toast('分享失败');
          });
          upload64image(dataString);
          return 0;
        }
      };
    };
  };

  // 分享全国疫情地图
  bossConfig.ei = 'boss_epidemic_h5_action';
  bossConfig.subType = 'shareBtnClick';
  bossConfig.pageArea = 'toast';
  bossConfig.openid = bosskv.openid || bosskv.unionid || '';
  bossConfig.omgid = bossConfig.omgid || '';
  bossConfig.chlid = channel_name;
  bossConfig.pageFrom = bbo.isNewsApp() ? 'inapp' : 'outapp';
  reporter(bossConfig, bosskv);
}

// 新闻客户端
function upload64image(str) {
  var fd = new FormData();
  fd.append('uploads', str);
  $.ajax({
    type: 'POST',
    processData: false,
    contentType: false,
    url: 'https://yc.static.qq.com/?service=App.Uplode_Uplode.uploads',
    data: fd,
    success: function (res) {
      saveLocalFun(res.data.url);
    }
  });
}

// 保存到大图相册
function saveLocalFun(imgstring) {
  // if (bbo.isNewsApp() && bbo.isIOS() && window.TencentNews && window.TencentNews.saveImageToLocal) {
  //   window.TencentNews.saveImageToLocal(window.saveLocalUrl, 'png');
  // }

  if ((bbo.isAndroid() && bbo.isNewsApp()) || (bbo.isIOS() && bbo.isNewsApp())) {
    var showBigImageShareMenu = function () {
      var jsonObject = {
        url: imgstring,
        onCallback: function () {}
      };

      if (window.TencentNews && window.TencentNews.showBigImageShareMenu) {
        window.TencentNews.showBigImageShareMenu(jsonObject);
      }
    };
    showBigImageShareMenu();
    $('.areaShareLoading').hide();
  }
}

// 了解更多疫情状态
document.querySelector('.open-or-download').addEventListener('click', function () {
  downapp.run();
  bossConfig.ei = 'boss_epidemic_h5_action';
  bossConfig.subType = 'h5ToAppClick';
  bossConfig.pageArea = '6';
  bossConfig.pageFrom = bbo.isNewsApp() ? 'inapp' : 'outapp';
  reporter(bossConfig, bosskv);
});


// 关注更多实时疫情(头部)
$('body').on('touchend click', '.jump', function () {
  downapp.run(
    `qqnews://article_9500?tab=news_news&channel=news_news_antip&from=xiaoai&behavior=checkPush&force=1&pagetype=h5epidemic&startextras=%7B%22from%22%3A%22weixin%22%2C%22pagetype%22%3A%22h5epidemic%22%2C%22force%22%3A1%7D`
  );
  // H5拉活入口点击
  bossConfig.ei = 'boss_epidemic_h5_action';
  bossConfig.subType = 'h5ToAppClick';
  bossConfig.pageArea = '1';
  bossConfig.pageFrom = bbo.isNewsApp() ? 'inapp' : 'outapp';
  downapp.checkAppIsInstalled(function (status) {
    if (status) {
      bossConfig.isNewInstall = 1;
    }
  });
  reporter(bossConfig, bosskv);
});

// 首页曝光
bossConfig.ei = 'boss_epidemic_h5_action';
bossConfig.subType = 'pageExp';
bossConfig.pageFrom = bbo.isNewsApp() ? 'inapp' : 'outapp';

if (bbo.isNewsApp() && window.TencentNews) {
  bossConfig.shareFromUser = bosskv.openid || bosskv.unionid || bossConfig.devid || '';
  reporter(bossConfig, bosskv);
} else if (bbo.isNewsApp()) {
  document.addEventListener('TencentNewsJSInjectionComplete', function () {
    bossConfig.shareFromUser = bosskv.openid || bosskv.unionid || bossConfig.devid || '';
    reporter(bossConfig, bosskv);
  });
} else {
  reporter(bossConfig, bosskv);
}
reporter(bossConfig, bosskv);