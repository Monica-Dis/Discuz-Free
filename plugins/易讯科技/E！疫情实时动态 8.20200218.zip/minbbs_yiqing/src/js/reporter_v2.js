// 上报相关
// BOSS上报相关
function _get(url, data) {
  let g_btrace_BOSS = new Image(1, 1);
  g_btrace_BOSS.src = `${url}${bbo.objectParam(data)}&extra="${JSON.stringify(bosskv)}"`;

  // console.log('上报参数', data);
  // console.log(g_btrace_BOSS.src);
}

let bossConfig = {
  ei: '', // 事件名称
  omgid: '', // omgid
  devid: '', // devid
  subType: '', // 操作类型
  pageFrom: '', // 	端内外
  chlid: '', // 	频道名
  ToChlid: '', //	跳转频道名
  pageArea: '', //	页面区域
  isNewInstall: 0, //	拉新拉活
  shareFromUser: '', // 页面分享发起方
  uuid: '', // uuid
  osType: bbo.isIOS() ? 'ios' : 'android',
  // JSON格式
  ts: Math.random()
};

function bossuuid() {
  let uuid = bbo.storage({ type: 'local', prefix: 'feiyan' }).getItem('uuid');
  if (bbo.isEmpty(uuid)) {
    let setid = bbo.uuid();
    bbo.storage({ type: 'local', prefix: 'feiyan' }).setItem('uuid', setid);
    bossConfig.uuid = setid;
  } else {
    bossConfig.uuid = uuid;
  }
}
bossuuid();

let bosskv = {
  ostype: bbo.isIOS() ? 'ios' : 'android',
  openid: '',
  unionid: '',
  av: '', // 用户app版本号,
  cav: '', // appver,
  ch: bbo.getUrlParam('ADTAG') || '' // 用来标注应用推广渠道，区分新用户的来源来查看统计
};

window['appInfo'] = function(res) {
  bossConfig.devid = bbo.toJson(res).deviceId || '';
  bossConfig.omgid =
    bbo.toJson(res).omgid || bbo.toJson(res).omgMid || bbo.toJson(res).omgbizid || '';

  bosskv.openid = bbo.getCookie('openid') || bbo.getCookie('open_openid') || '';
  bosskv.unionid = bbo.getCookie('unionid') || '';
  bosskv.av = bbo.toJson(res).versionForQQNews || '';
  bosskv.cav = bbo.toJson(res).version || '';
};

window['reporter'] = function(data, kv) {
  if (bbo.isNewsApp() && window.TencentNews && window.TencentNews.getAppInfo) {
    if (bbo.isAndroid()) {
      window.TencentNews.getAppInfo('appInfo');
    } else if (bbo.isIOS()) {
      // eslint-disable-next-line no-undef
      window.TencentNews.getAppInfo(appInfo);
    }
  }
  let reportData = {
    BossId: '8901',
    Pwd: '602773423',
    ...data
  };
  let url = 'https://btrace.qq.com/';
  _get(`${url}kvcollect?BossId=8901&Pwd=602773423&`, reportData);
};
