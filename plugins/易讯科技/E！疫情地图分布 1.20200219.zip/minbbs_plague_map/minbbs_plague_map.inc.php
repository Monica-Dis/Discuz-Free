<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache('plugin');
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
$minbbs = $_G['cache']['plugin']['minbbs_plague_map'];
$AppId = $minbbs['AppId'];
$AppSecret = $minbbs['AppSecret'];
$Total = $minbbs['Total'];
$Share_imgurl = $minbbs['Share_imgurl'];
$Share_title = $minbbs['Share_title'];
$Share_desc = $minbbs['Share_desc'];

$mod = trim($_GET['mod']);
$mod = in_array($mod, array('index', 'ajax', 'qrcode', 'js_signature')) ? $mod : "index";
require_once libfile("minbbs_" . $mod, 'plugin/minbbs_plague_map/module');
?>