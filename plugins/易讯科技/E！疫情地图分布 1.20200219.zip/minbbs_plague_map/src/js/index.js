initMiniApp();

// logo修改不需要先决条件。可以直接检测
initLogo();

window.onLoad  = function(){
  init();
}

function appendScript(url) {
  var jsapi = document.createElement('script');
  jsapi.charset = 'utf-8';
  jsapi.src = url;
  document.head.appendChild(jsapi);
}
var url = 'https://webapi.amap.com/maps?v=1.4.15&key='+$("input[name='amapkey']").val()+'&callback=onLoad&&plugin=AMap.Scale';
appendScript(url);

function appendDingScriptIfNeed(){
  if (isInDingTalk()) {
    var dingApi = document.createElement('script');
    dingApi.src = 'https://g.alicdn.com/ilw/ding/0.9.9/scripts/dingtalk.js';
    document.head.appendChild(dingApi);
  }
}
appendDingScriptIfNeed();

// url 后面添加 debug 参数会自动添加 vconsole 调试工具
function addDebugTools(){
  var isDebug = GetQueryValue('debug');
  if (isDebug) {
    var debugscript = document.createElement('script');
    debugscript.src = '//testing.amap.com/js/vconsole.min.js';
    document.head.appendChild(debugscript);
  }
}
addDebugTools();

var polys = [];
var texts = [];
var overlayItemMap = {}; //根据同的key来缓存数据对象
var labelLayer = null;
var modalInstance = [];
var serverData = null;
var map = null;
var tipModalInstanc = null;
var timeLineModalInstance = null; // 时间轴的提示
var cityModalController = null;
var dataSourceModalInstance = null;
var requestComplete = false;
var isShowAoi = false;
var isShowLabel = null;
var WEB_URL_TEST = 'http://testing.amap.com/activity/partner/plague-map/index.html'; //测网地址
var WEB_URL_RELEASE = 'https://cache.amap.com/activity/partner/plague-map/index.html'; //公网地址
var geolocation = null;
var hasRetryButtonClick = false; // 标记位 如果点了重新刷新按钮，则 onError onComplate 都需要重新请求
var selectFilterKey =  null;
var beforeTextItem = null; // 点击新的扎点时，上一个 textItem 样式需要改成 normal 态
var timeLineTimeOut = null;


var colorTypeDict = {
  1: '#FF3C01',
  2: '#FF8201',
  3: '#FF8201',
  4: '#FFB437',
}
var iconTypeDict = {
  1: 'source/plugin/minbbs_plague_map/src/img/circle-red.png',
  2: 'source/plugin/minbbs_plague_map/src/img/circle-orange.png',
  3: 'source/plugin/minbbs_plague_map/src/img/circle-orange.png',
  4: 'source/plugin/minbbs_plague_map/src/img/circle-yellow.png'
}

function init() {
  Util.loadImgAsync();
  initMap();
  // 控制UI元素的显示隐藏
  initUIElement();
  bindEvent();
  if(isInAMap()){
    //端内，打开分享
    document.getElementById('share-btn').style.display = 'flex';
  }
  addPageShowLog(); //页面展现埋点
  appendUrlParam(); //二次分享参数补全
}

/**
 * 二次分享参数补全
 */
function appendUrlParam(){
  var channel = GetQueryValue('fromchannel');
  if (!channel) {
      channel = 'gaode'
  }
  WEB_URL_RELEASE = WEB_URL_RELEASE + '?fromchannel=' +channel;
  WEB_URL_TEST = WEB_URL_TEST + '?fromchannel=' + channel;
  // console.log('--->>>urls '+WEB_URL_TEST+'   '+WEB_URL_RELEASE);
}

function initLogo() {
  // var channel = AmapApp.util.getUrlParam('fromchannel') || '';
  var channel = GetQueryValue('fromchannel');
  var logoImg = document.getElementById('logo');
  logoImg.setAttribute('data-src', 'source/plugin/minbbs_plague_map/src/img/cooperation.png');
  logoImg.setAttribute('class', 'logo-pair');
}

function initMiniApp() {
  var isMiniapp = GetQueryValue('miniapp');
  if(isMiniapp) {
    document.writeln('<script src="https://appx/web-view.min.js" charset="utf-8"' + '>' + '<' + '/' + 'script>');
  }
}

function GetQueryValue(queryName) {
    var query = decodeURI(window.location.search.substring(1));
    var vars = query.split("&");
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == queryName) { return pair[1]; }
    }
    return null;
}

/**
 * 添加页面展现埋点
 */
function addPageShowLog(){
  var channel = GetQueryValue('fromchannel');
  var logPageId = 'feiyanyiqingh5';
  var logButtonId = 'B001';
  AmapApp.log.initLog(logPageId);
  if (!channel) { // 没有渠道的话默认是高德渠道
    channel = 'gaode'
  }
  var logParams = {
    from: channel,
  };
  AmapApp.log.log(logButtonId,logParams)

}

//判断是否在高德端内
function isInAMap() {
    var ua = navigator.userAgent;
    if (ua){
        var index = ua.toLowerCase().indexOf('amap');
        return index != -1;
    }
    return false;
}

function isInAlipayOrNebula() {
    var ua = navigator.userAgent;
    if (ua){
        var index1 = ua.toLowerCase().indexOf('alipay');
        var index2 = ua.toLowerCase().indexOf('nebula');
        if ( index1 != -1 || index2 != -1){
            return true
        }
    }
    return false;
}

/**
 * 判断是否在头条客户端内
 * @returns {boolean}
 */
function isInTouTiao(){
  var ua = navigator.userAgent;
  if (ua){
    var index = ua.toLowerCase().indexOf('newsarticle');
    return index != -1;
  }
  return false;
}

/**
 * 判断是否在钉钉客户端内
 * @returns {boolean}
 */
function isInDingTalk(){
  var ua = navigator.userAgent;
  if (ua){
    var index = ua.toLowerCase().indexOf('dingtalk');
    return index != -1;
  }
  return false;
}


function initUIElement() {
  if(shouleShowRedButton()) {
    $('#chat-icon-red-btn').show();
  } else {
    $('#chat-icon-red-btn').hide();
  }
}

function bindEvent() {

  tipModalInstanc = new Modal({
    modal: document.getElementById('tip-modal'),
    openCallback: function() {
      $('#date-filter').hide();
    },
    closeCallback: function() {
      $('#date-filter').show();
      resetBeforeTextStyle();
    }
  })
  modalInstance.push(tipModalInstanc);
  document.getElementById('tip-modal-header-close').addEventListener('click', function() {
    tipModalInstanc.close();
  })

  document.getElementById('tip-model-ext-btn').addEventListener('click', function(e) {
    var currentTarget = e.currentTarget;
    my.openLocation({
      longitude: currentTarget.dataset.lon,
      latitude: currentTarget.dataset.lat,
      name: currentTarget.dataset.name,
      address: currentTarget.dataset.name,
      fail: function() {
        my.alert({
          title: '高小德提示',
          content: '请您检查位置授权开启和网络信号情况再试'
        });
      }
    })
  });

  // 时间轴的提示
  timeLineModalInstance =  new Modal({
    modal: document.getElementById('timeline_content'),
  });

  $('#timeline_close').on('click', function() {
    timeLineModalInstance.close();
  });

  modalInstance.push(tipModalInstanc);
  modalInstance.push(timeLineModalInstance);

  map.on('complete', function() {
    // console.log('map complete...');
  })

  map.on('zoomchange', zoomChangeHandler);


  // 城市列表modal
  cityModalController = new Modal({
    modal: document.getElementById('cities-modal'),
    openCallback: function() {
      document.getElementById('cities-modal-body').scrollTop = 0;
    }
  })
  modalInstance.push(cityModalController);

  // 弹起地址蒙层
  var citysSelect = document.getElementById('filter');
  citysSelect.addEventListener('click', function() {
    modalInstance.forEach(function(modal){modal.close()})
    cityModalController.open();
  })

  // 关闭地址蒙层
  // var closeCitySelect = document.getElementById('cities-modal-close');
  $('#cities-modal-close,#cities-modal-mask').on('click', function() {
    cityModalController.close();
  })

  // 选择地址
  $('#cities-modal-body').on('click', '.item-name', function(e) {
    cityModalController.close();
    var currentDom = e.target;
    var id = currentDom.getAttribute('data-city-id');
    var pId = currentDom.getAttribute('data-province-id');
    $('#cities-modal-body .item-name_active').removeClass('item-name_active');
    $(currentDom).addClass('item-name_active')
    var selectCity = getCityInfo(pId, id);
    // 左上角内容更新
    document.getElementById('filter-text').textContent = selectCity.name;
    // 地图移动到对应点
    setTimeout(function(){
      removeAOI();
      if (selectCity.geoobj){
          renderUtil.goGeoobj(selectCity.geoobj)
      } else  {
          renderUtil.goPosition(selectCity);
      }
      checkToAllDateMap();
      checkAOIIfNeedShow();
    }, 10)
    // 重新弹出气泡
    renderUtil.renderTimeLineModal(selectCity.text_info,true)
  })

  // 000000000000000000000000000000000000000000
  // 点击按钮，根据当前城市或者点击重试，做不同动作
  var currentCityBtnDom = $('#current-city-info');
  // 点击了重试
  currentCityBtnDom.on('click', function() {
    function reload() {
      if (geolocation) {
        hasRetryButtonClick = true;
        geolocation.getCurrentPosition();
      }
    }

    function goPosition() {
      if(serverData && serverData.selectCity) {
        var cityDom = $('[data-city-id="'+ serverData.selectCity + '"]');
        cityDom.click();
        checkToAllDateMap();
      }
    }
    if(!serverData.selectCityInfo) {
      return;
    }

    cityModalController.close();
    // 有位置跳位置
    if(serverData.selectCityInfo && serverData.selectCityInfo.user_loc) {
      goPosition();
    } else {
      // 无位置走刷新逻辑
      reload();
    }
  })

  // 000000000000000000000000000000000000000000


  dataSourceModalInstance = new Modal({
    modal: document.getElementById('data-source-helper'),
  })

  // 数据说明弹窗相关
  $('#chat-icon-wrap').on('click', function() {
    onRedButtonClick();
    modalInstance.forEach(function(modal){modal.close()})
    $('#chat-icon-red-btn').hide();
    dataSourceModalInstance.open();
  })

  $('#data-source-helper-header-close, #data-source-helper-mask').on('click', function(){
    dataSourceModalInstance.close();
  })

  modalInstance.push(dataSourceModalInstance);

  document.getElementById('share-btn').addEventListener('click', function() {
    share();
  })

  // 放大缩小控件相关
  $('#img_zoom_in').on('click', function() { // 缩小
    var currentZoom = map.getZoom();
    // console.log('--->>> 缩小 '+currentZoom);
    if (map && currentZoom > 4) {
        map.setZoom(currentZoom - 1)
    }
  })

  $('#img_zoom_out').on('click', function() { // 放大
    var currentZoom = map.getZoom();
    // console.log('--->>> 放大 '+currentZoom);

    if (map && currentZoom < 20) {
      map.setZoom(currentZoom + 1)
    }
  })

  // 点击日期筛选时
  var dateFilterDom = $('#date-filter');
  dateFilterDom.on('click', '.date-filter-item', function(evt) {
    var dateItemDom = $(evt.target).closest('.date-filter-item');
    var dateKey = dateItemDom.attr('data-key');
    // console.log(dateKey);
    dateFilterDom.find('.date-filter-item_selected').removeClass('date-filter-item_selected');
    dateItemDom.addClass('date-filter-item_selected');

    var filterDict = {
      all: undefined,
      one: ['one'],
      seven: ['one', 'seven'],
      fourteen: ['one', 'seven', 'fourteen'],
      other: ['other'],
    }
    var filterRange = filterDict[dateKey];
    // 只要选择了日期
    if(filterRange && serverData && serverData.pois) {
      // 如果该日期聚合结果是没有数据
      var hasData = filterRange.some(function(key) {
        return serverData.pois[key] && serverData.pois[key].poilist && serverData.pois[key].poilist.length > 0
      });
      if(!hasData) {
        Toast.show('该时间段暂无疫情场所数据，将持续更新…', 1000 * 3);
      }
    }
    renderUtil.renderMapWithFiter(filterRange);
    // setTimeout(function(){
    //     renderUtil.renderMapWithFiter(filterRange);
    // })
  })
}

function initMap() {
  map = new AMap.Map('container', {
    resizeEnable: true,
    mapStyle: "amap://styles/"+$("input[name='amapkey']").val(),
    zoom:11,//级别
  });

    var scale = new AMap.Scale({
        visible: true,
        offset:new AMap.Pixel(10, 20)
    });
    map.addControl(scale);
    // 增加定位点
  AMap.plugin('AMap.Geolocation', function() {
    geolocation = new AMap.Geolocation({
        enableHighAccuracy: true,//是否使用高精度定位，默认:true
        timeout: 10000,          //超过10秒后停止定位，默认：5s
        buttonPosition:'RB',    //定位按钮的停靠位置
        buttonOffset: new AMap.Pixel(10, 40),//定位按钮与设置的停靠位置的偏移量，默认：Pixel(10, 20)
        zoomToAccuracy: false,   //定位成功后是否自动调整地图视野到定位点
        buttonDom: '<img src="source/plugin/minbbs_plague_map/src/img/position.png" class="positiom-img" />',
        showCircle: false,
    });
    map.addControl(geolocation);
    AMap.event.addListener(geolocation, 'complete', onComplete)
    AMap.event.addListener(geolocation, 'error', onError)
    geolocation.getCurrentPosition();
    function onComplete(info) {

      checkToAllDateMap();
      if(serverData) {
        map.setZoom(11);
      }
      if (hasRetryButtonClick || !serverData) {
        var requestDataPrams = {lat: info.position.lat, lng: info.position.lng};
        if (hasRetryButtonClick) {
           requestDataPrams = Object.assign(requestDataPrams,{need_poilist:false});
        }
        requestData(requestDataPrams,!hasRetryButtonClick); // 如果点击了重试按钮，则不应该弹 timeline 框
      }

      if (serverData && !hasRetryButtonClick) { // 点击定位按钮造成的定位成功，此时需要展示时间轴弹框
        renderUtil.renderTimeLineModal(serverData.selectCityInfo.text_info,true);
      }
      openAmapApp();
      hasRetryButtonClick = false;
    }
    function onError(info) {
      weui.alert('暂时无法获取到定位信息，请尝试开启定位服务');
      if (hasRetryButtonClick || !serverData) {
        var requestDataPrams = undefined;
        if (hasRetryButtonClick) {
          requestDataPrams = {need_poilist:false};
        }
        requestData(requestDataPrams);
      }
      if(serverData && serverData.mapInfo) {
        map.panTo([serverData.mapInfo.lon, serverData.mapInfo.lat]);
        map.setZoom(serverData.mapInfo.level);
      }
      openAmapApp();
      hasRetryButtonClick = false;
    }
  });
}

/**
 * for dingding double_share
 */
function addDDShare() {
  if (!isInDingTalk()) {
      return
  }
  dd.ready(function(){
    dd.biz.navigation.setRight({
      show: true,//控制按钮显示， true 显示， false 隐藏， 默认true
      control: true,//是否控制点击事件，true 控制，false 不控制， 默认false
      onSuccess : function(result) {
        dd.biz.util.share({
          type: 0, //分享类型，0:全部组件 默认； 1:只能分享到钉钉；2:不能分享，只有刷新按钮
          url: WEB_URL_RELEASE,
          title: '高德地图：全国疫情场所最新动态查询',
          content: '发现距离你最近的疫情场所位置，安全防护，避让出行',
          image: 'http://store.is.autonavi.com/showpic/6ab1d92957d4184f2e062e396a276769?type=pic',
          onSuccess : function() {
            // onSuccess将在分享完成之后回调
            // 比如分享之后积分+10这种操作就可以放在这个回调里面
          },
          onFail : function(err) {
            // onFail将在分享完成之后回调
          }
        });
      },
      onFail : function(err) {
      }
    });


  });
}

function openAmapApp(){
  if(!isInAMap() && !isInAlipayOrNebula() && !isInTouTiao()){
    var isjump = GetQueryValue('isjump');
    if (isjump != 'false'){
        setTimeout(() => {
            openAmap(`amapuri://webview/amaponline?url=${encodeURIComponent(WEB_URL_RELEASE)}`);
        // console.log(`执行了 schema amapuri://webview/amaponline?url=${encodeURIComponent(WEB_URL_RELEASE)}`);
        }, 2000);
    }
  }
}

function requestData(positionInfo,shouldShowTimeLineModal = false) {
  // 首先初始化页面和客户端的连接
  // positionInfo = {lat: 40.024351, lng: 116.4465319};
  var noPoiList = positionInfo && positionInfo.need_poilist === false;
  AmapApp.bridge.ready(function() {
    // 发送端外请求
    var positionStr = '';
    if(positionInfo && positionInfo.lng && positionInfo.lat) {
      positionStr = positionInfo.lng + ',' + positionInfo.lat;
    }
    var channel = GetQueryValue('fromchannel');
    var parmas = [{
      user_loc: positionStr,
      sign: 1
    },{
        fromchannel: channel,
        version: 4,
        first_request:1, //只有初始化请求需要
        sign: 0
    }];
    if(noPoiList) {
      parmas.push({
        sign: 0,
        need_poilist: positionInfo.need_poilist,
      })
    }
    var requestConfig = getAOSRequestConfig()
    AmapApp.loader[requestConfig.requestFn](
      requestConfig.url,
      parmas,
      function(res) {
        if(res && res.code === 1) {
          // 如果是全量则renderPage，否则只render跟城市相关的。
          if(!noPoiList) {
            requestComplete = true;
            serverData = res.data;
            renderPage();
            renderUtil.renderTimeLineModal(serverData && serverData.selectCityInfo && serverData.selectCityInfo.text_info,shouldShowTimeLineModal)
            loadNextPatch(serverData,0,positionStr,channel);
            $('#date-filter').css('display','block'); //设置筛选显示
          } else {
            // 更新城市相关字段
            ['selectCityInfo', 'mapInfo', 'selectCity', 'selectProvince'].forEach(function(key){
              serverData[key] = res.data[key];
            });
            renderUtil.renderErrorPage(false,positionInfo);
            updateCityAboutUI(serverData);
          }
        }else{ // 服务请求失败，展示错误页面
          renderUtil.renderErrorPage(true,positionInfo);
        }
      }    
    );
  });
}

function getAOSRequestConfig(){
    var url = 'https://m5.amap.com/ws/shield/search/yiqing';
    var inAmap = isInAMap();
    // url =  'http://maps.testing.amap.com/ws/shield/search/yiqing'
    var ret = {
      url: url,
      requestFn: inAmap ? 'get' : 'aosJsonp',
      inAmap: inAmap
    }
    return ret;
}

function handleOnServerErrorClick(event){
  window.location.reload(true);
}

var renderUtil = {
  renderTimeLineModal: function(textInfo,shouldShowTimeLineModal){
    if (shouldShowTimeLineModal) {
      if (!textInfo || !textInfo.title || !textInfo.content) {
        return
      }
      document.getElementById('timeline_title_wrapper').innerHTML = textInfo.title;
      document.getElementById('timeline_desc').text = textInfo.content;
      if (timeLineModalInstance) {
        if (timeLineTimeOut) {
          clearTimeout(timeLineTimeOut);
        }
        timeLineModalInstance.open();
        timeLineTimeOut = setTimeout(function () {
          timeLineModalInstance.close();
        }, 5000);
      }
    }
  },
  renderErrorPage: function(isShow,positionInfo){
    var server_error = document.getElementById('server_error');
    var server_error_parent = document.getElementById('server-error-parent');
    var server_error_img = document.getElementById('server-error-img');
    var server_error_title = document.getElementById('server-error-title');

    server_error.style.display=isShow ? 'flex' : 'none';
    server_error.removeEventListener('click',handleOnServerErrorClick)
    if (isShow) {
      server_error._params = positionInfo;
      server_error_parent._params = positionInfo;
      server_error_img._params = positionInfo;
      server_error_title._params = positionInfo;

      server_error.addEventListener('click',handleOnServerErrorClick)
    }
  },

  renderTitle: function(date) {
    // var headerTitle = document.getElementById('header-title');
    // headerTitle.textContent = '新型肺炎疫情地图(' + date + '更新)';
    document.title = '新冠肺炎疫情场所(' + date+'更新)';
    // var descDate = document.getElementById('desc-update-time');
    // descDate.textContent = '更新时间：' + date;
    $('#new-msg-update-time').text('('+date+'更新)')
  },
  renderFilterContent: function(cityItem) {
    var filterTextDom = document.getElementById('filter-text');
    filterTextDom.textContent = cityItem.name;
  },
  renderCurrentCity: function(info) {
    function resetUI() {
      var cityCountInfoDom = $('.current-city-count-info');
      var block = $('.current-block-content')
      block.removeClass('location-error');
      block.removeClass('location-ok');
      cityCountInfoDom.removeClass('has-count');
      cityCountInfoDom.removeClass('no-count');
    }
    resetUI();

    // 1.城市可能在国外。或者库里没有数据。cityinfo为null,前端不展示
    if(!info) {
      $('.current-block').hide();
      return;
    }
    $('.current-block').show();
    // 2.无定位信息，显示对应的内容
    if(!info.user_loc) {
      $('.current-block-content').addClass('location-error');
      return;
    }

    // 3. 有定位
    var cityCountInfoDom = $('.current-city-count-info');
    if(info.user_loc) {
      $('.current-block-content').addClass('location-ok');
      $('#current-info-name-text').text(info.name);
      // 3.1 有定位且有数量
      if(info.count) {
        cityCountInfoDom.addClass('has-count');
        cityCountInfoDom.find('.city-count').text(info.count);
      } else {
        // 3.2 有定位且无数量
        cityCountInfoDom.addClass('no-count');
      }
    }
  },
  renderCityList: function(cityList, selectCity) {

    var container = $('#cities-modal-body');
    var provinceItem = $('<div class="province-block"></div>');
    function createProvinceItem(cityListItem) {
      var provinceItemCur = provinceItem.clone();
      var provinceTitle = $('<div class="province-title">' + cityListItem.name + '</div>');
      var provinceTotalCount = $('<div class="province-sub-title"><span class="count"></span>处场所</div>');
      provinceTotalCount.find('.count').text(cityListItem.total);
      var cityListDom = $('<div class="list"></div>');
      provinceTitle.append(provinceTotalCount);
      provinceItemCur.append(provinceTitle);

      var provinceCities = cityListItem.list || [];
      var curCityListDom = cityListDom.clone();
      provinceCities.forEach(function(city) {
        curCityListDom.append(createCityItem(city, cityListItem));
      })
      provinceItemCur.append(curCityListDom);
      container.append(provinceItemCur);
    }
    function createCityItem(cityItem, parentProvince) {
      var ret = $('<div class="item-name">' + cityItem.name + '</div>');
      ret.attr('data-province-id', parentProvince.id)
      ret.attr('data-city-id', cityItem.id)
      if(cityItem.id === selectCity.id) {
        ret.addClass('item-name_active');
      }
      if(cityItem.name && cityItem.name.length > 4) {
        ret.addClass('item-name_two-line')
      }
      return ret;
    }
    cityList.forEach(function(cityItem) {
      createProvinceItem(cityItem);
    })
    container.append('<div style="height: 0.8rem"></div>');
  },

  /**
   * 根据fiter来渲染图面
   * filter：筛选器，如果filter为空，则使用全部用数据渲染
   * */
  renderMapWithFiter:function (filter) {
      selectFilterKey = filter;
      if (filter && overlayItemMap){
          if (labelLayer){
              labelLayer.clear(); //remove方法不生效，换成clear()
          }
          for (var key in overlayItemMap){
              var index = filter.indexOf(key);
              var isShow = index !== -1;
              renderUtil.setOverlayVisbleForFilterKey(key,isShow);
          }
      } else if(overlayItemMap){
          if (labelLayer){
              labelLayer.clear() //remove方法不生效，换成clear()
          }
          for (var key in overlayItemMap){
              renderUtil.setOverlayVisbleForFilterKey(key,true);
          }
      }
  },
    /**
     * 根据key来改变对应overlay状态
     * */
  setOverlayVisbleForFilterKey:function (key,isShow) {
      if (key){
          var overlayItem = overlayItemMap[key];
          var zoomRes = map.getZoom();
          if (overlayItem) {
              var polysItem = overlayItem['polys'] || [];  //aoi
              var textsItem = overlayItem['texts'] || [];  //文字
              var markersItem = overlayItem['markers'] || []; //小圆点
              isShow  && zoomRes > 15 ? map.add(polysItem) : map.remove(polysItem)
              textsItem.forEach(function (text) {
                  isShow && zoomRes >= 11 ? text.show() : text.hide();
              })
              if (isShow && labelLayer){
                  labelLayer.add(markersItem);
              }
          }
      }
  },

  //根据服务数据中pois来渲染图面overlay
  renderMapWithPois:function(pois){
      if (pois){
          for (var key in pois){
              var poi = pois[key];
              var colorType = poi.colorType;
              var poilist = poi.poilist;
              var isVisible = true;
              if  (selectFilterKey){
                  var index = selectFilterKey.indexOf(key);
                  isVisible = index !== -1;
              }
              renderUtil.renderMap(poilist,colorType,key,isVisible);
          }
      }
  },

  /***
   * 渲染图面元素
   * poilist:poi列表
   * colorType:颜色
   * filterKey:对应的筛选key
   * isVisible:是否立即展示
   * */
  renderMap: function(poilist,colorType,filterKey,isVisible) {
    if(!poilist) return;

    if (!labelLayer){
        labelLayer = new AMap.LabelsLayer({
            zooms: [0, 11],
            zIndex: 1,
            animation: false,
            collision: false
        });
        map.add(labelLayer)
    }

    var useColor = colorTypeDict[colorType] || '#FF7D37';
    var useIcon = iconTypeDict[colorType] || 'source/plugin/minbbs_plague_map/src/img/circle-orange.png'
    var markers = [];
    var iconPath = Util.getImgFullPath(useIcon);
    var icon = {
      type: 'image',
      image: iconPath,
      size: [10, 10],
      anchor: 'center',
      angel: 0,
      retina: true
    };

    var currentTexts = [];
    var currentpolys = [];
    var zIndex = colorType ? 24/colorType : 1; //天数越新，层级越高
    var zoomRes = map.getZoom();
    var textVisible = isVisible && zoomRes >= 11 ? true : false;
    poilist.forEach(function(poi) {
      var textItem = AmapTextFactory({
        name: poi.poiname,
        position: [poi.lon, poi.lat],
        style: {
          'background-color': useColor
        },
        visible:textVisible
      },poi,zIndex);
      currentTexts.push(textItem);

      var markerOptions = {
        position: [poi.lon, poi.lat],
        icon,
        zooms: [0, 11],
        zIndex:zIndex
      };
      var labelMarker = new AMap.LabelMarker(markerOptions);
      markers.push(labelMarker);

      // var circleItem = AmapCircleMarkerFactory({point: [poi.lon, poi.lat]});
      // circles.push(circleItem);
      textItem.on('click', function() {
        if(tipModalInstanc) {
          resetBeforeTextStyle();
          textItem.setTop(true);
          renderUtil.renderTipModal(poi);
          modalInstance.forEach(function(modal){modal.close()});
          tipModalInstanc.open();
          updateCurrentTextStyle(textItem,poi);
          map.panTo([poi.lon, poi.lat]);
        }
      }, poi);

      if(poi.aoi) {
        poi.aoi.forEach(function(aoiItem) {
          aoiItem.forEach(function(item, index){
            aoiItem[index] = [item.lon, item.lat];
          })
        })
        var polyItem = AmapPolygonFactory({path: poi.aoi,color:useColor});
        currentpolys.push(polyItem);
      }
    })

    map.add(currentTexts); // 这里统一加，文字漂移的现象很明显
    if (isVisible){
        labelLayer.add(markers);
    }
    /*overlay item 缓存逻辑*/
    var overlayItem = overlayItemMap[filterKey] || {};
    var polysItem = overlayItem['polys'] || [];  //aoi
    var textsItem = overlayItem['texts'] || [];  //文字
    var markersItem = overlayItem['markers'] || []; //小圆点
    polysItem = polysItem.concat(currentpolys);
    textsItem = textsItem.concat(currentTexts);
    markersItem = markersItem.concat(markers);
    overlayItem['polys'] = polysItem;
    overlayItem['texts'] = textsItem;
    overlayItem['markers'] = markersItem;
    overlayItemMap[filterKey] = overlayItem;

    zoomChangeHandler()
  },

  //获取图面所有aoi的item
  getSelectPolysItem:function () {
     var polys = [];
     if (selectFilterKey) {
         selectFilterKey.forEach(function (key) {
             var item = overlayItemMap[key];
             if (item && item['polys']){
                 polys = polys.concat(item['polys'])
             }
         })
     } else  {
         for (var key in overlayItemMap) {
             var item = overlayItemMap[key];
             if (item && item['polys']){
                 polys = polys.concat(item['polys'])
             }
         }
     }
     return polys;
  },
  //获取图面所有text的item
  getSelectTextsItem:function () {
      var texts = [];
      if  (selectFilterKey) {
          selectFilterKey.forEach(function (key) {
              var item = overlayItemMap[key];
              if (item && item['texts']){
                  texts = texts.concat(item['texts'])
              }
          })
      } else {
          for (var key in overlayItemMap) {
              var item = overlayItemMap[key];
              if (item && item['texts']){
                  texts = texts.concat(item['texts'])
              }
          }
      }
      return texts;
  },
  renderTipModal: function(poiItem) {
    var formPairs = [
      {nameId: 'tip-modal-header-title', valueId: 'tip-modal-header-title', serverKey: 'poiname', showCss: 'block'},
      {nameId: 'info-form-item-distance', valueId: 'info-form-item-distance-content', serverKey: 'distance_display'},
      {nameId: 'info-form-item-type', valueId: 'info-form-item-type-content', serverKey: 'tag_display_std'},
      {nameId: 'info-form-item-number', valueId: 'info-form-item-number-content', serverKey: 'number'},
      {nameId: 'info-form-item-date', valueId: 'info-form-item-date-content', serverKey: 'date'},
      {nameId: 'tip-modal-footer', valueId: 'tip-modal-footer-text', serverKey: 'source'},
    ];
    // 1天tip修改
    if(poiItem.dateRange === 'one') {
      $('.one-day-tip').show();
    } else {
      $('.one-day-tip').hide();
    }
    // 更新表单
    formPairs.forEach(function(formItem) {
      // poiItem[formItem['serverKey']] = '超长测试超长测试超长测试超长测试超长测试超长测试超长测试超长测试超长测试超长测试超长测试超长测试超长测试超长测试';
      var formItemWrap = document.getElementById(formItem.nameId);
      var formItemValueDom = document.getElementById(formItem.valueId);
      if(typeof poiItem[formItem.serverKey] === 'undefined') {
        formItemWrap.style.display = 'none';
      } else {
        formItemWrap.style.display = formItem.showCss || 'flex';
        formItemValueDom.textContent = poiItem[formItem.serverKey];
      }
    })

    // 小程序内的额外逻辑, 默认display:none, 如果是小程序,则展示.
    var isMiniapp = GetQueryValue('miniapp');
    if(isMiniapp) {
      var extraBtn = document.getElementById('tip-model-ext-btn');
      extraBtn.style.display = 'flex';
      extraBtn.dataset.lat = poiItem.lat;
      extraBtn.dataset.lon = poiItem.lon;
      extraBtn.dataset.name = poiItem.poiname;
      extraBtn.dataset.address = poiItem.source;
    }
  },
  goPosition: function(mapInfo) {
    map.panTo([mapInfo.lon, mapInfo.lat]);
    map.setZoom(mapInfo.level);
    zoomChangeHandler();
  },
  goGeoobj:function (geoobj) {
      if (geoobj){
          var southWest = geoobj.southWest;
          var northEast = geoobj.northEast;
          if (Array.isArray(southWest) && Array.isArray(northEast)){
              var southWest = new AMap.LngLat(southWest[0],southWest[1]);
              var northEast = new AMap.LngLat(northEast[0],northEast[1]);
              var bounds = new AMap.Bounds(southWest, northEast);
              map.setBounds(bounds);
              zoomChangeHandler();
          }
      }
  }
}

function zoomChangeHandler() {
  var zoomRes = map.getZoom();
  // 5公里是11级。
  // 只展示圆点，无名称，随机压盖。屏蔽label
  if(zoomRes < 11) {
    if ( isShowLabel == null || isShowLabel == true) {
        var textItems = renderUtil.getSelectTextsItem()
        textItems.forEach(function(textItem) {
            textItem.hide();
        })
        isShowLabel = false;
    }

  } else {
    if  (isShowLabel == null || isShowLabel == false){
        var textItems = renderUtil.getSelectTextsItem()
        textItems.forEach(function(textItem) {
            textItem.show();
            textItem.setAnchor('center');
        });
        isShowLabel = true
    }
  }
  checkAOIIfNeedShow();
}

function checkAOIIfNeedShow() {
    var zoomRes = map.getZoom();
    if (zoomRes > 15 ){
        if (!isShowAoi){
            var polysItems = renderUtil.getSelectPolysItem()
            map.add(polysItems);
            isShowAoi = true
        }
    } else  if(isShowAoi){
        var polysItems = renderUtil.getSelectPolysItem()
        map.remove(polysItems);
        isShowAoi = false;
    }
}

function removeAOI() {
    var polysItems = renderUtil.getSelectPolysItem()
    map.remove(polysItems);
    isShowAoi = false;
}

// 渲染全部日期数据
function checkToAllDateMap(){
    $('.date-filter-item[data-key="all"]').click();
}

function renderPage() {
  if(serverData.date) {
    renderUtil.renderTitle(serverData.date)
  }
  if(serverData.citylist) {
    var selectCity = getInitCityInfo();
    renderUtil.renderFilterContent(selectCity);
    renderUtil.renderCurrentCity(serverData.selectCityInfo, selectCity);
    renderUtil.renderCityList(serverData.citylist, selectCity);
  }
  if (serverData.pois){
      renderUtil.renderMapWithPois(serverData.pois);
   }

  if(serverData.mapInfo) {
      if (serverData.mapInfo.geoobj){
          renderUtil.goGeoobj(serverData.mapInfo.geoobj)
      } else  {
          renderUtil.goPosition(serverData.mapInfo);
      }
  }
}

function updateCityAboutUI() {
  var selectCity = getInitCityInfo();
  renderUtil.renderFilterContent(selectCity);
  renderUtil.renderCurrentCity(serverData.selectCityInfo, selectCity);
  // 更新cityList中，选中的城市
  $('.item-name_active').removeClass('item-name_active');
  if(selectCity && selectCity.id) {
    $('[data-city-id="'+ selectCity.id+ '"]').addClass('item-name_active');
  }

  if(serverData.mapInfo) {
    if (serverData.mapInfo.geoobj){
        renderUtil.goGeoobj(serverData.mapInfo.geoobj)
    } else  {
        renderUtil.goPosition(serverData.mapInfo);
    }
  }
}

function AmapTextFactory(args,extData,zIndex) {
  var name = args.name;
  var position = args.position;
  var visible = args.visible;
  const option = {
    text: name,
    anchor: 'center',
    // map:map, 顶部统一添加
    position: position,
    style: {
      'display': 'block',
      'font-size': '0.24rem',
      'line-height': '0.24rem',
      'text-align': 'center',
      'white-space': 'nowrap',
      'vertical-align': 'middle',
      '-webkit-user-select': 'none',
      '-moz-user-select': 'none',
      '-ms-user-select': 'none',
      'user-select': 'none',
      'background-color': '#FA9937',
      'color': '#fff',
      'padding': '0.12rem 0.14rem',
      'border-radius': '0.08rem',
      'border-width':'0',
      'box-shadow': '0rem 0.04rem 0.16rem rgba(0,0,0,0.16)',
      'cursor': 'pointer'
    },
    visible: visible,
    extData: extData,
    zIndex:zIndex
  }
  if(args.style) {
    option.style = Object.assign(option.style, args.style);
  }
  return new AMap.Text(option)
}

function AmapPolygonFactory(args) {
  var color = args.color ? args.color : '#FF9F3D'
  return new AMap.Polygon({
    path: args.path,
    strokeColor: color,
    strokeWeight: 1,
    strokeOpacity: 1,
    strokeStyle: 'dashed',
    fillOpacity: 0.15,
    fillColor: color,
    zIndex: 10
  });
}

function AmapCircleMarkerFactory(args) {
  return new AMap.CircleMarker({
    center: args.point,
    radius: document.documentElement.clientWidth / 37.5 / 2,
    fillOpacity: '0.8',
    fillColor: '#FF9F3D',
    strokeColor: '#FF9F3D',
    strokeWeight: 0,
  })
}


//--------- 数据加工方法
//根据省份和城市查找信息
function getCityInfo(province,city) {
    if (serverData && province && city){
        var cityList = serverData.citylist;
        if (cityList) {
            var subcity = null;
            for (var index = 0;index < cityList.length;index++){
                var item = cityList[index];
                if (item.id == province){
                    subcity = item.list;
                    break;
                }
            }
            var cityInfo = null;
            if (subcity) {
                for (var index = 0;index < subcity.length;index++){
                    var item = subcity[index];
                    if (item.id == city){
                        cityInfo = item;
                        break;
                    }
                }
            }
            return cityInfo;
        }
    }
    return null;
}

//获取初始化接口中选中的city
function getInitCityInfo(){
    if (serverData){
        var selectProvince = serverData.selectProvince;
        var selectCity = serverData.selectCity;
        var info = getCityInfo(selectProvince,selectCity)
        return info;
    }
    return null;
}

/*
* 获取需要渲染的全部poilist 数据
* data：为空，默认取serverData中的数据
* */
function getAllPoiList(data){
    var poilist = null;
    var targetData = data ? data : serverData
    if (targetData && targetData.poilist) {
        poilist = targetData.poilist;
    } else if (targetData && targetData.pois){
        var pois = targetData.pois;
        poilist = [];
        for (var key in pois) {
            var item = pois[key];
            var sublist = item ?item.poilist:null;
            if (Array.isArray(sublist)){
                poilist = poilist.concat(sublist);
            }
        }
    }
    return poilist;
}

/**
 * 根据fiter来获取需要展示poilist
 * filter：筛选数组
 * */
function getPoiListWithFilter(filter) {
    if (Array.isArray(filter) && serverData && serverData.pois){
        var resultlist = [];
        filter.forEach(function (key) {
           var item = serverData.pois[key];
           var sublist = item ?item.poilist:null;
           if (Array.isArray(sublist)){
               resultlist = resultlist.concat(sublist);
           }
        });
        return resultlist;
    }
    return null;
}

/**
 * 合并分批下载请求的数据到serverData中
 * nextbach
 */

function mergeNextBatch(nextBatch) {
    if (nextBatch && serverData && nextBatch.pois){
        var nextPois = nextBatch.pois;
        var pois = serverData.pois ? serverData.pois:{};
        for (var key in nextPois){
            var nextPoi = nextPois[key];
            var current = pois[key];
            if (nextPoi && !current){
                pois[key] = nextPoi; //原数据中没有对应key，直接赋值
            } else if (nextPoi && current){
                var nextList = nextPoi.poilist; //如果原数据存在，则合并list
                var currentList = current.poilist ? current.poilist:[];
                if (nextList){
                    currentList = currentList.concat(nextList);
                    current.poilist = currentList;
                }
            }
        }
        serverData.pois = pois;
    }
}

//------------- for share
var _amapSchema;
var _hasCalledAmap = false;
/**
 * 使用 schema 呼起高德地图.
 * @param {String} schema 呼起高德地图使用的 schema
 */
function openAmap(schema) {
  // android 不支持 schema 手机：
  //   华为NXT-DL00 EMUI4.0 android6.0 系统浏览器
  // 6677 端口返回 true 却无法呼起手机：
  //   魅族 note2
  //   uc 浏览器 9.4.2
  // loadSchema(schema);
  //*
  if (schema.indexOf('androidamap://') !== 0) {
    loadSchema(schema);
  }
  else {
    _amapSchema = schema;
    // callback 名称不可以 下划线 开头
    AmapApp.util.addScript('http://127.0.0.1:6677/getpackageinfo?callback=amapCallback1&r=' + Math.random());
    setTimeout(function () {
      // console.log("400ms" + _hasCalledAmap);
      if (!_hasCalledAmap) {
        // console.log("loadschema");
        loadSchema(schema);
      }
    }, 400);
  } //*/
}
// Android socket服务获取高德地图版本信息回调
window.amapCallback1 = function (data) {
  // console.log(JSON.stringify(data));
  if (data && data.error_code == '0' && data.version_code >= 420 &&
    data['package'] === 'com.autonavi.minimap') {
    var schema = _amapSchema.replace(/^\w+map:\/\//i, '').replace('?', '&');
    AmapApp.util.addScript('http://127.0.0.1:6677/androidamap?action=' + schema +
      '&callback=amapCallback2&r=' + Math.random());
  }
};
window.amapCallback2 = function (data) {
  // console.log(JSON.stringify(data))
  // TODO 呼起失败时也返回 error_code === 0
  // 复现机型： 魅族note2 华为
  if (data.error_code == '0') {
    _hasCalledAmap = true;
  }
};

/**
 * 调用客户端schema.
 * @param {String} schema schema
 */
function loadSchema(schema) {
  if (AmapApp.os.ios && parseInt(AmapApp.os.version) >= 9) {
    window.location.href = schema;
    return;
  }

  var schemaIframe = document.getElementById('loadSchemaIframe');
  if (!schemaIframe) {
    schemaIframe = document.createElement('iframe');
    schemaIframe.id = 'loadSchemaIframe';
    schemaIframe.style.display = 'none';
    document.body.appendChild(schemaIframe);
  }
  schemaIframe.src = schema;
}

function addWXScript(url, onload, onerror) {
    var script = document.createElement('script');
    if (onload) {
        script.onload = function() {
            onload(script);
        };
    }
    script.onerror = function() {
        if(onerror){
            onerror(script);
        }else if(onload){
            onload(script);
        }
    };
    script.src = url;
    document.head.appendChild(script);
    return script;
}

//hyr添加二次分享
function addWXShare(){
    if (window.navigator.userAgent.search(/MicroMessenger/i) >= 0) {
        //微信分享逻辑
        // console.log('微信端');
        addWXScript(location.protocol + '//cache.amap.com/activity/tools/jweixin-1.0.0.js', function(){
            addWXScript(location.protocol + '//wb.amap.com/sign.php?r=' + Math.random(), function(){
                wx.ready(() => {
                    wx.checkJsApi({
                        jsApiList: [
                            'onMenuShareTimeline', // 分享到朋友圈
                            'onMenuShareAppMessage' // 分享给好友
                        ],
                        success(res) {
                            // console.log('微信');
                            // console.log('朋友圈：');
                            if (res.checkResult.onMenuShareAppMessage) {
                                wx.onMenuShareAppMessage({
                                    title: '高德地图：全国疫情场所最新动态查询',
                                    link: WEB_URL_RELEASE,
                                    imgUrl: 'http://store.is.autonavi.com/showpic/6ab1d92957d4184f2e062e396a276769?type=pic',
                                    desc: '发现距离你最近的疫情场所位置，安全防护，避让出行'
                                });
                            }
                            if (res.checkResult.onMenuShareTimeline) {
                                wx.onMenuShareTimeline({
                                    title: '高德地图：全国疫情场所最新动态查询',
                                    link:WEB_URL_RELEASE,
                                    imgUrl: 'http://store.is.autonavi.com/showpic/6ab1d92957d4184f2e062e396a276769?type=pic'
                                });
                            }
                        }
                    })
                });
            });
        });
    }
}


//---->>>>>> 提示

/**
 * 消息按钮点击时触发
 */
function onRedButtonClick(){
  saveCacheToLocal('show_red','false');
}

/**
 * 用于判断当前页面红点是否需要展示
 * @return true: 展示红点 false: 不展示红点
 */
function shouleShowRedButton(){
  if (getCacheFromLocal('show_red')=='false') {
    return false;
  }
  return true;
}

/**
 * 存储 key
 */
function saveCacheToLocal(key,value){
  var localStorage = window.localStorage;
  if (localStorage) {
    localStorage.setItem(key,value);
  }
}

/**
 * 获取 key
 */
function getCacheFromLocal(key){
  var localStorage = window.localStorage;
  if (localStorage) {
    return localStorage.getItem(key);
  }
  return null;
}

/* 分批请求逻辑*/

/**
 * @param data 数据
 * @param count 当前下载次数
 * @param user_loc 经纬度
 * @param channel 渠道
 */
function loadNextPatch(data,count,user_loc,channel){
    if (data && data.next_batch){
        var parmas = [{
            user_loc: user_loc,
            sign: 1
        },{
            fromchannel: channel,
            version: 4,
            batch: data.next_batch,
            sign: 0
        }]
        //
        var requestConfig = getAOSRequestConfig()
        AmapApp.loader[requestConfig.requestFn](
          requestConfig.url,
          parmas,
          function(res) {
              if(res && res.code === 1) {
                  //请求成功，
                  var nextData = res.data;
                  loadNextPatch(nextData,0,user_loc,channel);
                  renderNextData(nextData)
              }else{
                  //请求失败重试逻辑
                  if (count < 3){
                      var nextCount = count + 1;
                      loadNextPatch(data,nextCount,user_loc,channel);
                  }
              }
          }
      );
    }
}

//渲染下一批poi数据
function renderNextData(nextData) {
    if (serverData && nextData) {
        mergeNextBatch(nextData); //合并数据
        if (nextData.pois){
            renderUtil.renderMapWithPois(nextData.pois);
        }
    }
}

//----->>>>>>>点击标签后变大逻辑

/**
 * 恢复 label 样式，只需要恢复改动过的 label
 */
function resetBeforeTextStyle(){
  if (beforeTextItem) {
    beforeTextItem.setStyle({
      'font-size': '0.24rem',
      'padding': '0.12rem 0.14rem'});
  }
}

/**
 * 更新选中的样式
 */
function updateCurrentTextStyle(textItem,poi){
  if (textItem && poi) {
    textItem.setStyle({
      'font-size': '0.34rem',
      'padding': '0.22rem 0.24rem'});
    beforeTextItem = textItem;
  }
}



