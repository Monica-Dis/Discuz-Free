

(function() {

  var is3x = function() {
    return window.devicePixelRatio>=3;
  }

  var getImgFullPath = function(srcPath) {
    if(!srcPath) {
      return;
    }
    var imgSuffix = is3x() ? '@3x':'@2x';
    var formatPos = srcPath.lastIndexOf('.');
    var path = srcPath.substr(0, formatPos);
    var format = srcPath.substr(formatPos);
    return path + imgSuffix + format;
  }

  var loadImgAsync = function() {
    var imgs = document.getElementsByTagName('img');
    var imgArr = Array.prototype.slice.call(imgs);
    imgArr.forEach(function(item) {
      var srcPath = item.getAttribute('data-src');
      if(!srcPath) {
        return;
      }
      
      item.setAttribute('src', getImgFullPath(srcPath));

      var stopChangeDisplay = item.getAttribute('data-change') === 'false';
      if(stopChangeDisplay) {
        return false;
      }
      item.style['display'] = 'inline-block';
    })
  }

  var Util = {
    is3x: is3x,
    loadImgAsync: loadImgAsync,
    getImgFullPath: getImgFullPath,
  }

  window.Util = Util;
})()