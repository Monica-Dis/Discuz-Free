function Toast(){
  
}

Toast.show = function(text, showTime) {
  $('.toast').remove();
  var toastContent = $('<div class="toast" id="toast">'+ text +'</div>');
  $('body').append(toastContent);
  setTimeout(function() {
    toastContent.remove(toastContent)
  }, showTime)
}