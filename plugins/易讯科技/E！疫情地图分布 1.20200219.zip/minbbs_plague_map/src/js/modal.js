function Modal(options) {
  this.modal = options.modal;
  this.openState = Boolean(options.show);
  this.closeCallback = options.closeCallback || function() {};
  this.openCallback = options.openCallback || function() {};
}

Modal.prototype.open = function() {
  this.openState = true;
  this.openCallback();
  this.modal.style['display'] = 'flex';
}

Modal.prototype.close = function() {
  this.openState = false;
  this.modal.style['display'] = 'none';
  this.closeCallback();
}