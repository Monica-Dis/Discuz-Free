<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include template('minbbs_plague_map:minbbs_index');

?>