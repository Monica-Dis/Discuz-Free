<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_GET['formhash'] == FORMHASH){
	$url = 'http://2019ncov.nosugartech.com/data.json';
	$json = dfsockopen($url);
	$jsons = mb_convert_encoding($json, 'gbk','utf-8');
	echo $jsons;
}
//From: Dism��taobao��com
?>