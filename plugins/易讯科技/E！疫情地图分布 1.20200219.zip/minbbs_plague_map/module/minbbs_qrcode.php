<?php
/**
 *	Powered by Easexun Inc.
 *	Version: 6.20190309
 *	Identifier:minbbs_lietou
 *  Email:minbbs@qq.com
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$url = $_GET['url'] ? $_GET['url'] : urlencode($_G['siteurl']);
require_once DISCUZ_ROOT . 'source/plugin/mobile/qrcode.class.php';
$size = intval($_GET['size']) ? intval($_GET['size']) : 10;
if (class_exists('QRcode')) {
	QRcode::png($_GET['url'], false, 0, $size, 2);
	exit;
}
//From: Dism��taobao��com
?>