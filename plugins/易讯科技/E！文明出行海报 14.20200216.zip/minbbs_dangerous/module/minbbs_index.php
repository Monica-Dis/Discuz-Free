<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$count = DB::result(DB::query("SELECT count FROM ".DB::table('minbbs_dangerous')." "));
$counts = $count+$Total;
$refererurl = $_G['siteurl'] . 'plugin.php?id=minbbs_dangerous';

include template('minbbs_dangerous:dangerous');
?>