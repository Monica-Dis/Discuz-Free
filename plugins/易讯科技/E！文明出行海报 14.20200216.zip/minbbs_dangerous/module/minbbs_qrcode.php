<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$url = $_GET['url'] ? $_GET['url'] : urlencode($_G['siteurl']);
require_once DISCUZ_ROOT . 'source/plugin/mobile/qrcode.class.php';
$size = intval($_GET['size']) ? intval($_GET['size']) : 10;
if (class_exists('QRcode')) {
	QRcode::png($_GET['url'], false, 0, $size, 2);
	exit;
}
//From: Dism_taobao_com
?>