<?php
/**
 *	文明出行海报 (C)2018-2099 Powered by Easexun Inc.
 *	Version: 1.0.0
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function httpGet($url) {
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_TIMEOUT, 500);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($curl, CURLOPT_URL, $url);

	$res = curl_exec($curl);
	curl_close($curl);
	
	return $res;
}
//From: Dism_taobao_com
?>