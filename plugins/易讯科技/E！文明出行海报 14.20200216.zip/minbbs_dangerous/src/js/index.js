$(document).ready(function(){
    $(function() {
        $('.poster-box').hide()
        pv()
    })
    var name = ""
    var isPost = false
    var timer = 0

    $(document).on('tap','.button',function(){
        var input = document.getElementById("input");
        input.blur();
        var input = $('.input').val()
        var form = $('#form').serializeArray()
        var _form = {}
        // console.log
        for( index in form ){
            if(!form[index].value) return tpl('请先填写姓名')
                // var _name =  
            _form[form[index].name] = form[index].value
            if(name == form[index].value){
                return $('.poster-box').show()
            }else{
                name = form[index].value
            }
        }
        if(isPost) return false
        showLoading('海报生成中...')
        setTimeout(function(){
            getCanvas()
            // hideLoading()       
             isPost = false
        },1500) 
        return false
        showLoading('海报生成中...')
        isPost = true
        //$.ajax({
        //    type: 'post',
        //    url: '/2018/10/dangerous/index/count',
        //    // data: $(this).serializeArray(),
        //    dataType: "json",
        //    success: function(res) {
        //        // hideLoading()         
        //        isPost = false
        //        totalJoin = res.data.count
        //        setTimeout(function(){
        //            getCanvas()
         //       },1000) 
         //   },
         //   fail: function(err){
         //       console.info('err',err)
         //       hideLoading()       
         //       isPost = false  
         //   }
        //})
        // console.log($('#form').serializeArray())
    })

    function pv(){
        $.ajax({
            type: 'post',
            url: '/2018/10/dangerous/index/count',
            // data: $(this).serializeArray(),
            dataType: "json",
            success: function(res) {
                // hideLoading()         
                // isPost = false
                totalJoin = res.data.count
                // setTimeout(function(){
                //     getCanvas()
                // },1000) 
            },
            fail: function(err){
                console.info('err',err)
                hideLoading()       
                isPost = false  
            }
        })
    }

    var myCanvas = document.getElementById("myCanvas");

    function getCanvas(){
        myCanvas.height=myCanvas.height;   

        var QrObj = new Image();
        QrObj.src = "";
        var imgObj = new Image();
        imgObj.src = "img/poster.png?v=201811030900";
        var ctx = myCanvas.getContext('2d');
		var totalJoin = '1';
        imgObj.onload = function(){

            ctx.drawImage(this, 0, 0);//改变图片的大小到1024*768

                setTimeout(() => {
                    //人数
                    ctx.textAlign='center'
                    ctx.rect(0,1334,750,66);
                    ctx.fillStyle="#fee004";
                    ctx.fill();
                    ctx.font = "small-caps 50px '雅黑'";
                    ctx.fillStyle = "#000";
                    ctx.fillText("我是第" + totalJoin + "位文明出行者" ,375, 1385, 750);
                    ctx.textAlign='left'
                   
                    ctx.rotate( -8* Math.PI/180);
                    ctx.font = "small-caps 50px 'yuping'";
                    ctx.fillStyle = "#fff";
                    // ctx.textAlign='center';
                    ctx.fillText("承诺人:" ,300, 850, 300);
                    ctx.fillText(name ,310, 920, 300);
                    ctx.fillText(getTime() ,240, 990, 300);
                },200)

                setTimeout(function() {
                    var image = new Image();
                    image.src = myCanvas.toDataURL("image/png");
                    document.getElementById("psoter").src = image.src
                    hideLoading()
                    isPost = false
                    $('.poster-box').show()
                },1000)
        }
    }
    

    function convertCanvasToImage() {
        image.src = myCanvas.toDataURL("image/png");
        // console.info('src',image.src)
        document.getElementById("pngHolder").src = image.src
        return image;
    }


    function tpl(text) {
        var html = "";
        html = "<div class='hint'>" + text + "</div>";
        // $("<div class='hint'>" + text + "</div>").appendTo("body")
        $("body").append(html);
        setTimeout(function() {
            $('.hint').remove();
        }, 2000)
    }

    function showLoading(text){
        var _text = text || '正在提交'
        var html = "";
        html = "<div class='Loading'><div class='icon'></div><div>"+ _text + "</div></div>";
        $("body").append(html);
    }

    function hideLoading(){
        $('.Loading').remove();
    }


    function getTime(){
        var myDate = new Date();
        var year = myDate.getFullYear();
        var month = myDate.getMonth() + 1
        var day = myDate.getDate()
        return year + '年' + month + '月' + day + '日'
    }

    $(document).on('tap','.close',function(){
        $('.poster-box').hide()
    })

})


