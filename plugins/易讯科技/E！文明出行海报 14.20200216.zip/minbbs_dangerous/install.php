<?php
/**
 *	文明出行海报 (C)2018-2099 Powered by Easexun Inc.
 *	Version: 1.0.0
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_minbbs_dangerous` (
  `count` mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY (`count`)
) ENGINE=MyISAM;
INSERT INTO `pre_minbbs_dangerous` (`count`)VALUES ('1');
EOF;

runquery($sql);
$finish = TRUE;
?>