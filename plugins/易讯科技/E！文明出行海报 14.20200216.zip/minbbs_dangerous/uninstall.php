<?php
/**
 *	文明出行海报 (C)2018-2099 Powered by Easexun Inc.
 *	Version: 1.0.0
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
DROP TABLE IF EXISTS pre_minbbs_dangerous;
EOF;
runquery($sql);
$finish = TRUE;
?>