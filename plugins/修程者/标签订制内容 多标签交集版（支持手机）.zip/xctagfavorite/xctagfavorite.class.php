<?php 
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');

class plugin_xctagfavorite{
    public $isuse;
    public $showposition;
    public $navi;
    public $uid;
    public $shownum;
    public $picurl="source/plugin/xctagfavorite/css/images/hj.png";
    function __construct(){
        global $_G;
        $this->uid=$_G['uid'];
        $pluginvalue=$_G['cache']['plugin']['xctagfavorite'];
        $this->isuse=$pluginvalue['isopen'];
        $this->navi=$pluginvalue['kjclose'];
        $this->showposition=$pluginvalue['showposition'];
       $this->shownum= empty($pluginvalue['numofindex'])?0:$pluginvalue['numofindex'];
    }	
    public  function showMenu(){
        if ($this->isuse){
            $showNum=0;
            if ($this->shownum>0) {
                $showNum=$this->shownum-1;
            }
            if(empty($this->uid)){
                $data=$this->getDefaultFID();
            }else {
                $fidlist=DB::fetch_all('select tagid from %t where uid=%d and status=1',array('xc_tagfavorite',$this->uid));
                if (sizeof($fidlist)==0) {
                    $data=dimplode($this->getDefaultFID());
                }else {
                    $data=$fidlist[0]['tagid'];
                }
            }
            $sql.="  WHERE tagid in (".$data.")";
            $list=DB::fetch_all('select distinct a.subject,a.tid,a.dateline from %t a left join %t b on a.tid=b.itemid  '.$sql. ' order by dateline desc '.DB::limit($showNum+1),array('forum_thread','common_tagitem'));
            include template('xctagfavorite:indexlist');
            return $return;
        }
    }
    public function  global_header(){
        if ($this->isuse&&$this->navi) {
            $logourls=$this->picurl;
            $plugin_show=lang('plugin/xctagfavorite', 'ashow');
            include template('xctagfavorite:indexshow');
            return $return;
        } 
    }
    public function getDefaultFID(){
        $lists=DB::fetch_first('select tagid from %t order by id desc limit 1',array('xc_taglist'));
        foreach ($lists as $key=>$items){
            $datas[]=$items;
        }
        return $datas;
    }
}
class plugin_xctagfavorite_forum extends plugin_xctagfavorite{
    
    public  function index_top(){
        if ($this->showposition==1) {
            return $this->showMenu();
        }
    }
    public  function index_middle(){
        if ($this->showposition==2) {
            return $this->showMenu();
        }
    }
    public  function index_bottom(){
        if ($this->showposition==3) {
            return $this->showMenu();
        }
    }
}