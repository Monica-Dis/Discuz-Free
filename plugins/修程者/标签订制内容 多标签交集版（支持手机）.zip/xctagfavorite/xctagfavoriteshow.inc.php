<?php 
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
$title=lang('plugin/xctagfavorite', 'ashow');
$plugin_allpage=lang('plugin/xctagfavorite','allpage');
$plugin_cpage=lang('plugin/xctagfavorite','currentpage');
$plugin_fpage=lang('plugin/xctagfavorite','frist');
$plugin_ppage=lang('plugin/xctagfavorite','pre');
$plugin_npage=lang('plugin/xctagfavorite','next');
$plugin_epage=lang('plugin/xctagfavorite','end');
$pnum = intval($_GET['pagenum']) ? intval($_GET['pagenum']) : 20;
$page =  intval($_GET['page']) ? intval($_GET['page']) : 1;
    $lists=array();
    $alllists=array();
    $start_limit = ($page - 1) * $pnum;
    if(!empty($_G['uid'])){
        $fidlist=DB::fetch_all('select tagid from %t where uid=%d and status=1',array('xc_tagfavorite',$_G['uid']));
        $data=$fidlist[0]['tagid'];
    }
    if ($data!="") {
        $arr=explode(',', $data);
        $sql.="  WHERE idtype='tid'  ";
        $id=0;
        foreach ($arr as $item){
            if ($id==0) {
                $sql.=" and tagid=".$item;
            }else{
                $sql.=" or tagid=".$item;
            }
            $id++;
        }
        $num=sizeof($arr);
        $idlist=DB::fetch_all('select itemid,count(*) as num from %t '.$sql. ' group by itemid',array('common_tagitem'));
        foreach ($idlist as $numitem){
            if ($num==$numitem['num']) {
                $sqls.=$numitem['itemid'].',';
            }
        }
    }
    if (strlen($sqls)==0) {
        $sqls=0;
    }else{
        $sqls=substr($sqls, 0,strlen($sqls)-1);
    }
    $alllists=DB::fetch_all('select distinct a.subject as title,a.tid,a.dateline from %t a  where tid in( '.$sqls. ') order by dateline desc limit 100',array('forum_thread'));
    $listcount=sizeof($alllists) ;
    if ($listcount) {
        for ($i=$start_limit;$i<$start_limit+$pnum;$i++){
            if ($listcount>$i) {
                $alllists[$i]['id']=$i+1;
                array_push($lists, $alllists[$i]);
            }  
        } 
    }
    $changepage= page($alllists, $pnum, $page,'plugin.php?id=xctagfavorite:xctagfavoriteshow',$plugin_allpage,$plugin_fpage,$plugin_ppage,$plugin_npage,$plugin_epage,$plugin_cpage);
    include template('xctagfavorite:favoritelist');
    
function page($array,$pagesize,$current,$url,$all,$frist,$pre,$nexts,$end,$curr){
    $total=ceil(Count($array)/$pagesize);
    $prev=(($current-1)<=0 ? "1":($current-1));
    $next=(($current+1)>=$total ? $total:$current+1);
    $current=($current>($total)?($total):$current);
    $start=($current-1)*$pagesize;
    return $all.$total.'&nbsp;&nbsp;' .  $curr.$current. " &nbsp;&nbsp;  <a href=\"{$url}&page=1\">{$frist}</a> <a href=\"{$url}&page={$prev}
    \">{$pre}</a> <a href=\"{$url}&page={$next}\">{$nexts}</a> <a href=\"{$url}&page={$total}\">{$end}</a>"; 
}
//From: dis'.'m.tao'.'bao.com
?>