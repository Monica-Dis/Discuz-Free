<?php 
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')||!defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$plugin_name=lang('plugin/xctagfavorite','tablename');
$plugin_kwname=lang('plugin/xctagfavorite','taglist');
$plugin_title_invalid=lang('plugin/xctagfavorite','mustselect');
$pmods=$_GET['pmod'];
if ($pmods=='xcmanagetag') {
    if(!submitcheck('editsubmit')) {
        $kwlist=DB::fetch_all('select tagid,tagname from %t where status=0',array('common_tag'));
        $bgauto=DB::fetch_all('select tagid,id from %t order by id desc',array('xc_taglist'));
        $id=0;
        $tagid='';
        if (sizeof($bgauto)>0) {
            $id=$bgauto[0]['id'];
            $tagid=$bgauto[0]['tagid'];
        }
       
        $url="plugins&operation=config&identifier=xctagfavorite&pmod=xcmanagetag&subconfig=edit&fromid=".$id;
        showformheader($url,'enctype');
        showtableheader();
        showsetting($plugin_kwname, array('tags',$kwlist),explode(',',$tagid) ,'mcheckbox');
        showtagfooter('tbody');
        showsubtitle(array('<input type="checkbox" name="chkall" id="chkallWH8x" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'tags\')">'.$lang[select_all]));
        showsubmit('editsubmit','submit','');
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/
    }else {
        global $_G;
        if (empty($_GET['tags'])) {
            cpmsg($plugin_title_invalid, '', 'error');;
        }
        $data = array(
            'tagid' =>  implode(',',$_GET['tags']),
        );
        $id=intval($_GET['fromid']);
        if ($id==0) {
            DB::insert('xc_taglist',$data);
        }else{
            DB::update('xc_taglist',$data,array('id'=>$id));
        }
        cpmsg('plugins_edit_succeed', "action=plugins&operation=config&identifier=xctagfavorite&pmod=xcmanagetag", 'succeed');
    }
}
//From: dis'.'m.tao'.'bao.com
?>