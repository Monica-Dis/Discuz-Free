<?php 
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')||!defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$plugin_name=lang('plugin/xctagfavorite','tablename');
$plugin_kwname=lang('plugin/xctagfavorite','kwname');
$plugin_kwtime=lang('plugin/xctagfavorite','kwtime');
$plugin_kwtimes=lang('plugin/xctagfavorite','kwtimes');
$pnum = intval($_GET['pagenum']) ? intval($_GET['pagenum']) : 20;
$page =  intval($_GET['page']) ? intval($_GET['page']) : 1;
$pmods=$_GET['pmod'];
if ($pmods=='xctaguser') {
    showtagheader('div', 'vars', 'vars');
    showtableheader($plugin_name);
    showsubtitle(array('',  $plugin_kwname,$plugin_kwtimes, $plugin_kwtime));
    $start_limit = ($page - 1) * $pnum;
    $nowdate=strtotime(date('Y-m-d'));
    $countlist=DB::fetch_all('SELECT distinct uid FROM %t', array('xc_tagfavorite'));
    $catlist=DB::fetch_all('SELECT tagid,tagname FROM %t', array('common_tag'));
    $listcount=sizeof($countlist);
    if ($listcount) {
        $multipage = multi($listcount, $pnum, $page, ADMINSCRIPT."?action=plugins&operation=config&do=10&identifier=xctagfavorite&pmod=xctaguser&pagenum=$pnum", 0, 3);
        $lists=DB::fetch_all('select username,createtime,tagid from %t a left join %t b on a.uid=b.uid   order by createtime  desc '.DB::limit($start_limit, $pnum),array('xc_tagfavorite','common_member'));
        $i=0;
        foreach($lists as $var) {
            showtablerow('', array('class="td25"', 'class="td28"'), array(
                $i+1,
                $var['username'],
                getcontent($var['tagid'], $catlist) ,
                dgmdate($var['createtime'],'dt')
            ));
            $i++;
        }
    }
    showsubmit('', '', '', '', $multipage);
    showtablefooter(); /*Dism��taobao��com*/
    showtagfooter('div');
}

function getcontent($id,$listvalue){
    $content="";
    if ($id!="") {
        $arr=explode(',', $id);
        foreach ($arr as $var){
            foreach ($listvalue as $item){
               if ($var==$item['tagid']) {
                   $content.=$item['tagname'].',';
                   break;
               }
           }
       }
    }
    return  $content;
}
//From: dis'.'m.tao'.'bao.com
?>