<?php 
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');
global $_G;
$plugin_error=lang('plugin/xctagfavorite', 'records');
$plugin_errorsubmit=lang('plugin/xctagfavorite', 'submit');
$plugin_success=lang('plugin/xctagfavorite', 'success');
require_once libfile('function/magic');
$action = $_GET['action'];
$operation = $_GET['operation'];
$pagename = $_GET['page'];
if (empty($_G['uid'])){
    showmessage(lang('plugin/xctagfavorite',userlogin),'', array(), array('return' => true));
}
if ($action=="zfbox"&&$operation=="add"){
        $myid=DB::result_first('SELECT tagid FROM %t where uid=%d', array('xc_tagfavorite',$_G['uid']));
        if ($myid!="") {
            $arr=explode(',', $myid);
            $arr_value=join(',', $arr);
            $values="a.tagid in (".$arr_value.") and";
        }
        $tagid=DB::result_first('SELECT tagid FROM %t order by id desc limit 1', array('xc_taglist'));
        if ($tagid!="") {
            $arrtag=explode(',', $tagid);
            $arrtag_value=join(',', $arrtag);
            $morevalues.=" where a.tagid in (".$arrtag_value.") ";
        }
        $list=DB::fetch_all('SELECT  a.tagid as fid,tagname as name ,IFNULL(b.status,0) as status from %t a left join %t b on '.$values.' b.uid=%d  '.$morevalues.' order by fid desc',array('common_tag','xc_tagfavorite',$_G['uid']));
        $listresult=array();
            $listresult['message']='ok';
            $sizenum=0;
            foreach ($list as $key=>$item){
                if ($item['status']==1) {
                    $selectedlist[]=$item;
                    $sizenum++;
                }
            }
            if (strtolower($_G['charset'])=='gbk'||strtolower($_G['charset'])=='big5') {
                $listresult['result']=gbk2utf8($list);
            }else{
                $listresult['result']=$list;
            }
            $result=json_encode($listresult);
            include template('xctagfavorite:listshow');
            
}elseif($action=="zfbox"&&$operation=="showlist"){
    $values= str_replace('a', '', $_GET['vals']) ;
    $arr=array();
    $arr['flag']=false;
    $showmes='error:';
    if(empty($_GET['hash']) || $_GET['hash'] != formhash()) {
      $mes= $plugin_errorsubmit;
    }else{
        if (empty($values)) {
            $mes= $plugin_error;
        }else{
            $myid=DB::result_first('SELECT vid FROM %t where uid=%d', array('xc_tagfavorite',$_G['uid']));
            if ($myid>0) {
                $data=array(
                    'tagid'=>$values,
                    'createtime'=>time(),
                );
                DB::update('xc_tagfavorite',$data,array('vid'=>$myid));
            }else{
                $insertdata=array(
                    'createtime'=>time(),
                    'uid'=>$_G['uid'],
                    'status'=>1,
                    'tagid'=>$values,
                );
                DB::insert('xc_tagfavorite',$insertdata);
            }
            $mes= $plugin_success;
            $arr['flag']=true;
            $showmes="";
            $arr=explode(',', $values);
            $sql.="  WHERE idtype='tid'  ";
            $id=0;
            foreach ($arr as $item){
                if ($id==0) {
                    $sql.=" and tagid=".$item;
                }else{
                    $sql.=" or tagid=".$item;
                }
                $id++;
            }
            $num=sizeof($arr);
            $idlist=DB::fetch_all('select itemid,count(*) as num from %t '.$sql. ' group by itemid',array('common_tagitem'));
            foreach ($idlist as $numitem){
                if ($num==$numitem['num']) {
                    $sqls.=$numitem['itemid'].',';
                }
            }
            if (strlen($sqls)==0) {
                $sqls=0;
            }else{
                $sqls=substr($sqls, 0,strlen($sqls)-1);
            }
            $list=DB::fetch_all('select distinct a.subject,a.tid,a.dateline from %t a  where tid in( '.$sqls. ') order by dateline desc limit 12',array('forum_thread'));
            foreach ($list as $key=>$items)
           {
               $backvalue.=' <li><a href="forum.php?mod=viewthread&tid='.$items['tid'].'&extra=page%3D1">'.$items['subject'].'</a></li>';
           }
           $arr['pagename']=$_GET['pagename'];
            $arr['results']=$backvalue;
        }
    }
    if (!defined('IN_MOBILE')) {
        showmessage($mes, 'plugin.php?id=xctagfavorite:xctagfavoriteshow',$arr);
    }else{
        echo $showmes.$mes;
    }
}elseif ($action=="mshow"&&$operation=="add"){
    $myid=DB::result_first('SELECT tagid FROM %t where uid=%d', array('xc_tagfavorite',$_G['uid']));
    if ($myid!="") {
        $arr=explode(',', $myid);
        $arr_value=join(',', $arr);
        $values="a.tagid in (".$arr_value.") and";
        $myid=$myid.",";
    }
    $tagid=DB::result_first('SELECT tagid FROM %t order by id desc limit 1', array('xc_taglist'));
    if ($tagid!="") {
        $arrtag=explode(',', $tagid);
        $arrtag_value=join(',', $arrtag);
        $morevalues.=" where a.tagid in (".$arrtag_value.") ";
    }
    $list=DB::fetch_all('SELECT  a.tagid as fid,tagname as name ,IFNULL(b.status,0) as status from %t a left join %t b on '.$values.' b.uid=%d  '.$morevalues.' order by fid desc',array('common_tag','xc_tagfavorite',$_G['uid']));
    include template('xctagfavorite:listfourm');
}
function gbk2utf8($data){
    if(is_array($data)){
      return array_map('gbk2utf8', $data);
    }
    return diconv($data,'gbk','utf-8');
  }
