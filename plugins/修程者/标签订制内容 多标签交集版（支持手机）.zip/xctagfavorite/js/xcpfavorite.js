var sublist=JSON.parse(json);
	
		var spans=document.getElementById("subtitle");
		
		spans.onclick=function(e){
			var isexit=selecteds(e.target.id);
			if(!isexit){
			 document.getElementById(e.target.id).className="f-ib f-fl uc-interest-guide-item item uc-interest-guide-item_selected";
			var num=document.getElementById("num").innerText;
			document.getElementById("num").innerText=(Number(num)+1);
			document.getElementById("selectedtitle").innerHTML=document.getElementById("selectedtitle").innerHTML+('<span class="f-ib selected_item" id="'+e.target.id+'a">'+e.target.innerText+'<span class="f-ib f-pr close" id='+e.target.id+'></span></span>');
			}else{
				change(e.target.id);
			}
		}
		var selected=document.getElementById("selectedtitle");
		selected.onclick=function(e){
			change(e.target.id);
		}
		function selecteds(id){
			var selectedlist=document.getElementById("selectedtitle");
			var isexit=false;
			for(var i=0;i<selectedlist.children.length;i++){
				if(id+"a"==selectedlist.children[i].id){
					isexit=true;
					break;
				}
			}
			return isexit;
		}
		
		function change(id){
			if(id.indexOf("a")==-1){
			var num=document.getElementById("num").innerText;
			document.getElementById("num").innerText=(Number(num)-1);
			document.getElementById("selectedtitle").removeChild(document.getElementById(id+"a"));
			if(document.getElementById(id)!=null){
			document.getElementById(id).className="f-ib f-fl uc-interest-guide-item item";
			}
			}
		}
		function submitbtn(){
			var selectedlist=document.getElementById("selectedtitle");
			var pagename=document.getElementById("pagetype").value;
			var isexit=false;
			var selectvalue="";
			for(var i=1;i<selectedlist.children.length;i++){
				selectvalue+=selectedlist.children[i].id+",";
			}
			if(selectvalue.length>0){
				hideWindow('favoritelay');
				ajaxget('plugin.php?id=xctagfavorite:xcfavorite&action=zfbox&operation=showlist&pagename='+pagename+'&vals='+selectvalue.substr(0,selectvalue.length-1)+'&hash='+hashs, "", "", "", null);
			}else{
				alert(wrong);
			}
			
		}
		function succeedhandle_(url,msg,arr) {
			if(arr.pagename=='index'){
				document.getElementById("xqlist").innerHTML=arr.results;
			}else{
				window.location.href=url;
			}
		}