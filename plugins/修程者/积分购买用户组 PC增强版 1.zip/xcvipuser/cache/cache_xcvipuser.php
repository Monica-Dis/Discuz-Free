<?php 
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function build_cache_plugin_xcvipuser() {
    $list=DB::fetch_all('select distinct a.*,b.grouptitle from %t a left join %t b on a.groupid=b.groupid  order by ordernum asc ',array('xc_vipgroup','common_usergroup'));
    $strvalue=array();
    foreach ($list as $k =>  $items){
        $strvalue[$k]=array('grouptitle'=>$items['grouptitle'],'groupid'=>$items['groupid'],'price'=>$items['price'],'aboutday'=>$items['aboutday'],'desc'=>$items['desc'],'ordernum'=>$items['ordernum']);
    }
    require_once libfile('function/cache');
    require_once 'source/plugin/xcvipuser/vjsons.class.php';
    $data=array('xcvip'=>CJSONS::encode($strvalue));
    $cachename='xcvipuser';
    savecache($cachename, $data);
}
?>