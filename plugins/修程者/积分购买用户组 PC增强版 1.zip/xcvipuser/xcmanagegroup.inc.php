<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')||!defined('IN_ADMINCP')) {
    exit('Access Denied');
}
loadcache('plugin');
global $_G;
$arrgroup=$_G['cache']['plugin']['xcvipuser']['buygroup'];
$plugin_setname=lang('plugin/xcvipuser', 'plugin');
$plugin_setmore=lang('plugin/xcvipuser', 'pluginmore');
$plugin_title=lang('plugin/xcvipuser', 'mtitle');
$plugin_num=lang('plugin/xcvipuser', 'ordernum');
$plugin_price=lang('plugin/xcvipuser', 'price');
$plugin_day=lang('plugin/xcvipuser', 'aboutday');
$plugin_desc=lang('plugin/xcvipuser', 'desc');
$plugin_status=lang('plugin/xcvipuser', 'status');
$plugin_stop=lang('plugin/xcvipuser', 'uncheck');
$plugin_run=lang('plugin/xcvipuser', 'ischeck');
$plugin_createtimes=lang('plugin/xcvipuser', 'createtimes');
$plugin_add=lang('plugin/xcvipuser', 'add');
$plugin_submit_fail=lang('plugin/xcvipuser','submit_fail');
$plugin_title_invalid=lang('plugin/xcvipuser','title_invalid');
$plugin_num_invalid=lang('plugin/xcvipuser','url_invalid');
$plugin_back=lang('plugin/xcvipuser','back');
$plugin_edit=lang('plugin/xcvipuser','edits');
$plugin_about=lang('plugin/xcvipuser','num_about');
$plugin_groupabout=lang('plugin/xcvipuser','vipabout');
$pnum = empty($_GET['pagenum']) ? 20 : $_GET['pagenum'];
$page = empty($_GET['page']) ? 1 : $_GET['page'];
$do=$_GET['do'];
$typevalue="special";
$pmods=$_GET['pmod'];
$operation = !empty($_GET['subconfig']) ? $_GET['subconfig'] : 'list';
if ($pmods=='xcmanagegroup') {
    if ($operation=='list'){
        if(!submitcheck('editsubmit')) {
            showtagheader('div', 'vars', 'vars');
            showformheader("plugins&operation=config&identifier=xcvipuser&pmod=xcmanagegroup&subconfig=list", '', 'varsform');
            showtableheader($plugin_setname.$plugin_setmore);
            showsubtitle(array('', $plugin_title,$plugin_price,$plugin_day,$plugin_desc,$plugin_createtimes,$plugin_num,));
            $start_limit = ($page - 1) * $pnum;
            $listcount=DB::result_first('SELECT COUNT(*) FROM %t  ', array('xc_vipgroup'));
            if ($listcount) {
                $multipage = multi($listcount, $pnum, $page, ADMINSCRIPT."?action=plugins&operation=config&do=10&identifier=xcvipuser&pmod=managemember&pagenum=$pnum", 0, 3);
                $lists=DB::fetch_all('select a.*,b.grouptitle from %t a left join  %t b on a.groupid=b.groupid   order by ordernum desc,createtime desc'.DB::limit($start_limit, $pnum),array('xc_vipgroup','common_usergroup'));
                
                foreach($lists as $var) {
                    showtablerow('', array('class="td25"', 'class="td28"'), array(
                        "<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$var[vid]\">",
                        $var['grouptitle'],
                        $var['price'],
                        $var['aboutday'],
                        $var['desc'],
                        dgmdate($var['createtime'],'dt'),
                        $var['ordernum'],
                        "<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&identifier=xcvipuser&pmod=xcmanagegroup&subconfig=edit&formid=$var[vid]\" class=\"act\">$plugin_edit</a>"
                    ));
                }
            }
            showsubmit('editsubmit', 'submit', 'del','<a href='.ADMINSCRIPT.'?action=plugins&operation=config&do='.$do.'&identifier='.$_GET['identifier'].'&pmod=xcmanagegroup&subconfig=add> <input type="button" class="btn" id="addsubmit" name="addsubmit"  value='.$plugin_add.'></a>',$multipage);
            showtablefooter();/*Dism��taobao��com*/
            showformfooter();
            showtagfooter('div');
        }else {
            if(is_array($_GET['delete'])) {
                DB::delete('xc_vipgroup', DB::field('vid', $_GET['delete']));
            }
            cpmsg('plugins_edit_succeed', "action=plugins&operation=config&identifier=xcvipuser&pmod=xcmanagegroup", 'succeed');
        }
    }elseif ($operation=='add'){
        if(!submitcheck('addsubmit')) { 
            
            $grouplist=getgrouplist($arrgroup);
            foreach ($grouplist as $key=>$items){
                $selgroup.= "<option value=\"$items[groupid]\">$items[grouptitle]</option>";
            }
            $url="plugins&operation=config&identifier=xcvipuser&pmod=xcmanagegroup&subconfig=add";
            showformheader($url,'enctype');
            showtableheader();
            showsetting($plugin_title, '', '', "<select name=\"title\">$selgroup</select>",'',0,$plugin_groupabout);
            showsetting($plugin_price, 'price', 1, 'text','',0);
            showsetting($plugin_day, 'aboutday', 365, 'number','',0);
            showsetting($plugin_num, 'num', 0, "number",'',0,$plugin_about);
            showsetting($plugin_desc, 'desc','', "textarea",'',0);
            showtagfooter('tbody');
            showsubmit('addsubmit','submit','','<a href='.ADMINSCRIPT.'?action=plugins&operation=config&identifier=xcvipuser&pmod=xcmanagegroup&subconfig=list> <input type="button" class="btn" id="addsubmit" name="addsubmit"  value='.$plugin_back.'></a>');
            showtablefooter();/*Dism��taobao��com*/
            showformfooter();
        }else {
            if ($_GET['num']<1) {
                cpmsg($plugin_num_invalid, '', 'error');;
            }
            $data = array(
                'groupid' => $_GET['title'],
                'ordernum' => $_GET['num'],
                'desc' => $_GET['desc'],
                'price' => $_GET['price'],
                'aboutday' => $_GET['aboutday'],
                'createtime' => time(),
            );
            DB::insert('xc_vipgroup',$data);
            cpmsg('plugins_edit_succeed', "action=plugins&operation=config&identifier=xcvipuser&pmod=xcmanagegroup", 'succeed');
        }
    }elseif ($operation=='edit'){
        if(!submitcheck('editsubmit')) {
            $bgauto=DB::fetch_first('select * from %t where vid=%d',array('xc_vipgroup',$_GET['formid']));
           
            $grouplist=getgrouplist($arrgroup);
            foreach ($grouplist as $key=>$items){
                $selgroup.= "<option value=\"$items[groupid]\" ".($items['groupid']==$bgauto['groupid']?'selected':'').">$items[grouptitle]</option>";
            }
            $url="plugins&operation=config&identifier=xcvipuser&pmod=xcmanagegroup&subconfig=edit&fromid=".$_GET['formid'];
            showformheader($url,'enctype');
            showtableheader();
            showsetting($plugin_title, '', '', "<select name=\"title\">$selgroup</select>",'',0,$plugin_groupabout);
            showsetting($plugin_price, 'price', $bgauto['price'], 'text','',0);
            showsetting($plugin_day, 'aboutday', $bgauto['aboutday'], 'number','',0);
            showsetting($plugin_num, 'num', $bgauto['ordernum'], "number",'',0,$plugin_about);
            showsetting($plugin_desc, 'desc',$bgauto['desc'], "textarea",'',0);
            showtagfooter('tbody');
            showsubmit('editsubmit','submit','','<a href='.ADMINSCRIPT.'?action=plugins&operation=config&identifier=xcvipuser&pmod=xcmanagegroup&subconfig=list> <input type="button" class="btn" id="addsubmit" name="addsubmit"  value='.$plugin_back.'></a>');
            showtablefooter();/*Dism��taobao��com*/
            showformfooter();
        }else {
            if ($_GET['num']<1) {
                cpmsg($plugin_num_invalid, '', 'error');;
            }
            $data = array(
                'groupid' => $_GET['title'],
                'ordernum' => $_GET['num'],
                'desc' => $_GET['desc'],
                'price' => $_GET['price'],
                'aboutday' => $_GET['aboutday'],
                'createtime' => time(),
            );
            DB::update('xc_vipgroup',$data,array('vid'=>$_GET['fromid']));
            cpmsg('plugins_edit_succeed', "action=plugins&operation=config&identifier=xcvipuser&pmod=xcmanagegroup", 'succeed');
        }
    } 
}
function getgrouplist($arrgroup){
    $arrist=dunserialize($arrgroup);
    $arr_string = join(',', $arrist);
    $grouplist=DB::fetch_all("select groupid, grouptitle from %t  where groupid in (".$arr_string.")",array('common_usergroup'));
    return $grouplist;
}
?>