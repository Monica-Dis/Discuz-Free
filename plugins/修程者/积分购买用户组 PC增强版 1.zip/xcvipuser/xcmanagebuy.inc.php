<?php 
if(!defined('IN_DISCUZ')||!defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$plugin_name=lang('plugin/xcvipuser','pluginuser');
$plugin_kwname=lang('plugin/xcvipuser','username');
$plugin_kwtime=lang('plugin/xcvipuser','buytime');
$plugin_kwtimes=lang('plugin/xcvipuser','mtitle');
$plugin_now=lang('plugin/xcvipuser','paytypes');
$plugin_pay=lang('plugin/xcvipuser','paymoney');
$plugin_back=lang('plugin/xcvipuser','back');
$plugin_default=lang('plugin/xcvipuser','defaultgroup');
$pnum = empty($_GET['pagenum']) ? 20 : $_GET['pagenum'];
$page = empty($_GET['page']) ? 1 : $_GET['page'];
$pmods=$_GET['pmod'];
$uid=$_GET['uid'];
if ($pmods=='xcmanagebuy') {
    showtagheader('div', 'vars', 'vars');
    showtableheader($plugin_name);
    showsubtitle(array('',  $plugin_kwname,$plugin_kwtimes,$plugin_now,$plugin_pay, $plugin_kwtime,'IP'));
    $start_limit = ($page - 1) * $pnum;
    if (!empty($uid)) {
        $sqlcondition='where a.uid='.$uid;
        $backurl='<a href='.ADMINSCRIPT.'?action=plugins&operation=config&identifier=xcvipuser&pmod=xcmanageuser> <input type="button" class="btn" id="addsubmit" name="addsubmit"  value='.$plugin_back.'></a>';
    }
    $listcount=DB::result_first('SELECT COUNT(*) FROM %t a '.$sqlcondition, array('xc_vippay'));
    if ($listcount) {
        $multipage = multi($listcount, $pnum, $page, ADMINSCRIPT."?action=plugins&operation=config&do=10&identifier=xcvipuser&pmod=xcmanagebuy&pagenum=$pnum", 0, 3);
        $lists=DB::fetch_all('select a.*, b.username from %t a  left join %t b on a.uid=b.uid '.$sqlcondition.' order by createtime desc '.DB::limit($start_limit, $pnum),array('xc_vippay','common_member'));
        $i=0;
        foreach($lists as $var) {
            showtablerow('', array('class="td25"', 'class="td28"'), array(
                $i+1,
                $var['username'],
                $var['groupname'],
                $var['paytype'],
                $var['price'],
                dgmdate($var['createtime'],'dt'),
                $var['ip'],
            ));
            $i++;
        }
    }
    showsubmit('', '', '', $backurl, $multipage);
    showtablefooter();/*Dism��taobao��com*/
    showtagfooter('div');
}
?>