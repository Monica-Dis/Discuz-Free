<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')||!defined('IN_ADMINCP')) {
	exit('Access Denied');
}
global $_G;
$pres=$_G['config'][db][1][tablepre];
$vipgroup=$pres.'xc_vipgroup';
$vipuser=$pres.'xc_vipuser';
$vippay=$pres.'xc_vippay';
$sql = <<<EOF
drop table IF EXISTS `$vipgroup`;
drop table IF EXISTS `$vipuser`;
drop table IF EXISTS `$vippay`;
EOF;
runquery($sql);
$cachenames='xcvipuser';
if(!empty($cachenames)) {
    C::t('common_syscache')->delete($cachenames);
}
updatecache();
$finish = TRUE;
?>