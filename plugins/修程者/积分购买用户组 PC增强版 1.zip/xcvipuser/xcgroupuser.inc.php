<?php 
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');
global $_G;
require_once libfile('function/magic');
$pluginvalue=$_G['cache']['plugin']['xcvipuser'];
$moneytype=empty($pluginvalue['moneytype'])?2:$pluginvalue['moneytype'];
$moneytitle=$_G['setting']['extcredits'][$moneytype]['title'];
$jbnums= getuserprofile('extcredits'.$moneytype);
$syssettime=$pluginvalue['lastday'];
$syssetcolor=$pluginvalue['lastdaycolor'];
$dw=$pluginvalue['dw'];
$desc=$pluginvalue['desc'];
if ($pluginvalue['isopen']) {
    $metakeywords=$pluginvalue['seokeyword'];
    $metadescription=$pluginvalue['seodesc'];
    $navtitle=$pluginvalue['seotitle'];
}
$discount=$pluginvalue['discount'];
$action = $_GET['action'];
$operation = $_GET['operation'];
if (empty($_G['uid'])){
    showmessage(lang('plugin/xcvipuser',loginshow),'', array(), array('return' => true));
}
$uid=$_G['uid'];
$grouplist=DB::fetch_all('select c.groupid, c.grouptitle,a.createtime,b.aboutday,b.ordernum,a.price,b.vid,a.isecheck from  %t a left join %t b on a.vid=b.groupid  left join %t c on b.groupid=c.groupid where uid=%d',array('xc_vipuser','xc_vipgroup','common_usergroup',$uid));
$usergroupnum=sizeof($grouplist);
$mygroupid=0;
$ordernum=0;
$ordernumbj=0;
if ($usergroupnum>0) {
    $mygroupid=$grouplist[0]['groupid'];
    $ordernum=$grouplist[0]['ordernum'];
    $ordernumbj=$grouplist[0]['ordernum'];
}
$nowgroupid=$_G[group][groupid];

$arrgroup=$pluginvalue['limituser'];
require_once libfile('function/cache');
$cachename='xcvipuser';
loadcache($cachename);
if (!empty($_G['cache'][$cachename]['xcvip'])) {
    $dts=$_G['cache'][$cachename]['xcvip'];
    $list=getcache($dts);
    foreach ($list as $key=>$items){
        if ($ordernum>=$items['ordernum']) {
            $allmoney=$allmoney+$items['price'];
        }
    }
    $dismoney=$allmoney*$discount/10;
}
$chong=$pluginvalue['paylink'];
$title=lang('plugin/xcvipuser','buystock');
if(empty($action)){
    $page = empty($_GET['page']) ? 1 : $_GET['page'];
    $username=$_G['username'];
    $lasttime=lang('plugin/xcvipuser',notime);
    $zerostyle='visibility: hidden;';
    $defaultgroups= $_G[group][grouptitle];
    $defaultgroup=$defaultgroups;
    if ($mygroupid>0&&$grouplist[0]['isecheck']==0) {
        $zerostyle='';
        $defaultgroup=empty($grouplist[0]['grouptitle'])?$defaultgroups:$grouplist[0]['grouptitle'];
        $daynow=time();
        $lasttime=dgmdate($grouplist[0]['createtime'],'d');
        $lastday=diff_time($grouplist[0]['createtime'], $daynow,$_G['uid'],$pluginvalue['defaultGroup']);
       if ($lastday==0) {
           $zerostyle='visibility: hidden;';
        }
        if ($lastday<$syssettime) {
            $justtime='color:red';
        }
    }
    if ($operation=='paylist') {
        $pnum = empty($_GET['pagenum']) ? 20 : $_GET['pagenum'];
        $start_limit = ($page - 1) * $pnum;
        $sqlcondition='where a.uid='.$uid;
        $listcount=DB::result_first('SELECT COUNT(*) FROM %t a '.$sqlcondition, array('xc_vippay'));
        if ($listcount) {
            $multipage = multi($listcount, $pnum, $page, "plugin.php?id=xcvipuser:xcgroupuser&operation=paylist&pagenum=$pnum", 0, 3);
            $lists=DB::fetch_all('select a.*, b.username from %t a  left join %t b on a.uid=b.uid '.$sqlcondition.' order by createtime desc '.DB::limit($start_limit, $pnum),array('xc_vippay','common_member'));
        }
    }
       include template('xcvipuser:groupuser');    
}elseif ($action=='addbox'&&$operation=='buy') {
    if(empty($_GET['hash']) || $_GET['hash'] != formhash()) {
        showmessage('submit_invalid');
    }
    if ($mygroupid>=$_GET['cid']) {
        showmessage(lang('plugin/xcvipuser','limitshow'));
    }
    if (!limituser($nowgroupid, $arrgroup)) {
        showmessage(lang('plugin/xcvipuser','nolimit'));
    }
    $groupone=DB::fetch_all('select * from %t where groupid=%d',array('xc_vipgroup',$_GET['cid']));
    if (sizeof($groupone)>0) {
       if ($groupone[0]['ordernum']!=($ordernum+1)) {
           showmessage(lang('plugin/xcvipuser','superbuyshow'));
       }
       $stoptime=time()+($groupone[0]['aboutday']*24*60*60);
       if (isenougthmoney($jbnums, $groupone[0]['price'])) {
           showmessage(lang('plugin/xcvipuser','nomoney'));
       }
       insertPayList($groupone[0]['price'],getgroupname($_GET['cid'], $list),lang('plugin/xcvipuser','buystock'));
       changextcredits($_G['uid'],$groupone[0]['price'],$moneytype,lang('plugin/xcvipuser','buystock'));
       if ($usergroupnum==0) {
           insertUser($_GET['cid'], $groupone[0]['price'],$stoptime,$pluginvalue['defaultGroup'],$nowgroupid);
       }else {
           updateUser($_GET['cid'], $groupone[0]['price']+$grouplist[0]['price'],$stoptime,$pluginvalue['defaultGroup'],$nowgroupid);
       }     
    }else {
        showmessage(lang('plugin/xcvipuser','wrongshow'));
    }
    $msg = 'do_success';
    $magvalues = array();
    $magvalues['cid'] = $_GET['cid'];
    $cidarr= array('cid' => $cid, 'msg' => $msg, 'magvalues' => $magvalues);
    if (defined('IN_MOBILE')) {
        showmessage('do_success', 'plugin.php?id=xcvipuser:xcgroupuser', array('formhash' => FORMHASH));
    }else{
        showmessage($cidarr['msg'], 'plugin.php?id=xcvipuser:xcgroupuser', $cidarr['magvalues'], $_GET['quickcomment'] ? array('msgtype' => 3, 'showmsg' => true) : array('showdialog' => 3, 'showmsg' => true, 'closetime' => true));
    }
}elseif ($action=='addbox'&&$operation=='up') {
    if(empty($_GET['hash']) || $_GET['hash'] != formhash()) {
        showmessage('submit_invalid');
    }
    if (!limituser($nowgroupid, $arrgroup)) {
        showmessage(lang('plugin/xcvipuser','nolimit'));
    }
    if ($mygroupid==0) {
        showmessage(lang('plugin/xcvipuser','wrongshow'));
    }else {
        $groupones=DB::fetch_all('select * from %t where groupid=%d',array('xc_vipgroup',$mygroupid));
        $stoptime=$grouplist[0]['createtime']+($groupones[0]['aboutday']*24*60*60);
        if (isenougthmoney($jbnums, $dismoney)) {
            showmessage(lang('plugin/xcvipuser','nomoney'));
        }
        $paytype=lang('plugin/xcvipuser','buymore');
        changextcredits($_G['uid'],$dismoney,$moneytype,$paytype);
        updateUser($mygroupid, $dismoney+$grouplist[0]['price'],$stoptime,$pluginvalue['defaultGroup'],$nowgroupid);
        insertPayList($dismoney,getgroupname($mygroupid, $list),lang('plugin/xcvipuser','buymore'));
        if (defined('IN_MOBILE')) {
           showmessage('do_success', 'plugin.php?id=xcvipuser:xcgroupuser', array('formhash' => FORMHASH));
        }else{
            showmessage('do_success', 'plugin.php?id=xcvipuser:xcgroupuser', '', $_GET['quickcomment'] ? array('msgtype' => 3, 'showmsg' => true) : array('showdialog' => 3, 'showmsg' => true, 'closetime' => true));
        }
    }
}

function isenougthmoney($jfnum,$paynum){
    if ($jfnum<$paynum) {
        return true;
    }
}

function changextcredits($uid,$ttprice,$moneytype,$paytype){
    require_once libfile('function/credit');
    _updatemembercount($uid, array('extcredits'.$moneytype => -$ttprice), true,'',0,'', $paytype, '');
}
function insertUser($vid,$price,$stoptime,$expriygroup,$oldgroup){
    global $_G;
    $insertdata=array(
        'createtime'=>$stoptime,
        'uid'=>$_G['uid'],
        'isecheck'=>0,
        'vid'=>$vid,
        'price'=>$price,
    );
    DB::insert('xc_vipuser',$insertdata);
    updatememebergroup($_G['uid'], $vid,$stoptime,$expriygroup,$oldgroup);
}

function  updateUser($vid,$price,$stoptime,$expriygroup,$oldgroup){
    global $_G;
    $updata=array(
        'createtime'=>$stoptime,
        'price'=>$price,
        'vid'=>$vid,
        'isecheck'=>0,
    );
    DB::update('xc_vipuser',$updata,array('uid'=>$_G['uid']));
    updatememebergroup($_G['uid'], $vid,$stoptime,$expriygroup,$oldgroup);
}

function insertPayList($price,$groupname,$paytype){
    global $_G;
    $insertdata=array(
        'createtime'=>time(),
        'uid'=>$_G['uid'],
        'ip'=>$_G['clientip'],
        'price'=>$price,
        'groupname'=>$groupname,
        'paytype'=>$paytype,
    );
    DB::insert('xc_vippay',$insertdata);
}
function  updatememebergroup($uid,$defaultgroup,$stoptimes,$expriygroup,$oldgroupid){
    $listuserterms=DB::fetch_first('select groupterms from %t where uid=%d ',array('common_member_field_forum',$uid));
    $groupterms = array();
    $stoptime=$stoptimes;
    if (empty($listuserterms)) {
        $groupterms['main'] = array('time' => $stoptime, 'adminid' => -1, 'groupid' => $expriygroup);
        $groupterms['ext'][$defaultgroup] = $stoptime;
    }else {
        $terms=dunserialize($listuserterms['groupterms']);
        $groupterms['main'] = array('time' => $stoptime, 'adminid' =>empty($terms['main']['adminid'])?-1:$terms['main']['adminid'], 'groupid' => $expriygroup);
        $j=0;
        foreach ($terms['ext'] as $key=>$moreitems){
            if ($key==$oldgroupid) {
                $groupterms['ext'][$defaultgroup]=$stoptime;
                $j=1;
            }else {
                $groupterms['ext'][$key]=$moreitems;
            }
        }
        if ($j==0) {
            $groupterms['ext'][$defaultgroup]=$stoptime;
        }
    }
    $grouptermsnew = serialize($groupterms);
    C::t('common_member_field_forum')->update($uid, array('groupterms' => $grouptermsnew));
    $memberdata=array(
        'groupid'=>$defaultgroup,
        'groupexpiry'=>$stoptime,
        'extgroupids'=>$expriygroup,
    );
    DB::update('common_member',$memberdata,array('uid'=>$uid));
}

function diff_time($time1,$time2,$uid,$defaultgroup){
    if($time1 <= $time2){
        return 0;
    }else {
        $diff = ($time1-$time2)/86400;
        return intval($diff);
    }
}
function limituser($groupid,$arrgroup){
    foreach (dunserialize($arrgroup) as $key=>$items){
         if ($groupid==$items) {
             return  true;
         }
    }   
}
function getgroupname($id,$list){
    foreach ($list as $key=>$items){
        if ($id==$items['groupid']) {
            $returnvalue= $items['grouptitle'];
        }
    }
    return $returnvalue;
}

function getcache($dts){
    global $_G;
    if (strtolower($_G['charset'])=='gbk'||strtolower($_G['charset'])=='big5') {
        $arr=json_decode($dts,true);
        $list=array();
        foreach($arr as $k=>$item){
            $list[$k]['grouptitle']=diconv($item['grouptitle'],'utf-8');
            $list[$k]['desc']=diconv($item['desc'],'utf-8');
            $list[$k]['price']=$item['price'];
            $list[$k]['groupid']=$item['groupid'];
            $list[$k]['aboutday']=$item['aboutday'];
            $list[$k]['ordernum']=$item['ordernum'];
        }
        return $list;
    }
    return json_decode($dts,true);
}
?>