<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')||!defined('IN_ADMINCP')) {
	exit('Access Denied');
}
global $_G;
$pres=$_G['config'][db][1][tablepre];
$vipgroup=$pres.'xc_vipgroup';
$vipuser=$pres.'xc_vipuser';
$vippay=$pres.'xc_vippay';
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `$vipgroup` (
  `vid` int(10) NOT NULL AUTO_INCREMENT,
  `groupid` int(10) NOT NULL,
  `desc` varchar(500) NOT NULL,
  `price` int(10) NOT NULL,
  `aboutday` int(10) NOT NULL,
  `ordernum` int(3) NOT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`vid`)
);
CREATE TABLE IF NOT EXISTS `$vipuser` (
  `oid` int(10) NOT NULL AUTO_INCREMENT,
  `createtime` int(10) NOT NULL,
  `uid` mediumint(8) NOT NULL,
  `vid` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `isecheck` tinyint(1) unsigned NOT NULL default '0',
  INDEX `indexvalue` (`createtime`,`vid`),
  PRIMARY KEY (`oid`)
);
CREATE TABLE IF NOT EXISTS `$vippay` (
  `pid` int(10) NOT NULL AUTO_INCREMENT,
  `createtime` int(10) NOT NULL,
  `uid` mediumint(8) NOT NULL,
  `groupname` varchar(50) NOT NULL,
  `paytype` varchar(10) NOT NULL,
  `ip` char(15) NOT NULL,
  `price` int(10) NOT NULL,
  INDEX `indexvalue` (`uid`),
  PRIMARY KEY (`pid`)
);
EOF;
runquery($sql);
$finish = TRUE;
?>