<?php 
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_xcvipuser{
    function __construct(){

    }
    
    function global_header() {
        global $_G;
        $uid=$_G['uid'];
        if ($_G['basefilename'].'?mode='.$_G['mod']=='home.php?mode=spacecp') {
            $terms='';
            $listuserterms=DB::fetch_first('select b.groupterms from %t a left join %t b on a.uid=b.uid where a.uid=%d and groupexpiry=0 and  groupterms<>%s',array('common_member','common_member_field_forum',$uid,$terms));
            if (!empty($listuserterms)) {
                $terms=dunserialize($listuserterms['groupterms']);
                if (time()>$terms['main']['time'] ) {
                    $grouplist=DB::fetch_all('select * from %t where type=%s',array('common_usergroup','member'));
                    $moregroupid=$terms['main']['groupid'];
                    $jf=$_G['member'][credits];
                    $istrue=0;
                    $min=0;
                    $max=0;
                    foreach ($grouplist as $key=>$items){
                        if ($items['groupid']==$moregroupid) {
                           $min=$items['creditshigher'];
                           $max=$items['creditslower'];
                            $istrue=1;
                            break;
                        }
                    }
                    if ($istrue==1&($jf<$min||$jf>$max)) {
                        foreach($grouplist as $keys=>$values){
                            if ($jf>=$values['creditshigher']&&$jf<=$values['creditslower']) {
                                $moregroupid=$values['groupid'];
                            }
                        }
                    }
                    $memberdata=array(
                        'extgroupids'=>'',
                        'groupid'=>$moregroupid,
                    );
               DB::update('common_member',$memberdata,array('uid'=>$uid));
               C::t('common_member_field_forum')->update($uid, array('groupterms' => ''));
                    $updata=array(
                    'vid'=>$terms['main']['groupid'],
                    );
               DB::update('xc_vipuser',$updata,array('uid'=>$_G['uid']));
               require_once libfile('function/credit');
               $paytype=lang('plugin/xcvipuser','paychange');
               _updatemembercount($uid, array('extcredits2' =>1), true,'',0,'', $paytype, ''); 
            }
            }
        }
    }
}
?>