<?php 
if(!defined('IN_DISCUZ')||!defined('IN_ADMINCP')) {
    exit('Access Denied');
}
loadcache('plugin');
global $_G;
$pluginvalue=$_G['cache']['plugin']['xcvipuser'];
$syssettime=$pluginvalue['lastday'];
$plugin_name=lang('plugin/xcvipuser','pluginuser');
$plugin_kwname=lang('plugin/xcvipuser','username');
$plugin_kwtime=lang('plugin/xcvipuser','optime');
$plugin_kwtimes=lang('plugin/xcvipuser','oldgroup');
$plugin_now=lang('plugin/xcvipuser','nowgroup');
$plugin_pay=lang('plugin/xcvipuser','justday');
$plugin_more=lang('plugin/xcvipuser','seemore');
$plugin_default=lang('plugin/xcvipuser','defaultgroup');
$pnum = empty($_GET['pagenum']) ? 20 : $_GET['pagenum'];
$page = empty($_GET['page']) ? 1 : $_GET['page'];
$pmods=$_GET['pmod'];
if ($pmods=='manageday') {
    $daynow=time();
    $expday=$daynow+($syssettime*24*60*60);
    showtagheader('div', 'vars', 'vars');
    showtableheader($plugin_name);
    showsubtitle(array('',  $plugin_kwname,$plugin_now,$plugin_pay, $plugin_kwtime));
    $start_limit = ($page - 1) * $pnum;
    $listcount=DB::result_first('select count(*) from %t a where isecheck=0 and createtime<=%d  ', array('xc_vipuser',$expday));
    if ($listcount) {
        $grouplist=DB::fetch_all('select b.groupid,c.grouptitle from  %t b  left join %t c on b.groupid=c.groupid',array('xc_vipgroup','common_usergroup'));
        $multipage = multi($listcount, $pnum, $page, ADMINSCRIPT."?action=plugins&operation=config&do=10&identifier=xcvipuser&pmod=manageday&pagenum=$pnum", 0, 3);
        $lists=DB::fetch_all('select a.*, b.username from %t a  left join %t b on a.uid=b.uid  where isecheck=0 and createtime<=%d order by (createtime-%d) desc '.DB::limit($start_limit, $pnum),array('xc_vipuser','common_member',$expday,$daynow));
        $i=0;
        foreach($lists as $var) {
            showtablerow('', array('class="td25"', 'class="td28"'), array(
                $i+1,
                $var['username'],
                getgroupname($var['vid'], $grouplist,$plugin_default),
                intval(($var['createtime']-$daynow)/86400),
                dgmdate($var['createtime'],'dt')
            ));
            $i++;
        }
    }
    showsubmit('', '', '', '', $multipage);
    showtablefooter();/*Dism��taobao��com*/
    showtagfooter('div');
}

function getgroupname($id,$list,$defaultuser){
    $returnvalue=$defaultuser;
    foreach ($list as $key=>$items){
        if ($id==$items['groupid']) {
            $returnvalue= $items['grouptitle'];
        }
    }
    return $returnvalue;
}
?>