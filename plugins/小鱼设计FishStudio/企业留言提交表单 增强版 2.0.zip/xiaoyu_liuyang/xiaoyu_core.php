<?php

/*
 * xiaoyu process
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * From С������Ŷ�(www.minfish.com)
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');

function plugin_ins_error($identifier){
	global $_G;
	cpmsg('plugins_install_succeed', 'action=plugins&hl='.$pluginid, 'succeed');
}
