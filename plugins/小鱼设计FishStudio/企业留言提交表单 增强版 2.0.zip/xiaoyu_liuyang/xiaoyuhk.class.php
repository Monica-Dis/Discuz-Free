<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: Ӧ�ø���֧�֣�https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class plugin_xiaoyu_liuyang {
}
class plugin_xiaoyu_liuyang_portal extends plugin_xiaoyu_liuyang {
    function index_protaltop_output() {
    }
}
