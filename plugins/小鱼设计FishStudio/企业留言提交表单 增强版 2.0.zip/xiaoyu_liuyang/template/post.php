<?php exit;?>
<!--{template common/header}-->

<!--{if !$_G[inajax]}--><div class="xiaoyu_ct wp cl"><!--{/if}-->

	<h3 class="flb xiaoyu_flb">
		<em id="return_$_G[gp_handlekey]">{lang xiaoyu_liuyang:xiaoyuadmin}</em>
		<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_G[gp_handlekey]');" class="flbc" title="{lang xiaoyu_liuyang:xiaoyuadminclose}">{lang xiaoyu_liuyang:xiaoyuadminclose}</a></span><!--{/if}-->
	</h3>
	<form method="post" autocomplete="off" id="quesmod_{$pid}" name="quesmod_{$pid}"  action="plugin.php?id=xiaoyu_liuyang&pid=$pid&mod=$mod" {if $_G[inajax]} onsubmit="ajaxpost(this.id, 'return_$_G[gp_handlekey]', null, null, null,null);"{/if}>
		<input type="hidden" name="msgadminsubmit" value="true" />
		<input type="hidden" name="referer" value="$_G[referer]" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_G[gp_handlekey]" /><!--{/if}-->
        <div class="c xiaoyu_altw">
        <!--{if $mod == 'edit'}-->
        <div class="xiaoyu_mbn">
       		<p class="tabtxt1">{lang xiaoyu_liuyang:fishname}<span>*</span></p><input type="text" value="$edmsg['fishname']" id="fishname" name="fishname">
        </div>
        <div class="xiaoyu_mbn">
        	<p>{lang xiaoyu_liuyang:fishemail}</p><input type="text" value="$edmsg['fishemail']" id="fishemail" name="fishemail">
        </div>
        <div class="xiaoyu_mbn">
        	<p>{lang xiaoyu_liuyang:fishtel}</p><input type="text" value="$edmsg['fishtel']" id="fishtel" name="fishtel">
        </div>
        <div class="xiaoyu_mbn">
       		<p class="tabtxt1">{lang xiaoyu_liuyang:fishtitle}<span>*</span></p><input type="text" value="$edmsg['fishtitle']" id="fishtitle" name="fishtitle" />
        </div>
        <div class="xiaoyu_mbn">
       		<p class="tabtxt1">{lang xiaoyu_liuyang:fishmsg}<span>*</span></p>
        <textarea name="fishmsg" id="fishmsg" class="xiaoyu_area" >$edmsg['fishmsg']</textarea>
        </div> 
        <!--{elseif $mod == 'reply' }-->
        <div class="xiaoyu_mbn">
        	<p>{lang xiaoyu_liuyang:replycontent}</p>
        <textarea name="remsg" id="remsg" class="xiaoyu_area" >$edmsg['remsg']</textarea>
        </div> 
        <!--{elseif $mod == 'delete' }-->
        <div class="alert_info xiaoyu_echoinfo">
        	{lang xiaoyu_liuyang:xiaoyudelsub}
        </div>
        <!--{elseif $mod == 'hidemsg' }-->
        <div class="alert_info xiaoyu_echoinfo">
        <!--{if $edmsg['hidemsg']}-->  {lang xiaoyu_liuyang:xiaoyudispsub} <!--{else}--> {lang xiaoyu_liuyang:xiaoyushowsub} <!--{/if}-->
        </div>	  
        <!--{/if}-->
        </div>
		<div class="xiaoyu_submit">
			<button type="submit" name="adminsubmit_btn" id="adminsubmit_btn" class="xiaoyu_pn" value="true">{lang xiaoyu_liuyang:xiaoyupostsub}</button>
		</div>
	</form>
<!--{if !$_G[inajax]}--></div><!--{/if}-->
<link rel="stylesheet" type="text/css" href="source/plugin/xiaoyu_liuyang/template/xiaoyu_main.css" />
<!--{template common/footer}-->

