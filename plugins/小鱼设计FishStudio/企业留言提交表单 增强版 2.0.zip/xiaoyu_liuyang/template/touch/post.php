<?php exit;?>
<!--{if $xiaoyulyset[xiaoyutpl]==1}--><!--{subtemplate xiaoyu_liuyang:header}--><!--{else}--><!--{template common/header}--><!--{/if}-->     
<!--{if !$_G[inajax]}-->
	<div class="xiaoyu_ct cl">
<!--{/if}-->

	<h3 class="flb xiaoyu_flb">
		<em id="return_$_G[gp_handlekey]">{lang xiaoyu_liuyang:xiaoyuadmin}</em>
		<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_G[gp_handlekey]');" class="flbc" title="{lang xiaoyu_liuyang:xiaoyuadminclose}">{lang xiaoyu_liuyang:xiaoyuadminclose}</a></span><!--{/if}-->
	</h3>
	<form method="post" autocomplete="off" id="quesmod_{$pid}" name="quesmod_{$pid}"  action="plugin.php?id=xiaoyu_liuyang&pid=$pid&mod=$mod" {if $_G[inajax]} onsubmit="ajaxpost(this.id, 'return_$_G[gp_handlekey]', null, null, null,null);"{/if}>
		<input type="hidden" name="msgadminsubmit" value="true" />
		<input type="hidden" name="referer" value="$_G[referer]" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_G[gp_handlekey]" /><!--{/if}-->
        <div class="xqboxr"> 
        <!--{if $mod == 'edit'}-->
 
  <div class="fishtab1">
     <table> 
      <tbody>
       <tr class="changeinputborder"> 
        <td colspan="3"><p class="tabtxt1">{lang xiaoyu_liuyang:fishname}<span>*</span></p><input type="text"  value="$edmsg['fishname']" id="xiaoyuname" name="fishname" class="bdbttx1" /></td> 
       </tr> 
      </tbody>
     </table>
    </div>
    
    <div class="fishtab1"> 
     <table> 
      <tbody>
       <tr class="changeinputborder"> 
        <td><p class="tabtxt1">{lang xiaoyu_liuyang:fishemail}</p><input type="text"  value="$edmsg['fishemail']" id="fishemail" name="fishemail"  class="bdbttx1" /></td> 
       </tr> 
      </tbody>
     </table> 
    </div> 
    
    <div class="fishtab2"> 
     <table> 
      <tbody>
       <tr class="changeinputborder">  
        <td><p class="tabtxt1">{lang xiaoyu_liuyang:fishtel}</p><input type="text"  value="$edmsg['fishtel']" id="fishtel" name="fishtel"  class="bdbttx1" /></td> 
       </tr> 
      </tbody>
     </table> 
    </div>
    <div class="fishtab1">
     <table> 
      <tbody>
       <tr class="changeinputborder">  
        <td><p class="tabtxt1">{lang xiaoyu_liuyang:fishtitle}<span>*</span></p><input type="text"  value="$edmsg['fishtitle']" id="fishqq" name="fishtitle" class="bdbttx1" /></td> 
       </tr> 
      </tbody>
     </table>
    </div>
    <div class="fishtab3"> 
     <table> 
      <tbody>
       <tr class="changeinputborder"> 
        <td><p class="tabtxt1">{lang xiaoyu_liuyang:fishmsg}<span>*</span></p><textarea name="fishmsg" id="fishmsg" class="bdbttx2">$edmsg['fishmsg']</textarea> <br />
        <span style="color: gray; font-size: 12px; ">{$xiaoyulyset['msgfooter']}</span></td> 
       </tr> 
      </tbody>
     </table> 
    </div> 
        
        <!--{elseif $mod == 'reply' }-->

   <div class="fishtab3"> 
     <table> 
      <tbody>
       <tr class="changeinputborder"> 
        <td><p class="tabtxt1">{lang xiaoyu_liuyang:replycontent}</p><textarea name="remsg" id="remsg" class="bdbttx2">$edmsg['remsg']</textarea>
       </tr> 
      </tbody>
     </table> 
    </div>
        
        <!--{elseif $mod == 'delete' }-->
        <div class="alert_info xiaoyu_echoinfo">
        	{lang xiaoyu_liuyang:xiaoyudelsub}
        </div>
        <!--{elseif $mod == 'hidemsg' }-->
        <div class="alert_info xiaoyu_echoinfo">
        <!--{if $edmsg['hidemsg']}-->  {lang xiaoyu_liuyang:xiaoyudispsub} <!--{else}--> {lang xiaoyu_liuyang:xiaoyushowsub} <!--{/if}-->
        </div>	  
        <!--{/if}-->
        
    <div class="fishtab5"> 
     <table> 
      <tbody>
       <tr> 
        <td><input type="submit" id="postsubm_bt" name="adminsubmit_btn"  class="xqtjan" value="{lang xiaoyu_liuyang:xiaoyupostsub}" /></td> 
       </tr> 
      </tbody>
     </table>
    </div>
     </div>   
	</form>
    
<!--{if !$_G[inajax]}-->
</div>
<!--{/if}-->
<link rel="stylesheet" type="text/css" href="source/plugin/xiaoyu_liuyang/template/xiaoyu_toch.css" />
<style>.g_header .bar{ background:$xiaoyulyset[tplcolor]}.top .p1 .fh,.xiaoyu_lylist_box .fh{ border-color:$xiaoyulyset[tplcolor]}</style>
<!--{if $xiaoyulyset[xiaoyutpl]==1}--><!--{subtemplate xiaoyu_liuyang:footer}--><!--{else}--><!--{template common/footer}--><!--{/if}-->   
