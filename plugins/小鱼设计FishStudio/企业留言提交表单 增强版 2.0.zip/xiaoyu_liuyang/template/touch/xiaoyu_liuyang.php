<?php exit;?>
<!--{if $xiaoyulyset[xiaoyutpl]==1}--><!--{subtemplate xiaoyu_liuyang:header}--><!--{else}--><!--{template common/header}--><!--{/if}-->     
<div class="about_pic"><img src="source/plugin/xiaoyu_liuyang/template/img/c_b.jpg"></div>
<div class="g_cw">
<div class="top"><p class="p1"><em class="fh"></em>{lang xiaoyu_liuyang:fishdqwz}</p><a>{lang xiaoyu_liuyang:fishsy}</a> &gt; <a class="box">{lang xiaoyu_liuyang:fishlxwm}</a></div>	
<div class="xiaoyu_contact">
<div class="xiaoyu_text">$xiaoyulyset[xiaoyulyinfo]</div>
<!--{if $_G['page'] == 1 || empty($msglist)}-->
    <form id="postwd" name="postwd"  enctype="multipart/form-data" method="post" action="plugin.php?id=xiaoyu_liuyang" >
    <input type="hidden" name="formhash" value="{FORMHASH}">
    <input type="hidden" name="postmsgsubmit" value="true">
    <input type="hidden" name="bid" value="{$bid}">
        <div class="rt">
            <p><input type="text" id="xiaoyuname" name="fishname" placeholder="{lang xiaoyu_liuyang:fishname} {lang xiaoyu_liuyang:fishbt}" class="input"></p>
            <p><input type="text" id="fishemail" name="fishemail" placeholder="{lang xiaoyu_liuyang:fishemail}" class="input"></p>
            <p><input type="text" id="fishtel" name="fishtel" placeholder="{lang xiaoyu_liuyang:fishtel}" class="input"></p>
            <p><input type="text" placeholder="{lang xiaoyu_liuyang:fishtitle} {lang xiaoyu_liuyang:fishbt}" id="fishtitle" name="fishtitle" class="input" /></p>
            <p><textarea name="fishmsg" id="fishmsg" placeholder="{lang xiaoyu_liuyang:fishmsg} {lang xiaoyu_liuyang:fishbt}" class="ly_text" ></textarea></p>
            <input type="submit" id="postsubm_bt" name="postsubm_bt"  class="xqtjan" value="{lang xiaoyu_liuyang:xiaoyupost}" >
        </div>
    </form>
 <!--{/if}-->
</div>		

<!--{if !empty($msglist)}-->
<div class="xiaoyu_lylist_box cl">
<div class="lsttitle"><em class="fh"></em>{lang xiaoyu_liuyang:fishpostlist}</div>
   <div class="xiaoyu_ly cl">
   <!--{loop $msglist $key $edmsg}--> 
    <div class="newleavlist"> 
     <p class="newleavlist_title">{lang xiaoyu_liuyang:xiaoyulytitle}{$edmsg['fishtitle']} </p> 
     <p class="newleavlist_cont">{$edmsg['fishmsg']}��<span>{lang xiaoyu_liuyang:xiaoyulyname}{$edmsg['fishname']}</span>
      <!--{if $_G['adminid'] == 1  ||  in_array ( $_G['member'] ['groupid'], $postadmin )  || ($_G['uid'] && $_G['uid'] == $edmsg['authoruid']) }-->
        <!--{if !empty($edmsg['fishtel'])}--><span>Tel:{$edmsg['fishtel']}</span><!--{/if}-->
        <!--{if !empty($edmsg['fishqq'])}--><span>QQ:{$edmsg['fishqq']}</span><!--{/if}-->
        <!--{if !empty($edmsg['fishemail'])}--><span>E-mail:{$edmsg['fishemail']}</span><!--{/if}-->
        <!--{/if}-->
     <span>{lang xiaoyu_liuyang:xiaoyulytime}{$edmsg['dateline']}</span>��</p> 
     <p class="newleavlist_answer"> {lang xiaoyu_liuyang:adminreply} {if !empty($edmsg['remsg'])}$edmsg['remsg']{else}{lang xiaoyu_liuyang:xiaoyunoreply}{/if} </p> 
      <!--{if $_G['adminid'] == 1  ||  in_array ( $_G['member'] ['groupid'], $postadmin )  || ($_G['uid'] && $_G['uid'] == $edmsg['authoruid'])}-->
       <div class="xiaoyu_neededit">
        <!--{if  $_G['adminid'] == 1  ||  in_array ( $_G['member'] ['groupid'], $postadmin )  || ($_G['uid'] && $_G['uid'] == $edmsg['authoruid'] && empty($edmsg['remsg'])) }-->
        <a href="plugin.php?id=xiaoyu_liuyang&pid={$key}&mod=edit" id="edit">{lang xiaoyu_liuyang:xiaoyuedit} </a>
        <!--{/if}-->
        <!--{if  $_G['adminid'] == 1  ||  in_array ( $_G['member'] ['groupid'], $postadmin ) }-->
        <a href="plugin.php?id=xiaoyu_liuyang&pid={$key}&mod=delete" id="delete" >{lang xiaoyu_liuyang:xiaoyudel}</a>
        <a href="plugin.php?id=xiaoyu_liuyang&pid={$key}&mod=hidemsg" id="hidemsg"><!--{if $edmsg['hidemsg']}--><em style="color:#ff6f00">{lang xiaoyu_liuyang:xiaoyudisp}</em><!--{else}--><em style="color:blue">{lang xiaoyu_liuyang:xiaoyushow}</em><!--{/if}--></a>
        <a href="plugin.php?id=xiaoyu_liuyang&pid={$key}&mod=reply" id="reply" >{lang xiaoyu_liuyang:xiaoyureply}</a>
        <!--{/if}-->
       </div>
       <!--{/if}--> 
    </div>
    <!--{/loop}-->
    </div>
  <div id="pgt" class="xiaoyu_pgs cl">$multipage</div>
  </div>
<!--{/if}-->   
</div>
<link rel="stylesheet" type="text/css" href="source/plugin/xiaoyu_liuyang/template/xiaoyu_toch.css" />
<style>.g_header .bar,.xiaoyu_pgs .pg strong,.xiaoyu_pgs .pg a:hover, .xiaoyu_pgs .pgb a:hover{ background:$xiaoyulyset[tplcolor]}.xiaoyu_pgs .pg strong,.top .p1 .fh,.xiaoyu_lylist_box .fh,.xiaoyu_pgs .pg a:hover, .xiaoyu_pgs .pgb a:hover{ border-color:$xiaoyulyset[tplcolor]}</style>
<!--{if $xiaoyulyset[xiaoyutpl]==1}--><!--{subtemplate xiaoyu_liuyang:footer}--><!--{else}--><!--{template common/footer}--><!--{/if}-->   
   