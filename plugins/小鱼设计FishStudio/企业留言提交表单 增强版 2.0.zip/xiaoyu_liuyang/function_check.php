<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: Ӧ�ø���֧�֣�https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if (!ckfishname($_GET['fishname'])) showmessage('xiaoyu_liuyang:xiaoyu_ckname', '', '', array(
    'alert' => 'error'
));
if (!empty($_GET['fishqq']) && !ckfishqq($_GET['fishqq'])) showmessage('xiaoyu_liuyang:xiaoyu_ckqq', '', '', array(
    'alert' => 'error'
));
if (!empty($_GET['fishtel']) && !ckfishtel($_GET['fishtel'])) showmessage('xiaoyu_liuyang:xiaoyu_cktel', '', '', array(
    'alert' => 'error'
));
if (!empty($_GET['fishemail']) && !ckemail($_GET['fishemail'])) showmessage('xiaoyu_liuyang:xiaoyu_ckemail', '', '', array(
    'alert' => 'error'
));
if (empty($_GET['fishtitle']) || !ckfishtitle($_GET['fishtitle'])) showmessage('xiaoyu_liuyang:xiaoyu_cktitle', '', '', array(
    'alert' => 'error'
));
if (empty($_GET['fishmsg']) || !ckfishmsg($_GET['fishmsg'])) showmessage('xiaoyu_liuyang:xiaoyu_ckmsg', '', '', array(
    'alert' => 'error'
));
$fishname = preg_replace('/"([^"]*)"/', '��${1}��', $_GET['fishname']);
$fishname = fishfiltrate($fishname);
$fishtel = preg_replace('/"([^"]*)"/', '��${1}��', $_GET['fishtel']);
$fishtel = fishfiltrate($fishtel);
$fishemail = preg_replace('/"([^"]*)"/', '��${1}��', $_GET['fishemail']);
$fishemail = fishfiltrate($fishemail);
$fishqq = preg_replace('/"([^"]*)"/', '��${1}��', $_GET['fishqq']);
$fishqq = fishfiltrate($fishqq);
$fishtitle = preg_replace('/"([^"]*)"/', '��${1}��', $_GET['fishtitle']);
$fishtitle = fishfiltrate($fishtitle);
$fishmsg = preg_replace('/"([^"]*)"/', '��${1}��', $_GET['fishmsg']);
$fishmsg = fishfiltrate($fishmsg);