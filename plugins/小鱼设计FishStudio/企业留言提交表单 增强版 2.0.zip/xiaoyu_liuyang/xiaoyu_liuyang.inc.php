<?php

/*
 * xiaoyu process
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * From С������Ŷ�(www.minfish.com)
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');/*dism-Taobao-com*/
$xiaoyulyset = $_G['cache']['plugin']['xiaoyu_liuyang'];
$postadmin = unserialize($xiaoyulyset['postadmin']);
$postgroups = unserialize($xiaoyulyset['postgroups']);
$hidemsg = $xiaoyulyset['hidemsg'];
$fishseccode = $xiaoyulyset['fishseccode'];
$fishpostnum = $xiaoyulyset['postnum'] ? $xiaoyulyset['postnum'] : 10;
$mod = preg_replace('/[^\[A-Za-z0-9_\]]/', '', $_GET['mod']);
$mod = empty($mod) ? 'view' : $mod;
$uid = $_G['uid'];
$pid = intval($_GET['pid']);
$navtitle = $xiaoyulyset['navtitle'];
$perpage = intval($xiaoyulyset['fish_perpage']);
$page = addslashes($_GET['page']) ? addslashes($_GET['page']) : 1;
if ($page > 1) {
    $cut = ($page - 1) * $perpage;
} else {
    $cut = 0;
}
if ($mod == 'view') {
    if (submitcheck('postmsgsubmit', 0, 0, 0)) {
        if ($_G['uid']) {
            $postarr = DB::fetch_first(" SELECT count(*) as count FROM " . DB::table('xiaoyu_liuyang') . " WHERE authoruid=" . $_G['uid']);
        } else {
            $postarr = DB::fetch_first(" SELECT count(*) as count FROM " . DB::table('xiaoyu_liuyang') . " WHERE ip='$_G[clientip]'");
        }
        if ($postarr['count'] >= $fishpostnum) {
            showmessage('xiaoyu_liuyang:xiaoyu_submitnum', '', '', array(
                'alert' => 'error'
            ));
        }
        if (!in_array($_G['member']['groupid'], $postgroups)) {
            showmessage('xiaoyu_liuyang:xiaoyu_notlogin', '', '', array(
                'login' => 1
            ));
        }
        require_once 'function_check.php';
        $data = array(
            'authoruid' => $_G['uid'] ? $_G['uid'] : '0',
            'author' => $_G['username'] ? $_G['username'] : lang('plugin/xiaoyu_liuyang', 'xiaoyu_guest') . $_G['sid'],
            'dateline' => $_G['timestamp'],
            'ip' => $_G['clientip'],
            'fishname' => dhtmlspecialchars($fishname) ,
            'fishtel' => dhtmlspecialchars($fishtel) ,
            'fishemail' => dhtmlspecialchars($fishemail) ,
            'fishqq' => dhtmlspecialchars($fishqq) ,
			'fishtitle' => dhtmlspecialchars($fishtitle) ,
            'fishmsg' => dhtmlspecialchars($fishmsg) ,
            'hidemsg' => $hidemsg ? 0 : 1
        );
        DB::insert('xiaoyu_liuyang', $data, true);
        showmessage(lang('plugin/xiaoyu_liuyang', 'xiaoyu_postok') . $alertmsg, 'plugin.php?id=xiaoyu_liuyang', array() , array(
            'showdialog' => true,
            'locationtime' => true
        ));
    } else {
        if ($_G['adminid'] == 1 || in_array($_G['member']['groupid'], $postadmin)) {
            $show = '1=1';
        }elseif($_G['uid'] > 0) {
            $show = ' hidemsg = 1 || authoruid = ' . $_G['uid'];
        }else{
			$show = ' hidemsg = 1 || authoruid = -999';
		}
        $msgarr = DB::fetch_first(" SELECT count(*) as count FROM " . DB::table('xiaoyu_liuyang') . " WHERE " . $show);
        $msgcount = $msgarr['count'];
        unset($msgarr);
        $multipage = multi($msgcount, $perpage, $page, "plugin.php?id=xiaoyu_liuyang&mod=view");
        $query = DB::query(" SELECT * FROM " . DB::table('xiaoyu_liuyang') . " WHERE " . $show . "  ORDER by pid DESC  LIMIT $cut,$perpage");
        while ($msgs = DB::fetch($query)) {
            $msglist[$msgs['pid']]['authoruid'] = $msgs['authoruid'];
            $msglist[$msgs['pid']]['author'] = $msgs['author'];
            $msglist[$msgs['pid']]['ip'] = $msgs['ip'];
            $msglist[$msgs['pid']]['fishname'] = $msgs['fishname'];
            $msglist[$msgs['pid']]['fishtel'] = $msgs['fishtel'];
            $msglist[$msgs['pid']]['fishemail'] = $msgs['fishemail'];
            $msglist[$msgs['pid']]['fishqq'] = $msgs['fishqq'];
			$msglist[$msgs['pid']]['fishtitle'] = $msgs['fishtitle'];
            $msglist[$msgs['pid']]['fishmsg'] = $msgs['fishmsg'];
            $msglist[$msgs['pid']]['adminuid'] = $msgs['adminuid'];
            $msglist[$msgs['pid']]['adminname'] = $msgs['adminname'];
            $msglist[$msgs['pid']]['hidemsg'] = $msgs['hidemsg'];
            $msglist[$msgs['pid']]['remsg'] = $msgs['remsg'];
			$msglist[$msgs['pid']]['dateline'] = defined('IN_MOBILE') ? dgmdate($msgs['dateline'], d) : dgmdate($msgs['dateline']);
            $msglist[$msgs['pid']]['retime'] = defined('IN_MOBILE') ? dgmdate($msgs['retime'], d) : dgmdate($msgs['retime']);
        }
        unset($query);
        unset($msgs);
        include template('xiaoyu_liuyang:xiaoyu_liuyang');
    }
} elseif ($mod == 'edit' && $pid) {
    $edmsg = DB::fetch_first(" SELECT *  FROM " . DB::table('xiaoyu_liuyang') . " WHERE pid = " . $pid);
    if (!($_G['adminid'] == 1 || ($_G['uid'] == $edmsg['authoruid']) || in_array($_G['member']['groupid'], $postadmin))) {
        showmessage('xiaoyu_liuyang:xiaoyu_notlogin', '', '', array(
            'alert' => 'error'
        ));
    }
    if (!submitcheck('msgadminsubmit')) {
        include template('xiaoyu_liuyang:post');
    } else {
        require_once 'function_check.php';
        $data = array(
            'fishname' => dhtmlspecialchars($fishname) ,
            'fishtel' => dhtmlspecialchars($fishtel) ,
            'fishemail' => dhtmlspecialchars($fishemail) ,
            'fishqq' => dhtmlspecialchars($fishqq) ,
			'fishtitle' => dhtmlspecialchars($fishtitle) ,
            'fishmsg' => dhtmlspecialchars($fishmsg)
        );
        DB::update('xiaoyu_liuyang', $data, "pid='$pid'");
    }
    showmessage('xiaoyu_liuyang:xiaoyu_posteditok', 'plugin.php?id=xiaoyu_liuyang', array() , array(
        'showdialog' => true,
        'locationtime' => true
    ));
} else {
    if (!($_G['adminid'] == 1 || in_array($_G['member']['groupid'], $postadmin))) {
        showmessage('xiaoyu_liuyang:xiaoyu_notlogin', '', '', array(
            'alert' => 'error'
        ));
    }
    $edmsg = DB::fetch_first(" SELECT *  FROM " . DB::table('xiaoyu_liuyang') . " WHERE pid = " . $pid);
    if ($mod == 'hidemsg' && $pid) {
        if (!submitcheck('msgadminsubmit')) {
            include template('xiaoyu_liuyang:post');
        } else {
            $data = array(
                'hidemsg' => $edmsg['hidemsg'] ? 0 : 1,
            );
            DB::update('xiaoyu_liuyang', $data, "pid='$pid'");
            showmessage('xiaoyu_liuyang:xiaoyu_showok', 'plugin.php?id=xiaoyu_liuyang', array() , array(
                'showdialog' => true,
                'locationtime' => true
            ));
        }
    } elseif ($mod == 'reply' && $pid) {
        if (!submitcheck('msgadminsubmit')) {
            include template('xiaoyu_liuyang:post');
        } else {
            if (empty($_GET['remsg'])) showmessage('xiaoyu_liuyang:xiaoyu_ckreply', '', '', array(
                'alert' => 'error'
            ));
            $data = array(
                'remsg' => dhtmlspecialchars($_GET['remsg']) ,
                'adminuid' => $_G['uid'],
                'adminname' => $_G['username'],
                'retime' => $_G['timestamp']
            );
            DB::update('xiaoyu_liuyang', $data, "pid='$pid'");
            showmessage(lang('plugin/xiaoyu_liuyang', 'xiaoyu_replyok') . $alertmsg, 'plugin.php?id=xiaoyu_liuyang', array() , array(
                'showdialog' => true,
                'locationtime' => true
            ));
        }
    } elseif ($mod == 'delete' && $pid) {
        if (!submitcheck('msgadminsubmit')) {
            include template('xiaoyu_liuyang:post');
        } else {
            DB::query("DELETE FROM " . DB::table('xiaoyu_liuyang') . " WHERE  pid = '$pid'");
            showmessage('xiaoyu_liuyang:xiaoyu_delok', 'plugin.php?id=xiaoyu_liuyang', array() , array(
                'showdialog' => true,
                'locationtime' => true
            ));
        }
    }
}
function ckfishname($username) {
    $strlen = strlen($username);
    if (!preg_match("/^[a-zA-Z\x7f-\xff][a-zA-Z\x7f-\xff]+$/", $username)) {
        return false;
    } elseif ($strlen < 4 || $strlen > 16) {
        return false;
    }
    return true;
}
function ckfishqq($qq) {
    $strlen = strlen($qq);
    if (!preg_match("/^[1-9]*[1-9][0-9]*$/", $qq)) {
        return false;
    } elseif ($strlen < 5 || $strlen > 14) {
        return false;
    }
    return true;
}
function ckfishtel($tel) {
    $isMob = "/^1[34578]{1}[0-9]{9}$/";
    $isTel = "/^(0[0-9]{2,3}-)[0-9]{7,8}$/";
    if (!preg_match($isMob, $tel) && !preg_match($isTel, $tel)) {
        return false;
    }
    return true;
}
function ckemail($str) {
    return (preg_match('/^[_.0-9a-z-a-z-]+@([0-9a-z][0-9a-z-]+.)+[a-z]{2,4}$/', $str)) ? true : false;
}
function ckfishtitle($cktitle) {
    $strlen = strlen($cktitle);
    if ($strlen < 4 || $strlen > 50) {
        return false;
    }
    return true;
}
function ckfishmsg($ckmsg) {
    $strlen = strlen($ckmsg);
    if ($strlen < 10 || $strlen > 500) {
        return false;
    }
    return true;
}
function fishfiltrate($msg) {
    $msg = str_replace("'", "��", $msg);
    $msg = str_replace(",", "��", $msg);
    $msg = str_replace("0x", "", $msg);
    return $msg;
}
function hidename($name) {
    $name = substr_replace($name, "**", 2);
    return $name;
}
function hideqq($q) {
    $q = substr($q, 0, 2) . "***" . substr($q, -2);
    return $q;
}
function hidemail($str) {
    if (strpos($str, '@')) {
        $email_array = explode("@", $str);
        $prevfix = (strlen($email_array[0]) < 4) ? "" : substr($str, 0, 2); 
        $count = 0;
        $str = preg_replace('/([\d\w+_-]{0,100})@/', '***@', $str, -1, $count);
        $rs = $prevfix . $str;
    }
    return $rs;
}
function hidtel($tel) {
    $IsWhat = preg_match('/(0[0-9]{2,3}[-]?[2-9][0-9]{6,7}[-]?[0-9]?)/i', $tel);
    if ($IsWhat == 1) {
        return preg_replace('/(0[0-9]{2,3}[-]?[2-9])[0-9]{3,4}([0-9]{3}[-]?[0-9]?)/i', '$1****$2', $tel);
    } else {
        return preg_replace('/(1[34578]{1}[0-9])[0-9]{4}([0-9]{4})/i', '$1****$2', $tel);
    }
}

