<?php

/*
 * Xiaoyu Install Process
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * From С������Ŷ�(www.minfish.com)
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');
require_once ('xiaoyu_core.php');
$request_url = str_replace('&step='.$_GET['step'],'',$_SERVER['QUERY_STRING']);
$form_url = str_replace('action=','',$request_url);
showsubmenusteps($installlang['title'], array(
    array($installlang['xiaoyu_check'], !$_GET['step']),
	array($installlang['xiaoyu_succeed'], $_GET['step']=='ok')
));
switch($_GET['step']){
		default:
	case 'check':
		$addonid = $pluginarray['plugin']['identifier'].'.plugin';
		$array = cloudaddons_getmd5($addonid);
		if(cloudaddons_open('&mod=app&ac=validator&addonid='.$addonid.($array !== false ? '&rid='.$array['RevisionID'].'&sn='.$array['SN'].'&rd='.$array['RevisionDateline'] : '')) === '0') {
		}
		cpmsg($installlang['xiaoyu_check_ok'], "{$request_url}&step=ok", 'loading', '');
		break;
	case 'ok':
$sql = <<<EOF

DROP TABLE IF EXISTS `pre_xiaoyu_liuyang`;
CREATE TABLE `pre_xiaoyu_liuyang` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `authoruid` int(8) unsigned NOT NULL,
  `author` varchar(15) NOT NULL,
  `dateline` int(10) unsigned NOT NULL,
  `ip` char(15) NOT NULL,
  `fishname` varchar(6) NOT NULL,
  `fishtel` varchar(255) NOT NULL,
  `fishemail` varchar(45) NOT NULL,
  `fishqq` varchar(255) NOT NULL,
  `fishtitle` text NOT NULL,
  `fishmsg` text NOT NULL,
  `adminuid` int(8) unsigned NOT NULL,
  `adminname` char(15) NOT NULL,
  `hidemsg` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remsg` text NOT NULL,
  `retime` varchar(45) NOT NULL,
  `as_show` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
@unlink(DISCUZ_ROOT . './source/plugin/xiaoyu_liuyang/discuz_plugin_xiaoyu_liuyang.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaoyu_liuyang/discuz_plugin_xiaoyu_liuyang_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaoyu_liuyang/discuz_plugin_xiaoyu_liuyang_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaoyu_liuyang/discuz_plugin_xiaoyu_liuyang_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaoyu_liuyang/discuz_plugin_xiaoyu_liuyang_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/xiaoyu_liuyang/install.php');
}
