<?php

/*
 * Xiaoyu Unstall Process
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * From С������Ŷ�(www.minfish.com)
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');

$sql = <<<EOF
DROP TABLE IF EXISTS  `pre_xiaoyu_liuyang`;
EOF;

runquery($sql);
$finish = TRUE;
@unlink(DISCUZ_ROOT . './source/plugin/xiaoyu_liuyang/discuz_plugin_xiaoyu_liuyang.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaoyu_liuyang/discuz_plugin_xiaoyu_liuyang_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaoyu_liuyang/discuz_plugin_xiaoyu_liuyang_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaoyu_liuyang/discuz_plugin_xiaoyu_liuyang_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaoyu_liuyang/discuz_plugin_xiaoyu_liuyang_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/xiaoyu_liuyang/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/xiaoyu_liuyang/uninstall.php');