<?php

/*
 * xiaoyu uninstall process
 * This is not a freeware, use is subject to license terms
 * From С������Ŷ�(www.minfish.com)
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$finish = TRUE;
@unlink(DISCUZ_ROOT . './source/plugin/kym_list/discuz_plugin_kym_list.xml');
@unlink(DISCUZ_ROOT . './source/plugin/kym_list/discuz_plugin_kym_list_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/kym_list/discuz_plugin_kym_list_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/kym_list/discuz_plugin_kym_list_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/kym_list/discuz_plugin_kym_list_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/kym_list/kym_list.class.php');
@unlink(DISCUZ_ROOT . 'source/plugin/kym_list/xiaoyu_core.php');
@unlink(DISCUZ_ROOT . 'source/plugin/kym_list/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/kym_list/uninstall.php');