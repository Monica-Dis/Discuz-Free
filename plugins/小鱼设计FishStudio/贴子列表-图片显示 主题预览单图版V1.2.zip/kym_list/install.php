<?php

/*
 * Xiaoyu Install Process
 * This is NOT a freeware, use is subject to license terms
 * From С������Ŷ�(www.minfish.com)
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');
require_once ('xiaoyu_core.php');
$request_url = str_replace('&step='.$_GET['step'],'',$_SERVER['QUERY_STRING']);
$form_url = str_replace('action=','',$request_url);
showsubmenusteps($installlang['title'], array(
    array($installlang['xiaoyu_check'], !$_GET['step']),
	array($installlang['xiaoyu_succeed'], $_GET['step']=='ok')
));
switch($_GET['step']){
		default:
	case 'check':
		$addonid = $pluginarray['plugin']['identifier'].'.plugin';
		$array = cloudaddons_getmd5($addonid);
		if(cloudaddons_open('&mod=app&ac=validator&addonid='.$addonid.($array !== false ? '&rid='.$array['RevisionID'].'&sn='.$array['SN'].'&rd='.$array['RevisionDateline'] : '')) === '0') {
			plugin_ins_error($pluginarray['plugin']['identifier']);
			cpmsg('cloudaddons_genuine_message', '', 'error', array('addonid' => $addonid));
		}
		cpmsg($installlang['xiaoyu_check_ok'], "{$request_url}&step=ok", 'loading', '');
		break;
	case 'ok':
		$finish = TRUE;
		@unlink(DISCUZ_ROOT . './source/plugin/kym_list/discuz_plugin_kym_list.xml');
		@unlink(DISCUZ_ROOT . './source/plugin/kym_list/discuz_plugin_kym_list_SC_GBK.xml');
		@unlink(DISCUZ_ROOT . './source/plugin/kym_list/discuz_plugin_kym_list_SC_UTF8.xml');
		@unlink(DISCUZ_ROOT . './source/plugin/kym_list/discuz_plugin_kym_list_TC_BIG5.xml');
		@unlink(DISCUZ_ROOT . './source/plugin/kym_list/discuz_plugin_kym_list_TC_UTF8.xml');
		@unlink(DISCUZ_ROOT . 'source/plugin/kym_list/install.php');
		break;
}