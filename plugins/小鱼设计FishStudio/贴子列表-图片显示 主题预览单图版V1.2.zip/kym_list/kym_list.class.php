<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_kym_list {
}

class plugin_kym_list_forum extends plugin_kym_list {
	
		private function xiaoyu_img_list($pid, $message, $kym_listset, $nocache = 0, $type = ''){
		$arr = array();
		$kym_listset['xiaoyu_imgnum'] = 1;
		if(count($arr) < $kym_listset['xiaoyu_imgnum']){
			$imgs  = array();
			foreach(C::t('forum_attachment_n')->fetch_all_by_id('pid:'.$pid, 'pid', $pid) as $attach) {
				if(count($arr) >= $kym_listset['xiaoyu_imgnum']){
					break;
				}
				if($attach['isimage']){
					$xiaoyu_height = $kym_listset['xiaoyu_height'];
					$xiaoyu_width = $kym_listset['xiaoyu_width'];
					$aid = $attach[aid];
					$key = dsign($aid.'|'.$xiaoyu_width.'|'.$xiaoyu_height);
					if($kym_listset[xiaoyu_bigimg]){
						if ($kym_listset[xiaoyu_onlineurl]) {
							$src  = $kym_listset[xiaoyu_onlineurl].'/forum/' . $attach['attachment'];
						} else {
							$src  = $kym_listset['attachurl'].'forum/' . $attach['attachment'];;
						}
					}else{
						$src  = 'forum.php?mod=image&aid='.$aid.'&size='.$xiaoyu_width.'x'.$xiaoyu_height.'&key='.rawurlencode($key).($nocache ? '&nocache=yes' : '').($type ? '&type='.$type : '');
					}
					$arr[] = array('src' => $src, 'type' => 'img');
				}
			}						
		}
		if(count($arr) < $kym_listset['xiaoyu_imgnum']){
			$matches = array();
			preg_match_all('/\[img[^\]]*\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/is', $message, $matches);					
			if(!empty($matches) && !empty($matches[1]) && is_array($matches[1])){
				foreach($matches[1] as $src){
					if(count($arr) >= $kym_listset['xiaoyu_imgnum']){
						break;
					}
					$arr[] = array('src' => $src, 'type' => 'img');
				}
			}
		}
		return $arr;
	}
	
	private function xiaoyu_li_html($pid, $type, $num, $src, $tid, $xiaoyu_width, $xiaoyu_height, $xiaoyu_thread){
		$html = '<li onclick="window.location.href=\'forum.php?mod=viewthread&tid='.$tid.'\'" ><img src="'.$src.'"  /></li>';
		return $html;
	}
	
	private function xiaoyu_getlilst_html($tid, $displayorder, $kym_listset){
		$html = '';
		
			$post = C::t('forum_post')->fetch_threadpost_by_tid_invisible($tid);
			$pid = $post['pid'];
			$message = $post['message'];
			$arr = $this->xiaoyu_img_list($pid, $message, $kym_listset);			
			$message = trim(messagecutstr($message, $kym_listset['xiaoyu_sumlen']));
			if(!empty($message) || count($arr) > 0){
				$html .= '<div class="kym_list cl">';
				$thread = C::t('forum_thread')->fetch($tid); 
				$subject = $post[subject];
				$author = $post[author];
				$xiaoyu_replies = $thread[replies];
				if(!$kym_listset['xiaoyu_top'] || !in_array($displayorder, array(1, 2, 3, 4))){
					if(count($arr) > 0){
						$html .= '<div class="kym_list_ul"><ul>';
						foreach($arr as $num => $item){
							$src = $item['src'];
							$type = $item['type'];
							if(in_array($displayorder, array(1, 2, 3, 4))){
								$xiaoyu_thread = 'stickthread';
							}else{
								$xiaoyu_thread = 'normalthread';
							}
							$html .= $this->xiaoyu_li_html($pid, $type, $num, $src, $tid, $xiaoyu_width, $xiaoyu_height, $xiaoyu_thread);
							
						}		
						$html .= '</ul></div>';							
					}else{
						$html .= '<div class="kym_list_ul"><ul><li onclick="window.location.href=\'forum.php?mod=viewthread&tid='.$tid.'\'"  style="width:'.$kym_listset[xiaoyu_width].'px;background-image:url(static/image/common/nophoto.gif); background-size: 100% 100%;background-repeat: no-repeat;"></li></ul></div>';
						}
					if(!empty($message)){
						$html .= '<div class="kym_list_sum" onclick="window.location.href=\'forum.php?mod=viewthread&tid='.$tid.'\'" >'.$message.'</div>';
					}
				}
				$html .= '</div>';
			}		
		return $html;
	}
	
	function forumdisplay_top_output() {
		global $_G;
		$kym_listset = $_G['cache']['plugin']['kym_list'];
		if (is_array($kym_listset)) {
			$xiaoyu_forums = (array)dunserialize($kym_listset['xiaoyu_forums']);
			if (is_array($xiaoyu_forums) && in_array($_G['fid'], $xiaoyu_forums)) {
			$listcss = '<style type="text/css">
						.kym_list{ padding:15px 0 15px '.$kym_listset[xiaoyu_width].'px;cursor:pointer}
						.kym_list .kym_list_ul{ margin-left:-'.$kym_listset[xiaoyu_width].'px;}
						.kym_list_sum{ margin-left:15px;line-height:20px;}
						.kym_list_ul li{float:left; line-height:0;max-width:'.$kym_listset[xiaoyu_width].'px;height:'.$kym_listset[xiaoyu_height].'px;overflow:hidden; border-radius:2px;}
						.kym_list_ul li img{ max-width:100%;}
						.kym_list_ul,.kym_list_sum{ float:left}
						</style>';
			$listcss .= $kym_listset['kym_listcss'];
			}
		}
		return $listcss;
	}
	function forumdisplay_thread_subject_output() {
		global $_G;
		$kym_listset = $_G['cache']['plugin']['kym_list'];
		$kym_listset['attachurl'] = $_G['setting']['attachurl'];
		if (is_array($kym_listset)) {
			$xiaoyu_forums = (array)dunserialize($kym_listset['xiaoyu_forums']);
			if (is_array($xiaoyu_forums) && in_array($_G['fid'], $xiaoyu_forums)) {
				require_once libfile('function/post');
				foreach ($_G['forum_threadlist'] as $key => $thread) {
					$html[$key] = '';
					$html[$key] .= $this->xiaoyu_getlilst_html($thread['tid'], $thread['displayorder'], $kym_listset, $xiaoyu_aid);
				}
			}
		}
		return $html;
	}
}