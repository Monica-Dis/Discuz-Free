<?php
/**
 * 
 * DisM!出品 必属精品
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * 我们致力于为站长提供正版Discuz!应用而努力
 * E-mail: dism.taobao@qq.com
 * 工作时间: 周一到周五早上09:00-12:00, 下午13:00-18:00, 晚上19:30-23:30(周六、日休息)
 * DisM!用户交流群: ①群778390776
 * 
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function change_code($matches) {
    global $_G;
    $url = $matches[2];
    $xiaoyu_bpset = $_G['cache']['plugin']['xiaoyu_bigpic'];
	$img_width = $xiaoyu_bpset['img_width'] ? $xiaoyu_bpset['img_width'] : '100%';
	$img_height = $xiaoyu_bpset['img_height'] ? $xiaoyu_bpset['img_height'] : '100%';
    if (strpos($_G['discuzcodemessage'], '[/img]') !== FALSE) {
        return '<img width="' . $img_width . '" height="' . $img_height . '" style="max-width:100%; max-height:100%" src="' . $url . '">';
    }
}

