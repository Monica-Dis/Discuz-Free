<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class mobileplugin_fw_avatarupload
{
    
    public function global_footer_mobile()
    {
        global $_G;
        if ($_G['basescript'] == 'home' && CURMODULE == 'space' && $_GET['do'] == 'profile' & $_GET['mycenter'] == '1') {
            
            loadcache('plugin');
            $fwavatarconfig = $_G['cache']['plugin']['fw_avatarupload'];
            // �ϴ���ť����
            $fwavatar_upbtntxt = $fwavatarconfig['fwavatar_upbtntxt'] == '' ? lang('plugin/fw_avatarupload', 'sys003') : $fwavatarconfig['fwavatar_upbtntxt'];
            // ���水ť����
            $fwavatar_savebtntxt = $fwavatarconfig['fwavatar_savebtntxt'] == '' ? lang('plugin/fw_avatarupload', 'sys001') : $fwavatarconfig['fwavatar_savebtntxt'];
            // ȡ����ť����
            $fwavatar_cancelbtntxt = $fwavatarconfig['fwavatar_cancelbtntxt'] == '' ? lang('plugin/fw_avatarupload', 'sys002') : $fwavatarconfig['fwavatar_cancelbtntxt'];
            // ���水ť������ɫ
            $fwavatar_savebtncolor = $fwavatarconfig['fwavatar_savebtncolor'] == '' ? '#4cd964' : $fwavatarconfig['fwavatar_savebtncolor'];
            // ȡ����ť������ɫ
            $fwavatar_cancelbtncolor = $fwavatarconfig['fwavatar_cancelbtncolor'] == '' ? '#f6383a' : $fwavatarconfig['fwavatar_cancelbtncolor'];
            // �������޸Ĳ˵�������class
            $fwavatar_containerclass = $fwavatarconfig['fwavatar_containerclass'] == '' ? 'ul' : $fwavatarconfig['fwavatar_containerclass'];

            $formhash = FORMHASH;
            if (empty($_G['cache']['plugin'])) {
                loadcache('plugin');
            }
            $fw_config = $_G['cache']['plugin']['fw_avatarupload'];
            //Class
            $recipe_config['class'] = DISCUZ_ROOT . 'source/plugin/fw_avatarupload/class/';
            //Function
            $recipe_config['function'] = DISCUZ_ROOT . 'source/plugin/fw_avatarupload/function/';
            //Module
            $recipe_config['module'] = DISCUZ_ROOT . 'source/plugin/fw_avatarupload/module/';
            //Base
            $fw_config["base"] = array();
            $fw_config["base"]["image"] = "./source/plugin/fw_avatarupload/template/resource/images/";
            $fw_config["base"]["css"] = "./source/plugin/fw_avatarupload/template/resource/css/";
            $fw_config["base"]["js"] = "./source/plugin/fw_avatarupload/template/resource/js/";

            $pluginConfig = $_G['cache']['plugin']['fw_avatarupload'];

            // $appid = $pluginConfig['wxappid'];
            // $appsecret = $pluginConfig['wxappsecret'];
            // $uploadformdata_hash = md5(substr(md5($_G['config']['security']['authkey']), 8) . $_G['uid']);
            $ret = "";

            $signPackage = null;
            // check is running in wechat explore
            // if (strpos($_SERVER["HTTP_USER_AGENT"], 'MicroMessenger') !== false) {
            //     include_once DISCUZ_ROOT . 'source/plugin/fw_avatarupload/class/jssdk.php';
            //     $jssdk = new JSSDK($appid, $appsecret);
            //     $signPackage = $jssdk->GetSignPackage();
            //     $wechatConfigJson = json_encode($signPackage);
            // }
            include template('fw_avatarupload:upload');
            $ret = $html;
            $retli = '<script>jQuery(".myinfo_list ul").append(\'<li><a href="plugin.php?id=fw_weixin:fwwxbind&mobile=2">'.lang('plugin/fw_weixin','l34').'</a></li>\');</script>';
            return $ret . $retli;

        }
    }
}
//From: Dism��taobao��com
?>
