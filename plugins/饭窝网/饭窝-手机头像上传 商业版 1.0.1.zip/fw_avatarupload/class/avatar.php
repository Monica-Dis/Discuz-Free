<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once 'ucavatar_class.php';

if ($_G['uid']) {
    $file = null;
    $file = $_FILES['img'];
    $file["name"]= $file["name"].".jpg";
    $avatarfile = uploadavatar($file);
    if ($avatarfile == '-1') {
        echo (-1);
    } elseif ($avatarfile == '-2') {
        echo (-2);
    } elseif ($avatarfile == '-3') {
        echo (-3);
    } elseif ($avatarfile == '-99') {
        echo (-99);
    } else {
        $avatar = DISCUZ_ROOT . './data/attachment/common/' . $avatarfile;
        fw_syncavatar($_G['uid'], $avatar);
        echo (1);
    }
}


function uploadavatar($file, $type = 'avatar')
{
    global $_G;
    if($_G['uid']) {
        $data['extid'] = $_G['uid'];
        $uploadtype = 'common';

        $upload = new discuz_upload();

        $file['name'] = trim($file['name']);
        $file['ext'] = $upload->fileext($file['name']);
        $file['isimage'] = $upload->is_image_ext($file['ext']);
        if ($file['isimage']) {
            if (!$upload->init($file, $uploadtype, $data['extid'], $type)) {
                return -1;
            }
            if (!$upload->save()) {
                return -2;
            }

            require_once libfile('class/image');
            $img = new image;
            $img->Thumb($upload->attach['target'], './' . $uploadtype . '/' . $upload->attach['attachment'], 300, 300, 'fixwr');
            return $upload->attach['attachment'];
        } else {
            return -3;
        }
    }
    else {
        return -99;
    }
}

function fw_syncavatar($uid, $avatar)
{

    if (!$uid || !$avatar) {
        return false;
    }
    $result = fwupload_ucavatar::fwupload($uid, $avatar);
    C::t('common_member')->update($uid, array('avatarstatus' => '1'));
    return $result;
}


?>