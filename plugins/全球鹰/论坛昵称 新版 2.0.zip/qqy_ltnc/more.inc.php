<?php
/**

  * [DisM!] (C)2019-2020 DISM.Taobao.COM.
  
  * 官方淘宝店铺：DisM.Taobao.Com
  
  * Website:     dism.taobao.com
  
  * Email:       DISM.TAOBAO.COM
    
*/
echo '<script>
 location.href="https://dism.taobao.com/?@qqy_ltnc.plugin";
</script>';

?>

