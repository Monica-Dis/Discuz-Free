<?php
/**
 * Plugin For Discuz! X2.5-X3.1
 
 * Copyright (c) 2008 - 2016 Zhanzhangzu.com.

 * 最新插件：http://t.cn/Aiux1Jx1
 
 * 邮箱:      DISM.TAOBAO.COM
 
 * 网站:      dism.taobao.com
  
 */


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$dbcharset 		= $_G['config']['db'][1]['dbcharset'];
$charset 		= $_G['config']['output']['charset'];
$pdbcharset		= $dbcharset?$dbcharset:str_replace('-', '', $charset);

DB::query("ALTER TABLE ".DB::table('common_member')." ADD `addname` smallint(4) NOT NULL DEFAULT 0");

DB::query("CREATE TABLE IF NOT EXISTS ".DB::table('qqy_ltnclog')." (
`id` int(9) unsigned NOT NULL AUTO_INCREMENT,
`uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
`name` char(30) NOT NULL DEFAULT '',
`logtime` int(10) NOT NULL DEFAULT '0',
`status` tinyint(1) NOT NULL DEFAULT '1',
PRIMARY KEY (`id`),
KEY `uid` (`uid`),
KEY `logtime` (`logtime`)
) ENGINE=MyISAM DEFAULT CHARSET=$pdbcharset");

$finish = true;

?>