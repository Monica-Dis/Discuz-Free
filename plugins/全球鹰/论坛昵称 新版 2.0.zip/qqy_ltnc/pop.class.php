<?php
/**
 * Plugin For Discuz! X2.5-X3.0
 
 * Copyright 2001-2099 DisM!应用中心.

 * 最新插件：http://t.cn/Aiux1Jx1
 
 * 邮箱:      DISM.TAOBAO.COM
 
 * 网站:      dism.taobao.com
  
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_qqy_ltnc {

	function global_footer() {
		global $_G;
		$result = '';
		$uid = (int)$_G['uid'];
		if(!empty($uid) && (CURSCRIPT!='home' && $_GET['mod']!='spacecp' ) ){
			//$showpop = 1;
			$showpop = getcookie('ltncpop');
			if(empty($showpop)){
				$ifset = DB::result_first("SELECT addname FROM ".DB::table('common_member')." WHERE uid=$uid");
				if(empty($ifset)){
					$result = "<script>setTimeout(\"showWindow('pop', 'plugin.php?id=qqy_ltnc:pop')\",1200);</script>";
				}
			}
		}	
		return $result;
		}
}	