<?php exit('全球鹰QQ:641500953 商业保护！请到官网上购买正版 <a href="http://addon.discuz.com/?@qqy_designers.plugin" >http://addon.discuz.com/?@qqy_designers.plugin</a>');?>
<div class="wp mtw mbw">

	<div class="qqy_about cl">
	
	
	<div class="about_right">
		
		{if $profiles}
		<!--{loop $profiles $value}-->
			<div class="about_item cl">
				<div class="qqy_home_left">$value[title]</div>
				<div class="qqy_home_right">$value[value]</div>
			</div>
		<!--{/loop}-->
		
		{else}

		<p class="qqy_no_content">他还未设置个人资料</p>

		{/if}
	
	</div>
	
	
	<div class="about_left">
		
		<div class="blank_30">
		
		</div>
		
		<div class="avatar mbm">
			<!--{avatar($uid,middle)}-->
		</div>	
		{eval $baseinfo = array(
					'用户名'=>$username,
					'性别'=>$gender,
					'用户组'=>$userinfo['groupname'],
					'注册时间'=>date("Y-m-d",$user_member['regdate']),
				);
		}
		{if $baseinfo}
		<!--{loop $baseinfo $k=>$value}-->
			<p><em>$k</em><span>$value</span></p>
		<!--{/loop}-->
		{/if}
		
		
	
	
	</div>
	
	
	
	
	
	
	
	
	
	</div>
</div>