<?php exit('全球鹰QQ:641500953 商业保护！请到官网上购买正版 <a href="http://addon.discuz.com/?@qqy_designers.plugin" >http://addon.discuz.com/?@qqy_designers.plugin</a>');?>
<script type="text/javascript" src="{$static_dir}/j.min.js?{VERHASH}"></script>
<style>
.qqy_home_threadlist li.list0{ margin-right:{$list_space}px;}
</style>

<div class="wp mtw mbw cl">
	<div class="thread_list">
	<!--{if $threads}-->
			
	<ul class="qqy_home_threadlist cl">
	
	<!--{eval $listnum=1;}-->	
	<!--{loop $threads $key $thread}-->
		
								<!--{if $_G['hiddenexists'] && $thread['hidden']}-->
									<!--{eval continue;}-->
								<!--{/if}-->
								<!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
									<!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
										<!--{eval $thread[tid]=$thread[closed];}-->
									<!--{/if}-->
								<!--{/if}-->
								<!--{eval $waterfallwidth = $thumbwidth; }-->
								<li {if $listnum%{$mb_cols}==0}class="list3"{else}class="list0"{/if} style="width:{$waterfallwidth}px">
									
									<div class="c cl">
									
											<!--{if $thread['cover']}-->
											<div class="show_img" style="display:block;width:{$thumbwidth}px; height:{$thumbheight}px; overflow:hidden;">
												<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" {if $thread['isgroup'] == 1 || $thread['forumstick'] || CURMODULE == 'guide'} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]" hidefocus="true">
												<img src="$thread[coverpath]" alt="$thread[subject]" width="{$thumbwidth}" />
												</a>
											</div>
											
											<!--{else}-->
											
											<div class="show_text" style="display:block;width:{$thumbwidth}px; height:{$thumbheight}px;">
												
												<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" {if $thread['isgroup'] == 1 || $thread['forumstick'] || CURMODULE == 'guide'} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]" hidefocus="true">
												<div class="img_text">
													$thread['message']
												</div>
												</a>
												
											</div>
											<!--{/if}-->
										</a>
										
									</div>
									
									
									
									
									
										<div class="home_thread_title">
										
										<a href="forum.php?mod=forumdisplay&fid={$thread[fid]}" class="home_bk" hidefocus="true"><!--{eval $forumname = DB::result_first("SELECT name FROM ".DB::table('forum_forum')." WHERE fid=".$thread[fid]);echo mb_substr($forumname,0,4,'utf-8');}--></a>
										
										<!--{hook/forumdisplay_thread $key}-->
										<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick']} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]">{echo mb_substr($thread[subject],0,13,'utf-8');}</a>
										</div>
									
									
									
									
									<div class="home_thread_info cl">
										
										<div class="qqy_fd_pj cl">	
											<div class="right">
											
												<em class="fd_see">$thread[views]</em>
												<em class="fd_reply">$thread[replies]</em>	
												<em class="fd_like"><!--{if $thread[recommends]}-->$thread[recommends]<!--{else}-->0<!--{/if}--></em>																
											</div>	
											
											<span class="fd_time">{echo date("Y-m-d",$thread[dateline]);}</span>			
										</div>
										
									</div>
									
								</li>
								<!--{eval $listnum+=1;}-->
								<!--{/loop}-->
	</ul>	
	
	
	<!--{else}-->
		<div class="qqy_no_content">{$ta}还没有发布任何作品</div>
	<!--{/if}-->	
	</div>
</div>

<div class="cl">
	<span class="qqy_des_page" >$multipage</span>
</div>


<script>
/*	var mb_cols = {$mb_cols};
	var mb_width = {$mb_width};
	var thumbwidth = {$thumbwidth};
	var list_space = Math.floor( (mb_width-(mb_cols)*thumbwidth)/(mb_cols-1) );
	jQuery(".qqy_home_threadlist li.list0").css("margin-right",list_space);
*/	
</script>
