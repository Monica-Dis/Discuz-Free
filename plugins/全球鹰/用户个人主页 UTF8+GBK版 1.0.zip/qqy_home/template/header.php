<?php exit('全球鹰QQ:641500953 商业保护！请到官网上购买正版 <a href="http://addon.discuz.com/?@qqy_designers.plugin" >http://addon.discuz.com/?@qqy_designers.plugin</a>');?>
<!--{template common/header}-->
</div>
<link rel="stylesheet" type="text/css"  href="{$static_dir}/qqy_home_v1.css?{VERHASH}" />
<style>
.wp{ width:{$mb_width}px;}
{if $bbs_type=='default'}
.home_top_bg{ border-bottom:0px;}
.home_nav { border-bottom:1px solid #6bc30d;}
{/if}
</style>
<div class="home_bg">

	<div class="home_top_bg">
	
		<div class="home_top wp cl">
			<div class="top_left">
				<div class="left">
					<!--{avatar($uid,middle)}-->
				</div>
				<div class="right">
					<h2>$username</h2>
					<p class="location">{if $profile['resideprovince']}$profile['resideprovince']{else}中国{/if}</p>
					<p class="action">
						<!--{if $uid!=$_G[uid]}-->
							<a href="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$uid&touid=$uid&pmid=0&daterange=2" onclick="showWindow('sendpm', this.href);" title="发私信" class="home_sendpm" hideFocus="true">发私信</a>	
							<a href="home.php?mod=spacecp&ac=friend&op=add&uid=$uid&handlekey=addfriendhk_{$uid}" id="a_friend_li_{$uid}" onclick="showWindow(this.id, this.href, 'get', 0);" class="home_addfriend" hideFocus="true">加好友</a>
							<!--{if helper_access::check_module('follow')}-->
							<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$uid" id="followmod_$uid" title="加关注" class="home_follow" onclick="showWindow('followmod', this.href, 'get', 0);" hideFocus="true">加关注</a>
							<!--{/if}-->
						<!--{else}-->
						<a href="home.php?mod=spacecp" hidefocus="true">个人设置</a>
						<a href="forum.php?mod=guide&view=my" hidefocus="true">我的帖子</a>
						<a href="home.php?mod=space&do=favorite&view=me" hidefocus="true">我的收藏</a>			
						<!--{/if}-->
					</p>
				</div>
			</div>
			
			<div class="top_right cl">
				
				<p><em>主题</em><span>{$count['threads']}</span></p>
				<p><em>发帖</em><span>{$count['posts']}</span></p>
				<p class="nomargin"><em>积分</em><span title="{$credits}">{$credits}</span></p>
			</div>
		</div>
		
		
		<div class="home_nav wp cl">
		
			<a href="plugin.php?id=qqy_home&uid={$uid}&ac=index" class="nav_a{if $ac=='index'} on{/if}" hideFocus="true">{$ta}的作品</a>
			<a href="plugin.php?id=qqy_home&uid={$uid}&ac=about" class="nav_a {if $ac=='about'}on{/if}" hideFocus="true">{$ta}的资料</a>
		</div>
		
	</div>
	
	
	
	

