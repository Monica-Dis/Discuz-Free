<?php exit();?>
<div class="wp cl">

	<!--{if $threads}-->
		
	<ul class="qqy_threadlist cl">
	<!--{eval $listnum=1;}-->	
	<!--{loop $threads $key $thread}-->
		
								<!--{if $_G['hiddenexists'] && $thread['hidden']}-->
									<!--{eval continue;}-->
								<!--{/if}-->
								<!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
									<!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
										<!--{eval $thread[tid]=$thread[closed];}-->
									<!--{/if}-->
								<!--{/if}-->
								<!--{eval $waterfallwidth = $thumbwidth+18; }-->
								<li {if $listnum%3==0}class="list3"{/if} style="width:{$waterfallwidth}px">
									
									<div class="c cl">
											<!--{if $thread['cover']}-->
											<div class="show_img" style="display:block;width:{$thumbwidth}px; height:{$thumbheight}px; overflow:hidden;">
												<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" {if $thread['isgroup'] == 1 || $thread['forumstick'] || CURMODULE == 'guide'} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]" hidefocus="true">
												<img src="$thread[coverpath]" alt="$thread[subject]" width="{$thumbwidth}" />
												</a>
											</div>
											<div class="show_text" style="display:none;width:{$thumbwidth}px; height:{$thumbheight}px;">
												
												<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" {if $thread['isgroup'] == 1 || $thread['forumstick'] || CURMODULE == 'guide'} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]" hidefocus="true">
												<div class="img_text">
												$thread['message']
												</div>
												</a>
												
											</div>
											<!--{else}-->
											<div class="show_img" style="display:none;width:{$thumbwidth}px; height:{$thumbheight}px;">
												
												<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" {if $thread['isgroup'] == 1 || $thread['forumstick'] || CURMODULE == 'guide'} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]" hidefocus="true">
												<div class="img_text">
													$thread['message']
												</div>
												</a>
												
											</div>
											<div class="show_text" style="display:block;width:{$thumbwidth}px; height:{$thumbheight}px;">
												
												<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" {if $thread['isgroup'] == 1 || $thread['forumstick'] || CURMODULE == 'guide'} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]" hidefocus="true">
												<div class="img_text">
													$thread['message']
												</div>
												</a>
												
											</div>
											<!--{/if}-->
										</a>
										
									</div>
									
									<h3 class="xw0">
										<!--{hook/forumdisplay_thread $key}-->
										<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick']} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]">$thread[subject]</a>
									</h3>
									
									<div class="fd_thread_info cl">
									
										<div class="qqy_fd_pj cl">	
											<div class="right">
											
												<em class="fd_see">$thread[views]</em>
												<em class="fd_reply">$thread[replies]</em>	
												<em class="fd_like"><!--{if $thread[recommends]}-->$thread[recommends]<!--{else}-->0<!--{/if}--></em>																
											</div>	
											
											<span class="fd_time">$thread[dateline]</span>			
										</div>
										
										<div class="qqy_fd_author">
										
											<!--{hook/forumdisplay_author $key}-->
										<!--{if $thread['authorid'] && $thread['author']}-->
											<a href="home.php?mod=space&uid=$thread[authorid]" class="list_avatar">
												<!--{avatar($thread[authorid],small)}-->
											</a>
											
											<a href="home.php?mod=space&uid=$thread[authorid]" class="list_author">$thread[author]</a><!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}-->
										<!--{else}-->
											<span class="list_author">$_G[setting][anonymoustext]</span>
										<!--{/if}-->
										
											<span class="fd_type">
											<a href="forum.php?mod=forumdisplay&fid={$thread[fid]}" hidefocus="true"><!--{echo $forumname = DB::result_first("SELECT name FROM ".DB::table('forum_forum')." WHERE fid=".$thread[fid]);}--></a>
											
											</span>
										
										</div>
										
									</div>
								</li>
								<!--{eval $listnum+=1;}-->
								<!--{/loop}-->
	</ul>	
		
	<!--{/if}-->	
</div>

<div class="cl">
	<span id="fd_page_bottom">$multipage</span>
</div>