<?php 
/*
 * @author	quanqiuying
 * @time	2014-10-29
 * @contact	641500953@qq.com
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo '<p>待更新，有好建议，请联系作者</p><p>QQ:641500953</p>';
?>
