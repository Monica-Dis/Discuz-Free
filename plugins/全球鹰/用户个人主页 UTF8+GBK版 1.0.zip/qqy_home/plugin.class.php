<?php 
/*
 * @author	quanqiuying
 * @time	2014-10-29
 * @contact	641500953@qq.com
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_qqy_home {

	function global_footer() {
		global $_G;
		$result = '';
		$uid = (int)$_GET['uid'];
		if( !empty($uid) && CURSCRIPT=='home' && $_GET['mod']=='space' && !$_GET['ajaxmenu']  && !$_GET['inajax'] ){
			header("location:plugin.php?id=qqy_home&uid=$uid");
		}
		return;
	}

}

?>