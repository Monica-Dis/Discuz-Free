<?php 
/*
 * @author	quanqiuying
 * @time	2014-10-29
 * @contact	641500953@qq.com
 */

!defined('IN_DISCUZ') && exit('Access Denied');

$static_dir = 'source/plugin/qqy_home/static';
$uid = (int)$_GET['uid'];
if($uid<1){
	showmessage('你访问的页面不存在了','index.php');
}

$bbs_type = trim($_G['style']['directory']);
if( substr($bbs_type,-7,7)==='default'){
	$bbs_type='default';
}
$user_member = DB::fetch_first("SELECT username,credits,regdate FROM ".DB::table('common_member')." WHERE uid=".$uid);
$username = $user_member['username'];
$credits = $user_member['credits'];
$profile = DB::fetch_first("SELECT gender,resideprovince,residecity,bio FROM ".DB::table('common_member_profile')." WHERE uid=".$uid);
$count = DB::fetch_first("SELECT posts,threads FROM ".DB::table('common_member_count')." WHERE uid=".$uid);
$gender = $profile['gender']==2?'女':'男';
$ta = ($_G['uid']==$uid)?'我':($profile['gender']==2?'她':'他');

$member_field_forum = DB::fetch_first("SELECT sightml,medals FROM ".DB::table('common_member_field_forum')." WHERE uid=".$uid);
$sightml = $member_field_forum['sightml'];
$medals = $member_field_forum['medals'];



$ac = $_GET['ac']?$_GET['ac']:'';
if( !in_array($ac, array('index','about')) ){
	$ac = 'index';
}

$mb_width = 1240;//(int)$_G['cache']['plugin']['qqy_home']['mb_width'];
$mb_width = ($mb_width>=960 && $mb_width<=1600 )? $mb_width:'980';



$moduleName = $ac=='index'?'作品':'个人资料';
$navtitle  = $username.'的'.$moduleName;
$metakeywords = $navtitle;
$metadescription = $metakeywords;
include template('qqy_home:header');
if($ac=='index'){
	
	$thumbinfo = unserialize($_G[setting][forumpicstyle]);
	$thumbwidth = $thumbinfo['thumbwidth'];
	$thumbheight = $thumbinfo['thumbheight'];

	$mb_cols = 4;//(int)$_G['cache']['plugin']['qqy_home']['mb_cols'];
	$mb_cols = ($mb_cols>0 && $mb_cols<6)?$mb_cols:3;
	if( $mb_cols*($thumbwidth+2)> $mb_width){
		$mb_cols=$mb_cols-1;
	}
	$list_space =  floor(  ($mb_width-($mb_cols)*$thumbwidth)/($mb_cols-1) );

	$perpage = (int)$_G['setting']['topicperpage'];
	$perpage<1 && $perpage=12;
	$page = $_GET['page']>1?(int)$_GET['page']:1;
	$start = ($page-1)*$perpage;
	$orderby = 'dateline';//默认排序
	$threads = DB::fetch_all('SELECT * FROM '.DB::table('forum_thread').' WHERE authorid='.$uid.' AND `displayorder`>=0 ORDER BY '.$orderby.' DESC LIMIT '.$start.','.$perpage);
	if(!empty($threads)){
		require_once(DISCUZ_ROOT."./source/function/function_forum.php");
		require_once(DISCUZ_ROOT."./source/function/function_post.php");
		foreach ($threads as $key=>$val){
			$message= DB::result_first("SELECT message FROM ".DB::table('forum_post')." WHERE tid=".$val[tid]);
			$message && $message = messagecutstr($message,100);
			$threads[$key]['message'] = $message;
			$threads[$key]['coverpath'] = getthreadcover($val['tid'], $val['cover']);	
		}	
		
	}
	$count = DB::result_first('SELECT count(*) FROM '.DB::table('forum_thread').' WHERE authorid='.$uid.' AND `displayorder`>=0 ');
	$multipage = multi($count,$perpage, $page,'plugin.php?id=qqy_home&uid='.$uid,$_G['setting']['threadmaxpages']);
	include template('qqy_home:works');
	
	
}elseif($ac == 'about'){

	//个人栏目设置
	//0公开 1好友 3保密
	loadcache('profilesetting');
	include_once libfile('function/profile');
	$profiles = array();
	$space = DB::fetch_first("SELECT * FROM ".DB::table('common_member_profile')." WHERE uid=$uid");
	$privacy = DB::result_first("SELECT privacy FROM ".DB::table('common_member_field_home')." WHERE uid=$uid");
	$space['privacy'] = unserialize($privacy);
	$privacy = $privacy ? $space['privacy']['profile'] : array();
	
	foreach($_G['cache']['profilesetting'] as $fieldid => $field) {
		if( $field['available'] &&  !$field['invisible'] && $privacy[$fieldid]!=3 && $space[$fieldid] ) {
			$val = profile_show($fieldid, $space);
			if($val !== false) {
				if($val == '')  $val = '-';
				$profiles[$fieldid] = array('title'=>$field['title'], 'value'=>$val);
			}
		}
	}
	
	$user_status =DB::fetch_first("SELECT email,emailstatus,groupid,regdate FROM ".DB::table('common_member')." WHERE uid=".$uid);
	$user_profile =DB::fetch_first("SELECT qq,resideprovince,bio,site FROM ".DB::table('common_member_profile')." WHERE uid=".$uid);
	$userinfo = array_merge($user_status,$user_profile);
	if($userinfo['groupid']){
		$userinfo['groupname'] =DB::result_first("SELECT grouptitle FROM ".DB::table('common_usergroup')." WHERE groupid=".(int)$userinfo['groupid']);
	}
	include template('qqy_home:about');
}


include template('qqy_home:footer');
?>