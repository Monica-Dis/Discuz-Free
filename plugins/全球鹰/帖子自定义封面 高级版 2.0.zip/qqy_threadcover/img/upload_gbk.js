var state='pending';
var Upload = {	
	img:function(curClass,maxSize,callback){
		curThis = jQuery("."+curClass);
		var	uploader,imglist,imgbtn,curThis;		
		imgbtn = curThis.find(".uploadBtn");
		imglist = curThis.find(".uploadList");
		var uploader = WebUploader.create({
		    // ѡ���ļ����Ƿ��Զ��ϴ���
			fileNumLimit:1,
		    auto: false,
		    // swf�ļ�·��
		    swf:SITEURL+'/source/plugin/qqy_threadcover/img/Uploader.swf',
		    // �ļ����շ���ˡ�
		    server: 'plugin.php?id=qqy_threadcover:cover&formhash='+formhash,
		    // ѡ���ļ��İ�ť����ѡ��
		    // �ڲ����ݵ�ǰ�����Ǵ�����������inputԪ�أ�Ҳ������flash.
		    pick: {
		    	id:curThis.find(".picker"),
		    	multiple:false		    	
		    },
			fileVal:'threadcover',
			compress:{
				width:600,
				height:600,
				quality:100,
				crop:false,
				noCompressIfLarger:true
			},
		    // ֻ����ѡ��ͼƬ�ļ���		    
		    accept: {
		    	title: 'Images',
		        extensions: 'gif,jpg,jpeg,bmp,png',
		        mimeTypes: 'image/*'
		    }
		    		    
		});		
		imgbtn.on( 'click', function() {
		    if ( state === 'uploading' ) {
		        uploader.stop();
		    } else {
		        uploader.upload();
		    }
		});		
		imglist.on('click','.uploadDel',function() {
		    var curFileId=jQuery(this).data("fileid");
		    if(curFileId){		    	
		    	uploader.removeFile( curFileId );
			    imglist.html('');			    
			    curThis.find(".picker div").removeClass('webuploader-element-invisible').addClass("webuploader-container");
			    curThis.find(".preview").hide();
			    curThis.find(".imgVal").val('');
		    }  
		});		
		uploader.on( 'fileQueued', function( file ) {
			maxSize = maxSize?maxSize:2097152;
			if(file){
				if(file.size>maxSize){
					var humanMaxSize = humanSize(maxSize);
					showError('�ϴ��ļ���С���ܳ��� '+humanMaxSize,null);
					uploader.removeFile( file );
					return false;
				}
				curThis.find(".picker div").addClass('webuploader-element-invisible');
			}
			imglist.html('');
		    imglist.append( '<div id="' + file.id + '" class="item">' +
		        '<span class="info">' + shortStr(file.name) + '</span><span class="state">�ȴ��ϴ�</span><a href="javascript:;" data-fileid="'+file.id+'" class="uploadDel" >ɾ��</a>'+'</div>' );	    	
		    uploader.upload();		    
		});
			
		uploader.on( 'uploadProgress', function( file, percentage ) {
		    var fileli = jQuery( '#'+file.id ),
		        percent = fileli.find('.progress .progress-bar');
		    // �����ظ�����
		    if ( !percent.length ) {
		        percent = jQuery('<div class="progress progress-striped active">' +
		          '<div class="progress-bar" role="progressbar" style="width: 0%">' +
		          '</div>' +
		        '</div>').appendTo( fileli ).find('.progress-bar');
		    }
		    fileli.find('.state').text('�ϴ���...');
		    percent.css( 'width', percentage * 100 + '%' );
		});
		uploader.on( 'uploadSuccess', function( file ) {
		    jQuery( '#'+file.id ).find('.state').text('�ϴ��ɹ�');		    
		});

		uploader.on( 'uploadError', function( file ) {
		    jQuery( '#'+file.id ).find('.state').text('�ϴ�����!');
		    jQuery( '#'+file.id ).find('.state').addClass('error');
		    uploader.removeFile( file );
		});

		uploader.on( 'uploadComplete', function( file ) {
		    jQuery( '#'+file.id ).find('.progress').fadeOut();
		});
		uploader.on( 'uploadAccept', function( file, response ) {
			if(callback){
				callback(response,curThis);
				return response.errno?false:true;
			}
		    if ( response.errno ) {		   
		    	showError(response.error);
		        return false;
		    } 	    
		});
	}
}

function humanSize(size){
	var humanImgSize;
	if(size>1048576){
        humanImgSize = Math.floor(size/1048576)+' M';
	}else if(size>1024){
        humanImgSize = Math.floor(size/1024)+' KB';
	}else{
        humanImgSize = size+' B';
	}
	return humanImgSize;
}

function shortStr(str,startLen,endLen){
	var newStr = '';
	startLen = startLen?parseInt(startLen):3;
	endLen = endLen?parseInt(endLen):6;
	if( str.length>(startLen+endLen+5) ){
		newStr+=str.substr(0,3);
		newStr+='***';		    
		newStr+=str.substr(str.length-5,5);	
	}else{
		newStr = str;				
	}				    
	return newStr;
}
