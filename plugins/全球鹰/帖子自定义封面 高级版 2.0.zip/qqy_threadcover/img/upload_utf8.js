var state='pending';
var Upload = {	
	img:function(curClass,maxSize,callback){
		curThis = jQuery("."+curClass);
		var	uploader,imglist,imgbtn,curThis;		
		imgbtn = curThis.find(".uploadBtn");
		imglist = curThis.find(".uploadList");
		var uploader = WebUploader.create({
		    // 选完文件后，是否自动上传。
			fileNumLimit:1,
		    auto: false,
		    // swf文件路径
		    swf:SITEURL+'/source/plugin/qqy_threadcover/img/Uploader.swf',
		    // 文件接收服务端。
		    server: 'plugin.php?id=qqy_threadcover:cover&formhash='+formhash,
		    // 选择文件的按钮。可选。
		    // 内部根据当前运行是创建，可能是input元素，也可能是flash.
		    pick: {
		    	id:curThis.find(".picker"),
		    	multiple:false		    	
		    },
			fileVal:'threadcover',
			compress:{
				width:600,
				height:600,
				quality:100,
				crop:false,
				noCompressIfLarger:true
			},
		    // 只允许选择图片文件。		    
		    accept: {
		    	title: 'Images',
		        extensions: 'gif,jpg,jpeg,bmp,png',
		        mimeTypes: 'image/*'
		    }
		    		    
		});		
		imgbtn.on( 'click', function() {
		    if ( state === 'uploading' ) {
		        uploader.stop();
		    } else {
		        uploader.upload();
		    }
		});		
		imglist.on('click','.uploadDel',function() {
		    var curFileId=jQuery(this).data("fileid");
		    if(curFileId){		    	
		    	uploader.removeFile( curFileId );
			    imglist.html('');			    
			    curThis.find(".picker div").removeClass('webuploader-element-invisible').addClass("webuploader-container");
			    curThis.find(".preview").hide();
			    curThis.find(".imgVal").val('');
		    }  
		});		
		uploader.on( 'fileQueued', function( file ) {
			maxSize = maxSize?maxSize:2097152;
			if(file){
				if(file.size>maxSize){
					var humanMaxSize = humanSize(maxSize);
					showError('上传文件大小不能超过 '+humanMaxSize,null);
					uploader.removeFile( file );
					return false;
				}
				curThis.find(".picker div").addClass('webuploader-element-invisible');
			}
			imglist.html('');
		    imglist.append( '<div id="' + file.id + '" class="item">' +
		        '<span class="info">' + shortStr(file.name) + '</span><span class="state">等待上传</span><a href="javascript:;" data-fileid="'+file.id+'" class="uploadDel" >删除</a>'+'</div>' );	    	
		    uploader.upload();		    
		});
			
		uploader.on( 'uploadProgress', function( file, percentage ) {
		    var fileli = jQuery( '#'+file.id ),
		        percent = fileli.find('.progress .progress-bar');
		    // 避免重复创建
		    if ( !percent.length ) {
		        percent = jQuery('<div class="progress progress-striped active">' +
		          '<div class="progress-bar" role="progressbar" style="width: 0%">' +
		          '</div>' +
		        '</div>').appendTo( fileli ).find('.progress-bar');
		    }
		    fileli.find('.state').text('上传中...');
		    percent.css( 'width', percentage * 100 + '%' );
		});
		uploader.on( 'uploadSuccess', function( file ) {
		    jQuery( '#'+file.id ).find('.state').text('上传成功');		    
		});

		uploader.on( 'uploadError', function( file ) {
		    jQuery( '#'+file.id ).find('.state').text('上传出错!');
		    jQuery( '#'+file.id ).find('.state').addClass('error');
		    uploader.removeFile( file );
		});

		uploader.on( 'uploadComplete', function( file ) {
		    jQuery( '#'+file.id ).find('.progress').fadeOut();
		});
		uploader.on( 'uploadAccept', function( file, response ) {
			if(callback){
				callback(response,curThis);
				return response.errno?false:true;
			}
		    if ( response.errno ) {		   
		    	showError(response.error);
		        return false;
		    } 	    
		});
	}
}

function humanSize(size){
	var humanImgSize;
	if(size>1048576){
		humanImgSize = Math.floor(size/1048576)+' M';
	}else if(size>1024){
		humanImgSize = Math.floor(size/1024)+' KB';				
	}else{
		humanImgSize = size+' B';
	}
	return humanImgSize;
}

function shortStr(str,startLen,endLen){
	var newStr = '';
	startLen = startLen?parseInt(startLen):3;
	endLen = endLen?parseInt(endLen):6;
	if( str.length>(startLen+endLen+5) ){
		newStr+=str.substr(0,3);
		newStr+='***';		    
		newStr+=str.substr(str.length-5,5);	
	}else{
		newStr = str;				
	}				    
	return newStr;
}
