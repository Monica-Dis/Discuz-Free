var	uploader,$list,$btn,curThis;
var state='pending';
var Upload = {	
	/*
	 * callback:�ϴ��ɹ��ص�
	 */
	img:function(curClass,maxSize,cutSize,callback){
		curThis = $("."+curClass);
		var	uploader,$list,$btn,curThis;
		$btn = curThis.find(".uploadBtn");
		$list = curThis.find(".uploadList");
		
		formData = cutSize?{'cut_sizes':cutSize}:'{}';
		var uploader = WebUploader.create({
		    // ѡ���ļ����Ƿ��Զ��ϴ���
			fileNumLimit:1,
		    auto: false,
		    // swf�ļ�·��
		    swf:DOMAIN+'/js/uploader/Uploader.swf',
		    // �ļ����շ���ˡ�
		    server: '/upload/img',
		    // ѡ���ļ��İ�ť����ѡ��
		    // �ڲ����ݵ�ǰ�����Ǵ�����������inputԪ�أ�Ҳ������flash.
		    pick: {
		    	id:curThis.find(".picker"),
		    	multiple:false		    	
		    },
		    formData:formData,
		    // ֻ����ѡ��ͼƬ�ļ���		    
		    accept: {
		    	title: 'Images',
		        extensions: 'gif,jpg,jpeg,bmp,png',
		        mimeTypes: 'image/*'
		    }
		    		    
		});
		
		$btn.on( 'click', function() {
		    if ( state === 'uploading' ) {
		        uploader.stop();
		    } else {
		        uploader.upload();
		    }
		});
		
		$list.on('click','.uploadDel',function() {
		    var curFileId=$(this).data("fileid");
		    if(curFileId){		    	
		    	uploader.removeFile( curFileId );
			    $list.html('');			    
			    curThis.find(".picker div").removeClass('webuploader-element-invisible').addClass("webuploader-container");
			    curThis.find(".preview").hide();
			    curThis.find(".imgVal").val('');
		    }  
		});
		
		uploader.on( 'fileQueued', function( file ) {
			maxSize = maxSize?maxSize:2097152;
			if(file){
				if(file.size>maxSize){
					var humanSize = Func.humanSize(maxSize);
					Html.alert('�ϴ��ļ���С���ܳ��� '+humanSize,null);
					uploader.removeFile( file );
					return false;
				}				
				//curThis.find(".picker").hide();
				curThis.find(".picker div").addClass('webuploader-element-invisible');
			}
			$list.html('');
		    $list.append( '<div id="' + file.id + '" class="item">' +
		        '<span class="info">' + Func.shortStr(file.name) + '</span><span class="state">�ȴ��ϴ�</span><a href="javascript:;" data-fileid="'+file.id+'" class="uploadDel" >ɾ��</a>'+'</div>' );	    	
		    uploader.upload();		    
		});
			
		uploader.on( 'uploadProgress', function( file, percentage ) {
		    var $li = $( '#'+file.id ),
		        $percent = $li.find('.progress .progress-bar');
		    // �����ظ�����
		    if ( !$percent.length ) {
		        $percent = $('<div class="progress progress-striped active">' +
		          '<div class="progress-bar" role="progressbar" style="width: 0%">' +
		          '</div>' +
		        '</div>').appendTo( $li ).find('.progress-bar');
		    }
		    $li.find('.state').text('�ϴ���...');
		    $percent.css( 'width', percentage * 100 + '%' );
		});
		uploader.on( 'uploadSuccess', function( file ) {
		    $( '#'+file.id ).find('.state').text('�ϴ��ɹ�');		    
		});

		uploader.on( 'uploadError', function( file ) {
		    $( '#'+file.id ).find('.state').text('�ϴ�����!');
		    $( '#'+file.id ).find('.state').addClass('error');
		    uploader.removeFile( file );
		});

		uploader.on( 'uploadComplete', function( file ) {
		    $( '#'+file.id ).find('.progress').fadeOut();
		});
		uploader.on( 'uploadAccept', function( file, response ) {
			if(callback){
				callback(response,curThis);
				return response.errno?false:true;
			}
		    if ( response.errno ) {		   
		    	Html.alert(response.error);
		        return false;
		    } 	    
		});
	}
}