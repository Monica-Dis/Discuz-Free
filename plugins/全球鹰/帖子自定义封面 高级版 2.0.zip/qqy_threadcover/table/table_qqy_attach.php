<?php

/**
 * Plugin For Discuz! X2.5-X3.0
 
 * Copyright (c) 2006 - 2016 Zhanzhangzu.com.

 * ����:      ȫ��ӥ
 
 * ����:      641500953@qq.com
 
 * ��վ:      www.zhanzhangzu.com
  
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_qqy_attach extends discuz_table {

	public function __construct() {
		$this->_table = 'forum_threadimage';
		$this->_pk = '';
		parent::__construct();
	}
	
	public function update($tid,$attachment,$remote){
		$gettid = DB::result_first("SELECT tid FROM ".DB::table($this->_table)." WHERE tid=$tid");
		if(empty($gettid)){
			DB::query("INSERT INTO ".DB::table($this->_table)." (tid,attachment,remote) VALUES ('$tid','$attachment','$remote')");
		}else{
			DB::query("UPDATE ".DB::table($this->_table)." SET attachment='$attachment',remote='$remote' WHERE tid=$tid");
		}
	}

}
?>