<?php
/**

 * Plugin For Discuz! X2.5-X3.2

 * Copyright (c) 2006 - 2016 Zhanzhangzu.com.

 * author:     quanqiuying

 * email:      641500953@qq.com

 * site:       www.zhanzhangzu.com

 */


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_qqy_threadcover {

}

class plugin_qqy_threadcover_forum extends plugin_qqy_threadcover{

	function post_middle_output($a){
		global $_G,$isfirstpost;
		$staticDir = 'source/plugin/qqy_threadcover/img';
		$thefids 	= $_G['cache']['plugin']['qqy_threadcover']['thefids'];
		$theusers 	= $_G['cache']['plugin']['qqy_threadcover']['theusers'];
		$ismust 	= $_G['cache']['plugin']['qqy_threadcover']['ismust'];

		if(!in_array($_G['fid'],(array)unserialize($thefids))) {
			return '';
		}

		if(!in_array($_G['groupid'],(array)unserialize($theusers))) {
			return '';
		}		

		if($_G['gp_action']!='edit'&&$_G['gp_action']!='newthread'){
			return '';
		}		

		if($_G['gp_action']=='edit'&&!$isfirstpost){
			return '';
		}
		$return='';
		$tid = (int)$_GET['tid'];
		if($tid){
			$basedir = !$_G['setting']['attachdir'] ? (DISCUZ_ROOT.'./data/attachment/') : $_G['setting']['attachdir'];
			$coverdir = 'threadcover/'.substr(md5($tid), 0, 2).'/'.substr(md5($tid), 2, 2).'/';
			$qqycoverdir=$basedir.'./forum/'.$coverdir."$tid".".jpg";
			if(file_exists($qqycoverdir)){
				$cover_exist = 1;
				$coverpath = getthreadcover($tid,1);
			}else{
				$cover_exist = 0;
			}
		}
		$charset=$_G['config']['output']['charset'];		
		if($charset=='gbk'){
			include(template("qqy_threadcover:post_middle_gbk"));			
		}else{
			include(template("qqy_threadcover:post_middle_utf8"));			
		}		
		return $return;
	}   			

	function post_middle_message($a){
		global $_G, $isfirstpost;
		$thefids = $_G['cache']['plugin']['qqy_threadcover']['thefids'];
		$theusers 	= $_G['cache']['plugin']['qqy_threadcover']['theusers'];
		$ismust 	= $_G['cache']['plugin']['qqy_threadcover']['ismust'];
		if(!in_array($_G['fid'],(array)unserialize($thefids))) {
			return '';
		}
		if(!in_array($_G['groupid'],(array)unserialize($theusers))) {
			return '';
		}	
		if($_G['gp_action']!='edit'&&$_G['gp_action']!='newthread'){
			return '';
		}
		if($_G['gp_action']=='edit'&&!$isfirstpost){
			return '';
		}
		$tid= (int)$a['param'][2]['tid'];
		$pid= (int)$a['param'][2]['pid'];
		if($tid){
			if( $_POST['qqy_cover'] ){
				$basepath = 'data/attachment/forum/qqy_threadcover/';
				$tempfile = $_POST['qqy_cover'];
                //判断是否为图片文件 增强安全性
                $imageinfo = getimagesize($tempfile);
                if( !$imageinfo || !is_array($imageinfo) || !in_array($imageinfo['2'],array(1,2,3))){
                    return '';
                }
				$threadimagedir = substr(md5($tid), 0, 2).'/'.substr(md5($tid), 2, 2).'/';
				$threadimage = $threadimagedir.$tid.'.jpg';
				dmkdir(DISCUZ_ROOT.'./'.$basepath.$threadimagedir);
				copy(DISCUZ_ROOT.'./'.$tempfile, DISCUZ_ROOT.'./'.$basepath.$threadimage);
				unlink(DISCUZ_ROOT.'./'.$tempfile);										
				require_once libfile('function/post');
				$setCoverRet = setthreadcover($pid, $tid,0,0,$basepath.$threadimage);
				if( $setCoverRet ){
					if( $_G['gp_action']!='newthread' ){
						C::t('forum_threadimage')->delete($tid);
					}								
					C::t('forum_threadimage')->insert(array(
						'tid' => $tid,
						'attachment' =>'qqy_threadcover/'.$threadimage							
					));
				}
				$showmsg = array('fid' =>$_G['fid'],'tid'=>$tid,'coverimg'=>'');
				$msgforward = array ('clean_msgforward'=>1,'refreshtime'=>3,'timeout' =>3);			
				showmessage('post_newthread_succeed','forum.php?mod=viewthread&tid='.$tid,$showmsg,$msgforward);							
			}
		}
	}	

	function post_bottom_output($a){
		global $_G, $isfirstpost;
		$thefids = $_G['cache']['plugin']['qqy_threadcover']['thefids'];
		$theusers 	= $_G['cache']['plugin']['qqy_threadcover']['theusers'];
		$ismust 	= $_G['cache']['plugin']['qqy_threadcover']['ismust'];
		if(!in_array($_G['fid'],(array)unserialize($thefids))) {
			return '';
		}
		if(!in_array($_G['groupid'],(array)unserialize($theusers))) {
			return '';
		}
		if($_G['gp_action']!='edit'&&$_G['gp_action']!='newthread'){
			return '';
		}
		if($_G['gp_action']=='edit' && !$isfirstpost){
			return '';
		}
		if(!empty($ismust)){
			$charset=$_G['config']['output']['charset'];		
			if($charset=='gbk'){
				include(template("qqy_threadcover:post_bottom_gbk"));			
			}else{
				include(template("qqy_threadcover:post_bottom_utf8"));			
			}
			return $return;
		}
	} 

}
//From: Dism·taobao·com
?>