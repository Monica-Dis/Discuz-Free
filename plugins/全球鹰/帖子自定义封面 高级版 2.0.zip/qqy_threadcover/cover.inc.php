<?php
/**
 * Plugin For Discuz! X2.5-X3.0
 * Copyright (c) 2006 - 2016 Zhanzhangzu.com.
 * ����:      ȫ��ӥ
 
 * ����:      641500953@qq.com
 * ��վ:      www.zhanzhangzu.com
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$tempFile 	= $_FILES['threadcover']['tmp_name'];
$allowtype 	= array('jpg','jpeg','gif','png');
$imginfo 	= pathinfo($_FILES['threadcover']['name']);
$imgtype  	= strtolower($imginfo['extension']);
$imgsize	= $_FILES["threadcover"]["size"];
$imgsize	= $imgsize/1024/1024;
$tempid = $_G['uid'].time().random(6);$data = array();
if( $_G['uid'] && $imgsize>0 ){
	if( $imgsize<=2){
		if (in_array($imgtype,$allowtype)) {
			list($time1,$time2)=explode(" ",microtime());			$basepath = 'data/attachment/forum/qqy_threadcover/';			$fullpath = DISCUZ_ROOT.'./'.$basepath;			
			dmkdir($fullpath.'temp/');			$temppath = $fullpath.'temp/'.$tempid.'.jpg';		
			move_uploaded_file($_FILES['threadcover']['tmp_name'],$temppath);			$tempfile = $basepath.'temp/'.$tempid.'.jpg';			$data['url'] = $tempfile;
			echo json_encode(array('errno'=>false,'error'=>null,'data'=>$data));
		}else{
			echo json_encode(array('errno'=>true,'error'=>lang('plugin/qqy_threadcover', 'errortype')));
		}
	}else{
		echo json_encode(array('errno'=>true,'error'=>lang('plugin/qqy_threadcover', 'maxsize')));
	}
}exit();

?>