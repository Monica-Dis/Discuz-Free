<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/misc');
function get_use_area($tid,$pid,$ip){
	global $_G;
	$area = C::t('#marx_post_area#marx_post_area')->area_by_pid($pid);
	if(!$area){
		$area = marx_convertip($ip);
		if($_G['charset'] == 'utf-8'){
			$area = iconv("gb2312","utf-8//IGNORE",$area);
		}
		$area = str_replace('- ','',$area);
		$insertData = array(
			'pid'=>$pid,
			'tid'=>$tid,
			'useip'=>$ip,
			'use_area'=>$area,
		);
		C::t('#marx_post_area#marx_post_area')->insert($insertData);
	}
	return $area;
}

function marx_convertip($ip) {

	$return = '';

	if(preg_match("/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/", $ip)) {

		$iparray = explode('.', $ip);

		if($iparray[0] == 10 || $iparray[0] == 127 || ($iparray[0] == 192 && $iparray[1] == 168) || ($iparray[0] == 172 && ($iparray[1] >= 16 && $iparray[1] <= 31))) {
			$return = '- LAN';
		} elseif($iparray[0] > 255 || $iparray[1] > 255 || $iparray[2] > 255 || $iparray[3] > 255) {
			$return = '- Invalid IP Address';
		} else {
			$fullipfile = DISCUZ_ROOT.'./source/plugin/marx_post_area/data/ipdata/qqwry.dat';
			$tinyipfile = DISCUZ_ROOT.'./data/ipdata/tinyipdata.dat';
			if(@file_exists($fullipfile)) {
				$return = convertip_full($ip, $fullipfile);
			} else if(@file_exists($tinyipfile)) {
				$return = convertip_tiny($ip, $tinyipfile);
			}
		}
	}

	return $return;

}