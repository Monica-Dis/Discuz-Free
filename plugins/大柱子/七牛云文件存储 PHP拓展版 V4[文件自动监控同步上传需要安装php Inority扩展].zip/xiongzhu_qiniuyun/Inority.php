<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
class Inority
{
    static $self = null;
    static $monitorList = array();   //被监控的列表
    public $config = array(); //配置
    public $events = array(
        IN_ACCESS => 'File Accessed', //被访问
        IN_MODIFY => 'File Modified', //被修改
        IN_CLOSE_WRITE => 'File Closed, Opened for Writing',//关闭,以供写入
        IN_MOVED_TO => 'File Moved In',   //移进来的文件名
        IN_MOVED_FROM => 'File Moved Out',//移出去的文件名
        IN_CREATE => 'File Created',   //文件被创建
        IN_DELETE => 'File Deleted', //文件被删除
        IN_DELETE_SELF => '被监视的文件或目录被删除',
        IN_MOVE_SELF => '被监视的文件或目录被移动',
    );

    /**
     * Inority constructor.
     * @param string $dirname 被监控的目录
     */
    public function __construct()
    {
        require_once __DIR__ . '/Qiniu.class.php';
        require_once __DIR__ . '/vendor/autoload.php';
        $config = file_get_contents('source/plugin/xiongzhu_qiniuyun/attachment/xiongzhu_qiniuyun.config');
        $config = json_decode($config, 1);
        \Xiongzhu\Qiniu::getQiniu($config);
        //1,初始化Inority对象
        $this->my_event = array_sum(array_keys($this->events));
        $this->ifd = inotify_init();
        stream_set_blocking($this->ifd, 1);
    }

    /**
     * 初始化,遍历要监控的目录
     */
    public function init()
    {
        while ($this->event_list = inotify_read($this->ifd)) {
            foreach ($this->event_list as $arr) {
                $filename = self::$monitorList[$arr['wd']] . '/' . $arr['name'];

                switch ($arr['mask']) {
                    case IN_ACCESS;//被访问
                        break;
                    case IN_CREATE;
                        //echo $this->events[$arr['mask']] . '_' . $filename . PHP_EOL;
                        break;
                    case IN_MODIFY;
                        //echo $this->events[$arr['mask']] . '_' . $filename . PHP_EOL;
                        break;
                    case IN_DELETE;
                        echo date('Y-m-d H:i:s'), PHP_EOL;
                        echo $this->events[$arr['mask']] . '_' . $filename . PHP_EOL;
                        $this->delete($filename);
                        break;
                    case 1073742080;    //创建目录
                        echo date('Y-m-d H:i:s'), PHP_EOL;
                        echo $this->events[$arr['mask']] . ';创建目录:' . $filename . PHP_EOL;
                        $this->xreaddir($filename);
                        break;
                    case 1073741888;  //在宝塔手动删除目录时触发,实际应该是移动到垃圾桶
                        //echo $this->events[$arr['mask']] . '_删除目录:' . $filename . PHP_EOL;
                        break;
                    case IN_MOVED_TO;
                        echo date('Y-m-d H:i:s'), PHP_EOL;
                        echo $this->events[$arr['mask']] . '_' . $filename . PHP_EOL;
                        $this->save($filename);
                        break;
                    case IN_MOVED_FROM;
                        echo $this->events[$arr['mask']] . '_' . $filename . PHP_EOL;
                        $this->delete($filename);
                        break;

                    case IN_DELETE_SELF; //被监视的目录删除
                        echo date('Y-m-d H:i:s'), PHP_EOL;
                        echo '被删除的监视器1' . $filename . PHP_EOL;
                        break;
                    case IN_MOVE_SELF;
                        echo date('Y-m-d H:i:s'), PHP_EOL;
                        echo "被删除的目录2 $filename" . PHP_EOL;
                        $mask = array_search(rtrim($filename, '/'), self::$monitorList); //查找对应的监视器键名
                        $monitor = self::$monitorList[$mask]; //记录被删除的监视器名称,后面有用
                        //1,删监视器
                        unset(self::$monitorList[$mask]);
                        //删子监视器
                        foreach (self::$monitorList as $k => $v) {
                            if (strpos($v . '/', $monitor . '/') === 0) {
                                unset(self::$monitorList[$k]);
                                echo "被删除的监视器 " . $v . PHP_EOL;
                            }
                        }
                        echo "被删除的监视器 $mask" . PHP_EOL;
                        break;
                    case IN_CLOSE_WRITE;
                        echo date('Y-m-d H:i:s'), PHP_EOL;
                        echo "关闭文件以供写入: $filename" . PHP_EOL;
//                        var_dump(file_exists($filename));
                        $this->save($filename);
                        break;
                    default;
                        echo date('Y-m-d H:i:s'), PHP_EOL;
                        echo '未知事件' . $arr['mask'] . ',文件名:' . $filename . PHP_EOL;
                        //默认处理方式
                        break;
                }
            }
        }
        $doc=$_SERVER['DOCUMENT_ROOT'].$_SERVER['SCRIPT_NAME'];
        $cmd='php '.$doc;
        exec($cmd);
    }

    /**新增监视器
     * @param $dirname
     */
    public function monitor_add($dirname)
    {
        echo '创建监视器:' . $dirname . PHP_EOL;
        $wd = inotify_add_watch($this->ifd, $dirname, $this->my_event);
        self::$monitorList[$wd] = $dirname;
    }

    /**递归目录,对目录创建监视器
     * @param $dirname
     */
    public function xreaddir($dirname)
    {
        $this->monitor_add($dirname);
        $dirHandle = opendir($dirname);
        while ($row = readdir($dirHandle)) {
            if ($row === '.' || $row === '..') { //跳过linx的上级目录
                continue;
            }
            $filename = $dirname . '/' . $row;
            //是目录,则添加监视器
            if (is_dir($filename)) {
                $this->xreaddir($filename);
            }
//            else {
//                $this->save($filename);
//            }
        }
    }

    /**执行上传七牛云的方法
     * @param $filename 本地文件地址
     * @retuen 仅失败时报错, 正确时不做操作, 最低限度修改原生DZ
     */
    public function save($filename)
    {
        //文件大小必须大于0
        if (@filesize($filename) && file_exists($filename)) {
            $this->qiniu = \Xiongzhu\Qiniu::getQiniu($this->config); //获取七牛云示例        $this->qiniu = \Xiongzhu\Qiniu::getQiniu($this->config); //获取七牛云示例
            $result = @$this->qiniu->Upload($filename, trim($filename, './'));
            if($result){
                file_put_contents(__DIR__ . '/attachment/logo.log', '上传成功' . $filename . PHP_EOL, FILE_APPEND);
            }else{
                file_put_contents(__DIR__ . '/attachment/logo.log', '上传失败'.$this->qiniu->error . $filename . PHP_EOL, FILE_APPEND);
            }
        }
    }

    /**删除文件
     * @param $filename
     */
    public function delete($filename)
    {
        file_put_contents(__DIR__ . '/attachment/logo.log', '删除' . $filename . PHP_EOL, FILE_APPEND);
        $this->qiniu = \Xiongzhu\Qiniu::getQiniu($this->config); //获取七牛云示例        $this->qiniu = \Xiongzhu\Qiniu::getQiniu($this->config); //获取七牛云示例
        @$result = $this->qiniu->delete(trim($filename, './'));
    }

    /**
     * 销毁类时,移除所有监视器,并关闭锁文件
     */
    public function __destruct()
    {
        // TODO: Implement __destruct() method.
        foreach (self::$monitorList as $k => $v) {
            inotify_rm_watch($this->ifd, $k);
        }
        fclose($this->ifd);
    }
}

////初始化,并传入需要监视的目录单独
$Inority = new Inority(); //记得给参数,决定开启时候是否同步本地文件
$Inority->xreaddir('./data/attachment');
$Inority->xreaddir('./uc_server/data/avatar');
$Inority->init();