<?php
$scriptlang['xiongzhu_qiniuyun'] = array(
    'file_noexists' => '文件不存在!!',

    'syncFile_start' => '开始同步文件!',
    'syncFile_success' => '同步成功!',
    'syncFile_fail' => '同步失败!',
    'syncFile_dir' => '主目录',
    'syncFile_yes' => '是',
    'syncFile_no' => '否',
    'syncFile_dir_buhefa' => '上传目录不合法',
    'syncFile_notdir' => '上传目录有误',
    'open_inority' => '开启监控服务',

);
$templatelang['xiongzhu_qiniuyun'] = array(
    'select_update' => '选择手动同步目录',
    'attachment_avatar' => '头像文件',
    'attachment_root' => 'attachment附件全目录 ',
    'attachment_album' => 'attachment/album目录 -01',
    'attachment_category' => 'attachment/category目录 -02',
    'attachment_common' => 'attachment/common目录 -03',
    'attachment_forum' => 'attachment/forum目录 -04',
    'attachment_group' => 'attachment/group目录 -05',
    'attachment_image' => 'attachment/image目录 -06',
    'attachment_portal' => 'attachment/portal目录 -07',
    'attachment_profile' => 'attachment/profile目录 -08',
    'attachment_swfupload' => 'attachment/swfupload目录 -09',
    'attachment_temp' => 'attachment/temp(临时文件)目录 -10',

    'syncFile_yes' => '是',
    'syncFile_no' => '否',

    'is_logo' => '开启同步记录',
    'is_continue' => '关闭页面继续上传',
    'is_unlink' => '手动同步历史文件时删除本地文件(谨慎)',

    'start_syncFile' => '同步历史文件',
    'clear_logo' => '删除日志',
    'query_logo' => '查看日志',
    'open_inority' => '开启监控服务',
    'check_upload' => '檢測上傳',

    'is_unlink_info' => '选择此项,将删除本地文件. 建议您测试功能正常后再开启!',
    'start_syncFile_info' => '点击确定,后台将自动同步文件,请勿多次点击',
);

$installlang['xiongzhu_qiniuyun'] = array();

