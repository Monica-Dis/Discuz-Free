<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once 'functions.php';
class plugin_xiongzhu_qiniuyun
{
    public $config = array();  //插件配置参数
    public static $qiniu = null; //七牛对象

    public function __construct()
    {
        global $_G;
        $this->config = $_G['cache']['plugin']['xiongzhu_qiniuyun'];
        $this->config['timeout'] = $this->config['timeout'] ? $this->config['timeout'] : 300; //默认超时时间
        $this->config['head'] = $this->config['head'] ? $this->config['head'] : 'http://';  //默认请求头
        $this->config['head'] = trim($this->config['head']);
        $this->config['fulldomain'] = $this->config['head'].$this->config['domain'];
    }

    /**所有模块加载前执行
     *
     */
    public function common()
    {
        global $_G;
        $_G['setting']['attachurl'] = $this->config['head'] . $this->config['domain'] . '/' . $_G['setting']['attachurl'];
    }

    public function avatar($a)
    {
        //如果開啟移動頭像
        if (!$this->config['pc_avatar']) {
            return;
        }
        //如果本地頭像不存在
        $avatar_img = "/uc_server/data/avatar/" . get_avatar($a['param'][0], $a['param'][1]) ;
        if(!file_exists('./'.$avatar_img)){
            return;
        }
        //使用遠程頭像
        $avatar_img_url = $this->config['fulldomain'] . $avatar_img . '?ts=' . time();
        global $_G;
//        $_G['hookavatar'] = $avatar_img_url;
        $_G['hookavatar'] = "<img src=$avatar_img_url >";
    }
    /**
     * 帖子的水印处理
     */
    public function discuzcode()
    {
        global $_G;
        if (!$water = $this->config['water'] || !$water_list = $this->config['water_list']) {
            return;
        }
        $_G['discuzcodemessage'] = preg_replace_callback('/\[attach\]\d{1,100}\[\/attach\]/', function ($v) {
            global $_G;
            $aa = str_replace('[attach]', '', $v[0]); //带尾巴的
            $attach_id = str_replace('[/attach]', '', $aa); //纯正的ID
            $table = DB::fetch_first("select tableid from %t where `aid` = %d", array('forum_attachment', $attach_id));
            $file = DB::fetch_first("select filename,filesize,attachment,isimage from %t where `aid` = %d", array('forum_attachment_' . $table['tableid'], $attach_id));
            if ($file['isimage']) {
                $url = $_G['setting']['attachurl'] . 'forum/' . $file['attachment'] . $this->config['water'];
                $str = <<<A
    <!--图片内容的替换-->
    <ignore_js_op>
    <img id="aimg_$attach_id" alt="$file[filename]" aid="$attach_id" src="$url" zoomfile="$url" file="$url" class="zoom" onclick="zoom(this, this.src, 0, 0, 0)" inpost="1" initialized="true" onmouseover="showMenu({'ctrlid':this.id,'pos':'2'})" width="100%">
    </ignore_js_op>
    <!--图片内容的替换结束-->
A;
                return $str;
            }
            return '[attach]' . $aa;
        }, $_G['discuzcodemessage']);
    }
}

/**论坛嵌入点
 * Class plugin_xiongzhu_qiniuyun_forum
 */
class plugin_xiongzhu_qiniuyun_forum extends plugin_xiongzhu_qiniuyun
{

}

/*门户类
 *
 */

class plugin_xiongzhu_qiniuyun_portal extends plugin_xiongzhu_qiniuyun
{
    //id= imgattachlist img
    function view_test()
    {
        $water = $this->config['water'];   //水印
        /*开启水印*/
        $str = <<<a
<script>
    onload = function () {
        var imgs = document.querySelectorAll('.vwtb img');
        Object.keys(imgs).forEach(function(key){               
            imgs[key].src = imgs[key].src + '$water';
        });
    }
</script>
a;
        echo $str;
        /*水印结束*/

    }

    /**
     * 解决发布文章上传图片时,七牛云上传过慢导致的报错问题
     * 原理:注册一个JS定时器,每0,1秒检测一下,当被检测的图片发生错误, 替换!
     *
     */
    function portalcp_test()
    {
        global $_G;
        $domain = $this->config['head'] . $this->config['domain'] . '/'; //完整的附件头,如:http://qiniu.zhuzi.xyz/
        $str = <<<a
<script>
    setInterval(function(){
        var imgs = document.querySelectorAll('#imgattachlist img');
        Object.keys(imgs).forEach(function (key){
            imgs[key] . onerror = function () {
                var src =imgs[key] . src ;
                imgs[key] . src = src.replace("$domain",'');
                console.log(imgs[key] . src);    
                imgs[key] . onerror = null;
            }
        });
    },100)
        
    
</script>
a;
echo $str;
    }
}

//空间,相册类 门户上传累 ->
class plugin_xiongzhu_qiniuyun_misc extends plugin_xiongzhu_qiniuyun
{

}

/*家园类
 *
 */

class plugin_xiongzhu_qiniuyun_home extends plugin_xiongzhu_qiniuyun
{

}

