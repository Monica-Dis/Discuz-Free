<?php
/**
 * 
 * DisM!出品 必属精品
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * 我们致力于为站长提供正版Discuz!应用而努力
 * E-mail: dism.taobao@qq.com
 * 工作时间: 周一到周五早上09:00-12:00, 下午13:00-18:00, 晚上19:30-23:30(周六、日休息)
 * DisM!用户交流群: ①群778390776
 * 
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once 'functions.php';
require_once 'Qiniu.class.php';
require_once 'vendor/autoload.php';
$log = 'source/plugin/xiongzhu_qiniuyun/attachment/logo.log'; //日志保存的目录
$pluginlang = lang('plugin/xiongzhu_qiniuyun');
include template('xiongzhu_qiniuyun:syncFile');

//不是管理员,禁止掉
if ($_G['adminid'] != 1) {
    exit;
}
//执行的方法
if ($action = $_GET['xiongzhu_action']) {
    if (function_exists($action)) {
        $action();
    } else {
        echo 'function no`t exists';
    }
}

/***************************************接收参数*********************************/
$dir = $_POST['dir'];   //等待上传的目录
$is_logo = (bool)$_POST['is_logo'];  //是否开启日志
$is_continue = (bool)$_POST['is_continue']; //是否跳过已上传的文件
$ignore_user_abort = (bool)$_POST['$ignore_user_abort']; //断开脚本后是否继续上传
$is_unlink = (bool)$_POST['is_unlink'];  //是否删除原文件

/***************************************检查参数*********************************/

global $_G;

/***************************************执行*********************************/

loadcache('plugin');
$config = $_G['cache']['plugin']['xiongzhu_qiniuyun'];
$qiniu = \Xiongzhu\Qiniu::getQiniu($config);

/**************************************函数库*********************************/

function syncFiles()
{
    $dir = $_POST['dir'];
    xreadDir($dir);
}

/**递归读取目录并上传文件
 */
function xreadDir($filename)
{
    if (!is_dir($filename)) return;
    $result = dir($filename);
    while ($row = $result->read()) {
        //跳过部分不需要上传的内容
        if ($row == '.' || $row == '..' || strpos(strrchr($row, '.'), '.htm') !== false) {
            continue; //
        }
        $row = $filename . '/' . $row; //拼接当前文件地址
        is_dir($row) ? xreadDir($row) : qiniuUpload($row);
    }
}

function qiniuUpload($filename)
{
    global $_G;
    global $qiniu;
    global $log;
    global $is_logo;
    global $is_unlink;
    loadcache('plugin');
    $config = $_G['cache']['plugin']['xiongzhu_qiniuyun'];
    $qiniu = \Xiongzhu\Qiniu::getQiniu($config);
    $file['savename'] = ltrim(strrchr($filename, '/'), './');
    $file['savepath'] = ltrim(str_replace($file['savename'], '', $filename), './');
    $file['tmp_name'] = $filename;
    if (!$qiniu->Upload($filename, trim($filename, './'))) {
        $message = $filename . lang('plugin/xiongzhu_qiniuyun', 'syncFile_fail') . '~~' . $qiniu->getError();
    } else {
        $message = $filename . lang('plugin/xiongzhu_qiniuyun', 'syncFile_success') . '__' . date('m-d H:i:s');
        /*上传成功是否删除本地文件*/
        if ($is_unlink) {
            unlink($filename);
        }
    }
    /*是否记录日志*/
//    if ($is_logo) {
        file_put_contents($log, $message . "\r\n" . PHP_EOL, FILE_APPEND);
//    }
}


/**清日志
 *
 */
function clear_log()
{
    global $log;
    if (file_exists($log)) {
        unlink($log);
        echo 'success';
    } else {
        echo 'file not exists';
    }
}

/**查看日志
 *
 */
function query_log()
{
    global $log;
    if (file_exists($log)) {
        $file = file_get_contents($log);
        echo $file;
    } else {
        echo 'logo not exists';
    }
}

function cheke_upload()
{
    global $_G;
    loadcache('plugin');
    $config = $_G['cache']['plugin']['xiongzhu_qiniuyun'];
    $qiniu = \Xiongzhu\Qiniu::getQiniu($config);
    $result = $qiniu->Put('test1', 'test2');
    if ($result) {
        echo 'success';
    }else{
        echo 'fail '.$qiniu->error;
    }
}

function open_inority()
{
    global $pluginlang;
    $logo = __DIR__ . '/logo.txt';//服务记录
    //1,检查是否禁用了函数
    if (!function_exists('exec')) {
        echo $pluginlang['exec_func_notexists'];
        exit;
    }
    if (!function_exists('file_get_contents')) {
        echo $pluginlang['exec_func_notexists'];
        exit;
    }
    if (!function_exists('file_put_contents')) {
        echo $pluginlang['exec_func_notexists'];
        exit;
    }
    //2检查是否正确安装Inority拓展
    if (!extension_loaded('Inotify')) {
        echo $pluginlang['inotify_extend_notexists'];
        exit;
    };

    /*生成七牛配置*/
    global $_G;
    loadcache('plugin');
    $config = $_G['cache']['plugin']['xiongzhu_qiniuyun'];
    $config['timeout'] = $config['timeout'] ? $config['timeout'] : 300; //默认超时时间
    $config['head'] = $config['head'] ? $config['head'] : 'http://';  //默认请求头
    $config['head'] = trim($config['head']);
    $plugin_attach = './source/plugin/xiongzhu_qiniuyun/attachment/';
    if (!is_dir($plugin_attach)) {
        mkdir($plugin_attach, 0777, true);
    }
    file_put_contents($plugin_attach . 'xiongzhu_qiniuyun.config', json_encode($config));

    /*杀死其他程序, 再开启一次*/
    exec('ps aux |grep -v grep|grep Inority |cut -c 9-15|xargs kill -15', $result); //杀死其他进程
    exec("php source/plugin/xiongzhu_qiniuyun/Inority.php > $logo & ", $result); //后台挂起服务
    if (!empty($result)) {
        echo 'open fail' . PHP_EOL;
        foreach ($result as $k => $v) {
            echo $v . PHP_EOL;
        }
    }

    exec("ps aux |grep Inority |grep -v grep ", $result); //查询是否开启成功
    echo count($result) ? 'open succes!' : 'open fail~!';
}