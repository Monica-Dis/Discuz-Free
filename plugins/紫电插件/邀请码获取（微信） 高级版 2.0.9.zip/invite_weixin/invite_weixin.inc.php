<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$siteurl = $_G['siteurl'];
$_G['siteurl'] = substr($_G['siteurl'], 0, - 28);
$_G['siteroot'] = substr($_G['siteroot'], 0, - 28);

$wechatObj = new wechatCallback();
$wechatObj->responseMsg();

class wechatCallback
{
	public function responseMsg()
	{
		
		//get post data, May be due to the different environments
		$postStr = file_get_contents("php://input");
		$postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);

		if (!empty($postStr)){
			$msgType = $postObj->MsgType;
			switch($msgType)
			{
				case "event":
					$result = $this->receiveEvent($postObj, $postStr);
					break;
				case "text":
					$result = $this->receiveText($postObj, $postStr);
					break;
				default:
				$content = "未知消息类型！";
				$result = $this->transmitText($postObj, $content);
			}
			echo $result;
		}else{
			echo "";
			exit;
		}
	}

/* P2eQfFYd5fJ */

	//接收事件消息
	private function receiveEvent($object, $str = '')
	{
		global $_G;
		$invite_weixin = $_G['cache']['plugin']['invite_weixin'];
		$openid = trim($object->FromUserName);
		switch ($object->Event)
		{
			case "subscribe":
				$content = diconv(str_replace("#","\n",$invite_weixin['subscribe']), CHARSET, 'UTF-8');
				break;
			case "CLICK":
				if($object->EventKey == "click_invite"){
					if($invite_weixin['invite_weixin_switch']){
						include_once DISCUZ_ROOT . './source/plugin/invite_weixin/invite_weixin.func.php';
						$content = invite_weixin($openid);
					}else{
						$content = diconv($invite_weixin['invite_weixin_tips'], CHARSET, 'UTF-8');
					}
				}elseif($invite_weixin['other_weixin_api']){
					include_once DISCUZ_ROOT . './source/plugin/invite_weixin/invite_weixin.func.php';
					echo other_weixin_api($str);
					exit;
				}else{
					$content = "未知事件消息！";
				}
				break;
			default:
				if($invite_weixin['other_weixin_api']){
					include_once DISCUZ_ROOT . './source/plugin/invite_weixin/invite_weixin.func.php';
					echo other_weixin_api($str);
					exit;
				}else{
					$content = "未知事件消息！";
				}
		}

		$result = $this->transmitText($object, $content);
		return $result;
	}

	//接收文本消息
	private function receiveText($object, $str = '')
	{
		global $_G;
		$invite_weixin = $_G['cache']['plugin']['invite_weixin'];
		$keyword = trim($object->Content);
		$openid = trim($object->FromUserName);
		if($keyword == "邀请码" || $keyword == "邀請碼"){
			if($invite_weixin['invite_weixin_switch']){
				include_once DISCUZ_ROOT . './source/plugin/invite_weixin/invite_weixin.func.php';
				$content = invite_weixin($openid);
			}else{
				$content = diconv($invite_weixin['invite_weixin_tips'], CHARSET, 'UTF-8');
			}
		}else{
			$keyword = diconv($keyword, 'UTF-8', CHARSET);
			$keyword = daddslashes($keyword);
			$reply_array = C::t('#invite_weixin#invite_weixin_reply')->fetch_by_keyword($keyword);
			if($invite_weixin['reply_status'] && !empty($reply_array)){
				if($reply_array['reply_type'] == 1){
					$content = diconv(stripslashes(str_replace("#","\n",$reply_array['content'])), CHARSET, 'UTF-8');
				}elseif($reply_array['reply_type'] == 2){
					$content = array();
					$content['Title'] = diconv($reply_array['title'], CHARSET, 'UTF-8');
					$content['Description'] = diconv(str_replace("#","\n",$reply_array['description']), CHARSET, 'UTF-8');
					$content['Url'] = diconv($reply_array['url'], CHARSET, 'UTF-8');
					$content['PicUrl'] = diconv($reply_array['picurl'], CHARSET, 'UTF-8');
				}else{
					$content = "管理员设置错了回复消息类型，请联系管理员解决！";
				}
			}elseif($invite_weixin['other_weixin_api']){
				include_once DISCUZ_ROOT . './source/plugin/invite_weixin/invite_weixin.func.php';
				echo other_weixin_api($str);
				exit;
			}else{
				if($invite_weixin['search_keyword_switch']){
					include_once DISCUZ_ROOT . './source/plugin/invite_weixin/invite_weixin.func.php';
					$content = search_keyword($keyword);
				}else{
					$content = diconv($invite_weixin['search_keyword_tips'], CHARSET, 'UTF-8');
				}
			}
		}

		if(is_array($content)){
			$result = $this->transmitNews($object, $content);
		}else{
			$result = $this->transmitText($object, $content);
		}
		return $result;
	}

	//回复文本消息
	private function transmitText($object, $content)
	{
		if(empty($content)){
			echo '';
			exit;
		}
		$xmlTpl = "<xml>
<ToUserName><![CDATA[%s]]></ToUserName>
<FromUserName><![CDATA[%s]]></FromUserName>
<CreateTime>%s</CreateTime>
<MsgType><![CDATA[text]]></MsgType>
<Content><![CDATA[%s]]></Content>
</xml>";
		$resultStr = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time(), $content);
		return $resultStr;
	}

	//回复图文消息
	private function transmitNews($object, $newsArray)
	{
		if(!is_array($newsArray)){
			return;
		}
		$xmlTpl = "<xml>
<ToUserName><![CDATA[%s]]></ToUserName>
<FromUserName><![CDATA[%s]]></FromUserName>
<CreateTime>%s</CreateTime>
<MsgType><![CDATA[news]]></MsgType>
<ArticleCount>%s</ArticleCount>
<Articles>
<item>
<Title><![CDATA[%s]]></Title>
<Description><![CDATA[%s]]></Description>
<PicUrl><![CDATA[%s]]></PicUrl>
<Url><![CDATA[%s]]></Url>
</item>
</Articles>
</xml>";

		$resultStr = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time(), 1, $newsArray['Title'], $newsArray['Description'], $newsArray['PicUrl'], $newsArray['Url']);
		return $resultStr;
	}
}