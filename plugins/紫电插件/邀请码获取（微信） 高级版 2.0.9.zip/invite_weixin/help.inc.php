<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	global $_G;
	loadcache('plugin');
	$wx_url = $_G['siteurl']."source/plugin/invite_weixin/weixin.api.php";
	$wx_token = $_G['cache']['plugin']['invite_weixin']['token'];

	showtableheader();
	echo '<tr><th colspan="15" class="partition">' . lang('plugin/invite_weixin', 'api_help_title') . '</th></tr>';
	echo '<tr><td style="font-size:16px;" class="tipsblock" s="1"><ul id="tipslis">';
	echo '<li>'.lang('plugin/invite_weixin', 'api_help_1').'</li>';
	echo '<li>'.lang('plugin/invite_weixin', 'api_help_2').' <a href="'.$_G['siteurl'].ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'"><font color="#009900">' . lang('plugin/invite_weixin', 'click_me') . '</font></a></li>';
	echo '<li>'.lang('plugin/invite_weixin', 'api_help_3').'</li>';
	echo '<li>'.lang('plugin/invite_weixin', 'api_help_4').'</li>';
	echo '<li>'.lang('plugin/invite_weixin', 'api_help_5').'</li>';
	echo '<li>'.lang('plugin/invite_weixin', 'api_help_6').'</li>';
	echo '<li>'.lang('plugin/invite_weixin', 'api_help_7').'</li>';
	echo '<li>'.lang('plugin/invite_weixin', 'api_help_8').' <a href="'.$_G['siteurl'].ADMINSCRIPT.'?action=setting&operation=access"><font color="#009900">' . lang('plugin/invite_weixin', 'click_me') . '</font></a></li>';
	echo '</ul></td></tr>';
	echo '<tr><th colspan="15" class="partition">' . lang('plugin/invite_weixin', 'api_title') . '</th></tr>';
	echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
	echo '<li><b>' . lang('plugin/invite_weixin', 'api_url') . '</b><input id="api_url" type="text" value="'.$wx_url.'" size="80" /><button type="button" onclick="copyText(\'api_url\')">' . lang('plugin/invite_weixin', 'click_copy') . '</button></li>';
	echo '<li><b>' . lang('plugin/invite_weixin', 'api_token') . '</b><input id="api_token" type="text" value="'.$wx_token.'" size="80" /><button type="button" onclick="copyText(\'api_token\')">' . lang('plugin/invite_weixin', 'click_copy') . '</button> <a href="'.$_G['siteurl'].ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'"><font color="#FF0000">' . lang('plugin/invite_weixin', 'api_token_msg') . '</font></a></li>';
	echo '</ul></td></tr>';
	echo '<script>function copyText(id){if(id == "api_url"){document.getElementById("api_url").select();} else {document.getElementById("api_token").select();}if(document.execCommand("copy", false, null)){alert("'.lang('plugin/invite_weixin', 'copy_ok').'");} else{alert("'.lang('plugin/invite_weixin', 'copy_error').'");}}</script>';
	showtablefooter();/*Dism_taobao_com*/