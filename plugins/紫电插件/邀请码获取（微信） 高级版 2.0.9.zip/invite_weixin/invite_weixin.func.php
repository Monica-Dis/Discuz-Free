<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function invite_weixin($openid) {
	global $_G;
	$invite_weixin = $_G['cache']['plugin']['invite_weixin'];
	$invite_orderid = DB::fetch_first('SELECT * FROM %t WHERE orderid=%s ORDER BY id DESC', array('common_invite', $openid));
	if(empty($invite_orderid)){
		$invite_uid = dintval($invite_weixin['invite_uid']);
		$invite = substr(time(),-6).mt_rand(10,99);
		$alutime = 30 * 60;
		$begtime = time();
		$endtime = $begtime + $alutime;
		$invite_id = DB::insert('common_invite',array('uid' => $invite_uid,'code' => $invite,'fuid' => 0,'fusername' => '','type' => 0,'email' => '','inviteip' => '','appid' => 0,'dateline' => $begtime,'endtime' => $endtime,'regdateline' => 0,'status' => 1,'orderid' => $openid),1);
		if($invite_uid == 0){
			$content = "您的邀请码为：\n【".$invite."】\n有效期：30分钟\n\n<a href=\"".$_G['siteurl']."member.php?mod=".$_G['setting']['regname']."\">前往注册>></a>";
		}else{
			$content = "您的邀请码为：\n【".$invite."】\n有效期：30分钟\n\n<a href=\"".$_G['siteurl']."home.php?mod=invite&id=".$invite_id."&c=".$invite."\">前往注册>></a>";
		}
	}else{
		if($invite_orderid['status'] == 2){
			$invite_orderid['fusername'] = diconv($invite_orderid['fusername'], CHARSET, 'UTF-8');
			$content = "您已经使用邀请码注册过,请勿重复获取!\n\n此邀请码注册账号信息：\nUID：".$invite_orderid['fuid']."\n用户名：".$invite_orderid['fusername'];
		}elseif($invite_orderid['endtime'] > TIMESTAMP){
			if($invite_orderid['uid'] == 0){
				$content = "邀请码仍然有效,请勿重复获取!\n您的邀请码为：【".$invite_orderid['code']."】\n\n<a href=\"".$_G['siteurl']."member.php?mod=".$_G['setting']['regname']."\">前往注册>></a>";
			}else{
				$content = "邀请码仍然有效,请勿重复获取!\n您的邀请码为：【".$invite_orderid['code']."】\n\n<a href=\"".$_G['siteurl']."home.php?mod=invite&id=".$invite_orderid['id']."&c=".$invite_orderid['code']."\">前往注册>></a>";
			}
		}else{
			$alutime = 30 * 60;
			$begtime = time();
			$endtime = $begtime + $alutime;
			DB::update('common_invite',array('endtime' => $endtime),array('id' => $invite_orderid['id']));
			if($invite_orderid['uid'] == 0){
				$content = "已为您的邀请码续期！\n您的邀请码为：\n【".$invite_orderid['code']."】\n有效期：30分钟\n\n<a href=\"".$_G['siteurl']."member.php?mod=".$_G['setting']['regname']."\">前往注册>></a>";
			}else{
				$content = "已为您的邀请码续期！\n您的邀请码为：\n【".$invite_orderid['code']."】\n有效期：30分钟\n\n<a href=\"".$_G['siteurl']."home.php?mod=invite&id=".$invite_orderid['id']."&c=".$invite_orderid['code']."\">前往注册>></a>";
			}
		}
	}
	return $content;
}

function other_weixin_api($str) {
	global $_G;
	$invite_weixin = $_G['cache']['plugin']['invite_weixin'];
	return dataPost($invite_weixin['other_weixin_api_url'], $str);
}

function search_keyword($keyword) {
	global $_G;
	$keyword = str_replace("%","",str_replace("_","",$keyword));
	$serial_number_array = array('','','','','','','','');
	$fid = '';
	$maxthreads = 8;
	$sql = "SELECT subject,tid,authorid FROM ".DB::table('forum_thread')." WHERE displayorder >= 0";
	$sql .= " AND subject LIKE '%".$keyword."%' ORDER BY dateline DESC LIMIT 0, $maxthreads";
	$query = DB::query($sql);
	$content = "『".diconv($keyword, CHARSET, 'UTF-8')."』的搜索结果:\n\n";
	$i = 0;
	$posts_num = DB::num_rows($query) - 1;
	while($thread = DB::fetch($query)) {
		$content .= $serial_number_array[$i].'.<a href="'.$_G['siteurl'].'forum.php?mod=viewthread&tid='.$thread['tid'].'">'.diconv(cutstr($thread['subject'], 52), CHARSET, 'UTF-8').'</a>';
		if($i < $posts_num){
			$content .= "\n";
		}
		$i++;
	}
	if($posts_num < 0){
		$content = "对不起，该关键词未查询到相关文章！";
	}
	return $content;
}

function dataPost($url, $post_data = '') {//curl
	$ch = curl_init();
	$timeout = 5;
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, 1);
	if($post_data != ''){
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
	}
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	curl_setopt($ch, CURLOPT_HEADER, false);
	$file_contents = curl_exec($ch);
	curl_close($ch);
	return $file_contents;
}