<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_invite_weixin_reply extends discuz_table{
	public function __construct() {
		parent::__construct(); /*Dism_taobao-com*/
		$this->_table = 'plugin_invite_weixin_reply';
		$this->_pk    = 'id';
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}

	public function fetch_by_keyword($keyword) {
		return DB::fetch_first("SELECT * FROM %t WHERE keyword=%s", array($this->_table, $keyword));
	}

	public function fetch_all_list($where='') {
		$whereStr = '';
		if(!empty($where)){
			$whereStr = ' WHERE '.$where;
		}
		return DB::fetch_all("SELECT * FROM %t $whereStr ORDER BY id DESC", array($this->_table));
	}

	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}

	public function insert($data, $return_insert_id = false, $replace = false, $silent = false) {
		return DB::insert($this->_table, $data, $return_insert_id, $replace, $silent);
	}

	public function update($val, $data, $unbuffered = false, $low_priority = false) {
		if(isset($val) && !empty($data) && is_array($data)) {
			$this->checkpk();
			$ret = DB::update($this->_table, $data, DB::field($this->_pk, $val), $unbuffered, $low_priority);
			foreach((array)$val as $id) {
				$this->update_cache($id, $data);
			}
			return $ret;
		}
		return !$unbuffered ? 0 : false;
	}
}