<?php
	if ($_SERVER ['REQUEST_METHOD'] == 'POST' || isset($_GET ['echostr'])) {
		define('DISABLEXSSCHECK', true);
		require_once '../../../source/class/class_core.php';
		$discuz = C::app();
		$cachelist = array('plugin');
		$discuz->cachelist = $cachelist;
		$discuz->init();
		$invite_weixin = $_G['cache']['plugin']['invite_weixin'];
		if(!empty($_GET['echostr'])&&!empty($_GET["signature"])&&!empty($_GET["nonce"])){
			define("TOKEN", $invite_weixin['token']);
			$echoStr = $_GET["echostr"];

			//valid signature , option
			if($invite_weixin['token_check_sign'] && checkSignature()){
				echo $echoStr;
				exit;
			}
		} else {
			//define('CURMODULE', 'invite_weixin');
			require_once DISCUZ_ROOT . './source/plugin/invite_weixin/invite_weixin.inc.php';
		}
	} else {
		echo 'Access Denied';
	}
 
	/* 6210 */
	function checkSignature()
	{
		// you must define TOKEN by yourself
		if (!defined("TOKEN")) {
			throw new Exception('TOKEN is not defined!');
		}

		$signature = $_GET["signature"];
		$timestamp = $_GET["timestamp"];
		$nonce = $_GET["nonce"];

		$token = TOKEN;
		$tmpArr = array($token, $timestamp, $nonce);
		// use SORT_STRING rule
		sort($tmpArr, SORT_STRING);
		$tmpStr = implode( $tmpArr );
		$tmpStr = sha1( $tmpStr );

		if( $tmpStr == $signature ){
			return true;
		}else{
			return false;
		}
	}