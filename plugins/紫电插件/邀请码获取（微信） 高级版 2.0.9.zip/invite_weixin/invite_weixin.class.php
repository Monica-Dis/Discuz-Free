<?php
if(!defined('IN_DISCUZ'))exit('Access Defined!');
class plugin_invite_weixin{
	public function global_footer(){
		global $_G;
		$invite_button = $_G['cache']['plugin']['invite_weixin']['invite_button'];
		include template('invite_weixin:connect');
		return $button;
	}
}
class plugin_invite_weixin_member extends plugin_invite_weixin{
	public function register_top(){
		global $_G;
		$invite_button = $_G['cache']['plugin']['invite_weixin']['invite_button'];
		include template('invite_weixin:button');
		return $button;
	}
}