<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
showtableheader(lang('plugin/invite_weixin','tips'));
showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
	lang('plugin/invite_weixin','new_tip_1')
));
showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
	lang('plugin/invite_weixin','new_tip_2')
));
showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
	lang('plugin/invite_weixin','new_tip_3')
));
showtablefooter();/*Dism_taobao_com*/
$userlist=array();
$pagenum=20;
$page=max(1,intval($_GET['page']));
$count=DB::result_first("select count(*) from ".DB::table("common_invite")." where 1 $where");
$data=DB::fetch_all("select * from ".DB::table("common_invite")." where 1 $where order by id desc limit ".($page-1)*$pagenum.",$pagenum");
showtableheader(lang('plugin/invite_weixin','log_title'));
showsubtitle(array('ID',lang('plugin/invite_weixin','log_username'),lang('plugin/invite_weixin','log_username2'),lang('plugin/invite_weixin','log_code'),lang('plugin/invite_weixin','log_dateline'),lang('plugin/invite_weixin','log_endtime'),lang('plugin/invite_weixin','log_regdateline'),lang('plugin/invite_weixin','log_status'),lang('plugin/invite_weixin','log_openid')));
foreach($data as $k=>$item) {
	if(!$userlist[$item['uid']]){
		$userlist[$item['uid']]=_getusername($item['uid']);
	}
	$item['username']=$userlist[$item['uid']];
	showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
		$item['id'],
		$item['uid']==0? lang('plugin/invite_weixin','log_username1'):'<a href="home.php?mod=space&uid='.$item['uid'].'" target="_blank">'.$item['username'].'</a>',
		$item['fuid']? '<a href="home.php?mod=space&uid='.$item['fuid'].'" target="_blank">'.$item['fusername'].'</a>':'/',
		$item['code'],
		dgmdate($item['dateline'],'Y-m-d H:i:s'),
		dgmdate($item['endtime'],'Y-m-d H:i:s'),
		$item['regdateline']? dgmdate($item['regdateline'],'Y-m-d H:i:s'):'/',
		lang('plugin/invite_weixin','log_status_'.$item['status']),
		$item['orderid']? $item['orderid']:'/',
	));
}
showtablefooter();/*Dism_taobao_com*/
echo multi($count, $pagenum, $page, "admin.php?action=plugins&operation=config&do=".$pluginid."&identifier=invite_weixin&pmod=log"); 
function _getusername($uid){
	return DB::result_first("select username from ".DB::table('common_member')." where uid='$uid'");
}