<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	global $_G;
	loadcache('plugin');
	$invite_weixin = $_G['cache']['plugin']['invite_weixin'];

	if($_GET['mact'] == 'add'){
		if(submitcheck('submit')){
			$insertData = array();
			$keyword = isset($_POST['keyword'])? addslashes($_POST['keyword']):'';
			$have_keyword = C::t('#invite_weixin#invite_weixin_reply')->fetch_by_keyword($keyword);
			if(!empty($have_keyword)){
				cpmsg(lang('plugin/invite_weixin', 'has_keyword'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=invite_weixin&pmod=reply_config', 'error');
				exit;
			}
			if(empty($keyword)){
				cpmsg(lang('plugin/invite_weixin', 'not_keyword'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=invite_weixin&pmod=reply_config', 'error');
				exit;
			}
			$reply_type = $_GET['reply_type'];
			$content = isset($_POST['content'])? addslashes($_POST['content']):'';
			$title = isset($_POST['title'])? addslashes($_POST['title']):'';
			$description = isset($_POST['description'])? addslashes($_POST['description']):'';
			$url = isset($_POST['url'])? addslashes($_POST['url']):'';
			$picurl = isset($_POST['picurl'])? addslashes($_POST['picurl']):'';
			$insertData['keyword'] = $keyword;
			$insertData['reply_type'] = $reply_type;
			$insertData['content'] = $content;
			$insertData['title'] = $title;
			$insertData['description'] = $description;
			$insertData['url'] = $url;
			$insertData['picurl'] = $picurl;
			C::t('#invite_weixin#invite_weixin_reply')->insert($insertData);
			cpmsg(lang('plugin/invite_weixin', 'act_success'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=invite_weixin&pmod=reply_config', 'succeed');
		}else{
			showformheader('plugins&operation=config&do='.$pluginid.'&identifier=invite_weixin&pmod=reply_config&mact=add&reply_type='.$_GET['reply_type'],'','','post');
			showtableheader();
			echo '<tr><th colspan="15" class="partition"><a href="'.$_G['siteurl'].ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=invite_weixin&pmod=reply_config"><b>' . lang('plugin/invite_weixin', 'reply_list_back') . '</b></a></th></tr>';
			echo '<tr class="header"><th>'.lang('plugin/invite_weixin', 'keyword').'</th><th></th></tr>';
			echo '<tr><td width="300"><input name="keyword" type="text" value="" size="40" /></td><td>'.lang('plugin/invite_weixin', 'keyword_msg').'</td></tr>';

			if($_GET['reply_type'] == 1){
				echo '<tr class="header"><th>'.lang('plugin/invite_weixin', 'content').'</th><th></th></tr>';
				echo '<tr><td><textarea rows="6" name="content" id="content" cols="40" class="tarea"></textarea></td><td> <a href="javascript:void(0);" onclick="javascript:addA();">'.lang('plugin/invite_weixin', 'add_a').'</a> '.lang('plugin/invite_weixin', 'txt_msg').'</td></tr>';
				echo '<script>function addA(){var ele = document.getElementById("content");ele.value = ele.value + "<a href=\"'.lang('plugin/invite_weixin', 'a_link').'\">'.lang('plugin/invite_weixin', 'a_text').'<\/a>";}</script>';
			}else if($_GET['reply_type'] == 2){
				echo '<tr class="header"><th>'.lang('plugin/invite_weixin', 'title').'</th><th></th></tr>';
				echo '<tr><td><input name="title" type="text" value="" size="40"/></td><td></td></tr>';
				echo '<tr class="header"><th>'.lang('plugin/invite_weixin', 'description').'</th><th></th></tr>';
				echo '<tr><td><textarea rows="6" name="description" cols="40" class="tarea"></textarea></td><td>'.lang('plugin/invite_weixin', 'txt_msg').'</td></tr>';
				echo '<tr class="header"><th>'.lang('plugin/invite_weixin', 'url').'</th><th></th></tr>';
				echo '<tr><td><input name="url" type="text" value="" size="60"/></td><td>'.lang('plugin/invite_weixin', 'url_msg').'</td></tr>';
				echo '<tr class="header"><th>'.lang('plugin/invite_weixin', 'picurl').'</th><th></th></tr>';
				echo '<tr><td><input name="picurl" type="text" value="" size="60"/></td><td>'.lang('plugin/invite_weixin', 'url_msg').'</td></tr>';
			}
			showsubmit('submit', 'submit');
			showtablefooter();/*Dism_taobao_com*/
			showformfooter();
		}
	}else if($_GET['mact'] == 'edit'){
		$replyInfo = C::t('#invite_weixin#invite_weixin_reply')->fetch_by_id($_GET['id']);
		if(submitcheck('submit')){
			$updateData = array();
			$content = isset($_POST['content'])? addslashes($_POST['content']):'';
			$title = isset($_POST['title'])? addslashes($_POST['title']):'';
			$description = isset($_POST['description'])? addslashes($_POST['description']):'';
			$url = isset($_POST['url'])? addslashes($_POST['url']):'';
			$picurl = isset($_POST['picurl'])? addslashes($_POST['picurl']):'';
			$updateData['content'] = $content;
			$updateData['title'] = $title;
			$updateData['description'] = $description;
			$updateData['url'] = $url;
			$updateData['picurl'] = $picurl;
			C::t('#invite_weixin#invite_weixin_reply')->update($replyInfo['id'],$updateData);
			cpmsg(lang('plugin/invite_weixin', 'act_success'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=invite_weixin&pmod=reply_config', 'succeed');
		}else{
			showformheader('plugins&operation=config&do='.$pluginid.'&identifier=invite_weixin&pmod=reply_config&mact=edit&id='.$_GET['id'],'','','post');
			showtableheader();
			echo '<tr><th colspan="15" class="partition"><a href="'.$_G['siteurl'].ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=invite_weixin&pmod=reply_config'.'"><font color="#F60"><b>' . lang('plugin/invite_weixin', 'reply_list_back') . '</b></font></a></th></tr>';
			echo '<tr class="header"><th>'.lang('plugin/invite_weixin', 'keyword').'</th><th></th></tr>';
			echo '<tr><td width="300"><input name="keyword" disabled="disabled" type="text" value="'.stripslashes($replyInfo['keyword']).'" size="40" /></td><td>'.lang('plugin/invite_weixin', 'keyword_msg').'</td></tr>';

			if($replyInfo['reply_type'] == 1){
				echo '<tr class="header"><th>'.lang('plugin/invite_weixin', 'content').'</th><th></th></tr>';
				echo '<tr><td><textarea rows="6" name="content" id="content" cols="40" class="tarea">'.stripslashes($replyInfo['content']).'</textarea></td><td> <a href="javascript:void(0);" onclick="javascript:addA();">'.lang('plugin/invite_weixin', 'add_a').'</a> '.lang('plugin/invite_weixin', 'txt_msg').'</td></tr>';
				echo '<script>function addA(){var ele = document.getElementById("content");ele.value = ele.value + "<a href=\"'.lang('plugin/invite_weixin', 'a_link').'\">'.lang('plugin/invite_weixin', 'a_text').'<\/a>";}</script>';
			}else if($replyInfo['reply_type'] == 2){
				echo '<tr class="header"><th>'.lang('plugin/invite_weixin', 'title').'</th><th></th></tr>';
				echo '<tr><td><input name="title" type="text" value="'.stripslashes($replyInfo['title']).'" size="40"/></td><td></td></tr>';
				echo '<tr class="header"><th>'.lang('plugin/invite_weixin', 'description').'</th><th></th></tr>';
				echo '<tr><td><textarea rows="6" name="description" cols="40" class="tarea">'.stripslashes($replyInfo['description']).'</textarea></td><td>'.lang('plugin/invite_weixin', 'txt_msg').'</td></tr>';
				echo '<tr class="header"><th>'.lang('plugin/invite_weixin', 'url').'</th><th></th></tr>';
				echo '<tr><td><input name="url" type="text" value="'.stripslashes($replyInfo['url']).'" size="60"/></td><td></td></tr>';
				echo '<tr class="header"><th>'.lang('plugin/invite_weixin', 'picurl').'</th><th></th></tr>';
				echo '<tr><td><input name="picurl" type="text" value="'.stripslashes($replyInfo['picurl']).'" size="60"/></td><td></td></tr>';
			}
			showsubmit('submit', 'submit');
			showtablefooter();/*Dism_taobao_com*/
			showformfooter();
		}
	}else if($_GET['formhash'] == FORMHASH && $_GET['mact'] == 'del'){
		C::t('#invite_weixin#invite_weixin_reply')->delete_by_id($_GET['id']);
		cpmsg(lang('plugin/invite_weixin', 'act_success'), $_G['siteurl'].ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=invite_weixin&pmod=reply_config', 'succeed');
	}else{
		$replyList = C::t('#invite_weixin#invite_weixin_reply')->fetch_all_list();
		showtableheader();
		echo '<tr><th colspan="15" class="partition">' . lang('plugin/invite_weixin', 'reply_list_title') . '</th></tr>';
		echo '<tr><td colspan="15" class="tipsblock" s="1"><ul id="tipslis">';
		echo '<li>' . lang('plugin/invite_weixin', 'reply_list_tips') . '</li>';
		echo '</ul></td></tr>';
		echo '<tr><th colspan="15">';
		echo '&nbsp;&nbsp;<a class="addtr" href="'.$_G['siteurl'].ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=invite_weixin&pmod=reply_config&mact=add&reply_type=1">' . lang('plugin/invite_weixin', 'add_wb') . '</a>';
		echo '&nbsp;&nbsp;<a class="addtr" href="'.$_G['siteurl'].ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=invite_weixin&pmod=reply_config&mact=add&reply_type=2">' . lang('plugin/invite_weixin', 'add_tw') . '</a>';
		echo '</th></tr>';
		echo '<tr class="header">';
		echo '<th colspan="3">' . lang('plugin/invite_weixin', 'keyword') . '</th>';
		echo '<th colspan="2">' . lang('plugin/invite_weixin', 'reply_type') . '</th>';
		echo '<th colspan="4">' . lang('plugin/invite_weixin', 'content') . '</th>';
		echo '<th colspan="4">' . lang('plugin/invite_weixin', 'title') . '</th>';
		echo '<th colspan="2">' . lang('plugin/invite_weixin', 'handle') . '</th>';
		echo '</tr>';

		foreach ($replyList as $key => $value) {
			$type_name = '';
			if($value['reply_type']==1){
				$type_name = lang('plugin/invite_weixin', 'wb');
			}else if($value['reply_type']==2){
				$type_name = lang('plugin/invite_weixin', 'tw');
			}
			echo '<tr>';
			echo '<td colspan="3">' . stripslashes($value['keyword']) . '</td>';
			echo '<td colspan="2">' . $type_name . '</td>';
			echo '<td colspan="4"><code>' . htmlspecialchars(stripslashes($value['content'])) . '</code></td>';
			echo '<td colspan="4">' . stripslashes($value['title']) . '</td>';
			echo '<td colspan="2">';
			echo '<a href="'.$_G['siteurl'].ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=invite_weixin&pmod=reply_config&mact=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . lang('plugin/invite_weixin', 'edit').'</a>';
			echo '&nbsp;|&nbsp;';
			echo '<a href="'.$_G['siteurl'].ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=invite_weixin&pmod=reply_config&mact=del&id='.$value['id'].'&formhash='.FORMHASH.'">' . lang('plugin/invite_weixin', 'delete') . '</a>';
			echo '</td>';
			echo '</tr>';
		}
		showtablefooter();/*Dism_taobao_com*/
		echo '<style>table {width: 100%;table-layout: fixed;}table tr td {text-overflow: ellipsis;-moz-text-overflow: ellipsis;overflow: hidden;white-space: nowrap;}</style>';
	}