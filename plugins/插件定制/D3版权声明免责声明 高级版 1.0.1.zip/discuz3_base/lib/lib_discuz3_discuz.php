<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once 'source/function/function_discuzcode.php';
require_once 'source/plugin/discuz3_base/lib/lib_discuz3.php';

/**
 * discuz encapsulations
 * @version 1.0.0
 * @author DisM!Ӧ������(dism.taobao.com)
 * @date 2019-11-19 16:05
 */
class lib_discuz3_discuz extends lib_discuz3 {
    /**
     * identifier
     * @var string
     */
    private $identifier;
    
    /**
     * @return string
     */
    protected function getIdentifier () {
        return $this->identifier;
    }
    
	/**
     * Parametric construction
     * @param string $identifier
     * @author DisM!Ӧ������(dism.taobao.com)
     * @date 2019-11-21 18:46
     */
    public function __construct($identifier) {
    	$this->identifier = $identifier;
    }
    
    /**
     * get template path
     * @param string $template_name
     * @return string
     * @author DisM!Ӧ������(dism.taobao.com)
     * @date 2019-11-21 18:20
     */
    protected function template($template_name = '') {
    	if($this->is_empty($template_name)) {
    		$template_name = $this->identifier;
    	}
    	return template($this->identifier.':'.$template_name);
    }
    
    /**
     * get bbs name
     * @return string
     * @author DisM!Ӧ������(dism.taobao.com)
     * @date 2019-11-20 10:08
     */
    protected function bbname() {
    	global $_G;
    	return $_G['setting']['bbname'];
    }
    
    /**
     * get website url
     * @return string
     * @author DisM!Ӧ������(dism.taobao.com)
     * @date 2019-11-20 23:35
     */
    protected function siteurl() {
    	global $_G;
    	return $_G['siteurl'];
    }
    
    /**
     * get forum info
     * @param string $key
     * @return string
     * @author DisM!Ӧ������(dism.taobao.com)
     * @date 2019-11-20 21:16
     */
    protected function forum($key) {
    	global $_G;
    	return $_G['forum'][$key];
    }
    
    /**
     * get forum thread info
     * @param string $key
     * @return string
     * @author DisM!Ӧ������(dism.taobao.com)
     * @date 2019-11-20 20:24
     */
    protected function forum_thread($key) {
    	global $_G;
    	return $_G['forum_thread'][$key];
    }
    
    /**
     * get forum id
     * @return int
     * @author DisM!Ӧ������(dism.taobao.com)
     * @date 2019-11-21 00:12
     */
    protected function fid() {
    	return $this->forum('fid');
    }
    
    /**
     * get plugin var
     * @param string $var_name
     * @return string|int
     * @author DisM!Ӧ������(dism.taobao.com)
     * @date 2019-11-19 21:04
     */
    protected function plugin_var($var_name, $default_val = '') {
    	global $_G;
    	$value = $_G['cache']['plugin'][$this->identifier][$var_name];
    	
    	if($this->is_empty($value)) {
    		$value = $default_val;
    	}
    	return $value;
    }
    
    /**
     * get selected forums
     * @param string $key
     * @return array
     * @author DisM!Ӧ������(dism.taobao.com)
     * @date 2019-11-21 00:11
     */
    protected function forums($key) {
    	return unserialize($this->plugin_var($key));
    }
    
    /**
     * get selected values for selects
     * @param string $key
     * @return array
     * @author DisM!Ӧ������(dism.taobao.com)
     * @date 2019-11-21 23:54
     */
    protected function selects($key) {
    	return unserialize($this->plugin_var($key));
    }
    
    /**
     * discuz code to html
     * @param string $str
     * @return string
     * @author DisM!Ӧ������(dism.taobao.com)
     * @date 2019-11-21 11:38
     */
    protected function dzcode2html($str) {
    	/**'b', 'i', 'u', 'color','size', 'font', 'align', 'url', 'email', 'quote',
    	 'list', '\*', 'img', 'swf', 'wma', 'wmv', 'hide', 'FLIPH', 'FLIPV', 'BLUR'**/
    	//, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0
    	$hastag = preg_match('/(\[\s*\/[a-z]+\s*\])/', $str);
    	return $hastag ? discuzcode($str) : $str;
    }
}