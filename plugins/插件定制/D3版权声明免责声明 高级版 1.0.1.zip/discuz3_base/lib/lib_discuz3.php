<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/**
 * common class for my plugin
 */
class lib_discuz3 {
	// css style
	private $style;
	
	/**
	 * Determine if the object is empty
	 * @param string|array $obj
	 * @return boolean is_empty
	 * @author DisM!Ӧ������(dism.taobao.com)
	 * @date 2019-11-21 19:16
	 */
	protected function is_empty($obj) {
		if($obj == null) {
			return true;
		}
		if(is_string($obj)) {
			return strlen(trim($obj)) <= 0;
		}
		if(is_array($obj)) {
			return count($obj) <= 0;
		}
		return false;
	}
	
	/**
	 * Whether it contains empty for arra 
	 * @param array $obj
	 * @return boolean
	 * @author DisM!Ӧ������(dism.taobao.com)
	 * @date 2019-11-22 09:05
	 */
	protected function has_empty($obj) {
		if($this->is_empty($obj)) {
			return true;
		}
		
		$has_empty = false;
		
		if(is_array($obj)) {
			foreach ($obj as $key => $val) {
				if($this->is_empty($val)) {
					$has_empty = true;
					break;
				}
			}
		}
		return $has_empty;
	}
	
	/**
	 * Whether to include html tag for tr
	 * @param string $str
	 * @return boolean has_br_tag
	 * @author DisM!Ӧ������(dism.taobao.com)
	 * @date 2019-11-21 12:52
	 */
	protected function has_br_tag($str) {
		return preg_match('/(<\s*br\s*\/?\s*>)/', $str) > 0;
	}
	
	/**
	 * get array value
	 * @param array $arr
	 * @param int $index
	 * @return object
	 * @author DisM!Ӧ������(dism.taobao.com)
	 * @date 2019-11-21 00:23
	 */
	protected function arr_val($arr, $index) {
		return $arr[$index];
	}
	
	/**
	 * get arr index for obj
	 * @param string $arr
	 * @param string|int $obj
	 * @return number
	 * @author DisM!Ӧ������(dism.taobao.com)
	 * @date 2019-11-22 13:05
	 */
	protected function arr_index($arr, $obj = '') {
		$index = -1;
		$num = count($arr);
		for($i = 0;$i < $num;$i++) {
			if($arr[$i] == $obj) {
				$index = $i;
				break;
			}
		}
		return $index;
	}
	
	/**
	 * set css style
	 * @param string $key
	 * @param string|array $value
	 * @param boolean $important
	 * @return lib_discuz3
	 * @author DisM!Ӧ������(dism.taobao.com)
	 * @date 2019-11-21 14:22
	 */
	protected function css($key, $value, $important = false) {
		if(is_array($value)) {
			$value = implode(" ", $value);
		}
		
		$this->style.=$key.': '.$value;
		
		if($important == false) {
			$this->style.=';';
		} else {
			$this->style.=' !important;';
		}
		return $this;
	}
	
	/**
	 * get px
	 * @param int $px
	 * @return string
	 * @author DisM!Ӧ������(dism.taobao.com)
	 * @date 2019-11-21 14:35
	 */
	protected function px($px) {
		return $px.'px';
	}
	protected function em($em) {
	    return $em.'em';
	}
	
	/**
	 * get hex color
	 * @param string $hex
	 * @return string
	 * @author DisM!Ӧ������(dism.taobao.com)
	 * @date 2019-11-21 20:17
	 */
	protected function hex($hex) {
		return '#'.$hex;
	}
	
	/**
	 * text align
	 * @param string $align
	 * @return lib_discuz3
	 * @author DisM!Ӧ������(dism.taobao.com)
	 * @date 2019-11-21 20:29
	 */
	protected function text_align($align) {
		$this->css('text-align', $align);
		if($align == 'justify') {
			return $this->css('text-justify', 'inter-ideograph')->css('-webkit-box-pack', 'justify')->css('-ms-flex-pack', 'justify')
					->css('-webkit-justify-content', 'space-between')->css('justify-content', 'space-between');
		}
		return $this;
	}
	
	/**
	 * get and clear css style
	 * @return string
	 * @author DisM!Ӧ������(dism.taobao.com)
	 * @date 2019-11-21 15:07
	 */
	protected function style() {
		$style = $this->style;
		$this->style = '';
		return $style;
	}
	
	/**
	 * gen html tag
	 * @param string $tag_name
	 * @param string $text
	 * @param string $style
	 * @return string
	 * @author DisM!Ӧ������(dism.taobao.com)
	 * @date 2019-11-21 15:57
	 */
	protected function html_both($tag_name, $content = '', $style = '') {
		$html = '<'.$tag_name;
		
		if(!empty($style)) {
			$html.=' style="'.$style.'"';
		}
		
		$html.='>';
		
		if(!empty($content)) {
		    if(is_array($content)) {
		        $num = count($content);
		        for($i = 0;$i < $num;$i++) {
		            $html.=$content[$i];
		        }
		    } else {
		        $html.=$content;
		    }
		}
		
		$html.='</'.$tag_name.'>';
		return $html;
	}
	
	/**
	 * gen div tag
	 * @param string $text
	 * @param string $style
	 * @return string
	 * @author DisM!Ӧ������(dism.taobao.com)
	 * @date 2019-11-21 15:59
	 */
	protected function div($content = '', $style = '') {
	    return $this->html_both('div', $content, $style);
	}
	
	/**
	 * gen span tag
	 * @param string $text
	 * @param string $style
	 * @return string
	 * @author DisM!Ӧ������(dism.taobao.com)
	 * @date 2019-11-21 16:00
	 */
	protected function span($content = '', $style = '') {
	    return $this->html_both('span', $content, $style);
	}
}