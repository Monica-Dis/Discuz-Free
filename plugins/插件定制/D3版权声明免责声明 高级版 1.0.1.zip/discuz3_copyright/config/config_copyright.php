<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/**
 * config file for copyright
 */
class config_copyright {
	// copyright_bg_color default value
	const BG_COLOR_DEFAULT = '#fbfbfb';
	// copyright_border_radius options
	const BORDER_RADIUS_OPTIONS = 'return array(0, 4, 6, 8, 10, 12, 14, 16, 18, 20);';
	// copyright_line_height default value
	const LINE_HEIGHT_DEFAULT = 30;
	// copyright_border_width options
	const BORDER_WIDTH_OPTIONS = 'return array(1, 2, 3, 4, 5, 6, 7, 8, 10);';
	// copyright_border_style options
	const BORDER_STYLE_OPTIONS = 'return array(\'solid\', \'dashed\', \'dotted\', \'double\');';
	// copyright_border_color default value
	const BORDER_COLOR_DEFAULT = '#e4e4e4';
	// copyright_margin_top default value
	const MARGIN_TOP_DEFAULT = 40;
	
	// definition tag for bbname
	const DEFINITION_TAG_BBNAME = '{bbname}';
	// definition tag for siteurl
	const DEFINITION_TAG_SITEURL = '{siteurl}';
	// definition tag for subject
	const DEFINITION_TAG_SUBJECT = '{subject}';
	
	// copyright_forum_rule show seleced
	const FORUM_RULE_SHOW_SELECTED = 1;
	// copyright_forum_rule show not seleced
	const FORUM_RULE_SHOW_NOT_SELECTED = 0;
	
	// copyright_title_fontsize and copyright_content_fontsize options
	const FONT_SIZE_OPTIONS = 'return array(12, 13, 14, 15, 16, 17, 18, 19, 20, 24);';
	// copyright_title_weight options
	const FONT_WEIGHT_OPTIONS = 'return array(400, 500, 600, 700, 800, 900, 300, 200, 100);';
	// copyright_title_align options
	const TITLE_ALIGN_OPTIONS = 'return array(\'left\', \'center\');';
	// copyright_title_color default value
	const TITLE_COLOR_DEFAULT = '#262626';
	
	// copyright_content_color default value
	const CONTENT_COLOR_DEFAULT = '#262626';
	// copyright_border_display options
	const BORDER_DISPLAY_OPTIONS = 'return array(\'none\', \'border-left\', \'border-right\', \'border-top\', \'border-bottom\');';
	// copyright_content_align options
	const CONTENT_ALIGN_OPTIONS = 'return array(\'justify\', \'center\', \'left\');';
}