<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once 'source/plugin/discuz3_copyright/config/config_copyright.php';
require_once 'source/plugin/discuz3_copyright/adapter/adapter_discuz3_discuz.php';

/**
 * global hook
 * @version 1.0.0
 * @author DisM!Ӧ������(dism.taobao.com)
 * @date 2019-11-18 00:12
 */
class plugin_discuz3_copyright extends adapter_discuz3_discuz {
    /**
     * get copyright info
     * @param bool $is_mobile
     * @return void|string
     * @author juston
     * @date 2019-11-29 15:40
     */
    protected function get_copyright_info($is_mobile) {
        $copyright_forum_rule = $this->plugin_var('copyright_forum_rule');
        $copyright_forums = $this->forums('copyright_forums');
        $fid = $this->fid();
        
        // show selected
        if($copyright_forum_rule == config_copyright::FORUM_RULE_SHOW_SELECTED) {
            if(!$this->has_empty($copyright_forums) && !in_array($fid, $copyright_forums)) {
                return;
            }
        } elseif ($copyright_forum_rule == config_copyright::FORUM_RULE_SHOW_NOT_SELECTED) {
            if($this->has_empty($copyright_forums) || in_array($fid, $copyright_forums)) {
                return;
            }
        } else {
            return;
        }
        
        // copyright title
        $copyright_title = $this->plugin_var('copyright_title');
        // copyright title align
        $copyright_title_align = $this->arr_val(eval(config_copyright::TITLE_ALIGN_OPTIONS), $this->plugin_var('copyright_title_align'));
        
        // copyright content
        $copyright_content = $this->plugin_var('copyright_content');
        // Remove all <br> for copyright content if has
        if($this->has_br_tag($copyright_content)) {
            $copyright_content = preg_replace('/(<\s*br\s*\/?\s*>)/', '', $copyright_content);
        }
        
        // discuz code to html for copyright content
        $copyright_content = $this->dzcode2html($copyright_content);
        // replace define tag for copyright content
        $copyright_content = strtr($copyright_content, array(
                config_copyright::DEFINITION_TAG_BBNAME => $this->bbname(),
                config_copyright::DEFINITION_TAG_SITEURL => $this->siteurl(),
                config_copyright::DEFINITION_TAG_SUBJECT => $this->forum_thread('subject')
        ));
        
        // Not fount br tag
        if(!$this->has_br_tag($copyright_content)) {
            $copyright_content = str_replace(PHP_EOL, '<br />', $copyright_content);
        }
        
        // bg color
        $copyright_bg_color = $this->plugin_var('copyright_bg_color', config_copyright::BG_COLOR_DEFAULT);
        // border radius
        $copyright_border_radius = $this->px($this->arr_val(eval(config_copyright::BORDER_RADIUS_OPTIONS), $this->plugin_var('copyright_border_radius', 0)));
        // line-height
        $copyright_line_height = $this->px($this->plugin_var('copyright_line_height', config_copyright::LINE_HEIGHT_DEFAULT));
        $copyright_line_height = $copyright_line_height > 0 ? $copyright_line_height : config_copyright::LINE_HEIGHT_DEFAULT;
        
        // border width
        $copyright_border_width = $this->arr_val(eval(config_copyright::BORDER_WIDTH_OPTIONS), $this->plugin_var('copyright_border_width', 0));
        // border style
        $copyright_border_style = $this->arr_val(eval(config_copyright::BORDER_STYLE_OPTIONS), $this->plugin_var('copyright_border_style', 0));
        // border color
        $copyright_border_color = $this->plugin_var('copyright_border_color', config_copyright::BORDER_COLOR_DEFAULT);
        // margin-top
        $copyright_margin_top = $this->plugin_var('copyright_margin_top', config_copyright::MARGIN_TOP_DEFAULT);
        $copyright_margin_top = $copyright_margin_top >= 0 ? $copyright_margin_top : config_copyright::MARGIN_TOP_DEFAULT;
        $copyright_margin_top = $this->px($copyright_margin_top);
        
        // copyright title color
        $copyright_title_color = $this->plugin_var('copyright_title_color', config_copyright::TITLE_COLOR_DEFAULT);
        // copyright title fontsize
        $copyright_title_fontsize = $this->px($this->arr_val(eval(config_copyright::FONT_SIZE_OPTIONS), $this->plugin_var('copyright_title_fontsize', 0)));
        // copyright title weight
        $copyright_title_weight = $this->arr_val(eval(config_copyright::FONT_WEIGHT_OPTIONS), $this->plugin_var('copyright_title_weight', 0));
        
        // border show
        $copyright_border_display = $this->selects('copyright_border_display');
        // Not seleced empty
        if(!in_array($this->arr_index(eval(config_copyright::BORDER_DISPLAY_OPTIONS), 'none'), $copyright_border_display)) {
            // foreach set border
            for($i = 0;$i < count($copyright_border_display);$i++) {
                $display = $this->arr_val(eval(config_copyright::BORDER_DISPLAY_OPTIONS), $copyright_border_display[$i]);
                $this->css($display, array($this->px($copyright_border_width), $copyright_border_style, $copyright_border_color));
            }
        }
        $container_style = $this->style();
        
        $copyright_content_color = $this->plugin_var('copyright_content_color', config_copyright::CONTENT_COLOR_DEFAULT);
        $copyright_content_fontsize = $this->px($this->arr_val(eval(config_copyright::FONT_SIZE_OPTIONS), $this->plugin_var('copyright_content_fontsize', 0)));
        $copyright_content_align = $this->arr_val(eval(config_copyright::CONTENT_ALIGN_OPTIONS), $this->plugin_var('copyright_content_align', 0));
        
        // replace copyright title tag
        $copyright_title = strtr($copyright_title, array(
                config_copyright::DEFINITION_TAG_BBNAME => $this->bbname(),
                config_copyright::DEFINITION_TAG_SITEURL => $this->siteurl()
        ));
        
        // copyright title to html
        $copyright_title = $this->dzcode2html($copyright_title);
        
        $html = '';
        include $this->template('copyright');
        return $html;
    }
}

/**
 * forum hook
 * @version 1.0.0
 * @author DisM!Ӧ������(dism.taobao.com)
 * @date 2019-11-18 00:13
 */
class plugin_discuz3_copyright_forum extends plugin_discuz3_copyright {
    /**
     * viewthread_modaction(X2.5)
     *
     * @author DisM!Ӧ������(dism.taobao.com)
     * @date 2019-11-18 00:22
     */
    public function viewthread_modaction() {
        return $this->get_copyright_info(false);
    }
}

/**
 * mobile forum hook
 * @version v1.0.0
 * @author juston
 * @date 2019-11-29 09:25
 */
class mobileplugin_discuz3_copyright_forum extends plugin_discuz3_copyright {
    /**
     * viewthread_bottom_mobile
     *
     * @author juston
     * @date 2019-11-29 09:27
     */
    public function viewthread_bottom_mobile() {
        return $this->get_copyright_info(true);
    }
}