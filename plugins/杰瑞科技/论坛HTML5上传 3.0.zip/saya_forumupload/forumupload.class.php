<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
 */
if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
class plugin_saya_forumupload {
	protected $maxattachsize, $imgexts, $allowuploadnum, $allowuploadtoday, $allowuploadsize;

	function __construct() {
		global $_G;
		require_once libfile( 'function/upload' );
		$swfconfig = getuploadconfig( $_G[ 'uid' ], $_G[ 'fid' ] );
		//print_r($swfconfig);
		$this->imgexts = str_replace( array( ';', '*.' ), array( ', ', '' ), $swfconfig[ 'imageexts' ][ 'ext' ] );
		$this->attachexts = $swfconfig[ 'attachexts' ][ 'ext' ] != "" ? explode( ";", str_replace( "*.", '', $swfconfig[ 'attachexts' ][ 'ext' ] ) ) : "";
		$this->allowuploadnum = $this->allowuploadtoday = TRUE;
		if ( $_G[ 'group' ][ 'allowpostattach' ] || $_G[ 'group' ][ 'allowpostimage' ] ) {
			if ( $_G[ 'group' ][ 'maxattachnum' ] ) {
				$allowuploadnum = $_G[ 'group' ][ 'maxattachnum' ] - getuserprofile( 'todayattachs' );
				$this->allowuploadnum = $allowuploadnum < 0 ? 0 : $allowuploadnum;
				if ( !$this->allowuploadnum ) {
					$this->allowuploadtoday = false;
				}
			}
			if ( $_G[ 'group' ][ 'maxsizeperday' ] ) {
				$allowuploadsize = $_G[ 'group' ][ 'maxsizeperday' ] - getuserprofile( 'todayattachsize' );
				$allowuploadsize = $allowuploadsize < 0 ? 0 : $allowuploadsize;
				if ( !$allowuploadsize ) {
					$this->allowuploadtoday = false;
				}
				$this->allowuploadsize = $allowuploadsize / 1048576 >= 1 ? round( ( $allowuploadsize / 1048576 ), 1 ) . 'MB': round( ( $allowuploadsize / 1024 ) ) . 'KB';
			}
		}
		$this->maxattachsize = $_G[ 'group' ][ 'maxattachsize' ] / 1048576 >= 1 ? round( ( $_G[ 'group' ][ 'maxattachsize' ] / 1048576 ), 1 ) . 'MB': round( ( $_G[ 'group' ][ 'maxattachsize' ] / 1024 ) ) . 'KB';
	}

	function global_footer() {
		global $_G;
		$poll=false;
		//file_put_contents(DISCUZ_ROOT."ul.txt",print_r(get_included_files(),true));
		if ( $_G[ 'setting' ][ 'version' ] == "X3.4" ) {
			$includfiles = get_included_files();
			foreach ( $includfiles as $value ) {
				//file_put_contents(DISCUZ_ROOT."ul.txt",print_r($value,true)."\r\n",FILE_APPEND);
				if ( strpos( strtolower( $value ), "table_forum_poll.php" ) ) {
					
					$poll = true;
					break;
				}
			}
		}

		$maxattachsize = $this->maxattachsize;
		$imgexts = $this->imgexts;
		$allowuploadnum = $this->allowuploadnum;
		$allowuploadtoday = $this->allowuploadtoday;
		$allowuploadsize = $this->allowuploadsize;
		$attachexts = $this->attachexts;
		$imgextsScriptArray = '"' . str_replace( ", ", '","', $imgexts ) . '"';
		if ( strpos( $_G[ 'PHP_SELF' ], "home.php" ) !== false ) {
			if ( $_GET[ 'mod' ] == "spacecp" && $_GET[ 'ac' ] == "upload" ) {
				include template( "saya_forumupload:album" );
				return $album;
			}elseif( $_GET[ 'mod' ] == "spacecp" && $_GET[ 'ac' ] == "blog" ){
				if ( $_G[ 'cache' ][ 'plugin' ][ 'saya_forumupload' ][ 'saya_forumupload_switch' ] ) {
					include template( "saya_forumupload:upload_www" );
					include template( "saya_forumupload:portalupload" );
					return $portaldouble . "\n" . $portalscript;
				} else {
					include template( "saya_forumupload:upload_www" );
					include template( "saya_forumupload:portalupload" );
					return $portalonly . "\n" . $portalscript;
				}
			}
			if ( $_GET['mod']=="follow" ){
				if ( $_G[ 'cache' ][ 'plugin' ][ 'saya_forumupload' ][ 'saya_forumupload_switch' ] ) {
					include template( "saya_forumupload:upload_www" );
					return $homedouble. "\n" . $script;
				} else {
					include template( "saya_forumupload:upload_www" );
					return $homeonly . "\n" . $script;
				}
			}
		}
		if ( $_GET[ 'mod' ] == 'post' && (($_GET[ 'action' ] == "newthread" && intval($_GET['special'])==1) || ($_GET['action']=="edit" && $poll))  ) {
			$hash = md5( substr( md5( $_G[ 'config' ][ 'security' ][ 'authkey' ] ), 8 ) . $_G[ 'uid' ] );
			if ( is_array( $attachexts ) && $attachexts[ 0 ] != "*" ) {
				$attachextsJSarray = '["' . implode( '","', $attachexts ) . '",' . $imgextsScriptArray . '];';
			} else {
				$attachextsJSarray = 'new Array();';
			}
			if ( $_G[ 'cache' ][ 'plugin' ][ 'saya_forumupload' ][ 'saya_forumupload_switch' ] ) {
				include template( "saya_forumupload:upload_www3_4" );
				return ( ( $_GET[ 'mod' ] == "post" ) ? $double : "" ) . "\n" . $script;
			} else {
				include template( "saya_forumupload:upload_www3_4" );
				return ( ( $_GET[ 'mod' ] == "post" ) ? $only : "" ) . "\n" . $script;
			}
		}
		if ( is_array( $attachexts ) && $attachexts[ 0 ] != "*" ) {
			$attachextsJSarray = '["' . implode( '","', $attachexts ) . '",' . $imgextsScriptArray . '];';
		} else {
			$attachextsJSarray = 'new Array();';
		}
		if ( $_G[ 'cache' ][ 'plugin' ][ 'saya_forumupload' ][ 'saya_forumupload_switch' ] ) {
			include template( "saya_forumupload:upload_www" );
			return ( ( $_GET[ 'mod' ] == "post" ) ? $double : "" ) . "\n" . $script;
		} else {
			include template( "saya_forumupload:upload_www" );
			return ( ( $_GET[ 'mod' ] == "post" ) ? $only : "" ) . "\n" . $script;
		}
	}
}
class plugin_saya_forumupload_forum extends plugin_saya_forumupload {

	function post_image_btn_extra() {
		global $_G;
		if ( $_G[ 'cache' ][ 'plugin' ][ 'saya_forumupload' ][ 'saya_forumupload_switch' ] ) {
			include template( "saya_forumupload:upload_www" );
			return $imgbtn;
		}
	}

	function post_image_tab_extra() {
		global $_G;
		$maxattachsize = $this->maxattachsize;
		$imgexts = $this->imgexts;
		$allowuploadnum = $this->allowuploadnum;
		$allowuploadtoday = $this->allowuploadtoday;
		$allowuploadsize = $this->allowuploadsize;
		$imgextsScriptArray = '"' . str_replace( ", ", '","', $imgexts ) . '"';
		include template( "saya_forumupload:upload_www" );
		return $imgdiv;
	}

	function post_attach_btn_extra() {
		global $_G;
		if ( $_G[ 'cache' ][ 'plugin' ][ 'saya_forumupload' ][ 'saya_forumupload_switch' ] ) {
			include template( "saya_forumupload:upload_www" );
			return $filebtn;
		}
	}

	function post_attach_tab_extra() {
		global $_G;
		$maxattachsize = $this->maxattachsize;
		$imgexts = $this->imgexts;
		$allowuploadnum = $this->allowuploadnum;
		$allowuploadtoday = $this->allowuploadtoday;
		$allowuploadsize = $this->allowuploadsize;
		$authkey = md5( substr( md5( $_G[ 'config' ][ 'security' ][ 'authkey' ] ), 8 ) . $_G[ 'uid' ] );
		include template( "saya_forumupload:upload_www" );
		return $filediv;
	}

	function viewthread_fastpost_btn_extra() {
		global $_G;
		$maxattachsize = $this->maxattachsize;
		$imgexts = $this->imgexts;
		$allowuploadnum = $this->allowuploadnum;
		$allowuploadtoday = $this->allowuploadtoday;
		$allowuploadsize = $this->allowuploadsize;
		$attachexts = $this->attachexts;
		include template( "saya_forumupload:upload_www" );
		if ( $_G[ 'cache' ][ 'plugin' ][ 'saya_forumupload' ][ 'saya_forumupload_switch' ] ) {
			return $fastpostdouble;
		} else {
			return $fastpostonly;
		}
	}

	function forumdisplay_fastpost_btn_extra() {
		global $_G;
		$maxattachsize = $this->maxattachsize;
		$imgexts = $this->imgexts;
		$allowuploadnum = $this->allowuploadnum;
		$allowuploadtoday = $this->allowuploadtoday;
		$allowuploadsize = $this->allowuploadsize;
		$attachexts = $this->attachexts;
		include template( "saya_forumupload:upload_www" );
		if ( $_G[ 'cache' ][ 'plugin' ][ 'saya_forumupload' ][ 'saya_forumupload_switch' ] ) {
			return $fastpostdouble;
		} else {
			return $fastpostonly;
		}
	}

}
//门户上传部分，门户上传为额外扩展，故检查文件存在与否
class plugin_saya_forumupload_portal extends plugin_saya_forumupload {
	function portalcp_middle() {
		global $_G;
		$maxattachsize = $this->maxattachsize;
		$imgexts = $this->imgexts;
		$allowuploadnum = $this->allowuploadnum;
		$allowuploadtoday = $this->allowuploadtoday;
		$allowuploadsize = $this->allowuploadsize;
		$attachexts = $this->attachexts;
		if ( file_exists( './source/plugin/saya_forumupload/template/portalupload.htm' ) ) {
			$imgextsScriptArray = '"' . str_replace( ", ", '","', $imgexts ) . '"';
			if ( is_array( $attachexts ) && $attachexts[ 0 ] != "*" ) {
				$attachextsJSarray = '["' . implode( '","', $attachexts ) . '",' . $imgextsScriptArray . '];';
			} else {
				$attachextsJSarray = 'new Array();';
			}
			if ( $_G[ 'cache' ][ 'plugin' ][ 'saya_forumupload' ][ 'saya_forumupload_switch' ] ) {
				include template( "saya_forumupload:upload_www" );
				include template( "saya_forumupload:portalupload" );
				return $portaldouble . "\n" . $portalscript;
			} else {
				include template( "saya_forumupload:upload_www" );
				include template( "saya_forumupload:portalupload" );
				return $portalonly . "\n" . $portalscript;
			}

		}
	}
}
class mobileplugin_saya_forumupload{
	function global_footer_mobile(){
		global $_G;
		if($_GET['mod']=="post"){
			$hash = md5( substr( md5( $_G[ 'config' ][ 'security' ][ 'authkey' ] ), 8 ) . $_G[ 'uid' ] );
			include template("saya_forumupload:upload_mobile");
			return $mobile;
		}
	}
}

class mobileplugin_saya_forumupload_forum extends mobileplugin_saya_forumupload{
	function post_bottom_mobile(){
		
	}
	
}
//From: Dism_taobao_com
?>