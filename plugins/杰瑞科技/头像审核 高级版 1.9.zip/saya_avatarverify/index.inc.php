<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
 */
if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
//loaducenter();
function func_is_base64($str){  
	return $str == base64_encode(base64_decode($str)) ? true : false;  
}
function onuploadavatar( $uid, $url ) {
	@header( "Expires: 0" );
	@header( "Cache-Control: private, post-check=0, pre-check=0, max-age=0", FALSE );
	@header( "Pragma: no-cache" );
	if ( empty( $uid ) || $uid == 0 ) {
		return "\u767B\u5F55\u72B6\u6001\u5931\u6548\uFF0C\u8BF7\u91CD\u65B0\u767B\u5F55";//FLASH的报错使用Unicode编码
	}
	if ( empty( $_FILES[ 'Filedata' ] ) ) {
		return "\u672A\u4E0A\u4F20\u4EFB\u4F55\u6587\u4EF6";
	}

	list( $width, $height, $type, $attr ) = getimagesize( $_FILES[ 'Filedata' ][ 'tmp_name' ] );
	if ( !in_array( $type, array( 1, 2, 3, 6 ) ) ) {
		@unlink( $_FILES[ 'Filedata' ][ 'tmp_name' ] );
		return "\u56FE\u7247\u6587\u4EF6\u7C7B\u578B\u4E0D\u6B63\u786E";
	}
	$imgtype = array( 1 => '.gif', 2 => '.jpg', 3 => '.png' );
	$filetype = $imgtype[ $type ];
	if ( !$filetype )$filetype = '.jpg';
	$tmpavatar = DISCUZ_ROOT . 'data/saya_avatarverifytmp/upload' . $uid . $filetype;
	file_exists( $tmpavatar ) && @unlink( $tmpavatar );
	if ( @copy( $_FILES[ 'Filedata' ][ 'tmp_name' ], $tmpavatar ) || @move_uploaded_file( $_FILES[ 'Filedata' ][ 'tmp_name' ], $tmpavatar ) ) {
		@unlink( $_FILES[ 'Filedata' ][ 'tmp_name' ] );
		list( $width, $height, $type, $attr ) = getimagesize( $tmpavatar );
		if ( $width < 10 || $height < 10 || $type == 4 ) {
			@unlink( $tmpavatar );
			return "\u56FE\u7247\u5206\u8FA8\u7387\u592A\u4F4E\u6216\u56FE\u7247\u6587\u4EF6\u7C7B\u578B\u4E0D\u6B63\u786E";
		}
	} else {
		@unlink( $_FILES[ 'Filedata' ][ 'tmp_name' ] );
		return "\u56FE\u7247\u65E0\u6CD5\u4E0A\u4F20";
	}
	$avatarurl = $url . 'data/saya_avatarverifytmp/upload' . $uid . $filetype;
	return $avatarurl;
}

function onrectavatar( $uid, $url ) {
	@header( "Expires: 0" );
	@header( "Cache-Control: private, post-check=0, pre-check=0, max-age=0", FALSE );
	@header( "Pragma: no-cache" );
	if ( $_GET[ 'base64' ] ) {
		header( "Content-type: text/html; charset=utf-8" );
		$imgInfo=base64_decode($_GET['avatar1']);
		$imgFilehead=substr($imgInfo,0,2);
		$strInfo = @unpack("C2chars", $imgFilehead);
		$typeCode = intval($strInfo['chars1'].$strInfo['chars2']);
		switch( $typeCode ){
 			case '7173':
				return 'gif';
				break;
			case '13780':
				return 'png';
				break;
			case '255216':
			default:
 				$type='jpg';
 				break;
		}
	} else {
		header( "Content-type: application/xml; charset=utf-8" );
		/*DisM_taobao-com*/if(file_exists(DISCUZ_ROOT . 'data/saya_avatarverifytmp/upload' . $uid .".png")){
			$type="png";
		}else/*DisM_taobao-com*/if(file_exists(DISCUZ_ROOT . 'data/saya_avatarverifytmp/upload' . $uid .".gif")){
			$type="gif";
		}else{
			$type="jpg";
		}
	}
	$dir = DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $uid;
	if ( !is_dir( $dir ) ) {
		@mkdir( $dir, 0777, true );
		@chmod( $dir, 0777 );
	}
	if ( $uid == 0 ) {
		return '<root><message type="error" value="-1" /></root>';
	}
	$avatartype = $_GET[ 'avatartype' ] == 'real' ? 'real' : 'virtual';
	$bigavatarfile = $dir . "/big.".$type;
	$middleavatarfile = $dir . '/middle.'.$type;
	$smallavatarfile = $dir . '/small.'.$type;
	$bigavatar = flashdata_decode( $_GET['avatar1'] );
	$middleavatar = flashdata_decode( $_GET['avatar2'] );
	$smallavatar = flashdata_decode( $_GET['avatar3']  );
	if ( !$bigavatar || !$middleavatar || !$smallavatar ) {
		return '<root><message type="error" value="-2" /></root>';
	}

	$success = 1;
	$fp = @fopen( $bigavatarfile, 'wb' );
	@fwrite( $fp, $bigavatar );
	@fclose( $fp );

	$fp = @fopen( $middleavatarfile, 'wb' );
	@fwrite( $fp, $middleavatar );
	@fclose( $fp );

	$fp = @fopen( $smallavatarfile, 'wb' );
	@fwrite( $fp, $smallavatar );
	@fclose( $fp );

	$biginfo = @getimagesize( $bigavatarfile );
	$middleinfo = @getimagesize( $middleavatarfile );
	$smallinfo = @getimagesize( $smallavatarfile );
	
	
	if ( !$biginfo || !$middleinfo || !$smallinfo || $biginfo[ 2 ] == 4 || $middleinfo[ 2 ] == 4 || $smallinfo[ 2 ] == 4 ||
		$biginfo[ 0 ] > 200 || $biginfo[ 1 ] > 250 || $middleinfo[ 0 ] > 120 || $middleinfo[ 1 ] > 120 || $smallinfo[ 0 ] > 48 || $smallinfo[ 1 ] > 48 ) {
		file_exists( $bigavatarfile ) && unlink( $bigavatarfile );
		file_exists( $middleavatarfile ) && unlink( $middleavatarfile );
		file_exists( $smallavatarfile ) && unlink( $smallavatarfile );
		$success = 0;
	}
	if(!C::t("#saya_avatarverify#saya_avatarverify#")->newverify($uid)){
		$success = 0;
	}
	$filetype = '.'.$type;
	@unlink( DISCUZ_ROOT . 'data/saya_avatarverifytmp/upload' . $uid . $filetype );

	if ( $_GET['base64'] ) {
		if ( $success ) {
			return "<script>window.parent.postMessage('success','*');</script>";
		} else {
			return "<script>window.parent.postMessage('failure','*');</script>";
		}
	} else {
		if ( $success ) {
			return '<?xml version="1.0" ?><root><face success="1"/></root>';
		} else {
			return '<?xml version="1.0" ?><root><face success="0"/></root>';
		}
	}
}

function flashdata_decode( $s ) {
	$r = '';
	if ( $_GET['base64'] ) {
		$r = base64_decode( $s );
	} else {
		$l = strlen( $s );
		for ( $i = 0; $i < $l; $i = $i + 2 ) {
			$k1 = ord( $s[ $i ] ) - 48;
			$k1 -= $k1 > 9 ? 7 : 0;
			$k2 = ord( $s[ $i + 1 ] ) - 48;
			$k2 -= $k2 > 9 ? 7 : 0;
			$r .= chr( $k1 << 4 | $k2 );
		}
	}
	return $r;
}
if ( submitcheck( 'a' ) ) {
	if(in_array($_GET[ 'a' ], array("uploadavatar","rectavatar"))){
		$a = "on" . $_GET[ 'a' ];
		echo $a( $_G[ 'uid' ], $_G[ 'siteurl' ] );
	}
}
//print_r( UC_KEY );
?>