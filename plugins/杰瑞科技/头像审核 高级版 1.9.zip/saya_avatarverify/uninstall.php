<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if ( !defined( 'IN_DISCUZ' ) || !defined( 'IN_ADMINCP' ) ) {
	exit( 'Access Denied' );
}
function delDir( $directory ) {
	if ( file_exists( $directory ) ) {
		if ( $dir_handle = @opendir( $directory ) ) {
			while ( $filename = readdir( $dir_handle ) ) {
				if ( $filename != '.' && $filename != '..' ) {
					$subFile = $directory . "/" . $filename;
					if ( is_dir( $subFile ) ) {
						delDir( $subFile );
					}
					if ( is_file( $subFile ) ) {
						unlink( $subFile );
					}
				}
			}
			closedir( $dir_handle );
			rmdir( $directory );
		}
	}
}

delDir( DISCUZ_ROOT . "data/saya_avatarverifytmp" );
$sql = <<<ENDSQL
DROP TABLE `cdb_saya_avatarverify`;
ENDSQL;
runquery( $sql );
$finish = TRUE;
?>