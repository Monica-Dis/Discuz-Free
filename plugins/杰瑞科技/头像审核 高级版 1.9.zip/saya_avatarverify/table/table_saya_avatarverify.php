<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_forum_thread.php 36278 2016-12-09 07:52:35Z nemohou $
 */

if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
class table_saya_avatarverify extends discuz_table {
	public function __construct() {
		$this->_table = 'saya_avatarverify';
		$this->_pk = 'id';
		parent::__construct();/*dism-taobao��com*/
	}
	public function newverify($uid){
		$exists=DB::fetch_first("SELECT * FROM %t WHERE uid=%d",array($this->_table,$uid));
		if($exists['uid']>0){
			DB::update($this->_table,array("timestamp"=>time()),array("uid"=>$exists['uid']));
			return true;
		}else{
			if(DB::insert($this->_table,array("uid"=>$uid,"timestamp"=>time()),true)>0){
				return true;
			}
		}
		return false;
	}
	public function getverify(){
		return DB::fetch_all("SELECT * FROM %t ORDER BY timestamp LIMIT 0,10",array($this->_table));
	}
	
	public function getpass($array){
		return DB::fetch_all("SELECT * FROM %t WHERE uid IN (%n)",array($this->_table,$array));
	}
	
	public function del($array){
		return DB::query("DELETE FROM %t WHERE uid IN (%n)",array($this->_table,$array));
	}
}
//From: Dism��taobao��com
?>