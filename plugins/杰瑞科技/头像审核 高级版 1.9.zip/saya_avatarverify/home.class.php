<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
 */
if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
class plugin_saya_avatarverify {}
//脚本嵌入点类
class plugin_saya_avatarverify_home extends plugin_saya_avatarverify {

	function spacecp_avatar_top() {
		global $_G;
		$verifygroup=unserialize($_G['cache']['plugin']['saya_avatarverify']['verifygroup']);
		if($_G[ 'setting' ][ 'version' ]!="X3.4" || $_GET['old']){
		loaducenter();
		$uc_avatarflash = uc_avatar( $_G[ 'uid' ], 'virtual', 0 );
		$srcindex = array_search( "src", $uc_avatarflash );
		$src = $uc_avatarflash[ $srcindex + 1 ];
		$apiPos = stripos( $src, "ucapi=" ) + 6;
		$qmPos=stripos($src,"?");
		$src=$_G[ 'siteurl' ]."source/plugin/saya_avatarverify/camera.swf".substr($src,$qmPos);
		$avatartypePos = stripos( $src, "&avatartype=" );
		$apilength = $avatartypePos - $apiPos;
		$apicontent = substr( $src, $apiPos, $apilength );
		$siteurl = "&ucapi=".urlencode( $_G[ 'siteurl' ] . "plugin.php?id=saya_avatarverify:index&formhash=".formhash()."&" );
		//$siteulr=$siteurl . "plugin.php?id=saya_avatarverify:index";
		$newSrc = str_replace( $apicontent,$siteurl , $src );
		$uc_avatarflash[ $srcindex + 1 ] = $newSrc;
		$jsEcho = "[\"" . implode( '","', $uc_avatarflash ) . "\"]";
		include template( "saya_avatarverify:avatarverify" );
			if(in_array($_G['groupid'],$verifygroup)){
				return $script;
			}else{
				return;
			}
		
		}
	}
	function spacecp_avatar_bottom(){
		global $_G;
		$formhash=formhash();
		$verifygroup=unserialize($_G['cache']['plugin']['saya_avatarverify']['verifygroup']);
		include template( "saya_avatarverify:avatarverify" );
		if($_G[ 'setting' ][ 'version' ]!="X3.4" || $_GET['old']){
			if(in_array($_G['groupid'],$verifygroup)){
				return $script2;
			}else{
				return;
			}
		}else{
			if(in_array($_G['groupid'],$verifygroup)){
				return $html5;
			}else{
				return;
			}
		}
	}
}
//From: Dism·taobao·com
?>