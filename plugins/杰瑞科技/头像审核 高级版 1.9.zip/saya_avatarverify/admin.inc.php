<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if ( !defined( 'IN_DISCUZ' ) || !defined( 'IN_ADMINCP' ) ) {
	exit( 'Access Denied' );
}
function is_https() {
	if ( !empty( $_SERVER[ 'HTTPS' ] ) && strtolower( $_SERVER[ 'HTTPS' ] ) !== 'off' ) {
		return array(443,"https://");
	} elseif ( isset( $_SERVER[ 'HTTP_X_FORWARDED_PROTO' ] ) && $_SERVER[ 'HTTP_X_FORWARDED_PROTO' ] === 'https' ) {
		return array(443,"https://");
	} elseif ( !empty( $_SERVER[ 'HTTP_FRONT_END_HTTPS' ] ) && strtolower( $_SERVER[ 'HTTP_FRONT_END_HTTPS' ] ) !== 'off' ) {
		return array(443,"https://");
	}
	return array(80,"http://");
}
function flashdata_encode( $s ) {
	$r = "";
	$l = strlen( $s );
	for ( $i = 0; $i < $l; $i++ ) {
		//return $s[$i];
		$k1 = ord( $s[ $i ] );
		$k2 = decbin( $k1 );
		//$k3=str_split($k2,4);
		$k3_0 = substr( $k2, 0, -4 );
		$k3_1 = substr( $k2, -4 );
		$k4_0 = base_convert( $k3_0, 2, 10 );
		$k4_1 = base_convert( $k3_1, 2, 10 );
		//return($k4_0);
		$k4_0 += $k4_0 > 9 ? 7 : 0;
		$k4_1 += $k4_1 > 9 ? 7 : 0;
		$k4_0 = chr( $k4_0 + 48 );
		$k4_1 = chr( $k4_1 + 48 );

		$r .= $k4_0 . $k4_1;
	}
	return $r;
}

function getusername( $uid ) {
	$userInfo = DB::fetch_first( 'SELECT username FROM %t WHERE uid = %d', array( 'common_member', $uid ) );
	$userInfo = $userInfo ? $userInfo : DB::fetch_first( 'SELECT username FROM %t WHERE uid=%d', array( "common_member_archive", $uid ) );
	$username = $userInfo[ 'username' ] ? $userInfo[ 'username' ] : false;
	return $username;
}
$formhash = formhash();
if ( $_GET[ 'act' ] ) {
	switch ( $_GET[ 'act' ] ) {
		case 'verify':
			if ( !submitcheck( 'formhash' ) ) {
				break;
			}
			loaducenter();
			
			foreach ( $_GET[ 'pass' ] as $value ) {
				$pass[] = intval( $value );
			}
			
			foreach ( $_GET['del'] as $value){
				$del[]=intval( $value );
			}
			$delArray= C::t( "#saya_avatarverify#saya_avatarverify#" )->getpass( $del );
			foreach($delArray as $value){
				/*DisM_taobao-com*/if(file_exists(DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $value['uid'] . "/big.gif")){
					$imgtype="gif";
				}else/*DisM_taobao-com*/if(file_exists(DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $value['uid'] . "/big.png")){
					$imgtype="png";
				}else{
					$imgtype="jpg";
				}
				if($_GET['delreason'][$value['uid']]!=""){
					$lang=lang("plugin/saya_avatarverify",'avatardel').lang("plugin/saya_avatarverify",'reasonis').$_GET['delreason'][$value['uid']];
				}else{
					$lang=lang("plugin/saya_avatarverify",'avatardel');
				}
				notification_add($value['uid'],'system',$lang,'', 1);
				unlink(DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $value['uid'] . "/small.{$imgtype}");
				unlink(DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $value['uid'] . "/middle.{$imgtype}");
				unlink(DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $value['uid'] . "/big.{$imgtype}");
			}
			$passArray = C::t( "#saya_avatarverify#saya_avatarverify#" )->getpass( $pass );
			foreach ( $passArray as $value ) {
				/*DisM_taobao-com*/if(file_exists(DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $value['uid'] . "/big.gif")){
					$imgtype="gif";
				}else/*DisM_taobao-com*/if(file_exists(DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $value['uid'] . "/big.png")){
					$imgtype="png";
				}else{
					$imgtype="jpg";
				}
				$uid = $value[ 'uid' ];
				$id = $value[ 'uid' ];
				loaducenter();
				$uc_avatarflash = uc_avatar( $uid, 'virtual', 0 );
				$avatarflash = explode( "?", $uc_avatarflash[ 7 ] );
				$AvatarSettingArray = explode( "&", $avatarflash[ 1 ] );
				foreach ( $AvatarSettingArray as $value ) {
					$valueArray = explode( "=", $value );
					$AvatarSettings[ $valueArray[ 0 ] ] = $valueArray[ 1 ];
				}
				$is_https=is_https();
				$port=$is_https[0];
				$ucapi=urldecode( $AvatarSettings[ 'ucapi' ] );
				$host=$ucapi;
				$url="";
				$host=str_replace(array("http://","https://"),array("",""),$host);
				if(strpos($ucapi,"/")){
					$h=explode("/",$ucapi);
					$host=$h[0];
					$h[0]="";
					$url=implode("/",$h);
				}
				if(strpos($host,":")){
					$p=explode(":",$host);
					$port=$p[1];
					$host=$p[0];
				}
				
				$url=$url."/index.php?m=user&inajax={$AvatarSettings['inajax']}&a=rectavatar&appid={$AvatarSettings['appid']}&input={$AvatarSettings['input']}&agent={$AvatarSettings['agent']}&avatartype={$AvatarSettings['avatartype']}";
				$PostUrl = $is_https[1] . str_replace(array("http://","https://"),array("",""),urldecode( $AvatarSettings[ 'ucapi' ] )) . "/index.php?m=user&inajax={$AvatarSettings['inajax']}&a=rectavatar&appid={$AvatarSettings['appid']}&input={$AvatarSettings['input']}&agent={$AvatarSettings['agent']}&avatartype={$AvatarSettings['avatartype']}";
				/*DisM_taobao-com*/if(file_exists(DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $uid . "/big.gif")){
					$imgtype="gif";
				}else/*DisM_taobao-com*/if(file_exists(DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $uid . "/big.png")){
					$imgtype="png";
				}else{
					$imgtype="jpg";
				}
				$file1 = file_get_contents( DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $uid . "/big.{$imgtype}" );
				$file2 = file_get_contents( DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $uid . "/middle.{$imgtype}" );
				$file3 = file_get_contents( DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $uid . "/small.{$imgtype}" );
				$avatar1 = flashdata_encode( $file1 );
				$avatar2 = flashdata_encode( $file2 );
				$avatar3 = flashdata_encode( $file3 );
				$post_data = array(
						"avatar1" => $avatar1,
						"avatar2" => $avatar2,
						"avatar3" => $avatar3,
						"urlReaderTS" => time() . "000"
					);

				
					$curl = curl_init();
					curl_setopt( $curl, CURLOPT_URL, $PostUrl );
					curl_setopt( $curl, CURLOPT_HEADER, 0 );
					curl_setopt( $curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); 
					curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );
					curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, false );
					curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, false );
					curl_setopt( $curl, CURLOPT_POST, 1 );
					curl_setopt( $curl, CURLOPT_POSTFIELDS, $post_data );
					$data = curl_exec( $curl );
					curl_close( $curl );
				
				if(strpos($data,'success="1"')){
					notification_add($uid,'system',lang("plugin/saya_avatarverify",'avatarpass'),'', 1);
					$del[]=intval($id);
					unlink(DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $uid . "/small.{$imgtype}");
					unlink(DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $uid . "/middle.{$imgtype}");
					unlink(DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $uid . "/big.{$imgtype}");
				}
				
				
			}
			C::t( "#saya_avatarverify#saya_avatarverify#" )->del($del);
			break;
	}
}
$all = C::t( "#saya_avatarverify#saya_avatarverify#" )->getverify();
if ( count( $all ) > 0 ) {
	foreach ( $all as $value ) {
		/*DisM_taobao-com*/if(file_exists(DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $value['uid'] . "/big.gif")){
					$imgtype="gif";
				}else/*DisM_taobao-com*/if(file_exists(DISCUZ_ROOT . "data/saya_avatarverifytmp/" . $value['uid'] . "/big.png")){
					$imgtype="png";
				}else{
					$imgtype="jpg";
				}
		$file=file_get_contents("./data/saya_avatarverifytmp/{$value['uid']}/middle.{$imgtype}");
		$notsafe=false;
		if(preg_match_all("/(\<\?[PHPphp]{3}[^\?\>]+[\?\>]{0,2})/",$file,$match)){
			$notsafe=true;
				foreach($match[0] as $value2){
					$trojan.=$value2;
				}
		}
		$file=file_get_contents("./data/saya_avatarverifytmp/{$value['uid']}/big.{$imgtype}");
		if(preg_match_all("/(\<\?[PHPphp]{3}[^\?\>]+[\?\>]{0,2})/",$file,$match)){
			$notsafe=true;
				foreach($match[0] as $value2){
					$trojan.=$value2;
				}
		}
		$file=file_get_contents("./data/saya_avatarverifytmp/{$value['uid']}/small.{$imgtype}");
		if(preg_match_all("/(\<\?[PHPphp]{3}[^\?\>]+[\?\>]{0,2})/",$file,$match)){
			$notsafe=true;
				foreach($match[0] as $value2){
					$trojan.=$value2;
				}
		}
		$r .= "<tr>
	<td class=\"pass\"><input type=\"checkbox\" name=\"pass[]\" value=\"{$value['uid']}\" /></td>
			<td class=\"delete\"><input type=\"checkbox\" name=\"del[]\" value=\"{$value['uid']}\" /><br style=\"display:none\"><span style=\"display:none;color:black;\">".lang("plugin/saya_avaterverify",'reason')."</span><input type=\"text\" name=\"delreason[{$value['uid']}]\" value=\"\" style=\"display:none\" /></td>
			<td  style=\"text-align: center\">" . getusername( $value[ 'uid' ] ) . "</td>
			<td>" . date( "Y-m-d H:i:s", $value[ 'timestamp' ] ) . "</td>
			<td>".($notsafe?htmlspecialchars($trojan):lang("plugin/saya_avatarverify",'safe'))."</td>
			<td><img src=\"./data/saya_avatarverifytmp/{$value['uid']}/middle.{$imgtype}\"</td>
	</tr>";
	}
}
include template( "saya_avatarverify:admin" );
?>