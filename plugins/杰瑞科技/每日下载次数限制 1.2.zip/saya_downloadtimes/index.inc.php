<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
if ( $_GET[ 'act' ] ) {
	switch ( $_GET[ 'act' ] ) {
		case 'confirmpay':
			if ( submitcheck( 'formhash' ) ) {
				if ( $_G[ 'uid' ] == 0 ) {
					showmessage( '', '', array(), array( 'alert' => 'error', 'msgtype' => 2, 'showdialog' => false, 'login' => true ), $custom = 0 );
					break;
				}
				if ( $_G[ 'cache' ][ 'plugin' ][ 'saya_downloadtimes' ][ 'fee' ] ) {
					$discount = ltrim( $_G[ 'cache' ][ 'plugin' ][ 'saya_downloadtimes' ][ 'fee' ] );
					$discount = rtrim( $discount, ';' );
					$discount = explode( ";", $discount );
				}
				foreach ( $discount as $val ) {
					$valA = explode( '=>', $val );
					$th[ $valA[ 0 ] ] = $valA[ 1 ];
				}
				if ( !$th[ $_GET[ 'th' ] ] ) {
					$return = "err";
					$error = 1;
				} else {
					if ( checklowerlimit( array( 'extcredits' . $_G[ "cache" ][ "plugin" ][ 'saya_downloadtimes' ][ 'credits' ] => $th[ $_GET[ 'th' ] ] ), $_G[ 'uid' ], -1, null, true ) === intval( $_G[ "cache" ][ "plugin" ][ 'saya_downloadtimes' ][ 'credits' ] ) ) {
						$return = "err";
						$error = 2;
					} else {
						$versionArray = array( "X2", "X2.5" );
						if ( in_array( $_G[ 'setting' ][ 'version' ], $versionArray ) ) {
							updatemembercount( $_G[ 'uid' ], array( $_G[ "cache" ][ "plugin" ][ 'saya_downloadtimes' ][ 'credits' ] => ( $th[ $_GET[ 'th' ] ] * -1 ) ), true, '', 0, str_replace("{n}",$_GET['th'],lang("plugin/saya_downloadtimes","countinfo")) );
						} else {
							updatemembercount( $_G[ 'uid' ], array( $_G[ "cache" ][ "plugin" ][ 'saya_downloadtimes' ][ 'credits' ] => ( $th[ $_GET[ 'th' ] ] * -1 ) ), true, '', 0,  str_replace("{n}",$_GET['th'],lang("plugin/saya_downloadtimes","countinfo")), lang("plugin/saya_downloadtimes","counttitle"),  str_replace("{n}",$_GET['th'],lang("plugin/saya_downloadtimes","countinfo")) );
						}
						C::t("#saya_downloadtimes#saya_downloadtimes_buylog")->buy($_G['uid'],$th[ $_GET[ 'th' ] ]." ".$_G['setting']["extcredits"][$_G['cache']['plugin']['saya_downloadtimes']['credits']]['title'],$_GET[ 'th' ]);
						$return = "confirmpay";
						$n = $_GET[ 'th' ];
					}
				}
				
				if(!defined("IN_MOBILE"))include template( "common/header" );
				//include template( "common/header" );
				include template( "saya_downloadtimes:returns" );
				echo $$return;
				if(!defined("IN_MOBILE"))include template( "common/footer" );
				//include template( "common/footer" );
				break;
			} else {
				if(!defined("IN_MOBILE"))include template( "common/header" );
				$error = 0;
				include template( "saya_downloadtimes:returns" );
				echo $err;
				if(!defined("IN_MOBILE"))include template( "common/footer" );
				break;
			}
		case 'paylog':
			if(!$_GET['logpage'] || intval($_GET['logpage'])<0) $page=1;
			else $page=intval($_GET['logpage']);
			$paylog=DB::fetch_all("SELECT * FROM %t WHERE uid=%d ORDER BY id DESC LIMIT %d,20",array("saya_downloadtimes_buylog",$_G['uid'],($page-1)*20));
			$rows=DB::fetch_first("SELECT count(1) AS rows FROM %t WHERE uid=%d",array("saya_downloadtimes_buylog",$_G['uid']));
			$pages=ceil($rows['rows']/20);
			if($pages>1){
				$nextpage=$page+1;
				$prevpage=$page-1;
				if($page==1){
					$p="<a href=\"#\" onClick=\"logpage({$nextpage})\" class=\"nxt\">".lang("plugin/saya_downloadtimes","nextpage")."</a>";
				}elseif($page==$pages){
					$p="<a href=\"#\" onClick=\"logpage({$prevpage})\" class=\"prev\">&nbsp;&nbsp;</a>";
				}else{
					$p="<a href=\"#\" onClick=\"logpage({$prevpage})\" class=\"prev\">&nbsp;&nbsp;</a>
					<a href=\"#\" onClick=\"logpage({$nextpage})\" class=\"nxt\">".lang("plugin/saya_downloadtimes","nextpage")."</a>";
				}
			}
			foreach($paylog as $value){
				$tr.="<tr>
				<td>{$value['times']}</td>
				<td>{$value['cost']}</td>
				<td>".date("Y-m-d H:i:s",$value['timestamp'])."</td>
				</tr>";
			}
			
			include template( "common/header" );
			include template( "saya_downloadtimes:returns" );
			if($_GET['w']=="show") echo $paylog;
			elseif($_GET['w']=="page") echo $logtable;
			include template( "common/footer" );
			break;
	}
}
//di'.'sm.t'.'aoba'.'o.com
?>