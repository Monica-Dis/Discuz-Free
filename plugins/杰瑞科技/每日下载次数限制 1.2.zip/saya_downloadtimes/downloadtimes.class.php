<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
class plugin_saya_downloadtimes {
	function attachment() {
		global $_G;
		if ( CURSCRIPT == 'forum' && CURMODULE == 'attachment' && $_GET[ 'aid' ] ) {
			$oldGet=$_GET;
			$groups_dayslimit = dunserialize( $_G[ 'cache' ][ 'plugin' ][ 'saya_downloadtimes' ][ 'dayslimit' ] );
			file_put_contents("download.txt",1);
			if ( $groups_dayslimit[ $_G[ 'groupid' ] ] != "" && $groups_dayslimit[ $_G[ 'groupid' ] ] > 0 ) {
				$svars = $_G[ 'cache' ][ 'plugin' ][ 'saya_downloadtimes' ];
				$groups = dunserialize( $svars[ 'groups' ] );
				$forums = dunserialize( $svars[ 'forums' ] );
				if ( in_array( $_G[ 'groupid' ], $groups ) ){$_GET=$oldGet; file_put_contents("download.txt",2); return;}
				@list( $aid, $k, $t, $uid, $tid ) = daddslashes( explode( '|', base64_decode( $_GET[ 'aid' ] ) ) );
				$aid = intval( $aid );
				$authk = substr( md5( $aid . md5( $_G[ 'config' ][ 'security' ][ 'authkey' ] ) . $t . $uid ), 0, 8 );
				if ( $k != $authk ){$_GET=$oldGet; file_put_contents("download.txt",3); return;}
				$attach = C::t( "forum_attachment" )->fetch( $aid );
				$attach = C::t( "forum_attachment_n" )->fetch( $attach[ 'tableid' ], $aid );
				if ( !$attach ){$_GET=$oldGet; file_put_contents("download.txt",4); return;}
				if ( $attach[ 'uid' ] == $_G[ 'uid' ] ){$_GET=$oldGet; file_put_contents("download.txt",5); return;}
				$tid = $attach[ 'tid' ];
				$thread = C::t( "forum_thread" )->fetch( $tid );
				if ( !in_array( $thread[ 'fid' ], $forums ) ){$_GET=$oldGet; file_put_contents("download.txt",6); return;}
				if ( $svars[ 'notfree' ] ) {
					if ( $attach[ 'price' ] == 0 ){$_GET=$oldGet; file_put_contents("download.txt",7); return;}
				}
				if ( $svars[ 'notimg' ] ) {
					if ( $attach[ 'isimage' ] == 1 ){$_GET=$oldGet; file_put_contents("download.txt",8); return;}
				}

				$userLog = C::t( "#saya_downloadtimes#saya_downloadtimes_userlog" )->gettimes( $_G[ 'uid' ], $groups_dayslimit[ $_G[ 'groupid' ] ] );
				$todaysfreeaid = unserialize( $userLog[ 'todaysfreeaid' ] );
				if ( isset( $todaysfreeaid[ $aid ] ) ){$_GET=$oldGet; file_put_contents("download.txt",9); return;}

				if ( C::t( "#saya_downloadtimes#saya_downloadtimes_userlog" )->download( $_G[ 'uid' ], $aid ) ){$_GET=$oldGet; file_put_contents("download.txt",10); return;}
				if ( !defined( "IN_MOBILE" ) ) {
					showmessage( "<span style=\"color:#FFF;display:none\"></span>" . str_replace( "{buyurl}", "home.php?mod=spacecp&ac=plugin&id=saya_downloadtimes:buyth", $svars[ 'notify' ] ), "", array(), array( "alert" => "error" ) );
					file_put_contents("download.txt",11);
				} else {
					showmessage( "<span style=\"color:#FFF;display:none\"></span>" . str_replace( "{buyurl}", "plugin.php?id=saya_downloadtimes:buyth&tid={$tid}", $svars[ 'notify' ] ), "", array(), array( "alert" => "error" ) );
				}
			}
		}
	}
}
class mobileplugin_saya_downloadtimes extends plugin_saya_downloadtimes {

}
class plugin_saya_downloadtimes_forum extends plugin_saya_downloadtimes {

}
class mobileplugin_saya_downloadtimes_forum extends plugin_saya_downloadtimes {

}
//di'.'sm.t'.'aoba'.'o.com
?>