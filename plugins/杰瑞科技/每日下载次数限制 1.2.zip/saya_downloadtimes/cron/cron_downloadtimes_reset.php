<?php
//cronname:cron
//week:
//day:
//hour:00
//minute:0

if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
loadcache('plugin');
$userlog = DB::fetch_all( "SELECT * FROM %t ORDER BY uid", array( "saya_downloadtimes_userlog" ) );
$groupset=dunserialize($_G['cache']['plugin']['saya_downloadtimes']['dayslimit']);
foreach ( $groupset as $key => $value ) {
		$grouptimes[ $key ] = $value;
}
foreach ( $userlog as $value ) {
	DB::update("saya_downloadtimes_userlog",array("freetimes"=>$grouptimes[$value['gid']],"todaysfreeaid"=>serialize(array())),array("uid"=>$value['uid']));
}
//您的计划任务脚本内容

?>