<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if ( !defined( 'IN_DISCUZ' ) || !defined( 'IN_ADMINCP' ) ) {
	exit( 'Access Denied' );
}

if(!$_GET['page'] || intval($_GET['page'])<0) $page=1;
else $page=intval($_GET['page']);
$pages=DB::fetch_first("SELECT count(1) AS `rows` FROM %t",array("saya_downloadtimes_buylog"));
$pages=ceil($pages['rows']/100);
if($pages>1){
	for($i=1;$i<=$pages;$i++){
		if($i==$page){
			$p.="<strong>$i</strong>&nbsp;";
		}else{
			$p.="<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$_GET['do']}&identifier=saya_downloadtimes&pmod=admin&page={$i}\"><strong>{$i}</strong></a>&nbsp;";
		}
	}
}
$paylog=DB::fetch_all("SELECT * FROM %t ORDER BY id DESC LIMIT %d,50",array("saya_downloadtimes_buylog",(($page-1)*100) ));
showtableheader();
showsubtitle(array("ID",lang("plugin/saya_downloadtimes","buyer"), lang("plugin/saya_downloadtimes","buytimes"), lang("plugin/saya_downloadtimes","cost"), lang("plugin/saya_downloadtimes","time"),"","ID",lang("plugin/saya_downloadtimes","buyer"), lang("plugin/saya_downloadtimes","buytimes"), lang("plugin/saya_downloadtimes","cost"), lang("plugin/saya_downloadtimes","time")),'header',array("","","","","","style=\"border-left:1px dotted #DEEFFB;\""));
for($i=0;$i<count($paylog);$i+=2){
	if($paylog[$i+1]){
		showtablerow('', array("","","","","","style=\"border-left:1px dotted #DEEFFB;\""), array($paylog[$i]['id'], $paylog[$i]['uid'], $paylog[$i]['times'], $paylog[$i]['cost'], date("Y-m-d H:i:s",$paylog[$i]['timestamp']),"", $paylog[$i+1]['id'], $paylog[$i+1]['uid'], $paylog[$i+1]['times'], $paylog[$i+1]['cost'], date("Y-m-d H:i:s",$paylog[$i+1]['timestamp']) ));
	}else{
		showtablerow('', array("","","","","","style=\"border-left:1px dotted #DEEFFB;\""), array($paylog[$i]['id'], $paylog[$i]['uid'], $paylog[$i]['times'], $paylog[$i]['cost'], date("Y-m-d H:i:s",$paylog[$i]['timestamp']),"", "", "", "", "", "" ));
	}
}
//print_r(1);

showtablefooter();
echo $p;
echo "<style>
.leftline{
border-left:1px;
}
</style>";
?>