<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
if($_G['uid']){
$groups_dayslimit=dunserialize($_G['cache']['plugin']['saya_downloadtimes']['dayslimit']);
if($groups_dayslimit[$_G['groupid']]!="" && $groups_dayslimit>0){
$lefttimes=C::t("#saya_downloadtimes#saya_downloadtimes_userlog")->gettimes($_G['uid'],$groups_dayslimit[$_G['groupid']]);

if($_G['cache']['plugin']['saya_downloadtimes']['fee']){
	$discount=ltrim($_G['cache']['plugin']['saya_downloadtimes']['fee']);
	$discount=rtrim($discount,';');
	$discount=explode(";",$discount);
}
$formhash=formhash();
$checked="checked";
$subscript="subscript";
foreach($discount as $val){
	$valA=explode('=>',$val);
	$moneySelect.='<label>
						<div class="moneyselecter '.$checked.'" onClick="changemoney(this)">
						<input type="radio" name="th" style="display: none;" value="'.$valA[0].'" '.$checked.' />
							'.$valA[0].lang("plugin/saya_downloadtimes","times")." ".$valA[1].$_G['setting']["extcredits"][$_G['cache']['plugin']['saya_downloadtimes']['credits']]['title'].'
							<div class="'.$subscript.'"></div>
						</div>
					</label>
					';
	$checked=$subscript='';
}
	$needbuy=true;
}else{
	$needbuy=false;
}
if(defined("IN_MOBILE")) include template("saya_downloadtimes:buyth");
}else{
	showmessage("","",array(),array("alert"=>"error","login"=>true));
}
//di'.'sm.t'.'aoba'.'o.com
?>