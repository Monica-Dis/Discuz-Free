<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_forum_thread.php 36278 2016-12-09 07:52:35Z nemohou $
 */

if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
class table_saya_downloadtimes_buylog extends discuz_table {
	public function __construct() {
		$this->_table = 'saya_downloadtimes_buylog';
		$this->_pk = 'id';
		parent::__construct();
	}
	public function checklogs($uid=null){
		if(!$uid) return DB::fetch_all("SELECT * FROM %t ORDER BY id DESC",array($this->_table));
		else return DB::fetch_all("SELECT * FROM %t WHERE uid=%d ORDER BY id DESC",array($this->_table,$uid));
	}
	public function buy($uid,$cost,$times){
		DB::insert($this->_table,array("uid"=>$uid,"cost"=>$cost,"times"=>$times,"timestamp"=>time()));
		C::t("#saya_downloadtimes#saya_downloadtimes_userlog#")->buy($uid,$times);
		return true;
	}
}
//From: Dism��taobao��com
?>