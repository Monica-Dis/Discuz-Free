<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_forum_thread.php 36278 2016-12-09 07:52:35Z nemohou $
 */

if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
class table_saya_downloadtimes_userlog extends discuz_table {
	public function __construct() {
		$this->_table = 'saya_downloadtimes_userlog';
		$this->_pk = 'uid';
		parent::__construct();
	}
	public function gettimes($uid,$grouptimes){
		global $_G;
		$db=DB::fetch_first("SELECT * FROM %t WHERE uid=%d",array($this->_table,$uid));
		if(!$db){
			$db=array("uid"=>$uid,"freetimes"=>$grouptimes,"buytimes"=>0,"todaysfreeaid"=>serialize(array()),"gid"=>$_G['groupid']);
			DB::insert($this->_table,$db);
		}elseif($_G['groupid']!=$db['gid']){
			DB::update($this->_table,array("gid"=>$_G['groupid']),array("uid"=>$uid));
		}
		return $db;
	}
	public function download($uid,$aid){
		$db=DB::fetch_first("SELECT * FROM %t WHERE uid=%d",array($this->_table,$uid));
		if(($freetimes=$db['freetimes']-1)>=0){
			$todaysfreeaid=unserialize($db['todaysfreeaid']);
			$todaysfreeaid[$aid]=time();
			$todaysfreeaid=serialize($todaysfreeaid);
			DB::update($this->_table,array("freetimes"=>$freetimes,"todaysfreeaid"=>$todaysfreeaid),array("uid"=>$uid));
			return true;
		}elseif(($buytimes=$db['buytimes']-1)>=0){
			$todaysfreeaid=unserialize($db['todaysfreeaid']);
			$todaysfreeaid[$aid]=time();
			$todaysfreeaid=serialize($todaysfreeaid);
			DB::update($this->_table,array("buytimes"=>$buytimes,"todaysfreeaid"=>$todaysfreeaid),array("uid"=>$uid));
			return true;
		}else{
			return false;
		}
	}
	public function buy($uid,$times){
		$db=DB::fetch_first("SELECT * FROM %t WHERE uid=%d",array($this->_table,$uid));
		DB::update($this->_table,array("buytimes"=>$db['buytimes']+$times),array("uid"=>$uid));
		return;
	}
}
//From: Dism��taobao��com
?>