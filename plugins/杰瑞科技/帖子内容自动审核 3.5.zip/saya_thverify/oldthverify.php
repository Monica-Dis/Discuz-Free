<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if ( !defined( 'IN_DISCUZ' ) || !defined( 'IN_ADMINCP' ) ) {
    exit( 'Access Denied' );
}
loadcache( "saya_oldth_breakpoint" );
loadcache( "plugin" );
if ( !$_GET[ 'acting' ] ) {

    showtips( lang( "plugin/saya_thverify", "a1" ) );
    showformheader( "plugins&operation=config&do={$_GET['do']}&identifier=saya_thverify&pmod=admin&act=oldth&acting=start&step=0" );
    showtableheader( lang( "plugin/saya_thverify", "a2" ) );
    showsetting( lang( "plugin/saya_thverify", "a3" ), 'qps', 20, 'number', false, false, lang( "plugin/saya_thverify", "a4" ) );
    showsetting( lang( "plugin/saya_thverify", "a5" ), array( 'start', 'end' ), array( date( 'Y-m-d' ), date( 'Y-m-d' ) ), 'daterange', false, false, lang( "plugin/saya_thverify", "a6" ) );
    $forums = DB::fetch_all( "SELECT fid,name FROM %t WHERE type='forum' AND status IN (0,1) ORDER BY fid ASC", array( 'forum_forum' ) );
    foreach ( $forums as $forum ) {
        $mselectArray[] = array( $forum[ 'fid' ], $forum[ 'name' ] . "(fid:{$forum['fid']})" );
    }
    showsetting( lang( "plugin/saya_thverify", "a19" ), array( 'forums[]', $mselectArray ), array(), 'mselect', false, false, lang( "plugin/saya_thverify", "a20" ) );
    if ( $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'pid' ] || $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'tableid' ] ) {
        showsetting( lang( "plugin/saya_thverify", "a7" ), 'continue', 0, 'radio', false, false, lang( "plugin/saya_thverify", "a8" ) );
    }
    showsubmit( 'submit', 'submit' );
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/
    ?>
<script type="text/javascript" src="static/js/calendar.js"></script>
<?php
} elseif ( $_GET[ 'acting' ] == 'start' && $_GET[ 'step' ] == 0 ) {

    if ( !submitcheck( 'qps' ) )cpmsg_error( lang( "plugin/saya_thverify", "a9" ) );
    if ( !$_GET[ 'forums' ] )cpmsg_error( lang( "plugin/saya_thverify", "a21" ) );
    if ( $_GET[ 'continue' ] != 1 ) {
        if ( ( $_GET[ 'start' ] && !preg_match( "/\d{4}-\d{2}-\d{2}/", $_GET[ 'start' ] ) ) || ( $_GET[ 'end' ] && !preg_match( "/\d{4}-\d{2}-\d{2}/", $_GET[ 'end' ] ) ) ) {
            cpmsg_error( lang( "plugin/saya_thverify", "a10" ) );
        }
        $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'qps' ] = $_GET[ 'qps' ];
        $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'start' ] = $_GET[ 'start' ];
        $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'end' ] = $_GET[ 'end' ];
        $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'forums' ] = $_GET[ 'forums' ];
        $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'pid' ] = 0;
        $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'tableid' ] = 0;
        savecache( "saya_oldth_breakpoint", $_G[ 'cache' ][ 'saya_oldth_breakpoint' ] );
    }

    $form = "<input type='hidden' name='qps' value='{$_G['cache']['saya_oldth_breakpoint']['qps']}'>";
    $form .= "<input type='hidden' name='start' value='{$_G['cache']['saya_oldth_breakpoint']['start']}'>";
    $form .= "<input type='hidden' name='end' value='{$_G['cache']['saya_oldth_breakpoint']['end']}'>";
    foreach ( $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'forums' ] as $value ) {
        $form .= "<input type='hidden' name='forums[]' value='{$value}'>";
    }
    $form .= "<input type='hidden' name='pid' value='{$_G['cache']['saya_oldth_breakpoint']['pid']}'>";
    loadcache( 'posttableids' );
    if ( $_G[ 'cache' ][ 'posttableids' ] ) {
        $form .= "<input type='hidden' name='tableid' value='" . $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'tableid' ] ? $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'tableid' ] : min($_G[ 'cache' ][ 'posttableids' ]) . "'>";
    }
    cpmsg( lang( "plugin/saya_thverify", "a11" ) . " 1-" . $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'qps' ], "action=plugins&operation=config&do={$_GET['do']}&identifier=saya_thverify&pmod=admin&act=oldth&acting=start&step=1", "loadingform", array(), $form );
} elseif ( $_GET[ 'acting' ] == 'start' && $_GET[ 'step' ] > 0 ) {
    if ( !submitcheck( 'qps' ) )cpmsg_error( lang( "plugin/saya_thverify", "a9" ) );
    $step = intval( $_GET[ 'step' ] );
    loadcache( 'posttableids' );
    $fids=implode(',',$_GET['forums']);
    if ( $_G[ 'cache' ][ 'posttableids' ] ) {
        if ( !in_array( $_GET[ 'tableid' ], $_G[ 'cache' ][ 'posttableids' ] ) ) {
            $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'tableid' ] = 0;
            $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'pid' ] = 0;
            savecache( "saya_oldth_breakpoint", $_G[ 'cache' ][ 'saya_oldth_breakpoint' ] );
            cpmsg( lang( "plugin/saya_thverify", "a12" ), '', 'succeed' );
        }
        $posts = DB::fetch_all( "SELECT * FROM %t WHERE pid>%d AND fid IN (%i) AND invisible=0 AND dateline BETWEEN %d AND %d ORDER BY pid ASC LIMIT 0,%d", array( intval( $_GET[ 'tableid' ] )>0?"forum_post_" . intval( $_GET[ 'tableid' ] ):'forum_post', intval( $_GET[ 'pid' ] ), $fids, $_GET[ 'start' ] ? strtotime( $_GET[ 'start' ] ) : 0, $_GET[ 'end' ] ? strtotime( $_GET[ 'end' ] ) : time(), $_GET[ 'qps' ] ) );
    } else {
        $posts = DB::fetch_all( "SELECT * FROM %t WHERE pid>%d AND fid IN (%i) AND invisible=0 AND dateline BETWEEN %d AND %d ORDER BY pid ASC LIMIT 0,%d", array( "forum_post", intval( $_GET[ 'pid' ] ), $fids, $_GET[ 'start' ] ? strtotime( $_GET[ 'start' ] ) : 0, $_GET[ 'end' ] ? strtotime( $_GET[ 'end' ] ) : time(), $_GET[ 'qps' ] ) );
    }
    if ( $posts ) {
        foreach ( $posts as $post ) {
            $post[ 'message' ] = preg_replace( array( "/\[attach\]\d+\[\/attach\]/", "/\[attachimg\]\d+\[\/attachimg\]/", "/\[img\][^\[]+\[\/img\]/" ), array( "", "", "" ), $post[ 'message' ] );
            if ( $post[ 'subject' ] ) {
                $content = "<{$post['subject']}>" . $post[ 'message' ];
            } else {
                $content = $post[ 'message' ];
            }
            if(trim($content)!='') {
                $verify_array = oldthverify( $content );
                if ( $verify_array[ 'conclusionType' ] != 1 ) {
                    DB::insert( "saya_thverify_oldthlog", array( 'content' => $content, 'conclusion' => diconv( $verify_array[ "conclusion" ], "UTF-8", CHARSET ), 'msg' => diconv( $verify_array[ 'data' ][ 0 ][ "msg" ], "UTF-8", CHARSET ), 'pid' => $post[ 'pid' ], 'tid'=>$post['tid'], 'fid'=>$post['fid'] ) );
                }
            }
            $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'pid' ] = $post[ 'pid' ];
            savecache( "saya_oldth_breakpoint", $_G[ 'cache' ][ 'saya_oldth_breakpoint' ] );
        }
    }
    if ( count( $posts ) < $_GET[ 'qps' ] ) {
        if ( $_G[ 'cache' ][ 'posttableids' ] ) {
            $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'tableid' ] += 1;
            if ( !in_array( $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'tableid' ], $_G[ 'cache' ][ 'posttableids' ] ) ) {
                $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'tableid' ] = 0;
                $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'pid' ] = 0;
                savecache( "saya_oldth_breakpoint", $_G[ 'cache' ][ 'saya_oldth_breakpoint' ] );
                cpmsg( lang( "plugin/saya_thverify", "a12" ), '', 'succeed' );
            } else {
                $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'pid' ] = 0;
                savecache( "saya_oldth_breakpoint", $_G[ 'cache' ][ 'saya_oldth_breakpoint' ] );
            }
        } else {
            $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'tableid' ] = 0;
            $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'pid' ] = 0;
            savecache( "saya_oldth_breakpoint", $_G[ 'cache' ][ 'saya_oldth_breakpoint' ] );
            cpmsg( lang( "plugin/saya_thverify", "a12" ), '', 'succeed' );
        }
    }
    $form = "<input type='hidden' name='qps' value='{$_G['cache']['saya_oldth_breakpoint']['qps']}'>";
    $form .= "<input type='hidden' name='start' value='{$_G['cache']['saya_oldth_breakpoint']['start']}'>";
    $form .= "<input type='hidden' name='end' value='{$_G['cache']['saya_oldth_breakpoint']['end']}'>";
    foreach ( $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'forums' ] as $value ) {
        $form .= "<input type='hidden' name='forums[]' value='{$value}'>";
    }
    $form .= "<input type='hidden' name='pid' value='{$_G['cache']['saya_oldth_breakpoint']['pid']}'>";
    if ( $_G[ 'cache' ][ 'posttableids' ] ) {
        $form .= "<input type='hidden' name='tableid' value='{$_G['cache']['saya_oldth_breakpoint']['tableid']}'>";
    }
    cpmsg( lang( "plugin/saya_thverify", "a11" ) . " " . $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'qps' ] * $step . "-" . $_G[ 'cache' ][ 'saya_oldth_breakpoint' ][ 'qps' ] * ( $step + 1 ), "action=plugins&operation=config&do={$_GET['do']}&identifier=saya_thverify&pmod=admin&act=oldth&acting=start&step=" . ( $step + 1 ), "loadingform", array(), $form );

}
//From: Dism��taobao��com
?>