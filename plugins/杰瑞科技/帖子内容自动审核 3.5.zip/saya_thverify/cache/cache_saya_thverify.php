<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function build_cache_plugin_saya_thverify() {
	global $_G;
	loadcache('plugin');
	$postUrl = 'https://aip.baidubce.com/oauth/2.0/token';
	$post_data[ 'grant_type' ] = 'client_credentials';
	$post_data[ 'client_id' ] = $_G[ 'cache' ][ 'plugin' ][ 'saya_thverify' ][ 'apikey' ];
	$post_data[ 'client_secret' ] = $_G[ 'cache' ][ 'plugin' ][ 'saya_thverify' ][ 'secretkey' ];
	$o = "";
	foreach ( $post_data as $k => $v ) {
		$o .= "$k=" . urlencode( $v ) . "&";
	}
	$curlPost = substr( $o, 0, -1 );
	$curl = curl_init(); //初始化curl
	curl_setopt( $curl, CURLOPT_URL, $postUrl ); //抓取指定网页
	curl_setopt( $curl, CURLOPT_HEADER, 0 ); //设置header
	curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 ); //要求结果为字符串且输出到屏幕上
	curl_setopt( $curl, CURLOPT_POST, 1 ); //post提交方式
	curl_setopt( $curl, CURLOPT_POSTFIELDS, $curlPost );
	curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, FALSE ); // https请求 不验证证书和hosts
	curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, FALSE );
	$data = curl_exec( $curl ); //运行curl
	curl_close( $curl );
	$access_json = $data;
	$access_array = json_decode( $access_json, true );
	$access_token = $access_array[ 'access_token' ];
	$expires_in = time() + $access_array[ 'expires_in' ];
	savecache( 'saya_thverify_cache', array( 'access_token' => $access_token, 'expires_in' => $expires_in ) );
	/*START 为图片自动审核和头像自动审核保存cache*/
	$saya_imgverify = C::t( "common_plugin" )->fetch_by_identifier( "saya_imgverify" );
	if ( $saya_imgverify[ 'available' ]==1 ) {
		savecache( 'saya_imgverify_cache', array( 'access_token' => $access_token, 'expires_in' => $expires_in ) );
	}
	$saya_avatarverify = C::t( "common_plugin" )->fetch_by_identifier( "saya_avatarverify" );
	if ( $saya_avatarverify[ 'available' ]==1 ) {
		loadcache( 'saya_avatarverify_cache' );
		if($_G['cache']['saya_avatarverify_cache']['access_token']){
			savecache( 'saya_avatarverify_cache', array( 'access_token' => $access_token, 'expires_in' => $expires_in ) );
		}//兼容非自动审核版的头像审核
	}
	/*END*/
	DB::update( 'saya_thverify', array( "access_token" => $access_token, 'expires_in' => $expires_in ), array( "id" => 1 ) );
}
//From: dis'.'m.tao'.'bao.com
?>