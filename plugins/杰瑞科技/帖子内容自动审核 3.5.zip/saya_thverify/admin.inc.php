<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if ( !defined( 'IN_DISCUZ' ) || !defined('IN_ADMINCP') ) {
	exit( 'Access Denied' );
}
loadcache('plugin');
if($_GET['act']=="log"){
	$page=intval($_GET['page'])>0?intval($_GET['page']):1;
    showformheader("plugins&operation=config&do={$_GET['do']}&identifier=saya_thverify&pmod=admin&act=test");
    showtableheader("VERIFY TEST");
    showsetting('CONTENT', 'content', '', 'text');
    showsubmit('submit','SUBMIT');
    showtablefooter(); /*dism·taobao·com*/
    showformfooter(); /*Dism_taobao-com*/
	showtableheader("Delete All Logs");
	showtablerow("",array("class=\"partition\""),array("<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$_GET['do']}&identifier=saya_thverify&pmod=admin&act=deletelog\"><strong>Click To Delete</strong></a>"));
	showtablefooter(); /*dism·taobao·com*/
	showtableheader();	showtablerow("",array("class=\"partition\"","class=\"partition\"","class=\"partition\"","class=\"partition\"","class=\"partition\"","class=\"partition\""),array("ID","PID","CONTENT","CONCLUSION","POSTER(UID)","DATA"));
	$DB=DB::fetch_all("SELECT * FROM %t ORDER BY id DESC LIMIT %d,30",array("saya_thverify_bdlog",($page-1)*30));
	foreach($DB as $value){
		showtablerow("",array("","","","","","class=\"datajsons\""),array($value['id'],$value['pid'],$value['content'],$value['conclusion'],$value['poster'],$value['data']));
	}
	showtablefooter(); /*dism·taobao·com*/
	$pages=DB::fetch_first("SELECT count(1) AS `rows` FROM %t",array("saya_thverify_bdlog"));
	$pages=ceil($pages['rows']/30);
if($pages>1){
	for($i=1;$i<=$pages;$i++){
		if($i==$page){
			$p.="<strong>$i</strong>&nbsp;";
		}else{
			$p.="<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$_GET['do']}&identifier=saya_thverify&pmod=admin&act=log&page={$i}\"><strong>{$i}</strong></a>&nbsp;";
		}
	}
}
	echo $p;
	?>
<script>
	var datajsons=document.getElementsByClassName("datajsons");
	for(var i = 0; i < datajsons.length; i++) {
    	datajsons[i].innerHTML=unescape(datajsons[i].innerHTML.replace(/\\u/g, "%u"));
	};
</script>
	<?php
}elseif($_GET['act']=="deletelog"){
	DB::query("truncate table %t",array("saya_thverify_bdlog"));
	cpmsg("Delete Success", '', 'succeed');
}elseif($_GET['act']=="test"){
    if(submitcheck('formhash')){
		loadcache( 'saya_thverify_cache' );
		loadcache( 'saya_imgverify_cache' ); //如果安装了图片审核则同时检查图片审核是否有access_token，有则直接用
		loadcache( 'saya_avatarverify_cache' ); //如果安装了头像自动审核则同时检查图片审核是否有access_token，有则直接用
		/*
			因百度access_token每天获取次数有限，三个插件共用同一个access_token可有效节约次数，减少访问延迟，优化用户体验
		*/
        $content=diconv($_GET['content'],CHARSET,"UTF-8");;
        if ( ( !$_G[ 'cache' ][ 'saya_thverify_cache' ][ 'access_token' ] || $_G[ 'cache' ][ 'saya_thverify_cache' ][ 'expires_in' ] - time() < 3600 * 24 ) && ( !$_G[ 'cache' ][ 'saya_imgverify_cache' ][ 'access_token' ] || $_G[ 'cache' ][ 'saya_imgverify_cache' ][ 'expires_in' ] - time() < 3600 * 24 ) && ( !$_G[ 'cache' ][ 'saya_avatarverify_cache' ][ 'access_token' ] || $_G[ 'cache' ][ 'saya_avatarverify_cache' ][ 'expires_in' ] - time() < 3600 * 24 ) ) {
			if ( !$_G[ 'cache' ][ 'plugin' ][ 'saya_thverify' ][ 'apikey' ] || !$_G[ 'cache' ][ 'plugin' ][ 'saya_thverify' ][ 'secretkey' ] ) cpmsg_error('NO KEY');
			$access_json = _request_accesstoken( $_G[ 'cache' ][ 'plugin' ][ 'saya_thverify' ][ 'apikey' ], $_G[ 'cache' ][ 'plugin' ][ 'saya_thverify' ][ 'secretkey' ] );
			$access_array = json_decode( $access_json, true );
			$access_token = $access_array[ 'access_token' ];
			$expires_in = time() + $access_array[ 'expires_in' ];
			savecache( 'saya_thverify_cache', array( 'access_token' => $access_token, 'expires_in' => $expires_in ) );
			loadcache( 'saya_thverify_cache' );
			DB::update( 'saya_thverify', array( "access_token" => $access_token, 'expires_in' => $expires_in ), array( "id" => 1 ) );
		}else{
           $access_token = ( $_G[ 'cache' ][ 'saya_thverify_cache' ][ 'access_token' ] && $_G[ 'cache' ][ 'saya_thverify_cache' ][ 'expires_in' ] - time() > 3600 * 24 ) ? $_G[ 'cache' ][ 'saya_thverify_cache' ][ 'access_token' ] : ( ( $_G[ 'cache' ][ 'saya_imgverify_cache' ][ 'access_token' ] && $_G[ 'cache' ][ 'saya_imgverify_cache' ][ 'expires_in' ] - time() > 3600 * 24 ) ? $_G[ 'cache' ][ 'saya_imgverify_cache' ][ 'access_token' ] : $_G[ 'cache' ][ 'saya_avatarverify_cache' ][ 'access_token' ] );
        }
        $verifyresult_json = _verify( $access_token, $content );
        $verifyresult_array = json_decode( $verifyresult_json, true );
        if(isset($verifyresult_array[ "error_code" ])){
            $DBconclusion=0;
		}else{
            $DBconclusion=diconv($verifyresult_array[ "conclusionType" ],"UTF-8",CHARSET);
		}
        DB::insert('saya_thverify_bdlog',array("pid"=>0,"conclusion"=>$DBconclusion,"poster"=>$_G['uid'],"data"=>diconv($verifyresult_json,"UTF-8",CHARSET),"content"=>$_GET['content']));
        cpmsg("POST SUCCESS", "action=plugins&operation=config&do={$_GET['do']}&identifier=saya_thverify&pmod=admin&act=log", 'succeed');
    }
}elseif($_GET['act']=='oldth'){
	require DISCUZ_ROOT."source/plugin/saya_thverify/oldthverify.php";
}elseif($_GET['act']=='oldthlog'){
	require DISCUZ_ROOT."source/plugin/saya_thverify/oldthverify_log.php";
}
function _request_accesstoken( $apiley, $secretkey ) {
	$postUrl = 'https://aip.baidubce.com/oauth/2.0/token';
	$post_data[ 'grant_type' ] = 'client_credentials';
	$post_data[ 'client_id' ] = $apiley;
	$post_data[ 'client_secret' ] = $secretkey;
	$o = "";
	foreach ( $post_data as $k => $v ) {
		$o .= "$k=" . urlencode( $v ) . "&";
	}
	$curlPost = substr( $o, 0, -1 );
	$curl = curl_init(); //初始化curl
	curl_setopt( $curl, CURLOPT_URL, $postUrl ); //抓取指定网页
	curl_setopt( $curl, CURLOPT_HEADER, 0 ); //设置header
	curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 ); //要求结果为字符串且输出到屏幕上
	curl_setopt( $curl, CURLOPT_POST, 1 ); //post提交方式
	curl_setopt( $curl, CURLOPT_POSTFIELDS, $curlPost );
	curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, FALSE ); // https请求 不验证证书和hosts
	curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, FALSE );
	$data = curl_exec( $curl ); //运行curl
	curl_close( $curl );
	return $data;
}

function _verify( $accesstoken, $content ) {
	$postUrl = 'https://aip.baidubce.com/rest/2.0/solution/v1/text_censor/v2/user_defined?access_token=' . $accesstoken;
	$post_data[ 'text' ] = $content;
	$o = "";
	foreach ( $post_data as $k => $v ) {
		$o .= "$k=" . urlencode( $v ) . "&";
	}
	$curlPost = substr( $o, 0, -1 );
	$curl = curl_init(); //初始化curl
	curl_setopt( $curl, CURLOPT_URL, $postUrl ); //抓取指定网页
	curl_setopt( $curl, CURLOPT_HEADER, 0 ); //设置header
	curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 ); //要求结果为字符串且输出到屏幕上
	curl_setopt( $curl, CURLOPT_POST, 1 ); //post提交方式
	curl_setopt( $curl, CURLOPT_POSTFIELDS, $curlPost );
	curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, FALSE ); // https请求 不验证证书和hosts
	curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, FALSE );
	$data = curl_exec( $curl ); //运行curl
	curl_close( $curl );
	return $data;
}

function oldthverify($content){
	global $_G;
	loadcache( 'saya_thverify_cache' );
		loadcache( 'saya_imgverify_cache' ); //如果安装了图片审核则同时检查图片审核是否有access_token，有则直接用
		loadcache( 'saya_avatarverify_cache' ); //如果安装了头像自动审核则同时检查图片审核是否有access_token，有则直接用
		/*
			因百度access_token每天获取次数有限，三个插件共用同一个access_token可有效节约次数，减少访问延迟，优化用户体验
		*/
        $content=diconv($content,CHARSET,"UTF-8");
        if ( ( !$_G[ 'cache' ][ 'saya_thverify_cache' ][ 'access_token' ] || $_G[ 'cache' ][ 'saya_thverify_cache' ][ 'expires_in' ] - time() < 3600 * 24 ) && ( !$_G[ 'cache' ][ 'saya_imgverify_cache' ][ 'access_token' ] || $_G[ 'cache' ][ 'saya_imgverify_cache' ][ 'expires_in' ] - time() < 3600 * 24 ) && ( !$_G[ 'cache' ][ 'saya_avatarverify_cache' ][ 'access_token' ] || $_G[ 'cache' ][ 'saya_avatarverify_cache' ][ 'expires_in' ] - time() < 3600 * 24 ) ) {
			if ( !$_G[ 'cache' ][ 'plugin' ][ 'saya_thverify' ][ 'apikey' ] || !$_G[ 'cache' ][ 'plugin' ][ 'saya_thverify' ][ 'secretkey' ] ) cpmsg_error('NO KEY');
			$access_json = _request_accesstoken( $_G[ 'cache' ][ 'plugin' ][ 'saya_thverify' ][ 'apikey' ], $_G[ 'cache' ][ 'plugin' ][ 'saya_thverify' ][ 'secretkey' ] );
			$access_array = json_decode( $access_json, true );
			$access_token = $access_array[ 'access_token' ];
			$expires_in = time() + $access_array[ 'expires_in' ];
			savecache( 'saya_thverify_cache', array( 'access_token' => $access_token, 'expires_in' => $expires_in ) );
			loadcache( 'saya_thverify_cache' );
			DB::update( 'saya_thverify', array( "access_token" => $access_token, 'expires_in' => $expires_in ), array( "id" => 1 ) );
		}else{
           $access_token = ( $_G[ 'cache' ][ 'saya_thverify_cache' ][ 'access_token' ] && $_G[ 'cache' ][ 'saya_thverify_cache' ][ 'expires_in' ] - time() > 3600 * 24 ) ? $_G[ 'cache' ][ 'saya_thverify_cache' ][ 'access_token' ] : ( ( $_G[ 'cache' ][ 'saya_imgverify_cache' ][ 'access_token' ] && $_G[ 'cache' ][ 'saya_imgverify_cache' ][ 'expires_in' ] - time() > 3600 * 24 ) ? $_G[ 'cache' ][ 'saya_imgverify_cache' ][ 'access_token' ] : $_G[ 'cache' ][ 'saya_avatarverify_cache' ][ 'access_token' ] );
        }
        $verifyresult_json = _verify( $access_token, $content );
        $verifyresult_array = json_decode( $verifyresult_json, true );
		return $verifyresult_array;
}
//From: Dism·taobao·com
?>