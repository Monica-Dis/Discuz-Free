<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if ( !defined( 'IN_DISCUZ' ) || !defined( 'IN_ADMINCP' ) ) {
    exit( 'Access Denied' );
}
$_GET['show']=$_GET['show']?$_GET['show']:10;
if(submitcheck('submit')){
    include_once libfile('function/delete');
    if($_GET['recycle']==1){
        deletepost($_GET['delpid'], 'pid',false, false, true);
    }else{
        deletepost($_GET['delpid'], 'pid');
    }
    $delpids=implode(',',$_GET['delpid']);
    $passpids=implode(',',$_GET['passpid']);
    DB::query("DELETE FROM %t WHERE pid IN (%i) OR pid IN (%i)",array("saya_thverify_oldthlog",$delpids?$delpids:0,$passpids?$passpids:0));
    cpmsg(lang("plugin/saya_thverify","a13"),"action=plugins&operation=config&do={$_GET['do']}&identifier=saya_thverify&pmod=admin&act=oldthlog&show={$_GET['show']}",'succeed');
}
$page=intval($_GET['page'])>0?intval($_GET['page']):1;
showformheader("plugins&operation=config&do={$_GET['do']}&identifier=saya_thverify&pmod=admin&act=oldthlog&show={$_GET['show']}");
showtableheader();
showtablerow('class="header"',array("class='partition'","class='partition' width='80px'","class='partition'","class='partition' width='100px'","class='partition' width='200px'","class='partition' width='100px'","class='partition' width='100px'"),array("PID",lang("plugin/saya_thverify","a22"),lang("plugin/saya_thverify","a14"),lang("plugin/saya_thverify","a15"),lang("plugin/saya_thverify","a16"),lang("plugin/saya_thverify","a17")."<br><input type=\"checkbox\" onChange=\"delall(this)\"/>",lang("plugin/saya_thverify","a18")."<br><input type=\"checkbox\"  onChange=\"passall(this)\"/>"));
$data=DB::fetch_all("SELECT * FROM %t ORDER BY id ASC LIMIT %d,%d",array("saya_thverify_oldthlog",($page-1)*intval($_GET['show']) ,intval($_GET['show'])));
foreach($data as $d){
    showtablerow("",array(),array($d['pid'],"<a href=\"forum.php?mod=redirect&goto=findpost&ptid={$d['tid']}&pid={$d['pid']}\" target=\"_blank\">".lang("plugin/saya_thverify","a23")."</a>",str_replace(array("<",">"),array("&lt;","&gt;"),$d['content']),$d['conclusion'],$d['msg'],"<input type='checkbox' name='delpid[]' value='{$d['pid']}'>","<input type='checkbox' name='passpid[]' value='{$d['pid']}'>"));
}
showtablerow("",array("colspan='7'"),array(lang("plugin/saya_thverify","a24")."<input type='checkbox' name='recycle' value='1'>"));
showsubmit('submit','submit');
showtablefooter(); /*dism��taobao��com*/
showformfooter(); /*Dism_taobao-com*/
$pagenum=DB::fetch_first("SELECT count(1) as `row` FROM %t",array("saya_thverify_oldthlog"));
$options=array(10,20,50,100);
foreach($options as $option){
    if($option==$_GET['show']) $checked="selected";
    else $checked='';
    $optionStr.="<option value='{$option}' {$checked}>{$option}</option>";
}
echo lang("plugin/saya_thverify","a25")."<select onChange=\"changeshows(this)\">{$optionStr}</select>";
echo multi($pagenum['row'],$_GET['show'],intval($_GET['page'])>0?intval($_GET['page']):1, ADMINSCRIPT."?action=plugins&operation=config&do={$_GET['do']}&identifier=saya_thverify&pmod=admin&act=oldthlog&show={$_GET['show']}");
?>
<script type="text/javascript">
    function delall(p){
        var dels=document.getElementsByName('delpid[]')
        if(p.checked){
            for(var i=0;i<dels.length;i++){
                dels[i].checked=true;
            }
        }else{
            for(var i=0;i<dels.length;i++){
                dels[i].checked=false;
            }
        }
    }
    function passall(p){
        var passs=document.getElementsByName('passpid[]')
        if(p.checked){
            for(var i=0;i<passs.length;i++){
                passs[i].checked=true;
            }
        }else{
            for(var i=0;i<passs.length;i++){
                passs[i].checked=false;
            }
        }
    }
    function changeshows(p){
        location.href='<?php echo ADMINSCRIPT."?action=plugins&operation=config&do={$_GET['do']}&identifier=saya_thverify&pmod=admin&act=oldthlog&show="; ?>'+p.value;
    }
</script>
<style>
    .pg{
        display: inline-block;
    }
</style>