<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}

class plugin_saya_thverify {
	public $needverify = false;

	function _request_accesstoken( $apiley, $secretkey ) {
		$postUrl = 'https://aip.baidubce.com/oauth/2.0/token';
		$post_data[ 'grant_type' ] = 'client_credentials';
		$post_data[ 'client_id' ] = $apiley;
		$post_data[ 'client_secret' ] = $secretkey;
		$o = "";
		foreach ( $post_data as $k => $v ) {
			$o .= "$k=" . urlencode( $v ) . "&";
		}
		$curlPost = substr( $o, 0, -1 );
		$curl = curl_init(); //初始化curl
		curl_setopt( $curl, CURLOPT_URL, $postUrl ); //抓取指定网页
		curl_setopt( $curl, CURLOPT_HEADER, 0 ); //设置header
		curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 ); //要求结果为字符串且输出到屏幕上
		curl_setopt( $curl, CURLOPT_POST, 1 ); //post提交方式
		curl_setopt( $curl, CURLOPT_POSTFIELDS, $curlPost );
		curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, FALSE ); // https请求 不验证证书和hosts
		curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, FALSE );
		$data = curl_exec( $curl ); //运行curl
		curl_close( $curl );
		return $data;
	}

	function _verify( $accesstoken, $content ) {
		$postUrl = 'https://aip.baidubce.com/rest/2.0/solution/v1/text_censor/v2/user_defined?access_token=' . $accesstoken;
		$post_data[ 'text' ] = $content;
		$o = "";
		foreach ( $post_data as $k => $v ) {
			$o .= "$k=" . urlencode( $v ) . "&";
		}
		$curlPost = substr( $o, 0, -1 );
		$curl = curl_init(); //初始化curl
		curl_setopt( $curl, CURLOPT_URL, $postUrl ); //抓取指定网页
		curl_setopt( $curl, CURLOPT_HEADER, 0 ); //设置header
		curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 ); //要求结果为字符串且输出到屏幕上
		curl_setopt( $curl, CURLOPT_POST, 1 ); //post提交方式
		curl_setopt( $curl, CURLOPT_POSTFIELDS, $curlPost );
		curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, FALSE ); // https请求 不验证证书和hosts
		curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, FALSE );
		$data = curl_exec( $curl ); //运行curl
		curl_close( $curl );
		return $data;
	}

	function _access_token() {
		loadcache( 'saya_thverify_cache' );
		loadcache( 'saya_imgverify_cache' ); //如果安装了图片审核则同时检查图片审核是否有access_token，有则直接用
		loadcache( 'saya_avatarverify_cache' ); //如果安装了头像自动审核则同时检查图片审核是否有access_token，有则直接用
		/*
			因百度access_token每天获取次数有限，三个插件共用同一个access_token可有效节约次数，减少访问延迟，优化用户体验
		*/
		global $_G;
		if ( ( !$_G[ 'cache' ][ 'saya_thverify_cache' ][ 'access_token' ] || $_G[ 'cache' ][ 'saya_thverify_cache' ][ 'expires_in' ] - time() < 3600 * 24 ) && ( !$_G[ 'cache' ][ 'saya_imgverify_cache' ][ 'access_token' ] || $_G[ 'cache' ][ 'saya_imgverify_cache' ][ 'expires_in' ] - time() < 3600 * 24 ) && ( !$_G[ 'cache' ][ 'saya_avatarverify_cache' ][ 'access_token' ] || $_G[ 'cache' ][ 'saya_avatarverify_cache' ][ 'expires_in' ] - time() < 3600 * 24 ) ) {
			$access_json = $this->_request_accesstoken( $_G[ 'cache' ][ 'plugin' ][ 'saya_thverify' ][ 'apikey' ], $_G[ 'cache' ][ 'plugin' ][ 'saya_thverify' ][ 'secretkey' ] );
			$access_array = json_decode( $access_json, true );
			$access_token = $access_array[ 'access_token' ];
			$expires_in = time() + $access_array[ 'expires_in' ];
			savecache( 'saya_thverify_cache', array( 'access_token' => $access_token, 'expires_in' => $expires_in ) );
		} else {
			$access_token = ( $_G[ 'cache' ][ 'saya_thverify_cache' ][ 'access_token' ] && $_G[ 'cache' ][ 'saya_thverify_cache' ][ 'expires_in' ] - time() > 3600 * 24 ) ? $_G[ 'cache' ][ 'saya_thverify_cache' ][ 'access_token' ] : ( ( $_G[ 'cache' ][ 'saya_imgverify_cache' ][ 'access_token' ] && $_G[ 'cache' ][ 'saya_imgverify_cache' ][ 'expires_in' ] - time() > 3600 * 24 ) ? $_G[ 'cache' ][ 'saya_imgverify_cache' ][ 'access_token' ] : $_G[ 'cache' ][ 'saya_avatarverify_cache' ][ 'access_token' ] );
		}
		return $access_token;
	}

	function _hasimg( $attacharray ) {
		if ( preg_match( "/\[img=?[\d,]*\][^\[]+\[\/img\]/", $_GET[ 'message' ] ) ) return true;
		foreach ( $attacharray as $aid => $content ) {
			if ( C::t( "forum_attachment_n" )->fetch( "aid:" . $aid, $aid, true ) ) return true;
		}
		return false;
	}

	function _verifycontent( $content ) {
		global $_G;
		if ( trim($content) == "" ) {
			return true;
		}
		$access_token = $this->_access_token();
		$verifyresult_json = $this->_verify( $access_token, diconv( $content, CHARSET, "UTF-8" ) );
		$verifyresult_array = json_decode( $verifyresult_json, true );
		if ( isset( $verifyresult_array[ "error_code" ] ) || $verifyresult_array[ "conclusionType" ] != 1 ) {
			if ( isset( $verifyresult_array[ "error_code" ] ) ) {
				$DBconclusion = 0;
				$DBdata = diconv( $verifyresult_array[ "error_msg" ], "UTF-8", CHARSET );
			} else {
				$DBdata = diconv( json_encode( $verifyresult_array[ 'data' ] ), "UTF-8", CHARSET );
				$DBconclusion = diconv( $verifyresult_array[ "conclusionType" ], "UTF-8", CHARSET );
			}
			if($_G['cache']['plugin']['saya_thverify']['bdlog']) DB::insert( 'saya_thverify_bdlog', array( "pid" => 0, "conclusion" => $DBconclusion, "poster" => $_G[ 'uid' ], "data" => $DBdata, "content" => $content ) );
			return false;
		} else {
			return true;
		}
		return false;
	}

	function post() {
		global $_G, $saya_needverify;
		$config = $_G[ 'cache' ][ 'plugin' ][ 'saya_thverify' ];
		$fids = unserialize( $config[ 'fids' ] );
		if ( !in_array( $_G[ 'fid' ], $fids ) ) return;
		$groups = unserialize( $config[ 'groups' ] );
		if ( !in_array( $_G[ 'groupid' ], $groups ) ) return;
		if ( $config[ 'hasimg' ] == 2 ) {
			$saya_imgverify = C::t( "common_plugin" )->fetch_by_identifier( "saya_imgverify" );
			if ( !$saya_imgverify[ 'available' ] ) {
				$config[ 'hasimg' ] = 1;
			}
			//如果未安装图片审核又在后台选择了通过图片审核确定图片审核状态的话，直接改为手动审核
		}

		if ( ( $_GET[ 'action' ] == 'newthread' || ( $_GET[ 'action' ] == 'edit' && (isset( $_GET[ 'readperm' ] ) || isset( $_GET[ 'price' ] ) || isset( $_GET[ 'tags' ] )) ) ) && $config[ 'thread' ] && $_GET[ 'message' ] ) {
			$message = "<" . $_GET[ "subject" ] . ">" . $_GET[ 'message' ];
			if ( count( $_GET[ 'attachnew' ] ) > 0 && $this->_hasimg( $_GET[ 'attachnew' ] ) ) {
				if ( $config[ 'hasimg' ] == 1 ) {
					$_G[ 'forum' ][ 'modnewposts' ] = 1;
					$_G[ 'group' ][ 'allowdirectpost' ] = 1;
					return;
				} elseif ( $config[ 'hasimg' ] == 0 ) {
					$message = preg_replace( array( "/\[attach\]\d+\[\/attach\]/", "/\[attachimg\]\d+\[\/attachimg\]/", "/\[img=?[\d,]*\][^\[]+\[\/img\]/" ), "", $message );
				} elseif ( $config[ 'hasimg' ] == 2 ) {
					$message = preg_replace( array( "/\[attach\]\d+\[\/attach\]/", "/\[attachimg\]\d+\[\/attachimg\]/", "/\[img=?[\d,]*\][^\[]+\[\/img\]/" ), "", $message );

					if ( $saya_needverify ) {
						//如果安装了图片审核则优先获取图片审核返回的审核状态，减少网络访问延迟，优化用户体验
						$_G[ 'forum' ][ 'modnewposts' ] = 1;
						$_G[ 'group' ][ 'allowdirectpost' ] = 1;
						return;
					}

				}
			}
			if ( !$this->_verifycontent( $message ) ) {
				$_G[ 'forum' ][ 'modnewposts' ] = 1;
				$_G[ 'group' ][ 'allowdirectpost' ] = 1;
				$saya_needverify = true;
				//提供给图片审核的状态
				return;
			}
		} elseif ( ( $_GET[ 'action' ] == 'reply' || ( $_GET[ 'action' ] == 'edit' && !isset( $_GET[ 'readperm' ] ) && !isset( $_GET[ 'price' ] ) ) ) && $config[ 'reply' ] && $_GET[ 'message' ] ) {
			$message = $_GET[ 'message' ];
			if ( count( $_GET[ 'attachnew' ] ) > 0 && $this->_hasimg( $_GET[ 'attachnew' ] ) ) {
				if ( $config[ 'hasimg' ] == 1 ) {
					$_G[ 'forum' ][ 'modnewposts' ] = 2;
					$_G[ 'group' ][ 'allowdirectpost' ] = 2;
					return;
				} elseif ( $config[ 'hasimg' ] == 0 ) {
					$message = preg_replace( array( "/\[attach\]\d+\[\/attach\]/", "/\[attachimg\]\d+\[\/attachimg\]/", "/\[img=[\d,]+\][^\[]+\[\/img\]/" ), "", $message );
				} elseif ( $config[ 'hasimg' ] == 2 ) {
					$message = preg_replace( array( "/\[attach\]\d+\[\/attach\]/", "/\[attachimg\]\d+\[\/attachimg\]/", "/\[img=[\d,]+\][^\[]+\[\/img\]/" ), "", $message );
					if ( $saya_needverify ) {
						//如果安装了图片审核则优先获取图片审核返回的审核状态，减少网络访问延迟，优化用户体验
						$_G[ 'forum' ][ 'modnewposts' ] = 2;
						$_G[ 'group' ][ 'allowdirectpost' ] = 2;
						return;
					}

				}
			}
			if ( !$this->_verifycontent( $message ) ) {
				$_G[ 'forum' ][ 'modnewposts' ] = 2;
				$_G[ 'group' ][ 'allowdirectpost' ] = 2;
				$saya_needverify = true;
				//提供给图片审核的状态
				return;
			}
		}
	}
}
class plugin_saya_thverify_forum extends plugin_saya_thverify {

}
class mobileplugin_saya_thverify extends plugin_saya_thverify {

}
class mobileplugin_saya_thverify_forum extends plugin_saya_thverify {

}
//脚本嵌入点类

?>