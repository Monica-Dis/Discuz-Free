<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if ( !defined( 'IN_DISCUZ' ) || !defined( 'IN_ADMINCP' ) ) {
	exit( 'Access Denied' );
}
function slang( $langkey ) {
	return lang( "plugin/saya_scan", $langkey );
}
$undeal = C::t( "#saya_scan#saya_scan_log#" )->fetch_last_undeal();
if ( !$_GET[ 'act' ] && !$undeal ) {
	//echo ;
	showtips( slang("tips"), 'tips', TRUE, slang("tipstitle") );
	$configs = C::t( "#saya_scan#saya_scan_config#" )->fetch();
	//print_r($configs);
	showformheader( "plugins&operation=config&do={$_GET['do']}&identifier=saya_scan&pmod=admin&act=scan&stap=1", '', 'cpform', 'post' );
	showtableheader( slang("scansetting") );
	showsetting( slang("mydangercode"), 'dangerstr', $configs[ 'dangertext' ], 'text', '', 0, slang("mydangercodetips") );
	showsetting( slang("scanfiletype"), 'filetype', $configs[ 'filetype' ], 'text', '', 0, slang("scanfiletypetips") );
	showsetting( slang("miner"), 'miner', 0, 'radio' ,"", 0,slang("minertips"));
	showsetting( slang("strong"), 'strong', 0, 'radio' );
	
	showsubmit( 'submit', slang("start") );
	showtablefooter();/*dis'.'m.tao'.'bao.com*/
	showformfooter();/*Dism��taobao��com*/
} elseif ( $_GET[ 'act' ] && ( !$undeal || $_GET[ 'act' ] == "makemd5" ) ) {
	switch ( $_GET[ 'act' ] ) {
		case 'scan':
			switch ( $_GET[ 'stap' ] ) {
				case '1':
					if ( $_GET[ 'filetype' ] == "" )cpmsg_error( slang("nofiletype") );
					$form = "
<input type=\"hidden\" name=\"filetype\" value=\"{$_GET['filetype']}\" \>
<input type=\"hidden\" name=\"strong\" value=\"{$_GET[ 'strong' ]}\" \>
<input type=\"hidden\" name=\"miner\" value=\"{$_GET[ 'miner' ]}\" \>
";
					C::t( "#saya_scan#saya_scan_config#" )->update( 'dangertext', $_GET[ 'dangerstr' ] );
					C::t( "#saya_scan#saya_scan_config#" )->update( 'filetype', $_GET[ 'filetype' ] );
					if ( $_GET[ 'dangerstr' ] ) {
						$form .= "<input type=\"hidden\" name=\"dangerstr\" value=\"{$_GET['dangerstr']}\" \>";
					}
					if($_GET['miner'] && $_GET['strong']){
						$msg=slang("minerandstrongon");
					}elseif($_GET['miner'] && !$_GET['strong']){
						$msg=slang("mineron");
					}elseif(!$_GET['miner'] && $_GET['strong']){
						$msg=slang("strongon");
					}elseif(!$_GET['miner'] && !$_GET['strong']){
						$msg=slang("started");
					}
					cpmsg( $msg, "action=plugins&operation=config&do={$_GET['do']}&identifier=saya_scan&pmod=admin&act=scan&stap=2", 'loadingform', array(), $form );
					break;
				case '2':
					set_time_limit( 0 );
					$suffix = $_GET[ 'filetype' ];
					//$dangerstr=str_replace(array(".","?","$","+","*","<",">","/","\\","{","}"."[","]","^","-","(",")"),array("\.","\?","\$","\+","\*","\<","\>","\/","\\\\","\{","\}"."\[","\]","\^","\-","\(","\)"),$_GET[ 'dangerstr' ]);
					$danger = 'eval|cmd|passthru|gzuncompress|ActiveXObject|shell|system|shell_exec|create_function|\$[A-Za-z]{1}[\w]{0,}|\$_{1}[A-Za-z0-9_]{1,}|assert';
					$miner="coinhive\.com|coin\-hive\.com|webmine\.cz|webmine\.pro|munero\.me|load\.jsecoin\.com|browsermine\.com|authedmine\.com|crypto-loot\.com|cryptaloot\.pro|ppoi\.org";
					$mydanger = ( $_GET[ 'dangerstr' ] ? str_replace( array( "\\", ".", "?", "$", "+", "*", "<", ">", "/", "{", "}" . "[", "]", "^", "-", "(", ")", ":" ), array( "\\\\", "\.", "\?", "\$", "\+", "\*", "\<", "\>", "\/", "\{", "\}" . "\[", "\]", "\^", "\-", "\(", "\)", "\:" ), $_GET[ 'dangerstr' ] ) : "" );
					$diy_danger = ( $_GET[ 'dangerstr' ] ? explode( "|", $_GET[ 'dangerstr' ] ) : array() );
					$php_highdanger = array( "eval", "cmd", "system", "shell_exec", "passthru" );
					$js_highdanger = "shell";
					$jkdir_num = $file_num = $danger_num = 0;

					function Safe_Check( $jkdir ) {
						//echo"$jkdir";
						global $danger, $suffix, $jkdir_num, $miner, $file_num, $danger_num, $php_highdanger, $js_highdanger, $diy_danger, $mydanger;
						$dh = opendir( $jkdir );
						while ( $file = readdir( $dh ) ) {
							$filename = $jkdir . '/' . $file;
							if ( @is_dir( $filename ) && $file != '.' && $file != '..' && $file != './..' ) {
								$jkdir_num++;
								Safe_Check( $filename );
							}
							if ( preg_match_all( "/\.($suffix)$/i", strtolower( $filename ), $filetype ) ) {
								//echo md5_file($filename);
								if ( !$_GET[ 'strong' ] ) {
									if ( $filemd5 = C::t( "#saya_scan#saya_scan_file_list#" )->getfilemd5( $filename ) ) {
										//echo md5_file($filename);
										if ( md5_file( $filename ) == $filemd5 ) {
											continue;
										}
									}
								}
								$str = '';
								$fp = @fopen( $filename, 'r' );
								if(!$fp){
									$style="color:yellow";
									$insert = array( $style, array( str_replace( str_replace( '\\', "/", DISCUZ_ROOT ), "./", $filename ), "NaN", "NaN", slang("warning"), 0, slang("noaccess"), $_GET[ 'filetype' ] ));
									showtablerow( '', array( 3 => "style=\"$style\"", 5 => "style=\"white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:400px;\"" ), array( str_replace( str_replace( '\\', "/", DISCUZ_ROOT ), "./", $filename ), "NaN", date( "Y-m-d H:i:s", filemtime( $filename ) ), slang("warning"), 0, slang("noaccess") ) );
									C::t( "#saya_scan#saya_scan_log#" )->insert( serialize( $insert ) );
								}
								$row = 1;
								$may_echo = false;
								while ( !feof( $fp ) ) {
									$str = fgets( $fp );
									if ( $filetype[ 1 ][ 0 ] == "php" ) {
										if ( preg_match_all( "/\<(script)/i", $str ) ) {
											$may_echo = true;
										}
										if ( preg_match_all( "/\<\/script/i", $str ) ) {
											$may_echo = false;
										}
									}
									//var_dump($str);
									//echo "<br/>";
									if ( preg_match_all( "/(($danger)\s*[\(]{1}[\s\S]*)/i", $str, $out ) ) {
										//var_dump($out);
										foreach ( $out[ 2 ] as $key => $value ) {
											if ( $filetype[ 1 ][ 0 ] == "php" && !$may_echo ) {
												if ( preg_match_all( '/(eval|cmd|system|shell_exec|passthru|\$[A-Za-z]{1}[\w]{0,}|\$_{1}[A-Za-z0-9_]{1,}|assert)/i', $out[ 1 ][ $key ] ) ) {
													if ( preg_match_all( '/(eval|cmd|system|shell_exec|passthru|\$[A-Za-z]{1}[\w]{0,}|\$_{1}[A-Za-z0-9_]{1,}|assert)\s*\({1}"{0,1}\$_(GET|POST|COOKIE)/i', $out[ 1 ][ $key ] ) ) {
														$style = "color:red";
														$d = slang("verydanger");
													} else {
														$style = "color:orange";
														$d = slang("danger");
													}
													//��Σ����
													//$style="color:red";
													//$d="��Σ";
												} elseif ( in_array( $value, $diy_danger ) ) {
													$style = "";
													$d = slang("diy_verydanger");
													//�Զ������
												} else {
													$style = "color:orange";
													$d = slang("normaldanger");
													//���ɴ���
												}
											} else {
												if ( $value == $js_highdanger ) {
													$style = "color:red";
													$d = slang("js_verydanger");
													//��Σ
												} elseif ( in_array( $value, $diy_danger ) ) {
													$style = "";
													$d = slang("diy_verydanger");
													//�Զ���
												} else {
													$style = "color:orange";
													$d = slang("normaldanger");
													//����
												}
											}
											$insert = array( $style, array( str_replace( str_replace( '\\', "/", DISCUZ_ROOT ), "./", $filename ), date( "Y-m-d H:i:s", filectime( $filename ) ), date( "Y-m-d H:i:s", filemtime( $filename ) ), $d, $row, htmlspecialchars( $out[ 1 ][ $key ] ) ), $_GET[ 'filetype' ] );
											showtablerow( '', array( 3 => "style=\"$style\"", 5 => "style=\"white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:400px;\"" ), array( str_replace( str_replace( '\\', "/", DISCUZ_ROOT ), "./", $filename ), date( "Y-m-d H:i:s", filectime( $filename ) ), date( "Y-m-d H:i:s", filemtime( $filename ) ), $d, $row, htmlspecialchars( $out[ 1 ][ $key ] ) ) );
											$danger_num++;
											C::t( "#saya_scan#saya_scan_log#" )->insert( serialize( $insert ) );
										}

									}
									if ( $_GET[ 'dangerstr' ] ) {
										if ( preg_match_all( "/(($mydanger))/i", $str, $out ) ) {
											//var_dump($out);
											foreach ( $out[ 2 ] as $key => $value ) {

												$style = "";
												$d = slang("diy_verydanger");
												//�Զ���
												$insert = array( $style, array( str_replace( str_replace( '\\', "/", DISCUZ_ROOT ), "./", $filename ), date( "Y-m-d H:i:s", filectime( $filename ) ), date( "Y-m-d H:i:s", filemtime( $filename ) ), $d, $row, htmlspecialchars( $out[ 1 ][ $key ] ) ), $_GET[ 'filetype' ] );
												showtablerow( '', array( 3 => "style=\"$style\"", 5 => "style=\"white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:400px;\"" ), array( str_replace( str_replace( '\\', "/", DISCUZ_ROOT ), "./", $filename ), date( "Y-m-d H:i:s", filectime( $filename ) ), date( "Y-m-d H:i:s", filemtime( $filename ) ), $d, $row, htmlspecialchars( $out[ 1 ][ $key ] ) ) );
												$danger_num++;
												C::t( "#saya_scan#saya_scan_log#" )->insert( serialize( $insert ) );
											}

										}
									}
									if( $_GET['miner'] ){
										if ( preg_match_all( "/(($miner))/i", $str, $out ) ) {
											//var_dump($out);
											foreach ( $out[ 2 ] as $key => $value ) {
												$style = "color:red";
												$d = slang("minerdanger");
												//�Զ���
												$insert = array( $style, array( str_replace( str_replace( '\\', "/", DISCUZ_ROOT ), "./", $filename ), date( "Y-m-d H:i:s", filectime( $filename ) ), date( "Y-m-d H:i:s", filemtime( $filename ) ), $d, $row, htmlspecialchars( $out[ 1 ][ $key ] ) ), $_GET[ 'filetype' ] );
												showtablerow( '', array( 3 => "style=\"$style\"", 5 => "style=\"white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:400px;\"" ), array( str_replace( str_replace( '\\', "/", DISCUZ_ROOT ), "./", $filename ), date( "Y-m-d H:i:s", filectime( $filename ) ), date( "Y-m-d H:i:s", filemtime( $filename ) ), $d, $row, htmlspecialchars( $out[ 1 ][ $key ] ) ) );
												$danger_num++;
												C::t( "#saya_scan#saya_scan_log#" )->insert( serialize( $insert ) );
											}

										}
									}
									$row++;
								}
								fclose( $fp );
								$file_num++;
							}
							
						}
					}
					
						showtips( slang("resulttip"), 'tips', TRUE, slang("tipstitle") );
						showtableheader( slang("scanresult") );
						showsubtitle( array( slang("filename"), slang("createtime"), slang("modifytime"), slang("dangerlevel"), slang("rows"), slang("dangercode") ) );
						Safe_Check( substr( str_replace( '\\', "/", DISCUZ_ROOT ), 0, -1 ) );
					C::t( "#saya_scan#saya_scan_scanlog#" )->insert( 1, str_replace(array("{filetype}","{filenum}","{dangernum}"),array($_GET['filetype'],$file_num,$danger_num),slang("logscanlang")) );
					if($danger_num==0){
						$form = "
<input type=\"hidden\" name=\"filetype\" value=\"{$_GET['filetype']}\" \>
";
							//cpmsg(slang("nodangerfile"), "action=plugins&operation=config&do={$_GET['do']}&identifier=saya_scan&pmod=admin&act=makemd5&stap=2", 'loadingform',array(),$form);
						
					}
					
						
						showformheader( "plugins&operation=config&do={$_GET['do']}&identifier=saya_scan&pmod=admin&act=makemd5&stap=1", '', 'cpform', 'post' );
						showhiddenfields( array( 'filetype' => $_GET[ 'filetype' ] ) );
						showsubmit( 'submit', slang("createfilemd5") );
						showformfooter();/*Dism��taobao��com*/
						showtablefooter();/*dis'.'m.tao'.'bao.com*/
					
					break;
			}
			break;
		case 'makemd5':
			switch ( $_GET[ 'stap' ] ) {
				case '1':
					$form = "
<input type=\"hidden\" name=\"filetype\" value=\"{$_GET['filetype']}\" \>
";
					cpmsg( slang("createingfilemd5"), "action=plugins&operation=config&do={$_GET['do']}&identifier=saya_scan&pmod=admin&act=makemd5&stap=2", 'loadingform', array(), $form );
					break;
				case '2':
					set_time_limit( 0 );
					$suffix = $_GET[ 'filetype' ];
					$jkdir_num=$file_num=0;
					function makemd5( $jkdir ) {
						global  $suffix, $jkdir_num, $file_num;
						$dh = opendir( $jkdir );
						while ( $file = readdir( $dh ) ) {
							$filename = $jkdir . '/' . $file;
							if ( @is_dir( $filename ) && $file != '.' && $file != '..' && $file != './..' ) {
								$jkdir_num++;
								makemd5( $filename );
							}
							if ( preg_match_all( "/\.($suffix)$/i", strtolower( $filename ), $filetype ) ) {
								if(C::t( "#saya_scan#saya_scan_file_list#" )->insert( $filename, md5_file( $filename ) )){
									$file_num++;
								}
							}

						}
					}
					C::t( "#saya_scan#saya_scan_log#" )->deal();
					makemd5( substr( str_replace( '\\', "/", DISCUZ_ROOT ), 0, -1 ) );
					C::t( "#saya_scan#saya_scan_scanlog#" )->insert( 2, str_replace(array("{filetype}","{filenum}"),array($_GET['filetype'],$file_num),slang("logmd5lang")) );
					cpmsg( slang("md5result"), "action=plugins&operation=config&do={$_GET['do']}&identifier=saya_scan&pmod=admin", 'succeed', array( 'count' => $file_num ) );
					break;
			}
			break;
	}
} elseif ( $undeal ) {
	showformheader( "plugins&operation=config&do={$_GET['do']}&identifier=saya_scan&pmod=admin&act=makemd5&stap=1", '', 'cpform', 'post' );
	showtips( slang("undealtips"), 'tips', TRUE, slang("tipstitle") );
	showtableheader( slang("lastscanresult") );
	showsubtitle( array( slang("filename"), slang("createtime"), slang("modifytime"), slang("dangerlevel"), slang("rows"), slang("dangercode") )  );
	foreach ( $undeal as $value ) {
		$table = unserialize( $value[ 'content' ] );
		$style = $table[ 0 ];
		showtablerow( '', array( 3 => "style=\"$style\"", 5 => "style=\"white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:400px;\"" ), $table[ 1 ] );
		$filetype = $table[ 2 ];
	}

	showhiddenfields( array( 'filetype' => $filetype ) );
	showsubmit( 'submit', slang("createfilemd5") );

	showtablefooter();/*dis'.'m.tao'.'bao.com*/
	showformfooter();/*Dism��taobao��com*/
}
//From: Dism��taobao��com
?>