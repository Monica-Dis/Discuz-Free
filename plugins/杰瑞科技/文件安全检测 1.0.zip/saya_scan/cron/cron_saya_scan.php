<?php
//cronname:cron
//week:
//day:
//hour:00
//minute:0

if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
function slang( $langkey ) {
	return lang( "plugin/saya_scan", $langkey );
}

set_time_limit( 0 );
$configs = C::t( "#saya_scan#saya_scan_config#" )->fetch();

$suffix=$configs[ 'filetype' ];
//您的计划任务脚本内容
					$danger = 'eval|cmd|passthru|gzuncompress|ActiveXObject|shell|system|shell_exec|create_function|\$[A-Za-z]{1}[\w]{0,}|\$_{1}[A-Za-z0-9_]{1,}|assert';
					$diy_danger =  array() ;
					$php_highdanger = array( "eval", "cmd", "system", "shell_exec", "passthru" );
					$js_highdanger = "shell";
					$file_num=$danger_num=$jkdir_num = 0;

					function Safe_Check( $jkdir,$danger, $suffix, $jkdir_num, $php_highdanger, $js_highdanger, $diy_danger,$file_num,$danger_num) {
						//echo"$jkdir";
						$dh = opendir( $jkdir );
						while ( $file = readdir( $dh ) ) {
							$filename = $jkdir . '/' . $file;
							if ( @is_dir( $filename ) && $file != '.' && $file != '..' && $file != './..' ) {
								$jkdir_num++;
								$array=Safe_Check( $filename,$danger, $suffix, $jkdir_num, $php_highdanger, $js_highdanger, $diy_danger,$file_num,$danger_num );
								$file_num=$array['file_num'];
								$danger_num=$array['danger_num'];
							}
							if ( preg_match_all( "/\.($suffix)$/i", strtolower( $filename ), $filetype ) ) {
								//echo md5_file($filename);
								if ( !$_GET[ 'strong' ] ) {
									if ( $filemd5 = C::t( "#saya_scan#saya_scan_file_list#" )->getfilemd5( $filename ) ) {
										//echo md5_file($filename);
										if ( md5_file( $filename ) == $filemd5 ) {
											continue;
										}
									}
								}
								$str = '';
								$fp = @fopen( $filename, 'r' );
								if(!$fp){
									$style="color:yellow";
									$insert = array( $style, array( str_replace( str_replace( '\\', "/", DISCUZ_ROOT ), "./", $filename ), "NaN", "NaN", slang("warning"), 0, slang("noaccess"), $_GET[ 'filetype' ] ));
									showtablerow( '', array( 3 => "style=\"$style\"", 5 => "style=\"white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:400px;\"" ), array( str_replace( str_replace( '\\', "/", DISCUZ_ROOT ), "./", $filename ), "NaN", date( "Y-m-d H:i:s", filemtime( $filename ) ), slang("warning"), 0, slang("noaccess") ) );
									C::t( "#saya_scan#saya_scan_log#" )->insert( serialize( $insert ) );
								}
								$row = 1;
								$may_echo = false;
								while ( !feof( $fp ) ) {
									$str = fgets( $fp );
									if ( $filetype[ 1 ][ 0 ] == "php" ) {
										if ( preg_match_all( "/\<(script)/i", $str ) ) {
											$may_echo = true;
										}
										if ( preg_match_all( "/\<\/script/i", $str ) ) {
											$may_echo = false;
										}
									}
									//var_dump($str);
									//echo "<br/>";
									if ( preg_match_all( "/(($danger)\s*[\(]{1}[\s\S]*)/i", $str, $out ) ) {
										//var_dump($out);
										foreach ( $out[ 2 ] as $key => $value ) {
											if ( $filetype[ 1 ][ 0 ] == "php" && !$may_echo ) {
												if ( preg_match_all( '/(eval|cmd|system|shell_exec|passthru|\$[A-Za-z]{1}[\w]{0,}|\$_{1}[A-Za-z0-9_]{1,}|assert)/i', $out[ 1 ][ $key ] ) ) {
													if ( preg_match_all( '/(eval|cmd|system|shell_exec|passthru|\$[A-Za-z]{1}[\w]{0,}|\$_{1}[A-Za-z0-9_]{1,}|assert)\s*\({1}"{0,1}\$_(GET|POST|COOKIE)/i', $out[ 1 ][ $key ] ) ) {
														$style = "color:red";
														$d = slang("verydanger");
													} else {
														$style = "color:orange";
														$d = slang("danger");
													}
												} else {
													$style = "color:orange";
													$d = slang("normaldanger");
												}
											} else {
												if ( $value == $js_highdanger ) {
													$style = "color:red";
													$d = slang("js_verydanger");
												} elseif ( in_array( $value, $diy_danger ) ) {
													$style = "";
													$d = slang("diy_verydanger");
												} else {
													$style = "color:orange";
													$d = slang("normaldanger");
												}
											}
											$insert = array( $style, array( str_replace( str_replace( '\\', "/", DISCUZ_ROOT ), "./", $filename ), date( "Y-m-d H:i:s", filectime( $filename ) ), date( "Y-m-d H:i:s", filemtime( $filename ) ), $d, $row, htmlspecialchars( $out[ 1 ][ $key ] ) ), $_GET[ 'filetype' ] );
											$danger_num++;
											C::t( "#saya_scan#saya_scan_log#" )->insert( serialize( $insert ) );
										}

									}
									$row++;
								}
								fclose( $fp );
								$file_num++;
							}
							
						}
						return array("file_num"=>$file_num,"danger_num"=>$danger_num);
					}
if(in_array("saya_scan",$_G['setting']['plugins']['available'])!==false){//判断插件开启，不开启则不执行扫描
$array=Safe_Check( substr( str_replace( '\\', "/", DISCUZ_ROOT ), 0, -1 ),$danger, $suffix, $jkdir_num, $php_highdanger, $js_highdanger, $diy_danger,$file_num,$danger_num);
$file_num=$array['file_num'];
$danger_num=$array['danger_num'];
C::t( "#saya_scan#saya_scan_scanlog#" )->insert( 3, str_replace(array("{filetype}","{filenum}","{dangernum}"),array($_GET['filetype'],$file_num,$danger_num),slang("logscanlang")) );
if($danger_num>0){
	manage_addnotify("system",0,array("langkey"=>"saya_scan:notify","time"=>date("Y-m-d H:i:s"),"filenum"=>$file_num,"dangernum"=>$danger_num,"filetype"=>$suffix));
}
}
//From: Dism·taobao·com
?>