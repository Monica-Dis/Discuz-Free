<?php
/**
 * 
 * DisM!出品 必属精品
 * DisM!应用中心所有 https://dism.Taobao.Com
 * 专业Discuz!应用插件、模板正版采购提供代下载服务、技术支持等全方位服务...
 * 我们致力于为站长提供正版Discuz!应用而努力
 * E-mail: dism.taobao@qq.com
 * 工作时间: 周一到周五早上09:00-12:00, 下午13:00-18:00, 晚上19:30-23:30(周六、日休息)
 * DisM!用户交流群: ①群778390776
 * 
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
 exit('Access Denied');
}
$sql = <<<SQLEND
CREATE TABLE IF NOT EXISTS `cdb_saya_scan_config` (
  `configname` text NOT NULL,
  `content` text NOT NULL
);

INSERT INTO `cdb_saya_scan_config` (`configname`, `content`) VALUES
('dangertext', ''),
('whitedomain', ''),
('filetype', 'php|js|htm'),
('whiteip', '');

CREATE TABLE IF NOT EXISTS `cdb_saya_scan_file_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` text NOT NULL,
  `lastmd5` text NOT NULL,
  `newmd5` text NOT NULL,
  `lasttime` int(11) NOT NULL DEFAULT '0',
  `newtime` int(11) NOT NULL DEFAULT '0',
  `createtime` int(11) NOT NULL DEFAULT '0',
  `modifytime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
);

CREATE TABLE IF NOT EXISTS `cdb_saya_scan_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logtime` int(11) NOT NULL,
  `content` text NOT NULL,
  `deal` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `deal` (`deal`)
);

CREATE TABLE IF NOT EXISTS `cdb_saya_scan_scanlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `ext` text NOT NULL,
  PRIMARY KEY (`id`)
);
SQLEND;
runquery($sql);
DB::update("common_cron",array("available"=>0),array("filename"=>"saya_scan:cron_saya_scan.php"));//关闭计划任务
$finish=TRUE;
?>