<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if ( !defined( 'IN_DISCUZ' ) || !defined( 'IN_ADMINCP' ) ) {
	exit( 'Access Denied' );
}
function slang( $langkey ) {
	return lang( "plugin/saya_scan", $langkey );
}

$page=($_GET['page'])?$_GET['page']:1;
$infos=C::t( "#saya_scan#saya_scan_scanlog#" )->fetch_all($page,50);
$pages=$infos[0];
unset($infos[0]);
showtableheader();/*Dism_taobao_com*/
showsubtitle( array( slang("logid"), slang("scantime"), slang("scantype"), slang("logext")) );
$typearray=array(1=>slang("manuscan"),2=>slang("md5create"),3=>slang("autoscan"));
foreach($infos as $value){
	showtablerow( "", array(), array($value['id'],date("Y-m-d H:i:s",$value['timestamp']),$typearray[$value['type']],$value['ext']));
}
if($pages>1){
	for($i=1;$i<=$pages;$i++){
		if($i==$page){
			$link.="<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$_GET['do']}&identifier=saya_scan&pmod=scanlog&page={$i}\" ><strong>{$i}</strong></a>&nbsp;";
		}else $link.="<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$_GET['do']}&identifier=saya_scan&pmod=scanlog&page={$i}\" ><strong>{$i}</strong></a>&nbsp;";
	}
	showtablerow("",array("colspan=\"4\""),array($link));
}
showtablefooter();/*dis'.'m.tao'.'bao.com*/
?>