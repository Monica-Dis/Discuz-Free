<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_forum_thread.php 36278 2016-12-09 07:52:35Z nemohou $
 */

if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
class table_saya_scan_log extends discuz_table {
	public function __construct() {
		$this->_table = 'saya_scan_log';
		$this->_pk = 'id';
		parent::__construct();/*dism-taobao��com*/
	}
	public function fetch_last_undeal(){
		return DB::fetch_all("SELECT * FROM %t WHERE deal=0",array($this->_table));
	}
	public function insert($data){
		DB::insert($this->_table,array('logtime'=>time(),'content'=>$data));
	}
	public function deal(){
		DB::update($this->_table,array("deal"=>1),array("deal"=>0));
		DB::delete($this->_table,array("deal"=>1));
	}
}
//From: Dism��taobao��com
?>