<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_forum_thread.php 36278 2016-12-09 07:52:35Z nemohou $
 */

if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
class table_saya_scan_scanlog extends discuz_table {
	public function __construct() {
		$this->_table = 'saya_scan_scanlog';
		$this->_pk = 'id';
		parent::__construct();/*dism-taobao��com*/
	}
	public function fetch_all($page=1,$limit=50){
		$pages=DB::fetch_first("SELECT count(1) AS count FROM %t",array($this->_table));
		$pages=ceil($pages['count']/$limit);
		$infos= DB::fetch_all("SELECT * FROM %t ORDER BY id DESC LIMIT %d,%d",array($this->_table,(($page-1)*$limit),$limit ));
		return array_merge(array($pages),$infos);
	}
	public function insert($type,$ext){
		DB::insert($this->_table,array('timestamp'=>time(),'type'=>$type,'ext'=>$ext));
	}
}
//From: Dism��taobao��com
?>