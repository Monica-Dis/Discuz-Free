<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_forum_thread.php 36278 2016-12-09 07:52:35Z nemohou $
 */

if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
class table_saya_scan_config extends discuz_table {
	public function __construct() {
		$this->_table = 'saya_scan_config';
		//$this->_pk = 'configname';
		parent::__construct();/*dism-taobao��com*/
	}
	public function fetch($configname=array()){
		if(count($configname)==0){
			$configs=DB::fetch_all("SELECT * FROM %t",array($this->_table));
			foreach($configs as $value){
				$return[$value['configname']]=$value['content'];
			}
		}else{
			$configs=DB::fetch_all("SELECT * FROM %t WHERE configname IN (%n)",array($this->_table,$configname));
			foreach($configs as $value){
				$return[$value['configname']]=$value['content'];
			}
		}
		return $return;
	}
	public function update($configname,$content){
		DB::update($this->_table,array('content'=>$content),array('configname'=>$configname));
	}
}
//From: Dism��taobao��com
?>