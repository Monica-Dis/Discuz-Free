<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_forum_thread.php 36278 2016-12-09 07:52:35Z nemohou $
 */

if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
class table_saya_scan_file_list extends discuz_table {
	public function __construct() {
		$this->_table = 'saya_scan_file_list';
		$this->_pk = 'id';
		parent::__construct();/*dism-taobao��com*/
	}
	public function insert($filename,$md5str){
		if( $fileInfo=DB::fetch_first("SELECT * FROM %t WHERE filename=%s",array($this->_table,$filename))){
			if($fileInfo['lastmd5']!=$md5str){
				DB::update($this->_table,array("lastmd5"=>$md5str),array($this->_pk=>$fileInfo['id']));
				return true;
			}else{
				return false;
			}
		}else{
			DB::insert($this->_table,array('filename'=>$filename,'lastmd5'=>$md5str));
			return true;
		}
	}
	public function getfilemd5($filename){
		if( $fileInfo=DB::fetch_first("SELECT * FROM %t WHERE filename=%s",array($this->_table,$filename))){
			return $fileInfo['lastmd5'];
		}else{
			return false;
		}
	}
}
//From: Dism��taobao��com
?>