<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class plugin_saya_fastreply {
    
}
class plugin_saya_fastreply_forum extends plugin_saya_fastreply {

	function viewthread_fastpost_content() {
		global $_G;
		$fid=$_G['fid'];
		$fastreply_forums=unserialize($_G['cache']['plugin']["saya_fastreply"]["fastreply_forums"]);
		$fastreply_usergroups=unserialize($_G['cache']['plugin']["saya_fastreply"]["fastreply_usergroups"]);
		if(!in_array($fid,$fastreply_forums) || !in_array($_G["groupid"],$fastreply_usergroups)){
			return '';
		}else{
			$saya_fastreply_reply="";
			
			$replay_content_array=preg_split("/[\r\n]{1,2}/",$_G['cache']['plugin']["saya_fastreply"]["fastreply_content"]);
			if(count($replay_content_array)>=5){
				$random_keys=array_rand($replay_content_array,5);
				for($i=0;$i<5;$i++){
					$saya_fastreply_reply.="<div style=\"display:inline-block; *display:inline; *zoom:1; padding: 2px 8px 2px 8px; cursor: pointer\" onClick=\"sayaQuery('#fastpostmessage').val(sayaQuery('#fastpostmessage').val()+sayaQuery(this).html())\">{$replay_content_array[$random_keys[$i]]}</div>
					";
				}
				$saya_fastreply_refresh="<a href=\"javascript:ajaxget('plugin.php?id=saya_fastreply:fastreply&divid=saya_fastreply_div', 'saya_fastreply_div', 'saya_fastreply_div','Plase Wait','inline','set_saya_reply_color()');\" style=\"color:#369\">".lang('plugin/saya_fastreply', 'changefastreply')."<img src=\"./static/image/common/refresh.png\" /></a>";
			}else{
				$saya_fastreply_refresh="";
				foreach($replay_content_array as $value){
					$saya_fastreply_reply.="<div style=\"display:inline-block; *display:inline; *zoom:1; padding: 2px 8px 2px 8px; cursor: pointer\" onClick=\"sayaQuery('#fastpostmessage').val(sayaQuery('#fastpostmessage').val()+sayaQuery(this).html())\">{$value}</div>
					";
				}
			}
			include template("saya_fastreply:fastreply");
			return $return;
		}
		
		
	}
	
	function post_infloat_top(){
		global $_G;
		$fid=$_G['fid'];
		$fastreply_forums=unserialize($_G['cache']['plugin']["saya_fastreply"]["fastreply_forums"]);
		$fastreply_usergroups=unserialize($_G['cache']['plugin']["saya_fastreply"]["fastreply_usergroups"]);
		if(!in_array($fid,$fastreply_forums) || !in_array($_G["groupid"],$fastreply_usergroups)){
			return '';
		}else{
			$saya_fastreply_reply="";
			
			$replay_content_array=preg_split("/[\r\n]{1,2}/",$_G['cache']['plugin']["saya_fastreply"]["fastreply_content"]);
			if(count($replay_content_array)>=5){
				$random_keys=array_rand($replay_content_array,5);
				for($i=0;$i<5;$i++){
					$saya_fastreply_reply.="<div style=\"display:inline-block; *display:inline; *zoom:1; padding: 2px 8px 2px 8px; cursor: pointer\" onClick=\"sayaQuery('#postmessage').val(sayaQuery('#postmessage').val()+sayaQuery(this).html())\">{$replay_content_array[$random_keys[$i]]}</div>
					";
				}
				$saya_fastreply_refresh="<a href=\"javascript:ajaxget('plugin.php?id=saya_fastreply:fastreply&divid=saya_fastreply_div_float', 'saya_fastreply_div_float', 'saya_fastreply_div_float','Plase Wait','inline','set_saya_reply_color()');\" style=\"color:#369\">".lang('plugin/saya_fastreply', 'changefastreply')."<img src=\"./static/image/common/refresh.png\" /></a>";
			}else{
				$saya_fastreply_refresh="";
				foreach($replay_content_array as $value){
					$saya_fastreply_reply.="<div style=\"display:inline-block; *display:inline; *zoom:1; padding: 2px 8px 2px 8px; cursor: pointer\" onClick=\"sayaQuery('#postmessage').val(sayaQuery('#postmessage').val()+sayaQuery(this).html())\">{$value}</div>
					";
				}
			}
			include template("saya_fastreply:fastreply_float");
			return $return;
		}
		
	}
	function viewthread_bottom(){
		global $_G;
		$fid=$_G['fid'];
		$fastreply_forums=unserialize($_G['cache']['plugin']["saya_fastreply"]["fastreply_forums"]);
		$fastreply_usergroups=unserialize($_G['cache']['plugin']["saya_fastreply"]["fastreply_usergroups"]);
		if(!in_array($fid,$fastreply_forums) || !in_array($_G["groupid"],$fastreply_usergroups)){
			return '';
		}else{
			if($_G['cache']['plugin']["saya_fastreply"]["fastreply_color"]=="auto"){
				$fastreply_color="sayaQuery(\"#nv\").getHexBackgroundColor();";
			}else{
				$fastreply_color="\"{$_G['cache']['plugin']["saya_fastreply"]["fastreply_color"]}\";";
			}
			include template("saya_fastreply:js");
			return $js;
		}
		
	}

}

class mobileplugin_saya_fastreply {
	
}

class mobileplugin_saya_fastreply_forum extends mobileplugin_saya_fastreply {
	function viewthread_postbottom_mobile_output(){
		global $postlist,$_G;
		$fid=$_G['fid'];
		$fastreply_forums=unserialize($_G['cache']['plugin']["saya_fastreply"]["fastreply_forums"]);
		$fastreply_usergroups=unserialize($_G['cache']['plugin']["saya_fastreply"]["fastreply_usergroups"]);
		if(!in_array($fid,$fastreply_forums) || !in_array($_G["groupid"],$fastreply_usergroups)){
			return array();
		}else{
			$saya_fastreply_reply="";
			
			$replay_content_array=preg_split("/[\r\n]{1,2}/",$_G['cache']['plugin']["saya_fastreply"]["fastreply_content"]);
			if(count($replay_content_array)>=5){
				$random_keys=array_rand($replay_content_array,5);
				for($i=0;$i<5;$i++){
					$saya_fastreply_reply.="<div style=\"display:inline-block; *display:inline; *zoom:1; padding: 2px 8px 2px 8px; cursor: pointer\" onClick=\"sayaQuery('#fastpostmessage').focus();sayaQuery('#fastpostmessage').val(sayaQuery('#fastpostmessage').val()+sayaQuery(this).html())\">{$replay_content_array[$random_keys[$i]]}</div>
					";
				}
				$saya_fastreply_refresh="<a href=\"javascript:regetfast();\" style=\"color:#369\">".lang('plugin/saya_fastreply', 'changefastreply')."<img src=\"./static/image/common/refresh.png\" /></a>";
			}else{
				$saya_fastreply_refresh="";
				foreach($replay_content_array as $value){
					$saya_fastreply_reply.="<div style=\"display:inline-block; *display:inline; *zoom:1; padding: 2px 8px 2px 8px; cursor: pointer\" onClick=\"sayaQuery('#fastpostmessage').focus();sayaQuery('#fastpostmessage').val(sayaQuery('#fastpostmessage').val()+sayaQuery(this).html())\">{$value}</div>
					";
				}
			}
			if($_G['cache']['plugin']["saya_fastreply"]["fastreply_color"]=="auto"){
				$fastreply_color="sayaQuery(\"#replyid\").getHexBackgroundColor();";
			}else{
				$fastreply_color="\"{$_G['cache']['plugin']["saya_fastreply"]["fastreply_color"]}\";";
			}
			include template("saya_fastreply:fastreply");
			include template("saya_fastreply:js");
			$postcount=count($postlist)-1;
			return array($postcount=>$return.$js);
		}
		return array();
		
	}
}
//From: Dism_taobao_com
?>