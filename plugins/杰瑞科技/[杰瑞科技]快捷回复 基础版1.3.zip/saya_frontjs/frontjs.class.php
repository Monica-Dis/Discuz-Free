<?php

//全局嵌入点类（必须存在）
class mobileplugin_saya_frontjs {
	function global_header_mobile(){
		return "
		<script type=\"text/javascript\" src=\"./source/plugin/saya_frontjs/sayaquery.js\"></script>
		<script type=\"text/javascript\">sayaQuery.noConflict();</script>";
	}
}
//全局嵌入点类（必须存在）
class plugin_saya_frontjs {
	function global_header(){
		return "
		<script type=\"text/javascript\" src=\"./source/plugin/saya_frontjs/sayaquery.js\"></script>
		<script type=\"text/javascript\">sayaQuery.noConflict();</script>";
	}
}
//From: Dism_taobao_com
?>