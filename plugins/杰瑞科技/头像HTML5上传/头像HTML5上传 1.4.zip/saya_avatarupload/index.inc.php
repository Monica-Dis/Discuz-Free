<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
function is_https() {
	if ( !empty( $_SERVER[ 'HTTPS' ] ) && strtolower( $_SERVER[ 'HTTPS' ] ) !== 'off' ) {
		return array(443,"https://");
	} elseif ( isset( $_SERVER[ 'HTTP_X_FORWARDED_PROTO' ] ) && $_SERVER[ 'HTTP_X_FORWARDED_PROTO' ] === 'https' ) {
		return array(443,"https://");
	} elseif ( !empty( $_SERVER[ 'HTTP_FRONT_END_HTTPS' ] ) && strtolower( $_SERVER[ 'HTTP_FRONT_END_HTTPS' ] ) !== 'off' ) {
		return array(443,"https://");
	}
	return array(80,"http://");
}
if ( $_POST ) {
	@header( "Expires: 0" );
	@header( "Cache-Control: private, post-check=0, pre-check=0, max-age=0", FALSE );
	@header( "Pragma: no-cache" );
	header( "Content-type: application/xml; charset=utf-8" );
	if ( !submitcheck( 'formhash' ) ) {
		echo '<root><message type="error" value="-4" /></root>';
	} else {
		if ( $_G[ 'uid' ] == 0 ) { //登录检查
			echo '<root><message type="error" value="-3" /></root>';
		} else {
			loaducenter();
			$uc_avatarflash = uc_avatar( $_G[ 'uid' ], 'virtual', 0 );
			$avatarflash = explode( "?", $uc_avatarflash[ 7 ] );
			$AvatarSettingArray = explode( "&", $avatarflash[ 1 ] );
			foreach ( $AvatarSettingArray as $value ) {
				$valueArray = explode( "=", $value );
				$AvatarSettings[ $valueArray[ 0 ] ] = $valueArray[ 1 ];
			}
			$is_https=is_https();
			$PostUrl=$is_https[1] . str_replace(array("http://","https://"),array("",""),urldecode( $AvatarSettings[ 'ucapi' ] )) . "/index.php?m=user&inajax={$AvatarSettings['inajax']}&a=rectavatar&appid={$AvatarSettings['appid']}&input=".uc_api_input("uid={$_G[ 'uid' ]}")."&agent=".md5($_SERVER['HTTP_USER_AGENT'])."&avatartype={$AvatarSettings['avatartype']}";
			//echo $PostUrl;
			$curl = curl_init();
			curl_setopt( $curl, CURLOPT_URL, $PostUrl );
			curl_setopt( $curl, CURLOPT_HEADER, 0 );
			curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );
			curl_setopt( $curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); 
			if($is_https[0]==443){
				curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, false); 
				curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, false);
			}
			curl_setopt( $curl, CURLOPT_POST, 1 );
			$post_data = array(
				"avatar3" => $_GET['avatar3'],
				"urlReaderTS"=>$_GET['urlReaderTS'],
				"avatar2"=>$_GET['avatar2'],
				"avatar1"=>$_GET['avatar1']
			);
			curl_setopt( $curl, CURLOPT_POSTFIELDS, $post_data );
			$data = curl_exec( $curl );
			curl_close( $curl );
			echo $data;
		}
	}
}else{
	header("location:{$_G['siteurl']}");//非法访问则重定向到首页
}
//From: dis'.'m.tao'.'bao.com
?>