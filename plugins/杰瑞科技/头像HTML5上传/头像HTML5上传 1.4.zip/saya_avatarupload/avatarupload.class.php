<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
//全局嵌入点类（必须存在）
class mobileplugin_saya_avatarupload {
	private
	function _is_https() {
		if ( !empty( $_SERVER[ 'HTTPS' ] ) && strtolower( $_SERVER[ 'HTTPS' ] ) !== 'off' ) {
			return array( 443, "https://" );
		} elseif ( isset( $_SERVER[ 'HTTP_X_FORWARDED_PROTO' ] ) && $_SERVER[ 'HTTP_X_FORWARDED_PROTO' ] === 'https' ) {
			return array( 443, "https://" );
		} elseif ( !empty( $_SERVER[ 'HTTP_FRONT_END_HTTPS' ] ) && strtolower( $_SERVER[ 'HTTP_FRONT_END_HTTPS' ] ) !== 'off' ) {
			return array( 443, "https://" );
		}
		return array( 80, "http://" );
	}

	function global_footer_mobile() {
		global $_G;
		if ( $_GET[ 'mod' ] == "space" ) {
			if ( !empty( $_SERVER[ 'HTTPS' ] ) && strtolower( $_SERVER[ 'HTTPS' ] ) !== 'off' ) {
				$H = "https://";
			} elseif ( isset( $_SERVER[ 'HTTP_X_FORWARDED_PROTO' ] ) && $_SERVER[ 'HTTP_X_FORWARDED_PROTO' ] === 'https' ) {
				$H = "https://";
			} elseif ( !empty( $_SERVER[ 'HTTP_FRONT_END_HTTPS' ] ) && strtolower( $_SERVER[ 'HTTP_FRONT_END_HTTPS' ] ) !== 'off' ) {
				$H = "https://";
			} else {
				$H = "http://";
			}
			$JumpURL = $H . $_SERVER[ 'HTTP_HOST' ] . $_SERVER[ 'PHP_SELF' ] . '?' . $_SERVER[ 'QUERY_STRING' ];
			loaducenter();
			$uc_avatarflash = uc_avatar( $_G[ 'uid' ], 'virtual', 0 );
			$avatarflash = explode( "?", $uc_avatarflash[ 7 ] );
			$AvatarSettingArray = explode( "&", $avatarflash[ 1 ] );
			foreach ( $AvatarSettingArray as $value ) {
				$valueArray = explode( "=", $value );
				$AvatarSettings[ $valueArray[ 0 ] ] = $valueArray[ 1 ];
			}
			$is_https = $this->_is_https();
			if ( $_G[ 'cache' ][ 'plugin' ][ 'saya_avatarupload' ][ 'crossorigin' ] ) {
				$PostUrl = "plugin.php?id=saya_avatarupload:index";
				$formhash = ',formhash:"' . formhash() . '"';
			} else {
				$PostUrl = $is_https[ 1 ] . str_replace( array( "http://", "https://" ), array( "", "" ), urldecode( $AvatarSettings[ 'ucapi' ] ) ) . "/index.php?m=user&inajax={$AvatarSettings['inajax']}&a=rectavatar&appid={$AvatarSettings['appid']}&input={$AvatarSettings['input']}&agent={$AvatarSettings['agent']}&avatartype={$AvatarSettings['avatartype']}";
				$formhash = '';
			}


			if ( in_array( "saya_avatarverify", $_G[ 'setting' ][ 'plugins' ][ 'available' ] ) !== false ) { //检查头像审核是否开启，开启则接入
				$verifygroup = unserialize( $_G[ 'cache' ][ 'plugin' ][ 'saya_avatarverify' ][ 'verifygroup' ] );
				if ( in_array( $_G[ 'groupid' ], $verifygroup ) ) {
					$PostUrl = $_G[ 'siteurl' ] . "plugin.php?id=saya_avatarverify:index&formhash=" . formhash() . "&m=user&inajax={$AvatarSettings['inajax']}&a=rectavatar&appid={$AvatarSettings['appid']}&input={$AvatarSettings['input']}&agent={$AvatarSettings['agent']}&avatartype={$AvatarSettings['avatartype']}";
					$needvatarverify=true;
				}
			}
			include template( "saya_avatarupload:avatarupload" );
			return $mobile;
		}
	}
}
//全局嵌入点类（必须存在）
class plugin_saya_avatarupload {}
//脚本嵌入点类
class plugin_saya_avatarupload_home extends plugin_saya_avatarupload {
	private
	function _is_https() {
		if ( !empty( $_SERVER[ 'HTTPS' ] ) && strtolower( $_SERVER[ 'HTTPS' ] ) !== 'off' ) {
			return array( 443, "https://" );
		} elseif ( isset( $_SERVER[ 'HTTP_X_FORWARDED_PROTO' ] ) && $_SERVER[ 'HTTP_X_FORWARDED_PROTO' ] === 'https' ) {
			return array( 443, "https://" );
		} elseif ( !empty( $_SERVER[ 'HTTP_FRONT_END_HTTPS' ] ) && strtolower( $_SERVER[ 'HTTP_FRONT_END_HTTPS' ] ) !== 'off' ) {
			return array( 443, "https://" );
		}
		return array( 80, "http://" );
	}

	function spacecp_avatar_top() {
		global $_G;
		if ( $_G[ 'setting' ][ 'version' ] != "X3.4" || $_GET[ 'old' ] ) {
			include template( "saya_avatarupload:avatarupload" );
			return $script;
		} else {
			include template( "saya_avatarupload:avatarupload" );
			return $script;
		}
	}

	function spacecp_avatar_bottom() {
		global $_G;
		loaducenter();
		$uc_avatarflash = uc_avatar( $_G[ 'uid' ], 'virtual', 0 );
		$avatarflash = explode( "?", $uc_avatarflash[ 7 ] );
		$AvatarSettingArray = explode( "&", $avatarflash[ 1 ] );
		foreach ( $AvatarSettingArray as $value ) {
			$valueArray = explode( "=", $value );
			$AvatarSettings[ $valueArray[ 0 ] ] = $valueArray[ 1 ];
		}
		$is_https = $this->_is_https();
		if ( $_G[ 'cache' ][ 'plugin' ][ 'saya_avatarupload' ][ 'crossorigin' ] ) {
			$PostUrl = "plugin.php?id=saya_avatarupload:index";
			$formhash = ',formhash:"' . formhash() . '"';
		} else {
			$PostUrl = $is_https[ 1 ] . str_replace( array( "http://", "https://" ), array( "", "" ), urldecode( $AvatarSettings[ 'ucapi' ] ) ) . "/index.php?m=user&inajax={$AvatarSettings['inajax']}&a=rectavatar&appid={$AvatarSettings['appid']}&input={$AvatarSettings['input']}&agent={$AvatarSettings['agent']}&avatartype={$AvatarSettings['avatartype']}";
			$formhash = '';
		}
		$needvatarverify=false;
		if ( in_array( "saya_avatarverify", $_G[ 'setting' ][ 'plugins' ][ 'available' ] ) !== false ) { //检查头像审核是否开启，开启则接入
			$verifygroup = unserialize( $_G[ 'cache' ][ 'plugin' ][ 'saya_avatarverify' ][ 'verifygroup' ] );
			if ( in_array( $_G[ 'groupid' ], $verifygroup ) ) {
				$PostUrl = $_G[ 'siteurl' ] . "plugin.php?id=saya_avatarverify:index&formhash=" . formhash() . "&m=user&inajax={$AvatarSettings['inajax']}&a=rectavatar&appid={$AvatarSettings['appid']}&input={$AvatarSettings['input']}&agent={$AvatarSettings['agent']}&avatartype={$AvatarSettings['avatartype']}";
				$needvatarverify=true;
			}
		}
		$ucapi = urldecode( $AvatarSettings[ 'ucapi' ] );
		include template( "saya_avatarupload:avatarupload" );
		if ( $_G[ 'setting' ][ 'version' ] != "X3.4" || $_GET[ 'old' ] ) {
			return $script . $return;
		} else {
			return $html5 . $return;
		}
	}
}

//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>