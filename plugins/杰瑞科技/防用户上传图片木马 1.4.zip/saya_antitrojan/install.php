<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
 exit('Access Denied');
}
$sql = <<<SQLEND
CREATE TABLE IF NOT EXISTS `cdb_saya_antitrojan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `username` text NOT NULL,
  `trojan` text NOT NULL,
  `statu` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `ipaddress` TEXT NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
);
SQLEND;
runquery($sql);
$finish=TRUE;
?>