<?php
if ( !defined( 'IN_DISCUZ' ) || !defined( 'IN_ADMINCP' ) ) {
	exit( 'Access Denied' );
}
if($_GET['act']=="del"){
	if(submitcheck('act')){
		$delids="(".implode(",",$_GET['delid']).")";
		//DB::query();
		DB::delete("saya_antitrojan","id IN {$delids}");
	}
}
$page = isset( $_GET[ 'page' ] ) ? $_GET[ 'page' ] : 1;
$antilist = DB::fetch_all( "SELECT * FROM %t ORDER BY id DESC LIMIT %d,%d", array( "saya_antitrojan", ( $page - 1 ) * 30, $page * 30 ) );
$rows = DB::fetch_first( "SELECT count(0) AS rows FROM %t", array( "saya_antitrojan" ) );
$pages = ceil( $rows[ 'rows' ] / 30 );
showformheader("plugins&operation=config&do={$_GET['do']}&identifier=saya_antitrojan&pmod=admin");
showtableheader( lang("plugin/saya_antitrojan","tableheader") );
showsubtitle( array(lang("plugin/saya_antitrojan","delete"), "ID", lang("plugin/saya_antitrojan","upperuid"), lang("plugin/saya_antitrojan","upperusername"), lang("plugin/saya_antitrojan","trojan"), lang("plugin/saya_antitrojan","date"),lang("plugin/saya_antitrojan","ipaddress") ) );
foreach ( $antilist as $value ) {
	showtablerow( '', array(), array("<input type=\"checkbox\" name=\"delid[]\" value=\"{$value[ 'id' ]}\" /> ", $value[ 'id' ], $value[ 'uid' ], $value[ 'username' ], $value[ 'trojan' ], date( "Y-m-d H:i:s", $value[ 'timestamp' ] ),$value['ipaddress'] ) );
}
showsubmit('submit',lang("plugin/saya_antitrojan","submitdelete") );
//showtablerow("",array('colspan="10"'),array());
if ( $pages > 1 ) {
	for ( $i = 1; $i <= $pages; $i++ ) {
		$Query_String=preg_replace("/\&page=[\d]+/","",$_SERVER[ 'QUERY_STRING' ]);
		$href = ADMINSCRIPT . "?" . $Query_String . "&page=$i";
		$links .= ( $i != $page ) ? "<a href=\"$href\"><strong>$i</strong></a>&nbsp;" : "<span>$i</span>&nbsp;";
	}
	showtablerow( '', array( 'colspan="10"' ), array( $links ) );
}
showhiddenfields(array('act'=>'del'));
showtablefooter();/*Dism��taobao��com*/
showformfooter();
?>