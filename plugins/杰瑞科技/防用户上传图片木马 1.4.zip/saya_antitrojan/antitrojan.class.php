<?php
if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}

class plugin_saya_antitrojan {
	 function _getClientIp() {
    	$ip = 'unknown';
		$unknown = 'unknown';
    	if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'] && strcasecmp($_SERVER['HTTP_X_FORWARDED_FOR'], $unknown)) {
        	$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} elseif (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], $unknown)) {
        	$ip = $_SERVER['REMOTE_ADDR'];
    	}
    	if (strpos($ip, ',') !== false) {
        	$ip = reset(explode(',', $ip));
    	}
    	return $ip;
	 }
	function common(){
		global $_G;
		$groups=unserialize($_G['cache']['plugin']['saya_antitrojan']['groups']);
		if(!in_array($_G['groupid'],$groups)){
			return;
		}
		if($_FILES['Filedata']){
			$file_type=array(".jpg","jpeg",".png",".bmp",".gif");
			$FILEStype=substr($_FILES['Filedata']["name"],-4);
			if(!in_array($FILEStype,$file_type)){
				return;
			}
			$a=file_get_contents($_FILES['Filedata']["tmp_name"]);
			if($_G['cache']['plugin']['saya_antitrojan']['targ']){
				if(preg_match_all("/(\<\?\s[^\?\>]+[\?\>]{0,2})/",$a,$match)){
				foreach($match[0] as $value){
					DB::insert("saya_antitrojan",array("uid"=>$_G['uid'],"username"=>$_G['username'],"trojan"=>htmlspecialchars($value),"statu"=>0,"timestamp"=>time(),'ipaddress'=>$this->_getClientIp()));
				}
				if($_GET['operation'] == 'upload') {
					exit("-10");
				}elseif($_GET['operation'] == 'poll'){
					exit("{\"aid\":0, \"errorcode\":5}");
				}elseif($_GET['operation'] == 'album'){
					exit("{\"picid\":\"0\", \"url\":\"0\", \"bigimg\":\"0\"}");
				}elseif($_GET['operation'] == 'portal'){
					exit("{\"aid\":0, \"errorcode\":5}");
				}
			}
			}
			if(preg_match_all("/(\<\?[PHPphp]{3}[^\?\>]+[\?\>]{0,2})/",$a,$match)){
				foreach($match[0] as $value){
					DB::insert("saya_antitrojan",array("uid"=>$_G['uid'],"username"=>$_G['username'],"trojan"=>htmlspecialchars($value),"statu"=>0,"timestamp"=>time(),'ipaddress'=>$this->_getClientIp()));
				}
				if($_GET['operation'] == 'upload') {
					exit("-10");
				}elseif($_GET['operation'] == 'poll'){
					exit("{\"aid\":0, \"errorcode\":5}");
				}elseif($_GET['operation'] == 'album'){
					exit("{\"picid\":\"0\", \"url\":\"0\", \"bigimg\":\"0\"}");
				}elseif($_GET['operation'] == 'portal'){
					exit("{\"aid\":0, \"errorcode\":5}");
				}
			}
			
		}
	}
}

class mobileplugin_saya_antitrojan extends plugin_saya_antitrojan{	
}
?>