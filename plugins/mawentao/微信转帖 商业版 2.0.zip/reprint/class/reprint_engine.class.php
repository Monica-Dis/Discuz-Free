<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class reprint_engine
{
    private $_url = "";
    private $_fid = 0;
    private $_typeid = 0;
    private $_uid = 0;
    private $_html = '';
    public $_title = '';
    public $_subject = '';
    private $_content = '';
    public $_words;
    private $forumUpload = null;
    public function __construct() {}
    function buildContext($url,$fid,$typeid,$uid)
    {
        $this->_url = $url;
        $this->checkUrl();
        $record = C::t("#reprint#reprint_thread")->getThreadByUrl($url);
        if (!empty($record)) {
            throw new Exception(lang("plugin/reprint","duplicate_reprint"));
        }
        $fid = intval($fid);
        if ($fid<=0) {
            throw new Exception(lang("plugin/reprint","fid_lost"));
        }
        $this->_fid = $fid;
        $this->_typeid = $typeid;
        $uid = intval($uid);
        if ($uid<=0 || !$this->allowpost($fid,$uid)) {
            throw new Exception(lang("plugin/reprint","post_forbid"));
        }
        $this->_uid = $uid;
        return $this;
    }
    function checkUrl()
    {
        $reg = "/^http[s]?:\/\/mp.weixin.qq.com/i";
        if (!preg_match($reg, $this->_url)) {
            throw new Exception(lang("plugin/reprint",'url_forbid'));
        }
    }
    public function crawlAndParse()
    {
        $this->_html = dfsockopen($this->_url);
        require_once "phpquery.class.php";
        $doc = phpQuery::newDocumentHTML($this->_html);
        phpQuery::selectDocument($doc);
        $title = trim(pq('#activity-name')->html());
		$this->setTitle($title);
        $this->_content = trim(pq('#js_content')->html());
        if ($this->_title=='' || $this->_content=='') {
            throw new Exception(lang("plugin/reprint",'crawl_fail'));
        }
        $this->_content = $this->toBBCode($this->_content);
        $this->_words = $this->splitImgs($this->_content);
        return $this;
    }
    public function saveImgByAttach($imgurl)
    {
        $img = C::m("#reprint#reprint_image")->crawlImg($imgurl);
        if ($this->forumUpload==null) {
            require_once DISCUZ_ROOT."/source/plugin/reprint/class/reprint_forum_upload.class.php";
            $this->forumUpload = new reprint_forum_upload();
        }
        $img['aid'] = $this->forumUpload->forum_upload($img['file']);
        return $img;
    }
    public function postThread($content,$aids)
    {
        $fid = $this->_fid;
        $params = array(
            'typeid' => $this->_typeid,
            'subject' => reprint_utils::utf8_to_site_charset($this->_subject),
            'message' => reprint_utils::utf8_to_site_charset($content),
            "sortid" => 0,
            "special" => 0,
            "publishdate" => time(),
            "save" => "",
            "sticktopic" => null,
            "digest" => null,
            "readperm" => 0,
            "isanonymous" => null,
            "typeexpiration" => null,
            "ordertype" => null,
            "hiddenreplies" => null,
            "allownoticeauthor" => 1,
            "tags" => "",
            "bbcodeoff" => null,
            "smileyoff" => null,
            "parseurloff" => null,
            "usesig" => 1,
            "htmlon" => null,
            "geoloc" => null,
        );
        $modthread = C::m('forum_thread');
        include_once libfile('function/forum');
        loadforum($fid);
        $modthread->forum = $modthread->app->var['forum'];
        global $_G;
        if (!isset($_G['uid'])) {
            $_G['uid'] = $this->_uid;
        }
        $return = $modthread->newthread($params);
        $tid = $modthread->tid;
        $pid = $modthread->pid;
        if ($tid==0) {
            throw new Exception(lang('plugin/reprint','post_fail'));
        }
        if (!empty($aids)) {
            foreach ($aids as $aid) {
                $this->reprint_convertunusedattach($aid, $tid, $pid);
                $attachcount = C::t('forum_attachment_n')->count_by_id('tid:'.$tid, $pid ? 'pid' : 'tid', $pid ? $pid : $tid);
                $attachment = 0;
                if($attachcount) {
                    if(C::t('forum_attachment_n')->count_image_by_id('tid:'.$tid, $pid ? 'pid' : 'tid', $pid ? $pid : $tid)) {
                        $attachment = 2;
                    } else {
                        $attachment = 1;
                    }
                } else {
                    $attachment = 0;
                }
                C::t('forum_thread')->update($tid, array('attachment'=>$attachment));
                C::t('forum_post')->update('tid:'.$tid, $pid, array('attachment' => $attachment), true);
            }
        }
		$title = reprint_utils::utf8_to_site_charset($this->_title);
        C::t('#reprint#reprint_thread')->addThread($tid, $this->_url, $title, $this->_uid);
        return $tid;
    }
	public function setTitle($title) 
	{
		$this->_title = $title;
		$setting = C::m('#reprint#reprint_setting')->get();
        if ($setting['zlabel']==0) {
			$zhuan = lang('plugin/reprint','zhuan');
			$zutf = reprint_utils::toutf8($zhuan);
            $this->_subject = $zutf.$this->_title;
        } else {
            $this->_subject = $this->_title;
        }
	}
    private function toBBCode($content)
    {
        $content = urldecode($content);
        $content = $this->tripScriptAndStyle($content);
        require_once libfile('function/editor');
        $content = html2bbcode($content);
        $content = htmlspecialchars_decode($content);
        return $content;
    }
    private function tripScriptAndStyle(&$html)
    {
        $html = preg_replace("/<script>.*?<\/script>/i", "", $html);
        $html = preg_replace("/<style>.*?<\/style>/i", "", $html);
        return $html;
    }
    private function splitImgs(&$str)
    {
        $list=array();
        $n = strlen($str);
        $state=0;
        $word="";
        $urlprex = reprint_env::getSiteUrl()."/source/plugin/reprint/";
        for($i=0; $i<$n; ++$i) {
            $c = $str{$i};
            switch($state) {
                case 0:
                    $word.=$c;
                    if($c=='[') {$state=1;}
                    break;
                case 1:
                    $word.=$c;
                    if($c=='i' || $c=='I') {$state=2;}
                    else {$state=0;}
                    break;
                case 2:
                    $word.=$c;
                    if($c=='m' || $c=='M') {$state=3;}
                    else {$state=0;}
                    break;
                case 3:
                    $word.=$c;
                    if($c=='g' || $c=='G') {$state=4;}
                    else {$state=0;}
                    break;
                case 4:
                    $word.=$c;
                    if($c==']') {
                        $list[] = $word;
                        $word = "";
                        $state=5;
                    }
                    break;
                case 5:
                    if ($c=='[') {
                        $list[] = array(
                            "tag" => "img",
                            "src" => str_replace($urlprex,'',$word),
                        );
                        $word="";
                        $state=1;
                    }
                    $word.=$c;
                    break;
            }
        }
        if ($word!="") {
            $list[] = $word;
        }
        $this->processWords($list);
        return $list;
    }
    private function processWords(array &$words)
    {
        $sizereg = "/\[\/?size.*?\]/i";
        $j13reg  = "/&#13;/i";
        $imgreg = "/\[\/?img?\]/i";
        $setting = C::m("#reprint#reprint_setting")->get();
        $delwords = $setting['dwords'];
        $len = count($delwords);
        $i = 0;
        foreach ($words as &$word) {
            if (is_array($word)) {
                ++$i;
                continue;
            }
            $word = preg_replace($sizereg, "", $word);
            $word = preg_replace($j13reg, "", $word);
            $word = preg_replace($imgreg, "", $word);   
            if ($len>0) {
                foreach ($delwords as $delword) {
                    $dwreg = "/$delword/i";
                    $word = preg_replace($dwreg, "", $word);
                }
            }
            $word = trim($word);
            ++$i;
        }
    }
    function reprint_convertunusedattach($aid, $tid, $pid)
    {
        if(!$aid) {
            return;
        }
        global $_G;
        $attach = C::t('forum_attachment_n')->fetch_by_aid_uid(127, $aid, $_G['uid']);
        if(!$attach) {
            return;
        }
        $attach = daddslashes($attach);
        $attach['tid'] = $tid;
        $attach['pid'] = $pid;
        C::t('forum_attachment_n')->insert('tid:'.$tid, $attach);
        C::t('forum_attachment')->update($attach['aid'], array('tid' => $tid, 'pid' => $pid, 'tableid' => getattachtableid($tid)));
        C::t('forum_attachment_unused')->delete($attach['aid']);
    }
    public static function allowpost($fid,$uid)
    {
        global $_G;
        if (!$_G['group']['allowpost']) {
            return false;
        }
        $info = C::t('forum_access')->fetch_all_by_fid_uid($fid, $uid);      
        if (!empty($info)) {
            $allowpost = intval($info[0]['allowpost']);
            if ($allowpost<0) {
                return false;
            }
        }
        return true;
    }
}
//From: dis'.'m.tao'.'bao.com
?>