<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once 'log.class.php';
require_once 'json.class.php';
require_once 'utils.class.php';
require_once 'validate.class.php';
class reprint_env
{
    private static $_log_obj = null;
    private static $_aksk = false;
    public static function getlog($console=false)
    {
        if (!self::$_log_obj) {
            $logcfg = array('log_level'=>16,'console'=>$console);
            self::$_log_obj = new reprint_log($logcfg);
        }   
        return self::$_log_obj;
    }
    public static function getSiteUrl()
    {
        global $_G;
        $_G['siteurl'] = preg_replace("/source\/plugin\/reprint/i","", $_G['siteurl']);
        return rtrim($_G['siteurl'], '/');
    }
    public static function getPluginDataPath($extpath="") {
        $path = DISCUZ_ROOT."data/plugindata/reprint/".$extpath;
        if (!is_dir($path)) {
            mkdir($path, 0777, true);
        }
        return $path;
    }
    public static function getPluginDataPathUrl($extpath="") {
        global $_G;
        return self::getSiteUrl()."/data/plugindata/reprint/".$extpath;
    }
    public static function createReprintEngine()
    {
        require_once 'reprint_engine.class.php';
        return new reprint_engine();
    }
    public static function getDemoLink()
    {
        $paper = 'https://mp.weixin.qq.com/s?__biz=MzI0OTA2ODAyMw==&mid=2648952458&idx=1&sn=9cca310969ec46291af9f124cb6b7f48&chksm=f1804e12c6f7c704221478f43ebb79119e990f390135745580b20680e03737cae18ea4a0fcd0&token=747836075&lang=zh_CN#rd';
        $res = dfsockopen('http://139.196.29.35:8888/api/reprint/getdemo');
        $d = json_decode($res,true);
        if (!empty($d) && isset($d['paper'])) {
            $paper = $d['paper'];
        }
        return $paper;
    }
    public static function getPluginPath()
    {
        return self::getSiteUrl().'/source/plugin/reprint';
    }
}
//From: dis'.'m.tao'.'bao.com
?>