<?php
define("IN_REPRINT_API", 1);
define("REPRINT_PLUGIN_PATH", dirname(__FILE__));
chdir("../../../");
require_once('./source/class/class_core.php');
$discuz = C::app();
$discuz->init();
require_once REPRINT_PLUGIN_PATH.'/class/env.class.php';
$module = isset($_GET['module']) ? $_GET['module'] : '';
$action = isset($_GET['action']) ? $_GET['action'] : '';
$retcode = 0;
try {
	$modules = array ('admincp','reprint');
    if(!in_array($_GET['module'], $modules)) {
        throw new Exception("module not found[$module]");
    }
    $apifile = REPRINT_PLUGIN_PATH."/api/$module.php";
    if(!file_exists($apifile)) {
        throw new Exception("module not found[$module]");
    }
    require_once $apifile;
    $actionFun = $action . "Action";
    if (!function_exists($actionFun)) {
        throw new Exception("unkown action[$action] in api module[$module]");
    }
    $res = $actionFun();
    apiOutput(array("data" => $res));
    exit(0);
} catch (Exception $e) {
    if ($retcode==0) $retcode = 1001;
    apiOutput(array('retcode'=>$retcode,'retmsg'=>$e->getMessage()));
}
function authLogin()
{
    global $_G,$retcode;
    if ($_G['uid']==0) {
        $retcode = 1002;
        throw new Exception("please login");
    }
}
function authUsergroup(array $groupids)
{
    global $_G,$retcode;
    $groupid = $_G["groupid"];
    if (!empty($groupids) && !in_array($groupid,$groupids)) {
        $retcode = 1003;
        throw new Exception('Illegal Request [groupid:'.$groupid.' is forbidden]');
    }   
}
function apiOutput(array $result, $json_header=true, $charset=CHARSET)
{
    if (!isset($result['retcode'])) {
        $result['retcode'] = 0;
    }
    if (!isset($result['retmsg'])) {
        $result['retmsg'] = 'succ';
    }
    if ($json_header) {
        header("Content-type: application/json");
    }
	$charset = strtolower($charset);
    if ($charset=='gbk') {
        echo reprint_json::encode($result);
    } else {
        echo json_encode($result);
    }
    exit;
}
//From: dis'.'m.tao'.'bao.com
?>