<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_REPRINT_API')) {
    exit('Access Denied');
}
authLogin();
function configAction() 
{
	$setting = C::m('#reprint#reprint_setting')->get();
	$res = array (
		'title'  => lang('plugin/reprint','welcome'),
		'forbid' => false,
	);
	return $res;
}
function getDemoLinkAction() {return reprint_env::getDemoLink();}
function getForumTypelistAction()
{
	$fid = reprint_validate::getNCParameter('fid','fid','integer');
	$res = array();
	if ($fid>0) {
		$list = C::t('forum_threadclass')->fetch_all_by_fid($fid);
		if (!empty($list)) {
			foreach ($list as $item) {
				$res[] = array(
					'typeid' => $item['typeid'],
					'name'   => $item['name'],
				);
			}
		}
	}
	return $res;
}
function crawlPageAction()
{
	global $_G;
	$url = reprint_validate::getNCParameter('url','url','string',2048);
	$fid = reprint_validate::getNCParameter('fid','fid','integer');
	$typeid = reprint_validate::getNCParameter('typeid','typeid','integer');
	$uid = $_G['uid'];
	$reprintEngine = reprint_env::createReprintEngine();
	$reprintEngine->buildContext($url, $fid, $typeid, $uid)
				  ->crawlAndParse();
	$data = array(
		'fid' => $fid,
		'typeid'=> $typeid,
		'subject' => $reprintEngine->_title,
		'words' => $reprintEngine->_words,
		'formhash'=> $_G['formhash'],
	);
	$res = array (
		'data' => $data,
	);
	apiOutput($res, true, 'utf-8');
}
function saveimgByAttachAction()
{
	$imgurl = reprint_validate::getNCParameter('imgurl','imgurl','url',2048);
	$reprintEngine = reprint_env::createReprintEngine();
	$img = $reprintEngine->saveImgByAttach($imgurl);
	unset($img['file']);
	return $img;
}
function postThreadAction()
{
	global $_G;
	$fid = reprint_validate::getNCParameter('fid','fid','integer');
	$fromurl = reprint_validate::getNCParameter('fromurl','fromurl','string',4096);
	$typeid = reprint_validate::getNCParameter('typeid','typeid','integer');
	$subject = reprint_validate::getNCParameter('subject','subject','string',1024);
	$message = reprint_validate::getNCParameter('message','message','string',1024000);
	$reprintEngine = reprint_env::createReprintEngine();
	$reprintEngine->buildContext($fromurl,$fid,$typeid,$_G['uid']);
	$reprintEngine->setTitle($subject);
	$tid = $reprintEngine->postThread($message, $_POST['unused']);
	return array(
		'tid' => $tid,
	);
}
function queryThreadsAction() {return C::t("#reprint#reprint_thread")->query(); }
//From: dis'.'m.tao'.'bao.com
?>