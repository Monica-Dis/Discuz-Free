<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_reprint_thread extends discuz_table
{
	public function __construct() {
		$this->_table = 'reprint_thread';
		$this->_pk = 'tid';
		parent::__construct(); /*DISM.TAOBAO.COM*/
	}
    public function query()
    {
        $return = array(
            "totalProperty" => 0,
            "root" => array(),
        );
        $key = reprint_validate::getNCParameter('key','key','string',1024);
        $sort = reprint_validate::getOPParameter('sort','sort','string',1024,'ctime');
        $dir = reprint_validate::getOPParameter('dir','dir','string',1024,'DESC');
        $start = reprint_validate::getOPParameter('start','start','integer',0,0);
        $limit = reprint_validate::getOPParameter('limit','limit','integer',0,20);
        $where = "1";
        if ($key!="") $where.= " AND (title like '%$key%' OR fromurl like '%$key%')";
        $table = DB::table($this->_table);
        $table_common_member = DB::table('common_member');
        $table_forum_thread = DB::table('forum_thread');
        $sql = <<<EOF
SELECT SQL_CALC_FOUND_ROWS a.*,b.username,c.subject
FROM $table as a 
LEFT JOIN $table_common_member as b ON a.uid=b.uid
LEFT JOIN $table_forum_thread as c ON a.tid=c.tid
WHERE $where
ORDER BY `$sort` $dir
LIMIT $start,$limit
EOF;
        $return["root"] = DB::fetch_all($sql);
        $row = DB::fetch_first("SELECT FOUND_ROWS() AS total");
        $return["totalProperty"] = $row["total"];
        return $return;
    }
    public function getThreadByUrl($url)
    {
        $sql = "SELECT * FROM ".DB::table($this->_table)." WHERE fromurl='$url'";
        return DB::fetch_first($sql);
    }
    public function addThread($tid, $url, $title, $uid)
    {
        $data = array (
            'tid' => $tid,
            'fromurl' => $url,
			'title' => $title,
            'uid' => $uid,
            'ctime' => date("Y-m-d H:i:s")
        );
        DB::insert($this->_table,$data);
    }
    public function del()
    {
        $tid = isset($_REQUEST["tid"]) ? intval($_REQUEST["tid"]) : 0;
        if ($tid==0) {
            throw new Exception('tid is not set');
        }
        $sql = "DELETE FROM ".DB::table($this->_table)." WHERE tid='$tid'";
        runlog('reprint', "[sql: $sql]");
        DB::query($sql);
    }
}
//From: dis'.'m.tao'.'bao.com
?>