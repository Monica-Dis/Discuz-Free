<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


 
 echo '


  <div class="jz52_plutt">
<iframe width="98%" height="700"  scrolling="yes"  frameborder=no src="https://dism.taobao.com/category-1476983558.htm" ></iframe>
 
 </div>
 ';


?>