<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$charset = $_G['charset'];
$jz52_kfzxdm = $_G['cache']['plugin']['jz52_top']['jz52_kfzxdm'];
$jz52_kfzxwbwx = $_G['cache']['plugin']['jz52_top']['jz52_kfzxwbwx'];
$jz52_qqlist1 = $_G['cache']['plugin']['jz52_top']['jz52_qqlist'];
$jz52_wangwang1 = $_G['cache']['plugin']['jz52_top']['jz52_wangwang'];
$jz52_qqlist = explode("\r\n", $_G['cache']['plugin']['jz52_top']['jz52_qqlist']);
$jz52_wangwang = explode("\r\n", $_G['cache']['plugin']['jz52_top']['jz52_wangwang']);

    $jz52_qqlists = array();
    foreach($jz52_qqlist as $key => $val){
      $myarr = explode("|", $val);
      $jz52_qqlists[$key]['name'] = $myarr[0];
      $jz52_qqlists[$key]['qq'] = $myarr[1];
    }
	
	$jz52_wangwangs = array();
    foreach($jz52_wangwang as $key => $val){
      $myarrw = explode("|", $val);
      $jz52_wangwangs[$key]['name'] = $myarrw[0];
	  $jz52_wangwangs[$key]['zh'] = $myarrw[1];
	  
/**  
if($charset == gbk )
{
$jz52_wangwangs[$key]['zh'] = urlencode( mb_convert_encoding($myarrw[1], "UTF-8", "GBK")); //转换为utf-8
}
else
{
$jz52_wangwangs[$key]['zh'] = urlencode($myarrw[1]);
}    
*/
    }




	
include_once template('jz52_top:kf');


?>