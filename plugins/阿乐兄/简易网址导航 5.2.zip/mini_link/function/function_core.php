<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function mini_link_getcache(){
    global $_G,$cachetypedata, $cachelefttypedata, $cacheleftsitedata,$cacherighttypedata, $cacherightsitedata, $cachetopsitedata, $cachephonetypedata, $cachephonesitedata,$cachephonetopsitedata;
	$cachefile = DISCUZ_ROOT.'data/sysdata/cache_mini_link_cachedata.php';
	if(file_exists($cachefile)){
		@require_once DISCUZ_ROOT.'data/sysdata/cache_mini_link_cachedata.php';
	}else{
		mini_link_updatacache();
	}
}
function  mini_link_updatacache(){
	global $_G,$cachetypedata,  $cachelefttypedata, $cacheleftsitedata, $cacherighttypedata, $cacherightsitedata, $cachetopsitedata, $cachephonetypedata, $cachephonesitedata,$cachephonetopsitedata;
    require_once libfile('function/cache');
	$config=$_G['cache']['plugin']['mini_link'];
	$leftshuliang=$config['leftshuliang'];
	$rightshuliang=$config['rightshuliang'];
	$topshuliang=$config['topshuliang'];
	$moblietop=$config['moblietop'];
	$moblieright=$config['moblieright'];

	$querytype = DB::query("SELECT * FROM ".DB::table('plugin_mini_link_webtype'). " ORDER BY displayorder DESC,id DESC");
	$cachetypedata= array();
	while($valuetype = DB::fetch($querytype)){
		$cachetypedata[$valuetype['id']] = $valuetype;
	}
	$cachetypedata = dhtmlspecialchars($cachetypedata);

	$querylefttype = DB::query("SELECT * FROM ".DB::table('plugin_mini_link_webtype')." where weizhi = '1' ORDER BY displayorder DESC,id DESC");
	$cachelefttypedata= array();
	$cacheleftsitedata= array();
	while($valuelefttype = DB::fetch($querylefttype)){
		$cachelefttypedata[$valuelefttype['id']] = $valuelefttype;
		$queryleftsite = DB::query("SELECT * FROM ".DB::table('plugin_mini_link'). " where webtype = ".$valuelefttype['id']." AND shenhe = '1' ORDER BY displayorder DESC,id DESC LIMIT $leftshuliang");
		while($valueleftsite = DB::fetch($queryleftsite)){
		   	$cacheleftsitedata[$valuelefttype['id']][$valueleftsite['id']] = $valueleftsite;
		}
	}
	$cachelefttypedata = dhtmlspecialchars($cachelefttypedata);
	$cacheleftsitedata = dhtmlspecialchars($cacheleftsitedata);

	$queryrighttype = DB::query("SELECT * FROM ".DB::table('plugin_mini_link_webtype')." where weizhi = '2' ORDER BY displayorder DESC,id DESC");
	$cacherighttypedata= array();
	$cacherightsitedata= array();
	while($valuerighttype = DB::fetch($queryrighttype)){
		$cacherighttypedata[$valuerighttype['id']] = $valuerighttype;
		$queryrightsite = DB::query("SELECT * FROM ".DB::table('plugin_mini_link'). " where webtype = ".$valuerighttype['id']." AND shenhe = '1' ORDER BY displayorder DESC,id DESC LIMIT $rightshuliang");
		while($valuerightsite = DB::fetch($queryrightsite)){
		   	$cacherightsitedata[$valuerighttype['id']][$valuerightsite['id']] = $valuerightsite;
		}
	}
	$cacherighttypedata = dhtmlspecialchars($cacherighttypedata);
	$cacherightsitedata = dhtmlspecialchars($cacherightsitedata);

	$querytopsite = DB::query("SELECT * FROM ".DB::table('plugin_mini_link'). " where shenhe = '1' AND tuijian = '1'ORDER BY displayorder DESC,id DESC LIMIT $topshuliang");
	$cachetopsitedata= array();
	while($valuetopsite = DB::fetch($querytopsite)){
		$cachetopsitedata[] = $valuetopsite;
	}
	$cachetopsitedata = dhtmlspecialchars($cachetopsitedata);

	$queryphonetopsite = DB::query("SELECT * FROM ".DB::table('plugin_mini_link'). " where shenhe = '1' AND tuijian = '1'ORDER BY displayorder DESC,id DESC LIMIT $moblietop");
	$cachephonetopsitedata= array();
	while($valuephonetopsite = DB::fetch($queryphonetopsite)){
		$cachephonetopsitedata[] = $valuephonetopsite;
	}
	$cachephonetopsitedata = dhtmlspecialchars($cachephonetopsitedata);

	$queryphonetype = DB::query("SELECT * FROM ".DB::table('plugin_mini_link_webtype')." where weizhi != '0' ORDER BY displayorder DESC,id DESC");
	$cachephonetypedata= array();
	$cachephonesitedata= array();
	while($valuephonetype = DB::fetch($queryphonetype)){
		$cachephonetypedata[$valuephonetype['id']] = $valuephonetype;
		$queryphonesite = DB::query("SELECT * FROM ".DB::table('plugin_mini_link'). " where webtype = ".$valuephonetype['id']." AND shenhe = '1' ORDER BY displayorder DESC,id DESC LIMIT $moblieright");
		while($valuephonesite = DB::fetch($queryphonesite)){
		   	$cachephonesitedata[$valuephonetype['id']][$valuephonesite['id']] = $valuephonesite;
		}
	}
	$cachephonetypedata = dhtmlspecialchars($cachephonetypedata);
	$cachephonesitedata = dhtmlspecialchars($cachephonesitedata);
	
	writetocache('mini_link_cachedata', getcachevars(array('cachetypedata' => $cachetypedata,  'cachelefttypedata' => $cachelefttypedata, 'cacheleftsitedata' => $cacheleftsitedata, 'cacherighttypedata' => $cacherighttypedata, 'cacherightsitedata' => $cacherightsitedata, 'cachetopsitedata' => $cachetopsitedata, 'cachephonetypedata' => $cachephonetypedata, 'cachephonesitedata' => $cachephonesitedata, 'cachephonetopsitedata' => $cachephonetopsitedata)));
}
function mini_link_filter_url($url) {
	preg_match("/((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\/\/|www\.)[^\[\"']+/i", trim($url), $matches);
	return $matches[0];
}
//From: d'.'is'.'m.ta'.'obao.com
?>