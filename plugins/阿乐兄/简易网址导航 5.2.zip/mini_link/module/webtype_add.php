<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if ($_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
    if(submitcheck('webtypeadd')){
	    $web_type = dhtmlspecialchars($_GET['web_type']);
	    $webtype = DB::result_first("SELECT type FROM ".DB::table('plugin_mini_link_webtype'). " where type = '".$web_type."'");
	    $icon = dhtmlspecialchars($_GET['icon']);
	    $webtitle = daddslashes($_GET['webtitle']);
	    $webkey = dhtmlspecialchars($_GET['webkeyword']);
	    $webde = dhtmlspecialchars($_GET['webdescription']);
	    $weizhi = intval($_GET['weizhi']);	
	    $disable = intval($_GET['disable']);
	    $displayorder = intval($_GET['web_displayorder']);	
		if($_FILES['file']['error']==0){
			$filetype = array("jpg", "jpeg", "gif", "icon", "png","JPG", "JEPG", "GIF", "PNG", "ICON");
			$arr=explode(".", $_FILES["file"]["name"]);
			$hz=$arr[count($arr)-1];
			if(!in_array($hz, $filetype)){
				showmessage(lang('plugin/mini_link', 'zhiyunxu'));	
			}
			$filepath = "source/plugin/mini_link/upimg/".date("Ymd")."/";
			$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
			if(!file_exists($filepath)){ mkdir($filepath); }
			if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
				 @unlink($_FILES['file']['tmp_name']);
			}
			$icon = "source/plugin/mini_link/upimg/".date("Ymd")."/".$randname."";
	    }
	    if(!$webtype){
		    DB::INSERT('plugin_mini_link_webtype',array('type'=> $web_type,'icon'=> $icon,'title'=> $webtitle,'keyword'=> $webkey,'description'=> $webde,'weizhi'=> $weizhi,'disable'=> $disable,'displayorder'=> $displayorder));
	        mini_link_updatacache();
		    showmessage(lang('plugin/mini_link', 'tijiaook'),'plugin.php?id=mini_link&type=webtype&action=list');
	    }else{
		    showmessage(lang('plugin/mini_link', 'wangzhanleixingyicunzai'),'plugin.php?id=mini_link&type=webtype&action=list');
	    }
		include template('mini_link:webtype_add');
    }else{
	    include template('mini_link:webtype_add');
    }
}else{
	showmessage(lang('plugin/mini_link', 'wuquanxianshiyong'),'plugin.php?id=mini_link');
}
//From: d'.'is'.'m.ta'.'obao.com
?>






