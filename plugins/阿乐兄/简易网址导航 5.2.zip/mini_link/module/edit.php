<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$uid = intval($_G['uid']);
$siteid = intval($_GET['siteid']);
$content = DB::fetch_first("SELECT * FROM ".DB::table('plugin_mini_link')." where id = '".$siteid."'");
if (($content['uid']!='0' && $content['uid'] == $_G['uid']) || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
    mini_link_getcache();
    if(submitcheck('websitesubmit')){
        $webname = strip_tags(daddslashes($_GET['webname']));
        $weburl = strip_tags(daddslashes($_GET['weburl']));
        if(!preg_match('/^http(s)?:\\/\\/.+/',$weburl)){
            showmessage(lang('plugin/mini_link', 'wangzhicuowu'));
        }
        $weblogo = strip_tags(daddslashes($_GET['weblogo']));
   	    $icon = intval($_GET['icon']);
        $color = strip_tags(daddslashes($_GET['color']));
        $bgcolor = strip_tags(daddslashes($_GET['bgcolor']));
        $tuijian = intval($_GET['tuijian']);	
        if($config['fabushenhe']==0||$_G['groupid']==1){ 
	        $shenhe = 1 ; 
        }else{ 
	        $shenhe = 0 ; 
        }
	    $displayorder = intval($_GET['displayorder']);
	    $webtype = intval($_GET['webtype']);
	    if(!$webname){
		    showmessage(lang('plugin/mini_link', 'webnamebunengkong'),'');
	    }
	    if(!$weburl){
		    showmessage(lang('plugin/mini_link', 'weburlbunengkong'),'');
	    }
	    if($_FILES['file']['error']==0){
		    if ($content["weblogo"]!=false){
	            unlink($content["weblogo"]);
	        }
			$imageinfo = getimagesize($_FILES['file']['tmp_name']);
			if ($imageinfo[0] <= 0) {
                showmessage(lang('plugin/mini_link', 'zhiyunxu'));
			}
			$filesize = $_FILES['file']['size'] <= 204800 ;  
			$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
			$arr=explode(".", $_FILES["file"]["name"]);
			$hz=$arr[count($arr)-1];
			if(!in_array($hz, $filetype)){
				showmessage(lang('plugin/mini_link', 'tupiangeshibuzhengque'));	
			}
			$filepath = "source/plugin/mini_link/logo/".date("Ymd")."/";
			$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
			if(!file_exists($filepath)){ mkdir($filepath); }
			if($filesize){ 
				if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
				     @unlink($_FILES['file']['tmp_name']);
			    }
			}else{
				showmessage(lang('plugin/mini_link', 'chaochudaxiao'));	
			}
			$weblogo = "source/plugin/mini_link/logo/".date("Ymd")."/".$randname."";
	    }
	    $siteid = intval($_GET['siteid']);
	    $data = array('webname' =>  $webname,'weburl' => $weburl,'weblogo' => $weblogo,'color' =>  $color,'icon' =>  $icon,'bgcolor' => $bgcolor,'shenhe' => $shenhe,'tuijian' => $tuijian,'displayorder' => $displayorder,'webtype' => $webtype,'uid' => $uid,);
	    DB::UPDATE('plugin_mini_link' , $data, array('id' => $siteid));
        mini_link_updatacache();
	    showmessage(lang('plugin/mini_link', 'xiugaiok'), dreferer());
    }else{
	    include template('mini_link:edit');
    }
}else{
    showmessage(lang('plugin/mini_link', 'yemianbucunzai'));
}
//From: d'.'is'.'m.ta'.'obao.com
?>