<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if ($_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
    $title = $navtitle= $config['t_title'];
    $metakeywords = $config['keyword'];
    $metadescription = $config['description'];
    $paytype=$config['paytype'];
    $paymoney=getuserprofile('extcredits'."$paytype");
    $headstyle=$config['headstyle'];
    $headstylediy=$config['headstylediy'];
    $perpage = 20;
    $page = max(1, intval($_GET['page']));
    $start_limit = ($page - 1) * $perpage;
    $count = DB::result_first("SELECT count(*) FROM ".DB::table('plugin_mini_link_webtype'));
    $multipage = multi($count, $perpage, $page, "plugin.php?id=mini_link&type=webtype&action=list");
    $query = DB::query("SELECT * FROM ".DB::table('plugin_mini_link_webtype'). " ORDER BY displayorder DESC,id DESC LIMIT $start_limit, $perpage");
    $list = array();
    while($value = DB::fetch($query)){
	    $list[$value['id']] = $value;
    }
    $list = dhtmlspecialchars($list);
    if(submitcheck('applysubmdel')){
	    $pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $ssd) {
            $aid = intval($ssd);
		    $active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_mini_link_webtype')." WHERE id ='$ssd' LIMIT 0 , 1");
	        unlink($active["icon"]);
			DB::delete('plugin_mini_link_webtype',array('id'=> $ssd));
			$nums++;
        }
	    mini_link_updatacache();
        showmessage(lang('plugin/mini_link', 'shanchuchenggong'), dreferer());	
    }elseif(submitcheck('applysubmalldel')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $ssd) {
            $aid = intval($ssd);
            $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_link_webtype') . " WHERE id ='$aid' LIMIT 0 , 1");
            if ($active["icon"] != false) {
                unlink($active["icon"]);
            }
	        $query = DB::query("SELECT * FROM ".DB::table('plugin_mini_link')." WHERE webtype = '$aid'");
	        $delz = $delzs = array();
	        while($delz = DB::fetch($query)){
		        if ($delz["weblogo"]!=false){
			      unlink($delz["weblogo"]);
		        }
		        $delzs[] = $delz;
	        }
            DB::query("DELETE a,b FROM " . DB::table('plugin_mini_link')." AS a LEFT JOIN ". DB::table('plugin_mini_link_webtype') . " AS b ON b.id = a.webtype  WHERE a.webtype = '$aid' ");
			$nums++;
        }
	    mini_link_updatacache();
        showmessage(lang('plugin/mini_link', 'shanchuchenggong'), dreferer());	
    }
    mini_link_getcache();
    include template('mini_link:webtype_list');
}else{
	showmessage(lang('plugin/mini_link', 'yemianbucunzai'));
}
//From: d'.'is'.'m.ta'.'obao.com
?>