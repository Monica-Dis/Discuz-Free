<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$config=$_G['cache']['plugin']['mini_link'];
$groupso = $config['groupso'] ? $config['groupso'] : '1';
$admins = explode(",", $groupso);
$paytype=$config['paytype'];
$youkefabuset=$config['youkefabuset'];
$paymoney=getuserprofile('extcredits'."$paytype");
$style=$config['style'];
$touchstyle=$config['touchstyle'];
$diyset=$config['diyset'];
$html=$config['html'];
$keyword=$config['keyword'];
$description=$config['description'];
$headstyle=$config['headstyle'];
$headstylediy=$config['headstylediy'];
$title=$config['t_title'];
$defaultpic = $config['defaultpic'];
$links = array();
$linksql = DB::query("SELECT * FROM ".DB::table('common_friendlink')." order by `displayorder`");
while($linksloop = DB::fetch($linksql)){
	$links[] = $linksloop; 
}
$title = $navtitle = $title.' - '.$description;
$metakeywords = $keyword;
$metadescription = $description;
mini_link_getcache();
if($_G['mobile']) {
	include template('mini_link:index');
} else {
	if ($style == '1'){
		if ($diyset == '1'){
	      include template('diy:index:'.$_GET['id'].$_GET['index'], 0, 'source/plugin/mini_link/template/');
		}else{
	      include template('mini_link:index');
	    }
    }elseif ($style == '2'){
		if ($diyset == '1'){
	      include template('diy:index2:'.$_GET['id'].$_GET['index'], 0, 'source/plugin/mini_link/template/');
		}else{
	      include template('mini_link:index2');
	    }
    }elseif ($style == '3'){
		if ($diyset == '1'){
	      include template('diy:index3:'.$_GET['id'].$_GET['index'], 0, 'source/plugin/mini_link/template/');
		}else{
	      include template('mini_link:index3');
	    }
    }elseif ($style == '4'){
		if ($diyset == '1'){
	      include template('diy:index4:'.$_GET['id'].$_GET['index'], 0, 'source/plugin/mini_link/template/');
		}else{
	      include template('mini_link:index4');
	    }
	}
}
//From: d'.'is'.'m.ta'.'obao.com
?>	