<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$config = $_G['cache']['plugin']['mini_link'];
$paytype = $config['paytype'];
$creditd = $config['creditd'];
$groupso = $config['groupso'] ? $config['groupso'] : '1';
$admins = explode(",", $groupso);
if($creditd == '0'||!$paytype){
	showmessage(lang('plugin/mini_link', 'miaoshenweikaiqi'));
}
    $moneytype = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
	$sid = intval($_GET['sid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_link') . " WHERE id = '$sid'");
    if($item['shenhe']=="1"){
		showmessage(lang('plugin/mini_link', 'miaoshentongguo'), array(), array('alert' => 'error'));
	}
	if(submitcheck('applysubmiaoshen')){
          if($paymoney<$creditd){
              $tixing= lang('plugin/mini_link', 'miaoshenshibai').$creditd.$moneytype;
        	  showmessage(lang('plugin/mini_link', $tixing));
          }else{
			  DB::query("UPDATE ".DB::table('plugin_mini_link')." SET `shenhe` = '1' WHERE `id` = '$sid'");
			  updatemembercount($_G['uid'], array($paytype => -$creditd),true,'','','ok',lang('plugin/mini_link', 'jifentishia'),lang('plugin/mini_link', 'jifentishib'));
              for ($i = 0; $i < count($admins); $i++) {
                $message = '<a href="plugin.php?id=mini_link&type=website&action=alllist&display=all" target="_blank">'.lang('plugin/mini_link', 'miaoshenweisend').$item[webname].'</a>';
                notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
              }
              showmessage(lang('plugin/mini_link', 'tijiaook'),dreferer());
          }
	}
include template('mini_link:miaoshen');
?>