<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$display = dhtmlspecialchars($_GET['display']);
$where=$pageadd="";
	$key=stripsearchkey($_GET['key']);
    $keytype = intval($_GET['keytype']);
    if($key){
	    if($keytype==1){ 
		   $where=" WHERE weburl like '%".addcslashes(addslashes($key), '%_')."%' ";
	    }else{ 
		   $where=" WHERE webname like '%".addcslashes(addslashes($key), '%_')."%' ";
		}
	$keync=urlencode($key);
	$pageadd="&keytype=$keytype&key=$keync";
    }
$perpage = 20;
$page = max(1, intval($_GET['page']));
$start_limit = ($page - 1) * $perpage;
$count = DB::result_first("SELECT count(*) FROM ".DB::table('plugin_mini_link').$where);
$multipage = multi($count, $perpage, $page, "plugin.php?id=mini_link&type=website&action=alllist&display=all".$pageadd);
$query = DB::query("SELECT * FROM ".DB::table('plugin_mini_link').$where." ORDER BY shenhe ASC,id DESC LIMIT $start_limit, $perpage");
$list = array();
while($value=DB::fetch($query)){
			$list[$value['id']]=$value;
}
$list = dhtmlspecialchars($list);
	if(submitcheck('applysubmsh')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_mini_link')." SET shenhe='1' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
        mini_link_updatacache();
		showmessage(lang('plugin/mini_link', 'gengxinok'), dreferer());	
	}elseif(submitcheck('applysubmqxsh')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_mini_link')." SET shenhe='0' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
        mini_link_updatacache();
		showmessage(lang('plugin/mini_link', 'gengxinok'), dreferer());
	}elseif(submitcheck('applysubmtj')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_mini_link')." SET tuijian='1' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
        mini_link_updatacache();
		showmessage(lang('plugin/mini_link', 'gengxinok'), dreferer());
	}elseif(submitcheck('applysubmqxtj')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_mini_link')." SET tuijian='0' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
        mini_link_updatacache();
		showmessage(lang('plugin/mini_link', 'gengxinok'), dreferer());
	}elseif(submitcheck('applysubmdel')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $ssd) {
            $aid = intval($ssd);
		    $active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_mini_link')." WHERE id ='$ssd'LIMIT 0 , 1");
	        unlink($active["weblogo"]);
			DB::delete('plugin_mini_link',array('id'=> $ssd));
			$nums++;
        }
	        mini_link_updatacache();
            showmessage(lang('plugin/mini_link', 'shanchuchenggong'), dreferer());	
     }
mini_link_getcache();
include template('mini_link:alllist');
?>