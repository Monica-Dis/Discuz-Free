<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$config = $_G['cache']['plugin']['mini_link'];
$groupso = $config['groupso'] ? $config['groupso'] : '1';
$admins = explode(",", $groupso);
$style=$config['style'];
$youkefabuset=$config['youkefabuset'];
$touchstyle=$config['touchstyle'];
$s1widht= intval($config['width']);
$s1height= intval($config['height']);
$eacha = intval($config['eacha']);
$defaultpic = $config['defaultpic'];
$perpage = $eacha;
$page = max(1, intval($_GET['page']));
$start_limit = ($page - 1) * $perpage;
$typeid = intval($_GET['typeid']);
$count = DB::result_first("SELECT count(*) FROM ".DB::table('plugin_mini_link'). " where webtype = ".$typeid." AND shenhe = '1' ");
$multipage = multi($count, $perpage, $page, "plugin.php?id=mini_link&type=website&action=more&typeid=".$typeid);
$multilogopage = multi($count, $perpage, $page, "plugin.php?id=mini_link&type=website&action=more&typestyle=1&typeid=".$typeid);	
$type = DB::fetch_first("SELECT * FROM ".DB::table('plugin_mini_link_webtype'). " where id = ".$typeid);
$query = DB::query("SELECT * FROM ".DB::table('plugin_mini_link'). " where webtype = ".$typeid." AND shenhe = '1' ORDER BY displayorder DESC,id DESC LIMIT $start_limit, $perpage");
	$weblist = array();
	while($value = DB::fetch($query)){
	   $weblist[$value['id']] = $value;
	}
$weblist = dhtmlspecialchars($weblist);
$type = dhtmlspecialchars($type);
$title = $navtitle =$type['type']." - ".$config['t_title']." - ".$type['description'];
$metakeywords = $type['keyword'];
$metadescription = $type['description'];
if($_G['mobile']) {
	include template('mini_link:more');
} else {
	if ($style == '4'){
		if ($diyset == '1'){
	       include template('diy:more4:'.$_GET['id'].$_GET['typeid'], 0, 'source/plugin/mini_link/template/');
		}else{
	       include template('mini_link:more4');
	    }
    }else{
	    if ($diyset == '1'){
	       include template('diy:more:'.$_GET['id'].$_GET['typeid'], 0, 'source/plugin/mini_link/template/');
	    }else{
	       include template('mini_link:more');
	    }
	}
}
//From: d'.'is'.'m.ta'.'obao.com
?>