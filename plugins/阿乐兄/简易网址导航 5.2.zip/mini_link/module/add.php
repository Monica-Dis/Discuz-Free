<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
mini_link_getcache();
if($config['youkefabuset']==0){
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
}
if(submitcheck('submit')){
    $uid = intval($_G['uid']);	
    $web_name = strip_tags(daddslashes($_GET['webname']));
    $web_url = daddslashes(trim($_GET['weburl']));
        if(!preg_match('/^http(s)?:\\/\\/.+/',$web_url)){
            showmessage(lang('plugin/mini_link', 'wangzhicuowu'));
        }
    $weblogo = strip_tags(daddslashes($_GET['weblogo']));
	$webtype = intval($_GET['webtype']);
	$icon = intval($_GET['icon']);
    $color = strip_tags(daddslashes($_GET['color']));
    $bgcolor = strip_tags(daddslashes($_GET['bgcolor']));
    $displayorder = intval($_GET['displayorder']);
    $tuijian = intval($_GET['tuijian']);	
    if($config['fabushenhe']==0||$_G['groupid']==1|| in_array($_G['uid'], $admins)){
	    $shenhe = 1 ; 
    }else{ 
	    $shenhe = 0 ; 
    }	
    if(!$web_name){
	    showmessage(lang('plugin/mini_link', 'webnamebunengkong'),'plugin.php?id=mini_link&type=website&action=userlist&display=ok');
	}
	if(!$_GET['weburl']){
		showmessage(lang('plugin/mini_link', 'weburlbunengkong'),'plugin.php?id=mini_link&type=website&action=userlist&display=ok');
    }
	$weburl = DB::result_first("SELECT weburl FROM ".DB::table('plugin_mini_link'). " where weburl = '".$web_url."'");
	if(!$weburl){
        if($_FILES['file']['error']==0){
		    $imageinfo = getimagesize($_FILES["file"]['tmp_name']);
			if ($imageinfo[0] <= 0) {
                showmessage(lang('plugin/mini_link', 'zhiyunxu'));
			}
			$filesize = $_FILES['file']['size'] <= 204800 ;  
			$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
			$arr=explode(".", $_FILES["file"]["name"]);
			$hz=$arr[count($arr)-1];
			if(!in_array($hz, $filetype)){
				showmessage(lang('plugin/mini_link', 'tupiangeshibuzhengque'));	
			}
			$filepath = "source/plugin/mini_link/logo/".date("Ymd")."/";
			$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
			if(!file_exists($filepath)){ mkdir($filepath); }
			if($filesize){ 
				if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
					@unlink($_FILES['file']['tmp_name']);
				}
			}else{
				showmessage(lang('plugin/mini_link', 'chaochudaxiao'));	
			}
			$weblogo = "source/plugin/mini_link/logo/".date("Ymd")."/".$randname."";
        }
		DB::INSERT('plugin_mini_link',array('uid'=> $uid,'webname'=> $web_name,'weblogo'=> $weblogo,'weburl'=> $web_url,'webtype'=> $webtype,'icon'=> $icon,'color'=> $color,'bgcolor'=> $bgcolor,'shenhe'=> $shenhe,'tuijian'=> $tuijian,'displayorder'=> $displayorder));
		mini_link_updatacache();
	    if($shenhe==1){
			showmessage(lang('plugin/mini_link', 'tijiaook'),'plugin.php?id=mini_link');
        }else{
            showmessage(lang('plugin/mini_link', 'tijiaookdengdaishenhe'),'plugin.php?id=mini_link');
		}
	}else{
		showmessage(lang('plugin/mini_link', 'wangzhanyicunzai'));
	}
}else{
	include template('mini_link:add');
}
//From: d'.'is'.'m.ta'.'obao.com
?>