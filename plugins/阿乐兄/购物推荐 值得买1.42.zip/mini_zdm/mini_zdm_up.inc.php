<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once 'source/plugin/mini_zdm/class/upic.class.php';
$plyes=($_G['cache']['plugin']['mini_zdm']);
foreach($plyes as $key=>$value){ 
 $$key=$value;
}
$uploaddx=$picdx*1024;
$newpicwidth=1000;
if ($_FILES['file']['error']==0 && $_GET['formhash'] == FORMHASH) {
	 $picsize = $_FILES['file']['size'];
	 $imageinfo = getimagesize($_FILES['file']['tmp_name']);
		 if ($imageinfo[0] <= 0) {
             echo json_encode(array("error" =>lang('plugin/mini_zdm', 'tupiangeshibuzhengque')));
			 exit ;
		 }
     $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
	 $arr=explode(".", strtolower($_FILES['file']["name"]));
     $hz = $arr[count($arr) - 1];
         if (!in_array($hz, $filetype)) {
             echo json_encode(array("error" => lang('plugin/mini_zdm', 'tupiangeshibuzhengque')));
			 exit ;
         }
     $update = date('YmdHis') . rand(100, 999);
     $pics =$update. "." . $hz;
	 $img_dir = "source/plugin/mini_zdm/upimg/".date("Ymd")."/";
     if(!file_exists($img_dir)){
      mkdir($img_dir,0777,true);
     }
     $pic = $img_dir . $pics;
        if($picsize <= $uploaddx){
            if (@copy($_FILES['file']['tmp_name'], $pic) || @move_uploaded_file($_FILES['file']['tmp_name'], $pic)) {
             @unlink($_FILES['file']['tmp_name']);
            }
        }else{
             echo json_encode(array("error" =>lang('plugin/mini_zdm', 'tupiantaida')));
             exit ;
        }
		if ($imageinfo[0] > $newpicwidth) {
			new myThumbClass($pic,1,2,$pic,1,$newpicwidth); 
		}
	    echo json_encode(array("error" => "0", "pic" => $pic));
}
//From: Dism_taobao_com
?>