<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/discuzcode');
global $_G;
if(!isset($_G['cache']['plugin'])){ loadcache('plugin'); }
@extract($_G['cache']['plugin']['mini_zdm']);
!$_G['uid'] ? showmessage('not_loggedin', NULL, array(), array('login' => 1)) : '';
$uid = intval($_G['uid']);
if($_GET['option'] == 'reply'){//pinglunhuifu
		           $id = intval($_GET['did']);
                   $pl = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_post') . " WHERE id = '$id'");
				   	if($pl['uid']==$_G['uid']){
					   showmessage(lang('plugin/mini_zdm', 'bunenggeizijihuifu'), array(), array('alert' => error));
                     } 
	               $pl['message'] = discuzcode($pl['message']);
		if(submitcheck('applysubreply')){
		           if ($_G['groupid']=="1"){$display =1; }else{$display = intval($display) == 1 ? 1 : 0;}
		           $message = strip_tags(addslashes($_GET['message']),"<b><p><i><s>");
					DB::insert('plugin_mini_zdm_reply',array('id' => '','dpid' => $id,'reuid' => $uid,'reauthor' => $_G['username'],'remessage' => $message,'display' => $display,'dateline' => time()));
				    showmessage(lang('plugin/mini_zdm', 'tijiaochenggong'),dreferer());
		}
		include template('mini_zdm:reply');
}elseif($_GET['option'] == 'rereply'){//pinglunhuifu
		           $id = intval($_GET['reid']);
                   $pl = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_reply') . " WHERE id = '$id'");
				   	if($pl['reuid']==$_G['uid']){
					   showmessage(lang('plugin/mini_zdm', 'bunenggeizijihuifu'), array(), array('alert' => error));
                     } 
	               $reauthor = addslashes($pl['reauthor']);
	               $remessage = discuzcode($pl['remessage']);
	               $rereauthor = addslashes($_GET['rereauthor']);
	               $dpid = intval($_GET['dpid']);
	               $redpid = intval($_GET['redpid']);
		if(submitcheck('applysubrereply')){
		           if ($_G['groupid']=="1"){$display =1; }else{$display = intval($display) == 1 ? 1 : 0;}
		           $message = strip_tags(addslashes($_GET['message']),"<b><p><i><s>");
					DB::insert('plugin_mini_zdm_reply',array('id' => '','dpid' => $dpid,'reuid' => $uid,'reauthor' => $_G['username'],'redpid' => $redpid,'remessage' => $message,'display' => $display,'dateline' => time()));
				    showmessage(lang('plugin/mini_zdm', 'tijiaochenggong'),dreferer());
		}
		include template('mini_zdm:reply');
}elseif($_GET['option'] == 'shenhe'){
	if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        $id = intval($_GET['reid']);
	  if($_GET['formhash'] == FORMHASH) {
		DB::query("UPDATE ".DB::table('plugin_mini_zdm_reply')." SET display='1' WHERE id='$id'");
        showmessage(lang('plugin/mini_zdm', 'caozuochenggong'), dreferer());
      }
	}else{
		   showmessage(lang('plugin/mini_zdm', 'caozuocuowu'));
	}
}elseif($_GET['option'] == 'qxshenhe'){
	if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        $id = intval($_GET['reid']);
	  if($_GET['formhash'] == FORMHASH) {
		DB::query("UPDATE ".DB::table('plugin_mini_zdm_reply')." SET display='0' WHERE id='$id'");
        showmessage(lang('plugin/mini_zdm', 'caozuochenggong'), dreferer());
      }
	}else{
		   showmessage(lang('plugin/mini_zdm', 'caozuocuowu'));
	}
}elseif($_GET['option'] == 'del'){
	if($_G['groupid']==1||in_array($_G['uid'], $admins)){
	     $reid = intval($_GET['reid']);
         if($_GET['formhash'] == FORMHASH) {
              $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_mini_zdm_reply')." where id = '$reid'");
	            if($pl){
	               DB::delete('plugin_mini_zdm_reply',array('id'=> $reid));
	               showmessage(lang('plugin/mini_zdm', 'shanchuok'), dreferer());
	            }else{
	               showmessage(lang('plugin/mini_zdm', 'caozuocuowu'));
                }
         }
    }else{
		showmessage(lang('plugin/mini_zdm', 'wuquanxiancaozuo'), '', array(), array('alert' => right));
	}
}
//From: Dism_taobao_com
?>