<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
	CREATE TABLE IF NOT EXISTS `pre_plugin_mini_zdm_item` (
	  `id` int(11) NOT NULL auto_increment,
	  `diynum` int(11) NOT NULL,
	  `uid` int(11) NOT NULL,
	  `author` varchar(30) NOT NULL,
      `title` varchar(255) NOT NULL,
	  `cate` int(11) NOT NULL,
	  `pic` text NOT NULL,
      `yuanjia` varchar(50) NOT NULL,
      `xianjia` varchar(50) NOT NULL,
	  `shangjia` varchar(30) NOT NULL,
	  `url` text NOT NULL,
	  `info` text NOT NULL,
	  `begintime` int(11) NOT NULL,
	  `endtime` int(11) NOT NULL,
	  `biaoqian` varchar(255) NOT NULL,
	  `view` int(11) NOT NULL,
	  `jifen` int(11) NOT NULL,
	  `shoucangshu` int(11) NOT NULL,
      `dpcount` int(11) NOT NULL,
      `zhide` int(11) NOT NULL,
      `buzhide` int(11) NOT NULL,
      `tuijian` tinyint(4) NOT NULL,
	  `top` tinyint(4)  NOT NULL,
      `display` tinyint(4) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_mini_zdm_cate` (
	  `id` int(11) NOT NULL auto_increment,
	  `upid` int(11) NOT NULL,
	  `subid` text NOT NULL,
	  `subject` varchar(255) NOT NULL,
	  `displayorder` int(10) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_mini_zdm_post` (
   	  `id` int(11) NOT NULL auto_increment,
   	  `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
   	  `author` varchar(100) NOT NULL,
  	  `title` text NOT NULL,
  	  `message` text NOT NULL,
   	  `pay` int(11) NOT NULL,
   	  `moneytype` text NOT NULL,
  	  `display` tinyint(4) NOT NULL,
   	  `dateline` int(10) NOT NULL,
   	  PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_mini_zdm_reply` (
	  `id` int(11) NOT NULL auto_increment,
	  `itemid` int(11) NOT NULL,
	  `dpid` int(11) NOT NULL,
	  `redpid` int(11) NOT NULL,
	  `reuid` int(11) NOT NULL,
  	  `reauthor` varchar(30) NOT NULL,
  	  `remessage` text NOT NULL,
  	  `display` tinyint(4) NOT NULL,
 	  `dateline` int(10) NOT NULL,
      PRIMARY KEY  (`id`)
    ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_mini_zdm_dashang` (
   	  `id` int(11) NOT NULL auto_increment,
   	  `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
   	  `author` varchar(100) NOT NULL,
   	  `hsuid` int(11) NOT NULL,
   	  `hsauthor` varchar(100) NOT NULL,
  	  `title` text NOT NULL,
   	  `pay` int(11) NOT NULL,
   	  `moneytype` text NOT NULL,
   	  `dateline` int(10) NOT NULL,
   	  PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_mini_zdm_zhibuzhi` (
   	  `id` int(11) NOT NULL auto_increment,
 	  `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
  	  `zhide` tinyint(4) NOT NULL,
  	  `buzhide` tinyint(4) NOT NULL,
      PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_mini_zdm_favorites` (
   	  `id` int(11) NOT NULL auto_increment,
 	  `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
   	  `author` varchar(30) NOT NULL,
   	  `dateline` int(11) NOT NULL,
      PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_mini_zdm_img` (
	  `id` int(11) NOT NULL auto_increment,
	  `aid` int(11) NOT NULL,
	  `img` varchar(255) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
INSERT INTO `pre_plugin_mini_zdm_cate` (`id`, `upid`, `subid`, `subject`,`displayorder`) VALUES
(1, 0, '', '$installlang[cate1]',0),
(2, 0, '', '$installlang[cate2]',0),
(3, 0, '', '$installlang[cate3]',0),
(4, 0, '', '$installlang[cate4]',0),
(5, 0, '', '$installlang[cate5]',0),
(6, 0, '', '$installlang[cate6]',0),
(7, 0, '', '$installlang[cate7]',0),
(8, 0, '', '$installlang[cate8]',0),
(9, 0, '', '$installlang[cate9]',0);
EOF;
@unlink(DISCUZ_ROOT.'source/plugin/mini_zdm/discuz_plugin_mini_zdm.xml');
@unlink(DISCUZ_ROOT.'source/plugin/mini_zdm/discuz_plugin_mini_zdm_SC_GBK.xml');
@unlink(DISCUZ_ROOT.'source/plugin/mini_zdm/discuz_plugin_mini_zdm_SC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/mini_zdm/discuz_plugin_mini_zdm_TC_BIG5.xml');
@unlink(DISCUZ_ROOT.'source/plugin/mini_zdm/discuz_plugin_mini_zdm_TC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/mini_zdm/upgrade.php');
@unlink(DISCUZ_ROOT.'source/plugin/mini_zdm/install.php');
runquery($sql);
$finish =true;
?>