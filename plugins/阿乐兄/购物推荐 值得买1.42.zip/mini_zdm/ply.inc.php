<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
//From: Dism_taobao_com
?>
<script language="javascript">
document.write('<if' + 'rame src="https://dism.taobao.com/?@48286.developer" width="100%" height="1000" scrolling="yes" frameborder="0"></if' + 'rame>');		  
</script>;