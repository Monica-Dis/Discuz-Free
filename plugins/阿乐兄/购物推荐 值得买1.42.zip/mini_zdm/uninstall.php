<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
DROP TABLE IF EXISTS `pre_plugin_mini_zdm_item`;
DROP TABLE IF EXISTS `pre_plugin_mini_zdm_cate`;
DROP TABLE IF EXISTS `pre_plugin_mini_zdm_post`;
DROP TABLE IF EXISTS `pre_plugin_mini_zdm_reply`;
DROP TABLE IF EXISTS `pre_plugin_mini_zdm_dashang`;
DROP TABLE IF EXISTS `pre_plugin_mini_zdm_zhibuzhi`;
DROP TABLE IF EXISTS `pre_plugin_mini_zdm_favorites`;
DROP TABLE IF EXISTS `pre_plugin_mini_zdm_img`;
EOF;
runquery($sql);
$finish = TRUE;
?>