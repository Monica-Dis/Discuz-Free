<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once libfile('function/discuzcode');
require_once 'source/plugin/mini_zdm/function/function_core.php';
global $_G;
if (!isset($_G['cache']['plugin'])) {loadcache('plugin');}
@extract($_G['cache']['plugin']['mini_zdm']);
$menushangjia = parconfig($shangjia);
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
$appurl = $_G['siteurl'] . "plugin.php?id=mini_zdm";
$fabuset = unserialize($groups);
$djsheight = $liheight-18;
$navtitle = $t_title;
if (!$_GET['mod']) {
	$where="";
	if($_GET['key']){
	    $key=stripsearchkey($_GET['key']);
		$where="title like '%".addcslashes(addslashes($key), '%')."%' AND display!='0' AND";
		$keync=urlencode($key);
		$pageadd="&key=$keync";
    }elseif($_GET['biaoqian']){
	    $key=stripsearchkey($_GET['biaoqian']);
		$where="biaoqian like '%".addcslashes(addslashes($key), '%')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&biaoqian=$keync";
	}
    $cate_id = intval($_GET['a']);
    if ($cate_id) {
        $mcate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$cate_id'");
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id='$cate_id'");
        if ($subids) {
            $wb = "cate IN ($cate_id,$subids) AND";
        } else {
            $wb = "cate=$cate_id AND";
        }
        $pageadds = "&a=$cate_id";
        $av_d[$cate_id] = ' class="cur-on"';
    } else {
        $av_d[0] = ' class="cur-on"';
    }
    $sd = intval($_GET['b']);
       if($sd){ 
          $mcateb = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$sd'");
	      $wc="cate='$sd' AND"; 
	      $pageaddx="&b=$sd";
	      $av_d[$sd] = ' class="cur-on"'; 
       }else{
	      $av_d[0] = ' class="cur-on"';
       }
	$shangjia = intval($_GET['s']);
	if ($shangjia){
		$ss[] = "shangjia = '$shangjia'";
		$pageaddsj="&s=$shangjia";
		$sj_hover[$shangjia] = ' class="cur-on"'; 
        if ($menushangjia[$shangjia]) {$sjtitle=$menushangjia[$shangjia]." - ";}
	}
	if ($ss){ $sj = "" . implode(" AND ", $ss) . " AND"; }

    $list = intval($_GET['l']);
    if ($list==1){
		$pageaddl="&l=1";
    }else{
		$pageaddl="&l=0";
    }
	$uid=intval($_GET['uid']);
    if ($uid) {
		$where="uid='$uid' AND";
	    $keync=urlencode($uid);
	    $pageadd="&uid=$keync";
    }
	if($_GET['rq']){
		$px="view >'0' AND display!='0' ORDER BY view DESC"; $pageadd="&rq=rq";
        $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_item') . " WHERE $where $wb $wc $sj view >'0' AND display!='0' ");
	}
	elseif($_GET['tj']){
		$px="tuijian = '1' AND display!='0' ORDER BY dateline DESC"; $pageadd="&tj=t";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_item') . " WHERE $where $wb $wc $sj tuijian = '1' AND display!='0'");
	}elseif($_GET['wgq']){
		$px="endtime ='0' OR endtime > '$_G[timestamp]' AND display!='0' ORDER BY dateline DESC"; $pageadd="&wgq=wgq";
		$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_mini_zdm_item')." WHERE $where $wb $wc $sj endtime ='0' OR endtime > '$_G[timestamp]' AND display!='0'");
	}elseif($_GET['xsg']){
		$px="endtime > '$_G[timestamp]' AND endtime!='0' AND display!='0' ORDER BY endtime ASC"; $pageadd="&xsg=xsg";
		$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_mini_zdm_item')." WHERE $where $wb $wc $sj endtime > '$_G[timestamp]' AND endtime!='0' AND display!='0'");
	}elseif($_GET['ygq']){
		$px="endtime < '$_G[timestamp]' AND endtime!='0' AND display!='0' ORDER BY endtime DESC"; $pageadd="&ygq=ygq";
		$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_mini_zdm_item')." WHERE $where $wb $wc $sj endtime < '$_G[timestamp]' AND endtime!='0' AND display!='0'");
	}else{
		$px="display!='0' ORDER BY top DESC,diynum DESC,dateline DESC";
		$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_mini_zdm_item')." WHERE $where $wb $wc $sj display!='0'");
	}
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $eacha;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " WHERE $where $wb $wc $sj $px LIMIT $starts,$eacha");
        $mythread = $mythreads = array();
        while ($mythread = DB::fetch($query)) {
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$mythread[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$cate[upid]'");
                $mythread['cate'] = $cate['subject'];
                $mythread['cates'] = $cate_t['subject']."-".$cate['subject'];
	            $mythread['b'] = $cate['id'];
	            $mythread['a'] = $cate['upid'];
            } else {
                $mythread['cate'] = $cate['subject'];
		        $mythread['a'] = $cate['id'];
	            $mythread['b'] = '0';
            }
		    $mythread['title']=str_replace($key,"<font color='#ff0000'>$key</font>",$mythread['title']);
            $mythread['info'] = str_replace('&nbsp;','',strip_tags(discuzcode($mythread['info']),"<b><p><i><s>"));
			$mythread['shangjianame']=$menushangjia[$mythread['shangjia']];
            $mythreads[] = $mythread;
        }
    }
    $multis = "<div class='cl' style='margin:5px'>" . multi($counts, $eacha, $pages, $appurl . $pageadd . $pageadds . $pageaddbc . $pageaddsj . $pageaddl) . "</div>";

    $r_id = intval($_GET['a']);
    $subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id='$r_id'");
    if ($subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id IN ($subid) ORDER BY displayorder desc");
        while ($ros = DB::fetch($query)) {
            $locals[$ros['id']] = $ros;
        }
    }

	$query = DB::query("SELECT * FROM ".DB::table('plugin_mini_zdm_item')." WHERE tuijian ='1' AND display!='0' ORDER BY dateline DESC LIMIT 10");
	$tuijian = $tuijians = array();
	while($tuijian = DB::fetch($query)){
		$tuijians[] = $tuijian;
	}
	$query = DB::query("SELECT * FROM ".DB::table('plugin_mini_zdm_item')." WHERE view >'1' AND display!='0' ORDER BY view DESC LIMIT 10");
	$hot = $hots = array();
	while($hot = DB::fetch($query)){
		$hots[] = $hot;
	}
    if ($cate_id!='0') {
      if ($sd!='0') {
           $catenav = $mcate['subject'] . " - " . $mcateb['subject']. " - ";
      } else {
           $catenav = $mcate['subject']. " - ";
      }
    }
    $navtitle = $catenav.$sjtitle.$t_title;
    include template('mini_zdm:list');
} elseif ($_GET['mod'] == 'view') {
    $sid = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    $error = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " WHERE id = '$sid' and display!='0'");
    !$error ? showmessage(lang('plugin/mini_zdm', 'error') , "plugin.php?id=mini_zdm") : '';
    DB::query("update " . DB::table('plugin_mini_zdm_item') . " set view=view+1 where id='$sid'");
    $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " WHERE id='$sid'");
    $mythread['tuijianshu']= DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_mini_zdm_item')." WHERE uid='$mythread[uid]' AND  display!='0'");
    $biaoqian = explode(" ", $mythread['biaoqian']);
    $mythread['shangjianame']=$menushangjia[$mythread['shangjia']];
    //---------------------------------
    $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$mythread[cate]'");
    if ($cate['upid'] != 0) {
        $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$cate[upid]'");
        $mythread['cate_s'] = $cate_t['subject']." - ".$cate['subject'];
	    $mythread['b'] = $cate['id'];
	    $mythread['a'] = $cate['upid'];
    } else {
        $mythread['cate_s'] = $cate['subject'];
		$mythread['a'] = $cate['id'];
	    $mythread['b'] = '0';
    }
    //tuijian
    $query = DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " WHERE tuijian ='1' AND display!='0' ORDER BY dateline DESC LIMIT 10");
    $tuijian = $tuijians = array();
    while ($tuijian = DB::fetch($query)) {
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$tuijian[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$cate[upid]'");
            $tuijian['cate'] = $cate_t['subject']." - ".$cate['subject'];
        } else {
            $tuijian['cate'] = $cate['subject'];
        }
        $tuijians[] = $tuijian;
    }
    //renqi
    $query = DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " WHERE view >'0' AND display!='0' ORDER BY view DESC LIMIT 10");
    $hot = $hots = array();
    while ($hot = DB::fetch($query)) {
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$hot[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$cate[upid]'");
            $hot['cate'] = $cate_t['subject']." - ".$cate['subject'];
        } else {
            $hot['cate'] = $cate['subject'];
        }
        $hots[] = $hot;
    }
	//jinqi
	$query = DB::query("SELECT * FROM ".DB::table('plugin_mini_zdm_item')." WHERE uid ='$mythread[uid]' AND display!='0' ORDER BY dateline DESC LIMIT 10");
	$new = $news = array();
	while($new = DB::fetch($query)){
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$new[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$cate[upid]'");
            $new['cate'] = $cate_t['subject']." - ".$cate['subject'];
        } else {
            $new['cate'] = $cate['subject'];
        }
		$news[] = $new;
	}
	//zutu
	$query = DB::query("SELECT * FROM ".DB::table('plugin_mini_zdm_img')." WHERE aid='$sid' ORDER BY dateline DESC");
	$img = $imgs = array();
	while($img = DB::fetch($query)){
		$imgs[] = $img;
	}
	//liuyan
    if (submitcheck('applysubmit')) {
	  if($youkepinglunset==1){
	 	!$_G['uid'] ? $_G['username'] = $_G['clientip'] :'';
      }else{
	    if(!$_G['uid']){showmessage(lang('plugin/mini_zdm', 'youkewuquanxianpinglun'), array(), array('alert' => right));}
      }
	    $title = addslashes($mythread['title']);
        $hsuid = intval($mythread['uid']);
        $hsauthor = addslashes($mythread['author']);
		$message = strip_tags(addslashes($_GET['message']),"<b><p><i><s>");
		$pay = intval($_GET['pay']);
	 	$moneytype = intval($_GET['moneytype']);
        if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
            $display = 1;
        } else {
            $display = intval($display) == 1 ? 1 : 0;
        }
        foreach($_G['setting']['extcredits'] as $key => $value){
           $ext = 'extcredits'.$key;
           getuserprofile($ext);
           $mini_zdm['extcredits'][$key]['title'] = $value['title'];
           $mini_zdm['extcredits'][$key]['value'] = $_G['member'][$ext];
        }
        $jifenleixing = $mini_zdm['extcredits'][$moneytype]['title'];

	    if($pay<0){showmessage(lang('plugin/mini_zdm', 'dashangcuowu'), dreferer(), array(), array('alert'=> 'error','showdialog' => true));}
	          if($mini_zdm['extcredits'][$moneytype]['value']<$pay){
                    $tixing= lang('plugin/mini_zdm', 'jifenbuzu').$pay.$jifenleixing;
					showmessage(lang('plugin/mini_zdm', $tixing), dreferer());
              }else{
					updatemembercount($_G['uid'], array($moneytype => -$pay));
					updatemembercount($mythread['uid'], array($moneytype => +$pay));
					DB::insert('plugin_mini_zdm_post',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $title,'message' => $message,'pay' => $pay,'moneytype' => $jifenleixing,'display' => $display,'dateline' => time()));
					DB::insert('plugin_mini_zdm_dashang',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'author' => $_G['username'],'hsuid' => $hsuid,'hsauthor' => $hsauthor,'title' => $title,'pay' => $pay,'moneytype' => $jifenleixing,'dateline' => time()));
					$dpcount = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_post') . " WHERE sid='$sid' AND display!='0'");
					DB::query("update " . DB::table('plugin_mini_zdm_item') . " set jifen=jifen+$pay,dpcount=$dpcount where id='$sid'");
              }	
        if (intval($display) == 0) {
			        if (intval($_GET['pay']) > 0) {
                        showmessage(lang('plugin/mini_zdm', 'dashangneirongshenhe') , "plugin.php?id=mini_zdm&mod=view&sid=" . $sid, array() , array('alert' => right));
                    } else {
                        showmessage(lang('plugin/mini_zdm', 'pinglundengdaishenhezhong') , "plugin.php?id=mini_zdm&mod=view&sid=" . $sid, array() , array('alert' => right));
					}
        }else{
		      showmessage(lang('plugin/mini_zdm', 'tijiaochenggong') , "plugin.php?id=mini_zdm&mod=view&sid=" . $sid, array() , array('alert' => right));
        }
    }
    $count = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_post') . " WHERE sid='$sid' AND display!='0'");
    $page = intval($_GET['page']);
    $page = max($page, 1);
    $start = ($page - 1) * $each;
    if ($count) {
        $postquery = DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_post') . " WHERE sid='$sid' AND display!='0' ORDER BY dateline DESC LIMIT $start,$each");
        $postdata = array();
        $replydata = array();
        while ($pl = DB::fetch($postquery)) {
            $recount = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_reply') . " WHERE dpid = " . $pl['id'] . " AND display!='0'");
            $pl['count'] = $recount;
            $postdata[$pl['id']] = $pl;
            $replyquery = DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_reply') . " where dpid = " . $pl['id'] . " AND display!='0' ORDER BY dateline DESC LIMIT 5");
            while ($re = DB::fetch($replyquery)) {
                $reinfo = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_reply') . " WHERE id = " . $re['redpid'] . "");
                $re['rereauthor'] = $reinfo['reauthor'];
                $re['reremessage'] = $reinfo['remessage'];
                $replydata[$pl['id']][$re['id']] = $re;
            }
        }
    }
    $multi = "<div class='cl' style='margin:5px'>" . multi($count, $each, $page, 'plugin.php?id=mini_zdm&mod=view&sid=' . $sid . '#pinglunliebiao') . "</div>";
    //pinglunguanli
    if ($_GET['pinglun'] == 'del') {
        if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
            $sid = intval($_GET['sid']);
            $did = intval($_GET['did']);
            if ($_GET['formhash'] == FORMHASH) {
                DB::query("DELETE a,b FROM " . DB::table('plugin_mini_zdm_post') . " AS a LEFT JOIN " . DB::table('plugin_mini_zdm_reply') . " AS b ON a.id = b.dpid WHERE a.id = '$did' ");
                $dpcount = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_post') . " WHERE sid='$sid' AND display!='0'");
                DB::update('plugin_mini_zdm_item', array('dpcount' => $dpcount) , "id='$sid'");
                showmessage(lang('plugin/mini_zdm', 'shanchuok') , dreferer());
            }
        } else {
            showmessage(lang('plugin/mini_zdm', 'wuquanxiancaozuo') , '', array() , array('alert' => right));
        }
    }
    $navtitle = $mythread['title'] ." - " . $t_title;
    $metadescription = cutstr(strip_tags(discuzcode($mythread['info'])) , 100, '...');
    $metakeywords = $mythread['biaoqian'];
    include template('mini_zdm:view');   
} elseif ($_GET['mod'] == 'url') {
    $sid = intval($_GET['sid']);
    $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " WHERE id='$sid'");
    DB::query("update " . DB::table('plugin_mini_zdm_item') . " set view=view+1 where id='$sid'");
    if (!preg_match('/(http:\/\/)|(https:\/\/)/i', $mythread['url'])) {
      $mythread['url'] = "http://" . $mythread['url'];
    }
    header('Location: '.$mythread['url']);
} elseif ($_GET['mod'] == 'url2') {
    $sid = intval($_GET['sid']);
    $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " WHERE id='$sid'");
    if (!preg_match('/(http:\/\/)|(https:\/\/)/i', $mythread['url'])) {
      $mythread['url'] = "http://" . $mythread['url'];
    }
    header('Location: '.$mythread['url']);
} elseif ($_GET['mod'] == 'mobileview') {
    $sid = intval($_GET['sid']);
    $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " WHERE id='$sid'");
    include template('mini_zdm:mobileview');
} elseif ($_GET['mod'] == 'zhide') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $sid = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    $zhide = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_zhibuzhi') . " WHERE sid = '$sid' AND uid = '$uid'");
    if ($_GET['formhash'] == FORMHASH) {
        if ($zhide){
               DB::update('plugin_mini_zdm_zhibuzhi',array('zhide' => '1','buzhide' => '0'),"id='$zhide[id]'");
	    }else{
	           DB::insert('plugin_mini_zdm_zhibuzhi',array('sid' => $sid,'uid' => $uid,'zhide' =>'1','buzhide' =>'0'));
        } 
		$row = DB::fetch(DB::query("SELECT sum(zhide) AS 'zhide' , sum(buzhide) AS 'buzhide' FROM ".DB::table('plugin_mini_zdm_zhibuzhi')." WHERE sid='$sid'"));  
		 $zhide = intval($row['zhide']);
         $buzhide = intval($row['buzhide']);
	     DB::update('plugin_mini_zdm_item', array('zhide' => $zhide,'buzhide' => $buzhide), "id='$sid'");
         showmessage(lang('plugin/mini_zdm', 'toupiaochenggong'), dreferer(), array(), array('alert'=> 'right', 'locationtime' => true, 'showdialog' => 1));
    }
}elseif ($_GET['mod'] == 'buzhide') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $sid = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    $buzhide = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_zhibuzhi') . " WHERE sid = '$sid' AND uid = '$uid'");
    if ($_GET['formhash'] == FORMHASH) {
        if ($buzhide){
               DB::update('plugin_mini_zdm_zhibuzhi',array('zhide' => '0','buzhide' => '1'),"id='$buzhide[id]'");
	    }else{
	           DB::insert('plugin_mini_zdm_zhibuzhi',array('sid' => $sid,'uid' => $uid,'zhide' =>'0','buzhide' =>'1'));
        } 
		$row = DB::fetch(DB::query("SELECT sum(zhide) AS 'zhide' , sum(buzhide) AS 'buzhide' FROM ".DB::table('plugin_mini_zdm_zhibuzhi')." WHERE sid='$sid'"));  
		 $zhide = intval($row['zhide']);
         $buzhide = intval($row['buzhide']);
	     DB::update('plugin_mini_zdm_item', array('zhide' => $zhide,'buzhide' => $buzhide), "id='$sid'");
         showmessage(lang('plugin/mini_zdm', 'toupiaochenggong'), dreferer(), array(), array('alert'=> 'right', 'locationtime' => true, 'showdialog' => 1));
    } 
} elseif ($_GET['mod'] == 'reply') {
    $dpid = intval($_GET['dpid']);
    $pl = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_post') . " WHERE id = '$dpid' AND display!='0'");
    if (!$pl) {
        showmessage(lang('plugin/mini_zdm', 'error') , array() , array('alert' => error));
    }
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " WHERE id = '$pl[sid]'");
    $count = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_reply') . " WHERE dpid='$dpid' AND display!='0'");
    $page = intval($_GET['page']);
    $page = max($page, 1);
    $start = ($page - 1) * $each;
    if ($count) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_reply') . " WHERE dpid='$dpid' AND display!='0' ORDER BY dateline DESC LIMIT $start,$each");
        $pl = $pls = array();
        while ($pl = DB::fetch($query)) {
            $reinfo = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_reply') . " WHERE id = " . $pl['redpid'] . "");
            $pl['rereuid'] = $reinfo['reuid'];
            $pl['rereauthor'] = $reinfo['reauthor'];
            $pl['reremessage'] = $reinfo['remessage'];
            $pls[] = $pl;
        }
    }
    $multi = "<div class='cl' style='margin:5px'>" . multi($count, $each, $page, 'plugin.php?id=mini_zdm&mod=reply&dpid=' . $dpid . '') . "</div>";
    $navtitle = $item['title'] . " - " . $t_title;
    $metadescription = cutstr(strip_tags($item['info']) , 100, '...');
    $metakeywords = $item['biaoqian'];
    include template('mini_zdm:replylist'); 
} elseif ($_GET['mod'] == 'favorites') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $sid = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    if ($_GET['formhash'] == FORMHASH) {
        $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
        if ($favorites) {
            DB::delete('plugin_mini_zdm_favorites', array('sid' => $sid,'uid' => $uid));
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_item') . " SET shoucangshu = shoucangshu-1 WHERE `id` = '$sid'");
            showmessage(lang('plugin/mini_zdm', 'yiquxiaoshoucang') , '', array() , array('alert' => right));
        } else {
            DB::insert('plugin_mini_zdm_favorites', array('id' => '','sid' => $sid,'uid' => $uid,'author' => $_G['username'],'dateline' => time()));
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_item') . " SET shoucangshu = shoucangshu+1 WHERE `id` = '$sid'");
            showmessage(lang('plugin/mini_zdm', 'shoucangchenggong') , '', array() , array('alert' => right));
        }
    }
}
function parconfig($str) {
    $return = array();
    $array = explode("\n", str_replace("\r", "", $str));
    foreach ($array as $v) {
        $t = explode("=", $v);
        $t[0] = trim($t[0]);
        $return[$t[0]] = $t[1];
    }
    return $return;
}
function ubb($Text) {
      $Text=preg_replace("/\r/","<br>",$Text);
      $Text=preg_replace("/\[url=(.+?)\](.+?)\[\/url\]/is","<a href='\\1' target='_blank'>\\2</a>",$Text);
      $Text=preg_replace("/\[img\](.+?)\[\/img\]/is","<img src='\\1' onclick='zoom(this)'>",$Text);
      $Text=preg_replace("/\[img=(.+?),(.+?)\](.+?)\[\/img\]/is","<img src='\\3' width='\\1' height='\\2' onclick='zoom(this)'>",$Text);
      $Text=preg_replace("/\[color=(.+?)\](.+?)\[\/color\]/is","<font color=\\1>\\2</font>",$Text);
      $Text=preg_replace("/\[b\](.+?)\[\/b\]/is","<b>\\1</b>",$Text);
      return $Text;
}
function mubb($Text) {
      $Text=preg_replace("/\r/","<br>",$Text);
      $Text=preg_replace("/\[url=(.+?)\](.+?)\[\/url\]/is","<a href='\\1' target='_blank'>\\2</a>",$Text);
      $Text=preg_replace("/\[img\](.+?)\[\/img\]/is","<a href='\\1' target='_blank'><img src='\\1'></a>",$Text);
      $Text=preg_replace("/\[img=(.+?),(.+?)\](.+?)\[\/img\]/is","<a href='\\3' target='_blank'><img src='\\3' width='\\1' height='\\2'></a>",$Text);
      $Text=preg_replace("/\[color=(.+?)\](.+?)\[\/color\]/is","<font color=\\1>\\2</font>",$Text);
      $Text=preg_replace("/\[b\](.+?)\[\/b\]/is","<b>\\1</b>",$Text);
      return $Text;
}
//From: Dism_taobao_com
?>