<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');
@extract($_G['cache']['plugin']['mini_zdm']);
$p = $_GET['p'];
$p = $p ? $p : 'index';
$appurls = $_G['siteurl'] . "plugin.php?id=mini_zdm:mini_zdm_user";
$fabuset = unserialize($groups);
$mianshenhe = unserialize($mianshenhe);
$menushangjia= parconfig($shangjia);
$navtitle = $t_title;
$picdx = $picdx * 1024;
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
if ($p == 'index') {
        $uid = intval($_G['uid']);
        $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_item') . " WHERE uid='$uid'");
        $pager = intval($_GET['page']);
        $pager = max($pager, 1);
        $starts = ($pager - 1) * 15;
        if ($countr) {
            $rs = DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " WHERE uid='$uid' ORDER BY  display ASC,dateline DESC LIMIT $starts,15");
            while ($rw = DB::fetch($rs)) {
                $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$rw[cate]'"));
                if ($pa['upid'] != 0) {
                    $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$pa[upid]'");
                    $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
                } else {
                    $rw['cate'] = $pa['subject'];
                }
                $manylist[] = $rw;
            }
        }
        $appurl = $_G['siteurl'] . "plugin.php?id=mini_zdm:mini_zdm_user&p=index";
        $multir = "<div class='pages cl' style='margin-top:10px;'>" . multi($countr, 15, $pager, $appurl . $pageadd) . "</div>";
} elseif ($p == 'adminalllist') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
    } else {
        showmessage(lang('plugin/mini_zdm', 'wuquanxiancaozuo') , '', array() , array('alert' => right));
    }
    $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_item'));
    $pager = intval($_GET['page']);
    $pager = max($pager, 1);
    $starts = ($pager - 1) * 20;
    if ($countr) {
        $rs = DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " ORDER BY  display ASC, dateline DESC LIMIT $starts,20");
        while ($rw = DB::fetch($rs)) {
            $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$rw[cate]'"));
            if ($pa['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$pa[upid]'");
                $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
            } else {
                $rw['cate'] = $pa['subject'];
            }
            $manylist[] = $rw;
        }
    }
    $appurl = $_G['siteurl'] . "plugin.php?id=mini_zdm:mini_zdm_user&p=adminalllist";
    $multir = "<div class='pages cl' style='margin-top:10px;'>" . multi($countr, 20, $pager, $appurl . $pageadd) . "</div>";
    if (submitcheck('applysubmsh')) {
        $aid = intval($_GET['aid']);
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
			$aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_item') . " SET display='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/mini_zdm', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxsh')) {
        $aid = intval($_GET['aid']);
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
			$aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_item') . " SET display='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/mini_zdm', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmtj')) {
        $aid = intval($_GET['aid']);
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
			$aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_item') . " SET tuijian='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/mini_zdm', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxtj')) {
        $aid = intval($_GET['aid']);
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
			$aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_item') . " SET tuijian='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/mini_zdm', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmzd')) {
        $aid = intval($_GET['aid']);
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
			$aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_item') . " SET top='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/mini_zdm', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxzd')) {
        $aid = intval($_GET['aid']);
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
			$aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_item') . " SET top='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/mini_zdm', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmdel')) {
        $aid = intval($_GET['aid']);
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
			$aid = intval($aid);
            $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " WHERE id ='$aid'LIMIT 0 , 1");
            if ($active["pic"] != false) {
                unlink($active["pic"]);
            }
            $sql = "SELECT * FROM ".DB::table('plugin_mini_zdm_img')." WHERE aid = '$aid'";
	        $query = DB::query($sql);
	        $delz = $delzs = array();
	        while($delz = DB::fetch($query)){
		        if ($delz["img"]!=false){
			      unlink($delz["img"]);
		        }
		        $delzs[] = $delz;
	        }
            DB::query("DELETE a,b,c,d,e,f FROM " . DB::table('plugin_mini_zdm_item') . " AS a LEFT JOIN " . DB::table('plugin_mini_zdm_favorites') . " AS b ON a.id = b.sid LEFT JOIN " . DB::table('plugin_mini_zdm_img') . " AS c ON c.aid = a.id LEFT JOIN " . DB::table('plugin_mini_zdm_zhibuzhi') . " AS d ON d.sid = a.id LEFT JOIN " . DB::table('plugin_mini_zdm_post') . " AS e ON e.sid = a.id LEFT JOIN " . DB::table('plugin_mini_zdm_reply') . " AS f ON f.itemid = a.id WHERE a.id = '$aid' ");
            $nums++;
        }
        showmessage(lang('plugin/mini_zdm', 'shanchuok') , dreferer());
    } 
} elseif ($p == 'add') {
    $query = DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE upid='0' ORDER BY  displayorder DESC");
    while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;
    }
    $groups = unserialize($groups);
    if (!in_array($_G['groupid'], $groups)) {
        showmessage(lang('plugin/mini_zdm', 'wuquanxiancaozuo') , '', array() , array('login' => true));
    } else {
        if (submitcheck('applysubmit')) {
            //-----------------------------------------
            $uid = intval($_G['uid']);
            $title = addslashes(trim($_GET['title']));
            $pic = addslashes(trim($_GET['pic']));
            $cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
            $shangjia = addslashes(trim($_GET['shangjia']));
            $url = addslashes(trim($_GET['url']));
            $yuanjia = addslashes($_GET['yuanjia']);
            $xianjia = addslashes($_GET['xianjia']);
            $info = addslashes($_GET['info']);
            $begintime=strtotime($_GET['begintime']);
            $endtime=strtotime($_GET['endtime']);
            $biaoqian = addslashes($_GET['biaoqian']);
            $tuijian = intval($_GET['tuijian']);
            $top = intval($_GET['top']);
            if ($_G['groupid'] == "1" || in_array($_G['groupid'], $mianshenhe)) {
                $display = 1;
            } else {
                $display = 0;
            }
            $diynum = intval($_GET['diynum']);
            $timestamp = $_G['timestamp'];
            if ($_FILES['file']['error'] == 0) {
                $rand = date("YmdHis") . random(3, $numeric = 1);
                $filesize = $_FILES['file']['size'] <= $picdx;
                $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
                $arr = explode(".", $_FILES["file"]["name"]);
                $hz = $arr[count($arr) - 1];
                if (!in_array($hz, $filetype)) {
                    showmessage(lang('plugin/mini_zdm', 'tupiangeshibuzhengque'));
                }
                $filepath = "source/plugin/mini_zdm/logo/" . date("Ymd") . "/";
                $randname = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999) . "." . $hz;
                if (!file_exists($filepath)) {
                    mkdir($filepath);
                }
                if ($filesize) {
                    if (@copy($_FILES['file']['tmp_name'], $filepath . $randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath . $randname))) {
                        @unlink($_FILES['file']['tmp_name']);
                    }
                } else {
                    showmessage(lang('plugin/mini_zdm', 'chaochudaxiao'));
                }
                $pic = "source/plugin/mini_zdm/logo/" . date("Ymd") . "/" . $randname . "";
            }
            DB::insert('plugin_mini_zdm_item', array('id' => '','uid' => $uid,'author' => $_G['username'],'title' => $title,'pic' => $pic,'cate' => $cate,'shangjia' => $shangjia,'url' => $url,'yuanjia' => $yuanjia,'xianjia' => $xianjia,'info' => $info,'begintime' => $begintime,'endtime' => $endtime,'biaoqian' => $biaoqian,'tuijian' => $tuijian,'top' => $top,'display' => $display,'diynum' => $diynum,'dateline' => $timestamp));

		    $aid = DB::insert_id();
	 	    $countz = count($_GET['filelist']);
			     for($i=0;$i<$countz;$i++){
	                $img = daddslashes($_GET['filelist'][$i]);	
			        DB::query("INSERT INTO ".DB::table('plugin_mini_zdm_img')." ( `id` , `aid`, `img`,`dateline` ) VALUES (NULL , '$aid', '$img','$timestamp');");
			     }  
            if ($_G['groupid'] == "1" || in_array($_G['groupid'], $mianshenhe)) {
                showmessage(lang('plugin/mini_zdm', 'fabuchenggong') , 'plugin.php?id=mini_zdm:mini_zdm_user&p=index', array() , array('alert' => right));
            } else {
                for ($i = 0; $i < count($admins); $i++) {
                    $message = '<a href="plugin.php?id=mini_zdm&#58;mini_zdm_user&p=adminalllist" target="_blank">' . lang('plugin/mini_zdm', 'yonghufabuxinxinxi') . '</a>';
                    notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
                }
                showmessage(lang('plugin/mini_zdm', 'fabudengdaishenhe') , 'plugin.php?id=mini_zdm:mini_zdm_user&p=index', array() , array('alert' => right));
            }
        }
    } 
} elseif ($p == 'edit') {
    $id = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " WHERE id='$id'");
    $uid = intval($active['uid']);

	$imgsql = DB::query("SELECT * FROM ".DB::table('plugin_mini_zdm_img')." WHERE aid='$id' ORDER BY dateline DESC");
	$pser = $psers = array();
	while($pser = DB::fetch($imgsql)){
		$psers[] = $pser;
	}

    if ($active['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
    } else {
        showmessage(lang('plugin/mini_zdm', 'caozuocuowu') , '', array() , array('login' => true));
    }
    $cate = DB::result_first("SELECT upid FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id='$active[cate]'");
    if ($cate) {
        $catetwoshow = '<select name="cate_two" >';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE upid='$cate'");
        while ($row = DB::fetch($query)) {
            if ($row['id'] == $active['cate']) {
                $catetwoshow.= '<option value="' . $row['id'] . '" selected >' . $row['subject'] . '</option>';
            } else {
                $catetwoshow.= '<option value="' . $row['id'] . '">' . $row['subject'] . '</option>';
            }
        }
        $catetwoshow.= '</select>';
    } else {
        $cate = $active['cate'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE upid='0' ORDER BY  displayorder DESC");
    while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;
    }
    if (submitcheck('applysubmit')) {
        $title = addslashes(trim($_GET['title']));
        $pic = addslashes(trim($_GET['pic']));
        $cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
        $shangjia = addslashes(trim($_GET['shangjia']));
        $url = addslashes(trim($_GET['url']));
        $yuanjia= addslashes($_GET['yuanjia']);
        $xianjia = addslashes($_GET['xianjia']);
        $info = addslashes($_GET['info']);
        $begintime=strtotime($_GET['begintime']);
        $endtime=strtotime($_GET['endtime']);
        $biaoqian = addslashes($_GET['biaoqian']);
        $tuijian = intval($_GET['tuijian']);
        $top = intval($_GET['top']);
        if ($_G['groupid'] == "1" || in_array($_G['groupid'], $mianshenhe)) {
            $display = 1;
        } else {
            $display = 0;
        }
        $diynum = intval($_GET['diynum']);
        $timestamp = $_G['timestamp'];
        if ($_FILES['file']['error'] == 0) {
            if ($active["pic"] != false) {
                unlink($active["pic"]);
            }
            $rand = date("YmdHis") . random(3, $numeric = 1);
            $filesize = $_FILES['file']['size'] <= $picdx;
            $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
            $arr = explode(".", $_FILES["file"]["name"]);
            $hz = $arr[count($arr) - 1];
            if (!in_array($hz, $filetype)) {
                showmessage(lang('plugin/mini_zdm', 'tupiangeshibuzhengque'));
            }
            $filepath = "source/plugin/mini_zdm/logo/" . date("Ymd") . "/";
            $randname = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999) . "." . $hz;
            if (!file_exists($filepath)) {
                mkdir($filepath);
            }
            if ($filesize) {
                if (@copy($_FILES['file']['tmp_name'], $filepath . $randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath . $randname))) {
                    @unlink($_FILES['file']['tmp_name']);
                }
            } else {
                showmessage(lang('plugin/mini_zdm', 'chaochudaxiao'));
            }
            $pic = "source/plugin/mini_zdm/logo/" . date("Ymd") . "/" . $randname . "";
        }
        DB::update('plugin_mini_zdm_item', array('title' => $title,'pic' => $pic,'cate' => $cate,'shangjia' => $shangjia,'url' => $url,'yuanjia' => $yuanjia,'xianjia' => $xianjia,'info' => $info,'begintime' => $begintime,'endtime' => $endtime,'biaoqian' => $biaoqian,'tuijian' => $tuijian,'top' => $top,'display' => $display,'diynum' => $diynum) , "id='$id'");

        DB::query("delete from ".DB::table('plugin_mini_zdm_img')." where aid='$id'");
		$countz = count($_GET['filelist']);
			 for($i=0;$i<$countz;$i++){
			  $img = daddslashes($_GET['filelist'][$i]);
			  DB::query("INSERT INTO ".DB::table('plugin_mini_zdm_img')." ( `id` , `aid`,`img`,`dateline` ) VALUES (NULL , '$id', '$img','$timestamp');");
		     }  
        if ($_G['groupid'] == "1" || in_array($_G['groupid'], $mianshenhe)) {
            showmessage(lang('plugin/mini_zdm', 'gengxinok') , 'plugin.php?id=mini_zdm:mini_zdm_user&p=index', array() , array('alert' => right));
        } else {
            for ($i = 0; $i < count($admins); $i++) {
                $message = '<a href="plugin.php?id=mini_zdm&#58;mini_zdm_user&p=adminalllist" target="_blank">' . lang('plugin/mini_zdm', 'yonghufabuxinxinxi') . '</a>';
                notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
            }
            showmessage(lang('plugin/mini_zdm', 'gengxindaishenhe') , $appurls . "&p=edit&sid=" . $id, array() , array('alert' => right));
        }
    }
}elseif($p=='dsjl'){	
	$uid = intval($_G['uid']);
	$appurl=$_G['siteurl']."plugin.php?id=mini_zdm:mini_zdm_user";
	$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_mini_zdm_dashang')." WHERE uid='$uid' AND pay!='0'");
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 20;
if($counts) {
	$sql = "SELECT * FROM ".DB::table('plugin_mini_zdm_dashang')." WHERE uid = '$uid' AND pay!='0' ORDER BY dateline DESC LIMIT $starts,20";
	$query = DB::query($sql);
	$ds = $dss = array();
	while($ds = DB::fetch($query)){
		$dss[] = $ds;
	}
}
	$multis = "<div class='pages cl'>".multi($counts, 20, $pages, $appurl."&p=$p".$pageadd)."</div>";
}elseif($p=='hsjl'){	
	$uid = intval($_G['uid']);
	$appurl=$_G['siteurl']."plugin.php?id=mini_zdm:mini_zdm_user";
	$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_mini_zdm_dashang')." WHERE hsuid='$uid' AND pay!='0'");
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 20;
if($counts) {
	$sql = "SELECT * FROM ".DB::table('plugin_mini_zdm_dashang')." WHERE  hsuid='$uid' AND pay!='0' ORDER BY dateline DESC LIMIT $starts,20";
	$query = DB::query($sql);
	$hs = $hss = array();
	while($hs = DB::fetch($query)){
		$hss[] = $hs;
	}
}
	$multis = "<div class='pages cl'>".multi($counts, 20, $pages, $appurl."&p=$p".$pageadd)."</div>";   
} elseif ($p == 'favorites') {
    $uid = intval($_G['uid']);
    $appurl = $_G['siteurl'] . "plugin.php?id=mini_zdm:mini_zdm_user";
    $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_favorites') . " WHERE uid='$uid'");
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * 20;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " a, " . DB::table('plugin_mini_zdm_favorites') . " b WHERE b.uid='$uid' AND a.id = b.sid ORDER BY b.dateline DESC LIMIT $starts,20");
        $sc = $scs = array();
        while ($sc = DB::fetch($query)) {
            $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " where id = '$sc[sid]'");
            $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$item[cate]'"));
            if ($pa['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_cate') . " WHERE id = '$pa[upid]'");
                $sc['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
            } else {
                $sc['cate'] = $pa['subject'];
            }
            $scs[] = $sc;
        }
    }
    $multis = "<div class='pages cl'>" . multi($counts, 20, $pages, $appurl . "&p=$p" . $pageadd) . "</div>";
} elseif ($p == 'favoritesdel') {
    $id = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    if ($_GET['formhash'] == FORMHASH) {
        $favorite = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_favorites') . " WHERE id = '$id'");
        if ($favorite) {
            DB::query("DELETE FROM " . DB::table('plugin_mini_zdm_favorites') . " WHERE id = '$id' AND uid = '$uid'");
            showmessage(lang('plugin/mini_zdm', 'shanchuok') , dreferer());
        } else {
            showmessage(lang('plugin/mini_zdm', 'caozuocuowu'));
        }
    }
} elseif ($p == 'plshenheok') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $id = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
            $pl = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_post') . " where id = '$id'");
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_post') . " SET display='1' WHERE id='$id'");
			$dpcount = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_post') . " where sid='$pl[sid]' AND display!='0' ");
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_item') . " SET dpcount=$dpcount WHERE id='$pl[sid]'");
            showmessage(lang('plugin/mini_zdm', 'shenheok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/mini_zdm', 'caozuocuowu'));
    }
} elseif ($p == 'plqxshenhe') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $id = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
            $pl = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_post') . " where id = '$id'");
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_post') . " SET display='0' WHERE id='$id'");
			$dpcount = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_post') . " where sid='$pl[sid]' AND display!='0' ");
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_item') . " SET dpcount=$dpcount WHERE id='$pl[sid]'");
            showmessage(lang('plugin/mini_zdm', 'qxshenhe') , dreferer());
        }
    } else {
        showmessage(lang('plugin/mini_zdm', 'caozuocuowu'));
    }
} elseif ($p == 'adminpinglun') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $recountr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_reply'));
        $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_post'));
        $pager = intval($_GET['page']);
        $pager = max($pager, 1);
        $starts = ($pager - 1) * 20;
        if ($countr) {
            $rs = DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " a, " . DB::table('plugin_mini_zdm_post') . " b WHERE  a.id = b.sid ORDER BY b.dateline DESC LIMIT $starts,20");
            while ($rw = DB::fetch($rs)) {
                $recount = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_reply') . " WHERE dpid = " . $rw['id'] . " AND display!='0'");
                $rw['count'] = $recount;
                $manylist[] = $rw;
            }
        }
        $appurl = $_G['siteurl'] . "plugin.php?id=mini_zdm:mini_zdm_user&p=adminpinglun";
        $multir = "<div class='pages cl' style='margin-top:10px;'>" . multi($countr, 20, $pager, $appurl . $pageadd) . "</div>";
    } else {
        showmessage(lang('plugin/mini_zdm', 'caozuocuowu'));
    }
    if (submitcheck('applysubmsh')) {
        $aid = intval($_GET['aid']);
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $pl = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_post') . " where id = '$aid'");
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_post') . " SET display='1' WHERE id='$aid' LIMIT 1");
			$dpcount = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_post') . " where sid='$pl[sid]' AND display!='0' ");
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_item') . " SET dpcount=$dpcount WHERE id='$pl[sid]'");
            $nums++;
        }
        showmessage(lang('plugin/mini_zdm', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxsh')) {
        $aid = intval($_GET['aid']);
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $pl = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_post') . " where id = '$aid'");
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_post') . " SET display='0' WHERE id='$aid' LIMIT 1");
			$dpcount = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_post') . " where sid='$pl[sid]' AND display!='0' ");
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_item') . " SET dpcount=$dpcount WHERE id='$pl[sid]'");
            $nums++;
        }
        showmessage(lang('plugin/mini_zdm', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmdel')) {
        $aid = intval($_GET['aid']);
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $pl = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_post') . " where id = '$aid'");
            $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " where id = '$pl[sid]'");
            DB::delete('plugin_mini_zdm_post', array('id' => $aid));
            DB::delete('plugin_mini_zdm_reply', array('dpid' => $aid));
			$dpcount = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_post') . " where sid='$pl[sid]' AND display!='0' ");
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_item') . " SET dpcount=$dpcount WHERE id='$pl[sid]'");
            $nums++;
        }
        showmessage(lang('plugin/mini_zdm', 'shanchuok') , dreferer());
    }
} elseif ($p == 'shenheok') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $id = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_item') . " SET display='1' WHERE id='$id'");
            showmessage(lang('plugin/mini_zdm', 'shenheok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/mini_zdm', 'caozuocuowu'));
    }
} elseif ($p == 'qxshenhe') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $id = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_item') . " SET display='0' WHERE id='$id'");
            showmessage(lang('plugin/mini_zdm', 'qxshenhe') , dreferer());
        }
    } else {
        showmessage(lang('plugin/mini_zdm', 'caozuocuowu'));
    }
} elseif ($p == 'del') {
    $id = intval($_GET['sid']);
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        if ($_GET['formhash'] == FORMHASH) {
            $content = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " where id = '$id'");
            if ($content) {
                if ($content["pic"] != false) {
                    unlink($content["pic"]);
                }
	          $sql = "SELECT * FROM ".DB::table('plugin_mini_zdm_img')." WHERE aid = '$id'";
	          $query = DB::query($sql);
	          $delz = $delzs = array();
	          while($delz = DB::fetch($query)){
		         if ($delz["img"]!=false){
			        unlink($delz["img"]);
	             }
		         $delzs[] = $delz;
	          }

              DB::query("DELETE a,b,c,d,e,f FROM " . DB::table('plugin_mini_zdm_item') . " AS a LEFT JOIN " . DB::table('plugin_mini_zdm_favorites') . " AS b ON a.id = b.sid LEFT JOIN " . DB::table('plugin_mini_zdm_img') . " AS c ON c.aid = a.id LEFT JOIN " . DB::table('plugin_mini_zdm_zhibuzhi') . " AS d ON d.sid = a.id LEFT JOIN " . DB::table('plugin_mini_zdm_post') . " AS e ON e.sid = a.id LEFT JOIN " . DB::table('plugin_mini_zdm_reply') . " AS f ON f.itemid = a.id WHERE a.id = '$id' ");
                showmessage(lang('plugin/mini_zdm', 'shanchuok') , dreferer());
            } else {
                showmessage(lang('plugin/mini_zdm', 'caozuocuowu'));
            }
        }
    } else {
        $uid = intval($_G['uid']);
        if ($_GET['formhash'] == FORMHASH) {
            $content = DB::fetch_first("SELECT * FROM " . DB::table('plugin_mini_zdm_item') . " WHERE id ='$id' AND uid='$uid'");
            if ($content) {
                if ($content['uid'] != $uid) {
                    showmessage(lang('plugin/mini_zdm', 'caozuocuowu') , '', array() , array('login' => true));
                }
                if ($content["pic"] != false) {
                    unlink($content["pic"]);
                }
	          $sql = "SELECT * FROM ".DB::table('plugin_mini_zdm_img')." WHERE aid = '$id'";
	          $query = DB::query($sql);
	          $delz = $delzs = array();
	          while($delz = DB::fetch($query)){
		         if ($delz["img"]!=false){
			        unlink($delz["img"]);
	             }
		         $delzs[] = $delz;
	          }
                DB::query("DELETE a,b,c,d,e,f FROM " . DB::table('plugin_mini_zdm_item') . " AS a LEFT JOIN " . DB::table('plugin_mini_zdm_favorites') . " AS b ON a.id = b.sid LEFT JOIN " . DB::table('plugin_mini_zdm_img') . " AS c ON c.aid = a.id LEFT JOIN " . DB::table('plugin_mini_zdm_zhibuzhi') . " AS d ON d.sid = a.id LEFT JOIN " . DB::table('plugin_mini_zdm_post') . " AS e ON e.sid = a.id LEFT JOIN " . DB::table('plugin_mini_zdm_reply') . " AS f ON f.itemid = a.id WHERE a.id = '$id' ");
                showmessage(lang('plugin/mini_zdm', 'shanchuok') , dreferer());
            } else {
                showmessage(lang('plugin/mini_zdm', 'caozuocuowu'));
            }
        }
    }
} elseif ($p == 'adminreply') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $plcount = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_post'));
        $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_mini_zdm_reply'));
        $pager = intval($_GET['page']);
        $pager = max($pager, 1);
        $starts = ($pager - 1) * 20;
        if ($countr) {
            $rs = DB::query("SELECT * FROM " . DB::table('plugin_mini_zdm_reply') . " ORDER BY dateline DESC LIMIT $starts,20");
            while ($rw = DB::fetch($rs)) {
                $manylist[] = $rw;
            }
        }
        $appurl = $_G['siteurl'] . "plugin.php?id=mini_zdm:mini_zdm_user&p=adminreply";
        $multir = "<div class='pages cl' style='margin-top:10px;'>" . multi($countr, 20, $pager, $appurl . $pageadd) . "</div>";
    } else {
        showmessage(lang('plugin/mini_zdm', 'caozuocuowu'));
    }
    if (submitcheck('applysubmsh')) {
        $aid = intval($_GET['aid']);
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_reply') . " SET display='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/mini_zdm', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxsh')) {
        $aid = intval($_GET['aid']);
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            DB::query("UPDATE " . DB::table('plugin_mini_zdm_reply') . " SET display='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/mini_zdm', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmdel')) {
        $aid = intval($_GET['aid']);
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            DB::delete('plugin_mini_zdm_reply', array(
                'id' => $aid
            ));
            $nums++;
        }
        showmessage(lang('plugin/mini_zdm', 'shanchuok') , dreferer());
    }
}
include (template("mini_zdm:mini_zdm_user"));
function parconfig($str) {
    $return = array();
    $array = explode("\n", str_replace("\r", "", $str));
    foreach ($array as $v) {
        $t = explode("=", $v);
        $t[0] = trim($t[0]);
        $return[$t[0]] = $t[1];
    }
    return $return;
}
//From: Dism_taobao_com
?>