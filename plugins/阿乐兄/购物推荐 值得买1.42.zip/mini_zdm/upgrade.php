<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOT
EOT;
@unlink(DISCUZ_ROOT.'source/plugin/mini_zdm/discuz_plugin_mini_zdm_SC_GBK.xml');
@unlink(DISCUZ_ROOT.'source/plugin/mini_zdm/discuz_plugin_mini_zdm_SC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/mini_zdm/discuz_plugin_mini_zdm_TC_BIG5.xml');
@unlink(DISCUZ_ROOT.'source/plugin/mini_zdm/discuz_plugin_mini_zdm_TC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/mini_zdm/install.php');
@unlink(DISCUZ_ROOT.'source/plugin/mini_zdm/upgrade.php');
runquery($sql);
$finish = TRUE;
?>