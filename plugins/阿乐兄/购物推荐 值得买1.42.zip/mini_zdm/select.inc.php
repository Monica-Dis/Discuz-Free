<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	$action = addslashes($_GET['action']);
	$bl_name= addslashes($_GET['bl']);
		$lid = intval($_GET['lid']);
		$show = '';
		if($lid) {
			$subid = DB::result_first("SELECT subid FROM ".DB::table('plugin_mini_zdm_cate')." WHERE id='$lid'");
			if($subid) {
				$show = '<select class="ps" name="'.$bl_name.'" id="'.$bl_name.'"><option value=""></option>';
				$query = DB::query("SELECT * FROM ".DB::table('plugin_mini_zdm_cate')." WHERE id IN ({$subid}) ORDER BY displayorder desc");
				while($row = DB::fetch($query)) {
					$show .= '<option value="'.$row['id'].'">'.$row['subject'].'</option>';
				}
				$show .= '</select>';
			} else {
				$show = '';
			}
		}
include template("mini_zdm:select");
?>