<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require DISCUZ_ROOT . './source/plugin/faxian_weixin/class/common.class.php';

$IncludePath = DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';
if(file_exists($IncludePath))
{
    require ($IncludePath);
}else{
	require_once DISCUZ_ROOT . './source/plugin/faxian_weixin/class/wechat.lib.class.php';
}

require libfile('function/member');
require libfile('class/member');


if(submitcheck('loginsubmit'))
{
	$result = userlogin($_GET['username'], $_GET['password'], $_GET['questionid'], $_GET['answer'], 'auto', $_G['clientip']);
	if(!empty($result['status']) && $_GET['openid'])
	{
		WeChatHook::bindOpenId($result['ucresult']['uid'], $_GET['openid'], 0);
		C::t('#faxian_weixin#faxian_weixin_authcode')->delete($_GET['authcode']);
	}
	$ctl_obj = new logging_ctl();
	$_G['setting']['seccodestatus'] = 0;
	$ctl_obj->on_login();
	showmessage('faxian_weixin:WeChatBindSuccess', urldecode($_GET['referer']));
}

if(submitcheck('regsubmit'))
{
	$ctl_obj = new register_ctl();
	$ctl_obj->setting = $_G['setting'];
	$username = trim($_GET[''.$ctl_obj->setting['reginput']['username']]);
	$_GET['password'] = $_GET[''.$ctl_obj->setting['reginput']['password']];
	$_GET['password2'] = $_GET[''.$ctl_obj->setting['reginput']['password2']];
	$_GET['email'] = $_GET[''.$ctl_obj->setting['reginput']['email']];
	
    $usernamelen = dstrlen($username);
	if($usernamelen < 3)
	{
		showmessage('profile_username_tooshort');
	} elseif($usernamelen > 15)
	{
		showmessage('profile_username_toolong');
	}		
	if(uc_get_user(addslashes($username)) && !C::t('common_member')->fetch_uid_by_username($username) && !C::t('common_member_archive')->fetch_uid_by_username($username))
	{
	    showmessage('profile_username_duplicate');
	}
	if($ctl_obj->setting['pwlength'])
	{
		if(strlen($_GET['password']) < $ctl_obj->setting['pwlength'])
		{
			showmessage('profile_password_tooshort', '', array('pwlength' => $ctl_obj->setting['pwlength']));
		}
	}
	
	if($ctl_obj->setting['strongpw'])
	{
		$strongpw_str = array();
		if(in_array(1, $ctl_obj->setting['strongpw']) && !preg_match("/\d+/", $_GET['password'])) {
			$strongpw_str[] = lang('member/template', 'strongpw_1');
		}
		if(in_array(2, $ctl_obj->setting['strongpw']) && !preg_match("/[a-z]+/", $_GET['password'])) {
			$strongpw_str[] = lang('member/template', 'strongpw_2');
		}
		if(in_array(3, $ctl_obj->setting['strongpw']) && !preg_match("/[A-Z]+/", $_GET['password'])) {
			$strongpw_str[] = lang('member/template', 'strongpw_3');
		}
		if(in_array(4, $ctl_obj->setting['strongpw']) && !preg_match("/[^a-zA-z0-9]+/", $_GET['password'])) {
			$strongpw_str[] = lang('member/template', 'strongpw_4');
		}
		if($strongpw_str) {
			showmessage(lang('member/template', 'password_weak').implode(',', $strongpw_str));
		}
	}
	
	$email = strtolower(trim($_GET['email']));
	if($_GET['password'] !== $_GET['password2'])
	{
		showmessage('profile_passwd_notmatch');
	}
	if(!$_GET['password'] || $_GET['password'] != addslashes($_GET['password']))
	{
		showmessage('profile_passwd_illegal');
	}
	$password = $_GET['password'];
	
	$censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($ctl_obj->setting['censoruser'] = trim($ctl_obj->setting['censoruser'])), '/')).')$/i';
	if($ctl_obj->setting['censoruser'] && @preg_match($censorexp, $username))
	{
		showmessage('profile_username_protect');
	}
	
	$uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
	if($uid <= 0) {
		if($uid == -1) {
			showmessage('profile_username_illegal');
		} elseif($uid == -2) {
			showmessage('profile_username_protect');
		} elseif($uid == -3) {
			showmessage('profile_username_duplicate');
		} elseif($uid == -4) {
			showmessage('profile_email_illegal');
		} elseif($uid == -5) {
			showmessage('profile_email_domain_illegal');
		} elseif($uid == -6) {
			showmessage('profile_email_duplicate');
		} else {
			showmessage('undefined_action');
		}
	}
	
	$password = md5(random(10));
    if($invite && $ctl_obj->setting['inviteconfig']['invitegroupid'])
	{
		$groupinfo['groupid'] = $ctl_obj->setting['inviteconfig']['invitegroupid'];
	}
	
	$profile = array();
	if($uid)
	{
	    WeChatHook::bindOpenId($uid, $_GET['openid'], 1);
		C::t('#faxian_weixin#faxian_weixin_authcode')->delete($_GET['authcode']);
		
		$profile = array(
			'gender' => intval($_GET['sex']),
			'resideprovince' => $_GET['province'],
			'residecity' => $_GET['city']
		);
		
		if($_GET['headimgurl']){
			$headimg = dfsockopen($_GET['headimgurl']); 
			if($headimg){
				require_once libfile('class/image');
				$image = new image();
				$ucenterurl = substr(strrchr($_G['setting']['ucenterurl'], '/'), 1);
				$avatartype = array('big'=>250, 'middle'=>120, 'small'=>48);
				$uids = sprintf("%09d", $uid);
				foreach($avatartype as $type => $v){
					$dir1 = substr($uids, 0, 3);
					$dir2 = substr($uids, 3, 2);
					$dir3 = substr($uids, 5, 2);
					$file = $ucenterurl.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uids, -2).($real ? '_real' : '').'_avatar_'.$type.'.jpg';
					COMMON::mkdir_by_uid($uid,$ucenterurl.'/data/avatar/');
					$fp = @fopen($file, 'w');
					@fwrite($fp, $headimg);
					@fclose($fp);
					$image->Thumb($file, '', $v, $v, 1, 1);
				}
				C::t('common_member')->update($uid, array('avatarstatus' => 1));
			}
		}
	}
	
	if($ctl_obj->setting['inviteconfig']['invitegroupid'])
	{
		$groupinfo['groupid'] = $ctl_obj->setting['inviteconfig']['invitegroupid'];
	}
	
	$init_arr = array('credits' => explode(',', $ctl_obj->setting['initcredits']), 'profile'=>$profile, 'emailstatus' => 0);
	C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupinfo['groupid'], $init_arr);
		
	if($ctl_obj->setting['regverify'] == 2)
	{
		C::t('common_member_validate')->insert(array(
			'uid' => $uid,
			'submitdate' => $_G['timestamp'],
			'moddate' => 0,
			'admin' => '',
			'submittimes' => 1,
			'status' => 0,
			'message' => '',
			'remark' => '',
		), false, true);
		manage_addnotify('verifyuser');
	}
	
	setloginstatus(array(
		'uid' => $uid,
		'username' => $_G['username'],
		'password' => $password,
		'groupid' => $groupinfo['groupid'],
	), 0);
	include_once libfile('function/stat');
	updatestat('register');
	
	showmessage('faxian_weixin:WeChatRegSuccessTip', urldecode($_GET['referer']));
}


$ctl_obj = new register_ctl();

$code = intval($_GET['code']);
$authcode = C::t('#faxian_weixin#faxian_weixin_authcode')->fetch_by_code($code);

if(!$authcode){
	showmessage('Authcode Error');
}

$setting = (array)unserialize($_G['setting']['faxian_weixin']);
$WeChatClient = new WeChatClient($setting['wechat']['appid'], $setting['wechat']['appsecret']);

if($authcode['token'])
{
	$wxinfo = $WeChatClient->getUserInfoByAuth($authcode['token'], $authcode['openid'], 'zh_CN');
}else{
	$wxinfo = $WeChatClient->getUserInfoById($authcode['openid'], 'zh_CN');
}

$wxinfo['authcode'] = $authcode['sid'];
$wxinfo['openid'] = $authcode['openid'];
$wxinfo['nickname'] = WeChatEmoji::clear($wxinfo['nickname']);
$wxinfo['province'] = WeChatEmoji::clear($wxinfo['province']);
$wxinfo['city'] = WeChatEmoji::clear($wxinfo['city']);

$regex = "/\ |\^|\&|\*|\(|\)|\+|\<|\>|\?|\,|\'/";
$wxinfo['nickname'] = preg_replace($regex, '_', $wxinfo['nickname'], -1);

$ctl_obj->wechatmp = $wxinfo;
$ctl_obj->setting = $_G['setting'];
$ctl_obj->template = 'faxian_weixin:bind';
$ctl_obj->on_register();

?>