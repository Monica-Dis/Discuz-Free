<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class FaxianResponse
{
    private static $from;
	private static $data;
	private static $response;
	
	public function __construct()
	{
		global $_G;
	    self::$response = (array)unserialize($_G['setting']['faxian_weixin_reply']);
	}
	
	/*文本类型事件*/
	public static function text($param)
	{
		global $_G;
		list($data) = $param;
		self::$from = $data['from'];
		self::$data = $data;

		$data['content'] = diconv($data['content'], 'UTF-8');

		/*取出自动回复列表数组*/
		foreach(self::$response['reply'] as $val)
		{
            if(preg_match("/".dstripslashes($val['name'])."/", $data['content']))
			{
				self::_ReplyType($val, 'receiveMsg::text', $param);
				break;
			}
		}
		
		/*登录校验*/
		if(is_numeric($data['content']))
		{
			$authcode = C::t('#faxian_weixin#faxian_weixin_authcode')->fetch_by_code($data['content']);
			if($authcode)
			{
				C::t('#faxian_weixin#faxian_weixin_authcode')->update($authcode['sid'], array('openid' => $data['from']));
				
				if($authcode['mod'] == 'bind')
				{
					$wechatuser = C::t('#faxian_weixin#common_member_wechat')->fetch_by_openid($data['from']);
					if(!$wechatuser)
					{
						WeChatHook::bindOpenId($authcode['uid'], $data['from'], 2);
						echo WeChatServer::getXml4Txt(lang('plugin/faxian_weixin', 'WeChatBindSuccess'));
				        exit;
					}else{
						echo WeChatServer::getXml4Txt(lang('plugin/faxian_weixin', 'occupied'));
				        exit;
					}
				}
				
				if(!$authcode['type'])
				{
					echo WeChatServer::getXml4Txt(lang('plugin/faxian_weixin', 'CheckSuccess'));
				    exit;
				}
				
				$url = $_G['siteurl'].'plugin.php?id=faxian_weixin:login&check='.$authcode['code'];
				echo WeChatServer::getXml4Txt(lang('plugin/faxian_weixin', 'CheckSuccess_mobile', array('url'=>$url)));
				exit;
			}
		}

		/*无匹配关键词*/
		!self::$response['unanswerable']['content'] && self::$response['unanswerable']['content'] = lang('plugin/faxian_weixin', 'unanswerable');
		self::_ReplyType(self::$response['unanswerable'], 'receiveMsg::text', $param);
	}
	
    /*菜单点击事件*/
	public static function click($param)
	{
		global $_G;
		list($data) = $param;
		self::$from = $data['from'];
		self::$data = $data;
	    
		$click = explode('_',$data['key']);
		if(in_array($click[0], array('resource', 'text')))/*如果是图文素材或文字*/
		{
			$res['type'] = $click[0];
			if($res['type'] == 'text'){
				$res['content'] = diconv($click[1], 'UTF-8');
			}else{
				unset($click[0]);
			    $res['content'] = $click;
			}
			self::_ReplyType($res);
		}else{/*否则调用自动回复关键词*/
			$param['content'] = $data['key'];
			self::text($param);
		}
	}
	
    /*用户关注事件*/
	public static function subscribe($param)
	{
		global $_G;
		list($data) = $param;
		self::$from = $data['from'];
		self::$data = $data;
		
		self::$response['receiveEvent::subscribe'] && self::_ReplyType(self::$response['receiveEvent::subscribe'], 'receiveEvent::subscribe', $param);
	}
	
    /*取消关注事件*/
	public static function unsubscribe($param)
	{
		global $_G;
		list($data) = $param;
		self::$from = $data['from'];
		self::$data = $data;
		
		self::$response['receiveEvent::unsubscribe'] && self::_ReplyType(self::$response['receiveEvent::unsubscribe'], 'receiveEvent::unsubscribe', $param);
	}
	
	/*扫描二维码事件*/
	public static function scan($param)
	{
		global $_G;
		list($data) = $param;
		self::$from = $data['from'];
		self::$data = $data;
		
		self::$response['receiveEvent::scan'] && self::_ReplyType(self::$response['receiveEvent::scan'], 'receiveEvent::scan', $param);
	}
	
	/*上报地理位置事件*/
	public static function location($param)
	{
		global $_G;
		list($data) = $param;
		self::$from = $data['from'];
		self::$data = $data;
		
		self::$response['receiveEvent::location'] && self::_ReplyType(self::$response['receiveEvent::location'], 'receiveEvent::location', $param);
	}
	
	/*图片消息*/
	public static function image($param)
	{
		global $_G;
		list($data) = $param;
		self::$from = $data['from'];
		self::$data = $data;

		self::$response['receiveMsg::image'] && self::_ReplyType(self::$response['receiveMsg::image'], 'receiveMsg::image', $param);
	}
	
	/*视频消息*/
	public static function video($param)
	{
		global $_G;
		list($data) = $param;
		self::$from = $data['from'];
		self::$data = $data;
		
		self::$response['receiveMsg::video'] && self::_ReplyType(self::$response['receiveMsg::video'], 'receiveMsg::video', $param);
	}
	
	/*链接消息*/
	public static function link($param)
	{
		global $_G;
		list($data) = $param;
		self::$from = $data['from'];
		self::$data = $data;
		
		self::$response['receiveMsg::link'] && self::_ReplyType(self::$response['receiveMsg::link'], 'receiveMsg::link', $param);
	}
	
	/*语音消息*/
	public static function voice($param)
	{
		global $_G;
		list($data) = $param;
		self::$from = $data['from'];
		self::$data = $data;
		
		self::$response['receiveMsg::voice'] && self::_ReplyType(self::$response['receiveMsg::voice'], 'receiveMsg::voice', $param);
	}
	
	/*=======================自定义函数=======================*/
	
	/*判断回复类型*/
	public static function _ReplyType($c, $method)
	{
		global $_G;
		if($c['type'] == 'resource')/*回复图文素材*/
		{
			self::_GetResource($c['content']);
		}elseif($c['type'] == 'text')/*文本*/
		{
			if(!$c['content'])
			{
		        return;
		    }
			echo WeChatServer::getXml4Txt($c['content']);
			exit;
		}elseif($c['type'] == 'thirdparty')/*转发第三方接口*/
		{
			if($c['content']['url'] && $c['content']['token'])
			{
				$options = array(
					'http' => array(
						'method' => 'POST',
						'header'  => 'Content-type: application/x-www-form-urlencoded',
						'content' => file_get_contents("php://input"),
					),
				);
				$token = $c['content']['token'];
				$tmpArr = array($token, $_GET['timestamp'], $_GET['nonce']);
				sort($tmpArr, SORT_STRING);
				$tmpStr = sha1(implode($tmpArr));
				echo dfsockopen($c['content']['url'].(strpos($c['content']['url'],'?') ? '&' : '?').'signature='.$tmpStr.'&timestamp='.$_GET['timestamp'].'&nonce='.$_GET['nonce'], false, stream_context_create($options));
				exit;
			}
		}elseif(strlen($c['type']) == 32 && $method)/*映射到其他插件，主要是用于整合其他微信插件(必须是标准的微信登录插件接口)*/
		{
			$ResponseList = self::_GetResponse($method);
			$interface = $ResponseList[$c['type']];
			if(!empty($interface) && is_array($interface))
			{
				$param = func_get_args();
				require_once DISCUZ_ROOT . './source/plugin/'.$interface['plugin'].'/'.$interface['include'];
				$class = new $interface['class']();
				call_user_func(array($class, $interface['method']), $param[2]);
				exit;
			}
		}
	}
	
	/*获取指定图文素材*/
	public static function _GetResource($data = array())
	{
		global $_G;

        $wherearr[] = DB::field('rid', $data, 'in');
		foreach(C::t('#faxian_weixin#faxian_weixin_resource')->fetch_all_by_search($wherearr, NULL, NULL, 0, 10) as  $val)
		{
			$list[] = array(
				'title' => $val['title'],
				'desc' => $val['content'],
				'pic' => substr($val['cover'] , 0 , 4) == 'http' ? $val['cover'] : $_G['setting']['attachurl'].'common/'.$val['cover'],
				'url' => self::_AddOpenid($val['link'],self::$data),
			);
		}
		echo WeChatServer::getXml4RichMsgByArray($list);
		exit;
	}
	
	/*追加openid到url*/
	private static function _AddOpenid($url, $data)
	{
		global $_G;
        $key = array(
			'key' => urlencode(base64_encode(authcode($data['from'], 'ENCODE', $_G['config']['security']['authkey']))),
			'to' => $data['to']
		);
		$url = strpos($url, "?") ? $url."&" : $url.'?';
		return $url.http_build_query($key);
	}
	
	/*获取嵌入点数组*/
	private static function _GetResponse($type)
	{
		global $_G;
		if ($type)
		{
			$wechatresponse = unserialize($_G['setting']['wechatresponse']);
			$wechatresponseExts = unserialize($_G['setting']['wechatresponseExts']);
			foreach($wechatresponse as $k => $v)
			{
				if($k == $type)
				{
					$v['key'] = $k;
					$name = md5(implode('', $v));
				    $response[$name] = $v;
				}
			}
			foreach($wechatresponseExts as $v)
			{
				foreach($v as $k => $x)
				{
					if($k == $type)
					{
					    $x['key'] = $k;
						$name = md5(implode('', $x));
				        $response[$name] = $x;
				    }
				}
			}
			return $response;
		} 
	}
	
}
//From: Dism_taobao_com
?>