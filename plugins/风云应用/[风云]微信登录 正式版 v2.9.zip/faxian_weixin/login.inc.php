<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require DISCUZ_ROOT . './source/plugin/faxian_weixin/class/common.class.php';

$IncludePath = DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';
if(file_exists($IncludePath))
{
    require ($IncludePath);
}else{
	require_once DISCUZ_ROOT . './source/plugin/faxian_weixin/class/wechat.lib.class.php';
}

$openid = NULL;
$access_token = NULL;
$olddomain = $_G['setting']['domain']['app'];
$setting = (array)unserialize($_G['setting']['faxian_weixin']);

if($_GET['referer']){
	dsetcookie('referer', $_GET['referer'], 1800);
}

if($olddomain['mobile'] && $_SERVER['SERVER_NAME'] != $olddomain['mobile'] && checkmobile())
{
	if(!preg_match("/^http(s)?:\/\/.+/", $olddomain['mobile']))
	{
		 $_G['scheme'] = 'http'.($_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS']) != 'off' ? 's' : '');
		 dheader('location: '.$_G['scheme'].'://'.$olddomain['mobile'].$_SERVER['REQUEST_URI']);
	}
	dheader('location: '.$olddomain['mobile'].$_SERVER['REQUEST_URI']);
}

$referer = $_G['cookie']['referer'] ? $_G['cookie']['referer'] : urlencode($_G['siteurl']);


/*电脑端验证是否授权*/
if(!empty($_GET['check']))
{
	$err = 'wait';
	$code = intval($_GET['check']);
	$authcode = C::t('#faxian_weixin#faxian_weixin_authcode')->fetch_by_code($code);
	if($authcode['openid'])
	{
		$wechatuser = wechat_bind($authcode['token'], $authcode['openid']);
		if($wechatuser['uid'] < 1)
		{
			$err = "$code";
		}else{
			C::t('#faxian_weixin#faxian_weixin_authcode')->delete($authcode['sid']);
			dsetcookie('wechat_ticket', NULL);
			require_once libfile('function/member');
			$member = getuserbyuid($wechatuser['uid'], 1);
			setloginstatus($member, 1296000);
			
			$err = 'done';
		}
	} else {
		$err = 'wait';  //通知继续等待
	}
	
	if(checkmobile()){
		if($err == 'wait'){
			showmessage('faxian_weixin:code_expired', urldecode($referer));
		}else if($err == 'done'){
			dsetcookie('autologin', 1);
			showmessage('faxian_weixin:login_success', urldecode($referer));
		}else{
			dheader('location: '.$_G['siteurl'].'plugin.php?id=faxian_weixin:bind&code='.$code.'&referer='.$referer);
		}
		
	}else{
		exit($err);
	}
}

/*从这里开始*/
if (checkmobile() && $setting['wechat']['mptype'] == 2)
{
	$WeChatClient = new WeChatClient($setting['wechat']['appid'], $setting['wechat']['appsecret']);
	if(empty($_GET['oauth']))
	{
		$redirect_uri = ($olddomain['default'] ? 'http://'.$olddomain['default'].'/' : $_G['siteurl']).'plugin.php?id=faxian_weixin:login&oauth=yes&mobile=2&checkcode='.$_GET['checkcode'];
		$redirect_uri = $WeChatClient->getOAuthConnectUri($redirect_uri, NULL, 'snsapi_userinfo');
		dheader('location: '.$redirect_uri);
	}else{
		$token = $WeChatClient->getAccessTokenByCode($_GET['code']);
		$openid = $token['openid'];
		$access_token = $token['access_token'];
	}
}else{
	$CheckCode = rand(1000, 9999);
	
	C::t('#faxian_weixin#faxian_weixin_authcode')->delete_history();

	if(!$_G['cookie']['wechat_ticket']) 
	{
		$ticket = $_G['cookie']['saltkey'];
		dsetcookie('wechat_ticket', authcode($ticket."\t".$CheckCode, 'ENCODE'), 1800);
		C::t('#faxian_weixin#faxian_weixin_authcode')->insert(array('sid' => $ticket, 'code' => $CheckCode, 'type' => checkmobile() ? 1 : 0, 'openid' => 0, 'uid'=>$_G['uid'], 'createtime' => TIMESTAMP), 0, 1);
	}else{
		list($ticket, $CheckCode) = explode("\t", authcode($_G['cookie']['wechat_ticket'], 'DECODE'));
		$authcode = C::t('#faxian_weixin#faxian_weixin_authcode')->fetch_by_code($CheckCode);
		if(!$authcode)
		{
			C::t('#faxian_weixin#faxian_weixin_authcode')->insert(array('sid' => $ticket, 'code' => $CheckCode, 'type' => checkmobile() ? 1 : 0, 'openid' => 0, 'uid'=>$_G['uid'], 'createtime' => TIMESTAMP), 0, 1);
		}
	}
	
	if($setting['wechat']['mptype'] == 2)
	{
		$url = urlencode($_G['siteurl'].'plugin.php?id=faxian_weixin:login&checkcode='.$CheckCode);
		$qrcode = 'plugin.php?id=faxian_weixin:misc&op=qrcode&w=200&h=200&text='.$url;
	}else{
		require_once libfile('function/home');
		$qrcode = pic_get($setting['wechat']['qrcode'], 'common', 0, 0);
		$LoginMsg = lang('plugin/faxian_weixin', 'LoginMsg', array('x' => $CheckCode));
	}

	include_once template('faxian_weixin:wechat_qrcode');
	exit;
}

/*服务号登录*/
if($openid)
{
	$wechatuser = wechat_bind($access_token, $openid);
	
	/*绑定操作校验 - 电脑操作*/
	if(!empty($_GET['checkcode'])){
		$CheckCode = intval($_GET['checkcode']);
		$authcode = C::t('#faxian_weixin#faxian_weixin_authcode')->fetch_by_code($CheckCode);
		if($authcode)
		{
			C::t('#faxian_weixin#faxian_weixin_authcode')->update($authcode['sid'], array('openid' => $openid, 'token' => $access_token));
		}
	}else{//手机直接登录
		//注册、绑定失败，生成手动绑定信息
	    if($wechatuser['uid'] < 1)
		{
			if(!empty($_G['cookie']['wechat_ticket'])) 
			{
				list($ticket, $CheckCode) = explode("\t", authcode($_G['cookie']['wechat_ticket'], 'DECODE'));
			}else{
				$ticket = $_G['cookie']['saltkey'];
				$CheckCode = rand(1000, 9999);
				dsetcookie('wechat_ticket', authcode($ticket."\t".$CheckCode, 'ENCODE'), 1800);
			}
			
			$authcode = C::t('#faxian_weixin#faxian_weixin_authcode')->fetch_by_code($CheckCode);
			if($authcode)
			{
				C::t('#faxian_weixin#faxian_weixin_authcode')->update($authcode['sid'], array('openid' => $openid, 'token' => $access_token));
			}else{
				C::t('#faxian_weixin#faxian_weixin_authcode')->insert(array('sid' => $ticket, 'code' => $CheckCode, 'type' => 1, 'openid' => $openid, 'createtime' => TIMESTAMP, 'token' => $access_token), 0, 1);
			}
		}
	}

	if($wechatuser['uid'] > 0)
	{
		require_once libfile('function/member');
		$member = getuserbyuid($wechatuser['uid'], 1);
		setloginstatus($member, 1296000);
		dsetcookie('autologin', 1);
	}else{
		if($wechatuser['uid'] == -1){
			showmessage('faxian_weixin:username_already', 'plugin.php?id=faxian_weixin:bind&code='.$CheckCode.'&referer='.$referer);
		}
	    dheader('location: '.$_G['siteurl'].'plugin.php?id=faxian_weixin:bind&code='.$CheckCode.'&referer='.$referer);
	}
	
	dheader('location: '.urldecode($referer));
}

showmessage('Openid Get fail - '.$token['errcode'].' - '.$token['errmsg']);


function wechat_bind($access_token, $openid)
{
	global $_G, $setting;
	
	$wechatuser = C::t('#faxian_weixin#common_member_wechat')->fetch_by_openid($openid);
	if(!$wechatuser)
	{
		if(!$setting['login']['action'])
		{
			$wechatuser['uid'] = wechat_register($access_token, $openid, $setting['login']['newusergroupid']);
			if($wechatuser['uid'] > 0)
			{
				WeChatHook::bindOpenId($wechatuser['uid'], $openid, 1);
			}
		}
	}
	
	return $wechatuser;
}

function wechat_register($access_token, $openid, $groupid = 0) 
{
	global $_G, $setting;
	
	$wxinfo = array();
	$WeChatClient = new WeChatClient($setting['wechat']['appid'], $setting['wechat']['appsecret']);
	if($access_token)
	{
		$wxinfo = $WeChatClient->getUserInfoByAuth($access_token, $openid, 'zh_CN');
	}else{
	    $wxinfo = $WeChatClient->getUserInfoById($openid, 'zh_CN');
	}

	$wxinfo['nickname'] = WeChatEmoji::clear($wxinfo['nickname']);
	$wxinfo['province'] = WeChatEmoji::clear($wxinfo['province']);
	$wxinfo['city'] = WeChatEmoji::clear($wxinfo['city']);
	
	$regex = "/\ |\^|\&|\*|\(|\)|\+|\<|\>|\?|\,|\'/";
	$username = preg_replace($regex, '_', $wxinfo['nickname'], -1);
	
	if(!$username)
	{
		return 0;
	}
	
	$password = md5(random(10));
	$email = 'wechat_'.strtolower(random(10)).'@null.null';
	$length = dstrlen($username);
	if($length < 3)
	{
		$username = $username.'_'.random(5);
	}else if($length > 15){
		$username = substr($username, 0, 15);
	}
	
	loaducenter();
	$user = uc_get_user($username);
	if(!empty($user))
	{
		$username = cutstr($username, 7, '').'_'.random(5);
		//return -1;
	}

	$uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
	if($uid < 1)
	{
	    return $uid;
	}
	
	$profile = array(
	    'gender' => $wxinfo['sex'],
		'resideprovince' => $wxinfo['province'],
		'residecity' => $wxinfo['city']
	);
	
	$init_arr = array('credits' => explode(',', $_G['setting']['initcredits']), 'profile'=>$profile);
	$groupid = !$groupid ? $_G['setting']['newusergroupid'] : $groupid;
	C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);
	if($_G['setting']['regverify'] == 2)
	{
		C::t('common_member_validate')->insert(array(
			'uid' => $uid,
			'submitdate' => $_G['timestamp'],
			'moddate' => 0,
			'admin' => '',
			'submittimes' => 1,
			'status' => 0,
			'message' => '',
			'remark' => '',
		), false, true);
		manage_addnotify('verifyuser');
	}
	
	include_once libfile('function/stat');
	updatestat('register');
	
	if($wxinfo['headimgurl'])
	{
		$headimg = dfsockopen($wxinfo['headimgurl']); 
		if($headimg)
		{
			require_once libfile('class/image');
			$image = new image();
			
			$ucenterurl = substr(strrchr($_G['setting']['ucenterurl'], '/'), 1);
			$avatartype = array('big'=>250, 'middle'=>120, 'small'=>48);
			$uids = sprintf("%09d", $uid);
			foreach($avatartype as $type => $v)
			{
				$dir1 = substr($uids, 0, 3);
				$dir2 = substr($uids, 3, 2);
				$dir3 = substr($uids, 5, 2);
				$file = $ucenterurl.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uids, -2).($real ? '_real' : '').'_avatar_'.$type.'.jpg';
				COMMON::mkdir_by_uid($uid, $ucenterurl.'/data/avatar/');
				$fp = @fopen($file, 'w');
				@fwrite($fp, $headimg);
				@fclose($fp);
				$image->Thumb($file, '', $v, $v, 1, 1);
			}
			C::t('common_member')->update($uid, array('avatarstatus' => 1));
		}
	}
	
	return $uid;
}



?>