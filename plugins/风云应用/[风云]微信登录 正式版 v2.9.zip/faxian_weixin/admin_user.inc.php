<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require (DISCUZ_ROOT."/source/plugin/faxian_weixin/class/common.class.php");

$pluginurl = 'plugins&operation=config&do='.$_GET['do'].'&identifier=faxian_weixin&pmod='.$_GET['pmod'];

if(!submitcheck('submit'))
{
	showformheader($pluginurl);
	showtableheader();
	showsubtitle(array('', lang('plugin/faxian_weixin','nickname'), lang('plugin/faxian_weixin','binguid'), 'openid', lang('plugin/faxian_weixin','EntryTime'), ''));
	
	$fromarr[] = DB::table('common_member_wechat')." t ";
	$fromarr[] = DB::table('common_member')." t1 ON t1.uid=t.uid ";
	$return[] = 't.*, t1.username, t1.regdate';
		
	$limit = 50;
	$count = C::t('#faxian_weixin#common_member_wechat')->count_by_search(NULL,$fromarr);
	$_G['pageall'] = ceil($count / $limit);
	$_G['page'] = $limit && $_G['page'] > $_G['pageall'] ? 1 : $_G['page'];
	$start = ($_G['page'] - 1) * $limit;
	$multipage = multi($count, $limit, $_G['page'], ADMINSCRIPT.'?action='.$pluginurl);
	
	foreach(C::t('#faxian_weixin#common_member_wechat')->fetch_all_by_search(NULL,$fromarr,$return,$start,$limit) as $val)
	{
		showtablerow('', array(), array(
		    "<input type=\"checkbox\" class=\"checkbox\" name=\"delete[]\" value=\"$val[uid]\">",
			$val['username'],
			$val['uid'],
			$val['openid'],
			dgmdate($val['regdate'],'u'),
			''
		));
	}
	
	showsubmit('submit', 'submit', 'del', $multipage);
	showsubmit('', '', '',$multipage);
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();/*Dism-taobao_com*/
}else{
	$delete = $_GET['delete'];
	C::t('#faxian_weixin#common_member_wechat')->delete($delete);
	
	cpmsg('setting_update_succeed',dreferer(),'succeed');
}

?>