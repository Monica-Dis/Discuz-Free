<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP'))
{
    exit('Access Denied');
}

cpheader();
echo '<script type="text/javascript">var disallowfloat = "'.$_G['setting']['disallowfloat'].'", CSSPATH = "'.$_G['setting']['csspath'].'";</script>';

require (DISCUZ_ROOT."/source/plugin/faxian_weixin/class/common.class.php");

$preset = array('receiveEvent::subscribe', 'receiveEvent::unsubscribe', 'receiveEvent::scan', 'receiveEvent::location', 'receiveMsg::image', 'receiveMsg::video', 'receiveMsg::link', 'receiveMsg::voice', 'unanswerable');

$pluginurl = 'plugins&operation=config&do='.$_GET['do'].'&identifier=faxian_weixin&pmod='.$_GET['pmod'];
$_GET['act'] = in_array($_GET['act'],array('list','edit')) ? $_GET['act'] : 'list';

$setting = C::t('common_setting')->fetch_all(array('faxian_weixin_reply'));  //获取插件设置信息
$setting = (array)unserialize($setting['faxian_weixin_reply']);

echo '<style>
      a.but { color: #FFF; background-color: #666; margin-right: 3px; margin-left: 3px; padding-top: 2px; padding-right: 5px; padding-bottom: 2px; padding-left: 5px; border-radius: 2px; text-decoration: none;}
	  a.sx.but { background-color: #2366A8; }
	  .RoundBox { min-width: 48px; text-align: center; border-radius: 8px; background-color: #777; padding-right: 5px; padding-left: 5px; color: #FFF; line-height: 16px; height:16px; display: inline-block; }
	  #resourcelist li { float: none; margin-top: 5px; margin-bottom: 5px;  }
	  #resourcelist li a { border: 1px solid #B6CFD9; color: #2366A8; display: inline-block; padding: 0px 5px; line-height: 21px; height: 21px; }
	  #resourcelist li span { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; width: 200px; display: inline-block; vertical-align: middle; }
	  </style>
	  <script>
	function delobj(obj)
	{
		obj.parentNode.parentNode.removeChild(obj.parentNode);
	}
	</script>';

if($_GET['act'] == 'list')
{
	if(!submitcheck('submit'))
	{
		showformheader($pluginurl.'&act='.$_GET['act']);
		showtableheader();
		showsubtitle(array('', lang('plugin/faxian_weixin','TriggerType'), lang('plugin/faxian_weixin','Keyword'), lang('plugin/faxian_weixin','menu_response'), ''));
		
		showtablerow('', array('class="td23"'), array('<b>'.lang('plugin/faxian_weixin','SystemEvent').'</b>','','','',''));
		
		foreach($preset as $val)
		{
			$type = '';
			if(in_array($setting[$val]['type'], array('text','resource')))
			{
				$type = lang('plugin/faxian_weixin','display_'.$setting[$val]['type']);
			}elseif($setting[$val]['type'] == 'thirdparty')
			{
				$type = lang('plugin/faxian_weixin','Hosted',array('x'=>lang('plugin/faxian_weixin','display_'.$setting[$val]['type']),'f'=>'URL'));
			}elseif($setting[$val])
			{
				$vals = $val == 'unanswerable' ? 'receiveMsg::text' : $val;
				$response = COMMON::GetResponse($vals);
				foreach($response as $vc)
				{
					$name[] = $vc['plugin'];
				}
				$plugin = C::t('common_plugin')->fetch_all_identifier($name);
				$type = lang('plugin/faxian_weixin','Hosted',array('x'=>$plugin[$response[$setting[$val]['type']]['plugin']]['name'],'f'=>lang('plugin/faxian_weixin','api_'.$response[$setting[$val]['type']]['key'])));
			}
			showtablerow('', array('class="td23"','class="td31"','','','class="td23"'), array(
				'<input type="checkbox" class="checkbox" disabled>',
				'<span class="RoundBox" '.($val == 'unanswerable' ? 'style="background-color: #f50;"' : '').'>'.lang('plugin/faxian_weixin','api_'.$val).'</span>',
				'<span style="color:#999;"> -- </span>',
				'<span style="color:#999;">'.$type.'</span>',
				'<a class="but" href="'.ADMINSCRIPT.'?action='.$pluginurl.'&act=edit&key='.$val.'">'.cplang('edit').'</a>'
			));
		}
		
		showtablerow('', array('class="td23"'), array('<b>'.lang('plugin/faxian_weixin','CustomEvent').'</b>','','','',''));
		
		foreach($setting['reply'] as $k => $val)
		{
			$type = '';
			if(in_array($val['type'],array('text','resource')))
			{
				$type = lang('plugin/faxian_weixin','display_'.$val['type']);
			}elseif($val['type'] == 'thirdparty')
			{
				$type = lang('plugin/faxian_weixin','Hosted', array('x'=>lang('plugin/faxian_weixin','display_'.$val['type']),'f'=>'URL'));
			}else{
				$response = COMMON::GetResponse('receiveMsg::text');
				foreach($response as $vc)
				{
					$name[] = $vc['plugin'];
				}
				$plugin = C::t('common_plugin')->fetch_all_identifier($name);
				$type = lang('plugin/faxian_weixin','Hosted',array('x'=>$plugin[$response[$val['type']]['plugin']]['name'],'f'=>lang('plugin/faxian_weixin','api_'.$response[$val['type']]['key'])));
			}
			showtablerow('', array('class="td23"','class="td31"','','','class="td23"'), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$k.'">',
				'<span class="RoundBox" style="background-color: #0fb1cc;">'.lang('plugin/faxian_weixin', 'api_receiveMsg::text').'</span>',
				$val['name'],
				$type,
				'<a class="but" href="'.ADMINSCRIPT.'?action='.$pluginurl.'&act=edit&key='.$k.'">'.cplang('edit').'</a>'
			));
		}
			
		showsubmit('submit', 'submit', 'del', '<a href="'.ADMINSCRIPT.'?action='.$pluginurl.'&act=edit" class="btn">'.lang('plugin/faxian_weixin', 'AddKeyword').'</a>',$multipage);
		showtablefooter();/*Dism·taobao·com*/
		showformfooter();/*Dism-taobao_com*/
	}else{
		$delete = $_GET['delete'];
		foreach($delete as $sk)
		{
			unset($setting['reply'][$sk]);
		}	
		C::t('common_setting')->update_batch(array('faxian_weixin_reply' => serialize($setting)));
		cpmsg('setting_update_succeed',dreferer(),'succeed');
	}
}elseif($_GET['act'] == 'edit')
{
	if(in_array($_GET['key'], $preset))
	{
        $reply = $setting[$_GET['key']];
		$response = COMMON::GetResponse($_GET['key'] == 'unanswerable' ? 'receiveMsg::text' : $_GET['key']);
		$reply['name'] = lang('plugin/faxian_weixin', 'api_'.$_GET['key']);
	}else{
		$reply = $setting['reply'][$_GET['key']];
		$response = COMMON::GetResponse('receiveMsg::text');
	}
	if(!submitcheck('reply_submit'))
	{
		showformheader($pluginurl.'&act=edit&key='.$_GET['key']);
		showtableheader('');
		if(!in_array($_GET['key'], $preset))
		{
			showsetting(lang('plugin/faxian_weixin','UsersSendContent').'('.lang('plugin/faxian_weixin','Keyword').')', 'name', dstripslashes($reply['name']), 'text','','',lang('plugin/faxian_weixin','UsersSend_desc'),'required="required"');
		}else{
			showsetting(lang('plugin/faxian_weixin','TriggerType'), '','', lang('plugin/faxian_weixin','api_'.$_GET['key']));
		}
		$option[] = array('text',lang('plugin/faxian_weixin','display_text'),array('text_content' => '','resource_content'=>'none','thirdparty'=>'none'));
		$option[] = array('resource',lang('plugin/faxian_weixin','display_resource'),array('text_content' => 'none','resource_content'=>'','thirdparty'=>'none'));
		$option[] = array('thirdparty',lang('plugin/faxian_weixin','Hosted',array('x'=>lang('plugin/faxian_weixin', 'display_thirdparty'), 'f'=>'URL')), array('text_content' => 'none','resource_content'=>'none','thirdparty'=>''));
		
		if($response)
		{
			foreach($response as $val)
			{
				$name[] = $val['plugin'];
			}
			$plugin = C::t('common_plugin')->fetch_all_identifier($name);
			foreach($response as $k => $val)
			{
				$option[] = array($k, lang('plugin/faxian_weixin','Hosted',array('x'=>$plugin[$val['plugin']]['name'],'f'=>lang('plugin/faxian_weixin','api_'.$val['key']))),array('text_content' => 'none','resource_content'=>'none','thirdparty'=>'none'));
			}
		}
		showsetting(lang('plugin/faxian_weixin','menu_response'), array('type',$option), $reply['type'], 'mradio');
		
		showtagheader('tbody', 'text_content', $reply['type'] == 'text');
		$value['text'] = $reply['type'] == 'text' ? $reply['content'] : '';
		showsetting(lang('plugin/faxian_weixin','TextContent'), 'content[text]', $value['text'], 'textarea','','',lang('plugin/faxian_weixin','TextContent_desc'));
		showtagfooter('tbody');
		
		/*图文*/
		showtagheader('tbody', 'resource_content', $reply['type'] == 'resource');
		if($reply['type'] == 'resource')
		{
			foreach(C::t('#faxian_weixin#faxian_weixin_resource')->fetch_all($reply['content']) as $val)
			{
				$resourcelist .= '<li><input name="content[resource][]" type="hidden" value="'.$val['rid'].'" /> <a onclick="delobj(this);"><span>'.$val['title'].'</span> x </a></li>';
			}
		}
		showsetting(lang('plugin/faxian_weixin','SelectTeletext'), '', '', '<p><a class="btn" href="javascript:;" onclick="showWindow(\'unique\',\'plugin.php?id=faxian_weixin:misc&op=SelectResource&type=content&rid='.implode('_', $button['keyurl']).'\', \'get\', 0);">'.lang('plugin/faxian_weixin','SelectTeletext').'</a></p><br><p>'.lang('plugin/faxian_weixin','AlreadySelected', array('n' => count($button['keyurl']))).'</p><ul id="resourcelist">'.$resourcelist.'</ul>', '', '', lang('plugin/faxian_weixin','SelectTeletext_desc'));
		showtagfooter('tbody');
		
		showtagheader('tbody', 'thirdparty', $reply['type'] == 'thirdparty');
		$value['thirdparty'] = $reply['type'] == 'thirdparty' ? $reply['content'] : array();
		showsetting(lang('plugin/faxian_weixin','wechat_url'), 'content[thirdparty][url]', $value['thirdparty']['url'], 'text');
		showsetting(lang('plugin/faxian_weixin','server_token'), 'content[thirdparty][token]', $value['thirdparty']['token'], 'text');
		showtagfooter('tbody');
		
		showsubmit('reply_submit', 'submit');
		showtablefooter();/*Dism·taobao·com*/
		showformfooter();/*Dism-taobao_com*/
	}else{
		$data = array(
			'name' => $_GET['name'],
			'content' => $_GET['content'][$_GET['type']],
			'type' => $_GET['type'],
			'plugin' => $exts[$_GET['type']]['plugin'],
		);
		if(in_array($_GET['key'],$preset))
		{
			$setting[$_GET['key']] = $data;
		}elseif(is_numeric($_GET['key']))
		{
			$setting['reply'][$_GET['key']] = $data;
		}else{
			$setting['reply'][] = $data;
		}
		
	    C::t('common_setting')->update_batch(array('faxian_weixin_reply' => serialize($setting)));
		updatecache('setting');
        cpmsg('setting_update_succeed', 'action='.$pluginurl, 'succeed');
	}
}

?>