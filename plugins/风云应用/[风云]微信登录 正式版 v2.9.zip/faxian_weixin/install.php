<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS cdb_common_member_wechat (
  `uid` mediumint(8) unsigned NOT NULL,
  `openid` char(32) NOT NULL default '',
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `isregister` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `openid` (`openid`)
) ENGINE=MYISAM;
EOF;
runquery($sql);

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS cdb_faxian_weixin_authcode (
  `sid` char(6) NOT NULL,
  `code` int(10) unsigned NOT NULL,
  `type` tinyint(1) NOT NULL,
  `mod` varchar(10) NOT NULL,
  `openid` char(32) NOT NULL default '',
  `token` varchar(512) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `referer` varchar(255) NOT NULL,
  PRIMARY KEY (`sid`),
  UNIQUE KEY `code` (`code`),
  KEY `createtime` (`createtime`)
) ENGINE=MEMORY;
EOF;
runquery($sql);

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `cdb_faxian_weixin_resource` (
  `rid` int(7) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(40) NOT NULL,
  `summary` varchar(100) NOT NULL,
  `link` varchar(255) NOT NULL,
  `cover` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=MyISAM;
EOF;
runquery($sql);



$finish = TRUE;	
?>