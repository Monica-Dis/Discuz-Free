<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$pluginurl = 'plugins&operation=config&do='.$_GET['do'].'&identifier=faxian_weixin&pmod='.$_GET['pmod'];
$setting = C::t('common_setting')->fetch_all(array('faxian_weixin'));
$setting = (array)unserialize($setting['faxian_weixin']);

if(!submitcheck('submit'))
{
	showformheader($pluginurl.'&mods='.$_GET['mods'], 'enctype');
	showtableheader('');
	

	showtableheader('&#24341;&#23548;&#20851;&#27880;');

	$headguidelocaarr = array(
	    array('' ,'&#19981;&#26174;&#31034;'),
	    array('top' ,lang('plugin/faxian_weixin','loca_top')),
	    array('bottom' ,lang('plugin/faxian_weixin','loca_bottom'))
	);
	showsetting(lang('plugin/faxian_weixin','headguideloca'), array('setting[headguide][loca]', $headguidelocaarr), $setting['headguide']['loca'], 'select','','',lang('plugin/faxian_weixin','headguide_desc'));
	
	showsetting(lang('plugin/faxian_weixin','headguidetitle'), 'setting[headguide][title]', $setting['headguide']['title'], 'text');
	showsetting(lang('plugin/faxian_weixin','headguidetitle2'), 'setting[headguide][title2]', $setting['headguide']['title2'], 'text');
	
	$headguide_img = $setting['headguide']['img'] ? '<img src="'.$_G['setting']['attachurl'].'common/'.$setting['headguide']['img'].'" width="40" />' : '';
	showsetting(lang('plugin/faxian_weixin', 'headguideimg'), 'headguide_img', '', 'file', 0, 0, $headguide_img);
	
	$headguide_qrcode = $setting['headguide']['qrcode'] ? '<img src="'.$_G['setting']['attachurl'].'common/'.$setting['headguide']['qrcode'].'" width="80" />' : '';
	showsetting(lang('plugin/faxian_weixin', 'headguideqrcode'), 'headguide_qrcode', '', 'file', 0, 0, $headguide_qrcode);
	
	showsetting(lang('plugin/faxian_weixin','headguideqrcode_tip'), 'setting[headguide][qrcode_tip]', $setting['headguide']['qrcode_tip'], 'text');
	
    showtablefooter();/*Dism��taobao��com*/
	
	
	
	showsubmit('submit', 'submit');
    
	showformfooter();/*Dism-taobao_com*/
}else{
	if($_FILES['headguide_img']['tmp_name'])
	{
		$upload = new discuz_upload();
		
		$filetype = array('jpg','gif','png','jpeg');
		$ext = $upload->fileext($_FILES['headguide_img']['name']);
		if(!in_array($ext, $filetype))
		{
			cpmsg(lang('plugin/faxian_weixin', 'FileTypeErr',array('type'=>implode(',',$filetype))), '', 'error');
		}
		
		if(!$upload->init($_FILES['headguide_img'], 'common', random(3, 1), random(8)) || !$upload->save())
		{
			cpmsg($upload->errormessage(), '', 'error');
		}elseif($setting['headguide']['img'])
		{
			@unlink($_G['setting']['attachdir'].'common/'.$setting['headguide']['img']);
		}
		$_GET['setting']['headguide']['img'] = $upload->attach['attachment'];
	} else {
		$_GET['setting']['headguide']['img'] = $setting['headguide']['img'];
	}
	
	if($_FILES['headguide_qrcode']['tmp_name'])
	{
		$upload = new discuz_upload();
		
		$filetype = array('jpg','gif','png','jpeg');
		$ext = $upload->fileext($_FILES['headguide_qrcode']['name']);
		if(!in_array($ext, $filetype))
		{
			cpmsg(lang('plugin/faxian_weixin', 'FileTypeErr',array('type'=>implode(',',$filetype))), '', 'error');
		}
		
		if(!$upload->init($_FILES['headguide_qrcode'], 'common', random(3, 1), random(8)) || !$upload->save())
		{
			cpmsg($upload->errormessage(), '', 'error');
		}elseif($setting['headguide']['qrcode'])
		{
			@unlink($_G['setting']['attachdir'].'common/'.$setting['headguide']['qrcode']);
		}
		$_GET['setting']['headguide']['qrcode'] = $upload->attach['attachment'];
	} else {
		$_GET['setting']['headguide']['qrcode'] = $setting['headguide']['qrcode'];
	}
	
	$setting['headguide'] = $_GET['setting']['headguide'];
	
	$settings = array('faxian_weixin' => serialize($setting));
	C::t('common_setting')->update_batch($settings);
	updatecache('setting');
	cpmsg('setting_update_succeed', dreferer(), 'succeed');
}
//From: Dism_taobao_com
?>