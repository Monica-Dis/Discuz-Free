<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

cpheader();
echo '<script type="text/javascript">var disallowfloat = "'.$_G['setting']['disallowfloat'].'", CSSPATH = "'.$_G['setting']['csspath'].'";</script>';

require (DISCUZ_ROOT."/source/plugin/faxian_weixin/class/common.class.php");

/*判断是否安装微信登录，如果没有安装使用插件内置wechat.lib*/
$IncludePath = DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';
if(file_exists($IncludePath))
{
    require ($IncludePath);
}else{
	require_once DISCUZ_ROOT . './source/plugin/faxian_weixin/class/wechat.lib.class.php';
}

$pluginurl = 'plugins&operation=config&do='.$_GET['do'].'&identifier=faxian_weixin&pmod='.$_GET['pmod'];
$_GET['act'] = in_array($_GET['act'],array('list','edit')) ? $_GET['act'] : 'list';

$setting = C::t('common_setting')->fetch_all(array('faxian_weixin'));  //获取插件设置信息
$setting = (array)unserialize($setting['faxian_weixin']);

echo '<style>
      a.but { color: #FFF; background-color: #666; margin-right: 3px; margin-left: 3px; padding-top: 2px; padding-right: 5px; padding-bottom: 2px; padding-left: 5px; border-radius: 2px; text-decoration: none;}
	  a.sx.but { background-color: #2366A8; }
	  .RoundBox { min-width: 48px; text-align: center; border-radius: 8px; background-color: #666; padding-right: 5px; padding-left: 5px; color: #FFF; line-height: 16px; height:16px; display: inline-block; }
	  #resourcelist li { float: none; margin-top: 5px; margin-bottom: 5px;  }
	  #resourcelist li a { border: 1px solid #B6CFD9; color: #2366A8; display: inline-block; padding: 0px 5px; line-height: 21px; height: 21px; }
	  #resourcelist li span { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; width: 200px; display: inline-block; vertical-align: middle; }
	  </style>
	  <script>
	function delobj(obj)
	{
		obj.parentNode.parentNode.removeChild(obj.parentNode);
	}
	</script>';

if($_GET['act'] == 'list')
{
	if(!submitcheck('menusubmit') && !submitcheck('pubsubmit'))
	{
		echo '<script type="text/JavaScript">
	var rowtypedata = [
	[[1,\'\'], [1,\'<input name="newbutton[displayorder][]" value="" size="3" type="text" class="txt">\', \'td23 td28\'], [1, \'<div class="parentnode"><input name="newbutton[name][]" value="" size="30" type="text"></div>\'], [1, \'\', \'td29\'], [1, \'<div><a href="javascript:;" class="but" onClick="deleterow(this);">'.cplang('delete').'</a></div>\', \'\']],
	[[1,\'\'], [1,\'<input name="newsub_button[{1}][displayorder][]" value="" size="3" type="text" class="txt">\', \'td23 td28\'], [1, \'<div class="node"><input name="newsub_button[{1}][name][]" value="" size="30" type="text"></div>\'], [1, \'\', \'td29\'],[1, \'<div><a href="javascript:;" class="but" onClick="deleterow(this);">'.cplang('delete').'</a></div>\', \'\']],
	];
	</script>';
	
		showtips(lang('plugin/faxian_weixin', 'menu_tips'));      //输出技巧提示
		showformheader($pluginurl.'&act='.$_GET['act']);
		showtableheader();
		showsubtitle(array('', $lang['display_order'], lang('plugin/faxian_weixin', 'menu_name'), lang('plugin/faxian_weixin', 'menu_response'), ''));

		$response = COMMON::GetResponse('click');   //获取嵌入点信息
		foreach($response as $vc){
			$name[] = $vc['plugin'];  //遍历插件嵌入点标识
		}
		$plugin = C::t('common_plugin')->fetch_all_identifier($name);
				
		foreach($setting['menu']['button'] as $k => $button) {
			$type = '';
			if(empty($button['sub_button'])){
				$type = '';
				if(in_array($button['type'],array('text','resource','url','custom'))){
					$type = '<span class="RoundBox">'.lang('plugin/faxian_weixin','display_'.$button['type']).'</span>';
				}
			}
			$disabled = !empty($button['sub_button']) ? 'disabled' : '';
			showtablerow('', array('', 'class="td23 td28"', '', 'class="td29"'), array(
				'<input class="checkbox" type="checkbox" name="button['.$k.'][delete]" value="yes" '.$disabled.'>',
				'<input type="text" class="txt" size="3" name="button['.$k.'][displayorder]" value="'.$button['displayorder'].'">',
				'<div class="parentnode"><input type="text" size="30" name="button['.$k.'][name]" value="'.dhtmlspecialchars($button['name']).'"></div>',
				$type,
				empty($button['sub_button']) ? '<a class="sx but" href="'.ADMINSCRIPT.'?action='.$pluginurl.'&act=edit&key='.$k.'">'.cplang('edit').'</a>' : '',
			));
			if(!empty($button['sub_button'])) {
				foreach($button['sub_button'] as $sk => $sub_button)
				{
					$type = '';
					if(in_array($sub_button['type'],array('text','resource','url','custom')))
					{
						$type = '<span class="RoundBox">'.lang('plugin/faxian_weixin','display_'.$sub_button['type']).'</span>';
					}
					showtablerow('', array('', 'class="td23 td28"', '', 'class="td29"'), array(
						'<input class="checkbox" type="checkbox" name="button['.$k.'][sub_button]['.$sk.'][delete]" value="yes">',
						'<input type="text" class="txt" size="3" name="button['.$k.'][sub_button]['.$sk.'][displayorder]" value="'.$sub_button['displayorder'].'">',
						'<div class="node"><input type="text" size="30" name="button['.$k.'][sub_button]['.$sk.'][name]" value="'.dhtmlspecialchars($sub_button['name']).'"></div>',
						$type,
						'<a class="sx but" href="'.ADMINSCRIPT.'?action='.$pluginurl.'&act=edit&key='.$k.'&subkey='.$sk.'">'.cplang('edit').'</a>',
					));
				}
			}
			echo '<tr><td></td><td></td><td colspan="2"><div class="lastnode"><a href="###" onclick="addrow(this, 1, '.$k.')" class="addtr">'.lang('plugin/faxian_weixin', 'menu_sub_button').'</a></div></td><td></td></tr>';
		}
		echo '<tr><td></td><td class="td23 td28"></td><td colspan="2"><div><a href="###" onclick="addrow(this, 0, 0)" class="addtr">'.lang('plugin/faxian_weixin', 'menu_button').'</a></div></td><td></td></tr>';
	
		showsubmit('menusubmit', lang('plugin/faxian_weixin', 'menu_save'), 'del', '<input type="submit" class="btn" name="pubsubmit" value="'.lang('plugin/faxian_weixin', 'menu_pub').'" />');
		showtablefooter();/*Dism·taobao·com*/
		showformfooter();/*Dism-taobao_com*/
	
	} else {
	
		if(!empty($_GET['newbutton']))
		{
			foreach($_GET['newbutton']['name'] as $k => $name)
			{
				$button = array(
					'displayorder' => $_GET['newbutton']['displayorder'][$k],
					'name' => $name
				);
				$setting['menu']['button'][] = $button;
			}
		}
	
		foreach($_GET['button'] as $k => $value)
		{
			if($value['sub_button']) {
				foreach($value['sub_button'] as $sk => $v)
				{
					$value['sub_button'][$sk] = array('displayorder'=>$v['displayorder'],'name'=>$v['name'],'type'=>$setting['menu']['button'][$k]['sub_button'][$sk]['type'],'keyurl'=>$setting['menu']['button'][$k]['sub_button'][$sk]['keyurl']);
					if($v['delete']) {
						unset($value['sub_button'][$sk]);
					}
				}
			}else{
				$value = array('delete'=>$value['delete'],'displayorder'=>$value['displayorder'],'name'=>$value['name'],'type'=>$setting['menu']['button'][$k]['type'],'keyurl'=>$setting['menu']['button'][$k]['keyurl']);
			}
			if($value['delete'])
			{
				unset($setting['menu']['button'][$k]);
				continue;
			}
			
			$setting['menu']['button'][$k] = $value;
			if(!empty($_GET['newsub_button'][$k]))
			{
				foreach($_GET['newsub_button'][$k]['name'] as $sk => $name)
				{
					$sub_button = array(
						'displayorder' => $_GET['newsub_button'][$k]['displayorder'][$sk],
						'name' => $name
					);
					$setting['menu']['button'][$k]['sub_button'][] = $sub_button;
				}
			}
			if(count($setting['menu']['button'][$k]['sub_button']) > 7)
			{
				cpmsg(lang('plugin/faxian_weixin', 'menu_sub_button_max', array('x' => 7)), '', 'error');
			}
			usort($setting['menu']['button'][$k]['sub_button'], 'buttoncmp');
		}
	
		if(count($setting['menu']['button']) > 3)
		{
			cpmsg(lang('plugin/faxian_weixin', 'menu_button_max', array('x' => 3)), '', 'error');
		}
	
		usort($setting['menu']['button'], 'buttoncmp');
	
		C::t('common_setting')->update_batch(array('faxian_weixin' => serialize($setting)));
		updatecache('setting');
	
		if(submitcheck('pubsubmit'))
		{
	   
			if(!$setting['menu']['button'])
			{
				cpmsg(lang('plugin/faxian_weixin', 'menu_button_pub_error'), '', 'error');
			}
			
			$pubmenu = array('button' => array());
			foreach($setting['menu']['button'] as $button)
			{
				if(!$button['sub_button'])
				{
					if(!$button['name']) {
						cpmsg(lang('plugin/faxian_weixin', 'setting_required_form', array('text' => lang('plugin/faxian_weixin','menu_name'))), dreferer(), 'error');
					}
					if(!$button['keyurl']) {
						cpmsg(lang('plugin/faxian_weixin', 'menu_keyurl_empty',array('name'=>$button['name'])), '', 'error');
					}
					if($button['type'] == 'resource'){
						$item = array(
							'type' =>  'click',
							'name' => COMMON::convertname($button['name']),
							'key' => 'resource_'.implode('_',$button['keyurl'])
						);
					}else if($button['type'] == 'url'){
						$item = array(
							'type' =>  'view',
							'name' => COMMON::convertname($button['name']),
							'url' => $button['keyurl']
						);
					}else if($button['type'] == 'text'){
						$item = array(
							'type' =>  'click',
							'name' => COMMON::convertname($button['name']),
							'key' => COMMON::convertname('text_'.$button['keyurl'])
						);
					}else{
						$item = array(
							'type' =>  'click',
							'name' => COMMON::convertname($button['name']),
							'key' => $button['keyurl']
						);
					}
					$pubmenu['button'][] = $item;
				} else {
					if(!$button['name']) {
						cpmsg(lang('plugin/faxian_weixin', 'setting_required_form', array('text' => lang('plugin/faxian_weixin','menu_name'))), dreferer(), 'error');
					}
					$sub_buttons = array();
					foreach($button['sub_button'] as $sub_button)
					{
						if(!$sub_button['name']) {
							cpmsg(lang('plugin/faxian_weixin', 'setting_required_form', array('text' => lang('plugin/faxian_weixin','menu_name'))), dreferer(), 'error');
						}
						if(!$sub_button['keyurl']) {
							cpmsg(lang('plugin/faxian_weixin', 'menu_keyurl_empty',array('name'=>$sub_button['name'])), '', 'error');
						}
						if($sub_button['type'] == 'resource'){
							$item = array(
								'type' =>  'click',
								'name' => COMMON::convertname($sub_button['name']),
								'key' => 'resource_'.implode('_',$sub_button['keyurl'])
							);
						}else if($sub_button['type'] == 'url'){
							$item = array(
								'type' =>  'view',
								'name' => COMMON::convertname($sub_button['name']),
								'url' => $sub_button['keyurl']
							);
						}else if($sub_button['type'] == 'text'){
							$item = array(
								'type' =>  'click',
								'name' => COMMON::convertname($sub_button['name']),
								'key' => COMMON::convertname('text_'.$sub_button['keyurl'])
							);
						}else{
							$item = array(
								'type' =>  'click',
								'name' => COMMON::convertname($sub_button['name']),
								'key' => $sub_button['keyurl']
							);
						}
						$sub_buttons[] = $item;
					}
					$item = array(
						'name' => COMMON::convertname($button['name']),
						'sub_button' => $sub_buttons
					);
					$pubmenu['button'][] = $item;
				}
			}
			
			$wechat_client = new WeChatClient($setting['wechat']['appid'], $setting['wechat']['appsecret']);
	
			if($wechat_client->setMenu($pubmenu))
			{
				cpmsg(lang('plugin/faxian_weixin', 'menu_pub_succeed'), dreferer(), 'succeed');
			} else {
				cpmsg(lang('plugin/faxian_weixin', 'menu_pub_error', array('errno' => $wechat_client->error())), '', 'error');
			}
		} else {
			cpmsg('setting_update_succeed', dreferer(), 'succeed');
		}
	
	}
}elseif($_GET['act'] == 'edit')
{
	
	if($_GET['subkey'] != '')
	{
		$button = $setting['menu']['button'][$_GET['key']]['sub_button'][$_GET['subkey']];
	}else{
		$button = $setting['menu']['button'][$_GET['key']];
	}
	
	if(!submitcheck('menu_submit'))
	{
		showformheader($pluginurl.'&act='.$_GET['act'].'&key='.$_GET['key'].'&subkey='.$_GET['subkey']);
		showtableheader();
		showsetting(lang('plugin/faxian_weixin','menu_name'), 'name', $button['name'], 'text','','','','required="required"');
		$option[] = array('text',lang('plugin/faxian_weixin','display_text'),array('text_content' => '','resource_content'=>'none','url_content'=>'none','custom_content'=>'none'));
		$option[] = array('resource',lang('plugin/faxian_weixin','display_resource'),array('text_content' => 'none','resource_content'=>'','url_content'=>'none','custom_content'=>'none'));
		$option[] = array('url',lang('plugin/faxian_weixin','display_url'),array('text_content' => 'none','resource_content'=>'none','url_content'=>'','custom_content'=>'none'));
		$option[] = array('custom',lang('plugin/faxian_weixin','display_custom'),array('text_content' => 'none','resource_content'=>'none','url_content'=>'none','custom_content'=>''));
	
		showsetting(lang('plugin/faxian_weixin','menu_response'), array('type', $option), $button['type'], 'mradio');
		
		/*文本*/
		showtagheader('tbody', 'text_content', $button['type'] == 'text');
		$value['text'] = $button['type'] == 'text' ? $button['keyurl'] : '';
		showsetting(lang('plugin/faxian_weixin','TextContent'), 'keyurl[text]', $value['text'], 'textarea','','',lang('plugin/faxian_weixin','TextContent_desc'));
		showtagfooter('tbody');
		/*图文*/
		showtagheader('tbody', 'resource_content', $button['type'] == 'resource');
		if($button['type'] == 'resource')
		{
			foreach(C::t('#faxian_weixin#faxian_weixin_resource')->fetch_all($button['keyurl']) as $val)
			{
				$resourcelist .= '<li><input name="keyurl[resource][]" type="hidden" value="'.$val['rid'].'" /> <a onclick="delobj(this);"><span>'.$val['title'].'</span> x </a></li>';
			}
		}
		showsetting(lang('plugin/faxian_weixin','SelectTeletext'), '', '', '<p><a class="btn" href="javascript:;" onclick="showWindow(\'unique\',\'plugin.php?id=faxian_weixin:misc&op=SelectResource&type=keyurl&rid='.implode('_', $button['keyurl']).'\', \'get\', 0);">'.lang('plugin/faxian_weixin','SelectTeletext').'</a></p><br><p>'.lang('plugin/faxian_weixin','AlreadySelected', array('n' => count($button['keyurl']))).'</p><ul id="resourcelist">'.$resourcelist.'</ul>', '', '', lang('plugin/faxian_weixin','SelectTeletext_desc'));
		showtagfooter('tbody');
		/*URL*/
		showtagheader('tbody', 'url_content', $button['type'] == 'url');
		$value['url'] = $button['type'] == 'url' ? $button['keyurl'] : '';
		showsetting(lang('plugin/faxian_weixin','url_address'), 'keyurl[url]', $value['url'], 'text');
		showtagfooter('tbody');
		/*自定义*/
		showtagheader('tbody', 'custom_content', $button['type'] == 'custom');
		$value['custom'] = $button['type'] == 'custom' ? $button['keyurl'] : '';
		showsetting(lang('plugin/faxian_weixin','command'), 'keyurl[custom]', $value['custom'], 'text','','',lang('plugin/faxian_weixin','command_desc'));
		showtagfooter('tbody');
		
		showsubmit('menu_submit', 'submit');
		showtablefooter();/*Dism·taobao·com*/
		showformfooter();/*Dism-taobao_com*/
	}else{
		
		if(!$_GET['name'])
		{
		    cpmsg(lang('plugin/faxian_weixin', 'setting_required_form', array('text' => lang('plugin/faxian_weixin','menu_name'))), dreferer(), 'error');
		}
		
		if(!$_GET['type'])
		{
		    cpmsg(lang('plugin/faxian_weixin', 'setting_required_form', array('text' => lang('plugin/faxian_weixin','menu_response'))), dreferer(), 'error');
		}
		
		$button = array(
		    'displayorder' => $button['displayorder'],
			'name' => $_GET['name'],
			'keyurl' => $_GET['keyurl'][$_GET['type']],
			'type' => $_GET['type']
		);
		
		if($_GET['subkey'] != '')
		{
			$setting['menu']['button'][$_GET['key']]['sub_button'][$_GET['subkey']] = $button;
		}else{
			$setting['menu']['button'][$_GET['key']] = $button;
		}
		
	    C::t('common_setting')->update_batch(array('faxian_weixin' => serialize($setting)));
	    updatecache('setting');
		cpmsg('setting_update_succeed', 'action='.$pluginurl, 'succeed');
	}

}


?>