<?php

define('IN_MOBILE_API', 1);
define('IN_MOBILE', 1);
chdir('../../../');
define('CURSCRIPT', 'plugin');
define('DISABLEXSSCHECK', true);

//require_once 'source/plugin/mobile/mobile.class.php';

/*加载discuz核心*/
require './source/class/class_core.php';

$discuz = C::app();
$cachelist = array('plugin');
$discuz->cachelist = $cachelist;
$discuz->init();

/*判断是否安装微信登录，如果没有安装使用插件内置wechat.lib*/
$IncludePath = DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';
if(file_exists($IncludePath))
{
    require_once $IncludePath;
}else{
	require_once DISCUZ_ROOT . './source/plugin/faxian_weixin/class/wechat.lib.class.php';
}

/*菜单事件*/
$response['receiveEvent::click'] = array('plugin' => 'faxian_weixin', 'include' => 'response.class.php', 'class' => 'FaxianResponse', 'method' => 'click');

/*关注事件*/
$response['receiveEvent::subscribe'] = array('plugin' => 'faxian_weixin', 'include' => 'response.class.php','class' => 'FaxianResponse', 'method' => 'subscribe');

/*取消关注事件*/	
$response['receiveEvent::unsubscribe'] = array('plugin' => 'faxian_weixin', 'include' => 'response.class.php', 'class' => 'FaxianResponse', 'method' => 'unsubscribe');

/*扫描二维码事件*/
$response['receiveEvent::scan'] = array('plugin' => 'faxian_weixin', 'include' => 'response.class.php', 'class' => 'FaxianResponse', 'method' => 'scan');

/*上报地理位置事件*/
$response['receiveEvent::location'] = array('plugin' => 'faxian_weixin', 'include' => 'response.class.php', 'class' => 'FaxianResponse', 'method' => 'location');

/*图片消息*/
$response['receiveMsg::image'] = array('plugin' => 'faxian_weixin', 'include' => 'response.class.php', 'class' => 'FaxianResponse', 'method' => 'image');

/*视频消息*/
$response['receiveMsg::video'] = array('plugin' => 'faxian_weixin', 'include' => 'response.class.php', 'class' => 'FaxianResponse', 'method' => 'video');

/*链接消息*/
$response['receiveMsg::link'] = array('plugin' => 'faxian_weixin', 'include' => 'response.class.php', 'class' => 'FaxianResponse', 'method' => 'link');

/*语音消息*/
$response['receiveMsg::voice'] = array('plugin' => 'faxian_weixin', 'include' => 'response.class.php', 'class' => 'FaxianResponse', 'method' => 'voice');

/*文本消息接口绑定*/
$response['receiveMsg::text'] = array('plugin' => 'faxian_weixin', 'include' => 'response.class.php', 'class' => 'FaxianResponse', 'method' => 'text');


/*绑定变量到$_G['wechat']['setting']*/
$_G['siteurl'] = str_replace('source/plugin/faxian_weixin/', '', $_G['siteurl']);
$_G['setting']['faxian_weixin'] = unserialize($_G['setting']['faxian_weixin']);
$_G['wechat']['setting']['wechat_appId'] = $_G['setting']['faxian_weixin']['wechat']['appid'];
$_G['wechat']['setting']['wechat_appsecret'] = $_G['setting']['faxian_weixin']['wechat']['appsecret'];

/*绑定扩展接口*/
new WeChatServer($_G['setting']['faxian_weixin']['wechat']['token'], $response);
?>