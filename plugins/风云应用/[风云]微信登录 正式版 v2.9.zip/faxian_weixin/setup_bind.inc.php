<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/*3.22号，新增未登录判断*/
if(!$_G['uid'])
{
	dheader('location: '.$_G['siteurl'].'member.php?mod=logging&action=login');
}

if(submitcheck('bindsubmit'))
{
	
}elseif(submitcheck('removesubmit'))
{
	C::t('#faxian_weixin#common_member_wechat')->delete($_G['uid']);
	
	showmessage(lang('plugin/faxian_weixin', 'UnbundlingSuccess'), NULL, NULL, array('alert'=>'right'));
}else{
	$tmp = C::t('#faxian_weixin#common_member_wechat')->fetch($_G['uid']);
	if(!$tmp){
		$setting = (array)unserialize($_G['setting']['faxian_weixin']);
		
		if (!checkmobile() || $setting['wechat']['mptype'] != 2)
		{
			$CheckCode = rand(1000, 9999);
			
			if(!$_G['cookie']['wechat_ticket'])
			{
				$ticket = $_G['cookie']['saltkey'];
				dsetcookie('wechat_ticket', authcode($ticket."\t".$CheckCode, 'ENCODE'), 1800);
				C::t('#faxian_weixin#faxian_weixin_authcode')->insert(array('sid'=>$ticket, 'code'=>$CheckCode, 'type'=>checkmobile() ? 1 : 0, 'mod'=>'bind', 'openid'=>0, 'uid'=>$_G['uid'], 'createtime'=>TIMESTAMP), 0, 1);
			}else{
				list($ticket, $CheckCode) = explode("\t", authcode($_G['cookie']['wechat_ticket'], 'DECODE'));
				$authcode = C::t('#faxian_weixin#faxian_weixin_authcode')->fetch_by_code($CheckCode);
				if(!$authcode)
				{
					C::t('#faxian_weixin#faxian_weixin_authcode')->insert(array('sid'=>$ticket, 'code'=>$CheckCode, 'type'=>checkmobile() ? 1 : 0, 'mod'=>'bind', 'openid'=>0, 'uid'=>$_G['uid'], 'createtime'=>TIMESTAMP), 0, 1);
				}
			}
			
			if($setting['wechat']['mptype'] == 2)
			{
				$url = urlencode($_G['siteurl'].'plugin.php?id=faxian_weixin:userbind&checkcode='.$CheckCode);
				$qrcode = 'plugin.php?id=faxian_weixin:misc&op=qrcode&w=200&h=200&text='.$url;
			}else{
				require_once libfile('function/home');
				$qrcode = pic_get($setting['wechat']['qrcode'], 'common', 0, 0);
				$LoginMsg = lang('plugin/faxian_weixin', 'LoginMsg', array('x' => $CheckCode));
			}
			
		}
	
	}else{
		
	}
}

?>