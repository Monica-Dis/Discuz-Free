<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class COMMON {
	

	public function showsubmenusteps($title, $menus = array()) 
	{
		$html = '<ul class="stepstat" style="overflow: hidden;">'.($title ? '<li>'.cplang($title).': </li>' : '');
		
		if(is_array($menus)) 
		{
				$i = 0;
			foreach($menus as $menu) 
			{
				$i++;
				if($menu[1])
				{
					$html .= '<li>-> <a href="'.$menu[1].'" style="color: #CCC;">'.cplang($menu[0]).'</a></li>';
				}else{
					$html .= '<li class="current"><span style="color: #CCC;">-> </span>'.cplang($menu[0]).'</li>';
				}
			}
		}
		$html .= '</ul>';
		echo $html;
	}
	
	public function showsubmenu($title, $menus = array(), $right = '', $replace = array()) 
	{
		if(empty($menus)) {
			$s = '<div class="itemtitle">'.$right.'<h4>'.cplang($title, $replace).'</h4></div>';
		} elseif(is_array($menus)) {
			$s = '<div class="itemtitle" style="margin-top: 10px;margin-bottom: 15px !important;">'.$right.'<h4>'.cplang($title, $replace).'</h4><ul class="tab1">';
			foreach($menus as $k => $menu) {
				if(is_array($menu[0])) {
					$s .= '<li id="addjs'.$k.'" class="'.($menu[1] ? 'current' : 'hasdropmenu').'" onmouseover="dropmenu(this);"><a href="#"><span>'.cplang($menu[0]['menu']).'<em>&nbsp;&nbsp;</em></span></a><div id="addjs'.$k.'child" class="dropmenu" style="display:none;">';
					if(is_array($menu[0]['submenu'])) {
						foreach($menu[0]['submenu'] as $submenu) {
							$s .= $submenu[1] ? '<a href="'.ADMINSCRIPT.'?action='.$submenu[1].'" class="'.($submenu[2] ? 'current' : '').'" onclick="'.$submenu[3].'">'.cplang($submenu[0]).'</a>' : '<a><b>'.cplang($submenu[0]).'</b></a>';
						}
					}
					$s .= '</div></li>';
				} else {
					$s .= '<li'.($menu[2] ? ' class="current"' : '').'><a href="'.(!$menu[4] ? ADMINSCRIPT.'?action='.$menu[1] : $menu[1]).'"'.(!empty($menu[3]) ? ' target="_blank"' : '').'><span>'.cplang($menu[0]).'</span></a></li>';
				}
			}
			$s .= '</ul></div>';
		}
		echo $s;
	}
	
	
	public function convertname($str)
	{
		return urlencode(diconv($str, CHARSET, 'UTF-8'));
	}
	
	public function buttoncmp($a, $b)
	{
		return $a['displayorder'] > $b['displayorder'] ? 1 : -1;
	}
	
	public function GetResponse($type)
	{
		global $_G;
		if ($type)
		{
			$wechatresponse = unserialize($_G['setting']['wechatresponse']);
			$wechatresponseExts = unserialize($_G['setting']['wechatresponseExts']);
			
			foreach($wechatresponse as $k => $v)
			{
				if($k == $type)
				{
					$v['key'] = $k;
					$name = md5(implode('',$v));
					$response[$name] = $v;
				}
			}
			foreach($wechatresponseExts as $v)
			{
				foreach($v as $k => $x)
				{
					if($k == $type)
					{
						$x['key'] = $k;
						$name = md5(implode('',$x));
						$response[$name] = $x;
					}
				}
			}
			return $response;
		} 
	}
	
	public function mkdir_by_uid($uid, $dir = '.')
	{
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		!is_dir($dir.'/'.$dir1) && mkdir($dir.'/'.$dir1, 0777);
		!is_dir($dir.'/'.$dir1.'/'.$dir2) && mkdir($dir.'/'.$dir1.'/'.$dir2, 0777);
		!is_dir($dir.'/'.$dir1.'/'.$dir2.'/'.$dir3) && mkdir($dir.'/'.$dir1.'/'.$dir2.'/'.$dir3, 0777);
		return $dir1.'/'.$dir2.'/'.$dir3;
	}
		
}


?>