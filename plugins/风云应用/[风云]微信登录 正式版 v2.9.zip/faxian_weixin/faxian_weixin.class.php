<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_faxian_weixin
{
	function plugin_faxian_weixin()
	{
		global $_G;
		$_G['faxian_weixin'] = (array)unserialize($_G['setting']['faxian_weixin']);
		include_once template('faxian_weixin:embed');
	}
	
	function global_login_extra()
	{
		global $_G;
		if($_G['faxian_weixin']['login']['loginswitch'])
		{
			return faxian_weixin_tpl_login_bar(1);
		}
	}
	
}

class plugin_faxian_weixin_member extends plugin_faxian_weixin
{
	
	function logging_method()
	{
		global $_G;
		if($_G['faxian_weixin']['login']['loginswitch'])
		{
			$_G['connect']['referer'] = (!$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'].($_SERVER['QUERY_STRING'] ? '?'.$_SERVER['QUERY_STRING'] : '') : dreferer());
			return faxian_weixin_tpl_login_bar(2);
		}	
	}
	
	function register_logging_method()
	{
		global $_G;
		if($_G['faxian_weixin']['login']['loginswitch'])
		{
			$_G['connect']['referer'] = urlencode(!$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'].($_SERVER['QUERY_STRING'] ? '?'.$_SERVER['QUERY_STRING'] : '') : dreferer());
			return faxian_weixin_tpl_login_bar(2);
		}
	}
	
}


class mobileplugin_faxian_weixin
{
	
    function mobileplugin_faxian_weixin()
	{
		global $_G, $module;
		
		$_G['faxian_weixin'] = (array)unserialize($_G['setting']['faxian_weixin']);
		
        if (!$_G['uid'] && strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false && !in_array($module, array('login', 'bind')))
		{
			if($_G['faxian_weixin']['login']['loginswitch'] && $_G['faxian_weixin']['login']['autologin'] && $_G['faxian_weixin']['wechat']['mptype'] == 2 && !$_G['cookie']['autologin'])
			{
				dheader('location: '.$_G['siteurl'].'plugin.php?id=faxian_weixin:login');
			}
		}
		
		include_once template('faxian_weixin:embed');
	}
	
	function global_header_mobile($value)
	{
		global $_G;
		
		if(!$_G['uid'] && $_G['faxian_weixin']['headguide']['loca'] && !$_G['cookie']['headguide'])
		{
			return faxian_weixin_tpl_headguide_bar();
		}
	}

}

class mobileplugin_faxian_weixin_member extends mobileplugin_faxian_weixin
{
	
	function logging_bottom_mobile()
	{
		global $_G;
		if($_G['faxian_weixin']['login']['loginswitch'])
		{
			$_G['connect']['referer'] = urlencode(!$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'].($_SERVER['QUERY_STRING'] ? '?'.$_SERVER['QUERY_STRING'] : '') : dreferer());
			return faxian_weixin_tpl_login_bar();
		}
	}
	
	function register_bottom_mobile()
	{
		global $_G;
		if($_G['faxian_weixin']['login']['loginswitch'])
		{
			$_G['connect']['referer'] = urlencode(!$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'].($_SERVER['QUERY_STRING'] ? '?'.$_SERVER['QUERY_STRING'] : '') : dreferer());
			return faxian_weixin_tpl_login_bar();
		}
	}
	
}
//From: Dism_taobao_com
?>