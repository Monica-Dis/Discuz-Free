<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_common_member_wechat.php 34506 2014-05-13 02:09:15Z nemohou $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_common_member_wechat extends discuz_table {

	public function __construct() {
		$this->_table = 'common_member_wechat';
		$this->_pk = 'uid';
		$this->_pre_cache_key = 'common_member_wechat_';

		parent::__construct();
	}
    
	
	public function count_by_search($wherearr = array(), $fromarr = array()) {
		if(!$wherearr) {
			$wherearr[] = '1';
		}
		if(!$fromarr) {
			$fromarr[] = DB::table($this->_table);
		}
		return DB::result_first("SELECT COUNT(1) FROM ".implode(' LEFT JOIN ', $fromarr)." WHERE ".implode(' AND ', $wherearr));
	}
	
	public function fetch_all_by_search($wherearr = array(), $fromarr = array(), $return = array(), $start = 0, $limit = 15, $order = NULL) {
		if(!$wherearr) {
			$wherearr[] = '1';
		}
		if(!$fromarr) {
			$fromarr[] = DB::table($this->_table);
		}
		if(!$return){
			$return[] = '*';
		}
		$_order = !empty($order) ? ' ORDER BY '.DB::order($order, 'DESC').' ' : ' ';
		return DB::fetch_all("SELECT ".implode(',', $return)." FROM ".implode(' LEFT JOIN ', $fromarr)." WHERE ".implode(' AND ', $wherearr).$_order.DB::limit($start, $limit));
	}
	
	public function fetch_by_openid($openid)
	{
		return DB::fetch_first('SELECT * FROM %t WHERE openid=%s', array($this->_table, $openid));
	}
	
}