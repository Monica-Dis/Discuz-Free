<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
    exit('Aecsse Denied');
}
class table_faxian_weixin_resource extends discuz_table {
    public function __construct() {
        $this->_table = 'faxian_weixin_resource';
        $this->_pk = 'rid';
        $this->_pre_cache_key = 'faxian_weixin_resource_';
        parent::__construct();
    }
	
	public function count_by_search($wherearr = array(), $fromarr = array()) {
		if(!$wherearr) {
			$wherearr[] = '1';
		}
		if(!$fromarr) {
			$fromarr[] = DB::table($this->_table);
		}
		return DB::result_first("SELECT COUNT(1) FROM ".implode(' LEFT JOIN ', $fromarr)." WHERE ".implode(' AND ', $wherearr));
	}
	
	public function fetch_all_by_search($wherearr = array(), $fromarr = array(), $return = array(), $start=0, $limit=15, $order=NULL) {
		if(!$wherearr) {
			$wherearr[] = '1';
		}
		if(!$fromarr) {
			$fromarr[] = DB::table($this->_table);
		}
		if(!$return){
			$return[] = '*';
		}
		$_order = !empty($order) ? ' ORDER BY '.DB::order($order, 'DESC').' ' : ' ';
		return DB::fetch_all("SELECT ".implode(',', $return)." FROM ".implode(' LEFT JOIN ', $fromarr)." WHERE ".implode(' AND ', $wherearr).$_order.DB::limit($start, $limit));
	}
	
}

?>