<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

DB::query("ALTER TABLE ".DB::table('faxian_weixin_authcode')." ADD `token` varchar(512) NOT NULL;",'SILENT');
DB::query("ALTER TABLE ".DB::table('faxian_weixin_authcode')." ADD `referer` varchar(255) NOT NULL;",'SILENT');
DB::query("ALTER TABLE ".DB::table('faxian_weixin_authcode')." ADD `type` tinyint(1) NOT NULL;",'SILENT');
DB::query("ALTER TABLE ".DB::table('faxian_weixin_authcode')." ADD `uid` int(9) NOT NULL;",'SILENT');
DB::query("ALTER TABLE ".DB::table('faxian_weixin_authcode')." ADD `mod` varchar(10) NOT NULL;",'SILENT');

$finish = TRUE;

?>