<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require DISCUZ_ROOT . './source/plugin/faxian_weixin/class/common.class.php';

$IncludePath = DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';
if(file_exists($IncludePath))
{
    require ($IncludePath);
}else{
	require_once DISCUZ_ROOT . './source/plugin/faxian_weixin/class/wechat.lib.class.php';
}

$openid = NULL;
$access_token = NULL;
$olddomain = $_G['setting']['domain']['app'];
$setting = (array)unserialize($_G['setting']['faxian_weixin']);

if($_GET['referer']){
	dsetcookie('referer', $_GET['referer'], 1800);
}

if($olddomain['mobile'] && $_SERVER['SERVER_NAME'] != $olddomain['mobile'] && checkmobile())
{
	if(!preg_match("/^http(s)?:\/\/.+/", $olddomain['mobile']))
	{
		 $_G['scheme'] = 'http'.($_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS']) != 'off' ? 's' : '');
		 dheader('location: '.$_G['scheme'].'://'.$olddomain['mobile'].$_SERVER['REQUEST_URI']);
	}
	dheader('location: '.$olddomain['mobile'].$_SERVER['REQUEST_URI']);
}

$referer = $_G['cookie']['referer'] ? $_G['cookie']['referer'] : urlencode($_G['siteurl']);


/*电脑端验证是否授权*/
if(!empty($_GET['check']))
{
	$code = intval($_GET['check']);
	$authcode = C::t('#faxian_weixin#faxian_weixin_authcode')->fetch_by_code($code);
	if($authcode['openid'])
	{
		$wechatuser = C::t('#faxian_weixin#common_member_wechat')->fetch_by_openid($authcode['openid']);
	    if(!$wechatuser)
	    {
		    exit("wait");
	    }else{
			exit("done");
		}
	} else {
		exit("wait");
	}
}

/*从这里开始*/
if (checkmobile() && $setting['wechat']['mptype'] == 2)
{
	$WeChatClient = new WeChatClient($setting['wechat']['appid'], $setting['wechat']['appsecret']);
	if(empty($_GET['oauth']))
	{
		$redirect_uri = ($olddomain['default'] ? 'http://'.$olddomain['default'].'/' : $_G['siteurl']).'plugin.php?id=faxian_weixin:userbind&oauth=yes&mobile=2&checkcode='.$_GET['checkcode'];
		$redirect_uri = $WeChatClient->getOAuthConnectUri($redirect_uri, NULL, 'snsapi_userinfo');
		dheader('location: '.$redirect_uri);
	}else{
		$token = $WeChatClient->getAccessTokenByCode($_GET['code']);
		$openid = $token['openid'];
		$access_token = $token['access_token'];
	}
}

/*服务号登录*/
if($openid)
{
	/*绑定操作校验 - 电脑操作*/
	if(!empty($_GET['checkcode'])){
		$CheckCode = intval($_GET['checkcode']);
		$authcode = C::t('#faxian_weixin#faxian_weixin_authcode')->fetch_by_code($CheckCode);
		
		$wechatuser = C::t('#faxian_weixin#common_member_wechat')->fetch_by_openid($openid);
	    if(!$wechatuser)
	    {
		    WeChatHook::bindOpenId($authcode['uid'], $openid, 2);
	    }else{
			showmessage('faxian_weixin:occupied');
		}
		
		if($authcode)
		{
			C::t('#faxian_weixin#faxian_weixin_authcode')->update($authcode['sid'], array('openid' => $openid, 'token' => $access_token));
		}
	}else{//手机直接登录
        $wechatuser = C::t('#faxian_weixin#common_member_wechat')->fetch_by_openid($openid);
	    if(!$wechatuser)
	    {
		    WeChatHook::bindOpenId($_G['uid'], $openid, 2);
	    }else{
			showmessage('faxian_weixin:occupied');
		}
	}
	
	dheader('location: '.$_G['siteurl'].'home.php?mod=spacecp&ac=plugin&id=faxian_weixin:setup_bind');
}

showmessage('Openid Get fail - '.$token['errcode'].' - '.$token['errmsg']);

?>