<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$pluginurl = 'plugins&operation=config&do='.$_GET['do'].'&identifier=faxian_weixin&pmod='.$_GET['pmod'];
$_GET['act'] = in_array($_GET['act'],array('list','edit')) ? $_GET['act'] : 'list';

if($_GET['act'] == 'list')
{
	if(!submitcheck('submit'))
	{
		showformheader($pluginurl.'&act='.$_GET['act']);
		showtableheader();
		showsubtitle(array('', lang('plugin/faxian_weixin','Title'), lang('plugin/faxian_weixin','Summary'), ''));
		
		$limit = 20;
		$count = C::t('#faxian_weixin#faxian_weixin_resource')->count_by_search();
		$_G['pageall'] = ceil($count / $limit);
		$_G['page'] = $limit && $_G['page'] > $_G['pageall'] ? 1 : $_G['page'];
		$start = ($_G['page'] - 1) * $limit;
		$multipage = multi($count, $limit, $_G['page'], ADMINSCRIPT.'?action='.$pluginurl);
		
		foreach(C::t('#faxian_weixin#faxian_weixin_resource')->fetch_all_by_search(NULL, NULL, NULL, $start, $limit) as $val)
		{
			showtablerow('', array('class="td23"'), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['rid'].'">',
				$val['title'],
				cutstr($val['summary'],120),
				'<a href="'.ADMINSCRIPT.'?action='.$pluginurl.'&act=edit&rid='.$val['rid'].'">'.cplang('edit').'</a>'
			));
		}
			
		showsubmit('submit', 'submit', 'del', '<a href="'.ADMINSCRIPT.'?action='.$pluginurl.'&act=edit" class="btn">'.lang('plugin/faxian_weixin', 'Addresource').'</a>',$multipage);
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();/*Dism-taobao_com*/
	}else{
		$delete = $_GET['delete'];
		if(!empty($delete))
		{
			foreach(C::t('#faxian_weixin#faxian_weixin_resource')->fetch_all($delete) as $value)
			{
				@unlink($_G['setting']['attachdir'].'common/'.$value['cover']);
			}
			C::t('#faxian_weixin#faxian_weixin_resource')->delete($delete);
		}
		cpmsg('setting_update_succeed',dreferer(),'succeed');
	}
}elseif($_GET['act'] == 'edit')
{
	$rid = intval($_GET['rid']);
	$resource = array();
	$rid && $resource = C::t('#faxian_weixin#faxian_weixin_resource')->fetch($rid);
	if(!submitcheck('submit'))
	{
		showformheader($pluginurl.'&act=edit&&rid='.$_GET['rid'],'enctype');
		showtableheader('');
		showsetting(lang('plugin/faxian_weixin','Title'), 'title', $resource['title'], 'text','','',lang('plugin/faxian_weixin','resource_Title_Desc'),'required="required"');
		showsetting(lang('plugin/faxian_weixin','Link'), 'link', $resource['link'], 'text','','','','required="required"');
		showsetting(lang('plugin/faxian_weixin','Summary'), 'summary', $resource['summary'], 'textarea','','',lang('plugin/faxian_weixin','TextContent_desc'));

		$cover = $resource['cover'] ? '<img src="'.$_G['setting']['attachurl'].'common/'.$resource['cover'].'" height="64" />' : '';
	    showsetting(lang('plugin/faxian_weixin', 'image'), 'cover', $resource['cover'], 'filetext', 0, 0, lang('plugin/faxian_weixin', 'image_desc', array('qrcode' => $cover)));
		
		showsubmit('submit', 'submit');
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();/*Dism-taobao_com*/
	}else{
		if($_FILES['cover']['tmp_name'])
		{
			$upload = new discuz_upload();
			
			$filetype = array('jpg','gif','png','jpeg');
			$ext = $upload->fileext($_FILES['cover']['name']);
			if(!in_array($ext, $filetype))
			{
				cpmsg(lang('plugin/faxian_weixin', 'FileTypeErr',array('type'=>implode(',',$filetype))), '', 'error');
			}
		
			if(!$upload->init($_FILES['cover'], 'common', random(3, 1), random(8)) || !$upload->save())
			{
				cpmsg($upload->errormessage(), '', 'error');
			}elseif($resource['cover'])
			{
				@unlink($_G['setting']['attachdir'].'common/'.$resource['cover']);
			}
			$_GET['cover'] = $upload->attach['attachment'];
		}
		
	    $data = array(
			'title' => $_GET['title'],
			'summary' => $_GET['summary'],
			'link' => $_GET['link'],
			'cover' => $_GET['cover'],
			'dateline' => time()
		);
		if(!empty($rid) && $resource)
		{
			C::t('#faxian_weixin#faxian_weixin_resource')->update($rid, $data);	
		}else{
			C::t('#faxian_weixin#faxian_weixin_resource')->insert($data);
		}
        cpmsg('setting_update_succeed', 'action='.$pluginurl, 'succeed');
	}
}

?>