<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

foreach(C::t('#faxian_weixin#faxian_weixin_resource')->fetch_all_by_search() as $val)
{
	@unlink($_G['setting']['attachdir'].'common/'.$val['cover']);
}

DB::query("DROP TABLE IF EXISTS ".DB::table('faxian_weixin_authcode')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('faxian_weixin_resource')."");

/*清空微信和UID绑定表*/
//DB::query("TRUNCATE TABLE IF EXISTS".DB::table('common_member_wechat')."");

$_G['setting']['faxian_weixin']['wechat'] = unserialize($_G['setting']['faxian_weixin']['wechat']);
@unlink($_G['setting']['attachdir'].'common/'.$_G['setting']['faxian_weixin']['wechat']['qrcode']);


C::t('common_setting')->delete('faxian_weixin');
C::t('common_setting')->delete('faxian_weixin_reply');

?>