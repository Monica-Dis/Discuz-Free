<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$pluginurl = 'plugins&operation=config&do='.$_GET['do'].'&identifier=faxian_weixin&pmod='.$_GET['pmod'];

$setting = C::t('common_setting')->fetch_all(array('faxian_weixin'));
$setting = (array)unserialize($setting['faxian_weixin']);

if(!submitcheck('submit'))
{
    showformheader($pluginurl.'&mods='.$_GET['mods'], 'enctype');
	showtableheader();
	showsetting(lang('plugin/faxian_weixin', 'EnableWeChatLogin'), 'setting[login][loginswitch]', $setting['login']['loginswitch'], 'radio', 0, 1, lang('plugin/faxian_weixin', 'EnableWeChatLogin_desc'));
	
	showsetting(lang('plugin/faxian_weixin', 'autologin'), 'setting[login][autologin]', $setting['login']['autologin'], 'radio', 0, 0, lang('plugin/faxian_weixin', 'autologin_desc'));
	showsetting(lang('plugin/faxian_weixin', 'DefaultAction'), array('setting[login][action]',array(array(1,lang('plugin/faxian_weixin','BindAccount')),array(0,lang('plugin/faxian_weixin','AutoRegist')))), $setting['login']['action'], 'mradio', 0, 0, lang('plugin/faxian_weixin', 'DefaultAction_desc'));
	
	$groupselect = array();
	foreach(C::t('common_usergroup')->range_orderby_credit() as $group)
	{
		if($group['type'] != 'member' || $_G['setting']['newusergroupid'] == $group['groupid'])
		{
			$groupselect[$group['type']] .= '<option value="'.$group['groupid'].'"'.($setting['login']['newusergroupid'] == $group['groupid'] ? ' selected' : '').'>'.$group['grouptitle'].'</option>';
		}
	}
	$usergroups = '<select name="setting[login][newusergroupid]"><option value="">'.cplang('plugins_empty').'</option>'.
		'<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
		($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
		($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
		'<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup></select>';
	showsetting(lang('plugin/faxian_weixin', 'wechat_newusergroupid'), '', '', $usergroups, 0, 0, lang('plugin/faxian_weixin', 'wechat_newusergroupid_comment'));
	
	showtablefooter();/*Dism��taobao��com*/
	
	showtableheader();
	showsubmit('submit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();/*Dism-taobao_com*/
}else{
	$setting['login'] = $_GET['setting']['login'];
	
	$settings = array('faxian_weixin' => serialize($setting));
	C::t('common_setting')->update_batch($settings);
	updatecache('setting');
	cpmsg('setting_update_succeed', dreferer(), 'succeed');
}
//From: Dism_taobao_com
?>