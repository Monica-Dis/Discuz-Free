<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$pluginurl = 'plugins&operation=config&do='.$_GET['do'].'&identifier=faxian_weixin&pmod='.$_GET['pmod'];
$setting = C::t('common_setting')->fetch_all(array('faxian_weixin'));
$setting = (array)unserialize($setting['faxian_weixin']);

if(!submitcheck('submit'))
{
	showformheader($pluginurl.'&mods='.$_GET['mods'], 'enctype');
	showtableheader('');
	showtagheader('tbody', 'bind', true, 'tbody');

	showsetting('AppID', 'setting[wechat][appid]', $setting['wechat']['appid'], 'text','','',lang('plugin/faxian_weixin','wechat_appid_desc'),'required="required"');
	showsetting('AppSecret', 'setting[wechat][appsecret]', $setting['wechat']['appsecret'], 'text','','',lang('plugin/faxian_weixin','wechat_appsecret_desc'),'required="required"');
	
	$qrcode = $setting['wechat']['qrcode'] ? '<img src="'.$_G['setting']['attachurl'].'common/'.$setting['wechat']['qrcode'].'" width="80" />' : '';
	showsetting(lang('plugin/faxian_weixin', 'wechat_qrcode'), 'wechat_qrcode', '', 'file', 0, 0, lang('plugin/faxian_weixin', 'wechat_qrcode_comment', array('qrcode' => $qrcode)));
	
	showsetting(lang('plugin/faxian_weixin','wechat_type'), array('setting[wechat][mptype]', array(array(0,lang('plugin/faxian_weixin','wechat_mptype_0')),array(2,lang('plugin/faxian_weixin','wechat_mptype_2')))), $setting['wechat']['mptype'], 'mradio','','',lang('plugin/faxian_weixin','wechat_type_desc'));
	
	showsubmit('submit', 'submit');
	showtagfooter('tbody');
	showtablefooter();/*Dism��taobao��com*/
	
	showtableheader(lang('plugin/faxian_weixin','server_config').'<span style="float:right;margin-right:10px;" class="normal">'.lang('plugin/faxian_weixin','test_bind').'</span>');
	$apiurl = $_G['siteurl'].'source/plugin/faxian_weixin/server.php';

    showsetting(lang('plugin/faxian_weixin','wechat_url'), '', '', $apiurl);
	
	!$setting['wechat']['token'] && $setting['wechat']['token'] = md5(random(8));
	showsetting(lang('plugin/faxian_weixin','server_token'), 'setting[wechat][token]', $setting['wechat']['token'], 'text');
	
    showtablefooter();/*Dism��taobao��com*/
	showformfooter();/*Dism-taobao_com*/
}else{
	if($_FILES['wechat_qrcode']['tmp_name'])
	{
		$upload = new discuz_upload();
		
		$filetype = array('jpg','gif','png','jpeg');
		$ext = $upload->fileext($_FILES['wechat_qrcode']['name']);
		if(!in_array($ext, $filetype))
		{
			cpmsg(lang('plugin/faxian_weixin', 'FileTypeErr',array('type'=>implode(',',$filetype))), '', 'error');
		}
		
		if(!$upload->init($_FILES['wechat_qrcode'], 'common', random(3, 1), random(8)) || !$upload->save())
		{
			cpmsg($upload->errormessage(), '', 'error');
		}elseif($setting['wechat']['qrcode'])
		{
			@unlink($_G['setting']['attachdir'].'common/'.$setting['wechat']['qrcode']);
		}
		$_GET['setting']['wechat']['qrcode'] = $upload->attach['attachment'];
	} else {
		$_GET['setting']['wechat']['qrcode'] = $setting['wechat']['qrcode'];
	}
	
	$setting['wechat'] = $_GET['setting']['wechat'];
	
	$settings = array('faxian_weixin' => serialize($setting));
	C::t('common_setting')->update_batch($settings);
	updatecache('setting');
	cpmsg('setting_update_succeed', dreferer(), 'succeed');
}
//From: Dism_taobao_com
?>