<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


if($_GET['op'] == 'qrcode')
{
	require_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
	$value = $_GET['text'];	
	QRcode::png($value, false, QR_ECLEVEL_Q, 4);
}

if($_GET['op'] == 'SelectResource')
{
	require_once libfile('function/home');
	
	$ridarr = explode('_', $_GET['rid']);
	
	$limit = 15;
	$count = C::t('#faxian_weixin#faxian_weixin_resource')->count_by_search();
	$_G['pageall'] = ceil($count / $limit);
	$_G['page'] = $limit && $_G['page'] > $_G['pageall'] ? 1 : $_G['page'];
	$start = ($_G['page'] - 1) * $limit;
	$multipage = multi($count, $limit, $_G['page'], ADMINSCRIPT.'?action='.$pluginurl);
		
	foreach(C::t('#faxian_weixin#faxian_weixin_resource')->fetch_all_by_search(NULL, NULL, NULL, $start, $limit) as $val)
	{
		$img = substr($val['cover'] , 0 , 4) == 'http' ? $val['cover'] : $_G['siteurl'].pic_get($val['cover'], 'common');
		$html .= '<div class="item"><a href="javascript:;" onclick="setitem(this,'.$val['rid'].',\''.$val['title'].'\')"><p class="img"><img src="'.$img.'"></p><p class="title">'.$val['title'].'</p></a></div>';
		
	}
	
	include template('common/header_ajax');
	echo '<h3 class="flb" style="margin-bottom: 0px;"> <em id="return_'.$_GET['handlekey'].'">'.lang('plugin/faxian_weixin','SelectTeletext').'</em> <span> <a href="javascript:;" class="flbc" onclick="hideWindow(\''.$_GET['handlekey'].'\');">'.lang('close').'</a> </span> </h3>
<div class="showWindow" style="overflow:auto;overflow-x:hidden; padding:10px;"><div class="selectlist">'.$html.'</div><div style="padding:10px;">'.$multipage.'</div></div>';
    echo '<style>
	.showWindow { width: 900px; }
	.selectlist { overflow: hidden; }
	.selectlist .item { padding:10px;  float: left; width: 25%; }
	.selectlist a { display: block; text-align: center; }
	.selectlist a img { width: 100%; max-width: 100%; }
	.selectlist a .title { margin-top: 10px; }
	.selectlist a .img { border: 1px solid #B6CFD9; height: 163px; overflow: hidden; }
	.selectlist .Disable {}
	</style>
	<script>
	function setitem(obj, rid, name)
	{
		var num = parseInt(document.getElementById("SelectNum").innerHTML);
		if(num >= 10){
			alert("\u6700\u591a\u53ea\u80fd\u8bbe\u7f6e\u0031\u0030\u4e2a\u56fe\u6587!");
			hideWindow(\''.$_GET['handlekey'].'\');
			return false;
		}
		var node=document.createElement("li");
		node.innerHTML = \'<input name="'.$_GET['type'].'[resource][]" type="hidden" value="\'+rid+\'" /> <a onclick="delobj(this);"><span>\'+name+\'</span> x </a>\';
		document.getElementById("resourcelist").appendChild(node);
		obj.setAttribute("onclick", "");
		obj.setAttribute("class", "Disable");
		
		document.getElementById("SelectNum").innerHTML = num + 1;
	}
	</script>';
	include template('common/footer_ajax');
}

?>