<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$_GET['act'] = in_array($_GET['act'], array('list', 'edit')) ? $_GET['act'] : 'list';

$pluginurl = 'plugins&operation=config&do='.$_GET['do'].'&identifier=faxian_recharge&pmod='.$_GET['pmod'];
$formurl = $pluginurl.'&act='.$_GET['act'];

$setting = C::t('common_setting')->fetch_all(array('faxian_recharge'));
$setting = (array)unserialize($setting['faxian_recharge']);

if($_GET['act'] == 'list')
{
	if(!submitcheck('submit'))
	{
		echo '<script type="text/JavaScript">
		var rowtypedata = [
		[[1,\'\'], [1,\'<input name="item[displayorder][]" value="" type="text" class="txt">\', \'td25\'], [1, \'<input name="item[title][]" value="" type="text">\'], [1, \'<input name="item[amount][]" value="" type="text" class="txt">\', \'td25\'], [1,\'<span style="padding-left:10px;">=</span>\'], [1, \'<input name="item[credit][]" value="" type="text">\', \'td28\'], [1,\'\'], [1, \'<div><a href="javascript:;" onClick="deleterow(this)">'.cplang('delete').'</a></div>\', \'\']]
		];
		</script>';
		
		showtips('<li>'.lang('plugin/faxian_recharge','ItemTypeTip').'</li><li>'.lang('plugin/faxian_recharge','ItemTypeTip2').'</li>');
		
		showformheader($formurl);
		showtableheader();
		showsubtitle(array('', cplang('order'), lang('plugin/faxian_recharge','ItemName'), lang('plugin/faxian_recharge','AddAmount'), lang('plugin/faxian_recharge','equal'), lang('plugin/faxian_recharge','credit'), '', ''));
		
		
		foreach($setting['item'] as $k => $val)
		{
			showtablerow('',array('', 'class="td25"', '', 'class="td25"', 'class="td25"', 'class="td28"', 'class="td23"', 'class="td21"', 'class="td23"'), array(
			    '',
			    '<input name="item[displayorder][]" value="'.$val['displayorder'].'" type="text" class="txt">',
				'<input name="item[title][]" value="'.$val['title'].'" type="text">',
				'<input name="item[amount][]" value="'.$val['amount'].'" type="text" class="txt">',
				'<span style="padding-left:10px;">=</span>',
				'<input name="item[credit][]" value="'.$val['credit'].'" type="text">',
				'',
				'<div><a href="javascript:;" onClick="deleterow(this)">'.cplang('delete').'</a></div>'
			));
		}
		
		
		echo '<tr><td></td><td colspan="7"><div><a href="###" onclick="addrow(this, 0, 0)" class="addtr">'.lang('plugin/faxian_recharge', 'additem').'</a></div></td></tr>';
		
		showsubmit('submit', 'submit');
		/*Dism_taobao_com*/showtablefooter();
		showformfooter();/*Dism��taobao��com*/
	}else{
		$item = array();
		foreach($_GET['item']['title'] as $k => $val){
			$item[$k] = array('displayorder' => $_GET['item']['displayorder'][$k], 'title' => $val, 'amount' => $_GET['item']['amount'][$k], 'credit' => $_GET['item']['credit'][$k]);
		}
		
		$setting['item'] = $item;
		C::t('common_setting')->update_batch(array('faxian_recharge' => serialize($setting)));
		updatecache('setting');
		cpmsg('setting_update_succeed', 'action='.$pluginurl.'&mods='.$_GET['mods'], 'succeed');
	}
}
//From: Dism_taobao-com
?>