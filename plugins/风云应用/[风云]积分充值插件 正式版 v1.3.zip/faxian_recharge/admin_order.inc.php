<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

cpheader();

echo '<style>
	  .RoundBox { min-width: 48px; text-align: center; border-radius: 8px; background-color: #666; padding-right: 5px; padding-left: 5px; color: #FFF; line-height: 16px; height:16px; display: inline-block; }
	  </style>
      <script type="text/javascript">var disallowfloat = "'.$_G['setting']['disallowfloat'].'",CSSPATH = "'.$_G['setting']['csspath'].'";</script>';

$_GET['act'] = in_array($_GET['act'], array('order')) ? $_GET['act'] : 'order';

$pluginurl = 'plugins&operation=config&do='.$_GET['do'].'&identifier=faxian_recharge&pmod='.$_GET['pmod'];
$formurl = $pluginurl.'&act='.$_GET['act'];

$setting = C::t('common_setting')->fetch_all(array('faxian_recharge'));
$setting = (array)unserialize($setting['faxian_recharge']);

if($_GET['act'] == 'order')
{
	if(!submitcheck('submit'))
	{
		!$_GET['perpage'] && $_GET['perpage'] = 20;
		$selected['status'][$_GET['status']] = 'selected';
		$selected['orderby'][$_GET['orderby']] = 'selected';
		$selected['ordersc'][$_GET['ordersc']] = 'selected';
		$selected['perpage'][$_GET['perpage']] = 'selected';
		
		$limit = !empty($_GET['perpage']) ? intval($_GET['perpage']) : 10;
		$_order = $_GET['orderby'] ? $_GET['orderby'] : 'dateline';
		$ordersc = $_GET['ordersc'] ? $_GET['ordersc'] : 'desc';
		
		$fromarr[] = DB::table('faxian_recharge_order');
		$return[] = '*';
		
		$_GET['status'] != NULL && $condition[] =  DB::field('status', intval($_GET['status']));
		$_GET['oid'] != NULL && $condition[] =  DB::field('oid', $_GET['oid']);
		!empty($_GET['username']) && $condition[] =  DB::field('username', '%'.$_GET['username'].'%', 'like');
		
		$count = C::t('#faxian_recharge#faxian_recharge_order')->count_by_search($condition, $fromarr);
		$_G['pageall'] = ceil($count / $limit);
		$_G['page'] = $limit && $_G['page'] > $_G['pageall'] ? 1 : $_G['page'];
		$start = ($_G['page'] - 1) * $limit;
		$multipage = multi($count, $limit, $_G['page'], ADMINSCRIPT.'?'.http_build_query(array_unique($_GET)));
	
		showformheader($formurl.'&act='.$_GET['act'], NULL, 'tb_search');
		
		echo '<table cellpadding="3" cellspacing="3" style="float:left;" width="100%">
		<tr>
		  <td width="67">'.lang('plugin/faxian_recharge', 'OrderNumber').'</td>
		  <td><input type="text" class="txt" name="oid" value="'.$_GET['oid'].'">
		  '.lang('plugin/faxian_recharge','username').'* <input type="text" class="txt" name="title" value="'.$_GET['title'].'">
			*'.cplang('likesupport').'</td>
			<td style="text-align:right">
			</td>
		</tr>
		<tr>
		  <td>'.cplang('resultsort').'</td>
		  <td>
		    <select name="status">
			  <option value="" selected>='.lang('plugin/faxian_recharge','status').'=</option>
			  <option value="0" '.$selected['status'][0].'>'.lang('plugin/faxian_recharge', 'PayStatus_0').'</option>
			  <option value="1" '.$selected['status'][1].'>'.lang('plugin/faxian_recharge', 'PayStatus_1').'</option>
			</select>
			<select name="orderby">
			  <option value="" selected>'.cplang('defaultsort').'</option>
			  <option value="dateline" '.$selected['orderby']['dateline'].'>'.lang('plugin/faxian_recharge','OrderDateline').'</option>
			  <option value="amount" '.$selected['orderby']['amount'].'>'.lang('plugin/faxian_recharge','OrderAmount').'</option>
			</select>
			<select name="ordersc">
			  <option value="desc" '.$selected['ordersc']['desc'].'>'.cplang('orderdesc').'</option>
			  <option value="asc" '.$selected['ordersc']['asc'].'>'.cplang('orderasc').'</option>
			</select>
			<select name="perpage">
			  <option value="10" '.$selected['perpage']['10'].'>'.cplang('perpage_10').'</option>
			  <option value="20" '.$selected['perpage']['20'].'>'.cplang('perpage_20').'</option>
			  <option value="50" '.$selected['perpage']['50'].'>'.cplang('perpage_50').'</option>
			  <option value="100" '.$selected['perpage']['100'].'>'.cplang('perpage_100').'</option>
			</select>
			<input type="submit" name="searchsubmit" value="'.cplang('search').'" class="btn"></td>
			<td style="text-align:right">'.$multipage.'</td>
		</tr>
		</table>';
		showformfooter();/*Dism��taobao��com*/
	
		showformheader($formurl.'&act='.$_GET['act']);
		showtableheader();
		showsubtitle(array('<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" /><label for="chkall">'.cplang('select_all').'</label>', lang('plugin/faxian_recharge','OrderNumber'), lang('plugin/faxian_recharge','username'), lang('plugin/faxian_recharge','OrderAmount'), cplang('dateline'), lang('plugin/faxian_recharge','status')));
		
		foreach (C::t('#faxian_recharge#faxian_recharge_order')->fetch_all_by_search($condition, $fromarr, $return, $start, $limit, $_order, $ordersc) as $value) 
		{
			
			if ($value['status'] == 1) 
			{
				$value['statusd'] = '<span class="RoundBox" style="background-color: #090;">' . lang('plugin/faxian_recharge', 'PayStatus_'.$value['status']) . '</span>';
			} elseif ($value['status'] == 0) 
			{
				$value['statusd'] = '<span class="RoundBox" style="background-color: #EC6D1F;">' . lang('plugin/faxian_recharge', 'PayStatus_'.$value['status']) . '</span>';
			}
			
			$tablerow = array(
				"<input type=\"checkbox\" class=\"checkbox\" name=\"ids[]\" value=\"$value[oid]\">",
				$value['oid'],
				'<a class="but" href="home.php?mod=space&uid='.$value['uid'].'&do=profile" target="_blank">'.$value['username'].'</a>',
				$value['amount'],
				dgmdate($value['dateline'],'u'),
				$value['statusd']
			);
			showtablerow('', array('class="td25"','','class="td24"','class="td31"','class="devteam"','class="td31"','class="td23"','class="td23"'), $tablerow);
		
		}
		
		$optypehtml = '<b>'.lang('plugin/faxian_recharge', 'OperateSelectItems').':</b> 
		<select name="optype">
		  <option value="">--'.lang('plugin/faxian_recharge','PleaseChoose').'--</option>
		  <option value="audit">'.lang('plugin/faxian_recharge','Approved').'</option>
		  <option value="delete">'.cplang('delete').'</option>
		</select>
		&nbsp;&nbsp;';
		
		showsubmit('', '', '', $optypehtml.'<input type="submit" class="btn" name="submit" value="'.cplang('submit').'" />', $multipage);
		/*Dism_taobao_com*/showtablefooter();
		showformfooter();/*Dism��taobao��com*/
	}else{
		
		if($_GET['optype'] == 'delete') 
		{
			foreach($_GET['ids'] as $oid)
			{
				C::t('#faxian_recharge#faxian_recharge_order')->delete($oid);
			}
		}elseif($_GET['optype'] == 'audit') 
		{
			C::t('#faxian_recharge#faxian_recharge_order')->update($_GET['ids'], array('status'=>1));
		}
		
		cpmsg('setting_update_succeed', 'action='.$pluginurl.'&act='.$_GET['act'], 'succeed');
	}
}
//From: Dism_taobao-com
?>