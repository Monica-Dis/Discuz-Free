<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ'))
{
    exit('Access Denied');
}

class alipay 
{

    var $name = '&#25903;&#20184;&#23453;';  //阿里云
	var $desc;
	var $version = 'v1.0';
	var $copyright = '';
	
	
    /*设置项目*/
	public function setting($val=array()) 
	{
		$setting = array(
		    'enable' => array(
				'title' => '&#26159;&#21542;&#21551;&#29992;',  //设置项目名称
				'type' => 'radio',   //表单类型
				'value' => $val['enable'],
				'desc' => ''
			),
			'app_id' => array(
				'title' => 'appid',  //设置项目名称
				'type' => 'text',   //表单类型
				'value' => $val['app_id'],
				'desc' => '&#33719;&#21462;&#22320;&#22336;: https://openhome.alipay.com/platform/keyManage.htm'
			),
		    'merchant_private_key' => array(
				'title' => '&#21830;&#25143;&#31169;&#38053;',   //设置项目名称 (可用中文)
				'type' => 'textarea',   //表单类型
				'value' => $val['merchant_private_key'],
				'desc' => '&#25903;&#20184;&#23453;&#23494;&#38053;&#29983;&#25104;&#22120;&#25110;&#79;&#112;&#101;&#110;&#83;&#83;&#76;&#29983;&#25104;&#30340;&#21830;&#25143;&#31169;&#38053;'
			),
			'alipay_public_key' => array(
				'title' => '&#25903;&#20184;&#23453;&#20844;&#38053;',
				'type' => 'textarea',
				'value' => $val['alipay_public_key'],
				'desc' => '&#26597;&#30475;&#22320;&#22336;: https://openhome.alipay.com/platform/keyManage.htm'
			)
		);
		return $setting;
	}
	
	/*付款*/
	public function pay($pay, $order)
	{
		global $_G;
		
		require_once "config.php";
		
		$config['app_id'] = $pay['app_id'];
		$config['merchant_private_key'] = $pay['merchant_private_key'];
		$config['alipay_public_key'] = $pay['alipay_public_key'];
		
		require_once 'AopSdk.php';
		require_once 'pagepay/service/AlipayTradeService.php';
		require_once 'pagepay/buildermodel/AlipayTradePagePayContentBuilder.php';
		
		$title = diconv($order['title'], CHARSET, 'utf-8');
		
		//商户订单号，商户网站订单系统中唯一订单号，必填
		$out_trade_no = trim($order['oid']);
	
		//订单名称，必填
		$subject = trim($title);
	
		//付款金额，必填
		$total_amount = trim($order['amount']);
	
		//商品描述，可空
		$body = trim($title);
	
		//构造参数
		$payRequestBuilder = new AlipayTradePagePayContentBuilder();
		$payRequestBuilder->setBody($body);
		$payRequestBuilder->setSubject($subject);
		$payRequestBuilder->setTotalAmount($total_amount);
		$payRequestBuilder->setOutTradeNo($out_trade_no);

		$aop = new AlipayTradeService($config);
		$response = $aop->pagePay($payRequestBuilder, $config['return_url'], $config['notify_url']);
    }
	
	public function wappay($pay, $order)
	{
		global $_G;
		
		require_once "config.php";
		
		$config['app_id'] = $pay['app_id'];
		$config['merchant_private_key'] = $pay['merchant_private_key'];
		$config['alipay_public_key'] = $pay['alipay_public_key'];
		
		require_once 'AopSdk.php';
		require_once 'wappay/service/AlipayTradeService.php';
		require_once 'wappay/buildermodel/AlipayTradeWapPayContentBuilder.php';
		
		$title = diconv($order['title'], CHARSET, 'utf-8');
		
		//商户订单号，商户网站订单系统中唯一订单号，必填
		$out_trade_no = trim($order['oid']);
	
		//订单名称，必填
		$subject = trim($title);
	
		//付款金额，必填
		$total_amount = trim($order['amount']);
	
		//商品描述，可空
		$body = trim($title);
	
		//超时时间
		//$timeout_express = "1m";
	
		$payRequestBuilder = new AlipayTradeWapPayContentBuilder();
		$payRequestBuilder->setBody($body);
		$payRequestBuilder->setSubject($subject);
		$payRequestBuilder->setOutTradeNo($out_trade_no);
		$payRequestBuilder->setTotalAmount($total_amount);
		$payRequestBuilder->setTimeExpress($timeout_express);
	
		$payResponse = new AlipayTradeService($config);
		$result = $payResponse->wapPay($payRequestBuilder, $config['return_url'], $config['notify_url']);
    }
	
}

//From: Dism_taobao-com
?>