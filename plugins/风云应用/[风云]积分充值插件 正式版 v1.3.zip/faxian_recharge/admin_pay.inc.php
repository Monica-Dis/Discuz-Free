<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP'))
{
    exit('Access Denied');
}

require (DISCUZ_ROOT."/source/plugin/faxian_recharge/function/function_admin.php");

cpheader();
		  
$pluginurl = 'plugins&operation=config&do='.$_GET['do'].'&identifier=faxian_recharge&pmod='.$_GET['pmod'];


/*===========================我是一条分割线============================*/

$interfaceapi = _loadapi(DISCUZ_ROOT.'/source/plugin/faxian_recharge/api', array('name'));

$_GET['mods'] = $_GET['mods'] ? $_GET['mods'] : key($interfaceapi);
$formurl = $pluginurl.'&mods='.$_GET['mods'];

$ApiArr = array();
foreach($interfaceapi as $apiname => $val)
{
	$ApiArr[] = array($val['name'], $pluginurl.'&mods='.$apiname, $_GET['mods'] == $apiname);
}

_showsubmenu('', $ApiArr);

$setting = C::t('common_setting')->fetch_all(array('faxian_recharge'));
$setting = (array)unserialize($setting['faxian_recharge']);

if(!preg_match("/^[a-z0-9_\-]+$/i", $_GET['mods']) || !$_GET['mods'])
{
	cpmsg('Unidentified identity', 'action='.$pluginurl.'&mods='.$_GET['mods']);
}

$apiname = $_GET['mods'];

if(!submitcheck('submit'))
{
	showformheader($formurl);
	showtableheader();
	include_once DISCUZ_ROOT.'/source/plugin/faxian_recharge/api/'.$apiname.'/'.$apiname.'.php';
	if(class_exists($apiname))
	{
		$api = new $apiname();
		$apisetting = $api->setting($setting['api'][$apiname]);	

		foreach($apisetting as $k => $v)
		{
			if(in_array($v['type'], array('select','mradio','mradio2','mcheckbox','mcheckbox2','mselect')))
			{
				foreach($v['default'] as $n => $m)
				{
					$dbval[] = array($n, diconv($m, 'utf-8', CHARSET));
				}
				showsetting(diconv($v['title'], 'utf-8', CHARSET), array('api['.$apiname."][".$k."]", $dbval), dstripslashes($setting['api'][$apiname][$k]), $v['type'], '', '', $v['desc']);
			}else{
				showsetting(diconv($v['title'], 'utf-8', CHARSET), 'api['.$apiname."][".$k."]", dstripslashes($setting['api'][$apiname][$k]), $v['type'], '', '', $v['desc']);
			}
		}
	}

	showsubmit('submit', 'submit');
	/*Dism_taobao_com*/showtablefooter();
	showformfooter();/*Dism·taobao·com*/
}else{
	$setting['api'][$apiname] = $_GET['api'][$apiname];
	C::t('common_setting')->update_batch(array('faxian_recharge' => serialize($setting)));
	//updatecache('setting');
	cpmsg('setting_update_succeed', 'action='.$pluginurl.'&mods='.$_GET['mods'], 'succeed');
}
//From: Dism_taobao-com
?>