


var FileBlob, videoid = 0;

$(document).on('change', '#videodata', function () {
	if (this.files[0]) {
		popup.open('<div class="LoadingBar"><img src="./source/plugin/faxian_video/static/images/loading.gif" width="38"><p id="progress-bar">\u521d\u59cb\u5316\u4e2d...</p></div>');
		FileBlob = this.files[0];
		var ext = FileBlob.name.substring(FileBlob.name.lastIndexOf('.') + 1);
		var timestamp = new Date().getTime() + '_' + Math.ceil(Math.random() * 9999);
		var filename = "data/attachment/profile/" + timestamp + "." + ext;

		$.ajax({
			url: ServiceUrl + '&op=token',
			type: 'POST',
			data: { name: filename },
			success: function (data) {
				var data = JSON.parse(data);
				videoid = data.vid;
				if (data.vid > 0) {
					VideoUpload(data, filename);
				} else {
					popup.close();
					alert(data.msg);
				}
			}
		});
	}
});

function VideoUpload(data, filename) {
	if (data.api == 'aliyun') {
		var client = new OSS.Wrapper({ region: data.region, accessKeyId: data.access, accessKeySecret: data.secret, bucket: data.bucket });
		client.multipartUpload(filename, FileBlob, {
			progress: function (p) {
				return function (done) {
					popup.open('<div class="LoadingBar"><img src="./source/plugin/faxian_video/static/images/loading.gif" width="38"><p id="progress-bar">' + Math.floor(p * 100) + '%</p></div>');
					done();
				}
			}
		}).then(function (result) {
			var snapshot = client.signatureUrl(filename, { 'process': 'video/snapshot,t_5000,f_jpg,w_800,h_0,m_fast' }) + '&x-oss-process=video/snapshot,t_5000,f_jpg,w_800,h_0,m_fast';
			captureImage(snapshot);
		}).catch(function (err) {
			popup.close();
			alert(err);
		});
	} else if (data.api == 'qiniu') {
		var observable = qiniu.upload(FileBlob, filename, data.token, data.putExtra, data.config)
		var subscription = observable.subscribe(function (p) {
			popup.open('<div class="LoadingBar"><img src="./source/plugin/faxian_video/static/images/loading.gif" width="38"><p id="progress-bar">' + Math.floor(p.total.percent) + '%</p></div>');
		}, function (res) {
			popup.close();
			alert(res.err.message);
		}, function (result) {
			var snapshot = ServiceUrl + '&op=getfile&type=cover&name=' + result.key;
			captureImage(snapshot);
		});
	}
}

var captureImage = function (snapshot) {
	var image = new Image();
	image.crossOrigin = "Anonymous";
	image.src = snapshot;

	popup.open('<div class="LoadingBar"><img src="./source/plugin/faxian_video/static/images/loading.gif" width="38"><p id="progress-bar">\u622a\u53d6\u5c01\u9762...</p></div>');
	image.onload = function () {
		var canvas = document.createElement("canvas");
		canvas.width = image.width;
		canvas.height = image.height;
		canvas.getContext('2d').drawImage(image, 0, 0, image.width, image.height);
		canvas.toBlob(function (blob) {
			var formData = new FormData();
			formData.append("vid", videoid);
			formData.append("cover", blob, new Date().getTime() + '.jpg');
			setcover(formData);
		}, 'image/jpeg', 1);
	}, image.onerror = function () {
		var formData = new FormData();
		formData.append("vid", videoid);
		setcover(formData);
		//alert('\u60a8\u4e0a\u4f20\u7684\u89c6\u9891\u683c\u5f0f\u65e0\u6cd5\u622a\u53d6\u5c01\u9762');
	}
}

function setcover(formData) {
	$.ajax({
		url: ServiceUrl + '&op=setcover',
		type: 'POST',
		data: formData,
		processData: false,
		contentType: false,
		success: function (data) {
			var data = JSON.parse(data);
			if (data.vid > 0) {
				$('#videolist').html('<div class="video_cover"><a class="delvideo" href="javascript:;" onclick="DelVideo(this, ' + data.vid + ');"><img src="source/plugin/faxian_video/static/images/close.png"></a><video src="' + URL.createObjectURL(FileBlob) + '" controls="controls"></video><input name="videoid" type="hidden" value="' + data.vid + '" /></div>');
				popup.close();
			} else {
				popup.close();
				alert(data.msg);
			}
		}
	});
}

function DelVideo(obj, vid) {
	if (vid) {
		if (confirm("\u786e\u8ba4\u8981\u5220\u9664\uff1f")) {
			popup.open('<div class="LoadingBar"><img src="./source/plugin/faxian_video/static/images/loading.gif" width="38"><p id="progress-bar">\u5220\u9664\u4e2d...</p></div>');
			$.get(ServiceUrl + '&op=delfile&vid=' + vid, function (data) {
				var data = JSON.parse(data);
				if (data.result == 'done') {
					$('#videolist').html(ButtonHtml);
					popup.close();
				} else {
					console.log(data.msg);
					popup.close();
					alert('\u5220\u9664\u5931\u8d25, \u9519\u8bef\u7801: ' + data.result+ ' - ' + data.msg);
				}
			});
		}
	}
}