<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function _discuzcode_callback_parsemedia_video($matches)
{
	return video_media::parsemedia($matches);
}
function _discuzcode_callback_parseaudio_video($matches)
{
	return '<audio controls="controls" style="width:100%;margin:10px;"><source src="'.$matches[2].'" type="audio/mpeg"></audio>';
}
	
class video_media
{
	
	function parsemedia($matches)
	{
		$iframe = '';
		$lowerurl = $matches[2];
		
		if(dstrpos($matches[2], array('.webm', '.ogg ', '.mkv', '.mov', '.mpeg', '.mp4'))){
			return '<video src="'.$matches[2].'" controls="controls" preload="preload" width="100%" ></video>';
		}else{
			if(strpos($lowerurl, 'youku.com/') !== FALSE) {
				if (preg_match('/id_(.*?)\.html|sid\/(.*?)\/v/i', $lowerurl, $matches)) {
					$iframe = 'http://player.youku.com/embed/'.($matches[1] ? $matches[1] : $matches[2]);
				}
			}elseif(strpos($lowerurl, 'tudou.com/') !== FALSE) {
				if (preg_match('/tudou.com\/v\/(.[^\/]+)\//i',$lowerurl,$matches)) {
					$iframe = 'http://www.tudou.com/programs/view/html5embed.action?code='.$matches[1];
				}else{
					//$iframe = parse_tudouicode($matches[2]);
				}
			}elseif(strpos($lowerurl, 'qq.com/') !== FALSE){
				if(preg_match("/vid=(.*?)auto/i", $lowerurl, $matches)) {
					$iframe = 'https://v.qq.com/iframe/player.html?vid='.$matches[1].'tiny=0&auto=0';
				}
			}elseif(strpos($lowerurl, 'qiyi.com/') !== FALSE){
				if((preg_match("/qiyi.com\/([^\/]+)\/\d/i", $lowerurl, $vid))&&(preg_match("/tvid=(\d+)/i", $lowerurl, $tvid))){
					$iframe = 'http://open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid='.$vid[1].'&tvId='.$tvid[1].'&auto=0';
				}elseif((preg_match("/[\?|\&]vid=([\d|a-z]+)/i", $lowerurl, $vid))&&(preg_match("/tvid=(\d+)/i", $lowerurl, $tvid))){
					$iframe = 'http://open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid='.$vid[1].'&tvId='.$tvid[1].'&auto=0';
				}
			}elseif(strpos($lowerurl, 'share.vrs.sohu.com/') !== FALSE){
				if(preg_match("/[\?|\&]id=(\d+)/i", $lowerurl, $matches)) {
					$iframe = 'http://tv.sohu.com/upload/static/share/share_play.html#'.$matches[1].'_0_0_0_0';
				}
			}elseif(strpos($lowerurl, 'tv.sohu.com/') !== FALSE){
				if(preg_match("/[\?|\&]vid=(\d+)/i", $lowerurl, $matches)) {
					$iframe = 'http://tv.sohu.com/upload/static/share/share_play.html#'.$matches[1].'_0_0_0_0';
				}
			}elseif((strpos($lowerurl,'bilibili') !== FALSE)||(strpos($lowerurl,'acg.tv') !== FALSE)||(strpos($lowerurl,'hdslb.com') !== FALSE)){
				if(preg_match("/o\/av(.*?)\/|aid=(.*?)&/i", $lowerurl, $matches)) {
					$iframe = 'http://www.bilibili.com/video/av'.($matches[1] ? $matches[1] : $matches[2]);
				}
			}elseif((strpos($lowerurl,'acfun.cn') !== FALSE)||(strpos($lowerurl,'aixifan.com') !== FALSE)){
				if(preg_match("/ac(.[\d]+)|vid=(.[\d]+)&/i", $lowerurl, $matches)){
					$iframe = 'http://m.acfun.cn/ykplayer?cover=http://www.hooos.com/static/image/mobile/images/icon_load.gif&date=undefined#vid='.($matches[1] ? $matches[1] : $matches[2]);
				}
			}elseif((strpos($lowerurl,'music.163') !== FALSE)&&(strpos($lowerurl,'.swf?') !== FALSE)){
				if(preg_match("/\.swf\?(.*)$/i", $lowerurl, $matches)){
					$iframe = 'http://music.163.com/outchain/player?'.str_replace("sid","id",$matches[1]);
				}
			}
			if (!$iframe){
				if(strpos($lowerurl, '<iframe') !== FALSE){
					return $lowerurl;
				}
				$iframe = $lowerurl;
			}
			
			return '<iframe width="100%" scrolling="no" src='.$iframe.'" frameborder=0 allowfullscreen></iframe>';
		}

	}
	
 
}


?>