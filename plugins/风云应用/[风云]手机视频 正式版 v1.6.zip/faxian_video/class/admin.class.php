<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class ADMIN {
	
	/*遍历API*/
	public function loadapi($dir, $variable=array()) 
	{
		global $_G;
		$carr = array();
		if(!$dir || !file_exists($dir))
		{
			return $carr;
		}
		$apidir = dir($dir);
		while($entry = $apidir->read()) 
		{
			if(in_array($entry, array('.', '..')) || !is_dir($dir.'/'.$entry)) 
			{
				continue;
			}
			
			$IncludePath = $dir.'/'.$entry.'/'.$entry.'.php';
			if(!file_exists($IncludePath))
			{
				continue;
			}
			
			@include_once $IncludePath;
			if(!class_exists($entry)) 
			{
				continue;
			}
			
			$c = new $entry();
			foreach($variable as $val)
			{
				$carr[$entry][$val] = diconv($c->$val, 'utf-8', CHARSET);
			}
		}
		return $carr;
	}

	public function showsubmenusteps($title, $menus = array()) 
	{
		$html = '<ul class="stepstat" style="overflow: hidden;">'.($title ? '<li>'.cplang($title).': </li>' : '');
		
		if(is_array($menus)) 
		{
				$i = 0;
			foreach($menus as $menu) 
			{
				$i++;
				if($menu[1])
				{
					$html .= '<li>-> <a href="'.$menu[1].'" style="color: #CCC;">'.cplang($menu[0]).'</a></li>';
				}else{
					$html .= '<li class="current"><span style="color: #CCC;">-> </span>'.cplang($menu[0]).'</li>';
				}
			}
		}
		$html .= '</ul>';
		echo $html;
	}
	
	public function showsubmenu($title, $menus = array(), $right = '', $replace = array()) 
	{
		if(empty($menus)) {
			$s = '<div class="itemtitle">'.$right.'<h4>'.cplang($title, $replace).'</h4></div>';
		} elseif(is_array($menus)) {
			$s = '<div class="itemtitle" style="margin-top: 10px;margin-bottom: 15px !important;">'.$right.'<h4>'.cplang($title, $replace).'</h4><ul class="tab1">';
			foreach($menus as $k => $menu) {
				if(is_array($menu[0])) {
					$s .= '<li id="addjs'.$k.'" class="'.($menu[1] ? 'current' : 'hasdropmenu').'" onmouseover="dropmenu(this);"><a href="#"><span>'.cplang($menu[0]['menu']).'<em>&nbsp;&nbsp;</em></span></a><div id="addjs'.$k.'child" class="dropmenu" style="display:none;">';
					if(is_array($menu[0]['submenu'])) {
						foreach($menu[0]['submenu'] as $submenu) {
							$s .= $submenu[1] ? '<a href="'.ADMINSCRIPT.'?action='.$submenu[1].'" class="'.($submenu[2] ? 'current' : '').'" onclick="'.$submenu[3].'">'.cplang($submenu[0]).'</a>' : '<a><b>'.cplang($submenu[0]).'</b></a>';
						}
					}
					$s .= '</div></li>';
				} else {
					$s .= '<li'.($menu[2] ? ' class="current"' : '').'><a href="'.(!$menu[4] ? ADMINSCRIPT.'?action='.$menu[1] : $menu[1]).'"'.(!empty($menu[3]) ? ' target="_blank"' : '').'><span>'.cplang($menu[0]).'</span></a></li>';
				}
			}
			$s .= '</ul></div>';
		}
		echo $s;
	}
	
	
}



?>