<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class VIDEO 
{
	public static function getconfig()
	{
		global $_G;
		
		$setting = (array)unserialize($_G['setting']['faxian_video']);
		$api = $_G['cache']['plugin']['faxian_video']['remoteapi'];
		$parameter = $setting['attachment'][$api];
		$parameter['apiname'] = $api;
		
		return $parameter;
	}

	public static function cleardebris($time)
	{
		global $_G;
		
		$parameter = self::getconfig();
		include_once DISCUZ_ROOT.'/source/plugin/faxian_video/api/'.$parameter['apiname'].'/'.$parameter['apiname'].'.php';
	    
		$res = array();
		if(class_exists($parameter['apiname']))
		{
			$obj = new $parameter['apiname']();
			
			$condition[] = DB::field('tid', 1, '<');
			$condition[] = DB::field('lasttime', $_G['timestamp'] - $time, '<');
			foreach(C::t('#faxian_video#faxian_video')->fetch_all_by_search($condition, array(), array()) as $attach)
			{
				$res = $obj->deletefile($parameter, $attach['attachment']);
				if($res['result'] == 'done' || $attach['status'] < 1)
				{
					if($attach['cover'])
					{
						@unlink($_G['setting']['attachdir'].'/album/'.$attach['cover']);
					}
					
					C::t('#faxian_video#faxian_video')->delete($attach['vid']);
				}
			}
	    }
	}

}
//From: Dism_taobao_com
?>