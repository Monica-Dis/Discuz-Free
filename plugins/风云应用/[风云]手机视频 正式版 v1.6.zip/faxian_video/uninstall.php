<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$count = C::t('#faxian_video#faxian_video')->count();
if($count)
{
	/*清理已经上传到附件*/
	require_once(DISCUZ_ROOT."/source/plugin/faxian_video/class/common.class.php");
	$parameter = VIDEO::getconfig();
	include_once DISCUZ_ROOT.'/source/plugin/faxian_video/api/'.$parameter['apiname'].'/'.$parameter['apiname'].'.php';
	
	$res = array();
	if(class_exists($parameter['apiname']))
	{
		$obj = new $parameter['apiname']();
	
		$limit = 1000;
		$allpage = ceil($count / $limit);
		for($page=0; $page < $allpage; $page++)
		{
			foreach (C::t('#faxian_video#faxian_video')->fetch_all_by_search(array(),array(),array(),0,$limit) as $attach)
			{
				if($attach['cover'])
				{
					@unlink($_G['setting']['attachdir'].'/album/'.$attach['cover']);
				}
				$res = $obj->deletefile($parameter, $attach['attachment']);
			}
		}
	}
}

/*删除数据表*/
DB::query("DROP TABLE IF EXISTS ".DB::table('faxian_video')."");

C::t('common_setting')->delete('faxian_video');

$finish = TRUE;
?>