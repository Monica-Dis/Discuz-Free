<?php

class qiniu
{

    var $name = '&#19971;&#29275;&#20113;';  //七牛云
	var $desc;
	var $version = 'v1.0';
	var $copyright = '';
	
	
    /*设置项目*/
	public function getsetting($val=array())
	{
		$settings = array(
		    'area' => array( //区域
				'title' => '&#23384;&#20648;&#21306;&#22495;',  //设置项目名称
				'type' => 'mradio',   //表单类型
				'default' => array(
					'upload.qiniu.com'=>'&#21326;&#19996;',
					'upload-z1.qiniu.com'=>'&#21326;&#21271;',
					'upload_z2.qiniu.com'=>'&#21326;&#21335;',
					'up-na0.qiniup.com'=>'&#21271;&#32654;',
					'up-as0.qiniup.com'=>'&#19996;&#21335;&#20122;'
					),
				'value' => $val['area'],      //默认值
			),
		    'attachdomain' => array(
				'title' => '&#38468;&#20214;&#22495;&#21517;',   
				'type' => 'text',   
				'value' => $val['attachdomain'],
			),
			'access' => array(
				'title' => 'AK/AccessKey',
				'type' => 'text',
				'value' => $val['access'],
			),
			'secret' => array(
				'title' => 'SK/SecretKey',
				'type' => 'text',
				'value' => $val['secret'],
			),
			'bucket' => array(
				'title' => '&#31354;&#38388;&#21517;&#31216;',
				'type' => 'text',
				'value' => $val['bucket'],
			)
		);
		return $settings;
	}
	
	/*上传文件*/
	public function uploadfile($parameter, $attachment, $source)
	 {
		require_once("io.php");
	    require_once("rs.php");
		$parameter['area'] && $QINIU_UP_HOST = 'http://'.$parameter['area'];
		Qiniu_SetKeys($parameter['access'], $parameter['secret']);
		$putPolicy = new Qiniu_RS_PutPolicy($parameter['bucket']);
		$upToken = $putPolicy->Token(null);
		$putExtra = new Qiniu_PutExtra();
		$putExtra->Crc32 = 1;
		list($ret, $err) = Qiniu_PutFile($upToken, $attachment, $source, $putExtra);
		return array('result' => $err !== null ? $err->Code : 'done', 'msg' => $err->Err);
    }
	
	/*删除文件*/
	public function deletefile($parameter, $attachment)
	{
		require_once("io.php");
	    require_once("rs.php");
		$parameter['area'] && $QINIU_UP_HOST = 'http://'.$parameter['area'];
		Qiniu_SetKeys($parameter['access'], $parameter['secret']);
		$putPolicy = new Qiniu_RS_PutPolicy($parameter['bucket']);
		$upToken = $putPolicy->Token(null);
		$putExtra = new Qiniu_PutExtra();
		$putExtra->Crc32 = 1;
		
		$putPolicy = new Qiniu_MacHttpClient(null);
		$err = Qiniu_RS_Delete($putPolicy, $parameter['bucket'], $attachment);
		return array('result' => $err !== null ? $err->Code : 'done', 'msg' => $err->Err);
	}
	
	/*获取文件地址*/
	public function getfile($parameter, $filepath, $type) 
	{
		require_once("rs.php");

		Qiniu_SetKeys($parameter['access'], $parameter['secret']);
		$baseUrl = Qiniu_RS_MakeBaseUrl($parameter['attachdomain'], $filepath);
		$getPolicy = new Qiniu_RS_GetPolicy();
		
		if($type == 'cover'){
			$baseUrl = $baseUrl.'?vframe/jpg/offset/5/w/800';
		}
		
		$filepath = $getPolicy->MakeRequest($baseUrl, null);
		$filepath = stristr($filepath,'http://') ? $filepath : 'http://'.$filepath;

		return $filepath;
    }
	
}


?>