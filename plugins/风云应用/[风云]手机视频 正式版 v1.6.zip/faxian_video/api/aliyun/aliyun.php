<?php

class aliyun 
{

    var $name = '&#38463;&#37324;&#20113;';  //阿里云
	var $desc;
	
	
    /*设置项目*/
	public function getsetting($val=array()) 
	{
		$settings = array(
		    'region' => array( //区域
				'title' => '&#23384;&#20648;&#21306;&#22495;',  //设置项目名称
				'type' => 'mradio2',   //表单类型
				'default' => array(
					'oss-cn-hangzhou'=>'&#21326;&#19996; 1;',
					'oss-cn-shanghai'=>'&#21326;&#19996; 2',
					'oss-cn-qingdao'=>'&#21326;&#21271; 1',
					'oss-cn-beijing'=>'&#21326;&#21271; 2',
					'oss-cn-zhangjiakou'=>'&#21326;&#21271; 3',
					'oss-cn-huhehaote'=>'&#21326;&#21271; 5',
					'oss-cn-shenzhen'=>'&#21326;&#21335; 1',
					'oss-cn-hongkong'=>'&#39321;&#28207;',
					'oss-us-west-1'=>'&#32654;&#22269;&#35199;&#37096;&#32;&#49;&#32;&#65288;&#30789;&#35895;&#65289;',
					'oss-us-east-1'=>'&#32654;&#22269;&#19996;&#37096;&#32;&#49;&#32;&#65288;&#24343;&#21513;&#23612;&#20122;&#65289;',
					'oss-ap-southeast-1'=>'&#20122;&#22826;&#19996;&#21335;&#32;&#49;&#32;&#65288;&#26032;&#21152;&#22369;&#65289;',
					'oss-ap-southeast-2'=>'&#20122;&#22826;&#19996;&#21335;&#32;&#50;&#32;&#65288;&#24713;&#23612;&#65289;',
					'oss-ap-southeast-3'=>'&#20122;&#22826;&#19996;&#21335;&#32;&#51;&#32;&#65288;&#21513;&#38534;&#22369;&#65289;',
					'oss-ap-southeast-5'=>'&#20122;&#22826;&#19996;&#21335;&#32;&#53;&#32;&#40;&#38597;&#21152;&#36798;&#41;',
					'oss-ap-northeast-1'=>'&#20122;&#22826;&#19996;&#21271;&#32;&#49;&#32;&#65288;&#26085;&#26412;&#65289;',
					'oss-ap-south-1'=>'&#20122;&#22826;&#21335;&#37096;&#32;&#49;&#32;&#65288;&#23391;&#20080;&#65289;',
					'oss-eu-central-1'=>'&#27431;&#27954;&#20013;&#37096;&#32;&#49;&#32;&#65288;&#27861;&#20848;&#20811;&#31119;&#65289;',
					'oss-me-east-1'=>'&#20013;&#19996;&#19996;&#37096;&#32;&#49;&#32;&#65288;&#36842;&#25308;&#65289;',
					),
				'value' => $val['area'],      //默认值
			),
		    'attachdomain' => array(  //绑定域名
				'title' => '&#38468;&#20214;&#22495;&#21517;',
				'type' => 'text',   //表单类型
				'value' => $val['attachdomain'],      //默认值
			),
			'access' => array(
				'title' => 'Access Key',
				'type' => 'text',
				'value' => $val['access'],
			),
			'secret' => array(
				'title' => 'Secret',
				'type' => 'text',
				'value' => $val['secret'],
			),
			'bucket' => array(
				'title' => 'Bucket',
				'type' => 'text',
				'value' => $val['bucket'],
			)
		);
		return $settings;
	}
	
	/*上传文件函数*/
	public function uploadfile($parameter, $attachment, $source)
	{
		require_once("conf.inc.php");
		require_once("aliyun.class.php");
		$oss_sdk = new ALIOSS($parameter['access'], $parameter['secret'], $parameter['region'].'.aliyuncs.com');
		
		$response = $oss_sdk -> upload_file_by_file($parameter['bucket'], $attachment, $source);
		return array('result' => $response->status != 204 && $response->status != 200 ? $response->status : 'done', 'msg' => $response->body);
    }
	
	/*删除文件*/
	public function deletefile($parameter, $attachment)
	{
		require_once("conf.inc.php");
		require_once("aliyun.class.php");
		$oss_sdk = new ALIOSS($parameter['access'], $parameter['secret'], $parameter['region'].'.aliyuncs.com');
		
		$response = $oss_sdk -> delete_object($parameter['bucket'], $attachment);
		return array('result' => $response->status != 204 && $response->status != 200 ? $response->status : 'done', 'msg' => $response->body);
	}
	
	/*获取文件地址函数*/
	public function getfile($parameter, $filepath, $type) 
	{
		require_once("conf.inc.php");
		require_once("aliyun.class.php");
		$oss_sdk = new ALIOSS($parameter['access'], $parameter['secret'], $parameter['region'].'.aliyuncs.com');

		if($type == 'cover'){
			$filepath = $filepath.'?process=video/snapshot,t_5000,f_jpg,w_800,h_0,m_fast';
		}
		
		$response = $oss_sdk -> get_sign_url($parameter['bucket'], $filepath, 3600);
		$filepath = $parameter['attachdomain'].'/'.$response;
		$filepath = preg_match("/^http(s)?:\\/\\/.+/", $filepath) ? $filepath : 'http://'.$filepath;

		return $filepath;
		
    }
	
}


?>