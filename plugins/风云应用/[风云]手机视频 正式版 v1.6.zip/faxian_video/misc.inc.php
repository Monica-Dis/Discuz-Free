<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once("class/common.class.php");

if($_GET['op'] == 'token')
{
	if($_GET['formhash'] != FORMHASH)
	{
		echo json_encode(array('vid' => -1, 'msg' => 'Illegal access'));
		exit;
	}
	
	if(!$_G['uid'])
	{
		echo json_encode(array('result' => -1, 'msg' => 'Permission denied'));
		exit;
	}

	$parameter = VIDEO::getconfig();
	VIDEO::cleardebris(86400);
	
	$data = array('uid' => $_G['uid'], 'attachment' => $_GET['name'], 'lasttime' => $_G['timestamp']);
	$vid = C::t('#faxian_video#faxian_video')->insert($data, true);
	
	if($parameter['apiname'] == 'aliyun')
	{
	    echo json_encode(array('vid' => $vid, 'api' => $parameter['apiname'], 'region' => $parameter['region'], 'access' => $parameter['access'], 'secret' => $parameter['secret'], 'bucket' => $parameter['bucket']));
		exit;
	}else if($parameter['apiname'] == 'qiniu')
	{
		require_once("api/qiniu/io.php");
	    require_once("api/qiniu/rs.php");
		
		$parameter['area'] && $QINIU_UP_HOST = 'http://'.$parameter['area'];
		Qiniu_SetKeys($parameter['access'], $parameter['secret']);
		$putPolicy = new Qiniu_RS_PutPolicy($parameter['bucket']);
		$upToken = $putPolicy->Token();
		$putExtra = new Qiniu_PutExtra();
		$putExtra->Crc32 = 1;
		
		$config = array();
		echo json_encode(array('vid' => $vid, 'uid' => $_G['uid'], 'api' => $parameter['apiname'], 'token' => $upToken, 'putExtra' => $putExtra, 'config' => $config));
		exit;
	}
}

if($_GET['op'] == 'setcover')
{
	if($_GET['formhash'] != FORMHASH)
	{
		echo json_encode(array('vid' => -1, 'msg' => 'Illegal access'));
		exit;
	}
	
	$vid = intval($_GET['vid']);
	if(!$vid)
	{
		echo json_encode(array('vid' => -2, 'msg' => 'Missing parameters'));
		exit;
	}
	
	$data = array('status' => 1);
	if($_FILES['cover']['tmp_name'])
	{
		$filetype = array('jpg','gif','png','jpeg');
		$upload = new discuz_upload();
		$ext = $upload->fileext($_FILES['cover']['name']);
		if(in_array($ext, $filetype))
		{
			if($upload->init($_FILES['cover'], 'album', random(3, 1), random(8)) && $upload->save())
			{
				$data['cover'] = $upload->attach['attachment'];
			}
		}
	}
	
	C::t('#faxian_video#faxian_video')->update($vid, $data);
	echo json_encode(array('vid' => $vid));
	exit;
}

if($_GET['op'] == 'getfile')
{
	if($_GET['formhash'] != FORMHASH)
	{
		echo json_encode(array('result' => -1, 'msg' => 'Illegal access'));
		exit;
	}
	
	$parameter = VIDEO::getconfig();
	
	include_once DISCUZ_ROOT.'/source/plugin/faxian_video/api/'.$parameter['apiname'].'/'.$parameter['apiname'].'.php';
	
	if(class_exists($parameter['apiname']))
	{
		$obj = new $parameter['apiname']();
		$response = $obj->getfile($parameter, $_GET['name'], $_GET['type']);
	}
	
	dheader('location: '.$response);
}


if($_GET['op'] == 'delfile')
{
	if($_GET['formhash'] != FORMHASH)
	{
		echo json_encode(array('result' => -1, 'msg' => 'Illegal access'));
		exit;
	}
	
	$vid = intval($_GET['vid']);
	
	$attach = C::t('#faxian_video#faxian_video')->fetch($vid);
	
	if(!checkperm('managealbum') && $attach['uid'] != $_G['uid'])
	{
		echo json_encode(array('result' => -2, 'msg' => 'Permission denied'));
		exit;
	}
	
	$parameter = VIDEO::getconfig();
	
	include_once DISCUZ_ROOT.'/source/plugin/faxian_video/api/'.$parameter['apiname'].'/'.$parameter['apiname'].'.php';
	
	$res = array();
	if(class_exists($parameter['apiname']))
	{
		$obj = new $parameter['apiname']();
		$res = $obj->deletefile($parameter, $attach['attachment']);
	}
	
	if($res['result'] == 'done' || $attach['status'] < 1)
	{
		if($attach['cover'])
		{
			@unlink($_G['setting']['attachdir'].'/album/'.$attach['cover']);
		}
		
		C::t('#faxian_video#faxian_video')->delete($attach['vid']);
	}

	echo json_encode(array('result' => $res['result'], 'msg' => $res['msg']));
	exit;
}
//From: Dism_taobao_com
?>