<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*电脑板和手机版都会用到的方法*/
class plugin_faxian_video
{
	
	static function deletethread($value)
	{
		if($value['step'] == 'delete')
		{
			$videolist = C::t('#faxian_video#faxian_video')->fetch_all_by_tids($value['param'][0], NULL, CURSCRIPT);
			if($videolist)
			{
				global $_G;
				
				$_G['setting']['faxian_video'] = (array)unserialize($_G['setting']['faxian_video']);
				$api = $_G['cache']['plugin']['faxian_video']['remoteapi'];
				$parameter = $_G['setting']['faxian_video']['attachment'][$api];
				$parameter['apiname'] = $api;
				
				include_once DISCUZ_ROOT.'/source/plugin/faxian_video/api/'.$parameter['apiname'].'/'.$parameter['apiname'].'.php';
				$res = array();
				if(class_exists($parameter['apiname']))
				{
					$obj = new $parameter['apiname']();
					foreach($videolist as $attach)
					{
						$res = $obj->deletefile($parameter, $attach['attachment']);
						if($res['result'] == 'done')
						{
							if($attach['cover'])
							{
								@unlink($_G['setting']['attachdir'].'/album/'.$attach['cover']);
							}
						    C::t('#faxian_video#faxian_video')->delete($attach['vid']);
						}else{
							C::t('#faxian_video#faxian_video')->update($vid, array('status' => -1));
						}
					}
				}
			}
		}
	}
	
	static function script()
	{
		global $_G;
		
		$allowplate = (array)unserialize($_G['cache']['plugin']['faxian_video']['allowplate']);
		if($_G['cache']['plugin']['faxian_video']['upload'] && (($_G['basescript'] == 'group' && $_G['cache']['plugin']['faxian_video']['group']) || ($_G['basescript'] == 'forum' && in_array($_G['fid'], $allowplate) && $_GET['action'] != 'reply')))
		{
			$videolist = array();
			if(!empty($_G['tid']))
			{
			    $videolist = C::t('#faxian_video#faxian_video')->fetch_all_by_tid($_G['tid'], CURSCRIPT);
			}

		    include_once template('faxian_video:embed');
		    return faxian_tpl_up($videolist);
		}
	}
	
	static function set_video($param)
	{
		if(in_array($param['param'][0], array('post_edit_succeed', 'post_edit_mod_succeed', 'post_newthread_succeed', 'post_newthread_mod_succeed')))
		{
			if($_GET['videoid'] && $param['param'][2]['tid'])
			{
				$vid = intval($_GET['videoid']);
				$data = array('tid' => $param['param'][2]['tid'], 'module' => CURSCRIPT);
				C::t('#faxian_video#faxian_video')->update($vid, $data);
			}
		}
	}
	
	static function discuzcode($value)
	{
		global $_G;
		if($_G['cache']['plugin']['faxian_video']['external'])
		{
			require_once (DISCUZ_ROOT."/source/plugin/faxian_video/class/media.class.php");
			
			$msglower = strtolower($_G['discuzcodemessage']);
			if(strpos($msglower, '[/audio]') !== FALSE)
			{
				$_G['discuzcodemessage'] = preg_replace_callback("/\[audio\=?([\w,]+)?\]\s*([^\[\<\r\n]+?)\s*\[\/audio\]/is", '_discuzcode_callback_parseaudio_video', $_G['discuzcodemessage']);
			}
			if(strpos($msglower, '[/media]') !== FALSE)
			{
				$_G['discuzcodemessage'] = preg_replace_callback("/\[media\=?([\w,]+)?\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/is", '_discuzcode_callback_parsemedia_video', $_G['discuzcodemessage']);
			}
		}
	}
	
}

/*只有手机版会用到的方法*/
class mobileplugin_faxian_video extends plugin_faxian_video
{
	static function discuzcode($value)
	{
		global $_G;
		if($_G['cache']['plugin']['faxian_video']['external'])
		{
			require_once (DISCUZ_ROOT."/source/plugin/faxian_video/class/media.class.php");
			
			$msglower = strtolower($_G['discuzcodemessage']);
			if(strpos($msglower, '[/audio]') !== FALSE)
			{
				$_G['discuzcodemessage'] = preg_replace_callback("/\[audio\=?([\w,]+)?\]\s*([^\[\<\r\n]+?)\s*\[\/audio\]/is", '_discuzcode_callback_parseaudio_video', $_G['discuzcodemessage']);
			}
			if(strpos($msglower, '[/media]') !== FALSE)
			{
				$_G['discuzcodemessage'] = preg_replace_callback("/\[media\=?([\w,]+)?\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/is", '_discuzcode_callback_parsemedia_video', $_G['discuzcodemessage']);
			}
		}
	}
	
	static function analysis()
	{
		global $_G, $postlist;
		
		$post = reset($postlist);
		$html = '';
		foreach(C::t('#faxian_video#faxian_video')->fetch_all_by_tid($_G['tid'], CURSCRIPT) as $video)
		{
		    $html .= '<div><video style="width:100%;max-height:220px;" src="plugin.php?id=faxian_video:misc&formhash='.FORMHASH.'&op=getfile&name='.$video['attachment'].'" controls="controls" poster="'.$_G['setting']['attachurl'].'/album/'.$video['cover'].'"></video></div>';
		}
		$postlist[$post['pid']]['message'] = $postlist[$post['pid']]['message'].'<div class="video">'.$html.'</div>';
	}
	
	static function editnav()
	{
		global $_G;
		
		$allowplate = (array)unserialize($_G['cache']['plugin']['faxian_video']['allowplate']);
		if($_G['cache']['plugin']['faxian_video']['upload'] && (($_G['basescript'] == 'group' && $_G['cache']['plugin']['faxian_video']['group']) || ($_G['basescript'] == 'forum' && in_array($_G['fid'], $allowplate) && $_GET['action'] != 'reply')))
		{
		    return '<a id="VideoTrigger" onclick="Common.TabSwitch(this, \'#videobox\', 1);"><i class="icon">&#xe036;</i>&#35270;&#39057;</a>';
		}
	}
	
	static function global_footer_mobile()
	{
		global $op;
		if($op != 'add_success' && $_GET['mod'] == 'portalcp' && $_GET['ac'] == 'article')
		{
			global $_G;
		    if($_G['cache']['plugin']['faxian_video']['upload'] && $_G['cache']['plugin']['faxian_video']['portal'])
			{
				if(!empty($_GET['aid']))
				{
					$videolist = C::t('#faxian_video#faxian_video')->fetch_all_by_tid($_GET['aid'], CURSCRIPT);
				}
	
				include_once template('faxian_video:embed');
				return faxian_tpl_up($videolist);
			}
		}
	}
}

/**/
class plugin_faxian_video_portal extends plugin_faxian_video
{
	static function portalcp_output($param)
	{
		global $op,$aid;
		if($op == 'add_success' && $aid)
		{
			if($_GET['videoid'])
			{
				$vid = intval($_GET['videoid']);
				$data = array('tid' => $aid, 'module' => 'portal');
				C::t('#faxian_video#faxian_video')->update($vid, $data);
			}
		}
	}
	
	static function portalcp_bottom()
	{
		global $_G;
		
		if($_G['cache']['plugin']['faxian_video']['upload'] && $_G['cache']['plugin']['faxian_video']['portal'])
		{
		    if(!empty($_GET['aid']))
			{
			    $videolist = C::t('#faxian_video#faxian_video')->fetch_all_by_tid($_GET['aid'], 'portal');
			}

		    include_once template('faxian_video:embed');
		    return faxian_tpl_up($videolist);
		}
	}
	
	static function view_article_content()
	{
		global $_G;

		$html = '';
		foreach(C::t('#faxian_video#faxian_video')->fetch_all_by_tid($_GET['aid'], 'portal') as $video)
		{
		    $html .= '<div><video style="width:100%;" src="plugin.php?id=faxian_video:misc&formhash='.FORMHASH.'&op=getfile&name='.$video['attachment'].'" controls="controls" poster="'.$_G['setting']['attachurl'].'/album/'.$video['cover'].'"></video></div>';
		}
		return '<div class="video">'.$html.'</div>';
	}
}

class plugin_faxian_video_forum extends plugin_faxian_video
{
	
	static function post_editorctrl_left(){
		global $_G;
		$allowplate = (array)unserialize($_G['cache']['plugin']['faxian_video']['allowplate']);
		if($_G['cache']['plugin']['faxian_video']['upload'] && (($_G['basescript'] == 'group' && $_G['cache']['plugin']['faxian_video']['group']) || ($_G['basescript'] == 'forum' && in_array($_G['fid'], $allowplate) && $_GET['action'] != 'reply')))
		{
		    return '<a id="VideoTrigger" title="&#19978;&#20256;&#35270;&#39057;" href="javascript:;" onclick="showupvideo();">&#19978;&#20256;&#35270;&#39057;</a>';
		}
	}
	
	static function post_bottom()
	{
		return self::script();
	}
	
	static function viewthread_modaction()
	{
		global $_G, $videolist;
		
		$videolist = C::t('#faxian_video#faxian_video')->fetch_all_by_tid($_G['tid'], CURSCRIPT);
		if($videolist)
		{
		    include_once template('faxian_video:embed');
		    return faxian_tpl_video($videolist);
		}else{
			return array();
		}
	}
	
	function post_message($param)
	{
		if(submitcheck('topicsubmit') || submitcheck('editsubmit'))
		{
			self::set_video($param);
		}
	}
}

class plugin_faxian_video_group extends plugin_faxian_video
{
	static function post_editorctrl_left(){
		global $_G;
		$allowplate = (array)unserialize($_G['cache']['plugin']['faxian_video']['allowplate']);
		if($_G['cache']['plugin']['faxian_video']['upload'] && (($_G['basescript'] == 'group' && $_G['cache']['plugin']['faxian_video']['group']) || ($_G['basescript'] == 'forum' && in_array($_G['fid'], $allowplate) && $_GET['action'] != 'reply')))
		{
		    return '<style>.edt .bar a#VideoTrigger { background: transparent url(./source/plugin/faxian_video/static/images/video_min.png) no-repeat 0 0; }</style>
			<a id="VideoTrigger" title="&#19978;&#20256;&#35270;&#39057;" href="javascript:;" onclick="showupvideo();">&#19978;&#20256;&#35270;&#39057;</a>';
		}
	}
	
	static function post_bottom()
	{
		return self::script();
	}
	
	static function viewthread_modaction()
	{
		global $_G,$videolist;
		
		$videolist = C::t('#faxian_video#faxian_video')->fetch_all_by_tid($_G['tid'], CURSCRIPT);
		if($videolist)
		{
		    include_once template('faxian_video:embed');
		    return faxian_tpl_video($videolist);
		}else{
			return array();
		}
	}
	
	function post_message($param)
	{
		if(submitcheck('topicsubmit') || submitcheck('editsubmit'))
		{
			self::set_video($param);
		}
	}
}

/**/
class mobileplugin_faxian_video_portal extends mobileplugin_faxian_video
{
	static function portalcp_output($param)
	{
		global $op,$aid;
		if($op == 'add_success' && $aid)
		{
			if($_GET['videoid'])
			{
				$vid = intval($_GET['videoid']);
				$data = array('tid' => $aid, 'module' => 'portal');
				C::t('#faxian_video#faxian_video')->update($vid, $data);
			}
		}
	}
	
	static function portalcp_editnav_mobile()
	{
		global $_G;
		
		if($_G['cache']['plugin']['faxian_video']['upload'] && $_G['cache']['plugin']['faxian_video']['portal'])
		{
		    return '<a id="VideoTrigger" onclick="Common.TabSwitch(this, \'#videobox\', 1);"><i class="icon">&#xe036;</i>&#35270;&#39057;</a>';
		}
	}
	
	static function view_article_content_mobile()
	{
		global $_G;

		$html = '';
		foreach(C::t('#faxian_video#faxian_video')->fetch_all_by_tid($_GET['aid'], 'portal') as $video)
		{
		    $html .= '<div><video style="width:100%;" src="plugin.php?id=faxian_video:misc&formhash='.FORMHASH.'&op=getfile&name='.$video['attachment'].'" controls="controls" poster="'.$_G['setting']['attachurl'].'/album/'.$video['cover'].'"></video></div>';
		}
		return '<div class="video">'.$html.'</div>';
	}
}

class mobileplugin_faxian_video_forum extends mobileplugin_faxian_video
{
	
	function viewthread_output()
	{
		self::analysis();
	}
	
	static function post_editnav_mobile()
	{
		return self::editnav();
	}
	
	static function post_bottom_mobile()
	{
		return self::script();
	}
	
	function post_message($param)
	{
		if(submitcheck('topicsubmit') || submitcheck('editsubmit'))
		{
			self::set_video($param);
		}
	}
}

class mobileplugin_faxian_video_group extends mobileplugin_faxian_video
{
	function viewthread_output()
	{
		self::analysis();
	}
	
	static function post_editnav_mobile()
	{
		return self::editnav();
	}
	
	static function post_bottom_mobile()
	{
		return self::script();
	}
	
	function post_message($param)
	{
		if(submitcheck('topicsubmit') || submitcheck('editsubmit'))
		{
			self::set_video($param);
		}
	}
}
//From: Dism_taobao_com
?>