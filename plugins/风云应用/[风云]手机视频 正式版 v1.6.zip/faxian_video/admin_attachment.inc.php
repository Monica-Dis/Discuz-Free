<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP'))
{
    exit('Access Denied');
}

require (DISCUZ_ROOT."/source/plugin/faxian_video/class/admin.class.php");

cpheader();
		  
$pluginurl = 'plugins&operation=config&do='.$_GET['do'].'&identifier=faxian_video&pmod='.$_GET['pmod'];


/*===========================我是一条分割线============================*/

$interfaceapi = ADMIN::loadapi(DISCUZ_ROOT.'/source/plugin/faxian_video/api', array('name'));

$_GET['mods'] = $_GET['mods'] ? $_GET['mods'] : key($interfaceapi);
$formurl = $pluginurl.'&mods='.$_GET['mods'];

$ApiArr = array();
foreach($interfaceapi as $apiname => $val)
{
	$ApiArr[] = array($val['name'], $pluginurl.'&mods='.$apiname, $_GET['mods'] == $apiname);
}

ADMIN::showsubmenu('', $ApiArr);

$setting = C::t('common_setting')->fetch_all(array('faxian_video'));
$setting = (array)unserialize($setting['faxian_video']);

if(!preg_match("/^[a-z0-9_\-]+$/i", $_GET['mods']) || !$_GET['mods'])
{
	cpmsg('Unidentified identity', 'action='.$pluginurl.'&mods='.$_GET['mods']);
}

$apiname = $_GET['mods'];

if(!submitcheck('submit'))
{
	showformheader($formurl);
	showtableheader();
	include_once DISCUZ_ROOT.'/source/plugin/faxian_video/api/attachment/'.$apiname.'/'.$apiname.'.php';
	if(class_exists($apiname))
	{
		$api = new $apiname();
		$apisetting = $api->getsetting($setting['attachment'][$apiname]);	

		foreach($apisetting as $k => $v)
		{
			if(in_array($v['type'], array('select','radio','mradio','mradio2','mcheckbox','mcheckbox2','mselect')))
			{
				foreach($v['default'] as $n => $m)
				{
					$dbval[] = array($n, diconv($m,'utf-8', CHARSET));
				}
				showsetting(diconv($v['title'], 'utf-8', CHARSET), array('attachment['.$apiname."][".$k."]", $dbval), dstripslashes($setting['attachment'][$apiname][$k]), $v['type'], '', '', $v['desc']);
			}else{
				showsetting(diconv($v['title'], 'utf-8', CHARSET), 'attachment['.$apiname."][".$k."]", dstripslashes($setting['attachment'][$apiname][$k]), $v['type'], '', '', $v['desc']);
			}
		}
	}

	showsubmit('submit', 'submit');
	showtablefooter();/*dism-Taobao-com*/
	/*di'.'sm.t'.'aoba'.'o.com*/showformfooter();
}else{
	$setting['attachment'][$apiname] = $_GET['attachment'][$apiname];
	C::t('common_setting')->update_batch(array('faxian_video' => serialize($setting)));
	updatecache('setting');
	cpmsg('setting_update_succeed', 'action='.$pluginurl.'&mods='.$_GET['mods'], 'succeed');
}
//From: Dism_taobao_com
?>