<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `cdb_faxian_video` (
  `vid` int(9) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(9) NOT NULL,
  `uid` int(9) NOT NULL,
  `module` varchar(255) NOT NULL,
  `attachment` varchar(255) NOT NULL,
  `cover` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `lasttime` int(10) NOT NULL,
  PRIMARY KEY (`vid`),
  KEY `tid` (`tid`)
) ENGINE=MyISAM;
EOF;
runquery($sql);

$finish = TRUE;	
?>