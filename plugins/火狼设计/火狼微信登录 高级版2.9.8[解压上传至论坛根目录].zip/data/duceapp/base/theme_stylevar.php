<?php
/*
duceapp_wechat cache file, do not modify me!
Created: Aug 4, 2020, 19:07
*/

!defined('IN_DISCUZ') && exit('Access Denied');

$theme_styles = array (
  'themecolor' => '',
  'textcolor' => '',
  'linkcolor' => '',
  'buttoncolor' => '',
  'fontweight' => '0',
);
?>