<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90715
 * Date: 2020-08-06 03:25:46
 * File: logging.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

define('ALLOWGUEST', 1);
define('DUCEAPP_ACCESS', 1);

chdir('../../../');

$_GET['id'] = $_POST['id'] = 'duceapp_wechat';

require 'plugin.php';