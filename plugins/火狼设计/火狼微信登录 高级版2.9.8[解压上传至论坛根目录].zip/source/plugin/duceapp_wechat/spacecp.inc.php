<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2019-08-02
 * Version: 3.00527
 * Date: 2020-08-06 03:25:46
 * File: spacecp.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(submitcheck('resetpwsubmit') && $_G['duceapp_wechatuser']['isregister'] == 1) {
	if($_G['setting']['strongpw']) {
		$strongpw_str = array();
		if(in_array(1, $_G['setting']['strongpw']) && !preg_match("/\d+/", $_GET['newpassword1'])) {
			$strongpw_str[] = lang('member/template', 'strongpw_1');
		}
		if(in_array(2, $_G['setting']['strongpw']) && !preg_match("/[a-z]+/", $_GET['newpassword1'])) {
			$strongpw_str[] = lang('member/template', 'strongpw_2');
		}
		if(in_array(3, $_G['setting']['strongpw']) && !preg_match("/[A-Z]+/", $_GET['newpassword1'])) {
			$strongpw_str[] = lang('member/template', 'strongpw_3');
		}
		if(in_array(4, $_G['setting']['strongpw']) && !preg_match("/[^a-zA-z0-9]+/", $_GET['newpassword1'])) {
			$strongpw_str[] = lang('member/template', 'strongpw_4');
		}
		if($strongpw_str) {
			showmessage(lang('member/template', 'password_weak').implode(',', $strongpw_str));
		}
	}
	if($_GET['newpassword1'] !== $_GET['newpassword2']) {
		showmessage('profile_passwd_notmatch');
	}
	if(!$_GET['newpassword1'] || $_GET['newpassword1'] != addslashes($_GET['newpassword1'])) {
		showmessage('profile_passwd_illegal');
	}

	loaducenter();

	$newusername = trim($_GET['newusername']);

	if ($_G['cache']['duceapp_wechat']['allowchange'] && $newusername && $newusername != $_G['member']['username']) {
		$usernamelen = dstrlen($newusername);
		if ($usernamelen < 3) {
			showmessage('profile_username_tooshort');
		} elseif($usernamelen > 15) {
			showmessage('profile_username_toolong');
		}
		if (uc_get_user(addslashes($newusername)) || C::t('common_member')->fetch_uid_by_username($newusername) || C::t('common_member_archive')->fetch_uid_by_username($newusername)) {
			if ($_G['inajax']) {
				showmessage('profile_username_duplicate');
			} else {
				showmessage('register_activation_message', 'member.php?mod=logging&action=login', array('username' => $newusername));
			}
		}
		uc_user_edit(addslashes($_G['member']['username']), null, $_GET['newpassword1'], null, 1);
		$uc_tables = array(
			'members' => array('id' => 'uid', 'name' => 'username'),
			'mergemembers' => array('id' => 'username', 'name' => 'username'),
			'protectedmembers' => array('id' => 'uid', 'name' => 'username'),
		);
		$uc_db = $uc_controls['user']->db;
		foreach ($uc_tables as $table => $conf) {
			$uc_db->query("UPDATE ".UC_DBTABLEPRE.$table." SET ".DB::field($conf['name'], $newusername)." WHERE ".DB::field($conf['id'], $_G['member'][$conf['id']]));
		}

		require_once libfile('class/duceapp_wechatapi', 'plugin/duceapp_wechat');
		duceapp_wechatapi::report('synrename', array('uid' => $_G['uid'], 'username' => $_G['member']['username'], 'newusername' => $newusername));
		uc_user_edit(addslashes($newusername), null, $_GET['newpassword1'], null, 1);
	} else {
		uc_user_edit(addslashes($_G['member']['username']), null, $_GET['newpassword1'], null, 1);
		C::t('#duceapp_wechat#duceapp_wechat_member')->update($_G['uid'], array('isregister' => 2, 'username' => $_G['member']['username']));
	}
	if (defined('DUCEAPP_SMSAUTH')) {
		C::t('#duceapp_smsauth#duceapp_member')->batch_update($_G['uid'], array('isregister' => 2));
	}
	showmessage('duceapp_wechat:wechat_password_reset', $_GET['from'] == 'spacecp' || $_GET['from'] == 'contact' ? 'home.php?mod=spacecp&ac=profile&op=password'.($_GET['from'] == 'contact' ? '&from=contact#contact' : '') : dreferer());

} elseif (submitcheck('settingsubmit')) {

	if ($_G['cache']['duceapp_wechat']['tmplsend']) {
		$notifyclose = array();
		foreach($_G['cache']['duceapp_wechat']['tmplsend'] as $actiontype => $value) {
			if ($value['allowclose'] && !intval($_GET['tmplsend'][$actiontype])) {
				$notifyclose[$actiontype] = 1;
			}
		}
		$_G['duceapp_wechatuser']['setting'] = is_array($_G['duceapp_wechatuser']['setting']) ? $_G['duceapp_wechatuser']['setting'] : unserialize($_G['duceapp_wechatuser']['setting']);
		$_G['duceapp_wechatuser']['setting']['notifyclose'] = $notifyclose;
		C::t('duceapp_wechat_member')->update($_G['uid'], array('setting' => serialize($_G['duceapp_wechatuser']['setting'])));

		showmessage('profile_succeed', 'home.php?mod=spacecp&ac=plugin&id=duceapp_wechat:spacecp&d=tmplsend');
	} else {
		showmessage('undefined_action');
	}

} elseif (submitcheck('unbindsubmit') && $_G['duceapp_wechatuser']['isregister'] != 1) {

	require_once libfile('function/member');	
	C::t('#duceapp_wechat#duceapp_wechat_member')->delete($_G['uid']);
	clearcookies();
	showmessage('duceapp_wechat:wechat_message_unbinded', $_G['siteurl']);

} elseif (CURSCRIPT == 'plugin') {

	include template('duceapp_wechat:spacecp');

}