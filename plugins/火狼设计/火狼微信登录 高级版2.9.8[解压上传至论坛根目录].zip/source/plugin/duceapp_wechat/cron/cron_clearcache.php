<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.91123
 * Date: 2020-08-06 03:25:46
 * File: cron_clearcache.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

/*
cronname:duceapp_clearcache
week:
day:
hour:00
minute:00
*/

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$cachedir = array(
	DISCUZ_ROOT.'./data/duceapp/wechat/qrcode',
	DISCUZ_ROOT.'./data/duceapp/wechat/rescource',
);

$timelife = array(
	'qrcode' => 1800, 
	'rescource' => 86400,
);

foreach($cachedir as $dir => $path) {
	$type = basename($path);
	duceapp_wechat_clearcache($path, $type, $timelife[$type]);
}

function duceapp_wechat_clearcache($path, $type, $timelife = 1800) {
	if ($d = dir($path)) {
		while($fd = $d->read()) {
			if (in_array($fd, array('.', '..'))) {
				continue;
			}
			$fp = $path.'/'.$fd;
			if (is_dir($fp)) {
				duceapp_wechat_clearcache($fp, $type, $timeout);
			} elseif (preg_match('/\.jpg$/i', $fd) && @filemtime($fp) + $timelife < time()) {
				@unlink($fp);
			}
		}
		$d->close();
	}
}