<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90920
 * Date: 2020-08-06 03:25:46
 * File: check.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

define('DUCEAPP_ROOT', dirname(__FILE__).'/');

$base_supportver = '1.2.7';
@include DUCEAPP_ROOT.'language/lang_'.(file_exists(DUCEAPP_ROOT.'language/lang_check.php') ? 'check' : 'check_'.currentlang()).'.php';
$duceapp_base = C::t('common_plugin')->fetch_by_identifier('duceapp_base');
if ($duceapp_base && $duceapp_base['version'] < $base_supportver) {
	cpmsg('duceapp_base_supportver');
	exit;
}
if (!file_exists($admincss = DISCUZ_ROOT.'./source/plugin/duceapp_base/static/css/admin.css')) {
	include DUCEAPP_ROOT.'install/duceapp_base.php';
	if (!file_exists($admincss)) {
		cpmsg('duceapp_base_nowriteaccess');
		exit;
	}
}
define('DUCEAPP_AUTHC', '');
define('DUCEAPP_SINGLE', $duceapp_base ? 'duceapp_base' : basename(dirname(__FILE__)));