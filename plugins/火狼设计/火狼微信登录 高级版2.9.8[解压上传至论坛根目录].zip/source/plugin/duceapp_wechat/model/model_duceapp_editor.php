<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2019-01-31
 * Version: 3.90622
 * Date: 2020-08-06 03:25:46
 * File: model_duceapp_editor.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class model_duceapp_editor
{
	public function toolbar($return = false) {
		global $duceapp_editor;
		if (!$duceapp_editor) {
			@include duceapp_language('editor');
		}
		$htmlcode = <<<EOF
<div id="editor_uibar" class="editor_uibar">
	<div id="editor_tools" class="editor_tools edui_disabled cl">
		<div class="cl">
			<a class="edui_default edui_undo edui_disabled" title="{Undo}" href="javascript:;"></a>
			<a class="edui_default edui_redo edui_disabled" title="{Redo}" href="javascript:;"></a>
			<div class="edui_separator"></div>
			<a class="edui_default edui_box edui_fontsize" title="{Fontsize}" href="javascript:;">16px</a>
			<div class="edui_separator"></div>
			<a class="edui_default edui_blockquote" title="{Blockquote}" href="javascript:;"></a>
			<a class="edui_default edui_horizontal" title="{Horizontal}" href="javascript:;"></a>
			<div class="edui_separator"></div>
			<a class="edui_default edui_removeformat" title="{RemoveFormat}" href="javascript:;"></a>
			<a class="edui_default edui_formatmatch" title="{FormatMatch}" href="javascript:;"></a>
			<div class="edui_separator"></div>
			<a class="edui_default edui_link" title="{Link}" href="javascript:;"></a>
			<a class="edui_default edui_unlink edui_disabled" title="{Unlink}" href="javascript:;"></a>
		</div>
		<div class="cl" style="margin-top:10px;">
			<a class="edui_default edui_bold" title="{Bold}" href="javascript:;"></a>
			<a class="edui_default edui_italic" title="{Italic}" href="javascript:;"></a>
			<a class="edui_default edui_underline" title="{Underline}" href="javascript:;"></a>
			<a class="edui_default edui_box1" title="{Forecolor}" href="javascript:;">
				<span class="edui_forecolor"></span>
				<span class="edui_arrow"></span>
				<span class="colorbar" style="width:15px;"></span>
			</a>
			<a class="edui_default edui_box1" title="{Backcolor}" href="javascript:;">
				<span class="edui_backcolor"></span>
				<span class="edui_arrow"></span>
				<span class="colorbar"></span>
			</a>
			<div class="edui_separator"></div>
		</div>
	</div>
</div>
EOF;
		$htmlcode = preg_replace_callback("/\{([A-Z0-9_]+)\}/i", function($matches) use ($duceapp_editor) {
			return $duceapp_editor[strtolower($matches[1])];
		}, $htmlcode);
		
		if ($return) {
			return $htmlcode;
		}
		echo $htmlcode;
	}

	public function replace_callback_1() {
	}
}