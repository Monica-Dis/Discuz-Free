<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2020-03-03
 * Version: 3.00425
 * Date: 2020-08-06 03:25:46
 * File: model_duceapp_synlogin.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class model_duceapp_synlogin
{
	public $authorid;

	public function apply($pluginid = 'wechat') {
		global $_G;

		if (defined('DUCEAPP_SHUTSCRIPT') || !$_G['setting']['duceapp_synsite']) {
			return;
		}

		if ($this->authorid === null) {
			$this->authorid = $_G['uid'];
		}

		if ($_GET['referer']) {
			$_GET['referer'] = preg_replace('/[\?\&]?synauth\=[^\&]+?/i', '', $_GET['referer']);
		}

		if (!$_G['scheme']) {
			$_G['isHTTPS'] = ($_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS']) != 'off') ? true : false;
			$_G['scheme'] = 'http'.($_G['isHTTPS'] ? 's' : '');
		}

		$uid = $synlogin = 0;

		if (!$_G['uid'] && $_GET['synauth']) {
			list($uid, $clientip, $action) = explode("\t", authcode($_GET['synauth'], 'DECODE', $_G['config']['security']['authkey']));
			if (intval($uid) && $clientip == $_G['clientip']) {
				require_once libfile('function/member');
				$member = getuserbyuid($uid, 1);
				setloginstatus($member, 1296000);
				$synlogin = $_G['uid'];
			}
		}

		if ($_G['uid'] && $_GET['synlogout']) {
			list($uid, $clientip, $action) = explode("\t", authcode($_GET['synlogout'], 'DECODE', $_G['config']['security']['authkey']));
			if (intval($uid) && $clientip == $_G['clientip']) {
				require_once libfile('function/member');
				clearcookies();
			}
		}

		if ($_GET['ac'] == 'synlogin') exit();

		if (($synlogin || $_G['cookie']['duceapp_synlogin']) && !$_G['inajax']) {
			if (empty($synlogin)) {
				$authcode = $_G['cookie']['duceapp_synlogin'];
				list(,,$action) = explode("\t", authcode($authcode, 'DECODE', $_G['config']['security']['authkey']));
			} else {
				$authcode = $_GET['synauth'];
			}
			define('DUCEAPP_SHUTSCRIPT', 1);
			dsetcookie('duceapp_synlogin', '', -1);
			if ($action) {
				register_shutdown_function(array($this, 'shutscript'), $authcode, $action, $pluginid);
			}
		}
	}

	public function activate() {
		global $_G;
		static $value = null;
		if ($_G['setting']['duceapp_synsite'] && $value === null) {
			if ($_GET['action'] == 'logout') {
				$value = $this->authorid."\t".$_G['clientip']."\t".'synlogout';
			} elseif ($_G['uid']) {
				$value = $_G['uid']."\t".$_G['clientip']."\t".'synauth';
			}
			if ($value) {
				dsetcookie('duceapp_synlogin', $value = authcode($value, 'ENCODE', $_G['config']['security']['authkey'], 300), 2592000);
			}
		}
		return $value;
	}
	
	public function redirect($referer = '', $cross = false) {
		global $_G;
		$value = $this->activate();
		$referer = $referer ? $referer : dreferer();
		if ($value && ($cross || strpos($referer, preg_replace('/\/+$/', '', $_G['siteurl'])) === FALSE)) {
			$referer .= (strpos($referer, '?') !== false ? '&' : '?').'synauth='.urlencode($value);
		}
		return $referer;
	}

	public function shutscript($authcode = '', $action = 'synauth', $pluginid = 'wechat') {
		global $_G;
		$script = '';
		if ($_G['setting']['duceapp_synsite'] && $action && $authcode) {
			$query = '&'.$action.'='.urlencode($authcode);
			$regEx = $_G['scheme'].'\:\/\/'.preg_quote($_SERVER['HTTP_HOST'], '.');
			foreach(explode("\n", $_G['setting']['duceapp_synsite']) as $site) {
				$site = preg_replace('/\/+$/', '', trim($site));
				if (!preg_match('/^'.$regEx.'$/i', $site)) {
					$script .= '<script type="text/javascript" src="'.$site.'/plugin.php?id=duceapp_'.$pluginid.'&ac=synlogin'.$query.'"></script>';
				}
			}
		}
		echo $script;
	}
}