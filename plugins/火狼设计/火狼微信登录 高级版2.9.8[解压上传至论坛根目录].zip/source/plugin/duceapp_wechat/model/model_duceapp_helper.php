<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-12-04
 * Version: 3.00501
 * Date: 2020-08-06 03:25:46
 * File: model_duceapp_helper.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class model_duceapp_helper
{
	public function messagefunc($hscript, $script, $plugin_module, $method, $adminid = 0) {
		global $_G;
		if (strpos($plugin_module, '/')) {
			$class = dirname($plugin_module);
		} else {
			$class = $plugin_module;
			$plugin_module = $class.'/'.$class;
		}
		$msghook = $_G['setting'][HOOKTYPE][$hscript][$script];
		$msghook['module'][$class] = $plugin_module;
		$msghook['adminid'][$class] = $adminid;
		$msghook['messagefuncs'][$script][] = array($class, $method);
		$_G['setting'][HOOKTYPE][$hscript][$script] = $msghook;
	}

	public function pluginmenu($hook, $plugin_module, $method, $adminid = 0) {
		global $_G;
		list($plugindir) = explode(':', $plugin_module);
		$method = array_merge($_G['setting']['plugins'][$hook][$plugin_module] ? $_G['setting']['plugins'][$hook][$plugin_module] : array(
			'adminid' => $adminid,
			'name' => '',
			'url' => $method && $method['isDefault'] ? '' : 'plugin.php?id='.$plugindir,
			'directory' => $plugindir.'/',
		), $method);
		$_G['setting']['plugins'][$hook][$plugin_module] = $method;
	}

	public function get_seosetting($page, $data = array(), $defset = array(), $return = false) {
		global $_G, $navtitle, $metadescription, $metakeywords;
		if ($_G['inajax']) {
			return null;
		}
		$makehtml = $_G['makehtml'];
		$_G['makehtml'] = 1;
		$seoarray = get_seosetting($page, $data, $defset);
		$_G['makehtml'] = $makehtml;
		if ($return) {
			return $seoarray;
		}
		list($navtitle, $metadescription, $metakeywords) = $seoarray;
	}

	public function checkreferer() {
		$referer = parse_url($_SERVER['HTTP_REFERER']);
		$serverhost = $_SERVER['HTTP_HOST'];
		if (($pos = strpos($serverhost, ':')) !== false) {
			$serverhost = substr($serverhost, 0, $pos);
		}
		if ($referer['host'] != $serverhost) {
			exit();
		}
	}

	public function errormsg($message, $values = array(), $params = array()) {
		global $_G;
		$a = array('showdialog' => 1, 'showmsg' => 1, 'closetime' => empty($_G['duceapp_base']['showalert']));
		$values = $values ? $values : array();
		$values['rd'] = 1;
		showmessage($message, '', $values, $params ? array_merge($a, $params) : $a);
	}

	public function ajaxoutput($content = '') {
		global $_G;
		include_once template('common/header_ajax');
		echo $content;
		include_once template('common/footer_ajax');
	}
}