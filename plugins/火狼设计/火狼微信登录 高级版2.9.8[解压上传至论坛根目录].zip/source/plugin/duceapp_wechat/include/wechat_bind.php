<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00416
 * Date: 2020-08-06 03:25:46
 * File: wechat_bind.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if (isset($_GET['check'])) {
	$code = authcode(base64_decode($_GET['check']), 'DECODE', $_G['config']['security']['authkey']);
	if ($code) {
		$authcode = C::t('#duceapp_wechat#duceapp_wechat_authcode')->fetch_by_code($code);
		if ($authcode['status'] == 1) {
			include_once libfile('function/member');
			$member = getuserbyuid($authcode['uid'], 1);
			setloginstatus($member, 1296000);
			dsetcookie('duceapp_wechat_ticket', '', -1);
			C::m('#duceapp_base#duceapp_synlogin')->activate();
			$echostr = 'done';
		} elseif ($authcode['status'] == -1) {
			$echostr = '2';
		} else {
			$echostr = '1';
		}
	} else {
		$echostr = '-1';
	}

	if (!ob_start($_G['gzipcompress'] ? 'ob_gzhandler' : null)) {
		ob_start();
	}
	if ($echostr === 'done'){
		C::t('#duceapp_wechat#duceapp_wechat_authcode')->delete($authcode['sid']);
		if (!$_G['duceapp_discuzuid'] && $_G['uid']) {
			$_G['duceapp_discuzuid'] = $_G['uid'];
			plugin_duceapp_wechat::_tmplsend('logon');
		}		
	}
	include template('common/header_ajax');
	echo $echostr;
	include template('common/footer_ajax');
}

$_GET['loc'] = $ac == 'bind' ? 1 : $_GET['loc'];
$smsauth = defined('DUCEAPP_SMSAUTH') && $_G['cache']['duceapp_wechat']['smsauth'] && $_G['duceapp_member']['cellphone'];
$authkey = $_G['config']['security']['authkey'];
$loginurl = $_G['siteurl'].$_G['duceapp_wechataccess'];

if ($_G['uid'] && submitcheck('confirmsubmit')) {
	if ($smsauth) {
		duceapp_smsauth_checkqauth();
		$result = $_G['uid'];
	} else {
		loaducenter();
		list($result) = uc_user_login($_G['uid'], $_GET['passwordconfirm'], 1, 0);
	}
	if ($result >= 0) {
		dsetcookie('qrauth', $_G['cookie']['qrauth'] = base64_encode(authcode($result, 'ENCODE', $authkey, 300)));
		showmessage('', defined('IN_MOBILE') ? $_G['duceapp_wechataccess'].'ac=login' : dreferer());
	}
	showmessage('login_password_invalid');
}

if ($_G['duceapp_wechatuser']){
	include template('common/header');
	echo '<script type="text/javascript" reload="1">'.(defined('IN_MOBILE') ? 'popup.close();' : 'hideWindow(\'wechat_bind\');').'window.location.reload();</script>';
	include template('common/footer');
	exit;
}

if ($_G['duceapp_member']['isregister'] > 0){
	$qrauth = true;
} elseif ($_G['cookie']['qrauth']) {
	$qrauth = authcode(base64_decode($_G['cookie']['qrauth']), 'DECODE', $authkey);
}

if ($smsauth && $_G['uid'] && !$qrauth) {
	$actionurl = $loginurl.'ac=bind&infloat=yes&confirmsubmit=yes&handlekey='.$_GET['handlekey'];
	$succeedhandle = 'duceapp_wechat:smsauth_succeedhandle';
	include_once template('duceapp_smsauth:authconfirm');
	exit;
}

$showqrcode = !$_G['uid'] || $_G['uid'] && $qrauth;

if ($_G['cache']['duceapp_wechat']['qrtype'] && $showqrcode && (!defined('IN_MOBILE') || ($_G['cache']['duceapp_wechat']['jslogin'] && !$_G['cache']['duceapp_wechat']['mtype']))) {
	if ($_G['inajax'] || $_G['infloat']) {
		$referer = base64_encode(duceapp_wechat_referer());
		$redirect_uri = $loginurl.'ac=login&op=callback&referer='.urlencode($referer).'&qrtype=1&siteuid='.$_G['uid'];
		$appid = $_G['cache']['duceapp_wechat']['open']['appid'];
		$frameurl = '';
		if ($_G['cache']['duceapp_wechat']['api']) {
			$frameurl  = $_G['cache']['duceapp_wechat']['apihost'].$_G['cache']['duceapp_wechat']['apiurl'];
			$frameurl .= 'appid='.$appid;
			$frameurl .= '&auth='.urlencode(base64_encode(authcode($redirect_uri."\t".$appsecret."\t1", 'ENCODE', $_G['cache']['duceapp_wechat']['token'], 1800)));
			include template('common/header_ajax');
			echo '<script type="text/javascript" reload="1">'.(defined('IN_MOBILE') ? 'popup.close();' : 'hideWindow(\'wechat_bind\');').'window.location.href=\''.$frameurl.'\';</script>';
			include template('common/footer_ajax');
		} else {
			$redirect_uri = urlencode($redirect_uri);
			include_once template('duceapp_wechat:wechat_qrcodejs');
		}
		exit;
	} else {
		dheader('location: '.$_G['duceapp_wechataccess'].'ac=login');
	}
}

if (!$_G['cache']['duceapp_wechat']['qrtype'] || ($_G['cache']['duceapp_wechat']['mtype'] && DUCEAPP_WECHATBROWSE === FALSE)) {
	include_once libfile('class/duceapp_wechat', 'plugin/duceapp_wechat');
	list($qrapitype, $qrcodeurl, $codeenc, $code) = duceapp_wechat::getQrcode();
}

if ($_G['uid'] && !$qrauth && in_array('qqconnect', $_G['setting']['plugins']['available'])) {
	$connect = C::t('#qqconnect#common_member_connect')->fetch($_G['uid']);
	if ($connect['conisregister']) {
		if (!$_G['cache']['duceapp_wechat']['qrtype']) {
			$qrauth = true;
		} else {
			showmessage('', $_G['duceapp_wechataccess'].'ac=login', array(), array('location' => 1));
		}
	}
}

include_once template('duceapp_wechat:wechat_qrcode');