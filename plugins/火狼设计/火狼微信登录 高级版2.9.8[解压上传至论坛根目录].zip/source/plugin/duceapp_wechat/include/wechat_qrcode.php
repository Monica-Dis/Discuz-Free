<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00322
 * Date: 2020-08-06 03:25:46
 * File: wechat_qrcode.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if ($_GET['access']) {

	dheader('Expires: '.gmdate('D, d M Y H:i:s', TIMESTAMP + 86400).' GMT');

	$key = authcode("\t".substr($_G['cookie']['saltkey'], 0, 6)."\t".$_G['uid'], 'ENCODE', $_G['cache']['duceapp_wechat']['token']);
	$url = $_G['siteurl'].$_G['duceapp_wechataccess'].'ac=response&evt=noreqsmp&key='.urlencode(base64_encode($key));
	include_once libfile('class/duceapp_qrcode', 'plugin/duceapp_wechat');
	QRcode::png($url, false, QR_ECLEVEL_M, 5);
	
	exit;
}

include_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');
$wechat_client = new duceapp_wechatclient('mp');
list($ticket, $code) = explode("\t", authcode($_G['cookie']['duceapp_wechat_ticket'], 'DECODE'));

if ($ticket) {
	$dir = DISCUZ_ROOT.'./data/duceapp/wechat/qrcode/';
	$file = $dir.md5($ticket).'_'.$code.'.jpg';
	if(!file_exists($file) || !filesize($file)) {
		dmkdir($dir);
		$buff = dfsockopen($qrcodeurl = $wechat_client->getQrcodeImgUrlByTicket($ticket));
		if ($buff) {
			$fp = @fopen($file, 'wb');
			@fwrite($fp, $buff);
			@fclose($fp);
		} else {
			$file = $qrcodeurl;
		}
	}
	dheader('Content-Disposition: inline; filename=qrcode.jpg');
	dheader('Content-Type: image/pjpeg');
	@readfile($file);
}