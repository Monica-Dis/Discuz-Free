<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00806
 * Date: 2020-08-06 03:25:46
 * File: wechat_response.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$setting = $_G['cache']['duceapp_wechat'];
list($openid, $sid, $authuid, $key) = explode("\t", authcode(base64_decode($_GET['key']), 'DECODE', $setting['token']));

require_once libfile('class/duceapp_wechat', 'plugin/duceapp_wechat');
require_once libfile('class/duceapp_wechatapi', 'plugin/duceapp_wechat');

if ($setting['subscribe']['enabled']) {
	$openid = '';
}

$access_user =  $openid ? duceapp_wechat::getAccessUser($openid) : array();
$evt = $_GET['evt'];
$op = $_GET['op'] ? $_GET['op'] : 'bind';
$activation = $getwechat = $getauthcode = $updatelog = true;
$openid = $access_user['openid'];
$keyenc = urlencode(base64_encode(authcode($openid."\t".$sid."\t".$authuid, 'ENCODE', $setting['token'])));
$access_url = $_G['siteurl'].$_G['duceapp_wechataccess'];
$referer = $_GET['referer'] ? $_GET['referer'] : $_G['siteurl'];

if ($key) {
	$authcode = C::t('#duceapp_wechat#duceapp_wechat_authcode')->fetch_by_code($key);
	$getauthcode = false;
	if (!$authcode || $authcode['status'] == 1) {
	} else {
		if ($authcode['uid']) {
			$member = getuserbyuid($authcode['uid'], 1);
			if ($member['uid'] && $member['adminid'] == 0 && !$setting['confirmtype']) {
				$wechatuser = C::t('#duceapp_wechat#duceapp_wechat_member')->fetch_by_unionid($access_user);
				$getwechat = false;
				if (!$wechatuser) {
					$wechatuser = duceapp_wechat::bindOpenId($member['uid'], $access_user);
				}
				if ($wechatuser['uid'] == $member['uid']) {
					C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($authcode['sid'], array('uid' => $member['uid'], 'status' => 1));
					$sid = '';
				}
			}
			$authuid = true;
		} else {
			$wechatuser = C::t('#duceapp_wechat#duceapp_wechat_member')->fetch_by_unionid($access_user);
			$getwechat = false;
			if ($wechatuser) {
				$member = getuserbyuid($wechatuser['uid'], 1);
				if ($member['adminid'] == 0 && !$setting['confirmtype']) {
					C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($authcode['sid'], array('uid' => $member['uid'], 'status' => 1));
					$sid = '';
				}
			} elseif ($setting['mtype'] && $openid) {		
				require_once libfile('function/member');
				if ($wechatuser = duceapp_wechat_response($access_user, $activation)){
					C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($authcode['sid'], array('uid' => $wechatuser['uid'], 'status' => 1));
					$sid = '';
					$updatelog = false;
				}
				$activation = false;
			}
		}
		if ($sid) {
			C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($sid, array('status' => -1));
		}
	}
}

$selfurl = $access_url.'ac=response&key='.$keyenc.'&referer='.urlencode($referer).($_GET['username'] ? '&username='.urlencode($_GET['username']) : '')."&evt=$evt&op=";

if ($setting['mtype'] && DUCEAPP_WECHATBROWSE && !$openid) {
	if (!empty($_G['cookie']['duceapp_wxopenid'])) {
		$openid = authcode($_G['cookie']['duceapp_wxopenid'], 'DECODE', $_G['config']['security']['authkey']);
		if ($openid) {
			$access_user = duceapp_wechat::getAccessUser($openid);
			if (!($openid = $access_user['openid'])) {
				dsetcookie('duceapp_wxopenid', '', -1);
			}
		}
	}
	if (!$openid && $setting['mtype'] == 1 && !$_GET['submit']) {
		require_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');
		$wechat_client = new duceapp_wechatclient('mp');
		$reload = intval($_GET['reload']);
		if (empty($_GET['oauth'])) {
			if ($setting['oauthsite'] && !$setting['api']) {
				$selfurl = str_replace($access_url, duceapp_wechat_getRedirect(), $selfurl);
			}
			$redirect_uri = $selfurl.$op.'&oauth=yes'.($_GET['confirm'] ? '&confirm='.$_GET['confirm'] : '').'&reload='.$reload;			
			if ($setting['api']) {
				$appid = $setting['mp']['appid'];
				$appsecret = $setting['mp']['appsecret'];
				$scope = $evt == 'space' || $evt == 'access' ? 'snsapi_base' : 'snsapi_userinfo';
				$url  = $setting['apihost'].$setting['apiurl'];
				$url .= 'appid='.$appid.'&scope='.$scope;
				$url .= '&auth='.urlencode(base64_encode(authcode($redirect_uri."\t".$appsecret, 'ENCODE', $setting['token'], 1800)));
				dheader('Location:'.$url);
			}
			$scope = !$reload ? 'snsapi_base' : 'snsapi_userinfo';
			$redirect_uri = $wechat_client->getOauthConnectUri($redirect_uri, '', $scope);
			dheader('location: '.$redirect_uri);
		} else {
			$res = $wechat_client->getAccessTokenByCode($_GET['code']);
			if ($wechat_client->checkIsSuc($res)) {
				$access_user = duceapp_wechat::getAccessUser($res);
				$openid = $access_user['openid'];
			}
			if ($openid) {				
				dsetcookie('duceapp_wxopenid', authcode($openid, 'ENCODE', $_G['config']['security']['authkey']), 86400);
			} else {
				dheader('location: '.($reload > 2 ? $_G['siteurl'] : $selfurl.$_GET['op'].'&reload='.($reload + 1)));
			}
		}
	}
} elseif ($openid) {
	dsetcookie('duceapp_wxopenid', authcode($openid, 'ENCODE', $_G['config']['security']['authkey']), 86400);
}

require_once libfile('function/member');

if ($openid) {
	if ($getwechat) {
		$wechatuser = C::t('#duceapp_wechat#duceapp_wechat_member')->fetch_by_unionid($access_user);
	}
	if (!$wechatuser && !$authuid) {
		if ($_G['uid']) {
			clearcookies();
			dheader('location: '. $selfurl.$op);
		}
		if (!$key && $setting['mtype']) {
			if ($wechatuser = duceapp_wechat_response($access_user, $activation)){
				$updatelog = false;
				if ($sid) {
					C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($sid, array('uid' => $wechatuser['uid'], 'status' => 1));
					$sid = '';
				}
			}
		}
	}	
}

if ($evt == 'access' && ($redirect = duceapp_wechat::redirect())) {
	if ($wechatuser && $_G['uid'] != $wechatuser['uid']) {
		$member = getuserbyuid($wechatuser['uid'], 1);
		setloginstatus($member, 1296000);
	}
	if (!$_G['duceapp_discuzuid'] && $_G['uid']) {
		plugin_duceapp_wechat::_tmplsend('logon');
	}
	dheader('location: '.C::m('#duceapp_base#duceapp_synlogin')->redirect($redirect));
}

if ($sid) {
	if ($getauthcode) {
		$authcode = C::t('#duceapp_wechat#duceapp_wechat_authcode')->fetch($sid);
	}
	if ($authcode) {
		$navtitle = lang('plugin/duceapp_wechat', 'wechat_title_login');
		if ($_GET['confirm'] == 'delete') {
			C::t('#duceapp_wechat#duceapp_wechat_authcode')->delete($authcode['sid']);
			C::t('#duceapp_wechat#duceapp_wechat_member')->update($authcode['uid'], array('status' => 1));
			include template('duceapp_wechat:bind_confirm');
			exit;
		}
		if ($wechatuser && !$authcode['uid']) {
			$member = getuserbyuid($wechatuser['uid'], 1);
			if (empty($_GET['confirm']) && (!$setting['confirmtype'] && $member['adminid'] > 0 || $setting['confirmtype'] == 1)) {
				$member['avatar'] = '<img src="'.avatar($wechatuser['uid'], 'middle', true).'" /><br />';
				if ($evt == 'noreqsmp') {
					C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($sid, array('status' => -1));
				}
				include template('duceapp_wechat:bind_confirm');
				exit;
			}
			setloginstatus($member, 1296000);
			C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($sid, array('uid' => $wechatuser['uid'], 'status' => 1));
			if ($updatelog) {
				duceapp_wechat::updateLogin($wechatuser, $access_user, true);
			}
			$_GET['referer'] = $_G['siteurl'];
		} elseif ($authcode['uid']) {
			$member = getuserbyuid($authcode['uid'], 1);
			if ($wechatuser && $authcode['uid'] != $wechatuser['uid']) {
				if ($_G['uid'] && $_G['uid'] != $wechatuser['uid']) {
					clearcookies();
				}
				showmessage('duceapp_wechat:wechat_openid_exists_confirm', $access_url.'ac=response&evt=access&confirm=yes');
			}
			if ($member) {
				if (empty($_GET['confirm']) && (!$setting['confirmtype'] && $member['adminid'] > 0 || $setting['confirmtype'] == 1)) {
					$navtitle = lang('plugin/duceapp_wechat', 'wechat_title_bind');
					$member['avatar'] = '<img src="'.($member['avatarstatus'] || !$access_user['headimgurl'] ? avatar($authcode['uid'], 'middle', true) : $access_user['headimgurl']).'" /><br />';
					if ($evt == 'noreqsmp') {
						C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($sid, array('status' => -1));
					}
					include template('duceapp_wechat:bind_confirm');
					exit;
				}
				$_GET['referer'] = $_G['siteurl'];
				setloginstatus($member, 1296000);
				C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($sid, array('status' => 1));
				$wechatuser = $wechatuser ? $wechatuser : duceapp_wechat::bindOpenId($authcode['uid'], $access_user, 0, !$member['avatarstatus']);
				$updatelog = false;
			} else {
				$op = 'bind';
			}
		}
	}
}

if ($wechatuser && (!$_G['uid'] || (($authuid || !$authcode) && $_G['uid'] != $wechatuser['uid']))) {
	duceapp_wechat_login($access_user, $wechatuser, $updatelog);
}

if ($op == 'bind' && $setting['mtype']) {
	if (!$_G['uid'] && DUCEAPP_WECHATBROWSE && $setting['allowfastregister']) {
		$op = 'wxregister';
	}
}

if ($op == 'bind') {
	define('IN_MOBILE', 2);
	if (DUCEAPP_WECHATBROWSE) {
		if (!$_G['uid'] && $setting['mtype']) {
			$defaultusername = duceapp_wechat::getNewUsername($access_user);
			include template('duceapp_wechat:wechat_bind');
		} else {
			switch($evt) {
				case 'mycenter': $redirect = $_G['siteurl'].'home.php?mod=space&do=profile&mycenter=1&mobile=2'; break;
				case 'profile': $redirect = $_G['siteurl'].'home.php?mod=space&do=profile&mobile=2'; break;
				case 'group': $redirect = $_G['siteurl'].'group.php?mod=my&mobile=2'; break;
				case 'album': $redirect = $_G['siteurl'].'home.php?mod=space&do=album&view=me&mobile=2'; break;
				case 'blog': $redirect = $_G['siteurl'].'home.php?mod=space&do=blog&view=me&mobile=2'; break;
				default: $redirect = duceapp_wechat::redirect();
			}

			dheader('location: '.C::m('#duceapp_base#duceapp_synlogin')->redirect($redirect ? $redirect : $referer));
		}
	} else {
		dheader('location: '.$_G['siteurl'].(!$_G['uid'] ? 'member.php?mod=logging&action=login&referer='.dreferer() : ''));
	}
} elseif ($op == 'login' && submitcheck('submit')) {
	$_GET['username'] = trim($_GET['username']);
	if (!($loginperm = logincheck($_GET['username']))) {
		showmessage('login_strike');
	}	
	if(!$_GET['password'] || $_GET['password'] != addslashes($_GET['password'])) {
		showmessage('profile_passwd_illegal');
	}
	if (DISCUZ_VERSION < 'X3.0') {
		$_GET['username'] = duceapp_wechat::clearEmoji($_GET['username']);
	}
	$result = userlogin($_GET['username'], $_GET['password'], $_GET['questionid'], $_GET['answer'], $_G['setting']['autoidselect'] ? 'auto' : $_GET['loginfield'], $_G['clientip']);

	if ($result['status'] <= 0) {
		loginfailed($_GET['username']);
		failedip();
		showmessage('login_invalid', '', array('loginperm' => $loginperm - 1));
	}

	if ($setting['mtype'] && $_GET['wx_openid']) {
		if ($wechatuser) {
			if($result['member']['uid'] != $wechatuser['uid']) {
				showmessage('duceapp_wechat:wechat_openid_exists');
			}
		} else {
			$access_user = $access_user ? $access_user : duceapp_wechat::getAccessUser(array('openid' => $_GET['wx_openid'], 'access_token' => $_GET['token']));
			if (!$access_user['openid']) {
				showmessage('duceapp_wechat:wechat_member_openid_fail');
			}
			duceapp_wechat::bindOpenId($result['member']['uid'], $access_user, 0, !$result['member']['avatarstatus']);
		}
		if ($sid) {
			C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($sid, array('uid' => $result['member']['uid'], 'status' => 1));
		}
		setloginstatus($result['member'], 1296000);
		$referer = C::m('#duceapp_base#duceapp_synlogin')->redirect($referer);
		showmessage('duceapp_wechat:wechat_member_bind_succeed', $selfurl.'bind&referer='.urlencode($referer));
	} else {
		showmessage('undefined_action');
	}
} elseif(($op == 'register' && submitcheck('submit') || $op == 'wxregister') && $setting['allowregister']) {
	if ($wechatuser) {
		showmessage('duceapp_wechat:wechat_openid_exists');
	} elseif ($setting['mtype']) {
		if ($op == 'register') {
			if ($setting['needpawd'] == 1 || $setting['needpawd'] == 3 || $_GET['password']) {
				if ($_G['setting']['pwlength'] && strlen($_GET['password']) < $_G['setting']['pwlength']) {
					showmessage('profile_password_tooshort', NULL, array('pwlength' => $_G['setting']['pwlength']));
				}
				if ($_G['setting']['strongpw']) {
					$strongpw_str = array();
					if(in_array(1, $_G['setting']['strongpw']) && !preg_match("/\d+/", $_GET['password'])) {
						$strongpw_str[] = lang('member/template', 'strongpw_1');
					}
					if(in_array(2, $_G['setting']['strongpw']) && !preg_match("/[a-z]+/", $_GET['password'])) {
						$strongpw_str[] = lang('member/template', 'strongpw_2');
					}
					if(in_array(3, $_G['setting']['strongpw']) && !preg_match("/[A-Z]+/", $_GET['password'])) {
						$strongpw_str[] = lang('member/template', 'strongpw_3');
					}
					if(in_array(4, $_G['setting']['strongpw']) && !preg_match("/[^a-zA-z0-9]+/", $_GET['password'])) {
						$strongpw_str[] = lang('member/template', 'strongpw_4');
					}
					if($strongpw_str) {
						showmessage(lang('member/template', 'password_weak').implode(',', $strongpw_str));
					}
				}
			}
			if ($setting['needpawd'] == 2 || $setting['needpawd'] == 3 || $_GET['email']) {
				if ($setting['needpawd'] && empty($_GET['email'])) {
					showmessage('profile_email_illegal');
				}
				checkemail($_GET['email']);
			}
		}
		if (!$access_user) {
			$access_user = duceapp_wechat::getAccessUser(array('openid' => $_GET['wx_openid'], 'access_token' => $_GET['token']));
		}
		if (!$access_user['openid']) {
			showmessage('duceapp_wechat:wechat_member_openid_fail');
		}
		if ($activation) {
			$uid = duceapp_wechat::memberActivation(duceapp_wechatapi::report('syncheckuser', array(
				'uid' => 0,
				'openid' => $access_user['openid'],
				'unionid' => $access_user['unionid']
			)), $access_user);
			if ($uid) {				
				showmessage('duceapp_wechat:wechat_member_register_succeed', $selfurl.'bind&confirm=yes');
			}
		}
		if ($op == 'register') {
			$access_user['username'] = $_GET['username'] ? $_GET['username'] : $access_user['username'];
			loaducenter();
			$user = uc_get_user($access_user['username']);
			if ($user) {
				showmessage('register_activation', '', 'error');
			}
		}
		$uid = duceapp_wechat::register($access_user, 1);
		if ($uid) {
			duceapp_wechat::bindOpenId($uid, $access_user, $op == 'register' && $_GET['password'] ? 2 : 1);
		}

		$referer = C::m('#duceapp_base#duceapp_synlogin')->redirect($referer);
		if ($op == 'wxregister') {
			dheader('location: '.$referer);
		} else {
			showmessage('duceapp_wechat:wechat_member_register_succeed', $selfurl.'bind&confirm=yes&referer='.urlencode($referer));
		}
	} else {
		showmessage('undefined_action');
	}
} else {
	showmessage('undefined_action');
}