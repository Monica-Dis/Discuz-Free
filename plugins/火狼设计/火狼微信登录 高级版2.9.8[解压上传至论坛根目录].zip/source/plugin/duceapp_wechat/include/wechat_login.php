<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00806
 * Date: 2020-08-06 03:25:46
 * File: wechat_login.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$op = !empty($_GET['op']) ? $_GET['op'] : 'login';
$setting = $_G['cache']['duceapp_wechat'];

if (empty($setting['enable'])) {
	showmessage('duceapp_wechat:wechat_login_closed');
}

if (!empty($_GET['error'])) {
	showmessage('wechat_request_error_'.$_GET['error'], $_GET['referer'] ? base64_decode($_GET['referer']) : '');
}

$qrtype = (DUCEAPP_WECHATBROWSE && $setting['mtype']) || !$setting['qrtype'] ? 0 : 1;

if ($qrtype) {

	$appid = $setting['open']['appid'];
	$appsecret = $setting['open']['appsecret'];
	$scope = 'snsapi_login';

} else {

	if (!DUCEAPP_WECHATBROWSE) {
		showmessage('duceapp_wechat:wechat_login_qrtype_fail', dreferer());
	}
	$appid = $setting['mp']['appid'];
	$appsecret = $setting['mp']['appsecret'];
	$scope = $_GET['scope'] == 'snsapi_base' ? $_GET['scope'] : 'snsapi_userinfo';

}

if ($op == 'login') {

	$qrauth = $_G['cookie']['qrauth'] ? authcode(base64_decode($_G['cookie']['qrauth']), 'DECODE', $_G['config']['security']['authkey']) : '';
	if ($_G['uid'] && !$qrauth) {
		if ($_G['duceapp_wechatuser']) {
			dheader('location:'.($_GET['referer'] ? $_GET['referer'] : $_G['siteurl']));
		}
		$showtip = true;
		if (in_array('qqconnect', $_G['setting']['plugins']['available'])) {
			$connect = C::t('#qqconnect#common_member_connect')->fetch($_G['uid']);
			if($connect['conisregister']) {
				$showtip = false;
			}
		}
		if ($showtip) {
			dsetcookie('qrauth', '', -1);
			showmessage('duceapp_wechat:wechat_member_bind_qrauth_lost', dreferer());
		}
	}

	$referer = base64_encode(duceapp_wechat_referer());

	$redirect_uri = duceapp_wechat_getRedirect().'ac=login&op=callback&referer='.urlencode($referer).'&qrtype='.$qrtype.'&siteuid='.$_G['uid'];
	if ($setting['api']) {
		$url  = $setting['apihost'].$setting['apiurl'];
		$url .= 'appid='.$appid.'&scope='.$scope.'&state='.$_GET['state'];
		$url .= '&auth='.urlencode(base64_encode(authcode($redirect_uri."\t".$appsecret, 'ENCODE', $setting['token'], 1800)));
		dheader('Location:'.$url);
	}
	require_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');
	$wechat_client = new duceapp_wechatclient($appid, $appsecret);
	dheader('Location:'.$wechat_client->getOAuthConnectUri($redirect_uri, $_GET['state'], $scope));

} elseif ($op == 'callback') {

	$_GET['referer'] = base64_decode(str_replace($_G['siteurl'], '', $_GET['referer']));
	if ($_G['uid'] && $_GET['siteuid'] != $_G['uid']) {
		if ($_G['setting']['duceapp_synsite'] && strpos($_GET['referer'], $_G['scheme'].'://'.$_SERVER['HTTP_HOST']) === FALSE) {
			dheader('location: '.C::m('#duceapp_base#duceapp_synlogin')->redirect($_GET['referer'], true));
		}
		showmessage('duceapp_wechat:wechat_member_auth_fail');
	}

	require_once libfile('class/duceapp_wechat', 'plugin/duceapp_wechat');
	require_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');

	$wechat_client = new duceapp_wechatclient($appid, $appsecret);
	$res = $wechat_client->getAccessTokenByCode($_GET['code']);
	if (!$wechat_client->checkIsSuc($res)) {
		showmessage('duceapp_wechat:wechat_code_been_used', $_GET['referer']);
	}

	$access_user = duceapp_wechat::getAccessUser($res, !$qrtype);

	if (!$wechat_client->checkIsSuc($access_user)) {
		showmessage('duceapp_wechat:wechat_member_openid_fail');
	}

	duceapp_wechat_logon($access_user, $qrtype, $_GET['siteuid']);

	if (!$_G['duceapp_discuzuid'] && $_G['uid'] && !$qrtype) {
		plugin_duceapp_wechat::_tmplsend('logon');
	}

	dheader('location: '.C::m('#duceapp_base#duceapp_synlogin')->redirect($_GET['referer']));

} elseif ($op == 'regcallback') {

	list($openid, $access_token, $qrtype, $referer) = explode("\t", authcode(base64_decode($_GET['auth']), 'DECODE'));
	
	if ($_GET['defaultusername'] && $_GET['defaultusername'] != $_G['member']['username']) {
	} else {
		if (!$openid) {
			showmessage('duceapp_wechat:wechat_member_auth_fail');
		}
		require_once libfile('class/duceapp_wechat', 'plugin/duceapp_wechat');
		$access_user = duceapp_wechat::getAccessUser(array('openid' => $openid, 'access_token' => $access_token), !$qrtype);
		if ($access_user['openid']) {
			duceapp_wechat::bindOpenId($_G['uid'], $access_user, 2, 1);
		}
	}

	dheader('location: '.C::m('#duceapp_base#duceapp_synlogin')->redirect($referer ? $referer : $_G['siteurl']));

} else {

	showmessage('undefined_action');

}