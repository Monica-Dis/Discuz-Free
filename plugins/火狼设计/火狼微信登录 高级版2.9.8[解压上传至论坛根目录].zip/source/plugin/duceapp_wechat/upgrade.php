<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: upgrade.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if(!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

define('DUCEAPP_UPGRADE', 1);
define('DUCEAPP_ROOT', dirname(__FILE__).'/');
define('DUCEAPP_IDENT', basename(DUCEAPP_ROOT));
define('DUCEAPP_DATAURL', 'data/'.str_replace('_', '/', DUCEAPP_IDENT).'/');

include_once libfile('check', 'plugin/'.DUCEAPP_IDENT);
include_once libfile('class/duceapp_installcore', 'plugin/'.DUCEAPP_SINGLE);
$duceapp_install = new duceapp_installcore;
$duceapp_install->upgrade();

$finish = TRUE;