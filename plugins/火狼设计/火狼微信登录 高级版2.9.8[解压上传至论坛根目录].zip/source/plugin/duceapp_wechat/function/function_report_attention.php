<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2020-07-28
 * Version: 3.00728
 * Date: 2020-08-06 03:25:46
 * File: function_report_attention.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function duceapp_wechat_report_attention(){
	global $_G;
	if (!duceapp_wechatapi::_check_sign()) {
		return '';
	}
	if ($_GET['openid'] && isset($_GET['subscribe'])) {
		DB::update('duceapp_wechat_member', array('subscribe' => $_GET['subscribe']), "openid='$_GET[openid]'");
	}
}