<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2019-08-02
 * Version: 3.00426
 * Date: 2020-08-06 03:25:46
 * File: function_duceapp_admincp.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

function duceapp_headscript($jsname = null, $cssname = null) {
	static $baseloaded;
	if ($cssname === null && $jsname === null) {
		if ($baseloaded) {
			return;
		}
		echo '<link href="source/plugin/duceapp_base/static/css/admin.css?'.DUCEAPP_SCHASH.'" rel="stylesheet" type="text/css" />';
		echo '<script type="text/javascript" src="source/plugin/duceapp_base/static/js/admin.js?'.DUCEAPP_SCHASH.'"></script>';
		$baseloaded = true;
		return;
	}
	if ($jsname) {
		echo '<script type="text/javascript" src="'.DUCEAPP_DIRURL.'static/js/'.$jsname.'.js?'.DUCEAPP_SCHASH.'"></script>';
	}
	if ($cssname) {
		echo '<link href="'.DUCEAPP_DIRURL.'static/css/'.$cssname.'.css?'.DUCEAPP_SCHASH.'" rel="stylesheet" type="text/css" />';
	}
}

function duceapp_language($name, $path = '') {
	$path = $path ? $path : DUCEAPP_ROOT.'language/';
	$name = is_file($path.'lang_'.$name.'.php') ? $name : $name.'_'.currentlang();
	return $path.'lang_'.$name.'.php';
}

function duceapp_loadcompon() {
	global $_G, $plugin, $lang;
	$plugin['duceapp_compons'] = $componcpmenu = array();
	@include duceapp_language('admincp');
	if ($duceapp_cplang && is_array($duceapp_cplang)) {
		if ($_G['cache']['pluginlanguage_script'][DUCEAPP_IDENT]) {
			$_G['cache']['pluginlanguage_script'][DUCEAPP_IDENT] = array_merge($_G['cache']['pluginlanguage_script'][DUCEAPP_IDENT], $duceapp_cplang);
		} else {
			$_G['cache']['pluginlanguage_script'][DUCEAPP_IDENT] = $duceapp_cplang;
		}
	}
	if ($d = @dir(DUCEAPP_COMPONROOT)){
		while($file = $d->read()){
			if(is_file(DUCEAPP_COMPONROOT.$file) && substr($file, -10) == '.class.php'){
				$plugin['duceapp_compons'][substr($file, 0, -10)] = '1.0.0';
			}
		}
		$d->close();
		if ($plugin['duceapp_compons']) {
			$pluginlanguage = & $_G['cache']['pluginlanguage_script'][DUCEAPP_IDENT];
			$menus = $sortcompon = $api = array();
			foreach ($plugin['duceapp_compons'] as $compon => $version) {
				$duceapp_compon_lang = array();
				@include duceapp_language($compon);
				if ($duceapp_compon_lang && is_array($duceapp_compon_lang)) {
					if ($_GET['pmod'] == 'compon' && $_GET['cmod'] == $compon) {
						$plugin['duceapp_anchors'] = is_array($duceapp_compon_lang['anchors']) ? $duceapp_compon_lang['anchors'] : array();
						if ($duceapp_compon_lang['js']) {
							duceapp_headscript('admin_'.$compon);
						}
						if ($duceapp_compon_lang['css']) {
							duceapp_headscript('', 'admin_'.$compon);
						}
						$pluginlanguage = array_merge($pluginlanguage, $duceapp_compon_lang);
					}
					if (isset($duceapp_compon_lang['menu_title'])) {
						$pluginlanguage['menu_'.$compon] = $duceapp_compon_lang['menu_title'];
					}
					if (isset($duceapp_compon_lang['appver'])) {
						$plugin['duceapp_compons'][$compon] = $duceapp_compon_lang['appver'];
					}
				}
				if ($plugin['duceapp_setting_keys']) {
					$plugin['duceapp_setting_keys'][] = $compon;
				}
				if ($duceapp_compon_lang['menu_api']) {
					$api[$compon] = $duceapp_compon_lang['menu_api'];
					if ($_GET['cmod'] == $compon) {
						$_GET['api'] = $duceapp_compon_lang['menu_api'];
					}
					$plugin['duceapp_api'][] = $compon;
				}
				$menus[$compon] = intval($duceapp_compon_lang['menu_order']);
			}
			$componcpmenu = array(0 => array());
			uasort($menus, 'duceapp_cmpasc');
			foreach ($menus as $compon => $i) {
				$menu = array(duceapp_cplang('menu_'.$compon), 'pmod=compon&cmod='.$compon, $_GET['cmod'] == $compon);
				if ($api[$compon]) {
					$componcpmenu[$api[$compon]][] = $menu;
				} else {
					$componcpmenu[0][] = $menu;
				}
				$sortcompon[$compon] = $plugin['duceapp_compons'][$compon];
			}
			$plugin['duceapp_compons'] = $sortcompon;
		}
	}
	return $componcpmenu;
}

function duceapp_checkcompon($compon) {
	global $plugin;
	static $support_version;
	if ($support_version === null) {
		@include DUCEAPP_COMPONROOT.'support_version.php';
	}
	if (empty($support_version)) {
		$support_version = false;
		return false;
	}
	$support_version[$compon]['exec'] = version_compare($plugin['duceapp_compons'][$compon], $support_version[$compon]['admin'], '<') ? 1 : 0;
	if (!$support_version[$compon]['exec']) {
		$support_version[$compon]['exec'] = ($support_version[$compon]['main'] && version_compare(DUCEAPP_VERSION, $support_version[$compon]['main'], '<'));
	}
	$support_version[$compon]['duceapp_addonid'] = $duceapp_addonid;
	return $support_version[$compon];
}

function duceapp_cplang($var, $eval = null, $default = null) {
	if (empty($var)) {
		return '';
	}
	return lang('plugin/'.DUCEAPP_IDENT, $var, $eval, $default);
}

function duceapp_showanchors($pmod = '', $real = false) {
	global $plugin;
	if ($pmod == 'line') {
		if ($plugin['duceapp_core']->cpmethod != 'save') {
			echo '<table class="tb2 duceapp_tb" style="border-top:4px solid #deeffa;"><tr><th style="height:0;padding:0;"></th></tr></table>';
		}
		return;
	}
	if ($plugin['duceapp_cmod']) {
		$submenu = array(array('menu_'.$plugin['duceapp_cmod'], $plugin['duceapp_cmod'], 1, $plugin['duceapp_cmod'], '', '', 'compon'));
		$i = 0;
		$num = count($plugin['duceapp_anchors']);
		foreach($plugin['duceapp_anchors'] as $danchor => $item){
			$submenu[$danchor] = array(
				$item['title'], 
				$danchor,
				$plugin['duceapp_anchor'] == $danchor, 
				$item['real'] == 2 || $num < 2 || $plugin['duceapp_submit'] ? $danchor : null,
				'',
				!$i ? 'comma ccomma' : '',
			);
			$i++;
		}
		duceapp_subanchors($submenu);
		return;
	} elseif ($plugin['duceapp_anchors']) {
		$pmod = $pmod ? $pmod : $_GET['pmod'];
		$submenu = array();
		foreach($plugin['duceapp_anchors'] as $anchor){
			$submenu[] = array($pmod.'_'.$anchor, $anchor, $plugin['duceapp_anchor'] == $anchor, $real || $plugin['duceapp_submit'] ? $anchor : '');
		}
		duceapp_subanchors($submenu);
	}
}

function duceapp_editanchors($id, $name, $pmod = '', $mod = 'edit') {
	global $plugin;
	$danchor = $plugin['duceapp_anchor'];
	$pmod = $pmod ? $pmod : $_GET['pmod'];
	$componmenu = array();
	if ($plugin['duceapp_cmod']) {
		$submenus = array('menu' => 'menu_title', 'submenu' => array());
		foreach($plugin['duceapp_anchors'] as $anchor => $item){
			$submenus['submenu'][] = array($item['title'], 'danchor='.$anchor, $danchor == $anchor);
		}
		$componmenu = array($plugin['duceapp_anchors'][$danchor]['title'], 0, 0, $danchor, 'class="current"', 'comma ccomma');
	} else {
		$submenus = array('menu' => $pmod.'_'.$danchor, 'submenu' => array());
		foreach($plugin['duceapp_anchors'] as $i => $anchor){
			$submenus['submenu'][] = array($pmod.'_'.$anchor, 'danchor='.$anchor, $danchor == $anchor);
		}
	}
	duceapp_subanchors(array(
		array($submenus, $componmenu ? '' : $danchor, 1, 'comma', $plugin['duceapp_cmod']),
		$componmenu,
		array($name, '', '', $danchor.'&actid='.$id, 'class="duceapp_nav"', 'comma'),
		array(cplang(duceapp_cplang($mod)), '', 0, false, 'class="duceapp_navtitle"', 'comma'),
	), 'danchor', $mod);
}

function duceapp_formheader($extra = '', $name = 'duceapp_form') {
	global $plugin;
	$fields = array(
		'danchor' => $plugin['duceapp_anchor'], 
		'duceapp_submit' => 'yes',
		'subtab' => $_GET['subtab'],
	);
	if ($_GET['subtab']) {
		$fields['subtab'] = $_GET['subtab'];
	}
	if (isset($_GET['actid'])) {
		$fields['actid'] = $_GET['actid'];
	}
	showformheader($plugin['duceapp_basescript'], $extra, $name);
	showhiddenfields($fields);
}

function duceapp_showtableheader($title = '', $classname = '', $extra = '', $titlespan = 15) {
	echo '<table class="tb2 duceapp_tb '.$classname.'"'.($extra ? " $extra" : '').'>';
	if($title){
		$span = $titlespan ? 'colspan="'.$titlespan.'"' : '';
		echo '<tr><th '.$span.' class="partition">'.cplang(duceapp_cplang($title)).'</th></tr>';
	}
}

function duceapp_cacheinherit(&$object, $ident) {
	global $_G;
	if (is_object($object)) {
		$object->setting = & $_G['cache'][$ident];
	} 
	elseif($ident && isset($_G['setting'][$ident])) {
		$_G['cache'][$ident] = & $_G['setting'][$ident];
	}
}

function duceapp_defines() {
	define('DUCEAPP_AUTHC', '');
	define('DUCEAPP_COMPONROOT', DUCEAPP_ROOT.'compon/');	
	define(strtoupper(DUCEAPP_IDENT.'_ROOT'), DUCEAPP_ROOT);
}

function duceapp_anchortips($tips, $id = 'app', $display = null, $title = '') {
	global $plugin;
	$display = $display === null ? ($id == 'app' || $plugin['duceapp_anchor'] == $id) : $display;
	showtableheader($title, 'duceapp_tips', 'id="duceapp_'.$id.'_tips"'.(!$display ? ' style="display: none;"' : ''), 0);
	showtablerow('', 'class="tipsblock"', '<ul id="'.$id.'lis">'.duceapp_cplang($tips).'</ul>');
	showtablefooter();/*dis'.'m.tao'.'bao.com*/
}

function duceapp_anchorheader($id = 'app', $display = false, $class = '', $extra = ''){
	duceapp_showtagheader('div', $id, $display);
	echo '<table class="tb2 duceapp_tb '.$class.'"'.($extra ? " $extra" : '').'>';
}

function duceapp_showtagheader($tagname, $id, $display = false) {
	global $plugin;
	showtagheader($tagname, 'duceapp_'.$id.'_bd', $display || $id == 'app' || $plugin['duceapp_anchor'] == $id);
}

function duceapp_anchorfooter(){
	showtablefooter();/*dis'.'m.tao'.'bao.com*/
	showtagfooter('div');
}

function duceapp_subanchors($menus, $anchor = 'danchor', $tvar = '') {
	global $plugin;
	if ($menus && is_array($menus)) {
		echo '<div class="duceapp_floattop"><div class="duceapp_floatmenu"><table class="tb2 duceapp_tb" style="border-top:4px solid #deeffa;"><tr><th style="height:4px;padding:0;"></th></tr>';
		$s = '<div class="duceapp_tab"><ul id="duceapp_subtitle">';
		foreach($menus as $k => $menu){
			if (is_array($menu[0])) {
				$submenus = is_array($menu[0]['submenu']) && count($menu[0]['submenu']) > 1 ? $menu[0]['submenu'] : null;
				$s .= '<li id="addjs'.$tvar.$k.'" class="'.($menu[2] ? ' current' : 'hasdropmenu').($menu[4] ? ' compon' : '').'"'.($submenus ? ' onmouseover="duceapp_dropmenu(this);"' : '').'><a href="'.($menu[1] ? $plugin['duceapp_redirect'].'&'.$anchor.'='.$menu[1] : $plugin['duceapp_redirect']).'"><span>'.duceapp_cplang($menu[0]['menu']);
				if ($submenus) {
					$s .= '<em class="arrow-down">&nbsp;&nbsp;</em></span></a><div id="addjs'.$tvar.$k.'child" class="dropmenu" style="display:none;">';
					foreach($submenus as $submenu) {
						$s .= '<a href="'.$plugin['duceapp_redirect'].'&'.$submenu[1].'"'.($submenu[2] ? ' class="current"' : '').'>'.duceapp_cplang($submenu[0]).'</a>';
					}
					$s .= '</div>';
				} else {
					$s .= '</span></a>';
				}
				$s .= '</li>';
			} elseif (!empty($menu) && is_array($menu) && $menu[0]) {
				$s .= $menu[5] ? '<li class="'.$menu[5].'"><em><b></b></em></li>' : '';
				$s .= '<li'.($menu[2] ? ' class="current '.$menu[6].'"' : ($menu[4] ? ' '.$menu[4] : '')).' id="duceapp_'.$menu[1].'" '.($menu[3] || $menu[3] === false ? '' : 'onclick="duceapp_tabtoggle(this, \''.$tvar.'\')"').'><a'.($menu[3] ? ' href="'.$plugin['duceapp_redirect'].(empty($k) && $plugin['duceapp_cmod'] ? '' : '&'.$anchor.'='.$menu[3]).'"' : '').'><span>'.cplang(duceapp_cplang($menu[0])).'</span></a></li>';
			}
		}
		$s .= '</ul></div>';
		showtitle($s);
		echo '</table><div class="duceapp_floatempty"></div></div></div>';
	}
}

function duceapp_showsubtitle($title = array(), $tdstyle=array(), $rowclass='header') {
	if (is_array($title)) {
		$subtitle = "\n<tr class=\"$rowclass\">";
		foreach($title as $k => $v) {
			if($v !== NULL) {
				$subtitle .= '<th'.($tdstyle[$k] ? ' '.$tdstyle[$k] : '').'>'.cplang(duceapp_cplang($v)).'</th>';
			}
		}
		$subtitle .= '</tr>';
		echo $subtitle;
	}
}

function duceapp_renewalmenu(&$object) {
	global $_G, $plugin, $admincp;
	$plugin['duceapp_core'] = & $object;
	$plugin['duceapp_basescript'] = & $object->basescript;
	$plugin['duceapp_redirect'] = & $object->redirect;
	$plugin['duceapp_anchors'] = & $object->anchors;
	$plugin['duceapp_anchor'] = & $object->danchor;
	$plugin['duceapp_compons'] = & $object->compons;
	$plugin['duceapp_cmod'] = & $object->cmod;
	$plugin['duceapp_setting_keys'] = & $object->setting_keys;
	$plugin['duceapp_visitor'] = $admincp->adminsession['cpgroupid'] && !array_key_exists('_allowpost', $admincp->perms);
	duceapp_headscript();
	if ($object->admincss) {
		duceapp_headscript(null, 'admin_'.$object->admincss);
	}
	$componcpmenu = duceapp_loadcompon();
	if ($componcpmenu || $object->dropanchor || $object->dropmodule) {
		$submenus = $dropmenus = array();
		foreach ($plugin['modules'] as $k => $module) {
			if ($module['type'] != 3) {
				continue;
			}
			$pmod = $module['name'];
			if ($pmod == 'compon') {
				if (!$componcpmenu[0]) {
					$submenus[$k] = array($module['menu'], 'pmod='.$pmod, ($_GET['pmod'] == $module['name'] || !$k && !$_GET['pmod']) && !$_GET['api']);
				}
				if ($componcpmenu) {
					foreach($componcpmenu as $api => $cmenu) {
						if ($cmenu){
							$submenus[$k.($api ? '_'.$api : '')] = array(!$api ? $module['menu'] : duceapp_cplang('module_'.$api), 'pmod='.$pmod.($api ? '&api='.$api : ''), $cmenu, $_GET['pmod'] == $pmod && (($api && $_GET['api'] == $api) || (!$_GET['api'] && !$api)), 1, !$_GET['cmod'] ? 'hidedropmenu' : '');
						}
					}
				}
			} else {
				if ($object->dropanchor && $object->dropanchor[$pmod]) {
					$submenus[$k] = array($module['menu'], 'pmod='.$pmod, (array) $dropmenus[$pmod], $_GET['pmod'] == $pmod, 1, 'hidedropmenu');
					$dropmenus[$pmod] = & $submenus[$k][2];
					foreach($object->dropanchor[$pmod] as $key) {
						$dropmenus[$pmod][] = array(cplang(duceapp_cplang($pmod.'_'.$key)), 'pmod='.$pmod.'&danchor='.$key, $_GET['danchor'] == $key);
						if ($_GET['pmod'] == $pmod && !in_array($key, $plugin['duceapp_anchors'])) {
							$plugin['duceapp_anchors'][] = $key;
						}
					}
				}
				if ($object->dropmodule) {
					if ($object->dropmodule[$pmod]) {
						if (!$dropmenus[$pmod]) {
							$submenus[$k] = array($module['menu'], 'pmod='.$pmod, (array) $dropmenus[$pmod], $_GET['pmod'] == $pmod, 1, 'hidedropmenu');
							$dropmenus[$pmod] = & $submenus[$k][2];
						}
					} else {
						$isdrop = false;
						foreach($object->dropmodule as $key => $modules) {
							if (in_array($pmod, $modules)) {
								$dropmenus[$key][] = array($module['menu'], 'pmod='.$key.'&danchor='.$pmod, $_GET['danchor'] == $pmod);
								$isdrop = true;
								$_G['cache']['pluginlanguage_script'][DUCEAPP_IDENT][$key.'_'.$pmod] = $module['menu'];
								if ($_GET['pmod'] == $key && !in_array($pmod, $plugin['duceapp_anchors'])) {
									$plugin['duceapp_anchors'][] = $pmod;
								}
								break;
							}
						}
						if (!$isdrop && !$dropmenus[$pmod]) {
							$submenus[$k] = array($module['menu'], 'pmod='.$pmod, $_GET['pmod'] == $pmod);
						}
					}
				} elseif (!$dropmenus[$pmod]) {
					$submenus[$k] = array($module['menu'], 'pmod='.$pmod, $_GET['pmod'] == $pmod);
				}
			}
		}
		duceapp_showsubmenu($plugin['name'], $submenus);
	}	
}

function duceapp_showsubmenu($title, $menus = array(), $right = '', $replace = array()) {
	global $plugin;
	if (empty($menus)) {
		$s = '<div class="itemtitle">'.$right.'<h3>'.cplang($title, $replace).'</h3></div>';
	} elseif (is_array($menus)) {
		$s = '<div class="itemtitle">'.$right.'<h3>'.cplang($title, $replace).'</h3><ul class="tab1">';
		foreach($menus as $k => $menu) {
			$_href = ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin['pluginid'].'&';
			if(is_array($menu[2])) {
				$s .= '<li id="addjs'.$k.'" class="'.($menu[3] ? 'current' : 'hasdropmenu').'"'.(!$menu[3] || $menu[5] != 'hidedropmenu' ? ' onmouseover="dropmenu(this);' : '').'"><a href="'.($menu[4] ? $_href.$menu[1] : '#').'"><span>'.duceapp_cplang($menu[0]).'<em>&nbsp;&nbsp;</em></span></a><div id="addjs'.$k.'child" class="dropmenu" style="display:none;">';
				if (!$menu[3] || $menu[5] != 'hidedropmenu'){
					foreach($menu[2] as $submenu) {
						$s .= $submenu[1] ? '<a href="'.$_href.$submenu[1].'" class="'.($submenu[2] ? 'current' : '').'" onclick="'.$submenu[3].'">'.duceapp_cplang($submenu[0]).'</a>' : '<a><b>'.duceapp_cplang($submenu[0]).'</b></a>';
					}
				}
				$s .= '</div></li>';
			} else {
				$s .= '<li'.($menu[2] ? ' class="current"' : '').'><a href="'.$_href.$menu[1].'"'.(!empty($menu[3]) ? ' target="_blank"' : '').'><span>'.duceapp_cplang($menu[0]).'</span></a></li>';
			}
		}
		$s .= '</ul></div>';
	}
	echo !empty($menus) ? '<style>.floattop { display: none; }.floattopempty { display: none; }.mymenu { height:35px; }.mymenu .floattop { display: inline; }.mymenu .floattopempty { display: inline; }</style><div class="mymenu"><div class="floattop">'.$s.'</div><div class="floattopempty"></div></div>' : $s;
}

function duceapp_showsetting($setname, $varname, $value, $type = 'radio', $disabled = '', $hidden = 0, $comment = '', $extra = '', $setid = '', $nofaq = false) {
	if($comment === ''){
		$comment = duceapp_cplang($setname.'_comment') != $setname.'_comment' ? duceapp_cplang($setname.'_comment') : '';
	}
	if ($type == 'dxmcheckbox') {
		$check['disabled'] = !empty($disabled) ? ($disabled == 'readonly' ? ' readonly' : ' disabled') : '';
		$type = '<ul onmouseover="altStyle(this'.($disabled ? ', 1' : '').');" class="cl" style="padding:5px 0;overflow:hidden;">';
		foreach($varname[1] as $varary) {
			if(is_array($varary) && !empty($varary)) {
				$checked = is_array($value) && $value[$varary[0]] ? ' checked' : '';
				$type .= '<li'.($checked ? ' class="checked"' : '').' '.$addstyle.'><input class="checkbox" type="checkbox" name="'.$varname[0].'['.$varary[0].']" value="'.(isset($varary[2]) ? $varary[2] : 1).'"'.$checked.$check['disabled'].'>&nbsp;'.$varary[1].'</li>';
			}
		}
		$type .= '</ul>';
		$varname = $value = '';
	} elseif ($type == 'subcolor') {
		$type = duceapp_showcolorinput($varname, $value, ++$coloridcount, 'width:190px;').$extra;
	} elseif ($type == 'info') {
		showtablerow('', 'colspan="2" class="td27" s="1"', duceapp_cplang($setname));
		showtablerow('class="noborder"', 'colspan="2" class="vtop rowform"', $value);
		return;
	}
	$extra = (string) $disabled == 'disabled' ? ' style="opacity:.5;"' : $extra;
	$comment = $type == 'color' ? duceapp_cplang('setting_color_comment').' '.duceapp_cplang($comment) : $comment;
	showsetting(duceapp_cplang($setname), $varname, $value, $type, $disabled, $hidden, $comment, $extra, $setid, true);
}

function duceapp_showcolorinput($varname, $value = '', $key = null, $style = '', $func = '') {
	static $coloridcount = 0;
	$key = $key !== null ? $key : ++$coloridcount;
	$colorid = 'color_'.$key;
	return "<input id=\"{$colorid}_v\" type=\"text\" class=\"txt\" value=\"".$value."\" name=\"".$varname."\" style=\"float:left;".$style."\" onchange=\"updatecolorpreview('{$colorid}');".($func ? $func."('{$colorid}');" : "")."\"><input id=\"{$colorid}\" onclick=\"{$colorid}_frame.location='".DUCEAPP_BASEURL."static/getcolor.htm?{$colorid}|{$colorid}_v|".$func."';showMenu({'ctrlid':'{$colorid}'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:".$value."\"><span id=\"{$colorid}_menu\" style=\"display: none\"><iframe name=\"{$colorid}_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>";
}

function duceapp_showulstyle($varname, $varary, $value, $nofloat = 0, $type = 'radio', $extra = '', $disabled = false) {
	$s = '';
	if (is_array($varary) && !empty($varary)){
		$disabled = $disabled ? ' disabled' : '';
		$s .= '<ul'.($disabled ? '' : ' onmouseover="altStyle(this);"').' class="ulstyle'.($nofloat ? ' ulnofloat' : '').' cl"'.$extra.'>';
		foreach($varary as $name => $val){
			$checked = is_array($value) && in_array($val, $value) || (!is_array($value) && $val == $value) ? ' checked' : '';
			$s .= '<li'.($checked ? ' class="checked"' : '').'><input class="'.$type.'" type="'.$type.'" name="'.$varname.'" value="'.$val.'"'.$checked.$disabled.'>&nbsp;'.duceapp_cplang($name).'</li>';
		}
		$s .= '</ul>';
	}
	return $s;
}

function duceapp_anchortabs($id, $tabs, $value = '', $var = 'subtab', $style_extra = '') {
	global $plugin;
	$s = '<div id="duceapp_'.$id.'_subtab" class="duceapp_subtab"'.($id == $plugin['duceapp_anchor'] ? '' : ' style="display:none;"').'><ul class="cl" style="'.$style_extra.'">';
	foreach($tabs as $tab){
		$s .= '<li id="duceapp_'.$var.'_'.$tab.'"'.($tab == $value ? ' class="current"' : '').' onclick="duceapp_tabtoggle(this, \''.$var.'\', \'duceapp_'.$id.'_subtab\')">'.duceapp_cplang($tab).'</li>';
	}
	$s .= '</ul></div>';
	echo $s;
}

function duceapp_forumselect($forumselected = 0, $arrayformat = 0){
	include_once libfile('function/forumlist');
	return forumselect(FALSE, $arrayformat, $forumselected, TRUE);
}

function duceapp_groupselect($varname, $value = array(), $multiple = 1, $extra = '', $intact = 1) {
	global $_G, $lang;
	$s = '';
	$value = is_array($value) ? $value : array($value);
	if ($intact) {
		if ($multiple) {
			$s = '<select name="'.$varname.'[]" size="10" multiple="multiple" '.($extra ? $extra : 'style="margin-bottom:8px;"').'><option value=""'.(@in_array('', $value) ? ' selected' : '').'>'.cplang('plugins_empty').'</option>';
		} else {
			$s = '<select name="'.$varname.'" '.($extra ? $extra : 'style="margin-bottom:8px;"').'><option value="">'.cplang('plugins_empty').'</option>';
		}
	}
	$groupselect = array();
	$query = C::t('common_usergroup')->range_orderby_credit();
	foreach($query as $group) {
		$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
		$groupselect[$group['type']] .= '<option value="'.$group['groupid'].'"'.(@in_array($group['groupid'], $value) ? ' selected' : '').'>'.$group['grouptitle'].'</option>';
	}
	$s .= '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
		($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
		($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
		'<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup></select>';
	return $s;
}

function duceapp_cpmsg($message = '', $url = '', $type = 'succeed', $values = array(), $extra = '', $halt = TRUE, $cancelurl = ''){
	global $plugin;
	$plugin['duceapp_core']->redirect .= ($_GET['subtab'] ? '&subtab='.$_GET['subtab'] : '');
	$plugin['duceapp_core']->cpmsg($message, $url, $type, $values, $extra, $halt, $cancelurl);
	exit;
}

function duceapp_error($message = '', $values = array(), $updatebatch = false) {
	global $plugin;
	$plugin['duceapp_core']->error($message, $values, $updatebatch);
	exit;
}

function duceapp_succeed($message = '', $url = '', $values = array()) {
	global $plugin;
	$plugin['duceapp_core']->redirect .= ($_GET['subtab'] ? '&subtab='.$_GET['subtab'] : '');
	$plugin['duceapp_core']->succeed($message, $url, 'succeed', $values);
	exit;
}

function duceapp_cutencrypt($string, $start = 1, $end = 5, $enc = '********') {
	global $_G, $isfounder;
	if ($isfounder && empty($_G['cache']['duceapp_base']['sensitive'])) {
		return $string;
	}
	return $string ? substr($string, 0, $start).$enc.substr($string, -$end) : '';
}

function duceapp_comparencrypt($string, $source, $start = 1, $end = 5, $enc = '********') {
	return $string == duceapp_cutencrypt($source, $start, $end, $enc) ? $source : $string;
}

function duceapp_authencrypt($code, $force = '', $cachekey = 'duceapp_security') {
	global $_G;
	return $force == 'cookie' ? md5($code.FORMHASH) : md5(md5($code).($force ? $force : $_G['cache'][$cachekey]['salt']));
}

function duceapp_hex2rgb($hexColor, $opacity = 0, $string = true) {
	$color = str_replace('#', '', $hexColor);
	if (strlen($color) > 3) {
		$rgb = array(
			'r' => hexdec(substr($color, 0, 2)),
			'g' => hexdec(substr($color, 2, 2)),
			'b' => hexdec(substr($color, 4, 2))
		);
	} else {
		$color = $hexColor;
		$r = substr($color, 0, 1) . substr($color, 0, 1);
		$g = substr($color, 1, 1) . substr($color, 1, 1);
		$b = substr($color, 2, 1) . substr($color, 2, 1);
		$rgb = array(
			'r' => hexdec($r),
			'g' => hexdec($g),
			'b' => hexdec($b)
		);
	}
	return $string ? 'rgba('.$rgb['r'].','.$rgb['g'].','.$rgb['b'].','.(1 - $opacity/100).')' : $rgb;
}

function duceapp_csscache($file, $cssdata = '', $vars = array()) {
	$file = DISCUZ_ROOT.'./data/duceapp/'.$file.'.css';
	dmkdir(dirname($file));
	if ($cssdata) {
		duceapp_csscache_callback_1($vars, 1);
		$cssdata = preg_replace_callback("/\{([A-Z0-9_]+)\}/", 'duceapp_csscache_callback_1', $cssdata);
		$cssdata = preg_replace("/<\?.+?\?>\s*/", '', $cssdata);
		$cssdata = preg_replace(array('/\s*([,;:\{\}])\s*/', '/[\t\n\r]/', '/\/\*.+?\*\//'), array('\\1', '',''), $cssdata);
	}
	if (@$fp = fopen($file, 'wb')) {
		fwrite($fp, $cssdata);
		fclose($fp);
	}
}

function duceapp_csscache_callback_1($matches, $action = 0) {
	static $data = null;
	if ($action == 1) {
		$data = $matches;
	} else {
		return $data[strtolower($matches[1])];
	}
}

function duceapp_initcommoncss($styles = null) {
	if ($styles === null) {
		$theme_styles = array();
		@include DISCUZ_ROOT.'data/duceapp/base/theme_stylevar.php';
		return $theme_styles;
	}
	$cssdata = '';
	if ($styles) {
		if ($styles['fontweight']) {
			$cssdata .= '*{word-wrap:break-word;font-weight:400 !important;}* strong,* b,* a[style*="bold"],* span[style*="bold"],* strong *,* .seled,.seled *,* .bold{font-weight:600 !important;letter-spacing:0px;}*.quote *{font-weight:400 !important;}';
		}
		if ($styles['textcolor']) {
			$cssdata .= '.html,body{color:'.$styles['textcolor'].'}';
		}
		if ($styles['themecolor']) {
			$cssdata .= '.duceapp_head{background-color:'.$styles['themecolor'].'}.bgc,.slide_c{background-color:'.$styles['themecolor'].' !important}.bc_b,.tab li.a a{border-color:'.$styles['themecolor'].' !important;}.ffl, .ffl a, a.ffl,.ipt i.ppt,.bform .mdc a,.tip dt .xi2,.tab li.a a,.tbb li.a a{color:'.$styles['themecolor'].' !important;}';
		}
		if ($styles['linkcolor']) {
			$cssdata .= 'a:link, a:visited, a:hover{color:'.$styles['linkcolor'].'}';
		}
		if ($styles['buttoncolor']) {
			$cssdata .= '.bgt{background-color:'.$styles['buttoncolor'].' !important}';
		}
		duceapp_writecache(DISCUZ_ROOT.'./data/duceapp/base/theme_stylevar.php', $styles, 'theme_styles');
	}
	duceapp_csscache('base/common', $cssdata);
}

function duceapp_writeimage($target, $source = '', $s = '') {
	$succeed = false;
	if ($target && ($source || $s)) {
		dmkdir(dirname($target));
		if (($s || (@$fp_s = fopen($source, 'rb'))) && (@$fp_t = fopen($target, 'wb'))) {
			if ($s) {
				@fwrite($fp_t, $s);
			} else {
				while (!feof($fp_s)) {
					$s = @fread($fp_s, 1024 * 512);
					@fwrite($fp_t, $s);
				}
				fclose($fp_s);
			}
			fclose($fp_t);
			$succeed = true;
		}
	}
	return $succeed;
}

function duceapp_writecache($file, $data = null, $varname = '') {
	dmkdir(dirname($file));
	if ($fp = @fopen($file, 'wb')) {
		$varname = $varname ? preg_replace('/[^a-z0-9_]+/i', '', $varname) : 'data';
		require_once libfile('function/cache');
		$filedata = is_array($data) ? '$'.$varname.' = '.arrayeval($data) : $data;
		fputs($fp, "<?php\n/*\n".DUCEAPP_IDENT." cache file, do not modify me!".
			"\nCreated: ".date("M j, Y, G:i").
			"\n*/\n\n!defined('IN_DISCUZ') && exit('Access Denied');".
			"\n\n$filedata;\n?>");
		fclose($fp);
	}
}

function duceapp_download($name, $file = '', $buffer = '') {
	if (!$buffer && $file) {
		$etag = md5_file($file);
		$handle = fopen($file, "r");
		$buffer = '';
		while($b = fread($handle, 102400)) {
			$buffer .= $b;
			flush();
		}
		fclose($handle);
	}
	ob_end_clean();
	dheader("Expires: ".gmdate('D, d M Y H:i:s', time() + 86400)." GMT");
	dheader("Last-Modified: ".gmdate('D, d M Y H:i:s')." GMT"); 
	dheader('Pragma: no-cache');
	dheader("Cache-Control: no-cache, must-revalidate");
	dheader('Content-Encoding: none');
	dheader('Content-Disposition: attachment; filename="'.$name.'"');
	dheader('Etag: '.$etag ? $etag : md5($buffer));
	dheader('Content-Length: '.strlen($buffer));
	echo $buffer;
	define('FOOTERDISABLED' , 1);
	exit();
}

function duceapp_asort(&$data, $orderby = SORT_ASC, $colname = 'displayorder') {
	if (empty($data)) {
		return $data;
	}
	$sortarr = $temparr = array();
	foreach ($data as $key => $row) {
		$temparr[$row[$colname]][$key] = $row;
	}
	$column = array_keys($temparr);
	$orderby == SORT_DESC ? rsort($column) : sort($column);
	foreach($column as $col) {
		foreach ($temparr[$col] as $key => $row) {
			$sortarr[$key] = $row;
		}
	}
	return $data = $sortarr;
}

function duceapp_cmpdesc($a, $b) {
	if (is_array($a)) {
		$a = intval($a['displayorder']);
		$b = intval($b['displayorder']);
	}
	return $a == $b ? 0 : ($a > $b ? -1 : 1); 
}

function duceapp_cmpasc($a, $b) {
	if (is_array($a)) {
		$a = intval($a['displayorder']);
		$b = intval($b['displayorder']);
	}
	return $a == $b ? 0 : ($a < $b ? -1 : 1);
}