<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00602
 * Date: 2020-08-06 03:25:46
 * File: function_report_scan.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function duceapp_wechat_report_scan(){
	global $_G;
	if (!duceapp_wechatapi::_check_sign()) {
		return '';
	}
	$authcode = C::t('#duceapp_wechat#duceapp_wechat_authcode')->fetch_by_code($_GET['key']);
	if (!$authcode || $authcode['status'] == 1 || !$_GET['openid']) {
		return -1;
	} else {
		$authcode['resite'] = $_G['siteurl'];
		if ($authcode['uid']) {
			$member = getuserbyuid($authcode['uid'], 1);
			if ($member['uid'] && $member['adminid'] == 0 && !$_G['cache']['duceapp_wechat']['confirmtype']) {
				$wechatuser = C::t('#duceapp_wechat#duceapp_wechat_member')->fetch_by_unionid($_GET);
				if (!$wechatuser) {
					$wechatuser = duceapp_wechat::bindOpenId($member['uid'], $_GET);
				}
				if ($wechatuser['uid'] == $member['uid']) {
					C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($authcode['sid'], array('uid' => $member['uid'], 'status' => 1));
					$authcode['sid'] = '';
				}
			}
		} else {
			$wechatuser = C::t('#duceapp_wechat#duceapp_wechat_member')->fetch_by_unionid($_GET);
			if ($wechatuser && !($member = getuserbyuid($wechatuser['uid'], 1))) {
				C::t('#duceapp_wechat#duceapp_wechat_member')->delete($wechatuser['uid']);
			}
			if ($wechatuser) {
				if ($member['adminid'] == 0 && !$_G['cache']['duceapp_wechat']['confirmtype']) {
					C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($authcode['sid'], array('uid' => $member['uid'], 'status' => 1));
					$authcode['sid'] = '';
				}
			} elseif ($_G['cache']['duceapp_wechat']['mtype']) {
				$uid = duceapp_wechat::memberActivation(duceapp_wechatapi::report('syncheckuser', array(
					'uid' => 0,
					'openid' => $_GET['openid'],
					'unionid' => $_GET['unionid'],
				)));
				if (!$uid && $_G['cache']['duceapp_wechat']['allowregister'] && $_G['cache']['duceapp_wechat']['allowfastregister']) {
					$uid = duceapp_wechat::register($_GET);
				}
				if ($uid) {
					duceapp_wechat::bindOpenId($uid, $_GET, 1);
					C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
					$authcode['sid'] = '';
				}
			}
			if ($authcode['sid']) {
				C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($authcode['sid'], array('status' => -1));
			}
		}
		return json_encode($authcode);
	}
}