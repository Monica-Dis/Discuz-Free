<?php

function duceapp_wechat_report_synrename($_arg_0 = array())
{
	global $_G;
	if (empty($_arg_0)) {
		if (!duceapp_wechatapi::_check_sign()) {
			return '';
		}
		$_arg_0 = $_GET;
		require_once DISCUZ_ROOT . "./config/config_ucenter.php";
		if ($_arg_0["uc_api"] != UC_API) {
			return NULL;
		}
	}
	C::t("common_member")->update($_arg_0["uid"], array("password" => md5(random(10)), "username" => $_arg_0["newusername"]));
	$_var_2 = array("common_block" => array("id" => "uid", "name" => "username"), "common_invite" => array("id" => "fuid", "name" => "fusername"), "common_member" => array("id" => "uid", "name" => "username"), "common_member_verify_info" => array("id" => "uid", "name" => "username"), "common_mytask" => array("id" => "uid", "name" => "username"), "common_report" => array("id" => "uid", "name" => "username"), "forum_collection" => array("id" => "uid", "name" => "username"), "forum_activityapply" => array("id" => "uid", "name" => "username"), "forum_collectioncomment" => array("id" => "uid", "name" => "username"), "forum_collectionfollow" => array("id" => "uid", "name" => "username"), "forum_collectionteamworker" => array("id" => "uid", "name" => "username"), "forum_debate" => array("id" => "uid", "name" => "umpire"), "forum_forumrecommend" => array("id" => "authorid", "name" => "author"), "forum_groupuser" => array("id" => "uid", "name" => "username"), "forum_pollvoter" => array("id" => "uid", "name" => "username"), "forum_post" => array("id" => "authorid", "name" => "author"), "forum_postcomment" => array("id" => "authorid", "name" => "author"), "forum_promotion" => array("id" => "uid", "name" => "username"), "forum_ratelog" => array("id" => "uid", "name" => "username"), "forum_thread" => array("id" => "authorid", "name" => "author"), "home_album" => array("id" => "uid", "name" => "username"), "home_blog" => array("id" => "uid", "name" => "username"), "home_clickuser" => array("id" => "uid", "name" => "username"), "home_comment" => array("id" => "authorid", "name" => "author"), "home_docomment" => array("id" => "uid", "name" => "username"), "home_doing" => array("id" => "uid", "name" => "username"), "home_feed" => array("id" => "uid", "name" => "username"), "home_feed_app" => array("id" => "uid", "name" => "username"), "home_follow" => array("id" => "uid", "name" => "username"), "home_follow_feed" => array("id" => "uid", "name" => "username"), "home_follow_feed_archiver" => array("id" => "uid", "name" => "username"), "home_friend" => array("id" => "fuid", "name" => "fusername"), "home_friend_request" => array("id" => "fuid", "name" => "fusername"), "home_notification" => array("id" => "authorid", "name" => "author"), "home_pic" => array("id" => "uid", "name" => "username"), "home_poke" => array("id" => "fromuid", "name" => "fromusername"), "home_share" => array("id" => "uid", "name" => "username"), "home_show" => array("id" => "uid", "name" => "username"), "home_specialuser" => array("id" => "uid", "name" => "username"), "home_visitor" => array("id" => "vuid", "name" => "vusername"), "portal_article_title" => array("id" => "uid", "name" => "username"), "portal_comment" => array("id" => "uid", "name" => "username"), "portal_topic" => array("id" => "uid", "name" => "username"), "portal_topic_pic" => array("id" => "uid", "name" => "username"));
	if (!C::t("common_member")->update($_arg_0["uid"], array("username" => $_arg_0["newusername"])) && isset($_G["setting"]["membersplit"])) {
		C::t("common_member_archive")->update($_arg_0["uid"], array("username" => $_arg_0["newusername"]));
	}
	loadcache("posttableids");
	if ($_G["cache"]["posttableids"]) {
		foreach ($_G["cache"]["posttableids"] as $_var_3) {
			$_var_2[getposttable($_var_3)] = array("id" => "authorid", "name" => "author");
		}
	}
	foreach ($_var_2 as $_var_4 => $_var_5) {
		DB::query("UPDATE " . DB::table($_var_4) . " SET `" . $_var_5["name"] . "`='" . $_arg_0["newusername"] . "' WHERE `" . $_var_5["id"] . "`='" . $_arg_0["uid"] . "'");
	}
	DB::update("forum_collection", array("lastposter" => $_arg_0["newusername"]), array("lastposter" => $_arg_0["username"]));
	DB::update("forum_thread", array("lastposter" => $_arg_0["newusername"]), array("lastposter" => $_arg_0["username"]));
	DB::update("home_follow", array("fusername" => $_arg_0["newusername"]), array("followuid" => $_arg_0["uid"]));
	C::t("#duceapp_wechat#duceapp_wechat_member")->update($_arg_0["uid"], array("isregister" => 2, "username" => $_arg_0["newusername"]));
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}