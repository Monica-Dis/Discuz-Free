<?php

function duceapp_wechat_syncheckuser($_arg_0)
{
	$_var_1 = array("uid" => 0, "openid" => $_arg_0["openid"], "unionid" => $_arg_0["unionid"]);
	return duceapp_wechatapi::report("syncheckuser", $_var_1);
}
function duceapp_wechat_response($_arg_0, $_arg_1)
{
	global $_G;
	if ($_arg_1) {
		$_var_3 = duceapp_wechat_syncheckuser($_arg_0);
		$_var_4 = duceapp_wechat::memberActivation($_var_3);
	} else {
		$_var_4 = 0;
	}
	if (!$_var_4 && $_G["cache"]["duceapp_wechat"]["allowregister"] && $_G["cache"]["duceapp_wechat"]["allowfastregister"]) {
		$_var_4 = duceapp_wechat::register($_arg_0, 1);
	}
	if ($_var_4) {
		return duceapp_wechat::bindOpenId($_var_4, $_arg_0, 1);
	}
	return false;
}
function duceapp_wechat_login($_arg_0, $_arg_1, $_arg_2)
{
	$_var_3 = getuserbyuid($_arg_1["uid"], 1);
	setloginstatus($_var_3, 1296000);
	if ($_arg_2 && $_arg_0) {
		duceapp_wechat::updateLogin($_arg_1, $_arg_0, true);
	}
}
function duceapp_wechat_logon($_arg_0, $_arg_1, $_arg_2)
{
	global $_G;
	include_once libfile("class/duceapp_wechatapi", "plugin/duceapp_wechat");
	include_once libfile("function/member");
	$_var_4 = C::t("#duceapp_wechat#duceapp_wechat_member")->fetch_by_unionid($_arg_0);
	if ($_var_4) {
		if ($_G["uid"] && $_var_4["uid"] != $_arg_2) {
			showmessage("duceapp_wechat:wechat_openid_exists");
		}
		$_arg_2 = $_var_4["uid"];
	}
	$_var_5 = $_arg_2 ? getuserbyuid($_arg_2, 1) : false;
	if ($_var_5) {
		setloginstatus($_var_5, 1296000);
		if (!$_var_4 || $_var_5["uid"] != $_var_4["uid"]) {
			$_var_4 = C::t("#duceapp_wechat#duceapp_wechat_member")->fetch($_var_5["uid"]);
		}
		if (!$_var_4) {
			duceapp_wechat::bindOpenId($_var_5["uid"], $_arg_0);
		} else {
			duceapp_wechat::updateLogin($_var_4, $_arg_0, true, !$_arg_1);
		}
	} else {
		if ($_var_4["uid"]) {
			C::t("#duceapp_wechat#duceapp_wechat_member")->delete($_var_4["uid"]);
		}
		$_var_6 = duceapp_wechat_syncheckuser($_arg_0);
		$_var_7 = duceapp_wechat::memberActivation($_var_6, $_arg_0);
		$_var_5 = $_var_7 ? getuserbyuid($_var_7, 1) : false;
		if ($_var_5) {
			setloginstatus($_var_5, 1296000);
		} else {
			if (!$_G["cache"]["duceapp_wechat"]["allowfastregister"]) {
				duceapp_wechat::redirectregister($_arg_0, $_arg_1);
			}
			$_var_7 = duceapp_wechat::register($_arg_0, 1);
			if ($_var_7) {
				duceapp_wechat::bindOpenId($_var_7, $_arg_0, 1);
			} else {
				duceapp_wechat::redirectregister($_arg_0, $_arg_1);
			}
		}
	}
}
function duceapp_wechat_docompon($_arg_0, $_arg_1 = '')
{
	global $_G;
	if (is_array($_arg_0)) {
		$_arg_1 = is_array($_arg_1) ? $_arg_1 : array();
		foreach ($_arg_0 as $_var_3 => $_var_4) {
			if ($_G["cache"]["duceapp_wechat"][$_var_4]["enabled"] || $_arg_1[$_var_4]) {
				$_G["duceapp_module"][$_var_4] = $_arg_1[$_var_4];
				@(include DISCUZ_ROOT . "./source/plugin/duceapp_wechat/compon/" . $_var_4 . "/do.php");
			}
		}
	} else {
		if ($_G["cache"]["duceapp_wechat"][$_arg_0]["enabled"] || $_arg_1) {
			$_G["duceapp_module"][$_arg_0] = $_arg_1;
			@(include DISCUZ_ROOT . "./source/plugin/duceapp_wechat/compon/" . $_arg_0 . "/do.php");
		}
	}
}
function duceapp_wechat_validator()
{
	global $_G;
	$_var_2 = duceapp_wechat_makesign($_var_1);
	if ($_var_2[1] === $_G["setting"][$_var_2[0]]) {
		return true;
	}
	return false;
}
function duceapp_wechat_makesign($_arg_0)
{
	$_arg_0 = md5("duceapp_wechat " . $_arg_0);
	$_var_1 = base64_encode(substr($_arg_0, 3, 6));
	$_var_1 = str_replace("=", '', "duceapp_" . strtolower($_var_1));
	return array($_var_1, $_arg_0);
}
function duceapp_wechat_addoncheck()
{
	$_var_0 = cloudaddons_getmd5("duceapp_wechat.plugin");
	$_var_1 = explode(",", $_var_0["RevisionDateline"]);
	if (duceapp_wechat_validator()) {
		return $_var_1[0] ? $_var_1[0] : TIMESTAMP;
	}
	$_var_2 = '' . $_var_0[RevisionID] . "&sn=" . $_var_0[SN] . "&rd=" . $_var_0[RevisionDateline] . '';
	$_var_3 = explode(",", $_var_0["SN"]);
	$_var_4 = explode(",", $_var_0["RevisionID"]);
	duceapp_wechat_addonsign($_var_3[0], $_var_4[0]);
	return $_var_1[0];
}
function duceapp_wechat_addonsign($_arg_0, $_arg_1)
{
	$_var_2 = duceapp_wechat_makesign(md5($_arg_0 . $_arg_1));
	C::t("common_setting")->update_batch(array($_var_2[0] => $_var_2[1]));
	updatecache("setting");
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	include_once "function_duceapp_wechat.php";