<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: function_report_synactivation.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function duceapp_wechat_report_synactivation(){
	global $_G;
	if (!duceapp_wechatapi::_check_sign()) {
		return '';
	}
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if ($_GET['uc_api'] != UC_API) {
		return;
	}
	require_once libfile('class/duceapp_wechat', 'plugin/duceapp_wechat');
	$member = getuserbyuid($_GET['uid'], 1);
	$wechat_member = C::t('#duceapp_wechat#duceapp_wechat_member')->fetch_by_unionid($_GET);
	if ($member) {
		if (!$wechat_member) {
			duceapp_wechat::bindOpenId($member['uid'], $_GET);
		}
	} elseif (!$_G['setting']['regclosed'] && $_G['setting']['ucactivation']) {
		duceapp_wechat::memberActivation($_GET, !$wechat_member ? $_GET : null);
	}
}