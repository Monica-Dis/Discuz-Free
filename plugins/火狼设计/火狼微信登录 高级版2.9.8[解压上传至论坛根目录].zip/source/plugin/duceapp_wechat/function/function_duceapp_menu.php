<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: function_duceapp_menu.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

function convertname($str) {
	return urlencode(diconv($str, CHARSET, 'UTF-8'));
}

function menukeyselect($varname, $value, $selectarr, $disabled = ''){
	$s = '<select name="'.$varname.'">';
	foreach($selectarr as $k => $name) {
		$s .= '<option value="'.$k.'"'.($value == $k ? ' selected' : '').'>'.$name.'</option>';
	}
	$s .= '</select>';
	return $s;
}

function duceapp_wechat_set($id = '{vid}', $varname = '{varname}', $data = array(), $display = array(), $checked = array(), $return = false){
	global $_G, $lang, $keyselect, $plang;
	if (!$keyselect) {
		$plang = $_G['cache']['pluginlanguage_script']['duceapp_wechat'];
		$keyselect = array(
			'access' => $plang['menu_key_access'],
			'mycenter' => $plang['menu_key_mycenter'],
			'profile' => $plang['menu_key_profile'],
		);
		if (helper_access::check_module('group')) {
			$keyselect['group'] = $plang['menu_key_group'];
		}
		if (helper_access::check_module('album')) {
			$keyselect['album'] = $plang['menu_key_album'];
		}
		if (helper_access::check_module('album')) {
			$keyselect['blog'] = $plang['menu_key_blog'];
		}
	}
	$keyselectstr = menukeyselect("button{$varname}[keysel]", $data['keysel'] ? $data['keysel'] : 'access', $keyselect);
	if ($id === '{vid}') {
		$divid = 'sethidden';
		$display = array('', 'display:none;', 'display:none;', '', '', 'display:none;');
		$checked = array('checked', '', '', '', 'checked');
		$data['name'] = '{value}';
		$menuhead = '{menuhead}';
		$menuspan = '{menuspan}';
		$contentspan = '{contentspan}';
	} else {
		$id .= '';
		$divid = $id.'_set';
		$sub = strpos($id, '_') !== false;
		$menuhead = $sub ? $plang['menu_button_sub'] : $plang['menu_button'];
		$menuspan = $sub ? $plang['menu_button_subname'] : $plang['menu_button_name'];
		$contentspan = $sub ? $plang['menu_button_subcontent'] : $plang['menu_button_content'];
		$data = dhtmlspecialchars($data);
	}
$menuhtml = <<<EOF
<div id="wechat_{$divid}" class="wechat_menuset" style="display:none;">
	<h2 class="cl">{$menuhead}<span class="del" onclick="wechat_edit(this,'del','{$id}')">$lang[delete]</span></h2>
	<div class="box">
		<div class="pt cl"><span>{$menuspan}</span><input type="text" class="txt" name="button{$varname}[name]" value="$data[name]" onblur="wechat_edit(this,'edit','$id')" oninput="wechat_edit(this,'edit','$id')" onpropertychange="wechat_edit(this,'edit','$id')" style="width:294px"></div>
			<div id="wechat_{$id}_setbox">
			<div class="pt cl" style="padding:0;"><span>{$contentspan}</span><div onmouseover="wechat_keysel(this, '$id')"><label class="$checked[0]"><input type="radio" class="radio" name="button{$varname}[keymod]" value="0" $checked[0] />$plang[menu_button_keymod_0]</label> &nbsp; <label class="$checked[1]"><input type="radio" class="radio" name="button{$varname}[keymod]" value="1" $checked[1] />$plang[menu_button_keymod_1]</label> &nbsp;<label class="$checked[2]"><input type="radio" class="radio" name="button{$varname}[keymod]" value="2" $checked[2] />$plang[menu_button_keymod_2]</label></div></div>
			<div class="pt ptp" id="wechat_{$id}_type">
				<div style="margin-top:-8px;{$display[0]}" id="wechat_{$id}_type_0">
					<input type="text" class="txt" id="wechat_{$id}_keyurl" style="width:294px" name="button{$varname}[keyurl]" value="$data[keyurl]" placeholder="KEY/URL" />
					<div class="ptpm">
						<div class="pt cl" style="padding:0;">
							<span></span><ul onmouseover="altStyle(this);"><li class="$checked[5]"><input type="checkbox" class="checkbox" name="button{$varname}[keytype]" value="miniprogram" onclick="if(this.checked){\$('wechat_{$id}_miniprogram').style.display='';\$('wechat_{$id}_keyurl').setAttribute('placeholder','$plang[menu_miniprogram_holder]');}else{\$('wechat_{$id}_miniprogram').style.display='none';\$('wechat_{$id}_keyurl').setAttribute('placeholder','KEY/URL');}" $checked[5] />$plang[menu_button_miniprogram]</li></ul>
						</div>
						<div id="wechat_{$id}_miniprogram" style="$display[5]">
							<div class="pt cl" style="padding:0;">
								<span>$plang[menu_button_appid]</span>
								<input type="text" class="txt" style="width:294px" name="button{$varname}[appid]" value="$data[appid]" />
							</div>
							<div class="pt cl" style="padding:0;">
								<span>$plang[menu_button_pagepath]</span>
								<input type="text" class="txt" style="width:294px" name="button{$varname}[pagepath]" value="$data[pagepath]" />
							</div>
						</div>
					</div>
				</div>
				<div style="overflow:hidden;{$display[1]}" id="wechat_{$id}_type_1">
					<div class="selresource"><em class="add" onclick="resource_showlist(this)">$plang[menu_button_selresource]</em><em class="add" onclick="resource_showlist(this, 2)" style="margin-top:0;">$plang[menu_button_mpresource]</em><input type="hidden" name="button{$varname}[keyresource]" value="$data[keyresource]"></div>
				</div>
				<div style="overflow:hidden;margin-top:-8px;{$display[2]}" id="wechat_{$id}_type_2">
					$keyselectstr
				</div>
			</div>
		</div>
	</div>
</div>
EOF;
	if ($return) {
		return $menuhtml;
	}
	echo $menuhtml;
}