<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00806
 * Date: 2020-08-06 03:25:46
 * File: function_duceapp_wechat.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function duceapp_wechat_initialize() {
	global $_G; 
	static $initialized;

	if (!isset($_G['cache']['duceapp_wechat'])) {
		loadcache('duceapp_wechat');
	}
	if ($initialized) return;
	
	$_G['duceapp_wechataccess'] = 'source/plugin/duceapp_wechat/logging.php?';
	$_G['duceapp_wechatdataurl'] = 'data/duceapp/wechat/';
	$_G['duceapp_discuzuid'] = $_G['uid'];
	$_G['duceapp_wechatuser'] = null;

	$initialized = true;
}

function duceapp_wechat_getapps() {
	global $_G;
	if ($_G['cache']['duceapp_wechat']['synapps']) {
		return $_G['cache']['duceapp_wechat']['synapps'];
	}
	@include DISCUZ_ROOT.'./uc_client/data/cache/apps.php';
	return $_CACHE['apps'];
}

function duceapp_wechat_getuser($uid) {
	return $uid ? C::t('#duceapp_wechat#duceapp_wechat_member')->fetch($uid) : null;
}

function duceapp_wechat_language($name, $path = '') {
	$path = DISCUZ_ROOT.'./source/plugin/duceapp_wechat/'.($path ? $path : 'language');
	$name = is_file($path.'/lang_'.$name.'.php') ? $name : $name.'_'.currentlang();
	return $path.'/lang_'.$name.'.php';
}

function duceapp_wechat_authc() {
	return '178248af369453807cc02ad1cbb0f50a';
}

function duceapp_wechat_referer() {
	global $_G;
	$referer = dreferer();
	if (strpos($referer, 'member.php') !== false || strpos($referer, 'duceapp_wechat/logging.php') !== false) {
		parse_str($referer, $referer);
		if ($referer['referer']) {
			parse_str($referer['referer'], $referer);
		}
		if ($referer['auth']) {
			list(,,,$referer) = explode("\t", authcode(base64_decode($referer['auth']), 'DECODE'));
		} elseif ($referer['referer']) {
			$referer = strpos($referer['referer'], 'logging.php') !== false ? $_G['siteurl'] : $referer['referer'];
		}
		$referer = !is_array($referer) && $referer ? $referer : $_G['siteurl'];
	}
	return $referer;
}

function duceapp_wechat_checksign($request_http = 'get'){
	global $_G;
	$data = $request_http == 'get' ? $_GET : $_POST;
	$timestamp = intval($data['timestamp']);
	if (!$timestamp || TIMESTAMP - $timestamp > 60 || !$data['nonce'] || !$data['signature']) {
		return -2;
	}
	$shaArray = array($_G['cache']['duceapp_wechat']['secret'], $data['op'], $timestamp, $data['nonce']);
	sort($shaArray, SORT_STRING);
	$shaString = implode($shaArray);
	if ($data['signature'] != sha1($shaString)) {
		return -1;
	}
	return 0;
}

function duceapp_wechat_getRedirect() {
	global $_G;
	$setting = $_G['cache']['duceapp_wechat'];
	$redirect = $setting['oauthsite'] && !$setting['api'] ? $setting['oauthsite'] : $_G['siteurl'];
	if (!$qrtype && empty($_G['setting']['duceapp_synsite']) && strpos($redirect, $_SERVER['HTTP_HOST']) === FALSE) {
		$redirect .= 'duceapp_wechatauth.php?resite='.urlencode($_G['siteurl']).'&';
	} else {
		$redirect .= $_G['duceapp_wechataccess'];
	}
	return $redirect;
}