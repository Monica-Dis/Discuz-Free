<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00602
 * Date: 2020-08-06 03:25:46
 * File: api.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

define('IN_API', true);
define('ALLOWGUEST', 1);

chdir('../../../');

require 'source/class/class_core.php';

$discuz = C::app();
$cachelist = array('plugin');
$discuz->cachelist = $cachelist;
$discuz->init();

$_G['siteurl'] = str_replace('source/plugin/duceapp_wechat/', '', $_G['siteurl']);

require libfile('function/duceapp_core', 'plugin/duceapp_wechat');

duceapp_wechat_initialize();

$op = !empty($_GET['op']) ? $_GET['op'] : 'login';
$redirect = $appsecret = '';

if ($_GET['auth']) {
	list($redirect, $appsecret, $apilogin) = explode("\t", authcode(base64_decode($_GET['auth']), 'DECODE', $_G['cache']['duceapp_wechat']['token']));
}

if ($op == 'login') {

	if (!$redirect) {
		dheader('Location:'.$_G['siteurl'].$_G['duceapp_wechataccess'].'ac=login&error=auth');
	}
	if ($_G['cache']['duceapp_wechat']['api']) {
		dheader('Location:'.$redirect.'&error=api');
	}
	$redirect_uri = $_G['siteurl'].$_G['cache']['duceapp_wechat']['apiurl'].'op=callback&auth='.$_GET['auth'];
	if ($apilogin) {
		$frameurl = '';
		$appid = $_GET['appid'];
		$redirect_uri = urlencode($redirect_uri);
		include_once template('duceapp_wechat:wechat_qrcodejs');
		exit();
	}
	include_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');
	$wechat_client = new duceapp_wechatclient($_GET['appid'], $appsecret);
	dheader('Location:'.$wechat_client->getOAuthConnectUri($redirect_uri, $_GET['state'], $_GET['scope']));

} elseif ($op == 'callback') {

	if (!$redirect) {
		dheader('Location:'.$_G['siteurl'].$_G['duceapp_wechataccess'].'ac=login&error=auth');
	}
	dheader('Location:'.$redirect.(strpos($redirect, '?') !== false ? '&' : '?').'code='.$_GET['code'].'&state='.$_GET['state']);

} elseif ($op == 'ticket' || $op == 'token') {

	$appid = $_GET['appid'] ? $_GET['appid'] : $_G['cache']['duceapp_wechat']['mp']['appid'];
	if (!$appid) {
		echo json_encode(array('errcode' => 40013)); exit;
	}
	$refresh = intval($_GET['refresh']);
	if (!$appsecret) {
		if ($_G['cache']['duceapp_wechat']['secret'] !== $_GET['secret']) {
			echo json_encode(array('errcode' => 1)); exit;
		}
		$appsecret = $_G['cache']['duceapp_wechat']['mp']['appsecret'];
		$_GET['stronly'] = 0;
	}
	require_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');
	$wechat_client = new duceapp_wechatclient($appid, $appsecret);
	$res = $op == 'token' ? $wechat_client->getAccessToken($_GET['stronly'], 0, $refresh) : $wechat_client->getJsApiTicket($_GET['stronly'], $refresh);
	echo is_array($res) ? json_encode($res) : $res;

} elseif ($op == 'getuser' || $op == 'saveuser') {

	$res = array();

	if ($op == 'getuser') {

		if (empty($_GET['openid']) && empty($_GET['uid'])) {
			$res['errcode'] = -2;
		} else {
			$res['errcode'] = duceapp_wechat_checksign();
		}
		if ($res['errcode']) {
			echo json_encode($res);
		} else {
			if ($_GET['uid']) {
				$wechatuser = C::t('#duceapp_wechat#duceapp_wechat_member')->fetch($_GET['uid']);
			} else {
				$wechatuser = C::t('#duceapp_wechat#duceapp_wechat_member')->fetch_by_unionid($_GET);
			}
			$wechatuser = $wechatuser ? $wechatuser : array('errcode' => 1);
			echo json_encode($wechatuser);
		}

	} elseif ($op == 'binduser') {

		if (empty($_POST['openid']) || empty($_POST['uid']) || !getuserbyuid($_POST['uid'], 1)) {
			$res['errcode'] = -2;
		} else {
			$res['errcode'] = duceapp_wechat_checksign('post');
		}
		if (!$res['errcode']) {
			$wheresql = array(
				DB::field('uid', $_POST['uid']),
				DB::field('openid', $_POST['openid']),
			);
			if ($_POST['unionid']) {
				$wheresql[] = DB::field('unionid', $_POST['unionid']);
			}
			if (DB::fetch_first('SELECT * FROM %t WHERE %i', array('duceapp_wechat_member', implode(' OR ', $wheresql)))) {
				$res['errcode'] = 1;
			}
		}
		if ($res['errcode']) {
			echo json_encode($res);
		} else {
			$userdata = array(
				'uid' => intval($_POST['uid']),
				'subscribe' => isset($_POST['subscribe']) ? $_POST['subscribe'] : -1,
				'openid' => trim($_POST['openid']),
			);
			if ($_POST['unionid']) {
				$userdata['unionid'] = trim($_POST['unionid']);
			}
			foreach(array('username','isregister','nickname','sex','dateline','lastauth','lat','lng') as $k) {
				if (isset($_POST[$k])) {
					$userdata[$k] = $_POST[$k];
				}
			}
			C::t('#duceapp_wechat#duceapp_wechat_member')->insert($userdata, false, true);
			echo json_encode(array('errcode' => 0));
		}

	}

} elseif ($op == 'report') {

	include_once libfile('class/duceapp_wechat', 'plugin/duceapp_wechat');
	include_once libfile('class/duceapp_wechatapi', 'plugin/duceapp_wechat');
	echo duceapp_wechatapi::import();

}