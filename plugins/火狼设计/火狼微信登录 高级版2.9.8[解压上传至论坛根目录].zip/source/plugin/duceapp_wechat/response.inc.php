<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: response.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if (!defined('DUCEAPP_ADMINCP')) {
	dheader("Location:".ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&pmod=setting&danchor=response');
}

require_once libfile('class/duceapp_wechathook', 'plugin/duceapp_wechat');

$response = & $this->setting['response'];

if ($this->cpmethod != 'save') {

	$responsehook = duceapp_wechathook::getResponse('duceapp_wechat');

	if($_GET['subscribe'] == 'custom') {
		$response['subscribeback'] = $responsehook['receiveEvent::subscribe'];
		$updatedata = array('receiveEvent::subscribe' => array('plugin' => 'duceapp_wechat', 'include' => 'class/class_duceapp_response.php', 'class' => 'duceapp_response', 'method' => 'custom'));
		$responsehook = duceapp_wechathook::updateResponse($updatedata, 'duceapp_wechat');
		duceapp_succeed('response_message_custom', $this->redirect.'&danchor=response');
	} elseif($_GET['subscribe'] == 'restore') {
		$response['subscribeback'] = $response['subscribeback'] ? $response['subscribeback'] : array('plugin' => 'duceapp_wechat', 'include' => 'class/class_duceapp_response.php', 'class' => 'duceapp_response', 'method' => 'subscribe');
		$updatedata = array('receiveEvent::subscribe' => $response['subscribeback']);
		$responsehook = duceapp_wechathook::updateResponse($updatedata, 'duceapp_wechat');
		duceapp_succeed('response_message_plugin', $this->redirect.'&danchor=response');
	}

	duceapp_anchortips('response_tips');

	duceapp_formheader();

	duceapp_anchorheader();
	duceapp_showsubtitle(
		array('', 'response_keyword', '', 'response_content', 'response_level'), 
		array('class="td25"', 'style="width:185px;"', 'style="width:60px;"', 'style="width:420px;"', '')
	);
	if ($responsehook['receiveEvent::subscribe']['method'] == 'custom') {
		showtablerow('', array('class="vmtop1"', 'class="vmtop1"', 'class="vmtop1 textright"', 'class="vmtop3"', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" value=\"\" disabled>",
			duceapp_cplang('response_subscribe')." <a class=\"normal\" href=\"".$this->redirect."&danchor=response&subscribe=restore\">[".duceapp_cplang('response_switch_plugin_mode')."]</a>",
			"<a href=\"javascript:;\" id=\"rsel\" onclick=\"resource_showlist('res_subscribe')\">".duceapp_cplang('resource_select')."</a>",
			"<textarea class=\"tarea\" name=\"response[subscribe]\" id=\"res_subscribe\" style=\"height:16px;\" cols=\"40\" onclick=\"duceapp_inputobj=this\" ondblclick=\"if(this.style.height=='16px'){this.style.height='80px';\$('mext_subscribe').style.display=''}else{this.style.height='16px';\$('mext_subscribe').style.display='none'}\">".dhtmlspecialchars($response['subscribe'])."</textarea><br /><p id=\"mext_subscribe\" style=\"display:none;margin:6px 0 2px;\">".duceapp_cplang('response_linktxtbtn').duceapp_cplang('response_conftxtbtn')."</p>",
			''
		));
	} else {
		showtablerow('', array('class="vmtop1" style="height:25px;"'), array(
			"<input class=\"checkbox\" type=\"checkbox\" value=\"\" disabled>",
			duceapp_cplang('response_subscribe')." <a class=\"normal\" href=\"".$this->redirect."&danchor=response&subscribe=custom\">[".duceapp_cplang('response_switch_custom_mode')."]</a>",
			'',
			duceapp_cplang('response_plugin_mode'),
			''
		));
	}
	showtablerow('', array('class="vmtop1"', 'class="vmtop1"', 'class="vmtop1 textright"', 'class="vmtop3"', ''), array(
		"<input class=\"checkbox\" type=\"checkbox\" value=\"\" disabled>",
		duceapp_cplang('response_scan'),
		"<a href=\"javascript:;\" id=\"rsel\" onclick=\"resource_showlist('res_scan')\">".duceapp_cplang('resource_select')."</a>",
		"<textarea class=\"tarea\" name=\"response[scan]\" id=\"res_scan\" style=\"height:16px;\" cols=\"40\" onclick=\"duceapp_inputobj=this\" ondblclick=\"if(this.style.height=='16px'){this.style.height='80px';\$('mext_scan').style.display=''}else{this.style.height='16px';\$('mext_scan').style.display='none'}\">".dhtmlspecialchars($response['scan'])."</textarea><br /><p id=\"mext_scan\" style=\"display:none;margin:6px 0 2px;\">".duceapp_cplang('response_linktxtbtn').duceapp_cplang('response_conftxtbtn')."</p>",
		''
	));
	showtablerow('', array('class="vmtop1"', 'class="vmtop1"', 'class="vmtop1 textright"', 'class="vmtop3"', ''), array(
		"<input class=\"checkbox\" type=\"checkbox\" value=\"\" disabled>",
		duceapp_cplang('response_access'),
		"<a href=\"javascript:;\" id=\"rsel\" onclick=\"resource_showlist('res_access')\">".duceapp_cplang('resource_select')."</a>",
		"<textarea class=\"tarea\" name=\"response[access]\" id=\"res_access\" style=\"height:16px;\" cols=\"40\" onclick=\"duceapp_inputobj=this\" ondblclick=\"if(this.style.height=='16px'){this.style.height='80px';\$('mext_access').style.display=''}else{this.style.height='16px';\$('mext_access').style.display='none'}\">".dhtmlspecialchars($response['access'])."</textarea><br /><p id=\"mext_access\" style=\"display:none;margin:6px 0 2px;\">".duceapp_cplang('response_linktxtbtn').duceapp_cplang('response_conftxtbtn')."</p>",
		''
	));
	showtablerow('', array('class="vmtop1"', 'class="vmtop1"', 'class="vmtop1 textright"', 'class="vmtop3"', ''), array(
		"<input class=\"checkbox\" type=\"checkbox\" value=\"\" disabled>",
		duceapp_cplang('response_sendnum'),
		"<a href=\"javascript:;\" id=\"rsel\" onclick=\"resource_showlist('res_sendnum')\">".duceapp_cplang('resource_select')."</a>",
		"<textarea class=\"tarea\" name=\"response[sendnum]\" id=\"res_sendnum\" style=\"height:16px;\" cols=\"40\" onclick=\"duceapp_inputobj=this\" ondblclick=\"if(this.style.height=='16px'){this.style.height='80px';\$('mext_sendnum').style.display=''}else{this.style.height='16px';\$('mext_sendnum').style.display='none'}\">".dhtmlspecialchars($response['sendnum'])."</textarea><br /><p id=\"mext_sendnum\" style=\"display:none;margin:6px 0 2px;\">".duceapp_cplang('response_linktxtbtn').duceapp_cplang('response_conftxtbtn')."</p>",
		''
	));
	$linktxtbtn = duceapp_cplang('response_linktxtbtn');

	foreach($response['text'] as $k => $text) {
		showtablerow('', array('class="vmtop1"', 'class="vmtop2"', 'class="vmtop1 textright"', 'class="vmtop3"', 'class="vmtop2"'), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"response[text][$k][delete]\" value=\"yes\">",
			"<input type=\"text\" class=\"txt\" size=\"30\" name=\"response[text][$k][keyword]\" value=\"".dhtmlspecialchars($text['keyword'])."\" style=\"width:165px;\">",
			"<a href=\"javascript:;\" id=\"rsel\" onclick=\"resource_showlist('res_text_$k')\">".duceapp_cplang('resource_select')."</a>",
			"<textarea class=\"tarea\" name=\"response[text][$k][response]\" style=\"height:16px;\" id=\"res_text_$k\" cols=\"40\" onclick=\"duceapp_inputobj=this\" ondblclick=\"if(this.style.height=='16px'){this.style.height='80px';\$('mext_text_$k').style.display=''}else{this.style.height='16px';\$('mext_text_$k').style.display='none'}\">".dhtmlspecialchars($text['response'])."</textarea><p id=\"mext_text_$k\" style=\"display:none;margin:6px 0 2px;\">$linktxtbtn</p>",
			"<input class=\"txt\" type=\"text\" name=\"response[text][$k][displayorder]\" value=\"".intval($text['displayorder'])."\" style=\"width:70px;\">"
		));
	}
	echo '<tr><td></td><td colspan="14"><div><span onclick="duceapp_addrow(this, 0, newrowindex++)" class="addtr">'.duceapp_cplang('response_add_message').'</span></div></td></tr>';
	$s = "<a href=\"javascript:;\" id=\"rsel\" onclick=\"resource_showlist(\'res_newtext_{1}\')\">".duceapp_cplang('resource_select')."</a>";
	$this->showResource('menu', 1);
	$linkobjhtml = duceapp_cplang('response_linkobj');
	$confirmobjhtml = duceapp_cplang('response_confirmobj');
	echo <<<EOT
<script type="text/JavaScript">
var linkobjhtml = '$linkobjhtml';
var confirmobjhtml = '$confirmobjhtml';
var newrowindex = 0;
var rowtypedata = [
[[1,'<div><a href="javascript:;" class="deleterow" onClick="deleterow(this)" style="margin-left:6px;">$lang[delete]</a></div>'], [1, '<input name="newresponse[keyword][{1}]" value="" size="30" type="text" class="txt" style="width:165px;">', 'vmtop2'], [1, '$s', 'vmtop1 textright'], [1, '<textarea class="tarea" name="newresponse[response][{1}]" id="res_newtext_{1}" rows="4" cols="40" onclick="duceapp_inputobj=this" style="height:16px;" ondblclick="if(this.style.height==\'16px\'){this.style.height=\'80px\';\$(\'mext_newtext_{1}\').style.display=\'\'}else{this.style.height=\'16px\';\$(\'mext_newtext_{1}\').style.display=\'none\'}"></textarea><p id="mext_newtext_{1}" style="display:none;margin:6px 0 2px;">$linktxtbtn</p>', 'vmtop3'], [1, '<input class="txt" type="text" name="newresponse[displayorder][{1}]" value="" style="width:70px;">', 'vmtop2']],
];
</script>
EOT;
	showsubmit('wechatsave', 'submit', 'del');
	duceapp_anchorfooter();

	showformfooter();/*dism��taobao��com*/

} else {

	if (!empty($_GET['newresponse'])) {
		foreach($_GET['newresponse']['keyword'] as $k => $keyword) {
			$newvalue = trim($_GET['newresponse']['response'][$k]);
			$item = array(
				'displayorder' => intval($_GET['newresponse']['displayorder'][$k]),
				'keyword' => trim($keyword),
				'response' => $newvalue,
			);
			$response['text'][] = $item;
		}
	}

	if ($_GET['response']['text']){
		foreach($_GET['response']['text'] as $k => $value) {
			if($value['delete']) {
				unset($response['text'][$k]);
				continue;
			}
			$response['text'][$k] = $value;
		}
	}

	$response['subscribe'] = trim($_GET['response']['subscribe']);
	$response['access'] = trim($_GET['response']['access']);
	$response['scan'] = trim($_GET['response']['scan']);
	$response['sendnum'] = trim($_GET['response']['sendnum']);

	$query = array(
	    'subscribe' => $response['subscribe'],
	    'text' => array(),
	);

	$response['query_regex'] = array();

	foreach($response['text'] as $k => $value) {
		$query['text'][$value['keyword']] = trim($value['response']);
		preg_match_all('/^\{(\^)?(.+?)(\$)?\}$/', $value['keyword'], $matches);
		if ($matches[2][0]) {
			$regex = '/'.$matches[1][0].str_replace(array('*','^','$','\''), array('(.+?)','\\^','\\$', '\\\''), $matches[2][0]).$matches[3][0].'/i';
			$response['query_regex'][$value['keyword']] = array('displayorder' => intval($value['displayorder']), 'regex' => $regex);
		}
	}
	uasort($response['query_regex'], 'duceapp_cmp_asc');

	$response['query'] = $query;

}