<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00410
 * Date: 2020-08-06 03:25:46
 * File: duceapp_wechat.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$ac = !empty($_GET['ac']) ? $_GET['ac'] : 'response';

if (defined('DUCEAPP_ACCESS')) {
	$_G['siteurl'] = str_replace('source/plugin/duceapp_wechat/', '', $_G['siteurl']);
	if (!$_G['inajax'] && $ac != 'message') {
		class mobileplugin_duceapp_wechat_plugin {
			public function _showmessage($params) {
				global $_G;
				$s = urlencode($params['param'][0]).'&url='.urlencode($params['param'][1]);
				dheader('location:'.$_G['siteurl'].'plugin.php?id=duceapp_wechat&ac=message&skey='.$s);
			}
		}
		C::m('#duceapp_base#duceapp_helper')->messagefunc('plugin', 'duceapp_wechat', 'duceapp_wechat', '_showmessage');
	}
	if ($_GET['referer'] && !preg_match('/^http/i', $_GET['referer'])) {
		$_GET['referer'] = $_G['siteurl'].$_GET['referer'];
	}
}

if (@!file_exists(DISCUZ_ROOT.($acfile = './source/plugin/duceapp_wechat/include/wechat_'.$ac.'.php'))) {
	showmessage('undefined_action', '', array(), array('showdialog' => 1));
}

include DISCUZ_ROOT.$acfile;