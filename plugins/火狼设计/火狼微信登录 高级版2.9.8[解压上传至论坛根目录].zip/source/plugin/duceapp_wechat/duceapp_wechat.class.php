<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00729
 * Date: 2020-08-06 03:25:46
 * File: duceapp_wechat.class.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_duceapp_wechat
{
	public static $usabled;
	public static $tmplsend;

	public function common() {
		if (defined('IN_MOBILE_API')) {
			return;
		}
		global $_G;
		
		define('DUCEAPP_WECHAT', true);
		define('DUCEAPP_WECHATBROWSE', stripos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
		include_once libfile('function/duceapp_core', 'plugin/duceapp_wechat');
		include_once template('duceapp_wechat:module');

		duceapp_wechat_initialize();

		C::m('#duceapp_base#duceapp_synlogin')->apply();

		self::$usabled = $_G['cache']['duceapp_wechat']['enable'];
		self::$tmplsend = $_G['cache']['duceapp_wechat']['mtype'] == 1 && $_G['cache']['duceapp_wechat']['tmplsend'];

		if (DUCEAPP_WECHATBROWSE && self::$usabled && (!$_G['uid'] || $_GET['action'] == 'logout')) {
			if (empty($_G['inajax']) || $_GET['action'] == 'logout') {
				duceapp_wechat_docompon('onekey');
			}
		}
		
		if ($_G['uid'] && self::$usabled) {
			$_G['duceapp_wechatuser'] = self::_getuser($_G['uid']);
			if ($_G['duceapp_wechatuser']) {
				if (!$_G['duceapp_wechatuser']['status']) {
					$_G['duceapp_wechatuser']['isregister'] = 1;
				} elseif($_G['duceapp_wechatuser']['status'] == 1) {
					C::t('#duceapp_wechat#duceapp_wechat_member')->update($_G['uid'], array('status' => 0));
					include_once libfile('function/member');
					clearcookies();
				}
				if ($_G['cache']['duceapp_wechat']['unnewbiespan']){
					$_G['setting']['newbiespan'] = 0;
				}
			} else {
				if (CURSCRIPT == 'home' && CURMODULE == 'spacecp' && 
					$_G['cache']['duceapp_wechat']['unnewbiespan'] && 
					$_G['setting']['newbiespan'] && $_G['timestamp'] - $_G['member']['regdate'] < $_G['setting']['newbiespan']*60) {
					C::m('#duceapp_base#duceapp_helper')->messagefunc('home', CURMODULE.'_'.$_GET['ac'], 'duceapp_wechat', '_newbiespan');
				}
			}
		}

		if (!self::$usabled) {			
			unset($_G['setting']['plugins']['spacecp']['duceapp_wechat:spacecp']);
		}
	}

	public function deletemember($param) {
		$uids = $param['param'][0];
		if ($param['step'] == 'delete' && $uids && is_array($uids)) {
			foreach($uids as $uid) {
				C::t('#duceapp_wechat#duceapp_wechat_member')->delete($uid);
			}
		}
	}

	public function global_login_extra() {
		global $_G;
		if(!self::$usabled || defined('IN_MOBILE') || $_G['inshowmessage'] || !empty($_GET['errcode'])) {
			return;
		}
		return duceapp_wechat_login_bar();
	}

	public function global_usernav_extra1() {
		global $_G;
		if(!self::$usabled || defined('IN_MOBILE') || $_G['duceapp_wechatuser'] || $_G['inshowmessage'] || !$_G['uid']) {
			return;
		}
		return duceapp_wechat_user_bar();
	}

	public static function _getuser($uid) {
		return $uid ? C::t('#duceapp_wechat#duceapp_wechat_member')->fetch($uid) : null;
	}

	public static function _tmplsend($action) {
		global $_G;
		if (self::$tmplsend && $_G['cache']['duceapp_wechat']['tmplsend'][$action]['available']) {
			duceapp_wechat_docompon('tmplsend', $action);
		}
	}

	public static function _newbiespan($params) {
		global $_G;
		if ($_G['cache']['duceapp_wechat']['unnewbiespan']) {
			if ($params && $params['param'][0] == 'no_privilege_newbiespan') {
				showmessage('duceapp_wechat:no_privilege_newbiespan', '', array(
					'newbiespan' => $_G['setting']['newbiespan'], 
					'wechatbind' => duceapp_wechat_user_textbind()
				), array());
			}
		}
	}

	public static function _forcelogin($groupid) {
		global $_G;
		if ($groupid && @in_array($groupid, $_G['cache']['duceapp_wechat']['forcelogin'])) {
			showmessage('duceapp_wechat:wechat_forcelogin');
		}
	}
}

class plugin_duceapp_wechat_forum extends plugin_duceapp_wechat
{
	public function misc_message($params) {
		try{self::$tmplsend && C::m('#duceapp_wechat#duceapp_tmplsend')->forum_misc($params);}catch(Exception $e){}
	}

	public function post() {
		global $_G;
		if (!self::$usabled || empty($_G['uid']) || !$_G['cache']['duceapp_wechat']['poststatus'] || in_array($_G['group']['radminid'], array(1,2,3))) {
			return;
		}
		if ($_G['cache']['duceapp_wechat']['permfids'] == -1 || @in_array($_G['fid'], $_G['cache']['duceapp_wechat']['permfids'])) {
			if ($_G['cache']['duceapp_wechat']['poststatus'] == 1 && empty($_G['duceapp_wechatuser'])) {
				showmessage('duceapp_wechat:wechat_nopermission_1', NULL, array('bindtext' => duceapp_wechat_user_textbind()));
			}
			if ($_G['cache']['duceapp_wechat']['poststatus'] == 2 && empty($_G['duceapp_wechatuser']['subscribe'])) {				
				if (!empty($_G['duceapp_wechatuser'])) {
					$values = array('qrcode' => $_G['cache']['duceapp_wechat']['qrcode'] ? '<div class="mt10"><img src="'.$_G['siteurl'].'data/duceapp/wechat/'.$_G['cache']['duceapp_wechat']['qrcode'].'" style="width:180px;height:180px;" border="0"></div>' : '');
					$message = 'wechat_nopermission_2';
				} else {
					$values = array('bindtext' => duceapp_wechat_user_textbind(1));
					$message = 'wechat_nopermission_1';
				}
				showmessage('duceapp_wechat:'.$message, NULL, $values);
			}
		}
	}

	public function post_message($params) {
		self::_newbiespan($params);
		try{self::$tmplsend && C::m('#duceapp_wechat#duceapp_tmplsend')->forum_post($params);}catch(Exception $e){}
	}

	public function topicadmin_message($params) {
		try{self::$tmplsend && C::m('#duceapp_wechat#duceapp_tmplsend')->forum_topicadmin($params);}catch(Exception $e){}
	}
}

class plugin_duceapp_wechat_member extends plugin_duceapp_wechat
{
	public function logging_method() {
		if (!self::$usabled) {
			return;
		}
		global $_G;
		if ($_GET['loginsubmit'] && !$_G['uid'] && !defined('DUCEAPP_VIP') && $_G['cache']['duceapp_wechat']['forcelogin']) {
			if (!empty($_GET['auth'])) {
				list($_GET['username'], $_GET['password']) = daddslashes(explode("\t", authcode($_GET['auth'], 'DECODE', $_G['config']['security']['authkey'])));
			}
			if ($_GET['username'] && $_GET['password']) {
				$result = userlogin($_GET['username'], $_GET['password'], $_GET['questionid'], $_GET['answer'], $_G['setting']['autoidselect'] ? 'auto' : $_GET['loginfield'], $_G['clientip']);
				if ($result['status'] > 0 && !in_array($result['member']['adminid'], array(1,2,3))) {
					$this->_forcelogin($result['member']['groupid']);
				}
			}
		}
		return duceapp_wechat_login_method();
	}

	public function register_logging_method() {
		if (!self::$usabled) {
			return;
		}
		return duceapp_wechat_login_method();
	}

	public function logging_succeed_message($params) {
		global $_G;
		$message = $params['param'][0];
		if (($logined = strpos($message, 'login_succeed') !== false) && !$_GET['wxlogin'] && !$_G['duceapp_discuzuid']) {
			$this->_tmplsend('logon');
		}
		if ($logined || strpos($message, 'logout_succeed') !== false) {
			C::m('#duceapp_base#duceapp_synlogin')->activate();
		}
	}
}

class plugin_duceapp_wechat_home extends plugin_duceapp_wechat
{
	public function spacecp_friend_message($params) {
		try{
			self::$tmplsend && C::m('#duceapp_wechat#duceapp_tmplsend')->spacecp_friend($params);
		}catch(Exception $e){}
	}
	
	public function spacecp_pm_message($params) {
		try{
			self::$tmplsend && C::m('#duceapp_wechat#duceapp_tmplsend')->spacecp_pm($params);
		}catch(Exception $e){}
	}

	public function spacecp_profile() {
		global $_G;
		if ($_GET['op'] == 'password' && $_G['duceapp_wechatuser'] && $_G['duceapp_wechatuser']['isregister'] == 1) {
			$redirect = 'home.php?mod=spacecp&ac=plugin&id=duceapp_wechat:spacecp&d=security&from='.($_GET['from'] ? $_GET['from'] : 'spacecp');
			if ($_G['inajax']) {
				showmessage('', $redirect, array(), array('location' => true));
			} else {
				dheader('location:'.$redirect);
			}
		}
	}
}

class plugin_duceapp_wechat_misc extends plugin_duceapp_wechat
{
	public function invite_message($params) {
		try{self::$tmplsend && C::m('#duceapp_wechat#duceapp_tmplsend')->misc_invite($params);}catch(Exception $e){}
	}
}

class mobileplugin_duceapp_wechat extends plugin_duceapp_wechat
{
	public function global_footer_mobile() {		
		if (!self::$usabled || DUCEAPP_WECHATBROWSE === FALSE) {
			return;
		}
		duceapp_wechat_docompon('share');
	}
}

class mobileplugin_duceapp_wechat_forum extends plugin_duceapp_wechat_forum{}

class mobileplugin_duceapp_wechat_member extends mobileplugin_duceapp_wechat
{
	public function logging_bottom_mobile_output() {
		global $_G;
		$disinwechat = $_G['cache']['duceapp_wechat']['logintpl']['disinwechat'] && DUCEAPP_WECHATBROWSE === FALSE;
		if(!self::$usabled || $_G['cache']['duceapp_wechat']['logintpl']['hidemobilebtn'] || $disinwechat) {
			return;
		}
		return duceapp_wechat_login_bottom();
	}

	public function logging_succeed_message($params) {
		global $_G;
		$message = $params['param'][0];
		if (($logined = strpos($message, 'login_succeed') !== false) && !$_GET['wxlogin'] && !$_G['duceapp_discuzuid']) {
			$this->_tmplsend('logon');
		}
		if ($logined || strpos($message, 'logout_succeed') !== false) {
			C::m('#duceapp_base#duceapp_synlogin')->activate();
		}
	}

	public function register_logging_method_mobile_output() {
		return $this->logging_bottom_mobile_output();
	}
}

class mobileplugin_duceapp_wechat_home extends plugin_duceapp_wechat_home
{
	public function spacecp_plugin() {
		if (!defined('IN_DUCEAPP') && $_GET['id'] == 'duceapp_wechat:spacecp') {
			global $_G;
			$navtitle = $_G['setting']['plugins']['spacecp'][$_GET['id']]['name'];
			$_GET['id'] = $_GET['id'] ? preg_replace("/[^A-Za-z0-9_:]/", '', $_GET['id']) : '';
			include pluginmodule($_GET['id'], 'spacecp');
			include template('duceapp_wechat:spacecp');
			exit;
		}
	}
}

class mobileplugin_duceapp_wechat_misc extends plugin_duceapp_wechat_misc{}