<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90622
 * Date: 2020-08-06 03:25:46
 * File: resource.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if (!defined('DUCEAPP_ADMINCP')) {
	dheader("Location:".ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&pmod=setting&danchor=resource');
}

define('RSELF', $this->redirect.'&danchor='.$this->danchor.($_GET['from'] ? '&from='.$_GET['from'] : '').'&op=');
$op = !empty($_GET['op']) ? $_GET['op'] : '';
$filter = isset($_GET['filter']) ? intval($_GET['filter']) : -1;
$pna[$filter] = ' resource_pna';
$iconvdata = $filter == 2 && strtolower(CHARSET) != 'utf-8' ? true : false;
define('DESCMAXLEN', strtolower(CHARSET) == 'utf-8' ? 162 : 108);

if ($this->cpmethod != 'save') {

	duceapp_headscript('admin_resource');

	if (!$op) {

		$ppp = 9;
		$page = max(1, $_GET['page']);
		$start = ($page - 1) * $ppp;
		$count = C::t('#duceapp_wechat#duceapp_wechat_resource')->count_by_type($filter >= 0 ? $filter : null);
		$resource = C::t('#duceapp_wechat#duceapp_wechat_resource')->fetch_by_type($filter >= 0 ? $filter : null, $start, $ppp);
		$multi = multi($count, $ppp, $page, $this->redirect.'&danchor='.$this->danchor.'&filter='.$filter);
		
		duceapp_formheader();

		echo '<div class="wechat_resource cl" id="wechat_resource">';
		
		foreach($resource as $row) {
			if (!$row['type']) {
				echo '<div class="resource_item">
					<ul class="resource_single">
						<li>
							<div class="pic"'.($row['data']['pic'] ? '' : ' style="display:none;"').'>'.($row['data']['pic'] ? '<img data-src="'.$row['data']['pic'].'" src="'.STATICURL.'image/common/none.gif" />' : '').'</div>
							<div class="desktop">
								<div class="title">'.dhtmlspecialchars($row['data']['title']).'</div>
								<div class="desc">'.($row['data']['desc'] ? dhtmlspecialchars($row['data']['desc']) : cutstr(strip_tags($row['data']['content']), DESCMAXLEN)).'</div>
							</div>
						</li>
					</ul>
					<div class="partition">
						<div class="b cl"><label><a href="'.RSELF.'edit&id='.$row['id'].'">'.cplang('edit').'</a></label><label onclick="resource_del(this)" r="'.duceapp_cplang('recovery').'" d="'.cplang('delete').'"><span>'.cplang('delete').'</span></label><input type="checkbox" name="delete[]" value="'.$row['id'].'" style="display:none;">'.dgmdate($row['dateline']).'</div>
					</div>
				</div>';
			} else {
				$mergeids = array_values($row['data']['mergeids']);
				$mergedata = C::t('#duceapp_wechat#duceapp_wechat_resource')->fetch_all($mergeids);
				$resourcemerge = array();
				foreach($mergeids as $id){
					if ($mergedata[$id]) {
						$resourcemerge[] = $mergedata[$id];
					}
				}
				$i = 0;
				echo '<div class="resource_item">
					<ul class="resource_merge">';
				foreach($resourcemerge as $merge) {
					echo '<li class="e'.(!$i ? ' fst' : '').'">
							<div class="pic"'.($merge['data']['pic'] ? '' : ' style="display:none;"').'>'.($merge['data']['pic'] ? '<img data-src="'.$merge['data']['pic'].'" src="'.STATICURL.'image/common/none.gif" />' : '').'</div>
							<div class="desktop">
								<div class="title">'.dhtmlspecialchars($merge['data']['title']).'</div>
								<div class="desc">'.($merge['data']['desc'] ? dhtmlspecialchars($merge['data']['desc']) : cutstr(strip_tags($merge['data']['content']), DESCMAXLEN)).'</div>
							</div>
						</li>';
					$i++;
				}
				echo '</ul>
					<div class="partition">
						<div class="b cl"><label><a href="'.RSELF.'edit&id='.$row['id'].'">'.cplang('edit').'</a></label><label onclick="resource_del(this)" r="'.duceapp_cplang('recovery').'" d="'.cplang('delete').'"><span>'.cplang('delete').'</span></label><input type="checkbox" name="delete[]" value="'.$row['id'].'" style="display:none;">'.dgmdate($row['dateline']).' &nbsp;&nbsp; '.duceapp_cplang('resource_totals', array('num'=>count($resourcemerge))).'</div>
					</div>
				</div>';
			}
		}
		echo '<div class="resource_item resource_newadd"><a href="'.RSELF.'add"><span>+</span>'.duceapp_cplang('resource_add').'</a></div></div>';
		echo '<div style="clear:both;height:1px;overflow:hidden;"></div>
			<div class="right pg">'.$multi.'</div>
			<input class="btn leftbtn" type="submit" name="duceapp_submit" value="'.cplang('submit').'">
			<a href="'.RSELF.'add" class="resource_pn resource_pne">+'.duceapp_cplang('resource_add').'</a><a href="'.RSELF.'" class="resource_pn'.$pna['-1'].'">'.duceapp_cplang('resource_all').'</a><a href="'.RSELF.'&filter=0" class="resource_pn'.$pna['0'].'">'.duceapp_cplang('resource_stand').'</a><a href="'.RSELF.'&filter=1" class="resource_pn'.$pna['1'].'">'.duceapp_cplang('resource_list').'</a>
			<script type="text/javascript" reload="1">duceapp_imgzoom("wechat_resource")</script>';
		showformfooter();/*dism��taobao��com*/

	} elseif ($op == 'select') {

		include template('common/header_ajax');
		
		if ($_GET['frompmod'] == 'compon') {
			$comkey = $_GET['cmod'];
			$appid = $this->setting[$comkey]['appid'];
			$appsecret = $this->setting[$comkey]['appsecret'];
			$mp = $appid && $appsecret;
			$urlext = '&frompmod=compon&cmod='.$comkey;
		} else {
			$appid = $this->setting['mp']['appid'];
			$appsecret = $this->setting['mp']['appsecret'];
			$mp = $this->setting['mp'];
			$urlext = '';
		}
		if (empty($_GET['id'])){
			$ppp = 6;
			$page = max(1, $_GET['page']);
			$start = ($page - 1) * $ppp;

			if ($filter == 2) {
				if (!$mp) {
					duceapp_error('wechat_menu_at_error');
				}				
				require_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');
				$wechat_client = new duceapp_wechatclient($appid, $appsecret);
				$res = $wechat_client->getNews($start, $ppp);
				$count = $res['total_count'];
				$resource = array();
				$i = 0;
				foreach($res['item'] as $item) {
					$resource[$i] = array(
						'id' => $item['media_id'],
						'media_id' => $item['media_id'],
						'dateline' => $item['update_time'],
						'mergedata' => array()
					);				
					foreach($item['content']['news_item'] as $news){
						$resource[$i]['mergedata'][] = array(
							'data' => array(
								'title' => $news['title'],
								'desc' => $news['digest'],
								'content' => strip_tags($news['content']),
								'pic' => $this->getNewsImage($news),
								'url' => $news['url']
							)
						);					
					}
					if (count($resource[$i]['mergedata']) > 1) {
						$resource[$i]['type'] = 1;
					} else {
						$resource[$i]['data'] = $resource[$i]['mergedata'][0]['data'];
						unset($resource[$i]['mergedata']);
					}
					$i++;
				}
			} else {
				$count = C::t('#duceapp_wechat#duceapp_wechat_resource')->count_by_type($filter >= 0 ? $filter : null);
				$resource = C::t('#duceapp_wechat#duceapp_wechat_resource')->fetch_by_type($filter >= 0 ? $filter : null, $start, $ppp);
			}
			$multi = multi($count, $ppp, $page, RSELF.'select&filter='.$filter.'&inner='.$_GET['inner'].$urlext);
			
			echo '<div class="wechat_resource cl" id="wechat_resource" style="margin:0;padding-right:0;">';
		} else {
			if ($filter == 2) {
				$resource = $this->getNewsByid($_GET['id'], false, $appid, $appsecret);
			} else {
				$resource = array(C::t('#duceapp_wechat#duceapp_wechat_resource')->fetch($_GET['id']));
			}
		}

		foreach($resource as $row) {			
			if (empty($_GET['id'])){
				$event = 'onclick="resource_sel'.($_GET['inner'] ? 'txt' : '').'(this, \''.$row['id'].'\', \''.$row['name'].'\','.intval($filter).')" onmouseover="duceapp_addclass(this, \'resource_hover\')" onmouseout="duceapp_removeclass(this, \'resource_hover\')"';
			}
			if (!$row['type']) {
				if (empty($_GET['id'])){
					echo '<div class="resource_item" style="height:278px;cursor:pointer;"><ul class="resource_single" style="height:278px;" '.$event.'>';
				}
				$title = $iconvdata ? diconv($row['data']['title'], 'UTF-8', CHARSET) : $row['data']['title'];
				$desc = $iconvdata ? diconv($row['data']['desc'], 'UTF-8', CHARSET) : $row['data']['desc'];
				$content = $iconvdata ? diconv($row['data']['content'], 'UTF-8', CHARSET) : $row['data']['content'];
				$row['data'] = dhtmlspecialchars($row['data']);
				echo '<li class="e">
						<div class="pic" id="resource_pic_'.$row['id'].'"'.($row['data']['pic'] ? '' : ' style="display:none;"').'>'.($row['data']['pic'] ? '<img data-src="'.$row['data']['pic'].'" src="'.STATICURL.'image/common/none.gif" />' : '').'</div>
						<div class="desktop">
							<div class="title" id="editor_title_html_'.$row['id'].'">'.$title.'</div>
							<div class="desc" id="editor_desc_html_'.$row['id'].'">'.($desc ? $desc : cutstr(strip_tags($content), DESCMAXLEN)).'</div>
						</div>';
				if ($_GET['from'] != 'menu') {
					echo '<input type="hidden" name="resource[]" value="'.$row['id'].'">
					<input type="hidden" name="data['.$row['id'].'][title]" id="editor_title_'.$row['id'].'" value="'.str_replace('"', '\"', $row['data']['title']).'">
					<input type="hidden" name="data['.$row['id'].'][pic]" id="editor_pic_'.$row['id'].'" value="'.$row['data']['pic'].'">
					<input type="hidden" name="picdata_'.$row['id'].($row['data']['pic'] ? '_temp' : '').'" id="editor_picdata_'.$row['id'].'" value="">
					<input type="hidden" name="data['.$row['id'].'][desc]" id="editor_desc_'.$row['id'].'" value="'.str_replace('"', '\"', $row['data']['desc']).'">
					<input type="hidden" name="data['.$row['id'].'][content]" id="editor_content_'.$row['id'].'" value="'.str_replace('"', '\"', $row['data']['content']).'">
					<input type="hidden" name="data['.$row['id'].'][author]" id="editor_author_'.$row['id'].'" value="'.$row['data']['author'].'">
					<input type="hidden" name="data['.$row['id'].'][url]" id="editor_url_'.$row['id'].'" value="'.$row['data']['url'].'">
					<div class="resource_mask"><strong>'.duceapp_cplang('drag').'</strong><em class="_del">'.duceapp_cplang('remove').'</em></div>
					';
				}
				echo '</li>';
				if ($_GET['from'] == 'menu') {
					echo '<dl class="resource_mask"><a href="javascript:;" onclick="resource_del(this)">'.cplang('delete').'</a></dl>';
				}
				if (empty($_GET['id'])){
					echo '</ul></div>';
				}
			} else {
				if ($row['mergedata']) {
					$resourcemerge = $row['mergedata'];
				} else {
					$mergeids = array_values($row['data']['mergeids']);
					$mergedata = C::t('#duceapp_wechat#duceapp_wechat_resource')->fetch_all($mergeids);
					$resourcemerge = array();
					foreach($mergeids as $id){
						if ($mergedata[$id]) {
							$resourcemerge[] = $mergedata[$id];
						}
					}
				}
				if (empty($_GET['id'])){
					echo '<div class="resource_item" style="height:278px;cursor:pointer;"><ul class="resource_merge" style="height:278px;" '.$event.'>';
				}
				$i = 0;
				foreach($resourcemerge as $merge) {
					$title = $iconvdata ? diconv($merge['data']['title'], 'UTF-8', CHARSET) : $merge['data']['title'];
					$desc = $iconvdata ? diconv($merge['data']['desc'], 'UTF-8', CHARSET) : $merge['data']['desc'];
					$content = $iconvdata ? diconv($merge['data']['content'], 'UTF-8', CHARSET) : $merge['data']['content'];
					$merge['data'] = dhtmlspecialchars($merge['data']);
					echo '<li class="e'.(!$i ? ' fst' : '').'">
							<div class="pic"'.($merge['data']['pic'] ? '' : ' style="display:none;"').'>'.($merge['data']['pic'] ? '<img data-src="'.$merge['data']['pic'].'" src="'.STATICURL.'image/common/none.gif" />' : '').'</div>
							<div class="desktop">
								<div class="title">'.$title.'</div>
								<div class="desc">'.($desc ? $desc : cutstr(strip_tags($content), DESCMAXLEN)).'</div>
							</div>
						</li>';
					$i++;
				}
				echo '<dl class="resource_mask">'.($i > 3 ? '<span>'.duceapp_cplang('resource_totals', array('num'=>$i)).'</span>' : '').($_GET['from'] == 'menu' ? '<a href="javascript:;" onclick="resource_del(this)">'.cplang('delete').'</a>' : '').'</dl>';
				if (empty($_GET['id'])){
					echo '</ul></div>';
				}
			}
		}

		if (empty($_GET['id'])){
			echo '</div>';
			echo '<div style="clear:both;height:1px;overflow:hidden;"></div>			
			<div class="right">'.$multi.'</div>';
			/*if ($filter == 2) {
				echo '<div class="left" style="position:absolute;top:9px;left:90px;"><form action="'.RSELF.'select&filter='.$filter.'&inner='.$_GET['inner'].$urlext.'" onsubmit="_ajaxpost(this.id, \'rsel_content\')" id="resourcesrch" target="rsel_content"><input type="text" class="txt left" name="nameword" value="'.dhtmlspecialchars($_GET['nameword']).'"><button type="submit" class="btn left" name="srchresource" style="margin:0 0 0 6px;">'.cplang('search').'</button></form></div>';
			}*/
			if ($_GET['from'] == 'menu' && $filter != 2) {
				echo '<div class="left resource_pns"><a href="'.RSELF.'select" class="resource_pn'.$pna['-1'].'" ajaxtarget="rsel_content">'.duceapp_cplang('resource_all').'</a><a href="'.RSELF.'select&filter=0" class="resource_pn'.$pna['0'].'" ajaxtarget="rsel_content">'.duceapp_cplang('resource_stand').'</a><a href="'.RSELF.'select&filter=1" class="resource_pn'.$pna['1'].'" ajaxtarget="rsel_content">'.duceapp_cplang('resource_list').'</a></div>';
			}
			echo '<script type="text/javascript" reload="1">duceapp_imgzoom("wechat_resource")</script>';
		}

		include template('common/footer_ajax');

	} elseif($op == 'edit' || $op == 'add') {

		duceapp_headscript('wechat_editor', 'admin_editor');
		duceapp_formheader('enctype');

		if ($op == 'edit'){
			$res = C::t('#duceapp_wechat#duceapp_wechat_resource')->fetch($_GET['id']);
			if(!$res) {
				duceapp_error('resource_msg_nofound');
			}
			showhiddenfields(array('id' => $_GET['id']));
		} else {
			$res = array(
				'id' => 'r0',
				'type' => 0,
				'data' => array(
					'title' => duceapp_cplang('resource_title'),
					'desc' => duceapp_cplang('resource_desc'),
				),
			);
		}

		if (!$res['type']) {
			$resource = array($res);
			$num = 1;
		} else {
			$mergeids = array_values($res['data']['mergeids']);
			if (!$mergeids) {
				duceapp_error('resource_msg_nofound');
			}
			$mergedata = C::t('#duceapp_wechat#duceapp_wechat_resource')->fetch_all($mergeids);
			$num = count($mergedata);
			$resource = array();
			foreach($mergeids as $id){
				if ($mergedata[$id]) {
					$resource[] = $mergedata[$id];
				}
			}
		}
		$mains = $previews = '';
		$i = 0;
		$rsid = null;
		$curr = array();
		foreach($resource as $j => $row) {
			if ($rsid === null) {
				$rsid = $row['id'];
				$curr = $row;
			}
			$previews .= resource_main($row['id'], $row, $i, true, $num);
			$i++;
		}

		duceapp_headscript('sortable');
		@include duceapp_language('editor');

		echo '
		<script type="text/JavaScript">
		var CHARSET = "'.CHARSET.'";
		var rsid = "'.$rsid.'";
		var extrahtml = {editor_title:"'.duceapp_cplang('resource_title').'", editor_desc:"'.duceapp_cplang('resource_desc').'", nolocfile:"'.$duceapp_editor['nolocfile'].'"};
		</script>
		<div class="wechat_resource"><table width="100%">
			<tr><td style="width:320px;" class="vtop">
				<div class="resource_preview">
					<div class="cl">
						<ul id="resource_preview" class="'.($num > 1 ? 'resource_merge' : 'resource_single').'">
							'.$previews.'
						</ul>
					</div>
					<div id="resource_add" class="resource_add"'.($num >= 8 ? ' style="display:none"' : '').'>
						<span class="a" onclick="resource_showlist(false, 0)">'.duceapp_cplang('menu_button_selresource').'</span> <span class="a" onclick="resource_add()">'.duceapp_cplang('resource_add').'</span>
					</div>
				</div>
			</td><td class="vtop">
				<div id="resource_main">'.resource_main($rsid, $curr).'</div>
				<div class="resource_btns cl"><input class="btn" type="submit" name="'.$op.'submit" value="'.cplang('submit').'"></div>
			</td></tr>
		</table></div>';
		showformfooter();/*dism��taobao��com*/
		echo '<script type="text/JavaScript">resource_sort();duceapp_imgzoom("resource_preview");duceapp_imgzoom("editor_imgbox");</script>';
		$this->showResource();
	}

} else {

	if (submitcheck('editsubmit') || submitcheck('addsubmit')) {

		if (submitcheck('editsubmit')) {
			$resource = C::t('#duceapp_wechat#duceapp_wechat_resource')->fetch($_GET['id']);
			if (!$resource) {
				duceapp_error('resource_msg_nofound');
			}
		} else {
			$resource = array();
		}

		if ($_GET['resource']) {
			$updatedata = $pics = array();
			$mergename = '';
			foreach($_GET['resource'] as $id) {
				$data = $_GET['data'][$id];
				$data['desc'] = trim($data['desc']);
				if (dstrlen($data['desc'], CHARSET) > DESCMAXLEN) {
					$data['desc'] = cutstr(strip_tags($data['desc']), DESCMAXLEN);
				}
				if (!$data['desc'] && $data['content']) {
					$data['desc'] = cutstr(strip_tags(trim($data['content'])), DESCMAXLEN);
				}
				$data['title'] = trim($data['title']);
				if (!$data['title']) {
					continue;
				}				
				if (isset($_GET['picdata_'.$id])) {
					$upload = new discuz_upload();
					$error = '';
					if ($_GET['picdata_'.$id] && !preg_match('/data:image/i', $_GET['picdata_'.$id])) {
						$error = 'resource_upload_imageerr';
					}
					if ($error || !getimagesize($_FILES['pic_'.$id]['tmp_name']) || !$upload->init($_FILES['pic_'.$id], 'common', random(3, 1), random(8)) || !$upload->save()) {
						if ($pics) {
							foreach($pics as $pic){
								@unlink($_G['setting']['attachdir'].'common/'.$pic);
							}
						}
						duceapp_error($error ? $error : $upload->errormessage());
					}
					$data['pic'] = $_G['siteurl'].$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
					$data['local'] = $upload->attach['attachment'];
					$pics[] = $data['local'];
					if (substr($id, 0, 1) != 'r') {
						@unlink($_G['setting']['attachdir'].'common/'.$resource['data']['local']);
					}
				} else {
					$data['pic'] = trim($data['pic']);
				}
				$data['url'] = trim($data['url']);// ? urldecode($data['url']) : trim($data['url']);
				if (!$mergename) {
					$mergename = $data['title'];
				}
				$updatedata[$id] = array('name' => $data['title'], 'dateline' => time(), 'data' => $data);
			}
			$mergeids = array();
			$listnum = 0;
			foreach ($updatedata as $id => $data){
				if (substr($id, 0, 1) == 'r') {
					$id = C::t('#duceapp_wechat#duceapp_wechat_resource')->insert($data, true);
				} else {
					C::t('#duceapp_wechat#duceapp_wechat_resource')->update($id, $data);
				}
				if ($listnum < 8) {
					$mergeids[$id] = $id;
				}
				$listnum++;
			}
			if (count($mergeids) > 1) {
				$data = array(
					'name' => $mergename,
					'type' => 1,
					'dateline' => time(),
					'data' => array('mergeids' => $mergeids)
				);
				if (!$resource['type']){				
					C::t('#duceapp_wechat#duceapp_wechat_resource')->insert($data);
				} else {
					C::t('#duceapp_wechat#duceapp_wechat_resource')->update($resource['id'], $data);
				}
			} elseif ($resource['type']) {
				C::t('#duceapp_wechat#duceapp_wechat_resource')->delete($resource['id']);
			}
		} else {
			duceapp_error('resource_msg_nofound');
		}
	} else {
		if ($_GET['delete']) {
			foreach ($_GET['delete'] as $id) {
				if (intval($id)) {
					C::t('#duceapp_wechat#duceapp_wechat_resource')->delete(intval($id));
				}
			}
		}
	}

}

function resource_main($id = 'r0', $row = array(), $display = true, $preview = false, $num = 1){
	global $_G, $lang, $plang, $duceapp_editor;
	if (!$plang) {
		$plang = $_G['cache']['pluginlanguage_script']['duceapp_wechat'];
	}
	$title = $row['data']['title'];
	$content = $row['data']['content'];
	$desc = $row['data']['desc'] ? $row['data']['desc'] : cutstr(strip_tags($content), DESCMAXLEN);
	$data = $row['id'] == 'r0' ? array() : dhtmlspecialchars($row['data']);
	//$data['url'] = $data['url'] ? urlencode($data['url']) : $data['url'];
	if (!$row['data']['pic']) {
		$pichide = ' style="display:none"';
		$a = ' a';
	} else {
		$filehide = ' style="display:none"';
		$b = ' a';		
	}
	$pic = $data['pic'] ? '<img data-src="'.$data['pic'].'" src="'.STATICURL.'image/common/none.gif" />' : '';
	if ($preview) {
		return '<li id="preview_'.$id.'" onclick="resource_showset(this, \''.$id.'\')" class="e'.(!$display ? ' a'.($num > 1 ? ' fst' : '') : '').'" onmouseover="duceapp_addclass(this,\'resource_hover\')" onmouseout="duceapp_removeclass(this,\'resource_hover\')">
			<div class="pic" id="resource_pic_'.$id.'"'.$pichide.'>'.$pic.'</div>
			<div class="desktop">
				<div class="title" id="editor_title_html_'.$id.'" holder="$plang[resource_title]">'.$title.'</div>
				<div class="desc" id="editor_desc_html_'.$id.'" holder="$plang[resource_desc]">'.$desc.'</div>
			</div>
			<div class="resource_mask"><strong>'.$plang['drag'].'</strong><em class="_del">'.$plang['remove'].'</em></div>
			<input type="hidden" name="resource[]" value="'.$id.'">
			<input type="hidden" name="data['.$id.'][title]" id="editor_title_'.$id.'" value="'.$data['title'].'">
			<input type="hidden" name="data['.$id.'][pic]" id="editor_pic_'.$id.'" value="'.$data['pic'].'">
			<input type="hidden" name="picdata_'.$id.($data['pic'] ? '_temp' : '').'" id="editor_picdata_'.$id.'" value="">
			<input type="hidden" name="data['.$id.'][desc]" id="editor_desc_'.$id.'" value="'.$data['desc'].'">
			<input type="hidden" name="data['.$id.'][content]" id="editor_content_'.$id.'" value="'.$data['content'].'">
			<input type="hidden" name="data['.$id.'][author]" id="editor_author_'.$id.'" value="'.$data['author'].'">
			<input type="hidden" name="data['.$id.'][url]" id="editor_url_'.$id.'" value="'.$data['url'].'">
		</li>';
	}
	if ($duceapp_editor) {
		@include duceapp_language('editor');
	}
	//$editortoolbar = C::m('#duceapp_wechat#duceapp_editor')->toolbar(true);
	return <<<EOF
<div id="resource_preview_li" style="display:none;">
	<div class="pic" id="resource_pic_{vid}"></div>
	<div class="desktop">
		<div class="title" id="editor_title_html_{vid}" holder="$plang[resource_title]">$plang[resource_title]</div>
		<div class="desc" id="editor_desc_html_{vid}" holder="$plang[resource_desc]">$plang[resource_desc]</div>
	</div>
	<div class="resource_mask"><strong>$plang[drag]</strong><em class="_del">$plang[remove]</em></div>
	<input type="hidden" name="resource[]" value="{vid}">
	<input type="hidden" name="data[{vid}][title]" id="editor_title_{vid}" value="">
	<input type="hidden" name="data[{vid}][pic]" id="editor_pic_{vid}" value="">
	<input type="hidden" name="picdata_{vid}" id="editor_picdata_{vid}" value="">
	<input type="hidden" name="data[{vid}][desc]" id="editor_desc_{vid}" value="">
	<input type="hidden" name="data[{vid}][content]" id="editor_content_{vid}" value="">
	<input type="hidden" name="data[{vid}][author]" id="editor_author_{vid}" value="">
	<input type="hidden" name="data[{vid}][url]" id="editor_url_{vid}" value="">
</div>
<div class="resource_relbox">
	<div id="resource_arrow" class="resource_arrow"></div>
	<div class="resource_example">$duceapp_editor[example]</div>
</div>
{$editortoolbar}
<div class="resource_main">
	<div id="editor_wrap" class="editor_wrap">
		<div class="editor_top">
			<input id="editor_title" type="text" placeholder="$plang[resource_title_holder]" onfocus="hideMenu()" class="editor_input editor_title" value="$data[title]">
			<input id="editor_author" type="text" placeholder="$plang[resource_author_holder]" onfocus="hideMenu()" class="editor_input editor_author" value="$data[author]">
		</div>
		<div class="editor_area">
			<textarea id="editor_content" class="editor_input editor_textarea" onfocus="hideMenu()" placeholder="$plang[resource_content_holder]" style="display:none;">$data[content]</textarea>
		</div>
		<div class="editor_group">$plang[resource_pic_desc]</div>
		<div class="cl">
			<div id="editor_picbox" class="editor_picbox">
				<div class="editor_picbutton"><strong>$plang[resource_selpic]</strong></div>
				<div class="editor_imgbox" id="editor_imgbox">$pic</div>
			</div>
			<div id="editor_picbox_menu" class="editor_picbox_menu" style="display:none;">
				<div id="editor_file" class="editor_file" {$filehide}>
					<input type="text" value="$duceapp_editor[nolocfile]" id="editor_filepath" disabled="true" readonly>
					<span id="editor_picfilebox">$lang[switch_upload]<input id="picfile_$id" type="file" name="pic_$id" onchange="resource_viewpic(this)"></span>
				</div>
				<div id="editor_picurl" class="editor_picurl" {$pichide}>
					<input class="editor_input" type="text" id="editor_pic" value="$data[pic]">
				</div>
				<div class="editor_button cl">
					<span id="editor_file_btn" class="$a" href="javascript:;" onclick="resource_cutpic(this)">$plang[resource_upload]</span><span id="editor_picurl_btn" href="javascript:;" class="$b" onclick="resource_cutpic(this)">$plang[resource_pic_link]</span>
					<span class="closemenu" onclick="hideMenu()">close</span>
				</div>
			</div>
			<div class="editor_desc">
				<div><textarea class="editor_input" id="editor_desc" onfocus="hideMenu()" placeholder="$plang[resource_desc_holder]">$data[desc]</textarea></div>
			</div>
		</div>
		<div class="editor_url cl">
			<span>$plang[resource_url] &gt;</span>
			<input onfocus="hideMenu()" type="text" id="editor_url" class="editor_input" value="$data[url]">
		</div>
	</div>
</div>
EOF;
}