<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: menu.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if (!defined('DUCEAPP_ADMINCP')) {
	dheader("Location:".ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&pmod=setting&danchor=menu');
}

require_once libfile('function/duceapp_menu', 'plugin/duceapp_wechat');

if ($this->cpmethod != 'save') {

	$iconvdata = false;
	if ($_GET['synchr'] || !isset($this->setting['button'])) {
		require_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');
		$wechat_client = new duceapp_wechatclient($this->setting['mp']['appid'], $this->setting['mp']['appsecret']);
		$wechat_menu = $wechat_client->getMenu();
		$this->setting['button'] = $wechat_menu['menu']['button'];
		if (strtolower(CHARSET) != 'utf-8') {
			$iconvdata = true;
		}
	}

	duceapp_headscript('sortable');
	duceapp_headscript('admin_menu');
	
	duceapp_formheader();
	echo '
	<table width="100%">
		<tr>
		<td style="width:320px;" class="vtop">
			<div class="wechat_box">
				<div id="wechat" class="wechat_main cl">
					<div class="h"><div class="na"><strong>'.$_G['setting']['bbname'].'</strong></div></div>
					<div id="wechat_msg" class="wechat_msg"><ul>'.duceapp_cplang('wechat_menu_tips').'</ul></div>
					<div class="m cl">
						<span class="kwd"></span>';
	$i = 0;
	$menu = $submenu = $menuadd = $buttonsethtml = '';
	if ($this->setting['button']) {
		foreach($this->setting['button'] as $k => $button) {
			if ($i>=3) break;
			if ($iconvdata) {
				$button['name'] = diconv($button['name'], 'UTF-8', CHARSET);
			}
			$subcount = !empty($button['sub_button']) ? count($button['sub_button']) : 0;
			$menu .= '<li id="wechat_'.$k.'" onclick="wechat_showmn(this)" '.($subcount ? ' class="e a"' : ' class="e"').'><span><em>&nbsp;</em>'.$button['name'].'</span><input type="hidden" name="msort[]" value="'.$i.'"></li>';
			$submenu .= '<div id="wechat_'.$k.'_submenu" class="mns'.($subcount >= 5 ? '' : ($subcount ? ' mns_a' : ' mns_0')).'" style="margin-top:0;"><ul>';
			$j = 0;
			$button['keyurl'] = $button['keyurl'] ? $button['keyurl'] : ($button['key'] ? $button['key'] : $button['url']);
			if ($button['type'] == 'click' && $button['key']) {
				if (preg_match("/^\[resource=(\d+)\]/", $button['key'])) {
					$button['keyurl'] = '';
					$button['keyresource'] = $button['key'];
				} else {
					$button['keyurl'] = $button['key'];
				}
			}
			if ($button['type'] == 'media_id' && $button['media_id']) {
				$button['keymod'] = 1;
				$button['keyresource'] = '[media='.$button['media_id'].']';
			}
			$display = array('display:none;','display:none;','display:none;', '', '', 'display:none;');
			$checked = array();
			$checked[intval($button['keymod'])] = 'checked';
			$display[intval($button['keymod'])] = '';
			if ($button['keytype'] == 'miniprogram' || $button['type'] == 'miniprogram') {
				$checked[5] = 'checked';
				$display[5] = '';
			}
			$buttonsethtml .= duceapp_wechat_set($i, '['.$i.']', $button, $display, $checked, true);
			if ($subcount) {				
				foreach($button['sub_button'] as $sk => $sub_button) {
					if ($j>=5) break;
					if ($iconvdata) {
						$sub_button['name'] = diconv($sub_button['name'], 'UTF-8', CHARSET);
					}
					$submenu .= '<li id="wechat_'.$i.'_'.$j.'" onclick="wechat_showset(this,1)" class="e"><span>'.$sub_button['name'].'</span><input type="hidden" name="subsort['.$i.'][]" value="'.$j.'"></li>';
					$sub_button['keyurl'] = $sub_button['keyurl'] ? $sub_button['keyurl'] : ($sub_button['key'] ? $sub_button['key'] : $sub_button['url']);
					if ($sub_button['type'] == 'click' && $sub_button['key']) {
						if (preg_match("/^\[resource=(\d+)\]/", $sub_button['key'])) {
							$sub_button['keyurl'] = '';
							$sub_button['keyresource'] = $sub_button['key'];
						} else {
							$sub_button['keyurl'] = $sub_button['key'];
						}
					}
					if ($sub_button['type'] == 'media_id' && $sub_button['media_id']) {
						$sub_button['keymod'] = 1;
						$sub_button['keyresource'] = '[media='.$sub_button['media_id'].']';
					}
					$display = array('display:none;','display:none;','display:none;', '', '', 'display:none;');
					$checked = array();
					$checked[intval($sub_button['keymod'])] = 'checked';
					$display[intval($sub_button['keymod'])] = '';
					if ($sub_button['keytype'] == 'miniprogram' || $sub_button['type'] == 'miniprogram') {
						$checked[5] = 'checked';
						$display[5] = '';
					}
					$buttonsethtml .= duceapp_wechat_set($i.'_'.$j, '['.$i.'][sub_button]['.$j.']', $sub_button, $display, $checked, true);
					$j++;
				}
			}
			$submenu .= '</ul><div class="b" '.($j < 5 ? '' : 'style="display:none"').' onclick="wechat_add(this, [\'\',\''.duceapp_cplang('menu_button_subname').'\'], '.$i.')"><span>'.duceapp_cplang('menu_button_subname').'</span></div><em class="arow"></em></div>';
			$i++;
		}
	}
	echo '				<ul class="mn m'.($i).'" id="wechat_menu">
						'.$menu.'
						</ul>
						<div class="b" onclick="wechat_add(this, [\''.duceapp_cplang('menu_button_name').'\',\''.duceapp_cplang('menu_button_subname').'\'])"><span>'.($i < 1 ? '&nbsp;'.duceapp_cplang('menu_button_add') : '').'</span></div>
					</div>
					<div id="wechat_submenu">'.$submenu.'</div>
				</div>
			</div>
			<script type="text/JavaScript">wechat_sort();var delconfirmStr=\''.duceapp_cplang('menu_button_del_confirm').'\';</script>
		</td>
		<td class="vtop"><div class="wechat_setmain">
			<div id="wechat_menuset" a1="'.duceapp_cplang('menu_button').'" a2="'.duceapp_cplang('menu_button_sub').'" b1="'.duceapp_cplang('menu_button_name').'" b2="'.duceapp_cplang('menu_button_subname').'" c1="'.duceapp_cplang('menu_button_content').'" c2="'.duceapp_cplang('menu_button_subcontent').'">
			'.$buttonsethtml.'
			</div>
			<div class="wechat_btns"><input class="btn" type="submit" name="duceapp_submit" value="'.duceapp_cplang('menu_save').'"><input class="btn" type="submit" name="duceapp_pubsubmit" value="'.duceapp_cplang('menu_pub').'" style="margin-left:16px; background-position:0 -27px;"></div>
		</div></td>
		</tr>
	</table>';
	$this->showResource('menu');
	showformfooter();/*dism��taobao��com*/
	duceapp_wechat_set();

} else {

	$setting['button'] = & $this->setting['button'];

	if ($_GET['msort']) {
		$setting['button'] = array();
		foreach ($_GET['msort'] as $k) {
			if ($_GET['button'][$k]) {
				$button = array(
					'name' => trim($_GET['button'][$k]['name']),
					'keymod' => intval($_GET['button'][$k]['keymod']),
					'keyurl' => trim($_GET['button'][$k]['keyurl']),
					'keysel' => $_GET['button'][$k]['keysel'],
					'keyresource' => $_GET['button'][$k]['keyresource'],
					'keytype' => $_GET['button'][$k]['keytype'],
					'appid' => trim($_GET['button'][$k]['appid']),
					'pagepath' => trim($_GET['button'][$k]['pagepath']),
				);
				if ($_GET['subsort'][$k] && $_GET['button'][$k]['sub_button']) {
					foreach ($_GET['subsort'][$k] as $j) {
						$button['sub_button'][] = array(
							'name' => trim($_GET['button'][$k]['sub_button'][$j]['name']),
							'keymod' => intval($_GET['button'][$k]['sub_button'][$j]['keymod']),
							'keyurl' => trim($_GET['button'][$k]['sub_button'][$j]['keyurl']),
							'keysel' => $_GET['button'][$k]['sub_button'][$j]['keysel'],
							'keyresource' => $_GET['button'][$k]['sub_button'][$j]['keyresource'],
							'keytype' => $_GET['button'][$k]['sub_button'][$j]['keytype'],
							'appid' => trim($_GET['button'][$k]['sub_button'][$j]['appid']),
							'pagepath' => trim($_GET['button'][$k]['sub_button'][$j]['pagepath']),
						);
					}
				}
				$setting['button'][] = $button;
			}
		}
	}

	if (submitcheck('duceapp_pubsubmit')) {
		if (!$this->setting['mp']) {
			duceapp_error('wechat_menu_at_error');
		}
		if ($this->setting['api']) {
			duceapp_error('wechat_pubsave_invalid', array(), true);
		}
		if (!$setting['button']) {
			duceapp_error('menu_button_pub_error');
		}

		$url = ($this->setting['api'] ? $this->setting['apihost'] : $_G['siteurl']).$_G['duceapp_wechataccess'].'evt=';

		$pubmenu = array('button' => array());
		foreach($setting['button'] as $button) {
			if(!$button['sub_button']) {
				if(!$button['name']) {
					duceapp_error('menu_name_empty');
				}
				if ($button['keymod'] == 2){
					$button['keyurl'] = $url.($button['keysel'] ? $button['keysel'] : 'access');
				} elseif ($button['keymod'] == 1) {					
					if (preg_match("/^\[media=([^\]]+)\]/", $button['keyresource'], $r)){
						$button['keyurl'] = $r[1];
						$button['keytype'] = 'media_id';
					} else {
						$button['keyurl'] = $button['keyresource'];
					}
				}
				if(!$button['keyurl']) {
					duceapp_error('menu_keyurl_empty');
				}
				$parse = parse_url($button['keyurl']);
				if ($button['keytype'] == 'miniprogram') {
					if (!$parse['host'] || !$button['appid'] || !$button['pagepath']) {
						duceapp_error('menu_miniprogram_invalid');
					}
					$item = array(
						'type' => 'miniprogram',
						'name' => convertname($button['name']),
						'url' => $button['keyurl'],
						'appid' => $button['appid'],
						'pagepath' => $button['pagepath'],
					);
				} elseif ($button['keytype'] == 'media_id') {
					$item = array(
						'type' => 'media_id',
						'name' => convertname($button['name']),
						'media_id' => $button['keyurl'],
					);
				} else {
					$item = array(
						'type' => $parse['host'] ? 'view' : 'click',
						'name' => convertname($button['name']),
						$parse['host'] ? 'url' : 'key' => $button['keyurl']
					);
				}
				$pubmenu['button'][] = $item;
			} else {
				if(!$button['name']) {
					duceapp_error('menu_name_empty');
				}
				$sub_buttons = array();
				foreach($button['sub_button'] as $sub_button) {
					if(!$sub_button['name']) {
						duceapp_error('menu_name_empty');
					}
					if ($sub_button['keymod'] == 2){
						$sub_button['keyurl'] = $url.($sub_button['keysel'] ? $sub_button['keysel'] : 'access');
					} elseif ($sub_button['keymod'] == 1) {
						if (preg_match("/^\[media=([^\]]+)\]/", $sub_button['keyresource'], $r)){
							$sub_button['keyurl'] = $r[1];
							$sub_button['keytype'] = 'media_id';
						} else {
							$sub_button['keyurl'] = $sub_button['keyresource'];
						}
					}
					if (!$sub_button['keyurl']) {
						duceapp_error('menu_keyurl_empty');
					}
					$parse = parse_url($sub_button['keyurl']);
					if ($sub_button['keytype'] == 'miniprogram') {
						if (!$parse['host'] || !$sub_button['appid'] || !$sub_button['pagepath']) {
							duceapp_error('menu_miniprogram_invalid');
						}
						$item = array(
							'type' => 'miniprogram',
							'name' => convertname($sub_button['name']),
							'url' => $sub_button['keyurl'],
							'appid' => $sub_button['appid'],
							'pagepath' => $sub_button['pagepath'],
						);
					} elseif ($sub_button['keytype'] == 'media_id') {
						$item = array(
							'type' => 'media_id',
							'name' => convertname($sub_button['name']),
							'media_id' => $sub_button['keyurl'],
						);
					} else {
						$item = array(
							'type' => $parse['host'] ? 'view' : 'click',
							'name' => convertname($sub_button['name']),
							$parse['host'] ? 'url' : 'key' => $sub_button['keyurl']
						);
					}
					$sub_buttons[] = $item;
				}
				$item = array(
					'name' => convertname($button['name']),
					'sub_button' => $sub_buttons
				);
				$pubmenu['button'][] = $item;
			}			
		}

		require_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');
		$wechat_client = new duceapp_wechatclient($this->setting['mp']['appid'], $this->setting['mp']['appsecret']);
		if ($wechat_client->setMenu($pubmenu)) {
			duceapp_succeed('menu_pub_succeed');
		} else {
			duceapp_error('menu_pub_error', array('errno' => $wechat_client->error()), true);
		}
	}	
}