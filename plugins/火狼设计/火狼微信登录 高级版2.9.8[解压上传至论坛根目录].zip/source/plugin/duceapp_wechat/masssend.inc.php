<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.91119
 * Date: 2020-08-06 03:25:46
 * File: masssend.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if (!defined('DUCEAPP_ADMINCP')) {
	dheader("Location:".ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&pmod=setting&danchor=masssend');
}

define('RSELF', $this->redirect.'&danchor='.$this->danchor.'&op=');
require_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');

$wechat_client = new duceapp_wechatclient($this->setting['mp']['appid'], $this->setting['mp']['appsecret']);

if ($this->cpmethod != 'save') {

	duceapp_headscript('admin_masssend');

	$op = !empty($_GET['op']) ? $_GET['op'] : '';
	if (!$op) {
		$ppp = 10;
		$page = max(1, intval($_GET['page']));
		$start = ($page - 1) * $ppp;
		$count = C::t('#duceapp_wechat#duceapp_wechat_masssend')->count();
		$msg = C::t('#duceapp_wechat#duceapp_wechat_masssend')->range($start, $ppp, 'DESC');
		$multi = multi($count, $ppp, $page, RSELF);

		duceapp_anchortips('mass_main_tips');
		
		duceapp_formheader('enctype');

		duceapp_anchorheader();		
		duceapp_showsubtitle(array('mass_text_oper', 'mass_text_send', 'mass_type', 'mass_created_at', 'MSG_ID', 'mass_finish_at', 'mass_status', 'mass_totalcount', 'mass_filtercount', 'mass_sendcount', 'mass_errorcount'), array('style="width:100px;"', 'style="width:80px;"'));
		foreach ($msg as $m) {
			showtablerow('', array(), array(
			    '<a href="'.RSELF.'del&id='.$m['id'].'">'.duceapp_cplang('mass_delete').'</a> | <a href="'.RSELF.'add&id='.$m['id'].'">'.duceapp_cplang('mass_edit').'</a>',
			    '<input type="radio" name="massid" value="'.$m[id].'" class="radio"'.($m['type'] == 'media' && ($m['created_at'] + 86400 * 3) < TIMESTAMP ? ' disabled="disabled"' : '').'>',
			    duceapp_cplang('mass_type_'.$m['type']),
			    dgmdate($m['created_at']),
			    $m['msg_id'],
			    $m['res_finish_at'] ? dgmdate($m['res_finish_at']) : '',
			    $m['res_status'],
			    $m['res_totalcount'],
			    $m['res_filtercount'],
			    $m['res_sentcount'],
			    $m['res_errorcount'],
			));
		}

		duceapp_anchorfooter();
		echo '<div style="clear:both;height:8px;width:100%;border-top:1px solid #eee"></div><div class="right pg">' . $multi . '</div>';
		echo '<input class="btn leftbtn" name="sendsubmit" value="'.duceapp_cplang('mass_send').'" type="submit" style="background-position:0 -54px;"><a href="'.RSELF.'add" class="resource_pn resource_pne">+ '.duceapp_cplang('mass_create').'</a>';

		showformfooter();/*dism��taobao��com*/

	} else if ($op == 'add') {

		$groups = $wechat_client->getAllGroups();
		if (!$groups) {
			duceapp_error('mass_get_group_failed');
		}
		$resourcehtml = '';		

		if (intval($_GET['id']) > 0) {
			$mass = C::t('#duceapp_wechat#duceapp_wechat_masssend')->fetch(intval($_GET['id']));
			if ($mass['resource_id'] || ($mass['type'] == 'news' && $mass['media_id'])) {
				if ($mass['type'] == 'news' && $mass['media_id']) {
					list($resource) = $this->getNewsByid($mass['media_id']);
				} else {
					$resource = C::t('#duceapp_wechat#duceapp_wechat_resource')->fetch($mass['resource_id']);
				}
				if (!$resource['type']) {
					$resourcehtml = '<ul class="resource_single" style="height:278px;" onmouseover="duceapp_addclass(this, \'resource_hover\')" onmouseout="duceapp_removeclass(this, \'resource_hover\')"><li><div class="pic"'.($resource['data']['pic'] ? '' : ' style="display:none;"').'>'.($resource['data']['pic'] ? '<img data-src="'.$resource['data']['pic'].'" src="'.STATICURL.'image/common/none.gif" />' : '').'</div>
						<div class="desktop">
							<div class="title">'.$resource['data']['title'].'</div>
							<div class="desc">'.($resource['data']['desc'] ? $resource['data']['desc'] : cutstr($resource['data']['content'], 64)).'</div>
						</div></li><dl class="resource_mask"><a href="javascript:;" onclick="resource_del(this)">'.cplang('delete').'</a></dl></ul>';
				} else {
					if (isset($resource['mergedata'])) {
						$mergeids = array_keys($resource['mergedata']);
						$mergedata = $resource['mergedata'];
					} else {
						$mergeids = array_values($resource['data']['mergeids']);
						if (!$mergeids) {
							duceapp_error('resource_msg_nofound');
						}
						$mergedata = C::t('#duceapp_wechat#duceapp_wechat_resource')->fetch_all($mergeids);
					}
					$resourcehtml = '<ul class="resource_merge" style="height:278px;" onmouseover="duceapp_addclass(this, \'resource_hover\')" onmouseout="duceapp_removeclass(this, \'resource_hover\')">';
					$i = 0;
					
					foreach($mergeids as $id){
						$merge = $mergedata[$id];
						$resourcehtml .= '<li class="'.(!$i ? 'fst' : '').'">
							<div class="pic">'.($merge['data']['pic'] ? '<img data-src="'.$merge['data']['pic'].'" src="'.STATICURL.'image/common/none.gif" />' : '').'</div>
							<div class="desktop">
								<div class="title">'.$merge['data']['title'].'</div>
								<div class="desc">'.($merge['data']['desc'] ? $merge['data']['desc'] : cutstr($merge['data']['content'], 64)).'</div>
							</div>
						</li>';
						$i++;
					}
					$resourcehtml .= '<dl class="resource_mask"><a href="javascript:;" onclick="resource_del(this)">'.cplang('delete').'</a></dl></ul>';
				}
			}
		}

		duceapp_anchortips('mass_add_tips');
		
		duceapp_formheader('enctype');
		showhiddenfields(array('massid' => $mass['id']));
		duceapp_anchorheader();

		$masstype = $massdisplay = array();
		$_disabled = $this->setting['api'] ? ' disabled="disabled"' : '';
		if ($mass['resource_id'] || $mass['media_id']) {
			$masstype[1] = ' checked';
			$massdisplay[0] = 'style="display:none;"';
		} else {
			$masstype[0] = ' checked';
			$massdisplay[1] = 'style="display:none;"';
		}
		showtablerow('', array('class="masstype rowform"'), array('<strong>'.duceapp_cplang('mass_type').'</strong><ul'.($disabled ? '' : ' onmouseover="altStyle(this);"').'><li class="'.$masstype[0].'" id="masstype_0"><input type="radio" class="radio" name="masstype" onclick="$(\'masstype_0_m\').style.display=\'\';$(\'masstype_1_m\').style.display=\'none\';" value="0"'.$masstype[0].$disabled.'> '.duceapp_cplang('mass_text').'</li><li class="'.$masstype[1].'" id="masstype_1"><input type="radio" class="radio" name="masstype" onclick="$(\'masstype_1_m\').style.display=\'\';$(\'masstype_0_m\').style.display=\'none\';" value="1"'.$masstype[1].$disabled.'> '.duceapp_cplang('mass_mpnews').'</li></ul>', ''));
		showtablerow('', array('', 'class="td23 td28"', '', 'class="td29"'), array(
		    '<div class="masstext" id="masstype_0_m" '.$massdisplay[0].'><textarea class="tarea" name="massmessage" id="res_subscribe" rows="5" cols="40">'.$mass['text'].'</textarea></div><div class="massresource selresource" id="masstype_1_m" '.$massdisplay[1].'>'.$resourcehtml.'<em class="add" onclick="resource_showlist(this)">'.duceapp_cplang('menu_button_selresource').'</em><em class="add" onclick="resource_showlist(this, 2)" style="margin-top:0;">'.duceapp_cplang('menu_button_mpresource').'</em>'.($mass['type'] == 'news' ? '<input type="hidden" name="media_id" value="'.$mass['media_id'] : '<input type="hidden" name="resource_id" value="'.$mass['resource_id']).'"></div>',
			''
		));
		$select = array('group_id', array());
		foreach ($groups as $g) {
			$select[1][] = array($g['id'], diconv($g['name'], 'UTF-8', CHARSET)."($g[count])");
		}

		showtablerow('', array('class="masstype rowform"'), array('<strong>'.duceapp_cplang('resource_mediatype').'</strong><ul onmouseover="altStyle(this);"><li class="checked" id="permanent_0"><input type="radio" class="radio" name="permanent" value="0" checked> '.duceapp_cplang('resource_temporary').'</li><li class="" id="permanent_1"><input type="radio" class="radio" name="permanent" value="1"> '.duceapp_cplang('resource_permanent').'</li></ul>', ''));

		showsetting(duceapp_cplang('mass_group_id'), $select, $mass['group_id'], 'select', '', 0, '', 'style="width:300px;margin-bottom:5px;"');
		showsubmit('massaddsubmit', 'submit', '', '<input class="btn leftbtn" type="submit" name="addsendsubmit" value="'.cplang('submit').'" style="background-position:0 -108px;">');
		duceapp_anchorfooter();
		showformfooter();/*dism��taobao��com*/
		echo '<script type="text/JavaScript">duceapp_imgzoom("masstype_1_m");</script>';
		$this->showResource('menu');

	} else if ($op == 'del') {

		$massid = intval($_GET['id']);
		$msg = C::t('#duceapp_wechat#duceapp_wechat_masssend')->fetch($massid);
		if (!$msg) {
			duceapp_error('mass_not_exist');
		}
		if (!$msg['res_finish_at'] && $msg['msg_id']) {
			duceapp_cpmsg('mass_del_tips_1', RSELF.'&massid='.$_GET['id'].'&duceapp_submit=yes&delsubmit=yes', 'form');
		}
		duceapp_cpmsg('mass_del_tips_2', RSELF.'&massid='.$_GET['id'].'&duceapp_submit=yes&delsubmit=yes', 'form');
	}

} else {

	if (submitcheck('massaddsubmit') || submitcheck('addsendsubmit')) {

		$group_id = intval($_GET['group_id']);		
		if ($_GET['masstype'] == 1) {
			if (!$this->setting['mp']) {
				duceapp_error('wechat_menu_at_error');
			}
			dmkdir(DUCEAPP_DATAROOT.$dir.'/');

			if ($_GET['media_id']) {
				$newsRes = $this->getNewsByid($_GET['media_id'], true);
				if (!$newsRes) {
					duceapp_error('mass_no_found');
				}
				$massid = C::t('#duceapp_wechat#duceapp_wechat_masssend')->insert(array(
					'type' => 'news',
					'text' => '',
					'group_id' => $group_id,
					'media_id' => $_GET['media_id'],
					'created_at' => TIMESTAMP
				), true);
			} else {
				if ($this->setting['api']) {
					duceapp_error('wechat_pubsave_invalid');
				}
				$resource_id = intval($_GET['resource_id']);
				if (!$resource_id || !($res = C::t('#duceapp_wechat#duceapp_wechat_resource')->fetch($resource_id))) {
					duceapp_error('mass_no_found');
				}
				$mass = C::t('#duceapp_wechat#duceapp_wechat_masssend')->fetch(intval($_GET['massid']));
				if ($mass['type'] == 'media' && $mass['media_id'] && $mass['resource_id'] == $resource_id) {
					$massid = $mass['id'];
					C::t('#duceapp_wechat#duceapp_wechat_masssend')->update($massid, array('group_id' => $group_id));
				} else {
					$news = array();
					if ($res['type'] == 0) {
						if ($res['data']['pic']) {
							$cache = 0;
							if ($res['data']['local']) {
								$localimage = $_G['setting']['attachdir'].'common/'.$res['data']['local'];
							} else {
								$res['data']['pic'] = str_replace($_G['siteurl'].$_G['setting']['attachurl'].'common/', '', $res['data']['pic']);
								if (preg_match('/^http/i', $res['data']['pic'])) {
									$localimage = $this->getNewsImage(array(
										'thumb_media_id' => md5($res['data']['pic']), 
										'thumb_url' => $res['data']['pic'],
									));
									$cache = 1;
								} else {
									$localimage = $_G['setting']['attachdir'].'common/'.$res['data']['pic'];
								}
							}
							$thumb_media_id = $wechat_client->upload('image', $localimage, 1, $_GET['permanent']);
							if ($cache && !preg_match('/^http/i', $localimage)) {
								@unlink($localimage);
							}
							if (!$thumb_media_id) {
								duceapp_error($wechat_client->error());
							}
							$res['data']['thumb_media_id'] = $thumb_media_id;
							//$res['data']['author'] = '';
						} else {
							duceapp_error('mass_no_pic');
						}
						array_push($news, $res['data']);
					} else if ($res['type'] == 1) {
						$news = array();
						foreach (array_keys($res['data']['mergeids']) as $resourceid) {
							$res = C::t('#duceapp_wechat#duceapp_wechat_resource')->fetch($resourceid);
							if (!$res) {
								duceapp_error('mass_no_found');
							}
							if ($res['data']['pic']) {
								$cache = 0;
								if ($res['data']['local']) {
									$localimage = $_G['setting']['attachdir'].'common/'.$res['data']['local'];
								} else {
									$res['data']['pic'] = str_replace($_G['siteurl'].$_G['setting']['attachurl'].'common/', '', $res['data']['pic']);
									if (preg_match('/^http/i', $res['data']['pic'])) {
										$localimage = $this->getNewsImage(array(
											'thumb_media_id' => md5($res['data']['pic']), 
											'thumb_url' => $res['data']['pic'],
										));
										if ($localimage != $res['data']['pic']) {
											$localimage = DISCUZ_ROOT.$localimage;
											$cache = 1;
										}
									} else {
										$localimage = $_G['setting']['attachdir'].'common/'.$res['data']['pic'];
									}
								}
								$thumb_media_id = $wechat_client->upload('image', $localimage, 1, $_GET['permanent']);
								if ($cache && !preg_match('/^http/i', $localimage)) {
									@unlink($localimage);
								}
								if (!$thumb_media_id) {
									duceapp_error($wechat_client->error());
								}
								$res['data']['thumb_media_id'] = $thumb_media_id;
								//$res['data']['author'] = '';
								array_push($news, $res['data']);
							} else {
								duceapp_error('mass_no_pic');
							}
						}
					}
					$newsRes = $wechat_client->uploadNews($news, $_GET['permanent']);
					if (!$newsRes) {
						duceapp_error($wechat_client->error());
					}
					$massid = C::t('#duceapp_wechat#duceapp_wechat_masssend')->insert(array(
						'type' => $_GET['permanent'] ? 'news' : 'media',
						'resource_id' => $resource_id,
						'text' => '',
						'group_id' => $group_id,
						'media_id' => $newsRes['media_id'],
						'created_at' => $_GET['permanent'] ? TIMESTAMP : $newsRes['created_at']
					), true);
				}
			}
		} else {
			$massmessage = trim($_GET['massmessage']);
			if (empty($massmessage)) {
				duceapp_error('mass_no_text');
			}
			$data = array(
				'resource_id' => 0,
				'type' => 'text',
				'text' => $massmessage,
				'group_id' => $group_id,
				'created_at' => TIMESTAMP
			);
			$massid = C::t('#duceapp_wechat#duceapp_wechat_masssend')->insert($data, true);			
		}
		if (submitcheck('addsendsubmit') && $massid) {
			if ($this->setting['api']) {
				duceapp_error('wechat_pubsave_invalid');
			}
			duceapp_cpmsg('mass_sending', RSELF.'&massid='.$massid.'&duceapp_submit=yes&sendsubmit=yes', 'loadingform');
		}
		duceapp_cpmsg('mass_created_succ');

	} else if (submitcheck('sendsubmit')) {

		if (!$this->setting['mp']) {
			duceapp_error('wechat_menu_at_error');
		}
		if ($this->setting['api']) {
			duceapp_error('wechat_pubsave_invalid');
		}

		$massid = intval($_GET['massid']);
		if (!$massid) {
			duceapp_error('mass_not_exist');
		}
		$msg = C::t('#duceapp_wechat#duceapp_wechat_masssend')->fetch($massid);
		if (!$msg) {
			duceapp_error('mass_not_exist');
		}

		if ($msg['type'] == 'media' && ($msg['created_at'] + 86400 * 3) < TIMESTAMP) {
			duceapp_error('mass_send_expire');
		}

		$res = $wechat_client->sendMassMsg($msg);
		if ($res) {
			require_once libfile('class/duceapp_wechathook', 'plugin/duceapp_wechat');
			C::t('#duceapp_wechat#duceapp_wechat_masssend')->update($massid, array('msg_id' => $res['msg_id'], 'sent_at' => TIMESTAMP));
			$updatedata = array('receiveEvent::masssendjobfinish' => array('plugin' => 'duceapp_wechat', 'include' => 'class/class_duceapp_response.php', 'class' => 'duceapp_response', 'method' => 'masssendFinish'));
			$responsehook = duceapp_wechathook::updateResponse($updatedata, 'duceapp_wechat');
			duceapp_cpmsg('mass_sent_succ');
		} else {
			duceapp_error($wechat_client->error());
		}

	} else if (submitcheck('delsubmit')) {

		$massid = intval($_GET['massid']);
		$msg = C::t('#duceapp_wechat#duceapp_wechat_masssend')->fetch($massid);
		if (!$msg) {
			duceapp_error('mass_not_exist');
		}
		C::t('#duceapp_wechat#duceapp_wechat_masssend')->delete($massid);
		duceapp_cpmsg('mass_oper_succ', RSELF);

	}

}