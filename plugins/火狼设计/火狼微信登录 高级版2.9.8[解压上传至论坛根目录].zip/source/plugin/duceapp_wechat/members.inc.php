<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00428
 * Date: 2020-08-06 03:25:46
 * File: members.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once libfile('class/duceapp_admincp', 'plugin/duceapp_wechat');

class duceapp_modcp extends duceapp_admincp
{
	public $anchors = array('list', 'import', 'upunionid');

	public function __construct() {
		$this->header();

		$this->logfile = DUCEAPP_DATAURL.dgmdate(TIMESTAMP, 'Ym').'_upunionid.txt';
		duceapp_showanchors('members', 1);
		call_user_func(array(__CLASS__, $this->cpmethod));

		$this->footer();
	}	

	private function main() {
		global $_G, $lang;

		$ppp = 15;
		$page = max(1, $_G['page']);
		$start_limit = ($page - 1) * $ppp;

		if ($this->danchor == 'list') {			
			$members = '';
			$filteruid = null;
			$filter = trim($_GET['filterusername']);
			$filterusername = $filter ? explode(',', $filter) : false;
			if ($filterusername) {
				foreach($filterusername as $value){
					if (strexists($value, '*')) {
						$value = str_replace('*', '%', $value);
						$condition[] = "username LIKE '$value'";
					} else {
						$condition[] = "username = '$value'";
					}
				}
				$filteruid = array_keys(DB::fetch_all('SELECT uid FROM %t WHERE %i', array('common_member', implode(' OR ', $condition)), 'uid'));
			}
			$countmember = C::t('#duceapp_wechat#duceapp_wechat_member')->count_all_member($filteruid);
			
			if ($countmember) {
				$usergroups = array();
				foreach(C::t('common_usergroup')->range() as $group) {
					switch($group['type']) {
						case 'system': $group['grouptitle'] = '<b>'.$group['grouptitle'].'</b>'; break;
						case 'special': $group['grouptitle'] = '<i>'.$group['grouptitle'].'</i>'; break;
					}
					$usergroups[$group['groupid']] = $group;
				}
				$selfurl = $this->redirect.'&danchor='.$this->danchor;
				$sort = $_GET['sort'] == 'asc' ? 'asc' : 'desc';
				$orderby = $_GET['orderby'] ? $_GET['orderby'] : 'binddate';
				$multipage = multi($countmember, $ppp, $page, $selfurl."&orderby=$orderby&sort=$sort&filterusername=".urlencode($filter));
				$allmember = C::t('#duceapp_wechat#duceapp_wechat_member')->fetch_all_member($filteruid, $start_limit, $ppp, $orderby, $sort);
				foreach($allmember as $uid => $member) {
					$memberextcredits = array();
					if($_G['setting']['extcredits']) {
						foreach($_G['setting']['extcredits'] as $id => $credit) {
							$memberextcredits[] = $_G['setting']['extcredits'][$id]['title'].': '.$member['extcredits'.$id].' ';
						}
					}
					$lockshow = $member['status'] == '-1' ? '<em class="lightnum">['.cplang('lock').']</em>' : '';
					$freezeshow = $member['freeze'] ? '<em class="lightnum">['.cplang('freeze').']</em>' : '';
					$members .= showtablerow('', array('class="td25"', '', '', '', '', 'title="'.implode("\n", $memberextcredits).'"'), array(
						"<input type=\"checkbox\" name=\"delete[]\" value=\"$member[uid]\" class=\"checkbox\">",
						($_G['setting']['connect']['allow'] && $member['conisbind'] ? '<img class="vmiddle" src="static/image/common/connect_qq.gif" /> ' : '')."<a href=\"home.php?mod=space&uid=$member[uid]\" target=\"_blank\">$member[username]</a>",
						$member['isregister'] ? $lang['yes'] : $lang['no'],
						$member['subscribe'] == 1 ? $lang['yes'] : ($member['subscribe'] == -1 ? duceapp_cplang('members_pclogin') : $lang['no']),
						dgmdate($member['dateline'], 'Y-m-d H:i:s'),
						$member['credits'],
						$member['posts'],
						$usergroups[$member['adminid']]['grouptitle'],
						$usergroups[$member['groupid']]['grouptitle'].$lockshow.$freezeshow,
						"<a href=\"".ADMINSCRIPT."?action=members&operation=group&uid=$member[uid]\" class=\"act\">$lang[usergroup]</a><a href=\"".ADMINSCRIPT."?action=members&operation=access&uid=$member[uid]\" class=\"act\">$lang[members_access]</a>".
						($_G['setting']['extcredits'] ? "<a href=\"".ADMINSCRIPT."?action=members&operation=credit&uid=$member[uid]\" class=\"act\">$lang[credits]</a>" : "<span disabled>$lang[edit]</span>").
						"<a href=\"".ADMINSCRIPT."?action=members&operation=medal&uid=$member[uid]\" class=\"act\">$lang[medals]</a>".
						"<a href=\"".ADMINSCRIPT."?action=members&operation=repeat&uid=$member[uid]\" class=\"act\">$lang[members_repeat]</a>".
						"<a href=\"".ADMINSCRIPT."?action=members&operation=edit&uid=$member[uid]\" class=\"act\">$lang[detail]</a>".
						"<a href=\"".ADMINSCRIPT."?action=members&operation=ban&uid=$member[uid]\" class=\"act\">$lang[members_ban]</a>"
					), TRUE);
				}
			}
			
			showformheader($this->basescript);
			showhiddenfields(array('danchor' => $this->danchor));
			duceapp_anchorheader();
			echo '<tr>
				<td style="border-bottom:1px solid #eee;"><span style="display:inline-block;height:22px;line-height:22px;border:0px solid #aaa;padding:0 6px;vertical-align:middle;">'.cplang('username').
					'</span> <input type="text" class="txt" style="width:280px;" name="filterusername" value="'.$filter.'" placeholder="'.duceapp_cplang('members_srchholder').'"> <input type="submit" class="btn" name="search_submit" value="'.cplang('search').'">
				</td>
			</tr>';
			duceapp_anchorfooter();
			showformfooter();/*dism��taobao��com*/

			if ($members) {
				duceapp_formheader();
				duceapp_anchorheader();
				showsubtitle(array('', 'username', duceapp_cplang('members_isregister'), duceapp_cplang('members_subscribe'), '<a href="'.$selfurl.'&sort='.($sort == 'asc' || $orderby != 'binddate' ? 'desc' : 'asc').'">'.duceapp_cplang('members_bindtime').'</a>', '<a href="'.$selfurl.'&orderby=credits&sort='.($sort == 'asc' || $orderby != 'credits' ? 'desc' : 'asc').'">'.cplang('credits').'</a>', '<a href="'.$selfurl.'&orderby=posts&sort='.($sort == 'asc' || $orderby != 'posts' ? 'desc' : 'asc').'">'.cplang('posts').'</a>', 'admingroup', 'usergroup', ''), 'header', array(
					'', 'style="width:150px;"', 'style="width:70px;"', 'style="width:85px;"', 'style="width:180px;"',
				));
				echo $members;
				showsubmit('wechatunbind', 'submit', 'select_all', '', $multipage, false);
				duceapp_anchorfooter();
				showformfooter();/*dism��taobao��com*/
			} else {
				showtableheader();
				echo '<tr><td>'.duceapp_cplang($filteruid !== null ? 'members_noexists' : 'members_nolist').'</td></tr>';
				showtablefooter();/*dis'.'m.tao'.'bao.com*/
			}			
		} elseif ($this->danchor == 'import') {

			duceapp_anchortips('members_import_tips');
			duceapp_formheader();
			duceapp_anchorheader();
			duceapp_showsetting('members_import_type', array('import[type]', array(
				array(0, duceapp_cplang('members_import_wechat'), array('wechat_other' => 'none')),
				array(1, duceapp_cplang('members_import_other'), array('wechat_other' => '')),
			), 1), 0, 'mradio');
			showtagheader('tbody', 'wechat_other', 0, 'sub');
			duceapp_showsetting('members_import_other_table', 'import[table]', '', 'text');
			duceapp_showsetting('members_import_other_uidfield', 'importfield[uid]', 'uid', 'text');
			duceapp_showsetting('members_import_other_openidfield', 'importfield[openid]', 'openid', 'text');
			duceapp_showsetting('members_import_other_unionidfield', 'importfield[unionid]', 'unionid', 'text');
			showtagfooter('tbody');
			showsubmit('submit');
			duceapp_anchorfooter();
			showformfooter();/*dism��taobao��com*/

		} elseif ($this->danchor == 'upunionid') {

			duceapp_anchortips('members_upunionid_tips');

			if (C::t('#duceapp_wechat#duceapp_wechat_member')->count_by_emptyunionid()){
				duceapp_formheader();
				duceapp_anchorheader();
				duceapp_showsetting('members_uppapers', 'uppapers', '', 'text');
				showsubmit('submit');
				duceapp_anchorfooter();
				showformfooter();/*dism��taobao��com*/
			} else {
				showtableheader();
				echo '<tr><td>'.duceapp_cplang('members_upunionid_noexists').'</td></tr>';
				showtablefooter();/*dis'.'m.tao'.'bao.com*/
			}

		}
	}

	private function save() {
		global $_G;

		if ($this->danchor == 'list') {
			if ($_GET['delete']) {
				C::t('#duceapp_wechat#duceapp_wechat_member')->delete(dintval($_GET['delete'], true));
			}
		} elseif($this->danchor == 'import') {
			if (!submitcheck('importsubmit')) {
				$table = '';
				$type = intval($_GET['import']['type']);
				if (!$type) {
					$table = 'common_member_wechat';
					$field = array('uid'=>'uid', 'openid'=>'openid');
				} else {
					$table = trim($_GET['import']['table']);
					if (!$table || !preg_match('/^[a-z0-9_]+$/', $table)) {
						duceapp_error(duceapp_cplang('members_table_exists', array('table' => $table)));
					}
					$field = $_GET['importfield'];
				}
				if (DB::fetch_first("SELECT table_name FROM information_schema.TABLES WHERE ".DB::field('table_name', DB::table($table)))) {
					$query = DB::query('SHOW FIELDS FROM '.DB::table($table), '', 'SILENT');
					$fielddata = array();
					if ($query) {						
						while($value = DB::fetch($query)) { $fielddata[$value['Field']] = $value; }
					}
					foreach (array('uid', 'openid') as $key) {
						$fd = $field[$key];
						if (!$fd || !$fielddata[$fd]) {
							duceapp_error(duceapp_cplang('members_table_fieldexists', array('field' => $fd)));
						}
					}
				} else {
					duceapp_error(duceapp_cplang('members_table_exists', array('table' => $table)));
				}
				$auth = authcode($table."\t".serialize($field), 'ENCODE');
			} else {
				$auth = base64_decode($_GET['auth']);
				list($table, $field) = explode("\t", authcode($auth, 'DECODE'));
				$field = unserialize($field);
				if (!$table || !$field) {
					duceapp_error('members_import_invalid');
				}
			}
			$ppp = 20;
			if ($count = $this->import_member($table, $field, 0, $ppp)) {
				$page = max(1, $_G['page']);
				$message = duceapp_cplang('members_importing', array('start' => $ppp*($page - 1) + 1, 'limit' => $count == $ppp ? $ppp*$page : $ppp*($page - 1) + $count));
				duceapp_cpmsg($message, $this->redirect.'&danchor=import&duceapp_submit=yes&importsubmit=yes&auth='.urlencode(base64_encode($auth)).'&page='.($page + 1), 'loadingform');
			}
		} elseif($this->danchor == 'upunionid') {
			$ppp = intval($_GET['uppapers']);
			$ppp = $ppp > 1 ? $ppp : 30;
			$start = 0;
			
			if ($fp = @fopen($this->logfile, 'r')) {
				$start = intval(fread($fp, 1024));
				fclose($fp);
			}
			if ($count = $this->upunionid_member($start, $ppp)){				
				$page = max(1, $_G['page']);
				$message = duceapp_cplang('members_upunionid_process', array('start' => $ppp*($page - 1) + 1, 'limit' => $count == $ppp ? $ppp*$page : $ppp*($page - 1) + $count));
				duceapp_cpmsg($message, $this->redirect.'&danchor=upunionid&duceapp_submit=yes&importsubmit=yes&uppapers='.$ppp.'&page='.($page + 1), 'loadingform');
			}
		}

		duceapp_cpmsg();
	}

	private function upunionid_member($start = 0, $limit = 30) {
		$memberlist = C::t('#duceapp_wechat#duceapp_wechat_member')->fetch_by_emptyunionid($start, $limit);
		if (!$memberlist) {
			return 0;
		}
		require_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');
		$wechat_client = new duceapp_wechatclient('mp');
		$updateuids = array();
		$failedcount = 0;
		foreach ($memberlist as $member) {			
			$access_user = $wechat_client->getUserInfoById($member['openid']);
			if ($access_user === null || (isset($access_user['subscribe']) && $access_user['subscribe'] == 0)) {
				$failedcount++;
				continue;
			}
			if (!$access_user['unionid']) {
				duceapp_error('duceapp_wechat:access_nobindmp');
			}
			$updateuids[$member['uid']] = array('subscribe' => $access_user['subscribe'], 'unionid' => $access_user['unionid']);
		}
		foreach($updateuids as $uid => $data){
			C::t('#duceapp_wechat#duceapp_wechat_member')->update($uid, $data);
		}
		if ($failedcount && ($fp = @fopen($this->logfile, 'w'))) {
			$count = $start + $failedcount;
			fwrite($fp, (string) $count);
			fclose($fp);
		}
		return count($memberlist);
	}

	private function import_member($table, $field, $start = 0, $limit = 20) {
		$query = DB::query("SELECT o.* FROM ".DB::table($table)." o
			INNER JOIN ".DB::table('common_member')." m ON m.uid=o.".$field['uid']." 
			LEFT JOIN ".DB::table('duceapp_wechat_member')." d ON d.uid=o.".$field['uid']."
			WHERE d.uid IS NULL ".DB::limit($start, $limit));
		$memberlist = array();
		$count = 0;
		while($member = DB::fetch($query)) {
			$count++;
			if (DB::result_first('SELECT uid FROM %t WHERE %i', array('duceapp_wechat_member', DB::field('openid', $member[$field['openid']]).($field['unionid'] && $member[$field['unionid']] ? " OR ".DB::field('unionid', $member[$field['unionid']]) : "")))) {
				continue;
			}
			$memberlist[] = $member;
		}
		if (!$memberlist) {
			return $count == $limit ? $count : 0;
		}
		require_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');
		$wechat_client = new duceapp_wechatclient('mp');
		foreach ($memberlist as $member) {
			if (!$member[$field['openid']]) {
				continue;
			}
			$data = array();
			$data['uid'] = $member[$field['uid']];			
			$data['openid'] = $member[$field['openid']];
			$access_user = $data['openid'] ? $wechat_client->getUserInfoById($data['openid']) : null;
			if ($access_user) {
				if (isset($access_user['subscribe'])){
					$data['subscribe'] = $access_user['subscribe'];
					if ($data['subscribe']) {
						if ($access_user['unionid']) {
							$data['unionid'] = $access_user['unionid'];
						}
						$data['sex'] = $access_user['sex'];
						$data['nickname'] = $access_user['nickname'];
					}
				}				
			} else {
				if ($field['unionid'] && $member[$field['unionid']]) {
					$data['unionid'] = $member[$field['unionid']];
				}
			}
			$data['isregister'] = 1;
			if (isset($member['isregister'])) {
				$data['isregister'] = $member['isregister'];
			}
			C::t('#duceapp_wechat#duceapp_wechat_member')->insert($data);
		}
		return count($memberlist);
	}
}

new duceapp_modcp;