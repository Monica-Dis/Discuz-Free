<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!应用中心 dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90916
 * Date: 2020-08-06 03:25:46
 * File: lang_check.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

global $lang;
$lang['duceapp_base_supportver'] = '<p style="font:14px/1.8 \'Microsoft Yahei\';font-weight:bold;color:#ff0000;">火狼基础插件版本过低，至少需要升级到<b>'.$base_supportver.'</b>，【<a href="https://dism.taobao.com/?@duceapp_base.plugin">点此立即升级</a>】</p>';
$lang['duceapp_base_nowriteaccess'] = '<p style="font:14px/1.8 \'Microsoft Yahei\';font-weight:bold;color:#ff0000;">您的插件目录没有读写权限！</p>';