<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!应用中心 dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: lang_invoke.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$duceapp_compon_lang = array(
	'appver' => 'built in',
	'menu_order' => 0,
	'menu_title' => '數據同步',

	'anchors' => array(
		'api' => array('real' => 2, 'title' => '接口設置'),
		'doc' => array('real' => 2, 'title' => '接口文檔'),
	),

	'invoke_tips' => '<li>公眾號基礎Access_token是公眾號的全局唯一接口調用憑據，避免業務失敗，其他應用或插件使用到Access_token需統一調用</li><li>插件提供Access_token、Jsapi_ticket和微信用戶數據的接口，有數據同步(例如<b>微信支付</b>)的需求，請聯係相關開發者參閱本設置及<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin['pluginid'].'&pmod=compon&cmod=invoke&danchor=doc">接口文檔</a></li><li>調用外部憑據PHP代碼中可直接引用方法，GET方法：self::get(URL)，POST方法：self::post(URL, POSTDATA)，前後無需寫&lt;?php 和 ?&gt;</li>',	
	'invoke_secret' => '插件接口密鑰(Secret)',
	'invoke_secret_comment' => '如果接入設置選擇授權回調方式，填寫授權論壇的插件接口密鑰，兩者保持一致',
	'invoke_expires' => '接口憑據刷新模式',
	'invoke_expires_comment' => '本設置針對基礎Access_token和Jsapi_ticket的刷新，默認是7200秒刷新一次，如果公眾號有應用於其他非火狼出品應用，避免業務失敗可設置實時刷新或自定義刷新時間',
	'invoke_expires_0' => '默認',
	'invoke_expires_1' => '實時刷新',
	'invoke_expires_2' => '自定義',
	'invoke_expires_in' => '接口憑據刷新秒數',
	'invoke_expires_in_comment' => '秒數請設置10~7200秒之間',
	'invoke_synbind' => '同步綁定微信的應用',
	'invoke_synbind_comment' => '您的UCenter下有多個應用，選擇需要同步綁定微信的主應用URL（應用需安裝相應的火狼微信插件），任意一個應用中有綁定了同一個微信，則同步激活同一ID帳號並自動綁定微信<br>按住 Ctrl 鍵可多選。',
	'invoke_token' => '調用外部(Access_token)的PHP代碼',
	'invoke_token_comment' => '$res = self::get(API_URL); /* API_URL 為遠程獲取的地址 */<br />$res = json_decode($res, true); /* 例：$res 為遠程返回的JSON數據 */<br />$res[\'token\'] = $res[\'access_token\']; /* 必須將返回的access_token數據賦值到$res[\'token\'] */',
	'invoke_ticket' => '調用外部(Jsapi_ticket)的PHP代碼',
	'invoke_ticket_comment' => '$res = self::get(API_URL); /* API_URL 為遠程獲取的地址 */<br />$res = json_decode($res, true); /* 例：$res 為遠程返回的JSON數據 */<br />$res[\'ticket\'] = $res[\'ticket\']; /* 必須將返回的ticket數據賦值到$res[\'ticket\'] */',
	'invoke_doc_tips' => '<li>下列為其他應用或插件調用本插件數據的開放接口，獲取接口數據需要插件接口密鑰(Secret)</li><li>接口傳輸方式：'.strtoupper($_G['scheme']).'，數據格式：JSON，簽名算法：SHA1，字符編碼：'.strtoupper(CHARSET).'</li>',
	'invoke_doc' => '
	<h1 class="msyh f16" style="color:#690;">[API] 獲取公眾號基礎 ACCESS_TOKEN</h1>
	<p>
	請求方式：GET<br />
	URL地址：'.$_G['siteurl'].'source/plugin/duceapp_wechat/api.php?op=token&secret={插件接口密鑰}<br />
	請求參數說明：
	</p>
	<table>
	<tr><th class="th1">變量名</th><th class="th2">必填</th><th class="th3">示例值</th><th>描述</th></tr>
	<tr><td>op</td><td>是</td><td>token</td><td>API固定值</td></tr>
	<tr><td>secret</td><td>是</td><td>n38IKIMql8K8iw399ZEk5UHw</td><td>插件接口密鑰碼</td></tr>
	</table>
	<p>返回結果：errcode值=0 時有返回 token 值</p>
	<table>
	<tr><th class="th1">變量名</th><th class="th2">類型</th><th class="th3">示例值</th><th>描述</th></tr>
	<tr><td>errcode</td><td>Int</td><td>0</td><td>成功：0，其它值為失敗</td></tr>
	<tr><td>token</td><td>Sting</td><td>HoagFKDcsGMVCIY2vOjf9sdo...</td><td>ACCESS_TOKEN</td></tr>
	<tr><td>expiration</td><td>Sting</td><td>1532311201</td><td>下次刷新的時間戳</td></tr>
	</table>
	<h1 class="msyh f16" style="color:#690;">[API] 獲取公眾號 JSAPI_TICKET</h1>
	<p>
	請求方式：GET<br />
	URL地址：'.$_G['siteurl'].'source/plugin/duceapp_wechat/api.php?op=ticket&secret={插件接口密鑰}<br />
	請求參數說明：
	</p>
	<table>
	<tr><th class="th1">變量名</th><th class="th2">必填</th><th class="th3">示例值</th><th>描述</th></tr>
	<tr><td>op</td><td>是</td><td>ticket</td><td>API固定值</td></tr>
	<tr><td>secret</td><td>是</td><td>n38IKIMql8K8iw399ZEk5UHw</td><td>插件接口密鑰碼</td></tr>
	</table>
	<p>返回結果：errcode值=0 時有返回 ticket 值</p>
	<table>
	<tr><th class="th1">變量名</th><th class="th2">類型</th><th class="th3">示例值</th><th>描述</th></tr>
	<tr><td>errcode</td><td>Int</td><td>0</td><td>成功：0，其它值為失敗</td></tr>
	<tr><td>ticket</td><td>Sting</td><td>HoagFKDcsGMVCIY2vOjf9sdo...</td><td>JSAPI_TICKET</td></tr>
	<tr><td>expiration</td><td>Sting</td><td>1532311201</td><td>下次刷新的時間戳</td></tr>
	</table>
	<h1 class="msyh f16" style="color:#690;">[API] 獲取用戶綁定微信數據</h1>
	<p>
	請求方式：GET<br />
	URL地址：'.$_G['siteurl'].'source/plugin/duceapp_wechat/api.php?op=getuser&...<br />
	請求參數說明：
	</p>
	<table>
	<tr><th class="th1">變量名</th><th class="th2">必填</th><th class="th3">示例值</th><th>描述</th></tr>
	<tr><td>op</td><td>是</td><td>getuser</td><td>API固定值</td></tr>
	<tr><td>uid</td><td>openid 2選1</td><td>1</td><td>用戶UID</td></tr>
	<tr><td>openid</td><td>uid 2選1</td><td>n38IKIMql8K8iw399ZEk5UHw</td><td>從微信獲取的用戶openid</td></tr>
	<tr><td>unionid</td><td>否</td><td>n38IKIMql8K8iw399ZEk5UHw</td><td>從微信獲取的用戶unionid</td></tr>
	<tr><td>timestamp</td><td>是</td><td>1532311201</td><td>當前時間戳</td></tr>
	<tr><td>nonce</td><td>是</td><td>G8QM004m</td><td>隨機字符串</td></tr>
	<tr><td>signature</td><td>是</td><td>1e513cfcf108f7a0dc206956b1819197</td><td>sha1簽名</td></tr>
	</table>
	<p>返回結果：</p>
	<table>
	<tr><th class="th1">變量名</th><th class="th2">類型</th><th class="th3">示例值</th><th>描述</th></tr>
	<tr><td>errcode</td><td>Int</td><td>0</td><td>成功：0，缺少參數：-2，簽名錯誤：-1，未綁定微信：1</td></tr>
	<tr><td>uid</td><td>Int</td><td>1</td><td>用戶UID</td></tr>
	<tr><td>subscribe</td><td>Int</td><td>1</td><td>用戶是否關注公眾號，非通過公眾號登錄: -1，未關注：0，已關注：1</td></tr>
	<tr><td>openid</td><td>String</td><td>o284w1ln0WHnv7DfjSFl1bUJNKtY</td><td>從微信獲取的用戶openid</td></tr>
	<tr><td>unionid</td><td>String</td><td>oDFwuxLQPPd6YH7_GeJF69VBfwCo</td><td>從微信獲取的用戶unionid</td></tr>
	<tr><td>isregister</td><td>Int</td><td>0</td><td>是否微信注冊，否：0，是：1，是並已改用戶名：2</td></tr>
	<tr><td>nickname</td><td>String</td><td>火狼</td><td>從微信獲取的用戶昵稱</td></tr>
	<tr><td>sex</td><td>Int</td><td>1</td><td>從微信獲取的用戶性別，男：1，女：2</td></tr>
	<tr><td>dateline</td><td>Int</td><td>1532311201</td><td>用戶綁定微信的時間戳</td></tr>
	<tr><td>lastauth</td><td>Int</td><td>1532311201</td><td>用戶最後一次使用微信登錄的時間戳</td></tr>
	<tr><td>lat</td><td>float</td><td>1.265356</td><td>用戶定位經度值</td></tr>
	<tr><td>lng</td><td>float</td><td>1.265356</td><td>用戶定位緯度值</td></tr>
	</table>
	<h1 class="msyh f16" style="color:#690;">[API] 綁定用戶微信數據</h1>
	<p>
	請求方式：POST<br />
	URL地址：'.$_G['siteurl'].'source/plugin/duceapp_wechat/api.php<br />
	請求參數說明：
	</p>
	<table>
	<tr><th class="th1">變量名</th><th class="th2">必填</th><th class="th3">示例值</th><th>描述</th></tr>
	<tr><td>op</td><td>是</td><td>binduser</td><td>API固定值</td></tr>
	<tr><td>uid</td><td>是</td><td>1</td><td>用戶UID</td></tr>
	<tr><td>subscribe</td><td>否</td><td>1</td><td>用戶是否關注公眾號，默認: -1，未關注：0，已關注：1</td></tr>
	<tr><td>openid</td><td>是</td><td>o284w1ln0WHnv7DfjSFl1bUJNKtY</td><td>從微信獲取的用戶openid</td></tr>
	<tr><td>unionid</td><td>否</td><td>oDFwuxLQPPd6YH7_GeJF69VBfwCo</td><td>從微信獲取的用戶unionid</td></tr>
	<tr><td>nickname</td><td>否</td><td>火狼</td><td>從微信獲取的用戶昵稱</td></tr>
	<tr><td>sex</td><td>否</td><td>1</td><td>從微信獲取的用戶性別，男：1，女：2</td></tr>
	<tr><td>lat</td><td>否</td><td>1.265356</td><td>用戶定位經度值</td></tr>
	<tr><td>lng</td><td>否</td><td>1.265356</td><td>用戶定位緯度值</td></tr>
	<tr><td>timestamp</td><td>是</td><td>1532311201</td><td>當前時間戳</td></tr>
	<tr><td>nonce</td><td>是</td><td>G8QM004m</td><td>隨機字符串</td></tr>
	<tr><td>signature</td><td>是</td><td>1e513cfcf108f7a0dc206956b1819197</td><td>sha1簽名</td></tr>
	</table>
	<p>返回結果：</p>
	<table>
	<tr><th class="th1">變量名</th><th class="th2">類型</th><th class="th3">示例值</th><th>描述</th></tr>
	<tr><td>errcode</td><td>Int</td><td>0</td><td>綁定成功：0，缺少參數：-2，簽名錯誤：-1，微信已被綁定：1</td></tr>
	</table>
	<h1 class="msyh f16" style="color:#09C;">[API] <font color="#FF0000">SHA1</font>簽名方法</h1>
	<p>
	將插件接口密鑰 Secret、op、timestamp、nonce的value值進行字符串的字典序排序。<br />
	將參數字符串拚接成一個字符串進行sha1加密，得到signature<br />
	例如：<br />
	參數 Secret=bbc、op=getuser、timestamp=abc、nonce=aaa<br />
	排序 sort(array(bbc,getuser,abc,aaa), SORT_STRING)，排序後的參數字符串拚接成一個字符串 aaaabcbbcgetuser<br />
	得到 signature = sha1(aaaabcbbcgetuser)
	</p>
	',
	'invoke_phpcode_invalid' => '調用外部({extapi})的PHP代碼語法錯誤',
	'invoke_phpreturn_invalid' => '調用外部({extapi})的PHP代碼錯誤，請把返回值用數組形式賦值到$res中',
	'invoke_accesstoken_invalid' => '調用外部(Access_Token)的返回值請賦值到$res[\'token\']中',
	'invoke_jsapiticket_invalid' => '調用外部(JsApi_Ticket)的返回值請賦值到$res[\'ticket\']中',
);