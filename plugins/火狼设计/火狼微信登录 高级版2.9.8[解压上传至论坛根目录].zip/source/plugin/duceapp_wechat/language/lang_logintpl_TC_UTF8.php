<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!应用中心 dism.taobao.com
 * Created: 2019-02-10
 * Version: 3.00225
 * Date: 2020-02-25 16:53:10
 * File: lang_logintpl.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$duceapp_compon_lang = array(
	'appver' => '1.5.3',
	'menu_order' => 9,
	'menu_title' => '模板配置',

	'anchors' => array(
		'tpl' => array('real' => 1, 'title' => '基本配置'),
		'style' => array('real' => 1, 'title' => '模板風格'),
		'bgimg' => array('real' => 1, 'title' => '模板背景圖'),
		'icon' => array('real' => 1, 'title' => '圖標設置'),
	),
	'style_common' => '通用頁麵',
	'style_logging' => '登錄頁麵',
	'style_lostpw' => '第三方插件',

	'style_fontweight' => '通用字體粗細',
	'style_fontweight_0' => '極細字體',
	'style_fontweight_1' => '標準粗細',

	'logintpl_tpl_tips' => '<li>本組件提供一個手機版登錄頁麵的模板，可以替換您當前使用的手機模板登錄頁麵，並可隨時恢複</li><li>設置參數替換模板後保存，您可在手機頁麵刷新查看，可反複設置，以達到最佳效果</li>',
	'logintpl_icon_tips' => '<li>插件是按Discuz!標準嵌入點置入登錄或綁定圖標，您可向模板開發者核對下列的嵌入點是否存在</li><li>如果您的手機模板沒有Discuz!嵌入點，可在模板設置中選擇替換模板操作，或前往<a href="http://www.duceapp.cn" target="_blank">火狼設計網站</a>提問</li>',
	'logintpl_bgimg_tips' => '<li>登錄頁麵的背景圖片配置，可將製作好的背景圖片上傳至服務器，多張圖片可輪播展示</li><li>每次保存添加一張圖片，最多可添加5張圖片</li>',
	'logintpl_tpl_jsexists' => '<li><font color="#FF0000">缺少係統默認文件：<b>{jsexists}</b></font></li>',
	'logintpl_style_tips' => '<li>可通過下列設置風格參數設置個性登錄頁麵，通用適配主題色請到基礎插件全局設置>界麵設置</li><li>通用適配主題色所涉及到的頁麵有，登錄頁麵、用戶中心微信設置頁、登錄確認頁等</li>',
	'logintpl_action' => '請選擇操作類型',
	'logintpl_style' => '當前手機版模板風格：{name}<br/ >當前登錄頁模板風格：{name}',
	'logintpl_style1' => '當前手機版模板風格：{name}<br/ >當前登錄頁模板風格：<font color="green">插件風格</font>',
	'logintpl_action_none' => '保持當前風格設置',
	'logintpl_action_replace' => '替換當前模板登錄頁',
	'logintpl_action_recove' => '恢複成模板原有頁麵',
	'logintpl_themecolor' => '通用主題色',
	'logintpl_themecolor_comment' => '包括頭部背景、高亮線條、字體高亮顏色',
	'logintpl_textcolor' => '通用字體顏色',
	'logintpl_linkcolor' => '鏈接字體顏色',
	'logintpl_buttoncolor' => '通用按扭顏色',
	'logintpl_toplogo' => '登錄頁頂部LOGO',
	'logintpl_toplogo_comment' => '如果不填或不上傳表示不顯示，LOGO圖片建議為png格式，請以頁麵寬度720px作為標準製作{img}',
	'logintpl_logoheight' => '登錄頁頂部LOGO高度(px)',
	'logintpl_logoheight_comment' => '默認60px，頂部LOGO高度，您可以設置後刷新登錄頁查看，調整到最佳效果',
	'logintpl_headopacity' => '登錄頁頁頭背景透明度',
	'logintpl_headopacity_comment' => '整數0到100，數值越高越透明，全透明請填寫100，主題色請到基礎插件全局設置>界麵設置',
	'logintpl_opacity' => '透明度',
	'logintpl_iptbgcolor' => '登錄頁輸入框背景色',
	'logintpl_iptbgcomment' => '登錄頁輸入框背景色，透明度整數0到100，數值越高越透明，全透明請填寫100',
	'logintpl_iptbdcolor' => '登錄頁表單邊框顏色',
	'logintpl_iptbdcomment' => '表單邊框顏色，透明度整數0到100，數值越高越透明，全透明請填寫100',
	'logintpl_iptspacing' => '登錄頁表單輸入框間距(px)',
	'logintpl_iptspacing_comment' => '如果設置了間距，表單邊框線將全部透明化',
	'logintpl_fontcolor' => '登錄頁文字顏色',
	'logintpl_inputcolor' => '登錄頁輸入框文字顏色',
	'logintpl_formmargin' => '登錄頁表單外邊櫃(px)',
	'logintpl_formmargin_comment' => '用戶登錄輸入信息表單相對於設備邊框的距離，如果登錄頁設置了背景圖，建議設置為30',
	'logintpl_btncolor' => '按扭背景色',
	'logintpl_hidemobilebtn' => '是否隱藏手機版登錄按扭',
	'logintpl_hidemobilebtn_comment' => '如果您當前使用的手機模板，需要手動修改微信登錄按扭代碼的，請選擇隱藏；詳情請查看圖標設置的嵌入點',
	'logintpl_disinwechat' => '關閉非微信端登錄按扭',
	'logintpl_disinwechat_comment' => '選擇是否關閉用戶在非微信瀏覽器的微信登錄入口按扭',
	'logintpl_btn_method' => '電腦版登錄頁快捷按扭',
	'logintpl_method_comment' => '<span style="display:inline-block;height:30px;line-height:30px;width:300px;">頁麵嵌入點: hook/logging_method</span> {img}',
	'logintpl_btn_bind' => '電腦版頂部導航條綁定按扭',
	'logintpl_bind_comment' => '<span style="display:inline-block;height:30px;line-height:30px;width:300px;">頁麵嵌入點: hook/global_usernav_extra1</span> {img}',
	'logintpl_btn_bar' => '電腦版頁頭按扭',
	'logintpl_bar_comment' => '<span style="display:inline-block;height:30px;line-height:30px;width:300px;">頁麵嵌入點: hook/global_login_extra</span> {img}',
	'logintpl_btn_touch' => '手機版快捷登錄按扭',
	'logintpl_touch_comment' => '<span style="display:inline-block;height:30px;line-height:30px;width:300px;">頁麵嵌入點: hook/logging_bottom_mobile</span> {img}',
	'logintpl_action_noexists' => '選擇的操作模板和默認手機版模板不相符',
	'logintpl_noexists' => '當前手機模板文件夾{directory}/touch/member/沒有登錄頁麵login.htm文件<br /><br />請複製默認模板 template/default/touch/member/login.htm 到當前模板相對應的位置<br /><br />',
	'logintpl_induceapp' => '當前使用的是火狼手機模板係列無需替換',
	'logintpl_bgimg' => '背景圖片',
	'logintpl_smsloginurl' => '手機登錄頁麵鏈接',
	'logintpl_smsloginurl_comment' => '如果論壇有第三方手機登錄插件，可填寫相關插件登錄頁鏈接地址。',
	'logintpl_bgswitchtime' => '背景圖片輪播間隔時間（毫秒）',
	'logintpl_bgswitchtime_comment' => '多張圖片時，背景圖片輪播間隔時間，默認為3500毫秒=3.5秒',
	'logintpl_lostformobile' => '啟用第三方手機密碼找回',
	'logintpl_lostformobile_comment' => '如果論壇有第三方手機找回的應用插件，可啟用，請相關插件開發者協助設置',
	'logintpl_lostfindtype' => '是否優先顯示手機找回模式',
	'logintpl_lostfindtype_comment' => '選擇是用戶打開找回密碼頁麵，優先顯示手機找回模式',
	'logintpl_codeinterval' => '重新獲取短信碼時間(秒)',
	'logintpl_codeinterval_comment' => '兩次間獲取短信碼間隔秒數，一般為60秒',
	'logintpl_mobileformurl' => '找回密碼的URL請求地址',
	'logintpl_mobileformurl_comment' => '手機找回功能插件找回密碼請求URL地址',
	'logintpl_getmobilecodeurl' => '獲取驗證碼的URL請求地址',
	'logintpl_getmobilecodeurl_comment' => '手機找回功能插件獲取手機驗證碼的URL請求地址',
	'logintpl_ajaxdatatype' => '獲取驗證碼Ajax返回的數據類型',
	'logintpl_ajaxdatatype_comment' => '通過Ajax請求返回驗證碼的數據類型',
	'logintpl_ajaxdatatype_xml' => 'XML',
	'logintpl_ajaxdatatype_text' => 'TEXT',
	'logintpl_getcodesuccess' => '驗證碼獲取成功時的條件表達式',
	'logintpl_getcodesuccess_comment' => 'Ajax返回賦值變量為s，默認條件表達式為“s.indexOf(\'success\') != -1”，請務必填寫正確，例如：“ s == \'success\'”',
);