<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!应用中心 dism.taobao.com
 * Created: 2019-02-10
 * Version: 3.00225
 * Date: 2020-02-25 16:53:10
 * File: lang_logintpl.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$duceapp_compon_lang = array(
	'appver' => '1.5.3',
	'menu_order' => 9,
	'menu_title' => '模板配置',

	'anchors' => array(
		'tpl' => array('real' => 1, 'title' => '基本配置'),
		'style' => array('real' => 1, 'title' => '模板风格'),
		'bgimg' => array('real' => 1, 'title' => '模板背景图'),
		'icon' => array('real' => 1, 'title' => '图标设置'),
	),
	'style_common' => '通用页面',
	'style_logging' => '登录页面',
	'style_lostpw' => '第三方插件',

	'style_fontweight' => '通用字体粗细',
	'style_fontweight_0' => '极细字体',
	'style_fontweight_1' => '标准粗细',

	'logintpl_tpl_tips' => '<li>本组件提供一个手机版登录页面的模板，可以替换您当前使用的手机模板登录页面，并可随时恢复</li><li>设置参数替换模板后保存，您可在手机页面刷新查看，可反复设置，以达到最佳效果</li>',
	'logintpl_icon_tips' => '<li>插件是按Discuz!标准嵌入点置入登录或绑定图标，您可向模板开发者核对下列的嵌入点是否存在</li><li>如果您的手机模板没有Discuz!嵌入点，可在模板设置中选择替换模板操作，或前往<a href="http://www.duceapp.cn" target="_blank">火狼设计网站</a>提问</li>',
	'logintpl_bgimg_tips' => '<li>登录页面的背景图片配置，可将制作好的背景图片上传至服务器，多张图片可轮播展示</li><li>每次保存添加一张图片，最多可添加5张图片</li>',
	'logintpl_tpl_jsexists' => '<li><font color="#FF0000">缺少系统默认文件：<b>{jsexists}</b></font></li>',
	'logintpl_style_tips' => '<li>可通过下列设置风格参数设置个性登录页面，通用适配主题色请到基础插件全局设置>界面设置</li><li>通用适配主题色所涉及到的页面有，登录页面、用户中心微信设置页、登录确认页等</li>',
	'logintpl_action' => '请选择操作类型',
	'logintpl_style' => '当前手机版模板风格：{name}<br/ >当前登录页模板风格：{name}',
	'logintpl_style1' => '当前手机版模板风格：{name}<br/ >当前登录页模板风格：<font color="green">插件风格</font>',
	'logintpl_action_none' => '保持当前风格设置',
	'logintpl_action_replace' => '替换当前模板登录页',
	'logintpl_action_recove' => '恢复成模板原有页面',
	'logintpl_themecolor' => '通用主题色',
	'logintpl_themecolor_comment' => '包括头部背景、高亮线条、字体高亮颜色',
	'logintpl_textcolor' => '通用字体颜色',
	'logintpl_linkcolor' => '链接字体颜色',
	'logintpl_buttoncolor' => '通用按扭颜色',
	'logintpl_toplogo' => '登录页顶部LOGO',
	'logintpl_toplogo_comment' => '如果不填或不上传表示不显示，LOGO图片建议为png格式，请以页面宽度720px作为标准制作{img}',
	'logintpl_logoheight' => '登录页顶部LOGO高度(px)',
	'logintpl_logoheight_comment' => '默认60px，顶部LOGO高度，您可以设置后刷新登录页查看，调整到最佳效果',
	'logintpl_headopacity' => '登录页页头背景透明度',
	'logintpl_headopacity_comment' => '整数0到100，数值越高越透明，全透明请填写100，主题色请到基础插件全局设置>界面设置',
	'logintpl_opacity' => '透明度',
	'logintpl_iptbgcolor' => '登录页输入框背景色',
	'logintpl_iptbgcomment' => '登录页输入框背景色，透明度整数0到100，数值越高越透明，全透明请填写100',
	'logintpl_iptbdcolor' => '登录页表单边框颜色',
	'logintpl_iptbdcomment' => '表单边框颜色，透明度整数0到100，数值越高越透明，全透明请填写100',
	'logintpl_iptspacing' => '登录页表单输入框间距(px)',
	'logintpl_iptspacing_comment' => '如果设置了间距，表单边框线将全部透明化',
	'logintpl_fontcolor' => '登录页文字颜色',
	'logintpl_inputcolor' => '登录页输入框文字颜色',
	'logintpl_formmargin' => '登录页表单外边柜(px)',
	'logintpl_formmargin_comment' => '用户登录输入信息表单相对于设备边框的距离，如果登录页设置了背景图，建议设置为30',
	'logintpl_btncolor' => '按扭背景色',
	'logintpl_hidemobilebtn' => '是否隐藏手机版登录按扭',
	'logintpl_hidemobilebtn_comment' => '如果您当前使用的手机模板，需要手动修改微信登录按扭代码的，请选择隐藏；详情请查看图标设置的嵌入点',
	'logintpl_disinwechat' => '关闭非微信端登录按扭',
	'logintpl_disinwechat_comment' => '选择是否关闭用户在非微信浏览器的微信登录入口按扭',
	'logintpl_btn_method' => '电脑版登录页快捷按扭',
	'logintpl_method_comment' => '<span style="display:inline-block;height:30px;line-height:30px;width:300px;">页面嵌入点: hook/logging_method</span> {img}',
	'logintpl_btn_bind' => '电脑版顶部导航条绑定按扭',
	'logintpl_bind_comment' => '<span style="display:inline-block;height:30px;line-height:30px;width:300px;">页面嵌入点: hook/global_usernav_extra1</span> {img}',
	'logintpl_btn_bar' => '电脑版页头按扭',
	'logintpl_bar_comment' => '<span style="display:inline-block;height:30px;line-height:30px;width:300px;">页面嵌入点: hook/global_login_extra</span> {img}',
	'logintpl_btn_touch' => '手机版快捷登录按扭',
	'logintpl_touch_comment' => '<span style="display:inline-block;height:30px;line-height:30px;width:300px;">页面嵌入点: hook/logging_bottom_mobile</span> {img}',
	'logintpl_action_noexists' => '选择的操作模板和默认手机版模板不相符',
	'logintpl_noexists' => '当前手机模板文件夹{directory}/touch/member/没有登录页面login.htm文件<br /><br />请复制默认模板 template/default/touch/member/login.htm 到当前模板相对应的位置<br /><br />',
	'logintpl_induceapp' => '当前使用的是火狼手机模板系列无需替换',
	'logintpl_bgimg' => '背景图片',
	'logintpl_smsloginurl' => '手机登录页面链接',
	'logintpl_smsloginurl_comment' => '如果论坛有第三方手机登录插件，可填写相关插件登录页链接地址。',
	'logintpl_bgswitchtime' => '背景图片轮播间隔时间（毫秒）',
	'logintpl_bgswitchtime_comment' => '多张图片时，背景图片轮播间隔时间，默认为3500毫秒=3.5秒',
	'logintpl_lostformobile' => '启用第三方手机密码找回',
	'logintpl_lostformobile_comment' => '如果论坛有第三方手机找回的应用插件，可启用，请相关插件开发者协助设置',
	'logintpl_lostfindtype' => '是否优先显示手机找回模式',
	'logintpl_lostfindtype_comment' => '选择是用户打开找回密码页面，优先显示手机找回模式',
	'logintpl_codeinterval' => '重新获取短信码时间(秒)',
	'logintpl_codeinterval_comment' => '两次间获取短信码间隔秒数，一般为60秒',
	'logintpl_mobileformurl' => '找回密码的URL请求地址',
	'logintpl_mobileformurl_comment' => '手机找回功能插件找回密码请求URL地址',
	'logintpl_getmobilecodeurl' => '获取验证码的URL请求地址',
	'logintpl_getmobilecodeurl_comment' => '手机找回功能插件获取手机验证码的URL请求地址',
	'logintpl_ajaxdatatype' => '获取验证码Ajax返回的数据类型',
	'logintpl_ajaxdatatype_comment' => '通过Ajax请求返回验证码的数据类型',
	'logintpl_ajaxdatatype_xml' => 'XML',
	'logintpl_ajaxdatatype_text' => 'TEXT',
	'logintpl_getcodesuccess' => '验证码获取成功时的条件表达式',
	'logintpl_getcodesuccess_comment' => 'Ajax返回赋值变量为s，默认条件表达式为“s.indexOf(\'success\') != -1”，请务必填写正确，例如：“ s == \'success\'”',
);