<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!应用中心 dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: lang_invoke.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$duceapp_compon_lang = array(
	'appver' => 'built in',
	'menu_order' => 0,
	'menu_title' => '数据同步',

	'anchors' => array(
		'api' => array('real' => 2, 'title' => '接口设置'),
		'doc' => array('real' => 2, 'title' => '接口文档'),
	),

	'invoke_tips' => '<li>公众号基础Access_token是公众号的全局唯一接口调用凭据，避免业务失败，其他应用或插件使用到Access_token需统一调用</li><li>插件提供Access_token、Jsapi_ticket和微信用户数据的接口，有数据同步(例如<b>微信支付</b>)的需求，请联系相关开发者参阅本设置及<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin['pluginid'].'&pmod=compon&cmod=invoke&danchor=doc">接口文档</a></li><li>调用外部凭据PHP代码中可直接引用方法，GET方法：self::get(URL)，POST方法：self::post(URL, POSTDATA)，前后无需写&lt;?php 和 ?&gt;</li>',	
	'invoke_secret' => '插件接口密钥(Secret)',
	'invoke_secret_comment' => '如果接入设置选择授权回调方式，填写授权论坛的插件接口密钥，两者保持一致',
	'invoke_expires' => '接口凭据刷新模式',
	'invoke_expires_comment' => '本设置针对基础Access_token和Jsapi_ticket的刷新，默认是7200秒刷新一次，如果公众号有应用于其他非火狼出品应用，避免业务失败可设置实时刷新或自定义刷新时间',
	'invoke_expires_0' => '默认',
	'invoke_expires_1' => '实时刷新',
	'invoke_expires_2' => '自定义',
	'invoke_expires_in' => '接口凭据刷新秒数',
	'invoke_expires_in_comment' => '秒数请设置10~7200秒之间',
	'invoke_synbind' => '同步绑定微信的应用',
	'invoke_synbind_comment' => '您的UCenter下有多个应用，选择需要同步绑定微信的主应用URL（应用需安装相应的火狼微信插件），任意一个应用中有绑定了同一个微信，则同步激活同一ID帐号并自动绑定微信<br>按住 Ctrl 键可多选。',
	'invoke_token' => '调用外部(Access_token)的PHP代码',
	'invoke_token_comment' => '$res = self::get(API_URL); /* API_URL 为远程获取的地址 */<br />$res = json_decode($res, true); /* 例：$res 为远程返回的JSON数据 */<br />$res[\'token\'] = $res[\'access_token\']; /* 必须将返回的access_token数据赋值到$res[\'token\'] */',
	'invoke_ticket' => '调用外部(Jsapi_ticket)的PHP代码',
	'invoke_ticket_comment' => '$res = self::get(API_URL); /* API_URL 为远程获取的地址 */<br />$res = json_decode($res, true); /* 例：$res 为远程返回的JSON数据 */<br />$res[\'ticket\'] = $res[\'ticket\']; /* 必须将返回的ticket数据赋值到$res[\'ticket\'] */',
	'invoke_doc_tips' => '<li>下列为其他应用或插件调用本插件数据的开放接口，获取接口数据需要插件接口密钥(Secret)</li><li>接口传输方式：'.strtoupper($_G['scheme']).'，数据格式：JSON，签名算法：SHA1，字符编码：'.strtoupper(CHARSET).'</li>',
	'invoke_doc' => '
	<h1 class="msyh f16" style="color:#690;">[API] 获取公众号基础 ACCESS_TOKEN</h1>
	<p>
	请求方式：GET<br />
	URL地址：'.$_G['siteurl'].'source/plugin/duceapp_wechat/api.php?op=token&secret={插件接口密钥}<br />
	请求参数说明：
	</p>
	<table>
	<tr><th class="th1">变量名</th><th class="th2">必填</th><th class="th3">示例值</th><th>描述</th></tr>
	<tr><td>op</td><td>是</td><td>token</td><td>API固定值</td></tr>
	<tr><td>secret</td><td>是</td><td>n38IKIMql8K8iw399ZEk5UHw</td><td>插件接口密钥码</td></tr>
	</table>
	<p>返回结果：errcode值=0 时有返回 token 值</p>
	<table>
	<tr><th class="th1">变量名</th><th class="th2">类型</th><th class="th3">示例值</th><th>描述</th></tr>
	<tr><td>errcode</td><td>Int</td><td>0</td><td>成功：0，其它值为失败</td></tr>
	<tr><td>token</td><td>Sting</td><td>HoagFKDcsGMVCIY2vOjf9sdo...</td><td>ACCESS_TOKEN</td></tr>
	<tr><td>expiration</td><td>Sting</td><td>1532311201</td><td>下次刷新的时间戳</td></tr>
	</table>
	<h1 class="msyh f16" style="color:#690;">[API] 获取公众号 JSAPI_TICKET</h1>
	<p>
	请求方式：GET<br />
	URL地址：'.$_G['siteurl'].'source/plugin/duceapp_wechat/api.php?op=ticket&secret={插件接口密钥}<br />
	请求参数说明：
	</p>
	<table>
	<tr><th class="th1">变量名</th><th class="th2">必填</th><th class="th3">示例值</th><th>描述</th></tr>
	<tr><td>op</td><td>是</td><td>ticket</td><td>API固定值</td></tr>
	<tr><td>secret</td><td>是</td><td>n38IKIMql8K8iw399ZEk5UHw</td><td>插件接口密钥码</td></tr>
	</table>
	<p>返回结果：errcode值=0 时有返回 ticket 值</p>
	<table>
	<tr><th class="th1">变量名</th><th class="th2">类型</th><th class="th3">示例值</th><th>描述</th></tr>
	<tr><td>errcode</td><td>Int</td><td>0</td><td>成功：0，其它值为失败</td></tr>
	<tr><td>ticket</td><td>Sting</td><td>HoagFKDcsGMVCIY2vOjf9sdo...</td><td>JSAPI_TICKET</td></tr>
	<tr><td>expiration</td><td>Sting</td><td>1532311201</td><td>下次刷新的时间戳</td></tr>
	</table>
	<h1 class="msyh f16" style="color:#690;">[API] 获取用户绑定微信数据</h1>
	<p>
	请求方式：GET<br />
	URL地址：'.$_G['siteurl'].'source/plugin/duceapp_wechat/api.php?op=getuser&...<br />
	请求参数说明：
	</p>
	<table>
	<tr><th class="th1">变量名</th><th class="th2">必填</th><th class="th3">示例值</th><th>描述</th></tr>
	<tr><td>op</td><td>是</td><td>getuser</td><td>API固定值</td></tr>
	<tr><td>uid</td><td>openid 2选1</td><td>1</td><td>用户UID</td></tr>
	<tr><td>openid</td><td>uid 2选1</td><td>n38IKIMql8K8iw399ZEk5UHw</td><td>从微信获取的用户openid</td></tr>
	<tr><td>unionid</td><td>否</td><td>n38IKIMql8K8iw399ZEk5UHw</td><td>从微信获取的用户unionid</td></tr>
	<tr><td>timestamp</td><td>是</td><td>1532311201</td><td>当前时间戳</td></tr>
	<tr><td>nonce</td><td>是</td><td>G8QM004m</td><td>随机字符串</td></tr>
	<tr><td>signature</td><td>是</td><td>1e513cfcf108f7a0dc206956b1819197</td><td>sha1签名</td></tr>
	</table>
	<p>返回结果：</p>
	<table>
	<tr><th class="th1">变量名</th><th class="th2">类型</th><th class="th3">示例值</th><th>描述</th></tr>
	<tr><td>errcode</td><td>Int</td><td>0</td><td>成功：0，缺少参数：-2，签名错误：-1，未绑定微信：1</td></tr>
	<tr><td>uid</td><td>Int</td><td>1</td><td>用户UID</td></tr>
	<tr><td>subscribe</td><td>Int</td><td>1</td><td>用户是否关注公众号，非通过公众号登录: -1，未关注：0，已关注：1</td></tr>
	<tr><td>openid</td><td>String</td><td>o284w1ln0WHnv7DfjSFl1bUJNKtY</td><td>从微信获取的用户openid</td></tr>
	<tr><td>unionid</td><td>String</td><td>oDFwuxLQPPd6YH7_GeJF69VBfwCo</td><td>从微信获取的用户unionid</td></tr>
	<tr><td>isregister</td><td>Int</td><td>0</td><td>是否微信注册，否：0，是：1，是并已改用户名：2</td></tr>
	<tr><td>nickname</td><td>String</td><td>火狼</td><td>从微信获取的用户昵称</td></tr>
	<tr><td>sex</td><td>Int</td><td>1</td><td>从微信获取的用户性别，男：1，女：2</td></tr>
	<tr><td>dateline</td><td>Int</td><td>1532311201</td><td>用户绑定微信的时间戳</td></tr>
	<tr><td>lastauth</td><td>Int</td><td>1532311201</td><td>用户最后一次使用微信登录的时间戳</td></tr>
	<tr><td>lat</td><td>float</td><td>1.265356</td><td>用户定位经度值</td></tr>
	<tr><td>lng</td><td>float</td><td>1.265356</td><td>用户定位纬度值</td></tr>
	</table>
	<h1 class="msyh f16" style="color:#690;">[API] 绑定用户微信数据</h1>
	<p>
	请求方式：POST<br />
	URL地址：'.$_G['siteurl'].'source/plugin/duceapp_wechat/api.php<br />
	请求参数说明：
	</p>
	<table>
	<tr><th class="th1">变量名</th><th class="th2">必填</th><th class="th3">示例值</th><th>描述</th></tr>
	<tr><td>op</td><td>是</td><td>binduser</td><td>API固定值</td></tr>
	<tr><td>uid</td><td>是</td><td>1</td><td>用户UID</td></tr>
	<tr><td>subscribe</td><td>否</td><td>1</td><td>用户是否关注公众号，默认: -1，未关注：0，已关注：1</td></tr>
	<tr><td>openid</td><td>是</td><td>o284w1ln0WHnv7DfjSFl1bUJNKtY</td><td>从微信获取的用户openid</td></tr>
	<tr><td>unionid</td><td>否</td><td>oDFwuxLQPPd6YH7_GeJF69VBfwCo</td><td>从微信获取的用户unionid</td></tr>
	<tr><td>nickname</td><td>否</td><td>火狼</td><td>从微信获取的用户昵称</td></tr>
	<tr><td>sex</td><td>否</td><td>1</td><td>从微信获取的用户性别，男：1，女：2</td></tr>
	<tr><td>lat</td><td>否</td><td>1.265356</td><td>用户定位经度值</td></tr>
	<tr><td>lng</td><td>否</td><td>1.265356</td><td>用户定位纬度值</td></tr>
	<tr><td>timestamp</td><td>是</td><td>1532311201</td><td>当前时间戳</td></tr>
	<tr><td>nonce</td><td>是</td><td>G8QM004m</td><td>随机字符串</td></tr>
	<tr><td>signature</td><td>是</td><td>1e513cfcf108f7a0dc206956b1819197</td><td>sha1签名</td></tr>
	</table>
	<p>返回结果：</p>
	<table>
	<tr><th class="th1">变量名</th><th class="th2">类型</th><th class="th3">示例值</th><th>描述</th></tr>
	<tr><td>errcode</td><td>Int</td><td>0</td><td>绑定成功：0，缺少参数：-2，签名错误：-1，微信已被绑定：1</td></tr>
	</table>
	<h1 class="msyh f16" style="color:#09C;">[API] <font color="#FF0000">SHA1</font>签名方法</h1>
	<p>
	将插件接口密钥 Secret、op、timestamp、nonce的value值进行字符串的字典序排序。<br />
	将参数字符串拼接成一个字符串进行sha1加密，得到signature<br />
	例如：<br />
	参数 Secret=bbc、op=getuser、timestamp=abc、nonce=aaa<br />
	排序 sort(array(bbc,getuser,abc,aaa), SORT_STRING)，排序后的参数字符串拼接成一个字符串 aaaabcbbcgetuser<br />
	得到 signature = sha1(aaaabcbbcgetuser)
	</p>
	',
	'invoke_phpcode_invalid' => '调用外部({extapi})的PHP代码语法错误',
	'invoke_phpreturn_invalid' => '调用外部({extapi})的PHP代码错误，请把返回值用数组形式赋值到$res中',
	'invoke_accesstoken_invalid' => '调用外部(Access_Token)的返回值请赋值到$res[\'token\']中',
	'invoke_jsapiticket_invalid' => '调用外部(JsApi_Ticket)的返回值请赋值到$res[\'ticket\']中',
);