<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!应用中心 dism.taobao.com
 * Created: 2019-01-31
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: lang_editor.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

global $duceapp_editor;

$duceapp_editor = array(
	'nolocfile' => '未選擇文件',
	'example' => '<h2>友情提示：</h2>1、正文內容當前僅在群發消息或上傳到微信服務器可用到，如果素材僅作為自動響應信息或在公眾號菜單中作為引導消息，正文內容可忽略不填或僅填寫摘要內容。<br>2、正文內容HTML可暫時到<a href="http://www.wxb.com/editor" target="_blank">站外微信編輯器</a>編輯格式，完成後再拷貝源代碼粘到正文中。<br>3、本地素材可通過群發設置中新建群發信息，選擇上傳保存為微信服務器的永久素材。<br>4、插件將在後續版本中增加編輯器功能。',
	'undo' => '撤消',
	'redo' => '重做',
	'blockquote' => '引用',
	'horizontal' => '分隔線',
	'removeformat' => '清除格式',
	'formatmatch' => '格式刷',
	'link' => '超鏈接',
	'unlink' => '清除超鏈接',
	'fontsize' => '字體大小',
	'bold' => '加粗',
	'italic' => '斜體',
	'underline' => '下劃線',
	'forecolor' => '字體顏色',
	'backcolor' => '背景色',
);