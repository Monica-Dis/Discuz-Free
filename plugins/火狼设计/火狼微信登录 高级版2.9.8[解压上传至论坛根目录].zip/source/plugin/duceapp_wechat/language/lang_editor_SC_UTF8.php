<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!应用中心 dism.taobao.com
 * Created: 2019-01-31
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: lang_editor.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

global $duceapp_editor;

$duceapp_editor = array(
	'nolocfile' => '未选择文件',
	'example' => '<h2>友情提示：</h2>1、正文内容当前仅在群发消息或上传到微信服务器可用到，如果素材仅作为自动响应信息或在公众号菜单中作为引导消息，正文内容可忽略不填或仅填写摘要内容。<br>2、正文内容HTML可暂时到<a href="http://www.wxb.com/editor" target="_blank">站外微信编辑器</a>编辑格式，完成后再拷贝源代码粘到正文中。<br>3、本地素材可通过群发设置中新建群发信息，选择上传保存为微信服务器的永久素材。<br>4、插件将在后续版本中增加编辑器功能。',
	'undo' => '撤消',
	'redo' => '重做',
	'blockquote' => '引用',
	'horizontal' => '分隔线',
	'removeformat' => '清除格式',
	'formatmatch' => '格式刷',
	'link' => '超链接',
	'unlink' => '清除超链接',
	'fontsize' => '字体大小',
	'bold' => '加粗',
	'italic' => '斜体',
	'underline' => '下划线',
	'forecolor' => '字体颜色',
	'backcolor' => '背景色',
);