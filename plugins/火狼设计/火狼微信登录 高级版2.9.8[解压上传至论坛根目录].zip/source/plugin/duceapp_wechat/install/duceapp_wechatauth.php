<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2020-07-28
 * Version: 3.00806
 * Date: 2020-08-06 03:25:46
 * File: duceapp_wechatauth.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if ($_GET && $_GET['resite']) {
	$redirect = $_GET['resite'];
	unset($_GET['resite']);
	foreach($_GET as $k => $v) {
		$_GET[$k] = urlencode($v);
	}
	header('location:'.$redirect.'/source/plugin/duceapp_wechat/logging.php?'.http_build_query($_GET));
}
exit('Access Denied');