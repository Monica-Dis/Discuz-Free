<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00417
 * Date: 2020-08-06 03:25:46
 * File: initialize.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if(!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

global $_G, $duceapp_install;

require_once libfile('class/duceapp_wechathook', 'plugin/duceapp_wechat');

duceapp_wechat_initialize();

$responsehook = duceapp_wechathook::getResponse('duceapp_wechat');
$responsehook['receiveMsg::text'] = $responsehook['receiveMsg::text'] ? $responsehook['receiveMsg::text'] : array(
	'plugin' => 'duceapp_wechat', 
	'include' => 'class/class_duceapp_response.php', 
	'class' => 'duceapp_response', 
	'method' => 'text'
);
$responsehook['receiveEvent::click'] = $responsehook['receiveEvent::click'] ? $responsehook['receiveEvent::click'] : array(
	'plugin' => 'duceapp_wechat', 
	'include' => 'class/class_duceapp_response.php', 
	'class' => 'duceapp_response', 
	'method' => 'click'
);
$responsehook['receiveEvent::subscribe'] = $responsehook['receiveEvent::subscribe'] ? $responsehook['receiveEvent::subscribe'] : array(
	'plugin' => 'duceapp_wechat', 
	'include' => 'class/class_duceapp_response.php', 
	'class' => 'duceapp_response', 
	'method' => 'subscribe'
);
$responsehook['receiveEvent::unsubscribe'] = $responsehook['receiveEvent::unsubscribe'] ? $responsehook['receiveEvent::unsubscribe'] : array(
	'plugin' => 'duceapp_wechat', 
	'include' => 'class/class_duceapp_response.php', 
	'class' => 'duceapp_response',
	'method' => 'unsubscribe'
);
$responsehook['receiveEvent::scan'] = $responsehook['receiveEvent::scan'] ? $responsehook['receiveEvent::scan'] : array(
	'plugin' => 'duceapp_wechat', 
	'include' => 'class/class_duceapp_response.php', 
	'class' => 'duceapp_response',
	'method' => 'scan'
);
/*$responsehook['receiveEvent::location'] = $responsehook['receiveEvent::location'] ? $responsehook['receiveEvent::location'] : array(
	'plugin' => 'duceapp_wechat', 
	'include' => 'class/class_duceapp_response.php', 
	'class' => 'duceapp_response',
	'method' => 'location'
);*/
duceapp_wechathook::updateResponse($responsehook, 'duceapp_wechat');
$duceapp_install->flush_content('setting_receive');

if (empty($_G['cache']['duceapp_wechat'])) {
	$_G['duceapp_wechat'] = array(
		'token' => random(16),
		'vercat' => 'Pro',
		'jslogin' => 1,
		'allowregister' => 1,
		'allowfastregister' => 1,
		'disableregrule' => 1,
		'disinvitecode' => 1,
	);
}