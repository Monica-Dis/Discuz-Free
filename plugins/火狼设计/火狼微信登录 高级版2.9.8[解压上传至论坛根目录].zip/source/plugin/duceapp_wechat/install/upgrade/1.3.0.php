<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: 1.3.0.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if(!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

DB::query("ALTER TABLE %t ADD `subscribe` tinyint(1) NOT NULL DEFAULT '-1' AFTER `uid`", array('duceapp_wechat_member'));
DB::query("ALTER TABLE %t ADD `username` char(15) NOT NULL DEFAULT '' AFTER `unionid`", array('duceapp_wechat_member'));
DB::query("ALTER TABLE %t ADD `nickname` varchar(32) NOT NULL DEFAULT ''", array('duceapp_wechat_member'));
DB::query("ALTER TABLE %t ADD `sex` tinyint(1) unsigned NOT NULL DEFAULT '0'", array('duceapp_wechat_member'));
DB::query("ALTER TABLE %t ADD `dateline` int(10) unsigned NOT NULL DEFAULT '0'", array('duceapp_wechat_member'));
DB::query("ALTER TABLE %t ADD `lastauth` int(10) unsigned NOT NULL DEFAULT '0'", array('duceapp_wechat_member'));
DB::query("ALTER TABLE %t ADD `lat` float(10,6) NOT NULL", array('duceapp_wechat_member'));
DB::query("ALTER TABLE %t ADD `lng` float(10,6) NOT NULL", array('duceapp_wechat_member'));
DB::query("ALTER TABLE %t ADD `setting` blob NOT NULL", array('duceapp_wechat_member'));