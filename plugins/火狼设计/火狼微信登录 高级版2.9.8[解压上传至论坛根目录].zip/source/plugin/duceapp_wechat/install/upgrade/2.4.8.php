<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2020-04-19
 * Version: 3.00417
 * Date: 2020-08-06 03:25:46
 * File: 2.4.8.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if(!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$updatebatch = true;
$_G['cache']['duceapp_wechat']['disinvitecode'] = 1;