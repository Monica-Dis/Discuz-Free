<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: 1.5.0.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if(!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

DB::query("ALTER TABLE %t MODIFY `lat` float(10,6)", array('duceapp_wechat_member'));
DB::query("ALTER TABLE %t MODIFY `lng` float(10,6)", array('duceapp_wechat_member'));