<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: 1.8.0.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if(!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

//global $_G, $updatecache;

$updatebatch = true;

$setting = $_G['cache']['duceapp_wechat'];

dmkdir(DUCEAPP_DATAURL.'login/');

require_once libfile('class/duceapp_wechathook', 'plugin/duceapp_wechat');

$responsehook = duceapp_wechathook::getResponse('duceapp_wechat');

$responsehook['receiveMsg::text']['include'] = 'class/class_duceapp_response.php';
$responsehook['receiveEvent::click']['include'] = 'class/class_duceapp_response.php';
$responsehook['receiveEvent::subscribe']['include'] = 'class/class_duceapp_response.php';
$responsehook['receiveEvent::unsubscribe']['include'] = 'class/class_duceapp_response.php';
$responsehook['receiveEvent::scan']['include'] = 'class/class_duceapp_response.php';
if (isset($responsehook['receiveEvent::masssendjobfinish'])) {
	$responsehook['receiveEvent::masssendjobfinish']['include'] = 'class/class_duceapp_response.php';
}
if (isset($responsehook['receiveEvent::templatesendjobfinish'])) {
	$responsehook['receiveEvent::templatesendjobfinish']['include'] = 'class/class_duceapp_tmplsend.php';
	$responsehook['receiveEvent::templatesendjobfinish']['method'] = 'tmplsendfinish';
	$cache_tpllist = DISCUZ_ROOT.'./data/cache/cache_wechat_tpllist.php';
	$cache_shortlist = DISCUZ_ROOT.'./data/cache/cache_wechat_shortlist.php';
	if (file_exists($cache_tpllist)) {
		$filedata = file_get_contents($cache_tpllist);
		@file_put_contents(DISCUZ_ROOT.DUCEAPP_DATAURL.'tmplsend_tpllist.php', str_replace('$wechat_tpllist', '$tmplsend_tpllist', $filedata));
		@unlink($cache_tpllist);
	}
	if (file_exists($cache_shortlist)) {		
		$filedata = @file_get_contents($cache_shortlist);
		@file_put_contents(DISCUZ_ROOT.DUCEAPP_DATAURL.'tmplsend_shortlist.php', str_replace('$wechat_shortlist', '$tmplsend_shortlist', $filedata));
		@unlink($cache_shortlist);
	}
}

if (DB::result_first("SHOW TABLES LIKE '%".DB::table('duceapp_wechat_templatesend')."'")) {
	DB::query("RENAME TABLE %t TO %t", array('duceapp_wechat_templatesend', 'duceapp_wechat_tmplsend'));
}

if ($d = @dir($rescourcepath = DISCUZ_ROOT.'./data/cache/rescource/')) {
	dmkdir(DUCEAPP_DATAURL.'rescource/');
	while($file = $d->read()){
		if (is_file($rescourcepath.$file)){
			@rename($rescourcepath.$file, DISCUZ_ROOT.DUCEAPP_DATAURL.'rescource/'.$file);
		}
	}
	$d->close();
}

if ($d = @dir($loigntplpath = DISCUZ_ROOT.'./data/cache/logintpl/')) {
	while($file = $d->read()){
		if (is_file($loigntplpath.$file)) {
			if (preg_match('/\.(png|jpg|gif)$/i', $file)) {
				if (strpos($file, 'logintoplogo.') !== false) {
					$filenew = str_replace('logintoplogo.', 'toplogo.', $file);
					$_G['cache']['duceapp_wechat']['logintpl']['toplogo'] = DUCEAPP_DATAURL.'login/'.$filenew;
				} else {
					$filenew = $file;
				}
				@rename($loigntplpath.$file, DISCUZ_ROOT.DUCEAPP_DATAURL.'login/'.$filenew);
			} elseif ($file == 'extra.css') {
				@rename($loigntplpath.$file, DISCUZ_ROOT.DUCEAPP_DATAURL.'login_custom.css');
			}
		}
	}
	$d->close();
}

if ($setting['logintpl']['styleid']) {
	$defaultid2 = C::t('common_setting')->fetch('styleid2');	
	if ($setting['logintpl']['styleid'] == $defaultid2) {
		$stylearr = C::t('common_style')->fetch($defaultid2);
		$template = C::t('common_template')->fetch($stylearr['templateid']);
		$touchdir = DISCUZ_ROOT.$template['directory'].'/touch/member';
		if (($isphp = file_exists($touchdir.'/login.php')) || ($ishtm = file_exists($touchdir.'/login.htm'))) {
			$filepath = $touchdir.'/'.($isphp ? 'login.php' : 'login.htm');
			$bakfilepath = $touchdir.'/login_duceapp_bak.'.($isphp ? 'php' : 'htm');
			if (file_exists($bakfilepath) && file_exists(DUCEAPP_ROOT.'template/touch/logintpl.htm')) {
				$filedata = file_get_contents(DUCEAPP_ROOT.'template/touch/logintpl.htm');
				if ($isphp) {
					$filedata = "<?php exit('Access Denied @ duceapp.cn'); ?>\r\n".$filedata;
				}
				file_put_contents($filepath, $filedata);
				$tplcache = template('touch/member/login');
				@unlink($tplcache);
			}
		}
	}
}

if ($setting['logintpl']['bgimg']) {
	foreach ($setting['logintpl']['bgimg'] as $i => $filename) {
		if (strpos($filename, DUCEAPP_DATAURL) === false) {
			$_G['cache']['duceapp_wechat']['logintpl']['bgimg'][$i] = DUCEAPP_DATAURL.'login/'.$filename;
		}
	}
}

foreach(array('btn_method', 'btn_bind', 'btn_bar', 'btn_touch', 'btn_spacecp') as $key){
	if ($setting['logintpl'][$key] && file_exists(DUCEAPP_ROOT.'image/'.$setting['logintpl'][$key])) {
		$_G['cache']['duceapp_wechat']['logintpl'][$key] = DUCEAPP_DATAURL.'login/'.str_replace('custom_', '', $setting['logintpl'][$key]);
		@rename(DUCEAPP_ROOT.'image/'.$setting['logintpl'][$key], DISCUZ_ROOT.$_G['cache']['duceapp_wechat']['logintpl'][$key]);
	} elseif(isset($setting['logintpl'][$key])) {
		unset($setting['logintpl'][$key]);
	}
}

if ($setting['qrcode'] && file_exists(DUCEAPP_ROOT.'image/'.$setting['qrcode'])) {
	@rename(DUCEAPP_ROOT.'image/'.$setting['qrcode'], DISCUZ_ROOT.DUCEAPP_DATAURL.$setting['qrcode']);
}

if ($setting['subscribe']['qrcode'] && file_exists(DUCEAPP_ROOT.'image/'.$setting['subscribe']['qrcode'])) {
	@rename(DUCEAPP_ROOT.'image/'.$setting['subscribe']['qrcode'], DISCUZ_ROOT.DUCEAPP_DATAURL.$setting['subscribe']['qrcode']);
}

if ($setting['share']['logo'] && file_exists(DUCEAPP_ROOT.'image/'.$setting['share']['logo'])) {
	@rename(DUCEAPP_ROOT.'image/'.$setting['share']['logo'], DISCUZ_ROOT.DUCEAPP_DATAURL.'sharelogo.'.fileext($setting['share']['logo']));
	$_G['cache']['duceapp_wechat']['share']['logo'] = 'sharelogo.'.fileext($setting['share']['logo']);
}

if ($setting['exttoken'] && file_exists(DISCUZ_ROOT.'./data/cache/api/api_exttoken.php')) {
	dmkdir(DUCEAPP_DATAURL.'api/');
	$filedata = @file_get_contents(DISCUZ_ROOT.'./data/cache/api/api_exttoken.php');
	@file_put_contents(DISCUZ_ROOT.DUCEAPP_DATAURL.'api/token.php', str_replace(array('[exttoken]', '[/exttoken]'), array('[apitoken]', '[/apitoken]'), $filedata));
	$_G['cache']['duceapp_wechat']['apitoken'] = $setting['exttoken'];
}

if ($setting['extticket'] && file_exists(DISCUZ_ROOT.'./data/cache/api/api_extticket.php')) {
	dmkdir(DUCEAPP_DATAURL.'api/');
	$filedata = @file_get_contents(DISCUZ_ROOT.'./data/cache/api/api_extticket.php');
	@file_put_contents(DISCUZ_ROOT.DUCEAPP_DATAURL.'api/ticket.php', str_replace(array('[extticket]', '[/extticket]'), array('[apiticket]', '[/apiticket]'), $filedata));
	$_G['cache']['duceapp_wechat']['apiticket'] = $setting['extticket'];
}

if ($setting['tmplsend']) {
	@include duceapp_wechat_language('tmplsend');
	foreach($setting['tmplsend'] as $type => $value) {
		$value['cpname'] = $duceapp_compon_lang['actiontype_'.$type];
		$value['cpname_desc'] = $duceapp_compon_lang['actiontype_'.$type.'_cpdesc'];
		$_G['cache']['duceapp_wechat']['tmplsend'][$type] = $value;
	}
}

$_G['cache']['duceapp_wechat']['jslogin'] = 1;

duceapp_wechathook::updateResponse($responsehook, 'duceapp_wechat');