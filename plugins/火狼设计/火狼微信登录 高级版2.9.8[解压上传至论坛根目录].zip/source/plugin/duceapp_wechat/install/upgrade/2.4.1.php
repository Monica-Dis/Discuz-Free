<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2020-03-16
 * Version: 3.00316
 * Date: 2020-08-06 03:25:46
 * File: 2.4.1.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if(!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$field = C::t('#duceapp_wechat#duceapp_wechat_member')->fetch_all_field();

DB::query("ALTER TABLE %t CHANGE `unionid` `unionid` CHAR(32) DEFAULT NULL", array('duceapp_wechat_member'));
if ($field['unionid']['Key']) {
	DB::query("ALTER TABLE %t DROP INDEX `unionid`, ADD INDEX `unionid` (`unionid`) USING BTREE", array('duceapp_wechat_member'));
} else {
	DB::query("ALTER TABLE %t ADD INDEX (`unionid`)", array('duceapp_wechat_member'));
}