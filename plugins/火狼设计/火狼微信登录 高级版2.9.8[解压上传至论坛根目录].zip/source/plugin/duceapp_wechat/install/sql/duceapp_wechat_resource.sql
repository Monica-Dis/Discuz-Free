DROP TABLE IF EXISTS `cdb_duceapp_wechat_resource`;
CREATE TABLE IF NOT EXISTS `cdb_duceapp_wechat_resource` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `dateline` int(10) unsigned NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
)