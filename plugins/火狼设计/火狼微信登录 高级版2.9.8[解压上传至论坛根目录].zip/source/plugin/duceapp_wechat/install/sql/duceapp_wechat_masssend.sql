DROP TABLE IF EXISTS `cdb_duceapp_wechat_masssend`;
CREATE TABLE IF NOT EXISTS `cdb_duceapp_wechat_masssend` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` char(5) NOT NULL,
  `name` varchar(255) NOT NULL,
  `resource_id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned NOT NULL,
  `text` text,
  `media_id` char(64) DEFAULT '',
  `created_at` int(10) unsigned NOT NULL,
  `sent_at` int(10) unsigned DEFAULT NULL,
  `msg_id` int(10) unsigned DEFAULT NULL,
  `res_status` varchar(50) DEFAULT NULL,
  `res_totalcount` int(10) DEFAULT NULL,
  `res_filtercount` int(10) DEFAULT NULL,
  `res_sentcount` int(10) DEFAULT NULL,
  `res_errorcount` int(10) DEFAULT NULL,
  `res_finish_at` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
)