DROP TABLE IF EXISTS `cdb_duceapp_wechat_member`;
CREATE TABLE IF NOT EXISTS `cdb_duceapp_wechat_member` (
  `uid` mediumint(8) unsigned NOT NULL,
  `subscribe` tinyint(1) NOT NULL DEFAULT '-1',
  `openid` char(32) NOT NULL DEFAULT '',
  `unionid` char(32) DEFAULT NULL,
  `username` char(15) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `isregister` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `nickname` varchar(32) NOT NULL DEFAULT '',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  `lastauth` int(10) unsigned NOT NULL DEFAULT '0',
  `lat` float(10,6) NOT NULL,
  `lng` float(10,6) NOT NULL,
  `setting` blob NOT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `openid` (`openid`),
  INDEX (`unionid`)
);