<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: apievent.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.81125
 * Date: 2019-01-19 21:04:42
 * File: apievent.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once libfile('class/duceapp_admincp', 'plugin/duceapp_wechat');
require_once libfile('class/duceapp_wechathook', 'plugin/duceapp_wechat');
require_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');

class duceapp_modcp extends duceapp_admincp
{
	public function __construct() {
		$this->header();

		if ($checkmethod = $_GET['op']) {
			ajaxshowheader();
			if (method_exists($this, $checkmethod)){
				call_user_func(array(__CLASS__, $checkmethod));
			}
			ajaxshowfooter();
		}
		call_user_func(array(__CLASS__, $this->cpmethod));

		$this->footer();
	}

	private function main() {
		global $_G, $lang;

		$response = duceapp_wechathook::getResponse('duceapp_wechat');
		showtableheader(duceapp_cplang('apievent_wechat'));
		echo '<tr class="header"><th style="width:280px">'.duceapp_cplang('apievent_hook').'</th><th>'.duceapp_cplang('apievent_method').'</th></tr>';
		foreach($response as $k => $row) {
			if(!$plugins[$row['plugin']]) {
				$deleteresponses[$k] = array();
			}
			list(, $event) = explode('::', $k);
			echo '<tr class="hover"><td>'.duceapp_cplang('apievent_'.$k).'('.$event.')</td><td><b>File:</b> '.$row['include'].' <b>Method:</b> '.$row['class'].'->'.$row['method'].'</td></tr>';
		}
		showtablefooter();/*dis'.'m.tao'.'bao.com*/
		showtableheader('<span style="cursor:pointer" __onclick="check_apievent()">'.duceapp_cplang('apievent_server').'</span>');
		showtagheader('tbody', 'apievent_list', true);
		showtablerow('', array('style="width:280px"', 'class="apievtrow"'), array(
			'<strong>Addon Licensed</strong>',
			'<span id="addon_check">' . duceapp_cplang('apievent_time_check', array('imgdir' => $_G['style']['imgdir'])) .'</span>',
		));
		showtablerow('', array('style="width:280px"', 'class="apievtrow"'), array(
			'<strong>'.duceapp_cplang('apievent_dns').'</strong>',
			$this->check_dns('api.weixin.qq.com') ? duceapp_cplang('apievent_result_success').' '.$lang['available'] : duceapp_cplang('apievent_result_failure').' '.duceapp_cplang('apievent_dns_failure').' : api.weixin.qq.com'
		));
		if (!function_exists('curl_init')|| !function_exists('curl_exec')) {
			$curlcheckstr = 'curl_init or curl_exec is disabled';
		} else {
			$curl_version = curl_version();
			$ssl_version = isset($curl_version['ssl_version']) ? $curl_version['ssl_version'] : "";
			if (!$ssl_version) {
				$curlcheckstr = "miss SSL , curl_version:$ssl_version";
			}
		}
		showtablerow('', array('style="width:280px"', 'class="apievtrow"'), array(
			'<strong>CURL</strong>',
			(!$curlcheckstr ? duceapp_cplang('apievent_result_success').' '.$curl_version['version'].' , '.$curl_version['ssl_version'].' , '.'protocols: '.implode(',', $curl_version['protocols']) : duceapp_cplang('apievent_result_failure').$curlcheckstr)
		));
		showtablerow('', array('style="width:280px"', 'class="apievtrow"'), array(
			'<strong>Token</strong>',
			'<span id="token_check">' . duceapp_cplang('apievent_time_check', array('imgdir' => $_G['style']['imgdir'])) .'</span>',
		));
		showtablerow('', array('style="width:280px"', 'class="apievtrow"'), array(
			'<strong>AccessToken</strong>',
			'<span id="accesstoken_check">' . duceapp_cplang('apievent_time_check', array('imgdir' => $_G['style']['imgdir'])) .'</span>',
		));
		showtablerow('', array('style="width:280px"', 'class="apievtrow"'), array(
			'<strong>JsApiTicket</strong>',
			'<span id="jsapiticket_check">' . duceapp_cplang('apievent_time_check', array('imgdir' => $_G['style']['imgdir'])) .'</span>',
		));
		showtablerow('', array('style="width:280px"', 'class="apievtrow"'), array(
			'<strong>'.duceapp_cplang('apievent_posthttps').'</strong>',
			'<span id="posthttps_check">' . duceapp_cplang('apievent_time_check', array('imgdir' => $_G['style']['imgdir'])) .'</span>',
		));
		showtablerow('', array('class="td24"'), array(
    		'<strong>'.duceapp_cplang('apievent_avatar').'</strong>',
    		function_exists('gd_info') && is_writable($_G['setting']['attachdir'].'/temp/') ? duceapp_cplang('apievent_result_success').' '.$lang['available'] : duceapp_cplang('apievent_result_failure').duceapp_cplang('apievent_gdavt_error', array('path' => $_G['setting']['attachdir'].'/temp/'))
		));
		showtagfooter('tbody');
		showtablefooter();/*dis'.'m.tao'.'bao.com*/
		showtableheader();
		if ($this->setting['enable']) {
			showtitle(duceapp_cplang('apievent_access'));
			echo '<tr class="header"><th style="width:280px">'.cplang('type').'</th><th style="width:150px">AppId</th><th>AppSecret</th></tr>';
			if ($this->setting['mtype']) {
				echo '<tr class="hover"><td>'.duceapp_cplang('apievent_access_mp'.$this->setting['mtype']).'</td><td>'.$this->setting['mp']['appid'].'</td><td>'.duceapp_cutencrypt($this->setting['mp']['appsecret']).'</td></tr>';
			}
			if ($this->setting['qrtype']) {
				echo '<tr class="hover"><td>'.duceapp_cplang('access_open').'</td><td>'.$this->setting['open']['appid'].'</td><td>'.duceapp_cutencrypt($this->setting['open']['appsecret']).'</td></tr>';
			}
		}
		showtablefooter();/*dis'.'m.tao'.'bao.com*/
		echo '
		<script type="text/javascript">
		var apievent_check_enabled = false;
		function check_apievent() {
			$(\'apievent_list\').style.display = \'\';
			if (apievent_check_enabled) {
				return;
			}
			apievent_check_enabled = true;
			ajaxget(\''.$this->redirect.'&op=check_Addon\');
			ajaxget(\''.$this->redirect.'&op=check_Token\');
			ajaxget(\''.$this->redirect.'&op=check_AccessToken\');
			ajaxget(\''.$this->redirect.'&op=check_JsApiTicket\');
			ajaxget(\''.$this->redirect.'&op=check_postHttps\');
		};check_apievent();
		var refresh_time = Date.now || function(){return + new Date};
		function refresh_tokenticket(o){
			var t=o.getAttribute(\'toid\');
			$(\'refresh_\'+t).innerHTML = \''.duceapp_cplang('apievent_time_check', array('imgdir' => $_G['style']['imgdir'])).'\';
			ajaxget(\''.$this->redirect.'&op=refresh_\'+t+\'&t=\'+refresh_time());
		}
		</script>';
	}

	private function save() {
		duceapp_cpmsg();
	}

	function check_Addon() {
		$dateline = duceapp_wechat_addoncheck();
		if ($dateline = false) {
			echo '<script>$(\'addon_check\').innerHTML = \''.duceapp_cplang('apievent_result_failure').' '.duceapp_cplang('apievent_check_invalid').' ('.'<a href="https://dism.taobao.com/?@duceapp_wechat.plugin">'.duceapp_cplang('apievent_addon_nolicensed').'</a>)\';</script>';
		} else {
			$dateline = $dateline ? ' ('.duceapp_cplang('apievent_check_revisiondateline', array('date'=>dgmdate($dateline, 'Y-m-d'))).')' : '';
			echo '<script>$(\'addon_check\').innerHTML = \''.duceapp_cplang('apievent_result_success').' '.duceapp_cplang('apievent_check_fine').' '.duceapp_cplang('appvercat').$dateline.'\';</script>';
		}
	}

	function check_Token() {
		global $_G;		
		$token = $this->setting['token'];
		$timestamp = TIMESTAMP;
		$nonce = random(8, true);
		$echostr = random(20);
		$tmpArr = array($token, $timestamp, $nonce);
		sort($tmpArr, SORT_STRING);
		$tmpStr = implode($tmpArr);
		$signature = sha1($tmpStr);
		$url = $_G['siteurl'].$this->access_server.'?timestamp='.$timestamp.'&nonce='.$nonce.'&echostr='.$echostr.'&signature='.$signature;
		$data = duceapp_wechatclient::get($url);
		if ($_G['setting']['bbclosed']) {
			echo '<script>$(\'token_check\').innerHTML = \''.duceapp_cplang('apievent_result_failure').' '.duceapp_cplang('apievent_check_invalid').' ('.'<a href="?action=setting&operation=basic">'.cplang('setting_basic_bbclosed').'</a>)\';</script>';
		} else if($data == $echostr) {
			echo '<script>$(\'token_check\').innerHTML = \''.duceapp_cplang('apievent_result_success').' <a href="'.$url.'" target="_blank">'.duceapp_cplang('apievent_check_fine').'</a>\';</script>';
		} else {
			echo '<script>$(\'token_check\').innerHTML = \''.duceapp_cplang('apievent_result_failure').' <a href="'.$url.'" target="_blank">'.duceapp_cplang('apievent_check_invalid').'</a>\';</script>';
		}
	}

	function refresh_AccessToken() {
		$wechat_client = new duceapp_wechatclient('mp');
		$res = $wechat_client->getAccessToken(0, 0, 1);
		if ($wechat_client->checkIsSuc($res)) {
			echo '<script>$(\'refresh_AccessToken\').innerHTML = \'<span style="display:inline-block;width:350px;" class="vm duceapp_elli">'.$res['token'].'</span> '.($res['expiration'] ? '('.duceapp_cplang('apievent_accesstoken_expiration').': '.dgmdate($res['expiration'], 'Y-m-d H:i').')' : '').'\';</script>';
		} else {
			echo '<script>$(\'refresh_AccessToken\').innerHTML = \''.$wechat_client->error().'\';</script>';
		}
	}

	function refresh_JsApiTicket() {
		$wechat_client = new duceapp_wechatclient('mp');
		$res = $wechat_client->getJsApiTicket(0, 1);
		if ($wechat_client->checkIsSuc($res)) {
			echo '<script>$(\'refresh_JsApiTicket\').innerHTML = \'<span style="display:inline-block;width:350px;" class="vm duceapp_elli">'.$res['ticket'].'</span> '.($res['expiration'] ? '('.duceapp_cplang('apievent_accesstoken_expiration').': '.dgmdate($res['expiration'], 'Y-m-d H:i').')' : '').'\';</script>';
		} else {
			echo '<script>$(\'refresh_JsApiTicket\').innerHTML = \''.$wechat_client->error().'\';</script>';
		}
	}

	function check_AccessToken() {
		if (!$this->setting['mp']) {
			echo '<script>$(\'accesstoken_check\').innerHTML = \''.duceapp_cplang('apievent_result_failure').' '.duceapp_cplang('apievent_accesstoken_noapp').'\';</script>';
		} else {
			register_shutdown_function(array($this, 'check_shutdown', 'accesstoken_check'));
			$wechat_client = new duceapp_wechatclient($this->setting['mp']['appid'], $this->setting['mp']['appsecret']);
			$res = $wechat_client->getAccessToken(0);
			if ($wechat_client->checkIsSuc($res)) {
				echo '<script>$(\'accesstoken_check\').innerHTML = \''.duceapp_cplang('apievent_result_success').' <a href="javascript:;" onclick="refresh_tokenticket(this)" toid="AccessToken">'.duceapp_cplang('refresh').'</a> <span id="refresh_AccessToken"><span style="display:inline-block;width:350px;" class="vm duceapp_elli">'.$res['token'].'</span> '.($res['expiration'] ? '('.duceapp_cplang('apievent_accesstoken_expiration').': '.dgmdate($res['expiration'], 'Y-m-d H:i').')' : '').'</span>\';</script>';
			} else {
				echo '<script>$(\'accesstoken_check\').innerHTML = \''.duceapp_cplang('apievent_result_failure').' <a href="javascript:;" onclick="refresh_tokenticket(this)" toid="AccessToken">'.duceapp_cplang('refresh').'</a> '.$wechat_client->error().'\';</script>';
			}
		}
	}

	function check_JsApiTicket() {
		if (!$this->setting['mp']) {
			echo '<script>$(\'jsapiticket_check\').innerHTML = \''.duceapp_cplang('apievent_result_failure').' '.duceapp_cplang('apievent_accesstoken_noapp').'\';</script>';
		} else {
			register_shutdown_function(array($this, 'check_shutdown', 'jsapiticket_check'));
			$wechat_client = new duceapp_wechatclient($this->setting['mp']['appid'], $this->setting['mp']['appsecret']);
			$res = $wechat_client->getJsApiTicket(0);
			if ($res === '') {
				echo '<script>$(\'jsapiticket_check\').innerHTML = \''.duceapp_cplang('apievent_result_failure').' '.duceapp_cplang('apievent_accesstoken_error').'\';</script>';
			} elseif ($wechat_client->checkIsSuc($res)) {
				echo '<script>$(\'jsapiticket_check\').innerHTML = \''.duceapp_cplang('apievent_result_success').' <a href="javascript:;" onclick="refresh_tokenticket(this)" toid="JsApiTicket">'.duceapp_cplang('refresh').'</a> <span id="refresh_JsApiTicket"><span style="display:inline-block;width:350px;" class="vm duceapp_elli">'.$res['ticket'].'</span> '.($res['expiration'] ? '('.duceapp_cplang('apievent_accesstoken_expiration').': '.dgmdate($res['expiration'], 'Y-m-d H:i').')' : '').'</span>\';</script>';
			} else {
				echo '<script>$(\'jsapiticket_check\').innerHTML = \''.duceapp_cplang('apievent_result_success').' <a href="javascript:;" onclick="refresh_tokenticket(this)" toid="JsApiTicket">'.duceapp_cplang('refresh').'</a> '.$wechat_client->error().'\';</script>';
			}
		}
	}

	function check_postHttps() {
		register_shutdown_function(array($this, 'check_shutdown', 'posthttps_check'));
		$wechat_client = new duceapp_wechatclient($this->setting['mp']['appid'], $this->setting['mp']['appsecret']);
		$access_token = $wechat_client->getAccessToken();
		$url = duceapp_wechatclient::$_URL_API_ROOT."/cgi-bin/message/template/send?access_token=$access_token";
		$json = json_encode(array('touser' => 1,'template_id' => 2,'topcolor' => '#FFFFFF', 'data' => array()));
		$res = duceapp_wechatclient::post($url, $json);
		if ($res['errcode']) {
			echo '<script>$(\'posthttps_check\').innerHTML = \''.duceapp_cplang('apievent_result_success').' '.cplang('available').'\';</script>';
		} else {
			if (!function_exists('curl_init')|| !function_exists('curl_exec')) {
				$errmsg = 'curl_init or curl_exec is disabled';
			} else {
				$curl_version = curl_version();
				$ssl_version = isset($curl_version['ssl_version']) ? $curl_version['ssl_version'] : "";
				if (!$ssl_version) {
					$errmsg = "miss SSL , curl_version:$ssl_version";
				}
			}
			if ($errmsg) {
				echo '<script>$(\'posthttps_check\').innerHTML = \''.duceapp_cplang('apievent_result_failure').' '.$errmsg.'\';</script>';
			} else {
				echo '<script>$(\'posthttps_check\').innerHTML = \''.duceapp_cplang('apievent_result_success').' '.cplang('available').'\';</script>';
			}
		}
	}

	function check_shutdown($id) {
		$error = error_get_last();
		if ($error['type'] &~ E_NOTICE &~ E_DEPRECATED) {
			ob_end_clean();
			ajaxshowheader();
			echo '<script>$(\''.$id.'\').innerHTML = "<img align=\'absmiddle\' src=\'static/image/admincp/cloud/wrong.gif\' /> '.$error['type'].': '.$error['message'].'";</script>';
			ajaxshowfooter();
		}
	}

	function check_dns($url) {
		if (empty($url)) {
			return false;
		}
		$matches = parse_url($url);
		$host = !empty($matches['host']) ? $matches['host'] : $matches['path'];
		if (!$host) {
			return false;
		}
		$ip = gethostbyname($host);
		if ($ip == $host) {
			return false;
		} else {
			return $ip;
		}
	}
}
new duceapp_modcp;