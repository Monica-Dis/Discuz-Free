<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2019-02-10
 * Version: 3.91219
 * Date: 2020-02-25 16:53:09
 * File: logintpl.class.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

class duceapp_compon_logintpl
{
	public function init(){
		$this->componvar = & $this->setting['logintpl'];
		duceapp_showanchors();
		call_user_func(array(__CLASS__, $this->cpmethod));
	}

	private function main() {
		global $_G;

		$defaultid2 = C::t('common_setting')->fetch('styleid2');
		$stylearr = C::t('common_style')->fetch($defaultid2);
		$logintpl_tpl_tips = duceapp_cplang('logintpl_tpl_tips');
		$jsfile_exists = array();
		if (version_compare($_G['setting']['version'], 'X3.2') > 0) {
			if (!file_exists(DISCUZ_ROOT.STATICURL.'js/mobile/jquery.min.js')) {
				$jsfile_exists[] = STATICURL.'js/mobile/jquery.min.js';
			}
		} elseif (!file_exists(DISCUZ_ROOT.STATICURL.'js/mobile/jquery-1.8.3.min.js')) {
			$jsfile_exists[] = STATICURL.'js/mobile/jquery-1.8.3.min.js';
		}
		if (!file_exists(DISCUZ_ROOT.STATICURL.'js/mobile/common.js')) {
			$jsfile_exists[] = STATICURL.'js/mobile/common.js';
		}
		if ($jsfile_exists) {
			$logintpl_tpl_tips .= duceapp_cplang('logintpl_tpl_jsexists', array('jsexists' => implode(' , ', $jsfile_exists)));
		}
		duceapp_anchortips($logintpl_tpl_tips, 'tpl');
		duceapp_anchortips('logintpl_icon_tips', 'icon');
		duceapp_anchortips('logintpl_bgimg_tips', 'bgimg');
		duceapp_anchortips('logintpl_style_tips', 'style');
		duceapp_headscript('sortable');
		duceapp_formheader('enctype');

		duceapp_anchorheader('tpl');
		duceapp_showsetting('logintpl_action', array('logintplact', array(
			array('none', duceapp_cplang('logintpl_action_none'), array('hidebtn' => '')),
			array($defaultid2, duceapp_cplang('logintpl_action_replace'), array('hidebtn' => 'none')),
			array('recove', duceapp_cplang('logintpl_action_recove'), array('hidebtn' => '')),
		), 0), 'none', 'mradio', '', 0, duceapp_cplang($this->componvar['styleid'] == $defaultid2 ? 'logintpl_style1' : 'logintpl_style', $stylearr));
		showtagheader('tbody', 'hidebtn', 1);
		duceapp_showsetting('logintpl_hidemobilebtn', 'logintpl[hidemobilebtn]', $this->componvar['hidemobilebtn']);
		showtagfooter('tbody');
		duceapp_showsetting('logintpl_disinwechat', 'logintpl[disinwechat]', $this->componvar['disinwechat']);
		showsubmit('wechatsave', 'submit');
		duceapp_anchorfooter();

		$style = $this->componvar['style'];		
		$toplogo = $this->componvar['toplogo'] ? '<br><input type="checkbox" class="checkbox" name="deltoplogo" value="1">'.cplang('delete').' <img src="'.$this->componvar['toplogo'].'" style="height:30px;vertical-align:middle" />' : '';
		$tabs = array('style_common', 'style_logging', 'style_lostpw');
		$subtab = $_GET['subtab'] ? $_GET['subtab'] : $tabs[0];
		duceapp_anchortabs('style', $tabs, $subtab);
		duceapp_showtagheader('div', 'style');
		$theme_styles = duceapp_initcommoncss();
		duceapp_anchorheader('subtab_style_common', $subtab == 'style_common');
		duceapp_showsetting('logintpl_themecolor', 'theme_styles[themecolor]', $theme_styles['themecolor'], 'color');
		duceapp_showsetting('logintpl_textcolor', 'theme_styles[textcolor]', $theme_styles['textcolor'], 'color');
		duceapp_showsetting('logintpl_linkcolor', 'theme_styles[linkcolor]', $theme_styles['linkcolor'], 'color');
		duceapp_showsetting('logintpl_buttoncolor', 'theme_styles[buttoncolor]', $theme_styles['buttoncolor'], 'color');
		duceapp_showsetting('style_fontweight', array('theme_styles[fontweight]', array(
			array(0, duceapp_cplang('style_fontweight_0')),
			array(1, duceapp_cplang('style_fontweight_1')),
		), 1), intval($theme_styles['fontweight']), 'mradio');
		showsubmit('wechatsave', 'submit');
		duceapp_anchorfooter();
		duceapp_anchorheader('subtab_style_logging', $subtab == 'style_logging');
		duceapp_showsetting('logintpl_toplogo', 'toplogo', '', 'filetext', '', 0, duceapp_cplang('logintpl_toplogo_comment', array('img' => $toplogo)));
		duceapp_showsetting('logintpl_logoheight', 'style[logoheight]', $style['logoheight'], 'text');
		duceapp_showsetting('logintpl_headopacity', 'style[headopacity]', $style['headopacity'], 'text');
		duceapp_showsetting('logintpl_formmargin', 'style[formmargin]', $style['formmargin'], 'text');
		duceapp_showsetting('
			<div style="float:left;width:170px;">'.duceapp_cplang('logintpl_iptbgcolor').':</div>'.duceapp_cplang('logintpl_opacity').':', '', '', '
			<div style="float:left;">'.duceapp_showcolorinput('style[iptbgcolor]', $style['iptbgcolor'], null, 'float:left;width:90px;').'</div>
			<div style="float:left;text-align:center;width:33px;">&nbsp;</div>
			<div style="float:left;"><input name="style[iptbgopacity]" value="'.$style['iptbgopacity'].'" type="text" style="width:80px;" class="txt"></div>',
			'', 0, duceapp_cplang('logintpl_iptbgcomment').'
		');
		duceapp_showsetting('
			<div style="float:left;width:170px;">'.duceapp_cplang('logintpl_iptbdcolor').':</div>'.duceapp_cplang('logintpl_opacity').':', '', '', '
			<div style="float:left;">'.duceapp_showcolorinput('style[iptbdcolor]', $style['iptbdcolor'], null, 'float:left;width:90px;').'</div>
			<div style="float:left;text-align:center;width:33px;">&nbsp;</div>
			<div style="float:left;"><input name="style[iptbdopacity]" value="'.$style['iptbdopacity'].'" type="text" style="width:80px;" class="txt"></div>',
			'', 0, duceapp_cplang('logintpl_iptbdcomment').'
		');
		duceapp_showsetting('logintpl_iptspacing', 'style[iptspacing]', $style['iptspacing'], 'text');
		duceapp_showsetting('logintpl_fontcolor', 'style[fontcolor]', $style['fontcolor'], 'color');
		duceapp_showsetting('logintpl_inputcolor', 'style[inputcolor]', $style['inputcolor'], 'color');
		duceapp_showsetting('logintpl_btncolor', 'style[btncolor]', $style['btncolor'], 'color');
		showsubmit('wechatsave', 'submit');
		duceapp_anchorfooter();
		duceapp_anchorheader('subtab_style_lostpw', $subtab == 'style_lostpw');
		duceapp_showsetting('logintpl_smsloginurl', 'smsloginurl', $this->componvar['smsloginurl'], 'text');
		duceapp_showsetting('logintpl_lostformobile', 'lostformobile', $this->componvar['lostformobile'], 'radio', '', 1);
		duceapp_showsetting('logintpl_lostfindtype', 'lostfindtype', $this->componvar['lostfindtype']);
		duceapp_showsetting('logintpl_mobileformurl', 'mobileformurl', $this->componvar['mobileformurl'], 'text');
		duceapp_showsetting('logintpl_getmobilecodeurl', 'getmobilecodeurl', $this->componvar['getmobilecodeurl'], 'text');
		duceapp_showsetting('logintpl_codeinterval', 'codeinterval', $this->componvar['codeinterval'] > 0 ? $this->componvar['codeinterval'] : 60, 'text');
		duceapp_showsetting('logintpl_ajaxdatatype', array('ajaxdatatype', array(
			array('xml', duceapp_cplang('logintpl_ajaxdatatype_xml')),
			array('text', duceapp_cplang('logintpl_ajaxdatatype_text')),
		), 1), $this->componvar['ajaxdatatype'] == 'text' ? $this->componvar['ajaxdatatype'] : 'xml', 'mradio');
		duceapp_showsetting('logintpl_getcodesuccess', 'getcodesuccess', $this->componvar['getcodesuccess'], 'text');
		showtagfooter('tbody');
		showsubmit('wechatsave', 'submit');
		duceapp_anchorfooter();
		showtagfooter('div');

		$btn_method = '<img src="'.($this->componvar['btn_method'] ? $this->componvar['btn_method'] : DUCEAPP_DIRURL.'static/image/btn_login.png').'" style="vertical-align:middle" />';
		$btn_bind = '<img src="'.($this->componvar['btn_bind'] ? $this->componvar['btn_bind'] : DUCEAPP_DIRURL.'static/image/btn_bind.png').'" style="vertical-align:middle" />';
		$btn_bar = '<img src="'.($this->componvar['btn_bar'] ? $this->componvar['btn_bar'] : DUCEAPP_DIRURL.'static/image/btn_login.png').'" style="vertical-align:middle" />';
		$btn_touch = '<img src="'.($this->componvar['btn_touch'] ? $this->componvar['btn_touch'] : DUCEAPP_DIRURL.'static/image/btn_login2.png').'" style="height:30px;vertical-align:middle" />';
		duceapp_anchorheader('icon');
		duceapp_showsetting('logintpl_btn_bind', 'btn_bind', '', 'file', '', 0, duceapp_cplang('logintpl_bind_comment', array('img' => $btn_bind)));
		duceapp_showsetting('logintpl_btn_bar', 'btn_bar', '', 'file', '', 0, duceapp_cplang('logintpl_bar_comment', array('img' => $btn_bar)));
		duceapp_showsetting('logintpl_btn_method', 'btn_method', '', 'file', '', 0, duceapp_cplang('logintpl_method_comment', array('img' => $btn_method)));
		duceapp_showsetting('logintpl_btn_touch', 'btn_touch', '', 'file', '', 0, duceapp_cplang('logintpl_touch_comment', array('img' => $btn_touch)));
		showsubmit('wechatsave', 'submit');
		duceapp_anchorfooter();

		$bgimg = '<div id="wechatbgimg" class="cl">';
		if ($this->componvar['bgimg']){
			foreach($this->componvar['bgimg'] as $i => $file){
				$bgimg .= '<div class="e" style="float:left;position:relative;width:68px;height:120px;margin-right:20px;margin-bottom:20px;"><div style="width:68px;height:120px;text-align:center;overflow:hidden;cursor:move;" class="em"><img src="'.$file.'" style="width:68px;height:auto;"></div><input style="display:none;" type="checkbox" class="checkbox" name="bgimglist[]" value="'.$file.'" checked><div style="position:absolute;width:20px;height:20px;line-height:20px;text-align:center;overflow:hidden;border-radius:50%;top:-8px;right:-8px;background:#fff;cursor:pointer;" onclick="delbgimg(this)" class="checked"><em class="duceapp_font" style="font-size:20px;color:#f00;">&#xe94e;</em></div></div>';
			}			
		}
		$bgimg .= '</div>';
		duceapp_anchorheader('bgimg');
		duceapp_showsetting('logintpl_bgswitchtime', 'bgswitchtime', $this->componvar['bgswitchtime'], 'text');
		duceapp_showsetting('logintpl_bgimg', 'bgimg', '', 'filetext', '', 0, $bgimg);
		showsubmit('wechatsave', 'submit');
		duceapp_anchorfooter();
		echo '
		<script type="text/JavaScript">
		function delbgimg(obj){
			var el = obj.parentNode;
			var input = el.getElementsByTagName(\'input\')[0];
			if(BROWSER.ie || 1 && input.onclick){
				input.click();
			}
			if (obj.className != \'checked\') {
				obj.className = \'checked\';
				input.checked = true;
				el.style.opacity = 1;
				el.style.filter = \'alpha(opacity=100)\';
				obj.innerHTML = \'<em class="duceapp_font" style="font-size:20px;color:#f00;">&#xe94e;</em>\';				
			} else {
				obj.className = \'\';
				input.checked = false;
				el.style.opacity = 0.4;
				el.style.filter = \'alpha(opacity=40)\';
				obj.innerHTML = \'<em class="duceapp_font" style="font-size:20px;color:#693;">&#xe9ac;</em>\';				
			}
		}
		Sortable.create($(\'wechatbgimg\'), {animation: 150, handle:\'.em\', draggable: \'.e\', delay: 0, dragClass:\'esdrag\', setData: function(dtf){dtf.setData(\'duceapp\', \'\');}, fallbackClass: \'echosen\'});
		</script>
		';

		showformfooter();/*dism��taobao��com*/
	}

	private function save() {

		if ($this->danchor == 'style') {
			$this->redirect .= '&ctype='.str_replace('subtab_', '', $_GET['ctype']);
		}

		$this->componvar['hidemobilebtn'] = intval($_GET['logintpl']['hidemobilebtn']);		
		$this->componvar['disinwechat'] = intval($_GET['logintpl']['disinwechat']);
		$this->componvar['bgswitchtime'] = intval($_GET['bgswitchtime']);
		$this->componvar['lostformobile'] = intval($_GET['lostformobile']);
		$this->componvar['lostfindtype'] = intval($_GET['lostfindtype']);
		$this->componvar['codeinterval'] = intval($_GET['codeinterval']);
		$this->componvar['mobileformurl'] = trim($_GET['mobileformurl']);
		$this->componvar['getcodesuccess'] = trim($_GET['getcodesuccess']);
		$this->componvar['getmobilecodeurl'] = trim($_GET['getmobilecodeurl']);
		$this->componvar['smsloginurl'] = trim($_GET['smsloginurl']);
		$this->componvar['ajaxdatatype'] = $_GET['ajaxdatatype'] == 'text' ? 'text' : 'xml';
		$this->componvar['style'] = $style = $_GET['style'];
		if (!$this->componvar['mobileformurl'] || !$this->componvar['getmobilecodeurl']) {
			$this->componvar['lostformobile'] = 0;
		}
		
		if (intval($_GET['logintplact']) > 0) {
			$defaultid2 = C::t('common_setting')->fetch('styleid2');
			$styleid = $_GET['logintplact'];
			if ($styleid != $defaultid2) {
				duceapp_error('logintpl_action_noexists');
			}
			$template = C::t('common_style')->fetch($styleid);
			$template = C::t('common_template')->fetch($template['templateid']);
			$touchdir = DISCUZ_ROOT.$template['directory'].'/touch/member';			
			if (($isphp = file_exists($touchdir.'/login.php')) || ($ishtm = file_exists($touchdir.'/login.htm'))) {
				$filepath = $touchdir.'/'.($isphp ? 'login.php' : 'login.htm');
				$bakfilepath = $touchdir.'/login_duceapp_bak.'.($isphp ? 'php' : 'htm');
				$filedata = file_get_contents($filepath);
				$tplcache = DISCUZ_ROOT.'./data/template/'.$styleid.'_'.$template['templateid'].'_touch_member_login.tpl.php';
				if (strpos($filedata, 'id="duceapp_head"') === false) {
					if (@copy($filepath, $bakfilepath)) {
						$filedata = file_get_contents(DUCEAPP_ROOT.'template/touch/logintpl.htm');
						if ($isphp) {
							$filedata = "<?php exit('Access Denied @ duceapp.cn'); ?>\r\n".$filedata;
						}
						file_put_contents($filepath, $filedata);
						$this->componvar['styleid'] = $defaultid2;
						$this->componvar['hidemobilebtn'] = 0;						
						@unlink($tplcache);
					}
				} elseif (strpos($template['directory'], 'duceapp_cn') === false) {
					$filedata = file_get_contents(DUCEAPP_ROOT.'template/touch/logintpl.htm');
					if ($isphp) {
						$filedata = "<?php exit('Access Denied @ duceapp.cn'); ?>\r\n".$filedata;
					}
					file_put_contents($filepath, $filedata);
					$this->componvar['styleid'] = $defaultid2;
					$this->componvar['hidemobilebtn'] = 0;
					@unlink($tplcache);
				} else {
					duceapp_error('logintpl_induceapp');
				}
			} else {
				duceapp_error(duceapp_cplang('logintpl_noexists', array('directory' => $template['directory'])));
			}
		} elseif ($_GET['logintplact'] == 'recove') {
			$defaultid2 = C::t('common_setting')->fetch('styleid2');
			$template = C::t('common_style')->fetch($defaultid2);
			$template = C::t('common_template')->fetch($template['templateid']);
			$touchdir = DISCUZ_ROOT.$template['directory'].'/touch/member';
			if (($isphp = file_exists($touchdir.'/login_duceapp_bak.php')) || ($ishtm = file_exists($touchdir.'/login_duceapp_bak.htm'))) {
				$filepath = $touchdir.'/'.($isphp ? 'login.php' : 'login.htm');
				$bakfilepath = $touchdir.'/login_duceapp_bak.'.($isphp ? 'php' : 'htm');
				@copy($bakfilepath, $filepath);
				@unlink($bakfilepath);
				unset($this->componvar['styleid']);
				$tplcache = template('touch/member/login');
				@unlink($tplcache);
			}
		}
		$dataurl = DUCEAPP_DATAURL.'login/';
		dmkdir(DISCUZ_ROOT.$dataurl);

		if ($_GET['deltoplogo']) {
			@unlink(DISCUZ_ROOT.$this->componvar['toplogo']);
			$this->componvar['toplogo'] = '';
		}
		if ($_FILES['toplogo']['tmp_name'] && preg_match('/^image/', $_FILES['toplogo']['type'])) {
			$this->componvar['toplogo'] = $this->get_target_filename('toplogo');
			duceapp_writeimage(DISCUZ_ROOT.$this->componvar['toplogo'], $_FILES['toplogo']['tmp_name']);
		} elseif($_GET['toplogo'] && preg_match('/\.(png|jpg|gif)$/i', $_GET['toplogo'])){
			$this->componvar['toplogo'] = $_GET['toplogo'];
		}

		$_GET['bgimglist'] = is_array($_GET['bgimglist']) ? $_GET['bgimglist'] : array();
		if ($this->componvar['bgimg']) {
			foreach($this->componvar['bgimg'] as $i => $file) {
				if (!in_array($file, $_GET['bgimglist']) && !preg_match('/^http/i', $file)) {
					@unlink(DISCUZ_ROOT.$file);
				}
			}
		}
		$this->componvar['bgimg'] = $_GET['bgimglist'];

		if ($_FILES['bgimg'] && preg_match('/^image/', $_FILES['bgimg']['type'])) {
			$file = $this->get_target_filename('bgimg');
			duceapp_writeimage(DISCUZ_ROOT.$file, $_FILES['bgimg']['tmp_name']);
			$this->componvar['bgimg'][] = $file;
		} elseif($_GET['bgimg'] && preg_match('/^http/i', $_GET['bgimg']) && preg_match('/\.(png|jpg|gif)$/i', $_GET['bgimg'])) {
			$this->componvar['bgimg'][] = $_GET['bgimg'];
		}
		if ($_FILES['btn_bind']['tmp_name'] && preg_match('/^image/', $_FILES['btn_bind']['type'])) {
			$this->componvar['btn_bind'] = $this->get_target_filename('btn_bind');
			duceapp_writeimage(DISCUZ_ROOT.$this->componvar['btn_bind'], $_FILES['btn_bind']['tmp_name']);
		}
		if ($_FILES['btn_bar']['tmp_name'] && preg_match('/^image/', $_FILES['btn_bar']['type'])) {
			$this->componvar['btn_bar'] = $this->get_target_filename('btn_bar');
			duceapp_writeimage(DISCUZ_ROOT.$this->componvar['btn_bar'], $_FILES['btn_bind']['tmp_name']);
		}
		if ($_FILES['btn_method']['tmp_name'] && preg_match('/^image/', $_FILES['btn_method']['type'])) {
			$this->componvar['btn_method'] = $this->get_target_filename('btn_method');
			duceapp_writeimage(DISCUZ_ROOT.$this->componvar['btn_method'], $_FILES['btn_method']['tmp_name']);
		}
		if ($_FILES['btn_touch']['tmp_name'] && preg_match('/^image/', $_FILES['btn_touch']['type'])) {
			$this->componvar['btn_touch'] = $this->get_target_filename('btn_touch');
			duceapp_writeimage(DISCUZ_ROOT.$this->componvar['btn_touch'], $_FILES['btn_touch']['tmp_name']);
		}

		$customstyle = '';
		$theme_styles = $_GET['theme_styles'];
		if ($this->componvar['bgimg']) {
			$customstyle .= '.loginpage .lform{background:none !important;}';
		}
		if ($style['formmargin']) {
			$customstyle .= '.loginpage .loginbox{margin:0 '.$style['formmargin'].'px;}.loginpage .lform ul,.loginpage .bform .wide,.loginpage .bform fieldset{margin-left:0 !important;margin-right:0 !important;}.getlostpw_chose{border-radius:3px 3px 0 0;}.getlostpw_chose dd{padding:0 10px;}.getlostpw_chose dd.ema{float:right;}';
		}
		if ($style['btncolor']) {
			$customstyle .= '.bgt{background:'.$style['btncolor'].' !important;}';
		}
		if ($style['headopacity'] > 0 && $style['headopacity'] < 101) {
			$headcolor = duceapp_hex2rgb($theme_styles['headercolor'] ? $theme_styles['headercolor'] : '#53BCF5', intval($style['headopacity']));
			$customstyle .= '.loginpage .duceapp_lshead{background-color:'.$headcolor.'}';
			if ($style['headopacity'] == 100) {
				$customstyle .= '.loginpage .duceapp_lshead h2{display:none;}.toplogo{margin:-10px auto 0 !important;}';
			}
		}
		if ($style['iptbdcolor']) {
			$iptbdcolor = duceapp_hex2rgb($style['iptbdcolor'], $style['iptspacing'] ? 100 : intval($style['iptbdopacity']));
			$customstyle .= '.loginpage .lform,.loginpage .lform ul,.loginpage .bform li,.loginpage .lform .sectpl,.loginpage .bform .bt_e,.loginpage .bform .bb_e, .loginpage .bform .bc_e{border-color:'.$iptbdcolor.' !important;}.loginpage .bform fieldset{border-top-color:'.$style['iptbdcolor'].' !important;}';
		}
		if ($style['fontcolor']) {
			$customstyle .= '.loginpage cite i,.loginpage .ipt .tx,.loginpage .wide a,.loginpage .ipt .pwds,.loginpage .bform legend{color:'.$style['fontcolor'].' !important;}.loginpage ::-webkit-input-placeholder{color:'.$style['fontcolor'].' !important;}.loginpage :-moz-placeholder{color:'.$style['fontcolor'].' !important;}.loginpage ::-moz-placeholder{ color:'.$style['fontcolor'].' !important;}.loginpage :-ms-input-placeholder{color:'.$style['fontcolor'].' !important;}.loginpage .area textarea::-webkit-input-placeholder{color:'.$style['fontcolor'].' !important;}';
		}
		if ($style['inputcolor']) {
			$customstyle .= '.loginpage .ipt .px,.loginpage .ipt .selected span{color:'.$style['inputcolor'].' !important;}input:-webkit-autofill,textarea:-webkit-autofill,select:-webkit-autofill{-webkit-text-fill-color:'.$style['inputcolor'].' !important;}';
		}
		if ($style['iptbgcolor']) {
			$iptbgcolor = duceapp_hex2rgb($style['iptbgcolor'], $style['iptbgopacity']);
			$customstyle .= '.loginpage .bform li{background:'.$iptbgcolor.' !important;'.($style['iptspacing'] ? 'padding:5px 5px 5px 8px !important;margin-top:'.$style['iptspacing'] .'px;border-radius:2px;' : 'padding:8px 6px !important;').'}.getlostpw_chose,.getlostpw_chose dd{background:none !important;}.getlostpw_chose dd{color:#eee !important;}.getlostpw_chose dd.current{color:#fc0 !important;}';
		}
		if ($customstyle) {
			$customstyle .= '.duceapp_qqlogin{background:#53BCF5 !important;border:none !important;}.duceapp_qqlogin .qq{color:#FFF !important;}.duceapp_wxlogin{background:#9ED165 !important;border:none !important;}.duceapp_wxlogin .weixin{color:#FFF !important;}';
		}
		duceapp_csscache('wechat/login_custom', $customstyle);

		duceapp_initcommoncss($theme_styles);

		duceapp_succeed();
	}

	function get_target_filename($key) {
		if ($this->componvar[$key] && is_string($this->componvar[$key])) {
			@unlink(DISCUZ_ROOT.$this->componvar[$key]);
		}
		return DUCEAPP_DATAURL.'login/'.$key.'_'.date('His').strtolower(random(12)).'.'.fileext($_FILES[$key]['name']);
	}
}