<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: data.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if (CURSCRIPT == 'forum') {
	$_G['duceapp_sharedata']['pic'] = $_G['forum']['icon'] ? 'data/attachment/common/'.$_G['forum']['icon'] : '';
	if (CURMODULE == 'viewthread') {
		global $postlist;
		if ($postlist) {
			foreach($postlist as $tid => $post) break;
		}
		if ($post && $post['attachments']) {
			$attachments = $post['attachments'];
			$attach = array_shift($attachments);
			$_G['duceapp_sharedata']['pic'] = $_G['setting']['attachurl'].'forum/'.$attach['attachment'];
		} elseif ($_G['forum_attachtags']) {
			$attachid = $_G['forum_attachtags'][$post['pid']][0];
			$_G['duceapp_sharedata']['pic'] = getforumimg($attachid, 0, 140, 140, 'fixwr');
		}
		$_G['duceapp_sharedata']['title'] = ($_G['forum']['status'] == 3 ? $_G['setting']['navs'][3]['navname'] : '').$_G['forum_thread']['subject'];
		$_G['duceapp_sharedata']['content'] = ($post['message'] ? cutstr(str_replace(array("\n", "\r"), '', strip_tags($post['message'])), 300) : $_G['forum']['name'].' - '.$_G['setting']['sitename']);
	} elseif($_G['forum']['name']) {
		$_G['duceapp_sharedata']['title'] = $_G['forum']['name'].'-'.$_G['setting']['bbname'];
		$_G['duceapp_sharedata']['content'] = $_G['forum']['description'] ? $_G['forum']['description'] : '';
	}
} elseif (CURSCRIPT == 'home') {
	if (CURMODULE == 'space') {
		global $album, $pic, $blog;
		if ($_GET['do'] == 'album') {
			if ($_GET['id']) {
				$_G['duceapp_sharedata']['pic'] = ($album['picflag'] == 2 ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'album/'.$album['pic'];
				$_G['duceapp_sharedata']['title'] = $album['albumname'];
				$_G['duceapp_sharedata']['content'] = strip_tags($album['depict']);
			} elseif ($pic) {
				$_G['duceapp_sharedata']['pic'] = $pic['pic'];
				$_G['duceapp_sharedata']['title'] = $album['depict'] ? strip_tags($album['depict']) : $album['albumname'];
				$_G['duceapp_sharedata']['content'] = $pic['title'];
			}
		} elseif ($_GET['do'] == 'blog') {
			if ($_GET['id']) {
				$_G['duceapp_sharedata']['pic'] = $blog['pic'] ? ($blog['picflag'] == 2 ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'album/'.$blog['pic'] : '';
				$_G['duceapp_sharedata']['title'] = $blog['subject'];
				$_G['duceapp_sharedata']['content'] = strip_tags($blog['message']);
			}
		}
	}
}