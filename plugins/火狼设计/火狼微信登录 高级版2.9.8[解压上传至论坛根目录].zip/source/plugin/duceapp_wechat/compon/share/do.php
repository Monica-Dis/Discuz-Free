<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: do.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if (empty($_G)) {
	global $_G;
}

if ($_G['cache']['duceapp_wechat']['mtype'] && empty($_G['inajax'])) {
	if (!defined('IN_DUCEAPP')) {
		@include dirname(__FILE__).'/data.php';
		global $navtitle, $nobbname, $metadescription, $metakeywords;
		if (!$_G['duceapp_sharedata']['title']) {
			$_G['duceapp_sharedata']['title'] = $navtitle ? $navtitle.(empty($nobbname) ? ' - '.$_G['setting']['bbname'] : '') : $_G['setting']['bbname'];
		}
		if (!$_G['duceapp_sharedata']['content']) {
			if (!$metadescription || trim(str_replace(array($navtitle, $_G['setting']['bbname'], ','), '', $metadescription)) == '') {
				$_G['duceapp_sharedata']['content'] = $metakeywords ? $metakeywords : $_G['setting']['seokeywords'][CURSCRIPT];
			} elseif ($metadescription) {
				$_G['duceapp_sharedata']['content'] = $metadescription;
			}
		}
	}
	include_once template('duceapp_wechat:'.(defined('TPL_DEFAULT') && defined('IN_MOBILE') ? 'touch/wechat_share' : 'wechat_share'));
	include_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');
	$wechat_client = new duceapp_wechatclient('mp');
	if (is_array($_G['duceapp_wxjssdk'] = $wechat_client->GetSignPackage())) {
		$_G['setting']['pluginhooks']['global_footer_mobile'] .= duceapp_wechat_share();
	}
}