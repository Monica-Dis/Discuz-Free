<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00602
 * Date: 2020-08-06 03:25:46
 * File: invoke.class.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

class duceapp_compon_invoke
{
	public function init() {
		$this->dataurl = DUCEAPP_DATAURL.'login/';
		duceapp_showanchors();
		loaducenter();
		$this->synapps = uc_app_ls();
		call_user_func(array(__CLASS__, $this->cpmethod));
	}

	private function main() {
		global $_G, $plugin;

		duceapp_formheader();

		if ($this->danchor == 'api') {
			$filedir = DUCEAPP_DATAROOT.'api/';
			if ($this->setting['apitoken']) {
				preg_match('/\/\*\[apitoken\]\*\/([\s\S]*?)\/\*\[\/apitoken\]\*\//', file_get_contents($filedir.'token.php'), $apitokencode);
			}
			if ($this->setting['apiticket']) {
				preg_match('/\/\*\[apiticket\]\*\/([\s\S]*?)\/\*\[\/apiticket\]\*\//', file_get_contents($filedir.'ticket.php'), $apiticketcode);
			}
			if ($plugin['duceapp_visitor']) {
				$this->setting['secret'] = '';
			}
			duceapp_anchortips('invoke_tips');
			duceapp_anchorheader();
			duceapp_showsetting('invoke_secret', 'secret', $this->setting['secret'] ? $this->setting['secret'] : random(24), 'text');
			duceapp_showsetting('invoke_expires', array('expires', array(
				array(0, duceapp_cplang('invoke_expires_0'), array('invoke_expires_in' => 'none')),
				array(1, duceapp_cplang('invoke_expires_1'), array('invoke_expires_in' => 'none')),
				array(2, duceapp_cplang('invoke_expires_2'), array('invoke_expires_in' => '')),
			), 1), intval($this->setting['expires']), 'mradio');
			showtagheader('tbody', 'invoke_expires_in', intval($this->setting['expires']) == 2);
			duceapp_showsetting('invoke_expires_in', 'expires_in', isset($this->setting['expires_in']) ? $this->setting['expires_in'] : 7200, 'text');
			showtagfooter('tbody');			
			if ($this->synapps && count($this->synapps) > 1) {
				$appselect = '<select name="synapps[]" multiple="multiple" size="5"><option value=""'.($this->setting['synapps'] ? '' : ' selected').'>&nbsp;</option>';
				foreach ($this->synapps as $app) {
					if ($app['appid'] != UC_APPID) {
						$appselect .= '<option value="'.$app['appid'].'"'.($this->setting['synapps'][$app['appid']] ? ' selected' : '').'>'.$app['url'].'</option>';
					}
				}
				$appselect .= '</select>';
				duceapp_showsetting('invoke_synbind', '', '', $appselect);
			}
			if (empty($this->setting['api'])) {
				duceapp_showsetting('invoke_token', 'apitoken', trim($apitokencode[1]), 'textarea', $this->setting['api']);
				duceapp_showsetting('invoke_ticket', 'apiticket', trim($apiticketcode[1]), 'textarea', $this->setting['api']);
			}
			showsubmit('wechatsave', 'submit');
			duceapp_anchorfooter();
		} elseif ($this->danchor == 'doc') {
			duceapp_anchortips('invoke_doc_tips');
			duceapp_anchorheader();
			echo '<tr><td><div class="duceapp_info">';
			echo duceapp_cplang('invoke_doc');
			echo '</div></td></tr>';
			duceapp_anchorfooter();
		}

		showformfooter();/*dism��taobao��com*/
	}

	private function save() {		
		if ($this->danchor == 'api') {
			$this->setting['secret'] = trim($_GET['secret']);
			unset($this->setting['apitoken'], $this->setting['apiticket']);
			if (!$this->setting['api']) {
				require_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');
				$filedir = DUCEAPP_DATAROOT.'api/';
				dmkdir($filedir);
				$apitoken = trim($_GET['apitoken']);
				if ($apitoken) {
					$this->check_syntax($apitoken, 'Access_Token');
					$apitoken = "<?php\n\nif(!defined('IN_DISCUZ')) exit('Access Denied');\n\n/*[apitoken]*/\n\n".$apitoken."\n\n/*[/apitoken]*/\n\n?>";	
					if($fd = @fopen($filedir.'token.php', 'w+')) {
						fwrite($fd, $apitoken);
						fclose($fd);
						$this->setting['apitoken'] = 1;
					}
				}
				$apiticket = trim($_GET['apiticket']);
				if ($apiticket) {
					$this->check_syntax($apiticket, 'JsApi_Ticket');
					$apiticket = "<?php\n\nif(!defined('IN_DISCUZ')) exit('Access Denied');\n\n/*[apiticket]*/\n\n".$apiticket."\n\n/*[/apiticket]*/\n\n?>";
					if($fd = @fopen($filedir.'ticket.php', 'w+')) {
						fwrite($fd, $apiticket);
						fclose($fd);
						$this->setting['apiticket'] = 1;
					}
				}
			}
			$this->setting['synapps'] = array();
			if (count($this->synapps) > 1 && is_array($_GET['synapps'])) {
				foreach ($this->synapps as $i => $app) {
					if ($app['appid'] != UC_APPID && in_array($app['appid'], $_GET['synapps'])) {
						$this->setting['synapps'][$app['appid']] = array(
							'appid' => $app['appid'],
							'type' => $app['type'],
							'url' => $app['url'],
						);
					}
				}
			}
		}
		$this->setting['expires'] = intval($_GET['expires']);
		$this->setting['expires_in'] = intval($_GET['expires_in']) >= 10 && intval($_GET['expires_in']) <= 7200 ? intval($_GET['expires_in']) : 7200;
		duceapp_succeed();
	}

	function check_syntax($check_code, $api){
		global $_G;
		$check_code = "?><?php " . str_replace('self::', 'duceapp_wechatclient::', $check_code) . "?><?php return isset(\$res) ? \$res : null;";
		$syntax = @eval($check_code);
		if ($syntax === false) {
			duceapp_error('invoke_phpcode_invalid', array('extapi' => $api));
		}
		if ($syntax === null) {
			duceapp_error('invoke_phpreturn_invalid', array('extapi' => $api));
		}
		if ($api == 'Access_Token' && !isset($syntax['token'])) {
			duceapp_error('invoke_accesstoken_invalid');
		}
		if ($api == 'JsApi_Ticket' && !isset($syntax['ticket'])) {
			duceapp_error('invoke_jsapiticket_invalid');
		}
		return true;
	}
}