<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: support_version.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$duceapp_addonid = '80951';

$support_version = array(
	'logintpl' => array(
		'main' => '1.8.0', 
		'admin' => '1.3.2', 
		'addonid' => '81367'
	),
	'onekey' => array(
		'main' => '1.8.0', 
		'admin' => '1.2.5', 
		'addonid' => '81251'
	),
	'subscribe' => array(
		'main' => '1.8.0', 
		'admin' => '1.2.0', 
		'addonid' => '81323'
	),
	'tmplsend' => array(
		'main' => '1.8.0', 
		'admin' => '1.2.6', 
		'addonid' => '81510'
	),
);