<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00806
 * Date: 2020-08-06 03:25:46
 * File: access.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once libfile('class/duceapp_admincp', 'plugin/duceapp_wechat');

class duceapp_modcp extends duceapp_admincp
{
	public function __construct() {
		$this->header();
		duceapp_showanchors();
		call_user_func(array(__CLASS__, $this->cpmethod));
		$this->footer();
	}	

	private function main() {
		global $_G, $plugin;

		if (!isset($this->setting['token']) || $plugin['duceapp_visitor']) {
			$this->setting['token'] = random(16);
		}

		duceapp_formheader();
		
		duceapp_anchortips('access_server_tips', 'server', $this->danchor == 'server');
		duceapp_anchortips('access_mp_tips', 'mp', $this->danchor == 'mp');
		duceapp_anchortips('access_open_tips', 'open', $this->danchor == 'open');
		duceapp_anchortips('access_synch_tips', 'synch', $this->danchor == 'synch');

		duceapp_anchorheader('server');
		duceapp_showsetting('access_server_api', array('settingnew[api]', array(
			array(1, cplang('yes'), array('hidden_2' => 'none', 'hidden_1' => '')),
			array(0, cplang('no'), array('hidden_1' => 'none', 'hidden_2' => '')),
		), 1), intval($this->setting['api']), 'mradio');
		showtagfooter('table');
		showtagheader('table', 'hidden_1', $this->setting['api'] == 1, 'tb2 duceapp_tb');
		duceapp_showsetting('access_server_apihost', 'settingnew[apihost]', $this->setting['apihost'], 'text');
		showtagfooter('table');
		showtagheader('table', 'hidden_2', !$this->setting['api'], 'tb2 duceapp_tb');
		duceapp_showsetting('access_server_url', '', $_G['siteurl'].$this->access_server, 'info');
		showtagheader('table', '', TRUE, 'tb2 duceapp_tb');
		duceapp_showsetting('access_server_token', 'settingnew[token]', $this->setting['token'], 'text');
		duceapp_showsetting('access_server_encodingaeskey', 'settingnew[encodingaeskey]', duceapp_cutencrypt($this->setting['encodingaeskey']), 'text');
		showtagfooter('tbody');
		showsubmit('wechatsave', 'submit');
		duceapp_anchorfooter();

		duceapp_anchorheader('mp');
		duceapp_showsetting('access_mp_appid', 'settingnew[mp][appid]', $this->setting['mp']['appid'], 'text');
		duceapp_showsetting('access_mp_appsecret', 'settingnew[mp][appsecret]', duceapp_cutencrypt($this->setting['mp']['appsecret']), 'text');
		showsubmit('wechatsave', 'submit');
		duceapp_anchorfooter();

		duceapp_anchorheader('open');
		duceapp_showsetting('access_mp_appid', 'settingnew[open][appid]', $this->setting['open']['appid'], 'text');
		duceapp_showsetting('access_mp_appsecret', 'settingnew[open][appsecret]', duceapp_cutencrypt($this->setting['open']['appsecret']), 'text');
		showsubmit('wechatsave', 'submit');
		duceapp_anchorfooter();
		
		duceapp_anchorheader('synch');
		duceapp_showsetting('access_synch_oauthsite', 'settingnew[oauthsite]', $this->setting['oauthsite'], 'text');
		duceapp_showsetting('access_synch_synsite', 'settingnew[synsite]', $_G['setting']['duceapp_synsite'], 'textarea');
		showsubmit('wechatsave', 'submit');
		duceapp_anchorfooter();

		showformfooter();/*dism��taobao��com*/
	}

	private function save() {
		global $_G;
		$settingnew = $_GET['settingnew'];		
		
		if ($apihost = trim($settingnew['apihost'])) {
			$apihost = preg_match('/^http(s?)\:\/\//i', $apihost) ? $apihost : 'http://'.$apihost;
			$apihost = preg_replace('/\/+$/', '', $apihost).'/';
		}
		$cache_mtype = $this->setting['mtype'];
		$cache_appid = $this->setting['mp']['appid'];

		$settingnew['mp']['appid'] = trim($settingnew['mp']['appid']);
		$settingnew['mp']['appsecret'] = trim($settingnew['mp']['appsecret']);
		$settingnew['open']['appid'] = trim($settingnew['open']['appid']);
		$settingnew['open']['appsecret'] = trim($settingnew['open']['appsecret']);

		$settingnew['mp']['appsecret'] = duceapp_comparencrypt($settingnew['mp']['appsecret'], $this->setting['mp']['appsecret']);
		$settingnew['open']['appsecret'] = duceapp_comparencrypt($settingnew['open']['appsecret'], $this->setting['open']['appsecret']);

		$this->setting['mp'] = $settingnew['mp'];
		$this->setting['open'] = $settingnew['open'];
		$this->setting['apihost'] = $apihost;
		$this->setting['apiurl'] = 'source/plugin/duceapp_wechat/api.php?';
		$this->setting['api'] = intval($settingnew['api']) && $apihost ? 1 : 0;
		$this->setting['token'] = $settingnew['token'] ? $settingnew['token'] : random(16);
		$this->setting['mtype'] = $settingnew['mp']['appid'] && $settingnew['mp']['appsecret'] ? 1 : 0;
		$this->setting['qrtype'] = $settingnew['open']['appid'] && $settingnew['open']['appsecret'] ? 1 : 0;
		$this->setting['enable'] = $this->setting['mtype'] || $this->setting['qrtype'];
		$this->setting['encodingaeskey'] = duceapp_comparencrypt(trim($settingnew['encodingaeskey']), $this->setting['encodingaeskey']);
		$this->setting['share']['enabled'] = 0;	
		$this->setting['oauthsite'] = trim($settingnew['oauthsite']);

		if($this->setting['oauthsite']) {
			$this->setting['oauthsite'] = preg_replace('/\/+$/', '', $this->setting['oauthsite']).'/';
		}

		$synsite = trim($settingnew['synsite']);
		if ($synsite != $_G['setting']['duceapp_synsite']) {
			C::t('common_setting')->update_batch(array('duceapp_synsite' => $synsite));
			updatecache('setting');
		}

		if ($this->setting['encodingaeskey'] && strlen($this->setting['encodingaeskey']) != 43) {
			duceapp_error('access_server_encodingaeskey_error');
		}

		if ($this->setting['mtype'] || $this->setting['qrtype']) {
			require_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');
			foreach (array('open' => 'qrtype', 'mp' => 'mtype') as $k => $t) {
				if (!$this->setting[$t]) {
					continue;
				}
				$wechat_client = new duceapp_wechatclient($settingnew[$k]['appid'], $settingnew[$k]['appsecret']);
				$res = $wechat_client->getAccessToken(0, 1);
				if (!duceapp_wechatclient::checkIsSuc($res)) {
					if ($res['errcode'] == '40164') {
						preg_match("/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/", $res['errmsg'], $matches);
						duceapp_error('access_invalid_whiteip', array('whiteip' => $matches[0]));
					} else {
						$msg = $wechat_client->error();
						duceapp_error(preg_match('/^4[0-9]+$/', $msg) ? 'wechat_request_error_'.$k : $msg);
					}
				}
			}
		}

		if ($this->setting['mtype']) {
			$this->setting['mtype'] = $wechat_client->getQrcodeTicket(array('scene_id' => 100000,'expire' => 30,'ticketOnly' => 1)) ? 1 : 2;
			if ($cache_mtype == 1 && $this->setting['mtype'] != $cache_mtype && $settingnew['mp']['appid'] == $cache_appid) {
				duceapp_error('wechat_at_qrgeterror');
			}
			$this->setting['share']['enabled'] = 1;
			if ($this->setting['mtype'] == 2 && $settingnew['mtype'] == 1) {
				$this->setting['mtype'] = 1;
			}
		}

		duceapp_succeed();
	}
}

new duceapp_modcp;