<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00728
 * Date: 2020-08-06 03:25:46
 * File: setting.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once libfile('class/duceapp_admincp', 'plugin/duceapp_wechat');

class duceapp_modcp extends duceapp_admincp
{
	public function __construct() {
		$this->header();

		duceapp_showanchors('setting', 1);
		call_user_func(array(__CLASS__, $this->cpmethod));

		$this->footer();
	}	

	private function main() {
		global $_G, $lang;
		if ($this->danchor == 'basic') {
			if (!isset($this->setting['allowregister'])) {
				$setting = C::t('common_setting')->fetch_all(array('mobilewechat'));
				$setting = (array)unserialize($setting['mobilewechat']);
				if ($setting) {
					$this->setting['allowregister'] = $setting['wechat_allowregister'];
					$this->setting['allowfastregister'] = $setting['wechat_allowfastregister'];
					$this->setting['disableregrule'] = $setting['wechat_disableregrule'];
					$this->setting['confirmtype'] = $setting['wechat_confirmtype'];
					$this->setting['newusergroupid'] = $setting['wechat_newusergroupid'];
				}
			}

			$groupselect = array();
			foreach(C::t('common_usergroup')->range_orderby_credit() as $group) {
				if($group['type'] != 'member' || $_G['setting']['newusergroupid'] == $group['groupid']) {
					$groupselect[$group['type']] .= '<option value="'.$group['groupid'].'"'.($this->setting['newusergroupid'] == $group['groupid'] ? ' selected' : '').'>'.$group['grouptitle'].'</option>';
				}
			}
			$usergroups = '<select name="setting[newusergroupid]"><option value="">'.cplang('plugins_empty').'</option>'.
				'<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
				($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
				($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
				'<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup></select>';

			$rewardcredit = '<select name="setting[rewardcredit]"><option value="0">'.cplang('none').'</option>';
    		foreach($_G['setting']['extcredits'] as $i => $credit) {
        		$extcredit = 'extcredits'.$i.' ('.$credit['title'].')';
        		$rewardcredit .= '<option value="'.$i.'" '.($i == intval($this->setting['rewardcredit']) ? 'selected' : '').'>'.$extcredit.'</option>';
    		}
			$rewardcredit .= '</select>';
			$value = sprintf('%02b', $this->setting['needpawd']);
			$i = 1;
			$needpawd .= '<ul onmouseover="altStyle(this);">';
			foreach(array('wechat_required_password', 'wechat_required_email') as $var) {
				if($var !== false) {
					$needpawd .= '<li'.($value{2 - $i} ? ' class="checked"' : '').'><input class="checkbox" type="checkbox" name="setting[needpawd]['.$i.']" value="1"'.($value{2 - $i} ? ' checked' : '').' >&nbsp;'.duceapp_cplang($var).'</li>';
				}
				$i++;
			}
			$needpawd .= '</ul>';

			$tabs = array('wechat_signup', 'wechat_login', 'wechat_postperm');
			$subtab = $_GET['subtab'] ? $_GET['subtab'] : $tabs[0];
			duceapp_formheader();
			duceapp_anchortabs('basic', $tabs, $subtab);
			duceapp_showtagheader('div', 'basic');
			duceapp_anchorheader('subtab_wechat_signup', $subtab == 'wechat_signup');
			duceapp_showsetting('wechat_allowregister', 'setting[allowregister]', $this->setting['allowregister']);
			duceapp_showsetting('wechat_newusergroupid', '', '', $usergroups);
			duceapp_showsetting('wechat_rewardcredit', '', '', $rewardcredit);
			duceapp_showsetting('wechat_rewardcount', 'setting[rewardcount]', $this->setting['rewardcount'], 'text');
			duceapp_showsetting('wechat_allowfastregister', 'setting[allowfastregister]', $this->setting['allowfastregister']);
			duceapp_showsetting('wechat_required', '', '', $needpawd);
			duceapp_showsetting('wechat_disableregrule', 'setting[disableregrule]', $this->setting['disableregrule']);
			duceapp_showsetting('wechat_disinvitecode', 'setting[disinvitecode]', $this->setting['disinvitecode']);
			duceapp_showsetting('wechat_allowchange', 'setting[allowchange]', $this->setting['allowchange']);
			duceapp_showsetting('wechat_emojimode', 'setting[emojimode]', $this->setting['emojimode']);
			showsubmit('wechatsave', 'submit');
			duceapp_anchorfooter();
			duceapp_anchorheader('subtab_wechat_login', $subtab == 'wechat_login');
			duceapp_showsetting('wechat_smsauth', 'setting[smsauth]', $this->setting['smsauth']);
			duceapp_showsetting('wechat_confirmtype', 'setting[confirmtype]', $this->setting['confirmtype']);
			if($this->setting['mtype'] == 1){
				duceapp_showsetting('wechat_noreqsmp', 'setting[noreqsmp]', $this->setting['noreqsmp']);
			}
			if ($this->setting['qrtype']) {
				duceapp_showsetting('wechat_jslogin', 'setting[jslogin]', $this->setting['jslogin']);
			}
			duceapp_showsetting('wechat_jschecktime', 'setting[jschecktime]', $this->setting['jschecktime'], 'text');
			duceapp_showsetting('wechat_unnewbiespan', 'setting[unnewbiespan]', $this->setting['unnewbiespan']);
			$groupselect = array();
			$query = DB::query("SELECT groupid, radminid, type, grouptitle, creditshigher, creditslower FROM ".DB::table('common_usergroup')." ORDER BY creditshigher, groupid");
			while($group = DB::fetch($query)){
				$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
				$groupselect[$group['type']] .= "<option value=\"$group[groupid]\" ".(@in_array($group['groupid'], $this->setting['forcelogin']) ? 'selected' : '').">$group[grouptitle]</option>\n";
			}
			$groupselect = '<select multiple="multiple" name="setting[forcelogin][]" size="8"><option value=""'.(empty($this->setting['forcelogin']) ? ' selected' : '').'>'.cplang('none').'</optoin><optgroup label="'.cplang('usergroups_member').'">'.$groupselect['member'].'</optgroup>'.
				($groupselect['special'] ? '<optgroup label="'.cplang('usergroups_special').'">'.$groupselect['special'].'</optgroup>' : '').
				($groupselect['specialadmin'] ? '<optgroup label="'.cplang('usergroups_specialadmin').'">'.$groupselect['specialadmin'].'</optgroup>' : '').
				'<optgroup label="'.cplang('usergroups_system').'">'.$groupselect['system'].'</optgroup></select>';
			duceapp_showsetting('wechat_forcelogin', '', '', $groupselect);
			showsubmit('wechatsave', 'submit');
			duceapp_anchorfooter();
			duceapp_anchorheader('subtab_wechat_postperm', $subtab == 'wechat_postperm');
			duceapp_showsetting('wechat_poststatus', array('setting[poststatus]', array(
				array(0, cplang('unlimited')),
				array(1, duceapp_cplang('wechat_poststatus_1')),
				array(2, duceapp_cplang('wechat_poststatus_2')),
			), 1), intval($this->setting['poststatus']), 'mradio');
			duceapp_showsetting('wechat_permfids', '', '', '<select name="setting[permfids][]" multiple="multiple" size="10" style="margin-bottom:8px;"><option value=""'.(empty($this->setting['permfids']) ? ' selected' : '').'>'.cplang('none').'</option><option value="-1"'.($this->setting['permfids'] == -1 ? ' selected' : '').'>'.cplang('all').'</option>'.duceapp_forumselect((array)$this->setting['permfids']).'</select>');
			showsubmit('wechatsave', 'submit');
			duceapp_anchorfooter();
			showtagfooter('div');
			showformfooter();/*dism��taobao��com*/
		} elseif ($this->danchor == 'qrcode') {
			duceapp_anchortips('wechat_qrcode_tips');
			duceapp_formheader('enctype');
			duceapp_anchorheader('qrcode');
			duceapp_showsetting('wechat_qrcode_create', array('qrcode_createtype', array(
				array(0, duceapp_cplang('wechat_qrcode_create_type2'), array('sitelogo' => 'none', 'mpqrcode' => '')),
				array(1, duceapp_cplang('wechat_qrcode_create_type1'), array('sitelogo' => '', 'mpqrcode' => 'none')),
			), 1), 0, 'mradio');
			$qrcode = $this->setting['qrcode'] ? DUCEAPP_DATAURL.$this->setting['qrcode'] : '';
			$qrcode = $qrcode && file_exists(DISCUZ_ROOT.$qrcode) ? '<br /><img src="'.$qrcode.'" style="width:100px;height:100px;margin-left:-5px;" />' : '';
			showtagheader('tbody', 'mpqrcode', 1);
			duceapp_showsetting('wechat_qrcode_mp', 'mpqrcode', '', 'file', !$this->setting['mtype'], 0, duceapp_cplang('wechat_qrcode_mp_comment').$qrcode);
			showtagfooter('tbody');
			showtagheader('tbody', 'sitelogo', 0);
			duceapp_showsetting('wechat_qrcode_sitelogo', 'sitelogo', '', 'file', $this->setting['mtype'] != 1, 0, duceapp_cplang('wechat_qrcode_sitelogo_comment').$qrcode);
			showtagfooter('tbody');
			$sharelogo = $this->setting['share']['logo'] ? DUCEAPP_DATAURL.$this->setting['share']['logo'] : '';
			$sharelogo = $sharelogo && file_exists(DISCUZ_ROOT.$sharelogo) ? '<img src="'.$sharelogo.'?'.random(5).'" style="width:88px;height:88px;margin:-2px 0 6px;" />' : '';
			duceapp_showsetting('wechat_share_logo', 'sharelogo', '', 'file', '', 0, $sharelogo);

			showsubmit('wechatsave', 'submit');
			duceapp_anchorfooter();
			showformfooter();/*dism��taobao��com*/
		} else {
			@include DUCEAPP_ROOT.$this->danchor.'.inc.php';
		}

	}

	private function save() {
		global $_G;
		$setting = $_GET['setting'];

		if ($this->danchor == 'basic') {
			if ($_GET['subtab']) {
				$this->redirect .= '&subtab='.$_GET['subtab'];
			}
			if ($setting) {
				$this->setting['allowregister'] = intval($setting['allowregister']);
				$this->setting['allowfastregister'] = intval($setting['allowfastregister']);
				$this->setting['disableregrule'] = intval($setting['disableregrule']);
				$this->setting['disinvitecode'] = intval($setting['disinvitecode']);
				$this->setting['confirmtype'] = intval($setting['confirmtype']);
				$this->setting['jschecktime'] = trim($setting['jschecktime']);
				$this->setting['newusergroupid'] = $setting['newusergroupid'];
				$this->setting['emojimode'] = intval($setting['emojimode']);
				if (isset($setting['noreqsmp'])){
					$this->setting['noreqsmp'] = intval($setting['noreqsmp']);
				}
				$needpawd = '';
				for($i=2; $i>=1; $i--) {
					$needpawd .= intval($setting['needpawd'][$i]);
				}
				$this->setting['needpawd'] = bindec($needpawd);
				$this->setting['rewrite'] = intval($setting['rewrite']);
				$this->setting['rewardcredit'] = intval($setting['rewardcredit']);
				$this->setting['rewardcount'] = intval($setting['rewardcount']);
				$this->setting['unnewbiespan'] = intval($setting['unnewbiespan']);
				$this->setting['allowchange'] = intval($setting['allowchange']);
				if ($this->setting['qrtype']) {
					$this->setting['jslogin'] = intval($setting['jslogin']);
				}
				$this->setting['rewardcount'] = $this->setting['rewardcount'] > 0 ? $this->setting['rewardcount'] : '';
				$this->setting['smsauth'] = intval($setting['smsauth']);
				$this->setting['poststatus'] = intval($setting['poststatus']);
				$this->setting['permfids'] = in_array('-1', $setting['permfids']) ? -1 : array_filter(dintval($setting['permfids'], true));
				$this->setting['forcelogin'] = array_filter(dintval($setting['forcelogin'], true));
			}
		} elseif ($this->danchor == 'qrcode') {
			if ($this->setting['mtype']) {
				$qrcode_filename = $this->setting['qrcode'];
				$filename = date('His').strtolower(random(12)).'_qr.jpg';
				$file = DISCUZ_ROOT.DUCEAPP_DATAURL.$filename;
				if ($_GET['qrcode_createtype'] == 1) {
					require_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');
					$wechat_client = new duceapp_wechatclient($this->setting['mp']['appid'], $this->setting['mp']['appsecret']);
					if (!($ticket = $wechat_client->getQrcodeTicket(array('scene_id' => 100000,'expire' => 30,'ticketOnly' => 1)))) {
						duceapp_error('wechat_at_qrgeterror');
					}
					$ticket = $wechat_client->getQrcodeTicket(array('scene_id' => 1));
					$qrcode = dfsockopen($wechat_client->getQrcodeImgUrlByTicket($ticket));
					if ($_FILES['sitelogo']['tmp_name'] && preg_match('/^image/', $_FILES['sitelogo']['type'])) {
						$qrcodeImg = @imagecreatefromstring($qrcode);
						if (@$fp = fopen($_FILES['sitelogo']['tmp_name'], 'rb')) {
							while (!feof($fp)) $imgdata = @fread($fp, 1024 * 512);
							fclose($fp);
							$qrlogoImg = @imagecreatefromstring($imgdata);
							@imagecopymerge($qrcodeImg, $qrlogoImg, 165, 165, 0, 0, 100, 100, 100);
						}						
						@imagejpeg($qrcodeImg, $file);
					} elseif(!duceapp_writeimage($file, '', $qrcode)) {
						duceapp_error('wechat_createqrcode_error');
					}
					if ($qrcode_filename) {
						@unlink(DISCUZ_ROOT.DUCEAPP_DATAURL.$qrcode_filename);
					}
					$this->setting['qrcode'] = $filename;
				} elseif ($_FILES['mpqrcode']['tmp_name']) {
					if (!preg_match('/^image/', $_FILES['mpqrcode']['type']) || !duceapp_writeimage($file, $_FILES['mpqrcode']['tmp_name'])) {
						duceapp_error('wechat_createqrcode_error');
					}
					if ($qrcode_filename) {
						@unlink(DISCUZ_ROOT.DUCEAPP_DATAURL.$qrcode_filename);
					}
					$this->setting['qrcode'] = $filename;
				}
				if ($_FILES['sharelogo']['tmp_name']) {
					if (!preg_match('/^image/', $_FILES['sharelogo']['type'])) {
						duceapp_error('wechat_sharelogo_error');
					}
					if ($this->setting['share']['logo']) {
						@unlink(DISCUZ_ROOT.$this->setting['share']['logo']);
					}
					$filename = 'sharelogo_'.date('His').strtolower(random(12)).'.'.fileext($_FILES['sharelogo']['name']);
					duceapp_writeimage(DISCUZ_ROOT.DUCEAPP_DATAURL.$filename, $_FILES['sharelogo']['tmp_name']);
					$this->setting['share']['logo'] = $filename;
				}
			}
		} else {
			@include DUCEAPP_ROOT.$this->danchor.'.inc.php';
		}

		duceapp_succeed();
	}
}

new duceapp_modcp;