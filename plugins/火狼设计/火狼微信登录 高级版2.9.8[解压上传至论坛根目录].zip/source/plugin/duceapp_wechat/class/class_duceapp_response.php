<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00728
 * Date: 2020-08-06 03:25:46
 * File: class_duceapp_response.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class duceapp_response
{
	private static $expire = 1296000;
	public static $keyword = 'ACC_LOGIN';
	private static $redirect_siteurl;
	
	public static function text($param) {
		list($data) = $param;
		self::_init();
		global $_G;
		$data['content'] = diconv($data['content'], 'UTF-8');
		$authcode = C::t('#duceapp_wechat#duceapp_wechat_authcode')->fetch_by_code($data['content']);
		$isloginkeyword = self::_custom('text', $data['content']);
		if ($authcode['resite']) {
			self::$redirect_siteurl = $authcode['resite'];
		}
		if (!$authcode || $authcode['status']) {
			if ($isloginkeyword) {
				self::_show('access', $data['from']);
			}
		} else {
			self::_show('sendnum', $data['from']."\t".$authcode['sid'], 60);
		}
	}

	public static function click($param) {
		list($data) = $param;
		self::_init();
		global $_G;
		if ($data['key'] == self::$keyword) {
			self::_show('access', $data['from']);
		} else {
			self::_custom('text', $data['key']);
		}
	}

	public static function custom($param) {
		list($data) = $param;
		self::_init();
		global $_G;
		self::_updateSubscribe($data['from']);
		if ($data['key'] && $_G['cache']['duceapp_wechat']['response']['subscribe']) {
			$_G['cache']['duceapp_wechat']['response']['scan'] = $_G['cache']['duceapp_wechat']['response']['subscribe'];
			self::scan($param);
		} else {
			self::_custom('subscribe', $data['from']);
		}
	}

	public static function subscribe($param) {
		list($data) = $param;
		self::_init();
		global $_G;
		self::_updateSubscribe($data['from']);
		if ($data['key']) {
			self::scan($param);
		} else {
			self::_show('access', $data['from']);
		}
	}

	public static function scan($param) {
		list($data) = $param;
		self::_init();
		global $_G;

		$authcode = C::t('#duceapp_wechat#duceapp_wechat_authcode')->fetch_by_code($data['key']);

		if (!$authcode || $authcode['status'] == 1) {
		} else {
			include_once libfile('class/duceapp_wechat', 'plugin/duceapp_wechat');
			$access_user = duceapp_wechat::getAccessUser($data['from']);
			if (!$_G['cache']['duceapp_wechat']['api'] && $authcode['resite']) {
				include_once libfile('class/duceapp_wechatapi', 'plugin/duceapp_wechat');
				$data['subscribe'] = $access_user['subscribe'];
				$data['nickname'] = $access_user['nickname'];
				$data['sex'] = $access_user['sex'];
				$data['openid'] = $access_user['openid'];
				$data['unionid'] = $access_user['unionid'];
				$data['headimgurl'] = $access_user['headimgurl'];
				$res = duceapp_wechatapi::report('scan', array_merge($data, $authcode));
				if ($res && is_array($res)) {
					$authcode = $res;
				} elseif ($res != -1) {
					$authcode['key'] = $data['key'];
				}
			} else {
				if ($authcode['uid']) {
					$member = getuserbyuid($authcode['uid'], 1);
					if ($member['uid'] && $member['adminid'] == 0 && !$_G['cache']['duceapp_wechat']['confirmtype']) {
						$wechatuser = C::t('#duceapp_wechat#duceapp_wechat_member')->fetch_by_unionid($access_user);
						if (!$wechatuser) {
							$wechatuser = duceapp_wechat::bindOpenId($member['uid'], $access_user);
						}
						if ($wechatuser['uid'] == $member['uid']) {
							C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($authcode['sid'], array('uid' => $member['uid'], 'status' => 1));
							$authcode['sid'] = '';
						}
					}
				} else {
					$wechatuser = C::t('#duceapp_wechat#duceapp_wechat_member')->fetch_by_unionid($access_user);
					if ($wechatuser && !($member = getuserbyuid($wechatuser['uid'], 1))) {
						C::t('#duceapp_wechat#duceapp_wechat_member')->delete($wechatuser['uid']);
					}
					if ($wechatuser && $member) {
						if ($member['adminid'] == 0 && !$_G['cache']['duceapp_wechat']['confirmtype']) {
							C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($authcode['sid'], array('uid' => $member['uid'], 'status' => 1));
							$authcode['sid'] = '';
						}
					} elseif ($_G['cache']['duceapp_wechat']['mtype']) {
						include_once libfile('class/duceapp_wechatapi', 'plugin/duceapp_wechat');
						require_once libfile('function/member');
						$uid = duceapp_wechat::memberActivation(duceapp_wechatapi::report('syncheckuser', array(
							'uid' => 0,
							'openid' => $access_user['openid'],
							'unionid' => $access_user['unionid']
						)));
						if (!$uid && $_G['cache']['duceapp_wechat']['allowregister'] && $_G['cache']['duceapp_wechat']['allowfastregister']) {
							$uid = duceapp_wechat::register($access_user);
						}
						if ($uid) {
							duceapp_wechat::bindOpenId($uid, $access_user, 1);
							C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
							$authcode['sid'] = '';
						}
					}
				}
				if ($authcode['sid']) {
					C::t('#duceapp_wechat#duceapp_wechat_authcode')->update($authcode['sid'], array('status' => -1));
				}
			}
			if ($authcode['resite']) {
				self::$redirect_siteurl = $authcode['resite'];
			}
			self::_show('scan', $data['from']."\t".$authcode['sid']."\t".$authcode['uid']."\t".$authcode['key']);
		}
	}

	private static function _show($evt, $key, $expire = 0) {
		global $_G;
		$expire = $expire ? $expire : self::$expire;
		$key = authcode($key, 'ENCODE', $_G['cache']['duceapp_wechat']['token'], $expire);
		$url = self::$redirect_siteurl.$_G['duceapp_wechataccess'].'ac=response&evt='.$evt.'&key='.urlencode(base64_encode($key));
		$param = array('bbname' => $_G['setting']['sitename'], 'date' => dgmdate(TIMESTAMP, 'Y-m-d'));
		$desc = !empty($_G['cache']['duceapp_wechat']['response'][$evt]) ? $_G['cache']['duceapp_wechat']['response'][$evt] : 'wechat_response_text_'.$evt;
		if (preg_match("/^\[resource=(\d+)\]/", $desc, $r)) {
			self::_resource($r[1], $url);
		} 
		elseif (preg_match("/\<a([^\>]+)\>/i", $desc))
			{
			echo duceapp_wechatserver::getXml4Txt(str_replace(array('{confirmurl}','{bbname}','{date}'), array($url, $param['bbname'], $param['date']), $desc));
		} 
		else {
			$list = array(array(
				'title' => lang('plugin/duceapp_wechat', 'wechat_response_text_title', $param),
				'desc' => lang('plugin/duceapp_wechat', $desc, $param),
				'pic' => self::$redirect_siteurl.($_G['cache']['duceapp_wechat']['share']['logo'] ? 'data/duceapp/wechat/'.$_G['cache']['duceapp_wechat']['share']['logo'] : 'source/plugin/duceapp_wechat/static/image/sharelogo.png'),
				'url' => $url
			));
			echo duceapp_wechatserver::getXml4RichMsgByArray($list);
		}
		exit;
	}

	private static function _custom($type, $keyword = '') {
		global $_G;
		$response = & $_G['cache']['duceapp_wechat']['response'];
		$query = $type == 'text' ? $response['query']['text'][$keyword] : $response['query']['subscribe'];
		$url = '';
		if (!$query && $type == 'text' && $keyword) {
			$query = self::_regex($keyword);
		}		
		if ($query) {
			if($query == self::$keyword) {
				return 1;
			}
			if ($type == 'subscribe') {
				$key = authcode($keyword, 'ENCODE', $_G['cache']['duceapp_wechat']['token'], self::$expire);
				$url = self::$redirect_siteurl.$_G['duceapp_wechataccess'].'ac=response&evt=subscribe&key='.urlencode(base64_encode($key));
				$query = str_replace(array('{confirmurl}','{bbname}','{date}'), array($url, $_G['setting']['sitename'], dgmdate(TIMESTAMP, 'Y-m-d')), $query);
			}
			if (preg_match("/^\[resource=(\d+)\]/", $query, $r)) {
				self::_resource($r[1], $url);
			} else {
				echo duceapp_wechatserver::getXml4Txt($query);
			}
			exit;
		}
		return 0;
	}

	public static function _resource($rid, $url = '') {
		$resource = C::t('#duceapp_wechat#duceapp_wechat_resource')->fetch($rid);
		if(!$resource['type']) {
			$list = array(array(
				'title' => $resource['data']['title'],
				'desc' => trim($resource['data']['desc']) ? $resource['data']['desc'] : strip_tags($resource['data']['content']),
				'pic' => $resource['data']['pic'],
				'url' => $url ? $url.'&referer='.urlencode($resource['data']['url']) : $resource['data']['url'],
			));
		} else {
			$mergeids = array_keys($resource['data']['mergeids']);
			$sresource = C::t('#duceapp_wechat#duceapp_wechat_resource')->fetch_all($mergeids);
			$list = array();
			foreach($resource['data']['mergeids'] as $id => $order) {
				if ($sresource[$id]){
					$list[] = array(
						'title' => $sresource[$id]['data']['title'],
						'desc' => trim($sresource[$id]['data']['desc']) ? $sresource[$id]['data']['desc'] : strip_tags($sresource[$id]['data']['content']),
						'pic' => $sresource[$id]['data']['pic'],
						'url' => $url ? $url.'&referer='.urlencode($sresource[$id]['data']['url']) : $sresource[$id]['data']['url'],
					);
				}
			}
			if (!$list) {
				exit;
			}
		}
		echo duceapp_wechatserver::getXml4RichMsgByArray($list);
		exit;
	}

	public static function _regex($keyword) {
		global $_G;
		if ($_G['cache']['duceapp_wechat']['response']['query_regex']) {
			foreach($_G['cache']['duceapp_wechat']['response']['query_regex'] as $key => $value) {
				if (preg_match($value['regex'], $keyword)) {
					return $_G['cache']['duceapp_wechat']['response']['query']['text'][$key];
				}
			}
		}
		return '';
	}

	public static function location($param) {
		list($data) = $param;
		$res = DB::update('duceapp_wechat_member', array(
			'lat' => $data['la'],
			'lng' => $data['lo'],
		), "openid='".$data['from']."'");
		if ($res) {
			echo 'success';
		}
	}

	public static function unsubscribe($param) {
		list($data) = $param;
		self::_init();
		global $_G;
		self::_updateSubscribe($data['from'], 0);
	}

	public static function masssendFinish($param) {
	    list($data) = $param;
	    if(!$data['msg_id']) {
			exit;
	    }
	    $updatedata = array(
			'res_status' => $data['status'],
			'res_totalcount' => $data['totalcount'],
			'res_filtercount' => $data['filtercount'],
			'res_sentcount' => $data['sentcount'],
			'res_errorcount' => $data['errorcount'],
			'res_finish_at' => $data['time']
	    );
	    DB::update('duceapp_wechat_masssend', $updatedata, "msg_id='$data[msg_id]'");
	}

	public static function _updateSubscribe($openid, $subscribe = 1) {
		global $_G;
		DB::update('duceapp_wechat_member', array('subscribe' => $subscribe), "openid='$openid'");
		if ($_G['cache']['duceapp_wechat']['api']) {
			include_once libfile('class/duceapp_wechatapi', 'plugin/duceapp_wechat');
			duceapp_wechatapi::report('attention', array('openid' => $openid, 'subscribe' => $subscribe));
		}
	}

	private static function _init() {
		global $_G;
		if (!self::$redirect_siteurl) {
			self::$redirect_siteurl = $_G['siteurl'];
		}
		duceapp_wechat_initialize();
	}
}