<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00806
 * Date: 2020-08-06 03:25:46
 * File: class_duceapp_wechat.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')){
	exit('Access Denied');
}

class duceapp_wechat
{
	static $QRCODE_EXPIRE = 1800;

	public static function bindOpenId($uid, $access_user, $isregister = 0, $avatar = false) {
		$wechatuser = array(
			'uid' => $uid,
			'subscribe' => isset($access_user['subscribe']) || !$access_user['pclogin'] ? intval($access_user['subscribe']) : -1,
			'openid' => $access_user['openid'], 
			'unionid' => $access_user['unionid'], 
			'status' => 2, 
			'isregister' => $isregister,
			'nickname' => $access_user['nickname'], 
			'sex' => $access_user['sex'],
			'dateline' => TIMESTAMP,
			'lastauth' => TIMESTAMP,
		);
		C::t('#duceapp_wechat#duceapp_wechat_member')->insert($wechatuser, false, true);
		if ($avatar) {
			self::syncAvatar($uid, $access_user['headimgurl']);
		}
		return $wechatuser;
	}

	public static function updateLogin($wechat_member, $access_user, $login = true, $mtype = true) {
		$data = array();
		if (isset($access_user['subscribe'])) {
			$data['subscribe'] = $access_user['subscribe'];
		}
		if ($mtype && $wechat_member['openid'] != $access_user['openid']) {
			$data['openid'] = $access_user['openid'];
		}
		if (!$wechat_member['unionid'] && $access_user['unionid']) {
			$data['unionid'] = $access_user['unionid'];
		}
		$data['status'] = $login ? 2 : 1;
		$data['nickname'] = $access_user['nickname'];
		$data['sex'] = $access_user['sex'];
		$data['lastauth'] = TIMESTAMP;
		C::t('#duceapp_wechat#duceapp_wechat_member')->update($wechat_member['uid'], $data);
	}

	static public function getQrcode() {
		global $_G;
		$setting = $_G['cache']['duceapp_wechat'];
		$noreqsmp = $setting['mtype'] == 1 && $setting['noreqsmp'];
		if ($setting['oauthsite'] && empty($_G['setting']['duceapp_synsite']) && strpos($setting['oauthsite'], $_SERVER['HTTP_HOST']) === FALSE) {
			$noreqsmp = 1;
		}
		$ticket = $qrcodeurl = $qrapitype = '';
		if (!$_G['cookie']['duceapp_wechat_ticket'] || $setting['subscribe']['enabled'] || $noreqsmp) {
			$code = 0;
			$i = 0;
			do {
				$code = rand(100000, 999999);
				$codeexists = C::t('#duceapp_wechat#duceapp_wechat_authcode')->fetch_by_code($code);
				$i++;
			} 
			while($codeexists && $i < 10);

			if ($setting['subscribe']['enabled']) {
				$qrcodeurl = $_G['siteurl'].$_G['duceapp_wechatdataurl'].$setting['subscribe']['qrcode'];
			} elseif ($noreqsmp) {
				$qrcodeurl = $_G['siteurl'].$_G['duceapp_wechataccess'].'ac=qrcode&access=yes&rand='.random(5);
				$setting['api'] = 0;
				$qrapitype = 'access';
			} else {
				include_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');
				$wechat_client = new duceapp_wechatclient($setting['mp']['appid'], $setting['mp']['appsecret']);
				$option = array(
					'scene_id' => $code,
					'expire' => self::$QRCODE_EXPIRE,
					'ticketOnly' => '1'
				);
				$ticket = $wechat_client->getQrcodeTicket($option);
				$ticket = strlen($ticket) < 12 ? '' : $ticket;
				if (!$ticket && (!$setting['qrcode'] || !file_exists(DISCUZ_ROOT.$_G['duceapp_wechatdataurl'].$setting['qrcode']))) {
					showmessage('duceapp_wechat:wechat_message_codefull', '', array(), array('showdialog' => 1, 'showmsg' => true));
				}
				dsetcookie('duceapp_wechat_ticket', authcode($ticket."\t".$code, 'ENCODE'), self::$QRCODE_EXPIRE);
			}
		} else {
			list($ticket, $code) = explode("\t", authcode($_G['cookie']['duceapp_wechat_ticket'], 'DECODE'));
		}
		if ($codeexists) {
			showmessage('duceapp_wechat:wechat_message_codefull', '', array(), array('showdialog' => 1, 'showmsg' => true));
		}
		$qrapitype = $ticket ? $ticket : $qrapitype;
		$qrcodeurl = $qrcodeurl ? $qrcodeurl : ($ticket ? $_G['siteurl'].$_G['duceapp_wechataccess'].'ac=qrcode&rand='.random(5) : $_G['siteurl'].$_G['duceapp_wechatdataurl'].$setting['qrcode']);
		$codeenc = urlencode(base64_encode(authcode($code, 'ENCODE', $_G['config']['security']['authkey'])));
		$authcode = array('sid' => $_G['cookie']['saltkey'], 'uid' => $_G['uid'], 'code' => $code, 'createtime' => TIMESTAMP);
		C::t('#duceapp_wechat#duceapp_wechat_authcode')->insert($authcode, 0, 1);
		if(!discuz_process::islocked('clear_duceapp_wechat_authcode')) {
			C::t('#duceapp_wechat#duceapp_wechat_authcode')->delete_history();
			discuz_process::unlock('clear_duceapp_wechat_authcode');
		}
		if ($setting['api']) {
			include_once libfile('class/duceapp_wechatapi', 'plugin/duceapp_wechat');
			$authcode['resite'] = $_G['siteurl'];
			duceapp_wechatapi::report('authcode', $authcode);
		}
		return array($qrapitype, $qrcodeurl, $codeenc, $code);
	}

	public static function redirectregister($access_user, $qrtype) {
		global $_G;
		$defaultusername = self::getNewUsername($access_user);
		if (DUCEAPP_WECHATBROWSE) {
			$key = authcode($openid = $access_user['openid'], 'ENCODE', $_G['cache']['duceapp_wechat']['token']);
			$selfurl = $_G['siteurl'].$_G['duceapp_wechataccess'].'ac=response&key='.urlencode(base64_encode($key))."&evt=ajax&op=";
			include template('duceapp_wechat:wechat_bind');
			exit;
		}
		$auth = urlencode(base64_encode(authcode($access_user['openid']."\t".$access_user['access_token']."\t".$qrtype."\t".$_GET['referer'], 'ENCODE')));
		$referer = urlencode($_G['siteurl'].$_G['duceapp_wechataccess'].'ac=login&op=regcallback&auth='.$auth);
		dheader('location: '.$_G['siteurl'].'member.php?mod='.$_G['setting']['regname'].'&referer='.$referer.'&defaultusername='.urlencode($defaultusername));
	}

	public static function clearEmoji($defaultusername) {
		global $_G;
		include_once libfile('class/duceapp_wechatemoji', 'plugin/duceapp_wechat');
		$defaultusername = substr(duceapp_wechatemoji::clear($defaultusername, $_G['cache']['duceapp_wechat']['emojimode']), 0, 15);
		if (empty($defaultusername)) {
			$userprefix = trim($_G['cache']['duceapp_wechat']['userprefix']);
			$defaultusername = ($userprefix ? $userprefix : 'wx').strtolower(random(6));
		}
		return $defaultusername;
	}

	static public function getAccessUser($access, $mtype = true) {
		$access = is_array($access) ? $access : array('openid' => $access);
		$access_user = array();
		if ($access['openid']) {
			include_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');
			$wechat_client = new duceapp_wechatclient($mtype ? 'mp' : 'open');
			if ($mtype) {
				$access_user = $wechat_client->getUserInfoById($access['openid']);
				if (isset($access_user['subscribe']) && !$access_user['subscribe'] && $access['access_token']) {
					$access_user = $wechat_client->getUserInfoByAuth($access['access_token'], $access['openid']);
					$access_user['subscribe'] = 0;
				}
				if (!isset($access_user['nickname'])) {
					$access_user = array();
				}
			}
			if ((!$mtype || empty($access_user)) && $access['access_token']) {
				$access_user = $wechat_client->getUserInfoByAuth($access['access_token'], $access['openid']);
			}
			if ($access_user['openid'] && $access['access_token']) {
				$access_user['access_token'] = $access['access_token'];
			}
			if ($access_user && !$mtype) {
				$access_user['pclogin'] = 1;
			}
		}
		return $access_user;
	}

	public static function getNewUsername($access_user) {
		global $_G;
		include_once libfile('class/duceapp_wechatemoji', 'plugin/duceapp_wechat');
		$access_user['username'] = substr(duceapp_wechatemoji::clear($access_user['nickname'], $_G['cache']['duceapp_wechat']['emojimode']), 0, 15);
		if (!$access_user['username']) {
			$userprefix = trim($_G['cache']['duceapp_wechat']['userprefix']);
			$access_user['username'] = ($userprefix ? $userprefix : 'wx').strtolower(random(6));
		}
		loaducenter();
		return self::getUniqueUsername($access_user['username']);
	}

	private static function getUniqueUsername($unique_name, $username = null, $rn = 2, $num = 0) {
		$user = uc_get_user($unique_name);
		if (!empty($user)) {
			$username = $username ? $username : $unique_name;
			$unique_name = self::getUniqueUsername(cutstr($username, 15 - $rn, '').strtolower(random($rn,1)), $username, $rn + floor($num/10), $num + 1);
		}
		return $unique_name;
	}

	public static function memberActivation($member, $access_user = null) {
		global $_G;
		if (!$_G['setting']['regclosed'] && $_G['setting']['ucactivation'] && $member['username']) {
			if ($member['uid'] && $access_user) {
				self::bindOpenId($member['uid'], $access_user, $member['isregister']);
			}
			if (getuserbyuid($member['uid'], 1)) {
				return $member['uid'];
			}
			$init_arr = explode(',', $_G['setting']['initcredits']);
			$groupid = $_G['cache']['duceapp_wechat']['newusergroupid'] ? $_G['cache']['duceapp_wechat']['newusergroupid'] : $_G['setting']['newusergroupid'];
			C::t('common_member')->insert($member['uid'], $member['username'], md5(random(10)), $member['email'], $_G['clientip'], $groupid, $init_arr);
			include_once libfile('function/stat');
			updatestat('register');
			return $member['uid'];
		}
		return 0;
	}

	public static function redirect() {
		global $_G;
		$hook = unserialize($_G['setting']['wechatredirect']);
		if (!$hook || $hook['plugin'] != 'duceapp_wechat' || !in_array($hook['plugin'], $_G['setting']['plugins']['available'])) {
			return;
		}
		if(!preg_match("/^[\w\_]+$/i", $hook['plugin']) || !preg_match('/^[\w\_\.]+\.php$/i', $hook['include'])) {
			return;
		}
		include_once DISCUZ_ROOT . 'source/plugin/' . $hook['plugin'] . '/' . $hook['include'];
		if (!class_exists($hook['class'], false)) {
			return;
		}
		$class = new $hook['class'];
		if (!method_exists($class, $hook['method'])) {
			return;
		}
		$return = call_user_func(array($class, $hook['method']), $type);
		if($return) {
			return $return;
		}
	}

	public static function getInviteStatus() {
		global $_G;
		$invitestatus = false;
		if ($_G['setting']['regstatus'] == 2) {
			if($_G['setting']['inviteconfig']['inviteareawhite']) {
				$location = $whitearea = '';
				$location = trim(convertip($_G['clientip'], "./"));
				if($location) {
					$whitearea = preg_quote(trim($_G['setting']['inviteconfig']['inviteareawhite']), '/');
					$whitearea = str_replace(array("\\*"), array('.*'), $whitearea);
					$whitearea = '.*'.$whitearea.'.*';
					$whitearea = '/^('.str_replace(array("\r\n", ' '), array('.*|.*', ''), $whitearea).')$/i';
					if(@preg_match($whitearea, $location)) {
						$invitestatus = true;
					}
				}
			}

			if($_G['setting']['inviteconfig']['inviteipwhite']) {
				foreach(explode("\n", $_G['setting']['inviteconfig']['inviteipwhite']) as $ctrlip) {
					if(preg_match("/^(".preg_quote(($ctrlip = trim($ctrlip)), '/').")/", $_G['clientip'])) {
						$invitestatus = true;
						break;
					}
				}
			}
		}
		return $invitestatus;
	}

	static public function register($access_user, $showmsg = 0, $groupid = 0) {
		global $_G;

		if (!$access_user) {
			return 0;
		}

		if (!function_exists('setloginstatus')) {
			require_once libfile('function/member');
		}

		$username = $access_user['username'] ? $access_user['username'] : self::getNewUsername($access_user);
		$password = $_GET['password'] ? $_GET['password'] : md5(random(10));
		$_password = md5($password);
		$email = isemail($_GET['email']) ? trim($_GET['email']) : 'wechat_'.strtolower(random(10)).'@null.null';

		$usernamelen = dstrlen($username);
		if($usernamelen < 3) {
			$username = $username.strtolower(random(3-$usernamelen));
		}
		if($usernamelen > 15) {
			if($showmsg) {
				showmessage('profile_username_toolong');
			} else {
				return;
			}
		}

		$censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';

		if($_G['setting']['censoruser'] && @preg_match($censorexp, $username)) {
			if($showmsg) {
				showmessage('profile_username_protect');
			} else {
				return;
			}
		}

		$invitestatus = self::getInviteStatus();
		if (!$invitestatus) {
			$invite = getinvite();
		}
		
		if (empty($_G['cache']['duceapp_wechat']['disinvitecode']) && $_G['setting']['regstatus'] == 2 && empty($invite) && !$invitestatus) {
			if($showmsg) {
				showmessage('not_open_registration_invite');
			} else {
				return;
			}
		}

		if (!$_G['cache']['duceapp_wechat']['disableregrule']) {
			loadcache('ipctrl');
			if($_G['cache']['ipctrl']['ipregctrl']) {
				foreach(explode("\n", $_G['cache']['ipctrl']['ipregctrl']) as $ctrlip) {
					if(preg_match("/^(".preg_quote(($ctrlip = trim($ctrlip)), '/').")/", $_G['clientip'])) {
						$ctrlip = $ctrlip.'%';
						$_G['setting']['regctrl'] = $_G['setting']['ipregctrltime'];
						break;
					} else {
						$ctrlip = $_G['clientip'];
					}
				}
			} else {
				$ctrlip = $_G['clientip'];
			}

			if($_G['setting']['regctrl']) {
				if(C::t('common_regip')->count_by_ip_dateline($ctrlip, $_G['timestamp']-$_G['setting']['regctrl']*3600)) {
					if($showmsg) {
						showmessage('register_ctrl', NULL, array('regctrl' => $_G['setting']['regctrl']));
					} else {
						return;
					}
				}
			}

			$setregip = null;
			if($_G['setting']['regfloodctrl']) {
				$regip = C::t('common_regip')->fetch_by_ip_dateline($_G['clientip'], $_G['timestamp']-86400);
				if($regip) {
					if($regip['count'] >= $_G['setting']['regfloodctrl']) {
						if($showmsg) {
							showmessage('register_flood_ctrl', NULL, array('regfloodctrl' => $_G['setting']['regfloodctrl']));
						} else {
							return;
						}
					} else {
						$setregip = 1;
					}
				} else {
					$setregip = 2;
				}
			}

			if($setregip !== null) {
				if($setregip == 1) {
					C::t('common_regip')->update_count_by_ip($_G['clientip']);
				} else {
					C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => 1, 'dateline' => $_G['timestamp']));
				}
			}
		}

		$uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
		if($uid <= 0) {
			if($showmsg) {
				if($uid == -1) {
					showmessage('profile_username_illegal');
				} elseif($uid == -2) {
					showmessage('profile_username_protect');
				} elseif($uid == -3) {
					showmessage('profile_username_duplicate');
				} elseif($uid == -4) {
					showmessage('profile_email_illegal');
				} elseif($uid == -5) {
					showmessage('profile_email_domain_illegal');
				} elseif($uid == -6) {
					showmessage('profile_email_duplicate');
				} else {
					showmessage('undefined_action');
				}
			} else {
				return;
			}
		}
		
		if ($invite && $_G['setting']['inviteconfig']['invitegroupid']) {
			$groupid = $_G['setting']['inviteconfig']['invitegroupid'];
		} else {
			$groupid = !$groupid ? ($_G['cache']['duceapp_wechat']['newusergroupid'] ? $_G['cache']['duceapp_wechat']['newusergroupid'] : $_G['setting']['newusergroupid']) : $groupid;
		}

		$credits = explode(',', $_G['setting']['initcredits']);
		if ($_G['cache']['duceapp_wechat']['rewardcredit'] > 0 && $_G['cache']['duceapp_wechat']['rewardcount'] > 0) {
			$credits[$_G['cache']['duceapp_wechat']['rewardcredit']] = $_G['cache']['duceapp_wechat']['rewardcount'];
		}
		$init_arr = array(
			'credits' => $credits,
			'profile' => array('gender' => $access_user['sex']),
		);
		C::t('common_member')->insert($uid, $username, $_password, $email, $_G['clientip'], $groupid, $init_arr);

		require_once libfile('cache/userstats', 'function');
		build_cache_userstats();

		if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
			C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72)*3600);
			if($_G['setting']['regctrl']) {
				C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
			}
		}

		if($_G['setting']['regverify'] == 2) {
			C::t('common_member_validate')->insert(array(
				'uid' => $uid,
				'submitdate' => $_G['timestamp'],
				'moddate' => 0,
				'admin' => '',
				'submittimes' => 1,
				'status' => 0,
				'message' => '',
				'remark' => '',
			), false, true);
			manage_addnotify('verifyuser');
		}

		setloginstatus(array(
			'uid' => $uid,
			'username' => $username,
			'password' => $_password,
			'groupid' => $groupid,
		), 0);

		include_once libfile('function/stat');
		updatestat('register');

		if ($invite['id']) {
			$result = C::t('common_invite')->count_by_uid_fuid($invite['uid'], $uid);
			if(!$result) {
				C::t('common_invite')->update($invite['id'], array('fuid'=>$uid, 'fusername'=>$_G['username'], 'regdateline' => $_G['timestamp'], 'status' => 2));
				updatestat('invite');
			} else {
				$invite = array();
			}
		}
		if ($invite['uid']) {
			if($_G['setting']['inviteconfig']['inviteaddcredit']) {
				updatemembercount($uid, array($_G['setting']['inviteconfig']['inviterewardcredit'] => $_G['setting']['inviteconfig']['inviteaddcredit']));
			}
			if($_G['setting']['inviteconfig']['invitedaddcredit']) {
				updatemembercount($invite['uid'], array($_G['setting']['inviteconfig']['inviterewardcredit'] => $_G['setting']['inviteconfig']['invitedaddcredit']));
			}
			require_once libfile('function/friend');
			friend_make($invite['uid'], $invite['username'], false);
			notification_add($invite['uid'], 'friend', 'invite_friend', array('actor' => '<a href="home.php?mod=space&uid='.$invite['uid'].'" target="_blank">'.$invite['username'].'</a>'), 1);

			space_merge($invite, 'field_home');
			if(!empty($invite['privacy']['feed']['invite'])) {
				require_once libfile('function/feed');
				$tite_data = array('username' => '<a href="home.php?mod=space&uid='.$_G['uid'].'">'.$_G['username'].'</a>');
				feed_add('friend', 'feed_invite', $tite_data, '', array(), '', array(), array(), '', '', '', 0, 0, '', $invite['uid'], $invite['username']);
			}
			if($invite['appid']) {
				updatestat('appinvite');
			}
		}
		
		self::syncAvatar($uid, $access_user['headimgurl']);
		$_G['member']['avatarstatus'] = 1;

		return $uid;
	}

	static public function syncAvatar($uid, $avatar) {

		if(!$uid || !$avatar) {
			return false;
		}

		if(!$content = dfsockopen($avatar)) {
			return false;
		}

		$tmpFile = DISCUZ_ROOT.'./data/avatar/'.TIMESTAMP.random(6);
		file_put_contents($tmpFile, $content);

		if(!is_file($tmpFile)) {
			return false;
		}

		$result = duceapp_uploaducavatar::upload($uid, $tmpFile);
		unlink($tmpFile);

		C::t('common_member')->update($uid, array('avatarstatus'=>'1'));

		return $result;
	}
}

class duceapp_uploaducavatar 
{
	public static function upload($uid, $localFile) {
		global $_G;
		if(!$uid || !$localFile) {
			return false;
		}

		list($width, $height, $type, $attr) = getimagesize($localFile);
		if(!$width) {
			return false;
		}

		if($width < 10 || $height < 10 || $type == 4) {
			return false;
		}

		if (!defined('IN_UC')) {
			loaducenter();
		}

		$imageType = array(1 => '.gif', 2 => '.jpg', 3 => '.png');
		$fileType = $imgType[$type];
		if(!$fileType) {
			$fileType = '.jpg';
		}
		$avatarPath = $_G['setting']['attachdir'];
		$tmpAvatar = $avatarPath.'./temp/upload'.$uid.$fileType;
		file_exists($tmpAvatar) && @unlink($tmpAvatar);
		file_put_contents($tmpAvatar, file_get_contents($localFile));

		if(!is_file($tmpAvatar)) {
			return false;
		}

		$tmpAvatarBig = './temp/upload'.$uid.'big'.$fileType;
		$tmpAvatarMiddle = './temp/upload'.$uid.'middle'.$fileType;
		$tmpAvatarSmall = './temp/upload'.$uid.'small'.$fileType;

		$image = new image;
		if($image->Thumb($tmpAvatar, $tmpAvatarBig, 200, 250, 1) <= 0) {
			return false;
		}
		if($image->Thumb($tmpAvatar, $tmpAvatarMiddle, 120, 120, 1) <= 0) {
			return false;
		}
		if($image->Thumb($tmpAvatar, $tmpAvatarSmall, 48, 48, 2) <= 0) {
			return false;
		}

		$tmpAvatarBig = $avatarPath.$tmpAvatarBig;
		$tmpAvatarMiddle = $avatarPath.$tmpAvatarMiddle;
		$tmpAvatarSmall = $avatarPath.$tmpAvatarSmall;

		$avatar1 = self::byte2hex(file_get_contents($tmpAvatarBig));
		$avatar2 = self::byte2hex(file_get_contents($tmpAvatarMiddle));
		$avatar3 = self::byte2hex(file_get_contents($tmpAvatarSmall));

		$extra = '&avatar1='.$avatar1.'&avatar2='.$avatar2.'&avatar3='.$avatar3;
		$result = self::uc_api_post_ex('user', 'rectavatar', array('uid' => $uid), $extra);

		@unlink($tmpAvatar);
		@unlink($tmpAvatarBig);
		@unlink($tmpAvatarMiddle);
		@unlink($tmpAvatarSmall);

		return true;
	}

	public static function byte2hex($string) {
		$buffer = '';
		$value = unpack('H*', $string);
		$value = str_split($value[1], 2);
		$b = '';
		foreach($value as $k => $v) {
			$b .= strtoupper($v);
		}

		return $b;
	}

	public static function uc_api_post_ex($module, $action, $arg = array(), $extra = '') {
		$s = $sep = '';
		foreach($arg as $k => $v) {
			$k = urlencode($k);
			if(is_array($v)) {
				$s2 = $sep2 = '';
				foreach($v as $k2 => $v2) {
					$k2 = urlencode($k2);
					$s2 .= "$sep2{$k}[$k2]=".urlencode(uc_stripslashes($v2));
					$sep2 = '&';
				}
				$s .= $sep.$s2;
			} else {
				$s .= "$sep$k=".urlencode(uc_stripslashes($v));
			}
			$sep = '&';
		}
		$postdata = uc_api_requestdata($module, $action, $s, $extra);
		return uc_fopen2(UC_API.'/index.php', 500000, $postdata, '', TRUE, UC_IP, 20);
	}
}