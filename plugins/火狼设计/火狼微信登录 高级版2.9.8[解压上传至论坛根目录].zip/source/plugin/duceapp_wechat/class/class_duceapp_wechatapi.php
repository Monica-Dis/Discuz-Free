<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00410
 * Date: 2020-08-06 03:25:46
 * File: class_duceapp_wechatapi.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class duceapp_wechatapi
{
	public static $API_URL;
	public static $SETTING = array();

	public static function _dfsockopen($get, $post = array()) {
		$proxyapi = in_array($get['a'], array('scan', 'tmplsendfinish', 'getuser', 'access'));
		if ($proxyapi && $post['resite']) {
			self::$API_URL = $post['resite'].(strpos($post['resite'], '?') === false ? self::$SETTING['apiurl'] : '');
		}
		if (!self::$API_URL && self::$SETTING['api']) {
			self::$API_URL = self::$SETTING['apihost'].self::$SETTING['apiurl'];
		}
		if ($post) { // Avoid XSS tips
			foreach($post as $k => $v) {
				$post[$k] = base64_encode($v);
			}
		}
		$return = self::$API_URL ? dfsockopen(self::$API_URL.http_build_query($get), 0, $post, '', false) : '';
		return json_decode($return, true);
	}

	public static function _setting() {
		global $_G;
		if (!self::$SETTING) {
			self::$SETTING = $_G['cache']['duceapp_wechat'];
		}
	}

	public static function _make_sign($data, $token) {
		sort($data, SORT_STRING);
		$data[] = $token;
		$data = implode($data);
		return sha1($data);
	}

	public static function _token() {
		self::_setting();
		return self::$SETTING['token'];
	}

	public static function _check_sign($action = '') {
		$signature = $_GET['signature'];
		unset($_GET['signature']);
		if ($signature !== self::_make_sign($_GET, self::_token())) {
			return false;
		}
		return true;
	}

	public static function import() {
		$report_file = libfile('function/report_'.$_GET['a'], 'plugin/duceapp_wechat');
		if ($report_file && file_exists($report_file)) {
			if (!empty($_POST)) { 
				foreach($_POST as $k => $v) {
					$_GET[$k] = base64_decode($v);
				}
			}
			include_once $report_file;
			return call_user_func('duceapp_wechat_report_'.$_GET['a']);
		}
		return '';
	}

	public static function report($action, $postin = array()) {
		global $_G;
		$get = array('op' => 'report', 'a' => $action);
		$post = array('uid' => (int) $_G['uid'], 'userip' => $_G['clientip']);
		if ($postin && is_array($postin)) {
			$post = array_merge($post, $postin);
		}		
		if (in_array($action, array('synactivation', 'syncheckuser', 'synrename'))) {
			if (!defined('UC_API')) {
				require_once DISCUZ_ROOT.'./config/config_ucenter.php';
			}
			if ($action == 'synrename') {
				include_once libfile('function/report_synrename', 'plugin/duceapp_wechat');
				duceapp_wechat_report_synrename($postin);
			}
			$post['uc_api'] = UC_API;
			$post['uc_appid'] = UC_APPID;
			$post['signature'] = self::_make_sign(array_merge($get, $post), self::_token());
			$return = '';
			$apps = duceapp_wechat_getapps();
			if ($apps && is_array($apps)) {
				foreach ($apps as $i => $app) {
					if ($app['appid'] != UC_APPID) {
						if (strtoupper($app['type']) == 'DISCUZX') {
							self::$API_URL = $app['url'].'/'.self::$SETTING['apiurl'];
							$data = self::_dfsockopen($get, $post);
							if ($action == 'syncheckuser' && $data) {
								$return = $data;
								break;
							}
						}
					}
				}
			}
			return $return;
		} else {
			$post['signature'] = self::_make_sign(array_merge($get, $post), self::_token());
			return self::_dfsockopen($get, $post);
		}
	}
}