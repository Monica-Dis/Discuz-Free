<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00728
 * Date: 2020-08-06 03:25:46
 * File: class_duceapp_admincp.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once libfile('check', 'plugin/duceapp_wechat');
require_once libfile('function/duceapp_core', 'plugin/duceapp_wechat');
require_once libfile('class/duceapp_adminbase', 'plugin/'.DUCEAPP_SINGLE);

class duceapp_admincp extends duceapp_adminbase
{
	public $setting_keys = array(
		'vercat', 'token', 'mp', 'open', 'api', 'apihost', 'apiurl', 'mtype', 'qrtype', 'enable', 'jslogin', 'qrcode', 'button', 'response', 'resource', 'allowregister', 'allowfastregister', 'needpawd', 'disableregrule', 'disinvitecode', 'ignoreinvite', 'allowchange', 'rewardcredit', 'rewardcount', 'unnewbiespan', 'confirmtype', 'userprefix', 'newusergroupid', 'emojimode', 'floatqrcode', 'floattext', 'floatrange', 'encodingaeskey', 'noreqsmp', 'share', 'secret', 'expires', 'expires_in', 'apitoken', 'apiticket', 'synapps', 'oauthsite', 'smsauth', 'jschecktime', 'poststatus', 'permfids', 'forcelogin'
	);
	public $admincss = 'wechat';
	public $dropanchor = array(
		'access' => array('server', 'mp', 'open', 'synch'), 
		'setting' => array('basic', 'qrcode'),
	);
	public $dropmodule = array(
		'setting' => array('response', 'menu', 'resource', 'masssend')
	);
	public $login_access = 'source/plugin/duceapp_wechat/logging.php?';
	public $access_server = 'source/plugin/duceapp_wechat/access.php';

	public function header() {
		global $_G;		
		$this->init(true);
		$_G['duceapp_wechataccess'] = $this->login_access;
		$_G['duceapp_wechatdataurl'] = DUCEAPP_DATAURL;
		$this->duceapp();
	}

	public function getNewsByid($media_id, $check = false, $appid = '', $appsecret = ''){
		if ($media_id) {
			if (empty($this->wechat_client)) {
				require_once libfile('class/duceapp_wechatclient', 'plugin/duceapp_wechat');
				$appid = $appid ? $appid : $this->setting['mp']['appid'];
				$appsecret = $appsecret ? $appsecret : $this->setting['mp']['appsecret'];
				$this->wechat_client = new duceapp_wechatclient($appid, $appsecret);
			}
			$res = $this->wechat_client->getNewsByid($media_id);
			if ($check) {
				return $res;
			}
			$resource = array();
			foreach($res['news_item'] as $news) {					
				$resource[0]['mergedata'][] = array(
					'data' => array(
						'title' => $news['title'],
						'desc' => $news['digest'],
						'content' => strip_tags($news['content']),
						'pic' => $this->getNewsImage($news),
						'url' => $news['url']
					)
				);					
			}
			if (count($resource[0]['mergedata']) > 1) {
				$resource[0]['type'] = 1;
			} else {
				$resource[0]['data'] = $resource[0]['mergedata'][0]['data'];
				unset($resource[0]['mergedata']);
			}
		}
		return $resource;
	}

	public function getNewsImage($news, $dir = 'rescource'){
		$pathdir = DUCEAPP_DATAROOT.$dir.'/';
		if ($news['thumb_media_id'] && $news['thumb_url']) {
			dmkdir($pathdir);
			$filename = $news['thumb_media_id'].'.jpg';
			if (!file_exists($pathdir.$filename)) {
				if(($iamgedata = dfsockopen($news['thumb_url'])) && (@$fp = fopen($pathdir.$filename, 'w'))){
					fwrite($fp, $iamgedata);
					fclose($fp);
					return DUCEAPP_DATAURL.$dir.'/'.$filename;
				}
			} else {
				return DUCEAPP_DATAURL.$dir.'/'.$filename;
			}
		}
		return $news['thumb_url'];
	}

	public function showResource($from = '', $inner = 0){
		$from = $from ? '&from='.$from : '';
		$inner = $inner ? '&inner=1' : '';
		$url = str_replace('pmod=', 'frompmod=', $this->redirect).'&pmod=setting&danchor=resource&op=select'.$from;
		echo '<div id="rsel_menu" class="custom cmain resource_cmain" style="display:none;width:956px;height:665px;" onmousedown="dragMenu($(\'rsel_menu\'), event, 1)">
			<div class="cnote" style="width:100%"><span class="right"><a href="###" class="flbc" onclick="hideMenu();return false;"></a></span><h3 style="cursor: move;">'.duceapp_cplang('resource_select').'</h3></div>
			<div id="rsel_content" style="overflow:hidden;height:639px;"></div>
		</div>
		<script type="text/JavaScript">
		var showResourceObj = null;
		var resourceGetUrl = \''.$url.'&id=\';
		var resourceExistsMsg = \''.duceapp_cplang('resource_exists').'\';
		function resource_showlist(obj, filter){
			showMenu({\'ctrlid\':\'rsel\',\'evt\':\'click\',\'duration\':3,\'pos\':\'00\'});
			showResourceObj = obj && typeof obj == \'string\' ? $(obj) : obj;
			ajaxget(\''.$url.$inner.'\' + (typeof filter != \'undefined\' ? \'&filter=\' + filter : \'\'), \'rsel_content\');
		}
		function resource_seltxt(c, id, text, filter){
			var key = filter == 2 ? \'media\' : \'resource\';
			showResourceObj.value = \'[\' + key + \'=\' + id + \'] \' + text;
			hideMenu();
		}
		</script>';
	}
}