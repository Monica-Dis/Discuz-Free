<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: class_duceapp_wechatmsgcrypt.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class duceapp_wechatmsgcrypt
{
	private static $_token;
	private static $_encodingAesKey;
	private static $_appId;
	private static $_key;
	private static $ERROR_NO = 0;
	private static $block_size = 32;
	private static $ERRCODE_MAP = array(
		'0' => '',
		'40001' => '&#x7b7e;&#x540d;&#x9a8c;&#x8bc1;&#x9519;&#x8bef;',
		'40002' => 'xml&#x89e3;&#x6790;&#x5931;&#x8d25;',
		'40003' => 'sha&#x52a0;&#x5bc6;&#x751f;&#x6210;&#x7b7e;&#x540d;&#x5931;&#x8d25;',
		'40004' => 'encodingAesKey &#x975e;&#x6cd5;',
		'40005' => 'appid &#x6821;&#x9a8c;&#x9519;&#x8bef;',
		'40006' => 'ase &#x52a0;&#x5bc6;&#x5931;&#x8d25;',
		'40007' => 'ase &#x89e3;&#x5bc6;&#x5931;&#x8d25;',
		'40008' => '&#x89e3;&#x5bc6;&#x540e;&#x5f97;&#x5230;&#x7684;buffer&#x975e;&#x6cd5;',
		'40009' => 'base64&#x52a0;&#x5bc6;&#x5931;&#x8d25;',
		'40010' => 'base64&#x89e3;&#x5bc6;&#x5931;&#x8d25;',
		'40011' => '&#x751f;&#x6210;xml&#x5931;&#x8d25;',
	);

	private static function init() {
		global $_G;
		if ($_GET['encrypt_type'] == 'aes') {
			if (!self::$_appId) {
				if (defined('DUCEAPP_ACCESS_COMPON')) {
					self::$_token = $_G['cache']['duceapp_wechat']['subscribe']['token'];
					self::$_encodingAesKey = $_G['cache']['duceapp_wechat']['subscribe']['encodingaeskey'];
					self::$_appId = $_G['cache']['duceapp_wechat']['subscribe']['appid'];
				} else {
					self::$_token = $_G['cache']['duceapp_wechat']['token'];
					self::$_encodingAesKey = $_G['cache']['duceapp_wechat']['encodingaeskey'];
					self::$_appId = $_G['cache']['duceapp_wechat']['mp']['appid'];
				}
				self::$_key = base64_decode(self::$_encodingAesKey . '=');
			}
			return true;
		}
		return false;
	}

	public static function encryptMsg(&$encryptMsg) {
		if (!self::init()) {
			return;
		}
		$encrypt = self::encrypt($encryptMsg);
		if (self::$ERROR_NO != 0) {
			return self::$ERROR_NO;
		}
		$timeStamp = $_GET['timestamp'];
		$nonce = $_GET['nonce'];
		
		$signature = self::getSHA1($timeStamp, $nonce, $encrypt);
		if (self::$ERROR_NO != 0) {
			return self::$ERROR_NO;
		}
		$encryptMsg = self::generate($encrypt, $signature, $timeStamp, $nonce);
		return 0;
	}

	public static function decryptMsg(&$postData) {
		if (!self::init()) {
			return;
		}
		if (strlen(self::$_encodingAesKey) != 43) {
			return self::$ERROR_NO = 40004;
		}
		try {
			$xml = new DOMDocument();
			$xml->loadXML($postData);
			$array_e = $xml->getElementsByTagName('Encrypt');
			$array_a = $xml->getElementsByTagName('ToUserName');
			$encrypt = $array_e->item(0)->nodeValue;
			$tousername = $array_a->item(0)->nodeValue;
		} catch (Exception $e) {
			return self::$ERROR_NO = 40002;
		}

		$timeStamp = $_GET['timestamp'];
		$nonce = $_GET['nonce'];

		$signature = self::getSHA1($timeStamp, $nonce, $encrypt);
		if (self::$ERROR_NO != 0) {
			return self::$ERROR_NO;
		}


		if ($signature != $_GET['msg_signature']) {
			return self::$ERROR_NO = 40003;
		}

		$msg = self::decrypt($encrypt);
		if (self::$ERROR_NO != 0) {
			return self::$ERROR_NO;
		}
		$postData = $msg;

		return 0;
	}

	private static function encrypt($text) {
		try {
			$text = self::getRandomStr() . pack("N", strlen($text)) . $text . self::$_appId;
			$iv = substr(self::$_key, 0, 16);
			$text = self::encode($text);
			if (version_compare(PHP_VERSION, '7.1.0', '>=')) {
				$encrypted = openssl_encrypt($text, 'AES-256-CBC', substr(self::$_key, 0, 32), OPENSSL_ZERO_PADDING, $iv);
				return $encrypted;
			} else {
				$size = mcrypt_get_block_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
				$module = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_CBC, '');
				mcrypt_generic_init($module, self::$_key, $iv);
				$encrypted = mcrypt_generic($module, $text);
				mcrypt_generic_deinit($module);
				mcrypt_module_close($module);
				return base64_encode($encrypted);
			}
		} catch (Exception $e) {
			return self::$ERROR_NO = 40006;
		}
	}

	private static function decrypt($encrypted) {		
		try {
			if (version_compare(PHP_VERSION, '7.1.0', '>=')) {
				$decrypted = openssl_decrypt($encrypted, 'AES-256-CBC', substr(self::$_key, 0, 32), OPENSSL_ZERO_PADDING, substr(self::$_key, 0, 16));
			} else {
				$ciphertext_dec = base64_decode($encrypted);
				$module = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_CBC, '');
				$iv = substr(self::$_key, 0, 16);
				mcrypt_generic_init($module, self::$_key, $iv);
				$decrypted = mdecrypt_generic($module, $ciphertext_dec);
				mcrypt_generic_deinit($module);
				mcrypt_module_close($module);
			}
		} catch (Exception $e) {
			return self::$ERROR_NO = 40007;
		}
		try {
			$result = self::decode($decrypted);
			if (strlen($result) < 16) return "";
			$content = substr($result, 16, strlen($result));
			$len_list = unpack("N", substr($content, 0, 4));
			$xml_len = $len_list[1];
			$xml_content = substr($content, 4, $xml_len);
			$from_appid = substr($content, $xml_len + 4);
		} catch (Exception $e) {
			return self::$ERROR_NO = 40008;
		}
		if ($from_appid != self::$_appId) {
			return self::$ERROR_NO = 40005;
		}
		return $xml_content;

	}

	private static function encode($text) {
		$text_length = strlen($text);

		$amount_to_pad = self::$block_size - ($text_length % self::$block_size);
		if ($amount_to_pad == 0) {
			$amount_to_pad = self::$block_size;
		}
		$pad_chr = chr($amount_to_pad);
		$tmp = "";
		for ($index = 0; $index < $amount_to_pad; $index++) {
			$tmp .= $pad_chr;
		}
		return $text . $tmp;
	}

	private static function decode($text) {
		$pad = ord(substr($text, -1));
		if ($pad < 1 || $pad > 32) {
			$pad = 0;
		}
		return substr($text, 0, (strlen($text) - $pad));
	}

	private static function getSHA1($timestamp, $nonce, $encrypt_msg) {
		try {
			$array = array($encrypt_msg,  self::$_token, $timestamp, $nonce);
			sort($array, SORT_STRING);
			$str = implode($array);
			return sha1($str);
		} catch (Exception $e) {
			return self::$ERROR_NO = 40003;
		}
	}

	private function getRandomStr() {
		$str = "";
		$str_pol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
		$max = strlen($str_pol) - 1;
		for ($i = 0; $i < 16; $i++) {
			$str .= $str_pol[mt_rand(0, $max)];
		}
		return $str;
	}

	private function generate($encrypt, $signature, $timestamp, $nonce)	{
		$format = "<xml>
<Encrypt><![CDATA[%s]]></Encrypt>
<MsgSignature><![CDATA[%s]]></MsgSignature>
<TimeStamp>%s</TimeStamp>
<Nonce><![CDATA[%s]]></Nonce>
</xml>";
		return sprintf($format, $encrypt, $signature, $timestamp, $nonce);
	}
}