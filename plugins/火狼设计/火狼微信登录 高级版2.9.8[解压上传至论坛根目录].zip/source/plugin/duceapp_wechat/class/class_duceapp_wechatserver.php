<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: class_duceapp_wechatserver.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')){
	exit('Access Denied');
}

class duceapp_wechatserver 
{
	private $_token;
	private $_hooks;
	private $_classes;

	public function __construct($token, $hooks = array()) {
		$this->_token = $token;
		$this->_hooks = $hooks;
		$this->accessDataPush();
	}

	private function _activeHook($type) {
		if (!isset($this->_hooks[$type])) {
			return null;
		}
		$hook = & $this->_hooks[$type];
		global $_G;
		if (!in_array($hook['plugin'], $_G['setting']['plugins']['available'])) {
			return null;
		}
		if (!preg_match("/^[\w\_]+$/i", $hook['plugin']) || !preg_match('/^([\w\_]+\/)?[\w\_\.]+\.php$/i', $hook['include'])) {
			return null;
		}
		include_once DISCUZ_ROOT . 'source/plugin/' . $hook['plugin'] . '/' . $hook['include'];
		if (!class_exists($hook['class'], false)) {
			return null;
		}
		if (!isset($this->classes[$hook['class']])) {
			$this->classes[$hook['class']] = new $hook['class'];
		}
		if (!method_exists($this->classes[$hook['class']], $hook['method'])) {
			return null;
		}
		$param = func_get_args();
		array_shift($param);
		return call_user_func(array($this->classes[$hook['class']], $hook['method']), $param);
	}

	private function _checkSignature() {
		$signature = $_GET["signature"];
		$timestamp = $_GET["timestamp"];
		$nonce = $_GET["nonce"];

		$token = $this->_token;
		$tmpArr = array($token, $timestamp, $nonce);
		sort($tmpArr, SORT_STRING);
		$tmpStr = implode($tmpArr);
		$tmpStr = sha1($tmpStr);

		return $tmpStr == $signature;
	}

	private function _handlePostObj($postObj) {
		$MsgType = strtolower((string) $postObj->MsgType);
		$result = array(
		    'from' => self::$_from_id = (string) htmlspecialchars($postObj->FromUserName),
		    'to' => self::$_my_id = (string) htmlspecialchars($postObj->ToUserName),
		    'time' => (int) $postObj->CreateTime,
		    'type' => (string) $MsgType
		);

		if (property_exists($postObj, 'MsgId')) {
			$result['id'] = $postObj->MsgId;
		}

		switch ($result['type']) {
			case 'text':
				$result['content'] = (string) $postObj->Content; // Content ��Ϣ����
				break;

			case 'location':
				$result['X'] = (float) $postObj->Location_X; // Location_X ����λ��γ��
				$result['Y'] = (float) $postObj->Location_Y; // Location_Y ����λ�þ���
				$result['S'] = (float) $postObj->Scale;      // Scale ��ͼ���Ŵ�С
				$result['I'] = (string) $postObj->Label;     // Label ����λ����Ϣ
				break;

			case 'image':
				$result['url'] = (string) $postObj->PicUrl;  // PicUrl ͼƬ���ӣ������߿�����HTTP GET��ȡ
				$result['mid'] = (string) $postObj->MediaId; // MediaId ͼƬ��Ϣý��id�����Ե��ö�ý���ļ����ؽӿ���ȡ���ݡ�
				break;

			case 'video':
				$result['mid'] = (string) $postObj->MediaId;      // MediaId ͼƬ��Ϣý��id�����Ե��ö�ý���ļ����ؽӿ���ȡ���ݡ�
				$result['thumbmid'] = (string) $postObj->ThumbMediaId; // ThumbMediaId ��Ƶ��Ϣ����ͼ��ý��id�����Ե��ö�ý���ļ����ؽӿ���ȡ���ݡ�
				break;

			case 'link':
				$result['title'] = (string) $postObj->Title;
				$result['desc'] = (string) $postObj->Description;
				$result['url'] = (string) $postObj->Url;
				break;

			case 'voice':
				$result['mid'] = (string) $postObj->MediaId;
				$result['format'] = (string) $postObj->Format;
				if (property_exists($postObj, Recognition)) {
					$result['txt'] = (string) $postObj->Recognition;
				}
				break;

			case 'event':
				$result['event'] = strtolower((string) $postObj->Event);
				switch ($result['event']) {

					case 'subscribe':
					case 'scan':
						if (property_exists($postObj, EventKey)) {
							$result['key'] = str_replace(
								'qrscene_', '', (string) $postObj->EventKey
							);
							$result['ticket'] = (string) $postObj->Ticket;
						}
						break;

					case 'location':
						$result['la'] = (string) $postObj->Latitude;
						$result['lo'] = (string) $postObj->Longitude;
						$result['p'] = (string) $postObj->Precision;
						break;

					case 'click':
						$result['key'] = (string) $postObj->EventKey;
						break;
					case 'masssendjobfinish':
						$result['msg_id'] = (string) $postObj->MsgID;
						$result['status'] = (string) $postObj->Status;
						$result['totalcount'] = (string) $postObj->TotalCount;
						$result['filtercount'] = (string) $postObj->FilterCount;
						$result['sentcount'] = (string) $postObj->SentCount;
						$result['errorcount'] = (string) $postObj->ErrorCount;
						break;
					case 'templatesendjobfinish':
						$result['msg_id'] = (string) $postObj->MsgID;
						$result['status'] = (string) $postObj->Status;
						break;
				}
		}

		return $result;
	}

	private function accessDataPush() {
		if (!$this->_checkSignature()) {
			if (!headers_sent()) {
				header('HTTP/1.1 404 Not Found');
				header('Status: 404 Not Found');
			}
			$this->_activeHook('404');
			return;
		}

		$postdata = file_get_contents("php://input");
		if ($postdata) {
			if (!$this->_checkSignature()) {
				return;
			}

			$errorCode = duceapp_wechatmsgcrypt::decryptMsg($postdata);

			$postObj = simplexml_load_string($postdata, 'SimpleXMLElement', LIBXML_NOCDATA);
			$postObj = $this->_handlePostObj($postObj);

			$this->_activeHook('receiveAllStart', $postObj);

			if (isset($postObj['event'])) {
				$hookName = 'receiveEvent::' . $postObj['event'];
			} else {
				$hookName = 'receiveMsg::' . $postObj['type'];
			}
			$this->_activeHook($hookName, $postObj);

			$this->_activeHook('receiveAllEnd', $postObj);
		} elseif (isset($_GET['echostr'])) {

			$this->_activeHook('accessCheckSuccess');
			if (!headers_sent()) {
				header('Content-Type: text/plain');
			}
			echo preg_replace('/[^a-z0-9]/i', '', $_GET['echostr']);
		}
	}

	private static $_from_id;
	private static $_my_id;

	private static function _format2xml($nodes) {
		$xml = '<xml>'
			. '<ToUserName><![CDATA[%s]]></ToUserName>'
			. '<FromUserName><![CDATA[%s]]></FromUserName>'
			. '<CreateTime>%s</CreateTime>'
			. '%s'
			. '</xml>';
		$return = sprintf(
			$xml, self::$_from_id, self::$_my_id, time(), $nodes
		);
		$errorCode = duceapp_wechatmsgcrypt::encryptMsg($return = diconv($return, CHARSET, 'UTF-8'));
		return $return;
	}

	public static function getXml4Txt($txt) {
		$xml = '<MsgType><![CDATA[text]]></MsgType>'
			. '<Content><![CDATA[%s]]></Content>';
		return self::_format2xml(
				sprintf(
					$xml, $txt
				)
		);
	}

	public static function getXml4ImgByMid($mid) {
		$xml = '<MsgType><![CDATA[image]]></MsgType>'
			. '<Image>'
			. '<MediaId><![CDATA[%s]]></MediaId>'
			. '</Image>';
		return self::_format2xml(
				sprintf(
					$xml, $mid
				)
		);
	}

	public static function getXml4VoiceByMid($mid) {
		$xml = '<MsgType><![CDATA[voice]]></MsgType>'
			. '<Voice>'
			. '<MediaId><![CDATA[%s]]></MediaId>'
			. '</Voice>';
		return self::_format2xml(
				sprintf(
					$xml, $mid
				)
		);
	}

	public static function getXml4VideoByMid($mid, $title, $desc = '') {
		$desc = '' !== $desc ? $desc : $title;
		$xml = '<MsgType><![CDATA[video]]></MsgType>'
			. '<Video>'
			. '<MediaId><![CDATA[%s]]></MediaId>'
			. '<Title><![CDATA[%s]]></Title>'
			. '<Description><![CDATA[%s]]></Description>'
			. '</Video>';

		return self::_format2xml(
				sprintf(
					$xml, $mid, $title, $desc
				)
		);
	}

	public static function getXml4MusicByUrl($url, $thumbmid, $title, $desc = '', $hqurl = '') {
		$xml = '<MsgType><![CDATA[music]]></MsgType>'
			. '<Music>'
			. '<Title><![CDATA[%s]]></Title>'
			. '<Description><![CDATA[%s]]></Description>'
			. '<MusicUrl><![CDATA[%s]]></MusicUrl>'
			. '<HQMusicUrl><![CDATA[%s]]></HQMusicUrl>'
			. '<ThumbMediaId><![CDATA[%s]]></ThumbMediaId>'
			. '</Music>';

		return self::_format2xml(
				sprintf(
					$xml, $title, '' === $desc ? $title : $desc, $url, $hqurl ? $hqurl : $url, $thumbmid
				)
		);
	}

	public static function getXml4RichMsgByArray($list) {
		$max = 10;
		$i = 0;
		$ii = count($list);
		$list_xml = '';
		while ($i < $ii && $i < $max) {
			$item = $list[$i++];
			$list_xml .=
				sprintf(
				'<item>'
				. '<Title><![CDATA[%s]]></Title> '
				. '<Description><![CDATA[%s]]></Description>'
				. '<PicUrl><![CDATA[%s]]></PicUrl>'
				. '<Url><![CDATA[%s]]></Url>'
				. '</item>', $item['title'], $item['desc'], $item['pic'], $item['url']
			);
		}

		$xml = '<MsgType><![CDATA[news]]></MsgType>'
			. '<ArticleCount>%s</ArticleCount>'
			. '<Articles>%s</Articles>';

		return self::_format2xml(
				sprintf(
					$xml, $i, $list_xml
				)
		);
	}

}