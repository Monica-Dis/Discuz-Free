<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2019-06-17
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: class_duceapp_helper.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class duceapp_helper
{
	public static function messagefunc($hscript, $script, $plugin_module, $method, $adminid = 0) {
		global $_G;
		if (strpos($plugin_module, '/')) {
			$class = dirname($plugin_module);
		} else {
			$class = $plugin_module;
			$plugin_module = $class.'/'.$class;
		}
		$msghook = $_G['setting'][HOOKTYPE][$hscript][$script];
		$msghook['module'][$class] = $plugin_module;
		$msghook['adminid'][$class] = $adminid;
		$msghook['messagefuncs'][$script][] = array($class, $method);
		$_G['setting'][HOOKTYPE][$hscript][$script] = $msghook;
	}
}