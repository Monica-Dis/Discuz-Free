<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.91221
 * Date: 2020-08-06 03:25:46
 * File: class_duceapp_admincompon.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

class duceapp_compon extends duceapp_admincp
{
	public function __construct() {
		$this->header();

		if ($this->cmod) {
			$compare = duceapp_checkcompon($this->cmod);
			if ($compare && $compare['exec']) {
				duceapp_anchortips(duceapp_cplang('compon_tips', array('ident' => DUCEAPP_IDENT)), 'app', 1, 'tips');
				echo '<div class="duceapp_compon"><table class="tb2 duceapp_tb"><tr><td><ul>';
				$logofile = DUCEAPP_DIRURL.'static/'.$this->cmod.'.png';
				if (!is_file($logofile)) {
					$logofile = DUCEAPP_BASEURL.'static/image/compon.png';
				}
				$compare['addonid'] = $compare['exec'] === 1 && $compare['addonid'] ? $compare['addonid'] : $compare['duceapp_addonid'];
				echo '<li><em>'.$this->compons[$this->cmod].'</em><a href="javascript:;" style="background-image:url('.$logofile.')">'.duceapp_cplang('menu_'.$this->cmod).'</a></li>';
				echo '<li class="addonupdate"><a href="https://dism.taobao.com/?@'.DUCEAPP_IDENT.'.plugin'.($compare['addonid'] ? '.'.$compare['addonid'] : '').'">'.($compare['exec'] === 1 ? duceapp_cplang('version_compon_failed', array('now' => $this->compons[$this->cmod], 'new' => $compare['admin'])) : duceapp_cplang('version_main_failed', array('now' => DUCEAPP_VERSION, 'new' => $compare['main']))).'</a></li></ul>';
				echo '</td></tr></table></div>';
				if ($compare['disabled'] && $this->setting[$this->cmod]['enabled']) {
					$this->setting[$this->cmod]['enabled'] = 0;
					$this->updatebatch = true;
				}
			} else {
				@include_once DUCEAPP_COMPONROOT.$this->cmod.'.class.php';
				if (class_exists($classname = 'duceapp_compon_'.$this->cmod, false)) {
					$compon_obj = new $classname();
					$compon_obj->setting = & $this->setting;
					$compon_obj->danchor = & $this->danchor;
					$compon_obj->cpmethod = & $this->cpmethod;
					$compon_obj->stated = & $this->stated;
					$compon_obj->basescript = & $this->basescript;
					$compon_obj->redirect = & $this->redirect;
					$compon_obj->updatebatch = & $this->updatebatch;
					if (is_object($this->cache)) {
						$compon_obj->cache = & $this->cache;
					}
					$compon_obj->init();
				}
			}
		} else {
			global $plugin;
			$api = trim($_GET['api']);
			duceapp_anchortips(duceapp_cplang('compon_'.$api.'tips', array('ident' => DUCEAPP_IDENT)), 'app', 1, 'tips');
			echo '<div class="duceapp_compon"><table class="tb2 duceapp_tb"><tr><td><ul>';
			if ($this->compons) {
				foreach($this->compons as $compon => $version){
					if ($compon && ((!$api && (!$plugin['duceapp_api'] || !in_array($compon, $plugin['duceapp_api']))) || ($api && in_array($compon, $plugin['duceapp_api'])))) {
						$logofile = DUCEAPP_DIRURL.'static/image/'.$compon.'.png';
						if (!is_file($logofile)) {
							$logofile = DUCEAPP_BASEURL.'static/image/compon.png';
						}
						echo '<li><em>'.$version.'</em><a href="'.$this->redirect.'&cmod='.$compon.'" style="background-image:url('.$logofile.')">'.duceapp_cplang('menu_'.$compon).'</a></li>';
					}
				}
			}
			echo '<li class="addon"><a href="https://dism.taobao.com/?@'.DUCEAPP_IDENT.'.plugin"><span></span><span class="vertical"></span></a></li></ul></td></tr></table></div>';
		}

		$this->footer();
	}
}