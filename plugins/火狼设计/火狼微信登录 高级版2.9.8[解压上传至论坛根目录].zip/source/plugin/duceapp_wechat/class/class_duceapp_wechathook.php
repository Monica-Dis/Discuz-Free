<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: class_duceapp_wechathook.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

!defined('IN_DISCUZ') && exit('Access Denied');

class duceapp_wechathook
{
	public static function updateAppInfo($extId, $appId = '', $appSecret = '') {
		global $_G;
		$wechatappInfos = unserialize($_G['setting']['wechatappInfos']);
		if ($appId) {
			$wechatappInfos[$extId] = array('appId' => $appId, 'appSecret' => $appSecret);
		} else {
			unset($wechatappInfos[$extId]);
		}
		$settings = array('wechatappInfos' => serialize($wechatappInfos));
		C::t('common_setting')->update_batch($settings);
		updatecache('setting');
	}

	public static function getAppInfo($extId) {
		global $_G;
		$wechatappInfos = unserialize($_G['setting']['wechatappInfos']);
		if (isset($wechatappInfos[$extId])) {
			return $wechatappInfos[$extId];
		} else {
			return array();
		}
	}

	public static function updateResponse($data, $extId = '') {
		$response = self::getResponse($extId);
		foreach ($data as $key => $value) {
			if ($value) {
				if ($value['plugin'] && $value['include'] && $value['class'] && $value['method']) {
					$response[$key] = $value;
				}
			} else {
				unset($response[$key]);
			}
		}
		if (!$extId) {
			$settings = array('wechatresponse' => serialize($response));
		} else {
			global $_G;
			$wechatresponseExts = unserialize($_G['setting']['wechatresponseExts']);
			if ($data) {
				$wechatresponseExts[$extId] = $response;
			} else {
				unset($wechatresponseExts[$extId]);
			}
			$settings = array('wechatresponseExts' => serialize($wechatresponseExts));
		}
		C::t('common_setting')->update_batch($settings);
		updatecache('setting');
		return $response;
	}

	public static function getResponse($extId = '') {
		global $_G;
		if (!$extId) {
			return unserialize($_G['setting']['wechatresponse']);
		} else {
			$wechatresponseExts = unserialize($_G['setting']['wechatresponseExts']);
			return $wechatresponseExts[$extId];
		}
	}

	public static function updateRedirect($value) {
		if (!$value || $value['plugin'] && $value['include'] && $value['class'] && $value['method']) {
			$settings = array('wechatredirect' => $value);
			C::t('common_setting')->update_batch($settings);
			updatecache('setting');
		}
	}

	public static function getRedirect() {
		global $_G;
		return unserialize($_G['setting']['wechatredirect']);
	}

	public static function getViewPluginId() {
		global $_G;
		return $_G['setting']['wechatviewpluginid'];
	}

	public static function updateViewPluginId($value) {
		$settings = array('wechatviewpluginid' => $value);
		C::t('common_setting')->update_batch($settings);
		updatecache('setting');
	}

	public static function updateAPIHook($datas) {
		$apihook = self::getAPIHook();
		foreach ($datas as $data) {
			foreach ($data as $key => $value) {
				if (!$value['plugin']) {
					continue;
				}
				list($module, $hookname) = explode('_', $key);
				if ($value['include'] && $value['class'] && $value['method']) {
					$v = $value;
					unset($v['plugin']);
					$v['allow'] = 1;
					$apihook[$module][$hookname][$value['plugin']] = $v;
				} else {
					unset($apihook[$module][$hookname][$value['plugin']]);
				}
			}
		}
		$settings = array('mobileapihook' => serialize($apihook));
		C::t('common_setting')->update_batch($settings);
		updatecache('setting');
		return $apihook;
	}

	public static function getAPIHook($getplugin = '') {
		global $_G;
		$data = unserialize($_G['setting']['mobileapihook']);
		if (!$getplugin) {
			return $data;
		} else {
			foreach ($data as $key => $hooknames) {
				foreach ($hooknames as $hookname => $plugins) {
					foreach ($plugins as $plugin => $value) {
						if ($getplugin != $plugin) {
							unset($data[$key][$hookname][$plugin]);
						}
					}
				}
			}
			return $data;
		}
	}

	public static function delAPIHook($getplugin) {
		if (!$getplugin) {
			return;
		}
		$getplugins = (array) $getplugin;
		$apihook = self::getAPIHook();
		foreach ($apihook as $key => $hooknames) {
			foreach ($hooknames as $hookname => $plugins) {
				foreach ($plugins as $plugin => $value) {
					if (in_array($plugin, $getplugins)) {
						unset($apihook[$key][$hookname][$plugin]);
					}
				}
			}
		}
		$settings = array('mobileapihook' => serialize($apihook));
		C::t('common_setting')->update_batch($settings);
		updatecache('setting');
		return $apihook;
	}	
}