<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: table_duceapp_wechat_masssend.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_duceapp_wechat_masssend extends discuz_table {

	public function __construct() {
		$this->_table = 'duceapp_wechat_masssend';
		$this->_pk = 'id';

		parent::__construct();
	}

}