<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.90614
 * Date: 2020-08-06 03:25:46
 * File: table_duceapp_wechat_authcode.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_duceapp_wechat_authcode extends discuz_table {

	public function __construct() {
		$this->_table = 'duceapp_wechat_authcode';
		$this->_pk = 'sid';

		parent::__construct();
	}

	public function fetch_by_code($code) {
		return DB::fetch_first('SELECT * FROM %t WHERE code=%d', array($this->_table, $code));
	}

	public function delete_history() {
		$time = TIMESTAMP - 3600;
		return DB::delete($this->_table, "createtime<$time");
	}

}