<?php

/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com
 * Created: 2018-11-21
 * Version: 3.00428
 * Date: 2020-08-06 03:25:46
 * File: table_duceapp_wechat_member.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       https://Dism.taobao.com/
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_duceapp_wechat_member extends discuz_table {

	public function __construct() {
		$this->_table = 'duceapp_wechat_member';
		$this->_pk = 'uid';
		$this->_pre_cache_key = 'duceapp_wechat_member_';

		parent::__construct();
	}

	public function count_all_member($uid = null) {
		$where = $uid !== null ? ' WHERE m.'.DB::field('uid', $uid) : '';
		return DB::result_first("SELECT COUNT(*) FROM %t w INNER JOIN %t m ON m.uid=w.uid %i", array($this->_table, 'common_member', $where));
	}

	public function fetch_all_member($uid = null, $start = 0, $limit = 0, $orderby = 'binddate', $sort = 'desc') {
		return $this->fetch_all_member_by_uid($uid, $start, $limit, array('common_member_count' => '*'), $orderby, $sort);
	}

	public function count_by_emptyunionid() {
		return DB::result_first("SELECT COUNT(*) FROM %t w INNER JOIN %t m ON m.uid=w.uid WHERE w.unionid=''", array($this->_table, 'common_member'));
	}

	public function fetch_by_emptyunionid($start = 0, $limit = 30) {
		return DB::fetch_all("SELECT w.uid,w.openid FROM %t w 
			INNER JOIN %t m ON m.uid=w.uid 
			WHERE w.unionid='' ORDER BY w.dateline ASC ".DB::limit($start, $limit), array($this->_table, 'common_member'));
	}

	public function fetch_all_member_by_uid($uid, $start = 0, $limit = 0, $exttable = array(), $orderby = '', $sort = 'desc') {
		if (empty($uid) && $uid !== null) {
			return array();
		}
		$orders = array('uid', 'binddate', 'lastauth', 'credits');
		$column = 'w.*, m.*, w.status AS wechat_status, w.dateline AS binddate';
		$sql = " INNER JOIN ".DB::table('common_member')." m ON m.uid=w.uid";
		$i = 0;
		if (!empty($exttable) && is_array($exttable)) {
			foreach($exttable as $table => $fields) {
				if ($fields && (is_array($fields) || $fields == '*')) {
					$t = 'm'.($i++);
					$sql .= " LEFT JOIN ".DB::table($table)." {$t} ON {$t}.uid=w.uid";
					if ($fields == '*') {
						$column .= ", {$t}.*";
						if ($table == 'common_member_count') {
							$orders[] = 'posts';
							$orders[] = 'threads';
						}
					} else {
						foreach($fields as $field) {
							$column .= ", {$t}.$field";
							if ($field != '*') {
								$orders[] = $field;
							}
						}
					}
				}
			}
		}
		$orderby = in_array($orderby, $orders, true) ? $orderby : '';
		$sql .= !empty($uid) ? " WHERE w.".DB::field('uid', $uid) : '';
		$sql .= $orderby ? " ORDER BY ".DB::order($orderby, $sort) : '';
		$memberlist = array();
		$query = DB::query("SELECT $column FROM ".DB::table($this->_table)." w {$sql}".DB::limit($start, $limit));
		while($member = DB::fetch($query)) {
			$memberlist[$member['uid']] = $member;
		}
		return $memberlist;
	}

	public function fetch_by_search($filter = null, $start = 0, $limit = 0) {
		$wherearr = array(1);
		if ($filter && is_array($filter)) {
			foreach($filter as $key => $value) {
				if ($value && in_array($key, array('uid', 'openid', 'unionid', 'sex'))) {
					$wherearr[] = DB::field($key, $value);
				} elseif (in_array($key, array('dateline', 'lastauth', 'lat', 'lng'))) {
					$is_array = is_array($value) ? 1 : 0;
					$value = dintval($value, $is_array);
					if ($is_array) {
						if ($value[0]) {
							$wherearr[] = DB::field($key, $value[0], '>=');
						}
						if ($value[1]) {
							$wherearr[] = DB::field($key, $value[1], '<=');
						}
					} elseif($value) {
						$wherearr[] = DB::field($key, $value, '>=');
					}
				}
			}
		}
		return DB::fetch_all('SELECT * FROM %t WHERE %i '.DB::limit($start, $limit), array($this->_table, implode(' AND ', $wherearr)), $this->_pk);
	}

	public function fetch_by_openid($openid) {
		return DB::fetch_first('SELECT * FROM %t WHERE openid=%s', array($this->_table, $openid));
	}

	public function fetch_by_unionid($access) {
		global $_G;
		$res = null;
		if ($access['unionid']) {
			$res = DB::fetch_first('SELECT * FROM %t WHERE unionid=%s', array($this->_table, $access['unionid']));
		}
		return $res ? $res : $this->fetch_by_openid($access['openid']);
	}

	public function delete($uid, $unbuffered = false) {
		global $_G;
		return DB::delete($this->_table, DB::field('uid', $uid), 0, $unbuffered);
	}

}