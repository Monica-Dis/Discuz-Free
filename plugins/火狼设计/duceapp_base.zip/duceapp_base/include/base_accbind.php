<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-10-07
 * Version: 3.01120
 * Date: 2021-06-30 22:19:57
 * File: base_accbind.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$_G['uid']){
	dheader('location:'.$_G['siteurl'].'member.php?mod=logging&action=login');
}

if ($_GET['plid'] && $_G['setting']['plugins']['spacecp'][$_GET['plid']]['url']) {
	dheader('location:' . $_G['setting']['plugins']['spacecp'][$_GET['plid']]['url']);
}

define('DUCEAPP_CURSCRIPT', 'home');
include template('duceapp_base:accbind');