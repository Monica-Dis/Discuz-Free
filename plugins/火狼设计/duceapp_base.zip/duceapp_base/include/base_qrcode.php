<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-02-10
 * Version: 3.90629
 * Date: 2021-06-30 22:19:57
 * File: base_qrcode.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

dheader('Expires: '.gmdate('D, d M Y H:i:s', TIMESTAMP + 86400).' GMT');

$dir = DISCUZ_ROOT.'./data/duceapp/base/qrcode/';
$url = $_G['siteurl'];
$file = false;
$filename = 'index';

if ($_GET['access'] == 'index') {
	$file = $dir.'qr_index.jpg';
} elseif ($_GET['tid']) {
	if (empty($_GET['pid'])) {
		$tid = intval($_GET['tid']);
		$dtid = sprintf("%09d", $tid);
		$dir1 = substr($dtid, 0, 3);
		$dir2 = substr($dtid, 3, 2);
		$dir3 = substr($dtid, 5, 2);
		$dir = $dir.$dir1.'/'.$dir2.'/'.$dir3.'/';
		$file = $dir.'/qr_t'.$tid.'.jpg';
		$filename = 't'.$tid;
		$url .= 'forum.php?mod=viewthread&tid='.$tid;
	} else {
		$url .= 'forum.php?mod=viewthread&tid='.$_GET['tid'].'&viewpid='.$_GET['pid'];
	}
} elseif ($_GET['fid']) {
	$fid = intval($_GET['fid']);
	$url .= 'forum.php?mod=forumdisplay&fid='.$fid;
	$file = $dir.'qr_f'.$fid.'.jpg';
	$filename = 'f'.$fid;
} elseif ($_GET['request'] && ($_GET['request'] = authcode(base64_decode($_GET['request']), 'DECODE'))) {
	$url = preg_match('/:\/\//i', $_GET['request']) ? $_GET['request'] : $url.$_GET['request'];
	$filename = random(6);
} else {
	exit;
}

$qrsize = !empty($_GET['size']) ? $_GET['size'] : 3;

if (!$file) {
	include_once libfile('class/duceapp_qrcode', 'plugin/duceapp_base');
	QRcode::png($url, false, QR_ECLEVEL_M, $qrsize);
	exit;
} elseif (!file_exists($file) || !filesize($file)) {
	if ($_GET['fid'] && !C::t('forum_forum')->fetch($fid)) {
		exit;
	}
	if ($_GET['tid'] && !C::t('forum_thread')->fetch($tid)) {
		exit;
	}
	dmkdir($dir);
	include_once libfile('class/duceapp_qrcode', 'plugin/duceapp_base');
	QRcode::png($url, $file, QR_ECLEVEL_M, $qrsize);
}

dheader('Content-Disposition: inline; filename=qrcode_'.$filename.'.jpg');
dheader('Content-Type: image/pjpeg');
@readfile($file);
exit;