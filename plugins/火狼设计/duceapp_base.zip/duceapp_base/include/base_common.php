<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-02-10
 * Version: 3.90629
 * Date: 2021-06-30 22:19:57
 * File: base_common.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

showmessage('undefined_action', '', array(), array('showdialog' => 1));