<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-02-10
 * Version: 3.01107
 * Date: 2021-06-30 22:19:57
 * File: addon.class.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if(!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

class duceapp_compon_addon
{
	public function init() {
		global $plugin;
		if (!file_exists($menu = DISCUZ_ROOT.'./source/admincp/menu/menu_duceapp.php')) {
			dmkdir(DISCUZ_ROOT.'./source/admincp/menu/');
			@copy(DUCEAPP_ROOT.'./install/menu_duceapp.php', $menu);
			if (!file_exists($menu)) {
				echo '<div class="infobox">
				<h4 style="font-weight:700;line-height:22px;font-size:14px;color:#090;">'.duceapp_cplang('menudir_nolimited').'</h4>
				<p class="marginbot" style="margin-top:15px;"><a href="javascript:history.go(-1);" class="lightlink">'.cplang('message_return').'</a></p>
				</div>';
				$plugin['duceapp_core']->footer();
				exit;
			}
		}
		dheader('location:'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin['pluginid'].'&duceapp=addon');
	}
}