<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-02-19
 * Version: 3.10203
 * Date: 2021-06-30 22:19:57
 * File: api.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

define('IN_API', true);
define('ALLOWGUEST', 1);

chdir('../../../');

require 'source/class/class_core.php';

$discuz = C::app();
$cachelist = array('plugin');
$discuz->cachelist = $cachelist;
$discuz->init();

C::m('#duceapp_base#duceapp_helper')->checkreferer();

$_G['siteurl'] = str_replace('source/plugin/duceapp_template/', '', $_G['siteurl']);

$op = $_GET['op'];
	

if ($op == 'imageblur') {
	$srcimg = authcode($_GET['srcimg'], 'DECODE');
	$srcimg = str_replace(array($_G['siteurl'], DISCUZ_ROOT), '', $srcimg);
	$path = dirname($srcimg);
	$name = substr(md5(basename($srcimg)), 0, 22).'.jpg';
	if (file_exists($path.'/'.$name) && @filemtime($path.'/'.$name) > TIMESTAMP - 7200) {
		$imagefile = $path.'/'.$name;
	} else {
		$imagefile = C::m('#duceapp_base#duceapp_imageblur')->gaussian_blur($srcimg, null, $name, 6);
	}
	if ($imagefile) {
		if ($_GET['s'] == 1) {
			echo $imagefile;
		} else {
			echo file_get_contents($imagefile);
		}
	}
}

exit();