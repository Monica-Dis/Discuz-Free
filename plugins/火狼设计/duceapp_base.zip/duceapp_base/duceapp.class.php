<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-10-07
 * Version: 3.10128
 * Date: 2021-06-30 22:19:57
 * File: duceapp.class.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_duceapp_base
{
	public function common() {
		global $_G;
		if (!isset($_G['duceapp_base'])) {
			$_G['duceapp_base'] = dunserialize($_G['setting']['duceapp_base']);
		}
		define('DUCEAPP_RELEASE', '1.8.3');
		define('DUCEAPP_BASE', dirname(__FILE__).'/');
	}

	public function deletemember($param) {
		$uids = $param['param'][0];
		if ($param['step'] == 'delete' && $uids && is_array($uids)) {
			if (!defined('DUCEAPP_DELETEMEMBER')){
				foreach($uids as $uid) {
					C::t('#duceapp_base#duceapp_member')->delete($uid);
				}
				define('DUCEAPP_DELETEMEMBER', true);
			}
		}
	}

	public function global_footer() {
		global $_G;
		if (defined('IN_MOBILE')) {
			return;
		}
		$_G['connect']['loginbind_url'] = $_G['connect']['login_url'];
		if ($_G['duceapp_base']['pageqrcode']['enable'] > 0) {
			include_once template('duceapp_base:pageqrcode');
			$modid = $_G['basescript'].'::'.CURMODULE;
			if ($modid == 'forum::forumdisplay' && !empty($_GET['fid'])) {
				$idstr = '&fid='.intval($_GET['fid']);
				return duceapp_pageqrcode($idstr);
			} elseif ($modid == 'forum::viewthread' && !empty($_GET['tid'])) {
				$idstr = '&tid='.intval($_GET['tid']);
				return duceapp_pageqrcode($idstr);
			} elseif ($modid == 'forum::index') {
				return duceapp_pageqrcode('&access=index');
			}
		}
		$this->_spacecpmenu(CURSCRIPT == 'home' && $_GET['mod'] == 'spacecp' || (CURSCRIPT == 'plugin' && strpos($_GET['id'], 'duceapp_') !== FALSE));
	}

	public static function _spacecpnav() {
		global $_G;
		$navs = array('duceapp_wallet' => '', 'duceapp_vip' => '', 'duceapp_smsauth' => '', 'duceapp_base' => '');
		foreach($_G['setting']['plugins']['spacecp'] as $id => $module) {
			list($pluginid) = explode(':', $id);
			if (strpos($pluginid, 'duceapp_') !== FALSE) {
				$navs[$pluginid] = '<li'.($_GET['id'] == $id ? ' class="a"' : '').'><a href="home.php?mod=spacecp&ac=plugin&id='.$id.'">'.$module['name'].'</a></li>';
				unset($_G['setting']['plugins']['spacecp'][$id]);
			}
		}
		return implode('', $navs);
	}

	public function _spacecpmenu($force = true) {
		global $_G;		
		if (defined('DUCEAPP_ACCBIND') || $_GET['id'] == 'duceapp_base') {
			return;
		}
		if ($force && $_G['duceapp_base']['accbind']) {
			if (!defined('IN_MOBILE') && $_GET['ac'] == 'plugin') {
				list($pluginid) = explode(':', $_GET['id']);
				if (in_array($pluginid, $_G['duceapp_base']['accbind']) || in_array($_GET['id'], $_G['duceapp_base']['accbind'])) {
					if ($_G['setting']['plugins']['spacecp'][$_GET['id']]['url']) {
						$url = $_G['setting']['plugins']['spacecp'][$_GET['id']]['url'];
					} else {
						$url = 'plugin.php?id=duceapp_base&ac=accbind';
						$url .= '&plid='.$_GET['id'];
						foreach($_GET as $k => $v){
							if (!in_array($k, array('mod','ac','id'))){
								$url .= '&'.$k.'='.$v;
							}
						}					
					}
					dheader('location:'.$url);
				}
			}
			foreach($_G['duceapp_base']['accbind'] as $ident) {
				$ident = strpos($ident, ':') !== false ? $ident : $ident.':spacecp';
				if (isset($_G['setting']['plugins']['spacecp'][$ident])) {
					unset($_G['setting']['plugins']['spacecp'][$ident]);
				}
			}
			C::m('#duceapp_base#duceapp_helper')->pluginmenu('spacecp', 'duceapp_base:accbind', array(
				'name' => lang('plugin/duceapp_base', 'accbind'),
				'url' => 'plugin.php?id=duceapp_base&ac=accbind',
				'icon' => '&#xe9a1;',
			));
			define('DUCEAPP_ACCBIND', true);
		}
	}
}

class plugin_duceapp_base_home extends plugin_duceapp_base
{
	public function spacecp_plugin() {
		global $_G;
		if (defined('IN_MOBILE')) {
			return;
		}
		$this->_spacecpmenu();
	}
}

class plugin_duceapp_base_misc extends plugin_duceapp_base
{
	public function swfupload() {
		global $_G;
		if ($_G['duceapp_base']['thumbwidth']) {
			$_G['setting']['thumbstatus'] = 'fixnone';
			$_G['setting']['thumbwidth'] = intval($_G['duceapp_base']['thumbwidth']);
		}
	}
}

class mobileplugin_duceapp_base extends plugin_duceapp_base
{
	public function global_footer() {}
	public function global_spacecp() {}
}

class mobileplugin_duceapp_base_misc extends plugin_duceapp_base_misc{}

class mobileplugin_duceapp_base_home extends plugin_duceapp_base_home
{
	public function space_profile_output() {
		global $_G, $space;
		if ($space['self'] && $_GET['mycenter'] && defined('IN_DUCEAPP')) {
			$this->_spacecpmenu();
		}
	}
}