<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-02-10
 * Version: 3.10528
 * Date: 2021-06-30 22:19:57
 * File: cron_clearcache.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

/*
cronname:duceapp_clearcache
week:
day:
hour:03
minute:30
*/

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

duceapp_clearcachedir(DISCUZ_ROOT.'./data/duceapp/base/qrcode', 86400, '/^qr\_t\d+\.jpg$/i');
duceapp_clearcachedir($_G['setting']['attachdir'].'thumb', 86400 * 7);

function duceapp_clearcachedir($dirname, $timelife = 0, $regex = '') {
	$dirname = str_replace(array( "\n", "\r", '..'), array('', '', ''), $dirname);
	if (!is_dir($dirname)) {
		return FALSE;
	}
	$handle = opendir($dirname);
	while(($file = readdir($handle)) !== FALSE) {
		if($file != '.' && $file != '..') {
			$dir = $dirname . DIRECTORY_SEPARATOR . $file;
			if (is_dir($dir)) {
				duceapp_clearcachedir($dir, $timelife, $regex);
			} elseif($timelife <= 0 || ((!$regex || preg_match($regex, $dir)) && @filemtime($dir) + $timelife < TIMESTAMP)) {
				@unlink($dir);
			}
		}
	}
	closedir($handle);
}