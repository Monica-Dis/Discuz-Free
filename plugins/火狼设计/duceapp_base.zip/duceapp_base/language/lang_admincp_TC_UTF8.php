<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-10-07
 * Version: 3.10102
 * Date: 2021-06-30 22:19:57
 * File: lang_admincp.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$duceapp_cplang = array
(
	'setting_basic' => '基本參數',
	'setting_thumbwidth' => '縮略圖寬度',
	'setting_thumbwidth_comment' => '編輯器上傳的圖片將會縮略到此寬度，不填或0按係統默認',
	'setting_bdapikey' => '百度地圖API密鑰碼(瀏覽器端)',
	'setting_bdapikey_comment' => '百度地圖API密鑰碼<a href="http://lbsyun.baidu.com" target="_blank">點這裏免費申請</a>',
	'setting_memory' => '內存優化',
	'setting_memory_tips' => '<li>啟用內存優化功能將會大幅度提升程序性能和服務器的負載能力，性能優化到係統全局中配置</li><li>下列功能模塊為火狼插件相關通用數據</li>',
	'setting_memory_member' => '用戶數據',
	'setting_memory_member_comment' => '推薦開啟，時間設置為0，永不過期，UID為單位，表數據更新時緩存數據會同步更新',
	'setting_memory_member_orders' => '用戶訂單數據',
	'setting_memory_member_orders_comment' => '推薦開啟，時間設置為0，永不過期，UID為單位，表數據更新時緩存數據會同步更新',
	'setting_pageqrcode' => '是否顯示頁麵二維碼',
	'setting_pageqrcode_comment' => '在頁麵右側懸浮顯示頁麵鏈接的二維碼，用戶可通過移動設備掃描訪問',
	'setting_pageqrcode1' => '頂部對齊',
	'setting_pageqrcode2' => '底部對齊',
	'setting_pageqrtext' => '二維碼下方的提示文字',
	'setting_pageqrtext_comment' => '不填寫按插件默認文字顯示',
	'setting_pageqrpos' => '二維碼距離窗口的值',
	'setting_pageqrpos_comment' => '二維碼距離窗口頂部或底部邊緣的值，0或不填按默認220',
	'setting_accbind' => '賬號綁定菜單',
	'setting_accbind_comment' => '填寫格式：“插件唯一標識符:cpname”，一個一行，冒號後麵表示程序模塊名，後麵不填“:spacecp”表示默認程序模塊名為spacecp。<br>此設置是指個人設置將顯示“賬號綁定”菜單，把賬號綁定相關插件的設置菜單歸類到賬號綁定菜單下。<br>例如：duceapp_wechat:spacecp、qqconnect。',
	'setting_styles' => '界麵風格',
	'style_tips' => '<li>本設置是指火狼係列插件所涉及到單獨頁麵的CSS風格，您可以配置樣式來適應當前使用的模板風格</li><li>手機端布局為固定頭部，使用火狼手機模板的無需設置，如果您需要更改布局風格，請聯係模板開發者</li>',
	'style_common' => '手機通用',
	'style_footer' => '手機底部',
	'style_pc' => '電腦端',
	'style_footer_tips' => '<li>此處可自定義設置底部內容，留空按插件默認內容，內容支持HTML代碼。</li>',
	'style_header' => '通用主題色',
	'style_header_comment' => '包括頭部背景、高亮線條、字體高亮顏色',
	'style_text' => '通用字體顏色',
	'style_font' => '鏈接字體顏色',
	'style_button' => '通用按扭顏色',
	'style_button_comment' => '發布或保存按扭的背景色',
	'style_fontweight' => '通用字體粗細',
	'style_fontweight_0' => '極細字體',
	'style_fontweight_1' => '標準粗細',
	'style_nofooter' => '是否隱藏底部信息欄',
	'style_nofooter_comment' => '任意頁全通用底部信息欄，如果隱藏將不顯示',
	'style_showalert' => '信息提示樣式',
	'style_showalert_0' => '彈框自動關閉',
	'style_showalert_1' => '彈窗式不關閉',
	'style_showalert_comment' => '默認為彈框2秒自動關閉，彈窗式不關閉類似於js中Alert，需要用戶點擊確定或關閉。',

	'security_basic' => '參數配置',
	'security_basic_tips' => '<li>配置安全選項，是對火狼插件係列中修改相關敏感參數、內容等進行二次驗證保護。</li><li>安全選項通用於所有火狼插件係列，修改任意安全選項參數，需驗證原安全碼，請務必牢記此密碼！</li>',
	'security_sensitive' => '後台管理隱藏敏感內容',
	'security_sensitive_comment' => '後台管理火狼插件係列，可隱藏插件中的敏感內容，例如密鑰碼，密碼等信息部分會以*號替代',
	'security_invaild' => '本設置相關敏感參數安全，請您先設置安全密碼！',
	'security_pwdold' => '原安全碼',
	'security_pwdold_comment' => '請輸入原安全碼。',
	'security_pwdnew' => '請輸入安全碼',
	'security_pwdnew_comment' => '安全碼由字母(不區分大小寫)、下劃線、數字組成，位數不小於6位。',
	'security_pwdconfirm' => '請再次輸入安全碼',
	'security_pwdnew_need' => '請您設置安全碼',
	'security_pwdnew_invaild' => '兩次輸入的安全碼不一致！',
	'security_pwdold_invaild' => '請輸入原安全碼或原安全碼錯誤！',
	'security_password_invaild' => '無效的安全碼！',
	'security_no_isfounder' => '設置安全碼需要論壇創始人帳號！',
	'security_sesslife' => '安全碼有效期(秒)',
	'security_sesslife_comment' => '小於等於0表示瀏覽器關閉前持續有效，默認1800秒。',
	'security_reset' => '重置安全碼',
	'security_password_reset' => '成功重置安全碼，請刪除插件根目錄下的security.reset文件！',
	
	'security_cacheexport' => '導出配置',
	'cacheexport_plugin' => '請選擇導出配置的插件',
	'cacheexport_payment' => '請選擇導出配置的支付接口',
	'cacheexport_nodata' => '未選擇插件或插件沒有配置數據',
	'security_cacheimport' => '導入配置',
	'cacheimport_data' => '請選擇文件',
	'cacheimport_select' => '請確認要導入的插件數據',
	'cacheimport_data_invalid' => '數據無效或已損壞！',
	'cacheimport_payment' => '請選擇導入配置的支付接口',
	
	'compon_tips' => '<li>擴展模塊/組件和插件版本相關聯，低版本的模塊/組件可能在高版本的插件中無法生效，請及時關注升級。</li><li>插件擴展模塊/組件下載地址<a href="https://addon.dismall.com/?@{ident}.plugin">https://addon.dismall.com/?@{ident}.plugin</a></li>',
	'duceapp_clearcache' => '火狼插件緩存清理',
	'setting_color_comment' => '輸入 16 進製顏色 #RRGGBB',
	'menudir_nolimited' => '文件夾 ./source/admincp/ 沒有可寫權限<br />或將“插件目錄下/install/menu_duceapp.php”文件複製至 ./source/admincp/menu 目錄下，如果沒有menu文件夾，可手動創建',
	'update_succeed' => '數據更新成功',
);