<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-10-07
 * Version: 3.10102
 * Date: 2021-06-30 22:19:57
 * File: lang_admincp.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$duceapp_cplang = array
(
	'setting_basic' => '基本参数',
	'setting_thumbwidth' => '缩略图宽度',
	'setting_thumbwidth_comment' => '编辑器上传的图片将会缩略到此宽度，不填或0按系统默认',
	'setting_bdapikey' => '百度地图API密钥码(浏览器端)',
	'setting_bdapikey_comment' => '百度地图API密钥码<a href="http://lbsyun.baidu.com" target="_blank">点这里免费申请</a>',
	'setting_memory' => '内存优化',
	'setting_memory_tips' => '<li>启用内存优化功能将会大幅度提升程序性能和服务器的负载能力，性能优化到系统全局中配置</li><li>下列功能模块为火狼插件相关通用数据</li>',
	'setting_memory_member' => '用户数据',
	'setting_memory_member_comment' => '推荐开启，时间设置为0，永不过期，UID为单位，表数据更新时缓存数据会同步更新',
	'setting_memory_member_orders' => '用户订单数据',
	'setting_memory_member_orders_comment' => '推荐开启，时间设置为0，永不过期，UID为单位，表数据更新时缓存数据会同步更新',
	'setting_pageqrcode' => '是否显示页面二维码',
	'setting_pageqrcode_comment' => '在页面右侧悬浮显示页面链接的二维码，用户可通过移动设备扫描访问',
	'setting_pageqrcode1' => '顶部对齐',
	'setting_pageqrcode2' => '底部对齐',
	'setting_pageqrtext' => '二维码下方的提示文字',
	'setting_pageqrtext_comment' => '不填写按插件默认文字显示',
	'setting_pageqrpos' => '二维码距离窗口的值',
	'setting_pageqrpos_comment' => '二维码距离窗口顶部或底部边缘的值，0或不填按默认220',
	'setting_accbind' => '账号绑定菜单',
	'setting_accbind_comment' => '填写格式：“插件唯一标识符:cpname”，一个一行，冒号后面表示程序模块名，后面不填“:spacecp”表示默认程序模块名为spacecp。<br>此设置是指个人设置将显示“账号绑定”菜单，把账号绑定相关插件的设置菜单归类到账号绑定菜单下。<br>例如：duceapp_wechat:spacecp、qqconnect。',
	'setting_styles' => '界面风格',
	'style_tips' => '<li>本设置是指火狼系列插件所涉及到单独页面的CSS风格，您可以配置样式来适应当前使用的模板风格</li><li>手机端布局为固定头部，使用火狼手机模板的无需设置，如果您需要更改布局风格，请联系模板开发者</li>',
	'style_common' => '手机通用',
	'style_footer' => '手机底部',
	'style_pc' => '电脑端',
	'style_footer_tips' => '<li>此处可自定义设置底部内容，留空按插件默认内容，内容支持HTML代码。</li>',
	'style_header' => '通用主题色',
	'style_header_comment' => '包括头部背景、高亮线条、字体高亮颜色',
	'style_text' => '通用字体颜色',
	'style_font' => '链接字体颜色',
	'style_button' => '通用按扭颜色',
	'style_button_comment' => '发布或保存按扭的背景色',
	'style_fontweight' => '通用字体粗细',
	'style_fontweight_0' => '极细字体',
	'style_fontweight_1' => '标准粗细',
	'style_nofooter' => '是否隐藏底部信息栏',
	'style_nofooter_comment' => '任意页全通用底部信息栏，如果隐藏将不显示',
	'style_showalert' => '信息提示样式',
	'style_showalert_0' => '弹框自动关闭',
	'style_showalert_1' => '弹窗式不关闭',
	'style_showalert_comment' => '默认为弹框2秒自动关闭，弹窗式不关闭类似于js中Alert，需要用户点击确定或关闭。',

	'security_basic' => '参数配置',
	'security_basic_tips' => '<li>配置安全选项，是对火狼插件系列中修改相关敏感参数、内容等进行二次验证保护。</li><li>安全选项通用于所有火狼插件系列，修改任意安全选项参数，需验证原安全码，请务必牢记此密码！</li>',
	'security_sensitive' => '后台管理隐藏敏感内容',
	'security_sensitive_comment' => '后台管理火狼插件系列，可隐藏插件中的敏感内容，例如密钥码，密码等信息部分会以*号替代',
	'security_invaild' => '本设置相关敏感参数安全，请您先设置安全密码！',
	'security_pwdold' => '原安全码',
	'security_pwdold_comment' => '请输入原安全码。',
	'security_pwdnew' => '请输入安全码',
	'security_pwdnew_comment' => '安全码由字母(不区分大小写)、下划线、数字组成，位数不小于6位。',
	'security_pwdconfirm' => '请再次输入安全码',
	'security_pwdnew_need' => '请您设置安全码',
	'security_pwdnew_invaild' => '两次输入的安全码不一致！',
	'security_pwdold_invaild' => '请输入原安全码或原安全码错误！',
	'security_password_invaild' => '无效的安全码！',
	'security_no_isfounder' => '设置安全码需要论坛创始人帐号！',
	'security_sesslife' => '安全码有效期(秒)',
	'security_sesslife_comment' => '小于等于0表示浏览器关闭前持续有效，默认1800秒。',
	'security_reset' => '重置安全码',
	'security_password_reset' => '成功重置安全码，请删除插件根目录下的security.reset文件！',
	
	'security_cacheexport' => '导出配置',
	'cacheexport_plugin' => '请选择导出配置的插件',
	'cacheexport_payment' => '请选择导出配置的支付接口',
	'cacheexport_nodata' => '未选择插件或插件没有配置数据',
	'security_cacheimport' => '导入配置',
	'cacheimport_data' => '请选择文件',
	'cacheimport_select' => '请确认要导入的插件数据',
	'cacheimport_data_invalid' => '数据无效或已损坏！',
	'cacheimport_payment' => '请选择导入配置的支付接口',
	
	'compon_tips' => '<li>扩展模块/组件和插件版本相关联，低版本的模块/组件可能在高版本的插件中无法生效，请及时关注升级。</li><li>插件扩展模块/组件下载地址<a href="https://addon.dismall.com/?@{ident}.plugin">https://addon.dismall.com/?@{ident}.plugin</a></li>',
	'duceapp_clearcache' => '火狼插件缓存清理',
	'setting_color_comment' => '输入 16 进制颜色 #RRGGBB',
	'menudir_nolimited' => '文件夹 ./source/admincp/ 没有可写权限<br />或将“插件目录下/install/menu_duceapp.php”文件复制至 ./source/admincp/menu 目录下，如果没有menu文件夹，可手动创建',
	'update_succeed' => '数据更新成功',
);