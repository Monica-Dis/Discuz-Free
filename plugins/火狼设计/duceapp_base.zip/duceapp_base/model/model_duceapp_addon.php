<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2020-09-15
 * Version: 3.10621
 * Date: 2021-06-30 22:19:57
 * File: model_duceapp_addon.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

class model_duceapp_addon
{
	public function control() {
		global $plugin;
		define('DUCEAPP_F_CHARSET', 'UTF-8');
		define('DUCEAPP_API_URL', 'https://www.duceapp.com/addon?');
		define('DUCEAPP_OP_URL', ADMINSCRIPT.'?action=plugins&operation=');
		define('DUCEAPP_ADDON_URL', DUCEAPP_OP_URL.'config&do='.$plugin['pluginid'].'&duceapp=addon');
		if (!empty($_GET['inajax'])) {
			ob_end_clean();
		}
		$method = !empty($_GET['m']) || !empty($_GET['inajax']) ? $_GET['m'] : 'main';
		if ($method == 'enable' || $method == 'disable') {
			$method = 'toggle';
		}
		if ($method && method_exists($this, $method)) {
			call_user_func(array($this, $method));
			$this->output();
		}
		duceapp_exit();
	}

	public function main() {
		global $_G, $lang, $isplugindeveloper, $admincp;
		duceapp_headscript();
		$usrid = substr(md5(cloudaddons_getuniqueid()), 16);
		echo '<script type="text/javascript">
		var DUCEAPP_ADDON_URL=\''.DUCEAPP_ADDON_URL.'\',
			DUCEAPP_OP_URL=\''.DUCEAPP_OP_URL.'\',
			DUCEAPP_API_URL=\''.DUCEAPP_API_URL.'\',
			FORMHASH=\''.FORMHASH.'\';
		</script>';
		echo '<link href="source/plugin/duceapp_base/static/css/admin_addon.css?'.TIMESTAMP.'" rel="stylesheet" type="text/css">';
		echo <<<EOF
		<script type="text/javascript">
		var _xmlhttpRequest = false;
		var _downloadRequest = true;
		var _upgradeId = 0;
		var _triggertime = Date.now || function() {return + new Date};
		try {parent.switchheader('火狼')} catch(e) {}
		parent.document.title = '火狼 - 应用列表 (www.duceapp.com)';
		parent.$('admincpnav').innerHTML = '火狼 - 应用列表&nbsp;&nbsp;<a target="main" title="添加到常用操作" href="' + admincpfilename + '?action=misc&operation=custommenu&do=add&title=' + encodeURIComponent('火狼应用列表') + '&url=' + encodeURIComponent(DUCEAPP_ADDON_URL.replace(admincpfilename, '')) + '">[+]</a>';
		function duceapp_operation(o) {
			_xmlhttpRequest = true;
			var mask = document.createElement('div');
			mask.className = 'operatemask';
			mask.innerHTML = '<div class="dloading"><div class="rotor"></div></div>';
			o.parentNode.parentNode.appendChild(mask);
			var x = new Ajax();
			x.get(DUCEAPP_ADDON_URL + '&m=' + o.operate + '&actionid=' + o.pluginid + '&formhash=' + FORMHASH + '&inajax=1', function(s, x) {
				_xmlhttpRequest = false;
				mask.parentNode.removeChild(mask);
				if (s.indexOf('succeed') == 0) {
					$(o.operate == 'enable' ? 'duceapp_open': 'duceapp_close').appendChild($('ditem_' + o.pluginid))
				} else {
					var msg = s ? s.replace(/<script[^\>]*?>([^\x00]*?)<\/script>/ig, '').replace(/(^\s+|\s+$)/ig, '') : '';
					if (msg) {
						duceapp_showPrompt(msg);
						o.reqErr = 1;
						o.className = o.operate == 'enable' ? 'collapsed_no': 'collapsed_yes';
						o.style.left = o.operate == 'enable' ? '-17px': 0
					}
				}
				evalscript(s)
			})
		}
		function duceapp_addonUpgrade(actionid, extra, m) {
			if (_xmlhttpRequest) return;
			_xmlhttpRequest = true;
			var mask = document.createElement('div');
			mask.className = 'operatemask';
			mask.innerHTML = '<div class="dloading"><div class="rotor"></div></div>';
			if (actionid) {
				_upgradeId = actionid;
			}
			var itembox = $('ditem_' + _upgradeId);
			if (itembox) {
				itembox.appendChild(mask);
			}
			var x = new Ajax();
			x.get(DUCEAPP_ADDON_URL + '&m=' + (m || 'upgrade') + '&actionid=' + actionid + '&inajax=1&formhash=' + FORMHASH + (extra ? '&' + extra: ''), function(s, x) {
				if (actionid) _upgradeId = actionid;
				_xmlhttpRequest = false;
				mask.parentNode && mask.parentNode.removeChild(mask);
				var msg = s ? s.replace(/<script[^\>]*?>([^\x00]*?)<\/script>/ig, '').replace(/(^\s+|\s+$)/ig, '') : '';
				if (msg) duceapp_showPrompt(msg);
				evalscript(s)
			})
		}
		function duceapp_addonDownload(query, t, v) {
			_downloadRequest = true;
			if (typeof v == 'object') {
				if (v['addonid']) {
					duceapp_showPrompt('应用 ' + v['addonid'] + ' 下载中，请稍候 ......<br /><img src="static/image/admincp/ajax_loader.gif" style="margin:10px"><br /><strong id="download_percent">0%</strong>', {w: 500, btnhide: 1, h3: '安装提示' }, null, function() { _downloadRequest = false })
				} else if (v["install"]) {
					parent.document.getElementById('duceapp_prompt_main').innerHTML = '<div style="font-size:14px;font-weight:normal;">应用 ' + v['install'] + ' 正在复制文件，请稍候......<br /><img src="static/image/admincp/ajax_loader.gif" style="margin:10px 0 20px"></div>'
				} else if (typeof v['percent'] != 'undefined') {
					parent.document.getElementById('download_percent').innerHTML = v['percent']
				}
			}
			setTimeout(function() {
				if (!_downloadRequest) return;
				var x = new Ajax();
				x.get(DUCEAPP_ADDON_URL + '&m=download&' + query + '&formhash=' + FORMHASH, function(s, x) {
					var msg = s ? s.replace(/<script[^\>]*?>([^\x00]*?)<\/script>/ig, '').replace(/(^\s+|\s+$)/ig, '') : '';
					if (msg) {
						_downloadRequest = false;
						duceapp_showPrompt(msg)
					}
					evalscript(s)
				})
			}, t || 2000)
		}
		function duceapp_addonDelete(actionid, t) {
			var id = 'f_' + _triggertime();
			var s = t ? '模版' : '插件';
			var f = t ? '<form id="' + id + '" action="' + admincpfilename + '?action=styles" method="post"><input type="hidden" name="formhash" value="' + FORMHASH + '"><input type="hidden" name="delete[]" value="' + actionid + '"><input type="hidden" name="stylesubmit" value="yes"></form>' : '';
			duceapp_showPrompt('很遗憾您选择了卸载本'+s+'！<br />如遇到'+s+'使用问题，您可偿试<a class="nml" href="http://wpa.qq.com/msgrd?v=3&uin=24448714&site=火狼应用&menu=yes" target="_blank">联系插件作者</a>进行沟通<br />或前往'+s+'<a class="nml" href="https://www.duceapp.com" target="_blank">官方网站</a>发帖反馈' + f, {w: 500, confirm: '确认卸载'}, function() {
				if (t) {
					parent.document.getElementById(id).submit();
				} else {
					window.location.href = DUCEAPP_OP_URL + 'delete&pluginid=' + actionid;
				}
			})
		}
		function duceapp_showPrompt(msg, v, confirm_func, cancel_func) {
			duceapp_prompt('<div style="font-size:14px;font-weight:normal;">' + msg + '&lt;/div&gt;', v, confirm_func, cancel_func)
		}
		function duceapp_oleftmenu(op, pluginid, name) {
			var menubox = parent.document.getElementById('menu_火狼');
			if (!menubox) return;
			var _items_ = menubox.getElementsByTagName('a');
			var li = null;
			for (var i = 0; i < _items_.length; i++) {
				var href = _items_[i].href.replace(/\&amp;/ig, '&');
				if (href.indexOf('action=plugins&operation=config&do=' + pluginid) != -1) {
					if (op == "remove") {
						menubox.removeChild(_items_[i].parentNode)
					} else {
						li = _items_[i].parentNode;
						break
					}
				}
			}
			if (op == 'add' && !li) {
				var li = parent.document.createElement('li');
				li.innerHTML = '<a href="' + DUCEAPP_OP_URL + 'config&do=' + pluginid + '" hidefocus="true" target="main"><em onclick="menuNewwin(this)" title="新窗口打开"></em>' + name + '</a>';
				menubox.appendChild(li)
			}
		}
		function duceapp_toggleCollapse(o, pluginid) {
			if (o.className == "collapseing" || _xmlhttpRequest) return;
			o.operate = o.className == 'collapsed_no' ? 'enable': 'disable';
			o.className = "collapseing";
			o.style.left = o.operate == 'enable' ? 0 : '-17px';
			if (o.pluginid) return;
			o.pluginid = pluginid;
			var _trigger = function() {
				if (o.reqErr) return o.reqErr = 0;
				if (this.operate == 'enable') {
					this.className = 'collapsed_yes'
				} else {
					this.className = 'collapsed_no'
				}
				duceapp_operation(this)
			};
			_attachEvent(o, 'transitionend', _trigger);
			_attachEvent(o, 'webkitTransitionEnd', _trigger)
		}
		function duceapp_scrollxinit(o){
			if(o.getAttribute('init')) return;
			o.setAttribute('init', 'yes');			
			_attachEvent(o, 'mousedown', function(e){
				e = doane(e);
				window._scrollobj_ = this;
				this.status = this.scrollWidth == this.offsetWidth ? 0 : 1;
				if (!this.status) return;
				this.posx = this.scrollLeft;
				this.startx = e.pageX != undefined ? e.pageX : e.clientX;
				this.target = e.srcElement? e.srcElement: e.target;
				if (this.target.tagName.toLowerCase() == 'a') {
					this.target.setAttribute('onclick', 'return false');
				}
			});
			if (!window._scrollmenu_) {
				window._scrollmenu_ = true;
				window._scrollobj_ = null;
				_attachEvent(document, 'mousemove', function(e){
					if (!_scrollobj_ || !_scrollobj_.status) return;
					e = doane(e);
					_scrollobj_.status = 2;
					_scrollobj_.scrollLeft = _scrollobj_.posx + _scrollobj_.startx - (e.pageX != undefined ? e.pageX : e.clientX);
				});
				_attachEvent(document, 'mouseup', function(e){
					e = doane(e);
					if (_scrollobj_) {
						_scrollobj_.target && _scrollobj_.status == 1 && _scrollobj_.target.setAttribute('onclick', '');
						_scrollobj_.status = 0;
					}
				});
			}
		}
		function duceapp_cmdmarkid(){
			$('duceapp_markframe').src = DUCEAPP_API_URL + 'a=mark&usrid=$usrid';
		}
		</script>
EOF;
		$type = $_GET['type'] == 'template' ? 'template' : 'plugin';
		$curr[$type] = 'current';
		echo '<iframe id="duceapp_markframe" src="about:blank" style="display:none"></iframe><div class="floattop" style="z-index:201;"><div class="itemtitle duceapp_tabitem"><h3>火狼</h3><ul class="tab1"><li class="'.$curr['plugin'].'" onclick="window.location.href=\''.DUCEAPP_ADDON_URL.'\'"><a href="javascript:;"><span>插件列表</span></a></li><li class="'.$curr['template'].'" onclick="window.location.href=\''.DUCEAPP_ADDON_URL.'&type=template\'"><a href="javascript:;"><span>模板列表</span></a></li><li><a href="https://addon.dismall.com/?@duceapp"><span><font color="#237ffd">应用中心</font></span></a></li><li onclick="window.location.href=\''.DUCEAPP_ADDON_URL.'&upcheck=1&type='.$type.'\'"><a href="javascript:;"><span>检查更新</span></a></li><li style="margin-left:8px;"><a class="duceappsite" href="https://www.duceapp.com/addon?u='.$usrid.'" _onclick="duceapp_cmdmarkid()" target="_blank"></a></li></ul></div></div>';
		
		if ($type == 'plugin') {
			loadcache('plugin');
			$alldata = C::t('common_plugin')->fetch_all_data();
		} else {
			$alldata = C::t('common_style')->fetch_all_data(true);
		}		
		
		loadcache('duceappcheck_'.$type);
		$checkresult = $_G['cache']['duceappcheck_'.$type];

		if (($_GET['upcheck'] && $this->__allowpost()) || TIMESTAMP - $checkresult['expire'] > 43200) {
			foreach($alldata as $row) {
				if ($type == 'template') {
					preg_match('/^.?\/template\/([a-z]+[a-z0-9_]*)$/', $row['directory'], $a);
					$identifier = $a[1];
					$keyid = $row['styleid'];
				} else {
					$identifier = $row['identifier'];
					$keyid = $row['pluginid'];
				}
				if (strpos($identifier, 'duceapp_') !== FALSE){
					$addonids[$keyid] = $identifier.'.'.$type;
				}
			}
			$checkresult = $this->cloudcheck($addonids);
			$checkresult['expire'] = TIMESTAMP;
			savecache('duceappcheck_'.$type, $checkresult);
		}

		if ($type == 'plugin') {
			$this->chkpluginxmlsave = false;
			$list = array();
			foreach($alldata as $row) {
				if ((!isfounder() && !isset($admincp->perms['all']) && !$admincp->perms['plugins_config_'.$row['pluginid']]) || 
					substr($row['identifier'], 0, 8) != 'duceapp_') {
					continue;
				}
				$addonid = $row['identifier'].'.plugin';
				$updateinfo = $aclass = '';
				list(, $newver, $sysver, $duceappver) = explode(':', $checkresult[$addonid]);
				if (($sysver && $sysver > $row['version']) || $newver || $duceappver) {
					if ($duceappver) {
						$upver = $this->__($duceappver);
						$url = 'javascript:;';
						$onclick = ' onclick="duceapp_addonUpgrade(\''.$row['pluginid'].'\', null, \'download\');"';
						$aclass = 'dnew';
					} else {
						$upver = $sysver && $sysver > $row['version'] ? $sysver : $this->__($newver);
						$url = ADMINSCRIPT.'?action=cloudaddons&id='.$row['identifier'].'.plugin';
						$onclick = '';
						$aclass = 'gnew';
					}
					$updateinfo = '<a class="'.$aclass.'" href="'.$url.'"'.$onclick.' title="点击在线安装新版'."\n".(strpos($upver, '&#12289;') !== false ? str_replace(' &#12289; ', "\n", $upver) : $upver).'">发现新版</a>';
				}
				if (!$updateinfo) {
					$updateinfo = $this->upgradecheck($row);
				}
				$row['modules'] = dunserialize($row['modules']);
				$submenuitem = array();
				if (isset($_G['cache']['plugin'][$row['identifier']])) {
					$submenuitem[] = '<a href="'.DUCEAPP_OP_URL.'config&do='.$row['pluginid'].'">设置</a>';
				}
				if(is_array($row['modules'])) {
					foreach($row['modules'] as $k => $module) {
						if($module['type'] == 11) {
							$hookorder = $module['displayorder'];
							$hookexists = $k;
						}
						if($module['type'] == 3) {
							$submenuitem[] = '<a href="'.DUCEAPP_OP_URL.'config&do='.$row['pluginid'].'&pmod='.$module['name'].($module['param'] ? '&'.$module['param'] : '').'">'.$this->__($module['menu']).'</a>';
						}
						if($module['type'] == 29) {
							$submenuitem[] = '<a href="'.$module['url'].'" target="_blank">'.$this->__($module['menu']).'</a>';
						}
					}
				}
				$duceapp_cplang = array();
				@include duceapp_language('admincp', DISCUZ_ROOT.'source/plugin/'.$row['identifier'].'/language/');
				if ($duceapp_cplang['extapi']) {
					$submenuitem[] = '<a href="'.DUCEAPP_OP_URL.'config&do='.$row['pluginid'].'&pmod=compon&api='.$duceapp_cplang['extapi'].'">'.$this->__($duceapp_cplang['module_'.$duceapp_cplang['extapi']]).'</a>';
				}
				$s = '<div id="ditem_'.$row['pluginid'].'" class="duceapp_plugin'.($updateinfo ? ' duceapp_itemnew' : '').' cl">
					<span class="duceapp_slider_s"><img src="./static/image/common/none.gif" onclick="duceapp_toggleCollapse(this, '.$row['pluginid'].');" class="'.($row['available'] ? 'collapsed_yes' : 'collapsed_no').'" /></span>
					<div class="zoom"><img src="'.cloudaddons_pluginlogo_url($row['identifier']).'" onerror="this.src=\'static/image/admincp/plugin_logo.png\';this.onerror=null" align="left" /></div>
					<div><span class="bold" id="ditem_'.$row['pluginid'].'_name">'.$this->__n($row['name']).' '.$row['version'].$updateinfo.'</span></div>
					<div style="margin-top:9px;">'.
						'<a href="javascript:;" onclick="duceapp_addonUpgrade('.$row['pluginid'].')">更新</a>&nbsp;&nbsp;'.(!$row['modules']['system'] ? '<a href="javascript:;" onclick="duceapp_addonDelete('.$row['pluginid'].')">卸载</a>&nbsp;&nbsp;' : '').($isplugindeveloper && !$row['modules']['system'] ? '<a href="'.DUCEAPP_OP_URL.'edit&pluginid='.$row['pluginid'].'">设计</a>&nbsp;&nbsp;' : '').'
					</div>
					<div class="mnlist" id="ditem_menu_'.$row['pluginid'].'" onmouseover="duceapp_scrollxinit(this)">'.implode(' <span>/</span> ', $submenuitem).'</div>
				</div>';
				if ($row['identifier'] == 'duceapp_base') {
					$list[$row['available'] ? 'open' : 'close'] = $s.$list[$row['available'] ? 'open' : 'close'];
				} else {
					$list[$row['available'] ? 'open' : 'close'] .= $s;
				}
			}
			echo '<div class="duceapp_wrap cl" id="duceapp_open">'.$list['open'].'</div>';
			echo '<div class="duceapp_wrap cl" id="duceapp_close">'.$list['close'].'</div>';			
			if ($this->chkpluginxmlsave && isset($_G['cache']['duceappcheck_pluginxml'])) {
				savecache('duceappcheck_pluginxml', $_G['cache']['duceappcheck_pluginxml']);
			}
		} elseif ($type == 'template') {
			$s = '';
			foreach($alldata as $row) {
				preg_match('/^.?\/template\/([a-z]+[a-z0-9_]*)$/', $row['directory'], $a);
				$addonid = $a[1].'.template';
				if (substr($addonid, 0, 8) != 'duceapp_') {
					continue;
				}
				$updateinfo = $aclass = '';
				list(, $newver, , $duceappver) = explode(':', $checkresult[$addonid]);
				if ($duceappver || $newver) {
					if ($duceappver) {
						$upver = $this->__($duceappver);
						$url = 'javascript:;';
						$onclick = ' onclick="duceapp_addonUpgrade(\''.$row['styleid'].'\', \'tpl=1\', \'download\');"';
						$aclass = 'dnew';
					} else {
						$upver = $this->__($newver);
						$url = ADMINSCRIPT.'?action=cloudaddons&id='.$addonid;
						$onclick = '';
						$aclass = 'gnew';
					}
					$updateinfo = '<a class="'.$aclass.'" href="'.$url.'"'.$onclick.' title="点击在线安装新版'."\n".(strpos($upver, '&#12289;') !== false ? str_replace(' &#12289; ', "\n", $upver) : $upver).'">发现新版</a>';
				}
				$s .= '<div id="ditem_'.$row['styleid'].'" class="duceapp_tpl'.($updateinfo ? ' duceapp_itemnew' : '').' cl">
					<div class="zoom"><img src="'.$row['directory'].'/preview.jpg" onerror="this.src=\'./static/image/admincp/stylepreview.gif\';this.onerror=null" align="left" /></div>
					<div><span class="bold" id="ditem_'.$row['styleid'].'_name">'.$this->__n($row['name']).' '.$updateinfo.'</span></div>
					<div style="margin-top:9px;">'.
						'<a href="javascript:;" onclick="duceapp_addonUpgrade('.$row['styleid'].', \'tpl=1\')">更新</a>&nbsp;&nbsp;'.(!$row['modules']['system'] ? '<a href="javascript:;" onclick="duceapp_addonDelete('.$row['styleid'].', 1)">卸载</a>&nbsp;&nbsp;' : '').($isplugindeveloper ? '<a href="'.ADMINSCRIPT.'?action=styles&operation=edit&id='.$row['styleid'].'">编辑</a>&nbsp;&nbsp;' : '').'
					</div>
					<div style="margin-top:9px;color:#999;font-size:13px;">'.str_replace('./', '/', $row['directory']).'</div>
				</div>';
			}
			echo '<div class="duceapp_wrap cl">'.$s.'</div>';
		}
		
		if ($_GET['md5hash']) {
			$_GET['inajax'] = $_GET['step'] = 0;
			$this->download();
		}
	}	

	public function download() {
		global $_G;
		if ($_GET['actionid']) {
			$data = $_GET['tpl'] ? C::t('common_style')->fetch_by_styleid($_GET['actionid']) : C::t('common_plugin')->fetch($_GET['actionid']);
			if ($_GET['tpl']) {
				preg_match('/^.?\/template\/([a-z]+[a-z0-9_]*)$/', $data['directory'], $a);
				$key = $a[1].'.template';
			} else {
				$key = $data['identifier'].'.plugin';
			}
			$url = $this->__apiurl().'&a=down&r='.$key.'&inajax=1';
			$_GET = dunserialize($this->response($url));
			$_GET['inajax'] = 1;
		}
		if (!$this->__allowpost()) {
			$msg = '抱歉，您无权使用此功能';
			echo $_GET['inajax'] ? $msg : '<script reload="1">duceapp_showPrompt("'.$msg.'")</script>';
			return;
		}
		if ($_GET['errmsg'] || !$_GET['md5hash'] || md5($_GET['addonids'].md5(substr(md5(cloudaddons_getuniqueid()), 16).$_GET['timestamp'])) != $_GET['md5hash']) {
			$msg = $_GET['errmsg'] ? $_GET['errmsg'] : '校验失败，您无法下载此应用';
			if ($_GET['redirect']) {
				$msg .= '<br /><a class="nml" onclick="hideMenu();document.getElementById(\'duceapp_mask\').style.display=\'none\';" href="'.$_GET['redirect'].'" target="main">查看应用详情</a>';
			}
			echo $_GET['inajax'] ? $msg : '<script reload="1">duceapp_showPrompt("'.$msg.'")</script>';
			return;
		}
		$step = intval($_GET['step']);
		$addonids = explode(',', $_GET['addonids']);
		$addoni = intval($_GET['i']);
		list($_GET['key'], $_GET['type'], $_GET['rid']) = explode('.', isset($addonids[$addoni]) ? $addonids[$addoni] : $addonids[0]);
		$stepUrl = "addonids=$_GET[addonids]&md5hash=$_GET[md5hash]&timestamp=$_GET[timestamp]&inajax=1&i=";
		$tmpdir = DISCUZ_ROOT.'./data/duceapp/download/'.$_GET['rid'];
		$_addonid = $_GET['key'].'.'.$_GET['type'];

		if (!$step) {
			echo '<script reload="1">duceapp_addonDownload("'.$stepUrl.$addoni.'&step=1", 1000, {addonid:"<b>'.$_addonid.'</b>"});</script>';
		} elseif($step == 1) {
			$packnum = isset($_GET['num']) ? intval($_GET['num']) : 0;
			$data = $this->response($this->__apiurl().'&a=down&rid='.$_GET['rid'].'&packnum='.$packnum, '', 999);
			$errnum = isset($_GET['err']) ? intval($_GET['err']) : 0;
			$end = '';
			$md5tmp = DISCUZ_ROOT.'./data/duceapp/download/'.$_GET['rid'].'.md5';
			if($packnum) {
				list($md5total, $md5s) = unserialize(implode('', @file($md5tmp)));
				dmkdir($tmpdir, 0777, false);
			} else {
				$this->__cleardir($tmpdir);
				@unlink($md5tmp);
				dmkdir($tmpdir, 0777, false);
				$md5total = '';
				$md5s = array();
			}
			if (!empty($data)) {
				$_GET['importtxt'] = $data;
				$array = getimportdata('Discuz! File Pack', 0, 1);
			}
			if (empty($data) || empty($array)) {
				if ($errnum > 2) {
					$this->__cleardir($tmpdir);
					@unlink($md5tmp);
					echo '数据下载错误！';
				} else {
					$errnum++;
					echo '<script reload="1">duceapp_addonDownload("'.$stepUrl.$addoni.'&step=1&num='.$packnum.'&err='.$errnum.'", 3000);</script>';
				}
				return;
			}
			if (!$array['Status']) {
				list($_cur, $_max) = explode('/', $array['part']);
				$percent = intval($_cur/$_max * 100);
				if ($array['type'] != $_GET['type'] || $array['key'] != $_GET['key'] || !$array['files']) {
					$this->__cleardir($tmpdir);
					echo '数据下载错误';
					return;
				}
				foreach($array['files'] as $file => $data) {
					$filename = $tmpdir.'/'.$file.'._addons_';
					$dirname = dirname($filename);
					dmkdir($dirname, 0777, false);
					$fp = fopen($filename, !$data['Part'] ? 'w' : 'a');
					if (!$fp) {
						$this->__cleardir($tmpdir);
						@unlink($md5tmp);
						echo '文件无法下载，请确认“data/duceapp/download/”目录是否可写';
						return;
					}
					fwrite($fp, gzuncompress(base64_decode($data['Data'])));
					fclose($fp);
					if($data['MD5']) {
						$md5total .= $data['MD5'];
						$md5s[$filename] = $data['MD5'];
					}
				}
				$fp = fopen($md5tmp, 'w');
				fwrite($fp, serialize(array($md5total, $md5s)));
				fclose($fp);
			} elseif($array['Status'] == 'Error') {
				$this->__cleardir($tmpdir);
				@unlink($md5tmp);
				echo '您不能安装此应用('.$array['ErrorCode'].')';
				return;
			} else {
				foreach($md5s as $file => $md5) {
					if ($md5 != md5_file($file)) {
						$this->__cleardir($tmpdir);
						@unlink($md5tmp);
						echo '数据校验失败，无法安装此应用';
						return;
					}
				}
				@unlink($md5tmp);
				$end = rawurlencode(cloudaddons_http_build_query($array));
			}
			if (!$end) {
				$packnum++;
				echo '<script reload="1">duceapp_addonDownload("'.$stepUrl.$addoni.'&step=1&num='.$packnum.'", 1000, {percent:"'.$percent.'%"});</script>';
			} else {
				if ($md5total !== '' && md5($md5total) !== $this->response($this->__apiurl().'&a=chkmd5&rid='.$_GET['rid'])) {
					$this->__cleardir($tmpdir);
					@unlink($md5tmp);
					echo '数据校验失败，无法安装此应用';
					return;
				}
				echo '<script reload="1">duceapp_addonDownload("'.$stepUrl.$addoni.'&step=2&end='.$end.'", 1500, {install:"<b>'.$_addonid.'</b>"});</script>';
			}
		} elseif($step == 2) {
			if (!file_exists($tmpdir)) {
				$this->__cleardir($tmpdir);
				echo '数据下载错误';
				return;
			}
			$typedir = array(
				'plugin' => 'source/plugin',
				'template' => 'template',
				'pack' => '.',
			);
			if (!$typedir[$_GET['type']]) {
				$this->__cleardir($tmpdir);
				echo '数据下载错误';
				return;
			}
			if ($_GET['type'] != 'pack') {
				$descdir = DISCUZ_ROOT.$typedir[$_GET['type']].'/';
				$subdir = $_GET['key'];
			} else {
				$descdir = DISCUZ_ROOT;
				$subdir = '';
			}
			$descdir .= $subdir;
			$isDever = in_array(basename(DISCUZ_ROOT), array('dev', 'app', 'master'));
			if (!$isDever) {
				cloudaddons_comparetree($tmpdir, $descdir, $tmpdir, $_addonid, 1);
				cloudaddons_copytree($tmpdir, $descdir);
				cloudaddons_savemd5($_addonid, $_GET['end'], $_G['treeop']['md5']);
			}
			cloudaddons_deltree($tmpdir);
			duceapp_addonbatch();
			if (count($addonids) - 1 > $addoni) {
				$addoni++;
				echo '<script reload="1">duceapp_addonDownload("'.$stepUrl.$addoni.'&step=1", 1000, {addonid:"<b>'.$_addonid.'</b>"});</script>';
				return;
			}
			list($_GET['key'], $_GET['type'], $_GET['rid']) = explode('.', $addonids[0]);
			if ($_GET['type'] == 'plugin') {
				$plugin = C::t('common_plugin')->fetch_by_identifier($_GET['key']);
				if (!$plugin['pluginid']) {
					echo '<script reload="1">try{parent.document.getElementById("duceapp_mask").style.display="none";}catch(e){}parent.hideMenu();
					window.location.href="'.ADMINSCRIPT.'?action=plugins&operation=import&dir='.$_GET['key'].'";
					</script>';
				} else {
					$modules = dunserialize($plugin['modules']);
					$dir = substr($plugin['directory'], 0, -1);
					$extra = file_exists(DISCUZ_ROOT.'./source/plugin/'.$dir.'/discuz_plugin_'.$dir.($modules['extra']['installtype'] ? '_'.$modules['extra']['installtype'] : '').'.xml') ? 'confirmed=1' : 'fromdl=yes';
					echo '<script reload="1">parent.document.getElementById(\'duceapp_prompt_main\').innerHTML = \'<div style="font-size:14px;font-weight:normal;">应用 <b>'.$dir.'.'.$_GET['type'].'</b> 安装更新中，请勿关闭......<br /><img src="static/image/admincp/ajax_loader.gif" style="margin:10px 0 20px"></div>\';duceapp_addonUpgrade("'.$plugin['pluginid'].'", "'.$extra.'");</script>';
				}
			} elseif($_GET['type'] == 'template') {
				savecache('duceappcheck_template', array());
				$siteoutchar = '_'.($_G['config']['output']['language'] == 'zh_tw' ? 'TC_' : 'SC_').str_replace('-', '', strtoupper(CHARSET));
				foreach(array('', '_SC_GBK', '_SC_UTF8', '_TC_UTF8', '_TC_BIG5') as $char) {
					if ($char != $siteoutchar) {
						@unlink($descdir.'/discuz_style_'.$_GET['key'].$char.'.xml');
					}
				}
				echo '<script reload="1">parent.document.getElementById(\'duceapp_prompt_main\').innerHTML = \'<div style="font-size:14px;font-weight:normal;">应用 <b>'.$_GET['key'].'.'.$_GET['type'].'</b> 安装更新中，请勿关闭......<br /><img src="static/image/admincp/ajax_loader.gif" style="margin:10px 0 20px"></div>\';duceapp_addonUpgrade(0, "tpl=1&sdir='.$_GET['key'].'");</script>';
			} else {
				if(file_exists(DISCUZ_ROOT.'./data/addonpack/'.$_GET['key'].'.php')) {
					echo '<script reload="1">try{parent.document.getElementById("duceapp_mask").style.display="none";}catch(e){}parent.hideMenu();
					window.location.href="'.$_G['siteurl'].'data/addonpack/'.$_GET['key'].'.php";</script>';
				}
			}
		}
	}	

	public function toggle() {
		global $_G, $lang, $admincp, $importtxt;
		$op = $_GET['m'];
		if (FORMHASH != $_GET['formhash']) {
			$result = '请求不合法';
		} elseif (!$this->__allowpost()) {
			$result = '抱歉，您无权使用此功能';
		} elseif (!($plugin = C::t('common_plugin')->fetch($_GET['actionid']))) {
			$result = '插件未找到';
		} else {
			$dir = substr($plugin['directory'], 0, -1);
			$plugin['modules'] = dunserialize($plugin['modules']);
			$file = DISCUZ_ROOT.'./source/plugin/'.$dir.'/discuz_plugin_'.$dir.($plugin['modules']['extra']['installtype'] ? '_'.$plugin['modules']['extra']['installtype'] : '').'.xml';
			if(!file_exists($file)) {
				$pluginarray[$op.'file'] = $plugin['modules']['extra'][$op.'file'];
				$pluginarray['plugin']['version'] = $plugin['version'];
			} else {				
				$importtxt = @implode('', file($file));
				$pluginarray = getimportdata('Discuz! Plugin', 0, 1);
			}
			if(!empty($pluginarray[$op.'file']) && preg_match('/^[\w\.]+$/', $pluginarray[$op.'file'])) {
				$filename = DISCUZ_ROOT.'./source/plugin/'.$dir.'/'.$pluginarray[$op.'file'];
				if (file_exists($filename) && $op == 'enable') {					
					$installfile = DISCUZ_ROOT.'./source/plugin/'.$dir.'/'.($pluginarray['installfile'] ? $pluginarray['installfile'] : 'install.php');
					$lockfile = DISCUZ_ROOT.'./data/duceapp/'.$plugin['identifier'].'.lock';
					if (!$plugin['available'] && !file_exists($lockfile) && file_exists($installfile)) {
						$this->ajaxout('<script reload="1">window.location.href="'.DUCEAPP_OP_URL.'enable&pluginid='.$plugin['pluginid'].'&formhash='.FORMHASH.'";</script>');
					}
				}
			}
			$available = $op == 'enable' ? 1 : 0;
			C::t('common_plugin')->update($_GET['actionid'], array('available' => $available));
			updatecache(array('plugin', 'setting', 'styles'));
			cleartemplatecache();
			updatemenu('plugin');
			$result = "succeed";
			$submenuitem = array();
			loadcache('plugin');
			if ($op == 'enable' && isset($_G['cache']['plugin'][$plugin['identifier']])) {
				$submenuitem[] = '<a href="'.DUCEAPP_OP_URL.'config&do='.$plugin['pluginid'].'">设置</a>';
			}
			if ($plugin['modules']) {
				foreach($plugin['modules'] as $k => $module) {
					if($module['type'] == 3) {
						$submenuitem[] = '<a href="'.DUCEAPP_OP_URL.'config&do='.$plugin['pluginid'].'&pmod='.$module['name'].($module['param'] ? '&'.$module['param'] : '').'">'.$this->__($module['menu']).'</a>';
					}
					if($module['type'] == 29) {
						$submenuitem[] = '<a href="'.$module['url'].'" target="_blank">'.$this->__($module['menu']).'</a>';
					}
				}
			}
			$duceapp_cplang = array();
			@include duceapp_language('admincp', DISCUZ_ROOT.'source/plugin/'.$dir.'/language/');
			if ($duceapp_cplang['extapi']) {
				$submenuitem[] = '<a href="'.DUCEAPP_OP_URL.'config&do='.$plugin['pluginid'].'&pmod=compon&api='.$duceapp_cplang['extapi'].'">'.$this->__($duceapp_cplang['module_'.$duceapp_cplang['extapi']]).'</a>';
			}
			$result .= '<script reload="1">$("ditem_menu_'.$plugin['pluginid'].'").innerHTML="'.addslashes(implode(' <span>/</span> ', $submenuitem)).'";duceapp_oleftmenu("'.($submenuitem && $op == 'enable' ? 'add' : 'remove').'",'.$_GET['actionid'].',"'.addslashes($this->__($plugin['name'])).'")</script>';
		}
		$this->ajaxout($result);
	}

	public function upgradecheck($plugin) {
		global $_G, $importtxt;
		$addonid = $plugin['identifier'].'.plugin';
		if (!$_G['cache']['duceappcheck_pluginxml']) {
			loadcache('duceappcheck_pluginxml');
		}
		if ($checkresult = $_G['cache']['duceappcheck_pluginxml'][$addonid]) {
			unset($_G['cache']['duceappcheck_pluginxml'][$addonid]);
		}
		$upgradeinfo = '';
		if (file_exists($entrydir = DISCUZ_ROOT.'./source/plugin/'.substr($plugin['directory'], 0, -1))) {
			$d = dir($entrydir);
			$newresult = array();
			while($f = $d->read()) {
				if (preg_match('/^discuz\_plugin\_'.$plugin['identifier'].'(\_\w+)?\.xml$/', $f, $a)) {
					$ver = substr($a[1], 1);
					if (preg_match('/^SC\_GBK$/i', $ver)) {
						$vertxt = '&#31616;&#20307;&#20013;&#25991;&#29256;';
					} elseif(preg_match('/^SC\_UTF8$/i', $ver)) {
						$vertxt = '&#31616;&#20307;&#20013;&#25991;&#85;&#84;&#70;&#56;&#29256;';
					} elseif(preg_match('/^TC\_BIG5$/i', $ver)) {
						$vertxt = '&#32321;&#39636;&#20013;&#25991;&#29256;';
					} elseif(preg_match('/^TC\_UTF8$/i', $ver)) {
						$vertxt = '&#32321;&#39636;&#20013;&#25991;&#85;&#84;&#70;&#56;&#29256;';
					} else {
						$ver = 'DEFAULT'; $vertxt = '默认';
					}
					list($oldtime, $upgradename, $verno) = explode("\t", $checkresult[$ver]);
					if ($oldtime == ($mtime = @filemtime($entrydir.'/'.$f)) && $verno) {
						$newresult[$ver] = $checkresult[$ver];
						if (!$_GET['upcheck'] && $verno > $pluginarray['plugin']['version']) {
							$upgradeinfo .= "\n".$upgradename.' '.$verno;
						}
					}
					if ($_GET['upcheck'] && $this->__allowpost()) {
						$importtxt = @implode('', file($entrydir.'/'.$f));
						$pluginarray = getimportdata('Discuz! Plugin', 0, 1);
						$newverother = !empty($pluginarray['plugin']['version']) ? $pluginarray['plugin']['version'] : 0;
						if ($newverother > $plugin['version']) {
							$newresult[$ver] = $mtime."\t".$vertxt."\t".$newverother;
							$upgradeinfo .= "\n".$vertxt." ".$newverother;
							$this->chkpluginxmlsave = true;
						}
					}
				}
			}
			if ($newresult) {
				$_G['cache']['duceappcheck_pluginxml'][$addonid] = $newresult;
			}
		}
		return $upgradeinfo ? '<a class="gnew" href="javascript:;" style="color:#096" onclick="duceapp_addonUpgrade('.$plugin['pluginid'].')" title="点击安装更新'.$upgradeinfo.'">安装更新</a>' : '';
	}

	public function renewtpl() {
		global $_G, $importtxt, $stylearray;
		if ($_GET['sdir']) {
			require_once libfile('function/importdata');
			$dir = str_replace(array('/', '\\'), '', $_GET['sdir']);
			$templatedir = DISCUZ_ROOT.'./template/'.$dir;
			$searchdir = dir($templatedir);
			$stylearrays = array();
			while($searchentry = $searchdir->read()) {
				if (substr($searchentry, 0, 13) == 'discuz_style_' && fileext($searchentry) == 'xml') {
					$importfile = $templatedir.'/'.$searchentry;
					$importtxt = implode('', file($importfile));
					$stylearrays[] = getimportdata('Discuz! Style', 0, 1);
				}
			}
			foreach($stylearrays as $stylearray) {
				$renamed = 0;
				if ($stylearray['templateid'] != 1) {
					$templatedir = DISCUZ_ROOT.'./'.$stylearray['directory'];
					if(!is_dir($templatedir)) {
						if(!@mkdir($templatedir, 0777)) {
							$basedir = dirname($stylearray['directory']);
							$this->ajaxout('界面方案导入失败，模版目录没有可写权限');
						}
					}
					$templateid = DB::result_first("SELECT templateid FROM %t WHERE %i", array('common_template', DB::field('directory', '%/'.$dir, 'like')));
					if (!$templateid) {
						$templateid = C::t('common_template')->insert(array(
							'name' => $stylearray['tplname'],
							'directory' => $stylearray['directory'],
							'copyright' => $stylearray['copyright']
						), true);
					}
				} else {
					$templateid = 1;
				}
				if (!C::t('common_style')->check_stylename($stylearray['name'])) {
					$styleidnew = C::t('common_style')->insert(array('name' => $stylearray['name'], 'templateid' => $templateid), true);
				} else {
					$renamed = 1;
				}
				foreach($stylearray['style'] as $variable => $substitute) {
					$substitute = @dhtmlspecialchars($substitute);
					if ($styleidnew) {
						C::t('common_stylevar')->insert(array('styleid' => $styleidnew, 'variable' => $variable, 'substitute' => $substitute));
					}
				}
			}
			cloudaddons_clear('template', $dir);
			updatecache('styles');
			updatecache('setting');
			if ($renamed) {
				$js = '<script reload="1">if($("ditem_"+_upgradeId)){$("ditem_"+_upgradeId).className="duceapp_tpl cl";$("ditem_"+_upgradeId+"_name").innerHTML="'.addslashes($this->__n($stylearray['name'])).'";}</script>';
			} else {
				$js = '<script reload="1">setTimeout(function(){window.location.reload()}, 2000);</script>';
			}
		} elseif ($_GET['actionid']) {
			$template = C::t('common_style')->fetch_by_styleid($_GET['actionid']);
			preg_match('/^.?\/template\/([a-z]+[a-z0-9_]*)$/', $template['directory'], $a);
			$addonid = $a[1].'.template';
			$checkresult = $this->cloudcheck(array($addonid), false);
			list(, $newver, , $duceappver) = explode(':', $checkresult[$addonid]);
			if ($newver || $duceappver) {			
				if ($duceappver) {
					$upver = $this->__($duceappver);
					$msg = '发现此模版在官方网站存在新版本';				
					$callback = 'duceapp_addonUpgrade(\''.$template['styleid'].'\', \'tpl=1\', \'download\');parent.hideMenu();return false;';
					$loga = '<a style=\"float:none;display:inline;color:#237ffd\" href=\"'.substr(DUCEAPP_API_URL, 0, -6).'templates/'.$a[1].'.html?revlog\" target=\"_blank\">查看更新日志</a>';
				} else {
					$upver = $this->__($newver);
					$msg = '发现此模版在应用中心存在新版本';
					$callback = 'window.location.href="'.ADMINSCRIPT.'?action=cloudaddons&id='.$addonid.'"';
					$loga = '';
				}
				$this->ajaxout('<script reload="1">duceapp_showPrompt("'.$msg.' <b>'.(strpos($upver, '&#12289;') !== false ? '<br /><span style=\"white-space:nowrap\">'.str_replace(' &#12289; ', '</span> &nbsp; <span style=\"white-space:nowrap\">', $upver).'</span>' : $upver).'</b><br />是否需要升级？'.$loga.'",{w:500,h3:"'.addslashes($this->__n($template['name'])).'",confirm:"升级此模版",cancel:"暂不升级"},function(){'.$callback.'})</script>');
			}
		}
		$this->ajaxout('模版已更新到最新版本'.$js);
	}

	public function upgrade() {
		global $_G, $admincp, $plugin, $importtxt;
		if (!$_GET['inajax']) {
			dheader('location:'.DUCEAPP_ADDON_URL);
		}
		if (!$this->__allowpost()) {
			$this->ajaxout('抱歉，您无权使用此功能');
		}
		if ($_GET['tpl']) {
			$this->renewtpl();
		}
		$plugin = C::t('common_plugin')->fetch($_GET['actionid']);
		$modules = dunserialize($plugin['modules']);
		$dir = substr($plugin['directory'], 0, -1);
		
		if (!$_GET['confirmed']) {
			$file = DISCUZ_ROOT.'./source/plugin/'.$dir.'/discuz_plugin_'.$dir.($modules['extra']['installtype'] ? '_'.$modules['extra']['installtype'] : '').'.xml';
			$upgrade = false;
			if (file_exists($file)) {
				$importtxt = @implode('', file($file));
				$pluginarray = getimportdata('Discuz! Plugin', 0, 1);
				$newver = !empty($pluginarray['plugin']['version']) ? $pluginarray['plugin']['version'] : 0;
				$upgrade = $newver > $plugin['version'] ? true : false;
			}
			if ($upgrade) {
				$return = '<script reload="1">duceapp_showPrompt("您确定要把 '.addslashes($this->__($plugin['name'])).' <b>'.$plugin['version'].'</b> 插件更新到 <b>'.$newver.'</b> 吗？", {w:500,h3:"更新提示",confirm:"立即更新"}, function(){duceapp_addonUpgrade('.$plugin['pluginid'].', "confirmed=1")})</script>';
				$this->ajaxout($return);
			}
			$entrydir = DISCUZ_ROOT.'./source/plugin/'.$dir;
			$upgradestr = '';
			if(file_exists($entrydir)) {
				$d = dir($entrydir);
				$isCurr = false;
				while($f = $d->read()) {
					if(preg_match('/^discuz\_plugin\_'.$plugin['identifier'].'(\_\w+)?\.xml$/', $f, $a)) {
						$extratxt = $extra = substr($a[1], 1);
						$style = $checked = '';
						$current = false;
						if(preg_match('/^SC\_GBK$/i', $extra)) {
							$extratxt = '&#31616;&#20307;&#20013;&#25991;&#29256;';
							$current = strtoupper(CHARSET) == 'GBK';
						} elseif(preg_match('/^SC\_UTF8$/i', $extra)) {
							$extratxt = '&#31616;&#20307;&#20013;&#25991;&#85;&#84;&#70;&#56;&#29256;';
							$current = strtoupper(CHARSET) == 'UTF-8' && $_G['config']['output']['language'] == 'zh_cn';
						} elseif(preg_match('/^TC\_BIG5$/i', $extra)) {
							$extratxt = '&#32321;&#39636;&#20013;&#25991;&#29256;';
							$current = strtoupper(CHARSET) == 'BIG5';
						} elseif(preg_match('/^TC\_UTF8$/i', $extra)) {
							$extratxt = '&#32321;&#39636;&#20013;&#25991;&#85;&#84;&#70;&#56;&#29256;';
							$current = strtoupper(CHARSET) == 'UTF-8' && $_G['config']['output']['language'] == 'zh_tw';
						}
						if($modules['extra']['installtype'] == $extratxt) {
							continue;
						}
						if (($current || !$extra) && !$isCurr) {
							$style = 'color:#fff;background:#096;';
							$checked = ' checked';
							$isCurr = true;
						}
						$importtxt = @implode('', file($entrydir.'/'.$f));
						$pluginarray = getimportdata('Discuz! Plugin', 0, 1);
						$newverother = !empty($pluginarray['plugin']['version']) ? $pluginarray['plugin']['version'] : 0;
						$upgradestr .= $newverother > $plugin['version'] ? '<span style="display:inline-block;margin:8px 5px 0;height:20px;line-height:20px;padding:0 5px 0 3px;border-radius:3px;cursor:pointer;'.$style.'"><input name="installtype" style="display:none;" type="radio" value="'.($extra ? $extra : 'DEFAULT').'"'.$checked.' />&nbsp;'.($extra ? $extratxt : '默认').' '.$newverother.'</span>' : '';
					}
				}
			}
			if ($upgradestr) {
				$formid = random(10);
				echo '<script reload="1">
				duceapp_showPrompt("您确定要把 '.addslashes($this->__($plugin['name'])).' <b>'.$plugin['version'].'</b> 更新到以下版本吗？<form id=\"update_'.$formid.'\" style=\"font-size:12px\">'.addslashes($upgradestr).'</form>", {w:500,h3:"更新提示",confirm:"立即更新"}, function(){
					var instype=parent.document.getElementById("update_'.$formid.'").installtype.value;
					if (!instype) {
						alert("请选择要更新的版本");return false;
					}
					instype = instype == "DEFAULT" ? "" : "&installtype="+instype;
					duceapp_addonUpgrade('.$plugin['pluginid'].', "confirmed=1" + instype)
				});
				var span=parent.document.getElementById("update_'.$formid.'").getElementsByTagName("span");
				for(var i=0;i<span.length;i++){
					_attachEvent(span[i], "click", function(){
						for(var j=0;j<span.length;j++){
							span[j].style.color="";
							span[j].style.background="";
						}
						this.getElementsByTagName("input")[0].checked=true;
						this.style.color="#fff";
						this.style.background="#096";
					});
				}
				</script>';
			} else {
				$addonid = $plugin['identifier'].'.plugin';
				$checkresult = $this->cloudcheck(array($addonid), false);
				$js = '';
				if ($_GET['fromdl']) {
					$js = '<script>$("ditem_'.$plugin['pluginid'].'").className="duceapp_plugin cl";$("ditem_'.$plugin['pluginid'].'_name").innerHTML="'.addslashes($this->__n($plugin['name'])).' '.$plugin['version'].'";</script>';
					savecache('duceappcheck_plugin', $checkresult = array());
				}
				list($return, $newver, $sysver, $duceappver) = explode(':', $checkresult[$addonid]);
				if (($sysver && $sysver > $plugin['version']) || $newver || $duceappver) {			
					if ($duceappver) {
						$upver = $this->__($duceappver);
						$msg = '发现此插件在官方网站存在新版本';				
						$callback = 'duceapp_addonUpgrade(\''.$plugin['pluginid'].'\', null, \'download\');parent.hideMenu();return false;';
						$loga = '<a style=\"float:none;display:inline;color:#237ffd\" href=\"'.substr(DUCEAPP_API_URL, 0, -6).'plugins/'.$plugin['identifier'].'.html?revlog\" target=\"_blank\">查看更新日志</a>';
					} else {
						$upver = $sysver && $sysver > $plugin['version'] ? $sysver : $this->__($newver);
						$msg = '发现此插件在应用中心存在新版本';
						$callback = 'window.location.href="'.ADMINSCRIPT.'?action=cloudaddons&id='.$plugin['identifier'].'.plugin"';
						$loga = '';
					}
					$this->ajaxout('<script reload="1">duceapp_showPrompt("'.$msg.' <b>'.(strpos($upver, '&#12289;') !== false ? '<br /><span style=\"white-space:nowrap\">'.str_replace(' &#12289; ', '</span> &nbsp; <span style=\"white-space:nowrap\">', $upver).'</span>' : $upver).'</b><br />是否需要升级？'.$loga.'",{w:500,h3:"'.addslashes($this->__n($plugin['name'])).'",confirm:"升级此插件",cancel:"暂不升级"},function(){'.$callback.'})</script>');
				} else {
					$this->ajaxout('插件已更新到最新版本'.$js);
				}
			}
		} else {
			$installtype = !isset($_GET['installtype']) ? $modules['extra']['installtype'] : (preg_match('/^\w+$/', $_GET['installtype']) ? $_GET['installtype'] : '');
			$importfile = DISCUZ_ROOT.'./source/plugin/'.$dir.'/discuz_plugin_'.$dir.($installtype ? '_'.$installtype : '').'.xml';
			if (!file_exists($importfile)) {
				$this->ajaxout('插件文件缺失');
			}
			$importtxt = @implode('', file($importfile));
			$pluginarray = getimportdata('Discuz! Plugin', 0, 1);

			if (!ispluginkey($pluginarray['plugin']['identifier']) || $pluginarray['plugin']['identifier'] != $plugin['identifier']) {
				$this->ajaxout('插件唯一标识符不合法或与现有插件重复');
			}
			if(is_array($pluginarray['vars'])) {
				foreach($pluginarray['vars'] as $config) {
					if (!ispluginkey($config['variable'])) {
						$this->ajaxout('插件的嵌入点名称不合法，无法更新');
					}
				}
			}
			$toversion = $pluginarray['plugin']['version'];
			$s = '插件成功更新到 <b>'.$toversion.'</b><script reload="1">$("ditem_'.$plugin['pluginid'].'").className="duceapp_plugin cl";$("ditem_'.$plugin['pluginid'].'_name").innerHTML="'.addslashes($this->__n($plugin['name'])).' '.$toversion.'";</script>';
			
			if (in_array(basename(DISCUZ_ROOT), array('dev', 'app', 'master'))) {
				$this->ajaxout($s);
			}

			pluginupgrade($pluginarray, $installtype);
			
			if (!$_G['cache']['duceappcheck_pluginxml']) {
				loadcache('duceappcheck_pluginxml');
			}
			if (isset($_G['cache']['duceappcheck_pluginxml'][$plugin['identifier'].'.plugin'])) {
				unset($_G['cache']['duceappcheck_pluginxml'][$plugin['identifier'].'.plugin']);
				savecache('duceappcheck_pluginxml', $_G['cache']['duceappcheck_pluginxml']);
			}
			savecache('duceappcheck_plugin', array());
			updatecache(array('plugin', 'setting', 'styles'));

			if (!empty($plugin['directory']) && !empty($pluginarray['upgradefile']) && preg_match('/^[\w\.]+$/', $pluginarray['upgradefile'])) {
				$url = ADMINSCRIPT.'?action=plugins&operation=pluginupgrade&dir='.$dir.'&installtype='.$installtype.'&fromversion='.$plugin['version'];
				$s = '
				<script reload="1">
				(function(){
					var x = new Ajax();
					x.get("'.$url.'", function(s) {
						duceapp_showPrompt("插件成功更新到 <b>'.$toversion.'</b>");
						$("ditem_'.$plugin['pluginid'].'").className="duceapp_plugin cl";
						$("ditem_'.$plugin['pluginid'].'_name").innerHTML="'.addslashes($this->__n($plugin['name'])).' '.$toversion.'";
					});
				})();
				</script>';
			}
			$this->ajaxout($s);
		}
	}

	public function __($str) {
		return diconv($str, CHARSET, DUCEAPP_F_CHARSET);
	}

	public function __n($pluginname) {
		return str_replace(array('【', '】'), array('', '<em style="margin:0 2px;">-</em>'), dhtmlspecialchars($this->__($pluginname)));
	}

	public function __allowpost() {
		global $admincp;
		return isfounder() || !$admincp->adminsession['cpgroupid'] || array_key_exists('_allowpost', $admincp->perms);
	}

	public function __apiurl() {
		global $_G;
		require_once DISCUZ_ROOT.'./source/discuz_version.php';
		$data = 'usrid='.rawurlencode(substr(md5(cloudaddons_getuniqueid()), 16));
		$data .= '&siteurl='.rawurlencode($_G['siteurl']);
		$data .= '&sitever='.DISCUZ_VERSION.'/'.DISCUZ_RELEASE;
		$data .= '&sitecharset='.CHARSET;
		$data .= '&mysiteid='.$_G['setting']['my_siteid'];
		$param = 'data='.rawurlencode(base64_encode($data)).'&md5hash='.substr(md5($data.TIMESTAMP), 8, 8).'&timestamp='.TIMESTAMP;
		return DUCEAPP_API_URL.$param;
		//return DUCEAPP_API_URL.str_replace(CLOUDADDONS_DOWNLOAD_URL.'?', '', cloudaddons_url('&from=s'));
	}

	public function __cleardir($dir) {
		if($directory = @dir($dir)) {
			while($entry = $directory->read()) {
				if($entry == '.' || $entry == '..') {
					continue;
				}
				$filename = $dir.'/'.$entry;
				if(is_file($filename)) {
					@unlink($filename);
				} else {
					$this->__cleardir($filename);
				}
			}
			$directory->close();
			@rmdir($dir);
		}
	}

	public function output() {
		$content = ob_get_contents();
		ob_end_clean();
		if (!empty($_GET['inajax'])) {
			$this->ajaxout($content);
		}
		$_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
		echo diconv($content, DUCEAPP_F_CHARSET, CHARSET);
		duceapp_exit();
	}

	public function ajaxout($content) {
		ajaxshowheader();
		echo diconv($content, DUCEAPP_F_CHARSET, CHARSET);
		ajaxshowfooter();
		exit();
	}

	public function response($url, $post = null, $timeout = 60) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		if (!empty($post)) {
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, is_array($post) ? implode('&', $post) : $post);
		}
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
		curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
		$data = curl_exec($ch);
		$status = curl_getinfo($ch);
		$errno = curl_errno($ch);
		curl_close($ch);
		if (!$errno && $status['http_code'] == 200) {
			return $data;
		}
		return null;
	}

	public function cloudcheck($addonids, $getall = true) {
		if (function_exists('curl_init') && function_exists('curl_exec')) {
			$post = array();
			if ($getall) {
				$post[] = 'getall=yes';
			}
			foreach($addonids as $addonid) {
				$array = cloudaddons_getmd5($addonid);
				$post[] = 'rid['.$addonid.']='.$array['RevisionID'].'&sn['.$addonid.']='.$array['SN'].'&rd['.$addonid.']='.$array['RevisionDateline'];
			}
			$data = dunserialize($this->response($this->__apiurl(), $post));
			if ($data && $data['data']) {
				$duceappdata = $data['data'];
				$data = dunserialize(cloudaddons_upgradecheck($addonids));				
				foreach($duceappdata as $addonid => $ver) {
					if ($data[$addonid]) {
						$data[$addonid] .= str_replace('2::', '', $ver);
					} else {
						$data[$addonid] = $ver;
					}
				}
			}
		}
		return $data ? $data : dunserialize(cloudaddons_upgradecheck($addonids));
	}
}