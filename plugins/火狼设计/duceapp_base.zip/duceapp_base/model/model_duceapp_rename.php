<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2020-03-11
 * Version: 3.00310
 * Date: 2021-06-30 22:19:57
 * File: model_duceapp_rename.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class model_duceapp_rename
{
	public function apply($get = array()) {
		if (empty($get) || !$get['uid'] || !$get['username']) {
			return '';
		}
		global $_G;
		C::t('common_member')->update($get['uid'], array('password' => md5(random(10)), 'username' => $get['newusername']));
		$tables = array(
			'common_block' => array('id' => 'uid', 'name' => 'username'),
			'common_invite' => array('id' => 'fuid', 'name' => 'fusername'),
			'common_member' => array('id' => 'uid', 'name' => 'username'),
			'common_member_verify_info' => array('id' => 'uid', 'name' => 'username'),
			'common_mytask' => array('id' => 'uid', 'name' => 'username'),
			'common_report' => array('id' => 'uid', 'name' => 'username'),

			'forum_collection' => array('id' => 'uid', 'name' => 'username'),

			'forum_activityapply' => array('id' => 'uid', 'name' => 'username'),
			'forum_collectioncomment' => array('id' => 'uid', 'name' => 'username'),
			'forum_collectionfollow' => array('id' => 'uid', 'name' => 'username'),
			'forum_collectionteamworker' => array('id' => 'uid', 'name' => 'username'),
			'forum_debate' => array('id' => 'uid', 'name' => 'umpire'),
			'forum_forumrecommend' => array('id' => 'authorid', 'name' => 'author'),
			'forum_groupuser' => array('id' => 'uid', 'name' => 'username'),
			'forum_pollvoter' => array('id' => 'uid', 'name' => 'username'),
			'forum_post' => array('id' => 'authorid', 'name' => 'author'),
			'forum_postcomment' => array('id' => 'authorid', 'name' => 'author'),
			'forum_promotion' => array('id' => 'uid', 'name' => 'username'),
			'forum_ratelog' => array('id' => 'uid', 'name' => 'username'),
			'forum_thread' => array('id' => 'authorid', 'name' => 'author'),
			
			'home_album' => array('id' => 'uid', 'name' => 'username'),
			'home_blog' => array('id' => 'uid', 'name' => 'username'),
			'home_clickuser' => array('id' => 'uid', 'name' => 'username'),
			'home_comment' => array('id' => 'authorid', 'name' => 'author'),
			'home_docomment' => array('id' => 'uid', 'name' => 'username'),
			'home_doing' => array('id' => 'uid', 'name' => 'username'),
			'home_feed' => array('id' => 'uid', 'name' => 'username'),
			'home_feed_app' => array('id' => 'uid', 'name' => 'username'),
			'home_follow' => array('id' => 'uid', 'name' => 'username'),
			'home_follow_feed' => array('id' => 'uid', 'name' => 'username'),
			'home_follow_feed_archiver' => array('id' => 'uid', 'name' => 'username'),
			'home_friend' => array('id' => 'fuid', 'name' => 'fusername'),
			'home_friend_request' => array('id' => 'fuid', 'name' => 'fusername'),
			'home_notification' => array('id' => 'authorid', 'name' => 'author'),
			'home_pic' => array('id' => 'uid', 'name' => 'username'),
			'home_poke' => array('id' => 'fromuid', 'name' => 'fromusername'),
			'home_share' => array('id' => 'uid', 'name' => 'username'),
			'home_show' => array('id' => 'uid', 'name' => 'username'),
			'home_specialuser' => array('id' => 'uid', 'name' => 'username'),
			'home_visitor' => array('id' => 'vuid', 'name' => 'vusername'),

			'portal_article_title' => array('id' => 'uid', 'name' => 'username'),
			'portal_comment' => array('id' => 'uid', 'name' => 'username'),
			'portal_topic' => array('id' => 'uid', 'name' => 'username'),
			'portal_topic_pic' => array('id' => 'uid', 'name' => 'username') 
		);

		if (!C::t('common_member')->update($get['uid'], array('username' => $get['newusername'])) && isset($_G['setting']['membersplit'])){
			C::t('common_member_archive')->update($get['uid'], array('username' => $get['newusername']));
		}

		loadcache("posttableids");

		if ($_G['cache']['posttableids']) {
			foreach($_G['cache']['posttableids'] as $tableid) {
				$tables[getposttable($tableid)] = array('id' => 'authorid', 'name' => 'author');
			}
		}

		foreach($tables as $table => $conf) {
			DB::query("UPDATE ".DB::table($table)." SET `$conf[name]`='$get[newusername]' WHERE `$conf[id]`='$get[uid]'");
		}

		DB::update('forum_collection', array('lastposter' => $get['newusername']), array('lastposter' => $get['username']));
		DB::update('forum_thread', array('lastposter' => $get['newusername']), array('lastposter' => $get['username']));
		DB::update('home_follow', array('fusername' => $get['newusername']), array('followuid' => $get['uid']));
	}
}