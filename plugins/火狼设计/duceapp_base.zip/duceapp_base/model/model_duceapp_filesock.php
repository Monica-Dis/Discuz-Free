<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-10-07
 * Version: 3.10102
 * Date: 2021-06-30 22:19:57
 * File: model_duceapp_filesock.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class model_duceapp_filesock
{
	public $compression = '';
	public $sslverify = FALSE;
	public $usecert = FALSE;
	public $location = TRUE;
	public $allowurl = TRUE;
	public $charset = 'utf-8';
	public $header;

	public function init($sslverify = FALSE, $usecert = FALSE, $compression = '', $location = TRUE, $allowcurl = TRUE, $header = NULL) {
		$this->sslverify = $sslverify;
		$this->usecert = $usecert;
		$this->compression = $compression;
		$this->location = $location;
		$this->allowcurl = $allowcurl;
		$this->header = $header;
		return $this;
	}

	public function open($url, $post = '', $timeout = 15, $limit = 0, $cookie = '', $bysocket = FALSE, $ip = '', $block = TRUE, $encodetype = 'URLENCODE', $allowcurl = TRUE, $position = 0, $files = array()) {
		if (!function_exists('curl_init') || !function_exists('curl_exec')) {
			if (!$this->allowcurl || !$allowcurl) {
				throw new Exception(diconv("服务器PHP不支持cURL", $this->charset));
				return;
			}
			$data = dfsockopen($url, $limit, $post, $cookie, $bysocket, $ip, $timeout, $block, $encodetype, $allowcurl, $position, $files);
			if ($this->compression == 'gzip') {
				return $this->gzdecode($data);
			}
			return $data;
		}
		$ch = curl_init();

		if (defined('DUCEAPP_PROXYHOST') && defined('DUCEAPP_PROXYPORT') && DUCEAPP_PROXYHOST != '0.0.0.0' && DUCEAPP_PROXYPORT != 0) {
			curl_setopt($ch, CURLOPT_PROXY, DUCEAPP_PROXYHOST);
			curl_setopt($ch, CURLOPT_PROXYPORT, DUCEAPP_PROXYPORT);
		}

		if(!empty($this->header)){
			curl_setopt($ch, CURLOPT_HTTPHEADER, $this->header);
		}
		
		curl_setopt($ch, CURLOPT_URL, $url);		
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $this->sslverify ? TRUE : FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $this->sslverify ? 2 : FALSE);
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		
		if ($cookie) {
			curl_setopt($ch, CURLOPT_COOKIE, $cookie);
		}
		if ($this->compression) {
        	curl_setopt($ch, CURLOPT_ENCODING, $this->compression);
		}
		if (DUCEAPP_CURLCAINFO === TRUE) {
			curl_setopt($ch, CURLOPT_CAINFO, DISCUZ_ROOT.'./source/plugin/duceapp_base/static/cacert/root.pem');
		}
		if ($this->usecert) {
			curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM');
			curl_setopt($ch, CURLOPT_SSLCERT, DUCEAPP_SSLCERT);
			curl_setopt($ch, CURLOPT_SSLKEYTYPE, 'PEM');
			curl_setopt($ch, CURLOPT_SSLKEY, DUCEAPP_SSLKEY);
		}
		if ($post) {
			curl_setopt($ch, CURLOPT_POST, TRUE);
			if ($encodetype == 'URLENCODE') {
				curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
			} else {
				foreach($post as $k => $v) {
					if(isset($files[$k])) {
						$post[$k] = '@'.$files[$k];
					}
				}
				foreach($files as $k => $file) {
					if(!isset($post[$k]) && file_exists($file)) {
						$post[$k] = '@'.$file;
					}
				}
				curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
			}
		}
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
		curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, $this->location);

		$data = curl_exec($ch);
		
		if ($data) {
			curl_close($ch);
			return $data;
		} else {
			$error = curl_errno($ch);
			curl_close($ch);
			throw new Exception(diconv("cURL出错，错误码：$error", $this->charset));
			return;
		}
	}

	public function gzdecode($data){
		$len = strlen($data);
		if ($len < 18 || strcmp(substr($data,0,2),"\x1f\x8b")) {
			return null;
		}
		$method = ord(substr($data,2,1));
		$flags  = ord(substr($data,3,1));
		if ($flags & 31 != $flags) {
			return null;
		}
		$mtime = unpack("V", substr($data,4,4));
		$mtime = $mtime[1];
		$xfl   = substr($data,8,1);
		$os    = substr($data,8,1);
		$headerlen = 10;
		$extralen  = 0;
		$extra     = "";
		if ($flags & 4) {
			if ($len - $headerlen - 2 < 8) {
				return false;
			}
			$extralen = unpack("v",substr($data,8,2));
			$extralen = $extralen[1];
			if ($len - $headerlen - 2 - $extralen < 8) {
				return false;
			}
			$extra = substr($data,10,$extralen);
			$headerlen += 2 + $extralen;
		}

		$filenamelen = 0;
		$filename = "";
		if ($flags & 8) {
			if ($len - $headerlen - 1 < 8) {
				return false;
			}
			$filenamelen = strpos(substr($data,8+$extralen),chr(0));
			if ($filenamelen === false || $len - $headerlen - $filenamelen - 1 < 8) {
				return false;
			}
			$filename = substr($data,$headerlen,$filenamelen);
			$headerlen += $filenamelen + 1;
		}

		$commentlen = 0;
		$comment = "";
		if ($flags & 16) {
			if ($len - $headerlen - 1 < 8) {
				return false;
			}
			$commentlen = strpos(substr($data,8+$extralen+$filenamelen),chr(0));
			if ($commentlen === false || $len - $headerlen - $commentlen - 1 < 8) {
				return false;
			}
			$comment = substr($data,$headerlen,$commentlen);
			$headerlen += $commentlen + 1;
		}

		$headercrc = "";
		if ($flags & 2) {
			if ($len - $headerlen - 2 < 8) {
				return false;
			}
			$calccrc = crc32(substr($data,0,$headerlen)) & 0xffff;
			$headercrc = unpack("v", substr($data,$headerlen,2));
			$headercrc = $headercrc[1];
			if ($headercrc != $calccrc) {
				return false;
			}
			$headerlen += 2;
		}

		$datacrc = unpack("V",substr($data,-8,4));
		$datacrc = $datacrc[1];
		$isize = unpack("V",substr($data,-4));
		$isize = $isize[1];

		$bodylen = $len-$headerlen-8;
		if ($bodylen < 1) {
			return null;
		}
		$body = substr($data,$headerlen,$bodylen);
		$data = "";
		if ($bodylen > 0) {
			switch ($method) {
				case 8:
					$data = gzinflate($body);
					break;
				default:
					return false;
			}
		}

		if ($isize != strlen($data) || crc32($data) != $datacrc) {
			return false;
		}
		return $data;
	}
}