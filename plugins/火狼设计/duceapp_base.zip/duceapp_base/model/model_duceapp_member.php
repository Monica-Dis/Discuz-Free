<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-02-23
 * Version: 3.01202
 * Date: 2021-06-30 22:19:57
 * File: model_duceapp_member.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class model_duceapp_member
{
	public $lang = array(
		'navtitle' => '&#21021;&#22987;&#21270;&#23494;&#30721;',
		'passlevel' => '&#23494;&#30721;&#24378;&#24230;',
		'new_username' => '&#26032;&#29992;&#25143;&#21517;',
		'new_username_tips' => '&#19981;&#20462;&#25913;&#30331;&#24405;&#29992;&#25143;&#21517;&#35831;&#30041;&#31354;&#65292;&#25552;&#20132;&#21518;&#23558;&#19981;&#20877;&#26377;&#20462;&#25913;&#30340;&#26435;&#38480;&#12290;',
		'password_reset' => '&#24080;&#21495;&#23494;&#30721;&#24050;&#35774;&#32622;&#25104;&#21151;&#12290;',
	);

	public function fetch($uid = null, $mem = null) {
		global $_G;
		if ($mem && $mem['duceapp_ready']) {
			return $mem;
		}
		$uid = $uid === null ? $_G['uid'] : $uid;
		if (empty($uid)) {
			return $mem !== null ? $mem : array();
		}
		if ($_G['uid'] == $uid) {
			if (!isset($_G['duceapp_member'])) {
				$_G['duceapp_member'] = C::t('#duceapp_base#duceapp_member')->fetch($uid);
			}
			$member = $_G['duceapp_member'];
		} else {
			$member = C::t('#duceapp_base#duceapp_member')->fetch($uid);
		}
		if ($mem !== null) {
			$mem['duceapp_ready'] = 1;
		}
		return $mem ? array_merge($member, $mem) : $member;
	}

	public function repwd($pwd1 = null, $pwd2 = null) {
		global $_G, $uc_controls;

		$redirect = $_GET['from'] == 'spacecp' || $_GET['from'] == 'contact' ? 'home.php?mod=spacecp&ac=profile'.($_GET['from'] == 'contact' ? '&op=password&from=contact#contact' : '') : dreferer();
		foreach(array('duceapp_member', 'duceapp_wechatuser') as $key) {
			if ($_G[$key] && $_G[$key]['isregister'] != 1) {
				if ($_G['inajax']) {
					showmessage('', $redirect, array(), array('location' => true));
				} else {
					dheader('location:'.$redirect);
				}
				return;
			}
		}
		$allowusername = $_G['cache']['duceapp_wechat']['allowchange'] || $_G['cache']['duceapp_smsauth']['allowrename'];

		if (submitcheck('newpwsubmit')) {
			$newpassword = $pwd1 !== null ? $pwd1 : $_GET['newpassword1'];
			$confirmpassword = $pwd2 !== null ? $pwd2 : $_GET['newpassword2'];
			if ($_G['setting']['strongpw']) {
				$strongpw_str = array();
				if(in_array(1, $_G['setting']['strongpw']) && !preg_match("/\d+/", $newpassword)) {
					$strongpw_str[] = lang('member/template', 'strongpw_1');
				}
				if(in_array(2, $_G['setting']['strongpw']) && !preg_match("/[a-z]+/", $newpassword)) {
					$strongpw_str[] = lang('member/template', 'strongpw_2');
				}
				if(in_array(3, $_G['setting']['strongpw']) && !preg_match("/[A-Z]+/", $newpassword)) {
					$strongpw_str[] = lang('member/template', 'strongpw_3');
				}
				if(in_array(4, $_G['setting']['strongpw']) && !preg_match("/[^a-zA-z0-9]+/", $newpassword)) {
					$strongpw_str[] = lang('member/template', 'strongpw_4');
				}
				if($strongpw_str) {
					showmessage(lang('member/template', 'password_weak').implode(',', $strongpw_str));
				}
			}
			if ($newpassword !== $confirmpassword) {
				showmessage('profile_passwd_notmatch');
			}
			if (!$newpassword || $newpassword != addslashes($newpassword)) {
				showmessage('profile_passwd_illegal');
			}

			loaducenter();

			if ($allowusername && ($newusername = trim($_GET['newusername']))) {
				$this->reacct($newusername);
				uc_user_edit(addslashes($_G['username'] = $newusername), null, $newpassword, null, 1);
			} else {
				uc_user_edit(addslashes($_G['username']), null, $newpassword, null, 1);
			}
			if (defined('DUCEAPP_SMSAUTH')) {
				C::t('#duceapp_base#duceapp_member')->batch_update($_G['uid'], array('isregister' => 2, 'nickname' => $_G['username']));
			}
			if (defined('DUCEAPP_WECHAT')) {				
				if ($allowusername && $newusername) {
					include_once libfile('class/duceapp_wechatapi', 'plugin/duceapp_wechat');
					duceapp_wechatapi::report('synrename', array('uid' => $_G['uid'], 'username' => $_G['username'], 'newusername' => $newusername));
				}
				C::t('#duceapp_wechat#duceapp_wechat_member')->update($_G['uid'], array('isregister' => 2, 'username' => $_G['username']));
			}
			showmessage($this->lang['password_reset'], $redirect);
		} else {
			$lang = lang('member/template');
			include_once template('duceapp_base:newpasswd');
			exit;
		}		
	}

	public function reacct($newusername, $uid = null, $return = false){
		global $_G, $uc_controls;

		if (!defined('UC_API')) {
			loaducenter();
		}

		$uid = $uid === null ? $_G['uid'] : $uid;
		$newusername = trim($newusername);

		$usernamelen = dstrlen($newusername);
		if ($usernamelen < 3) {
			if ($return) {
				return false;
			}
			showmessage('profile_username_tooshort');
		} elseif($usernamelen > 15) {
			if ($return) {
				return false;
			}
			showmessage('profile_username_toolong');
		}
		if (uc_get_user(addslashes($newusername)) || C::t('common_member')->fetch_uid_by_username($newusername) || C::t('common_member_archive')->fetch_uid_by_username($newusername)) {
			if ($_G['inajax']) {
				if ($return) {
					return false;
				}
				showmessage('profile_username_duplicate');
			} else {
				if ($return) {
					return false;
				}
				showmessage('register_activation');
			}
		}
		uc_user_edit(addslashes($_G['username']), null, $newpassword, null, 1);
		$uc_tables = array(
			'members' => array('id' => 'uid', 'name' => 'username'),
			'mergemembers' => array('id' => 'username', 'name' => 'username'),
			'protectedmembers' => array('id' => 'uid', 'name' => 'username'),
		);
		$uc_db = $uc_controls['user']->db;
		foreach ($uc_tables as $table => $conf) {
			$uc_db->query("UPDATE ".UC_DBTABLEPRE.$table." SET ".DB::field($conf['name'], $newusername)." WHERE ".DB::field($conf['id'], $_G['member'][$conf['id']]));
		}

		C::t('common_member')->update($uid, array('password' => md5(random(10)), 'username' => $newusername));
		$tables = array(
			'common_block' => array('id' => 'uid', 'name' => 'username'),
			'common_invite' => array('id' => 'fuid', 'name' => 'fusername'),
			'common_member' => array('id' => 'uid', 'name' => 'username'),
			'common_member_verify_info' => array('id' => 'uid', 'name' => 'username'),
			'common_mytask' => array('id' => 'uid', 'name' => 'username'),
			'common_report' => array('id' => 'uid', 'name' => 'username'),

			'forum_collection' => array('id' => 'uid', 'name' => 'username'),

			'forum_activityapply' => array('id' => 'uid', 'name' => 'username'),
			'forum_collectioncomment' => array('id' => 'uid', 'name' => 'username'),
			'forum_collectionfollow' => array('id' => 'uid', 'name' => 'username'),
			'forum_collectionteamworker' => array('id' => 'uid', 'name' => 'username'),
			'forum_debate' => array('id' => 'uid', 'name' => 'umpire'),
			'forum_forumrecommend' => array('id' => 'authorid', 'name' => 'author'),
			'forum_groupuser' => array('id' => 'uid', 'name' => 'username'),
			'forum_pollvoter' => array('id' => 'uid', 'name' => 'username'),
			'forum_post' => array('id' => 'authorid', 'name' => 'author'),
			'forum_postcomment' => array('id' => 'authorid', 'name' => 'author'),
			'forum_promotion' => array('id' => 'uid', 'name' => 'username'),
			'forum_ratelog' => array('id' => 'uid', 'name' => 'username'),
			'forum_thread' => array('id' => 'authorid', 'name' => 'author'),
			
			'home_album' => array('id' => 'uid', 'name' => 'username'),
			'home_blog' => array('id' => 'uid', 'name' => 'username'),
			'home_clickuser' => array('id' => 'uid', 'name' => 'username'),
			'home_comment' => array('id' => 'authorid', 'name' => 'author'),
			'home_docomment' => array('id' => 'uid', 'name' => 'username'),
			'home_doing' => array('id' => 'uid', 'name' => 'username'),
			'home_feed' => array('id' => 'uid', 'name' => 'username'),
			'home_feed_app' => array('id' => 'uid', 'name' => 'username'),
			'home_follow' => array('id' => 'uid', 'name' => 'username'),
			'home_follow_feed' => array('id' => 'uid', 'name' => 'username'),
			'home_follow_feed_archiver' => array('id' => 'uid', 'name' => 'username'),
			'home_friend' => array('id' => 'fuid', 'name' => 'fusername'),
			'home_friend_request' => array('id' => 'fuid', 'name' => 'fusername'),
			'home_notification' => array('id' => 'authorid', 'name' => 'author'),
			'home_pic' => array('id' => 'uid', 'name' => 'username'),
			'home_poke' => array('id' => 'fromuid', 'name' => 'fromusername'),
			'home_share' => array('id' => 'uid', 'name' => 'username'),
			'home_show' => array('id' => 'uid', 'name' => 'username'),
			'home_specialuser' => array('id' => 'uid', 'name' => 'username'),
			'home_visitor' => array('id' => 'vuid', 'name' => 'vusername'),

			'portal_article_title' => array('id' => 'uid', 'name' => 'username'),
			'portal_comment' => array('id' => 'uid', 'name' => 'username'),
			'portal_topic' => array('id' => 'uid', 'name' => 'username'),
			'portal_topic_pic' => array('id' => 'uid', 'name' => 'username') 
		);

		if (!C::t('common_member')->update($uid, array('username' => $newusername)) && isset($_G['setting']['membersplit'])){
			C::t('common_member_archive')->update($uid, array('username' => $newusername));
		}

		loadcache('posttableids');

		if ($_G['cache']['posttableids']) {
			foreach($_G['cache']['posttableids'] as $tableid) {
				$tables[getposttable($tableid)] = array('id' => 'authorid', 'name' => 'author');
			}
		}

		foreach($tables as $table => $conf) {
			DB::query("UPDATE ".DB::table($table)." SET `$conf[name]`='$newusername' WHERE `$conf[id]`='$get[uid]'");
		}

		DB::update('forum_collection', array('lastposter' => $newusername), array('lastposter' => $_G['username']));
		DB::update('forum_thread', array('lastposter' => $newusername), array('lastposter' => $_G['username']));
		DB::update('home_follow', array('fusername' => $newusername), array('followuid' => $uid));

		return true;
	}
}