<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-02-10
 * Version: 3.90629
 * Date: 2021-06-30 22:19:57
 * File: model_duceapp_bdmap.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class model_duceapp_bdmap
{
	public $apikey = '7M239ENQiGYyPuxYflMe5oAjvA3ErxiD';
	public $cityloc = array();
	public $charset = 'utf-8';

	public function __construct() {
		global $_G;
		if ($_G['duceapp_base']['bdapikey']) {
			$this->apikey = $_G['duceapp_base']['bdapikey'];
		}
	}

	public function getlocation($input, $ak = '') {
		try {
			if ($input['location']) {
				$res = $this->bygps($input['location'], $ak);
			} else {
				$res = $this->byip($input['ip'], $ak);
			}
		} catch (Exception $e) {
			$res = null;
		}
		return $res;
	}

	public function getcityloc($cityid) {
		return $this->cityloc[$cityid];
	}

	public function getcitylist($c = 'cn') {
		if (!$this->citylist[$c]) {
			$file = DISCUZ_ROOT.'./source/plugin/duceapp_base/include/city'.$c.'.json';
			$this->citylist[$c] = (array) json_decode(file_get_contents($file), true);
		}
		return $this->citylist[$c];
	}

	public function getcityid($input, $ak = '', $rc = false) {
		$cityid = '';
		$res = $this->getlocation($input, $ak);
		if (is_array($res) && $res['province']) {
			foreach($this->getcitylist() as $p => $clist) {
				$province = $clist[0]['province'];
				if (strpos($res['province'], $province) !== FALSE) {
					$res['p'] = $province;
					foreach($clist as $j => $item) {
						if (!$res['c'] && $item['city'] && strpos($res['city'], $item['city']) !== FALSE) {
							$cityid = $item['id'];
							$res['c'] = $item['city'];
							$res['name'] = $res['city'];
						}
						if ($res['district']) {
							if (!$item['cd'] && $item['district'] && strpos($res['district'], $item['district']) !== FALSE) {
								$cityid = $item['id'];
								$res['c'] = $item['city'];
								$res['name'] = $res['district'];
								break;
							}
						} elseif ($cityid) {
							break;
						}
					}
					if (!$cityid) {
						$cityid = $clist[0]['id'];
						$res = $this->getlocation(array('location' => $clist[0]['lat'].','.$clist[0]['lon']), $ak);	
						$res['c'] = $clist[0]['city'];
						$res['name'] = $res['city'];
					}
					break;
				}
			}
			if ($cityid) {
				$this->cityloc[$cityid] = $res;
			}
		}

		return $rc ? $res['c'] : ($cityid ? $cityid : '101010100');
	}

	public function async($url, $params = array(), $encode = true, $method = 'GET'){
		if ($method == 'GET'){
			$url = $url . '?' . http_build_query($params);
		}
		if(function_exists('curl_init') && function_exists('curl_exec')){
			$ch = curl_init();
			if ($method == 'GET'){
				$url = $encode ? $url : urldecode($url);
				curl_setopt($ch, CURLOPT_URL, $url);
			} else {
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
			}
			curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			$res = curl_exec($ch);
			curl_close($ch);
			return $res;
		} else {
			return dfsockopen($url, 0, $method == 'GET' ? '' : $params, '', FALSE, '', 30, TRUE, $encode ? 'URLENCODE' : '', FALSE);
		}
	}

	public function bycityid($cityid, $city_limit = false, $coord_type = 3) {
		if ($this->cityloc[$cityid]) {
			return $this->cityloc[$cityid];
		}
		$cdata = array();
		foreach($this->getcitylist() as $i => $citys) {
			foreach($citys as $j => $item) {
				if ($item['id'] == $cityid) {
					$cdata = $item;
					break;
				}
			}
		}
		if ($city_limit === 'check') {
			return $cdata ? $cityid : false;
		}
		if ($cdata) {
			$res = $this->getlocation(array('location' => $cdata['lat'].','.$cdata['lng']), $this->apikey);
			if (is_array($res) && $res['province']) {
				$res['p'] = $cdata['province'];
				$res['c'] = $cdata['city'];
				$res['name'] = $cdata['city'] == $cdata['district'] ? $res['city'] : $res['district'];
				$this->cityloc[$cityid] = $res;
			}
			/*$limit = $city_limit ? 'true' : 'false';
			$res = dfsockopen('http://api.map.baidu.com/place/v2/suggestion?q='.urlencode($cdata['district']).'&region='.urlencode($cdata['province']).'&city_limit='.$limit.'&output=json&coord_type='.$coord_type.'&ak='.$this->apikey);
			$data = json_decode($res, true);
			if ($data && $data['result']){
				foreach($data['result'] as $id => $result) {
					if ($result['province'] && $result['cityid'] != 0) {
						$this->cityloc[$cityid] = array(
							'address' => $result['name'],
							'province' => $result['province'],
							'city' => $result['city'],
							'district' => $result['district'],
							'city_code' => $result['cityid'],
							'lat' => $result['location']['lat'],
							'lng' => $result['location']['lng'],
							'name' => $cdata['city'] == $cdata['district'] ? $result['city'] : (strpos($result['district'], $cdata['district']) !== FALSE ? $result['district'] : $cdata['district']),
						);
						break;
					}
				}
			}*/
		}
		return $this->cityloc[$cityid];
	}

	public function byip($ip, $ak = ''){
		if (!filter_var($ip, FILTER_VALIDATE_IP)){
			throw new Exception('IP Address is Invalid');
			return null;
		}
		$params = array(
			'ak' => $ak ? $ak : $this->apikey,
			'ip' => $ip,
			'coor' => 'bd09ll'
		);
		$res = $this->async('http://api.map.baidu.com/location/ip', $params);
		$data = json_decode($res, true);

		if ($data['status'] != 0){
			throw new Exception(diconv($data['message'], $this->charset));
		}
		return array(
			'address' => $data['content']['address'],
			'province' => $data['content']['address_detail']['province'],
			'city' => $data['content']['address_detail']['city'],
			'district' => $data['content']['address_detail']['district'],
			'street' => $data['content']['address_detail']['street'],
			'street_number' => $data['content']['address_detail']['street_number'],
			'city_code' => $data['content']['address_detail']['city_code'],
			'lat' => $data['content']['point']['y'],
			'lng' => $data['content']['point']['x'],
		);
	}

	public function bygps($location, $ak = '') {
		$params = array(
			'coordtype' => 'wgs84ll',
			'location' => $location,
			'ak' => $ak ? $ak : $this->apikey,
			'output' => 'json',
			'pois' => 0
		);
		$res = $this->async('http://api.map.baidu.com/geocoder/v2/', $params, false);
		$data = json_decode($res, true);

		if ($data['status'] != 0){
			throw new Exception(diconv($data['message'], $this->charset));
		}
		return array(
			'address' => $data['result']['formatted_address'],
			'province' => $data['result']['addressComponent']['province'],
			'city' => $data['result']['addressComponent']['city'],
			'district' => $data['result']['addressComponent']['district'],
			'street' => $data['result']['addressComponent']['street'],
			'street_number' => $data['result']['addressComponent']['street_number'],
			'city_code' => $data['result']['cityCode'],
			'lat' => $data['result']['location']['lat'],
			'lng' => $data['result']['location']['lng'],
		);
	}	
}