<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-10-07
 * Version: 3.10328
 * Date: 2021-06-30 22:32:49
 * File: model_duceapp_helper.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class model_duceapp_helper
{
	public function messagefunc($hscript, $script, $plugin_module, $method, $adminid = 0) {
		global $_G;
		if (strpos($plugin_module, '/')) {
			$class = dirname($plugin_module);
		} else {
			$class = $plugin_module;
			$plugin_module = $class.'/'.$class;
		}
		$msghook = $_G['setting'][HOOKTYPE][$hscript][$script];
		$msghook['module'][$class] = $plugin_module;
		$msghook['adminid'][$class] = $adminid;
		$msghook['messagefuncs'][$script][] = array($class, $method);
		$_G['setting'][HOOKTYPE][$hscript][$script] = $msghook;
	}

	public function pluginmenu($hook, $plugin_module, $method, $adminid = 0) {
		global $_G;
		list($plugindir) = explode(':', $plugin_module);
		$method = array_merge($_G['setting']['plugins'][$hook][$plugin_module] ? $_G['setting']['plugins'][$hook][$plugin_module] : array(
			'adminid' => $adminid,
			'name' => '',
			'url' => $method && $method['isDefault'] ? '' : 'plugin.php?id='.$plugindir,
			'directory' => $plugindir.'/',
		), $method);
		$_G['setting']['plugins'][$hook][$plugin_module] = $method;
	}

	public function get_seosetting($page, $data = array(), $defset = array(), $return = false) {
		global $_G, $navtitle, $metadescription, $metakeywords;
		if ($_G['inajax']) {
			return null;
		}
		$seoarray = get_seosetting($page, $data, $defset);
		if ($return) {
			return $seoarray;
		}
		list($navtitle, $metadescription, $metakeywords) = $seoarray;
	}

	public function checkreferer() {
		$referer = parse_url($_SERVER['HTTP_REFERER']);
		$serverhost = $_SERVER['HTTP_HOST'];
		if (($pos = strpos($serverhost, ':')) !== false) {
			$serverhost = substr($serverhost, 0, $pos);
		}
		if ($referer['host'] != $serverhost) {
			exit();
		}
	}

	public function errormsg($message, $values = array(), $params = null) {
		global $_G;
		$values = $values ? $values : array();
		$params = $params !== null ? $params : array('showdialog' => 1, 'showmsg' => 1, 'closetime' => $closetime);
		$closetime = empty($_G['duceapp_base']['showalert']) ? 1 : 0;
		if (defined('IN_MAGMOBILE_API')) {
			$vars = explode(':', $message);
			if(count($vars) == 2) {
				$message = lang('plugin/'.$vars[0], $vars[1], $values);
			} else {
				$message = lang('message', $message, $values);
			}
			if ($_G['messageparam']) {
			    $_G['messageparam'] = array($message, $params['urlforward'], $values, $params);
			    $_G['hookscriptmessage'] = $message;
		    }
			error($message);
		}
		$values['rd'] = 1;
		showmessage($message, $params['urlforward'], $values, $params);
	}

	public function ajaxoutput($content = '') {
		global $_G;
		include_once template('common/header_ajax');
		echo $content;
		include_once template('common/footer_ajax');
	}
}