<?php

	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}

class model_duceapp_imageblur
{
	public function gaussian_blur($_arg_0, $_arg_1, $_arg_2, $_arg_3 = 6)
	{
		$_var_5 = $this->image_create_from_ext($_arg_0);
		$_var_6 = @getimagesize($_arg_0);
		if ($_var_6[0] && $_var_6[0] < 640) {
			$_arg_3 = $_var_6[0] / 640 * $_arg_3;
		}
		$_var_7 = $this->blur($_var_5, $_arg_3);
		$_var_8 = pathinfo($_arg_0);
		$_var_9 = $_var_8["basename"];
		$_var_10 = $_var_8["dirname"];
		$_var_11 = $_var_8["extension"];
		$_arg_2 = $_arg_2 ? $_arg_2 : $_var_9;
		$_arg_1 = $_arg_1 ? $_arg_1 : $_var_10;
		$_var_12 = $_arg_1 . "/" . $_arg_2;
		if ($_var_6[2] == 1) {
			imagegif($_var_7, $_var_12);
		} elseif ($_var_6[2] == 2) {
			imagejpeg($_var_7, $_var_12);
		} elseif ($_var_6[2] == 3) {
			imagepng($_var_7, $_var_12);
		} else {
			return false;
		}
		imagedestroy($_var_7);
		return $_var_12;
	}
	public function blur($_arg_0, $_arg_1 = 6)
	{
		$_arg_1 = round($_arg_1);
		$_var_3 = imagesx($_arg_0);
		$_var_4 = imagesy($_arg_0);
		$_var_5 = ceil($_var_3 * pow((double) "0.5", $_arg_1));
		$_var_6 = ceil($_var_4 * pow((double) "0.5", $_arg_1));
		$_var_7 = $_arg_0;
		$_var_8 = $_var_3;
		$_var_9 = $_var_4;
		$_var_10 = 0;
		while ($_var_10 < $_arg_1) {
			$_var_11 = $_var_5 * pow(2, $_var_10);
			$_var_12 = $_var_6 * pow(2, $_var_10);
			$_var_13 = imagecreatetruecolor($_var_11, $_var_12);
			imagecopyresized($_var_13, $_var_7, 0, 0, 0, 0, $_var_11, $_var_12, $_var_8, $_var_9);
			imagefilter($_var_13, IMG_FILTER_GAUSSIAN_BLUR);
			$_var_7 = $_var_13;
			$_var_8 = $_var_11;
			$_var_9 = $_var_12;
			$_var_10 = $_var_10 + 1;
		}
		imagecopyresized($_arg_0, $_var_13, 0, 0, 0, 0, $_var_3, $_var_4, $_var_11, $_var_12);
		imagefilter($_arg_0, IMG_FILTER_GAUSSIAN_BLUR);
		imagedestroy($_var_7);
		return $_arg_0;
	}
	public function image_create_from_ext($_arg_0)
	{
		$_var_2 = @getimagesize($_arg_0);
		$_var_3 = NULL;
		if ($_var_2[2] == 1) {
			$_var_3 = imagecreatefromgif($_arg_0);
		} elseif ($_var_2[2] == 2) {
			$_var_3 = imagecreatefromjpeg($_arg_0);
		} elseif ($_var_2[2] == 3) {
			$_var_3 = imagecreatefrompng($_arg_0);
		}
		return $_var_3;
	}
}