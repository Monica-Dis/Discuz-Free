<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-02-10
 * Version: 3.10309
 * Date: 2021-06-30 22:19:57
 * File: model_duceapp_weather.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class model_duceapp_weather
{
	public $days_json_url = 'https://wthrcdn.etouch.cn/weather_mini?citykey=';
	public $days_xml_url = 'https://wthrcdn.etouch.cn/WeatherApi?citykey=';
	public $tianqiapi_url = 'https://www.tianqiapi.com/api/?version=v1&';
	public $sk_url = 'http://www.weather.com.cn/data/sk/'; //cityid.html
	public $timeoffset = 8;
	public $out_charset = 'UTF-8';
	public $apikey;
	public $cachedir = 'data/duceapp/weather/';

	public function __construct($apikey = '', $appid = '', $appsecret = '') {
		global $_G;
		if (!$appid || !$appsecret) {
			$appid = $_G['duceapp_base']['tianqiapi_appid'];
			$appsecret = $_G['duceapp_base']['tianqiapi_appsecret'];
		}
		$this->apikey = $apikey ? $apikey : $_G['duceapp_base']['bdapikey'];
		$this->tianqiapi_url .= 'appid='.$appid.'&appsecret='.$appsecret.'&';
	}

	public function getcityid($clientip, $location = '', $getname = false) {
		return C::m('#duceapp_base#duceapp_bdmap')->getcityid(array('location' => $location ? $location : $_GET['location'], 'ip' => $clientip), $this->apikey, $getname);
	}

	public function getinfo($cityid, $alarm = false) {		
		$filesock = C::m('#duceapp_base#duceapp_filesock')->init(FALSE, FALSE, 'gzip');
		$weather = array();
		if (@include($cachefile = DISCUZ_ROOT.$this->cachedir.$cityid.'.php')) {
			if (($weather && $weather['cachelife1'] && $weather['cachelife1'] > TIMESTAMP) || !$weather['data']) {
				$weather['nowtime'] = $this->dgmdate(TIMESTAMP, 'H:i');
				if ($weather['cachelife2'] < TIMESTAMP || !$weather['data']) {
					$res2 = json_decode($filesock->open($this->tianqiapi_url.'cityid='.$cityid), true);
					$weather['alarm']['type'] = $res2['data'][0]['alarm']['alarm_type'];
					$weather['alarm']['level'] = $res2['data'][0]['alarm']['alarm_level'];
					$weather['alarm']['content'] = $res2['data'][0]['alarm']['alarm_content'];
					$weather['air']['quality'] = $res2['data'][0]['air'];
					$weather['air']['level'] = $res2['data'][0]['air_level'];
					$weather['air']['tips'] = $res2['data'][0]['air_tips'];
					$weather['updatetime'] = $res2['update_time'];
					$weather['data'] = $res2['data'];
					$weather['cachelife2'] = $this->lifetime($weather['updatetime']);
					$this->writetocache($cachefile, $weather);
				}
				//return $weather;
			}
		}
		try{
			$res1 = $filesock->open($this->days_xml_url.$cityid);
			if ($weather && $weather['cachelife2'] && $weather['cachelife2'] > TIMESTAMP) {
				$res2 = $weather;
			} else {
				$res2 = json_decode($filesock->open($this->tianqiapi_url.'cityid='.$cityid), true);
			}
		} catch (Exception $e) {
			return false;
		}
		if ($res1) {
			$res1 = simplexml_load_string(utf8_encode($res1));
			$res1 = $this->simplexml($res1);
			$weather['cityid'] = $cityid;
			$weather['city'] = $res2['city'] ? $res2['city'] : $res1['city'];
			$weather['uptime'] = $res1['updatetime'];
			$weather['nowtime'] = $this->dgmdate(TIMESTAMP, 'H:i');
			$weather['weath'] = '';
			$weather['temp'] = $res1['wendu'];
			$weather['wind'] = $this->getwind($res1['fengxiang'], $res1['fengli']);
			$weather['sunrise'] = $res1['sunrise_1'];
			$weather['sunset'] = $res1['sunset_1'];
			$weather['alarm'] = array(
				'img' => '',
				'type' => $res2['data'][0]['alarm']['alarm_type'],
				'level' => $res2['data'][0]['alarm']['alarm_level'],
				'content' => $res2['data'][0]['alarm']['alarm_content'],
			);
			$weather['air'] = array(
				'quality' => $res2['data'][0]['air'],
				'humidity' => $res1['shidu'] ? $res1['shidu'] : $res2['data'][0]['humidity'].'%',
				'level' => $res2['data'][0]['air_level'],
				'tips' => $res2['data'][0]['air_tips'],
				'color' => '',
			);
			if ($alarm && $res1['alarm'] && is_string($res1['alarm']['imgUrl'])) {
				$weather['alarm']['img'] = $this->grabImage($res1['alarm']['imgUrl']);
			}
			$weather['location'] = C::m('#duceapp_base#duceapp_bdmap')->bycityid($cityid);
			$weather['yesterday'] = $res1['yesterday'];
			$weather['forecast'] = $res1['forecast']['weather'];
			$weather['zhishus'] = $res1['zhishus']['zhishu'];
		}
		$weather['updatetime'] = $res2['updatetime'] ? $res2['updatetime'] : $res2['update_time'];
		$weather['data'] = $res2['data'];		

		$weather['cachelife1'] = $this->lifetime($weather['uptime']);
		$weather['cachelife2'] = $this->lifetime($weather['updatetime']);

		$this->writetocache($cachefile, $weather);
	
		return $weather;
	}

	public function writetocache($cachefile, $weather) {
		if ($fp = @fopen($cachefile, 'wb')) {
			include_once libfile('function/cache');
			$cachedata = '$weather = '.arrayeval($weather).';';
			fwrite($fp, "<?php\n//Discuz! cache file, DO NOT modify me!\n//Identify: ".md5($cachefile.$cachedata.$_G['config']['security']['authkey'])."\n\n$cachedata?>");
			fclose($fp);
		}
	}

	public function lifetime($time) {
		$updatetime = strtotime($time);
		if ($updatetime > TIMESTAMP) {
			$updatetime -= 86400;
		}
		$hour = ceil((TIMESTAMP - $updatetime)/3600);
		return $updatetime + $hour * 3600;
	}

	public function simplexml($xml, $resdata = array()) {
		foreach($xml->children() as $key => $value) {
			if ($value->children()) {
				if ($key == 'weather' || $key == 'zhishu') {
					$resdata[$key][] = $this->simplexml($value);
				} else {
					$resdata[$key] = $this->simplexml($value);
				}
			} else {
				$resdata[$key] = utf8_decode((string)$value);
			}
		}
		return $resdata;
	}

	public function grabImage(&$src){
		global $_G;
		$targetdir = DISCUZ_ROOT.$this->cachedir;
		$filename = basename($src);
		$file = $targetdir.$filename;
		$fileurl = $_G['siteurl'].$this->cachedir.$filename;
		if (is_file($file)){
			return ($src = $fileurl);
		}		
		if (in_array(strrchr($filename,'.'), array('.png','.gif','.jpg'))){
			dmkdir($targetdir);
			if(($img = dfsockopen($src)) && ($fp = @fopen($file, 'a'))){
				fwrite($fp, $img);
				fclose($fp);
				return ($src = $fileurl);
			}
		}
		return $src;
	}

	public function dgmdate($timestamp, $format){
		return gmdate($format, $timestamp + $this->timeoffset*3600);
	}

	public function dayline($cityid, $templateid = '') {
		global $_G;
		
		$weather = $this->getinfo($cityid);
		if (!$weather) {
			exit;
		}

		if ($weather['city']) {
			$forecast = $weather['forecast'][0];
			$yesterday = $weather['yesterday'];
			$today = $this->getnumber($forecast['date']);
			$timeday = $this->dgmdate(TIMESTAMP, 'd');
			$timestamp = TIMESTAMP - ($today > $timeday ? 86400 : 0);
			$year = $this->dgmdate($timestamp, 'Y');
			$month = $this->dgmdate($timestamp, 'n');
			$times = gmmktime(0, 0, 0, $month, $today, $year);
			$weather['date'] = $this->getday($times);
			
			$weather['air']['color'] = $this->getaqicolor($weather['air']['quality']);

			$night = false;
			if ($weather['nowtime'] >= $weather['sunset'] && !$this->isdusk($weather['sunset'])) {
				$weather['weath'] = $forecast['night']['type'];
				$weather['win'] = $forecast['night']['fengxiang'];
				$weather['wind_io'] = $this->getfenx($weather['win']);
				$weather['wind'] = $this->getwind($forecast['night']['fengxiang'], $forecast['night']['fengli']);
				$night = true;
			} elseif ($weather['nowtime'] <= $weather['sunrise']) {
				if ($today == $this->dgmdate(TIMESTAMP, 'd') - 0){
					$weather['weath'] = $yesterday ? $yesterday['night_1']['type_1'] : $forecast['day']['type'];
					$weather['win'] = $yesterday ? $yesterday['night_1']['fx_1'] : $forecast['day']['fengxiang'];
					$weather['wind_io'] = $this->getfenx($weather['win']);
					$weather['wind'] = $yesterday ? $this->getwind($yesterday['night_1']['fx_1'], $yesterday['night_1']['fl_1']) : $this->getwind($forecast['day']['fengxiang'], $forecast['day']['fengli']);
				} else {
					$weather['weath'] = $forecast['night']['type'];
					$weather['win'] = $forecast['night']['fengxiang'];
					$weather['wind_io'] = $this->getfenx($weather['win']);
					$weather['wind'] = $this->getwind($forecast['night']['fengxiang'], $forecast['night']['fengli']);
				}
				$night = true;
			} else {
				$weather['weath'] = $forecast['day']['type'];
				$weather['win'] = $forecast['day']['fengxiang'];
				$weather['wind_io'] = $this->getfenx($weather['win']);
				$weather['wind'] = $this->getwind($forecast['day']['fengxiang'], $forecast['day']['fengli']);
			}
			$weather['icon'] = $this->geticon($weather['weath'], $night);
			$weather['tem1'] = $this->getnumber($forecast['high']);
			$weather['tem2'] = $this->getnumber($forecast['low']);
			if ($weather['temp'] > $weather['high']) {
				$weather['high'] = $weather['temp'];
			}
			if ($weather['temp'] < $weather['low']) {
				$weather['low'] = $weather['temp'];
			}

			$from = in_array($_GET['hookid'], array(2, 3, 5)) ? 'float' : $_GET['from'];
			if ($from == 'switchtag' || $from == 'float') {
				$weather['week'] = $this->getweek($times, $from == 'float');
			} else {
				$weather['week'] = substr($this->getnumber($forecast['date']), 3);
				switch($weather['week']){
					case '星期六': $weatherinfo['week'] = '<em class="saturday">'.$weather['week'].'</em>';break;
					case '星期天': $weatherinfo['week'] = '<em class="sunday">'.$weather['week'].'</em>';break;
				}
			}
			if ($_GET['hookid'] == 5 || $_GET['hookid'] == 6) {
				$weather['lunar'] = C::m('#duceapp_base#duceapp_lunar')->convertSolarToLunar($year, $month, $today);
			}
			$weather['bgid'] = $this->getchangebgid($weather['icon'], $arrempty, 1, $this->isdusk($weather['sunset']));
		}
		if ($templateid) {
			include template($templateid);
			$this->output();
		} else {
			return $weather;
		}
	}

	public function daysmenu($cityid, $templateid = '', $hour24 = false) {
		global $_G, $navtitle, $metadescription, $metakeywords;
		
		$weather = $this->getinfo($cityid, true);
		if (!$weather) {
			exit;
		}

		$weather['bgid'] = array();
		if ($weather['city']) {
			$today = $this->getnumber($weather['forecast'][0]['date']);
			$yesterday = $weather['yesterday'];
			$timeday = $this->dgmdate(TIMESTAMP, 'd');
			$timestamp = TIMESTAMP - ($today > $timeday ? 86400 : 0);
			$year = $this->dgmdate($timestamp, 'Y');
			$month = $this->dgmdate($timestamp, 'n');
			$times = gmmktime(0, 0, 0, $month, $today, $year);
			$isdusk = $this->isdusk($weather['sunset']);
			$weather['air']['color'] = $this->getaqicolor($weather['air']['quality']);
			
			foreach($weather['forecast'] as $id => $item){
				$forecast = $weather['forecast'][$id];
				$forecast['high'] = $this->getnumber($item['high']);
				$forecast['low'] = $this->getnumber($item['low']);
				if (!$id){
					if ($weather['nowtime'] >= $weather['sunset'] && !$isdusk) {
						$weather['weath'] = $item['night']['type'];
						$forecast['weath'] = $item['night']['type'];
						$forecast['win'] = $item['night']['fengxiang'];
						$forecast['wind_io'] = $this->getfenx($forecast['win']);
						$forecast['wind'] = $this->getwind($forecast['win'], $item['night']['fengli']);
						$forecast['icon'] = $this->geticon($forecast['weath'], true);
						$bgclassid1 = in_array($forecast['icon'], array(2,6)) ? 2 : 3;
						$bgclassid2 = $bgclassid1 == 2 ? 2 : 1;
					} elseif ($weather['nowtime'] <= $weather['sunrise']) {
						if ($today == $this->dgmdate(TIMESTAMP, 'd') - 0) {
							$yt = $yesterday ? $yesterday['night_1']['type_1'] : $item['day']['type'];
							$forecast['weath'] = $weather['weath'] = $yt;
							$forecast['win'] = $yesterday ? $yesterday['night_1']['fx_1'] : $item['day']['fengxiang'];
							$forecast['wind_io'] = $this->getfenx($forecast['win']);
							$forecast['wind'] = $yesterday ? $this->getwind($yesterday['night_1']['fx_1'], $yesterday['night_1']['fl_1']) : $this->getwind($item['day']['fengxiang'], $item['day']['fengli']);
						} else {
							$forecast['weath'] = $weather['weath'] = $item['night']['type'];
							$forecast['win'] = $item['night']['fengxiang'];
							$forecast['wind_io'] = $this->getfenx($forecast['win']);
							$forecast['wind'] = $this->getwind($item['night']['fengxiang'], $item['night']['fengli']);
						}
						$forecast['icon'] = $this->geticon($forecast['weath'], true);
					} else {
						$weather['weath'] = $item['day']['type'];
						$forecast['weath'] = $item['night']['type'] == $item['day']['type'] ? $item['day']['type'] : $item['day']['type'].'转'.$item['night']['type'];
						$forecast['win'] = $item['day']['fengxiang'];
						$forecast['wind_io'] = $this->getfenx($forecast['win']);
						$forecast['wind'] = $this->getwind($item['day']['fengxiang'], $item['day']['fengli']);
						$forecast['icon'] = $this->geticon($item['day']['type']);
					}					
					if ($weather['temp'] > $forecast['high']) {
						$forecast['high'] = $weather['temp'];
					}
					if ($weather['temp'] < $forecast['low']) {
						$forecast['low'] = $weather['temp'];
					}
				} else {
					$forecast['icon'] = $this->geticon($item['day']['type']);
					$forecast['weath'] = $item['night']['type'] == $item['day']['type'] ? $item['day']['type'] : $item['day']['type'].'转'.$item['night']['type'];
					$forecast['win'] = $item['day']['fengxiang'];
					$forecast['wind_io'] = $this->getfenx($forecast['win']);
					$forecast['wind'] = $this->getwind($item['day']['fengxiang'], $item['day']['fengli']);
				}
				$forecast['bgid'] = $this->getchangebgid($forecast['icon'], $weather['bgid'], $id + 1, $isdusk);
				$forecast['week'] = $this->getweek($times + $id*86400);
				$forecast['date'] = $this->getday($times + $id*86400);

				$weather['forecast'][$id] = $forecast; //b
			}
			$weather['lunar'] = C::m('#duceapp_base#duceapp_lunar')->convertSolarToLunar($year, $month, $today);
			
			if ($hour24) {
				$weather['hour24'] = $this->get24hour($weather);
			}
		}
		if ($templateid) {
			if (empty($_G['inajax'])) {
				C::m('#duceapp_base#duceapp_helper')->get_seosetting('forum', array(), array('seotitle' => $weather['city'].'天气'));
			}
			include template($templateid);
			$this->output();
		} else {
			return $weather;
		}
	}

	public function get24hour($weather) {
		if (!$weather['data']) {
			$filesock = C::m('#duceapp_base#duceapp_filesock')->init();
			$res = json_decode($filesock->open($this->tianqiapi_url.'cityid='.$weather['cityid'].'&city='.$weather['city']), true);
			$weather['updatetime'] = $res['updatetime'];
			$weather['data'] = $res['data'];
		}
		$hours = array();
		if ($weather) {
			//list($date) = explode(' ', $weather['updatetime']);
			//list($year, $month, $day) = explode('-', $date);
			$j = $k = $i = 0;
			$prev = array();
			foreach($weather['data'] as $a => $data) {
				list($year, $month, $day) = explode('-', $data['date']);
				$h = $s = 0;
				foreach($data['hours'] as $b => $item) {					
					preg_match('/([\d]+)时/', $item['hours'], $m);
					if ($m[1] < $h) {
						$s = 86400;
						$h = 0;
					} else {
						$h = $m[1];
					}
					if ($hours[$m[1]]){
						continue;
					}
					if (!$j) {
						$times = strtotime($data['date'].' '.$m[1].':00:00') + $s;
					}
					if ($j || TIMESTAMP < $times) {
						if (!$prev) {
							$prev = $i ? $data['hours'][$i-1] : ($k ? array_pop($weather['data'][$k-1]) : false);
						}						
						$item['day'] = $day;
						$item['time'] = $m[1];
						$item['strtime'] = $m[1].':00';
						$item['tem'] = intval($item['tem']);
						$item['win_io'] = $this->getfenx($item['win']);
						$item['wind'] = $this->getwind($item['win'], $item['win_speed'], 1);
						$hours[$m[1]] = $item;
						$j++;
					}
					$i++;
					if ($j > 23) break;
				}
				$k++;
				if ($j > 23) break;
			}
			$hours = array_values($hours);
			if ($prev) {
				list($year, $month, $day) = explode('-', $prev['date']);
				preg_match('/([\d]+)时/', $prev['hours'], $m);
				$item['wea'] = $weather['weath'];
				$item['day'] = $day;
				$item['time'] = $m[1];
				$item['strtime'] = '现在';
				$item['tem'] = $weather['temp'];
				$item['win_io'] = $this->getfenx($item['win']);
				$item['wind'] = $this->getwind($item['win'], $item['win_speed'], 1);
				array_unshift($hours, $item);
			}
		}
		return $hours;
	}

	public function getchangebgid($icon, &$weatherbg, $i, $isdusk){
		switch (intval($icon)){
			case 1: case 2: case 17: case 18: $bgid = $i == 1 && $isdusk ? 5 : 1; break;
			case 5: case 6: $bgid = 2; break;
			case 13: case 14: $bgid = 4; break;
			default: $bgid = 3;
		}
		if (!in_array($bgid, $weatherbg)) {
			$weatherbg[$i] = $bgid;
		}
		return $bgid;
	}

	public function getaqicolor($air) {
		if ($air <= 50) {
			return '#BBEA5D';
		} elseif ($air <= 100) {
			return '#AFDB00';
		} elseif ($air <= 150) {
			return '#FF9900';
		} elseif ($air <= 200) {
			return '#F55345';
		} elseif ($air <= 300) {
			return '#CD4971';
		} elseif ($air > 300) {
			return '#922E5D';
		}
	}

	public function getwind($value, $fl, $ret = false) {
		if ($value == '无持续风向') {
			$value = $this->getfenji($fl);
		}
		return $ret ? $value : str_replace(array('微风级', '0级'), array('微风', '无风'), $value.$fl);
	}

	public function getfenx($value) {
		if ($value == '东风') {
			return 1;
		} elseif ($value == '东南风') {
			return 2;
		} elseif ($value == '南风') {
			return 3;
		} elseif ($value == '西南风') {
			return 4;
		} elseif ($value == '西风') {
			return 5;
		} elseif ($value == '西北风') {
			return 6;
		} elseif ($value == '北风') {
			return 7;
		} elseif ($value == '东北风') {
			return 8;
		} 
		return 0;
	}

	public function getfenji($fl) {
		preg_match('/([\d]+)?(\<|\-)?([\d]+)/', $fl, $m);
		if ($m[3] >= 12) {
			$fl = '台风';
		} elseif ($m[3] > 10) {
			$fl = '狂风';
		} elseif ($m[3] > 8) {
			$fl = '大风';
		} elseif ($m[3] > 6) {
			$fl = '强风';
		} elseif ($m[3] > 3) {
			$fl = '和风';
		} elseif ($m[3] > 0) {
			$fl = '微风';
		}
		return $fl;
	}

	public function getnumber($value) {
		return preg_replace('/[^\-0-9]/', '', $value);
	}

	public function getday($times) {
		return $this->dgmdate($times, 'm月d日');
	}

	public function getweek($times, $j = false){
		switch($this->dgmdate($times, 'w')){
			case 0: return $j ? '<em class="sunday">周日</em>' : '<em class="sunday">星期日</em>';
			case 1: return $j ? '周一' : '星期一';
			case 2: return $j ? '周二' : '星期二';
			case 3: return $j ? '周三' : '星期三';
			case 4: return $j ? '周四' : '星期四';
			case 5: return $j ? '周五' : '星期五';
			case 6: return $j ? '<em class="sunday">周六</em>' : '<em class="saturday">星期六</em>';
		}
	}

	public function geticon($weath, $night = false){
		switch($weath){
			case '晴': $iconid = $night ? 5 : 1; break;
			case '多云': $iconid = $night ? 6 : 2; break;
			case '阴': $iconid = 3; break;
			case '雾': $iconid = 4; break;
			case '小雨': case '阵雨': $iconid = 7; break;
			case '小到中雨': case '中雨': $iconid = 8; break;
			case '中到大雨': case '大雨': $iconid = 9; break;
			case '大到暴雨': case '暴雨': $iconid = 10; break;
			case '暴雨到大暴雨': case '大暴雨': $iconid = 11; break;
			case '大暴雨到特大暴雨': case '特大暴雨': $iconid = 12; break;
			case '雷阵雨': $iconid = 13; break;
			case '雷阵雨伴有冰雹': $iconid = 14; break;
			case '雨夹雪': $iconid = 15; break;
			case '小雪': case '阵雪': $iconid = 16; break;
			case '小到中雪': case '中雪': $iconid = 17; break;
			case '中到大雪': case '大雪': $iconid = 18; break;
			case '大到暴雪': case '暴雪': $iconid = 19; break;
			case '浮尘': $iconid = 20; break;
			case '扬沙': $iconid = 21; break;
			case '沙尘暴': $iconid = 22; break;
			case '强沙尘暴': $iconid = 23; break;
			case '霾': case '雾霾': $iconid = 24; break;
			default: $iconid = 0;
		}
		return $iconid;
	}

	public function wendufont($wendu) {
		$wendu .= '';
		$str = '';
		for ($i = 0; $i < strlen($wendu); $i++) {
			if (preg_match('/[0-9]/', $s = substr($wendu, $i, 1))) {
				$str .= '&#xe93'.$s.';';
			} elseif($s == '-') {
				$str .= '&#xe93d;';
			}
		} return $str;
	}

	public function isdusk($time){
		$sunsettime = strtotime($time);
		return TIMESTAMP > $sunsettime - 900 && TIMESTAMP < $sunsettime + 2700 ? true : false;
	}	

	public function output($out_charset = null) {
		global $_G;		
		
		$contents = ob_get_contents();
		ob_end_clean();

		dheader("Expires: -1");
		dheader("Cache-Control: no-store, private, post-check=0, pre-check=0, max-age=0", FALSE);
		dheader("Pragma: no-cache");
		dheader("Content-Type: text/html; charset=".($out_charset ? $out_charset : $this->out_charset));

		$_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
		if ($contents && $_G['config']['output']['language'] == 'zh_tw') {
			$contents = C::m('#duceapp_base#duceapp_translang')->c2t($contents);
		}
		echo $contents; exit;
	}
}