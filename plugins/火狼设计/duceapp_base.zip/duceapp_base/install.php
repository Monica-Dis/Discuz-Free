<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-02-10
 * Version: 3.01001
 * Date: 2021-06-30 22:19:57
 * File: install.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

define('DUCEAPP_INSTALL', 1);
define('DUCEAPP_ROOT', dirname(__FILE__).'/');
define('DUCEAPP_IDENT', $operation == 'plugininstall' ? $_GET['dir'] : $dir);
define('DUCEAPP_DIRURL', 'source/plugin/'.DUCEAPP_IDENT.'/');
define('DUCEAPP_CPURL', ADMINSCRIPT.'?action=plugins&operation='.($operation == 'enable' ? 'enable&pluginid='.$_GET['pluginid'].($_GET['pmod'] ? '&pmod='.$_GET['pmod'] : '') : 'plugininstall&&pluginid='.$pluginid.'&dir='.$dir.'&installtype='.$installtype));
define('DUCEAPP_DATAURL', 'data/'.str_replace('_', '/', DUCEAPP_IDENT).'/');

include_once libfile('class/duceapp_installcore', 'plugin/duceapp_base');
include_once DUCEAPP_ROOT.'install/index.php';

if ($operation == 'enable' && $_GET['pmod']) {
	dheader('location:'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['pluginid'].'&pmod='.$_GET['pmod']);
}

$finish = TRUE;