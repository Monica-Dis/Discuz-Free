<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-02-10
 * Version: 3.01001
 * Date: 2021-06-30 22:19:57
 * File: index.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

class duceapp_install extends duceapp_installcore
{
	public $tables = array('duceapp_member');
	public $steps = array('table');

	public function __construct() {
		if ($this->init() !== true) {
			exit;
		}
	}
}

new duceapp_install;