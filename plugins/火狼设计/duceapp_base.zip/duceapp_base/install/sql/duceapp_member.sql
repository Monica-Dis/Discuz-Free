DROP TABLE IF EXISTS `cdb_duceapp_member`;
CREATE TABLE IF NOT EXISTS `cdb_duceapp_member` (
  `uid` mediumint(8) unsigned NOT NULL,
  `duceapp` tinyint(1) DEFAULT '0',
  `stylecolorid` smallint(5) NOT NULL DEFAULT '-1',
  `backdrop` varchar(255) DEFAULT NULL,
  `weatherid` varchar(20) DEFAULT NULL,
  `nickname` varchar(64) DEFAULT '',
  `intcode` char(5) DEFAULT '',
  `cellphone` varchar(32) DEFAULT '',
  `isregister` tinyint(1) DEFAULT '0',
  `bindtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`)
);