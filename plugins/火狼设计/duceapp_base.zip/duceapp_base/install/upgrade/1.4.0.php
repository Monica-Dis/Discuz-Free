<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2020-02-24
 * Version: 3.01001
 * Date: 2021-06-30 22:19:57
 * File: 1.4.0.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$tb_member = DB::result_first("SHOW TABLES LIKE '".DB::table('duceapp_member')."'");
if (!$tb_member && is_file(DUCEAPP_ROOT.'install/sql/duceapp_member.sql')) {
	$sqldata = @implode('', file(DUCEAPP_ROOT.'install/sql/duceapp_member.sql'));
	runquery($sqldata);
}