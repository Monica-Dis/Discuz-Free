<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2020-10-23
 * Version: 3.01024
 * Date: 2021-06-30 22:19:57
 * File: 1.7.2.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

dmkdir(DISCUZ_ROOT.'./source/admincp/menu/');
@copy(DUCEAPP_ROOT.'./install/menu_duceapp.php', DISCUZ_ROOT.'./source/admincp/menu/menu_duceapp.php');