<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2020-01-16
 * Version: 3.01001
 * Date: 2021-06-30 22:19:57
 * File: 1.3.3.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$field = C::t('#duceapp_base#duceapp_member')->fetch_all_field();

if (!$field['intcode']) {
	DB::query("ALTER TABLE %t ADD `intcode` char(5) DEFAULT '' AFTER `nickname`", array('duceapp_member'));
}