<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-12-02
 * Version: 3.01001
 * Date: 2021-06-30 22:19:57
 * File: 1.3.1.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$field = C::t('#duceapp_base#duceapp_member')->fetch_all_field();

if ($field['mphone']) {
	DB::query("ALTER TABLE %t CHANGE `mphone` `duceapp` tinyint(1) DEFAULT '0'", array('duceapp_member'));
}
if ($field['mregister']) {
	DB::query("ALTER TABLE %t DROP `mregister`", array('duceapp_member'));
}
if ($field['mstatus']) {
	DB::query("ALTER TABLE %t DROP `mstatus`", array('duceapp_member'));
}

if (!$field['nickname']) {
	DB::query("ALTER TABLE %t ADD `nickname` varchar(64) DEFAULT '' AFTER `weatherid`", array('duceapp_member'));
}
if (!$field['cellphone']) {
	DB::query("ALTER TABLE %t ADD `cellphone` char(11) DEFAULT '' AFTER `nickname`", array('duceapp_member'));
}
if (!$field['isregister']) {
	DB::query("ALTER TABLE %t ADD `isregister` tinyint(1) NOT NULL DEFAULT '0' AFTER `cellphone`", array('duceapp_member'));
}
if (!$field['bindtime']) {
	DB::query("ALTER TABLE %t ADD `bindtime` int(10) unsigned NOT NULL DEFAULT '0' AFTER `isregister`", array('duceapp_member'));
}