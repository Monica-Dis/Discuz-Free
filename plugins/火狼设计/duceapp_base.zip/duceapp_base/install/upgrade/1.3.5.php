<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2020-01-21
 * Version: 3.01001
 * Date: 2021-06-30 22:19:57
 * File: 1.3.5.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$field = C::t('#duceapp_base#duceapp_member')->fetch_all_field();

if ($field['cellphone']) {
	DB::query("ALTER TABLE %t MODIFY `cellphone` varchar(32)", array('duceapp_member'));
}

DB::query("UPDATE %t SET intcode='86' WHERE (intcode='' OR intcode IS NULL) AND `cellphone`<>''", array('duceapp_member'));

if (!$field['intcode']) {
	DB::query("ALTER TABLE %t ADD `intcode` char(5) DEFAULT '' AFTER `ipaddress`", array('duceapp_session'));
}