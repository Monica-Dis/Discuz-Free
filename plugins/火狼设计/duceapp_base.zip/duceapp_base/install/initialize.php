<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-02-10
 * Version: 3.01024
 * Date: 2021-06-30 22:19:57
 * File: initialize.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

global $_G;

$_G['duceapp_base']['sensitive'] = 1;

dmkdir(DISCUZ_ROOT.'./source/admincp/menu/');
@copy(DUCEAPP_ROOT.'./install/menu_duceapp.php', DISCUZ_ROOT.'./source/admincp/menu/menu_duceapp.php');

cron_create('duceapp_base');