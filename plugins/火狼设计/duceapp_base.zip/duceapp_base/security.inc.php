<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-07-24
 * Version: 3.10102
 * Date: 2021-06-30 22:19:57
 * File: security.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once libfile('class/duceapp_admincp', 'plugin/duceapp_base');

class duceapp_modcp extends duceapp_admincp
{
	public $anchors = array('basic', 'cacheexport', 'cacheimport');

	public function __construct() {		
		$this->header();		
		$this->security = C::m('#duceapp_base#duceapp_security')->initaldata();
		if (!$this->security['auth']) {
			$this->danchor = 'basic';
		}
		duceapp_showanchors('', 1);
		call_user_func(array(__CLASS__, $this->cpmethod));

		$this->footer();
	}

	private function main() {
		global $_G;

		duceapp_anchortips('security_basic_tips', 'basic');
		
		duceapp_formheader('enctype');
		
		if ($this->danchor == 'basic') {
			duceapp_anchorheader('basic');
			if ($this->security['auth']) {
				duceapp_showsetting('security_pwdold', 'security_pwdold', '', 'password');
				duceapp_showsetting('security_sensitive', 'sensitive', intval($this->setting['sensitive']));
			}
			duceapp_showsetting('security_pwdnew', 'security_pwdnew', '', 'password');
			duceapp_showsetting('security_pwdconfirm', 'security_pwdconfirm', '', 'password');
			duceapp_showsetting('security_sesslife', 'security_sesslife', $_G['cache']['duceapp_security']['sesslife'], 'text');
			showsubmit('submit');
			duceapp_anchorfooter();
		} elseif ($this->danchor == 'cacheexport') {
			$allplugin = array();
			foreach(C::t('common_plugin')->fetch_all_data() as $plugin) {
				if ($plugin['identifier'] == 'duceapp' || strpos($plugin['identifier'], 'duceapp_') !== false){
					$allplugin[] = array($plugin['identifier'], $plugin['name']);
				}
			}
			$_G['duceapp_payments'] = (array) dunserialize($_G['setting']['duceapp_payments']);
			$allpayment = array();
			foreach($_G['duceapp_payments'] as $key => $payment){
				if ($key != 'walletpay') {
					$allpayment[] = array($key, ($payment['supform'] ? $_G['duceapp_payments'][$payment['supform']]['name'].' : ' : '').$payment['name']);
				}
			}
			duceapp_anchorheader('cacheexport');
			duceapp_showsetting('security_pwdold', 'security_pwdold', '', 'password');
			duceapp_showsetting('cacheexport_plugin', array('cacheexport[]', $allplugin), '', 'mselect');
			duceapp_showsetting('cacheexport_payment', array('paymentexport[]', $allpayment), '', 'mselect');
			showsubmit('submit', 'export');
			duceapp_anchorfooter();
		} elseif ($this->danchor == 'cacheimport') {
			duceapp_anchorheader('cacheimport');
			duceapp_showsetting('security_pwdold', 'security_pwdold', '', 'password');
			duceapp_showsetting('cacheimport_data', 'importdata', '', 'file');
			showsubmit('submit', 'import');
			duceapp_anchorfooter();
		}

		showformfooter();
	}

	private function save() {
		global $_G;

		if ($_GET['security_pwdolden']) {
			$_GET['security_pwdold'] = authcode($_GET['security_pwdolden']);
		}

		if (C::m('#duceapp_base#duceapp_security')->storage(true)) {
			if ($this->danchor == 'basic') {
				$this->setting['sensitive'] = intval($_GET['sensitive']);
			} elseif ($this->danchor == 'cacheexport') {
				$exportdata = array();
				if ($_GET['cacheexport'] && is_array($_GET['cacheexport'])) {
					foreach($_GET['cacheexport'] as $pkey) {
						if ($_G['setting'][$pkey]){
							$exportdata['setting'][$pkey] = is_array($_G['setting'][$pkey]) ? $_G['setting'][$pkey] : dunserialize($_G['setting'][$pkey]);
						} else {
							loadcache($pkey);
							if ($_G['cache'][$pkey]) {
								$exportdata['cache'][$pkey] = $_G['cache'][$pkey];
							}
						}
					}
				}
				if ($_GET['paymentexport'] && is_array($_GET['paymentexport'])) {
					$_G['duceapp_payments'] = (array) dunserialize($_G['setting']['duceapp_payments']);
					foreach($_GET['paymentexport'] as $pkey) {
						if ($_G['duceapp_payments'][$pkey]) {
							$exportdata['payment'][$pkey] = $_G['duceapp_payments'][$pkey];
						}
					}
				}
				if ($exportdata) {
					$exportdata = base64_encode(serialize($exportdata));
					duceapp_download('duceapp_syscache.data', '', $exportdata);
				} else {
					duceapp_error('cacheexport_nodata');
				}
			} elseif ($this->danchor == 'cacheimport') {
				$plugins = array();
				foreach(C::t('common_plugin')->fetch_all_data() as $plugin){
					if ($plugin['identifier'] == 'duceapp' || strpos($plugin['identifier'], 'duceapp_') !== false){
						$plugins[$plugin['identifier']] = $plugin['name'];
					}
				}
				if ($_GET['importconfirm']) {
					$data = $_GET['importdata'] ? unserialize(base64_decode(urldecode($_GET['importdata']))) : false;
					if ($data) {
						$updatesetting = false;
						foreach((array) $_GET['import'] as $pk) {
							if ($plugins[$pk]) {
								if ($data['setting'][$pk]) {
									C::t('common_setting')->update_batch(array($pk => $data['setting'][$pk]));
									$updatesetting = true;
								} elseif ($data['cache'][$pk]) {
									savecache($pk, $data['cache'][$pk]);
								}
							}
						}
						if ($_GET['payment']) {
							$updatesetting1 = false;
							$_G['duceapp_payments'] = (array) dunserialize($_G['setting']['duceapp_payments']);
							foreach((array) $_GET['payment'] as $pk) {
								if ($data['payment'][$pk]) {
									$_G['duceapp_payments'][$pk] = $data['payment'][$pk];
									$updatesetting = $updatesetting1 = true;
								}
							}
							if ($updatesetting1){
								C::t('common_setting')->update_batch(array('duceapp_payments' => $_G['duceapp_payments']));
							}
						}
						$updatesetting && updatecache('setting');
						duceapp_cpmsg();
					} else {
						duceapp_error('cacheimport_data_invalid');
					}
				} elseif ($_FILES['importdata'] && (@$fp = fopen($_FILES['importdata']['tmp_name'], 'r'))) {
					$buffer = '';
					while($b = fread($fp, 102400)) {
						$buffer .= $b;
						flush();
					}
					fclose($fp);
					$data = unserialize(base64_decode($buffer));
					if (!$data) {
						duceapp_error('cacheimport_data_invalid');
					}
					$confirmbox = '<div style="float:left;position:relative;width:790px;"><div unselectable="on" style="width:100%;height:100%;overflow:hidden;-moz-user-select:none;-webkit-user-select:none;-ms-user-select:none;-khtml-user-select:none;user-select:none;"><ul style="width:790px;float:left;" class="nofloat" onmouseover="altStyle(this);">';
					foreach($data as $type => $p) {
						if ($type == 'payment') {
							continue;
						}
						foreach($p as $k => $v) {
							if ($plugins[$k]) {
								$confirmbox .= '<li class="" style="float:left;width:25%;overflow:hidden;"><input class="checkbox" type="checkbox" name="import[]" value="'.$k.'">&nbsp;'.$plugins[$k].'</li>';
								unset($plugins[$k]);
							}
						}
					}
					$confirmbox .= '</ul></div></div>';
					if ($data['payment']) {
						$confirmpayment = '<div style="float:left;position:relative;width:790px;"><div unselectable="on" style="width:100%;height:100%;overflow:hidden;-moz-user-select:none;-webkit-user-select:none;-ms-user-select:none;-khtml-user-select:none;user-select:none;"><ul style="width:790px;float:left;" class="nofloat" onmouseover="altStyle(this);">';
						foreach($data['payment'] as $k => $d) {
							$confirmpayment .= '<li class="" style="float:left;width:25%;overflow:hidden;"><input class="checkbox" type="checkbox" name="payment[]" value="'.$k.'">&nbsp;'.($d['supform'] ? $data['payment'][$d['supform']]['name'].': ' : '').$d['name'].'</li>';
						}
						$confirmpayment .= '</ul></div></div>';
					}
					duceapp_formheader();
					duceapp_anchorheader();
					showhiddenfields(array(
						'importconfirm' => 1, 
						'importdata' => urlencode($buffer), 
						'security_pwdolden' => authcode($_GET['security_pwdold'], 'ENCODE'),
					));
					showtablerow('', 'class="td27" colspan="2"', duceapp_cplang('cacheimport_select'));
					showtablerow('class="noborder"', 'class="vtop rowform" colspan="2"', $confirmbox);
					if ($confirmpayment) {
						showtablerow('', 'class="td27" colspan="2"', duceapp_cplang('cacheimport_payment'));
						showtablerow('class="noborder"', 'class="vtop rowform" colspan="2"', $confirmpayment);
					}
					showsubmit('submit', 'ok');
					duceapp_anchorfooter();
					showformfooter();
					return;
				}
			}
		}

		duceapp_succeed();
	}
}

new duceapp_modcp;