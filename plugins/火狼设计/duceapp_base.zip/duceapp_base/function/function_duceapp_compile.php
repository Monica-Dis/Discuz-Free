<?php

	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "Access Denied";
		return 0;
	}

function duceapp_loadcore($_arg_0)
{
	$_var_1 = libfile("function/duceapp_core", "plugin/" . DUCEAPP_IDENT);
	if ($_var_1 && @file_exists($_var_1)) {
		include_once $_var_1;
	}
	if ($_arg_0 == "duceapp_base") {
		include_once libfile("function/duceapp_authc", "plugin/duceapp_base");
	}
	return true;
}
function duceapp_available($_arg_0)
{
	global $_G;
	global $updatebatch;
	global $duceapp_install;
	if (!$_arg_0->handle) {
		duceapp_loadcore($_arg_0->basedir);
	}
	$_var_4 = NULL;
	if ($_arg_0->basedir == "duceapp_base") {
		$_var_4 = duceapp_addoncheck(DUCEAPP_IDENT);
	} else {
		$_var_5 = DUCEAPP_IDENT . "_addoncheck";
		if (function_exists($_var_5)) {
			$_var_4 = call_user_func($_var_5);
		}
	}
	if (defined("DUCEAPP_UPGRADE")) {
		if ($updatebatch) {
			if ($_arg_0->cachetype != "setting") {
				savecache(DUCEAPP_IDENT, $_G["cache"][DUCEAPP_IDENT]);
			} else {
				C::t("common_setting")->update_batch(array(DUCEAPP_IDENT => serialize($_G["setting"][DUCEAPP_IDENT])));
				updatecache("setting");
			}
		}
	} else {
		if ($_var_4 !== NULL) {
			$_arg_0->flush_content("setting_addoncheck", '', $_var_4 ? "valid" : "invalid");
		}
		$duceapp_install = $_arg_0;
		@(include DUCEAPP_ROOT . "./install/initialize.php");
		if ($_G[DUCEAPP_IDENT]) {
			if (defined("DUCEAPP_CACHETYPE") && DUCEAPP_CACHETYPE == "setting") {
				C::t("common_setting")->update_batch(array(DUCEAPP_IDENT => serialize($_G[DUCEAPP_IDENT])));
				updatecache("setting");
			} else {
				savecache(DUCEAPP_IDENT, $_G[DUCEAPP_IDENT]);
			}
		}
	}
}