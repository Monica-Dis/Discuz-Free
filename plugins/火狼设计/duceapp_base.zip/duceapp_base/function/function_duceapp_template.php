<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2020-10-17
 * Version: 3.10323
 * Date: 2021-06-30 22:19:57
 * File: function_duceapp_template.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function duceapp_template($file, $templateid = 0, $tpldir = '', $styleid = 0, $primaltpl = '') {
	global $_G;
	$tplfile = template($file, $templateid, $tpldir, true, $primaltpl);
	if (strpos($file, ':') !== false) {
		list($templateid, $file) = explode(':', $file);
	}
	if (!empty($_G['inajax']) && ($file == 'common/header' || $file == 'common/footer')) {
		$file .= '_ajax';
	}
	if ($file == 'common/header' && defined('CURMODULE') && CURMODULE){
		$file = 'common/header_'.$_G['basescript'].'_'.CURMODULE;
	}
	$_G['style']['tplfile'] = $file;

	$tpldir = str_replace(array('/'.$file.'.htm', '/'.$_G['mobiletpl'][IN_MOBILE]), '', $tplfile);
	if ($templateid == 'diy' && strpos($tplfile, 'data/diy/') === false && file_exists(DISCUZ_ROOT.'data/diy/'.$tplfile)) {
		$tpldir = 'data/diy/'.$tpldir;
		$tplfile = 'data/diy/'.$tplfile;
	}
	$file = $primaltpl ? $primaltpl : $file;
	$templateid = $templateid ? $templateid : (defined('TEMPLATEID') ? TEMPLATEID : '');
	$cachefile = './data/template/'.($styleid ? $styleid.'_' : (defined('STYLEID') ? STYLEID.'_' : '')).'duceapp_'.md5($templateid.$file.$_G['config']['security']['authkey']).'.tpl.php';
	checktplrefresh($tplfile, $tplfile, @filemtime(DISCUZ_ROOT.$cachefile), $templateid, $cachefile, $tpldir, $file);
	
	return DISCUZ_ROOT.$cachefile;
}