<?php

	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	define("DUCEAPP_PLUGIN", 1);

function duceapp_validator($_arg_0)
{
	global $_G;
	$_var_2 = defined("IN_ADMINCP") ? DUCEAPP_AUTHC : call_user_func($_arg_0 . "_authc");
	$_var_3 = duceapp_makesign($_var_2, $_arg_0);
	return true;
}
function duceapp_makesign($_arg_0, $_arg_1)
{
	$_arg_0 = md5($_arg_1 . " " . $_arg_0);
	$_var_2 = base64_encode(substr($_arg_0, 3, 6));
	$_var_2 = str_replace("=", '', "duceapp_" . strtolower($_var_2));
	return array($_var_2, $_arg_0);
}
function duceapp_addonbatch($_arg_0 = array())
{
	if (empty($_arg_0) && $_GET["end"]) {
		parse_str($_GET["end"], $_var_1);
		if ($_var_1["Branche"]) {
			$_var_2 = explode("|", $_var_1["Branche"]);
			$_arg_0 = array($_var_2[0] => $_var_2[1]);
		}
	}
	if ($_arg_0) {
		C::t("common_setting")->update_batch($_arg_0);
	}
}
function duceapp_addoncheck($_arg_0)
{
	$_var_1 = cloudaddons_getmd5($_arg_0 . ".plugin");
	$_var_2 = explode(",", $_var_1["RevisionDateline"]);
	if (duceapp_validator($_arg_0)) {
		return $_var_2[0] ? $_var_2[0] : TIMESTAMP;
	}
	$_var_3 = cloudaddons_url("&from=s");
	$_var_4 = "&mod=app&ac=validator&ver=2&addonid=" . $_arg_0 . ".plugin&rid=" . $_var_1["RevisionID"] . "&sn=" . $_var_1["SN"] . "&rd=" . $_var_1["RevisionDateline"];
	$_var_5 = explode(",", $_var_1["SN"]);
	$_var_6 = explode(",", $_var_1["RevisionID"]);
	$_var_7 = duceapp_makesign(md5($_var_5[0] . $_var_6[0]), $_arg_0);
	duceapp_addonbatch(array($_var_7[0] => $_var_7[1]));
	updatecache("setting");
	return $_var_2[0];
}