<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-02-10
 * Version: 3.01202
 * Date: 2021-06-30 22:19:58
 * File: table_duceapp_member.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_duceapp_member extends discuz_table
{
	public function __construct() {
		$this->_table = 'duceapp_member';
		$this->_pk    = 'uid';
		$this->_pre_cache_key = 'duceapp_member_';
		$this->_cache_ttl = 0;
		parent::__construct();
	}

	public function batch_update($uid, $data) {
		if ($uid) {
			if ($this->fetch($uid)) {
				$this->update($uid, $data);
			} else {
				$data['uid'] = $uid;
				$this->insert($data);
			}
		}
	}

	public function count_by_uid($uid) {
		return DB::result_first('SELECT COUNT(*) FROM %t WHERE %i', array($this->_table, DB::field('uid', $uid)));
	}

	public function fetch_by_cellphone($cellphone, $intcode = '86') {
		$intcode = $intcode ? $intcode : '86';
		return DB::fetch_first("SELECT * FROM %t WHERE intcode=%i AND cellphone=%i", array($this->_table, $intcode, $cellphone));
	}	
}