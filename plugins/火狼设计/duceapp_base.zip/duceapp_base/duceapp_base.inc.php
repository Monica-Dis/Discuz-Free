<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-10-07
 * Version: 3.00223
 * Date: 2021-06-30 22:19:57
 * File: duceapp_base.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$ac = !empty($_GET['ac']) && in_array($_GET['ac'], array('qrcode', 'accbind')) ? $_GET['ac'] : 'common';

if ($_GET['compon']) {
	$inc = libfile($_GET['compon'], 'plugin/duceapp_base/compon');
} else {
	$inc = libfile('base_'.$ac, 'plugin/duceapp_base/include');
}

if (!$inc || !file_exists($inc)) {
	showmessage('undefined_action', '', array(), array('showdialog' => 1));
}

include $inc;