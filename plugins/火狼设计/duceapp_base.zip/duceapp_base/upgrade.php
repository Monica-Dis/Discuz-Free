<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-02-10
 * Version: 3.01001
 * Date: 2021-06-30 22:19:58
 * File: upgrade.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

define('DUCEAPP_UPGRADE', 1);
define('DUCEAPP_ROOT', dirname(__FILE__).'/');
define('DUCEAPP_IDENT', basename(DUCEAPP_ROOT));
define('DUCEAPP_DATAURL', 'data/'.str_replace('_', '/', DUCEAPP_IDENT).'/');

include_once libfile('class/duceapp_installcore', 'plugin/duceapp_base');
$duceapp_install = new duceapp_installcore;
$duceapp_install->upgrade();

$finish = TRUE;