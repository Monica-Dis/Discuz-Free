<?php

	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "Access Denied";
		return 0;
	}

class duceapp_installcore
{
	public $steps = array();
	public $flushtime = 200;
	public $timeout = 300;
	public $step;
	public $lockfile;
	public $cachetype;
	public $tables = array();
	public $table_feilds = array();
	public $staticdir;
	public $requestpost;
	public $initTable;
	public function init()
	{
		$this->lockfile = DISCUZ_ROOT . "./data/duceapp/" . DUCEAPP_IDENT . ".lock";
		$this->staticdir = "source/plugin/" . basename(substr(dirname(__FILE__), 0, -5)) . "/";
		if ($_GET["step"] == "finish") {
			return $this->finished();
		}
		if (!$this->steps || $_GET["operation"] == "enable" && file_exists($this->lockfile)) {
			return true;
		}
		$this->installlang();
		if (!in_array("setting", $this->steps)) {
			$this->steps[] = "setting";
		}
		$this->requestpost = submitcheck("duceapp_install");
		$this->step = $_GET["step"] && in_array($_GET["step"], $this->steps) ? $_GET["step"] : $this->steps[0];
		if ($this->step && method_exists($this, $this->step)) {
			call_user_func(array($this, $this->step));
		} else {
			$this->setting();
		}
	}
	public function installlang()
	{
		global $_G;
		global $pluginarray;
		global $plugin;
		global $installlang;
		if (!isset($_G["cache"]["pluginlanguage_install"])) {
			loadcache("pluginlanguage_install");
		}
		$installlang = !empty($pluginarray) ? $pluginarray["language"]["installlang"] : $_G["cache"]["pluginlanguage_install"][DUCEAPP_IDENT];
		$installlang = is_array($installlang) ? $installlang : array();
		if (!empty($pluginarray)) {
			$installlang["pluginname"] = $pluginarray["plugin"]["name"];
			$installlang["version"] = $pluginarray["plugin"]["version"];
			$installlang["appvercat"] = $pluginarray["language"]["scriptlang"]["appvercat"];
		} else {
			$installlang["pluginname"] = $plugin["name"];
			$installlang["version"] = $plugin["version"];
		}
		if (DUCEAPP_IDENT != "duceapp_base" && !empty($_G["cache"]["pluginlanguage_install"]["duceapp_base"])) {
			$installlang = array_merge($_G["cache"]["pluginlanguage_install"]["duceapp_base"], $installlang);
		}
	}
	public function gettables()
	{
		if (!$this->initTable) {
			$this->initTable = true;
			if ($this->tables) {
				$_var_1 = array();
				foreach ($this->tables as $_var_2) {
					$_var_1[$_var_2] = DB::result_first("SHOW TABLES LIKE '" . DB::table($_var_2) . "'");
				}
				return $this->tables = $_var_1;
			}
			if ($_var_3 = dir(DUCEAPP_ROOT . "install/sql")) {
				while ($_var_4 = $_var_3->read()) {
					if (preg_match("/^(duceapp_[\\w_]+)\\.sql\$/", $_var_4, $_var_5)) {
						$this->tables[$_var_5[1]] = DB::result_first("SHOW TABLES LIKE '" . DB::table($_var_5[1]) . "'");
					}
				}
			}
		}
		return $this->tables;
	}
	public function getfields($_arg_0)
	{
		$_var_2 = false;
		$_var_3 = DB::query("SHOW FIELDS FROM " . DB::table($_arg_0), '', "SILENT");
		if ($_var_3) {
			$_var_2 = array();
			while ($_var_4 = DB::fetch($_var_3)) {
				$_var_2[$_var_4["Field"]] = $_var_4;
			}
		}
		return $_var_2;
	}
	public function table()
	{
		global $installlang;
		$_var_2 = array();
		$_var_2["contents"] = "<ul class=\"cl\">";
		foreach ($this->gettables() as $_var_3 => $_var_4) {
			$_var_2["contents"] = $_var_2["contents"] . ("<li class=\"" . ($_var_4 ? "prompt" : '') . "\" id=\"table_" . $_var_3 . "\"><img src=\"" . $this->staticdir . "static/image/table.png\">" . DB::table($_var_3) . " <span id=\"table_" . $_var_3 . "_valid\">" . ($_var_4 ? "(" . $installlang["table_exists"] . ")" : '') . "</span></li>");
			if ($_var_4) {
				$_var_5 = $this->requestpost ? "disabled" : '';
				$_var_6 = $this->requestpost && $_POST["tabletype"] == "force" ? "force" : "ignore";
				$_var_7 = array($_var_6 => "checked");
				$_var_8 = $this->requestpost ? '' : "onmouseover=\"altStyle(this);\"";
				$_var_2["tips"] = $this->requestpost ? $installlang["table_runtips"] : $installlang["table_tips"];
				$_var_2["extra"] = "<ul " . $_var_8 . " style=\"margin-left:-4px;\"><li class=\"" . $_var_7["ignore"] . "\"><input type=\"radio\" name=\"tabletype\" value=\"ignore\" class=\"radio\" " . $_var_7["ignore"] . " " . $_var_5 . " />" . $installlang["table_ignore"] . "</li><li class=\"" . $_var_7["force"] . "\"><input type=\"radio\" name=\"tabletype\" value=\"force\" class=\"radio\" " . $_var_7["force"] . " " . $_var_5 . " />" . $installlang["table_force"] . "</li></ul>";
			}
		}
		$_var_2["contents"] = $_var_2["contents"] . "</ul>";
		$this->output($_var_2);
		if (!$this->requestpost) {
			return NULL;
		}
		$_var_9 = false;
		foreach ($this->gettables() as $_var_3 => $_var_4) {
			if (!$_var_4 || $_POST["tabletype"] == "force") {
				$this->flush_script(str_replace("{table}", $_var_3, $installlang["table_runquery"]), $_var_3);
				if (is_file(DUCEAPP_ROOT . "install/sql/" . $_var_3 . ".sql")) {
					$_var_10 = @implode('', file(DUCEAPP_ROOT . "install/sql/" . $_var_3 . ".sql"));
					runquery($_var_10);
				}
			}
			if ($_var_4 && $_POST["tabletype"] != "force") {
				$_var_9 = true;
			}
		}
		$this->flush_end("table", $_var_9 ? "table_finishignore" : "table_finish", "next");
	}
	public function output($_arg_0 = array())
	{
		global $_G;
		global $installlang;
		global $plugin;
		$_var_5 = $_arg_0["langvar"] ? $_arg_0["langvar"] : $this->step;
		$_var_6 = $_arg_0["button"] ? $_arg_0["button"] : $installlang["button"];
		$_var_7 = $this->requestpost || $_arg_0["disabled"] ? "disabled" : '';
		if (count($this->steps) > 1) {
			$_var_8 = "<em>" . (array_search($this->step, $this->steps) + 1) . ".</em>";
		}
		echo "\r\n\t\t<link rel=\"stylesheet\" href=\"" . $this->staticdir . "static/css/install.css?" . random(3) . "\" type=\"text/css\" media=\"all\">\r\n\t\t<div class=\"install_main\">\r\n\t\t\t<form id=\"installform\" method=\"post\" action=\"" . DUCEAPP_CPURL . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"formhash\" value=\"" . FORMHASH . "\">\r\n\t\t\t\t<input type=\"hidden\" id=\"duceapp_step\" name=\"step\" value=\"" . $this->step . "\">\r\n\t\t\t\t<input type=\"hidden\" id=\"duceapp_install\" name=\"duceapp_install\" value=\"yes\">\r\n\t\t\t\t<table width=\"100%\" height=\"100%\">\r\n\t\t\t\t\t<thead>\r\n\t\t\t\t\t\t<tr><td><a href=\"http://www.duceapp.cn\" target=\"_blank\">&nbsp;</a><h1>" . $installlang["thead"] . "</h1></td></tr>\r\n\t\t\t\t\t</thead>\r\n\t\t\t\t\t<tbody>\r\n\t\t\t\t\t\t<tr><td><div class=\"plugin_info\">" . $installlang["pluginname"] . " v" . $installlang["version"] . " " . $installlang["appvercat"] . " for Discuz!" . $_G["setting"]["version"] . " " . strtoupper(CHARSET) . "</div></td></tr>\r\n\t\t\t\t\t\t<tr><td>\r\n\t\t\t\t\t\t\t<div class=\"stepmain\">\r\n\t\t\t\t\t\t\t\t<h2>" . $_var_8 . $installlang[$_var_5] . "</h2>\r\n\t\t\t\t\t\t\t\t<h3>" . $installlang[$_var_5 . "_comment"] . "</h3>\r\n\t\t\t\t\t\t\t\t" . $_arg_0["contents"] . "\r\n\t\t\t\t\t\t\t\t<div id=\"prompt_tip\" class=\"prompt_tip cl\">" . $_arg_0["tips"] . "</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</td></tr>\r\n\t\t\t\t\t</tbody>\r\n\t\t\t\t\t<tfoot>\r\n\t\t\t\t\t\t<tr><td>\r\n\t\t\t\t\t\t\t<input class=\"btn " . $_var_7 . "\" type=\"submit\" name=\"duceapp_submit\" id=\"duceapp_submit\" value=\"" . $_var_6 . "\" " . $_var_7 . ">\r\n\t\t\t\t\t\t\t<div class=\"extra\">" . $_arg_0["extra"] . "</div>\r\n\t\t\t\t\t\t</td></tr>\r\n\t\t\t\t\t</tfoot>\r\n\t\t\t\t</table>\r\n\t\t\t</form>\r\n\t\t</div>\r\n\t\t";
		echo $_arg_0["finish"] && !$this->requestpost ? "<script type=\"text/javascript\">setTimeout(function(){\$('installform').submit()}, 1000)</script>" : '';
	}
	public function setting()
	{
		global $_G;
		global $installlang;
		$this->output(array("disabled" => "disabled", "button" => $installlang["setting_button"], "finish" => true, "contents" => "<ul class=\"cl\" id=\"duceapp_contents\"></ul>"));
		if (!$this->requestpost) {
			return NULL;
		}
		$this->loadcache();
		if (defined("DUCEAPP_COMPILE")) {
			duceapp_available($this);
		} else {
			@(include DUCEAPP_ROOT . "./install/initialize.php");
			if ($_G[DUCEAPP_IDENT]) {
				if ($this->cachetype == "setting") {
					C::t("common_setting")->update_batch(array(DUCEAPP_IDENT => serialize($_G[DUCEAPP_IDENT])));
					updatecache("setting");
				} else {
					savecache(DUCEAPP_IDENT, $_G[DUCEAPP_IDENT]);
				}
			}
		}
		$this->flush_content("setting_initialize");
		if (DUCEAPP_IDENT != "duceapp_base") {
			@(include DUCEAPP_ROOT . "install/duceapp_base.php");
		}
		$this->flush_end("finish");
	}
	public function finished()
	{
		foreach (array("SC_GBK", "SC_UTF8", "TC_BIG5", "TC_UTF8") as $_var_1) {
			@unlink(DUCEAPP_ROOT . "discuz_plugin_" . DUCEAPP_IDENT . "_" . $_var_1 . ".xml");
		}
		return true;
	}
	public function flush_content($_arg_0 = '', $_arg_1 = '', $_arg_2 = "valid")
	{
		global $installlang;
		$_arg_0 = $_arg_0 && $installlang[$_arg_0] ? $installlang[$_arg_0] : $_arg_0;
		echo "<script type=\"text/javascript\">setTimeout(function(){";
		echo $_arg_0 ? "\$('duceapp_contents').innerHTML += \"<li>" . str_replace("\"", "\\\"", $_arg_0) . " <img src=\\\"./static/image/common/data_" . $_arg_2 . ".gif\\\" /></li>\";" : '';
		$_arg_1 = $_arg_1 && $installlang[$_arg_1] ? $installlang[$_arg_1] : $_arg_1;
		echo $_arg_1 ? "\$('prompt_tip').innerHTML = \"" . str_replace("\"", "\\\"", $_arg_1) . "\";" : '';
		echo "}, " . $this->flushtime . ");</script>";
		$this->flushtime = $this->flushtime + $this->timeout;
	}
	public function flush_script($_arg_0 = '', $_arg_1 = '')
	{
		global $installlang;
		echo "<script type=\"text/javascript\">setTimeout(function(){";
		echo $_arg_1 ? "\$('table_" . $_arg_1 . "').className += \" checked\";\$('table_" . $_arg_1 . "_valid').innerHTML = \"<img src=\\\"./static/image/common/data_valid.gif\\\" />\";" : '';
		$_arg_0 = $_arg_0 && $installlang[$_arg_0] ? $installlang[$_arg_0] : $_arg_0;
		echo $_arg_0 ? "\$('prompt_tip').innerHTML = \"" . str_replace("\"", "\\\"", $_arg_0) . "\";" : '';
		echo "}, " . $this->flushtime . ");</script>";
		$this->flushtime = $this->flushtime + $this->timeout;
	}
	public function flush_end($_arg_0, $_arg_1 = false, $_arg_2 = '')
	{
		global $installlang;
		if ($_arg_0 != "finish") {
			$_var_5 = array_search($_arg_0, $this->steps);
			$_var_5 = !($_var_5 === false) ? intval($_var_5) + 1 : 0;
			$_arg_0 = $_var_5 && $this->steps[$_var_5] ? $this->steps[$_var_5] : "setting";
		}
		$_arg_2 = $installlang[$_arg_2 ? $_arg_2 : $_arg_0];
		echo "\r\n\t\t<script type=\"text/javascript\">\r\n\t\tsetTimeout(function(){\r\n\t\t\t" . (!($_arg_1 === false) ? "\$('prompt_tip').innerHTML = \"" . ($_arg_1 ? str_replace("\"", "\\\"", $installlang[$_arg_1]) : '') . "\";" : '') . "\r\n\t\t\t\$('duceapp_step').value = '" . $_arg_0 . "';\r\n\t\t\t\$('duceapp_submit').value = \"" . $_arg_2 . "\";\r\n\t\t\t\$('duceapp_install').name = \"duceapp_next\";\r\n\t\t";
		if ($_arg_0 != "finish") {
			echo "\r\n\t\t\t\$('duceapp_submit').className = 'btn';\r\n\t\t\t\$('duceapp_submit').disabled = false;\r\n\t\t\t";
		} else {
			@touch($this->lockfile);
			echo "setTimeout(function(){\$('installform').submit()}, 1000);";
		}
		echo "}, " . $this->flushtime . ");\r\n\t\t</script>";
	}
	public function loadcache()
	{
		global $_G;
		$this->basedir = basename(substr(dirname(__FILE__), 0, -5));
		$_var_2 = libfile("function/duceapp_compile", "plugin/" . $this->basedir);
		if ($_var_2 && @file_exists($_var_2)) {
			include_once $_var_2;
			define("DUCEAPP_COMPILE", true);
		}
		@(include DUCEAPP_ROOT . "install/plugin_constant.php");
		if (defined("DUCEAPP_CACHETYPE") && DUCEAPP_CACHETYPE == "setting") {
			$this->cachetype = "setting";
		}
		if ($this->cachetype != "setting") {
			if (!$_G["cache"][DUCEAPP_IDENT]) {
				loadcache(DUCEAPP_IDENT);
			}
		} else {
			$_G["setting"][DUCEAPP_IDENT] = dunserialize($_G["setting"][DUCEAPP_IDENT]);
			if (empty($_G["setting"][DUCEAPP_IDENT])) {
				$_G["setting"][DUCEAPP_IDENT] = array();
			}
		}
		if (defined("DUCEAPP_UPGRADE") && defined("DUCEAPP_COMPILE")) {
			$this->handle = duceapp_loadcore($this->basedir);
		}
		dmkdir(DISCUZ_ROOT . "./data/duceapp/");
	}
	public function upgrade()
	{
		global $_G;
		global $updatebatch;
		$this->lockfile = DISCUZ_ROOT . "./data/duceapp/" . DUCEAPP_IDENT . ".lock";
		$this->loadcache();
		$updatebatch = false;
		$_var_3 = DUCEAPP_ROOT . "/install/upgrade/";
		$_var_4 = array();
		if ($_var_5 = dir($_var_3)) {
			while ($_var_6 = $_var_5->read()) {
				if (preg_match("/^\\d+(\\.\\d+)?\\.\\d+\\.php\$/i", $_var_6)) {
					$_var_4[] = substr($_var_6, 0, -4);
				}
			}
		}
		if ($_var_4) {
			sort($_var_4);
			foreach ($_var_4 as $_var_7) {
				if ($_GET["fromversion"] < $_var_7) {
					include $_var_3 . $_var_7 . ".php";
				}
			}
		}
		@touch($this->lockfile);
		if (defined("DUCEAPP_COMPILE")) {
			duceapp_available($this);
		} else {
			if ($updatebatch) {
				if ($this->cachetype != "setting") {
					savecache(DUCEAPP_IDENT, $_G["cache"][DUCEAPP_IDENT]);
				} else {
					C::t("common_setting")->update_batch(array(DUCEAPP_IDENT => serialize($_G["setting"][DUCEAPP_IDENT])));
					updatecache("setting");
				}
			}
		}
		if (DUCEAPP_IDENT != "duceapp_base") {
			@(include DUCEAPP_ROOT . "install/duceapp_base.php");
		}
		$this->finished();
	}
}