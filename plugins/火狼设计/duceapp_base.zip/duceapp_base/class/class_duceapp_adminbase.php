<?php

	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "Access Denied";
		return 0;
	}

class duceapp_adminbase
{
	public $setting_keys = array();
	public $compon_keys = array();
	public $updatebatch = FALSE;
	public $stated = array();
	public $setting = array();
	public $anchors = array();
	public $dropanchor = array();
	public $dropmodule = array();
	public $coptyright = "2009-2017";
	public $cachetype = "syscache";
	public function init($_arg_0 = false)
	{
		global $_G;
		global $plugin;
		global $isplugindeveloper;
		global $isfounder;
		define("DUCEAPP_ADMINCP", 1);
		define("DUCEAPP_IDENT", $plugin["identifier"]);
		define("DUCEAPP_VERSION", $plugin["version"]);
		if ($_arg_0 && !$plugin["available"] && !file_exists(DISCUZ_ROOT . "./data/duceapp/" . DUCEAPP_IDENT . ".lock")) {
			dheader("location:" . ADMINSCRIPT . "?action=plugins&operation=enable&pluginid=" . $plugin["pluginid"] . "&formhash=" . FORMHASH . "&pmod=" . $_GET["pmod"]);
		}
		$this->basedir = basename(substr(dirname(__FILE__), 0, -5));
		define("DUCEAPP_BASEURL", "source/plugin/" . $this->basedir . "/");
		define("DUCEAPP_DIRURL", "source/plugin/" . DUCEAPP_IDENT . "/");
		define("DUCEAPP_ROOT", DISCUZ_ROOT . DUCEAPP_DIRURL);
		define("DUCEAPP_DATAURL", "data/" . str_replace("_", "/", DUCEAPP_IDENT) . "/");
		define("DUCEAPP_DATAROOT", DISCUZ_ROOT . DUCEAPP_DATAURL);
		define("DUCEAPP_SCHASH", $isplugindeveloper ? random(6) : FORMHASH);
		define("DUCEAPP_INBASE", $this->basedir == "duceapp_base");
		$this->basescript = "plugins&operation=config&do=" . $plugin["pluginid"] . "&pmod=" . $_GET["pmod"];
		$this->redirect = $_G["siteurl"] . ADMINSCRIPT . "?action=" . $this->basescript;
		$this->isfounder = $isfounder;
		$this->stated = array();
		$this->setting = array();
		$this->compons = array();
		$this->cmod = '';
		$this->danchor = '';
		include_once libfile("function/duceapp_admincp", "plugin/" . $this->basedir);
		$this->loadcore();
	}
	public function duceapp()
	{
		global $_G;
		global $plugin;
		duceapp_renewalmenu($this);
		$_var_3 = $_GET["danchor"];
		$_var_4 = $_GET["cmod"];
		$_var_5 = $this->anchors;
		if ($_GET["pmod"] == "compon") {
			$_var_6 = $this->compons;
			if ($_var_6 && $_var_6[$_var_4]) {
				$this->cmod = $_var_4;
			}
			if ($this->cmod) {
				if ($_var_5) {
					$this->danchor = $_var_3 && isset($_var_5[$_var_3]) ? $_var_3 : current(array_keys($_var_5));
				}
				$this->redirect = $this->redirect . ("&cmod=" . $this->cmod);
				$this->basescript = $this->basescript . ("&cmod=" . $this->cmod);
			}
		} else {
			if ($_var_5) {
				$this->danchor = $_var_3 && in_array($_var_3, $_var_5) ? $_var_3 : $_var_5[0];
			}
		}
		$this->cpmethod = submitcheck("duceapp_submit") ? "save" : "main";
		if ($this->cpmethod == "save" && $this->danchor) {
			$this->redirect = $this->redirect . ("&danchor=" . $this->danchor);
		}
		@(include DUCEAPP_ROOT . "install/plugin_constant.php");
		if (defined("DUCEAPP_CACHETYPE") && DUCEAPP_CACHETYPE == "setting") {
			$this->cachetype = "setting";
		}
		$plugin["duceapp_submit"] = $this->cpmethod == "save";
		$this->loadcache();
	}
	public function footer()
	{
		if (defined("DUCEAPP_INFOOTER")) {
			return NULL;
		}
		define("DUCEAPP_INFOOTER", 1);
		echo "<div class=\"duceapp_copyright\">Powered by <a href=\"http://addon.discuz.com/?@" . DUCEAPP_IDENT . ".plugin\" target=_blank><em>" . ucwords(str_replace("_", " ", DUCEAPP_IDENT)) . " " . $this->setting["vercat"] . "</em></a> <cite>" . DUCEAPP_VERSION . "</cite>&nbsp;&copy; " . $this->coptyright . ", <a href=\"http://www.duceapp.com\" target=\"_blank\">duceapp.com</a></div>";
		$this->savecache();
	}
	public function cpmsg($_arg_0 = '', $_arg_1 = '', $_arg_2 = "succeed", $_arg_3 = array(), $_arg_4 = '', $_arg_5 = true, $_arg_6 = '')
	{
		global $_G;
		$_arg_1 = $_arg_1 == '' && $_arg_2 == "succeed" ? $this->redirect : $_arg_1;
		if ($_arg_1) {
			$_arg_1 = str_replace($_G["siteurl"] . ADMINSCRIPT . "?", '', $_arg_1);
		}
		cpmsg(duceapp_cplang($_arg_0 ? $_arg_0 : "update_succeed", $_arg_3), $_arg_1, $_arg_2, $_arg_3, $_arg_4, false, $_arg_6);
		$this->footer();
	}
	public function succeed($_arg_0 = '', $_arg_1 = '', $_arg_2 = array())
	{
		$this->updatebatch = true;
		$this->cpmsg($_arg_0, $_arg_1, "succeed", $_arg_2);
	}
	public function error($_arg_0 = '', $_arg_1 = array(), $_arg_2 = false)
	{
		if ($_arg_2) {
			$this->updatebatch = true;
		}
		$this->cpmsg($_arg_0, '', "error", $_arg_1);
	}
	public function setcache($_arg_0, $_arg_1)
	{
		if ($this->cmod) {
			$this->setting[$this->cmod][$_arg_0] = $_arg_1;
		} else {
			$this->setting[$_arg_0] = $_arg_1;
		}
		$this->updatebatch = true;
	}
	public function loadcore()
	{
		$_var_1 = libfile("function/duceapp_core", "plugin/" . DUCEAPP_IDENT);
		if ($_var_1 && @file_exists($_var_1)) {
			include_once $_var_1;
		}
		if (DUCEAPP_INBASE) {
			include_once libfile("function/duceapp_authc", "plugin/duceapp_base");
		}
		duceapp_defines();
	}
	public function loadcache($_arg_0 = DUCEAPP_IDENT)
	{
		global $_G;
		if ($_arg_0 != "duceapp_base" && DUCEAPP_INBASE) {
			if (isset($_G["setting"]["duceapp_base"])) {
				$_G["cache"]["duceapp_base"] = dunserialize($_G["setting"]["duceapp_base"]);
			} else {
				loadcache("duceapp_base");
			}
		}
		if ($this->cachetype == "setting") {
			$_G["setting"][$_arg_0] = dunserialize($_G["setting"][$_arg_0]);
			if (!isset($_G["cache"][$_arg_0])) {
				duceapp_cacheinherit($_var_3, $_arg_0);
			}
		} else {
			if (!isset($_G["cache"][$_arg_0])) {
				loadcache($_arg_0);
			}
		}
		$_G["cache"][$_arg_0] = is_array($_G["cache"][$_arg_0]) ? $_G["cache"][$_arg_0] : array();
		duceapp_cacheinherit($this, $_arg_0);
		return $this->setting;
	}
	public function savecache($_arg_0 = DUCEAPP_IDENT)
	{
		if (DUCEAPP_INBASE) {
			if (!duceapp_addoncheck($_arg_0)) {
				return NULL;
			}
		} else {
			$_var_2 = $_arg_0 . "_addoncheck";
			if (function_exists($_var_2) && !call_user_func($_var_2)) {
				return NULL;
			}
		}
		if ($this->updatebatch && $this->setting) {
			$this->updatebatch = false;
			if ($this->setting_keys) {
				foreach ($this->setting as $_var_3 => $_var_4) {
					if (!in_array($_var_3, $this->setting_keys)) {
						unset($this->setting[$_var_3]);
					}
				}
			}
			if ($this->cmod && $this->compon_keys && is_array($this->setting[$this->cmod])) {
				foreach ($this->setting[$this->cmod] as $_var_3 => $_var_4) {
					if (!in_array($_var_3, $this->compon_keys)) {
						unset($this->setting[$this->cmod][$_var_3]);
					}
				}
			}
			if ($this->cachetype == "setting") {
				$_var_5 = array($_arg_0 => serialize($this->setting));
				C::t("common_setting")->update_batch($_var_5);
				updatecache("setting");
			} else {
				savecache($_arg_0, $this->setting);
			}
		}
		if ($this->stated && is_object($this->cache)) {
			$this->cache->putstate($this->stated);
		}
	}
}