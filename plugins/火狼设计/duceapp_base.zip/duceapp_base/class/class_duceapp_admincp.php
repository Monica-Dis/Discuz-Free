<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-02-10
 * Version: 3.10528
 * Date: 2021-06-30 22:19:57
 * File: class_duceapp_admincp.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once libfile('class/duceapp_adminbase', 'plugin/duceapp_base');

class duceapp_admincp extends duceapp_adminbase
{
	public $setting_keys = array();
	public $cachetype = 'setting';

	public function header() {
		global $_G;
		if (!is_file(DISCUZ_ROOT.'./source/admincp/menu/menu_duceapp.php')) {
			dmkdir(DISCUZ_ROOT.'./source/admincp/menu/');
			@copy(DUCEAPP_ROOT.'./install/menu_duceapp.php', DISCUZ_ROOT.'./source/admincp/menu/menu_duceapp.php');
		}
		$this->init(true);
		$this->duceapp();
	}
}