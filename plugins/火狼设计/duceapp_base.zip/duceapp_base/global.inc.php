<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-10-07
 * Version: 3.10528
 * Date: 2021-06-30 22:19:57
 * File: global.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once libfile('class/duceapp_admincp', 'plugin/duceapp_base');

class duceapp_modcp extends duceapp_admincp
{
	public $anchors = array('basic', 'styles');

	public function __construct() {
		$this->header();

		duceapp_showanchors('setting');
		call_user_func(array(__CLASS__, $this->cpmethod));

		$this->footer();
	}

	private function main() {
		global $_G;

		duceapp_formheader('enctype');

		duceapp_anchortips('setting_watermark_tips', 'watermark');
		duceapp_anchortips('setting_memory_tips', 'memory');

		duceapp_anchorheader('basic');
		duceapp_showsetting('setting_thumbwidth', 'settingnew[thumbwidth]', $this->setting['thumbwidth'], 'text');
		duceapp_showsetting('setting_bdapikey', 'settingnew[bdapikey]', $this->setting['bdapikey'], 'text');
		duceapp_showsetting('setting_accbind', 'settingnew[accbind]', $this->setting['accbind'] ? implode("\n", $this->setting['accbind']) : '', 'textarea');
		showsubmit('duceapp_submit');
		duceapp_anchorfooter();

		showtagheader('div', 'duceapp_styles_bd', $this->danchor == 'styles');

		duceapp_anchortips('style_tips', 'styles');
		$theme_styles = duceapp_initcommoncss();
		$tabs = array('style_common', 'style_footer', 'style_pc');
		$subtab = $_GET['subtab'] ? $_GET['subtab'] : $tabs[0];
		duceapp_anchortabs('styles', $tabs, $subtab);
		duceapp_anchorheader('subtab_style_common', 'style_common' == $subtab);
		duceapp_showsetting('style_header', 'styles[themecolor]', $theme_styles['themecolor'], 'color');
		duceapp_showsetting('style_text', 'styles[textcolor]', $theme_styles['textcolor'], 'color');
		duceapp_showsetting('style_font', 'styles[linkcolor]', $theme_styles['linkcolor'], 'color');
		duceapp_showsetting('style_button', 'styles[buttoncolor]', $theme_styles['buttoncolor'], 'color');
		duceapp_showsetting('style_fontweight', array('styles[fontweight]', array(
			array(0, duceapp_cplang('style_fontweight_0')),
			array(1, duceapp_cplang('style_fontweight_1')),
		), 1), intval($theme_styles['fontweight']), 'mradio');
		duceapp_showsetting('style_nofooter', 'settingnew[nofooter]', $this->setting['nofooter']);
		showsubmit('duceapp_submit');
		duceapp_anchorfooter();

		duceapp_anchortips('style_footer_tips', 'subtab_style_footer');
		duceapp_anchorheader('subtab_style_footer', 'style_footer' == $subtab);
		$footerhtml = $this->setting['footerhtml'] ? @file_get_contents(DUCEAPP_DATAURL.'footerhtml.php') : '';
		showtablerow('', array('colspan="15"'), array('<textarea class="tarea" name="settingnew[footerhtml]" style="width:60%;height:300px;line-height:20px;">'.$footerhtml.'</textarea>'));
		showsubmit('duceapp_submit');
		duceapp_anchorfooter();

		duceapp_anchorheader('subtab_style_pc', 'style_pc' == $subtab);
		duceapp_showsetting('setting_pageqrcode', array('settingnew[pageqrcode][enable]', array(
			array(0, cplang('no'), array('pageqrcode' => 'none')),
			array(1, duceapp_cplang('setting_pageqrcode1'), array('pageqrcode' => '')),
			array(2, duceapp_cplang('setting_pageqrcode2'), array('pageqrcode' => '')),
		), 1), intval($this->setting['pageqrcode']['enable']), 'mradio');
		showtagheader('tbody', 'pageqrcode', !empty($this->setting['pageqrcode']['enable']), 'sub');
		duceapp_showsetting('setting_pageqrtext', 'settingnew[pageqrcode][text]', dhtmlspecialchars($this->setting['pageqrcode']['text']), 'text');
		duceapp_showsetting('setting_pageqrpos', 'settingnew[pageqrcode][pos]', $this->setting['pageqrcode']['pos'], 'text');
		showtagfooter('tbody');
		duceapp_showsetting('style_showalert', array('settingnew[showalert]', array(
			array(0, duceapp_cplang('style_showalert_0')),
			array(1, duceapp_cplang('style_showalert_1')),
		), 1), intval($this->setting['showalert']), 'mradio');
		showsubmit('duceapp_submit');
		duceapp_anchorfooter();

		showtagfooter('div');

		showformfooter();
	}

	private function save() {
		global $_G;
		$setting = $_GET['settingnew'];
		
		$this->setting['thumbwidth'] = intval($setting['thumbwidth']);
		$this->setting['bdapikey'] = trim($setting['bdapikey']);
		$this->setting['watermark']['adduser'] = intval($setting['watermarkadduser']);
		$this->setting['watermark']['type'] = $setting['watermarktype'];
		$this->setting['watermark']['text'] = trim($setting['watermarktext']);
		$this->setting['watermark']['size'] = intval($setting['watermarksize']);
		$this->setting['watermark']['fontpath'] = $setting['watermarkfontpath'];
		$setting['pageqrcode']['enable'] = intval($setting['pageqrcode']['enable']);
		$setting['pageqrcode']['text'] = trim($setting['pageqrcode']['text']);
		$setting['pageqrcode']['pos'] = intval($setting['pageqrcode']['pos']);
		$this->setting['pageqrcode'] = $setting['pageqrcode'];

		if ($_FILES['sharelogo']['tmp_name']) {
			if (!preg_match('/^image/', $_FILES['sharelogo']['type'])) {
				$this->error('wechat_sharelogo_error');
			}
			$filename = 'sharelogo.'.fileext($_FILES['sharelogo']['name']);
			duceapp_writeimage(DISCUZ_ROOT.DUCEAPP_DATAURL.$filename, $_FILES['sharelogo']['tmp_name']);
			$this->setting['sharelogo'] = $filename;
		}
		$this->setting['nofooter'] = intval($setting['nofooter']);
		$this->setting['showalert'] = intval($setting['showalert']);
		$this->setting['accbind'] = array();
		if ($setting['accbind']) {
			foreach(explode("\n", $setting['accbind']) as $ident) {
				if (trim($ident)){
					$this->setting['accbind'][] = trim($ident);
				}
			}
		}

		if ($setting['footerhtml'] = trim($setting['footerhtml'])) {
			@file_put_contents(DUCEAPP_DATAURL.'footerhtml.php', $setting['footerhtml']);
			$this->setting['footerhtml'] = 1;
		} else {
			$this->setting['footerhtml'] = 0;
		}

		if (in_array('duceapp_template', $_G['setting']['plugins']['available'])) {
			loadcache('duceapp_template');
			$_G['cache']['duceapp_template']['surface']['fontweight'] = intval($_GET['styles']['fontweight']);
			savecache('duceapp_template', $_G['cache']['duceapp_template']);
		}

		duceapp_initcommoncss($_GET['styles']);

		duceapp_succeed();
	}
}

new duceapp_modcp;