<?php

/**
 * Copyright (c) 2011 by duceapp.cn
 * Author: Hoolan Chan
 * Created: 2019-02-10
 * Version: 3.01001
 * Date: 2021-06-30 22:19:57
 * File: enable.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://www.duceapp.cn/
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

@include DISCUZ_ROOT.'./source/plugin/'.$dir.'/'.($pluginarray['installfile'] ? $pluginarray['installfile'] : 'install.php');

$finish = TRUE;