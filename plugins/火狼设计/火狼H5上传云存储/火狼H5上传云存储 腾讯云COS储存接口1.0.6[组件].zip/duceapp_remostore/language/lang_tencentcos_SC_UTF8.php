<?php

/**
 * Copyright (c) 2011 by dism.taobao.com
 * Author: Hoolan Chan
 * Created: 2021-07-20
 * Version: 3.10716
 * Date: 2021-08-24 04:43:51
 * File: lang_tencentcos.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$duceapp_compon_lang = array(
	'appver' => '1.0.6',
	'menu_api' => 'oss',
	'menu_order' => 1,
	'menu_title' => '腾讯云COS',
	'css' => 1,

	'anchors' => array(
		'basic' => array('real' => 1, 'title' => '接口参数'),
	),

	'appid' => 'AppId',
	'appid_comment' => '<a href="https://console.cloud.tencent.com/cam/capi" target="_blank">点此获取</a>',
	'secretid' => 'SecretId',
	'secretid_comment' => '腾讯云<a href="https://console.cloud.tencent.com/cam/capi" target="_blank">API密钥管理界面</a>获取',
	'secretkey' => 'SecretKey',
	'secretkey_comment' => '腾讯云<a href="https://console.cloud.tencent.com/cam/capi" target="_blank">API密钥管理界面</a>获取',
	'bucket' => '存储空间(Bucket)名称',
	'bucket_comment' => '填写对象储存 Bucket 名称，存储桶名称格式：BucketName-AppId，如果要新创建，名称后面可不加-AppId，创建时填写secretid相对应的AppId',
	'region' => '所属地域节点(Region)',
	'region_comment' => '腾讯云对象储存 / <u>Bucket概况页面</u> / <u>基本信息</u> / <u>所属地域</u>，示例：ap-shanghai',
	'region_0' => '选择地域：',
	'region_1' => '中国',
	'region_2' => '亚太地区',
	'region_3' => '欧洲地区',
	'region_4' => '北美地区',
	'region_ap-nanjing' => '南京',
	'region_ap-chengdu' => '成都',
	'region_ap-beijing' => '北京',
	'region_ap-guangzhou' => '广州',
	'region_ap-shanghai' => '上海',
	'region_ap-chongqing' => '重庆',
	'region_ap-beijing-fsi' => '北京金融',
	'region_ap-shanghai-fsi' => '上海金融',
	'region_ap-shenzhen-fsi' => '深圳金融',
	'region_ap-hongkong' => '中国香港',
	'region_ap-singapore' => '新加坡',
	'region_ap-mumbai' => '印度孟买',
	'region_ap-seoul' => '韩国首尔',
	'region_ap-bangkok' => '泰国曼谷',
	'region_ap-tokyo' => '日本东京',
	'region_eu-moscow' => '俄罗斯莫斯科',
	'region_eu-frankfurt' => '德国法兰克福',
	'region_na-toronto' => '加拿大多伦多',
	'region_na-ashburn' => '美国弗吉尼亚',
	'region_na-siliconvalley' => '美国硅谷',
	'domain' => '存储空间(Bucket)访问域名',
	'domain_comment' => '腾讯云对象储存 / <u>Bucket概况页面</u> / <u>域名信息</u> / <u>访问域名</u>，示例：https://duceapp-123456.cos.ap-shanghai.myqcloud.com',
	'remourl' => '存储空间(Bucket)访问网址',
	'remourl_comment' => '填写“http(s)”开头的Bucket访问网址，可前往腾讯云对象储存 / <u>Bucket名称</u> / <u>域名和传输管理</u> / <u>自定义源站域名</u> / <u>绑定域名</u> 或 使用 Bucket 访问域名',
	'imgStyleTips' => '<b>腾讯云COS，<a href="https://console.cloud.tencent.com/cos5/bucket/setting?type=ci&anchorType=image&bucketName='.$_G['cache']['duceapp_remostore']['server']['tencentcos']['bucket'].'&projectId=0&path=%252F&region='.$_G['cache']['duceapp_remostore']['server']['tencentcos']['region'].'" target="_blank">图片样式设置</a>，<a href="https://cloud.tencent.com/document/product/436/46823" target="_blank">设置教程</a></b>',
);