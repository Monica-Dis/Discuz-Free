<?php

/**
 * Copyright (c) 2011 by dism.taobao.com
 * Author: Hoolan Chan
 * Created: 2021-06-08
 * Version: 3.00905
 * Date: 2021-08-24 04:43:53
 * File: CosException.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

namespace Qcloud\Cos\Exception;

use Qcloud\Cos\Exception\ServiceResponseException;

class CosException extends ServiceResponseException {}