<?php

/**
 * Copyright (c) 2011 by dism.taobao.com
 * Author: Hoolan Chan
 * Created: 2021-06-26
 * Version: 3.10821
 * Date: 2021-08-22 23:59:48
 * File: cpavatar.class.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class duceapp_compon_cpavatar
{
	public function init(){
		$this->componvar = & $this->setting['cpavatar'];
		duceapp_showanchors();
		call_user_func(array(__CLASS__, $this->cpmethod));
	}

	private function main() {
		global $_G;
		duceapp_formheader();
		duceapp_anchortips('avatar_tips');
		duceapp_anchorheader();
		duceapp_showsetting('available', array('setting[available]', array(
			duceapp_cplang('available_1'),
			duceapp_cplang('available_2'),
		)), $this->componvar['available'], 'binmcheckbox');
		duceapp_showsetting('gifmaxsize', 'setting[gifmaxsize]', $this->componvar['gifmaxsize'], 'text');
		duceapp_showsetting('forcestatic', 'setting[forcestatic]', $this->componvar['forcestatic']);
		duceapp_showsetting('tplrefresh', 'setting[tplrefresh]', $this->componvar['tplrefresh']);
		showsubmit('submit');
		duceapp_anchorfooter();
		showformfooter(); /*Dism_taobao-com*/
	}

	private function save() {
		global $_G;

		$available = '';
		for($i = 2; $i >= 1; $i--) {
			$available .= intval($_GET['setting']['available'][$i]);
		}
		$this->componvar['available'] = bindec($available);
		$this->componvar['gifmaxsize'] = intval($_GET['setting']['gifmaxsize']);
		$this->componvar['tplrefresh'] = intval($_GET['setting']['tplrefresh']);
		$this->componvar['forcestatic'] = intval($_GET['setting']['forcestatic']);

		@unlink(DISCUZ_ROOT.'./data/template/'.$_G['style']['styleid'].'_'.$_G['style']['templateid'].'_home_spacecp_avatar_body.tpl.php');
		
		duceapp_succeed();
	}
}