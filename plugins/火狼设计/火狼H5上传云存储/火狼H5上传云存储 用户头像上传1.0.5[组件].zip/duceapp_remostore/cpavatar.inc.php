<?php

/**
 * Copyright (c) 2011 by dism.taobao.com
 * Author: Hoolan Chan
 * Created: 2021-06-28
 * Version: 3.10628
 * Date: 2021-08-22 23:59:48
 * File: cpavatar.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$setting = $_G['cache']['duceapp_remostore']['cpavatar'];

$uc_datadir = DISCUZ_ROOT.'uc_server/data/';

$avatartype = $_GET['avatartype'] == 'real' ? 'real' : 'virtual';
$uid = isset($_GET['uid']) ? $_GET['uid'] : intval($_G['uid']);

$bigavatarfile = $uc_datadir.'./avatar/'.get_avatar($uid, 'big', $avatartype);
$middleavatarfile = $uc_datadir.'./avatar/'.get_avatar($uid, 'middle', $avatartype);
$smallavatarfile = $uc_datadir.'./avatar/'.get_avatar($uid, 'small', $avatartype);

$langpath = DISCUZ_ROOT.'./source/plugin/duceapp_remostore/language/';
@include file_exists($incfile = $langpath.'lang_cpavatar_'.currentlang().'.php') ? $incfile : $langpath.'lang_cpavatar.php';

dmkdir(dirname($bigavatarfile));
$upload = new discuz_upload();

if ($upload->init($_FILES["file"]) && $upload->save() && $upload->get_image_info($upload->attach['target'])) {
	if ($setting['gifmaxsize'] <= 0 || $upload->attach['size'] <= $setting['gifmaxsize'] * 1024) {		
		$tmp = parse_url($_G['setting']['ucenterurl']);
		$uc_root = $tmp['host'] == $_SERVER['HTTP_HOST'] && strpos($tmp['path'], '/uc_server') !== false ? DISCUZ_ROOT.'uc_server' : false;
		if (!$uc_root) {
			loaducenter();
			$request = UC_API.'/cpavatar.php?appid='.UC_APPID.'&input='.uc_api_input("uid=$uid").'&agent='.md5($_SERVER['HTTP_USER_AGENT']).
			'&ucapi='.urlencode(UC_API).'&avatartype='.$avatartype;
			if ($fp = @fopen($upload->attach['target'], 'rb')) {
				$avatar = urlencode(base64_encode(fread($fp, filesize($upload->attach['target']))));
				fclose($fp);
				@unlink($upload->attach['target']);
			} else {
				err_duceapp_upload($duceapp_compon_lang['err_upload']);
			}
			$res = uc_fopen($request, 0, 'avatar1='.$avatar);
			if ($res == 'success') {
				echo "<script>window.parent.postMessage('success', '*');</script>";
			} else {
				err_duceapp_upload($duceapp_compon_lang['err_upload']);
			}
		} else {
			@copy($upload->attach['target'], $bigavatarfile);
			@copy($upload->attach['target'], $middleavatarfile);
			@copy($upload->attach['target'], $smallavatarfile);
			@unlink($upload->attach['target']);

			$biginfo = @getimagesize($bigavatarfile);
			$middleinfo = @getimagesize($middleavatarfile);
			$smallinfo = @getimagesize($smallavatarfile);

			if (!$biginfo || !$middleinfo || !$smallinfo) {
				file_exists($bigavatarfile) && unlink($bigavatarfile);
				file_exists($middleavatarfile) && unlink($middleavatarfile);
				file_exists($smallavatarfile) && unlink($smallavatarfile);
				err_duceapp_upload($duceapp_compon_lang['err_upload']);
			} else {
				echo "<script>window.parent.postMessage('success', '*');</script>";
			}
		}
	} else {
		err_duceapp_upload(str_replace('{size}', $setting['gifmaxsize'], $duceapp_compon_lang['err_maxsize']));
	}
} else {
	err_duceapp_upload($duceapp_compon_lang['err_upload']);
}

function err_duceapp_upload($msg) {
	echo "<script>parent.duceapp_showmsg('".addslashes($msg, "'")."');</script>";
	exit;
}

function get_avatar($uid, $size = 'middle', $type = '') {
	$size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	$uid = abs(intval($uid));
	$uid = sprintf("%09d", $uid);
	$dir1 = substr($uid, 0, 3);
	$dir2 = substr($uid, 3, 2);
	$dir3 = substr($uid, 5, 2);
	$typeadd = $type == 'real' ? '_real' : '';
	return $dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).$typeadd."_avatar_$size.jpg";
}