<?php

/**
 * Copyright (c) 2011 by dism.taobao.com
 * Author: Hoolan Chan
 * Created: 2021-06-26
 * Version: 3.10822
 * Date: 2021-08-22 23:59:48
 * File: lang_cpavatar.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$duceapp_compon_lang = array(
	'appver' => '1.0.5',
	'menu_order' => 0,
	'menu_title' => '頭像上傳',

	'anchors' => array(
		'basic' => array('real' => 1, 'title' => '基本參數'),
	),

	'avatar_tips' => '<li><span style="color:red">如果站點的UCenter為獨立安裝，請把插件目錄/install/cpavatar.php複製到UCenter根目錄下</span></li>',
	'available' => '開啟上傳功能',
	'available_1' => '電腦端頭像上傳',
	'available_2' => '手機端頭像上傳',
	'available_comment' => '如果和已有頭像上傳插件衝突，請取消選擇相關選項或關閉其他頭像上傳插件<br />手機端模板如自帶頭像上傳功能，此處無需勾選，如<a href="javascript:;">火狼手機模板</a>',
	'gifmaxsize' => '限製GIF頭像大小(KB)',
	'gifmaxsize_comment' => '避免用戶上傳較大的GIF圖片，導致前台頭像加載緩慢影響其他用戶訪問體驗，建議設置限製在500KB內，0為不限製',
	'tplrefresh' => '電腦端頭像裁剪區替換原有代碼',
	'tplrefresh_comment' => '選擇“是”，插件將直接替換原有代碼的模板緩存，如恢複原有代碼需清除模板緩存，選擇“否"以frame嵌套方式',
	'forcestatic' => '強製靜態地址調用頭像',
	'forcestatic_comment' => '百度收錄快照頁如果不能正常顯示頭像，可強製靜態地址調用頭像。',

	'err_maxsize' => '頭像文件不能超出 {size} KB',
	'err_upload' => '文件上傳失敗',
);