<?php

/**
 * Copyright (c) 2011 by dism.taobao.com
 * Author: Hoolan Chan
 * Created: 2021-06-26
 * Version: 3.10822
 * Date: 2021-08-22 23:59:48
 * File: lang_cpavatar.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$duceapp_compon_lang = array(
	'appver' => '1.0.5',
	'menu_order' => 0,
	'menu_title' => '头像上传',

	'anchors' => array(
		'basic' => array('real' => 1, 'title' => '基本参数'),
	),

	'avatar_tips' => '<li><span style="color:red">如果站点的UCenter为独立安装，请把插件目录/install/cpavatar.php复制到UCenter根目录下</span></li>',
	'available' => '开启上传功能',
	'available_1' => '电脑端头像上传',
	'available_2' => '手机端头像上传',
	'available_comment' => '如果和已有头像上传插件冲突，请取消选择相关选项或关闭其他头像上传插件<br />手机端模板如自带头像上传功能，此处无需勾选，如<a href="javascript:;">火狼手机模板</a>',
	'gifmaxsize' => '限制GIF头像大小(KB)',
	'gifmaxsize_comment' => '避免用户上传较大的GIF图片，导致前台头像加载缓慢影响其他用户访问体验，建议设置限制在500KB内，0为不限制',
	'tplrefresh' => '电脑端头像裁剪区替换原有代码',
	'tplrefresh_comment' => '选择“是”，插件将直接替换原有代码的模板缓存，如恢复原有代码需清除模板缓存，选择“否"以frame嵌套方式',
	'forcestatic' => '强制静态地址调用头像',
	'forcestatic_comment' => '百度收录快照页如果不能正常显示头像，可强制静态地址调用头像。',

	'err_maxsize' => '头像文件不能超出 {size} KB',
	'err_upload' => '文件上传失败',
);