<?php

/**
 * Copyright (c) 2011 by dism.taobao.com
 * Author: Hoolan Chan
 * Created: 2021-07-20
 * Version: 3.10720
 * Date: 2021-08-24 04:43:51
 * File: lang_huaweiobs.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$duceapp_compon_lang = array(
	'appver' => '1.0.7',
	'menu_api' => 'oss',
	'menu_order' => 4,
	'menu_title' => '華為雲OBS',
	'css' => 1,

	'anchors' => array(
		'basic' => array('real' => 1, 'title' => '接口參數'),
	),

	'accessid' => '帳號ID',
	'accessid_comment' => '華為雲<a href="https://console.huaweicloud.com/iam/#/mine/apiCredential" target="_blank">我的憑證</a> &gt; <u>API憑證</u> 獲取',
	'accesskey' => 'Access Key ID',
	'accesskey_comment' => '華為雲<a href="https://console.huaweicloud.com/iam/#/mine/apiCredential" target="_blank">我的憑證</a> &gt; <u>訪問密鑰</u> 獲取',
	'secretkey' => 'Secret Access Key',
	'secretkey_comment' => '華為雲<a href="https://console.huaweicloud.com/iam/#/mine/apiCredential" target="_blank">我的憑證</a> &gt; <u>訪問密鑰</u> 獲取',
	'bucket' => '存儲空間(Bucket)名稱',
	'bucket_comment' => '填寫對象存儲空間 Bucket 名稱，如果 Bucket 不存在，提交後可創建',
	'endpoint' => '訪問節點(EndPoint)',
	'endpoint_comment' => '華為雲對象儲存 / <u>Bucket概覽</u> / <u>基本信息</u> / <b>Endpoint</b>，示例：obs.cn-east-3.myhuaweicloud.com',
	'domain' => '存儲空間(Bucket)訪問域名',
	'domain_comment' => '華為雲對象儲存 / <u>Bucket概覽</u> / <u>基本信息</u> / 訪問域名',
	'remourl' => '存儲空間(Bucket)訪問域名',
	'remourl_comment' => '填寫“http(s)”開頭的Bucket訪問域名，華為雲對象儲存 / <u>Bucket概覽</u> / <u>基本信息</u> / <b>訪問域名</b> 或 <u>域名管理</u> / <u>綁定域名</u>',
	'endpoint_emptyerr' => '訪問節點(EndPoint)不能為空',
	'endpoint_region' => '選擇區域：',
	'endpoint_cn-north-4' => '華北-北京四',
	'endpoint_cn-east-3' => '華東-上海一',
	'endpoint_cn-south-1' => '華南-廣州',
	'endpoint_cn-south-4' => '華南-廣州-友好用戶環境',
	'endpoint_cn-southwest-2' => '西南-貴陽一',
	'endpoint_ap-southeast-1' => '亞太-香港',
	'endpoint_ap-southeast-2' => '亞太-曼穀',
	'endpoint_ap-southeast-3' => '亞太-新加坡',
	'endpoint_na-mexico-1' => '拉美-墨西哥城一',
	'endpoint_sa-brazil-1' => '拉美-聖保羅一',
	'endpoint_la-south-2' => '拉美-聖地亞哥',
	'endpoint_af-south-1' => '非洲-約翰內斯堡',
	'imgStyleTips' => '<b>華為雲OBS，<a href="https://console.huaweicloud.com/console/?#/obs/manage/'.$_G['cache']['duceapp_remostore']['server']['baidubos']['bucket'].'/image/styles" target="_blank">圖片樣式設置</a>，<a href="https://support.huaweicloud.com/fg-obs/obs_01_0310.html" target="_blank">設置教程</a></b>',
);