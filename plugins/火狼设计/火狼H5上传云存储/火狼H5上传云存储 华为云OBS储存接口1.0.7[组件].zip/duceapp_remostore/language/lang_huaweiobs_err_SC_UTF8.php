<?php

/**
 * Copyright (c) 2011 by dism.taobao.com
 * Author: Hoolan Chan
 * Created: 2021-07-20
 * Version: 3.10714
 * Date: 2021-08-24 04:43:51
 * File: lang_huaweiobs_err.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$duceapp_compon_lang = array(
	'permanentredirect' => '尝试访问的桶必须使用指定的地址，请将以后的请求发送到这个地址。',
	'websiteredirect' => 'Website请求缺少bucketName。',
	'temporaryredirect' => '临时重定向，当DNS更新时，请求将被重定向到桶。',
	'baddigest' => '客户端指定的对象内容的md5值与系统接收到的内容md5值不一致。',
	'baddomainname' => '域名不合法。',
	'badrequest' => '请求参数不合法。',
	'customdomainareadyexist' => '配置了已存在的域。',
	'customdomainnotexist' => '删除不存在的域。',
	'entitytoolarge' => '用户POST上传的对象大小超过了条件允许的最大大小。',
	'entitytoosmall' => '用户POST上传的对象大小小于条件允许的最小大小。',
	'illegallocationconstraintexception' => '用户未带Location在非默认Region创桶。',
	'incompletebody' => '由于网络原因或其他问题导致请求体未接受完整。',
	'incorrectnumberoffilesinpostrequest' => '每个POST请求都需要带一个上传的文件。',
	'invalidargument' => '无效的参数。',
	'invalidbucket' => '请求访问的桶已不存在。',
	'invalidbucketname' => '请求中指定的桶名无效，超长或带不允许的特殊字符。',
	'invalidencryptionalgorithmerror' => '错误的加密算法。下载SSE-C加密的对象，携带的加密头域错误，导致不能解密。',
	'invalidlocationconstraint' => '创建桶时，指定的Location不合法或不存在。',
	'invalidpart' => '一个或多个指定的段无法找到。这些段可能没有上传，或者指定的entity tag与段的entity tag不一致。',
	'invalidpartorder' => '段列表的顺序不是升序，段列表必须按段号升序排列。',
	'invalidpolicydocument' => '表单中的内容与策略文档中指定的条件不一致。',
	'invalidredirectlocation' => '无效的重定向地址。',
	'invalidrequest' => '无效请求。',
	'invalidrequestbody' => '请求体无效，需要消息体的请求没有上传消息体。',
	'invalidtargetbucketforlogging' => 'delivery group对目标桶无acl权限。',
	'keytoolongerror' => '提供的key过长。',
	'kms.disabledexception' => 'SSE-KMS加密方式下，主密钥被禁用。',
	'kms.notfoundexception' => 'SSE-KMS加密方式下，主密钥不存在。',
	'malformedaclerror' => '提供的XML格式错误，或者不符合我们要求的格式。',
	'malformederror' => '请求中携带的XML格式不正确。',
	'malformedloggingstatus' => 'Logging的XML格式不正确。',
	'malformedpolicy' => 'Bucket policy检查不通过。',
	'malformedquotaerror' => 'Quota的XML格式不正确。',
	'malformedxml' => '当用户发送了一个配置项的错误格式的XML会出现这样的错误。',
	'maxmessagelengthexceeded' => '拷贝对象，带请求消息体。',
	'metadatatoolarge' => '元数据消息头超过了允许的最大元数据大小。',
	'missingregion' => '请求中缺少region信息，且系统无默认region。',
	'missingrequestbodyerror' => '当用户发送一个空的XML文档作为请求时会发生。',
	'missingrequiredheader' => '请求中缺少必要的头域。',
	'missingsecurityheader' => '请求缺少一个必须的头。',
	'toomanybuckets' => '用户拥有的桶的数量达到了系统的上限，并且请求试图创建一个新桶。',
	'toomanycustomdomains' => '配置了过多的用户域',
	'toomanywrongsignature' => '因高频错误请求被拒绝服务。',
	'unexpectedcontent' => '该请求需要消息体而客户端没带，或该请求不需要消息体而客户端带了。',
	'userkeymustbespecified' => '该操作只有特殊用户可使用。',
	'accessdenied' => '拒绝访问，请求没有携带日期头域或者头域格式错误。',
	'accessforbidden' => '权限不足，桶未配置CORS或者CORS规则不匹配。',
	'allaccessdisabled' => '用户无权限执行某操作。桶名为禁用关键字。',
	'deregisteruserid' => '用户已经注销。',
	'inarrearorinsufficientbalance' => '用户欠费或余额不足而没有权限进行某种操作。',
	'insufficientstoragespace' => '存储空间不足。',
	'invalidaccesskeyid' => '系统记录中不存在客户提供的Access Key Id。',
	'invalidobjectstate' => '归档对象不能直接下载，需要先进行取回才能下载。',
	'notsignedup' => '你的帐户还没有在系统中注册，必须先在系统中注册了才能使用该帐户。',
	'requesttimetooskewed' => '请求的时间与服务器的时间相差太大。',
	'signaturedoesnotmatch' => '请求中带的签名与系统计算得到的签名不一致。',
	'virtualhostdomainrequired' => '未使用虚拟主机访问域名。',
	'unauthorized' => '用户未实名认证。',
	'nosuchbucket' => '指定的桶不存在。',
	'nosuchbucketpolicy' => '桶policy不存在。',
	'nosuchcorsconfiguration' => 'CORS配置不存在。',
	'nosuchcustomdomain' => '请求的用户域不存在。',
	'nosuchkey' => '指定的key不存在。',
	'nosuchlifecycleconfiguration' => '请求的lifeCycle不存在。',
	'nosuchupload' => '指定的多段上传不存在。upload id不存在，或者多段上传已经终止或完成。',
	'nosuchversion' => '请求中指定的version id与现存的所有版本都不匹配。',
	'nosuchwebsiteconfiguration' => '请求的Website不存在。',
	'methodnotallowed' => '指定的方法不允许操作在请求的资源上。',
	'requesttimeout' => '用户与Server之间的Socket连接在超时时间内没有进行读写操作。',
	'bucketalreadyexists' => '请求的桶名已经存在。桶的命名空间是系统中所有用户共用的，选择一个不同的桶名再重试一次。',
	'bucketalreadyownedbyyou' => '发起该请求的用户已经创建过了这个名字的桶，并拥有这个桶。',
	'bucketnotempty' => '用户尝试删除的桶不为空。',
	'invalidbucketstate' => '无效的桶状态，配置跨region复制后不允许关闭桶多版本。',
	'operationaborted' => '另外一个冲突的操作当前正作用在这个资源上，请重试。',
	'servicenotsupported' => '请求的方法服务端不支持。',
	'missingcontentlength' => '必须要提供http消息头中的content-length字段。',
	'preconditionfailed' => '用户指定的先决条件中至少有一项没有包含。',
	'invalidrange' => '请求的range不可获得。',
	'internalerror' => '系统遇到内部错误，请重试。',
	'servicenotimplemented' => '请求的方法服务端没有实现。',
	'serviceunavailable' => '服务器过载或者内部错误异常。',
	'slowdown' => '请降低请求频率。',
);