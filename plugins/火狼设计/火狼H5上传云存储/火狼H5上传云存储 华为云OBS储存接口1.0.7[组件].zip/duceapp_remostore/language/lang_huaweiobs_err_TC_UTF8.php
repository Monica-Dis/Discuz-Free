<?php

/**
 * Copyright (c) 2011 by dism.taobao.com
 * Author: Hoolan Chan
 * Created: 2021-07-20
 * Version: 3.10714
 * Date: 2021-08-24 04:43:51
 * File: lang_huaweiobs_err.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$duceapp_compon_lang = array(
	'permanentredirect' => '嚐試訪問的桶必須使用指定的地址，請將以後的請求發送到這個地址。',
	'websiteredirect' => 'Website請求缺少bucketName。',
	'temporaryredirect' => '臨時重定向，當DNS更新時，請求將被重定向到桶。',
	'baddigest' => '客戶端指定的對象內容的md5值與係統接收到的內容md5值不一致。',
	'baddomainname' => '域名不合法。',
	'badrequest' => '請求參數不合法。',
	'customdomainareadyexist' => '配置了已存在的域。',
	'customdomainnotexist' => '刪除不存在的域。',
	'entitytoolarge' => '用戶POST上傳的對象大小超過了條件允許的最大大小。',
	'entitytoosmall' => '用戶POST上傳的對象大小小於條件允許的最小大小。',
	'illegallocationconstraintexception' => '用戶未帶Location在非默認Region創桶。',
	'incompletebody' => '由於網絡原因或其他問題導致請求體未接受完整。',
	'incorrectnumberoffilesinpostrequest' => '每個POST請求都需要帶一個上傳的文件。',
	'invalidargument' => '無效的參數。',
	'invalidbucket' => '請求訪問的桶已不存在。',
	'invalidbucketname' => '請求中指定的桶名無效，超長或帶不允許的特殊字符。',
	'invalidencryptionalgorithmerror' => '錯誤的加密算法。下載SSE-C加密的對象，攜帶的加密頭域錯誤，導致不能解密。',
	'invalidlocationconstraint' => '創建桶時，指定的Location不合法或不存在。',
	'invalidpart' => '一個或多個指定的段無法找到。這些段可能沒有上傳，或者指定的entity tag與段的entity tag不一致。',
	'invalidpartorder' => '段列表的順序不是升序，段列表必須按段號升序排列。',
	'invalidpolicydocument' => '表單中的內容與策略文檔中指定的條件不一致。',
	'invalidredirectlocation' => '無效的重定向地址。',
	'invalidrequest' => '無效請求。',
	'invalidrequestbody' => '請求體無效，需要消息體的請求沒有上傳消息體。',
	'invalidtargetbucketforlogging' => 'delivery group對目標桶無acl權限。',
	'keytoolongerror' => '提供的key過長。',
	'kms.disabledexception' => 'SSE-KMS加密方式下，主密鑰被禁用。',
	'kms.notfoundexception' => 'SSE-KMS加密方式下，主密鑰不存在。',
	'malformedaclerror' => '提供的XML格式錯誤，或者不符合我們要求的格式。',
	'malformederror' => '請求中攜帶的XML格式不正確。',
	'malformedloggingstatus' => 'Logging的XML格式不正確。',
	'malformedpolicy' => 'Bucket policy檢查不通過。',
	'malformedquotaerror' => 'Quota的XML格式不正確。',
	'malformedxml' => '當用戶發送了一個配置項的錯誤格式的XML會出現這樣的錯誤。',
	'maxmessagelengthexceeded' => '拷貝對象，帶請求消息體。',
	'metadatatoolarge' => '元數據消息頭超過了允許的最大元數據大小。',
	'missingregion' => '請求中缺少region信息，且係統無默認region。',
	'missingrequestbodyerror' => '當用戶發送一個空的XML文檔作為請求時會發生。',
	'missingrequiredheader' => '請求中缺少必要的頭域。',
	'missingsecurityheader' => '請求缺少一個必須的頭。',
	'toomanybuckets' => '用戶擁有的桶的數量達到了係統的上限，並且請求試圖創建一個新桶。',
	'toomanycustomdomains' => '配置了過多的用戶域',
	'toomanywrongsignature' => '因高頻錯誤請求被拒絕服務。',
	'unexpectedcontent' => '該請求需要消息體而客戶端沒帶，或該請求不需要消息體而客戶端帶了。',
	'userkeymustbespecified' => '該操作隻有特殊用戶可使用。',
	'accessdenied' => '拒絕訪問，請求沒有攜帶日期頭域或者頭域格式錯誤。',
	'accessforbidden' => '權限不足，桶未配置CORS或者CORS規則不匹配。',
	'allaccessdisabled' => '用戶無權限執行某操作。桶名為禁用關鍵字。',
	'deregisteruserid' => '用戶已經注銷。',
	'inarrearorinsufficientbalance' => '用戶欠費或餘額不足而沒有權限進行某種操作。',
	'insufficientstoragespace' => '存儲空間不足。',
	'invalidaccesskeyid' => '係統記錄中不存在客戶提供的Access Key Id。',
	'invalidobjectstate' => '歸檔對象不能直接下載，需要先進行取回才能下載。',
	'notsignedup' => '你的帳戶還沒有在係統中注冊，必須先在係統中注冊了才能使用該帳戶。',
	'requesttimetooskewed' => '請求的時間與服務器的時間相差太大。',
	'signaturedoesnotmatch' => '請求中帶的簽名與係統計算得到的簽名不一致。',
	'virtualhostdomainrequired' => '未使用虛擬主機訪問域名。',
	'unauthorized' => '用戶未實名認證。',
	'nosuchbucket' => '指定的桶不存在。',
	'nosuchbucketpolicy' => '桶policy不存在。',
	'nosuchcorsconfiguration' => 'CORS配置不存在。',
	'nosuchcustomdomain' => '請求的用戶域不存在。',
	'nosuchkey' => '指定的key不存在。',
	'nosuchlifecycleconfiguration' => '請求的lifeCycle不存在。',
	'nosuchupload' => '指定的多段上傳不存在。upload id不存在，或者多段上傳已經終止或完成。',
	'nosuchversion' => '請求中指定的version id與現存的所有版本都不匹配。',
	'nosuchwebsiteconfiguration' => '請求的Website不存在。',
	'methodnotallowed' => '指定的方法不允許操作在請求的資源上。',
	'requesttimeout' => '用戶與Server之間的Socket連接在超時時間內沒有進行讀寫操作。',
	'bucketalreadyexists' => '請求的桶名已經存在。桶的命名空間是係統中所有用戶共用的，選擇一個不同的桶名再重試一次。',
	'bucketalreadyownedbyyou' => '發起該請求的用戶已經創建過了這個名字的桶，並擁有這個桶。',
	'bucketnotempty' => '用戶嚐試刪除的桶不為空。',
	'invalidbucketstate' => '無效的桶狀態，配置跨region複製後不允許關閉桶多版本。',
	'operationaborted' => '另外一個衝突的操作當前正作用在這個資源上，請重試。',
	'servicenotsupported' => '請求的方法服務端不支持。',
	'missingcontentlength' => '必須要提供http消息頭中的content-length字段。',
	'preconditionfailed' => '用戶指定的先決條件中至少有一項沒有包含。',
	'invalidrange' => '請求的range不可獲得。',
	'internalerror' => '係統遇到內部錯誤，請重試。',
	'servicenotimplemented' => '請求的方法服務端沒有實現。',
	'serviceunavailable' => '服務器過載或者內部錯誤異常。',
	'slowdown' => '請降低請求頻率。',
);