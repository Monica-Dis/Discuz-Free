<?php

/**
 * Copyright (c) 2011 by dism.taobao.com
 * Author: Hoolan Chan
 * Created: 2021-07-20
 * Version: 3.10720
 * Date: 2021-08-24 04:43:51
 * File: lang_huaweiobs.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$duceapp_compon_lang = array(
	'appver' => '1.0.7',
	'menu_api' => 'oss',
	'menu_order' => 4,
	'menu_title' => '华为云OBS',
	'css' => 1,

	'anchors' => array(
		'basic' => array('real' => 1, 'title' => '接口参数'),
	),

	'accessid' => '帐号ID',
	'accessid_comment' => '华为云<a href="https://console.huaweicloud.com/iam/#/mine/apiCredential" target="_blank">我的凭证</a> &gt; <u>API凭证</u> 获取',
	'accesskey' => 'Access Key ID',
	'accesskey_comment' => '华为云<a href="https://console.huaweicloud.com/iam/#/mine/apiCredential" target="_blank">我的凭证</a> &gt; <u>访问密钥</u> 获取',
	'secretkey' => 'Secret Access Key',
	'secretkey_comment' => '华为云<a href="https://console.huaweicloud.com/iam/#/mine/apiCredential" target="_blank">我的凭证</a> &gt; <u>访问密钥</u> 获取',
	'bucket' => '存储空间(Bucket)名称',
	'bucket_comment' => '填写对象存储空间 Bucket 名称，如果 Bucket 不存在，提交后可创建',
	'endpoint' => '访问节点(EndPoint)',
	'endpoint_comment' => '华为云对象储存 / <u>Bucket概览</u> / <u>基本信息</u> / <b>Endpoint</b>，示例：obs.cn-east-3.myhuaweicloud.com',
	'domain' => '存储空间(Bucket)访问域名',
	'domain_comment' => '华为云对象储存 / <u>Bucket概览</u> / <u>基本信息</u> / 访问域名',
	'remourl' => '存储空间(Bucket)访问域名',
	'remourl_comment' => '填写“http(s)”开头的Bucket访问域名，华为云对象储存 / <u>Bucket概览</u> / <u>基本信息</u> / <b>访问域名</b> 或 <u>域名管理</u> / <u>绑定域名</u>',
	'endpoint_emptyerr' => '访问节点(EndPoint)不能为空',
	'endpoint_region' => '选择区域：',
	'endpoint_cn-north-4' => '华北-北京四',
	'endpoint_cn-east-3' => '华东-上海一',
	'endpoint_cn-south-1' => '华南-广州',
	'endpoint_cn-south-4' => '华南-广州-友好用户环境',
	'endpoint_cn-southwest-2' => '西南-贵阳一',
	'endpoint_ap-southeast-1' => '亚太-香港',
	'endpoint_ap-southeast-2' => '亚太-曼谷',
	'endpoint_ap-southeast-3' => '亚太-新加坡',
	'endpoint_na-mexico-1' => '拉美-墨西哥城一',
	'endpoint_sa-brazil-1' => '拉美-圣保罗一',
	'endpoint_la-south-2' => '拉美-圣地亚哥',
	'endpoint_af-south-1' => '非洲-约翰内斯堡',
	'imgStyleTips' => '<b>华为云OBS，<a href="https://console.huaweicloud.com/console/?#/obs/manage/'.$_G['cache']['duceapp_remostore']['server']['baidubos']['bucket'].'/image/styles" target="_blank">图片样式设置</a>，<a href="https://support.huaweicloud.com/fg-obs/obs_01_0310.html" target="_blank">设置教程</a></b>',
);