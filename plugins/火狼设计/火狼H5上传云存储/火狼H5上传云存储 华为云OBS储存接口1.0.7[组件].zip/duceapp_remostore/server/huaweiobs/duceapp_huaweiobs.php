<?php

/**
 * Copyright (c) 2011 by dism.taobao.com
 * Author: Hoolan Chan
 * Created: 2021-07-20
 * Version: 3.10720
 * Date: 2021-08-24 04:43:51
 * File: duceapp_huaweiobs.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

use Obs\ObsClient;
use Obs\ObsException;

class duceapp_huaweiobs extends duceapp_ossbase
{
	public function __construct($config) {
		global $_G;
		$this->config = $config;
		$this->bucket = $config['bucket'];
		$this->basedir = $config['basedir'];
		$config = array(
			'key' => $config['accesskey'],
			'secret' => $config['secretkey'],
			'endpoint' => $config['endpoint'] ? $config['endpoint'] : 'obs.cn-east-3.myhuaweicloud.com',
			'socket_timeout' => 60,
			'connect_timeout' => 10,
		);
		if (!$_G['isHTTPS']) {
			$this->config['domain'] = str_replace('https://', 'http://', $this->config['domain']);
		}
		$_G['cache']['duceapp_remostore']['directoss']['image'] = $_G['cache']['duceapp_remostore']['directoss']['attach'] = 0;
		$this->client = ObsClient::factory($config);
	}

	public function getException($code, $message) {
		if ($code) {
			if ($errmsg = duceapp_remostore_lang('huaweiobs_err', strtolower(str_replace(' ', '', $code)))) {
				throw(new Obs\ObsException($errmsg));
			}
			throw(new Obs\ObsException('Error Code: '.$code.' , <a href="https://support.huaweicloud.com/api-obs/obs_04_0115.html" target="_blank">Go Support</a>'));
		} else {
			throw(new Obs\ObsException($message));
		}
	}

	public function createBucket($bucket) {
		if (!defined('IN_ADMINCP')) {
			return;
		}
		try {
			list(,$region) = explode('.', $this->config['endpoint']);
			$this->client->createBucket(array(
				'Bucket' => $bucket,
				'ACL' => ObsClient::AclPublicRead,
				'StorageClass' => ObsClient::StorageClassStandard,
				'LocationConstraint' => $region,
			));
			$this->bucket = $bucket;
		} catch(Exception $e) {
			if ($this->config['debug']) {
				$this->getException($e->getExceptionCode(), $e->getMessage());
			}
            return 0;
        }
		return 1;
	}

	public function bucketExist($bucket) {
		try {
			$resp = $this->client->headBucket(array('Bucket' => $bucket));
			return $resp['Location'];
		} catch(Exception $e) {
            return 0;
        }
	}

	public function checkRes() {
		try {
			$res = array();
			$res[0] = $this->client->putObject(array(
				'Bucket' => $this->bucket,
				'Key' => 'test.txt',
				'Body' => 'test'
			));
			$file = __DIR__ . 'test.txt';
			$this->client->getObject(array(
				'Bucket' => $this->bucket,
				'Key' => 'test.txt',
				'SaveAsFile' => $file,
			));
			if (file_exists($file)) {
				$res[1] = 1;
				@unlink($file);
			}
			$content = $this->fileSock($this->config['remourl'].'test.txt');
			if ($content) {
				$res[2] = 1;
			}
			$res[0] && $this->client->deleteObject(array(
				'Bucket' => $this->bucket,
				'Key' => 'test.txt',
			));
			return $res;
		} catch(Exception $e) {
			throw(new OSS\Core\OssException($e->getMessage()));
		}
	}

	public function setReferer() {
	}

	public function setCors() {
		try {
			/*$scheme = 'http';
			if ((isset($_SERVER["HTTPS"]) && strtolower($_SERVER["HTTPS"]) != "off") ||
				(isset($_SERVER["HTTP_X_FORWARDED_PROTO"]) && strtolower($_SERVER["HTTP_X_FORWARDED_PROTO"]) == "https") ||
				(isset($_SERVER["HTTP_SCHEME"]) && strtolower($_SERVER["HTTP_SCHEME"]) == "https") || 
				(isset($_SERVER["HTTP_FROM_HTTPS"]) && strtolower($_SERVER["HTTP_FROM_HTTPS"]) != "off") ||
				(isset($_SERVER["SERVER_PORT"]) && $_SERVER["SERVER_PORT"] == 443)) {
				$scheme .= 's';
			}*/
			$this->client->setBucketCors(array(
				'Bucket' => $this->bucket,
				'CorsRules' => array(array(
					'ID' => 'duceapp',
					'AllowedMethod' => array('POST', 'GET'),
					'AllowedOrigin' => array('*'),
					'AllowedHeader'=> array('*'),
					'MaxAgeSeconds' => 120,
				)),
			));
		} catch (Exception $e){
			if ($this->config['debug']) {
				$this->getException($e->getExceptionCode(), $e->getMessage());
			}
			return 0;
		}
		return 1;
	}	

	public function objectExists($object) {
		try {
			$res = $this->client->getObjectMetadata(array(
				'Bucket' => $this->bucket,
				'Key' => $this->basedir.$object,
			));
            return $res && $res['HttpStatusCode'] == 200 ? $this->config['remourl'].$this->basedir.$object : 0;
        } catch(Exception $e) {
            return 0;
        }
	}

	public function getFileslist($prefix = '', $marker = '', $limit = 100, $delimiter = '') {
		$res = array(
			'marker' => $marker,
			'run' => 0,
			'items' => array(),
		);
		while (true) {
			try {
				$listObjectInfo = $this->client->listObjects(array(
					'Bucket' => $this->bucket,
					'MaxKeys' => $limit > 0 ? $limit : 100,
					'Prefix' => $prefix,
					'Marker' => $res['marker'],
				));
			} catch (Exception $e) {
				return array();
			}
			$res['marker'] = $listObjectInfo['NextMarker'];
			if (!empty($listObjectInfo['Contents'])) {
				foreach ($listObjectInfo['Contents'] as $object) {
					$res['items'][] = array(
						'key' => $object['Key'],
						'size' => $object['Size'],
						'filemtime' => strtotime($object['LastModified']),
					);
				}
			}
			$res['run']++;
			if ($limit > 0 || empty($res['marker'])) {
				break;
			}
		}
		return $res;
	}

	public function imageStyle($style) {
		if (empty($style)) {
			return '';
		}
		return 'x-image-process='.$style;
    }

	public function uploadFile($file, $object, $Acl = null) {
		try {
			if (!file_exists($file)) {
				return 0;
			}
			$this->client->putObject(array(
				'Bucket' => $this->bucket,
				'Key' => $this->basedir.$object,
				'SourceFile' => $file,
			));
			if ($Acl === null) {
				$Acl = $this->getAcl($file);
			}
			if ($Acl) {
				$Acl = $Acl == 'public' ? ObsClient::AclPublicRead : ObsClient::AclPrivate;
				$this->client->setObjectAcl(array(
					'Bucket' => $this->bucket,
					'Key' => $this->basedir.$object,
					'ACL' => $Acl,
				));
			}
		} catch (Exception $e) {
			if ($this->config['debug']) {
				$this->getException($e->getExceptionCode(), $e->getMessage());
			}
			return 0;
		}
		return 1;
	}

	public function uploadData($data, $object, $Acl = null, $fread = false) {
		try {
			$ret = 0;
			if ($fread) {
				$data = $this->fileSock($data);
			}
			if (empty($data)) {
				return 0;
			}
			if ($Acl === null) {
				$Acl = $this->getAcl($object);
			}
			$Acl = $Acl == 'public' || $Acl == 'public-read' ? ObsClient::AclPublicRead : ObsClient::AclPrivate;
			$ret = $this->client->putObject(array(
				'Bucket' => $this->bucket,
				'Key' => $this->basedir.$object,
				'Body' => $data,
				'ACL' => $Acl,
			));
		} catch (Exception $e) {
			if ($this->config['debug']) {
				$this->getException($e->getExceptionCode(), $e->getMessage());
			}
			return 0;
		}
		return $ret;
	}

	public function setAcl($object, $Acl = null) {
		try {
			$Acl = $Acl == 'public' || $Acl == 'public-read' ? ObsClient::AclPublicRead : ObsClient::AclPrivate;
			if ($Acl) {
				$this->client->setObjectAcl(array(
					'Bucket' => $this->bucket,
					'Key' => $this->basedir.$object,
					'ACL' => $Acl,
				));
			}
		} catch (Exception $e) {
			if ($this->config['debug']) {
				$this->getException($e->getExceptionCode(), $e->getMessage());
			}
			return 0;
		}
		return 1;       
	}

	public function renameObject($oldObject, $newObject, $MimeType = null) {
		try {
			if ($this->client->copyObject(array(
				'Bucket' => $this->bucket,
				'Key' => $this->basedir.$newObject,
				'CopySource' => $this->bucket.'/'.$this->basedir.$oldObject,
				))) {
				$this->client->deleteObject(array(
					'Bucket' => $this->bucket,
					'Key' => $this->basedir.$oldObject,
				));
			}
		} catch (Exception $e) {
			if ($this->config['debug']) {
				$this->getException($e->getExceptionCode(), $e->getMessage());
			}
			return 0;
		}
		return 1;
	}

	public function downFile($file, $object) {
		try {
			$this->client->getObject(array(
				'Bucket' => $this->bucket,
				'Key' => $this->basedir.$object,
				'SaveAsFile' => $file,
			));
		} catch (Exception $e) {
			if ($this->config['debug']) {
				$this->getException($e->getExceptionCode(), $e->getMessage());
			}
			return 0;
		}
		return 1;
	}

	public function deleteFile($objects) {
		try {
			if (is_array($objects)) {
				foreach($objects as $i => $object) {
					$objects[$i] = array('Key' => $this->basedir.$object, 'VersionId' => null);
				}
				$this->client->deleteObjects(array(
					'Bucket' => $this->bucket,
					'Quiet' => false,
					'Objects' => $objects,
				));
			} else {
				$this->client->deleteObject(array(
					'Bucket' => $this->bucket,
					'Key' => $this->basedir.$objects,
				));
			}
		} catch (Exception $e) {
			if ($this->config['debug']) {
				$this->getException($e->getExceptionCode(), $e->getMessage());
			}
			return 0;
		}
		return 1;
	}

	public function getPolicy($dir, $object, $length = 3048576000) {
		$expire = 3600;
		$dir = $this->basedir.$dir;
		$client = new ObsClient(array(
			'key' => $this->config['accesskey'],
			'secret' => $this->config['secretkey'],
			'endpoint' => $this->config['endpoint'],
			'signature' => 'obs',
		));
		try {
			$resp = $client->createPostSignature(array(
				'Expires' => $expire,
				/*'FormParams' => array(
					'x-obs-acl' => ObsClient::AclPrivate,
					'content-type' => 'text/plain',
				),*/
			));
		} catch (Exception $e) {
			return '{}';
		}
		$response = array(
			'accesskey' => $this->config['accesskey'],
			'policy' => $resp['Policy'],
			'signature' => $resp['Signature'],
			'expire' => $expire,
			'dir' => $dir,
			'object' => $object,
		);
		return json_encode($response);
	}

	public function signUrl($object, $filename = '', $expire = 3600) {
		empty($expire) && ($expire = 3600);
		$url = '';
		try {
			$resp = $this->client->createSignedUrl(array(
				'Method' => 'GET',
				'Bucket' => $this->bucket, 
				'Key' => $this->basedir.$object,
				'Expires' => $expire,
			));
			$url = $resp['SignedUrl'];
		} catch (Exception $e) {
			if ($this->config['debug']) {
				$this->getException($e->getExceptionCode(), $e->getMessage());
			}
			return null;
		}
		return $url;
	}

	public function getData($object) {
		$res = $this->client->getObjectMetadata(array(
			'Bucket' => $this->bucket,
			'Key' => $object,
		));		
		if ($res['ContentLength'] <= 0) {
			return null;
		}
		$data = array();
		$data['object'] = strpos($object, $this->basedir) === 0 ? substr($object, strlen($this->basedir)) : $object;
		$data['size'] = $res['ContentLength'];
		$data['height'] = 0;
		$data['width'] = 0;
		if (strpos($res['ContentType'], 'image') !== FALSE) {
			$endpoint = $this->config['endpoint'];
			if (strpos($endpoint, 'http') !== 0){
				$endpoint = 'https://' . $this->bucket.'.'.$endpoint;
			}
			$res = $this->fileSock($endpoint.'/'.$object.'?'.$this->imageStyle('image/info'));
			$res = json_decode($res, true);
			$data['height'] = $res['height'];
			$data['width'] = $res['width'];
		}
		return $data;
	}
}