<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-12
 * Version: 3.10614
 * Date: 2021-09-13 11:55:28
 * File: table_duceapp_remostore_forum_typeoptionvar.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_duceapp_remostore_forum_typeoptionvar extends discuz_table {

	public function __construct() {
		$this->_table = 'forum_typeoptionvar';
		$this->_pk    = '';
		parent::__construct(); /*dism �� taobao �� com*/
	}

	public function fetch_all_by_value($remote = 0, $start = 0, $limit = 10) {
		$sql = "SELECT t.*,o.identifier FROM %t t LEFT JOIN %t o ON t.optionid=o.optionid WHERE %i";
		if ($remote === null || $remote > 1) {
			$where = "t.value REGEXP 'url[^s]+s:[1-9]' AND o.type='image'";
		} elseif ($remote == 0) {
			$where = "t.value REGEXP 'url[^s]+s:[^\\\"]+\\\"data/attachment/'";
		} elseif ($remote == 1) {
			$where = "t.value REGEXP 'url[^s]+s:[^\\\"]+\\\"http'";
		}
		return DB::fetch_all($sql.DB::limit($start, $limit), array($this->_table, 'forum_typeoption', $where));
	}

	public function count_by_value($remote = null) { 
		if ($remote === null || $remote > 1) {
			$where = "value REGEXP 'url[^s]+s:[1-9]'";
		} elseif ($remote == 0) {
			$where = "value REGEXP 'url[^s]+s:[^\\\"]+\\\"data/attachment/'";
		} elseif ($remote == 1) {
			$where = "value REGEXP 'url[^s]+s:[^\\\"]+\\\"http'";
		}
		return DB::result_first('SELECT count(*) FROM %t WHERE %i', array($this->_table, $where));
	}
}