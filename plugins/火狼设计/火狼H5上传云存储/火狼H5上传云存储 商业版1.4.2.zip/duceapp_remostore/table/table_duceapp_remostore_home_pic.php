<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-12
 * Version: 3.10614
 * Date: 2021-09-13 11:55:28
 * File: table_duceapp_remostore_home_pic.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_duceapp_remostore_home_pic extends discuz_table {

	public function __construct() {
		$this->_table = 'home_pic';
		$this->_pk    = 'picid';
		parent::__construct(); /*dism �� taobao �� com*/
	}

	public function count_all($remote = 0) { 
		return DB::result_first('SELECT count(*) FROM %t '.($remote != 4 ? 'WHERE '.DB::field('remote', $remote) : ''), array($this->_table));
	}

	public function fetch_by_filepath($uid, $remote, $filepath) {        
        return DB::result_first('SELECT picid FROM %t WHERE uid=%d AND remote=%d AND filepath=%s', array($this->_table, $uid, $remote, $filepath));
    }

	public function update_by_remote($picid, $remote){
        return DB::update($this->_table, array('remote' => $remote), DB::field('picid', $picid));
    }

	public function count_by_alubm($remote = 0) {
        return DB::result_first('SELECT count(*) FROM %t'.($remote ? ' WHERE '.DB::field('picflag', $remote) : ''), array('home_album'));
    }

	public function update_by_picid($picid, $remote) {
        return $picid ? DB::update($this->_table, array('remote' => $remote), DB::field('picid', $picid)) : false;
    }

	public function update_by_albumid($albumid, $remote) {
        return $albumid ? DB::update('home_album', array('picflag' => $remote), DB::field('albumid', $albumid)) : false;
    }

	public function fetch_all_data($remote = 0, $start = 0, $limit = 10) {
		return $limit ? DB::fetch_all("SELECT * FROM %t WHERE remote=%d".DB::limit($start, $limit), array($this->_table, $remote), $this->_pk) : array();
    }    
    
    public function fetch_all_cover($remote = 0, $start = 0, $limit = 10) {
        return $limit ? DB::fetch_all("SELECT * FROM %t WHERE picflag=%d".DB::limit($start, $limit), array('home_album', $remote + 1), 'albumid') : array();
    }
}