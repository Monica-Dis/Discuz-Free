<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-12
 * Version: 3.10613
 * Date: 2021-09-13 11:55:28
 * File: table_duceapp_remostore_forum_thread.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_duceapp_remostore_forum_thread extends discuz_table
{
    private $_posttableid = array();
    private $_urlparam = array();

    public function __construct() {        
        $this->_table = 'forum_thread';
        $this->_pk    = 'tid';
        $this->_pre_cache_key = 'forum_thread_';
        parent::__construct(); /*dism �� taobao �� com*/
    }

    public function get_table_name($tableid = 0){
        $tableid = intval($tableid);
        return $tableid ? "forum_thread_$tableid" : 'forum_thread';
    }

    public function count_cover($remote = 0){
		return DB::result_first("SELECT count(*) FROM %t WHERE %i AND displayorder>'-1'", array($this->_table, DB::field('cover', 0, $remote ? '<' : '>')));
    }

    public function fetch_all_cover($remote = 0, &$start = 0, $limit = 10) {
		if ($limit) {
			$start = intval($start);
			return DB::fetch_all("SELECT * FROM %t WHERE %i AND displayorder>'-1'".DB::limit($start, $limit), array(
				$this->_table, DB::field('cover', 0, $remote ? '<' : '>')
			), $this->_pk);
		}
        return array();
    }    
}