<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-12
 * Version: 3.10614
 * Date: 2021-09-13 11:55:28
 * File: table_duceapp_remostore_portal_attachment.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_duceapp_remostore_portal_attachment extends discuz_table
{
    public function __construct() {        
        $this->_table = 'portal_attachment';
        $this->_pk    = 'attachid';        
        parent::__construct(); /*dism �� taobao �� com*/
    }

	public function count_all($remote = null) {
		if ($remote === null || $remote > 1) {
			$where = 'WHERE 1';
		} elseif ($remote == 0) {
			$where = 'WHERE '.DB::field('remote', 0);
        } elseif($remote == 1) {
            $where = 'WHERE '.DB::field('remote', 1);
        }
		return DB::result_first("SELECT count(*) FROM %t %i", array($this->_table, $where));
    }

	public function count_article() {
        return DB::result_first("SELECT count(*) FROM %t", array('portal_article_content'));
    }

	public function update_by_attachid($attachid, $remote) {
        $attachid = dintval($attachid);
        return $attachid ? DB::update($this->_table, array('remote' => $remote), DB::field('attachid', $attachid)) : false;
    }

	public function fetch_all_article($start = 0, $limit = 2) {
        if ($limit) {
            return DB::fetch_all("SELECT * FROM %t".DB::limit($start, $limit), array('portal_article_content'), 'cid');
        }
        return array();
    }
    
    public function fetch_all_attach($remote = 0, $start = 0, $limit = 10) {
        if ($limit) {
			return DB::fetch_all("SELECT * FROM %t WHERE remote=%d".DB::limit($start, $limit), array($this->_table, $remote), $this->_pk);
        }
        return array();
    }
}