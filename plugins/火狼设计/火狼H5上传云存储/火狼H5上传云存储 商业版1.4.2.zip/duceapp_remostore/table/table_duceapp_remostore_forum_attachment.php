<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-11
 * Version: 3.10623
 * Date: 2021-09-13 11:55:28
 * File: table_duceapp_remostore_forum_attachment.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_duceapp_remostore_forum_attachment extends discuz_table {

	public function __construct() {
		$this->_table = '';
		$this->_pk    = 'aid';
		parent::__construct(); /*dism �� taobao �� com*/
	}

	private function _get_table($tableid) {
		if(!is_numeric($tableid)) {
			list($idtype, $id) = explode(':', $tableid);
			if($idtype == 'aid') {
				$aid = dintval($id);
				$tableid = DB::result_first("SELECT tableid FROM ".DB::table('forum_attachment')." WHERE aid='$aid'");
			} elseif($idtype == 'tid') {
				$tid = (string)$id;
				$tableid = dintval($tid[strlen($tid)-1]);
			} elseif($idtype == 'pid') {
				$pid = dintval($id);
				$tableid = DB::result_first("SELECT tableid FROM ".DB::table('forum_attachment')." WHERE pid='$pid' LIMIT 1");
				$tableid = $tableid >= 0 && $tableid < 10 ? intval($tableid) : 127;
			}
		}
		if($tableid >= 0 && $tableid < 10) {
			return 'forum_attachment_'.intval($tableid);
		} elseif($tableid == 127) {
			return 'forum_attachment_unused';
		} else {
			throw new DbException('Table forum_attachment_'.$this->_table.' has not exists');
		}
	}

	private function _check_id($idtype, $ids) {
		if($idtype == 'pid' && $this->_table == 'forum_attachment_unused') {
			return false;
		}
		if(in_array($idtype, array('aid', 'tid', 'pid', 'uid')) && !empty($ids)) {
			return true;
		} else {
			return false;
		}
	}

	public function count_all($remote = null, $date = '', $fileext = '', $filesize = 20480) {
		$where = $this->get_condition($remote, $date, $fileext, $filesize);
		$count = 0;
		for ($i = 0;$i < 10; $i++) {
            $count += DB::result_first('SELECT COUNT(aid) FROM %t WHERE %i', array('forum_attachment_'.$i, $where));
        }
		return $count;
	}

	public function fetch_all_data($remote = 0, $date = '', $fileext = '', $filesize = 20480, &$start = 0, $limit = 10, &$tableid = 0) {
		$where = $this->get_condition($remote, $date, $fileext, $filesize);
		$start = intval($start);
		$tableid = intval($tableid);
		$data = array();
		for ($i = $tableid; $i < 10; $i++) {
			if ($data = DB::fetch_all('SELECT * FROM %t WHERE %i'.DB::limit($start, $limit), array('forum_attachment_'.$i, $where))) {
				break;
			}
			$start = 0;
			$tableid = $i + 1;
        }
		return $data;
	}

	private function get_condition($remote = null, $date = '', $fileext = '', $filesize = 20480) {
		$filesize *= $remote === null ? 0 : 1024;
		$dateline = $date ? strtotime($date) : 0;
		$where = DB::field('remote', intval($remote));
		empty($filesize) || $where .= ' AND '. DB::field('filesize', $filesize, '<=');
		empty($dateline) || $where .= ' AND '. DB::field('dateline', $dateline, '>=');
		if (!empty($fileext)) {
			$extarr = array();
			foreach(explode(',', $fileext) as $ext) {
				if ($ext = trim($ext)) {
					$extarr[] = DB::field('filename', "%.$ext", 'like');
				}
			}
			empty($extarr) || $where .= ' AND ('. implode(' OR ', $extarr) .')';
		}
		$where .= " AND attachment NOT LIKE('%#attachpan%')";
		return $where;
	}
}