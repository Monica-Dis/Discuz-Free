<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-09
 * Version: 3.00903
 * Date: 2021-09-13 11:55:24
 * File: install.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

define('DUCEAPP_INSTALL', 1);
define('DUCEAPP_ROOT', dirname(__FILE__).'/');
define('DUCEAPP_IDENT', $operation == 'plugininstall' ? $_GET['dir'] : $dir);
define('DUCEAPP_DIRURL', 'source/plugin/'.DUCEAPP_IDENT.'/');
define('DUCEAPP_CPURL', ADMINSCRIPT.'?action=plugins&operation='.($operation == 'enable' ? 'enable&pluginid='.$_GET['pluginid'].($_GET['pmod'] ? '&pmod='.$_GET['pmod'] : '') : 'plugininstall&&pluginid='.$pluginid.'&dir='.$dir.'&installtype='.$installtype));
define('DUCEAPP_DATAURL', 'data/'.str_replace('_', '/', DUCEAPP_IDENT).'/');

include_once libfile('check', 'plugin/'.DUCEAPP_IDENT);
include_once libfile('class/duceapp_installcore', 'plugin/'.DUCEAPP_SINGLE);
@include DUCEAPP_ROOT.'install/index.php';

if ($operation == 'enable' && $_GET['pmod']) {
	dheader('location:'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['pluginid'].'&pmod='.$_GET['pmod']);
}

$finish = TRUE;