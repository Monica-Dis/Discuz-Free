<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-07-20
 * Version: 3.10715
 * Date: 2021-08-24 04:43:53
 * File: duceapp_tencentcos.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class duceapp_tencentcos extends duceapp_ossbase
{
	public function __construct($config) {
		$this->config = $config;
		$this->bucket = $config['bucket'];
		$this->basedir = $config['basedir'];
		$this->client = new Qcloud\Cos\Client(array(
			'region' => $config['region'], 
			'schema' => 'https', 
			'credentials' => array(
				'secretId' => $config['secretid'],
				'secretKey' => $config['secretkey'],
			),
		));
	}

	public function createBucket($bucket) {
		if (!defined('IN_ADMINCP')) {
			return;
		}
		try {
			$this->client->createBucket(array('Bucket' => $bucket, 'ACL' => 'public-read'));
			$this->bucket = $bucket;
		} catch(Exception $e) {
			if ($this->config['debug']) {
				throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
			}
            return 0;
        }
		return 1;
	}

	public function bucketExist($bucket) {
		try {
			return $this->client->doesBucketExist($bucket);
		} catch(Exception $e) {
			if ($this->config['debug']) {
				throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
			}
            return 0;
        }
	}

	public function checkRes() {
		try {
			$res = array();
			$res[0] = $this->client->putObject(array(
                'Bucket' => $this->bucket, 
                'Key' => 'test.txt',
                'Body' => 'test',
                'ACL' => 'public-read',
            ));
			$file = __DIR__ . '/test.txt';
			$this->client->getObject(array(
				'Bucket' => $this->bucket, 
                'Key' => 'test.txt',
				'SaveAs' => $file,
			));
			if (file_exists($file)) {
				$res[1] = 1;
				@unlink($file);
			}
			$content = $this->fileSock($this->config['remourl'].'test.txt');
			if ($content) {
				$res[2] = 1;
			}
			$res[0] && $this->client->deleteObject(array(
				'Bucket' => $this->bucket, 
				'Key' => 'test.txt',
			));
			return $res;
		} catch(Exception $e) {
			throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
		}
	}

	public function setReferer() {
	}

	public function setCors() {
		try {
			$result = $this->client->putBucketCors(array(
				'Bucket' => $this->bucket,
				'CORSRules' => array(
					array(
						'AllowedHeaders' => array('*'),
						'AllowedMethods' => array('POST'),
						'AllowedOrigins' => array('*'),
						'ExposeHeaders' => array('*'),
					),
				)
			));
		} catch (Exception $e) {
			if ($this->config['debug']) {
				throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
			}
			return 0;
		}
		return 1;
	}

	public function objectExists($object) {
		try {
            $ret = $this->client->doesObjectExist($this->bucket, $this->basedir.$object);
			return $ret ? $this->config['remourl'].$this->basedir.$object : 0;
        } catch(Exception $e) {
            return 0;
        }
	}

	public function getFileslist($prefix = '', $marker = '', $limit = 100, $delimiter = '') {
		$res = array(
			'marker' => $marker,
			'run' => 0,
			'items' => array(),
		);
		while (true) {
			try {
				$result = $this->client->listObjects(array(
					'Bucket' => $this->bucket, 
					'Delimiter' => $delimiter,
					'EncodingType' => 'url',
					'Marker' => $res['marker'],
					'Prefix' => $prefix,
					'MaxKeys' => $limit > 0 ? $limit : 100,
				));
			} catch (Exception $e) {
				return array();
			}
			$res['marker'] = $result['NextMarker'];
			foreach ($result['Contents'] as $k => $item) {
				$res['items'][] = array(
					'key' => $item['Key'],
					'size' => $item['Size'],
					'filemtime' => strtotime($item['LastModified']),
				);
			}
			unset($result);
			$res['run']++;
			if ($limit > 0 || empty($res['marker'])) {
				break;
			}
		}
		return $res;
	}

	public function imageStyle($style) {
		return $style;
    }

	public function uploadFile($file, $object, $Acl = null) {
		try {
			$file = @fopen($file, 'rb');
			if (!$file) {
				return 0;
			}
			$this->client->Upload($this->bucket, $this->basedir.$object, $file);
			if ($Acl === null) {
				$Acl = $this->getAcl($file);
			}
			if ($Acl) {
				$Acl = $Acl == 'public' ? 'public-read' : $Acl;
				$this->client->putObjectAcl(array(
					'Bucket' => $this->bucket,
					'Key' => $this->basedir.$object,
					'ACL' => $Acl,
				));
			}
		} catch (Exception $e) {
			if ($this->config['debug']) {
				throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
			}
			return 0;
		}
		return 1;
	}

	public function uploadData($data, $object, $Acl = null, $fread = false) {
		try {
			if ($fread) {
				$data = $this->fileSock($data);
			}
			if (empty($data)) {
				return 0;
			}
			if ($Acl === null) {
				$Acl = $this->getAcl($object);
			}
			$Acl = $Acl == 'public' || $Acl == 'public-read' ? 'public-read' : 'private';
			$this->client->putObject(array(
				'Bucket' => $this->bucket,
				'Key' => $this->basedir.$object,
				'Body' => $data,
				'ACL' => $Acl,
			));
		} catch (Exception $e) {
			if ($this->config['debug']) {
				throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
			}
			return 0;
		}
		return 1;
	}

	public function setAcl($object, $Acl = null){
		try {
			$Acl = $Acl == 'public' || $Acl == 'public-read' ? 'public-read' : $Acl;
			if ($Acl) {
				$this->client->putObjectAcl(array(
					'Bucket' => $this->bucket,
					'Key' => $this->basedir.$object,
					'ACL' => $Acl,
				));
			}
		} catch (Exception $e) {
			if ($this->config['debug']) {
				throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
			}
			return 0;
		}
		return 1;
	}

	public function renameObject($oldObject, $newObject, $MimeType = null) {
		try {
			if ($this->client->copyObject(array(
				'Bucket' => $this->bucket,
				'Key' => $this->basedir.$newObject,
				'CopySource' => $this->bucket.'.'.$this->config['endpoint'].'/'.$this->basedir.$oldObject,
				))) {
				$this->client->deleteObject(array(
					'Bucket' => $this->bucket, 
					'Key' => $this->basedir.$oldObject,
				));
			}
		} catch (Exception $e) {
			if ($this->config['debug']) {
				throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
			}
			return 0;
		}
		return 1;
	}

	public function downFile($file, $object) {
		try {
			$this->client->getObject(array(
				'Bucket' => $this->bucket,
				'Key' => $this->basedir.$object,
				'SaveAs' => $file
			));
		} catch (Exception $e) {
			if ($this->config['debug']) {
				throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
			}
			return 0;
		}
		return 1;
	}

	public function deleteFile($objects) {
		try {
			if (is_array($objects)) {
				foreach($objects as $i => $object) {
					$objects[$i] = $this->basedir.$object;
				}
				$this->client->deleteObjects(array(
					'Bucket' => $this->bucket, 
					'Objects' => $objects
				));
			} else {
				$this->client->deleteObject(array(
					'Bucket' => $this->bucket, 
					'Key' => $this->basedir.$objects,
				));
			}
		} catch (Exception $e) {
			if ($this->config['debug']) {
				throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
			}
			return 0;
		}
		return 1;
	}

	public function getPolicy($dir, $object, $length = 1048576000) {
		require_once __DIR__ . '/qcloud-cos-sts-sdk.php';
		$sts = new STS();
		$config = array(
			'url' => 'https://sts.tencentcloudapi.com/',
			'domain' => 'sts.tencentcloudapi.com',
			'proxy' => '',
			'secretId' => $this->config['secretid'], 
			'secretKey' => $this->config['secretkey'],
			'bucket' => $this->bucket, 
			'region' => $this->config['region'], 
			'durationSeconds' => 1800,
			'allowPrefix' => '*',
			'allowActions' => array (
				'name/cos:PutObject',
				'name/cos:PostObject',
				'name/cos:InitiateMultipartUpload',
				'name/cos:ListMultipartUploads',
				'name/cos:ListParts',
				'name/cos:UploadPart',
				'name/cos:CompleteMultipartUpload'
			)
		);

		$tempKeys = $sts->getTempKeys($config);
		$tempKeys['dir'] = $this->basedir.$dir;
		$tempKeys['object'] = $object;

		header('Content-Type: application/json');
		header('Access-Control-Allow-Origin: http://127.0.0.1'); 
		header('Access-Control-Allow-Headers: origin,accept,content-type');

		return json_encode($tempKeys);
	}

	public function signUrl($object, $filename = '', $expire = 3600) {
		empty($expire) && ($expire = 3600);
		$url = '';
		try {
			$object = $this->basedir.$object;
			if (!empty($filename)) {
				$filename = rawurldecode(diconv($filename, CHARSET, 'utf8'));
				$meta = $this->client->headObject(array(
					'Bucket' => $this->bucket, 
					'Key' => $object,
				));
				if (!isset($meta['Metadata']) || !isset($meta['Metadata']['filename']) || $meta['Metadata']['filename'] != $filename) {
					$params = array(
						'Bucket' => $this->bucket, 
						'Key' => $object,
						'CopySource' => $this->bucket.'.'.$this->config['endpoint'].'/'.$object,
						'MetadataDirective' => 'Replaced',
						'Metadata' => array(
							'filename' => $filename,
						),
						'ContentDisposition' => "attachment; filename=\"$filename\";filename*=utf-8''$filename",
					);
					if (fileext($filename) == 'mp4') {
						$params['ContentType'] = 'video/mp4';
					}
					$this->client->copyObject($params);
				}
			}
			$expire = intval($expire/60);
			$expire <=0 && ($expire = 1);
			$url =  $this->client->getObjectUrl($this->bucket, $object, "+$expire minutes");
		} catch (Exception $e) {
			if ($this->config['debug']) {
				throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
			}
			return 0;
		}
		return $url;
	}

	public function getData($object) {
		if (!$this->client->doesObjectExist($this->bucket, $object)) {
			return null;
		}
		$res = $this->client->headObject(array(
			'Bucket' => $this->bucket, 
			'Key' => $object
		));
		$data = array();
		$data['object'] = strpos($object, $this->basedir) === 0 ? substr($object, strlen($this->basedir)) : $object;
		$data['size'] = $res['ContentLength'];
		$data['height'] = 0;
		$data['width'] = 0;
		if (strpos($res['ContentType'], 'image') !== FALSE) {
			$url = $this->client->getObjectUrl($this->bucket, $object, '+10 minutes');
			$url .= '&imageInfo';
			$content = $this->fileSock($url);
			if (!$content) {
				return null;
			}
			$content = json_decode($content, true);
			$data['height'] = $content['height'];
			$data['width'] = $content['width'];
		}
		return $data;
	}
}