<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-08
 * Version: 3.00905
 * Date: 2021-08-24 04:43:53
 * File: InvalidArgumentException.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

namespace Qcloud\Cos\Exception;

class InvalidArgumentException extends CosException {}