<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-08
 * Version: 3.10608
 * Date: 2021-08-24 04:43:53
 * File: autoload.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

require_once __DIR__ . '/vendor/composer/autoload_real.php';

return duceapp_qcloudcos_classLoader::getLoader();