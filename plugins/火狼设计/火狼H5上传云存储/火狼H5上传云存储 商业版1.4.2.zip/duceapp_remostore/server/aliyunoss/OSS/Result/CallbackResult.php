<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-05
 * Version: 3.91115
 * Date: 2021-08-24 04:43:51
 * File: CallbackResult.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

namespace OSS\Result;


/**
 * Class CallbackResult
 * @package OSS\Result
 */
class CallbackResult extends PutSetDeleteResult
{
    protected function isResponseOk()
    {
        $status = $this->rawResponse->status;
        if ((int)(intval($status) / 100) == 2 && (int)(intval($status)) !== 203) {
            return true;
        }
        return false;
    }

}