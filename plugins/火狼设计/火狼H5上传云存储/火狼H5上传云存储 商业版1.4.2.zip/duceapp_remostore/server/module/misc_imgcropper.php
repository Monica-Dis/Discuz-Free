<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-12
 * Version: 3.10624
 * Date: 2021-09-13 11:55:25
 * File: misc_imgcropper.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$_GET['img'] = htmlspecialchars($_GET['img']);
$_GET['bid'] = intval($_GET['bid']);
$_GET['picflag'] = intval($_GET['picflag']);
$_GET['ictype'] = !empty($_GET['ictype']) ? 'block' : '';
$_GET['width'] = intval($_GET['width']);
$_GET['height'] = intval($_GET['height']);

if(!submitcheck('imgcroppersubmit')) {
	if($_GET['op'] == 'loadcropper') {
		$cboxwidth = $_GET['width'] > 50 ? $_GET['width'] : 300;
		$cboxheight = $_GET['height'] > 50 ? $_GET['height'] : 300;

		$cbgboxwidth = $cboxwidth + 300;
		$cbgboxheight = $cboxheight + 300;
		$dragpl = ($cbgboxwidth - $cboxwidth)/2;
		$dragpt = ($cbgboxheight - $cboxheight)/2;
	} else {
		$prefix = $_GET['picflag'] == 2 ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl'];
	}
	include_once template("common/misc_imgcropper");
} else {
	$cropfile = md5($_GET['cutimg']).'.jpg';
	$ictype = $_GET['ictype'];

	if($ictype == 'block') {
		require_once libfile('function/block');
		$block = C::t('common_block')->fetch($_GET['bid']);
		$cropfile = block_thumbpath($block, array('picflag' => intval($_GET['picflag']), 'pic' => $_GET['cutimg']));
		$cutwidth = $block['picwidth'];
		$cutheight = $block['picheight'];
	} else {
		$cutwidth = $_GET['cutwidth'];
		$cutheight = $_GET['cutheight'];
	}

	$flag = false;
	if (C::m('#duceapp_remostore#duceapp_oss')->exec('objectExists', $_GET['cutimg'])){
        $tmpfilename = $_G['setting']['attachdir'].'temp/'.random(16).'_'.substr(strrchr($_GET['cutimg'], '.'), 0);
        if (C::m('#duceapp_remostore#duceapp_oss')->exec('downFile', $tmpfilename, $_GET['cutimg'])) {
            $_GET['cutimg'] = substr($tmpfilename, strlen($_G['setting']['attachdir']));
            $_GET['picflag'] = 1;
            $flag = true;
        }        
    }

	$top = intval($_GET['cuttop'] < 0 ? 0 : $_GET['cuttop']);
	$left = intval($_GET['cutleft'] < 0 ? 0 : $_GET['cutleft']);
	$picwidth = $cutwidth > $_GET['picwidth'] ? $cutwidth : $_GET['picwidth'];
	$picheight = $cutheight > $_GET['picheight'] ? $cutheight : $_GET['picheight'];

	require_once libfile('class/image');
	$image = new image();
	$prefix = $_GET['picflag'] == 2 ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl'];
	if (!$image->Thumb($prefix.$_GET['cutimg'], $cropfile, $picwidth, $picheight)) {
		showmessage('imagepreview_errorcode_'.$image->errorcode, null, null, array('showdialog' => true, 'closetime' => true));
	}
	$image->Cropper($image->target, $cropfile, $cutwidth, $cutheight, $left, $top);

	if ($flag) {
        C::m('#duceapp_remostore#duceapp_oss')->exec('uploadFile', $_G['setting']['attachdir'].$cropfile, $cropfile, 'public');
        @unlink($_G['setting']['attachdir'].$cropfile);
        @unlink($tmpfilename);
    }

	showmessage('do_success', dreferer(), array('icurl' => $cropfile), array('showdialog' => true, 'closetime' => true));
}