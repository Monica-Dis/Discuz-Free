<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-12
 * Version: 3.10720
 * Date: 2021-09-13 11:55:25
 * File: admincp_syndata.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function duceapp_remostore_onForum(&$task) {
	global $_G;
	static $duceapptemplate;
	
	if ($duceapptemplate === null) {
		$duceapptemplate = DB::result_first("SHOW TABLES LIKE '%".DB::table('duceapp_threads')."'") ? 1 : 0;
	}

	$publicext = C::m('#duceapp_remostore#duceapp_oss')->getConfig('publicext');

	if ($task['runstatus'] != 1) {
		return 0;
	}

	$limit = $task['limit'] > 0 ? $task['limit'] : 10;
	$index = 0;

	if (!$task['marker']) {
		$tids = array();
		foreach(C::t('#duceapp_remostore#duceapp_remostore_forum_attachment')->fetch_all_data($task['direction'], $task['limitdate'], $task['fileext'], $task['filesize'], $task['start'], $limit, $task['tableid']) as $attach) {
			$object = 'forum/'.$attach['attachment'];
			$filename = $_G['setting']['attachdir'].$object;
			$succeed = false;
			if ($task['direction']) {
				if (C::m('#duceapp_remostore#duceapp_oss')->exec('objectExists', $object)) {
					dmkdir(dirname($filename));
					if (C::m('#duceapp_remostore#duceapp_oss')->exec('downFile', $filename, $object)) {
						$attach['remote'] = 0;
						C::t('forum_attachment_n')->update('tid:'.$attach['tid'], $attach['aid'], $attach);
						$task['delsource'] && C::m('#duceapp_remostore#duceapp_oss')->exec('deleteFile', $object);
						if ($attach['isimage']){
							$object = 'forum/'.$attach['attachment'].'.thumb.jpg';
							$filename = $_G['setting']['attachdir'].$object;
							if ($attach['thumb'] && C::m('#duceapp_remostore#duceapp_oss')->exec('objectExists', $object) && 
								C::m('#duceapp_remostore#duceapp_oss')->exec('downFile', $filename, $object)) {
								$task['delsource'] && C::m('#duceapp_remostore#duceapp_oss')->exec('deleteFile', $object);
							}
							$picid = C::t('#duceapp_remostore#duceapp_remostore_home_pic')->fetch_by_filepath($attach['uid'], 3, $attach['attachment']);
							$picid && C::t('#duceapp_remostore#duceapp_remostore_home_pic')->update_by_remote($picid, 2);
							DB::update('forum_threadimage', array('remote' => 0), DB::field('tid', $attach['tid']).' AND '.DB::field('attachment', $attach['attachment']));
						}
						$succeed = true;
						$tids[] = $attach['tid'];
					}
				}
			} else {
				if (file_exists($filename)) {
					$ext = ($ext = fileext($attach['filename'])) ? $ext : fileext($attach['attachment']);
					if (C::m('#duceapp_remostore#duceapp_oss')->exec('uploadFile', $filename, $object, @in_array($ext, $publicext) ? 'public' : 'private')) {
						$attach['remote'] = 1;
						C::t('forum_attachment_n')->update('tid:'.$attach['tid'], $attach['aid'], $attach);
						$task['delsource'] && @unlink($filename);
						if ($attach['isimage']) {
							$picid = C::t('#duceapp_remostore#duceapp_remostore_home_pic')->fetch_by_filepath($attach['uid'], 2, $attach['attachment']);
							$picid && C::t('#duceapp_remostore#duceapp_remostore_home_pic')->update_by_remote($picid, 3);
							DB::update('forum_threadimage', array('remote' => 1), DB::field('tid', $attach['tid']).' AND '.DB::field('attachment', $attach['attachment']));
							$object = 'forum/'.$attach['attachment'].'.thumb.jpg';
							$filename = $_G['setting']['attachdir'].$object;
							if ($attach['thumb'] && file_exists($filename) && 
								C::m('#duceapp_remostore#duceapp_oss')->exec('uploadFile', $filename, $object, 'public')) {
								$task['delsource'] && @unlink($filename);
							}
						}
						$succeed = true;
						$tids[] = $attach['tid'];
					}
				}
			}
			$task['procesfile'] = $filename;
			$index++;
			if ($succeed) {
				$task['succeed']++;
			} else {
				$task['start']++;
				$task['failed']++;
			}
			$task['completed']++;
			$task['lastruntime'] = time();
			if ($task['completed'] >= $task['ppp']) {
				$task['runstatus'] = 0;
				break;
			}
		}

		if ($tids && $duceapptemplate) {
			C::t('#duceapp_template#duceapp_threads')->update(array('tid' => array_unique($tids), 'cachetime' => 0));
		}

		if ($index) {
			return $index;
		}
	}

	$task['marker'] = 1;

	foreach(C::t('#duceapp_remostore#duceapp_remostore_forum_thread')->fetch_all_cover($task['direction'], $task['re_start'], $limit) as $cover) {
		$object = 'forum/threadcover/'.substr(md5($cover['tid']), 0, 2).'/'.substr(md5($cover['tid']), 2, 2).'/'.$cover['tid'].'.jpg';
		$filename = (!$_G['setting']['attachdir'] ? DISCUZ_ROOT.'./data/attachment/' : $_G['setting']['attachdir']).$object;
		$succeed = false;
		if ($task['direction']) {
			if (C::m('#duceapp_remostore#duceapp_oss')->exec('objectExists', $object)) {
				dmkdir(dirname($filename));
				if (C::m('#duceapp_remostore#duceapp_oss')->exec('downFile', $filename, $object)) {
					$task['delsource'] && C::m('#duceapp_remostore#duceapp_oss')->exec('deleteFile', $object);
					$succeed = true;
				}
			}
		} else {
			if (file_exists($filename)) {
				if (C::m('#duceapp_remostore#duceapp_oss')->exec('uploadFile', $filename, $object, 'public')) {
					$task['delsource'] && @unlink($filename);
					$succeed = true;
				}
			}			
		}
		C::t('forum_thread')->update($cover['tid'], array('cover' => $task['direction'] ? abs($cover['cover']) : '-'.$cover['cover']));
		$index++;
		if ($succeed) {
			$task['succeed']++;
		} else {
			$task['re_start']++;
			$task['failed']++;
		}
		$task['completed']++;
		$task['lastruntime'] = time();
		if ($task['ppp'] && $task['completed'] >= $task['ppp']) {
			$task['runstatus'] = 0;
			break;
		}
	}

	if (!$index) {
		$task['runstatus'] = -1;
	}

	return $index;
}

function duceapp_remostore_onSorttype(&$task) {
	global $_G;

	static $duceapptemplate;
	
	if ($duceapptemplate === null) {
		$duceapptemplate = DB::result_first("SHOW TABLES LIKE '%".DB::table('duceapp_threads')."'") ? 1 : 0;
	}

	if ($task['runstatus'] != 1) {
		return 0;
	}

	$limit = $task['limit'] > 0 ? $task['limit'] : 10;
	$index = 0;

	if (!$task['marker']) {
		$tids = array();
		foreach (C::t('#duceapp_remostore#duceapp_remostore_forum_typeoptionvar')->fetch_all_by_value($task['direction'], $task['start'], $limit) as $var) {
			$value = dunserialize($var['value']);
			$object = substr($value['url'], strpos($value['url'], 'forum'));
			$filename = $_G['setting']['attachdir'].$object;
			$succeed = false;
			if ($task['direction']) {
				if (C::m('#duceapp_remostore#duceapp_oss')->exec('objectExists', $object)) {
					dmkdir(dirname($filename));
					if (C::m('#duceapp_remostore#duceapp_oss')->exec('downFile', $filename, $object)) {	
						$value['url'] = 'data/attachment/'.$object;
						$succeed = true;
						$tids[] = $var['tid'];
					}
				}
			} else {
				if (file_exists($filename) && C::m('#duceapp_remostore#duceapp_oss')->exec('uploadFile', $filename, $object, 'public')) {
					$value['url'] = C::m('#duceapp_remostore#duceapp_oss')->objectUrl($object);												
					$succeed = true;
					$tids[] = $var['tid'];
				}
			}		
			$index++;
			if ($succeed) {
				$task['succeed']++;
				$value = addslashes(serialize($value));
				DB::update('forum_threadimage', array('remote' => $task['direction'] ? 0 : 1), DB::field('tid', $var['tid']).' AND '.DB::field('attachment', str_replace('forum/', '', $object)));
				C::t('forum_attachment_n')->update('tid:'.$var['tid'], $value['aid'], array('remote' => $task['direction'] ? 0 : 1));
				C::t('forum_typeoptionvar')->update_by_tid($var['tid'], array('value' => $value, 'sortid' => $var['sortid']), false, false, $var['optionid']);
				C::t('forum_optionvalue')->update($var['sortid'], $var['tid'], $var['fid'], $var['identifier']."='$value'");
				if ($task['delsource']) {
					$task['direction'] ? C::m('#duceapp_remostore#duceapp_oss')->exec('deleteFile', $object) : @unlink($filename);
				}
			} else {
				$task['start']++;
				$task['failed']++;
			}
			$task['procesfile'] = $filename;
			$task['completed']++;
			$task['lastruntime'] = time();
			if ($task['ppp'] && $task['completed'] >= $task['ppp']) {
				$task['runstatus'] = 0;
				break;
			}	
		}

		if ($tids && $duceapptemplate) {		
			C::t('#duceapp_template#duceapp_threads')->update(array('tid' => array_unique($tids), 'cachetime' => 0));
		}
		
		if ($index) {
			return $index;
		}
	}

	$index = duceapp_remostore_reSorttype($task);

	if (!$index) {
		$task['runstatus'] = -1;
	}

	return $index;
}

function duceapp_remostore_reSorttype(&$task) {
	global $_G;

	$task['marker'] = 1;
	if ($task['runstatus'] != 1) {
		return 0;
	}

	$limit = $task['limit'] > 0 ? $task['limit'] : 10;

	foreach (C::t('#duceapp_remostore#duceapp_remostore_forum_typeoptionvar')->fetch_all_by_value(null, $task['re_start'], $limit) as $var) {
		$value = dunserialize($var['value']);
		$object = substr($value['url'], strpos($value['url'], 'forum'));
		$filename = $_G['setting']['attachdir'].$object;
		$fileoss = C::m('#duceapp_remostore#duceapp_oss')->objectUrl($object);
		$remote = (strpos($value['url'], 'http') !== FALSE);
		$update = false;
		if (!$remote && !file_exists($filename) && C::m('#duceapp_remostore#duceapp_oss')->exec('objectExists', $object)) {
			$value['url'] = $fileoss;
			C::t('forum_attachment_n')->update('tid:'.$var['tid'], $value['aid'], array('remote' => 1));
			$update = true;
		} elseif ($remote && file_exists($filename) && !C::m('#duceapp_remostore#duceapp_oss')->exec('objectExists', $object)) {
			$value['url'] = 'data/attachment/'.$object;
			C::t('forum_attachment_n')->update('tid:'.$var['tid'], $value['aid'], array('remote' => 0));
			$update = true;
		} elseif ($remote && $value['url'] != $fileoss) {
			$value['url'] = $fileoss;
			$update = true;
		}
		if ($update) {
			$value = addslashes(serialize($value));
			C::t('forum_typeoptionvar')->update_by_tid($var['tid'], array('value' => $value, 'sortid' => $var['sortid']), false, false, $var['optionid']);
			C::t('forum_optionvalue')->update($var['sortid'], $var['tid'], $var['fid'], BD::field($var['identifier'], $value));
		}		
		$index++;
		$task['re_start']++;
		$task['procesfile'] = $filename;
		$task['succeed']++;
		$task['completed']++;
		$task['lastruntime'] = time();
		if ($task['ppp'] && $task['completed'] >= $task['ppp']) {
			$task['runstatus'] = 0;
			break;
		}
	}

	if (!$index) {
		$task['runstatus'] = -1;
	}

	return $index;
}

function duceapp_remostore_onAlbum(&$task) {
	global $_G;

	if ($task['runstatus'] != 1) {
		return 0;
	}

	$limit = $task['limit'] > 0 ? $task['limit'] : 10;
	$index = 0;

	if (!$task['marker']) {
		foreach(C::t('#duceapp_remostore#duceapp_remostore_home_pic')->fetch_all_data($task['direction'], $task['start'], $limit) as $pic) {
			$object = 'album/'.$pic['filepath'];
			$filename = $_G['setting']['attachdir'].$object;
			$succeed = false;
			if ($task['direction']) {
				if (C::m('#duceapp_remostore#duceapp_oss')->exec('objectExists', $object)) {
					dmkdir(dirname($filename));
					if (C::m('#duceapp_remostore#duceapp_oss')->exec('downFile', $filename, $object)) {
						C::t('#duceapp_remostore#duceapp_remostore_home_pic')->update_by_picid($pic['picid'], 0);
						$task['delsource'] && C::m('#duceapp_remostore#duceapp_oss')->exec('deleteFile', $object);
						$object = 'album/'.$pic['filepath'].'.thumb.jpg';
						$filename = $_G['setting']['attachdir'].$object;
						if ($pic['thumb'] && C::m('#duceapp_remostore#duceapp_oss')->exec('objectExists', $object) && 
							C::m('#duceapp_remostore#duceapp_oss')->exec('downFile', $filename, $object)) {
							$task['delsource'] && C::m('#duceapp_remostore#duceapp_oss')->exec('deleteFile', $object);
						}
						$succeed = true;
					}
				}
			} else {
				if (file_exists($filename) && C::m('#duceapp_remostore#duceapp_oss')->exec('uploadFile', $filename, $object, 'public')) {
					C::t('#duceapp_remostore#duceapp_remostore_home_pic')->update_by_picid($pic['picid'], 1);
					$task['delsource'] && @unlink($filename);
					$object = 'album/'.$pic['filepath'].'.thumb.jpg';
					$filename = $_G['setting']['attachdir'].$object;
					if ($pic['thumb'] && file_exists($filename) && C::m('#duceapp_remostore#duceapp_oss')->exec('uploadFile', $filename, $object, 'public')) {
						$task['delsource'] && @unlink($filename);
					}
					$succeed = true;
				}
			}
			$index++;
			if ($succeed) {
				$task['succeed']++;
			} else {
				$task['start']++;
				$task['failed']++;
			}
			$task['procesfile'] = $filename;
			$task['completed']++;
			$task['lastruntime'] = time();
			if ($task['ppp'] && $task['completed'] >= $task['ppp']) {
				$task['runstatus'] = 0;
				break;
			}
		}

		if ($index) {
			return $index;
		}
	}

	$task['marker'] = 1;

	foreach(C::t('#duceapp_remostore#duceapp_remostore_home_pic')->fetch_all_cover($task['direction'], $task['re_start'], $limit) as $album) {
		$object = 'album/'.$album['pic'];
		$filename = $_G['setting']['attachdir'].$object;
		$succeed = false;
		if ($task['direction']) {
			if (C::m('#duceapp_remostore#duceapp_oss')->exec('objectExists', $object)) {
				dmkdir(dirname($filename));
				if (C::m('#duceapp_remostore#duceapp_oss')->exec('downFile', $filename, $object)) {
					$task['delsource'] && C::m('#duceapp_remostore#duceapp_oss')->exec('deleteFile', $object);
					C::t('#duceapp_remostore#duceapp_remostore_home_pic')->update_by_albumid($album['albumid'], 1);
					$succeed = true;
				}
			}			
		} else {
			if (file_exists($filename) && C::m('#duceapp_remostore#duceapp_oss')->exec('uploadFile', $filename, $object, 'public')) {
				$task['delsource'] && @unlink($filename);
				C::t('#duceapp_remostore#duceapp_remostore_home_pic')->update_by_albumid($album['albumid'], 2);
				$succeed = true;
			}
		}
		$index++;
		if ($succeed) {
			$task['succeed']++;
		} else {
			$task['re_start']++;
			$task['failed']++;
		}
		$task['procesfile'] = $filename;
		$task['completed']++;
		$task['lastruntime'] = time();
		if ($task['ppp'] && $task['completed'] >= $task['ppp']) {
			$task['runstatus'] = 0;
			break;
		}
	}

	if (!$index) {
		$task['runstatus'] = -1;
	}

	return $index;
}

function duceapp_remostore_onPortal(&$task) {
	global $_G;

	$publicext = C::m('#duceapp_remostore#duceapp_oss')->getConfig('publicext');
	
	if ($task['runstatus'] != 1) {
		return 0;
	}

	$limit = $task['limit'] > 0 ? $task['limit'] : 10;
	$index = 0;

	if (!$task['marker']) {
		foreach(C::t('#duceapp_remostore#duceapp_remostore_portal_attachment')->fetch_all_attach($task['direction'], $task['start'], $limit) as $attach) {
			$object = 'portal/'.$attach['attachment'];
			$filename = $_G['setting']['attachdir'].$object;
			$succeed = false;
			if ($task['direction']) {
				if (C::m('#duceapp_remostore#duceapp_oss')->exec('objectExists', $object)) {
					dmkdir(dirname($filename));
					if (C::m('#duceapp_remostore#duceapp_oss')->exec('downFile', $filename, $object)) {
						C::t('#duceapp_remostore#duceapp_remostore_portal_attachment')->update_by_attachid($attach['attachid'], 0);
						$task['delsource'] && C::m('#duceapp_remostore#duceapp_oss')->exec('deleteFile', $object);
						$object = 'portal/'.$attach['attachment'].'.thumb.jpg';
						$filename = $_G['setting']['attachdir'].$object;
						if ($attach['thumb'] && C::m('#duceapp_remostore#duceapp_oss')->exec('objectExists', $object) && 
							C::m('#duceapp_remostore#duceapp_oss')->exec('downFile', $filename, $object)) {
							$task['delsource'] && C::m('#duceapp_remostore#duceapp_oss')->exec('deleteFile', $object);
						}
						$succeed = true;
					}
				}
			} else {
				if (file_exists($filename)) {
					$ext = ($ext = fileext($attach['filename'])) ? $ext : fileext($attach['attachment']);
					if (C::m('#duceapp_remostore#duceapp_oss')->exec('uploadFile', $filename, $object, @in_array($ext, $publicext) ? 'public' : 'private')) {
						C::t('#duceapp_remostore#duceapp_remostore_portal_attachment')->update_by_attachid($attach['attachid'], 1);
						$task['delsource'] && @unlink($filename);			
						$object = 'portal/'.$attach['attachment'].'.thumb.jpg';
						$filename = $_G['setting']['attachdir'].$object;
						if ($attach['thumb'] && file_exists($filename)) {
							if (C::m('#duceapp_remostore#duceapp_oss')->exec('uploadFile', $filename, $object, 'public')) {
								$task['delsource'] && @unlink($filename);
							}
						}
						$succeed = true;
					}
				}
			}
			$index++;
			if ($succeed) {
				$task['succeed']++;
			} else {
				$task['start']++;
				$task['failed']++;
			}
			$task['procesfile'] = $filename;
			$task['completed']++;
			$task['lastruntime'] = time();
			if ($task['ppp'] && $task['completed'] >= $task['ppp']) {
				$task['runstatus'] = 0;
				break;
			}	
		}

		if ($index) {
			return $index;
		}
	}

	$index = duceapp_remostore_reArticle($task);

	if (!$index) {
		$task['runstatus'] = -1;
	}

	return $index;
}

function duceapp_remostore_reArticle(&$task) {
	global $_G;

	$task['marker'] = 1;
	if ($task['runstatus'] != 1) {
		return 0;
	}

	$limit = $task['limit'] > 0 ? $task['limit'] : 5;
	$index = 0;

	foreach(C::t('#duceapp_remostore#duceapp_remostore_portal_attachment')->fetch_all_article($task['re_start'], $limit) as $artice) {
		$flag = false;
		foreach(DB::fetch_all("SELECT * FROM %t WHERE aid=%d AND isimage=1", array('portal_attachment', $artice['aid']), 'attachid') as $attach) {
			$matches = array();
			$object = 'portal/'.$attach['attachment'];
			$filepath = $attach['remote'] ? C::m('#duceapp_remostore#duceapp_oss')->objectUrl($object) : 'data/attachment/'.$object;
			preg_match_all('/src="(.*)"|href="(.*)"/iU', $artice['content'], $matches);
			foreach(array_merge($matches[1], $matches[2]) as $m) {
				if (strpos($m, $attach['attachment']) !== FALSE && $m != $filepath) {
					$artice['content'] = str_replace('"'.$m.'"', '"'.$filepath.'"', $artice['content']);
					$flag = true;
				}
			}
		}
		if ($flag) {
			C::t('portal_article_content')->update_by_aid($artice['aid'], array('content' => $artice['content']));
		}
		$index++;
		$task['re_start']++;
		$task['procesfile'] = $filepath;
		$task['succeed']++;
		$task['completed']++;
		$task['lastruntime'] = time();
		if ($task['ppp'] && $task['completed'] >= $task['ppp']) {
			$task['runstatus'] = 0;
			break;
		}
	}

	if (!$index) {
		$task['runstatus'] = -1;
	}

	return $index;
}

function duceapp_remostore_onAvatar(&$task) {
	global $_G;
	static $ucenterdir, $remoData;
	$ucenterurl = $_G['setting']['ucenterurl'];
	if ($ucenterdir === null) {
		$tmp = parse_url($_G['setting']['ucenterurl']);
		$ucenterdir = $tmp['host'] == $_SERVER['HTTP_HOST'] && strpos($tmp['path'], '/uc_server') !== false ? DISCUZ_ROOT.'uc_server' : false;
	}
	
	if ($task['runstatus'] != 1) {
		return 0;
	}

	$limit = $task['limit'] > 0 ? $task['limit'] : ($task['direction'] ? 5 : 10);
	$task['start'] = intval($task['start']);
	$index = 0;
	$remoDir = DISCUZ_ROOT.'data/duceapp/remostore/';
	if ($task['direction']) {
		$oss = C::m('#duceapp_remostore#duceapp_oss');
	}

	$members = DB::fetch_all('SELECT uid FROM %t WHERE avatarstatus<>0 ORDER BY regdate ASC'.DB::limit($task['start'], $limit), array('common_member'));
	foreach($members as $member) {
		$uidstr = sprintf("%09d", $member['uid']);
		$dir1 = substr($uidstr, 0, 3);
		$dir2 = substr($uidstr, 3, 2);
		$dir3 = substr($uidstr, 5, 2);
		$name = substr($uidstr, -2);
		$datafile = 'avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'.data';
		if (!$remoData || !isset($remoData[$datafile])) {
			$remoData[$datafile] = json_decode(@file_get_contents($remoDir.$datafile), true);
		}
		$ret = 0;
		if ($task['direction']) {
			$avatardir = 'data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.$name.($task['real'] ? '_real' : '');
			foreach(array('small','middle','big') as $size) {
				$avatar = $avatardir.'_avatar_'.$size.'.jpg';
				$filename = DISCUZ_ROOT.'uc_server/'.$avatar;
				if ($oss->exec('objectExists', $avatar, 'basedir:uc_server/')) {
					dmkdir(dirname($filename));
					$ret += $oss->exec('downFile', $filename, $avatar, 'basedir:uc_server/');
					if ($task['delsource'] && $ucenterdir) {
						C::m('#duceapp_remostore#duceapp_oss')->exec('deleteFile', $avatar, 'basedir:uc_server/');
						$remoData[$datafile][$member['uid']] = 0;
					}				
				}
			}
			if (!$ucenterdir && $ret) {
				if ($ret = C::m('#duceapp_remostore#duceapp_avatar')->putuc($member['uid'], $avatar)) {
					foreach(array('small','middle','big') as $size) {
						$avatar = $avatardir.'_avatar_'.$size.'.jpg';
						@unlink(DISCUZ_ROOT.'uc_server/'.$avatar);
						if ($task['delsource']) {
							C::m('#duceapp_remostore#duceapp_oss')->exec('deleteFile', $avatar, 'basedir:uc_server/');	
							$remoData[$datafile][$member['uid']] = 0;
						}
					}
				}
			}
			$task['procesfile'] = $ucenterurl.'/'.$avatar;
		} else {
			$avatar = 'data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.$name.($task['real'] ? '_real' : '').'_avatar_middle.jpg';
			$ret = $remoData[$datafile][$member['uid']] && $remoData[$datafile][$member['uid']] + 86400 > TIMESTAMP ? 1 : C::m('#duceapp_remostore#duceapp_avatar')->upload($member['uid'], $avatar, $ucenterurl, true);
			if ($ret) {
				$remoData[$datafile][$member['uid']] = TIMESTAMP;
			}
			$task['procesfile'] = $ucenterurl.'/'.$avatar;
		}
		if ($ret) {
			$task['succeed']++;
		} else {
			$task['failed']++;
		}
		$index++;
		$task['start']++;
		$task['completed']++;
		$task['lastruntime'] = time();
		if ($task['ppp'] && $task['completed'] >= $task['ppp']) {
			$task['runstatus'] = 0;
			break;
		}
	}

	if (!$index) {
		$task['runstatus'] = -1;
	}

	if ($remoData && ($task['runstatus'] == 0 || $task['runstatus'] == -1)) {
		foreach($remoData as $file => $data) {
			dmkdir(dirname($remoDir.$file));
			@file_put_contents($remoDir.$file, json_encode($data));
		}
	}

	return $index;
}

function duceapp_remostore_doRun($scene) {
	global $_G;
	loadcache('duceapp_remostore_taskcon', true);
	$task = array();
	$ret = 0;
	if ($runclass = $_G['cache']['duceapp_remostore_taskcon']['runclass']) {
		$task = & $_G['cache']['duceapp_remostore_taskcon'][$runclass];
		if ($task) {
			$task['runstatus'] = $task['scene'] == $scene ? 1 : 0;
			$task['completed'] = $task['completed'] >= $task['ppp'] ? 0 : $task['completed'];
		}
		$function = 'duceapp_remostore_on'.ucwords($runclass);
		if (function_exists($function)) {
			$ret = $function($task);
		} else {
			throw new Exception($runclass. ' function Nofound!');
		}
	}
	if (!$runclass || $task['runstatus'] == -1 || $task['scene'] != 'cron') {
		$cronid = C::t('common_cron')->get_cronid_by_filename('duceapp_remostore:cron_syndata.php');
		$cronid && C::t('common_cron')->update($cronid, array('available' => 0));
	}
	savecache('duceapp_remostore_taskcon', $_G['cache']['duceapp_remostore_taskcon']);
	return $task['runstatus'] && $ret;
}

function duceapp_remostore_doErr() {
	global $_G;
	loadcache('duceapp_remostore_taskcon', true);
	if ($runclass = $_G['cache']['duceapp_remostore_taskcon']['runclass']) {
		if ($_G['cache']['duceapp_remostore_taskcon'][$runclass]) {
			$_G['cache']['duceapp_remostore_taskcon'][$runclass]['runstatus'] = -2;
		}
		savecache('duceapp_remostore_taskcon', $_G['cache']['duceapp_remostore_taskcon']);
		$cronid = C::t('common_cron')->get_cronid_by_filename('duceapp_remostore:cron_syndata.php');
		$cronid && C::t('common_cron')->update($cronid, array('available' => 0));
	}
}

function duceapp_remostore_ignore_abort($scene, $sleep = 10) {
	if ($scene != 'cron') {
		@ignore_user_abort(TRUE);
    	@set_time_limit(0);
	}
	try {
		while(true) {
			if (!duceapp_remostore_doRun($scene)) {
				break;
			}
			$sleep && sleep($sleep);
		}
	} catch(Exception $e) {
		writelog('duceapp_remostore', print_r($e, true));
		duceapp_remostore_doErr();
    }
}