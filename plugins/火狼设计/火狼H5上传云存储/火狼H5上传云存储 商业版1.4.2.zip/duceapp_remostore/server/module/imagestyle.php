<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-07-05
 * Version: 3.10705
 * Date: 2021-09-13 11:55:25
 * File: imagestyle.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $postlist;

if ($_G['cache']['duceapp_remostore']['ossimgstyle'] && !@in_array($_G['fid'], $_G['cache']['duceapp_remostore']['ossexclfids'])) {
	foreach($postlist as $i => $post) {
		$postlist[$i]['message'] = preg_replace_callback('/https?:\/\/(?!(\.jpg|\.png)).+?(\.jpg\.thumb\.jpg|\.png\.thumb\.jpg|\.jpg|\.png)/is', function($m) {
			global $_G;
			if (strpos($m[0], C::m('#duceapp_remostore#duceapp_oss')->server->config['remourl']) === FALSE) {
				return $m[0];
			}
			if (strpos($m[0], '?') !== FALSE) {
				return $m[0].'&'.C::m('#duceapp_remostore#duceapp_oss')->exec('imageStyle', $_G['cache']['duceapp_remostore']['ossimgstyle']);
			} else {
				return $m[0].'?'.C::m('#duceapp_remostore#duceapp_oss')->exec('imageStyle', $_G['cache']['duceapp_remostore']['ossimgstyle']);
			}			
		}, $post['message']);
		
		if ($post['attachments']) {
			foreach($post['attachments'] as $aid => $attach) {
				if ($attach['isimage'] == 1 && strpos($attach['url'], C::m('#duceapp_remostore#duceapp_oss')->server->config['remourl']) !== FALSE) {
					$attach['attachment'] .= ($attach['thumb'] ? '.thumb.jpg' : '').'?'.C::m('#duceapp_remostore#duceapp_oss')->exec('imageStyle', $_G['cache']['duceapp_remostore']['ossimgstyle']);
					$attach['thumb'] = 0;
					$postlist[$i]['attachments'][$aid] = $attach;
				}
			}
		}
	}
}