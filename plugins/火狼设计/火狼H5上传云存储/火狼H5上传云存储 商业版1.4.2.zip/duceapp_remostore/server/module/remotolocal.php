<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-07-03
 * Version: 3.10730
 * Date: 2021-09-13 11:55:25
 * File: remotolocal.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$temp = array();
if (@in_array($_G['groupid'], $_G['cache']['duceapp_remostore']['remolocgids'])) {
	preg_match_all('/\[img(=\d{1,4}[x|\,]\d{1,4})?\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/is', $_GET['message'], $codeimgs, PREG_SET_ORDER);
	preg_match_all("/\<img.+src=('|\"|)?(.*)(\\1)([\s].*)?\>/ismUe", $_GET['message'], $tagimgs, PREG_SET_ORDER);
	if (is_array($codeimgs) && !empty($codeimgs)) {
		foreach($codeimgs as $value) {
			$temp[] = array($value[0], trim($value[2]));
		}
	}
	if (is_array($tagimgs) && !empty($tagimgs)) {
		foreach($tagimgs as $value) {
			$temp[] = array($value[0], trim($value[2]));
		}
	}
}

if (!empty($temp)) {
	$_G['setting']['thumbquality'] = $_G['cache']['duceapp_remostore']['thumbquality'] ? $_G['cache']['duceapp_remostore']['thumbquality'] : 100;
	$exclhost = $_G['cache']['duceapp_remostore']['exclhost'] ? 
		str_replace('/i', '|\/\/'.preg_quote($_SERVER['HTTP_HOST']).'/i', $_G['cache']['duceapp_remostore']['exclhost']) : 
		'/\/\/'.preg_quote($_SERVER['HTTP_HOST']).'/i';
	$search = $replace = $images = array();
	$upload = new discuz_upload();
	foreach($temp as $value) {
		$imagesrc = $value[1];		
		if ($imagesrc && preg_match('/^https?:\/\//i', $imagesrc) && !preg_match($exclhost, $imagesrc)){
			$key = md5($imagesrc);			
			if (!isset($images[$key])) {
				$images[$key] = $imagesrc;
				$filename = strrchr($imagesrc, '/');
				$attach = array();
				$attach['name'] = strpos($filename, '?') !== false ? substr($filename, 1, strpos($filename, '?') - 1) : substr($filename, 1);
				$attach['ext'] = 'jpg';
				$attach['thumb'] = '';
				$attach['isimage'] = 1;
				$attach['extension'] = $upload->get_target_extension($attach['ext']);
				$attach['attachdir'] = $upload->get_target_dir('forum');
                $attach['attachment'] = $attach['attachdir'] . $upload->get_target_filename('forum').'.'.$attach['extension'];
                $attach['target'] = getglobal('setting/attachdir').'./forum/'.$attach['attachment'];

				$binary = dfsockopen($imagesrc);
				$binary or ($binary = @file_get_contents($imagesrc));

				if (empty($binary) || !@$fp = fopen($attach['target'], 'wb')) {
					continue;
				}
				flock($fp, 2);
				fwrite($fp, $binary);
				fclose($fp);

				if (!($imageinfo = $upload->get_image_info($attach['target']))) {
					@unlink($attach['target']);
					continue;
				}
				
				$search[] = $value[0];

				$attach['size'] = filesize($attach['target']);
				$width = $imageinfo[0];
				$upload->attach = $attach;

				if ($_G['setting']['thumbsource'] && $_G['setting']['sourcewidth'] && $_G['setting']['sourceheight']) {
					$image = new image();
					$image->Thumb($upload->attach['target'], '', $_G['setting']['sourcewidth'], $_G['setting']['sourceheight'], 1, 1);
					$width = $image->imginfo['width'];
					$upload->attach['size'] = $image->imginfo['size'];
				}
				if ($_G['setting']['thumbstatus']) {
					$image = new image();
					$thumb = $image->Thumb($upload->attach['target'], '', $_G['setting']['thumbwidth'], $_G['setting']['thumbheight'], $_G['setting']['thumbstatus'], 0) ? 1 : 0;
					$width = $image->imginfo['width'];
				}
				if ($_G['setting']['watermarkstatus'] && empty($_G['forum']['disablewatermark'])) {
					$image = new image();
					$image->Watermark($attach['target'], '', 'forum');
					$upload->attach['size'] = $image->imginfo['size'];
				}

				$aid = getattachnewaid();
				$_GET['attachnew'][$aid] = array();

				$insert = array(
					'aid' => $aid,
					'dateline' => $_G['timestamp'],
					'filename' => $upload->attach['name'],
					'filesize' => $upload->attach['size'],
					'attachment' => $upload->attach['attachment'],
					'isimage' => $upload->attach['isimage'],
					'uid' => $_G['uid'],
					'thumb' => $thumb,
					'remote' => 0,
					'width' => $width,
				);
				C::t("forum_attachment_unused")->insert($insert);

				$images[$key] = $replace[] = '[attachimg]'.$aid.'[/attachimg]';				

			} else {
				$search[] = $value[0];
				$replace[] = $images[$key];
			}
		}
	}
	if ($search) {
		$_GET['message'] = str_replace($search, $replace, $_GET['message']);
	}
}