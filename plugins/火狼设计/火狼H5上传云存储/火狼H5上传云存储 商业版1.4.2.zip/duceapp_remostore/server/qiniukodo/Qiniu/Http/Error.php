<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * 最新插件：http://t.cn/Aiux1Jx1
 * Created: 2021-06-08
 * Version: 3.00905
 * Date: 2021-08-24 04:43:53
 * File: Error.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

namespace Qiniu\Http;

/**
 * 七牛业务请求逻辑错误封装类，主要用来解析API请求返回如下的内容：
 * <pre>
 *     {"error" : "detailed error message"}
 * </pre>
 */
final class Error
{
    private $url;
    private $response;

    public function __construct($url, $response)
    {
        $this->url = $url;
        $this->response = $response;
    }

    public function code()
    {
        return $this->response->statusCode;
    }

    public function getResponse()
    {
        return $this->response;
    }

    public function message()
    {
        return $this->response->error;
    }
}