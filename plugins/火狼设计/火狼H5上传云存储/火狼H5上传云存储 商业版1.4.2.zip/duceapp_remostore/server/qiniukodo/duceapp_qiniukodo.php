<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-07-20
 * Version: 3.10715
 * Date: 2021-08-24 04:43:52
 * File: duceapp_qiniukodo.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class duceapp_qiniukodo extends duceapp_ossbase
{
	public function __construct($config) {
		$this->config = $config;
		$this->bucket = $config['bucket'];
		$this->basedir = $config['basedir'];
		$this->client = new Qiniu\Auth($config['accesskey'], $config['secretkey']);
	}

	private function manager() {
		static $_obj;
		if ($_obj === null) {
			$_config = new \Qiniu\Config();
        	$_obj = new \Qiniu\Storage\BucketManager($this->client, $_config);
		}
		return $_obj;
	}	

	public function createBucket($bucket) {
		if (!defined('IN_ADMINCP')) {
			return;
		}
		list($ret, $err) = $this->manager()->createBucket(urlencode(base64_encode($bucket)), $this->config['region'] ? $this->config['region'] : 'z0');
		if ($err) {
			throw new Exception($err->code().' | '.$err->message());
		}
		$this->bucket = $bucket;
		return 1;
	}

	public function bucketExist($bucket) {
		try {
			list($info, $err) = $this->manager()->bucketInfo($bucket);
			if ($err) {
            	return 0;
        	}
			return $info;
		} catch(Exception $e) {
			if ($this->config['debug']) {
				throw new Exception($e->getMessage());
			}
            return 0;
        }
	}

	public function checkRes() {
		$res = array();
		try {
			$token = $this->client->uploadToken($this->bucket);
			$uploadManager = new Qiniu\Storage\UploadManager();
			list(, $err) = $uploadManager->put($token, 'test.txt', 'A test of qiniu');
			if ($err !== null) {
                throw new Exception($err->code().' | '.$err->message());
            }
			$res[0] = 1;
			$url = $this->client->privateDownloadurl($this->config['remourl'].'test.txt');
			$content = $this->fileSock($url);
			if ($content) {
                $res[2] = 1;
            }
			$this->manager()->delete($this->bucket, 'test.txt');
		} catch(Exception $e) {           
        }
		return $res;
	}

	public function setReferer() {
	}

	public function setCors() {
        list(, $err) = $this->manager()->putBucketAccessMode($this->bucket, 0);
		if ($err) {
			throw new Exception($err->code().' | '.$err->message());
        }
	}

	public function objectExists($object) {
		try {
			list($ret, $err) = $this->manager()->stat($this->bucket, $this->basedir.$object);
			if ($err) {
            	throw new Exception($err->code().' | '.$err->message());
				return 0;
        	}
			return $this->config['remourl'].$this->basedir.$object;
        } catch(Exception $e) {
            return 0;
        }
        return 1;
	}

	public function getFileslist($prefix = '', $marker = '', $limit = 100, $delimiter = '') {
		$res = array(
			'marker' => $marker,
			'run' => 0,
			'items' => array(),
		);
		while (true) {
			list($result, $err) = $this->manager()->listFiles($this->bucket, $prefix, $res['marker'], $limit > 0 ? $limit : 100, $delimiter);
			if ($err !== null) {
				return $res;
			}
			$res['marker'] = $result['marker'];
			foreach($result['items'] as $i => $item) {
				$res['items'][] = array(
					'key' => $item['key'],
					'size' => $item['fsize'],
					'mimeType' => $item['mimeType'],
					'filemtime' => substr(number_format($item['putTime'], 0, '', ''), 0, 10),
				);
			}
			$res['run']++;
			if ($limit > 0 || empty($res['marker'])) {
				break;
			}
		}
		return $res;
	}

	public function imageStyle($style) {
		return $style;
    }

	public function uploadFile($file, $object, $Acl = null) {
		try {
			if (!file_exists($file)) {
				return 0;
			}
			$token = $this->client->uploadToken($this->bucket, $this->basedir.$object);
			$uploadManager = new Qiniu\Storage\UploadManager();
			list($ret, $err) = $uploadManager->putFile($token, $this->basedir.$object, $file);
			if ($err) {
				throw new Exception($err->code().' | '.$err->message());
			}
			if ($Acl === null) {
				$Acl = $this->getAcl($file);
			}
			$Acl = $Acl == 'public' ? 0 : 1;
			$this->manager()->changeStatus($this->bucket, $this->basedir.$object, $Acl);
		} catch (Exception $e) {
			return 0;
		}
		return 1;
	}

	public function uploadData($data, $object, $Acl = null, $fread = false) {
		try {
			if ($fread) {
				$data = $this->fileSock($data);
			}
			if (empty($data)) {
				return 0;
			}
			$token = $this->client->uploadToken($this->bucket);
			$uploadManager = new Qiniu\Storage\UploadManager();
			list($ret, $err) = $uploadManager->put($token, $this->basedir.$object, $data);
			if ($err !== null) {
                throw new Exception($err->code().' | '.$err->message());
            }
			if ($Acl === null) {
				$Acl = $this->getAcl($object);
			}
			$Acl = $Acl == 'public' ? 0 : 1;
			$this->manager()->changeStatus($this->bucket, $this->basedir.$object, $Acl);
		} catch (Exception $e) {
			if ($this->config['debug']) {
                throw new Exception($e->getMessage());
            }
			return 0;
		}
		return $ret;
	}

	public function setAcl($object, $Acl = null) {
		$this->manager()->changeStatus($this->bucket, $this->basedir.$object, $Acl == 'public' ? 0 : 1);
		return 1;       
	}

	public function renameObject($oldObject, $newObject, $MimeType = null) {
		try {
			$err = $this->manager()->move($this->bucket, $this->basedir.$oldObject, $this->bucket, $this->basedir.$newObject);
			if ($err) {
				throw new Exception($err->code().' | '.$err->message());
			}
			$MimeType && $this->manager()->changeMime($this->bucket, $this->basedir.$newObject, $MimeType);
		} catch (Exception $e) {
			return 0;
		}
		return 1;
	}

	public function downFile($file, $object) {
		try {
			$url = $this->client->privateDownloadurl($this->config['remourl'].$this->basedir.$object);
			$content = $this->fileSock($url);
			if (!$content || !@file_put_contents($file, $content)) {
            	throw new Exception('downfile error!');
        	}
		} catch (Exception $e) {
			if ($this->config['debug']) {
                throw new Exception($e->getMessage());
            }
			return 0;
		}
		return 1;
	}

	public function deleteFile($objects) {
		try {
			if (is_array($objects)) {
				foreach($objects as $i => $object) {
					$objects[$i] = $this->basedir.$object;
				}
				$ops = $this->manager()->buildBatchDelete($this->bucket, $objects);
				list($ret, $err) = $this->manager()->batch($ops);
			} else {
				$err = $this->manager()->delete($this->bucket, $this->basedir.$objects);
			}
			if ($err) {
            	throw new Exception($err->code().' | '.$err->message());
        	}
		} catch (Exception $e) {
			return 0;
		}
		return 1;
	}

	public function getPolicy($dir, $object, $length = 1048576000) {
		$expires = 3600;
		$policy = array();
		$keyToOverwrite = $this->basedir.$dir.$object;
		$upToken = $this->client->uploadToken($this->config['bucket'], $keyToOverwrite, $expires, $policy, true);
		$arr = array(
			'token' => $upToken,
			'filename' => $keyToOverwrite,
		);
		return json_encode($arr);
	}
	
	public function signUrl($object, $filename = '', $expire = 3600) {
		empty($expire) && ($expire = 3600);
		$url = '';
		try {
			$url =  $this->client->privateDownloadurl($this->config['remourl'].$this->basedir.$object, $expire);
			if ($filename) {
				$filename = rawurldecode(diconv($filename, CHARSET, 'utf8'));
				$url .= '&attname='.$filename;
			}
		} catch (Exception $e) {
			if($this->config['debug']){
				throw(new Exception($e->getMessage()));
			}
			return 0;
		}
		return $url;
	}

	public function getData($object) {
		list($res, $err) = $this->manager()->stat($this->bucket, $object);
		$data = array();
		if ($err) {
			return null;
		}
		$data['object'] = strpos($object, $this->basedir) === 0 ? substr($object, strlen($this->basedir)) : $object;
		$data['size'] = $res['fsize'];
		$data['height'] = 0;
		$data['width'] = 0;
		if (strpos($res['mimeType'], 'image') !== FALSE) {
			$url = $this->config['remourl'].$object;
			$url .= '?imageInfo';
			$content = $this->fileSock($url);
			if (!$content) {
				return $data;
			}
			$content = json_decode($content, true);
			$data['height'] = $content['height'];
			$data['width'] = $content['width'];
		}
		return $data;
	}
}