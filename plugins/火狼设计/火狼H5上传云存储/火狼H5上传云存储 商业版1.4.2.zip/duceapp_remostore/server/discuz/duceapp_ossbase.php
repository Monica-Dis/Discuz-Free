<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-09
 * Version: 3.10705
 * Date: 2021-09-13 11:55:24
 * File: duceapp_ossbase.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

abstract class duceapp_ossbase
{
	public $bucket;
	public $client;
	public $config;
	public $basedir;
	public $publicext = array();

	public function gmt_iso8601($time) {
		$dtStr = date('c', $time);
		$mydatetime = new DateTime($dtStr);
		$expiration = $mydatetime->format(DateTime::ISO8601);
		$pos = strpos($expiration, '+');
		$expiration = substr($expiration, 0, $pos);
		return $expiration.'Z';
	}
    
	public function fileSock($url, $timeout = 15, $encodetype = 'URLENCODE') {
		global $_G;
		if (function_exists('curl_init') && function_exists('curl_exec')) {
			$ch = curl_init();
			$httpheader = array(
				'User-Agent: '.$_SERVER['HTTP_USER_AGENT'],
				'Referer: '.$_G['siteurl'],
			);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HEADER, 1);

			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
			curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
			$data = curl_exec($ch);
			$status = curl_getinfo($ch);
			$errno = curl_errno($ch);
			curl_close($ch);
			if ($errno || $status['http_code'] != 200) {
				return;
			} else {
				$GLOBALS['filesockheader'] = substr($data, 0, $status['header_size']);
				$data = substr($data, $status['header_size']);
				return $data;
			}
		}
	}

	public function getAcl($file) {
		$ext = addslashes(strtolower(substr(strrchr($file, '.'), 1, 16)));
		return $ext && @in_array($ext, $this->config['publicext']) ? 'public' : 'private';
	}
        
	abstract public function createBucket($bucket);
	abstract public function bucketExist($bucket);
	abstract public function setCors();
	abstract public function setReferer();
	abstract public function objectExists($object);
	abstract public function setAcl($object, $Acl = null);
	abstract public function uploadFile($file, $object, $Acl = null);
	abstract public function getFileslist($prefix = '', $marker = '', $limit = 100, $delimiter = '');
	abstract public function uploadData($data, $object, $Acl = null, $fread = false);
	abstract public function renameObject($oldObject, $newObject, $MimeType = null);
	abstract public function deleteFile($objects);
	abstract public function downFile($file, $object);
	abstract public function getPolicy($dir, $object, $length = 1048576000);
	abstract public function signUrl($object);
	abstract public function getData($object);
}