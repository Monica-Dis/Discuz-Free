<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-08
 * Version: 3.10906
 * Date: 2021-09-13 11:55:24
 * File: discuz_ftp.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!defined('FTP_ERR_SERVER_DISABLED')) {
	define('FTP_ERR_SERVER_DISABLED', -100);
	define('FTP_ERR_CONFIG_OFF', -101);
	define('FTP_ERR_CONNECT_TO_SERVER', -102);
	define('FTP_ERR_USER_NO_LOGGIN', -103);
	define('FTP_ERR_CHDIR', -104);
	define('FTP_ERR_MKDIR', -105);
	define('FTP_ERR_SOURCE_READ', -106);
	define('FTP_ERR_TARGET_WRITE', -107);
}

class discuz_ftp
{
	var $enabled = false;
	var $config = array();

	var $func;
	var $connectid;
	var $_error;

	function &instance($config = array()) {
		static $object;
		if(empty($object)) {
			$object = new discuz_ftp($config);
		}
		return $object;
	}

	function __construct($config = array()) {
		$this->set_error(0);
		$this->enabled = true;
	}

	function __call($name, $arguments) {
        return '';
    }

	function upload($source, $target) {
		global $_G;
		static $attachs;
		$watermark = $_G['cache']['duceapp_remostore']['watermark'];
		if (CURSCRIPT == 'forum' && (empty($watermark['forum']['fid']) || @in_array($_G['fid'], $watermark['forum']['fid'])) && 
			($waterstatus = duceapp_remostore_watermark('forum'))) {
			require_once libfile('class/duceapp_image', 'plugin/duceapp_remostore');
			$image = new duceapp_image;
			if ($waterstatus == 1 && preg_match('/\.thumb\.jpg$/', $source)) {
				$image->Watermark($source, '', 'forum');
			}
			if ($waterstatus == 2 && !preg_match('/\.thumb\.jpg$/', $source)) {
				$image->Watermark($source, '', 'forum');
			}
		}
		if (!duceapp_remostore_getstatus(0) || !duceapp_remostore_getstatus(1)) {
			$v = debug_backtrace()[2];
            $isimg = false;
            if (!is_array($attachs) && ($v['function'] == 'ftpupload') && !empty($v['args'][0])) {
                foreach(C::t('forum_attachment')->fetch_all($v['args'][0]) as $attach) {
                    $temp  = C::t('forum_attachment_n')->fetch_all($attach['tableid'], $attach['aid'], 0);
                    $attachs[] = $temp[0];
                }
            }
			list(, $filename) = preg_split('/(forum|album|portal)\//i', $source);				
			if ($filename) {
				foreach($attachs as $attach) {					
					if (str_replace('.thumb.jpg', '', $filename) == $attach['attachment']) {						
						$isimg = $attach['isimage'];
						break;
					}
				}
				if ((!duceapp_remostore_getstatus(0) && $isimg > 0) || (!duceapp_remostore_getstatus(1) && $isimg <= 0)) {					
					return 0;
				}
			}
		}
		$size = ($size = intval($_G['cache']['duceapp_remostore']['ossmaxsize'])) > 0 ? $size : 20;
		if (file_exists($source) && filesize($source) <= $size * 1024 * 1024) {
			return C::m('#duceapp_remostore#duceapp_oss')->exec('uploadFile', $source, $target);
        } elseif (file_exists($source)) {
			return 0;
        } else {
			return 1;
        }
	}

	function ftp_size($path) {
        global $_G;
        $v = debug_backtrace()[1];
        if (C::m('#duceapp_remostore#duceapp_oss')->exec('objectExists', $path)) {
            return 1;
        } elseif (($v['function'] == 'block_updateitem') && ($bid = $v['args'][0]) && ($block = $_G['block'][$bid])) {
            $pic = '';
            foreach(C::t('common_block_item')->fetch_all_by_bid($bid, true) as $value) {
                $item1 =  array('pic' => $value['pic'],'picflag' => 1);
                $item2 = array('pic' => $value['pic'],'picflag' => 2);
                if ((block_thumbpath($block,$item1) == $path) || (block_thumbpath($block, $item2) == $path)) {
                    $pic = $value['pic'];
                    break;
                }
            }
            $basedir = !$_G['setting']['attachdir'] ? (DISCUZ_ROOT.'./data/attachment/') : $_G['setting']['attachdir'];
            if (!empty($pic) && C::m('#duceapp_remostore#duceapp_oss')->exec('objectExists', $pic)) {
                $tmpfilename =$_G['setting']['attachdir'].'temp/'.random(16).substr(strrchr($path, '.'), 0);
                require_once libfile('class/image');
                $image = new image();
                if (C::m('#duceapp_remostore#duceapp_oss')->exec('downFile', $tmpfilename, $pic) && 
					$image->Thumb($tmpfilename, $path, $block['picwidth'], $block['picheight'], 2)
                    && $this->upload($basedir.$path, $path)) {
					@unlink($tmpfilename);
					@unlink($basedir.$path);
					return 1;
                }
            }
        }
        return 0;
    }

	function ftp_get($local_file, $remote_file, $mode, $resumepos = 0) {
        $remote_file = discuz_ftp::clear($remote_file);
        $local_file = discuz_ftp::clear($local_file);
        return C::m('#duceapp_remostore#duceapp_oss')->exec('downFile', $local_file, $remote_file);
    }

	function ftp_delete($path) {
        $path = discuz_ftp::clear($path);
        return C::m('#duceapp_remostore#duceapp_oss')->exec('deleteFile', $path);
    }

	function connect() {
		return $this->connectid = 1;
	}

	function set_error($code = 0) {
		$this->_error = $code;
	}

	function error() {
		return $this->_error;
	}

	function clear($str) {
		return str_replace(array( "\n", "\r", '..'), '', $str);
	}
}