<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-09
 * Version: 3.10821
 * Date: 2021-09-13 11:55:24
 * File: model_duceapp_avatar.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class model_duceapp_avatar
{
	public function hook($value) {
		global $_G;

		$uid = abs(intval($value['param'][0]));
		$size = in_array($value['param'][1], array('big', 'middle', 'small')) ? $value['param'][1] : 'middle';
		$returnsrc = isset($value['param'][2]) ? $value['param'][2] : FALSE;
		$real = isset($value['param'][3]) ? $value['param'][3] : FALSE;
		$static = isset($value['param'][4]) ? $value['param'][4] : FALSE;
		$ucenterurl = empty($value['param'][5]) ? $_G['setting']['ucenterurl'] : $value['param'][5];
		
		static $staticavatar;
		if ($staticavatar === null) {
			$staticavatar = $_G['setting']['avatarmethod'];
		}
		if ($_G['cache']['duceapp_remostore']['cpavatar']['forcestatic']) {
			$static = true;
		}

		$avatar = & $_G['hookavatar'];
		if (!$staticavatar && !$static) {
			$timestamp = $uid == $_G['uid'] ? '&random=1' : '';
			if (!defined('DUCEAPP_OSSON') || !duceapp_remostore_getstatus(4)) {
				$avatar = $returnsrc ? $ucenterurl.'/avatar.php?uid='.$uid.'&size='.$size.($real ? '&type=real' : '').$timestamp : '<img src="'.$ucenterurl.'/avatar.php?uid='.$uid.'&size='.$size.($real ? '&type=real' : '').$timestamp.'" />';
			} else {
				$avatar = $returnsrc ? $_G['siteurl'].'plugin.php?id=duceapp_remostore:avatar&uid='.$uid.'&size='.$size.($real ? '&type=real' : '').$timestamp : '<img src="'.$_G['siteurl'].'plugin.php?id=duceapp_remostore:avatar&uid='.$uid.'&size='.$size.($real ? '&type=real' : '').$timestamp.'" />';
			}
		} else {
			$uidstr = sprintf("%09d", $uid);
			$dir1 = substr($uidstr, 0, 3);
			$dir2 = substr($uidstr, 3, 2);
			$dir3 = substr($uidstr, 5, 2);
			$file = 'data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uidstr, -2).($real ? '_real' : '').'_avatar_'.$size.'.jpg';
			if (defined('DUCEAPP_OSSON') && duceapp_remostore_getstatus(4) && $this->check($uid, $file)) {
				$file = C::m('#duceapp_remostore#duceapp_oss')->objectUrl($file, $ucenterurl.'/', 'uc_server/');
			} elseif ($_file = $this->upload($uid, $file, $ucenterurl)) {
				$file = $_file;
			} else {
				$file = $ucenterurl.'/'.$file;
			}
			$file .= ($random ? "?random=$rand" : '');
			$avatar = $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.$ucenterurl.'/images/noavatar_'.$size.'.gif\'" />';
		}
		return $avatar;
	}

	public function check($uid, $file, $batchtime = null) {
		static $remotes = array();
		$key = substr(dirname($file), 5);
		$datafile = DISCUZ_ROOT.'data/duceapp/remostore/'.$key.'.data';
		if (!isset($remotes[$key])) {
			$remotes[$key] = json_decode(@file_get_contents($datafile), true);
		}
		$return = $remotes[$key] && $remotes[$key][$uid];
		if ($_GET['batchnew']) {
			$batchtime = $return = 0;
		}
		if ($batchtime !== null && (!$return || $remotes[$key][$uid] + 86400 < TIMESTAMP)) {
			$remotes[$key][$uid] = intval($batchtime);
			dmkdir(dirname($datafile));
			@file_put_contents($datafile, json_encode($remotes[$key]));
		}
		return $return > 0 ? true : false;
	}

	public function upload($uid, $file, $ucenterurl = '', $intask = false) {
		global $_G;
		static $ucenterdir;
		if (!defined('DUCEAPP_OSSON') || !duceapp_remostore_getstatus(4)) {
			return false;
		}
		$ucenterurl = $ucenterurl ? $ucenterurl : $_G['setting']['ucenterurl'];
		if ($ucenterdir === null) {
			$tmp = parse_url($ucenterurl);
			$ucenterdir = $tmp['host'] == $_SERVER['HTTP_HOST'] && strpos($tmp['path'], '/uc_server') !== false ? DISCUZ_ROOT.'uc_server' : false;
		}
		$avatarfore = substr($file, 0, strrpos($file, '_'));
		$s_avatar = $avatarfore.'_small.jpg';
		$m_avatar = $avatarfore.'_middle.jpg';
		$b_avatar = $avatarfore.'_big.jpg';
		$oss = C::m('#duceapp_remostore#duceapp_oss');
		$ret = 0;
		if ($ucenterdir) {
			$ret += $oss->exec('uploadFile', $ucenterdir.'/'.$s_avatar, $s_avatar, 'public', 'basedir:uc_server/');
			$ret += $ret > 0 ? $oss->exec('uploadFile', $ucenterdir.'/'.$m_avatar, $m_avatar, 'public', 'basedir:uc_server/') : 0;
			$ret += $ret > 1 ? $oss->exec('uploadFile', $ucenterdir.'/'.$b_avatar, $b_avatar, 'public', 'basedir:uc_server/') : 0;
		} else {
			$ret += $oss->exec('uploadData', $ucenterurl.'/'.$s_avatar, $s_avatar, 'public', true, 'basedir:uc_server/') ? 1 : 0;
			$ret += $ret > 0 ? ($oss->exec('uploadData', $ucenterurl.'/'.$m_avatar, $m_avatar, 'public', true, 'basedir:uc_server/') ? 1 : 0) : 0;
			$ret += $ret > 0 ? ($oss->exec('uploadData', $ucenterurl.'/'.$b_avatar, $b_avatar, 'public', true, 'basedir:uc_server/') ? 1 : 0) : 0;
		}
		if ($intask) {
			return $ret;
		}
		$this->check($uid, $file, $ret ? TIMESTAMP : -1);
		if ($oss->exec('objectExists', $file, 'basedir:uc_server/')) {
			return $oss->objectUrl($file, $ucenterurl.'/', 'uc_server/');
		}
		return false;
	}

	public function putuc($uid, $file) {
		global $_G;
		$avatarfore = DISCUZ_ROOT.'uc_server/'.substr($file, 0, strrpos($file, '_'));
		$type = strpos($file, '_real') !== false ? 'real' : 'virtual';
		$avatardata = '';
		foreach(array('_big.jpg', '_middle.jpg', '_small.jpg') as $i => $size) {
			if ($fp = @fopen($avatarfore.$size, 'rb')) {
				$avatardata .= ($avatardata ? '&' : '') . 'avatar' . ($i+1) . '=' . urlencode(base64_encode(fread($fp, filesize($avatarfore.$size))));
				fclose($fp);
			}
		}
		!defined('UC_API') && loaducenter();
		$request = UC_API.'/index.php?m=user&a=rectavatar&base64=1&inajax=1'.
			'&appid='.UC_APPID.'&input='.uc_api_input("uid=$uid").'&agent='.md5($_SERVER['HTTP_USER_AGENT']).
			'&ucapi='.urlencode(UC_API).'&avatartype='.$type.'&uploadSize=2048';
		
		$data = uc_fopen($request, 0, $avatardata);

		return $data && (strpos($data, "'success'") !== false || strpos($data, 'success="1"') !== false);
	}
}