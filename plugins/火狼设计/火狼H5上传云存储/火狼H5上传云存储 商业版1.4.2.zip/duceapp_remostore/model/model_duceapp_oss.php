<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-07
 * Version: 3.10821
 * Date: 2021-09-13 11:55:24
 * File: model_duceapp_oss.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class model_duceapp_oss
{
	public $server;

	public function __construct($ossapi = null) {
		global $_G;
		if (!isset($_G['cache']['duceapp_remostore'])) {
			loadcache('duceapp_remostore');
		}
		$config = array();
		$ossapi = $ossapi && defined('IN_ADMINCP') ? $ossapi : $_G['cache']['duceapp_remostore']['ossapi'];
		if (preg_match('/^[a-z0-9\_]+$/i', $ossapi)) {
			define('DUCEAPP_OSSROOT', DISCUZ_ROOT.'source/plugin/duceapp_remostore/server/'.$ossapi.'/');
			$config = $_G['cache']['duceapp_remostore']['server'][$ossapi];
		}		
		if (!empty($config) && $config['bucket'] && file_exists(DUCEAPP_OSSROOT.'autoload.php')) {
			if (!empty($_G['cache']['duceapp_remostore']['basedir'])) {
				$config['basedir'] = preg_replace('/\/+$/', '', $_G['cache']['duceapp_remostore']['basedir']).'/';
			}
			$config['remourl'] = preg_replace('/\/+$/', '', $config['remourl']).'/';
			$config['debug'] = defined('IN_ADMINCP') || ($_G['cache']['duceapp_remostore']['debug'] && $_G['adminid']);
			$config['domain'] = preg_replace('/\/+$/', '', (preg_match('/^https?/i', $config['domain']) ? '' : 'https://').$config['domain']).'/';
			$oldFunctions = spl_autoload_functions();
			if ($oldFunctions) {
       			foreach ($oldFunctions as $f) {
					spl_autoload_unregister($f);
				}
			}
			spl_autoload_register(array('model_duceapp_oss', 'classLoader'));
			require_once DUCEAPP_OSSROOT.'autoload.php';
			if ($oldFunctions) {
       			foreach ($oldFunctions as $f) {
					spl_autoload_register($f);
				}
			}
			$_G['setting']['ftp']['on'] = 1;
        	$_G['setting']['ftp']['attachurl'] = $config['remourl'].$config['basedir'];
			$publicext = explode(',', preg_replace('/\s/', '', $_G['cache']['duceapp_remostore']['publicext']));
			$config['publicext'] = array_merge(array('png','jpg','jpeg','bmp','gif','PNG','JPG','JPEG','BMP','GIF'), $publicext);
			$classKey = 'duceapp_'.$ossapi;
			$this->server = new $classKey($config);
			define('DUCEAPP_OSSON', $ossapi);
		} elseif (!empty($_G['cache']['duceapp_remostore']['attachurl'])) {
			$_G['setting']['ftp']['attachurl'] = $_G['cache']['duceapp_remostore']['attachurl'];
		}
	}

	public function exec() {
		if ($this->server) {
			$args = func_get_args();
			$method = array_shift($args);
			$n = count($args);
			$basedir = null;
			if (strpos($args[$n-1], 'basedir:') !== false) {
				$basedir = array_pop($args);
				$this->server->basedir = $basedir == 'basedir:' ? '' : substr($basedir, 8);
			}
			try {
				$ret = call_user_func_array(array($this->server, $method), $args);
				if ($basedir !== null) {
					$this->server->basedir = $this->server->config['basedir'];
				}
				return $ret;
			} catch(Exception $e) {
				if ($this->server->config['debug']) {
					$message = diconv($e->getMessage(), 'utf-8');
					defined('IN_ADMINCP') ? duceapp_error($message) : showmessage($message, NULL);
				}
				return 0;
			}
		}
		return null;
	}
	
	public function module($name) {
		if ($this->server) {
			global $_G;
			require_once libfile($name, 'plugin/duceapp_remostore/server/module');
		}
	}

	public function getConfig($key) {
		if ($this->server) {
			return $this->server->config[$key];
		}
		return false;
	}

	public function objectUrl($object, $forec = '', $basedir = null) {
		if ($this->server) {
			$basedir = $basedir !== null ? $basedir : $this->server->basedir;
			return $this->server->config['remourl'].$basedir.$object;
		} else {
			return $forec.$object;
		}
	}

	public function classLoader($class) {
		$discuz = array('discuz_ftp', 'forum_upload', 'duceapp_ossbase', 'extend_thread_image', 'extend_thread_activity');
		if (duceapp_remostore_getstatus(2)) {
			$discuz[] = 'extend_thread_sort';
		}
		if (duceapp_remostore_getstatus(3)) {
			$discuz[] = 'extend_thread_trade';
		}
		$dir = in_array($class, $discuz) ? DISCUZ_ROOT.'source/plugin/duceapp_remostore/server/discuz/' : DUCEAPP_OSSROOT;
		$path = str_replace('\\', DIRECTORY_SEPARATOR, $class);
		$file = $dir . $path . '.php';
		if (file_exists($file)) {
			require_once $file;
		}
	}

	public function bucketCheck($config, $formurl, $extra = '', $object = null) {
		if (!defined('IN_ADMINCP')) {
			return $config;
		}
		if (!($response = $this->exec('bucketExist', $config['bucket']))) {
			if ($_GET['confirm'] && authcode($_GET['confirm'], 'DECODE') == $config['bucket']) {
				$ret = $this->exec('createBucket', $config['bucket']);
				if ($ret) {
					$config = $object->created($config);
				} else {
					duceapp_error('bucket_createrroe', array('bucket' => $config['bucket']));
				}
			} else {
				foreach($config as $key => $val) {
					$extra = '<input type="hidden" name="setting['.$key.']" value="'.$val.'">'.$extra;
				}
				$extra .= '<input type="hidden" name="duceapp_submit" value="true"><input type="hidden" name="confirm" value="'.authcode($config['bucket'], 'ENCODE', '', 180).'">';
				duceapp_cpmsg('bucket_noexists', $formurl, 'form', array('bucket' => $config['bucket']), $extra);
			}
		} else {
			$config = $object->domain($config, $response);
		}
		return $config;
	}	
}