<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-12
 * Version: 3.10720
 * Date: 2021-09-13 11:55:24
 * File: model_duceapp_cptools.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

class model_duceapp_cptools
{
	function cron_create($pluginid, $filename = null, $name = null, $weekday = null, $day = null, $hour = null, $minute = null) {
		if(!ispluginkey($pluginid)) {
			return false;
		}
		$dir = DISCUZ_ROOT.'./source/plugin/'.$pluginid.'/cron';
		if(!file_exists($dir)) {
			return false;
		}
		$crondir = dir($dir);
		while($filename = $crondir->read()) {
			if(!in_array($filename, array('.', '..')) && preg_match("/^cron\_[\w\.]+$/", $filename)) {
				$content = file_get_contents($dir.'/'.$filename);
				preg_match("/cronname\:(.+?)\n/", $content, $r);$name = lang('plugin/'.$pluginid, trim($r[1]));
				preg_match("/week\:(.+?)\n/", $content, $r);$weekday = trim($r[1]) ? intval($r[1]) : -1;
				preg_match("/day\:(.+?)\n/", $content, $r);$day = trim($r[1]) ? intval($r[1]) : -1;
				preg_match("/hour\:(.+?)\n/", $content, $r);$hour = trim($r[1]) ? intval($r[1]) : -1;
				preg_match("/minute\:(.+?)\n/", $content, $r);$minute = trim($r[1]) ? trim($r[1]) : 0;
				$minutenew = explode(',', $minute);
				foreach($minutenew as $key => $val) {
					$minutenew[$key] = $val = intval($val);
					if($val < 0 || $var > 59) {
						unset($minutenew[$key]);
					}
				}
				$minutenew = array_slice(array_unique($minutenew), 0, 12);
				$minutenew = implode("\t", $minutenew);
				$filename = $pluginid.':'.$filename;
				$cronid = C::t('common_cron')->get_cronid_by_filename($filename);
				if(!$cronid) {
					C::t('common_cron')->insert(array(
						'available' => 1,
						'type' => 'plugin',
						'name' => $name,
						'filename' => $filename,
						'weekday' => $weekday,
						'day' => $day,
						'hour' => $hour,
						'minute' => $minutenew,
					), true);
				} else {
					C::t('common_cron')->update($cronid, array(
						'name' => $name,
						'weekday' => $weekday,
						'day' => $day,
						'hour' => $hour,
						'minute' => $minutenew,
					));
				}
			}
		}
	}

	function fmtcode($str, $dark = true){
		$code = array();
		preg_match_all('/(\<!\-\-([\S\s]+?)\-\-\>)/', $str, $parseCode);
		preg_match_all('/(\/\*([\S\s]+?)\*\/)/', $str, $noteCode);
		if ($parseCode[0]) {
			foreach($parseCode[0] as $i => $c) {
				$str = str_replace($c, '{parseCode_'.$i.'}', $str);
				$parseCode[0][$i] = str_replace(array('<', '>'), array('<em class="_note">&lt;', '&gt;</em>'), $c);
			}
		}
		if ($noteCode[0]) {
			foreach($noteCode[0] as $i => $c) {
				$str = str_replace($c, '{noteCode_'.$i.'}', $str);
				$noteCode[0][$i] = '<em class="_note">'.str_replace(array('<', '>'), array('&lt;', '&gt;'), $c).'</em>';
			}
		}
		preg_match_all('/(\<(div|a|span|em|li|ul|ol|cite|table|tr|td|tbody)([^>]+)\>)/i', $str, $htmlCode);
		if ($htmlCode[0]) {
			foreach($htmlCode[0] as $i => $c) {
				$str = str_replace($c, '{htmlCode_'.$i.'}', $str);
			}
		}
		foreach(explode("\n", $str) as $i => $line) {
			$line = str_replace("\r", '', $line);
			$notepos = strpos($line, '//');
			$notes = '';
			if ($notepos !== false) {
				$code[$i] = substr($line, 0, $notepos - 1);
				$notes = '<em class="_note">'.substr($line, $notepos - 1).'</em>';
			} else {
				$code[$i] = $line;
			}
			$code[$i] = preg_replace(array(
				'/([\'"])([^\\1]+?)(\\1)/i',
				'/(\$[a-z0-9_]+)(\s*\=)?/i',
				'/(if|else|elseif|return|include_once|array|global|break|defined|\=\>)/i',
				'/(function)(\s+[a-z0-9_]+\s*\()/i',
				'/(is_array|in_array|file_exists|strtolower|json_decode|urlencode|serialize)(\s*\()/i',
				'/(\:\:|define)/i',
			), array(
				'<em class="_quot">\\1\\2\\3</em>',
				'<em class="_vars">\\1</em><em class="_evns">\\2</em>',
				'<em class="_evns">\\1</em>',
				'<em class="_evns">\\1</em>\\2',
				'<em class="_func">\\1</em>\\2',
				'<em class="_evns">\\1</em>'
			), $code[$i]).$notes;
		}
		$code = implode("\n", $code);
		if ($parseCode[0]) {
			foreach($parseCode[0] as $i => $c) {
				$code = str_replace('{parseCode_'.$i.'}', $c, $code);
			}
		}
		if ($noteCode[0]) {
			foreach($noteCode[0] as $i => $c) {
				$code = str_replace('{noteCode_'.$i.'}', $c, $code);
			}
		}
		if ($htmlCode[0]) {
			foreach($htmlCode[0] as $i => $c) {
				$code = str_replace('{htmlCode_'.$i.'}', $c, $code);
			}
		}
		return '<pre id="previewCommoncode" class="duceapp_codes'.($dark ? '_b' : '').'">'.$code.'</pre>';
	}
}