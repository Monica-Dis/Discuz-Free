<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-11
 * Version: 3.10821
 * Date: 2021-09-13 11:55:28
 * File: syndata.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once libfile('class/duceapp_admincp', 'plugin/duceapp_remostore');

class duceapp_modcp extends duceapp_admincp
{
	public $anchors = array('taskcon', 'cronlist');

	public function __construct() {
		global $_G;
		$this->header();
		if (!isset($_G['cache']['duceapp_remostore_taskcon'])) {
			loadcache('duceapp_remostore_taskcon');
		}		
		duceapp_showanchors('syndata', 1);
		if ($this->cpmethod == 'save' && $this->danchor == 'taskcon' && empty($_GET['taskcon_confirm'])) {
			$this->cpmethod = 'main';
		}		
		if ($_GET['oauth']) {
			$this->cpmethod = 'proces';
		}
		call_user_func(array(__CLASS__, $this->cpmethod));

		$this->footer();
	}

	private function main() {
		global $_G, $lang;
		if (!$this->setting['ossapi']) {
			duceapp_cpmsg('syndata_invalid', $this->redirect.'&pmod=compon&api=oss', 'error');
		}		
		duceapp_formheader();
		if ($this->danchor == 'taskcon') {
			$runclass = $_G['cache']['duceapp_remostore_taskcon']['runclass'] ? $_G['cache']['duceapp_remostore_taskcon']['runclass'] : 'forum';
			$task = $_G['cache']['duceapp_remostore_taskcon'][$runclass];

			echo '<script type="text/javascript" src="'.STATICURL.'js/calendar.js"></script>';
			showhiddenfields(array('taskcon_confirm' => '', 'syndata_task' => ''));
			duceapp_anchortips('syndata_tips', 'taskcon');
			duceapp_anchorheader('taskcon');
			duceapp_showsetting('syndata_runclass', array('setting[runclass]', array(
				array('forum', duceapp_cplang('setting_cldstat_forum'), array('runclass' => '')),
				array('sorttype', duceapp_cplang('setting_cldstat_sorttype'), array('runclass' => 'none')),
				array('album', duceapp_cplang('setting_cldstat_album'), array('runclass' => 'none')),
				array('portal', duceapp_cplang('setting_cldstat_portal'), array('runclass' => 'none')),
				array('avatar', duceapp_cplang('setting_cldstat_avatar'), array('runclass' => 'none')),
			)), $runclass, 'mradio', '', '', duceapp_cplang('syndata_runclass_comment', array(
				'forum' => C::t('#duceapp_remostore#duceapp_remostore_forum_attachment')->count_all(0),
				'forum_remote' => C::t('#duceapp_remostore#duceapp_remostore_forum_attachment')->count_all(1),
				'sorttype' => C::t('#duceapp_remostore#duceapp_remostore_forum_typeoptionvar')->count_by_value(0),
				'sorttype_remote' => C::t('#duceapp_remostore#duceapp_remostore_forum_typeoptionvar')->count_by_value(1),
				'album' => C::t('#duceapp_remostore#duceapp_remostore_home_pic')->count_all(0),
				'album_remote' => C::t('#duceapp_remostore#duceapp_remostore_home_pic')->count_all(1),
				'portal' => C::t('#duceapp_remostore#duceapp_remostore_portal_attachment')->count_all(0),
				'portal_remote' => C::t('#duceapp_remostore#duceapp_remostore_portal_attachment')->count_all(1),
				'avatar' => DB::result_first('SELECT COUNT(*) FROM %t WHERE avatarstatus<>0', array('common_member')),
			)));
			duceapp_showsetting('syndata_direction', array('setting[direction]', array(
				array(0, duceapp_cplang('syndata_direction_0')),
				array(1, duceapp_cplang('syndata_direction_1')),
			)), intval($task['direction']), 'mradio', '', '', duceapp_cplang('syndata_direction_comment', array('server' => duceapp_cplang('menu_'.$this->setting['ossapi']), 'display' => !empty($task) && $task['runstatus'] != -1 ? 'none' : '')));
			duceapp_showsetting('syndata_actask', array('setting[actask]', array(
				array(1, duceapp_cplang('syndata_actask_1'), array('duceapp_actask_bd' => '', 'delsource' => '')),
				array(0, duceapp_cplang('syndata_actask_0'), array('duceapp_actask_bd' => 'none', 'delsource' => 'none')),
			)), !empty($task) && $task['runstatus'] != -1 ? 0 : 1, 'mradio');
			showtablefooter(); /*dism��taobao��com*/
			duceapp_anchorheader('actask', empty($task) || $task['runstatus'] == -1, '', 'style="margin-top:-8px;"');
			showtagheader('tbody', 'runclass', $runclass == 'forum');
			duceapp_showsetting('syndata_limitdate', 'setting[limitdate]', '', 'calendar');
			duceapp_showsetting('syndata_fileext', 'setting[fileext]', '', 'text');
			duceapp_showsetting('syndata_filesize', 'setting[filesize]', '', 'text');
			showtagfooter('tbody');
			duceapp_anchorfooter();
			showtableheader();
			showsubmit('duceapp_submit', duceapp_cplang('syndata_submit'), '', '', '', false);
			showtablefooter(); /*dism��taobao��com*/
			echo '<script type="text/javascript">
			$("submit_duceapp_submit").setAttribute("onclick", "return false");
			_attachEvent($("submit_duceapp_submit"), "click", function() {
				var form = this.form;
				var actask = "setting[actask]";
				var msg = "'.addslashes(duceapp_cplang('taskcon_confirm')).'";
				if (form[actask].value == 1) {
					duceapp_prompt(msg + "'.addslashes(duceapp_cplang('taskcon_action')).'", {w:450,drag:1}, function(){
						if (parent.document.getElementById("taskcon_action2").checked == true) {
							form["syndata_task"].value = "1";
						}
						form["taskcon_confirm"].value = "yes";
						form.submit();
					});
				} else {
					var x = new Ajax(), direction="setting[direction]", runclass="setting[runclass]";
					var postdata = "setting[actask]=0&setting[direction]="+form[direction].value+"&setting[runclass]="+form[runclass].value;
					x.post("'.$this->redirect.'&inajax=1", "duceapp_submit=yes&taskcon_confirm=1&formhash='.FORMHASH.'&" + postdata, function(s, x) {
						if (s.indexOf("error") == -1) {
							msg = s;
						}
						duceapp_prompt(msg, {w:450,drag:1}, function(){
							form["taskcon_confirm"].value = "yes";
							form.submit();
						});
					});
				}
				return false;
			});
			</script>';
		} elseif ($this->danchor == 'cronlist') {
			C::m('#duceapp_base#duceapp_cptools')->cron_create('duceapp_remostore');
			$cronlist = DB::fetch_all('SELECT * FROM %t WHERE %i ORDER BY type DESC', array('common_cron', DB::field('filename', 'duceapp_remostore:%', 'like')));
			duceapp_anchorheader('cronlist');
			duceapp_showsubtitle(array(
				'name', 'available', 'time', 'misc_cron_last_run', 'misc_cron_next_run', ''), array(
			));
			foreach($cronlist as $cron){
				$disabled = $cron['weekday'] == -1 && $cron['day'] == -1 && $cron['hour'] == -1 && $cron['minute'] == '' ? 'disabled' : '';

				if($cron['day'] > 0 && $cron['day'] < 32) {
					$cron['time'] = cplang('misc_cron_permonth').$cron['day'].cplang('misc_cron_day');
				} elseif($cron['weekday'] >= 0 && $cron['weekday'] < 7) {
					$cron['time'] = cplang('misc_cron_perweek').cplang('misc_cron_week_day_'.$cron['weekday']);
				} elseif($cron['hour'] >= 0 && $cron['hour'] < 24) {
					$cron['time'] = cplang('misc_cron_perday');
				} else {
					$cron['time'] = cplang('misc_cron_perhour');
				}

				$cron['time'] .= $cron['hour'] >= 0 && $cron['hour'] < 24 ? sprintf('%02d', $cron[hour]).cplang('misc_cron_hour') : '';

				if(!in_array($cron['minute'], array(-1, ''))) {
					foreach($cron['minute'] = explode("\t", $cron['minute']) as $k => $v) {
						$cron['minute'][$k] = sprintf('%02d', $v);
					}
					$cron['minute'] = implode(',', $cron['minute']);
					$cron['time'] .= $cron['minute'].cplang('misc_cron_minute');
				} else {
					$cron['time'] .= '00'.cplang('misc_cron_minute');
				}

				$cron['lastrun'] = $cron['lastrun'] ? dgmdate($cron['lastrun'], $_G['setting']['dateformat']."<\b\\r />".$_G['setting']['timeformat']) : '<b>N/A</b>';
				$cron['nextcolor'] = $cron['nextrun'] && $cron['nextrun'] + $_G['setting']['timeoffset'] * 3600 < TIMESTAMP ? 'style="color: #ff0000"' : '';
				$cron['nextrun'] = $cron['nextrun'] ? dgmdate($cron['nextrun'], $_G['setting']['dateformat']."<\b\\r />".$_G['setting']['timeformat']) : '<b>N/A</b>';
				$cron['run'] = $cron['available'];
				$efile = explode(':', $cron['filename']);
				if(count($efile) > 1 && !in_array($efile[0], $_G['setting']['plugins']['available'])) {
					$cron['run'] = 0;
				}
				showtablerow('', array('class="crons"', 'class="td25"', 'class="td23"', 'class="td23"', 'class="td23"', 'class="td25"'), array(
					"<input type=\"hidden\" name=\"namenew[$cron[cronid]]\" size=\"20\" value=\"$cron[name]\"><b>$cron[name]</b>",
					"<input class=\"checkbox\" type=\"checkbox\" name=\"availablenew[$cron[cronid]]\" value=\"1\" ".($cron['available'] ? 'checked' : '')." $disabled>",
					$cron[time],
					$cron[lastrun],
					$cron[nextrun],
					($cron['run'] ? " <a href=\"".ADMINSCRIPT."?action=misc&operation=cron&run=$cron[cronid]\" class=\"act\">$lang[misc_cron_run]</a>" : " <a href=\"###\" class=\"act\" disabled>$lang[misc_cron_run]</a>")
				));
			}
			showsubmit('submit');
			duceapp_anchorfooter();
		}

		showformfooter();
	}

	private function save() {
		global $_G;

		$message = '';

		if ($this->danchor == 'taskcon') {
			$runclass = $_GET['setting']['runclass'] ? $_GET['setting']['runclass'] : 'forum';
			$task = & $_G['cache']['duceapp_remostore_taskcon'][$runclass];
			if ($_GET['inajax']) {
				if (!empty($task) && $_GET['setting']['direction'] == $task['direction']) {
					$lang = $_G['cache']['pluginlanguage_script'][DUCEAPP_IDENT];
					$value = array(
						'runtime' => dgmdate($task['runtime'], 'Y-m-d H:i:s'),
						'runclass' => duceapp_cplang('setting_cldstat_'.$runclass),
						'direction' => duceapp_cplang('syndata_direction_'.(intval($task['direction']) + 2), array('server' => duceapp_cplang('menu_'.$this->setting['ossapi']))),
						'limitdate' => $task['limitdate'] ? $task['limitdate'] : cplang('unlimited'),
						'delsource' => $task['delsource'] ? cplang('yes') : cplang('no'),
						'fileext' => $task['fileext'] ? $task['fileext'] : cplang('unlimited'),
						'filesize' => $task['filesize'] > 0 ? $task['filesize'].'KB' : cplang('unlimited'),
						'totals' => intval($task['totals']) > 0 ? ' / '.intval($task['totals']) : '',
						'succeed' => intval($task['succeed']),
						'failed' => intval($task['failed']),
						'scene' => $task['scene'],
					);
					include_once template('duceapp_remostore:admin_taskmsg');
				} else {
					$outmsg = duceapp_cplang('syndata_actask_noexists');
				}
				ajaxshowheader();
				echo $outmsg;
				ajaxshowfooter();
			}			
			C::m('#duceapp_remostore#duceapp_oss', $this->setting['ossapi']);
			if (!defined('DUCEAPP_OSSON')) {
				duceapp_error('server_noexists');
			}
			if ($_GET['setting']['actask']) {
				$task = array(
					'direction' => intval($_GET['setting']['direction']),
					'limitdate' => strtotime($_GET['setting']['limitdate']) ? $_GET['setting']['limitdate'] : 0,
					'filesize' => intval($_GET['setting']['filesize']),
					'fileext' => preg_replace('/\s/', '', $_GET['setting']['fileext']),
					'ppp' => 500,
					'delsource' => intval($_GET['setting']['delsource']),
					'completed' => 0,
					'start' => 0,
					're_start' => 0,
					'marker' => 0,
					'tableid' => 0,
					'failed' => 0,
					'succeed' => 0,
					'runstatus' => 0,
					'scene' => $_GET['syndata_task'] ? 'cron' : 'admin',
				);
			} elseif(empty($task) || $task['direction'] != intval($_GET['setting']['direction'])) {
				$task = array(
					'direction' => intval($_GET['setting']['direction']),
					'ppp' => 500,
					'delsource' => 0,
					'completed' => 0,
					'start' => 0,
					're_start' => 0,
					'marker' => 0,
					'tableid' => 0,
					'failed' => 0,
					'succeed' => 0,
					'runstatus' => 0,
					'scene' => 'admin',
				);
			}
			foreach($_G['cache']['duceapp_remostore_taskcon'] as $class => $item) {
				if ($class == $runclass) {
					$_G['cache']['duceapp_remostore_taskcon']['runclass'] = $class;
					if (empty($item['runstatus'])) {
						$task['runtime'] = TIMESTAMP;
					}
				} elseif ($item['runstatus'] == 1) {
					$_G['cache']['duceapp_remostore_taskcon'][$class]['runstatus'] = 0;
				}
			}
			if (!$task['totals']) {
				switch($runclass) {
					case 'forum': 
						$task['totals'] = C::t('#duceapp_remostore#duceapp_remostore_forum_attachment')->count_all($task['direction'], $task['limitdate'], $task['fileext'], $task['filesize']) + C::t('#duceapp_remostore#duceapp_remostore_forum_thread')->count_cover($task['direction']);
						break;
					case 'sorttype': 
						$task['totals'] = C::t('#duceapp_remostore#duceapp_remostore_forum_typeoptionvar')->count_by_value($task['direction']) + C::t('#duceapp_remostore#duceapp_remostore_forum_typeoptionvar')->count_by_value();
						break;
					case 'album': 
						$task['totals'] = C::t('#duceapp_remostore#duceapp_remostore_home_pic')->count_all($task['direction']) + C::t('#duceapp_remostore#duceapp_remostore_home_pic')->count_by_alubm($task['direction'] + 1);
						break;
					case 'portal': 
						$task['totals'] = C::t('#duceapp_remostore#duceapp_remostore_portal_attachment')->count_all($task['direction']) + C::t('#duceapp_remostore#duceapp_remostore_portal_attachment')->count_article();
						break;
					case 'avatar': 
						$task['totals'] = DB::result_first('SELECT COUNT(*) FROM %t WHERE avatarstatus<>0', array('common_member'));
						break;
				}
			}
			
			savecache('duceapp_remostore_taskcon', $_G['cache']['duceapp_remostore_taskcon']);
			
			$_GET['oauth'] = authcode($runclass, 'ENCODE');

			if ($_GET['setting']['actask'] && $_GET['syndata_task']) {
				$message = 'syndata_autotask_succeed';
				$this->redirect .= '&oauth='.urlencode($_GET['oauth']);
				C::m('#duceapp_base#duceapp_cptools')->cron_create('duceapp_remostore');
				$cronid = C::t('common_cron')->get_cronid_by_filename('duceapp_remostore:cron_syndata.php');
				C::t('common_cron')->update($cronid, array('available' => 1));
			} else {
				return $this->proces();
			}
		} elseif ($this->danchor == 'cronlist') {
			if(is_array($_GET['namenew'])) {
				foreach($_GET['namenew'] as $id => $name) {
					$newcron = array('available' => $_GET['availablenew'][$id]);
					if(empty($_GET['availablenew'][$id])) {
						$newcron['nextrun'] = '0';
					}
					DB::update('common_cron', $newcron, DB::field("cronid", $id));
				}
			}
		}

		duceapp_cpmsg($message);
	}

	private function proces() {
		if (!($runclass = authcode($_GET['oauth']))) {
			return empty($_GET['inajax']) ? $this->main() : exit();
		}
		global $_G;

		$task = $_G['cache']['duceapp_remostore_taskcon'][$runclass];

		if (empty($_GET['inajax'])) {
			$lang = $_G['cache']['pluginlanguage_script'][DUCEAPP_IDENT];
			$value = $this->getTaskval($runclass);
			$redirect = str_replace('pmod=syndata', '', $this->redirect).'&inajax=1&oauth='.urlencode($_GET['oauth']);
			include_once template('duceapp_remostore:admin_taskcon');
		} elseif ($task && empty($task['runstatus'])) {
			if ($task['scene'] != 'cron') {
				C::m('#duceapp_remostore#duceapp_oss')->module('admincp_syndata');
				duceapp_remostore_ignore_abort($task['scene'], 2);
			} else {
				$cronid = C::t('common_cron')->get_cronid_by_filename('duceapp_remostore:cron_syndata.php');
				C::t('common_cron')->update($cronid, array('available' => 1));
				discuz_cron::run($cronid);
			}
		}

		!empty($_GET['inajax']) && exit;
	}
}

new duceapp_modcp;