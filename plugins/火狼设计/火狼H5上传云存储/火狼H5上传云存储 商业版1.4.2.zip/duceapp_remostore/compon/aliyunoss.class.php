<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-07-20
 * Version: 3.10715
 * Date: 2021-08-24 04:43:51
 * File: aliyunoss.class.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class duceapp_compon_aliyunoss
{
	private $serverName = 'aliyunoss';

	public function init(){
		$this->componvar = & $this->setting['server'][$this->serverName];
		duceapp_showanchors();
		call_user_func(array(__CLASS__, $this->cpmethod));
	}

	private function main() {
		global $_G;
		if ($this->danchor == 'basic') {
			duceapp_formheader('enctype');
			duceapp_anchorheader();
			duceapp_showsetting('accesskey', 'setting[accesskey]', $this->componvar['accesskey'], 'text');
			duceapp_showsetting('secretkey', 'setting[secretkey]', duceapp_cutencrypt($this->componvar['secretkey']), 'text');
			duceapp_showsetting('bucket', 'setting[bucket]', $this->componvar['bucket'], 'text');
			duceapp_showsetting('endpoint', 'setting[endpoint]', $this->componvar['endpoint'], 'text');
			//duceapp_showsetting('domain', 'setting[domain]', $this->componvar['domain'], 'text');
			duceapp_showsetting('remourl', 'setting[remourl]', $this->componvar['remourl'], 'text');
			//duceapp_showsetting('imagestyle', 'setting[imagestyle]', $this->componvar['imagestyle'], 'textarea');
			duceapp_showsetting('setting_setossapi', 'setting[setossapi]', $this->setting['ossapi'] == $this->serverName ? 1 : 0);			
			showsubmit('submit', 'submit', '', ' <input type="button" class="btn" value="'.duceapp_cplang('server_check').'" onclick="serverCheck(this)">');
			duceapp_anchorfooter();
			showformfooter();
			echo '<script type="text/javascript">
			function serverCheck(btn){
				duceapp_prompt("<span class=\"rotateLoading\"><div class=\"duceapp-ballclip\"><div class=\"duceapp-ballclip-rotate\"></div></div></span> &nbsp;'.duceapp_cplang('server_checking').'");
				btn.disabled = true;
				var form = btn.form, postdata = "";
				for (var i in form.elements) {
					if (form.elements[i].type == "text") {
						postdata += form.elements[i].name + "=" + form.elements[i].value + "&";
					}
				}
				postdata += "duceapp_submit=yes&formhash='.FORMHASH.'";
				var x = new Ajax();
				x.post("'.$this->redirect.'&check=yes&inajax=1", postdata, function(s, x) {
					btn.disabled = false;
					evalscript(s);
				});
			}
			</script>';
		} elseif ($this->danchor == 'referer') {
			list($refererList, $allowempty) = $this->componvar['bucket'] ? C::m('#duceapp_remostore#duceapp_oss', $this->serverName)->exec('getReferer') : array();
			duceapp_formheader();
			duceapp_anchorheader();
			duceapp_showsetting('referer', 'referer', $refererList ? implode("\n", $refererList) : '', 'textarea', '', 0, '', 'style="height:120px"');
			duceapp_showsetting('referer_allowempty', 'allowempty', $allowempty ? 1 : 0);
			showsubmit('submit');
			duceapp_anchorfooter();
			showformfooter();
		}
	}	

	private function save() {

		if ($this->danchor == 'basic') {
		
			$this->componvar = array(
				'accesskey' => trim($_GET['setting']['accesskey']),
				'secretkey' => duceapp_comparencrypt(trim($_GET['setting']['secretkey']), $this->componvar['secretkey']),
				'bucket' => trim($_GET['setting']['bucket']),
				'endpoint' => trim($_GET['setting']['endpoint']),
				'domain' => $this->componvar['domain'], //trim($_GET['setting']['domain']),
				'remourl' => trim($_GET['setting']['remourl']),
				'zoomrule' => 'x-oss-process=image/auto-orient,1/interlace,1/resize,m_lfit,w_{w}/quality,q_{q}',
			);

			if ($_GET['check'] && $_GET['inajax']) {
				$result = C::m('#duceapp_remostore#duceapp_oss', $this->serverName)->exec('checkRes');
				$message = ($result[0] ? '<div style="font-size:14px;line-height:28px;color:#2bbe51;">'.duceapp_cplang('server_upload_succeed').'&nbsp; <img src="source/plugin/duceapp_remostore/static/image/right.png" style="height:16px;margin-top:-2px;vertical-align:middle"></div>' : '<div style="font-size:14px;line-height:28px;color:#dd3e00;">'.duceapp_cplang('server_upload_failed').'&nbsp; <img src="source/plugin/duceapp_remostore/static/image/error.png" style="height:16px;margin-top:-2px;vertical-align:middle"></div>').($result[1] ? '<div style="font-size:14px;line-height:28px;color:#2bbe51;">'.duceapp_cplang('server_download_succeed').'&nbsp;  <img src="source/plugin/duceapp_remostore/static/image/right.png" style="height:16px;margin-top:-2px;vertical-align:middle"></div>' : '<div style="font-size:14px;line-height:28px;color:#dd3e00;">'.duceapp_cplang('server_download_failed').'&nbsp; <img src="source/plugin/duceapp_remostore/static/image/error.png" style="height:16px;margin-top:-2px;vertical-align:middle"></div></div>').($result[2] ? '<div style="font-size:14px;line-height:28px;color:#2bbe51;">'.duceapp_cplang('server_remourl_succeed').'&nbsp;  <img src="source/plugin/duceapp_remostore/static/image/right.png" style="height:16px;margin-top:-2px;vertical-align:middle"></div>' : '<div style="font-size:14px;line-height:28px;color:#dd3e00;">'.duceapp_cplang('server_remourl_failed').'&nbsp; <img src="source/plugin/duceapp_remostore/static/image/error.png" style="height:16px;margin-top:-2px;vertical-align:middle"></div></div>');
				ajaxshowheader();
				echo '<script type="text/javascript" reload="1">
				duceapp_prompt("'.addslashes($message).'", {w:450});
				</script>';
				ajaxshowfooter();
			}

			if ($this->componvar['bucket']) {
				if (!preg_match('/^[a-z0-9\-]+$/', $this->componvar['bucket']) || preg_match('/^\-|\-$/', $this->componvar['bucket'])) {
					duceapp_error('bucket_invalid');
				}

				$default = '';
				$select = '<br />'.duceapp_cplang('endpoint_region').'<select name="setting[endpoint]" onchange="$(\'endpoint\').innerHTML=this.value" style="min-width:200px;">';
				foreach(array('cn-hangzhou', 'cn-shanghai', 'cn-qingdao', 'cn-beijing', 'cn-zhangjiakou', 'cn-huhehaote', 'cn-wulanchabu', 'cn-shenzhen', 'cn-heyuan', 'cn-guangzhou', 'cn-chengdu', 'cn-hongkong', 'ap-southeast-1', 'ap-southeast-2', 'ap-southeast-3', 'ap-southeast-5', 'ap-northeast-1', 'ap-south-1', 'eu-central-1', 'eu-west-1', 'us-west-1', 'us-east-1', 'me-east-1') as $key) {
					$val = 'oss-'.$key.'.aliyuncs.com';
					if (!$default || $val == $this->componvar['endpoint']) {
						$default = $val;
					}
					$select .= '<option value="'.$val.'"'.($val == $this->componvar['endpoint'] ? ' selected' : '').'>'.duceapp_cplang('endpoint_'.$key).'</option>';
				}
				$select .= '</select><br /><br />Endpoint: <strong id="endpoint">'.$default.'</strong><br />';

				$this->componvar = C::m('#duceapp_remostore#duceapp_oss', $this->serverName)->bucketCheck($this->componvar, $this->redirect, $select, $this);

				if (empty($this->componvar['remourl'])) {
					$this->componvar['remourl'] = 'https://'.$this->componvar['domain'];
				} elseif(!preg_match('/^http(s)?:\/\//', $this->componvar['remourl'])) {
					$this->componvar['remourl'] = 'https://'.$this->componvar['remourl'];
				}
				$this->componvar['remourl'] = preg_replace('/\/+$/', '', $this->componvar['remourl']).'/';

				if ($this->setting['ossapi'] == $this->serverName) {
					$this->setting['attachurl'] = $this->componvar['remourl'].$this->setting['basedir'];
				}

				C::m('#duceapp_remostore#duceapp_oss', $this->serverName)->exec('setCors');

				if (intval($_GET['setting']['setossapi'])) {
					$this->setting['ossapi'] = $this->serverName;
				}
			}

			duceapp_succeed();

		} elseif ($this->danchor == 'referer') {

			if ($this->componvar['bucket']) {
				C::m('#duceapp_remostore#duceapp_oss', $this->serverName)->exec('setReferer', trim($_GET['referer']), intval($_GET['allowempty']));
			}
			duceapp_cpmsg();

		}

		
	}

	public function domain($config, $endpoint = null) {
		if ($endpoint) {
			$config['endpoint'] = $endpoint;
		}
		if (empty($config['domain']) || strpos($config['domain'], $config['endpoint']) === false) {
			$config['domain'] = $config['bucket'].'.'.$config['endpoint'];
		}
		if (strpos($config['remourl'], '.aliyuncs.com') !== false) {
			$config['remourl'] = 'https://'.$config['domain'];
		}
		return $config;
	}

	public function created($config) {
		$config['domain'] = $config['bucket'].'.'.$config['endpoint'];
		$config['remourl'] = 'https://'.$config['domain'];
		return $config;
	}
}