<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-07-20
 * Version: 3.10715
 * Date: 2021-08-24 04:43:51
 * File: tencentcos.class.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class duceapp_compon_tencentcos
{
	private $serverName = 'tencentcos';

	public function init(){
		$this->componvar = & $this->setting['server'][$this->serverName];
		duceapp_showanchors();
		call_user_func(array(__CLASS__, $this->cpmethod));
	}

	private function main() {
		global $_G;
		duceapp_formheader('enctype');
		duceapp_anchorheader();
		duceapp_showsetting('secretid', 'setting[secretid]', $this->componvar['secretid'], 'text');
		duceapp_showsetting('secretkey', 'setting[secretkey]', duceapp_cutencrypt($this->componvar['secretkey']), 'text');
		duceapp_showsetting('bucket', 'setting[bucket]', $this->componvar['bucket'], 'text');
		duceapp_showsetting('region', 'setting[region]', $this->componvar['region'], 'text');
		//duceapp_showsetting('domain', 'setting[domain]', $this->componvar['domain'], 'text');
		duceapp_showsetting('remourl', 'setting[remourl]', $this->componvar['remourl'], 'text');
		duceapp_showsetting('setting_setossapi', 'setting[setossapi]', $this->setting['ossapi'] == $this->serverName ? 1 : 0);
		showsubmit('submit', 'submit', '', ' <input type="button" class="btn" value="'.duceapp_cplang('server_check').'" onclick="serverCheck(this)">');
		duceapp_anchorfooter();
		showformfooter();
		echo '<script type="text/javascript">
		function serverCheck(btn){
			duceapp_prompt("<span class=\"rotateLoading\"><div class=\"duceapp-ballclip\"><div class=\"duceapp-ballclip-rotate\"></div></div></span> &nbsp;'.duceapp_cplang('server_checking').'");
			btn.disabled = true;
			var form = btn.form, postdata = "";
			for (var i in form.elements) {
				if (form.elements[i].type == "text") {
					postdata += form.elements[i].name + "=" + form.elements[i].value + "&";
				}
			}
			postdata += "duceapp_submit=yes&formhash='.FORMHASH.'";
			var x = new Ajax();
			x.post("'.$this->redirect.'&check=yes&inajax=1", postdata, function(s, x) {
				btn.disabled = false;
				evalscript(s);
			});
		}
		</script>';
	}	

	private function save() {
		
		$this->componvar = array(
			'appid' => $this->componvar['appid'],
			'secretid' => trim($_GET['setting']['secretid']),
			'secretkey' => duceapp_comparencrypt(trim($_GET['setting']['secretkey']), $this->componvar['secretkey']),
			'bucket' => trim($_GET['setting']['bucket']),
			'region' => trim($_GET['setting']['region']),
			'endpoint' => 'cos.'.trim($_GET['setting']['region']).'.myqcloud.com',
			'domain' => $this->componvar['domain'], //trim($_GET['setting']['domain']),
			'remourl' => trim($_GET['setting']['remourl']),
			'zoomrule' => 'imageMogr2/thumbnail/{w}x/interlace/1',
		);

		if ($_GET['check'] && $_GET['inajax']) {
			$result = C::m('#duceapp_remostore#duceapp_oss', $this->serverName)->exec('checkRes');
			$message = ($result[0] ? '<div style="font-size:14px;line-height:28px;color:#2bbe51;">'.duceapp_cplang('server_upload_succeed').'&nbsp; <img src="source/plugin/duceapp_remostore/static/image/right.png" style="height:16px;margin-top:-2px;vertical-align:middle"></div>' : '<div style="font-size:14px;line-height:28px;color:#dd3e00;">'.duceapp_cplang('server_upload_failed').'&nbsp; <img src="source/plugin/duceapp_remostore/static/image/error.png" style="height:16px;margin-top:-2px;vertical-align:middle"></div>').($result[1] ? '<div style="font-size:14px;line-height:28px;color:#2bbe51;">'.duceapp_cplang('server_download_succeed').'&nbsp;  <img src="source/plugin/duceapp_remostore/static/image/right.png" style="height:16px;margin-top:-2px;vertical-align:middle"></div>' : '<div style="font-size:14px;line-height:28px;color:#dd3e00;">'.duceapp_cplang('server_download_failed').'&nbsp; <img src="source/plugin/duceapp_remostore/static/image/error.png" style="height:16px;margin-top:-2px;vertical-align:middle"></div></div>').($result[2] ? '<div style="font-size:14px;line-height:28px;color:#2bbe51;">'.duceapp_cplang('server_remourl_succeed').'&nbsp;  <img src="source/plugin/duceapp_remostore/static/image/right.png" style="height:16px;margin-top:-2px;vertical-align:middle"></div>' : '<div style="font-size:14px;line-height:28px;color:#dd3e00;">'.duceapp_cplang('server_remourl_failed').'&nbsp; <img src="source/plugin/duceapp_remostore/static/image/error.png" style="height:16px;margin-top:-2px;vertical-align:middle"></div></div>');
			ajaxshowheader();
			echo '<script type="text/javascript" reload="1">
			duceapp_prompt("'.addslashes($message).'", {w:450});
			</script>';
			ajaxshowfooter();
		}

		if ($this->componvar['bucket']) {
			if (!preg_match('/^[a-z0-9\-]+$/', $this->componvar['bucket']) || preg_match('/^\-|\-$/', $this->componvar['bucket'])) {
				duceapp_error('bucket_invalid');
			}
			$isCreate = $_GET['confirm'] ? authcode($_GET['confirm'], 'DECODE') == $this->componvar['bucket'] : false;
			$appid = preg_replace('/[^0-9]/', '', $_GET['setting']['newappid']);
			if ($isCreate && $appid && !preg_match('/\-'.$appid.'$/', $this->componvar['bucket'])) {
				$this->componvar['bucket'] = str_replace($this->componvar['appid'], '', $this->componvar['bucket']).'-'.$appid;
				$_GET['confirm'] = authcode($this->componvar['bucket'], 'ENCODE', '', 180);
			}
			$default = '';
			$select = '<br />'.duceapp_cplang('region_0').'<select name="setting[region]" onchange="$(\'region\').innerHTML=this.value" style="min-width:200px;">';
			foreach(array('ap-nanjing', 'ap-chengdu', 'ap-beijing', 'ap-guangzhou', 'ap-shanghai', 'ap-chongqing', 'ap-beijing-fsi', 'ap-shanghai-fsi', 'ap-shenzhen-fsi', 'ap-hongkong', 'ap-singapore', 'ap-mumbai', 'ap-seoul', 'ap-bangkok', 'ap-tokyo', 'eu-moscow', 'eu-frankfurt', 'na-toronto', 'na-ashburn', 'na-siliconvalley') as $key) {
				if (!$default || $key == $this->componvar['region']) {
					$default = $key;
				}
				if ($key == 'ap-nanjing') {
					$select .= '<optgroup label="'.duceapp_cplang('region_1').'">';
				} elseif ($key == 'ap-singapore') {
					$select .= '</optgroup><optgroup label="'.duceapp_cplang('region_2').'">';
				} elseif ($key == 'eu-moscow') {
					$select .= '</optgroup><optgroup label="'.duceapp_cplang('region_3').'">';
				} elseif ($key == 'na-toronto') {
					$select .= '</optgroup><optgroup label="'.duceapp_cplang('region_4').'">';
				}
				$select .= '<option value="'.$key.'"'.($key == $this->componvar['region'] ? ' selected' : '').'>'.duceapp_cplang('region_'.$key).'</option>';
			}			
			$select .= '</optgroup></select><br /><br />'.duceapp_cplang('appid').': <input type="text" name="setting[newappid]" value="'.$this->componvar['appid'].'" class="txt" style="width:130px;"> '.duceapp_cplang('appid_comment').'<br /><br />Region: <strong id="region">'.$default.'</strong><br />';

			$this->componvar = C::m('#duceapp_remostore#duceapp_oss', $this->serverName)->bucketCheck($this->componvar, $this->redirect, $select, $this);

			if (empty($this->componvar['remourl'])) {
				$this->componvar['remourl'] = 'https://'.$this->componvar['domain'];
			} elseif(!preg_match('/^http(s)?:\/\//', $this->componvar['remourl'])) {
				$this->componvar['remourl'] = 'https://'.$this->componvar['remourl'];
			}
			$this->componvar['remourl'] = preg_replace('/\/+$/', '', $this->componvar['remourl']).'/';

			if ($this->setting['ossapi'] == $this->serverName) {
				$this->setting['attachurl'] = $this->componvar['remourl'].$this->setting['basedir'];
			}
			$this->componvar['appid'] = substr($this->componvar['bucket'], strrpos($this->componvar['bucket'], '-') + 1);

			C::m('#duceapp_remostore#duceapp_oss', $this->serverName)->exec('setCors');

			if (intval($_GET['setting']['setossapi'])) {
				$this->setting['ossapi'] = $this->serverName;
			}
		}

		duceapp_succeed();
	}

	public function domain($config, $bucket = null) {
		if (empty($config['domain']) || strpos($config['domain'], $config['bucket'].'.') === false) {
			$config['domain'] = $config['bucket'].'.'.$config['endpoint'];
		}
		if (strpos($config['remourl'], '.myqcloud.com') !== false) {
			$config['remourl'] = 'https://'.$config['domain'];
		}
		return $config;
	}

	public function created($config) {
		$config['domain'] = $config['bucket'].'.'.$config['endpoint'];
		$config['remourl'] = 'https://'.$config['domain'];
		return $config;
	}
}