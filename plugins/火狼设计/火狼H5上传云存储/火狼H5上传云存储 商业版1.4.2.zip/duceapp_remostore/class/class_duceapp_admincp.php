<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-05
 * Version: 3.10906
 * Date: 2021-09-13 11:55:24
 * File: class_duceapp_admincp.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include_once libfile('check', 'plugin/duceapp_remostore');
include_once libfile('class/duceapp_adminbase', 'plugin/'.DUCEAPP_SINGLE);

class duceapp_admincp extends duceapp_adminbase
{
	public $setting_keys = array('ossapi', 'server', 'basedir', 'attachurl', 'copyinfo', 'expires', 'publicext', 'cldstat', 'debug', 'sourcewidth', 'sourceheight', 'thumbquality', 'compresspng', 'chunkgid', 'directoss', 'watermark', 'chklimit', 'fileslimit', 'limitfids', 'excludegid', 'forceimage', 'forceimagefids', 'insertimage', 'insertallimage', 'mobile', 'remotolocal', 'unfithost', 'exclhost', 'remolocgids', 'ossimgstyle', 'ossexclfids', 'ossmaxsize', 'chunksize');
	public $dropanchor = array(
		'setting' => array('basic', 'upload', 'watermark', 'remoloc', 'mobile'),
		'syndata' => array('taskcon', 'cronlist'),
	);

	public function header() {
		global $_G;
		$this->init();
		$this->duceapp();
		include_once libfile('function/duceapp_core', 'plugin/duceapp_remostore');
		if ($_GET['pmod'] == 'setting' && $_GET['oauth']) {
			$runclass = authcode($_GET['oauth']);
			$values = $this->getTaskval($runclass);
			if (strtolower(CHARSET) != 'utf-8') {
			    $values = eval('return '.diconv(var_export($values, true).';', CHARSET, 'utf-8'));
		    }
			ajaxshowheader();
			echo json_encode($values);
			ajaxshowfooter();
		}
	}

	public function savesetting($setting, $multisel = false) {
		foreach($this->setting_keys as $key) {
			if ($multisel && in_array($key, array('forceimagefids', 'chunkgid', 'directoss', 'watermark', 'limitfids', 'excludegid', 'mobile', 'remolocgids', 'ossexclfids'))) {
				$setting[$key] = (array) $setting[$key];
			}
			if (is_array($setting[$key])) {
				$this->setting[$key] = array();
				foreach($setting[$key] as $k => $v) {
					$this->setting[$key][$k] = is_array($v) ? $v : trim($v);
				}
			} elseif(isset($setting[$key])) {
				$this->setting[$key] = is_array($setting[$key]) ? $setting[$key] : trim($setting[$key]);
			}
		}
	}

	public function getTaskval($class) {
		global $_G;
		if (!isset($_G['cache']['duceapp_remostore_taskcon'])) {
			loadcache('duceapp_remostore_taskcon');
		}
		if (!$class) {
			return;
		}
		$task = $_G['cache']['duceapp_remostore_taskcon'][$class];
		$succeed = intval($task['succeed']);
		$failed = intval($task['failed']);
		$values = array(
			'percent' => $task['totals'] > 0 ? number_format(($succeed + $failed)*100/$task['totals'], 1, '.', '') - 0 : 100,
			'runtime' => dgmdate($task['runtime'], 'Y-m-d H:i:s'),
			'runclass' => duceapp_cplang('setting_cldstat_'.$class),
			'direction' => duceapp_cplang('syndata_direction_'.(intval($task['direction']) + 2), array('server' => duceapp_cplang('menu_'.$this->setting['ossapi']))),
			'limitdate' => $task['limitdate'] ? $task['limitdate'] : cplang('unlimited'),
			'delsource' => $task['delsource'] ? cplang('yes') : cplang('no'),
			'fileext' => $task['fileext'] ? $task['fileext'] : cplang('unlimited'),
			'filesize' => $task['filesize'] > 0 ? $task['filesize'].'KB' : cplang('unlimited'),
			'totals' => intval($task['totals']) > 0 ? ' / '.intval($task['totals']) : '',
			'succeed' => intval($task['succeed']),
			'failed' => intval($task['failed']),
			'procesfile' => str_replace('/./', '/', $task['procesfile']),
			'runstatus' => intval($task['runstatus']),
			'lastruntime' => dgmdate(intval($task['lastruntime']) ? $task['lastruntime'] : $task['runtime'], 'Y-m-d H:i:s'),
			'scene' => $task['scene'],
		);
		return $values;
	}

	public function groupselect($varname, $value = null, $mult = 1, $extra = '') {
		$groupselect = array();
		$value = $value && is_array($value) ? array_diff($value, array('', 0)) : array();
		$res = DB::fetch_all("SELECT * FROM %t WHERE %i ORDER BY creditshigher, groupid", array('common_usergroup', DB::field('groupid', array('4','5','6','7','8','9','20'), 'notin'), 'groupid'));
		foreach($res as $groupid => $group){
			$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
			$groupselect[$group['type']] .= "<option value=\"$group[groupid]\" ".(@in_array($group['groupid'], $value) ? 'selected' : '').">$group[grouptitle]</option>\n";
		}
		return '<select '.($mult ? 'multiple="multiple"' : '').' name="'.$varname.'" size="8" '.$extra.'>
		<option value=""'.(empty($value) ? ' selected' : '').'>'.cplang('none').'</optoin>
		<optgroup label="'.cplang('usergroups_member').'">'.$groupselect['member'].'</optgroup>'.
		($groupselect['special'] ? '<optgroup label="'.cplang('usergroups_special').'">'.$groupselect['special'].'</optgroup>' : '').
		($groupselect['specialadmin'] ? '<optgroup label="'.cplang('usergroups_specialadmin').'">'.$groupselect['specialadmin'].'</optgroup>' : '').
		'<optgroup label="'.cplang('usergroups_system').'">'.$groupselect['system'].'</optgroup></select>';
	}
}