<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-24
 * Version: 3.10907
 * Date: 2021-09-13 11:55:24
 * File: class_duceapp_uploadoss.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class duceapp_uploadoss
{
    public $uid;
    public $aid;
    public $error_sizelimit;
    public $attach;
    public $object;
    public $simple;

    public function __construct($attach) {
        global $_G;

		$this->aid = 0;
        $this->error_sizelimit = 0;
        $this->attach = &$attach;
        $this->uid = $uid = $_G['uid'];
		$this->simple = $attach['simple'] = dintval($_GET['simple']);

		$swfhash = md5(substr(md5($_G['config']['security']['authkey']), 8).$uid);
		$filename = daddslashes($_GET['filename']);
		$object = daddslashes($_GET['object']);
		$attach['type'] = $_GET['attachtype'];
		$attach['simple'] && ($filename = diconv(urldecode($filename), 'UTF-8'));
        
		if (empty($uid) || $_GET['hash'] != $swfhash || empty($filename) || empty($object) || !in_array($attach['type'], array('image', 'attach'))) {
            return $this->uploadmsg(10);
        }

		$attach['filename'] = $filename;
		$attach['attachment'] = str_replace('forum/', '', $attach['object']);
        $this->object = $attach['object'];

		if (empty($attach['size'])) {
			return $this->uploadmsg(2);
        }

		if($_G['group']['maxattachsize'] && $attach['size'] > $_G['group']['maxattachsize']) {
            $this->error_sizelimit = $_G['group']['maxattachsize'];
            return $this->uploadmsg(3);
        }
        
		if ($attach['size'] && $_G['group']['maxsizeperday']) {
			$todaysize = getuserprofile('todayattachsize') + $attach['size'];
			if ($todaysize >= $_G['group']['maxsizeperday']) {
				$this->error_sizelimit = 'perday|'.$_G['group']['maxsizeperday'];
				return $this->uploadmsg(11);
			}
		}
        updatemembercount($uid, array('todayattachs' => 1, 'todayattachsize' => $attach['size']));

		if (!empty($attach['width'])) {
			C::m('#duceapp_remostore#duceapp_oss')->exec('setAcl', $this->object, 'public');
			$attach['isimage'] = 1;
        }
		if ($attach['type'] != 'image' && $attach['width'] > 0) {
			$attach['isimage'] = -1;
		}

		$thumb = 0;
		$remote = 1;
		$width = $attach['width'];
		$tmpfilename  = '';
		$havewater = false;
		$exif = null;
		$directoss = $_G['cache']['duceapp_remostore']['directoss'];
		$watermark = $_G['cache']['duceapp_remostore']['watermark']['forum'];
		$watermark['image'] = empty($watermark['fid']) || @in_array($_GET['fid'], $watermark['fid']) ? $watermark['image'] : 0;

		if ($attach['isimage'] && ($watermark['image'] || $directoss['thumb'] || $_G['setting']['showexif'])) {
			if ($watermark['image'] && !duceapp_remostore_watermark('forum') && function_exists('duceapp_template_watermark')) {
				duceapp_template_watermark('forum');
			}
			if ($_G['setting']['thumbsource'] || $_G['setting']['thumbstatus'] || $watermark['image'] || $_G['setting']['showexif']) {
				require_once libfile('class/duceapp_image', 'plugin/duceapp_remostore');
				$image = new duceapp_image;
				$tmpfilename = $_G['setting']['attachdir'].'temp/'.random(16).substr(strrchr($attach['attachment'], '.'), 0);
				C::m('#duceapp_remostore#duceapp_oss')->exec('downFile', $tmpfilename, $attach['object']);
			}
			if ($tmpfilename && file_exists($tmpfilename)) {
				if ($directoss['thumb'] && $_G['setting']['thumbsource'] && $_G['setting']['sourcewidth'] && $_G['setting']['sourceheight']) {
					$thumbsource = $image->Thumb($tmpfilename, '', $_G['setting']['sourcewidth'], $_G['setting']['sourceheight'], 1, 1) ? 1 : 0;
				}
				if ($directoss['thumb'] && $_G['setting']['thumbstatus']) {
					$thumb = $image->Thumb($tmpfilename, '', $_G['setting']['thumbwidth'], $_G['setting']['thumbheight'], $_G['setting']['thumbstatus'], 0) ? 1 : 0;
					if ($thumb) {
						if ($watermark['image'] == 1) {
							$image->Watermark($tmpfilename.'.thumb.jpg', '', 'forum');
						}
						C::m('#duceapp_remostore#duceapp_oss')->exec('uploadFile', $tmpfilename.'.thumb.jpg', $attach['object'].'.thumb.jpg', 'public');
					}
				}
				if ($watermark['image'] == 2) {
					$image->Watermark($tmpfilename, '', 'forum');
				}
				if ($_G['setting']['showexif']) {
					require_once libfile('function/attachment');
					$exif = getattachexif(0, $tmpfilename);
				}
				if ($thumbsource || $watermark['image'] == 2) {
					$width = $image->imginfo['width'];
					$attach['size'] = $image->imginfo['size'];
					C::m('#duceapp_remostore#duceapp_oss')->exec('uploadFile', $tmpfilename, $attach['object'], 'public');
				}				
			}
		}

		$this->aid = $aid = getattachnewaid($this->uid);
		$insert = array(
			'aid' => $aid,
			'dateline' => $_G['timestamp'],
			'filename' => dhtmlspecialchars(censor($attach['filename'])),
			'filesize' => $attach['size'],
			'attachment' => $attach['attachment'],
			'isimage' => $attach['isimage'],
			'uid' => $this->uid,
			'thumb' => $thumb,
			'remote' => $remote,
			'width' => $width,
		);
		C::t('forum_attachment_unused')->insert($insert);

		$ext = strtolower(substr(strrchr($attach['filename'], '.'), 1));
		$publicext = C::m('#duceapp_remostore#duceapp_oss')->getConfig('publicext');
		C::m('#duceapp_remostore#duceapp_oss')->exec('setAcl', $attach['object'], @in_array($ext, $publicext) ? 'public' : 'private');

		if (file_exists($tmpfilename)) {
			@unlink($tmpfilename);
			@unlink($tmpfilename.'.thumb.jpg');
		}

		if ($exif) {
			C::t('forum_attachment_exif')->insert($aid, $exif);
		}
		
		return $this->uploadmsg(0);
	}
	
	public function uploadmsg($statusid) {
		global $_G;
		
		$this->error_sizelimit = !empty($this->error_sizelimit) ? $this->error_sizelimit : 0;
        
		if (!$this->aid && !empty($this->object)) {
			C::m('#duceapp_remostore#duceapp_oss')->exec('deleteFile', $this->object);
        }

		if ($this->simple == 1) {
            echo 'DISCUZUPLOAD|'.$statusid.'|'.$this->aid.'|'.$this->attach['isimage'].'|'.$this->error_sizelimit;
		} elseif($this->simple == 2) {
			echo 'DISCUZUPLOAD|'.($this->attach['type'] == 'image' ? '1' : '0').'|'.$statusid.'|'.$this->aid.'|'.$this->attach['isimage'].'|'.($this->attach['isimage'] ? str_replace('forum/', '', $this->attach['object']) : '').'|'.dhtmlspecialchars(censor($this->attach['filename'])).'|'.$this->error_sizelimit;
		} else {
			echo $statusid ? -$statusid : $this->aid;
        }
		exit;
    }
}