<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-23
 * Version: 3.10623
 * Date: 2021-09-13 11:55:24
 * File: chunkupload.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if ($_G['group']['radminid'] != 1 && @!in_array($_G['groupid'], $_G['cache']['duceapp_remostore']['chunkgid'])) {
	exit('10');
}

$guid = $_GET['guid'];
$op = $_GET['op'] == 'delete' ? 'delete' : 'upload';

$targetDir = $_G['setting']['attachdir'].'./temp/';

if ($op == 'upload') {
	
	if (empty($_GET['simple'])) {
		$_FILES['file']['name'] = diconv(urldecode($_FILES['file']['name']), 'UTF-8');
		$_FILES['file']['type'] = $_GET['filetype'];
	}
	$upload = new discuz_upload();
	$upload->init($_FILES['file'], 'forum');
	$attach = $upload->attach;
	
	$cleanupTargetDir = true;
	$maxFileAge = 5 * 3600;
	$chunk = isset($_GET["chunk"]) ? intval($_GET["chunk"]) : 0;
	$chunks = isset($_GET["chunks"]) ? intval($_GET["chunks"]) : 1;

	$uploadDir = $_G['setting']['attachdir'].'./forum/'.$attach['attachdir'];
	
	dmkdir($uploadDir, 0777, false);
	dmkdir($targetDir, 0777, false);
	
	if (!is_dir($targetDir) || !($dir = opendir($targetDir))) {
		exit('8');
	}

	$filePath = $targetDir . $guid;
	$part = $filePath.'_'.$chunk.'.part';
	$parttmp = $filePath.'_'.$chunk.'.parttmp';

	while(($file = readdir($dir)) !== false) {
		$tmpfilePath = $targetDir . $file;
		if ($tmpfilePath == $part || $tmpfilePath == $parttmp) {
			continue;
		}
		if (preg_match('/\.(part|parttmp)$/', $file) && (@filemtime($tmpfilePath) < time() - $maxFileAge)) {
			@unlink($tmpfilePath);
		}
	}
	closedir($dir);

	if (!($tmp = @fopen($parttmp, 'wb'))) {
		exit('8');
    }

	if (!empty($_FILES)) {
		if ($_FILES['file']["error"] || !is_uploaded_file($_FILES['file']['tmp_name'])) {
			exit('9');
		}
		if (!$input = @fopen($_FILES['file']['tmp_name'], 'rb')) {
			exit('9');
		}
	} else {
		if (!$input = @fopen('php://input', 'rb')) {
			exit('9');
		}
	}
	while ($buff = fread($input, 4096)) {
		fwrite($tmp, $buff);
	}
	@fclose($tmp);
	@fclose($input);
	
	@rename($parttmp, $part);

	$index = 0;
    $done = true;
	for($index = 0; $index < $chunks; $index++) {
		if (!file_exists($filePath.'_'.$index.'.part')){
			$done = false;
			break;
		}
	}
	if ($done) {
		$uploadPath = $attach['target'];
		if (!$fp = @fopen($uploadPath, 'wb')) {
            exit('8');
        }
		if (flock($fp, LOCK_EX)) {
            for($index = 0; $index < $chunks; $index++) {
                if (!$input = @fopen($filePath.'_'.$index.'.part', 'rb')) {
                    break;
                }
                while ($buff = fread($input, 4096)) {
                    fwrite($fp, $buff);
                }
                @fclose($input);
                @unlink($filePath.'_'.$index.'.part');
            }
            flock($fp, LOCK_UN);
        }
        @fclose($fp);

		require_once libfile('class/duceapp_toattach', 'plugin/duceapp_remostore');

		$attachextensions = '';
        $fid = intval($_GET['fid']);
        if ($fid) {
            $forum = $fid != $_G['fid'] ? C::t('forum_forum')->fetch_info_by_fid($fid) : $_G['forum'];
            if ($forum['status'] == 3 && $forum['level']) {
                $levelinfo = C::t('forum_grouplevel')->fetch($forum['level']);
                if ($postpolicy = $levelinfo['postpolicy']) {
                    $postpolicy = dunserialize($postpolicy);
                    $attachextensions = $postpolicy['attachextensions'];
                }
            } else {
                $attachextensions = $forum['attachextensions'];
            }
            if ($attachextensions) {
                $_G['group']['attachextensions'] = $attachextensions;
            }
        }
		
		new duceapp_toattach($attach);
	}

} elseif ($op == 'delete') {

	if (!empty($guid) && is_dir($targetDir) && ($dir = opendir($targetDir))) {
		while(($file = readdir($dir)) !== false) {
			$tmpfilePath = $targetDir.$file;
			if (strpos($file, $guid) !== false) {
				@unlink($tmpfilePath);
			}
		}
		closedir($dir);
	}
}