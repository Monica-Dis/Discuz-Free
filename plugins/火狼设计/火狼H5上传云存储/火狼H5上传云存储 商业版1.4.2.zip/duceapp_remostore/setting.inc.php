<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-05
 * Version: 3.10907
 * Date: 2021-09-13 11:55:28
 * File: setting.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once libfile('class/duceapp_admincp', 'plugin/duceapp_remostore');

class duceapp_modcp extends duceapp_admincp
{
	public function __construct() {
		global $_G;
		$this->header();

		$this->cldstat = array(
			duceapp_cplang('setting_cldstat_image'),
			duceapp_cplang('setting_cldstat_attach'),
			duceapp_cplang('setting_cldstat_sorttype'),
			duceapp_cplang('setting_cldstat_trade'),
			duceapp_cplang('setting_cldstat_avatar'),
		);

		duceapp_showanchors();
		call_user_func(array(__CLASS__, $this->cpmethod));

		$this->footer();
	}

	private function main() {
		global $_G;

		duceapp_formheader('enctype');
		$servers = array(array('', cplang('none')));
		if ($this->setting['server']) {
			foreach($this->setting['server'] as $key => $config) {
				$servers[] = array($key, duceapp_cplang('menu_'.$key));
			}
		}
		duceapp_anchorheader('basic');
		duceapp_showsetting('setting_ossapi', array('setting[ossapi]', $servers), $this->setting['ossapi'], 'select');
		duceapp_showsetting('setting_basedir', 'setting[basedir]', $this->setting['basedir'], 'text');
		duceapp_showsetting('setting_cldstat', array('setting[cldstat]', $this->cldstat), $this->setting['cldstat'], 'binmcheckbox');
		duceapp_showsetting('setting_ossmaxsize', 'setting[ossmaxsize]', $this->setting['ossmaxsize'], 'text');
		duceapp_showsetting('setting_copyinfo', 'setting[copyinfo]', $this->setting['copyinfo'], 'text');
		duceapp_showsetting('setting_expires', 'setting[expires]', $this->setting['expires'], 'text');
		duceapp_showsetting('setting_publicext', 'setting[publicext]', isset($this->setting['publicext']) ? $this->setting['publicext'] : 'flv,mp3,mp4', 'text');
		duceapp_showsetting('setting_debug', 'setting[debug]', $this->setting['debug']);
		showsubmit('duceapp_submit');
		duceapp_anchorfooter();

		duceapp_showtagheader('div', 'upload');
		$tabs = array('upload_basic', 'upload_bigattach', 'upload_directoss');
		$subtab = $_GET['subtab'] ? $_GET['subtab'] : $tabs[0];
		duceapp_anchortabs('upload', $tabs, $subtab, 'subtab');
		duceapp_anchorheader('subtab_upload_basic', 'upload_basic' == $subtab);
		duceapp_showsetting('setting_imagesource', array('setting[sourcewidth]', 'setting[sourceheight]'), array(intval($this->setting['sourcewidth']), intval($this->setting['sourceheight'])), 'multiply');
		duceapp_showsetting('setting_thumbquality', 'setting[thumbquality]', $this->setting['thumbquality'], 'text');
		duceapp_showsetting('setting_compresspng', 'setting[compresspng]', intval($this->setting['compresspng']));
		duceapp_showsetting('setting_insertallimage', 'setting[insertallimage]', intval($this->setting['insertallimage']));
		duceapp_showsetting('setting_forceimage', 'setting[forceimage]', intval($this->setting['forceimage']), 'radio', '', 1);
		duceapp_showsetting('setting_insertimage', 'setting[insertimage]', intval($this->setting['insertimage']));
		duceapp_showsetting('setting_forceimagefids', '', '', '<select name="setting[forceimagefids][]" multiple="multiple" size="8" style="margin-bottom:5px;"><option value=""'.(empty($this->setting['forceimagefids']) ? ' selected' : '').'>'.cplang('none').'</option><option value="-1"'.($this->setting['forceimagefids'] == -1 ? ' selected' : '').'>'.duceapp_cplang('setting_allforum').'</option>'.duceapp_forumselect((array)$this->setting['forceimagefids']).'</select>');
		showtagfooter('tbody');
		duceapp_showsetting('setting_chklimit', 'setting[chklimit]', $this->setting['chklimit'], 'radio', '', 1);
		duceapp_showsetting('setting_fileslimit', 'setting[fileslimit]', $this->setting['fileslimit'], 'text');
		duceapp_showsetting('setting_limitfids', '', '', '<select name="setting[limitfids][]" multiple="multiple" size="8" style="margin-bottom:5px;"><option value=""'.(empty($this->setting['limitfids']) ? ' selected' : '').'>'.cplang('none').'</option><option value="-1"'.($this->setting['limitfids'] == -1 ? ' selected' : '').'>'.duceapp_cplang('setting_allforum').'</option>'.duceapp_forumselect((array)$this->setting['limitfids']).'</select>');
		duceapp_showsetting('setting_excludegid', '', '', $this->groupselect('setting[excludegid][]', $this->setting['excludegid'], 1, 'style="margin-bottom:5px;"'));
		showtagfooter('tbody');
		showsubmit('duceapp_submit');
		duceapp_anchorfooter();
		duceapp_anchorheader('subtab_upload_bigattach', 'upload_bigattach' == $subtab);
		duceapp_showsetting('setting_chunkgid', '', '', $this->groupselect('setting[chunkgid][]', $this->setting['chunkgid'], 1, 'style="margin-bottom:5px;"'));
		duceapp_showsetting('upload_chunksize', 'setting[chunksize]', $this->setting['chunksize'], 'text');
		showsubmit('duceapp_submit');
		duceapp_anchorfooter();
		$directoss = $this->setting['directoss'];
		duceapp_anchortips('setting_directoss_tips', 'subtab_upload_directoss', 'upload_directoss' == $subtab);
		duceapp_anchorheader('subtab_upload_directoss', 'upload_directoss' == $subtab);
		duceapp_showsetting('setting_imgdirect', 'setting[directoss][image]', intval($directoss['image']));
		duceapp_showsetting('setting_attadirect', 'setting[directoss][attach]', intval($directoss['attach']));
		duceapp_showsetting('setting_makethumb', 'setting[directoss][thumb]', intval($directoss['thumb']));		
		duceapp_showsetting('setting_exclfids', '', '', '<select name="setting[directoss][exclfids][]" multiple="multiple" size="8" style="margin-bottom:5px;"><option value=""'.(empty($directoss['exclfids']) ? ' selected' : '').'>'.cplang('none').'</option>'.duceapp_forumselect((array)$directoss['exclfids']).'</select>');
		showsubmit('duceapp_submit');
		duceapp_anchorfooter();
		showtagfooter('div');

		duceapp_showtagheader('div', 'watermark');
		$watermark = $this->setting['watermark'];
		$waterforum = ($waterforum = intval($watermark['forum']['status'])) ? $waterforum : intval($_G['setting']['watermarkstatus']['forum']);
		$waterforum = $waterforum ? $waterforum : 9;
		$checkedwm[$waterforum] = 'checked';
		duceapp_anchortips('setting_watermark_tips', 'watermark');
		$tabs = array('watermark_forum');
		$subtab = $_GET['subtab1'] ? $_GET['subtab1'] : $tabs[0];
		duceapp_anchortabs('watermark', $tabs, $subtab, 'subtab1');
		duceapp_anchorheader('subtab1_watermark_forum', 'watermark_forum' == $subtab);
		duceapp_showsetting('setting_waterimage', array('setting[watermark][forum][image]', array(
			array(0, duceapp_cplang('setting_waterimage_def'), array('watersetting' => 'none')),
			array(1, duceapp_cplang('setting_waterimage_thumb'), array('watersetting' => '')),
			array(2, duceapp_cplang('setting_waterimage_source'), array('watersetting' => '')),
		), 1), intval($watermark['forum']['image']), 'mradio');
		showtagheader('tbody', 'watersetting', intval($watermark['forum']['image']));
		duceapp_showsetting('setting_waterstatus', '', '', '<table style="margin-bottom: 3px; margin-top:3px;"><tr><td><label><input class="radio" type="radio" name="setting[watermark][forum][status]" value="1" '.$checkedwm[1].'> #1</label></td><td><label><input class="radio" type="radio" name="setting[watermark][forum][status]" value="2" '.$checkedwm[2].'> #2</label></td><td><label><input class="radio" type="radio" name="setting[watermark][forum][status]" value="3" '.$checkedwm[3].'> #3</label></td></tr><tr><td><label><input class="radio" type="radio" name="setting[watermark][forum][status]" value="4" '.$checkedwm[4].'> #4</label></td><td><label><input class="radio" type="radio" name="setting[watermark][forum][status]" value="5" '.$checkedwm[5].'> #5</label></td><td><label><input class="radio" type="radio" name="setting[watermark][forum][status]" value="6" '.$checkedwm[6].'> #6</label></td></tr><tr><td><label><input class="radio" type="radio" name="setting[watermark][forum][status]" value="7" '.$checkedwm[7].'> #7</label></td><td><label><input class="radio" type="radio" name="setting[watermark][forum][status]" value="8" '.$checkedwm[8].'> #8</label></td><td><label><input class="radio" type="radio" name="setting[watermark][forum][status]" value="9" '.$checkedwm[9].'> #9</label></td></tr><tr><td colspan="3"><label><input class="radio" type="radio" name="setting[watermark][forum][status]" value="10" '.$checkedwm[10].'> '.duceapp_cplang('setting_waterrepeat').'</label></td></tr></table>');
		duceapp_showsetting('setting_watermargin', 'setting[watermark][forum][margin]', $watermark['forum']['margin'], 'text');
		duceapp_showsetting('setting_waterfile', 'watermarkforumfile', $watermark['forum']['file'], 'file', '', 0, duceapp_cplang('setting_waterfile_comment', array('input' => $watermark['forum']['file'] ? '<label><input type="checkbox" name="watermarkforumdel" value="1"> '.duceapp_cplang('setting_waterfileclear').'</label> &nbsp;&nbsp; <a href="'.$_G['siteurl'].$watermark['forum']['file'].'" target="blank">'.cplang('view').'</a> &nbsp;&nbsp; ' : '')));
		duceapp_showsetting('setting_waterquality', 'setting[watermark][forum][quality]', $watermark['forum']['quality'], 'text');
		duceapp_showsetting('setting_waterfids', '', '', '<select name="setting[watermark][forum][fid][]" multiple="multiple" size="8" style="margin-bottom:5px;"><option value="0"'.(empty($watermark['forum']['fid']) ? ' selected' : '').'>'.cplang('all').'</option>'.duceapp_forumselect((array)$watermark['forum']['fid']).'</select>');
		showtagfooter('tbody');
		showsubmit('duceapp_submit');
		duceapp_anchorfooter();
		showtagfooter('div');

		$api = $this->setting['ossapi'] ? $this->setting['ossapi'] : 'no';
		$oss = $this->setting['server'][$api];
		$api = $oss['bucket'] ? $api : 'no';
		$osstips = '<br />'.duceapp_remostore_lang($api, 'imgStyleTips');
		duceapp_anchorheader('remoloc');
		duceapp_showsetting('setting_remotolocal', 'setting[remotolocal]', $this->setting['remotolocal']);
		duceapp_showsetting('setting_unfithost', 'setting[unfithost]', $this->setting['unfithost'], 'textarea');
		duceapp_showsetting('setting_remolocgids', '', '', $this->groupselect('setting[remolocgids][]', $this->setting['remolocgids'], 1, 'style="margin-bottom:5px;"'));
		duceapp_showsetting('setting_ossimgstyle', 'setting[ossimgstyle]', $this->setting['ossimgstyle'], 'textarea', '', 0, duceapp_cplang('setting_ossimgstyle_comment', array('osstips' => $osstips)));
		duceapp_showsetting('setting_ossexclfids', '', '', '<select name="setting[ossexclfids][]" multiple="multiple" size="8" style="margin-bottom:5px;"><option value=""'.(empty($this->setting['ossexclfids']) ? ' selected' : '').'>'.cplang('none').'</option>'.duceapp_forumselect((array)$this->setting['ossexclfids']).'</select>');
		showsubmit('duceapp_submit');
		duceapp_anchorfooter();

		duceapp_anchorheader('mobile');
		duceapp_showsetting('setting_inmobile', 'setting[mobile][enable]', $this->setting['mobile']['enable']);
		duceapp_showsetting('setting_hookpicker', 'setting[mobile][hookpicker]', $this->setting['mobile']['hookpicker'], 'text');
		duceapp_showsetting('setting_hookshow', 'setting[mobile][hookshow]', $this->setting['mobile']['hookshow']);
		duceapp_showsetting('setting_hookhides', 'setting[mobile][hookhides]', $this->setting['mobile']['hookhides'], 'text');
		duceapp_showsetting('setting_hookhead', 'setting[mobile][hookhead]', $this->setting['mobile']['hookhead'], 'text');
		duceapp_showsetting('setting_hookfoot', 'setting[mobile][hookfoot]', $this->setting['mobile']['hookfoot'], 'text');
		showsubmit('duceapp_submit');
		duceapp_anchorfooter();

		showformfooter();
	}

	private function save() {

		$cldstat = '';
		for($i = count($this->cldstat); $i >= 1; $i--) {
			$cldstat .= intval($_GET['setting']['cldstat'][$i]);
		}
		$_GET['setting']['cldstat'] = bindec($cldstat);
		$_GET['setting']['watermark']['forum']['file'] = $this->setting['watermark']['forum']['file'];
		$_GET['setting']['watermark']['forum']['fid'] = dintval($_GET['setting']['watermark']['forum']['fid'], true);
		
		if ($_GET['setting']['unfithost']) {
			$unfithost = $exclhost = array();
			foreach(explode("\n", $_GET['setting']['unfithost']) as $host) {
				if ($host = trim($host)) {
					$unfithost[] = $host;
					$exclhost[] = str_replace('\\*', '(.+?)', preg_quote($host));
				}
			}
			$_GET['setting']['unfithost'] = implode("\n", $unfithost);
			$this->setting['exclhost'] = $exclhost ? '/'.implode('|', $exclhost).'/i' : '';
		}

		$this->savesetting($_GET['setting'], true);

		$ossapi = $this->setting['ossapi'];		
		if ($ossapi && $this->setting['server'][$ossapi]) {
			$this->setting['attachurl'] = $this->setting['server'][$ossapi]['remourl'].$this->setting['basedir'];			
		}
		if (is_array($this->setting['forceimagefids'])) {
			$this->setting['forceimagefids'] = array_diff(dintval($this->setting['forceimagefids'], true), array(0));
			$this->setting['forceimagefids'] = @in_array(-1, $this->setting['forceimagefids']) ? -1 : $this->setting['forceimagefids'];
		}
		if (is_array($this->setting['directoss']['exclfids'])) {
			$this->setting['directoss']['exclfids'] = array_diff(dintval($this->setting['directoss']['exclfids'], true), array(0));
		}
		if (is_array($this->setting['limitfids'])) {
			$this->setting['limitfids'] = array_diff(dintval($this->setting['limitfids'], true), array(0));
			$this->setting['limitfids'] = @in_array(-1, $this->setting['limitfids']) ? -1 : $this->setting['limitfids'];
		}
		if (is_array($this->setting['excludegid'])) {
			$this->setting['excludegid'] = array_diff(dintval($this->setting['excludegid'], true), array(0));
		}
		if (is_array($this->setting['ossexclfids'])) {
			$this->setting['ossexclfids'] = array_diff(dintval($this->setting['ossexclfids'], true), array(0));
		}
		if (is_array($this->setting['remolocgids'])) {
			$this->setting['remolocgids'] = array_diff(dintval($this->setting['remolocgids'], true), array(0));
		}
		if (!$this->setting['chklimit']) {
			$this->setting['fileslimit'] = '';
		}
		if (@in_array(0, $this->setting['watermark']['forum']['fid'])) {
			$this->setting['watermark']['forum']['fid'] = 0;
		}
		if ($_GET['watermarkforumdel'] && $this->setting['watermark']['forum']['file']) {
			@unlink($this->setting['watermark']['forum']['file']);
			$this->setting['watermark']['forum']['file'] = '';
		}
		if ($_FILES['watermarkforumfile']['tmp_name'] && preg_match('/^image\/(gif|png)/', $_FILES['watermarkforumfile']['type'])) {
			$filename = dgmdate(TIMESTAMP, 'YmdHis').strtolower(random(8));
			$filepath = DUCEAPP_DATAURL.$filename.'.'.fileext($_FILES['watermarkforumfile']['name']);
			if (duceapp_writeimage(DISCUZ_ROOT.$filepath, $_FILES['watermarkforumfile']['tmp_name'])) {
				if ($this->setting['watermark']['forum']['file']) {
					@unlink($this->setting['watermark']['forum']['file']);
				}
				$this->setting['watermark']['forum']['file'] = $filepath;
			}
		}

		duceapp_succeed();
	}
}

new duceapp_modcp;