<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-05
 * Version: 3.10906
 * Date: 2021-09-13 11:55:24
 * File: remostore.class.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_duceapp_remostore
{
	public function common() {
		global $_G;
		include_once libfile('function/duceapp_core', 'plugin/duceapp_remostore');
		duceapp_remostore_initialize();
	}

	public function avatar($value) {
		C::m('#duceapp_remostore#duceapp_avatar')->hook($value);
	}

	public function global_header() {
		global $_G;
		$module = '';
		if (CURSCRIPT == 'forum' && CURMODULE == 'post') {
			$module = 'post';
		} elseif (CURSCRIPT == 'home' && CURMODULE == 'spacecp') {
			if ($_GET['ac'] == 'upload') {
				$module = 'album';
			} elseif ($_GET['ac'] == 'blog') {
				$module = 'blog';
			} elseif ($_GET['ac'] == 'avatar') {
				$module = 'cpavatar';
			}
		} elseif (CURSCRIPT == 'portal' && CURMODULE == 'portalcp') {
			if ($_GET['ac'] == 'article' || $_GET['op'] == 'edit') {
				$module = 'portal';
			}
		} elseif (in_array(CURMODULE, array('forumdisplay', 'viewthread', 'follow'))) {
			$module = CURMODULE == 'follow' ? 'follow' : 'fastpost';
		}
		if ($module && $_G['uid']) {
			if (!defined('DUCEAPP_REMOSTORE')) {
				$this->common();
			}
			return duceapp_remostore_tpl_uploader($module);
		}
	}
}

class plugin_duceapp_remostore_forum extends plugin_duceapp_remostore
{
	public function attachment() {
		C::m('#duceapp_remostore#duceapp_oss')->module('forum_attachment');
	}

	public function image() {
		C::m('#duceapp_remostore#duceapp_oss')->module('forum_image');
	}

	public function ajax() {
		global $_G;
		if ($_GET['action'] == 'setthreadcover') {
			C::m('#duceapp_remostore#duceapp_oss')->module('forum_ajax');
		}
	}

	public function post() {
		global $_G;
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			if ($_G['cache']['duceapp_remostore']['remotolocal'] && ($_GET['editsubmit'] || $_GET['topicsubmit'])) {
				C::m('#duceapp_remostore#duceapp_oss')->module('remotolocal');
			}
			if (defined('DUCEAPP_OSSON')) {
				$directoss = $_G['cache']['duceapp_remostore']['directoss'];
				if (!@in_array($_G['fid'], $directoss['exclfids']) && ($directoss['image'] || $directoss['attach'])) {
					$_G['forum']['disablewatermark'] = 1;
				}
				$watermark = $_G['cache']['duceapp_remostore']['watermark'];
				if ($watermark['forum']['image'] && (empty($watermark['forum']['fid']) || @in_array($_G['fid'], $watermark['forum']['fid']))) {
					$_G['forum']['disablewatermark'] = 1;
				}
			}
		}
	}

	public function viewthread_output() {
		if (!defined('DUCEAPP_INPAY') && (!defined('DUCEAPP_ATTACHPAN') || defined('IN_MOBILE'))){
			C::m('#duceapp_remostore#duceapp_oss')->module('imagestyle');
		}
	}
}

class plugin_duceapp_remostore_misc extends plugin_duceapp_remostore
{
	public function imgcropper(){
        global $_G;
		C::m('#duceapp_remostore#duceapp_oss')->module('misc_imgcropper');
    }
}

class mobileplugin_duceapp_remostore extends plugin_duceapp_remostore{}
class mobileplugin_duceapp_remostore_forum extends plugin_duceapp_remostore_forum{}