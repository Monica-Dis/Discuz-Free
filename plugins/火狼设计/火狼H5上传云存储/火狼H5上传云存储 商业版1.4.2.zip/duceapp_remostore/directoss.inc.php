<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-24
 * Version: 3.10703
 * Date: 2021-09-13 11:55:24
 * File: directoss.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if ($_G['uid'] && defined('DUCEAPP_OSSON')) 
{
	$_G['inajax'] = $_GET['inajax'] = 1;

	if ($_GET['op'] == 'signature') {	
		$hash = md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']);
		$type = $_GET['type'];
		$attachtype = $_GET['attachtype'];
		$filename = trim($_GET['filename']);

		if ($_GET['hash'] != $hash || empty($filename) || !in_array($type, array('forum')) || !in_array($attachtype, array('image', 'attach'))) {
			echo -10;
			exit();
		}

		$upload = new discuz_upload();
		$type = $upload->check_dir_type($type);
		$ext = $upload->fileext($filename);
		$filename = dhtmlspecialchars($filename, ENT_QUOTES);

		if (strlen($filename) > 90) {
			$filename = cutstr($filename, 80, '').'.'.$ext;
		}
		
		$extension = $upload->get_target_extension($ext);
		$dir = $type.'/'.$upload->get_target_dir($type, 0);
		$object = $upload->get_target_filename($upload->type, 0, '').'.'.$extension;

		$allowupload = !$_G['group']['maxattachnum'] || $_G['group']['maxattachnum'] && $_G['group']['maxattachnum'] > getuserprofile('todayattachs');
		if (!$allowupload) {
			echo -6;
			exit();
		}

		if ($_G['group']['attachextensions'] && (!preg_match('/(^|\s|,)'.preg_quote($ext, '/').'($|\s|,)/i', $_G['group']['attachextensions']) || !$ext)) {
			echo -1;
			exit();
		}

		echo C::m('#duceapp_remostore#duceapp_oss')->exec('getPolicy', $dir, $object);
		exit();

	} elseif ($_GET['op'] == 'callback') {
		
		require_once libfile('class/duceapp_uploadoss', 'plugin/duceapp_remostore');
		$data = C::m('#duceapp_remostore#duceapp_oss')->exec('getData', $_GET['object']);
		new duceapp_uploadoss($data);
	}
}
exit('0');