<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-09
 * Version: 3.10701
 * Date: 2021-09-13 11:55:24
 * File: duceapp_base.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$basefile = array(
	'./class/class_duceapp_qrcode.php',
	'./function/function_duceapp_template.php',
	'./include/citycn.json',
	'./model/model_duceapp_bdmap.php',
	'./model/model_duceapp_cptools.php',
	'./model/model_duceapp_filesock.php',
	'./model/model_duceapp_helper.php',
	'./model/model_duceapp_imageblur.php',
	'./model/model_duceapp_lunar.php',
	'./model/model_duceapp_member.php',
	'./model/model_duceapp_pinyin.php',
	'./model/model_duceapp_security.php',
	'./model/model_duceapp_translang.php',
	'./model/model_duceapp_weather.php',
	'./static/getcolor.htm',
	'./static/cacert/root.pem',
	'./static/css/admin.css',
	'./static/css/acpanel.css',
	'./static/css/base.css',
	'./static/css/duceapp_font.css',
	'./static/css/style.css',
	'./static/css/weather.css',
	'./static/css/fonts/duceapp_base.eot',
	'./static/css/fonts/duceapp_base.svg',
	'./static/css/fonts/duceapp_base.ttf',
	'./static/css/fonts/duceapp_base.woff',
	'./static/css/fonts/duceapp_weather.eot',
	'./static/css/fonts/duceapp_weather.svg',
	'./static/css/fonts/duceapp_weather.ttf',
	'./static/css/fonts/duceapp_weather.woff',
	'./static/js/admin.js',
	'./static/js/common.js',
	'./static/js/jquery.min.js',
	'./static/js/jquery.swiper.min.js',
	'./static/js/jweixin-1.3.2.js',
	'./static/js/optinit.js',
	'./static/js/sortable.js',
	'./static/image/codebg.gif',
	'./static/image/tab_bg.gif',
	'./template/library.htm',
	'./template/touch/library.htm',
	'./template/touch/footer.htm',
	'./template/touch/header.htm',
	'./template/touch/seccheck.htm',
);

dmkdir($DUCEAPP_BASE = DISCUZ_ROOT.'./source/plugin/duceapp_base/', 0777, false);

foreach($basefile as $file) {
	if ($file == './template/touch/header.htm' && C::t('common_plugin')->fetch_by_identifier('duceapp_base')) {
		continue;
	}
	if (file_exists($from = DUCEAPP_ROOT.$file)) {
		$target = $DUCEAPP_BASE.$file;
		if (!file_exists($target) || @filemtime($from) > @filemtime($target)) {
			dmkdir(dirname($target), 0777, false);
			@copy($from, $target);
		}
	}
}

@unlink(DUCEAPP_ROOT.'./install/duceapp_base.php');