<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-09
 * Version: 3.10609
 * Date: 2021-09-13 11:55:24
 * File: initialize.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

global $_G, $pluginarray, $plang;

if (!isset($_G['cache']['duceapp_remostore'])) {
	loadcache('duceapp_remostore');
}

dmkdir(DISCUZ_ROOT.DUCEAPP_DATAURL);