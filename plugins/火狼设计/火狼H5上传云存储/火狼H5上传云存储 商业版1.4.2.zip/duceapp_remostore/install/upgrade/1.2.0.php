<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-07-20
 * Version: 3.10714
 * Date: 2021-09-13 11:55:24
 * File: 1.2.0.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

global $_G, $updatebatch;

foreach(array(
	'aliyun' => 'aliyunoss',
	'huawei' => 'huaweiobs',
	'qiniu' => 'qiniukodo',
	'tencent' => 'tencentcos',
) as $oldkey => $newkey) {
	if (!empty($_G['cache']['duceapp_remostore']['server'][$oldkey])) {
		$_G['cache']['duceapp_remostore']['server'][$newkey] = $_G['cache']['duceapp_remostore']['server'][$oldkey];
		unset($_G['cache']['duceapp_remostore']['server'][$oldkey]);
	}
	if ($_G['cache']['duceapp_remostore']['ossapi'] == $oldkey) {
		$_G['cache']['duceapp_remostore']['ossapi'] = $newkey;
	}
}

@unlink(DUCEAPP_ROOT.'./compon/aliyun.class.php');
@unlink(DUCEAPP_ROOT.'./compon/huawei.class.php');
@unlink(DUCEAPP_ROOT.'./compon/qiniu.class.php');
@unlink(DUCEAPP_ROOT.'./compon/tencent.class.php');
foreach(array('SC_GBK', 'SC_UTF8', 'TC_BIG5', 'TC_UTF8') as $outlang) {
	@unlink(DUCEAPP_ROOT.'./language/lang_aliyun_'.$outlang.'.php');
	@unlink(DUCEAPP_ROOT.'./language/lang_huawei_'.$outlang.'.php');
	@unlink(DUCEAPP_ROOT.'./language/lang_qiniu_'.$outlang.'.php');
	@unlink(DUCEAPP_ROOT.'./language/lang_tencent_'.$outlang.'.php');
}

$updatebatch = true;