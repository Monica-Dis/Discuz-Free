<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * 最新插件：http://t.cn/Aiux1Jx1
 * Created: 2021-07-20
 * Version: 3.10716
 * Date: 2021-08-24 04:43:51
 * File: lang_aliyunoss.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$duceapp_compon_lang = array(
	'appver' => '1.0.7',
	'menu_api' => 'oss',
	'menu_order' => 0,
	'menu_title' => '阿裏雲OSS',
	'css' => 1,

	'anchors' => array(
		'basic' => array('real' => 2, 'title' => '接口參數'),
		'referer' => array('real' => 2, 'title' => '防盜鏈'),
	),

	'tipval' => array(
		'bucket' => $_G['cache']['duceapp_remostore']['server']['aliyunoss']['bucket'],
		'endpoint' => str_replace('.aliyuncs.com', '', $_G['cache']['duceapp_remostore']['server']['aliyunoss']['endpoint']),
	),

	'accesskey' => 'Access Key ID',
	'accesskey_comment' => '阿裏雲<a href="https://ram.console.aliyun.com/manage/ak" target="_blank">AccessKey 管理界麵</a>獲取',
	'secretkey' => 'Access Key Secret',
	'secretkey_comment' => '阿裏雲<a href="https://ram.console.aliyun.com/manage/ak" target="_blank">AccessKey 管理界麵</a>獲取',
	'bucket' => '存儲空間(Bucket)名稱',
	'bucket_comment' => '填寫對象存儲空間 Bucket 名稱，如果 Bucket 不存在，提交後可創建',
	'referer' => '防盜鏈 HTTP Referer 白名單',
	'referer_comment' => 'Referer為域名和IP地址，支持通配符星號（*）和問號（?），多個Referer以換行分隔，示例：*.duceapp.com',
	'referer_allowempty' => '允許空 Referer',
	'endpoint' => '訪問節點(EndPoint)外網',
	'endpoint_comment' => '阿裏雲對象儲存 / <u>Bucket概況</u> / <u>訪問域名</u> / Endpoint（地域節點）外網地址，示例：oss-cn-hangzhou.aliyuncs.com',
	'endpoint_region' => '選擇地域：',
	'endpoint_cn-hangzhou' => '華東1（杭州）',
	'endpoint_cn-shanghai' => '華東2（上海）',
	'endpoint_cn-qingdao' => '華北1（青島）',
	'endpoint_cn-beijing' => '華北2（北京）',
	'endpoint_cn-zhangjiakou' => '華北3（張家口）',
	'endpoint_cn-huhehaote' => '華北5（呼和浩特）',
	'endpoint_cn-wulanchabu' => '華北6（烏蘭察布）',
	'endpoint_cn-shenzhen' => '華南1（深圳）',
	'endpoint_cn-heyuan' => '華南2（河源）',
	'endpoint_cn-guangzhou' => '華南3（廣州）',
	'endpoint_cn-chengdu' => '西南1（成都）',
	'endpoint_cn-hongkong' => '中國（香港）',
	'endpoint_ap-southeast-1' => '新加坡',
	'endpoint_ap-southeast-2' => '澳大利亞（悉尼）',
	'endpoint_ap-southeast-3' => '馬來西亞（吉隆坡）',
	'endpoint_ap-southeast-5' => '印度尼西亞（雅加達）',
	'endpoint_ap-northeast-1' => '日本（東京）',
	'endpoint_ap-south-1' => '印度（孟買）',
	'endpoint_eu-central-1' => '德國（法蘭克福）',
	'endpoint_eu-west-1' => '英國（倫敦）',
	'endpoint_us-west-1' => '美國（矽穀）',
	'endpoint_us-east-1' => '美國（弗吉尼亞）',
	'endpoint_me-east-1' => '阿聯酋（迪拜）',
	'endpoint_emptyerr' => '訪問節點(EndPoint)不能為空',
	'domain' => '存儲空間(Bucket)域名外網',
	'domain_comment' => '阿裏雲對象儲存 / <u>Bucket概況</u> / <u>訪問域名</u> / Bucket 域名外網地址',
	'remourl' => '存儲空間(Bucket)訪問網址',
	'remourl_comment' => '填寫“http(s)”開頭的Bucket訪問網址，阿裏雲對象儲存 / <u>Bucket名稱</u> / <u>傳輸管理</u> / <u>域名管理</u> / <u>綁定域名</u> 或 <u>Bucket概況</u> / <u>訪問域名</u> / Bucket 域名外網地址',
	'imagestyle' => '圖片處理樣式',
	'imagestyle_comment' => '可給上傳的圖片進行壓縮、添加水印等操作，阿裏雲對象儲存 / <u>Bucket名稱</u> / <u>數據處理</u> / 圖片處理，拷貝樣式代碼',
	'imgStyleTips' => '<b>阿裏雲OSS，<a href="https://oss.console.aliyun.com/bucket/'.str_replace('.aliyuncs.com', '', $_G['cache']['duceapp_remostore']['server']['aliyunoss']['endpoint']).'/'.$_G['cache']['duceapp_remostore']['server']['aliyunoss']['bucket'].'/process/img" target="_blank">圖片樣式設置</a>，<a href="https://help.aliyun.com/document_detail/204523.html" target="_blank">設置教程</a></b>',
);