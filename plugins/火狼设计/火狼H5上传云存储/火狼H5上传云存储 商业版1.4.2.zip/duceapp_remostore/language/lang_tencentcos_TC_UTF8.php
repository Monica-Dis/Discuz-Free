<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * 最新插件：http://t.cn/Aiux1Jx1
 * Created: 2021-07-20
 * Version: 3.10716
 * Date: 2021-08-24 04:43:51
 * File: lang_tencentcos.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$duceapp_compon_lang = array(
	'appver' => '1.0.6',
	'menu_api' => 'oss',
	'menu_order' => 1,
	'menu_title' => '騰訊雲COS',
	'css' => 1,

	'anchors' => array(
		'basic' => array('real' => 1, 'title' => '接口參數'),
	),

	'appid' => 'AppId',
	'appid_comment' => '<a href="https://console.cloud.tencent.com/cam/capi" target="_blank">點此獲取</a>',
	'secretid' => 'SecretId',
	'secretid_comment' => '騰訊雲<a href="https://console.cloud.tencent.com/cam/capi" target="_blank">API密鑰管理界麵</a>獲取',
	'secretkey' => 'SecretKey',
	'secretkey_comment' => '騰訊雲<a href="https://console.cloud.tencent.com/cam/capi" target="_blank">API密鑰管理界麵</a>獲取',
	'bucket' => '存儲空間(Bucket)名稱',
	'bucket_comment' => '填寫對象儲存 Bucket 名稱，存儲桶名稱格式：BucketName-AppId，如果要新創建，名稱後麵可不加-AppId，創建時填寫secretid相對應的AppId',
	'region' => '所屬地域節點(Region)',
	'region_comment' => '騰訊雲對象儲存 / <u>Bucket概況頁麵</u> / <u>基本信息</u> / <u>所屬地域</u>，示例：ap-shanghai',
	'region_0' => '選擇地域：',
	'region_1' => '中國',
	'region_2' => '亞太地區',
	'region_3' => '歐洲地區',
	'region_4' => '北美地區',
	'region_ap-nanjing' => '南京',
	'region_ap-chengdu' => '成都',
	'region_ap-beijing' => '北京',
	'region_ap-guangzhou' => '廣州',
	'region_ap-shanghai' => '上海',
	'region_ap-chongqing' => '重慶',
	'region_ap-beijing-fsi' => '北京金融',
	'region_ap-shanghai-fsi' => '上海金融',
	'region_ap-shenzhen-fsi' => '深圳金融',
	'region_ap-hongkong' => '中國香港',
	'region_ap-singapore' => '新加坡',
	'region_ap-mumbai' => '印度孟買',
	'region_ap-seoul' => '韓國首爾',
	'region_ap-bangkok' => '泰國曼穀',
	'region_ap-tokyo' => '日本東京',
	'region_eu-moscow' => '俄羅斯莫斯科',
	'region_eu-frankfurt' => '德國法蘭克福',
	'region_na-toronto' => '加拿大多倫多',
	'region_na-ashburn' => '美國弗吉尼亞',
	'region_na-siliconvalley' => '美國矽穀',
	'domain' => '存儲空間(Bucket)訪問域名',
	'domain_comment' => '騰訊雲對象儲存 / <u>Bucket概況頁麵</u> / <u>域名信息</u> / <u>訪問域名</u>，示例：https://duceapp-123456.cos.ap-shanghai.myqcloud.com',
	'remourl' => '存儲空間(Bucket)訪問網址',
	'remourl_comment' => '填寫“http(s)”開頭的Bucket訪問網址，可前往騰訊雲對象儲存 / <u>Bucket名稱</u> / <u>域名和傳輸管理</u> / <u>自定義源站域名</u> / <u>綁定域名</u> 或 使用 Bucket 訪問域名',
	'imgStyleTips' => '<b>騰訊雲COS，<a href="https://console.cloud.tencent.com/cos5/bucket/setting?type=ci&anchorType=image&bucketName='.$_G['cache']['duceapp_remostore']['server']['tencentcos']['bucket'].'&projectId=0&path=%252F&region='.$_G['cache']['duceapp_remostore']['server']['tencentcos']['region'].'" target="_blank">圖片樣式設置</a>，<a href="https://cloud.tencent.com/document/product/436/46823" target="_blank">設置教程</a></b>',
);