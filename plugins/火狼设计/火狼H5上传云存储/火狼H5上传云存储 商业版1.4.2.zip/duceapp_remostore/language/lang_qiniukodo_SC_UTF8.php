<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * 最新插件：http://t.cn/Aiux1Jx1
 * Created: 2021-07-20
 * Version: 3.10716
 * Date: 2021-08-24 04:43:51
 * File: lang_qiniukodo.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$duceapp_compon_lang = array(
	'appver' => '1.0.6',
	'menu_api' => 'oss',
	'menu_order' => 2,
	'menu_title' => '七牛云Kodo',
	'css' => 1,

	'anchors' => array(
		'basic' => array('real' => 1, 'title' => '接口参数'),
	),

	'accesskey' => 'AccessKey',
	'accesskey_comment' => '七牛云<a href="https://portal.qiniu.com/user/key" target="_blank">密钥管理界面</a>获取',
	'secretkey' => 'SecretKey',
	'secretkey_comment' => '七牛云<a href="https://portal.qiniu.com/user/key" target="_blank">密钥管理界面</a>获取',
	'bucket' => '存储空间(Bucket)名称',
	'bucket_comment' => '填写对象存储空间 Bucket 名称',
	'endpoint' => '区域节点(EndPoint)',
	'endpoint_comment' => '七牛云对象储存 / <u>空间概览</u> / <u>基础配置</u> / 点击查看 <u>S3 域名</u>，示例：s3-cn-east-1.qiniucs.com',
	'region_0' => '选择区域：',
	'region_z0' => '华东',
	'region_z1' => '华北',
	'region_z2' => '华南',
	'region_na0' => '北美',
	'region_as0' => '东南亚',
	'region_cn-east-2' => '华东-浙江2',
	'domain' => '存储空间(Bucket)域名',
	'domain_comment' => '七牛云对象储存 / <u>空间概览</u> / <u>基础配置</u> / 点击查看 <u>S3 域名</u>',
	'remourl' => '存储空间(Bucket)外链访问网址',
	'remourl_comment' => '填写“http(s)”开头的Bucket访问网址，七牛云对象储存 / <u>空间概览</u> / <u>域名管理</u> / <u>绑定域名</u> 或 存储空间外链域名',
	'imgStyleTips' => '<b>七牛云，<a href="https://portal.qiniu.com/kodo/bucket/image-style?bucketName='.$_G['cache']['duceapp_remostore']['server']['qiniukodo']['bucket'].'" target="_blank">图片样式设置</a>，<a href="http://dn-odum9helk.qbox.me/spjc/4.mp4" target="_blank">视频教程</a></b>',
);