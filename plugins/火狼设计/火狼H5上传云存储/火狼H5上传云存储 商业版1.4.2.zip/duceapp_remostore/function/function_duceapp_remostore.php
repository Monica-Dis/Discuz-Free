<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-07
 * Version: 3.10907
 * Date: 2021-09-13 11:55:24
 * File: function_duceapp_remostore.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function duceapp_remostore_initialize() {
	global $_G;
	static $inited = false;
	if ($inited) {
		return;
	}
	$inited = true;
	if (!isset($_G['cache']['duceapp_remostore'])) {
		loadcache('duceapp_remostore');
	}
	define('DUCEAPP_REMOSTORE', DISCUZ_ROOT.'./source/plugin/duceapp_remostore/');
	C::m('#duceapp_remostore#duceapp_oss');
	include_once template('duceapp_remostore:module');
}

function duceapp_remostore_getstatus($i, $key = 'cldstat') {
	global $_G;
	static $status = array();
	if (!isset($status[$key][$i])) {
		$stat = $_G['cache']['duceapp_remostore'][$key];
		$count = 5;
		if (empty($stat) || $i >= $count) {
			return 0;
		}
		$stat = sprintf('%0'.$count.'b', $stat);
		for ($j = 1; $j <= $count; $j++) {
			$status[$key][$j-1] = $stat{$count - $j};
		}
	}
	return $status[$key][$i];
}

function duceapp_remostore_authc() {
	return '663bf6b328cc1bbcfb87ecdcd54b0029';
}

function duceapp_remostore_fileslimit() {
	global $_G;
	static $surplus;
	if ($surplus !== null) {
		return $surplus;
	}
	$fileslimit = intval($_G['cache']['duceapp_remostore']['fileslimit']);
	if ($fileslimit > 0) {
		$fileslimit = !@in_array($_G['groupid'], $_G['cache']['duceapp_remostore']['excludegid']) && 
			($_G['cache']['duceapp_remostore']['limitfids'] == -1 || @in_array($_G['fid'], $_G['cache']['duceapp_remostore']['limitfids'])) ? $fileslimit : 0;
	}
	$surplus = false;
	if ($fileslimit > 0) {
		require_once libfile('function/post');
		$pid = dintval($_GET['pid']);
		$attachlist = getattach($pid);
		$attachs = @count($attachlist['attachs']['used']) + @count($attachlist['attachs']['unused']);
		$imgattachs = @count($attachlist['imgattachs']['used']) + @count($attachlist['imgattachs']['unused']);
		$surplus = max(0, $fileslimit - $attachs - $imgattachs);
	}
	return $surplus;
}

function duceapp_remostore_lang($file, $var = null) {
	global $_G;
	static $lang = array();
	if (!isset($lang[$file])) {
		$path = DISCUZ_ROOT.'./source/plugin/duceapp_remostore/language/';
		$incfile = file_exists($incfile = $path.'lang_'.$file.'_'.currentlang().'.php') ? $incfile : $path.'lang_'.$file.'.php';
		$lang[$file] = is_array($ret = @include $incfile) ? $ret : ($duceapp_compon_lang ? $duceapp_compon_lang : array());
	}
	return $var ? $lang[$file][$var] : $lang[$file];
}

function duceapp_remostore_watermark($type = 'forum') {
	static $status;
	if ($status !== null) {
		return $status[$type];
	}
	global $_G;
	if (!isset($_G['cache']['duceapp_remostore'])) {
		loadcache('duceapp_remostore');
	}
	$watermark = $_G['cache']['duceapp_remostore']['watermark'];
	if ($status[$type] = $watermark[$type]['image']) {
		$_G['setting']['watermarkstatus'] = dunserialize($_G['setting']['watermarkstatus']);		
		$_G['setting']['watermarkstatus'][$type] = $watermark[$type]['status'];
		$_G['setting']['watermarkstatus'] = serialize($_G['setting']['watermarkstatus']);
		$_G['setting']['watermarkfile'][$type] = $watermark[$type]['file'];
		if ($watermark[$type]['file']) {
			$_G['setting']['watermarktype'][$type] = preg_match('/\.png/', $watermark[$type]['file']) ? 'png' : 'gif';
		}
		if ($watermark[$type]['quality'] > 0 && $watermark[$type]['quality'] <= 100) {
			$_G['setting']['watermarkquality'] = dunserialize($_G['setting']['watermarkquality']);
			$_G['setting']['watermarkquality'][$type] = intval($watermark[$type]['quality']);
			$_G['setting']['watermarkquality'] = serialize($_G['setting']['watermarkquality']);
		}
		$_G['setting']['watermarkmargin'][$type] = intval($watermark[$type]['margin']);
	}	
	return $status[$type];
}