<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-05
 * Version: 3.10605
 * Date: 2021-09-13 11:55:24
 * File: compon.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once libfile('class/duceapp_admincp', 'plugin/duceapp_remostore');
require_once libfile('class/duceapp_admincompon', 'plugin/'.DUCEAPP_SINGLE);

new duceapp_compon;