<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-09
 * Version: 3.10701
 * Date: 2021-09-13 11:55:24
 * File: avatar.inc.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if (empty($_GET['batchnew']) && (!defined('DUCEAPP_OSSON') || !duceapp_remostore_getstatus(4))) {
	exit;
}

$uid = isset($_GET['uid']) ? intval($_GET['uid']) : intval($_G['uid']);
$size = isset($_GET['size']) ? $_GET['size'] : 'middle';
$random = isset($_GET['random']) ? $_GET['random'] : '';
$type = isset($_GET['type']) ? $_GET['type'] : '';
$check = isset($_GET['check_file_exists']) ? $_GET['check_file_exists'] : '';
$ucenterurl = $_G['setting']['ucenterurl'];
$file = 'data/avatar/'.get_avatar($uid, $size, $type);

if (C::m('#duceapp_remostore#duceapp_avatar')->check($uid, $file)) {
	if ($check) {
		echo 1; exit;
	}
	$avatar = C::m('#duceapp_remostore#duceapp_oss')->objectUrl($file, $ucenterurl.'/', 'uc_server/');
} elseif($_file = C::m('#duceapp_remostore#duceapp_avatar')->upload($uid, $file)) {
	$avatar = $_file;
} else {
	$avatar = $ucenterurl.'/images/noavatar_'.$size.'.gif';
}

if (empty($_GET['batchnew'])) {
	$random = !empty($random) ? rand(1000, 9999) : '';
	$avatar .= $random ? '?random='.$random : '';
	dheader('location:' . $avatar);
}
exit();

function get_avatar($uid, $size = 'middle', $type = '') {
	$size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	$uid = abs(intval($uid));
	$uid = sprintf("%09d", $uid);
	$dir1 = substr($uid, 0, 3);
	$dir2 = substr($uid, 3, 2);
	$dir3 = substr($uid, 5, 2);
	$typeadd = $type == 'real' ? '_real' : '';
	return $dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).$typeadd."_avatar_$size.jpg";
}