<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-05
 * Version: 3.10605
 * Date: 2021-09-13 11:55:24
 * File: check.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

define('DUCEAPP_ROOT', dirname(__FILE__).'/');
$duceapp_base = C::t('common_plugin')->fetch_by_identifier('duceapp_base');
if ($_GET['duceapp'] != 'addon') {
	$base_supportver = '2.0.1';
	@include DUCEAPP_ROOT.'language/lang_'.(file_exists(DUCEAPP_ROOT.'language/lang_check.php') ? 'check' : 'check_'.currentlang()).'.php';
	if ($duceapp_base && $duceapp_base['version'] < $base_supportver) {
		cpmsg('duceapp_base_supportver');
		exit;
	}
	if (!file_exists($admincss = DISCUZ_ROOT.'./source/plugin/duceapp_base/static/css/admin.css')) {
		include DUCEAPP_ROOT.'install/duceapp_base.php';
		if (!file_exists($admincss)) {
			cpmsg('duceapp_base_nowriteaccess');
			exit;
		}
	}
}
define('DUCEAPP_AUTHC', '{ADDONVAR:SN}');
define('DUCEAPP_SINGLE', $duceapp_base ? 'duceapp_base' : basename(dirname(__FILE__)));