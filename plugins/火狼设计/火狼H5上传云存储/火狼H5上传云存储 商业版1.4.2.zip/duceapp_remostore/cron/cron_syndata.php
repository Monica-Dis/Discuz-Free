<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-14
 * Version: 3.10630
 * Date: 2021-09-13 11:55:24
 * File: cron_syndata.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

/*
cronname:duceapp_syndata
week:
day:
hour:
minute:0,10,20,30,40,50
*/

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/duceapp_core', 'plugin/duceapp_remostore');
C::m('#duceapp_remostore#duceapp_oss')->module('admincp_syndata');
defined('DUCEAPP_OSSON') && duceapp_remostore_ignore_abort('cron', 2);