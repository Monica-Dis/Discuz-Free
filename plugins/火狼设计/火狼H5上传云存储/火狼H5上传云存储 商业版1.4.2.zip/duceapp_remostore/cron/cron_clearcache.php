<?php

/**
 * Copyright (c) 2011 by Dism.Taobao.Com
 * ���²����http://t.cn/Aiux1Jx1
 * Created: 2021-06-15
 * Version: 3.10630
 * Date: 2021-09-13 11:55:24
 * File: cron_clearcache.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

/*
cronname:duceapp_clearcache
week:
day:
hour:05
minute:
*/

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/duceapp_core', 'plugin/duceapp_remostore');
duceapp_remostore_initialize();
if (defined('DUCEAPP_OSSON')) {
	duceapp_remostore_clearcache('data/attachment/thumb/', 86400 * 7);
	duceapp_remostore_clearcache('data/attachment/image/');
}

function duceapp_remostore_clearcache($prefix = '', $cachelife = 0, $limit = 100, $marker = '') {
	$result = C::m('#duceapp_remostore#duceapp_oss')->exec('getFileslist', $prefix, $marker, $limit);
	if ($result && $result['items']) {
		$objects = array();
		foreach($result['items'] as $i => $object) {
			if (!$cachelife || $object['filemtime'] + $cachelife < TIMESTAMP) {
				$objects[] = $object['key'];
			}
		}
		if ($objects) {
			C::m('#duceapp_remostore#duceapp_oss')->exec('deleteFile', $objects, 'basedir:');
		}
		if ($result['marker']) {
			duceapp_remostore_clearcache($prefix, $cachelife, $limit, $result['marker']);
		}
	}
}