<?php

/**
 * Copyright (c) 2011 by dism.taobao.com
 * Author: Hoolan Chan
 * Created: 2021-07-20
 * Version: 3.10716
 * Date: 2021-08-24 04:43:51
 * File: lang_qiniukodo.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$duceapp_compon_lang = array(
	'appver' => '1.0.6',
	'menu_api' => 'oss',
	'menu_order' => 2,
	'menu_title' => '七牛雲Kodo',
	'css' => 1,

	'anchors' => array(
		'basic' => array('real' => 1, 'title' => '接口參數'),
	),

	'accesskey' => 'AccessKey',
	'accesskey_comment' => '七牛雲<a href="https://portal.qiniu.com/user/key" target="_blank">密鑰管理界麵</a>獲取',
	'secretkey' => 'SecretKey',
	'secretkey_comment' => '七牛雲<a href="https://portal.qiniu.com/user/key" target="_blank">密鑰管理界麵</a>獲取',
	'bucket' => '存儲空間(Bucket)名稱',
	'bucket_comment' => '填寫對象存儲空間 Bucket 名稱',
	'endpoint' => '區域節點(EndPoint)',
	'endpoint_comment' => '七牛雲對象儲存 / <u>空間概覽</u> / <u>基礎配置</u> / 點擊查看 <u>S3 域名</u>，示例：s3-cn-east-1.qiniucs.com',
	'region_0' => '選擇區域：',
	'region_z0' => '華東',
	'region_z1' => '華北',
	'region_z2' => '華南',
	'region_na0' => '北美',
	'region_as0' => '東南亞',
	'region_cn-east-2' => '華東-浙江2',
	'domain' => '存儲空間(Bucket)域名',
	'domain_comment' => '七牛雲對象儲存 / <u>空間概覽</u> / <u>基礎配置</u> / 點擊查看 <u>S3 域名</u>',
	'remourl' => '存儲空間(Bucket)外鏈訪問網址',
	'remourl_comment' => '填寫“http(s)”開頭的Bucket訪問網址，七牛雲對象儲存 / <u>空間概覽</u> / <u>域名管理</u> / <u>綁定域名</u> 或 存儲空間外鏈域名',
	'imgStyleTips' => '<b>七牛雲，<a href="https://portal.qiniu.com/kodo/bucket/image-style?bucketName='.$_G['cache']['duceapp_remostore']['server']['qiniukodo']['bucket'].'" target="_blank">圖片樣式設置</a>，<a href="http://dn-odum9helk.qbox.me/spjc/4.mp4" target="_blank">視頻教程</a></b>',
);