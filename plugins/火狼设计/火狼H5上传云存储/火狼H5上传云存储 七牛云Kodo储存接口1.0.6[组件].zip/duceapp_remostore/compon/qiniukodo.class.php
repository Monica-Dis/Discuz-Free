<?php

/**
 * Copyright (c) 2011 by dism.taobao.com
 * Author: Hoolan Chan
 * Created: 2021-07-20
 * Version: 3.10714
 * Date: 2021-08-24 04:43:51
 * File: qiniukodo.class.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class duceapp_compon_qiniukodo
{
	private $serverName = 'qiniukodo';
	public $regions = array(
		'z0' => 'https://upload.qiniup.com', 
		'z1' => 'https://upload-z1.qiniup.com', 
		'z2' => 'https://upload-z2.qiniup.com', 
		'na0' => 'https://upload-na0.qiniup.com', 
		'as0' => 'https://upload-as0.qiniup.com', 
		'cn-east-2' => 'https://upload-cn-east-2.qiniup.com',
	);

	public function init(){
		$this->componvar = & $this->setting['server'][$this->serverName];
		duceapp_showanchors();
		call_user_func(array(__CLASS__, $this->cpmethod));
	}

	private function main() {
		global $_G;
		duceapp_formheader('enctype');
		duceapp_anchorheader();
		duceapp_showsetting('accesskey', 'setting[accesskey]', $this->componvar['accesskey'], 'text');
		duceapp_showsetting('secretkey', 'setting[secretkey]', duceapp_cutencrypt($this->componvar['secretkey']), 'text');
		duceapp_showsetting('bucket', 'setting[bucket]', $this->componvar['bucket'], 'text');
		duceapp_showsetting('remourl', 'setting[remourl]', $this->componvar['remourl'], 'text');
		duceapp_showsetting('setting_setossapi', 'setting[setossapi]', $this->setting['ossapi'] == $this->serverName ? 1 : 0);
		showsubmit('submit', 'submit', '', ' <input type="button" class="btn" value="'.duceapp_cplang('server_check').'" onclick="serverCheck(this)">');
		duceapp_anchorfooter();
		showformfooter(); /*Dism_taobao-com*/
		echo '<script type="text/javascript">
		function serverCheck(btn){
			duceapp_prompt("<span class=\"rotateLoading\"><div class=\"duceapp-ballclip\"><div class=\"duceapp-ballclip-rotate\"></div></div></span> &nbsp;'.duceapp_cplang('server_checking').'");
			btn.disabled = true;
			var form = btn.form, postdata = "";
			for (var i in form.elements) {
				if (form.elements[i].type == "text") {
					postdata += form.elements[i].name + "=" + form.elements[i].value + "&";
				}
			}
			postdata += "duceapp_submit=yes&formhash='.FORMHASH.'";
			var x = new Ajax();
			x.post("'.$this->redirect.'&check=yes&inajax=1", postdata, function(s, x) {
				btn.disabled = false;
				evalscript(s);
			});
		}
		</script>';
	}	

	private function save() {
		
		$this->componvar = array(
			'accesskey' => trim($_GET['setting']['accesskey']),
			'secretkey' => duceapp_comparencrypt(trim($_GET['setting']['secretkey']), $this->componvar['secretkey']),
			'bucket' => trim($_GET['setting']['bucket']),
			'region' => trim($_GET['setting']['region']),
			'domain' => $this->componvar['domain'],
			'remourl' => trim($_GET['setting']['remourl']),
			'zoomrule' => 'imageView2/2/w/{w}/interlace/1/q/{q}',
		);

		if ($_GET['check'] && $_GET['inajax']) {
			$result = C::m('#duceapp_remostore#duceapp_oss', $this->serverName)->exec('checkRes');
			$message = ($result[0] ? '<div style="font-size:14px;line-height:28px;color:#2bbe51;">'.duceapp_cplang('server_upload_succeed').'&nbsp; <img src="source/plugin/duceapp_remostore/static/image/right.png" style="height:16px;margin-top:-2px;vertical-align:middle"></div>' : '<div style="font-size:14px;line-height:28px;color:#dd3e00;">'.duceapp_cplang('server_upload_failed').'&nbsp; <img src="source/plugin/duceapp_remostore/static/image/error.png" style="height:16px;margin-top:-2px;vertical-align:middle"></div>').($result[2] ? '<div style="font-size:14px;line-height:28px;color:#2bbe51;">'.duceapp_cplang('server_remourl_succeed').'&nbsp;  <img src="source/plugin/duceapp_remostore/static/image/right.png" style="height:16px;margin-top:-2px;vertical-align:middle"></div>' : '<div style="font-size:14px;line-height:28px;color:#dd3e00;">'.duceapp_cplang('server_remourl_failed').'&nbsp; <img src="source/plugin/duceapp_remostore/static/image/error.png" style="height:16px;margin-top:-2px;vertical-align:middle"></div></div>');
			ajaxshowheader();
			echo '<script type="text/javascript" reload="1">
			duceapp_prompt("'.addslashes($message).'", {w:450});
			</script>';
			ajaxshowfooter();
		}

		if ($this->componvar['bucket']) {
			if (!preg_match('/^[a-z0-9\-]+$/', $this->componvar['bucket']) || preg_match('/^\-|\-$/', $this->componvar['bucket'])) {
				duceapp_error('bucket_invalid');
			}
			$default = '';
			$select = '<br />'.duceapp_cplang('region_0').'<select name="setting[region]" style="min-width:200px;">';
			foreach($this->regions as $key => $domain) {
				if (!$default || $key == $this->componvar['region']) {
					$default = $key;
				}
				$select .= '<option value="'.$key.'"'.($key == $this->componvar['region'] ? ' selected' : '').'>'.duceapp_cplang('region_'.$key).'</option>';
			}
			$select .= '</select><br />';

			$this->componvar = C::m('#duceapp_remostore#duceapp_oss', $this->serverName)->bucketCheck($this->componvar, $this->redirect, $select, $this);

			$this->componvar['remourl'] = preg_replace('/\/+$/', '', $this->componvar['remourl']).'/';

			if ($this->setting['ossapi'] == $this->serverName) {
				$this->setting['attachurl'] = $this->componvar['remourl'].$this->setting['basedir'];
			}

			C::m('#duceapp_remostore#duceapp_oss', $this->serverName)->exec('setCors');

			if (intval($_GET['setting']['setossapi'])) {
				$this->setting['ossapi'] = $this->serverName;
			}
		}

		duceapp_succeed();
	}
	
	public function domain($config, $bucket = null) {
		if ((empty($config['domain']) || $config['region'] != $bucket['region']) && $bucket) {
			$config['region'] = $bucket['region'];
			$config['domain'] = $this->regions[$bucket['region']];
		}
		return $config;
	}

	public function created($config) {
		$config['domain'] = '';
		return $this->domain($config, array('region' => $_GET['setting']['region']));
	}
}