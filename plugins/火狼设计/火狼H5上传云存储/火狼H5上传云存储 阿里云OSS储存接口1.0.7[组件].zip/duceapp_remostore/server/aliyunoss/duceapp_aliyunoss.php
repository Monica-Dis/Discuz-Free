<?php

/**
 * Copyright (c) 2011 by dism.taobao.com
 * Author: Hoolan Chan
 * Created: 2021-07-20
 * Version: 3.10715
 * Date: 2021-08-24 04:43:51
 * File: duceapp_aliyunoss.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

use OSS\OssClient;

class duceapp_aliyunoss extends duceapp_ossbase
{
	public function __construct($config) {
		$config['endpoint'] = $config['endpoint'] ? $config['endpoint'] : 'oss-cn-hangzhou.aliyuncs.com';
		$this->config = $config;
		$this->bucket = $config['bucket'];
		$this->basedir = $config['basedir'];
		$this->client = new OSS\OssClient($config['accesskey'], $config['secretkey'], $config['endpoint']);
	}

	public function createBucket($bucket) {
		if (!defined('IN_ADMINCP')) {
			return;
		}
		try {
			$options = array(
        		OssClient::OSS_STORAGE => OssClient::OSS_STORAGE_IA
    		);
			$this->client->createBucket($bucket, OssClient::OSS_ACL_TYPE_PUBLIC_READ, $options);
			$this->bucket = $bucket;
		} catch(Exception $e) {
			if ($this->config['debug']) {
				throw(new OSS\Core\OssException($e->getMessage()));
			}
            return 0;
        }
		return 1;
	}

	public function bucketExist($bucket) {
		try {
			$res = $this->client->doesBucketExist($bucket);
			return $res ? $this->config['endpoint'] : false;
		} catch(Exception $e) {
			if ($this->config['debug']) {
				throw(new OSS\Core\OssException($e->getMessage()));
			}
            return 0;
        }
	}

	public function checkRes() {
		try {
			$res = array();
			$res[0] = $this->client->putObject($this->bucket, 'test.txt', 'test', array(
				OssClient::OSS_HEADERS => array(
					'x-oss-object-acl' => 'public-read',
				),
			));
			$file = __DIR__ . '/test.txt';
			$this->client->getObject($this->bucket, 'test.txt', array(
				'fileDownload' => $file,
			));
			if (file_exists($file)) {
				$res[1] = 1;
				@unlink($file);
			}
			$content = $this->fileSock($this->config['remourl'].'test.txt');
			if ($content) {
				$res[2] = 1;
			}
			$res[0] && $this->client->deleteObject($this->bucket, 'test.txt');
			return $res;
		} catch(Exception $e) {
			throw(new OSS\Core\OssException($e->getMessage()));
		}
	}

	public function getReferer() {
		try {
			$referer = $this->client->getBucketReferer($this->bucket);
			return array($referer->getRefererList(), $referer->isAllowEmptyReferer());
		} catch(Exception $e) {
			if ($this->config['debug']) {
				throw(new OSS\Core\OssException($e->getMessage()));
			}
			return array();
		}
	}

	public function setReferer() {
		$args = func_get_args();
		$domains = array();
		if (!empty($args[0])) {
			foreach(explode("\n", $args[0]) as $v) {
				if (trim($v)) {
					$domains[] = trim($v);
				}
			}			
		}
		$rc = new OSS\Model\RefererConfig();
		$rc->setAllowEmptyReferer($domains && $args[1] ? true : false);
		if ($domains) {
			if (!in_array('*aliyun.com*', $domains)) {
				$rc->addReferer('*aliyun.com*');
			}
			if (!in_array('*'.$_SERVER['HTTP_HOST'].'*', $domains)) {
				$rc->addReferer('*'.$_SERVER['HTTP_HOST'].'*');
			}
			foreach($domains as $item) {
				$rc->addReferer($item);
			}
		}
		$this->client->putBucketReferer($this->bucket, $rc);
	}

	public function setCors() {
		$corsConfig = new OSS\Model\CorsConfig();
		$rule = new OSS\Model\CorsRule();
		$rule->addAllowedOrigin("*");
		$rule->addAllowedMethod("POST");
		$rule->addAllowedMethod("GET");
		$rule->setMaxAgeSeconds(0);
		$corsConfig->addRule($rule);
		try {
			$this->client->putBucketCors($this->bucket, $corsConfig);
		} catch (Exception $e){
			return 0;
		}
		return 1;
	}	

	public function objectExists($object) {
		try {
			$ret = $this->client->doesObjectExist($this->bucket, $this->basedir.$object);
            return $ret ? $this->config['remourl'].$this->basedir.$object : 0;
        } catch(Exception $e) {
            return 0;
        }
	}

	public function getFileslist($prefix = '', $marker = '', $limit = 100, $delimiter = '') {
		$res = array(
			'marker' => $marker,
			'run' => 0,
			'items' => array(),
		);
		while (true) {
			$options = array(
				'delimiter' => $delimiter,
				'prefix' => $prefix,
				'max-keys' => $limit > 0 ? $limit : 100,
				'marker' => $res['marker'],
			);
			try {
				$listObjectInfo = $this->client->listObjects($this->bucket, $options);
			} catch (Exception $e) {
				return array();
			}
			$res['marker'] = $listObjectInfo->getNextMarker();
			$objects = $listObjectInfo->getObjectList();
			if (!empty($objects)) {
				foreach ($objects as $object) {
					$res['items'][] = array(
						'key' => $object->getKey(),
						'size' => $object->getSize(),
						'filemtime' => strtotime($object->getLastModified()),
					);
				}
			}
			$res['run']++;
			if ($limit > 0 || empty($res['marker'])) {
				break;
			}
		}
		return $res;
	}

	public function imageStyle($style) {
		if (empty($style)) {
			return '';
		}
		return 'x-oss-process='.$style;
    }

	public function uploadFile($file, $object, $Acl = null) {
		try {
			if (!file_exists($file)) {
				return 0;
			}
			$this->client->multiuploadFile($this->bucket, $this->basedir.$object, $file);
			if ($Acl === null) {
				$Acl = $this->getAcl($file);
			}
			if ($Acl) {
				$Acl = $Acl == 'public' ? 'public-read' : $Acl;
				$this->client->putObjectAcl($this->bucket, $this->basedir.$object, $Acl);
			}
		} catch (Exception $e) {
			if ($this->config['debug']) {
				throw(new OSS\Core\OssException($e->getMessage()));
			}
			return 0;
		}
		return 1;
	}

	public function uploadData($data, $object, $Acl = null, $fread = false) {
		try {
			$ret = 0;
			if ($fread) {
				$data = $this->fileSock($data);
			}
			if (empty($data)) {
				return 0;
			}
			if ($Acl === null) {
				$Acl = $this->getAcl($object);
			}
			$Acl = $Acl == 'public' || $Acl == 'public-read' ? 'public-read' : 'private';
			$options = array(
				OssClient::OSS_HEADERS => array(
					'x-oss-object-acl' => $Acl,
				),
			);
			$ret = $this->client->putObject($this->bucket, $this->basedir.$object, $data, $options);
		} catch (Exception $e) {
			if ($this->config['debug']) {
				throw(new OSS\Core\OssException($e->getMessage()));
			}
			return 0;
		}
		return $ret;
	}

	public function setAcl($object, $Acl = null) {
		try {
			$Acl = $Acl == 'public' || $Acl == 'public-read' ? 'public-read' : $Acl;
			if ($Acl) {
				$this->client->putObjectAcl($this->bucket, $this->basedir.$object, $Acl);
			}
		} catch (Exception $e) {
			if ($this->config['debug']) {
				throw(new OSS\Core\OssException($e->getMessage()));
			}
			return 0;
		}
		return 1;       
	}

	public function renameObject($oldObject, $newObject, $MimeType = null) {
		try {
			if ($this->client->copyObject($this->bucket, $this->basedir.$oldObject, $this->bucket, $this->basedir.$newObject)) {
				$this->client->deleteObject($this->bucket, $this->basedir.$oldObject);
			}
		} catch (Exception $e) {
			if ($this->config['debug']) {
				throw(new OSS\Core\OssException($e->getMessage()));
			}
			return 0;
		}
		return 1;
	}

	public function downFile($file, $object) {
		try {
			$options = array(
				OssClient::OSS_FILE_DOWNLOAD => $file,
			);
			$this->client->getObject($this->bucket, $this->basedir.$object, $options);
		} catch (Exception $e) {
			if ($this->config['debug']) {
				throw(new OSS\Core\OssException($e->getMessage()));
			}
			return 0;
		}
		return 1;
	}

	public function deleteFile($objects) {
		try {
			if (is_array($objects)) {
				foreach($objects as $i => $object) {
					$objects[$i] = $this->basedir.$object;
				}
				$this->client->deleteObjects($this->bucket, $objects);
			} else {
				$this->client->deleteObject($this->bucket, $this->basedir.$objects);
			}
		} catch (Exception $e) {
			if ($this->config['debug']) {
				throw(new OSS\Core\OssException($e->getMessage()));
			}
			return 0;
		}
		return 1;
	}

	public function getPolicy($dir, $object, $length = 3048576000) {
		$accesskey = $this->config['accesskey'];
		$secretkey = $this->config['secretkey'];     
		$host = $this->config['remourl'];
		$dir = $this->basedir.$dir;

		$expire = time() + 300;  

		$policy = array(
			'expiration' => $this->gmt_iso8601($expire), 
			'conditions' => array(
				array('content-length-range', 0, $length),
			),
		);

		$policyBase64 = base64_encode(json_encode($policy));
		$message = $policyBase64;
		$signature = base64_encode(hash_hmac('sha1', $message, $secretkey, true));

		$response = array(
			'accesskey' => $accesskey,
			'policy' => $policyBase64,
			'signature' => $signature,
			'expire' => $expire,
			'dir' => $dir,
			'object' => $object,
		);	
		return json_encode($response);
	}

	public function signUrl($object, $filename = '', $expire = 3600) {
		empty($expire) && ($expire = 3600);
		$url = '';
		try {
			$object = $this->basedir.$object;
			if (!empty($filename)) {
				$meta = $this->client->getObjectMeta($this->bucket, $object);
				if (!isset($meta['x-oss-meta-filename']) || 
					$meta['x-oss-meta-filename'] != $filename  || 
					(fileext($filename) == 'mp4' && $meta['content-type'] != 'video/mp4')) {
					$filename = rawurldecode(diconv($filename, CHARSET, 'utf8'));
					$headers = array(
						'Content-Disposition' => "attachment; filename=\"$filename\";filename*=utf-8''$filename",
						'x-oss-meta-filename' => $filename,
						'x-oss-metadata-directive' => 'REPLACE',
					);
					if (fileext($filename) == 'mp4') {
						$headers['Content-Type'] = 'video/mp4';
					}
					$copyOptions = array(
						'headers' =>  $headers,
					);
					$this->client->copyObject($this->bucket, $object, $this->bucket, $object, $copyOptions);
				}
			}
			$url = $this->client->signUrl($this->bucket, $object, $expire);
			$url = explode('?', $url);
			$url = $this->config['remourl'].$object.($url[1] ? '?'.$url[1] : '');
			$url = str_replace('-internal', '', $url);
		} catch (Exception $e) {
			if ($this->config['debug']) {
				throw(new OSS\Core\OssException($e->getMessage()));
			}
			return 0;
		}
		return $url;
	}

	public function getData($object) {
		if (!$this->client->doesObjectExist($this->bucket, $object)) {
			return null;
		}
		$res = $this->client->getObjectMeta($this->bucket, $object);
		$data = array();
		$data['object'] = strpos($object, $this->basedir) === 0 ? substr($object, strlen($this->basedir)) : $object;
		$data['size'] = $res['content-length'];
		$data['height'] = 0;
		$data['width'] = 0;
		if (strpos($res['content-type'], 'image') !== FALSE) {
			$options = array(
				OssClient::OSS_PROCESS => 'image/info'
			);
			$res = $this->client->getObject($this->bucket, $object, $options);
			$res = json_decode($res, true);
			$data['height'] = $res['ImageHeight']['value'];
			$data['width'] = $res['ImageWidth']['value'];
		}
		return $data;
	}
}