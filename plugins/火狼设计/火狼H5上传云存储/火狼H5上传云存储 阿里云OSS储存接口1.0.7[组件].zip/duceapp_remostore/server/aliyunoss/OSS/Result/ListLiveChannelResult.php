<?php

/**
 * Copyright (c) 2011 by dism.taobao.com
 * Author: Hoolan Chan
 * Created: 2021-06-05
 * Version: 3.91115
 * Date: 2021-08-24 04:43:51
 * File: ListLiveChannelResult.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

namespace OSS\Result;

use OSS\Model\LiveChannelListInfo;

class ListLiveChannelResult extends Result
{
    protected function parseDataFromResponse()
    {
        $content = $this->rawResponse->body;
        $channelList = new LiveChannelListInfo();
        $channelList->parseFromXml($content);
        return $channelList;
    }
}