<?php

/**
 * Copyright (c) 2011 by dism.taobao.com
 * Author: Hoolan Chan
 * Created: 2021-07-20
 * Version: 3.10716
 * Date: 2021-08-24 04:43:51
 * File: lang_aliyunoss.php
 * PHP library for duceapp - Support
 * - Documentation and latest version
 *       http://dism.taobao.com/
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$duceapp_compon_lang = array(
	'appver' => '1.0.7',
	'menu_api' => 'oss',
	'menu_order' => 0,
	'menu_title' => '阿里云OSS',
	'css' => 1,

	'anchors' => array(
		'basic' => array('real' => 2, 'title' => '接口参数'),
		'referer' => array('real' => 2, 'title' => '防盗链'),
	),

	'tipval' => array(
		'bucket' => $_G['cache']['duceapp_remostore']['server']['aliyunoss']['bucket'],
		'endpoint' => str_replace('.aliyuncs.com', '', $_G['cache']['duceapp_remostore']['server']['aliyunoss']['endpoint']),
	),

	'accesskey' => 'Access Key ID',
	'accesskey_comment' => '阿里云<a href="https://ram.console.aliyun.com/manage/ak" target="_blank">AccessKey 管理界面</a>获取',
	'secretkey' => 'Access Key Secret',
	'secretkey_comment' => '阿里云<a href="https://ram.console.aliyun.com/manage/ak" target="_blank">AccessKey 管理界面</a>获取',
	'bucket' => '存储空间(Bucket)名称',
	'bucket_comment' => '填写对象存储空间 Bucket 名称，如果 Bucket 不存在，提交后可创建',
	'referer' => '防盗链 HTTP Referer 白名单',
	'referer_comment' => 'Referer为域名和IP地址，支持通配符星号（*）和问号（?），多个Referer以换行分隔，示例：*.duceapp.com',
	'referer_allowempty' => '允许空 Referer',
	'endpoint' => '访问节点(EndPoint)外网',
	'endpoint_comment' => '阿里云对象储存 / <u>Bucket概况</u> / <u>访问域名</u> / Endpoint（地域节点）外网地址，示例：oss-cn-hangzhou.aliyuncs.com',
	'endpoint_region' => '选择地域：',
	'endpoint_cn-hangzhou' => '华东1（杭州）',
	'endpoint_cn-shanghai' => '华东2（上海）',
	'endpoint_cn-qingdao' => '华北1（青岛）',
	'endpoint_cn-beijing' => '华北2（北京）',
	'endpoint_cn-zhangjiakou' => '华北3（张家口）',
	'endpoint_cn-huhehaote' => '华北5（呼和浩特）',
	'endpoint_cn-wulanchabu' => '华北6（乌兰察布）',
	'endpoint_cn-shenzhen' => '华南1（深圳）',
	'endpoint_cn-heyuan' => '华南2（河源）',
	'endpoint_cn-guangzhou' => '华南3（广州）',
	'endpoint_cn-chengdu' => '西南1（成都）',
	'endpoint_cn-hongkong' => '中国（香港）',
	'endpoint_ap-southeast-1' => '新加坡',
	'endpoint_ap-southeast-2' => '澳大利亚（悉尼）',
	'endpoint_ap-southeast-3' => '马来西亚（吉隆坡）',
	'endpoint_ap-southeast-5' => '印度尼西亚（雅加达）',
	'endpoint_ap-northeast-1' => '日本（东京）',
	'endpoint_ap-south-1' => '印度（孟买）',
	'endpoint_eu-central-1' => '德国（法兰克福）',
	'endpoint_eu-west-1' => '英国（伦敦）',
	'endpoint_us-west-1' => '美国（硅谷）',
	'endpoint_us-east-1' => '美国（弗吉尼亚）',
	'endpoint_me-east-1' => '阿联酋（迪拜）',
	'endpoint_emptyerr' => '访问节点(EndPoint)不能为空',
	'domain' => '存储空间(Bucket)域名外网',
	'domain_comment' => '阿里云对象储存 / <u>Bucket概况</u> / <u>访问域名</u> / Bucket 域名外网地址',
	'remourl' => '存储空间(Bucket)访问网址',
	'remourl_comment' => '填写“http(s)”开头的Bucket访问网址，阿里云对象储存 / <u>Bucket名称</u> / <u>传输管理</u> / <u>域名管理</u> / <u>绑定域名</u> 或 <u>Bucket概况</u> / <u>访问域名</u> / Bucket 域名外网地址',
	'imagestyle' => '图片处理样式',
	'imagestyle_comment' => '可给上传的图片进行压缩、添加水印等操作，阿里云对象储存 / <u>Bucket名称</u> / <u>数据处理</u> / 图片处理，拷贝样式代码',
	'imgStyleTips' => '<b>阿里云OSS，<a href="https://oss.console.aliyun.com/bucket/'.str_replace('.aliyuncs.com', '', $_G['cache']['duceapp_remostore']['server']['aliyunoss']['endpoint']).'/'.$_G['cache']['duceapp_remostore']['server']['aliyunoss']['bucket'].'/process/img" target="_blank">图片样式设置</a>，<a href="https://help.aliyun.com/document_detail/204523.html" target="_blank">设置教程</a></b>',
);