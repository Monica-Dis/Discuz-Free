<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zpl_car/helper.class.php';

global $_G;
loadcache(['zpl_car_langs']);
$zclangs = $_G['cache']['zpl_car_langs'];

$mpurl = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_browserecord';

$intkeys = array('uid');
$strkeys = array();
$randkeys = array();
$likekeys = array('username', 'ip');
$results = getwheres($intkeys, $strkeys, $randkeys, $likekeys, 'br.');
foreach ($likekeys as $k) {
    $_GET[$k] = dhtmlspecialchars($_GET[$k]);
}
$wherearr = $results['wherearr'];
$mpurl .= '&' . implode('&', $results['urls']);
if ($_GET['dateline1']) {
    $wherearr[] = "br.dateline >= '" . strtotime($_GET['dateline1']) . "'";
    $mpurl .= '&dateline1=' . $_GET['dateline1'];
}
if ($_GET['dateline2']) {
    $wherearr[] = "br.dateline <= '" . strtotime($_GET['dateline2']) . "'";
    $mpurl .= '&dateline2=' . $_GET['dateline2'];
}
$wheresql = empty($wherearr) ? '1' : implode(' AND ', $wherearr);

$ppp = 10;
$page = max(1, intval($_GET['page']));
$count = C::t('#zpl_car#zpl_car_browserecord')->fetch_countall_by_search($wheresql);
$multipage = multi($count, $ppp, $page, $mpurl);

$searchlang = array();
$keys = array('search', 'username', 'uid', 'car_browserecord_dateline', 'car_browserecord_ip');
foreach ($keys as $key) {
    if (substr($key, 0, 4) == 'car_') {
        $searchlang[$key] = $zclangs['zclang_' . $key];
    } else {
        $searchlang[$key] = cplang($key);
    }
}

$adminhiddens = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_browserecord';
parse_str($adminhiddens, $arrparams);
$hiddenhtml = '';
foreach ($arrparams as $key => $value) {
    $hiddenhtml .= '<input type="hidden" name="' . $key . '" value="' . $value . '">';
}

echo <<<SEARCH
<form method="get" autocomplete="off" action="">
    <table cellspacing="3" cellpadding="3">
        <tr>
            <th>$searchlang[username]</th><td><input type="text" class="txt" name="username" value="$_GET[username]"></td>
            <th>UID</th><td><input type="text" class="txt" name="uid" value="$_GET[uid]"></td>
            <th>$searchlang[car_browserecord_dateline]</th><td><input type="text" name="dateline1" value="$_GET[dateline1]" size="10" onclick="showcalendar(event, this)"> ~ <input type="text" name="dateline2" value="$_GET[dateline2]" size="10" onclick="showcalendar(event, this)"></td>
            <th>$searchlang[car_browserecord_ip]</th><td><input type="text" class="txt" name="ip" value="$_GET[ip]"></td>
            <th><td>$hiddenhtml<input type="submit" name="searchsubmit" value="$searchlang[search]" class="btn"></td></th>
        </tr>
    </table>
</form>
<script type="text/javascript" src="static/js/calendar.js"></script>
SEARCH;

showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_browserecord&page=' . $page, 'enctype');
showtableheader($zclangs['zclang_car_browserecord_list']);
$subtitle = array('car_browserecord_cimgname', 'car_browserecord_user', 'car_browserecord_dateline', 'car_browserecord_ip');
foreach ($subtitle as $key => $value) {
    if ($value) {
        $subtitle[$key] = $zclangs['zclang_' . $value];
    }
}
showsubtitle($subtitle);
$rows = C::t('#zpl_car#zpl_car_browserecord')->fetch_countall_by_search($wheresql, 0, $ppp, $page);
foreach ($rows as $row) {
    showtablerow('', array(), array(
        '<div style="display: flex; align-items: center">' . ($row['image'] ? '<img src="' . helper::gethandledurl($row['image']) . '" style="width: 40px; height: 30px">&nbsp;' : '') . $row['bname'] . ' ' . $row['sname'] . ' ' . $row['cartype'] . '</div>',
        $row['username'] . '/' . $row['uid'],
        date('Y-m-d H:i:s', $row['dateline']),
        $row['ip'],
    ));
}
showsubmit('', '', '', '', $multipage);
showtablefooter(); /*dism �� taobao �� com*/
showformfooter();

?>