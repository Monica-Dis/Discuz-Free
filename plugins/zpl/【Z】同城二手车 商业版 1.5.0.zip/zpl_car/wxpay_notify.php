<?php

chdir('../../../');

require_once 'source/class/class_core.php';

C::app()->init();

require_once DISCUZ_ROOT . './source/plugin/zpl_car/helper.class.php';

if (CHARSET == 'gbk') {
    require_once DISCUZ_ROOT . './source/plugin/zpl_car/libraries/wxpay/gbk/lib/WxPay.Api.php';
    require_once DISCUZ_ROOT . './source/plugin/zpl_car/libraries/wxpay/gbk/lib/WxPay.Notify.php';
    require_once DISCUZ_ROOT . './source/plugin/zpl_car/libraries/wxpay/gbk/example/WxPay.Config.php';
} else {
    require_once DISCUZ_ROOT . './source/plugin/zpl_car/libraries/wxpay/utf8/lib/WxPay.Api.php';
    require_once DISCUZ_ROOT . './source/plugin/zpl_car/libraries/wxpay/utf8/lib/WxPay.Notify.php';
    require_once DISCUZ_ROOT . './source/plugin/zpl_car/libraries/wxpay/utf8/example/WxPay.Config.php';
}

class PayNotifyCallBack extends WxPayNotify
{
    public function Queryorder($transaction_id)
    {
        $input = new WxPayOrderQuery();
        $input->SetTransaction_id($transaction_id);
        $config = new WxPayConfig();
        $result = WxPayApi::orderQuery($config, $input);
        if (array_key_exists("return_code", $result)
            && array_key_exists("result_code", $result)
            && $result["return_code"] == "SUCCESS"
            && $result["result_code"] == "SUCCESS") {
            return true;
        }
        return false;
    }

    public function LogAfterProcess($xmlData)
    {
        return;
    }

    public function NotifyProcess($objData, $config, &$msg)
    {
        $data = $objData->GetValues();
        if (!array_key_exists("return_code", $data) || (array_key_exists("return_code", $data) && $data['return_code'] != "SUCCESS")) {
            $msg = '';
            runlog('pluginzplcarwxpay', CHARSET == 'gbk' ? iconv('UTF-8', 'GBK', json_encode($data)) : json_encode($data));
            return false;
        }
        if (!array_key_exists("transaction_id", $data)) {
            $msg = '';
            runlog('pluginzplcarwxpay', CHARSET == 'gbk' ? iconv('UTF-8', 'GBK', json_encode($data)) : json_encode($data));
            return false;
        }

        try {
            $checkResult = $objData->CheckSign($config);
            if ($checkResult == false) {
                $msg = '';
                runlog('pluginzplcarwxpay', 'check sign fail');
                return false;
            }
        } catch (Exception $e) {
            $msg = '';
            runlog('pluginzplcarwxpay', 'check sign fail');
            return false;
        }

        if (!$this->Queryorder($data["transaction_id"])) {
            $msg = '';
            runlog('pluginzplcarwxpay', 'query order fail');
            return false;
        }

        // handle business
        $order = C::t('#zpl_car#zpl_car_order')->fetch_by_orderno($data['out_trade_no'], 10);
        if ($order) {
            if (in_array($order['type'], array(helper::$ORDER_TYPE_GRFB, helper::$ORDER_TYPE_SJFB))) {
                C::t('#zpl_car#zpl_car_order')->update($order['orderid'], array(
                    'tradeno' => $data['transaction_id'],
                    'status' => 20,
                    'paytime' => strtotime($data['time_end']),
                ));
                if ($order['cid']) {
                    C::t('#zpl_car#zpl_car')->update($order['cid'], array(
                        'paystatus' => 1,
                        'updatetime' => time(),
                    ));
                }
            } elseif ($order['type'] == helper::$ORDER_TYPE_SJRZ) {
                C::t('#zpl_car#zpl_car_order')->update($order['orderid'], array(
                    'tradeno' => $data['transaction_id'],
                    'status' => 20,
                    'paytime' => strtotime($data['time_end']),
                ));
                if ($order['storeid']) {
                    C::t('#zpl_car#zpl_car_store')->update($order['storeid'], array(
                        'paystatus' => 1,
                        'updatetime' => time(),
                    ));
                }
            } elseif ($order['type'] == helper::$ORDER_TYPE_ZDCL) {
                C::t('#zpl_car#zpl_car_order')->update($order['orderid'], array(
                    'tradeno' => $data['transaction_id'],
                    'status' => 20,
                    'paytime' => strtotime($data['time_end']),
                ));
                if ($order['cid']) {
                    $body = unserialize($order['body']);
                    $car = C::t('#zpl_car#zpl_car')->fetch($order['cid']);
                    if ($car['topexpireat'] <= time()) {
                        C::t('#zpl_car#zpl_car')->update($order['cid'], array(
                            'topexpireat' => time() + intval($body[0] * 24 * 3600),
                            'updatetime' => time(),
                        ));
                    } else {
                        C::t('#zpl_car#zpl_car')->update($order['cid'], array(
                            'topexpireat' => $car['topexpireat'] + intval($body[0] * 24 * 3600),
                            'updatetime' => time(),
                        ));
                    }
                }
            }
        }

        return true;
    }
}

$config = new WxPayConfig();
$notify = new PayNotifyCallBack();
$notify->Handle($config, false);

?>