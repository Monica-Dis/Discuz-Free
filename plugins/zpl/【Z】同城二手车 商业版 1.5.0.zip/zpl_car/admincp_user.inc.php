<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

global $_G;
loadcache(['zpl_car_langs']);
$zclangs = $_G['cache']['zpl_car_langs'];

$act = $_GET['act'];

if (!$act) {
    $mpurl = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_user';

    $intkeys = array('uid');
    $strkeys = array();
    $randkeys = array();
    $likekeys = array('username');
    $results = getwheres($intkeys, $strkeys, $randkeys, $likekeys);
    foreach ($likekeys as $k) {
        $_GET[$k] = dhtmlspecialchars($_GET[$k]);
    }
    $wherearr = $results['wherearr'];
    $wheresql = empty($wherearr) ? '1' : implode(' AND ', $wherearr);
    $mpurl .= '&' . implode('&', $results['urls']);

    $ppp = 10;
    $page = max(1, intval($_GET['page']));
    $count = C::t('#zpl_car#zpl_car_user')->fetch_count($wheresql);
    $multipage = multi($count, $ppp, $page, $mpurl);

    $searchlang = array();
    $keys = array('search', 'likesupport', 'uid', 'username');
    foreach ($keys as $key) {
        $searchlang[$key] = cplang($key);
    }

    $adminhiddens = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_user';
    parse_str($adminhiddens, $arrparams);
    $hiddenhtml = '';
    foreach ($arrparams as $key => $value) {
        $hiddenhtml .= '<input type="hidden" name="' . $key . '" value="' . $value . '">';
    }

    echo <<<SEARCH
<form method="get" autocomplete="off" action="">
    <table cellspacing="3" cellpadding="3">
        <tr>
            <th>$searchlang[username]</th><td><input type="text" class="txt" name="username" value="$_GET[username]"></td>
            <th>UID</th><td><input type="text" class="txt" name="uid" value="$_GET[uid]"></td>
            <th><td>$hiddenhtml<input type="submit" name="searchsubmit" value="$searchlang[search]" class="btn"></td></th>
        </tr>
    </table>
</form>
SEARCH;

    showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_user&page=' . $page, 'enctype');
    showtableheader($zclangs['zclang_car_user_list']);
    $subtitle = array('car_user', 'car_user_name', 'car_user_tel', 'car_user_address', 'car_user_desc', 'operation');
    foreach ($subtitle as $key => $value) {
        if ($value) {
            $subtitle[$key] = $zclangs['zclang_' . $value];
        }
    }
    showsubtitle($subtitle);
    $rows = C::t('#zpl_car#zpl_car_user')->fetch_all_by_conditions($wheresql, $ppp, $page);
    foreach ($rows as $row) {
        showtablerow('', array(), array(
            $row['username'] . '/' . $row['uid'],
            $row['name'],
            $row['tel'],
            $row['address'],
            $row['desc'],
            '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_user&act=edit&uid=' . $row['uid'] . '&page=' . $_GET['page'] . '">' . $zclangs['zclang_edit'] . '</a>',
        ));
    }
    showsubmit('', '', '', '', $multipage);
    showtablefooter(); /*dism �� taobao �� com*/
    showformfooter();
} elseif ($act == 'add') {
} elseif ($act == 'edit') {
    $user = C::t('#zpl_car#zpl_car_user')->fetch($_GET['uid']);
    if (!submitcheck('editsubmit')) {
        showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_user&act=edit&uid=' . $_GET['uid'] . '&page=' . $_GET['page'], 'enctype');
        showtableheader($zclangs['zclang_car_edit_user']);
        showsetting($zclangs['zclang_car_user_name'], 'name', $user['name'], 'text');
        showsetting($zclangs['zclang_car_user_tel'], 'tel', $user['tel'], 'text');
        showsetting($zclangs['zclang_car_user_address'], 'address', $user['address'], 'text');
        showsetting($zclangs['zclang_car_user_desc'], 'desc', $user['desc'], 'textarea');
        showsubmit('editsubmit');
        showtablefooter(); /*dism �� taobao �� com*/
        showformfooter();
    } else {
        $userdata = array();
        $userdata['name'] = $_POST['name'];
        $userdata['tel'] = $_POST['tel'];
        $userdata['address'] = $_POST['address'];
        $userdata['desc'] = $_POST['desc'];
        C::t('#zpl_car#zpl_car_user')->update($_GET['uid'], $userdata);

        cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_user&act=edit&uid=' . $_GET['uid'] . '&page=' . $_GET['page'], 'succeed');
    }
}
//From: Dism_taobao-com
?>