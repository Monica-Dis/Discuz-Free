<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zpl_car/helper.class.php';

loadcache(['plugin', 'zpl_car_brands', 'zpl_car_brand_list', 'zpl_car_langs']);
global $_G;

$vars = $_G['cache']['plugin']['zpl_car'];

$sorts = explode(PHP_EOL, $vars['car_sort']);

$brands = $_G['cache']['zpl_car_brands'];
$brands = $brands ? helper::index($brands, null, 'letter') : array();
$list = $_G['cache']['zpl_car_brand_list'];
$zclangs = $_G['cache']['zpl_car_langs'];
$bid = $_GET['bid'];
if (isset($list[$bid])) {
    $brand = $list[$bid]['brand'];
    $series = $list[$bid]['series'];
} else {
    $brand = array();
    $series = array();
}

$prices = explode(PHP_EOL, $vars['car_price']);

$levels = explode(PHP_EOL, $vars['car_level']);
$colors = explode(PHP_EOL, $vars['car_color']);
$gearboxs = explode(PHP_EOL, $vars['car_gearbox']);
$ages = explode(PHP_EOL, $vars['car_age']);
$kilometres = explode(PHP_EOL, $vars['car_kilometres']);
$displacements = explode(PHP_EOL, $vars['car_displacement']);
$countries = explode(PHP_EOL, $vars['car_countries']);
$fueltypes = explode(PHP_EOL, $vars['car_fueltype']);
$drives = explode(PHP_EOL, $vars['car_drive']);
$seats = explode(PHP_EOL, $vars['car_seats']);
$emissstandards = explode(PHP_EOL, $vars['car_emissstandard_filter']);

$labels = array();

// sorts
$pcsortshtml = '<ul>';
$sortshtml = '<div class="box-sort">';
$sortsarr = array();
foreach ($sorts as $k => $sort) {
    $sort = str_replace(["\r\n", "\n", "\r"], "", $sort);
    $sortarr = explode('=', $sort);
    $sortsarr[$sortarr[0]] = $sortarr[1];
    $pcsortshtml .= '<li class="c-sort-item"><a class="' . (trim($_GET['sort']) == $sortarr[0] ? 'active' : '') . ($k + 1 == count($sorts) ? ' last' : '') . '" data-queryname="sort" data-value="' . $sortarr[0] . '" href="javascript:;">' . $sortarr[1] . '</a></li>';
    $sortshtml .= '<a class="' . (trim($_GET['sort']) == $sortarr[0] ? 'active' : '') . '" data-queryname="sort" data-value="' . $sortarr[0] . '" href="javascript:;">' . $sortarr[1] . '</a>';
}
$pcsortshtml .= '</ul>';
$sortshtml .= '</div>';

// brands
$brandshtml = '<div class="box-brand"><div class="brand">';
$brandshtml .= '<div class="brand-list"><span class="brand-letter" id="brand-top">*</span><a class="all" data-queryname="bid" data-value="" href="javascript:;"><span class="brand-name" style="margin-left: .4rem">' . $zclangs['zclang_list_filter_allbrands'] . '</span></a></div>';
foreach ($brands as $group => $items) {
    $brandshtml .= '<div class="brand-list"><span class="brand-letter" id="' . $group . '1">' . $group . '</span>';
    if (is_array($items)) {
        foreach ($items as $item) {
            $brandshtml .= '<a class="brand-item" data-queryname="bid" data-value="' . $item['id'] . '" href="javascript:;"><img class="brand-icon" src="' . ($item['image'] ? helper::gethandledurl($item['image']) : $zclangs['zclang_no_image']) . '"><span class="brand-name">' . $item['name'] . '</span></a>';
        }
    }
    $brandshtml .= '</div>';
}
$brandshtml .= '</div></div>';
if ($_GET['bid']) {
    $labels['bid'] = C::t('#zpl_car#zpl_car_brand')->fetch_name($_GET['bid']);
}
if ($_GET['sid']) {
    $labels['sid'] = C::t('#zpl_car#zpl_car_brand')->fetch_name($_GET['sid']);
}

// prices
$pcpriceshtml = '<dl class="clearfix" style="float: left"><dt class="p-tit">' . $zclangs['zclang_price'] . '</dt>';
$priceshtml = '<div class="box-price">';
$pricesarr = array();
foreach ($prices as $k => $price) {
    $price = str_replace(["\r\n", "\n", "\r"], "", $price);
    $arr = explode('|', $price);
    $pricesarr[$arr[0]] = $arr[2];
    $pcpriceshtml .= '<dd class="' . ($k == 0 ? 'all' : 'item') . (trim($_GET['expectprice']) == $arr[0] ? ' active' : '') . '"><a data-queryname="expectprice" data-value="' . $arr[0] . '" href="javascript:;">' . ($k == 0 ? $zclangs['zclang_unlimited'] : $arr[2]) . '</a></dd>';
    $priceshtml .= '<a class="' . (trim($_GET['expectprice']) == $arr[0] ? 'active' : '') . '" data-queryname="expectprice" data-value="' . $arr[0] . '" href="javascript:;">' . $arr[2] . '</a>';
}
$pcpriceshtml .= '</dl>';
$priceshtml .= '</div>';
if ($_GET['expectprice']) {
    $labels['expectprice'] = $pricesarr[$_GET['expectprice']];
}

// more
$morearray = array();
$more = array(
    'carlevel' => array('name' => $zclangs['zclang_car_level_name'], 'items' => $levels),
    'appearance' => array('name' => $zclangs['zclang_car_color_name'], 'items' => $colors),
    'gearbox' => array('name' => $zclangs['zclang_car_gearbox_name'], 'items' => $gearboxs),
    'age' => array('name' => $zclangs['zclang_car_age_name'], 'items' => $ages),
    'apparentmileage' => array('name' => $zclangs['zclang_car_kilometres_name'], 'items' => $kilometres),
    'enginedis' => array('name' => $zclangs['zclang_car_displacement_name'], 'items' => $displacements),
    'country' => array('name' => $zclangs['zclang_car_countries_name'], 'items' => $countries),
    'enginefueltype' => array('name' => $zclangs['zclang_car_fueltype_name'], 'items' => $fueltypes),
    'tcbdrive' => array('name' => $zclangs['zclang_car_drive_name'], 'items' => $drives),
    'cbseats' => array('name' => $zclangs['zclang_car_seats_name'], 'items' => $seats),
    'engineemistand' => array('name' => $zclangs['zclang_car_emissstandard_filtername'], 'items' => $emissstandards)
);
$morehtml = '<div class="box-more">';
foreach ($more as $k => $v) {
    $morehtml .= '<div class="filter-section">';
    $morehtml .= '<h3 class="section-h">' . $v['name'] . '</h3>';
    $morehtml .= '<ul class="section-ul">';
    $itemarr = array();
    foreach ($v['items'] as $value) {
        $value = str_replace(["\r\n", "\n", "\r"], "", $value);
        $arr = explode('=', $value);
        $morearray[$k] = trim($_GET[$k]);
        if ($k == 'appearance') {
            if ($arr[1] == '#fff') {
                $morehtml .= '<li class="section-li"><a class="section-item' . (trim($_GET[$k]) == $arr[0] ? ' active' : '') . '" data-queryname="' . $k . '" data-value="' . $arr[0] . '" href="javascript:;"><span style="border: 1px solid #e1e1e1; background-color: #fff" class="color-v"></span> ' . $arr[2] . '</a></li>';
            } elseif ($arr[1] == 'multicolor') {
                $morehtml .= '<li class="section-li"><a class="section-item' . (trim($_GET[$k]) == $arr[0] ? ' active' : '') . '" data-queryname="' . $k . '" data-value="' . $arr[0] . '" href="javascript:;"><span style="background-position: -60px -48px;" class="color-v"><img style="width: 100%; height: 100%" src="source/plugin/zpl_car/assets/images/multicolor.png"></span> ' . $arr[2] . '</a></li>';
            } elseif ($arr[1] == 'other') {
                $morehtml .= '<li class="section-li"><a class="section-item' . (trim($_GET[$k]) == $arr[0] ? ' active' : '') . '" data-queryname="' . $k . '" data-value="' . $arr[0] . '" href="javascript:;"><span style="background-position: -78px -48px; border: 1px solid #ccc;" class="color-v"><img style="width: 100%; height: 100%" src="source/plugin/zpl_car/assets/images/othercolor.png"></span> ' . $arr[2] . '</a></li>';
            } else {
                $morehtml .= '<li class="section-li"><a class="section-item' . (trim($_GET[$k]) == $arr[0] ? ' active' : '') . '" data-queryname="' . $k . '" data-value="' . $arr[0] . '" href="javascript:;"><span style="background-color: ' . $arr[1] . '" class="color-v"></span> ' . $arr[2] . '</a></li>';
            }
            $itemarr[$arr[0]] = $arr[2];
        } else {
            $morehtml .= '<li class="section-li"><a class="section-item' . (trim($_GET[$k]) == $arr[0] ? ' active' : '') . '" data-queryname="' . $k . '" data-value="' . $arr[0] . '"  href="javascript:;">' . $arr[1] . '</a></li>';
            $itemarr[$arr[0]] = $arr[1];
        }
    }
    if ($_GET[$k]) {
        $labels[$k] = $itemarr[$_GET[$k]];
    }
    $morehtml .= '</ul></div>';
}
$brightspots = array(
    'insidedcyxxt' => $zclangs['zclang_car_dcyxxt'],
    'externalqjtc' => $zclangs['zclang_car_qjtc'],
    'insidegpsdhxt' => $zclangs['zclang_car_gpsdhxt'],
    'secuwysqdxt' => $zclangs['zclang_car_wysqdxt'],
    'secuwysjrxt' => $zclangs['zclang_car_wysjrxt'],
    'insidezpzy' => $zclangs['zclang_car_zpzy'],
    'insidedsxh' => $zclangs['zclang_car_dsxh'],
    'insidezktcsdp' => $zclangs['zclang_car_zktcsdp'],
    'insideczld' => $zclangs['zclang_car_czld'],
);
$morehtml .= '<div class="filter-section"><h3 class="section-h">' . $zclangs['zclang_car_brightspot_configname'] . '</h3><ul class="section-ul">';
foreach ($brightspots as $key => $value) {
    $morearray[$key] = trim($_GET[$key]);
    if ($_GET[$key]) {
        $labels[$key] = $value;
    }
    $morehtml .= '<li class="section-li-l"><a class="section-item ld-item' . (trim($_GET[$key]) == 1 ? ' active' : '') . '" data-queryname="' . $key . '" data-value="1" href="javascript:;">' . $value . '</a></li>';
}
$morehtml .= '</ul></div>';
$morehtml .= '</div>';
$morejson = helper_json::encode($morearray);

if ($_GET['new']) {
    $labels['new'] = $zclangs['zclang_new'];
}

// labellist
if ($labels) {
    $pclabellisthtml = '<div class="c-selected clearfix"><div class="tit">' . $zclangs['zclang_selected'] . '</div><div class="selected-area"><ul class="clearfix">';
    $labellisthtml = '<div class="weui-label-list">';
    foreach ($labels as $key => $value) {
        $pclabellisthtml .= '<li><a class="alb" data-queryname="' . $key . '" data-value="" href="javascript:;">' . $value . '<span class="clear-x">x</span></a></li>';
        $labellisthtml .= '<a class="alb" data-queryname="' . $key . '" data-value="" href="javascript:;"><label class="label b-default f-default">' . $value . ' <span class="icon icon-95"></span></label></a>';
    }
    $pclabellisthtml .= '<a class="reset" href="plugin.php?id=zpl_car:list">' . $zclangs['zclang_reset'] . '</a>';
    $labellisthtml .= '<a href="plugin.php?id=zpl_car:list"><label class="label b-red f-red">' . $zclangs['zclang_reset'] . '</label></a>';
    $pclabellisthtml .= '</ul></div></div>';
    $labellisthtml .= '</div>';
}

$queryarray = array();
foreach ($_GET as $key => $value) {
    if ($key != 'id' && $value) {
        $queryarray[$key] = $value;
    }
}
$urlpar = $queryarray ? '&' . http_build_query($queryarray) : '';

include_once template('zpl_car:list');

?>