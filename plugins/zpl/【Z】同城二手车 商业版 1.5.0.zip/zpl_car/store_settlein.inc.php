<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zpl_car/helper.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/wechat.lib.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/wechat.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/pay.class.php';

loadcache(['plugin', 'zpl_car_langs']);
global $_G;
$vars = $_G['cache']['plugin']['zpl_car'];
$zclangs = $_G['cache']['zpl_car_langs'];

$appid = $vars['wxappid'];
$appsecret = $vars['wxappsecret'];

// login
$returnurl = $_G['siteurl'] . './plugin.php?id=zpl_car:store_settlein';
if (empty($_G['uid'])) {
    $openwxlogin = $vars['openwxlogin'];

    if (helper::isweixin() && $openwxlogin == 1) {
        // WX login
        if (!isset($_GET['code'])) {
            $redirecturi = urlencode($returnurl);
            $wxurl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$appid}&redirect_uri={$redirecturi}&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";
            dheader('location: ' . $wxurl);
        } else {
            require_once libfile('function/member');

            $wechat_client = new WeChatClient($appid, $appsecret);

            $code = $_GET['code'];
            $tokeninfo = $wechat_client->getAccessTokenByCode($code);
            if ($tokeninfo['openid']) {
                $openid = $tokeninfo['openid'];
                $mp = C::t('#zpl_car#zpl_car_user_wxmp')->fetch_by_openid($openid);
                if ($mp) {
                    $member = getuserbyuid($mp['uid'], 1);
                    setloginstatus($member, 1296000);
                } else {
                    $uid = ZplWeChat::register(ZplWeChat::getnewname($openid), 1);
                    if ($uid) {
                        $data = array(
                            'uid' => $uid,
                            'openid' => $openid,
                        );
                        C::t('#zpl_car#zpl_car_user_wxmp')->insert($data);
                    }
                }
                dheader('location: ' . $returnurl);
            } else {
                // common login
                showmessage('not_loggedin', NULL, array(), array('login' => 1));
            }
        }
    } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX") !== false) {
        // MAGAPP login
        include_once template('zpl_car:mag_login');
        dexit();
    } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "QianFan") !== false) {
        // QFAPP login
        include_once template('zpl_car:qianfan_login');
        dexit();
    } else {
        // common login
        showmessage('not_loggedin', NULL, array(), array('login' => 1));
    }
}

$storesettleinopencheck = $vars['storesettleinopencheck'];
$storeopensettleinpay = $vars['storeopensettleinpay'];
$storesettleinpayamount = $vars['storesettleinpayamount'];
$storesettleinpayt = $vars['storesettleinpayt'];
$paytips = str_replace('{money}', '<span style="color: #f85d00"> ' . $storesettleinpayamount . ' </span>', $storesettleinpayt);
$paytips2 = str_replace('{money}', '<span style=\"color: #f85d00\"> ' . $storesettleinpayamount . ' </span>', $storesettleinpayt);

$store = C::t('#zpl_car#zpl_car_store')->fetch_by_uid($_G['uid']);
if ($store) {
    if (($storesettleinopencheck == 1 && $store['checkstatus'] == 1) &&
        (!$storeopensettleinpay || ($storeopensettleinpay == 1 && $store['paystatus'] == 1))
    ) {
        dheader('location: plugin.php?id=zpl_car:my');
    } elseif ((!$storesettleinopencheck || ($storesettleinopencheck == 1 && $store['checkstatus'] == 2)) &&
        (!$storeopensettleinpay || ($storeopensettleinpay == 1 && $store['paystatus'] == 1))
    ) {
        dheader('location: plugin.php?id=zpl_car:store_center');
    }
}

$wxjsconfig = helper::getwxjsconfig(
    $appid,
    $appsecret,
    $_G['scheme'] . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']
);

if (submitcheck('storeinfosubmit')) {
    $data = array(
        'name' => dhtmlspecialchars(trim($_POST['name'])),
        'image' => $_POST['image'],
        'idfront' => $_POST['idfront'],
        'idback' => $_POST['idback'],
        'idpeople' => $_POST['idpeople'],
        'businesslicense' => $_POST['businesslicense'],
        'tel' => dhtmlspecialchars(trim($_POST['tel'])),
        'address' => dhtmlspecialchars(trim($_POST['address'])),
        'desc' => dhtmlspecialchars(trim($_POST['desc'])),
    );
    foreach ($data as $value) {
        if (!$value) {
            echo '<script>parent.showerrmsg("' . $zclangs['zclang_required'] . '");parent.enableconfirmbtn();</script>';
            dexit();
        }
    }

    $data['uid'] = $_G['uid'];

    if ($storesettleinopencheck == 1) {
        $data['checkstatus'] = 1;
    } else {
        $data['checkstatus'] = 2;
    }

    if ($store) {
        if ($store['checkstatus'] == 2) {
            $data['checkstatus'] = 2;
        }
        $data['updatetime'] = time();
        C::t('#zpl_car#zpl_car_store')->update($store['storeid'], $data);
        $storeid = $store['storeid'];
    } else {
        $data['createtime'] = time();
        $data['updatetime'] = time();
        $storeid = C::t('#zpl_car#zpl_car_store')->insert($data, true);
    }

    if ((!$store || $store['paystatus'] == 0) && $storeopensettleinpay == 1) {
        if (in_array(helper::getenv(), ['MOBILE', 'PC'])) {
            $config = array(
                'env' => helper::getenv(),
                'title' => $zclangs['zclang_car_order_type_20'],
                'content' => $paytips2,
                'openwxpay' => $vars['openwxpay'],
                'openalipay' => $vars['openalipay'],
                'langchoose' => $zclangs['zclang_tpl_pay_choose'],
                'langwxpay' => $zclangs['zclang_tpl_wxpay'],
                'langalipay' => $zclangs['zclang_tpl_alipay'],
                'langconfirm' => $zclangs['zclang_tpl_confirm_pay'],
                'langsuccessmsg' => $zclangs['zclang_save_storeinfo_success'],
                'langajaxerror' => $zclangs['zclang_tpl_ajax_error'],
                'dataordertype' => helper::$ORDER_TYPE_SJRZ,
                'datastoreid' => $storeid,
                'databody' => '',
                'currenturl' => 'plugin.php?id=zpl_car:store_settlein',
                'redirecturl' => 'plugin.php?id=zpl_car:my',
            );
            $config = helper_json::encode($config);
            echo "<script>parent.otherpay('{$config}');parent.enableconfirmbtn()</script>";
        } else {
            $user = C::t('#zpl_car#zpl_car_user')->fetch($_G['uid']);
            $config = array(
                'env' => helper::getenv(),
                'orderno' => helper::generateorderno(),
                'amount' => helper::keeptwodecimal($vars['storesettleinpayamount']),
                'body' => CHARSET == 'gbk' ? iconv('GBK', 'UTF-8', $zclangs['zclang_car_order_type_20']) : $zclangs['zclang_car_order_type_20'],
                'openid' => $user['openid'],
            );
            $pay = new pay($config);
            $parameters = $pay->order();

            $orderdata = array(
                'orderno' => $pay->orderno,
                'uid' => $_G['uid'],
                'username' => $_G['username'],
                'paymentmethod' => $pay->paymentmethod,
                'status' => '10',
                'price' => $pay->amount,
                'type' => helper::$ORDER_TYPE_SJRZ,
                'createtime' => time(),
                'storeid' => $storeid,
                'ip' => $_G['clientip'],
                'body' => '',
            );
            C::t('#zpl_car#zpl_car_order')->insert($orderdata);

            if ($pay->err) {
                echo "<script>parent.showerrmsg('{$pay->errmsg}');parent.enableconfirmbtn();</script>";
            } else {
                $successmsg = $zclangs['zclang_save_storeinfo_success'];
                $ajaxerrmsg = $zclangs['zclang_tpl_ajax_error'];
                $redirecturl = 'plugin.php?id=zpl_car:my';
                echo "<script>parent.pay('{$pay->paymentmethod}', '{$parameters}', '{$pay->orderno}', '{$redirecturl}', '{$successmsg}', '{$ajaxerrmsg}');parent.enableconfirmbtn();</script>";
            }
        }
    } else {
        $storedata = array(
            'paystatus' => 1,
        );
        C::t('#zpl_car#zpl_car_store')->update($storeid, $storedata);
        echo '<script>parent.showsuccessmsg("' . $zclangs['zclang_save_storeinfo_success'] . '", 3000, true, "plugin.php?id=zpl_car:my");</script>';
    }
} else {
    if ($storeopensettleinpay == 1 && helper::isweixin()) {
        $tools = new JsApiPay();
        $openid = $tools->GetOpenid();
        if ($openid) {
            $user = C::t('#zpl_car#zpl_car_user')->fetch($_G['uid']);
            if ($user) {
                C::t('#zpl_car#zpl_car_user')->update($_G['uid'], array('openid' => $openid));
            } else {
                C::t('#zpl_car#zpl_car_user')->insert(array('uid' => $_G['uid'], 'openid' => $openid));
            }
        }
    }
}

if ($store) {
    $store['imageurl'] = helper::gethandledurl($store['image']);
    $store['idfronturl'] = helper::gethandledurl($store['idfront']);
    $store['idbackurl'] = helper::gethandledurl($store['idback']);
    $store['idpeopleurl'] = helper::gethandledurl($store['idpeople']);
    $store['businesslicenseurl'] = helper::gethandledurl($store['businesslicense']);
}

include_once template('zpl_car:store_ruzhu');

?>