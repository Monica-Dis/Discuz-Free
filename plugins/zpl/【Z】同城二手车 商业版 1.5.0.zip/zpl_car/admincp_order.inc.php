<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zpl_car/helper.class.php';

global $_G;
loadcache(['zpl_car_langs']);
$zclangs = $_G['cache']['zpl_car_langs'];

$mpurl = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_order';

$intkeys = array('uid');
$strkeys = array('orderno', 'tradeno');
$randkeys = array();
$likekeys = array('username');
$results = getwheres($intkeys, $strkeys, $randkeys, $likekeys);
foreach ($likekeys as $k) {
    $_GET[$k] = dhtmlspecialchars($_GET[$k]);
}
$wherearr = $results['wherearr'];
$mpurl .= '&' . implode('&', $results['urls']);
if ($_GET['createtime1']) {
    $wherearr[] = "createtime >= '" . strtotime($_GET['createtime1']) . "'";
    $mpurl .= '&createtime1=' . $_GET['createtime1'];
}
if ($_GET['createtime2']) {
    $wherearr[] = "createtime <= '" . strtotime($_GET['createtime2']) . "'";
    $mpurl .= '&createtime2=' . $_GET['createtime2'];
}
if ($_GET['paytime1']) {
    $wherearr[] = "paytime >= '" . strtotime($_GET['paytime1']) . "'";
    $mpurl .= '&paytime1=' . $_GET['paytime1'];
}
if ($_GET['paytime2']) {
    $wherearr[] = "paytime <= '" . strtotime($_GET['paytime2']) . "'";
    $mpurl .= '&paytime2=' . $_GET['paytime2'];
}
$wheresql = empty($wherearr) ? '1' : implode(' AND ', $wherearr);

$ppp = 10;
$page = max(1, intval($_GET['page']));
$count = C::t('#zpl_car#zpl_car_order')->fetch_count($wheresql);
$multipage = multi($count, $ppp, $page, $mpurl);

$searchlang = array();
$keys = array('search', 'likesupport', 'car_order_no', 'car_order_tradeno', 'uid', 'username', 'car_order_paytime', 'car_order_createtime');
foreach ($keys as $key) {
    if (substr($key, 0, 4) == 'car_') {
        $searchlang[$key] = $zclangs['zclang_' . $key];
    } else {
        $searchlang[$key] = cplang($key);
    }
}

$adminhiddens = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_order';
parse_str($adminhiddens, $arrparams);
$hiddenhtml = '';
foreach ($arrparams as $key => $value) {
    $hiddenhtml .= '<input type="hidden" name="' . $key . '" value="' . $value . '">';
}

echo <<<SEARCH
<form method="get" autocomplete="off" action="">
    <table cellspacing="3" cellpadding="3">
        <tr>
            <th>$searchlang[car_order_no]</th><td><input type="text" class="txt" name="orderno" value="$_GET[orderno]"></td>
            <th>$searchlang[car_order_tradeno]</th><td><input type="text" class="txt" name="tradeno" value="$_GET[tradeno]"></td>
            <th>$searchlang[username]</th><td><input type="text" class="txt" name="username" value="$_GET[username]"></td>
            <td>
                $hiddenhtml
                <input type="submit" name="searchsubmit" value="$searchlang[search]" class="btn">
            </td>
        </tr>
    </table>
</form>
<script type="text/javascript" src="static/js/calendar.js"></script>
SEARCH;

showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_order&page=' . $page, 'enctype');
showtableheader($zclangs['zclang_car_order_list']);
$subtitle = array('car_order_no', 'car_order_tradeno', 'car_order_user2',
    'car_order_paymentmethod', 'car_order_price2', 'car_order_status',
    'car_order_desc', 'car_order_paytime', 'car_order_createtime');
foreach ($subtitle as $key => $value) {
    if ($value) {
        $subtitle[$key] = $zclangs['zclang_' . $value];
    }
}
showsubtitle($subtitle);
$rows = C::t('#zpl_car#zpl_car_order')->fetch_all_by_conditions($wheresql, $ppp, $page);
foreach ($rows as $row) {
    if ($row['type'] == helper::$ORDER_TYPE_GRFB) {
        $desc = $zclangs['zclang_car_order_type_' . $row['type'] . '_2'] .
            ' | ' .
            $zclangs['zclang_car_cid'] .
            $zclangs['zclang_tpl_colon'] .
            $row['cid'];
    } elseif ($row['type'] == helper::$ORDER_TYPE_SJRZ) {
        $desc = $zclangs['zclang_car_order_type_20'] .
            ' | ' .
            $zclangs['zclang_car_store_storeid'] .
            $zclangs['zclang_tpl_colon'] .
            $row['storeid'];
    } elseif ($row['type'] == helper::$ORDER_TYPE_SJFB) {
        $desc = $zclangs['zclang_car_order_type_30'] .
            ' | ' .
            $zclangs['zclang_car_cid'] .
            $zclangs['zclang_tpl_colon'] .
            $row['cid'];
    } elseif ($row['type'] == helper::$ORDER_TYPE_ZDCL) {
        $body = unserialize($row['body']);
        $desc = $zclangs['zclang_car_order_type_40'] .
            ' | ' .
            $zclangs['zclang_car_cid'] .
            $zclangs['zclang_tpl_colon'] .
            $row['cid'] .
            ' | ' .
            $zclangs['zclang_car_store_storeid'] .
            $zclangs['zclang_tpl_colon'] .
            $row['storeid'] .
            ' | ' .
            $body[2];
    } else {
        $desc = '';
    }
    showtablerow('', array('', '', '', '', '', '', 'style="width: 300px"'), array(
        $row['orderno'],
        $row['tradeno'],
        $row['username'] . '/' . $row['uid'],
        $row['paymentmethod'],
        $row['price'] . ' ' . $zclangs['zclang_tpl_unit_yuan'],
        $zclangs['zclang_car_order_status_' . $row['status']],
        $desc,
        $row['paytime'] ? date('Y-m-d H:i:s', $row['paytime']) : '',
        date('Y-m-d H:i:s', $row['createtime']),
    ));
}
showsubmit('', '', '', '', $multipage);
showtablefooter(); /*dism �� taobao �� com*/
showformfooter();

?>