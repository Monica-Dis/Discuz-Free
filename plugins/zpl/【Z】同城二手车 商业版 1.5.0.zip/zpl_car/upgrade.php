<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_zpl_car_user_wxmp` (
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` char(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`)
) TYPE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_zpl_car_lang` (
  `ckey` varchar(255) NOT NULL DEFAULT '',
  `cvalue` text,
  PRIMARY KEY (`ckey`)
) TYPE=MyISAM;
EOF;
runquery($sql);

// zpl_car
$paystatusexisted = false;
$query = DB::query("SHOW COLUMNS FROM " . DB::table('zpl_car'));
while ($temp = DB::fetch($query)) {
    if ($temp['Field'] == 'paystatus') {
        $paystatusexisted = true;
        continue;
    }
}
$sql = !$paystatusexisted ? "ALTER TABLE " . DB::table('zpl_car') . " ADD COLUMN paystatus tinyint(1) unsigned NOT NULL default '0';\n" : '';
runquery($sql);

// zpl_car_config
$sql = "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secujsyqn` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secufjsqn` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secutyjczz` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secuaqdwxts` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secuetzyjk` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secucnzks` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secuwysqdxt` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secuwysjrxt` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secuabs` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secuesp` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insidezpfxp` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insidezpzy` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insidedgnfxp` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insidezktcsdp` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insidekt` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insidedsxh` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insidegpsdhxt` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insidedcyxxt` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insideczld` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `externalddcc` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `externalqjtc` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `externalddxhm` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `externalgyhbx` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `externalqhddcc` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `externalhys` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `lightingjgd` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `lightingddgdkt` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `lightingzdtd` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `lightingzxfzd` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `lightingqwd` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
runquery($sql);

// zpl_car_order
$magunionordernumexisted = false;
$appidexisted = false;
$mchidexisted = false;
$noteexisted = false;
$bodyexisted = false;
$query = DB::query("SHOW COLUMNS FROM " . DB::table('zpl_car_order'));
while ($temp = DB::fetch($query)) {
    if ($temp['Field'] == 'magunionordernum') {
        $magunionordernumexisted = true;
        continue;
    }
    if ($temp['Field'] == 'appid') {
        $appidexisted = true;
        continue;
    }
    if ($temp['Field'] == 'mchid') {
        $mchidexisted = true;
        continue;
    }
    if ($temp['Field'] == 'note') {
        $noteexisted = true;
        continue;
    }
    if ($temp['Field'] == 'body') {
        $bodyexisted = true;
        continue;
    }
}
$sql = $magunionordernumexisted ? "ALTER TABLE " . DB::table('zpl_car_order') . " DROP COLUMN `magunionordernum`;\n" : '';
$sql .= $appidexisted ? "ALTER TABLE " . DB::table('zpl_car_order') . " DROP COLUMN `appid`;\n" : '';
$sql .= $mchidexisted ? "ALTER TABLE " . DB::table('zpl_car_order') . " DROP COLUMN `mchid`;\n" : '';
$sql .= $noteexisted ? "ALTER TABLE " . DB::table('zpl_car_order') . " DROP COLUMN `note`;\n" : '';
$sql .= !$bodyexisted ? "ALTER TABLE " . DB::table('zpl_car_order') . " ADD COLUMN `body` text NOT NULL AFTER `ip`;\n" : '';
runquery($sql);

// zpl_car_user
$openidexisted = false;
$query = DB::query("SHOW COLUMNS FROM " . DB::table('zpl_car_user'));
while ($temp = DB::fetch($query)) {
    if ($temp['Field'] == 'openid') {
        $openidexisted = true;
        continue;
    }
}
$sql = $openidexisted ? "ALTER TABLE " . DB::table('zpl_car_user') . " DROP COLUMN `openid`;\n" : '';
runquery($sql);

// zpl_car_store
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_zpl_car_store` (
  `storeid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `tel` char(64) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `desc` text NOT NULL,
  `idfront` varchar(255) NOT NULL DEFAULT '',
  `idback` varchar(255) NOT NULL DEFAULT '',
  `idpeople` varchar(255) NOT NULL DEFAULT '',
  `businesslicense` varchar(255) NOT NULL DEFAULT '',
  `checkstatus` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `checkremarks` varchar(255) NOT NULL DEFAULT '',
  `createtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`storeid`)
) TYPE=MyISAM;
EOF;
runquery($sql);

// zpl_car
$storeidexisted = false;
$query = DB::query("SHOW COLUMNS FROM " . DB::table('zpl_car'));
while ($temp = DB::fetch($query)) {
    if ($temp['Field'] == 'storeid') {
        $storeidexisted = true;
        continue;
    }
}
$sql = !$storeidexisted ? "ALTER TABLE " . DB::table('zpl_car') . " ADD COLUMN `storeid`  int(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `uid`;\n" : '';
runquery($sql);

// zpl_car_browserecord
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_zpl_car_browserecord` (
  `brid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` char(15) NOT NULL DEFAULT '',
  `bdate` varchar(32) NOT NULL DEFAULT '',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(16) NOT NULL DEFAULT '',
  PRIMARY KEY (`brid`)
) TYPE=MyISAM;
EOF;
runquery($sql);

// zpl_car
$sql = "ALTER TABLE " . DB::table('zpl_car') . " MODIFY COLUMN `paystatus`  tinyint(1) UNSIGNED NOT NULL DEFAULT 0 AFTER `detailrecomm`;\n";
runquery($sql);

$viewsexisted = false;
$query = DB::query("SHOW COLUMNS FROM " . DB::table('zpl_car'));
while ($temp = DB::fetch($query)) {
    if ($temp['Field'] == 'views') {
        $viewsexisted = true;
        continue;
    }
}
$sql = !$viewsexisted ? "ALTER TABLE " . DB::table('zpl_car') . " ADD COLUMN `views`  int(10) NOT NULL DEFAULT 0 AFTER `paystatus`;\n" : '';
runquery($sql);

// zpl_car_user
$openidexisted = false;
$query = DB::query("SHOW COLUMNS FROM " . DB::table('zpl_car_user'));
while ($temp = DB::fetch($query)) {
    if ($temp['Field'] == 'openid') {
        $openidexisted = true;
        continue;
    }
}
$sql = !$openidexisted ? "ALTER TABLE " . DB::table('zpl_car_user') . " ADD COLUMN `openid`  char(64) NOT NULL DEFAULT '' AFTER `desc`;\n" : '';
runquery($sql);

// zpl_car_order
$tradetypeexisted = false;
$query = DB::query("SHOW COLUMNS FROM " . DB::table('zpl_car_order'));
while ($temp = DB::fetch($query)) {
    if ($temp['Field'] == 'tradetype') {
        $tradetypeexisted = true;
        continue;
    }
}
$sql = $tradetypeexisted ? "ALTER TABLE " . DB::table('zpl_car_order') . " DROP COLUMN `tradetype`;\n" : '';
runquery($sql);

$sql = "ALTER TABLE " . DB::table('zpl_car_order') . " MODIFY COLUMN `paymentmethod`  char(32) NOT NULL DEFAULT '' AFTER `username`;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_order') . " MODIFY COLUMN `status`  tinyint(2) UNSIGNED NOT NULL DEFAULT 0 AFTER `paymentmethod`;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_order') . " MODIFY COLUMN `price`  float(7,2) UNSIGNED NOT NULL DEFAULT 0.00 AFTER `status`;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_order') . " MODIFY COLUMN `type`  tinyint(3) UNSIGNED NOT NULL DEFAULT 0 AFTER `price`;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_order') . " MODIFY COLUMN `body`  text NOT NULL AFTER `cid`;\n";
runquery($sql);

$storeidexisted = false;
$query = DB::query("SHOW COLUMNS FROM " . DB::table('zpl_car_order'));
while ($temp = DB::fetch($query)) {
    if ($temp['Field'] == 'storeid') {
        $storeidexisted = true;
        continue;
    }
}
$sql = !$storeidexisted ? "ALTER TABLE " . DB::table('zpl_car_order') . " ADD COLUMN `storeid`  int(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `cid`;\n" : '';
runquery($sql);

// zpl_car_store
$openidexisted = false;
$paystatusexisted = false;
$query = DB::query("SHOW COLUMNS FROM " . DB::table('zpl_car_store'));
while ($temp = DB::fetch($query)) {
    if ($temp['Field'] == 'openid') {
        $openidexisted = true;
        continue;
    }
    if ($temp['Field'] == 'paystatus') {
        $paystatusexisted = true;
        continue;
    }
}
$sql = !$openidexisted ? "ALTER TABLE " . DB::table('zpl_car_store') . " ADD COLUMN `openid`  char(64) NOT NULL DEFAULT '' AFTER `checkremarks`;\n" : '';
$sql .= !$paystatusexisted ? "ALTER TABLE " . DB::table('zpl_car_store') . " ADD COLUMN `paystatus`  tinyint(1) UNSIGNED NOT NULL DEFAULT 0 AFTER `openid`;\n" : '';
runquery($sql);

// zpl_car_store
$openidexisted = false;
$query = DB::query("SHOW COLUMNS FROM " . DB::table('zpl_car_store'));
while ($temp = DB::fetch($query)) {
    if ($temp['Field'] == 'openid') {
        $openidexisted = true;
        continue;
    }
}
$sql = $openidexisted ? "ALTER TABLE " . DB::table('zpl_car_store') . " DROP COLUMN `openid`;\n" : '';
runquery($sql);

// zpl_car
$topexpireatexisted = false;
$query = DB::query("SHOW COLUMNS FROM " . DB::table('zpl_car'));
while ($temp = DB::fetch($query)) {
    if ($temp['Field'] == 'topexpireat') {
        $topexpireatexisted = true;
        continue;
    }
}
$sql = !$topexpireatexisted ? "ALTER TABLE " . DB::table('zpl_car') . " ADD COLUMN `topexpireat`  int(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `views`;\n" : '';
runquery($sql);

// zpl_car
$issoldexisted = false;
$query = DB::query("SHOW COLUMNS FROM " . DB::table('zpl_car'));
while ($temp = DB::fetch($query)) {
    if ($temp['Field'] == 'issold') {
        $issoldexisted = true;
        continue;
    }
}
$sql = !$issoldexisted ? "ALTER TABLE " . DB::table('zpl_car') . " ADD COLUMN `issold`  tinyint(1) UNSIGNED NOT NULL DEFAULT 0 AFTER `topexpireat`;\n" : '';
runquery($sql);

global $_G;
$dbcharset = $_G['config']['db'][1]['dbcharset'];
$ckey = DB::result_first("SELECT ckey from %t", array('zpl_car_lang'));
if (empty($ckey)) {
    if (stripos($dbcharset, 'gbk') !== false) {
        $lsql = file_get_contents('source/plugin/zpl_car/data/zpl_car_lang_gbk.sql');
    } else {
        $lsql = file_get_contents('source/plugin/zpl_car/data/zpl_car_lang_utf8.sql');
    }
    $lsql = str_replace("\r\n", "\n", $lsql);
    runquery($lsql);
} else {
    if (stripos($dbcharset, 'gbk') !== false) {
        $zclangs = require('source/plugin/zpl_car/data/zpl_car_lang_upgrade_gbk.php');
    } else {
        $zclangs = require('source/plugin/zpl_car/data/zpl_car_lang_upgrade_utf8.php');
    }
    foreach ($zclangs as $zclang) {
        $row = DB::fetch_first("SELECT * from %t WHERE ckey=%s", array('zpl_car_lang', $zclang['ckey']));
        if ($row) {
            //DB::update('zpl_car_lang', array('cvalue' => $zclang['cvalue']), DB::field('ckey', $zclang['ckey']));
        } else {
            DB::insert('zpl_car_lang', $zclang);
        }
    }
}
updatecache('zpl_car:zpl_car_lang');

$finish = TRUE;

?>