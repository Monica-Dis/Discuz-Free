<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: wechat.class.php 36284 2016-12-12 00:47:50Z nemohou $
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class ZplWeChat {
	static public function register($username, $return = 0, $groupid = 0) {
		global $_G;
		if(!$username) {
			return;
		}

		loaducenter();
        $groupid = !$groupid ? $_G['setting']['newusergroupid'] : $groupid;

		$password = md5(random(10));
		$email = 'wechat_'.strtolower(random(10)).'@null.null';

		$usernamelen = dstrlen($username);
		if($usernamelen < 3) {
			$username = $username.'_'.random(5);
		}
		if($usernamelen > 15) {
			if(!$return) {
				showmessage('profile_username_toolong');
			} else {
				return;
			}
		}

		$censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';

		if($_G['setting']['censoruser'] && @preg_match($censorexp, $username)) {
			if(!$return) {
				showmessage('profile_username_protect');
			} else {
				return;
			}
		}

        loadcache('ipctrl');
        if($_G['cache']['ipctrl']['ipregctrl']) {
            foreach(explode("\n", $_G['cache']['ipctrl']['ipregctrl']) as $ctrlip) {
                if(preg_match("/^(".preg_quote(($ctrlip = trim($ctrlip)), '/').")/", $_G['clientip'])) {
                    $ctrlip = $ctrlip.'%';
                    $_G['setting']['regctrl'] = $_G['setting']['ipregctrltime'];
                    break;
                } else {
                    $ctrlip = $_G['clientip'];
                }
            }
        } else {
            $ctrlip = $_G['clientip'];
        }

        if($_G['setting']['regctrl']) {
            if(C::t('common_regip')->count_by_ip_dateline($ctrlip, $_G['timestamp']-$_G['setting']['regctrl']*3600)) {
                if(!$return) {
                    showmessage('register_ctrl', NULL, array('regctrl' => $_G['setting']['regctrl']));
                } else {
                    return;
                }
            }
        }

        $setregip = null;
        if($_G['setting']['regfloodctrl']) {
            $regip = C::t('common_regip')->fetch_by_ip_dateline($_G['clientip'], $_G['timestamp']-86400);
            if($regip) {
                if($regip['count'] >= $_G['setting']['regfloodctrl']) {
                    if(!$return) {
                        showmessage('register_flood_ctrl', NULL, array('regfloodctrl' => $_G['setting']['regfloodctrl']));
                    } else {
                        return;
                    }
                } else {
                    $setregip = 1;
                }
            } else {
                $setregip = 2;
            }
        }

        if($setregip !== null) {
            if($setregip == 1) {
                C::t('common_regip')->update_count_by_ip($_G['clientip']);
            } else {
                C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => 1, 'dateline' => $_G['timestamp']));
            }
        }

		$uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
		if($uid <= 0) {
			if(!$return) {
				if($uid == -1) {
					showmessage('profile_username_illegal');
				} elseif($uid == -2) {
					showmessage('profile_username_protect');
				} elseif($uid == -3) {
					showmessage('profile_username_duplicate');
				} elseif($uid == -4) {
					showmessage('profile_email_illegal');
				} elseif($uid == -5) {
					showmessage('profile_email_domain_illegal');
				} elseif($uid == -6) {
					showmessage('profile_email_duplicate');
				} else {
					showmessage('undefined_action');
				}
			} else {
				return;
			}
		}

        $init_arr = array('credits' => explode(',', $_G['setting']['initcredits']));
		C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);

		if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
			C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72)*3600);
			if($_G['setting']['regctrl']) {
				C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
			}
		}

		if($_G['setting']['regverify'] == 2) {
			C::t('common_member_validate')->insert(array(
				'uid' => $uid,
				'submitdate' => $_G['timestamp'],
				'moddate' => 0,
				'admin' => '',
				'submittimes' => 1,
				'status' => 0,
				'message' => '',
				'remark' => '',
			), false, true);
			manage_addnotify('verifyuser');
		}

        setloginstatus(array(
            'uid' => $uid,
            'username' => $username,
            'password' => $password,
            'groupid' => $groupid,
        ), 0);

		include_once libfile('function/stat');
		updatestat('register');

		return $uid;
	}

	static public function getnewname($openid) {
        global $_G;
        loadcache(['plugin']);
        $vars = $_G['cache']['plugin']['zpl_car'];
        $appid = $vars['wxappid'];
        $appsecret = $vars['wxappsecret'];
		$wechat_client = new WeChatClient($appid, $appsecret);
		$userinfo = $wechat_client->getUserInfoById($openid);
		if($userinfo) {
			$defaultusername = substr(WeChatEmoji::clear($userinfo['nickname']), 0, 15);
			loaducenter();
			$user = uc_get_user($defaultusername);
			if(!empty($user)) {
				$defaultusername = cutstr($defaultusername, 7, '').'_'.random(5);
			} else {
                $defaultusername = 'wx_'.random(5);
            }
		} else {
			$defaultusername = 'wx_'.random(5);
		}
		return $defaultusername;
	}
}