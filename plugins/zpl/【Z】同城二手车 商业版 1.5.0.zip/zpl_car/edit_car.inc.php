<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zpl_car/helper.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/wechat.lib.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/wechat.class.php';

loadcache(['plugin', 'zpl_car_brands', 'zpl_car_langs']);
global $_G;
$vars = $_G['cache']['plugin']['zpl_car'];
$zclangs = $_G['cache']['zpl_car_langs'];

$appid = $vars['wxappid'];
$appsecret = $vars['wxappsecret'];

// login
if (empty($_G['uid'])) {
    $openwxlogin = $vars['openwxlogin'];

    $returnurl = $_G['siteurl'] . '.' . $_SERVER['REQUEST_URI'];
    if (helper::isweixin() && $openwxlogin == 1) {
        // WX login
        if (!isset($_GET['code'])) {
            $redirecturi = urlencode($returnurl);
            $wxurl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$appid}&redirect_uri={$redirecturi}&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";
            dheader('location: ' . $wxurl);
        } else {
            require_once libfile('function/member');

            $wechat_client = new WeChatClient($appid, $appsecret);

            $code = $_GET['code'];
            $tokeninfo = $wechat_client->getAccessTokenByCode($code);
            if ($tokeninfo['openid']) {
                $openid = $tokeninfo['openid'];
                $mp = C::t('#zpl_car#zpl_car_user_wxmp')->fetch_by_openid($openid);
                if ($mp) {
                    $member = getuserbyuid($mp['uid'], 1);
                    setloginstatus($member, 1296000);
                } else {
                    $uid = ZplWeChat::register(ZplWeChat::getnewname($openid), 1);
                    if ($uid) {
                        $data = array(
                            'uid' => $uid,
                            'openid' => $openid,
                        );
                        C::t('#zpl_car#zpl_car_user_wxmp')->insert($data);
                    }
                }
                dheader('location: ' . $returnurl);
            } else {
                // common login
                showmessage('not_loggedin', NULL, array(), array('login' => 1));
            }
        }
    } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX") !== false) {
        // MAGAPP login
        include_once template('zpl_car:mag_login');
        dexit();
    } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "QianFan") !== false) {
        // QFAPP login
        include_once template('zpl_car:qianfan_login');
        dexit();
    } else {
        // common login
        showmessage('not_loggedin', NULL, array(), array('login' => 1));
    }
}

$cid = intval($_GET['cid']);
$uid = $_G['uid'];
$car = C::t('#zpl_car#zpl_car')->fetch_by_cid_uid($cid, $uid);
if (!$car) {
    include_once template('zpl_car:err');
    dexit();
}

$wxjsconfig = helper::getwxjsconfig(
    $appid,
    $appsecret,
    $_G['scheme'] . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']
);

$brands = $_G['cache']['zpl_car_brands'];
$brandsarr = array();
$biarray = array();
if ($brands && is_array($brands)) {
    foreach ($brands as $brand) {
        $brandsarr[] = array('title' => $brand['name'], 'value' => $brand['id']);
        $biarray[$brand['id']] = $brand['name'];
    }
}

$gearboxs = explode(PHP_EOL, $vars['car_gearbox']);
$levels = explode(PHP_EOL, $vars['car_level']);
$countries = explode(PHP_EOL, $vars['car_countries']);
$colors = explode(PHP_EOL, $vars['car_color']);
$intakeforms = explode(PHP_EOL, $vars['car_intakeform']);
$emissstandards = explode(PHP_EOL, $vars['car_emissstandard']);
$fueltypes = explode(PHP_EOL, $vars['car_fueltype']);
$drives = explode(PHP_EOL, $vars['car_drive']);
$haveornots = explode(PHP_EOL, $vars['car_haveornot']);

$bitems = helper_json::encode($brandsarr);
list($gitems, $giarray) = get_items_iarr($gearboxs);
list($litems, $liarray) = get_items_iarr($levels);
list($citems, $ciarray) = get_items_iarr($countries);
list($coitems, $coiarray) = get_items_iarr($colors, true);
list($iitems, $iiarray) = get_items_iarr($intakeforms);
list($eitems, $eiarray) = get_items_iarr($emissstandards);
list($fitems, $fiarray) = get_items_iarr($fueltypes);
list($ditems, $diarray) = get_items_iarr($drives);
list($hitems, $hiarray) = get_items_iarr($haveornots);

$brands2 = $brands ? helper::index($brands, null, 'letter') : array();
$brandshtml = '<div class="box-brand" style="padding-bottom: 3rem"><div class="brands">';
foreach ($brands2 as $group => $items) {
    $brandshtml .= '<div class="brand-list"><span class="brand-letter" id="' . $group . '1">' . $group . '</span>';
    if (is_array($items)) {
        foreach ($items as $item) {
            $brandshtml .= '<a class="brand-item" data-queryname="bid" data-label="' . $item['name'] . '" data-value="' . $item['id'] . '" href="javascript:;"><img class="brand-icon" src="' . ($item['image'] ? helper::gethandledurl($item['image']) : $zclangs['zclang_no_image']) . '"><span class="brand-name">' . $item['name'] . '</span></a>';
        }
    }
    $brandshtml .= '</div>';
}
$brandshtml .= '</div></div>';

$attachments = C::t('#zpl_car#zpl_car_attachment')->fetch_all_by_cid_uid($cid, $uid);
foreach ($attachments as $key => $attachment) {
    $attachments[$key]['attachmenturl'] = helper::gethandledurl($attachment['attachment']);
}
$series = get_series($car['bid']);
$config = C::t('#zpl_car#zpl_car_config')->fetch_by_cid_uid($cid, $uid);

if (submitcheck('csubmit')) {
    if (!$_POST['attachments']) {
        echo '<script>parent.showerrmsg("' . $zclangs['zclang_required_img'] . '");</script>';
        dexit();
    }

    list($intsarr, $floatsarr, $stringsarr, $cararr, $configarr, $notrequirearr) = helper::getfields();

    required($intsarr, $notrequirearr);
    required($floatsarr, $notrequirearr);
    required($stringsarr, $notrequirearr);

    $aarray = array();
    $postattachments = $_POST['attachments'];
    while ($current = current($postattachments)) {
        $next = next($postattachments);
        $next2 = next($postattachments);
        $aarray[] = array(
            'aid' => $current['aid'],
            'attachment' => $next['attachment'],
            'filename' => $next2['filename'],
        );
        next($postattachments);
    }

    if (count($aarray) > 16) {
        echo '<script>parent.showerrmsg("' . $zclangs['zclang_img_maxlimit_error'] . '");</script>';
        dexit();
    }

    $cardata = array();
    foreach ($cararr as $value) {
        if (in_array($value, $intsarr)) {
            $cardata[$value] = intval($_POST[$value]);
        } elseif (in_array($value, $floatsarr)) {
            $cardata[$value] = floatval($_POST[$value]);
        } elseif (in_array($value, $stringsarr)) {
            $cardata[$value] = dhtmlspecialchars(trim($_POST[$value]));
        }
        if ($value == 'cardyear' || $value == 'cardmonth') {
            $cardarr = explode(' ', trim($_POST['cardtime']));
            if ($value == 'cardyear') {
                $cardata[$value] = $cardarr[0];
            }
            if ($value == 'cardmonth') {
                $cardata[$value] = $cardarr[1];
            }
        }
        if ($value == 'listyear' || $value == 'listmonth') {
            $listarr = explode(' ', trim($_POST['listtime']));
            if ($value == 'listyear') {
                $cardata[$value] = $listarr[0];
            }
            if ($value == 'listmonth') {
                $cardata[$value] = $listarr[1];
            }
        }
    }
    $cardata['cardtime'] = strtotime($cardata['cardyear'] . ($cardata['cardmonth'] ? '-' . $cardata['cardmonth'] : ''));

    $configdata = array();
    foreach ($configarr as $value) {
        if (in_array($value, $intsarr)) {
            $configdata[$value] = intval($_POST[$value]);
        } elseif (in_array($value, $floatsarr)) {
            $configdata[$value] = floatval($_POST[$value]);
        } elseif (in_array($value, $stringsarr)) {
            $configdata[$value] = dhtmlspecialchars(trim($_POST[$value]));
        }
    }

    $cardata['uid'] = $_G['uid'];
    $cardata['username'] = $_G['username'];
    $cardata['updatetime'] = time();
    C::t('#zpl_car#zpl_car')->update($cid, $cardata);

    $aids = array();
    foreach ($aarray as $item) {
        if (intval($item['aid']) == 0) {
            $f = $_G['setting']['attachdir'] . $item['attachment'];
            list($width) = getimagesize($f);
            $adata = array(
                'cid' => $cid,
                'uid' => $_G['uid'],
                'dateline' => time(),
                'filename' => $item['filename'],
                'filesize' => filesize($f),
                'attachment' => $item['attachment'],
                'width' => $width,
            );
            C::t('#zpl_car#zpl_car_attachment')->insert($adata);
        } else {
            $aids[] = $item['aid'];
        }
    }
    $delaids = array_diff(helper::get_column($attachments, 'aid'), $aids);
    C::t('#zpl_car#zpl_car_attachment')->delete($delaids);

    $configdata['uid'] = $_G['uid'];
    C::t('#zpl_car#zpl_car_config')->update($cid, $configdata);

    if ($car['storeid']) {
        echo '<script>parent.showsuccessmsg("' . $zclangs['zclang_save_success'] . '", 1000, true, "plugin.php?id=zpl_car:store_center");</script>';
    } else {
        echo '<script>parent.showsuccessmsg("' . $zclangs['zclang_save_success'] . '", 1000, true, "plugin.php?id=zpl_car:my&action=mylist");</script>';
    }
}

include_once template('zpl_car:edit_car');

function required($array = array(), $array2 = array())
{
    global $_G;
    loadcache(['zpl_car_langs']);
    $zclangs = $_G['cache']['zpl_car_langs'];
    foreach ($array as $value) {
        if (!in_array($value, $array2) && ($_POST[$value] == null || $_POST[$value] == '')) {
            echo '<script>parent.showerrmsg("' . $zclangs['zclang_required'] . '");</script>';
            dexit();
        }
    }
}

function get_items_iarr($array = array(), $color = false)
{
    $items = array();
    $iarr = array();
    if (is_array($array)) {
        foreach ($array as $v) {
            $arr = explode('=', $v);
            if ($color) {
                $items[] = array('title' => str_replace(["\r\n", "\n", "\r"], "", $arr[2]), 'value' => $arr[0]);
                $iarr[$arr[0]] = str_replace(["\r\n", "\n", "\r"], "", $arr[2]);
            } else {
                $items[] = array('title' => str_replace(["\r\n", "\n", "\r"], "", $arr[1]), 'value' => $arr[0]);
                $iarr[$arr[0]] = str_replace(["\r\n", "\n", "\r"], "", $arr[1]);
            }
        }
    }
    return [helper_json::encode($items), $iarr];
}

function get_series($upid = 0)
{
    loadcache(['zpl_car_brand_list']);
    global $_G;
    $list = $_G['cache']['zpl_car_brand_list'];
    $data = array();
    if (isset($list[$upid])) {
        $series = $list[$upid]['series'];
        if ($series) {
            foreach ($series as $e) {
                $data[$e['id']] = $e['name'];
            }
        }
    }
    return $data;
}
//From: Dism_taobao-com
?>