<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_zpl_car` (
  `cid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` char(15) NOT NULL DEFAULT '',
  `cartype` varchar(64) NOT NULL DEFAULT '',
  `cardyear` smallint(6) unsigned NOT NULL DEFAULT '0',
  `cardmonth` tinyint(2) unsigned ZEROFILL NOT NULL DEFAULT '0',
  `cardtime` int(10) unsigned NOT NULL DEFAULT '0',
  `apparentmileage` float(5,2) unsigned NOT NULL DEFAULT '0.00',
  `price` float(7,2) unsigned NOT NULL DEFAULT '0.00',
  `expectprice` float(7,2) unsigned NOT NULL DEFAULT '0.00',
  `downpayment` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `periods` smallint(4) unsigned NOT NULL DEFAULT '0',
  `listyear` smallint(6) unsigned NOT NULL DEFAULT '0',
  `listmonth` tinyint(2) unsigned ZEROFILL NOT NULL DEFAULT '0',
  `transfertimes` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `gxbzhoilcons` float(5,1) unsigned NOT NULL DEFAULT '0.0',
  `gearbox` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `carlevel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `country` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `appearance` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `new` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `desc` text NOT NULL,
  `isshow` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `homepagerecomm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `detailrecomm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `createtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `bid` (`bid`) USING BTREE,
  KEY `sid` (`sid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE
) TYPE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_zpl_car_ad` (
  `adid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(60) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `sort` smallint(4) NOT NULL DEFAULT '0',
  `starttime` int(4) NOT NULL DEFAULT '0',
  `endtime` int(4) NOT NULL DEFAULT '0',
  `isshow` tinyint(1) NOT NULL DEFAULT '1',
  `atype` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`adid`)
) TYPE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_zpl_car_attachment` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `attachment` varchar(255) NOT NULL DEFAULT '',
  `width` smallint(6) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`aid`),
  KEY `cid` (`cid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE
) TYPE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_zpl_car_brand`  (
  `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `pinyin` varchar(64) NOT NULL DEFAULT '',
  `letter` char(4) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `level` tinyint(4) NOT NULL DEFAULT 0,
  `upid` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `displayorder` smallint(6) NOT NULL DEFAULT 0,
  `showhomepage` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_zpl_car_config` (
  `cid` int(10) unsigned NOT NULL,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `enginedis` float(5,1) unsigned NOT NULL DEFAULT '0.0',
  `engineintakeform` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `enginecylinder` varchar(255) NOT NULL DEFAULT '',
  `enginemaxhorsepower` varchar(255) NOT NULL DEFAULT '',
  `enginemaxpower` varchar(255) NOT NULL DEFAULT '',
  `enginemaxtorque` varchar(255) NOT NULL DEFAULT '',
  `engineemistand` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `engineroz` varchar(255) NOT NULL DEFAULT '',
  `enginefueltype` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tcbttype` varchar(255) NOT NULL DEFAULT '',
  `tcbgears` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `tcbdrive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tcbassistance` varchar(255) NOT NULL DEFAULT '',
  `tcbfrontsusp` varchar(255) NOT NULL DEFAULT '',
  `tcbrearsusp` varchar(255) NOT NULL DEFAULT '',
  `tcbfrontbrake` varchar(255) NOT NULL DEFAULT '',
  `tcbrearbrake` varchar(255) NOT NULL DEFAULT '',
  `tcbparkingbraking` varchar(255) NOT NULL DEFAULT '',
  `tcbfronttire` varchar(255) NOT NULL DEFAULT '',
  `tcbreartire` varchar(255) NOT NULL DEFAULT '',
  `cblength` smallint(6) unsigned NOT NULL DEFAULT '0',
  `cbwidth` smallint(6) unsigned NOT NULL DEFAULT '0',
  `cbheight` smallint(6) unsigned NOT NULL DEFAULT '0',
  `cbcardoors` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cbseats` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cbstructure` varchar(255) NOT NULL DEFAULT '',
  `cbtankvolume` float(5,1) unsigned NOT NULL DEFAULT '0.0',
  `cbtrunkvolume` varchar(255) NOT NULL DEFAULT '',
  `secujsyqn` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `secufjsqn` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `secutyjczz` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `secuaqdwxts` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `secuetzyjk` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `secucnzks` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `secuwysqdxt` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `secuwysjrxt` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `secuabs` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `secuesp` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `insidezpfxp` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `insidezpzy` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `insidedgnfxp` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `insidezktcsdp` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `insidekt` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `insidedsxh` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `insidegpsdhxt` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `insidedcyxxt` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `insideczld` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `externalddcc` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `externalqjtc` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `externalddxhm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `externalgyhbx` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `externalqhddcc` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `externalhys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lightingjgd` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lightingddgdkt` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lightingzdtd` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lightingzxfzd` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lightingqwd` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`)
) TYPE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_zpl_car_user` (
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` char(15) NOT NULL DEFAULT '',
  `openid` char(64) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `tel` char(64) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `desc` text NOT NULL,
  `createtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`)
) TYPE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_zpl_car_inquiryrecord` (
  `irid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `cid` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `uid` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `phone` char(32) NOT NULL DEFAULT '',
  `dateline` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `ip` varchar(16) NOT NULL DEFAULT '',
  PRIMARY KEY (`irid`)
) TYPE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_zpl_car_collection` (
  `collid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `cid` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `uid` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `dateline` int(10) UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`collid`),
  UNIQUE KEY cu (cid,uid)
) TYPE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_zpl_car_order` (
  `orderid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orderno` char(32) NOT NULL DEFAULT '',
  `appid` char(64) NOT NULL DEFAULT '',
  `mchid` char(64) NOT NULL DEFAULT '',
  `tradeno` varchar(255) NOT NULL DEFAULT '',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` char(15) NOT NULL DEFAULT '',
  `cid` int(10) unsigned NOT NULL DEFAULT '0',
  `paymentmethod` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `tradetype` char(32) NOT NULL DEFAULT '',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `price` float(7,2) unsigned NOT NULL DEFAULT '0.00',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `createtime` int(10) unsigned NOT NULL DEFAULT '0',
  `paytime` int(10) unsigned NOT NULL DEFAULT '0',
  `note` text NOT NULL,
  `ip` char(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`orderid`),
  UNIQUE KEY orderno (orderno)
) TYPE=MyISAM;
EOF;
runquery($sql);

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_zpl_car_user_wxmp` (
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` char(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`)
) TYPE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_zpl_car_lang` (
  `ckey` varchar(255) NOT NULL DEFAULT '',
  `cvalue` text,
  PRIMARY KEY (`ckey`)
) TYPE=MyISAM;
EOF;
runquery($sql);

// zpl_car
$sql = "ALTER TABLE " . DB::table('zpl_car') . " ADD COLUMN paystatus tinyint(1) unsigned NOT NULL default '0';\n";
runquery($sql);

// zpl_car_config
$sql = "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secujsyqn` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secufjsqn` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secutyjczz` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secuaqdwxts` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secuetzyjk` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secucnzks` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secuwysqdxt` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secuwysjrxt` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secuabs` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `secuesp` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insidezpfxp` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insidezpzy` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insidedgnfxp` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insidezktcsdp` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insidekt` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insidedsxh` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insidegpsdhxt` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insidedcyxxt` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `insideczld` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `externalddcc` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `externalqjtc` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `externalddxhm` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `externalgyhbx` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `externalqhddcc` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `externalhys` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `lightingjgd` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `lightingddgdkt` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `lightingzdtd` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `lightingzxfzd` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_config') . " MODIFY COLUMN `lightingqwd` tinyint(1) UNSIGNED NOT NULL DEFAULT 2;\n";
runquery($sql);

// zpl_car_order
$sql = "ALTER TABLE " . DB::table('zpl_car_order') . " ADD COLUMN magunionordernum varchar(255) NOT NULL DEFAULT '';\n";
runquery($sql);
$sql = "ALTER TABLE " . DB::table('zpl_car_order') . " DROP COLUMN `magunionordernum`;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_order') . " DROP COLUMN `appid`;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_order') . " DROP COLUMN `mchid`;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_order') . " DROP COLUMN `note`;\n";
runquery($sql);
$sql = "ALTER TABLE " . DB::table('zpl_car_order') . " ADD COLUMN `body` text NOT NULL AFTER `ip`;\n";
runquery($sql);

// zpl_car_user
$sql = "ALTER TABLE " . DB::table('zpl_car_user') . " DROP COLUMN `openid`;\n";
runquery($sql);

// zpl_car_store
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_zpl_car_store` (
  `storeid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `tel` char(64) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `desc` text NOT NULL,
  `idfront` varchar(255) NOT NULL DEFAULT '',
  `idback` varchar(255) NOT NULL DEFAULT '',
  `idpeople` varchar(255) NOT NULL DEFAULT '',
  `businesslicense` varchar(255) NOT NULL DEFAULT '',
  `checkstatus` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `checkremarks` varchar(255) NOT NULL DEFAULT '',
  `createtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`storeid`)
) TYPE=MyISAM;
EOF;
runquery($sql);

// zpl_car
$sql = "ALTER TABLE " . DB::table('zpl_car') . " ADD COLUMN `storeid`  int(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `uid`;\n";
runquery($sql);

// zpl_car_browserecord
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_zpl_car_browserecord` (
  `brid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` char(15) NOT NULL DEFAULT '',
  `bdate` varchar(32) NOT NULL DEFAULT '',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(16) NOT NULL DEFAULT '',
  PRIMARY KEY (`brid`)
) TYPE=MyISAM;
EOF;
runquery($sql);

// zpl_car
$sql = "ALTER TABLE " . DB::table('zpl_car') . " MODIFY COLUMN `paystatus`  tinyint(1) UNSIGNED NOT NULL DEFAULT 0 AFTER `detailrecomm`;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car') . " ADD COLUMN `views`  int(10) NOT NULL DEFAULT 0 AFTER `paystatus`;\n";
runquery($sql);

// zpl_car_user
$sql = "ALTER TABLE " . DB::table('zpl_car_user') . " ADD COLUMN `openid`  char(64) NOT NULL DEFAULT '' AFTER `desc`;\n";
runquery($sql);

// zpl_car_order
$sql = "ALTER TABLE " . DB::table('zpl_car_order') . " DROP COLUMN `tradetype`;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_order') . " MODIFY COLUMN `paymentmethod`  char(32) NOT NULL DEFAULT '' AFTER `username`;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_order') . " MODIFY COLUMN `status`  tinyint(2) UNSIGNED NOT NULL DEFAULT 0 AFTER `paymentmethod`;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_order') . " MODIFY COLUMN `price`  float(7,2) UNSIGNED NOT NULL DEFAULT 0.00 AFTER `status`;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_order') . " MODIFY COLUMN `type`  tinyint(3) UNSIGNED NOT NULL DEFAULT 0 AFTER `price`;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_order') . " MODIFY COLUMN `body`  text NOT NULL AFTER `cid`;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_order') . " ADD COLUMN `storeid`  int(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `cid`;\n";
runquery($sql);

// zpl_car_store
$sql = "ALTER TABLE " . DB::table('zpl_car_store') . " ADD COLUMN `openid`  char(64) NOT NULL DEFAULT '' AFTER `checkremarks`;\n";
$sql .= "ALTER TABLE " . DB::table('zpl_car_store') . " ADD COLUMN `paystatus`  tinyint(1) UNSIGNED NOT NULL DEFAULT 0 AFTER `openid`;\n";
runquery($sql);

// zpl_car_store
$sql = "ALTER TABLE " . DB::table('zpl_car_store') . " DROP COLUMN `openid`;\n";
runquery($sql);

// zpl_car
$sql = "ALTER TABLE " . DB::table('zpl_car') . " ADD COLUMN `topexpireat`  int(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `views`;\n";
runquery($sql);

// zpl_car
$sql = "ALTER TABLE " . DB::table('zpl_car') . " ADD COLUMN `issold`  tinyint(1) UNSIGNED NOT NULL DEFAULT 0 AFTER `topexpireat`;\n";
runquery($sql);

global $_G;
$dbcharset = $_G['config']['db'][1]['dbcharset'];
if (stripos($dbcharset, 'gbk') !== false) {
    $sql = file_get_contents('source/plugin/zpl_car/data/zpl_car_brand_gbk.sql');
} else {
    $sql = file_get_contents('source/plugin/zpl_car/data/zpl_car_brand_utf8.sql');
}
$sql = str_replace("\r\n", "\n", $sql);
runquery($sql);
updatecache('zpl_car:zpl_car_brand');

if (stripos($dbcharset, 'gbk') !== false) {
    $sql = file_get_contents('source/plugin/zpl_car/data/zpl_car_lang_gbk.sql');
} else {
    $sql = file_get_contents('source/plugin/zpl_car/data/zpl_car_lang_utf8.sql');
}
$sql = str_replace("\r\n", "\n", $sql);
runquery($sql);
updatecache('zpl_car:zpl_car_lang');

$finish = TRUE;

?>