<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zpl_car/helper.class.php';

global $_G;
loadcache(['zpl_car_langs']);
$zclangs = $_G['cache']['zpl_car_langs'];

$act = $_GET['act'];

if (!$act) {
    if (!submitcheck('adsubmit')) {
        $ppp = 10;
        $page = max(1, $_GET['page']);
        $count = C::t('#zpl_car#zpl_car_ad')->fetch_count();
        $multipage = multi($count, $ppp, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_ad');
        showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_ad&page=' . $_GET['page'], 'enctype');
        showtableheader($zclangs['zclang_car_ad_list']);
        showsubtitle(array('', $zclangs['zclang_car_ad_sort'], $zclangs['zclang_car_ad_image'], $zclangs['zclang_car_ad_starttime'], $zclangs['zclang_car_ad_endtime'], $zclangs['zclang_car_ad_title'], $zclangs['zclang_car_ad_link'], $zclangs['zclang_car_ad_isshow'], $zclangs['zclang_car_ad_atype'], $zclangs['zclang_operation']));
        $ads = C::t('#zpl_car#zpl_car_ad')->fetch_all_by_page_and_limit($ppp, $page);
        foreach ($ads as $key => $ad) {
            showtablerow('', array('class="td25"', 'class="td28"'), array(
                "<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"{$ad['adid']}\">",
                "<input type=\"text\" class=\"txt\" name=\"sortnew[{$ad['adid']}]\" value=\"{$ad['sort']}\" size=\"2\">",
                $ad['image'] ? '<img src="' . helper::gethandledurl($ad['image']) . '" style="width: 60px; height: 40px">' : '',
                $ad['starttime'] ? dgmdate($ad['starttime'], 'Y-n-j H:i') : '',
                $ad['endtime'] ? dgmdate($ad['endtime'], 'Y-n-j H:i') : ($ad['starttime'] ? $lang['unlimited'] : ''),
                $ad['title'],
                $ad['link'] ? '<a href="' . $ad['link'] . '" target="_blank">' . $ad['link'] . '</a>' : '',
                $ad['isshow'] ? '<span style="color: green; font-weight: 600">' . $zclangs['zclang_car_ad_isshow_is'] . '</span>' : '<span style="color: red; font-weight: 600">' . $zclangs['zclang_car_ad_isshow_not'] . '</span>',
                $ad['atype'] == 1 ? $zclangs['zclang_car_ad_atype_1'] : $zclangs['zclang_car_ad_atype_2'],
                '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_ad&act=edit&adid=' . $ad['adid'] . '&page=' . $_GET['page'] . '">' . $lang['edit'] . '</a></th></tr>'
            ));
        }
        showsubmit('adsubmit', 'submit', 'del', '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_ad&act=add&adid=' . $ad['adid'] . '&page=' . $_GET['page'] . '" class="btn"><span>' . $zclangs['zclang_add'] . '</span></a>', $multipage);
        showtablefooter(); /*dism �� taobao �� com*/
        showformfooter();
    } else {
        if (is_array($_GET['delete'])) {
            C::t('#zpl_car#zpl_car_ad')->delete_by_adid($_GET['delete']);
        }

        if (is_array($_GET['sortnew'])) {
            foreach ($_GET['sortnew'] as $adid => $sort) {
                C::t('#zpl_car#zpl_car_ad')->update_sort_by_adid($adid, $sort);
            }
        }

        updatecache('zpl_car:zpl_car_ad');

        cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_ad&page=' . $_GET['page'], 'succeed');
    }
} elseif ($act == 'add') {
    if (!submitcheck('addsubmit')) {
        $starttime = dgmdate(TIMESTAMP, 'Y-n-j H:i');
        $endtime = dgmdate(TIMESTAMP + 86400 * 7, 'Y-n-j H:i');

        showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_ad&act=add', 'enctype');
        showtableheader($zclangs['zclang_car_ad_add']);
        showsetting($zclangs['zclang_car_ad_title'], 'title', '', 'text');
        showsetting($zclangs['zclang_car_ad_image'], 'image', '', 'filetext', 0, 0, $zclangs['zclang_car_ad_image_comment']);
        showsetting($zclangs['zclang_car_ad_link'], 'link', '', 'text', 0, 0, $zclangs['zclang_car_ad_link_comment']);
        showsetting($zclangs['zclang_car_ad_sort'], 'sort', '0', 'number');
        showsetting($zclangs['zclang_car_ad_starttime'], 'starttime', $starttime, 'calendar', '', 0, '', 1);
        showsetting($zclangs['zclang_car_ad_endtime'], 'endtime', $endtime, 'calendar', '', 0, $zclangs['zclang_car_ad_endtime_comment'], 1);
        showsetting($zclangs['zclang_car_ad_isshow'], 'isshow', '1');
        showsetting($zclangs['zclang_car_ad_atype'], ['atype', [[1, $zclangs['zclang_car_ad_atype_1']], [2, $zclangs['zclang_car_ad_atype_2']]]], 1, 'select');
        showsubmit('addsubmit');
        showtablefooter(); /*dism �� taobao �� com*/
        showformfooter();
    } else {
        if ($_FILES['image']['tmp_name']) {
            $upload = new discuz_upload();
            if (!$upload->init($_FILES['image'], 'common', random(3, 1), 'plugin_zpl_car_' . date('YmdHis') . strtolower(random(16))) || !$upload->save()) {
                cpmsg($upload->errormessage(), '', 'error');
            }
            $_GET['image'] = 'common/' . $upload->attach['attachment'];
        }

        if (!$_GET['image']) {
            cpmsg($zclangs['zclang_car_ad_error_image'], '', 'error');
        }

        $starttime = $_GET['starttime'] ? strtotime($_GET['starttime']) : 0;
        $endtime = $_GET['endtime'] ? strtotime($_GET['endtime']) : 0;

        if ($endtime && $starttime > $endtime) {
            cpmsg($zclangs['zclang_car_ad_time_invalid'], '', 'error');
        }

        $data = array(
            'title' => $_GET['title'],
            'image' => $_GET['image'],
            'link' => $_GET['link'],
            'sort' => $_GET['sort'],
            'starttime' => $starttime,
            'endtime' => $endtime,
            'isshow' => $_GET['isshow'],
            'atype' => $_GET['atype'],
        );
        C::t('#zpl_car#zpl_car_ad')->insert($data);

        updatecache('zpl_car:zpl_car_ad');

        cpmsg($zclangs['zclang_car_ad_add_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_ad', 'succeed');
    }
} elseif ($act == 'edit' && $_GET['adid']) {
    $ad = C::t('#zpl_car#zpl_car_ad')->fetch_by_adid($_GET['adid']);
    if (!$ad) {
        cpmsg($zclangs['zclang_car_ad_nonexistence'], '', 'error');
    }

    if (!submitcheck('editsubmit')) {
        $ad['starttime'] = $ad['starttime'] ? dgmdate($ad['starttime'], 'Y-n-j H:i') : "";
        $ad['endtime'] = $ad['endtime'] ? dgmdate($ad['endtime'], 'Y-n-j H:i') : "";

        showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_ad&act=edit&adid=' . $_GET['adid'] . '&page=' . $_GET['page'], 'enctype');
        showtableheader();
        showtableheader($zclangs['zclang_car_ad_edit']);
        showsetting($zclangs['zclang_car_ad_title'], 'title', $ad['title'], 'text');
        showsetting($zclangs['zclang_car_ad_image'], 'image', $ad['image'], 'filetext', 0, 0, $zclangs['zclang_car_ad_image_comment'] . ($ad['image'] ? '<br><img style="margin-top: 6px; margin-bottom: 3px" src="' . helper::gethandledurl($ad['image']) . '" width="150" height="100" />' : ''));
        showsetting($zclangs['zclang_car_ad_link'], 'link', $ad['link'], 'text', 0, 0, $zclangs['zclang_car_ad_link_comment']);
        showsetting($zclangs['zclang_car_ad_sort'], 'sort', $ad['sort'], 'number');
        showsetting($zclangs['zclang_car_ad_starttime'], 'starttime', $ad['starttime'], 'calendar', '', 0, '', 1);
        showsetting($zclangs['zclang_car_ad_endtime'], 'endtime', $ad['endtime'], 'calendar', '', 0, $zclangs['zclang_car_ad_endtime_comment'], 1);
        showsetting($zclangs['zclang_car_ad_isshow'], 'isshow', $ad['isshow']);
        showsetting($zclangs['zclang_car_ad_atype'], ['atype', [[1, $zclangs['zclang_car_ad_atype_1']], [2, $zclangs['zclang_car_ad_atype_2']]]], $ad['atype'], 'select');
        showsubmit('editsubmit');
        showtablefooter(); /*dism �� taobao �� com*/
        showformfooter();
    } else {
        if ($_FILES['image']['tmp_name']) {
            $upload = new discuz_upload();
            if (!$upload->init($_FILES['image'], 'common', random(3, 1), 'plugin_zpl_car_' . date('YmdHis') . strtolower(random(16))) || !$upload->save()) {
                cpmsg($upload->errormessage(), '', 'error');
            }
            $_GET['image'] = 'common/' . $upload->attach['attachment'];
        } else {
            $_GET['image'] = $ad['image'];
        }

        if (!$_GET['image']) {
            cpmsg($zclangs['zclang_car_ad_error_image'], '', 'error');
        }

        if (strpos($_GET['starttime'], '-')) {
            $starttime = strtotime($_GET['starttime']);
        } else {
            $starttime = 0;
        }
        if (strpos($_GET['endtime'], '-')) {
            $endtime = strtotime($_GET['endtime']);
        } else {
            $endtime = 0;
        }

        if ($endtime && $starttime > $endtime) {
            cpmsg($zclangs['zclang_car_ad_time_invalid'], '', 'error');
        }

        C::t('#zpl_car#zpl_car_ad')->update_by_adid($_GET['adid'], array(
            'title' => $_GET['title'],
            'image' => $_GET['image'],
            'link' => $_GET['link'],
            'sort' => $_GET['sort'],
            'starttime' => $starttime,
            'endtime' => $endtime,
            'isshow' => $_GET['isshow'],
            'atype' => $_GET['atype'],
        ));

        updatecache('zpl_car:zpl_car_ad');

        cpmsg($zclangs['zclang_car_ad_edit_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_ad&page=' . $_GET['page'], 'succeed');
    }
}

echo '<script type="text/javascript" src="static/js/calendar.js"></script>';

?>