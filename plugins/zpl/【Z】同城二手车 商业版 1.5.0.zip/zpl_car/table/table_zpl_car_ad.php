<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_zpl_car_ad extends discuz_table
{
    public function __construct()
    {
        $this->_table = 'zpl_car_ad';
        $this->_pk = 'adid';

        parent::__construct(); /*dism��taobao��com*/
    }

    public function fetch_count()
    {
        return count(DB::fetch_all('SELECT * FROM %t ORDER BY sort', array($this->_table), $this->_pk));
    }

    public function fetch_all_by_limit($limit = 6)
    {
        return DB::fetch_all('SELECT * FROM %t WHERE isshow=1 AND ((' . time() . ' >= starttime AND endtime = 0) OR (' . time() . ' >= starttime AND endtime >= ' . time() . ')) ORDER BY sort LIMIT ' . $limit, array($this->_table), $this->_pk);
    }

    public function fetch_all_by_page_and_limit($limit = 10, $page = 1)
    {
        return DB::fetch_all('SELECT * FROM %t ORDER BY sort LIMIT ' . $limit . ' OFFSET ' . ($page - 1) * $limit, array($this->_table), $this->_pk);
    }

    public function fetch_by_adid($adid)
    {
        return DB::fetch_first('SELECT * FROM %t WHERE adid=%a', array($this->_table, $adid));
    }

    public function delete_by_adid($adids)
    {
        if (($ids = dintval((array)$adids, true))) {
            DB::query('DELETE FROM %t WHERE adid IN(%n)', array($this->_table, $adids), false, true);
        }
    }

    public function update_sort_by_adid($adid, $sort)
    {
        if (($id = dintval((array)$adid, true))) {
            DB::query('UPDATE %t SET sort=%s WHERE adid IN(%n)', array($this->_table, $sort, $adid), false, true);
        }
    }

    public function update_by_adid($adid, $data)
    {
        if (($adid = dintval($adid, true)) && $data && is_array($data)) {
            DB::update($this->_table, $data, DB::field($this->_pk, $adid), true);
        }
    }
}
//From: Dism_taobao-com
?>