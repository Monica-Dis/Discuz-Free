<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_zpl_car extends discuz_table
{
    public function __construct()
    {
        $this->_table = 'zpl_car';
        $this->_pk = 'cid';

        parent::__construct(); /*dism��taobao��com*/
    }

    public function fetch_all_by_search($where, $order = '', $start = 0, $limit = 0, $count = 0)
    {
        $where = $where && !is_array($where) ? " WHERE $where" : '';
        if (is_array($order)) {
            $order = '';
        }
        if ($count) {
            return DB::result_first('SELECT COUNT(*) FROM ' . DB::table($this->_table) . ' c %i %i ' . DB::limit($start, $limit), array($where, $order));
        }
        return DB::fetch_all('SELECT c.cid AS cid, a.attachment AS image, b.name AS bname, s.name AS sname, c.cartype AS cartype, c.expectprice AS expectprice, c.cardyear AS cardyear, c.cardmonth AS cardmonth, c.createtime AS createtime, c.username AS username, c.uid AS uid, c.homepagerecomm AS homepagerecomm, c.detailrecomm AS detailrecomm, c.paystatus AS paystatus 
                FROM ' . DB::table($this->_table) . ' c 
                LEFT JOIN ' . DB::table('zpl_car_attachment') . ' a ON a.cid = c.cid 
                LEFT JOIN ' . DB::table('zpl_car_brand') . ' b ON b.id = c.bid 
                LEFT JOIN ' . DB::table('zpl_car_brand') . ' s ON s.id = c.sid 
                %i GROUP BY cid %i ' . DB::limit($start, $limit), array($where, $order));
    }

    public function fetch_all_by_bid_or_sid($paramid)
    {
        $paramid = intval($paramid);
        return DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . ' WHERE bid=' . $paramid . ' OR sid=' . $paramid);
    }
    
    public function delete_by_cid($cids)
    {
        if (($ids = dintval((array)$cids, true))) {
            DB::query('DELETE FROM %t WHERE cid IN(%n)', array($this->_table, $cids), false, true);
        }
    }

    public function fetch_all_by_recomm($page = 1, $limit = 10, $recommtype = 1)
    {
        if ($recommtype == 1) {
            $where = ' WHERE (c.topexpireat >= ' . time() . ' OR c.homepagerecomm = 1)';
        } elseif ($recommtype == 2) {
            $where = ' WHERE (c.topexpireat >= ' . time() . ' OR c.detailrecomm = 1)';
        } else {
            return array();
        }
        $page = intval($page);
        $limit = intval($limit);
        $start = ($page - 1) * $limit;

        loadcache(['plugin']);
        global $_G;
        $vars = $_G['cache']['plugin']['zpl_car'];
        if ($recommtype == 1) {
            if ($start + 10 > intval($vars['hprecommnum'])) {
                $limit = intval($vars['hprecommnum']) - $start;
            }
        } elseif ($recommtype == 2) {
            if ($start + 10 > intval($vars['detailrecommnum'])) {
                $limit = intval($vars['detailrecommnum']) - $start;
            }
        }

        return DB::fetch_all('SELECT c.cid, a.attachment AS image, b.name AS bname, s.name AS sname, c.cartype, c.cardyear, c.apparentmileage, c.expectprice, c.topexpireat, c.issold, c.storeid 
                FROM %t c LEFT JOIN ' . DB::table('zpl_car_attachment') . ' a ON a.cid = c.cid 
                LEFT JOIN ' . DB::table('zpl_car_brand') . ' b ON b.id = c.bid 
                LEFT JOIN ' . DB::table('zpl_car_brand') . ' s ON s.id = c.sid 
                %i AND c.isshow=1 AND c.paystatus=1 GROUP BY cid ORDER BY CASE WHEN c.topexpireat<' . time() . ' THEN 0 ELSE c.topexpireat END DESC, c.cid DESC ' . DB::limit($start, $limit), array($this->_table, $where, time()));
    }

    public function fetch_by_cid_uid($cid = 0, $uid = 0, $byuid = true)
    {
        if ($byuid) {
            return DB::fetch_first('SELECT * FROM ' . DB::table($this->_table) . ' WHERE cid=' . intval($cid) . ' AND uid=' . intval($uid) . ' AND paystatus=1');
        } else {
            return DB::fetch_first('SELECT * FROM ' . DB::table($this->_table) . ' WHERE cid=' . intval($cid));
        }
    }

    public function fetch_all_list($where, $order = '', $page = 1, $limit = 10)
    {
        $page = intval($page);
        $limit = intval($limit);
        $start = ($page - 1) * $limit;
        return DB::fetch_all('SELECT c.cid, a.attachment AS image, b.name AS bname, s.name AS sname, c.cartype, CONCAT_WS(\' \', b.name, s.name, c.cartype) AS title, c.cardyear, c.cardtime, c.apparentmileage, c.expectprice, c.price, c.topexpireat, c.issold, c.storeid 
                FROM %t c 
                LEFT JOIN ' . DB::table('zpl_car_attachment') . ' a ON a.cid = c.cid 
                LEFT JOIN ' . DB::table('zpl_car_brand') . ' b ON b.id = c.bid 
                LEFT JOIN ' . DB::table('zpl_car_brand') . ' s ON s.id = c.sid 
                LEFT JOIN ' . DB::table('zpl_car_config') . ' cc ON cc.cid = c.cid 
                WHERE %i AND c.isshow=1 AND c.paystatus=1 GROUP BY cid %i ' . DB::limit($start, $limit), array($this->_table, $where, $order));
    }

    public function fetch_all_by_storeid($page = 1, $limit = 10, $storeid = 0)
    {
        $page = intval($page);
        $limit = intval($limit);
        $start = ($page - 1) * $limit;

        return DB::fetch_all('SELECT c.cid, a.attachment AS image, b.name AS bname, s.name AS sname, c.cartype, c.cardyear, c.apparentmileage, c.expectprice, c.isshow, c.issold 
                FROM %t c 
                LEFT JOIN ' . DB::table('zpl_car_attachment') . ' a ON a.cid = c.cid 
                LEFT JOIN ' . DB::table('zpl_car_brand') . ' b ON b.id = c.bid 
                LEFT JOIN ' . DB::table('zpl_car_brand') . ' s ON s.id = c.sid 
                WHERE c.storeid = %d AND c.paystatus=1 GROUP BY cid ORDER BY c.createtime DESC' . DB::limit($start, $limit), array($this->_table, $storeid));
    }

    public function fetch_all_by_uid($uid = 0, $page = 1, $limit = 10, $storeid = 0)
    {
        $page = intval($page);
        $limit = intval($limit);
        $start = ($page - 1) * $limit;

        return DB::fetch_all('SELECT c.cid, a.attachment AS image, b.name AS bname, s.name AS sname, c.cartype, c.cardyear, c.apparentmileage, c.expectprice, c.topexpireat, c.isshow, c.issold 
                FROM %t c 
                LEFT JOIN ' . DB::table('zpl_car_attachment') . ' a ON a.cid = c.cid 
                LEFT JOIN ' . DB::table('zpl_car_brand') . ' b ON b.id = c.bid 
                LEFT JOIN ' . DB::table('zpl_car_brand') . ' s ON s.id = c.sid 
                WHERE c.uid=%u AND c.storeid = %d AND c.paystatus=1 GROUP BY cid ORDER BY c.topexpireat DESC, c.createtime DESC' . DB::limit($start, $limit), array($this->_table, $uid, $storeid));
    }

    public function delete_by_cid_uid($cid, $uid)
    {
        return DB::delete($this->_table, DB::field('cid', intval($cid)) . ' AND ' . DB::field('uid', intval($uid)) . ' AND ' . DB::field('paystatus', 1));
    }

    public function update_views($cid)
    {
        return DB::query('UPDATE %t SET views = views + 1 WHERE cid = %d', array($this->_table, $cid));
    }

    public function fetch_count_by_uid($uid)
    {
        return DB::result_first('SELECT COUNT(*) FROM ' . DB::table($this->_table) . ' WHERE uid = %i AND storeid=0 AND paystatus=1', array($uid));
    }

    public function fetch_count_by_storeid($uid, $storeid)
    {
        return DB::result_first('SELECT COUNT(*) FROM ' . DB::table($this->_table) . ' WHERE uid = %i AND storeid = %i AND paystatus=1', array($uid, $storeid));
    }

    public function fetch_all_views_by_storeid($uid, $storeid)
    {
        return DB::result_first('SELECT SUM(views) FROM ' . DB::table($this->_table) . ' WHERE uid = %d AND storeid = %d AND paystatus=1', array($uid, $storeid));
    }
}
//From: Dism_taobao-com
?>