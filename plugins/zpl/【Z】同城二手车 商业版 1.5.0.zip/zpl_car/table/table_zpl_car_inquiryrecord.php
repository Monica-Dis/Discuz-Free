<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_zpl_car_inquiryrecord extends discuz_table
{
    public function __construct()
    {
        $this->_table = 'zpl_car_inquiryrecord';
        $this->_pk = 'irid';

        parent::__construct(); /*dism��taobao��com*/
    }

    public function fetch_countall_by_search($wheresql, $iscount = 1, $limit = 10, $page = 1)
    {
        if ($iscount) {
            return DB::result_first('SELECT count(*) FROM ' . DB::table($this->_table) . ' ir WHERE %i', array($wheresql));
        } else {
            $limit = intval($limit);
            $offset = (intval($page) - 1) * $limit;
            return DB::fetch_all('SELECT ir.irid, ir.phone, ir.dateline, a.attachment AS image, b.name AS bname, s.name AS sname, c.cartype AS cartype, ir.ip 
                    FROM %t ir 
                    LEFT JOIN ' . DB::table('zpl_car') . ' c ON c.cid = ir.cid 
                    LEFT JOIN ' . DB::table('zpl_car_attachment') . ' a ON a.cid = c.cid 
                    LEFT JOIN ' . DB::table('zpl_car_brand') . ' b ON b.id = c.bid 
                    LEFT JOIN ' . DB::table('zpl_car_brand') . ' s ON s.id = c.sid 
                    WHERE c.cid IS NOT NULL AND %i GROUP BY ir.irid ORDER BY ir.dateline DESC LIMIT ' . $limit . ' OFFSET ' . $offset, array($this->_table, $wheresql), $this->_pk);
        }
    }

    public function fetch_all_by_cuid($cuid, $page = 1, $limit = 10, $storeid = 0)
    {
        $limit = intval($limit);
        $offset = (intval($page) - 1) * $limit;
        return DB::fetch_all('SELECT ir.irid, c.cid, ir.phone, ir.dateline, a.attachment AS image, b.name AS bname, s.name AS sname, c.cartype AS cartype, c.cardyear, c.apparentmileage, c.expectprice, ir.ip 
                FROM %t ir 
                LEFT JOIN ' . DB::table('zpl_car') . ' c ON c.cid = ir.cid 
                LEFT JOIN ' . DB::table('zpl_car_attachment') . ' a ON a.cid = c.cid 
                LEFT JOIN ' . DB::table('zpl_car_brand') . ' b ON b.id = c.bid 
                LEFT JOIN ' . DB::table('zpl_car_brand') . ' s ON s.id = c.sid 
                WHERE c.cid IS NOT NULL AND c.uid=%i AND c.storeid=%d GROUP BY ir.irid ORDER BY ir.dateline DESC LIMIT ' . $limit . ' OFFSET ' . $offset, array($this->_table, $cuid, $storeid));
    }

    public function fetch_count_by_storeid($storeid, $uid)
    {
        return DB::result_first('SELECT COUNT(*) FROM ' . DB::table($this->_table) . ' ir 
                LEFT JOIN ' . DB::table('zpl_car') . ' c ON c.cid = ir.cid 
                WHERE c.cid IS NOT NULL AND c.storeid = %d AND c.uid = %d', array($storeid, $uid));
    }
}
//From: Dism_taobao-com
?>