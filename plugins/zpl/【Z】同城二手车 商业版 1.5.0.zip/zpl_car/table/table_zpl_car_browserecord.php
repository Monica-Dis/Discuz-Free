<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_zpl_car_browserecord extends discuz_table
{
    public function __construct()
    {
        $this->_table = 'zpl_car_browserecord';
        $this->_pk = 'brid';

        parent::__construct(); /*dism��taobao��com*/
    }

    public function fetch_countall_by_search($wheresql, $iscount = 1, $limit = 10, $page = 1)
    {
        if ($iscount) {
            return DB::result_first('SELECT count(*) FROM ' . DB::table($this->_table) . ' br WHERE %i', array($wheresql));
        } else {
            $limit = intval($limit);
            $offset = (intval($page) - 1) * $limit;
            return DB::fetch_all('SELECT br.brid, br.dateline, br.uid, br.username, br.ip, a.attachment AS image, b.name AS bname, s.name AS sname, c.cartype AS cartype 
                    FROM %t br 
                    LEFT JOIN ' . DB::table('zpl_car') . ' c ON c.cid = br.cid 
                    LEFT JOIN ' . DB::table('zpl_car_attachment') . ' a ON a.cid = c.cid 
                    LEFT JOIN ' . DB::table('zpl_car_brand') . ' b ON b.id = c.bid 
                    LEFT JOIN ' . DB::table('zpl_car_brand') . ' s ON s.id = c.sid 
                    WHERE c.cid IS NOT NULL AND %i GROUP BY br.brid ORDER BY br.dateline DESC LIMIT ' . $limit . ' OFFSET ' . $offset, array($this->_table, $wheresql), $this->_pk);
        }
    }

    public function fetch_by_date($cid = 0, $uid = 0, $date = '')
    {
        return DB::fetch_first('SELECT * FROM ' . DB::table($this->_table) . ' WHERE cid=' . intval($cid) . ' AND uid=' . intval($uid), array(trim($date)));
    }

    public function fetch_all_by_uid($uid, $page = 1, $limit = 10)
    {
        $limit = intval($limit);
        $offset = (intval($page) - 1) * $limit;
        return DB::fetch_all('SELECT br.brid, c.cid, a.attachment AS image, b.name AS bname, s.name AS sname, c.cartype AS cartype, c.cardyear, c.apparentmileage, c.expectprice, br.ip 
                FROM %t br 
                LEFT JOIN ' . DB::table('zpl_car') . ' c ON c.cid = br.cid 
                LEFT JOIN ' . DB::table('zpl_car_attachment') . ' a ON a.cid = c.cid 
                LEFT JOIN ' . DB::table('zpl_car_brand') . ' b ON b.id = c.bid 
                LEFT JOIN ' . DB::table('zpl_car_brand') . ' s ON s.id = c.sid 
                WHERE c.cid IS NOT NULL AND br.uid=%i GROUP BY br.brid ORDER BY br.dateline DESC LIMIT ' . $limit . ' OFFSET ' . $offset, array($this->_table, $uid));
    }
}
//From: Dism_taobao-com
?>