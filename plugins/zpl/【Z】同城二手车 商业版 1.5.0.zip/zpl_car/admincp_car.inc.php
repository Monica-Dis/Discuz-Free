<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zpl_car/helper.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/zplupload.class.php';

echo '<link href="source/plugin/zpl_car/assets/plugins/layui/css/layui.css" rel="stylesheet" type="text/css" charset="' . CHARSET . '">';
echo '<link href="source/plugin/zpl_car/assets/css/plugins.css" rel="stylesheet" type="text/css">';
echo '<script type="text/javascript" src="./source/plugin/zpl_car/assets/plugins/layui/layui.js" charset="' . CHARSET . '"></script>';

global $_G;
loadcache(['zpl_car_langs', 'plugin', 'zpl_car_brands']);
$zclangs = $_G['cache']['zpl_car_langs'];
$brands = $_G['cache']['zpl_car_brands'];
$vars = $_G['cache']['plugin']['zpl_car'];

$brandsarray = array();
foreach ($brands as $brand) {
    $brandsarray[] = array(helper::get_value($brand, 'id'), helper::get_value($brand, 'name'));
}
$brandsarray = array_merge(array(array(0, $zclangs['zclang_tpl_choose'])), $brandsarray);

$iarray = helper::get_array(explode(PHP_EOL, $vars['car_intakeform']), false, 'select');
$harray = helper::get_array(explode(PHP_EOL, $vars['car_haveornot']), false, 'select');

$gearboxs = helper::get_array(explode(PHP_EOL, $vars['car_gearbox']), false, 'select');
$levels = helper::get_array(explode(PHP_EOL, $vars['car_level']), false, 'select');
$countries = helper::get_array(explode(PHP_EOL, $vars['car_countries']), false, 'select');
$colors = helper::get_array(explode(PHP_EOL, $vars['car_color']), true, 'select');
$emissstandards = helper::get_array(explode(PHP_EOL, $vars['car_emissstandard']), false, 'select');
$fueltypes = helper::get_array(explode(PHP_EOL, $vars['car_fueltype']), false, 'select');
$drives = helper::get_array(explode(PHP_EOL, $vars['car_drive']), false, 'select');

$iarray = array_merge(array(array(0, $zclangs['zclang_tpl_choose'])), $iarray);
$harray = array_merge(array(array(2, $zclangs['zclang_tpl_choose'])), $harray);

$gearboxs = array_merge(array(array(0, $zclangs['zclang_tpl_choose'])), $gearboxs);
$levels = array_merge(array(array(0, $zclangs['zclang_tpl_choose'])), $levels);
$countries = array_merge(array(array(0, $zclangs['zclang_tpl_choose'])), $countries);
$colors = array_merge(array(array(0, $zclangs['zclang_tpl_choose'])), $colors);
$emissstandards = array_merge(array(array(0, $zclangs['zclang_tpl_choose'])), $emissstandards);
$fueltypes = array_merge(array(array(0, $zclangs['zclang_tpl_choose'])), $fueltypes);
$drives = array_merge(array(array(0, $zclangs['zclang_tpl_choose'])), $drives);

$act = $_GET['act'];

if ($act == 'list') {
    $searchctrl = '<span style="float: right;">'
        . '<a href="javascript:;" class="btn" onclick="$(\'tb_search\').style.display=\'\';$(\'a_search_show\').style.display=\'none\';$(\'a_search_hide\').style.display=\'\';" id="a_search_show" style="display:none">' . cplang('show_search') . '</a>'
        . '<a href="javascript:;" class="btn" onclick="$(\'tb_search\').style.display=\'none\';$(\'a_search_show\').style.display=\'\';$(\'a_search_hide\').style.display=\'none\';" id="a_search_hide">' . cplang('hide_search') . '</a>'
        . '</span>';

    $array = array('cid', 'bid', 'sid', 'uid', 'cartype', 'username', 'createtime1', 'createtime2', 'orderby', 'ordersc', 'perpage', 'page');

    $toarray = array();
    foreach ($array as $value) {
        if (isset($_GET[$value])) {
            $toarray[$value] = $_GET[$value];
        }
    }

    if (!submitcheck('carsubmit')) {
        $baseurl = ADMINSCRIPT . '?action=';
        $action = "plugins&operation=config&do=$pluginid&identifier=zpl_car&pmod=admincp_car&act=list";

        if ($_GET['op'] == 'ps') {
            $car = C::t('#zpl_car#zpl_car')->fetch($_GET['carid']);
            if ($car['paystatus']) {
                C::t('#zpl_car#zpl_car')->update($_GET['carid'], ['paystatus' => 0]);
            } else {
                C::t('#zpl_car#zpl_car')->update($_GET['carid'], ['paystatus' => 1]);
            }
            dheader('location: ' . $baseurl . $action . ($toarray ? '&' . http_build_query($toarray) : ''));
        }

        $intkeys = array('cid', 'bid', 'sid', 'uid');
        $strkeys = array();
        $randkeys = array();
        $likekeys = array('cartype', 'username');
        $results = getwheres($intkeys, $strkeys, $randkeys, $likekeys, 'c.');
        foreach ($likekeys as $k) {
            $_GET[$k] = dhtmlspecialchars($_GET[$k]);
        }
        $action .= '&' . implode('&', $results['urls']);
        $wherearr = $results['wherearr'];
        if ($_GET['createtime1']) {
            $wherearr[] = "c.createtime >= '" . strtotime($_GET['createtime1']) . "'";
            $action .= '&createtime1=' . $_GET['createtime1'];
        }
        if ($_GET['createtime2']) {
            $wherearr[] = "c.createtime <= '" . strtotime($_GET['createtime2']) . "'";
            $action .= '&createtime2=' . $_GET['createtime2'];
        }
        $wheresql = empty($wherearr) ? '1' : implode(' AND ', $wherearr);

        $orders = getorders(array('createtime'), 'cid', 'c.');
        if ($orders['urls']) {
            $action .= '&' . implode('&', $orders['urls']);
        }
        $ordersql = $orders['sql'];

        $orderby = array($_GET['orderby'] => ' selected');
        $ordersc = array($_GET['ordersc'] => ' selected');

        $perpage = empty($_GET['perpage']) ? 0 : intval($_GET['perpage']);
        if (!in_array($perpage, array(10, 20, 50, 100))) {
            $perpage = 10;
        }
        $action .= '&perpage=' . $perpage;
        $perpages = array($perpage => ' selected');

        $page = empty($_GET['page']) ? 1 : intval($_GET['page']);
        if ($page < 1) {
            $page = 1;
        }
        $start = ($page - 1) * $perpage;

        $searchlang = array();
        $keys = array('search', 'likesupport', 'resultsort', 'defaultsort', 'orderdesc', 'orderasc', 'perpage_10', 'perpage_20', 'perpage_50', 'perpage_100',
            'car_cid', 'car_brand', 'car_series', 'car_brand_level_2', 'car_type', 'car_username', 'car_uid', 'car_createtime');
        foreach ($keys as $key) {
            if (substr($key, 0, 4) == 'car_') {
                $searchlang[$key] = $zclangs['zclang_' . $key];
            } else {
                $searchlang[$key] = cplang($key);
            }
        }

        $adminhiddens = 'operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=list';
        parse_str($adminhiddens, $arrparams);
        $hiddenhtml = '';
        foreach ($arrparams as $key => $value) {
            $hiddenhtml .= '<input type="hidden" name="' . $key . '" value="' . $value . '">';
        }

        $brandoptions = brandlist($_GET['bid']);
        $adminscript = ADMINSCRIPT;
        $addcar = '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part1" class="addtr"><span>' . $zclangs['zclang_add_car'] . '</span></a>';
        echo <<<EOF
        <form method="get" autocomplete="off" action="">
            <div class="block style4">
                <div style="float: left">
                    <table cellspacing="3" cellpadding="3" id="tb_search">
                        <tr>
                            <th>$searchlang[car_cid]</th><td><input type="text" class="txt" name="cid" value="$_GET[cid]"></td>
                            <th>$searchlang[car_brand]</th><td><select id="brandid" name="bid" style="width: 100%;" onchange="ajaxget('$adminscript?action=plugins&operation=config&do=$pluginid&identifier=zpl_car&pmod=admincp_car&act=getseriesbyupid&bid=' + this.value, 'carseries')">$brandoptions</select></td>
                            <th>$searchlang[car_series]</th><td><span id="carseries"><select name="sid" style="width: 150px;"><option value="">$searchlang[car_brand_level_2]</option></select></span></td>
                            <th>$searchlang[car_type]* </th><td><input type="text" class="txt" name="cartype" value="$_GET[cartype]"> *$searchlang[likesupport]</td>
                        </tr>
                        <tr>
                            <th>$searchlang[car_username]* </th><td><input type="text" name="username" value="$_GET[username]"></td>
                            <th>$searchlang[car_uid]</th><td><input type="text" name="uid" value="$_GET[uid]"></td>
                        </tr>
                        <tr>
                            <th>$searchlang[car_createtime]</th>
                            <td colspan="3">
                                <input type="text" name="createtime1" value="$_GET[createtime1]" size="10" onclick="showcalendar(event, this)"> ~
                                <input type="text" name="createtime2" value="$_GET[createtime2]" size="10" onclick="showcalendar(event, this)"> (YYYY-MM-DD)
                            </td>
                        </tr>
                        <tr>
                            <th>$searchlang[resultsort]</th>
                            <td colspan="3">
                                <select name="orderby">
                                <option value="">$searchlang[defaultsort]</option>
                                <option value="createtime"$orderby[createtime]>$searchlang[car_createtime]</option>
                                </select>
                                <select name="ordersc">
                                <option value="desc"$ordersc[desc]>$searchlang[orderdesc]</option>
                                <option value="asc"$ordersc[asc]>$searchlang[orderasc]</option>
                                </select>
                                <select name="perpage">
                                <option value="10"$perpages[10]>$searchlang[perpage_10]</option>
                                <option value="20"$perpages[20]>$searchlang[perpage_20]</option>
                                <option value="50"$perpages[50]>$searchlang[perpage_50]</option>
                                <option value="100"$perpages[100]>$searchlang[perpage_100]</option>
                                </select>
                                <input type="hidden" name="action" value="plugins">
                                $hiddenhtml
                                <input type="submit" name="searchsubmit" value="$searchlang[search]" class="btn">
                                $addcar
                            </td>
                        </tr>
                    </table>
                </div>
                <div style="display: none; float: right; margin-top: 3px;">$searchctrl</div>
                <div style="clear: both;"></div>
            </div>
        </form>
        <script type="text/javascript" src="static/js/calendar.js"></script>
        <script>
            ajaxget('$adminscript?action=plugins&operation=config&do=$pluginid&identifier=zpl_car&pmod=admincp_car&act=getseriesbyupid&bid=$_GET[bid]&sid=$_GET[sid]', 'carseries');
        </script>
EOF;
        $action .= '&page=' . $page;
        showformheader($action, 'enctype="multipart/form-data" onsubmit="return confirm(\'' . $zclangs['zclang_del_confirm'] . '\');"');
        showtableheader($zclangs['zclang_car_list']);

        $subtitle = array('', 'car_cid', 'car_image', 'car_name', 'car_expectprice', 'car_cardtime', 'car_user', 'car_createtime', 'car_homepagerecomm_title', 'car_detailrecomm_title', 'car_paystatus', 'operation');
        foreach ($subtitle as $key => $value) {
            if ($value) {
                $subtitle[$key] = $zclangs['zclang_' . $value];
            }
        }
        showsubtitle($subtitle);

        $multipage = '';
        $count = C::t('#zpl_car#zpl_car')->fetch_all_by_search($wheresql, '', 0, 0, 1);
        if ($count) {
            $result = C::t('#zpl_car#zpl_car')->fetch_all_by_search($wheresql, $ordersql, $start, $perpage);
            foreach ($result as $item) {
                $row = array();
                $row[] = "<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$item[cid]\">";
                $row[] = $item['cid'];
                $row[] = '<input type="hidden" name="cids[]" value="' . $item['cid'] . '" />' . ($item['image'] ? '<img src="' . helper::gethandledurl($item['image']) . '" style="width: 40px; height: 40px">' : '');
                $row[] = $item['bname'] . ' ' . $item['sname'] . ' ' . $item['cartype'];
                $row[] = $item['expectprice'];
                $row[] = $item['cardyear'] . '-' . $item['cardmonth'];
                $row[] = $item['username'] . '/' . $item['uid'];
                $row[] = date('Y-m-d', $item['createtime']);
                $row[] = '<input type="checkbox" name="homepagerecomm[' . $item['cid'] . ']" value="1" class="checkbox"' . ($item['homepagerecomm'] ? ' checked="checked" ' : '') . ' />';
                $row[] = '<input type="checkbox" name="detailrecomm[' . $item['cid'] . ']" value="1" class="checkbox"' . ($item['detailrecomm'] ? ' checked="checked" ' : '') . ' />';
                $row[] = '<a onclick="javascript:return confirm(\'' . ($item['paystatus'] ? $zclangs['zclang_car_paystatus_text_0'] : $zclangs['zclang_car_paystatus_text_1']) . '\');" href="' . $baseurl . $action. '&op=ps&carid=' . $item['cid'] . '">' . $zclangs['zclang_car_paystatus_' . $item['paystatus']] . '</a>';
                $row[] = '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part1&cid=' . $item['cid'] . '&page=' . $_GET['page'] . '">' . $zclangs['zclang_edit'] . '</a>&nbsp;&nbsp;' . '<a target="_blank" href="plugin.php?id=zpl_car:detail&cid=' . $item['cid'] . '">' . $zclangs['zclang_view'] . '</a>';
                showtablerow('', array(), $row);
            }
            $multipage = multi($count, $perpage, $page, $baseurl . $action);
        }

        showsubmit('carsubmit', 'submit', 'del', '', $multipage, false);
        showtablefooter(); /*dism �� taobao �� com*/
        showformfooter();
    } else {
        if (is_array($_GET['delete'])) {
            C::t('#zpl_car#zpl_car')->delete_by_cid($_GET['delete']);
        }

        $cids = $_POST['cids'];
        if (is_array($cids)) {
            $fields = ['homepagerecomm', 'detailrecomm'];
            $data = array();
            foreach ($cids as $cid) {
                foreach ($fields as $field) {
                    if (isset($_POST[$field])) {
                        $pfd = $_POST[$field];
                        if (is_array($pfd) && in_array($cid, array_keys($pfd))) {
                            $data[$cid][$field] = 1;
                        } else {
                            $data[$cid][$field] = 0;
                        }
                    } else {
                        $data[$cid][$field] = 0;
                    }
                }
            }
            foreach ($data as $id => $datum) {
                C::t('#zpl_car#zpl_car')->update($id, $datum);
            }
        }

        cpmsg($zclangs['zclang_succeed'], "action=plugins&operation=config&do=$pluginid&identifier=zpl_car&pmod=admincp_car&act=list" . ($toarray ? '&' . http_build_query($toarray) : ''), 'succeed');
    }
} elseif ($act == 'add') {
    echo <<<EOF
<style>
.floattop { display: none; }
.floattopempty { display: none; }
.cmenu { height:35px; }
.cmenu .floattop { display: inline; }
.cmenu .floattopempty { display: inline; }
</style>
EOF;

    $current = array($_GET['subact'] => 1);

    echo '<div class="cmenu">';
    showsubmenu($zclangs['zclang_add_car'], array(
        array($zclangs['zclang_car_return_list'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=list'),
        array($zclangs['zclang_car_part1'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part1', $current['part1']),
        //array($zclangs['zclang_car_part2'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part2', $current['part2']),
        //array($zclangs['zclang_car_part3'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part3', $current['part3']),
        //array($zclangs['zclang_car_part4'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part4', $current['part4']),
        //array($zclangs['zclang_car_part5'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part5', $current['part5']),
        //array($zclangs['zclang_car_part6'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part6', $current['part6']),
        //array($zclangs['zclang_car_part7'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part7', $current['part7']),
        //array($zclangs['zclang_car_part8'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part8', $current['part8']),
    ));
    echo '</div>';

    if ($_GET['subact'] == 'part1') {
        if (!submitcheck('submit')) {
            showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part1', 'enctype');
            showtableheader($zclangs['zclang_car_part1']);

            $url = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=upload&inajax=1';
            $zplupload = new zplupload(null, 'attachments', $url, 'images', array(), array('uploadimagesbtntext' => $zclangs['zclang_upload_images_btn'], 'delbtntext' => $zclangs['zclang_delete']));
            echo '<tr><td colspan="2" class="td27" s="1">' . $zclangs['zclang_tpl_upload_images_label'] . ':</td></tr>';
            echo '<tr class="noborder"><td colspan="2"><p style="margin-bottom: 5px">' . $zclangs['zclang_tpl_upload_images_size'] . '</p>' . $zplupload->gethtml() . '</td></tr>';
            $zplupload->registerjs();

            showsetting($zclangs['zclang_tpl_brand'], ['bid', $brandsarray], 0, 'select', '', 0, '', 'onchange="ajaxget(\'' . ADMINSCRIPT . '?action=plugins&operation=config&do=$pluginid&identifier=zpl_car&pmod=admincp_car&act=getseriesbyupid&ae=1&bid=\' + this.value, \'carsid\')"');
            showsetting($zclangs['zclang_tpl_series'], ['sid'], 0, 'select', '', 0, '', 'id="carsid"');

            showsetting($zclangs['zclang_tpl_cartype'], 'cartype', '', 'text', '', 0, $zclangs['zclang_tpl_cartype_example']);
            showsetting($zclangs['zclang_tpl_cardtime'], 'cardtime', '', 'text', '', 0, '', 'id=cardtime');
            showsetting($zclangs['zclang_tpl_apparentmileage'], 'apparentmileage', null, 'number', '', 0, $zclangs['zclang_tpl_unit_wan'] . $zclangs['zclang_tpl_unit_kilometre'], 'step="0.01"');
            showsetting($zclangs['zclang_tpl_price'], 'price', null, 'number', '', 0, $zclangs['zclang_tpl_unit_wan'] . $zclangs['zclang_tpl_unit_yuan'], 'step="0.01"');
            showsetting($zclangs['zclang_tpl_expectprice'], 'expectprice', null, 'number', '', 0, $zclangs['zclang_tpl_unit_wan'] . $zclangs['zclang_tpl_unit_yuan'], 'step="0.01"');
            showsetting($zclangs['zclang_tpl_gearbox'], ['gearbox', $gearboxs], 0, 'select');
            showsetting($zclangs['zclang_tpl_listtime'], 'listtime', '', 'text', '', 0, '', 'id=listtime');
            showsetting($zclangs['zclang_tpl_carlevel'], ['carlevel', $levels], 0, 'select');
            showsetting($zclangs['zclang_tpl_country'], ['country', $countries], 0, 'select');
            showsetting($zclangs['zclang_tpl_appearance'], ['appearance', $colors], 0, 'select');
            showsetting($zclangs['zclang_tpl_transfertimes'], 'transfertimes', null, 'number', '', 0, '');
            showsetting($zclangs['zclang_tpl_enginedis'], 'enginedis', null, 'number', '', 0, 'L', 'step="0.01"');
            showsetting($zclangs['zclang_tpl_engineemistand'], ['engineemistand', $emissstandards], 0, 'select');
            showsetting($zclangs['zclang_tpl_enginefueltype'], ['enginefueltype', $fueltypes], 0, 'select');
            showsetting($zclangs['zclang_tpl_tcbdrive'], ['tcbdrive', $drives], 0, 'select');
            showsetting($zclangs['zclang_tpl_new'], 'new', 0, 'radio', '', 0, '');
            showsetting($zclangs['zclang_tpl_gxbzhoilcons'], 'gxbzhoilcons', null, 'number', '', 0, 'L/100km', 'step="0.01"');
            showsetting($zclangs['zclang_tpl_desc'], 'desc', '', 'textarea', '', 0, '');

            showsubmit('submit');
            showtablefooter(); /*dism �� taobao �� com*/
            showformfooter();
        } else {
            $cardata = array();
            $cardata['bid'] = $_POST['bid'];
            $cardata['sid'] = $_POST['sid'];
            $cardata['cartype'] = $_POST['cartype'];
            $cardata['apparentmileage'] = $_POST['apparentmileage'];
            $cardata['price'] = $_POST['price'];
            $cardata['expectprice'] = $_POST['expectprice'];
            $cardata['gearbox'] = $_POST['gearbox'];
            $cardata['carlevel'] = $_POST['carlevel'];
            $cardata['country'] = $_POST['country'];
            $cardata['appearance'] = $_POST['appearance'];
            $cardata['transfertimes'] = $_POST['transfertimes'];
            $cardata['new'] = $_POST['new'];
            $cardata['gxbzhoilcons'] = $_POST['gxbzhoilcons'];
            $cardata['desc'] = $_POST['desc'];
            if (isset($_POST['cardtime'])) {
                $cardarr = explode('-', trim($_POST['cardtime']));
                $cardata['cardyear'] = $cardarr[0];
                $cardata['cardmonth'] = $cardarr[1];
            }
            if (isset($_POST['listtime'])) {
                $listarr = explode('-', trim($_POST['listtime']));
                $cardata['listyear'] = $listarr[0];
                $cardata['listmonth'] = $listarr[1];
            }
            $cardata['uid'] = $_G['uid'];
            $cardata['username'] = $_G['username'];
            $cardata['createtime'] = time();
            $cardata['updatetime'] = time();
            $cid = C::t('#zpl_car#zpl_car')->insert($cardata, true);

            $aarray = array();
            $postattachments = $_POST['attachments'];
            while ($current = current($postattachments)) {
                $next = next($postattachments);
                $next2 = next($postattachments);
                $aarray[] = array(
                    'aid' => $current['aid'],
                    'attachment' => $next['attachment'],
                    'filename' => $next2['filename'],
                );
                next($postattachments);
            }
            $aids = array();
            foreach ($aarray as $item) {
                if (intval($item['aid']) == 0) {
                    $f = $_G['setting']['attachdir'] . $item['attachment'];
                    list($width) = getimagesize($f);
                    $adata = array(
                        'cid' => $cid,
                        'uid' => $_G['uid'],
                        'dateline' => time(),
                        'filename' => $item['filename'],
                        'filesize' => filesize($f),
                        'attachment' => $item['attachment'],
                        'width' => $width,
                    );
                    C::t('#zpl_car#zpl_car_attachment')->insert($adata);
                } else {
                    $aids[] = $item['aid'];
                }
            }

            $configdata = array();
            $configdata['cid'] = $cid;
            $configdata['uid'] = $_G['uid'];
            $configdata['enginedis'] = $_POST['enginedis'];
            $configdata['engineemistand'] = $_POST['engineemistand'];
            $configdata['enginefueltype'] = $_POST['enginefueltype'];
            $configdata['tcbdrive'] = $_POST['tcbdrive'];
            C::t('#zpl_car#zpl_car_config')->insert($configdata);

            cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part1&cid=' . $cid, 'succeed');
        }
    } elseif ($_GET['subact'] == 'part2') {
        if (!submitcheck('submit')) {
            showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part2', 'enctype');
            showtableheader($zclangs['zclang_car_part2']);

            showsetting($zclangs['zclang_tpl_engineintakeform'], ['engineintakeform', $iarray], 0, 'select');
            showsetting($zclangs['zclang_tpl_enginecylinder'], 'enginecylinder', '', 'text', '', 0, $zclangs['zclang_tpl_enginecylinder_example']);
            showsetting($zclangs['zclang_tpl_enginemaxhorsepower'], 'enginemaxhorsepower', null, 'number', '', 0, 'Ps');
            showsetting($zclangs['zclang_tpl_enginemaxpower'], 'enginemaxpower', null, 'number', '', 0, 'kW');
            showsetting($zclangs['zclang_tpl_enginemaxtorque'], 'enginemaxtorque', null, 'number', '', 0, 'N*m');
            showsetting($zclangs['zclang_tpl_engineroz'], 'engineroz', null, 'number', '', 0, '#');

            showsubmit('submit');
            showtablefooter(); /*dism �� taobao �� com*/
            showformfooter();
        } else {
            cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part2', 'succeed');
        }
    } elseif ($_GET['subact'] == 'part3') {
        if (!submitcheck('submit')) {
            showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part3', 'enctype');
            showtableheader($zclangs['zclang_car_part3']);

            showsetting($zclangs['zclang_tpl_tcbttype'], 'tcbttype', '', 'text', '', 0, $zclangs['zclang_tpl_tcbttype_example']);
            showsetting($zclangs['zclang_tpl_tcbgears'], 'tcbgears', null, 'number');
            showsetting($zclangs['zclang_tpl_tcbassistance'], 'tcbassistance', '', 'text', '', 0, $zclangs['zclang_tpl_tcbassistance_example']);
            showsetting($zclangs['zclang_tpl_tcbrearsusp'], 'tcbrearsusp', '', 'text', '', 0, $zclangs['zclang_tpl_tcbrearsusp_example']);
            showsetting($zclangs['zclang_tpl_tcbfrontbrake'], 'tcbfrontbrake', '', 'text', '', 0, $zclangs['zclang_tpl_tcbfrontbrake_example']);
            showsetting($zclangs['zclang_tpl_tcbrearbrake'], 'tcbrearbrake', '', 'text', '', 0, $zclangs['zclang_tpl_tcbrearbrake_example']);
            showsetting($zclangs['zclang_tpl_tcbparkingbraking'], 'tcbparkingbraking', '', 'text', '', 0, $zclangs['zclang_tpl_tcbparkingbraking_example']);
            showsetting($zclangs['zclang_tpl_tcbfronttire'], 'tcbfronttire', '', 'text', '', 0, $zclangs['zclang_tpl_tcbfronttire_examplle']);
            showsetting($zclangs['zclang_tpl_tcbreartire'], 'tcbreartire', '', 'text', '', 0, $zclangs['zclang_tpl_tcbreartire_examplle']);

            showsubmit('submit');
            showtablefooter(); /*dism �� taobao �� com*/
            showformfooter();
        } else {
            cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part3', 'succeed');
        }
    } elseif ($_GET['subact'] == 'part4') {
        if (!submitcheck('submit')) {
            showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part4', 'enctype');
            showtableheader($zclangs['zclang_car_part4']);

            showsetting($zclangs['zclang_tpl_cblength'], 'cblength', null, 'number', '', 0, 'mm');
            showsetting($zclangs['zclang_tpl_cbwidth'], 'cbwidth', null, 'number', '', 0, 'mm');
            showsetting($zclangs['zclang_tpl_cbheight'], 'cbheight', null, 'number', '', 0, 'mm');
            showsetting($zclangs['zclang_tpl_cbcardoors'], 'cbcardoors', null, 'number', '', 0, '');
            showsetting($zclangs['zclang_tpl_cbseats'], 'cbseats', null, 'number', '', 0, '');
            showsetting($zclangs['zclang_tpl_cbstructure'], 'cbstructure', '', 'text', '', 0, $zclangs['zclang_tpl_cbstructure_example']);
            showsetting($zclangs['zclang_tpl_cbtankvolume'], 'cbtankvolume', null, 'number', '', 0, 'L', 'step="0.01"');
            showsetting($zclangs['zclang_tpl_cbtrunkvolume'], 'cbtrunkvolume', '', 'text', '', 0, 'L', 'step="0.01"');

            showsubmit('submit');
            showtablefooter(); /*dism �� taobao �� com*/
            showformfooter();
        } else {
            cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part4', 'succeed');
        }
    } elseif ($_GET['subact'] == 'part5') {
        if (!submitcheck('submit')) {
            showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part5', 'enctype');
            showtableheader($zclangs['zclang_car_part5']);

            showsetting($zclangs['zclang_tpl_secujsyqn'], ['secujsyqn', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_secufjsqn'], ['secufjsqn', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_secutyjczz'], ['secutyjczz', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_secuaqdwxts'], ['secuaqdwxts', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_secuetzyjk'], ['secuetzyjk', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_secucnzks'], ['secucnzks', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_secuwysqdxt'], ['secuwysqdxt', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_secuwysjrxt'], ['secuwysjrxt', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_secuabs'], ['secuabs', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_secuesp'], ['secuesp', $harray], 2, 'select');

            showsubmit('submit');
            showtablefooter(); /*dism �� taobao �� com*/
            showformfooter();
        } else {
            cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part5', 'succeed');
        }
    } elseif ($_GET['subact'] == 'part6') {
        if (!submitcheck('submit')) {
            showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part6', 'enctype');
            showtableheader($zclangs['zclang_car_part6']);

            showsetting($zclangs['zclang_tpl_insidezpfxp'], ['insidezpfxp', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_insidezpzy'], ['insidezpzy', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_insidedgnfxp'], ['insidedgnfxp', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_insidezktcsdp'], ['insidezktcsdp', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_insidekt'], ['insidekt', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_insidedsxh'], ['insidedsxh', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_insidegpsdhxt'], ['insidegpsdhxt', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_insidedcyxxt'], ['insidedcyxxt', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_insideczld'], ['insideczld', $harray], 2, 'select');

            showsubmit('submit');
            showtablefooter(); /*dism �� taobao �� com*/
            showformfooter();
        } else {
            cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part6', 'succeed');
        }
    } elseif ($_GET['subact'] == 'part7') {
        if (!submitcheck('submit')) {
            showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part7', 'enctype');
            showtableheader($zclangs['zclang_car_part7']);

            showsetting($zclangs['zclang_tpl_externalddcc'], ['externalddcc', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_externalqjtc'], ['externalqjtc', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_externalddxhm'], ['externalddxhm', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_externalgyhbx'], ['externalgyhbx', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_externalqhddcc'], ['externalqhddcc', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_externalhys'], ['externalhys', $harray], 2, 'select');

            showsubmit('submit');
            showtablefooter(); /*dism �� taobao �� com*/
            showformfooter();
        } else {
            cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part7', 'succeed');
        }
    } elseif ($_GET['subact'] == 'part8') {
        if (!submitcheck('submit')) {
            showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part8', 'enctype');
            showtableheader($zclangs['zclang_car_part8']);

            showsetting($zclangs['zclang_tpl_lightingjgd'], ['lightingjgd', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_lightingddgdkt'], ['lightingddgdkt', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_lightingzdtd'], ['lightingzdtd', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_lightingzxfzd'], ['lightingzxfzd', $harray], 2, 'select');
            showsetting($zclangs['zclang_tpl_lightingqwd'], ['lightingqwd', $harray], 2, 'select');

            showsubmit('submit');
            showtablefooter(); /*dism �� taobao �� com*/
            showformfooter();
        } else {
            cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=add&subact=part8', 'succeed');
        }
    }
} elseif ($act == 'edit') {
    echo <<<EOF
<style>
.floattop { display: none; }
.floattopempty { display: none; }
.cmenu { height:35px; }
.cmenu .floattop { display: inline; }
.cmenu .floattopempty { display: inline; }
</style>
EOF;

    $current = array($_GET['subact'] => 1);
    $cid = intval($_GET['cid']);

    $attachments = C::t('#zpl_car#zpl_car_attachment')->fetch_all_by_cid_uid($cid, 0, false);
    foreach ($attachments as $key => $attachment) {
        $attachments[$key]['attachmenturl'] = helper::gethandledurl($attachment['attachment']);
    }
    $car = C::t('#zpl_car#zpl_car')->fetch_by_cid_uid($cid, 0, false);
    $config = C::t('#zpl_car#zpl_car_config')->fetch_by_cid_uid($cid, 0, false);

    echo '<div class="cmenu">';
    showsubmenu($zclangs['zclang_edit_car'], array(
        array($zclangs['zclang_car_return_list'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=list&page=' . $_GET['page']),
        array($zclangs['zclang_car_part1'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part1&page=' . $_GET['page'] . '&cid=' . $cid, $current['part1']),
        array($zclangs['zclang_car_part2'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part2&page=' . $_GET['page'] . '&cid=' . $cid, $current['part2']),
        array($zclangs['zclang_car_part3'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part3&page=' . $_GET['page'] . '&cid=' . $cid, $current['part3']),
        array($zclangs['zclang_car_part4'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part4&page=' . $_GET['page'] . '&cid=' . $cid, $current['part4']),
        array($zclangs['zclang_car_part5'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part5&page=' . $_GET['page'] . '&cid=' . $cid, $current['part5']),
        array($zclangs['zclang_car_part6'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part6&page=' . $_GET['page'] . '&cid=' . $cid, $current['part6']),
        array($zclangs['zclang_car_part7'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part7&page=' . $_GET['page'] . '&cid=' . $cid, $current['part7']),
        array($zclangs['zclang_car_part8'], 'plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part8&page=' . $_GET['page'] . '&cid=' . $cid, $current['part8']),
    ));
    echo '</div>';

    if ($_GET['subact'] == 'part1') {
        if (!submitcheck('submit')) {
            showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part1&page=' . $_GET['page'] . '&cid=' . $cid, 'enctype');
            showtableheader($zclangs['zclang_car_part1']);

            $url = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=upload&inajax=1';
            $zplupload = new zplupload(null, 'attachments', $url, 'images', $attachments, array('uploadimagesbtntext' => $zclangs['zclang_upload_images_btn'], 'delbtntext' => $zclangs['zclang_delete']));
            echo '<tr><td colspan="2" class="td27" s="1">' . $zclangs['zclang_tpl_upload_images_label'] . ':</td></tr>';
            echo '<tr class="noborder"><td colspan="2"><p style="margin-bottom: 5px">' . $zclangs['zclang_tpl_upload_images_size'] . '</p>' . $zplupload->gethtml() . '</td></tr>';
            $zplupload->registerjs();

            showsetting($zclangs['zclang_tpl_brand'], ['bid', $brandsarray], $car['bid'], 'select', '', 0, '', 'onchange="ajaxget(\'' . ADMINSCRIPT . '?action=plugins&operation=config&do=$pluginid&identifier=zpl_car&pmod=admincp_car&act=getseriesbyupid&ae=1&bid=\' + this.value, \'carsid\')"');
            showsetting($zclangs['zclang_tpl_series'], ['sid'], 0, 'select', '', 0, '', 'id="carsid"');
            $adminscript = ADMINSCRIPT;
            echo <<<EOF
<script>
    ajaxget('$adminscript?action=plugins&operation=config&do=$pluginid&identifier=zpl_car&pmod=admincp_car&act=getseriesbyupid&ae=1&bid=$car[bid]&sid=$car[sid]', 'carsid');
</script>
EOF;

            $car['cardtime'] = $car['cardyear'] ? $car['cardyear'] . '-' . $car['cardmonth'] : '';
            $car['listtime'] = $car['listyear'] ? $car['listyear'] . '-' . $car['listmonth'] : '';
            showsetting($zclangs['zclang_tpl_cartype'], 'cartype', $car['cartype'], 'text', '', 0, $zclangs['zclang_tpl_cartype_example']);
            showsetting($zclangs['zclang_tpl_cardtime'], 'cardtime', $car['cardtime'], 'text', '', 0, '', 'id="cardtime"');
            showsetting($zclangs['zclang_tpl_apparentmileage'], 'apparentmileage', $car['apparentmileage'], 'number', '', 0, $zclangs['zclang_tpl_unit_wan'] . $zclangs['zclang_tpl_unit_kilometre'], 'step="0.01"');
            showsetting($zclangs['zclang_tpl_price'], 'price', $car['price'], 'number', '', 0, $zclangs['zclang_tpl_unit_wan'] . $zclangs['zclang_tpl_unit_yuan'], 'step="0.01"');
            showsetting($zclangs['zclang_tpl_expectprice'], 'expectprice', $car['expectprice'], 'number', '', 0, $zclangs['zclang_tpl_unit_wan'] . $zclangs['zclang_tpl_unit_yuan'], 'step="0.01"');
            showsetting($zclangs['zclang_tpl_gearbox'], ['gearbox', $gearboxs], $car['gearbox'], 'select');
            showsetting($zclangs['zclang_tpl_listtime'], 'listtime', $car['listtime'], 'text', '', 0, '', 'id="listtime"');
            showsetting($zclangs['zclang_tpl_carlevel'], ['carlevel', $levels], $car['carlevel'], 'select');
            showsetting($zclangs['zclang_tpl_country'], ['country', $countries], $car['country'], 'select');
            showsetting($zclangs['zclang_tpl_appearance'], ['appearance', $colors], $car['appearance'], 'select');
            showsetting($zclangs['zclang_tpl_transfertimes'], 'transfertimes', $car['transfertimes'], 'number', '', 0, '', 'step="1"');
            showsetting($zclangs['zclang_tpl_enginedis'], 'enginedis', $config['enginedis'], 'number', '', 0, 'L', 'step="0.01"');
            showsetting($zclangs['zclang_tpl_engineemistand'], ['engineemistand', $emissstandards], $config['engineemistand'], 'select');
            showsetting($zclangs['zclang_tpl_enginefueltype'], ['enginefueltype', $fueltypes], $config['enginefueltype'], 'select');
            showsetting($zclangs['zclang_tpl_tcbdrive'], ['tcbdrive', $drives], $config['tcbdrive'], 'select');
            showsetting($zclangs['zclang_tpl_new'], 'new', $car['new'], 'radio', '', 0, '');
            showsetting($zclangs['zclang_tpl_gxbzhoilcons'], 'gxbzhoilcons', $car['gxbzhoilcons'], 'number', '', 0, 'L/100km', 'step="0.01"');
            showsetting($zclangs['zclang_tpl_desc'], 'desc', $car['desc'], 'textarea', '', 0, '');
            $car['topexpireat'] = $car['topexpireat'] ? dgmdate($car['topexpireat'], 'Y-n-j H:i') : "";
            showsetting($zclangs['zclang_top_label'], 'topexpireat', $car['topexpireat'], 'calendar', '', 0, '', 1);
            showsetting($zclangs['zclang_car_isshow'], 'isshow', $car['isshow']);
            showsetting($zclangs['zclang_car_issold'], 'issold', $car['issold']);

            showsubmit('submit');
            showtablefooter(); /*dism �� taobao �� com*/
            showformfooter();
        } else {
            $aarray = array();
            $postattachments = $_POST['attachments'];
            while ($current = current($postattachments)) {
                $next = next($postattachments);
                $next2 = next($postattachments);
                $aarray[] = array(
                    'aid' => $current['aid'],
                    'attachment' => $next['attachment'],
                    'filename' => $next2['filename'],
                );
                next($postattachments);
            }
            $aids = array();
            foreach ($aarray as $item) {
                if (intval($item['aid']) == 0) {
                    $f = $_G['setting']['attachdir'] . $item['attachment'];
                    list($width) = getimagesize($f);
                    $adata = array(
                        'cid' => $cid,
                        'uid' => $_G['uid'],
                        'dateline' => time(),
                        'filename' => $item['filename'],
                        'filesize' => filesize($f),
                        'attachment' => $item['attachment'],
                        'width' => $width,
                    );
                    C::t('#zpl_car#zpl_car_attachment')->insert($adata);
                } else {
                    $aids[] = $item['aid'];
                }
            }
            $delaids = array_diff(helper::get_column($attachments, 'aid'), $aids);
            C::t('#zpl_car#zpl_car_attachment')->delete($delaids);

            $cardata = array();
            $cardata['bid'] = $_POST['bid'];
            $cardata['sid'] = $_POST['sid'];
            $cardata['cartype'] = $_POST['cartype'];
            $cardata['apparentmileage'] = $_POST['apparentmileage'];
            $cardata['price'] = $_POST['price'];
            $cardata['expectprice'] = $_POST['expectprice'];
            $cardata['gearbox'] = $_POST['gearbox'];
            $cardata['carlevel'] = $_POST['carlevel'];
            $cardata['country'] = $_POST['country'];
            $cardata['appearance'] = $_POST['appearance'];
            $cardata['transfertimes'] = $_POST['transfertimes'];
            $cardata['new'] = $_POST['new'];
            $cardata['gxbzhoilcons'] = $_POST['gxbzhoilcons'];
            $cardata['desc'] = $_POST['desc'];

            if (strpos($_GET['topexpireat'], '-')) {
                $topexpireat = strtotime($_GET['topexpireat']);
            } else {
                $topexpireat = 0;
            }
            $cardata['topexpireat'] = $topexpireat;

            $cardata['isshow'] = $_POST['isshow'];
            $cardata['issold'] = $_POST['issold'];

            if (isset($_POST['cardtime'])) {
                $cardarr = explode('-', trim($_POST['cardtime']));
                $cardata['cardyear'] = $cardarr[0];
                $cardata['cardmonth'] = $cardarr[1];
            }
            if (isset($_POST['listtime'])) {
                $listarr = explode('-', trim($_POST['listtime']));
                $cardata['listyear'] = $listarr[0];
                $cardata['listmonth'] = $listarr[1];
            }
            $cardata['updatetime'] = time();
            C::t('#zpl_car#zpl_car')->update($cid, $cardata);

            $configdata = array();
            $configdata['enginedis'] = $_POST['enginedis'];
            $configdata['engineemistand'] = $_POST['engineemistand'];
            $configdata['enginefueltype'] = $_POST['enginefueltype'];
            $configdata['tcbdrive'] = $_POST['tcbdrive'];
            C::t('#zpl_car#zpl_car_config')->update($cid, $configdata);

            cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part1&page=' . $_GET['page'] . '&cid=' . $cid, 'succeed');
        }
    } elseif ($_GET['subact'] == 'part2') {
        if (!submitcheck('submit')) {
            showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part2&page=' . $_GET['page'] . '&cid=' . $cid, 'enctype');
            showtableheader($zclangs['zclang_car_part2']);

            showsetting($zclangs['zclang_tpl_engineintakeform'], ['engineintakeform', $iarray], $config['engineintakeform'], 'select');
            showsetting($zclangs['zclang_tpl_enginecylinder'], 'enginecylinder', $config['enginecylinder'], 'text', '', 0, $zclangs['zclang_tpl_enginecylinder_example']);
            showsetting($zclangs['zclang_tpl_enginemaxhorsepower'], 'enginemaxhorsepower', $config['enginemaxhorsepower'], 'number', '', 0, 'Ps');
            showsetting($zclangs['zclang_tpl_enginemaxpower'], 'enginemaxpower', $config['enginemaxpower'], 'number', '', 0, 'kW');
            showsetting($zclangs['zclang_tpl_enginemaxtorque'], 'enginemaxtorque', $config['enginemaxtorque'], 'number', '', 0, 'N*m');
            showsetting($zclangs['zclang_tpl_engineroz'], 'engineroz', $config['engineroz'], 'number', '', 0, '#');

            showsubmit('submit');
            showtablefooter(); /*dism �� taobao �� com*/
            showformfooter();
        } else {
            $configdata = array();
            $configdata['engineintakeform'] = $_POST['engineintakeform'];
            $configdata['enginecylinder'] = $_POST['enginecylinder'];
            $configdata['enginemaxhorsepower'] = $_POST['enginemaxhorsepower'];
            $configdata['enginemaxpower'] = $_POST['enginemaxpower'];
            $configdata['enginemaxtorque'] = $_POST['enginemaxtorque'];
            $configdata['engineroz'] = $_POST['engineroz'];
            C::t('#zpl_car#zpl_car_config')->update($cid, $configdata);

            cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part2&page=' . $_GET['page'] . '&cid=' . $cid, 'succeed');
        }
    } elseif ($_GET['subact'] == 'part3') {
        if (!submitcheck('submit')) {
            showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part3&page=' . $_GET['page'] . '&cid=' . $cid, 'enctype');
            showtableheader($zclangs['zclang_car_part3']);

            showsetting($zclangs['zclang_tpl_tcbttype'], 'tcbttype', $config['tcbttype'], 'text', '', 0, $zclangs['zclang_tpl_tcbttype_example']);
            showsetting($zclangs['zclang_tpl_tcbgears'], 'tcbgears', $config['tcbgears'], 'number');
            showsetting($zclangs['zclang_tpl_tcbassistance'], 'tcbassistance', $config['tcbassistance'], 'text', '', 0, $zclangs['zclang_tpl_tcbassistance_example']);
            showsetting($zclangs['zclang_tpl_tcbrearsusp'], 'tcbrearsusp', $config['tcbrearsusp'], 'text', '', 0, $zclangs['zclang_tpl_tcbrearsusp_example']);
            showsetting($zclangs['zclang_tpl_tcbfrontbrake'], 'tcbfrontbrake', $config['tcbfrontbrake'], 'text', '', 0, $zclangs['zclang_tpl_tcbfrontbrake_example']);
            showsetting($zclangs['zclang_tpl_tcbrearbrake'], 'tcbrearbrake', $config['tcbrearbrake'], 'text', '', 0, $zclangs['zclang_tpl_tcbrearbrake_example']);
            showsetting($zclangs['zclang_tpl_tcbparkingbraking'], 'tcbparkingbraking', $config['tcbparkingbraking'], 'text', '', 0, $zclangs['zclang_tpl_tcbparkingbraking_example']);
            showsetting($zclangs['zclang_tpl_tcbfronttire'], 'tcbfronttire', $config['tcbfronttire'], 'text', '', 0, $zclangs['zclang_tpl_tcbfronttire_examplle']);
            showsetting($zclangs['zclang_tpl_tcbreartire'], 'tcbreartire', $config['tcbreartire'], 'text', '', 0, $zclangs['zclang_tpl_tcbreartire_examplle']);

            showsubmit('submit');
            showtablefooter(); /*dism �� taobao �� com*/
            showformfooter();
        } else {
            $configdata = array();
            $configdata['tcbttype'] = $_POST['tcbttype'];
            $configdata['tcbgears'] = $_POST['tcbgears'];
            $configdata['tcbassistance'] = $_POST['tcbassistance'];
            $configdata['tcbrearsusp'] = $_POST['tcbrearsusp'];
            $configdata['tcbfrontbrake'] = $_POST['tcbfrontbrake'];
            $configdata['tcbrearbrake'] = $_POST['tcbrearbrake'];
            $configdata['tcbparkingbraking'] = $_POST['tcbparkingbraking'];
            $configdata['tcbfronttire'] = $_POST['tcbfronttire'];
            $configdata['tcbreartire'] = $_POST['tcbreartire'];
            C::t('#zpl_car#zpl_car_config')->update($cid, $configdata);

            cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part3&page=' . $_GET['page'] . '&cid=' . $cid, 'succeed');
        }
    } elseif ($_GET['subact'] == 'part4') {
        if (!submitcheck('submit')) {
            showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part4&page=' . $_GET['page'] . '&cid=' . $cid, 'enctype');
            showtableheader($zclangs['zclang_car_part4']);

            showsetting($zclangs['zclang_tpl_cblength'], 'cblength', $config['cblength'], 'number', '', 0, 'mm');
            showsetting($zclangs['zclang_tpl_cbwidth'], 'cbwidth', $config['cbwidth'], 'number', '', 0, 'mm');
            showsetting($zclangs['zclang_tpl_cbheight'], 'cbheight', $config['cbheight'], 'number', '', 0, 'mm');
            showsetting($zclangs['zclang_tpl_cbcardoors'], 'cbcardoors', $config['cbcardoors'], 'number', '', 0, '');
            showsetting($zclangs['zclang_tpl_cbseats'], 'cbseats', $config['cbseats'], 'number', '', 0, '');
            showsetting($zclangs['zclang_tpl_cbstructure'], 'cbstructure', $config['cbstructure'], 'text', '', 0, $zclangs['zclang_tpl_cbstructure_example']);
            showsetting($zclangs['zclang_tpl_cbtankvolume'], 'cbtankvolume', $config['cbtankvolume'], 'number', '', 0, 'L', 'step="0.01"');
            showsetting($zclangs['zclang_tpl_cbtrunkvolume'], 'cbtrunkvolume', $config['cbtrunkvolume'], 'text', '', 0, 'L', 'step="0.01"');

            showsubmit('submit');
            showtablefooter(); /*dism �� taobao �� com*/
            showformfooter();
        } else {
            $configdata = array();
            $configdata['cblength'] = $_POST['cblength'];
            $configdata['cbwidth'] = $_POST['cbwidth'];
            $configdata['cbheight'] = $_POST['cbheight'];
            $configdata['cbcardoors'] = $_POST['cbcardoors'];
            $configdata['cbseats'] = $_POST['cbseats'];
            $configdata['cbstructure'] = $_POST['cbstructure'];
            $configdata['cbtankvolume'] = $_POST['cbtankvolume'];
            $configdata['cbtrunkvolume'] = $_POST['cbtrunkvolume'];
            C::t('#zpl_car#zpl_car_config')->update($cid, $configdata);

            cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part4&page=' . $_GET['page'] . '&cid=' . $cid, 'succeed');
        }
    } elseif ($_GET['subact'] == 'part5') {
        if (!submitcheck('submit')) {
            showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part5&page=' . $_GET['page'] . '&cid=' . $cid, 'enctype');
            showtableheader($zclangs['zclang_car_part5']);

            showsetting($zclangs['zclang_tpl_secujsyqn'], ['secujsyqn', $harray], $config['secujsyqn'], 'select');
            showsetting($zclangs['zclang_tpl_secufjsqn'], ['secufjsqn', $harray], $config['secufjsqn'], 'select');
            showsetting($zclangs['zclang_tpl_secutyjczz'], ['secutyjczz', $harray], $config['secutyjczz'], 'select');
            showsetting($zclangs['zclang_tpl_secuaqdwxts'], ['secuaqdwxts', $harray], $config['secuaqdwxts'], 'select');
            showsetting($zclangs['zclang_tpl_secuetzyjk'], ['secuetzyjk', $harray], $config['secuetzyjk'], 'select');
            showsetting($zclangs['zclang_tpl_secucnzks'], ['secucnzks', $harray], $config['secucnzks'], 'select');
            showsetting($zclangs['zclang_tpl_secuwysqdxt'], ['secuwysqdxt', $harray], $config['secuwysqdxt'], 'select');
            showsetting($zclangs['zclang_tpl_secuwysjrxt'], ['secuwysjrxt', $harray], $config['secuwysjrxt'], 'select');
            showsetting($zclangs['zclang_tpl_secuabs'], ['secuabs', $harray], $config['secuabs'], 'select');
            showsetting($zclangs['zclang_tpl_secuesp'], ['secuesp', $harray], $config['secuesp'], 'select');

            showsubmit('submit');
            showtablefooter(); /*dism �� taobao �� com*/
            showformfooter();
        } else {
            $configdata = array();
            $configdata['secujsyqn'] = $_POST['secujsyqn'];
            $configdata['secufjsqn'] = $_POST['secufjsqn'];
            $configdata['secutyjczz'] = $_POST['secutyjczz'];
            $configdata['secuaqdwxts'] = $_POST['secuaqdwxts'];
            $configdata['secuetzyjk'] = $_POST['secuetzyjk'];
            $configdata['secucnzks'] = $_POST['secucnzks'];
            $configdata['secuwysqdxt'] = $_POST['secuwysqdxt'];
            $configdata['secuwysjrxt'] = $_POST['secuwysjrxt'];
            $configdata['secuabs'] = $_POST['secuabs'];
            $configdata['secuesp'] = $_POST['secuesp'];
            C::t('#zpl_car#zpl_car_config')->update($cid, $configdata);

            cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part5&page=' . $_GET['page'] . '&cid=' . $cid, 'succeed');
        }
    } elseif ($_GET['subact'] == 'part6') {
        if (!submitcheck('submit')) {
            showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part6&page=' . $_GET['page'] . '&cid=' . $cid, 'enctype');
            showtableheader($zclangs['zclang_car_part6']);

            showsetting($zclangs['zclang_tpl_insidezpfxp'], ['insidezpfxp', $harray], $config['insidezpfxp'], 'select');
            showsetting($zclangs['zclang_tpl_insidezpzy'], ['insidezpzy', $harray], $config['insidezpzy'], 'select');
            showsetting($zclangs['zclang_tpl_insidedgnfxp'], ['insidedgnfxp', $harray], $config['insidedgnfxp'], 'select');
            showsetting($zclangs['zclang_tpl_insidezktcsdp'], ['insidezktcsdp', $harray], $config['insidezktcsdp'], 'select');
            showsetting($zclangs['zclang_tpl_insidekt'], ['insidekt', $harray], $config['insidekt'], 'select');
            showsetting($zclangs['zclang_tpl_insidedsxh'], ['insidedsxh', $harray], $config['insidedsxh'], 'select');
            showsetting($zclangs['zclang_tpl_insidegpsdhxt'], ['insidegpsdhxt', $harray], $config['insidegpsdhxt'], 'select');
            showsetting($zclangs['zclang_tpl_insidedcyxxt'], ['insidedcyxxt', $harray], $config['insidedcyxxt'], 'select');
            showsetting($zclangs['zclang_tpl_insideczld'], ['insideczld', $harray], $config['insideczld'], 'select');

            showsubmit('submit');
            showtablefooter(); /*dism �� taobao �� com*/
            showformfooter();
        } else {
            $configdata = array();
            $configdata['insidezpfxp'] = $_POST['secujsyqn'];
            $configdata['insidezpzy'] = $_POST['secufjsqn'];
            $configdata['insidedgnfxp'] = $_POST['secutyjczz'];
            $configdata['insidezktcsdp'] = $_POST['secuaqdwxts'];
            $configdata['insidekt'] = $_POST['secuetzyjk'];
            $configdata['insidedsxh'] = $_POST['secucnzks'];
            $configdata['insidegpsdhxt'] = $_POST['secuwysqdxt'];
            $configdata['insidedcyxxt'] = $_POST['secuwysjrxt'];
            $configdata['insideczld'] = $_POST['secuabs'];
            C::t('#zpl_car#zpl_car_config')->update($cid, $configdata);

            cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part6&page=' . $_GET['page'] . '&cid=' . $cid, 'succeed');
        }
    } elseif ($_GET['subact'] == 'part7') {
        if (!submitcheck('submit')) {
            showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part7&page=' . $_GET['page'] . '&cid=' . $cid, 'enctype');
            showtableheader($zclangs['zclang_car_part7']);

            showsetting($zclangs['zclang_tpl_externalddcc'], ['externalddcc', $harray], $config['externalddcc'], 'select');
            showsetting($zclangs['zclang_tpl_externalqjtc'], ['externalqjtc', $harray], $config['externalqjtc'], 'select');
            showsetting($zclangs['zclang_tpl_externalddxhm'], ['externalddxhm', $harray], $config['externalddxhm'], 'select');
            showsetting($zclangs['zclang_tpl_externalgyhbx'], ['externalgyhbx', $harray], $config['externalgyhbx'], 'select');
            showsetting($zclangs['zclang_tpl_externalqhddcc'], ['externalqhddcc', $harray], $config['externalqhddcc'], 'select');
            showsetting($zclangs['zclang_tpl_externalhys'], ['externalhys', $harray], $config['externalhys'], 'select');

            showsubmit('submit');
            showtablefooter(); /*dism �� taobao �� com*/
            showformfooter();
        } else {
            $configdata = array();
            $configdata['externalddcc'] = $_POST['externalddcc'];
            $configdata['externalqjtc'] = $_POST['externalqjtc'];
            $configdata['externalddxhm'] = $_POST['externalddxhm'];
            $configdata['externalgyhbx'] = $_POST['externalgyhbx'];
            $configdata['externalqhddcc'] = $_POST['externalqhddcc'];
            $configdata['externalhys'] = $_POST['externalhys'];
            C::t('#zpl_car#zpl_car_config')->update($cid, $configdata);

            cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part7&page=' . $_GET['page'] . '&cid=' . $cid, 'succeed');
        }
    } elseif ($_GET['subact'] == 'part8') {
        if (!submitcheck('submit')) {
            showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part8&page=' . $_GET['page'] . '&cid=' . $cid, 'enctype');
            showtableheader($zclangs['zclang_car_part8']);

            showsetting($zclangs['zclang_tpl_lightingjgd'], ['lightingjgd', $harray], $config['lightingjgd'], 'select');
            showsetting($zclangs['zclang_tpl_lightingddgdkt'], ['lightingddgdkt', $harray], $config['lightingddgdkt'], 'select');
            showsetting($zclangs['zclang_tpl_lightingzdtd'], ['lightingzdtd', $harray], $config['lightingzdtd'], 'select');
            showsetting($zclangs['zclang_tpl_lightingzxfzd'], ['lightingzxfzd', $harray], $config['lightingzxfzd'], 'select');
            showsetting($zclangs['zclang_tpl_lightingqwd'], ['lightingqwd', $harray], $config['lightingqwd'], 'select');

            showsubmit('submit');
            showtablefooter(); /*dism �� taobao �� com*/
            showformfooter();
        } else {
            $configdata = array();
            $configdata['lightingjgd'] = $_POST['lightingjgd'];
            $configdata['lightingddgdkt'] = $_POST['lightingddgdkt'];
            $configdata['lightingzdtd'] = $_POST['lightingzdtd'];
            $configdata['lightingzxfzd'] = $_POST['lightingzxfzd'];
            $configdata['lightingqwd'] = $_POST['lightingqwd'];
            C::t('#zpl_car#zpl_car_config')->update($cid, $configdata);

            cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_car&act=edit&subact=part8&page=' . $_GET['page'] . '&cid=' . $cid, 'succeed');
        }
    }
} elseif ($act == 'getseriesbyupid') {
    include template('common/header_ajax');
    echo serieslist($_GET['bid'], $_GET['sid'], $_GET['ae']);
    include template('common/footer_ajax');
} elseif ($act == 'upload') {
    ob_clean();
    header('Content-Type: application/json');
    $file = $_FILES['file'];
    $upload = new discuz_upload();
    $upload->init($file, 'common', random(3, 1), 'plugin_zpl_car_' . date('YmdHis') . strtolower(random(16)));
    if ($upload->attach['isimage']) {
        if ($upload->save()) {
            echo helper_json::encode(array('status' => 1, 'data' => [
                'src' => helper::gethandledurl('common/' . $upload->attach['attachment']),
                'attachment' => 'common/' . $upload->attach['attachment'],
                'filename' => trim($file['name'])
            ]));
        } else {
            echo helper_json::encode(array('status' => 0, 'msg' => $upload->errormessage()));
        }
    } else {
        echo helper_json::encode(array('status' => 0, 'msg' => $zclangs['zclang_ajax_upload_notimage_error']));
    }
    dexit();
}

echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
echo <<<EOF
<script type="text/javascript">
    layui.use(['laydate'], function(){
        var laydate = layui.laydate;
        laydate.render({
            elem: '#cardtime',
            type: 'month'
        });
        laydate.render({
            elem: '#listtime',
            type: 'month'
        });
    });
</script>
EOF;

function brandlist($bid)
{
    loadcache(['plugin', 'zpl_car_brands', 'zpl_car_langs']);
    global $_G;
    $brands = $_G['cache']['zpl_car_brands'];
    $zclangs = $_G['cache']['zpl_car_langs'];

    $html = '<option value="">' . $zclangs['zclang_car_brand_level_1'] . '</option>';
    foreach ($brands as $brand) {
        $selected = $bid == $brand['id'] ? ' selected' : '';
        $html .= '<option value="' . $brand['id'] . '"' . $selected . '>' . $brand['name'] . '</option>';
    }
    return $html;
}

function serieslist($upid, $sid, $ae = 0)
{
    loadcache(['plugin', 'zpl_car_brand_list', 'zpl_car_langs']);
    global $_G;
    $list = $_G['cache']['zpl_car_brand_list'];
    $zclangs = $_G['cache']['zpl_car_langs'];

    if ($ae) {
        $select = '<select name="sid" style="min-width: 150px;"><option value="">' . $zclangs['zclang_tpl_choose'] . '</option>';
    } else {
        $select = '<select name="sid" style="min-width: 150px;"><option value="">' . $zclangs['zclang_car_brand_level_2'] . '</option>';
    }
    if (isset($list[$upid])) {
        $series = $list[$upid]['series'];
        foreach ($series as $item) {
            $selected = $sid == $item['id'] ? ' selected' : '';
            $select .= '<option value="' . $item['id'] . '"' . $selected . '>' . $item['name'] . '</option>';
        }
    }
    $select .= '</select>';
    return $select;
}
//From: Dism_taobao-com
?>