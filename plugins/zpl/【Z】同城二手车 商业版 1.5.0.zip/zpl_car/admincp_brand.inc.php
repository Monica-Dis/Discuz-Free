<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zpl_car/helper.class.php';

global $_G;
loadcache(['zpl_car_langs']);
$zclangs = $_G['cache']['zpl_car_langs'];

$pid = intval($_GET['pid']);
$ppp = 5;
$page = max(1, intval($_GET['page']));

if (!submitcheck('bsubmit')) {
    if ($_GET['act'] == 'addbrand') {
        if (!submitcheck('addbrandsubmit')) {
            showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_brand&act=addbrand&pid=' . $pid . '&page=' . $page, 'enctype');
            showtableheader($zclangs['zclang_car_brand_add']);
            showsetting($zclangs['zclang_car_brand_image'], 'image', '', 'filetext', 0, 0);
            showsetting($zclangs['zclang_car_brand_name'], 'name', '', 'text');
            showsetting($zclangs['zclang_car_brand_pinyin'], 'pinyin', '', 'text');
            showsetting($zclangs['zclang_car_brand_letter'], 'letter', '', 'text', 0, 0, $zclangs['zclang_car_brand_letter_comment']);
            showsetting($zclangs['zclang_car_brand_displayorder'], 'displayorder', '', 'text');
            showsetting($zclangs['zclang_car_brand_showhomepage'], 'showhomepage', '0');
            showsubmit('addbrandsubmit');
            showtablefooter(); /*dism �� taobao �� com*/
            showformfooter();
        } else {
            if ($_FILES['image']['tmp_name']) {
                $upload = new discuz_upload();
                if (!$upload->init($_FILES['image'], 'common', random(3, 1), 'plugin_zpl_car_' . date('YmdHis') . strtolower(random(16))) || !$upload->save()) {
                    cpmsg($upload->errormessage(), '', 'error');
                }
                $_GET['image'] = 'common/' . $upload->attach['attachment'];;
            }

            if (empty($_GET['name'])) {
                cpmsg($zclangs['zclang_car_brand_name_err'], '', 'error');
            }

            $data = array(
                'image' => dhtmlspecialchars(trim($_GET['image'])),
                'name' => dhtmlspecialchars(trim($_GET['name'])),
                'pinyin' => dhtmlspecialchars(trim($_GET['pinyin'])),
                'letter' => strtoupper(dhtmlspecialchars(trim($_GET['letter']))),
                'displayorder' => intval($_GET['displayorder']),
                'showhomepage' => intval($_GET['showhomepage']),
            );
            C::t('#zpl_car#zpl_car_brand')->insert($data);

            updatecache('zpl_car:zpl_car_brand');

            cpmsg($zclangs['zclang_car_brand_add_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_brand&pid=' . $pid . '&page=' . $page, 'succeed');
        }
    } elseif ($_GET['delete']) {
        $delid = $_GET['delete'][0];
        if (C::t('#zpl_car#zpl_car')->fetch_all_by_bid_or_sid($delid)) {
            cpmsg($zclangs['zclang_car_brand_delete_error'], '', 'error');
        } else {
            C::t('#zpl_car#zpl_car_brand')->delete($delid);
            updatecache('zpl_car:zpl_car_brand');
            cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_brand&pid=' . $pid . '&page=' . $page, 'succeed');
        }
    } else {
        showtips($zclangs['zclang_car_brand_tips']);

        echo '<br>';

        showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_brand&pid=' . $pid . '&page=' . $page, 'enctype');
        if ($pid === 0) {
            showtableheader($zclangs['zclang_car_brand_list']);
        } else {
            showtableheader($zclangs['zclang_car_brand_series_list']);
        }

        $values = C::t('#zpl_car#zpl_car_brand')->fetch_all_brands_lvl1();
        $html = '<select name="brand_id" id="brand-id" onchange="refresh(this.value, ' . $page . ')">';
        $html .= '<option value="">' . $zclangs['zclang_car_brand_level_1'] . '</option>';
        foreach ($values as $value) {
            $selected = $value['id'] == $pid ? ' selected="selected"' : '';
            $html .= '<option value="' . $value['id'] . '"' . $selected . '>' . $value['name'] . '</option>';
        }
        $html .= '</select>';
        echo $zclangs['zclang_car_brand_choose'] . ' &nbsp; ' . $html . ' &nbsp; ' . '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_brand&act=addbrand&pid=' . $pid . '&page=' . $page . '" class="addtr">' . $zclangs['zclang_car_brand_add'] . '</a>';

        $titledisplayorder = $zclangs['zclang_car_brand_displayorder'];
        $titleimage = $zclangs['zclang_car_brand_image'];
        $titlename = $zclangs['zclang_car_brand_name'];
        $titlepinyin = $zclangs['zclang_car_brand_pinyin'];
        $titleletter = $zclangs['zclang_car_brand_letter'];
        $titleshowhomepage = $zclangs['zclang_car_brand_showhomepage_title'];
        $titleop = $zclangs['zclang_operation'];
        !$pid ? showsubtitle(array($titledisplayorder, $titleimage, '', $titlename, $titlepinyin, $titleletter, $titleshowhomepage, $titleop), 'header', array('', 'style="text-align: center;"'))
            : showsubtitle(array($titledisplayorder, $titlename, $titlepinyin, $titleop));

        $rows = C::t('#zpl_car#zpl_car_brand')->fetch_all_by_upid($pid, $ppp, $page);
        foreach ($rows as $row) {
            $arr = array();
            $arr[] = '<input type="text" id="displayorder_' . $row['id'] . '" class="txt" name="displayorder[' . $row['id'] . ']" value="' . $row['displayorder'] . '"/>';
            if (!$pid) {
                $arr[] = $row['image'] ? '<img src="' . helper::gethandledurl($row['image']) . '" style="width: 60px; height: 60px">' : '';

                $imagevalue = $row['image'];
                $varname = 'image[' . $row['id'] . ']';
                $extra = '';
                $defaulttype = $imagevalue ? 1 : 0;
                $id = 'file' . random(2);
                $s = "\n";
                $s .= '<input id="' . $id . '_0" style="display:' . ($defaulttype ? 'none' : '') . '" name="' . ($defaulttype ? 'TMP' : '') . $varname . '" value="" type="file" class="txt uploadbtn marginbot" />' .
                    '<input id="' . $id . '_1" style="display:' . (!$defaulttype ? 'none' : '') . '" name="' . (!$defaulttype ? 'TMP' : '') . $varname . '" value="' . dhtmlspecialchars($imagevalue) . '" type="text" class="txt marginbot" /><br />' .
                    '<a id="' . $id . '_0a" style="' . (!$defaulttype ? 'font-weight:bold' : '') . '" href="javascript:;" onclick="$(\'' . $id . '_1a\').style.fontWeight = \'\';this.style.fontWeight = \'bold\';$(\'' . $id . '_1\').name = \'TMP' . $varname . '\';$(\'' . $id . '_0\').name = \'' . $varname . '\';$(\'' . $id . '_0\').style.display = \'\';$(\'' . $id . '_1\').style.display = \'none\'">' . cplang('switch_upload') . '</a>&nbsp;' .
                    '<a id="' . $id . '_1a" style="' . ($defaulttype ? 'font-weight:bold' : '') . '" href="javascript:;" onclick="$(\'' . $id . '_0a\').style.fontWeight = \'\';this.style.fontWeight = \'bold\';$(\'' . $id . '_0\').name = \'TMP' . $varname . '\';$(\'' . $id . '_1\').name = \'' . $varname . '\';$(\'' . $id . '_1\').style.display = \'\';$(\'' . $id . '_0\').style.display = \'none\'">' . cplang('switch_url') . '</a>';
                $arr[] = $s;
            }
            $arr[] = '<p id="p_name_' . $row['id'] . '"><input type="text" id="input_name_' . $row['id'] . '" class="txt" name="name[' . $row['id'] . ']" value="' . $row['name'] . '"/></p>';
            $arr[] = '<p id="p_pinyin_' . $row['id'] . '"><input type="text" id="input_pinyin_' . $row['id'] . '" class="txt" name="pinyin[' . $row['id'] . ']" value="' . $row['pinyin'] . '"/></p>';
            if (!$pid) {
                $arr[] = '<p id="p_letter_' . $row['id'] . '"><input type="text" id="input_letter_' . $row['id'] . '" class="txt" name="letter[' . $row['id'] . ']" value="' . $row['letter'] . '"/></p>';
                $arr[] = '<input type="checkbox" name="showhomepage[' . $row['id'] . ']" value="1" class="checkbox"' . ($row['showhomepage'] ? ' checked="checked" ' : '') . ' />';
            }
            $arr[] = '<a onclick="javascript:return confirm(\'' . $zclangs['zclang_confirm_delete_tip'] . '\');" href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_brand&pid=' . $pid . '&page=' . $page . '&delete[]=' . $row['id'] . '">' . cplang('delete') . '</a></th></tr>';
            if (!$pid) {
                showtablerow('id="td_' . $row['id'] . '"', array('class="td25"', 'style="text-align: center;"', 'class="td26"'), $arr);
            } else {
                showtablerow('id="td_' . $row['id'] . '"', array('class="td25"', 'class="td29"', 'class="td29"'), $arr);
            }
        }

        if ($pid) {
            echo '<td colspan="4"><div><a href="###" onclick="addrow(this, 0, 0)" class="addtr">' . $zclangs['zclang_car_brand_series_add'] . '</a></div></td></tr>';
        }

        if (!$pid) {
            $multipage = multi(count($values), $ppp, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_brand&pid=' . $pid . '&page=' . $page);
            showsubmit('bsubmit', 'submit', '', '', $multipage);
        } else {
            showsubmit('bsubmit', 'submit', '');
        }

        $adminurl = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_brand';
        echo <<<SCRIPT
<script type="text/javascript">
    var rowtypedata = [
		[[1,'<input name="newdisplayorder[]" value="" size="3" type="text" class="txt">', 'td25'], [1,'<input name="newname[]" value="" size="3" type="text" class="txt">', 'td29'], [1,'<input name="newpinyin[]" value="" size="3" type="text" class="txt">', 'td29'], [1, '', '']]
	];

    function refresh(pid, page) {
        location.href = "$adminurl" + "&pid=" + pid + "&page=" + page;
    }
</script>
SCRIPT;

        showtablefooter(); /*dism �� taobao �� com*/
        showformfooter();
    }
} else {
    $ids = array();
    $data = array();
    $fields = ['displayorder', 'image', 'name', 'pinyin', 'letter', 'showhomepage'];
    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            if ($field == 'displayorder') {
                $ids = array_keys($_POST[$field]);
                foreach ($ids as $id) {
                    $data[$id]['showhomepage'] = 0;
                }
            }
            foreach ($_POST[$field] as $k => $v) {
                if ($field == 'displayorder' || $field == 'showhomepage') {
                    $data[$k][$field] = intval($v);
                } else {
                    if ($field == 'letter') {
                        $data[$k][$field] = strtoupper(dhtmlspecialchars(trim($v)));
                    } else {
                        $data[$k][$field] = dhtmlspecialchars(trim($v));
                    }
                }
            }
        }
    }

    if ($_FILES['image']['tmp_name']) {
        $images = array();
        foreach ($_FILES['image'] as $k => $v) {
            foreach ($v as $kk => $vv) {
                $images[$kk][$k] = $vv;
            }
        }
        foreach ($images as $k => $image) {
            if ($image['name']) {
                $upload = new discuz_upload();
                if (!$upload->init($image, 'common', random(3, 1), 'plugin_zpl_car_' . date('YmdHis') . strtolower(random(16))) || !$upload->save()) {
                    cpmsg($upload->errormessage(), '', 'error');
                }
                $data[$k]['image'] = 'common/' . $upload->attach['attachment'];
            }
        }
    }
    foreach ($data as $id => $datum) {
        $fieldsdata = array();
        foreach ($fields as $field) {
            if (isset($datum[$field])) {
                $fieldsdata[$field] = $datum[$field];
            }
        }
        C::t('#zpl_car#zpl_car_brand')->update($id, $fieldsdata);
    }

    if (is_array($_GET['newname'])) {
        foreach ($_GET['newname'] as $k => $v) {
            $v = dhtmlspecialchars(trim($v));
            if (!empty($v)) {
                $pinyin = dhtmlspecialchars(trim($_GET['newpinyin'][$k]));
                $displayorder = intval($_GET['newdisplayorder'][$k]);
                $data = array(
                    'name' => $v,
                    'pinyin' => $pinyin,
                    'upid' => $pid,
                    'displayorder' => $displayorder
                );
                C::t('#zpl_car#zpl_car_brand')->insert($data);
            }
        }
    }

    updatecache('zpl_car:zpl_car_brand');

    cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_brand&pid=' . $pid . '&page=' . $page, 'succeed');
}
//From: Dism_taobao-com
?>