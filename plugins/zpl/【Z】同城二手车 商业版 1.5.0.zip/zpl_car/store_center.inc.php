<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zpl_car/helper.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/wechat.lib.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/wechat.class.php';

loadcache(['plugin', 'zpl_car_langs']);
global $_G;
$vars = $_G['cache']['plugin']['zpl_car'];
$zclangs = $_G['cache']['zpl_car_langs'];

// login
$returnurl = $_G['siteurl'] . './plugin.php?id=zpl_car:store_center';
if (empty($_G['uid'])) {
    $openwxlogin = $vars['openwxlogin'];
    $appid = $vars['wxappid'];
    $appsecret = $vars['wxappsecret'];

    if (helper::isweixin() && $openwxlogin == 1) {
        // WX login
        if (!isset($_GET['code'])) {
            $redirecturi = urlencode($returnurl);
            $wxurl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$appid}&redirect_uri={$redirecturi}&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";
            dheader('location: ' . $wxurl);
        } else {
            require_once libfile('function/member');

            $wechat_client = new WeChatClient($appid, $appsecret);

            $code = $_GET['code'];
            $tokeninfo = $wechat_client->getAccessTokenByCode($code);
            if ($tokeninfo['openid']) {
                $openid = $tokeninfo['openid'];
                $mp = C::t('#zpl_car#zpl_car_user_wxmp')->fetch_by_openid($openid);
                if ($mp) {
                    $member = getuserbyuid($mp['uid'], 1);
                    setloginstatus($member, 1296000);
                } else {
                    $uid = ZplWeChat::register(ZplWeChat::getnewname($openid), 1);
                    if ($uid) {
                        $data = array(
                            'uid' => $uid,
                            'openid' => $openid,
                        );
                        C::t('#zpl_car#zpl_car_user_wxmp')->insert($data);
                    }
                }
                dheader('location: ' . $returnurl);
            } else {
                // common login
                showmessage('not_loggedin', NULL, array(), array('login' => 1));
            }
        }
    } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX") !== false) {
        // MAGAPP login
        include_once template('zpl_car:mag_login');
        dexit();
    } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "QianFan") !== false) {
        // QFAPP login
        include_once template('zpl_car:qianfan_login');
        dexit();
    } else {
        // common login
        showmessage('not_loggedin', NULL, array(), array('login' => 1));
    }
}

$store = C::t('#zpl_car#zpl_car_store')->fetch_by_uid($_G['uid']);
if (!$store) {
    dheader('location: plugin.php?id=zpl_car:store_settlein');
} else {
    if (($vars['storesettleinopencheck'] == 1 && $store['checkstatus'] == 1) &&
        (!$vars['storeopensettleinpay'] || ($vars['storeopensettleinpay'] == 1 && $store['paystatus'] == 1))
    ) {
        dheader('location: plugin.php?id=zpl_car:my');
    } elseif ((($vars['storesettleinopencheck'] == 1 && $store['checkstatus'] == 2) && ($vars['storeopensettleinpay'] == 1 && $store['paystatus'] == 0)) ||
        ($vars['storesettleinopencheck'] == 1 && $store['checkstatus'] == 3) ||
        ($vars['storeopensettleinpay'] == 1 && $store['paystatus'] == 0)
    ) {
        dheader('location: plugin.php?id=zpl_car:store_settlein');
    }
}

$action = $_GET['action'];
if ($action == 'info') {
    if (submitcheck('storeinfosubmit')) {
        $data = array(
            'name' => dhtmlspecialchars(trim($_POST['name'])),
            'image' => $_POST['image'],
            'idfront' => $_POST['idfront'],
            'idback' => $_POST['idback'],
            'idpeople' => $_POST['idpeople'],
            'businesslicense' => $_POST['businesslicense'],
            'tel' => dhtmlspecialchars(trim($_POST['tel'])),
            'address' => dhtmlspecialchars(trim($_POST['address'])),
            'desc' => dhtmlspecialchars(trim($_POST['desc'])),
            'updatetime' => time(),
        );
        foreach ($data as $value) {
            if (!$value) {
                echo '<script>parent.showerrmsg("' . $zclangs['zclang_required'] . '");parent.enableconfirmbtn();</script>';
                dexit();
            }
        }
        C::t('#zpl_car#zpl_car_store')->update($store['storeid'], $data);
        echo '<script>parent.showsuccessmsg("' . $zclangs['zclang_save_storeinfo_success'] . '", 1000, true, "plugin.php?id=zpl_car:store_center");</script>';
    }
}

$store['imageurl'] = helper::gethandledurl($store['image']);
$store['idfronturl'] = helper::gethandledurl($store['idfront']);
$store['idbackurl'] = helper::gethandledurl($store['idback']);
$store['idpeopleurl'] = helper::gethandledurl($store['idpeople']);
$store['businesslicenseurl'] = helper::gethandledurl($store['businesslicense']);

$stat['cars'] = (int) C::t('#zpl_car#zpl_car')->fetch_count_by_storeid($_G['uid'], $store['storeid']);
$stat['bevieweds'] = (int) C::t('#zpl_car#zpl_car')->fetch_all_views_by_storeid($_G['uid'], $store['storeid']);
$stat['beinquirieds'] = (int) C::t('#zpl_car#zpl_car_inquiryrecord')->fetch_count_by_storeid($store['storeid'], $_G['uid']);
$stat['becollected'] = (int) C::t('#zpl_car#zpl_car_collection')->fetch_count_by_storeid($store['storeid'], $_G['uid']);

include_once template('zpl_car:store_center');

?>