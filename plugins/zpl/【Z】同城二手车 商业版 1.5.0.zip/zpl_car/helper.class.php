<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zpl_car/wechat.lib.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/wechat.class.php';

class helper
{
    public static $ORDER_TYPE_GRFB = 10;
    public static $ORDER_TYPE_SJRZ = 20;
    public static $ORDER_TYPE_SJFB = 30;
    public static $ORDER_TYPE_ZDCL = 40;

    public static function get_column($array, $name, $keepkeys = true)
    {
        $result = array();
        if ($keepkeys) {
            foreach ($array as $k => $element) {
                $result[$k] = static::get_value($element, $name);
            }
        } else {
            foreach ($array as $element) {
                $result[] = static::get_value($element, $name);
            }
        }

        return $result;
    }

    public static function map($array, $from, $to, $group = null)
    {
        $result = [];
        foreach ($array as $element) {
            $key = static::get_value($element, $from);
            $value = static::get_value($element, $to);
            if ($group !== null) {
                $result[static::get_value($element, $group)][$key] = $value;
            } else {
                $result[$key] = $value;
            }
        }

        return $result;
    }

    public static function index($array, $key, $groups = array())
    {
        $result = array();
        $groups = (array) $groups;

        foreach ($array as $element) {
            $lastArray = &$result;

            foreach ($groups as $group) {
                $value = self::get_value($element, $group);
                if (!array_key_exists($value, $lastArray)) {
                    $lastArray[$value] = array();
                }
                $lastArray = &$lastArray[$value];
            }

            if ($key === null) {
                if (!empty($groups)) {
                    $lastArray[] = $element;
                }
            } else {
                $value = self::get_value($element, $key);
                if ($value !== null) {
                    if (is_float($value)) {
                        $value = str_replace(',', '.', (string) $value);;
                    }
                    $lastArray[$value] = $element;
                }
            }
            unset($lastArray);
        }

        return $result;
    }

    public static function get_value($array, $key, $default = null)
    {
        if ($key instanceof \Closure) {
            return $key($array, $default);
        }

        if (is_array($key)) {
            $lastKey = array_pop($key);
            foreach ($key as $keyPart) {
                $array = self::get_value($array, $keyPart);
            }
            $key = $lastKey;
        }

        if (is_array($array) && (isset($array[$key]) || array_key_exists($key, $array))) {
            return $array[$key];
        }

        if (($pos = strrpos($key, '.')) !== false) {
            $array = self::get_value($array, substr($key, 0, $pos), $default);
            $key = substr($key, $pos + 1);
        }

        if (is_object($array)) {
            // this is expected to fail if the property does not exist, or __get() is not implemented
            // it is not reliably possible to check whether a property is accessible beforehand
            return $array->$key;
        } elseif (is_array($array)) {
            return (isset($array[$key]) || array_key_exists($key, $array)) ? $array[$key] : $default;
        }

        return $default;
    }

    public static function gethandledurl($url = '')
    {
        if ($url) {
            if (substr($url, 0, 4) === 'http' || substr($url, 0, 6) === 'source') {
                return $url;
            } else {
                global $_G;
                return $_G['setting']['attachurl'] . $url;
            }
        }
        return $url;
    }

    public static function keeptwodecimal($param)
    {
        return sprintf("%.2f", substr(sprintf("%.3f", $param), 0, -1));
    }

    public static function generateorderno()
    {
        return date('Ymd') . substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
    }

    public static function gethostinfo()
    {
        global $_G;
        $siteurl = $_G['siteurl'];
        if (substr($siteurl, -1) == '/') {
            $hostinfo = substr($siteurl, 0, -1);
        } else {
            $hostinfo = $siteurl;
        }
        return $hostinfo;
    }

    public static function getfields()
    {
        $intsarr = array('bid', 'sid', 'downpayment', 'periods', 'transfertimes', 'new', 'gearbox', 'carlevel',
            'country', 'appearance', 'engineintakeform', 'engineemistand', 'enginefueltype', 'tcbgears', 'tcbdrive',
            'tcbdrive', 'cblength', 'cbwidth', 'cbheight', 'cbcardoors', 'cbseats', 'secujsyqn', 'secufjsqn', 'secutyjczz',
            'secuaqdwxts', 'secuetzyjk', 'secucnzks', 'secuwysqdxt', 'secuwysjrxt', 'secuabs', 'secuesp', 'insidezpfxp',
            'insidezpzy', 'insidedgnfxp', 'insidezktcsdp', 'insidekt', 'insidedsxh', 'insidegpsdhxt', 'insidedcyxxt',
            'insideczld', 'externalddcc', 'externalqjtc', 'externalddxhm', 'externalgyhbx', 'externalqhddcc', 'externalhys',
            'lightingjgd', 'lightingddgdkt', 'lightingzdtd', 'lightingzxfzd', 'lightingqwd');

        $floatsarr = array('apparentmileage', 'price', 'expectprice', 'gxbzhoilcons', 'enginedis', 'cbtankvolume');

        $stringsarr = array('cartype', 'cardtime', 'listtime', 'desc', 'enginecylinder', 'enginemaxhorsepower', 'enginemaxpower',
            'enginemaxtorque', 'engineroz', 'tcbttype', 'tcbassistance', 'tcbfrontsusp', 'tcbrearsusp', 'tcbfrontbrake',
            'tcbrearbrake', 'tcbparkingbraking', 'tcbfronttire', 'tcbreartire', 'cbstructure', 'cbtrunkvolume');

        $cararr = array('bid', 'sid', 'uid', 'username', 'cartype', 'cardyear', 'cardmonth', 'apparentmileage', 'price',
            'expectprice', 'gxbzhoilcons', 'downpayment', 'periods', 'listyear', 'listmonth', 'transfertimes', 'new', 'gearbox',
            'carlevel', 'country', 'appearance', 'desc', 'createtime', 'updatetime');

        $configarr = array('enginedis', 'engineintakeform', 'enginecylinder', 'enginemaxhorsepower', 'enginemaxpower', 'enginemaxtorque', 'engineemistand', 'engineroz', 'enginefueltype',
            'tcbttype', 'tcbgears', 'tcbdrive', 'tcbassistance', 'tcbfrontsusp', 'tcbrearsusp', 'tcbfrontbrake', 'tcbrearbrake', 'tcbparkingbraking', 'tcbfronttire', 'tcbreartire',
            'cblength', 'cbwidth', 'cbheight', 'cbcardoors', 'cbseats', 'cbstructure', 'cbtankvolume', 'cbtrunkvolume',
            'secujsyqn', 'secufjsqn', 'secutyjczz', 'secuaqdwxts', 'secuetzyjk', 'secucnzks', 'secuwysqdxt', 'secuwysjrxt', 'secuabs', 'secuesp',
            'insidezpfxp', 'insidezpzy', 'insidedgnfxp', 'insidezktcsdp', 'insidekt', 'insidedsxh', 'insidegpsdhxt', 'insidedcyxxt', 'insideczld',
            'externalddcc', 'externalqjtc', 'externalddxhm', 'externalgyhbx', 'externalqhddcc', 'externalhys',
            'lightingjgd', 'lightingddgdkt', 'lightingzdtd', 'lightingzxfzd', 'lightingqwd');

        $notrequirearr = array('sid', 'downpayment', 'periods', 'cardtime', 'new', 'gxbzhoilcons', 'desc',
            'engineintakeform', 'enginecylinder', 'enginemaxhorsepower', 'enginemaxpower', 'enginemaxtorque', 'engineroz',
            'tcbttype', 'tcbgears', 'tcbassistance', 'tcbfrontsusp', 'tcbrearsusp', 'tcbfrontbrake', 'tcbrearbrake', 'tcbparkingbraking', 'tcbfronttire', 'tcbreartire',
            'cblength', 'cbwidth', 'cbheight', 'cbcardoors', 'cbseats', 'cbstructure', 'cbtankvolume', 'cbtrunkvolume',
            'secujsyqn', 'secufjsqn', 'secutyjczz', 'secuaqdwxts', 'secuetzyjk', 'secucnzks', 'secuwysqdxt', 'secuwysjrxt', 'secuabs', 'secuesp',
            'insidezpfxp', 'insidezpzy', 'insidedgnfxp', 'insidezktcsdp', 'insidekt', 'insidedsxh', 'insidegpsdhxt', 'insidedcyxxt', 'insideczld',
            'externalddcc', 'externalqjtc', 'externalddxhm', 'externalgyhbx', 'externalqhddcc', 'externalhys',
            'lightingjgd', 'lightingddgdkt', 'lightingzdtd', 'lightingzxfzd', 'lightingqwd');

        return array($intsarr, $floatsarr, $stringsarr, $cararr, $configarr, $notrequirearr);
    }

    public static function isweixin()
    {
        if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) {
            return true;
        }
        return false;
    }

    public static function delpluginuploadfiles($path)
    {
        if (is_dir($path)) {
            $p = scandir($path);
            foreach ($p as $val) {
                if ($val != '.' && $val != '..') {
                    if (is_dir($path . $val)) {
                        self::delpluginuploadfiles($path . $val . '/');
                    } else {
                        if (strpos($val, 'plugin_zpl_car_') !== false) {
                            unlink($path . $val);
                        }
                    }
                }
            }
        }
    }

    public static function qfnonce($length = 32)
    {
        $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
        $str = "";
        for ($i = 0; $i < $length; $i++) {
            $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
        }
        return $str;
    }

    public static function qfsign($params, $secret)
    {
        ksort($params);
        $sparams = array();
        foreach ($params as $k => $v) {
            if ("@" != substr($v, 0, 1)) {
                $sparams[] = "$k=$v";
            }
        }
        $sparams[] = "secret=" . $secret;
        return strtoupper(md5(implode("&", $sparams)));
    }

    public static function get($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        # curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

        if (!curl_exec($ch)) {
            error_log(curl_error($ch));
            $data = '';
        } else {
            $data = curl_multi_getcontent($ch);
        }
        curl_close($ch);
        return $data;
    }

    public static function get_array($array = array(), $color = false, $type = '')
    {
        $result = array();
        if (is_array($array)) {
            foreach ($array as $v) {
                $arr = explode('=', $v);
                if ($color) {
                    if ($type == 'select') {
                        $result[] = [$arr[0], $arr[2]];
                    } else {
                        $result[$arr[0]] = $arr[2];
                    }
                } else {
                    if ($type == 'select') {
                        $result[] = [$arr[0], $arr[1]];
                    } else {
                        $result[$arr[0]] = $arr[1];
                    }
                }
            }
        }
        return $result;
    }

    public static function getenv()
    {
        if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) { // wx
            return 'WX';
        } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX") !== false) { // mag app
            return 'MAG';
        } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "QianFan") !== false) { // qf app
            return 'QF';
        } elseif (checkmobile()) { // mobile
            return 'MOBILE';
        } else { // pc
            return 'PC';
        }
    }

    public static function getwxjsconfig($appid, $appsecret, $url)
    {
        $wechat_client = new WeChatClient($appid, $appsecret);
        $jsapiticket = $wechat_client->getJsapiTicket();
        $noncestr = helper::getnoncestr();
        $timestamp = time();
        $values = array(
            'noncestr' => $noncestr,
            'jsapi_ticket' => $jsapiticket,
            'timestamp' => $timestamp,
            'url' => $url,
        );
        ksort($values);
        $string = helper::tourlparams($values);
        $signature = sha1($string);
        return array(
            'appId' => $appid,
            'timestamp' => $timestamp,
            'nonceStr' => $noncestr,
            'signature' => $signature,
        );
    }

    public static function tourlparams($values)
    {
        $buff = "";
        foreach ($values as $k => $v) {
            $buff .= $k . "=" . $v . "&";
        }
        $buff = trim($buff, "&");
        return $buff;
    }

    public static function getnoncestr($length = 32)
    {
        $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
        $str = "";
        for ($i = 0; $i < $length; $i++) {
            $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
        }
        return $str;
    }
}
//From: Dism_taobao-com
?>