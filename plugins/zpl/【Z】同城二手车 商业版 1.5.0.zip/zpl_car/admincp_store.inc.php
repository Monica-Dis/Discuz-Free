<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zpl_car/helper.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/zplupload.class.php';

echo '<link href="source/plugin/zpl_car/assets/plugins/layui/css/layui.css" rel="stylesheet" type="text/css" charset="' . CHARSET . '">';
echo '<link href="source/plugin/zpl_car/assets/css/plugins.css" rel="stylesheet" type="text/css">';
echo '<script type="text/javascript" src="./source/plugin/zpl_car/assets/plugins/layui/layui.js" charset="' . CHARSET . '"></script>';

global $_G;
loadcache(['zpl_car_langs']);
$zclangs = $_G['cache']['zpl_car_langs'];

$act = $_GET['act'];

if (!$act) {
    $mpurl = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_store';

    $intkeys = array('uid', 'checkstatus', 'paystatus');
    $strkeys = array();
    $randkeys = array();
    $likekeys = array('name');
    $results = getwheres($intkeys, $strkeys, $randkeys, $likekeys);
    foreach ($likekeys as $k) {
        $_GET[$k] = dhtmlspecialchars($_GET[$k]);
    }
    $wherearr = $results['wherearr'];
    $wheresql = empty($wherearr) ? '1' : implode(' AND ', $wherearr);
    $mpurl .= '&' . implode('&', $results['urls']);

    $ppp = 10;
    $page = max(1, intval($_GET['page']));
    $count = C::t('#zpl_car#zpl_car_store')->fetch_count($wheresql);
    $multipage = multi($count, $ppp, $page, $mpurl);

    $searchlang = array();
    $keys = array('search', 'likesupport', 'uid', 'name');
    foreach ($keys as $key) {
        $searchlang[$key] = cplang($key);
    }
    $searchlang['store_name'] = $zclangs['zclang_tpl_store_info_name'];
    $searchlang['checkstatus'] = $zclangs['zclang_car_store_checkstatus'];
    $searchlang['paystatus'] = $zclangs['zclang_car_store_paystatus'];

    $adminhiddens = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_store';
    parse_str($adminhiddens, $arrparams);
    $hiddenhtml = '';
    foreach ($arrparams as $key => $value) {
        $hiddenhtml .= '<input type="hidden" name="' . $key . '" value="' . $value . '">';
    }

    $checkstatusselected = array(
        'checkstatus1' => $_GET['checkstatus'] == 1 ? ' selected' : '',
        'checkstatus2' => $_GET['checkstatus'] == 2 ? ' selected' : '',
        'checkstatus3' => $_GET['checkstatus'] == 3 ? ' selected' : '',
    );
    $paystatusselected = array(
        'paystatus0' => $_GET['paystatus'] === '0' ? ' selected' : '',
        'paystatus1' => $_GET['paystatus'] === '1' ? ' selected' : '',
    );

    echo <<<SEARCH
<form method="get" autocomplete="off" action="">
    <table cellspacing="3" cellpadding="3">
        <tr>
            <th>$searchlang[store_name]</th><td><input type="text" class="txt" name="name" value="$_GET[name]"></td>
            <th>$searchlang[checkstatus]</th>
            <td colspan="3">
                <select name="checkstatus">
                <option value="">$zclangs[zclang_all_states]</option>
                <option value="1"$checkstatusselected[checkstatus1]>$zclangs[zclang_store_checkstatus1]</option>
                <option value="2"$checkstatusselected[checkstatus2]>$zclangs[zclang_store_checkstatus2]</option>
                <option value="3"$checkstatusselected[checkstatus3]>$zclangs[zclang_store_checkstatus3]</option>
                </select>
            </td>
            <th>$searchlang[paystatus]</th>
            <td colspan="3">
                <select name="paystatus">
                <option value="">$zclangs[zclang_all_states]</option>
                <option value="0"$paystatusselected[paystatus0]>$zclangs[zclang_car_store_paystatus0]</option>
                <option value="1"$paystatusselected[paystatus1]>$zclangs[zclang_car_store_paystatus1]</option>
                </select>
            </td>
            <th><td>$hiddenhtml<input type="submit" name="searchsubmit" value="$searchlang[search]" class="btn"></td></th>
        </tr>
    </table>
</form>
SEARCH;

    showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_store&page=' . $page, 'enctype');
    showtableheader($zclangs['zclang_store_list']);
    $subtitle = array(
        $zclangs['zclang_tpl_store_info_image'] . '/' . $zclangs['zclang_tpl_store_info_name'] . '/' . $zclangs['zclang_tpl_store_info_tel'],
        $zclangs['zclang_store_user'],
        $zclangs['zclang_tpl_store_info_idfront'],
        $zclangs['zclang_tpl_store_info_idback'],
        $zclangs['zclang_tpl_store_info_idpeople'],
        $zclangs['zclang_tpl_store_info_businesslicense'],
        $zclangs['zclang_tpl_store_info_address'],
        $zclangs['zclang_car_store_checkstatus'],
        $zclangs['zclang_car_store_paystatus'],
        $zclangs['zclang_operation'],
    );
    showsubtitle($subtitle);
    $rows = C::t('#zpl_car#zpl_car_store')->fetch_all_by_conditions($wheresql, $ppp, $page);
    foreach ($rows as $row) {
        $member = getuserbyuid($row['uid'], 1);

        $html = '<div style="height: 100%; display: flex; align-items: center;">';
        $html .= '<div style="float: left; margin-right: 10px;">' . ($row['image'] ? '<img src="' . helper::gethandledurl($row['image']) . '" style="width: 50px; height: 50px">' : '') . '</div>';
        $html .= '<div style="float: left;">';
        $html .= '<div>' . $row['name'] . '</div>';
        $html .= '<div style="margin-top: 10px;">' . $row['tel'] . '</div>';
        $html .= '</div>';
        $html .= '<div style="clear: both"></div>';
        $html .= '</div>';

        $html2 = '';
        if ($row['checkstatus'] == 1) {
            $html2 .= '<span style="color: #333">' . $zclangs['zclang_store_checkstatus' . $row['checkstatus']] . '</span>';
        } elseif ($row['checkstatus'] == 2) {
            $html2 .= '<span style="color: #0D0">' . $zclangs['zclang_store_checkstatus' . $row['checkstatus']] . '</span>';
        } elseif ($row['checkstatus'] == 3) {
            $html2 .= '<span style="color: #f84d4a">' . $zclangs['zclang_store_checkstatus' . $row['checkstatus']] . '</span>';
        }
        showtablerow('', array(), array(
            $html,
            $member['username'] . '/' . $row['uid'],
            $row['idfront'] ? '<img src="' . helper::gethandledurl($row['idfront']) . '" style="width: 50px; height: 50px">' : '',
            $row['idback'] ? '<img src="' . helper::gethandledurl($row['idback']) . '" style="width: 50px; height: 50px">' : '',
            $row['idpeople'] ? '<img src="' . helper::gethandledurl($row['idpeople']) . '" style="width: 50px; height: 50px">' : '',
            $row['businesslicense'] ? '<img src="' . helper::gethandledurl($row['businesslicense']) . '" style="width: 50px; height: 50px">' : '',
            $row['address'],
            $html2,
            $zclangs['zclang_car_paystatus_' . $row['paystatus']],
            '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_store&act=edit&storeid=' . $row['storeid'] . '&page=' . $_GET['page'] . '">' . $zclangs['zclang_edit'] . '</a>',
        ));
    }
    showsubmit('', '', '', '', $multipage);
    showtablefooter(); /*dism �� taobao �� com*/
    showformfooter();
} elseif ($act == 'add') {
} elseif ($act == 'edit') {
    $store = C::t('#zpl_car#zpl_car_store')->fetch($_GET['storeid']);
    if (!submitcheck('editsubmit')) {
        showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_store&act=edit&storeid=' . $_GET['storeid'] . '&page=' . $_GET['page'], 'enctype');
        showtableheader($zclangs['zclang_car_edit_store']);

        showsetting($zclangs['zclang_tpl_store_info_name'], 'name', $store['name'], 'text');
        showsetting('UID', 'uid', $store['uid'], 'text');

        $url = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_store&act=upload&inajax=1';

        $zplupload1 = new zplupload(null, 'image', $url, 'image', [$store['image'], helper::gethandledurl($store['image'])], array('uploadimagebtntext' => $zclangs['zclang_upload_image'], 'delbtntext' => $zclangs['zclang_delete']));
        $zplupload2 = new zplupload(null, 'idfront', $url, 'image', [$store['idfront'], helper::gethandledurl($store['idfront'])], array('uploadimagebtntext' => $zclangs['zclang_upload_image'], 'delbtntext' => $zclangs['zclang_delete']));
        $zplupload3 = new zplupload(null, 'idback', $url, 'image', [$store['idback'], helper::gethandledurl($store['idback'])], array('uploadimagebtntext' => $zclangs['zclang_upload_image'], 'delbtntext' => $zclangs['zclang_delete']));
        $zplupload4 = new zplupload(null, 'idpeople', $url, 'image', [$store['idpeople'], helper::gethandledurl($store['idpeople'])], array('uploadimagebtntext' => $zclangs['zclang_upload_image'], 'delbtntext' => $zclangs['zclang_delete']));
        $zplupload5 = new zplupload(null, 'businesslicense', $url, 'image', [$store['businesslicense'], helper::gethandledurl($store['businesslicense'])], array('uploadimagebtntext' => $zclangs['zclang_upload_image'], 'delbtntext' => $zclangs['zclang_delete']));
        echo '<tr><td colspan="2" class="td27" s="1">';
        echo '<div style="float: left; width: 100px">' . $zclangs['zclang_tpl_store_info_image'] . ':</div>';
        echo '<div style="float: left; width: 100px">' . $zclangs['zclang_tpl_store_info_idfront'] . ':</div>';
        echo '<div style="float: left; width: 100px">' . $zclangs['zclang_tpl_store_info_idback'] . ':</div>';
        echo '<div style="float: left; width: 100px">' . $zclangs['zclang_tpl_store_info_idpeople'] . ':</div>';
        echo '<div style="float: left; width: 100px">' . $zclangs['zclang_tpl_store_info_businesslicense'] . ':</div>';
        echo '<div style="clear: both"</div>';
        echo '</td></tr>';
        echo '<tr class="noborder"><td colspan="2">';
        echo '<div style="float: left; width: 100px">' . $zplupload1->gethtml() . '</div>';
        echo '<div style="float: left; width: 100px">' . $zplupload2->gethtml() . '</div>';
        echo '<div style="float: left; width: 100px">' . $zplupload3->gethtml() . '</div>';
        echo '<div style="float: left; width: 100px">' . $zplupload4->gethtml() . '</div>';
        echo '<div style="float: left; width: 100px">' . $zplupload5->gethtml() . '</div>';
        echo '<div style="clear: both"</div>';
        echo '</td></tr>';
        $zplupload1->registerjs();
        $zplupload2->registerjs();
        $zplupload3->registerjs();
        $zplupload4->registerjs();
        $zplupload5->registerjs();

        showsetting($zclangs['zclang_tpl_store_info_tel'], 'tel', $store['tel'], 'text');
        showsetting($zclangs['zclang_tpl_store_info_address'], 'address', $store['address'], 'text');
        showsetting($zclangs['zclang_tpl_store_info_desc'], 'desc', $store['desc'], 'textarea');
        showsetting($zclangs['zclang_store_checkstatus'], ['checkstatus', [[1, $zclangs['zclang_store_checkstatus1']], [2, $zclangs['zclang_store_checkstatus2']], [3, $zclangs['zclang_store_checkstatus3']]]], $store['checkstatus'], 'mradio2');
        showsetting($zclangs['zclang_store_checkremarks'], 'checkremarks', $store['checkremarks'], 'textarea');
        showsetting($zclangs['zclang_car_store_paystatus'], ['paystatus', [[0, $zclangs['zclang_car_store_paystatus0']], [1, $zclangs['zclang_car_store_paystatus1']]]], $store['paystatus'], 'mradio2');
        showsubmit('editsubmit');
        showtablefooter(); /*dism �� taobao �� com*/
        showformfooter();
    } else {
        $storedata = array();
        $storedata['name'] = $_POST['name'];
        $storedata['uid'] = $_POST['uid'];
        $storedata['image'] = $_POST['image'];
        $storedata['tel'] = $_POST['tel'];
        $storedata['address'] = $_POST['address'];
        $storedata['desc'] = $_POST['desc'];
        $storedata['idfront'] = $_POST['idfront'];
        $storedata['idback'] = $_POST['idback'];
        $storedata['idpeople'] = $_POST['idpeople'];
        $storedata['businesslicense'] = $_POST['businesslicense'];
        $storedata['checkstatus'] = $_POST['checkstatus'];
        $storedata['checkremarks'] = $_POST['checkremarks'];
        $storedata['paystatus'] = $_POST['paystatus'];
        C::t('#zpl_car#zpl_car_store')->update($_GET['storeid'], $storedata);

        cpmsg($zclangs['zclang_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zpl_car&pmod=admincp_store&act=edit&storeid=' . $_GET['storeid'] . '&page=' . $_GET['page'], 'succeed');
    }
} elseif ($act == 'upload') {
    ob_clean();
    header('Content-Type: application/json');
    $file = $_FILES['file'];
    $upload = new discuz_upload();
    $upload->init($file, 'common', random(3, 1), 'plugin_zpl_car_' . date('YmdHis') . strtolower(random(16)));
    if ($upload->attach['isimage']) {
        if ($upload->save()) {
            echo helper_json::encode(array('status' => 1, 'data' => [
                'src' => helper::gethandledurl('common/' . $upload->attach['attachment']),
                'attachment' => 'common/' . $upload->attach['attachment'],
                'filename' => trim($file['name'])
            ]));
        } else {
            echo helper_json::encode(array('status' => 0, 'msg' => $upload->errormessage()));
        }
    } else {
        echo helper_json::encode(array('status' => 0, 'msg' => $zclangs['zclang_ajax_upload_notimage_error']));
    }
    dexit();
}
//From: Dism_taobao-com
?>