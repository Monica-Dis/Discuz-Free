<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zpl_car/helper.class.php';

class zplupload
{
    public static $counter = 0;
    public static $autoidprefix = 'z';
    public $name;
    public $type = 'file';
    public $url;
    public $values;
    public $textarray;
    public $delbtntext;
    private $_id;

    public function __construct($id, $name, $url, $type, $values = array(), $textarray = array())
    {
        $this->initid($id);
        if ($name === null) {
            $this->name = '';
        } else {
            $this->name = $name;
        }
        $this->url = $url;
        if ($type) {
            $this->type = $type;
        }
        if ($values) {
            $this->values = $values;
        }
        $this->textarray = $textarray;
    }

    public function initid($id)
    {
        if ($id) {
            $this->_id = $id;
        } else {
            $this->_id = static::$autoidprefix . static::$counter++;
        }
    }

    public function getid()
    {
        return $this->_id;
    }

    public function setid($value)
    {
        $this->_id = $value;
    }

    public function gethtml()
    {
        if ($this->type == 'image') {
            return $this->getimagehtml();
        } elseif ($this->type == 'images') {
            return $this->getimageshtml();
        } else {
            return '';
        }
    }

    public function getimagehtml()
    {
        $values = $this->values;
        $uploadimagebtntext = helper::get_value($this->textarray, 'uploadimagebtntext', '');
        $delbtntext = helper::get_value($this->textarray, 'delbtntext', '');

        $html = '<div class="layui-upload">';
        $html .= '<button type="button" class="layui-btn layui-btn-xs" id="btn-' . $this->_id . '">' . $uploadimagebtntext . '</button>';
        $html .= '<a class="del-image" style="margin-left: 5px;" href="javascript:;">' . $delbtntext . '</a>';
        $html .= '<input type="hidden" id="' . $this->name . '" name="' . $this->name . '" value="' . $values[0] . '">';
        $html .= '<div class="layui-upload-list">';
        $src = $values[1] ? $values[1] : 'source/plugin/zpl_car/assets/images/no.png';
        $html .= '<img id="layui-img-' . $this->_id . '" class="layui-upload-img" src="' . $src . '">';
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    public function getimageshtml()
    {
        $values = $this->values;
        $uploadimagesbtntext = helper::get_value($this->textarray, 'uploadimagesbtntext', '');
        $delbtntext = helper::get_value($this->textarray, 'delbtntext', '');

        $html = '<div class="layui-upload">';
        $html .= '<button type="button" class="layui-btn layui-btn-xs" id="btn-' . $this->_id . '">' . $uploadimagesbtntext . '</button>';
        $html .= '<div id="layer-photos-' . $this->_id . '" class="layui-upload-list">';

        foreach ($values as $value) {
            $html .= '<div class="item" style="float: left; margin-right: 5px;">';
            $html .= '<input type="hidden" name="' . $this->name .  '[][aid]" value="' . $value['aid'] . '">';
            $html .= '<input type="hidden" name="' . $this->name .  '[][attachment]" value="' . $value['attachment'] . '">';
            $html .= '<input type="hidden" name="' . $this->name .  '[][filename]" value="' . $value['filename'] . '">';
            $html .= '<img style="cursor: pointer" layer-pid="" layer-src="' . $value['attachmenturl'] . '" src="' . $value['attachmenturl'] . '" alt="" class="layui-upload-img">';
            $html .= '<a class="layui-del" href="javascript:;">' . $delbtntext . '</a>';
            $html .= '</div>';
        }

        $html .= '</div>';
        $html .= '<div style="clear: both"></div>';
        $html .= '</div>';

        return $html;
    }

    public function registerjs()
    {
        if ($this->type == 'image') {
            $this->registerimagejs();
        } elseif ($this->type == 'images') {
            $this->registerimagesjs();
        } else {
            echo <<<EOF
EOF;
        }
    }

    public function registerimagejs()
    {
        $id = $this->_id;
        $url = $this->url;
        $src = 'source/plugin/zpl_car/assets/images/no.png';
        echo <<<EOF
<script type="text/javascript">
    layui.use(['layer', 'upload'], function(){
        var $ = layui.jquery, 
            layer = layui.layer, 
            upload = layui.upload, 
            container;
        
        var handleShowPointer = function() {
            if ($('#layui-img-$id').attr('src') !== '$src') {
                $('#layui-img-$id').css({cursor: 'pointer'});
            } else {
                $('#layui-img-$id').css({cursor: 'default'});
            }
        };
        
        handleShowPointer();
        
        $('#layui-img-$id').on('click', function(e) {
            e.preventDefault();
            var src = $(this).attr('src');
            if (src !== '$src') {
                layer.photos({
                    photos: {
                        "title": "",
                        "id": 'album0',
                        "data": [
                            {
                                "alt": "",
                                "pid": 'album0_0',
                                "src": src,
                                "thumb": ""
                            }
                        ]
                    },
                    anim: 5
                });
            }
        });
        
        $('.del-image').on('click', function(e) {
            e.preventDefault();
            var parent = $(this).parent();
            parent.find('.layui-upload-list img').attr('src', '$src');
            parent.find('#{$this->name}').attr('value', '');
            handleShowPointer();
        });
        
        upload.render({
            elem: '#btn-' + '$id',
            url: '$url',
            accept: 'images',
            acceptMime: 'image/*',
            before: function (obj) {
                container = $(this.elem).parent();
            },
            done: function (res) {
                if (res.status === 0) {
                    return layer.msg(res.msg);
                }
                container.find('#{$this->name}').attr('value', res.data.attachment);
                container.find('.layui-upload-list img').attr('src', res.data.src);
                handleShowPointer();
            }
        });
    });
</script>
EOF;
    }

    public function registerimagesjs()
    {
        $id = $this->_id;
        $url = $this->url;
        $name = $this->name;
        $delbtntext = helper::get_value($this->textarray, 'delbtntext', '');
        echo <<<EOF
<script type="text/javascript">
    layui.use(['layer', 'upload'], function(){
        var $ = layui.jquery, layer = layui.layer, upload = layui.upload, name = '$name', container;
        
        var handleLayerPhotosInit = function() {
            layer.photos({
                photos: '#layer-photos-$id',
                anim: 5
            });
        };
        
        var handleDelAndAlbum = function() {
            $('.layui-del').on('click', function(e) {
                e.preventDefault();
                var parent = $(this).parent();
                parent.remove();
                handleLayerPhotos();
            });
        };
        
        var handleLayerPhotos = function() {
            $('#layer-photos-$id img').on('click', function() {
                var array = [];
                var index = $('#layer-photos-$id img').index($(this));
                $('#layer-photos-$id').find('img').each(function(k, e) {
                    array.push({
                        "pid": k,
                        "src": $(e).attr('src')
                    });
                });
                layer.photos({
                    photos: {
                        "title": "",
                        "id": 'album-$id',
                        "start": index,
                        "data": array
                    }
                });
            });
        };
        
        handleLayerPhotosInit();
        handleDelAndAlbum();
        
        upload.render({
            elem: '#btn-' + '$id',
            url: '$url',
            accept: 'images',
            acceptMime: 'image/*',
            multiple: true,
            before: function (obj) {
                container = $(this.elem).parent();
            },
            done: function (res) {
                if (res.status === 0) {
                    return layer.msg(res.msg);
                }
                
                if (res.status === 1) {
                    var value = res.data.attachment;
                    var filename = res.data.filename;
                    var src = res.data.src;
                    var tpl = '<div class="item" style="float: left; margin-right: 5px;">' + "\\r\\n" +
                                  '<input type="hidden" name="' + name + '[][aid]" value="0">' + "\\r\\n" +
                                  '<input type="hidden" name="' + name + '[][attachment]" value="' + value +'">' + "\\r\\n" +
                                  '<input type="hidden" name="' + name + '[][filename]" value="' + filename +'">' + "\\r\\n" +
                                  '<img style="cursor: pointer" layer-pid="" layer-src="' + src + '" src="' + src + '" alt="" class="layui-upload-img">' + "\\r\\n" +
                                  '<a class="layui-del" href="javascript:;">$delbtntext</a>' + "\\r\\n" +
                              '</div>';
                    container.find('.layui-upload-list').append(tpl);
                }
                
                handleLayerPhotos();
                handleDelAndAlbum();
            }
        });
    });
</script>
EOF;
    }
}
//From: Dism_taobao-com
?>