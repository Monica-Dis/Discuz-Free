<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class verify
{
    protected $config = array(
        'seKey' => 'zplcar',
        'codeSet' => '2345678abcdefhijkmnpqrstuvwxyzABCDEFGHJKLMNPQRTUVWXY',
        'expire' => 300,
        'useZh' => false,
        'useImgBg' => false,
        'fontSize' => 25,
        'useCurve' => false,
        'useNoise' => true,
        'imageH' => 0,
        'imageW' => 0,
        'length' => 5,
        'fontttf' => '4.ttf',
        'bg' => array(243, 251, 254),
        'reset' => true,
    );

    private $_image = NULL;
    private $_color = NULL;

    public function __construct($config = array())
    {
        global $_G;
        loadcache(['zpl_car_langs']);
        $zclangs = $_G['cache']['zpl_car_langs'];

        $this->config['zhSet'] = $zclangs['zclang_car_verify_zhset'];
        $this->config = array_merge($this->config, $config);
    }

    public function __get($name)
    {
        return $this->config[$name];
    }

    public function __set($name, $value)
    {
        if (isset($this->config[$name])) {
            $this->config[$name] = $value;
        }
    }

    public function __isset($name)
    {
        return isset($this->config[$name]);
    }

    public function check($code)
    {
        $key = $this->authcode($this->seKey);
        session_start();
        $secode = $_SESSION["$key"];
        if (empty($code) || empty($secode)) {
            return false;
        }

        if (time() - $secode['verify_time'] > $this->expire) {
            $_SESSION["$key"] = null;
            return false;
        }
        if ($this->authcode(strtoupper($code)) == $secode['verify_code']) {
            $this->reset && $_SESSION["$key"] = null;
            return true;
        }

        return false;
    }

    public function entry($id = '')
    {
        $this->imageW || $this->imageW = $this->length * $this->fontSize * 1.5 + $this->length * $this->fontSize / 2;
        $this->imageH || $this->imageH = $this->fontSize * 2.5;
        $this->_image = imagecreate($this->imageW, $this->imageH);
        imagecolorallocate($this->_image, $this->bg[0], $this->bg[1], $this->bg[2]);

        $this->_color = imagecolorallocate($this->_image, mt_rand(1, 150), mt_rand(1, 150), mt_rand(1, 150));
        $ttfPath = 'source/plugin/zpl_car/assets/verify/' . ($this->useZh ? 'zhttfs' : 'ttfs') . '/';

        if (empty($this->fontttf)) {
            $dir = dir($ttfPath);
            $ttfs = array();
            while (false !== ($file = $dir->read())) {
                if ($file[0] != '.' && substr($file, -4) == '.ttf') {
                    $ttfs[] = $file;
                }
            }
            $dir->close();
            $this->fontttf = $ttfs[array_rand($ttfs)];
        }
        $this->fontttf = $ttfPath . $this->fontttf;

        if ($this->useImgBg) {
            $this->_background();
        }

        if ($this->useNoise) {
            $this->_writeNoise();
        }
        if ($this->useCurve) {
            $this->_writeCurve();
        }

        $code = array();
        $codeNX = 0;
        if ($this->useZh) {
            for ($i = 0; $i < $this->length; $i++) {
                $code[$i] = iconv_substr($this->zhSet, floor(mt_rand(0, mb_strlen($this->zhSet, 'utf-8') - 1)), 1, 'utf-8');
                imagettftext($this->_image, $this->fontSize, mt_rand(-40, 40), $this->fontSize * ($i + 1) * 1.5, $this->fontSize + mt_rand(10, 20), $this->_color, $this->fontttf, $code[$i]);
            }
        } else {
            for ($i = 0; $i < $this->length; $i++) {
                $code[$i] = $this->codeSet[mt_rand(0, strlen($this->codeSet) - 1)];
                $codeNX += mt_rand($this->fontSize * 1.2, $this->fontSize * 1.6);
                imagettftext($this->_image, $this->fontSize, 0, $codeNX, $this->fontSize * 1.6, $this->_color, $this->fontttf, $code[$i]);
            }
        }

        $key = $this->authcode($this->seKey);
        $code = $this->authcode(strtoupper(implode('', $code)));
        $secode = array();
        $secode['verify_code'] = $code;
        $secode['verify_time'] = time();
        session_start();
        $_SESSION["$key"] = $secode;
        header('Cache-Control: private, max-age=0, no-store, no-cache, must-revalidate');
        header('Cache-Control: post-check=0, pre-check=0', false);
        header('Pragma: no-cache');
        header("content-type: image/png");

        imagepng($this->_image);
        imagedestroy($this->_image);
    }

    private function _writeCurve()
    {
        $px = $py = 0;

        $A = mt_rand(1, $this->imageH / 2);
        $b = mt_rand(-$this->imageH / 4, $this->imageH / 4);
        $f = mt_rand(-$this->imageH / 4, $this->imageH / 4);
        $T = mt_rand($this->imageH, $this->imageW * 2);
        $w = (2 * M_PI) / $T;

        $px1 = 0;
        $px2 = mt_rand($this->imageW / 2, $this->imageW * 0.8);

        for ($px = $px1; $px <= $px2; $px = $px + 1) {
            if ($w != 0) {
                $py = $A * sin($w * $px + $f) + $b + $this->imageH / 2;
                $i = (int)($this->fontSize / 5);
                while ($i > 0) {
                    imagesetpixel($this->_image, $px + $i, $py + $i, $this->_color);
                    $i--;
                }
            }
        }

        $A = mt_rand(1, $this->imageH / 2);
        $f = mt_rand(-$this->imageH / 4, $this->imageH / 4);
        $T = mt_rand($this->imageH, $this->imageW * 2);
        $w = (2 * M_PI) / $T;
        $b = $py - $A * sin($w * $px + $f) - $this->imageH / 2;
        $px1 = $px2;
        $px2 = $this->imageW;

        for ($px = $px1; $px <= $px2; $px = $px + 1) {
            if ($w != 0) {
                $py = $A * sin($w * $px + $f) + $b + $this->imageH / 2;
                $i = (int)($this->fontSize / 5);
                while ($i > 0) {
                    imagesetpixel($this->_image, $px + $i, $py + $i, $this->_color);
                    $i--;
                }
            }
        }
    }

    private function _writeNoise()
    {
        $codeSet = '2345678abcdefhijkmnpqrstuvwxyz';
        for ($i = 0; $i < 10; $i++) {
            $noiseColor = imagecolorallocate($this->_image, mt_rand(150, 225), mt_rand(150, 225), mt_rand(150, 225));
            for ($j = 0; $j < 5; $j++) {
                imagestring($this->_image, 5, mt_rand(-10, $this->imageW), mt_rand(-10, $this->imageH), $codeSet[mt_rand(0, 29)], $noiseColor);
            }
        }
    }

    private function _background()
    {
        $path = 'source/plugin/zpl_car/assets/verify/bgs/';
        $dir = dir($path);

        $bgs = array();
        while (false !== ($file = $dir->read())) {
            if ($file[0] != '.' && substr($file, -4) == '.jpg') {
                $bgs[] = $path . $file;
            }
        }
        $dir->close();

        $gb = $bgs[array_rand($bgs)];

        list($width, $height) = @getimagesize($gb);

        $bgImage = @imagecreatefromjpeg($gb);
        @imagecopyresampled($this->_image, $bgImage, 0, 0, 0, 0, $this->imageW, $this->imageH, $width, $height);
        @imagedestroy($bgImage);
    }

    private function authcode($str)
    {
        $key = substr(md5($this->seKey), 5, 8);
        $str = substr(md5($str), 8, 10);
        return md5($key . $str);
    }
}
//From: Dism_taobao-com
?>