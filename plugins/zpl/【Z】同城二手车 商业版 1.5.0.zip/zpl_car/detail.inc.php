<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zpl_car/helper.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/wechat.lib.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/wechat.class.php';

loadcache(['plugin', 'zpl_car_langs']);

global $_G;

$vars = $_G['cache']['plugin']['zpl_car'];
$zclangs = $_G['cache']['zpl_car_langs'];

$appid = $vars['wxappid'];
$appsecret = $vars['wxappsecret'];

$cid = intval($_GET['cid']);
$car = C::t('#zpl_car#zpl_car')->fetch($cid);
$config = C::t('#zpl_car#zpl_car_config')->fetch($cid);

if (!$car) {
    include_once template('zpl_car:err');
    dexit();
}

$garray = get_array(explode(PHP_EOL, $vars['car_gearbox']));
$larray = get_array(explode(PHP_EOL, $vars['car_level']));
$carray = get_array(explode(PHP_EOL, $vars['car_countries']));
$coarray = get_array(explode(PHP_EOL, $vars['car_color']), true);
$iarray = get_array(explode(PHP_EOL, $vars['car_intakeform']));
$earray = get_array(explode(PHP_EOL, $vars['car_emissstandard']));
$farray = get_array(explode(PHP_EOL, $vars['car_fueltype']));
$darray = get_array(explode(PHP_EOL, $vars['car_drive']));
$harray = get_array(explode(PHP_EOL, $vars['car_haveornot']));
$formatcaritems = array(
    'gearbox' => $garray,
    'carlevel' => $larray,
    'country' => $carray,
    'appearance' => $coarray,
);
$formatconfigitems = array(
    'engineintakeform' => $iarray,
    'engineemistand' => $earray,
    'enginefueltype' => $farray,
    'tcbdrive' => $darray,
);
$car['bname'] = C::t('#zpl_car#zpl_car_brand')->fetch_name($car['bid']);
$car['sname'] = C::t('#zpl_car#zpl_car_brand')->fetch_name($car['sid']);
$car['downpaymentprice'] = helper::keeptwodecimal($car['expectprice'] * (3 / 10));
$car['periodprice'] = helper::keeptwodecimal((($car['expectprice'] - ($car['expectprice'] * (3 / 10))) * 10000) / 12);
foreach ($car as $key => $value) {
    if (in_array($key, array_keys($formatcaritems))) {
        $car[$key] = $formatcaritems[$key][$value];
    }
}
$car['createtime'] = date('Y-m-d', $car['createtime']);
$config['engineintakeformo'] = $config['engineintakeform'];
foreach ($config as $key => $value) {
    if (in_array($key, array_keys($formatconfigitems))) {
        $config[$key] = $formatconfigitems[$key][$value];
    }
}

if ($_GET['action'] != 'config') {
    C::t('#zpl_car#zpl_car')->update_views($cid);

    if ($_G['uid']) {
        $bdate = date('Y-m-d');
        $data = array(
            'cid' => $cid,
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'bdate' => $bdate,
            'dateline' => time(),
            'ip' => $_G['clientip'],
        );
        $browserecord = C::t('#zpl_car#zpl_car_browserecord')->fetch_by_date($cid, $_G['uid'], $bdate);
        if ($browserecord) {
            C::t('#zpl_car#zpl_car_browserecord')->update($browserecord['brid'], $data);
        } else {
            C::t('#zpl_car#zpl_car_browserecord')->insert($data);
        }
    }

    if ($_GET['op'] == 'collect') {
        // login
        if (empty($_G['uid'])) {
            $openwxlogin = $vars['openwxlogin'];
            $appid = $vars['wxappid'];
            $appsecret = $vars['wxappsecret'];

            $returnurl = $_G['siteurl'] . './plugin.php?id=zpl_car:detail&cid=' . $cid;
            $redirecturi = $_G['siteurl'] . './plugin.php?id=zpl_car:detail&cid=' . $cid . '&op=collect';
            if (helper::isweixin() && $openwxlogin == 1) {
                // WX login
                if (!isset($_GET['code'])) {
                    $redirecturi = urlencode($redirecturi);
                    $wxurl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$appid}&redirect_uri={$redirecturi}&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";
                    dheader('location: ' . $wxurl);
                } else {
                    require_once libfile('function/member');

                    $wechat_client = new WeChatClient($appid, $appsecret);

                    $code = $_GET['code'];
                    $tokeninfo = $wechat_client->getAccessTokenByCode($code);
                    if ($tokeninfo['openid']) {
                        $openid = $tokeninfo['openid'];
                        $mp = C::t('#zpl_car#zpl_car_user_wxmp')->fetch_by_openid($openid);
                        if ($mp) {
                            $member = getuserbyuid($mp['uid'], 1);
                            setloginstatus($member, 1296000);
                        } else {
                            $uid = ZplWeChat::register(ZplWeChat::getnewname($openid), 1);
                            if ($uid) {
                                $data = array(
                                    'uid' => $uid,
                                    'openid' => $openid,
                                );
                                C::t('#zpl_car#zpl_car_user_wxmp')->insert($data);
                            }
                        }
                        dheader('location: ' . $returnurl);
                    } else {
                        // common login
                        showmessage('not_loggedin', NULL, array(), array('login' => 1));
                    }
                }
            } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX") !== false) {
                // MAGAPP login
                include_once template('zpl_car:mag_login');
                dexit();
            } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "QianFan") !== false) {
                // QFAPP login
                include_once template('zpl_car:qianfan_login');
                dexit();
            } else {
                // common login
                showmessage('not_loggedin', NULL, array(), array('login' => 1));
            }
        }
    }

    $attachments = C::t('#zpl_car#zpl_car_attachment')->fetch_all_by_cid($cid);
    foreach ($attachments as $key => $attachment) {
        $attachments[$key]['attachmenturl'] = helper::gethandledurl($attachment['attachment']);
    }
    $user = C::t('#zpl_car#zpl_car_user')->fetch($car['uid']);
    $store = C::t('#zpl_car#zpl_car_store')->fetch($car['storeid']);
    if ($store) {
        $store['imageurl'] = helper::gethandledurl($store['image']);
    }
    $collection = C::t('#zpl_car#zpl_car_collection')->fetch_by_cid_uid($cid, $_G['uid']);

    $wxjsconfig = helper::getwxjsconfig(
        $appid,
        $appsecret,
        $_G['scheme'] . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']
    );
    $sharedata = array();
    $sharedata['title'] = $car['bname'] . ' ' . $car['sname'] . ' ' . $car['cartype'];
    $sharedata['desc'] = '';
    $sharedata['link'] = $_G['scheme'] . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    $sharedata['image'] = $_G['siteurl'] . $attachments[0]['attachmenturl'];

    include_once template('zpl_car:detail');
} else {
    include_once template('zpl_car:config');
}

function get_array($array = array(), $color = false)
{
    $result = array();
    if (is_array($array)) {
        foreach ($array as $v) {
            $arr = explode('=', $v);
            if ($color) {
                $result[$arr[0]] = $arr[2];
            } else {
                $result[$arr[0]] = $arr[1];
            }
        }
    }
    return $result;
}
//From: Dism_taobao-com
?>