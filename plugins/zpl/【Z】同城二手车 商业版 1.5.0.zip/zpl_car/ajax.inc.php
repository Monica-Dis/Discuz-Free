<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zpl_car/wechat.lib.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/wechat.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/helper.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/verify.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/pay.class.php';

global $_G;
loadcache(['plugin', 'zpl_car_langs']);
$vars = $_G['cache']['plugin']['zpl_car'];
$zclangs = $_G['cache']['zpl_car_langs'];

$appid = $vars['wxappid'];
$appsecret = $vars['wxappsecret'];

$qfhostname = trim($vars['qianfanhostname']);
$qfsecret = trim($vars['qianfansecret']);

$magappurl = trim($vars['magappurl']);
$magsecret = trim($vars['magsecret']);

if ($_GET['action'] == 'homepagerecommlist') {
    $page = intval($_GET['page']);
    $size = intval($_GET['size']);
    if ($size > 20) {
        include template('common/header_ajax');
        echo json_encode(array('status' => 0, 'msg' => $zclangs['zclang_ajax_limit_error']), 320);
        include template('common/footer_ajax');
        dexit();
    }
    $data = C::t('#zpl_car#zpl_car')->fetch_all_by_recomm($page, $size);
    foreach ($data as $key => $datum) {
        $data[$key]['isshowtopsign'] = time() > $datum['topexpireat'] ? 0 : 1;
        $data[$key]['sname'] = trim($datum['sname']);
        $data[$key]['image'] = helper::gethandledurl($datum['image']);
        $data[$key]['cardyear'] = $datum['cardyear'] ? $datum['cardyear'] : '';
    }
    $nextpagedata = C::t('#zpl_car#zpl_car')->fetch_all_by_recomm($page + 1, $size);
    $hasnext = $nextpagedata ? 1 : 0;
    include template('common/header_ajax');
    echo helper_json::encode(array('status' => 1, 'data' => $data, 'hasnext' => $hasnext));
    include template('common/footer_ajax');
    dexit();
} elseif ($_GET['action'] == 'list') {
    $page = intval($_GET['page']);
    $size = intval($_GET['size']);
    if ($size > 20) {
        include template('common/header_ajax');
        echo json_encode(array('status' => 0, 'msg' => $zclangs['zclang_ajax_limit_error']), 320);
        include template('common/footer_ajax');
        dexit();
    }

    $orders = array(
        '1' => 'ORDER BY CASE WHEN c.topexpireat<' . time() . ' THEN 0 ELSE c.topexpireat END DESC, c.createtime DESC',
        '2' => 'ORDER BY CASE WHEN c.topexpireat<' . time() . ' THEN 0 ELSE c.topexpireat END DESC, c.expectprice ASC',
        '3' => 'ORDER BY CASE WHEN c.topexpireat<' . time() . ' THEN 0 ELSE c.topexpireat END DESC, c.expectprice DESC',
        '4' => 'ORDER BY CASE WHEN c.topexpireat<' . time() . ' THEN 0 ELSE c.topexpireat END DESC, c.cardtime != 0, c.cardtime DESC',
        '5' => 'ORDER BY CASE WHEN c.topexpireat<' . time() . ' THEN 0 ELSE c.topexpireat END DESC, c.apparentmileage ASC',
    );
    $ordersql = '';
    if ($_GET['sort'] && $orders[$_GET['sort']]) {
        $ordersql = $orders[$_GET['sort']];
    }
    if (!$ordersql) {
        $ordersql = 'ORDER BY CASE WHEN c.topexpireat<' . time() . ' THEN 0 ELSE c.topexpireat END DESC, c.cid DESC';
    }

    $likekeys = array('search');
    $otherkeys = array('c.bid', 'c.sid', 'c.storeid', 'c.carlevel', 'c.appearance', 'c.new', 'c.gearbox', 'c.country', 'cc.enginefueltype', 'cc.tcbdrive',
        'cc.insidedcyxxt', 'cc.externalqjtc', 'cc.insidegpsdhxt', 'cc.secuwysqdxt', 'cc.secuwysjrxt',
        'cc.insidezpzy', 'cc.insidedsxh', 'cc.insidezktcsdp', 'cc.insideczld', 'c.expectprice', 'age',
        'c.apparentmileage', 'cc.enginedis', 'cc.cbseats', 'cc.engineemistand');
    if ($_GET['type'] == 'new') {
        $_GET['new'] = 1;
    }
    $wheresql = getws($likekeys, $otherkeys);

    $data = C::t('#zpl_car#zpl_car')->fetch_all_list($wheresql, $ordersql, $page, $size);
    foreach ($data as $key => $datum) {
        $data[$key]['isshowtopsign'] = time() > $datum['topexpireat'] ? 0 : 1;
        $data[$key]['sname'] = trim($datum['sname']);
        $data[$key]['image'] = helper::gethandledurl($datum['image']);
        $data[$key]['cardyear'] = $datum['cardyear'] ? $datum['cardyear'] : '';
    }
    $nextpagedata = C::t('#zpl_car#zpl_car')->fetch_all_list($wheresql, $ordersql, $page + 1, $size);
    $hasnext = $nextpagedata ? 1 : 0;

    include template('common/header_ajax');
    echo helper_json::encode(array('status' => 1, 'data' => $data, 'hasnext' => $hasnext));
    include template('common/footer_ajax');
    dexit();
} elseif ($_GET['action'] == 'getseries') {
    include template('common/header_ajax');
    $upid = $_GET['upid'];
    loadcache(['zpl_car_brand_list']);
    $list = $_G['cache']['zpl_car_brand_list'];
    if (isset($list[$upid])) {
        $brand = $list[$upid]['brand'];
        $series = $list[$upid]['series'];
        $html = '<a href="javascript:;" class="brand">' . ($brand['image'] ? '<img src="' . helper::gethandledurl($brand['image']) . '">' : '') . '<span>' . $brand['name']. '</span></a>';
        $html .= '<div class="items"><a class="series-item" data-queryname="sid" data-value="" href="javascript:;">' . $zclangs['zclang_car_brand_allseries'] . '</a>';
        if ($series) {
            foreach ($series as $e) {
                $html .= '<a class="series-item" data-queryname="sid" data-value="' . $e['id'] . '" href="javascript:;">' . $e['name'] . '</a>';
            }
        }
        $html .= '</div>';
        echo helper_json::encode(array('status' => 1, 'html' => $html));
    } else {
        echo helper_json::encode(array('status' => 0, 'msg' => $zclangs['zclang_ajax_brand_notexist_error']));
    }
    include template('common/footer_ajax');
    dexit();
} elseif ($_GET['action'] == 'publishgetseries') {
    include template('common/header_ajax');
    $upid = $_GET['upid'];
    loadcache(['zpl_car_brand_list']);
    $list = $_G['cache']['zpl_car_brand_list'];
    if (isset($list[$upid])) {
        $series = $list[$upid]['series'];
        $data = array();
        if ($series) {
            foreach ($series as $e) {
                $data[] = [
                    'title' => $e['name'],
                    'value' => $e['id']
                ];
            }
        }
        echo helper_json::encode(array('status' => 1, 'data' => $data));
    } else {
        echo helper_json::encode(array('status' => 0, 'msg' => $zclangs['zclang_ajax_brand_notexist_error']));
    }
    include template('common/footer_ajax');
    dexit();
} elseif ($_GET['action'] == 'upload') {
    include template('common/header_ajax');
    $file = $_FILES['file'];
    $upload = new discuz_upload();
    $upload->init($file, 'common', random(3, 1), 'plugin_zpl_car_' . date('YmdHis') . strtolower(random(16)));
    if ($upload->attach['isimage']) {
        if ($upload->save()) {
            echo helper_json::encode(array('status' => 1, 'data' => [
                'src' => helper::gethandledurl('common/' . $upload->attach['attachment']),
                'attachment' => 'common/' . $upload->attach['attachment'],
            ]));
        } else {
            echo helper_json::encode(array('status' => 0, 'msg' => $upload->errormessage()));
        }
    } else {
        echo helper_json::encode(array('status' => 0, 'msg' => $zclangs['zclang_ajax_upload_notimage_error']));
    }
    include template('common/footer_ajax');
    dexit();
} elseif ($_GET['action'] == 'wxuploadimage') {
    $wechat_client = new WeChatClient($appid, $appsecret);
    $access_token = $wechat_client->getAccessToken();
    $media_id = $_GET['media_id'];
    $url = "https://api.weixin.qq.com/cgi-bin/media/get?access_token=$access_token&media_id=$media_id";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, TRUE);
    curl_setopt($ch, CURLOPT_NOBODY, FALSE);
    $data = curl_exec($ch);
    if (curl_getinfo($ch, CURLINFO_HTTP_CODE) == '200') {
        $headersize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $header = substr($data, 0, $headersize);
        $content = substr($data, $headersize);
        //$body = json_decode($content, true);
        curl_close($ch);
        $arr = array();
        if (preg_match('/filename="(.*?)"/', $header, $arr)) {
            $ext = pathinfo($arr[1], PATHINFO_EXTENSION);
            if ($ext) {
                $upload = new discuz_upload();
                $type = 'common';
                $extid = random(3, 1);
                $forcename = 'plugin_zpl_car_' . date('YmdHis') . strtolower(random(16));
                $filename = $upload->get_target_filename($type, $extid, $forcename) . '.' . $ext;
                $attachment = $upload->get_target_dir($type, $extid) . $filename;
                $target = getglobal('setting/attachdir') . './' . $type . '/' . $attachment;
                if (file_put_contents($target, $content) !== false) {
                    include template('common/header_ajax');
                    echo helper_json::encode(array('status' => 1, 'data' => [
                        'src' => helper::gethandledurl('common/' . $attachment),
                        'attachment' => 'common/' . $attachment,
                        'filename' => $filename,
                    ]));
                    include template('common/footer_ajax');
                    dexit();
                }
            }
        }
    }
    include template('common/header_ajax');
    echo helper_json::encode(array('status' => 0, 'msg' => $zclangs['zclang_upload_err']));
    include template('common/footer_ajax');
    dexit();
} elseif ($_GET['action'] == 'maguploadimage') {
    $aid = $_GET['aid'];
    $url = $magappurl . "core/attachment/attachment/attach?aid=$aid";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_NOBODY, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_exec($ch);
    $url2 = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    curl_close($ch);

    $tmpFile = tempnam(sys_get_temp_dir(), 'image');
    $resource = fopen($tmpFile, 'wb');
    $curl = curl_init($url2);
    curl_setopt($curl, CURLOPT_FILE, $resource);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_exec($curl);
    curl_close($curl);
    fclose($resource);
    if (function_exists('exif_imagetype')) {
        $fileType = exif_imagetype($tmpFile);
    } else {
        $fileInfo = getimagesize($tmpFile);
        $fileType = $fileInfo[2];
    }
    $extension = image_type_to_extension($fileType);
    if ($extension) {
        $upload = new discuz_upload();
        $type = 'common';
        $extid = random(3, 1);
        $forcename = 'plugin_zpl_car_' . date('YmdHis') . strtolower(random(16));
        $filename = $upload->get_target_filename($type, $extid, $forcename) . $extension;
        $attachment = $upload->get_target_dir($type, $extid) . $filename;
        $target = getglobal('setting/attachdir') . './' . $type . '/' . $attachment;
        if (copy($tmpFile, $target) !== false) {
            include template('common/header_ajax');
            echo helper_json::encode(array('status' => 1, 'data' => [
                'src' => helper::gethandledurl('common/' . $attachment),
                'attachment' => 'common/' . $attachment,
                'filename' => $filename,
            ]));
            include template('common/footer_ajax');
            dexit();
        }
    }
    include template('common/header_ajax');
    echo helper_json::encode(array('status' => 0, 'msg' => $zclangs['zclang_upload_err']));
    include template('common/footer_ajax');
    dexit();
} elseif ($_GET['action'] == 'pay') {
    if (empty($_G['uid'])) {
        include template('common/header_ajax');
        echo helper_json::encode(array('status' => -1));
        include template('common/footer_ajax');
        dexit();
    }

    $paytype = $_GET['paytype'];
    $ordertype = $_GET['ordertype'];
    if ($paytype == 'WXPAY') {
        if ($ordertype == helper::$ORDER_TYPE_GRFB) {
            $config = array(
                'paytype' => pay::$PAY_TYPE_WXPAY,
                'env' => helper::getenv(),
                'orderno' => helper::generateorderno(),
                'amount' => helper::keeptwodecimal($vars['publishaddpayamount']),
                'body' => CHARSET == 'gbk' ? iconv('GBK', 'UTF-8', $zclangs['zclang_car_order_type_10_2']) : $zclangs['zclang_car_order_type_10_2'],
                'productid' => helper::$ORDER_TYPE_GRFB,
                'wapurl' => helper::gethostinfo(),
                'wapname' => $vars['hptitle'],
                'redirecturl' => $_G['siteurl'] . 'plugin.php?id=zpl_car:my&action=mylist',
            );
        } elseif ($ordertype == helper::$ORDER_TYPE_SJRZ) {
            $config = array(
                'paytype' => pay::$PAY_TYPE_WXPAY,
                'env' => helper::getenv(),
                'orderno' => helper::generateorderno(),
                'amount' => helper::keeptwodecimal($vars['storesettleinpayamount']),
                'body' => CHARSET == 'gbk' ? iconv('GBK', 'UTF-8', $zclangs['zclang_car_order_type_20']) : $zclangs['zclang_car_order_type_20'],
                'productid' => helper::$ORDER_TYPE_SJRZ,
                'wapurl' => helper::gethostinfo(),
                'wapname' => $vars['hptitle'],
                'redirecturl' => $_G['siteurl'] . 'plugin.php?id=zpl_car:my',
            );
        } elseif ($ordertype == helper::$ORDER_TYPE_SJFB) {
            $config = array(
                'paytype' => pay::$PAY_TYPE_WXPAY,
                'env' => helper::getenv(),
                'orderno' => helper::generateorderno(),
                'amount' => helper::keeptwodecimal($vars['storepublishaddpayamount']),
                'body' => CHARSET == 'gbk' ? iconv('GBK', 'UTF-8', $zclangs['zclang_car_order_type_30']) : $zclangs['zclang_car_order_type_30'],
                'productid' => helper::$ORDER_TYPE_SJFB,
                'wapurl' => helper::gethostinfo(),
                'wapname' => $vars['hptitle'],
                'redirecturl' => $_G['siteurl'] . 'plugin.php?id=zpl_car:store_center',
            );
        } elseif ($ordertype == helper::$ORDER_TYPE_ZDCL) {
            $toptype = $_GET['toptype'];
            $toprules = explode(PHP_EOL, $vars['topcarpayrules']);
            $rulesarr = array();
            foreach ($toprules as $toprule) {
                $arr = explode('|', $toprule);
                $arr[2] = str_replace('{days}', $arr[0], $arr[2]);
                $arr[2] = str_replace('{money}', $arr[1], $arr[2]);
                foreach ($arr as $key => $value) {
                    $arr[$key] = str_replace(["\r\n", "\n", "\r"], "", $value);
                }
                $rulesarr[$arr[0]] = $arr;
            }
            $config = array(
                'paytype' => pay::$PAY_TYPE_WXPAY,
                'env' => helper::getenv(),
                'orderno' => helper::generateorderno(),
                'amount' => helper::keeptwodecimal($rulesarr[$toptype][1]),
                'body' => CHARSET == 'gbk' ? iconv('GBK', 'UTF-8', $zclangs['zclang_car_order_type_40']) : $zclangs['zclang_car_order_type_40'],
                'productid' => helper::$ORDER_TYPE_ZDCL,
                'wapurl' => helper::gethostinfo(),
                'wapname' => $vars['hptitle'],
                'redirecturl' =>  $_G['siteurl'] . $_GET['redirecturl'],
            );
        }
        $pay = new pay($config);
        $url = $pay->order();

        if ($ordertype == helper::$ORDER_TYPE_GRFB) {
            $orderdata = array(
                'orderno' => $pay->orderno,
                'uid' => $_G['uid'],
                'username' => $_G['username'],
                'paymentmethod' => $pay->paymentmethod,
                'status' => '10',
                'price' => $pay->amount,
                'type' => helper::$ORDER_TYPE_GRFB,
                'createtime' => time(),
                'cid' => $_GET['cid'],
                'ip' => $_G['clientip'],
                'body' => $_GET['body'],
            );
        } elseif ($ordertype == helper::$ORDER_TYPE_SJRZ) {
            $orderdata = array(
                'orderno' => $pay->orderno,
                'uid' => $_G['uid'],
                'username' => $_G['username'],
                'paymentmethod' => $pay->paymentmethod,
                'status' => '10',
                'price' => $pay->amount,
                'type' => helper::$ORDER_TYPE_SJRZ,
                'createtime' => time(),
                'storeid' => $_GET['storeid'],
                'ip' => $_G['clientip'],
                'body' => $_GET['body'],
            );
        } elseif ($ordertype == helper::$ORDER_TYPE_SJFB) {
            $orderdata = array(
                'orderno' => $pay->orderno,
                'uid' => $_G['uid'],
                'username' => $_G['username'],
                'paymentmethod' => $pay->paymentmethod,
                'status' => '10',
                'price' => $pay->amount,
                'type' => helper::$ORDER_TYPE_SJFB,
                'createtime' => time(),
                'storeid' => $_GET['storeid'],
                'cid' => $_GET['cid'],
                'ip' => $_G['clientip'],
                'body' => $_GET['body'],
            );
        } elseif ($ordertype == helper::$ORDER_TYPE_ZDCL) {
            $orderdata = array(
                'orderno' => $pay->orderno,
                'uid' => $_G['uid'],
                'username' => $_G['username'],
                'paymentmethod' => $pay->paymentmethod,
                'status' => '10',
                'price' => $pay->amount,
                'type' => helper::$ORDER_TYPE_ZDCL,
                'createtime' => time(),
                'storeid' => $_GET['storeid'],
                'cid' => $_GET['cid'],
                'ip' => $_G['clientip'],
                'body' => serialize($rulesarr[$toptype]),
            );
        }
        C::t('#zpl_car#zpl_car_order')->insert($orderdata);

        if ($pay->err) {
            include template('common/header_ajax');
            echo helper_json::encode(array('status' => 0, 'msg' => $pay->errmsg));
            include template('common/footer_ajax');
            dexit();
        }

        include template('common/header_ajax');
        echo helper_json::encode(array('status' => 1, 'data' => array('url' => $url, 'orderno' => $pay->orderno)));
        include template('common/footer_ajax');
        dexit();
    }
} elseif ($_GET['action'] == 'getorder') {
    if ($_GET['type'] == 'wx') {
        $order = C::t('#zpl_car#zpl_car_order')->fetch_by_orderno($_GET['orderno'], 20);
        if ($order) {
            include template('common/header_ajax');
            echo helper_json::encode(array('status' => 1));
            include template('common/footer_ajax');
            dexit();
        }

        if (CHARSET == 'gbk') {
            require_once DISCUZ_ROOT . './source/plugin/zpl_car/libraries/wxpay/gbk/lib/WxPay.Api.php';
            require_once DISCUZ_ROOT . './source/plugin/zpl_car/libraries/wxpay/gbk/example/WxPay.Config.php';
        } else {
            require_once DISCUZ_ROOT . './source/plugin/zpl_car/libraries/wxpay/utf8/lib/WxPay.Api.php';
            require_once DISCUZ_ROOT . './source/plugin/zpl_car/libraries/wxpay/utf8/example/WxPay.Config.php';
        }

        $input = new WxPayOrderQuery();
        $input->SetOut_trade_no($_GET['orderno']);
        $config = new WxPayConfig();
        $result = WxPayApi::orderQuery($config, $input);
        if (array_key_exists("return_code", $result)
            && array_key_exists("result_code", $result)
            && array_key_exists("trade_state", $result)
            && $result["return_code"] == "SUCCESS"
            && $result["result_code"] == "SUCCESS"
            && $result["trade_state"] == "SUCCESS")
        {
            $order = C::t('#zpl_car#zpl_car_order')->fetch_by_orderno($result['out_trade_no'], 10);
            if ($order) {
                if (in_array($order['type'], array(helper::$ORDER_TYPE_GRFB, helper::$ORDER_TYPE_SJFB))) {
                    if ($order['cid']) {
                        C::t('#zpl_car#zpl_car')->update($order['cid'], array(
                            'paystatus' => 1,
                            'updatetime' => time(),
                        ));
                    }
                    C::t('#zpl_car#zpl_car_order')->update($order['orderid'], array(
                        'tradeno' => $result['transaction_id'],
                        'status' => 20,
                        'paytime' => strtotime($result['time_end']),
                    ));
                } elseif ($order['type'] == helper::$ORDER_TYPE_SJRZ) {
                    if ($order['storeid']) {
                        C::t('#zpl_car#zpl_car_store')->update($order['storeid'], array(
                            'paystatus' => 1,
                            'updatetime' => time(),
                        ));
                    }
                    C::t('#zpl_car#zpl_car_order')->update($order['orderid'], array(
                        'tradeno' => $result['transaction_id'],
                        'status' => 20,
                        'paytime' => strtotime($result['time_end']),
                    ));
                } elseif ($order['type'] == helper::$ORDER_TYPE_ZDCL) {
                    if ($order['cid']) {
                        $body = unserialize($order['body']);
                        $car = C::t('#zpl_car#zpl_car')->fetch($order['cid']);
                        if ($car['topexpireat'] <= time()) {
                            C::t('#zpl_car#zpl_car')->update($order['cid'], array(
                                'topexpireat' => time() + intval($body[0] * 24 * 3600),
                                'updatetime' => time(),
                            ));
                        } else {
                            C::t('#zpl_car#zpl_car')->update($order['cid'], array(
                                'topexpireat' => $car['topexpireat'] + intval($body[0] * 24 * 3600),
                                'updatetime' => time(),
                            ));
                        }
                    }
                    C::t('#zpl_car#zpl_car_order')->update($order['orderid'], array(
                        'tradeno' => $data['transaction_id'],
                        'status' => 20,
                        'paytime' => strtotime($data['time_end']),
                    ));
                }

                include template('common/header_ajax');
                echo helper_json::encode(array('status' => 1));
                include template('common/footer_ajax');
                dexit();
            }
        }
    } elseif ($_GET['type'] == 'qf') {
        $params = array(
            'order_id' => $_GET['orderno'],
            'nonce' => helper::qfnonce(),
        );
        $params['sign'] = helper::qfsign($params, $qfsecret);
        $url = 'http://' . $qfhostname . '.qianfanapi.com/api1_2/orders/query?' . http_build_query($params);
        $res = json_decode(helper::get($url), true);
        if ($res['ret'] == 0 && $res['data'][$_GET['orderno']]) {
            $qforder = $res['data'][$_GET['orderno']];
            if ($qforder['result'] == 1) {
                $order = C::t('#zpl_car#zpl_car_order')->fetch_by_orderno($qforder['info']['out_trade_no'], 10);
                if ($order) {
                    if (in_array($order['type'], array(helper::$ORDER_TYPE_GRFB, helper::$ORDER_TYPE_SJFB))) {
                        if ($order['cid']) {
                            C::t('#zpl_car#zpl_car')->update($order['cid'], array(
                                'paystatus' => 1,
                                'updatetime' => time(),
                            ));
                        }
                        C::t('#zpl_car#zpl_car_order')->update($order['orderid'], array(
                            'tradeno' => $qforder['info']['trade_no'],
                            'status' => 20,
                            'paytime' => $qforder['info']['pay_time'],
                        ));
                    } elseif ($order['type'] == helper::$ORDER_TYPE_SJRZ) {
                        if ($order['storeid']) {
                            C::t('#zpl_car#zpl_car_store')->update($order['storeid'], array(
                                'paystatus' => 1,
                                'updatetime' => time(),
                            ));
                        }
                        C::t('#zpl_car#zpl_car_order')->update($order['orderid'], array(
                            'tradeno' => $qforder['info']['trade_no'],
                            'status' => 20,
                            'paytime' => $qforder['info']['pay_time'],
                        ));
                    } elseif ($order['type'] == helper::$ORDER_TYPE_ZDCL) {
                        if ($order['cid']) {
                            $body = unserialize($order['body']);
                            $car = C::t('#zpl_car#zpl_car')->fetch($order['cid']);
                            if ($car['topexpireat'] <= time()) {
                                C::t('#zpl_car#zpl_car')->update($order['cid'], array(
                                    'topexpireat' => time() + intval($body[0] * 24 * 3600),
                                    'updatetime' => time(),
                                ));
                            } else {
                                C::t('#zpl_car#zpl_car')->update($order['cid'], array(
                                    'topexpireat' => $car['topexpireat'] + intval($body[0] * 24 * 3600),
                                    'updatetime' => time(),
                                ));
                            }
                        }
                        C::t('#zpl_car#zpl_car_order')->update($order['orderid'], array(
                            'tradeno' => $qforder['info']['trade_no'],
                            'status' => 20,
                            'paytime' => $qforder['info']['pay_time'],
                        ));
                    }
                }
            }
        }
    } elseif ($_GET['type'] == 'mag') {
        $url = $magappurl . 'core/pay/pay/orderStatusQuery?unionOrderNum=' . $_GET['orderno'] . '&secret=' . $magsecret;
        $res = json_decode(helper::get($url), true);
        if ($res['paycode'] == 1) {
            $order = C::t('#zpl_car#zpl_car_order')->fetch_by_tradeno($_GET['orderno'], 10, pay::$PAYMENT_METHOD_APP_MAG);
            if ($order) {
                if (in_array($order['type'], array(helper::$ORDER_TYPE_GRFB, helper::$ORDER_TYPE_SJFB))) {
                    if ($order['cid']) {
                        C::t('#zpl_car#zpl_car')->update($order['cid'], array(
                            'paystatus' => 1,
                            'updatetime' => time(),
                        ));
                    }
                    C::t('#zpl_car#zpl_car_order')->update($order['orderid'], array(
                        'status' => 20,
                    ));
                } elseif ($order['type'] == helper::$ORDER_TYPE_SJRZ) {
                    if ($order['storeid']) {
                        C::t('#zpl_car#zpl_car_store')->update($order['storeid'], array(
                            'paystatus' => 1,
                            'updatetime' => time(),
                        ));
                    }
                    C::t('#zpl_car#zpl_car_order')->update($order['orderid'], array(
                        'status' => 20,
                    ));
                } elseif ($order['type'] == helper::$ORDER_TYPE_ZDCL) {
                    if ($order['cid']) {
                        $body = unserialize($order['body']);
                        $car = C::t('#zpl_car#zpl_car')->fetch($order['cid']);
                        if ($car['topexpireat'] <= time()) {
                            C::t('#zpl_car#zpl_car')->update($order['cid'], array(
                                'topexpireat' => time() + intval($body[0] * 24 * 3600),
                                'updatetime' => time(),
                            ));
                        } else {
                            C::t('#zpl_car#zpl_car')->update($order['cid'], array(
                                'topexpireat' => $car['topexpireat'] + intval($body[0] * 24 * 3600),
                                'updatetime' => time(),
                            ));
                        }
                    }
                    C::t('#zpl_car#zpl_car_order')->update($order['orderid'], array(
                        'status' => 20,
                    ));
                }
            }
        }
    }
} elseif ($_GET['action'] == 'inquiry') {
    $cid = intval($_GET['cid']);
    $mobile = trim($_GET['mobile']);
    $code = trim($_GET['code']);

    if ($_GET['formhash'] != formhash()) {
        include template('common/header_ajax');
        echo json_encode(array('status' => 0, 'msg' => $zclangs['zclang_submit_invalid']), 320);
        include template('common/footer_ajax');
        dexit();
    }

    if (!$cid || !$mobile || !$code) {
        include template('common/header_ajax');
        echo helper_json::encode(array('status' => 0, 'msg' => $zclangs['zclang_required']));
        include template('common/footer_ajax');
        dexit();
    }

    if (!preg_match('/^[1]([3-9])[0-9]{9}$/', $mobile)) {
        include template('common/header_ajax');
        echo helper_json::encode(array('status' => -1));
        include template('common/footer_ajax');
        dexit();
    }

    include template('common/header_ajax');
    $verify = new verify();
    $checkres = $verify->check($code);
    if (!$checkres) {
        echo helper_json::encode(array('status' => 0, 'msg' => $zclangs['zclang_ajax_code_error']));
    } else {
        C::t('#zpl_car#zpl_car_inquiryrecord')->insert(array(
            'cid' => $cid,
            'uid' => intval($_G['uid']),
            'phone' => $mobile,
            'dateline' => time(),
            'ip' => $_G['clientip'],
        ));
        echo helper_json::encode(array('status' => 1, 'msg' => $zclangs['zclang_ajax_submit_success']));
    }
    include template('common/footer_ajax');
    dexit();
} elseif ($_GET['action'] == 'collect') {
    if (empty($_G['uid'])) {
        include template('common/header_ajax');
        echo helper_json::encode(array('status' => -1));
        include template('common/footer_ajax');
        dexit();
    }

    $cid = intval($_GET['cid']);
    $uid = $_G['uid'];

    if ($_GET['formhash'] != formhash()) {
        include template('common/header_ajax');
        echo json_encode(array('status' => 0, 'msg' => $zclangs['zclang_submit_invalid']), 320);
        include template('common/footer_ajax');
        dexit();
    }

    include template('common/header_ajax');
    $collection = C::t('#zpl_car#zpl_car_collection')->fetch_by_cid_uid($cid, $uid);
    if ($collection) {
        C::t('#zpl_car#zpl_car_collection')->delete($collection['collid']);
        echo helper_json::encode(array('status' => 1));
    } else {
        C::t('#zpl_car#zpl_car_collection')->insert(array(
            'cid' => $cid,
            'uid' => $uid,
            'dateline' => time(),
        ));
        echo helper_json::encode(array('status' => 2));
    }
    include template('common/footer_ajax');
    dexit();
} elseif ($_GET['action'] == 'detailrecommlist') {
    $page = intval($_GET['page']);
    $size = intval($_GET['size']);
    if ($size > 20) {
        include template('common/header_ajax');
        echo json_encode(array('status' => 0, 'msg' => $zclangs['zclang_ajax_limit_error']), 320);
        include template('common/footer_ajax');
        dexit();
    }
    $data = C::t('#zpl_car#zpl_car')->fetch_all_by_recomm($page, $size, 2);
    foreach ($data as $key => $datum) {
        $data[$key]['isshowtopsign'] = time() > $datum['topexpireat'] ? 0 : 1;
        $data[$key]['sname'] = trim($datum['sname']);
        $data[$key]['image'] = helper::gethandledurl($datum['image']);
        $data[$key]['cardyear'] = $datum['cardyear'] ? $datum['cardyear'] : '';
    }
    $nextpagedata = C::t('#zpl_car#zpl_car')->fetch_all_by_recomm($page + 1, $size, 2);
    $hasnext = $nextpagedata ? 1 : 0;
    include template('common/header_ajax');
    echo helper_json::encode(array('status' => 1, 'data' => $data, 'hasnext' => $hasnext));
    include template('common/footer_ajax');
    dexit();
} elseif ($_GET['action'] == 'storecarlist') {
    $page = intval($_GET['page']);
    $size = intval($_GET['size']);
    if ($size > 20) {
        include template('common/header_ajax');
        echo json_encode(array('status' => 0, 'msg' => $zclangs['zclang_ajax_limit_error']), 320);
        include template('common/footer_ajax');
        dexit();
    }
    $data = C::t('#zpl_car#zpl_car')->fetch_all_by_storeid($page, $size, intval($_GET['storeid']));
    foreach ($data as $key => $datum) {
        $data[$key]['sname'] = trim($datum['sname']);
        $data[$key]['image'] = helper::gethandledurl($datum['image']);
        $data[$key]['cardyear'] = $datum['cardyear'] ? $datum['cardyear'] : '';
    }
    $nextpagedata = C::t('#zpl_car#zpl_car')->fetch_all_by_storeid($page + 1, $size, intval($_GET['storeid']));
    $hasnext = $nextpagedata ? 1 : 0;
    include template('common/header_ajax');
    echo helper_json::encode(array('status' => 1, 'data' => $data, 'hasnext' => $hasnext));
    include template('common/footer_ajax');
    dexit();
} elseif ($_GET['action'] == 'mylist') {
    if (empty($_G['uid'])) {
        include template('common/header_ajax');
        echo helper_json::encode(array('status' => -1));
        include template('common/footer_ajax');
        dexit();
    }

    $uid = $_G['uid'];
    $store = C::t('#zpl_car#zpl_car_store')->fetch_by_uid($_G['uid']);

    if ($_GET['op'] == 'sh') {
        if ($_GET['formhash'] != formhash()) {
            include template('common/header_ajax');
            echo json_encode(array('status' => 0, 'msg' => $zclangs['zclang_submit_invalid']), 320);
            include template('common/footer_ajax');
            dexit();
        }

        $cid = intval($_GET['cid']);
        $car = C::t('#zpl_car#zpl_car')->fetch_by_cid_uid($cid, $uid);
        if ($car['isshow']) {
            C::t('#zpl_car#zpl_car')->update($car['cid'], array('isshow' => 0));
        } else {
            C::t('#zpl_car#zpl_car')->update($car['cid'], array('isshow' => 1));
        }
        include template('common/header_ajax');
        echo helper_json::encode(array('status' => 1));
        include template('common/footer_ajax');
        dexit();
    }

    if ($_GET['op'] == 'ss') {
        if ($_GET['formhash'] != formhash()) {
            include template('common/header_ajax');
            echo json_encode(array('status' => 0, 'msg' => $zclangs['zclang_submit_invalid']), 320);
            include template('common/footer_ajax');
            dexit();
        }

        $cid = intval($_GET['cid']);
        $car = C::t('#zpl_car#zpl_car')->fetch_by_cid_uid($cid, $uid);
        if ($car['issold']) {
            C::t('#zpl_car#zpl_car')->update($car['cid'], array('issold' => 0));
        } else {
            C::t('#zpl_car#zpl_car')->update($car['cid'], array('issold' => 1));
        }
        include template('common/header_ajax');
        echo helper_json::encode(array('status' => 1));
        include template('common/footer_ajax');
        dexit();
    }

    if ($_GET['op'] == 'delete') {
        $cid = intval($_GET['cid']);

        if ($_GET['formhash'] != formhash()) {
            include template('common/header_ajax');
            echo json_encode(array('status' => 0, 'msg' => $zclangs['zclang_submit_invalid']), 320);
            include template('common/footer_ajax');
            dexit();
        }

        C::t('#zpl_car#zpl_car')->delete_by_cid_uid($cid, $uid);
        C::t('#zpl_car#zpl_car_config')->delete_by_cid_uid($cid, $uid);
        C::t('#zpl_car#zpl_car_attachment')->delete_by_cid_uid($cid, $uid);
        include template('common/header_ajax');
        echo helper_json::encode(array('status' => 1));
        include template('common/footer_ajax');
        dexit();
    }

    $page = intval($_GET['page']);
    $size = intval($_GET['size']);
    if ($size > 20) {
        include template('common/header_ajax');
        echo json_encode(array('status' => 0, 'msg' => $zclangs['zclang_ajax_limit_error']), 320);
        include template('common/footer_ajax');
        dexit();
    }
    $data = C::t('#zpl_car#zpl_car')->fetch_all_by_uid($uid, $page, $size, $_GET['isstore'] ? intval($store['storeid']) : 0);
    foreach ($data as $key => $datum) {
        $data[$key]['sname'] = trim($datum['sname']);
        $data[$key]['isshowexpiretime'] = time() > $datum['topexpireat'] ? 0 : 1;
        $data[$key]['expiretime'] = date('Y-m-d H:i', $datum['topexpireat']);
        $data[$key]['image'] = helper::gethandledurl($datum['image']);
        $data[$key]['cardyear'] = $datum['cardyear'] ? $datum['cardyear'] : '';
        $data[$key]['dorh'] = $datum['isshow'] ? '<span class="weui-mark-rt bg">' . $zclangs['zclang_displayed'] . '</span>' : '<span class="weui-mark-rt bg-gray" style="color: #fff; background-color: #999;">' . $zclangs['zclang_hidden'] . '</span>';
        $data[$key]['sorh'] = $datum['isshow'] ? $zclangs['zclang_hide'] : $zclangs['zclang_show'];
        $data[$key]['wory'] = $datum['issold'] ? $zclangs['zclang_car_ws'] : $zclangs['zclang_car_ys'];
    }
    $nextpagedata = C::t('#zpl_car#zpl_car')->fetch_all_by_uid($uid, $page + 1, $size, $_GET['isstore'] ? intval($store['storeid']) : 0);
    $hasnext = $nextpagedata ? 1 : 0;
    include template('common/header_ajax');
    echo helper_json::encode(array('status' => 1, 'data' => $data, 'hasnext' => $hasnext));
    include template('common/footer_ajax');
    dexit();
} elseif ($_GET['action'] == 'inquiryrecords') {
    if (empty($_G['uid'])) {
        include template('common/header_ajax');
        echo helper_json::encode(array('status' => -1));
        include template('common/footer_ajax');
        dexit();
    }

    $uid = $_G['uid'];
    $store = C::t('#zpl_car#zpl_car_store')->fetch_by_uid($_G['uid']);

    $isstore = intval($_GET['isstore']);
    $page = intval($_GET['page']);
    $size = intval($_GET['size']);
    if ($size > 20) {
        include template('common/header_ajax');
        echo json_encode(array('status' => 0, 'msg' => $zclangs['zclang_ajax_limit_error']), 320);
        include template('common/footer_ajax');
        dexit();
    }
    $storeid = $isstore == 1 ? $store['storeid'] : 0;
    $data = C::t('#zpl_car#zpl_car_inquiryrecord')->fetch_all_by_cuid($uid, $page, $size, $storeid);
    foreach ($data as $key => $datum) {
        $data[$key]['sname'] = trim($datum['sname']);
        $data[$key]['time'] = date('Y-m-d', $datum['dateline']);
        $data[$key]['image'] = helper::gethandledurl($datum['image']);
        $data[$key]['cardyear'] = $datum['cardyear'] ? $datum['cardyear'] : '';
    }
    $nextpagedata = C::t('#zpl_car#zpl_car_inquiryrecord')->fetch_all_by_cuid($uid, $page + 1, $size, $storeid);
    $hasnext = $nextpagedata ? 1 : 0;
    include template('common/header_ajax');
    echo helper_json::encode(array('status' => 1, 'data' => $data, 'hasnext' => 0));
    include template('common/footer_ajax');
    dexit();
} elseif ($_GET['action'] == 'collectionlist') {
    if (empty($_G['uid'])) {
        include template('common/header_ajax');
        echo helper_json::encode(array('status' => -1));
        include template('common/footer_ajax');
        dexit();
    }

    $uid = $_G['uid'];

    if ($_GET['op'] == 'cancelcoll') {
        $cid = intval($_GET['cid']);

        if ($_GET['formhash'] != formhash()) {
            include template('common/header_ajax');
            echo json_encode(array('status' => 0, 'msg' => $zclangs['zclang_submit_invalid']), 320);
            include template('common/footer_ajax');
            dexit();
        }

        $collection = C::t('#zpl_car#zpl_car_collection')->fetch_by_cid_uid($cid, $uid);
        if ($collection) {
            C::t('#zpl_car#zpl_car_collection')->delete($collection['collid']);
        }
        include template('common/header_ajax');
        echo helper_json::encode(array('status' => 1));
        include template('common/footer_ajax');
        dexit();
    }

    $page = intval($_GET['page']);
    $size = intval($_GET['size']);
    if ($size > 20) {
        include template('common/header_ajax');
        echo json_encode(array('status' => 0, 'msg' => $zclangs['zclang_ajax_limit_error']), 320);
        include template('common/footer_ajax');
        dexit();
    }
    $data = C::t('#zpl_car#zpl_car_collection')->fetch_all_by_uid($uid, $page, $size);
    foreach ($data as $key => $datum) {
        $data[$key]['sname'] = trim($datum['sname']);
        $data[$key]['time'] = date('Y-m-d', $datum['dateline']);
        $data[$key]['image'] = helper::gethandledurl($datum['image']);
        $data[$key]['cardyear'] = $datum['cardyear'] ? $datum['cardyear'] : '';
    }
    $nextpagedata = C::t('#zpl_car#zpl_car_collection')->fetch_all_by_uid($uid, $page + 1, $size, 2);
    $hasnext = $nextpagedata ? 1 : 0;
    include template('common/header_ajax');
    echo helper_json::encode(array('status' => 1, 'data' => $data, 'hasnext' => 0));
    include template('common/footer_ajax');
    dexit();
} elseif ($_GET['action'] == 'browserecords') {
    if (empty($_G['uid'])) {
        include template('common/header_ajax');
        echo helper_json::encode(array('status' => -1));
        include template('common/footer_ajax');
        dexit();
    }

    $uid = $_G['uid'];

    $page = intval($_GET['page']);
    $size = intval($_GET['size']);
    if ($size > 20) {
        include template('common/header_ajax');
        echo json_encode(array('status' => 0, 'msg' => $zclangs['zclang_ajax_limit_error']), 320);
        include template('common/footer_ajax');
        dexit();
    }
    $data = C::t('#zpl_car#zpl_car_browserecord')->fetch_all_by_uid($uid, $page, $size);
    foreach ($data as $key => $datum) {
        $data[$key]['sname'] = trim($datum['sname']);
        $data[$key]['time'] = date('Y-m-d', $datum['dateline']);
        $data[$key]['image'] = helper::gethandledurl($datum['image']);
        $data[$key]['cardyear'] = $datum['cardyear'] ? $datum['cardyear'] : '';
    }
    $nextpagedata = C::t('#zpl_car#zpl_car_browserecord')->fetch_all_by_uid($uid, $page + 1, $size, 2);
    $hasnext = $nextpagedata ? 1 : 0;
    include template('common/header_ajax');
    echo helper_json::encode(array('status' => 1, 'data' => $data, 'hasnext' => 0));
    include template('common/footer_ajax');
    dexit();
} elseif ($_GET['action'] == 'top') {
    if ($_GET['op'] == 'pay') {
        if (empty($_G['uid'])) {
            include template('common/header_ajax');
            echo helper_json::encode(array('status' => -1));
            include template('common/footer_ajax');
            dexit();
        }

        $toptype = $_GET['toptype'];
        $toprules = explode(PHP_EOL, $vars['topcarpayrules']);
        $rulesarr = array();
        foreach ($toprules as $toprule) {
            $arr = explode('|', $toprule);
            $arr[2] = str_replace('{days}', $arr[0], $arr[2]);
            $arr[2] = str_replace('{money}', $arr[1], $arr[2]);
            foreach ($arr as $key => $value) {
                $arr[$key] = str_replace(["\r\n", "\n", "\r"], "", $value);
            }
            $rulesarr[$arr[0]] = $arr;
        }

        $user = C::t('#zpl_car#zpl_car_user')->fetch($_G['uid']);
        $config = array(
            'env' => helper::getenv(),
            'orderno' => helper::generateorderno(),
            'amount' => helper::keeptwodecimal($rulesarr[$toptype][1]),
            'body' => CHARSET == 'gbk' ? iconv('GBK', 'UTF-8', $zclangs['zclang_car_order_type_40']) : $zclangs['zclang_car_order_type_40'],
            'openid' => $user['openid'],
        );
        $pay = new pay($config);
        $parameters = $pay->order();

        $orderdata = array(
            'orderno' => $pay->orderno,
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'paymentmethod' => $pay->paymentmethod,
            'status' => '10',
            'price' => $pay->amount,
            'type' => helper::$ORDER_TYPE_ZDCL,
            'createtime' => time(),
            'cid' => $_GET['cid'],
            'storeid' => $_GET['storeid'],
            'body' => serialize($rulesarr[$toptype]),
            'ip' => $_G['clientip'],
        );
        C::t('#zpl_car#zpl_car_order')->insert($orderdata);

        if ($pay->err) {
            include template('common/header_ajax');
            echo helper_json::encode(array('status' => 0, 'msg' => $pay->errmsg));
            include template('common/footer_ajax');
            dexit();
        } else {
            $successmsg = $zclangs['zclang_succeed'];
            $ajaxerrmsg = $zclangs['zclang_tpl_ajax_error'];
            $redirecturl = $_GET['redirecturl'];
            include template('common/header_ajax');
            echo helper_json::encode(array('status' => 1, 'data' => array(
                'paymentmethod' => $pay->paymentmethod,
                'parameters' => $parameters,
                'orderno' => $pay->orderno,
                'redirecturl' => $redirecturl,
                'successmsg' => $successmsg,
                'ajaxerrmsg' => $ajaxerrmsg,
            )));
            include template('common/footer_ajax');
            dexit();
        }
    } else {
        $toprules = explode(PHP_EOL, $vars['topcarpayrules']);
        $rulesarr = array();
        foreach ($toprules as $toprule) {
            $arr = explode('|', $toprule);
            $arr[2] = str_replace('{days}', '<span style="color: #f85d00"> ' . $arr[0] . ' </span>', $arr[2]);
            $arr[2] = str_replace('{money}', '<span style="color: #f85d00"> ' . $arr[1] . ' </span>', $arr[2]);
            foreach ($arr as $key => $value) {
                $arr[$key] = str_replace(["\r\n", "\n", "\r"], "", $value);
            }
            $rulesarr[$arr[0]] = $arr;
        }
        $html .= '<div class="weui-cells weui-cells_radio">';
        $count = 0;
        foreach ($rulesarr as $key => $item) {
            $html .= '<label class="weui-cell weui-check__label" style="padding: .2rem 0;" for="top' . $key . '">';
            $html .= '<div class="weui-cell__bd">';
            $html .= '<p style="font-size: .26rem">'. $item[2] . '</p>';
            $html .= '</div>';
            $html .= '<div class="weui-cell__ft" style="margin-right: 0">';
            if ($count == 0) {
                $html .= '<input name="toptype" value="' . $key . '" class="weui-check" checked="checked" id="top' . $key . '" type="radio">';
            } else {
                $html .= '<input name="toptype" value="' . $key . '" class="weui-check" id="top' . $key . '" type="radio">';
            }
            $html .= '<span class="weui-icon-checked"></span>';
            $html .= '</div>';
            $html .= '</label>';
            $count++;
        }
        $html .= '</div>';
        $config = array(
            'env' => helper::getenv(),
            'title' => $zclangs['zclang_car_order_type_40'],
            'content' => $html,
            'openwxpay' => $vars['openwxpay'],
            'openalipay' => $vars['openalipay'],
            'langchoose' => $zclangs['zclang_tpl_pay_choose'],
            'langwxpay' => $zclangs['zclang_tpl_wxpay'],
            'langalipay' => $zclangs['zclang_tpl_alipay'],
            'langconfirm' => $zclangs['zclang_tpl_confirm_pay'],
            'langsuccessmsg' => $zclangs['zclang_succeed'],
            'langajaxerror' => $zclangs['zclang_tpl_ajax_error'],
            'dataordertype' => helper::$ORDER_TYPE_ZDCL,
            'datacid' => intval($_GET['cid']),
            'datastoreid' => intval($_GET['storeid']),
            'databody' => '',
            'currenturl' => trim($_GET['currenturl']),
            'redirecturl' => trim($_GET['redirecturl']),
        );
        include template('common/header_ajax');
        echo helper_json::encode(array('status' => 1, 'config' => $config));
        include template('common/footer_ajax');
        dexit();
    }
}

function getws($likekeys, $otherkeys)
{
    $wherearr = array();

    foreach ($likekeys as $var) {
        $value = isset($_GET[$var])?stripsearchkey($_GET[$var]):'';
        if(strlen($value)>1) {
            $value = addslashes($value);
            $wherearr[] = "CONCAT_WS(' ', b.name, s.name, c.cartype) LIKE BINARY '%$value%'";
        }
    }

    foreach ($otherkeys as $var) {
        $tempvar = substr($var, strpos($var, '.') ? strpos($var, '.') + 1 : 0);
        if (strpos($_GET[$tempvar], '-') === false) {
            if ($tempvar == 'storeid') {
                if ($_GET['type'] == 'geren') {
                    $wherearr[] = "{$var}=0";
                } elseif ($_GET['type'] == 'shangjia') {
                    $wherearr[] = "{$var}!=0";
                }
            } else {
                $value = isset($_GET[$tempvar]) ? $_GET[$tempvar] : '';
                if (strlen($value)) {
                    $var = addslashes($var);
                    $wherearr[] = "{$var}='" . intval($value) . "'";
                }
            }
        } else {
            $valuearray = explode('-', $_GET[$tempvar]);
            if ($tempvar == 'age') {
                $value1 = getmonthtime($valuearray[1]);
                $value2 = getmonthtime($valuearray[0]);
                $var = 'c.cardtime';
            } else {
                $value1 = $valuearray[0];
                $value2 = $valuearray[1];
            }
            if ($value1) {
                $value1 = addslashes($value1);
                if (!$value2) {
                    $wherearr[] = "{$var}>'$value1'";
                } else {
                    $wherearr[] = "{$var}>='$value1'";
                }
            }
            if ($value2) {
                $value2 = addslashes($value2);
                if (!$value1) {
                    $wherearr[] = "{$var}<'$value2'";
                } else {
                    $wherearr[] = "{$var}<='$value2'";
                }
            }
        }
    }

    return empty($wherearr) ? '1' : implode(' AND ', $wherearr);
}

function getmonthtime($years)
{
    if (!$years) {
        return null;
    }
    $date = explode('-', date('Y-m', time()));
    return strtotime(((string)(intval($date[0]) - intval($years))) . '-' . $date[1]);
}

function required($array = array())
{
    global $_G;
    loadcache(['zpl_car_langs']);
    $zclangs = $_G['cache']['zpl_car_langs'];

    foreach ($array as $value) {
        if (($value !== 'sid' && $value !== 'new') && ($_POST[$value] == null || $_POST[$value] == '')) {
            include template('common/header_ajax');
            echo helper_json::encode(array('status' => 0, 'msg' => $zclangs['zclang_required']));
            include template('common/footer_ajax');
            dexit();
        }
    }
}
//From: Dism_taobao-com
?>