<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zpl_car/helper.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/wechat.lib.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/wechat.class.php';

global $_G;

loadcache(['plugin']);
$vars = $_G['cache']['plugin']['zpl_car'];
$openwxlogin = $vars['openwxlogin'];
$appid = $vars['wxappid'];
$appsecret = $vars['wxappsecret'];

$returnurl = $_GET['returnurl'];
$redirecturi = $_G['siteurl'] . 'plugin.php?id=zpl_car:login&returnurl=' . urlencode($returnurl);

if (helper::isweixin() && $openwxlogin == 1) {
    // WX login
    if (!isset($_GET['code'])) {
        $redirecturi = urlencode($redirecturi);
        $wxurl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$appid}&redirect_uri={$redirecturi}&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";
        dheader('location: ' . $wxurl);
    } else {
        require_once libfile('function/member');

        $wechat_client = new WeChatClient($appid, $appsecret);

        $code = $_GET['code'];
        $returnurl = $_GET['returnurl'];
        $tokeninfo = $wechat_client->getAccessTokenByCode($code);
        if ($tokeninfo['openid']) {
            $openid = $tokeninfo['openid'];
            $mp = C::t('#zpl_car#zpl_car_user_wxmp')->fetch_by_openid($openid);
            if ($mp) {
                $member = getuserbyuid($mp['uid'], 1);
                setloginstatus($member, 1296000);
            } else {
                $uid = ZplWeChat::register(ZplWeChat::getnewname($openid), 1);
                $data = array(
                    'uid' => $uid,
                    'openid' => $openid,
                );
                C::t('#zpl_car#zpl_car_user_wxmp')->insert($data);
            }
            C::t('#zpl_car#zpl_car_user')->update($_G['uid'], array('openid' => $openid));
            dheader('location: ' . $returnurl);
        } else {
            showmessage('not_loggedin', $returnurl, '', array('login' => 1));
        }
    }
} elseif (strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX") !== false) {
    // MAGAPP login
    include_once template('zpl_car:mag_login');
    dexit();
} elseif (strstr($_SERVER['HTTP_USER_AGENT'], "QianFan") !== false) {
    // QFAPP login
    include_once template('zpl_car:qianfan_login');
    dexit();
} else {
    // common login
    showmessage('not_loggedin', $returnurl, '', array('login' => 1));
}
//From: Dism_taobao-com
?>