function showerrmsg(msg, duration, url) {
    $.toptip(msg, duration);
    if (url !== undefined) {
        setTimeout(function () {
            location.href = url;
        }, duration);
    }
}

function showsuccessmsg(msg, duration, refresh, url) {
    msg = '<i class="weui-icon-success-circle" style="font-size: .4rem; color: #fff"></i>' + (msg || '');
    duration = duration || 3000;
    $.toptip(msg, duration, 'success');
    refresh = refresh === undefined ? true : refresh;
    setTimeout(function () {
        if (refresh === true) {
            if (url !== undefined) {
                location.href = url;
            } else {
                location.reload();
            }
        }
    }, duration);
}

function getqueryurlpar(url) {
    url = url || window.location.href;
    var reg = /([^?=&]+)=([^?=&]+)/g;
    var obj = {};
    url.replace(reg, function () {
        obj[arguments[1]] = arguments[2];
    });
    return obj;
}

function geturlwithoutpar(url) {
    url = url || window.location.href;
    return url.indexOf('?') !== -1 ? url.substring(0, url.indexOf('?')) : url;
}

function geturlparhandled(data, url) {
    var urlPar = getqueryurlpar(url);
    var urlWithoutPar = geturlwithoutpar(url);
    $.extend(true, urlPar, data);
    return $.isEmptyObject(urlPar) === true ? urlWithoutPar : urlWithoutPar + '?' + decodeURIComponent($.param(urlPar, true));
}

function getqueryvariable(variable) {
    var query = window.location.search.substring(1);
    var vars = query.split("&");
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == variable) {
            return pair[1];
        }
    }
    return false;
}

function initimgheight() {
    $('img.weui-media-box__thumb').each(function () {
        var w = $(this).width();
        $(this).parents('.weui-media-box__hd').css('height', w * 2/3);
    });
}

function pay(paymentmethod, parameters, orderno, redirecturl, successmsg, ajaxerrmsg) {
    if (paymentmethod == 'WX-JSAPI') {
        wxpay(parameters, orderno, redirecturl, successmsg, ajaxerrmsg);
    } else if (paymentmethod == 'APP-QF') {
        qfpay(parameters, redirecturl, successmsg, ajaxerrmsg);
    } else if (paymentmethod == 'APP-MAG') {
        magpay(parameters, redirecturl, successmsg, ajaxerrmsg);
    }
}

function wxpay(jsapiparameters, orderno, redirecturl, successmsg, ajaxerrmsg) {
    function jsApiCall() {
        WeixinJSBridge.invoke(
            'getBrandWCPayRequest',
            (JSON.parse(jsapiparameters)),
            function (res) {
                if (res.err_msg == "get_brand_wcpay_request:ok") {
                    var t = setInterval(function () {
                        $.ajax({
                            type: 'GET',
                            url: 'plugin.php?id=zpl_car:ajax&action=getorder&orderno=' + orderno,
                            data: {type: 'wx'},
                            dataType: 'xml',
                            success: function (res) {
                                res = JSON.parse($(res).find('root').text());
                                if (res.status == 1) {
                                    clearInterval(t);
                                    showsuccessmsg(successmsg, 3000, true, redirecturl);
                                }
                            },
                            error: function (xhr, type) {
                                alert(ajaxerrmsg);
                            }
                        });
                    }, 2000);
                }
            }
        );
    }
    if (typeof WeixinJSBridge == "undefined") {
        if (document.addEventListener) {
            document.addEventListener('WeixinJSBridgeReady', jsApiCall, false);
        } else if (document.attachEvent) {
            document.attachEvent('WeixinJSBridgeReady', jsApiCall);
            document.attachEvent('onWeixinJSBridgeReady', jsApiCall);
        }
    } else {
        jsApiCall();
    }
}

function qfpay(jsonstr, redirecturl, successmsg, ajaxerrmsg) {
    var json = JSON.parse(jsonstr);
    var after = function (state, data) {
        if(state == 1){
            var orderid = parseInt(data.order_id);
            QFH5.jumpPayOrder(orderid, function (state, data) {
                if (state == 1) {
                    $.ajax({
                        type: 'GET',
                        data: {type: 'qf'},
                        url: 'plugin.php?id=zpl_car:ajax&action=getorder&orderno=' + orderid,
                        dataType: 'xml',
                        success: function (res) {
                        },
                        error: function (xhr, type) {
                            alert(ajaxerrmsg);
                        }
                    });

                    var t = setInterval(function () {
                        clearInterval(t);
                        showsuccessmsg(successmsg, 3000, true, redirecturl);
                    }, 2000);
                }
            })
        }
    };
    try {
        // 3.0
        QFH5.Order(jsonstr, function (state, data) {
            after(state, data);
        });
    } catch (e) {
        // 2.2
        QFH5.createOrder(json.type, json.item, json.send_type, json.address, json.allow_pay_type, function (state, data) {
            after(state, data);
        });
    }
}

function magpay(configstr, redirecturl, successmsg, ajaxerrmsg) {
    var config = JSON.parse(configstr);
    mag.pay(config, function () {
        $.ajax({
            type: 'GET',
            data: {type: 'mag'},
            url: 'plugin.php?id=zpl_car:ajax&action=getorder&orderno=' + config.unionOrderNum,
            dataType: 'xml',
            success: function (res) {
            },
            error: function (xhr, type) {
                alert(ajaxerrmsg);
            }
        });

        var t = setInterval(function () {
            clearInterval(t);
            showsuccessmsg(successmsg, 3000, true, redirecturl);
        }, 2000);
    }, function () {
    });
}

function otherpay(config) {
    var c = $.extend({
        env: '',
        title: '',
        content: '',
        openwxpay: 0,
        openalipay: 0,
        langchoose: '',
        langwxpay: '',
        langalipay: '',
        langconfirm: '',
        langsuccessmsg: '',
        langajaxerror: '',
        currenturl: '',
        redirecturl: '',
        dataordertype: 0,
        datacid: 0,
        datastoreid: 0,
        databody: '',
    }, JSON.parse(config));
    var index, html = '';
    if (c.openwxpay == 1) {
        html +=
            '        <label class="weui-cell weui-check__label" style="padding: .2rem 0;" for="x11">\n' +
            '            <div class="weui-cell__bd">\n' +
            '                <p class="pay-method"><img src="source/plugin/zpl_car/assets/images/wxpay.png">' + c.langwxpay + '</p>\n' +
            '            </div>\n' +
            '            <div class="weui-cell__ft" style="margin-right: 0">\n' +
            '                <input name="paytype" value="WXPAY" class="weui-check" checked="checked" id="x11" type="radio">\n' +
            '                <span class="weui-icon-checked"></span>\n' +
            '            </div>\n' +
            '        </label>\n';
    }
    if (c.openalipay == 1) {
        html +=
            '        <label class="weui-cell weui-check__label" style="padding: .2rem 0;" for="x12">\n' +
            '            <div class="weui-cell__bd">\n' +
            '                <p class="pay-method"><img src="source/plugin/zpl_car/assets/images/alipay.png">' + c.langalipay + '</p>\n' +
            '            </div>\n' +
            '            <div class="weui-cell__ft" style="margin-right: 0">\n' +
            '                <input name="paytype" value="ALIPAY" class="weui-check" id="x12" type="radio">\n' +
            '                <span class="weui-icon-checked"></span>\n' +
            '            </div>\n' +
            '        </label>\n';
    }
    index = layer.open({
        type: 1,
        content:
            '<div class="pay">\n' +
            '    <div class="pay-header">\n' +
            '        <div class="pay-title">' + c.title + '</div>\n' +
            '        <div class="pay-close">\n' +
            '            <span class="icon icon-95"></span>\n' +
            '        </div>\n' +
            '    </div>\n' +
            '    <div class="pay-content">' + c.content + '</div>\n' +
            '    <div class="weui-cells__title">' + c.langchoose + '</div>\n' +
            '    <div class="weui-cells weui-cells_radio">\n' +
            html +
            '    </div>\n' +
            '    <button class="btn-confirm-pay">\n' + c.langconfirm + '</button>\n' +
            '</div>',
        anim: 'up',
        style: 'z-index: 9; position: fixed; bottom: 0; left: 0; width: 100%; height: auto; padding: 10px 0; border: none;',
        success: function (elem) {
            $(elem).find('.pay-close').on('click', function (e) {
                e.preventDefault();
                layer.close(index);
            });
            $(elem).find('.btn-confirm-pay').on('click', function (e) {
                e.preventDefault();
                var paytype = $(elem).find('input[name=paytype]:checked').val();
                var toptype = $(elem).find('input[name=toptype]:checked').val();
                var data = {
                    ordertype: c.dataordertype,
                    toptype: toptype,
                    cid: c.datacid,
                    storeid: c.datastoreid,
                    body: c.databody,
                    currenturl: c.currenturl,
                    redirecturl: c.redirecturl
                };
                if (paytype == 'WXPAY') {
                    if (c.env == 'MOBILE') {
                        otherpaywxmweb(data, c.currenturl, c.langajaxerror);
                    } else if (c.env == 'PC') {
                        otherpaywxnative(data, c.currenturl, c.redirecturl, c.langsuccessmsg, c.langajaxerror);
                    }
                }
            });
        }
    });
}

function otherpaywxmweb(data, currenturl, ajaxerror) {
    $.ajax({
        type: 'GET',
        url: 'plugin.php?id=zpl_car:ajax&action=pay&paytype=WXPAY',
        data: data,
        dataType: 'xml',
        success: function (res) {
            res = JSON.parse($(res).find('root').text());
            if (res.status == -1) {
                location.href = currenturl;
            } else if (res.status == 1) {
                if (res.data.url != '') {
                    location.href = res.data.url;
                }
                $('.pay-mask').click(function (e) {
                    $('.pay-mask').css({'display': 'none'});
                });
            } else {
                $.toptip(res.msg);
            }
        },
        error: function (xhr, type) {
            alert(ajaxerror);
        }
    });
}

function otherpaywxnative(data, currenturl, redirecturl, successmsg, ajaxerror) {
    $.ajax({
        type: 'GET',
        url: 'plugin.php?id=zpl_car:ajax&action=pay&paytype=WXPAY',
        data: data,
        dataType: 'xml',
        success: function (res) {
            res = JSON.parse($(res).find('root').text());
            if (res.status == -1) {
                location.href = currenturl;
            } else if (res.status == 1) {
                if (res.data.url != '') {
                    $('.pay-mask').css({'display': 'flex'}).find('img').attr('src', 'plugin.php?id=zpl_car:qrcode&data=' + res.data.url);
                    var t = setInterval(function () {
                        $.ajax({
                            type: 'GET',
                            url: 'plugin.php?id=zpl_car:ajax&action=getorder&orderno=' + res.data.orderno,
                            data: {type: 'wx'},
                            dataType: 'xml',
                            success: function (res) {
                                res = JSON.parse($(res).find('root').text());
                                if (res.status == 1) {
                                    clearInterval(t);
                                    showsuccessmsg(successmsg, 3000, true, redirecturl);
                                }
                            },
                            error: function (xhr, type) {
                                // alert(ajaxerror);
                            }
                        });
                    }, 2000);
                }
                $('.pay-mask').click(function (e) {
                    if (e.target == e.currentTarget) {
                        $('.pay-mask').css({'display': 'none'});
                    }
                });
            } else {
                $.toptip(res.msg);
            }
        },
        error: function (xhr, type) {
            alert(ajaxerror);
        }
    });
}