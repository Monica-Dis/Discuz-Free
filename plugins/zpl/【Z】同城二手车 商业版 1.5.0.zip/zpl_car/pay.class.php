<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zpl_car/helper.class.php';

if (CHARSET == 'gbk') {
    require_once DISCUZ_ROOT . './source/plugin/zpl_car/libraries/wxpay/gbk/lib/WxPay.Api.php';
    require_once DISCUZ_ROOT . './source/plugin/zpl_car/libraries/wxpay/gbk/example/WxPay.Config.php';
    require_once DISCUZ_ROOT . './source/plugin/zpl_car/libraries/wxpay/gbk/example/WxPay.JsApiPay.php';
} else {
    require_once DISCUZ_ROOT . './source/plugin/zpl_car/libraries/wxpay/utf8/lib/WxPay.Api.php';
    require_once DISCUZ_ROOT . './source/plugin/zpl_car/libraries/wxpay/utf8/example/WxPay.Config.php';
    require_once DISCUZ_ROOT . './source/plugin/zpl_car/libraries/wxpay/utf8/example/WxPay.JsApiPay.php';
}

class pay
{
    public static $PAY_TYPE_WXPAY = 'WXPAY';
    public static $PAY_TYPE_ALIPAY = 'ALIPAY';

    public static $PAYMENT_METHOD_WX_JSAPI = 'WX-JSAPI';
    public static $PAYMENT_METHOD_WX_MWEB = 'WX-MWEB';
    public static $PAYMENT_METHOD_WX_NATIVE = 'WX-NATIVE';
    public static $PAYMENT_METHOD_APP_QF = 'APP-QF';
    public static $PAYMENT_METHOD_APP_MAG = 'APP-MAG';

    public $paytype;
    public $env;
    public $amount;
    public $orderno;
    public $body;
    public $openid;
    public $productid;
    public $wapurl;
    public $wapname;
    public $redirecturl;

    public $paymentmethod;
    public $qfordertypeid;
    public $magappurl;
    public $magsecret;
    public $wxnotifyurl;
    public $qfnotifyurl;
    public $magnotifyurl;

    public $magunionordernum;

    public $err = false;
    public $errmsg;

    public function __construct($config = array())
    {
        if (is_array($config)) {
            foreach ($config as $name => $value) {
                if (property_exists($this, $name)) {
                    $this->$name = $value;
                }
            }
        }

        if (!$this->paymentmethod) {
            if ($this->env == 'WX') {
                $this->paymentmethod = self::$PAYMENT_METHOD_WX_JSAPI;
            } elseif ($this->env == 'MAG') {
                $this->paymentmethod = self::$PAYMENT_METHOD_APP_MAG;
            } elseif ($this->env == 'QF') {
                $this->paymentmethod = self::$PAYMENT_METHOD_APP_QF;
            } elseif ($this->env == 'MOBILE') {
                if ($this->paytype == self::$PAY_TYPE_WXPAY) {
                    $this->paymentmethod = self::$PAYMENT_METHOD_WX_MWEB;
                } elseif ($this->paytype == self::$PAY_TYPE_ALIPAY) {
                    $this->paymentmethod = '';
                }
            } elseif ($this->env == 'PC') {
                if ($this->paytype == self::$PAY_TYPE_WXPAY) {
                    $this->paymentmethod = self::$PAYMENT_METHOD_WX_NATIVE;
                } elseif ($this->paytype == self::$PAY_TYPE_ALIPAY) {
                    $this->paymentmethod = '';
                }
            }
        }

        loadcache(['plugin']);
        global $_G;
        $vars = $_G['cache']['plugin']['zpl_car'];
        if (!$this->qfordertypeid) {
            $this->qfordertypeid = trim($vars['qianfanordertypeid']);
        }
        if (!$this->magappurl) {
            $this->magappurl = trim($vars['magappurl']);
        }
        if (!$this->magsecret) {
            $this->magsecret = trim($vars['magsecret']);
        }

        if (!$this->wxnotifyurl) {
            $this->wxnotifyurl = $_G['siteurl'] . 'source/plugin/zpl_car/wxpay_notify.php';
        }
        if (!$this->qfnotifyurl) {
            $this->qfnotifyurl = $_G['siteurl'] . 'source/plugin/zpl_car/qianfanapppay_notify.php';
        }
        if (!$this->magnotifyurl) {
            $this->magnotifyurl = $_G['siteurl'] . 'source/plugin/zpl_car/magapppay_notify.php';
        }
    }

    public function order()
    {
        if ($this->paymentmethod == self::$PAYMENT_METHOD_WX_JSAPI) {
            return $this->wxjsapiorder();
        } elseif ($this->paymentmethod == self::$PAYMENT_METHOD_WX_MWEB) {
            return $this->wxmweborder();
        } elseif ($this->paymentmethod == self::$PAYMENT_METHOD_WX_NATIVE) {
            return $this->wxnativeorder();
        } elseif ($this->paymentmethod == self::$PAYMENT_METHOD_APP_QF) {
            return $this->qforder();
        } elseif ($this->paymentmethod == self::$PAYMENT_METHOD_APP_MAG) {
            return $this->magorder();
        } else {
            return '';
        }
    }

    public function wxjsapiorder()
    {
        $tools = new JsApiPay();
        $input = new WxPayUnifiedOrder();
        $input->SetBody($this->body);
        $input->SetOut_trade_no($this->orderno);
        $input->SetTotal_fee($this->gettotalfee());
        $input->SetTime_start(date('YmdHis'));
        $input->SetTime_expire(date('YmdHis', time() + 600));
        $input->SetNotify_url($this->wxnotifyurl);
        $input->SetTrade_type('JSAPI');
        $input->SetOpenid($this->openid);
        $wxpayconfig = new WxPayConfig();
        try {
            $result = WxPayApi::unifiedOrder($wxpayconfig, $input);
            return $jsapiparameters = $tools->GetJsApiParameters($result);
        } catch (Exception $e) {
            $this->err = true;
            return $this->errmsg = $e->getMessage();
        }
    }

    public function wxmweborder()
    {
        $input = new WxPayUnifiedOrder();
        $input->SetBody($this->body);
        $input->SetOut_trade_no($this->orderno);
        $input->SetTotal_fee($this->gettotalfee());
        $input->SetTime_start(date('YmdHis'));
        $input->SetTime_expire(date('YmdHis', time() + 600));
        $input->SetNotify_url($this->wxnotifyurl);
        $input->SetTrade_type('MWEB');
        $sceneinfo = '{"h5_info": {"type": "Wap", "wap_url": "' . $this->wapurl . '", "wap_name": "' . $this->wapname . '"}}';
        $sceneinfo = CHARSET == 'gbk' ? iconv('GBK', 'UTF-8', $sceneinfo) : $sceneinfo;
        $input->SetScene_info($sceneinfo);
        $config = new WxPayConfig();
        try {
            $result = WxPayApi::unifiedOrder($config, $input);
        } catch (Exception $e) {
            $this->err = true;
            return $this->errmsg = $e->getMessage();
        }
        if (!isset($result['mweb_url'])) {
            if (CHARSET == 'gbk') {
                $msg = iconv('UTF-8', 'GBK', $result['err_code_des'] ? $result['err_code_des'] : $result['return_msg']);
            } else {
                $msg = $result['err_code_des'] ? $result['err_code_des'] : $result['return_msg'];
            }
            $this->err = true;
            return $this->errmsg = $msg;
        } else {
            return $url = $result['mweb_url'] . '&redirect_url=' . urlencode($this->redirecturl);
        }
    }

    public function wxnativeorder()
    {
        $input = new WxPayUnifiedOrder();
        $input->SetBody($this->body);
        $input->SetOut_trade_no($this->orderno);
        $input->SetTotal_fee($this->gettotalfee());
        $input->SetTime_start(date('YmdHis'));
        $input->SetTime_expire(date('YmdHis', time() + 600));
        $input->SetNotify_url($this->wxnotifyurl);
        $input->SetTrade_type('NATIVE');
        $input->SetProduct_id($this->productid);
        $config = new WxPayConfig();
        try {
            $result = WxPayApi::unifiedOrder($config, $input);
        } catch (Exception $e) {
            $this->err = true;
            return $this->errmsg = $e->getMessage();
        }
        if (!isset($result['code_url'])) {
            if (CHARSET == 'gbk') {
                $msg = iconv('UTF-8', 'GBK', $result['err_code_des'] ? $result['err_code_des'] : $result['return_msg']);
            } else {
                $msg = $result['err_code_des'] ? $result['err_code_des'] : $result['return_msg'];
            }
            $this->err = true;
            return $this->errmsg = $msg;
        } else {
            return urlencode($result['code_url']);
        }
    }

    public function gettotalfee()
    {
        return $this->amount * 100;
    }

    public function qforder()
    {
        $qfpaydata = array(
            'type' => $this->qfordertypeid,
            'item' => array(
                array(
                    'title' => $this->body,
                    'subtitle' => $this->body,
                    'cover' => '',
                    'num' => 1,
                    'cash_cost' => $this->amount,
                    'gold_cost' => 0,
                    'get_expire' => 0,
                ),
            ),
            'send_type' => 0,
            'send_cost' => '0.00',
            'address' => array(),
            'allow_pay_type' => 14,
            'out_trade_no' => $this->orderno,
        );
        return json_encode($qfpaydata);
    }

    public function magorder()
    {
        global $_G;
        $params = array(
            'trade_no' => $this->orderno,
            'callback' => $this->magnotifyurl,
            'amount' => $this->amount,
            'title' => $this->body,
            'user_id' => $_G['uid'],
            'des' => $this->body,
            'remark' => $this->body,
            'secret' => $this->magsecret,
        );
        $url = $this->magappurl . 'core/pay/pay/unifiedOrder?' . http_build_query($params);
        $magres = json_decode(helper::get($url), true);
        if ($magres['success'] != true) {
            $this->err = true;
            return $this->errmsg = CHARSET == 'gbk' ? iconv('UTF-8', 'GBK', trim($magres['msg'])) : trim($magres['msg']);
        }
        $this->magunionordernum = $magres['data']['unionOrderNum'];
        $config = array(
            'money' => $this->amount,
            'title' => $this->body,
            'des' => $this->body,
            'payWay' => array(
                'wallet' => 1,
                'weixin' => 1,
                'alipay' => 1,
            ),
            'orderNum' => $this->orderno,
            'unionOrderNum' => $magres['data']['unionOrderNum'],
            'type' => $this->body,
        );
        return json_encode($config);
    }
}
//From: Dism_taobao-com
?>