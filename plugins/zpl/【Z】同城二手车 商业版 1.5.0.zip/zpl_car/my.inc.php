<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zpl_car/helper.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/wechat.lib.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/wechat.class.php';
require_once DISCUZ_ROOT . './source/plugin/zpl_car/pay.class.php';

$action = $_GET['action'];

loadcache(['plugin', 'zpl_car_langs']);
global $_G;
$vars = $_G['cache']['plugin']['zpl_car'];
$zclangs = $_G['cache']['zpl_car_langs'];

if (!$action) {
    $custserphone = trim($vars['custserphone']);
    $store = C::t('#zpl_car#zpl_car_store')->fetch_by_uid($_G['uid']);
    include_once template('zpl_car:center');
} elseif ($action == 'collectionlist') {
    // login
    if (empty($_G['uid'])) {
        $openwxlogin = $vars['openwxlogin'];
        $appid = $vars['wxappid'];
        $appsecret = $vars['wxappsecret'];

        $returnurl = $_G['siteurl'] . './plugin.php?id=zpl_car:my&action=collectionlist';
        if (helper::isweixin() && $openwxlogin == 1) {
            // WX login
            if (!isset($_GET['code'])) {
                $redirecturi = urlencode($returnurl);
                $wxurl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$appid}&redirect_uri={$redirecturi}&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";
                dheader('location: ' . $wxurl);
            } else {
                require_once libfile('function/member');

                $wechat_client = new WeChatClient($appid, $appsecret);

                $code = $_GET['code'];
                $tokeninfo = $wechat_client->getAccessTokenByCode($code);
                if ($tokeninfo['openid']) {
                    $openid = $tokeninfo['openid'];
                    $mp = C::t('#zpl_car#zpl_car_user_wxmp')->fetch_by_openid($openid);
                    if ($mp) {
                        $member = getuserbyuid($mp['uid'], 1);
                        setloginstatus($member, 1296000);
                    } else {
                        $uid = ZplWeChat::register(ZplWeChat::getnewname($openid), 1);
                        if ($uid) {
                            $data = array(
                                'uid' => $uid,
                                'openid' => $openid,
                            );
                            C::t('#zpl_car#zpl_car_user_wxmp')->insert($data);
                        }
                    }
                    dheader('location: ' . $returnurl);
                } else {
                    // common login
                    showmessage('not_loggedin', NULL, array(), array('login' => 1));
                }
            }
        } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX") !== false) {
            // MAGAPP login
            include_once template('zpl_car:mag_login');
            dexit();
        } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "QianFan") !== false) {
            // QFAPP login
            include_once template('zpl_car:qianfan_login');
            dexit();
        } else {
            // common login
            showmessage('not_loggedin', NULL, array(), array('login' => 1));
        }
    }

    include_once template('zpl_car:collection_list');
} elseif ($action == 'browserecords') {
    // login
    if (empty($_G['uid'])) {
        $openwxlogin = $vars['openwxlogin'];
        $appid = $vars['wxappid'];
        $appsecret = $vars['wxappsecret'];

        $returnurl = $_G['siteurl'] . './plugin.php?id=zpl_car:my&action=browserecords';
        if (helper::isweixin() && $openwxlogin == 1) {
            // WX login
            if (!isset($_GET['code'])) {
                $redirecturi = urlencode($returnurl);
                $wxurl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$appid}&redirect_uri={$redirecturi}&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";
                dheader('location: ' . $wxurl);
            } else {
                require_once libfile('function/member');

                $wechat_client = new WeChatClient($appid, $appsecret);

                $code = $_GET['code'];
                $tokeninfo = $wechat_client->getAccessTokenByCode($code);
                if ($tokeninfo['openid']) {
                    $openid = $tokeninfo['openid'];
                    $mp = C::t('#zpl_car#zpl_car_user_wxmp')->fetch_by_openid($openid);
                    if ($mp) {
                        $member = getuserbyuid($mp['uid'], 1);
                        setloginstatus($member, 1296000);
                    } else {
                        $uid = ZplWeChat::register(ZplWeChat::getnewname($openid), 1);
                        $data = array(
                            'uid' => $uid,
                            'openid' => $openid,
                        );
                        C::t('#zpl_car#zpl_car_user_wxmp')->insert($data);
                    }
                    dheader('location: ' . $returnurl);
                } else {
                    // common login
                    showmessage('not_loggedin', NULL, array(), array('login' => 1));
                }
            }
        } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX") !== false) {
            // MAGAPP login
            include_once template('zpl_car:mag_login');
            dexit();
        } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "QianFan") !== false) {
            // QFAPP login
            include_once template('zpl_car:qianfan_login');
            dexit();
        } else {
            // common login
            showmessage('not_loggedin', NULL, array(), array('login' => 1));
        }
    }

    include_once template('zpl_car:browse_records');
} elseif ($action == 'userinfo') {
    // login
    if (empty($_G['uid'])) {
        $openwxlogin = $vars['openwxlogin'];
        $appid = $vars['wxappid'];
        $appsecret = $vars['wxappsecret'];

        $returnurl = $_G['siteurl'] . './plugin.php?id=zpl_car:my&action=userinfo';
        if (helper::isweixin() && $openwxlogin == 1) {
            // WX login
            if (!isset($_GET['code'])) {
                $redirecturi = urlencode($returnurl);
                $wxurl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$appid}&redirect_uri={$redirecturi}&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";
                dheader('location: ' . $wxurl);
            } else {
                require_once libfile('function/member');

                $wechat_client = new WeChatClient($appid, $appsecret);

                $code = $_GET['code'];
                $tokeninfo = $wechat_client->getAccessTokenByCode($code);
                if ($tokeninfo['openid']) {
                    $openid = $tokeninfo['openid'];
                    $mp = C::t('#zpl_car#zpl_car_user_wxmp')->fetch_by_openid($openid);
                    if ($mp) {
                        $member = getuserbyuid($mp['uid'], 1);
                        setloginstatus($member, 1296000);
                    } else {
                        $uid = ZplWeChat::register(ZplWeChat::getnewname($openid), 1);
                        if ($uid) {
                            $data = array(
                                'uid' => $uid,
                                'openid' => $openid,
                            );
                            C::t('#zpl_car#zpl_car_user_wxmp')->insert($data);
                        }
                    }
                    dheader('location: ' . $returnurl);
                } else {
                    // common login
                    showmessage('not_loggedin', NULL, array(), array('login' => 1));
                }
            }
        } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX") !== false) {
            // MAGAPP login
            include_once template('zpl_car:mag_login');
            dexit();
        } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "QianFan") !== false) {
            // QFAPP login
            include_once template('zpl_car:qianfan_login');
            dexit();
        } else {
            // common login
            showmessage('not_loggedin', NULL, array(), array('login' => 1));
        }
    }

    if (submitcheck('userinfosubmit')) {
        $data = array(
            'name' => dhtmlspecialchars(trim($_POST['name'])),
            'tel' => dhtmlspecialchars(trim($_POST['tel'])),
            'address' => dhtmlspecialchars(trim($_POST['address'])),
            'desc' => dhtmlspecialchars(trim($_POST['desc'])),
        );
        foreach ($data as $value) {
            if (!$value) {
                echo '<script>parent.showerrmsg("' . $zclangs['zclang_required'] . '");</script>';
                dexit();
            }
        }
        if (C::t('#zpl_car#zpl_car_user')->fetch($_G['uid'])) {
            $data['username'] = $_G['username'];
            $data['updatetime'] = time();
            C::t('#zpl_car#zpl_car_user')->update($_G['uid'], $data);
        } else {
            $data['uid'] = $_G['uid'];
            $data['username'] = $_G['username'];
            $data['createtime'] = time();
            $data['updatetime'] = time();
            C::t('#zpl_car#zpl_car_user')->insert($data);
        }
        echo '<script>parent.showsuccessmsg("' . $zclangs['zclang_save_userinfo_success'] . '", 3000, true, "plugin.php?id=zpl_car:my");</script>';
    }
    $user = C::t('#zpl_car#zpl_car_user')->fetch($_G['uid']);
    include_once template('zpl_car:user_info');
} elseif ($action == 'mylist') {
    // login
    if (empty($_G['uid'])) {
        $openwxlogin = $vars['openwxlogin'];
        $appid = $vars['wxappid'];
        $appsecret = $vars['wxappsecret'];

        $returnurl = $_G['siteurl'] . './plugin.php?id=zpl_car:my&action=mylist';
        if (helper::isweixin() && $openwxlogin == 1) {
            // WX login
            if (!isset($_GET['code'])) {
                $redirecturi = urlencode($returnurl);
                $wxurl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$appid}&redirect_uri={$redirecturi}&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";
                dheader('location: ' . $wxurl);
            } else {
                require_once libfile('function/member');

                $wechat_client = new WeChatClient($appid, $appsecret);

                $code = $_GET['code'];
                $tokeninfo = $wechat_client->getAccessTokenByCode($code);
                if ($tokeninfo['openid']) {
                    $openid = $tokeninfo['openid'];
                    $mp = C::t('#zpl_car#zpl_car_user_wxmp')->fetch_by_openid($openid);
                    if ($mp) {
                        $member = getuserbyuid($mp['uid'], 1);
                        setloginstatus($member, 1296000);
                    } else {
                        $uid = ZplWeChat::register(ZplWeChat::getnewname($openid), 1);
                        if ($uid) {
                            $data = array(
                                'uid' => $uid,
                                'openid' => $openid,
                            );
                            C::t('#zpl_car#zpl_car_user_wxmp')->insert($data);
                        }
                    }
                    dheader('location: ' . $returnurl);
                } else {
                    // common login
                    showmessage('not_loggedin', NULL, array(), array('login' => 1));
                }
            }
        } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX") !== false) {
            // MAGAPP login
            include_once template('zpl_car:mag_login');
            dexit();
        } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "QianFan") !== false) {
            // QFAPP login
            include_once template('zpl_car:qianfan_login');
            dexit();
        } else {
            // common login
            showmessage('not_loggedin', NULL, array(), array('login' => 1));
        }
    }

    if ($vars['opentopcarpay'] == 1 && helper::isweixin()) {
        $tools = new JsApiPay();
        $openid = $tools->GetOpenid();
        if ($openid) {
            $user = C::t('#zpl_car#zpl_car_user')->fetch($_G['uid']);
            if ($user) {
                C::t('#zpl_car#zpl_car_user')->update($_G['uid'], array('openid' => $openid));
            } else {
                C::t('#zpl_car#zpl_car_user')->insert(array('uid' => $_G['uid'], 'openid' => $openid));
            }
        }
    }

    include_once template('zpl_car:my_list');
} elseif ($action == 'inquiryrecords') {
    // login
    if (empty($_G['uid'])) {
        $openwxlogin = $vars['openwxlogin'];
        $appid = $vars['wxappid'];
        $appsecret = $vars['wxappsecret'];

        $returnurl = $_G['siteurl'] . './plugin.php?id=zpl_car:my&action=inquiryrecords';
        if (helper::isweixin() && $openwxlogin == 1) {
            // WX login
            if (!isset($_GET['code'])) {
                $redirecturi = urlencode($returnurl);
                $wxurl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$appid}&redirect_uri={$redirecturi}&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";
                dheader('location: ' . $wxurl);
            } else {
                require_once libfile('function/member');

                $wechat_client = new WeChatClient($appid, $appsecret);

                $code = $_GET['code'];
                $tokeninfo = $wechat_client->getAccessTokenByCode($code);
                if ($tokeninfo['openid']) {
                    $openid = $tokeninfo['openid'];
                    $mp = C::t('#zpl_car#zpl_car_user_wxmp')->fetch_by_openid($openid);
                    if ($mp) {
                        $member = getuserbyuid($mp['uid'], 1);
                        setloginstatus($member, 1296000);
                    } else {
                        $uid = ZplWeChat::register(ZplWeChat::getnewname($openid), 1);
                        if ($uid) {
                            $data = array(
                                'uid' => $uid,
                                'openid' => $openid,
                            );
                            C::t('#zpl_car#zpl_car_user_wxmp')->insert($data);
                        }
                    }
                    dheader('location: ' . $returnurl);
                } else {
                    // common login
                    showmessage('not_loggedin', NULL, array(), array('login' => 1));
                }
            }
        } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX") !== false) {
            // MAGAPP login
            include_once template('zpl_car:mag_login');
            dexit();
        } elseif (strstr($_SERVER['HTTP_USER_AGENT'], "QianFan") !== false) {
            // QFAPP login
            include_once template('zpl_car:qianfan_login');
            dexit();
        } else {
            // common login
            showmessage('not_loggedin', NULL, array(), array('login' => 1));
        }
    }

    include_once template('zpl_car:inquiry_records');
}
//From: Dism_taobao-com
?>