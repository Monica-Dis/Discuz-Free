<?php
/**
 *		[Discuz! X] (C)2001-2099 Comsenz Inc.
 *		This is NOT a freeware, use is subject to license terms
 *
 *		$Id: security.class.php 33945 2013-09-05 01:48:02Z DisM $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class the7_ximalaya_utils{
	public static function replace_callback($matches){
		global $_G;
		$type = $matches[1];
		$id = $matches[2];
		if($type==1){
			return "<iframe height=\"36\" width=\"260\" src=\"//www.ximalaya.com/thirdparty/player/sound/player.html?id=$id&type=red\" frameborder=0 allowfullscreen></iframe>";
		}elseif ($type==2){
            return "<iframe height=\"230\" width=\"260\" src=\"//www.ximalaya.com/thirdparty/player/album/player.html?id=$id&type=red\" frameborder=0 allowfullscreen></iframe>";
        }else{
            return "<iframe height=\"36\" width=\"260\" src=\"//www.ximalaya.com/thirdparty/player/sound/player.html?id=$id&type=red\" frameborder=0 allowfullscreen></iframe>";
        }
	}
}

class plugin_the7_ximalaya {
	function discuzcode($value){
		global $_G;
		if($value['caller']=='discuzcode'){
			$val = $_G['discuzcodemessage'];
			$_G['discuzcodemessage'] = preg_replace_callback('/\[xmly\](\d)_(\d+)_(.*?)\[\/xmly\]/ism',array('the7_ximalaya_utils', 'replace_callback'),$val);
		}
	}
}

class plugin_the7_ximalaya_forum extends plugin_the7_ximalaya{
	function post_editorctrl_left() {
        global $_G;
		$VERSION = '2019.5';
		$API = "//discuz-ximalaya.136cc.com/api/v1/ximalaya/script?v=$VERSION";
        $musicConfig = $_G['cache']['plugin']['the7_ximalaya'];
		if(intVal($musicConfig['enable'])==1 && in_array($_G['groupid'], unserialize($musicConfig['allowedgroups'])) && in_array($_G['fid'], unserialize($musicConfig['allowedforums']))){

		    $html  = '<script>';
			$html .= 'window.the7_xmly_config_themeColor   = "'.$musicConfig['themecolor'].'";';
			$html .= 'window.the7_xmly_lang_sound          = "'.lang('plugin/the7_ximalaya', 'sound').'";';
            $html .= 'window.the7_xmly_lang_album          = "'.lang('plugin/the7_ximalaya', 'album').'";';
			$html .= 'window.the7_lang_xmly_urlResolve     = "'.lang('plugin/the7_ximalaya', 'url_resolve').'";';
			$html .= 'window.the7_lang_xmly_placeholder    = "'.lang('plugin/the7_ximalaya', 'placeholder').'";';
			$html .= 'window.the7_lang_xmly_addToEditor    = "'.lang('plugin/the7_ximalaya', 'add_to_editor').'";';

			$html .= '(function() { var s = document.createElement("script");s.type="text/javascript";s.async=true;s.src="'.$API.'";var x = document.getElementsByTagName("script")[0];x.parentNode.insertBefore(s, x);})();';
			$html .= '</script>';
			$html .= '<link rel="stylesheet" href="source/plugin/the7_ximalaya/template/style.css?v='.$VERSION.'" type="text/css" />';
			$html .= '<style>#e_the7_ximalaya_search_pager li a:hover{background:'.$musicConfig['themecolor'].';color:#fff;} #e_the7_ximalaya_search_pager li a.cur{background:'.$musicConfig['themecolor'].';color:#fff;}#e_the7_ximalaya_add_to_editor a{ background:'.$musicConfig['themecolor'].'; color:#fff;}#e_the7_ximalaya_add_to_editor a:hover{opacity:.9;}</style>';
			return '<span id="e_the7_ximalaya" title="'.$musicConfig['btnmusictxt'].'">'.$musicConfig['btnmusictxt'].'</span>'.$html;
		}

	}
}
?>