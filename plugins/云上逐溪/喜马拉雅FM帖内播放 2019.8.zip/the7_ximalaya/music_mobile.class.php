<?php
/**
 *		[Discuz! X] (C)2001-2099 Comsenz Inc.
 *		This is NOT a freeware, use is subject to license terms
 *
 *		$Id: security.class.php 33945 2013-09-05 01:48:02Z DisM $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class the7_ximalaya_mobile_utils{
    public static function replace_callback($matches){
        global $_G;
        $type = $matches[1];
        $id = $matches[2];
        if($type==1){
            return "<iframe height=\"36\" width=\"260\" src=\"//www.ximalaya.com/thirdparty/player/sound/player.html?id=$id&type=red\" frameborder=0 allowfullscreen></iframe>";
        }elseif ($type==2){
            return "<iframe height=\"230\" width=\"260\" src=\"//www.ximalaya.com/thirdparty/player/album/player.html?id=$id&type=red\" frameborder=0 allowfullscreen></iframe>";
        }else{
            return "<iframe height=\"36\" width=\"260\" src=\"//www.ximalaya.com/thirdparty/player/sound/player.html?id=$id&type=red\" frameborder=0 allowfullscreen></iframe>";
        }
    }
}

class mobileplugin_the7_ximalaya {
	function discuzcode($value){
		global $_G;
        if($value['caller']=='discuzcode'){
            $val = $_G['discuzcodemessage'];
            $_G['discuzcodemessage'] = preg_replace_callback('/\[xmly\](\d)_(\d+)_(.*?)\[\/xmly\]/ism',array('the7_ximalaya_mobile_utils', 'replace_callback'),$val);
        }
	}
}
?>