<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_hux_zhidao {

	function hux_zhidao() {
		global $_G;
		$zdsetting = $_G['cache']['plugin']['hux_zhidao'];
		$zdmoneytype = 'extcredits'.$zdsetting['moneytype'];
		$zdmoneynum = $zdsetting['moneynum'];
		$zdverify = 'verify'.$zdsetting['verify'];
		$zdjifen = 'extcredits'.$zdsetting['jifen'];
		$gpbestanswersubmit = addslashes($_GET['bestanswersubmit']);
		$gppid = addslashes($_GET['pid']);
		if ($gpbestanswersubmit == 'yes') {
			$zdpid = $gppid;
			$zduid = DB::result_first("SELECT authorid FROM ".DB::table('forum_post')." WHERE pid = '$zdpid'");
			$zdrz = DB::result_first("SELECT count(*) FROM ".DB::table('common_member_verify')." WHERE $zdverify = '1' AND uid='$zduid'");
			if ($zdrz > 0) {
				if ($zdsetting['moneytype'] != '' && $zdsetting['moneytype'] != '0') {
					updatemembercount($zduid , array($zdmoneytype => $zdmoneynum));
				}
			}
			if ($zdsetting['jifen'] != '' && $zdsetting['jifen'] != '0') {
					updatemembercount($zduid , array($zdjifen => 1));
			}
		}
		return '';
	}

	function global_header() {
		global $_G;
		return $this->hux_zhidao();
	}
}
//From: Dism_taobao_com
?>