<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$_GET = daddslashes($_GET);
$_POST = daddslashes($_POST);
foreach(array_merge($_POST, $_GET) as $k => $v) {
	$_G['gp_'.$k] = $v;
	$_GET[$k] = $v;
}
require_once DISCUZ_ROOT.'./source/discuz_version.php';
require_once(DISCUZ_ROOT.'./source/function/function_cache.php');
$cacheFile = DB::result_first("select dateline from ".DB::table('common_syscache')." WHERE cname='hux_zhidao'");
$zd_root = "source/plugin/hux_zhidao";
$action = empty($_GET['action']) ? '' : dhtmlspecialchars(addslashes($_GET['action']));
$zdfid = empty($_GET['fid']) ? '' : dhtmlspecialchars(addslashes($_GET['fid']));
$zdtype = empty($_GET['type']) ? '' : dhtmlspecialchars(addslashes($_GET['type']));
$gppage = addslashes($_GET['page']);
$gpformhash = addslashes($_GET['formhash']);
$gpsort = addslashes($_GET['sort']);
$zdsetting = $_G['cache']['plugin']['hux_zhidao'];
$navtitle = ($zdsetting['seotitle'] == '') ? $zdsetting['pluginname'] : $zdsetting['seotitle'];
if ($zdsetting['seokeywords'] != '') {
	$metakeywords = $zdsetting['seokeywords'];
}
if ($zdsetting['seodescription'] != '') {
	$metadescription = $zdsetting['seodescription'];
}
$zdjifen = 'extcredits'.$zdsetting['jifen'];
$zdjifenname = $_G['setting']['extcredits'][$zdsetting['jifen']]['title'];
$zdverify = 'verify'.$zdsetting['verify'];
$zdmoneynum = $zdsetting['moneynum'];
$zdmoneyname = $_G['setting']['extcredits'][$zdsetting['moneytype']]['title'];
$atclass[$zdtype] = "class='a'";
$uid = $_G['uid'];
$username = $_G['username'];
$adminid = $_G['adminid'];
$closemsg = $zdsetting['closemsg'];
$upcachetime = intval($zdsetting['upcachetime'] * 60);
$loadfid = unserialize($zdsetting['fid']);
$loadfid = array_unique($loadfid);
$loadfid = array_filter($loadfid);
$loadfid = dimplode($loadfid);
$zdlang = lang('plugin/hux_zhidao');
$getmid_err_msg = str_replace('{renum}',$zdsetting['mnum'],$zdlang['getmid_err']);
$tjtid = explode(',',$zdsetting['tjtid']);

if (!$cacheFile || (TIMESTAMP-$cacheFile) > $upcachetime || $action == 'updatecache') {
	$sortupsql = DB::query("SELECT fid FROM ".DB::table('forum_forum')." WHERE fup='0'");
	$sortuplist = '';
	while($sortupids = DB::fetch($sortupsql)) {
		$sortuplist .= $sortupids['fid'].',';
	}
	$loadupfid = explode(',',$sortuplist);
	$loadupfid = array_unique($loadupfid);
	$loadupfid = array_filter($loadupfid);
	$loadupfid = dimplode($loadupfid);

	if ($zdsetting['sorttype'] == '1') {
		$sortorder = '<br>';
	} else {
		$sortorder = '&nbsp;&nbsp;';
	}	
	
	$donum = DB::result_first("select count(tid) from ".DB::table('forum_thread')." WHERE displayorder<>'-1' AND displayorder<>'-2' AND displayorder<>'-3' AND displayorder<>'-4' AND authorid>'0' AND special='3' AND price<'0' AND fid IN(".$loadfid.")");
	$undonum = DB::result_first("select count(tid) from ".DB::table('forum_thread')." WHERE displayorder<>'-1' AND displayorder<>'-2' AND displayorder<>'-3' AND displayorder<>'-4' AND authorid>'0' AND special='3' AND price>'0' AND fid IN(".$loadfid.")");
	$sortsql = DB::query("SELECT fid,name,simple FROM ".DB::table('forum_forum')." WHERE fid IN({$loadfid}) AND fup IN({$loadupfid}) ORDER BY displayorder ASC");
	while($sortids = DB::fetch($sortsql)) {
		$sortsqlb = DB::query("SELECT fid,name FROM ".DB::table('forum_forum')." WHERE fid IN({$loadfid}) AND fup='{$sortids['fid']}' ORDER BY displayorder ASC");
		if ($sortids['simple'] & 1) {
			$sorturl = "<strong>".cutstr($sortids['name'],$zdsetting['sortnum'])."</strong>";
		} else {
			$sorturl = "<a href=plugin.php?id=hux_zhidao:hux_zhidao$exc&fid=$sortids[fid] title=".$sortids['name']."><strong>".cutstr($sortids['name'],$zdsetting['sortnum'])."</strong></a>";
		}
		$sortlist .= "<li class=sortlist><img src=".$zd_root."/images/dot.gif align=absmiddle /> ".$sorturl."<div style=padding-left:8px;>";
		while($sortidsb = DB::fetch($sortsqlb)) {
			$sortlist .= "<a href=plugin.php?id=hux_zhidao:hux_zhidao$exc&fid=$sortidsb[fid] title=".$sortidsb['name'].">".cutstr($sortidsb['name'],$zdsetting['sortnumb'])."</a>".$sortorder;
		}
		$sortlist .= "</div></li>";
	}
	
	$cacheArray = array();
	$cacheArray['sortuplist'] = $sortuplist;
	$cacheArray['donum'] = $donum;
	$cacheArray['undonum'] = $undonum;
	$cacheArray['sortlist'] = $sortlist;
	$cacheArray['version'] = DB::result_first("select version from ".DB::table('common_plugin')." WHERE identifier='hux_zhidao'");
	save_syscache('hux_zhidao', $cacheArray);
} else {
	loadcache('hux_zhidao');
	$sortuplist = $_G['cache']['hux_zhidao']['sortuplist'];
	$donum = $_G['cache']['hux_zhidao']['donum'];
	$undonum = $_G['cache']['hux_zhidao']['undonum'];
	$sortlist = $_G['cache']['hux_zhidao']['sortlist'];
	$VeRsIoN = $_G['cache']['hux_zhidao']['version'];
}

require_once DISCUZ_ROOT.'./source/plugin/hux_zhidao/hux_zhidao.func.php';
if ($zdsetting['open'] == '0') {
	showmessage("$closemsg","index.php");
}

$where = '';
$exc = '';
if ($zdtype == 'do') {
	$where = " AND price<'0'";
	$exc = "&type=do";
} elseif ($zdtype == 'undo') {
	$where = " AND price>'0'";
	$exc = "&type=undo";
} elseif ($zdtype == 'my') {
	$where = " AND authorid='".$uid."'";
	$exc = "&type=my";
} else {
	$where = " AND price<>'0'";
	$exc = "";
}
if ($zdfid == '') {
	$whereb = " AND fid IN(".$loadfid.")";
	$excb = "";
} else {
	$whereb = " AND fid='$zdfid'";
	$excb = "&fid=$zdfid";
}

if ($zdtype != '' || $zdfid != '') {
$perpage = $zdsetting['shownum'];
$n = DB::query("select * from ".DB::table('forum_thread')." WHERE displayorder<>'-1' AND displayorder<>'-2' AND displayorder<>'-3' AND displayorder<>'-4' AND authorid>'0' AND special='3'$where$whereb");
$fnum = DB::num_rows($n);
$page = max(1, $gppage);
$showfnum = str_replace('{fnum}',$fnum,$zdlang['fnum']);
$start = ($page-1)*$perpage;
	
$fquery = DB::query("select * from ".DB::table('forum_thread')." WHERE displayorder<>'-1' AND displayorder<>'-2' AND displayorder<>'-3' AND displayorder<>'-4' AND authorid>'0' AND special='3'$where$whereb ORDER BY dateline DESC limit $start,$perpage");
while($fresult = DB::fetch($fquery)){
	$fresult['fname'] = DB::result_first("SELECT name FROM ".DB::table('forum_forum')." WHERE fid='".$fresult['fid']."'");
	if (checkmobile()) {
		$fresult['subjectb'] = cutstr($fresult['subject'],22);
		$fresult['dateline'] = date('Y-m-d',$fresult['dateline']);
	} else {
		$fresult['subjectb'] = cutstr($fresult['subject'],70);
		$fresult['dateline'] = date('Y-m-d H:i',$fresult['dateline']);
	}
	$fresult['money'] = abs($fresult['price']);
	$flist[] = $fresult;
}
$multi = multi($fnum, $perpage, $page, "plugin.php?id=hux_zhidao:hux_zhidao$exc$excb");
}

if ($zdsetting['jifen'] != '') {
	if ($uid) {
		$mycash = HUX_ZD_UserInfo('mycash');
	}
}

if ($uid) {
	$myasknum = HUX_ZD_UserInfo('asknum');
	$myrenum = HUX_ZD_UserInfo('renum');
	$mymid = HUX_ZD_UserInfo('medal');
	$mybest = intval(HUX_ZD_UserInfo('bestreply')/$myrenum*100);
}

if ($action == 'ask') {
	$sortsqlask = DB::query("SELECT fid,name,simple FROM ".DB::table('forum_forum')." WHERE fid IN(".$loadfid.") ORDER BY displayorder ASC");
	while($sortidsask = DB::fetch($sortsqlask)) {
		$sortlistask[] = $sortidsask;
	}
	if(submitcheck('addsubmit')){
		$askfid = dhtmlspecialchars($gpsort);
		dheader("location:forum.php?mod=post&action=newthread&fid=$askfid&special=3");
	}
} elseif ($action == 'team') {
	$zdteamsql = DB::query("SELECT m.username,m.uid FROM ".DB::table('common_member_verify')." rs LEFT JOIN ".DB::table('common_member')." m ON rs.uid = m.uid WHERE $zdverify = '1' GROUP BY rs.uid ORDER BY m.uid ASC");
	while($zdteamresult = DB::fetch($zdteamsql)){
		if ($zdsetting['jifen'] != '') {	
			$zdteamresult['jifen'] = DB::result_first("SELECT ".$zdjifen." FROM ".DB::table('common_member_count')." WHERE uid = '{$zdteamresult['uid']}'");
		}
		$zdteamlist[] = $zdteamresult;
	}
} elseif ($action == 'getmid') {
	if ($gpformhash == formhash() && $uid && $zdsetting['mid'] != '0') {
		if ($myrenum < $zdsetting['mnum']) {
			showmessage($getmid_err_msg,'plugin.php?id=hux_zhidao:hux_zhidao');
		} else {
			$medalday = DB::result_first("SELECT expiration FROM ".DB::table('forum_medal')." WHERE medalid='".$zdsetting['mid']."'");
			if ($medalday == '0') {
				$medalend = 0;
			} else {
				$medalend = TIMESTAMP + 86400 * $medalday;
			}
			$medaldata = array(
				'uid' => $uid,
				'medalid' => $zdsetting['mid'],
				'type' => 0,
				'dateline' => TIMESTAMP,
				'expiration' => $medalend,
				'status' => 1,
			);
			DB::insert('forum_medallog', $medaldata);
			$medalsql = DB::fetch_first("SELECT medals FROM ".DB::table('common_member_field_forum')." WHERE uid='$uid'");
			$oldmedals = explode('\t',$medalsql['medals']);
			$oldmedals = array_unique($oldmedals);
			$oldmedals = array_filter($oldmedals);
			if (!in_array(intval($zdsetting['mid']),$oldmedals)) {
				$medalsnew = $zdsetting['mid'].'\t'.$medalsql['medals'];
				DB::query("UPDATE ".DB::table('common_member_field_forum')." SET medals='$medalsnew' WHERE uid='$uid'");
			}
			showmessage($zdlang['getmid_sus'],'plugin.php?id=hux_zhidao:hux_zhidao');
		}
	}
} elseif ($action == 'updatecache') {
	if ($gpformhash == formhash() && $adminid == '1') {
		$tpl = dir(DISCUZ_ROOT.'./data/cache/hux_zhidao');
		while($entry = $tpl->read()) {
			if(preg_match("/\.php$/", $entry)) {
				@unlink(DISCUZ_ROOT.'./data/cache/hux_zhidao/'.$entry);
			}
		}
		$tpl->close();
		showmessage($zdlang['updatecache_sus'],'plugin.php?id=hux_zhidao:hux_zhidao');
	}
} else {
	if ($zdsetting['jifen'] != '' && $zdsetting['jifen'] != '0') {
		$rztopsql = DB::query("SELECT m.".$zdjifen." as rzjifen,rs.username,rs.uid FROM ".DB::table('common_member')." rs LEFT JOIN ".DB::table('common_member_count')." m ON rs.uid = m.uid GROUP BY rs.uid ORDER BY $zdjifen DESC LIMIT 10");
		while($rztop = DB::fetch($rztopsql)) {
			$rztopdata[] = $rztop;
		}
	}
	$doquery = DB::query("select * from ".DB::table('forum_thread')." WHERE displayorder<>'-1' AND displayorder<>'-2' AND displayorder<>'-3' AND displayorder<>'-4' AND authorid>'0' AND special='3' AND price<'0' AND fid IN(".$loadfid.") ORDER BY dateline DESC limit ".$zdsetting['indexshownum']);
	while($dolists = DB::fetch($doquery)) {
		$dolists['fname'] = DB::result_first("SELECT name FROM ".DB::table('forum_forum')." WHERE fid='".$dolists['fid']."'");
		if (checkmobile()) {
			$dolists['subject'] = cutstr($dolists['subject'],32);
		} else{
			$dolists['subject'] = cutstr($dolists['subject'],70);
		}
		$dolists['money'] = abs($dolists['price']);
		$dolist[] = $dolists;
	}
	$undoquery = DB::query("select * from ".DB::table('forum_thread')." WHERE displayorder<>'-1' AND displayorder<>'-2' AND displayorder<>'-3' AND displayorder<>'-4' AND authorid>'0' AND special='3' AND price>'0' AND fid IN(".$loadfid.") ORDER BY dateline DESC limit ".$zdsetting['indexshownum']);
	while($undolists = DB::fetch($undoquery)) {
		$undolists['fname'] = DB::result_first("SELECT name FROM ".DB::table('forum_forum')." WHERE fid='".$undolists['fid']."'");
		if (checkmobile()) {
			$undolists['subject'] = cutstr($undolists['subject'],32);
		} else {
			$undolists['subject'] = cutstr($undolists['subject'],80);
		}
		$undolists['money'] = abs($undolists['price']);
		$undolist[] = $undolists;
	}
	$tjtids = $tjtid[1].','.$tjtid[2].','.$tjtid[3].','.$tjtid[4].','.$tjtid[5];
	$tjtids = explode(',',$tjtids);
	$tjtids = array_unique($tjtids);
	$tjtids = array_filter($tjtids);
	$tjtids = dimplode($tjtids);
	if ($zdsetting['tjpic'] != '') {
		$tjquery = DB::query("select * from ".DB::table('forum_thread')." WHERE displayorder<>'-1' AND displayorder<>'-2' AND displayorder<>'-3' AND displayorder<>'-4' AND authorid>'0' AND tid IN(".$tjtids.") ORDER BY dateline DESC limit 5");
		while($tjlists = DB::fetch($tjquery)) {
			if (checkmobile()) {
				$tjlists['subject'] = cutstr($tjlists['subject'],30);
			} else {
				$tjlists['subject'] = cutstr($tjlists['subject'],90);
			}
			$tjlist[] = $tjlists;
		}
	}
}
if (checkmobile()) {
	include template('hux_zhidao:index');
} else {
	include template('diy:hux_zhidao', null, 'source/plugin/hux_zhidao/template');
}
//From: Dism_taobao_com
?>