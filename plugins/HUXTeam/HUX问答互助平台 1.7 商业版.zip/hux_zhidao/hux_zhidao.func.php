<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function hux_zhidao_writetocache($uid, $cachedata) {
	global $_G;

	$dir = DISCUZ_ROOT.'./data/cache/hux_zhidao/';
	if(!is_dir($dir)) {
		@mkdir($dir, 0777);
	}
	if($fp = @fopen("$dir$uid.php", 'wb')) {
		fwrite($fp, "<?php\n//Discuz! cache file, DO NOT modify me!\n//Identify: ".md5($uid.'.php'.$cachedata.$_G['config']['security']['authkey'])."\n\n$cachedata?>");
		fclose($fp);
	} else {
		exit('Can not write to cache files, please check directory ./data/ and ./data/cache/ and ./data/cache/hux_zhidao/ .');
	}
}

function HUX_ZD_UserInfo($field) {
	global $_G,$uid,$loadfid,$zdsetting,$zdjifen,$zdlang,$getmid_err_msg,$showmid,$asknum,$renum,$bestreply,$action,$upcachetime;
	$huxcacheFile = DISCUZ_ROOT.'./data/cache/hux_zhidao/'.$uid.'.php';
	if (!file_exists($huxcacheFile) || (TIMESTAMP-@filemtime($huxcacheFile)) > $upcachetime || $action == 'getmid') {
	$loadtidquery = DB::query("select tid,dateline from ".DB::table('forum_thread')." WHERE displayorder<>'-1' AND displayorder<>'-2' AND displayorder<>'-3' AND displayorder<>'-4' AND special='3' AND fid IN(".$loadfid.")");
	$loadtid = '';
	while ($loadtidss = DB::fetch($loadtidquery)) {
		$allmyquery = DB::query("select pid from ".DB::table('forum_post')." WHERE invisible='0' AND authorid='".$uid."' AND tid='".$loadtidss['tid']."' AND first='0' AND dateline=".$loadtidss['dateline']."+1");
		while ($loadpidss = DB::fetch($allmyquery)) {
			$loadpids .= $loadpidss['pid'].',';
		}
		$loadtids .= $loadtidss['tid'].',';
	}
	$loadtid = explode(',',$loadtids);
	$loadtid = array_unique($loadtid);
	$loadtid = array_filter($loadtid);
	$loadtid = dimplode($loadtid);
	$loadpid = explode(',',$loadpids);
	$loadpid = array_unique($loadpid);
	$loadpid = array_filter($loadpid);
	$loadpid = dimplode($loadpid);
	$renum = DB::result_first("select count(pid) from ".DB::table('forum_post')." WHERE invisible='0' AND authorid='".$uid."' AND tid IN(".$loadtid.") AND first='0'");
	$medalsql = DB::fetch_first("SELECT medals FROM ".DB::table('common_member_field_forum')." WHERE uid='".$uid."'");
	$oldmedals = explode('\t',$medalsql['medals']);
	$oldmedals = array_unique($oldmedals);
	$oldmedals = array_filter($oldmedals);
	$showmid = '';
	$medelpic = DB::fetch_first("SELECT name,image FROM ".DB::table('forum_medal')." WHERE medalid='".$zdsetting['mid']."'");
	$medelpicb = DB::result_first("SELECT image FROM ".DB::table('forum_medal')." WHERE medalid='".$zdsetting['midb']."'");
	if (in_array(intval($zdsetting['mid']),$oldmedals)) {
		$showmid = "<a href=home.php?mod=medal&action=log title=".$medelpic['name']." target=_blank><img src=static/image/common/".$medelpic['image']." /></a>";
	} else {
		if ($medelpicb == '0') {
			if ($renum >= $zdsetting['mnum']) {
				$showmid = "<a href=plugin.php?id=hux_zhidao:hux_zhidao&action=getmid&formhash=".$_G['formhash'].">".$zdlang['getmid']."</a>";
			}
		} else {
			if ($renum >= $zdsetting['mnum']) {
				$showmid = "<a href=plugin.php?id=hux_zhidao:hux_zhidao&action=getmid&formhash=".$_G['formhash']." title=".$zdlang['getmid']."><img src=static/image/common/".$medelpicb." /></a>";
			} else {
				$showmid = "<a href=home.php?mod=medal&action=log title=".$getmid_err_msg." target=_blank><img src=static/image/common/".$medelpicb." /></a>";
			}
		}
	}
	$asknum = DB::result_first("select count(tid) from ".DB::table('forum_thread')." WHERE displayorder<>'-1' AND displayorder<>'-2' AND displayorder<>'-3' AND displayorder<>'-4' AND authorid='".$uid."' AND special='3' AND fid IN(".$loadfid.")");
	$bestreply = DB::result_first("select count(pid) from ".DB::table('forum_post')." WHERE invisible='0' AND authorid='".$uid."' AND tid IN(".$loadtid.") AND pid IN(".$loadpid.") AND first='0'");
	$huxcacheArray = "\$showmid=".arrayeval($showmid).";\n\$asknum=".arrayeval($asknum).";\n\$renum=".arrayeval($renum).";\n\$bestreply=".arrayeval($bestreply).";\n\n";
	hux_zhidao_writetocache($uid, $huxcacheArray);
	
	} else {
		include($huxcacheFile);
	}
	$infofields = array(
		'asknum'	=>	$asknum,
		'renum'	=>	$renum,
		'mycash'	=>	getuserprofile($zdjifen),
		'medal'	=>	$showmid,
		'bestreply'	=>	$bestreply,
	);
	return $infofields[$field];
}
//From: Dism��taobao��com
?>