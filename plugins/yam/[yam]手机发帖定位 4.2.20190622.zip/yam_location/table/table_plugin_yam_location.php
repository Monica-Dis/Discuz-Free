<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/9/23
 * Time: 16:29
 */

if (!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}
class table_plugin_yam_location extends discuz_table
{
    function __construct(){
        $this->_table = 'plugin_yam_location';
        $this->_pk ='geoid';

        parent::__construct();
    }

    function save($data){
        DB::query('INSERT INTO %t SET `uid` = %d, `tid` = %d,`fid` = %d, `pid` = %d, `address` = %s,`lng` = %f, `lat` = %f, `province` = %s, `city` = %s, `district` = %s, `poiname` = %s',
                array(
                $this->_table,
                $data['uid'],
                $data['tid'],
                $data['fid'],
                $data['pid'],
                $data['address'],
                $data['lng'],
                $data['lat'],
                $data['province'],
                $data['city'],
                $data['district'],
                $data['poiname'],
            )
        );
    }

    function edit($data){
        DB::query('UPDATE %t SET `uid` = %d, `tid` = %d,`fid` = %d, `pid` = %d, `address` = %s,`lng` = %f, `lat` = %f, `province` = %s, `city` = %s, `district` = %s, `poiname` = %s WHERE pid = %d',
            array(
                $this->_table,
                $data['uid'],
                $data['tid'],
                $data['fid'],
                $data['pid'],
                $data['address'],
                $data['lng'],
                $data['lat'],
                $data['province'],
                $data['city'],
                $data['district'],
                $data['poiname'],
                $data['pid'],
            )
        );
    }

    function findadr($id)
    {
        if(empty($id)){
            return FALSE;
        }
        return  DB::fetch_all("SELECT pid, address,province,city,district,lng,lat,poiname FROM ".DB::table($this->_table)." WHERE pid IN (" . dimplode($id) . ')');
    }

    function fetchbypid($pid)
    {
        $where = " WHERE pid= $pid ";
        return  DB::fetch_all("SELECT * FROM ".DB::table($this->_table)." $where");
    }


    function findadrbytids($tids)
    {
        if(empty($tids)){
            return FALSE;
        }
        return  DB::fetch_all("SELECT s.pid, s.address,s.province,s.city,s.district,s.lng,s.lat,s.poiname FROM (SELECT min(tid) as tid FROM %t WHERE tid IN ( %n ) GROUP BY tid) as t LEFT JOIN  %t AS s ON s.tid = t.tid",
            array(
                $this->_table,
                $tids,
                $this->_table
            ));
    }
}
