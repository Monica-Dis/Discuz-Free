
<!--{block return}-->


<a name="location" id="location" style="height:30px;line-height: 30px;width: 100%;display: block;">
    <div style="float: right;padding-right: 5%">
        <input type="hidden" name="pluginid" value="yam_location">
        <img class="locationimg" src="{$this->img}" style="width: 12px;margin-top: 5px;margin-right: 2px"><span id="locationadr" >{lang yam_location:dizhi}</span>
    </div>
</a>

<style>
    .tipmap{position:fixed;top:0;left:0;height:100%;width:100%;z-index:9999999;display:none}
</style>

<div class="tipmap">
    <script charset="utf-8" src="https://map.qq.com/api/js?v=2.exp&key={$this->config['mapKey']}"></script>
    <iframe id="mapPage" width="100%" height="100%" frameborder=0 src=""></iframe>
    <script>
        window.addEventListener('message', function(event) {
            var loc = event.data;
            if (loc && loc.module == 'locationPicker') {
                var geocoder;
                geocoder = new qq.maps.Geocoder();
                var latLng = new qq.maps.LatLng(loc.latlng.lat, loc.latlng.lng);
                geocoder.getAddress(latLng);
                geocoder.setComplete(function(result) {
                    var cityhtml = '';
                    cityhtml += '<input type="hidden" name="resideprovince" value="'+ result.detail.addressComponents.province +'" />';
                    cityhtml += '<input type="hidden" name="residecity" value="'+ result.detail.addressComponents.city +'" />';
                    cityhtml += '<input type="hidden" name="residedist" value="'+ result.detail.addressComponents.district +'" />';

                    var address=loc.poiaddress;
                    var poiname=loc.poiname;
//                    $('.locationimg').hide();
                    $('#locationadr').html(loc.poiname+ cityhtml +
                            '<input type="hidden" name="address" value="'+address+'" />'+
                            '<input type="hidden" name="poiname" value="'+poiname+'" />'+
                            '<input type="hidden" name="lat" value="'+loc.latlng.lat+'" />'+
                            '<input type="hidden" name="lng" value="'+loc.latlng.lng+'" />');
                    $('.tipmap').fadeOut();
                });
            }
        }, false);
        $('#location').on('click', function(){
            if(!$('#mapPage').attr('src')){
                $('#mapPage').attr('src', 'https://apis.map.qq.com/tools/locpicker?search=1&type=1&key={$this->config[mapKey]}&referer=myapp');
            }
            $('.tipmap').fadeIn();
        });
    </script>
</div>
<!--{/block}-->