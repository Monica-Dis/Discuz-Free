
<!--{block return}-->
    <!--{if $_G['cache']['plugin']['yam_location']['openGps']}-->

        <script>
            var html =
                "<a name=\"location{$pid}\" id=\"location{$pid}\" style=\"height:30px;line-height: 30px;width: 100%;display: block; color:{$color}\">"+
                "<div style=\"text-align: right;padding-right: 5%\">"+
                "<img src=\"{$this->img}\" style=\"width: 12px;margin-top: 5px;margin-right: 2px\"><span  >{$adr}</span>"+
                "</div>"+
                "</a>"
            $('#pid{$pid}').append(html);
        </script>

        <style>
            .tipmap{position:fixed;top:0;left:0;height:100%;width:100%;z-index:9999999;display:none}
        </style>

        <div class="tipmap" id="tipmap{$pid}">
            <script charset="utf-8" src="https://map.qq.com/api/js?v=2.exp&key={$this->config['mapKey']}"></script>
            <iframe id="mapPage{$pid}" width="100%" height="100%" frameborder=0 src=""></iframe>
            <script>
                $('#location{$pid}').on('click', function(){
                    if(!$('#mapPage{$pid}').attr('src')){
                        $('#mapPage{$pid}').attr('src', 'https://apis.map.qq.com/tools/routeplan/eword={$poiname}&epointx={$lng}&epointy={$lat}?referer=myapp&key={$this->config[mapKey]}');
                    }
                    $('#tipmap{$pid}').fadeIn();
                });
            </script>
        </div>

    <!--{else}-->

        <script>
            var html = "<div style=\"text-align: right;padding-right: 5%;color:{$color}\"><img src=\"{$this->img}\" style=\"width: 12px;margin-top: 5px;margin-right: 2px\">{$adr}</div>";
            $('#pid{$pid}').append(html);
        </script>

    <!--{/if}-->

<!--{/block}-->