<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
if(!$_G['cache']['plugin']){
	loadcache('plugin');
}
if(!$_G['uid']){
	exit;
}
$config = $_G['cache']['plugin']['yam_location'];
$userinfo = C::t('#yam_location#plugin_yam_location_common')->fetch($_G['uid']);

if(submitcheck('clsubmit')){
		$data = array(
			'uid' => $_G['uid'],
			'is_visible'=>$_POST['is_visible'],
		);
	if(isset($_POST['lat'])){
		$data += array(
			'address'=>$_POST['address'],
			'lat'=>$_POST['lat'],
			'lng'=>$_POST['lng'],
			'province'=>$_POST['resideprovince'],
			'city'=>$_POST['residecity'],
			'district'=>$_POST['residedist'],
			'poiname'=>$_POST['poiname'],
		);
	}
	$return = C::t("#yam_location#plugin_yam_location_common")->save($data);
	showmessage(lang('plugin/yam_location','success'), "home.php?mod=spacecp&ac=plugin&id=yam_location:common_location");
}
if(checkmobile()){
	include_once template('yam_location:common_location');
	exit;
}
//From: Dism_taobao-com
?>