<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/9/21
 * Time: 9:36
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


class plugin_yam_location
{
    public function post_message($value){
        global $_G;
        $param = $value['param'];
        $tid = $param[2]['tid'];
        $pid = $param[2]['pid'];
        $fid = $param[2]['fid'];

        if ( strtolower($_SERVER['REQUEST_METHOD']) == 'post' && $_GET['pluginid'] == "yam_location" ) {
            $data = array(
                'uid' => $_G['uid'],
                'tid' => $tid,
                'pid' => $pid,
                'fid' => $fid,
                'address'=>$_GET['address'],
                'lat'=>$_GET['lat'],
                'lng'=>$_GET['lng'],
                'province'=>$_GET['resideprovince'],
                'city'=>$_GET['residecity'],
                'district'=>$_GET['residedist'],
                'poiname'=>$_GET['poiname'],
            );


            switch ($param[0]) {
                case 'post_newthread_succeed':
                case 'post_newthread_mod_succeed':
                case 'post_reply_succeed':
                case 'post_reply_mod_succeed':
                    C::t('#yam_location#plugin_yam_location')->save($data);
                    break;
                case 'post_edit_succeed':
                case 'edit_reply_mod_succeed':
                case 'edit_newthread_mod_succeed':
                    if(C::t('#yam_location#plugin_yam_location')->fetchbypid($pid)){
                        C::t('#yam_location#plugin_yam_location')->edit($data);
                    }else{
                        C::t('#yam_location#plugin_yam_location')->save($data);
                    }
                    break;
                default:break;
            }
        }
    }
}

class mobileplugin_yam_location_forum extends plugin_yam_location
{
    private $groupon =false;
    private $groupviewon =false;
    private $config;
    public $img;
    public function __construct()
    {
        global $_G;
        if (!$_G['cache']['plugin']) {
            loadcache('plugin');
        }
        $this->config = $_G['cache']['plugin']['yam_location'];
        //�û�����Ȩ��
        $groups = unserialize($this->config['groupOn']);
        $this->groupon = in_array('', $groups) ? TRUE : (in_array($_G['groupid'], $groups) ? TRUE : FALSE);
        if(!$groups[0]&&count($groups)<=1){
            $this->groupon = TRUE;
        }
        //�û����Ȩ��
        $viewgroups = unserialize($this->config['groupViewOn']);
        $this->groupviewon = in_array('', $viewgroups) ? TRUE : (in_array($_G['groupid'], $viewgroups) ? TRUE : FALSE);
        if(!$viewgroups[0]&&count($viewgroups)<=1){
            $this->groupviewon = TRUE;
        }
        //�û�Ĭ��ͼ������
        if($this->config['phone_img']){
            $this->img=$this->config['img'];
        }else{
            $this->img=$_G['siteurl'].'source/plugin/yam_location/template/common/location.png';
        }
    }
    public function post_bottom_mobile()
    {
        if(!$this->groupon){
            return '';
        }
        if(getgpc('action') == 'reply' && !$this->config['repliesOn']){
            return '';
        }
        include template('yam_location:post_bottom_mobile');
        return $return;
    }

    public function viewthread_fastpost_button_mobile()
    {
        if(!$this->groupon){
            return '';
        }
        if(!$this->groupon || !$this->config['repliesOn']){
            return '';
        }
        include template('yam_location:post_bottom_mobile');
        return $return;
    }

    public function viewthread_postbottom_mobile_output()
    {
        if(!$this->groupviewon){
            return '';
        }
        global $_G,$postlist;

        $data = array();
        foreach(array_values($postlist) as $index => $item){
            $pids[]=$item['pid'];
            $uids[$item['uid']]=$item['uid'];
        };
        $userinfos = C::t('#yam_location#plugin_yam_location_common')->fetchall($uids);
        $addrs= C::t('#yam_location#plugin_yam_location')->findadr($pids);

        foreach($addrs as $addr){
            $address[$addr['pid']]=$addr;
        }
        foreach($userinfos as $userinfo){
            $useraddress[$userinfo['uid']]=$userinfo;
        }
        foreach (array_values($postlist) as $index => $item) {

            $pid= $item['pid'];
            if(empty($address[$pid])){
                $address[$pid] = $useraddress[$item['uid']]['is_visible']==1?$useraddress[$item['uid']]:'';
            }

            switch($this->config['addressType']){
                case '1':
                    $adr =  $address[$pid]['province'];
                    break;
                case '2':
                    $adr =  $address[$pid]['province'].$address[$pid]['city'];
                    break;
                case '3':
                    $adr =  $address[$pid]['province'].$address[$pid]['city'].$address[$pid]['district'];
                    break;
                case '4':
                    $adr =  $address[$pid]['city'];
                    break;
                case '5':
                    $adr =  $address[$pid]['city'].$address[$pid]['district'];
                    break;
                case '6':
                    $adr =  $address[$pid]['address'];
                    break;
                case '7':
                    $adr =  $address[$pid]['poiname'];
                    break;
                default:
                    $adr =  $address[$pid]['poiname'];
                    break;
            }

            $adr  = $adr?$adr:$address[$pid]['address'];

            $lng=$address[$pid]['lng'];
            $lat=$address[$pid]['lat'];
            $poiname=$address[$pid]['poiname'];
            $color = $this->config['color'];

            $return ="";

            if($adr != ''){
                    include template('yam_location:viewthread_postbottom_mobile');
            }
            if($index == 0 ){
                $data[$index]=$data['']=$return;
            }else{
                $data[$index]=$return;
            }
        }
        return $data;
    }

}