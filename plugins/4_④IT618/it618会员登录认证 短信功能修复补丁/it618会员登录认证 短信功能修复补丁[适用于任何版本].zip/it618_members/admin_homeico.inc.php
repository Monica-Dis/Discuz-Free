<?php
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if(count($reabc)!=13)return;

loadcache('plugin');
$it618_members = $_G['cache']['plugin']['it618_members'];

require_once DISCUZ_ROOT.'./source/plugin/it618_members/function/it618_members.func.php';

if($reabc[10]!='e')return;

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_dxjk&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_homeico');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_homeico' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter();
?>