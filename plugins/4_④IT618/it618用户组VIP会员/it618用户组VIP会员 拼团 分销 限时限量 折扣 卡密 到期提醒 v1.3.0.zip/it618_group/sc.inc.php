<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_default.func.php';

if($group_templatename_admin=='sc'){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
		$it618_membersstr= '<span id="it618_members"></span>'.it618_members_getmembers($_GET['id'],'#it618_members');
	}
	
	if($IsCredits==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
		$it618_creditsstr= '<span id="it618_credits"></span>'.it618_credits_getcredits($_GET['id'],'#it618_credits');
	}
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_group/config/feieyun.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/config/feieyun.php';
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_group:'.$group_templatename_admin.'/sc_index');
?>