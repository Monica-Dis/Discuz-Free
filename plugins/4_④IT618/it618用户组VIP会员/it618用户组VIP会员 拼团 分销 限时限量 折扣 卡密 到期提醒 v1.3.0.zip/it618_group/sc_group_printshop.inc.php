<?php
 /**
 *	�����Ŷӣ�DisM.Taobao.Com
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';

$prid=intval($_GET['prid']);

$it618_group_print = C::t('#it618_group#it618_group_print')->fetch_by_id($prid);

$it618_waimai = $_G['cache']['plugin']['it618_waimai'];
$it618_brand = $_G['cache']['plugin']['it618_brand'];
$it618_tuan = $_G['cache']['plugin']['it618_tuan'];

$brandcss='';$tuancss='';$waimaicss='';
if($_GET['shoptype']=='waimai'){$waimaicss='class="current"';$shoptype=$_GET['shoptype'];}
if($_GET['shoptype']=='brand'){$brandcss='class="current"';$shoptype=$_GET['shoptype'];}
if($_GET['shoptype']=='tuan'){$tuancss='class="current"';$shoptype=$_GET['shoptype'];}

if($shoptype=='')exit;

if(submitcheck('it618submit')){
	
	$pids_array = !empty($_GET['it618_shopidstmp']) ? $_GET['it618_shopidstmp'] : array();
	foreach($pids_array as $key => $value) {
		$value=$_GET['it618_shopids'][$key];
		if($it618_group_printshop=C::t('#it618_group#it618_group_printshop')->fetch_by_prid_shoptype_pid($prid,$shoptype,$key)){
			C::t('#it618_group#it618_group_printshop')->update($it618_group_printshop['id'],array(
				'it618_isok' => $value
			));
		}else{
			C::t('#it618_group#it618_group_printshop')->insert(array(
				'it618_prid' => $prid,
				'it618_shoptype' => $shoptype,
				'it618_shopid' => $key,
				'it618_isok' => $value
			), true);
		}
	}
	
	it618_cpmsg($it618_group_lang['s469'], "plugin.php?id=it618_group:sc_group_printshop&prid=$prid&shoptype=$shoptype", 'succeed');
}

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:10px"><ul class="tab1" id="submenu">';

if($it618_waimai['waimai_name']!=''){
	echo '<li '.$waimaicss.'><a href="'.$hosturl.'plugin.php?id=it618_group:sc_group_printshop&prid='.$prid.'&shoptype=waimai"><span>'.$it618_group_lang['s385'].'</span></a></li>';
}
if($it618_brand['brand_name']!=''){
	echo '<li '.$brandcss.'><a href="'.$hosturl.'plugin.php?id=it618_group:sc_group_printshop&prid='.$prid.'&shoptype=brand"><span>'.$it618_group_lang['s383'].'</span></a></li>';
}
if($it618_tuan['seotitle']!=''){
	echo '<li '.$tuancss.'><a href="'.$hosturl.'plugin.php?id=it618_group:sc_group_printshop&prid='.$prid.'&shoptype=tuan"><span>'.$it618_group_lang['s384'].'</span></a></li>';
}

echo '</ul></div>';

if($shoptype=='waimai'){
	require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function.func.php';
	$it618_shopids_strtmp='';
	$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai')." where it618_state=2 and it618_htstate=1");
	while($tmpshop = DB::fetch($query)) {
		
		$it618_group_printshop=C::t('#it618_group#it618_group_printshop')->fetch_by_prid_shoptype_pid($prid,$shoptype,$tmpshop['id']);
		$tmpchecked='';
		if($it618_group_printshop['it618_isok']==1){
			$tmpchecked='checked="checked"';
		}
		
		$tmpurl=it618_waimai_getrewrite('shop_home',$tmpshop['id'],'plugin.php?id=it618_waimai:shop&sid='.$tmpshop['id']);
		
		$it618_shopids_strtmp.='<li><span class="salepowerspan"><input type="hidden" name="it618_shopidstmp['.$tmpshop['id'].']"><input type="checkbox" class="shop'.$shoptype.'" id="it618_shopids'.$tmpshop['id'].'" name="it618_shopids['.$tmpshop['id'].']" value="1" '.$tmpchecked.'><label for="it618_shopids'.$tmpshop['id'].'">'.$it618_group_lang['s468'].'</label></span>['.$tmpshop['id'].'] <a href="'.$tmpurl.'" target="_blank">'.$tmpshop['it618_name'].'</a></li>';
	}
}

if($shoptype=='brand'){
	require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';
	$it618_shopids_strtmp='';
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand')." where it618_state=2 and it618_htstate=1");
	while($tmpshop = DB::fetch($query)) {
		$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($tmpshop['it618_power']);
		if($it618_brand_brandgroup['it618_isgoods']==1){
			
			$it618_group_printshop=C::t('#it618_group#it618_group_printshop')->fetch_by_prid_shoptype_pid($prid,$shoptype,$tmpshop['id']);
			$tmpchecked='';
			if($it618_group_printshop['it618_isok']==1){
				$tmpchecked='checked="checked"';
			}
			
			$tmpurl=it618_brand_getrewrite('shop_home',$tmpshop['id'],'plugin.php?id=it618_brand:shop&sid='.$tmpshop['id']);
			
			$it618_shopids_strtmp.='<li><span class="salepowerspan"><input type="hidden" name="it618_shopidstmp['.$tmpshop['id'].']"><input type="checkbox" class="shop'.$shoptype.'" id="it618_shopids'.$tmpshop['id'].'" name="it618_shopids['.$tmpshop['id'].']" value="1" '.$tmpchecked.'><label for="it618_shopids'.$tmpshop['id'].'">'.$it618_group_lang['s468'].'</label></span>['.$tmpshop['id'].'] <a href="'.$tmpurl.'" target="_blank">'.$tmpshop['it618_name'].'</a></li>';
		}
	}
}

if($shoptype=='tuan'){
	require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';
	$it618_shopids_strtmp='';
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_shop')." where it618_state=2 and it618_htstate=1");
	while($tmpshop = DB::fetch($query)) {
		
		$it618_group_printshop=C::t('#it618_group#it618_group_printshop')->fetch_by_prid_shoptype_pid($prid,$shoptype,$tmpshop['id']);
		$tmpchecked='';
		if($it618_group_printshop['it618_isok']==1){
			$tmpchecked='checked="checked"';
		}
		
		$tmpurl=it618_tuan_getrewrite('tuan_shop',$tmpshop['id'],'plugin.php?id=it618_tuan:shop&sid='.$tmpshop['id']);
		
		$it618_shopids_strtmp.='<li><span class="salepowerspan"><input type="hidden" name="it618_shopidstmp['.$tmpshop['id'].']"><input type="checkbox" class="shop'.$shoptype.'" id="it618_shopids'.$tmpshop['id'].'" name="it618_shopids['.$tmpshop['id'].']" value="1" '.$tmpchecked.'><label for="it618_shopids'.$tmpshop['id'].'">'.$it618_group_lang['s468'].'</label></span>['.$tmpshop['id'].'] <a href="'.$tmpurl.'" target="_blank">'.$tmpshop['it618_name'].'</a></li>';

	}
}

if($it618_shopids_strtmp!='')$it618_shopids_str.='<div class="goodsdiv"><span class="salepowerspan"><input type="checkbox" id="shopsalepower'.$shoptype.'" onclick="editsalepower(\''.$shoptype.'\')"><label for="shopsalepower'.$shoptype.'">'.$it618_group_lang['s467'].'</label></span><span class="namespan">'.$it618_group_lang['s466'].'</span></div><ul class="goodsul">'.$it618_shopids_strtmp.'</ul>';

it618_showformheader("plugin.php?id=it618_group:sc_group_printshop&prid=$prid&shoptype=$shoptype");
showtableheaders($it618_group_print['it618_sn'].'-'.$it618_group_print['it618_about'].'<span style="font-weight:normal;float:right;">'.$it618_group_lang['s464'].'</span>','sc_group_printshop');

echo '
<style>
.goodsdiv{float:left;width:100%;padding:10px 0px}
.goodsdiv .namespan{font-size:12px;color:#000;}
.goodsdiv .salepowerspan{float:right;margin-right:6px}
.goodsul{float:left;width:99%;background-color:#f1f1f1;padding:10px;padding-right:0}
.goodsul li{float:left;width:50%;padding-top:5px;padding-bottom:5px}
.goodsul li .salepowerspan{float:right;margin-right:15px}
.salepowerspan label,.salepowerspan input{vertical-align:middle}
</style>
<script charset="utf-8" src="source/plugin/it618_group/js/jquery.js"></script>

<script>
function editsalepower(type){
	IT618_GROUP(".shop"+type).attr("checked",IT618_GROUP("#shopsalepower"+type).prop("checked"));
}
</script>

<tr><td>'.$it618_shopids_str.'</td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_group_getlang('s10').'" /></div></td></tr>';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>