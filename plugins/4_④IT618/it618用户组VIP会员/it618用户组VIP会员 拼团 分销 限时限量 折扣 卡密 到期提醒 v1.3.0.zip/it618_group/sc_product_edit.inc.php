<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tmpidarr=explode(":",$_GET['id']);
$tempabc=$tmpidarr[0];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';

$pid=intval($_GET['pid']);
$it618_group_goods=C::t('#it618_group#it618_group_goods')->fetch_by_id($pid);
$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);

$it618_unit=it618_group_getgoodsunit($it618_group_goods);

if(submitcheck('it618submit')){
	for($i=0;$i<=0;$i++){
		if($i==0)$tmpi='';else $tmpi=$i;
		$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
		
		if($it618_group_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
			$tmparr=explode("source",$it618_group_goods['it618_picbig'.$tmpi]);
			$tmparr1=explode("://",$it618_group_goods['it618_picbig'.$tmpi]);
			$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
			
			if(file_exists($it618_picbig)&&count($tmparr1)==1){
				$result=unlink($it618_picbig);
			}
		}
		
		$file_ext=strtolower(substr($it618_group_goods['it618_picbig'.$tmpi],strrpos($it618_group_goods['it618_picbig'.$tmpi], '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext;
		if(file_exists($it618_smallurl)){
			$result=unlink($it618_smallurl);
		}
		
		if($it618_group_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/smallimage/';
			if (!file_exists($smallpath)) {
				mkdir($smallpath);
			}

			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1));
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/smallimage/goods'.$pid.'_'.md5($get_it618_picbig).'.'.$file_ext;
			it618_group_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,385,1);
		}

	}
	
	C::t('#it618_group#it618_group_goods')->update($pid,array(
		'it618_picbig' => dhtmlspecialchars($_GET['it618_picbig']),
		'it618_seokeywords' => dhtmlspecialchars($_GET['it618_seokeywords']),
		'it618_seodescription' => dhtmlspecialchars($_GET['it618_seodescription']),
		'it618_message' => $_GET['it618_message']
	));
	
	echo '<script>parent.location.reload();parent.layer.closeAll();</script>';
}

if($it618_group_goods['it618_picbig']!='')$src='src="'.$it618_group_goods['it618_picbig'].'"';

it618_showformheader("plugin.php?id=it618_group:sc_product_edit&pid=$pid");
showtableheaders($grouptitle.' - '.$it618_unit,'it618_group_goods');

echo '
<link rel="stylesheet" href="source/plugin/it618_group/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_group/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_group/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_group/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_group/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_group/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_group/kindeditor/php/upload_json.php?&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_group/kindeditor/php/file_manager_json.php?\',
			allowFileManager : true,
			filterMode:false
		});
		
		K(\'#image1\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
	});
</script>

<tr><td width=80>'.it618_group_getlang('s258').'</td><td><img id="img1" '.$src.' width="100" height="60" align="absmiddle"/> <input type="text" id="url1" name="it618_picbig" value="'.$it618_group_goods['it618_picbig'].'" readonly="readonly"/> <input type="button" id="image1" value="'.it618_group_getlang('s259').'" /></td></tr>
<tr><td>'.it618_group_getlang('s48').'</td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;">'.$it618_group_goods['it618_message'].'</textarea></td></tr>
<tr><td>'.it618_group_getlang('s49').'</td><td><input type="text" class="txt" style="width:696px;margin-right:0" name="it618_seokeywords" value="'.$it618_group_goods['it618_seokeywords'].'"></td></tr>
<tr><td>'.it618_group_getlang('s50').'</td><td><textarea name="it618_seodescription" style="width:696px;height:60px;">'.$it618_group_goods['it618_seodescription'].'</textarea></td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_group_getlang('s122').'" /></div></td></tr>';
	if(count($reabc)!=11)return;
    showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>