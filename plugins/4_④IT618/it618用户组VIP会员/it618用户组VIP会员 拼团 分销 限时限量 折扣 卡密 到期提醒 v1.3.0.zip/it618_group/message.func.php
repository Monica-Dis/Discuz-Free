<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function sendSMS($uid,$pwd,$mobile,$content){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
	
	$smsapi='http://www.smsbao.com/';
	$pwd = md5($pwd);
	
	$sendurl = $smsapi."sms?u=".$uid."&p=".$pwd."&m=".$mobile."&c=".urlencode(it618_group_gbktoutf($content));
	$result =dfsockopen($sendurl);

	return $result;
}

function sendSMS_ALi($it618_tel,$members_bz,$members_sign,$members_tplid,$members_param,$it618_jktype){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/message.func.php';
	
	return sendSMS_ALIAPI('it618_group',$it618_tel,$members_bz,$members_sign,$members_tplid,$members_param,$it618_jktype);
}

function sendSMS_WX($uid,$url,$members_tplid,$members_param){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/message.func.php';
	
	return sendSMS_WXAPI('it618_group',$uid,$url,$members_tplid,$members_param);
}

function debugSMS($content){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_group/debug.txt',"a");
	fwrite($fp,$content);
	fclose($fp);
}
?>