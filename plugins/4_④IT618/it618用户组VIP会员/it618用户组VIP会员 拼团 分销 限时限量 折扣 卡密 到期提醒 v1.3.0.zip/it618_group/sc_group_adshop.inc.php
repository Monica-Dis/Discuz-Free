<?php
 /**
 *	�����Ŷӣ�DisM.Taobao.Com
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';

$aid=intval($_GET['aid']);

$it618_group_ad=C::t('#it618_group#it618_group_ad')->fetch_by_id($aid);

if($it618_group_ad['it618_type']==1){
	$it618_type=$it618_group_lang['s406'];
	$size=$it618_group_ad['it618_width'].'% * '.$it618_group_ad['it618_height'].'%';
}else{
	$it618_type=$it618_group_lang['s407'];
	$size=$it618_group_ad['it618_width'].'px * '.$it618_group_ad['it618_height'].'px';
}

$it618_video = $_G['cache']['plugin']['it618_video'];
$it618_exam = $_G['cache']['plugin']['it618_exam'];
$it618_brand = $_G['cache']['plugin']['it618_brand'];
$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
$it618_waimai = $_G['cache']['plugin']['it618_waimai'];

if(submitcheck('it618submit')){
	C::t('#it618_group#it618_group_adshop')->update_it618_isok_by_aid(0,$aid);
	
	$adarea_array = !empty($_GET['adareatmp']) ? $_GET['adareatmp'] : array();
	foreach($adarea_array as $key => $value) {
		$plugin=$_GET['adarea'][$key];
		if($plugin!=''){
			if($it618_group_adshop=C::t('#it618_group#it618_group_adshop')->fetch_by_plugin_aid($plugin,$aid)){
				C::t('#it618_group#it618_group_adshop')->update($it618_group_adshop['id'],array(
					'it618_isok' => 1
				));
			}else{
				C::t('#it618_group#it618_group_adshop')->insert(array(
					'it618_plugin' => $plugin,
					'it618_aid' => $aid,
					'it618_isok' => 1
				), true);
			}
		}
	}
	
	$tmparr=explode(",",$_GET['it618_uids']);
	$tmparr=array_unique($tmparr);
	for($i=0;$i<count($tmparr);$i++){
		$tmpuid=intval($tmparr[$i]);
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$tmpuid);
		if($username!=''){
			$uidstr.=$tmpuid.',';
		}
	}
	
	if($uidstr!=''){
		$uidstr.='@';
		$uidstr=str_replace(",@","",$uidstr);
	}
	
	C::t('#it618_group#it618_group_ad')->update($it618_group_ad['id'],array(
		'it618_uids' => $uidstr
	));
	
	echo '<script>parent.location.reload();parent.layer.closeAll();</script>';
}

function getpluginarea($plugin,$n,$aid,$title){
	global $it618_group_lang;
	
	$it618_group_adshop=C::t('#it618_group#it618_group_adshop')->fetch_by_plugin_aid($plugin,$aid);
	$tmpchecked='';
	if($it618_group_adshop['it618_isok']==1){
		$tmpchecked='checked="checked"';
	}
	
	return '<li><input type="hidden" name="adareatmp['.$n.']"><input type="checkbox" id="adarea'.$n.'" name="adarea['.$n.']" value="'.$plugin.'" '.$tmpchecked.'><label for="adarea'.$n.'">'.$title.$it618_group_lang['s485'].'</label></li>';
}

$n=0;

if($it618_video['seotitle']!=''){
	$n=$n+1;
	$adarea_strtmp.=getpluginarea('video',$n,$aid,$it618_group_lang['s381']);
}
if($it618_exam['seotitle']!=''){
	$n=$n+1;
	$adarea_strtmp.=getpluginarea('exam',$n,$aid,$it618_group_lang['s382']);
}
if($it618_brand['brand_name']!=''){
	$n=$n+1;
	$adarea_strtmp.=getpluginarea('brand',$n,$aid,$it618_group_lang['s383']);
}
if($it618_tuan['seotitle']!=''){
	$n=$n+1;
	$adarea_strtmp.=getpluginarea('tuan',$n,$aid,$it618_group_lang['s384']);
}
if($it618_waimai['waimai_name']!=''){
	$n=$n+1;
	$adarea_strtmp.=getpluginarea('waimai',$n,$aid,$it618_group_lang['s385']);
}

it618_showformheader("plugin.php?id=it618_group:sc_group_adshop&aid=$aid");
showtableheaders($it618_group_lang['s401'].$aid.' <font color=red>'.$it618_type.'</font> '.$it618_group_lang['s414'].$size,'sc_group_adshop');

$tmparr=explode(",",$it618_group_ad['it618_uids']);
$tmparr=array_unique($tmparr);
for($i=0;$i<count($tmparr);$i++){
	$tmpuid=intval($tmparr[$i]);
	$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$tmpuid);
	if($username!=''){
		$userstr.=$username.'('.$tmpuid.') , ';
	}
}

if($userstr!=''){
	$userstr.='@';
	$userstr=str_replace(" , @","",$userstr);
}

echo '
<style>
.goodsul{float:left;width:99%;padding:10px;padding-right:0}
.goodsul li{float:left;width:230px;padding-top:5px;padding-bottom:5px}
.goodsul li label,.goodsul li input{vertical-align:middle}
</style>

<tr><td><ul class="goodsul">'.$adarea_strtmp.'</ul></td></tr>
<tr><td><br>'.$it618_group_lang['s486'].'<br><br>
<textarea name="it618_uids" style="width:800px;height:180px;line-height:18px;font-size:13px">'.$it618_group_ad['it618_uids'].'</textarea><br><br><font color=#390>'.$userstr.'</font><br><br>
'.$it618_group_lang['s487'].'<br>
</td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_group_getlang('s10').'" /></div></td></tr>';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>