<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tmpidarr=explode(":",$_GET['id']);
$tempabc=$tmpidarr[0];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';

$aid=intval($_GET['aid']);
$it618_group_ad=C::t('#it618_group#it618_group_ad')->fetch_by_id($aid);

if($it618_group_ad['it618_type']==1){
	$it618_type=$it618_group_lang['s406'];
	$size=$it618_group_ad['it618_width'].'% * '.$it618_group_ad['it618_height'].'%';
}else{
	$it618_type=$it618_group_lang['s407'];
	$size=$it618_group_ad['it618_width'].'px * '.$it618_group_ad['it618_height'].'px';
}

if(submitcheck('it618submit')){
	
	C::t('#it618_group#it618_group_ad')->update($aid,array(
		'it618_content' => $_GET['it618_content']
	));
	
	echo '<script>parent.location.reload();parent.layer.closeAll();</script>';
}

it618_showformheader("plugin.php?id=it618_group:sc_group_adcontent&aid=$aid");
showtableheaders($it618_group_lang['s401'].$aid.' '.$it618_type.' '.$it618_group_lang['s414'].$size,'it618_group_goods');

echo '
<link rel="stylesheet" href="source/plugin/it618_group/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_group/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_group/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_group/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_group/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_content"]\', {
			cssPath : \'source/plugin/it618_group/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_group/kindeditor/php/upload_json.php?&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_group/kindeditor/php/file_manager_json.php?\',
			allowFileManager : true,
			filterMode:false
		});
	});
</script>

<tr><td><textarea name="it618_content" style="width:700px;height:400px;visibility:hidden;">'.$it618_group_ad['it618_content'].'</textarea></td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_group_getlang('s122').'" /></div></td></tr>';
	if(count($reabc)!=11)return;
    showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>