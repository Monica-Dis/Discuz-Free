<?php
 /**
 *	�����Ŷӣ�DisM.Taobao.Com
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';

$gid=intval($_GET['gid']);

$it618_group_group = C::t('#it618_group#it618_group_group')->fetch_by_id($gid);
$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_group['it618_groupid']);

if(submitcheck('it618submit')){
	$video_pids=getids($_GET['it618_video_pids'],'SELECT * FROM '.DB::table('it618_video_goods').' WHERE id=');
	
	C::t('#it618_group#it618_group_group')->update($gid,array(
		'it618_video_pids' => $video_pids
	));

	echo '<script>parent.location.reload();parent.layer.closeAll();</script>';
}

function getids($ids,$sql){
	$tmpids=',';
	$tmpidsarr=explode(',',$ids);
	for($i=0;$i<count($tmpidsarr);$i++){
		$id=intval($tmpidsarr[$i]);
		if($id>0){
			if(DB::result_first($sql.$id)>0){
				$tmpids.=','.$id;
			}
		}
	}
	if($tmpids==','){
		$tmpids='';
	}else{
		$tmpids=str_replace(',,','',$tmpids);
	}
	
	return $tmpids;
}

it618_showformheader("plugin.php?id=it618_group:sc_group_videopids&gid=$gid");
showtableheaders($grouptitle,'sc_group_videopids');

$tmpidsarr=explode(',',$it618_group_group['it618_video_pids']);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);
	
	$pnamestr.='<option>'.DB::result_first("SELECT it618_name FROM ".DB::table('it618_video_goods')." WHERE id=".$id).'</option>';
}

echo '
<tr><td>'.$it618_group_lang['s221'].'</td></tr>
<tr><td><textarea name="it618_video_pids" style="width:580px;height:80px;">'.$it618_group_group['it618_video_pids'].'</textarea></td></tr>
<tr><td><select style="color:green;">'.$pnamestr.'</select></td></tr>
<tr><td>'.$it618_group_lang['s222'].'</td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_group_getlang('s10').'" /></div></td></tr>';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>