<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tmpidarr=explode(":",$_GET['id']);
$tempabc=$tmpidarr[0];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_group_ad', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_type'])) {
		foreach($_GET['it618_type'] as $id => $val) {
			
			$it618_type=trim($_GET['it618_type'][$id]);
			$it618_width=trim($_GET['it618_width'][$id]);
			$it618_height=trim($_GET['it618_height'][$id]);
			
			if($it618_type==1){
				if($it618_width<30)$it618_width=30;
				if($it618_height<30)$it618_height=30;
				if($it618_width>100)$it618_width=100;
				if($it618_height>100)$it618_height=100;
			}

			C::t('#it618_group#it618_group_ad')->update($id,array(
				'it618_type' => trim($_GET['it618_type'][$id]),
				'it618_btn1title' => trim($_GET['it618_btn1title'][$id]),
				'it618_btn2title' => trim($_GET['it618_btn2title'][$id]),
				'it618_btn1url' => trim($_GET['it618_btn1url'][$id]),
				'it618_cookiestime' => trim($_GET['it618_cookiestime'][$id]),
				'it618_width' => $it618_width,
				'it618_height' => $it618_height,
				'it618_isok' => trim($_GET['it618_isok'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_type_array = !empty($_GET['newit618_type']) ? $_GET['newit618_type'] : array();
	$newit618_btn1title_array = !empty($_GET['newit618_btn1title']) ? $_GET['newit618_btn1title'] : array();
	$newit618_btn2title_array = !empty($_GET['newit618_btn2title']) ? $_GET['newit618_btn2title'] : array();
	$newit618_btn1url_array = !empty($_GET['newit618_btn1url']) ? $_GET['newit618_btn1url'] : array();
	$newit618_cookiestime_array = !empty($_GET['newit618_cookiestime']) ? $_GET['newit618_cookiestime'] : array();
	$newit618_width_array = !empty($_GET['newit618_width']) ? $_GET['newit618_width'] : array();
	$newit618_height_array = !empty($_GET['newit618_height']) ? $_GET['newit618_height'] : array();
	
	foreach($newit618_type_array as $key => $value) {
		$newit618_type = addslashes(trim($newit618_type_array[$key]));
		
		$it618_width=trim($newit618_width_array[$key]);
		$it618_height=trim($newit618_height_array[$key]);
		if($newit618_type==1){
			if($it618_width<30)$it618_width=30;
			if($it618_height<30)$it618_height=30;
			if($it618_width>100)$it618_width=100;
			if($it618_height>100)$it618_height=100;
		}
		
		if($newit618_type != '') {
			
			C::t('#it618_group#it618_group_ad')->insert(array(
				'it618_type' => trim($newit618_type_array[$key]),
				'it618_btn1title' => trim($newit618_btn1title_array[$key]),
				'it618_btn2title' => trim($newit618_btn2title_array[$key]),
				'it618_btn1url' => trim($newit618_btn1url_array[$key]),
				'it618_cookiestime' => trim($newit618_cookiestime_array[$key]),
				'it618_width' => $it618_width,
				'it618_height' => $it618_height,
			), true);
			$ok2=$ok2+1;
		}
	}

	it618_cpmsg($it618_group_lang['s33'].$ok1.' '.$it618_group_lang['s34'].$ok2.' '.$it618_group_lang['s35'].$del.')', "plugin.php?id=it618_group:sc_group_ad&page=$page", 'succeed');
}

if(count($reabc)!=11)return;

it618_showformheader("plugin.php?id=it618_group:sc_group_ad&page=$page");
showtableheaders($it618_group_lang['s394'],'it618_group_ad');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_group_ad'));
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_group:sc_group_ad&page=$page");
	
	echo '<tr><td colspan=10 style="line-height:19px">'.$it618_group_lang['s488'].'</td></tr>';
	echo '<tr><td colspan=10>'.$it618_group_lang['s404'].$count.'<span style="float:right">'.$it618_group_lang['s405'].'</span></td></tr>';
	showsubtitle(array('', $it618_group_lang['s399'], $it618_group_lang['s409'], $it618_group_lang['s400'],$it618_group_lang['s402'],$it618_group_lang['s403']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_ad')." ORDER BY id desc LIMIT $startlimit, $ppp");
	while($it618_group_ad = DB::fetch($query)) {
		
		if($it618_group_ad['it618_type']==1){
			$it618_type=$it618_group_lang['s406'];
		}else{
			$it618_type=$it618_group_lang['s407'];
		}
		
		$adcontentcount='<font color=red>'.strlen($it618_group_ad['it618_content']).'</font>';
		$areacount=DB::result_first("select count(1) from ".DB::table('it618_group_adarea')." where it618_isok=1 and it618_aid=".$it618_group_ad['id']);
		$groupcount=DB::result_first("select count(1) from ".DB::table('it618_group_adgroup')." where it618_isok=1 and it618_aid=".$it618_group_ad['id']);
		$shopcount=DB::result_first("select count(1) from ".DB::table('it618_group_adshop')." where it618_isok=1 and it618_aid=".$it618_group_ad['id']);
		$usercount=0;
		if($it618_group_ad['it618_uids']!='')$usercount=count(explode(',',$it618_group_ad['it618_uids']));
		
		$urlareacount=strlen($it618_group_ad['it618_urlarea']);
		if($urlareacount>0)$urlareacount='/'.$urlareacount;else $urlareacount='';
		$areacount='<font color=red>'.$areacount.$urlareacount.'</font>';
		$groupcount='<font color=red>'.$groupcount.'</font>';
		$shopcount='<font color=red>'.$shopcount.'</font>';
		$usercount='<font color=red>'.$usercount.'</font>';
		
		if($it618_group_ad['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
		
		showtablerow('', array('class="td25"', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="adid'.$it618_group_ad['id'].'" name="delete[]" value="'.$it618_group_ad['id'].'" '.$disabled.'><label for="adid'.$it618_group_ad['id'].'">'.$it618_group_ad['id'].'</label>',
			$it618_type.'<input type="hidden" name="it618_type['.$it618_group_ad['id'].']" value="'.$it618_group_ad['it618_type'].'"> <input class="txt" type="text" name="it618_width['.$it618_group_ad['id'].']" value="'.$it618_group_ad['it618_width'].'" style="width:58px;margin-right:3px"><input class="txt" type="text" name="it618_height['.$it618_group_ad['id'].']" value="'.$it618_group_ad['it618_height'].'" style="width:58px">',
			' <a href="javascript:" onclick="showadcontent('.$it618_group_ad['id'].')">'.$it618_group_lang['s410'].'('.$adcontentcount.')</a> | <a href="javascript:" onclick="showaderea('.$it618_group_ad['id'].')">'.$it618_group_lang['s411'].'('.$areacount.')</a> | <a href="javascript:" onclick="showadgroup('.$it618_group_ad['id'].')">'.$it618_group_lang['s439'].'('.$groupcount.')</a> <a href="javascript:" onclick="showadshop('.$it618_group_ad['id'].')">'.$it618_group_lang['s483'].'('.$shopcount.'/'.$usercount.')</a>',
			'<input class="txt" type="text" name="it618_btn1title['.$it618_group_ad['id'].']" value="'.$it618_group_ad['it618_btn1title'].'" style="width:80px;margin-right:3px"><input class="txt" type="text" name="it618_btn2title['.$it618_group_ad['id'].']" value="'.$it618_group_ad['it618_btn2title'].'" style="width:80px;margin-right:3px"><input class="txt" type="text" name="it618_btn1url['.$it618_group_ad['id'].']" value="'.$it618_group_ad['it618_btn1url'].'" style="width:230px;margin-right:3px">',
			'<input class="txt" type="text" name="it618_cookiestime['.$it618_group_ad['id'].']" value="'.$it618_group_ad['it618_cookiestime'].'" style="width:58px">',
			'<input class="checkbox" type="checkbox" id="it618_isok'.$it618_group_ad['id'].'" name="it618_isok['.$it618_group_ad['id'].']" '.$it618_isok_checked.' value="1"><label for="it618_isok'.$it618_group_ad['id'].'">'.$it618_group_lang['s329'].'</label>',
		));
	}
	
	$it618_group_lang406=$it618_group_lang['s406'];
	$it618_group_lang407=$it618_group_lang['s407'];
	$it618_group_lang408=$it618_group_lang['s408'];
	$it618_group_lang411=$it618_group_lang['s411'];
	$it618_group_lang412=$it618_group_lang['s412'];

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	
echo '
	<script>
	function showadcontent(aid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_group_lang['s412'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_group:sc_group_adcontent&aid="+aid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	
	function showaderea(aid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_group_lang['s413'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_group:sc_group_adarea&aid="+aid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	
	function showadgroup(aid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_group_lang['s437'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_group:sc_group_adgroup&aid="+aid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	
	function showadshop(aid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_group_lang['s483'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_group:sc_group_adshop&aid="+aid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	</script>
	';
	
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_type[]").length;
	
		return [
		[[1,''], 
		[1,'<select name="newit618_type[]"><option value=1>$it618_group_lang406</option><option value=2>$it618_group_lang407</option></select> <input type="text" class="txt" style="width:58px;margin-right:3px" name="newit618_width[]"><input type="text" class="txt" style="width:58px" name="newit618_height[]">'],
		[1,'$it618_group_lang408'],
		[1,'<input type="text" class="txt" style="width:80px;margin-right:3px" name="newit618_btn1title[]"><input type="text" class="txt" style="width:80px;margin-right:3px" name="newit618_btn2title[]"><input type="text" class="txt" style="width:230px;margin-right:3px" name="newit618_btn1url[]">'], 
		[1,'<input type="text" class="txt" style="width:58px" name="newit618_cookiestime[]">'], 
		[1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$it618_group_lang['s119'].'</a></div></td></tr>';
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_group_lang['s591'].'</label></td><td colspan="4"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.$it618_group_lang['s120'].'"/></div></td></tr>';
	if(count($reabc)!=11)return;
    showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>