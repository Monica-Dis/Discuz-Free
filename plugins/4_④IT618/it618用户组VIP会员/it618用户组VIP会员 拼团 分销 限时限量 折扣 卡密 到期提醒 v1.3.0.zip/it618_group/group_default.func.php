<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';

$group_logo=$it618_group['group_logo'];
$group_logourl=$it618_group['group_logourl'];
if($group_logourl==''){
	$group_logourl=$_G['siteurl'];
}

if($_G['uid']>0){
	$group_adminuids=explode(",",$it618_group['group_adminuids']);
	if(in_array($_G['uid'], $group_adminuids)){
		$isadmin=1;
		$adminurl=it618_group_getrewrite('group_sc','','plugin.php?id=it618_group:sc');
	}
	
	C::t('#it618_group#it618_group_sale')->update_lastactivity_by_uid(TIMESTAMP,$_G['uid']);
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		$it618_members = $_G['cache']['plugin']['it618_members'];
		if($it618_members['members_ishome']==1||$it618_members['members_ishome']==2){
			$tmpmembers='<li>
					<a href="javascript:" class="login-link" id="it618_members"><img src="source/plugin/it618_members/images/logo.png" style="vertical-align:middle; margin-right:3px; margin-top:-3px;height:17px" />'.$it618_members['members_homename'].'</a> 
					</li>';
		}
	}
	
	if($IsCredits==1){
		$tmpcredits='<li>
					<a href="javascript:" class="login-link" id="it618_credits"><img src="source/plugin/it618_credits/images/ico.png" style="vertical-align:middle; margin-right:3px; margin-top:-3px;height:15px" />'.it618_group_getlang('s118').'</a> 
					</li>';
	}
	
	$usermenu='<ul class="login cl">
				<li class="login-link">'.it618_group_getusername($_G['uid']).'</li>
				'.$tmpmembers.'
				'.$tmpcredits.'
                <li class="dropdown dropdown-account">
                    <p class="textwarp">
                        <em class="text">'.it618_group_getlang('s456').'</em>
                        <i class="triangle"></i>
                        <em class="account-num" style="display:none;"></em>
					</p>
                    <ul class="htul">
						<li>
						<a href="javascript:" id="mysale">'.it618_group_getlang('s457').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="mysubscribe">'.it618_group_getlang('s1403').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="mygoods">'.it618_group_getlang('s73').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="mytest">'.it618_group_getlang('s458').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="myerr">'.it618_group_getlang('s846').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="myutest">'.it618_group_getlang('s448').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="mytestpj"><font color=green>'.it618_group_getlang('s459').'</font></a> 
				    	</li>
						'.$tmprz.'
                    </ul>
                </li>
                <li><a class="login-link" href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'">['.it618_group_getlang('s460').']</a></li>
			   </ul>';
}else{
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if($it618_members['members_isok']==1){
		$usermenu='<ul class="login cl">
				'.$templatestylestr.'
                <li><a class="login-link it618_members_login" href="javascript:">['.it618_group_getlang('s461').']</a></li>
                <li><a class="login-link it618_members_reg" href="javascript:">['.it618_group_getlang('s462').']</a></li>    
               </ul>';
	}else{
		$usermenu='<ul class="login cl">
				'.$templatestylestr.'
                <li><a class="login-link" href="member.php?mod=logging&action=login">['.it618_group_getlang('s461').']</a></li>
                <li><a class="login-link" href="member.php?mod='.$RegName.'">['.it618_group_getlang('s462').']</a></li>    
               </ul>';
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_group_nav')." where it618_order>0 ORDER BY it618_order desc");
while($it618_group_nav = DB::fetch($query)) {
	$it618_color='';
	if($it618_group_nav['it618_color']!=''){
		$it618_color='style="color:'.$it618_group_nav['it618_color'].'"';
	}
	$it618_target='';
	if($it618_group_nav['it618_target']==1){
		$it618_target='target="_blank"';
	}
	
	$navstr.='<li class="fr nav-btn nav-sjhb">
                <a class="pulldown-title-link singleA" '.$it618_color.' '.$it618_target.' href="'.$it618_group_nav['it618_url'].'">'.$it618_group_nav['it618_name'].'</a>
			</li>';
}

if($pagetype!='group_class'){
	foreach(C::t('#it618_group#it618_group_focus')->fetch_all_by_type_rand(6) as $it618_group_focus) {
		if($it618_group_focus['it618_url']!=''){
			$str_focus.='<li><a href="'.$it618_group_focus['it618_url'].'" target="_blank"><img src="'.$it618_group_focus['it618_img'].'"/></a></li>';
		}else{
			$str_focus.='<li><img src="'.$it618_group_focus['it618_img'].'"/></li>';
		}
	}
}

require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
$it618_group_uc=it618_group_getgroup($_GET['id']);

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	if(isset($_GET['reg']))$winapireg='winapireg';
	$it618_members_index=it618_members_getmembers($_GET['id'],'#it618_members','',$winapireg);
}

if($IsCredits==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$it618_credits_index=it618_credits_getcredits($_GET['id'],'.it618_credits');
	$it618_credits_buygroup=it618_credits_getcredits($_GET['id'],'#vippaybtn','plugin.php?id=it618_credits:do&dotype=buygroup');
}

$it618_group_ad=it618_group_getad($_GET['id'],2);
?>