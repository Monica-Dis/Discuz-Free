<?php
 /**
 *	�����Ŷӣ�DisM.Taobao.Com
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';

$aid=intval($_GET['aid']);

$it618_group_ad=C::t('#it618_group#it618_group_ad')->fetch_by_id($aid);

if($it618_group_ad['it618_type']==1){
	$it618_type=$it618_group_lang['s406'];
	$size=$it618_group_ad['it618_width'].'% * '.$it618_group_ad['it618_height'].'%';
}else{
	$it618_type=$it618_group_lang['s407'];
	$size=$it618_group_ad['it618_width'].'px * '.$it618_group_ad['it618_height'].'px';
}

if(submitcheck('it618submit')){

	if(is_array($_GET['it618_groupid'])) {
		foreach($_GET['it618_groupid'] as $id => $val) {
			
				C::t('#it618_group#it618_group_adgroup')->update($id,array(
					'it618_isok' => $_GET['it618_isok'][$id],
				));
		}
	}

	echo '<script>parent.location.reload();parent.layer.closeAll();</script>';
}

if(submitcheck('it618daosubmit')) {
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup'));
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_group_adgroup')." WHERE it618_aid=$aid and it618_groupid=".$common_usergroup['groupid'])==0){
			C::t('#it618_group#it618_group_adgroup')->insert(array(
				'it618_aid' => $aid,
				'it618_groupid' => $common_usergroup['groupid'],
			), true);
		}
	}
}

if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_group_adgroup')." where it618_aid=$aid")==0){
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup'));
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_group_adgroup')." WHERE it618_aid=$aid and it618_groupid=".$common_usergroup['groupid'])==0){
			C::t('#it618_group#it618_group_adgroup')->insert(array(
				'it618_aid' => $aid,
				'it618_groupid' => $common_usergroup['groupid'],
			), true);
		}
	}	
}

it618_showformheader("plugin.php?id=it618_group:sc_group_adgroup&aid=$aid");

showtableheaders('','it618_group_adgroup');
echo '<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618daosubmit" value="'.it618_group_getlang('s438').'" /></div></td></tr>';
	
	$groupcount=C::t('#it618_group#it618_group_adgroup')->count_by_aid($aid);
	
	echo '<tr><td colspan=10>'.$it618_group_lang['s440'].$groupcount.'<span style="float:right;color:red">'.$it618_group_lang['s441'].'</span></td></tr>';
	
	showsubtitle(array($it618_group_lang['s1845']));
	
	echo '<tr><td colspan=10><ul>';
	$query = DB::query("SELECT p.id,g.groupid,g.grouptitle,p.* FROM ".DB::table('it618_group_adgroup')." p,".DB::table('common_usergroup')." g WHERE p.it618_groupid=g.groupid and p.it618_aid=$aid");
	while($it618_group_adgroup =	DB::fetch($query)) {
		
		if($it618_group_adgroup['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
		
		echo '<li style="float:left;width:230px"><input type="hidden" name="it618_groupid['.$it618_group_adgroup['id'].']"><input type="checkbox" id="isok'.$it618_group_adgroup['id'].'" name="it618_isok['.$it618_group_adgroup['id'].']" style="vertical-align:middle" value="1" '.$it618_isok_checked.'><label for="isok'.$it618_group_adgroup['id'].'">'.$it618_group_adgroup['grouptitle'].'</label></li>';
	}
	echo '</ul></td></tr>';
	
echo '<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_group_getlang('s592').'" /></div></td></tr>';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>