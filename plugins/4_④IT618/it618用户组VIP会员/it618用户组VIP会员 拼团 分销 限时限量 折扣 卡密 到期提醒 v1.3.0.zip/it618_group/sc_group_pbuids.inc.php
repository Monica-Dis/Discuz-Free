<?php
 /**
 *	�����Ŷӣ�DisM.Taobao.Com
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';

$gid=intval($_GET['gid']);

$it618_group_group = C::t('#it618_group#it618_group_group')->fetch_by_id($gid);
$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_group['it618_groupid']);

if(submitcheck('it618submit')){
	
	$tmparr=explode(",",$_GET['it618_pbuids']);
	$tmparr=array_unique($tmparr);
	for($i=0;$i<count($tmparr);$i++){
		$tmpuid=intval($tmparr[$i]);
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$tmpuid);
		if($username!=''){
			$uidstr.=$tmpuid.',';
		}
	}
	
	if($uidstr!=''){
		$uidstr.='@';
		$uidstr=str_replace(",@","",$uidstr);
	}
	
	C::t('#it618_group#it618_group_group')->update($gid,array(
		'it618_pbuids' => $uidstr
	));

	echo '<script>parent.location.reload();parent.layer.closeAll();</script>';
}

it618_showformheader("plugin.php?id=it618_group:sc_group_pbuids&gid=$gid");
showtableheaders($grouptitle,'sc_group_pbuids');

$tmparr=explode(",",$it618_group_group['it618_pbuids']);
$tmparr=array_unique($tmparr);
for($i=0;$i<count($tmparr);$i++){
	$tmpuid=intval($tmparr[$i]);
	$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$tmpuid);
	if($username!=''){
		$userstr.=$username.'('.$tmpuid.') , ';
	}
}

if($userstr!=''){
	$userstr.='@';
	$userstr=str_replace(" , @","",$userstr);
}

echo '
<tr><td><textarea name="it618_pbuids" style="width:800px;height:280px;line-height:18px;font-size:13px;margin-bottom:3px">'.$it618_group_group['it618_pbuids'].'</textarea><br>'.$userstr.'</td></tr>
<tr><td style="color:red">'.$it618_group_lang['s397'].'</td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_group_getlang('s10').'" /></div></td></tr>';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>