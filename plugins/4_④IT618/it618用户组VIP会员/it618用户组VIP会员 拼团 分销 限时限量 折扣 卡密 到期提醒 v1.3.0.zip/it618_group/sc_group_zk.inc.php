<?php
 /**
 *	�����Ŷӣ�DisM.Taobao.Com
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';

$gid=intval($_GET['gid']);

$it618_group_group = C::t('#it618_group#it618_group_group')->fetch_by_id($gid);
$groupid=$it618_group_group['it618_groupid'];
$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$groupid);

$it618_video = $_G['cache']['plugin']['it618_video'];
$it618_exam = $_G['cache']['plugin']['it618_exam'];
$it618_brand = $_G['cache']['plugin']['it618_brand'];
$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
$it618_waimai = $_G['cache']['plugin']['it618_waimai'];

$videocss='';$examcss='';$brandcss='';$tuancss='';$waimaicss='';
if($_GET['shoptype']=='video'){$videocss='class="current"';$shoptype=$_GET['shoptype'];}
if($_GET['shoptype']=='exam'){$examcss='class="current"';$shoptype=$_GET['shoptype'];}
if($_GET['shoptype']=='brand'){$brandcss='class="current"';$shoptype=$_GET['shoptype'];}
if($_GET['shoptype']=='tuan'){$tuancss='class="current"';$shoptype=$_GET['shoptype'];}
if($_GET['shoptype']=='waimai'){$waimaicss='class="current"';$shoptype=$_GET['shoptype'];}

if($shoptype=='')exit;

if(submitcheck('it618submit')){
	
	$pids_array = !empty($_GET['it618_pids']) ? $_GET['it618_pids'] : array();
	foreach($pids_array as $key => $value) {
		if($it618_group_group_zk=C::t('#it618_group#it618_group_group_zk')->fetch_by_groupid_shoptype_pid($groupid,$shoptype,$key)){
			C::t('#it618_group#it618_group_group_zk')->update($it618_group_group_zk['id'],array(
				'it618_zk' => $value
			));
		}else{
			C::t('#it618_group#it618_group_group_zk')->insert(array(
				'it618_groupid' => $groupid,
				'it618_shoptype' => $shoptype,
				'it618_pid' => $key,
				'it618_zk' => $value
			), true);
		}
	}
	
	it618_cpmsg($it618_group_lang['s386'], "plugin.php?id=it618_group:sc_group_zk&gid=$gid&shoptype=$shoptype", 'succeed');
}

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:10px"><ul class="tab1" id="submenu">';

if($it618_video['seotitle']!=''){
	echo '<li '.$videocss.'><a href="'.$hosturl.'plugin.php?id=it618_group:sc_group_zk&gid='.$gid.'&shoptype=video"><span>'.$it618_group_lang['s381'].'</span></a></li>';
}
if($it618_exam['seotitle']!=''){
	echo '<li '.$examcss.'><a href="'.$hosturl.'plugin.php?id=it618_group:sc_group_zk&gid='.$gid.'&shoptype=exam"><span>'.$it618_group_lang['s382'].'</span></a></li>';
}
if($it618_brand['brand_name']!=''){
	echo '<li '.$brandcss.'><a href="'.$hosturl.'plugin.php?id=it618_group:sc_group_zk&gid='.$gid.'&shoptype=brand"><span>'.$it618_group_lang['s383'].'</span></a></li>';
}
if($it618_tuan['seotitle']!=''){
	echo '<li '.$tuancss.'><a href="'.$hosturl.'plugin.php?id=it618_group:sc_group_zk&gid='.$gid.'&shoptype=tuan"><span>'.$it618_group_lang['s384'].'</span></a></li>';
}
if($it618_waimai['waimai_name']!=''){
	echo '<li '.$waimaicss.'><a href="'.$hosturl.'plugin.php?id=it618_group:sc_group_zk&gid='.$gid.'&shoptype=waimai"><span>'.$it618_group_lang['s385'].'</span></a></li>';
}

echo '</ul></div>';

if($shoptype=='video'){
	require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_shop')." where it618_issale=1 and it618_state=2 and it618_htstate=1");
	while($tmpshop = DB::fetch($query)) {
		$it618_pids_strtmp='';
		
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_goods')." where it618_state=1 and it618_shopid=".$tmpshop['id']);
		while($tmpgoods = DB::fetch($query1)) {
			$it618_group_group_zk=C::t('#it618_group#it618_group_group_zk')->fetch_by_groupid_shoptype_pid($groupid,$shoptype,$tmpgoods['id']);
			
			$tmpurl=it618_video_getrewrite('video_product',$tmpgoods['id'],'plugin.php?id=it618_video:product&pid='.$tmpgoods['id']);
			
			$it618_pids_strtmp.='<li><span class="zkspan"><input type="text" class="txt shop'.$tmpshop['id'].'" name="it618_pids['.$tmpgoods['id'].']" style="width:58px;margin-right:3px" onclick="this.select()" value="'.$it618_group_group_zk['it618_zk'].'">%</span>['.$tmpgoods['id'].'] <a href="'.$tmpurl.'" target="_blank">'.$tmpgoods['it618_name'].'</a></li>';
		}
		
		if($it618_pids_strtmp!='')$it618_pids_str.='<div class="goodsdiv"><span class="zkspan"><input type="text" class="txt" id="shopzk'.$tmpshop['id'].'" name="it618_pids['.$tmpgoods['id'].']" style="width:58px;margin-right:3px" onclick="this.select()" value="">% <input type="button" class="btn" value="'.$it618_group_lang['s388'].'" onclick="editzk('.$tmpshop['id'].')"></span><span class="namespan">'.$tmpshop['it618_name'].'</span></div><ul class="goodsul">'.$it618_pids_strtmp.'</ul>';
	}
}

if($shoptype=='exam'){
	require_once DISCUZ_ROOT.'./source/plugin/it618_exam/function.func.php';
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_exam_shop')." where it618_state=2 and it618_htstate=1");
	while($tmpshop = DB::fetch($query)) {
		$it618_pids_strtmp='';
		
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_exam_goods')." where it618_gtype=1 and it618_state=1 and it618_shopid=".$tmpshop['id']);
		while($tmpgoods = DB::fetch($query1)) {
			$it618_group_group_zk=C::t('#it618_group#it618_group_group_zk')->fetch_by_groupid_shoptype_pid($groupid,$shoptype,$tmpgoods['id']);
			
			$tmpurl=it618_exam_getrewrite('exam_product',$tmpgoods['id'],'plugin.php?id=it618_exam:product&pid='.$tmpgoods['id']);
			
			$it618_pids_strtmp.='<li><span class="zkspan"><input type="text" class="txt shop'.$tmpshop['id'].'" name="it618_pids['.$tmpgoods['id'].']" style="width:58px;margin-right:3px" onclick="this.select()" value="'.$it618_group_group_zk['it618_zk'].'">%</span>['.$tmpgoods['id'].'] <a href="'.$tmpurl.'" target="_blank">'.$tmpgoods['it618_name'].'</a></li>';
		}
		
		if($it618_pids_strtmp!='')$it618_pids_str.='<div class="goodsdiv"><span class="zkspan"><input type="text" class="txt" id="shopzk'.$tmpshop['id'].'" name="it618_pids['.$tmpgoods['id'].']" style="width:58px;margin-right:3px" onclick="this.select()" value="">% <input type="button" class="btn" value="'.$it618_group_lang['s388'].'" onclick="editzk('.$tmpshop['id'].')"></span><span class="namespan">'.$tmpshop['it618_name'].'</span></div><ul class="goodsul">'.$it618_pids_strtmp.'</ul>';
	}
}

if($shoptype=='group'){
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_goods')." where it618_state=1");
	while($tmpgoods = DB::fetch($query)) {
		if($_GET['shoptype']=='group'){
			$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($tmpgoods['it618_groupid']);
			$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$tmpgoods['it618_groupid']);
			$it618_unit=it618_union_getvipgoodsunit($tmpgoods);
			$tmpgoods['it618_name']=$grouptitle.' '.$it618_unit;
		}
					
		$it618_pids_str.='<li><input type="checkbox" name="it618_pids['.$tmpgoods['id'].']" value="'.$tmpgoods['id'].'" style="vertical-align:middle"><label for="it618_pids'.$tmpgoods['id'].'">['.$tmpgoods['id'].'] <a href="'.$tmpurl.'" target="_blank">'.$tmpgoods['it618_name'].'</a></label></li>';
	}
}

if($shoptype=='brand'){
	require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brand')." where it618_state=2 and it618_htstate=1");
	while($tmpshop = DB::fetch($query)) {
		$it618_brand_brandgroup = C::t('#it618_brand#it618_brand_brandgroup')->fetch_by_id($tmpshop['it618_power']);
		if($it618_brand_brandgroup['it618_isgoods']==1){
					
			$it618_pids_strtmp='';
			
			$query1 = DB::query("SELECT * FROM ".DB::table('it618_brand_goods')." where it618_state=1 and it618_shopid=".$tmpshop['id']);
			while($tmpgoods = DB::fetch($query1)) {
				$it618_group_group_zk=C::t('#it618_group#it618_group_group_zk')->fetch_by_groupid_shoptype_pid($groupid,$shoptype,$tmpgoods['id']);
				
				$tmpurl=it618_brand_getrewrite('shop_product',$tmpgoods['it618_shopid'].'@'.$tmpgoods['id'],'plugin.php?id=it618_brand:product&sid='.$tmpgoods['it618_shopid'].'&pid='.$tmpgoods['id']);
				
				$it618_pids_strtmp.='<li><span class="zkspan"><input type="text" class="txt shop'.$tmpshop['id'].'" name="it618_pids['.$tmpgoods['id'].']" style="width:58px;margin-right:3px" onclick="this.select()" value="'.$it618_group_group_zk['it618_zk'].'">%</span>['.$tmpgoods['id'].'] <a href="'.$tmpurl.'" target="_blank">'.$tmpgoods['it618_name'].'</a></li>';
			}
			
			if($it618_pids_strtmp!='')$it618_pids_str.='<div class="goodsdiv"><span class="zkspan"><input type="text" class="txt" id="shopzk'.$tmpshop['id'].'" name="it618_pids['.$tmpgoods['id'].']" style="width:58px;margin-right:3px" onclick="this.select()" value="">% <input type="button" class="btn" value="'.$it618_group_lang['s388'].'" onclick="editzk('.$tmpshop['id'].')"></span><span class="namespan">'.$tmpshop['it618_name'].'</span></div><ul class="goodsul">'.$it618_pids_strtmp.'</ul>';
		}

	}
}

if($shoptype=='tuan'){
	require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_shop')." where it618_state=2 and it618_htstate=1");
	while($tmpshop = DB::fetch($query)) {
		$it618_pids_strtmp='';
		
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_tuan_goods')." where it618_type=1 and it618_state=1 and it618_shopid=".$tmpshop['id']);
		while($tmpgoods = DB::fetch($query1)) {
			$it618_group_group_zk=C::t('#it618_group#it618_group_group_zk')->fetch_by_groupid_shoptype_pid($groupid,$shoptype,$tmpgoods['id']);
			
			$tmpurl=it618_tuan_getrewrite('tuan_product',$tmpgoods['id'],'plugin.php?id=it618_tuan:product&pid='.$tmpgoods['id']);
			
			$it618_pids_strtmp.='<li><span class="zkspan"><input type="text" class="txt shop'.$tmpshop['id'].'" name="it618_pids['.$tmpgoods['id'].']" style="width:58px;margin-right:3px" onclick="this.select()" value="'.$it618_group_group_zk['it618_zk'].'">%</span>['.$tmpgoods['id'].'] <a href="'.$tmpurl.'" target="_blank">'.$tmpgoods['it618_name'].'</a></li>';
		}
		
		if($it618_pids_strtmp!='')$it618_pids_str.='<div class="goodsdiv"><span class="zkspan"><input type="text" class="txt" id="shopzk'.$tmpshop['id'].'" name="it618_pids['.$tmpgoods['id'].']" style="width:58px;margin-right:3px" onclick="this.select()" value="">% <input type="button" class="btn" value="'.$it618_group_lang['s388'].'" onclick="editzk('.$tmpshop['id'].')"></span><span class="namespan">'.$tmpshop['it618_name'].'</span></div><ul class="goodsul">'.$it618_pids_strtmp.'</ul>';
	}
}

if($shoptype=='waimai'){
	$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimai')." where it618_state=2 and it618_htstate=1");
	while($tmpshop = DB::fetch($query)) {
	
		$it618_pids_strtmp='';
		
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_waimai_goods')." where it618_ison=1 and it618_shopid=".$tmpshop['id']);
		while($tmpgoods = DB::fetch($query1)) {
			$it618_group_group_zk=C::t('#it618_group#it618_group_group_zk')->fetch_by_groupid_shoptype_pid($groupid,$shoptype,$tmpgoods['id']);
			$it618_pids_strtmp.='<li><span class="zkspan"><input type="text" class="txt shop'.$tmpshop['id'].'" name="it618_pids['.$tmpgoods['id'].']" style="width:58px;margin-right:3px" onclick="this.select()" value="'.$it618_group_group_zk['it618_zk'].'">%</span>['.$tmpgoods['id'].'] <a href="'.$tmpurl.'" target="_blank">'.$tmpgoods['it618_name'].'</a></li>';
		}
		
		if($it618_pids_strtmp!='')$it618_pids_str.='<div class="goodsdiv"><span class="zkspan"><input type="text" class="txt" id="shopzk'.$tmpshop['id'].'" name="it618_pids['.$tmpgoods['id'].']" style="width:58px;margin-right:3px" onclick="this.select()" value="">% <input type="button" class="btn" value="'.$it618_group_lang['s388'].'" onclick="editzk('.$tmpshop['id'].')"></span><span class="namespan">'.$tmpshop['it618_name'].'</span></div><ul class="goodsul">'.$it618_pids_strtmp.'</ul>';

	}
}

it618_showformheader("plugin.php?id=it618_group:sc_group_zk&gid=$gid&shoptype=$shoptype");
showtableheaders($grouptitle.'<span style="font-weight:normal;float:right;color:red">'.$it618_group_lang['s387'].'</span>','sc_group_zk');

echo '
<style>
.goodsdiv{float:left;width:100%;padding:10px 0px}
.goodsdiv .namespan{font-size:15px;font-weight:bold;color:#000;}
.goodsdiv .zkspan{float:right;margin-right:6px}
.goodsdiv .zkspan .txt{text-align:center;color:red}
.goodsul{float:left;width:99%;background-color:#f1f1f1;padding:10px;padding-right:0}
.goodsul li{float:left;width:50%;padding-top:5px;padding-bottom:5px}
.goodsul li .zkspan{float:right;margin-right:15px}
.goodsul li .zkspan .txt{text-align:center;color:red}
</style>
<script charset="utf-8" src="source/plugin/it618_group/js/jquery.js"></script>

<script>
function editzk(shopid){
	IT618_GROUP(".shop"+shopid).val(IT618_GROUP("#shopzk"+shopid).val());
}
</script>

<tr><td>'.$it618_pids_str.'</td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_group_getlang('s10').'" /></div></td></tr>';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>