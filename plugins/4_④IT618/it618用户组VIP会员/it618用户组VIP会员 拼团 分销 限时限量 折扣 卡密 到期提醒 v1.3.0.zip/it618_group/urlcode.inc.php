<?php
 /**
 *	�����Ŷӣ�DisM.Taobao.Com
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;

$tmparr=explode($_G['siteurl'],$_GET['url']);
if(count($tmparr)==1)exit;

include DISCUZ_ROOT.'./source/plugin/it618_group/phpqrcode.php';

$url=urldecode($_GET['url']);
$tmparr=explode("&q=",$url);
if(count($tmparr)>1){
	$url=$tmparr[0].'&q='.urlencode($tmparr[1]);
}

$errorCorrectionLevel = 'L';//�ݴ����� 
$matrixPointSize = 6;//����ͼƬ��С  
QRcode::png($url, false, $errorCorrectionLevel, $matrixPointSize, 2); 
?>