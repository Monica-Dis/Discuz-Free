<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';


if($_GET['ac']=="groupad"){
	$aid=intval($_GET['aid']);
	$wap=intval($_GET['wap']);
	$it618_group_ad=C::t('#it618_group#it618_group_ad')->fetch_by_id($aid);
	
	dsetcookie('it618_groupad_'.$aid,$_G['timestamp'],$it618_group_ad['it618_cookiestime']*60);
	echo 'ok';exit;
}

if($_GET['formhash']!=FORMHASH)exit;

$uid=$_G['uid'];


if($_GET['ac']=="getpay"){
	if($uid>0){
		$pid=intval($_GET['pid']);
		$it618_count=intval($_GET['it618_count']);
		
		$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($pid);
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
		
		if($it618_group_group['it618_xgzk']>0){
			$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
			$groupterms = dunserialize($memberfieldforum['groupterms']);
			unset($memberfieldforum);
			if(!empty($groupterms['ext'])) {
				foreach($groupterms['ext'] as $extgroupid => $time) {
					if($it618_group_goods['it618_groupid']==$extgroupid){
						if($time-3600*24*365*60>$_G['timestamp']){
							$iszk=1;
							$grouptime=$it618_group_lang['s64'];
						}else{
							$grouptime=dgmdate($time, 'd');
							if($time>$_G['timestamp']){
								$iszk=1;	
							}
						}
						break;
					}
				}
			}
		}
		
		$xgzk=1;
		if($iszk==1){
			$xgzk=$it618_group_group['it618_xgzk']/100;
		}
		
		$goods_price=$it618_group_goods['it618_saleprice'];
		$goods_jfid=$it618_group_goods['it618_jfid'];
		$goods_score=$it618_group_goods['it618_score'];
		
		$yfmoney=round($goods_price*$it618_count*$xgzk,2);
		if($goods_score>0){
			$goodsjfname=$_G['setting']['extcredits'][$goods_jfid]['title'];
			$sumscore[$goods_jfid]+=intval($goods_score*$it618_count*$xgzk);
		}
		
		if($it618_group_goods['it618_jfbl']>0&&$goods_price>0){
			$jfbl='<font color=#888>'.it618_group_getlang('s144').'<font color=red>'.$it618_group_goods['it618_jfbl'].'%</font> '.$creditname.'</font>';
		}
		
		for($i=1;$i<=8;$i++){
			if($sumscore[$i]>0){
				$jfname=$_G['setting']['extcredits'][$i]['title'];
				
				$scorestr.=$sumscore[$i].$jfname.' + ';
				
				$creditnum=C::t('#it618_group#it618_group_sale')->fetch_extcredits_by_uid($i,$_G['uid']);
				if($creditnum=="")$creditnum=0;
				$jfcounttmp.='<font color="red">'.$creditnum.'</font>'.$jfname;
			}
		}
		
		$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
		$groupterms = dunserialize($memberfieldforum['groupterms']);
		unset($memberfieldforum);
		
		if($scorestr!=''){
			$scorestr.='@';
			$scorestr=str_replace(' + @',"",$scorestr);
			
			$jfcountstr=$it618_group_lang['s143'].' '.$jfcounttmp;
		}
		
		if($yfmoney>0&&$scorestr!=''){
			$yfmoneystr='<input type="hidden" id="yfmoneyvalue" value="'.$yfmoney.'"><em>&yen;</em><span id="yfmoney">'.$yfmoney.'</span>'.' + '.$scorestr;
			$moneyscore=1;
		}else{
			if($yfmoney>=0){
				$yfmoneystr='<input type="hidden" id="yfmoneyvalue" value="'.$yfmoney.'"><em>&yen;</em><span id="yfmoney">'.$yfmoney.'</span>';
			}
			if($scorestr!=''){
				$yfmoneystr=$scorestr;
			}
		}
		
		if($yfmoney>0){
			if($_GET['wap']==1){
				$it618paystr=it618_group_pay('paywap',$it618_group_lang['s145']);
			}else{
				$it618paystr=it618_group_pay('pay',$it618_group_lang['s145']);
			}
		}
		
		if($IsUnion==1){
			$isquanstr=1;
			if($yfmoney>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
				
				$quanstr=it618_union_getquansale('group',$it618_group_goods['it618_shopid'],$_GET['wap'],$it618_group_goods['id'],$yfmoney);
				$tmparr=explode("<select",$quanstr);
				if(count($tmparr)==1){
					$isquanstr=0;
				}
			}else{
				$quanstr='<input type="hidden" id="quanid" value="0">';
				$isquanstr=0;
			}
		}
		
		if($isquanstr==1){
			if($_GET['wap']==1){
				$getpaystr.='
				<tr>
				<td>'.$it618_group_lang['s146'].'</td>
				<td>
				'.$quanstr.'
				</td>
				</tr>';
			}else{
				$getpaystr.='
				<tr>
				<td>'.$it618_group_lang['s146'].'</td>
				<td>
				'.$quanstr.'
				</td>
				</tr>';
			}
		}else{
			$getpaystr.='
				<tr style="display:none">
				<td></td>
				<td>
				'.$quanstr.'
				</td>
				</tr>';
		}
		
		if($yfmoneystr!=''){
			if($_GET['wap']==1){
				$getpaystr.='
				<tr>
				<td width="68">'.$it618_group_lang['s147'].'</td>
				<td class="tdyfmoney">
				<span class="yfmoney">'.$yfmoneystr.'</span><input type="hidden" id="moneyscore" value="'.$moneyscore.'" />
				<div>'.$jfbl.$jfcountstr.'</div>
				</td>
				</tr>';
			}else{
				$getpaystr.='
				<tr>
				<td width="80">'.$it618_group_lang['s147'].'</td>
				<td class="tdyfmoney">
				<span style="float:right">'.$jfbl.$jfcountstr.'</span><span class="yfmoney">'.$yfmoneystr.'</span><input type="hidden" id="moneyscore" value="'.$moneyscore.'" />
				</td>
				</tr>';
			}
		}
		
		echo 'it618_splitokit618_split'.$getpaystr.$it618paystr;
	}
	exit;
}


if($_GET['ac']=="pay_add"){
	if($uid<=0){
		echo it618_group_getlang('s154');
	}else{
		set_time_limit (0);
		ignore_user_abort(true);

		if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
		
		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_group_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_group_delsalework();
			}
		}
		C::t('#it618_group#it618_group_salework')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$pid=intval($_GET['pid']);
		$it618_jfid=intval($_GET['it618_jfid']);
		$it618_count=intval($_GET['it618_count']);
		$it618_isswitch=intval($_GET['it618_isswitch']);
		
		if($IsUnion==1&&$_GET['tuijcode']!=''){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
			$it618_tuijid=Union_IsTuiJoin('group',$pid,$_GET['tuijcode']);
		}
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		if($it618_count<=0){
			echo it618_group_getlang('s155');it618_group_delsalework();exit;
		}
		
		if(!($it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id_state($pid,1))){
			echo it618_group_getlang('s141');it618_group_delsalework();exit;
		}
		
		$goods_count=$it618_group_goods['it618_count'];
		$goods_price=$it618_group_goods['it618_saleprice'];
		$goods_jfid=$it618_group_goods['it618_jfid'];
		$goods_score=$it618_group_goods['it618_score'];
		
		if($it618_group_goods['it618_counttype']==1){
			if($goods_count<$it618_count){
				echo it618_group_getlang('s328');it618_group_delsalework();exit;
			}
			
			if($it618_group_goods['it618_xgcount']>0){
				$countstr=$it618_group_lang['s216'];
				$countstr=str_replace("{xgcount}",$it618_group_goods['it618_xgcount'],$countstr);
				
				$tomonth = date('n'); 
				$todate = date('j'); 
				$toyear = date('Y');
				$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
				$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_group_sale')." where it618_pid=".$it618_group_goods['id']." and it618_time>$time and it618_state=1");
				
				if($it618_group_goods['it618_xgcount']-$buycount<$it618_count){		
					echo $countstr;it618_group_delsalework();exit;
				}
			}
		}
		
		if($it618_group_goods['it618_xgtype']==1){
			
			$timetmp1=explode(" ",$it618_group_goods['it618_xgtime1']);
			$timetmp2=explode(" ",$it618_group_goods['it618_xgtime2']);
			$timetmp11=explode("-",$timetmp1[0]);
			$timetmp12=explode(":",$timetmp1[1]);
			$timetmp21=explode("-",$timetmp2[0]);
			$timetmp22=explode(":",$timetmp2[1]);
			
			
			$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
			$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
			
			if($etime<$_G['timestamp']){
				echo $it618_group_lang['s156'];it618_group_delsalework();exit;
			}else{
				if($btime>$_G['timestamp']){
					echo $it618_group_lang['s157'];it618_group_delsalework();exit;
				}
			}
		}
		
		if($it618_group_goods['it618_xgtype']==2){
			$timetmp1=explode(" ",$it618_group_goods['it618_xgtime1']);
			$timetmp2=explode(" ",$it618_group_goods['it618_xgtime2']);
			$timetmp11=explode("-",$timetmp1[0]);
			$timetmp12=explode(":",$timetmp1[1]);
			$timetmp21=explode("-",$timetmp2[0]);
			$timetmp22=explode(":",$timetmp2[1]);
			
			$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
			$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
			
			if($etime<$_G['timestamp']){
				echo $it618_group_lang['s156'];it618_group_delsalework();exit;
				
			}else{
				if($btime>$_G['timestamp']){
					echo $it618_group_lang['s157'];it618_group_delsalework();exit;
				}else{
					$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
					$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
					$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
					
					if($btimecur>$_G['timestamp']){
						echo $it618_group_lang['s157'];it618_group_delsalework();exit;
					}
					
					if($etimecur<$_G['timestamp']){
						echo $it618_group_lang['s157'];it618_group_delsalework();exit;
					}
				}
			}
		}

		if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
		
		if($it618_group_group['it618_pbuids']!=''){
			$pbuidsarr=explode(",",$it618_group_group['it618_pbuids']);
			if(in_array($uid,$pbuidsarr)){
				echo $it618_group_lang['s398'];it618_group_delsalework();exit;
			}
		}
		
		if($it618_group_group['it618_xgzk']>0){
			$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
			$groupterms = dunserialize($memberfieldforum['groupterms']);
			unset($memberfieldforum);
			if(!empty($groupterms['ext'])) {
				foreach($groupterms['ext'] as $extgroupid => $time) {
					if($it618_group_goods['it618_groupid']==$extgroupid){
						if($time-3600*24*365*60>$_G['timestamp']){
							$iszk=1;
							$grouptime=$it618_group_lang['s64'];
						}else{
							$grouptime=dgmdate($time, 'd');
							if($time>$_G['timestamp']){
								$iszk=1;	
							}
						}
						break;
					}
				}
			}
		}
		
		$xgzk=1;
		if($iszk==1){
			$it618_xgzk=$it618_group_group['it618_xgzk'];
			$xgzk=$it618_group_group['it618_xgzk']/100;
		}
		
		$yfmoney=round($goods_price*$it618_count*$xgzk,2);
		
		if($goods_score>0){
			$goodsjfname=$_G['setting']['extcredits'][$goods_jfid]['title'];
			$yfscore=intval($goods_score*$it618_count*$xgzk);

			$creditnum=DB::result_first("select extcredits".$goods_jfid." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
			if($creditnum<$yfscore){
				echo it618_group_getlang('s158').$creditnum.$goodsjfname.it618_group_getlang('s159');it618_group_delsalework();exit;
			}
		}
		
		$quanid=intval($_GET['quanid']);
		if($quanid>0){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
			$it618_union_quansale = C::t('#it618_union#it618_union_quansale')->fetch_by_id($quanid);
			if(it618_union_getisokquan($it618_union_quansale,$it618_group_goods['id'],$yfmoney)==''){
				echo $it618_union_lang['s319'];it618_group_delsalework();exit;
			}
			$it618_quanmoney=it618_union_getquantype($it618_union_quansale,'quanmoney');
			if($yfmoney<$it618_quanmoney){
				$it618_quanmoney=$yfmoney;
			}
			$yfmoney=$yfmoney-$it618_quanmoney;
		}
		
		if($yfmoney>0){
			if($_GET['paytype']==""){
				echo it618_group_getlang('s1069');it618_group_delsalework();exit;
			}
			
			$it618_state=0;
		}else{
			$it618_state=1;
		}
		
		$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
		$groupterms = dunserialize($memberfieldforum['groupterms']);
		unset($memberfieldforum);
		
		if(!empty($groupterms['ext'])) {
			foreach($groupterms['ext'] as $extgroupid => $time) {
				if($it618_group_goods['it618_groupid']==$extgroupid){
					if($time-3600*24*365*60>$_G['timestamp']){
						echo it618_group_getlang('s181');it618_group_delsalework();exit;
					}
					break;
				}
			}
		}
		
		if($ii1i11i[9]!='u')exit;
		$tmptime=$_G['timestamp'];
		$id = C::t('#it618_group#it618_group_sale')->insert(array(
			'it618_uid' => $uid,
			'it618_pid' => $pid,
			'it618_groupid' => $it618_group_goods['it618_groupid'],
			'it618_unitcount' => $it618_group_goods['it618_unitcount'],
			'it618_unit' => $it618_group_goods['it618_unit'],
			'it618_tuijid' => $it618_tuijid,
			'it618_count' => $it618_count,
			'it618_xgzk' => $it618_xgzk,
			'it618_price' => $goods_price,
			'it618_jfid' => $goods_jfid,
			'it618_score' => $goods_score,
			'it618_sfscore' => $yfscore,
			'it618_quanmoney' => $it618_quanmoney,
			'it618_sfmoney' => $yfmoney,
			'it618_jfbl' => $it618_group_goods['it618_jfbl'],
			'it618_tel' => '1',
			'it618_isswitch' => $it618_isswitch,
			'it618_state' => $it618_state,
			'it618_time' => $tmptime
		), true);

		if($id>0){
			if($yfscore>0){
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$goods_jfid => (0-$yfscore))
				);
			}
			
			if($quanid>0){
				DB::query("update ".DB::table('it618_union_quansale')." set it618_saleid=$id,it618_usetime=$tmptime,it618_state=1 where id=".$quanid);
			}
			
			if($yfmoney==0){
				if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
				if($it618_tuijid>0){
					require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
					Union_TuiTC_Add($it618_tuijid,$id);
				}
				$it618_group_sale = C::t('#it618_group#it618_group_sale')->fetch_by_id($id);
				it618_group_updategoodscount($it618_group_sale);
				it618_group_qrxf($id);
				
				echo 'it618_splitjfokit618_split';it618_group_delsalework();exit;	
			}
			
			$saletype='0901';
			$saleid=$id;
			$out_trade_no = date("YmdHis").$saletype.$saleid;
			
			
			$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
			$it618_unit=it618_group_getgoodsunit($it618_group_goods);
			
			$body=$it618_unit.$grouptitle;
			
			$total_fee=$yfmoney;
			
			if(group_is_mobile()){ 
				$wap=1;
				$url=$_G['siteurl'].it618_group_getrewrite('group_wap','product@'.$pid,'plugin.php?id=it618_group:wap&pagetype=product&cid1='.$pid);
			}else{
				$wap=0;
				$url=$_G['siteurl'].it618_group_getrewrite('group_product',$pid,'plugin.php?id=it618_group:product&pid='.$pid);
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
			$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
			$tmparr=explode("it618_split",$domainurl_paytype);
			$domainurl=$tmparr[0];
			$paytype=$tmparr[1];

			C::t('#it618_credits#it618_credits_salepay')->insert(array(
				'it618_out_trade_no' => $out_trade_no,
				'it618_uid' => $uid,
				'it618_saletype' => $saletype,
				'it618_saleid' => $saleid,
				'it618_paytype' => $paytype,
				'it618_url' => $url,
				'it618_body' => $body,
				'it618_total_fee' => round($total_fee,2),
				'it618_plugin' => 'it618_group',
				'it618_wap' => $wap,
				'it618_state' => 0,
				'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
				'it618_time' => $_G['timestamp']
			), true);
		
			$ajaxpay=$domainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
			
			
			echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype;it618_group_delsalework();
		}else{
			echo it618_group_getlang('s25');it618_group_delsalework();exit;
		}
	}
	exit;
}


if($_GET['ac']=="readkm"){
	if($it618_group_goods_km = C::t('#it618_group#it618_group_goods_km')->fetch_by_it618_code($_GET['kmcode'])){
		if($it618_group_goods_km['it618_etime']==0){
			$it618_etime=$it618_group_lang['s296'];
		}else{
			$it618_etime=date('Y-m-d H:i:s', $it618_group_goods_km['it618_etime']);
		}
		
		if($it618_group_goods_km['it618_xgtime']>0){
			$it618_xgtime='<font color=red>'.$it618_group_goods_km['it618_xgtime'].'</font>'.$it618_group_lang['s300'];
		}else{
			$it618_xgtime=$it618_group_lang['s301'];
		}
		
		$it618_group_goods=C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_goods_km['it618_pid']);
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
		
		$it618_unit=it618_group_getgoodsunit($it618_group_goods);

		echo "<font color=#999>".$it618_group_lang['s298'].'<img src="'.$it618_group_group['it618_ico'].'" style="vertical-align:middle;margin-top:-3px;margin-right:3px;width:18px">'."<font color=red>".$grouptitle.' '.$it618_unit.'</font> '.$it618_group_lang['s299'].'<font color=green>'.$it618_xgtime.'</font> '.$it618_group_lang['s297'].'<font color=green>'.$it618_etime.'</font></font>';
	}else{
		echo '<font color=red>'.$it618_group_lang['s295'].'</font>';
	}
	exit;
}


if($_GET['ac']=="salekm"){	
	if($it618_group_goods_km = C::t('#it618_group#it618_group_goods_km')->fetch_by_it618_code($_GET['kmcode'])){
		
		if($it618_group_goods_km['it618_etime']>0&&$it618_group_goods_km['it618_etime']<$_G['timestamp']){
			echo $it618_group_lang['s305'];exit;
		}
		
		if($it618_group_goods_km['it618_xgtime']>0){
			$time=$_G['timestamp']-$it618_group_goods_km['it618_xgtime']*3600*24;
			$buycount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_group_salekm')." where it618_pid=".$it618_group_goods_km['it618_pid']." and it618_time>$time and it618_uid=".$uid);
			if($buycount>0){
				echo $it618_group_lang['s302'].$it618_group_goods_km['it618_xgtime'].$it618_group_lang['s303'].$buycount.$it618_group_lang['s304'];exit;
			}
		}
		
		$it618_group_goods=C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_goods_km['it618_pid']);
		
		$memberfieldforum = C::t('common_member_field_forum')->fetch($uid);
		$groupterms = dunserialize($memberfieldforum['groupterms']);
		unset($memberfieldforum);
		
		if(!empty($groupterms['ext'])) {
			foreach($groupterms['ext'] as $extgroupid => $time) {
				if($it618_group_goods['it618_groupid']==$extgroupid){
					if($time-3600*24*365*60>$_G['timestamp']){
						echo it618_group_getlang('s307');exit;
					}
					break;
				}
			}
		}
		
		$tmptime=$_G['timestamp'];
		$id = C::t('#it618_group#it618_group_salekm')->insert(array(
			'it618_uid' => $uid,
			'it618_pid' => $it618_group_goods_km['it618_pid'],
			'it618_code' => $it618_group_goods_km['it618_code'],
			'it618_bz' => $it618_group_goods_km['it618_bz'],
			'it618_xgtime' => $it618_group_goods_km['it618_xgtime'],
			'it618_etime' => $it618_group_goods_km['it618_etime'],
			'it618_addtime' => $it618_group_goods_km['it618_addtime'],
			'it618_groupid' => $it618_group_goods['it618_groupid'],
			'it618_unitcount' => $it618_group_goods['it618_unitcount'],
			'it618_unit' => $it618_group_goods['it618_unit'],
			'it618_time' => $tmptime
		), true);
		
		if($it618_group_goods_km['it618_usedel']==1){
			C::t('#it618_group#it618_group_goods_km')->delete_by_id($it618_group_goods_km['id']);
		}
		
		$groupid=$it618_group_goods['it618_groupid'];
			
		$extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
		
		require_once libfile('function/forum');
		
		$extgroupidsarray = array();
		foreach(array_unique(array_merge($extgroupids, array($groupid))) as $extgroupid) {
			if($extgroupid) {
				$extgroupidsarray[] = $extgroupid;
			}
		}
		
		$it618_unitcount=$it618_group_goods['it618_unitcount'];
		$it618_unit=$it618_group_goods['it618_unit'];
		$it618_count=1;
		
		if($it618_unit==1)$it618_days=$it618_unitcount*$it618_count;
		if($it618_unit==2)$it618_days=$it618_unitcount*$it618_count*30;
		if($it618_unit==3)$it618_days=$it618_unitcount*$it618_count*90;
		if($it618_unit==4)$it618_days=$it618_unitcount*$it618_count*365;
		if($it618_unit==5)$it618_days=$it618_count*365*90;
		
		$groupterms['ext'][$groupid] = ($groupterms['ext'][$groupid] > TIMESTAMP ? $groupterms['ext'][$groupid] : TIMESTAMP) + $it618_days * 86400;
	
		$grouptermsnew = serialize($groupterms);
		$groupexpirynew = groupexpiry($groupterms);
		$extgroupidsnew = implode("\t", $extgroupidsarray);
	
		C::t('common_member')->update($uid, array('extgroupids'=>$extgroupidsnew, 'groupexpiry'=>$groupexpirynew));
		if(C::t('common_member_field_forum')->fetch($uid)) {
			C::t('common_member_field_forum')->update($uid, array('groupterms' => $grouptermsnew));
		} else {
			C::t('common_member_field_forum')->insert(array('uid' => $uid, 'groupterms' => $grouptermsnew));
		}
		
		echo 'it618_splitokit618_split'.$it618_group_lang['s306'];exit;
	}else{
		echo '<font color=red>'.$it618_group_lang['s295'].'</font>';exit;
	}
}


if($_GET['ac']=="group_switch"){
	if($uid<=0){
		echo $it618_group_lang['s179'];
	}else{
		$groupid = intval($_GET['groupid']);
		$extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
		$tmpgrouparr = array();
		$tmpgrouparr[] = $groupid;
		$okvipgroupids=it618_group_getisvipuser($tmpgrouparr);
		if(count($okvipgroupids[0])==0){
			$common_usergrouptmp = DB::fetch_first("SELECT groupid,grouptitle FROM ".DB::table('common_usergroup')." WHERE type='member' AND creditshigher<=".$_G['member']['credits']." AND creditslower>=".$_G['member']['credits']." LIMIT 1");
			if($groupid!=$common_usergrouptmp['groupid']){
				echo $it618_group_lang['s597'];exit;
			}else{
				if($_G['adminid']>0){
					echo $it618_group_lang['s597'];exit;
				}
			}
		}
		if($_G['groupid'] == 4 && $_G['member']['groupexpiry'] > 0 && $_G['member']['groupexpiry'] > TIMESTAMP) {
			echo $it618_group_lang['s597'];exit;
		}
		
		$group = C::t('common_usergroup')->fetch($groupid);
		
		if($_G['adminid'] > 0 && $group['radminid'] > 0) {
			$newadminid = $_G['adminid'] < $group['radminid'] ? $_G['adminid'] : $group['radminid'];
		} elseif($_G['adminid'] > 0) {
			$newadminid = $_G['adminid'];
		} else {
			$newadminid = $group['radminid'];
		}

		$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
		$groupterms = dunserialize($memberfieldforum['groupterms']);
		unset($memberfieldforum);
		$extgroupidsnew = $_G['groupid'];
		$groupexpirynew = $groupterms['ext'][$extgroupidsnew];
		foreach($extgroupids as $extgroupid) {
			if($extgroupid && $extgroupid != $groupid) {
				$extgroupidsnew .= "\t".$extgroupid;
			}
		}

		C::t('common_member')->update($_G['uid'], array('groupid' => $groupid, 'adminid' => $newadminid, 'groupexpiry' => $groupexpirynew, 'extgroupids' => $extgroupidsnew));
		
		echo 'it618_splitokit618_split'.$it618_group_lang['s183'];
	}
	exit;
}


if($_GET['ac']=="getunames"){
	$it618_groupid=$_GET['it618_groupid'];
	$tmparr=explode(",",$_GET['it618_uids']);
	$tmparr=array_unique($tmparr);
	for($i=0;$i<count($tmparr);$i++){
		$tmpuid=intval($tmparr[$i]);
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$tmpuid);
		if($username!=''){
			$memberfieldforum = C::t('common_member_field_forum')->fetch($tmpuid);
			$groupterms = dunserialize($memberfieldforum['groupterms']);
			unset($memberfieldforum);
			
			$grouptime=$it618_group_lang['s379'];	
			if(!empty($groupterms['ext'])) {
				foreach($groupterms['ext'] as $extgroupid => $time) {
					if($it618_groupid==$extgroupid){
						if($time-3600*24*365*60>$_G['timestamp']){
							$grouptime=$it618_group_lang['s64'];
						}else{
							$grouptime=dgmdate($time, 'd');
							if($time<$_G['timestamp']){
								$grouptime='<del>'.$grouptime.'</del>';	
							}
						}
						break;
					}
				}
			}
			
			$userstr.=$username.'('.$tmpuid.' / '.$grouptime.') , ';
			$uidstr.=$tmpuid.',';
		}
	}
	
	if($uidstr!=''){
		$userstr.='@';
		$userstr=str_replace(" , @","",$userstr);
		$uidstr.='@';
		$uidstr=str_replace(",@","",$uidstr);
	}
	echo $uidstr.'it618_split<br>'.$userstr;exit;
}


if($_GET['ac']=="goodssalelist_get"){
	if($_GET['wap']==0)$ppp = 20;
	if($_GET['wap']==1)$ppp = 15;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	
	$pid=intval($_GET['it618_pid']);
	foreach(C::t('#it618_group#it618_group_sale')->fetch_all_by_it618_pid(
		$pid,$startlimit,$ppp
	) as $it618_group_sale) {
		if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
	
		$username=it618_group_getusername($it618_group_sale['it618_uid']);
		
		$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_sale['it618_pid']);
		
		$buyuser=$username;
		
		if($it618_group_goods['it618_isbm']==1){
			if($_G['uid']!=$it618_group_sale['it618_uid'])$buyuser=cutstr($username, 2, '').'***';
		}
		if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
		
		if($_GET['wap']==0){

			$salelist_get.='<tr>
						<td>'.$buyuser.'</td>
						<td>'.$it618_group_sale['it618_count'].'</td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_group_sale['it618_time']).'</font></td>
						</tr>';
		}else{
			$buyuser=str_replace("<a","<a style='color:#888;'",$buyuser);
			
			$salelist_get.='<tr>
						<td style="wtext-align:left;">'.$buyuser.'</td>
						<td style="text-align:center;">'.$it618_group_sale['it618_count'].'</td>
						<td align="right"><font color=#999>'.date('Y-m-d H:i', $it618_group_sale['it618_time']).'</font></td>
						</tr>
						';
		}
	}
	
	$count = C::t('#it618_group#it618_group_sale')->count_by_it618_pid($pid);
	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_group:ajax&it618_pid=".$pid);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getsalelist(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
		
		if($multipage!='')$multipage='<div class="pjpage">'.$multipage.'</div>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="getsalelist(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_group_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&sid=$ShopId&it618_pid=".$pid.'&page=2';
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_group_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_group_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_group_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_group_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_group_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_group_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}

	}
	
	echo $salelist_get."it618_split".$multipage;
	exit;
}

if($_GET['ac']=="salelist_get"){
	if($_GET['ac1']=='pcmysale')$ppp = 10;
	if($_GET['ac1']=='wapmysale')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;

	if($_GET['ac1']=='pcmysale'||$_GET['ac1']=='wapmysale'){		
		$it618_group_sales=C::t('#it618_group#it618_group_sale')->fetch_all_by_search("s.it618_state!=0 ".$it618sql,'s.id desc',$_GET['classid'],$_GET['groupid'],$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
		$count=C::t('#it618_group#it618_group_sale')->count_by_search("s.it618_state!=0 ".$it618sql,'s.id desc',$_GET['classid'],$_GET['groupid'],$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$money=C::t('#it618_group#it618_group_sale')->sum_money_by_search("s.it618_state!=0 ".$it618sql,'s.id desc',$_GET['classid'],$_GET['groupid'],$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$funname='getmysalelist';
	}

	$n=0;
	foreach($it618_group_sales as $it618_group_sale) {
		if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_sale['it618_pid']);

		$jftmp='';
		if($it618_group_sale['it618_jfbl']>0&&$it618_group_sale['it618_price']>0){
			$it618_jfbl=intval($it618_group_sale['it618_jfbl']*$it618_group_sale['it618_price']/100);
			$jftmp=$it618_jfbl.$creditname;
		}
		
		$pricestr=it618_group_getsalemoney($it618_group_sale);
		
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
		
		$it618_unit=it618_group_getgoodsunit($it618_group_goods);

		if($_GET['ac1']=='pcmysale'){
			$tmpurl=it618_group_getrewrite('group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id']);
			
			$salelist_get.='<tr class="hover">
						<td style="padding-top:8px; padding-bottom:8px">'.$it618_group_sale['id'].'</td>
						<td class="tdgroup"><a href="'.$tmpurl.'" target="_blank"><img src="'.$it618_group_group['it618_ico'].'"/>'.$grouptitle.'</a></td>
						<td style="text-align:center">'.$it618_unit.'*'.$it618_group_sale['it618_count'].'</td>
						<td style="text-align:center">'.$pricestr.'</td>
						<td style="text-align:center">'.$jftmp.'</td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_group_sale['it618_time']).'</font></td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmysale'){
			
			if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
			
			if($jftmp!=''){
				$jftmp=' <font color=#999>'.$it618_group_lang['s188'].':'.$jftmp.'</font>';
			}
			
			$tmpurl=it618_group_getrewrite('group_wap','product@'.$it618_group_goods['id'],'plugin.php?id=it618_group:wap&pagetype=product&cid1='.$it618_group_goods['id']);
					
			$salelist_get.='<tr><td style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="60" style="vertical-align:top;border:none">
							<a href="'.$tmpurl.'"><img src="'.$it618_group_group['it618_ico'].'" width="48" height="48" style="border-radius: 3px;"/></a>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a class="name" href="'.$tmpurl.'" target="_blank" style="font-size:14px;color:#333">'.$grouptitle.'</a><br>
							<font color="#888">'.$pricestr.'</font> <font color="#999">'.$jftmp.'</font><br>
							<font color=#ccc>'.date('Y-m-d H:i:s', $it618_group_sale['it618_time']).'</font>
							<span style="float:right;color:#333">'.$it618_unit.'*'.$it618_group_sale['it618_count'].'</span>
							</td></tr>
						</table>
					</td></tr>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmysale'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_group:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_group_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_group_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_group_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_group_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_group_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_group_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_group_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_group_getlang('s229')."<font color=red>$count</font> ".it618_group_getlang('s230')."<font color=red>$money</font>"."it618_split".$salelist_get."it618_split".$multipage;
}

if($_GET['ac']=="salekmlist_get"){
	if($_GET['ac1']=='pcmysalekm')$ppp = 10;
	if($_GET['ac1']=='wapmysalekm')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;

	if($_GET['ac1']=='pcmysalekm'||$_GET['ac1']=='wapmysalekm'){		
		$it618_group_salekms=C::t('#it618_group#it618_group_salekm')->fetch_all_by_search($it618sql,'id desc',$_GET['pid'],$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
		$count=C::t('#it618_group#it618_group_salekm')->count_by_search($it618sql,'',$_GET['pid'],$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$funname='getmysalekmlist';
	}

	$n=0;
	foreach($it618_group_salekms as $it618_group_salekm) {
		if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_salekm['it618_pid']);
		
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
		
		$it618_unit=it618_group_getgoodsunit($it618_group_goods);

		if($_GET['ac1']=='pcmysalekm'){
			$tmpurl=it618_group_getrewrite('group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id']);
			
			$salelist_get.='<tr class="hover">
						<td class="tdgroup"><a href="'.$tmpurl.'" target="_blank"><img src="'.$it618_group_group['it618_ico'].'"/>'.$grouptitle.'</a></td>
						<td style="text-align:center">'.$it618_unit.'</td>
						<td><font color=#999>'.$it618_group_salekm['it618_code'].'</font></td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_group_salekm['it618_time']).'</font></td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmysalekm'){
			
			if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
			
			if($jftmp!=''){
				$jftmp=' <font color=#999>'.$it618_group_lang['s188'].':'.$jftmp.'</font>';
			}
			
			$tmpurl=it618_group_getrewrite('group_wap','product@'.$it618_group_goods['id'],'plugin.php?id=it618_group:wap&pagetype=product&cid1='.$it618_group_goods['id']);
					
			$salelist_get.='<tr><td style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="60" style="vertical-align:top;border:none">
							<a href="'.$tmpurl.'"><img src="'.$it618_group_group['it618_ico'].'" width="48" height="48" style="border-radius: 3px;"/></a>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a class="name" href="'.$tmpurl.'" target="_blank" style="font-size:14px;color:#333">'.$grouptitle.'</a><br>
							<font color=#999>'.$it618_group_salekm['it618_code'].'</font><br>
							<font color=#ccc>'.date('Y-m-d H:i:s', $it618_group_salekm['it618_time']).'</font>
							<span style="float:right;color:#333">'.$it618_unit.'</span>
							</td></tr>
						</table>
					</td></tr>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmysalekm'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_group:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_group_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_group_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_group_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_group_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_group_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_group_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_group_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_group_getlang('s285')."<font color=red>$count</font>it618_split".$salelist_get."it618_split".$multipage;
}

if($_GET['ac']=="salejllist_get"){
	if($_GET['ac1']=='pcmysalejl')$ppp = 10;
	if($_GET['ac1']=='wapmysalejl')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;

	if($_GET['ac1']=='pcmysalejl'||$_GET['ac1']=='wapmysalejl'){		
		$it618_group_salejls=C::t('#it618_group#it618_group_salejl')->fetch_all_by_search($it618sql,'s.id desc',$_GET['groupid'],$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
		$count=C::t('#it618_group#it618_group_salejl')->count_by_search($it618sql,'s.id desc',$_GET['groupid'],$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$funname='getmysalejllist';
	}

	$n=0;
	foreach($it618_group_salejls as $it618_group_salejl) {
		if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_salejl['it618_groupid']);
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_salejl['it618_groupid']);
		
		if($it618_group_salejl['it618_saletype']=='videopid'){
			$it618_video_sale=C::t('#it618_video#it618_video_sale')->fetch_by_id($it618_group_salejl['it618_saleid']);
			$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
			$aboutstr=$it618_group_lang['s253'].$it618_group_salejl['it618_saleid'].' '.$it618_video_goods['it618_name'];
		}
		
		if($it618_group_salejl['it618_saletype']=='sgzs'){
			$aboutstr=$it618_group_salejl['it618_bz'];
		}
		
		if($it618_group_salejl['it618_days']>=365*60){
			$it618_days=$it618_group_lang['s167'];
		}else{
			$it618_days=$it618_group_salejl['it618_days'].$it618_group_lang['s60'];
		}

		if($_GET['ac1']=='pcmysalejl'){

			$salelist_get.='<tr class="hover">
						<td class="tdgroup"><img src="'.$it618_group_group['it618_ico'].'"/>'.$grouptitle.'</td>
						<td style="text-align:center">'.$it618_days.'</td>
						<td style="text-align:center" title="'.$aboutstr.'">'.cutstr($aboutstr,68,'...').'</td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_group_salejl['it618_time']).'</font></td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmysalejl'){
			
			if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
					
			$salelist_get.='<tr><td style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="60" style="vertical-align:top;border:none">
							<img src="'.$it618_group_group['it618_ico'].'" width="48" height="48" style="border-radius: 3px;"/>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a class="name" style="font-size:14px;color:#333">'.$grouptitle.'</a><br>
							<font color="#999">'.$aboutstr.'</font><br>
							<font color=#ccc>'.date('Y-m-d H:i:s', $it618_group_salejl['it618_time']).'</font>
							<span style="float:right;color:#333">'.$it618_days.'</span>
							</td></tr>
						</table>
					</td></tr>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmysalejl'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_group:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_group_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_group_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_group_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_group_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_group_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_group:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_group_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_group_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_group_getlang('s257')."<font color=red>$count</font> it618_split".$salelist_get."it618_split".$multipage;
}

if($_GET['ac']=="km_dao"||$_GET['ac']=="sale_get"||$_GET['ac']=="sale_dao"||$_GET['ac']=="salekm_get"||$_GET['ac']=="salekm_dao"||$_GET['ac']=="salejl_get"||$_GET['ac']=="salejl_dao"||$_GET['ac']=="user_get"||$_GET['ac']=="user_dao"){
	$group_adminuids=explode(",",$it618_group['group_adminuids']);
	if(!in_array($_G['uid'], $group_adminuids)){
		echo it618_group_getlang('s194');exit;
	}
}


if($_GET['ac']=="km_dao"){
	$pid=intval($_GET['pid']);
	
	$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($pid);

	$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
	$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
	
	$it618_unit=it618_group_getgoodsunit($it618_group_goods);
	
	$strtmp=$grouptitle." ".$it618_unit."\n".$it618_group_lang['s246']."\n";
	foreach(C::t('#it618_group#it618_group_goods_km')->fetch_all_by_search(
		$it618sql,'id desc',$pid,it618_group_utftogbk($_GET['it618_bzfind']),$startlimit,$ppp
	) as $it618_group_goods_km) {
		
		if($it618_group_goods_km['it618_etime']==0){
			$it618_etime=$it618_group_lang['s352'];
		}else{
			$it618_etime=date('Y-m-d H:i:s', $it618_group_goods_km['it618_etime']);
		}
		
		if($it618_group_goods_km['it618_xgtime']>0){
			$it618_xgtime='<font color=red>'.$it618_group_goods_km['it618_xgtime'].'</font>'.$it618_group_lang['s885'];
		}else{
			$it618_xgtime=$it618_group_lang['s886'];
		}
		
		$strtmp.=$it618_group_goods_km['it618_code'].",".$it618_xgtime.",".$it618_etime.",".$it618_group_goods_km['it618_bz'].",".date('Y-m-d H:i:s', $it618_group_goods_km['it618_addtime'])."\n";
		$datacount=$datacount+1;
	}
	
	$datapath1=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/';
	if(!file_exists($datapath1)) {
		mkdir($datapath1);
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	$timestr=md5(date("YmdHis").FORMHASH).'_'.$pid. '_' . $datacount;
	it618_group_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_group/kindeditor/data/dao/'.$timestr.'.csv';
	exit;
}


if($_GET['ac']=="sale_get"){
	if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
	
	$ppp = 13;
	
	$count = C::t('#it618_group#it618_group_sale')->count_by_search("s.it618_state!=0 ".$it618sql,'s.id desc',$_GET['classid'],$_GET['groupid'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$summoney = C::t('#it618_group#it618_group_sale')->sum_money_by_search("s.it618_state!=0 ".$it618sql,'s.id desc',$_GET['classid'],$_GET['groupid'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$salesum= '<td colspan=15>'.it618_group_getlang('s229').'<font color=red>'.$count.'</font> '.it618_group_getlang('s230').'<font color=red>'.$summoney.'</font> '.it618_group_getlang('s415').'<font color=red>'.$sumtcmoney.'</font><span style="float:right"></span></td>';
	
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_group:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getsalelist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
			
	foreach(C::t('#it618_group#it618_group_sale')->fetch_all_by_search(
		"s.it618_state!=0 ".$it618sql,'s.id desc',$_GET['classid'],$_GET['groupid'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_group_sale) {
		
		$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_sale['it618_pid']);
		
		$jftmp='';
		if($it618_group_sale['it618_jfbl']>0&&$it618_group_sale['it618_price']>0){
			$it618_jfbl=intval($it618_group_sale['it618_jfbl']*$it618_group_sale['it618_price']/100);
			$jftmp=$it618_jfbl.$creditname;
		}
		
		$pricestr='<font color=red>'.it618_group_getsalemoney($it618_group_sale).'</font>';
		
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
		
		$it618_unit=it618_group_getgoodsunit($it618_group_goods);
		
		$it618_tuitc='';
		if($it618_group_sale['it618_tuitcbl']>0){
			$it618_tuitc=$it618_group_sale['it618_tuitcbl'].'% ';
			$it618_tuitc.='<font color=red>'.$it618_group_sale['it618_tuitc'].'</font>'.$it618_group_lang['s125'].' ';
			
			if($it618_group_sale['it618_score']>0){
				$tmptc=intval($it618_group_sale['it618_tuitcbl']*$it618_group_sale['it618_score']/100);
				$jfname=$_G['setting']['extcredits'][$it618_group_sale['it618_jfid']]['title'];
				$it618_tuitc.=' <font color=red>'.$tmptc.'</font>'.$jfname;
			}
			
			$it618_tuitc='<br>'.$it618_group_lang['s1207'].$it618_tuitc;
		}
		
		$tmpurl=it618_group_getrewrite('group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id']);
		$sale_get.='<tr class="hover">
		<td><input class="checkbox" type="checkbox" id="chk_del'.$it618_group_sale['id'].'" name="delete[]" value="'.$it618_group_sale['id'].'" '.$disabled.'><label for="chk_del'.$it618_group_sale['id'].'">'.$it618_group_sale['id'].'</label></td>
		<td class="tdgroup"><a href="'.$tmpurl.'" target="_blank"><img src="'.$it618_group_group['it618_ico'].'"/>'.$grouptitle.'</a></td>
		<td>'.$it618_unit.'*'.$it618_group_sale['it618_count'].'</td>
		<td>'.$pricestr.'</td>
		<td>'.$jftmp.'</td>
		<td><a href="'.it618_group_rewriteurl($it618_group_sale['it618_uid']).'" target="_blank">'.it618_group_getusername($it618_group_sale['it618_uid']).'</a></td>
		<td><font color=#999>'.date('Y-m-d H:i:s', $it618_group_sale['it618_time']).'</font></td>
		</tr>';

	}
	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /><script>'.$tmpjs.'</script></td>';
	
	echo $salesum.'it618_split'.$sale_get.'it618_split'.$multipage;
	exit;
}


if($_GET['ac']=="sale_dao"){	
	$strtmp=$it618_group_lang['s193']."\n";
	foreach(C::t('#it618_group#it618_group_sale')->fetch_all_by_search(
		"s.it618_state!=0 ".$it618sql,'s.id desc',$_GET['classid'],$_GET['groupid'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],0,0
	) as $it618_group_sale) {
		$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_sale['it618_pid']);
		
		$jftmp='';
		if($it618_group_sale['it618_jfbl']>0&&$it618_group_sale['it618_price']>0){
			$it618_jfbl=intval($it618_group_sale['it618_jfbl']*$it618_group_sale['it618_price']/100);
			$jftmp=$it618_jfbl.$creditname;
		}
		
		$pricestr=it618_group_getsalemoney($it618_group_sale);
		
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
		
		$it618_unit=it618_group_getgoodsunit($it618_group_goods);
		
		$strtmp.=$it618_group_sale['id'].",".$grouptitle.",".$it618_unit.'*'.$it618_group_sale['it618_count'].",".$pricestr.",".$jftmp.",".it618_group_getusername($it618_group_sale['it618_uid']).'('.$it618_group_salejl['it618_uid'].')'.",".date('Y-m-d H:i:s', $it618_group_sale['it618_time'])."\n";
		$datacount=$datacount+1;
	}
	
	$datapath1=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/';
	if(!file_exists($datapath1)) {
		mkdir($datapath1);
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	if($_GET['it618_time1']!=''||$_GET['it618_time2']!=''){
		if($_GET['it618_time1']!=''){
			$timetmp1=str_replace("-","",$_GET['it618_time1']);
		}else{
			$timetmp1='null';
		}
		if($_GET['it618_time2']!=''){
			$timetmp2=str_replace("-","",$_GET['it618_time2']);
		}else{
			$timetmp2='null';
		}
		$timetmp=$timetmp1.'-'.$timetmp2;
	}
	$timestr=md5(date("YmdHis").FORMHASH).'_'.$timetmp. '_' . $datacount;
	it618_group_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_group/kindeditor/data/dao/'.$timestr.'.csv';
	exit;
}


if($_GET['ac']=="salekm_get"){
	if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
	
	$ppp = 13;
	
	$count = C::t('#it618_group#it618_group_salekm')->count_by_search($it618sql,'id desc',$_GET['findpid'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$salesum= '<td colspan=15>'.it618_group_getlang('s257').'<font color=red>'.$count.'</font><span style="float:right"></span></td>';
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_group:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getsalelist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
			
	foreach(C::t('#it618_group#it618_group_salekm')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['findpid'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_group_salekm) {
		
		$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_salekm['it618_pid']);
		
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
		
		$it618_unit=it618_group_getgoodsunit($it618_group_goods);
		
		$sale_get.='<tr class="hover">
		<td><input class="checkbox" type="checkbox" id="chk_del'.$it618_group_salekm['id'].'" name="delete[]" value="'.$it618_group_salekm['id'].'" '.$disabled.'><label for="chk_del'.$it618_group_salekm['id'].'">'.$it618_group_salekm['id'].'</label></td>
		<td class="tdgroup"><img src="'.$it618_group_group['it618_ico'].'"/>'.$grouptitle.'</td>
		<td>'.$it618_unit.'</td>
		<td>'.$it618_group_salekm['it618_code'].'</td>
		<td><a href="'.it618_group_rewriteurl($it618_group_salekm['it618_uid']).'" target="_blank">'.it618_group_getusername($it618_group_salekm['it618_uid']).'</a></td>
		<td><font color=#999>'.date('Y-m-d H:i:s', $it618_group_salekm['it618_time']).'</font></td>
		</tr>';

	}
	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /><script>'.$tmpjs.'</script></td>';
	
	echo $salesum.'it618_split'.$sale_get.'it618_split'.$multipage;
	exit;
}


if($_GET['ac']=="salekm_dao"){
	$strtmp=$it618_group_lang['s245']."\n";
	foreach(C::t('#it618_group#it618_group_salekm')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['findpid'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],0,0
	) as $it618_group_salekm) {
		
		$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_salekm['it618_pid']);
		
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
		
		$it618_unit=it618_group_getgoodsunit($it618_group_goods);
		
		$strtmp.=$it618_group_salekm['id'].",".$grouptitle.",".$it618_unit.",".$it618_group_salekm['it618_code'].",".it618_group_getusername($it618_group_salekm['it618_uid']).'('.$it618_group_salejl['it618_uid'].')'.",".date('Y-m-d H:i:s', $it618_group_salekm['it618_time'])."\n";
		$datacount=$datacount+1;
	}
	
	$datapath1=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/';
	if(!file_exists($datapath1)) {
		mkdir($datapath1);
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	if($_GET['it618_time1']!=''||$_GET['it618_time2']!=''){
		if($_GET['it618_time1']!=''){
			$timetmp1=str_replace("-","",$_GET['it618_time1']);
		}else{
			$timetmp1='null';
		}
		if($_GET['it618_time2']!=''){
			$timetmp2=str_replace("-","",$_GET['it618_time2']);
		}else{
			$timetmp2='null';
		}
		$timetmp=$timetmp1.'-'.$timetmp2;
	}
	$timestr=md5(date("YmdHis").FORMHASH).'_'.$timetmp. '_' . $datacount;
	it618_group_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_group/kindeditor/data/dao/'.$timestr.'.csv';
	exit;
}


if($_GET['ac']=="salejl_get"){
	if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
	
	$ppp = 13;
	
	$count = C::t('#it618_group#it618_group_salejl')->count_by_search($it618sql,'s.id desc',$_GET['groupid'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$salesum= '<td colspan=15>'.it618_group_getlang('s257').'<font color=red>'.$count.'</font><span style="float:right"></span></td>';
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_group:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getsalelist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
			
	foreach(C::t('#it618_group#it618_group_salejl')->fetch_all_by_search(
		$it618sql,'s.id desc',$_GET['groupid'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_group_salejl) {
		
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_salejl['it618_groupid']);
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_salejl['it618_groupid']);
		
		if($it618_group_salejl['it618_saletype']=='videopid'){
			$it618_video_sale=C::t('#it618_video#it618_video_sale')->fetch_by_id($it618_group_salejl['it618_saleid']);
			$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
			$aboutstr=$it618_group_lang['s253'].$it618_group_salejl['it618_saleid'].' '.$it618_video_goods['it618_name'];
		}
		
		if($it618_group_salejl['it618_saletype']=='sgzs'){
			$aboutstr=$it618_group_salejl['it618_bz'];
		}
		
		if($it618_group_salejl['it618_days']>=365*60){
			$it618_days=$it618_group_lang['s167'];
		}else{
			$it618_days=$it618_group_salejl['it618_days'];
		}
		
		$sale_get.='<tr class="hover">
		<td><input class="checkbox" type="checkbox" id="chk_del'.$it618_group_salejl['id'].'" name="delete[]" value="'.$it618_group_salejl['id'].'" '.$disabled.'><label for="chk_del'.$it618_group_salejl['id'].'">'.$it618_group_salejl['id'].'</label></td>
		<td class="tdgroup"><img src="'.$it618_group_group['it618_ico'].'"/>'.$grouptitle.'</td>
		<td>'.$it618_days.'</td>
		<td>'.$aboutstr.'</td>
		<td><a href="'.it618_group_rewriteurl($it618_group_salejl['it618_uid']).'" target="_blank">'.it618_group_getusername($it618_group_salejl['it618_uid']).'('.$it618_group_salejl['it618_uid'].')</a></td>
		<td><font color=#999>'.date('Y-m-d H:i:s', $it618_group_salejl['it618_time']).'</font></td>
		</tr>';

	}
	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /><script>'.$tmpjs.'</script></td>';
	
	echo $salesum.'it618_split'.$sale_get.'it618_split'.$multipage;
	exit;
}


if($_GET['ac']=="salejl_dao"){
	$strtmp=$it618_group_lang['s247']."\n";
	foreach(C::t('#it618_group#it618_group_salejl')->fetch_all_by_search(
		$it618sql,'s.id desc',$_GET['groupid'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],0,0
	) as $it618_group_salejl) {
		
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_salejl['it618_groupid']);
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_salejl['it618_groupid']);
		
		if($it618_group_salejl['it618_saletype']=='videopid'){
			$it618_video_sale=C::t('#it618_video#it618_video_sale')->fetch_by_id($it618_group_salejl['it618_saleid']);
			$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
			$aboutstr=$it618_group_lang['s253'].$it618_group_salejl['it618_saleid'].' '.$it618_video_goods['it618_name'];
		}
		
		if($it618_group_salejl['it618_saletype']=='sgzs'){
			$aboutstr=$it618_group_salejl['it618_bz'];
		}
		
		if($it618_group_salejl['it618_days']>=365*60){
			$it618_days=$it618_group_lang['s167'];
		}else{
			$it618_days=$it618_group_salejl['it618_days'];
		}
		
		$strtmp.=$grouptitle.",".$it618_days.",".$aboutstr.",".it618_group_getusername($it618_group_salejl['it618_uid']).'('.$it618_group_salejl['it618_uid'].')'.",".date('Y-m-d H:i:s', $it618_group_salejl['it618_time'])."\n";
		$datacount=$datacount+1;
	}
	
	$datapath1=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/';
	if(!file_exists($datapath1)) {
		mkdir($datapath1);
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	if($_GET['it618_time1']!=''||$_GET['it618_time2']!=''){
		if($_GET['it618_time1']!=''){
			$timetmp1=str_replace("-","",$_GET['it618_time1']);
		}else{
			$timetmp1='null';
		}
		if($_GET['it618_time2']!=''){
			$timetmp2=str_replace("-","",$_GET['it618_time2']);
		}else{
			$timetmp2='null';
		}
		$timetmp=$timetmp1.'-'.$timetmp2;
	}
	$timestr=md5(date("YmdHis").FORMHASH).'_'.$timetmp. '_' . $datacount;
	it618_group_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_group/kindeditor/data/dao/'.$timestr.'.csv';
	exit;
}


if($_GET['ac']=="user_get"){
	if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
	
	$ppp = 13;
	
	$count = C::t('#it618_group#it618_group_group_user')->count_by_search($it618sql,'s.id desc',$_GET['groupid'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$salesum= '<td colspan=15>'.it618_group_getlang('s257').'<font color=red>'.$count.'</font><span style="float:right"></span></td>';
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_group:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getsalelist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
			
	foreach(C::t('#it618_group#it618_group_group_user')->fetch_all_by_search(
		$it618sql,'s.id desc',$_GET['groupid'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_group_group_user) {
		
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_group_user['it618_groupid']);
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_group_user['it618_groupid']);
		
		if($it618_group_group_user['it618_etime']>0){
			if($it618_group_group_user['it618_etime']-3600*24*365*60>$_G['timestamp']){
				$it618_etime=$it618_group_lang['s167'];
			}else{
				$it618_etime=date('Y-m-d H:i:s', $it618_group_group_user['it618_etime']);
			}
		}else{
			$it618_etime=$it618_group_lang['s167'];
		}
		
		$it618_txtime='';
		if($it618_group_group_user['it618_txtime']>0){
			$it618_txtime=date('Y-m-d H:i:s', $it618_group_group_user['it618_txtime']);
		}
		
		$it618_txstate='-';
		if($it618_group_group_user['it618_txstate']==1){
			$it618_txstate=$it618_group_lang['s275'];
		}
		if($it618_group_group_user['it618_txstate']==2){
			$it618_txstate=$it618_group_lang['s276'];
		}
		
		$sale_get.='<tr class="hover">
		<td><input class="checkbox" type="checkbox" id="chk_del'.$it618_group_group_user['id'].'" name="delete[]" value="'.$it618_group_group_user['id'].'" '.$disabled.'><label for="chk_del'.$it618_group_group_user['id'].'">'.$it618_group_group_user['id'].'</label></td>
		<td><a href="'.it618_group_rewriteurl($it618_group_group_user['it618_uid']).'" target="_blank">'.it618_group_getusername($it618_group_group_user['it618_uid']).'('.$it618_group_group_user['it618_uid'].')</a></td>
		<td class="tdgroup"><img src="'.$it618_group_group['it618_ico'].'"/>'.$grouptitle.' <font color=#999>VIPID:'.$it618_group_group_user['it618_groupid'].'</font></td>
		<td>'.$it618_etime.'</td>
		<td><a href="javascript:" onclick="showuserbz('.$it618_group_group_user['id'].')">'.$it618_group_lang['s472'].'(<font color=red>'.strlen($it618_group_group_user['it618_bz']).'</font>)</a></td>
		<td><font color=#999>'.$it618_txtime.'</font></td>
		<td>'.$it618_txstate.'</td>
		</tr>';

	}
	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /><script>'.$tmpjs.'</script></td>';
	
	echo $salesum.'it618_split'.$sale_get.'it618_split'.$multipage;
	exit;
}


if($_GET['ac']=="user_dao"){	
	$strtmp=$it618_group_lang['s273']."\n";
	foreach(C::t('#it618_group#it618_group_group_user')->fetch_all_by_search(
		$it618sql,'s.id desc',$_GET['groupid'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],0,0
	) as $it618_group_group_user) {
		
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_group_user['it618_groupid']);
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_group_user['it618_groupid']);
		
		if($it618_group_group_user['it618_etime']-3600*24*365*60>$_G['timestamp']){
			$it618_etime=$it618_group_lang['s167'];
		}else{
			$it618_etime=date('Y-m-d H:i:s', $it618_group_group_user['it618_etime']);
		}
		
		$it618_txtime='';
		if($it618_group_group_user['it618_txtime']>0){
			$it618_txtime=date('Y-m-d H:i:s', $it618_group_group_user['it618_txtime']);
		}
		
		$it618_txstate='-';
		if($it618_group_group_user['it618_txstate']==1){
			$it618_txstate=$it618_group_lang['s275'];
		}
		if($it618_group_group_user['it618_txstate']==2){
			$it618_txstate=$it618_group_lang['s276'];
		}
		
		$strtmp.=it618_group_getusername($it618_group_group_user['it618_uid']).'('.$it618_group_group_user['it618_uid'].')'.",".$grouptitle.",".$it618_etime.",".$it618_group_group_user['it618_bz'].",".date('Y-m-d H:i:s', $it618_group_group_user['it618_time']).",".$it618_txtime.",".$it618_txstate."\n";
		$datacount=$datacount+1;
	}
	
	$datapath1=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/';
	if(!file_exists($datapath1)) {
		mkdir($datapath1);
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	if($_GET['it618_time1']!=''||$_GET['it618_time2']!=''){
		if($_GET['it618_time1']!=''){
			$timetmp1=str_replace("-","",$_GET['it618_time1']);
		}else{
			$timetmp1='null';
		}
		if($_GET['it618_time2']!=''){
			$timetmp2=str_replace("-","",$_GET['it618_time2']);
		}else{
			$timetmp2='null';
		}
		$timetmp=$timetmp1.'-'.$timetmp2;
	}
	$timestr=md5(date("YmdHis").FORMHASH).'_'.$timetmp. '_' . $datacount;
	it618_group_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_group/kindeditor/data/dao/'.$timestr.'.csv';
	exit;
}


if($_GET['ac']=="zuser_get"){
	if(lang('plugin/it618_group', $it618_group_lang['it618'])!=$it618_group_lang['version'])exit;
	
	$ppp = 13;
	
	$count = C::t('#it618_group#it618_group_group_zuser')->count_by_search($it618sql,'id desc',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$salesum= '<td colspan=15>'.it618_group_getlang('s257').'<font color=red>'.$count.'</font><span style="float:right"></span></td>';
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_group:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getsalelist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
			
	foreach(C::t('#it618_group#it618_group_group_zuser')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_group_group_zuser) {
		
		$sale_get.='<tr class="hover">
		<td><input class="checkbox" type="checkbox" id="chk_del'.$it618_group_group_zuser['id'].'" name="delete[]" value="'.$it618_group_group_zuser['id'].'" '.$disabled.'><label for="chk_del'.$it618_group_group_zuser['id'].'">'.$it618_group_group_zuser['id'].'</label></td>
		<td><a href="'.it618_group_rewriteurl($it618_group_group_zuser['it618_uid']).'" target="_blank">'.it618_group_getusername($it618_group_group_zuser['it618_uid']).'('.$it618_group_group_zuser['it618_uid'].')</a></td>
		<td><a href="javascript:" onclick="showuserbz('.$it618_group_group_zuser['id'].')">'.$it618_group_lang['s472'].'(<font color=red>'.strlen($it618_group_group_zuser['it618_bz']).'</font>)</a></td>
		<td>'.date('Y-m-d H:i:s', $it618_group_group_zuser['it618_time']).'</td>
		</tr>';

	}
	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /><script>'.$tmpjs.'</script></td>';
	
	echo $salesum.'it618_split'.$sale_get.'it618_split'.$multipage;
	exit;
}


if($_GET['ac']=="zuser_dao"){	
	$strtmp=$it618_group_lang['s476']."\n";
	foreach(C::t('#it618_group#it618_group_group_zuser')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],0,0
	) as $it618_group_group_zuser) {
		
		$strtmp.=it618_group_getusername($it618_group_group_zuser['it618_uid']).'('.$it618_group_group_zuser['it618_uid'].')'.",".$it618_group_group_zuser['it618_bz'].",".date('Y-m-d H:i:s', $it618_group_group_zuser['it618_time'])."\n";
		$datacount=$datacount+1;
	}
	
	$datapath1=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/';
	if(!file_exists($datapath1)) {
		mkdir($datapath1);
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	if($_GET['it618_time1']!=''||$_GET['it618_time2']!=''){
		if($_GET['it618_time1']!=''){
			$timetmp1=str_replace("-","",$_GET['it618_time1']);
		}else{
			$timetmp1='null';
		}
		if($_GET['it618_time2']!=''){
			$timetmp2=str_replace("-","",$_GET['it618_time2']);
		}else{
			$timetmp2='null';
		}
		$timetmp=$timetmp1.'-'.$timetmp2;
	}
	$timestr=md5(date("YmdHis").FORMHASH).'_'.$timetmp. '_' . $datacount;
	it618_group_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_group/kindeditor/data/dao/'.$timestr.'.csv';
	exit;
}


if($_GET['ac']=="zuser_add"){	
	if(!$it618_group_group_zuser=C::t('#it618_group#it618_group_group_zuser')->fetch_by_uid($_GET['uid'])){
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".intval($_GET['uid']));
		if($username!=''){
			$id = C::t('#it618_group#it618_group_group_zuser')->insert(array(
				'it618_uid' => $_GET['uid']
			), true);
			echo 'ok';
		}else{
			echo $it618_group_lang['s480'];
		}
	}else{
		echo $it618_group_lang['s481'];
	}
	exit;
}
?>