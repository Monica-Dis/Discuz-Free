<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_group;
$it618_group = $_G['cache']['plugin']['it618_group'];
require_once DISCUZ_ROOT.'./source/plugin/it618_group/lang.func.php';

function it618_group_getgroup($pluginid,$name='#it618_group'){
	global $_G,$it618_group,$it618_group_lang;
	
	$url="plugin.php?id=it618_group:uc";
	$getgroup='<script type="text/javascript" src="source/plugin/it618_group/js/layer/layer.js"></script>';
	
	$widthheight='"868px", "588px"';

	$getgroup.= '
		<script>			
		jQuery(document).ready(function() {
			
		jQuery("'.$name.'").click(function() {
			layerindex=layer.open({
			  type: 2,
			  title: "<div style=\'float:left\'><img src=\'source/plugin/it618_group/images/group.png\' style=\'vertical-align:middle;margin-right:3px; margin-top:-4px; height:18px\'>'.$it618_group_lang['s111'].'</div>",
			  shadeClose: false,
			  scrollbar: false,
			  shade:  [0.5, "#393D49"],
			  maxmin: false,
			  area: ['.$widthheight.'],
			  content: "'.$url.'",
			  cancel: function(index, layero){ 
			  }    
			});
		});
		
		});
		</script>
	';
	
	return $getgroup;
}

function it618_group_getad($pluginid,$type){
	global $_G,$it618_group,$it618_group_lang;
	
	if($pluginid!='it618_discuz'){
		$tmparr=explode(":",$pluginid);
		$tmparr1=explode("_",$tmparr[0]);
		$plugin=$tmparr1[1];
	}
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_ad')." where it618_isok=1 and it618_type=$type");
	while($it618_group_ad = DB::fetch($query)) {
		$aid=$it618_group_ad['id'];
		$type=$it618_group_ad['it618_type'];
		$width=$it618_group_ad['it618_width'];
		$height=$it618_group_ad['it618_height'];
		$isadok1=0;
		
		if($it618_group_ad['it618_urlarea']!=''){
			$tmparr=explode(",",$it618_group_ad['it618_urlarea']);
			for($i=0;$i<count($tmparr);$i++){
				$tmparr1=explode($tmparr[$i],$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
				if(count($tmparr1)>1){
					$isadok1=1;
					break;
				}
			}
		}
		
		if($isadok1==0&&$plugin!=''){
			if($it618_group_adarea=C::t('#it618_group#it618_group_adarea')->fetch_by_plugin_aid_ok($plugin,$aid)){
				$isadok1=1;
			}
		}
		
		$isadok2=0;
		$tmpuser1=0;$tmpuser2=0;$tmpuser3=0;
		if($it618_group_ad['it618_uids']!=''){
			$tmpuser1=1;
			$uidsarr=explode(",",$it618_group_ad['it618_uids']);
			if(in_array($_G['uid'], $uidsarr)){
				$isadok2=1;
			}
		}
		
		if($isadok2==0){
			$query = DB::query("SELECT * FROM ".DB::table('it618_group_adshop')." WHERE it618_aid=".$aid." and it618_isok=1");
			while($it618_group_adshop = DB::fetch($query)) {
				$tmpuser2=1;
				if($it618_group_adshop['it618_plugin']=='video'){
					if($tmpshop=C::t('#it618_video#it618_video_shop')->fetch_by_uid($_G['uid'])){
						$isadok2=1;
						break;
					}
				}
				if($it618_group_adshop['it618_plugin']=='exam'){
					if($tmpshop=C::t('#it618_exam#it618_exam_shop')->fetch_by_uid($_G['uid'])){
						$isadok2=1;
						break;
					}
				}
				if($it618_group_adshop['it618_plugin']=='tuan'){
					if($tmpshop=C::t('#it618_tuan#it618_tuan_shop')->fetch_by_uid($_G['uid'])){
						$isadok2=1;
						break;
					}
				}
				if($it618_group_adshop['it618_plugin']=='brand'){
					if($tmpshop=C::t('#it618_brand#it618_brand_brand')->fetch_by_uid($_G['uid'])){
						$isadok2=1;
						break;
					}
				}
				if($it618_group_adshop['it618_plugin']=='waimai'){
					if($tmpshop=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_uid($_G['uid'])){
						$isadok2=1;
						break;
					}
				}
			}
		}
		
		if($isadok2==0){
			$adgroupids = array();
			$query = DB::query("SELECT * FROM ".DB::table('it618_group_adgroup')." WHERE it618_aid=".$aid." and it618_isok=1");
			while($it618_group_adgroup = DB::fetch($query)) {
				if($it618_group_adgroup['it618_groupid']>0){
					if(!in_array($it618_group_adgroup['it618_groupid'], $adgroupids)){
						$adgroupids[]=$it618_group_adgroup['it618_groupid'];
					}
				}
			}
			
			if(count($adgroupids)>0){
				$tmpuser3=1;
				require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
				$okvipgroupids=it618_group_getisvipuser($adgroupids);
				if(count($okvipgroupids[0])>0){
					$isadok2=1;
				}
			}
		}
		
		if($tmpuser1==0&&$tmpuser2==0&&$tmpuser3==0){
			$isadok2=1;
		}
		
		if($isadok1==1&&$isadok2==1){
			$url="plugin.php?id=it618_group:showad&aid=".$aid;
			
			$it618_groupad=getcookie('it618_groupad_'.$aid);
			if($it618_groupad==''){
				if($type==1){
					$width=$width/100;
					$height=$height/100;
				
					$getgroup.= '
						<script>
							var adwidth=document.documentElement.clientWidth*'.$width.';
							var adheight=document.documentElement.clientHeight*'.$height.';
							var adleft=(document.documentElement.clientWidth-adwidth)/2;
							var adbottom=(document.documentElement.clientHeight-adheight)/2;
						
							var adcontent=\'<table width="100%" id="tablelayer">\';
								
							adcontent+=\'<tr><td style="background-color:#fff;padding:0 0px;text-align:center;border-radius:10px"><div id="divlayerheight" style="width:100%;height:100%;-webkit-overflow-scrolling:touch;overflow:scroll;overflow-x:hidden;"><iframe src="'.$url.'&wap=1" style="border:none;display:block;width:100%;height:\'+adheight+\'px"></iframe></div></td></tr>\';
								
							adcontent+=\'</table>\';
								
							layerindex_ad'.$aid.'=layer.open({
							  type: 1
							  ,shade: "background-color: rgba(0,0,0,.3)"
							  ,content: adcontent
							  ,shadeClose:false
							  ,anim: "up"
							  ,style: "position:fixed;left:"+adleft+"px;bottom:"+adbottom+"px;width:"+adwidth+"px;height:"+adheight+"px;border: none; -webkit-animation-duration: .5s; animation-duration: .5s;background:none;"
							});
							
							function closead'.$aid.'(){
								jQuery.get("'.$_G['siteurl'].'plugin.php?id=it618_group:ajax&aid='.$aid.'", {ac:"groupad"},function (data, textStatus){
								}, "html");
								layer.close(layerindex_ad'.$aid.');
							}
						</script>
					';
				}else{
					$getgroup='<script type="text/javascript" src="source/plugin/it618_group/js/layer/layer.js"></script>';
					$widthheight='"'.$width.'px", "'.$height.'px"';
				
					$getgroup.= '
						<script>
							layerindex_ad'.$aid.'=layer.open({
							  type: 2,
							  title: false,
							  closeBtn: 0,
							  shadeClose: false,
							  scrollbar: false,
							  shade:  [0.5, "#393D49"],
							  maxmin: false,
							  area: ['.$widthheight.'],
							  content: "'.$url.'",
							  cancel: function(index, layero){ 
							  }    
							});
							
							function closead'.$aid.'(){
								jQuery.get("'.$_G['siteurl'].'plugin.php?id=it618_group:ajax&aid='.$aid.'", {ac:"groupad"},function (data, textStatus){
								}, "html");
								layer.close(layerindex_ad'.$aid.');
							}
						</script>
					';
				}
			}	
		}
	}
	
	return $getgroup;
}
?>