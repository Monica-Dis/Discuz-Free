<?php
/**
 *	�����Ŷӣ�DisM.Taobao.Com
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_group,$creditname;

$it618_group = $_G['cache']['plugin']['it618_group'];
$creditname=$_G['setting']['extcredits'][$it618_group['group_credit']]['title'];
require_once DISCUZ_ROOT.'./source/plugin/it618_group/lang.func.php';

function it618_group_getjftype($jfid=0){
	global $_G,$it618_group_lang;
	
	for($i=1;$i<=8;$i++){
		$jfname=$_G['setting']['extcredits'][$i]['title'];
		
		if($jfname!=''){
			if($jfid==$i)$selectedstr='selected="selected"';else $selectedstr='';
			$tmpstr.='<option value="'.$i.'" '.$selectedstr.'>'.$jfname.'</option>';
		}
	}
	
	return '<option value="0">'.$it618_group_lang['s32'].'</option>'.$tmpstr;
}

function it618_group_pay($type,$title){
	if(!file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php')){
		return;
	}
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
	$tmpstr=getpaytype();
	
	$tmparr=explode("it618getpaytype",$tmpstr);
	if(count($tmparr)>1){
		$tmpstr=$tmparr[0];
		
		if($type=='pay'){
			$paystr='<tr id="payselect">
			<td>'.$title.'</td>
			<td>
			'.$tmpstr.'
			</td>
			</tr>';
		}
		
		if($type=='paywap'){
			$paystr='<tr id="payselect"><td colspan=2>'.$tmpstr.'</td></tr>';
		}
		
		if($type=='gwc'){
			$paystr='<div class="buy-block" id="payselect">
					<div class="buy-block-title"><h3>'.$title.'</h3></div>
					<div style="padding:10px">'.$tmpstr.'</div>
					</div>';
		}
		
		if($type=='gwcwap'){
			$paystr='<table width="100%" class="gwctable" bgcolor="#FFFFFF" id="payselect">
					<tr><td><table width="100%">
					<tr class="gwctrtitle">
					<th style="padding-left:3px">'.$title.'</th>
					</tr>
					</table></td></tr><tr><td style="padding:3px">
					'.$tmpstr.'
					</td></tr></table>';
		}
	}else{
		$paystr=$tmpstr.'<span id="payselect"></span>';
	}
    
	return $paystr;
}

function it618_group_getisvipuser($vipgroupids){
	global $_G,$it618_group,$it618_group_lang;
	
	$okvipgroupids = array(array(),array());
	
	if(count($vipgroupids)>0){

		$extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
	
		$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
		$groupterms = dunserialize($memberfieldforum['groupterms']);
		unset($memberfieldforum);
		$expgrouparray = $expirylist = $termsarray = array();
	
		if(!empty($groupterms['ext']) && is_array($groupterms['ext'])) {
			$termsarray = $groupterms['ext'];
		}
		if(!empty($groupterms['main']['time']) && (empty($termsarray[$_G['groupid']]) || $termsarray[$_G['groupid']] > $groupterm['main']['time'])) {
			$termsarray[$_G['groupid']] = $groupterms['main']['time'];
		}
		
		foreach($termsarray as $expgroupid => $expiry) {
			if($expiry <= TIMESTAMP) {
				$expgrouparray[] = $expgroupid;
			}
		}
	
		$groupids = array();
		foreach($_G['cache']['usergroups'] as $groupid => $usergroup) {
			if(!empty($usergroup['pubtype'])) {
				$groupids[] = $groupid;
			}
		}
		
		if(!empty($groupterms['ext'])) {
			foreach($groupterms['ext'] as $extgroupid => $time) {
				$expirylist[$extgroupid] = array('timestamp' => $time, 'time' => dgmdate($time, 'd'), 'type' => 'ext', 'noswitch' => $time < TIMESTAMP);
			}
		}
		
		if(!empty($groupterms['main'])) {
			$expirylist[$_G['groupid']] = array('timestamp' => $groupterms['main']['time'], 'time' => dgmdate($groupterms['main']['time'], 'd'), 'type' => 'main');
		}
		
		$expiryids = array_keys($expirylist);
		$groupids = array_merge($extgroupids, $expiryids, $groupids);
		
		if($groupids) {
			foreach(C::t('common_usergroup')->fetch_all($groupids) as $group) {
				$groupid=$group['groupid'];
				
				if(in_array($groupid, $vipgroupids)){
					
					$isgroupok=1;
					if($group['type']!='system'&&$group['type']!='member'){
						$timestamp=$expirylist[$group['groupid']]['timestamp'];
						$grouptime=$expirylist[$group['groupid']]['time'];
						
						if($timestamp-3600*24*365*60>$_G['timestamp']||$grouptime==''){
							$grouptime=$it618_group_lang['s64'];
						}elseif($timestamp<$_G['timestamp']){
							$isgroupok=0;
						}
					}else{
						$grouptime='';
					}
					if($isgroupok==1){
						$okvipgroupids[0][]=$groupid;
						$okvipgroupids[1][]=$grouptime;
					}
				}
			}
		}
		
		if(!in_array($_G['groupid'], $okvipgroupids[0])){
			if(in_array($_G['groupid'], $vipgroupids)){
				$okvipgroupids[0][]=$_G['groupid'];
				$timestamp=$_G['member']['groupexpiry'];
				if($timestamp>0){
					$timestamp= dgmdate($timestamp, 'd');
				}
				$okvipgroupids[1][]=$timestamp;
			}
		}

	}
	
	return $okvipgroupids;
}

function it618_group_getucvip($wap=0){
	global $_G,$it618_group,$it618_group_lang;
	
	$extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
		
	$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
	$groupterms = dunserialize($memberfieldforum['groupterms']);
	unset($memberfieldforum);
	$expgrouparray = $expirylist = $termsarray = array();
	
	if(!empty($groupterms['ext']) && is_array($groupterms['ext'])) {
		$termsarray = $groupterms['ext'];
	}
	if(!empty($groupterms['main']['time']) && (empty($termsarray[$_G['groupid']]) || $termsarray[$_G['groupid']] > $groupterm['main']['time'])) {
		$termsarray[$_G['groupid']] = $groupterms['main']['time'];
	}
	
	foreach($termsarray as $expgroupid => $expiry) {
		if($expiry <= TIMESTAMP) {
			$expgrouparray[] = $expgroupid;
		}
	}
	
	if(!empty($groupterms['ext'])) {
		foreach($groupterms['ext'] as $extgroupid => $time) {
			$expirylist[$extgroupid] = array('timestamp' => $time, 'time' => date('Y-m-d H:i:s', $time), 'type' => 'ext', 'noswitch' => $time < TIMESTAMP);
		}
	}
	
	if(!empty($groupterms['main'])) {
		$expirylist[$_G['groupid']] = array('timestamp' => $groupterms['main']['time'], 'time' => date('Y-m-d H:i:s', $groupterms['main']['time']), 'type' => 'main');
	}
	
	$groupids = array();
	foreach($_G['cache']['usergroups'] as $groupid => $usergroup) {
		if(!empty($usergroup['pubtype'])) {
			$groupids[] = $groupid;
		}
	}
	
	$expiryids = array_keys($expirylist);
	if(!$expiryids && $_G['member']['groupexpiry']) {
		C::t('common_member')->update($_G['uid'], array('groupexpiry' => 0));
	}
	
	$groupids = array_merge($extgroupids, $expiryids, $groupids);
	
	if($groupids) {
		foreach(C::t('common_usergroup')->fetch_all($groupids) as $group) {
			$isexp = in_array($group['groupid'], $expgrouparray);
	
			$expirylist[$group['groupid']]['maingroup'] = $group['type'] != 'special' || $group['system'] == 'private' || $group['radminid'] > 0;
			$expirylist[$group['groupid']]['grouptitle'] = $isexp ? '<s>'.$group['grouptitle'].'</s>' : $group['grouptitle'];
			$expirylist[$group['groupid']]['type'] = $group['type'];
		}
	}
	
	$ismembergroup=0;
	$common_usergrouptmp = DB::fetch_first("SELECT groupid,grouptitle FROM ".DB::table('common_usergroup')." WHERE type='member' AND creditshigher<=".$_G['member']['credits']." AND creditslower>=".$_G['member']['credits']." LIMIT 1");
	$membergroupid=$common_usergrouptmp['groupid'];
	
	$tmpexpiryarr = array();
	foreach($expirylist as $groupid => $group) {
		$tmpexpiryarr[]=$groupid;
	}
	
	$n=0;
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_group')." order by it618_order desc");
	while($it618_group_group =	DB::fetch($query)) {
		if(in_array($it618_group_group['it618_groupid'], $tmpexpiryarr)){
			$expirylist[$it618_group_group['it618_groupid']]['order']=$n;
			$n=$n+1;
		}
	}
	
	foreach($expirylist as $groupid => $group) {
		if($it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($groupid)){
			$expirylist[$groupid]['groupico']=$it618_group_group['it618_ico'];
			$expirylist[$groupid]['it618_switch']=$it618_group_group['it618_switch'];
		}else{
			$expirylist[$groupid]['order']=$n;	
			$expirylist[$groupid]['groupico']='source/plugin/it618_group/images/vip.png';
			$expirylist[$groupid]['it618_switch']=0;
			$n=$n+1;
		}
	}
	
	foreach($expirylist as $groupid => $group) {
		
		$grouptitle=$group['grouptitle'];
		$groupico=$group['groupico'];
		$timestamp=$group['timestamp'];
		$grouptime=$group['time'];
		
		if($membergroupid==$groupid){
			$ismembergroup=1;
		}
		
		$atitle=$it618_group_lang['s177'];
		if($timestamp-3600*24*365*60>$_G['timestamp']||($grouptime==''&&$group['type']!='system'&&$group['type']!='member')){
			$grouptime=$it618_group_lang['s64'];
			$atitle=$it618_group_lang['s178'];
		}
		
		if($group['type']!='system'&&$group['type']!='member'){
			if($timestamp<$_G['timestamp']&&$timestamp!=''){
				$grouptime='<s>'.$grouptime.'</s>';
				$atitle=$it618_group_lang['s313'];
			}
		}
		
		if($groupid == $_G['groupid']&&$timestamp==''){
			if($group['type']!='system'&&$group['type']!='member'){
				$grouptime=$it618_group_lang['s64'];
			}else{
				$grouptime='';
			}
		}
		
		$goodsgroup='';
		if($it618_group_goodstmp = DB::fetch_first("SELECT * FROM ".DB::table('it618_group_goods')." where it618_groupid=".$groupid." and it618_state=1 ORDER BY it618_unit")){
			if($wap==1){ 
				$tmpurl=it618_group_getrewrite('group_wap','product@'.$it618_group_goodstmp['id'],'plugin.php?id=it618_group:wap&pagetype=product&cid1='.$it618_group_goodstmp['id']);
				$goodsgroup='<a href="'.$tmpurl.'">'.$atitle.'<img src="source/plugin/it618_group/images/right.png" class="rightimg"></a>';
			}else{
				$tmpurl=it618_group_getrewrite('group_product',$it618_group_goodstmp['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goodstmp['id']);
				$goodsgroup='<a href="'.$tmpurl.'" target="_ablank">'.$atitle.'<img src="source/plugin/it618_group/images/right.png" class="rightimg"></a>';
			}
		}
		
		$maingroupstr='';$maincss='';
		if($groupid == $_G['groupid']){
			$maingroupstr='<span>'.$it618_group_lang['s598'].'</span>';
			$maincss=' groupmain';
		}else{
			if(!$group['noswitch']){
				if($group['it618_switch']==1){
					$maingroupstr='<a href="javascript:" class="switch" onclick="group_switch('.$groupid.')">'.$it618_group_lang['s599'].'</a>';
				}else{
					$maingroupstr='<span>'.$it618_group_lang['s198'].'</span>';
				}
			}
		}
		
		if($grouptime!=''){
			$grouptime=$it618_group_lang['s163'].$grouptime;
		}else{
			if($group['type']=='system'){$grouptime=$it618_group_lang['s175'];$groupico='source/plugin/it618_group/images/system.png';}
			if($group['type']=='member'){$grouptime=$it618_group_lang['s176'];$groupico='source/plugin/it618_group/images/member.png';}
			$maingroupstr='<a href="javascript:" class="switch" onclick="group_switch('.$groupid.')">'.$it618_group_lang['s599'].'</a>';
		}
		
		if($groupid == $_G['groupid']){
			$maingroupstr='<span>'.$it618_group_lang['s598'].'</span>';
			$maincss=' groupmain';
		}
		
		if($wap==1){ 
			$groupstrarr[$group['order']]='<tr><td class="tdvipleft'.$maincss.'">
			<img src="'.$groupico.'" class="groupico"/></td><td class="tdvipright">
			<div>'.$grouptitle.$maingroupstr.'<p>'.$goodsgroup.$grouptime.'</p></div>
			</td></tr><tr><td class="tdline" colspan="2"></td></tr>';
		}else{
			$groupstrarr[$group['order']]='<li class="'.$maincss.'">
			<img src="'.$groupico.'" class="groupico"/>
			<div>'.$grouptitle.$maingroupstr.'<p>'.$goodsgroup.$grouptime.'</p></div>
			</li>';
		}
	}
	
	ksort($groupstrarr);
	$groupstr=join($groupstrarr);
	
	if($ismembergroup==0&&$_G['adminid']<=0){
		if($membergroupid == $_G['groupid']){
			$maingroupstr='<span>'.$it618_group_lang['s598'].'</span>';
			$maincss=' groupmain';
		}else{
			$maingroupstr='<a href="javascript:" class="switch" onclick="group_switch('.$membergroupid.')">'.$it618_group_lang['s599'].'</a>';
		}
		
		$grouptitle=$common_usergrouptmp['grouptitle'];
		$grouptime=$it618_group_lang['s176'];
		$groupico='source/plugin/it618_group/images/member.png';
		$goodsgroup='';
		
		if($wap==1){ 
			$groupstr.='<tr><td class="tdvipleft'.$maincss.'">
			<img src="'.$groupico.'" class="groupico"/></td><td class="tdvipright">
			<div>'.$grouptitle.$maingroupstr.'<p>'.$goodsgroup.$grouptime.'</p></div>
			</td></tr><tr><td class="tdline" colspan="2"></td></tr>';
		}else{
			$groupstr.='<li class="'.$maincss.'">
			<img src="'.$groupico.'" class="groupico"/>
			<div>'.$grouptitle.$maingroupstr.'<p>'.$goodsgroup.$grouptime.'</p></div>
			</li>';
		}
	}
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_group')." where it618_ispublic=1 order by it618_order desc");
	while($it618_group_group =	DB::fetch($query)) {
		if(!in_array($it618_group_group['it618_groupid'], $tmpexpiryarr)){
			$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_group['it618_groupid']);
			$grouptime=$it618_group_lang['s330'];
			$groupico=$it618_group_group['it618_ico'];
			
			$goodsgroup='';
			$atitle=$it618_group_lang['s313'];
			if($it618_group_goodstmp = DB::fetch_first("SELECT * FROM ".DB::table('it618_group_goods')." where it618_groupid=".$it618_group_group['it618_groupid']." and it618_state=1 ORDER BY it618_unit")){
				if($wap==1){ 
					$tmpurl=it618_group_getrewrite('group_wap','product@'.$it618_group_goodstmp['id'],'plugin.php?id=it618_group:wap&pagetype=product&cid1='.$it618_group_goodstmp['id']);
					$goodsgroup='<a href="'.$tmpurl.'">'.$atitle.'<img src="source/plugin/it618_group/images/right.png" class="rightimg"></a>';
				}else{
					$tmpurl=it618_group_getrewrite('group_product',$it618_group_goodstmp['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goodstmp['id']);
					$goodsgroup='<a href="'.$tmpurl.'" target="_ablank">'.$atitle.'<img src="source/plugin/it618_group/images/right.png" class="rightimg"></a>';
				}
			}
			
			if($wap==1){ 
				$groupstr.='<tr><td class="tdvipleft">
				<img src="'.$groupico.'" class="groupico" style="-webkit-filter: grayscale(100%);filter: grayscale(100%);"/></td><td class="tdvipright">
				<div>'.$grouptitle.'<p>'.$goodsgroup.$grouptime.'</p></div>
				</td></tr><tr><td class="tdline" colspan="2"></td></tr>';
			}else{
				$groupstr.='<li>
				<img src="'.$groupico.'" class="groupico" style="-webkit-filter: grayscale(100%);filter: grayscale(100%);"/>
				<div>'.$grouptitle.'<p>'.$goodsgroup.$grouptime.'</p></div>
				</li>';
			}
		}
	}
	
	return $groupstr;
}

function it618_group_getgoodsprice($it618_group_goods,$type=''){
	global $_G,$it618_group,$it618_group_lang;
	
	$it618_unit=it618_group_getgoodsunit($it618_group_goods);
	
	$it618_saleprice=floatval($it618_group_goods['it618_saleprice']);
	
	//199<span class="year">Ԫ+1���/��{saleabout}</span>
	if($type=='class'){
		$goodspricestr=$it618_group_lang['s41'].'<span class="year">{saleabout}</span>';
		
		$it618_score=$it618_group_goods['it618_score'];
		if($it618_group_goods['it618_isuser']==1&&$_G['uid']<=0){
			$it618_saleprice='***';
			$it618_score='***';
		}
		
		if($it618_group_goods['it618_saleprice']>0&&$it618_group_goods['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_group_goods['it618_jfid']]['title'];
			$goodspricestr=$it618_saleprice.'<span class="year">'.$it618_group_lang['s22'].'+'.$it618_score.$goodsjfname;
		}else{
			if($it618_group_goods['it618_saleprice']>0){
				$goodspricestr=$it618_saleprice.'<span class="year">'.$it618_group_lang['s22'];
			}
			
			if($it618_group_goods['it618_score']>0){
				$goodsjfname=$_G['setting']['extcredits'][$it618_group_goods['it618_jfid']]['title'];
				$goodspricestr=$it618_score.'<span class="year">'.$goodsjfname;
			}
			
			if($it618_group_goods['it618_saleprice']==0&&$it618_group_goods['it618_score']==0){
				$goodspricestr=$it618_group_lang['s41'].'<span class="year">'.$it618_group_lang['s22'];
			}
		}
		
		$goodspricestr.='/'.$it618_unit.'{saleabout}</span>';
	}else{
		if($it618_group_goods['it618_saleprice']>0&&$it618_group_goods['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_group_goods['it618_jfid']]['title'];
			$goodspricestr='<em>&yen;</em>'.$it618_saleprice.'+'.$it618_score.'<em class="jfname">'.$goodsjfname.'</em>';
		}else{
			if($it618_group_goods['it618_saleprice']>0){
				$goodspricestr='<em>&yen;</em>'.$it618_saleprice;
			}
			
			if($it618_group_goods['it618_score']>0){
				$goodsjfname=$_G['setting']['extcredits'][$it618_group_goods['it618_jfid']]['title'];
				$goodspricestr=$it618_score.'<em class="jfname">'.$goodsjfname.'</em>';
			}
			
			if($it618_group_goods['it618_saleprice']==0&&$it618_group_goods['it618_score']==0){
				$goodspricestr=$it618_group_lang['s41'];
			}
		}	
	}
	
	return $goodspricestr;
}

function it618_group_getgoodsunit($it618_group_goods){
	global $_G,$it618_group,$it618_group_lang;
	
	$it618_unitcount=$it618_group_goods['it618_unitcount'];
	
	if($it618_group_goods['it618_unit']==1)$it618_unit=$it618_unitcount.$it618_group_lang['s60'];
	if($it618_group_goods['it618_unit']==2)$it618_unit=$it618_unitcount.$it618_group_lang['s61'];
	if($it618_group_goods['it618_unit']==3)$it618_unit=$it618_unitcount.$it618_group_lang['s62'];
	if($it618_group_goods['it618_unit']==4)$it618_unit=$it618_unitcount.$it618_group_lang['s63'];
	if($it618_group_goods['it618_unit']==5)$it618_unit=$it618_group_lang['s64'];
	
	return $it618_unit;
}

function it618_group_salejl($saletype,$saleid,$groupid,$days,$uid=0,$bz=''){
	global $_G,$it618_group;
			
	if($uid==0){
		$it618_video_sale=C::t('#it618_video#it618_video_sale')->fetch_by_id($saleid);
		$uid=$it618_video_sale['it618_uid'];
	}
	
	require_once libfile('function/member');
	$member=getuserbyuid($uid, 1);
	$extgroupids = $member['extgroupids'] ? explode("\t", $member['extgroupids']) : array();
	
	$memberfieldforum = C::t('common_member_field_forum')->fetch($uid);
	$groupterms = dunserialize($memberfieldforum['groupterms']);
	unset($memberfieldforum);
	require_once libfile('function/forum');
	
	$extgroupidsarray = array();
	foreach(array_unique(array_merge($extgroupids, array($groupid))) as $extgroupid) {
		if($extgroupid) {
			$extgroupidsarray[] = $extgroupid;
		}
	}
	
	$tmptime = ($groupterms['ext'][$groupid] > TIMESTAMP ? $groupterms['ext'][$groupid] : TIMESTAMP) + $days * 86400;
	$groupterms['ext'][$groupid]=$tmptime;
	
	$grouptermsnew = serialize($groupterms);
	$groupexpirynew = groupexpiry($groupterms);
	$extgroupidsnew = implode("\t", $extgroupidsarray);

	C::t('common_member')->update($uid, array('extgroupids'=>$extgroupidsnew, 'groupexpiry'=>$groupexpirynew));
	if(C::t('common_member_field_forum')->fetch($uid)) {
		C::t('common_member_field_forum')->update($uid, array('groupterms' => $grouptermsnew));
	} else {
		C::t('common_member_field_forum')->insert(array('uid' => $uid, 'groupterms' => $grouptermsnew));
	}
	
	$id = C::t('#it618_group#it618_group_salejl')->insert(array(
		'it618_uid' => $uid,
		'it618_groupid' => $groupid,
		'it618_days' => $days,
		'it618_saletype' => $saletype,
		'it618_saleid' => $saleid,
		'it618_bz' => $bz,
		'it618_time' => $_G['timestamp']
	), true);
	
	it618_group_sendmessage('salejl_user',$id);
	
	if($it618_group_group_user=C::t('#it618_group#it618_group_group_user')->fetch_by_groupid_uid($groupid,$uid)){
		if($it618_group_group_user['it618_etime']!=$tmptime){
			C::t('#it618_group#it618_group_group_user')->update($it618_group_group_user['id'],array(
				'it618_etime' => $tmptime
			));
		}
	}else{
		$id = C::t('#it618_group#it618_group_group_user')->insert(array(
			'it618_uid' => $uid,
			'it618_groupid' => $groupid,
			'it618_etime' => $tmptime
		), true);
	}
}

function it618_group_qrxf($saleid){
	global $_G,$it618_group;
	
	$it618_group_sale=C::t('#it618_group#it618_group_sale')->fetch_by_id($saleid);
	
	$uid=$it618_group_sale['it618_uid'];
	$member=getuserbyuid($uid, 1);
	
	$groupid=$it618_group_sale['it618_groupid'];
			
	$extgroupids = $member['extgroupids'] ? explode("\t", $member['extgroupids']) : array();
	
	$memberfieldforum = C::t('common_member_field_forum')->fetch($uid);
	$groupterms = dunserialize($memberfieldforum['groupterms']);
	unset($memberfieldforum);
	require_once libfile('function/forum');
	
	$extgroupidsarray = array();
	foreach(array_unique(array_merge($extgroupids, array($groupid))) as $extgroupid) {
		if($extgroupid) {
			$extgroupidsarray[] = $extgroupid;
		}
	}
	
	$it618_unitcount=$it618_group_sale['it618_unitcount'];
	$it618_unit=$it618_group_sale['it618_unit'];
	$it618_count=$it618_group_sale['it618_count'];
	
	if($it618_unit==1)$it618_days=$it618_unitcount*$it618_count;
	if($it618_unit==2)$it618_days=$it618_unitcount*$it618_count*30;
	if($it618_unit==3)$it618_days=$it618_unitcount*$it618_count*90;
	if($it618_unit==4)$it618_days=$it618_unitcount*$it618_count*365;
	if($it618_unit==5)$it618_days=$it618_count*365*90;
	
	$groupterms['ext'][$groupid] = ($groupterms['ext'][$groupid] > TIMESTAMP ? $groupterms['ext'][$groupid] : TIMESTAMP) + $it618_days * 86400;
	
	$grouptermsnew = serialize($groupterms);
	$groupexpirynew = groupexpiry($groupterms);
	$extgroupidsnew = implode("\t", $extgroupidsarray);

	C::t('common_member')->update($uid, array('extgroupids'=>$extgroupidsnew, 'groupexpiry'=>$groupexpirynew));
	if(C::t('common_member_field_forum')->fetch($uid)) {
		C::t('common_member_field_forum')->update($uid, array('groupterms' => $grouptermsnew));
	} else {
		C::t('common_member_field_forum')->insert(array('uid' => $uid, 'groupterms' => $grouptermsnew));
	}
	
	if($it618_group_sale['it618_isswitch']==1&&$groupid!=$member['groupid']){

		$memberfieldforum = C::t('common_member_field_forum')->fetch($uid);
		$groupterms = dunserialize($memberfieldforum['groupterms']);
		unset($memberfieldforum);
		$extgroupidsnew = $member['groupid'];
		$groupexpirynew = $groupterms['ext'][$extgroupidsnew];
		foreach($extgroupids as $extgroupid) {
			if($extgroupid && $extgroupid != $groupid) {
				$extgroupidsnew .= "\t".$extgroupid;
			}
		}

		C::t('common_member')->update($uid, array('groupid' => $groupid, 'groupexpiry' => $groupexpirynew, 'extgroupids' => $extgroupidsnew));
	}
	
	if($it618_group_sale['it618_score']>0){
		$tmpscore=($it618_group_sale['it618_score']*$it618_group_sale['it618_count'])-intval($ShopTCBL*($it618_group_sale['it618_score']*$it618_group_sale['it618_count'])/100);
		C::t('common_member_count')->increase($it618_group_shop['it618_uid'], array(
			'extcredits'.$it618_group_sale['it618_jfid'] => $tmpscore)
		);
	}
	
	if($it618_group_sale['it618_jfbl']>0){
		$it618_jfbl=intval($it618_group_sale['it618_jfbl']*$it618_group_sale['it618_price']*$it618_group_sale['it618_count']/100);
		C::t('common_member_count')->increase($it618_group_sale['it618_uid'], array(
			'extcredits'.$it618_group['group_credit'] => $it618_jfbl)
		);
	}
	
	if($it618_group_sale['it618_tuijid']>0){
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
		Union_TuiTC_OK($saleid,$it618_group_shop['it618_uid']);
	}

	$tmpmoney=$it618_group_sale['it618_price']*$it618_group_sale['it618_count']-$it618_group_sale['it618_quanmoney'];
	
	if($tmpmoney>0){
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
		}
		
		if($union_group_isok==1&&$tmpmoney>=$union_group_money){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
			Union_SaleTC('it618_group',$tmpmoney,$it618_group_sale['id'],$it618_group_sale['it618_uid']);
		}
	}
	
	if($it618_group_group_user=C::t('#it618_group#it618_group_group_user')->fetch_by_groupid_uid($it618_group_sale['it618_groupid'],$it618_group_sale['it618_uid'])){
		C::t('#it618_group#it618_group_sale')->update($it618_group_sale['id'],array(
			'it618_type' => 2,
		));
		if($it618_group_sale['it618_pinsaleid']==0){
			it618_group_sendmessage('sale_admin1',$it618_group_sale['id']);
			it618_group_sendmessage('sale_user1',$it618_group_sale['id']);
		}
	}else{
		if($it618_group_sale['it618_pinsaleid']==0){
			it618_group_sendmessage('sale_admin',$it618_group_sale['id']);
			it618_group_sendmessage('sale_user',$it618_group_sale['id']);
		}
	}
}

function it618_group_updategoodscount($it618_group_sale){	
	
	$pid=$it618_group_sale['it618_pid'];
	
	$salecount = C::t('#it618_group#it618_group_sale')->sumcount_by_it618_pid($pid);
	$salemoney = C::t('#it618_group#it618_group_sale')->summoney_by_it618_pid($pid);
	if($salecount=='')$salecount=0;
	if($salemoney=='')$salemoney=0;
	DB::query("update ".DB::table('it618_group_goods')." set it618_salecount=".$salecount.",it618_salemoney=".$salemoney." where id=".$pid);
	DB::query("update ".DB::table('it618_group_goods')." set it618_count=it618_count-1 where it618_count>0 and id=".$pid);
}

function it618_group_getsaleprice($it618_group_sale){
	global $_G,$it618_group,$it618_group_lang;
	
	if($it618_group_sale['it618_price']>0&&$it618_group_sale['it618_score']>0){
		$goodsjfname=$_G['setting']['extcredits'][$it618_group_sale['it618_jfid']]['title'];
		$goodspricestr=$it618_group_sale['it618_price'].$it618_group_lang['s58'].'+'.$it618_group_sale['it618_score'].$goodsjfname;
	}else{
		if($it618_group_sale['it618_price']>0){
			$goodspricestr=$it618_group_sale['it618_price'].$it618_group_lang['s58'];
		}
		
		if($it618_group_sale['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_group_sale['it618_jfid']]['title'];
			$goodspricestr=$it618_group_sale['it618_score'].$goodsjfname;
		}
	}
	
	if($it618_group_sale['it618_quanmoney']>0){
		$goodspricestr.='-'.$it618_group_sale['it618_quanmoney'].$it618_group_lang['s58'];
	}
	
	return $goodspricestr;
}

function it618_group_getsalemoney($it618_group_sale){
	global $_G,$it618_group,$it618_group_lang;
	
	if($it618_group_sale['it618_sfmoney']>0&&$it618_group_sale['it618_sfscore']>0){
		$goodsjfname=$_G['setting']['extcredits'][$it618_group_sale['it618_jfid']]['title'];
		$goodspricestr=$it618_group_sale['it618_sfmoney'].$it618_group_lang['s58'].'+'.$it618_group_sale['it618_sfscore'].$goodsjfname;
	}else{
		if($it618_group_sale['it618_price']>0){
			$goodspricestr=$it618_group_sale['it618_sfmoney'].$it618_group_lang['s58'];
		}
		
		if($it618_group_sale['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_group_sale['it618_jfid']]['title'];
			$goodspricestr=$it618_group_sale['it618_sfscore'].$goodsjfname;
		}
	}
	
	return $goodspricestr;
}

function it618_group_delsalework(){
	DB::query("delete from ".DB::table('it618_group_salework'));
}

function it618_group_getusername($uid){
	return C::t('#it618_group#it618_group_sale')->fetch_username_by_uid($uid);
}


function it618_group_getrewrite($pagetype,$pagevalue,$url,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_group']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_group/config/rewrite.php')){
		return $url;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_group/config/rewrite.php';
	
	if($pagetype=='group_class'){//group_class-{cid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$group_class.$group_class1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{cid}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{cid}",$tmparr[0],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='group_product'){//group_product-{pid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$group_product.$group_product1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{pid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='group_sc'){
		return $group_sc.$urltype;
	}
	
	if($pagetype=='group_wap'){//group_wap-{pagetype}-{cid1}-{cid2}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$group_wap.$group_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid1}-{cid2}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{pagetype}",$pagevalue,$pageurl);
				$pageurl=str_replace("-{cid1}-{cid2}","",$pageurl);
			}
			if(count($tmparr)==2){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("-{cid2}","",$pageurl);
			}
			if(count($tmparr)==3){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[2],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
}

function it618_group_union_getrewrite($pagetype,$pagevalue,$url,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_union']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/rewrite.php')){
		return $url;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_union/config/rewrite.php';
	
	if($pagetype=='union_home'){
		return $union_home.$urltype;
	}
	
	if($pagetype=='union_yq'){//reg-{tuiuid}.html
		$pageurl=$union_yq.$union_yq1;
		
		$pageurl=str_replace("{tuiuid}",$pagevalue,$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='union_quans'){
		return $union_quans.$urltype;
	}
	
	if($pagetype=='union_quan'){//quan-{qid}.html
		$pageurl=$union_quan.$union_quan1;
		
		$pageurl=str_replace("{qid}",$pagevalue,$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='union_tuis'){
		return $union_tuis.$urltype;
	}
	
	if($pagetype=='union_tui'){//union_tui-{tid}.html
		$pageurl=$union_tui.$union_tui1;
		
		$pageurl=str_replace("{tid}",$pagevalue,$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='union_uc'){//union_uc-{pagetype}.html
		$pageurl=$union_uc.$union_uc1;
		
		$pageurl=str_replace("{pagetype}",$pagevalue,$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='union_wap'){//union_wap-{pagetype}-{cid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$union_wap.$union_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid}","",$pageurl);
		}else{
			if(count($tmparr)==2){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid}",$tmparr[1],$pageurl);
			}else{
				$pageurl=str_replace("-{cid}","",$pageurl);
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
}

function it618_group_rewriteurl($uid){
	global $_G;
	if($_G['cache']['plugin']['it618_group']['rewriteurl']==1){
		return 'space-uid-'.$uid.'.html';
	}else{
		return 'home.php?mod=space&uid='.$uid;
	}
}

function it618_group_sendmessage($type,$id,$type1=''){
	global $_G,$creditname,$it618_group_lang;
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_group/config/message.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_group/config/message.php';
	
	$tmpurl=it618_group_getrewrite('group_wap','','plugin.php?id=it618_group:wap');
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].'/';
	
	if($it618_isok==1){
		
		if($it618_isok_admin==1){
			if($type=='sale_admin'&&$it618_body_sale_admin_isok==1){
				$tel=$it618_tel_admin;
				
				$it618_group_sale = C::t('#it618_group#it618_group_sale')->fetch_by_id($id);
				$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_sale['it618_pid']);
				$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
				$it618_unit=it618_group_getgoodsunit($it618_group_goods);
				$pname=$grouptitle.' '.$it618_unit;
				$purl=it618_group_getrewrite('group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id']);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_sale_admin_tplid_wxsms;
				$body_wxsms=$it618_body_sale_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_group_getusername($it618_group_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$pname,$tmpvalue);
						$tmpvalue=str_replace("{pprice}",it618_group_getsalemoney($it618_group_sale),$tmpvalue);
						$tmpvalue=str_replace("{purl}",$purl,$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_group_sale['it618_time']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_group_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_sale_admin;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_group_getusername($it618_group_sale['it618_uid']),$Body);
				$Body=str_replace("{pname}",$pname,$Body);
				$Body=str_replace("{pprice}",it618_group_getsalemoney($it618_group_sale),$Body);
				$Body=str_replace("{purl}",$purl,$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_group_sale['it618_time']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_group_getusername($it618_group_sale['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.$pname.'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.it618_group_getsalemoney($it618_group_sale).'",';
					
					$tmparr=explode("{purl}",$ALDYBody);
					if(count($tmparr)>1)$param.='"purl":"'.$purl.'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_group_sale['it618_time']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='sale1_admin'&&$it618_body_sale1_admin_isok==1){
				$tel=$it618_tel_admin;
				
				$it618_group_sale = C::t('#it618_group#it618_group_sale')->fetch_by_id($id);
				$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_sale['it618_pid']);
				$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
				$it618_unit=it618_group_getgoodsunit($it618_group_goods);
				$pname=$grouptitle.' '.$it618_unit;
				$purl=it618_group_getrewrite('group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id']);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_sale1_admin_tplid_wxsms;
				$body_wxsms=$it618_body_sale1_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_group_getusername($it618_group_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$pname,$tmpvalue);
						$tmpvalue=str_replace("{pprice}",it618_group_getsalemoney($it618_group_sale),$tmpvalue);
						$tmpvalue=str_replace("{purl}",$purl,$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_group_sale['it618_time']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_group_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_sale1_admin;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_group_getusername($it618_group_sale['it618_uid']),$Body);
				$Body=str_replace("{pname}",$pname,$Body);
				$Body=str_replace("{pprice}",it618_group_getsalemoney($it618_group_sale),$Body);
				$Body=str_replace("{purl}",$purl,$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_group_sale['it618_time']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale1_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_group_getusername($it618_group_sale['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.$pname.'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.it618_group_getsalemoney($it618_group_sale).'",';
					
					$tmparr=explode("{purl}",$ALDYBody);
					if(count($tmparr)>1)$param.='"purl":"'.$purl.'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_group_sale['it618_time']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sale_user'&&$it618_body_sale_user_isok==1){
			$it618_group_sale = C::t('#it618_group#it618_group_sale')->fetch_by_id($id);
			$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_sale['it618_pid']);
			$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
			$it618_unit=it618_group_getgoodsunit($it618_group_goods);
			$pname=$grouptitle.' '.$it618_unit;
			$purl=it618_group_getrewrite('group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id']);
			
			$uid=$it618_group_sale['it618_uid'];
			if($IsMembers==1)$tel = C::t('#it618_members#it618_members_user')->fetch_tel_by_uid($uid);
			
			$tplid_wxsms=$it618_body_sale_user_tplid_wxsms;
			$body_wxsms=$it618_body_sale_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_group_getusername($it618_group_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{pname}",$pname,$tmpvalue);
					$tmpvalue=str_replace("{pprice}",it618_group_getsalemoney($it618_group_sale),$tmpvalue);
					$tmpvalue=str_replace("{purl}",$purl,$tmpvalue);
					$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_group_sale['it618_time']),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_group_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
				
			$Body=$it618_body_sale_user;
			
			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_group_getusername($it618_group_sale['it618_uid']),$Body);
			$Body=str_replace("{pname}",$pname,$Body);
			$Body=str_replace("{pprice}",it618_group_getsalemoney($it618_group_sale),$Body);
			$Body=str_replace("{purl}",$purl,$Body);
			$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_group_sale['it618_time']),$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sale_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_group_getusername($it618_group_sale['it618_uid']).'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.$pname.'",';
				
				$tmparr=explode("{pprice}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pprice":"'.it618_group_getsalemoney($it618_group_sale).'",';
				
				$tmparr=explode("{purl}",$ALDYBody);
				if(count($tmparr)>1)$param.='"purl":"'.$purl.'",';
				
				$tmparr=explode("{time}",$ALDYBody);
				if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_group_sale['it618_time']).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}

		}
		
		if($type=='sale1_user'&&$it618_body_sale1_user_isok==1){
			$it618_group_sale = C::t('#it618_group#it618_group_sale')->fetch_by_id($id);
			$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_sale['it618_pid']);
			$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
			$it618_unit=it618_group_getgoodsunit($it618_group_goods);
			$pname=$grouptitle.' '.$it618_unit;
			$purl=it618_group_getrewrite('group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id']);
			
			$uid=$it618_group_sale['it618_uid'];
			if($IsMembers==1)$tel = C::t('#it618_members#it618_members_user')->fetch_tel_by_uid($uid);
			
			$tplid_wxsms=$it618_body_sale1_user_tplid_wxsms;
			$body_wxsms=$it618_body_sale1_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_group_getusername($it618_group_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{pname}",$pname,$tmpvalue);
					$tmpvalue=str_replace("{pprice}",it618_group_getsalemoney($it618_group_sale),$tmpvalue);
					$tmpvalue=str_replace("{purl}",$purl,$tmpvalue);
					$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_group_sale['it618_time']),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_group_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
				
			$Body=$it618_body_sale1_user;
			
			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_group_getusername($it618_group_sale['it618_uid']),$Body);
			$Body=str_replace("{pname}",$pname,$Body);
			$Body=str_replace("{pprice}",it618_group_getsalemoney($it618_group_sale),$Body);
			$Body=str_replace("{purl}",$purl,$Body);
			$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_group_sale['it618_time']),$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sale1_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_group_getusername($it618_group_sale['it618_uid']).'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.$pname.'",';
				
				$tmparr=explode("{pprice}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pprice":"'.it618_group_getsalemoney($it618_group_sale).'",';
				
				$tmparr=explode("{purl}",$ALDYBody);
				if(count($tmparr)>1)$param.='"purl":"'.$purl.'",';
				
				$tmparr=explode("{time}",$ALDYBody);
				if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_group_sale['it618_time']).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}

		}
		
		if($type=='salejl_user'&&$it618_body_salejl_user_isok==1){
			$it618_group_salejl = C::t('#it618_group#it618_group_salejl')->fetch_by_id($id);
			$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_salejl['it618_groupid']);
			$vipname=$grouptitle;
			
			if($it618_group_salejl['it618_saletype']=='videopid'){
				$it618_video_sale=C::t('#it618_video#it618_video_sale')->fetch_by_id($it618_group_salejl['it618_saleid']);
				$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
				$aboutstr=$it618_group_lang['s253'].$it618_group_salejl['it618_saleid'].' '.$it618_video_goods['it618_name'];
			}
			
			if($it618_group_salejl['it618_saletype']=='sgzs'){
				$aboutstr=$it618_group_salejl['it618_bz'];
			}
			
			$uid=$it618_group_salejl['it618_uid'];
			if($IsMembers==1)$tel = C::t('#it618_members#it618_members_user')->fetch_tel_by_uid($uid);
			
			$tplid_wxsms=$it618_body_salejl_user_tplid_wxsms;
			$body_wxsms=$it618_body_salejl_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_group_getusername($it618_group_salejl['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{vipname}",$vipname,$tmpvalue);
					$tmpvalue=str_replace("{days}",$it618_group_salejl['it618_days'],$tmpvalue);
					$tmpvalue=str_replace("{bz}",$aboutstr,$tmpvalue);
					$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_group_salejl['it618_time']),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_group_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
				
			$Body=$it618_body_salejl_user;
			
			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_group_getusername($it618_group_salejl['it618_uid']),$Body);
			$Body=str_replace("{vipname}",$vipname,$Body);
			$Body=str_replace("{days}",$it618_group_salejl['it618_days'],$Body);
			$Body=str_replace("{bz}",$bz,$Body);
			$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_group_salejl['it618_time']),$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_salejl_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_group_getusername($it618_group_salejl['it618_uid']).'",';
				
				$tmparr=explode("{vipname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"vipname":"'.$vipname.'",';
				
				$tmparr=explode("{days}",$ALDYBody);
				if(count($tmparr)>1)$param.='"days":"'.$it618_group_salejl['it618_days'].'",';
				
				$tmparr=explode("{bz}",$ALDYBody);
				if(count($tmparr)>1)$param.='"bz":"'.$bz.'",';
				
				$tmparr=explode("{time}",$ALDYBody);
				if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_group_salejl['it618_time']).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}

		}
		
		if($type=='tx_user'&&$it618_body_tx_user_isok==1){
			$it618_group_group_user = C::t('#it618_group#it618_group_group_user')->fetch_by_id($id);
			$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_group_user['it618_groupid']);
			
			$query = DB::query("SELECT * FROM ".DB::table('it618_group_goods')." where it618_groupid=".$it618_group_group_user['it618_groupid']." and it618_state=1 ORDER BY it618_unit");
			while($it618_group_goodstmp = DB::fetch($query)) {
				$purl=it618_group_getrewrite('group_product',$it618_group_goodstmp['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goodstmp['id']);
				break;
			}
			
			$days=round(($it618_group_group_user['it618_etime']-$_G['timestamp'])/(3600*24),2);
			
			$uid=$it618_group_group_user['it618_uid'];
			if($IsMembers==1)$tel = C::t('#it618_members#it618_members_user')->fetch_tel_by_uid($uid);
			
			$tplid_wxsms=$it618_body_tx_user_tplid_wxsms;
			$body_wxsms=$it618_body_tx_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_group_getusername($it618_group_group_user['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{vipname}",$grouptitle,$tmpvalue);
					$tmpvalue=str_replace("{days}",$days,$tmpvalue);
					$tmpvalue=str_replace("{purl}",$purl,$tmpvalue);
					$tmpvalue=str_replace("{etime}",date('Y-m-d H:i:s', $it618_group_group_user['it618_etime']),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_group_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$Body=$it618_body_tx_user;		

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_group_getusername($it618_group_group_user['it618_uid']),$Body);
			$Body=str_replace("{vipname}",$grouptitle,$Body);
			$Body=str_replace("{days}",$days,$Body);
			$Body=str_replace("{purl}",$purl,$Body);
			$Body=str_replace("{etime}",date('Y-m-d H:i:s', $it618_group_group_user['it618_etime']),$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_tx_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_group_getusername($it618_group_group_user['it618_uid']).'",';
				
				$tmparr=explode("{vipname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"name":"'.$grouptitle.'",';
				
				$tmparr=explode("{days}",$ALDYBody);
				if(count($tmparr)>1)$param.='"days":"'.$days.'",';
				
				$tmparr=explode("{purl}",$ALDYBody);
				if(count($tmparr)>1)$param.='"purl":"'.$purl.'",';
				
				$tmparr=explode("{etime}",$ALDYBody);
				if(count($tmparr)>1)$param.='"etime":"'.date('Y-m-d H:i:s', $it618_group_group_user['it618_etime']).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($Body!=''||(count($param_wxsms)>0&&$uid!='')){
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_group/message.func.php';
			
			if(count($param_wxsms)>0&&$uid!=''){
				$tmparr=explode(",",$uid);
				for($i=0;$i<count($tmparr);$i++){
					$wxsms=sendSMS_WX($tmparr[$i],$url_this.$tmpurl,$tplid_wxsms,$param_wxsms);
				}
			}
			
			if($wxsms=='true')return 1;
			
			if($tel!=''&&$wxsms!='true'){
				$Body=str_replace('$','',$Body);
	
				if($it618_type=='smsbao'){
					if($it618_smsbaosign!='')$it618_smsbaosign=$it618_group_lang['s1860'].$it618_smsbaosign.$it618_group_lang['s1861'];
					$dxsms=sendSMS($it618_tel,$it618_password,$tel,$it618_smsbaosign.$Body);
				}else{
					$dxsms=sendSMS_ALi($tel,$Body,$it618_sign,$tplid,$param,$it618_type);
				}
			}
			
			if($dxsms=="0"||$dxsms=="ok")return 2;
			return 0;

		}
	}
}

function it618_group_delfile($dirName){
}

function it618_group_del_dir($dir,$type=0){
    if(is_dir($dir)){
        foreach(scandir($dir) as $row){
            if($row == '.' || $row == '..'){
                continue;
            }
            $path = $dir .'/'. $row;
            if(filetype($path) == 'dir'){
            }else{
            }
        }
        if($type==1);
    }else{
        return false;
    }
}

function it618_group_getsize($size) { 
	$format = 'M';
	$size1=$size;
    $size /= pow(1024, 2); 
	$getsize=number_format($size, 2);
	if($getsize<1){
		$format = 'K';
		$size1 /= pow(1024, 1); 
		$getsize=number_format($size1, 2);
	}
	
    return $getsize.$format;  
} 

function it618_group_dirsize($dir) { 
	@$dh = opendir($dir); 
	$size = 0; 
	while ($file = @readdir($dh)) { 
	if ($file != "." and $file != "..") { 
	$path = $dir."/".$file; 
	if (is_dir($path)) { 
	$size += it618_group_dirsize($path); 
	} elseif (is_file($path)) { 
	$size += filesize($path); 
	} 
	} 
	} 
	@closedir($dh); 
	return $size; 
}

function it618_group_discuz_uc_avatar($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   if(empty($GLOBALS['avatarmethod'])) {
		return $returnsrc ? UC_API.'/avatar.php?uid='.$uid.'&size='.$size : '<img src="'.UC_API.'/avatar.php?uid='.$uid.'&size='.$size.'" />';
	   } else {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	   }
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_group_utftogbk($strcontent){
	$strcontent=dhtmlspecialchars($strcontent);
	
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_group_gbktoutf($strcontent);
	}
}

function it618_group_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function it618_group_getfileext($filestr){
	$file_ext=strtolower(substr($filestr,strrpos($filestr, '.')+1)); 
	$tmparr=explode("?",$file_ext);
	return $tmparr[0];
}

function it618_group_getgoodspic($pid,$it618_picbig,$i=0){
	$file_ext=it618_group_getfileext($it618_picbig);
	
	return 'source/plugin/it618_group/kindeditor/data/smallimage/goods'.$pid.'_'.md5($it618_picbig).'.'.$file_ext.'?'.substr(md5($it618_picbig),0,6);
}

function it618_group_getwapppic($pid,$get_it618_picbig,$type=1){
	$file_ext=it618_group_getfileext($get_it618_picbig); 
	
	if($shopid=='wapad'){
		$file_ext=it618_group_getfileext($get_it618_picbig); 
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/smallimage/wapad'.$pid.'.'.$file_ext;
		
		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {
				
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/smallimage/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			it618_group_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,280,1);
		}
		
		$it618_smallurl='source/plugin/it618_group/kindeditor/data/smallimage/wapad'.$pid.'.'.$file_ext;
	}else{
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/smallimages/goods'.$pid.'_'.md5($get_it618_picbig).'.'.$file_ext;

		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {
				
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/smallimages/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/smallimages/goods'.$pid.'_'.md5($get_it618_picbig).'.'.$file_ext;
			it618_group_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,360,1);
		}
		
		$it618_smallurl='source/plugin/it618_group/kindeditor/data/smallimages/goods'.$pid.'_'.md5($get_it618_picbig).'.'.$file_ext;
	}
	
	return $it618_smallurl.'?'.substr(md5($get_it618_picbig),0,6);
}

function it618_group_hex2rgb($hexColor) {
	$color = str_replace('#', '', $hexColor);
	if (strlen($color) > 3) {
		$rgb = array(
			'r' => hexdec(substr($color, 0, 2)),
			'g' => hexdec(substr($color, 2, 2)),
			'b' => hexdec(substr($color, 4, 2))
		);
	} else {
		$color = $hexColor;
		$r = substr($color, 0, 1) . substr($color, 0, 1);
		$g = substr($color, 1, 1) . substr($color, 1, 1);
		$b = substr($color, 2, 1) . substr($color, 2, 1);
		$rgb = array(
			'r' => hexdec($r),
			'g' => hexdec($g),
			'b' => hexdec($b)
		);
	}
	return $rgb;
}

function it618_group_imagetosmall($bigimagepath,$smallimagepath,$file_ext,$width,$height=0,$type=0){
	//��ΪPHPֻ�ܶ���Դ���в���������Ҫ����Ҫ�������ŵ�ͼƬ���п���������Ϊ�µ���Դ 
	if($file_ext=='jpg'||$file_ext=='jpeg')$src=imagecreatefromjpeg($bigimagepath); 
	if($file_ext=='png')$src=imagecreatefrompng($bigimagepath); 
	if($file_ext=='gif')$src=imagecreatefromgif($bigimagepath); 
	
	//ȡ��ԴͼƬ�Ŀ��Ⱥ͸߶� 
	$size_src=@getimagesize($bigimagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$maxָ�����ų��������Ŀ��ȣ�Ҳ�п����Ǹ߶ȣ�
	
	if($type==0){
		$max=$width;
		//�������ֵΪ300�������һ���ߵĳ��ȣ��õ����ź��ͼƬ���Ⱥ͸߶� 
		if($w > $h){ 
		   $w=$max;
		   $h=$h*($max/$size_src['0']); 
		}else{ 
		   $h=$max;
		   $w=$w*($max/$size_src['1']); 
		} 
	}else{
		$w=$width;
		$h=$height;
	}
	
	//����һ��$w����$h�ߵ����ͼƬ��Դ 
	$image=imagecreatetruecolor($w, $h); 
	 
	//�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h�� 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if($file_ext=='jpg'||$file_ext=='jpeg')imagejpeg($image,$smallimagepath); 
	if($file_ext=='png')imagepng($image,$smallimagepath); 
	if($file_ext=='gif')imagegif($image,$smallimagepath); 
	@chmod($smallimagepath, 0644);
	
	//������Դ 
	imagedestroy($image); 
}

function it618_group_filedown($file_path,$file_name,$file_ext) {
	$tmparr=explode("://",$file_path);
	if(count($tmparr)>1){
		$info = get_headers($file_path, true);
		$file_size = $info['Content-Length'];
		readfile($file_path);
	}else{
		$file_path = iconv('utf-8', 'gb2312', $file_path);
		if (!file_exists($file_path)) {
		  echo 'err';exit;
		}
		$file_size = filesize($file_path);
		$fp = fopen($file_path, 'r');
		$buffer = 1024;
		$file_count = 0;
		while (!feof($fp) && ($file_size-$file_count>0)) {
		  $file_data = fread($fp, $buffer);
		  $file_count += $buffer;
		  echo $file_data;
		}
		fclose($fp);
	}
	
	if($file_ext=='gif'||$file_ext=='jpg'||$file_ext=='jpeg'||$file_ext=='png'){
		header("Content-type: image/$file_ext");
	}else{
		header("Content-type: application/octet-stream");
		header("Accept-Ranges: bytes");
		header("Accept-Length: {$file_size}");
		header("Content-Disposition: attachment;filename={$file_name}");
	}
	
	if(count($tmparr)>1){
		readfile($file_path);
	}else{
		$fp = fopen($file_path, 'r');
		$buffer = 1024;
		$file_count = 0;
		while (!feof($fp) && ($file_size-$file_count>0)) {
		  $file_data = fread($fp, $buffer);
		  $file_count += $buffer;
		  echo $file_data;
		}
		fclose($fp);
	}
}

function group_is_mobile(){ 
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}

?>