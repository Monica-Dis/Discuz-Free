<?php
 /**
 *	�����Ŷӣ�DisM.Taobao.Com
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;

$it618_group = $_G['cache']['plugin']['it618_group'];
$metakeywords = $it618_group['seokeywords'];
$metadescription = $it618_group['seodescription'];
$sitetitle=$it618_group['seotitle'];

require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';

$waphome=it618_group_getrewrite('group_wap','','plugin.php?id=it618_group:wap');
$wapu=it618_group_getrewrite('group_wap','u@0','plugin.php?id=it618_group:wap&pagetype=u');

$tmparr=explode($_G['siteurl'],$_SERVER['HTTP_REFERER']);

$stylecount=C::t('#it618_group#it618_group_wapstyle')->count_by_isok_search();
$it618_group_wapstyle=C::t('#it618_group#it618_group_wapstyle')->fetch_by_isok_search();

if(isset($_GET['pagetype'])){
	$pagetypearray = array('class', 'product', 'pin', 'u');
	$pagetype = !in_array($_GET['pagetype'], $pagetypearray) ? 'class' : $_GET['pagetype'];
}else{
	$pagetype='class';
	$navtitle=$sitetitle;
}

$n=0;
$query = DB::query("SELECT * FROM ".DB::table('it618_group_bottomnav')." where it618_order<>0 ORDER BY it618_order");
while($it618_group_bottomnav = DB::fetch($query)) {	
	$it618_url=$it618_group_bottomnav['it618_url'];
	$iscur=0;
	
	$tmpurlarr1=explode("{wapclass}",$it618_url);
	$tmpurl=it618_group_getrewrite('group_wap','','plugin.php?id=it618_group:wap');
	$it618_url=str_replace("{wapclass}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='class'){
			$iscur=1;
		}
	}
	
	if($it618_group_bottomnav['id']==5)$it618_url=it618_group_getrewrite('group_wap','u@0','plugin.php?id=it618_group:wap&pagetype=u');
	
	if($iscur==0){
		$REQUEST_URI=str_replace("/","",$_SERVER['REQUEST_URI']);
		$REQUEST_URI=str_replace("?mobile=2","",$REQUEST_URI);
		$REQUEST_URI=str_replace("&mobile=2","",$REQUEST_URI);
		if($REQUEST_URI==$it618_url){
			$iscur=1;
		}
	}
	
	if($iscur==1){
		$it618_img=$it618_group_bottomnav['it618_curimg'];
		if($it618_img=='')$it618_img=$it618_group_bottomnav['it618_img'];
		$it618_title='<font color="'.$it618_group_bottomnav['it618_color'].'">'.$it618_group_bottomnav['it618_title'].'</font>';
	}else{
		$it618_img=$it618_group_bottomnav['it618_img'];
		$it618_title=$it618_group_bottomnav['it618_title'];
	}
	
	if($it618_group_bottomnav['id']==1){
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;" class="mymenu"><a href="javascript:" style="color:#666"><img src="'.$it618_group_bottomnav['it618_img'].'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}else{
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;"><a href="'.$it618_url.'" style="color:#666"><img src="'.$it618_img.'" height="23" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}

	$n=$n+1;
}

$n=100/$n;
$bottomnav=str_replace("it618width","width:$n%",$bottomnav);

$wap=1;

$urlarr=explode("https:",$_G['siteurl']);
if(count($urlarr)==1){
	$thisurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}else{
	$thisurl = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}
$thisurl=str_replace("?mobile=2","",$thisurl);
$thisurl=str_replace("&mobile=2","",$thisurl);

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;

if($iswx==1){
	$wx_appid=trim($it618_group['group_appid']);
	$wx_secret=trim($it618_group['group_appsecret']);
	if($wx_appid==''&&$wx_secret==''){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
		}
	}
}

if($wx_appid!=''&&$wx_secret!=''){
	if($pagetype=='class'){
		$cid=intval($_GET['cid1']);
		$it618_group_class = C::t('#it618_group#it618_group_class')->fetch_by_id($cid);
		$wxshare_title=$it618_group_class['it618_name'];
		$wxshare_imgUrl=$it618_group['group_wxlogo'];
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_group_class['it618_about'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$_G['siteurl'].it618_group_getrewrite('group_class',$cid,'plugin.php?id=it618_group:class&cid='.$cid);
		
	}elseif($pagetype=='product'){
		$pid=intval($_GET['cid1']);
		$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($pid);
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
		$it618_unit=it618_group_getgoodsunit($it618_group_goods);
		$wxshare_title=$grouptitle.' '.$it618_unit;
		$wxshare_imgUrl=$it618_group_group['it618_ico'];
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_group_group['it618_power'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		if($_GET['e']!=''){
			$wxshare_link=$_G['siteurl'].it618_group_getrewrite('group_wap','product@'.$it618_group_goods['id'],'plugin.php?id=it618_group:wap&pagetype=product&cid1='.$it618_group_goods['id'].'&e='.$_GET['e'],'?e='.$_GET['e']);
		}else{
			$wxshare_link=$_G['siteurl'].it618_group_getrewrite('group_wap','product@'.$it618_group_goods['id'],'plugin.php?id=it618_group:wap&pagetype=product&cid1='.$it618_group_goods['id']);
		}
		
	}else{
		$wxshare_title=$it618_group['seotitle'];
		
		if($it618_group['group_wxlogo']!=''){
			$wxshare_imgUrl=$it618_group['group_wxlogo'];
		}else{
			$wxshare_imgUrl=$it618_group['group_logo'];
			$tmparr=explode('src="',$wxshare_imgUrl);
			$tmparr1=explode('"',$tmparr[1]);
			$wxshare_imgUrl=$tmparr1[0];
		}
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_group['seodescription'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$_G['siteurl'].it618_group_getrewrite('group_wap','','plugin.php?id=it618_group:wap');
	}
	
	if($wxshare_title!=''){
		$isshare=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_group/wxshare.php';
		$wxshare = new JSSDK($wx_appid, $wx_secret, $thisurl);
		$signPackage = $wxshare->getSignPackage();
	}
}

$wapbottomsubnav=C::t('#it618_group#it618_group_set')->getsetvalue_by_setname('wapbottomsubnav');
$wapbottomsubnavdefault=C::t('#it618_group#it618_group_set')->getsetvalue_by_setname('wapbottomsubnavdefault');
$footer_mall_wap=C::t('#it618_group#it618_group_set')->getsetvalue_by_setname('footer_mall_wap');

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	$getapplogin=it618_members_getapplogin($_GET['id']);
	if($appurl=it618_members_apploginok($_GET['token'])){
		dheader("location:$appurl");
	}
}

require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
$it618_group_wapad=it618_group_getad($_GET['id'],1);

require_once DISCUZ_ROOT.'./source/plugin/it618_group/wap/'.$pagetype.'.inc.php';
?>