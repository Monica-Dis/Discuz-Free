<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function YunPrint($shoptype,$shopid,$saleid,$saletype=''){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_group/config/feieyun.php')){
		require_once DISCUZ_ROOT.'./source/plugin/it618_group/config/feieyun.php';
	}
	
	if($feieyun_isok!=1)return;

	$query = DB::query("SELECT * FROM ".DB::table('it618_group_printshop')." where it618_shoptype='$shoptype' and it618_shopid=$shopid and it618_isok=1");
	while($it618_group_printshop = DB::fetch($query)) {
		$pridarr[]=$it618_group_printshop['it618_prid'];
	}
	
	if(count($pridarr)==0)return;
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
	
	$tmpprint="<BR>";
	
	if($shoptype=='waimai'){
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_waimai/function.func.php';
		if($it618_waimai_gwcsale_main = C::t('#it618_waimai#it618_waimai_gwcsale_main')->fetch_by_id($saleid)){
			$username=it618_waimai_getusername($it618_waimai_gwcsale_main['it618_uid']);
			$it618_waimai_waimai=C::t('#it618_waimai#it618_waimai_waimai')->fetch_by_id($it618_waimai_gwcsale_main['it618_shopid']);
			
			$content=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1124'].$it618_waimai_lang['s1152'].$it618_waimai_gwcsale_main['id'].$tmpprint;
	
			$content.=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1125'].$it618_waimai_lang['s1152'].$it618_waimai_waimai['it618_name'].$tmpprint;
			
			$content.=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1134'].$it618_waimai_lang['s1152'].$username.' '.$it618_waimai_gwcsale_main['it618_tel'].' '.$it618_waimai_gwcsale_main['it618_name'].$tmpprint;
			
			$content.=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1119'].$it618_waimai_lang['s1152'].$it618_waimai_gwcsale_main['it618_lbsaddr'].' '.$it618_waimai_gwcsale_main['it618_addr'].$tmpprint;
			
			if($it618_waimai_gwcsale_main['it618_bz']!='')$content.=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1108'].$it618_waimai_lang['s1152'].$it618_waimai_gwcsale_main['it618_bz'].$tmpprint;
			
			$content.=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1135'].$it618_waimai_lang['s1152'].date('Y-m-d H:i:s', $it618_waimai_gwcsale_main['it618_time']).$tmpprint;
			
			$content.=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1127'].$it618_waimai_lang['s1152'].$it618_waimai_gwcsale_main['it618_money'].$tmpprint;
			
			if($it618_waimai_gwcsale_main['it618_mjmoney']>0)$content.=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1105'].$it618_waimai_lang['s1152'].$it618_waimai_gwcsale_main['it618_mjmoney'].$tmpprint;
			
			$content.=$it618_waimai_lang['s1151'].$it618_waimai_lang['s1128'].$it618_waimai_lang['s1152'].$it618_waimai_gwcsale_main['it618_yunfei'].$tmpprint;
			
			$content.="---------------------------------------------------".$tmpprint;
			
			foreach(C::t('#it618_waimai#it618_waimai_sale')->fetch_all_by_it618_gwcid($gwcid) as $it618_waimai_sale) {
				$it618_waimai_goods = C::t('#it618_waimai#it618_waimai_goods')->fetch_by_id($it618_waimai_sale['it618_pid']);
				
				$gtypename='';
				if($it618_waimai_sale['it618_gtypeid']>0){
					$gtypename1 = C::t('#it618_waimai#it618_waimai_goods_type')->fetch_it618_name_by_id($it618_waimai_sale['it618_gtypeid']);
					$gtypename = '<font color=red>'.$gtypename1.'</font> ';
					
					$it618_waimai_goods_type = C::t('#it618_waimai#it618_waimai_goods_type')->fetch_by_id($it618_waimai_sale['it618_gtypeid']);
					$it618_uprice=$it618_waimai_goods_type['it618_uprice'];
					$it618_zsscore=$it618_waimai_goods_type['it618_zsscore'];
				}else{
					$it618_uprice=$it618_waimai_goods['it618_uprice'];
					$it618_zsscore=$it618_waimai_goods['it618_zsscore'];
				}
				
				$content.=$it618_waimai_lang['s1151'].$it618_waimai_goods['it618_name'].' '.$gtypename1.$it618_waimai_lang['s1152'].' '.$it618_waimai_lang['s1142'].$it618_waimai_sale['it618_count'].' '.$it618_waimai_lang['s1143'].$it618_uprice.$tmpprint;

			}
		}
	}
	
	if($shoptype=='brand'){
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_brand/function.func.php';
		
		if($saletype=='gwc'){
			if($it618_brand_gwcsale_main = C::t('#it618_brand#it618_brand_gwcsale_main')->fetch_by_id($saleid)){
				$username=it618_brand_getusername($it618_brand_gwcsale_main['it618_uid']);
				$it618_brand_brand=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_brand_gwcsale_main['it618_shopid']);

				$content=$it618_brand_lang['s1860'].$it618_brand_lang['s1971'].$it618_brand_lang['s1861'].$it618_brand_gwcsale_main['id'].$tmpprint;
		
				$content.=$it618_brand_lang['s1860'].$it618_brand_lang['s51'].$it618_brand_lang['s1861'].$it618_brand_brand['it618_name'].$tmpprint;
				
				$content.=$it618_brand_lang['s1860'].$it618_brand_lang['s51'].$it618_brand_lang['s1861'].date('Y-m-d H:i:s', $it618_brand_gwcsale_main['it618_time']).$tmpprint;
				
				$content.="---------------------------------------------------".$tmpprint;
				
				$query = DB::query("SELECT * FROM ".DB::table('it618_brand_sale')." where it618_gwcid=$saleid and it618_shopid=$shopid");
				while($it618_brand_sale = DB::fetch($query)) {
					$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
					
					$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
					
					if($it618_brand_sale['it618_saletype']==1)$saletypestr=it618_brand_getlang('s1245');
					if($it618_brand_sale['it618_saletype']==2){
						$saletypestr=it618_brand_getlang('s1246').$it618_addr;
					}
					if($it618_brand_sale['it618_saletype']==3)$saletypestr=it618_brand_getlang('s1247');
					
					if($it618_brand_sale['it618_saletype']==5)$saletypestr=it618_brand_getlang('s1658');
					
					if($it618_brand_sale['it618_saletype']==6)$saletypestr=it618_brand_getlang('s857').' '.$it618_brand_sale['it618_prepaybl'].'%';
					
					$content.=$it618_brand_goods['it618_name'].' '.$gtypename1.' '.$saletypestr.' '.$it618_brand_sale['it618_count'].$it618_brand_sale['it618_unit'].' '.$tmpprint;
	
				}
			}
		}else{
			if($it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($saleid)){
				$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
						
				$gtypename = C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
				
				if($it618_brand_sale['it618_saletype']==1)$saletypestr=it618_brand_getlang('s1245');
				if($it618_brand_sale['it618_saletype']==2){
					$saletypestr=it618_brand_getlang('s1246').$it618_addr;
				}
				if($it618_brand_sale['it618_saletype']==3)$saletypestr=it618_brand_getlang('s1247');
				
				if($it618_brand_sale['it618_saletype']==5)$saletypestr=it618_brand_getlang('s1658');
				
				if($it618_brand_sale['it618_saletype']==6)$saletypestr=it618_brand_getlang('s857').' '.$it618_brand_sale['it618_prepaybl'].'%';
				
				$content.=$it618_brand_goods['it618_name'].' '.$gtypename1.' '.$saletypestr.' '.$it618_brand_sale['it618_count'].$it618_brand_sale['it618_unit'].' '.$tmpprint;
			}
		}
	}
	
	if($shoptype=='tuan'){
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_tuan/function.func.php';
		
		if($saletype=='gwc'){
			if($it618_tuan_gwcsale_main = C::t('#it618_tuan#it618_tuan_gwcsale_main')->fetch_by_id($saleid)){
				$username=it618_tuan_getusername($it618_tuan_gwcsale_main['it618_uid']);
				$it618_tuan_shop=C::t('#it618_brand#it618_brand_brand')->fetch_by_id($it618_tuan_gwcsale_main['it618_shopid']);

				$content=$it618_tuan_lang['s1860'].$it618_tuan_lang['t796'].$it618_tuan_lang['s1861'].$it618_tuan_gwcsale_main['id'].$tmpprint;
		
				$content.=$it618_tuan_lang['s1860'].$it618_tuan_lang['s585'].$it618_tuan_lang['s1861'].$it618_tuan_shop['it618_name'].$tmpprint;
				
				$content.=$it618_tuan_lang['s1860'].$it618_tuan_lang['s228'].$it618_tuan_lang['s1861'].date('Y-m-d H:i:s', $it618_tuan_gwcsale_main['it618_time']).$tmpprint;
				
				$content.="---------------------------------------------------".$tmpprint;
				
				$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_sale')." where it618_gwcid=$saleid and it618_shopid=$shopid");
				while($it618_tuan_sale = DB::fetch($query)) {
					$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
					
					$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
					
					$content.=$it618_tuan_goods['it618_name'].' '.$gtypename1.' '.$saletypestr.' '.$it618_tuan_sale['it618_count'].$it618_tuan_sale['it618_unit'].' '.$tmpprint;
	
				}
			}
		}else{
			if($it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($saleid)){
						
				$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
					
				$gtypename = C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
					
				$content.=$it618_tuan_goods['it618_name'].' '.$gtypename1.' '.$saletypestr.' '.$it618_tuan_sale['it618_count'].$it618_tuan_sale['it618_unit'].' '.$tmpprint;
			}
		}
	}
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/feieyun/function.func.php';
	for($i=0;$i<count($pridarr);$i++){
		$prid=$pridarr[$i];
		$it618_group_print = C::t('#it618_group#it618_group_print')->fetch_by_id($prid);
		$printreturn=printMsg($it618_group_print['it618_sn'],$content,1);
		
		C::t('#it618_group#it618_group_printsale')->insert(array(
			'it618_prid' => $prid,
			'it618_shoptype' => $shoptype,
			'it618_shopid' => $shopid,
			'it618_saleid' => $saleid,
			'it618_printsaleid' => $printreturn['data'],
			'it618_msg' => it618_group_utftogbk($printreturn['msg']),
			'it618_message' => $content,
			'it618_time' => $_G['timestamp']
		), true);
	}
}
?>