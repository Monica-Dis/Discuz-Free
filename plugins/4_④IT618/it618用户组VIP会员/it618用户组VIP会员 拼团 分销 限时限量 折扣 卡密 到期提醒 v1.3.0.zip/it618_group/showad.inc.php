<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_group = $_G['cache']['plugin']['it618_group'];
require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';

$aid=intval($_GET['aid']);

$it618_group_ad=C::t('#it618_group#it618_group_ad')->fetch_by_id($aid);

$wap=$_GET['wap'];
if($wap!=1){
	$height=$it618_group_ad['it618_height']-85;
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_group:showad');
?>