<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

class plugin_it618_group_base {
	function common_base($wap) {
		global $_G;
		
		$cache_file = DISCUZ_ROOT.'./source/plugin/it618_group/cache.php';
		$tmptime=10;
		require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
		
		if(($_G['timestamp'] - @filemtime($cache_file)) > $tmptime) {
			
			@$fp = fopen($cache_file,"w");
			fwrite($fp,$_G['timestamp']);
			fclose($fp);
			
			$query = DB::query("SELECT * FROM ".DB::table('it618_group_group')." where it618_txtime1>0 and it618_txtime2>0");
			while($it618_group_group = DB::fetch($query)) {
				$query1 = DB::query("SELECT * FROM ".DB::table('it618_group_group_user')." where it618_groupid=".$it618_group_group['it618_groupid']." and it618_etime<".($_G['timestamp']+($it618_group_group['it618_txtime1']*3600*24))." and it618_etime>".$_G['timestamp']);
				while($it618_group_group_user = DB::fetch($query1)) {
					if($it618_group_group_user['it618_txtime']==0){
						$isok=1;
					}else{
						if($it618_group_group_user['it618_txtime']+($it618_group_group['it618_txtime2']*3600*24)<$_G['timestamp']){
							$isok=1;
						}
					}
					
					if($isok==1){
						$tmpstr=it618_group_sendmessage('tx_user',$it618_group_group_user['id']);
						C::t('#it618_group#it618_group_group_user')->update($it618_group_group_user['id'],array(
							'it618_txtime' => $_G['timestamp'],
							'it618_txstate' => $tmpstr
						));
					}
				}
			}
		}
		
		if($_G['uid']>0){
			$extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
		
			$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
			$groupterms = dunserialize($memberfieldforum['groupterms']);
			unset($memberfieldforum);
			$expgrouparray = $expirylist = $termsarray = array();
			
			if(!empty($groupterms['ext']) && is_array($groupterms['ext'])) {
				$termsarray = $groupterms['ext'];
			}
			if(!empty($groupterms['main']['time']) && (empty($termsarray[$_G['groupid']]) || $termsarray[$_G['groupid']] > $groupterm['main']['time'])) {
				$termsarray[$_G['groupid']] = $groupterms['main']['time'];
			}
			
			foreach($termsarray as $expgroupid => $expiry) {
				if($expiry <= TIMESTAMP) {
					$expgrouparray[] = $expgroupid;
				}
			}
			
			if(!empty($groupterms['ext'])) {
				foreach($groupterms['ext'] as $extgroupid => $time) {
					$expirylist[$extgroupid] = array('timestamp' => $time, 'time' => date('Y-m-d H:i:s', $time), 'type' => 'ext', 'noswitch' => $time < TIMESTAMP);
				}
			}
			
			if(!empty($groupterms['main'])) {
				$expirylist[$_G['groupid']] = array('timestamp' => $groupterms['main']['time'], 'time' => date('Y-m-d H:i:s', $groupterms['main']['time']), 'type' => 'main');
			}
			
			$groupids = array();
			foreach($_G['cache']['usergroups'] as $groupid => $usergroup) {
				if(!empty($usergroup['pubtype'])) {
					$groupids[] = $groupid;
				}
			}
			
			$expiryids = array_keys($expirylist);
			if(!$expiryids && $_G['member']['groupexpiry']) {
				C::t('common_member')->update($_G['uid'], array('groupexpiry' => 0));
			}
			
			$groupids = array_merge($extgroupids, $expiryids, $groupids);
			
			$groupmessage=getcookie('groupmessage');
			if($groupmessage!='1'){
				dsetcookie('groupmessage','1',3);
				if($groupids) {
					DB::query("update ".DB::table('it618_group_group_user')." set it618_chkstate=0 WHERE it618_uid=".$_G['uid']);
					foreach(C::t('common_usergroup')->fetch_all($groupids) as $group) {
						if($group['type']!='system'&&$group['type']!='member'){
							$tmptime=$expirylist[$group['groupid']]['timestamp'];

							if($it618_group_group_user=C::t('#it618_group#it618_group_group_user')->fetch_by_groupid_uid($group['groupid'],$_G['uid'])){
								if($it618_group_group_user['it618_etime']!=$tmptime){
									C::t('#it618_group#it618_group_group_user')->update($it618_group_group_user['id'],array(
										'it618_etime' => $tmptime
									));
								}
								
								C::t('#it618_group#it618_group_group_user')->update($it618_group_group_user['id'],array(
									'it618_chkstate' => 1
								));
							}else{
								$id = C::t('#it618_group#it618_group_group_user')->insert(array(
									'it618_uid' => $_G['uid'],
									'it618_groupid' => $group['groupid'],
									'it618_etime' => $tmptime,
									'it618_chkstate' => 1
								), true);
							}
						}
					}
					DB::query("delete from ".DB::table('it618_group_group_user')." WHERE it618_chkstate=0 and it618_uid=".$_G['uid']);
				}
			}
			
			if($expgrouparray) {
				$isflag=0;
				if(in_array($_G['adminid'], array(1, 2, 3))) {
					$isflag=1;
				}else{
					$tmpgroupid = DB::result_first("SELECT groupid FROM ".DB::table('common_usergroup')." WHERE type='member' AND creditshigher<=".$_G['member']['credits']." AND creditslower>=".$_G['member']['credits']." LIMIT 1");
					if($_G['groupid']==$tmpgroupid){
						$isflag=1;
					}
				}
				
				if($isflag==0){		
					$extgroupidarray = array();
					foreach(explode("\t", $_G['forum_extgroupids']) as $extgroupid) {
						if(($extgroupid = intval($extgroupid)) && !in_array($extgroupid, $expgrouparray)) {
								$extgroupidarray[] = $extgroupid;
						}
					}
			
					$groupidnew = $_G['groupid'];
					$adminidnew = $_G['adminid'];
					
					foreach($expgrouparray as $expgroupid) {
						if($expgroupid == $_G['groupid']) {
							if(!empty($groupterms['main']['groupid'])) {
									$groupidnew = $groupterms['main']['groupid'];
									$adminidnew = $groupterms['main']['adminid'];
							} else {
									$groupidnew = DB::result_first("SELECT groupid FROM ".DB::table('common_usergroup')." WHERE type='member' AND creditshigher<=".$_G['member']['credits']." AND creditslower>=".$_G['member']['credits']." LIMIT 1");
									if(in_array($_G['adminid'], array(1, 2, 3))) {
											$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup')." WHERE groupid IN (".dimplode($extgroupidarray).") AND radminid='$_G[adminid]' LIMIT 1");
											$adminidnew = (DB::num_rows($query)) ? $_G['adminid'] : 0;
									} else {
											$adminidnew = 0;
									}
							}
							unset($groupterms['main']);
						}
						unset($groupterms['ext'][$expgroupid]);
					}
			
					require_once libfile('function/forum');
					$groupexpirynew = groupexpiry($groupterms);
					$extgroupidsnew = implode("\t", $extgroupidarray);
					$grouptermsnew = addslashes(serialize($groupterms));
					
					if(in_array($_G['adminid'], array(1, 2, 3))) {
						$groupidnew = $_G['adminid'];
						$adminidnew = $_G['adminid'];
					}
			
					DB::query("UPDATE ".DB::table('common_member')." SET adminid='$adminidnew', groupid='$groupidnew', extgroupids='$extgroupidsnew', groupexpiry='$groupexpirynew' WHERE uid='$_G[uid]'");
					DB::query("UPDATE ".DB::table('common_member_field_forum')." SET groupterms='$grouptermsnew' WHERE uid='$_G[uid]'");
					
					$isbuygroup=1;
				}
			}
			
			if($isbuygroup==1){
				$urlarr=explode("https://",$_G['siteurl']);
				if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';		
				$url_this = $httpstr.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];

				$tmparr=explode("it618_group",$_GET['id']);
				
				$urlarr=explode(":ajax",$url_this);
				if(count($urlarr)>1)$url_this=$_G['siteurl'];
				dsetcookie('buygroup_preurl',$url_this,31536000);
				
				if(count($tmparr)==1){
					require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
					if($wap==1){
						$tmpurl_buygroup=it618_group_getrewrite('group_wap','uc','plugin.php?id=it618_group:wap&pagetype=uc&groupexpiry','?groupexpiry');
					}else{
						$tmpurl_buygroup=it618_group_getrewrite('group_class','','plugin.php?id=it618_group:class&groupexpiry','?groupexpiry');
					}
					dheader("location:$tmpurl_buygroup");
				}
			}
	
		}
	}
}

class mobileplugin_it618_group extends plugin_it618_group_base {
	function common() {
		$this->common_base(1);
	}
	
	function global_footer_mobile(){
		require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
		return it618_group_getad('it618_discuz',1);
	}
}

class plugin_it618_group extends plugin_it618_group_base {
	
	function common() {
		$this->common_base(0);
	}
	
	function global_footer(){
		global $_G;
		$it618_group = $_G['cache']['plugin']['it618_group'];
		$group_diy=(array)unserialize($it618_group['group_diy']);

		$it618_group['group_jquerys']=$it618_group['group_jquerys'].'|spacecp&ac=avatar';
		if($it618_group['group_jquerys']!=''){
			$tmparr=explode("|",$it618_group['group_jquerys']);
			for($i=0;$i<count($tmparr);$i++){
				$tmparr1=explode($tmparr[$i],$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
				if(count($tmparr1)>1){
					$tmpjs='<script>jQuery.noConflict();</'.'SCRIPT>';
					break;
				}
				if($_SERVER['REQUEST_URI']=='/'&&$tmparr[$i]=='@'){
					$tmpjs='<script>jQuery.noConflict();</'.'SCRIPT>';
					break;
				}
			}
		}
		if($tmpjs=='')$tmpjs='<SCRIPT src="source/plugin/it618_group/js/jquery.js" type=text/javascript></'.'SCRIPT>';
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
		return $tmpjs.'
				'.it618_group_getgroup('it618_discuz','.it618_group').'
				'.it618_group_getad('it618_discuz',2).'
			';

	}
	
	function global_usernav_extra1(){
		global $_G;
		$it618_group = $_G['cache']['plugin']['it618_group'];
		$group_diy=(array)unserialize($it618_group['group_diy']);
		if(in_array(1, $group_diy)){
			if($_G['uid']>0){
				return '<span class="pipe">|</span>'.$it618_group['group_apibtn1'].'<span style="margin-left:5px;"></span>';
			}
		}
		
		return '';
	}

}

class plugin_it618_group_forum {
	
	function viewthread_sidetop_output(){
		global $_G,$postlist;
		$it618_group = $_G['cache']['plugin']['it618_group'];
		
		$viewthread_sidetop=array();
		
		if($_G['uid']>0){
			$group_diy=(array)unserialize($it618_group['group_diy']);
			if(in_array(2, $group_diy)){
				
				foreach($postlist as $id => $post){
					if($post['authorid']>0){
						$viewthread_sidetop[]='<div style="margin-top:-3px;margin-bottom:10px;text-align:center">'.$it618_group['group_apibtn2'].'</div>';
					}
		
				}
			}
		}
		
		return $viewthread_sidetop;
	}

}
?>