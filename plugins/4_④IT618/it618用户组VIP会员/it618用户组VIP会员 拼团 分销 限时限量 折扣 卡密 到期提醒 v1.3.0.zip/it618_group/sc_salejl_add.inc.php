<?php
 /**
 *	�����Ŷӣ�DisM.Taobao.Com
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';

if(submitcheck('it618submit')){
	
	$it618_groupid=$_GET['it618_groupid'];
	$tmparr=explode(",",$_GET['it618_uids']);
	$tmparr=array_unique($tmparr);
	
	set_time_limit (0);
	ignore_user_abort(true);
		
	for($i=0;$i<count($tmparr);$i++){
		$tmpuid=intval($tmparr[$i]);
		$username=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$tmpuid);
		if($username!=''){
			$memberfieldforum = C::t('common_member_field_forum')->fetch($tmpuid);
			$groupterms = dunserialize($memberfieldforum['groupterms']);
			unset($memberfieldforum);
			
			$isok=1;
			if(!empty($groupterms['ext'])) {
				foreach($groupterms['ext'] as $extgroupid => $time) {
					if($it618_group_goods['it618_groupid']==$it618_groupid){
						if($time-3600*24*365*60>$_G['timestamp']){
							$isok=0;
						}
						break;
					}
				}
			}
			
			if($isok==1){
				it618_group_salejl('sgzs',0,$it618_groupid,$_GET['it618_days'],$tmpuid,$_GET['it618_bz']);
			}

		}
	}

	echo '<script>parent.location.reload();parent.layer.closeAll();</script>';
}

it618_showformheader("plugin.php?id=it618_group:sc_salejl_add&gid=$gid");
showtableheaders($grouptitle,'sc_salejl_add');

$query = DB::query("SELECT * FROM ".DB::table('it618_group_group')." order by it618_order");
while($it618_group_group =	DB::fetch($query)) {
	$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_group['it618_groupid']);
	$groupoption.='<option value="'.$it618_group_group['it618_groupid'].'">'.$grouptitle.'</option>';
}

echo '
<tr><td width=80>'.$it618_group_lang['s369'].'</td><td><select id="it618_groupid" name="it618_groupid">'.$groupoption.'</select></td></tr>
<tr><td>'.$it618_group_lang['s370'].'</td><td><input type="text" id="it618_days" name="it618_days" style="width:68px;margin-right:6px">'.$it618_group_lang['s60'].' '.$it618_group_lang['s395'].'</td></tr>
<tr><td>'.$it618_group_lang['s371'].'</td><td><textarea id="it618_uids" name="it618_uids" style="width:680px;height:180px;line-height:18px;font-size:13px;margin-bottom:3px">'.$it618_group_group['it618_power'].'</textarea><br><input type="button" class="btn" value="'.it618_group_getlang('s378').'" onclick="getunames()" /><span id="unametips"></span></td></tr>
<tr><td>'.$it618_group_lang['s372'].'</td><td><input type="text" id="it618_bz" name="it618_bz" style="width:680px"></td></tr>
<tr><td colspan=2 style="color:red">'.$it618_group_lang['s375'].'</td></tr>

<script charset="utf-8" src="source/plugin/it618_group/js/jquery.js"></script>
<script>
function checkvalue(){
	if(document.getElementById("it618_days").value==""){
		alert("'.it618_group_getlang('s376').'");
		document.getElementById("it618_days").focus();
		return false;
	}
	
	if(document.getElementById("it618_uids").value==""){
		alert("'.it618_group_getlang('s377').'");
		document.getElementById("it618_uids").focus();
		return false;
	}
	
	if(!confirm("'.it618_group_getlang('s374').'")){
		return false;
	}
}

function getunames(){
	if(document.getElementById("it618_uids").value==""){
		alert("'.it618_group_getlang('s377').'");
		document.getElementById("it618_uids").focus();
	}else{

		IT618_GROUP.post("'.$_G['siteurl'].'plugin.php?id=it618_group:ajax&ac=getunames&formhash={FORMHASH}",IT618_GROUP("#cpform").serialize(),function (data, textStatus){
			var tmparr=data.split("it618_split");
			document.getElementById("it618_uids").value=tmparr[0];
			IT618_GROUP("#unametips").html("<br>"+tmparr[1]+"<br><br>");
		}, "html");	
	}
}
</script>
';

echo '<tr><td colspan=2><div class="fixsel"><input type="submit" class="btn" name="it618submit" onclick="return checkvalue()" value="'.it618_group_getlang('s373').'" /></div></td></tr>';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>