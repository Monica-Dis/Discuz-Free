<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function pay_success($out_trade_no){
	global $_G;
	
	if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_out_trade_no($out_trade_no)){
		if($it618_salepay['it618_state']==1)return;
	}else{
		return;	
	}
	
	$salepay_saletype=$it618_salepay['it618_saletype'];
	$salepay_saleid=$it618_salepay['it618_saleid'];
	$salepay_paytype=$it618_salepay['it618_paytype'];
	$salepay_payid=$it618_salepay['it618_payid'];
	$salepay_url=$it618_salepay['it618_url'];
	$salepay_wap=$it618_salepay['it618_wap'];

	require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
	
	set_time_limit (0);
	ignore_user_abort(true);

	$flagkm=0;$times=0;
	while($flagkm==0){
		if(DB::result_first("select count(1) from ".DB::table('it618_group_salework'))==0){
			$flagkm=1;
		}
		if($flagkm==0){
			sleep(1);
			$times=$times+1;
		}
		if($times>60){
			it618_group_delsalework();
		}
	}
	C::t('#it618_group#it618_group_salework')->insert(array(
		'it618_iswork' => 1
	), true);
	
	if($salepay_saletype=='0901'){
		$it618_group_sale=C::t('#it618_group#it618_group_sale')->fetch_by_id($salepay_saleid);
			
		if($it618_group_sale['it618_state']!=1){
			C::t('#it618_group#it618_group_sale')->update($salepay_saleid,array(
				'it618_state' => 1,
			));
			
			if($it618_group_sale['it618_tuijid']>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
				Union_TuiTC_Add($it618_group_sale['it618_tuijid'],$salepay_saleid);
			}
			
			C::t('#it618_credits#it618_credits_salepay')->update_state_by_out_trade_no(1,$_G['timestamp'],$out_trade_no);
			
			for($i=1;$i<=8;$i++){
				if($it618_group_sale['it618_credit'.$i]>0){
					C::t('common_member_count')->increase($it618_group_sale['it618_uid'], array(
						'extcredits'.$i => (0-$it618_group_sale['it618_credit'.$i]))
					);
				}
			}
			
			it618_group_updategoodscount($it618_group_sale);
			
			it618_group_qrxf($it618_group_sale['id']);
			
			it618_group_delsalework();
			
			return 'success';
		}
	
	}
	
	it618_group_delsalework();

}
?>