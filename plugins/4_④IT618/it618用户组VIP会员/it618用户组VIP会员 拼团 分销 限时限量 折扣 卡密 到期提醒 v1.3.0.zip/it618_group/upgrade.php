<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
/*
	Install Uninstall Upgrade AutoStat System Code
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_group_salejl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_days` int(10) unsigned NOT NULL,
  `it618_saletype` varchar(30) NOT NULL,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_group_rzmoney` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_lid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isautocheck` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istbtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_group_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_tel` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_group_group_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_txtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_txstate` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_group_group_zuser` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_group_goods_km` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_code` varchar(32) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_usedel` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_xgtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_group_salekm` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_code` varchar(32) NOT NULL,
  `it618_bz` varchar(32) NOT NULL,
  `it618_xgtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_unitcount` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_unit` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_group_group_zk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_zk` float(9,2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_group_group_salepower` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_group_ad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_content` mediumtext NOT NULL,
  `it618_height` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_width` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_cookiestime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_btn1title` varchar(30) NOT NULL,
  `it618_btn2title` varchar(30) NOT NULL,
  `it618_btn1url` varchar(255) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_group_adarea` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_aid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_plugin` varchar(30) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_group_adshop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_aid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_plugin` varchar(30) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_group_adgroup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_aid` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_group_print` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_sn` varchar(50) NOT NULL,
  `it618_key` varchar(50) NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_phonenum` varchar(50) NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_group_printshop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_prid` int(10) unsigned NOT NULL,
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_group_printsale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_prid` int(10) unsigned NOT NULL,
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saleid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_printsaleid` varchar(50) NOT NULL,
  `it618_msg` varchar(255) NOT NULL,
  `it618_content` mediumtext NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_group_group'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_xgzk', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_group')." add `it618_xgzk` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_video_pids', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_group')." add `it618_video_pids` varchar(1000) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_pbuids', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_group')." add `it618_pbuids` varchar(1000) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_txtime1', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_group')." add `it618_txtime1` int(10) unsigned NOT NULL DEFAULT '10';"; 
	DB::query($sql);
}

if(!in_array('it618_txtime2', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_group')." add `it618_txtime2` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}

if(!in_array('it618_isagree', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_group')." add `it618_isagree` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_agreetime', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_group')." add `it618_agreetime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_agreeabout', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_group')." add `it618_agreeabout` mediumtext NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_ispublic', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_group')." add `it618_ispublic` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}


unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_group_goods'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_isuser', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_goods')." add `it618_isuser` int(10) unsigned NOT NULL default '0';"; 
	DB::query($sql);
}

if(!in_array('it618_issd', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_goods')." add `it618_issd` int(10) unsigned NOT NULL default '1';"; 
	DB::query($sql);
}

if(!in_array('it618_unitcount', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_goods')." add `it618_unitcount` int(10) unsigned NOT NULL default '1';"; 
	DB::query($sql);
}

if(!in_array('it618_picbig', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_goods')." add `it618_picbig` varchar(255) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_counttype', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_goods')." add `it618_counttype` int(10) unsigned NOT NULL default '1';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_group_sale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_xgzk', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_sale')." add `it618_xgzk` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_vipzk', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_sale')." add `it618_vipzk` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_sfmoney', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_sale')." add `it618_sfmoney` float(9,2) NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_group_sale')." add `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_sale'));
	while($it618_group_sale = DB::fetch($query)) {
		$it618_sfmoney = $it618_group_sale['it618_price']*$it618_group_sale['it618_count']-$it618_group_sale['it618_quanmoney'];
		$it618_sfscore = $it618_group_sale['it618_score']*$it618_group_sale['it618_count'];
		$sql = "update ".DB::table('it618_group_sale')." set it618_sfmoney=$it618_sfmoney,it618_sfscore=$it618_sfscore where id=".$it618_group_sale['id']; 
		DB::query($sql);
	}
}

if(!in_array('it618_tel', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_sale')." add `it618_tel` varchar(20) NOT NULL;"; 
	DB::query($sql);
	
	DB::query("update ".DB::table('it618_group_sale')." set it618_tel='1'");
}

if(!in_array('it618_unitcount', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_sale')." add `it618_unitcount` int(10) unsigned NOT NULL default '1';"; 
	DB::query($sql);
}

if(!in_array('it618_type', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_sale')." add `it618_type` int(10) unsigned NOT NULL default '1';"; 
	DB::query($sql);
}

if(!in_array('it618_pinsaleid', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_sale')." add `it618_pinsaleid` int(10) unsigned NOT NULL default '0';"; 
	DB::query($sql);
}

if(!in_array('it618_isswitch', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_sale')." add `it618_isswitch` int(10) unsigned NOT NULL default '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_group_salejl'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_bz', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_salejl')." add `it618_bz` varchar(1000) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_group_ad'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_urlarea', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_ad')." add `it618_urlarea` varchar(1000) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_uids', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_ad')." add `it618_uids` varchar(1000) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_group_group_user'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_chkstate', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_group_user')." add `it618_chkstate` int(10) unsigned NOT NULL default '0';"; 
	DB::query($sql);
}

if(!in_array('it618_bz', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_group_user')." add `it618_bz` varchar(1000) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_time', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_group_user')." add `it618_time` int(10) unsigned NOT NULL default '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_group_salework'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_v1', $col_field)){
	$sql = "Alter table ".DB::table('it618_group_salework')." add `it618_v1` int(10) unsigned NOT NULL default '0';"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('common_member')." modify column `extgroupids` char(255) NOT NULL;"; 
	DB::query($sql);
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL2Rpc2N1el9wbHVnaW5faXQ2MThfZ3JvdXAueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL2Rpc2N1el9wbHVnaW5faXQ2MThfZ3JvdXBfU0NfR0JLLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL2Rpc2N1el9wbHVnaW5faXQ2MThfZ3JvdXBfU0NfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL2Rpc2N1el9wbHVnaW5faXQ2MThfZ3JvdXBfVENfQklHNS54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL2Rpc2N1el9wbHVnaW5faXQ2MThfZ3JvdXBfVENfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL2xhbmd1YWdlLlRDX0JJRzUucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL2xhbmd1YWdlLlRDX1VURjgucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL2luc3RhbGwucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL3VwZ3JhZGUucGhw'));
?>