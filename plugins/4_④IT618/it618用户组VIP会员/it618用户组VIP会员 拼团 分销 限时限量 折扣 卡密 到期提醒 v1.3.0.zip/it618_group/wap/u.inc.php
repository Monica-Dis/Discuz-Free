<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!group_is_mobile()){
	dheader("location:$group_home");
}

$navtitle=it618_group_getlang('s111');

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_group_getlang('s835');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_group:'.$group_templatename_wap.'/wap_group');
	return;
}

if($IsCredits==1){
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$creditsurl=it618_credits_getrewriteapi('credits_wap','uc','plugin.php?id=it618_credits:wap&dotype=uc');
	$tmpurl_buygroup=it618_credits_getrewriteapi('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
}

if($IsUnion==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
	$url_union=it618_union_getrewrite('union_wap','u','plugin.php?id=it618_union:wap&pagetype=u');
}

$menuusername=$_G['username'];
$u_avatarimg=it618_group_discuz_uc_avatar($_G['uid'],'middle').'&random='.rand();

$groupstr=it618_group_getucvip(1);

$groupclassurl=it618_group_getrewrite('group_class','','plugin.php?id=it618_group:class');

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_group:'.$group_templatename_wap.'/wap_group');
?>