<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pid=intval($_GET['cid1']);
if(!group_is_mobile()){ 
	if(isset($_GET['tuiuid'])){
		$urltmp='tuiuid='.$_GET['tuiuid'];
	}
	if(isset($_GET['e'])){
		if($urltmp!='')$urltmp.='&e='.$_GET['e'];else $urltmp.='e='.$_GET['e'];
	}
	
	if($urltmp!=''){
		$tmpurl=it618_group_getrewrite('group_product',$pid,'plugin.php?id=it618_group:product&pid='.$pid.'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=it618_group_getrewrite('group_product',$pid,'plugin.php?id=it618_group:product&pid='.$pid);
	}

	dheader("location:$tmpurl");
}

if($it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($pid)){
	$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
	$classurl=it618_group_getrewrite('group_class',$it618_group_group['it618_classid'],'plugin.php?id=it618_group:class&cid='.$it618_group_group['it618_classid']);
	if($it618_group_goods['it618_state']==0){
		dheader("location:$classurl");
	}
	if($it618_group_goods['it618_isuser']==1&&$_G['uid']<=0){
		dheader("location:$classurl");
	}
}else{
	$tmpurl=it618_group_getrewrite('group_class','','plugin.php?id=it618_group:class');
	dheader("location:$tmpurl");	
}

$classname = C::t('#it618_group#it618_group_class')->fetch_it618_name_by_id($it618_group_group['it618_classid']);
$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
$goodspicstr=it618_group_getwapppic($it618_group_goods['id'],$it618_group_goods['it618_picbig']);

$it618_unit=it618_group_getgoodsunit($it618_group_goods);

if($it618_group_group['it618_xgzk']>0){
	$it618_xgzk='<img src="source/plugin/it618_group/images/zk.png" style="vertical-align:middle;margin-top:-3px;height:16px;margin-right:3px">'.$it618_group_lang['s365'].$it618_group_group['it618_xgzk'].'%';
}

if($it618_group_goods['it618_counttype']==1){
	$countstr=$it618_group_lang['s130'];
	if($it618_group_goods['it618_xgcount']>0){
		$countstr=$it618_group_lang['s131'];
		$countstr=str_replace("{xgcount}",$it618_group_goods['it618_xgcount'],$countstr);
		
		$tomonth = date('n'); 
		$todate = date('j'); 
		$toyear = date('Y');
		$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
		$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_group_sale')." where it618_pid=".$it618_group_goods['id']." and it618_time>$time and it618_state=1");
		
		$countstr=str_replace("{xgcount1}",$it618_group_goods['it618_xgcount']-$buycount,$countstr);
	}
	$countstr=str_replace("{count}",$it618_group_goods['it618_count'],$countstr);
}

$it618_powers=explode("@@@",str_replace(array("\r\n", "\r", "\n"), '@@@', $it618_group_group['it618_power']));
foreach($it618_powers as $key => $it618_power){
	if($it618_power!=""){
		$grouppower.='<tr><td><img src="source/plugin/it618_group/template/default/images/vipabout.png">'.$it618_power.'</td></tr>';
	}
}

C::t('#it618_group#it618_group_goods')->update_it618_views_by_id($pid);
$goodspricestr=it618_group_getgoodsprice($it618_group_goods);

$query = DB::query("SELECT * FROM ".DB::table('it618_group_goods')." where it618_groupid=".$it618_group_goods['it618_groupid']." and it618_state=1 ORDER BY it618_unit");
while($it618_group_goodstmp = DB::fetch($query)) {
	$curstr='';
	if($it618_group_goodstmp['it618_unitcount']==$it618_group_goods['it618_unitcount']&&$it618_group_goodstmp['it618_unit']==$it618_group_goods['it618_unit']){
		$curstr='class="current"';
	}
	
	$tmpurl=it618_group_getrewrite('group_product',$it618_group_goodstmp['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goodstmp['id']);
	
	$it618_unittmp=it618_group_getgoodsunit($it618_group_goodstmp);
	$goodsgroupunit.='<a '.$curstr.' href="'.$tmpurl.'">'.$it618_unittmp.'</a>';
}

$navtitle=$grouptitle.' '.$it618_unit;
$metakeywords=$it618_group_goods['it618_seokeywords'];
$metadescription=$it618_group_goods['it618_seodescription'];

$it618_message=$it618_group_goods['it618_message'];
$it618_message=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$it618_message);
$it618_message=preg_replace('/<img.+?src=\"(.+?)\".+?>/','<img src="\1"/>',$it618_message);
$it618_message=preg_replace('/<table.+?>/','<table cellspacing="0" cellpadding="0" width="100%">',$it618_message);
$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="220" frameborder="0" allowfullscreen="1">',$it618_message);

if(isset($_GET['e'])){
	$goodsurl=it618_group_getrewrite('group_product',$pid,'plugin.php?id=it618_group:product&pid='.$pid.'&e='.$_GET['e'],'?e='.$_GET['e']);
}else{
	$goodsurl=it618_group_getrewrite('group_product',$pid,'plugin.php?id=it618_group:product&pid='.$pid);
}

$timeflag=0;$isxgok=0;
if($it618_group_goods['it618_xgtype']==0)$isxgok=1;

if($it618_group_goods['it618_xgtype']==1){
	$timestr=$it618_group_goods['it618_xgtime1'].' - '.$it618_group_goods['it618_xgtime2'];
	
	$timetmp1=explode(" ",$it618_group_goods['it618_xgtime1']);
	$timetmp2=explode(" ",$it618_group_goods['it618_xgtime2']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);
	
	
	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
	
	$timeflag=1;$timebgcolor='#ff4628';$timecolor='#fff';
	if($etime<$_G['timestamp']){
		$timeflag=0;$timebgcolor='#eee';$timecolor='#999';
		$timetip=it618_group_getlang('s952');
	}else{
		if($btime>$_G['timestamp']){
			$timetip=it618_group_getlang('s953');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_group_goods['it618_xgtime1'];
		}else{
			$timetip=it618_group_getlang('s954');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_group_goods['it618_xgtime2'];
			$isxgok=1;
		}
	}
	
	$isxg=1;
}

if($it618_group_goods['it618_xgtype']==2){
	$timetmp1=explode(" ",$it618_group_goods['it618_xgtime1']);
	$timetmp2=explode(" ",$it618_group_goods['it618_xgtime2']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);
	
	$timestr=$timetmp1[0].' - '.$timetmp2[0].' '.it618_group_getlang('s955').' '.$timetmp1[1].' - '.$timetmp2[1];
	
	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
	
	$timeflag=1;
	if($etime<$_G['timestamp']){
		$timeflag=0;
		$timetip=it618_group_getlang('s952');
		
	}else{
		if($btime>$_G['timestamp']){
			$timetip=it618_group_getlang('s953');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_group_goods['it618_xgtime1'];
		}else{
			$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
			$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
			$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
			
			if($btimecur>$_G['timestamp']){
				$timetip=it618_group_getlang('s953');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $btimecur);
			}
			
			if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
				$timetip=it618_group_getlang('s954');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $etimecur);
				$isxgok=1;
			}
			
			if($etimecur<$_G['timestamp']){
				$timetip=it618_group_getlang('s953');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $btimecur1);
			}
		}
	}
	
	$isxg=1;
}

$it618sql='p.it618_state=1 and p.id!='.$pid;
foreach(C::t('#it618_group#it618_group_goods')->fetch_all_by_search(
		$it618sql,'rand()',0,0,0,10
	) as $it618_group_goodstmp) {
	
	$n=$n+1;
	
	$it618_group_grouptmp=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goodstmp['it618_groupid']);
	$grouptitletmp=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goodstmp['it618_groupid']);
	$it618_unittmp=it618_group_getgoodsunit($it618_group_goodstmp);
	
	$tmpurl=it618_group_getrewrite('group_product',$it618_group_goodstmp['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goodstmp['id']);

	$roundgoods.='<tr>
                <td width="60"><a href="'.$tmpurl.'" target="_blank"><img src="'.$it618_group_grouptmp['it618_ico'].'" style="width:48px; height:48px" /></a></td>
                <td class="tdtitle"><a href="'.$tmpurl.'" target="_blank">'.$grouptitletmp.' '.$it618_unittmp.'</a><br /><span>'.it618_group_getgoodsprice($it618_group_goodstmp).'</span></td>
                </tr>';
}

if($_G['uid']>0){
	$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
	$groupterms = dunserialize($memberfieldforum['groupterms']);
	unset($memberfieldforum);
	
	if(!empty($groupterms['ext'])) {
		foreach($groupterms['ext'] as $extgroupid => $time) {
			if($it618_group_goods['it618_groupid']==$extgroupid){
				if($time-3600*24*365*60>$_G['timestamp']){
					$isgroupok=1;
					$grouptime=$it618_group_lang['s64'];
				}else{
					$grouptime=date('Y-m-d H:i:s', $time);
					if($time<$_G['timestamp']){
						$grouptime='<s>'.$grouptime.'</s>';
					}else{
						$it618_group_lang['s128']=$it618_group_lang['s436'];
					}
				}
				break;
			}
		}
	}
}

if($grouptime!=''){
	$grouptime=$it618_group_lang['s163'].$grouptime;
}else{
	$grouptime=$it618_group_lang['s197'];
}

require_once DISCUZ_ROOT.'./source/plugin/it618_group/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_group:'.$group_templatename_wap.'/wap_group');
?>