<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_group/group_default.func.php';

$cid=intval($_GET['cid1']);
if(!group_is_mobile()){ 
	$tmpurl=it618_group_getrewrite('group_class',$cid,'plugin.php?id=it618_group:class&cid='.$cid);
	dheader("location:$tmpurl");
}

$groupclassn=0;
$query = DB::query("SELECT * FROM ".DB::table('it618_group_class')." ORDER BY it618_order");
while($it618_group_class = DB::fetch($query)) {
	$curstr='';
	if(($it618_group_class['id']==$cid||$cid==0)&&$metatitle==''){
		if($cid==0)$cid=$it618_group_class['id'];
		$navtitle=$it618_group_class['it618_name'];
		$metakeywords=$it618_group_class['it618_seokeywords'];
		$metadescription=$it618_group_class['it618_seodescription'];
		$classabout=$it618_group_class['it618_about'];
		$curstr='class="current"';
	}
	
	$tmpurl=it618_group_getrewrite('group_wap','class@'.$it618_group_class['id'],'plugin.php?id=it618_group:wap&pagetype=class&cid1='.$it618_group_class['id']);
	
	$groupclass.='<a '.$curstr.' href="'.$tmpurl.'">'.$it618_group_class['it618_name'].'</a>';
	$groupclassn=$groupclassn+1;
}

foreach(C::t('#it618_group#it618_group_goods')->fetch_all_by_search(
	'p.it618_state=1','p.it618_order,p.id desc',$cid,0
) as $it618_group_goods) {
	$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
	$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_group['it618_groupid']);
	
	$goodspirce=it618_group_getgoodsprice($it618_group_goods,'class');
	
	if($it618_group_goods['it618_xgcount']>0){
		$xgcountstr='sears-differ';
	}
	
	if($IsPinEdu==1){
		$pinstr='';
		if($it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_by_shoptype_typeid('group',$it618_group_goods['id'])){
			$pinstr='<span class="pin-sign">'.$it618_group_lang['s218'].'</span>';
		}
	}
	
	$timestr='';
	if($it618_group_goods['it618_xgtype']>0){
		if($pinstr=='')$timecss='pin';else $timecss='time';
		$timestr='<span class="'.$timecss.'-sign">'.$it618_group_lang['s219'].'</span>';
	}
	
	$saleaboutstr='';
	if($it618_group_goods['it618_saleabout']!=''){
		$saleaboutstr='<span class="discount-sign">'.$it618_group_goods['it618_saleabout'].'</span>';
	}
	$goodspirce=str_replace("{saleabout}",$saleaboutstr,$goodspirce);
	
	$pricecss='opacity:0;';
	if($it618_group_goods['it618_price']>0){
		$pricecss='';
		$xgcountstr='sears-differ';
	}
	
	if($it618_group_goods['it618_counttype']==1){
		$countstr=$it618_group_lang['s114'];
		if($it618_group_goods['it618_xgcount']>0){
			$countstr=$it618_group_lang['s115'];
			$countstr=str_replace("{xgcount}",$it618_group_goods['it618_xgcount'],$countstr);
			
			$tomonth = date('n'); 
			$todate = date('j'); 
			$toyear = date('Y');
			$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
			$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_group_sale')." where it618_pid=".$it618_group_goods['id']." and it618_time>$time and it618_state=1");
			
			$countstr=str_replace("{xgcount1}",$it618_group_goods['it618_xgcount']-$buycount,$countstr);
		}
		$countstr=str_replace("{count}",$it618_group_goods['it618_count'],$countstr);
	}
	
	$grouppower1='';$grouppower2='';$n=0;
	if($it618_group_goods['it618_isuser']==1&&$_G['uid']<=0){
		$grouppower1=$it618_group_lang['s214'];
		$grouppower2='<li class="details">&nbsp;</li><li class="details">'.$it618_group_lang['s215'].'</li>';
		$tmpurl='href="member.php?mod=logging&action=login"';
	}else{
		$it618_powers=explode("@@@",str_replace(array("\r\n", "\r", "\n"), '@@@', $it618_group_group['it618_power']));
		foreach($it618_powers as $key => $it618_power){
			if($n>2)break;
			if($it618_power!=""){
				$it618_powertmp=$it618_power;
				if($grouppower1==''){
					$grouppower1=$it618_powertmp;
				}else{
					$grouppower2.='<li class="details">'.$it618_powertmp.'</li>';
				}
				$n=$n+1;
			}
		}
		$tmpurl=it618_group_getrewrite('group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id']);
		$tmpurl='href="'.$tmpurl.'"';
	}
	
	$tjstr1='';$tjstr2='';$tjstr3='';
	if($it618_group_goods['it618_istj']==1){
		$tjstr1='sears-differ';
		$tjstr2='<div class="diff-recommend"></div>';
		$tjstr3='swi-diff';
	}
	
	$groupstr.='<li class="sears '.$tjstr1.'">
                <h3><div class="symbol"><img src="'.$it618_group_group['it618_ico'].'"></div> '.$grouptitle.'</h3>
                '.$tjstr2.'
                <div class="origin-price origin-price-show clearBoth" style="'.$pricecss.'">
                <s>&yen;'.$it618_group_goods['it618_price'].'</s>
                <div class="limit-c">'.$countstr.'</div>
                </div>
                <p class="price orange">'.$goodspirce.'</p>'.$pinstr.''.$timestr.'
                <a '.$tmpurl.' class="switch '.$tjstr3.'">'.$it618_group_lang['s116'].'</a>
                <span class="sears-desc">'.$grouppower1.'</span>
                <div class="line"></div>
                <ul class="se-details">
                '.$grouppower2.'
				<li class="powermore"><a '.$tmpurl.' target="_blank">'.$it618_group_lang['s364'].'<img src="source/plugin/it618_group/template/default/images/more.png" style="vertical-align:middle;margin-top:-3px;height:13px;margin-left:3px"></a></li>
                </ul>
                <br style="clear: both;">
            </li>';
}

require_once DISCUZ_ROOT.'./source/plugin/it618_group/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_group:'.$group_templatename_wap.'/wap_group');
?>