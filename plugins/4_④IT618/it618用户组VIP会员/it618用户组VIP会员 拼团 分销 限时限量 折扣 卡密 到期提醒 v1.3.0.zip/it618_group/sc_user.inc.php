<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';

echo '
<script charset="utf-8" src="source/plugin/it618_group/js/Calendar.js"></script>
<script charset="utf-8" src="source/plugin/it618_group/js/jquery.js"></script>
<style>
#tr_salelist td.tdgroup img{vertical-align:middle; margin-top:-3px; margin-right:5px; width:20px; height:20px; border-radius:3px}
</style>
';

showtableheaders(it618_group_getlang('s265'),'it618_group_sum');

	echo '<tr><td colspan="15"><div class="fixsel">'.it618_group_getlang('s270').' <input id="finduid" class="txt" style="width:76px" />'.it618_group_getlang('s271').' <input id="groupid" class="txt" style="width:76px" />'.it618_group_getlang('s272').' <input id="it618_time1" class="txt" style="width:90px;margin-right:0" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly" />-<input id="it618_time2" class="txt" style="width:90px;" onclick="SetDate(this,\'yyyy-MM-dd\')" readonly="readonly"/> &nbsp;<input type="button" class="btn" value="'.it618_group_getlang('s170').'" onclick="findsalelist()" /> <input type="button" class="btn" value="'.it618_group_getlang('s256').'" onclick="dao()" /> </div></td></tr>';
	
	echo '<tr id="tr_salesum"></tr>';
	
	showsubtitle(array('', it618_group_getlang('s266'),it618_group_getlang('s267'),it618_group_getlang('s268'),it618_group_getlang('s473'),it618_group_getlang('s269'),it618_group_getlang('s274')));
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_group/images/loading.gif"></td></tr><tbody id="tr_salelist"></tbody>';
	
	echo '<tr id="salepage"></tr>';

showtablefooter();
echo '
<script>
var saleurl="'.$_G['siteurl'].'plugin.php?id=it618_group:ajax";
var sqlurl="";
function getsalelist(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("tr_salelist").style.display="none";
	IT618_GROUP.post(url+sqlurl+"&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"user_get"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_GROUP("#tr_salesum").html(tmparr[0]);
	IT618_GROUP("#tr_salelist").html(tmparr[1]);
	IT618_GROUP("#salepage").html(tmparr[2]);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("tr_salelist").style.display="";
	}, "html");	
	saleurl=url;
}
getsalelist(saleurl);

function findsalelist(){
	var finduid = document.getElementById("finduid").value;
	var groupid = document.getElementById("groupid").value;
	var it618_time1 = document.getElementById("it618_time1").value;
	var it618_time2 = document.getElementById("it618_time2").value;
	
	sqlurl="&finduid="+finduid+"&groupid="+groupid+"&it618_time1="+it618_time1+"&it618_time2="+it618_time2;
	var url="'.$_G['siteurl'].'plugin.php?id=it618_group:ajax";
	getsalelist(url);
}

function dao(){
	findsalelist();
	IT618_GROUP.get(saleurl+sqlurl+"&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"user_dao"},function (data, textStatus){
	window.open(data);
	}, "html");	
}

function showuserbz(vuid){
	layerindex=layer.open({
		type: 2,
		title: "<div style=\'float:left;color:blue\'>'.$it618_group_lang['s474'].'</div>",
		shadeClose: false,
		scrollbar: false,
		shade:  [0.5, "#393D49"],
		maxmin: false,
		area: ["830px", "480px"],
		content: "plugin.php?id=it618_group:sc_group_userbz&type=vip&vuid="+vuid,
		cancel: function(index, layero){ 
			//location.reload();
		}    
	});
}
</script>
';
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>