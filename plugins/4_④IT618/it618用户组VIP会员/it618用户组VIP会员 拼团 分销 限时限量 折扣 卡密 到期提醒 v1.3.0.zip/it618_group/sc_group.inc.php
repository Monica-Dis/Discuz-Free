<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tmpidarr=explode(":",$_GET['id']);
$tempabc=$tmpidarr[0];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_group_class'));
if($count==0){
	it618_cpmsg($it618_group_lang['s168'], "plugin.php?id=it618_group:sc_group_class", 'error');
}

$it618_video = $_G['cache']['plugin']['it618_video'];
$it618_exam = $_G['cache']['plugin']['it618_exam'];
$it618_brand = $_G['cache']['plugin']['it618_brand'];
$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
$it618_waimai = $_G['cache']['plugin']['it618_waimai'];

$shoptype='';
if($it618_video['seotitle']!=''&&$shoptype=='')$shoptype='video';
if($it618_exam['seotitle']!=''&&$shoptype=='')$shoptype='exam';
if($it618_brand['brand_name']!=''&&$shoptype=='')$shoptype='brand';
if($it618_tuan['seotitle']!=''&&$shoptype=='')$shoptype='tuan';
if($it618_waimai['waimai_name']!=''&&$shoptype=='')$shoptype='waimai';

$it618sql='1=1';
if($_GET['class_id']>0){
	$it618sql.=' and it618_classid='.intval($_GET['class_id']);
}
$urlsql='&class_id='.$_GET['class_id'];

if(submitcheck('it618submit')){

	if(is_array($_GET['it618_ico'])) {
		foreach($_GET['it618_ico'] as $id => $val) {
			
				if($_GET['it618_xgzk'][$id]>=100){
					$it618_xgzk=0;
				}else{
					$it618_xgzk=$_GET['it618_xgzk'][$id];	
				}
			
				C::t('#it618_group#it618_group_group')->update($id,array(
					'it618_ico' => $_GET['it618_ico'][$id],
					'it618_classid' => $_GET['it618_classid'][$id],
					'it618_isagree' => $_GET['it618_isagree'][$id],
					'it618_ispublic' => $_GET['it618_ispublic'][$id],
					'it618_switch' => $_GET['it618_switch'][$id],
					'it618_xgzk' => $it618_xgzk,
					'it618_txtime1' => $_GET['it618_txtime1'][$id],
					'it618_txtime2' => $_GET['it618_txtime2'][$id],
					'it618_order' => $_GET['it618_order'][$id]
				));
		}
	}

	it618_cpmsg($it618_group_lang['s16'], "plugin.php?id=it618_group:sc_group&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=11)return;
if(submitcheck('it618daosubmit')) {
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup')." where radminid=0 and type='special' order by groupid");
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_group_group')." WHERE it618_groupid=".$common_usergroup['groupid'])==0){
			C::t('#it618_group#it618_group_group')->insert(array(
				'it618_groupid' => $common_usergroup['groupid'],
				'it618_ico' => 'source/plugin/it618_group/images/vip.png'
			), true);
		}
	}
}

if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_group_group'))==0){
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup')." where radminid=0 and type='special' order by groupid");
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_group_group')." WHERE it618_groupid=".$common_usergroup['groupid'])==0){
			C::t('#it618_group#it618_group_group')->insert(array(
				'it618_groupid' => $common_usergroup['groupid'],
				'it618_ico' => 'source/plugin/it618_group/images/vip.png'
			), true);
		}
	}	
}

it618_showformheader("plugin.php?id=it618_group:sc_group&page=$page".$urlsql);

$query1 = DB::query("SELECT * FROM ".DB::table('it618_group_class')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}

$tmp1=str_replace('<option value='.$_GET['class_id'].'>','<option value='.$_GET['class_id'].' selected="selected">',$tmp);

showtableheaders($it618_group_lang['s8'],'it618_group_group');
	if($reabc[5]!='_')return;

	echo '<tr><td colspan=14>'.$it618_group_lang['s169'].' <select name="class_id"><option value=0>'.$it618_group_lang['s171'].'</option>'.$tmp1.'</select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.$it618_group_lang['s170'].'" /> <input type="submit" class="btn" name="it618daosubmit" style="float:right" value="'.it618_group_getlang('s15').'" /></td></tr>';
	
	$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_group_group'." where $it618sql"));
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_group:sc_group".$urlsql);
	echo '<style>.hover td{line-height:26px}</style><tr><td colspan=10>'.$it618_group_lang['s12'].$count.'<span style="float:right;">'.$it618_group_lang['s9'].'</span></td></tr>';

	showsubtitle(array($it618_group_lang['s5'],$it618_group_lang['s228'],$it618_group_lang['s14'],$it618_group_lang['s420'],$it618_group_lang['s7'],$it618_group_lang['s196']));

	$query = DB::query("SELECT * FROM ".DB::table('it618_group_group')." where $it618sql order by it618_order desc LIMIT $startlimit, $ppp");
	while($it618_group_group =	DB::fetch($query)) {
		
		if(DB::result_first("select count(1) from ".DB::table('common_usergroup')." where groupid=".$it618_group_group['it618_groupid'])>0){
			$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_group['it618_groupid']);
		}else{
			DB::query("delete FROM ".DB::table('it618_group_group')." where id=".$it618_group_group['id']);
		}
		
		if($it618_group_group['it618_isagree']==1)$it618_isagree_checked='checked="checked"';else $it618_isagree_checked="";
		if($it618_group_group['it618_switch']==1)$it618_switch_checked='checked="checked"';else $it618_switch_checked="";
		if($it618_group_group['it618_ispublic']==1)$it618_ispublic_checked='checked="checked"';else $it618_ispublic_checked="";
		$tmp1=str_replace('<option value='.$it618_group_group['it618_classid'].'>','<option value='.$it618_group_group['it618_classid'].' selected="selected">',$tmp);
		
		$goodscount=C::t('#it618_group#it618_group_goods')->count_by_groupid($it618_group_group['it618_groupid']);
		
		if($it618_video['seotitle']!=''){
			$pidcount=0;
			if($it618_group_group['it618_video_pids']!=''){
				$pidcount=count(explode(",",$it618_group_group['it618_video_pids']));
				$pidcount='<font color=red>'.$pidcount.'</font>';
			}
			$videopidstr=' <a href="javascript:" onclick="showvideopid('.$it618_group_group['id'].')">'.$it618_group_lang['s220'].'('.$pidcount.')</a>';
		}
		
		if($shoptype!=''){
			$zkcount=DB::result_first("select count(1) from ".DB::table('it618_group_group_zk')." where it618_zk>0 and it618_groupid=".$it618_group_group['it618_groupid']);
			if($zkcount>0)$zkcount='<font color=red>'.$zkcount.'</font>';
			$groupzkstr='<a href="javascript:" onclick="showgroupzk('.$it618_group_group['id'].')">'.$it618_group_lang['s380'].'('.$zkcount.')</a> ';
			
			$salepowercount=DB::result_first("select count(1) from ".DB::table('it618_group_group_salepower')." where it618_isok=1 and it618_groupid=".$it618_group_group['it618_groupid']);
			if($salepowercount>0)$salepowercount='<font color=red>'.$salepowercount.'</font>';
			$groupsalepowerstr='<a href="javascript:" onclick="showgroupsalepower('.$it618_group_group['id'].')">'.$it618_group_lang['s390'].'('.$salepowercount.')</a><br>';
		}
		
		$powercount=0;
		if($it618_group_group['it618_power']!=''){
			$it618_powers=explode("@@@",str_replace(array("\r\n", "\r", "\n"), '@@@', $it618_group_group['it618_power']));
			$powercount='<font color=red>'.count($it618_powers).'</font>';
		}
		
		$tmppurl='';
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_group_goods')." where it618_groupid=".$it618_group_group['it618_groupid']." and it618_state=1 ORDER BY it618_unit");
		while($it618_group_goodstmp = DB::fetch($query1)) {
			$tmppurl=it618_group_getrewrite('group_product',$it618_group_goodstmp['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goodstmp['id']);
			$tmppurl='href="'.$tmppurl.'" target="_blank"';
			break;
		}
		
		$pbuidscount=0;
		if($it618_group_group['it618_pbuids']!=''){
			$pbuidscount=explode(',', $it618_group_group['it618_pbuids']);
			$pbuidscount='<font color=red>'.count($pbuidscount).'</font>';
		}
		$pbuidsstr='<a href="javascript:" onclick="showpbuids('.$it618_group_group['id'].')">'.$it618_group_lang['s396'].'('.$pbuidscount.')</a>';
		
		showtablerow('', array('class="td28"', '', ''), array(
			'<a '.$tmppurl.'><img src="'.$it618_group_group['it618_ico'].'" id="img'.$it618_group_group['id'].'" width="68" height="68" align="absmiddle" style="float:left;margin-right:15px"/></a><div style="float:left;line-height:28px"><div style="font-weight:bold;line-height:18px">'.$grouptitle.'</div>
			<a href="javascript:" onclick="showgrouppowers('.$it618_group_group['id'].')">'.$it618_group_lang['s6'].'('.$powercount.')</a>
			<input class="checkbox" type="checkbox" id="it618_isagree'.$it618_group_group['id'].'" name="it618_isagree['.$it618_group_group['id'].']" '.$it618_isagree_checked.' value="1"><label for="it618_isagree'.$it618_group_group['id'].'">'.$it618_group_lang['s317'].'</label>
			<a href="javascript:" onclick="showgroupagree('.$it618_group_group['id'].')">'.$it618_group_lang['s318'].'('.strlen($it618_group_group['it618_agreeabout']).')</a>
			<br>
			<select id="class'.$n.'" name="it618_classid['.$it618_group_group['id'].']" style="margin-bottom:4px"><option value=0>'.$it618_group_lang['s172'].'</option>'.$tmp1.'</select> <input class="txt" type="text" style="width:113px" id="url'.$it618_group_group['id'].'" name="it618_ico['.$it618_group_group['id'].']" readonly="readonly" value="'.$it618_group_group['it618_ico'].'" /><input type="button" id="image'.$it618_group_group['id'].'" value="'.$it618_group_lang['s123'].'" /><br>'.$pbuidsstr.'</div>',
			$it618_group_lang['s365'].'<input type="text" class="txt" style="width:50px;margin-right:3px;color:red" name="it618_xgzk['.$it618_group_group['id'].']" value="'.$it618_group_group['it618_xgzk'].'">% '.$it618_group_lang['s366'].'<br>'.$it618_group_lang['s262'].'<input type="text" class="txt" style="width:50px;margin-left:3px;margin-right:0px" name="it618_txtime1['.$it618_group_group['id'].']" value="'.$it618_group_group['it618_txtime1'].'">
			'.$it618_group_lang['s263'].'<input type="text" class="txt" style="width:20px;margin-left:3px;margin-right:0px" name="it618_txtime2['.$it618_group_group['id'].']" value="'.$it618_group_group['it618_txtime2'].'">'.$it618_group_lang['s264'].'<br>
			'.$groupzkstr.'
			'.$groupsalepowerstr.'
			'.$videopidstr,
			'<input class="checkbox" type="checkbox" id="it618_switch'.$it618_group_group['id'].'" name="it618_switch['.$it618_group_group['id'].']" '.$it618_switch_checked.' value="1"><label for="it618_switch'.$it618_group_group['id'].'">'.$it618_group_lang['s320'].'</label>',
			'<input class="checkbox" type="checkbox" id="it618_ispublic'.$it618_group_group['id'].'" name="it618_ispublic['.$it618_group_group['id'].']" '.$it618_ispublic_checked.' value="1"><label for="it618_ispublic'.$it618_group_group['id'].'">'.$it618_group_lang['s320'].'</label>',
			'<input type="text" class="txt" style="width:30px" name="it618_order['.$it618_group_group['id'].']" value="'.$it618_group_group['it618_order'].'">',
			$goodscount
		));
		
		$editorjs.='K(\'#image'.$it618_group_group['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url'.$it618_group_group['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$it618_group_group['id'].'\').val(url);
								K(\'#img'.$it618_group_group['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});
				';
	}
	
		echo '
<link rel="stylesheet" href="source/plugin/it618_group/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_group/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_group/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var editor = K.editor({
					uploadJson : \'source/plugin/it618_group/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/it618_group/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$editorjs.'
			});
</script>';

echo '
	<script>
	function showgrouppowers(gid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_group_lang['s6'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_group:sc_group_powers&gid="+gid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	
	function showpbuids(gid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_group_lang['s396'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_group:sc_group_pbuids&gid="+gid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}

	function showgroupagree(gid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_group_lang['s318'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_group:sc_group_agree&gid="+gid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	
	function showgroupzk(gid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_group_lang['s380'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_group:sc_group_zk&shoptype='.$shoptype.'&gid="+gid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	
	function showgroupsalepower(gid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_group_lang['s390'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_group:sc_group_salepower&shoptype='.$shoptype.'&gid="+gid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	</script>
	';

if($videopidstr!=''){
	echo '
	<script>
	function showvideopid(gid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_group_lang['s220'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["930px", "430px"],
			content: "plugin.php?id=it618_group:sc_group_videopids&gid="+gid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	</script>
	';
}
	
	echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type="submit" class="btn" name="it618submit" value="'.$it618_group_lang['s10'].'"/><input type=hidden value='.$page.' name=page /></div><br></td></tr>';
	echo '<tr><td colspan=10 style="line-height:23px;">'.$it618_group_lang['s13'].'</td></tr>';
	if(count($reabc)!=11)return;
    showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>