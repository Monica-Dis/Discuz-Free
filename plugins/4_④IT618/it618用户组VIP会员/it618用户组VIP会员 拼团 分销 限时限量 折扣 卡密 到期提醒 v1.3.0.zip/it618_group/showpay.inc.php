<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_group = $_G['cache']['plugin']['it618_group'];
require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';

$pid=intval($_GET['pid']);

if($it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($pid)){
	if($it618_group_goods['it618_state']==0){
		echo it618_group_getlang('s141');exit;
	}
}else{
	echo it618_group_getlang('s141');exit;
}

$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_group['it618_groupid']);

$it618_unit=it618_group_getgoodsunit($it618_group_goods);

if($_G['uid']>0){
	$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
	$groupterms = dunserialize($memberfieldforum['groupterms']);
	unset($memberfieldforum);
	
	if(!empty($groupterms['ext'])) {
		foreach($groupterms['ext'] as $extgroupid => $time) {
			if($it618_group_goods['it618_groupid']==$extgroupid){
				if($time-3600*24*365*60>$_G['timestamp']){
					$iszk=1;
					$grouptime=$it618_group_lang['s64'];
				}else{
					$grouptime=dgmdate($time, 'd');
					if($time>$_G['timestamp']){
						$iszk=1;	
					}
				}
				break;
			}
		}
	}
	
	if($_G['groupid']!=$it618_group_goods['it618_groupid']&&$it618_group_group['it618_switch']==1){
		$isswitch=1;
	}
}

if($grouptime!=''){
	$grouptime=$it618_group_lang['s163'].$grouptime;
}

if($it618_group_group['it618_xgzk']>0&&$iszk==1){
	$it618_xgzk='<img src="source/plugin/it618_group/images/zk.png" style="vertical-align:middle;margin-top:-3px;height:23px;margin-left:3px"> '.$it618_group_lang['s365'].'<font color=red>'.$it618_group_group['it618_xgzk'].'%</font>';
}

if($it618_group_goods['it618_counttype']==1){
	$countstr=$it618_group_lang['s130'];
	if($it618_group_goods['it618_xgcount']>0){
		$countstr=$it618_group_lang['s131'];
		$countstr=str_replace("{xgcount}",$it618_group_goods['it618_xgcount'],$countstr);
		
		$tomonth = date('n'); 
		$todate = date('j'); 
		$toyear = date('Y');
		$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
		$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_group_sale')." where it618_pid=".$it618_group_goods['id']." and it618_time>$time and it618_state=1");
		
		$countstr=str_replace("{xgcount1}",$it618_group_goods['it618_xgcount']-$buycount,$countstr);
	}
	$countstr=str_replace("{count}",$it618_group_goods['it618_count'],$countstr);
}

$goodspricestr=it618_group_getgoodsprice($it618_group_goods);
$it618_price=$it618_group_goods['it618_price'];

$it618_powers=explode("@@@",str_replace(array("\r\n", "\r", "\n"), '@@@', $it618_group_group['it618_power']));
foreach($it618_powers as $key => $it618_power){
	if($it618_power!=""){
		$grouppower.='<tr><td><img src="source/plugin/it618_group/template/default/images/vipabout.png">'.$it618_power.'</td></tr>';
	}
}

$_G['mobiletpl'][IN_MOBILE]='/';
if($_GET['wap']==1){
	include template('it618_group:showpay_wap');
}else{
	include template('it618_group:showpay');
}
?>