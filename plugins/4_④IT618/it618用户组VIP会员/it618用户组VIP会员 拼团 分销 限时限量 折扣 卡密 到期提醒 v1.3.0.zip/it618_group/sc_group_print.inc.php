<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tmpidarr=explode(":",$_GET['id']);
$tempabc=$tmpidarr[0];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_group/feieyun/function.func.php';

$it618_waimai = $_G['cache']['plugin']['it618_waimai'];
$it618_brand = $_G['cache']['plugin']['it618_brand'];
$it618_tuan = $_G['cache']['plugin']['it618_tuan'];

$shoptype='';
if($it618_waimai['waimai_name']!=''&&$shoptype=='')$shoptype='waimai';
if($it618_brand['brand_name']!=''&&$shoptype=='')$shoptype='brand';
if($it618_tuan['seotitle']!=''&&$shoptype=='')$shoptype='tuan';

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_group_print = C::t('#it618_group#it618_group_print')->fetch_by_id($delid);
		
		$printreturn=printerDelList($it618_group_print['it618_sn']);
		if($printreturn['msg']=='ok'){
			DB::delete('it618_group_print', "id=$delid");
			$del=$del+1;
		}else{
			$delerr.='<br>'.$sn.': '.it618_group_utftogbk($printreturn['msg']).'<br>';
		}
	}

	if(is_array($_GET['it618_about'])) {
		foreach($_GET['it618_about'] as $id => $val) {

			C::t('#it618_group#it618_group_print')->update($id,array(
				'it618_about' => trim($_GET['it618_about'][$id]),
				'it618_isok' => trim($_GET['it618_isok'][$id])
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_sn_array = !empty($_GET['newit618_sn']) ? $_GET['newit618_sn'] : array();
	$newit618_key_array = !empty($_GET['newit618_key']) ? $_GET['newit618_key'] : array();
	$newit618_about_array = !empty($_GET['newit618_about']) ? $_GET['newit618_about'] : array();
	
	foreach($newit618_sn_array as $key => $value) {
		$newit618_sn = addslashes(trim($newit618_sn_array[$key]));
		
		if($newit618_sn != '') {
			$sn=trim($newit618_sn_array[$key]);
			$key=trim($newit618_key_array[$key]);
			
			$printerContent = "$sn#$key##";
			$printreturn=printerAddlist($printerContent);
			
			if($printreturn['msg']=='ok'){
				C::t('#it618_group#it618_group_print')->insert(array(
					'it618_sn' => $sn,
					'it618_key' => $key,
					'it618_about' => trim($newit618_about_array[$key])
				), true);
				
				$ok2=$ok2+1;
			}else{
				$adderr.='<br>'.$sn.': '.it618_group_utftogbk($printreturn['msg']).'<br>';
			}
			
		}
	}

	it618_cpmsg($it618_group_lang['s33'].$ok1.' '.$it618_group_lang['s34'].$ok2.$adderr.' '.$it618_group_lang['s35'].$del.')', "plugin.php?id=it618_group:sc_group_print&page=$page", 'succeed');
}

if(count($reabc)!=11)return;

it618_showformheader("plugin.php?id=it618_group:sc_group_print&page=$page");
showtableheaders($it618_group_lang['s442'],'it618_group_print');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_group_print'));
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_group:sc_group_print&page=$page");
	
	echo '<tr><td colspan=10>'.$it618_group_lang['s463'].$count.'<span style="float:right">'.$it618_group_lang['s450'].'</span></td></tr>';
	showsubtitle(array('', $it618_group_lang['s443'], $it618_group_lang['s444'], $it618_group_lang['s446'],$it618_group_lang['s445'],$it618_group_lang['s448']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_print')." ORDER BY id desc LIMIT $startlimit, $ppp");
	while($it618_group_print = DB::fetch($query)) {
		
		$shopcount1=DB::result_first("select count(1) from ".DB::table('it618_group_printshop')." where it618_isok=1 and it618_prid=".$it618_group_print['id']);
		$shopcount='<font color=red>'.$shopcount1.'</font>';
		
		if($it618_group_print['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
		
		$salecount=C::t('#it618_group#it618_group_printsale')->count_by_it618_prid($it618_group_print['id']);
		$disabled="";
		if($salecount>0||$shopcount1>0)$disabled="disabled=\"disabled\"";
		
		showtablerow('', array('class="td25"', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="adid'.$it618_group_print['id'].'" name="delete[]" value="'.$it618_group_print['id'].'" '.$disabled.'><label for="adid'.$it618_group_print['id'].'">'.$it618_group_print['id'].'</label>',
			$it618_group_print['it618_sn'],
			$it618_group_print['it618_key'],
			'<a href="javascript:" onclick="showprintshop('.$it618_group_print['id'].')">'.$it618_group_lang['s447'].'('.$shopcount.')</a>',
			'<input class="txt" type="text" name="it618_about['.$it618_group_print['id'].']" value="'.$it618_group_print['it618_about'].'" style="width:300px">',
			'<input class="checkbox" type="checkbox" id="it618_isok'.$it618_group_print['id'].'" name="it618_isok['.$it618_group_print['id'].']" '.$it618_isok_checked.' value="1"><label for="it618_isok'.$it618_group_print['id'].'">'.$it618_group_lang['s329'].'</label>',
		));
	}
	
	$it618_group_lang449=$it618_group_lang['s449'];

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	
echo '
	<script>
	function showprintshop(prid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_group_lang['s465'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_group:sc_group_printshop&shoptype='.$shoptype.'&prid="+prid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	</script>
	';
	
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_sn[]").length;
	
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:150px;margin-right:3px" name="newit618_sn[]">'],
		[1,'<input type="text" class="txt" style="width:150px;margin-right:3px" name="newit618_key[]">'], 
		[1,'$it618_group_lang449'], 
		[1,'<input type="text" class="txt" style="width:300px" name="newit618_about[]">'], 
		[1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$it618_group_lang['s119'].'</a></div></td></tr>';
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_group_lang['s591'].'</label></td><td colspan="4"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.$it618_group_lang['s120'].'"/></div></td></tr>';
	if(count($reabc)!=11)return;
    showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>