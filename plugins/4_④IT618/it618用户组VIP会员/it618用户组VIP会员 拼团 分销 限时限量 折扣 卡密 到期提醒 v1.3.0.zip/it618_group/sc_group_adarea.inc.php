<?php
 /**
 *	�����Ŷӣ�DisM.Taobao.Com
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';

$aid=intval($_GET['aid']);

$it618_group_ad=C::t('#it618_group#it618_group_ad')->fetch_by_id($aid);

if($it618_group_ad['it618_type']==1){
	$it618_type=$it618_group_lang['s406'];
	$size=$it618_group_ad['it618_width'].'% * '.$it618_group_ad['it618_height'].'%';
}else{
	$it618_type=$it618_group_lang['s407'];
	$size=$it618_group_ad['it618_width'].'px * '.$it618_group_ad['it618_height'].'px';
}

$it618_video = $_G['cache']['plugin']['it618_video'];
$it618_exam = $_G['cache']['plugin']['it618_exam'];
$it618_brand = $_G['cache']['plugin']['it618_brand'];
$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
$it618_waimai = $_G['cache']['plugin']['it618_waimai'];

$it618_sale = $_G['cache']['plugin']['it618_sale'];
$it618_scoremall = $_G['cache']['plugin']['it618_scoremall'];
$it618_auction = $_G['cache']['plugin']['it618_auction'];
$it618_paotui = $_G['cache']['plugin']['it618_paotui'];

if(submitcheck('it618submit')){
	C::t('#it618_group#it618_group_adarea')->update_it618_isok_by_aid(0,$aid);
	
	$adarea_array = !empty($_GET['adareatmp']) ? $_GET['adareatmp'] : array();
	foreach($adarea_array as $key => $value) {
		$plugin=$_GET['adarea'][$key];
		if($plugin!=''){
			if($it618_group_adarea=C::t('#it618_group#it618_group_adarea')->fetch_by_plugin_aid($plugin,$aid)){
				C::t('#it618_group#it618_group_adarea')->update($it618_group_adarea['id'],array(
					'it618_isok' => 1
				));
			}else{
				C::t('#it618_group#it618_group_adarea')->insert(array(
					'it618_plugin' => $plugin,
					'it618_aid' => $aid,
					'it618_isok' => 1
				), true);
			}
		}
	}
	
	C::t('#it618_group#it618_group_ad')->update($it618_group_ad['id'],array(
		'it618_urlarea' => $_GET['it618_urlarea']
	));
	
	echo '<script>parent.location.reload();parent.layer.closeAll();</script>';
}

function getpluginarea($plugin,$n,$aid,$title){
	global $it618_group_lang;
	
	$it618_group_adarea=C::t('#it618_group#it618_group_adarea')->fetch_by_plugin_aid($plugin,$aid);
	$tmpchecked='';
	if($it618_group_adarea['it618_isok']==1){
		$tmpchecked='checked="checked"';
	}
	
	return '<li><input type="hidden" name="adareatmp['.$n.']"><input type="checkbox" id="adarea'.$n.'" name="adarea['.$n.']" value="'.$plugin.'" '.$tmpchecked.'><label for="adarea'.$n.'">'.$title.'</label></li>';
}

$n=0;
$adarea_strtmp=getpluginarea('group',$n,$aid,$it618_group_lang['s415']);

if($it618_video['seotitle']!=''){
	$n=$n+1;
	$adarea_strtmp.=getpluginarea('video',$n,$aid,$it618_group_lang['s381']);
}
if($it618_exam['seotitle']!=''){
	$n=$n+1;
	$adarea_strtmp.=getpluginarea('exam',$n,$aid,$it618_group_lang['s382']);
}
if($it618_brand['brand_name']!=''){
	$n=$n+1;
	$adarea_strtmp.=getpluginarea('brand',$n,$aid,$it618_group_lang['s383']);
}
if($it618_tuan['seotitle']!=''){
	$n=$n+1;
	$adarea_strtmp.=getpluginarea('tuan',$n,$aid,$it618_group_lang['s384']);
}
if($it618_waimai['waimai_name']!=''){
	$n=$n+1;
	$adarea_strtmp.=getpluginarea('waimai',$n,$aid,$it618_group_lang['s385']);
}
if($IsMembers==1&&$it618_group_ad['it618_type']==1){
	$n=$n+1;
	$adarea_strtmp.=getpluginarea('members',$n,$aid,$it618_group_lang['s600']);
}
if($IsCredits==1&&$it618_group_ad['it618_type']==1){
	$n=$n+1;
	$adarea_strtmp.=getpluginarea('credits',$n,$aid,$it618_group_lang['s601']);
}
if($IsUnion==1){
	$n=$n+1;
	$adarea_strtmp.=getpluginarea('union',$n,$aid,$it618_group_lang['s602']);
}
if($it618_sale['seotitle']!=''){
	$n=$n+1;
	$adarea_strtmp.=getpluginarea('sale',$n,$aid,$it618_group_lang['s603']);
}
if($it618_scoremall['seotitle']!=''){
	$n=$n+1;
	$adarea_strtmp.=getpluginarea('scoremall',$n,$aid,$it618_group_lang['s604']);
}
if($it618_auction['seotitle']!=''){
	$n=$n+1;
	$adarea_strtmp.=getpluginarea('auction',$n,$aid,$it618_group_lang['s605']);
}
if($it618_paotui['paotui_name']!=''&&$it618_group_ad['it618_type']==1){
	$n=$n+1;
	$adarea_strtmp.=getpluginarea('paotui',$n,$aid,$it618_group_lang['s606']);
}

it618_showformheader("plugin.php?id=it618_group:sc_group_adarea&aid=$aid");
showtableheaders($it618_group_lang['s401'].$aid.' <font color=red>'.$it618_type.'</font> '.$it618_group_lang['s414'].$size,'sc_group_adarea');

echo '
<style>
.goodsul{float:left;width:99%;padding:10px;padding-right:0}
.goodsul li{float:left;width:150px;padding-top:5px;padding-bottom:5px}
.goodsul li label,.goodsul li input{vertical-align:middle}
</style>

<tr><td><ul class="goodsul">'.$adarea_strtmp.'</ul></td></tr>
<tr><td><br>'.$it618_group_lang['s416'].'<br><br>
<textarea name="it618_urlarea" style="width:800px;height:280px;line-height:18px;font-size:13px">'.$it618_group_ad['it618_urlarea'].'</textarea><br><br>
'.$it618_group_lang['s417'].'<br>
</td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_group_getlang('s10').'" /></div></td></tr>';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>