<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$oss;

$it618_group = $_G['cache']['plugin']['it618_group'];

require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';

$ppp = $it618_group['pagecount'];
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

if($_G['uid']<=0){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		if(!group_is_mobile()){ 
			require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
			$it618_members_index=it618_members_getmembers($_GET['id'],'#it618_members','','winapilogin');
			echo '<script type="text/javascript" src="source/plugin/it618_group/js/jquery.js"></script>'.$it618_members_index;exit;
		}
	}
	
	dheader("location:member.php?mod=logging&action=login");
}else{
	global $oss;
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/php/aliyunossconfig.php')){
		require_once DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/php/aliyunossconfig.php';
		if($it618_isok==1){
			$oss='&oss';
		}
	}
	
	$group_adminuids=explode(",",$it618_group['group_adminuids']);
	if(!in_array($_G['uid'], $group_adminuids)){
		echo it618_group_getlang('s194');exit;
	}
	
	$urltmp='member.php?mod=logging&action=logout&formhash='.FORMHASH;
	$username=$_G['username'];
	$u_avatarimg=it618_group_discuz_uc_avatar($_G['uid'],'middle');
}
?>