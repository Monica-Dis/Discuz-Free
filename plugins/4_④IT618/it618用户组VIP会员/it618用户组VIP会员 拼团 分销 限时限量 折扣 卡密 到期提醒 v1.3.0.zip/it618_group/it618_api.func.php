<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsUnion,$IsCredits,$IsChat,$it618_group,$it618_hongbao_lang;

if($IsUnion==1&&($pagetype=='group_product'||$pagetype=='product')){
	$sql='it618_ison=1 and (it618_pids=\'\' or CONCAT(\',\',it618_pids,\',\') like \'%,'.$pid.',%\')';
	$quancount=C::t('#it618_union#it618_union_quan')->count_by_shoptype_shopid('group',0,$sql);
	$shopquanurl=it618_group_union_getrewrite('union_quans','','plugin.php?id=it618_union:union_quans');

	if($quancount>0){
		
		$union_quanmoney=C::t('#it618_union#it618_union_quan')->fetch_money_by_shoptype_shopid('group',0,$sql,'it618_money desc');
		if($union_quanmoney>0){
			$union_quan=$it618_union_lang['s1584'].$union_quanmoney.$it618_union_lang['s1585'];
		}
		$union_quanmoney=C::t('#it618_union#it618_union_quan')->fetch_mjmoney_by_shoptype_shopid('group',0,$sql,'it618_mjmoney2 desc');
		if($union_quanmoney['it618_mjmoney2']>0){
			$union_quan.=' '.$it618_union_lang['s1582'].$union_quanmoney['it618_mjmoney1'].$it618_union_lang['s1585'].$it618_union_lang['s1583'].$union_quanmoney['it618_mjmoney2'].$it618_union_lang['s1585'];
		}
	}
	
	$tuicount=C::t('#it618_union#it618_union_tui')->count_by_shoptype_shopid('group',0,$sql);
	if($tuicount>0){
		$union_tuitcbl=C::t('#it618_union#it618_union_tui')->fetch_tc_by_shoptype_shopid('group',0,$sql,'it618_tcbl desc');
		$union_tuitc=$it618_union_lang['s1580'].str_replace(".00","",$union_tuitcbl).'%'.$it618_union_lang['s1581'];
	}
}

if($IsUnion==1){
	$tuipower=1;
	$tuiuid=intval($_GET['tuiuid']);
	if($tuiuid>0){
		$usercount=DB::result_first("SELECT count(1) FROM ".DB::table('common_member')." WHERE uid=".$tuiuid);
		if($usercount>0){
			$groupid=DB::result_first("select groupid from ".DB::table('common_member')." where uid=".$tuiuid);
			$union_tuigroup=(array)unserialize($it618_union['union_tuigroup']);
			if(!in_array($groupid, $union_tuigroup)&&$union_tuigroup[0]!=''){
				$tuipower=0;
			}
		}
	}
	
	if($tuipower==1){
		if($it618_union['union_cookietime']==0)$union_cookietime=3600;else $union_cookietime=$it618_union['union_cookietime']*3600;
		dsetcookie('it618_union_tuiuid',$tuiuid,$union_cookietime);
	}
}

if($IsPinEdu==1&&($pagetype=='group_product'||$pagetype=='product')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/function.func.php';
	$shoptype='group';
	$pingoods=it618_pinedu_getpingoods($shoptype,$it618_group_goods['id'],$wap);
	if($pingoods['pinstr']!=''){
		$ispinok=1;
		$jqueryname='IT618_GROUP';
		if($wap==1){
			if($_GET['e']!=''){
				$pinurl=$_G['siteurl'].it618_group_getrewrite('group_wap','pin@tmptypeid@tmpspid','plugin.php?id=it618_group:wap&pagetype=pin&cid1=tmptypeid&cid2=tmpspid'.'&e='.$_GET['e'],'?e='.$_GET['e']);
			}else{
				$pinurl=$_G['siteurl'].it618_group_getrewrite('group_wap','pin@tmptypeid@tmpspid','plugin.php?id=it618_group:wap&pagetype=pin&cid1=tmptypeid&cid2=tmpspid');
			}
			
			$tmpmobiletpl=$_G['mobiletpl'][IN_MOBILE];
			$_G['mobiletpl'][IN_MOBILE]='/';
			include template('it618_pinedu:pinsale');
			$_G['mobiletpl'][IN_MOBILE]=$tmpmobiletpl;
		}else{
			include template('it618_pinedu:pinsale');
		}
	}
}
?>