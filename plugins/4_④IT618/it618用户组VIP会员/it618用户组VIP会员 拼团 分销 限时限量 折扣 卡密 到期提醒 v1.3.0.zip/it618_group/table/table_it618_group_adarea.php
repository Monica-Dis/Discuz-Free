<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_group_adarea extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_group_adarea';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function count_by_search() {
		return DB::result_first("SELECT COUNT(1) FROM %t", array($this->_table));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_groupid($groupid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_groupid=%d", array($this->_table, $groupid));
	}
	
	public function fetch_by_plugin_aid($plugin,$aid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_plugin=%s and it618_aid=%d", array($this->_table, $plugin, $aid));
	}
	
	public function fetch_by_plugin_aid_ok($plugin,$aid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_isok=1 and it618_plugin=%s and it618_aid=%d", array($this->_table, $plugin, $aid));
	}
	
	public function fetch_by_search() {
		return DB::fetch_first("SELECT * FROM %t", array($this->_table));
	}
	
	public function update_it618_isok_by_aid($isok,$aid) {
		DB::query("UPDATE %t SET it618_isok=%d WHERE it618_aid=%d", array($this->_table, $isok, $aid));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}

?>