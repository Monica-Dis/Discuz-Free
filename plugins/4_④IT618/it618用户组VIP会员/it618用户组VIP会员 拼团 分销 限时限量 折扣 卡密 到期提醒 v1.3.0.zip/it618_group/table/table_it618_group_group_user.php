<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_group_group_user extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_group_group_user';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_groupid_uid($groupid, $uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_groupid=%d and it618_uid=%d", array($this->_table, $groupid, $uid));
	}
	
	public function count_by_search($it618sql = '', $it618orderby = '', $groupid=0, $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $groupid, $it618_uid, $it618_time1, $it618_time2);
		return DB::result_first("SELECT count(1) FROM %t s LEFT JOIN ".DB::table('it618_group_group')." g ON s.it618_groupid=g.it618_groupid $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby = '', $groupid=0, $it618_uid = 0, $it618_time1 = '', $it618_time2 = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $groupid, $it618_uid, $it618_time1, $it618_time2);
		$data = array();
		$query = DB::query("SELECT s.* FROM %t s LEFT JOIN ".DB::table('it618_group_group')." g ON s.it618_groupid=g.it618_groupid $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby = '', $groupid=0, $it618_uid = 0, $it618_time1 = '', $it618_time2 = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($groupid)) {
			$parameter[] = $groupid;
			$wherearr[] = 's.it618_groupid=%d';
		}
		if(!empty($it618_uid)) {
			$parameter[] = $it618_uid;
			$wherearr[] = 's.it618_uid=%d';
		}
		if(!empty($it618_time1)) {
			$parameter[] = $it618_time1;
			$wherearr[] = 's.it618_etime>=unix_timestamp(%s)';
		}
		if(!empty($it618_time2)) {
			$parameter[] = $it618_time2.' 23:59:59';
			$wherearr[] = 's.it618_etime<=unix_timestamp(%s)';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}

?>