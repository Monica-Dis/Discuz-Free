<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_group_salework extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_group_salework';
		$this->_pk = 'id';
		parent::__construct();
	}
}

?>