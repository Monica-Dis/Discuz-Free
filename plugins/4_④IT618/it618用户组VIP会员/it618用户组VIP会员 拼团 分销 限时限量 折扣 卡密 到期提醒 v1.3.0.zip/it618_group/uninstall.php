<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_group_nav`;

DROP TABLE IF EXISTS `pre_it618_group_focus`;

DROP TABLE IF EXISTS `pre_it618_group_bottomnav`;

DROP TABLE IF EXISTS `pre_it618_group_set`;

DROP TABLE IF EXISTS `pre_it618_group_wapstyle`;

DROP TABLE IF EXISTS `pre_it618_group_class`;

DROP TABLE IF EXISTS `pre_it618_group_group`;

DROP TABLE IF EXISTS `pre_it618_group_group_zk`;

DROP TABLE IF EXISTS `pre_it618_group_group_salepower`;

DROP TABLE IF EXISTS `pre_it618_group_rzmoney`;

DROP TABLE IF EXISTS `pre_it618_group_user`;

DROP TABLE IF EXISTS `pre_it618_group_group_user`;

DROP TABLE IF EXISTS `pre_it618_group_goods`;

DROP TABLE IF EXISTS `pre_it618_group_goods_km`;

DROP TABLE IF EXISTS `pre_it618_group_sale`;

DROP TABLE IF EXISTS `pre_it618_group_salejl`;

DROP TABLE IF EXISTS `pre_it618_group_salekm`;

DROP TABLE IF EXISTS `pre_it618_group_ad`;

DROP TABLE IF EXISTS `pre_it618_group_adarea`;

DROP TABLE IF EXISTS `pre_it618_group_adgroup`;

DROP TABLE IF EXISTS `pre_it618_group_print`;

DROP TABLE IF EXISTS `pre_it618_group_printshop`;

DROP TABLE IF EXISTS `pre_it618_group_printsale`;

DROP TABLE IF EXISTS `pre_it618_group_salework`;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>