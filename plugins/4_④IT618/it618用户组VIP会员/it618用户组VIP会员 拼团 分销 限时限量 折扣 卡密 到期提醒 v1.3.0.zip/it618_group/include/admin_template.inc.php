<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_group/config/templateset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_group/config/templateset.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_group/config/templateset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$group_template_set[\'pcname\']=\''.trim($_GET['template_pcname'])."';\n";
		$fileData .= '$group_template_set[\'wapname\']=\''.trim($_GET['template_wapname'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_group_lang['s21'], "action=plugins&identifier=$identifier&cp=admin_template&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

$pcnameoption='<option value="default">'.$it618_group_lang['s106'].'</option>';
$pcnameoption=str_replace('<option value="'.$group_template_set['pcname'].'"','<option value="'.$group_template_set['pcname'].'" selected="selected"',$pcnameoption);

$wapnameoption='<option value="default_wap">'.$it618_group_lang['s106'].'</option>';
$wapnameoption=str_replace('<option value="'.$group_template_set['wapname'].'"','<option value="'.$group_template_set['wapname'].'" selected="selected"',$wapnameoption);

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_template&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_group_lang['s103'].'</th></tr>
<tr class="header"><th width=180>'.$it618_group_lang['s107'].'</th><th>'.$it618_group_lang['s108'].'</th><th>'.$it618_group_lang['s109'].'</th></tr>

<tr class="hover">
<td>'.$it618_group_lang['s104'].'</td><td class="longtxt">
<select name="template_pcname">
	'.$pcnameoption.'
</select></td>
<td>'.$it618_group_lang['s110'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_group_lang['s105'].'</td><td class="longtxt">
<select name="template_wapname">
	'.$wapnameoption.'
</select></td>
<td>'.$it618_group_lang['s110'].'</td>
</tr>

</table>
';

showsubmit('it618submit', $it618_group_lang['s10']);

if(count($reabc)!=11)return;
showtablefooter();

?>