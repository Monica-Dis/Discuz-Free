<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618_video = $_G['cache']['plugin']['it618_video'];
$it618_exam = $_G['cache']['plugin']['it618_exam'];
$it618_brand = $_G['cache']['plugin']['it618_brand'];
$it618_tuan = $_G['cache']['plugin']['it618_tuan'];
$it618_waimai = $_G['cache']['plugin']['it618_waimai'];

if($it618_video['seotitle']!=''){
	if(C::t('#it618_group#it618_group_rzmoney')->count_by_shoptype_lid('video',0)==0){
		C::t('#it618_group#it618_group_rzmoney')->insert(array(
			'it618_shoptype' => 'video',
			'it618_lid' => 0
		), true);
	}
}
if($it618_exam['seotitle']!=''){
	if(C::t('#it618_group#it618_group_rzmoney')->count_by_shoptype_lid('exam',0)==0){
		C::t('#it618_group#it618_group_rzmoney')->insert(array(
			'it618_shoptype' => 'exam',
			'it618_lid' => 0
		), true);
	}
}
if($it618_brand['brand_name']!=''){
	$query = DB::query("SELECT * FROM ".DB::table('it618_brand_brandgroup')." ORDER BY it618_order");
	while($it618_brand_brandgroup = DB::fetch($query)) {
		if(C::t('#it618_group#it618_group_rzmoney')->count_by_shoptype_lid('brand',$it618_brand_brandgroup['id'])==0){
			C::t('#it618_group#it618_group_rzmoney')->insert(array(
				'it618_shoptype' => 'brand',
				'it618_lid' => $it618_brand_brandgroup['id']
			), true);
		}
	}
}
if($it618_tuan['seotitle']!=''){
	if(C::t('#it618_group#it618_group_rzmoney')->count_by_shoptype_lid('tuan',0)==0){
		C::t('#it618_group#it618_group_rzmoney')->insert(array(
			'it618_shoptype' => 'tuan',
			'it618_lid' => 0
		), true);
	}
}
if($it618_waimai['waimai_name']!=''){
	$query = DB::query("SELECT * FROM ".DB::table('it618_waimai_waimaigroup')." ORDER BY it618_order");
	while($it618_waimai_waimaigroup = DB::fetch($query)) {
		if(C::t('#it618_group#it618_group_rzmoney')->count_by_shoptype_lid('waimai',$it618_waimai_waimaigroup['id'])==0){
			C::t('#it618_group#it618_group_rzmoney')->insert(array(
				'it618_shoptype' => 'waimai',
				'it618_lid' => $it618_waimai_waimaigroup['id']
			), true);
		}
	}
}

if(submitcheck('it618submit_edit')){
	
	if(is_array($_GET['it618_groupid'])) {
		foreach($_GET['it618_groupid'] as $id => $val) {

			C::t('#it618_group#it618_group_rzmoney')->update($id,array(
				'it618_groupid' => trim($_GET['it618_groupid'][$id]),
				'it618_isautocheck' => trim($_GET['it618_isautocheck'][$id]),
				'it618_istbtime' => trim($_GET['it618_istbtime'][$id])
			));
		}
	}

	cpmsg($it618_group_lang['s434'], "action=plugins&identifier=$identifier&cp=admin_rzmoney&pmod=admin_rzmoney&operation=$operation&do=$do&page=$page", 'succeed');
}

$query1 = DB::query("SELECT * FROM ".DB::table('it618_group_group')." ORDER BY it618_order desc");
while($it618_tmp =	DB::fetch($query1)) {
	$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_tmp['it618_groupid']);
	$tmp.='<option value='.$it618_tmp['it618_groupid'].'>'.$grouptitle.'</option>';
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_rzmoney&pmod=admin_rzmoney&operation=$operation&do=$do");
showtableheaders($it618_group_lang['s423'],'it618_group_rzmoney');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_group_rzmoney')." w WHERE 1 $extrasql");
	
	echo '<tr><td colspan=10>'.$it618_group_lang['s435'].'</td></tr>';
	echo '<tr><td colspan=10>'.$it618_group_lang['s257'].$count.'<span style="float:right;color:red">'.$it618_group_lang['s424'].'</span></td></tr>';
	showsubtitle(array($it618_group_lang['s427'],$it618_group_lang['s428'],$it618_group_lang['s429'],$it618_group_lang['s430']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_rzmoney')." WHERE 1 $extrasql ORDER BY it618_shoptype,it618_lid");
	while($it618_group_rzmoney = DB::fetch($query)) {
		
		if($it618_group_rzmoney['it618_isautocheck']==1)$it618_isautocheck_checked='checked="checked"';else $it618_isautocheck_checked="";
		if($it618_group_rzmoney['it618_istbtime']==1)$it618_istbtime_checked='checked="checked"';else $it618_istbtime_checked="";
		
		if($it618_group_rzmoney['it618_shoptype']=='video'){
			$it618_shoptype=$it618_group_lang['s381'];
			$it618_groupname=$it618_group_lang['s431'];
		}
		
		if($it618_group_rzmoney['it618_shoptype']=='exam'){
			$it618_shoptype=$it618_group_lang['s382'];
			$it618_groupname=$it618_group_lang['s431'];
		}
		
		if($it618_group_rzmoney['it618_shoptype']=='tuan'){
			$it618_shoptype=$it618_group_lang['s384'];
			$it618_groupname=$it618_group_lang['s431'];
		}
		
		if($it618_group_rzmoney['it618_shoptype']=='brand'){
			$it618_shoptype=$it618_group_lang['s383'];
			$it618_groupname=DB::result_first("SELECT it618_groupname FROM ".DB::table('it618_brand_brandgroup')." WHERE id=".$it618_group_rzmoney['it618_lid']);
		}
		
		if($it618_group_rzmoney['it618_shoptype']=='waimai'){
			$it618_shoptype=$it618_group_lang['s385'];
			$it618_groupname=DB::result_first("SELECT it618_groupname FROM ".DB::table('it618_waimai_waimaigroup')." WHERE id=".$it618_group_rzmoney['it618_lid']);
		}
		
		$tmp1=str_replace('<option value='.$it618_group_rzmoney['it618_groupid'].'>','<option value='.$it618_group_rzmoney['it618_groupid'].' selected="selected">',$tmp);
		
		showtablerow('', array('', ''), array(
			$it618_shoptype,
			$it618_groupname,
			'<select name="it618_groupid['.$it618_group_rzmoney['id'].']"><option value=0>'.$it618_group_lang['s432'].'</option>'.$tmp1.'</select>',
			'<input class="checkbox" type="checkbox" id="it618_isautocheck'.$it618_group_rzmoney['id'].'" name="it618_isautocheck['.$it618_group_rzmoney['id'].']" '.$it618_isautocheck_checked.' value="1"><label for="it618_isautocheck'.$it618_group_rzmoney['id'].'">'.$it618_group_lang['s425'].'</label>
			<input class="checkbox" type="checkbox" id="it618_istbtime'.$it618_group_rzmoney['id'].'" name="it618_istbtime['.$it618_group_rzmoney['id'].']" '.$it618_istbtime_checked.' value="1"><label for="it618_istbtime'.$it618_group_rzmoney['id'].'">'.$it618_group_lang['s426'].'</label>'
		));
	}

	echo '<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit_edit" value="'.$it618_group_lang['s433'].'"/></div></td></tr>';

	if(count($reabc)!=11)return;
showtablefooter();
?>