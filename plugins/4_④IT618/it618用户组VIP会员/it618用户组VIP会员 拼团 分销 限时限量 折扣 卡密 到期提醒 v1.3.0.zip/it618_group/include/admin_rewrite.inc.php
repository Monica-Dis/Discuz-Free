<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_group/config/rewrite.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_group/config/rewrite.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_group/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$group_class=\''.'groups'."';\n";
		$fileData .= '$group_product=\''.'group'."';\n";
		$fileData .= '$group_sc=\''.'group_sc'."';\n";
		$fileData .= '$group_wap=\''.'group_wap'."';\n";
		
		$urltype='.html';
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$group_class1=\'-{cid}'.$urltype."';\n";
		$fileData .= '$group_product1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$group_sc1=\''.$urltype."';\n";
		$fileData .= '$group_wap1=\'-{pagetype}-{cid1}-{cid2}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		require DISCUZ_ROOT.'./source/plugin/it618_group/config/rewrite.php';
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_group/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$group_class=\''.str_replace("-","",$_GET['group_class'])."';\n";
		$fileData .= '$group_product=\''.str_replace("-","",$_GET['group_product'])."';\n";
		$fileData .= '$group_sc=\''.str_replace("-","",$_GET['group_sc'])."';\n";
		$fileData .= '$group_wap=\''.str_replace("-","",$_GET['group_wap'])."';\n";
		
		$urltype=str_replace("-","",$_GET['urltype']);
		$urltype=str_replace("?","",$_GET['urltype']);
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$group_class1=\'-{cid}'.$urltype."';\n";
		$fileData .= '$group_product1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$group_sc1=\''.$urltype."';\n";
		$fileData .= '$group_wap1=\'-{pagetype}-{cid1}-{cid2}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_group_lang['s209'], "action=plugins&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$strtmptitle[$cp1].'</th></tr>
<tr><td class="vtop tips2" colspan="3">'.$it618_group_lang['s236'].'</font></td></tr>
<tr><td colspan="3">'.$it618_group_lang['s237'].'<input name="urltype" value="'.$urltype.'"/></td></tr>
<tr class="header"><th>'.$it618_group_lang['s238'].'</th><th>'.$it618_group_lang['s239'].'</th><th>'.$it618_group_lang['s240'].'</th></tr>
<tr class="hover">
<td>'.$it618_group_lang['s241'].'</td><td>{cid}</td><td class="longtxt"><input name="group_class" value="'.$group_class.'"/>'.$group_class.$group_class1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_group_lang['s242'].'</td><td>{pid}</td><td class="longtxt"><input name="group_product" value="'.$group_product.'" />'.$group_product.$group_product1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_group_lang['s243'].'</td><td></td><td class="longtxt"><input name="group_sc" value="'.$group_sc.'"/>'.$group_sc.$group_sc1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_group_lang['s244'].'</td><td>{pagetype}, {cid1}, {cid2}</td><td class="longtxt"><input name="group_wap" value="'.$group_wap.'"/>'.$group_wap.$group_wap1.'</td>
</tr>
</table>
';

showsubmit('it618submit', $it618_group_lang['s10']);

$urltype1=$urltype;
if($urltype!='')$urltype=str_replace(".","\\.",$urltype);

$strtmp= '<br><h1>'.$it618_group_lang['s248'].'</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
	<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$group_class.$urltype.'$ $1/plugin.php?id=it618_group:class&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$group_class.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_group:class&cid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$group_product.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_group:product&pid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$group_sc.$urltype.'$ $1/plugin.php?id=it618_group:sc&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$group_wap.$urltype.'$ $1/plugin.php?id=it618_group:wap&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$group_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_group:wap&pagetype=$2&cid1=$3&cid2=$4&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$group_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_group:wap&pagetype=$2&cid1=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$group_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_group:wap&pagetype=$2&%1</font>
&lt;/IfModule&gt;
</pre>

<h1>'.$it618_group_lang['s249'].'</h1>
<pre class="colorbox">
'.$it618_group_lang['s250'].'
<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$group_class.$urltype.'$ plugin.php?id=it618_group:class&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$group_class.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_group:class&cid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$group_product.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_group:product&pid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$group_sc.$urltype.'$ plugin.php?id=it618_group:sc&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$group_wap.$urltype.'$ plugin.php?id=it618_group:wap&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$group_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_group:wap&pagetype=$1&cid1=$2&cid2=$3&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$group_wap.'-(.+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_group:wap&pagetype=$1&cid1=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$group_wap.'-(.+)'.$urltype.'$ plugin.php?id=it618_group:wap&pagetype=$1&%1</font>

</pre>

<h1>'.$it618_group_lang['s251'].'</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
<font color=blue>RewriteRule ^(.*)/'.$group_class.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_group:index&$3
RewriteRule ^(.*)/'.$group_class.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_group:class&cid=$2&$4
RewriteRule ^(.*)/'.$group_product.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_group:product&pid=$2&$4
RewriteRule ^(.*)/'.$group_sc.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_group:sc&$3
RewriteRule ^(.*)/'.$group_wap.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_group:wap&$3
RewriteRule ^(.*)/'.$group_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_group:wap&pagetype=$2&cid1=$3&cid2=$4&$6
RewriteRule ^(.*)/'.$group_wap.'-(.+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_group:wap&pagetype=$2&cid1=$3&$5
RewriteRule ^(.*)/'.$group_wap.'-(.+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_group:wap&pagetype=$2&$4</font>

</pre>

<h1>'.$it618_group_lang['s252'].'</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
		<font color=blue>&lt;rule name="group_class"&gt;
			&lt;match url="^(.*/)*'.$group_class.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_group:class&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="group_class1"&gt;
			&lt;match url="^(.*/)*'.$group_class.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_group:class&amp;amp;cid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="group_product"&gt;
			&lt;match url="^(./)*'.$group_product.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_group:product&amp;amp;pid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="group_sc"&gt;
			&lt;match url="^(.*/)*'.$group_sc.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_group:sc&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="group_wap"&gt;
			&lt;match url="^(.*/)*'.$group_wap.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_group:wap&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="group_wap1"&gt;
			&lt;match url="^(.*/)*'.$group_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_group:wap&amp;amp;pagetype={R:2}&amp;amp;cid1={R:3}&amp;amp;cid2={R:4}&amp;amp;{R:5}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="group_wap2"&gt;
			&lt;match url="^(.*/)*'.$group_wap.'-(.+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_group:wap&amp;amp;pagetype={R:2}&amp;amp;cid1={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="group_wap3"&gt;
			&lt;match url="^(.*/)*'.$group_wap.'-(.+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_group:wap&amp;amp;pagetype={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;</font>
	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
<font color=blue>match URL into $ with ^(.*)/'.$group_class.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_group:class&$2
endif
match URL into $ with ^(.*)/'.$group_class.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_group:class&cid=$2&$3
endif
match URL into $ with ^(.*)/'.$group_product.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_group:product&pid=$2&$3
endif
match URL into $ with ^(.*)/'.$group_sc.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_group:sc&$2
endif
match URL into $ with ^(.*)/'.$group_wap.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_group:wap&$2
endif
match URL into $ with ^(.*)/'.$group_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_group:wap&pagetype=$2&cid1=$3&cid2=$4&$5
endif
match URL into $ with ^(.*)/'.$group_wap.'-(.+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_group:wap&pagetype=$2&cid1=$3&$4
endif
match URL into $ with ^(.*)/'.$group_wap.'-(.+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_group:wap&pagetype=$2&$3
endif
</font>

</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
<font color=blue>rewrite ^([^\.]*)/'.$group_class.$urltype.'$ $1/plugin.php?id=it618_group:class&$2 last;
rewrite ^([^\.]*)/'.$group_class.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_group:class&cid=$2&$3 last;
rewrite ^([^\.]*)/'.$group_product.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_group:product&pid=$2&$3 last;
rewrite ^([^\.]*)/'.$group_sc.$urltype.'$ $1/plugin.php?id=it618_group:sc&$2 last;
rewrite ^([^\.]*)/'.$group_wap.$urltype.'$ $1/plugin.php?id=it618_group:wap&$2 last;
rewrite ^([^\.]*)/'.$group_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_group:wap&pagetype=$2&cid1=$3&cid2=$4&$5 last;
rewrite ^([^\.]*)/'.$group_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_group:wap&pagetype=$2&cid1=$3&$4 last;
rewrite ^([^\.]*)/'.$group_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_group:wap&pagetype=$2&$3 last;</font>
if (!-e $request_filename) {
	return 404;
}
</pre>
';

echo $strtmp;

if(count($reabc)!=10)return;
showtablefooter();

?>