<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_group_class', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_group#it618_group_class')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_seokeywords' => trim($_GET['it618_seokeywords'][$id]),
				'it618_seodescription' => trim($_GET['it618_seodescription'][$id]),
				'it618_about' => trim($_GET['it618_about'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_seokeywords_array = !empty($_GET['newit618_seokeywords']) ? $_GET['newit618_seokeywords'] : array();
	$newit618_seodescription_array = !empty($_GET['newit618_seodescription']) ? $_GET['newit618_seodescription'] : array();
	$newit618_about_array = !empty($_GET['newit618_about']) ? $_GET['newit618_about'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		$newit618_name = addslashes(trim($newit618_name_array[$key]));
		
		if($newit618_name != '') {
			
			C::t('#it618_group#it618_group_class')->insert(array(
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_seokeywords' => trim($newit618_seokeywords_array[$key]),
				'it618_seodescription' => trim($newit618_seodescription_array[$key]),
				'it618_about' => trim($newit618_about_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_group_lang['s33'].$ok1.' '.$it618_group_lang['s34'].$ok2.' '.$it618_group_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_class&pmod=admin_class&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=11)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_class&pmod=admin_class&operation=$operation&do=$do");
showtableheaders($it618_group_lang['s26'],'it618_group_class');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_group_class'));
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_class&pmod=admin_class&operation=$operation&do=$do");
	
	echo '<tr><td colspan=10>'.$it618_group_lang['s27'].$count.'<span style="float:right">'.$it618_group_lang['s24'].'</span></td></tr>';
	showsubtitle(array('', $it618_group_lang['s28'], $it618_group_lang['s29'],$it618_group_lang['s25'],$it618_group_lang['s30'],$it618_group_lang['s31']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_class')." ORDER BY it618_order LIMIT $startlimit, $ppp");
	while($it618_group =	DB::fetch($query)) {
		//$goodscount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_group_shop')." WHERE it618_area1_id=".$it618_group['id']);
		$disabled="";
		if($goodscount>0)$disabled="disabled=\"disabled\"";
		
		$tmpid=$it618_group['id'];
		
		showtablerow('', array('class="td25"', '', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$tmpid\" $disabled><input type=\"hidden\" name=\"id[$tmpid]\" value=\"$tmpid\">",
			"<input type=\"text\" class=\"txt\" style=\"width:130px\" name=\"it618_name[$tmpid]\" value=\"".$it618_group['it618_name']."\">",
			'<textarea name="it618_seokeywords['.$it618_group['id'].']" style="width:300px;height:50px">'.$it618_group['it618_seokeywords'].'</textarea><br>
			 <textarea name="it618_seodescription['.$it618_group['id'].']" style="width:300px;height:60px;margin-top:3px">'.$it618_group['it618_seodescription'].'</textarea>',
			'<textarea name="it618_about['.$it618_group['id'].']" style="width:300px;height:120px">'.$it618_group['it618_about'].'</textarea>',
			'<input class="txt" type="text" name="it618_order['.$it618_group['id'].']" value="'.$it618_group['it618_order'].'">',
			$goodscount
		));
		$tmpcolorjs.="updatecolorpreview('c".$it618_group['id']."');";
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_name[]").length;
	
		return [
		[[1,''], [1,'<input type="text" class="txt" style=\"width:130px\" name="newit618_name[]">'], [1,'<textarea style=\"width:300px;height:50px\" name="newit618_seokeywords[]"></textarea><br><textarea style=\"width:300px;height:60px;margin-top:3px\" name="newit618_seodescription[]"></textarea>'], [1,'<textarea style=\"width:300px;height:120px\" name="newit618_about[]"></textarea>'], [1, ' <input class="txt" type="text" name="newit618_order[]">'], [1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />", $multipage);
	if(count($reabc)!=11)return;
showtablefooter();
?>