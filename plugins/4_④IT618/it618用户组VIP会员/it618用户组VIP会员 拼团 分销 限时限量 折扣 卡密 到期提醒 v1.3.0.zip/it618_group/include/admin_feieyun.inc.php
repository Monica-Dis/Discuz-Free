<?php
 /**
 *	�����Ŷӣ�DisM.Taobao.Com
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_group/config/feieyun.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/config/feieyun.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_group/config/feieyun.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$feieyun_isok=\''.trim($_GET['feieyun_isok'])."';\n";
		$fileData .= '$feieyun_user=\''.trim($_GET['feieyun_user'])."';\n";
		$fileData .= '$feieyun_ukey=\''.trim($_GET['feieyun_ukey'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_group_lang['s462'], "action=plugins&identifier=$identifier&cp=admin_feieyun&pmod=admin_feieyun&operation=$operation&do=$do&page=$page", 'succeed');
}


showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_feieyun&pmod=admin_feieyun&operation=$operation&do=$do");

if($feieyun_isok==1)$check_feieyun_isok='checked="checked"';else $check_feieyun_isok='';

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_group_lang['s451'].'</th></tr>
<tr class="header"><th width=180>'.$it618_group_lang['s452'].'</th><th>'.$it618_group_lang['s453'].'</th><th>'.$it618_group_lang['s454'].'</th></tr>

<tr class="hover">
<td>'.$it618_group_lang['s455'].'</td><td class="longtxt"><input type="checkbox" id="feieyun_isok" name="feieyun_isok" value="1" style="vertical-align:middle" '.$check_feieyun_isok.'> <label for="feieyun_isok">'.$it618_group_lang['s456'].'</label></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_group_lang['s457'].'</td><td class="longtxt"><input name="feieyun_user" value="'.$feieyun_user.'" style="width:380px" /></td>
<td>'.$it618_group_lang['s459'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_group_lang['s458'].'</td><td class="longtxt"><input name="feieyun_ukey" value="'.$feieyun_ukey.'" style="width:380px" /></td>
<td>'.$it618_group_lang['s460'].'</td>
</tr>

</table>
';

showsubmit('it618submit', $it618_group_lang['s461']);

if(count($reabc)!=10)return;
showtablefooter();

?>