<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_group#it618_group_wapstyle')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_color1'])) {
		foreach($_GET['it618_color1'] as $id => $val) {
			
			if($_GET['it618_isok']==$id)$it618_isok=1;else $it618_isok=0;
			
			C::t('#it618_group#it618_group_wapstyle')->update($id,array(
				'it618_color1' => trim($_GET['it618_color1'][$id]),
				'it618_color2' => trim($_GET['it618_color2'][$id]),
				'it618_isok' => $it618_isok,
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_color1_array = !empty($_GET['newit618_color1']) ? $_GET['newit618_color1'] : array();
	$newit618_color2_array = !empty($_GET['newit618_color2']) ? $_GET['newit618_color2'] : array();
	
	foreach($newit618_color1_array as $key => $value) {
		$newit618_color1 = trim($newit618_color1_array[$key]);
		
		if($newit618_color1 != '') {
			
			C::t('#it618_group#it618_group_wapstyle')->insert(array(
				'it618_color1' => trim($newit618_color1_array[$key]),
				'it618_color2' => trim($newit618_color2_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}
	
	cpmsg($it618_group_lang['s33'].$ok1.' '.$it618_group_lang['s34'].$ok2.' '.$it618_group_lang['s35'].$del.')',"action=plugins&identifier=$identifier&cp=admin_wapstyle&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=11)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_wapstyle&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($it618_group_lang['s962'],'it618_group_wapstyle');
	$count = C::t('#it618_group#it618_group_wapstyle')->count_by_search();
	
	echo '<tr><td colspan=4>'.$it618_group_lang['s657'].$count.'</td></tr>';
	showsubtitle(array('', $it618_group_lang['s973'], $it618_group_lang['s974'],$it618_group_lang['s975']));
	
	foreach(C::t('#it618_group#it618_group_wapstyle')->fetch_all_by_search() as $it618_group_wapstyle) {
		
		if($it618_group_wapstyle['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
		
		$tmpid=$it618_group_wapstyle['id'];
		
		showtablerow('', array('class="td25"', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$tmpid\" $disabled><input type=\"hidden\" name=\"id[$tmpid]\" value=\"$tmpid\">",
			"<input id=\"c1".$it618_group_wapstyle['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"it618_color1[$tmpid]\" value=\"".$it618_group_wapstyle['it618_color1']."\" onchange=\"updatecolorpreview('c1".$it618_group_wapstyle['id']."')\"><input id=\"c1".$it618_group_wapstyle['id']."\" onclick=\"c1".$it618_group_wapstyle['id']."_frame.location='static/image/admincp/getcolor.htm?c1".$it618_group_wapstyle['id']."|c1".$it618_group_wapstyle['id']."_v';showMenu({'ctrlid':'c1".$it618_group_wapstyle['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c1".$it618_group_wapstyle['id']."_menu\" style=\"display: none\"><iframe name=\"c1".$it618_group_wapstyle['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			"<input id=\"c2".$it618_group_wapstyle['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"it618_color2[$tmpid]\" value=\"".$it618_group_wapstyle['it618_color2']."\" onchange=\"updatecolorpreview('c2".$it618_group_wapstyle['id']."')\"><input id=\"c2".$it618_group_wapstyle['id']."\" onclick=\"c2".$it618_group_wapstyle['id']."_frame.location='static/image/admincp/getcolor.htm?c2".$it618_group_wapstyle['id']."|c2".$it618_group_wapstyle['id']."_v';showMenu({'ctrlid':'c2".$it618_group_wapstyle['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c2".$it618_group_wapstyle['id']."_menu\" style=\"display: none\"><iframe name=\"c2".$it618_group_wapstyle['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			'<input class="radio" type="radio" name="it618_isok" '.$it618_isok_checked.' value="'.$it618_group_wapstyle['id'].'">'
		));
		$tmpcolorjs.="updatecolorpreview('c1".$it618_group_wapstyle['id']."');";
		$tmpcolorjs.="updatecolorpreview('c2".$it618_group_wapstyle['id']."');";
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_color1[]").length;
	
		return [
		[[1,''], [1,'<input id="c1_add'+n+'_v" type="text" class="txt" style=\"width:80px;float:left\" name="newit618_color1[]" onchange="updatecolorpreview(\'c1_add'+n+'\')"><input id="c1_add'+n+'" onclick="c1_add'+n+'_frame.location=\'static/image/admincp/getcolor.htm?c1_add'+n+'|c1_add'+n+'_v\';showMenu({\'ctrlid\':\'c1_add'+n+'\'})" type="button" class="colorwd" value="" style="background: "><span id="c1_add'+n+'_menu" style="display: none"><iframe name="c1_add'+n+'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>'], [1,'<input id="c2_add'+n+'_v" type="text" class="txt" style=\"width:80px;float:left\" name="newit618_color2[]" onchange="updatecolorpreview(\'c2_add'+n+'\')"><input id="c2_add'+n+'" onclick="c2_add'+n+'_frame.location=\'static/image/admincp/getcolor.htm?c2_add'+n+'|c2_add'+n+'_v\';showMenu({\'ctrlid\':\'c2_add'+n+'\'})" type="button" class="colorwd" value="" style="background: "><span id="c2_add'+n+'_menu" style="display: none"><iframe name="c2_add'+n+'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>'], [1, ''], [1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	</script>
EOT;
	echo '<tr><td></td><td colspan="3"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=11)return;
showtablefooter();
?>