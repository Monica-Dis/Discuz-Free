<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618_group_set=C::t('#it618_group#it618_group_set')->fetch_by_setname($setname);

if(submitcheck('it618submit')){
	if(C::t('#it618_group#it618_group_set')->count_by_setname($setname)==0){
		C::t('#it618_group#it618_group_set')->insert(array(
			'setname' => $setname,
			'setvalue' => $_GET[$setname]
		), true);
	}else{
		C::t('#it618_group#it618_group_set')->update($it618_group_set['id'],array(
			'setvalue' => $_GET[$setname]
		));
	}
	

	cpmsg($it618_group_lang['s315'], "action=plugins&identifier=$identifier&cp=admin_set&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_set&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($strtmptitle[$cp1].'<span style="font-weight:normal;color:red;margin-left:90px">'.$it618_group_lang['s314'].'</span>','it618_group_set');

if($cp1==7){
	$tmpstr='<br><font color=blue>'.$it618_group_lang['s316']."</font>";
}

echo '
<link rel="stylesheet" href="source/plugin/it618_group/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_group/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_group/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_group/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_group/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="'.$setname.'"]\', {
			cssPath : \'source/plugin/it618_group/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_group/kindeditor/php/upload_json.php?imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_group/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
				
		prettyPrint();
	});
</script>

<tr><td width=800><textarea name="'.$setname.'" style="width:800px;height:400px;visibility:hidden;">'.$it618_group_set['setvalue'].'</textarea>'.$tmpstr.'</td></tr>
';

showsubmit('it618submit', $it618_group_lang['s10']);
if(count($reabc)!=11)return;
showtablefooter();

?>