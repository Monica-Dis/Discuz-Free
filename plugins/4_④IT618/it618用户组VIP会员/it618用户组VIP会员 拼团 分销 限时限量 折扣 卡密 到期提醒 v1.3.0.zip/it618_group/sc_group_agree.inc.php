<?php
 /**
 *	�����Ŷӣ�DisM.Taobao.Com
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';

$gid=intval($_GET['gid']);

$it618_group_group = C::t('#it618_group#it618_group_group')->fetch_by_id($gid);
$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_group['it618_groupid']);

if(submitcheck('it618submit')){
	
	C::t('#it618_group#it618_group_group')->update($gid,array(
		'it618_agreetime' => $_GET['it618_agreetime'],
		'it618_agreeabout' => $_GET['it618_agreeabout']
	));

	echo '<script>parent.location.reload();parent.layer.closeAll();</script>';
}

it618_showformheader("plugin.php?id=it618_group:sc_group_agree&gid=$gid");
showtableheaders($grouptitle,'sc_group_powers');

echo '
<link rel="stylesheet" href="source/plugin/it618_group/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_group/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_group/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_group/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_group/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_agreeabout"]\', {
			cssPath : \'source/plugin/it618_group/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_group/kindeditor/php/upload_json.php?&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_group/kindeditor/php/file_manager_json.php?\',
			allowFileManager : true,
			filterMode:false
		});
	});
</script>

<tr><td>'.$it618_group_lang['s319'].'<input type="text" name="it618_agreetime" style="width:50px" value="'.$it618_group_group['it618_agreetime'].'"> '.$it618_group_lang['s321'].'</td></tr>
<tr><td><textarea name="it618_agreeabout" style="width:800px;height:430px;line-height:18px;visibility:hidden;">'.$it618_group_group['it618_agreeabout'].'</textarea></td></tr>
<tr><td style="color:red">'.$it618_group_lang['s363'].'</td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_group_getlang('s10').'" /></div></td></tr>';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>