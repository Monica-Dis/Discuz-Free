<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_group_nav`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_focus`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_type` int(10) unsigned NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_bottomnav`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_curimg` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_set`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_wapstyle`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_class`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(300) NOT NULL,
  `it618_seokeywords` varchar(1000) NOT NULL,
  `it618_seodescription` varchar(1000) NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_group`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_classid` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_ico` varchar(255) NOT NULL,
  `it618_power` varchar(1000) NOT NULL,
  `it618_xgzk` float(9,2) NOT NULL DEFAULT '0',
  `it618_video_pids` varchar(1000) NOT NULL,
  `it618_pbuids` varchar(1000) NOT NULL,
  `it618_switch` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_txtime1` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_txtime2` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_isagree` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_agreetime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_agreeabout` mediumtext NOT NULL,
  `it618_ispublic` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_group_zk`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_group_zk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_zk` float(9,2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_group_salepower`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_group_salepower` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_rzmoney`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_rzmoney` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_lid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isautocheck` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istbtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_user`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_tel` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_group_user`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_group_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_txtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_txstate` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_chkstate` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_bz` varchar(1000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_group_zuser`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_group_zuser` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_goods`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_unitcount` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_unit` int(10) unsigned NOT NULL,
  `it618_picbig` varchar(255) NOT NULL,
  `it618_seokeywords` varchar(1000) NOT NULL,
  `it618_seodescription` varchar(1000) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_price` float(9,2) NOT NULL,
  `it618_saleprice` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jfbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_counttype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_xgcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgtype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgtime1` varchar(20) NOT NULL,
  `it618_xgtime2` varchar(20) NOT NULL,
  `it618_saleabout` varchar(20) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salemoney` float(9,2) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isuser` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_issd` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_isbm` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_goods_km`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_goods_km` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_code` varchar(32) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_usedel` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_xgtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_unitcount` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_unit` int(10) unsigned NOT NULL,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_price` float(9,2) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL,
  `it618_xgzk` float(9,2) NOT NULL DEFAULT '0',
  `it618_vipzk` float(9,2) NOT NULL DEFAULT '0',
  `it618_quanmoney` float(9,2) NOT NULL,
  `it618_sfmoney` float(9,2) NOT NULL,
  `it618_jfbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tel` varchar(20) NOT NULL,
  `it618_isswitch` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(20) NOT NULL,
  `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuitcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tuitc` float(9,2) NOT NULL DEFAULT '0',
  `it618_pinsaleid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_salejl`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_salejl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_days` int(10) unsigned NOT NULL,
  `it618_saletype` varchar(30) NOT NULL,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_salekm`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_salekm` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_code` varchar(32) NOT NULL,
  `it618_bz` varchar(32) NOT NULL,
  `it618_xgtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_unitcount` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_unit` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_ad`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_ad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_content` mediumtext NOT NULL,
  `it618_height` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_width` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_cookiestime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_btn1title` varchar(30) NOT NULL,
  `it618_btn2title` varchar(30) NOT NULL,
  `it618_btn1url` varchar(255) NOT NULL,
  `it618_urlarea` varchar(1000) NOT NULL,
  `it618_uids` varchar(1000) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_adarea`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_adarea` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_aid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_plugin` varchar(30) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_adshop`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_adshop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_aid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_plugin` varchar(30) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_adgroup`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_adgroup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_aid` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_print`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_print` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_sn` varchar(50) NOT NULL,
  `it618_key` varchar(50) NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_phonenum` varchar(50) NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_printshop`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_printshop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_prid` int(10) unsigned NOT NULL,
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_printsale`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_printsale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_prid` int(10) unsigned NOT NULL,
  `it618_shoptype` varchar(50) NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saleid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_printsaleid` varchar(50) NOT NULL,
  `it618_msg` varchar(255) NOT NULL,
  `it618_content` mediumtext NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_group_salework`;
CREATE TABLE IF NOT EXISTS `pre_it618_group_salework` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

EOF;

runquery($sql);


//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL2Rpc2N1el9wbHVnaW5faXQ2MThfZ3JvdXAueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL2Rpc2N1el9wbHVnaW5faXQ2MThfZ3JvdXBfU0NfR0JLLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL2Rpc2N1el9wbHVnaW5faXQ2MThfZ3JvdXBfU0NfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL2Rpc2N1el9wbHVnaW5faXQ2MThfZ3JvdXBfVENfQklHNS54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL2Rpc2N1el9wbHVnaW5faXQ2MThfZ3JvdXBfVENfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL2xhbmd1YWdlLlRDX0JJRzUucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL2xhbmd1YWdlLlRDX1VURjgucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL3VwZ3JhZGUucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X2dyb3VwL2luc3RhbGwucGhw'));
?>