<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tmpidarr=explode(":",$_GET['id']);
$tempabc=$tmpidarr[0];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';

if($IsPinEdu==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/function.func.php';
}

$urlsql='&it618_classid='.$_GET['it618_classid'].'&it618_groupid='.$_GET['it618_groupid'];

if(submitcheck('it618submit_del')){
	$del=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$salecount = C::t('#it618_group#it618_group_sale')->sumcount_by_it618_pid($delid);
		
		$delflag=0;
		if($salecount<=0){
			if($IsPinEdu==1){
				if($it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_by_shoptype_typeid('group',$delid)){
					$delflag=1;
				}
			}
			
			if($delflag==0){
				C::t('#it618_group#it618_group_goods')->delete_by_id($delid);
				$del=$del+1;
			}
		}else{
			$flag=1;
		}
	}
	
	if($flag==1)$tmpstr='<br><br>'.$it618_group_lang['s102'];

	it618_cpmsg(it618_group_getlang('s98').$del.$tmpstr,  "plugin.php?id=it618_group:sc_product&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_on')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($delid);
		if($it618_group_goods['it618_state']==0){
			DB::query("update ".DB::table('it618_group_goods')." set it618_state=1 where id=".$delid);
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_group_getlang('s100').$ok,  "plugin.php?id=it618_group:sc_product&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_down')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($delid);
		if($it618_group_goods['it618_state']==1){
			DB::query("update ".DB::table('it618_group_goods')." set it618_state=0 where id=".$delid);
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_group_getlang('s101').$ok,  "plugin.php?id=it618_group:sc_product&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_edit')){
	$ok=0;
	if(is_array($_GET['goods'])) {
		foreach($_GET['goods'] as $id => $val) {
			
			if($_GET['it618_jfid'][$id]==0)$_GET['it618_score'][$id]=0;
			if($_GET['it618_saleprice'][$id]==0&&$_GET['it618_score'][$id]==0){
				$_GET['it618_saleprice'][$id]=0.01;
			}
			
			C::t('#it618_group#it618_group_goods')->update($id,array(
				'it618_count' => $_GET['it618_count'][$id],
				'it618_jfid' => $_GET['it618_jfid'][$id],
				'it618_score' => $_GET['it618_score'][$id],
				'it618_saleprice' => $_GET['it618_saleprice'][$id],
				'it618_price' => $_GET['it618_price'][$id],
				'it618_jfbl' => $_GET['it618_jfbl'][$id],
				'it618_counttype' => $_GET['it618_counttype'][$id],
				'it618_xgcount' => $_GET['it618_xgcount'][$id],
				'it618_xgtype' => $_GET['it618_xgtype'][$id],
				'it618_xgtime1' => dhtmlspecialchars($_GET['it618_xgtime1'][$id]),
				'it618_xgtime2' => dhtmlspecialchars($_GET['it618_xgtime2'][$id]),
				'it618_saleabout' => dhtmlspecialchars($_GET['it618_saleabout'][$id]),
				'it618_istj' => $_GET['it618_istj'][$id],
				'it618_isuser' => $_GET['it618_isuser'][$id],
				'it618_issd' => $_GET['it618_issd'][$id],
				'it618_isbm' => $_GET['it618_isbm'][$id],
				'it618_order' => $_GET['it618_order'][$id]
			));
	
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_group_getlang('s99').$ok,  "plugin.php?id=it618_group:sc_product&page=$page".$urlsql, 'succeed');
}

$tmp='<option value="0">'.it618_group_getlang('s55').'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_group_class')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_classid'].'>','<option value='.$_GET['it618_classid'].' selected="selected">',$tmp);

if($_GET['it618_classid']>0){
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_group')." where it618_classid=".$_GET['it618_classid']." ORDER BY it618_order");
	$indextmp=1;
	$index=0;
	while($it618_tmp = DB::fetch($query)) {
		if($it618_tmp['it618_groupid']==$_GET['it618_groupid']){
			$index=$indextmp;
		}
		$indextmp+=1;
	}
	$jstmp.="redirec_class(document.getElementById('it618_classid').options.selectedIndex);redirec_class_sel('it618_groupid',".$index.");";
}

it618_showformheader("plugin.php?id=it618_group:sc_product&page=$page".$urlsql);
showtableheaders($it618_group_lang['s17'],'it618_group_sum');
	echo '<tr><td colspan=14>'.it618_group_getlang('s68').' <select id="it618_classid" name="it618_classid" onchange="redirec_class(this.options.selectedIndex)">'.$tmp1.'</select> <select id="it618_groupid"  name="it618_groupid"><option value="0">'.it618_group_getlang('s56').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_group_getlang('s70').'" /></td></tr>';
	
	$count = C::t('#it618_group#it618_group_goods')->count_by_search($it618sql,'',$_GET['it618_classid'],$_GET['it618_groupid']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_group:sc_product".$urlsql);
	
	echo '<tr><td colspan=14>'.it618_group_getlang('s71').$count.'<span style="float:right">'.it618_group_getlang('s78').'</span></td></tr>';
	showsubtitle(array('',it618_group_getlang('s72'),it618_group_getlang('s73'),it618_group_getlang('s74'),it618_group_getlang('s75'),$it618_group_lang['s113'],$it618_group_lang['s213'],$it618_group_lang['s210'],$it618_group_lang['s184'],$it618_group_lang['s76'],it618_group_getlang('s77')));
	
	$n=1;
	foreach(C::t('#it618_group#it618_group_goods')->fetch_all_by_search(
		$it618sql,'p.it618_order,p.id desc',$_GET['it618_classid'],$_GET['it618_groupid'],$startlimit,$ppp
	) as $it618_group_goods) {

		if($it618_group_goods['it618_state']==0)$it618_state='<font color=blue>'.it618_group_getlang('s103').'</font>';
		if($it618_group_goods['it618_state']==1)$it618_state='<font color=green>'.it618_group_getlang('s104').'</font>';
		
		if($it618_group_goods['it618_xgtype']==0)$it618_xgtype0=' selected="selected"';else $it618_xgtype0="";
		if($it618_group_goods['it618_xgtype']==1)$it618_xgtype1=' selected="selected"';else $it618_xgtype1="";
		if($it618_group_goods['it618_xgtype']==2)$it618_xgtype2=' selected="selected"';else $it618_xgtype2="";
		
		$salecount = $it618_group_goods['it618_salecount'];
		$salemoney = $it618_group_goods['it618_salemoney'];
		
		$preurl="action=plugin.php?id=it618_group:sc_product&page=$page".$urlsql;
		$preurl=str_replace("&","@",$preurl);
		
		$tmpurl=it618_group_getrewrite('group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id']);
		
		$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
		$classname = C::t('#it618_group#it618_group_class')->fetch_it618_name_by_id($it618_group_group['it618_classid']);
		if(DB::result_first("select count(1) from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid'])>0){
			$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
		}else{
			DB::query("delete FROM ".DB::table('it618_group_group')." where id=".$it618_group_group['id']);
		}
		
		$it618_unit=it618_group_getgoodsunit($it618_group_goods);
		
		if($it618_group_goods['it618_state']==0)$it618_state='<font color=#999>'.$it618_group_lang['s87'].'</font>';
		if($it618_group_goods['it618_state']==1)$it618_state='<font color=green>'.$it618_group_lang['s88'].'</font>';
		
		if($it618_group_goods['it618_istj']==1)$it618_istj_checked='checked="checked"';else $it618_istj_checked="";
		if($it618_group_goods['it618_isuser']==1)$it618_isuser_checked='checked="checked"';else $it618_isuser_checked="";
		if($it618_group_goods['it618_issd']==1)$it618_issd_checked='checked="checked"';else $it618_issd_checked="";
		if($it618_group_goods['it618_isbm']==1)$it618_isbm_checked='checked="checked"';else $it618_isbm_checked="";
		
		if($it618_group_goods['it618_counttype']==1){
			$spancountcss='style="display:"';
			$it618_counttype1=' selected="selected"';
			$it618_counttype2='';
		}else{
			$spancountcss='style="display:none"';
			$it618_counttype1='';
			$it618_counttype2=' selected="selected"';
		}
		
		if($IsPinEdu==1){
			$goodspin=it618_pinedu_getgoodspinstate('group',$it618_group_goods['id']);
			$goodspinstr=' <a href="javascript:" onclick="showgoodspin('.$goodspin['id'].','.$it618_group_goods['id'].')"><font color=blue>'.$goodspin['name'].'</font>'.$goodspin['count'].'</a>';
		}
		
		$kmcount = C::t('#it618_group#it618_group_goods_km')->count_by_search('','',$it618_group_goods['id']);
		$kmusecount = C::t('#it618_group#it618_group_salekm')->count_by_search('','',$it618_group_goods['id']);

		showtablerow('', array('', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_group_goods['id'].'"><label for="chk_del'.$n.'">'.$it618_group_goods['id'].'</label><input type="hidden" name="goods['.$it618_group_goods['id'].']">',
			'<a style="float:left" href="'.$tmpurl.'" target="_blank"><img src="'.it618_group_getwapppic($it618_group_goods['id'],$it618_group_goods['it618_picbig']).'" width="111" height="68" align="absmiddle"/></a><div style="float:left;margin-left:6px;line-height:23px"><img src="'.$it618_group_group['it618_ico'].'" width="18" height="18" align="absmiddle" style="margin-top:-3px"/> '.$grouptitle.' '.$it618_unit.' <a href="javascript:" onclick="showedit('.$it618_group_goods['id'].')">'.it618_group_getlang('s89').'</a><br><input type="text" class="txt" style="width:68px;margin-right:3px;margin-top:3px" name="it618_saleabout['.$it618_group_goods['id'].']" value="'.$it618_group_goods['it618_saleabout'].'"><br><font color=#999>'.$classname.'</font> <a href="javascript:" onclick="showkm('.$it618_group_goods['id'].')">'.$it618_group_lang['s281'].'(<font color=red>'.$kmcount.'</font>)</a> <a href="javascript:" onclick="showkmuse('.$it618_group_goods['id'].')">'.$it618_group_lang['s282'].'(<font color=red>'.$kmusecount.'</font>)</a>
			</div>',
			'<div style="line-height:23px">
			<input type="text" class="txt" style="width:68px;margin-right:3px;color:red" name="it618_saleprice['.$it618_group_goods['id'].']" value="'.$it618_group_goods['it618_saleprice'].'">'.it618_group_getlang('s58').'+<input type="text" class="txt" style="width:80px;margin-right:3px;;color:red" name="it618_score['.$it618_group_goods['id'].']" value="'.$it618_group_goods['it618_score'].'"><select name="it618_jfid['.$it618_group_goods['id'].']">'.it618_group_getjftype($it618_group_goods['it618_jfid']).'</select><br>
			<input type="text" class="txt" style="width:68px;margin-right:3px" name="it618_price['.$it618_group_goods['id'].']" value="'.$it618_group_goods['it618_price'].'">'.it618_group_getlang('s58').'
			<select style="margin-left:6px;margin-right:3px" name="it618_counttype['.$it618_group_goods['id'].']" onchange="getcountype(this.value,'.$it618_group_goods['id'].')"><option value="1" '.$it618_counttype1.'>'.$it618_group_lang['s418'].'</option><option value="2" '.$it618_counttype2.'>'.$it618_group_lang['s419'].'</option></select><span id="spancount'.$it618_group_goods['id'].'" '.$spancountcss.'><input type="text" class="txt" style="width:25px;margin-right:3px;color:green;" name="it618_xgcount['.$it618_group_goods['id'].']" value="'.$it618_group_goods['it618_xgcount'].'"><input type="text" class="txt" style="width:46px;margin-right:1px;color:green;" name="it618_count['.$it618_group_goods['id'].']" value="'.$it618_group_goods['it618_count'].'"></span><br>'.$goodspinstr.'</div>',
			'<select id="it618_xgtype'.$n.'" name="it618_xgtype['.$it618_group_goods['id'].']" style="margin-top:3px"><option value="0"'.$it618_xgtype0.'>'.it618_group_getlang('s81').'</option><option value="1"'.$it618_xgtype1.'>'.it618_group_getlang('s82').'</option><option value="2"'.$it618_xgtype2.'>'.it618_group_getlang('s83').'</option></select><br><input type="text" class="txt" style="width:115px;margin-top:3px" id="it618_xgtime1_'.$n.'" name="it618_xgtime1['.$it618_group_goods['id'].']" readonly="readonly" value="'.$it618_group_goods['it618_xgtime1'].'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')"><br><input type="text" class="txt" style="width:115px;margin-top:3px" id="it618_xgtime2_'.$n.'" name="it618_xgtime2['.$it618_group_goods['id'].']" readonly="readonly" value="'.$it618_group_goods['it618_xgtime2'].'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')">',
			'<input type="text" class="txt" style="width:50px;margin-right:1px;color:blue" name="it618_jfbl['.$it618_group_goods['id'].']" value="'.$it618_group_goods['it618_jfbl'].'">%<br><div style="line-height:16px;margin-top:3px">'.it618_group_getlang('s84').': '.$it618_group_goods['it618_views'].'<br>'.it618_group_getlang('s85').': '.$salecount.''.'<br>'.it618_group_getlang('s86').': '.$salemoney.'</div>',
			'<input class="checkbox" type="checkbox" name="it618_istj['.$it618_group_goods['id'].']" '.$it618_istj_checked.' value="1">',
			'<input class="checkbox" type="checkbox" name="it618_isuser['.$it618_group_goods['id'].']" '.$it618_isuser_checked.' value="1">',
			'<input class="checkbox" type="checkbox" name="it618_issd['.$it618_group_goods['id'].']" '.$it618_issd_checked.' value="1">',
			'<input class="checkbox" type="checkbox" name="it618_isbm['.$it618_group_goods['id'].']" '.$it618_isbm_checked.' value="1">',
			'<input type="text" class="txt" style="width:30px;" name="it618_order['.$it618_group_goods['id'].']" value="'.$it618_group_goods['it618_order'].'">',
			$it618_state
		));
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_group_getlang('s90').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.it618_group_getlang('s91').'" onclick="return confirm(\''.it618_group_getlang('s95').'\')" /> <input type="submit" class="btn" name="it618submit_edit" value="'.it618_group_getlang('s92').'"/> <input type="submit" class="btn" name="it618submit_on" value="'.it618_group_getlang('s93').'" onclick="return confirm(\''.it618_group_getlang('s96').'\')" /> <input type="submit" class="btn" name="it618submit_down" value="'.it618_group_getlang('s94').'" onclick="return confirm(\''.it618_group_getlang('s97').'\')" /><br>'.$it618_group_lang['s211'].'<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

showtablefooter();

$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_group_class'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_group_class')." ORDER BY it618_order");
$n1=1;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_group_group')." where it618_classid=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_tmp2['it618_groupid']);
		$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$grouptitle.'", "'.$it618_tmp2['it618_groupid'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}
echo '
	<script>
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x)
	{
	 var temp = document.getElementById("it618_groupid"); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	function redirec_class_sel(id,index)
	{
	 var temp = document.getElementById(id); 
	 temp.options[index].selected=true;
	
	}
	
	function getcountype(value,n){
		if(value==1){
			document.getElementById("spancount"+n).style.display="";
		}else{
			document.getElementById("spancount"+n).style.display="none";
		}
	}
	</script>';

if($IsPinEdu==1){
	echo '
	<script>
	function showgoodspin(pinid,typeid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_pinedu_lang['s5'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["930px", "430px"],
			content: "plugin.php?id=it618_pinedu:sc_product&shoptype=group&pinid="+pinid+"&typeid="+typeid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	</script>
	';
	}

echo '
<script>
		function showedit(pid){
			layerindex=layer.open({
				type: 2,
				title: "<div style=\'float:left;color:blue\'>'.$it618_group_lang['s19'].'</div>",
				shadeClose: false,
				scrollbar: false,
				shade:  [0.5, "#393D49"],
				maxmin: false,
				area: ["100%", "100%"],
				content: "plugin.php?id=it618_group:sc_product_edit&pid="+pid,
				cancel: function(index, layero){ 
	
				}    
			});
		}
		
		function showkm(pid){
			layerindex=layer.open({
				type: 2,
				title: "<div style=\'float:left;color:blue\'>'.$it618_group_lang['s280'].'</div>",
				shadeClose: false,
				scrollbar: false,
				shade:  [0.5, "#393D49"],
				maxmin: false,
				area: ["100%", "100%"],
				content: "plugin.php?id=it618_group:sc_product_km&pid="+pid,
				cancel: function(index, layero){ 
	
				}    
			});
		}
		
		function showkmuse(pid){
			layerindex=layer.open({
				type: 2,
				title: "<div style=\'float:left;color:blue\'>'.$it618_group_lang['s283'].'</div>",
				shadeClose: false,
				scrollbar: false,
				shade:  [0.5, "#393D49"],
				maxmin: false,
				area: ["100%", "100%"],
				content: "plugin.php?id=it618_group:sc_salekm&pid="+pid,
				cancel: function(index, layero){ 
	
				}    
			});
		}
		
		</script>';
echo '<script charset="utf-8" src="source/plugin/it618_group/js/Calendar.js"></script>
	  <script type="text/javascript">
		function check_all(obj,id)
		{
			for(var i=1;i<'.$n.';i++)
			{
				document.getElementById(id+""+i).checked = obj.checked;
			}
		}
	  </script>';
	if(count($reabc)!=11)return;
    showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>