<?php
 /**
 *	�����Ŷӣ�DisM.Taobao.Com
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';

$vuid=intval($_GET['vuid']);

if($_GET['type']=='vip'){
	$it618_group_group_user = C::t('#it618_group#it618_group_group_user')->fetch_by_id($vuid);
	$grouptitle=' - '.DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_group_user['it618_groupid']);
	$type='vip';
}else{
	$it618_group_group_user = C::t('#it618_group#it618_group_group_zuser')->fetch_by_id($vuid);
	$type='zvip';
}

$username=it618_group_getusername($it618_group_group_user['it618_uid']).'('.$it618_group_group_user['it618_uid'].')';

if(submitcheck('it618submit')){

	if($type=='vip'){
		C::t('#it618_group#it618_group_group_user')->update($vuid,array(
			'it618_bz' => $_GET['it618_bz'],
			'it618_time' => $_G['timestamp']
		));
	}else{
		C::t('#it618_group#it618_group_group_zuser')->update($vuid,array(
			'it618_bz' => $_GET['it618_bz'],
			'it618_time' => $_G['timestamp']
		));
	}

	echo '<script>parent.location.reload();parent.layer.closeAll();</script>';
}

it618_showformheader("plugin.php?id=it618_group:sc_group_userbz&type=$type&vuid=$vuid");
showtableheaders($username.$grouptitle,'it618_group_group_user');

if($it618_group_group_user['it618_time']>0){
	$it618_time=$it618_group_lang['s477'].date('Y-m-d H:i:s', $it618_group_group_user['it618_time']);
}

echo '
<tr><td><textarea name="it618_bz" style="width:803px;height:320px;line-height:18px;font-size:13px">'.$it618_group_group_user['it618_bz'].'</textarea></td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_group_getlang('s10').'" /> <span style="color:#999">'.$it618_time.'</span></div></td></tr>';

showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>