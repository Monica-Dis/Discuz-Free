<?php
/**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsMembers,$IsCredits,$IsUnion,$IsPinEdu,$IsChat,$IsWxMini,$RegName,$group_templatename,$group_templatename_wap,$group_templatename_admin,$group_template_set;
$RegName=$_G['setting']['regname'];

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_group/config/templateset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_group/config/templateset.php';
}

if($group_template_set['pcname']=='')$template_pcname='default';else $template_pcname=$group_template_set['pcname'];
if($group_template_set['wapname']=='')$template_wapname='default_wap';else $template_wapname=$group_template_set['wapname'];
if($group_template_set['adminname']=='')$template_adminname='sc_proton';else $template_adminname=$group_template_set['adminname'];

$group_templatename=$template_pcname;
$group_templatename_wap=$template_wapname;
$group_templatename_admin=$template_adminname;

$it618_members = $_G['cache']['plugin']['it618_members'];
if($it618_members['members_isok']==1){
	$IsMembers=1;
}

$it618_credits = $_G['cache']['plugin']['it618_credits'];
if($it618_credits['seotitle']!=''&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/plugins/autoheight/it618.png')){
	$IsCredits=1;
}

$it618_union = $_G['cache']['plugin']['it618_union'];
if($it618_union['seotitle']!=''){
	if($it618_union['seotitle']!=''&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/kindeditor/plugins/code/it618.png')){
		$IsUnion=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/lang.func.php';
	}
}

$it618_pinedu = $_G['cache']['plugin']['it618_pinedu'];
if($it618_pinedu['pagecount']!=''){
	if($it618_pinedu['pagecount']!=''&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_pinedu/kindeditor/plugins/code/it618.png')){
		$IsPinEdu=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/lang.func.php';
	}
}

$it618_wxmini = $_G['cache']['plugin']['it618_wxmini'];
if($it618_wxmini['pagecount']!=''&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_wxmini/kindeditor/plugins/autoheight/it618.png')){
	$IsWxMini=1;
}

$langpluginname='it618_group';
if($_SERVER['HTTP_HOST']=='localhost'||strpos($_SERVER['HTTP_HOST'],'localhost'))$language = 'language.php';else$language = 'language.'.currentlang().'.php';
if(!file_exists(DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language))$language = 'language.php';
require_once DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language;$language_edit = 'language.'.currentlang().'_edit.php';
if(file_exists(DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language_edit)){
$lang_version=$it618_exam_lang['version'];	$lang_it618=$it618_exam_lang['it618'];	require_once DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language_edit;$it618_exam_lang['version']=$lang_version;$it618_exam_lang['it618']=$lang_it618;
}
?>