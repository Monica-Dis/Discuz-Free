<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_G['uid']<=0){
	dheader("location:".$_G['siteurl'].'member.php?mod=logging&action=login');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';

$navtitle = $it618_members_lang['t64'];

$menuusername=$_G['username'];
$u_avatarimg=it618_group_discuz_uc_avatar($_G['uid'],'middle').'&random='.rand();

$groupstr=it618_group_getucvip();

$groupclassurl=it618_group_getrewrite('group_class','','plugin.php?id=it618_group:class');

$_G['mobiletpl'][IN_MOBILE]='/';

include template('it618_group:uc');
?>