<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tmpidarr=explode(":",$_GET['id']);
$tempabc=$tmpidarr[0];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_header.func.php';

if(submitcheck('it618submit')){
	
	$count=C::t('#it618_group#it618_group_goods')->count_by_groupid_unitcount_unit($_GET['it618_groupid'],$_GET['it618_unitcount'],$_GET['it618_unit']);
	if($count>0){
		it618_cpmsg(it618_group_getlang('s47'), "plugin.php?id=it618_group:sc_product_add", 'error');
	}
	
	if($_GET['it618_jfid']==0)$_GET['it618_score']=0;
	if($_GET['it618_saleprice']==0&&$_GET['it618_score']==0){
		$_GET['it618_saleprice']=0.01;
	}
	if($_GET['it618_unit']==5)$_GET['it618_unitcount']=1;
	
	$pid=C::t('#it618_group#it618_group_goods')->insert(array(
		'it618_groupid' => $_GET['it618_groupid'],
		'it618_unitcount' => $_GET['it618_unitcount'],
		'it618_unit' => $_GET['it618_unit'],
		'it618_counttype' => 2,
		'it618_jfid' => $_GET['it618_jfid'],
		'it618_score' => $_GET['it618_score'],
		'it618_saleprice' => $_GET['it618_saleprice'],
		'it618_price' => $_GET['it618_price'],
		'it618_seokeywords' => dhtmlspecialchars($_GET['it618_seokeywords']),
		'it618_seodescription' => dhtmlspecialchars($_GET['it618_seodescription']),
		'it618_picbig' => dhtmlspecialchars($_GET['it618_picbig']),
		'it618_message' => $_GET['it618_message'],
		'it618_time' => $_G['timestamp']
	), true);
	
	for($i=0;$i<=0;$i++){
		if($i==0)$tmpi='';else $tmpi=$i;
		$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
		
		if($get_it618_picbig!=''){
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/smallimage/';
			if (!file_exists($smallpath)) {
				mkdir($smallpath);
			}

			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1));
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_group/kindeditor/data/smallimage/goods'.$id.'_'.md5($get_it618_picbig).'.'.$file_ext;
			it618_group_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,385,1);
		}

	}

	it618_cpmsg(it618_group_getlang('s20'), "plugin.php?id=it618_group:sc_product_add", 'succeed');
}

it618_showformheader("plugin.php?id=it618_group:sc_product_add");
showtableheaders($it618_group_lang['s18'],'it618_group_goods');

$query1 = DB::query("SELECT * FROM ".DB::table('it618_group_class')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmpclass.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}

$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_group_class'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_group_class')." ORDER BY it618_order");
$n1=1;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_group_group')." where it618_classid=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_tmp2['it618_groupid']);
		$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$grouptitle.'", "'.$it618_tmp2['it618_groupid'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}

for($i=1;$i<=10;$i++){
	$unitcounttmp.='<option value='.$i.'>'.$i.'</option>';
}

$unittmp.='
<option value=1>'.$it618_group_lang['s60'].'</option>
<option value=2>'.$it618_group_lang['s61'].'</option>
<option value=3>'.$it618_group_lang['s62'].'</option>
<option value=4 selected="selected">'.$it618_group_lang['s63'].'</option>
<option value=5>'.$it618_group_lang['s64'].'</option>
';
	
echo '
<link rel="stylesheet" href="source/plugin/it618_group/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_group/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_group/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_group/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_group/kindeditor/plugins/code/prettify.js"></script>
<script charset="utf-8" src="source/plugin/it618_group/js/Calendar.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_group/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_group/kindeditor/php/upload_json.php?imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_group/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false
		});
		
		K(\'#image1\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
	});
	
	function checkvalue(){
		if(document.getElementById("it618_groupid").value=="0"){
			alert("'.it618_group_getlang('s173').'");
			return false;
		}
		if(document.getElementById("it618_saleprice").value<=0&&document.getElementById("it618_score").value<=0){
			alert("'.it618_group_getlang('s174').'");
			return false;
		}
		if(document.getElementById("url1").value==""){
			alert("'.it618_group_getlang('s260').'");
			return false;
		}
	}
	
	function setunit(unit){
		if(unit==5){
			document.getElementById("it618_unitcount").style.display="none";
		}else{
			document.getElementById("it618_unitcount").style.display="";
		}
	}
	
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x,n)
	{
	 if(n==0)n="";
	 var temp = document.getElementById("it618_groupid"+n); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
</script>

<tr><td width=80>'.it618_group_getlang('s37').'</td><td>
<select name="it618_classid" onchange="redirec_class(this.options.selectedIndex,0)"><option value="0">'.it618_group_getlang('s66').'</option>'.$tmpclass.'</select>
<select id="it618_groupid"  name="it618_groupid"><option value="0">'.it618_group_getlang('s67').'</option></select> '.$it618_group_lang['s57'].'
</td></tr>
<tr><td>'.it618_group_getlang('s38').'</td><td><select id="it618_unitcount" name="it618_unitcount">'.$unitcounttmp.'</select> <select name="it618_unit" onchange="setunit(this.value)">'.$unittmp.'</select> '.$it618_group_lang['s65'].'</td></tr>
<tr><td>'.it618_group_getlang('s421').'</td><td>'.it618_group_getlang('s422').'</td></tr>
<tr><td>'.it618_group_getlang('s43').'</td><td><input type="text" class="txt" style="width:80px;color:red;margin-right:3px" id="it618_saleprice" name="it618_saleprice">'.it618_group_getlang('s58').' + <input type="text" class="txt" style="width:80px;color:red;margin-right:3px" id="it618_score" name="it618_score"><select id="it618_jfid" name="it618_jfid">'.it618_group_getjftype().'</select> <font color=blue>'.$it618_group_lang['s44'].'</font></td></tr>
<tr><td>'.it618_group_getlang('s45').'</td><td><input type="text" class="txt" style="width:80px;margin-right:3px" id="it618_price" name="it618_price">'.it618_group_getlang('s58').' <font color=#666>'.$it618_group_lang['s46'].'</font></td></tr>
<tr><td>'.it618_group_getlang('s258').'</td><td><img id="img1" width="100" height="60" align="absmiddle"/> <input type="text" id="url1" name="it618_picbig" readonly="readonly"/> <input type="button" id="image1" value="'.it618_group_getlang('s259').'" /></td></tr>
<tr><td>'.it618_group_getlang('s48').'</td><td><textarea name="it618_message" style="width:780px;height:400px;visibility:hidden;"></textarea></td></tr>
<tr><td>'.it618_group_getlang('s49').'</td><td><input type="text" class="txt" style="width:776px;margin-right:0" name="it618_seokeywords"></td></tr>
<tr><td>'.it618_group_getlang('s50').'</td><td><textarea name="it618_seodescription" style="width:776px;height:60px;"></textarea></td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_group_getlang('s59').'" /></div></td></tr>';
	if(count($reabc)!=11)return;
    showtablefooter();
require_once DISCUZ_ROOT.'./source/plugin/it618_group/sc_footer.func.php';
?>