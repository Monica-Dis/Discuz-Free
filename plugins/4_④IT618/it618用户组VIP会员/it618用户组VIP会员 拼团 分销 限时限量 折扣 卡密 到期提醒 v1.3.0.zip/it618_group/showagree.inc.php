<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_group = $_G['cache']['plugin']['it618_group'];
require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';

$gid=intval($_GET['gid']);

$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_id($gid);
$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_group['it618_groupid']);

$wap=$_GET['wap'];

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_group:showagree');
?>