<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if($reabc[4]!='8')return;

loadcache('plugin');
$it618_group = $_G['cache']['plugin']['it618_group'];

require_once DISCUZ_ROOT.'./source/plugin/it618_group/function/it618_group.func.php';

if($reabc[9]!='u')return;
$ppp = $it618_group['pagecount'];
$page = max(1, intval($_GET['page']));
if($_GET['findbtn']==1)$page=1;
$startlimit = ($page - 1) * $ppp;
$deletes = '';
$extrasql = '';



$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_set&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

if(isset($_GET['cp1'])){
	$cp1=$_GET['cp1'];
}else{
	$cp1=0;
}
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<=7;$i++){
	if($i==$cp1){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

$strtmptitle[0]=$it618_group_lang['s1'];
$strtmptitle[1]=$it618_group_lang['s2'];
$strtmptitle[2]=$it618_group_lang['s3'];
$strtmptitle[3]=$it618_group_lang['s4'];
$strtmptitle[4]=$it618_group_lang['s1878'];
$strtmptitle[5]=$it618_group_lang['s103'];
$strtmptitle[6]=$it618_group_lang['s261'];

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_nav&cp1=0'.$urls.'"><span>'.$strtmptitle[0].'</span></a></li>
<li '.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_bottomnav&cp1=1'.$urls.'"><span>'.$strtmptitle[1].'</span></a></li>
<li '.$strtmp[5].'><a href="'.$hosturl.'plugins&cp=admin_template&cp1=5'.$urls.'"><span>'.$strtmptitle[5].'</span></a></li>
<li '.$strtmp[2].'><a href="'.$hosturl.'plugins&cp=admin_wapstyle&cp1=2'.$urls.'"><span>'.$strtmptitle[2].'</span></a></li>
<li '.$strtmp[3].'><a href="'.$hosturl.'plugins&cp=admin_rewrite&cp1=3'.$urls.'"><span>'.$strtmptitle[3].'</span></a></li>
<li '.$strtmp[6].'><a href="'.$hosturl.'plugins&cp=admin_message&cp1=6'.$urls.'"><span>'.$strtmptitle[6].'</span></a></li>
<li '.$strtmp[4].'><a href="'.$hosturl.'plugins&cp=admin_aliyunoss&cp1=4'.$urls.'"><span>'.$strtmptitle[4].'</span></a></li>
</ul></div>';

$cparray = array('admin_nav', 'admin_bottomnav', 'admin_template', 'admin_wapstyle', 'admin_rewrite', 'admin_message', 'admin_aliyunoss', 'admin_set');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_nav' : $_GET['cp'];

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter();
?>