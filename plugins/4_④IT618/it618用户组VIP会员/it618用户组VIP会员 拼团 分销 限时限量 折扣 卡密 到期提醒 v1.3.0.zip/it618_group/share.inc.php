<?php
 /**
 *	开发团队：DisM.Taobao.Com
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1Qh0" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_group = $_G['cache']['plugin']['it618_group'];

require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';

if($_GET['sharetype']=='goods'||$_GET['sharetype']=='goodstui'){
	$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($_GET['shareid']);
	$pid=$it618_group_goods['id'];
	
	$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
	$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
	$it618_unit=it618_group_getgoodsunit($it618_group_goods);
	$it618_name=$grouptitle.' '.$it618_unit;
	$share_img=it618_group_getwapppic($it618_group_goods['id'],$it618_group_goods['it618_picbig']);
	$tmparr=explode('://',$share_img);
	if(count($tmparr)==1)$share_img=$_G['siteurl'].$share_img;
	$it618_about=$it618_group_group['it618_power'];
	$it618_about=str_replace(array("\r\n", "\r", "\n"), '', $it618_about);
	$it618_about=cutstr($it618_about,90,'...');
	
	$pricestr=it618_group_getgoodsprice($it618_group_goods);
	
	if($IsUnion==1&&$_G['uid']>0){
		$urltmp='tuiuid='.$_G['uid'];
	}
	
	if($urltmp!=''){
		$tmpurl=$_G['siteurl'].it618_group_getrewrite('group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id'].'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=$_G['siteurl'].it618_group_getrewrite('group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id']);
	}
	
	if($IsWxMini==1){
		if($it618_wxmini_app=C::t('#it618_wxmini#it618_wxmini_app')->fetch_by_pluginid('it618_group')){
			$tmpurl=$_G['siteurl'].'plugin.php?id=it618_wxmini:url&aid='.$it618_wxmini_app['id'].'&q='.urlencode($tmpurl);
		}
	}
	
	$qrcodesrc='plugin.php?id=it618_group:urlcode&url='.urlencode($tmpurl);
	
	if($IsUnion==1){
		$sharecodecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." WHERE id=8 and it618_isproduct=1 and it618_state=1");
		if($sharecodecount>0){
			$share_img=$_G['siteurl'].'plugin.php?id=it618_union:sharecode&cid=8&class=product&dataid='.$it618_group_goods['id'].'&shareurl='.urlencode($tmpurl);
		}
	}
}

if($IsUnion==1){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
	}
}

$tuicount=intval($_GET['tuicount']);
if($sharecodecount>0||$union_group_isok>0||$tuicount>0){
	$sharetui=1;
}

if($_GET['wap']==1){
	if($sharetui>0){
		$shoptype='group';
		$scrolldivheight=$_GET['height']-100;
		
		$tmpmobiletpl=$_G['mobiletpl'][IN_MOBILE];
		$_G['mobiletpl'][IN_MOBILE]='/';
		include template('it618_union:unionshare');
		$_G['mobiletpl'][IN_MOBILE]=$tmpmobiletpl;
	}
}else{
	if($sharetui>0){
		$shoptype='group';
		$scrolldivheight=390;
		
		include template('it618_union:unionshare');
	}
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_group:share');
?>