<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_video/video_function.func.php';

if($pagetype=='search'||$templatename=='edu'){
	if($_GET['sw']==''||!isset($_GET['sw']))$searchsw=$it618_video['video_sw'];else $searchsw=dhtmlspecialchars($_GET['sw']);
}
if($searchsw!='')$sw=' style="display:none"';

$homeurl=it618_video_getrewrite('video_home','','plugin.php?id=it618_video:index');
$listurl=it618_video_getrewrite('video_list','0@0','plugin.php?id=it618_video:list');
$searchurl=it618_video_getrewrite('video_search','','plugin.php?id=it618_video:search');

$video_hotsw=explode(',',$it618_video['video_hotsw']);
for($i=0;$i<count($video_hotsw);$i++){
	$tmpurl=it618_video_getrewrite('video_search','','plugin.php?id=it618_video:search&sw='.urlencode($video_hotsw[$i]),'?sw='.urlencode($video_hotsw[$i]));
	$hotsw.='<a href="'.$tmpurl.'">'.$video_hotsw[$i].'</a>';
}

$stylecount=C::t('#it618_video#it618_video_style')->count_by_isok();
$it618_video_style=C::t('#it618_video#it618_video_style')->fetch_by_isok();

$topnav=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('topnav');
if($templatename=='mall'){
	$footer=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('footer');
	$video_logo=str_replace("{homeurl}",$homeurl,$it618_video['video_logo']);
}

if($templatename=='edu'){
	$footer=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('footer_edu');
	$tmparr=explode('src="',$it618_video['video_logo']);
	$tmparr1=explode('"',$tmparr[1]);
	$logosrc=$tmparr1[0];
	$tmparr=explode('href="',$it618_video['video_logo']);
	$tmparr1=explode('"',$tmparr[1]);
	$logourl=$tmparr1[0];
	if($logourl=='{homeurl}'){
		$logourl=$homeurl;
	}
}

if($template_isselect==1){
	if($templatename=='mall')$style1='style="color:red"';
	$styleli.='<li><a href="javascript:" onclick="templatestyle(\'mall\')" '.$style1.'>'.it618_video_getlang('s1812').'</a></li>';
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/template/edu/video_default.htm')){
		if($templatename=='edu')$style2='style="color:red"';
		$styleli.='<li><a href="javascript:" onclick="templatestyle(\'edu\')" '.$style2.'>'.it618_video_getlang('s1813').'</a></li>';
	}
	
	$templatestylestr='<li class="dropdown dropdown-account">
                    <p class="textwarp">
                        <em class="text">'.it618_video_getlang('s1811').'</em>
                        <i class="triangle"></i>
                        <em class="account-num" style="display:none;"></em>
					</p>
                    <ul class="htul">
						'.$styleli.'
                    </ul>
                </li>';
}

if($_G['uid']>0){
	C::t('#it618_video#it618_video_sale')->update_lastactivity_by_uid(TIMESTAMP,$_G['uid']);
	if(C::t('#it618_video#it618_video_shop')->count_by_it618_uid($_G['uid'])>0){
		if(C::t('#it618_video#it618_video_shop')->fetch_it618_state_by_it618_uid($_G['uid'])==2){
			$adminurl=it618_video_getrewrite('video_sc','','plugin.php?id=it618_video:sc');
		}
	}
	
	$pid=intval($_GET['pid']);
	if($pid>0){
		if($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid)){
			$adminurltmp=it618_video_getrewrite('video_sc','','plugin.php?id=it618_video:sc&adminsid='.$it618_video_goods['it618_shopid'],'?adminsid='.$it618_video_goods['it618_shopid']);
			$shopadmin=explode(",",$it618_video['video_shopadmin']);
			if(in_array($_G['uid'],$shopadmin)){
				$tmprz='<li>
						<a href="'.$adminurltmp.'" target="_blank"><font color=red>'.it618_video_getlang('s1433').'</font></a> 
					</li>';
			}
		}
	}
	
	$lid=intval($_GET['lid']);
	if($lid>0&&$pagetype=='lecturer'){
		if($it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($lid)){
			$adminurltmp=it618_video_getrewrite('video_sc','','plugin.php?id=it618_video:sc&adminsid='.$it618_video_shop['id'],'?adminsid='.$it618_video_shop['id']);
			$shopadmin=explode(",",$it618_video['video_shopadmin']);
			if(in_array($_G['uid'],$shopadmin)){
				$tmprz='<li>
						<a href="'.$adminurltmp.'" target="_blank"><font color=red>'.it618_video_getlang('s1433').'</font></a> 
					</li>';
			}
		}
	}
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		$it618_members = $_G['cache']['plugin']['it618_members'];
		if($it618_members['members_ishome']==1||$it618_members['members_ishome']==2){
			$tmpmembers='<li>
					<a href="javascript:" class="login-link" id="it618_members" style="color:#333"><img src="source/plugin/it618_members/images/logo.png" style="vertical-align:middle; margin-right:4px; margin-top:-3px;height:15px" />'.$it618_members['members_homename'].'</a> 
					</li>';
		}
	}
	
	if($IsCredits==1){
		$tmpcredits='<li>
					<a href="javascript:" class="login-link" id="it618_credits" style="color:#333"><img src="source/plugin/it618_credits/images/bigico.png" style="vertical-align:middle; margin-right:4px; margin-top:-3px;height:15px" />'.it618_video_getlang('s960').'</a> 
					</li>';
	}
	
	if($IsGroup==1){
		$tmpgroup='<li>
					<a href="javascript:" class="login-link" id="it618_group" style="color:#333"><img src="source/plugin/it618_group/images/group.png" style="vertical-align:middle; margin-right:4px; margin-top:-3px;height:15px" />'.it618_video_getlang('s797').'</a> 
					</li>';
	}
	
	$count=C::t('#it618_video#it618_video_gwc')->count_by_uid($_G['uid']);
	if($count>0)$count='<font color=red>'.$count.'</font>';
	$gwcurl=it618_video_getrewrite('video_gwc','','plugin.php?id=it618_video:gwc');
	
	$usermenu='<ul class="login cl">
				<li class="login-link">'.it618_video_getusername($_G['uid']).'</li>
				'.$tmpmembers.'
				'.$tmpcredits.'
				'.$tmpgroup.'
				<li style="padding-top:5px;"><a href="'.$gwcurl.'" target="_blank" style="color:#333"><img src="source/plugin/it618_video/images/gwc.png" style="vertical-align:middle;height:13px;margin-top:-1px"/> '.it618_video_getlang('t187').'(<span id="gwccount">'.$count.'</span>)</a></li>
                <li class="dropdown dropdown-account">
                    <p class="textwarp">
                        <em class="text">'.it618_video_getlang('s1595').'</em>
                        <i class="triangle"></i>
                        <em class="account-num" style="display:none;"></em>
					</p>
                    <ul class="htul">
						<li>
						<a href="javascript:" id="mysale">'.it618_video_getlang('s457').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="mysalekm">'.it618_video_getlang('s2288').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="mysubscribe">'.it618_video_getlang('s1403').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="mygoods">'.it618_video_getlang('s1653').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="myplay">'.it618_video_getlang('s458').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="mycollect">'.it618_video_getlang('s1654').'</a> 
				    	</li>
						<li>
						<a href="javascript:" id="myplaypj"><font color=green>'.it618_video_getlang('s459').'</font></a> 
				    	</li>
						'.$tmprz.'
                    </ul>
                </li>
				'.$templatestylestr.'
                <li><a class="login-link" href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" style="color:#333">['.it618_video_getlang('s460').']</a></li>
			   </ul>';
}else{
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if($it618_members['members_isok']==1){
		$usermenu='<ul class="login cl">
				'.$templatestylestr.'
                <li><a class="login-link it618_members_login" href="javascript:" style="color:#333">['.it618_video_getlang('s461').']</a></li>
                <li><a class="login-link it618_members_reg" href="javascript:" style="color:#333">['.it618_video_getlang('s462').']</a></li>    
               </ul>';
	}else{
		$usermenu='<ul class="login cl">
				'.$templatestylestr.'
                <li><a class="login-link" href="member.php?mod=logging&action=login" style="color:#333">['.it618_video_getlang('s461').']</a></li>
                <li><a class="login-link" href="member.php?mod='.$RegName.'" style="color:#333">['.it618_video_getlang('s462').']</a></li>    
               </ul>';
	}
}

if($templatename=='mall'){
	$n=1;
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_class1')." ORDER BY it618_order LIMIT 0,12");
	while($it618_video_class1 = DB::fetch($query1)) {
	
		$tmpurl1=it618_video_getrewrite('video_list',$it618_video_class1['id'],'plugin.php?id=it618_video:list&class1='.$it618_video_class1['id']);
		
		if($it618_video_class1['it618_color']!="")
		$tmpname='<font color='.$it618_video_class1['it618_color'].'>'.$it618_video_class1['it618_classname'].'</font>';else $tmpname=$it618_video_class1['it618_classname'];
		
		if($n<=9)$str_nav.='<a href="'.$tmpurl1.'">'.$tmpname.'</a>';
		
		$goodscount=C::t('#it618_video#it618_video_goods')->count_by_search('g.it618_state=1','',0,$it618_video_class1['id']);
		$str_class.='<div class="sort">
						<div class="sort-menu"><em class="sort-icon"></em><a class="title" href="'.$tmpurl1.'">'.$tmpname.'</a><span style="color:#999;line-height:26px">('.$goodscount.')</span></div>
						{it618classall}
					</div>';
		$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_video_class2')." where it618_class1_id=".$it618_video_class1['id']." ORDER BY it618_order");
		$it618classall='';
		while($it618_video_class2 = DB::fetch($query2)) {
			if($it618_video_class2['it618_color']!="")
			$tmpname='<font color='.$it618_video_class2['it618_color'].'>'.$it618_video_class2['it618_classname'].'</font>';else $tmpname=$it618_video_class2['it618_classname'];
			
			$tmpurl2=it618_video_getrewrite('video_list',$it618_video_class1['id'].'@'.$it618_video_class2['id'],'plugin.php?id=it618_video:list&class1='.$it618_video_class1['id'].'&class2='.$it618_video_class2['id']);
			$it618classall.='<li><a href="'.$tmpurl2.'">'.$tmpname.'</a></li>';
			if($i1ii1[5]!='_')return;
		}
		
		if($it618classall!=''){
			$str_class=str_replace("{it618classall}",'<div class="sort-con">
							<div class="sort-con-left">
								<h4><a href="'.$tmpurl1.'">'.$it618_video_class1['it618_classname'].'</a></h4>
								<ul class="sort-link02 cl">
									'.$it618classall.'
								</ul>
							</div>
						  </div>',$str_class);
		}else{
			$str_class=str_replace("{it618classall}",'',$str_class);
		}
	
		$n=$n+1;
	}
	
	$str_class.='<div class="sort-lottery">
					<div class="sort-menu" style="height:0;padding:0; margin:0"></div>
				 </div>';
				 
	$count = C::t('#it618_video#it618_video_nav')->count_by_search1();
	if($count>0){
		$str_nav='';
		foreach(C::t('#it618_video#it618_video_nav')->fetch_all_by_search1() as $it618_video_nav) {
			if($it618_video_nav['it618_color']!="")
			$tmpname='<font color='.$it618_video_nav['it618_color'].'>'.$it618_video_nav['it618_name'].'</font>';else $tmpname=$it618_video_nav['it618_name'];
			
			if($it618_video_nav['it618_target']==1)$it618_target=' target="_blank"';else $it618_target='';
			
			$str_nav.='<a href="'.$it618_video_nav['it618_url'].'"'.$it618_target.'>'.$tmpname.'</a>';
		}
	}
}

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	if(isset($_GET['reg']))$winapireg='winapireg';
	$it618_members_index=it618_members_getmembers($_GET['id'],'#it618_members','',$winapireg);
	if($_G['uid']>0)$it618_members_index.=it618_members_getmembers($_GET['id'],'#it618_members_wxbd','plugin.php?id=it618_members:home&ac=wxsubscribe').'<div id="it618_members_wxbd"></div>';
	if($it618_video['video_saletel']==2){
		if($_G['uid']>0)$it618_members_telbd=it618_members_getmembers($_GET['id'],'#it618_members_telbd','plugin.php?id=it618_members:home&ac=salebdtel').'<div id="it618_members_telbd"></div>';
	}
}

if($IsCredits==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$it618_credits_index=it618_credits_getcredits($_GET['id'],'#it618_credits');
	$it618_credits_buygroup=it618_credits_getcredits($_GET['id'],'#vippaybtn','plugin.php?id=it618_credits:do&dotype=buygroup');
}

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
	$it618_group_uc=it618_group_getgroup($_GET['id'],'#it618_group');
	$it618_group_ad=it618_group_getad($_GET['id'],2);
}
?>