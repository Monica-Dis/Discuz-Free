<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$ppp = 10;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$it618sql = "1";

$state0='';$state1='';$state2='';$state3='';$state4='';
if($_GET['state']==0){$state0='selected="selected"';}
if($_GET['state']==1){$it618sql .= " and it618_btime >".$_G['timestamp'];$state1='selected="selected"';}
if($_GET['state']==2){$it618sql .= " and it618_btime <".$_G['timestamp']." and it618_etime>".$_G['timestamp'];$state2='selected="selected"';}
if($_GET['state']==3){$it618sql .= " and it618_etime <".$_G['timestamp'];$state3='selected="selected"';}
if($_GET['state']==4){$it618sql .= " and it618_isok=1 and it618_etime <".$_G['timestamp'];$state4='selected="selected"';}

$chkstate0='';$chkstate1='';$chkstate2='';$chkstate3='';
if($_GET['chkstate']==0){$chkstate0='selected="selected"';}
if($_GET['chkstate']==1){$it618sql .= " and it618_chkstate = 0";$chkstate1='selected="selected"';}
if($_GET['chkstate']==2){$it618sql .= " and it618_chkstate = 1";$chkstate2='selected="selected"';}
if($_GET['chkstate']==3){$it618sql .= " and it618_chkstate = 2";$chkstate3='selected="selected"';}

$urlsql='&key='.$_GET['key'].'&state='.$_GET['state'].'&chkstate='.$_GET['chkstate'];

$preurl="plugin.php?id=it618_video:sc_live$adminsid".$urlsql."&page=$page";
$preurl=str_replace("&","@",$preurl);

if(submitcheck('it618submit_edit')){
	$ok=0;
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			C::t('#it618_video#it618_video_live')->update($id,array(
				'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
				'it618_description' => dhtmlspecialchars($_GET['it618_description'][$id]),
				'it618_savetype' => $_GET['it618_savetype'][$id],
				'it618_isuser' => $_GET['it618_isuser'][$id]
			));
			
			$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_liveid($id);
			C::t('#it618_video#it618_video_goods_video')->update($it618_video_goods_video['id'],array(
				'it618_isuser' => $_GET['it618_isuser'][$id]
			));
			
			if(dhtmlspecialchars($_GET['it618_m3u8url'][$id])!=''){
				C::t('#it618_video#it618_video_live')->update($id,array(
					'it618_m3u8url' => dhtmlspecialchars($_GET['it618_m3u8url'][$id])
				));
			}
	
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_video_getlang('s345').$ok, "plugin.php?id=it618_video:sc_live$adminsid&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_del')){
	$del=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($delid);
		if($it618_video_live['it618_chkstate']==2){
			DB::delete('it618_video_live', "id=$delid");
			$del=$del+1;
		}
	}

	it618_cpmsg(it618_video_getlang('s1344').$del, "plugin.php?id=it618_video:sc_live$adminsid&page=$page".$urlsql, 'succeed');
}

it618_showformheader("plugin.php?id=it618_video:sc_live$adminsid&page=$page".$urlsql);
showtableheaders(it618_video_getlang('s1276'),'it618_video_sum');
	echo '<tr><td colspan=14>'.it618_video_getlang('s97').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:300px;margin-right:3px" />'.it618_video_getlang('s1314').' <select name="state"><option value=0 '.$state0.'>'.it618_video_getlang('s102').'</option><option value=1 '.$state1.'>'.it618_video_getlang('s1350').'</option><option value=2 '.$state2.'>'.it618_video_getlang('s1317').'</option><option value=3 '.$state3.'>'.it618_video_getlang('s1728').'</option><option value=4 '.$state4.'>'.it618_video_getlang('s1318').'</option></select> '.it618_video_getlang('s1315').' <select name="chkstate"><option value=0 '.$chkstate0.'>'.it618_video_getlang('s102').'</option><option value=1 '.$chkstate1.'>'.it618_video_getlang('s677').'</option><option value=2 '.$chkstate2.'>'.it618_video_getlang('s678').'</option><option value=3 '.$chkstate3.'>'.it618_video_getlang('s679').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_video_getlang('s350').'" /></td></tr>';
	
	$count = C::t('#it618_video#it618_video_live')->count_by_search($it618sql,'',$ShopId,0,0,$_GET['key']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_video:sc_live$adminsid".$urlsql);
	
	echo '<tr><td colspan=14>'.it618_video_getlang('s1319').$count.'<span style="float:right;color:red">'.$it618_video_lang['s1320'].'</font></td></tr>';
	showsubtitle(array('',it618_video_getlang('s1310'),it618_video_getlang('s1311'),it618_video_getlang('s1312'),$it618_video_lang['s1313'],$it618_video_lang['s1314'],$it618_video_lang['s1315']));
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/message.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_video/config/message.php';
	}
	
	if($it618_isok==1&&$it618_body_live_user_isok==1){
		$isliveorder=1;
	}
	
	$n=1;
	foreach(C::t('#it618_video#it618_video_live')->fetch_all_by_search(
		$it618sql,'id desc',$ShopId,0,0,$_GET['key'],$startlimit,$ppp
	) as $it618_video_live) {
		
		$it618_video_liveset = C::t('#it618_video#it618_video_liveset')->fetch_by_id($it618_video_live['it618_liveset_id']);
		
		if($it618_video_live['it618_isuser']==0){$it618_isuser_selected0='selected="selected"';$isusercolor='#390';$tmpuser=$it618_video_lang['s30'];}else $it618_isuser_selected0="";
		if($it618_video_live['it618_isuser']==1){$it618_isuser_selected1='selected="selected"';$isusercolor='#f30';$tmpuser=$it618_video_lang['s27'];}else $it618_isuser_selected1="";
		if($it618_video_live['it618_isuser']==2){$it618_isuser_selected2='selected="selected"';$isusercolor='#22b1fe';$tmpuser=$it618_video_lang['s28'];}else $it618_isuser_selected2="";
		
		$tmpnamestr='<input type="text" class="txt" style="width:300px;margin-bottom:4px" name="it618_name['.$it618_video_live['id'].']" value="'.$it618_video_live['it618_name'].'"><br><textarea name="it618_description['.$it618_video_live['id'].']" style="width:300px;height:50px;">'.$it618_video_live['it618_description'].'</textarea>';
		$tmpuserstr='<select style="color:'.$isusercolor.'" name="it618_isuser['.$it618_video_live['id'].']"><option value=1 '.$it618_isuser_selected1.' style="color:#f30">'.$it618_video_lang['s27'].'</option><option value=2 '.$it618_isuser_selected2.' style="color:#22b1fe">'.$it618_video_lang['s28'].'</option><option value=0 '.$it618_isuser_selected0.' style="color:#390">'.$it618_video_lang['s30'].'</option></select>';
		
		if($it618_video_live['it618_chkstate']==0){
			$it618_chkstate='<font color=red>'.$it618_video_lang['s677'].'</font>';
		}
		
		$it618_state='';
		if($it618_video_live['it618_chkstate']==1){
			$it618_chkstate='<font color=green>'.$it618_video_lang['s678'].'</font>';
			
			$livecode='';
			if($it618_video_live['it618_btime']>$_G['timestamp']){
				if($it618_video_live['it618_liveset_id']>0){
					if($it618_video_live['it618_btime']-$_G['timestamp']<=$it618_video_liveset['it618_copytime']*60){
						$livecode='<br><a href="javascript:" style="display:inline-block; padding:3px 6px;padding-bottom:4px; background-color:#390; margin-top:3px; color:#fff; border-radius:3px" onclick="setlivecode('.$it618_video_live['id'].')">'.$it618_video_lang['s1334'].'</a>';
					}
				}
				
				if($isliveorder==1){
					$ordercount=C::t('#it618_video#it618_video_live_order')->count_by_liveid($it618_video_live['id']);
					$liveorder='<br><br>'.$it618_video_lang['s1856'].$ordercount;
				}
				
				$it618_state='<font color=red>'.it618_video_gettime1($it618_video_live['it618_btime']).$it618_video_lang['s1316'].'</font> '.$livecode.$liveorder;
			}
			
			if($it618_video_live['it618_btime']<$_G['timestamp']&&$_G['timestamp']<$it618_video_live['it618_etime']){
				$tmptime=round(($it618_video_live['it618_etime']-$_G['timestamp'])/60,2);
				$it618_video_lang['s1720']=str_replace("{time}",$tmptime,$it618_video_lang['s1720']);
				$it618_state='<font color=green>'.$it618_video_lang['s1317'].'</font><br><br>'.$it618_video_lang['s1720'];
				if($it618_video_live['it618_liveset_id']>0){
					$it618_state.='<br><a href="javascript:" style="display:inline-block; padding:3px 6px;padding-bottom:4px; background-color:#390; margin-top:3px; color:#fff; border-radius:3px" onclick="setlivecode('.$it618_video_live['id'].')">'.$it618_video_lang['s1334'].'</a>';
				}
			}
			
			if($_G['timestamp']>$it618_video_live['it618_etime']){
				if($it618_video_live['it618_isok']==1){
					$it618_state='<font color=#999>'.$it618_video_lang['s1318'].'</font>';
				}else{
					$it618_state='<font color=#fof>'.$it618_video_lang['s1728'].'</font>';
				}
				$tmpnamestr='<div style="width:313px;line-height:18px">'.$it618_video_live['it618_name'].'<br>'.$it618_video_live['it618_description'].'</div>';
				$tmpuserstr=$tmpuser;
			}
			
			$m3u8url='';$tmpsavetypestr='';
			if($it618_video_live['it618_etime']>$_G['timestamp']){
				if($it618_video_live['it618_liveset_id']==0){
					$m3u8url='<br><br>'.$it618_video_lang['s1501'].'<br><textarea name="it618_m3u8url['.$it618_video_live['id'].']" style="width:300px;height:50px;margin-top:3px">'.$it618_video_live['it618_m3u8url'].'</textarea>';
				}
				
				if($it618_video_live['it618_liveset_id']==0||($it618_video_live['it618_ossbucket']==''&&$it618_video_live['it618_ossendpoint']=='')){
					if($it618_video_live['it618_savetype']==1)$it618_savetype_selected1='selected="selected"';else $it618_savetype_selected1="";
					if($it618_video_live['it618_savetype']==2)$it618_savetype_selected2='selected="selected"';else $it618_savetype_selected2="";
					if($it618_video_live['it618_savetype']==3)$it618_savetype_selected3='selected="selected"';else $it618_savetype_selected3="";
					
					$tmpsavetypestr='<br><select name="it618_savetype['.$it618_video_live['id'].']"><option value=1 '.$it618_savetype_selected1.'>'.$it618_video_lang['s1611'].'</option><option value=2 '.$it618_savetype_selected2.'>'.$it618_video_lang['s1612'].'</option><option value=3 '.$it618_savetype_selected3.'>'.$it618_video_lang['s1613'].'</option></select>';
				}
				
				if($it618_video_live['it618_iseditetime']==1||$it618_video_live['it618_liveset_id']==0)$it618_state.='<br><br><a href="javascript:" style="display:inline-block; padding:3px 6px;padding-bottom:4px; background-color:#f30; color:#fff; border-radius:3px" onclick="setliveetime('.$it618_video_live['id'].','.$it618_video_live['it618_liveset_id'].')">'.$it618_video_lang['s1754'].'</a>';
			}
		}
		
		if($it618_video_live['it618_chkstate']==2){
			$it618_chkstate='<font color=blue>'.$it618_video_lang['s679'].'</font>';
		}
		
		$it618_video_goods_lesson=C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($it618_video_live['it618_lid']);
		$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_live['it618_pid']);
		$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_liveid($it618_video_live['id']);
		$liveurl='';
		if($it618_video_goods_video['id']>0){
			$tmpurl=it618_video_getrewrite('video_lesson',$it618_video_goods_video['id'],'plugin.php?id=it618_video:lesson&lid='.$it618_video_goods_video['id']);
			$liveurl='<a href="'.$tmpurl.'" style="display:inline-block; padding:3px 6px;padding-bottom:4px; background-color:#22b1fe; color:#fff; border-radius:3px" target="_blank">'.$it618_video_lang['s746'].'</a>';
		}
		
		if($it618_video_live['it618_ossbucket']!=''&&$it618_video_live['it618_ossendpoint']!=''){
			$livesetstr='<font color=#f60>'.$it618_video_lang['s1302'].$it618_video_live['it618_livetime'].$it618_video_lang['s1305'].'</font> <font color=green>'.$it618_video_lang['s1272'].'</font>';
		}else{
			$livesetstr='<font color=#f60>'.$it618_video_lang['s1302'].$it618_video_live['it618_livetime'].$it618_video_lang['s1305'].'</font> <font color=blue>'.$it618_video_lang['s1273'].'</font>';
		}
		
		$it618_usercode='';
		if($it618_video_live['it618_isuser']!=1){
			if($it618_video_goods_video['it618_usercode']!=''){
				$it618_usercode='<br>'.$it618_video_lang['s1983'];
			}
		}

		showtablerow('', array('', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_video_live['id'].'"><label for="chk_del'.$n.'">'.$it618_video_live['id'].'</label>',
			$tmpnamestr.$m3u8url,
			'<div style="width:300px;line-height:18px">'.$it618_video_goods['it618_name'].'<br><a href="plugin.php?id=it618_video:sc_product_lesson'.$adminsid.'&type=live&pid='.$it618_video_goods['id'].'&preurl='.$preurl.'"><img src="source/plugin/it618_video/images/zj.png" style="vertical-align:middle;height:12px;margin-top:-1px;margin-right:3px">'.$it618_video_goods_lesson['it618_name'].'</a><br>'.$liveurl.' <font color=#999>'.date('Y-m-d H:i:s', $it618_video_live['it618_time']).'</font></div>',
			$it618_video_liveset['it618_name'].'<br>'.$livesetstr.'<br><font color=#999>'.date('Y-m-d H:i:s', $it618_video_live['it618_btime']).'<br>'.date('Y-m-d H:i:s', $it618_video_live['it618_etime']).'</font>'.$tmpsavetypestr,
			$tmpuserstr.$it618_usercode,
			$it618_state,
			$it618_chkstate
		));
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_video_getlang('s129').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_edit" value="'.it618_video_getlang('s1322').'"/> <input type="submit" class="btn" name="it618submit_del" value="'.it618_video_getlang('s1323').'"/><input type=hidden value='.$page.' name=page /></div><br></td></tr>';
	
	echo '
	<div id="livecode"></div><a class="clipboardbtn1" id="clipboardbtn1" data-clipboard-text=""></a><a class="clipboardbtn2" id="clipboardbtn2" data-clipboard-text=""></a><a class="clipboardbtn3" id="clipboardbtn3" data-clipboard-text=""></a>
<script charset="utf-8" src="source/plugin/it618_video/js/laydate/laydate.js"></script>
<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_video/js/jquery.js"></script>
<script type="text/javascript" src="source/plugin/it618_video/js/clipboard.min.js"></script>

<script>
function setlivecode(liveid){
	layerindex=layer.open({
		type: 1,
		title: "<div style=\'float:left;color:blue\'>'.$it618_video_lang['s1334'].'</div>",
		shadeClose: false,
		scrollbar: false,
		shade:  0.3,
		maxmin: false,
		area: ["690px","410px"],
		content: \'<div style="padding:6px;text-align:left" id="layer_livecode"></div>\',
		cancel: function(index, layero){ 
		}    
	});
	
	IT618_VIDEO("#layer_livecode").html(\'<img src="source/plugin/it618_video/wap/images/loading.gif">\');
	
	IT618_VIDEO.get("'.$_G['siteurl'].'plugin.php?id=it618_video:showlivecode'.$adminsid.'"+"&liveid="+liveid, {ac:"it618"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	
	IT618_VIDEO("#clipboardbtn1").attr("data-clipboard-text",tmparr[0]);
	IT618_VIDEO("#clipboardbtn2").attr("data-clipboard-text",tmparr[1]);
	IT618_VIDEO("#clipboardbtn3").attr("data-clipboard-text",tmparr[2]);
	
	IT618_VIDEO("#layer_livecode").html(tmparr[3]);
	
	}, "html");	
}

var clipboardbtn1 = new Clipboard(".clipboardbtn1");
clipboardbtn1.on("success", function(e) {
	layeralert("'.$it618_video_lang['s1457'].'");
});
var clipboardbtn2 = new Clipboard(".clipboardbtn2");
clipboardbtn2.on("success", function(e) {
	layeralert("'.$it618_video_lang['s1458'].'");
});
var clipboardbtn3 = new Clipboard(".clipboardbtn3");
clipboardbtn3.on("success", function(e) {
	layeralert("'.$it618_video_lang['s1539'].'");
});

function layeralert(value){
	layer.msg(value);
}

function setliveetime(liveid,type){
	if(type==0){
		var tmpstr="'.$it618_video_lang['s1975'].'";
	}else{
		var tmpstr="'.$it618_video_lang['s1755'].'";
	}
	if(confirm(tmpstr)){
		IT618_VIDEO.get("'.$_G['siteurl'].'plugin.php?id=it618_video:ajax'.$adminsid.'&liveid="+liveid+"&formhash='.FORMHASH.'", {ac:"setliveetime"},function (data, textStatus){
			var tmparr=data.split("it618_split");
			if(tmparr[0]=="ok"){
				alert("'.$it618_video_lang['s1756'].'");
				location.reload();
			}else{
				alert(data);
			}
		}, "html");	
	}
}
</script>
';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/

require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>