<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$ppp = 20;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$pid=intval($_GET['pid']);
$lid=intval($_GET['lid']);
$vid=intval($_GET['vid']);

$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
$it618_price = DB::result_first("SELECT it618_price FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_video_goods_type', "id=$delid");
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_timetype'])) {
		foreach($_GET['it618_timetype'] as $id => $val) {
			
			if(trim($_GET['it618_saleprice'][$id])>$it618_price){
				$it618_saleprice=trim($_GET['it618_saleprice'][$id]);
			}else{
				$it618_saleprice=$it618_price;
			}
			
			$it618_score=$_GET['it618_score'][$id];
			if($_GET['it618_jfid'][$id]==0)$it618_score=0;
			
			$it618_ison=$_GET['it618_ison'][$id];
			
			$it618_xgtime=trim($_GET['it618_xgtime'][$id]);
			$it618_xgcount=trim($_GET['it618_xgcount'][$id]);
			if( trim($_GET['it618_time'][$id])==0){
				$it618_xgtime=0;
				$it618_xgcount=1;
			}
			
			$it618_timetype=trim($_GET['it618_timetype'][$id]);
			$it618_time=trim($_GET['it618_time'][$id]);

			C::t('#it618_video#it618_video_goods_type')->update($id,array(
				'it618_time' => trim($_GET['it618_time'][$id]),
				'it618_typename' => trim($_GET['it618_typename'][$id]),
				'it618_timetype' => trim($_GET['it618_timetype'][$id]),
				'it618_counttype' => trim($_GET['it618_counttype'][$id]),
				'it618_count' => trim($_GET['it618_count'][$id]),
				'it618_xgtime' => $it618_xgtime,
				'it618_xgcount' => $it618_xgcount,
				'it618_saleprice' => $it618_saleprice,
				'it618_price' => trim($_GET['it618_price'][$id]),
				'it618_jfid' => trim($_GET['it618_jfid'][$id]),
				'it618_score' => $it618_score,
				'it618_ison' => $it618_ison
			));
			
			$ok1=$ok1+1;
		}
	}
	
	$newit618_time_array = !empty($_GET['newit618_time']) ? $_GET['newit618_time'] : array();
	$newit618_timetype_array = !empty($_GET['newit618_timetype']) ? $_GET['newit618_timetype'] : array();
	$newit618_count_array = !empty($_GET['newit618_count']) ? $_GET['newit618_count'] : array();
	$newit618_xgtime_array = !empty($_GET['newit618_xgtime']) ? $_GET['newit618_xgtime'] : array();
	$newit618_xgcount_array = !empty($_GET['newit618_xgcount']) ? $_GET['newit618_xgcount'] : array();
	$newit618_saleprice_array = !empty($_GET['newit618_saleprice']) ? $_GET['newit618_saleprice'] : array();
	$newit618_price_array = !empty($_GET['newit618_price']) ? $_GET['newit618_price'] : array();
	$newit618_jfid_array = !empty($_GET['newit618_jfid']) ? $_GET['newit618_jfid'] : array();
	$newit618_score_array = !empty($_GET['newit618_score']) ? $_GET['newit618_score'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	$newit618_order1_array = !empty($_GET['newit618_order1']) ? $_GET['newit618_order1'] : array();
	
	foreach($newit618_timetype_array as $key => $value) {
		$newit618_timetype = addslashes(trim($newit618_timetype_array[$key]));
		
		if($newit618_timetype != '') {
			
			if(trim($newit618_saleprice_array[$key])>$it618_price){
				$it618_saleprice=trim($newit618_saleprice_array[$key]);
			}else{
				$it618_saleprice=$it618_price;
			}
			
			$it618_xgtime=trim($newit618_xgtime_array[$key]);
			$it618_xgcount=trim($newit618_xgcount_array[$key]);
			if(trim($newit618_time_array[$key])==0){
				$it618_xgtime=0;
				$it618_xgcount=1;
			}
			
			$it618_timetype=trim($newit618_timetype_array[$key]);
			$it618_time=trim($newit618_time_array[$key]);
			                                        
			C::t('#it618_video#it618_video_goods_type')->insert(array(
				'it618_pid' => $pid,
				'it618_lid' => $lid,
				'it618_vid' => $vid,
				'it618_time' => $it618_time,
				'it618_timetype' => $it618_timetype,
				'it618_counttype' => 2,
				'it618_saleprice' => $it618_saleprice,
				'it618_price' => trim($newit618_price_array[$key]),
				'it618_jfid' => trim($newit618_jfid_array[$key]),
				'it618_score' => trim($newit618_score_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}
	
	if(C::t('#it618_video#it618_video_goods_type')->counttype_by_pid_lid_vid_ok($pid,$lid,$vid)>0){
		if(!$it618_video_goods_typetmp=C::t('#it618_video#it618_video_goods_type')->fetch_price_by_it618_pid_lid_vid($pid,$lid,$vid)){
			if(!$it618_video_goods_typetmp=C::t('#it618_video#it618_video_goods_type')->fetch_score_by_it618_pid_lid_vid($pid,$lid,$vid)){
				DB::query("update ".DB::table('it618_video_goods_type')." set it618_ison=0 WHERE it618_pid=".$pid);
				it618_cpmsg($it618_video_lang['s1351'], "plugin.php?id=it618_video:sc_product_type$adminsid&pid=$pid&lid=$lid&vid=$vid", 'error');
			}
		}
	}
	
	if($lid==0&&$vid==0){
		C::t('#it618_video#it618_video_goods')->update($pid,array(
			'it618_saleprice' => $it618_video_goods_typetmp['it618_saleprice'],
			'it618_price' => $it618_video_goods_typetmp['it618_price'],
			'it618_jfid' => $it618_video_goods_typetmp['it618_jfid'],
			'it618_score' => $it618_video_goods_typetmp['it618_score']
		));
	}
	
	if($lid>0&&$vid==0){
		C::t('#it618_video#it618_video_goods_lesson')->update($lid,array(
			'it618_saleprice' => $it618_video_goods_typetmp['it618_saleprice'],
			'it618_price' => $it618_video_goods_typetmp['it618_price'],
			'it618_jfid' => $it618_video_goods_typetmp['it618_jfid'],
			'it618_score' => $it618_video_goods_typetmp['it618_score']
		));
	}
	
	if($lid>0&&$vid>0){
		C::t('#it618_video#it618_video_goods_video')->update($vid,array(
			'it618_saleprice' => $it618_video_goods_typetmp['it618_saleprice'],
			'it618_price' => $it618_video_goods_typetmp['it618_price'],
			'it618_jfid' => $it618_video_goods_typetmp['it618_jfid'],
			'it618_score' => $it618_video_goods_typetmp['it618_score']
		));
	}

	it618_cpmsg($it618_video_lang['s33'].$ok1.' '.$it618_video_lang['s34'].$ok2.' '.$it618_video_lang['s35'].$del.')', "plugin.php?id=it618_video:sc_product_type$adminsid&pid=$pid&lid=$lid&vid=$vid", 'succeed');
}

if(submitcheck('it618submitcopy')){
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_type')." WHERE it618_pid=".intval($_GET['it618_copyid']));
	if($count==0){
		it618_cpmsg($it618_video_lang['s1164'], "plugin.php?id=it618_video:sc_product_type$adminsid&pid=$pid&lid=$lid&vid=$vid", 'error');
	}
	
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_type')." WHERE it618_pid=".$pid);
	if($count>0){
		it618_cpmsg($it618_video_lang['s1165'], "plugin.php?id=it618_video:sc_product_type$adminsid&pid=$pid&lid=$lid&vid=$vid", 'error');
	}
	
	$ok=0;
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_type')." WHERE it618_pid=".intval($_GET['it618_copyid'])." ORDER BY it618_order,it618_name");
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_lesson')." WHERE it618_pid=".intval($_GET['it618_copyid']));
	while($it618_video_goods_type = DB::fetch($query)) {
		if($it618_video_goods_type['it618_index1']<$count&&$it618_video_goods_type['it618_index2']<$count){
			C::t('#it618_video#it618_video_goods_type')->insert(array(
				'it618_pid' => $pid,
				'it618_lid' => $lid,
				'it618_vid' => $vid,
				'it618_time' => $it618_video_goods_type['it618_time'],
				'it618_timetype' => $it618_video_goods_type['it618_timetype'],
				'it618_count' => $it618_video_goods_type['it618_count'],
				'it618_xgtime' => $it618_video_goods_type['it618_xgtime'],
				'it618_xgcount' => $it618_video_goods_type['it618_xgcount'],
				'it618_saleprice' => $it618_video_goods_type['it618_saleprice'],
				'it618_price' => $it618_video_goods_type['it618_price'],
				'it618_jfid' => $it618_video_goods_type['it618_jfid'],
				'it618_score' => $it618_video_goods_type['it618_score'],
			), true);
			$ok=$ok+1;
		}
	}
	
	it618_cpmsg($it618_video_lang['s1166'].$ok, "plugin.php?id=it618_video:sc_product_type$adminsid&pid=$pid&lid=$lid&vid=$vid", 'succeed');
}

it618_showformheader("plugin.php?id=it618_video:sc_product_type$adminsid&pid=$pid&lid=$lid&vid=$vid");
$preurltmp=str_replace("@","&",$preurl);
showtableheaders('','admin_shopproduct_type');

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_type')." WHERE it618_pid=$pid and it618_lid=$lid and it618_vid=$vid");

$tmpname=$it618_video_goods['it618_name'];

if($lid>0){
	$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
	$tmpname.=' -> '.$it618_video_goods_lesson['it618_name'];
}

if($vid>0){
	$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($vid);
	$tmpname.=' -> '.$it618_video_goods_video['it618_name'];
}

echo '<tr><td colspan=15 style="line-height:21px"><b>'.$tmpname.'</b></td></tr>';

echo '<tr style="display:none"><td colspan=15>'.$it618_video_lang['s1167'].'<input class="txt" type="text" name="it618_copyid" style="width:60px"><input type="submit" class="btn" name="it618submitcopy" value="'.$it618_video_lang['s1168'].'" onclick="return confirm(\''.$it618_video_lang['s1169'].'\')" /></span></td></tr>';
echo '<tr><td colspan=15 style="line-height:21px">'.$it618_video_lang['s1354'].'</td></tr>';
echo '<tr><td colspan=15>'.$it618_video_lang['s713'].$count.'<span style="float:right;">'.$it618_video_lang['s714'].'</span></td></tr>';

showsubtitle(array('', $it618_video_lang['s712'].'/'.$it618_video_lang['s1995'],$it618_video_lang['s717'],$it618_video_lang['s718'].'/'.$it618_video_lang['s719'].'/'.$it618_video_lang['s1120'], $it618_video_lang['s721'], $it618_video_lang['s722']));

$tmpoptionstr='<option value="5">'.$it618_video_lang['s1148'].'</option><option value="4">'.$it618_video_lang['s1147'].'</option><option value="3">'.$it618_video_lang['s1146'].'</option><option value="2">'.$it618_video_lang['s1145'].'</option><option value="1">'.$it618_video_lang['s1144'].'</option><option value="6">'.$it618_video_lang['s1153'].'</option>';

$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_type')." WHERE it618_pid=$pid and it618_lid=$lid and it618_vid=$vid ORDER BY it618_ison desc,it618_timetype desc,it618_time");
while($it618_video_goods_type = DB::fetch($query)) {

	$salecount = $it618_video_goods_type['it618_salecount'];
	$disabled="";$readonly="";$bgcolor="";
	if($salecount>0){
		$disabled="disabled=\"disabled\"";
		
		if($it618_video_goods_type['it618_timetype']==1)$it618_name=$it618_video_goods_type['it618_time'].$it618_video_lang['s1144'];
		if($it618_video_goods_type['it618_timetype']==2)$it618_name=$it618_video_goods_type['it618_time'].$it618_video_lang['s1145'];
		if($it618_video_goods_type['it618_timetype']==3)$it618_name=$it618_video_goods_type['it618_time'].$it618_video_lang['s1146'];
		if($it618_video_goods_type['it618_timetype']==4)$it618_name=$it618_video_goods_type['it618_time'].$it618_video_lang['s1147'];
		if($it618_video_goods_type['it618_timetype']==5)$it618_name=$it618_video_goods_type['it618_time'].$it618_video_lang['s1148'];
		if($it618_video_goods_type['it618_timetype']==6)$it618_name=$it618_video_lang['s1153'];
		
		$it618_timestr=$it618_name."<input type=\"hidden\" name=\"it618_time[".$it618_video_goods_type['id']."]\" value=\"".$it618_video_goods_type['it618_time']."\"><input type=\"hidden\" name=\"it618_timetype[".$it618_video_goods_type['id']."]\" value=\"".$it618_video_goods_type['it618_timetype']."\">";
	}else{
		$tmpcss=';display:';
		if($it618_video_goods_type['it618_timetype']==6)$tmpcss=';display:none';
		
		$tmpoptionstr1=str_replace('<option value="'.$it618_video_goods_type['it618_timetype'].'"','<option value="'.$it618_video_goods_type['it618_timetype'].'" selected="selected"',$tmpoptionstr);
		$tmpoptionstr1="<select name=\"it618_timetype[".$it618_video_goods_type['id']."]\" onchange=\"getselect(this,".$it618_video_goods_type['id'].")\">".$tmpoptionstr1."</select>";
		
		$it618_timestr="<input type=\"text\" class=\"txt\" style=\"width:40px;margin-right:3px;margin-bottom:3px;".$tmpcss."\" id=\"time".$it618_video_goods_type['id']."\" name=\"it618_time[".$it618_video_goods_type['id']."]\" value=\"".$it618_video_goods_type['it618_time']."\">".$tmpoptionstr1;
	}
	if($it618_video_goods_type['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
	
	if($it618_video_goods_type['it618_counttype']==1){
		$spancountcss='style="display:"';
		$it618_counttype1=' selected="selected"';
		$it618_counttype2='';
	}else{
		$spancountcss='style="display:none"';
		$it618_counttype1='';
		$it618_counttype2=' selected="selected"';
	}
	
	if($it618_video_goods_type['it618_time']==0)$timecss='display:none';else $timecss="";
	
	if($IsPinEdu==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/function.func.php';
		$goodspin=it618_pinedu_getgoodspinstate('video',$it618_video_goods_type['id']);
		$goodspinstr=' <a href="javascript:" onclick="showgoodspin('.$goodspin['id'].','.$it618_video_goods_type['id'].')">'.$goodspin['name'].''.$goodspin['count'].'</a>';
	}
	
	if($it618_video_shop['it618_issalekm']==1){
		$IsSaleKm=1;
	}else{
		$shopadmin=explode(",",$it618_video['video_shopadmin']);
		if(in_array($_G['uid'],$shopadmin)){
			$IsSaleKm=1;
		}
	}
	
	if($IsSaleKm==1){
		$kmcount = C::t('#it618_video#it618_video_goods_km')->count_by_search('','',$it618_video_goods_type['id']);
		$kmusecount = C::t('#it618_video#it618_video_salekm')->count_by_search('','',$it618_video_goods_type['id']);
		if($kmcount>0)$kmcount='<font color=red>'.$kmcount.'</font>';
		$salekmstr=' <a href="javascript:" onclick="showkm('.$it618_video_goods_type['id'].')">'.$it618_video_lang['s2027'].'('.$kmcount.')</a> <a href="javascript:" onclick="showkmuse('.$it618_video_goods_type['id'].')">'.$it618_video_lang['s2028'].'('.$kmusecount.')</a>';
		if($IsPinEdu==1){
			$goodspinstr=' |'.$goodspinstr;
		}
	}
	
	showtablerow('', array('class="td25"', '', '', '', '', ''), array(
		'<input class="checkbox" type="checkbox" id="chk_del'.$it618_video_goods_type['id'].'" name="delete[]" value="'.$it618_video_goods_type['id'].'" '.$disabled.'><label for="chk_del'.$it618_video_goods_type['id'].'">'.$it618_video_goods_type['id'].'</label>',
		'<div style="float:left;width:58px">'.$it618_timestr."</div><span style=\"float:left\"><input type=\"text\" class=\"txt\" style=\"width:80px;margin-right:3px\" name=\"it618_typename[".$it618_video_goods_type['id']."]\" value=\"".$it618_video_goods_type['it618_typename']."\">".'<a href="javascript:" onclick="showtypeabout('.$it618_video_goods_type['id'].')">'.$it618_video_lang['s1996'].'('.strlen($it618_video_goods_type['it618_typeabout']).')</a></span>',
		"<input type=\"text\" class=\"txt\" style=\"width:50px;color:red;margin-right:3px\" name=\"it618_saleprice[".$it618_video_goods_type['id']."]\" value=\"".$it618_video_goods_type['it618_saleprice']."\">".it618_video_getlang('s125')." + <input type=\"text\" class=\"txt\" style=\"width:40px;color:red;margin-right:3px\" name=\"it618_score[".$it618_video_goods_type['id']."]\" value=\"".$it618_video_goods_type['it618_jfid']."\">".'<select name="it618_jfid['.$it618_video_goods_type['id'].']">'.it618_video_getjftype($it618_video_goods_type['it618_jfid']).'</select>'.$salekmstr.$goodspinstr,
		"<input type=\"text\" class=\"txt\" style=\"width:60px\" name=\"it618_price[".$it618_video_goods_type['id']."]\" value=\"".$it618_video_goods_type['it618_price']."\">".'<select style="margin-left:6px;margin-right:3px" name="it618_counttype['.$it618_video_goods_type['id'].']" onchange="getcountype(this.value,'.$it618_video_goods_type['id'].')"><option value="1" '.$it618_counttype1.'>'.$it618_video_lang['s1659'].'</option><option value="2" '.$it618_counttype2.'>'.$it618_video_lang['s1660'].'</option></select><span id="spancount'.$it618_video_goods_type['id'].'" '.$spancountcss.'>'."<input type=\"text\" class=\"txt\" style=\"width:40px\" name=\"it618_count[".$it618_video_goods_type['id']."]\" value=\"".$it618_video_goods_type['it618_count']."\"><span style='".$timecss."'><input type=\"text\" class=\"txt\" style=\"width:20px;margin-right:3px\" name=\"it618_xgtime[".$it618_video_goods_type['id']."]\" value=\"".$it618_video_goods_type['it618_xgtime']."\">".$it618_video_lang['s1124']." <input type=\"text\" class=\"txt\" style=\"width:20px;margin-right:3px\" name=\"it618_xgcount[".$it618_video_goods_type['id']."]\" value=\"".$it618_video_goods_type['it618_xgcount']."\">".$it618_video_lang['s1129']."</span></span>",
		'<input class="checkbox" type="checkbox" id="chk_ison'.$n.'" name="it618_ison['.$it618_video_goods_type['id'].']" '.$it618_ison_checked.' value="1">',
		$salecount
	));
}
	

	$s125=it618_video_getlang('s125');
	$s1124=it618_video_getlang('s1124');
	$s1661=$it618_video_lang['s1661'];

	$tmpjftype='<select name="newit618_jfid[]">'.it618_video_getjftype().'</select>';
	
	if($IsPinEdu==1){
	echo '
	<script>
	function showgoodspin(pinid,typeid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_pinedu_lang['s5'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["930px", "430px"],
			content: "plugin.php?id=it618_pinedu:sc_product'.$adminsid.'&shoptype=video&pinid="+pinid+"&typeid="+typeid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	</script>
	';
	}
	
	echo '<script>
		function getcountype(value,n){
			if(value==1){
				document.getElementById("spancount"+n).style.display="";
			}else{
				document.getElementById("spancount"+n).style.display="none";
			}
		}
	
		function showtypeabout(typeid){
			layerindex=layer.open({
				type: 2,
				title: "<div style=\'float:left;color:blue\'>'.$it618_video_lang['s1997'].'</div>",
				shadeClose: false,
				scrollbar: false,
				shade:  [0.5, "#393D49"],
				maxmin: false,
				area: ["830px", "330px"],
				content: "plugin.php?id=it618_video:sc_product_typeabout'.$adminsid.'&typeid="+typeid,
				cancel: function(index, layero){ 
					location.reload();
				}    
			});
		}
		
		function showkm(typeid){
			layerindex=layer.open({
				type: 2,
				title: "<div style=\'float:left;color:blue\'>'.$it618_video_lang['s2029'].'</div>",
				shadeClose: false,
				scrollbar: false,
				shade:  [0.5, "#393D49"],
				maxmin: false,
				area: ["100%", "100%"],
				content: "plugin.php?id=it618_video:sc_product_type_km'.$adminsid.'&typeid="+typeid,
				cancel: function(index, layero){ 
					location.reload();
				}    
			});
		}
		
		function showkmuse(typeid){
			layerindex=layer.open({
				type: 2,
				title: "<div style=\'float:left;color:blue\'>'.$it618_video_lang['s2030'].'</div>",
				shadeClose: false,
				scrollbar: false,
				shade:  [0.5, "#393D49"],
				maxmin: false,
				area: ["100%", "100%"],
				content: "plugin.php?id=it618_video:sc_salekm'.$adminsid.'&typeid="+typeid,
				cancel: function(index, layero){ 
	
				}    
			});
		}
	</script>
	';
	
	echo <<<EOT
	<script type="text/JavaScript">
	
	function getselect(obj,tmpn){
		if(obj.value==6){
			document.getElementById("time"+tmpn).style.display='none';
		}else{
			document.getElementById("time"+tmpn).style.display='';
		}
	}
	
	function getselect_add(obj,tmpn){
		if(obj.value==6){
			document.getElementById("time_add"+tmpn).style.display='none';
		}else{
			document.getElementById("time_add"+tmpn).style.display='';
		}
	}
	
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_time[]").length;
		
		return [
		[[1,''], 
		[1,'<input type="text" id="time_add'+n+'" class="txt" style="width:40px;margin-right:3px" name="newit618_time[]"><select name="newit618_timetype[]" onchange="getselect_add(this,'+n+')">$tmpoptionstr</select>'],
		[1,'<input type="text" class="txt" style="width:60px;margin-right:3px" name="newit618_saleprice[]">$s125 + <input type="text" class="txt" style="width:60px;color:red;margin-right:3px" name="newit618_score[]">$tmpjftype'],
		[1,'<input type="text" class="txt" style="width:60px" name="newit618_price[]">$s1661'],
		[1,''], 
		[1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$it618_video_lang['s831'].'</a></div></td></tr>';
	
    echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallC240" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallC240">'.$it618_video_lang['s591'].'</label></td><td colspan="15"><div class="fixsel"><input type="submit" class="btn" name="it618submit" onclick="return checkvalue()" value="'.$it618_video_lang['s592'].'" /></div></td></tr>';

require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>