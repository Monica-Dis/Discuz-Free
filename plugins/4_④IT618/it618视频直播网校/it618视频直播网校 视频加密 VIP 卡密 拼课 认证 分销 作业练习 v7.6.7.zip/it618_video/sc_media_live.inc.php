<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$ppp = 10;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$urlsql='&key='.$_GET['key'].'&class_id='.$_GET['class_id'];

if(submitcheck('it618submit_edit')){
	$ok=0;
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			C::t('#it618_video#it618_video_media_live')->update($id,array(
				'it618_class_id' => $_GET['it618_class_id'][$id]
			));
	
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_video_getlang('s345').$ok, "plugin.php?id=it618_video:sc_media_live$adminsid&page=$page".$urlsql, 'succeed');
}

$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_media_liveclass')." where it618_shopid=$ShopId ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

$tmp1=str_replace('<option value='.$_GET['class_id'].'>','<option value='.$_GET['class_id'].' selected="selected">',$tmp);

it618_showformheader("plugin.php?id=it618_video:sc_media_live$adminsid&page=$page".$urlsql);
showtableheaders($it618_video_lang['s1278'],'it618_video_sum');
	echo '<tr><td colspan=14>'.it618_video_getlang('s97').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:300px" /> '.it618_video_getlang('s848').' <select name="class_id"><option value=0>'.it618_video_getlang('s102').'</option>'.$tmp1.'</select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_video_getlang('s350').'" /></td></tr>';
	
	$count = C::t('#it618_video#it618_video_media_live')->count_by_search($it618sql,'',$ShopId,$_GET['class_id'],$_GET['key']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_video:sc_media_live$adminsid".$urlsql);
	
	echo '<tr><td colspan=14>'.it618_video_getlang('s850').$count.'<span style="float:right;color:red">'.$it618_video_lang['s1480'].'</span></td></tr>';
	showsubtitle(array('',it618_video_getlang('s231'),it618_video_getlang('s232'),it618_video_getlang('s1324')));

	$n=1;
	foreach(C::t('#it618_video#it618_video_media_live')->fetch_all_by_search(
		$it618sql,$it618orderby,$ShopId,$_GET['class_id'],$_GET['key'],$startlimit,$ppp
	) as $it618_video_media_live) {

		$tmp1=str_replace('<option value='.$it618_video_media_live['it618_aclass_id'].'>','<option value='.$it618_video_media_live['it618_aclass_id'].' selected="selected">',$tmp);
		
		$it618_size='';
		if($it618_video_media_live['it618_size']>0){
			$it618_size=round(($it618_video_media_live['it618_size']/1024/1024),2).'MB';
		}
		
		if($it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_url($it618_video_media_live['it618_url'])){
			$lessonurl=it618_video_getrewrite('video_lesson',$it618_video_goods_video['id'],'plugin.php?id=it618_video:lesson&lid='.$it618_video_goods_video['id']);
			$it618_name='<a href="'.$lessonurl.'" target="_blank">'.$it618_video_media_live['it618_name'].'</a>';
		}else{
			$it618_name=$it618_video_media_live['it618_name'];
		}

		showtablerow('', array('', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_video_media_live['id'].'"><label for="chk_del'.$n.'">'.$it618_video_media_live['id'].'</label>',
			'<select id="class'.$n.'" name="it618_class_id['.$it618_video_media_live['id'].']" style="margin-bottom:4px">'.$tmp1.'</select>',
			$it618_name,
			$it618_video_media_live['it618_time1'].$it618_video_lang['s397'].$it618_video_media_live['it618_time2'].$it618_video_lang['s398'].$it618_video_media_live['it618_time3'].$it618_video_lang['s400'].' '.$it618_size.' <font color=#999>'.date('Y-m-d H:i:s', $it618_video_media_live['it618_time']).'</font>'
		));
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_video_getlang('s129').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><select onchange="mediaclass(this)">'.$tmp.'</select><input type="submit" class="btn" name="it618submit_edit" value="'.it618_video_getlang('s851').'"/><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/

echo '
<script type="text/javascript">
  function mediaclass(obj){
	  for(var i=1;i<'.$n.';i++){
		  document.getElementById("class"+i).selectedIndex = obj.selectedIndex;
	  }
  }
  
  function check_all(obj,id){
	  for(var i=1;i<'.$n.';i++){
		  document.getElementById(id+""+i).checked = obj.checked;
	  }
  }
</script>';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>