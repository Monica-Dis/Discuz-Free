<?php
include_once 'aliyun-php-sdk-core/AcsRequest.php';
include_once 'aliyun-php-sdk-core/AcsResponse.php';
include_once 'aliyun-php-sdk-core/RoaAcsRequest.php';
include_once 'aliyun-php-sdk-core/RpcAcsRequest.php';
include_once 'aliyun-php-sdk-core/IAcsClient.php';
include_once 'aliyun-php-sdk-core/DefaultAcsClient.php';

include_once 'aliyun-php-sdk-core/Exception/ClientException.php';
include_once 'aliyun-php-sdk-core/Exception/ServerException.php';

include_once 'aliyun-php-sdk-core/Auth/Credential.php';
include_once 'aliyun-php-sdk-core/Auth/ISigner.php';
include_once 'aliyun-php-sdk-core/Auth/ShaHmac1Signer.php';
include_once 'aliyun-php-sdk-core/Auth/ShaHmac256Signer.php';

include_once 'aliyun-php-sdk-core/Regions/ProductDomain.php';
include_once 'aliyun-php-sdk-core/Regions/LocationService.php';
include_once 'aliyun-php-sdk-core/Regions/EndpointProvider.php';
include_once 'aliyun-php-sdk-core/Regions/EndpointProvider.php';
include_once 'aliyun-php-sdk-core/Regions/Endpoint.php';
include_once 'aliyun-php-sdk-core/Regions/EndpointConfig.php';

include_once 'aliyun-php-sdk-core/Profile/IClientProfile.php';
include_once 'aliyun-php-sdk-core/Profile/DefaultProfile.php';

include_once 'aliyun-php-sdk-core/Http/HttpHelper.php';
include_once 'aliyun-php-sdk-core/Http/HttpResponse.php';

include_once 'aliyun-php-sdk-mts/Mts/Request/V20140618/QueryMediaListByURLRequest.php';
include_once 'aliyun-php-sdk-mts/Mts/Request/V20140618/UpdateMediaPublishStateRequest.php';
include_once 'aliyun-php-sdk-mts/Mts/Request/V20140618/DeleteMediaRequest.php';

date_default_timezone_set('PRC');

//config http proxy
define('ENABLE_HTTP_PROXY', false);
define('HTTP_PROXY_IP', '127.0.0.1');
define('HTTP_PROXY_PORT', '8888');

	
function encodeByRFC3986($arg_1){
	$encodeOssObject="";
	$arraylist = explode("/", $arg_1);
	for($i = 0; $i < count($arraylist); $i++)
	{
		$tmp = rawurlencode($arraylist[$i]);
		$encodeOssObject = $encodeOssObject.$tmp;
		if ($i !== count($arraylist) -1) {
			$encodeOssObject = $encodeOssObject."/";
		}
	}
	return $encodeOssObject;
}

function object_array($array) {  
    if(is_object($array)) {  
        $array = (array)$array;  
     } if(is_array($array)) {  
         foreach($array as $key=>$value) {  
             $array[$key] = object_array($value);  
             }  
     }  
     return $array;  
}
?>