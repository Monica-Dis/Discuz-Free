<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_video = $_G['cache']['plugin']['it618_video'];
require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

$it618_video_play_pj=C::t('#it618_video#it618_video_play_pj')->fetch_by_id($_GET['playpjid']);
$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_play_pj['it618_pid']);
$pjname=C::t('#it618_video#it618_video_class1')->fetch_it618_pj_by_id($it618_video_goods['it618_class1_id']);
$pjname=explode("_",$pjname);

$tmpstr1=$it618_video_lang['t288'];
if($it618_video_play_pj['it618_score1']>0){
	$tmpstr=$it618_video_lang['s786'];
	$tmpstr1=$it618_video_lang['t339'];
	if($_GET['wap']==1){
		$tmpstr2='document.getElementById("score1").options['.$it618_video_play_pj['it618_score1'].'].selected = true;
				  document.getElementById("score2").options['.$it618_video_play_pj['it618_score2'].'].selected = true;
				  document.getElementById("score3").options['.$it618_video_play_pj['it618_score3'].'].selected = true;
				  document.getElementById("score4").options['.$it618_video_play_pj['it618_score4'].'].selected = true;';
	}else{
		$tmpstr2='IT618_VIDEO(\'.sp_a\').children().eq('.($it618_video_play_pj['it618_score1']-1).').click();
				  IT618_VIDEO(\'.sp_b\').children().eq('.($it618_video_play_pj['it618_score2']-1).').click();
				  IT618_VIDEO(\'.sp_c\').children().eq('.($it618_video_play_pj['it618_score3']-1).').click();
				  IT618_VIDEO(\'.sp_d\').children().eq('.($it618_video_play_pj['it618_score4']-1).').click();';
	}
}

$it618_video_play_pj['it618_content']=str_replace("[br]","\n",$it618_video_play_pj['it618_content']);

$pname=$it618_video_goods['it618_name'];

$_G['mobiletpl'][2]='/';
include template('it618_video:playpj');
?>