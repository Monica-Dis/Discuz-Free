<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$osstype=intval($_GET['osstype']);

if($osstype==0){
	$lang_s566=$it618_video_lang['s566'];
	$lang_s563=$it618_video_lang['s563'];
	$lang_s564=$it618_video_lang['s564'];
	$lang_t28=$it618_video_lang['t28'];
}
if($osstype==1){
	$lang_s566=$it618_video_lang['s1197'];
	$lang_s563=$it618_video_lang['s1194'];
	$lang_s564=$it618_video_lang['s1195'];
	$lang_t28=$it618_video_lang['s1196'];
}
if($osstype==2){
	$lang_s566=$it618_video_lang['s2015'];
	$lang_s563=$it618_video_lang['s2013'];
	$lang_s564=$it618_video_lang['s2014'];
	$lang_t28=$it618_video_lang['s2016'];
}

$query = DB::query("SELECT w.* FROM ".DB::table('it618_video_media_aoss')." w join ".DB::table('it618_video_media_shopaoss')." s on w.id=s.it618_aoss_id and s.it618_shopid=$ShopId where w.it618_isok=1 and w.it618_osstype=$osstype ORDER BY w.it618_order");
while($it618_video_media_aoss = DB::fetch($query)) {
	
	$count = C::t('#it618_video#it618_video_media_audio')->count_by_search('it618_aoss_id='.$it618_video_media_aoss['id'],'',$ShopId);
	$sumsize = C::t('#it618_video#it618_video_media_audio')->sum_size_by_search('it618_aoss_id='.$it618_video_media_aoss['id'],'',$ShopId);
	
	$aossstr.='<tr class="hover">
			<td width="180"><font color="green"><b>'.$it618_video_media_aoss['it618_name'].'</b></font></td>
			<td style="color:#888">'.$it618_video_media_aoss['it618_about'].'<br><br>'.$lang_s563.'<font color="red">'.$it618_video_media_aoss['it618_size'].'M</font><br>'.$lang_s564.'<font color="green">'.$it618_video_media_aoss['it618_type'].'</font><br><br><a href="plugin.php?id=it618_video:sc_media_audio_add'.$adminsid.'&osstype='.$osstype.'&oid='.$it618_video_media_aoss['id'].'" style="background-color:#0AF;color:#fff;padding:6px 15px;">'.$lang_t28.'</a><br><br></td>
			<td width="40"></td>
			<td style="color:#999" width="150">'.$it618_video_lang['s447'].$count.'<br>'.$it618_video_lang['s448'].round(($sumsize/1024/1024),2).'M</td>
			</tr>
			';
}

if($aossstr=='')$aossstr='<tr><td colspan="15" style="color:red;font-size:18px">'.$it618_video_lang['s1203'].'</td></tr>';

echo '<table class="tb tb2" style="clear: both;margin-top: 5px;width:100%;">
<tr><th colspan="15" class="partition">'.$lang_s566.'</th></tr>
<tr class="header"><th>'.$it618_video_lang['s445'].'</th><th>'.$it618_video_lang['s446'].'</th><th></th><th>'.$it618_video_lang['s674'].'</th></tr>
'.$aossstr.'
</table>';

require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>