<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_video = $_G['cache']['plugin']['it618_video'];
require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

$pid=intval($_GET['pid']);
$lid=intval($_GET['lid']);
$vid=intval($_GET['vid']);
$typeid=intval($_GET['typeid']);

if($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid)){
	$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
	if($it618_video_shop['it618_state']!=2||$it618_video_shop['it618_htstate']!=1){
		echo it618_video_getlang('s470');exit;
	}
	if($it618_video_shop['it618_uid']==$_G['uid']){
		$isshop=1;
	}
}

if($isshop!=1){
	if(!($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id_state($pid,1))){
		echo it618_video_getlang('s470');exit;
	}else{
		if(!it618_video_issecretok($it618_video_goods)){
			echo it618_video_getlang('s470');exit;
		}
	}
}

if($it618_video_shop['it618_issale']!=1){
	echo it618_video_getlang('s470');exit;
}

$goodspic=it618_video_getgoodspic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig'],0);

$goodsabout=it618_video_getgoodsabout($pid,$lid,$vid);

$videopower=it618_video_getpower($_G['uid'],$pid,$lid,$vid);
if($videopower['state']!=0)$powertimeabout=$videopower['time'];

if($it618_video_shop['it618_issale']==1){
	$sd_userpower=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('sd_userpower');
	$sd_userpower=explode(",",$sd_userpower);
	if(in_array($_G['uid'],$sd_userpower)&&$_G['uid']>0){
		$sdbtn='onclick="salesd()"';
	}
}

$goodstypeid=0;
$goodstypename='';
$goodstypename1='';
$n=0;

if($it618_video_shop['it618_issale']==1){
	$n=0;$typeaboutcss='none';
	foreach(C::t('#it618_video#it618_video_goods_type')->fetch_all_by_it618_pid_lid_vid($pid,$lid,$vid) as $it618_video_goods_type) {
		$tmpstr='';
		if($n==0){
			$tmpstr='class="current"';
			$goodstypeid=$it618_video_goods_type['id'];
			$it618_price=$it618_video_goods_type['it618_price'];
			
			$it618_typeabout=$it618_video_goods_type['it618_typeabout'];
			if($it618_typeabout!='')$typeaboutcss='';
			
			$goodspricestr=it618_video_getgoodsprice($it618_video_goods_type,'vipzk');
			$it618_price=$it618_video_goods_type['it618_price'];
			
			if($it618_video_goods_type['it618_counttype']==1){
				$tmpcount='<font color=#999>'.$it618_video_lang['s1067'].' <font style="color:red">'.$it618_video_goods_type['it618_count'].'</font></font>';
				
				if($it618_video_goods_type['it618_xgcount']>0){
					if($it618_video_goods_type['it618_xgtime']>0){
						$tmpxgstr='<font color=#999>('.$it618_video_lang['t24'].$it618_video_goods_type['it618_xgtime'].$it618_video_lang['t25'].$it618_video_goods_type['it618_xgcount'].$it618_video_lang['t57'].')</font>';
					}else{
						$tmpxgstr='<font color=#999>('.$it618_video_lang['t71'].$it618_video_goods_type['it618_xgcount'].$it618_video_lang['t57'].')</font>';
					}
				}
			}
		}
		
		if($it618_video_goods_type['it618_timetype']==1)$it618_name1=$it618_video_goods_type['it618_time'].$it618_video_lang['s1144'];
		if($it618_video_goods_type['it618_timetype']==2)$it618_name1=$it618_video_goods_type['it618_time'].$it618_video_lang['s1145'];
		if($it618_video_goods_type['it618_timetype']==3)$it618_name1=$it618_video_goods_type['it618_time'].$it618_video_lang['s1146'];
		if($it618_video_goods_type['it618_timetype']==4)$it618_name1=$it618_video_goods_type['it618_time'].$it618_video_lang['s1147'];
		if($it618_video_goods_type['it618_timetype']==5)$it618_name1=$it618_video_goods_type['it618_time'].$it618_video_lang['s1148'];
		if($it618_video_goods_type['it618_timetype']==6)$it618_name1=$it618_video_lang['s1153'];
		
		if($it618_video_goods_type['it618_typename']!='')$it618_name1=$it618_video_goods_type['it618_typename'];
		
		if($typeid==$it618_video_goods_type['id']){
			$tmpjs='setselect(\'goodstype\','.$n.',\''.$it618_video_goods_type['id'].'\');';	
		}
		
		$goodstypestr.='<a '.$tmpstr.' href="javascript:void(0)" onclick="setselect(\'goodstype\','.$n.',\''.$it618_video_goods_type['id'].'\')" name="goodstype"><span>'.$it618_name1.'</span><i></i></a><span id="typeabout'.$n.'" style="display:none">'.$it618_video_goods_type['it618_typeabout'].'</span>';
		$n=$n+1;
	}
}

if($goodstypeid==0){
	if($lid==0&&$vid==0){
		$goodspricestr=it618_video_getgoodsprice($it618_video_goods,'vipzk');
		$it618_price=$it618_video_goods['it618_price'];
	}
	
	if($lid>0&&$vid==0){
		$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
		$goodspricestr=it618_video_getgoodsprice($it618_video_goods_lesson,'vipzk');
		$it618_price=$it618_video_goods_lesson['it618_price'];
	}
	
	if($lid>0&&$vid>0){
		$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($vid);
		$goodspricestr=it618_video_getgoodsprice($it618_video_goods_video,'vipzk');
		$it618_price=$it618_video_goods_video['it618_price'];
	}
}

if($IsGroup==1&&$lid==0&&$vid==0){
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_group')." where it618_video_pids!=''");
	while($it618_group_group =	DB::fetch($query)) {
		$videopids=explode(",",$it618_group_group['it618_video_pids']);
		if(in_array($pid, $videopids)){
			$grouptitlestr.='<img src="'.$it618_group_group['it618_ico'].'" style="height:16px;margin-right:3px;vertical-align:middle;margin-top:-3px">'.DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_group['it618_groupid']).' ';
		}
	}
}

$_G['mobiletpl'][2]='/';
if($_GET['wap']==1){
	include template('it618_video:showpay_wap');
}else{
	include template('it618_video:showpay');
}
?>