<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$typeid=intval($_GET['typeid']);

$it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($typeid);

$pid=$it618_video_goods_type['it618_pid'];
$lid=$it618_video_goods_type['it618_lid'];
$vid=$it618_video_goods_type['it618_vid'];

$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);

$tmpname=$it618_video_goods['it618_name'];

if($lid>0){
	$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
	$tmpname.=' -> '.$it618_video_goods_lesson['it618_name'];
}

if($vid>0){
	$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($vid);
	$tmpname.=' -> '.$it618_video_goods_video['it618_name'];
}

if($it618_video_goods_type['it618_timetype']==1)$it618_name=$it618_video_goods_type['it618_time'].$it618_video_lang['s1144'];
if($it618_video_goods_type['it618_timetype']==2)$it618_name=$it618_video_goods_type['it618_time'].$it618_video_lang['s1145'];
if($it618_video_goods_type['it618_timetype']==3)$it618_name=$it618_video_goods_type['it618_time'].$it618_video_lang['s1146'];
if($it618_video_goods_type['it618_timetype']==4)$it618_name=$it618_video_goods_type['it618_time'].$it618_video_lang['s1147'];
if($it618_video_goods_type['it618_timetype']==5)$it618_name=$it618_video_goods_type['it618_time'].$it618_video_lang['s1148'];
if($it618_video_goods_type['it618_timetype']==6)$it618_name=$it618_video_lang['s1153'];

if(submitcheck('it618submit')){
	C::t('#it618_video#it618_video_goods_type')->update($typeid,array(
		'it618_typeabout' => $_GET['it618_typeabout']
	));

	echo '<script>parent.location.reload();parent.layer.closeAll();</script>';
}

it618_showformheader("plugin.php?id=it618_video:sc_product_typeabout$adminsid&typeid=$typeid");
showtableheaders($tmpname.' '.$it618_name,'sc_product_typeabout');

echo '
<tr><td><textarea name="it618_typeabout" style="width:580px;height:80px;">'.$it618_video_goods_type['it618_typeabout'].'</textarea></td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_video_getlang('s1970').'" /></div></td></tr>';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>