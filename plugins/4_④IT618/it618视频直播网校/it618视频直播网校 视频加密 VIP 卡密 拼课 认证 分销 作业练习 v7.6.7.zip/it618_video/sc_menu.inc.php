<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_default.func.php';

if($IsUnion==1){	
	require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
	$union_home=it618_union_getrewrite('union_home','','plugin.php?id=it618_union:index');
}

$m3u8osscount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_video_media_wmf')." w join ".DB::table('it618_video_media_shopwmf')." s on w.id=s.it618_wmf_id and s.it618_shopid=$ShopId where w.it618_isok=1");
			
$mp4osscount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_video_media_aoss')." w join ".DB::table('it618_video_media_shopaoss')." s on w.id=s.it618_aoss_id and s.it618_shopid=$ShopId where w.it618_isok=1 and w.it618_osstype=1");

$audioosscount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_video_media_aoss')." w join ".DB::table('it618_video_media_shopaoss')." s on w.id=s.it618_aoss_id and s.it618_shopid=$ShopId where w.it618_isok=1 and w.it618_osstype=0");

$livesetcount = DB::query("SELECT count(1) FROM ".DB::table('it618_video_liveset')." w join ".DB::table('it618_video_shopliveset')." s on w.id=s.it618_liveset_id and s.it618_shopid=$ShopId where w.it618_isok=1");

$_G['mobiletpl'][2]='/';
include template('it618_video:sc/sc_menu');
?>