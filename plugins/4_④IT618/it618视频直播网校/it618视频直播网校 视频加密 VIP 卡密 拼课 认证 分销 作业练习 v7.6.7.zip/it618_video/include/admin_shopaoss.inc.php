<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$sid=intval($_GET['sid']);
$preurl=$_GET['preurl'];
$urlsql='&sid='.$sid;
$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($sid);

if(submitcheck('it618submit')){
	
	C::t('#it618_video#it618_video_media_shopaoss')->delete_by_shopid($sid);
	
	foreach($_GET['delete'] as $key => $delid) {
		
		C::t('#it618_video#it618_video_media_shopaoss')->insert(array(
			'it618_shopid' => $sid,
			'it618_aoss_id' => $delid
		), true);
	}

	cpmsg($it618_video_lang['s16'], "action=plugins&identifier=$identifier&pmod=admin_shop&cp=admin_shopaoss&operation=$operation&do=$do&page=$page&preurl=$preurl".$urlsql, 'succeed');
}

if(count($reabc)!=11)return;

showformheader("plugins&findbtn=1&identifier=$identifier&pmod=admin_shop&cp=admin_shopaoss&operation=$operation&do=$do&page=$page&preurl=$preurl".$urlsql);
$preurl=str_replace("@","&",$preurl);
showtableheaders('<a href="'.$preurl.'">'.$it618_video_lang['s1765'].'<font color=red>'.$it618_video_lang['s514'].$it618_video_shop['it618_name'].$it618_video_lang['s515'].'</font></a> '.$it618_video_lang['s534'],'it618_video_media_aoss');
	
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_media_aoss'));
	echo '<tr><td colspan=15>'.$it618_video_lang['s555'].$count.'<span style="float:right;color:red">'.$it618_video_lang['s565'].'</span></td></tr>';
	showsubtitle(array($it618_video_lang['s865'],$it618_video_lang['s536'],$it618_video_lang['s867']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_media_aoss')." ORDER BY it618_order");
	while($it618_video_media_aoss = DB::fetch($query)) {

		if($it618_video_media_aoss['it618_isok']==1)$it618_isok='<font color="green"><b>'.$it618_video_lang['s1766'].'</b></font>';else $it618_isok="";
		
		$checked="";
		if(C::t('#it618_video#it618_video_media_shopaoss')->count_by_shopid_aossid($sid,$it618_video_media_aoss['id'])>0){
			$checked="checked=\"checked\"";
		}
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" id=\"id".$it618_video_media_aoss['id']."\" name=\"delete[]\" $checked value=\"".$it618_video_media_aoss['id']."\">",
			"<label for=\"id".$it618_video_media_aoss['id']."\">".'<b>'.$it618_video_media_aoss['it618_name'].'</b> <span style="color:#888">'.$it618_video_media_aoss['it618_about'].' '.$it618_video_lang['s563'].'<font color="red">'.$it618_video_media_aoss['it618_size'].'M</font>'.$it618_video_lang['s573'].$it618_video_lang['s564'].'<font color="red">'.$it618_video_media_aoss['it618_type'].'</font></span>'."</label>",
			$it618_isok
		));
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_video_lang['s129'].'</label></td><td colspan="15"><input type="submit" class="btn" name="it618submit" value="'.$it618_video_lang['s23'].'"/></td></tr>';
showtablefooter(); /*dis'.'m.tao'.'bao.com*/
?>