<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$player_httptime=trim($_GET['player_httptime']);
		if($player_httptime>30){
			$player_httptime=30;
		}
		
		if($player_httptime<1){
			$player_httptime=1;
		}
		
		$fileData = '$player_version=\''.trim($_GET['player_version'])."';\n";
		$fileData .= '$player_typeagent=\''.trim($_GET['player_typeagent'])."';\n";
		$fileData .= '$player_httptime=\''.$player_httptime."';\n";
		$fileData .= '$player_ischat=\''.trim($_GET['player_ischat'])."';\n";
		$fileData .= '$player_ismemory=\''.trim($_GET['player_ismemory'])."';\n";
		$fileData .= '$player_memorytime=\''.trim($_GET['player_memorytime'])."';\n";
		$fileData .= '$player_memorydo=\''.trim($_GET['player_memorydo'])."';\n";
		$fileData .= '$player_isrotate=\''.trim($_GET['player_isrotate'])."';\n";
		$fileData .= '$player_ismarquee=\''.trim($_GET['player_ismarquee'])."';\n";
		$fileData .= '$player_ismarqueewap=\''.trim($_GET['player_ismarqueewap'])."';\n";
		$fileData .= '$player_marqueetime=\''.trim($_GET['player_marqueetime'])."';\n";
		$fileData .= '$player_marquee=\''.str_replace("'","\'",trim($_GET['player_marquee']))."';\n";
		$fileData .= '$player_browsermode=\''.trim($_GET['player_browsermode'])."';\n";
		$fileData .= '$player_browseragent2=\''.trim($_GET['player_browseragent2'])."';\n";
		$fileData .= '$player_browseragent3=\''.trim($_GET['player_browseragent3'])."';\n";
		$fileData .= '$player_browserabout=\''.trim($_GET['player_browserabout'])."';\n";
		$fileData .= '$player_browseruid=\''.intval($_GET['player_browseruid'])."';\n";
		$fileData .= '$player_wxgoodsids=\''.trim($_GET['player_wxgoodsids'])."';\n";
		$fileData .= '$player_wxvideoids=\''.trim($_GET['player_wxvideoids'])."';\n";
		$fileData .= '$player_wxabout=\''.trim($_GET['player_wxabout'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_video_lang['s1188'], "action=plugins&identifier=$identifier&cp=admin_player&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

$memorydo='<option value="1">'.$it618_video_lang['s1186'].'</option>
	<option value="2">'.$it618_video_lang['s1187'].'</option>';
$memorydo=str_replace('<option value="'.$player_memorydo.'"','<option value="'.$player_memorydo.'" selected="selected"',$memorydo);

$browsermode='<option value="1">'.$it618_video_lang['s1421'].'</option>
	<option value="2">'.$it618_video_lang['s1422'].'</option>
	<option value="3">'.$it618_video_lang['s1423'].'</option>';
$browsermode=str_replace('<option value="'.$player_browsermode.'"','<option value="'.$player_browsermode.'" selected="selected"',$browsermode);

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_player&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

if($player_ischat==1)$check_player_ischat='checked="checked"';else $check_player_ischat='';
if($player_ismemory==1)$check_player_ismemory='checked="checked"';else $check_player_ismemory='';
if($player_isrotate==1)$check_player_isrotate='checked="checked"';else $check_player_isrotate='';
if($player_ismarquee==1)$check_player_ismarquee='checked="checked"';else $check_player_ismarquee='';
if($player_ismarqueewap==1)$check_player_ismarqueewap='checked="checked"';else $check_player_ismarqueewap='';

if($player_httptime=='')$player_httptime='1.5';
$player_version=$it618_video_lang['playerversion'];

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$strtmptitle[$cp1].'</th></tr>
<tr class="header"><th width=180>'.$it618_video_lang['s937'].'</th><th>'.$it618_video_lang['s939'].'</th><th>'.$it618_video_lang['s938'].'</th></tr>

<tr class="hover" style="display:none">
<td>'.$it618_video_lang['s1833'].'</td><td class="longtxt"><input name="player_version" value="'.$player_version.'" style="width:80px" /></td>
<td>'.$it618_video_lang['s1834'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1502'].'</td><td class="longtxt"><input name="player_httptime" value="'.$player_httptime.'" style="width:80px" /> '.$it618_video_lang['s1189'].'</td>
<td>'.$it618_video_lang['s1503'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1835'].'</td><td class="longtxt"><input type="checkbox" name="player_ischat" value=1 '.$check_player_ischat.'></td>
<td>'.$it618_video_lang['s1836'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1181'].'</td><td class="longtxt"><input type="checkbox" name="player_ismemory" value=1 '.$check_player_ismemory.'></td>
<td>'.$it618_video_lang['s1182'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1183'].'</td><td class="longtxt"><input name="player_memorytime" value="'.$player_memorytime.'" style="width:80px" /> '.$it618_video_lang['s1189'].'</td>
<td>'.$it618_video_lang['s1184'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1185'].'</td><td class="longtxt">
<select name="player_memorydo">
	'.$memorydo.'
</select></td>
<td>
</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1573'].'</td><td class="longtxt"><input type="checkbox" name="player_isrotate" value=1 '.$check_player_isrotate.'></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s734'].'</td><td class="longtxt"><input type="checkbox" name="player_ismarquee" value=1 '.$check_player_ismarquee.'></td>
<td>'.$it618_video_lang['s735'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s733'].'</td><td class="longtxt"><input type="checkbox" name="player_ismarqueewap" value=1 '.$check_player_ismarqueewap.'></td>
<td>'.$it618_video_lang['s742'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1453'].'</td><td class="longtxt"><input name="player_marqueetime" value="'.$player_marqueetime.'" style="width:80px" /></td>
<td>'.$it618_video_lang['s1454'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s736'].'</td><td class="longtxt"><textarea name="player_marquee" style="width:400px;height:80px">'.$player_marquee.'</textarea></td>
<td>'.$it618_video_lang['s741'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1729'].'</td><td class="longtxt"><textarea name="player_typeagent" style="width:400px;height:80px">'.$player_typeagent.'</textarea></td>
<td>'.$it618_video_lang['s1730'].'</td>
</tr>

<tr class="hover">
<td colspan="3"><b>'.$it618_video_lang['s2130'].'</b></td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1417'].'</td><td class="longtxt"><select name="player_browsermode">
	'.$browsermode.'
</select></td>
<td>'.$it618_video_lang['s1414'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1413'].'</td><td class="longtxt"><textarea name="player_browseragent2" style="width:400px;height:50px">'.$player_browseragent2.'</textarea></td>
<td>'.$it618_video_lang['s1424'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1420'].'</td><td class="longtxt"><textarea name="player_browseragent3" style="width:400px;height:50px">'.$player_browseragent3.'</textarea></td>
<td>'.$it618_video_lang['s1425'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1415'].'</td><td class="longtxt"><textarea name="player_browserabout" style="width:400px;height:50px">'.$player_browserabout.'</textarea></td>
<td>'.$it618_video_lang['s1416'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1418'].'</td><td class="longtxt"><input name="player_browseruid" value="'.$player_browseruid.'" style="width:80px" /></td>
<td>'.$it618_video_lang['s1419'].'</td>
</tr>

<tr class="hover">
<td style="background-color:#f1f1f1"><b>'.$it618_video_lang['s779'].'</b></td><td colspan=2 style="background-color:#f1f1f1">'.$it618_video_lang['s1543'].'</td>
</tr>

<tr class="hover">
<td style="background-color:#f1f1f1">'.$it618_video_lang['s1544'].'</td><td class="longtxt"  style="background-color:#f1f1f1"><textarea name="player_wxgoodsids" style="width:400px;height:50px">'.$player_wxgoodsids.'</textarea></td>
<td style="background-color:#f1f1f1">'.$it618_video_lang['s1545'].'</td>
</tr>

<tr class="hover">
<td style="background-color:#f1f1f1">'.$it618_video_lang['s1546'].'</td><td class="longtxt"  style="background-color:#f1f1f1"><textarea name="player_wxvideoids" style="width:400px;height:50px">'.$player_wxvideoids.'</textarea></td>
<td style="background-color:#f1f1f1">'.$it618_video_lang['s1547'].'</td>
</tr>

<tr class="hover">
<td style="background-color:#f1f1f1">'.$it618_video_lang['s1548'].'</td><td class="longtxt"  style="background-color:#f1f1f1"><textarea name="player_wxabout" style="width:400px;height:50px">'.$player_wxabout.'</textarea></td>
<td style="background-color:#f1f1f1">'.$it618_video_lang['s1549'].'</td>
</tr>

</table>
';

showsubmit('it618submit', $it618_video_lang['s23']);

if(count($reabc)!=11)return;
showtablefooter(); /*dis'.'m.tao'.'bao.com*/

?>