<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

$pid=intval($_GET['pid']);
$preurl=$_GET['preurl'];
$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);

if(submitcheck('it618submit')){

	if(is_array($_GET['it618_groupid'])) {
		foreach($_GET['it618_groupid'] as $id => $val) {
			
				C::t('#it618_video#it618_video_goods_vipgroup')->update($id,array(
					'it618_isok' => $_GET['it618_isok'][$id],
				));
		}
	}

	cpmsg($it618_video_lang['s1537'], "action=plugins&identifier=$identifier&cp=admin_goodsvipgroup&pmod=admin_product&pid=$pid&operation=$operation&do=$do&page=$page&preurl=$preurl", 'succeed');
}

if(submitcheck('it618daosubmit')) {
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup'));
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_vipgroup')." WHERE it618_pid=$pid and it618_groupid=".$common_usergroup['groupid'])==0){
			C::t('#it618_video#it618_video_goods_vipgroup')->insert(array(
				'it618_pid' => $pid,
				'it618_groupid' => $common_usergroup['groupid'],
			), true);
		}
	}
	
	cpmsg($it618_video_lang['s1849'], "action=plugins&identifier=$identifier&cp=admin_goodsvipgroup&pmod=admin_product&pid=$pid&operation=$operation&do=$do&page=$page&preurl=$preurl", 'succeed');
}

if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_vipgroup')." where it618_pid=$pid")==0){
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup'));
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_vipgroup')." WHERE it618_pid=$pid and it618_groupid=".$common_usergroup['groupid'])==0){
			C::t('#it618_video#it618_video_goods_vipgroup')->insert(array(
				'it618_pid' => $pid,
				'it618_groupid' => $common_usergroup['groupid'],
			), true);
		}
	}	
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_goodsvipgroup&pmod=admin_product&pid=$pid&operation=$operation&do=$do&preurl=$preurl");

$preurlhref=str_replace("@","&",$preurl);
showtableheaders('<a href="'.$preurlhref.'">'.$it618_video_lang['s504'].'<font color=red>'.$it618_video_lang['s514'].$it618_video_goods['it618_name'].$it618_video_lang['s515'].'</font></a> '.$it618_video_lang['s1535'],'it618_video_goods_vipgroup');
	showsubmit('it618daosubmit', $it618_video_lang['s1846']);
	if($reabc[5]!='_')return;
	
	$groupcount=C::t('#it618_video#it618_video_goods_vipgroup')->count_by_pid($pid);
	
	echo '<tr><td colspan=10>'.$it618_video_lang['s1847'].$groupcount.'<span style="float:right;color:red">'.$it618_video_lang['s1536'].'</span></td></tr>';
	
	showsubtitle(array($it618_video_lang['s1845']));
	
	echo '<tr><td colspan=10><ul>';
	$query = DB::query("SELECT p.id,g.groupid,g.grouptitle,p.* FROM ".DB::table('it618_video_goods_vipgroup')." p,".DB::table('common_usergroup')." g WHERE p.it618_groupid=g.groupid and p.it618_pid=$pid");
	while($it618_video_goods_vipgroup =	DB::fetch($query)) {
		
		if($it618_video_goods_vipgroup['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
		
		echo '<li style="float:left;width:230px"><input type="hidden" name="it618_groupid['.$it618_video_goods_vipgroup['id'].']"><input type="checkbox" id="isok'.$it618_video_goods_vipgroup['id'].'" name="it618_isok['.$it618_video_goods_vipgroup['id'].']" style="vertical-align:middle" value="1" '.$it618_isok_checked.'><label for="isok'.$it618_video_goods_vipgroup['id'].'">'.$it618_video_goods_vipgroup['grouptitle'].'</label></li>';
	}
	echo '</ul></td></tr>';
	
	showsubmit('it618submit', $it618_video_lang['s592']);
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
?>