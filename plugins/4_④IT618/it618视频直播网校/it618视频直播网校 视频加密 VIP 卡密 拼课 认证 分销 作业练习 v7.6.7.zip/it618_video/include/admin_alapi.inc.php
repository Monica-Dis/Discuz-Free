<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(submitcheck('it618submit')){
	$accessid=trim($_GET['accessid']);
	$accesskey=trim($_GET['accesskey']);
	$livearea=trim($_GET['livearea']);
	$apphost=trim($_GET['apphost']);
	$appname=trim($_GET['appname']);
	
	$it618_ossbucket=$appname.'-video-out';
	$it618_ossendpoint='oss-cn-'.$livearea.'.aliyuncs.com';
	
	C::t('#it618_video#it618_video_liveset')->insert(array(
		'it618_name' => $it618_video_lang['s1739'],
		'it618_about' => $it618_video_lang['s1739'],
		'it618_sqtime' => 30,
		'it618_accessid' => $accessid,
		'it618_accesskey' => $accesskey,
		'it618_cdnkey' => $it618_video_lang['s1741'],
		'it618_pushcdnkey' => $it618_video_lang['s1741'],
		'it618_ossbucket' => $it618_ossbucket,
		'it618_ossendpoint' => $it618_ossendpoint,
		'it618_appname' => $appname,
		'it618_cnname' => 'cn-'.$livearea,
		'it618_domainname' => 'live.'.$apphost,
		'it618_pushdomainname' => 'push.'.$apphost,
		'it618_liveordertime' => 5,
		'it618_livetime' => 60,
		'it618_copytime' => 30,
		'it618_order' => 1
	), true);
	
	C::t('#it618_video#it618_video_liveset')->insert(array(
		'it618_name' => $it618_video_lang['s1740'],
		'it618_about' => $it618_video_lang['s1740'],
		'it618_sqtime' => 30,
		'it618_accessid' => $accessid,
		'it618_accesskey' => $accesskey,
		'it618_cdnkey' => $it618_video_lang['s1741'],
		'it618_pushcdnkey' => $it618_video_lang['s1741'],
		'it618_ossbucket' => '',
		'it618_ossendpoint' => '',
		'it618_appname' => $appname,
		'it618_cnname' => 'cn-'.$livearea,
		'it618_domainname' => 'live.'.$apphost,
		'it618_pushdomainname' => 'push.'.$apphost,
		'it618_liveordertime' => 5,
		'it618_livetime' => 60,
		'it618_copytime' => 30,
		'it618_order' => 2
	), true);
	
	
	C::t('#it618_video#it618_video_media_wmf')->insert(array(
		'it618_name' => $it618_video_lang['s1748'],
		'it618_about' => $it618_video_lang['s1748'],
		'it618_type' => '3gp,asf,avi,dat,dv,flv,f4v,gif,m2t,m4v,mj2,mjpeg,mkv,mov,mp4,mpe,mpg,mpeg,mts,ogg,qt,rm,rmvb,swf,ts,vob,wmv,webm',
		'it618_size' => 1000,
		'it618_accessid' => $accessid,
		'it618_accesskey' => $accesskey,
		'it618_endpoint' => $it618_ossendpoint,
		'it618_wmfpath' => $it618_video_lang['s1741'],
		'it618_order' => 1,
		'it618_isok' => 1
	), true);
	
	$it618_ossbucket=$appname.'-video-in';
	
	C::t('#it618_video#it618_video_media_aoss')->insert(array(
		'it618_osstype' => 0,
		'it618_name' => $it618_video_lang['s1746'],
		'it618_about' => $it618_video_lang['s1746'],
		'it618_type' => 'mp3,wav,m4a,ogg,oga,webma',
		'it618_size' => 1000,
		'it618_accessid' => $accessid,
		'it618_accesskey' => $accesskey,
		'it618_endpoint' => $it618_ossendpoint,
		'it618_bucket' => $it618_ossbucket,
		'it618_order' => 1,
		'it618_isok' => 1
	), true);
	
	$it618_ossbucket=$appname.'-video-in';
	
	C::t('#it618_video#it618_video_media_aoss')->insert(array(
		'it618_osstype' => 1,
		'it618_name' => $it618_video_lang['s1747'],
		'it618_about' => $it618_video_lang['s1747'],
		'it618_type' => 'mp4',
		'it618_size' => 1000,
		'it618_accessid' => $accessid,
		'it618_accesskey' => $accesskey,
		'it618_endpoint' => $it618_ossendpoint,
		'it618_bucket' => $it618_ossbucket,
		'it618_order' => 1,
		'it618_isok' => 1
	), true);
	
	$it618_ossbucket=$appname.'-video-in';
	
	C::t('#it618_video#it618_video_media_aoss')->insert(array(
		'it618_osstype' => 2,
		'it618_name' => $it618_video_lang['s2128'],
		'it618_about' => $it618_video_lang['s2128'],
		'it618_type' => 'rar,zip,pdf,doc,xls',
		'it618_size' => 1000,
		'it618_accessid' => $accessid,
		'it618_accesskey' => $accesskey,
		'it618_endpoint' => $it618_ossendpoint,
		'it618_bucket' => $it618_ossbucket,
		'it618_order' => 1,
		'it618_isok' => 1
	), true);
	
	$it618_ossurl=$appname.'-video-in.oss-cn-'.$livearea.'.aliyuncs.com';
	
	C::t('#it618_video#it618_video_cdn')->insert(array(
		'it618_cdnurl' => 'video-in.'.$apphost,
		'it618_ossurl' => $it618_ossurl,
		'it618_key' => $it618_video_lang['s1741'],
		'it618_time' => 1,
		'it618_ishttps' => 0,
		'it618_iskeyok' => 1,
		'it618_iscdnok' => 1,
	), true);
	
	$it618_ossurl=$appname.'-video-out.oss-cn-'.$livearea.'.aliyuncs.com';
	
	C::t('#it618_video#it618_video_cdn')->insert(array(
		'it618_cdnurl' => 'video-out.'.$apphost,
		'it618_ossurl' => $it618_ossurl,
		'it618_key' => $it618_video_lang['s1741'],
		'it618_time' => 1,
		'it618_ishttps' => 0,
		'it618_iskeyok' => 1,
		'it618_iscdnok' => 1,
	), true);

	cpmsg($it618_video_lang['s1751'], "action=plugins&identifier=$identifier&cp=admin_liveset&pmod=admin_live&operation=$operation&do=$do&page=$page", 'succeed');
}

$livearea='<option value="beijing">'.$it618_video_lang['s1735'].'</option>
	<option value="shanghai">'.$it618_video_lang['s2010'].'shanghai</option><option value="shenzhen">'.$it618_video_lang['s1737'].'</option>';

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_alapi&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$strtmptitle[$cp1].'</th></tr>
<tr><td colspan="15" style="line-height:23px">'.$it618_video_lang['s1734'].'</td></tr>
<tr class="header"><th width=180>'.$it618_video_lang['s937'].'</th><th>'.$it618_video_lang['s939'].'</th><th>'.$it618_video_lang['s938'].'</th></tr>

<tr class="hover">
<td>'.$it618_video_lang['s1732'].'</td><td class="longtxt"><input name="accessid" style="width:300px" /></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1733'].'</td><td class="longtxt"><input name="accesskey" style="width:300px" /></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1744'].'</td><td class="longtxt"><input name="apphost" style="width:300px" /></td>
<td>'.$it618_video_lang['s1745'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1742'].'</td><td class="longtxt"><input name="appname" style="width:300px" /></td>
<td>'.$it618_video_lang['s1743'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1738'].'</td><td class="longtxt">
<select name="livearea">
	'.$livearea.'
</select></td>
<td>
</td>
</tr>

</table>
';

echo '<tr><td colspan="15"><input type="submit" class="btn" name="it618submit" value="'.$it618_video_lang['s1749'].'" onclick="return confirm(\''.$it618_video_lang['s1750'].'\')"/></td></tr>';


if(count($reabc)!=11)return;
showtablefooter(); /*dis'.'m.tao'.'bao.com*/

?>