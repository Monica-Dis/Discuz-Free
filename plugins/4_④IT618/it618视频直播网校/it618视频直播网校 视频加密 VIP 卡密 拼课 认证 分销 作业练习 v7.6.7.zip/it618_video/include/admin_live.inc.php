<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

$it618sql = "1";

$state0='';$state1='';$state2='';$state3='';$state4='';
if($_GET['state']==0){$state0='selected="selected"';}
if($_GET['state']==1){$it618sql .= " and it618_btime >".$_G['timestamp'];$state1='selected="selected"';}
if($_GET['state']==2){$it618sql .= " and it618_btime <".$_G['timestamp']." and it618_etime>".$_G['timestamp'];$state2='selected="selected"';}
if($_GET['state']==3){$it618sql .= " and it618_etime <".$_G['timestamp'];$state3='selected="selected"';}
if($_GET['state']==4){$it618sql .= " and it618_isok=1 and it618_etime <".$_G['timestamp'];$state4='selected="selected"';}

$chkstate0='';$chkstate1='';$chkstate2='';$chkstate3='';
if($_GET['chkstate']==0){$chkstate0='selected="selected"';}
if($_GET['chkstate']==1){$it618sql .= " and it618_chkstate = 0";$chkstate1='selected="selected"';}
if($_GET['chkstate']==2){$it618sql .= " and it618_chkstate = 1";$chkstate2='selected="selected"';}
if($_GET['chkstate']==3){$it618sql .= " and it618_chkstate = 2";$chkstate3='selected="selected"';}

$urlsql='&key='.$_GET['key'].'&state='.$_GET['state'].'&chkstate='.$_GET['chkstate'];

if(submitcheck('it618submit_edit')){
	$ok=0;
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			C::t('#it618_video#it618_video_live')->update($id,array(
				'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
				'it618_description' => dhtmlspecialchars($_GET['it618_description'][$id]),
				'it618_savetype' => $_GET['it618_savetype'][$id],
				'it618_isuser' => $_GET['it618_isuser'][$id]
			));
			
			$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_liveid($id);
			C::t('#it618_video#it618_video_goods_video')->update($it618_video_goods_video['id'],array(
				'it618_isuser' => $_GET['it618_isuser'][$id]
			));
			
			if(dhtmlspecialchars($_GET['it618_m3u8url'][$id])!=''){
				C::t('#it618_video#it618_video_live')->update($id,array(
					'it618_m3u8url' => dhtmlspecialchars($_GET['it618_m3u8url'][$id])
				));
			}
	
			$ok=$ok+1;
		}
	}

	cpmsg(it618_video_getlang('s345').$ok, "action=plugins&identifier=$identifier&cp=admin_live&pmod=admin_live&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_pass')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($delid);

		if($it618_video_live['it618_chkstate']==0){
			$it618_video_liveset = C::t('#it618_video#it618_video_liveset')->fetch_by_id($it618_video_live['it618_liveset_id']);
			
			C::t('#it618_video#it618_video_live')->update($delid,array(
				'it618_streamname' => md5($it618_video_liveset['it618_accesskey'].$delid.FORMHASH)
			));
			
			$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($delid);
			
			if($it618_video_live['it618_liveset_id']>0){
				if($it618_video_live['it618_ossbucket']!=''&&$it618_video_live['it618_ossendpoint']!=''){
					$returnstr=it618_video_addliverecordconfig($it618_video_live);
					if($returnstr!=1){
						cpmsg($returnstr, "action=plugins&identifier=$identifier&cp=admin_live&pmod=admin_live&operation=$operation&do=$do&page=$page".$urlsql, 'error');
					}
				}
			}
			
			C::t('#it618_video#it618_video_goods_video')->insert(array(
				'it618_pid' => $it618_video_live['it618_pid'],
				'it618_lid' => $it618_video_live['it618_lid'],
				'it618_liveid' => $it618_video_live['id'],
				'it618_livebtime' => $it618_video_live['it618_btime'],
				'it618_isuser' => $it618_video_live['it618_isuser'],
				'it618_usercode' => $it618_video_live['it618_usercode'],
				'it618_ischat' => 1,
				'it618_islive' => 1
			), true);
			
			C::t('#it618_video#it618_video_live')->update($delid,array(
				'it618_chkstate' => 1
			));
			
			$ok=$ok+1;
		}
	}

	cpmsg($it618_video_lang['s1332'].$ok, "action=plugins&identifier=$identifier&cp=admin_live&pmod=admin_live&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_nopass')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($delid);
		if($it618_video_live['it618_chkstate']==0){
			DB::query("update ".DB::table('it618_video_live')." set it618_chkstate=2 where id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_video_lang['s1333'].$ok, "action=plugins&identifier=$identifier&cp=admin_live&pmod=admin_live&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_del')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($delid);
		
		if($it618_video_live['it618_etime']>$_G['timestamp']){
			DB::query("delete from ".DB::table('it618_video_live_order')." where it618_liveid=".$it618_video_live['id']);
			DB::query("delete from ".DB::table('it618_video_live')." where id=".$it618_video_live['id']);
			it618_video_deletegoodsvideo($it618_video_live['id'],'admindel');
			if($it618_video_live['it618_liveset_id']>0)it618_video_forbidlivestream($it618_video_live);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_video_lang['s1839'].$ok, "action=plugins&identifier=$identifier&cp=admin_live&pmod=admin_live&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_okdel')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($delid);
		
		if($it618_video_live['it618_isok']==1){
			DB::query("delete from ".DB::table('it618_video_live')." where id=".$it618_video_live['id']);
			DB::query("delete from ".DB::table('it618_video_live_order')." where it618_liveid=".$it618_video_live['id']);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_video_lang['s1839'].$ok, "action=plugins&identifier=$identifier&cp=admin_live&pmod=admin_live&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_okclear')){
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_live')." where it618_isok=1");
	while($it618_video_live = DB::fetch($query)) {
		DB::query("delete from ".DB::table('it618_video_live_order')." where it618_liveid=".$it618_video_live['id']);
	}
	DB::query("delete from ".DB::table('it618_video_live')." where it618_isok=1");

	cpmsg($it618_video_lang['s1855'], "action=plugins&identifier=$identifier&cp=admin_live&pmod=admin_live&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_edittime')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($delid);
	
		if($it618_video_live['it618_etime']-$_G['timestamp']>180){
			$dovalue=intval($_GET['dovalue']);
			if($_GET['dotype']==1){
				C::t('#it618_video#it618_video_live')->update($delid,array(
					'it618_etime' => $it618_video_live['it618_etime']+$dovalue*60,
					'it618_livetime' => $it618_video_live['it618_livetime']+$dovalue
				));
				$ok=$ok+1;
			}else{
				if($it618_video_live['it618_etime']-$_G['timestamp']-180>$dovalue*60){
					C::t('#it618_video#it618_video_live')->update($delid,array(
						'it618_etime' => $it618_video_live['it618_etime']-$dovalue*60,
						'it618_livetime' => $it618_video_live['it618_livetime']-$dovalue
					));
					$ok=$ok+1;
				}
			}
		}
	}

	cpmsg($it618_video_lang['s1489'].$ok, "action=plugins&identifier=$identifier&cp=admin_live&pmod=admin_live&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_edittime1')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($delid);
	
		if($it618_video_live['it618_btime']-$_G['timestamp']>180){
			$dovalue=intval($_GET['dovalue1']);
			if($_GET['dotype1']==1){
				C::t('#it618_video#it618_video_live')->update($delid,array(
					'it618_btime' => $it618_video_live['it618_btime']+$dovalue*60,
					'it618_etime' => $it618_video_live['it618_etime']+$dovalue*60
				));
				$ok=$ok+1;
			}else{
				if($it618_video_live['it618_btime']-$_G['timestamp']-180>$dovalue*60){
					C::t('#it618_video#it618_video_live')->update($delid,array(
						'it618_btime' => $it618_video_live['it618_btime']-$dovalue*60,
						'it618_etime' => $it618_video_live['it618_etime']-$dovalue*60
					));
					$ok=$ok+1;
				}
			}
		}
	}

	cpmsg($it618_video_lang['s1719'].$ok, "action=plugins&identifier=$identifier&cp=admin_live&pmod=admin_live&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=11)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_live&pmod=admin_live&operation=$operation&do=$do&page=$page".$urlsql);
showtableheaders($it618_video_lang['s1325'],'it618_video_live');

echo '<tr><td colspan=14>'.it618_video_getlang('s97').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:300px" /> '.it618_video_getlang('s1314').' <select name="state"><option value=0 '.$state0.'>'.it618_video_getlang('s102').'</option><option value=1 '.$state1.'>'.it618_video_getlang('s1350').'</option><option value=2 '.$state2.'>'.it618_video_getlang('s1317').'</option><option value=3 '.$state3.'>'.it618_video_getlang('s1728').'</option><option value=4 '.$state4.'>'.it618_video_getlang('s1318').'</option></select> '.it618_video_getlang('s1315').' <select name="chkstate"><option value=0 '.$chkstate0.'>'.it618_video_getlang('s102').'</option><option value=1 '.$chkstate1.'>'.it618_video_getlang('s677').'</option><option value=2 '.$chkstate2.'>'.it618_video_getlang('s678').'</option><option value=3 '.$chkstate3.'>'.it618_video_getlang('s679').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_video_getlang('s350').'" /></td></tr>';
	
	$count = C::t('#it618_video#it618_video_live')->count_by_search($it618sql,'',0,0,0,$_GET['key']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_live&pmod=admin_live&operation=$operation&do=$do&cp1=$cp1".$urlsql);
	
	echo '<tr><td colspan=14>'.it618_video_getlang('s1319').$count.'<span style="float:right;color:red">'.it618_video_getlang('s1326').'</span></td></tr>';
	showsubtitle(array('',it618_video_getlang('s1310'),it618_video_getlang('s1311'),it618_video_getlang('s1312'),$it618_video_lang['s1313'],$it618_video_lang['s1314'],$it618_video_lang['s1315']));
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/message.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_video/config/message.php';
	}
	
	if($it618_isok==1&&$it618_body_live_user_isok==1){
		$isliveorder=1;
	}
	
	$n=1;
	foreach(C::t('#it618_video#it618_video_live')->fetch_all_by_search(
		$it618sql,'id desc',0,0,0,$_GET['key'],$startlimit,$ppp
	) as $it618_video_live) {
		
		$it618_video_liveset = C::t('#it618_video#it618_video_liveset')->fetch_by_id($it618_video_live['it618_liveset_id']);
		
		if($it618_video_live['it618_isuser']==0){$it618_isuser_selected0='selected="selected"';$isusercolor='#390';$tmpuser=$it618_video_lang['s30'];}else $it618_isuser_selected0="";
		if($it618_video_live['it618_isuser']==1){$it618_isuser_selected1='selected="selected"';$isusercolor='#f30';$tmpuser=$it618_video_lang['s27'];}else $it618_isuser_selected1="";
		if($it618_video_live['it618_isuser']==2){$it618_isuser_selected2='selected="selected"';$isusercolor='#22b1fe';$tmpuser=$it618_video_lang['s28'];}else $it618_isuser_selected2="";
		
		$tmpnamestr='<input type="text" class="txt" style="width:313px;margin-bottom:4px" name="it618_name['.$it618_video_live['id'].']" value="'.$it618_video_live['it618_name'].'"><br><textarea name="it618_description['.$it618_video_live['id'].']" style="width:313px;height:50px;">'.$it618_video_live['it618_description'].'</textarea>';
		$tmpuserstr='<select style="color:'.$isusercolor.'" name="it618_isuser['.$it618_video_live['id'].']"><option value=1 '.$it618_isuser_selected1.' style="color:#f30">'.$it618_video_lang['s27'].'</option><option value=2 '.$it618_isuser_selected2.' style="color:#22b1fe">'.$it618_video_lang['s28'].'</option><option value=0 '.$it618_isuser_selected0.' style="color:#390">'.$it618_video_lang['s30'].'</option></select>';
		
		if($it618_video_live['it618_chkstate']==0){
			$it618_chkstate='<font color=red>'.$it618_video_lang['s677'].'</font>';
			if($_G['timestamp']>$it618_video_live['it618_etime']){
				DB::delete('it618_video_live', "id=".$it618_video_live['id']);
			}
		}
		
		$it618_state='';
		if($it618_video_live['it618_chkstate']==1){
			$it618_chkstate='<font color=green>'.$it618_video_lang['s678'].'</font>';
			
			if($it618_video_live['it618_btime']>$_G['timestamp']){
				if($isliveorder==1){
					$ordercount=C::t('#it618_video#it618_video_live_order')->count_by_liveid($it618_video_live['id']);
					$liveorder='<br><br>'.$it618_video_lang['s1856'].$ordercount;
				}
				$it618_state='<font color=red>'.it618_video_gettime1($it618_video_live['it618_btime']).$it618_video_lang['s1316'].'</font>'.$liveorder;
			}
			
			if($it618_video_live['it618_btime']<$_G['timestamp']&&$_G['timestamp']<$it618_video_live['it618_etime']){
				$tmptime=round(($it618_video_live['it618_etime']-$_G['timestamp'])/60,2);
				$it618_video_lang['s1720']=str_replace("{time}",$tmptime,$it618_video_lang['s1720']);
				$it618_state='<font color=green>'.$it618_video_lang['s1317'].'</font><br><br>'.$it618_video_lang['s1720'];
			}
			
			if($_G['timestamp']>$it618_video_live['it618_etime']){
				if($it618_video_live['it618_isok']==1){
					$it618_state='<font color=#999>'.$it618_video_lang['s1318'].'</font>';
				}else{
					$it618_state='<font color=#fof>'.$it618_video_lang['s1728'].'</font>';
				}
				$tmpnamestr='<div style="width:313px;line-height:18px">'.$it618_video_live['it618_name'].'<br>'.$it618_video_live['it618_description'].'</div>';
				$tmpuserstr=$tmpuser;
			}
		}
		
		$m3u8url='';$tmpsavetypestr='';
		if($it618_video_live['it618_etime']>$_G['timestamp']){
			if($it618_video_live['it618_liveset_id']==0){
				$m3u8url='<br><br>'.$it618_video_lang['s1501'].'<br><textarea name="it618_m3u8url['.$it618_video_live['id'].']" style="width:313px;height:50px;margin-top:3px">'.$it618_video_live['it618_m3u8url'].'</textarea>';
			}
			
			if($it618_video_live['it618_liveset_id']==0||($it618_video_live['it618_ossbucket']==''&&$it618_video_live['it618_ossendpoint']=='')){
				if($it618_video_live['it618_savetype']==1)$it618_savetype_selected1='selected="selected"';else $it618_savetype_selected1="";
				if($it618_video_live['it618_savetype']==2)$it618_savetype_selected2='selected="selected"';else $it618_savetype_selected2="";
				if($it618_video_live['it618_savetype']==3)$it618_savetype_selected3='selected="selected"';else $it618_savetype_selected3="";
				
				$tmpsavetypestr='<br><select name="it618_savetype['.$it618_video_live['id'].']"><option value=1 '.$it618_savetype_selected1.'>'.$it618_video_lang['s1611'].'</option><option value=2 '.$it618_savetype_selected2.'>'.$it618_video_lang['s1612'].'</option><option value=3 '.$it618_savetype_selected3.'>'.$it618_video_lang['s1613'].'</option></select>';
			}
		}
		
		if($it618_video_live['it618_chkstate']==2){
			$it618_chkstate='<font color=blue>'.$it618_video_lang['s679'].'</font>';
		}
		
		$it618_video_goods_lesson=C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($it618_video_live['it618_lid']);
		$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_live['it618_pid']);
		$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_live['it618_shopid']);
		$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_liveid($it618_video_live['id']);
		$liveurl='';
		if($it618_video_goods_video['id']>0){
			$tmpurl=it618_video_getrewrite('video_lesson',$it618_video_goods_video['id'],'plugin.php?id=it618_video:lesson&lid='.$it618_video_goods_video['id']);
			$liveurl='<a href="'.$tmpurl.'" target="_blank">'.$it618_video_lang['s746'].'</a>';
		}
		
		if($it618_video_live['it618_ossbucket']!=''&&$it618_video_live['it618_ossendpoint']!=''){
			$livesetstr='<font color=#f60>'.$it618_video_lang['s1302'].$it618_video_live['it618_livetime'].$it618_video_lang['s1305'].'</font> <font color=green>'.$it618_video_lang['s1272'].'</font>';
		}else{
			$livesetstr='<font color=#f60>'.$it618_video_lang['s1302'].$it618_video_live['it618_livetime'].$it618_video_lang['s1305'].'</font> <font color=blue>'.$it618_video_lang['s1273'].'</font>';
		}

		showtablerow('', array('', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_video_live['id'].'"><label for="chk_del'.$n.'">'.$it618_video_live['id'].'</label>',
			$tmpnamestr.$m3u8url,
			'<div style="width:300px;line-height:18px">'.$it618_video_goods['it618_name'].'<br>'.$it618_video_goods_lesson['it618_name'].'<br>'.$liveurl.' <font color=#999>'.date('Y-m-d H:i:s', $it618_video_live['it618_time']).'</font><br>'.$it618_video_shop['it618_name'].'</div>',
			$it618_video_liveset['it618_name'].'<br>'.$livesetstr.'<br><font color=#999>'.date('Y-m-d H:i:s', $it618_video_live['it618_btime']).'<br>'.date('Y-m-d H:i:s', $it618_video_live['it618_etime']).'</font>'.$tmpsavetypestr,
			$tmpuserstr,
			$it618_state,
			$it618_chkstate
		));
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_video_getlang('s129').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_edit" value="'.it618_video_getlang('s1322').'"/> <input type="submit" class="btn" onclick="return confirm(\''.$it618_video_lang['s1330'].'\')" name="it618submit_pass" value="'.$it618_video_lang['s1328'].'"/> <input type="submit" onclick="return confirm(\''.$it618_video_lang['s1331'].'\')" class="btn" name="it618submit_nopass" value="'.$it618_video_lang['s1329'].'"/><br>'.$it618_video_lang['s1482'].'<select name="dotype"><option value="1">'.$it618_video_lang['s1483'].'</option><option value="2">'.$it618_video_lang['s1484'].'</option></select> <input type="text" id="dovalue" name="dovalue" style="width:80px"> '.$it618_video_lang['s1485'].' <input type="submit" class="btn" onclick="return confirm(\''.$it618_video_lang['s1486'].'\')" style="color:blue" name="it618submit_edittime" value="'.$it618_video_lang['s1487'].'"/> <input type="submit" onclick="return confirm(\''.$it618_video_lang['s1838'].'\')" class="btn" name="it618submit_del" style="color:red" value="'.$it618_video_lang['s1837'].'"/> <input type="submit" onclick="return confirm(\''.$it618_video_lang['s1852'].'\')" class="btn" name="it618submit_okdel" value="'.$it618_video_lang['s1851'].'"/> <input type="submit" onclick="return confirm(\''.$it618_video_lang['s1854'].'\')" class="btn" name="it618submit_okclear" value="'.$it618_video_lang['s1853'].'"/> <br>
'.$it618_video_lang['s1488'].'
<br>'.$it618_video_lang['s1715'].'<select name="dotype1"><option value="1">'.$it618_video_lang['s1483'].'</option><option value="2">'.$it618_video_lang['s1484'].'</option></select> <input type="text" id="dovalue1" name="dovalue1" style="width:80px"> '.$it618_video_lang['s1485'].' <input type="submit" class="btn" onclick="return confirm(\''.$it618_video_lang['s1718'].'\')" style="color:blue" name="it618submit_edittime1" value="'.$it618_video_lang['s1717'].'"/> <br>
'.$it618_video_lang['s1716'].'
<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/

?>