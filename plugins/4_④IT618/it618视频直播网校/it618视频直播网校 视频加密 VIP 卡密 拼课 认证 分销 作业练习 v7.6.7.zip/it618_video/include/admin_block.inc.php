<?php
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='d')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_video_goods_block', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_shopids'])) {
		foreach($_GET['it618_shopids'] as $id => $val) {

			C::t('#it618_video#it618_video_goods_block')->update($id,array(
				'it618_shopids' => trim($_GET['it618_shopids'][$id]),
				'it618_pids' => trim($_GET['it618_pids'][$id]),
				'it618_etime' => trim($_GET['it618_etime'][$id]),
				'it618_about' => trim($_GET['it618_about'][$id]),
				'it618_bz' => trim($_GET['it618_bz'][$id]),
				'it618_isok' => trim($_GET['it618_isok'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_shopids_array = !empty($_GET['newit618_shopids']) ? $_GET['newit618_shopids'] : array();
	$newit618_pids_array = !empty($_GET['newit618_pids']) ? $_GET['newit618_pids'] : array();
	$newit618_uid_array = !empty($_GET['newit618_uid']) ? $_GET['newit618_uid'] : array();
	$newit618_etime_array = !empty($_GET['newit618_etime']) ? $_GET['newit618_etime'] : array();
	$newit618_about_array = !empty($_GET['newit618_about']) ? $_GET['newit618_about'] : array();
	$newit618_bz_array = !empty($_GET['newit618_bz']) ? $_GET['newit618_bz'] : array();
	$newit618_isok_array = !empty($_GET['newit618_isok']) ? $_GET['newit618_isok'] : array();
	
	foreach($newit618_shopids_array as $key => $value) {
		$it618_uid = trim($newit618_uid_array[$key]);
		$username=C::t('#it618_video#it618_video_goods_block')->fetch_username_by_uid($it618_uid);
		if($username!=''){		
			C::t('#it618_video#it618_video_goods_block')->insert(array(
				'it618_shopids' => trim($newit618_shopids_array[$key]),
				'it618_pids' => trim($newit618_pids_array[$key]),
				'it618_uid' => $it618_uid,
				'it618_etime' => trim($newit618_etime_array[$key]),
				'it618_about' => trim($newit618_about_array[$key]),
				'it618_bz' => trim($newit618_bz_array[$key]),
				'it618_isok' => trim($newit618_isok_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_video_lang['s33'].$ok1.' '.$it618_video_lang['s34'].$ok2.' '.$it618_video_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_block&pmod=admin_set&cp1=$cp1&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=11)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_block&pmod=admin_set&cp1=$cp1&operation=$operation&do=$do");
showtableheaders($strtmptitle[$cp1],'it618_video_class');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_block'));
	
	echo '<tr><td colspan=10>'.$it618_video_lang['s1522'].$count.'<span style="float:right;color:red">'.$it618_video_lang['s1514'].'</div></td></tr>';
	showsubtitle(array('',$it618_video_lang['s1517'],$it618_video_lang['s1515'], $it618_video_lang['s1516'], $it618_video_lang['s1518'],$it618_video_lang['s1519'],$it618_video_lang['s1520'],$it618_video_lang['s1521']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_block')." ORDER BY id");
	while($it618_video_goods_block = DB::fetch($query)) {
		
		if($it618_video_goods_block['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
		$username=C::t('#it618_video#it618_video_goods_block')->fetch_username_by_uid($it618_video_goods_block['it618_uid']);
		
		showtablerow('', array('class="td25"', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"".$it618_video_goods_block['id']."\">".$it618_video_goods_block['id']."",
			$username.'<br>('.$it618_video_goods_block['it618_uid'].')',
			"<textarea class=\"txt\" style=\"width:90px;height:58px\" name=\"it618_shopids[".$it618_video_goods_block['id']."]\">".$it618_video_goods_block['it618_shopids']."</textarea>",
			"<textarea class=\"txt\" style=\"width:180px;height:58px\" name=\"it618_pids[".$it618_video_goods_block['id']."]\">".$it618_video_goods_block['it618_pids']."</textarea>",
			"<textarea class=\"txt\" style=\"width:280px;height:58px\" name=\"it618_about[".$it618_video_goods_block['id']."]\">".$it618_video_goods_block['it618_about']."</textarea>",
			"<textarea class=\"txt\" style=\"width:180px;height:58px\" name=\"it618_bz[".$it618_video_goods_block['id']."]\">".$it618_video_goods_block['it618_bz']."</textarea>",
			"<textarea class=\"txt\" style=\"width:90px;height:33px;margin-bottom:3px\" id=\"time".$it618_video_goods_block['id']."\" readonly=\"readonly\" name=\"it618_etime[".$it618_video_goods_block['id']."]\">".$it618_video_goods_block['it618_etime']."</textarea><br><a href='javascript:' onclick='deltime(".$it618_video_goods_block['id'].")'>".$it618_video_lang['s1525']."</a>",
			'<input type="checkbox" name="it618_isok['.$it618_video_goods_block['id'].']" style="vertical-align:middle" value="1" '.$it618_isok_checked.'>'
		));
		
		$tmpjs.='
		laydate.render({
		  elem: "#time'.$it618_video_goods_block['id'].'"
		  ,type: "datetime"
		});
		';
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	$s890=$it618_video_lang['s1524'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_shopids[]").length;
	
		return [
		[[1,''],[1,'<input type=\"text\" class="txt" style=\"width:58px;margin-bottom:3px\" name="newit618_uid[]"><br><font color=red>$s890</font>'], [1,'<textarea class="txt" style=\"width:90px;height:58px\" name="newit618_shopids[]"></textarea>'], [1,'<textarea class="txt" style=\"width:180px;height:58px\" name="newit618_pids[]"></textarea>'], [1,'<textarea class="txt" style=\"width:280px;height:58px\" name="newit618_about[]"></textarea>'], [1,'<textarea class="txt" style=\"width:180px;height:58px\" name="newit618_bz[]"></textarea>'],[1,''], [1,'<input type="checkbox" name="newit618_isok[]" style="vertical-align:middle" value="1">']]
		];
	}
	rowtypedata=rundata();
	
	function deltime(id){
		document.getElementById("time"+id).value='';
	}
	</script>
EOT;
	echo '<tr><td></td><td colspan="10" style="color:blue">'.$it618_video_lang['s1523'].'</td></tr>';
    echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr><script charset="utf-8" src="source/plugin/it618_video/js/laydate/laydate.js"></script><style>.laydate-btns-time{float:left}</style><script>'.$tmpjs.'</script>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=11)return;
showtablefooter(); /*dis'.'m.tao'.'bao.com*/
?>