<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$urlsql='&key='.$_GET['key'].'&price1='.$_GET['price1'].'&price2='.$_GET['price2'].'&it618_class1_id='.$_GET['it618_class1_id'].'&it618_class2_id='.$_GET['it618_class2_id'].'&state='.$_GET['state'].'&orderby='.$_GET['orderby'];

if(count($reabc)!=11)return;

if(submitcheck('it618submit_dao')){

	foreach(C::t('#it618_video#it618_video_sale')->fetch_all_by_search(
		$_GET['findshopid'],"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'s.id desc',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],0,0
	) as $it618_video_sale) {
		
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
		$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
		
		$jftmp='';
		if($it618_video_sale['it618_jfbl']>0&&$it618_video_sale['it618_price']>0){
			$it618_jfbl=intval($it618_video_sale['it618_jfbl']*$it618_video_sale['it618_price']/100);
			$jftmp=$it618_jfbl.$creditname;
		}
		
		if($it618_video_sale['it618_price']>0||$it618_video_sale['it618_score']>0){
			$pricestr=it618_video_getsalemoney($it618_video_sale);
		}else{
			$pricestr=$it618_video_lang['s106'];
		}
	
		$it618_tc='';
		if($it618_video_sale['it618_tcbl']>0){
			$it618_tc=$it618_video_sale['it618_tcbl'].'% ';
			$it618_tc.=$it618_video_sale['it618_tc'].$it618_video_lang['s125'].' ';
			
			if($it618_video_sale['it618_score']>0){
				$tmptc=intval($it618_video_sale['it618_tcbl']*$it618_video_sale['it618_score']/100);
				$jfname=$_G['setting']['extcredits'][$it618_video_sale['it618_jfid']]['title'];
				$it618_tc.=' '.$tmptc.$jfname;
			}
			
			$it618_tc=$it618_video_lang['s1206'].$it618_tc;
		}
		
		$it618_tuitc='';
		if($it618_video_sale['it618_tuitcbl']>0){
			$it618_tuitc=$it618_video_sale['it618_tuitcbl'].'% ';
			$it618_tuitc.=$it618_video_sale['it618_tuitc'].$it618_video_lang['s125'].' ';
			
			if($it618_video_sale['it618_score']>0){
				$tmptc=intval($it618_video_sale['it618_tuitcbl']*$it618_video_sale['it618_score']/100);
				$jfname=$_G['setting']['extcredits'][$it618_video_sale['it618_jfid']]['title'];
				$it618_tuitc.=' '.$tmptc.$jfname;
			}
			
			$it618_tuitc=' '.$it618_video_lang['s1207'].$it618_tuitc;
		}
		
		if($it618_video_sale['it618_gtypeid']>0){
			$gtypename = it618_video_gettypename($it618_video_sale['it618_gtypeid']);
		}else{
			$gtypename=$it618_video_lang['s1153'];
		}
		
		$strtmp.=$it618_video_goods['id'].",".$it618_video_goods['it618_name'].",".$gtypename.'*'.$it618_video_sale['it618_count'].",".$pricestr.",".$jftmp.",".$it618_tc.",".it618_video_getusername($it618_video_sale['it618_uid'])." ".$it618_video_sale['it618_tel'].",".date('Y-m-d H:i:s', $it618_video_sale['it618_time']).",".$it618_video_shop['it618_name']."\n";
		$datacount=$datacount+1;
	}
	
	$datapath1=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/';
	if(!file_exists($datapath1)) {
		mkdir($datapath1);
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	if($_GET['it618_time1']!=''||$_GET['it618_time2']!=''){
		if($_GET['it618_time1']!=''){
			$timetmp1=str_replace("-","",$_GET['it618_time1']);
		}else{
			$timetmp1='null';
		}
		if($_GET['it618_time2']!=''){
			$timetmp2=str_replace("-","",$_GET['it618_time2']);
		}else{
			$timetmp2='null';
		}
		$timetmp=$timetmp1.'-'.$timetmp2;
	}
	$timestr=md5(date("YmdHis").FORMHASH).'_'.$timetmp. '_' . $datacount;
	it618_video_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	dsetcookie('it618_video_timestr',$timestr,31536000);
	
	cpmsg($it618_video_lang['s777'], "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&cp1=$cp1&page=$page".$urlsql, 'succeed');
}

$it618_video_timestr=getcookie('it618_video_timestr');
if($it618_video_timestr!=''){
	$downstr='<a href="'.$_G['siteurl'].'source/plugin/it618_video/kindeditor/data/dao/'.$it618_video_timestr.'.csv" target="_blank">'.$it618_video_lang['s778'].'</a>';
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&cp1=$cp1".$urlsql);
showtableheaders($it618_video_lang['s413'],'it618_video_goods');
	
	echo '<tr><td colspan="15"><div class="fixsel">'.it618_video_getlang('s224').' <input name="pname" class="txt" style="width:180px;margin-right:1px" value="'.$_GET['pname'].'" /> '.$it618_video_lang['s775'].' <input name="findshopid" class="txt" style="width:76px" value="'.$_GET['findshopid'].'"/>'.it618_video_getlang('s761').' <input name="finduid" class="txt" style="width:76px" value="'.$_GET['finduid'].'"/>'.it618_video_getlang('s228').' <input id="it618_time1" name="it618_time1" class="txt" style="width:90px;margin-right:0" readonly="readonly" value="'.$_GET['it618_time1'].'"/>-<input id="it618_time2" name="it618_time2" class="txt" style="width:90px;" readonly="readonly" value="'.$_GET['it618_time2'].'"/> &nbsp;<input type="submit" class="btn" value="'.it618_video_getlang('s763').'" name="it618submit_find" /> <input type="submit" class="btn" value="'.it618_video_getlang('s1102').'" name="it618submit_dao" /> '.$downstr.'</div></td></tr>';
	
	$count = C::t('#it618_video#it618_video_sale')->count_by_search($_GET['findshopid'],"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$summoney = C::t('#it618_video#it618_video_sale')->sum_money_by_search($_GET['findshopid'],"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$sumtcmoney = C::t('#it618_video#it618_video_sale')->sum_tcmoney_by_search($_GET['findshopid'],"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&cp1=$cp1".$urlsql);
	
	echo '<tr><td colspan=14>'.it618_video_getlang('s229').'<font color=red>'.$count.'</font> '.it618_video_getlang('s230').'<font color=red>'.$summoney.'</font> '.it618_video_getlang('s415').'<font color=red>'.$sumtcmoney.'</font><span style="float:right">'.it618_video_getlang('s776').'</span></td></tr>';
	showsubtitle(array('',it618_video_getlang('s233'),it618_video_getlang('t202'),it618_video_getlang('s419'),it618_video_getlang('s803'),it618_video_getlang('s774')));
	
	$n=1;
	foreach(C::t('#it618_video#it618_video_sale')->fetch_all_by_search(
		$_GET['findshopid'],"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'s.id desc',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_video_sale) {
		
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
		$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
		
		$jftmp='';
		if($it618_video_sale['it618_jfbl']>0&&$it618_video_sale['it618_price']>0){
			$it618_jfbl=intval($it618_video_sale['it618_jfbl']*$it618_video_sale['it618_price']/100);
			$jftmp=$it618_jfbl.$creditname;
		}
		
		if($it618_video_sale['it618_price']>0||$it618_video_sale['it618_score']>0){
			$pricestr='<font color=red>'.it618_video_getsalemoney($it618_video_sale).'</font>';
		}else{
			$pricestr='<font color=#390>'.$it618_video_lang['s106'].'</font>';
		}
	
		$it618_tc='';
		if($it618_video_sale['it618_tcbl']>0){
			$it618_tc=$it618_video_sale['it618_tcbl'].'% ';
			$it618_tc.='<font color=red>'.$it618_video_sale['it618_tc'].'</font>'.$it618_video_lang['s125'].' ';
			
			if($it618_video_sale['it618_score']>0){
				$tmptc=intval($it618_video_sale['it618_tcbl']*$it618_video_sale['it618_score']/100);
				$jfname=$_G['setting']['extcredits'][$it618_video_sale['it618_jfid']]['title'];
				$it618_tc.=' <font color=red>'.$tmptc.'</font>'.$jfname;
			}
			
			$it618_tc=$it618_video_lang['s1206'].$it618_tc;
		}
		
		$it618_tuitc='';
		if($it618_video_sale['it618_tuitcbl']>0){
			$it618_tuitc=$it618_video_sale['it618_tuitcbl'].'% ';
			$it618_tuitc.='<font color=red>'.$it618_video_sale['it618_tuitc'].'</font>'.$it618_video_lang['s125'].' ';
			
			if($it618_video_sale['it618_score']>0){
				$tmptc=intval($it618_video_sale['it618_tuitcbl']*$it618_video_sale['it618_score']/100);
				$jfname=$_G['setting']['extcredits'][$it618_video_sale['it618_jfid']]['title'];
				$it618_tuitc.=' <font color=red>'.$tmptc.'</font>'.$jfname;
			}
			
			$it618_tuitc='<br>'.$it618_video_lang['s1207'].$it618_tuitc;
		}
		
		if($it618_video_sale['it618_gtypeid']>0){
			$gtypename = it618_video_gettypename($it618_video_sale['it618_gtypeid']);
		}else{
			$gtypename=$it618_video_lang['s1153'];
		}
		
		$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
		$tmpurl1=it618_video_getrewrite('video_lecturer',$it618_video_goods['it618_shopid'],'plugin.php?id=it618_video:lecturer&lid='.$it618_video_goods['it618_shopid']);

		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_video_sale['id'].'" name="delete[]" value="'.$it618_video_sale['id'].'" '.$disabled.'><label for="chk_del'.$it618_video_sale['id'].'">'.$it618_video_sale['id'].'</label>',
			'<a href="'.$tmpurl.'" target="_blank">'.$it618_video_goods['it618_name'].'</a> <font color=#999>'.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'</font><br>'.$pricestr.'',
			$jftmp,
			$it618_tc.$it618_tuitc,
			'<font color=blue>'.$gtypename.'*'.$it618_video_sale['it618_count'].'</font><br><a href="'.it618_video_rewriteurl($it618_video_sale['it618_uid']).'" target="_blank">'.it618_video_getusername($it618_video_sale['it618_uid']).'</a> '.$it618_video_sale['it618_tel'].'',
			'<font color=#999>'.date('Y-m-d H:i:s', $it618_video_sale['it618_time']).'</font><br><a href="'.$tmpurl1.'" target="_blank">'.$it618_video_shop['it618_name'].'</a>'
		));
		$n=$n+1;
	}

	echo '
	<script>
	laydate.render({
	  elem: "#it618_time1"
	});
	laydate.render({
	  elem: "#it618_time2"
	});
	</script>
	<tr><td class="td25"></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=11)return;
showtablefooter(); /*dis'.'m.tao'.'bao.com*/
?>