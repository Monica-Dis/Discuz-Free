<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_video#it618_video_focus')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_img'])) {
		foreach($_GET['it618_img'] as $id => $val) {

			C::t('#it618_video#it618_video_focus')->update($id,array(
				'it618_img' => $_GET['it618_img'][$id],
				'it618_url' => $_GET['it618_url'][$id],
				'it618_order' => $_GET['it618_order'][$id],
			));
			if($cp1==26)it618_video_getwapppic('wapad',$id,$_GET['it618_img'][$id],0);
			$ok1=$ok1+1;
		}
	}

	$newit618_img_array = !empty($_GET['newit618_img']) ? $_GET['newit618_img'] : array();
	$newit618_url_array = !empty($_GET['newit618_url']) ? $_GET['newit618_url'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_url_array as $key => $value) {

		C::t('#it618_video#it618_video_focus')->insert(array(
			'it618_type' => $cp1,
			'it618_img' => $newit618_img_array[$key],
			'it618_url' => $newit618_url_array[$key],
			'it618_order' => $newit618_order_array[$key],
		), true);
		$ok2=$ok2+1;
	}
	
	cpmsg($it618_video_lang['s33'].$ok1.' '.$it618_video_lang['s34'].$ok2.' '.$it618_video_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_focus&pmod=admin_style&operation=$operation&do=$do&page=$page&cp1=$cp1", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_focus&pmod=admin_style&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($strtmptitle[$cp1],'it618_video_focus');
	if($cp1==2){
		$strtmp=$it618_video_lang['s60'].'<font color=red>1200</font>px,'.$it618_video_lang['s61'].'<font color=red>63</font>px';
		$imgwidth=1200;$width=300;$height=40;
	}elseif($cp1==3||$cp1==4){
		$strtmp=$it618_video_lang['s60'].'<font color=red>223</font>px,'.$it618_video_lang['s61'].'<font color=red>231</font>px';
		$imgwidth=640;$width=80;$height=80;
	}elseif($cp1==5||$cp1==6){
		$strtmp=$it618_video_lang['s60'].'<font color=red>223</font>px,'.$it618_video_lang['s61'].'<font color=red>180</font>px';
		$imgwidth=640;$width=80;$height=60;
	}elseif($cp1==17){
		$strtmp=$it618_video_lang['s60'].'<font color=red>940</font>px,'.$it618_video_lang['s61'].'<font color=red>358</font>px';
		$imgwidth=1200;$width=180;$height=80;
		$tips='';
	}elseif($cp1==18){
		$strtmp=$it618_video_lang['s1804'];
		$imgwidth=3200;$width=260;$height=80;
		$tips='';
	}elseif($cp1==26){
		$strtmp=$it618_video_lang['s879'];
		$imgwidth=1200;$width=222;$height=80;
		$tips='';
	}
	
	$count = C::t('#it618_video#it618_video_focus')->count_by_type($cp1);
	echo '<tr><td colspan=4>'.$it618_video_lang['s62'].$count.'<span style="float:right">'.$it618_video_lang['s63'].$tips.'</span></td></tr>';
	showsubtitle(array('', "<div style='width:400px'>".$it618_video_lang['s64']."(".$strtmp.')'."</div>","<div style='width:400px'>".$it618_video_lang['s65']."</div>","<div style='width:50px'>".$it618_video_lang['s66']."</div>"));
	
	foreach(C::t('#it618_video#it618_video_focus')->fetch_all_by_type($cp1) as $it618_video_focus) {

		showtablerow('', array('class="td25"', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"".$it618_video_focus['id']."\">",
			'<img src="'.$it618_video_focus['it618_img'].'" id="img'.$it618_video_focus['id'].'" width="'.$width.'" height="'.$height.'" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" id="url'.$it618_video_focus['id'].'" name="it618_img['.$it618_video_focus['id'].']" readonly="readonly" value="'.$it618_video_focus['it618_img'].'" /> <input type="button" id="image'.$it618_video_focus['id'].'" value="'.$it618_video_lang['s67'].'" />',
			'<input class="txt" type="text" style="width:400px;" name="it618_url['.$it618_video_focus['id'].']" value="'.$it618_video_focus['it618_url'].'">',
			'<input class="txt" type="text" style="width:30px;" name="it618_order['.$it618_video_focus['id'].']" value="'.$it618_video_focus['it618_order'].'">'
		));
		
		$editorjs.='K(\'#image'.$it618_video_focus['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url'.$it618_video_focus['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$it618_video_focus['id'].'\').val(url);
								K(\'#img'.$it618_video_focus['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});';
	}
	
	echo '
<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var editor = K.editor({
					uploadJson : \'source/plugin/it618_video/kindeditor/php/upload_json.php?imgwidth='.$imgwidth.$oss.'\',
					fileManagerJson : \'source/plugin/it618_video/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$editorjs.'
			});
</script>';
$it618_video_lang184=$it618_video_lang['s68'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
	
		return [
				[[1,''], [1, '$it618_video_lang184'], [1, ' <input type="text" class="txt" style="width:400px;" name="newit618_url[]">'], [1, ' <input class="txt" style="width:30px" type="text" name="newit618_order[]" value="1">'], [1,'']]
				];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="5"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=11)return;
showtablefooter(); /*dis'.'m.tao'.'bao.com*/
?>