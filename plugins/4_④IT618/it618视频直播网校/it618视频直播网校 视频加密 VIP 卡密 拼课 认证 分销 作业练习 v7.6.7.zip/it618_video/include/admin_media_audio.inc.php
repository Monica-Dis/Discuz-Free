<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

$lang_s234=$it618_video_lang['s234'];
$typecss='style="display:"';

if($osstype==0){
	$lang_t29=$it618_video_lang['t29'];
}

if($osstype==1){
	$lang_t29=$it618_video_lang['t798'];
}

if($osstype==2){
	$lang_t29=$it618_video_lang['s2019'];
	$typecss='style="display:none"';
	$lang_s234=$it618_video_lang['s2020'];
}

$it618sql = "it618_osstype=$osstype";

$state0='';$state1='';$state2='';$state3='';$state4='';$state5='';
if($_GET['state']==0){$state0='selected="selected"';}
if($_GET['state']==1){$it618sql .= " and it618_chkstate = 0";$state3='selected="selected"';}
if($_GET['state']==2){$it618sql .= " and it618_chkstate = 1";$state4='selected="selected"';}
if($_GET['state']==3){$it618sql .= " and it618_chkstate = 2";$state5='selected="selected"';}

$orderby0='';$orderby1='';
if($_GET['orderby']==0){$it618orderby = "it618_time desc";$orderby0='selected="selected"';}
if($_GET['orderby']==1){$it618orderby = "it618_size desc";$orderby1='selected="selected"';}

$urlsql='&osstype='.$osstype.'&key='.$_GET['key'].'&class_id='.$_GET['class_id'].'&state='.$_GET['state'].'orderby='.$_GET['orderby'];

if(submitcheck('it618submit_pass')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_media_audio = C::t('#it618_video#it618_video_media_audio')->fetch_by_id($delid);
		if($it618_video_media_audio['it618_chkstate']==0){
			DB::query("update ".DB::table('it618_video_media_audio')." set it618_chkstate=1 where id=".$delid);
			it618_video_sendmessage('media_shop',$it618_video_media_audio['id']);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_video_lang['s1096'].$ok, "action=plugins&identifier=$identifier&cp=admin_media_audio&pmod=admin_media&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_nopass')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_media_audio = C::t('#it618_video#it618_video_media_audio')->fetch_by_id($delid);
		if($it618_video_media_audio['it618_chkstate']==1){
			DB::query("update ".DB::table('it618_video_media_audio')." set it618_chkstate=0 where id=".$delid);
			it618_video_sendmessage('media_shop',$it618_video_media_audio['id']);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_video_lang['s1097'].$ok, "action=plugins&identifier=$identifier&cp=admin_media_audio&pmod=admin_media&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_delete')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_media_audio = C::t('#it618_video#it618_video_media_audio')->fetch_by_id($delid);
		if($it618_video_media_audio['it618_chkstate']==0){
			it618_video_deletemediaaudio($it618_video_media_audio['it618_url']);
			DB::query("delete from ".DB::table('it618_video_media_audio')." where id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_video_lang['s193'].$ok, "action=plugins&identifier=$identifier&cp=admin_media_audio&pmod=admin_media&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=11)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_media_audio&pmod=admin_media&operation=$operation&do=$do&page=$page".$urlsql);
showtableheaders($lang_t29,'it618_video_media_audio');

echo '<tr><td colspan=14>'.it618_video_getlang('s97').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:300px" /> '.it618_video_getlang('s101').' <select name="state"><option value=0 '.$state0.'>'.it618_video_getlang('s102').'</option><option value=1 '.$state1.'>'.it618_video_getlang('s677').'</option><option value=2 '.$state2.'>'.it618_video_getlang('s678').'</option><option value=3 '.$state3.'>'.it618_video_getlang('s679').'</option></select> <select name="orderby"><option value=0 '.$orderby0.'>'.it618_video_getlang('s697').'</option><option value=1 '.$orderby1.'>'.it618_video_getlang('s886').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_video_getlang('s350').'" /></td></tr>';
	
	$count = C::t('#it618_video#it618_video_media_audio')->count_by_search($it618sql,'',0,0,$_GET['key']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_media_audio&pmod=admin_media&operation=$operation&do=$do".$urlsql);
	
	$sumsize = C::t('#it618_video#it618_video_media_audio')->sum_size_by_search($it618sql,'',0,0,$_GET['key']);
	
	echo '<tr><td colspan=14>'.it618_video_getlang('s850').$count.' '.$it618_video_lang['s235'].round(($sumsize/1024/1024),2).'M<span style="float:right;color:red">'.it618_video_getlang('s838').'</span></td></tr>';
	showsubtitle(array('',it618_video_getlang('s837'),$lang_s234,$it618_video_lang['s845']));
	
	$n=1;
	foreach(C::t('#it618_video#it618_video_media_audio')->fetch_all_by_search(
		$it618sql,$it618orderby,0,0,$_GET['key'],$startlimit,$ppp
	) as $it618_video_media_audio) {

		if($it618_video_media_audio['it618_chkstate']==0){
			$it618_chkstate='<font color=red>'.$it618_video_lang['s677'].'</font>';
		}
		
		if($it618_video_media_audio['it618_chkstate']==1){
			$it618_chkstate='<font color=green>'.$it618_video_lang['s678'].'</font>';
		}
		
		if($it618_video_media_audio['it618_chkstate']==2){
			$it618_chkstate='<font color=green>'.$it618_video_lang['s679'].'</font>';
		}
		
		$shopname=C::t('#it618_video#it618_video_shop')->fetch_name_by_id($it618_video_media_audio['it618_shopid']);
		
		if($osstype==2){
			$media_playstr='[<a href="'.it618_video_getsignedurl($it618_video_media_audio['it618_url']).'" target="_blank">'.$it618_video_lang['s46'].'</a>] ';
		}else{
			$media_playstr='[<a href="javascript:" onclick="media_play(\''.it618_video_getsignedurl($it618_video_media_audio['it618_url']).'\',\''.$shopname.' '.str_replace("'","",$it618_video_media_audio['it618_name']).'\')">'.$it618_video_lang['s1100'].'</a>] ';
		}

		showtablerow('', array('', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_video_media_audio['id'].'"><label for="chk_del'.$n.'">'.$it618_video_media_audio['id'].'</label>',
			$shopname.' '.$it618_video_media_audio['it618_name'],
			$media_playstr.'<span '.$typecss.'>'.$it618_video_lang['s399'].$it618_video_media_audio['it618_time1'].$it618_video_lang['s397'].$it618_video_media_audio['it618_time2'].$it618_video_lang['s398'].$it618_video_media_audio['it618_time3'].$it618_video_lang['s400'].' </span>'.$it618_video_media_audio['it618_ext'].' '.round(($it618_video_media_audio['it618_size']/1024/1024),2).'MB <font color=#999>'.date('Y-m-d H:i:s', $it618_video_media_audio['it618_time']).'</font>',
			$it618_chkstate
		));
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_video_getlang('s129').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_pass" value="'.$it618_video_lang['s1094'].'"/> <input type="submit" class="btn" name="it618submit_nopass" value="'.$it618_video_lang['s1095'].'"/> <input type="submit" class="btn" name="it618submit_delete" value="'.$it618_video_lang['s191'].'" onclick="return confirm(\''.$it618_video_lang['s194'].'\')"/><input type=hidden value='.$page.' name=page /></div><br></td></tr>';
	
if($osstype==0){
	echo '
	<script type="text/javascript" src="source/plugin/it618_video/js/jquery.js"></script>
	<script type="text/javascript" src="source/plugin/it618_video/js/layer/layer.js"></script>
	<script>
	var playurl,title;
	function media_play(url,tmptitle){
		playurl=url;
		title=tmptitle;
		
		layerindex=layer.open({
			type: 1,
			title: "<div style=\'float:left\'>"+title+"</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["848px", "90px"],
			content: "<iframe src=\'plugin.php?id=it618_video:audiotie&&playurl="+playurl+"\' style=\'border:0;\' frameborder=0 width=\'848\' height=\'80\'></iframe>",
			cancel: function(index, layero){ 
			}    
		});
	}
    </script>';
}

if($osstype==1){
echo '
	<script type="text/javascript" src="source/plugin/it618_video/js/jquery.js"></script>
	<script type="text/javascript" src="source/plugin/it618_video/js/layer/layer.js"></script>
	<script>
	var playurl,title;
	function media_play(url,tmptitle){
		playurl=url;
		title=tmptitle;
		
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left\'>"+title+"</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["800px", "550px"],
			content: "plugin.php?id=it618_video:sc_media_play'.$adminsid.'&playurl="+playurl,
			cancel: function(index, layero){ 
			}    
		});
	}
    </script>';
}

showtablefooter(); /*dis'.'m.tao'.'bao.com*/

echo '<script type="text/javascript">
		function check_all(obj,id)
		{
			for(var i=1;i<'.$n.';i++)
			{
				document.getElementById(id+""+i).checked = obj.checked;
			}
		}
	  </script>';
?>