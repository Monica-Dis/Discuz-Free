<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

$it618sql = "1";

$state0='';$state1='';$state2='';$state3='';$state4='';$state5='';
if($_GET['state']==0){$state0='selected="selected"';}
if($_GET['state']==1){$it618sql .= " and it618_state = 0";$state1='selected="selected"';}
if($_GET['state']==2){$it618sql .= " and it618_state = 1";$state2='selected="selected"';}
if($_GET['state']==3){$it618sql .= " and it618_chkstate = 0";$state3='selected="selected"';}
if($_GET['state']==4){$it618sql .= " and it618_chkstate = 1";$state4='selected="selected"';}
if($_GET['state']==5){$it618sql .= " and it618_chkstate = 2";$state5='selected="selected"';}

$orderby0='';$orderby1='';$orderby2='';
if($_GET['orderby']==0){$it618orderby = "it618_time desc";$orderby0='selected="selected"';}
if($_GET['orderby']==1){$it618orderby = "it618_duration desc";$orderby1='selected="selected"';}
if($_GET['orderby']==2){$it618orderby = "it618_size desc";$orderby2='selected="selected"';}

$urlsql='&key='.$_GET['key'].'&class_id='.$_GET['class_id'].'&state='.$_GET['state'].'orderby='.$_GET['orderby'];

if(submitcheck('it618submit_true')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_media = C::t('#it618_video#it618_video_media')->fetch_by_id($delid);
		if($it618_video_media['it618_state']==0&&$it618_video_media['it618_mediaid']!=''){
			it618_video_updatemediastate($it618_video_media['it618_mediaid'],'true');
			DB::query("update ".DB::table('it618_video_media')." set it618_state=1 where id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_video_lang['s956'].$ok, "action=plugins&identifier=$identifier&cp=admin_media&pmod=admin_media&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_false')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_media = C::t('#it618_video#it618_video_media')->fetch_by_id($delid);
		if($it618_video_media['it618_state']==1){
			it618_video_updatemediastate($it618_video_media['it618_mediaid'],'false');
			DB::query("update ".DB::table('it618_video_media')." set it618_state=0 where id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_video_lang['s957'].$ok, "action=plugins&identifier=$identifier&cp=admin_media&pmod=admin_media&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_pass')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_media = C::t('#it618_video#it618_video_media')->fetch_by_id($delid);
		if($it618_video_media['it618_state']==1&&$it618_video_media['it618_chkstate']==0){
			DB::query("update ".DB::table('it618_video_media')." set it618_chkstate=1 where id=".$delid);
			it618_video_sendmessage('media_shop',$it618_video_media['id']);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_video_lang['s1096'].$ok, "action=plugins&identifier=$identifier&cp=admin_media&pmod=admin_media&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_nopass')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_media = C::t('#it618_video#it618_video_media')->fetch_by_id($delid);
		if($it618_video_media['it618_chkstate']==1){
			DB::query("update ".DB::table('it618_video_media')." set it618_chkstate=0 where id=".$delid);
			it618_video_sendmessage('media_shop',$it618_video_media['id']);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_video_lang['s1097'].$ok, "action=plugins&identifier=$identifier&cp=admin_media&pmod=admin_media&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_delete')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_media = C::t('#it618_video#it618_video_media')->fetch_by_id($delid);
		if($it618_video_media['it618_chkstate']==0){
			it618_video_deletemediaandmts($it618_video_media['it618_mediaid']);
			DB::query("delete from ".DB::table('it618_video_media')." where id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_video_lang['s193'].$ok, "action=plugins&identifier=$identifier&cp=admin_media&pmod=admin_media&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_deletemedia')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_media = C::t('#it618_video#it618_video_media')->fetch_by_id($delid);
		it618_video_deletemedia($it618_video_media['it618_mediaid']);
		DB::query("update ".DB::table('it618_video_media')." set it618_urldel=1 where id=".$delid);
		$ok=$ok+1;
	}

	cpmsg($it618_video_lang['s2005'].$ok, "action=plugins&identifier=$identifier&cp=admin_media&pmod=admin_media&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=11)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_media&pmod=admin_media&operation=$operation&do=$do&page=$page");
showtableheaders($it618_video_lang['t34'],'it618_video_media');

echo '<tr><td colspan=14>'.it618_video_getlang('s97').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:300px" /> '.it618_video_getlang('s101').' <select name="state"><option value=0 '.$state0.'>'.it618_video_getlang('s102').'</option><option value=1 '.$state1.'>'.it618_video_getlang('s695').'</option><option value=2 '.$state2.'>'.it618_video_getlang('s696').'</option><option value=3 '.$state3.'>'.it618_video_getlang('s677').'</option><option value=4 '.$state4.'>'.it618_video_getlang('s678').'</option><option value=5 '.$state5.'>'.it618_video_getlang('s679').'</option></select> <select name="orderby"><option value=0 '.$orderby0.'>'.it618_video_getlang('s697').'</option><option value=1 '.$orderby1.'>'.it618_video_getlang('s698').'</option><option value=2 '.$orderby2.'>'.it618_video_getlang('s699').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_video_getlang('s350').'" /></td></tr>';
	
	$count = C::t('#it618_video#it618_video_media')->count_by_search($it618sql,'',0,0,$_GET['key']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_media&pmod=admin_media&operation=$operation&do=$do&cp1=$cp1".$urlsql);
	
	$sumsize = C::t('#it618_video#it618_video_media')->sum_size_by_search($it618sql,'',0,0,$_GET['key']);
	$summtscount = C::t('#it618_video#it618_video_media')->sum_mtscount_by_search($it618sql,'',0,0,$_GET['key']);
	$summtssize = C::t('#it618_video#it618_video_media')->sum_mtssize_by_search($it618sql,'',0,0,$_GET['key']);
	
	echo '<tr><td colspan=14>'.it618_video_getlang('s850').$count.' '.$it618_video_lang['s583'].round((($sumsize+$summtssize)/1024/1024),2).'M '.$it618_video_lang['s584'].round(($sumsize/1024/1024),2).'M '.$it618_video_lang['s585'].$summtscount.' '.$it618_video_lang['s586'].round(($summtssize/1024/1024),2).'M<span style="float:right;color:red">'.it618_video_getlang('s849').'</span></td></tr>';
	showsubtitle(array('',it618_video_getlang('s842'),it618_video_getlang('s864'),it618_video_getlang('s844'),$it618_video_lang['s845']));
	
	$n=1;
	foreach(C::t('#it618_video#it618_video_media')->fetch_all_by_search(
		$it618sql,$it618orderby,0,0,$_GET['key'],$startlimit,$ppp
	) as $it618_video_media) {

		$tmp1=str_replace('<option value='.$it618_video_media['it618_class_id'].'>','<option value='.$it618_video_media['it618_class_id'].' selected="selected">',$tmp);
		$shopname=C::t('#it618_video#it618_video_shop')->fetch_name_by_id($it618_video_media['it618_shopid']);
		
		$mtsstr='';$media_playstr='';
		if($it618_video_media['it618_mtscount']==0){
			it618_video_updatemedia($it618_video_media['it618_url']);
			$mtsstr=$it618_video_lang['s958'];
		}else{
			$query = DB::query("SELECT * FROM ".DB::table('it618_video_media_mts')." where it618_media_id=".$it618_video_media['id']." ORDER BY it618_size");
			while($it618_video_media_mts =	DB::fetch($query)) {
				
				if($it618_video_media['it618_state']==1){
					$media_playstr='[<a href="javascript:" onclick="media_play(\''.$it618_video_media_mts['it618_url'].'\',\''.$shopname.' '.str_replace("'","",$it618_video_media['it618_name']).'\')">'.$it618_video_lang['s1100'].'</a>]';
				}
				
				$mtsstr.='<font color=green><b>'.$it618_video_media_mts['it618_actname'].'</b></font> '.$media_playstr.' <font color=#999>'.$it618_video_lang['s1685'].'</font>'.it618_video_getvideotime($it618_video_media_mts['it618_duration']).' <font color=#999>'.$it618_video_lang['s1686'].'</font>'.round(($it618_video_media_mts['it618_size']/1024/1024),2).'MB<br><font color=#999>'.$it618_video_lang['s1687'].'</font>'.$it618_video_media_mts['it618_fps'].'FPS <font color=#999>'.$it618_video_lang['s1688'].'</font>'.$it618_video_media_mts['it618_bitrate'].'Kbps <font color=#999>'.$it618_video_lang['s1689'].'</font>'.$it618_video_media_mts['it618_width'].'x'.$it618_video_media_mts['it618_height'].'px<br>';
			}
		}
		
		if($it618_video_media['it618_state']==0){
			$it618_state='<font color=red>'.$it618_video_lang['s1690'].'</font>';
		}else{
			$it618_state='<font color=green>'.$it618_video_lang['s1691'].'</font>';
		}
		
		if($it618_video_media['it618_chkstate']==0){
			$it618_chkstate='<font color=red>'.$it618_video_lang['s677'].'</font>';
		}
		
		if($it618_video_media['it618_chkstate']==1){
			$it618_chkstate='<font color=green>'.$it618_video_lang['s678'].'</font>';
		}
		
		if($it618_video_media['it618_chkstate']==2){
			$it618_chkstate='<font color=green>'.$it618_video_lang['s679'].'</font>';
		}
		
		$downstr='';
		if($it618_video_media['it618_urldel']==0){
			$downstr='[<a href="'.it618_video_getsignedurl($it618_video_media['it618_url']).'" target="_blank">'.$it618_video_lang['s46'].'</a>]';
		}

		showtablerow('', array('', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_video_media['id'].'"><label for="chk_del'.$n.'">'.$it618_video_media['id'].'</label>',
			'<img src="'.it618_video_cdnkeyurl($it618_video_media['it618_coverurl']).'" width="133" height="80"/>',
			$shopname.' '.$it618_video_media['it618_name'].'<br>
			<font color=#999>'.$it618_video_lang['s1685'].'</font>'.it618_video_getvideotime($it618_video_media['it618_duration']).' <font color=#999>'.$it618_video_lang['s1686'].'</font>'.round(($it618_video_media['it618_size']/1024/1024),2).'MB '.$downstr.' <font color=#999>'.date('Y-m-d H:i:s', $it618_video_media['it618_time']).'</font><br>
			<font color=#999>ID:'.$it618_video_media['it618_mediaid'].'</font><br><font color=#999>'.$it618_video_lang['s1687'].'</font>'.$it618_video_media['it618_fps'].'FPS <font color=#999>'.$it618_video_lang['s1688'].'</font>'.$it618_video_media['it618_bitrate'].'Kbps <font color=#999>'.$it618_video_lang['s1689'].'</font>'.$it618_video_media['it618_width'].'x'.$it618_video_media['it618_height'].'px',
			$mtsstr,
			$it618_state.' '.$it618_chkstate
		));
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_video_getlang('s129').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_true" value="'.$it618_video_lang['s1692'].'"/> <input type="submit" class="btn" name="it618submit_false" value="'.$it618_video_lang['s1693'].'"/> <input type="submit" class="btn" name="it618submit_pass" value="'.$it618_video_lang['s1094'].'"/> <input type="submit" class="btn" name="it618submit_nopass" value="'.$it618_video_lang['s1095'].'"/> <input type="submit" class="btn" name="it618submit_delete" value="'.$it618_video_lang['s191'].'" onclick="return confirm(\''.$it618_video_lang['s192'].'\')"/><br><input type="submit" class="btn" name="it618submit_deletemedia" value="'.$it618_video_lang['s2006'].'" onclick="return confirm(\''.$it618_video_lang['s2007'].'\')"/> '.$it618_video_lang['s2008'].'<input type=hidden value='.$page.' name=page /></div><br>'.$it618_video_lang['s1093'].'</td></tr>';
	
	echo '
	<script type="text/javascript" src="source/plugin/it618_video/js/jquery.js"></script>
	<script type="text/javascript" src="source/plugin/it618_video/js/layer/layer.js"></script>
	<script>
	var playurl,title;
	function media_play(url,tmptitle){
		playurl=url;
		title=tmptitle;
		
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left\'>"+title+"</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["800px", "550px"],
			content: "plugin.php?id=it618_video:sc_media_play'.$adminsid.'&playurl="+playurl,
			cancel: function(index, layero){ 
			}    
		});
	}
    </script>';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/

echo '<script type="text/javascript">
		function check_all(obj,id)
		{
			for(var i=1;i<'.$n.';i++)
			{
				document.getElementById(id+""+i).checked = obj.checked;
			}
		}
	  </script>';
?>