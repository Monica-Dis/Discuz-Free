<?php
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='d')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_video_cdn', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_cdnurl'])) {
		foreach($_GET['it618_cdnurl'] as $id => $val) {

			C::t('#it618_video#it618_video_cdn')->update($id,array(
				'it618_cdnurl' => trim($_GET['it618_cdnurl'][$id]),
				'it618_ossurl' => trim($_GET['it618_ossurl'][$id]),
				'it618_key' => trim($_GET['it618_key'][$id]),
				'it618_time' => trim($_GET['it618_time'][$id]),
				'it618_ishttps' => trim($_GET['it618_ishttps'][$id]),
				'it618_iskeyok' => trim($_GET['it618_iskeyok'][$id]),
				'it618_iscdnok' => trim($_GET['it618_iscdnok'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_cdnurl_array = !empty($_GET['newit618_cdnurl']) ? $_GET['newit618_cdnurl'] : array();
	$newit618_ossurl_array = !empty($_GET['newit618_ossurl']) ? $_GET['newit618_ossurl'] : array();
	$newit618_key_array = !empty($_GET['newit618_key']) ? $_GET['newit618_key'] : array();
	$newit618_time_array = !empty($_GET['newit618_time']) ? $_GET['newit618_time'] : array();
	$newit618_ishttps_array = !empty($_GET['newit618_ishttps']) ? $_GET['newit618_ishttps'] : array();
	$newit618_iskeyok_array = !empty($_GET['newit618_iskeyok']) ? $_GET['newit618_iskeyok'] : array();
	$newit618_iscdnok_array = !empty($_GET['newit618_iscdnok']) ? $_GET['newit618_iscdnok'] : array();
	
	foreach($newit618_cdnurl_array as $key => $value) {
		$newit618_cdnurl = trim($newit618_cdnurl_array[$key]);
		
		if($newit618_cdnurl != '') {
			
			C::t('#it618_video#it618_video_cdn')->insert(array(
				'it618_cdnurl' => trim($newit618_cdnurl_array[$key]),
				'it618_ossurl' => trim($newit618_ossurl_array[$key]),
				'it618_key' => trim($newit618_key_array[$key]),
				'it618_time' => trim($newit618_time_array[$key]),
				'it618_ishttps' => trim($newit618_ishttps_array[$key]),
				'it618_iskeyok' => trim($newit618_iskeyok_array[$key]),
				'it618_iscdnok' => trim($newit618_iscdnok_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_video_lang['s33'].$ok1.' '.$it618_video_lang['s34'].$ok2.' '.$it618_video_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_cdn&pmod=admin_set&cp1=$cp1&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=11)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_cdn&pmod=admin_set&cp1=$cp1&operation=$operation&do=$do");
showtableheaders($strtmptitle[$cp1],'it618_video_class');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_cdn'));
	
	echo '<tr><td colspan=10>'.$it618_video_lang['s1209'].$count.'<span style="float:right;color:red">'.$it618_video_lang['s1214'].'</div></td></tr>';
	showsubtitle(array($it618_video_lang['s1226'], $it618_video_lang['s1210'], $it618_video_lang['s1211'],$it618_video_lang['s1212'],$it618_video_lang['s1862'],$it618_video_lang['s1015'],$it618_video_lang['s1215'],$it618_video_lang['s1213']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_cdn')." ORDER BY id");
	while($it618_video_cdn = DB::fetch($query)) {
		
		if($it618_video_cdn['it618_ishttps']==1)$it618_ishttps_checked='checked="checked"';else $it618_ishttps_checked="";
		if($it618_video_cdn['it618_iskeyok']==1)$it618_iskeyok_checked='checked="checked"';else $it618_iskeyok_checked="";
		if($it618_video_cdn['it618_iscdnok']==1)$it618_iscdnok_checked='checked="checked"';else $it618_iscdnok_checked="";
		
		showtablerow('', array('class="td25"', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"".$it618_video_cdn['id']."\">".$it618_video_cdn['id']."",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_cdnurl[".$it618_video_cdn['id']."]\" value=\"".$it618_video_cdn['it618_cdnurl']."\">",
			"<input type=\"text\" class=\"txt\" style=\"width:350px\" name=\"it618_ossurl[".$it618_video_cdn['id']."]\" value=\"".$it618_video_cdn['it618_ossurl']."\">",
			"<input type=\"text\" class=\"txt\" style=\"width:180px\" name=\"it618_key[".$it618_video_cdn['id']."]\" value=\"".$it618_video_cdn['it618_key']."\">",
			"<input type=\"text\" class=\"txt\" style=\"width:40px;margin-right:3px\" name=\"it618_time[".$it618_video_cdn['id']."]\" value=\"".$it618_video_cdn['it618_time']."\">".$it618_video_lang['s890'],
			'<input type="checkbox" name="it618_ishttps['.$it618_video_cdn['id'].']" style="vertical-align:middle" value="1" '.$it618_ishttps_checked.'>',
			'<input type="checkbox" name="it618_iskeyok['.$it618_video_cdn['id'].']" style="vertical-align:middle" value="1" '.$it618_iskeyok_checked.'>',
			'<input type="checkbox" name="it618_iscdnok['.$it618_video_cdn['id'].']" style="vertical-align:middle" value="1" '.$it618_iscdnok_checked.'>'
		));
	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	$s890=$it618_video_lang['s890'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_cdnurl[]").length;
	
		return [
		[[1,''], [1,'<input type="text" class="txt" style=\"width:200px\" name="newit618_cdnurl[]">'], [1,'<input type="text" class="txt" style=\"width:350px\" name="newit618_ossurl[]">'],[1,'<input type="text" class="txt" style=\"width:180px\" name="newit618_key[]">'],[1,'<input type="text" class="txt" style=\"width:40px;margin-right:3px\" name="newit618_time[]">$s890'], [1,'<input type="checkbox" name="newit618_ishttps[]" style="vertical-align:middle" value="1">'], [1,'<input type="checkbox" name="newit618_iskeyok[]" style="vertical-align:middle" value="1">'], [1,'<input type="checkbox" name="newit618_iscdnok[]" style="vertical-align:middle" value="1">']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="10" style="color:blue">'.$it618_video_lang['s1227'].'</td></tr>';
    echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del');
	if(count($reabc)!=11)return;
showtablefooter(); /*dis'.'m.tao'.'bao.com*/
?>