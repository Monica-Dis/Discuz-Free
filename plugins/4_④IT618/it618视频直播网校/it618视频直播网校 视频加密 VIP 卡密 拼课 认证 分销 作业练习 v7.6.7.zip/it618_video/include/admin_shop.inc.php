<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$it618sql='it618_uid>0';
if($_GET['state']) {
	$state0='';$state1='';$state2='';$state3='';$state4='';
	if($_GET['state']==0){$it618sql .= "";$state0='selected="selected"';}
	if($_GET['state']==1){$it618sql .= " AND it618_state = 0";$state1='selected="selected"';}
	if($_GET['state']==2){$it618sql .= " AND it618_state = 1";$state2='selected="selected"';}
	if($_GET['state']==3){$it618sql .= " AND it618_state = 2";$state3='selected="selected"';}
}

if($_GET['htstate']) {
	$htstate0='';$htstate1='';$htstate2='';$htstate3='';$htstate4='';
	if($_GET['htstate']==0){$it618sql .= "";$htstate0='selected="selected"';}
	if($_GET['htstate']==1){$it618sql .= " AND it618_htstate = 0";$htstate1='selected="selected"';}
	if($_GET['htstate']==2){$it618sql .= " AND it618_htstate = 1";$htstate2='selected="selected"';}
	if($_GET['htstate']==3){$it618sql .= " AND it618_htstate = 2";$htstate3='selected="selected"';}
}

$sql='&key='.$_GET['key'].'&finduid='.$_GET['finduid'].'&state='.$_GET['state'].'&htstate='.$_GET['htstate'];

if(submitcheck('it618submit_del')){
	$del=0;
	if($reabc[6]!='v')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($delid);
		if($it618_video_shop['it618_state']!=2){
			
			C::t('#it618_video#it618_video_shop')->delete_by_id($delid);
			$del=$del+1;
		}else{
			$flag=1;
		}
	}
	
	if($flag==1)$tmpstr='<br><br>'.$it618_video_lang['s1774'];

	cpmsg($it618_video_lang['s153'].$del.$tmpstr, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_pass')){
	$ok=0;
	if($reabc[8]!='d')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($delid);
		$tomonth = date('n'); 
		$todate = date('j'); 
		$toyear = date('Y');
		$it618_htetime=mktime(0, 0, 0, $tomonth, $todate, $toyear+$it618_video['video_httimecount']);
		
		if($it618_video_shop['it618_state']==0){
			C::t('#it618_video#it618_video_shop')->update_pass_by_id($delid,$it618_htetime);
			C::t('#it618_video#it618_video_shop')->update($delid,array(
				'it618_ulogo' => 'source/plugin/it618_video/images/man.jpg',
			));
			$ok=$ok+1;
		}
	}
	cpmsg($it618_video_lang['s154'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_edit')){
	$ok=0;
	if($reabc[9]!='e')return;
	
	if(is_array($_GET['it618_tcbl'])) {
		foreach($_GET['it618_tcbl'] as $id => $val) {
		
			C::t('#it618_video#it618_video_shop')->update($id,array(
				'it618_price' => $_GET['it618_price'][$id],
				'it618_score' => $_GET['it618_score'][$id],
				'it618_livetime' => $_GET['it618_livetime'][$id],
				'it618_wxmessagecount' => $_GET['it618_wxmessagecount'][$id],
				'it618_isdel' => $_GET['it618_isdel'][$id],
				'it618_issale' => $_GET['it618_issale'][$id],
				'it618_issalekm' => $_GET['it618_issalekm'][$id],
				'it618_ischeck' => $_GET['it618_ischeck'][$id],
				'it618_ischeck_audio' => $_GET['it618_ischeck_audio'][$id],
				'it618_ischeck_live' => $_GET['it618_ischeck_live'][$id],
				'it618_istiemedia' => $_GET['it618_istiemedia'][$id],
				'it618_isiframemedia' => $_GET['it618_isiframemedia'][$id],
				'it618_tcbl' => $_GET['it618_tcbl'][$id],
				'it618_order' => $_GET['it618_order'][$id]
			));
	
			$ok=$ok+1;
		}
	}

	cpmsg($it618_video_lang['s155'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_zhuan')){
	$ok=0;
	if($reabc[8]!='d')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$zhuanuid=intval($_GET['zhuanuid']);
		if(DB::result_first("select count(1) from ".DB::table('common_member')." where uid=".$zhuanuid)==0){
			cpmsg($it618_video_lang['s156'], "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'error');
		}else{
			if(DB::result_first("select count(1) from ".DB::table('it618_video_shop')." where it618_uid=".$zhuanuid)>0){
				cpmsg($it618_video_lang['s157'], "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'error');
			}
		}
		
		$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." where id=".$delid);
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$zhuanuid);
		
		C::t('#it618_video#it618_video_shop')->update_it618_uid_by_id($delid,$zhuanuid);
		DB::query("update ".DB::table('it618_video_goods')." set it618_shopuid=".$it618_video_shop['it618_uid']." where it618_shopid=".$delid);
		cpmsg($it618_video_lang['s158'].$it618_video_shop['it618_name'].$it618_video_lang['s159'].$username.' '.$it618_video_lang['s37'], "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
		break;
	}
}

if(submitcheck('it618submit_nopass')){
	$ok=0;
	if($reabc[8]!='d')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($delid);
		
		if($it618_video_shop['it618_state']==0){
			C::t('#it618_video#it618_video_shop')->update_it618_state_by_id($delid,1);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_video_lang['s160'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_editht')){
	$ok=0;
	if($reabc[8]!='d')return;
	$time=mktime(0, 0, 0, $_GET['sel_month'], $_GET['sel_date'], $_GET['sel_year']);
	if($_G['timestamp']>=$time){
		cpmsg($it618_video_lang['s161'], "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
	}
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($delid);
		
		if($it618_video_shop['it618_state']==2){
			$isviptbtime=0;
			if($IsGroup==1){
				if($it618_group_rzmoney=C::t('#it618_group#it618_group_rzmoney')->fetch_by_shoptype_lid('video',0)){
					if($it618_group_rzmoney['it618_istbtime']==1){
						$isviptbtime=1;
					}
				}
			}
			if($isviptbtime==0){
				C::t('#it618_video#it618_video_shop')->update_it618_htetime_by_id($delid,$time);
				if($_G['timestamp']>=$time){
					C::t('#it618_video#it618_video_shop')->update_it618_htstate_by_id($delid,2);
				}else{
					C::t('#it618_video#it618_video_shop')->update_it618_htstate_by_id($delid,1);
				}
				$ok=$ok+1;
			}
		}
	}

	cpmsg($it618_video_lang['s162'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_clock')){
	$ok=0;
	if($reabc[8]!='d')return;

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($delid);
		
		if($it618_video_shop['it618_state']==2){
			C::t('#it618_video#it618_video_shop')->update_it618_htstate_by_id($delid,0);
			C::t('#it618_video#it618_video_shop')->fetch_by_id($delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_video_lang['s163'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_unclock')){
	$ok=0;
	if($reabc[8]!='d')return;

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($delid);
		
		if($it618_video_shop['it618_state']==2){
			C::t('#it618_video#it618_video_shop')->update_it618_htstate_by_id($delid,1);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_video_lang['s164'].$ok, "action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1&page=$page".$sql, 'succeed');
}

if(count($reabc)!=11)return;

echo '
<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/kindeditor-min.js"></script>
';

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1");
showtableheaders($it618_video_lang['s562'].'<span style="float:right">'.$it618_video_lang['s1682'].'</span>','it618_store_renzheng');
	showsubmit('it618sercsubmit', $it618_video_lang['s25'], $it618_video_lang['s166'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:100px" /> '.$it618_video_lang['s167'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> '.$it618_video_lang['s170'].' <select name="state"><option value=0 '.$state0.'>'.$it618_video_lang['s169'].'</option><option value=1 '.$state1.'>'.$it618_video_lang['s171'].'</option><option value=2 '.$state2.'>'.$it618_video_lang['s172'].'</option><option value=3 '.$state3.'>'.$it618_video_lang['s173'].'</option></select> '.$it618_video_lang['s174'].' <select name="htstate"><option value=0 '.$htstate0.'>'.$it618_video_lang['s169'].'</option><option value=1 '.$htstate1.'>'.$it618_video_lang['s175'].'</option><option value=2 '.$htstate2.'>'.$it618_video_lang['s176'].'</option><option value=3 '.$htstate3.'>'.$it618_video_lang['s177'].'</option></select>');
	
	$count = C::t('#it618_video#it618_video_shop')->count_by_search($it618sql,'',$_GET['key'],$_GET['finduid']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&cp1=$cp1".$sql);
	
	echo '<tr><td colspan=14>'.$it618_video_lang['s178'].$count.'<span style="float:right;color:red">'.$it618_video_lang['s809'].'</span></td></tr>';
	showsubtitle(array('', $it618_video_lang['s179'],$it618_video_lang['s868'],$it618_video_lang['s180'],$it618_video_lang['s869'],$it618_video_lang['s185']));
	
	foreach(C::t('#it618_video#it618_video_shop')->fetch_all_by_search(
		$it618sql,'it618_order desc,id DESC',$_GET['key'],$_GET['finduid'],$startlimit,$ppp
	) as $it618_video_shop) {
		
		$username=C::t('#it618_video#it618_video_sale')->fetch_username_by_uid($it618_video_shop['it618_uid']);
		
		$salecountstr='';$salemoneystr='';
		if($it618_video_shop['it618_state']==2){
			$pcount1=C::t('#it618_video#it618_video_goods')->count_by_shopid_state($it618_video_shop['id'],0);
			$pcount2=C::t('#it618_video#it618_video_goods')->count_by_shopid_state($it618_video_shop['id'],1);
			$pcount3=C::t('#it618_video#it618_video_goods')->count_by_shopid_state($it618_video_shop['id'],2);

			$salecount=C::t('#it618_video#it618_video_sale')->sumcount_by_shopid($it618_video_shop['id']);
			$salemoney=C::t('#it618_video#it618_video_sale')->summoney_by_shopid($it618_video_shop['id']);
			
			$tcmoney=C::t('#it618_video#it618_video_sale')->sumtcmoney_by_shopid($it618_video_shop['id']);
			$ktxmoney=C::t('#it618_video#it618_video_shop')->fetch_money_by_id($it618_video_shop['id']);
			$sqmoney=C::t('#it618_video#it618_video_tx')->sumtxmoney_by_shopid_state($it618_video_shop['id'],1);
			$txmoney=C::t('#it618_video#it618_video_tx')->sumtxmoney_by_shopid_state($it618_video_shop['id'],2);
			if($sqmoney=='')$sqmoney='0.00';
			if($txmoney=='')$txmoney='0.00';else $txmoney=round($txmoney,2);
			$txtc=C::t('#it618_video#it618_video_tx')->sumtxtc_by_shopid($it618_video_shop['id']);
		}
		
		if($salesum=="")$salesum=0;
		
		if($it618_video_shop['it618_state']==0)$it618_state='<font color=red>'.$it618_video_lang['s171'].'</font>';
		if($it618_video_shop['it618_state']==1)$it618_state='<font color=blue>'.$it618_video_lang['s172'].'</font>';
		if($it618_video_shop['it618_state']==2)$it618_state='<font color=green>'.$it618_video_lang['s173'].'</font>';
		
		if($it618_video_shop['it618_state']==2){
			if($it618_video_shop['it618_htstate']==0)$it618_htstate='<font color=red>'.$it618_video_lang['s175'].'</font>';
			if($it618_video_shop['it618_htstate']==1)$it618_htstate='<font color=green>'.$it618_video_lang['s176'].'</font>';
			if($it618_video_shop['it618_htstate']==2)$it618_htstate='<font color=#ccc>'.$it618_video_lang['s177'].'</font>';
			$httime=date('Y-m-d', $it618_video_shop['it618_htetime']);
			
			if($IsGroup==1){
				if($it618_group_rzmoney=C::t('#it618_group#it618_group_rzmoney')->fetch_by_shoptype_lid('video',0)){
					if($it618_group_rzmoney['it618_istbtime']==1){
						if($it618_group_group_user=C::t('#it618_group#it618_group_group_user')->fetch_by_groupid_uid($it618_group_rzmoney['it618_groupid'],$it618_video_shop['it618_uid'])){
							if($it618_group_group_user['it618_etime']>0){
								$httime='VIP:'.date('Y-m-d', $it618_group_group_user['it618_etime']);
							}else{
								$httime='VIP:'.$it618_video_lang['s1153'];
							}
						}else{
							$httime='VIP:'.$it618_video_lang['s1224'];
						}
					}
				}
			}
		}else{
			$it618_htstate='';	
			$httime='';
		}
		
		if($it618_video_shop['it618_isdel']==1)$it618_isdel_checked='checked="checked"';else $it618_isdel_checked="";
		if($it618_video_shop['it618_issale']==1)$it618_issale_checked='checked="checked"';else $it618_issale_checked="";
		if($it618_video_shop['it618_issalekm']==1)$it618_issalekm_checked='checked="checked"';else $it618_issalekm_checked="";
		if($it618_video_shop['it618_ischeck']==1)$it618_ischeck_checked='checked="checked"';else $it618_ischeck_checked="";
		if($it618_video_shop['it618_ischeck_audio']==1)$it618_ischeck_audio_checked='checked="checked"';else $it618_ischeck_audio_checked="";
		if($it618_video_shop['it618_ischeck_live']==1)$it618_ischeck_live_checked='checked="checked"';else $it618_ischeck_live_checked="";
		if($it618_video_shop['it618_istiemedia']==1)$it618_istiemedia_checked='checked="checked"';else $it618_istiemedia_checked="";
		if($it618_video_shop['it618_isiframemedia']==1)$it618_isiframemedia_checked='checked="checked"';else $it618_isiframemedia_checked="";
		
		$goodscount = $pcount1+$pcount2+$pcount3;
		
		$creditnum=C::t('#it618_video#it618_video_sale')->fetch_extcredits_by_uid($it618_video['video_credit'],$it618_video_shop['it618_uid']);
		if($creditnum=="")$creditnum=0;
		
		$wmfallcount = C::t('#it618_video#it618_video_media_shopwmf')->count_all_by_shopid($it618_video_shop['id']);
		$wmfokcount = C::t('#it618_video#it618_video_media_shopwmf')->count_ok_by_shopid($it618_video_shop['id']);
		
		$count = C::t('#it618_video#it618_video_media')->count_by_search('','',$it618_video_shop['id']);
		$sumsize = C::t('#it618_video#it618_video_media')->sum_size_by_search('','',$it618_video_shop['id']);
		$summtscount = C::t('#it618_video#it618_video_media')->sum_mtscount_by_search('','',$it618_video_shop['id']);
		$summtssize = C::t('#it618_video#it618_video_media')->sum_mtssize_by_search('','',$it618_video_shop['id']);
		
		$aossallcount = C::t('#it618_video#it618_video_media_shopaoss')->count_all_by_shopid($it618_video_shop['id']);
		$aossokcount = C::t('#it618_video#it618_video_media_shopaoss')->count_ok_by_shopid($it618_video_shop['id']);
		
		$acount = C::t('#it618_video#it618_video_media_audio')->count_by_search('it618_osstype=0','',$it618_video_shop['id']);
		$asumsize = C::t('#it618_video#it618_video_media_audio')->sum_size_by_search('it618_osstype=0','',$it618_video_shop['id']);
		
		$acount1 = C::t('#it618_video#it618_video_media_audio')->count_by_search('it618_osstype=1','',$it618_video_shop['id']);
		$asumsize1 = C::t('#it618_video#it618_video_media_audio')->sum_size_by_search('it618_osstype=1','',$it618_video_shop['id']);
		
		$livesetallcount = C::t('#it618_video#it618_video_shopliveset')->count_all_by_shopid($it618_video_shop['id']);
		$livesetokcount = C::t('#it618_video#it618_video_shopliveset')->count_ok_by_shopid($it618_video_shop['id']);
		
		$livecount = C::t('#it618_video#it618_video_live')->count_by_shopid_chkstate($it618_video_shop['id'],1);
		$liveallcount = C::t('#it618_video#it618_video_live')->count_by_shopid($it618_video_shop['id']);
		
		$preurl=ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_shop&pmod=admin_shop&operation=$operation&do=$do&page=$page".$sql;
		$preurl=str_replace("&","@",$preurl);
		
		$it618_ulogo='src="source/plugin/it618_video/images/man.jpg"';
		if($it618_video_shop['it618_ulogo']!='')$it618_ulogo='src="'.$it618_video_shop['it618_ulogo'].'"';
		
		$tmpurl=it618_video_getrewrite('video_lecturer',$it618_video_shop['id'],'plugin.php?id=it618_video:lecturer&lid='.$it618_video_shop['id']);
		
		$adminstr='';
		if($it618_video_shop['it618_state']==2){
			$adminurl=it618_video_getrewrite('video_sc','','plugin.php?id=it618_video:sc&adminsid='.$it618_video_shop['id'],'?adminsid='.$it618_video_shop['id']);
			$adminstr='<a href="'.$adminurl.'" target="_blank">'.$it618_video_lang['s1434'].'</a>';
		}
		
		
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_video_shop['id'].'" name="delete[]" value="'.$it618_video_shop['id'].'" '.$disabled.'><input type="hidden" name="id['.$it618_video_shop['id'].']" value="'.$it618_video_shop['id'].'"><label for="chk_del'.$it618_video_shop['id'].'">'.$it618_video_shop['id'].'</label>',
			'<div style="float:left;width:68px;"><a href="'.$tmpurl.'" target="_blank">
			<img '.$it618_ulogo.' width=58 height=58 style="margin-bottom:5px; border-radius:30px;border:none">
			</a>
			</div>
			<div style="float:left;width:380px;margin-left:6px;line-height:20px"><span style="font-size:13px;color:#666"><strong>'.$it618_video_shop['it618_name'].'</strong></span> <a href="javascript:" id="about'.$it618_video_shop['id'].'">'.$it618_video_lang['s186'].'</a> '.$it618_state.' '.$adminstr.'<br>'.$it618_video_lang['s188'].'<a href="home.php?mod=space&uid='.$it618_video_shop['it618_uid'].'" target="_blank">'.$username.'</a> '.$it618_video_lang['s189'].$httime.' '.$it618_video_lang['s190'].$it618_htstate.'<br>'.$it618_video_lang['s1083'].'<input class="txt" style="width:50px;margin-right:3px;color:green;font-weight:bold" type="text" name="it618_score['.$it618_video_shop['id'].']" value="'.$it618_video_shop['it618_score'].'">/<font color=red>'.$creditnum.'</font>'.$creditname.' <span style="display:none">'.$it618_video_lang['s940'].'<input class="txt" style="width:50px;margin-right:3px;color:blue;font-weight:bold" type="text" name="it618_price['.$it618_video_shop['id'].']" value="'.$it618_video_shop['it618_price'].'">'.$it618_video_lang['s941'].'</span><br><input type="checkbox" id="issale'.$it618_video_shop['id'].'" name="it618_issale['.$it618_video_shop['id'].']" style="vertical-align:middle" value="1" '.$it618_issale_checked.'><label for="issale'.$it618_video_shop['id'].'" style="color:blue">'.$it618_video_lang['s1708'].'</label><br><input type="checkbox" id="issalekm'.$it618_video_shop['id'].'" name="it618_issalekm['.$it618_video_shop['id'].']" style="vertical-align:middle" value="1" '.$it618_issalekm_checked.'><label for="issalekm'.$it618_video_shop['id'].'">'.$it618_video_lang['s2314'].'</label><br><input type="checkbox" id="ischeck'.$it618_video_shop['id'].'" name="it618_ischeck['.$it618_video_shop['id'].']" style="vertical-align:middle" value="1" '.$it618_ischeck_checked.'><label for="ischeck'.$it618_video_shop['id'].'">'.$it618_video_lang['s1788'].'</label><br><input type="checkbox" id="ischeck_audio'.$it618_video_shop['id'].'" name="it618_ischeck_audio['.$it618_video_shop['id'].']" style="vertical-align:middle" value="1" '.$it618_ischeck_audio_checked.'><label for="ischeck_audio'.$it618_video_shop['id'].'">'.$it618_video_lang['s1789'].'</label><br><input type="checkbox" id="ischeck_live'.$it618_video_shop['id'].'" name="it618_ischeck_live['.$it618_video_shop['id'].']" style="vertical-align:middle" value="1" '.$it618_ischeck_live_checked.'><label for="ischeck_live'.$it618_video_shop['id'].'">'.$it618_video_lang['s1267'].'</label><br><input type="checkbox" id="istiemedia'.$it618_video_shop['id'].'" name="it618_istiemedia['.$it618_video_shop['id'].']" style="vertical-align:middle" value="1" '.$it618_istiemedia_checked.'><label for="istiemedia'.$it618_video_shop['id'].'">'.$it618_video_lang['s1529'].'</label> <input type="checkbox" id="isiframemedia'.$it618_video_shop['id'].'" name="it618_isiframemedia['.$it618_video_shop['id'].']" style="vertical-align:middle" value="1" '.$it618_isiframemedia_checked.'><label for="isiframemedia'.$it618_video_shop['id'].'">'.$it618_video_lang['s1530'].'</label><br><input type="checkbox" id="isdel'.$it618_video_shop['id'].'" name="it618_isdel['.$it618_video_shop['id'].']" style="vertical-align:middle" value="1" '.$it618_isdel_checked.'><label for="isdel'.$it618_video_shop['id'].'">'.$it618_video_lang['s1603'].'</label><br>'.$it618_video_lang['s1917'].'<input class="txt" style="width:58px;margin-right:0;color:green;font-weight:bold" type="text" name="it618_wxmessagecount['.$it618_video_shop['id'].']" value="'.$it618_video_shop['it618_wxmessagecount'].'"></div>',
			'<div style="line-height:19px"><a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_shop&cp=admin_shopwmf&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&sid='.$it618_video_shop['id'].'&preurl='.$preurl.'">'.$it618_video_lang['s830'].'(<font color=red>'.$wmfokcount.'</font>/<font color=red>'.$wmfallcount.'</font>)</a><br>
			'.$it618_video_lang['s852'].$count.' '.$it618_video_lang['s583'].round((($sumsize+$summtssize)/1024/1024),2).'M '.$it618_video_lang['s584'].round(($sumsize/1024/1024),2).'M<br>'.$it618_video_lang['s585'].$summtscount.' '.$it618_video_lang['s586'].round(($summtssize/1024/1024),2).'M<br>
			<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_shop&cp=admin_shopaoss&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&sid='.$it618_video_shop['id'].'&preurl='.$preurl.'">'.$it618_video_lang['s534'].'(<font color=red>'.$aossokcount.'</font>/<font color=red>'.$aossallcount.'</font>)</a><br>
			'.$it618_video_lang['s1204'].$acount.'/'.round(($asumsize/1024/1024),2).'M '.$it618_video_lang['s1205'].$acount1.'/'.round(($asumsize1/1024/1024),2).'M<br>
			<a href="'.ADMINSCRIPT.'?action=plugins&pmod=admin_shop&cp=admin_shopliveset&identifier='.$identifier.'&operation='.$operation.'&do='.$do.'&sid='.$it618_video_shop['id'].'&preurl='.$preurl.'">'.$it618_video_lang['s1268'].'(<font color=red>'.$livesetokcount.'</font>/<font color=red>'.$livesetallcount.'</font>)</a><br>'.$it618_video_lang['s1269'].$livecount.'/'.$liveallcount.'
			<br>'.$it618_video_lang['s1491'].'<input class="txt" style="width:80px;margin-right:3px;color:green;font-weight:bold" type="text" name="it618_livetime['.$it618_video_shop['id'].']" value="'.$it618_video_shop['it618_livetime'].'">'.$it618_video_lang['s1485'].'
			<br>'.$it618_video_lang['s788'].'<input class="txt" style="width:58px;margin-top:3px;" type="text" name="it618_order['.$it618_video_shop['id'].']" value="'.$it618_video_shop['it618_order'].'">
			</div>',
			$it618_video_lang['s103'].'(<font color=red>'.$pcount1.'</font>)<br>'.$it618_video_lang['s104'].'(<font color=red>'.$pcount2.'</font>)<br>'.$it618_video_lang['s105'].'(<font color=red>'.$pcount3.'</font>)',
			$it618_video_lang['s853'].'<input class="txt" style="width:40px;margin-right:0;color:green;font-weight:bold" type="text" name="it618_tcbl['.$it618_video_shop['id'].']" value="'.$it618_video_shop['it618_tcbl'].'">%<br>'.$it618_video_lang['s857'].$salemoney.'<br>'.$it618_video_lang['s858'].'<font color=red>'.$tcmoney.'</font>',
			$it618_video_lang['s196'].'(<font color=red>'.$ktxmoney.'</font>)<br>'.$it618_video_lang['s197'].'(<font color=red>'.$sqmoney.'</font>)<br>'.$it618_video_lang['s198'].'(<font color=red>'.$txmoney.'</font>)<br>'.$it618_video_lang['s199'].'(<font color=red>'.round($txtc,2).'</font>)'
		));
		
		$morecontent=$it618_video_lang['s200'];
		$morecontent=str_replace("{name}",$it618_video_shop['it618_name'],$morecontent);
		$morecontent=str_replace("{tel}",$it618_video_shop['it618_tel'],$morecontent);
		$morecontent=str_replace("{qq}",$it618_video_shop['it618_qq'],$morecontent);
		$morecontent=str_replace("{about}",$it618_video_shop['it618_about'],$morecontent);
		$morecontent=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_shop['it618_time']),$morecontent);
		
		$morecontent=str_replace("'","\"",$morecontent);
		$morecontent=str_replace(array("\r\n", "\r", "\n"),"",$morecontent);
		$tmpjs.='KindEditor.ready(function(K) {K(\'#about'.$it618_video_shop['id'].'\').click(function() {
			var dialog = K.dialog({
				width : 500,
				height : 300,
				title : \''.$it618_video_lang['s288'].'\',
				body : \'<div style="margin:10px;">'.$morecontent.'</div>\',
				closeBtn : {
					name : \''.$it618_video_lang['s289'].'\',
					click : function(e) {
						dialog.remove();
					}
				},
				noBtn : {
					name : \''.$it618_video_lang['s289'].'\',
					click : function(e) {
						dialog.remove();
					}
				}
			});
		});});';
		
	}
	
	$tmptime=date('Y-m-d H:i:s', $_G['timestamp']);
	$timearr=explode(" ",$tmptime);
	$timearr1=explode("-",$timearr[0]);
	$timearr2=explode(":",$timearr[1]);
	//
	$strtmp="";
	for($i=2013;$i<=2050;$i++){
		if($timearr1[0]==$i){
			$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
		}else{
			$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
		}
	}
	$sel_year='<select name="sel_year">'.$strtmp.'</select>';
	
	//
	$strtmp="";
	for($i=1;$i<=12;$i++){
		if($timearr1[1]==$i){
			$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
		}else{
			$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
		}
	}
	$sel_month='<select name="sel_month">'.$strtmp.'</select>';
	
	//
	$strtmp="";
	for($i=1;$i<=31;$i++){
		if($timearr1[2]==$i){
			$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
		}else{
			$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
		}
	}
	$sel_date='<select name="sel_date">'.$strtmp.'</select>';
	
	function towstr($i){
		if(strlen($i)==1)return "0".$i;else return $i;
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_video_lang['s129'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel" style="line-height:20px"><input type="submit" class="btn" name="it618submit_del" value="'.$it618_video_lang['s201'].'" onclick="return confirm(\''.$it618_video_lang['s202'].'\')" /> <input type="submit" class="btn" name="it618submit_edit" value="'.$it618_video_lang['s203'].'"/> <input type="submit" class="btn" name="it618submit_pass" value="'.$it618_video_lang['s204'].'" onclick="return confirm(\''.$it618_video_lang['s205'].'\')"/> <input type="submit" class="btn" name="it618submit_nopass" value="'.$it618_video_lang['s206'].'" onclick="return confirm(\''.$it618_video_lang['s207'].'\')"/><br>'.$it618_video_lang['s208'].' '.$sel_year.$sel_month.$sel_date.'<input type="submit" class="btn" name="it618submit_editht" value="'.$it618_video_lang['s209'].'" onclick="return confirm(\''.$it618_video_lang['s210'].'\')"/> <input type="submit" class="btn" name="it618submit_clock" value="'.$it618_video_lang['s211'].'" onclick="return confirm(\''.$it618_video_lang['s212'].'\')"/> <input type="submit" class="btn" name="it618submit_unclock" value="'.$it618_video_lang['s213'].'" onclick="return confirm(\''.$it618_video_lang['s214'].'\')"/> <font color=red>'.$it618_video_lang['s215'].'</font><br>'.$it618_video_lang['s216'].'<input type="test" id="zhuanuid" name="zhuanuid" style="width:50px"> <input type="submit" class="btn" name="it618submit_zhuan" value="'.$it618_video_lang['s217'].'" onclick="return checkone()"  /><br>'.$it618_video_lang['s1492'].'<br>'.$it618_video_lang['s1709'].' &nbsp;<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=11)return;
showtablefooter(); /*dis'.'m.tao'.'bao.com*/
echo '<script>'.$tmpjs.'</script>';
echo  '<script>
		function checkone(){
		var inputs = document.getElementsByName("delete[]");
		var checked_counts = 0;
		for(var i=0;i<inputs.length;i++){
			if(inputs[i].checked){
				checked_counts++;
			}
		}
		if(checked_counts==0){
			alert("'.$it618_video_lang['s218'].'");
			return false;
		}
		if(checked_counts>1){
			alert("'.$it618_video_lang['s219'].'");
			return false;
		}
		if(document.getElementById("zhuanuid").value==""){
			alert("'.$it618_video_lang['s220'].'");
			return false;
		}
		return confirm(\''.$it618_video_lang['s221'].'\');
		}
		</script>';
?>