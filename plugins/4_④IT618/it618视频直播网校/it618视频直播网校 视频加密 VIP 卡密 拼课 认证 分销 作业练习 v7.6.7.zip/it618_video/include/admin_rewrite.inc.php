<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/rewrite.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_video/config/rewrite.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_video/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$video_home=\''.'video'."';\n";
		$fileData .= '$video_list=\''.'video_list'."';\n";
		$fileData .= '$video_search=\''.'video_search'."';\n";
		$fileData .= '$video_gwc=\''.'video_gwc'."';\n";
		$fileData .= '$video_product=\''.'course'."';\n";
		$fileData .= '$video_lesson=\''.'lesson'."';\n";
		$fileData .= '$video_lecturer=\''.'lecturer'."';\n";
		$fileData .= '$video_sc=\''.'video_sc'."';\n";
		$fileData .= '$video_wap=\''.'video_wap'."';\n";
		
		$urltype='.html';
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$video_home1=\''.$urltype."';\n";
		$fileData .= '$video_list1=\'-{cid1}-{cid2}-{price}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$video_search1=\'-{cid1}-{cid2}-{price}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$video_gwc1=\''.$urltype."';\n";
		$fileData .= '$video_product1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$video_lesson1=\'-{lid}'.$urltype."';\n";
		$fileData .= '$video_lecturer1=\'-{lid}'.$urltype."';\n";
		$fileData .= '$video_sc1=\''.$urltype."';\n";
		$fileData .= '$video_wap1=\'-{pagetype}-{cid1}-{cid2}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		require DISCUZ_ROOT.'./source/plugin/it618_video/config/rewrite.php';
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_video/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$video_home=\''.str_replace("-","",$_GET['video_home'])."';\n";
		$fileData .= '$video_list=\''.str_replace("-","",$_GET['video_list'])."';\n";
		$fileData .= '$video_search=\''.str_replace("-","",$_GET['video_search'])."';\n";
		$fileData .= '$video_gwc=\''.str_replace("-","",$_GET['video_gwc'])."';\n";
		$fileData .= '$video_product=\''.str_replace("-","",$_GET['video_product'])."';\n";
		$fileData .= '$video_lesson=\''.str_replace("-","",$_GET['video_lesson'])."';\n";
		$fileData .= '$video_lecturer=\''.str_replace("-","",$_GET['video_lecturer'])."';\n";
		$fileData .= '$video_sc=\''.str_replace("-","",$_GET['video_sc'])."';\n";
		$fileData .= '$video_wap=\''.str_replace("-","",$_GET['video_wap'])."';\n";
		
		$urltype=str_replace("-","",$_GET['urltype']);
		$urltype=str_replace("?","",$_GET['urltype']);
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$video_home1=\''.$urltype."';\n";
		$fileData .= '$video_list1=\'-{cid1}-{cid2}-{price}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$video_search1=\'-{cid1}-{cid2}-{price}-{order}-{page}'.$urltype."';\n";
		$fileData .= '$video_gwc1=\''.$urltype."';\n";
		$fileData .= '$video_product1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$video_lesson1=\'-{lid}'.$urltype."';\n";
		$fileData .= '$video_lecturer1=\'-{lid}'.$urltype."';\n";
		$fileData .= '$video_sc1=\''.$urltype."';\n";
		$fileData .= '$video_wap1=\'-{pagetype}-{cid1}-{cid2}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_video_lang['s16'], "action=plugins&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_rewrite&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$strtmptitle[$cp1].'</th></tr>
<tr><td class="vtop tips2" colspan="3">'.$it618_video_lang['s136'].'</font></td></tr>
<tr><td colspan="3">'.$it618_video_lang['s137'].'<input name="urltype" value="'.$urltype.'"/></td></tr>
<tr class="header"><th>'.$it618_video_lang['s138'].'</th><th>'.$it618_video_lang['s139'].'</th><th>'.$it618_video_lang['s140'].'</th></tr>
<tr class="hover">
<td>'.$it618_video_lang['s141'].'</td><td></td><td class="longtxt"><input name="video_home" value="'.$video_home.'"/>'.$video_home.$video_home1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_video_lang['s142'].'</td><td>{cid1}, {cid2}, {price}, {order}, {page}</td><td class="longtxt"><input name="video_list" value="'.$video_list.'" />'.$video_list.$video_list1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_video_lang['s143'].'</td><td>{cid1}, {cid2}, {price}, {order}, {page}</td><td class="longtxt"><input name="video_search" value="'.$video_search.'" />'.$video_search.$video_search1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_video_lang['s1071'].'</td><td></td><td class="longtxt"><input name="video_gwc" value="'.$video_gwc.'"/>'.$video_gwc.$video_gwc1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_video_lang['s144'].'</td><td>{pid}</td><td class="longtxt"><input name="video_product" value="'.$video_product.'" />'.$video_product.$video_product1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_video_lang['s145'].'</td><td>{lid}</td><td class="longtxt"><input name="video_lesson" value="'.$video_lesson.'" />'.$video_lesson.$video_lesson1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_video_lang['s766'].'</td><td>{lid}</td><td class="longtxt"><input name="video_lecturer" value="'.$video_lecturer.'" />'.$video_lecturer.$video_lecturer1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_video_lang['s146'].'</td><td></td><td class="longtxt"><input name="video_sc" value="'.$video_sc.'"/>'.$video_sc.$video_sc1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_video_lang['s147'].'</td><td>{pagetype}, {cid1}, {cid2}</td><td class="longtxt"><input name="video_wap" value="'.$video_wap.'"/>'.$video_wap.$video_wap1.'</td>
</tr>
</table>
';

showsubmit('it618submit', $it618_video_lang['s23']);

$urltype1=$urltype;
if($urltype!='')$urltype=str_replace(".","\\.",$urltype);

$strtmp= '<br><h1>'.$it618_video_lang['s148'].'</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
	<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$video_home.$urltype.'$ $1/plugin.php?id=it618_video:index&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$video_list.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:list&class1=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$video_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:list&class1=$2&class2=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$video_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:list&class1=$2&class2=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$video_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:list&class1=$2&class2=$3&price=$4&order=$5&page=$6&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$video_search.$urltype.'$ $1/plugin.php?id=it618_video:search&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$video_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:search&class1=$2&class2=$3&price=$4&order=$5&page=$6&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$video_gwc.$urltype.'$ $1/plugin.php?id=it618_video:gwc&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$video_product.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:product&pid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$video_lesson.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:lesson&lid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$video_lecturer.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:lecturer&lid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$video_sc.$urltype.'$ $1/plugin.php?id=it618_video:sc&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$video_wap.$urltype.'$ $1/plugin.php?id=it618_video:wap&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$video_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:wap&pagetype=$2&cid1=$3&cid2=$4&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$video_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:wap&pagetype=$2&cid=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$video_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_video:wap&pagetype=$2&%1</font>
&lt;/IfModule&gt;
</pre>

<h1>'.$it618_video_lang['s149'].'</h1>
<pre class="colorbox">
'.$it618_video_lang['s150'].'
<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$video_home.$urltype.'$ plugin.php?id=it618_video:index&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$video_list.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_video:list&class1=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$video_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_video:list&class1=$1&class2=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$video_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_video:list&class1=$1&class2=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$video_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_video:list&class1=$1&class2=$2&area1=$3&order=$4&page=$5&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$video_search.$urltype.'$ plugin.php?id=it618_video:search&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$video_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_video:search&class1=$1&class2=$2&price=$3&order=$4&page=$5&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$video_gwc.$urltype.'$ plugin.php?id=it618_video:gwc&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$video_product.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_video:product&pid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$video_lesson.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_video:lesson&lid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$video_lecturer.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_video:lecturer&lid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$video_sc.$urltype.'$ plugin.php?id=it618_video:sc&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$video_wap.$urltype.'$ plugin.php?id=it618_video:wap&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$video_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_video:wap&pagetype=$1&cid1=$2&cid2=$3&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$video_wap.'-(.+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_video:wap&pagetype=$1&cid=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$video_wap.'-(.+)'.$urltype.'$ plugin.php?id=it618_video:wap&pagetype=$1&%1</font>

</pre>

<h1>'.$it618_video_lang['s151'].'</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
<font color=blue>RewriteRule ^(.*)/'.$video_home.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_video:index&$3
RewriteRule ^(.*)/'.$video_list.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_video:list&class1=$2&$4
RewriteRule ^(.*)/'.$video_list.'-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_video:list&class1=$2&class2=$3&$5
RewriteRule ^(.*)/'.$video_list.'-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_video:list&class1=$2&class2=$3&$5
RewriteRule ^(.*)/'.$video_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_video:list&class1=$2&class2=$3&price=$4&order=$5&page=$6&$8
RewriteRule ^(.*)/'.$video_search.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_video:search&$3
RewriteRule ^(.*)/'.$video_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_video:search&class1=$2&class2=$3&price=$4&order=$5&page=$6&$8
RewriteRule ^(.*)/'.$video_gwc.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_video:gwc&$3
RewriteRule ^(.*)/'.$video_product.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_video:product&pid=$2&$4
RewriteRule ^(.*)/'.$video_lesson.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_video:lesson&lid=$2&$4
RewriteRule ^(.*)/'.$video_lecturer.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_video:lecturer&lid=$2&$4
RewriteRule ^(.*)/'.$video_sc.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_video:sc&$3
RewriteRule ^(.*)/'.$video_wap.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_video:wap&$3
RewriteRule ^(.*)/'.$video_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_video:wap&pagetype=$2&cid1=$3&cid2=$4&$6
RewriteRule ^(.*)/'.$video_wap.'-(.+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_video:wap&pagetype=$2&cid=$3&$5
RewriteRule ^(.*)/'.$video_wap.'-(.+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_video:wap&pagetype=$2&$4</font>

</pre>

<h1>'.$it618_video_lang['s152'].'</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
		<font color=blue>&lt;rule name="video_home"&gt;
			&lt;match url="^(.*/)*'.$video_home.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_video:index&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="video_list1"&gt;
			&lt;match url="^(.*/)*'.$video_list.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_video:list&amp;amp;class1={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="video_list2"&gt;
			&lt;match url="^(.*/)*'.$video_list.'-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_video:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="video_list3"&gt;
			&lt;match url="^(.*/)*'.$video_list.'-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_video:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="video_list4"&gt;
			&lt;match url="^(.*/)*'.$video_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_video:list&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;price={R:4}&amp;amp;order={R:5}&amp;amp;page={R:6}&amp;amp;{R:7}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="video_search"&gt;
			&lt;match url="^(.*/)*'.$video_search.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_video:search&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="video_search1"&gt;
			&lt;match url="^(.*/)*'.$video_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_video:search&amp;amp;class1={R:2}&amp;amp;class2={R:3}&amp;amp;price={R:4}&amp;amp;order={R:5}&amp;amp;page={R:6}&amp;amp;{R:7}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="video_gwc"&gt;
			&lt;match url="^(.*/)*'.$video_gwc.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_video:gwc&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="video_product"&gt;
			&lt;match url="^(.*/)*'.$video_product.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_video:product&amp;amp;pid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="video_lesson"&gt;
			&lt;match url="^(.*/)*'.$video_lesson.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_video:lesson&amp;amp;lid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="video_lecturer"&gt;
			&lt;match url="^(.*/)*'.$video_lecturer.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_video:lecturer&amp;amp;lid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="video_sc"&gt;
			&lt;match url="^(.*/)*'.$video_sc.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_video:sc&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="video_wap"&gt;
			&lt;match url="^(.*/)*'.$video_wap.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_video:wap&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="video_wap1"&gt;
			&lt;match url="^(.*/)*'.$video_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_video:wap&amp;amp;pagetype={R:2}&amp;amp;cid1={R:3}&amp;amp;cid2={R:4}&amp;amp;{R:5}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="video_wap2"&gt;
			&lt;match url="^(.*/)*'.$video_wap.'-(.+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_video:wap&amp;amp;pagetype={R:2}&amp;amp;cid={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="video_wap3"&gt;
			&lt;match url="^(.*/)*'.$video_wap.'-(.+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_video:wap&amp;amp;pagetype={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;</font>
	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
<font color=blue>match URL into $ with ^(.*)/'.$video_home.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_video:index&$2
endif
match URL into $ with ^(.*)/'.$video_list.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_video:list&class1=$2&$3
endif
match URL into $ with ^(.*)/'.$video_list.'-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_video:list&class1=$2&class2=$3&$4
endif
match URL into $ with ^(.*)/'.$video_list.'-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_video:list&class1=$2&class2=$3&$4
endif
match URL into $ with ^(.*)/'.$video_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_video:list&class1=$2&class2=$3&price=$4&order=$5&page=$6&$7
endif
match URL into $ with ^(.*)/'.$video_search.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_video:search&$2
endif
match URL into $ with ^(.*)/'.$video_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_video:search&class1=$2&class2=$3&price=$4&order=$5&page=$6&$7
endif
match URL into $ with ^(.*)/'.$video_gwc.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_video:gwc&$2
endif
match URL into $ with ^(.*)/'.$video_product.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_video:product&pid=$2&$3
endif
match URL into $ with ^(.*)/'.$video_lesson.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_video:lesson&lid=$2&$3
endif
match URL into $ with ^(.*)/'.$video_lecturer.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_video:lecturer&lid=$2&$3
endif
match URL into $ with ^(.*)/'.$video_sc.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_video:sc&$2
endif
match URL into $ with ^(.*)/'.$video_wap.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_video:wap&$2
endif
match URL into $ with ^(.*)/'.$video_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_video:wap&pagetype=$2&cid1=$3&cid2=$4&$5
endif
match URL into $ with ^(.*)/'.$video_wap.'-(.+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_video:wap&pagetype=$2&cid=$3&$4
endif
match URL into $ with ^(.*)/'.$video_wap.'-(.+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_video:wap&pagetype=$2&$3
endif</font>

</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
<font color=blue>rewrite ^([^\.]*)/'.$video_home.$urltype.'$ $1/plugin.php?id=it618_video:index&$2 last;
rewrite ^([^\.]*)/'.$video_list.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:list&class1=$2&$3 last;
rewrite ^([^\.]*)/'.$video_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:list&class1=$2&class2=$3&$4 last;
rewrite ^([^\.]*)/'.$video_list.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:list&class1=$2&class2=$3&$4 last;
rewrite ^([^\.]*)/'.$video_list.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:list&class1=$2&class2=$3&price=$4&order=$5&page=$6&$7 last;
rewrite ^([^\.]*)/'.$video_search.$urltype.'$ $1/plugin.php?id=it618_video:search&$2 last;
rewrite ^([^\.]*)/'.$video_search.'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:search&class1=$2&class2=$3&price=$4&order=$5&page=$6&$7 last;
rewrite ^([^\.]*)/'.$video_gwc.$urltype.'$ $1/plugin.php?id=it618_video:gwc&$2 last;
rewrite ^([^\.]*)/'.$video_product.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:product&pid=$2&$3 last;
rewrite ^([^\.]*)/'.$video_lesson.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:lesson&lid=$2&$3 last;
rewrite ^([^\.]*)/'.$video_lecturer.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:lecturer&lid=$2&$3 last;
rewrite ^([^\.]*)/'.$video_sc.$urltype.'$ $1/plugin.php?id=it618_video:sc&$2 last;
rewrite ^([^\.]*)/'.$video_wap.$urltype.'$ $1/plugin.php?id=it618_video:wap&$2 last;
rewrite ^([^\.]*)/'.$video_wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:wap&pagetype=$2&cid1=$3&cid2=$4&$5 last;
rewrite ^([^\.]*)/'.$video_wap.'-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_video:wap&pagetype=$2&cid=$3&$4 last;
rewrite ^([^\.]*)/'.$video_wap.'-(.+)'.$urltype.'$ $1/plugin.php?id=it618_video:wap&pagetype=$2&$3 last;</font>
if (!-e $request_filename) {
	return 404;
}
</pre>
';

echo $strtmp;

if(count($reabc)!=11)return;
showtablefooter(); /*dis'.'m.tao'.'bao.com*/

?>