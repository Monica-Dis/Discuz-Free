<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='d')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_video_media_wmf', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_video#it618_video_media_wmf')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_about' => trim($_GET['it618_about'][$id]),
				'it618_type' => str_replace(" ","",trim($_GET['it618_type'][$id])),
				'it618_size' => trim($_GET['it618_size'][$id]),
				'it618_accessid' => trim($_GET['it618_accessid'][$id]),
				'it618_accesskey' => trim($_GET['it618_accesskey'][$id]),
				'it618_endpoint' => trim($_GET['it618_endpoint'][$id]),
				'it618_wmfpath' => trim($_GET['it618_wmfpath'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
				'it618_isurldel' => trim($_GET['it618_isurldel'][$id]),
				'it618_isok' => trim($_GET['it618_isok'][$id])
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_about_array = !empty($_GET['newit618_about']) ? $_GET['newit618_about'] : array();
	$newit618_type_array = !empty($_GET['newit618_type']) ? $_GET['newit618_type'] : array();
	$newit618_size_array = !empty($_GET['newit618_size']) ? $_GET['newit618_size'] : array();
	$newit618_accessid_array = !empty($_GET['newit618_accessid']) ? $_GET['newit618_accessid'] : array();
	$newit618_accesskey_array = !empty($_GET['newit618_accesskey']) ? $_GET['newit618_accesskey'] : array();
	$newit618_endpoint_array = !empty($_GET['newit618_endpoint']) ? $_GET['newit618_endpoint'] : array();
	$newit618_wmfpath_array = !empty($_GET['newit618_wmfpath']) ? $_GET['newit618_wmfpath'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	$newit618_isok_array = !empty($_GET['newit618_isok']) ? $_GET['newit618_isok'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		
		if(trim($newit618_name_array[$key]) != '') {
			
			C::t('#it618_video#it618_video_media_wmf')->insert(array(
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_about' => trim($newit618_about_array[$key]),
				'it618_type' => str_replace(" ","",trim($newit618_type_array[$key])),
				'it618_size' => trim($newit618_size_array[$key]),
				'it618_accessid' => trim($newit618_accessid_array[$key]),
				'it618_accesskey' => trim($newit618_accesskey_array[$key]),
				'it618_endpoint' => trim($newit618_endpoint_array[$key]),
				'it618_wmfpath' => trim($newit618_wmfpath_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
				'it618_isok' => trim($newit618_isok_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_video_lang['s33'].$ok1.' '.$it618_video_lang['s34'].$ok2.' '.$it618_video_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_mts&pmod=admin_video&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=11)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_mts&pmod=admin_video&operation=$operation&do=$do&page=$page");
showtableheaders($it618_video_lang['s812'],'it618_video_media_wmf');

	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_media_wmf'));
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_mts&pmod=admin_video&operation=$operation&do=$do");
	
	echo '<tr><td colspan=15>'.$it618_video_lang['s813'].$count.'<span style="float:right;color:red">'.$it618_video_lang['s826'].'</span></td></tr>';
	showsubtitle(array($it618_video_lang['s802'],$it618_video_lang['s814'], $it618_video_lang['s815'],$it618_video_lang['s816'],$it618_video_lang['s817'],$it618_video_lang['s818']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_media_wmf')." ORDER BY it618_order LIMIT $startlimit, $ppp");
	while($it618_video_media_wmf = DB::fetch($query)) {

		$mediacount=C::t('#it618_video#it618_video_media')->count_by_wmf_id($it618_video_media_wmf['id']);
		$disabled="";
		if($mediacount>0){
			$disabled="disabled=\"disabled\"";
		}
		
		if($it618_video_media_wmf['it618_isurldel']==1)$it618_isurldel_checked='checked="checked"';else $it618_isurldel_checked="";
		if($it618_video_media_wmf['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" id=\"id".$it618_video_media_wmf['id']."\" name=\"delete[]\" value=\"".$it618_video_media_wmf['id']."\" $disabled><label for=\"id".$it618_video_media_wmf['id']."\">".$it618_video_media_wmf['id']."</label>",
			'<div style="width:530px"><input type="text" class="txt" style="width:180px" name="it618_name['.$it618_video_media_wmf['id'].']" value="'.$it618_video_media_wmf['it618_name'].'"><span style="float:right;margin-right:-5px">'.$it618_video_lang['s801'].'<input type="text" class="txt" style="width:40px;margin-right:3px" name="it618_size['.$it618_video_media_wmf['id'].']" value="'.$it618_video_media_wmf['it618_size'].'">M '.$it618_video_lang['s764'].'<input type="text" class="txt" style="width:190px;margin-right:0px" name="it618_type['.$it618_video_media_wmf['id'].']" value="'.$it618_video_media_wmf['it618_type'].'"></span><br><textarea name="it618_about['.$it618_video_media_wmf['id'].']" style="width:530px;height:63px;margin-top:5px;margin-bottom:5px">'.$it618_video_media_wmf['it618_about'].'</textarea><br></div>',
			'<div style="width:330px;line-height:25px">'.$it618_video_lang['s819'].'<input type="text" class="txt" style="width:230px;float:right" name="it618_accessid['.$it618_video_media_wmf['id'].']" value="'.$it618_video_media_wmf['it618_accessid'].'"><br>'.$it618_video_lang['s820'].'<input type="text" class="txt" style="width:230px;float:right" name="it618_accesskey['.$it618_video_media_wmf['id'].']" value="'.$it618_video_media_wmf['it618_accesskey'].'"><br>'.$it618_video_lang['s821'].'<input type="text" class="txt" style="width:230px;float:right;" name="it618_endpoint['.$it618_video_media_wmf['id'].']" value="'.$it618_video_media_wmf['it618_endpoint'].'"><br>'.$it618_video_lang['s822'].'<input type="text" class="txt" style="width:230px;float:right;" name="it618_wmfpath['.$it618_video_media_wmf['id'].']" value="'.$it618_video_media_wmf['it618_wmfpath'].'"></div>',
			$it618_video_lang['s587'].$it618_video_media_wmf['it618_mediacount'].'<br>'.$it618_video_lang['s584'].$it618_video_media_wmf['it618_mediasize'].'M<br>'.$it618_video_lang['s585'].$it618_video_media_wmf['it618_mtscount'].'<br>'.$it618_video_lang['s586'].$it618_video_media_wmf['it618_mtssize'].'M<br><input class="checkbox" type="checkbox" name="it618_isurldel['.$it618_video_media_wmf['id'].']" id="it618_isurldel'.$it618_video_media_wmf['id'].'" '.$it618_isurldel_checked.' value="1"><label for="it618_isurldel'.$it618_video_media_wmf['id'].'">'.$it618_video_lang['s2009'].'</label>',
			'<input class="checkbox" type="checkbox" name="it618_isok['.$it618_video_media_wmf['id'].']" '.$it618_isok_checked.' value="1">',
			'<input class="txt" type="text" style="width:30px" name="it618_order['.$it618_video_media_wmf['id'].']" value="'.$it618_video_media_wmf['it618_order'].'">'
		));
	}
	
	global $_G;
if($reabc[4]!='8')return;

	$lang_s764=$it618_video_lang['s764'];
	$lang_s801=$it618_video_lang['s801'];
	$lang_s819=$it618_video_lang['s819'];
	$lang_s820=$it618_video_lang['s820'];
	$lang_s821=$it618_video_lang['s821'];
	$lang_s822=$it618_video_lang['s822'];

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT

	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<div style="width:530px"><input type="text" class="txt" style="width:180px" name="newit618_name[]"><span style="float:right;margin-right:-5px">$lang_s801<input type="text" class="txt" style="width:40px;margin-right:3px" name="newit618_size[]" value="1000">M $lang_s764<input type="text" class="txt" style="width:190px;margin-right:0px" name="newit618_type[]" value="mp4"></span><br><textarea name="newit618_about[]" style="width:530px;height:63px;margin-top:5px;margin-bottom:5px"></textarea></div>'],
		[1,'<div style="width:330px;line-height:25px">$lang_s819<input type="text" class="txt" style="width:230px;float:right" name="newit618_accessid[]"><br>$lang_s820<input type="text" class="txt" style="width:230px;float:right" name="newit618_accesskey[]"><br>$lang_s821</td><td><input type="text" class="txt" style="width:230px;float:right" name="newit618_endpoint[]"><br>$lang_s822<input type="text" class="txt" style="width:230px;float:right" name="newit618_wmfpath[]"></div>'],
		[1,''], 
		[1,'<input class="checkbox" type="checkbox" name="newit618_isok[]" value="1">'], 
		[1,'<input class="txt" type="text" style="width:30px" name="newit618_order[]" value="0">']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="15"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />", $multipage);
    echo '<tr><td></td><td colspan="15">'.$it618_video_lang['s588'].'</td></tr>';
	if(count($reabc)!=11)return;
showtablefooter(); /*dis'.'m.tao'.'bao.com*/
?>