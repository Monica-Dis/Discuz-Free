<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='d')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_video_liveset', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			$it618_accessid=trim($_GET['it618_accessid'][$id]);
			$it618_accesskey=trim($_GET['it618_accesskey'][$id]);
			$it618_pushcdnkey=trim($_GET['it618_pushcdnkey'][$id]);
			$it618_pushdomainname=trim($_GET['it618_pushdomainname'][$id]);
			$it618_cdnkey=trim($_GET['it618_cdnkey'][$id]);
			$it618_domainname=trim($_GET['it618_domainname'][$id]);
			$it618_appname=trim($_GET['it618_appname'][$id]);
			$it618_sqtime=trim($_GET['it618_sqtime'][$id]);
			$it618_livetime=trim($_GET['it618_livetime'][$id]);
			$it618_copytime=trim($_GET['it618_copytime'][$id]);
			$it618_ossbucket=trim($_GET['it618_ossbucket'][$id]);
			$it618_ossendpoint=trim($_GET['it618_ossendpoint'][$id]);
			$it618_isok=trim($_GET['it618_isok'][$id]);
			
			if($it618_accessid==''||$it618_accesskey==''||$it618_domainname==''||$it618_pushdomainname==''||$it618_appname==''||$it618_sqtime==''||$it618_copytime==''||$it618_livetime==''||$it618_cdnkey==''||$it618_pushcdnkey==''){
				$it618_isok=0;
			}
			
			if($it618_sqtime<3){
				$it618_sqtime=3;
			}
			
			if($it618_livetime<3){
				$it618_livetime=3;
			}
			
			if($it618_copytime<0){
				$it618_copytime=1;
			}

			C::t('#it618_video#it618_video_liveset')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_about' => trim($_GET['it618_about'][$id]),
				'it618_sqtime' => $it618_sqtime,
				'it618_accessid' => $it618_accessid,
				'it618_accesskey' => $it618_accesskey,
				'it618_ossbucket' => $it618_ossbucket,
				'it618_ossendpoint' => $it618_ossendpoint,
				'it618_appname' => $it618_appname,
				'it618_domainname' => $it618_domainname,
				'it618_cdnkey' => $it618_cdnkey,
				'it618_pushdomainname' => $it618_pushdomainname,
				'it618_pushcdnkey' => $it618_pushcdnkey,
				'it618_pcflash' => trim($_GET['it618_pcflash'][$id]),
				'it618_liveordertime' => trim($_GET['it618_liveordertime'][$id]),
				'it618_livetime' => $it618_livetime,
				'it618_iseditetime' => trim($_GET['it618_iseditetime'][$id]),
				'it618_copytime' => $it618_copytime,
				'it618_order' => trim($_GET['it618_order'][$id]),
				'it618_isok' => $it618_isok
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_about_array = !empty($_GET['newit618_about']) ? $_GET['newit618_about'] : array();
	$newit618_sqtime_array = !empty($_GET['newit618_sqtime']) ? $_GET['newit618_sqtime'] : array();
	$newit618_accessid_array = !empty($_GET['newit618_accessid']) ? $_GET['newit618_accessid'] : array();
	$newit618_accesskey_array = !empty($_GET['newit618_accesskey']) ? $_GET['newit618_accesskey'] : array();
	$newit618_cdnkey_array = !empty($_GET['newit618_cdnkey']) ? $_GET['newit618_cdnkey'] : array();
	$newit618_pushcdnkey_array = !empty($_GET['newit618_pushcdnkey']) ? $_GET['newit618_pushcdnkey'] : array();
	$newit618_ossbucket_array = !empty($_GET['newit618_ossbucket']) ? $_GET['newit618_ossbucket'] : array();
	$newit618_ossendpoint_array = !empty($_GET['newit618_ossendpoint']) ? $_GET['newit618_ossendpoint'] : array();
	$newit618_appname_array = !empty($_GET['newit618_appname']) ? $_GET['newit618_appname'] : array();
	$newit618_cnname_array = !empty($_GET['newit618_cnname']) ? $_GET['newit618_cnname'] : array();
	$newit618_domainname_array = !empty($_GET['newit618_domainname']) ? $_GET['newit618_domainname'] : array();
	$newit618_pushdomainname_array = !empty($_GET['newit618_pushdomainname']) ? $_GET['newit618_pushdomainname'] : array();
	$newit618_liveordertime_array = !empty($_GET['newit618_liveordertime']) ? $_GET['newit618_liveordertime'] : array();
	$newit618_livetime_array = !empty($_GET['newit618_livetime']) ? $_GET['newit618_livetime'] : array();
	$newit618_copytime_array = !empty($_GET['newit618_copytime']) ? $_GET['newit618_copytime'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	$newit618_isok_array = !empty($_GET['newit618_isok']) ? $_GET['newit618_isok'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		
		if(trim($newit618_name_array[$key]) != '') {
			
			$it618_livetime=trim($newit618_livetime_array[$key]);
			$it618_sqtime=trim($newit618_sqtime_array[$key]);
			$it618_copytime=trim($newit618_copytime_array[$key]);
			$it618_ossbucket=trim($newit618_ossbucket_array[$key]);
			$it618_ossendpoint=trim($newit618_ossendpoint_array[$key]);
			
			if($it618_sqtime<3){
				$it618_sqtime=3;
			}
			
			if($it618_livetime<3){
				$it618_livetime=3;
			}
			
			if($it618_copytime<0){
				$it618_copytime=1;
			}
			
			
			if($it618_copytime>7200){
				$it618_copytime=7200;
			}
			
			C::t('#it618_video#it618_video_liveset')->insert(array(
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_about' => trim($newit618_about_array[$key]),
				'it618_sqtime' => $it618_sqtime,
				'it618_accessid' => trim($newit618_accessid_array[$key]),
				'it618_accesskey' => trim($newit618_accesskey_array[$key]),
				'it618_cdnkey' => trim($newit618_cdnkey_array[$key]),
				'it618_pushcdnkey' => trim($newit618_pushcdnkey_array[$key]),
				'it618_ossbucket' => $it618_ossbucket,
				'it618_ossendpoint' => $it618_ossendpoint,
				'it618_appname' => trim($newit618_appname_array[$key]),
				'it618_cnname' => trim($newit618_cnname_array[$key]),
				'it618_domainname' => trim($newit618_domainname_array[$key]),
				'it618_pushdomainname' => trim($newit618_pushdomainname_array[$key]),
				'it618_liveordertime' => trim($newit618_liveordertime_array[$key]),
				'it618_livetime' => $it618_livetime,
				'it618_copytime' => $it618_copytime,
				'it618_order' => trim($newit618_order_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_video_lang['s33'].$ok1.' '.$it618_video_lang['s34'].$ok2.' '.$it618_video_lang['s35'].$del.')', "action=plugins&identifier=$identifier&cp=admin_liveset&pmod=admin_live&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=11)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_liveset&pmod=admin_live&operation=$operation&do=$do&page=$page");
showtableheaders($it618_video_lang['s1249'],'it618_video_liveset');

	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_liveset'));
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_liveset&pmod=admin_live&operation=$operation&do=$do");
	
	echo '<tr><td colspan=15>'.$it618_video_lang['s1250'].$count.'<span style="float:right;color:red">'.$it618_video_lang['s1262'].'</span></td></tr>';
	showsubtitle(array($it618_video_lang['s802'],$it618_video_lang['s1251'], $it618_video_lang['s1252'],$it618_video_lang['s1253'],$it618_video_lang['s817'],$it618_video_lang['s818']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_liveset')." ORDER BY it618_order LIMIT $startlimit, $ppp");
	while($it618_video_liveset = DB::fetch($query)) {

		$mediacount=C::t('#it618_video#it618_video_media_live')->count_by_liveset_id($it618_video_liveset['id']);
		$disabled="";
		if($mediacount>0){
			$disabled="disabled=\"disabled\"";
		}
		
		if($it618_video_liveset['it618_isok']==1)$it618_isok_checked='checked="checked"';else $it618_isok_checked="";
		if($it618_video_liveset['it618_pcflash']==1)$it618_pcflash_checked='checked="checked"';else $it618_pcflash_checked="";
		if($it618_video_liveset['it618_iseditetime']==1)$it618_iseditetime_checked='checked="checked"';else $it618_iseditetime_checked="";
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" id=\"id".$it618_video_liveset['id']."\" name=\"delete[]\" value=\"".$it618_video_liveset['id']."\" $disabled><label for=\"id".$it618_video_liveset['id']."\">".$it618_video_liveset['id']."</label>",
			'<input type="text" class="txt" style="width:280px" name="it618_name['.$it618_video_liveset['id'].']" value="'.$it618_video_liveset['it618_name'].'"><br><textarea name="it618_about['.$it618_video_liveset['id'].']" style="width:280px;height:68px;margin-top:5px;margin-bottom:5px">'.$it618_video_liveset['it618_about'].'</textarea><br><input type="text" class="txt" style="width:280px;" name="it618_accessid['.$it618_video_liveset['id'].']" value="'.$it618_video_liveset['it618_accessid'].'"><br><input type="text" class="txt" style="width:280px;" name="it618_accesskey['.$it618_video_liveset['id'].']" value="'.$it618_video_liveset['it618_accesskey'].'"></div>',
			'<div style="width:340px;line-height:25px">'.$it618_video_lang['s1254'].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=red>'.$it618_video_liveset['it618_cnname'].'</font><br>'.$it618_video_lang['s1256'].'<input type="text" class="txt" style="width:230px;float:right" name="it618_pushdomainname['.$it618_video_liveset['id'].']" value="'.$it618_video_liveset['it618_pushdomainname'].'"><br>'.$it618_video_lang['s1336'].'<input type="text" class="txt" style="width:230px;float:right;" name="it618_pushcdnkey['.$it618_video_liveset['id'].']" value="'.$it618_video_liveset['it618_pushcdnkey'].'"><br>'.$it618_video_lang['s1255'].'<input type="text" class="txt" style="width:230px;float:right" name="it618_domainname['.$it618_video_liveset['id'].']" value="'.$it618_video_liveset['it618_domainname'].'"><br>'.$it618_video_lang['s1257'].'<input type="text" class="txt" style="width:230px;float:right;" name="it618_cdnkey['.$it618_video_liveset['id'].']" value="'.$it618_video_liveset['it618_cdnkey'].'"><br>'.$it618_video_lang['s1258'].'<input type="text" class="txt" style="width:230px;float:right" name="it618_appname['.$it618_video_liveset['id'].']" value="'.$it618_video_liveset['it618_appname'].'"><br><input class="checkbox" type="checkbox" id="it618_pcflash'.$it618_video_liveset['id'].'" name="it618_pcflash['.$it618_video_liveset['id'].']" '.$it618_pcflash_checked.' value="1"><label for="it618_pcflash'.$it618_video_liveset['id'].'">'.$it618_video_lang['s1727'].'</label></div>',
			'<div style="width:360px;line-height:25px">'.$it618_video_lang['s1340'].'<input type="text" class="txt" style="width:40px;margin-left:3px;margin-right:3px" name="it618_sqtime['.$it618_video_liveset['id'].']" value="'.$it618_video_liveset['it618_sqtime'].'">'.$it618_video_lang['s1341'].'<br>'.$it618_video_lang['s1340'].'<input type="text" class="txt" style="width:40px;margin-left:3px;margin-right:3px" name="it618_copytime['.$it618_video_liveset['id'].']" value="'.$it618_video_liveset['it618_copytime'].'">'.$it618_video_lang['s1342'].'<br>'.$it618_video_lang['s1340'].'<input type="text" class="txt" style="width:40px;margin-left:3px;margin-right:3px" name="it618_liveordertime['.$it618_video_liveset['id'].']" value="'.$it618_video_liveset['it618_liveordertime'].'">'.$it618_video_lang['s1387'].'<br>'.$it618_video_lang['s1302'].'<input type="text" class="txt" style="width:40px;margin-left:3px;margin-right:3px" name="it618_livetime['.$it618_video_liveset['id'].']" value="'.$it618_video_liveset['it618_livetime'].'">'.$it618_video_lang['s1305'].$it618_video_lang['s1343'].'<br><input class="checkbox" type="checkbox" id="it618_iseditetime'.$it618_video_liveset['id'].'" name="it618_iseditetime['.$it618_video_liveset['id'].']" '.$it618_iseditetime_checked.' value="1"><label for="it618_iseditetime'.$it618_video_liveset['id'].'" style="color:red">'.$it618_video_lang['s1597'].'</label><br><font color=#999>'.$it618_video_lang['s1266'].'</font><br>'.$it618_video_lang['s1259'].'<input type="text" class="txt" style="width:230px;float:right" name="it618_ossbucket['.$it618_video_liveset['id'].']" value="'.$it618_video_liveset['it618_ossbucket'].'"><br>'.$it618_video_lang['s1260'].'<input type="text" class="txt" style="width:230px;float:right;" name="it618_ossendpoint['.$it618_video_liveset['id'].']" value="'.$it618_video_liveset['it618_ossendpoint'].'"></div>',
			'<input class="checkbox" type="checkbox" name="it618_isok['.$it618_video_liveset['id'].']" '.$it618_isok_checked.' value="1">',
			'<input class="txt" type="text" style="width:30px" name="it618_order['.$it618_video_liveset['id'].']" value="'.$it618_video_liveset['it618_order'].'">'
		));
	}
	
	global $_G;
if($reabc[4]!='8')return;

	$lang_s1254=$it618_video_lang['s1254'];
	$lang_s1255=$it618_video_lang['s1255'];
	$lang_s1256=$it618_video_lang['s1256'];
	$lang_s1257=$it618_video_lang['s1257'];
	$lang_s1258=$it618_video_lang['s1258'];
	$lang_s1259=$it618_video_lang['s1259'];
	$lang_s1260=$it618_video_lang['s1260'];
	$lang_s1261=$it618_video_lang['s1261'];
	$lang_s1264=$it618_video_lang['s1264'];
	$lang_s1265=$it618_video_lang['s1265'];
	$lang_s1266=$it618_video_lang['s1266'];
	$lang_s1301=$it618_video_lang['s1301'];
	$lang_s1302=$it618_video_lang['s1302'];
	$lang_s1305=$it618_video_lang['s1305'];
	$lang_s1336=$it618_video_lang['s1336'];
	$lang_s1340=$it618_video_lang['s1340'];
	$lang_s1341=$it618_video_lang['s1341'];
	$lang_s1342=$it618_video_lang['s1342'];
	$lang_s1343=$it618_video_lang['s1343'];
	$lang_s1387=$it618_video_lang['s1387'];
	$lang_s1578=$it618_video_lang['s1578'];

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT

	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:280px" name="newit618_name[]"><br><textarea name="newit618_about[]" style="width:280px;height:68px;margin-top:5px;margin-bottom:5px"></textarea><br><input type="text" class="txt" style="width:280px" name="newit618_accessid[]"><br><input type="text" class="txt" style="width:280px" name="newit618_accesskey[]">'],
		[1,'<div style="width:340px;line-height:25px">$lang_s1254<select name="newit618_cnname[]" style="width:235px;float:right;margin-right:10px"><option value="cn-beijing">$lang_s1264</option><option value="cn-shanghai" selected="selected">$lang_s1265</option><option value="cn-shenzhen">$lang_s1578</option></select><br>$lang_s1256<input type="text" class="txt" style="width:230px;float:right" name="newit618_pushdomainname[]"><br>$lang_s1336<input type="text" class="txt" style="width:230px;float:right" name="newit618_pushcdnkey[]"><br>$lang_s1255<input type="text" class="txt" style="width:230px;float:right" name="newit618_domainname[]"><br>$lang_s1257<input type="text" class="txt" style="width:230px;float:right" name="newit618_cdnkey[]"><br>$lang_s1258<input type="text" class="txt" style="width:230px;float:right" name="newit618_appname[]"></div>'],
		[1,'<div style="width:360px;line-height:25px">$lang_s1340<input type="text" class="txt" style="width:40px;margin-left:3px;margin-right:3px" name="newit618_sqtime[]">$lang_s1341<br>$lang_s1340<input type="text" class="txt" style="width:40px;margin-left:3px;margin-right:3px" name="newit618_copytime[]">$lang_s1342<br>$lang_s1340<input type="text" class="txt" style="width:40px;margin-left:3px;margin-right:3px" name="newit618_liveordertime[]">$lang_s1387<br>$lang_s1302<input type="text" class="txt" style="width:40px;margin-left:3px;margin-right:3px" name="newit618_livetime[]">$lang_s1305$lang_s1343<br>$lang_s1266<br>$lang_s1259<input type="text" class="txt" style="width:230px;float:right" name="newit618_ossbucket[]"><br>$lang_s1260</td><td><input type="text" class="txt" style="width:230px;float:right" name="newit618_ossendpoint[]"></div>'],
		[1,''], 
		[1,'<input class="txt" type="text" style="width:30px" name="newit618_order[]" value="0">']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="15"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />", $multipage);
    echo '<tr><td></td><td colspan="15">'.$it618_video_lang['s1388'].'</td></tr>';
	if(count($reabc)!=11)return;
showtablefooter(); /*dis'.'m.tao'.'bao.com*/
?>