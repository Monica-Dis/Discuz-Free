<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/templateset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_video/config/templateset.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_video/config/templateset.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$template_pcname=\''.trim($_GET['template_pcname'])."';\n";
		$fileData .= '$template_wapname=\''.trim($_GET['template_wapname'])."';\n";
		$fileData .= '$template_wapuname=\''.trim($_GET['template_wapuname'])."';\n";
		$fileData .= '$template_adminname=\''.trim($_GET['template_adminname'])."';\n";
		$fileData .= '$template_isselect=\''.trim($_GET['template_isselect'])."';\n";
		$fileData .= '$template_ispagetui=\''.trim($_GET['template_ispagetui'])."';\n";
		$fileData .= '$template_isshoptui=\''.trim($_GET['template_isshoptui'])."';\n";
		$fileData .= '$template_pagedefaut=\''.trim($_GET['template_pagedefaut'])."';\n";
		$fileData .= '$template_set[\'ispcsale\']=\''.trim($_GET['template_ispcsale'])."';\n";
		$fileData .= '$template_set[\'iswapsale\']=\''.trim($_GET['template_iswapsale'])."';\n";
		$fileData .= '$template_set[\'wappagebotbtn\']=\''.trim($_GET['template_wappagebotbtn'])."';\n";
		$fileData .= '$template_set[\'waphomeico\']=\''.trim($_GET['template_waphomeico'])."';\n";
		$fileData .= '$template_set[\'waphomelive\']=\''.trim($_GET['template_waphomelive'])."';\n";
		$fileData .= '$template_set[\'waphomehot\']=\''.trim($_GET['template_waphomehot'])."';\n";
		$fileData .= '$template_set[\'pchometeacher\']=\''.trim($_GET['template_pchometeacher'])."';\n";
		$fileData .= '$template_set[\'waphometeacher\']=\''.trim($_GET['template_waphometeacher'])."';\n";
		$fileData .= '$template_set[\'homegoodscatchtime\']=\''.trim($_GET['template_homegoodscatchtime'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_video_lang['s1805'], "action=plugins&identifier=$identifier&cp=admin_template&cp1=$cp1&pmod=admin_style&operation=$operation&do=$do&page=$page", 'succeed');
}

$pcnameoption='<option value="mall">'.$it618_video_lang['s1010'].'</option>';
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/template/edu/video_default.htm')){
	$pcnameoption.='<option value="edu">'.$it618_video_lang['s1011'].'</option>';
}
$pcnameoption=str_replace('<option value="'.$template_pcname.'"','<option value="'.$template_pcname.'" selected="selected"',$pcnameoption);

$wapnameoption='<option value="mall_wap">'.$it618_video_lang['s1010'].'</option>';
$wapnameoption=str_replace('<option value="'.$template_wapname.'"','<option value="'.$template_wapname.'" selected="selected"',$wapnameoption);

$wapunameoption='<option value="">'.$it618_video_lang['s1010'].'</option>';
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/template/mall_wap/u1/wap_video_u.htm')){
	$wapunameoption.='<option value="1">'.$it618_video_lang['s783'].'</option>';
}
$wapunameoption=str_replace('<option value="'.$template_wapuname.'"','<option value="'.$template_wapuname.'" selected="selected"',$wapunameoption);

$adminnameoption='<option value="sc">'.$it618_video_lang['s743'].'</option>';
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/template/sc_proton/sc_index.htm')){
	$adminnameoption.='<option value="sc_proton">'.$it618_video_lang['s744'].'</option>';
}
$adminnameoption=str_replace('<option value="'.$template_adminname.'"','<option value="'.$template_adminname.'" selected="selected"',$adminnameoption);

$pagedefautoption='<option value="content">'.$it618_video_lang['s1824'].'</option><option value="class">'.$it618_video_lang['s1825'].'</option>';
$pagedefautoption=str_replace('<option value="'.$template_pagedefaut.'"','<option value="'.$template_pagedefaut.'" selected="selected"',$pagedefautoption);

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_template&cp1=$cp1&pmod=admin_style&operation=$operation&do=$do");

if($template_isselect==1)$check_template_isselect='checked="checked"';else $check_template_isselect='';
if($template_ispagetui==1)$check_template_ispagetui='checked="checked"';else $check_template_ispagetui='';
if($template_isshoptui==1)$check_template_isshoptui='checked="checked"';else $check_template_isshoptui='';
if($template_set['ispcsale']==1)$check_template_ispcsale='checked="checked"';else $check_template_ispcsale='';
if($template_set['iswapsale']==1)$check_template_iswapsale='checked="checked"';else $check_template_iswapsale='';

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_video_lang['s1007'].'</th></tr>
<tr class="header"><th width=180>'.$it618_video_lang['s937'].'</th><th>'.$it618_video_lang['s939'].'</th><th>'.$it618_video_lang['s938'].'</th></tr>

<tr class="hover">
<td>'.$it618_video_lang['s1008'].'</td><td class="longtxt">
<select name="template_pcname">
	'.$pcnameoption.'
</select></td>
<td>'.$it618_video_lang['s1012'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1009'].'</td><td class="longtxt">
<select name="template_wapname">
	'.$wapnameoption.'
</select></td>
<td>'.$it618_video_lang['s1012'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s784'].'</td><td class="longtxt">
<select name="template_wapuname">
	'.$wapunameoption.'
</select></td>
<td>'.$it618_video_lang['s1012'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s745'].'</td><td class="longtxt">
<select name="template_adminname">
	'.$adminnameoption.'
</select></td>
<td>'.$it618_video_lang['s1012'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1809'].'</td><td class="longtxt"><input type="checkbox" name="template_isselect" value=1 '.$check_template_isselect.'></td>
<td>'.$it618_video_lang['s1810'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1822'].'</td><td class="longtxt"><input type="checkbox" name="template_ispagetui" value=1 '.$check_template_ispagetui.'></td>
<td>'.$it618_video_lang['s1826'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1840'].'</td><td class="longtxt"><input type="checkbox" name="template_isshoptui" value=1 '.$check_template_isshoptui.'></td>
<td>'.$it618_video_lang['s1841'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1823'].'</td><td class="longtxt">
<select name="template_pagedefaut">
	'.$pagedefautoption.'
</select></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1821'].'</td><td class="longtxt"><input type="checkbox" name="template_ispcsale" value=1 '.$check_template_ispcsale.'></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1829'].'</td><td class="longtxt"><input type="checkbox" name="template_iswapsale" value=1 '.$check_template_iswapsale.'></td>
<td></td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1646'].'</td><td class="longtxt"><input type="text" name="template_wappagebotbtn" style="width:200px" value='.$template_set['wappagebotbtn'].'></td>
<td>'.$it618_video_lang['s1647'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1724'].'</td><td class="longtxt"><input type="text" name="template_waphomeico" style="width:200px" value='.$template_set['waphomeico'].'></td>
<td>'.$it618_video_lang['s1599'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1721'].'</td><td class="longtxt"><input type="text" name="template_waphomelive" style="width:200px" value='.$template_set['waphomelive'].'></td>
<td>'.$it618_video_lang['s1722'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1725'].'</td><td class="longtxt"><input type="text" name="template_waphomehot" style="width:200px" value='.$template_set['waphomehot'].'></td>
<td>'.$it618_video_lang['s1726'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1589'].'</td><td class="longtxt"><input type="text" name="template_pchometeacher" style="width:200px" value='.$template_set['pchometeacher'].'></td>
<td>'.$it618_video_lang['s1591'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1590'].'</td><td class="longtxt"><input type="text" name="template_waphometeacher" style="width:200px" value='.$template_set['waphometeacher'].'></td>
<td>'.$it618_video_lang['s1591'].'</td>
</tr>

<tr class="hover">
<td>'.$it618_video_lang['s1576'].'</td><td class="longtxt"><input type="text" name="template_homegoodscatchtime" style="width:200px" value='.$template_set['homegoodscatchtime'].'></td>
<td>'.$it618_video_lang['s1577'].'</td>
</tr>

</table>
';

showsubmit('it618submit', $it618_video_lang['s23']);

if(count($reabc)!=11)return;
showtablefooter(); /*dis'.'m.tao'.'bao.com*/

?>