<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

$orderby0='';$orderby1='';
if($_GET['orderby']==0){$it618orderby = "id desc";$orderby0='selected="selected"';}
if($_GET['orderby']==1){$it618orderby = "it618_duration desc";$orderby1='selected="selected"';}

$urlsql='&key='.$_GET['key'].'&orderby='.$_GET['orderby'];

if(submitcheck('it618submit_delete')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_media_live = C::t('#it618_video#it618_video_media_live')->fetch_by_id($delid);
		it618_video_deletemedialive($it618_video_media_live['it618_url']);
		DB::query("delete from ".DB::table('it618_video_media_live')." where id=".$delid);
		
		if($it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_url($it618_video_media_live['it618_url'])){
			DB::query("delete from ".DB::table('it618_video_goods_video')." where id=".$it618_video_goods_video['id']);
			it618_video_deletegoodsvideo($it618_video_goods_video['id'],'media_live');
		}
		$ok=$ok+1;
	}

	cpmsg($it618_video_lang['s193'].$ok, "action=plugins&identifier=$identifier&cp=admin_media_live&pmod=admin_media&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=11)return;

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_media_live&pmod=admin_media&operation=$operation&do=$do&page=$page".$urlsql);
showtableheaders($it618_video_lang['s1278'],'it618_video_media_live');

echo '<tr><td colspan=14>'.it618_video_getlang('s97').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:300px" /> <select name="orderby"><option value=0 '.$orderby0.'>'.it618_video_getlang('s1827').'</option><option value=1 '.$orderby1.'>'.it618_video_getlang('s1828').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_video_getlang('s350').'" /></td></tr>';
	
	$count = C::t('#it618_video#it618_video_media_live')->count_by_search($it618sql,'',0,0,$_GET['key']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_media_live&pmod=admin_media&operation=$operation&do=$do".$urlsql);
	
	echo '<tr><td colspan=14>'.it618_video_getlang('s850').$count.'<span style="float:right;color:red">'.it618_video_getlang('s1477').'</span></td></tr>';
	showsubtitle(array('',it618_video_getlang('s837').'/'.it618_video_getlang('s1478')));
	
	$n=1;
	foreach(C::t('#it618_video#it618_video_media_live')->fetch_all_by_search(
		$it618sql,$it618orderby,0,0,$_GET['key'],$startlimit,$ppp
	) as $it618_video_media_live) {
		
		$shopname=C::t('#it618_video#it618_video_shop')->fetch_name_by_id($it618_video_media_live['it618_shopid']);
		
		$it618_size='';
		if($it618_video_media_live['it618_size']>0){
			$it618_size=round(($it618_video_media_live['it618_size']/1024/1024),2).'MB';
		}
		
		if($it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_url($it618_video_media_live['it618_url'])){
			$lessonurl=it618_video_getrewrite('video_lesson',$it618_video_goods_video['id'],'plugin.php?id=it618_video:lesson&lid='.$it618_video_goods_video['id']);
			$it618_name='<a href="'.$lessonurl.'" target="_blank">'.$it618_video_media_live['it618_name'].'</a>';
		}else{
			$it618_name=$it618_video_media_live['it618_name'];
		}
		
		$media_playstr='[<a href="javascript:" onclick="media_play(\''.it618_video_getsignedurl($it618_video_media_live['it618_url']).'\',\''.$shopname.' '.str_replace("'","",$it618_video_media_live['it618_name']).'\')">'.$it618_video_lang['s1100'].'</a>] ';

		showtablerow('', array('', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_video_media_live['id'].'"><label for="chk_del'.$n.'">'.$it618_video_media_live['id'].'</label>',
			$shopname.' '.$it618_name.' '.$media_playstr.$it618_video_lang['s399'].$it618_video_media_live['it618_time1'].$it618_video_lang['s397'].$it618_video_media_live['it618_time2'].$it618_video_lang['s398'].$it618_video_media_live['it618_time3'].$it618_video_lang['s400'].' '.$it618_size.' <font color=#999>'.date('Y-m-d H:i:s', $it618_video_media_live['it618_time']).'<br>'.$it618_video_media_live['it618_url'].'</font>'
		));
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_video_getlang('s129').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_delete" value="'.$it618_video_lang['s1475'].'" onclick="return confirm(\''.$it618_video_lang['s1476'].'\')"/><input type=hidden value='.$page.' name=page /></div><br></td></tr>';
	
echo '
	<script type="text/javascript" src="source/plugin/it618_video/js/jquery.js"></script>
	<script type="text/javascript" src="source/plugin/it618_video/js/layer/layer.js"></script>
	<script>
	var playurl,title;
	function media_play(url,tmptitle){
		playurl=url;
		title=tmptitle;
		
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left\'>"+title+"</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["800px", "550px"],
			content: "plugin.php?id=it618_video:sc_media_play'.$adminsid.'&playurl="+playurl,
			cancel: function(index, layero){ 
			}    
		});
	}
    </script>';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/

echo '<script type="text/javascript">
		function check_all(obj,id)
		{
			for(var i=1;i<'.$n.';i++)
			{
				document.getElementById(id+""+i).checked = obj.checked;
			}
		}
	  </script>';
?>