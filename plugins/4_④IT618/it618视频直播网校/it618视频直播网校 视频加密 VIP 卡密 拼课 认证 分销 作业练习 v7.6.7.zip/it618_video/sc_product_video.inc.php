<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$ppp = 30;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$lid=intval($_GET['lid']);
$preurl=$_GET['preurl'];

$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_lesson['it618_pid']);

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($it618_video_shop['it618_isdel']==1){
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_id($delid);
			$typecountall = C::t('#it618_video#it618_video_goods_type')->counttype_by_pid_lid_vid($it618_video_goods_video['it618_pid'],$it618_video_goods_video['it618_lid'],$it618_video_goods_video['id']);
			if(!($typecountall>0||$it618_video_goods_video['it618_salecount']>0)){
				DB::delete('it618_video_goods_video', "id=$delid");
				$del=$del+1;
			}
		}
	}else{
		$del=$it618_video_lang['s1604'];
	}
	
	if(is_array($_GET['it618_isuser'])) {
		foreach($_GET['it618_isuser'] as $id => $val) {
			
			$it618_videotime1=intval($_GET['it618_videotime1'][$id]);
			$it618_videotime2=intval($_GET['it618_videotime2'][$id]);
			$it618_videotime3=intval($_GET['it618_videotime3'][$id]);
			
			$it618_videotime=$it618_videotime1*3600+$it618_videotime2*60+$it618_videotime3;
			
			$it618_videourl= trim($_GET['it618_videourl'][$id]);
			$it618_videourl=str_replace("'",'"',$it618_videourl);
			$it618_videourl=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" frameborder=0 allowfullscreen=1>',$it618_videourl);
			
			$tmparr=explode("<iframe",$it618_videourl);
			if(count($tmparr)>1){
				$urlarr=explode("https://",$_G['siteurl']);
				if(count($urlarr)>1){
					$it618_videourl=str_replace("http://","https://",$it618_videourl);
				}
			}
			
			if($it618_video_media_mts=C::t('#it618_video#it618_video_media_mts')->fetch_by_url($it618_videourl)){
				if($it618_video_media_mts['it618_shopid']!=$ShopId){
					$it618_videourl='';
				}
			}
			
			$it618_isuser=trim($_GET['it618_isuser'][$id]);
			
			$it618_saleprice=$_GET['it618_saleprice'][$id];
			
			$it618_score=$_GET['it618_score'][$id];
			if($_GET['it618_jfid'][$id]==0)$it618_score=0;
			
			if($Shopisale!=1){
				$it618_saleprice=1;
			}

			C::t('#it618_video#it618_video_goods_video')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_description' => trim($_GET['it618_description'][$id]),
				'it618_issale' => $_GET['it618_issale'][$id],
				'it618_price' => $_GET['it618_price'][$id],
				'it618_saleprice' => $it618_saleprice,
				'it618_jfid' => $_GET['it618_jfid'][$id],
				'it618_score' => $it618_score,
				'it618_videourl' => $it618_videourl,
				'it618_islive' => trim($_GET['it618_islive'][$id]),
				'it618_ison' => trim($_GET['it618_ison'][$id]),
				'it618_isuser' => $it618_isuser,
				'it618_usercode' => trim($_GET['it618_usercode'][$id]),
				'it618_previewtime' => 0,
				'it618_videotime' => $it618_videotime,
				'it618_videotime1' => $it618_videotime1,
				'it618_videotime2' => $it618_videotime2,
				'it618_videotime3' => $it618_videotime3,
				'it618_order' => trim($_GET['it618_order'][$id])
			));
			
			$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_id($id);
			if($it618_video_goods_video['it618_liveid']>0){
				$it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
				C::t('#it618_video#it618_video_live')->update($it618_video_live['id'],array(
					'it618_isuser' => $_GET['it618_isuser'][$id]
				));
			}
			
			if($it618_isuser==1){
				$tmparr=explode("<iframe",$it618_videourl);
				if(count($tmparr)==1){
					C::t('#it618_video#it618_video_goods_video')->update($id,array(
						'it618_previewtime' => trim($_GET['it618_previewtime'][$id])
					));
				}
			}
			
			if($IsChat==1){
				C::t('#it618_video#it618_video_goods_video')->update($id,array(
					'it618_ischat' => trim($_GET['it618_ischat'][$id])
				));
			}
			$ok1=$ok1+1;
		}
	}
	
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_description_array = !empty($_GET['newit618_description']) ? $_GET['newit618_description'] : array();
	$newit618_videourl_array = !empty($_GET['newit618_videourl']) ? $_GET['newit618_videourl'] : array();
	$newit618_islive_array = !empty($_GET['newit618_islive']) ? $_GET['newit618_islive'] : array();
	$newit618_ischat_array = !empty($_GET['newit618_ischat']) ? $_GET['newit618_ischat'] : array();
	$newit618_isuser_array = !empty($_GET['newit618_isuser']) ? $_GET['newit618_isuser'] : array();
	$newit618_usercode_array = !empty($_GET['newit618_usercode']) ? $_GET['newit618_usercode'] : array();
	$newit618_previewtime_array = !empty($_GET['newit618_previewtime']) ? $_GET['newit618_previewtime'] : array();
	$newit618_videotime1_array = !empty($_GET['newit618_videotime1']) ? $_GET['newit618_videotime1'] : array();
	$newit618_videotime2_array = !empty($_GET['newit618_videotime2']) ? $_GET['newit618_videotime2'] : array();
	$newit618_videotime3_array = !empty($_GET['newit618_videotime3']) ? $_GET['newit618_videotime3'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		
		if(trim($newit618_name_array[$key]) != '') {
			
			$it618_videotime1=intval($newit618_videotime1_array[$key]);
			$it618_videotime2=intval($newit618_videotime2_array[$key]);
			$it618_videotime3=intval($newit618_videotime3_array[$key]);
			
			$it618_videotime=$it618_videotime1*3600+$it618_videotime2*60+$it618_videotime3;
			
			$it618_videourl= trim($newit618_videourl_array[$key]);
			$it618_videourl=str_replace("'",'"',$it618_videourl);
			$it618_videourl=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" frameborder=0 allowfullscreen=1>',$it618_videourl);
			
			$tmparr=explode("<iframe",$it618_videourl);
			if(count($tmparr)>1){
				$urlarr=explode("https://",$_G['siteurl']);
				if(count($urlarr)>1){
					$it618_videourl=str_replace("http://","https://",$it618_videourl);
				}
			}
			
			if($it618_video_media_mts=C::t('#it618_video#it618_video_media_mts')->fetch_by_url($it618_videourl)){
				if($it618_video_media_mts['it618_shopid']!=$ShopId){
					$it618_videourl='';
				}
			}
			                                        
			$id=C::t('#it618_video#it618_video_goods_video')->insert(array(
				'it618_pid' => $it618_video_goods_lesson['it618_pid'],
				'it618_lid' => $lid,
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_description' => trim($newit618_description_array[$key]),
				'it618_videourl' => $it618_videourl,
				'it618_islive' => trim($newit618_islive_array[$key]),
				'it618_isuser' => trim($newit618_isuser_array[$key]),
				'it618_usercode' => trim($newit618_usercode_array[$key]),
				'it618_previewtime' => 0,
				'it618_videotime' => $it618_videotime,
				'it618_videotime1' => $it618_videotime1,
				'it618_videotime2' => $it618_videotime2,
				'it618_videotime3' => $it618_videotime3,
				'it618_ison' => 1,
				'it618_order' => trim($newit618_order_array[$key])
			), true);
			
			if(trim($newit618_isuser_array[$key])==1){
				$tmparr=explode("<iframe",$it618_videourl);
				if(count($tmparr)==1){
					C::t('#it618_video#it618_video_goods_video')->update($id,array(
						'it618_previewtime' => trim($newit618_previewtime_array[$key])
					));
				}
			}
			
			if($IsChat==1){
				C::t('#it618_video#it618_video_goods_video')->update($id,array(
					'it618_ischat' => trim($newit618_ischat_array[$key])
				));
			}
			
			$ok2=$ok2+1;
		}
	}
	
	$it618_video_goods_videotmp=C::t('#it618_video#it618_video_goods_video')->fetch_count_time_by_pid($it618_video_goods_lesson['it618_pid']);
	C::t('#it618_video#it618_video_goods')->update($it618_video_goods_lesson['it618_pid'],array(
		'it618_videocount' => $it618_video_goods_videotmp['videocount'],
		'it618_videotime' => $it618_video_goods_videotmp['videotime']
	));
	
	$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_lesson['it618_pid']);
	if($it618_video_goods['it618_allvideocount']<$it618_video_goods_videotmp['videocount']){
		C::t('#it618_video#it618_video_goods')->update($it618_video_goods_lesson['it618_pid'],array(
			'it618_allvideocount' => $it618_video_goods_videotmp['videocount']
		));
	}
	
	$it618_video_goods_videotmp=C::t('#it618_video#it618_video_goods_video')->fetch_count_time_by_lid($lid);
	C::t('#it618_video#it618_video_goods_lesson')->update($lid,array(
		'it618_videocount' => $it618_video_goods_videotmp['videocount'],
		'it618_videotime' => $it618_video_goods_videotmp['videotime']
	));

	it618_cpmsg($it618_video_lang['s33'].$ok1.' '.$it618_video_lang['s34'].$ok2.' '.$it618_video_lang['s35'].$del.')', "plugin.php?id=it618_video:sc_product_video$adminsid&lid=$lid&preurl=$preurl&page=$page&lid=$lid", 'succeed');
}

if(submitcheck('it618submit_move')){
	$ok=0;
	foreach($_GET['delete'] as $key => $id) {
		C::t('#it618_video#it618_video_goods_video')->update($id,array(
			'it618_lid' => $_GET['lessonid']
		));
		$ok=$ok+1;
	}
	
	$it618_video_goods_videotmp=C::t('#it618_video#it618_video_goods_video')->fetch_count_time_by_lid($_GET['lessonid']);
	C::t('#it618_video#it618_video_goods_lesson')->update($_GET['lessonid'],array(
		'it618_videocount' => $it618_video_goods_videotmp['videocount'],
		'it618_videotime' => $it618_video_goods_videotmp['videotime']
	));
	
	$it618_video_goods_videotmp=C::t('#it618_video#it618_video_goods_video')->fetch_count_time_by_lid($lid);
	C::t('#it618_video#it618_video_goods_lesson')->update($lid,array(
		'it618_videocount' => $it618_video_goods_videotmp['videocount'],
		'it618_videotime' => $it618_video_goods_videotmp['videotime']
	));
	
	it618_cpmsg($it618_video_lang['s643'].$ok, "plugin.php?id=it618_video:sc_product_video$adminsid&lid=$lid&preurl=$preurl&page=$page&lid=$lid", 'succeed');
}

$it618_gtype=it618_video_getlang('s380');
$it618_gtype1=it618_video_getlang('s382');
$it618_gtype2=it618_video_getlang('s383');
$it618_gtype3=it618_video_getlang('s401');
$it618_gtype4=it618_video_getlang('s1769');
$it618_gtype5=it618_video_getlang('s646');
$it618_gtype6=it618_video_getlang('s1202');

it618_showformheader("plugin.php?id=it618_video:sc_product_video$adminsid&lid=$lid&preurl=$preurl&page=$page&lid=$lid");
showtableheaders('<a href="plugin.php?id=it618_video:sc_product_lesson'.$adminsid.'&pid='.$it618_video_goods_lesson['it618_pid'].'&preurl='.$preurl.'">'.$it618_video_lang['s506'].'<font color=red>'.$it618_video_lang['s514'].$it618_video_goods['it618_name'].' - '.$it618_video_goods_lesson['it618_name'].$it618_video_lang['s515'].'</font></a> '.$it618_gtype,'sc_product_video');

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_video')." WHERE it618_lid=".$lid);
$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_video:sc_product_video$adminsid&page=$page&lid=$lid");

echo '
<style>
.sc_product_video tr td{vertical-align:top}
</style>
<tr><td colspan=15>'.$it618_video_lang['s381'].$count.'<span style="float:right;">'.$it618_gtype3.'</span></td></tr>';

$it618_exam = $_G['cache']['plugin']['it618_exam'];

showsubtitle(array($it618_video_lang['s56'], $it618_gtype1,$it618_gtype2, $it618_video_lang['s384'], $it618_video_lang['s385']));

$n=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_video')." WHERE it618_lid=".$lid." ORDER BY it618_order,id limit $startlimit,$ppp");
while($it618_video_goods_video = DB::fetch($query)) {
	
	if($it618_video_goods_video['it618_islive']==1){$it618_islive_checked='checked="checked"';}else $it618_islive_checked="";
	if($it618_video_goods_video['it618_ischat']==1){$it618_ischat_checked='checked="checked"';}else $it618_ischat_checked="";
	
	$previewcss='display:none';$usercodecss='display:none';$usercodeaboutcss='display:none';
	if($it618_video_goods_video['it618_isuser']==0){$it618_isuser_selected0='selected="selected"';$isusercolor='#390';$usercodecss='display:';}else $it618_isuser_selected0="";
	if($it618_video_goods_video['it618_isuser']==1){$it618_isuser_selected1='selected="selected"';$isusercolor='#f30';$previewcss='display:';}else $it618_isuser_selected1="";
	if($it618_video_goods_video['it618_isuser']==2){$it618_isuser_selected2='selected="selected"';$isusercolor='#22b1fe';$usercodecss='display:';}else $it618_isuser_selected2="";
	
	if($it618_video_goods_video['it618_isuser']!=1){
		if($it618_video_goods_video['it618_usercode']!='')$usercodeaboutcss='display:';
	}
	
	$mtsmp4str='';
	if($it618_video_media_mts=C::t('#it618_video#it618_video_media_mts')->fetch_by_url($it618_video_goods_video['it618_videourl'])){
		$it618_video_media=C::t('#it618_video#it618_video_media')->fetch_by_id($it618_video_media_mts['it618_media_id']);
		$mediaimg=it618_video_cdnkeyurl($it618_video_media['it618_coverurl']);
		$mtsmp4str='[<a href="'.it618_video_getsignedurl($it618_video_media['it618_url']).'" target="_blank">'.$it618_video_lang['s46'].'</a>]';
	}
	
	if($Shopisale==1){
		$salecount = $it618_video_goods_video['it618_salecount'];
		$salemoney = $it618_video_goods_video['it618_salemoney'];
	
		$typecountall = C::t('#it618_video#it618_video_goods_type')->counttype_by_pid_lid_vid($it618_video_goods_video['it618_pid'],$it618_video_goods_video['it618_lid'],$it618_video_goods_video['id']);
		$typecountok = C::t('#it618_video#it618_video_goods_type')->counttype_by_pid_lid_vid_ok($it618_video_goods_video['it618_pid'],$it618_video_goods_video['it618_lid'],$it618_video_goods_video['id']);
		$goodstypestr='<a href="javascript:" onclick="showgoodstype('.$it618_video_goods_video['it618_pid'].','.$it618_video_goods_video['it618_lid'].','.$it618_video_goods_video['id'].')"><img src="source/plugin/it618_video/images/price.png" style="vertical-align:middle;height:13px;margin-top:-1px;margin-right:3px">'.$it618_video_lang['s710'].'</font></a> <font color=#888>('.$typecountok.'/'.$typecountall.')</font><span style="float:right;color:#999">'.it618_video_getlang('s119').''.$salecount.' '.it618_video_getlang('s120').''.$salemoney.'</span>';
		
		$goodstypecss='';
		if($typecountok>0){
			$goodstypecss='display:none';
		}
	}else{
		$goodstypecss='display:none';
		$salecss='display:none';
	}
	
	if($it618_video_goods_video['it618_issale']==1){
		$it618_issale_checked='checked="checked"';
		$issalecss='';
	}else{
		$it618_issale_checked="";
		$issalecss='display:none';
	}
	
	if($it618_video_goods_video['it618_videoimg']!=''){
		$it618_videoimg=$it618_video_goods_video['it618_videoimg'];
	}else{
		$it618_videoimg='source/plugin/it618_video/images/videoimg.png';
		if($mediaimg!='')$it618_videoimg=$mediaimg;
	}
	
	$tmpurl=it618_video_getrewrite('video_lesson',$it618_video_goods_video['id'],'plugin.php?id=it618_video:lesson&lid='.$it618_video_goods_video['id']);
	
	$disabled="";
	if($it618_video_goods_video['it618_liveid']==0){
		if($it618_exam['seotitle']!=''){
			$examcount=C::t('#it618_video#it618_video_goods_video_exam')->count_by_vid($it618_video_goods_video['id']);
			$tmpexam='<a href="javascript:" onclick="addexams('.$it618_video_goods_video['id'].',\''.$it618_video_goods['it618_name'].' -> '.it618_video_getsmsstr($it618_video_goods_video['it618_name'],60).'\')"><img src="source/plugin/it618_video/images/addpaper.png" style="vertical-align:middle;height:15px;margin-top:-1px;margin-right:3px">'.$it618_video_lang['s1426'].'</a> <a href="javascript:" onclick="editexams('.$it618_video_goods_video['id'].',\''.$it618_video_goods['it618_name'].' -> '.it618_video_getsmsstr($it618_video_goods_video['it618_name'],60).'\')"><img src="source/plugin/it618_video/images/paper.png" style="vertical-align:middle;height:14px;margin-top:-1px;margin-right:3px">'.$it618_video_lang['s1427'].'</a> <font color=#888>('.$examcount.')</font>';
		}
	
		$namestr='<div style="width:460px;">
		<div style="width:80px;float:left;text-align:center">
		<a href="'.$tmpurl.'" target="_blank"><img src="'.$it618_videoimg.'" style="height:50px;width:80px;border-radius:3px;margin-bottom:6px"></a><br><a href="javascript:" onclick="showvideoimg('.$it618_video_goods_video['id'].')" style="color:#999">'.it618_video_getlang('s1615').'</a><br>
		<div style="margin-top:6px"><a href="javascript:" onclick="showvideocontent('.$it618_video_goods_video['id'].')"><img src="source/plugin/it618_video/images/xq.png" style="vertical-align:middle;height:13px;margin-top:-2px;margin-right:3px;">'.it618_video_getlang('s1602').'</a> <font color=#888>('.strlen($it618_video_goods_video['it618_message']).')</font></div>
		</div>
		<div style="width:358px;float:left"><input type="text" class="txt" style="width:355px;margin-bottom:3px;margin-left:6px" id="name'.$it618_video_goods_video['id'].'" name="it618_name['.$it618_video_goods_video['id'].']" value="'.$it618_video_goods_video['it618_name'].'" ><br>
		<textarea name="it618_description['.$it618_video_goods_video['id'].']" style="width:355px;height:43px;margin-bottom:6px;margin-left:6px">'.$it618_video_goods_video['it618_description'].'</textarea><br>
		<span style="float:right">'.$tmpexam.'</span>
		<a href="plugin.php?id=it618_video:sc_product_data'.$adminsid.'&vid='.$it618_video_goods_video['id'].'&preurl='.$preurl.'"><img src="source/plugin/it618_video/images/fj.png" style="vertical-align:middle;height:12px;margin-top:-3px;margin-right:3px;margin-left:6px">'.$it618_video_lang['s442'].'</a> <font color=#888>('.$it618_video_goods_video['it618_datacount'].')</font></div></div>';
		$videostr='<div style="position:absolute;bottom:28px;right:18px"><input type="checkbox" id="it618_islive'.$it618_video_goods_video['id'].'" name="it618_islive['.$it618_video_goods_video['id'].']" value=1 style="vertical-align:middle" '.$it618_islive_checked.'><label for="it618_islive'.$it618_video_goods_video['id'].'">'.$it618_video_lang['s1013'].'</label></div><textarea id="videourl'.$it618_video_goods_video['id'].'" name="it618_videourl['.$it618_video_goods_video['id'].']" style="width:460px;height:67px;margin-bottom:6px">'.$it618_video_goods_video['it618_videourl'].'</textarea><br>
		'.$it618_video_lang['s399'].'<input id="time1'.$it618_video_goods_video['id'].'" type="text" class="txt" style="width:23px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" name="it618_videotime1['.$it618_video_goods_video['id'].']" value="'.$it618_video_goods_video['it618_videotime1'].'">'.$it618_video_lang['s397'].'
		<input id="time2'.$it618_video_goods_video['id'].'" type="text" class="txt" style="width:23px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" name="it618_videotime2['.$it618_video_goods_video['id'].']" value="'.$it618_video_goods_video['it618_videotime2'].'">'.$it618_video_lang['s398'].'
		<input id="time3'.$it618_video_goods_video['id'].'" type="text" class="txt" style="width:23px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" name="it618_videotime3['.$it618_video_goods_video['id'].']" value="'.$it618_video_goods_video['it618_videotime3'].'">'.$it618_video_lang['s400'].' '.$mtsmp4str.' <span style="float:right">[<a href="javascript:" onclick="media_select1('.$it618_video_goods_video['id'].')">'.$it618_gtype6.'</a>] [<a href="javascript:" onclick="media_select('.$it618_video_goods_video['id'].')">'.$it618_gtype4.'</a>]</span></div>';
		
		$livecss='display:';
		
	}else{
		$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
		$namestr='<div style="width:460px;">
		<div style="width:80px;float:left;text-align:center">
		<a href="'.$tmpurl.'" target="_blank"><img src="'.$it618_videoimg.'" style="height:50px;width:80px;border-radius:3px;margin-bottom:6px"></a><br><a href="javascript:" onclick="showvideoimg('.$it618_video_goods_video['id'].')" style="color:#999">'.it618_video_getlang('s1615').'</a>
		<div style="margin-top:6px"><a href="javascript:" onclick="showvideocontent('.$it618_video_goods_video['id'].')"><img src="source/plugin/it618_video/images/xq.png" style="vertical-align:middle;height:13px;margin-top:-2px;margin-right:3px">'.it618_video_getlang('s1602').'</a> <font color=#888>('.strlen($it618_video_goods_video['it618_message']).')</font></div>
		</div>
		<div style="width:358px;float:left;margin-left:6px;line-height:15px">'.$it618_video_live['it618_name'].'<br><font color=#999>'.$it618_video_live['it618_description'].'</font></div></div>';
		
		if($it618_video_live['it618_ossbucket']!=''&&$it618_video_live['it618_ossendpoint']!=''){
			$livesetstr=$it618_video_lang['s1302'].$it618_video_live['it618_livetime'].$it618_video_lang['s1305'].' '.$it618_video_lang['s1272'];
		}else{
			$videostr=$it618_video_lang['s1302'].$it618_video_live['it618_livetime'].$it618_video_lang['s1305'].' '.$it618_video_lang['s1273'];
		}
		
		$livecss='display:none';
		$previewcss='display:none';
		$disabled="disabled=\"disabled\"";
	}
	
	if($IsChat==1){
		if($it618_video_goods_video['it618_ischat']==0){$it618_ischat_selected0='selected="selected"';}else $it618_ischat_selected0="";
		if($it618_video_goods_video['it618_ischat']==1){$it618_ischat_selected1='selected="selected"';}else $it618_ischat_selected1="";
		if($it618_video_goods_video['it618_ischat']==2){$it618_ischat_selected2='selected="selected"';}else $it618_ischat_selected2="";
		if($it618_video_goods_video['it618_ischat']==3){$it618_ischat_selected3='selected="selected"';}else $it618_ischat_selected3="";
		
		$chatstr='<br><select name="it618_ischat['.$it618_video_goods_video['id'].']" style="margin-top:3px;'.$livecss.'"><option value=3 '.$it618_ischat_selected3.'>'.$it618_video_lang['s1018'].'</option><option value=2 '.$it618_ischat_selected2.'>'.$it618_video_lang['s1019'].'</option><option value=1 '.$it618_ischat_selected1.'>'.$it618_video_lang['s1020'].'</option><option value=0 '.$it618_ischat_selected0.'>'.$it618_video_lang['s1021'].'</option></select>';
	}
	
	$tmparr=explode("<iframe",$it618_video_goods_video['it618_videourl']);
	if(count($tmparr)>1){
		$previewcss='display:none';
	}
	
	if($it618_video_goods_video['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
	
	showtablerow('', array('class="td25"', '', '', '', '', ''), array(
		'<input class="checkbox" type="checkbox" id="chk_del'.$it618_video_goods_video['id'].'" name="delete[]" value="'.$it618_video_goods_video['id'].'" '.$disabled.'><label for="chk_del'.$it618_video_goods_video['id'].'">'.$it618_video_goods_video['id'].'</label>',
		$namestr,
		'
		<div style="width:460px;position:relative">
		'.$videostr.'

		<div style="width:460px;line-height:26px;margin-top:6px'.$salecss.';border:#f1f1f1 1px solid;padding:3px"><input class="checkbox" type="checkbox" id="chk_isprotect'.$n.'" name="it618_issale['.$it618_video_goods_video['id'].']" '.$it618_issale_checked.' value="1" onchange="getprice(this,'.$it618_video_goods_video['id'].')"><label for="chk_isprotect'.$n.'">'.it618_video_getlang('s1897').'</label> <span id="spanprice'.$it618_video_goods_video['id'].'" style="'.$issalecss.'">
		
		<div style="'.$goodstypecss.'">
		<input type="text" class="txt" style="width:80px;margin-right:3px;color:red;" name="it618_saleprice['.$it618_video_goods_video['id'].']" value="'.$it618_video_goods_video['it618_saleprice'].'">'.it618_video_getlang('s125').'+<input type="text" class="txt" style="width:80px;margin-right:3px;;color:red" name="it618_score['.$it618_video_goods_video['id'].']" value="'.$it618_video_goods_video['it618_score'].'"><select name="it618_jfid['.$it618_video_goods_video['id'].']">'.it618_video_getjftype($it618_video_goods_video['it618_jfid']).'</select> '.$it618_video_lang['s1795'].'<input type="text" class="txt" style="width:80px;margin-right:3px;" name="it618_price['.$it618_video_goods_video['id'].']" value="'.$it618_video_goods_video['it618_price'].'">'.it618_video_getlang('s125').'
		</div>
		<div>
		'.$goodstypestr.$goodspinstr.'
		</div>
		</span></div>
		</div>
		',
		'<select style="color:'.$isusercolor.';margin-bottom:3px" name="it618_isuser['.$it618_video_goods_video['id'].']" onchange="setisuser('.$it618_video_goods_video['id'].',this)"><option value=1 '.$it618_isuser_selected1.' style="color:#f30">'.$it618_video_lang['s27'].'</option><option value=2 '.$it618_isuser_selected2.' style="color:#22b1fe">'.$it618_video_lang['s28'].'</option><option value=0 '.$it618_isuser_selected0.' style="color:#390">'.$it618_video_lang['s30'].'</option></select><span id="usercodespan'.$it618_video_goods_video['id'].'" style="'.$usercodecss.'"><br>'.$it618_video_lang['s1598'].':<input type="text" class="txt" style="width:38px;color:blue;text-align:center;margin-right:3px;margin-bottom:3px;margin-left:3px" onclick="this.select();" name="it618_usercode['.$it618_video_goods_video['id'].']" value="'.$it618_video_goods_video['it618_usercode'].'"><span style="'.$usercodeaboutcss.'"><br><a href="javascript:" onclick="showvideocode('.$it618_video_goods_video['id'].')">'.it618_video_getlang('s1977').'</a> <font color=#888>('.strlen($it618_video_goods_video['it618_usercodeabout']).')</font></span></span><span id="previewspan'.$it618_video_goods_video['id'].'" style="'.$previewcss.'"><br>'.$it618_video_lang['s1713'].':<input type="text" class="txt" style="width:26px;color:blue;text-align:center;margin-right:3px;margin-left:3px" onclick="this.select();" name="it618_previewtime['.$it618_video_goods_video['id'].']" value="'.$it618_video_goods_video['it618_previewtime'].'">'.$it618_video_lang['s400'].'</span>'.$chatstr,
		'<input type="text" class="txt" style="width:40px;text-align:center;margin-bottom:3px" name="it618_order['.$it618_video_goods_video['id'].']" value="'.$it618_video_goods_video['it618_order'].'"><br>
		<input class="checkbox" type="checkbox" id="chk_ison'.$n.'" name="it618_ison['.$it618_video_goods_video['id'].']" '.$it618_ison_checked.' value="1" style="'.$livecss.'"><label for="chk_ison'.$n.'" style="'.$livecss.'">'.it618_video_getlang('s104').'</label>'
	));
	$n=$n+1;
}

$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_lesson')." where it618_pid=".$it618_video_goods_lesson['it618_pid']." and id!=".$lid." and it618_type=1 ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}
	

	$it618_video_langs399=$it618_video_lang['s399'];
	$it618_video_langs397=$it618_video_lang['s397'];
	$it618_video_langs398=$it618_video_lang['s398'];
	$it618_video_langs400=$it618_video_lang['s400'];
	$it618_video_langs315=$it618_video_lang['s315'];
	$it618_video_langs1769=$it618_video_lang['s1769'];
	$it618_video_langs1202=$it618_video_lang['s1202'];
	$it618_video_langs27=$it618_video_lang['s27'];
	$it618_video_langs28=$it618_video_lang['s28'];
	$it618_video_langs30=$it618_video_lang['s30'];
	$it618_video_langs1013=$it618_video_lang['s1013'];
	$it618_video_langs1018=$it618_video_lang['s1018'];
	$it618_video_langs1019=$it618_video_lang['s1019'];
	$it618_video_langs1020=$it618_video_lang['s1020'];
	$it618_video_langs1021=$it618_video_lang['s1021'];
	$it618_video_langs1713=$it618_video_lang['s1713'];
	$it618_video_langs1598=$it618_video_lang['s1598'];
	
	if($IsChat!=1){
		$chatcss='display:none';
	}
	
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<div style="height:50px;width:80px;float:left;border-radius:3px;margin-bottom:6px"></div><div style="float:left;margin-left:6px;"><input type="text" class="txt" style="width:350px" id="name1000'+n+'" name="newit618_name[]"><br><textarea name="newit618_description[]" style="width:350px;height:46px;margin-top:3px"></textarea></div>'],
		[1,'<div style="width:536px;position:relative"><div style="position:absolute;bottom:28px;right:18px"><input type="checkbox" id="it618_islive1000'+n+'" name="newit618_islive[]" value=1 style="vertical-align:middle"><label for="it618_islive1000'+n+'">$it618_video_langs1013</label></div><textarea id="videourl1000'+n+'" name="newit618_videourl[]" style="width:530px;height:46px;margin-bottom:3px"></textarea><br>$it618_video_langs399<input type="text" class="txt" style="width:26px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" id="time11000'+n+'" name="newit618_videotime1[]">$it618_video_langs397<input type="text" class="txt" style="width:26px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" id="time21000'+n+'" name="newit618_videotime2[]">$it618_video_langs398<input type="text" class="txt" style="width:26px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" id="time31000'+n+'" name="newit618_videotime3[]">$it618_video_langs400<span style="float:right">[<a href="javascript:" onclick="media_select1(1000'+n+')">$it618_video_langs1202</a>] [<a href="javascript:" onclick="media_select(1000'+n+')">$it618_video_langs1769</a>]</span></div>'],
		[1,'<select name="newit618_isuser[]" onchange="setisuser1('+n+',this)" style="color:#f30;margin-bottom:3px"><option value=1 style="color:#f30">$it618_video_langs27</option><option value=2 style="color:#22b1fe">$it618_video_langs28</option><option value=0 style="color:#390">$it618_video_langs30</option></select><span id="usercodespan0'+n+'" style="display:none"><br>$it618_video_langs1598:<input type="text" class="txt" style="width:38px;color:blue;text-align:center;margin-right:3px;margin-left:3px" onclick="this.select();" name="newit618_usercode[]" value=""></span><span id="previewspan0'+n+'"><br>$it618_video_langs1713:<input type="text" class="txt" style="width:26px;color:blue;text-align:center;margin-right:3px;margin-left:3px" onclick="this.select();" name="newit618_previewtime[]" value="">$it618_video_langs400</span><span style="$chatcss"><br><select name="newit618_ischat[]" style="margin-top:3px;"><option value=3>$it618_video_langs1018</option><option value=2>$it618_video_langs1019</option><option value=1>$it618_video_langs1020</option><option value=0>$it618_video_langs1021</option></select>'],
		[1,'<input type="text" class="txt" style="width:26px" name="newit618_order[]">']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$it618_video_lang['s831'].'</a> <input type="button" style="margin-left:6px;float:right" class="btn" onclick="showdao()" value="'.it618_video_getlang('s1984').'"/> <input type="btn" class="btn" name="it618submit_daochu" style="width:158px;float:right" onclick="dao()" value="'.it618_video_getlang('s1985').' "/></div></td></tr>';
    
    echo '
    <span id="it618_media_select"></span>
	<script>
	function getprice(obj,tmpn){
		if(!obj.checked){
			document.getElementById("spanprice"+tmpn).style.display="none";
		}else{
			document.getElementById("spanprice"+tmpn).style.display="";
		}
	}
	
	function showdao(){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_video_lang['s1984'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["68%", "68%"],
			content: "plugin.php?id=it618_video:sc_product_video_dao'.$adminsid.'&lid='.$lid.'",
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	
	function dao(){
		IT618_VIDEO.get("'.$_G['siteurl'].'plugin.php?id=it618_video:ajax'.$adminsid.'&lid='.$lid.'&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"video_dao"},function (data, textStatus){
		window.open(data);
		}, "html");	
	}
	
	function setisuser1(vid,obj){
		setisuser("0"+vid,obj);
	}
	
	function setisuser(vid,obj){
		document.getElementById("usercodespan"+vid).style.display="none"; 
		document.getElementById("previewspan"+vid).style.display="none"; 
		
		if(obj.value==1){
			document.getElementById("previewspan"+vid).style.display="";
			obj.style.color="#f30";
		}
		if(obj.value==2){
			document.getElementById("usercodespan"+vid).style.display="";	
			obj.style.color="#22b1fe";
		}
		if(obj.value==0){
			document.getElementById("usercodespan"+vid).style.display="";
			obj.style.color="#390";
		}
	}
	
	function showgoodstype(pid,lid,vid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_video_lang['s710'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_video:sc_product_type'.$adminsid.'&pid="+pid+"&lid="+lid+"&vid="+vid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	
	function showvideocontent(vid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_video_lang['s1602'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_video:sc_product_content_edit&type=videocontent'.$adminsid.'&vid="+vid,
			cancel: function(index, layero){ 

			}    
		});
	}
	
	function showvideoimg(vid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_video_lang['s1615'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["800px", "380px"],
			content: "plugin.php?id=it618_video:sc_product_videoimg'.$adminsid.'&vid="+vid,
			cancel: function(index, layero){ 

			}    
		});
	}
	
	function addexams(vid,title){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>"+title+" - '.$it618_video_lang['s1426'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_exam:sc_product_examadd'.$adminsid.'&vid="+vid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	
	function editexams(vid,title){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>"+title+" - '.$it618_video_lang['s1427'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_exam:sc_product_examedit'.$adminsid.'&vid="+vid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	
	function showvideocode(vid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_video_lang['s1978'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_video:sc_product_content_edit'.$adminsid.'&type=usercodeabout&vid="+vid,
			cancel: function(index, layero){ 

			}    
		});
	}
	
	var vid,type;
	function media_select(id){
		vid=id;type="video";title="'.$it618_video_lang['s1777'].'";
		document.getElementById("it618_media_select").click();
	}
	function media_select1(id){
		vid=id;type="video1";title="'.$it618_video_lang['s1201'].'";
		document.getElementById("it618_media_select").click();
	}
	
    var dialog_media;
    KindEditor.ready(function(K) {K("#it618_media_select").click(function() {
    
        dialog_media = K.dialog({
            width : 848,
            height: 558,
            title : title,
            body : \'<div><iframe id="ifa_media" src="plugin.php?id=it618_video:sc_media_select'.$adminsid.'&type=\'+type+\'" style="border:0;" frameborder=0 width="848" height="536"></iframe></div>\',
            closeBtn : {
                name : "'.$it618_video_lang['t285'].'",
                click : function(e) {
                    dialog_media.remove();
                }
            }
        });
    
    });});
    </script>';
	
	if($tmp!='')$tmp='<span style="float:right"><select name="lessonid">'.$tmp.'</select> <input type="submit" class="btn" name="it618submit_move" value="'.$it618_gtype5.'" onclick="return confirm(\''.it618_video_getlang('s661').'\')" /></span>';
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_video_getlang('s644').'</label></td><td colspan="15"><input type="submit" class="btn" name="it618submit" value="'.it618_video_getlang('s645').'"/>'.$tmp.'<div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></div><br><font color=#999>'.$it618_video_lang['s1710'].'</font></td></tr>';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>