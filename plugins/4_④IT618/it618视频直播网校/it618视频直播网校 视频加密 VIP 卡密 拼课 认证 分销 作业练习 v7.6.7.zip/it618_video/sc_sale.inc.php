<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

echo '
<script charset="utf-8" src="source/plugin/it618_video/js/laydate/laydate.js"></script>
<script charset="utf-8" src="source/plugin/it618_video/js/jquery.js"></script>
';

showtableheaders(it618_video_getlang('s413'),'it618_video_sum');

	echo '<tr><td colspan="15"><div class="fixsel">'.it618_video_getlang('s224').' <input id="pname" class="txt" style="width:180px;margin-right:1px" /> '.it618_video_getlang('s761').' <input id="finduid" class="txt" style="width:76px" />'.it618_video_getlang('s228').' <input id="it618_time1" class="txt" style="width:90px;margin-right:0" readonly="readonly" />-<input id="it618_time2" class="txt" style="width:90px;" readonly="readonly"/> &nbsp;<input type="button" class="btn" value="'.it618_video_getlang('s763').'" onclick="findsalelist()" /> <input type="button" class="btn" value="'.it618_video_getlang('s1102').'" onclick="dao()" /> </div></td></tr>';
	
	echo '<tr id="tr_salesum"></tr>';
	
	showsubtitle(array('', it618_video_getlang('s233'),it618_video_getlang('t202'),it618_video_getlang('s419'),it618_video_getlang('s803'),it618_video_getlang('s804')));
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_video/wap/images/loading.gif"></td></tr><tbody id="tr_salelist"></tbody>';
	
	echo '<tr id="salepage"></tr>';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/
echo '
<script>
laydate.render({
  elem: "#it618_time1"
});
laydate.render({
  elem: "#it618_time2"
});

var saleurl="'.$_G['siteurl'].'plugin.php?id=it618_video:ajax";
var sqlurl="";
function getsalelist(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("tr_salelist").style.display="none";
	IT618_VIDEO.post(url+sqlurl+"'.$adminsid.'&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"sale_get"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_VIDEO("#tr_salesum").html(tmparr[0]);
	IT618_VIDEO("#tr_salelist").html(tmparr[1]);
	IT618_VIDEO("#salepage").html(tmparr[2]);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("tr_salelist").style.display="";
	}, "html");	
	saleurl=url;
}
getsalelist(saleurl);

function findsalelist(){
	var pname = document.getElementById("pname").value;
	var finduid = document.getElementById("finduid").value;
	var it618_time1 = document.getElementById("it618_time1").value;
	var it618_time2 = document.getElementById("it618_time2").value;
	
	sqlurl="&pname="+pname+"&finduid="+finduid+"&it618_time1="+it618_time1+"&it618_time2="+it618_time2;
	var url="'.$_G['siteurl'].'plugin.php?id=it618_video:ajax";
	getsalelist(url);
}

function dao(){
	findsalelist();
	IT618_VIDEO.get(saleurl+sqlurl+"'.$adminsid.'&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"sale_dao"},function (data, textStatus){
	window.open(data);
	}, "html");	
}
</script>
';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>