<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!video_is_mobile()){
	$tmpurl=it618_video_getrewrite('video_home','','plugin.php?id=it618_video:index');
	dheader("location:$tmpurl");
}

$navtitle=it618_video_getlang('s1863');

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_video_getlang('s835');
}else{
	$shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_uid_ok($_G['uid']);
	if($_G['uid']!=$shoptmp['it618_uid']){
		$error=1;
		$errormsg=it618_video_getlang('s513');
	}
}

if($error==1){
	$_G['mobiletpl'][2]='/';
	include template('it618_video:'.$templatename_wap.'/wap_video');
	return;
}

$scliveurl=it618_video_getrewrite('video_wap','sc_live@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_live&cid='.$shoptmp['id']);
$scliveseturl=it618_video_getrewrite('video_wap','sc_liveset@0','plugin.php?id=it618_video:wap&pagetype=sc_liveset&cid=0');
$scproducturl=it618_video_getrewrite('video_wap','sc_product@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_product&cid='.$shoptmp['id']);
$scproductaddurl=it618_video_getrewrite('video_wap','sc_product_add@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_product_add&cid='.$shoptmp['id']);

$sc_str1 = '<tr><td colspan="2" style="padding-bottom:6px;line-height:32px">'.it618_video_getlang('s97').' <input id="key" name="key" class="txt" style="width:300px;margin-right:3px" /><br>'.it618_video_getlang('s1314').' <select id="state" name="state"><option value=0 '.$state0.'>'.it618_video_getlang('s102').'</option><option value=1 '.$state1.'>'.it618_video_getlang('s1350').'</option><option value=2 '.$state2.'>'.it618_video_getlang('s1317').'</option><option value=3 '.$state3.'>'.it618_video_getlang('s1728').'</option><option value=4 '.$state4.'>'.it618_video_getlang('s1318').'</option></select> '.it618_video_getlang('s1315').' <select id="chkstate" name="chkstate"><option value=0 '.$chkstate0.'>'.it618_video_getlang('s102').'</option><option value=1 '.$chkstate1.'>'.it618_video_getlang('s677').'</option><option value=2 '.$chkstate2.'>'.it618_video_getlang('s678').'</option><option value=3 '.$chkstate3.'>'.it618_video_getlang('s679').'</option></select> &nbsp;<input type="button" class="it618btn inputbtn" onclick="searchsclive()" value="'.it618_video_getlang('s350').'" /></td></tr>';

	
$sc_str2 = '
<tr><td><input type="checkbox" name="chkall" style="vertical-align:middle" id="chkallDx4b" class="checkbox" onclick="check_all(this,\'chk_del\')" /><label for="chkallDx4b" style="vertical-align:middle">'.it618_video_getlang('s129').'</label> </td><td><input type="button" class="it618btn inputbtn" onclick="sc_save(\'edit\')" value="'.it618_video_getlang('s1322').'"/> <input type="button" class="it618btn inputbtn" onclick="sc_save(\'del\')" value="'.it618_video_getlang('s1323').'"/></td></tr>';

$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename_wap.'/wap_video');
?>