<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(isset($_GET['cid2'])){
	$classid1=intval($_GET['cid1']);
}else{
	$classid1=intval($_GET['cid']);
}
$classid2=intval($_GET['cid2']);

if(!video_is_mobile()){ 
	$tmpurl=it618_video_getrewrite('video_list','','plugin.php?id=it618_video:list');
	if($classid1>0){
		$tmpurl=it618_video_getrewrite('video_list',$classid1,'plugin.php?id=it618_video:list&class1='.$classid1);
	}
	
	if($classid1>0&&$classid2>0){
		$tmpurl=it618_video_getrewrite('video_list',$classid1.'@'.$classid2,'plugin.php?id=it618_video:list&class1='.$classid1.'&class2='.$classid2);
	}
	dheader("location:$tmpurl");
}

$navtitle=$it618_video_lang['t317'];


$n=1;
if($cid>0){
	$current='';
}else{
	$current='class="current"';
}
$classtmp='<a '.$current.' href="javascript:void(0)" onclick="setselect(\'productclass1\',0,0)" name="productclass1"><span>'.$it618_video_lang['s466'].'</span><i></i></a>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_class1')." ORDER BY it618_order");
while($it618_tmp = DB::fetch($query1)) {
	if($it618_tmp['id']==$classid1){
		$current='class="current"';
		$classjs='setselect(\'productclass1\','.$n.','.$it618_tmp['id'].');';
	}else{
		$current='';
	}
	$classtmp.='<a '.$current.' href="javascript:void(0)" onclick="setselect(\'productclass1\','.$n.','.$it618_tmp['id'].')" name="productclass1"><span>'.$it618_tmp['it618_classname'].'</span><i></i></a>';
	$n=$n+1;
}

if($classid2>0){
	$n=1;
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_class2')." WHERE it618_class1_id=$classid1 ORDER BY it618_order");
	while($it618_tmp = DB::fetch($query1)) {
		if($it618_tmp['id']==$classid2){
			$classid_n2=$n;
		}
		$n=$n+1;
	}
}

$n=1;
$video_hotsw=explode(',',$it618_video['video_hotsw']);
for($i=0;$i<count($video_hotsw);$i++){
	$hotkey.='<a href="javascript:void(0)" onclick="findbykey(\''.$video_hotsw[$i].'\')"><span>'.$video_hotsw[$i].'</span><i></i></a>';
	$n=$n+1;
}

require_once DISCUZ_ROOT.'./source/plugin/it618_video/it618_api.func.php';
$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename_wap.'/wap_video');
?>