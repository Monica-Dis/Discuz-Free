<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($it618_video['video_computer']==1){
	if(!video_is_mobile()){
		$tmpurl=it618_video_getrewrite('video_gwc','','plugin.php?id=it618_video:gwc');
		dheader("location:$tmpurl");
	}
}

$uid = $_G['uid'];
if($uid<=0){
	$error=1;
}

if(isset($_GET['mysale'])){
	$mysale=1;
}

$it618paystr=it618_video_pay('gwcwap',$it618_video_lang['t384']);

$navtitle=it618_video_getlang('t187');

$ucurl=it618_video_getrewrite('video_wap','uc@'.$_G['uid'],'plugin.php?id=it618_video:wap&pagetype=uc');

$tmpurl=it618_video_getrewrite('video_gwc','','plugin.php?id=it618_video:gwc');

if($it618_video['video_saletel']==2){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
	$uhomeurl=it618_members_getrewrite("members_uhome","","plugin.php?id=it618_members:home&ac=sitetelbd&preurl=".urlencode($tmpurl),"?ac=sitetelbd&preurl=".urlencode($tmpurl));
}

$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename_wap.'/wap_video');
?>