<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pid=intval($_GET['cid']);

if(isset($_GET['chaturl'])&&$IsChat==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_chat/chat.func.php';
	echo it618_chat_getchaturl('it618_video','product',$pid);
	exit;
}

if(!video_is_mobile()){ 
	if(isset($_GET['tuiuid'])){
		$urltmp='tuiuid='.$_GET['tuiuid'];
	}
	if(isset($_GET['e'])){
		if($urltmp!='')$urltmp.='&e='.$_GET['e'];else $urltmp.='e='.$_GET['e'];
	}
	
	if($urltmp!=''){
		$tmpurl=it618_video_getrewrite('video_product',$pid,'plugin.php?id=it618_video:product&pid='.$pid.'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=it618_video_getrewrite('video_product',$pid,'plugin.php?id=it618_video:product&pid='.$pid);
	}
	
	dheader("location:$tmpurl");
}

if($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid)){
	$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
	if($it618_video_shop['it618_state']!=2||$it618_video_shop['it618_htstate']!=1){
		$error=10;
		$errormsg=it618_video_getlang('s470');
		$errorurl=it618_video_getrewrite('video_wap','','plugin.php?id=it618_video:wap');
	}
	if($it618_video_shop['it618_uid']==$_G['uid']){
		$isshop=1;
		if($it618_video_goods['it618_state']==0){
			$tmppname=$it618_video_lang['s1842'];
		}
	}
}

if($isshop!=1){
	if(!($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id_state($pid,1))){
		$error=10;
		$errormsg=it618_video_getlang('s470');
		$errorurl=it618_video_getrewrite('video_wap','','plugin.php?id=it618_video:wap');
	}else{
		if(!it618_video_issecretok($it618_video_goods)){
			$error=10;
			$errormsg=it618_video_getlang('s470');
			$errorurl=it618_video_getrewrite('video_wap','','plugin.php?id=it618_video:wap');
		}
	}
}

if($it618_video_shop['it618_ulogo']==''){
	C::t('#it618_video#it618_video_shop')->update($it618_video_shop['id'],array(
		'it618_ulogo' => '/source/plugin/it618_video/images/man.jpg',
	));
}

$footer_mall_wap.='<div style="display:none">'.$it618_video_shop['it618_tongji'].'</div>';

if($error>0){
	$_G['mobiletpl'][2]='/';
	include template('it618_video:'.$templatename_wap.'/wap_video');
	return;
}

$navtitle=$tmppname.$it618_video_goods['it618_name'];

$wapproductad1=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('wapproductad1');
$wapproductad2=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('wapproductad2');

C::t('#it618_video#it618_video_goods')->update_it618_views_by_id($pid);

$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
if($_G['uid']>0){
	if(count($vipgroupids)>0){
		$tmpgrouparr=it618_video_getisvipuser($vipgroupids);
		$isvipuser=count($tmpgrouparr[0]);
	}
}

$isgoodsprice=0;
if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
	$goodspricestr=it618_video_getgoodsprice($it618_video_goods,'goods_price');
	$isgoodsprice=1;
}

if($it618_video_shop['it618_issale']==0){
	$isgoodsprice=1;
}

if($_G['uid']>0&&$isgoodsprice==1){
	$goodssaleok['state']=0;
	if($it618_video_goods_time=C::t('#it618_video#it618_video_goods_time')->fetch_by_uid_pid_lid_vid($_G['uid'],$pid,0,0)){
		if($it618_video_goods_time['it618_etime']==0){
			$goodssaleok['state']=1;
			$goodssaleok['time']=$_G['username'].' '.$it618_video_lang['s1154'];
		}
	}
}

if(count($vipgroupids)>0){
	$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;height:18px;margin-top:-1px;margin-right:3px">';
	if($isvipuser>0){
		$isvipok=1;
	}
	$it618_isvipstr='<a href="javascript:" class="showvipgroupbtn"><font color=red style="font-size:13px">'.$it618_video_lang['s926'].'</font></a> <div id="vippaybtn"></div>';
}

$ShopId=$it618_video_shop['id'];
$goodscount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods')." WHERE it618_shopid=$ShopId and it618_state=1");
$playpjcount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_play_pj')." WHERE it618_score1>0 and it618_shopid=$ShopId");
$playcount=DB::result_first("SELECT SUM(it618_plays) FROM ".DB::table('it618_video_goods')." WHERE it618_shopid=$ShopId");

if($_G['uid']>0){
	if($it618_video_play_pj=C::t('#it618_video#it618_video_play_pj')->fetch_by_pid_uid($it618_video_goods['id'],$_G['uid'])){
		if($it618_video_play_pj['it618_score1']==0){
			$upjstr='<span style="float:right; height:26px; line-height:26px; background-color:'.$it618_video_wapstyle['it618_color1'].'; color:#fff; border-radius:3px; padding:0 10px; margin-top:-10px; cursor:pointer; font-size:14px" id="spanpj" onclick="setplaypj1('.$it618_video_play_pj['id'].')">'.$it618_video_lang['s500'].'</span>';
		}else{
			$upjstr='<span style="float:right; height:30px; line-height:30px; font-size:14px; margin-top:-10px;color:'.$it618_video_wapstyle['it618_color1'].'">'.$it618_video_lang['s728'].'</span>';
		}
	}
}

if(C::t('#it618_video#it618_video_shop_subscribe')->count_by_shopid_uid($ShopId,$_G['uid'])>0){
	$subscribetitle=$it618_video_lang['s1397'];
}else{
	$subscribetitle=$it618_video_lang['s1396'];
}
$shopsubscribes=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_shop_subscribe')." WHERE it618_shopid=".$it618_video_shop['id']);
$shopviews=DB::result_first("SELECT SUM(it618_views) FROM ".DB::table('it618_video_goods')." WHERE it618_shopid=".$it618_video_shop['id']);

$lecturerurl=it618_video_getrewrite('video_lecturer',$it618_video_shop['id'],'plugin.php?id=it618_video:lecturer&lid='.$it618_video_shop['id']);

$adlogo='<img src="'.$it618_video_shop['it618_logo'].'" style="margin-top:3px; max-width:100%; border-radius:3px"/>';

if($it618_video_shop['it618_logourl']!=''){
	$adlogo='<a href="'.$it618_video_shop['it618_logourl'].'" target="_blank">'.$adlogo.'</a>';
}

$it618_message=$it618_video_goods['it618_message'];
$it618_message=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$it618_message);
$it618_message=preg_replace('/<img.+?src=\"(.+?)\".+?>/','<img class="lazy" data-original="\1"/>',$it618_message);
$it618_message=preg_replace('/<table.+?>/','<table cellspacing="0" cellpadding="0" width="100%">',$it618_message);
$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="220" frameborder="0" allowfullscreen="1">',$it618_message);

$pjcount=C::t('#it618_video#it618_video_play_pj')->countpj_by_pid($it618_video_goods['id']);
if($pjcount>0){
	$pjname=C::t('#it618_video#it618_video_class1')->fetch_it618_pj_by_id($it618_video_goods['it618_class1_id']);
	$pjname=explode("_",$pjname);
	
	$pjscore=C::t('#it618_video#it618_video_play_pj')->fetch_sumpjscore_by_pid($it618_video_goods['id']);
	$pjavgscore1=sprintf( "%.1f",$pjscore['score1']/$pjcount);
	$pjavgscore2=sprintf( "%.1f",$pjscore['score2']/$pjcount);
	$pjavgscore3=sprintf( "%.1f",$pjscore['score3']/$pjcount);
	$pjavgscore4=sprintf( "%.1f",$pjscore['score4']/$pjcount);
	$pjpl1=sprintf( "%.1f",$pjavgscore1/5*100);
	$pjpl2=sprintf( "%.1f",$pjavgscore2/5*100);
	$pjpl3=sprintf( "%.1f",$pjavgscore3/5*100);
	$pjpl4=sprintf( "%.1f",$pjavgscore4/5*100);
	
	$pj1_count1=C::t('#it618_video#it618_video_play_pj')->countpj1_by_pid_score($it618_video_goods['id'],1);
	$pj1_count2=C::t('#it618_video#it618_video_play_pj')->countpj1_by_pid_score($it618_video_goods['id'],2);
	$pj1_count3=C::t('#it618_video#it618_video_play_pj')->countpj1_by_pid_score($it618_video_goods['id'],3);
	$pj1_count4=C::t('#it618_video#it618_video_play_pj')->countpj1_by_pid_score($it618_video_goods['id'],4);
	$pj1_count5=C::t('#it618_video#it618_video_play_pj')->countpj1_by_pid_score($it618_video_goods['id'],5);
	
	$mydpl=intval(($pj1_count4+$pj1_count5)/$pjcount*100);
	
	$pj1_pl1=intval($pj1_count1/$pjcount*100);
	$pj1_pl2=intval($pj1_count2/$pjcount*100);
	$pj1_pl3=intval($pj1_count3/$pjcount*100);
	$pj1_pl4=intval($pj1_count4/$pjcount*100);
	$pj1_pl5=intval($pj1_count5/$pjcount*100);
	
	$pj=$pjcount.' '.it618_video_getlang('s482').' '.$pjavgscore1.' '.it618_video_getlang('s483').':'.$mydpl.'% ';
	$it618_pjpfstr=$pjcount.' '.it618_video_getlang('s482').' '.$pjavgscore1.' '.it618_video_getlang('s483').':'.$mydpl.'% ';
}else{
	$pj=it618_video_getlang('s484');	
	$it618_pjpfstr=it618_video_getlang('s484').' ';	
}

$pjpicjs='<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/themes/default/default.css" />
			<script src="source/plugin/it618_video/kindeditor/kindeditor-min.js?v3.9" charset="utf-8"></script>
			<script src="source/plugin/it618_video/kindeditor/lang/zh_CN.js" charset="utf-8"></script>';

DB::query("UPDATE ".DB::table('it618_video_goods')." SET it618_pjpfstr='".$it618_pjpfstr."' WHERE id=$pid");

$timeflag=0;$isxgok=0;
if($it618_video_goods['it618_xgtype']==0)$isxgok=1;

if($it618_video_goods['it618_xgtype']==1){
	$timestr=$it618_video_goods['it618_xgtime1'].' - '.$it618_video_goods['it618_xgtime2'];
	
	$timetmp1=explode(" ",$it618_video_goods['it618_xgtime1']);
	$timetmp2=explode(" ",$it618_video_goods['it618_xgtime2']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);
	
	
	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
	
	$timeflag=1;$timebgcolor='#ff4628';$timecolor='#fff';
	if($etime<$_G['timestamp']){
		$timeflag=0;$timebgcolor='#eee';$timecolor='#999';
		$timetip=it618_video_getlang('s952');
	}else{
		if($btime>$_G['timestamp']){
			$timetip=it618_video_getlang('s953');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_video_goods['it618_xgtime1'];
		}else{
			$timetip=it618_video_getlang('s954');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_video_goods['it618_xgtime2'];
			$isxgok=1;
		}
	}
	
	$isxg=1;
}

if($it618_video_goods['it618_xgtype']==2){
	$timetmp1=explode(" ",$it618_video_goods['it618_xgtime1']);
	$timetmp2=explode(" ",$it618_video_goods['it618_xgtime2']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);
	
	$timestr=$timetmp1[0].' - '.$timetmp2[0].' '.it618_video_getlang('s955').' '.$timetmp1[1].' - '.$timetmp2[1];
	
	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
	
	$timeflag=1;$timebgcolor='#ff4628';$timecolor='#fff';
	if($etime<$_G['timestamp']){
		$timeflag=0;$timebgcolor='#eee';$timecolor='#999';
		$timetip=it618_video_getlang('s952');
	}else{
		if($btime>$_G['timestamp']){
			$timetip=it618_video_getlang('s953');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_video_goods['it618_xgtime1'];
		}else{
			$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
			$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
			$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
			
			if($btimecur>$_G['timestamp']){
				$timetip=it618_video_getlang('s953');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $btimecur);
			}
			
			if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
				$timetip=it618_video_getlang('s954');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $etimecur);
				$isxgok=1;
			}
			
			if($etimecur<$_G['timestamp']){
				$timetip=it618_video_getlang('s953');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $btimecur1);
			}
		}
	}
	
	$isxg=1;
}

$goodspicstr=it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']);

$n=1;$l=1;$lessonurlhref='';
$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_lesson')." WHERE it618_pid=".$pid." ORDER BY it618_order");
while($it618_video_goods_lesson = DB::fetch($query)) {
	
	$lessonpricestr='';
	if($isgoodsprice==1){
		if($it618_video_goods_lesson['it618_issale']==1&&$isgoodsprice==1){
			$lessonpricestr=it618_video_getgoodsprice($it618_video_goods_lesson,'goods_lesson_price');
			$delpricestr='';
			if($it618_video_goods_lesson['it618_price']>0){
				$delpricestr='<del>&yen;'.$it618_video_goods_lesson['it618_price'].'</del>';
			}
			
			$lessonpricestr='<p class="lessonprice">
			<img src="source/plugin/it618_video/template/mall_wap/images/uc_right.png" style="float:right; width:18px; margin-top:-3px; vertical-align:middle">
			<span class="buybtn" onclick="showpay('.$it618_video_goods_lesson['it618_pid'].','.$it618_video_goods_lesson['id'].',0)">'.$it618_video_lang['s1586'].'</span>
			<span class="spanprice">'.$lessonpricestr.' '.$delpricestr.'</span>
			</p>';
			
		}
	}
	
	if($it618_video_goods['it618_lessoncount']>1||$lessonpricestr!=''){
		if($it618_video_goods_lesson['it618_type']==1){
			$videostr.='<tr class="trgroup" onclick="getcourse('.$l.',\'\')">
							<td class="tdindex">
							<img src="source/plugin/it618_video/template/mall_wap/images/li0.png" id="liimg'.$l.'" width="15" style="margin-top:-2px; vertical-align:middle">
							</td>
							<td>
							<b>'.$it618_video_goods_lesson['it618_name'].'</b>
							'.$lessonpricestr.'
							<p style="padding-top:6px"><font color=#999>'.it618_video_getvideocounttime($it618_video_goods_lesson['it618_videocount'],$it618_video_goods_lesson['it618_videotime'],1).'</font></p>
							</td>
						</tr>';
			
			$datalstrtmp='<tr class="trgroup" onclick="getcourse('.$l.',\'data\')">
							<td class="tdindex">
							<img src="source/plugin/it618_video/template/mall_wap/images/li0.png" id="liimgdata'.$l.'" width="15" style="margin-top:-2px; vertical-align:middle">
							</td>
							<td>
							<b>'.$it618_video_goods_lesson['it618_name'].'</b>
							</td>
						</tr>';
						
			$examlstrtmp='<tr class="trgroup" onclick="getcourse('.$l.',\'exam\')">
							<td class="tdindex">
							<img src="source/plugin/it618_video/template/mall_wap/images/li0.png" id="liimgexam'.$l.'" width="15" style="margin-top:-2px; vertical-align:middle">
							</td>
							<td>
							<b>'.$it618_video_goods_lesson['it618_name'].'</b>
							</td>
						</tr>';
		}else{
			$videostr.='<tr class="trgroup">
							<td class="tdindex">
							<img src="source/plugin/it618_video/images/link.png" width="16" style="margin-top:-2px; vertical-align:middle">
							</td>
							<td>
							<b><a href="'.$it618_video_goods_lesson['it618_url'].'" style="font-size:15px;color:#000;display:inline">'.$it618_video_goods_lesson['it618_name'].'</a></b>
							</td>
						</tr>';
		}
	}
	
	if($it618_video_goods_lesson['it618_type']==1){
		$datastrtmp='';$examstrtmp='';
		$v=1;
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_goods_video')." WHERE it618_lid=".$it618_video_goods_lesson['id']." and it618_ison=1 ORDER BY it618_order,id");
		while($it618_video_goods_video = DB::fetch($query1)) {
			
			$videopowertmp=it618_video_getpower($_G['uid'],$it618_video_goods_video['it618_pid'],$it618_video_goods_video['it618_lid'],$it618_video_goods_video['id']);
			
			$lessonurl=it618_video_getrewrite('video_wap','lesson@'.$it618_video_goods_video['id'],'plugin.php?id=it618_video:wap&pagetype=lesson&cid='.$it618_video_goods_video['id']);
			
			$isuserstr='';$videopricestr='';
			
			if($isgoodsprice==1){
				if($it618_video_goods_video['it618_issale']==1&&$it618_video_goods_video['it618_isuser']==1&&$isgoodsprice==1){
					$videopricestr=it618_video_getgoodsprice($it618_video_goods_video,'goods_video_price');
					$delpricestr='';
					if($it618_video_goods_video['it618_price']>0){
						$delpricestr='<del>&yen;'.$it618_video_goods_video['it618_price'].'</del>';
					}
					
					$videopricestr='<p class="lessonprice" onclick="showpay('.$it618_video_goods_video['it618_pid'].','.$it618_video_goods_video['it618_lid'].','.$it618_video_goods_video['id'].')">
					<img src="source/plugin/it618_video/template/mall_wap/images/uc_right.png" style="float:right; width:18px; margin-top:-3px; vertical-align:middle">
					<span class="buybtn">'.$it618_video_lang['s1586'].'</span>
					<span class="spanprice">'.$videopricestr.' '.$delpricestr.'</span>
					</p>';
					
				}
			}
			
			if($it618_video_goods['it618_lessoncount']>1)$tdindex=$l.'.'.$v;else $tdindex=$v;
			
			if($it618_video_goods_video['it618_liveid']>0){
				$it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
				
				$livestate='';
				if($it618_video_live['it618_btime']>$_G['timestamp']){
					$livestate='<font color=red style="font-size:12px">'.it618_video_gettime1($it618_video_live['it618_btime']).$it618_video_lang['s1316'].'</font>';
				}
				
				if($it618_video_live['it618_btime']<$_G['timestamp']&&$_G['timestamp']<$it618_video_live['it618_etime']){
					$livestate='<font color=#23b8ff style="font-size:12px">'.$it618_video_lang['s1317'].'</font>';
				}
				
				if($livestate=='')continue;
				if($it618_video_goods['it618_isprotect']==1&&$_G['uid']!=$it618_video_shop['it618_uid']&&$it618_video_goods_video['it618_isuser']==1){
					if(it618_video_isprotect($isgoodsprice,$videopowertmp,$isvipuser))continue;
				}
				if($lessonurlhref=='')$lessonurlhref=$lessonurl;
				
				if($isgoodsprice==0||$it618_video_goods_video['it618_isuser']==0||$it618_video_goods_video['it618_isuser']==2){
					if($it618_video_goods_video['it618_usercode']!=''){
						$tmpuserstr=$it618_video_lang['s1976'];
					}else{
						$tmpuserstr=$it618_video_lang['s106'];
					}
					$isuserstr='<span class="isuser">'.$tmpuserstr.' </span> ';
				}
				
				$despcss='display:none';
				if($it618_video_live['it618_description']!=''){
					$despcss='';
				}
				
				$it618_name=$it618_video_live['it618_name'];
				
				$videostr.='<tr class="lesson'.$l.'">
								<td class="tdindex">
								'.$tdindex.'
								</td>
								<td>
								<span style="float:right;'.$despcss.'">
								<img src="source/plugin/it618_video/template/mall_wap/images/dec0.png" width="13" onclick="getdesp('.$n.',this)" style="width:13px;">
								</span>
								<a href="'.$lessonurl.'" class="videotdbtn '.$curstr.'">'.$it618_name.'</a>
								'.$videopricestr.'
								<p>'.$isuserstr.'<img src="source/plugin/it618_video/images/live.gif" style="margin-right:1px;margin-top:-1px;height:16px"> '.$livestate.'</p>
								<p id="desp'.$n.'" style="display:none;">'.$it618_video_live['it618_description'].'</p>
								</td>
							</tr>';
	
			}else{
				if($it618_video_goods['it618_isprotect']==1&&$_G['uid']!=$it618_video_shop['it618_uid']&&$it618_video_goods_video['it618_isuser']==1){
					if(it618_video_isprotect($isgoodsprice,$videopowertmp,$isvipuser))continue;
				}
				if($lessonurlhref=='')$lessonurlhref=$lessonurl;
				
				$it618_name=$it618_video_goods_video['it618_name'];
					
				$tmpimg='';$vtimestr='';
				if($it618_video_goods_video['it618_islive']==1){
					$tmpimg='<img src="source/plugin/it618_video/images/live.gif" style="margin-right:1px;margin-top:-1px;height:16px"> <font color=#23b8ff style="font-size:11px">'.$it618_video_lang['s1317'].'</font>';
				}else{
					$vtimestr='<img src="source/plugin/it618_video/template/mall_wap/images/time.png" height="14" style="vertical-align:middle; margin-top:-3px; margin-left:-1px; margin-right:2px" />'.$it618_video_lang['s1900'].' '.it618_video_getvideotimestr($it618_video_goods_video);	
				}
				
				if($isgoodsprice==1){
					if($isgoodsprice==0||$it618_video_goods_video['it618_isuser']==0||$it618_video_goods_video['it618_isuser']==2){
						if($it618_video_goods_video['it618_usercode']!=''){
							$tmpuserstr=$it618_video_lang['s1976'];
						}else{
							$tmpuserstr=$it618_video_lang['s106'];
						}
						$isuserstr='<span class="isuser">'.$tmpuserstr.' </span> ';
					}
					
					$previewtimestr='';
					if($it618_video_goods_video['it618_previewtime']>0){
						$previewtimestr='<span class="isuser">'.$it618_video_lang['s1713'].'</span> ';
					}
					
					if($isuserstr!=''||$previewtimestr!='')$isuserstr=$isuserstr.''.$previewtimestr;
				}
				
				$despcss='display:none';
				if($it618_video_goods_video['it618_description']!=''){
					$despcss='';
				}
							
				$videostr.='<tr class="lesson'.$l.'">
								<td class="tdindex">
								'.$tdindex.'
								</td>
								<td>
								<span style="float:right;'.$despcss.'">
								<img src="source/plugin/it618_video/template/mall_wap/images/dec0.png" onclick="getdesp('.$n.',this)" style="width:13px">
								</span>
								<a href="'.$lessonurl.'" class="videotdbtn '.$curstr.'">'.$it618_name.'</a>
								'.$videopricestr.'
								<p style="font-size:11px; color:#999">'.$isuserstr.''.$vtimestr.$tmpimg.'</p>
								<p id="desp'.$n.'" style="display:none;">'.$it618_video_goods_video['it618_description'].'</p>
								</td>
							</tr>';
			}
			
			$query2 = DB::query("SELECT * FROM ".DB::table('it618_video_goods_data')." WHERE it618_vid=".$it618_video_goods_video['id']." and it618_dataurl!='' ORDER BY it618_order");
			while($it618_video_goods_data = DB::fetch($query2)) {
				$isdata=1;
				$isok=0;
				if($it618_video_goods_data['it618_isuser']==0){
					$isok=1;
				}
				
				if($it618_video_goods_data['it618_isuser']==2){
					$it618_dataurl='<font color=#999>'.$it618_video_lang['s942'].'</font>';
					if($_G['uid']>0){
						$isok=1;
					}
				}
				
				if($it618_video_goods_data['it618_isuser']==1){
					$it618_dataurl='<font color=#999>'.$it618_video_lang['s805'].'</font>';
					
					if($isgoodsprice>0){
						if($videopowertmp['state']>0){
							$isok=1;
						}else{
							if($isvipok==1){
								$isok=1;
							}
						}
					}else{
						$isok=1;
					}
					
					if($_G['uid']>0){
						$it618_video_shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_uid($_G['uid']);
						if($it618_video_goods['it618_shopid']==$it618_video_shoptmp['id']){
							$isok=1;
						}
					}
				}
	
				if($isok==1){
					$it618_dataurl1='href="plugin.php?id=it618_video:datadown&did='.$it618_video_goods_data['id'].'" target="_blank"';
					$it618_dataurl=''.$it618_video_lang['s806'].'';
				}
				
				$datastrtmp.='<tr class="lessondata'.$l.'">
								<td class="tdindex">
								'.$tdindex.'
								</td>
								<td>
								<a '.$it618_dataurl1.' class="videotdbtn">'.$it618_video_goods_data['it618_name'].'</a>
								<p><span style="float:right">'.$it618_dataurl.'</span><span>'.$it618_video_goods_data['it618_datasizestr'].' , '.$it618_video_lang['s46'].': '.$it618_video_goods_data['it618_views'].'</span></p>
								</td>
							</tr>';
				
			}
			
			$query3 = DB::query("SELECT * FROM ".DB::table('it618_video_goods_video_exam')." WHERE it618_vid=".$it618_video_goods_video['id']." ORDER BY it618_order");
			while($it618_video_goods_video_exam = DB::fetch($query3)) {
				$isexam=1;
				
				$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_video_goods_video_exam['it618_tid']);
				
				$examurl=it618_video_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
				
				$it618_exam_goods['it618_examscore']=str_replace(".0","",$it618_exam_goods['it618_examscore']);
				$it618_examstr=str_replace("{qcount}",$it618_exam_goods['it618_questioncount'],$it618_video_lang['s1429']);
				$it618_examstr=str_replace("{score}",$it618_exam_goods['it618_examscore'],$it618_examstr);
				$it618_examstr=str_replace("{time}",$it618_exam_goods['it618_examtime'],$it618_examstr);
				
				
				$isuserstr='';
				if($it618_video_goods_video_exam['it618_power']==1&&$isgoodsprice==1){
					$isuserstr='<span class="isuser">'.$it618_video_lang['s1574'].' </span> ';
				}
		
				$examstrtmp.='<tr class="lessonexam'.$l.'">
								<td class="tdindex">
								'.$tdindex.'
								<td>
								<a href="'.$examurl.'" class="videotdbtn">'.$it618_exam_goods['it618_name'].'</a>
								<p>'.$isuserstr.'<span>'.$it618_examstr.'</span></p>
								</td>
							</tr>';
				
			}
			
			$v=$v+1;
			$n=$n+1;
		}
		
		
		if($datastrtmp!=''){
			$datastr.=$datalstrtmp.$datastrtmp;
		}
		if($examstrtmp!=''){
			$examstr.=$examlstrtmp.$examstrtmp;
		}
		$l=$l+1;
	}
}

if($it618_video_goods['it618_videocount']<$it618_video_goods['it618_allvideocount']){
	$it618_videotimestr=$it618_video_lang['s399'].$it618_video_goods['it618_lessoncount'].$it618_video_lang['s1816'].$it618_video_goods['it618_allvideocount'].$it618_video_lang['s108'].' '.$it618_video_lang['s1893'].$it618_video_goods['it618_videocount'].$it618_video_lang['s108'];
}else{
	$it618_videotimestr=$it618_video_lang['s399'].$it618_video_goods['it618_lessoncount'].$it618_video_lang['s1816'].$it618_video_goods['it618_videocount'].$it618_video_lang['s108'];
}

if($_G['uid']>0){
	$count=C::t('#it618_video#it618_video_collect')->count_by_uid_pid($_G['uid'],$pid);
	if($count>0){
		$collectname=$it618_video_lang['s1650'];
	}else{
		$collectname=$it618_video_lang['s1648'];
	}
}else{
	$collectname=$it618_video_lang['s1648'];
}

if($IsChat==1){
	if($it618_video_shop['it618_isqunchat']==1)$isqunchat=1;
}

$despcount=$n-1;

$uurl=it618_video_getrewrite('video_wap','u@'.$_G['uid'],'plugin.php?id=it618_video:wap&pagetype=u');
$lecturerurl=it618_video_getrewrite('video_wap','lecturer@'.$it618_video_goods['it618_shopid'],'plugin.php?id=it618_video:wap&pagetype=lecturer&cid='.$it618_video_goods['it618_shopid']);

$bottommenu=C::t('#it618_video#it618_video_bottomnav')->fetch_by_id(1);

$footercss='margin-bottom:60px;';

$tmpurl=it618_video_getrewrite('video_wap','product@'.$pid,'plugin.php?id=it618_video:wap&pagetype=product&cid='.$pid.'&e='.$_GET['e'],'?e='.$_GET['e']);
if($it618_video['video_saletel']==2){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
	$uhomeurl=it618_members_getrewrite("members_uhome","","plugin.php?id=it618_members:home&ac=sitetelbd&preurl=".urlencode($tmpurl),"?ac=sitetelbd&preurl=".urlencode($tmpurl));
}

$playtitle=$it618_video_lang['s1645'];
if($it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_mfvideo_by_pid($pid)){
	$playtitle=$it618_video_lang['s1632'];
	$lessonurlhref=it618_video_getrewrite('video_wap','lesson@'.$it618_video_goods_video['id'],'plugin.php?id=it618_video:wap&pagetype=lesson&cid='.$it618_video_goods_video['id']);
}

if($_G['uid']>0){
	if($it618_video_play=C::t('#it618_video#it618_video_play')->fetch_by_uid_pid_etime($_G['uid'],$pid)){
		$playtitle=$it618_video_lang['s1633'];
		$lessonurlhref=it618_video_getrewrite('video_wap','lesson@'.$it618_video_play['it618_vid'],'plugin.php?id=it618_video:wap&pagetype=lesson&cid='.$it618_video_play['it618_vid']);
	}
}

$wappagebotbtn=$template_set['wappagebotbtn'];
if($wappagebotbtn==''){
	$wappagebotbtn='#fec400|#ff9602|#fe5809|#ff7802';
}
$wappagebotbtnarr=explode('|',$wappagebotbtn);

$homeurl=it618_video_getrewrite('video_wap','','plugin.php?id=it618_video:wap');

require_once DISCUZ_ROOT.'./source/plugin/it618_video/it618_api.func.php';
$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename_wap.'/wap_video');
?>