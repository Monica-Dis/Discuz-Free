<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!video_is_mobile()){
	$tmpurl=it618_video_getrewrite('video_home','','plugin.php?id=it618_video:index');
	dheader("location:$tmpurl");
}

$navtitle=it618_video_getlang('s1864');

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_video_getlang('s835');
}else{
	$shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_uid_ok($_G['uid']);
	if($_G['uid']!=$shoptmp['it618_uid']){
		$error=1;
		$errormsg=it618_video_getlang('s513');
	}
}

$lid=intval($_GET['cid1']);
$livesetid=intval($_GET['cid2']);

if($lid>0){
	if($it618_video_goods_lesson=C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid)){
		if($it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_lesson['it618_pid'])){
			if($it618_video_goods['it618_shopid']==$shoptmp['id'])$flag=1;
		}
	}
	
	if($flag!=1){
		$error=1;
		$errormsg=it618_video_getlang('s1298');
	}
	
	if($livesetid>0){
		if(C::t('#it618_video#it618_video_shopliveset')->count_ok_by_shopid_livesetid($shoptmp['id'],$livesetid)==0){
			$error=1;
			$errormsg=it618_video_getlang('s1297');
		}else{
			$it618_video_liveset=C::t('#it618_video#it618_video_liveset')->fetch_by_id($livesetid);
			if($it618_video_liveset['it618_ossbucket']!=''&&$it618_video_liveset['it618_ossendpoint']!=''){
				$livesetstr='<font color=#f60>'.$it618_video_lang['s1302'].$it618_video_liveset['it618_livetime'].$it618_video_lang['s1305'].'</font> <font color=green>'.$it618_video_lang['s1272'].'</font>';
			}else{
				$livesetstr='<font color=#f60>'.$it618_video_lang['s1302'].$it618_video_liveset['it618_livetime'].$it618_video_lang['s1305'].'</font> <font color=blue>'.$it618_video_lang['s1273'].'</font>';
				
				$savetypestr='<div class="sctdtitle">'.it618_video_getlang('s1610').'</div><select name="it618_savetype"><option value=1>'.$it618_video_lang['s1611'].'</option><option value=2 selected="selected">'.$it618_video_lang['s1612'].'</option><option value=3>'.$it618_video_lang['s1613'].'</option></select> '.$it618_video_lang['s1614'];
			}
			
			$it618_sqtime=$it618_video_liveset['it618_sqtime'];
			$livesetstr=$it618_video_liveset['it618_name'].'<br>'.$livesetstr;
		}
	}else{

		if($shoptmp['it618_livetime']==0){
			$error=1;
			$errormsg=it618_video_getlang('s1295');
		}
		
		$it618_sqtime=3;
		$livesetstr='<b>'.$it618_video_lang['s1494'].'</b><br><br>'.$it618_video_lang['s1495'].'<br><br><font color=#f60>'.$it618_video_lang['s1496'].$shoptmp['it618_livetime'].$it618_video_lang['s1485'].'</font> <font color=blue>'.$it618_video_lang['s1273'].'</font>';
		
		$liveset0='
		<div class="sctdtitle">'.it618_video_getlang('s1497').'</div><input type="text" class="txt" style="width:98%;margin-right:3px" id="it618_livetime" name="it618_livetime" value="'.$it618_livetime.'">'.$it618_video_lang['s1305'].'
		<div class="sctdtitle">'.it618_video_getlang('s1498').'</div><textarea name="it618_m3u8url" style="width:98%;height:60px;margin-bottom:3px">'.$it618_m3u8url.'</textarea><br>'.$it618_video_lang['s1499'];
		
		$savetypestr='<div class="sctdtitle">'.it618_video_getlang('s1610').'</div><select name="it618_savetype"><option value=1>'.$it618_video_lang['s1611'].'</option><option value=2 selected="selected">'.$it618_video_lang['s1612'].'</option><option value=3>'.$it618_video_lang['s1613'].'</option></select> '.$it618_video_lang['s1614'];
	}
}else{
	$error=1;
	$errormsg=it618_video_getlang('s1697');
}

if($error==1){
	$_G['mobiletpl'][2]='/';
	include template('it618_video:'.$templatename_wap.'/wap_video');
	return;
}

$scliveurl=it618_video_getrewrite('video_wap','sc_live@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_live&cid='.$shoptmp['id']);
$scliveseturl=it618_video_getrewrite('video_wap','sc_liveset@0','plugin.php?id=it618_video:wap&pagetype=sc_liveset&cid=0');
$scproducturl=it618_video_getrewrite('video_wap','sc_product@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_product&cid='.$shoptmp['id']);
$scproductaddurl=it618_video_getrewrite('video_wap','sc_product_add@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_product_add&cid='.$shoptmp['id']);

if($Shopischeck_live==1){
	$check='<font color=blue>'.$it618_video_lang['s1303'].'</font>';
}else{
	$check='<font color=green>'.$it618_video_lang['s1304'].'</font>';
}

$about=str_replace("{sqtime}",'<font color=blue>'.$it618_sqtime.$it618_video_lang['s1305'].'</font>',$it618_video_lang['s1300']);
$about=str_replace("{check}",$check,$about);

$sc_str='
<tr><td colspan="2"></td></tr><tr><td colspan="2" style="background-color:#f9f9f9; border-bottom:#e8e8e8 1px solid; padding-bottom:6px; padding-top:6px;">'.$about.'</td></tr><tr><td colspan="2"></td></tr>';

$sc_str.='
<script>
var tmptime_x=15;
</script>
<script charset="utf-8" src="source/plugin/it618_video/js/laydate/laydate.js"></script>

<tr><td class="tdliveadd">
<div class="sctdtitle">
'.it618_video_getlang('s1281').'
</div>
'.$livesetstr.'
<div class="sctdtitle">
'.$it618_video_lang['s1286'].'
</div>
'.$it618_video_goods['it618_name'].' - '.$it618_video_goods_lesson['it618_name'].'
<div class="sctdtitle">
'.it618_video_getlang('s1280').'
</div>
<input type="text" class="txt" style="width:98%;margin-right:0" id="it618_name" name="it618_name" value="'.$it618_name.'">
<div class="sctdtitle">
'.it618_video_getlang('s1282').'
</div>
<input type="text" class="txt" style="width:98%;margin-right:3px" id="it618_btime" name="it618_btime" readonly="readonly"> '.$it618_video_lang['s1283'].'
<br>
'.$liveset0.'
<div class="sctdtitle">
'.it618_video_getlang('s1287').'
</div>
<select name="it618_isuser" onchange="setisuser(this)"><option value=1>'.$it618_video_lang['s27'].'</option><option value=2>'.$it618_video_lang['s28'].'</option><option value=0>'.$it618_video_lang['s30'].'</option></select> '.$it618_video_lang['s1284'].'
<span id="trusercode" style="display:none">
<div class="sctdtitle">
'.it618_video_getlang('s1981').'
</div>
<input type="text" class="txt" style="width:98%;margin-right:3px" name="it618_usercode"> '.$it618_video_lang['s1982'].'
</span>
'.$savetypestr.'
<div class="sctdtitle">
'.it618_video_getlang('s1285').'
</div>
<textarea name="it618_description" style="width:98%;height:60px;">'.$it618_description.'</textarea>
<a href="javascript:" onclick="sc_save()" style="background-color:'.$it618_video_wapstyle['it618_color1'].';color:#FFF;border:none;height:48px;line-height:48px;padding:0;font-size:15px;width:100%; text-align:center;border-radius:0px;position:fixed;bottom:45px;left:0">'.$it618_video_lang['s1299'].'</a>
</td></tr>
<style>.laydate-btns-time{float:left}</style>
<script>
laydate.render({
  elem: "#it618_btime"
  ,type: "datetime"
});
</script>
';

$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename_wap.'/wap_video');
?>