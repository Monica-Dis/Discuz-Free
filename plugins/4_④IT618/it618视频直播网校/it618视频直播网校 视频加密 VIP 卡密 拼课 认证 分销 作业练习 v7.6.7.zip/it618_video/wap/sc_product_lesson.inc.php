<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!video_is_mobile()){
	$tmpurl=it618_video_getrewrite('video_home','','plugin.php?id=it618_video:index');
	dheader("location:$tmpurl");
}

$navtitle=it618_video_getlang('t49');

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_video_getlang('s835');
}else{
	$shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_uid_ok($_G['uid']);
	if($_G['uid']!=$shoptmp['it618_uid']){
		$error=1;
		$errormsg=it618_video_getlang('s513');
	}
}

if($error==1){
	$_G['mobiletpl'][2]='/';
	include template('it618_video:'.$templatename_wap.'/wap_video');
	return;
}

$pid=intval($_GET['cid']);
$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);

$scliveurl=it618_video_getrewrite('video_wap','sc_live@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_live&cid='.$shoptmp['id']);
$scliveseturl=it618_video_getrewrite('video_wap','sc_liveset@0','plugin.php?id=it618_video:wap&pagetype=sc_liveset&cid=0');
$scproducturl=it618_video_getrewrite('video_wap','sc_product@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_product&cid='.$shoptmp['id']);
$scproductaddurl=it618_video_getrewrite('video_wap','sc_product_add@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_product_add&cid='.$shoptmp['id']);

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_lesson')." WHERE it618_pid=".$pid);

$urlsql='&key='.$_GET['key'].'&it618_class1_id='.$_GET['it618_class1_id'].'&it618_class2_id='.$_GET['it618_class2_id'].'&state='.$_GET['state'].'&orderby='.$_GET['orderby'];

$sc_str='
<tr style="position:fixed;top:45px;left:0; z-index:1000;background-color:#f9f9f9;width:100%" onclick="location.href=\'plugin.php?id=it618_video:wap&pagetype=sc_product'.$urlsql.'\'"><td width=35 style="border:none"><img src="source/plugin/it618_video/images/left.png"></td><td style="border:none;padding-right:6px">'.$it618_video_lang['s504'].'<font color=red>'.$it618_video_lang['s514'].$it618_video_goods['it618_name'].$it618_video_lang['s515'].'</font></td></tr>
<tr><td colspan="2"></td></tr><tr><td colspan="2" style="background-color:#f9f9f9; border-bottom:#e8e8e8 1px solid; padding-bottom:6px; padding-top:6px;">'.it618_video_getlang('s491').'<font color=red>'.$count.'</font><br>'.it618_video_getlang('s492').'</td></tr><tr><td colspan="2"></td></tr>';

$it618_exam = $_G['cache']['plugin']['it618_exam'];
$n=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_lesson')." WHERE it618_pid=".$pid." ORDER BY it618_order");
while($it618_video_goods_lesson = DB::fetch($query)) {
	if($it618_video_goods_lesson['it618_type']==1){
		$disabled="";
		if($it618_video_goods_lesson['it618_videocount']>0)$disabled="disabled=\"disabled\"";
		
		$it618_videotimestr='<font color=red>'.$it618_video_goods_lesson['it618_videocount'].'</font>'.$it618_video_lang['s108'].' '.it618_video_getvideotime($it618_video_goods_lesson['it618_videotime']);
		
		if($it618_video_goods['it618_gtype']==1){
			$tmpurl=it618_video_getrewrite('video_wap','sc_liveset@'.$it618_video_goods_lesson['id'],'plugin.php?id=it618_video:wap&pagetype=sc_liveset&cid='.$it618_video_goods_lesson['id']);
			
			$it618_gtype='<font color=#999>'.$it618_videotimestr.'</font><br><a href="'.$tmpurl.'"><font color="#FF3399">'.$it618_video_lang['s1275'].'</font></a>';
		}else{
			$it618_gtype='<font color=#999>'.$it618_videotimestr.'</font>';
		}
		
		$sc_str.='<tr>
				  <td width="48" style="vertical-align:top"><input class="checkbox" type="checkbox" id="chk_del'.$n.'" style="vertical-align:middle" name="delete[]" value="'.$it618_video_goods_lesson['id'].'"><label for="chk_del'.$n.'" style="vertical-align:middle">'.$it618_video_goods_lesson['id'].'</label></td>
				  <td>
				  <textarea name="it618_name['.$it618_video_goods_lesson['id'].']" style="width:98%;height:38px;margin-top:3px;border:#e8e8e8 1px solid">'.$it618_video_goods_lesson['it618_name'].'</textarea>
				  <br><span style="float:right;color:#999">'.$it618_video_lang['s66'].': <input type="text" class="txt" style="width:40px;text-align:center;" name="it618_order['.$it618_video_goods_lesson['id'].']" value="'.$it618_video_goods_lesson['it618_order'].'"></span>'.$it618_gtype.'
				  </td>
				  </tr>';
		$n=$n+1;
	}else{
		$sc_str.='<tr>
				  <td width="48" style="vertical-align:top"><input class="checkbox" type="checkbox" id="chk_del'.$n.'" style="vertical-align:middle" name="delete[]" value="'.$it618_video_goods_lesson['id'].'"><label for="chk_del'.$n.'" style="vertical-align:middle">'.$it618_video_goods_lesson['id'].'</label></td>
				  <td>
				  <textarea name="it618_name['.$it618_video_goods_lesson['id'].']" style="width:98%;height:38px;margin-top:3px;border:#e8e8e8 1px solid">'.$it618_video_goods_lesson['it618_name'].'</textarea>
				  <textarea name="it618_url['.$it618_video_goods_lesson['id'].']" style="width:98%;height:38px;margin-top:3px;border:#e8e8e8 1px solid">'.$it618_video_goods_lesson['it618_url'].'</textarea>
				  <br><span style="float:right;color:#999">'.$it618_video_lang['s66'].': <input type="text" class="txt" style="width:40px;text-align:center;" name="it618_order['.$it618_video_goods_lesson['id'].']" value="'.$it618_video_goods_lesson['it618_order'].'"></span>
				  </td>
				  </tr>';
	}
}

	$it618_video_lang66=$it618_video_lang['s66'];
	$it618_video_lang790=$it618_video_lang['s790'];
	$it618_video_lang791=$it618_video_lang['s791'];
	$it618_video_lang792=$it618_video_lang['s792'];

	$sc_str.= <<<EOT
	<style>.addtr{ padding-left:17px; line-height:25px; background:url(static/image/admincp/bg_repno.gif) no-repeat 0 1px; *background:url(static/image/admincp/bg_repno.gif) no-repeat 0 0; color:#F60; }</style>
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''],[1,'<select name="newit618_type[]"><option value=1>$it618_video_lang790</option><option value=0>$it618_video_lang791</option></select> $it618_video_lang792<span style="float:right;color:#999">$it618_video_lang66: <input type="text" class="txt" style="width:40px;text-align:center;" name="newit618_order[]" value="0"></span><br><textarea style="width:98%;height:38px;margin-top:3px;border:#e8e8e8 1px solid" name="newit618_name[]"></textarea>']]
		];
	}
	rowtypedata=rundata();
	
	var addrowdirect = 0;
	var addrowkey = 0;
	function addrow(obj, type) {
		var table = obj.parentNode.parentNode.parentNode.parentNode.parentNode;
		if(!addrowdirect) {
			var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex);
		} else {
			var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex + 1);
		}
		var typedata = rowtypedata[type];
		for(var i = 0; i <= typedata.length - 1; i++) {
			var cell = row.insertCell(i);
			cell.colSpan = typedata[i][0];
			var tmp = typedata[i][1];
			if(typedata[i][2]) {
				cell.className = typedata[i][2];
			}
			tmp = tmp.replace(/\{(n)\}/g, function($1) {return addrowkey;});
			tmp = tmp.replace(/\{(\d+)\}/g, function($1, $2) {return addrow.arguments[parseInt($2) + 1];});
			cell.innerHTML = tmp;
		}
		addrowkey ++;
		addrowdirect = 0;
	}
	</script>
EOT;
	$sc_str.= '<tr><td colspan="8"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$it618_video_lang['s831'].'</a></div></td></tr>';

$sc_str.= '
<tr><td><input type="checkbox" name="chkall" style="vertical-align:middle" id="chkallDx4b" class="checkbox" onclick="check_all(this,\'chk_del\')" /><label for="chkallDx4b" style="vertical-align:middle">'.it618_video_getlang('s591').'</label> </td><td><input type="button" class="it618btn inputbtn" value="'.it618_video_getlang('s592').'" onclick="sc_save()" /></td></tr>'.'<input type=hidden value='.$n.' id="n" />';

$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename_wap.'/wap_video');
?>