<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php';
	if($player_browseruid!=''&&$_G['uid']>0){
		if($player_browseruid==$_G['uid']){
			echo $_SERVER['HTTP_USER_AGENT'];exit;
		}
	}
}

$lid=intval($_GET['cid']);
if(!video_is_mobile()){ 
	$tmpurl=it618_video_getrewrite('video_lesson',$lid,'plugin.php?id=it618_video:lesson&lid='.$lid);
	dheader("location:$tmpurl");
}

if(!($it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id_ison($lid))){
	$error=11;
	if($it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_vid($lid)){
		if($it618_video_live['it618_ossbucket']==''&&$it618_video_live['it618_ossendpoint']==''){
			$errormsg=it618_video_getlang('s1393').' '.$it618_video_lang['s1395'];
			$errorurl=it618_video_getrewrite('video_product',$it618_video_live['it618_pid'],'plugin.php?id=it618_video:product&pid='.$it618_video_live['it618_pid']);
		}else{
			$errormsg=it618_video_getlang('s389');
			$errorurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods_video['it618_pid'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods_video['it618_pid']);
		}
	}else{
		$errormsg=it618_video_getlang('s389');
		$errorurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods_video['it618_pid'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods_video['it618_pid']);
	}
}else{
	if($it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_vid($lid)){
		if($it618_video_live['it618_ossbucket']!=''&&$it618_video_live['it618_ossendpoint']!=''){
			if($it618_video_live['it618_etime']<$_G['timestamp']){
				if($it618_video_live['it618_isok']==0){
					$error=11;
					$tmptime=intval(($_G['timestamp']-$it618_video_live['it618_etime'])/60);
					$it618_video_lang['s1394']=str_replace("{time}",(5-$tmptime),$it618_video_lang['s1394']);
					$errormsg=it618_video_getlang('s1394').' '.$it618_video_lang['s1395'];
					$errorurl=it618_video_getrewrite('video_product',$it618_video_live['it618_pid'],'plugin.php?id=it618_video:product&pid='.$it618_video_live['it618_pid']);
				}
			}
		}
	}
}

$pid=$it618_video_goods_video['it618_pid'];
$producturl=it618_video_getrewrite('video_wap','product@'.$pid,'plugin.php?id=it618_video:wap&pagetype=product&cid='.$pid);

if($error==0){
	if(!($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id_state($pid,1))){
		$error=10;
		$errormsg=it618_video_getlang('s470');
		$errorurl=it618_video_getrewrite('video_wap','','plugin.php?id=it618_video:wap');
	}else{
		if(!it618_video_issecretok($it618_video_goods)){
			$error=10;
			$errormsg=it618_video_getlang('s470');
			$errorurl=it618_video_getrewrite('video_wap','','plugin.php?id=it618_video:wap');
		}
		
		$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
		if($it618_video_shop['it618_state']!=2||$it618_video_shop['it618_htstate']!=1){
			$error=10;
			$errormsg=it618_video_getlang('s470');
			$errorurl=it618_video_getrewrite('video_wap','','plugin.php?id=it618_video:wap');
		}
		
		$ShopId=$it618_video_shop['id'];
		$goodscount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods')." WHERE it618_shopid=$ShopId and it618_state=1");
		$playpjcount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_play_pj')." WHERE it618_score1>0 and it618_shopid=$ShopId");
		$playcount=DB::result_first("SELECT SUM(it618_plays) FROM ".DB::table('it618_video_goods')." WHERE it618_shopid=$ShopId");
		
		$shopsubscribes=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_shop_subscribe')." WHERE it618_shopid=".$ShopId);
		$shopviews=DB::result_first("SELECT SUM(it618_views) FROM ".DB::table('it618_video_goods')." WHERE it618_shopid=".$ShopId);
		
		$lecturerurl=it618_video_getrewrite('video_lecturer',$it618_video_shop['id'],'plugin.php?id=it618_video:lecturer&lid='.$ShopId);
		$lecturerulogo=$it618_video_shop['it618_ulogo'];
		$adlogo='<img src="'.$it618_video_shop['it618_logo'].'" style="margin-top:3px; max-width:100%; border-radius:3px"/>';
		
		if($it618_video_shop['it618_logourl']!=''){
			$adlogo='<a href="'.$it618_video_shop['it618_logourl'].'" target="_blank">'.$adlogo.'</a>';
		}
		
		if(C::t('#it618_video#it618_video_shop_subscribe')->count_by_shopid_uid($ShopId,$_G['uid'])>0){
			$subscribetitle=$it618_video_lang['s1397'];
		}else{
			$subscribetitle=$it618_video_lang['s1396'];
		}
	}
	
	C::t('#it618_video#it618_video_goods')->update_it618_views_by_id($pid);
	
	$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($it618_video_goods_video['it618_lid']);
	if($it618_video_goods_lesson['it618_saleprice']>0&&$it618_video_goods_lesson['it618_issale']==1){
		$goodslessonprice='<a href="javascript:" class="salebtn salebtn1" style="color:#fff" onclick="showpay_l('.$it618_video_goods_video['it618_lid'].')">'.$it618_video_lang['s795'].'</a>';
	}
	
	if($it618_video_goods_video['it618_saleprice']>0&&$it618_video_goods_video['it618_issale']==1){
		$goodsvideoprice='<a href="javascript:" class="salebtn salebtn1" style="color:#fff" onclick="showpay_v('.$it618_video_goods_video['it618_lid'].','.$it618_video_goods_video['id'].')">'.$it618_video_lang['s796'].'</a>';
	}
	
	$isgoodsprice=0;
	if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
		$isgoodsprice=1;
	}
	
	if($it618_video_shop['it618_issale']==0){
		$isgoodsprice=1;
	}
	
	$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
	if($_G['uid']>0){
		$videopower=it618_video_getpower($_G['uid'],$it618_video_goods_video['it618_pid'],$it618_video_goods_video['it618_lid'],$it618_video_goods_video['id']);
		if(count($vipgroupids)>0){
			$tmpgrouparr=it618_video_getisvipuser($vipgroupids);
			$isvipuser=count($tmpgrouparr[0]);
		}
	}
}

if($error>0){
	$_G['mobiletpl'][2]='/';
	include template('it618_video:'.$templatename_wap.'/wap_video');
	return;
}

$pname=$it618_video_goods['it618_name'];

$footer_mall_wap.='<div style="display:none">'.$it618_video_shop['it618_tongji'].'</div>';

if($it618_video_goods_video['it618_liveid']>0){
	$it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
	$it618_name=$it618_video_live['it618_name'];
	
	if($it618_video_live['it618_etime']<$_G['timestamp']){
		$tmpurl=it618_video_getrewrite('video_product',$pid,'plugin.php?id=it618_video:product&pid='.$pid);
		dheader("location:$tmpurl");
	}else{
		if($it618_video_live['it618_btime']>$_G['timestamp']){
			$timeflag=1;
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=date('Y-m-d H:i:s', $it618_video_live['it618_btime']);
			$timetip=date('Y-m-d H:i:s', $it618_video_live['it618_btime']).' - '.date('Y-m-d H:i:s', $it618_video_live['it618_etime']);
		}
	}
	$liveid=$it618_video_goods_video['it618_liveid'];
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/message.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_video/config/message.php';
	}
	
	if($it618_isok==1&&$it618_body_live_user_isok==1){
		if($it618_video_live['it618_liveset_id']>0){
			$it618_video_liveset=C::t('#it618_video#it618_video_liveset')->fetch_by_id($it618_video_live['it618_liveset_id']);
			$it618_liveordertime=$it618_video_liveset['it618_liveordertime'];
		}else{
			$it618_liveordertime=5;
		}
		if($it618_liveordertime>=5&&(($it618_video_live['it618_btime']-$_G['timestamp'])>$it618_liveordertime*60)){
			$isliveorder=1;
			if(C::t('#it618_video#it618_video_live_order')->count_by_liveid_uid($liveid,$_G['uid'])>0){
				$liveorderbtntitle=$it618_video_lang['s1385'];
				$orderok=1;
			}else{
				$liveorderbtntitle=$it618_video_lang['s1370'];	
				$orderok=0;
			}
		}
	}
}else{
	$it618_name=$it618_video_goods_video['it618_name'];
}

$it618_isuser=$it618_video_goods_video['it618_isuser'];

$navtitle=$it618_name;

$producturl=it618_video_getrewrite('video_wap','product@'.$pid,'plugin.php?id=it618_video:wap&pagetype=product&cid='.$pid);

if($it618_isuser==0){
	$isok=1;
}

if($it618_isuser==2){
	if($_G['uid']>0){
		$isok=1;
	}else{
		$btnstr=$it618_video_lang['t204'];
		$it618_isvipstr='<a href="javascript:" class="loginbtn salebtn">'.$it618_video_lang['t205'].'</a>';
	}
}

if($it618_isuser==1){
	$btnstr=$it618_video_lang['t263'];
	if($isgoodsprice>0){
		if($videopower['state']>0){
			$isok=1;
			if($videopower['state']==2){
				$isajaxpower=1;
			}
		}else{
			if(count($vipgroupids)>0){
				$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
				if($isvipuser>0){
					$isok=1;
				}else{
					if($it618_video_shop['it618_issale']==1){
						if($_G['uid']>0){
							$btnstr=$it618_video_lang['t800'];
						}else{
							$btnstr=$it618_video_lang['t419'];
							$btnstr=str_replace("{url}",'member.php?mod=logging&action=login',$btnstr);
						}
					}else{
						$btnstr=$it618_video_lang['s1592'];
					}
					$it618_isvipstr='<a href="javascript:" class="vipbtn salebtn showvipgroupbtn">'.$it618_video_lang['s19'].'</a>';
				}
			}
		}
	}else{
		$isok=1;
	}
	
	if($_G['uid']==$it618_video_shop['it618_uid']){
		$isok=1;
	}
}

if($it618_video_goods_video['it618_ischat']==0)$IsChat=0;

if($it618_video_goods['it618_gtype']==1){
	$isvideo=1;
	$tmparr=explode("<iframe",$it618_video_goods_video['it618_videourl']);
	if(count($tmparr)>1)$isiframe=1;
}

if($player_httptime=='')$player_httptime=1.5;
$player_httptime=$player_httptime*1000;
if($IsChat==0)$player_ischat=0;

if($isok!=1){
	if($it618_video_goods_video['it618_previewtime']>0){
		$isok=1;
		$previewtime=$it618_video_goods_video['it618_previewtime'];
	}
}

if($isok==1){
	$tmpcode=md5($_G['timestamp'].FORMHASH);
		
	C::t('#it618_video#it618_video_videowork')->insert(array(
		'it618_code' => $tmpcode,
		'it618_video' => $it618_video_goods['it618_gtype'].'it618_split'.$it618_video_goods_video['id']
	), true);
	
	$playadtime=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('wapplayadtime');
	$playad=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('wapplayad');
	
	$it618_video_play_pj=C::t('#it618_video#it618_video_play_pj')->fetch_by_pid_uid($pid,$_G['uid']);
	
	if($isvideo==1&&$isiframe!=1){
		
		$player_version=$it618_video_lang['playerversion'];
		
		if($_G['uid']>0){
			if($player_ismemory==1)$memorytime=$player_memorytime*1000;
			if($player_memorydo==1)$memorydo=str_replace("{time}",$player_memorytime,$it618_video_lang['t353']);
			if($player_memorydo==2)$memorydo=str_replace("{time}",$player_memorytime,$it618_video_lang['t374']);
			
			$player_marquee=str_replace("{uid}",$_G['uid'],$player_marquee);
			$player_marquee=str_replace("{username}",dhtmlspecialchars($_G['username']),$player_marquee);
			$player_marquee=str_replace(array("\r\n", "\r", "\n"),"",$player_marquee);
		}else{
			$player_ismarqueewap=0;	
		}
	}

}

$n=1;$l=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_lesson')." WHERE it618_pid=".$pid." ORDER BY it618_order");
while($it618_video_goods_lesson = DB::fetch($query)) {
	if($it618_video_goods['it618_lessoncount']>1){
		if($it618_video_goods_lesson['it618_type']==1){
			$it618_videotimestr=$it618_video_goods_lesson['it618_videocount'].$it618_video_lang['s108'].' '.it618_video_getvideotime($it618_video_goods_lesson['it618_videotime']);
			$videostr.='<tr class="trgroup" onclick="getcourse('.$l.',\'\')">
							<td class="tdindex">
							<img src="source/plugin/it618_video/template/mall_wap/images/li0.png" id="liimg'.$l.'" width="15" style="margin-top:-2px; vertical-align:middle">
							</td>
							<td>
							<b>'.cutstr($it618_video_goods_lesson['it618_name'],40,'...').'</b>
							'.$lessonpricestr.'
							<p style="padding-top:9px"><font color=#999>'.it618_video_getvideocounttime($it618_video_goods_lesson['it618_videocount'],$it618_video_goods_lesson['it618_videotime'],1).'</font></p>
							</td>
						</tr>';
		}else{
			$videostr.='<tr class="trgroup">
							<td class="tdindex">
							<img src="source/plugin/it618_video/images/link.png"  width="16" style="margin-top:-2px; vertical-align:middle">
							</td>
							<td>
							<b><a href="'.$it618_video_goods_lesson['it618_url'].'" style="font-size:15px;color:#000;display:inline">'.cutstr($it618_video_goods_lesson['it618_name'],40,'...').'</a></b>
							</td>
						</tr>';
		}
	}
	
	if($it618_video_goods_lesson['it618_type']==1){		
		$v=1;
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_goods_video')." WHERE it618_lid=".$it618_video_goods_lesson['id']." and it618_ison=1 ORDER BY it618_order,id");
		while($it618_tmp = DB::fetch($query1)) {
			$videopowertmp=it618_video_getpower($_G['uid'],$it618_tmp['it618_pid'],$it618_tmp['it618_lid'],$it618_tmp['id']);
			
			$lessonurl=it618_video_getrewrite('video_wap','lesson@'.$it618_tmp['id'],'plugin.php?id=it618_video:wap&pagetype=lesson&cid='.$it618_tmp['id']);
			$lessonurlarr[$n]=$lessonurl;
			if($lid==$it618_tmp['id']){
				$curstr='cur';
				$curn=$n;
			}else{
				$curstr='';
			}
			
			$isuserstr='';
			
			if($it618_video_goods['it618_lessoncount']>1)$tdindex=$l.'.'.$v;else $tdindex=$v;
			
			$tmpvid=$it618_tmp['id'];
			if($it618_tmp['it618_liveid']>0){
				$it618_usercode=$it618_tmp['it618_usercode'];
				$it618_tmp=C::t('#it618_video#it618_video_live')->fetch_by_id($it618_tmp['it618_liveid']);
				
				$livestate='';
				if($it618_tmp['it618_btime']>$_G['timestamp']){
					$livestate='<font color=red style="font-size:12px">'.it618_video_gettime1($it618_tmp['it618_btime']).$it618_video_lang['s1316'].'</font>';
					$imgstr='<img src="source/plugin/it618_video/images/live.gif" style="margin-right:1px;margin-top:-1px;height:16px">';
				}
				
				if($it618_tmp['it618_btime']<$_G['timestamp']&&$_G['timestamp']<$it618_tmp['it618_etime']){
					$livestate='<font color=#23b8ff style="font-size:12px">'.$it618_video_lang['s1317'].'</font>';
					$imgstr='<img src="source/plugin/it618_video/images/live.gif" style="margin-right:1px;margin-top:-1px;height:16px">';
				}
				
				if($livestate=='')continue;
				if($it618_video_goods['it618_isprotect']==1&&$_G['uid']!=$it618_video_shop['it618_uid']&&$it618_tmp['it618_isuser']==1){
					if(it618_video_isprotect($isgoodsprice,$videopowertmp,$isvipuser))continue;
				}
				
				if($isgoodsprice==0||$it618_tmp['it618_isuser']==0||$it618_tmp['it618_isuser']==2){
					if($it618_usercode!=''){
						$tmpuserstr=$it618_video_lang['s1609'];
					}else{
						$tmpuserstr=$it618_video_lang['s1968'];
					}
					$isuserstr='<span class="isuser">'.$tmpuserstr.'</span> ';
				}
				
				$it618_name=cutstr($it618_tmp['it618_name'],36,'...');
				
				$videostr.='<tr class="tr'.$tmpvid.' lesson'.$l.'">
								<td class="tdindex">
								'.$tdindex.'
								</td>
								<td>
								<span style="float:right">
								<img src="source/plugin/it618_video/template/mall_wap/images/dec0.png" onclick="getdesp('.$n.',this)" style="width:13px">
								</span>
								'.$isuserstr.'<img src="source/plugin/it618_video/images/live.gif" style="margin-right:3px;margin-top:0px;height:12px;float:right"><a href="'.$lessonurl.'" class="videotdbtn '.$curstr.'">'.$it618_name.'</a>
								<p class="desp'.$n.'">'.$livestate.'</p>
								<p class="desp'.$n.'">'.$it618_tmp['it618_description'].'</p>
								</td>
							</tr>';
			}else{
				if($it618_video_goods['it618_isprotect']==1&&$_G['uid']!=$it618_video_shop['it618_uid']&&$it618_tmp['it618_isuser']==1){
					if(it618_video_isprotect($isgoodsprice,$videopowertmp,$isvipuser))continue;
				}
				
				if($isgoodsprice==0||$it618_tmp['it618_isuser']==0||$it618_tmp['it618_isuser']==2){
					if($it618_tmp['it618_usercode']!=''){
						$tmpuserstr=$it618_video_lang['s1609'];
					}else{
						$tmpuserstr=$it618_video_lang['s1968'];
					}
					$isuserstr='<span class="isuser">'.$tmpuserstr.' </span> ';
				}
				$it618_name=cutstr($it618_tmp['it618_name'],36,'...');
				
				$tmpimg='';
				if($it618_tmp['it618_islive']==1){
					$tmpimg='<img src="source/plugin/it618_video/images/live.gif" style="margin-right:1px;margin-top:-1px;height:16px">';
				}
				
				$previewtimestr='';
				if($it618_tmp['it618_previewtime']>0){
					$previewtimestr='<span class="isuser">'.$it618_video_lang['s1969'].'</span> ';
				}
				
				$isuserstr=$isuserstr.''.$previewtimestr;
				
				$videopricestr='';
				if($it618_tmp['it618_issale']==1&&$it618_tmp['it618_isuser']==1&&$isgoodsprice==1){
					$videopricestr=it618_video_getgoodsprice($it618_tmp,'goods_video_price');
					$delpricestr='';
					if($it618_tmp['it618_price']>0){
						$delpricestr='<del>&yen;'.$it618_tmp['it618_price'].'</del>';
					}
					
					$videopricestr='<p class="lessonprice desp'.$n.'" onclick="showpay_v('.$it618_tmp['it618_lid'].','.$it618_tmp['id'].')">
					<img src="source/plugin/it618_video/template/mall_wap/images/uc_right.png" style="float:right; width:18px; margin-top:-3px; vertical-align:middle">
					<span class="buybtn">'.$it618_video_lang['s1586'].'</span>
					<span class="spanprice">'.$videopricestr.' '.$delpricestr.'</span>
					</p>';
				}
							
				$videostr.='<tr class="tr'.$it618_tmp['id'].' lesson'.$l.'">
								<td class="tdindex">
								'.$tdindex.'
								</td>
								<td>
								<span style="float:right">
								<img src="source/plugin/it618_video/template/mall_wap/images/dec0.png" onclick="getdesp('.$n.',this)" style="width:13px">
								</span>
								'.$isuserstr.'<a href="'.$lessonurl.'" class="videotdbtn '.$curstr.'">'.$it618_name.'</a>
								'.$videopricestr.'
								<p class="desp'.$n.'">'.$tmpimg.' <img src="source/plugin/it618_video/template/mall_wap/images/time.png" height="14" style="vertical-align:middle; margin-top:-3px; margin-right:2px;margin-left:-1px" />'.$it618_video_lang['s1900'].' '.it618_video_getvideotimestr($it618_tmp).'</p>
								<p class="desp'.$n.'">'.$it618_tmp['it618_description'].'</p>
								</td>
							</tr>';
			}
			$n=$n+1;
			$v=$v+1;
		}
	}
	$l=$l+1;
}

$it618_pname=cutstr($it618_video_goods['it618_name'],46,'...');

if($curn==$n-1){
	$nexturl='';
}else{
	$nexturl=$lessonurlarr[$curn+1];
}

if($playadtime=='')$playadtime=0;
$wapplayadnotids=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('wapplayadnotids');
$tmparr=explode(",",$wapplayadnotids);
if(in_array($pid,$tmparr)){
	$playadtime=0;
}

if($isvipuser>0&&$playadtime>0){
	$wapplayadvip=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('wapplayadvip');
	$tmparr=explode(",",$wapplayadvip);
	if(!in_array($pid,$tmparr)){
		$playadtime=0;
	}
}

$query3 = DB::query("SELECT * FROM ".DB::table('it618_video_goods_data')." WHERE it618_vid=".$it618_video_goods_video['id']." and it618_dataurl!='' ORDER BY it618_order");
while($it618_video_goods_data = DB::fetch($query3)) {
	$isoktmp=0;
	if($it618_video_goods_data['it618_isuser']==0){
		$isoktmp=1;
	}
	
	if($it618_video_goods_data['it618_isuser']==2){
		$it618_dataurl='<font color=#999>'.$it618_video_lang['s942'].'</font>';
		if($_G['uid']>0){
			$isoktmp=1;
		}
	}
	
	if($it618_video_goods_data['it618_isuser']==1){
		$it618_dataurl='<font color=#999>'.$it618_video_lang['s805'].'</font>';
		
		if($isgoodsprice>0){
			if($videopowertmp['state']>0){
				$isoktmp=1;
			}else{
				if($isvipok==1){
					$isoktmp=1;
				}
			}
		}else{
			$isoktmp=1;
		}
		
		if($_G['uid']>0){
			$it618_video_shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_uid($_G['uid']);
			if($it618_video_goods['it618_shopid']==$it618_video_shoptmp['id']){
				$isoktmp=1;
			}
		}
	}

	if($isoktmp==1){
		$it618_dataurl1='href="plugin.php?id=it618_video:datadown&did='.$it618_video_goods_data['id'].'" target="_blank"';
		$it618_dataurl=''.$it618_video_lang['s806'].'';
	}
	
	$datastr.='<tr>
				  <td>
				  <a '.$it618_dataurl1.' class="videotdbtn">'.$it618_video_goods_data['it618_name'].'</a>
				  <p><span style="border:#ddd 1px solid; padding:0; height:15px; line-height:15px; display:inline-block; padding-left:2px; padding-right:2px; border-radius:3px;color:#aaa;font-size:12px;vertical-align:middle;margin-top:-1px;float:right;margin-right:3px">'.$it618_dataurl.'</span><span>'.$it618_video_goods_data['it618_datasizestr'].' , '.$it618_video_lang['s46'].': '.$it618_video_goods_data['it618_views'].'</span></p>
				  </td>
			  </tr>';
}

if($datastr!=''){
	$datastr='<table class="dataexam" style="margin-bottom:13px"><tr><td class="dataexamtitle">'.$it618_video_lang['t138'].'</td><tr>'.$datastr.'<tr></table>';
}

$query3 = DB::query("SELECT * FROM ".DB::table('it618_video_goods_video_exam')." WHERE it618_vid=".$it618_video_goods_video['id']." ORDER BY it618_order");
while($it618_video_goods_video_exam = DB::fetch($query3)) {
	
	$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_video_goods_video_exam['it618_tid']);
	
	$examurl=it618_video_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
	
	$it618_exam_goods['it618_examscore']=str_replace(".0","",$it618_exam_goods['it618_examscore']);
	$it618_examstr=str_replace("{qcount}",$it618_exam_goods['it618_questioncount'],$it618_video_lang['s1429']);
	$it618_examstr=str_replace("{score}",$it618_exam_goods['it618_examscore'],$it618_examstr);
	$it618_examstr=str_replace("{time}",$it618_exam_goods['it618_examtime'],$it618_examstr);
	
	$isuserstr='';
	if($it618_video_goods_video_exam['it618_power']==1&&$isgoodsprice==1){
		$isuserstr='<span style="border:#ddd 1px solid; padding:0; height:15px; line-height:15px; display:inline-block; padding-left:2px; padding-right:2px; border-radius:3px;color:#aaa;font-size:12px;vertical-align:middle;margin-top:-1px;float:right;margin-right:3px">'.$it618_video_lang['s1574'].'</span> ';
	}

	$examstr.='<tr>
				  <td>
				  <a href="'.$examurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a>
				  <p>'.$isuserstr.'<span>'.$it618_examstr.'</span></p>
				  </td>
			  </tr>';
}

if($examstr!=''){
	$examstr='<table class="dataexam"><tr><td class="dataexamtitle">'.$it618_video_lang['s1428'].'</td><tr>'.$examstr.'</table>';
}

if($datastr==''||$examstr==''){
	if($examstr!='')$it618_video_lang['s2129']=$it618_video_lang['t297'];
	if($datastr!='')$it618_video_lang['s2129']=$it618_video_lang['t409'];
}

if($it618_video_goods_video['it618_message']!=''){
	if($it618_video_goods_video['it618_ismessagetb']==1){
		$it618_message=$it618_video_lang['s1605'];
	}else{
		$it618_message=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$it618_video_goods_video['it618_message']);
		$it618_message=preg_replace('/<table.+?>/','<table cellspacing="0" cellpadding="0" width="100%">',$it618_message);
		$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="220" frameborder="0" allowfullscreen="1">',$it618_message);
		$it618_message=str_replace('&it618mediatype=audio"','&wap=1" style="border:0;width:100%;height:53px" scrolling="no" frameborder=0',$it618_message);
	}
}

if($player_ischat==0){
	if($it618_video_goods_video['it618_ischatdefault']==1){
		$player_ischat=1;
	}
}

if($it618_video_goods_video['it618_ismessagedefault']==1){
	$it618_ismessagedefault=1;
	$player_ischat=0;
}

$it618_messagename=$it618_video_lang['s1814'];
if($it618_video_goods_video['it618_messagename']!=''){
	$it618_messagename=$it618_video_goods_video['it618_messagename'];
}

$it618_videoimg=$it618_video_goods_video['it618_videoimg'];
if($it618_videoimg==''){
	$it618_videoimg=$it618_video_goods['it618_picbig'];

	$tmparr1=explode(".m3u8",$it618_video_goods_video['it618_videourl']);
	if(count($tmparr1)>1){
		if($it618_video_media_mts=C::t('#it618_video#it618_video_media_mts')->fetch_by_url($it618_video_goods_video['it618_videourl'])){
			$it618_video_media=C::t('#it618_video#it618_video_media')->fetch_by_id($it618_video_media_mts['it618_media_id']);
			$it618_videoimg=it618_video_cdnkeyurl($it618_video_media['it618_coverurl']);
		}
	}
}

$tmpurl=it618_video_getrewrite('video_wap','lesson@'.$lid,'plugin.php?id=it618_video:wap&pagetype=lesson&cid='.$lid);
if($it618_video['video_saletel']==2){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/function.func.php';
	$uhomeurl=it618_members_getrewrite("members_uhome","","plugin.php?id=it618_members:home&ac=sitetelbd&preurl=".urlencode($tmpurl),"?ac=sitetelbd&preurl=".urlencode($tmpurl));
}

$it618_goodsmessage=$it618_video_goods['it618_message'];
$it618_goodsmessage=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$it618_goodsmessage);
$it618_goodsmessage=preg_replace('/<table.+?>/','<table cellspacing="0" cellpadding="0" width="100%">',$it618_goodsmessage);
$it618_goodsmessage=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="220" frameborder="0" allowfullscreen="1">',$it618_goodsmessage);

$kindeditorjs='<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/themes/default/default.css" />
			<script src="source/plugin/it618_video/kindeditor/kindeditor-min.js?'.$it618_video_lang['version'].'" charset="utf-8"></script>
			<script src="source/plugin/it618_video/kindeditor/lang/zh_CN.js" charset="utf-8"></script>';

$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename_wap.'/wap_video');
?>