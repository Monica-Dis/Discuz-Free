<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lid=intval($_GET['cid']);
if(!video_is_mobile()){ 
	if(isset($_GET['tuiuid'])){
		$urltmp='tuiuid='.$_GET['tuiuid'];
	}
	
	if($urltmp!=''){
		$tmpurl=it618_video_getrewrite('video_lecturer',$lid,'plugin.php?id=it618_video:lecturer&lid='.$lid.'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=it618_video_getrewrite('video_lecturer',$lid,'plugin.php?id=it618_video:lecturer&lid='.$lid);
	}

	dheader("location:$tmpurl");
}

if($it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($lid)){	
	$navtitle=$it618_video_shop['it618_name'];
	$it618_state=$it618_video_shop['it618_state'];
	if($it618_state==0){
		$error=1;
		$errormsg=it618_video_getlang('s334');
	}elseif($it618_state==1){
		$error=1;
		$errormsg=it618_video_getlang('s335');
	}else{
		$it618_htstate=$it618_video_shop['it618_htstate'];
		if($it618_htstate==0){
			$error=1;
			$errormsg=it618_video_getlang('s336');
		}elseif($it618_htstate==2){
			$error=1;
			$errormsg=it618_video_getlang('s337');
		}else{
			$ShopId=$it618_video_shop['id'];
		}
	}
}else{
	$error=1;
	$errormsg=it618_video_getlang('s338');
}

if($error==1){
	$_G['mobiletpl'][2]='/';
	include template('it618_video:'.$templatename_wap.'/wap_video');
	return;
}

$footer_mall_wap.='<div style="display:none">'.$it618_video_shop['it618_tongji'].'</div>';

$goodscount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods')." WHERE it618_shopid=$ShopId and it618_state=1");

if(C::t('#it618_video#it618_video_shop_subscribe')->count_by_shopid_uid($ShopId,$_G['uid'])>0){
	$subscribetitle=$it618_video_lang['s1397'];
}else{
	$subscribetitle=$it618_video_lang['s1396'];
}
$shopsubscribes=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_shop_subscribe')." WHERE it618_shopid=".$it618_video_shop['id']);
$shopviews=DB::result_first("SELECT SUM(it618_views) FROM ".DB::table('it618_video_goods')." WHERE it618_shopid=".$it618_video_shop['id']);

if($it618_video['video_style']>2){
	$videostyle=getcookie('videostyle');
	if($videostyle==''){
		if($it618_video['video_style']==3)$videostyle='1';else $videostyle='2';
	}
}else{
	if($it618_video['video_style']==1)$videostyle='1';else $videostyle='2';
}

$shopgoodsarr=explode("it618_split",it618_video_getshopgoods($ShopId,1,1));

if($IsChat==1){
	if($it618_video_shop['it618_isqunchat']==1)$isqunchat=1;
}

require_once DISCUZ_ROOT.'./source/plugin/it618_video/it618_api.func.php';
$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename_wap.'/wap_video');
?>