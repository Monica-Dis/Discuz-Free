<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!video_is_mobile()){
	dheader("location:$video_home");
}

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_video_getlang('s835');
}

if($error==1){
	$_G['mobiletpl'][IN_MOBILE]='/';
	include template('it618_video:'.$templatename_wap.'/wap_video');
	return;
}

$navtitle=it618_video_getlang('s1403');

$subscribeurl=it618_video_getrewrite('video_wap','subscribe@'.$_G['uid'],'plugin.php?id=it618_video:wap&pagetype=subscribe');
$ucurl=it618_video_getrewrite('video_wap','uc@1','plugin.php?id=it618_video:wap&pagetype=uc&cid=1');

require_once DISCUZ_ROOT.'./source/plugin/it618_video/it618_api.func.php';
$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_video:'.$templatename_wap.'/wap_video');
?>