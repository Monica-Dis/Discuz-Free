<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!video_is_mobile()){
	$tmpurl=it618_video_getrewrite('video_home','','plugin.php?id=it618_video:index');
	dheader("location:$tmpurl");
}

$navtitle=it618_video_getlang('t49');

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_video_getlang('s835');
}else{
	$shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_uid_ok($_G['uid']);
	if($_G['uid']!=$shoptmp['it618_uid']){
		$error=1;
		$errormsg=it618_video_getlang('s513');
	}
}

if($error==1){
	$_G['mobiletpl'][2]='/';
	include template('it618_video:'.$templatename_wap.'/wap_video');
	return;
}

$scliveurl=it618_video_getrewrite('video_wap','sc_live@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_live&cid='.$shoptmp['id']);
$scliveseturl=it618_video_getrewrite('video_wap','sc_liveset@0','plugin.php?id=it618_video:wap&pagetype=sc_liveset&cid=0');
$scproducturl=it618_video_getrewrite('video_wap','sc_product@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_product&cid='.$shoptmp['id']);
$scproductaddurl=it618_video_getrewrite('video_wap','sc_product_add@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_product_add&cid='.$shoptmp['id']);

$state0='';$state1='';$state2='';$state3='';$state4='';$state5='';$state6='';$state7='';
if($_GET['state']==0){$state0='selected="selected"';}
if($_GET['state']==1){$it618sql .= " and g.it618_state = 0";$state1='selected="selected"';}
if($_GET['state']==2){$it618sql .= " and g.it618_state = 1";$state2='selected="selected"';}
if($_GET['state']==3){$it618sql .= " and g.it618_state = 2";$state3='selected="selected"';}
if($_GET['state']==4){$it618sql .= " and g.it618_isvip = 0";$state4='selected="selected"';}
if($_GET['state']==5){$it618sql .= " and g.it618_isvip = 1";$state5='selected="selected"';}
if($_GET['state']==6){$it618sql .= " and g.it618_issecret = 0";$state6='selected="selected"';}
if($_GET['state']==7){$it618sql .= " and g.it618_issecret = 1";$state7='selected="selected"';}

$orderby0='';$orderby1='';$orderby2='';$orderby3='';
if($_GET['orderby']==0){$it618orderby = "g.it618_shoporder desc,id desc";$orderby0='selected="selected"';}
if($_GET['orderby']==1){$it618orderby = "g.it618_salecount desc";$orderby1='selected="selected"';}
if($_GET['orderby']==2){$it618orderby = "g.it618_views desc";$orderby2='selected="selected"';}
if($_GET['orderby']==3){$it618orderby = "g.it618_saleprice desc";$orderby3='selected="selected"';}

$tmp='<option value="0">'.it618_video_getlang('s346').'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_class1')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class1_id'].'>','<option value='.$_GET['it618_class1_id'].' selected="selected">',$tmp);

if($_GET['it618_class1_id']>0){
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_class2')." where it618_class1_id=".$_GET['it618_class1_id']." ORDER BY it618_order");
	$indextmp=1;
	$index=0;
	while($it618_tmp =	DB::fetch($query)) {
		if($it618_tmp['id']==$_GET['it618_class2_id']){
			$index=$indextmp;
		}
		$indextmp+=1;
	}
	$jstmp.="redirec_class(document.getElementById('it618_class1_id').options.selectedIndex);redirec_class_sel('it618_class2_id',".$index.");";
}

if($shoptmp['it618_issale']!=1){
	$issalecss='display:none';
}

$sc_str1 = '<tr><td colspan="2" style="padding-bottom:6px;line-height:32px">'.it618_video_getlang('s97').' <input id="key" value="'.$_GET['key'].'" class="txt" style="width:150px" /><span style="'.$issalecss.'"> '.it618_video_getlang('s99').' <select id="it618_class1_id" name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex)">'.$tmp1.'</select><select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.it618_video_getlang('s100').'</option></select> '.it618_video_getlang('s101').' <select id="state"><option value=0 '.$state0.'>'.it618_video_getlang('s102').'</option><option value=1 '.$state1.'>'.it618_video_getlang('s103').'</option><option value=2 '.$state2.'>'.it618_video_getlang('s104').'</option><option value=3 '.$state3.'>'.it618_video_getlang('s105').'</option><option value=4 '.$state4.'>'.$it618_video_lang['s39'].'</option><option value=5 '.$state5.'>'.$it618_video_lang['s40'].'</option><option value=6 '.$state6.'>'.$it618_video_lang['s1176'].'</option><option value=7 '.$state7.'>'.$it618_video_lang['s1177'].'</option></select> <select id="orderby"><option value=0 '.$orderby0.'>'.it618_video_getlang('s110').'</option><option value=1 '.$orderby1.' style="'.$issalecss.'">'.it618_video_getlang('s111').'</option><option value=2 '.$orderby2.'>'.it618_video_getlang('s112').'</option><option value=3 '.$orderby3.' style="'.$issalecss.'">'.it618_video_getlang('s113').'</option></select> &nbsp;<input type="button" class="it618btn inputbtn" onclick="searchscproduct()" value="'.it618_video_getlang('s350').'" /></td></tr>';


$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_video_class1'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_class1')." ORDER BY it618_order");
$n1=1;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_video_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}

$sc_str2.= '
	<script>
	var tmptime_x=58;
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	'.$jstmp.'
	
	function redirec_class(x)
	{
	 var temp = document.getElementById("it618_class2_id"); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	function redirec_class_sel(id,index)
	{
	 var temp = document.getElementById(id); 
	 temp.options[index].selected=true;
	
	}

	function checkvalue(){
		for(var i=1;i<document.getElementById("n").value;i++){
			var chk_del = document.getElementById("chk_del"+i).value;
			var it618_xgtype = document.getElementById("it618_xgtype"+i).value;
			var it618_xgtime1 = document.getElementById("it618_xgtime1_"+i).value;
			var it618_xgtime2 = document.getElementById("it618_xgtime2_"+i).value;
			
			var tmparr1=it618_xgtime1.split(" ");
			var tmparr2=it618_xgtime2.split(" ");
			
			if(it618_xgtype>0){
				if(it618_xgtime1==""){
					alert("'.it618_video_getlang('s949').'"+chk_del+") '.it618_video_getlang('s950').'");
					document.getElementById("it618_xgtime1_"+i).focus();
					return false;
				}
				if(it618_xgtime2==""){
					alert("'.it618_video_getlang('s949').'"+chk_del+") '.it618_video_getlang('s951').'");
					document.getElementById("it618_xgtime2_"+i).focus();
					return false;
				}
				if(parseInt(tmparr2[0].replace(/-/g,""))<parseInt(tmparr1[0].replace(/-/g,""))){
					alert("'.it618_video_getlang('s949').'"+chk_del+")'.it618_video_getlang('s947').'");
					document.getElementById("it618_xgtime1_"+i).focus();
					return false;
				}
				
				var flag=0;
				if(it618_xgtype==2){
					flag=1;
				}else{
					if(parseInt(tmparr2[0].replace(/-/g,""))==parseInt(tmparr1[0].replace(/-/g,""))){
						flag=1;
					}
				}
				if(flag==1&&parseInt(tmparr2[1].replace(":",""))<=parseInt(tmparr1[1].replace(":",""))){
					alert("'.it618_video_getlang('s949').'"+chk_del+")'.it618_video_getlang('s948').'");
					document.getElementById("it618_xgtime1_"+i).focus();
					return false;
				}
			}
		}
		
		return true;
	}
	</script>
	<script charset="utf-8" src="source/plugin/it618_video/js/laydate/laydate.js"></script>
	';

$sc_str2.= '
<tr><td><input type="checkbox" name="chkall" style="vertical-align:middle" id="chkallDx4b" class="checkbox" onclick="check_all(this,\'chk_del\')" /><label for="chkallDx4b" style="vertical-align:middle">'.it618_video_getlang('s129').'</label> </td><td><input type="button" class="it618btn inputbtn" name="it618submit_del" value="'.it618_video_getlang('s352').'" onclick="return sc_save(\'del\')" /> <input type="button" class="it618btn inputbtn" value="'.it618_video_getlang('s354').'" onclick="return sc_save(\'edit\')"/> <input type="button" class="it618btn inputbtn" value="'.it618_video_getlang('s355').'" onclick="return sc_save(\'on\')" /> <input type="button" class="it618btn inputbtn" style="margin-top:6px" value="'.it618_video_getlang('s357').'" onclick="return sc_save(\'down\')" /><br>'.it618_video_getlang('s135').'</td></tr>';

$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename_wap.'/wap_video');
?>