<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!video_is_mobile()){
	$tmpurl=it618_video_getrewrite('video_home','','plugin.php?id=it618_video:index');
	dheader("location:$tmpurl");
}

$navtitle=it618_video_getlang('s1864');

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_video_getlang('s835');
}else{
	$shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_uid_ok($_G['uid']);
	if($_G['uid']!=$shoptmp['it618_uid']){
		$error=1;
		$errormsg=it618_video_getlang('s513');
	}
}

if($error==1){
	$_G['mobiletpl'][2]='/';
	include template('it618_video:'.$templatename_wap.'/wap_video');
	return;
}

$scliveurl=it618_video_getrewrite('video_wap','sc_live@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_live&cid='.$shoptmp['id']);
$scliveseturl=it618_video_getrewrite('video_wap','sc_liveset@0','plugin.php?id=it618_video:wap&pagetype=sc_liveset&cid=0');
$scproducturl=it618_video_getrewrite('video_wap','sc_product@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_product&cid='.$shoptmp['id']);
$scproductaddurl=it618_video_getrewrite('video_wap','sc_product_add@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_product_add&cid='.$shoptmp['id']);

$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_class1')." ORDER BY it618_order");
while($it618_tmp = DB::fetch($query1)) {
	$classtmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_video_class1'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_class1')." ORDER BY it618_order");
$n1=1;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_video_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}

$sc_str.='
<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_video/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_video/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_video/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false,
			width : \'99%\',
			afterBlur: function () { this.sync(); },
			items : [\'source\',\'|\', \'emoticons\', \'image\', \'|\',\'fontname\', \'fontsize\', \'|\', \'forecolor\', \'hilitecolor\', \'bold\', \'underline\']
		});
		
		editor1.clickToolbar("source");
		
		K(\'#image1\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
	});
	
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x,n)
	{
	 if(n==0)n="";
	 var temp = document.getElementById("it618_class2_id"+n); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
</script>

<tr><td class="tdliveadd">
<div class="sctdtitle">
'.it618_video_getlang('s374').'
</div>
<select name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex,0)"><option value="0">'.it618_video_getlang('s375').'</option>'.$classtmp1.'</select> <select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.it618_video_getlang('s376').'</option></select>
<br><br>'.$it618_video_lang['s1005'].'
<br><br>
<select name="it618_class1_id1" onchange="redirec_class(this.options.selectedIndex,1)"><option value="0">'.it618_video_getlang('s375').'</option>'.$classtmp1.'</select> <select id="it618_class2_id1"  name="it618_class2_id1"><option value="0">'.it618_video_getlang('s376').'</option></select>
<br><br>
<select name="it618_class1_id2" onchange="redirec_class(this.options.selectedIndex,2)"><option value="0">'.it618_video_getlang('s375').'</option>'.$classtmp1.'</select> <select id="it618_class2_id2"  name="it618_class2_id2"><option value="0">'.it618_video_getlang('s376').'</option></select>
<br><br>
<select name="it618_class1_id3" onchange="redirec_class(this.options.selectedIndex,3)"><option value="0">'.it618_video_getlang('s375').'</option>'.$classtmp1.'</select> <select id="it618_class2_id3"  name="it618_class2_id3"><option value="0">'.it618_video_getlang('s376').'</option></select>
<div class="sctdtitle">
'.$it618_video_lang['s21'].'
</div>
<select name="it618_gtype"><option value="0">'.$it618_video_lang['s22'].'</option><option value="1" selected="selected">'.$it618_video_lang['s26'].'</option></select><br>'.$it618_video_lang['s24'].'
<div class="sctdtitle">
'.it618_video_getlang('s839').'
</div>
<input type="text" class="txt" style="width:98%;margin-right:0" id="it618_name" name="it618_name" value="">
<div class="sctdtitle">';

if($IsChat==1){
$sc_str.= '<div class="sctdtitle">'.$it618_video_lang['s1369'].'</div>
<input class="checkbox" type="checkbox" id="chk_isuser" name="it618_isuser" checked="checked" value="1"><label for="chk_isuser">'.it618_video_getlang('s1366').'</label><br>
<input class="checkbox" type="checkbox" id="chk_isip" name="it618_isip" value="1"><label for="chk_isip">'.it618_video_getlang('s1367').'</label><br>
<input class="checkbox" type="checkbox" id="chk_isaddr" name="it618_isaddr" value="1"><label for="chk_isaddr">'.it618_video_getlang('s1368').'</label><br>';
}

$sc_str.='<div class="sctdtitle">'.it618_video_getlang('s394').'
</div>
<img id="img1" width="100" height="60" align="absmiddle"/> <input type="text" style="width:130px" id="url1" name="it618_picbig" readonly="readonly"/> <input type="button" id="image1" style="height:35px;line-height:35px;padding:0 10px;border-radius:3px; " value="'.it618_video_getlang('s395').'" />
<div class="sctdtitle">
'.it618_video_getlang('s567').'
</div>
<textarea name="it618_description" style="width:98%;height:60px;"></textarea>
<div class="sctdtitle">
'.it618_video_getlang('s404').'
</div>
<textarea name="it618_message" style="width:98%;height:260px;visibility:hidden;"></textarea>
<div class="sctdtitle">
'.it618_video_getlang('s405').'
</div>
<textarea name="it618_seokeywords" style="width:98%;height:60px;"></textarea>
<div class="sctdtitle">
'.it618_video_getlang('s406').'
</div>
<textarea name="it618_seodescription" style="width:98%;height:60px;"></textarea>
<a href="javascript:" onclick="sc_save()" style="background-color:'.$it618_video_wapstyle['it618_color1'].';color:#FFF;border:none;height:48px;line-height:48px;padding:0;font-size:15px;width:100%; text-align:center;border-radius:0px;position:fixed;bottom:45px;left:0">'.$it618_video_lang['s407'].'</a>
</td></tr>';

$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename_wap.'/wap_video');
?>