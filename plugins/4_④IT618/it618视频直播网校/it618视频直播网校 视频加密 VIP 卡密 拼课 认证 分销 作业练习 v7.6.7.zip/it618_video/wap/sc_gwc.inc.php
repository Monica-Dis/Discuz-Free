<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!video_is_mobile()){
	$tmpurl=it618_video_getrewrite('video_home','','plugin.php?id=it618_video:index');
	dheader("location:$tmpurl");
}

$navtitle=it618_video_getlang('s1792');

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_video_getlang('s835');
}else{
	$shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_uid_ok($_G['uid']);
	if($_G['uid']!=$shoptmp['it618_uid']){
		$error=1;
		$errormsg=it618_video_getlang('s513');
	}
}

if($error==1){
	$_G['mobiletpl'][2]='/';
	include template('it618_video:'.$templatename_wap.'/wap_video');
	return;
}

$scurl=it618_video_getrewrite('video_wap','sc@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc&cid='.$shoptmp['id']);
$scsubscribeurl=it618_video_getrewrite('video_wap','sc_subscribe@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_subscribe&cid='.$shoptmp['id']);
$scgwcurl=it618_video_getrewrite('video_wap','sc_gwc@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_gwc&cid='.$shoptmp['id']);

$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename_wap.'/wap_video');
?>