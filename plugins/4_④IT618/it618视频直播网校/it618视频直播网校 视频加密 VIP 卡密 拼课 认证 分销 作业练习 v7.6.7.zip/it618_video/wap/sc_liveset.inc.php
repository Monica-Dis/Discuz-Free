<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!video_is_mobile()){
	$tmpurl=it618_video_getrewrite('video_home','','plugin.php?id=it618_video:index');
	dheader("location:$tmpurl");
}

$navtitle=it618_video_getlang('s1865');

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_video_getlang('s835');
}else{
	$shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_uid_ok($_G['uid']);
	if($_G['uid']!=$shoptmp['it618_uid']){
		$error=1;
		$errormsg=it618_video_getlang('s513');
	}
}

if($error==1){
	$_G['mobiletpl'][2]='/';
	include template('it618_video:'.$templatename_wap.'/wap_video');
	return;
}

$lid=intval($_GET['cid']);

$scliveurl=it618_video_getrewrite('video_wap','sc_live@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_live&cid='.$shoptmp['id']);
$scliveseturl=it618_video_getrewrite('video_wap','sc_liveset@0','plugin.php?id=it618_video:wap&pagetype=sc_liveset&cid=0');
$scproducturl=it618_video_getrewrite('video_wap','sc_product@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_product&cid='.$shoptmp['id']);
$scproductaddurl=it618_video_getrewrite('video_wap','sc_product_add@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_product_add&cid='.$shoptmp['id']);

if($lid>0){
	$tmpurl=it618_video_getrewrite('video_wap','sc_live_add@'.$lid.'@0','plugin.php?id=it618_video:wap&pagetype=sc_live_add&cid1='.$lid.'&cid2=0');
	$tmpbtn='<a href="'.$tmpurl.'" style="background-color:'.$it618_video_wapstyle['it618_color1'].';color:#fff;padding:6px 15px;border-radius:3px;float:right;margin-top:-5px">'.$it618_video_lang['s1279'].'</a>';
	
	if($shoptmp['it618_livetime']>0){
		$addcount = C::t('#it618_video#it618_video_live')->count_by_search('it618_liveset_id=0','',$ShopId);
		$okcount = C::t('#it618_video#it618_video_live')->count_by_search('it618_chkstate=1 and it618_liveset_id=0','',$ShopId);
		
		$sc_str.='<tr>
			  <td>
			  <div style="font-size:15px;color:#333;margin-top:6px;margin-bottom:6px">'.$it618_video_lang['s1494'].'</div>
			  <div style="color:#888">'.$it618_video_lang['s1495'].'<br><br><font color=#f60>'.$it618_video_lang['s1496'].$shoptmp['it618_livetime'].$it618_video_lang['s1485'].'</font> <font color=blue>'.$it618_video_lang['s1273'].'</font><br></div>
			  <div style="color:#999">'.$tmpbtn.''.$it618_video_lang['s1293'].$addcount.' '.$it618_video_lang['s1294'].$okcount.'</div>
			  </td>
			  </tr>';
	}
	
	$query = DB::query("SELECT w.* FROM ".DB::table('it618_video_liveset')." w join ".DB::table('it618_video_shopliveset')." s on w.id=s.it618_liveset_id and s.it618_shopid=".$shoptmp['id']." where w.it618_isok=1 ORDER BY w.it618_order");
	while($it618_video_liveset = DB::fetch($query)) {
		
		$addcount = C::t('#it618_video#it618_video_live')->count_by_search('it618_liveset_id='.$it618_video_liveset['id'],'',$ShopId);
		$okcount = C::t('#it618_video#it618_video_live')->count_by_search('it618_chkstate=1 and it618_liveset_id='.$it618_video_liveset['id'],'',$ShopId);
		
		if($it618_video_liveset['it618_ossbucket']!=''&&$it618_video_liveset['it618_ossendpoint']!=''){
			$ossstr='<font color=#f60>'.$it618_video_lang['s1302'].$it618_video_liveset['it618_livetime'].$it618_video_lang['s1305'].'</font> '.$it618_video_lang['s1272'];
		}else{
			$ossstr='<font color=#f60>'.$it618_video_lang['s1302'].$it618_video_liveset['it618_livetime'].$it618_video_lang['s1305'].'</font> '.$it618_video_lang['s1273'];
		}
		
		if($lid>0){
			$tmpurl=it618_video_getrewrite('video_wap','sc_live_add@'.$lid.'@'.$it618_video_liveset['id'],'plugin.php?id=it618_video:wap&pagetype=sc_live_add&cid1='.$lid.'&cid2='.$it618_video_liveset['id']);
			$tmpbtn='<a href="'.$tmpurl.'" style="background-color:'.$it618_video_wapstyle['it618_color1'].';color:#fff;padding:6px 15px;border-radius:3px;float:right;margin-top:-5px">'.$it618_video_lang['s1279'].'</a>';
		}
		
		$sc_str.='<tr>
			  <td>
			  <div style="font-size:15px;color:#333;margin-top:6px;margin-bottom:6px">'.$it618_video_liveset['it618_name'].'</div>
			  <div style="color:#888">'.$it618_video_liveset['it618_about'].'<br><br>'.$ossstr.'<br><br></div>
			  <div style="color:#999">'.$tmpbtn.''.$it618_video_lang['s1293'].$addcount.' '.$it618_video_lang['s1294'].$okcount.'</div>
			  </td>
			  </tr>';
	}
	
	if($sc_str==''){
		$sc_str='<tr><td style="color:red;font-size:18px">'.$it618_video_lang['s1289'].'</td></tr>';
	}
}else{
	$sc_str= '<tr><td style="height:580px;vertical-align:top"><div style="font-size:18px;line-height:26px;color:'.$it618_video_wapstyle['it618_color1'].';margin-top:10px">'.it618_video_getlang('s1288').'<a href="'.$scproducturl.'" style="background-color:'.$it618_video_wapstyle['it618_color1'].';color:#FFF;border:none;height:48px;line-height:48px;padding:0;font-size:15px;width:100%; text-align:center;border-radius:0px;position:fixed;bottom:45px;left:0;">'.$it618_video_lang['s1866'].'</a></div></td></tr>';
}

$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename_wap.'/wap_video');
?>