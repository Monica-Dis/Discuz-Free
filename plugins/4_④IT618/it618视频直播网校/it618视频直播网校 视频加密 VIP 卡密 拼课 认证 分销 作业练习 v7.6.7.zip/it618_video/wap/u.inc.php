<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!video_is_mobile()){
	dheader("location:$video_home");
}

$navtitle=it618_video_getlang('t389');

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_video_getlang('s835');
}

if($error==1){
	$_G['mobiletpl'][2]='/';
	include template('it618_video:'.$templatename_wap.'/wap_video');
	return;
}

$menuusername=$_G['username'];
$u_avatarimg=it618_video_discuz_uc_avatar($_G['uid'],'middle');
$creditname=$_G['setting']['extcredits'][$it618_video['video_credit']]['title'];
$creditnum=DB::result_first("select extcredits".$it618_video['video_credit']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);

if($IsCredits==1){
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$creditsurl=it618_credits_getrewriteapi('credits_wap','uc','plugin.php?id=it618_credits:wap&dotype=uc');
	$tmpurl_buygroup=it618_credits_getrewriteapi('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
	$tmpurl_myvip=it618_credits_getrewriteapi('credits_wap','buygroup','plugin.php?id=it618_credits:wap&dotype=buygroup');
	$viplogo='source/plugin/it618_credits/images/group.png';
}

if($IsGroup==1){
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_vipgroup')." WHERE it618_isok=1");
	while($it618_video_goods_vipgroup =	DB::fetch($query)) {
		if($it618_video_goods_vipgroup['it618_groupid']>0){
			$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_video_goods_vipgroup['it618_groupid']);
			$groupclassid=$it618_group_group['it618_classid'];
			break;
		}
	}
	$tmpurl_myvip=it618_group_getrewrite('group_wap','u@0','plugin.php?id=it618_group:wap&pagetype=u');
	$viplogo='source/plugin/it618_group/images/group.png';
}

if($groupclassid>0){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
	$tmpurl_buygroup=it618_group_getrewrite('group_class',$groupclassid,'plugin.php?id=it618_group:class&cid='.$groupclassid);
}

if($IsUnion==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
	$url_union=it618_union_getrewrite('union_wap','u','plugin.php?id=it618_union:wap&pagetype=u');
}

$ucurl1=it618_video_getrewrite('video_wap','uc@1','plugin.php?id=it618_video:wap&pagetype=uc&cid=1');
$ucurl2=it618_video_getrewrite('video_wap','uc@2','plugin.php?id=it618_video:wap&pagetype=uc&cid=2');
$ucurl3=it618_video_getrewrite('video_wap','uc@3','plugin.php?id=it618_video:wap&pagetype=uc&cid=3');
$ucurl4=it618_video_getrewrite('video_wap','uc@4','plugin.php?id=it618_video:wap&pagetype=uc&cid=4');
$ucurl5=it618_video_getrewrite('video_wap','uc@5','plugin.php?id=it618_video:wap&pagetype=uc&cid=5');
$ucurl6=it618_video_getrewrite('video_wap','uc@6','plugin.php?id=it618_video:wap&pagetype=uc&cid=6');
$ucurl7=it618_video_getrewrite('video_wap','uc@7','plugin.php?id=it618_video:wap&pagetype=uc&cid=7');

$collectcount=C::t('#it618_video#it618_video_collect')->count_by_search(0,'','','',$_G['uid']);

$subscribecount=C::t('#it618_video#it618_video_shop_subscribe')->count_by_search(0,'','',$_G['uid']);

$salecount=C::t('#it618_video#it618_video_sale')->count_by_search(0,"s.it618_state!=0 ",'','',$_G['uid']);

$salekmcount=C::t('#it618_video#it618_video_salekm')->count_by_search('','',0,$_G['uid']);

$ucgoodscount=C::t('#it618_video#it618_video_goods_time')->count_by_search(0,'','','',$_G['uid']);

$playcount=C::t('#it618_video#it618_video_play')->count_by_search('','',0,$_G['uid']);

$playpjcount1=C::t('#it618_video#it618_video_play_pj')->count_by_search('it618_score1>0','',0,$_G['uid']);
$playpjcount2=C::t('#it618_video#it618_video_play_pj')->count_by_search('','',0,$_G['uid']);

$shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_uid_ok($_G['uid']);
if($_G['uid']==$shoptmp['it618_uid']&&$shoptmp['it618_state']==2&&$shoptmp['it618_htstate']==1){
	$scurl=it618_video_getrewrite('video_wap','sc@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc&cid='.$shoptmp['id']);
	$scsubscribeurl=it618_video_getrewrite('video_wap','sc_subscribe@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_subscribe&cid='.$shoptmp['id']);
	$scgwcurl=it618_video_getrewrite('video_wap','sc_gwc@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_gwc&cid='.$shoptmp['id']);
	$lecturerurl=it618_video_getrewrite('video_wap','lecturer@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=lecturer&cid='.$shoptmp['id']);
	$scliveurl=it618_video_getrewrite('video_wap','sc_live@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_live&cid='.$shoptmp['id']);
	$scproducturl=it618_video_getrewrite('video_wap','sc_product@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_product&cid='.$shoptmp['id']);
	
	$sclivecount = C::t('#it618_video#it618_video_live')->count_by_search('','',$shoptmp['id']);
	$sccount=C::t('#it618_video#it618_video_sale')->count_by_search($shoptmp['id'],"s.it618_tel!='' and s.it618_state!=0 ");
	$goodscount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods')." WHERE it618_shopid=".$shoptmp['id']." and it618_state=1");
	
	$isshop=1;
}

require_once DISCUZ_ROOT.'./source/plugin/it618_video/it618_api.func.php';
$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename_wap.'/wap_video');
?>