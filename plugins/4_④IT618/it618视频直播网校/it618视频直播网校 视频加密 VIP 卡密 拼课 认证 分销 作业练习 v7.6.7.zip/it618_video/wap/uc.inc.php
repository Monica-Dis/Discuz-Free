<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!video_is_mobile()){
	dheader("location:$video_home");
}

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_video_getlang('s835');
}

if($error==1){
	$_G['mobiletpl'][2]='/';
	include template('it618_video:'.$templatename_wap.'/wap_video');
	return;
}

$menutype=intval($_GET['cid']);
if($menutype==0)$menutype=1;
if($menutype==1){$current1='class="current"';$navtitle=it618_video_getlang('t8');}
if($menutype==2){$current2='class="current"';$navtitle=it618_video_getlang('s73');}
if($menutype==3){$current3='class="current"';$navtitle=it618_video_getlang('s933');}
if($menutype==4){$current4='class="current"';$navtitle=it618_video_getlang('s935');}
if($menutype==5){$current5='class="current"';$navtitle=it618_video_getlang('s1403');}
if($menutype==6){$current6='class="current"';$navtitle=it618_video_getlang('s1654');}
if($menutype==7){$current7='class="current"';$navtitle=it618_video_getlang('s2288');}

$ucurl1=it618_video_getrewrite('video_wap','uc@1','plugin.php?id=it618_video:wap&pagetype=uc&cid=1');
$ucurl2=it618_video_getrewrite('video_wap','uc@2','plugin.php?id=it618_video:wap&pagetype=uc&cid=2');
$ucurl3=it618_video_getrewrite('video_wap','uc@3','plugin.php?id=it618_video:wap&pagetype=uc&cid=3');
$ucurl4=it618_video_getrewrite('video_wap','uc@4','plugin.php?id=it618_video:wap&pagetype=uc&cid=4');
$ucurl5=it618_video_getrewrite('video_wap','uc@5','plugin.php?id=it618_video:wap&pagetype=uc&cid=5');
$ucurl6=it618_video_getrewrite('video_wap','uc@6','plugin.php?id=it618_video:wap&pagetype=uc&cid=6');
$ucurl7=it618_video_getrewrite('video_wap','uc@7','plugin.php?id=it618_video:wap&pagetype=uc&cid=7');

if($menutype==4){
	global $oss;
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/php/aliyunossconfig.php')){
		require_once DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/php/aliyunossconfig.php';
		if($it618_isok==1){
			$oss='&oss';
		}
	}
	
	$pjpicjs='<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/themes/default/default.css" />
				<script src="source/plugin/it618_video/kindeditor/kindeditor-min.js" charset="utf-8"></script>
				<script src="source/plugin/it618_video/kindeditor/lang/zh_CN.js" charset="utf-8"></script>';
}

require_once DISCUZ_ROOT.'./source/plugin/it618_video/it618_api.func.php';
$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename_wap.'/wap_video');
?>