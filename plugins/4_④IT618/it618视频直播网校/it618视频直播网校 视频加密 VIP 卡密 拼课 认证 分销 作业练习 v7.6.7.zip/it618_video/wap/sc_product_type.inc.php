<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!video_is_mobile()){
	$tmpurl=it618_video_getrewrite('video_home','','plugin.php?id=it618_video:index');
	dheader("location:$tmpurl");
}

$navtitle=it618_video_getlang('t49');

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_video_getlang('s835');
}else{
	$shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_uid_ok($_G['uid']);
	if($_G['uid']!=$shoptmp['it618_uid']){
		$error=1;
		$errormsg=it618_video_getlang('s513');
	}
}

if($error==1){
	$_G['mobiletpl'][2]='/';
	include template('it618_video:'.$templatename_wap.'/wap_video');
	return;
}

$pid=intval($_GET['cid']);
$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
$it618_price = DB::result_first("SELECT it618_price FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);

$scliveurl=it618_video_getrewrite('video_wap','sc_live@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_live&cid='.$shoptmp['id']);
$scliveseturl=it618_video_getrewrite('video_wap','sc_liveset@0','plugin.php?id=it618_video:wap&pagetype=sc_liveset&cid=0');
$scproducturl=it618_video_getrewrite('video_wap','sc_product@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_product&cid='.$shoptmp['id']);
$scproductaddurl=it618_video_getrewrite('video_wap','sc_product_add@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_product_add&cid='.$shoptmp['id']);

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_lesson')." WHERE it618_pid=".$pid);

$urlsql='&key='.$_GET['key'].'&it618_class1_id='.$_GET['it618_class1_id'].'&it618_class2_id='.$_GET['it618_class2_id'].'&state='.$_GET['state'].'&orderby='.$_GET['orderby'];

$sc_str='
<tr style="position:fixed;top:45px;left:0; z-index:1000;background-color:#f9f9f9;width:100%" onclick="location.href=\'plugin.php?id=it618_video:wap&pagetype=sc_product'.$urlsql.'\'"><td width=35 style="border:none"><img src="source/plugin/it618_video/images/left.png"></td><td style="border:none;padding-right:6px">'.$it618_video_lang['s504'].'<font color=red>'.$it618_video_lang['s514'].$it618_video_goods['it618_name'].$it618_video_lang['s515'].'</font></td></tr>
<tr><td colspan="2"></td></tr><tr><td colspan="2" style="background-color:#f9f9f9; border-bottom:#e8e8e8 1px solid; padding-bottom:6px; padding-top:6px;">'.it618_video_getlang('s491').'<font color=red>'.$count.'</font><br>'.it618_video_getlang('s492').'</td></tr><tr><td colspan="2"></td></tr>';

$tmpoptionstr='<option value="1">'.$it618_video_lang['s1144'].'</option><option value="2">'.$it618_video_lang['s1145'].'</option><option value="3">'.$it618_video_lang['s1146'].'</option><option value="4">'.$it618_video_lang['s1147'].'</option><option value="5">'.$it618_video_lang['s1148'].'</option>';

$n=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_type')." WHERE it618_pid=".$pid." ORDER BY it618_order,it618_name");
while($it618_video_goods_type = DB::fetch($query)) {
	
	$salecount = $it618_video_goods_type['it618_salecount'];
	$disabled="";$readonly="";$bgcolor="";
	if($salecount>0){
		$disabled="disabled=\"disabled\"";
		$readonly="readonly";
		$bgcolor=";background-color:#e8e8e8";
		
		if($it618_video_goods_type['it618_time']>0){
			if($it618_video_goods_type['it618_timetype']==1)$tmptype=$it618_video_lang['s1144'];
			if($it618_video_goods_type['it618_timetype']==2)$tmptype=$it618_video_lang['s1145'];
			if($it618_video_goods_type['it618_timetype']==3)$tmptype=$it618_video_lang['s1146'];
			if($it618_video_goods_type['it618_timetype']==4)$tmptype=$it618_video_lang['s1147'];
			if($it618_video_goods_type['it618_timetype']==5)$tmptype=$it618_video_lang['s1148'];
		}
		
		$tmpoptionstr1=$tmptype."<input type=\"hidden\" name=\"it618_timetype[".$it618_video_goods_type['id']."]\" value=\"".$it618_video_goods_type['it618_timetype']."\">";
	}else{
		$tmpoptionstr1=str_replace('<option value="'.$it618_video_goods_type['it618_timetype'].'"','<option value="'.$it618_video_goods_type['it618_timetype'].'" selected="selected"',$tmpoptionstr);
		$tmpoptionstr1="<select name=\"it618_timetype[".$it618_video_goods_type['id']."]\">".$tmpoptionstr1."</select>";
	}
	if($it618_video_goods_type['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
	
	if($it618_video_goods_type['it618_time']==0)$timecss='display:none';else $timecss="";
	
	$sc_str.='<tr>
			  <td width="48" style="vertical-align:top"><input class="checkbox" type="checkbox" id="chk_del'.$n.'" style="vertical-align:middle" name="delete[]" value="'.$it618_video_goods_lesson['id'].'"><label for="chk_del'.$n.'" style="vertical-align:middle">'.$it618_video_goods_lesson['id'].'</label></td>
			  <td>
			  <textarea name="it618_name['.$it618_video_goods_lesson['id'].']" style="width:98%;height:50px;margin-top:3px;border:#e8e8e8 1px solid">'.$it618_video_goods_lesson['it618_name'].'</textarea>
			  <br><span style="float:right"><input type="text" class="txt" style="width:40px;text-align:center;" name="it618_order['.$it618_video_goods_lesson['id'].']" value="'.$it618_video_goods_lesson['it618_order'].'"></span>'.$it618_gtype.'
			  </td>
			  </tr>';
	$n=$n+1;
}

	$sc_str.= <<<EOT
	<style>.addtr{ padding-left:17px; line-height:25px; background:url(static/image/admincp/bg_repno.gif) no-repeat 0 1px; *background:url(static/image/admincp/bg_repno.gif) no-repeat 0 0; color:#F60; }</style>
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''],[1,'<textarea style="width:98%;height:50px;margin-top:3px;border:#e8e8e8 1px solid" name="newit618_name[]"></textarea>']]
		];
	}
	rowtypedata=rundata();
	
	var addrowdirect = 0;
	var addrowkey = 0;
	function addrow(obj, type) {
		var table = obj.parentNode.parentNode.parentNode.parentNode.parentNode;
		if(!addrowdirect) {
			var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex);
		} else {
			var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex + 1);
		}
		var typedata = rowtypedata[type];
		for(var i = 0; i <= typedata.length - 1; i++) {
			var cell = row.insertCell(i);
			cell.colSpan = typedata[i][0];
			var tmp = typedata[i][1];
			if(typedata[i][2]) {
				cell.className = typedata[i][2];
			}
			tmp = tmp.replace(/\{(n)\}/g, function($1) {return addrowkey;});
			tmp = tmp.replace(/\{(\d+)\}/g, function($1, $2) {return addrow.arguments[parseInt($2) + 1];});
			cell.innerHTML = tmp;
		}
		addrowkey ++;
		addrowdirect = 0;
	}
	</script>
EOT;
	$sc_str.= '<tr><td colspan="8"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$it618_video_lang['s831'].'</a></div></td></tr>';

$sc_str.= '
<tr><td><input type="checkbox" name="chkall" style="vertical-align:middle" id="chkallDx4b" class="checkbox" onclick="check_all(this,\'chk_del\')" /><label for="chkallDx4b" style="vertical-align:middle">'.it618_video_getlang('s591').'</label> </td><td><input type="button" class="it618btn inputbtn" value="'.it618_video_getlang('s592').'" onclick="sc_save()" /></td></tr>'.'<input type=hidden value='.$n.' id="n" />';

$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename_wap.'/wap_video');
?>