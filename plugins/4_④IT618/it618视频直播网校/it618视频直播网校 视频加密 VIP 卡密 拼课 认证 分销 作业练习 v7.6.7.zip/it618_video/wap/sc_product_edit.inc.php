<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!video_is_mobile()){
	$tmpurl=it618_video_getrewrite('video_home','','plugin.php?id=it618_video:index');
	dheader("location:$tmpurl");
}

$navtitle=it618_video_getlang('s409');

if($_G['uid']<=0){
	$error=1;
	$errormsg=it618_video_getlang('s835');
}else{
	$shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_uid_ok($_G['uid']);
	if($_G['uid']!=$shoptmp['it618_uid']){
		$error=1;
		$errormsg=it618_video_getlang('s513');
	}
}

if($error==1){
	$_G['mobiletpl'][2]='/';
	include template('it618_video:'.$templatename_wap.'/wap_video');
	return;
}

$scliveurl=it618_video_getrewrite('video_wap','sc_live@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_live&cid='.$shoptmp['id']);
$scliveseturl=it618_video_getrewrite('video_wap','sc_liveset@0','plugin.php?id=it618_video:wap&pagetype=sc_liveset&cid=0');
$scproducturl=it618_video_getrewrite('video_wap','sc_product@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_product&cid='.$shoptmp['id']);
$scproductaddurl=it618_video_getrewrite('video_wap','sc_product_add@'.$shoptmp['id'],'plugin.php?id=it618_video:wap&pagetype=sc_product_add&cid='.$shoptmp['id']);

$sc_producturl='plugin.php?id=it618_video:wap&pagetype=sc_product&key='.$_GET['key'].'&it618_class1_id='.$_GET['it618_class1_id'].'&it618_class2_id='.$_GET['it618_class2_id'].'&state='.$_GET['state'].'&orderby='.$_GET['orderby'];

$pid=intval($_GET['cid']);
$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);

$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_class1')." ORDER BY it618_order");
while($it618_tmp = DB::fetch($query1)) {
	$classtmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

$classtmptmp=$classtmp1;
$classtmp1=str_replace('<option value='.$it618_video_goods['it618_class1_id'].'>','<option value='.$it618_video_goods['it618_class1_id'].' selected="selected">',$classtmp1);
$classtmp11=str_replace('<option value='.$it618_video_goods['it618_class1_id1'].'>','<option value='.$it618_video_goods['it618_class1_id1'].' selected="selected">',$classtmptmp);
$classtmp12=str_replace('<option value='.$it618_video_goods['it618_class1_id2'].'>','<option value='.$it618_video_goods['it618_class1_id2'].' selected="selected">',$classtmptmp);
$classtmp13=str_replace('<option value='.$it618_video_goods['it618_class1_id3'].'>','<option value='.$it618_video_goods['it618_class1_id3'].' selected="selected">',$classtmptmp);

$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_video_class1'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_class1')." ORDER BY it618_order");
$n1=1;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_video_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}

$indextmp=1;
$index=0;
$query = DB::query("SELECT * FROM ".DB::table('it618_video_class2')." where it618_class1_id=".$it618_video_goods['it618_class1_id']." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query)) {
	if($it618_tmp['id']==$it618_video_goods['it618_class2_id']){
		$index=$indextmp;
	}
	$indextmp+=1;
}
$jstmp.="redirec_class(document.getElementById('it618_class1_id').options.selectedIndex,0);redirec_class_sel('it618_class2_id',".$index.");";

if($it618_video_goods['it618_class1_id1']>0){
	$indextmp=1;
	$index1=0;
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_class2')." where it618_class1_id=".$it618_video_goods['it618_class1_id1']." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query)) {
		if($it618_tmp['id']==$it618_video_goods['it618_class2_id1']){
			$index1=$indextmp;
		}
		$indextmp+=1;
	}
	$jstmp.="redirec_class(document.getElementById('it618_class1_id1').options.selectedIndex,1);redirec_class_sel('it618_class2_id1',".$index1.");";
}

if($it618_video_goods['it618_class1_id2']>0){
	$indextmp=1;
	$index2=0;
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_class2')." where it618_class1_id=".$it618_video_goods['it618_class1_id2']." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query)) {
		if($it618_tmp['id']==$it618_video_goods['it618_class2_id2']){
			$index2=$indextmp;
		}
		$indextmp+=1;
	}
	$jstmp.="redirec_class(document.getElementById('it618_class1_id2').options.selectedIndex,2);redirec_class_sel('it618_class2_id2',".$index2.");";
}

if($it618_video_goods['it618_class1_id3']>0){
	$indextmp=1;
	$index3=0;
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_class2')." where it618_class1_id=".$it618_video_goods['it618_class1_id3']." ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query)) {
		if($it618_tmp['id']==$it618_video_goods['it618_class2_id3']){
			$index3=$indextmp;
		}
		$indextmp+=1;
	}
	$jstmp.="redirec_class(document.getElementById('it618_class1_id3').options.selectedIndex,3);redirec_class_sel('it618_class2_id3',".$index3.");";
}

$it618_video_goods['it618_tbts']=str_replace('[br]','<br />',$it618_video_goods['it618_tbts']);

if($it618_video_goods['it618_picbig']!='')$src='src="'.$it618_video_goods['it618_picbig'].'"';

if($it618_video_goods['it618_issecret']==1){
	$secretusersstr='';
	$tmparr=explode(",",$it618_video_goods['it618_secretusers']);
	for($i=0;$i<count($tmparr);$i++){
		$username=C::t('#it618_video#it618_video_sale')->fetch_username_by_uid($tmparr[$i]);
		$secretusersstr.=$username.' , ';
	}
	if($secretusersstr!='')$secretusersstr.='@';
	$secretusersstr=str_replace(' , @','',$secretusersstr);
	if($secretusersstr!=''){
		$secretusersstr='<tr><td></td><td style="color:green">'.$secretusersstr.'</td></tr>';	
	}
	
	$it618_issecret='<tr><td>'.it618_video_getlang('s1178').'</td><td><textarea name="it618_secretusers" style="width:776px;height:190px;margin-bottom:3px">'.$it618_video_goods['it618_secretusers'].'</textarea><br><font color=red>'.it618_video_getlang('s1179').'</font></td></tr>
	'.$secretusersstr.'
	';
}

if($it618_video_goods['it618_isuser']==1)$it618_isuser_checked='checked="checked"';else $it618_isuser_checked="";
if($it618_video_goods['it618_isip']==1)$it618_isip_checked='checked="checked"';else $it618_isip_checked="";
if($it618_video_goods['it618_isaddr']==1)$it618_isaddr_checked='checked="checked"';else $it618_isaddr_checked="";

$sc_str.='
<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_video/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_video/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_video/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false,
			width : \'99%\',
			afterBlur: function () { this.sync(); },
			items : [\'source\',\'|\', \'emoticons\', \'image\', \'|\',\'fontname\', \'fontsize\', \'|\', \'forecolor\', \'hilitecolor\', \'bold\', \'underline\']
		});
		
		editor1.clickToolbar("source");
		
		K(\'#image1\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
	});
	
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x,n)
	{
	 if(n==0)n="";
	 var temp = document.getElementById("it618_class2_id"+n); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	function redirec_class_sel(id,index)
	{
	 var temp = document.getElementById(id); 
	 temp.options[index].selected=true;
	
	}
</script>

<tr><td class="tdliveadd">
<div class="sctdtitle">
'.it618_video_getlang('s374').'
</div>
<select id="it618_class1_id" name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex,0)"><option value="0">'.it618_video_getlang('s375').'</option>'.$classtmp1.'</select> <select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.it618_video_getlang('s376').'</option></select>
<br><br>'.$it618_video_lang['s1005'].'
<br><br>
<select id="it618_class1_id1" name="it618_class1_id1" onchange="redirec_class(this.options.selectedIndex,1)"><option value="0">'.it618_video_getlang('s375').'</option>'.$classtmp11.'</select> <select id="it618_class2_id1"  name="it618_class2_id1"><option value="0">'.it618_video_getlang('s376').'</option></select>
<br><br>
<select id="it618_class1_id2" name="it618_class1_id2" onchange="redirec_class(this.options.selectedIndex,2)"><option value="0">'.it618_video_getlang('s375').'</option>'.$classtmp12.'</select> <select id="it618_class2_id2"  name="it618_class2_id2"><option value="0">'.it618_video_getlang('s376').'</option></select>
<br><br>
<select id="it618_class1_id3" name="it618_class1_id3" onchange="redirec_class(this.options.selectedIndex,3)"><option value="0">'.it618_video_getlang('s375').'</option>'.$classtmp13.'</select> <select id="it618_class2_id3"  name="it618_class2_id3"><option value="0">'.it618_video_getlang('s376').'</option></select>
<div class="sctdtitle">
'.$it618_video_lang['s21'].'
</div>
<select name="it618_gtype"><option value="0">'.$it618_video_lang['s22'].'</option><option value="1" selected="selected">'.$it618_video_lang['s26'].'</option></select><br>'.$it618_video_lang['s24'].'
<div class="sctdtitle">
'.it618_video_getlang('s839').'
</div>
<input type="text" class="txt" style="width:98%;margin-right:0" id="it618_name" name="it618_name" value="'.$it618_video_goods['it618_name'].'">
<div class="sctdtitle">';

if($IsChat==1){
$sc_str.= '<div class="sctdtitle">'.$it618_video_lang['s1369'].'</div>
<input class="checkbox" type="checkbox" id="chk_isuser" name="it618_isuser" '.$it618_isuser_checked.' value="1"><label for="chk_isuser">'.it618_video_getlang('s1366').'</label><br>
<input class="checkbox" type="checkbox" id="chk_isip" name="it618_isip" '.$it618_isip_checked.' value="1"><label for="chk_isip">'.it618_video_getlang('s1367').'</label><br>
<input class="checkbox" type="checkbox" id="chk_isaddr" name="it618_isaddr" '.$it618_isaddr_checked.' value="1"><label for="chk_isaddr">'.it618_video_getlang('s1368').'</label><br>';
}

$sc_str.='<div class="sctdtitle">'.it618_video_getlang('s394').'
</div>
<img id="img1" '.$src.' width="100" height="60" align="absmiddle"/> <input type="text" style="width:130px" id="url1" name="it618_picbig" value="'.$it618_video_goods['it618_picbig'].'" readonly="readonly"/> <input type="button" id="image1" style="height:35px;line-height:35px;padding:0 10px;border-radius:3px; " value="'.it618_video_getlang('s395').'" />
<div class="sctdtitle">
'.it618_video_getlang('s567').'
</div>
<textarea name="it618_description" style="width:98%;height:60px;">'.$it618_video_goods['it618_description'].'</textarea>
<div class="sctdtitle">
'.it618_video_getlang('s404').'
</div>
<textarea name="it618_message" style="width:98%;height:260px;visibility:hidden;">'.$it618_video_goods['it618_message'].'</textarea>
<div class="sctdtitle">
'.it618_video_getlang('s405').'
</div>
<textarea name="it618_seokeywords" style="width:98%;height:60px;">'.$it618_video_goods['it618_seokeywords'].'</textarea>
<div class="sctdtitle">
'.it618_video_getlang('s406').'
</div>
<textarea name="it618_seodescription" style="width:98%;height:60px;">'.$it618_video_goods['it618_seodescription'].'</textarea>
<a href="javascript:" onclick="sc_save()" style="background-color:'.$it618_video_wapstyle['it618_color1'].';color:#FFF;border:none;height:48px;line-height:48px;padding:0;font-size:15px;width:100%; text-align:center;border-radius:0px;position:fixed;bottom:45px;left:0">'.$it618_video_lang['s407'].'</a><script>'.$jstmp.'</script>
</td></tr>';

$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename_wap.'/wap_video');
?>