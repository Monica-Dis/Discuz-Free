<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

echo '
<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_video/js/jquery.js"></script>
<style>
.ns-sub-a, .ns-sub-b{background:url(source/plugin/it618_video/images/icon_new.png) no-repeat;}
.ns-sid-sub{margin-left:199px}
span.ns-sub-a{float:left;width:53px;height:26px;text-align:center;font:700 12px/26px Simsan;color:#fff;background-position:0 -2925px;cursor:pointer}
span.ns-sub-b{float:left;width:53px;height:26px;text-align:center;font:700 12px/26px Simsan;color:#666;background-position:-63px -2925px;cursor:pointer; margin-left:3px}
</style>
';

showtableheaders(it618_video_getlang('s1116'),'it618_video_sum');

	echo '<tr><td colspan="15"><div class="fixsel">'.it618_video_getlang('t236').' <input id="pid" class="txt" style="width:80px;margin-right:1px" /> '.it618_video_getlang('t238').' <input id="vid" class="txt" style="width:80px;margin-right:1px" /> '.it618_video_getlang('t239').' <input id="uid" class="txt" style="width:80px;margin-right:1px" /> &nbsp;<input type="button" class="btn" value="'.it618_video_getlang('t244').'" onclick="findpllist()" /> </div></td></tr>';
	
	echo '<tr id="tr_plsum"></tr>';
	
	showsubtitle(array(it618_video_getlang('t226'),it618_video_getlang('s1117'),it618_video_getlang('s1118'),it618_video_getlang('s1119')));
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_video/wap/images/loading.gif"></td></tr><tbody id="tr_pllist"></tbody>';
	
	echo '<tr id="plpage"></tr><div id="hfplbtn"></div>';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/
echo '
<script>
var plurl="'.$_G['siteurl'].'plugin.php?id=it618_video:ajax";
var sqlurl="";
function getpllist(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("tr_pllist").style.display="none";
	IT618_VIDEO.get(url+sqlurl+"'.$adminsid.'&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"shoppl_get"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_VIDEO("#tr_plsum").html(tmparr[0]);
	IT618_VIDEO("#tr_pllist").html(tmparr[1]);
	IT618_VIDEO("#plpage").html(tmparr[2]);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("tr_pllist").style.display="";
	}, "html");	
	plurl=url;
}
getpllist(plurl);

function findpllist(){
	var pid = document.getElementById("pid").value;
	var vid = document.getElementById("vid").value;
	var uid = document.getElementById("uid").value;
	
	sqlurl="&pid="+pid+"&vid="+vid+"&uid="+uid;
	var url="'.$_G['siteurl'].'plugin.php?id=it618_video:ajax";
	getpllist(url);
}

function hfpl(plid){
	if(hfplid==0){
		hfplid=plid;
		IT618_VIDEO("#hfplbtn").click();
	}
}

var dialog_hfpl,hfplid=0;
KindEditor.ready(function(K) {K(\'#hfplbtn\').click(function() {
	gethfpl(K);
});});

function gethfpl(K){
IT618_VIDEO.get("'.$_G['siteurl'].'plugin.php?id=it618_video:hfpl'.$adminsid.'"+"&plid="+hfplid, {ac:"it618"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	dialog_hfpl = K.dialog({
		width : 520,
		title : tmparr[0],
		body : \'<div style="padding:5px">\'+tmparr[1]+\'</div>\',
		closeBtn : {
			name : \''.$it618_video_lang['t285'].'\',
			click : function(e) {
				dialog_hfpl.remove();
				hfplid=0;
			}
		}
	});
	
	IT618_VIDEO(\'.ns-sub-a\').click(function(){
		var it618_content=document.getElementById("hfvalue").value;
		
		if(it618_content==\'\'){
			alert("'.$it618_video_lang['t342'].'");
			return;
		}
		if(confirm("'.$it618_video_lang['t343'].'")){
			
			document.getElementById("hfvalue").value=it618_content.replace(/\n/g,"[br]");
			
			IT618_VIDEO.post("'.$_G['siteurl'].'plugin.php?id=it618_video:ajax'.$adminsid.'"+"&ac=hfpl&plid="+hfplid,IT618_VIDEO("#it618_hfpl").serialize(),function (data, textStatus){
				var tmparr=data.split("it618_split");
			
				if(tmparr[0]=="ok"){
					alert(tmparr[1]);
					dialog_hfpl.remove();
					getpllist(plurl);
					hfplid=0;
				}else{
					if(getstrlen(data)>1000){
						alert("'.$it618_video_lang['t413'].'");
						return false;
    				}
					alert(data);
				}
			}, "html");
		}
	})
	
	IT618_VIDEO(\'.ns-sub-b\').click(function(){
		dialog_hfpl.remove();
		hfplid=0;
	})
	
	}, "html");		
}

function getstrlen(str) {
    var realLength = 0, len = str.length, charCode = -1;
    for (var i = 0; i < len; i++) {
        charCode = str.charCodeAt(i);
        if (charCode >= 0 && charCode <= 128) realLength += 1;
        else realLength += 2;
    }
    return realLength;
}

function delpl(plid){
	var geturl="'.$_G['siteurl'].'plugin.php?id=it618_video:ajax'.$adminsid.'&plid="+plid;

	IT618_VIDEO.get(geturl, {ac:"pl_del"},function (data, textStatus){
	alert(data);
	var url="'.$_G['siteurl'].'plugin.php?id=it618_video:ajax'.$adminsid.'&vid={$lid}&page=1";
	getpllist(plurl);
	}, "html");
}
</script>
';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>