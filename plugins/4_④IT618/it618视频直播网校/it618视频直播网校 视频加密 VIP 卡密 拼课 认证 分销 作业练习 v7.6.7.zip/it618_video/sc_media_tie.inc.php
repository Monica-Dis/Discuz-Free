<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

if($it618_video['video_tiemedia']!=1)exit;
if($it618_video_shop['it618_istiemedia']!=1)exit;

$ppp = 10;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$urlsql='&key='.$_GET['key'].'&class_id='.$_GET['class_id'].'&type='.$_GET['type'];

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_video_media_tie', "id=$delid");
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			$it618_url= trim($_GET['it618_url'][$id]);
			$it618_url=str_replace("'",'"',$it618_url);
			$it618_url=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" frameborder=0 allowfullscreen=1>',$it618_url);
			
			$urlarr1=explode("aliyuncs.com",$it618_url);
			$urlarr2=explode("https://",$_G['siteurl']);
			if(count($urlarr1)==1&&count($urlarr2)>1){
				$it618_url=str_replace("http://","https://",$it618_url);
			}
			
			if(count($urlarr1)>1){
				$it618_url=str_replace("https://","http://",$it618_url);
			}
			
			if($it618_video_media_mts=C::t('#it618_video#it618_video_media_mts')->fetch_by_url($it618_url)){
				if($it618_video_media_mts['it618_shopid']!=$ShopId){
					$it618_url='';
				}
			}

			C::t('#it618_video#it618_video_media_tie')->update($id,array(
				'it618_cid' => trim($_GET['it618_cid'][$id]),
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_url' => $it618_url,
				'it618_time1' => $_GET['it618_time1'][$id],
				'it618_time2' => $_GET['it618_time2'][$id],
				'it618_time3' => $_GET['it618_time3'][$id],
				'it618_islive' => trim($_GET['it618_islive'][$id]),
				'it618_isuser' => trim($_GET['it618_isuser'][$id]),
				'it618_isautoplay' => trim($_GET['it618_isautoplay'][$id])
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_cid_array = !empty($_GET['newit618_cid']) ? $_GET['newit618_cid'] : array();
	$newit618_type_array = !empty($_GET['newit618_type']) ? $_GET['newit618_type'] : array();
	
	foreach($newit618_cid_array as $key => $value) {
		
		if(trim($newit618_cid_array[$key]) != '') {
			                                        
			C::t('#it618_video#it618_video_media_tie')->insert(array(
				'it618_shopid' => $ShopId,
				'it618_cid' => trim($newit618_cid_array[$key]),
				'it618_type' => trim($newit618_type_array[$key]),
				'it618_isuser' => 0
			), true);
			$ok2=$ok2+1;
		}
	}

	it618_cpmsg($it618_video_lang['s33'].$ok1.' '.$it618_video_lang['s34'].$ok2.' '.$it618_video_lang['s35'].$del.')', "plugin.php?id=it618_video:sc_media_tie$adminsid".$urlsql, 'succeed');
}

it618_showformheader("plugin.php?id=it618_video:sc_media_tie$adminsid".$urlsql);
showtableheaders($it618_video_lang['s1228'],'sc_media_tie');

$query = DB::query("SELECT * FROM ".DB::table('it618_video_media_tieclass')." where it618_shopid=$ShopId ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

$tmpfind=str_replace('<option value='.$_GET['class_id'].'>','<option value='.$_GET['class_id'].' selected="selected">',$tmp);

echo '<tr><td colspan=14>'.it618_video_getlang('s97').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:300px" />'.it618_video_getlang('s1242').' <select name="type"><option value=0>'.it618_video_getlang('s102').'</option><option value=1>'.it618_video_getlang('s1237').'</option><option value=2>'.it618_video_getlang('s1238').'</option></select> '.it618_video_getlang('s848').' <select name="class_id"><option value=0>'.it618_video_getlang('s102').'</option>'.$tmpfind.'</select>&nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_video_getlang('s350').'" /></td></tr>';
	
$count = C::t('#it618_video#it618_video_media_tie')->count_by_search($it618sql,'',$ShopId,$_GET['type'],$_GET['class_id'],$_GET['key']);
$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_video:sc_media_tie$adminsid".$urlsql);

echo '<tr><td colspan=15>'.$it618_video_lang['s1235'].$count.'<span style="float:right;color:red">'.$it618_video_lang['s1234'].'</span></td></tr>';

showsubtitle(array($it618_video_lang['s1236'],$it618_video_lang['s1230'], $it618_video_lang['s1231'],$it618_video_lang['s1232']));

$n=1;
foreach(C::t('#it618_video#it618_video_media_tie')->fetch_all_by_search(
		$it618sql,$it618orderby,$ShopId,$_GET['type'],$_GET['class_id'],$_GET['key'],$startlimit,$ppp
) as $it618_video_media_tie) {
	
	if($it618_video_media_tie['it618_islive']==1){$it618_islive_checked='checked="checked"';}else $it618_islive_checked="";
	if($it618_video_media_tie['it618_isautoplay']==1){$it618_isautoplay_checked='checked="checked"';}else $it618_isautoplay_checked="";
	
	if($it618_video_media_tie['it618_isuser']==0){$it618_isuser_selected0='selected="selected"';}else $it618_isuser_selected0="";
	if($it618_video_media_tie['it618_isuser']==1){$it618_isuser_selected1='selected="selected"';}else $it618_isuser_selected1="";
	if($it618_video_media_tie['it618_isuser']==2){$it618_isuser_selected2='selected="selected"';}else $it618_isuser_selected2="";
	
	if($it618_video_media_tie['it618_type']==1){
		$it618_type='<font color="blue">'.$it618_video_lang['s1237'].'</font>';
		$btnstr='<span style="float:right">[<a href="javascript:" onclick="media_select2('.$it618_video_media_tie['id'].')">'.$it618_video_lang['s1790'].'</a>]</span>';
		$livestr='';
	}else{
		$it618_type='<font color="red">'.$it618_video_lang['s1238'].'</font>';
		$btnstr='<span style="float:right">[<a href="javascript:" onclick="media_select1('.$it618_video_media_tie['id'].')">'.$it618_video_lang['s1202'].'</a>] [<a href="javascript:" onclick="media_select('.$it618_video_media_tie['id'].')">'.$it618_video_lang['s1769'].'</a>]</span>';
		$livestr='<input type="checkbox" id="it618_islive'.$it618_video_media_tie['id'].'" name="it618_islive['.$it618_video_media_tie['id'].']" value=1 style="vertical-align:middle" '.$it618_islive_checked.'><label for="it618_islive'.$it618_video_media_tie['id'].'">'.$it618_video_lang['s128'].'</label>';
	}
	
	$tmp1=str_replace('<option value='.$it618_video_media_tie['it618_cid'].'>','<option value='.$it618_video_media_tie['it618_cid'].' selected="selected">',$tmp);
	
	showtablerow('', array('class="td25"', '', '', '', '', ''), array(
		'<input class="checkbox" type="checkbox" id="chk_del'.$it618_video_media_tie['id'].'" name="delete[]" value="'.$it618_video_media_tie['id'].'" '.$disabled.'><label for="chk_del'.$it618_video_media_tie['id'].'">'.$it618_video_media_tie['id'].'</label>',
		'<textarea id="name'.$it618_video_media_tie['id'].'" name="it618_name['.$it618_video_media_tie['id'].']" style="width:350px;height:33px;margin-bottom:3px">'.$it618_video_media_tie['it618_name'].'</textarea><br>
		'.$it618_type.' <select name="it618_cid['.$it618_video_media_tie['id'].']">'.$tmp1.'</select>',
		'<div style="width:536px;position:relative"><textarea id="videourl'.$it618_video_media_tie['id'].'" name="it618_url['.$it618_video_media_tie['id'].']" style="width:530px;height:33px;margin-bottom:3px">'.$it618_video_media_tie['it618_url'].'</textarea><br>'.$livestr.' <input type="checkbox" id="it618_isautoplay'.$it618_video_media_tie['id'].'" name="it618_isautoplay['.$it618_video_media_tie['id'].']" value=1 style="vertical-align:middle" '.$it618_isautoplay_checked.'><label for="it618_isautoplay'.$it618_video_media_tie['id'].'">'.$it618_video_lang['s1247'].'</label><span style="display:none"><br>
		'.$it618_video_lang['s399'].'<input id="time1'.$it618_video_media_tie['id'].'" type="text" class="txt" style="width:23px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" name="it618_time1['.$it618_video_media_tie['id'].']" value="'.$it618_video_media_tie['it618_time1'].'">'.$it618_video_lang['s397'].'
		<input id="time2'.$it618_video_media_tie['id'].'" type="text" class="txt" style="width:23px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" name="it618_time2['.$it618_video_media_tie['id'].']" value="'.$it618_video_media_tie['it618_time2'].'">'.$it618_video_lang['s398'].'
		<input id="time3'.$it618_video_media_tie['id'].'" type="text" class="txt" style="width:23px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" name="it618_time3['.$it618_video_media_tie['id'].']" value="'.$it618_video_media_tie['it618_time3'].'">'.$it618_video_lang['s400'].'</span>'.$btnstr.'</div>',
		'<select name="it618_isuser['.$it618_video_media_tie['id'].']"><option value=1 '.$it618_isuser_selected1.'>'.$it618_video_lang['s1239'].$it618_video_lang['s1241'].'</option><option value=2 '.$it618_isuser_selected2.'>'.$it618_video_lang['s28'].$it618_video_lang['s1241'].'</option><option value=0 '.$it618_isuser_selected0.'>'.$it618_video_lang['s30'].$it618_video_lang['s1241'].'</option></select><br><input type="text" style="width:95px;margin-top:6px;color:blue" readonly="readonly" onclick="this.select()" value="[mid='.$it618_video_media_tie['id'].']">'
	));
	$n=$n+1;
}
	
	$it618_video_langss1237=$it618_video_lang['s1237'];
	$it618_video_langss1238=$it618_video_lang['s1238'];
	$it618_video_langs1233=$it618_video_lang['s1233'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<select name="newit618_type[]"><option value=1>$it618_video_langss1237</option><option value=2 selected="selected">$it618_video_langss1238</option></select> <select name="newit618_cid[]">$tmp</select>'],
		[1,'$it618_video_langs1233'],
		[1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$it618_video_lang['s831'].'</a></div></td></tr>';
    
    echo '
    <span id="it618_media_select"></span>
	<script>
	var vid,type;
	function media_select(id){
		vid=id;type="video";title="'.$it618_video_lang['s1777'].'";
		document.getElementById("it618_media_select").click();
	}
	function media_select1(id){
		vid=id;type="video1";title="'.$it618_video_lang['s1201'].'";
		document.getElementById("it618_media_select").click();
	}
	function media_select2(id){
		vid=id;type="audio";title="'.$it618_video_lang['s1790'].'";
		document.getElementById("it618_media_select").click();
	}
	
    var dialog_media;
    KindEditor.ready(function(K) {K("#it618_media_select").click(function() {
    
        dialog_media = K.dialog({
            width : 848,
            height: 558,
            title : title,
            body : \'<div><iframe id="ifa_media" src="plugin.php?id=it618_video:sc_media_select'.$adminsid.'&type=\'+type+\'" style="border:0;" frameborder=0 width="848" height="536"></iframe></div>\',
            closeBtn : {
                name : "'.$it618_video_lang['t285'].'",
                click : function(e) {
                    dialog_media.remove();
                }
            }
        });
    
    });});
    </script>';
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_video_getlang('s644').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><input type="submit" class="btn" name="it618submit" value="'.it618_video_getlang('s645').'"/><input type=hidden value='.$page.' name=page /></div><br></td></tr>';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>