<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_video/video_default.func.php';

if(video_is_mobile()){ 
	$tmpurl=it618_video_getrewrite('video_wap','gwcsale@'.$_G['uid'],'plugin.php?id=it618_video:wap&pagetype=gwcsale');
	dheader("location:$tmpurl");
}

$uid = $_G['uid'];
if($uid<=0){
	echo it618_video_getlang('s1072').'<a href="member.php?mod=logging&action=login">'.it618_video_getlang('s461').'</a> <a href="member.php?mod='.$RegName.'">'.it618_video_getlang('s462').'</a>';exit;
}

if(isset($_GET['mysale'])){
	$mysale=1;
}

$it618paystr=it618_video_pay('gwc',$it618_video_lang['t384']);

$metatitle=it618_video_getlang('t187').' - '.$metatitle;

$pagetype='gwc';
$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename.'/video_default');
?>