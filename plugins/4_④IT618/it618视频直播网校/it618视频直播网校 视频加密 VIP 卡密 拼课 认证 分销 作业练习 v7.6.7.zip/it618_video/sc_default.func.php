<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$oss;

$it618_video = $_G['cache']['plugin']['it618_video'];

require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

if($_G['uid']<=0){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		if(!video_is_mobile()){ 
			require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
			$it618_members_index=it618_members_getmembers($_GET['id'],'#it618_members','','winapilogin');
			echo '<script type="text/javascript" src="source/plugin/it618_video/js/jquery.js"></script>'.$it618_members_index;exit;
		}
	}
	
	dheader("location:member.php?mod=logging&action=login");
}else{
	global $oss;
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/php/aliyunossconfig.php')){
		require_once DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/php/aliyunossconfig.php';
		if($it618_isok==1){
			$oss='&oss';
		}
	}
	
	if(isset($_GET['adminsid'])){
		$shopadmin=explode(",",$it618_video['video_shopadmin']);
		if(in_array($_G['uid'],$shopadmin)){
			$adminsid='&adminsid='.$_GET['adminsid'];
			if(!$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($_GET['adminsid'])){
				echo it618_video_getlang('s338');exit;
			}
		}
	}else{
		if(!$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_uid($_G['uid'])){
			echo it618_video_getlang('s338');exit;
		}
		
		$pid=intval($_GET['pid']);
		if($pid>0){
			if($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid)){
				if($it618_video_goods['it618_shopid']!=$it618_video_shop['id']){
					echo it618_video_getlang('s513');exit;
				}
			}
		}
		
		$lid=intval($_GET['lid']);
		if($lid>0){
			if($it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid)){
				$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_lesson['it618_pid']);
				if($it618_video_goods['it618_shopid']!=$it618_video_shop['id']){
					echo it618_video_getlang('s513');exit;
				}
			}
		}
		
		$typeid=intval($_GET['typeid']);
		if($typeid>0){
			if($it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($typeid)){
				$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_type['it618_pid']);
				if($it618_video_goods['it618_shopid']!=$it618_video_shop['id']){
					echo it618_video_getlang('s513');exit;
				}
			}
		}
	}
			
	$it618_state=$it618_video_shop['it618_state'];
	if($it618_state==0){
		echo it618_video_getlang('s334');exit;
	}elseif($it618_state==1){
		echo it618_video_getlang('s335');exit;
	}else{
		$it618_htstate=$it618_video_shop['it618_htstate'];
		if($it618_htstate==0){
			echo it618_video_getlang('s336');exit;
		}elseif($it618_htstate==2){
			echo it618_video_getlang('s337');exit;
		}else{
			$ShopId=$it618_video_shop['id'];
			$ShopUid=$it618_video_shop['it618_uid'];
			$ShopName=$it618_video_shop['it618_name'];
			$ShopName1=$ShopName;
			if(isset($_GET['adminsid'])){
				$ShopName1=$ShopName.'(<font color=red>'.$it618_video_lang['s1434'].'</font>)';
			}
			$Shopisale=$it618_video_shop['it618_issale'];
			$Shopischeck_live=$it618_video_shop['it618_ischeck_live'];
		}
	}
		
}
?>