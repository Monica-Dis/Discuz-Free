<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$ppp = 10;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$it618sql = "1";

$state0='';$state1='';$state2='';$state3='';
if($_GET['state']==0){$state0='selected="selected"';}
if($_GET['state']==1){$it618sql .= " and it618_chkstate = 0";$state1='selected="selected"';}
if($_GET['state']==2){$it618sql .= " and it618_chkstate = 1";$state2='selected="selected"';}
if($_GET['state']==3){$it618sql .= " and it618_chkstate = 2";$state3='selected="selected"';}

$orderby0='';$orderby1='';$orderby2='';
if($_GET['orderby']==0){$it618orderby = "it618_time desc";$orderby0='selected="selected"';}
if($_GET['orderby']==1){$it618orderby = "it618_duration desc";$orderby1='selected="selected"';}
if($_GET['orderby']==2){$it618orderby = "it618_size desc";$orderby2='selected="selected"';}

$urlsql='&key='.$_GET['key'].'&class_id='.$_GET['class_id'].'&state='.$_GET['state'].'orderby='.$_GET['orderby'];

if(submitcheck('it618submit_edit')){
	$ok=0;
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			C::t('#it618_video#it618_video_media')->update($id,array(
				'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
				'it618_class_id' => $_GET['it618_class_id'][$id]
			));
	
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_video_getlang('s345').$ok, "plugin.php?id=it618_video:sc_media$adminsid&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_delete')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_media = C::t('#it618_video#it618_video_media')->fetch_by_id($delid);
		if($it618_video_media['it618_chkstate']==0){
			it618_video_deletemediaandmts($it618_video_media['it618_mediaid']);
			DB::query("delete from ".DB::table('it618_video_media')." where id=".$delid);
			$ok=$ok+1;
		}
	}

	it618_cpmsg($it618_video_lang['s193'].$ok, "plugin.php?id=it618_video:sc_media$adminsid&page=$page".$urlsql, 'succeed');
}

$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_media_class')." where it618_shopid=$ShopId ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

$tmp1=str_replace('<option value='.$_GET['class_id'].'>','<option value='.$_GET['class_id'].' selected="selected">',$tmp);

it618_showformheader("plugin.php?id=it618_video:sc_media$adminsid&page=$page".$urlsql);
showtableheaders(it618_video_getlang('t34'),'it618_video_sum');
	echo '<tr><td colspan=14>'.it618_video_getlang('s97').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:300px" /> '.it618_video_getlang('s848').' <select name="class_id"><option value=0>'.it618_video_getlang('s102').'</option>'.$tmp1.'</select> '.it618_video_getlang('s101').' <select name="state"><option value=0 '.$state0.'>'.it618_video_getlang('s102').'</option><option value=1 '.$state1.'>'.it618_video_getlang('s677').'</option><option value=2 '.$state2.'>'.it618_video_getlang('s678').'</option><option value=3 '.$state3.'>'.it618_video_getlang('s679').'</option></select> <select name="orderby"><option value=0 '.$orderby0.'>'.it618_video_getlang('s697').'</option><option value=1 '.$orderby1.'>'.it618_video_getlang('s698').'</option><option value=2 '.$orderby2.'>'.it618_video_getlang('s699').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_video_getlang('s350').'" /></td></tr>';
	
	$count = C::t('#it618_video#it618_video_media')->count_by_search($it618sql,'',$ShopId,$_GET['class_id'],$_GET['key']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_video:sc_media$adminsid".$urlsql);
	
	$sumsize = C::t('#it618_video#it618_video_media')->sum_size_by_search($it618sql,'',$ShopId,$_GET['class_id'],$_GET['key']);
	$summtscount = C::t('#it618_video#it618_video_media')->sum_mtscount_by_search($it618sql,'',$ShopId,$_GET['class_id'],$_GET['key']);
	$summtssize = C::t('#it618_video#it618_video_media')->sum_mtssize_by_search($it618sql,'',$ShopId,$_GET['class_id'],$_GET['key']);
	
	echo '<tr><td colspan=14>'.it618_video_getlang('s850').$count.' '.$it618_video_lang['s583'].round((($sumsize+$summtssize)/1024/1024),2).'M '.$it618_video_lang['s584'].round(($sumsize/1024/1024),2).'M '.$it618_video_lang['s585'].$summtscount.' '.$it618_video_lang['s586'].round(($summtssize/1024/1024),2).'M<span style="float:right;color:red">'.it618_video_getlang('s849').'</span></td></tr>';
	showsubtitle(array('',it618_video_getlang('s842'),it618_video_getlang('s843'),it618_video_getlang('s844'),$it618_video_lang['s845']));
	
	$n=1;
	foreach(C::t('#it618_video#it618_video_media')->fetch_all_by_search(
		$it618sql,$it618orderby,$ShopId,$_GET['class_id'],$_GET['key'],$startlimit,$ppp
	) as $it618_video_media) {

		$tmp1=str_replace('<option value='.$it618_video_media['it618_class_id'].'>','<option value='.$it618_video_media['it618_class_id'].' selected="selected">',$tmp);
		
		$mtsstr='';
		if($it618_video_media['it618_mtscount']==0){
			it618_video_updatemedia($it618_video_media['it618_url']);
			$mtsstr=$it618_video_lang['s958'];
		}else{
			$query = DB::query("SELECT * FROM ".DB::table('it618_video_media_mts')." where it618_media_id=".$it618_video_media['id']." ORDER BY it618_size");
			while($it618_video_media_mts =	DB::fetch($query)) {
				$mtsstr.='<font color=green><b>'.$it618_video_media_mts['it618_actname'].'</b></font> <font color=#999>'.$it618_video_lang['s1685'].'</font>'.it618_video_getvideotime($it618_video_media_mts['it618_duration']).' <font color=#999>'.$it618_video_lang['s1686'].'</font>'.round(($it618_video_media_mts['it618_size']/1024/1024),2).'MB<br><font color=#999>'.$it618_video_lang['s1687'].'</font>'.$it618_video_media_mts['it618_fps'].'FPS <font color=#999>'.$it618_video_lang['s1688'].'</font>'.$it618_video_media_mts['it618_bitrate'].'Kbps <font color=#999>'.$it618_video_lang['s1689'].'</font>'.$it618_video_media_mts['it618_width'].'x'.$it618_video_media_mts['it618_height'].'px<br>';
			}
		}
		
		$urlstr='';
		if($it618_video_media['it618_chkstate']==0){
			$it618_chkstate='<font color=red>'.$it618_video_lang['s677'].'</font>';
		}
		
		if($it618_video_media['it618_chkstate']==1){
			$it618_chkstate='<font color=green>'.$it618_video_lang['s678'].'</font>';
			//$urlstr='[<a href="'.it618_video_getsignedurl($it618_video_media['it618_url']).'" target="_blank">'.$it618_video_lang['s46'].'</a>]';
		}
		
		if($it618_video_media['it618_chkstate']==2){
			$it618_chkstate='<font color=blue>'.$it618_video_lang['s679'].'</font>';
		}

		showtablerow('', array('', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_video_media['id'].'"><label for="chk_del'.$n.'">'.$it618_video_media['id'].'</label>',
			'<img src="'.it618_video_cdnkeyurl($it618_video_media['it618_coverurl']).'" width="133" height="80"/>',
			'<input type="text" class="txt" style="width:430px;margin-bottom:4px" name="it618_name['.$it618_video_media['id'].']" value="'.$it618_video_media['it618_name'].'"><br>
			<select id="class'.$n.'" name="it618_class_id['.$it618_video_media['id'].']" style="margin-bottom:4px">'.$tmp1.'</select> <font color=#999>'.$it618_video_lang['s1685'].'</font>'.it618_video_getvideotime($it618_video_media['it618_duration']).' <font color=#999>'.$it618_video_lang['s1686'].'</font>'.round(($it618_video_media['it618_size']/1024/1024),2).'MB '.$urlstr.' <font color=#999>'.date('Y-m-d H:i:s', $it618_video_media['it618_time']).'</font><br>
			<font color=#999>ID:'.$it618_video_media['it618_mediaid'].'</font><br><font color=#999>'.$it618_video_lang['s1687'].'</font>'.$it618_video_media['it618_fps'].'FPS <font color=#999>'.$it618_video_lang['s1688'].'</font>'.$it618_video_media['it618_bitrate'].'Kbps <font color=#999>'.$it618_video_lang['s1689'].'</font>'.$it618_video_media['it618_width'].'x'.$it618_video_media['it618_height'].'px',
			$mtsstr,
			$it618_chkstate
		));
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_video_getlang('s129').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><select onchange="mediaclass(this)">'.$tmp.'</select><input type="submit" class="btn" name="it618submit_edit" value="'.it618_video_getlang('s851').'"/> <input type="submit" class="btn" name="it618submit_delete" value="'.$it618_video_lang['s191'].'" onclick="return confirm(\''.$it618_video_lang['s1431'].'\')"/><input type=hidden value='.$page.' name=page /></div><br></td></tr>
	';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/

echo '
<script type="text/javascript">
  function mediaclass(obj){
	  for(var i=1;i<'.$n.';i++){
		  document.getElementById("class"+i).selectedIndex = obj.selectedIndex;
	  }
  }
  
  function check_all(obj,id){
	  for(var i=1;i<'.$n.';i++){
		  document.getElementById(id+""+i).checked = obj.checked;
	  }
  }
</script>';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>