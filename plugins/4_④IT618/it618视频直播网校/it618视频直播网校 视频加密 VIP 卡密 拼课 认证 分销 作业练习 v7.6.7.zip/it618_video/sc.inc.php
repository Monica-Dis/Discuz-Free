<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_default.func.php';

if($templatename_admin=='sc_proton'){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
		$it618_membersstr= '<span id="it618_members"></span>'.it618_members_getmembers($_GET['id'],'#it618_members');
	}
	
	if($IsCredits==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
		$it618_creditsstr= '<span id="it618_credits"></span>'.it618_credits_getcredits($_GET['id'],'#it618_credits');
	}
	
	if($IsGroup==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
		$it618_membersstr.=it618_group_getad($_GET['id'],2);
	}
	
	$m3u8osscount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_video_media_wmf')." w join ".DB::table('it618_video_media_shopwmf')." s on w.id=s.it618_wmf_id and s.it618_shopid=$ShopId where w.it618_isok=1");
			
	$mp4osscount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_video_media_aoss')." w join ".DB::table('it618_video_media_shopaoss')." s on w.id=s.it618_aoss_id and s.it618_shopid=$ShopId where w.it618_isok=1 and w.it618_osstype=1");
	
	$audioosscount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_video_media_aoss')." w join ".DB::table('it618_video_media_shopaoss')." s on w.id=s.it618_aoss_id and s.it618_shopid=$ShopId where w.it618_isok=1 and w.it618_osstype=0");
	
	$attachosscount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_video_media_aoss')." w join ".DB::table('it618_video_media_shopaoss')." s on w.id=s.it618_aoss_id and s.it618_shopid=$ShopId where w.it618_isok=1 and w.it618_osstype=2");
	
	$livesetcount = DB::query("SELECT count(1) FROM ".DB::table('it618_video_liveset')." w join ".DB::table('it618_video_shopliveset')." s on w.id=s.it618_liveset_id and s.it618_shopid=$ShopId where w.it618_isok=1");
}

$urltmp='member.php?mod=logging&action=logout&formhash='.FORMHASH;
$username=$_G['username'];
$u_avatarimg=it618_video_discuz_uc_avatar($_G['uid'],'middle');
$lecturerurl=it618_video_getrewrite('video_lecturer',$ShopId,'plugin.php?id=it618_video:lecturer&lid='.$ShopId);

$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename_admin.'/sc_index');
?>