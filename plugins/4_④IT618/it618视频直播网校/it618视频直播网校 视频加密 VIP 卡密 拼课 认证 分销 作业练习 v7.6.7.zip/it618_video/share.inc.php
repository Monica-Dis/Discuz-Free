<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_video = $_G['cache']['plugin']['it618_video'];

require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

if($_GET['sharetype']=='shop'){
	$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($_GET['shareid']);
	$it618_name=$it618_video_shop['it618_name'];
	$share_img=$it618_video_shop['it618_logo'];
	$tmparr=explode('://',$share_img);
	if(count($tmparr)==1)$share_img=$_G['siteurl'].$share_img;
	$it618_about=$it618_video_shop['it618_about'];
	$it618_about=str_replace(array("\r\n", "\r", "\n"), '', $it618_about);
	$it618_about=cutstr($it618_about,190,'...');
	
	if($IsUnion==1&&$_G['uid']>0){
		$urltmp='tuiuid='.$_G['uid'];
	}
	
	if($urltmp!=''){
		$tmpurl=$_G['siteurl'].it618_video_getrewrite('video_lecturer',$it618_video_shop['id'],'plugin.php?id=it618_video:lecturer&lid='.$it618_video_shop['id'].'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=$_G['siteurl'].it618_video_getrewrite('video_lecturer',$it618_video_shop['id'],'plugin.php?id=it618_video:lecturer&lid='.$it618_video_shop['id']);
	}
	
	if($IsWxMini==1){
		if($it618_wxmini_app=C::t('#it618_wxmini#it618_wxmini_app')->fetch_by_pluginid('it618_video')){
			$tmpurl=$_G['siteurl'].'plugin.php?id=it618_wxmini:url&aid='.$it618_wxmini_app['id'].'&q='.urlencode($tmpurl);
		}
	}
	
	$qrcodesrc='plugin.php?id=it618_video:urlcode&url='.urlencode($tmpurl);

	if($IsUnion==1){
		$sharecodecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." WHERE id=2 and it618_isshop=1 and it618_state=1");
		if($sharecodecount>0){
			$share_img=$_G['siteurl'].'plugin.php?id=it618_union:sharecode&cid=2&class=shop&dataid='.$it618_video_shop['id'].'&shareurl='.urlencode($tmpurl);
		}
	}
}else{
	$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($_GET['shareid']);
	$pid=$it618_video_goods['id'];
	$it618_name=$it618_video_goods['it618_name'];
	$share_img=it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']);
	$tmparr=explode('://',$share_img);
	if(count($tmparr)==1)$share_img=$_G['siteurl'].$share_img;
	$it618_about=$it618_video_goods['it618_description'];
	$it618_about=str_replace(array("\r\n", "\r", "\n"), '', $it618_about);
	$it618_about=cutstr($it618_about,90,'...');
	
	$pricestr=$it618_video_lang['s1534'];
	$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
	if($it618_video_shop['it618_issale']==1){
		if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
			$pricestr=it618_video_getgoodsprice($it618_video_goods,'goods_price');
		}else{
			$pricestr=$it618_video_lang['s106'];
		}
	}
	
	if($IsUnion==1&&$_G['uid']>0){
		$urltmp='tuiuid='.$_G['uid'];
	}
	
	if($urltmp!=''){
		$tmpurl=$_G['siteurl'].it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id'].'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=$_G['siteurl'].it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
	}
	
	if($IsWxMini==1){
		if($it618_wxmini_app=C::t('#it618_wxmini#it618_wxmini_app')->fetch_by_pluginid('it618_video')){
			$tmpurl=$_G['siteurl'].'plugin.php?id=it618_wxmini:url&aid='.$it618_wxmini_app['id'].'&q='.urlencode($tmpurl);
		}
	}
	
	$qrcodesrc='plugin.php?id=it618_video:urlcode&url='.urlencode($tmpurl);
	
	if($IsUnion==1){
		$sharecodecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." WHERE id=2 and it618_isproduct=1 and it618_state=1");
		if($sharecodecount>0){
			$share_img=$_G['siteurl'].'plugin.php?id=it618_union:sharecode&cid=2&class=product&dataid='.$it618_video_goods['id'].'&shareurl='.urlencode($tmpurl);
		}
	}
}

if($IsUnion==1){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
	}
}

$tuicount=intval($_GET['tuicount']);
if($sharecodecount>0||$union_video_isok>0||$tuicount>0){
	$sharetui=1;
}

if($_GET['wap']==1){
	if($sharetui>0){
		$shoptype='video';
		$scrolldivheight=$_GET['height']-100;
		
		$tmpmobiletpl=$_G['mobiletpl'][IN_MOBILE];
		$_G['mobiletpl'][2]='/';
		include template('it618_union:unionshare');
		$_G['mobiletpl'][IN_MOBILE]=$tmpmobiletpl;
	}
}else{
	if($sharetui>0){
		$shoptype='video';
		$scrolldivheight=390;
		
		include template('it618_union:unionshare');
	}
}

$_G['mobiletpl'][2]='/';
include template('it618_video:share');
?>