<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

class plugin_it618_video_base {
	function common_base() {
		global $_G;
		$cache_file = DISCUZ_ROOT.'./source/plugin/it618_video/cache.php';
		$tmptime=3;
		require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';
		
		if(($_G['timestamp'] - @filemtime($cache_file)) > $tmptime) {
			
			@$fp = fopen($cache_file,"w");
			fwrite($fp,$_G['timestamp']);
			fclose($fp);

			$liveonline = array();
			$liveorder = array();
			$query = DB::query("SELECT * FROM ".DB::table('it618_video_live')." where it618_chkstate=1 and it618_isok=0 and it618_streamname!=''");
			while($it618_video_live = DB::fetch($query)) {
				if($it618_video_live['it618_etime']<=$_G['timestamp']){
					if($it618_video_live['it618_liveset_id']==0){
						if($it618_video_live['it618_etime']+30<$_G['timestamp']){
							C::t('#it618_video#it618_video_live')->update($it618_video_live['id'],array(
								'it618_isok' => 1
							));
							it618_video_deletegoodsvideo($it618_video_live['id']);
						}
					}else{
						it618_video_updatevideolive($it618_video_live);
					}
				}else{
					if($it618_video_live['it618_liveset_id']==0){
						if($it618_video_live['it618_btime']<=$_G['timestamp']&&$it618_video_live['it618_isonline']!=1&&$it618_video_live['it618_m3u8url']!=''){
							C::t('#it618_video#it618_video_live')->update($it618_video_live['id'],array(
								'it618_isonline' => 1
							));
						}
					}else{
						if(!in_array($it618_video_live['it618_liveset_id'], $liveonline)){
							$liveonline[]=$it618_video_live['it618_liveset_id'];
						}
					}
					
					if($it618_video_live['it618_btime']-300<=$_G['timestamp']){
						$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_live_order')." where it618_state=0 and it618_liveid=".$it618_video_live['id']." limit 30");
						while($it618_video_live_order = DB::fetch($query1)) {
							DB::query("update ".DB::table('it618_video_live_order')." set it618_state=1 where id=".$it618_video_live_order['id']);
							$liveorder[]=$it618_video_live_order['id'];
						}
					}
				}
			}
			
			for($i=0;$i<count($liveorder);$i++){
				set_time_limit (0);
				ignore_user_abort(true);
				it618_video_sendmessage("live_user",$liveorder[$i]);
			}

			for($i=0;$i<count($liveonline);$i++){
				it618_video_updatevideoliveonline($liveonline[$i]);
			}
			
			foreach(C::t('#it618_video#it618_video_shop')->fetch_all_by_search("it618_htstate<>0") as $it618_video_shop) {
				$isviptbtime=0;
				if($IsGroup==1){
					if($it618_group_rzmoney=C::t('#it618_group#it618_group_rzmoney')->fetch_by_shoptype_lid('video',0)){
						if($it618_group_rzmoney['it618_istbtime']==1){
							$isviptbtime=1;
							if($it618_group_group_user=C::t('#it618_group#it618_group_group_user')->fetch_by_groupid_uid($it618_group_rzmoney['it618_groupid'],$it618_video_shop['it618_uid'])){
								if($_G['timestamp']>=$it618_group_group_user['it618_etime']&&$it618_group_group_user['it618_etime']>0){
									C::t('#it618_video#it618_video_shop')->update_it618_htstate_by_id($it618_video_shop['id'],2);
								}else{
									C::t('#it618_video#it618_video_shop')->update_it618_htstate_by_id($it618_video_shop['id'],1);
								}
							}else{
								C::t('#it618_video#it618_video_shop')->update_it618_htstate_by_id($it618_video_shop['id'],2);
							}
						}
					}
				}
				
				if($isviptbtime==0){
					if($_G['timestamp']>=$it618_video_shop['it618_htetime']){
						C::t('#it618_video#it618_video_shop')->update_it618_htstate_by_id($it618_video_shop['id'],2);
					}else{
						C::t('#it618_video#it618_video_shop')->update_it618_htstate_by_id($it618_video_shop['id'],1);
					}
				}
			}

		}
		
	}
	
	function post_message_base($value){
		global $_G;
		
		$type=$value['param'][0];
		$fid=$value['param'][2]['fid'];
		$tid=$value['param'][2]['tid'];
		$pid=$value['param'][2]['pid'];
		
		$it618_video = $_G['cache']['plugin']['it618_video'];
		if($it618_video['video_tiemedia']==0)return;

		if($type=='post_newthread_succeed'||$type=='post_reply_succeed'||$type=='post_edit_succeed'){
			if($forum_post=DB::fetch_first("SELECT * FROM ".DB::table('forum_post')." WHERE pid=$pid")){
				$tmparr=explode("[mid=",$forum_post['message']);
				for($i=1;$i<count($tmparr);$i++){
					$tmparr1=explode("]",$tmparr[$i]);
					if($tmparr1[0]>0){
						$mids.=$tmparr1[0].',';	
					}
				}
				
				if($mids!=''){
					$mids=$mids.'@';
					$mids=str_replace(",@","",$mids);
				}
				
				if($it618_video_tie=C::t('#it618_video#it618_video_tie')->fetch_by_pid($pid)){
					if($mids!=''){
						C::t('#it618_video#it618_video_tie')->update($it618_video_tie['id'],array(
							'it618_first' => $forum_post['first'],
							'it618_mids' => $mids
						));
					}else{
						DB::delete('it618_video_tie', "id=".$it618_video_tie['id']);
					}
				}else{
					if($mids!=''){
						C::t('#it618_video#it618_video_tie')->insert(array(
							'it618_fid' => $fid,
							'it618_tid' => $tid,
							'it618_first' => $forum_post['first'],
							'it618_pid' => $pid,
							'it618_mids' => $mids
						), true);
					}
				}
				
			}
		}
	}
	
	function getmediatie($mid,$wap,$authorid,$tid,$type=0) {
		global $_G,$it618_video_lang;
		if($it618_video_media_tie=C::t('#it618_video#it618_video_media_tie')->fetch_by_id($mid)){
			if($it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_uid_ok($authorid)){
				if($it618_video_shop['id']!=$it618_video_media_tie['it618_shopid']){
					return '';
				}
				if($it618_video_shop['it618_istiemedia']!=1){
					return '';
				}
			}else{
				return '';	
			}
			
			if($type==0){
				if($_G['uid']!=$it618_video_shop['it618_uid']){
					require_once DISCUZ_ROOT.'./source/plugin/it618_video/lang.func.php';
					
					if($it618_video_media_tie['it618_type']==1){
						$tmptype=$it618_video_lang['s1246'];
					}else{
						$tmptype=$it618_video_lang['s1245'];
					}
					
					if($it618_video_media_tie['it618_isuser']==2){
						if($_G['uid']<=0){
							return '<div style="width:100%;padding-top:10px;padding-bottom:10px"><font color=red>'.$it618_video_lang['s1243'].$tmptype.$it618_video_media_tie['it618_name'].'</font></div>';
						}
					}
					
					if($it618_video_media_tie['it618_isuser']==1){
						if($_G['uid']<=0){
							return '<div style="width:100%;padding-top:10px;padding-bottom:10px"><font color=red>'.$it618_video_lang['s1244'].$tmptype.$it618_video_media_tie['it618_name'].'</font></div>';
						}else{
							if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('forum_post')." WHERE tid=".$tid." and authorid=".$_G['uid']." and first=0")==0){
								return '<div style="width:100%;padding-top:10px;padding-bottom:10px"><font color=red>'.$it618_video_lang['s1244'].$tmptype.$it618_video_media_tie['it618_name'].'</font></div>';
							}
						}
					}
				}
			}
			
			if($it618_video_media_tie['it618_type']==1){
				if($wap==1){
					$getmediatiestr='<iframe src="plugin.php?id=it618_video:audiotie&type='.$type.'&mid='.$it618_video_media_tie['id'].'&wap='.$wap.'" style="border:0;width:100%;height:45px" scrolling="no" frameborder=0></iframe>';
				}else{
					$getmediatiestr='<iframe src="plugin.php?id=it618_video:audiotie&type='.$type.'&mid='.$it618_video_media_tie['id'].'&wap='.$wap.'" style="border:0;width:760px;height:45px" scrolling="no" frameborder=0></iframe>';
				}
				return $getmediatiestr;
			}else{
				$it618_url=$it618_video_media_tie['it618_url'];
				$tmparr=explode("<iframe",$it618_url);
				if(count($tmparr)>1){
					$isiframe=1;
					$it618_url=str_replace("'",'"',$it618_url);
					if($wap==1){
						$getmediatiestr=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe style="width:100%;height:200px;margin-top:10px;" src="\1" frameborder=0 allowfullscreen=1>',$it618_url);
					}else{
						$getmediatiestr=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe style="width:760px;height:430px;margin-top:10px;margin-bottom:10px" src="\1" frameborder=0 allowfullscreen=1>',$it618_url);
					}
				}else{
					$tmparr1=explode(".m3u8",$it618_url);
					if(count($tmparr1)>1){
						$it618_url1=str_replace("https://",'http://',$it618_url);
						if($it618_video_media_mts=C::t('#it618_video#it618_video_media_mts')->fetch_by_url($it618_url1)){
							$it618_video_media=C::t('#it618_video#it618_video_media')->fetch_by_id($it618_video_media_mts['it618_media_id']);
							$it618_video_media_wmf=C::t('#it618_video#it618_video_media_wmf')->fetch_by_id($it618_video_media['it618_wmf_id']);
							dsetcookie('it618_hlskms'.md5($it618_video_media['it618_mediaid'].$it618_video_media_wmf['it618_accesskey']),1,31536000);
						}
					}
					$it618_url=it618_video_cdnkeyurl($it618_url);
					
					if($type==1){
						$autoplay='false';
					}else{
						if($it618_video_media_tie['it618_isautoplay']==1)$autoplay='true';else $autoplay='false';
					}
					
					if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php')){
						require DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php';
					}
					
					$player_version=$it618_video_lang['playerversion'];
				
					if($wap==1){
						$getmediatiestr='
						<link rel="stylesheet" href="https://g.alicdn.com/de/prismplayer/'.$player_version.'/skins/default/aliplayer-min.css" />
						<script type="text/javascript" src="https://g.alicdn.com/de/prismplayer/'.$player_version.'/aliplayer-min.js" charset="utf-8"></script>
						<style type="text/css">
						  .prism-player .prism-cover{
							background-color:none;
							display:block;
						  }
						  
						  .prism-player .prism-marker-text{
							display:none;
						  }
						</style>
						<div id="J_prismPlayer'.$mid.'" style="width:100%;height:200px;margin-top:10px;margin-bottom:10px"></div>
						<script>
						var videourl="'.$it618_url.'";
						var livetmp="'.$it618_video_media_tie['it618_islive'].'";
						
						if(livetmp==1){
							livetmp = true;
						}else{
							livetmp = false;	
						}
						
						var layout=[
							{
							  "name": "bigPlayButton",
							  "align": "cc"
							},
							{
							  "name": "H5Loading",
							  "align": "cc"
							},
							{
							  "name": "errorDisplay",
							  "align": "tlabs",
							  "x": 0,
							  "y": 0
							},
							{
							  "name": "infoDisplay"
							},
							{
							  "name": "tooltip",
							  "align": "blabs",
							  "x": 0,
							  "y": 56
							},
							{
							  "name": "thumbnail"
							},
							{
							  "name": "controlBar",
							  "align": "blabs",
							  "x": 0,
							  "y": 0,
							  "children": [
								{
								  "name": "progress",
								  "align": "blabs",
								  "x": 0,
								  "y": 44
								},
								{
								  "name": "playButton",
								  "align": "tl",
								  "x": 15,
								  "y": 12
								},
								{
								  "name": "timeDisplay",
								  "align": "tl",
								  "x": 10,
								  "y": 7
								},
								{
								  "name": "fullScreenButton",
								  "align": "tr",
								  "x": 10,
								  "y": 12
								},
								{
								  "name": "setting",
								  "align": "tr",
								  "x": 15,
								  "y": 12
								},
								{
								  "name": "volume",
								  "align": "tr",
								  "x": 5,
								  "y": 10
								}
							  ]
							}
						  ];
						
						player = new Aliplayer({
							"id": "J_prismPlayer'.$mid.'",
							"source": videourl,
							"width": "100%",
							"height": 210,
							"autoplay": '.$autoplay.',
							"isLive": livetmp,
							"rePlay": false,
							"playsinline": true,
							"preload": true,
							"controlBarVisibility": "hover",
							"useH5Prism": true,
							"skinLayout": layout
						  }, function (player) {
						  }
						);
						</script>
						';
					}else{		
						if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php')){
							require DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php';
						}
						
						$isflash=0;
						if(!strpos($_SERVER['HTTP_USER_AGENT'],'WindowsWechat')!==false){
							$agentarr=explode(",",$player_typeagent);
							for($i=0;$i<count($agentarr);$i++){
								$tmparrtmp=explode($agentarr[$i],$it618_url);
								if(count($tmparrtmp)>1){
									$isflash=1;
									break;
								}
							}
						}
						
						$player_version=$it618_video_lang['playerversion'];
							
						$getmediatiestr='
						<link rel="stylesheet" href="https://g.alicdn.com/de/prismplayer/'.$player_version.'/skins/default/aliplayer-min.css" />
						<script type="text/javascript" src="https://g.alicdn.com/de/prismplayer/'.$player_version.'/aliplayer-min.js" charset="utf-8"></script>
						<style type="text/css">
						  .prism-player .prism-cover{
							background-color:none;
							display:block;
						  }
						  
						  .prism-player .prism-marker-text{
							display:none;
						  }
						</style>
						<div id="J_prismPlayer'.$mid.'" style="width:760px;height:430px;margin-top:10px;margin-bottom:10px"></div>
						<script type="text/javascript">
						var playurl="'.$it618_url.'";
						var isflash='.$isflash.';
						var livetmp="'.$it618_video_media_tie['it618_islive'].'";
							
						var Flashtmp=false;
						var H5tmp=true;
						if(isflash==1){
							Flashtmp=true;
							H5tmp=false;
						}
						if(livetmp==1){
							livetmp = true;
							Flashtmp=true;
							H5tmp=false;
						}else{
							livetmp = false;	
						}
						
						var layout=[
						{
						  "name": "bigPlayButton",
						  "align": "cc"
						},
						{
						  "name": "controlBar",
						  "align": "blabs",
						  "x": 0,
						  "y": 0,
						  "children": [
							{
							  "name": "progress",
							  "align": "tlabs",
							  "x": 0,
							  "y": 0
							},
							{
							  "name": "playButton",
							  "align": "tl",
							  "x": 15,
							  "y": 26
							},
							{
							  "name": "nextButton",
							  "align": "tl",
							  "x": 10,
							  "y": 26
							},
							{
							  "name": "timeDisplay",
							  "align": "tl",
							  "x": 10,
							  "y": 24
							},
							{
							  "name": "fullScreenButton",
							  "align": "tr",
							  "x": 10,
							  "y": 25
							},
							{
							  "name": "streamButton",
							  "align": "tr",
							  "x": 10,
							  "y": 23
							},
							{
							  "name": "volume",
							  "align": "tr",
							  "x": 10,
							  "y": 25
							}
						  ]
						},
						{
						  "name": "fullControlBar",
						  "align": "tlabs",
						  "x": 0,
						  "y": 0,
						  "children": [
							{
							  "name": "fullTitle",
							  "align": "tl",
							  "x": 25,
							  "y": 6
							},
							{
							  "name": "fullNormalScreenButton",
							  "align": "tr",
							  "x": 24,
							  "y": 13
							},
							{
							  "name": "fullTimeDisplay",
							  "align": "tr",
							  "x": 10,
							  "y": 12
							},
							{
							  "name": "fullZoom",
							  "align": "cc"
							}
						  ]
						}
					  ];
						
						if(H5tmp==true) layout=[
							{
							  "name": "bigPlayButton",
							  "align": "cc"
							},
							{
							  "name": "H5Loading",
							  "align": "cc"
							},
							{
							  "name": "errorDisplay",
							  "align": "tlabs",
							  "x": 0,
							  "y": 0
							},
							{
							  "name": "infoDisplay"
							},
							{
							  "name": "tooltip",
							  "align": "blabs",
							  "x": 0,
							  "y": 56
							},
							{
							  "name": "thumbnail"
							},
							{
							  "name": "controlBar",
							  "align": "blabs",
							  "x": 0,
							  "y": 0,
							  "children": [
								{
								  "name": "progress",
								  "align": "blabs",
								  "x": 0,
								  "y": 44
								},
								{
								  "name": "playButton",
								  "align": "tl",
								  "x": 15,
								  "y": 12
								},
								{
								  "name": "timeDisplay",
								  "align": "tl",
								  "x": 10,
								  "y": 7
								},
								{
								  "name": "fullScreenButton",
								  "align": "tr",
								  "x": 10,
								  "y": 12
								},
								{
								  "name": "setting",
								  "align": "tr",
								  "x": 15,
								  "y": 12
								},
								{
								  "name": "volume",
								  "align": "tr",
								  "x": 5,
								  "y": 10
								}
							  ]
							}
						  ];
						
						player = new Aliplayer({
							"id": "J_prismPlayer'.$mid.'",
							"source": playurl,
							"width": 760,
							"height": 430,
							"autoplay": '.$autoplay.',
							"isLive": livetmp,
							"rePlay": false,
							"playsinline": true,
							"preload": true,
							"controlBarVisibility": "hover",
							"useFlashPrism": Flashtmp,
							"useH5Prism": H5tmp,
							"skinLayout": layout,
						  }, function (player) {
						  }
						);
						</script>
						';

					}

				}
				
				if($type==1){
					if($isiframe==1)return $getmediatiestr;
					
					return '<div style="width:100%;padding-top:6px;padding-bottom:6px">'.$getmediatiestr.'</div>';
				}else{
					return '<div style="width:100%;padding-top:10px;padding-bottom:10px">'.$it618_video_media_tie['it618_name'].'<br>'.$getmediatiestr.'</div>';
				}
				
			}
		}
		
		return '';
	}
}

class plugin_it618_video extends plugin_it618_video_base{
	function common() {
		$this->common_base();
	}
	
	function post_message($value){
		$this->post_message_base($value);
	}
	
	function global_header(){
		foreach(C::t('#it618_video#it618_video_diy')->fetch_all_by_search() as $it618_video_diy) {
			
			$blockcount=C::t('#it618_video#it618_video_sale')->count_by_name($it618_video_diy["it618_name"]);
			if($blockcount>0){
				if((time()-$it618_video_diy["it618_time"])<(60*$it618_video_diy["it618_catchtime"])){
					continue;
				}else{
					C::t('#it618_video#it618_video_diy')->update_it618_time_by_id(time(),$it618_video_diy["id"]);
				}
			
				require_once DISCUZ_ROOT.'./source/plugin/it618_video/getmode.func.php';
				$content=it618_video_getmodecontent($it618_video_diy['it618_type'],$it618_video_diy['it618_sql'],$it618_video_diy['it618_modecode'],$it618_video_diy['it618_count']);
				C::t('#it618_video#it618_video_sale')->update_summary_dateline_by_name($content,time(),$it618_video_diy["it618_name"]);
			}
		}
		
	}

}

class plugin_it618_video_forum extends plugin_it618_video{
	function viewthread_posttop_output(){
		global $_G,$postlist;
		$it618_video = $_G['cache']['plugin']['it618_video'];
		if($it618_video['video_tiemedia']==0)return;
		
		foreach($postlist as $id => $post) {
			if($it618_video_tie=C::t('#it618_video#it618_video_tie')->fetch_by_pid($post['pid'])){
				$tmpmessagestr=$post['message'];
				$videoids=explode(",",$it618_video_tie['it618_mids']);
				for($i=0;$i<count($videoids);$i++){
					$tmpmessagestr=str_replace("[mid=".$videoids[$i]."]",$this->getmediatie($videoids[$i],0,$post['authorid'],$post['tid']),$tmpmessagestr);
				}
				$post['message']=$tmpmessagestr;
				$postlist[$id] =$post;
			}
		}
		return array();
	}
}

class mobileplugin_it618_video extends plugin_it618_video_base{
	function common() {
		$this->common_base();
	}
	
	function post_message($value){
		$this->post_message_base($value);
	}
}

class mobileplugin_it618_video_forum extends mobileplugin_it618_video{
	function forumdisplay_thread_mobile_output(){
		global $_G;
		$it618_video = $_G['cache']['plugin']['it618_video'];
		if($it618_video['video_tiemedia']!=0){
			$thread_subject=array();
			$threadlist = $_G['forum_threadlist'];
			foreach($threadlist as $id => $thread){
				if($it618_video_tie=C::t('#it618_video#it618_video_tie')->fetch_by_tid_first($thread['tid'])){
					$videoids=explode(",",$it618_video_tie['it618_mids']);
					if(count($videoids)>0){
						$thread['subject']=$thread['subject'].'<div style="width:100%;overflow:hidden" onclick="return false;">'.$this->getmediatie($videoids[0],1,$thread['authorid'],$thread['tid'],1).'</div>';
						$threadlist[$id]=$thread;
					}
				}
			}
			$_G['forum_threadlist']=$threadlist;
		}
		return array();
	}
	
	function viewthread_posttop_mobile_output(){
		global $_G,$postlist;
		$it618_video = $_G['cache']['plugin']['it618_video'];
		if($it618_video['video_tiemedia']==0)return;
		
		foreach($postlist as $id => $post) {
			if($it618_video_tie=C::t('#it618_video#it618_video_tie')->fetch_by_pid($post['pid'])){
				$tmpmessagestr=$post['message'];
				$videoids=explode(",",$it618_video_tie['it618_mids']);
				for($i=0;$i<count($videoids);$i++){
					$tmpmessagestr=str_replace("[mid=".$videoids[$i]."]",$this->getmediatie($videoids[$i],1,$post['authorid'],$post['tid']),$tmpmessagestr);
				}
				$post['message']=$tmpmessagestr;
				$postlist[$id] =$post;
			}
		}
		return array();
	}
}
?>