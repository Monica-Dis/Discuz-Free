<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_video;

$it618_video = $_G['cache']['plugin']['it618_video'];
$metatitle = $it618_video['seotitle'];

if($_GET['playurl']!=''){
	$videoadmin=getcookie('videoadmin');
	if($videoadmin!=1)exit;
	$url=$_GET['playurl'];
	$urlext=pathinfo($url, PATHINFO_EXTENSION);
	$tmparr=explode("?",$urlext);
	$urlext=$tmparr[0];
	$it618_isautoplay='play';
	$_G['mobiletpl'][2]='/';
	include template('it618_video:audiotie');
	exit;
}

require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

if($_GET['mid']>0){
	if($it618_video_media_tie=C::t('#it618_video#it618_video_media_tie')->fetch_by_id($_GET['mid'])){
		$name=it618_video_gbktoutf($it618_video_media_tie['it618_name']);
		$url=it618_video_getsignedurl($it618_video_media_tie['it618_url']);
		$urlext=pathinfo($url, PATHINFO_EXTENSION);
		$tmparr=explode("?",$urlext);
		$urlext=$tmparr[0];
		if($_GET['type']==0){
			if($it618_video_media_tie['it618_isautoplay']==1)$it618_isautoplay='play';
		}
	}else{
		echo $it618_video_lang['s513'];
		exit;
	}
}

if($_GET['mfid']>0){
	if($it618_video_media_iframe=C::t('#it618_video#it618_video_media_iframe')->fetch_by_id($_GET['mfid'])){
		$name=it618_video_gbktoutf($it618_video_media_iframe['it618_name']);
		$url=it618_video_getsignedurl($it618_video_media_iframe['it618_url']);
		$urlext=pathinfo($url, PATHINFO_EXTENSION);
		$tmparr=explode("?",$urlext);
		$urlext=$tmparr[0];
		if($_GET['type']==0){
			if($it618_video_media_iframe['it618_isautoplay']==1)$it618_isautoplay='play';
		}
	}else{
		echo $it618_video_lang['s513'];
		exit;
	}
}

$_G['mobiletpl'][2]='/';
include template('it618_video:audiotie');
?>