<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pagetype='index';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/video_default.func.php';

if(video_is_mobile()){ 
	$tmpurl=it618_video_getrewrite('video_wap','','plugin.php?id=it618_video:wap');
	dheader("location:$tmpurl");
}

$homehotgoods=it618_video_template_pchomehotgoods($templatename,$hotclassgoods[2]);

if($template_set['homegoodscatchtime']>0){
	$cache_file = DISCUZ_ROOT.'./source/plugin/it618_video/cache_pchome_'.$templatename.'.php';
	$str_goods =file_get_contents($cache_file);
}else{
	$str_goods=it618_video_template_pchomeclassgoods($templatename);
}

if($templatename=='edu'||$templatename=='mall'){
	foreach(C::t('#it618_video#it618_video_live')->fetch_all_by_search(
		'it618_chkstate=1 and it618_etime>'.$_G['timestamp'],'it618_btime'
	) as $it618_video_live) {
		
		$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_live['it618_pid']);
		if(!it618_video_issecretok($it618_video_goods)){
			continue;
		}
		
		$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_liveid($it618_video_live['id']);
		$it618_video_goods_lesson=C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($it618_video_live['it618_lid']);
		
		$isuserstr='';
		
		$isgoodsprice=0;
		if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
			$isgoodsprice=1;
		}
		
		if($isgoodsprice==0||$it618_video_goods_video['it618_isuser']==0||$it618_video_goods_video['it618_isuser']==2){
			$isuserstr='<span style="border:#ddd 1px solid; padding:0; height:15px; line-height:15px; display:inline-block; padding-left:2px; padding-right:2px; border-radius:3px;color:#aaa;font-size:12px;vertical-align:middle;margin-top:-1px;float:right">'.$it618_video_lang['s106'].'</span> ';
		}
		
		$csstmp='1';$csstmp1='';
		if($livecontent==''){
			$tmpcontent=it618_video_getlivecontent($it618_video_live['id']);
			$tmparr=explode("it618_split",$tmpcontent);
			$livecontent=$tmparr[0];
			if($tmparr[1]!=''){
				$timestr='serverTime="'.$tmparr[1].'";
			endTime="'.$tmparr[2].'";
			Czgou();
			curliveid='.$it618_video_live['id'].';';
			}
			$csstmp='';
			$csstmp1='style="background-color:#ececec"';
		}
		
		$livestate='';
		if($it618_video_live['it618_btime']>$_G['timestamp']){
			$livestate='<font color=red>'.it618_video_gettime1($it618_video_live['it618_btime']).$it618_video_lang['s1316'].'</font>';
			$imgstr='source/plugin/it618_video/template/edu/images/courseliveimg'.$csstmp.'.png';
		}
		
		if($it618_video_live['it618_btime']<$_G['timestamp']&&$_G['timestamp']<$it618_video_live['it618_etime']){
			$livestate='<font color=#39f>'.$it618_video_lang['s1317'].'</font>';
			$imgstr='source/plugin/it618_video/images/live.gif';
		}

		$livestr.='<li id="'.$it618_video_live['id'].'" '.$csstmp1.'>
						<img src="'.$imgstr.'" width="20" class="liimg" style="vertical-align:middle;margin-top:-3px;">&nbsp;&nbsp;
						'.$isuserstr.''.$it618_video_live['it618_name'].' '.$livestate.'
					</li>';
	}
}

if($template_set['pchometeacher']>0){
	foreach(C::t('#it618_video#it618_video_shop')->fetch_all_by_search(
			'it618_state=2 and it618_htstate=1','it618_order desc,it618_views desc','',0,0,30
		) as $it618_video_shop) {
			
		$tmpurl=it618_video_getrewrite('video_lecturer',$it618_video_shop['id'],'plugin.php?id=it618_video:lecturer&lid='.$it618_video_shop['id']);
		
		$teacherlists.='<div class="swiper-slide">
					<a href="'.$tmpurl.'" target="_blank" class="i-item">
						<div class="i-avatar-box">
							<img src="'.$it618_video_shop['it618_ulogo'].'"/>
						</div>
						<div class="i-text-box" title="'.$it618_video_shop['it618_about'].'">
							<div class="i-name">'.$it618_video_shop['it618_name'].'</div>
							<div class="i-slogan">'.$it618_video_shop['it618_about'].'</div>
						</div>
					</a>
				</div>';
	}
}

require_once DISCUZ_ROOT.'./source/plugin/it618_video/it618_api.func.php';
$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename.'/video_default');
?>