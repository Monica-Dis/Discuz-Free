<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$ppp = 15;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

if($_GET['type']=='video'){
	$urlsql='&type='.$_GET['type'].'&key='.$_GET['key'].'&class_id='.$_GET['class_id'];
	
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_media_class')." where it618_shopid=$ShopId ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	
	$tmp1=str_replace('<option value='.$_GET['class_id'].'>','<option value='.$_GET['class_id'].' selected="selected">',$tmp);
	
	it618_showformheader("plugin.php?id=it618_video:sc_media_select$adminsid&page=$page".$urlsql);
	showtableheaders('','it618_video_sum');
	
		echo '<tr><td colspan=14>'.it618_video_getlang('s97').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:300px" /> '.it618_video_getlang('s848').' <select name="class_id"><option value=0>'.it618_video_getlang('s102').'</option>'.$tmp1.'</select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_video_getlang('s350').'" /></td></tr>';
		
		$count = C::t('#it618_video#it618_video_media')->count_by_search('it618_chkstate=1','',$ShopId,$_GET['class_id'],$_GET['key']);
		$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_video:sc_media_select$adminsid".$urlsql);
		
		$sumsize = C::t('#it618_video#it618_video_media')->sum_size_by_search('it618_chkstate=1','',$ShopId,$_GET['class_id'],$_GET['key']);
		$summtscount = C::t('#it618_video#it618_video_media')->sum_mtscount_by_search('it618_chkstate=1','',$ShopId,$_GET['class_id'],$_GET['key']);
		$summtssize = C::t('#it618_video#it618_video_media')->sum_mtssize_by_search('it618_chkstate=1','',$ShopId,$_GET['class_id'],$_GET['key']);
		
		echo '<tr><td colspan=14>'.it618_video_getlang('s850').$count.' '.$it618_video_lang['s583'].round((($sumsize+$summtssize)/1024/1024),2).'M '.$it618_video_lang['s584'].round(($sumsize/1024/1024),2).'M '.$it618_video_lang['s585'].$summtscount.' '.$it618_video_lang['s586'].round(($summtssize/1024/1024),2).'M</td></tr>';
		
		if($multipage!='')echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'<input type=hidden value='.$page.' name=page /></div><br></td></tr>';
		
		$n=1;
		foreach(C::t('#it618_video#it618_video_media')->fetch_all_by_search(
			'it618_chkstate=1','it618_time desc',$ShopId,$_GET['class_id'],$_GET['key'],$startlimit,$ppp
		) as $it618_video_media) {
			
			$mtsstr='';
			if($it618_video_media['it618_mtscount']>0){
				$query = DB::query("SELECT * FROM ".DB::table('it618_video_media_mts')." where it618_media_id=".$it618_video_media['id']." ORDER BY it618_size");
				while($it618_video_media_mts =	DB::fetch($query)) {
					
					$tmparr=it618_video_getvideotimearr($it618_video_media_mts['it618_duration']);
					
					$mtsstr.='
					<li>
					<a href="javascript:" onclick="selectmts('.$it618_video_media_mts['id'].')" style="float:right;background-color:#0AF;color:#fff;height:15px;line-height:15px;padding:1px;padding-left:6px;padding-right:5px;padding-bottom:2px;font-size:12px">'.$it618_video_lang['s1767'].'</a><font color=green><b>'.$it618_video_media_mts['it618_actname'].'</b></font> <font color=#999>'.$it618_video_lang['s1685'].'</font>'.it618_video_getvideotime($it618_video_media_mts['it618_duration']).' <font color=#999>'.$it618_video_lang['s1686'].'</font>'.round(($it618_video_media_mts['it618_size']/1024/1024),2).'MB <font color=#999>'.$it618_video_lang['s1687'].'</font>'.$it618_video_media_mts['it618_fps'].'FPS <font color=#999>'.$it618_video_lang['s1688'].'</font>'.$it618_video_media_mts['it618_bitrate'].'Kbps <font color=#999>'.$it618_video_lang['s1689'].'</font>'.$it618_video_media_mts['it618_width'].'x'.$it618_video_media_mts['it618_height'].'px
					<input type="hidden" id="name'.$it618_video_media_mts['id'].'" value="'.$it618_video_media['it618_name'].'">
					<input type="hidden" id="videourl'.$it618_video_media_mts['id'].'" value="'.$it618_video_media_mts['it618_url'].'">
					<input type="hidden" id="time1'.$it618_video_media_mts['id'].'" value="'.$tmparr[0].'">
					<input type="hidden" id="time2'.$it618_video_media_mts['id'].'" value="'.$tmparr[1].'">
					<input type="hidden" id="time3'.$it618_video_media_mts['id'].'" value="'.$tmparr[2].'">
					</li>';
				}
			}
			
			echo '<tr><td width=135><img src="'.it618_video_cdnkeyurl($it618_video_media['it618_coverurl']).'" width="133" height="80"/></td><td colspan=14 style="vertical-align:top"><span style="font-size:13px">'.$it618_video_media['it618_name'].'</span><br><ul class="ulmts">'.$mtsstr.'</ul></td></tr>';
		}
		
	if($multipage!='')echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'<input type=hidden value='.$page.' name=page /></div><br></td></tr>';
	
	echo '<tr><td colspan=14 style="height:15px"></td></tr>';
	
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	
	echo '<style>
	.ulmts li{width:668px;padding-bottom:6px; padding-top:6px}
	</style>
	
	<script>
	function selectmts(id){
		if(parent.document.getElementById("name"+parent.vid).value==""){
			parent.document.getElementById("name"+parent.vid).value=document.getElementById("name"+id).value;
		}
		parent.document.getElementById("videourl"+parent.vid).value=document.getElementById("videourl"+id).value;
		parent.document.getElementById("time1"+parent.vid).value=document.getElementById("time1"+id).value;
		parent.document.getElementById("time2"+parent.vid).value=document.getElementById("time2"+id).value;
		parent.document.getElementById("time3"+parent.vid).value=document.getElementById("time3"+id).value;
		parent.dialog_media.remove();
	}
	</script>
	';
}else{
	$osstype=0;$typecss='style="display:"';
	if($_GET['type']=='video1')$osstype=1;
	if($_GET['type']=='attach'){$osstype=2;$typecss='style="display:none"';}
	
	$urlsql='&type='.$_GET['type'].'&key='.$_GET['key'].'&class_id='.$_GET['class_id'];
	
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_media_aclass')." where it618_shopid=$ShopId and it618_osstype=$osstype ORDER BY it618_order");
	while($it618_tmp =	DB::fetch($query1)) {
		$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
	
	$tmp1=str_replace('<option value='.$_GET['class_id'].'>','<option value='.$_GET['class_id'].' selected="selected">',$tmp);
	
	it618_showformheader("plugin.php?id=it618_video:sc_media_select$adminsid&page=$page".$urlsql);
	showtableheaders('','it618_video_sum');
	
		echo '<tr><td colspan=14>'.it618_video_getlang('s97').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:300px" /> '.it618_video_getlang('s848').' <select name="class_id"><option value=0>'.it618_video_getlang('s102').'</option>'.$tmp1.'</select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_video_getlang('s350').'" /></td></tr>';
		
		$count = C::t('#it618_video#it618_video_media_audio')->count_by_search('it618_chkstate=1 and it618_osstype='.$osstype,'',$ShopId,$_GET['class_id'],$_GET['key']);
		$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_video:sc_media_select$adminsid".$urlsql);
		
		$sumsize = C::t('#it618_video#it618_video_media_audio')->sum_size_by_search('it618_chkstate=1 and it618_osstype='.$osstype,'',$ShopId,$_GET['class_id'],$_GET['key']);
		
		echo '<tr><td colspan=14>'.it618_video_getlang('s850').$count.' '.$it618_video_lang['s235'].round(($sumsize/1024/1024),2).'M</td></tr>';
		
		if($multipage!='')echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'<input type=hidden value='.$page.' name=page /></div><br></td></tr>';
		
		$n=1;
		foreach(C::t('#it618_video#it618_video_media_audio')->fetch_all_by_search(
			'it618_chkstate=1 and it618_osstype='.$osstype,'it618_time desc',$ShopId,$_GET['class_id'],$_GET['key'],$startlimit,$ppp
		) as $it618_video_media_audio) {

			echo '<tr><td>'.$it618_video_media_audio['it618_name'].'</td><td colspan=14><a href="javascript:" onclick="selectmts('.$it618_video_media_audio['id'].')" style="float:right;background-color:#0AF;color:#fff;height:15px;line-height:15px;padding:1px;padding-left:6px;padding-right:5px;padding-bottom:2px;font-size:12px">'.$it618_video_lang['s1767'].'</a><span '.$typecss.'>'.$it618_video_lang['s399'].$it618_video_media_audio['it618_time1'].$it618_video_lang['s397'].$it618_video_media_audio['it618_time2'].$it618_video_lang['s398'].$it618_video_media_audio['it618_time3'].$it618_video_lang['s400'].' </span>'.$it618_video_media_audio['it618_ext'].' '.round(($it618_video_media_audio['it618_size']/1024/1024),2).'MB <input type="hidden" id="name'.$it618_video_media_audio['id'].'" value="'.$it618_video_media_audio['it618_name'].'"><input type="hidden" id="videourl'.$it618_video_media_audio['id'].'" value="'.$it618_video_media_audio['it618_url'].'"><input type="hidden" id="time1'.$it618_video_media_audio['id'].'" value="'.$it618_video_media_audio['it618_time1'].'"><input type="hidden" id="time2'.$it618_video_media_audio['id'].'" value="'.$it618_video_media_audio['it618_time2'].'"><input type="hidden" id="time3'.$it618_video_media_audio['id'].'" value="'.$it618_video_media_audio['it618_time3'].'"><input type="hidden" id="size'.$it618_video_media_audio['id'].'" value="'.round(($it618_video_media_audio['it618_size']/1024/1024),2).'MB"></td></tr>';
			
		}
		
	if($multipage!='')echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'<input type=hidden value='.$page.' name=page /></div><br></td></tr>';
	
	echo '<tr><td colspan=14 style="height:15px"></td></tr>';
	
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	
	if($_GET['type']=='attach'){
		echo '<style>
		.ulmts li{width:668px;padding-bottom:6px; padding-top:6px}
		</style>
		
		<script>
		function selectmts(id){
			if(parent.document.getElementById("name"+parent.vid).value==""){
				parent.document.getElementById("name"+parent.vid).value=document.getElementById("name"+id).value;
			}
			parent.document.getElementById("videourl"+parent.vid).value=document.getElementById("videourl"+id).value;
			parent.document.getElementById("size"+parent.vid).value=document.getElementById("size"+id).value;
			parent.dialog_media.remove();
		}
		</script>
		';
	}else{
		echo '<style>
		.ulmts li{width:668px;padding-bottom:6px; padding-top:6px}
		</style>
		
		<script>
		function selectmts(id){
			if(parent.document.getElementById("name"+parent.vid).value==""){
				parent.document.getElementById("name"+parent.vid).value=document.getElementById("name"+id).value;
			}
			parent.document.getElementById("videourl"+parent.vid).value=document.getElementById("videourl"+id).value;
			parent.document.getElementById("time1"+parent.vid).value=document.getElementById("time1"+id).value;
			parent.document.getElementById("time2"+parent.vid).value=document.getElementById("time2"+id).value;
			parent.document.getElementById("time3"+parent.vid).value=document.getElementById("time3"+id).value;
			parent.dialog_media.remove();
		}
		</script>
		';
	}
}

require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>