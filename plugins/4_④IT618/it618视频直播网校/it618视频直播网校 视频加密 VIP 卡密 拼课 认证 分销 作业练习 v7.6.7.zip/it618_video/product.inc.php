<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pagetype='product';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/video_default.func.php';

$pid=intval($_GET['pid']);

if(isset($_GET['chaturl'])&&$IsChat==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_chat/chat.func.php';
	echo it618_chat_getchaturl('it618_video','product',$pid);
	exit;
}

if(video_is_mobile()){ 
	if(isset($_GET['tuiuid'])){
		$urltmp='tuiuid='.$_GET['tuiuid'];
	}
	if(isset($_GET['e'])){
		if($urltmp!='')$urltmp.='&e='.$_GET['e'];else $urltmp.='e='.$_GET['e'];
	}
	
	if($urltmp!=''){
		$tmpurl=it618_video_getrewrite('video_wap','product@'.$pid,'plugin.php?id=it618_video:wap&pagetype=product&cid='.$pid.'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=it618_video_getrewrite('video_wap','product@'.$pid,'plugin.php?id=it618_video:wap&pagetype=product&cid='.$pid);
	}

	dheader("location:$tmpurl");
}



$homeurl=it618_video_getrewrite('video_home','','plugin.php?id=it618_video:index');
if($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid)){
	$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
	if($it618_video_shop['it618_state']!=2||$it618_video_shop['it618_htstate']!=1){
		echo it618_video_getlang('s470').' <a href="'.$homeurl.'">'.$it618_video_lang['s18'].'</a>';exit;
	}
	if($it618_video_shop['it618_uid']==$_G['uid']){
		$isshop=1;
		if($it618_video_goods['it618_state']==0){
			$tmppname=$it618_video_lang['s1842'];
		}
	}
}

if($isshop!=1){
	if(!($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id_state($pid,1))){
		echo it618_video_getlang('s470').' <a href="'.$homeurl.'">'.$it618_video_lang['s18'].'</a>';exit;
	}else{
		if(!it618_video_issecretok($it618_video_goods)){
			echo it618_video_getlang('s470').' <a href="'.$homeurl.'">'.$it618_video_lang['s18'].'</a>';exit;
		}
	}
}

if($it618_video_shop['it618_ulogo']==''){
	C::t('#it618_video#it618_video_shop')->update($it618_video_shop['id'],array(
		'it618_ulogo' => '/source/plugin/it618_video/images/man.jpg',
	));
}

$footer.='<div style="display:none">'.$it618_video_shop['it618_tongji'].'</div>';

$lecturerurl=it618_video_getrewrite('video_lecturer',$it618_video_shop['id'],'plugin.php?id=it618_video:lecturer&lid='.$it618_video_shop['id']);

if($templatename=='mall'){
	$adlogo='<img src="'.$it618_video_shop['it618_logo'].'" width="348" style="max-height:268px"/>';
}

if($templatename=='edu'){
	$adlogo='<img src="'.$it618_video_shop['it618_logo'].'" width="280" style="margin-top:3px"/>';
}

if($it618_video_shop['it618_logourl']!=''){
	$adlogo='<a href="'.$it618_video_shop['it618_logourl'].'" target="_blank">'.$adlogo.'</a>';
}

$productnav='<a href="'.$homeurl.'">'.$metatitle.'</a><i></i>'.$it618_video_goods['it618_name'];

$class1=$it618_video_goods['it618_class1_id'];
$class2=$it618_video_goods['it618_class2_id'];
$class1name=C::t('#it618_video#it618_video_class1')->fetch_it618_name_by_id($class1);
$class2name=C::t('#it618_video#it618_video_class2')->fetch_it618_name_by_id($class2);

$classurl1=it618_video_getrewrite('video_list',$class1,'plugin.php?id=it618_video:list&class1='.$class1);
$classurl2=it618_video_getrewrite('video_list',$class1.'@'.$class2,'plugin.php?id=it618_video:list&class1='.$class1.'&class2='.$class2);

if(isset($_GET['e'])){
	$goodsurl=it618_video_getrewrite('video_product',$pid,'plugin.php?id=it618_video:product&pid='.$pid.'&e='.$_GET['e'],'?e='.$_GET['e']);
}else{
	$goodsurl=it618_video_getrewrite('video_product',$pid,'plugin.php?id=it618_video:product&pid='.$pid);
}

if(C::t('#it618_video#it618_video_shop_subscribe')->count_by_shopid_uid($it618_video_shop['id'],$_G['uid'])>0){
	$subscribetitle=$it618_video_lang['s1397'];
}else{
	$subscribetitle=$it618_video_lang['s1396'];
}

$shopsubscribes=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_shop_subscribe')." WHERE it618_shopid=".$it618_video_shop['id']);
$shopviews=DB::result_first("SELECT SUM(it618_views) FROM ".DB::table('it618_video_goods')." WHERE it618_shopid=".$it618_video_shop['id']);

C::t('#it618_video#it618_video_goods')->update_it618_views_by_id($pid);

$isgoodsprice=0;
if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
	$goodspricestr=it618_video_getgoodsprice($it618_video_goods,'goods_price');
	$isgoodsprice=1;
}

if($it618_video_shop['it618_issale']==0){
	$isgoodsprice=1;
}

if($_G['uid']>0&&$isgoodsprice==1){
	$goodssaleok['state']=0;
	if($it618_video_goods_time=C::t('#it618_video#it618_video_goods_time')->fetch_by_uid_pid_lid_vid($_G['uid'],$pid,0,0)){
		if($it618_video_goods_time['it618_etime']==0){
			$goodssaleok['state']=1;
			$goodssaleok['time']=$_G['username'].' '.$it618_video_lang['s1154'];
		}
	}
}

$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
if(count($vipgroupids)>0){
	if($_G['uid']>0){
		$tmpgrouparr=it618_video_getisvipuser($vipgroupids);
		$isvipuser=count($tmpgrouparr[0]);
	}

	if($isvipuser>0){
		$isvipok=1;
	}
	$it618_isvipstr='<div id="vippaybtn"></div><img src="source/plugin/it618_video/template/mall_wap/images/vip.png" style="height:13px;vertical-align:middle;margin-right:3px;margin-top:0px"> <a href="javascript:" class="showvipgroupbtn" title="'.$it618_video_lang['s17'].'" style="float:right;margin-top:-2px"><font color=#f30 style="font-size:13px">'.$it618_video_lang['s926'].'</font></a>';
}

//$goodspic=it618_video_getgoodspic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig'],0);
$goodspic=$it618_video_goods['it618_picbig'];
$tjgoodstmp=it618_video_template_pcpagetjgoods($templatename,$it618_video_goods['it618_shopid']);
$tjgoodstmp=explode("it618_split",$tjgoodstmp);
$tjgoods=$tjgoodstmp[0];
$roundgoods=$tjgoodstmp[1];

$it618_description=cutstr($it618_video_goods['it618_description'],280,'...');
if($it618_description!=$it618_video_goods['it618_description']){
	$it618_descriptiontitle=' title="'.$it618_video_goods['it618_description'].'"';
}

$ShopId=$it618_video_shop['id'];
$goodscount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods')." WHERE it618_shopid=$ShopId and it618_state=1");
$playpjcount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_play_pj')." WHERE it618_score1>0 and it618_shopid=$ShopId");
$playcount=DB::result_first("SELECT SUM(it618_plays) FROM ".DB::table('it618_video_goods')." WHERE it618_shopid=$ShopId");

if($_G['uid']>0){
	if($it618_video_play_pj=C::t('#it618_video#it618_video_play_pj')->fetch_by_pid_uid($it618_video_goods['id'],$_G['uid'])){
		if($it618_video_play_pj['it618_score1']==0){
			$pjtype='goodpj';
			$upjstr='<span style="float:right; height:30px; line-height:30px; background-color:'.$it618_video_style['it618_color1'].'; color:#fff; border-radius:3px; padding:0 10px; margin-top:-4px; cursor:pointer; font-size:13px" id="spanpj" onclick="goodsplaypj('.$it618_video_play_pj['id'].',\''.$pjtype.'\')">'.$it618_video_lang['s500'].'</span>';
		}else{
			$upjstr='<span style="float:right; height:30px; line-height:30px; font-size:12px; margin-top:-4px;color:'.$it618_video_style['it618_color1'].'">'.$it618_video_lang['s728'].'</span>';
		}
	}
}

if($isgoodsprice==1&&$it618_video_shop['it618_issale']==1&&$template_set['ispcsale']==1){
	$salecount = C::t('#it618_video#it618_video_sale')->sumcount_by_it618_pid1($pid);
}

$pjcount=C::t('#it618_video#it618_video_play_pj')->countpj_by_pid($it618_video_goods['id']);
if($pjcount>0){
	$pjname=C::t('#it618_video#it618_video_class1')->fetch_it618_pj_by_id($it618_video_goods['it618_class1_id']);
	$pjname=explode("_",$pjname);
	
	$pjscore=C::t('#it618_video#it618_video_play_pj')->fetch_sumpjscore_by_pid($it618_video_goods['id']);
	$pjavgscore1=sprintf( "%.1f",$pjscore['score1']/$pjcount);
	$pjavgscore2=sprintf( "%.1f",$pjscore['score2']/$pjcount);
	$pjavgscore3=sprintf( "%.1f",$pjscore['score3']/$pjcount);
	$pjavgscore4=sprintf( "%.1f",$pjscore['score4']/$pjcount);
	$pjpl1=sprintf( "%.1f",$pjavgscore1/5*100);
	$pjpl2=sprintf( "%.1f",$pjavgscore2/5*100);
	$pjpl3=sprintf( "%.1f",$pjavgscore3/5*100);
	$pjpl4=sprintf( "%.1f",$pjavgscore4/5*100);
	
	$pj1_count1=C::t('#it618_video#it618_video_play_pj')->countpj1_by_pid_score($it618_video_goods['id'],1);
	$pj1_count2=C::t('#it618_video#it618_video_play_pj')->countpj1_by_pid_score($it618_video_goods['id'],2);
	$pj1_count3=C::t('#it618_video#it618_video_play_pj')->countpj1_by_pid_score($it618_video_goods['id'],3);
	$pj1_count4=C::t('#it618_video#it618_video_play_pj')->countpj1_by_pid_score($it618_video_goods['id'],4);
	$pj1_count5=C::t('#it618_video#it618_video_play_pj')->countpj1_by_pid_score($it618_video_goods['id'],5);
	
	$mydpl=intval(($pj1_count4+$pj1_count5)/$pjcount*100);
	
	$pj1_pl1=intval($pj1_count1/$pjcount*100);
	$pj1_pl2=intval($pj1_count2/$pjcount*100);
	$pj1_pl3=intval($pj1_count3/$pjcount*100);
	$pj1_pl4=intval($pj1_count4/$pjcount*100);
	$pj1_pl5=intval($pj1_count5/$pjcount*100);
	
	$it618_pjpfstr=$pjcount.' '.it618_video_getlang('s482').' '.$pjavgscore1.' '.it618_video_getlang('s483').':'.$mydpl.'% ';
}else{
	$it618_pjpfstr=it618_video_getlang('s484').' ';	
}

DB::query("UPDATE ".DB::table('it618_video_goods')." SET it618_pjpfstr='".$it618_pjpfstr."' WHERE id=$pid");

$timeflag=0;$isxgok=0;
if($it618_video_goods['it618_xgtype']==0)$isxgok=1;

if($it618_video_goods['it618_xgtype']==1){
	$timestr=$it618_video_goods['it618_xgtime1'].' - '.$it618_video_goods['it618_xgtime2'];
	
	$timetmp1=explode(" ",$it618_video_goods['it618_xgtime1']);
	$timetmp2=explode(" ",$it618_video_goods['it618_xgtime2']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);
	
	
	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
	
	$timeflag=1;
	if($etime<$_G['timestamp']){
		$timeflag=0;
		$timetip=it618_video_getlang('s952');
	}else{
		if($btime>$_G['timestamp']){
			$timetip=it618_video_getlang('s953');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_video_goods['it618_xgtime1'];
		}else{
			$timetip=it618_video_getlang('s954');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_video_goods['it618_xgtime2'];
			$isxgok=1;
		}
	}
	
	$isxg=1;
}

if($it618_video_goods['it618_xgtype']==2){
	$timetmp1=explode(" ",$it618_video_goods['it618_xgtime1']);
	$timetmp2=explode(" ",$it618_video_goods['it618_xgtime2']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);
	
	$timestr=$timetmp1[0].' - '.$timetmp2[0].' '.it618_video_getlang('s955').' '.$timetmp1[1].' - '.$timetmp2[1];
	
	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
	
	$timeflag=1;
	if($etime<$_G['timestamp']){
		$timeflag=0;
		$timetip=it618_video_getlang('s952');
		
	}else{
		if($btime>$_G['timestamp']){
			$timetip=it618_video_getlang('s953');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_video_goods['it618_xgtime1'];
		}else{
			$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
			$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
			$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
			
			if($btimecur>$_G['timestamp']){
				$timetip=it618_video_getlang('s953');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $btimecur);
			}
			
			if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
				$timetip=it618_video_getlang('s954');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $etimecur);
				$isxgok=1;
			}
			
			if($etimecur<$_G['timestamp']){
				$timetip=it618_video_getlang('s953');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $btimecur1);
			}
		}
	}
	
	$isxg=1;
}

$n=1;$ln=1;$vn=1;$lessonurlhref='';
$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_lesson')." WHERE it618_pid=".$pid." ORDER BY it618_order");
while($it618_video_goods_lesson = DB::fetch($query)) {
	
	if($it618_video_goods_lesson['it618_issale']==1&&$isgoodsprice==1){
		$lessonpricestr=it618_video_getgoodsprice($it618_video_goods_lesson,'goods_lesson_price');
		$delpricestr='';
		if($it618_video_goods_lesson['it618_price']>0){
			$delpricestr='<del>&yen;'.$it618_video_goods_lesson['it618_price'].'</del>';
		}
		
		$lessonpricestr='<br><span class="spanlessonprice" onclick="showpay('.$it618_video_goods_lesson['it618_pid'].','.$it618_video_goods_lesson['id'].',0)"><span>'.$lessonpricestr.' '.$delpricestr.' <font color="#999" style="font-size:12px">'.$it618_video_lang['s1869'].'</font></span></span>';
		
	}else{
		$lessonpricestr='';
	}
	
	if($it618_video_goods['it618_lessoncount']>1||$lessonpricestr!=''){
		if($it618_video_goods_lesson['it618_type']==1){
			if($templatename=='mall'){
				$videostr.='<tr>
							<td style="color:#666;font-size:15px">
							<b>'.$it618_video_goods_lesson['it618_name'].'</b> <font color=#999 style="font-size:12px">'.it618_video_getvideocounttime($it618_video_goods_lesson['it618_videocount'],$it618_video_goods_lesson['it618_videotime'],1).'</font>
							'.$lessonpricestr.'
							</td>
						</tr>';
			}
			
			if($templatename=='edu'){
				$videostr.='<div class="course-name">
									<p onclick="getcourse('.$ln.')"><img src="source/plugin/it618_video/template/edu/images/li0.png" style="width:15px;margin-right:8px;margin-left:-3px;" id="liimg'.$ln.'">'.$it618_video_goods_lesson['it618_name'].' <span>'.it618_video_getvideocounttime($it618_video_goods_lesson['it618_videocount'],$it618_video_goods_lesson['it618_videotime'],1).'</span></p>
									'.$lessonpricestr.'
									<div class="course" id="course'.$ln.'">';
									
				$datastr1='<div class="course-name">
									<p onclick="getcoursedata('.$ln.')"><img src="source/plugin/it618_video/template/edu/images/li0.png" style="width:15px;margin-right:8px;margin-left:-3px" id="lidataimg'.$ln.'">'.$it618_video_goods_lesson['it618_name'].'</p>
									<div class="course" id="coursedata'.$ln.'">';
			}
		}else{
			if($templatename=='mall'){
				$videostr.='<tr>
							<td style="color:#666;font-size:15px">
							<b><a href="'.$it618_video_goods_lesson['it618_url'].'" target="_blank"><font color=#666>'.$it618_video_goods_lesson['it618_name'].'</font></a></b> <font color=#999 style="font-size:12px">'.$it618_video_lang['s791'].'</font>
							</td>
						</tr>';
			}
			
			if($templatename=='edu'){
				$videostr.='<div class="course-name">
									<p><img src="source/plugin/it618_video/images/link.png" style="width:16px;margin-right:8px;margin-left:-3px;"><a href="'.$it618_video_goods_lesson['it618_url'].'" target="_blank" style="font-size:18px">'.$it618_video_goods_lesson['it618_name'].'</a> <span>'.$it618_video_lang['s791'].'</span></p></div>';
			}
		}
	}else{
		if($templatename=='edu'){
			$videostr.='<div class="course-name">
								<div class="course">';
								
			$datastr1='<div class="course-name">
								<div class="course">';
		}
	}
	
	if($it618_video_goods_lesson['it618_type']==1){
		$datastr2='';$datastr3='';
		$vn=1;
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_goods_video')." WHERE it618_lid=".$it618_video_goods_lesson['id']." and it618_ison=1 ORDER BY it618_order,id");
		while($it618_video_goods_video = DB::fetch($query1)) {
			
			$videopowertmp=it618_video_getpower($_G['uid'],$it618_video_goods_video['it618_pid'],$it618_video_goods_video['it618_lid'],$it618_video_goods_video['id']);
			
			$lessonurl=it618_video_getrewrite('video_lesson',$it618_video_goods_video['id'],'plugin.php?id=it618_video:lesson&lid='.$it618_video_goods_video['id']);
			
			$isuserstr='';$videopricestr='';
			
			if($it618_video_goods_video['it618_issale']==1&&$it618_video_goods_video['it618_isuser']==1&&$isgoodsprice==1){
				$videopricestr=it618_video_getgoodsprice($it618_video_goods_video,'goods_video_price');
				$delpricestr='';
				if($it618_video_goods_video['it618_price']>0){
					$delpricestr='<del>&yen;'.$it618_video_goods_video['it618_price'].'</del>';
				}
				
				$videopricestr='<span class="spanvideoprice" style="floatmarginright" onclick="showpay('.$it618_video_goods_video['it618_pid'].','.$it618_video_goods_video['it618_lid'].','.$it618_video_goods_video['id'].')"><span>'.$videopricestr.' '.$delpricestr.' <font color="#999" style="font-size:12px">'.$it618_video_lang['s1869'].'</font></span></span>';
				
			}
			
			if($it618_video_goods_video['it618_liveid']>0){
				$it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
				
				$livestate='';
				if($it618_video_live['it618_btime']>$_G['timestamp']){
					$livestate='<font color=red>'.it618_video_gettime1($it618_video_live['it618_btime']).$it618_video_lang['s1316'].'</font>';
					$imgstr='source/plugin/it618_video/template/edu/images/courseliveimg1.png';
				}
				
				if($it618_video_live['it618_btime']<$_G['timestamp']&&$_G['timestamp']<$it618_video_live['it618_etime']){
					$livestate='<font color=#23b8ff>'.$it618_video_lang['s1317'].'</font>';
					$imgstr='source/plugin/it618_video/images/live.gif';
				}
				
				if($livestate=='')continue;
				if($it618_video_goods['it618_isprotect']==1&&$_G['uid']!=$it618_video_shop['it618_uid']&&$it618_video_goods_video['it618_isuser']==1){
					if(it618_video_isprotect($isgoodsprice,$videopowertmp,$isvipuser))continue;
				}
				if($lessonurlhref=='')$lessonurlhref=$lessonurl;
				
				$despcss='display:none';$floatmarginright='margin-right:23px';
				if($it618_video_live['it618_description']!=''){
					$despcss='';
					$floatmarginright='margin-right:8px';
				}
				
				if($templatename=='mall'){
					if($isgoodsprice==0||$it618_video_goods_video['it618_isuser']==0||$it618_video_goods_video['it618_isuser']==2){
						if($it618_video_goods_video['it618_usercode']!=''){
							$tmpuserstr=$it618_video_lang['s1976'];
						}else{
							$tmpuserstr=$it618_video_lang['s106'];
						}
						$isuserstr='<span style="border:#ddd 1px solid; padding:0; height:15px; line-height:15px; display:inline-block; padding-left:2px; padding-right:2px; border-radius:3px;color:#aaa;font-size:12px;vertical-align:middle;margin-top:-1px;float:right;'.$floatmarginright.'">'.$tmpuserstr.'</span> ';
					}
					
					$videostr.='<tr>
								<td>
								<a href="'.$lessonurl.'" class="videotdbtn" target="_blank">'.$it618_video_live['it618_name'].'</a> '.$livestate.'<span class="videotdtime"><a href="javascript:" style="'.$despcss.'" onclick="getdesp('.$n.',this)">'.$it618_video_lang['s390'].'</a></span>'.$isuserstr.'
								'.$videopricestr.'
								<p id="desp'.$n.'" style="display:none;line-height:23px;font-size:14px">'.$it618_video_live['it618_description'].'</p>
								</td>
							</tr>';
				}
				
				if($templatename=='edu'){
					if($isgoodsprice==0||$it618_video_goods_video['it618_isuser']==0||$it618_video_goods_video['it618_isuser']==2){
						if($it618_video_goods_video['it618_usercode']!=''){
							$tmpuserstr=$it618_video_lang['s1976'];
						}else{
							$tmpuserstr=$it618_video_lang['s106'];
						}
						$isuserstr='<span style="border:#ddd 1px solid; padding:0; height:15px; line-height:15px; display:inline-block; padding-left:2px; padding-right:2px; border-radius:3px;color:#aaa;font-size:12px;vertical-align:middle;margin-top:-1px;float:right;'.$floatmarginright.'">'.$tmpuserstr.'</span> ';
					}
					
					$videostr.='<li>
									<span style="float:right;'.$despcss.'" onclick="getdesp('.$n.')">
									<img src="source/plugin/it618_video/template/edu/images/dec0.png" id="decimg'.$n.'" style="cursor:pointer">
									</span>
									<img src="'.$imgstr.'" width="20" class="liimg">&nbsp;&nbsp;
									'.$isuserstr.' <a href="'.$lessonurl.'" target="_blank">'.$it618_video_live['it618_name'].'</a> '.$livestate.'
									'.$videopricestr.'
									<div id="desp'.$n.'" style="display:none;line-height:23px;font-size:14px">'.$it618_video_live['it618_description'].'</div
								</li>';
				}
				
			}else{
				if($it618_video_goods['it618_isprotect']==1&&$_G['uid']!=$it618_video_shop['it618_uid']&&$it618_video_goods_video['it618_isuser']==1){
					if(it618_video_isprotect($isgoodsprice,$videopowertmp,$isvipuser))continue;
				}
				if($lessonurlhref=='')$lessonurlhref=$lessonurl;
				
				$despcss='display:none';$floatmarginright='margin-right:23px';
				if($it618_video_goods_video['it618_description']!=''){
					$despcss='';
					$floatmarginright='margin-right:8px';
				}
				
				if($templatename=='mall'){
					if($isgoodsprice==0||$it618_video_goods_video['it618_isuser']==0||$it618_video_goods_video['it618_isuser']==2){
						if($it618_video_goods_video['it618_usercode']!=''){
							$tmpuserstr=$it618_video_lang['s1976'];
						}else{
							$tmpuserstr=$it618_video_lang['s106'];
						}
						$isuserstr='<span style="border:#ddd 1px solid; padding:0; height:15px; line-height:15px; display:inline-block; padding-left:2px; padding-right:2px; border-radius:3px;color:#aaa;font-size:12px;vertical-align:middle;margin-top:-1px;float:right;'.$floatmarginright.'">'.$tmpuserstr.'</span> ';
					}
					
					$previewtimestr='';
					if($it618_video_goods_video['it618_previewtime']>0){
						$previewtimestr='<span style="border:#ddd 1px solid; padding:0; height:15px; line-height:15px; display:inline-block; padding-left:2px; padding-right:2px; border-radius:3px;color:#aaa;font-size:12px;vertical-align:middle;margin-top:-1px;float:right;'.$floatmarginright.'">'.$it618_video_lang['s1713'].'</span> ';
					}
					
					$videostr.='<tr>
								<td>
								<a href="'.$lessonurl.'" class="videotdbtn" target="_blank">'.$it618_video_goods_video['it618_name'].'</a> <span style="font-size:13px;color:#999"> ('.it618_video_getvideotimestr($it618_video_goods_video).')</span><span class="videotdtime"><a href="javascript:" onclick="getdesp('.$n.',this)" style="'.$despcss.'">'.$it618_video_lang['s390'].'</a></span>'.$isuserstr.$previewtimestr.'
								'.$videopricestr.'
								<p id="desp'.$n.'" style="display:none;line-height:23px;font-size:14px">'.$it618_video_goods_video['it618_description'].'</p>
								</td>
							</tr>';
				}
				
				if($templatename=='edu'){
					if($isgoodsprice==0||$it618_video_goods_video['it618_isuser']==0||$it618_video_goods_video['it618_isuser']==2){
						if($it618_video_goods_video['it618_usercode']!=''){
							$tmpuserstr=$it618_video_lang['s1976'];
						}else{
							$tmpuserstr=$it618_video_lang['s106'];
						}
						$isuserstr='<span style="border:#ddd 1px solid; padding:0; height:15px; line-height:15px; display:inline-block; padding-left:2px; padding-right:2px; border-radius:3px;color:#aaa;font-size:12px;vertical-align:middle;margin-top:-1px;float:right;'.$floatmarginright.'">'.$tmpuserstr.'</span> ';
					}
					
					$previewtimestr='';
					if($it618_video_goods_video['it618_previewtime']>0){
						$previewtimestr='<span style="border:#ddd 1px solid; padding:0; height:15px; line-height:15px; display:inline-block; padding-left:2px; padding-right:2px; border-radius:3px;color:#aaa;font-size:12px;vertical-align:middle;margin-top:-1px;float:right;'.$floatmarginright.'">'.$it618_video_lang['s1713'].'</span> ';
					}
					
					if($it618_video_goods_video['it618_islive']==1){
						$vtimestr='<font color=#23b8ff>'.$it618_video_lang['s1317'].'</font>';
						$tmpimg='source/plugin/it618_video/images/live.gif';
					}else{
						$vtimestr='<span class="lispantime">('.it618_video_getvideotimestr($it618_video_goods_video).')</span>';
						$tmpimg='source/plugin/it618_video/template/edu/images/courseimg1.png';
					}
					
					$videostr.='<li>
									<span style="float:right;'.$despcss.'" onclick="getdesp('.$n.')">
									<img src="source/plugin/it618_video/template/edu/images/dec0.png" id="decimg'.$n.'" style="cursor:pointer">
									</span>
									<img src="'.$tmpimg.'" width="20" class="liimg">&nbsp;&nbsp;
									'.$isuserstr.$previewtimestr.'<a href="'.$lessonurl.'" target="_blank">'.$it618_video_goods_video['it618_name'].'</a> '.$vtimestr.'
									'.$videopricestr.'
									<div id="desp'.$n.'" style="display:none;line-height:23px;font-size:14px">'.$it618_video_goods_video['it618_description'].'</div>
								</li>';
				}
			}
			
			$videostr=str_replace("floatmarginright",$floatmarginright,$videostr);
						
			if($it618_video_goods['it618_lessoncount']>1){
				$datatmpstr=$ln.'-'.$vn;
			}else{
				$datatmpstr=$vn;
			}
			
			$query2 = DB::query("SELECT * FROM ".DB::table('it618_video_goods_data')." WHERE it618_vid=".$it618_video_goods_video['id']." and it618_dataurl!='' ORDER BY it618_order");
			while($it618_video_goods_data = DB::fetch($query2)) {
				$isdata=1;
				$isok=0;
				if($it618_video_goods_data['it618_isuser']==0){
					$isok=1;
				}
				
				if($it618_video_goods_data['it618_isuser']==2){
					$it618_dataurl='<font color=#999>'.$it618_video_lang['s942'].'</font>';
					if($_G['uid']>0){
						$isok=1;
					}
				}
				
				if($it618_video_goods_data['it618_isuser']==1){
					$it618_dataurl='<font color=#f60>'.$it618_video_lang['s805'].'</font>';
					
					if($isgoodsprice>0){
						if($videopowertmp['state']>0){
							$isok=1;
						}else{
							if($isvipok==1){
								$isok=1;
							}
						}
					}else{
						$isok=1;
					}
					
					if($_G['uid']>0){
						$it618_video_shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_uid($_G['uid']);
						if($it618_video_goods['it618_shopid']==$it618_video_shoptmp['id']){
							$isok=1;
						}
					}
				}
				
				$datadownurl='plugin.php?id=it618_video:datadown&did='.$it618_video_goods_data['id'];
	
				if($templatename=='mall'){
					if($isok==1)$it618_dataurl='<a href="'.$datadownurl.'" target="_blank">'.$it618_video_lang['s806'].'</a>';
					
					$datastr.='<tr>
								<td>'.$datatmpstr.'</td>
								<td style="text-align:left;padding-left:8px">'.$it618_video_goods_data['it618_name'].'</td>
								<td>'.$it618_video_goods_data['it618_datasizestr'].' , '.$it618_video_lang['s46'].': '.$it618_video_goods_data['it618_views'].'</td>
								<td>'.$it618_dataurl.'</td>
							</tr>';
				}
				
				$it618_dataurl1='';
				if($templatename=='edu'){
					if($isok==1){
						$it618_dataurl1='href="'.$datadownurl.'" target="_blank"';
						$it618_dataurl='<font color=#9ac485>'.$it618_video_lang['s806'].'</font>';
					}
					$datastr2.='<li>
									<img src="source/plugin/it618_video/template/edu/images/coursedataimg1.png" width="20" class="liimg">&nbsp;&nbsp;
									'.$it618_dataurl.'&nbsp;&nbsp;<a '.$it618_dataurl1.'>'.$it618_video_goods_data['it618_name'].'</a> <span class="lispantime">('.$it618_video_goods_data['it618_datasizestr'].' , '.$it618_video_lang['s46'].': '.$it618_video_goods_data['it618_views'].')</span>
								</li>';
				}
				
			}
			
			$query3 = DB::query("SELECT * FROM ".DB::table('it618_video_goods_video_exam')." WHERE it618_vid=".$it618_video_goods_video['id']." ORDER BY it618_order");
			while($it618_video_goods_video_exam = DB::fetch($query3)) {
				$isexam=1;
				
				$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_video_goods_video_exam['it618_tid']);
				
				$examurl=it618_video_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
				
				$it618_exam_goods['it618_examscore']=str_replace(".0","",$it618_exam_goods['it618_examscore']);
				$it618_examstr=str_replace("{qcount}",$it618_exam_goods['it618_questioncount'],$it618_video_lang['s1429']);
				$it618_examstr=str_replace("{score}",$it618_exam_goods['it618_examscore'],$it618_examstr);
				$it618_examstr=str_replace("{time}",$it618_exam_goods['it618_examtime'],$it618_examstr);
				
				$isuserstr='';
				if($it618_video_goods_video_exam['it618_power']==1&&$isgoodsprice==1){
					$isuserstr='<span style="border:#ddd 1px solid; padding:0; height:15px; line-height:15px; display:inline-block; padding-left:2px; padding-right:2px; border-radius:3px;color:#aaa;font-size:12px;vertical-align:middle;margin-top:-1px;float:right;margin-right:8px">'.$it618_video_lang['s1574'].'</span> ';
				}
		
				if($templatename=='mall'){
					$examstr.='<tr>
								<td>'.$datatmpstr.'</td>
								<td style="text-align:left;padding-left:8px">'.$isuserstr.'<a href="'.$examurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a> ('.$it618_examstr.')</td>
							</tr>';
				}
				
				$it618_dataurl1='';
				if($templatename=='edu'){
					$datastr3.='<li>
									<img src="source/plugin/it618_video/template/edu/images/coursedataimg1.png" width="20" class="liimg">&nbsp;&nbsp;
									'.$isuserstr.'<a href="'.$examurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a> <span class="lispantime">('.$it618_examstr.')</span>
								</li>';
				}
				
			}
			
			$n=$n+1;
			$vn=$vn+1;
		}
		
		if($templatename=='edu'){
			if($datastr2!=''){
				$datastr.=$datastr1.$datastr2.'</div></div>';
			}
		}
		
		if($templatename=='edu'){
			if($datastr3!=''){
				$datastr1=str_replace("data","exam",$datastr1);
				$examstr.=$datastr1.$datastr3.'</div></div>';
			}
		}
		
		$videostr.='</div></div>';
	}
	
	$ln=$ln+1;
}

$despcount=$n-1;

if($templatename=='edu'){
	$it618_exam_goods['it618_message']=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe width="800" height="450" src="\1" frameborder="0" allowfullscreen="1"/>',$it618_exam_goods['it618_message']);
}else{
	$it618_exam_goods['it618_message']=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe width="910" height="510" src="\1" frameborder="0" allowfullscreen="1"/>',$it618_exam_goods['it618_message']);
}

if($it618_video_goods['it618_videocount']<$it618_video_goods['it618_allvideocount']){
	$it618_videotimestr=$it618_video_lang['s399'].$it618_video_goods['it618_lessoncount'].$it618_video_lang['s1816'].$it618_video_goods['it618_allvideocount'].$it618_video_lang['s108'].' '.$it618_video_lang['s1893'].$it618_video_goods['it618_videocount'].$it618_video_lang['s108'];
}else{
	$it618_videotimestr=$it618_video_lang['s399'].$it618_video_goods['it618_lessoncount'].$it618_video_lang['s1816'].$it618_video_goods['it618_videocount'].$it618_video_lang['s108'];
}

if($_G['uid']>0){
	$count=C::t('#it618_video#it618_video_collect')->count_by_uid_pid($_G['uid'],$pid);
	if($count>0){
		$collectname=$it618_video_lang['s1649'];
	}else{
		$collectname=$it618_video_lang['s1648'];	
	}
}else{
	$collectname=$it618_video_lang['s1648'];
}

if($IsChat==1){
	if($it618_video_shop['it618_isqunchat']==1)$isqunchat=1;
}

$playtitle=$it618_video_lang['s1645'];
if($it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_mfvideo_by_pid($pid)){
	$playtitle=$it618_video_lang['s1632'];
	$lessonurlhref=it618_video_getrewrite('video_wap','lesson@'.$it618_video_goods_video['id'],'plugin.php?id=it618_video:wap&pagetype=lesson&cid='.$it618_video_goods_video['id']);
}

if($_G['uid']>0){
	if($it618_video_play=C::t('#it618_video#it618_video_play')->fetch_by_uid_pid_etime($_G['uid'],$pid)){
		$playtitle=$it618_video_lang['s1633'];
		$lessonurlhref=it618_video_getrewrite('video_wap','lesson@'.$it618_video_play['it618_vid'],'plugin.php?id=it618_video:wap&pagetype=lesson&cid='.$it618_video_play['it618_vid']);
	}
}

$metatitle=$tmppname.$it618_video_goods['it618_name'].' - '.$metatitle;
$metakeywords=$it618_video_goods['it618_seokeywords'];
$metadescription=$it618_video_goods['it618_seodescription'];

require_once DISCUZ_ROOT.'./source/plugin/it618_video/it618_api.func.php';
$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename.'/video_default');
?>