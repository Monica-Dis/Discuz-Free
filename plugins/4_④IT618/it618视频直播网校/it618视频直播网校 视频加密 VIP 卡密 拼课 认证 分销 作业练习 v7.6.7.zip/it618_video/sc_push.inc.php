<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

echo '
<script charset="utf-8" src="source/plugin/it618_video/js/jquery.js"></script>
';

$lecturerurl=$_G['siteurl'].it618_video_getrewrite('video_lecturer',$ShopId,'plugin.php?id=it618_video:lecturer&lid='.$ShopId);

$it618_video_lang['s1932']=str_replace('{siteurl}',$_G['siteurl'],$it618_video_lang['s1932']);
$it618_video_lang['s1946']=str_replace('{siteurl}',$_G['siteurl'],$it618_video_lang['s1946']);

$tomonth = date('n'); 
$todate = date('j'); 
$toyear = date('Y');
$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_video_shop_push')." where it618_time>=$time and it618_shopid=$ShopId");

$it618_video_lang['s1928']=str_replace('{count1}',$it618_video_shop['it618_wxmessagecount'],$it618_video_lang['s1928']);
$it618_video_lang['s1928']=str_replace('{count2}',$count,$it618_video_lang['s1928']);

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/message.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_video/config/message.php';
}

$flag=0;
if($it618_isok==1&&$it618_body_push_user_isok==1){
	if($it618_body_push_user!=''&&$it618_length>0){
		$flag=1;
		$it618_video_lang['s1945']=str_replace('{lenght}',$it618_length,$it618_video_lang['s1945']);
		if($it618_body_push_user_tplid_wxsms!=''){
			$istelmessage='<tr><td>'.$it618_video_lang['s1929'].'</td><td><select name="istelmessage"><option value=1 selected="selected">'.$it618_video_lang['s1949'].'</option><option value=0>'.$it618_video_lang['s1951'].'</option></select></td></tr>';
		}
	}
}

if($flag==0)$it618_video_lang['s1945']='';

showtableheaders(it618_video_getlang('s1918'),'it618_video_sum');

	echo '
	<form id="it618_push">
	<tr><td colspan="2">'.$it618_video_lang['s1928'].'</td></tr>
	<tr><td width=80>'.$it618_video_lang['s1930'].'</td><td><input id="it618_url" name="it618_url" class="txt" style="width:580px;margin-right:1px" value="'.$lecturerurl.'" /> <font color=#999>'.$it618_video_lang['s1932'].'</font></td></tr>
	<tr><td>'.$it618_video_lang['s1931'].'</td><td style="position:relative"><textarea id="it618_message" name="it618_message" style="width:580px;height:80px"></textarea><span style="position:absolute; bottom:10px;left:596px;color:#999">'.$it618_video_lang['s1945'].'</span></td></tr>
	'.$istelmessage.'
	<tr><td colspan="2"><input type="button" class="btn" style="width:90px;height:38px" value="'.it618_video_getlang('s1927').'" onclick="addpush()" /></td></tr>
	</form>
	<tr class="trreturn1" style="display:none"><td colspan="2">'.$it618_video_lang['s1933'].'<span id="spancount1" style="color:red">0</span>'.$it618_video_lang['s1934'].'<span id="spancount2" style="color:red">0</span>'.$it618_video_lang['s1935'].'</td></tr>
	<tr class="trreturn2" style="display:none"><td colspan="2">
	<table id="pushreturn"></table>
	</td></tr>
	';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/
echo '
<script>
function addpush(){
	if(document.getElementById("it618_url").value==""){
		alert("'.$it618_video_lang['s1936'].'");
		document.getElementById("it618_url").focus();
		return;
	}else{
		var tmparr=document.getElementById("it618_url").value.split("'.$_G['siteurl'].'");
		if(tmparr.length==1){
			alert("'.$it618_video_lang['s1946'].'");
			document.getElementById("it618_url").focus();
			return;
		}
	}
	
	if(document.getElementById("it618_message").value==""){
		alert("'.$it618_video_lang['s1937'].'");
		document.getElementById("it618_message").focus();
		return;
	}
	
	if(confirm("'.$it618_video_lang['s1938'].'")){
		IT618_VIDEO.post("'.$_G['siteurl'].'plugin.php?id=it618_video:ajax'.$adminsid.'"+"&ac=addpush&formhash='.FORMHASH.'",IT618_VIDEO("#it618_push").serialize(),function (data, textStatus){
			var tmparr=data.split("it618_split");
			
			if(tmparr[1]=="ok"){
				IT618_VIDEO("#pushreturn").html(tmparr[4]);
				IT618_VIDEO("#spancount1").html(tmparr[3]);
				IT618_VIDEO(".trreturn1").show();
				
				var okcount=0;
				for(var i=1;i<=tmparr[3];i++){
					var uid=document.getElementById("user"+i).value;
					IT618_VIDEO("#tduser"+i).html("<img src=\'source/plugin/it618_video/wap/images/loading.gif\'>");
					IT618_VIDEO.get("'.$_G['siteurl'].'plugin.php?id=it618_video:ajax'.$adminsid.'&pushid="+tmparr[2]+"&uid="+uid+"&i="+i+"&formhash='.FORMHASH.'", {ac:"pushmessage"},function (data, textStatus){
						var tmparr=data.split("it618_split");
						IT618_VIDEO("#tduser"+tmparr[1]).html(tmparr[3]);
						if(tmparr[2]=="ok"){
							okcount=okcount+1;
							IT618_VIDEO("#spancount2").html(okcount);
						}
					}, "html");		
				}
			}else{
				IT618_VIDEO("#pushreturn").html("<tr><td style=\'color:red\'>"+tmparr[1]+"</td></tr>");
			}
			
			IT618_VIDEO(".trreturn2").show();
		}, "html");
	}
}
</script>
';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>