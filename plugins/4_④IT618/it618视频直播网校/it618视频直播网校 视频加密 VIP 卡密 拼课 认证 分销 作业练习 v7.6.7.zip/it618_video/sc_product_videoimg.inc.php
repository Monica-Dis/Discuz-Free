<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$vid=intval($_GET['vid']);
$preurl=$_GET['preurl'];
$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_id($vid);
$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_video['it618_pid']);
$it618_video_goods_lesson=C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($it618_video_goods_video['it618_lid']);
if($it618_video_goods_video['it618_liveid']==0){
	$videoname=$it618_video_goods_video['it618_name'];
}else{
	$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
	$videoname=$it618_video_live['it618_name'];
}

if(submitcheck('it618submit')){
	C::t('#it618_video#it618_video_goods_video')->update($vid,array(
		'it618_videoimg' => $_GET['it618_videoimg']
	));

	echo '<script>parent.location.reload();parent.layer.closeAll();</script>';
}

it618_showformheader("plugin.php?id=it618_video:sc_product_videoimg$adminsid&vid=$vid&preurl=$preurl");
showtableheaders($it618_video_goods['it618_name'].' - '.$it618_video_goods_lesson['it618_name'].' - '.$videoname.'</font>','sc_product_video_edit');

if(video_is_mobile()){
	$issource='editor1.clickToolbar("source");';
}

if($it618_video_goods_video['it618_videoimg']!='')$src='src="'.$it618_video_goods_video['it618_videoimg'].'"';

echo '
<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/plugins/code/prettify.js"></script>

<script>
	KindEditor.ready(function(K) {
		var editor = K.editor({
					uploadJson : \'source/plugin/it618_video/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=1200'.$oss.'\',
					fileManagerJson : \'source/plugin/it618_video/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
					allowFileManager : true
				});
		
		K(\'#image1\').click(function() {
			editor.loadPlugin(\'image\', function() {
				editor.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor.hideDialog();
					}
				});
			});
		});
		
	});
</script>

<tr><td><img id="img1" '.$src.' width="100" height="60" align="absmiddle"/> <input type="text" id="url1" name="it618_videoimg" value="'.$it618_video_goods_video['it618_videoimg'].'" readonly="readonly"/> <input type="button" id="image1" value="'.it618_video_getlang('s395').'" /></td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_video_getlang('s1616').'" /></div></td></tr>';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>