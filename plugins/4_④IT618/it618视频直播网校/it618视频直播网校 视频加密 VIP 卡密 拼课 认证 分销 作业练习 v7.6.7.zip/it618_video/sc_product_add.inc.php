<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

if(submitcheck('it618submit')){
	
	$id=C::t('#it618_video#it618_video_goods')->insert(array(
		'it618_shopid' => $ShopId,
		'it618_shopuid' => $ShopUid,
		'it618_class1_id' => $_GET['it618_class1_id'],
		'it618_class2_id' => $_GET['it618_class2_id'],
		'it618_class1_id1' => $_GET['it618_class1_id1'],
		'it618_class2_id1' => $_GET['it618_class2_id1'],
		'it618_class1_id2' => $_GET['it618_class1_id2'],
		'it618_class2_id2' => $_GET['it618_class2_id2'],
		'it618_class1_id3' => $_GET['it618_class1_id3'],
		'it618_class2_id3' => $_GET['it618_class2_id3'],
		'it618_gtype' => $_GET['it618_gtype'],
		'it618_name' => dhtmlspecialchars($_GET['it618_name']),
		'it618_allvideocount' => dhtmlspecialchars($_GET['it618_allvideocount']),
		'it618_description' => dhtmlspecialchars($_GET['it618_description']),
		'it618_seokeywords' => dhtmlspecialchars($_GET['it618_seokeywords']),
		'it618_seodescription' => dhtmlspecialchars($_GET['it618_seodescription']),
		'it618_picbig' => dhtmlspecialchars($_GET['it618_picbig']),
		'it618_message' => $_GET['it618_message'],
		'it618_time' => $_G['timestamp']
	), true);
	
	if($IsChat==1){
		C::t('#it618_video#it618_video_goods')->update($id,array(
			'it618_isuser' => $_GET['it618_isuser'],
			'it618_isip' => $_GET['it618_isip'],
			'it618_isaddr' => $_GET['it618_isaddr']
		));
	}
	
	for($i=0;$i<=0;$i++){
		if($i==0)$tmpi='';else $tmpi=$i;
		$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
		
		if($get_it618_picbig!=''){
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/smallimage/';
			if (!file_exists($smallpath)) {
				mkdir($smallpath);
			}

			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1));
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$id.'_'.md5($get_it618_picbig).'.'.$file_ext;
			it618_video_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,385,1);
		}

	}

	it618_cpmsg(it618_video_getlang('s359'), "plugin.php?id=it618_video:sc_product$adminsid", 'succeed');
}

it618_showformheader("plugin.php?id=it618_video:sc_product_add$adminsid");
showtableheaders(it618_video_getlang('s360'),'it618_video_goods');

$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_class1')." ORDER BY it618_order");
while($it618_tmp = DB::fetch($query1)) {
	$classtmp1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_video_class1'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_class1')." ORDER BY it618_order");
$n1=1;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_video_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}
	
echo '
<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/plugins/code/prettify.js"></script>
<script charset="utf-8" src="source/plugin/it618_video/js/laydate/laydate.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_video/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_video/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_video/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false
		});
		
		K(\'#image1\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
	});
	
	function checkvalue(){
		if(document.getElementById("it618_class2_id").value=="0"){
			alert("'.it618_video_getlang('s361').'");
			return false;
		}
		if(document.getElementById("it618_name").value==""){
			alert("'.it618_video_getlang('s362').'");
			return false;
		}
		if(document.getElementById("url1").value==""){
			alert("'.it618_video_getlang('s372').'");
			return false;
		}
	}
	
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x,n)
	{
	 if(n==0)n="";
	 var temp = document.getElementById("it618_class2_id"+n); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
</script>

<tr><td width=80>'.it618_video_getlang('s374').'</td><td>
<select name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex,0)"><option value="0">'.it618_video_getlang('s375').'</option>'.$classtmp1.'</select> <select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.it618_video_getlang('s376').'</option></select>
'.$it618_video_lang['s1005'].'
<br><br>
<select name="it618_class1_id1" onchange="redirec_class(this.options.selectedIndex,1)"><option value="0">'.it618_video_getlang('s375').'</option>'.$classtmp1.'</select> <select id="it618_class2_id1"  name="it618_class2_id1"><option value="0">'.it618_video_getlang('s376').'</option></select>
<br>
<select name="it618_class1_id2" onchange="redirec_class(this.options.selectedIndex,2)"><option value="0">'.it618_video_getlang('s375').'</option>'.$classtmp1.'</select> <select id="it618_class2_id2"  name="it618_class2_id2"><option value="0">'.it618_video_getlang('s376').'</option></select>
<br>
<select name="it618_class1_id3" onchange="redirec_class(this.options.selectedIndex,3)"><option value="0">'.it618_video_getlang('s375').'</option>'.$classtmp1.'</select> <select id="it618_class2_id3"  name="it618_class2_id3"><option value="0">'.it618_video_getlang('s376').'</option></select>
</td></tr>
<tr><td>'.$it618_video_lang['s21'].'</td><td><select name="it618_gtype"><option value="0">'.$it618_video_lang['s22'].'</option><option value="1" selected="selected">'.$it618_video_lang['s26'].'</option></select> '.$it618_video_lang['s24'].'</td></tr>
<tr><td>'.it618_video_getlang('s839').'</td><td><input type="text" class="txt" style="width:776px;margin-right:0" id="it618_name" name="it618_name"> </td></tr>
<tr><td>'.it618_video_getlang('s1891').'</td><td><input type="text" class="txt" style="width:50px;margin-right:3px" name="it618_allvideocount">'.it618_video_getlang('s1892').'</td></tr>
';

if($IsChat==1){
echo '<tr><td>'.$it618_video_lang['s1369'].'</td><td>
<input class="checkbox" type="checkbox" id="chk_isuser" name="it618_isuser" checked="checked" value="1"><label for="chk_isuser">'.it618_video_getlang('s1366').'</label>
<input class="checkbox" type="checkbox" id="chk_isip" name="it618_isip" value="1"><label for="chk_isip">'.it618_video_getlang('s1367').'</label>
<input class="checkbox" type="checkbox" id="chk_isaddr" name="it618_isaddr" value="1"><label for="chk_isaddr">'.it618_video_getlang('s1368').'</label>
</td></tr>';
}

echo '<tr><td>'.it618_video_getlang('s394').'</td><td><img id="img1" width="100" height="60" align="absmiddle"/> <input type="text" id="url1" name="it618_picbig" readonly="readonly"/> <input type="button" id="image1" value="'.it618_video_getlang('s395').'" /></td></tr>
<tr><td>'.it618_video_getlang('s567').'</td><td><textarea name="it618_description" style="width:776px;height:60px;"></textarea></td></tr>
<tr><td>'.it618_video_getlang('s404').'</td><td><textarea name="it618_message" style="width:780px;height:400px;visibility:hidden;"></textarea></td></tr>
<tr><td>'.it618_video_getlang('s405').'</td><td><input type="text" class="txt" style="width:776px;margin-right:0" name="it618_seokeywords"></td></tr>
<tr><td>'.it618_video_getlang('s406').'</td><td><textarea name="it618_seodescription" style="width:776px;height:60px;"></textarea></td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_video_getlang('s407').'" /></div></td></tr>';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>