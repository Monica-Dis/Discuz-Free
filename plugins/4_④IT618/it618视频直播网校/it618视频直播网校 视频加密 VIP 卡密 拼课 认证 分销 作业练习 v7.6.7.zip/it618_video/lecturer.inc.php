<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pagetype='lecturer';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/video_default.func.php';

$lid=intval($_GET['lid']);
if(video_is_mobile()){ 
	if(isset($_GET['tuiuid'])){
		$urltmp='tuiuid='.$_GET['tuiuid'];
	}
	if(isset($_GET['quan'])){
		$urltmp='quan';
	}
	if(isset($_GET['tui'])){
		$urltmp='tui';
	}
	
	if($urltmp!=''){
		$tmpurl=it618_video_getrewrite('video_wap','lecturer@'.$lid,'plugin.php?id=it618_video:wap&pagetype=lecturer&cid='.$lid.'&'.$urltmp,'?'.$urltmp);
	}else{
		$tmpurl=it618_video_getrewrite('video_wap','lecturer@'.$lid,'plugin.php?id=it618_video:wap&pagetype=lecturer&cid='.$lid);
	}

	dheader("location:$tmpurl");
}

$homeurl=it618_video_getrewrite('video_home','','plugin.php?id=it618_video:index');
if($it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($lid)){	
	$it618_state=$it618_video_shop['it618_state'];
	if($it618_state==0){
		echo it618_video_getlang('s334').' <a href="'.$homeurl.'">'.$it618_video_lang['s18'].'</a>';exit;
	}elseif($it618_state==1){
		echo it618_video_getlang('s335').' <a href="'.$homeurl.'">'.$it618_video_lang['s18'].'</a>';exit;
	}else{
		$it618_htstate=$it618_video_shop['it618_htstate'];
		if($it618_htstate==0){
			echo it618_video_getlang('s336').' <a href="'.$homeurl.'">'.$it618_video_lang['s18'].'</a>';exit;
		}elseif($it618_htstate==2){
			echo it618_video_getlang('s337').' <a href="'.$homeurl.'">'.$it618_video_lang['s18'].'</a>';exit;
		}else{
			$ShopId=$it618_video_shop['id'];
		}
	}
}else{
	echo it618_video_getlang('s338').' <a href="'.$homeurl.'">'.$it618_video_lang['s18'].'</a>';exit;
}

if(C::t('#it618_video#it618_video_shop_subscribe')->count_by_shopid_uid($ShopId,$_G['uid'])>0){
	$subscribetitle=$it618_video_lang['s1397'];
}else{
	$subscribetitle=$it618_video_lang['s1396'];
}

$shopsubscribes=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_shop_subscribe')." WHERE it618_shopid=".$it618_video_shop['id']);
$shopviews=DB::result_first("SELECT SUM(it618_views) FROM ".DB::table('it618_video_goods')." WHERE it618_shopid=".$it618_video_shop['id']);

$goodscount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods')." WHERE it618_shopid=$ShopId and it618_state=1");
$playpjcount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_play_pj')." WHERE it618_score1>0 and it618_shopid=$ShopId");
$salecount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_sale')." WHERE it618_shopid=$ShopId and it618_state!=0");
$playcount=DB::result_first("SELECT SUM(it618_plays) FROM ".DB::table('it618_video_goods')." WHERE it618_shopid=$ShopId");

$shopgoodsarr=explode("it618_split",it618_video_getshopgoods($ShopId));

if($IsChat==1){
	if($it618_video_shop['it618_isqunchat']==1)$isqunchat=1;
}

$metatitle=$it618_video_shop['it618_name'].' - '.$metatitle;
$metakeywords=$it618_video_goods['it618_name'];
$metadescription=$it618_video_goods['it618_about'];

$url_this=$_G['siteurl'].it618_video_getrewrite('video_wap','lecturer@'.$lid,'plugin.php?id=it618_video:wap&pagetype=lecturer&cid='.$lid);
$qrcodesrc='plugin.php?id=it618_video:urlcode&url='.urlencode($url_this);

$footer.='<div style="display:none">'.$it618_video_shop['it618_tongji'].'</div>';

require_once DISCUZ_ROOT.'./source/plugin/it618_video/it618_api.func.php';
$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename.'/video_default');
?>