<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if($reabc[4]!='8')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_video/function/it618_video.func.php';

if($reabc[9]!='e')return;
$ppp = $it618_video['pagecount'];
$page = max(1, intval($_GET['page']));
if($_GET['findbtn']==1)$page=1;
$startlimit = ($page - 1) * $ppp;
$deletes = '';
$extrasql = '';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_set&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$tmpcss=' style="display:none"';
$tmpcp1=29;
$tmpcp='admin_player';
$count1 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_liveset'));
$count2 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_media_wmf'));
$count3 = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_media_aoss'));
if($count1==0&&$count2==0&&$count3==0){
	$isalapi=1;
	$tmpcss='';
	$tmpcp1=32;
	$tmpcp='admin_alapi';
}

if(isset($_GET['cp1'])){
	$cp1=$_GET['cp1'];
}else{
	$cp1=$tmpcp1;
}
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<=33;$i++){
	if($i==$cp1){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

$strtmptitle[7]=$it618_video_lang['s8'];
$strtmptitle[8]=$it618_video_lang['s9'];
$strtmptitle[9]=$it618_video_lang['s10'];
$strtmptitle[10]=$it618_video_lang['s11'];
$strtmptitle[11]=$it618_video_lang['s738'];
$strtmptitle[12]=$it618_video_lang['s1467'];
$strtmptitle[13]=$it618_video_lang['s561'];

$strtmptitle[15]=$it618_video_lang['s737'];
$strtmptitle[16]=$it618_video_lang['s871'];

$strtmptitle[18]=$it618_video_lang['s888'];
$strtmptitle[19]=$it618_video_lang['s889'];

$strtmptitle[21]=$it618_video_lang['s1057'];
$strtmptitle[22]=$it618_video_lang['s1127'];
$strtmptitle[23]=$it618_video_lang['s1878'];
$strtmptitle[24]=$it618_video_lang['s402'];
$strtmptitle[25]=$it618_video_lang['s403'];
$strtmptitle[26]=$it618_video_lang['s1922'];
$strtmptitle[27]=$it618_video_lang['s793'];
$strtmptitle[28]=$it618_video_lang['s794'];
$strtmptitle[29]=$it618_video_lang['s1180'];
$strtmptitle[30]=$it618_video_lang['s1208'];
$strtmptitle[31]=$it618_video_lang['s1513'];
$strtmptitle[32]=$it618_video_lang['s1731'];
$strtmptitle[33]=$it618_video_lang['s1617'];

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">

<li '.$strtmp[18].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=18'.$urls.'"><span>'.$strtmptitle[18].'</span></a></li>
<li '.$strtmp[16].'><a href="'.$hosturl.'plugins&cp=admin_gonggao&cp1=16'.$urls.'"><span>'.$strtmptitle[16].'</span></a></li>
<li '.$strtmp[24].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=24'.$urls.'"><span>'.$strtmptitle[24].'</span></a></li>
<li '.$strtmp[25].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=25'.$urls.'"><span>'.$strtmptitle[25].'</span></a></li>
<li '.$strtmp[11].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=11'.$urls.'"><span>'.$strtmptitle[11].'</span></a></li>
<li '.$strtmp[15].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=15'.$urls.'"><span>'.$strtmptitle[15].'</span></a></li>
<li '.$strtmp[12].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=12'.$urls.'"><span>'.$strtmptitle[12].'</span></a></li>
<li '.$strtmp[22].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=22'.$urls.'"><span>'.$strtmptitle[22].'</span></a></li>
<li '.$strtmp[27].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=27'.$urls.'"><span>'.$strtmptitle[27].'</span></a></li>
<li '.$strtmp[28].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=28'.$urls.'"><span>'.$strtmptitle[28].'</span></a></li>
<li '.$strtmp[26].'><a href="'.$hosturl.'plugins&cp=admin_set&cp1=26'.$urls.'"><span>'.$strtmptitle[26].'</span></a></li>
<li '.$strtmp[7].'><a href="'.$hosturl.'plugins&cp=admin_rewrite&cp1=7'.$urls.'"><span>'.$strtmptitle[7].'</span></a></li>
<li '.$strtmp[8].'><a href="'.$hosturl.'plugins&cp=admin_message&cp1=8'.$urls.'"><span>'.$strtmptitle[8].'</span></a></li>
<li '.$strtmp[10].'><a href="'.$hosturl.'plugins&cp=admin_txbl&cp1=10'.$urls.'"><span>'.$strtmptitle[10].'</span></a></li>
<li '.$strtmp[13].'><a href="'.$hosturl.'plugins&cp=admin_jfhl&cp1=13'.$urls.'"><span style="color:red">'.$strtmptitle[13].'</span></a></li>
<li '.$strtmp[19].'><a href="'.$hosturl.'plugins&cp=admin_diy&cp1=19'.$urls.'"><span>'.$strtmptitle[19].'</span></a></li>
<li '.$strtmp[21].'><a href="'.$hosturl.'plugins&cp=admin_shuadan&cp1=21'.$urls.'"><span>'.$strtmptitle[21].'</span></a></li>
<li '.$strtmp[23].'><a href="'.$hosturl.'plugins&cp=admin_aliyunoss&cp1=23'.$urls.'"><span>'.$strtmptitle[23].'</span></a></li>
<li '.$strtmp[29].'><a href="'.$hosturl.'plugins&cp=admin_player&cp1=29'.$urls.'"><span>'.$strtmptitle[29].'</span></a></li>
<li '.$strtmp[33].'><a href="'.$hosturl.'plugins&cp=admin_appad&cp1=33'.$urls.'"><span>'.$strtmptitle[33].'</span></a></li>
<li '.$strtmp[30].'><a href="'.$hosturl.'plugins&cp=admin_cdn&cp1=30'.$urls.'"><span>'.$strtmptitle[30].'</span></a></li>
<li '.$strtmp[31].'><a href="'.$hosturl.'plugins&cp=admin_block&cp1=31'.$urls.'"><span>'.$strtmptitle[31].'</span></a></li>
<li '.$strtmp[32].$tmpcss.'><a href="'.$hosturl.'plugins&cp=admin_alapi&cp1=32'.$urls.'"><span>'.$strtmptitle[32].'</span></a></li>
</ul></div>';


$cparray = array('admin_set', 'admin_gonggao', 'admin_diy', 'admin_rewrite', 'admin_message', 'admin_txbl', 'admin_jfhl',  'admin_shuadan', 'admin_aliyunoss', 'admin_player', 'admin_appad', 'admin_cdn', 'admin_block', 'admin_alapi');
$cp = !in_array($_GET['cp'], $cparray) ? $tmpcp : $_GET['cp'];

if($cp1==11)$setname='wapplayad';
if($cp1==12)$setname='screencapad';
if($cp1==15)$setname='playad';
if($cp1==18)$setname='rzabout';
if($cp1==22)$setname='waphomead';
if($cp1==24)$setname='lessontopad';
if($cp1==25)$setname='lessonbottomad';
if($cp1==26)$setname='subscribeabout';
if($cp1==27)$setname='wapproductad1';
if($cp1==28)$setname='wapproductad2';

$pmod='admin_set';

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*dism��taobao��com*/
?>