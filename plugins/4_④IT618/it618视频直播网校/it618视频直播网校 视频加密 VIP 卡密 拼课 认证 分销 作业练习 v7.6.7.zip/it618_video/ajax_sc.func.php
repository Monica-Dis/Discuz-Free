<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if($_GET['ac1']=="scproduct_save"){

	if($_GET['ac2']=="del"){
		$del=0;
		if($it618_video_shop['it618_isdel']==1){
			foreach($_GET['delete'] as $key => $delid) {
				$delid=intval($delid);
				$salecount = C::t('#it618_video#it618_video_sale')->sumcount_by_it618_pid($delid);
				$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($delid);
				if($it618_video_goods['it618_shopid']!=$ShopId){
					echo $it618_video_lang['s513'];exit;
				}
				if($salecount==0&&$it618_video_goods['it618_videocount']==0){
		
					$tmpurl=$_G['siteurl'].it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
					
					$tmparr=explode("source",$it618_video_goods['it618_picbig']);
					$tmparr1=explode("://",$it618_video_goods['it618_picbig']);
					$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
					
					if(file_exists($it618_picbig)&&count($tmparr1)==1){
						$result=unlink($it618_picbig);
					}
					
					for($i=0;$i<=4;$i++){
						if($i==0)$tmpi='';else $tmpi=$i;
						$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
						
						if($it618_video_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
							$tmparr=explode("source",$it618_video_goods['it618_picbig'.$tmpi]);
							$tmparr1=explode("://",$it618_video_goods['it618_picbig'.$tmpi]);
							$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
							
							if(file_exists($it618_picbig)&&count($tmparr1)==1){
								$result=unlink($it618_picbig);
							}
						}
						
						$file_ext=strtolower(substr($it618_video_goods['it618_picbig'.$tmpi],strrpos($it618_video_goods['it618_picbig'.$tmpi], '.')+1)); 
						$file_extarr=explode("?",$file_ext);
						$file_ext=$file_extarr[0];
						$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$delid.'_'.$i.'.'.$file_ext;
						if(file_exists($it618_smallurl)){
							$result=unlink($it618_smallurl);
						}
					}
					
					C::t('#it618_video#it618_video_goods')->delete_by_id($delid);
					$del=$del+1;
				}else{
					$flag=1;
				}
			}
		}else{
			$del=$it618_video_lang['s1604'];
		}
		
		if($flag==1)$tmpstr='<br><br>'.$it618_video_lang['s1775'];
	
		echo it618_video_getlang('s342').$del.$tmpstr;
	}

	if($_GET['ac2']=="edit"){
		$ok=0;
		if(is_array($_GET['it618_name'])) {
			foreach($_GET['it618_name'] as $id => $val) {
	
				$it618_saleprice=$_GET['it618_saleprice'][$id];
				
				$it618_score=$_GET['it618_score'][$id];
				if($_GET['it618_jfid'][$id]==0)$it618_score=0;
				
				if($Shopisale!=1){
					$it618_saleprice=1;
				}
				
				$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($id);
				if($it618_video_goods['it618_shopid']!=$ShopId){
					echo $it618_video_lang['s513'];exit;
				}
					
				C::t('#it618_video#it618_video_goods')->update($id,array(
					'it618_name' => it618_video_utftogbk($_GET['it618_name'][$id]),
					'it618_price' => $_GET['it618_price'][$id],
					'it618_saleprice' => $it618_saleprice,
					'it618_jfid' => $_GET['it618_jfid'][$id],
					'it618_score' => $it618_score,
					'it618_jfbl' => $_GET['it618_jfbl'][$id],
					'it618_xgtype' => $_GET['it618_xgtype'][$id],
					'it618_xgtime1' => it618_video_utftogbk($_GET['it618_xgtime1'][$id]),
					'it618_xgtime2' => it618_video_utftogbk($_GET['it618_xgtime2'][$id]),
					'it618_shoporder' => $_GET['it618_shoporder'][$id],
					'it618_isbm' => $_GET['it618_isbm'][$id],
					'it618_isprotect' => $_GET['it618_isprotect'][$id]
				));
		
				$ok=$ok+1;
			}
		}
	
		echo it618_video_getlang('s345').$ok;
	}
	
	if($_GET['ac2']=="on"){
		$ok=0;
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($delid);
			if($it618_video_goods['it618_shopid']!=$ShopId){
				echo $it618_video_lang['s513'];exit;
			}
			if($it618_video_goods['it618_state']==0){
				DB::query("update ".DB::table('it618_video_goods')." set it618_state=1 where id=".$delid);
				$ok=$ok+1;
			}
		}
	
		echo it618_video_getlang('s343').$ok;
	}
	
	if($_GET['ac2']=="down"){
		$ok=0;
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($delid);
			if($it618_video_goods['it618_shopid']!=$ShopId){
				echo $it618_video_lang['s513'];exit;
			}
			if($it618_video_goods['it618_state']==1){
				DB::query("update ".DB::table('it618_video_goods')." set it618_state=0 where id=".$delid);
				$ok=$ok+1;
			}
		}
	
		echo it618_video_getlang('s344').$ok;
	}
}
					

if($_GET['ac1']=="scproduct"){
	$ppp = 8;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$it618sql = "1";
	
	$state0='';$state1='';$state2='';$state3='';$state4='';$state5='';$state6='';$state7='';
	if($_GET['state']==0){$state0='selected="selected"';}
	if($_GET['state']==1){$it618sql .= " and g.it618_state = 0";$state1='selected="selected"';}
	if($_GET['state']==2){$it618sql .= " and g.it618_state = 1";$state2='selected="selected"';}
	if($_GET['state']==3){$it618sql .= " and g.it618_state = 2";$state3='selected="selected"';}
	if($_GET['state']==4){$it618sql .= " and g.it618_isvip = 0";$state4='selected="selected"';}
	if($_GET['state']==5){$it618sql .= " and g.it618_isvip = 1";$state5='selected="selected"';}
	if($_GET['state']==6){$it618sql .= " and g.it618_issecret = 0";$state6='selected="selected"';}
	if($_GET['state']==7){$it618sql .= " and g.it618_issecret = 1";$state7='selected="selected"';}
	
	$orderby0='';$orderby1='';$orderby2='';$orderby3='';
	if($_GET['orderby']==0){$it618orderby = "g.it618_shoporder desc,id desc";$orderby0='selected="selected"';}
	if($_GET['orderby']==1){$it618orderby = "g.it618_salecount desc";$orderby1='selected="selected"';}
	if($_GET['orderby']==2){$it618orderby = "g.it618_views desc";$orderby2='selected="selected"';}
	if($_GET['orderby']==3){$it618orderby = "g.it618_saleprice desc";$orderby3='selected="selected"';}
	
	$count = C::t('#it618_video#it618_video_goods')->count_by_search($it618sql,'',$ShopId,$_GET['it618_class1_id'],$_GET['it618_class2_id'],it618_video_utftogbk($_GET['key']));
	
	if($Shopisale==1){
		$sc_str='<tr><td colspan="2" style="background-color:#f9f9f9; border-bottom:#f3f3f3 1px solid; padding-bottom:6px; padding-top:6px">'.it618_video_getlang('s114').'<font color=red>'.$count.'</font><br>'.it618_video_getlang('s927').'</td></tr><tr><td colspan="2"></td></tr>';
	}else{
		$sc_str='<tr><td colspan="2" style="background-color:#f9f9f9; border-bottom:#f3f3f3 1px solid; padding-bottom:6px; padding-top:6px">'.it618_video_getlang('s114').'<font color=red>'.$count.'</font></td></tr><tr><td colspan="2"></td></tr>';
	}
	
	$n=1;
	foreach(C::t('#it618_video#it618_video_goods')->fetch_all_by_search(
		$it618sql,$it618orderby,$ShopId,$_GET['it618_class1_id'],$_GET['it618_class2_id'],it618_video_utftogbk($_GET['key']),0,0,$startlimit,$ppp
	) as $it618_video_goods) {
		
		if(C::t('#it618_video#it618_video_goods_lesson')->count_by_pid($it618_video_goods['id'])==0){
			$lid=C::t('#it618_video#it618_video_goods_lesson')->insert(array(
				'it618_pid' => $it618_video_goods['id'],
				'it618_name' => $it618_video_lang['s488']
			), true);
			
			DB::query("update ".DB::table('it618_video_goods_video')." set it618_lid=".$lid." where it618_pid=".$it618_video_goods['id']." and it618_lid=0");
			DB::query("update ".DB::table('it618_video_goods')." set it618_lessoncount=1 where id=".$it618_video_goods['id']);
		}
		
		if($it618_video_goods['it618_isbm']==1)$it618_isbm_checked='checked="checked"';else $it618_isbm_checked="";
		if($it618_video_goods['it618_isprotect']==1)$it618_isprotect_checked='checked="checked"';else $it618_isprotect_checked="";
		
		if($it618_video_goods['it618_state']==0)$it618_state='<input type="checkbox" id="state'.$it618_video_goods['id'].'" onClick="savegoodsstate('.$it618_video_goods['id'].')" class="chk_it618"> <label for="state'.$it618_video_goods['id'].'"></label>';
		if($it618_video_goods['it618_state']==1)$it618_state='<input type="checkbox" id="state'.$it618_video_goods['id'].'" onClick="savegoodsstate('.$it618_video_goods['id'].')" checked="checked" class="chk_it618"> <label for="state'.$it618_video_goods['id'].'"></label>';
		if($it618_video_goods['it618_state']==2)$it618_state='<font color=red>'.it618_video_getlang('s105').'</font>';
		
		if($it618_video_goods['it618_xgtype']==0)$it618_xgtype0=' selected="selected"';else $it618_xgtype0="";
		if($it618_video_goods['it618_xgtype']==1)$it618_xgtype1=' selected="selected"';else $it618_xgtype1="";
		if($it618_video_goods['it618_xgtype']==2)$it618_xgtype2=' selected="selected"';else $it618_xgtype2="";
		
		$salecount = C::t('#it618_video#it618_video_sale')->sumcount_by_it618_pid($it618_video_goods['id']);
		$salemoney = C::t('#it618_video#it618_video_sale')->summoney_by_it618_pid($it618_video_goods['id']);

		$jfpricecss='display:none';
		if($it618_video_goods['it618_paytype']==1){
			$jfpricecss	= 'display:';
		}
		
		$it618_isvip='';
		$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
		if(count($vipgroupids)>0){
			$it618_isvip='<br><img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-left:15px">';
		}
		
		$it618_issecret='';
		if($it618_video_goods['it618_issecret']==1){
			$it618_issecret='<br><img src="source/plugin/it618_video/images/secret.png" style="vertical-align:middle;height:18px;margin-left:15px">';
		}
		
		$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
		
		$it618_videotimestr=$it618_video_goods['it618_lessoncount'].''.$it618_video_lang['s489'].$it618_video_goods['it618_videocount'].$it618_video_lang['s108'];
		
		if($it618_video_goods['it618_gtype']==1){
			$it618_gtype=it618_video_getlang('s380');
		}else{
			$it618_gtype=it618_video_getlang('s386');
		}
		
		if($Shopisale==1){
			$typecountall = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_type')." WHERE it618_pid=".$it618_video_goods['id']);
			$typecountok = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_type')." WHERE it618_ison>0 and it618_pid=".$it618_video_goods['id']);
			$goodstypestr='<span onclick="scproduct_type('.$it618_video_goods['id'].')" style="color:#333"><img src="source/plugin/it618_video/images/price.png" style="vertical-align:middle;height:12px;margin-top:-3px;margin-left:1px;margin-right:2px;">'.$it618_video_lang['s710'].' <font color="#aaa">('.$typecountok.'/'.$typecountall.')</font></span>';
			
			$goodstypecss='';
			if($typecountok>0){
				$goodstypecss='display:none';
			}
			$issalebr='<br>';
		}else{
			$goodstypecss='display:none';
			$issalecss='display:none';
		}
		
		$redatmpstr='';
		if($it618_video_goods['it618_state']!=1)$redatmpstr='<a href="'.$tmpurl.'" target="_blank">'.it618_video_getlang('t315').'</a>';
		
		$sc_str.='<tr>
					<td width="48" style="vertical-align:top"><input class="checkbox" type="checkbox" id="chk_del'.$n.'" style="vertical-align:middle" name="delete[]" value="'.$it618_video_goods['id'].'"><label for="chk_del'.$n.'" style="vertical-align:middle">'.$it618_video_goods['id'].'</label>'.$it618_isvip.$it618_issecret.'</td>
					<td style="vertical-align:top">
					<table width="100%">
					<tr>
					<td width="133">
					<a href="'.$tmpurl.'" target="_blank"><img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" width="123" height="76" align="absmiddle" style="border-radius:3px"/></a>
					</td>
					<td style="padding-top:5px">
					'.$goodstypestr.$issalebr.'<span onclick="scproduct_lesson('.$it618_video_goods['id'].')" style="color:#333"><img src="source/plugin/it618_video/images/zj.png" style="vertical-align:middle;height:11px;margin-top:-3px;margin-right:2px;">'.$it618_gtype.'</span> <font color=#aaa>('.$it618_videotimestr.')</font>
					<br><br>
					<span style="float:right;">'.$it618_state.'</span>
					<span onclick="scproduct_edit('.$it618_video_goods['id'].')">'.it618_video_getlang('s351').'</span> '.$redatmpstr.'
					</td>
					</tr>
					<tr><td colspan=2 style="padding-top:6px">
					<input type="text" class="txt" style="width:98%;margin-bottom:4px;border:#f3f3f3 1px solid" name="it618_name['.$it618_video_goods['id'].']" value="'.$it618_video_goods['it618_name'].'">
					<div style="line-height:23px"><span style="'.$goodstypecss.'"><input type="text" class="txt" style="width:50px;margin-right:3px;color:red;" name="it618_saleprice['.$it618_video_goods['id'].']" value="'.$it618_video_goods['it618_saleprice'].'">'.it618_video_getlang('s125').'+<input type="text" class="txt" style="width:40px;margin-right:3px;;color:red" name="it618_score['.$it618_video_goods['id'].']" value="'.$it618_video_goods['it618_score'].'"><select name="it618_jfid['.$it618_video_goods['id'].']">'.it618_video_getjftype($it618_video_goods['it618_jfid']).'</select> '.$it618_video_lang['s1795'].'<input type="text" class="txt" style="width:50px;margin-right:3px;" name="it618_price['.$it618_video_goods['id'].']" value="'.$it618_video_goods['it618_price'].'">'.it618_video_getlang('s125').' </div>
					
					<div style="'.$issalecss.'"><select id="it618_xgtype'.$n.'" name="it618_xgtype['.$it618_video_goods['id'].']" style="margin-top:3px"><option value="0"'.$it618_xgtype0.'>'.it618_video_getlang('s944').'</option><option value="1"'.$it618_xgtype1.'>'.it618_video_getlang('s945').'</option><option value="2"'.$it618_xgtype2.'>'.it618_video_getlang('s946').'</option></select> <input type="text" class="txt" style="width:99px;margin-top:3px" id="it618_xgtime1_'.$n.'" name="it618_xgtime1['.$it618_video_goods['id'].']" readonly="readonly" value="'.$it618_video_goods['it618_xgtime1'].'"> <input type="text" class="txt" style="width:99px;margin-top:3px" id="it618_xgtime2_'.$n.'" name="it618_xgtime2['.$it618_video_goods['id'].']" readonly="readonly" value="'.$it618_video_goods['it618_xgtime2'].'"></div>
					
					<div style="line-height:23px;margin-top:10px">
					<span style="'.$issalecss.'"><div style="line-height:15px">'.it618_video_getlang('s118').''.$it618_video_goods['it618_views'].' '.it618_video_getlang('s119').''.$salecount.''.' '.it618_video_getlang('s120').''.$salemoney.'</span>
					
					 <br><br><span style="float:right;margin-top:-6px">'.$it618_video_lang['s1037'].': <input type="text" class="txt" style="width:30px;margin-right:1px;" name="it618_jfbl['.$it618_video_goods['id'].']" value="'.$it618_video_goods['it618_jfbl'].'">% '.$it618_video_lang['s66'].': <input type="text" class="txt" style="width:30px;margin-right:1px;" name="it618_shoporder['.$it618_video_goods['id'].']" value="'.$it618_video_goods['it618_shoporder'].'"></span><span style="'.$issalecss.'"><input class="checkbox" type="checkbox" style="vertical-align:middle" id="chk_isbm'.$n.'" name="it618_isbm['.$it618_video_goods['id'].']" '.$it618_isbm_checked.' value="1"><label for="chk_isbm'.$n.'" style="vertical-align:middle">'.it618_video_getlang('s862').'</label></span> <input class="checkbox" type="checkbox" id="chk_isprotect'.$n.'" name="it618_isprotect['.$it618_video_goods['id'].']" '.$it618_isprotect_checked.' value="1" style="vertical-align:middle"><label for="chk_isprotect'.$n.'" style="vertical-align:middle">'.it618_video_getlang('s1016').'</label>
					 </div>
					</td></tr>
					</table>
					</td>
					</tr>';

		$n=$n+1;
	}
	
	$funname='getscproductlist';
	
	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$i=1;
		while($i<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".$i;
			if($page==$i)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$i.'/'.$pagecount.'</option>';
			$i=$i+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s510').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_video_getlang('s511').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s511').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	echo $sc_str.'it618_split'.$multipage.'<input type=hidden value='.$n.' id="n" />';
}


if($_GET['ac1']=="scproduct_add"){
	$id=C::t('#it618_video#it618_video_goods')->insert(array(
		'it618_shopid' => $ShopId,
		'it618_shopuid' => $ShopUid,
		'it618_class1_id' => $_GET['it618_class1_id'],
		'it618_class2_id' => $_GET['it618_class2_id'],
		'it618_class1_id1' => $_GET['it618_class1_id1'],
		'it618_class2_id1' => $_GET['it618_class2_id1'],
		'it618_class1_id2' => $_GET['it618_class1_id2'],
		'it618_class2_id2' => $_GET['it618_class2_id2'],
		'it618_class1_id3' => $_GET['it618_class1_id3'],
		'it618_class2_id3' => $_GET['it618_class2_id3'],
		'it618_gtype' => $_GET['it618_gtype'],
		'it618_name' => it618_video_utftogbk($_GET['it618_name']),
		'it618_description' => it618_video_utftogbk($_GET['it618_description']),
		'it618_seokeywords' => it618_video_utftogbk($_GET['it618_seokeywords']),
		'it618_seodescription' => it618_video_utftogbk($_GET['it618_seodescription']),
		'it618_picbig' => $_GET['it618_picbig'],
		'it618_message' => it618_video_utftogbk($_GET['it618_message'],0),
		'it618_time' => $_G['timestamp']
	), true);
	
	if($IsChat==1){
		C::t('#it618_video#it618_video_goods')->update($id,array(
			'it618_isuser' => $_GET['it618_isuser'],
			'it618_isip' => $_GET['it618_isip'],
			'it618_isaddr' => $_GET['it618_isaddr']
		));
	}
	
	for($i=0;$i<=0;$i++){
		if($i==0)$tmpi='';else $tmpi=$i;
		$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
		
		if($get_it618_picbig!=''){
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/smallimage/';
			if (!file_exists($smallpath)) {
				mkdir($smallpath);
			}

			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1));
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$id.'_'.md5($get_it618_picbig).'.'.$file_ext;
			it618_video_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,385,1);
		}

	}
	
	echo it618_video_getlang('s359');exit;
}


if($_GET['ac1']=="scproduct_edit"){
	$pid=intval($_GET['pid']);
	$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
	if($it618_video_goods['it618_shopid']!=$ShopId){
		echo $it618_video_lang['s513'];exit;
	}
	
	for($i=0;$i<=0;$i++){
		if($i==0)$tmpi='';else $tmpi=$i;
		$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
		
		if($it618_video_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
			$tmparr=explode("source",$it618_video_goods['it618_picbig'.$tmpi]);
			$tmparr1=explode("://",$it618_video_goods['it618_picbig'.$tmpi]);
			$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
			
			if(file_exists($it618_picbig)&&count($tmparr1)==1){
				$result=unlink($it618_picbig);
			}
		}
		
		$file_ext=strtolower(substr($it618_video_goods['it618_picbig'.$tmpi],strrpos($it618_video_goods['it618_picbig'.$tmpi], '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext;
		if(file_exists($it618_smallurl)){
			$result=unlink($it618_smallurl);
		}
		
		if($it618_video_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/smallimage/';
			if (!file_exists($smallpath)) {
				mkdir($smallpath);
			}

			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1));
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$pid.'_'.md5($get_it618_picbig).'.'.$file_ext;
			it618_video_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,385,1);
		}

	}
	
	C::t('#it618_video#it618_video_goods')->update($pid,array(
		'it618_shopuid' => $ShopUid,
		'it618_class1_id' => $_GET['it618_class1_id'],
		'it618_class2_id' => $_GET['it618_class2_id'],
		'it618_class1_id1' => $_GET['it618_class1_id1'],
		'it618_class2_id1' => $_GET['it618_class2_id1'],
		'it618_class1_id2' => $_GET['it618_class1_id2'],
		'it618_class2_id2' => $_GET['it618_class2_id2'],
		'it618_class1_id3' => $_GET['it618_class1_id3'],
		'it618_class2_id3' => $_GET['it618_class2_id3'],
		'it618_name' => it618_video_utftogbk($_GET['it618_name']),
		'it618_description' => it618_video_utftogbk($_GET['it618_description']),
		'it618_seokeywords' => it618_video_utftogbk($_GET['it618_seokeywords']),
		'it618_seodescription' => it618_video_utftogbk($_GET['it618_seodescription']),
		'it618_picbig' => $_GET['it618_picbig'],
		'it618_message' => it618_video_utftogbk($_GET['it618_message'],0),
		'it618_time' => $_G['timestamp']
	));
	
	if($IsChat==1){
		C::t('#it618_video#it618_video_goods')->update($pid,array(
			'it618_isuser' => $_GET['it618_isuser'],
			'it618_isip' => $_GET['it618_isip'],
			'it618_isaddr' => $_GET['it618_isaddr']
		));
	}
	
	if($it618_video_goods['it618_issecret']==1){
		$tmparr=explode(",",$_GET['it618_secretusers']);
		for($i=0;$i<count($tmparr);$i++){
			$count=C::t('#it618_video#it618_video_sale')->count_by_uid($tmparr[$i]);
			if($count>0){
				$tmpstr.=$tmparr[$i].',';
			}
		}
		if($tmpstr!='')$tmpstr.='@';
		$tmpstr=str_replace(',@','',$tmpstr);
	
		C::t('#it618_video#it618_video_goods')->update($pid,array(
			'it618_secretusers' => $tmpstr
		));
	}
	
	echo it618_video_getlang('s408');exit;
}


if($_GET['ac1']=="scproduct_lesson_save"){
	$pid=intval($_GET['pid']);
	$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
	if($it618_video_goods['it618_shopid']!=$ShopId){
		echo $it618_video_lang['s513'];exit;
	}
	
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($delid);
		$salecount = $it618_video_goods_lesson['it618_salecount'];
		$salemoney = $it618_video_goods_lesson['it618_salemoney'];
		$typecountall = C::t('#it618_video#it618_video_goods_type')->counttype_by_pid_lid_vid($it618_video_goods_lesson['it618_pid'],$it618_video_goods_lesson['id'],0);
	
		if(!($it618_video_goods_lesson['it618_videocount']>0||$typecountall>0||$salecount>0||$examcount>0)){
			DB::delete('it618_video_goods_lesson', "id=$delid");
			$del=$del+1;
		}
	}
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			C::t('#it618_video#it618_video_goods_lesson')->update($id,array(
				'it618_name' => it618_video_utftogbk($_GET['it618_name'][$id]),
				'it618_url' => it618_video_utftogbk($_GET['it618_url'][$id]),
				'it618_order' => $_GET['it618_order'][$id]
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_type_array = !empty($_GET['newit618_type']) ? $_GET['newit618_type'] : array();
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		
		if(trim($newit618_name_array[$key]) != '') {
			                                        
			C::t('#it618_video#it618_video_goods_lesson')->insert(array(
				'it618_pid' => $pid,
				'it618_type' => $newit618_type_array[$key],
				'it618_name' => it618_video_utftogbk($newit618_name_array[$key]),
				'it618_order' => $newit618_order_array[$key]
			), true);
			$ok2=$ok2+1;
		}
	}
	
	$it618_lessoncount=C::t('#it618_video#it618_video_goods_lesson')->count_by_pid($pid);
	C::t('#it618_video#it618_video_goods')->update($pid,array(
		'it618_lessoncount' => $it618_lessoncount
	));

	echo $it618_video_lang['s33'].$ok1.' '.$it618_video_lang['s34'].$ok2.' '.$it618_video_lang['s35'].$del;exit;
}


if($_GET['ac1']=="sclive"){
	$ppp = 10;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$it618sql = "1";
	
	$state0='';$state1='';$state2='';$state3='';$state4='';
	if($_GET['state']==0){$state0='selected="selected"';}
	if($_GET['state']==1){$it618sql .= " and it618_btime >".$_G['timestamp'];$state1='selected="selected"';}
	if($_GET['state']==2){$it618sql .= " and it618_btime <".$_G['timestamp']." and it618_etime>".$_G['timestamp'];$state2='selected="selected"';}
	if($_GET['state']==3){$it618sql .= " and it618_etime <".$_G['timestamp'];$state3='selected="selected"';}
	if($_GET['state']==4){$it618sql .= " and it618_isok=1 and it618_etime <".$_G['timestamp'];$state4='selected="selected"';}
	
	$chkstate0='';$chkstate1='';$chkstate2='';$chkstate3='';
	if($_GET['chkstate']==0){$chkstate0='selected="selected"';}
	if($_GET['chkstate']==1){$it618sql .= " and it618_chkstate = 0";$chkstate1='selected="selected"';}
	if($_GET['chkstate']==2){$it618sql .= " and it618_chkstate = 1";$chkstate2='selected="selected"';}
	if($_GET['chkstate']==3){$it618sql .= " and it618_chkstate = 2";$chkstate3='selected="selected"';}
	
	$count = C::t('#it618_video#it618_video_live')->count_by_search($it618sql,'',$ShopId,0,0,it618_video_utftogbk($_GET['key']));
	
	$sc_str='<tr><td colspan="2" style="background-color:#f9f9f9; border-bottom:#f3f3f3 1px solid; padding-bottom:6px; padding-top:6px">'.it618_video_getlang('s1319').'<font color=red>'.$count.'</font><br>'.it618_video_getlang('s1320').'</td></tr><tr><td colspan="2"></td></tr>';
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/message.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_video/config/message.php';
	}
	
	if($it618_isok==1&&$it618_body_live_user_isok==1){
		$isliveorder=1;
	}
	
	$n=1;
	foreach(C::t('#it618_video#it618_video_live')->fetch_all_by_search(
		$it618sql,'id desc',$ShopId,0,0,it618_video_utftogbk($_GET['key']),$startlimit,$ppp
	) as $it618_video_live) {
		
		$it618_video_liveset = C::t('#it618_video#it618_video_liveset')->fetch_by_id($it618_video_live['it618_liveset_id']);
		
		if($it618_video_live['it618_isuser']==0){$it618_isuser_selected0='selected="selected"';$isusercolor='#390';$tmpuser=$it618_video_lang['s30'];}else $it618_isuser_selected0="";
		if($it618_video_live['it618_isuser']==1){$it618_isuser_selected1='selected="selected"';$isusercolor='#f30';$tmpuser=$it618_video_lang['s27'];}else $it618_isuser_selected1="";
		if($it618_video_live['it618_isuser']==2){$it618_isuser_selected2='selected="selected"';$isusercolor='#22b1fe';$tmpuser=$it618_video_lang['s28'];}else $it618_isuser_selected2="";
		
		$tmpnamestr='<input type="text" class="txt" style="width:98%;margin-bottom:4px;border:#f1f1f1 1px solid" name="it618_name['.$it618_video_live['id'].']" value="'.$it618_video_live['it618_name'].'"><br><textarea name="it618_description['.$it618_video_live['id'].']" style="width:98%;height:50px;border:#f1f1f1 1px solid">'.$it618_video_live['it618_description'].'</textarea>';
		$tmpuserstr='<select style="color:'.$isusercolor.'" name="it618_isuser['.$it618_video_live['id'].']"><option value=1 '.$it618_isuser_selected1.' style="color:#f30">'.$it618_video_lang['s27'].'</option><option value=2 '.$it618_isuser_selected2.' style="color:#22b1fe">'.$it618_video_lang['s28'].'</option><option value=0 '.$it618_isuser_selected0.' style="color:#390">'.$it618_video_lang['s30'].'</option></select>';
		
		if($it618_video_live['it618_chkstate']==0){
			$it618_chkstate='<font color=red>'.$it618_video_lang['s677'].'</font>';
		}
		
		$it618_state='';$livecode='';
		if($it618_video_live['it618_chkstate']==1){
			$it618_chkstate='<font color=green>'.$it618_video_lang['s678'].'</font>';
			
			if($it618_video_live['it618_btime']>$_G['timestamp']){
				if($it618_video_live['it618_liveset_id']>0){
					if($it618_video_live['it618_btime']-$_G['timestamp']<=$it618_video_liveset['it618_copytime']*60){
						$livecode='<div class="livecode"><a href="javascript:" onclick="setlivecode('.$it618_video_live['id'].')">'.$it618_video_lang['s1867'].'</a></div>';
					}
				}
				
				if($isliveorder==1){
					$ordercount=C::t('#it618_video#it618_video_live_order')->count_by_liveid($it618_video_live['id']);
					$liveorder=' '.$it618_video_lang['s1856'].$ordercount;
				}
				
				$it618_state='<font color=red>'.it618_video_gettime1($it618_video_live['it618_btime']).$it618_video_lang['s1316'].'</font> '.$liveorder;
			}
			
			if($it618_video_live['it618_btime']<$_G['timestamp']&&$_G['timestamp']<$it618_video_live['it618_etime']){
				$tmptime=round(($it618_video_live['it618_etime']-$_G['timestamp'])/60,2);
				$it618_video_lang['s1720']=str_replace("{time}",$tmptime,$it618_video_lang['s1720']);
				$it618_state='<font color=green>'.$it618_video_lang['s1317'].'</font> '.$it618_video_lang['s1720'];
				if($it618_video_live['it618_liveset_id']>0){
					$livecode='<div class="livecode"><a href="javascript:" onclick="setlivecode('.$it618_video_live['id'].')">'.$it618_video_lang['s1867'].'</a></div>';
				}
			}
			
			if($_G['timestamp']>$it618_video_live['it618_etime']){
				if($it618_video_live['it618_isok']==1){
					$it618_state='<font color=#999>'.$it618_video_lang['s1318'].'</font>';
				}else{
					$it618_state='<font color=#fof>'.$it618_video_lang['s1728'].'</font>';
				}
				$tmpnamestr='<div>'.$it618_video_live['it618_name'].'<br>'.$it618_video_live['it618_description'].'</div>';
				$tmpuserstr=$tmpuser;
			}
			
			$m3u8url='';$tmpsavetypestr='';
			if($it618_video_live['it618_etime']>$_G['timestamp']){
				if($it618_video_live['it618_liveset_id']==0){
					$m3u8url='<br>'.$it618_video_lang['s1501'].'<br><textarea name="it618_m3u8url['.$it618_video_live['id'].']" style="width:98%;height:50px;margin-top:3px;border:#f1f1f1 1px solid">'.$it618_video_live['it618_m3u8url'].'</textarea>';
				}
				
				if($it618_video_live['it618_liveset_id']==0||($it618_video_live['it618_ossbucket']==''&&$it618_video_live['it618_ossendpoint']=='')){
					if($it618_video_live['it618_savetype']==1)$it618_savetype_selected1='selected="selected"';else $it618_savetype_selected1="";
					if($it618_video_live['it618_savetype']==2)$it618_savetype_selected2='selected="selected"';else $it618_savetype_selected2="";
					if($it618_video_live['it618_savetype']==3)$it618_savetype_selected3='selected="selected"';else $it618_savetype_selected3="";
					
					$tmpsavetypestr='<br><select name="it618_savetype['.$it618_video_live['id'].']"><option value=1 '.$it618_savetype_selected1.'>'.$it618_video_lang['s1611'].'</option><option value=2 '.$it618_savetype_selected2.'>'.$it618_video_lang['s1612'].'</option><option value=3 '.$it618_savetype_selected3.'>'.$it618_video_lang['s1613'].'</option></select>';
				}
				
				if($it618_video_live['it618_iseditetime']==1||$it618_video_live['it618_liveset_id']==0)$livecode.='<div class="livecode"><a href="javascript:" style="color:red" onclick="setliveetime('.$it618_video_live['id'].','.$it618_video_live['it618_liveset_id'].')">'.$it618_video_lang['s1754'].'</a></div>';
			}
		}
		
		if($it618_video_live['it618_chkstate']==2){
			$it618_chkstate='<font color=blue>'.$it618_video_lang['s679'].'</font>';
		}
		
		$it618_video_goods_lesson=C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($it618_video_live['it618_lid']);
		$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_live['it618_pid']);
		$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_liveid($it618_video_live['id']);
		$liveurl='';
		if($it618_video_goods_video['id']>0){
			$tmpurl=it618_video_getrewrite('video_lesson',$it618_video_goods_video['id'],'plugin.php?id=it618_video:lesson&lid='.$it618_video_goods_video['id']);
			$liveurl='<br><a href="'.$tmpurl.'" target="_blank">'.$it618_video_lang['s746'].'</a>';
		}
		
		if($it618_video_live['it618_ossbucket']!=''&&$it618_video_live['it618_ossendpoint']!=''){
			$livesetstr='<font color=#f60>'.$it618_video_live['it618_livetime'].$it618_video_lang['s1305'].'</font> '.$it618_video_lang['s1272'];
		}else{
			$livesetstr='<font color=#f60>'.$it618_video_live['it618_livetime'].$it618_video_lang['s1305'].'</font> '.$it618_video_lang['s1273'];
		}
		
		$it618_usercode='';
		if($it618_video_live['it618_isuser']!=1){
			if($it618_video_goods_video['it618_usercode']!=''){
				$it618_usercode=' '.$it618_video_lang['s1983'];
			}
		}
		
		$sc_str.='<tr>
						<td width="48" style="vertical-align:top"><input class="checkbox" type="checkbox" id="chk_del'.$n.'" style="vertical-align:middle" name="delete[]" value="'.$it618_video_live['id'].'"><label for="chk_del'.$n.'" style="vertical-align:middle">'.$it618_video_live['id'].'</label></td>
						<td style="vertical-align:top">
						<table width="100%">
						<tr>
						<td width="133" style="vertical-align:top">
						<a href="'.$tmpurl.'" target="_blank"><img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" width="123" height="76" align="absmiddle" style="border-radius:3px"/></a>
						</td>
						<td>
						'.$livesetstr.'<br>
						'.$it618_state.'
						<br><font color=#999>'.date('Y-m-d H:i:s', $it618_video_live['it618_btime']).'<br> '.date('Y-m-d H:i:s', $it618_video_live['it618_etime']).'</font>'.$tmpsavetypestr.'
						</td>
						</tr>
						<tr><td colspan=2 style="padding-top:6px">
						'.$livecode.'
						'.$tmpnamestr.$m3u8url.'
						<br>'.$it618_video_goods['it618_name'].'<br>'.$it618_video_goods_lesson['it618_name'].$liveurl.$it618_usercode.'
						<br>'.$it618_video_liveset['it618_name'].'<br><span style="float:right;margin-top:-6px">'.$it618_chkstate.' '.$tmpuserstr.'</span><font color=#999>'.date('Y-m-d H:i:s', $it618_video_live['it618_time']).'</font>
						</td></tr>
						</table>
						</td>
						</tr>';
		$n=$n+1;
	}
	
	$funname='getsclivelist';
	
	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$i=1;
		while($i<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".$i;
			if($page==$i)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$i.'/'.$pagecount.'</option>';
			$i=$i+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s510').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_video_getlang('s511').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s511').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	echo $sc_str.'it618_split'.$multipage.'<input type=hidden value='.$n.' id="n" />';
}


if($_GET['ac1']=="sclive_save"){
	
	if($_GET['ac2']=="del"){
		$del=0;
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($delid);
			if($it618_video_live['it618_shopid']!=$ShopId){
				echo $it618_video_lang['s513'];exit;
			}
			if($it618_video_live['it618_chkstate']==2){
				DB::delete('it618_video_live', "id=$delid");
				$del=$del+1;
			}
		}
	
		echo it618_video_getlang('s1344').$del;
	}

	if($_GET['ac2']=="edit"){
		$ok=0;
		if(is_array($_GET['it618_name'])) {
			foreach($_GET['it618_name'] as $id => $val) {
				$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($id);
				if($it618_video_live['it618_shopid']!=$ShopId){
					echo $it618_video_lang['s513'];exit;
				}
				C::t('#it618_video#it618_video_live')->update($id,array(
					'it618_name' => it618_video_utftogbk($_GET['it618_name'][$id]),
					'it618_description' => it618_video_utftogbk($_GET['it618_description'][$id]),
					'it618_savetype' => $_GET['it618_savetype'][$id],
					'it618_isuser' => $_GET['it618_isuser'][$id]
				));
				
				$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_liveid($id);
				C::t('#it618_video#it618_video_goods_video')->update($it618_video_goods_video['id'],array(
					'it618_isuser' => $_GET['it618_isuser'][$id]
				));
				
				if(dhtmlspecialchars($_GET['it618_m3u8url'][$id])!=''){
					C::t('#it618_video#it618_video_live')->update($id,array(
						'it618_m3u8url' => it618_video_utftogbk($_GET['it618_m3u8url'][$id])
					));
				}
		
				$ok=$ok+1;
			}
		}
	
		echo it618_video_getlang('s345').$ok;
	}
}


if($_GET['ac1']=="sclive_add"){
	$lid=intval($_GET['lid']);
	$livesetid=intval($_GET['livesetid']);
	
	if($lid>0){
		if($it618_video_goods_lesson=C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid)){
			if($it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_lesson['it618_pid'])){
				if($it618_video_goods['it618_shopid']==$ShopId)$flag=1;
			}
		}
		
		if($flag!=1){
			echo it618_video_getlang('s513');exit;
		}
		
		if($livesetid>0){
			if(C::t('#it618_video#it618_video_shopliveset')->count_ok_by_shopid_livesetid($ShopId,$livesetid)==0){
				echo it618_video_getlang('s513');exit;
			}else{
				$it618_video_liveset=C::t('#it618_video#it618_video_liveset')->fetch_by_id($livesetid);	
			}
		}else{
			if($it618_video_shop['it618_livetime']==0){
				echo it618_video_getlang('s513');exit;
			}
			
			$it618_livetime=$_GET['it618_livetime'];
		}
	}else{
		echo it618_video_getlang('s513');exit;
	}
	
	if($livesetid==0){
		if($_GET['it618_livetime']>$it618_video_shop['it618_livetime']){
			echo $it618_video_lang['s1500'];exit;
		}
	}
	
	$timetmp1=explode(" ",$_GET['it618_btime']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	
	$btime=mktime($timetmp12[0], $timetmp12[1], $timetmp12[2], $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	if($btime<$_G['timestamp']+$it618_sqtime*60){
		$it618_video_lang['s1308']=str_replace("{sqtime}",$it618_sqtime.$it618_video_lang['s1305'],$it618_video_lang['s1308']);
		echo $it618_video_lang['s1308'];exit;
	}
	
	if($livesetid>0){
		$it618_livetime=$it618_video_liveset['it618_livetime'];
	}else{
		$it618_livetime=$_GET['it618_livetime'];
	}
	
	$id=C::t('#it618_video#it618_video_live')->insert(array(
		'it618_shopid' => $ShopId,
		'it618_liveset_id' => $livesetid,
		'it618_pid' => $it618_video_goods['id'],
		'it618_lid' => $it618_video_goods_lesson['id'],
		'it618_name' => it618_video_utftogbk($_GET['it618_name']),
		'it618_btime' => $btime,
		'it618_etime' => $btime+$it618_livetime*60,
		'it618_livetime' => $it618_livetime,
		'it618_iseditetime' => $it618_video_liveset['it618_iseditetime'],
		'it618_savetype' => $_GET['it618_savetype'],
		'it618_m3u8url' => $_GET['it618_m3u8url'],
		'it618_ossbucket' => $it618_video_liveset['it618_ossbucket'],
		'it618_ossendpoint' => $it618_video_liveset['it618_ossendpoint'],
		'it618_description' => it618_video_utftogbk($_GET['it618_description']),
		'it618_isuser' => $_GET['it618_isuser'],
		'it618_usercode' => trim($_GET['it618_usercode']),
		'it618_chkstate' => 0,
		'it618_time' => $_G['timestamp']
	), true);
	
	if($Shopischeck_live!=1){
		C::t('#it618_video#it618_video_live')->update($id,array(
			'it618_streamname' => md5($it618_video_liveset['it618_accesskey'].$id.FORMHASH)
		));
		
		$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($id);
		
		if($livesetid>0){
			if($it618_video_live['it618_ossbucket']!=''&&$it618_video_live['it618_ossendpoint']!=''){
				$returnstr=it618_video_addliverecordconfig($it618_video_live);
				if($returnstr!=1){
					echo $returnstr;exit;
				}
			}
		}
		
		C::t('#it618_video#it618_video_goods_video')->insert(array(
			'it618_pid' => $it618_video_live['it618_pid'],
			'it618_lid' => $it618_video_live['it618_lid'],
			'it618_liveid' => $it618_video_live['id'],
			'it618_livebtime' => $btime,
			'it618_isuser' => $_GET['it618_isuser'],
			'it618_usercode' => trim($_GET['it618_usercode']),
			'it618_ischat' => 1,
			'it618_islive' => 1
		), true);
		
		C::t('#it618_video#it618_video_live')->update($id,array(
			'it618_chkstate' => 1
		));
	}
	
	echo 'it618_splitokit618_split'.it618_video_getlang('s1309');exit;
}
?>