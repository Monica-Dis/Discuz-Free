<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$query = DB::query("SELECT w.* FROM ".DB::table('it618_video_media_wmf')." w join ".DB::table('it618_video_media_shopwmf')." s on w.id=s.it618_wmf_id and s.it618_shopid=$ShopId where w.it618_isok=1 ORDER BY w.it618_order");
while($it618_video_media_wmf = DB::fetch($query)) {
	
	$summtscount = C::t('#it618_video#it618_video_media')->sum_mtscount_by_search('it618_wmf_id='.$it618_video_media_wmf['id'],'',$ShopId);
	$summtssize = C::t('#it618_video#it618_video_media')->sum_mtssize_by_search('it618_wmf_id='.$it618_video_media_wmf['id'],'',$ShopId);
	if($summtscount=='')$summtscount=0;
	
	$wmfstr.='<tr class="hover">
			<td width="180"><font color="green"><b>'.$it618_video_media_wmf['it618_name'].'</b></font></td>
			<td style="color:#888">'.$it618_video_media_wmf['it618_about'].'<br><br>'.$it618_video_lang['s589'].'<font color="red">'.$it618_video_media_wmf['it618_size'].'M</font><br>'.$it618_video_lang['s590'].'<br><font color="green">'.$it618_video_media_wmf['it618_type'].'</font><br><br><a href="plugin.php?id=it618_video:sc_media_add'.$adminsid.'&wid='.$it618_video_media_wmf['id'].'" style="background-color:#0AF;color:#fff;padding:6px 15px;">'.$it618_video_lang['s578'].'</a><br><br></td>
			<td width="40"></td>
			<td style="color:#999" width="150">'.$it618_video_lang['s585'].$summtscount.'<br>'.$it618_video_lang['s586'].round(($summtssize/1024/1024),2).'M</td>
			</tr>
			';
}

if($wmfstr=='')$wmfstr='<tr><td colspan="15" style="color:red;font-size:18px">'.$it618_video_lang['s579'].'</td></tr>';

echo '<table class="tb tb2" style="clear: both;margin-top: 5px;width:100%;">
<tr><th colspan="15" class="partition">'.$it618_video_lang['s666'].'</th></tr>
<tr class="header"><th>'.$it618_video_lang['s667'].'</th><th>'.$it618_video_lang['s668'].'</th><th></th><th>'.$it618_video_lang['s674'].'</th></tr>
'.$wmfstr.'
</table>';

require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>