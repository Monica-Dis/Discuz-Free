<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_video = $_G['cache']['plugin']['it618_video'];
require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

$mid=intval($_GET['mid']);
$wap=intval($_GET['wap']);

if($it618_video_media_iframe=C::t('#it618_video#it618_video_media_iframe')->fetch_by_id($mid)){
	if($it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_media_iframe['it618_shopid'])){
		if($it618_video_shop['it618_isiframemedia']!=1){
			exit;
		}
	}else{
		exit;
	}
}

if($_G['uid']!=$it618_video_shop['it618_uid']){
	
	if($it618_video_media_iframe['it618_type']==1){
		$tmptype=$it618_video_lang['s1246'];
	}else{
		$tmptype=$it618_video_lang['s1245'];
	}
	
	if($it618_video_media_iframe['it618_isuser']==1){
		if($_G['uid']<=0){
			return '<div style="width:100%;padding-top:10px;padding-bottom:10px"><font color=red>'.$it618_video_lang['s1243'].$tmptype.$it618_video_media_iframe['it618_name'].'</font></div>';
		}
	}
}

if(video_is_mobile()){ 
	$wap=1;
}

if($it618_video_media_iframe['it618_type']==1){
	if($wap==1){
		$getmediatiestr='<iframe src="plugin.php?id=it618_video:audiotie&type='.$type.'&mfid='.$it618_video_media_iframe['id'].'&wap='.$wap.'" style="border:0;width:100%;height:45px" scrolling="no" frameborder=0></iframe>';
	}else{
		$getmediatiestr='<iframe src="plugin.php?id=it618_video:audiotie&type='.$type.'&mfid='.$it618_video_media_iframe['id'].'&wap='.$wap.'" style="border:0;width:760px;height:45px" scrolling="no" frameborder=0></iframe>';
	}
	echo $getmediatiestr;exit;
}else{
	$it618_url=$it618_video_media_iframe['it618_url'];
	$tmparr=explode("<iframe",$it618_url);
	if(count($tmparr)>1){
		$isiframe=1;
		$it618_url=str_replace("'",'"',$it618_url);
		if($wap==1){
			$getmediatiestr=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe style="width:100%;height:210px;margin-top:10px;" src="\1" frameborder=0 allowfullscreen=1>',$it618_url);
		}else{
			$getmediatiestr=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe style="width:760px;height:430px;margin-top:10px;margin-bottom:10px" src="\1" frameborder=0 allowfullscreen=1>',$it618_url);
		}
	}else{
		$tmparr1=explode(".m3u8",$it618_url);
		if(count($tmparr1)>1){
			$it618_url1=str_replace("https://",'http://',$it618_url);
			if($it618_video_media_mts=C::t('#it618_video#it618_video_media_mts')->fetch_by_url($it618_url1)){
				$it618_video_media=C::t('#it618_video#it618_video_media')->fetch_by_id($it618_video_media_mts['it618_media_id']);
				$it618_video_media_wmf=C::t('#it618_video#it618_video_media_wmf')->fetch_by_id($it618_video_media['it618_wmf_id']);
				dsetcookie('it618_hlskms'.md5($it618_video_media['it618_mediaid'].$it618_video_media_wmf['it618_accesskey']),1,31536000);
			}
		}
		$it618_url=it618_video_cdnkeyurl($it618_url);
		
		if($type==1){
			$autoplay='false';
		}else{
			if($it618_video_media_iframe['it618_isautoplay']==1)$autoplay='true';else $autoplay='false';
		}
		
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php';
		}
		
		$player_version=$it618_video_lang['playerversion'];
	
		if($wap==1){
			$getmediatiestr='<html>
			<head>
			<title>'.$it618_video_media_iframe['it618_name'].'</title>
			<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'" />
			</head>
			
			<link rel="stylesheet" href="https://g.alicdn.com/de/prismplayer/'.$player_version.'/skins/default/aliplayer-min.css" />
			<script type="text/javascript" src="https://g.alicdn.com/de/prismplayer/'.$player_version.'/aliplayer-min.js" charset="utf-8"></script>
			<style type="text/css">
			  body{padding:0;margin:0;overflow:hidden}
			  .prism-player .prism-cover{
				background-color:none;
				display:block;
			  }
			  
			  .prism-player .prism-marker-text{
				display:none;
			  }
			</style>
			<body>
			<div id="J_prismPlayer" style="width:100%;height:100%;padding:0;margin:0;overflow:hidden"></div>
			
			<script>
			var videourl="'.$it618_url.'";
			var livetmp="'.$it618_video_media_iframe['it618_islive'].'";
			
			if(livetmp==1){
				livetmp = true;
			}else{
				livetmp = false;	
			}
			
			var layout=[
				{
				  "name": "bigPlayButton",
				  "align": "cc"
				},
				{
				  "name": "H5Loading",
				  "align": "cc"
				},
				{
				  "name": "errorDisplay",
				  "align": "tlabs",
				  "x": 0,
				  "y": 0
				},
				{
				  "name": "infoDisplay"
				},
				{
				  "name": "tooltip",
				  "align": "blabs",
				  "x": 0,
				  "y": 56
				},
				{
				  "name": "thumbnail"
				},
				{
				  "name": "controlBar",
				  "align": "blabs",
				  "x": 0,
				  "y": 0,
				  "children": [
					{
					  "name": "progress",
					  "align": "blabs",
					  "x": 0,
					  "y": 44
					},
					{
					  "name": "playButton",
					  "align": "tl",
					  "x": 15,
					  "y": 12
					},
					{
					  "name": "timeDisplay",
					  "align": "tl",
					  "x": 10,
					  "y": 7
					},
					{
					  "name": "fullScreenButton",
					  "align": "tr",
					  "x": 10,
					  "y": 12
					},
					{
					  "name": "setting",
					  "align": "tr",
					  "x": 15,
					  "y": 12
					},
					{
					  "name": "volume",
					  "align": "tr",
					  "x": 5,
					  "y": 10
					}
				  ]
				}
			  ];
			
			player = new Aliplayer({
				"id": "J_prismPlayer",
				"source": videourl,
				"autoplay": '.$autoplay.',
				"isLive": livetmp,
				"rePlay": false,
				"playsinline": true,
				"preload": true,
				"controlBarVisibility": "hover",
				"useH5Prism": true,
				"skinLayout": layout
			  }, function (player) {
			  }
			);
			</script>
			';
		}else{	
			if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php')){
				require DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php';
			}
			
			$isflash=0;
			if(!strpos($_SERVER['HTTP_USER_AGENT'],'WindowsWechat')!==false){
				$agentarr=explode(",",$player_typeagent);
				for($i=0;$i<count($agentarr);$i++){
					$tmparrtmp=explode($agentarr[$i],$it618_url);
					if(count($tmparrtmp)>1){
						$isflash=1;
						break;
					}
				}
			}
			
			$player_version=$it618_video_lang['playerversion'];
					
			$getmediatiestr='<html>
			<head>
			<title>'.$it618_video_media_iframe['it618_name'].'</title>
			<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'" />
			</head>
			
			<link rel="stylesheet" href="https://g.alicdn.com/de/prismplayer/'.$player_version.'/skins/default/aliplayer-min.css" />
			<script type="text/javascript" src="https://g.alicdn.com/de/prismplayer/'.$player_version.'/aliplayer-min.js" charset="utf-8"></script>
			<style type="text/css">
			  body{padding:0;margin:0;overflow:hidden}
			  .prism-player .prism-cover{
				background-color:none;
				display:block;
			  }
			  
			  .prism-player .prism-marker-text{
				display:none;
			  }
			</style>
			<body>
			<div id="J_prismPlayer" style="width:100%;height:100%;padding:0;margin:0;overflow:hidden"></div>
			
			<script type="text/javascript">
			var playurl="'.$it618_url.'";
			var isflash='.$isflash.';
			var livetmp="'.$it618_video_media_iframe['it618_islive'].'";
				
			var Flashtmp=false;
			var H5tmp=true;
			if(isflash==1){
				Flashtmp=true;
				H5tmp=false;
			}
			if(livetmp==1){
				livetmp = true;
				Flashtmp=true;
				H5tmp=false;
			}else{
				livetmp = false;	
			}
			
			var layout=[
			{
			  "name": "bigPlayButton",
			  "align": "cc"
			},
			{
			  "name": "controlBar",
			  "align": "blabs",
			  "x": 0,
			  "y": 0,
			  "children": [
				{
				  "name": "progress",
				  "align": "tlabs",
				  "x": 0,
				  "y": 0
				},
				{
				  "name": "playButton",
				  "align": "tl",
				  "x": 15,
				  "y": 26
				},
				{
				  "name": "nextButton",
				  "align": "tl",
				  "x": 10,
				  "y": 26
				},
				{
				  "name": "timeDisplay",
				  "align": "tl",
				  "x": 10,
				  "y": 24
				},
				{
				  "name": "fullScreenButton",
				  "align": "tr",
				  "x": 10,
				  "y": 25
				},
				{
				  "name": "streamButton",
				  "align": "tr",
				  "x": 10,
				  "y": 23
				},
				{
				  "name": "volume",
				  "align": "tr",
				  "x": 10,
				  "y": 25
				}
			  ]
			},
			{
			  "name": "fullControlBar",
			  "align": "tlabs",
			  "x": 0,
			  "y": 0,
			  "children": [
				{
				  "name": "fullTitle",
				  "align": "tl",
				  "x": 25,
				  "y": 6
				},
				{
				  "name": "fullNormalScreenButton",
				  "align": "tr",
				  "x": 24,
				  "y": 13
				},
				{
				  "name": "fullTimeDisplay",
				  "align": "tr",
				  "x": 10,
				  "y": 12
				},
				{
				  "name": "fullZoom",
				  "align": "cc"
				}
			  ]
			}
		  ];
			
			if(H5tmp==true) layout=[
				{
				  "name": "bigPlayButton",
				  "align": "cc"
				},
				{
				  "name": "H5Loading",
				  "align": "cc"
				},
				{
				  "name": "errorDisplay",
				  "align": "tlabs",
				  "x": 0,
				  "y": 0
				},
				{
				  "name": "infoDisplay"
				},
				{
				  "name": "tooltip",
				  "align": "blabs",
				  "x": 0,
				  "y": 56
				},
				{
				  "name": "thumbnail"
				},
				{
				  "name": "controlBar",
				  "align": "blabs",
				  "x": 0,
				  "y": 0,
				  "children": [
					{
					  "name": "progress",
					  "align": "blabs",
					  "x": 0,
					  "y": 44
					},
					{
					  "name": "playButton",
					  "align": "tl",
					  "x": 15,
					  "y": 12
					},
					{
					  "name": "timeDisplay",
					  "align": "tl",
					  "x": 10,
					  "y": 7
					},
					{
					  "name": "fullScreenButton",
					  "align": "tr",
					  "x": 10,
					  "y": 12
					},
					{
					  "name": "setting",
					  "align": "tr",
					  "x": 15,
					  "y": 12
					},
					{
					  "name": "volume",
					  "align": "tr",
					  "x": 5,
					  "y": 10
					}
				  ]
				}
			  ];
			
			player = new Aliplayer({
				"id": "J_prismPlayer",
				"source": playurl,
				"autoplay": '.$autoplay.',
				"isLive": livetmp,
				"rePlay": false,
				"playsinline": true,
				"preload": true,
				"controlBarVisibility": "hover",
				"useFlashPrism": Flashtmp,
				"useH5Prism": H5tmp,
				"skinLayout": layout,
			  }, function (player) {
			  }
			);
			</script>
			</body></html>
			';
		}

	}
	
	echo $getmediatiestr;
}
?>