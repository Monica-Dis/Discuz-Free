<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$osstype=intval($_GET['osstype']);

if($osstype==0){
	$osspath='audiomedia/';
	$lang_s1696=$it618_video_lang['s1696'];
	$lang_s610=$it618_video_lang['s610'];
	$lang_s563=$it618_video_lang['s563'];
	$lang_s564=$it618_video_lang['s564'];
	$lang_t28=$it618_video_lang['t28'];
}

if($osstype==1){
	$osspath='videomedia/';
	$lang_s1696=$it618_video_lang['s1198'];
	$lang_s610=$it618_video_lang['s1199'];
	$lang_s563=$it618_video_lang['s1194'];
	$lang_s564=$it618_video_lang['s1195'];
	$lang_t28=$it618_video_lang['s1196'];
}

if($osstype==2){
	$osspath='attachmedia/';
	$lang_s1696=$it618_video_lang['s2021'];
	$lang_s610=$it618_video_lang['s2022'];
	$lang_s563=$it618_video_lang['s2023'];
	$lang_s564=$it618_video_lang['s2024'];
	$lang_t28=$it618_video_lang['s2018'];
}

if(C::t('#it618_video#it618_video_media_aclass')->count_by_shopid_osstype($ShopId,$osstype)==0){
	it618_cpmsg($lang_s1696, "plugin.php?id=it618_video:sc_media_aclass$adminsid&osstype=".$osstype, 'error');
}

if(isset($_GET['oid'])){
	if(C::t('#it618_video#it618_video_media_shopaoss')->count_ok_by_shopid_aossid($ShopId,$_GET['oid'])==0){
		it618_cpmsg($it618_video_lang['s1697'], "plugin.php?id=it618_video:sc_media_aoss$adminsid", 'error');
	}else{
		$it618_video_media_aoss=C::t('#it618_video#it618_video_media_aoss')->fetch_by_id($_GET['oid']);
		$type=$it618_video_media_aoss['it618_type'];
		$size=$it618_video_media_aoss['it618_size']*1024*1024;	
		
		$aossstr=$lang_s610.'<b><font color="red">'.$it618_video_media_aoss['it618_name'].'</font></b> <font color=#888>'.$it618_video_media_aoss['it618_about'].' '.$lang_s563.'<font color="red">'.$it618_video_media_aoss['it618_size'].'M</font>'.$it618_video_lang['s573'].$lang_s564.'<font color="red">'.$it618_video_media_aoss['it618_type'].'</font></font>';
		
		$typestr=$it618_video_lang['s1699'].$it618_video_media_aoss['it618_type'].$it618_video_lang['s1701'];
		$sizestr=$it618_video_lang['s1700'].$it618_video_media_aoss['it618_size'].'M'.$it618_video_lang['s1701'];
	}
}else{
	it618_cpmsg($it618_video_lang['s1702'], "plugin.php?id=it618_video:sc_media_aoss$adminsid", 'error');
}

foreach(C::t('#it618_video#it618_video_media_aclass')->fetch_all_by_shopid_osstype($ShopId,$osstype) as $it618_video_media_aclass) {
	$classoption.='<option value=\''.$it618_video_media_aclass['id'].'\'>'.$it618_video_media_aclass['it618_classname'].'</option>';
}

$expiration=date('Y-m-d H:i:s', $_G['timestamp']+3600*24*10);
$expiration=str_replace(" ","T",$expiration).'Z';
$tmpcode=md5($_G['timestamp'].FORMHASH.rand());
		
C::t('#it618_video#it618_video_mediawork')->insert(array(
	'it618_code' => $tmpcode
), true);

echo '
<script>
var oid="'.$_GET['oid'].'";
var siteurl="'.$_G['siteurl'].'";
var tmpcode="'.$tmpcode.'";
var ShopId="'.$ShopId.'";
var osspath="'.$osspath.'";
var classoption="'.$classoption.'";
var type="'.$type.'";
var size="'.$size.'";
var typestr="'.$typestr.'";
var sizestr="'.$sizestr.'";
</script>

<link rel="stylesheet" type="text/css" href="source/plugin/it618_video/alioss/style.css"/>
<script type="text/javascript" src="source/plugin/it618_video/js/jquery.js"></script>

<table class="tb tb2" style="clear: both;margin-top: 5px;width:100%;">
<tr><th colspan="15" class="partition">'.$it618_video_lang['t28'].'<span style="float:right; font-weight:normal; color:red">'.$it618_video_lang['s609'].'</span></th></tr>
<td colspan="15">
'.$aossstr.'
</td>
</tr>
<tr class="header"><th>'.$it618_video_lang['s596'].'</th><th>'.$it618_video_lang['s598'].'</th><th>'.$it618_video_lang['s580'].'</th><th width="260">'.$it618_video_lang['s600'].'</th><th>'.$it618_video_lang['s601'].'</th></tr>
<tbody id="ossfile">

</tbody>
<tr>
<td colspan="15">
<div id="container">
	<a id="selectfiles" href="javascript:void(0);" class="btn">'.$it618_video_lang['s662'].'</a>
	<a id="postfiles" href="javascript:void(0);" class="btn">'.$it618_video_lang['s663'].'</a>
    <a href="javascript:void(0);" onclick="if(confirm(\''.$it618_video_lang['s664'].'\'))location.reload()" class="btn" style="background-color:#e8e8e8;color:#000">'.$it618_video_lang['s665'].'</a>
</div>
</td>
</tr>
</table>
<form id="it618_media">
<input type="hidden" name="oid" value="'.$_GET['oid'].'">
<input type="hidden" name="osstype" value="'.$osstype.'">
<input type="hidden" name="code" value="'.$tmpcode.'">
<input type="hidden" id="it618_name" name="name">
<input type="hidden" id="it618_classid" name="classid">
<input type="hidden" id="it618_medianame" name="medianame">
<input type="hidden" id="it618_mediasize" name="mediasize">
</form>
';
?>

<script type="text/javascript" src="source/plugin/it618_video/alioss/crypto-min.js"></script>
<script type="text/javascript" src="source/plugin/it618_video/alioss/hmac-min.js"></script>
<script type="text/javascript" src="source/plugin/it618_video/alioss/sha1-min.js"></script>
<script type="text/javascript" src="source/plugin/it618_video/alioss/base64.js"></script>
<script type="text/javascript" src="source/plugin/it618_video/alioss/plupload/js/plupload.full.min.js"></script>
<script>
var accessid,aosspath,host,policyBase64,signature,randomfilename;
	
var uploader = new plupload.Uploader({
	runtimes : 'html5,flash,silverlight,html4',
	browse_button : 'selectfiles', 
	multi_selection: true,
	container: document.getElementById('container'),
	flash_swf_url : 'source/plugin/it618_video/alioss/plupload/Moxie.swf',
	silverlight_xap_url : 'source/plugin/it618_video/alioss/plupload/Moxie.xap',
	url : host,
	filters: {
		mime_types: [
			{title: "Video/Audio files", extensions: type}
		],
		max_file_size : size,
		prevent_duplicates: true
	},
	max_retries:3,
	init: {
		PostInit: function() {
			document.getElementById('ossfile').innerHTML = '';
			document.getElementById('postfiles').onclick = function() {
				if(accessid!=''){
					uploader.start();
				}
				return false;
			};
		},
		FilesAdded: function(up, files) {
			plupload.each(files, function(file) {
				var filename=file.name.substring(0,file.name.lastIndexOf("."));
				
				document.getElementById('ossfile').innerHTML 
				+='<tr id="tr' + file.id + '">'
				+'<td><select id="classid' + file.id + '">' + classoption + '</select></td>'
				+'<td><input type="text" style="width:90%" id="name' + file.id + '" value="' + filename + '"></td>'
				+'<td>' + file.name + ' (' + plupload.formatSize(file.size) + ')</td>'
				+'<td id="' + file.id + '"><div class="progress"><div class="progress-bar" style="width: 0%"><span></span></div></div></td>'
				+'<td><img id="del' + file.id + '" data-val="' + file.id + '" class="delbtn" src="source/plugin/it618_video/alioss/del.png" height="15" style="cursor:pointer"></td>'
				+'</tr>';
			});
			
			IT618_VIDEO(document).on('click','.delbtn',function(){
				IT618_VIDEO(this).parent().parent().remove();
				var id=IT618_VIDEO(this).attr("data-val");
				uploader.removeFile(uploader.getFile(id));
			});
		},
		BeforeUpload: function(up, file) {
			set_upload_param(up, file.name);
		},
		UploadProgress: function(up, file) {
			var d = document.getElementById(file.id);
			d.getElementsByTagName('span')[0].innerHTML = file.percent + "%";
			
			var prog = d.getElementsByTagName('div')[0];
			var progBar = prog.getElementsByTagName('div')[0]
			progBar.style.width= 2*file.percent+'px';
			progBar.setAttribute('aria-valuenow', file.percent);
			
			document.getElementById("del"+file.id).style.display='none';
		},
		FileUploaded: function(up, file, info) {
			if (info.status >= 200 || info.status < 200){
				document.getElementById("classid"+file.id).disabled=true;
				document.getElementById("name"+file.id).readOnly=true;
				document.getElementById("name"+file.id).style.border="none";
				document.getElementById("name"+file.id).style.backgroundColor="#fff";
				
				document.getElementById("it618_classid").value=document.getElementById("classid"+file.id).value;
				document.getElementById("it618_name").value=randomfilename;
				document.getElementById("it618_medianame").value=document.getElementById("name"+file.id).value;
				document.getElementById("it618_mediasize").value=file.size;
				
				document.getElementById(file.id).getElementsByTagName('span')[0].innerHTML = 'ok';
				
				IT618_VIDEO.get(siteurl+"plugin.php?id=it618_video:ajax", {ac:"getformhash"},function (data, textStatus){
					var tmparr=data.split("it618_split");
					IT618_VIDEO.post(siteurl+"plugin.php?id=it618_video:ajax&ac=addmediaaudio<?php echo $adminsid?>&formhash="+tmparr[1],IT618_VIDEO("#it618_media").serialize(),function (data, textStatus){
					var tmparr=data.split("it618_split");
					if(tmparr[1]=='ok')document.getElementById(file.id).getElementsByTagName('span')[0].innerHTML = 'ok!';
				}, "html");	
				}, "html");	
			}else{
				document.getElementById(file.id).getElementsByTagName('span')[0].innerHTML = info.response;
			} 
		},
		Error: function(up, err) {
			if(err.code=="-600"){
				alert(sizestr);
			}else if(err.code=="-601"){
				alert(typestr);
			}else{
				alert(err.code + "\n" + err.message);
			}
		}
	}
});
uploader.init();

IT618_VIDEO.get(siteurl+"plugin.php?id=it618_video:ajax<?php echo $adminsid?>&oid="+oid+"&code="+tmpcode, {ac:"getmediacode"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	accessid= tmparr[1];
	var accesskey= tmparr[2];
	aosspath = tmparr[3];
	host = tmparr[4];
	var policyText = {
		"expiration": "<?php echo $expiration?>",
		"conditions": [
		["content-length-range", 0, <?php echo $size?>]
		]
	};
	policyBase64 = Base64.encode(JSON.stringify(policyText))
	var message = policyBase64;
	var bytes = Crypto.HMAC(Crypto.SHA1, message, accesskey, { asBytes: true }) ;
	signature = Crypto.util.bytesToBase64(bytes);
}, "html");	

function random_string(len) {
	len = len || 32;
	var chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz123456789';   
	var maxPos = chars.length;
	var pwd = '';
	for (i = 0; i < len; i++) {
		pwd += chars.charAt(Math.floor(Math.random() * maxPos));
	}
	return pwd;
}

function set_upload_param(up, filename)
{
	var pos = filename.lastIndexOf('.');
    var suffix = ''
    if (pos != -1) {
        suffix = filename.substring(pos);
    }
	randomfilename = random_string(15) + suffix;

    new_multipart_params = {
		'key' : aosspath+osspath+'shop'+ShopId+'/'+tmpcode+'/'+randomfilename,
		'policy': policyBase64,
		'OSSAccessKeyId': accessid, 
		'success_action_status' : '200',
		'signature': signature,
    };

    up.setOption({
        'url': host,
        'multipart_params': new_multipart_params
    });
}
</script>

<?php
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>