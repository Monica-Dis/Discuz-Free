<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

$did=intval($_GET['did']);
$isok=0;
if($it618_video_goods_data=DB::fetch_first("SELECT * FROM ".DB::table('it618_video_goods_data')." WHERE id=".$did)){
	
	if(!($it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($it618_video_goods_data['it618_vid']))){
		echo it618_video_getlang('s470').' <a href="'.$homeurl.'">'.$it618_video_lang['s18'].'</a>';exit;
	}
	$pid=$it618_video_goods_video['it618_pid'];
	
	if($it618_video_goods_data['it618_isuser']==0){
		$isok=1;
	}
	
	if($it618_video_goods_data['it618_isuser']==2){
		$errstr=$it618_video_lang['s1504'];
		if($_G['uid']>0){
			$isok=1;
		}
	}
	
	if($it618_video_goods_data['it618_isuser']==1){
		$homeurl=it618_video_getrewrite('video_home','','plugin.php?id=it618_video:index');
		
		if(!($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id_state($pid,1))){
			echo it618_video_getlang('s470').' <a href="'.$homeurl.'">'.$it618_video_lang['s18'].'</a>';exit;
		}else{
			if(!it618_video_issecretok($it618_video_goods)){
				echo it618_video_getlang('s470').' <a href="'.$homeurl.'">'.$it618_video_lang['s18'].'</a>';exit;
			}
			
			$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
			if($it618_video_shop['it618_state']!=2||$it618_video_shop['it618_htstate']!=1){
				echo it618_video_getlang('s470').' <a href="'.$homeurl.'">'.$it618_video_lang['s18'].'</a>';exit;
			}
		}
		
		$isgoodsprice=0;
		if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
			$isgoodsprice=1;
		}
		
		$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
		if($_G['uid']>0){
			$videopower=it618_video_getpower($_G['uid'],$it618_video_goods_video['it618_pid'],$it618_video_goods_video['it618_lid'],$it618_video_goods_video['id']);
			if(count($vipgroupids)>0){
				$tmpgrouparr=it618_video_getisvipuser($vipgroupids);
				$isvipuser=count($tmpgrouparr[0]);
			}
		}
		
		$errstr=$it618_video_lang['s1505'];
		
		if($isgoodsprice>0){
			if($videopower['state']>0){
				$isok=1;
			}else{
				if($isvipuser>0){
					$isok=1;
				}
			}
		}else{
			$isok=1;
		}
		
		if($_G['uid']>0){
			$it618_video_shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_uid($_G['uid']);
			if($it618_video_goods['it618_shopid']==$it618_video_shoptmp['id']){
				$isok=1;
			}
		}
		
		if($isok!=1){
			$tmpurl=it618_video_getrewrite('video_product',$pid,'plugin.php?id=it618_video:product&pid='.$pid);
			echo $errstr.' <a href="'.$tmpurl.'">'.$it618_video_lang['t169'].'</a>';exit;
		}
	}
}else{
	$errstr=$it618_video_lang['s1506'];
}

if($isok!=1){
	$tmpurl=it618_video_getrewrite('video_product',$pid,'plugin.php?id=it618_video:product&pid='.$pid);
	echo $errstr.' <a href="'.$tmpurl.'">'.$it618_video_lang['t169'].'</a>';exit;
}else{
	C::t('#it618_video#it618_video_goods_data')->update_it618_views_by_id($did);
	
	$it618_dataurl=it618_video_gbktoutf(it618_video_getsignedurl($it618_video_goods_data['it618_dataurl']));
	dheader("location:$it618_dataurl");

	$tmparr=explode("it618_video",$it618_dataurl);
	if(count($tmparr)>1){
		$tmparr=explode("source",$it618_dataurl);
		if(count($tmparr)>1){
			$it618_dataurl=DISCUZ_ROOT.'./source'.$tmparr[1];
		}
		$file_ext=strtolower(substr($it618_dataurl,strrpos($it618_dataurl, '.')+1)); 
		it618_video_filedown($it618_dataurl,'data-pid-'.$pid.'-did-'.$did.'.'.$file_ext,$file_ext);
	}else{
		dheader("location:$it618_dataurl");
	}
}
?>