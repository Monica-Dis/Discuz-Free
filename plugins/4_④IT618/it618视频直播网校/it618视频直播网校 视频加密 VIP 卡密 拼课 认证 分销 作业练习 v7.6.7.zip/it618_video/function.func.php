<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_video;

$it618_video = $_G['cache']['plugin']['it618_video'];
$creditname=$_G['setting']['extcredits'][$it618_video['video_credit']]['title'];
require_once DISCUZ_ROOT.'./source/plugin/it618_video/lang.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/template.func.php';

function it618_video_getisvipuser($vipgroupids){
	global $_G,$it618_video,$it618_video_lang;

	$okvipgroupids = array(array(),array());
	
	if(count($vipgroupids)>0){

		$extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
	
		$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
		$groupterms = dunserialize($memberfieldforum['groupterms']);
		unset($memberfieldforum);
		$expgrouparray = $expirylist = $termsarray = array();
	
		if(!empty($groupterms['ext']) && is_array($groupterms['ext'])) {
			$termsarray = $groupterms['ext'];
		}
		if(!empty($groupterms['main']['time']) && (empty($termsarray[$_G['groupid']]) || $termsarray[$_G['groupid']] > $groupterm['main']['time'])) {
			$termsarray[$_G['groupid']] = $groupterms['main']['time'];
		}
		
		foreach($termsarray as $expgroupid => $expiry) {
			if($expiry <= TIMESTAMP) {
				$expgrouparray[] = $expgroupid;
			}
		}
	
		$groupids = array();
		foreach($_G['cache']['usergroups'] as $groupid => $usergroup) {
			if(!empty($usergroup['pubtype'])) {
				$groupids[] = $groupid;
			}
		}
		
		if(!empty($groupterms['ext'])) {
			foreach($groupterms['ext'] as $extgroupid => $time) {
				$expirylist[$extgroupid] = array('timestamp' => $time, 'time' => dgmdate($time, 'd'), 'type' => 'ext', 'noswitch' => $time < TIMESTAMP);
			}
		}
		
		if(!empty($groupterms['main'])) {
			$expirylist[$_G['groupid']] = array('timestamp' => $groupterms['main']['time'], 'time' => dgmdate($groupterms['main']['time'], 'd'), 'type' => 'main');
		}
		
		$expiryids = array_keys($expirylist);
		$groupids = array_merge($extgroupids, $expiryids, $groupids);
		
		if($groupids) {
			foreach(C::t('common_usergroup')->fetch_all($groupids) as $group) {
				$groupid=$group['groupid'];
				
				if(in_array($groupid, $vipgroupids)){
					
					$isgroupok=1;
					if($group['type']!='system'&&$group['type']!='member'){
						$timestamp=$expirylist[$group['groupid']]['timestamp'];
						$grouptime=$expirylist[$group['groupid']]['time'];
						
						if($timestamp-3600*24*365*60>$_G['timestamp']||$grouptime==''){
							$grouptime=$it618_video_lang['s1153'];
						}elseif($timestamp<$_G['timestamp']){
							$isgroupok=0;
						}
					}else{
						$grouptime='';
					}
					if($isgroupok==1){
						$okvipgroupids[0][]=$groupid;
						$okvipgroupids[1][]=$grouptime;
					}
				}
			}
		}
		
		if(!in_array($_G['groupid'], $okvipgroupids[0])){
			if(in_array($_G['groupid'], $vipgroupids)){
				$okvipgroupids[0][]=$_G['groupid'];
				$timestamp=$_G['member']['groupexpiry'];
				if($timestamp>0){
					$timestamp= dgmdate($timestamp, 'd');
				}else{
					$timestamp=$it618_video_lang['s1153'];
				}
				$okvipgroupids[1][]=$timestamp;
			}
		}

	}
	
	return $okvipgroupids;
}

function it618_video_getgoodsvipgroupids($it618_video_goods){
	global $_G,$it618_video;
	
	$vipgroupids = array();
	
	$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
	
	if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0||$it618_video_shop['it618_issale']==0){
	
		$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_vipgroup')." WHERE it618_pid=".$it618_video_goods['id']." and it618_isok=1");
		while($it618_video_goods_vipgroup =	DB::fetch($query)) {
			if($it618_video_goods_vipgroup['it618_groupid']>0){
				if(!in_array($it618_video_goods_vipgroup['it618_groupid'], $vipgroupids)){
					$vipgroupids[]=$it618_video_goods_vipgroup['it618_groupid'];
				}
			}
		}
		
		for($i=0;$i<=3;$i++){
			if($i==0)$tmpi='';else $tmpi=$i;
			if($it618_video_goods['it618_class1_id'.$tmpi]>0){
				$query = DB::query("SELECT * FROM ".DB::table('it618_video_class_vipgroup')." WHERE it618_class1_id=".$it618_video_goods['it618_class1_id'.$tmpi]." and it618_isok=1");
				while($it618_video_class_vipgroup =	DB::fetch($query)) {
					if($it618_video_class_vipgroup['it618_groupid']>0){
						if(!in_array($it618_video_class_vipgroup['it618_groupid'], $vipgroupids)){
							$vipgroupids[]=$it618_video_class_vipgroup['it618_groupid'];
						}
					}
				}
			}
		}
	}
	
	return $vipgroupids;
}

function it618_video_groupsalepower($pid){
	$vipgroupids_zk = array();$vipgroupids_sale = array();
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_group_salepower')." where it618_shoptype='video' and it618_pid=$pid and it618_isok=1");
	while($it618_group_group_salepower = DB::fetch($query)) {
		if(!in_array($it618_group_group_salepower['it618_groupid'], $vipgroupids_sale)){
			$vipgroupids_sale[]=$it618_group_group_salepower['it618_groupid'];
		}
	}
	
	if(count($vipgroupids_sale)>0){
		$query = DB::query("SELECT * FROM ".DB::table('it618_group_group_zk')." where it618_shoptype='video' and it618_pid=$pid and it618_zk>0");
		while($it618_group_group_zk = DB::fetch($query)) {
			if(!in_array($it618_group_group_zk['it618_groupid'], $vipgroupids_zk)){
				$vipgroupids_zk[]=$it618_group_group_zk['it618_groupid'];
			}
		}
		
		$vipgroupids=array_merge($vipgroupids_zk,$vipgroupids_sale);
	
		$okvipgroupids=it618_video_getisvipuser($vipgroupids);
		
		if(count($okvipgroupids[0])==0){
			if(count($vipgroupids_zk)>0){
				return 2;
			}else{
				return 1;
			}
		}
	}
}

function it618_video_pay($type,$title){
	if(!file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php')){
		return;
	}
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
	$tmpstr=getpaytype();
	
	$tmparr=explode("it618getpaytype",$tmpstr);
	if(count($tmparr)>1){
		$tmpstr=$tmparr[0];
		
		if($type=='pay'){
			$paystr='<tr id="payselect">
			<td>'.$title.'</td>
			<td>
			'.$tmpstr.'
			</td>
			</tr>';
		}
		
		if($type=='paywap'){
			$paystr='<tr id="payselect"><td colspan=2>'.$tmpstr.'</td></tr>';
		}
		
		if($type=='gwc'){
			$paystr='<div class="buy-block" id="payselect">
					<div class="buy-block-title"><h3>'.$title.'</h3></div>
					<div style="padding:10px">'.$tmpstr.'</div>
					</div>';
		}
		
		if($type=='gwcwap'){
			$paystr='<table width="100%" class="gwctable" bgcolor="#FFFFFF" id="payselect">
					<tr><td><table width="100%">
					<tr class="gwctrtitle">
					<th style="padding-left:3px">'.$title.'</th>
					</tr>
					</table></td></tr><tr><td style="padding:3px">
					'.$tmpstr.'
					</td></tr></table>';
		}
	}else{
		$paystr=$tmpstr.'<span id="payselect"></span>';
	}
    
	return $paystr;
}

function it618_video_getlivecontent($liveid,$wap=0){
	global $_G,$it618_video,$it618_video_lang;
	
	if($it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($liveid)){
		$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_liveid($it618_video_live['id']);
		$it618_video_goods_lesson=C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($it618_video_live['it618_lid']);
		$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_live['it618_pid']);
		$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
		
		if($it618_video_goods_video['it618_videoimg']!=''){
			$goodspic=$it618_video_goods_video['it618_videoimg'];
		}else{
			$goodspic=it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']);	
		}
		
		if($wap==0){
			$livestate='';
			if($it618_video_live['it618_btime']>$_G['timestamp']){
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $it618_video_live['it618_btime']);
				
				$livestate='<div class="livecountdown" style="background-color:rgba(10,10,10,0.5); width:300px; padding:6px; margin-left:150px; border-radius:10px;">
							<span>00</span>
							<em>'.$it618_video_lang['t308'].'</em>
							<span>00</span>
							<em>'.$it618_video_lang['t309'].'</em>
							<span>00</span>
							<em>'.$it618_video_lang['t310'].'</em>
							<span>00</span>
							<em>'.$it618_video_lang['t311'].'</em>
							<span>00</span>
						  </div>';
			}
			
			if($it618_video_live['it618_btime']<$_G['timestamp']&&$_G['timestamp']<$it618_video_live['it618_etime']){
				$livestate='<div style="background-color:rgba(10,10,10,0.5); width:200px; padding:6px; margin-left:200px; border-radius:10px;font-size:18px; color:#fff;">
							<img src="source/plugin/it618_video/images/live.gif" /> '.$it618_video_lang['s1317'].'
						  </div>';
			}
			
			$lessonurl=it618_video_getrewrite('video_lesson',$it618_video_goods_video['id'],'plugin.php?id=it618_video:lesson&lid='.$it618_video_goods_video['id']);
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
			
			$livecontent='<div style="position:absolute;">
				<img width="590" height="338" border="0" src="'.$goodspic.'">
				</div>
			   <div style="position:absolute;width:590px; height:278px;background-color:rgba(50,50,50,0.6);text-align:center;"><div style="position:absolute; top:55px;width:590px; text-align:center; font-size:22px; color:#fff">'.$it618_video_live['it618_name'].'</div>
			  <div class="divlive" style="position: absolute;top:120px;left: 0;width: 100%;text-align:center; color:#fff; font-size:23px">
			  '.$livestate.'
			   <a href="'.$lessonurl.'" class="salebtn" style="margin-top:10px; margin-left:239px" target="_blank">'.$it618_video_lang['s1831'].'</a>
			   </div>
			   </div>
			   <div style="position:absolute; bottom:0px;width:570px;font-size:16px; color:#fff; background-color:rgba(10,10,10,0.5); height:40px; padding:10px 10px"><a class="bottomkca" title="'.$it618_video_goods['it618_name'].'" href="'.$tmpurl.'" target="_blank">'.$it618_video_lang['s1832'].''.cutstr($it618_video_goods['it618_name'],30,'...').' ></a><img src="'.$it618_video_shop['it618_ulogo'].'" height="40" style="border-radius:20px; margin-right:10px" /><span style="line-height:40px;font-size:16px;">'.cutstr($it618_video_shop['it618_name'],10,'...').'</span></div>';
		}else{
			$livestate='';
			if($it618_video_live['it618_btime']>$_G['timestamp']){
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $it618_video_live['it618_btime']);
				
				$livestate='<div class="livecountdown">
							<span style="color:#f30">00</span>
							<em style="color:#888">'.$it618_video_lang['t308'].'</em>
							<span style="color:#f30">00</span>
							<em style="color:#888">'.$it618_video_lang['t309'].'</em>
							<span style="color:#f30">00</span>
							<em style="color:#888">'.$it618_video_lang['t310'].'</em>
							<span style="color:#f30">00</span>
							<em style="color:#888">'.$it618_video_lang['t311'].'</em>
							<span style="color:#f30">00</span>
						  </div>';
			}
			
			if($it618_video_live['it618_btime']<$_G['timestamp']&&$_G['timestamp']<$it618_video_live['it618_etime']){
				$livestate='<img src="source/plugin/it618_video/images/live.gif" height="15" style="margin-top:-3px" /> <font color=#ccc style="font-size:10px">'.$it618_video_lang['s1317'].'</font>';
			}
			
			$lessonurl=it618_video_getrewrite('video_lesson',$it618_video_goods_video['id'],'plugin.php?id=it618_video:lesson&lid='.$it618_video_goods_video['id']);
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
			
			$livecontent='<td width="146" style="padding-top:13px;padding-bottom:13px;border-bottom:#f3f3f3 1px solid;position:relative">
			<a href="'.$lessonurl.'" target="_blank"><img width="138" border="0" style="border-radius:3px;" src="'.$goodspic.'"></a>
			<div style="position:absolute;top:13px;width:138px;background-color:rgba(0,0,0,0.1);text-align:center; height:78px"><a href="'.$lessonurl.'" target="_blank"><img src="source/plugin/it618_video/images/play.png" style="width:35px; border-radius:20px; margin-top:22px;"/></a>
			</div></td>
			<td style="padding-top:11px;vertical-align:top;border-bottom:#f3f3f3 1px solid">
			<div style="margin-bottom:3px;line-height:20px;height:40px;"><a href="'.$lessonurl.'" target="_blank" style="font-size:14px;color:#333">'.cutstr($it618_video_live['it618_name'],58,'...').'</a></div>
			<div style="font-size:12px;color:#999;margin-top:0px;">
			<div style="font-size:11px;line-height:15px;margin-bottom:10px;">'.$livestate.'</div>
			<div style="margin-top:-3px"><img src="'.$it618_video_shop['it618_ulogo'].'" height="18" style="border-radius:10px; margin-right:3px;margin-top:-5px" />'.cutstr($it618_video_shop['it618_name'],26,'...').'</div></div>
			</td>';
		}

		return $livecontent.'it618_split'.$btimestr.'it618_split'.$etimestr;
	}	
}

function it618_video_getgoodstypename($it618_video_goods_type){
	global $_G,$it618_video,$it618_video_lang;
	
	$pid=$it618_video_goods_type['it618_pid'];
	$lid=$it618_video_goods_type['it618_lid'];
	$vid=$it618_video_goods_type['it618_vid'];
	
	$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
	$name=$it618_video_goods['it618_name'];
	
	if($lid==0&&$vid==0){
		$type=$it618_video_lang['s2117'];
	}
	
	if($lid>0&&$vid==0){
		$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
		$name.=' -> '.$it618_video_goods_lesson['it618_name'];
		if($ispaytitle==1)$name=$it618_video_goods_lesson['it618_name'];
		$type=$it618_video_lang['s2118'];
	}
	
	if($lid>0&&$vid>0){
		$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
		$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($vid);
		if($it618_video_goods_video['it618_liveid']>0){
			$it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
			$videoname=$it618_video_live['it618_name'];
		}else{
			$videoname=$it618_video_goods_video['it618_name'];
		}
		$name.=' -> '.$it618_video_goods_lesson['it618_name'].' -> '.$videoname;
		if($ispaytitle==1)$name=$videoname;
		$type=$it618_video_lang['s2119'];
	}
	
	$gtypename = it618_video_gettypename($it618_video_goods_type['id']);
	
	return $name.' '.$gtypename;
}

function it618_video_getsmsstr($strtmp,$length){
	if($length>0){
		return cutstr($strtmp,$length,'');
	}
	return $strtmp;
}

function it618_video_issecretok($it618_video_goods){
	global $_G,$it618_video,$it618_video_lang;
	
	if($it618_video_goods['it618_issecret']==1){
		$it618_secretusers=explode(",",$it618_video_goods['it618_secretusers']);
		
		if($_G['uid']>0){
			if(!in_array($_G['uid'], $it618_secretusers)){
				if($it618_video_goods['it618_shopuid']!=$_G['uid']){
					$video_shopadmin=explode(",",$it618_video['video_shopadmin']);
					if(!in_array($_G['uid'], $video_shopadmin)){
						return false;
					}
				}
			}
		}else{
			return false;
		}
	}
	
	return true;
}

function it618_video_updategoodscount($it618_video_sale){	
	if($it618_video_sale['it618_gtypeid']>0){
		$salecount = C::t('#it618_video#it618_video_sale')->sumcount_by_it618_gtypeid($it618_video_sale['it618_gtypeid']);
		if($salecount=='')$salecount=0;
		
		DB::query("update ".DB::table('it618_video_goods_type')." set it618_salecount=".$salecount." where id=".$it618_video_sale['it618_gtypeid']);
		DB::query("update ".DB::table('it618_video_goods_type')." set it618_count=it618_count-".$it618_video_sale['it618_count']." where it618_count>0 and id=".$it618_video_sale['it618_gtypeid']);
	}
	
	$pid=$it618_video_sale['it618_pid'];
	$lid=$it618_video_sale['it618_lid'];
	$vid=$it618_video_sale['it618_vid'];
	
	$salecount = C::t('#it618_video#it618_video_sale')->sumcount_by_it618_pid($pid);
	$salemoney = C::t('#it618_video#it618_video_sale')->summoney_by_it618_pid($pid);
	if($salecount=='')$salecount=0;
	if($salemoney=='')$salemoney=0;
	DB::query("update ".DB::table('it618_video_goods')." set it618_salecount=".$salecount.",it618_salemoney=".$salemoney." where id=".$pid);
	
	if($lid>0&&$vid==0){
		$salecount = C::t('#it618_video#it618_video_sale')->sumcount_by_it618_lid($lid);
		$salemoney = C::t('#it618_video#it618_video_sale')->summoney_by_it618_lid($lid);
		if($salecount=='')$salecount=0;
		if($salemoney=='')$salemoney=0;
		DB::query("update ".DB::table('it618_video_goods_lesson')." set it618_salecount=".$salecount.",it618_salemoney=".$salemoney." where id=".$lid);
	}
	
	if($lid>0&&$vid>0){
		$salecount = C::t('#it618_video#it618_video_sale')->sumcount_by_it618_vid($vid);
		$salemoney = C::t('#it618_video#it618_video_sale')->summoney_by_it618_vid($vid);
		if($salecount=='')$salecount=0;
		if($salemoney=='')$salemoney=0;
		DB::query("update ".DB::table('it618_video_goods_video')." set it618_salecount=".$salecount.",it618_salemoney=".$salemoney." where id=".$vid);
	}
}

function it618_video_getetime($timetype,$time){
	if($timetype==1)return $time*60;
	if($timetype==2)return $time*60*60;
	if($timetype==3)return $time*60*60*24;
	if($timetype==4)return $time*60*60*24*30;
	if($timetype==5)return $time*60*60*24*365;
	if($time==0)return 0;
}

function it618_video_getedays($timetype,$time){
	if($timetype==1)return 0;
	if($timetype==2)return 0;
	if($timetype==3)return $time;
	if($timetype==4)return $time*30;
	if($timetype==5)return $time*365;
	if($time==0)return 365*90;
}

function it618_video_getpowertime($time){
	global $_G,$it618_video,$it618_video_lang;
	
	$tmp1=round(($time-$_G['timestamp'])/(3600*24),2);
	$tmp2=$it618_video_lang['s1157'];
	if($tmp1<1){
		$tmp1=round(($time-$_G['timestamp'])/3600,2);
		$tmp2=$it618_video_lang['s1158'];
		if($tmp1<1){
			$tmp1=round(($time-$_G['timestamp'])/60,2);
			$tmp2=$it618_video_lang['s1159'];
		}
	}
	
	$powertime[0]=$tmp1;
	$powertime[1]=$tmp2;
	
	return $powertime;
}

function it618_video_getpower_sale($uid,$pid,$lid,$vid){
	global $_G,$it618_video,$it618_video_lang;
	
	$videopower_sale['state']=0;
	
	if($it618_video_goods_time=C::t('#it618_video#it618_video_goods_time')->fetch_by_uid_pid_lid_vid($uid,$pid,0,0)){
		if($it618_video_goods_time['it618_etime']==0){
			$videopower_sale['state']=1;
			$videopower_sale['about']=$it618_video_lang['s811'];
			return $videopower_sale;
		}
	}
	
	if($lid>0){
		if($it618_video_goods_time=C::t('#it618_video#it618_video_goods_time')->fetch_by_uid_pid_lid_vid($uid,$pid,$lid,0)){
			if($it618_video_goods_time['it618_etime']==0){
				$videopower_sale['state']=1;
				$videopower_sale['about']=$it618_video_lang['s1540'];
				return $videopower_sale;
			}
		}
	}
	
	if($vid>0){
		if($it618_video_goods_time=C::t('#it618_video#it618_video_goods_time')->fetch_by_uid_pid_lid_vid($uid,$pid,$lid,$vid)){
			if($it618_video_goods_time['it618_etime']==0){
				$videopower_sale['state']=1;
				$videopower_sale['about']=$it618_video_lang['s1541'];
				return $videopower_sale;
			}
		}
	}
	
	$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
	$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
	if(count($vipgroupids)>0){
		$tmpgrouparr=it618_video_getisvipuser($vipgroupids);
		$isvipuser=count($tmpgrouparr[0]);
		if($isvipuser>0){
			$videopower_sale['state']=1;
			$videopower_sale['about']=$it618_video_lang['s1572'];
			return $videopower_sale;
		}
	}
	
	return $videopower_sale;
}

function it618_video_getpower($uid,$pid,$lid,$vid){
	global $_G,$it618_video,$it618_video_lang;
	
	$videopower['state']=0;
	$videopower['time']=$_G['username'].' '.$it618_video_lang['s1600'];
	
	if($it618_video_goods_time=C::t('#it618_video#it618_video_goods_time')->fetch_by_uid_pid_lid_vid($uid,$pid,0,0)){
		if($it618_video_goods_time['it618_etime']==0){
			$videopower['state']=1;
			$videopower['time']=$_G['username'].' '.$it618_video_lang['s1154'];
			
			return $videopower;
		}else{
			if($_G['timestamp']<$it618_video_goods_time['it618_etime']){
				$videopower['state']=2;
				$powertime=it618_video_getpowertime($it618_video_goods_time['it618_etime']);
				$videopower['time']=$_G['username'].' '.$it618_video_lang['s1155'].'<font color=red>'.$powertime[0].$powertime[1].'</font>'.' '.date('Y-m-d H:i:s', $it618_video_goods_time['it618_etime']);
				
				$it618_etime1=$it618_video_goods_time['it618_etime'];
			}else{
				$it618_etime1=$_G['timestamp'];
			}
		}
	}
	
	if($lid>0){
		if($it618_video_goods_time=C::t('#it618_video#it618_video_goods_time')->fetch_by_uid_pid_lid_vid($uid,$pid,$lid,0)){
			if($it618_video_goods_time['it618_etime']==0){
				$videopower['state']=1;
				$videopower['time']=$_G['username'].' '.$it618_video_lang['s1154'];
				
				return $videopower;
			}else{
				if($it618_etime1<$it618_video_goods_time['it618_etime']){
					$videopower['state']=2;
					$powertime=it618_video_getpowertime($it618_video_goods_time['it618_etime']);
					$videopower['time']=$_G['username'].' '.$it618_video_lang['s1155'].'<font color=red>'.$powertime[0].$powertime[1].'</font>'.' '.date('Y-m-d H:i:s', $it618_video_goods_time['it618_etime']);
					
					$it618_etime2=$it618_video_goods_time['it618_etime'];
				}else{
					$it618_etime2=$_G['timestamp'];
				}
			}
		}
	}
	
	if($vid>0){
		if($it618_video_goods_time=C::t('#it618_video#it618_video_goods_time')->fetch_by_uid_pid_lid_vid($uid,$pid,$lid,$vid)){
			if($it618_video_goods_time['it618_etime']==0){
				$videopower['state']=1;
				$videopower['time']=$_G['username'].' '.$it618_video_lang['s1154'];
				
				return $videopower;
			}else{
				if($it618_etime2<$it618_video_goods_time['it618_etime']){
					$videopower['state']=2;
					$powertime=it618_video_getpowertime($it618_video_goods_time['it618_etime']);
					$videopower['time']=$_G['username'].' '.$it618_video_lang['s1155'].'<font color=red>'.$powertime[0].$powertime[1].'</font>'.' '.date('Y-m-d H:i:s', $it618_video_goods_time['it618_etime']);
				}
			}
		}
	}
	
	return $videopower;
}

function it618_video_gettypename($it618_gtypeid){
	global $_G,$it618_video_lang;
	
	$it618_video_goods_type=C::t('#it618_video#it618_video_goods_type')->fetch_by_id($it618_gtypeid);
	
	if($it618_video_goods_type['it618_timetype']==1)$it618_name=$it618_video_goods_type['it618_time'].$it618_video_lang['s1144'];
	if($it618_video_goods_type['it618_timetype']==2)$it618_name=$it618_video_goods_type['it618_time'].$it618_video_lang['s1145'];
	if($it618_video_goods_type['it618_timetype']==3)$it618_name=$it618_video_goods_type['it618_time'].$it618_video_lang['s1146'];
	if($it618_video_goods_type['it618_timetype']==4)$it618_name=$it618_video_goods_type['it618_time'].$it618_video_lang['s1147'];
	if($it618_video_goods_type['it618_timetype']==5)$it618_name=$it618_video_goods_type['it618_time'].$it618_video_lang['s1148'];
	if($it618_video_goods_type['it618_timetype']==6)$it618_name=$it618_video_lang['s1153'];
	
	if($it618_video_goods_type['it618_typename']!='')$it618_name=$it618_video_goods_type['it618_typename'];
		
	return $it618_name;
}

function it618_video_getgoodsabout($pid,$lid,$vid){
	global $_G,$it618_video_lang;
	
	if($lid==0&&$vid==0){
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
		$tmpaboutstr='<font color=#999>'.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'</font>';
		$typestr=$it618_video_lang['s1870'];
	}
	
	if($lid>0&&$vid==0){
		$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
		$tmpaboutstr='<font color=#999>'.$it618_video_lang['s489'].': </font>'.$it618_video_goods_lesson['it618_name'].' <font color=#999>'.it618_video_getvideocounttime($it618_video_goods_lesson['it618_videocount'],$it618_video_goods_lesson['it618_videotime']).'</font>';
		$typestr=$it618_video_lang['s1871'];
	}
	
	if($lid>0&&$vid>0){
		$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
		$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($vid);
		if($it618_video_goods_video['it618_liveid']>0){
			$it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
			$videoname=$it618_video_live['it618_name'];
		}else{
			$videoname=$it618_video_goods_video['it618_name'];
		}
		$tmpaboutstr='<font color=#999>'.$it618_video_lang['s489'].': </font>'.$it618_video_goods_lesson['it618_name'].' <font color=#999>-></font> <font color=#999>'.$it618_video_lang['s108'].': </font>'.$videoname;
		$typestr=$it618_video_lang['s1872'];
	}
	
	$goodsabout['about']=$tmpaboutstr;
	$goodsabout['type']=$typestr;
		
	return $goodsabout;
}

function it618_video_qrxf($saleid){
	global $_G,$IsGroup,$it618_video;
	
	$it618_video_sale=C::t('#it618_video#it618_video_sale')->fetch_by_id($saleid);
	
	if($it618_video_sale['it618_gtypeid']>0){
		$it618_video_goods_type=C::t('#it618_video#it618_video_goods_type')->fetch_by_id($it618_video_sale['it618_gtypeid']);
		$timevalue=it618_video_getetime($it618_video_goods_type['it618_timetype'],$it618_video_goods_type['it618_time']*$it618_video_sale['it618_count']);
	}else{
		$timevalue=0;
	}
	
	if($it618_video_goods_time=C::t('#it618_video#it618_video_goods_time')->fetch_by_uid_pid_lid_vid($it618_video_sale['it618_uid'],$it618_video_sale['it618_pid'],$it618_video_sale['it618_lid'],$it618_video_sale['it618_vid'])){
		if($timevalue==0){
			$it618_etime=0;
		}else{
			if($it618_video_goods_time['it618_etime']>$_G['timestamp']){
				$it618_etime=$it618_video_goods_time['it618_etime']+$timevalue;
			}else{
				$it618_etime=$_G['timestamp']+$timevalue;
			}
		}
		
		DB::query("update ".DB::table('it618_video_goods_time')." set it618_etime=".$it618_etime." where id=".$it618_video_goods_time['id']);
	}else{
		if($timevalue==0){
			$it618_etime=0;
		}else{
			$it618_etime=$_G['timestamp']+$timevalue;
		}
		
		C::t('#it618_video#it618_video_goods_time')->insert(array(
			'it618_shopid' => $it618_video_sale['it618_shopid'],
			'it618_pid' => $it618_video_sale['it618_pid'],
			'it618_lid' => $it618_video_sale['it618_lid'],
			'it618_vid' => $it618_video_sale['it618_vid'],
			'it618_uid' => $it618_video_sale['it618_uid'],
			'it618_etime' => $it618_etime
		), true);	
	}
	
	if($IsGroup==1&&$it618_video_sale['it618_lid']==0&&$it618_video_sale['it618_vid']==0){
		if($it618_video_sale['it618_gtypeid']>0){
			$days=it618_video_getedays($it618_video_goods_type['it618_timetype'],$it618_video_goods_type['it618_time']*$it618_video_sale['it618_count']);
		}else{
			$days=365*90;
		}
		
		if($days>0){
			require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
			$query = DB::query("SELECT * FROM ".DB::table('it618_group_group')." where it618_video_pids!=''");
			while($it618_group_group =	DB::fetch($query)) {
				$videopids=explode(",",$it618_group_group['it618_video_pids']);
				if(in_array($it618_video_sale['it618_pid'], $videopids)){
					it618_group_salejl('videopid',$it618_video_sale['id'],$it618_group_group['it618_groupid'],$days);
				}
			}
		}
	}
	
	if($it618_video_sale['it618_tel']=='')return;
	
	$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_sale['it618_shopid']);
	$ShopTCBL=$it618_video_shop['it618_tcbl'];
	
	$allmoney=$it618_video_sale['it618_sfmoney'];
	$tcmoney=round((($ShopTCBL*$allmoney)/100), 2);
	$it618_money=$allmoney-$tcmoney;
	
	DB::query("update ".DB::table('it618_video_sale')." set it618_tcbl=".$ShopTCBL.",it618_tc=".$tcmoney." where id=".$saleid);
	
	if($it618_money>0)DB::query("update ".DB::table('it618_video_shop')." set it618_money=it618_money+".$it618_money." where id=".$it618_video_sale['it618_shopid']);
	
	if($it618_video_sale['it618_score']>0){
		$tmpscore=($it618_video_sale['it618_score']*$it618_video_sale['it618_count'])-intval($ShopTCBL*($it618_video_sale['it618_score']*$it618_video_sale['it618_count'])/100);
		C::t('common_member_count')->increase($it618_video_shop['it618_uid'], array(
			'extcredits'.$it618_video_sale['it618_jfid'] => $tmpscore)
		);
	}
	
	if($it618_video_sale['it618_jfbl']>0){
		$it618_jfbl=intval($it618_video_sale['it618_jfbl']*$it618_video_sale['it618_sfmoney']/100);
		C::t('common_member_count')->increase($it618_video_sale['it618_uid'], array(
			'extcredits'.$it618_video['video_credit'] => $it618_jfbl)
		);
		C::t('common_member_count')->increase($it618_video_shop['it618_uid'], array(
			'extcredits'.$it618_video['video_credit'] => (0-$it618_jfbl))
		);
	}
	
	if($it618_video_sale['it618_tuijid']>0){
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
		Union_TuiTC_OK($saleid,$it618_video_shop['it618_uid']);
	}

	$tmpmoney=$it618_video_sale['it618_sfmoney'];
	
	if($tmpmoney>0){
		if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
		}
		
		if($union_video_isok==1&&$tmpmoney>=$union_video_money){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
			Union_SaleTC('it618_video',$tmpmoney,$it618_video_sale['id'],$it618_video_sale['it618_uid']);
		}
	}
}

function it618_video_getjftype($jfid=0){
	global $_G,$it618_video_lang;
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_jfhl')." where it618_isok=1 ORDER BY it618_order");
	while($it618_video_jfhl = DB::fetch($query)) {
		$jfname=$_G['setting']['extcredits'][$it618_video_jfhl['it618_jfid']]['title'];
		
		if($jfname!=''){
			if($jfid==$it618_video_jfhl['it618_jfid'])$selectedstr='selected="selected"';else $selectedstr='';
			$tmpstr.='<option value="'.$it618_video_jfhl['it618_jfid'].'" '.$selectedstr.'>'.$jfname.'</option>';
		}
	}
	
	return '<option value="0">'.$it618_video_lang['s364'].'</option>'.$tmpstr;
}

function it618_video_getvideopower($it618_video_goods_video,$it618_video_goods){
	global $_G,$it618_video_lang;
	
	$isgoodsprice=0;
	if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
		$isgoodsprice=1;
	}
	
	$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
	if($_G['uid']>0){
		$videopower=it618_video_getpower($_G['uid'],$it618_video_goods_video['it618_pid'],$it618_video_goods_video['it618_lid'],$it618_video_goods_video['id']);
		if(count($vipgroupids)>0){
			$tmpgrouparr=it618_video_getisvipuser($vipgroupids);
			$isvipuser=count($tmpgrouparr[0]);
		}
	}
	
	if($it618_video_goods_video['it618_liveid']>0){
		$it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
		$it618_isuser=$it618_video_live['it618_isuser'];
	}else{
		$it618_isuser=$it618_video_goods_video['it618_isuser'];
	}
	
	if($it618_isuser==0){
		$isok=1;
	}
	
	if($it618_isuser==2){
		if($_G['uid']>0){
			$isok=1;
		}
	}
	
	if($it618_isuser==1){
		if($isgoodsprice>0){
			if($videopower['state']>0){
				$isok=1;
			}else{
				if(count($vipgroupids)>0){
					if($isvipuser>0){
						$isok=1;
					}
				}
			}
		}else{
			$isok=1;
		}
		
		if($_G['uid']>0){
			$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
			if($_G['uid']==$it618_video_shop['it618_uid']){
				$isok=1;
			}
		}
	}
	
	return $isok;
}

function it618_video_isprotect($isgoodsprice,$videopower,$isvipuser){
	global $_G,$it618_video_lang;
	
	if($isgoodsprice>0){
		if($_G['uid']>0){
			if($videopower['state']>0){
				return false;
			}else{
				if($isvipuser>0){
					return false;
				}else{
					return true;
				}
			}
		}else{
			return true;
		}
	}else{
		return false;
	}
}

function it618_video_getvipzk($pid){
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_group_zk')." where it618_shoptype='video' and it618_pid=$pid and it618_zk>0 order by it618_zk");
	while($it618_group_group_zk = DB::fetch($query)) {
		$vipzkgroupids[] = $it618_group_group_zk['it618_groupid'];
		
		$okvipgroupids=it618_video_getisvipuser($vipzkgroupids);
		if(in_array($it618_group_group_zk['it618_groupid'], $okvipgroupids[0])){
			return $it618_group_group_zk['it618_zk'];
		}
	}
	return 0;
}

function it618_video_getgoodsprice($it618_video_goods, $type=''){
	global $_G,$it618_video,$it618_video_lang,$IsGroup;

	if($type=='vipzk'){
		if($IsGroup==1){
			$pid=$it618_video_goods['id'];
			if($it618_video_goods['it618_pid']>0)$pid=$it618_video_goods['it618_pid'];
			
			$vipzk=it618_video_getvipzk($pid);
		}
	}
	
	$goodspricestr=$it618_video_lang['s106'];
	
	if($type=='goods_price'){
		$pid=$it618_video_goods['id'];
		$lid=0;
		$vid=0;
	}
	
	if($type=='goods_lesson_price'){
		$pid=$it618_video_goods['it618_pid'];
		$lid=$it618_video_goods['id'];
		$vid=0;
	}
	
	if($type=='goods_video_price'){
		$pid=$it618_video_goods['it618_pid'];
		$lid=$it618_video_goods['it618_lid'];
		$vid=$it618_video_goods['id'];
	}
	
	if($type!='vipzk'){
		$typecountok = C::t('#it618_video#it618_video_goods_type')->counttype_by_pid_lid_vid_ok($pid,$lid,$vid);
		if($typecountok>1){
			if(!$it618_video_goods_typetmp=C::t('#it618_video#it618_video_goods_type')->fetch_price_by_it618_pid_lid_vid($pid,$lid,$vid)){
				if(!$it618_video_goods_typetmp=C::t('#it618_video#it618_video_goods_type')->fetch_score_by_it618_pid_lid_vid($pid,$lid,$vid)){
				}
			}
			
			if($lid==0&&$vid==0){
				C::t('#it618_video#it618_video_goods')->update($pid,array(
					'it618_saleprice' => $it618_video_goods_typetmp['it618_saleprice'],
					'it618_price' => $it618_video_goods_typetmp['it618_price'],
					'it618_jfid' => $it618_video_goods_typetmp['it618_jfid'],
					'it618_score' => $it618_video_goods_typetmp['it618_score']
				));
			}
			
			if($lid>0&&$vid==0){
				C::t('#it618_video#it618_video_goods_lesson')->update($lid,array(
					'it618_saleprice' => $it618_video_goods_typetmp['it618_saleprice'],
					'it618_price' => $it618_video_goods_typetmp['it618_price'],
					'it618_jfid' => $it618_video_goods_typetmp['it618_jfid'],
					'it618_score' => $it618_video_goods_typetmp['it618_score']
				));
			}
			
			if($lid>0&&$vid>0){
				C::t('#it618_video#it618_video_goods_video')->update($vid,array(
					'it618_saleprice' => $it618_video_goods_typetmp['it618_saleprice'],
					'it618_price' => $it618_video_goods_typetmp['it618_price'],
					'it618_jfid' => $it618_video_goods_typetmp['it618_jfid'],
					'it618_score' => $it618_video_goods_typetmp['it618_score']
				));
			}
			
			$tmpprice='<em class="jfname">'.$it618_video_lang['s1556'].'</em>';
		}
	}
	
	if($vipzk>0){
		$it618_video_goods['it618_saleprice']=round($it618_video_goods['it618_saleprice']*$vipzk/100,2);
		$it618_video_goods['it618_score']=intval($it618_video_goods['it618_score']*$vipzk/100);
	}
	
	$it618_video_goods['it618_saleprice']=floatval($it618_video_goods['it618_saleprice']);
	
	if($it618_video_goods['it618_saleprice']>0&&$it618_video_goods['it618_score']>0){
		$goodsjfname=$_G['setting']['extcredits'][$it618_video_goods['it618_jfid']]['title'];
		$goodspricestr='<em>&yen;</em>'.$it618_video_goods['it618_saleprice'].'+'.$it618_video_goods['it618_score'].'<em class="jfname">'.$goodsjfname.'</em>';
	}else{
		if($it618_video_goods['it618_saleprice']>0){
			$goodspricestr='<em>&yen;</em>'.$it618_video_goods['it618_saleprice'];
		}
		
		if($it618_video_goods['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_video_goods['it618_jfid']]['title'];
			$goodspricestr=$it618_video_goods['it618_score'].'<em class="jfname">'.$goodsjfname.'</em>';
		}
	}
	
	if($vipzk>0){
		$zk=round(($vipzk/10),2);
		$zkstr=$zk.$it618_video_lang['s1551'];
		
		$goodspricestr='<img src="source/plugin/it618_group/images/zk.png" style="height:18px;margin-right:3px;vertical-align:middle;margin-top:-3px"><span style="font-size:12px">'.$zkstr.'</span> '.$goodspricestr;
	}
	
	return $goodspricestr.$tmpprice;
}

function it618_video_getsaleprice($it618_video_sale){
	global $_G,$it618_video,$it618_video_lang;
	
	if($it618_video_sale['it618_price']>0&&$it618_video_sale['it618_score']>0){
		$goodsjfname=$_G['setting']['extcredits'][$it618_video_sale['it618_jfid']]['title'];
		$goodspricestr=$it618_video_sale['it618_price'].$it618_video_lang['s125'].'+'.$it618_video_sale['it618_score'].$goodsjfname;
	}else{
		if($it618_video_sale['it618_price']>0){
			$goodspricestr=$it618_video_sale['it618_price'].$it618_video_lang['s125'];
		}
		
		if($it618_video_sale['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_video_sale['it618_jfid']]['title'];
			$goodspricestr=$it618_video_sale['it618_score'].$goodsjfname;
		}
	}
	
	if($it618_video_sale['it618_quanmoney']>0){
		$goodspricestr.='-'.$it618_video_sale['it618_quanmoney'].$it618_video_lang['s125'];
	}
	
	return $goodspricestr;
}

function it618_video_getsalemoney($it618_video_sale){
	global $_G,$it618_video,$it618_video_lang;
	
	if(($it618_video_sale['it618_price']>0&&$it618_video_sale['it618_sfmoney']==0)||($it618_video_sale['it618_score']>0&&$it618_video_sale['it618_sfscore']==0)){
		$it618_sfmoney = $it618_video_sale['it618_price']*$it618_video_sale['it618_count']-$it618_video_sale['it618_quanmoney'];
		$it618_sfscore = $it618_video_sale['it618_score']*$it618_video_sale['it618_count'];
		$sql = "update ".DB::table('it618_video_sale')." set it618_sfmoney=$it618_sfmoney,it618_sfscore=$it618_sfscore where id=".$it618_video_sale['id']; 
		DB::query($sql);
		$it618_video_sale['it618_sfmoney']=$it618_sfmoney;
		$it618_video_sale['it618_sfscore']=$it618_sfscore;
	}
	
	if($it618_video_sale['it618_price']>0&&$it618_video_sale['it618_score']>0){
		$goodsjfname=$_G['setting']['extcredits'][$it618_video_sale['it618_jfid']]['title'];
		$goodspricestr=$it618_video_sale['it618_sfmoney'].$it618_video_lang['s125'].'+'.$it618_video_sale['it618_sfscore'].$goodsjfname;
	}else{
		if($it618_video_sale['it618_price']>0){
			$goodspricestr=$it618_video_sale['it618_sfmoney'].$it618_video_lang['s125'];
		}
		
		if($it618_video_sale['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_video_sale['it618_jfid']]['title'];
			$goodspricestr=$it618_video_sale['it618_sfscore'].$goodsjfname;
		}
	}
	
	return $goodspricestr;
}

function it618_video_getsalemoneytmp($it618_video_sale){
	global $_G,$it618_video,$it618_video_lang;
	
	if($it618_video_sale['it618_price']>0&&$it618_video_sale['it618_score']>0){
		$goodsjfname=$_G['setting']['extcredits'][$it618_video_sale['it618_jfid']]['title'];
		$goodspricestr=round($it618_video_sale['it618_price']*$it618_video_sale['it618_count'],2).$it618_video_lang['s125'].'+'.$it618_video_sale['it618_score']*$it618_video_sale['it618_count'].$goodsjfname;
	}else{
		if($it618_video_sale['it618_price']>0){
			$goodspricestr=round($it618_video_sale['it618_price']*$it618_video_sale['it618_count'],2).$it618_video_lang['s125'];
		}
		
		if($it618_video_sale['it618_score']>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_video_sale['it618_jfid']]['title'];
			$goodspricestr=$it618_video_sale['it618_score']*$it618_video_sale['it618_count'].$goodsjfname;
		}
	}
	
	if($it618_video_sale['it618_quanmoney']>0){
		$goodspricestr.='-'.$it618_video_sale['it618_quanmoney'].$it618_video_lang['s125'];
	}
	
	return $goodspricestr;
}

function it618_video_getvideotimestr($it618_video_goods_video){
	global $it618_video_lang;
	if($it618_video_goods_video['it618_islive']==0){
		$it618_videotime=$it618_video_goods_video['it618_videotime1'];
		if($it618_videotime>0){
			if($it618_videotime<10)$it618_videotime='0'.$it618_videotime;
			$videotimestr.=$it618_videotime.':';
		}
		
		$it618_videotime=$it618_video_goods_video['it618_videotime2'];
		if($it618_videotime<10)$it618_videotime='0'.$it618_videotime;
		$videotimestr.=$it618_videotime.':';
			
		$it618_videotime=$it618_video_goods_video['it618_videotime3'];
		if($it618_videotime<10)$it618_videotime='0'.$it618_videotime;
		$videotimestr.=$it618_videotime;
		
		if($videotimestr=='00:')$videotimestr='00:00';
	}else{
		$videotimestr='<font color=#23b8ff>'.$it618_video_lang['s1317'].'</font>';
	}
	
	return $videotimestr;
}

function it618_video_getplaytime($playtime){
	global $it618_video_lang;
	if($playtime<60){
		$tmpstr='00:00:'.$playtime;
	}
	
	if($playtime>=60&&$playtime<3600){
		$time1=intval($playtime/60);
		$time2=$playtime-$time1*60;
		$tmpstr='00:'.$time1.':'.$time2;
	}
	
	if($playtime>=3600){
		$time1=intval($playtime/3600);
		$playtime=$playtime-$time1*3600;
		$time2=intval($playtime/60);
		$time3=$playtime-$time2*60;
		
		$tmpstr=$time1.':'.$time2.':'.$time3;
	}
	
	return $tmpstr;
}

function it618_video_getvideocounttime($videocount,$videotime,$type=0){
	global $it618_video_lang;
	if($type==0){
		return $videocount.$it618_video_lang['s108'];
	}else{
		return $videocount.$it618_video_lang['s108'].it618_video_getvideotime($videotime);
	}
}

function it618_video_getvideotime($videotime){
	global $it618_video_lang;
	if($videotime<60){
		$tmpstr=$videotime.$it618_video_lang['s400'];
	}
	
	if($videotime>=60&&$videotime<3600){
		$time1=intval($videotime/60);
		$time2=$videotime-$time1*60;
		$tmpstr=$time1.$it618_video_lang['s398'].$time2.$it618_video_lang['s400'];
	}
	
	if($videotime>=3600){
		$time1=intval($videotime/3600);
		$videotime=$videotime-$time1*3600;
		$time2=intval($videotime/60);
		$time3=$videotime-$time2*60;
		
		$tmpstr=$time1.$it618_video_lang['s397'].$time2.$it618_video_lang['s398'].$time3.$it618_video_lang['s400'];
	}
	
	return $tmpstr;
}

function it618_video_getvideotimearr($videotime){
	$tmparr[0]=0;
	$tmparr[1]=0;
	$tmparr[2]=0;
	
	if($videotime<60){
		$tmparr[2]=$videotime;
	}
	
	if($videotime>=60&&$videotime<3600){
		$time1=intval($videotime/60);
		$time2=$videotime-$time1*60;
		
		$tmparr[1]=$time1;
		$tmparr[2]=$time2;
	}
	
	if($videotime>=3600){
		$time1=intval($videotime/3600);
		$videotime=$videotime-$time1*3600;
		$time2=intval($videotime/60);
		$time3=$videotime-$time2*60;
		
		$tmparr[0]=$time1;
		$tmparr[1]=$time2;
		$tmparr[2]=$time3;
	}
	
	return $tmparr;
}

function it618_video_updatemediastate($mediaid,$state){
	if($it618_video_media=C::t('#it618_video#it618_video_media')->fetch_by_mediaid($mediaid)){
		
		include_once DISCUZ_ROOT.'./source/plugin/it618_video/aliapi/alimts.php';
		
		$it618_video_media_wmf=C::t('#it618_video#it618_video_media_wmf')->fetch_by_id($it618_video_media['it618_wmf_id']);
	
		$accessid=$it618_video_media_wmf['it618_accessid'];
		$accesskey=$it618_video_media_wmf['it618_accesskey'];
		$endpoint=$it618_video_media['it618_endpoint'];
	
		$region = str_replace(".aliyuncs.com","",$endpoint);
		$regionid = str_replace("oss-","",$region);
		
		$profile = DefaultProfile::getProfile($region, $accessid, $accesskey);
		$client = new DefaultAcsClient($profile);
		
		$request = new UpdateMediaPublishStateRequest();
		$request->setRegionId($regionid);
		
	    $request->setMediaId($mediaid);
	    $request->setPublish($state);
	    $response = $client->getAcsResponse($request);
	}
}

function it618_video_deletemediamts($mediaid){
	if($it618_video_media=C::t('#it618_video#it618_video_media')->fetch_by_mediaid($mediaid)){
		include_once DISCUZ_ROOT.'./source/plugin/it618_video/aliapi/alimts.php';
		
		$it618_video_media_wmf=C::t('#it618_video#it618_video_media_wmf')->fetch_by_id($it618_video_media['it618_wmf_id']);
	
		$accessid=$it618_video_media_wmf['it618_accessid'];
		$accesskey=$it618_video_media_wmf['it618_accesskey'];
		$endpoint=$it618_video_media['it618_endpoint'];
	
		$region = str_replace(".aliyuncs.com","",$endpoint);
		$regionid = str_replace("oss-","",$region);
		
		$profile = DefaultProfile::getProfile($region, $accessid, $accesskey);
		$client = new DefaultAcsClient($profile);
		
		$request = new DeleteMediaRequest();
		$request->setRegionId($regionid);
		
	    $request->setMediaIds($mediaid);
	    $response = $client->getAcsResponse($request);
	}
}

function it618_video_deletemediaaudio($url){
	if($it618_video_media_audio=C::t('#it618_video#it618_video_media_audio')->fetch_by_url($url)){
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_video/oss/OssClient.php';
		
		$it618_video_media_aoss=C::t('#it618_video#it618_video_media_aoss')->fetch_by_id($it618_video_media_audio['it618_aoss_id']);
	
		$accessid=$it618_video_media_aoss['it618_accessid'];
		$accesskey=$it618_video_media_aoss['it618_accesskey'];
		$endpoint=$it618_video_media_audio['it618_endpoint'];

		$ossClient = new OssClient($accessid, $accesskey, $endpoint);
		
		$it618_url=$it618_video_media_audio['it618_url'];
		
		$tmparr=explode($endpoint,$it618_url);
		$bucket=str_replace("http://","",$tmparr[0]);
		$bucket=str_replace("https://","",$bucket);
		$bucket=str_replace(".","",$bucket);
		
		$tmparr=explode('.aliyuncs.com/',$it618_url);
		$object=$tmparr[1];
		
		$ossClient->deleteObject($bucket, $object);
	}
}

function it618_video_deletemedialive($url){
	if($it618_video_media_live=C::t('#it618_video#it618_video_media_live')->fetch_by_url($url)){
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_video/oss/OssClient.php';
		
		$it618_video_liveset=C::t('#it618_video#it618_video_liveset')->fetch_by_id($it618_video_media_live['it618_liveset_id']);
	
		$accessid=$it618_video_liveset['it618_accessid'];
		$accesskey=$it618_video_liveset['it618_accesskey'];
		$endpoint=$it618_video_media_live['it618_endpoint'];

		$ossClient = new OssClient($accessid, $accesskey, $endpoint);
		
		$it618_url=$it618_video_media_live['it618_url'];
		
		$tmparr=explode($endpoint,$it618_url);
		$bucket=str_replace("http://","",$tmparr[0]);
		$bucket=str_replace("https://","",$bucket);
		$bucket=str_replace(".","",$bucket);
		
		$tmparr1=explode('.aliyuncs.com/',$it618_url);
		$tmparr2=explode('/',$it618_url);
		$name=$tmparr2[count($tmparr2)-1];
		$prefix=str_replace($name,"",$tmparr1[1]);
		
		$delimiter = '/';
		$nextMarker = '';
		$maxkeys = 100;
		
		while (true) {
			$options = array(
				'delimiter' => $delimiter,
				'prefix' => $prefix,
				'max-keys' => $maxkeys,
				'marker' => $nextMarker,
			);
		
			$listObjectInfo = $ossClient->listObjects($bucket, $options);
			
			$nextMarker = $listObjectInfo->getNextMarker();
			$listObject = $listObjectInfo->getObjectList();
			
			foreach ($listObject as $Object){
				$ossClient->deleteObject($bucket, $Object->getKey());
			}
			
			if ($nextMarker === '') {
				break;
			}
		}
	}
}

function it618_video_deletemedia($mediaid){
	if($it618_video_media=C::t('#it618_video#it618_video_media')->fetch_by_mediaid($mediaid)){
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_video/oss/OssClient.php';
		
		$it618_video_media_wmf=C::t('#it618_video#it618_video_media_wmf')->fetch_by_id($it618_video_media['it618_wmf_id']);
	
		$accessid=$it618_video_media_wmf['it618_accessid'];
		$accesskey=$it618_video_media_wmf['it618_accesskey'];
		$endpoint=$it618_video_media['it618_endpoint'];

		$ossClient = new OssClient($accessid, $accesskey, $endpoint);
		
		$it618_url=$it618_video_media['it618_url'];
		
		$tmparr=explode($endpoint,$it618_url);
		$bucket=str_replace("http://","",$tmparr[0]);
		$bucket=str_replace("https://","",$bucket);
		$bucket=str_replace(".","",$bucket);
		
		$tmparr=explode('.aliyuncs.com/',$it618_url);
		$object=$tmparr[1];
		
		$ossClient->deleteObject($bucket, $object);
		
		$it618_mediacount=C::t('#it618_video#it618_video_media')->count_by_wmf_id($it618_video_media['it618_wmf_id']);
		$it618_mediasize=C::t('#it618_video#it618_video_media')->sum_size_by_wmf_id($it618_video_media['it618_wmf_id']);
		
		C::t('#it618_video#it618_video_media_wmf')->update($it618_video_media['it618_wmf_id'],array(
			'it618_mediacount' => $it618_mediacount,
			'it618_mediasize' => ($it618_mediasize/1024/1024),
		));
	}
}

function it618_video_deletemediaandmts($mediaid){
	if($it618_video_media=C::t('#it618_video#it618_video_media')->fetch_by_mediaid($mediaid)){
		
		it618_video_deletemediamts($mediaid);
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_video/oss/OssClient.php';
		
		$it618_video_media_wmf=C::t('#it618_video#it618_video_media_wmf')->fetch_by_id($it618_video_media['it618_wmf_id']);
	
		$accessid=$it618_video_media_wmf['it618_accessid'];
		$accesskey=$it618_video_media_wmf['it618_accesskey'];
		$endpoint=$it618_video_media['it618_endpoint'];

		$ossClient = new OssClient($accessid, $accesskey, $endpoint);
		
		$it618_url=$it618_video_media['it618_url'];
		
		$tmparr=explode($endpoint,$it618_url);
		$bucket=str_replace("http://","",$tmparr[0]);
		$bucket=str_replace("https://","",$bucket);
		$bucket=str_replace(".","",$bucket);
		
		$tmparr=explode('.aliyuncs.com/',$it618_url);
		$object=$tmparr[1];
		
		$ossClient->deleteObject($bucket, $object);
		
		if($it618_video_media['it618_mtscount']>0){
			$query = DB::query("SELECT * FROM ".DB::table('it618_video_media_mts')." where it618_media_id=".$it618_video_media['id']);
			while($it618_video_media_mts =	DB::fetch($query)) {
				$it618_url=$it618_video_media_mts['it618_url'];

				$tmparr=explode($endpoint,$it618_url);
				$bucket=str_replace("http://","",$tmparr[0]);
				$bucket=str_replace("https://","",$bucket);
				$bucket=str_replace(".","",$bucket);
				
				$tmparr1=explode('.aliyuncs.com/',$it618_url);
				$tmparr2=explode('/',$it618_url);
				$name=$tmparr2[count($tmparr2)-1];
				
				$prefix=str_replace($name,"",$tmparr1[1]);

				$delimiter = '/';
				$nextMarker = '';
				$maxkeys = 100;
				
				while (true) {
					$options = array(
						'delimiter' => $delimiter,
						'prefix' => $prefix,
						'max-keys' => $maxkeys,
						'marker' => $nextMarker,
					);
				
					$listObjectInfo = $ossClient->listObjects($bucket, $options);
					
					$nextMarker = $listObjectInfo->getNextMarker();
					$listObject = $listObjectInfo->getObjectList();
					
					foreach ($listObject as $Object){
						$ossClient->deleteObject($bucket, $Object->getKey());
					}
					
					if ($nextMarker === '') {
						break;
					}
				}
			}
		}
		
		$it618_mediacount=C::t('#it618_video#it618_video_media')->count_by_wmf_id($it618_video_media['it618_wmf_id']);
		$it618_mtscount=C::t('#it618_video#it618_video_media_mts')->count_by_wmf_id($it618_video_media['it618_wmf_id']);
		$it618_mediasize=C::t('#it618_video#it618_video_media')->sum_size_by_wmf_id($it618_video_media['it618_wmf_id']);
		$it618_mtssize=C::t('#it618_video#it618_video_media_mts')->sum_size_by_wmf_id($it618_video_media['it618_wmf_id']);
		
		C::t('#it618_video#it618_video_media_wmf')->update($it618_video_media['it618_wmf_id'],array(
			'it618_mediacount' => $it618_mediacount,
			'it618_mtscount' => $it618_mtscount,
			'it618_mediasize' => ($it618_mediasize/1024/1024),
			'it618_mtssize' => ($it618_mtssize/1024/1024),
		));

	}
}

function it618_video_updatemedia($url){
	if($it618_video_media=C::t('#it618_video#it618_video_media')->fetch_by_url($url)){
	
		include_once DISCUZ_ROOT.'./source/plugin/it618_video/aliapi/alimts.php';
		
		$it618_video_media_wmf=C::t('#it618_video#it618_video_media_wmf')->fetch_by_id($it618_video_media['it618_wmf_id']);
	
		$accessid=$it618_video_media_wmf['it618_accessid'];
		$accesskey=$it618_video_media_wmf['it618_accesskey'];
		$endpoint=$it618_video_media['it618_endpoint'];
	
		$region = str_replace(".aliyuncs.com","",$endpoint);
		$regionid = str_replace("oss-","",$region);
		
		$profile = DefaultProfile::getProfile($region, $accessid, $accesskey);
		$client = new DefaultAcsClient($profile);
		
		$request = new QueryMediaListByURLRequest();
		$request->setRegionId($regionid);
		
		$request->setFileURLs($it618_video_media['it618_url']);
		$request->setIncludePlayList(true);
		$response = $client->getAcsResponse($request);
		
		$tmparr=object_array($response);
		
//		$s = var_export($tmparr,true);
//		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_video/debug.txt',"a");
//		fwrite($fp,$s);
//		fclose($fp);
		
		$MediaArr=$tmparr['MediaList']['Media'][0];
		
		$it618_mediaid=$MediaArr['MediaId'];
		$it618_coverurl=$MediaArr['CoverURL'];
		$it618_url=$MediaArr['File']['URL'];
		$it618_duration=$MediaArr['Duration'];
		$it618_fps=$MediaArr['Fps'];
		$it618_bitrate=$MediaArr['Bitrate'];
		$it618_width=$MediaArr['Width'];
		$it618_height=$MediaArr['Height'];
		$it618_size=$MediaArr['Size'];
		
		if($it618_url==$url){
			C::t('#it618_video#it618_video_media')->update($it618_video_media['id'],array(
				'it618_mediaid' => $it618_mediaid,
				'it618_coverurl' => $it618_coverurl,
				'it618_duration' => $it618_duration,
				'it618_fps' => $it618_fps,
				'it618_bitrate' => $it618_bitrate,
				'it618_width' => $it618_width,
				'it618_height' => $it618_height,
				'it618_size' => $it618_size
			));
			
			$PlayArrs=$tmparr['MediaList']['Media'][0]['PlayList']['Play'];
			
			for($i=0;$i<count($PlayArrs);$i++){
				
				$PlayArr=$PlayArrs[$i];
				
				$it618_wmfid=$PlayArr['MediaWorkflowId'];
				$it618_wmfname=it618_video_utftogbk($PlayArr['MediaWorkflowName']);
				$it618_actname=it618_video_utftogbk($PlayArr['ActivityName']);
				$it618_url=$PlayArr['File']['URL'];
				$it618_duration=$PlayArr['Duration'];
				$it618_fps=$PlayArr['Fps'];
				$it618_bitrate=$PlayArr['Bitrate'];
				$it618_width=$PlayArr['Width'];
				$it618_height=$PlayArr['Height'];
				$it618_size=$PlayArr['Size'];
				
				$count=C::t('#it618_video#it618_video_media_mts')->count_by_url($it618_url);
				if($count==0){
					C::t('#it618_video#it618_video_media_mts')->insert(array(
						'it618_shopid' => $it618_video_media['it618_shopid'],
						'it618_wmf_id' => $it618_video_media['it618_wmf_id'],
						'it618_media_id' => $it618_video_media['id'],
						'it618_wmfid' => $it618_wmfid,
						'it618_wmfname' => $it618_wmfname,
						'it618_actname' => $it618_actname,
						'it618_url' => $it618_url,
						'it618_duration' => $it618_duration,
						'it618_fps' => $it618_fps,
						'it618_bitrate' => $it618_bitrate,
						'it618_width' => $it618_width,
						'it618_height' => $it618_height,
						'it618_size' => $it618_size
					), true);
				}
			}
			
			$it618_mtscount=C::t('#it618_video#it618_video_media_mts')->count_by_media_id($it618_video_media['id']);
			$it618_mtssize=C::t('#it618_video#it618_video_media_mts')->sum_size_by_media_id($it618_video_media['id']);
			
			if($it618_mtscount>0){
				it618_video_updatemediastate($it618_mediaid,'true');
				$it618_state=1;
				
				if($it618_video_media_wmf['it618_isurldel']==1){
					it618_video_deletemedia($it618_mediaid);
					DB::query("update ".DB::table('it618_video_media')." set it618_urldel=1 where id=".$it618_video_media['id']);
				}
			}
			
			C::t('#it618_video#it618_video_media')->update($it618_video_media['id'],array(
				'it618_mtscount' => $it618_mtscount,
				'it618_mtssize' => $it618_mtssize,
				'it618_state' => $it618_state
			));
			
			$it618_mediacount=C::t('#it618_video#it618_video_media')->count_by_wmf_id($it618_video_media['it618_wmf_id']);
			$it618_mtscount=C::t('#it618_video#it618_video_media_mts')->count_by_wmf_id($it618_video_media['it618_wmf_id']);
			$it618_mediasize=C::t('#it618_video#it618_video_media')->sum_size_by_wmf_id($it618_video_media['it618_wmf_id']);
			$it618_mtssize=C::t('#it618_video#it618_video_media_mts')->sum_size_by_wmf_id($it618_video_media['it618_wmf_id']);
			
			C::t('#it618_video#it618_video_media_wmf')->update($it618_video_media['it618_wmf_id'],array(
				'it618_mediacount' => $it618_mediacount,
				'it618_mtscount' => $it618_mtscount,
				'it618_mediasize' => ($it618_mediasize/1024/1024),
				'it618_mtssize' => ($it618_mtssize/1024/1024),
			));
		}
	}
}

function it618_video_getkmsdecrypt($mediaid,$CiphertextBlob){
	global $_G;

	if($it618_video_media=C::t('#it618_video#it618_video_media')->fetch_by_mediaid($mediaid)){

		$it618_video_media_wmf=C::t('#it618_video#it618_video_media_wmf')->fetch_by_id($it618_video_media['it618_wmf_id']);
		
		$it618_hlskms=getcookie('it618_hlskms'.md5($it618_video_media['it618_mediaid'].$it618_video_media_wmf['it618_accesskey']));
		if($it618_hlskms==1){
			dsetcookie('it618_hlskms'.md5($it618_video_media['it618_mediaid'].$it618_video_media_wmf['it618_accesskey']),'',31536000);
		}else{
			if(!video_is_mobile()){
				return;
			}
			//return;
		}

		include_once DISCUZ_ROOT.'./source/plugin/it618_video/aliapi/alikms.php';
		
		$accessid=$it618_video_media_wmf['it618_accessid'];
		$accesskey=$it618_video_media_wmf['it618_accesskey'];
		$endpoint=$it618_video_media['it618_endpoint'];
		$region = str_replace(".aliyuncs.com","",$endpoint);
		$region = str_replace("oss-","",$region);
		
		$profile = DefaultProfile::getProfile($region, $accessid, $accesskey);
		$client = new DefaultAcsClient($profile);
		
		$request = new DecryptRequest();
		$request->setCiphertextBlob($CiphertextBlob);

	    $response = $client->getAcsResponse($request);
		
//		$tmparr=object_array($response);
//		$s = var_export($tmparr,true);
//		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_video/debug.txt',"a");
//		fwrite($fp,$s);
//		fclose($fp);
		
		return base64_decode($response->Plaintext);
		
		//return base64_decode($tmparr['Plaintext']);
	}
}

function it618_video_addliverecordconfig($it618_video_live){
	global $_G;
	include_once DISCUZ_ROOT.'./source/plugin/it618_video/aliapi/alilive.php';
	
	$it618_video_liveset=C::t('#it618_video#it618_video_liveset')->fetch_by_id($it618_video_live['it618_liveset_id']);

	$accessid=$it618_video_liveset['it618_accessid'];
	$accesskey=$it618_video_liveset['it618_accesskey'];
	
	$profile = DefaultProfile::getProfile($it618_video_liveset['it618_cnname'], $accessid, $accesskey);
	$client = new DefaultAcsClient($profile);
	
	$request = new AddLiveAppRecordConfigRequest();
	$request->setAppName($it618_video_liveset['it618_appname']);
	$request->setStreamName($it618_video_live['it618_streamname']);
	$request->setDomainName($it618_video_liveset['it618_domainname']);
	$request->setOssBucket($it618_video_live['it618_ossbucket']);
	$request->setOssEndpoint($it618_video_live['it618_ossendpoint']);
	
	$RecordFormats[0]['CycleDuration']=360*60;
	$RecordFormats[0]['Format']='m3u8';
	$RecordFormats[0]['OssObjectPrefix']="record/".$it618_video_liveset['it618_appname']."/".$it618_video_live['it618_streamname']."/{EscapedStartTime}_{EscapedEndTime}";
	$RecordFormats[0]['SliceOssObjectPrefix']="record/".$it618_video_liveset['it618_appname']."/".$it618_video_live['it618_streamname']."/{UnixTimestamp}_{Sequence}";
	
	$request->setRecordFormats($RecordFormats);
	//$request->setStartTime(str_replace(" ","T",date('Y-m-d H:i:s', $it618_video_live['it618_btime'])).'Z');
	//$request->setEndTime(str_replace(" ","T",date('Y-m-d H:i:s', $it618_video_live['it618_etime'])).'Z');
	
	$response = $client->getAcsResponse($request);
	
	$s = var_export($response,true);
	
	$tmparr=explode("Code",$s);
	if(count($tmparr)==1){
		return 1;
	}else{
		return $s;
	}
}

function it618_video_delliverecordconfig($it618_video_live){
	global $_G;
	include_once DISCUZ_ROOT.'./source/plugin/it618_video/aliapi/alilive.php';
	
	$it618_video_liveset=C::t('#it618_video#it618_video_liveset')->fetch_by_id($it618_video_live['it618_liveset_id']);

	$accessid=$it618_video_liveset['it618_accessid'];
	$accesskey=$it618_video_liveset['it618_accesskey'];
	
	$profile = DefaultProfile::getProfile($it618_video_liveset['it618_cnname'], $accessid, $accesskey);
	$client = new DefaultAcsClient($profile);
	
	$request = new DeleteLiveAppRecordConfigRequest();
	$request->setAppName($it618_video_liveset['it618_appname']);
	$request->setStreamName($it618_video_live['it618_streamname']);
	$request->setDomainName($it618_video_liveset['it618_domainname']);
	
	$response = $client->getAcsResponse($request);
	
	$s = var_export($response,true);
	
	$tmparr=explode("Code",$s);
	if(count($tmparr)==1){
		return 1;
	}else{
		return $s;
	}
}

function it618_video_forbidlivestream($it618_video_live){
	include_once DISCUZ_ROOT.'./source/plugin/it618_video/aliapi/alilive.php';
	
	$it618_video_liveset=C::t('#it618_video#it618_video_liveset')->fetch_by_id($it618_video_live['it618_liveset_id']);

	$accessid=$it618_video_liveset['it618_accessid'];
	$accesskey=$it618_video_liveset['it618_accesskey'];
	
	$profile = DefaultProfile::getProfile($it618_video_liveset['it618_cnname'], $accessid, $accesskey);
	$client = new DefaultAcsClient($profile);
	
	$request = new ForbidLiveStreamRequest();
	$request->setAppName($it618_video_liveset['it618_appname']);
	$request->setStreamName($it618_video_live['it618_streamname']);
	$request->setDomainName($it618_video_liveset['it618_domainname']);
	$request->setLiveStreamType('publisher');
	
	$response = $client->getAcsResponse($request);
	
	$s = var_export($response,true);
	
	$tmparr=explode("Code",$s);
	if(count($tmparr)==1){
		return 1;
	}else{
		return $s;
	}
}

function it618_video_getlivestreamrecord($it618_video_live){
	global $_G;
	include_once DISCUZ_ROOT.'./source/plugin/it618_video/aliapi/alilive.php';
	
	$it618_video_liveset=C::t('#it618_video#it618_video_liveset')->fetch_by_id($it618_video_live['it618_liveset_id']);

	$accessid=$it618_video_liveset['it618_accessid'];
	$accesskey=$it618_video_liveset['it618_accesskey'];
	
	$profile = DefaultProfile::getProfile($it618_video_liveset['it618_cnname'], $accessid, $accesskey);
	$client = new DefaultAcsClient($profile);
	
	$request = new DescribeLiveStreamRecordIndexFilesRequest();
	$request->setAppName($it618_video_liveset['it618_appname']);
	$request->setStreamName($it618_video_live['it618_streamname']);
	$request->setDomainName($it618_video_liveset['it618_domainname']);
	$request->setStartTime(str_replace(" ","T",date('Y-m-d H:i:s', $it618_video_live['it618_btime']-3600*10)).'Z');
	$request->setEndTime(str_replace(" ","T",date('Y-m-d H:i:s', $_G['timestamp']+3600)).'Z');
	
	$response = $client->getAcsResponse($request);
	
	$tmparr=object_array($response);
	
//	$s = var_export($response,true);
//	
//	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_video/debug.txt',"a");
//	fwrite($fp,$s);
//	fclose($fp);

	$RecordArr=$tmparr['RecordIndexInfoList']['RecordIndexInfo'];
	
	return $RecordArr;
}

function it618_video_addlivem3u8($it618_video_live, $m3u8object){
	global $_G;
	include_once DISCUZ_ROOT.'./source/plugin/it618_video/aliapi/alilive.php';
	
	$it618_video_liveset=C::t('#it618_video#it618_video_liveset')->fetch_by_id($it618_video_live['it618_liveset_id']);

	$accessid=$it618_video_liveset['it618_accessid'];
	$accesskey=$it618_video_liveset['it618_accesskey'];
	
	$profile = DefaultProfile::getProfile($it618_video_liveset['it618_cnname'], $accessid, $accesskey);
	$client = new DefaultAcsClient($profile);
	
	$request = new CreateLiveStreamRecordIndexFilesRequest();
	$request->setAppName($it618_video_liveset['it618_appname']);
	$request->setStreamName($it618_video_live['it618_streamname']);
	$request->setDomainName($it618_video_liveset['it618_domainname']);
	$request->setOssBucket($it618_video_live['it618_ossbucket']);
	$request->setOssEndpoint($it618_video_live['it618_ossendpoint']);
	$request->setOssObject($m3u8object);
	$request->setStartTime(str_replace(" ","T",date('Y-m-d H:i:s', $it618_video_live['it618_btime']-3600*10)).'Z');
	$request->setEndTime(str_replace(" ","T",date('Y-m-d H:i:s', $_G['timestamp']+3600)).'Z');
	
	$response = $client->getAcsResponse($request);
}

function it618_video_updatevideolive($it618_video_live,$type=''){
	global $_G;
	$etime=$it618_video_live['it618_etime'];
	
	if($etime+1000<$_G['timestamp']){
		C::t('#it618_video#it618_video_live')->update($it618_video_live['id'],array(
			'it618_isok' => 1
		));
		if($it618_video_live['it618_ossbucket']==''&&$it618_video_live['it618_ossendpoint']==''){
			it618_video_deletegoodsvideo($it618_video_live['id']);
		}
	}
		
	if($it618_video_live['it618_forbid']==0){
		if(($etime+90<$_G['timestamp']&&$it618_video_live['it618_rtmpcode']!='')||$type=='btn'){
			$returnvalue=it618_video_forbidlivestream($it618_video_live);
			if($returnvalue==1){
				C::t('#it618_video#it618_video_live')->update($it618_video_live['id'],array(
					'it618_forbid' => 1,
					'it618_forbidtime' => $_G['timestamp']
				));
			}
		}
	}else{

		if($it618_video_live['it618_ossbucket']!=''&&$it618_video_live['it618_ossendpoint']!=''){

			$forbidtime=$it618_video_live['it618_forbidtime'];
			if($forbidtime+180<$_G['timestamp']){
				$it618_video_liveset=C::t('#it618_video#it618_video_liveset')->fetch_by_id($it618_video_live['it618_liveset_id']);
				$RecordArr=it618_video_getlivestreamrecord($it618_video_live);
	
				for($i=0;$i<count($RecordArr);$i++){
					
					$it618_videourl=$RecordArr[$i]['RecordUrl'];
					
					$tmparr=explode($it618_video_live['it618_streamname'],$it618_videourl);
					$m3u8path=$tmparr[0].$it618_video_live['it618_streamname'].'/'.$_G['timestamp'].'.m3u8';
					$tmparr=explode($it618_video_live['it618_ossendpoint'].'/',$m3u8path);
					$m3u8object=$tmparr[1];
					
					break;
				}
				
				if($m3u8path!=''){
					it618_video_addlivem3u8($it618_video_live, $m3u8object);
					
					$it618_order=C::t('#it618_video#it618_video_goods_video')->fetch_order_by_lid($it618_video_live['it618_lid']);
					$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_liveid($it618_video_live['id']);
					
					C::t('#it618_video#it618_video_goods_video')->update($it618_video_goods_video['id'],array(
						'it618_name' => $it618_video_live['it618_name'],
						'it618_description' => $it618_video_live['it618_description'],
						'it618_videourl' => $m3u8path,
						'it618_islive' => 0,
						'it618_liveid' => 0,
						'it618_order' => $it618_order
					), true);
					
					C::t('#it618_video#it618_video_media_live')->insert(array(
						'it618_shopid' => $it618_video_live['it618_shopid'],
						'it618_liveset_id' => $it618_video_live['it618_liveset_id'],
						'it618_live_id' => $it618_video_live['id'],
						'it618_endpoint' => $OssEndpoint,
						'it618_name' => $it618_video_live['it618_name'].$tmpname,
						'it618_url' => $m3u8path,
						'it618_time' => $_G['timestamp'],
					), true);	
					
					it618_video_delliverecordconfig($it618_video_live);
					
					C::t('#it618_video#it618_video_live')->update($it618_video_live['id'],array(
						'it618_isok' => 1
					));
				}
			}

		}else{
			C::t('#it618_video#it618_video_live')->update($it618_video_live['id'],array(
				'it618_isok' => 1
			));
			it618_video_deletegoodsvideo($it618_video_live['id']);
		}
	}

}

function it618_video_deletegoodsvideo($id,$type='live'){
	if($type=='live'||$type=='admindel'){
		$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_liveid($id);
		$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($id);
		$vid=$it618_video_goods_video['id'];
	}else{
		$vid=$id;
		$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_id($id);
		$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
	}
	
	if($type!='admindel'){
		if($it618_video_live['it618_savetype']==1||$it618_video_live['it618_savetype']==2){
			$ison=1;
			if($it618_video_live['it618_savetype']==2)$ison=0;
			
			$it618_order=C::t('#it618_video#it618_video_goods_video')->fetch_order_by_lid($it618_video_live['it618_lid']);
			
			C::t('#it618_video#it618_video_goods_video')->update($vid,array(
				'it618_name' => $it618_video_live['it618_name'],
				'it618_description' => $it618_video_live['it618_description'],
				'it618_videourl' => $it618_video_live['it618_m3u8url'],
				'it618_islive' => 0,
				'it618_liveid' => 0,
				'it618_ison' => $ison,
				'it618_order' => $it618_order
			), true);
		}else{
			$isdel=1;
		}
	}else{
		$isdel=1;
	}
	
	if($isdel==1){
		$salecount = C::t('#it618_video#it618_video_sale')->sumcount_by_it618_vid($vid);
		if($salecount==0){
			DB::query("delete from ".DB::table('it618_video_goods_video')." where id=".$vid);
			DB::query("delete from ".DB::table('it618_video_goods_video_pl')." where it618_vid=".$vid);
		}else{
			DB::query("update ".DB::table('it618_video_goods_video')." set it618_ison=0,it618_liveid=0 where id=".$vid);
			if($type=='media_live'){
				DB::query("update ".DB::table('it618_video_goods_video')." set it618_videourl='' where id=".$vid);
			}
		}
	}
}

function it618_video_updatevideoliveonline($it618_liveset_id){
	global $_G;
	if($it618_video_liveset=C::t('#it618_video#it618_video_liveset')->fetch_by_id($it618_liveset_id)){
		
		include_once DISCUZ_ROOT.'./source/plugin/it618_video/aliapi/alilive.php';
	
		$accessid=$it618_video_liveset['it618_accessid'];
		$accesskey=$it618_video_liveset['it618_accesskey'];
		
		$profile = DefaultProfile::getProfile($it618_video_liveset['it618_cnname'], $accessid, $accesskey);
		$client = new DefaultAcsClient($profile);
		
		$request = new DescribeLiveStreamsOnlineListRequest();
		$request->setAppName($it618_video_liveset['it618_appname']);
		$request->setDomainName($it618_video_liveset['it618_domainname']);
		$request->setPageNum(1);
		$request->setPageSize(3000);
		
		$response = $client->getAcsResponse($request);
		
		$tmparr=object_array($response);
		
		$OnlineArr=$tmparr['OnlineInfo']['LiveStreamOnlineInfo'];
//		$s = var_export($tmparr,true);
//		
//		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_video/debug.txt',"a");
//		fwrite($fp,$s);
//		fclose($fp);
		
		for($i=0;$i<count($OnlineArr);$i++){
			$StreamName=$OnlineArr[$i]['StreamName'];
			$PublishTime=$OnlineArr[$i]['PublishTime'];
			$PublishTime=str_replace("Z","",$PublishTime);
			$PublishTime=str_replace("T"," ",$PublishTime);
			
			if($it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_livesetid_streamname($it618_liveset_id,$StreamName)){
				if(strtotime($PublishTime)+50<$_G['timestamp']){
					C::t('#it618_video#it618_video_live')->update($it618_video_live['id'],array(
						'it618_btime' => $_G['timestamp'],
						'it618_isonline' => 1
					));
					return;
				}
			}
		}
		
		DB::query("update ".DB::table('it618_video_live')." set it618_isonline=0 where it618_liveset_id=".$it618_liveset_id);
	}

}

function it618_video_getsignedurl($it618_url){
	global $_G;
	
	return it618_video_cdnkeyurl($it618_url);
	
//	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php')){
//		require DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php';
//	}
	
//	if($player_isosssignedurl!=1){
//		return it618_video_cdnkeyurl($it618_url);
//	}
	
	$it618_videourl=str_replace("https://","http://",$it618_url);
	
	if($it618_video_media_audio=C::t('#it618_video#it618_video_media_audio')->fetch_by_url($it618_videourl)){
		$it618_video_media_aoss=C::t('#it618_video#it618_video_media_aoss')->fetch_by_id($it618_video_media_audio['it618_aoss_id']);
		$endpoint=$it618_video_media_audio['it618_endpoint'];
		$isok=1;
	}else{
		if($it618_video_media=C::t('#it618_video#it618_video_media')->fetch_by_url($it618_videourl)){
			$it618_video_media_aoss=C::t('#it618_video#it618_video_media_wmf')->fetch_by_id($it618_video_media['it618_wmf_id']);
			$endpoint=$it618_video_media['it618_endpoint'];
			$isok=1;
		}
	}
	
	if($isok!=1)return $it618_url;
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_video/oss/OssClient.php';

	$accessid=$it618_video_media_aoss['it618_accessid'];
	$accesskey=$it618_video_media_aoss['it618_accesskey'];

	$ossClient = new OssClient($accessid, $accesskey, $endpoint);
	
	$tmparr=explode($endpoint,$it618_url);
	$bucket=str_replace("http://","",$tmparr[0]);
	$bucket=str_replace("https://","",$bucket);
	$bucket=str_replace(".","",$bucket);
	
	$tmparr=explode('.aliyuncs.com/',$it618_url);
	$object=$tmparr[1];
	
	$timeout = 8000;
	$signedUrl = $ossClient->signUrl($bucket, $object, $timeout);
	$tmparr=explode("Signature=",$signedUrl);

	$it618_url = $tmparr[0].'Signature='.$tmparr[1];
	
	$urlarr=explode("aliyuncs.com",$it618_url);
	if(count($urlarr)>1){
		$urlarr=explode("https://",$_G['siteurl']);
		if(count($urlarr)>1){
			$it618_url=str_replace("http://","https://",$it618_url);
		}
	}
	
	return $it618_url;
}

function it618_video_cdnkeyurl($it618_url){
	global $_G;
	
	$urlarr=explode("aliyuncs.com",$it618_url);
	if(count($urlarr)>1){
		$it618_url=str_replace("https://",'http://',$it618_url);
	}
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_cdn')." where it618_iscdnok=1");
	while($it618_video_cdn = DB::fetch($query)) {
		
		$urltmp=str_replace($it618_video_cdn['it618_ossurl'],$it618_video_cdn['it618_cdnurl'],$it618_url);
		
		if($urltmp!=$it618_url){
			
			if($it618_video_cdn['it618_iskeyok']==1){
				$time=$_G['timestamp']+$it618_video_cdn['it618_time']*60+8000;
			
				$key=$it618_video_cdn['it618_key'];

				$filename=str_replace('http://'.$it618_video_cdn['it618_cdnurl']."","",$urltmp);
			
				//$sstring = "URI-Timestamp-rand-uid-PrivateKey"
			
				$sstring = $filename."-".$time."-0-0-".$key;
			
				$md5=md5($sstring);
			
				$auth_key="auth_key=".$time."-0-0-".$md5;
			
				$urltmp=$urltmp."?".$auth_key;
			}
			
			$urlarr=explode("https://",$_G['siteurl']);
			if(count($urlarr)>1){
				if($it618_video_cdn['it618_ishttps']==1)$urltmp=str_replace("http://","https://",$urltmp);
			}
		
			return $urltmp;
		}
	}
	
	$urlarr=explode("aliyuncs.com",$it618_url);
	if(count($urlarr)>1){
		$urlarr=explode("https://",$_G['siteurl']);
		if(count($urlarr)>1){
			$it618_url=str_replace("http://","https://",$it618_url);
		}
	}
	
	return $it618_url;

}

function it618_video_setlivecdn($it618_video_live){
	global $_G;
			
	$it618_video_liveset=C::t('#it618_video#it618_video_liveset')->fetch_by_id($it618_video_live['it618_liveset_id']);
	
	$time=$it618_video_live['it618_etime'];

	$key=$it618_video_liveset['it618_pushcdnkey'];
	
	$httpstr='http://';

	$filename='/'.$it618_video_liveset['it618_appname'].'/'.$it618_video_live['it618_streamname'];
	$sstring = $filename."-".$time."-0-0-".$key;
	$md5=md5($sstring);
	$auth_key="auth_key=".$time."-0-0-".$md5;
	$it618_rtmpcode=$it618_video_live['it618_streamname']."?".$auth_key;
	
	$key=$it618_video_liveset['it618_cdnkey'];
	
	$filename='/'.$it618_video_liveset['it618_appname'].'/'.$it618_video_live['it618_streamname'].'.m3u8';
	$sstring = $filename."-".$time."-0-0-".$key;
	$md5=md5($sstring);
	$auth_key="auth_key=".$time."-0-0-".$md5;
	$it618_m3u8url=$httpstr.$it618_video_liveset['it618_domainname'].$filename."?".$auth_key;
	
	$filename='/'.$it618_video_liveset['it618_appname'].'/'.$it618_video_live['it618_streamname'].'.flv';
	$sstring = $filename."-".$time."-0-0-".$key;
	$md5=md5($sstring);
	$auth_key="auth_key=".$time."-0-0-".$md5;
	$it618_flvurl=$httpstr.$it618_video_liveset['it618_domainname'].$filename."?".$auth_key;
  
	C::t('#it618_video#it618_video_live')->update($it618_video_live['id'],array(
		'it618_rtmpcode' => $it618_rtmpcode,
		'it618_m3u8url' => $it618_m3u8url,
		'it618_flvurl' => $it618_flvurl,
	));
}

function it618_video_get_contents($str){
	return dfsockopen($str);
}

function it618_video_getshopgoods($shopid,$page=1,$wap=0,$orderbytmp=''){
	global $_G,$it618_video,$templatename,$it618_video_lang,$creditname;
	$creditname=$_G['setting']['extcredits'][$it618_video['video_credit']]['title'];
	if($wap==1){
		$ppp = 18;
		
		if($it618_video['video_style']>2){
			$videostyle=getcookie('videostyle');
			if($videostyle==''){
				if($it618_video['video_style']==3)$videostyle='1';else $videostyle='2';
			}
		}else{
			if($it618_video['video_style']==1)$videostyle='1';else $videostyle='2';
		}
	}else{
		if($templatename=='mall')$ppp = 10;else $ppp = 12;
	}
	$page = max(1, intval($page));
	$startlimit = ($page - 1) * $ppp;
	
	$sql='';
	$orderby='g.it618_shoporder desc,g.it618_plays desc';
	if($orderbytmp=='plays')$orderby='g.it618_plays desc';
	if($orderbytmp=='views')$orderby='g.it618_views desc';
	if($orderbytmp=='jfbl'){
		$sql=' and g.it618_saleprice>0 and g.it618_score>0';
		$orderby='g.it618_jfbl desc';
	}
	if($orderbytmp=='time')$orderby='g.it618_time desc';
	
	$tdn=1;
	foreach(C::t('#it618_video#it618_video_goods')->fetch_all_by_search(
		'g.it618_state=1'.$sql,$orderby,$shopid,0,0,'',0,0,$startlimit,$ppp
	) as $it618_video_goods) {
		$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
		
		$jfbl='';
		if($it618_video_goods['it618_jfbl']>0&&$it618_video_goods['it618_saleprice']>0){
			//$jfbl='<div class="divjfbl">'.$it618_video_lang['s1371'].str_replace(".00","",$it618_video_goods['it618_jfbl']).'%'.$creditname.'</div>';
		}
		
		if($wap==1){
			
			$it618_isvip='';
			$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
			if(count($vipgroupids)>0){
				$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" class="imgvip">';
			}
		
			$it618_islive='';
			if(C::t('#it618_video#it618_video_live')->count_by_pid_ok($it618_video_goods['id'])>0){
				$it618_islive='<img src="source/plugin/it618_video/images/live.gif" class="imglive">';
			}
			
			$pricestr='<span style="color:#f30">'.$it618_video_lang['s1534'].'</span>';
			$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
			if($it618_video_shop['it618_issale']==1){
				if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
					$pricestr='<span style="color:#f30">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
				}else{
					$pricestr='<span style="color:#390">'.$it618_video_lang['s106'].'</span>';
				}
			}
			
			if($it618_video_goods['it618_price']>0){
				$pricestr.=' <del>&yen;'.$it618_video_goods['it618_price'].'</del>';
			}
			
			DB::query("UPDATE ".DB::table('it618_video_goods')." SET it618_pjpfstr='".$pj."' WHERE id=".$it618_video_goods['id']);
			
			$zk=sprintf("%.2f", $it618_video_goods['it618_saleprice']/$it618_video_goods['it618_price'])*10;
			
			$tmpurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);
			
			if($videostyle=='1'){
			
				$strlist.='<tr>
								<td class="tdleft">'.$jfbl.$it618_islive.'<a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'"/></a></td>
								<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
									<div class="tdname">'.$it618_video_goods['it618_name'].'</div>
									<div class="tddes">'.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).' '.$it618_video_goods['it618_plays'].it618_video_getlang('s931').'</div>
									<div class="tdprice">'.$it618_isvip.$pricestr.'</div>
								</td>
							  </tr>
							  <tr><td colspan="2" class="tdcolspan"></td></tr>';
			}else{
				if($tdn%2>0){
					$trtmpstr='<tr>';
					$tdstr='class="tdleft"';
				}else{
					$tdstr='class="tdright"';
				}
				
				$trtmpstr.='<td '.$tdstr.'><div class="tddiv">
								<a href="'.$tmpurl.'">
								'.$jfbl.$it618_islive.'
							<div class="divtime">'.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).' <img src="source/plugin/it618_video/images/plays.png" class="imguser">'.$it618_video_goods['it618_plays'].'</div>
							<img class="lazy" data-original="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'"/>
								<div class="tdname">'.$it618_video_goods['it618_name'].'</div>
								<div class="tdprice">'.$it618_isvip.$pricestr.'</div>
							</a></div></td>';
							
				if($tdn%2==0){
					$trtmpstr.='</tr>';
					$strlist.=$trtmpstr;
				}
				
				$tdn=$tdn+1;
			}
		}else{
			if($templatename=='mall'){
			
				$pricestr='<span class="price" style="color:#f30;font-size:20px">'.$it618_video_lang['s1534'].'</span>';
				if($it618_video_shop['it618_issale']==1){
					if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
						$pricestr='<span class="price" style="padding:0;padding-right:3px">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
					}else{
						$pricestr='<span class="price" style="color:#390;font-size:20px">'.$it618_video_lang['s106'].'</span>';
					}
				}
				
				$it618_isvip='';
				$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
				if(count($vipgroupids)>0){
					$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
				}
				
				$it618_islive='';
				if(C::t('#it618_video#it618_video_live')->count_by_pid_ok($it618_video_goods['id'])>0){
					$it618_islive='<img src="source/plugin/it618_video/images/live.gif" class="imglive">';
				}
				
				$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
				$getshopgoods.='<div class="goods lgoods">
							'.$jfbl.$it618_islive.'
							<a class="goods-img" href="'.$tmpurl.'" target="_blank">
							<img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" width="380" height="206" alt="'.$it618_video_goods['it618_name'].'" />
							</a>
							<h3>
							<a class="goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'">'.$it618_video_goods['it618_name'].'</a>
							<a class="goods-text" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_description'].'">'.$it618_video_goods['it618_description'].'</a>
							<span style="color:#999;line-height:35px;font-weight:normal;font-size:12px"><span style="float:right"><font color=red>'.$it618_video_goods['it618_plays'].'</font>'.it618_video_getlang('s931').'</span>'.$it618_isvip.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'</span>
							</h3>
							<div class="goods-info">
							'.$pricestr.'
							</div>
							</div>';
			}
			
			if($templatename=='edu'){
				$pricestr='<span style="color:#f30;font-size:13px">'.$it618_video_lang['s1534'].'</span>';
				if($it618_video_shop['it618_issale']==1){
					if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
						$pricestr='<span class="price">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
					}else{
						$pricestr='<span style="color:#390;">'.$it618_video_lang['s106'].'</span>';
					}
				}
				
				$it618_isvip='';
				$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
				if(count($vipgroupids)>0){
					$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
				}
				
				$it618_islive='';
				if(C::t('#it618_video#it618_video_live')->count_by_pid_ok($it618_video_goods['id'])>0){
					$it618_islive='<img src="source/plugin/it618_video/images/live.gif" class="imglive">';
				}
				
				$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
				$getshopgoods.='<div class="course-card" title="'.$it618_video_goods['it618_name'].'">
									'.$jfbl.$it618_islive.'
									<div class="course-img">
										<a href="'.$tmpurl.'" target="_blank"><img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" alt="'.$it618_video_goods['it618_name'].'" class="goodsimg"></a>
										<div class="course-name">
											<a href="'.$tmpurl.'" target="_blank">'.cutstr($it618_video_goods['it618_name'],48,'...').'</a>
										</div>
										<div class="course-author">
											'.$it618_isvip.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'
										</div>
										<div class="course-price">
											'.$pricestr.'
											<span class="course-plays">'.$it618_video_goods['it618_plays'].''.it618_video_getlang('s931').'</span>
										</div>
									</div>
								</div>';
			}
		}
	}
	
	if($wap==1){
		if($videostyle=='1'){
			$tmparr=explode('</tr>',$strlist);
			if(count($tmparr)>1){
				$strlist=$strlist.'@@@';
				$strlist=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$strlist);
			}
		}else{
			$trtmpstr1=$trtmpstr.'@@@';
			$tmparr=explode('</td>@@@',$trtmpstr1);
			if(count($tmparr)>1){
				$trtmpstr=str_replace('<td class="tdleft"','<td class="tdleft tdleft1" style="padding-right:13px"',$trtmpstr.'</tr>');
				$strlist.=$trtmpstr;
			}
		}
		
		$getshopgoods=$strlist;
	}
	
	$count = C::t('#it618_video#it618_video_goods')->count_by_search('g.it618_state=1'.$sql,'',$shopid);
	$funname='getshopgoods';
	
	if($wap==1){
		
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}

		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_video_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}else{
		$multipage = multi($count, $ppp, $page, $_G['siteurl'].'plugin.php?id=it618_video:ajax');
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',''.$funname.'(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
	}
	
	return $getshopgoods.'it618_split'.$multipage;
}

function it618_video_delsalework(){
	DB::query("delete from ".DB::table('it618_video_salework'));
}

function it618_video_get_contents1($str){
	return dfsockopen($str);
}

function it618_video_sendmessage($type,$id,$type1=''){
	global $_G,$creditname,$it618_video_lang;
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/message.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_video/config/message.php';
	
	$tmpurl=it618_video_getrewrite('video_wap','','plugin.php?id=it618_video:wap');
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].'/';
	
	if($it618_isok==1){
		
		if($it618_isok_admin==1){
			if($type=='rz_admin'&&$it618_body_rz_admin_isok==1){
				$tel=$it618_tel_admin;
				
				$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_rz_admin_tplid_wxsms;
				$body_wxsms=$it618_body_rz_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_video_getusername($it618_video_shop['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_video_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_rz_admin;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_video_getusername($it618_video_shop['it618_uid']),$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_rz_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_video_getusername($it618_video_shop['it618_uid']).'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='tx_admin'&&$it618_body_tx_admin_isok==1){
				$tel=$it618_tel_admin;
				
				$it618_video_tx = C::t('#it618_video#it618_video_tx')->fetch_by_id($id);
				$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_tx['it618_shopid']);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_tx_admin_tplid_wxsms;
				$body_wxsms=$it618_body_tx_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{shopname}",$it618_video_shop['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{txmoney}",$it618_video_tx['it618_price'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_video_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_tx_admin;
				
				$ALDYBody=$Body;
				$Body=str_replace("{shopname}",$it618_video_shop['it618_name'],$Body);
				$Body=str_replace("{txmoney}",$it618_video_tx['it618_price'],$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $_G['timestamp']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_tx_admin_tplid;
					
					$tmparr=explode("{shopname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"shopname":"'.$it618_video_shop['it618_name'].'",';
					
					$tmparr=explode("{txmoney}",$ALDYBody);
					if(count($tmparr)>1)$param.='"txmoney":"'.$it618_video_tx['it618_price'].'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $_G['timestamp']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='sale_admin'&&$it618_body_sale_admin_isok==1){
				$tel=$it618_tel_admin;

				$it618_video_sale = C::t('#it618_video#it618_video_sale')->fetch_by_id($id);
				$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
				$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
				
				if($it618_video_sale['it618_price']>0||$it618_video_sale['it618_score']>0){
					$pricestr=it618_video_getsalemoney($it618_video_sale);
				}else{
					$pricestr=$it618_video_lang['s106'];
				}
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_sale_admin_tplid_wxsms;
				$body_wxsms=$it618_body_sale_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_video_getusername($it618_video_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_video_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{pprice}",$pricestr,$tmpvalue);
						$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_video_sale['it618_tel'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_sale['it618_time']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_video_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_sale_admin;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_video_getusername($it618_video_sale['it618_uid']),$Body);
				$Body=str_replace("{pname}",$it618_video_goods['it618_name'],$Body);
				$Body=str_replace("{pprice}",$pricestr,$Body);
				$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
				$Body=str_replace("{tel}",$it618_video_sale['it618_tel'],$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_sale['it618_time']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_video_getusername($it618_video_sale['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_video_getsmsstr($it618_video_goods['it618_name'],$it618_length).'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$pricestr.'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_video_sale['it618_tel'].'",';
					
					$tmparr=explode("{purl}",$ALDYBody);
					if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_video_sale['it618_time']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='gwc_admin'&&$it618_body_gwc_admin_isok==1){
				$tel=$it618_tel_admin;
				
				$it618_video_sale = C::t('#it618_video#it618_video_sale')->fetch_by_gwcid($id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_gwc_admin_tplid_wxsms;
				$body_wxsms=$it618_body_gwc_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_video_getusername($it618_video_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{gwcid}",$id,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_video_sale['it618_tel'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_sale['it618_time']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_video_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_gwc_admin;	

				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_video_getusername($it618_video_sale['it618_uid']),$Body);
				$Body=str_replace("{gwcid}",$id,$Body);
				$Body=str_replace("{tel}",$it618_video_sale['it618_tel'],$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_sale['it618_time']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_gwc_admin_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_video_getusername($it618_video_sale['it618_uid']).'",';
					
					$tmparr=explode("{gwcid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"gwcid":"'.$id.'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_video_sale['it618_tel'].'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_video_sale['it618_time']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}

			}
		}
		
		if($type=='tx_shop'&&$it618_body_tx_shop_isok==1){
			$it618_video_tx = C::t('#it618_video#it618_video_tx')->fetch_by_id($id);
			$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_tx['it618_shopid']);
			
			$tel=$it618_video_shop['it618_msgtel'];
			
			if($it618_video_shop['it618_msgisok']==1){
				
				$uid=$it618_video_shop['it618_uid'];
				$tplid_wxsms=$it618_body_tx_shop_tplid_wxsms;
				$body_wxsms=$it618_body_tx_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{txmoney}",$it618_video_tx['it618_price'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_tx['it618_time']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_video_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_tx_shop;
				
				$ALDYBody=$Body;
				$Body=str_replace("{txmoney}",$it618_video_tx['it618_price'],$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_tx['it618_time']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_tx_shop_tplid;
					
					$tmparr=explode("{txmoney}",$ALDYBody);
					if(count($tmparr)>1)$param.='"txmoney":"'.$it618_video_tx['it618_price'].'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_video_tx['it618_time']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sale_shop'&&$it618_body_sale_shop_isok==1){
			$it618_video_sale = C::t('#it618_video#it618_video_sale')->fetch_by_id($id);
			$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
			
			$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_sale['it618_shopid']);
			
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
			
			if($it618_video_sale['it618_price']>0||$it618_video_sale['it618_score']>0){
				$pricestr=it618_video_getsalemoney($it618_video_sale);
			}else{
				$pricestr=$it618_video_lang['s106'];
			}
			
			$tel=$it618_video_shop['it618_msgtel'];
			
			if($it618_video_shop['it618_msgisok']==1){
				$uid=$it618_video_brand['it618_uid'];
				$tplid_wxsms=$it618_body_sale_shop_tplid_wxsms;
				$body_wxsms=$it618_body_sale_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_video_getusername($it618_video_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_video_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{pprice}",$pricestr,$tmpvalue);
						$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_video_sale['it618_tel'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_sale['it618_time']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_video_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_sale_shop;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_video_getusername($it618_video_sale['it618_uid']),$Body);
				$Body=str_replace("{pname}",$it618_video_goods['it618_name'],$Body);
				$Body=str_replace("{pprice}",$pricestr,$Body);
				$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
				$Body=str_replace("{tel}",$it618_video_sale['it618_tel'],$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_sale['it618_time']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_shop_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_video_getusername($it618_video_sale['it618_uid']).'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_video_getsmsstr($it618_video_goods['it618_name'],$it618_length).'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$pricestr.'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_video_sale['it618_tel'].'",';
					
					$tmparr=explode("{purl}",$ALDYBody);
					if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_video_sale['it618_time']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='gwc_shop'&&$it618_body_gwc_shop_isok==1){
			$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($type1);
	
			$tel=$it618_video_shop['it618_msgtel'];

			if($it618_video_shop['it618_msgisok']==1){
				$it618_video_sale = C::t('#it618_video#it618_video_sale')->fetch_by_gwcid_shopid($id,$type1);
				
				$uid=$it618_video_shop['it618_uid'];
				$tplid_wxsms=$it618_body_gwc_shop_tplid_wxsms;
				$body_wxsms=$it618_body_gwc_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{user}",it618_video_getusername($it618_video_sale['it618_uid']),$tmpvalue);
						$tmpvalue=str_replace("{gwcid}",$id,$tmpvalue);
						$tmpvalue=str_replace("{tel}",$it618_video_sale['it618_tel'],$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_sale['it618_time']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_video_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_gwc_shop;
				
				$ALDYBody=$Body;
				$Body=str_replace("{user}",it618_video_getusername($it618_video_sale['it618_uid']),$Body);
				$Body=str_replace("{gwcid}",$id,$Body);
				$Body=str_replace("{tel}",$it618_video_sale['it618_tel'],$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_sale['it618_time']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_gwc_shop_tplid;
					
					$tmparr=explode("{user}",$ALDYBody);
					if(count($tmparr)>1)$param.='"user":"'.it618_video_getusername($it618_video_sale['it618_uid']).'",';
					
					$tmparr=explode("{gwcid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"gwcid":"'.$id.'",';
					
					$tmparr=explode("{tel}",$ALDYBody);
					if(count($tmparr)>1)$param.='"tel":"'.$it618_video_sale['it618_tel'].'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_video_sale['it618_time']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='media_shop'&&$it618_body_media_shop_isok==1){
			$it618_video_media = C::t('#it618_video#it618_video_media')->fetch_by_id($id);
			$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_media['it618_shopid']);
	
			$tel=$it618_video_shop['it618_msgtel'];

			if($it618_video_shop['it618_msgisok']==1){
				if($it618_video_media['it618_chkstate']==0)$chkstate=$it618_video_lang['s679'];
				if($it618_video_media['it618_chkstate']==1)$chkstate=$it618_video_lang['s678'];

				$uid=$it618_video_shop['it618_uid'];
				$tplid_wxsms=$it618_body_media_shop_tplid_wxsms;
				$body_wxsms=$it618_body_media_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{medianame}",$it618_video_media['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{chkstate}",$chkstate,$tmpvalue);
						$tmpvalue=str_replace("{mediaid}",$id,$tmpvalue);
						$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_media['it618_time']),$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_video_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$Body=$it618_body_media_shop;
				
				$ALDYBody=$Body;
				$Body=str_replace("{medianame}",$it618_video_media['it618_name'],$Body);
				$Body=str_replace("{chkstate}",$chkstate,$Body);
				$Body=str_replace("{mediaid}",$id,$Body);
				$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_media['it618_time']),$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_media_shop_tplid;
					
					$tmparr=explode("{medianame}",$ALDYBody);
					if(count($tmparr)>1)$param.='"medianame":"'.$it618_video_media['it618_name'].'",';
					
					$tmparr=explode("{chkstate}",$ALDYBody);
					if(count($tmparr)>1)$param.='"chkstate":"'.$chkstate.'",';
					
					$tmparr=explode("{mediaid}",$ALDYBody);
					if(count($tmparr)>1)$param.='"mediaid":"'.$id.'",';
					
					$tmparr=explode("{time}",$ALDYBody);
					if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_video_media['it618_time']).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			
			}

		}
		
		if($type=='sale_user'&&$it618_body_sale_user_isok==1){
			$it618_video_sale = C::t('#it618_video#it618_video_sale')->fetch_by_id($id);
			$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
			
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
			
			if($it618_video_sale['it618_price']>0||$it618_video_sale['it618_score']>0){
				$pricestr=it618_video_getsalemoney($it618_video_sale);
			}else{
				$pricestr=$it618_video_lang['s106'];
			}
			
			$tel=$it618_video_sale['it618_tel'];
			
			$uid=$it618_video_sale['it618_uid'];
			$tplid_wxsms=$it618_body_sale_user_tplid_wxsms;
			$body_wxsms=$it618_body_sale_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_video_getusername($it618_video_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{pname}",$it618_video_goods['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{pprice}",$pricestr,$tmpvalue);
					$tmpvalue=str_replace("{code}",$it618_video_sale['it618_code'],$tmpvalue);
					$tmpvalue=str_replace("{purl}",$url_this.$tmpurl,$tmpvalue);
					$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_sale['it618_time']),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_video_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
				
			$Body=$it618_body_sale_user;
			
			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_video_getusername($it618_video_sale['it618_uid']),$Body);
			$Body=str_replace("{pname}",$it618_video_goods['it618_name'],$Body);
			$Body=str_replace("{pprice}",$pricestr,$Body);
			$Body=str_replace("{purl}",$url_this.$tmpurl,$Body);
			$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_sale['it618_time']),$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sale_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_video_getusername($it618_video_sale['it618_uid']).'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.it618_video_getsmsstr($it618_video_goods['it618_name'],$it618_length).'",';
				
				$tmparr=explode("{pprice}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pprice":"'.$pricestr.'",';
				
				$tmparr=explode("{purl}",$ALDYBody);
				if(count($tmparr)>1)$param.='"purl":"'.$url_this.$tmpurl.'",';
				
				$tmparr=explode("{time}",$ALDYBody);
				if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_video_sale['it618_time']).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}

		}
		
		if($type=='gwc_user'&&$it618_body_gwc_user_isok==1){
			$it618_video_sale = C::t('#it618_video#it618_video_sale')->fetch_by_gwcid($id);
			$tel=$it618_video_sale['it618_tel'];
			
			$uid=$it618_video_sale['it618_uid'];
			$tplid_wxsms=$it618_body_gwc_user_tplid_wxsms;
			$body_wxsms=$it618_body_gwc_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_video_getusername($it618_video_sale['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{gwcid}",$id,$tmpvalue);
					$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_sale['it618_time']),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_video_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$Body=$it618_body_gwc_user;		

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_video_getusername($it618_video_sale['it618_uid']),$Body);
			$Body=str_replace("{gwcid}",$id,$Body);
			$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_sale['it618_time']),$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_gwc_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_video_getusername($it618_video_sale['it618_uid']).'",';
				
				$tmparr=explode("{gwcid}",$ALDYBody);
				if(count($tmparr)>1)$param.='"gwcid":"'.$id.'",';
				
				$tmparr=explode("{time}",$ALDYBody);
				if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_video_sale['it618_time']).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='live_user'&&$it618_body_live_user_isok==1){
			$it618_video_live_order = C::t('#it618_video#it618_video_live_order')->fetch_by_id($id);
			$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_live_order['it618_liveid']);
			$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_liveid($it618_video_live_order['it618_liveid']);
			
			$tel=$it618_video_live_order['it618_tel'];
			
			$tmpurl=it618_video_getrewrite('video_lesson',$it618_video_goods_video['id'],'plugin.php?id=it618_video:lesson&lid='.$it618_video_goods_video['id']);
			
			$uid=$it618_video_live_order['it618_uid'];
			$tplid_wxsms=$it618_body_live_user_tplid_wxsms;
			$body_wxsms=$it618_body_live_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_video_getusername($it618_video_live_order['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{name}",$it618_video_live['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_live['it618_btime']),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_video_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$Body=$it618_body_live_user;		

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_video_getusername($it618_video_live_order['it618_uid']),$Body);
			$Body=str_replace("{name}",$it618_video_live['it618_name'],$Body);
			$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_live['it618_btime']),$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_live_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_video_getusername($it618_video_live_order['it618_uid']).'",';
				
				$tmparr=explode("{name}",$ALDYBody);
				if(count($tmparr)>1)$param.='"name":"'.it618_video_getsmsstr($it618_video_live['it618_name'],$it618_length).'",';
				
				$tmparr=explode("{time}",$ALDYBody);
				if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_video_live['it618_btime']).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($type=='push_user'&&$it618_body_push_user_isok==1){
			$it618_video_shop_push = C::t('#it618_video#it618_video_shop_push')->fetch_by_id($id);
			$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_shop_push['it618_shopid']);
			$it618_video_shop_subscribe = C::t('#it618_video#it618_video_shop_subscribe')->fetch_by_shopid_uid($it618_video_shop_push['it618_shopid'],$type1);
			
			$tmpurl=$it618_video_shop_push['it618_url'];
			
			if($it618_video_shop_push['it618_istelmessage']==1)$tel=$it618_video_shop_subscribe['it618_tel'];
			
			$uid=$it618_video_shop_subscribe['it618_uid'];
			$tplid_wxsms=$it618_body_push_user_tplid_wxsms;
			$body_wxsms=$it618_body_push_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{user}",it618_video_getusername($it618_video_shop_subscribe['it618_uid']),$tmpvalue);
					$tmpvalue=str_replace("{shopname}",$it618_video_shop['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{content}",it618_video_getsmsstr($it618_video_shop_push['it618_message'],$it618_length),$tmpvalue);
					$tmpvalue=str_replace("{url}",str_replace($_G['siteurl'],'',$it618_video_shop_push['it618_url']),$tmpvalue);
					$tmpvalue=str_replace("{turl}",$it618_video_shop_push['it618_url'],$tmpvalue);
					$tmpvalue=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_shop_push['it618_time']),$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_video_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$Body=$it618_body_push_user;		

			$ALDYBody=$Body;
			$Body=str_replace("{user}",it618_video_getusername($it618_video_shop_subscribe['it618_uid']),$Body);
			$Body=str_replace("{shopname}",$it618_video_shop['it618_name'],$Body);
			$Body=str_replace("{content}",$it618_video_shop_push['it618_message'],$Body);
			$Body=str_replace("{url}",str_replace($_G['siteurl'],'',$it618_video_shop_push['it618_url']),$Body);
			$Body=str_replace("{turl}",$it618_video_shop_push['it618_url'],$Body);
			$Body=str_replace("{time}",date('Y-m-d H:i:s', $it618_video_shop_push['it618_time']),$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_push_user_tplid;
				
				$tmparr=explode("{user}",$ALDYBody);
				if(count($tmparr)>1)$param.='"user":"'.it618_video_getusername($it618_video_shop_subscribe['it618_uid']).'",';
				
				$tmparr=explode("{shopname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"shopname":"'.$it618_video_shop['it618_name'].'",';
				
				$tmparr=explode("{content}",$ALDYBody);
				if(count($tmparr)>1)$param.='"content":"'.$it618_video_shop_push['it618_message'].'",';
				
				$tmparr=explode("{url}",$ALDYBody);
				if(count($tmparr)>1)$param.='"url":"'.str_replace($_G['siteurl'],'',$it618_video_shop_push['it618_url']).'",';
				
				$tmparr=explode("{turl}",$ALDYBody);
				if(count($tmparr)>1)$param.='"turl":"'.$it618_video_shop_push['it618_url'].'",';
				
				$tmparr=explode("{time}",$ALDYBody);
				if(count($tmparr)>1)$param.='"time":"'.date('Y-m-d H:i:s', $it618_video_shop_push['it618_time']).'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($Body!=''||(count($param_wxsms)>0&&$uid!='')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_video/message.func.php';
			
			if(count($param_wxsms)>0&&$uid!=''){
				$tmparr=explode(",",$uid);
				for($i=0;$i<count($tmparr);$i++){
					$tmparrtmp=explode("://",$tmpurl);
					if(count($tmparrtmp)==1)$tmpurl=$url_this.$tmpurl;
					$wxsms=sendSMS_WX($tmparr[$i],$tmpurl,$tplid_wxsms,$param_wxsms);
				}
			}
			
			if($wxsms=='true')return 1;
			
			if($tel!=''&&$wxsms!='true'){
				$Body=str_replace('$','',$Body);
	
				if($it618_type=='smsbao'){
					if($it618_smsbaosign!='')$it618_smsbaosign=$it618_video_lang['s1860'].$it618_smsbaosign.$it618_video_lang['s1861'];
					$dxsms=sendSMS($it618_tel,$it618_password,$tel,$it618_smsbaosign.$Body);
				}else{
					$dxsms=sendSMS_ALi($tel,$Body,$it618_sign,$tplid,$param,$it618_type);
				}
			}
			
			if($dxsms=='true')return 2;
			return 0;
		}
	}
}

function it618_video_get_contents2($str){
	return dfsockopen($str);
}

function it618_video_multipage($pagevalue,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_video']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/rewrite.php')){
		return $pagevalue;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_video/config/rewrite.php';

	$tmparr=explode("it618page".$urltype."?page=",$pagevalue);
	$pagevalue='';

	$urltype=$urltype.$uri;
	for($i=0;$i<count($tmparr);$i++){
		
		$tmpstr=$tmparr[$i];
		$tmparr1=explode('" class=',$tmpstr);
		if(count($tmparr1)>1){
			$page=$tmparr1[0];
			$tmpstr=str_replace($page.'" class=',$page.$urltype.'" class=',$tmpstr);
		}
		
		$tmparr1=explode('">',$tmpstr);
		$tmparr2=explode('</a><',$tmparr1[1]);
		if(count($tmparr2)>1){
			$page=$tmparr2[0];
			$tmpstr=str_replace($page.'">'.$page.'</a>',$page.$urltype.'">'.$page.'</a>',$tmpstr);
			
		}
		
		$pagevalue.=$tmpstr;
	}
	
	$pagevalue=str_replace("+this.value","+this.value+'".$urltype."'",$pagevalue);
	
	return $pagevalue;
}


function it618_video_getrewrite($pagetype,$pagevalue,$url,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_video']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/rewrite.php')){
		return $url;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_video/config/rewrite.php';
	
	if($pagetype=='video_home'){
		return $video_home.$urltype;
	}
	
	if($pagetype=='video_list'){//video_list-{cid1}-{cid2}-{price}-{order}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$video_list.$video_list1;

		if(count($tmparr)==1){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("-{cid2}-{price}-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==2){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("-{aid1}-{aid2}-{price}-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==2){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("-{price}-{order}-{page}",'',$pageurl);
		}
		
		if(count($tmparr)==4){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{price}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{order}",$tmparr[3],$pageurl);
			$pageurl=str_replace("{page}",'1',$pageurl);
		}
		
		if(count($tmparr)==5){
			$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{price}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{order}",$tmparr[3],$pageurl);
			$pageurl=str_replace("{page}",$tmparr[4],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='video_search'){//video_search-{cid1}-{cid2}-{price}-{order}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$video_search.$video_search1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{cid1}-{cid2}-{price}-{order}-{page}","",$pageurl);
		}else{
			if(count($tmparr)==4){
				$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{price}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{order}",$tmparr[3],$pageurl);
				$pageurl=str_replace("{page}",'1',$pageurl);
			}
			
			if(count($tmparr)==5){
				$pageurl=str_replace("{cid1}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{price}",$tmparr[2],$pageurl);
				$pageurl=str_replace("{order}",$tmparr[3],$pageurl);
				$pageurl=str_replace("{page}",$tmparr[4],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='video_product'){//video_product-{pid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$video_product.$video_product1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{pid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='video_lesson'){//lesson-{lid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$video_lesson.$video_lesson1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{lid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='video_lecturer'){//lecturer-{lid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$video_lecturer.$video_lecturer1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{lid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='video_gwc'){
		return $video_gwc.$urltype;
	}
	
	if($pagetype=='video_gwcmysale'){
		return $video_gwc.$urltype.'?mysale';
	}
	
	if($pagetype=='video_sc'){
		return $video_sc.$urltype.$uri;
	}
	
	if($pagetype=='video_wap'){//video_wap-{pagetype}-{cid1}-{cid2}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$video_wap.$video_wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid1}-{cid2}","",$pageurl);
		}else{
			if(count($tmparr)==1){
				$pageurl=str_replace("{pagetype}",$pagevalue,$pageurl);
				$pageurl=str_replace("-{cid1}-{cid2}","",$pageurl);
			}
			if(count($tmparr)==2){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("-{cid2}","",$pageurl);
			}
			if(count($tmparr)==3){
				$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
				$pageurl=str_replace("{cid1}",$tmparr[1],$pageurl);
				$pageurl=str_replace("{cid2}",$tmparr[2],$pageurl);
			}
		}
		
		return $pageurl.$uri;
	}
}

function it618_video_exam_getrewrite($pagetype,$pagevalue,$url,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_exam']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_exam/config/rewrite.php')){
		return $url;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_exam/config/rewrite.php';
	
	if($pagetype=='exam_product'){//exam_product-{pid}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$exam_product.$exam_product1;
		
		if(count($tmparr)==1){
			$pageurl=str_replace("{pid}",$tmparr[0],$pageurl);
		}
		
		return $pageurl.$uri;
	}
}

function it618_video_get_contents3($str){
	return dfsockopen($str);
}

function it618_video_utftogbk($strcontent,$type=1){
	if($type==1)$strcontent=dhtmlspecialchars($strcontent);
	
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_video_gbktoutf($strcontent);
	}
}

function it618_video_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function it618_video_delfile($dirName){
}

function it618_video_del_dir($dir,$type=0){
    if(is_dir($dir)){
        foreach(scandir($dir) as $row){
            if($row == '.' || $row == '..'){
                continue;
            }
            $path = $dir .'/'. $row;
            if(filetype($path) == 'dir'){
            }else{
            }
        }
        if($type==1);
    }else{
        return false;
    }
}

function it618_video_getsize($size) { 
	$format = 'M';
	$size1=$size;
    $size /= pow(1024, 2); 
	$getsize=number_format($size, 2);
	if($getsize<1){
		$format = 'K';
		$size1 /= pow(1024, 1); 
		$getsize=number_format($size1, 2);
	}
	
    return $getsize.$format;  
}  

function it618_video_get_contents4($str){
	return dfsockopen($str);
}

function it618_video_dirsize($dir) { 
	@$dh = opendir($dir); 
	$size = 0; 
	while ($file = @readdir($dh)) { 
	if ($file != "." and $file != "..") { 
	$path = $dir."/".$file; 
	if (is_dir($path)) { 
	$size += it618_video_dirsize($path); 
	} elseif (is_file($path)) { 
	$size += filesize($path); 
	} 
	} 
	} 
	@closedir($dh); 
	return $size; 
}

function it618_video_getusername($uid){
	return C::t('#it618_video#it618_video_sale')->fetch_username_by_uid($uid);
}

function it618_video_gettime($it618_time){
	global $_G;
	$timecount=intval(($_G['timestamp']-$it618_time)/3600);
	if($timecount>24){
		$timecount=intval($timecount/24);
		$timestr=$timecount.it618_video_getlang('s449');
	}elseif($timecount>=1){
		$timestr=$timecount.it618_video_getlang('s450');
	}else{
		$timecount=intval(($_G['timestamp']-$it618_time)/60);
		if($timecount>=1){
			$timestr=$timecount.it618_video_getlang('s451');
		}else{
			$timecount=intval(($_G['timestamp']-$it618_time));
			if($timecount==0)$timecount=1;
			$timestr=$timecount.it618_video_getlang('s452');
		}
	}
	
	return $timestr;
}

function it618_video_gettime1($it618_time){
	global $_G,$it618_video_lang;
	$timecount=intval(($it618_time-$_G['timestamp'])/3600);
	if($timecount>24){
		$timestr=date('@m'.$it618_video_lang['t65'].'@d', $it618_time);
	}elseif($timecount>=1){
		$timestr=date('@H'.$it618_video_lang['s397'].'@i', $it618_time);
	}else{
		$timecount=intval(($it618_time-$_G['timestamp'])/60);
		if($timecount>=1){
			$timestr=date('@H'.$it618_video_lang['s397'].'@i', $it618_time);
		}else{
			$timestr=date('@i'.$it618_video_lang['s398'].'@s', $it618_time);
		}
	}
	
	$timestr=str_replace("@0","",$timestr);
	$timestr=str_replace("@","",$timestr);
	
	return $timestr;
}

function it618_video_gettime11($it618_time){
	global $_G;
	$timecount=intval(($it618_time-$_G['timestamp'])/3600);
	if($timecount>24){
		$timecount=intval($timecount/24);
		$timestr=$timecount.it618_video_getlang('s1449');
	}elseif($timecount>=1){
		$timestr=$timecount.it618_video_getlang('s1450');
	}else{
		$timecount=intval(($it618_time-$_G['timestamp'])/60);
		if($timecount>=1){
			$timestr=$timecount.it618_video_getlang('s1451');
		}else{
			$timecount=intval(($it618_time-$_G['timestamp']));
			if($timecount==0)$timecount=1;
			$timestr=$timecount.it618_video_getlang('s1452');
		}
	}
	
	return $timestr;
}

function it618_video_discuz_uc_avatar($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   if(empty($GLOBALS['avatarmethod'])) {
		return $returnsrc ? UC_API.'/avatar.php?uid='.$uid.'&size='.$size : '<img src="'.UC_API.'/avatar.php?uid='.$uid.'&size='.$size.'" />';
	   } else {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	   }
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_video_getonlinestate($it618_uid){
	if(TIMESTAMP-C::t('#it618_video#it618_video_goods_video_pl')->fetch_lastactivity_by_uid($it618_uid)<=900){
		$tmponlineico='source/plugin/it618_video/images/online.gif';
	}else{
		$tmponlineico='source/plugin/it618_video/images/offline.gif';
	}
	
	return $tmponlineico;
}

function it618_video_get_contents5($str){
	return dfsockopen($str);
}

function it618_video_discuz_uc_avatar1($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   $uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_video_rewriteurl($uid){
	global $_G;
	if($_G['cache']['plugin']['it618_video']['rewriteurl']==1){
		return 'space-uid-'.$uid.'.html';
	}else{
		return 'home.php?mod=space&uid='.$uid;
	}
}

function it618_video_getfileext($filestr){
	$file_ext=strtolower(substr($filestr,strrpos($filestr, '.')+1)); 
	$tmparr=explode("?",$file_ext);
	return $tmparr[0];
}

function it618_video_getgoodspic($shopid,$pid,$it618_picbig,$i=0){
	$file_ext=it618_video_getfileext($it618_picbig);
	
	return 'source/plugin/it618_video/kindeditor/data/shop'.$shopid.'/smallimages/goods'.$pid.'_'.md5($it618_picbig).'.'.$file_ext.'?'.substr(md5($it618_picbig),0,6);
}

function it618_video_getwapppic($shopid,$pid,$get_it618_picbig,$type=1){
	$file_ext=it618_video_getfileext($get_it618_picbig); 
	
	if($shopid=='wapad'){
		$file_ext=it618_video_getfileext($get_it618_picbig); 
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/smallimage/wapad'.$pid.'.'.$file_ext;
		
		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {
				
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/smallimage/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			it618_video_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,280,1);
		}
		
		$it618_smallurl='source/plugin/it618_video/kindeditor/data/smallimage/wapad'.$pid.'.'.$file_ext;
	}else{
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$shopid.'/smallimages/goods'.$pid.'_'.md5($get_it618_picbig).'.'.$file_ext;

		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {
			
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$shopid.'/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
				
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$shopid.'/smallimages/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$shopid.'/smallimages/goods'.$pid.'_'.md5($get_it618_picbig).'.'.$file_ext;
			it618_video_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,360,1);
		}
		
		$it618_smallurl='source/plugin/it618_video/kindeditor/data/shop'.$shopid.'/smallimages/goods'.$pid.'_'.md5($get_it618_picbig).'.'.$file_ext;
	}
	
	return $it618_smallurl.'?'.substr(md5($get_it618_picbig),0,6);
}

function it618_video_getpjpic($uid,$pjpicid,$picurl){
	$file_ext=it618_video_getfileext($picurl); 

	$tmparr1=explode("://",$picurl);
	if(count($tmparr1)>1){
		$it618_url=$picurl;
	}else{
		$tmparr=explode("source",$picurl);
		$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
	}

	$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/user/u'.$uid.'/smallimage/pjpic'.$pjpicid.'.'.$file_ext;
	
	it618_video_imagetosmall($it618_url,$it618_smallurl,$file_ext,48);

}

function it618_video_getvideowmpic(){
	global $_G;
	$it618_video = $_G['cache']['plugin']['it618_video'];
	
	$dst_path = $it618_video['video_wmbgimg']; 
	$dst = imagecreatefromstring(file_get_contents($dst_path)); 
	 
	$font = 'source/plugin/it618_video/images/font.ttf';
	$english = 'source/plugin/it618_video/images/english.ttf';
	
	$username=C::t('#it618_video#it618_video_sale')->fetch_username_by_uid($_G['uid']);
	
	$video_wmcontents=explode("@@@",str_replace(array("\r\n", "\r", "\n"), '@@@', $it618_video['video_wmcontent']));
	foreach($video_wmcontents as $key => $video_wmcontent){
		if($video_wmcontent!=""){
			$wmcontent=explode("|",$video_wmcontent);
			
			//{uid}|10|#ff0000|43|15
			$rgb=it618_video_hex2rgb($wmcontent[2]);
			$color = imagecolorallocate($dst, $rgb['r'], $rgb['g'], $rgb['b']);
			
			$wmcontent[0]=str_replace("{uid}",$_G['uid'],$wmcontent[0]);
			$wmcontent[0]=str_replace("{uname}",$username,$wmcontent[0]);
			
			imagefttext($dst, $wmcontent[1], 0, $wmcontent[3], $wmcontent[4], $color, $font, it618_video_gbktoutf($wmcontent[0])); 
		}
	}
	
	$smallimagepath=DISCUZ_ROOT.'./source/plugin/it618_video/qrcode/wm'.$_G['uid'].'.png';
	
	imagepng($dst,$smallimagepath);
	imagedestroy($dst); 
	
	return $_G['siteurl'].'source/plugin/it618_video/qrcode/wm'.$_G['uid'].'.png?'.time();
}

function it618_video_hex2rgb($hexColor) {
	$color = str_replace('#', '', $hexColor);
	if (strlen($color) > 3) {
		$rgb = array(
			'r' => hexdec(substr($color, 0, 2)),
			'g' => hexdec(substr($color, 2, 2)),
			'b' => hexdec(substr($color, 4, 2))
		);
	} else {
		$color = $hexColor;
		$r = substr($color, 0, 1) . substr($color, 0, 1);
		$g = substr($color, 1, 1) . substr($color, 1, 1);
		$b = substr($color, 2, 1) . substr($color, 2, 1);
		$rgb = array(
			'r' => hexdec($r),
			'g' => hexdec($g),
			'b' => hexdec($b)
		);
	}
	return $rgb;
}

function it618_video_imagetosmall($bigimagepath,$smallimagepath,$file_ext,$width,$height=0,$type=0){
	//��ΪPHPֻ�ܶ���Դ���в���������Ҫ����Ҫ�������ŵ�ͼƬ���п���������Ϊ�µ���Դ 
	if($file_ext=='jpg'||$file_ext=='jpeg')$src=imagecreatefromjpeg($bigimagepath); 
	if($file_ext=='png')$src=imagecreatefrompng($bigimagepath); 
	if($file_ext=='gif')$src=imagecreatefromgif($bigimagepath); 
	
	//ȡ��ԴͼƬ�Ŀ��Ⱥ͸߶� 
	$size_src=@getimagesize($bigimagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$maxָ�����ų��������Ŀ��ȣ�Ҳ�п����Ǹ߶ȣ�
	
	if($type==0){
		$max=$width;
		//�������ֵΪ300�������һ���ߵĳ��ȣ��õ����ź��ͼƬ���Ⱥ͸߶� 
		if($w > $h){ 
		   $w=$max;
		   $h=$h*($max/$size_src['0']); 
		}else{ 
		   $h=$max;
		   $w=$w*($max/$size_src['1']); 
		} 
	}else{
		$w=$width;
		$h=$height;
	}
	
	//����һ��$w����$h�ߵ����ͼƬ��Դ 
	$image=imagecreatetruecolor($w, $h); 
	 
	//�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h�� 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if($file_ext=='jpg'||$file_ext=='jpeg')imagejpeg($image,$smallimagepath); 
	if($file_ext=='png')imagepng($image,$smallimagepath); 
	if($file_ext=='gif')imagegif($image,$smallimagepath); 
	@chmod($smallimagepath, 0644);
	
	//������Դ 
	imagedestroy($image); 
}

function it618_video_filedown($file_path,$file_name,$file_ext) {
	$tmparr=explode("://",$file_path);
	if(count($tmparr)>1){
		$info = get_headers($file_path, true);
		$file_size = $info['Content-Length'];
		readfile($file_path);
	}else{
		$file_path = iconv('utf-8', 'gb2312', $file_path);
		if (!file_exists($file_path)) {
		  echo 'err';exit;
		}
		$file_size = filesize($file_path);
		$fp = fopen($file_path, 'r');
		$buffer = 1024;
		$file_count = 0;
		while (!feof($fp) && ($file_size-$file_count>0)) {
		  $file_data = fread($fp, $buffer);
		  $file_count += $buffer;
		  echo $file_data;
		}
		fclose($fp);
	}
	
	if($file_ext=='gif'||$file_ext=='jpg'||$file_ext=='jpeg'||$file_ext=='png'){
		header("Content-type: image/$file_ext");
	}else{
		header("Content-type: application/octet-stream");
		header("Accept-Ranges: bytes");
		header("Accept-Length: {$file_size}");
		header("Content-Disposition: attachment;filename={$file_name}");
	}
	
	if(count($tmparr)>1){
		readfile($file_path);
	}else{
		$fp = fopen($file_path, 'r');
		$buffer = 1024;
		$file_count = 0;
		while (!feof($fp) && ($file_size-$file_count>0)) {
		  $file_data = fread($fp, $buffer);
		  $file_count += $buffer;
		  echo $file_data;
		}
		fclose($fp);
	}
}

function video_is_mobile(){ 
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}
?>