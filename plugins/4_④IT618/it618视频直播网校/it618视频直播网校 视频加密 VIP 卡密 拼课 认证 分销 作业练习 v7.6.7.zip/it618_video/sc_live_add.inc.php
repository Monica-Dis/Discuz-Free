<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$lid=intval($_GET['lid']);
$livesetid=intval($_GET['livesetid']);

if($lid>0){
	if($it618_video_goods_lesson=C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid)){
		if($it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_lesson['it618_pid'])){
			if($it618_video_goods['it618_shopid']==$ShopId)$flag=1;
		}
	}
	
	if($flag!=1){
		it618_cpmsg($it618_video_lang['s1298'], "plugin.php?id=it618_video:sc_liveset$adminsid", 'error');
	}
	
	if($livesetid>0){
		if(C::t('#it618_video#it618_video_shopliveset')->count_ok_by_shopid_livesetid($ShopId,$livesetid)==0){
			it618_cpmsg($it618_video_lang['s1297'], "plugin.php?id=it618_video:sc_liveset$adminsid", 'error');
		}else{
			$it618_video_liveset=C::t('#it618_video#it618_video_liveset')->fetch_by_id($livesetid);
			if($it618_video_liveset['it618_ossbucket']!=''&&$it618_video_liveset['it618_ossendpoint']!=''){
				$livesetstr='<font color=#f60>'.$it618_video_lang['s1302'].$it618_video_liveset['it618_livetime'].$it618_video_lang['s1305'].'</font> <font color=green>'.$it618_video_lang['s1272'].'</font>';
			}else{
				$livesetstr='<font color=#f60>'.$it618_video_lang['s1302'].$it618_video_liveset['it618_livetime'].$it618_video_lang['s1305'].'</font> <font color=blue>'.$it618_video_lang['s1273'].'</font>';
				$savetypestr='<tr><td>'.it618_video_getlang('s1610').'</td><td><select name="it618_savetype"><option value=1>'.$it618_video_lang['s1611'].'</option><option value=2 selected="selected">'.$it618_video_lang['s1612'].'</option><option value=3>'.$it618_video_lang['s1613'].'</option></select> '.$it618_video_lang['s1614'].'</td></tr>';
			}
			
			$it618_sqtime=$it618_video_liveset['it618_sqtime'];
			$livesetstr='<b>'.$it618_video_liveset['it618_name'].'</b><br><br>'.$livesetstr;
		}
	}else{
		$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($ShopId);

		if($it618_video_shop['it618_livetime']==0){
			it618_cpmsg($it618_video_lang['s1295'], "plugin.php?id=it618_video:sc_liveset$adminsid", 'error');
		}
		
		$it618_sqtime=3;
		$livesetstr='<b>'.$it618_video_lang['s1494'].'</b><br><br>'.$it618_video_lang['s1495'].'<br><br><font color=#f60>'.$it618_video_lang['s1496'].$it618_video_shop['it618_livetime'].$it618_video_lang['s1485'].'</font> <font color=blue>'.$it618_video_lang['s1273'].'</font>';
		
		$liveset0='
		<tr><td>'.it618_video_getlang('s1497').'</td><td><input type="text" class="txt" style="width:130px;margin-right:3px" id="it618_livetime" name="it618_livetime" value="'.$it618_livetime.'">'.$it618_video_lang['s1305'].'</td></tr>
		<tr><td>'.it618_video_getlang('s1498').'</td><td><textarea name="it618_m3u8url" style="width:776px;height:60px;margin-bottom:3px">'.$it618_m3u8url.'</textarea><br>'.$it618_video_lang['s1499'].'</td></tr>';
		
		$savetypestr='<tr><td>'.it618_video_getlang('s1610').'</td><td><select name="it618_savetype"><option value=1>'.$it618_video_lang['s1611'].'</option><option value=2 selected="selected">'.$it618_video_lang['s1612'].'</option><option value=3>'.$it618_video_lang['s1613'].'</option></select> '.$it618_video_lang['s1614'].'</td></tr>';
	}
}else{
	it618_cpmsg($it618_video_lang['s1697'], "plugin.php?id=it618_video:sc_liveset$adminsid", 'error');
}

if(submitcheck('it618submit')){
	dsetcookie('it618_name',$_GET['it618_name'],300);
	dsetcookie('it618_description',$_GET['it618_description'],300);
	dsetcookie('it618_livetime',$_GET['it618_livetime'],300);
	dsetcookie('it618_m3u8url',$_GET['it618_m3u8url'],300);
	
	if($livesetid==0){
		if($_GET['it618_livetime']>$it618_video_shop['it618_livetime']){
			it618_cpmsg($it618_video_lang['s1500'], "plugin.php?id=it618_video:sc_live_add$adminsid&lid=".$lid, 'error');
		}
	}
	
	$timetmp1=explode(" ",$_GET['it618_btime']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	
	$btime=mktime($timetmp12[0], $timetmp12[1], $timetmp12[2], $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	if($btime<$_G['timestamp']+$it618_sqtime*60){
		$it618_video_lang['s1308']=str_replace("{sqtime}",'<font color=blue>'.$it618_sqtime.$it618_video_lang['s1305'].'</font>',$it618_video_lang['s1308']);
		it618_cpmsg($it618_video_lang['s1308'], "plugin.php?id=it618_video:sc_live_add$adminsid&lid=".$lid."&livesetid=".$livesetid, 'error');
	}
	
	if($livesetid>0){
		$it618_livetime=$it618_video_liveset['it618_livetime'];
	}else{
		$it618_livetime=$_GET['it618_livetime'];
	}
	
	$id=C::t('#it618_video#it618_video_live')->insert(array(
		'it618_shopid' => $ShopId,
		'it618_liveset_id' => $livesetid,
		'it618_pid' => $it618_video_goods['id'],
		'it618_lid' => $it618_video_goods_lesson['id'],
		'it618_name' => $_GET['it618_name'],
		'it618_btime' => $btime,
		'it618_etime' => $btime+$it618_livetime*60,
		'it618_livetime' => $it618_livetime,
		'it618_iseditetime' => $it618_video_liveset['it618_iseditetime'],
		'it618_savetype' => $_GET['it618_savetype'],
		'it618_m3u8url' => $_GET['it618_m3u8url'],
		'it618_ossbucket' => $it618_video_liveset['it618_ossbucket'],
		'it618_ossendpoint' => $it618_video_liveset['it618_ossendpoint'],
		'it618_description' => $_GET['it618_description'],
		'it618_chkstate' => 0,
		'it618_isuser' => $_GET['it618_isuser'],
		'it618_usercode' => trim($_GET['it618_usercode']),
		'it618_time' => $_G['timestamp']
	), true);
	
	if($Shopischeck_live!=1){
		C::t('#it618_video#it618_video_live')->update($id,array(
			'it618_streamname' => md5($it618_video_liveset['it618_accesskey'].$id.FORMHASH)
		));
		
		$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($id);
		
		if($livesetid>0){
			if($it618_video_live['it618_ossbucket']!=''&&$it618_video_live['it618_ossendpoint']!=''){
				$returnstr=it618_video_addliverecordconfig($it618_video_live);
				if($returnstr!=1){
					it618_cpmsg($returnstr, "plugin.php?id=it618_video:sc_live_add$adminsid&lid=".$lid."&livesetid=".$livesetid, 'error');
				}
			}
		}
		
		C::t('#it618_video#it618_video_goods_video')->insert(array(
			'it618_pid' => $it618_video_live['it618_pid'],
			'it618_lid' => $it618_video_live['it618_lid'],
			'it618_liveid' => $it618_video_live['id'],
			'it618_livebtime' => $btime,
			'it618_isuser' => $_GET['it618_isuser'],
			'it618_usercode' => trim($_GET['it618_usercode']),
			'it618_ischat' => 1,
			'it618_islive' => 1
		), true);
		
		C::t('#it618_video#it618_video_live')->update($id,array(
			'it618_chkstate' => 1
		));
	}
	
	dsetcookie('it618_name','');
	dsetcookie('it618_description','');
	dsetcookie('it618_livetime','');
	dsetcookie('it618_m3u8url','');

	it618_cpmsg(it618_video_getlang('s1309'), "plugin.php?id=it618_video:sc_live$adminsid", 'succeed');
}

it618_showformheader("plugin.php?id=it618_video:sc_live_add$adminsid&lid=".$lid."&livesetid=".$livesetid);
showtableheaders(it618_video_getlang('s1279'),'it618_video_live');

$it618_name=getcookie('it618_name');
$it618_description=getcookie('it618_description');
$it618_livetime=getcookie('it618_livetime');
$it618_m3u8url=getcookie('it618_m3u8url');

if($Shopischeck_live==1){
	$check='<font color=blue>'.$it618_video_lang['s1303'].'</font>';
}else{
	$check='<font color=green>'.$it618_video_lang['s1304'].'</font>';
}

$about=str_replace("{sqtime}",'<font color=blue>'.$it618_sqtime.$it618_video_lang['s1305'].'</font>',$it618_video_lang['s1300']);
$about=str_replace("{check}",$check,$about);

echo '
<script charset="utf-8" src="source/plugin/it618_video/js/laydate/laydate.js"></script>
<script>
function checkvalue(){
	if(document.getElementById("it618_name").value==""){
		alert("'.it618_video_getlang('s1306').'");
		document.getElementById("it618_name").focus();
		return false;
	}
	if(document.getElementById("it618_btime").value==""){
		alert("'.it618_video_getlang('s1307').'");
		return false;
	}
}

function setisuser(obj){
	document.getElementById("trusercode").style.display="none"; 
	
	if(obj.value!=1){
		document.getElementById("trusercode").style.display=""; 
	}
}
</script>
<tr><td width=90>'.it618_video_getlang('s1281').'</td><td>
'.$livesetstr.'
</td></tr>
<tr><td>'.$it618_video_lang['s1286'].'</td><td>
'.$it618_video_goods['it618_name'].' - '.$it618_video_goods_lesson['it618_name'].'
</td></tr>
<tr><td>'.it618_video_getlang('s1280').'</td><td><input type="text" class="txt" style="width:776px;margin-right:0" id="it618_name" name="it618_name" value="'.$it618_name.'"></td></tr>
<tr><td>'.it618_video_getlang('s1282').'</td><td><input type="text" class="txt" style="width:150px;margin-right:3px" id="it618_btime" name="it618_btime" readonly="readonly" 
> '.$it618_video_lang['s1283'].'</td></tr>
'.$liveset0.'
<tr><td>'.it618_video_getlang('s1287').'</td><td><select name="it618_isuser" onchange="setisuser(this)"><option value=1>'.$it618_video_lang['s27'].'</option><option value=2>'.$it618_video_lang['s28'].'</option><option value=0>'.$it618_video_lang['s30'].'</option></select> '.$it618_video_lang['s1284'].'</td></tr>
<tr id="trusercode" style="display:none"><td>'.it618_video_getlang('s1981').'</td><td><input type="text" class="txt" style="width:130px;margin-right:0" name="it618_usercode"> '.$it618_video_lang['s1982'].'</td></tr>
'.$savetypestr.'
<tr><td>'.it618_video_getlang('s1285').'</td><td><textarea name="it618_description" style="width:776px;height:60px;">'.$it618_description.'</textarea></td></tr>
<tr><td colspan=2 style="color:red">'.$about.'</td></tr>
<tr><td colspan=2><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.it618_video_getlang('s1299').'" /></td></tr>
<style>.laydate-btns-time{float:left}</style>
<script>
laydate.render({
  elem: "#it618_btime"
  ,type: "datetime"
});
</script>
';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>