<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$pid=intval($_GET['pid']);

$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);

if(submitcheck('it618submit')){
	if($it618_video_goods['it618_issecret']==1){
		$tmparr=explode(",",$_GET['it618_secretusers']);
		for($i=0;$i<count($tmparr);$i++){
			$count=C::t('#it618_video#it618_video_sale')->count_by_uid($tmparr[$i]);
			if($count>0){
				$tmpstr.=$tmparr[$i].',';
			}
		}
		if($tmpstr!='')$tmpstr.='@';
		$tmpstr=str_replace(',@','',$tmpstr);
	
		C::t('#it618_video#it618_video_goods')->update($pid,array(
			'it618_secretusers' => $tmpstr
		));
	}

	echo '<script>parent.location.reload();parent.layer.closeAll();</script>';
}

it618_showformheader("plugin.php?id=it618_video:sc_product_secret$adminsid&pid=$pid");
showtableheaders($it618_video_goods['it618_name'],'sc_product_secret');

if($it618_video_goods['it618_issecret']==1){
	$secretusersstr='';
	$tmparr=explode(",",$it618_video_goods['it618_secretusers']);
	for($i=0;$i<count($tmparr);$i++){
		$username=C::t('#it618_video#it618_video_sale')->fetch_username_by_uid($tmparr[$i]);
		$secretusersstr.=$username.' , ';
	}
	if($secretusersstr!='')$secretusersstr.='@';
	$secretusersstr=str_replace(' , @','',$secretusersstr);
	if($secretusersstr!=''){
		$secretusersstr='<tr><td></td><td style="color:green">'.$secretusersstr.'</td></tr>';	
	}
	
	$it618_issecret='<tr><td width=80>'.it618_video_getlang('s1178').'</td><td><textarea name="it618_secretusers" style="width:776px;height:190px;margin-bottom:3px">'.$it618_video_goods['it618_secretusers'].'</textarea><br><font color=red>'.it618_video_getlang('s1179').'</font></td></tr>
	'.$secretusersstr.'
	';
}

echo $it618_issecret;

echo '<tr><td colspan=10><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_video_getlang('s1970').'" /></div></td></tr>';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>