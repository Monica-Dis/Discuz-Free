<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$ppp = 9;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$tmpidarr=explode(":",$_GET['id']);
$tempabc=$tmpidarr[0];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

if($it618_video_shop['it618_issalekm']==1){
	$IsSaleKm=1;
}else{
	$shopadmin=explode(",",$it618_video['video_shopadmin']);
	if(in_array($_G['uid'],$shopadmin)){
		$IsSaleKm=1;
		$it618_isadmin=1;
	}
}

if($IsSaleKm!=1){
	echo $it618_video_lang['s513'];exit;
}

$typeid=intval($_GET['typeid']);
$it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($typeid);
		
$tmptitle=it618_video_getgoodstypename($it618_video_goods_type);

if(submitcheck('it618submit')){
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_video_goods_km', "id=$delid");
		$del=$del+1;
	}

	it618_cpmsg($it618_video_lang['s2031'].$del, "plugin.php?id=it618_video:sc_product_type_km&typeid=$typeid$adminsid&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_clear')){
	DB::query("delete from ".DB::table('it618_video_goods_km'));
	
	it618_cpmsg($it618_video_lang['s2032'], "plugin.php?id=it618_video:sc_product_type_km&typeid=$typeid$adminsid&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_deltime')){
	DB::query("delete FROM ".DB::table('it618_video_goods_km')." WHERE it618_etime<>0 and it618_etime<".$_G['timestamp']);
	
	it618_cpmsg($it618_video_lang['s2032'], "plugin.php?id=it618_video:sc_product_type_km&typeid=$typeid$adminsid&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submitadd')) {
	$it618_count=intval($_GET['it618_count']);
	$shopadmin=explode(",",$it618_video['video_shopadmin']);

	if($it618_count>99&&!in_array($_G['uid'],$shopadmin)){
		it618_cpmsg($it618_video_lang['s2315'], "plugin.php?id=it618_video:sc_product_type_km&typeid=$typeid$adminsid&page=$page".$urlsql, 'error');
	}
	
	if($_GET['chketime']==1){
		$it618_etime=explode(" ",$_GET['it618_etime']);
		$it618_date=explode("-",$it618_etime[0]);
		$it618_hour=explode(":",$it618_etime[1]);
		
		$it618_etime=mktime($it618_hour[0], $it618_hour[1], $it618_hour[2], $it618_date[1], $it618_date[2], $it618_date[0]);
	}else{
		$it618_etime=0;
	}
	$ok=0;
	$it618_addtime=$_G['timestamp'];
	for($i=0;$i<$it618_count;$i++){
		$id=C::t('#it618_video#it618_video_goods_km')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_isadmin' => $it618_isadmin,
			'it618_typeid' => $typeid,
			'it618_bz' => $_GET['it618_bz'],
			'it618_usedel' => $_GET['it618_usedel'],
			'it618_xgtime' => $_GET['it618_xgtime'],
			'it618_etime' => $it618_etime,
			'it618_addtime' => $it618_addtime
		), true);
		setcode($id);
		$ok=$ok+1;
	}
	it618_cpmsg($it618_video_lang['s2033'].$ok,"plugin.php?id=it618_video:sc_product_type_km&typeid=$typeid$adminsid&page=$page".$urlsql, 'succeed');
}

function setcode($kmid){
	global $it618_video;
	$video_kmstrlen=$it618_video['video_kmstrlen'];
	if($video_kmstrlen<6)$video_kmstrlen=6;
	
	$n=0;
	while($n<$video_kmstrlen){
		if($it618_video['video_kmtype']==1){
			if($n==0){
				$tmpstr.=rand(1,9);
			}else{
				$tmpstr.=rand(0,9);
			}
		}else{
			$tmpstr.=getrandstr($it618_video['video_kmtype']);
		}
		
		$n=$n+1;
	}
	
	C::t('#it618_video#it618_video_goods_km')->update_it618_code($kmid,$kmid.$tmpstr);
}

function getrandstr($type){
	if($type==2)$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	if($type==3)$chars = 'abcdefghijklmnopqrstuvwxyz';
	if($type==4)$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
	if($type==5)$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
	if($type==6)$chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
	
	return substr($chars,mt_rand(0,strlen($chars)-1),1);
}

$urlsql='&it618_bz='.$_GET['it618_bz'];


//
$strtmp="";
for($i=2018;$i<=2028;$i++){
	if(date('Y')==$i){
		$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
}
$sel_year='<select id="sel_year" onclick="returnvalue()">'.$strtmp.'</select>';

//
$strtmp="";
for($i=1;$i<=12;$i++){
	if(date('n')==$i){
		$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
}
$sel_month='<select id="sel_month" onclick="returnvalue()">'.$strtmp.'</select>';

//
$strtmp="";
for($i=1;$i<=31;$i++){
	if(date('j')==$i){
		$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
}
$sel_date='<select id="sel_date" onclick="returnvalue()">'.$strtmp.'</select>';

//
$strtmp="";
for($i=0;$i<=23;$i++){
	if(0==$i){
		$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
}
$sel_hour='<select id="sel_hour" onclick="returnvalue()">'.$strtmp.'</select>';

//
$strtmp="";
for($i=0;$i<=59;$i++){
	if(0==$i){
		$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
}
$sel_minute='<select id="sel_minute" onclick="returnvalue()">'.$strtmp.'</select>';

//
$strtmp="";
for($i=0;$i<=59;$i++){
	if(0==$i){
		$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
}
$sel_second='<select id="sel_second" onclick="returnvalue()">'.$strtmp.'</select>';

function towstr($i){
	if(strlen($i)==1)return "0".$i;else return $i;
}

$tmpnow=date('Y-m-d H:i:s', $_G['timestamp']);

it618_showformheader("plugin.php?id=it618_video:sc_product_type_km&typeid=$typeid$adminsid&page=$page".$urlsql);
showtableheaders('','it618_video_goods_km');
	echo '<tr></tr><tr><td colspan="15"><b>'.$tmptitle.'</b></td></tr>';
	echo '<tr></tr><tr><td colspan="15"><div class="fixsel" style="line-height:50px">'.$it618_video_lang['s2035'].'<input id="it618_count" name="it618_count" value="" class="txt" style="width:40px" /> '.$it618_video_lang['s2083'].'<input id="it618_xgtime" name="it618_xgtime" value="0" class="txt" style="width:40px;margin-right:3px" />'.$it618_video_lang['s2123'].' '.$it618_video_lang['s2038'].'<input type="checkbox" id="chketime" name="chketime" style="vertical-align:middle" onclick="setetime(this)" value="1"/><input type="hidden" id="it618_etime" name="it618_etime"><span id="etime" style="display:none">'.$sel_year.$sel_month.$sel_date.$sel_hour.$sel_minute.$sel_second.'</span><input type="hidden" id="tmpnow" value="'.$tmpnow.'"> '.$it618_video_lang['s2039'].'<input id="it618_bz" name="it618_bz" value="" class="txt" style="width:230px" /> '.$it618_video_lang['s2308'].'<select name="it618_usedel"><option value="1">'.$it618_video_lang['s2310'].'</option><option value="0">'.$it618_video_lang['s2311'].'</option></select><input type="submit" class="btn" style="margin-left:6px" name="it618submitadd" value="'.$it618_video_lang['s2040'].'" onclick="return checkvalue()" /></div></td></tr>';

$it618_bzfind='<option value="">'.$it618_video_lang['s2043'].'</option>';
$query = DB::query("SELECT count(1) as quancount,it618_bz FROM ".DB::table('it618_video_goods_km')." WHERE it618_typeid=$typeid group by it618_bz");
while($it618_video_goods_km = DB::fetch($query)) {
	$it618_bzfind.='<option value='.$it618_video_goods_km['it618_bz'].'>'.$it618_video_goods_km['it618_bz'].' ('.$it618_video_lang['s2062'].$it618_video_goods_km['quancount'].')</option>';
}
$it618_bzfind=str_replace('<option value='.$_GET['it618_bzfind'].'>','<option value='.$_GET['it618_bzfind'].' selected="selected">',$it618_bzfind);

echo '<tr><td colspan="15"><div class="fixsel">'.$it618_video_lang['s2045'].' <select id="it618_bzfind" name="it618_bzfind">'.$it618_bzfind.'</select> &nbsp;<input type="submit" class="btn" name="it618submitfind" value="'.$it618_video_lang['s2044'].'" /> <input type="button" class="btn" value="'.it618_video_getlang('s2057').'" onclick="dao()" /></div></td></tr>';

	$count = C::t('#it618_video#it618_video_goods_km')->count_by_search($it618sql,'',$typeid,$_GET['it618_bzfind']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_video:sc_product_type_km&typeid=$typeid".$urlsql);
	
	echo '<tr><td colspan=7>'.$it618_video_lang['s2046'].$count.'<span style="float:right;color:red">'.$it618_video_lang['s2289'].'</span></td></tr>';
	showsubtitle(array('', $it618_video_lang['s2047'], $it618_video_lang['s2084'],$it618_video_lang['s2049'],$it618_video_lang['s2309'],$it618_video_lang['s2050'],$it618_video_lang['s2051']));
	
	foreach(C::t('#it618_video#it618_video_goods_km')->fetch_all_by_search(
		$it618sql,'id desc',$typeid,$_GET['it618_bzfind'],$startlimit,$ppp
	) as $it618_video_goods_km) {
		if($it618_video_goods_km['it618_etime']==0){
			$it618_etime=$it618_video_lang['s2052'];
		}else{
			$it618_etime=date('Y-m-d H:i:s', $it618_video_goods_km['it618_etime']);
		}
		
		if($it618_video_goods_km['it618_xgtime']>0){
			$it618_xgtime='<font color=red>'.$it618_video_goods_km['it618_xgtime'].'</font>'.$it618_video_lang['s2085'];
		}else{
			$it618_xgtime=$it618_video_lang['s2086'];
		}
		
		if($it618_video_goods_km['it618_usedel']==1){
			$it618_usedel=$it618_video_lang['s2310'];
		}else{
			$it618_usedel=$it618_video_lang['s2311'];
		}
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"".$it618_video_goods_km['id']."\" $disabled>",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_code[".$it618_video_goods_km['id']."]\" value=\"".$it618_video_goods_km['it618_code']."\" onclick=\"this.select()\">",
			$it618_xgtime,
			$it618_etime,
			$it618_usedel,
			$it618_video_goods_km['it618_bz'],
			date('Y-m-d H:i:s', $it618_video_goods_km['it618_addtime'])
		));

	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_video_lang['s2053'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.$it618_video_lang['s2054'].'"/> <input type="submit" class="btn" name="it618submit_deltime" value="'.$it618_video_lang['s2081'].'" onclick="return confirm(\''.$it618_video_lang['s2082'].'\')"/> <input type="submit" class="btn" name="it618submit_clear" value="'.$it618_video_lang['s2055'].'" onclick="return confirm(\''.$it618_video_lang['s2056'].'\')"/> <input type=hidden value='.$page.' name=page /></div></td></tr>';

echo '<script>
function returnvalue(){
document.getElementById("it618_etime").value=document.getElementById("sel_year").value+"-"+document.getElementById("sel_month").value+"-"+document.getElementById("sel_date").value+" "+document.getElementById("sel_hour").value+":"+document.getElementById("sel_minute").value+":"+document.getElementById("sel_second").value;
}

function setetime(chkobj){
	if(chkobj.checked==true){
		document.getElementById("etime").style.display="";
		returnvalue();
	}else{
		document.getElementById("etime").style.display="none";
	}
}

function checkvalue(){
	if(document.getElementById("it618_count").value<=0){
		alert("'.$it618_video_lang['s2058'].'");
		return false;
	}
	
	if(document.getElementById("chketime").checked==true){
		
		var sel_year=document.getElementById("sel_year").value;
		var sel_month=document.getElementById("sel_month").value;
		var sel_date=document.getElementById("sel_date").value;
		var sel_hour=document.getElementById("sel_hour").value;
		var sel_minute=document.getElementById("sel_minute").value;
		var sel_second=document.getElementById("sel_second").value;

		var dateValue = parseInt(sel_year+sel_month+sel_date+sel_hour+sel_minute+sel_second);
		var datNow = parseInt(document.getElementById("tmpnow").value.replace(/-/g,"").replace(/:/g,"").replace(" ",""));

		if(dateValue < datNow) {
			alert("'.$it618_video_lang['s2060'].'");
			return false;
		}
	}
	
	if(document.getElementById("it618_bz").value==""){
		alert("'.$it618_video_lang['s2061'].'");
		return false;
	}
}

function dao(){
	var it618_bzfind = document.getElementById("it618_bzfind").value;
	sqlurl="&it618_bzfind="+it618_bzfind;
	var url="'.$_G['siteurl'].'plugin.php?id=it618_video:ajax";
	
	IT618_VIDEO.get(url+sqlurl+"&typeid='.$typeid.''.$adminsid.'&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"km_dao"},function (data, textStatus){
	window.open(data);
	}, "html");	
}
</script>';
	if(count($reabc)!=11)return;
    showtablefooter(); /*dis'.'m.tao'.'bao.com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>