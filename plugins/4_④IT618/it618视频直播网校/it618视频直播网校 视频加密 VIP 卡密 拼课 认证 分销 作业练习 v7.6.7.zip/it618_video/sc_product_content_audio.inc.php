<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$ppp = 20;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$vid=intval($_GET['vid']);
$preurl=$_GET['preurl'];

$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($vid);
$it618_video_goods_lesson=C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($it618_video_goods_video['it618_lid']);
$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_video['it618_pid']);

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($it618_video_shop['it618_isdel']==1){
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			DB::delete('it618_video_goods_video_audio', "id=$delid");
			$del=$del+1;
		}
	}else{
		$del=$it618_video_lang['s1604'];
	}
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			$it618_videotime1=intval($_GET['it618_videotime1'][$id]);
			$it618_videotime2=intval($_GET['it618_videotime2'][$id]);
			$it618_videotime3=intval($_GET['it618_videotime3'][$id]);
			
			$it618_videotime=$it618_videotime1*3600+$it618_videotime2*60+$it618_videotime3;
			
			$it618_videourl= trim($_GET['it618_videourl'][$id]);
			
			if($it618_video_media_audio=C::t('#it618_video#it618_video_media_audio')->fetch_by_url($it618_videourl)){
				if($it618_video_media_audio['it618_shopid']!=$ShopId){
					$it618_videourl='';
				}
			}

			C::t('#it618_video#it618_video_goods_video_audio')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_videourl' => $it618_videourl,
				'it618_videotime' => $it618_videotime,
				'it618_videotime1' => $it618_videotime1,
				'it618_videotime2' => $it618_videotime2,
				'it618_videotime3' => $it618_videotime3,
				'it618_order' => trim($_GET['it618_order'][$id])
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_videourl_array = !empty($_GET['newit618_videourl']) ? $_GET['newit618_videourl'] : array();
	$newit618_videotime1_array = !empty($_GET['newit618_videotime1']) ? $_GET['newit618_videotime1'] : array();
	$newit618_videotime2_array = !empty($_GET['newit618_videotime2']) ? $_GET['newit618_videotime2'] : array();
	$newit618_videotime3_array = !empty($_GET['newit618_videotime3']) ? $_GET['newit618_videotime3'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		
		if(trim($newit618_name_array[$key]) != '') {
			
			$it618_videotime1=intval($newit618_videotime1_array[$key]);
			$it618_videotime2=intval($newit618_videotime2_array[$key]);
			$it618_videotime3=intval($newit618_videotime3_array[$key]);
			
			$it618_videotime=$it618_videotime1*3600+$it618_videotime2*60+$it618_videotime3;
			
			$it618_videourl= trim($newit618_videourl_array[$key]);
			
			if($it618_video_media_audio=C::t('#it618_video#it618_video_media_audio')->fetch_by_url($it618_videourl)){
				if($it618_video_media_audio['it618_shopid']!=$ShopId){
					$it618_videourl='';
				}
			}
			                                        
			C::t('#it618_video#it618_video_goods_video_audio')->insert(array(
				'it618_pid' => $it618_video_goods_lesson['it618_pid'],
				'it618_vid' => $vid,
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_videourl' => $it618_videourl,
				'it618_videotime' => $it618_videotime,
				'it618_videotime1' => $it618_videotime1,
				'it618_videotime2' => $it618_videotime2,
				'it618_videotime3' => $it618_videotime3,
				'it618_order' => trim($newit618_order_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}

	$it618_video_goods_video_audiotmp=C::t('#it618_video#it618_video_goods_video_audio')->fetch_count_time_by_vid($vid);
	$tmparr=it618_video_getvideotimearr($it618_video_goods_video_audiotmp['videotime']);
	C::t('#it618_video#it618_video_goods_video')->update($vid,array(
		'it618_videotime' => $it618_video_goods_video_audiotmp['videotime'],
		'it618_videotime1' => $tmparr[0],
		'it618_videotime2' => $tmparr[1],
		'it618_videotime3' => $tmparr[2],
	));
	
	$it618_video_goods_videotmp=C::t('#it618_video#it618_video_goods_video')->fetch_count_time_by_pid($it618_video_goods_video['it618_pid']);
	C::t('#it618_video#it618_video_goods')->update($it618_video_goods_video['it618_pid'],array(
		'it618_videocount' => $it618_video_goods_videotmp['videocount'],
		'it618_videotime' => $it618_video_goods_videotmp['videotime']
	));
	
	$it618_video_goods_videotmp=C::t('#it618_video#it618_video_goods_video')->fetch_count_time_by_lid($it618_video_goods_video['it618_lid']);
	C::t('#it618_video#it618_video_goods_lesson')->update($it618_video_goods_video['it618_lid'],array(
		'it618_videocount' => $it618_video_goods_videotmp['videocount'],
		'it618_videotime' => $it618_video_goods_videotmp['videotime']
	));

	it618_cpmsg($it618_video_lang['s33'].$ok1.' '.$it618_video_lang['s34'].$ok2.' '.$it618_video_lang['s35'].$del.')', "plugin.php?id=it618_video:sc_product_content_audio$adminsid&vid=$vid&preurl=$preurl", 'succeed');
}

it618_showformheader("plugin.php?id=it618_video:sc_product_content_audio$adminsid&vid=$vid&preurl=$preurl");
showtableheaders('<a href="plugin.php?id=it618_video:sc_product_content'.$adminsid.'&lid='.$it618_video_goods_video['it618_lid'].'&preurl='.$preurl.'">'.$it618_video_lang['s521'].'<font color=red>'.$it618_video_lang['s514'].$it618_video_goods['it618_name'].' - '.$it618_video_goods_lesson['it618_name'].' - '.$it618_video_goods_video['it618_name'].$it618_video_lang['s515'].'</font></a> '.$it618_video_lang['s538'],'sc_product_content_audio');

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_video_audio')." WHERE it618_vid=".$vid);

echo '<tr><td colspan=15>'.$it618_video_lang['s242'].$count.'<span style="float:right;color:red">'.it618_video_getlang('s417').'</span></td></tr>';

showsubtitle(array($it618_video_lang['s56'], it618_video_getlang('s237'),it618_video_getlang('s238'), $it618_video_lang['s385']));

$n=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_video_audio')." WHERE it618_vid=".$vid." ORDER BY it618_order");
while($it618_video_goods_video_audio = DB::fetch($query)) {
	
	showtablerow('', array('class="td25"', '', '', '', '', ''), array(
		'<input class="checkbox" type="checkbox" id="chk_del'.$it618_video_goods_video_audio['id'].'" name="delete[]" value="'.$it618_video_goods_video_audio['id'].'" '.$disabled.'><label for="chk_del'.$it618_video_goods_video_audio['id'].'">'.$it618_video_goods_video_audio['id'].'</label>',
		'<div style="width:480px"><input type="text" class="txt" style="width:480px;margin-bottom:6px" id="name'.$it618_video_goods_video_audio['id'].'" name="it618_name['.$it618_video_goods_video_audio['id'].']" value="'.$it618_video_goods_video_audio['it618_name'].'"><br>'.$it618_video_lang['s399'].'<input id="time1'.$it618_video_goods_video_audio['id'].'" type="text" class="txt" style="width:23px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" name="it618_videotime1['.$it618_video_goods_video_audio['id'].']" value="'.$it618_video_goods_video_audio['it618_videotime1'].'">'.$it618_video_lang['s397'].'
		<input id="time2'.$it618_video_goods_video_audio['id'].'" type="text" class="txt" style="width:23px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" name="it618_videotime2['.$it618_video_goods_video_audio['id'].']" value="'.$it618_video_goods_video_audio['it618_videotime2'].'">'.$it618_video_lang['s398'].'
		<input id="time3'.$it618_video_goods_video_audio['id'].'" type="text" class="txt" style="width:23px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" name="it618_videotime3['.$it618_video_goods_video_audio['id'].']" value="'.$it618_video_goods_video_audio['it618_videotime3'].'">'.$it618_video_lang['s400'].'<span style="float:right;"><a href="javascript:" onclick="media_select('.$it618_video_goods_video_audio['id'].')">'.it618_video_getlang('s1787').'</a></span></div>',
		'<textarea id="videourl'.$it618_video_goods_video_audio['id'].'" name="it618_videourl['.$it618_video_goods_video_audio['id'].']" style="width:430px;height:46px">'.$it618_video_goods_video_audio['it618_videourl'].'</textarea>',
		'<input type="text" class="txt" style="width:26px;text-align:center;" name="it618_order['.$it618_video_goods_video_audio['id'].']" value="'.$it618_video_goods_video_audio['it618_order'].'">'
	));
	$n=$n+1;
}
	

	$it618_video_langs399=$it618_video_lang['s399'];
	$it618_video_langs397=$it618_video_lang['s397'];
	$it618_video_langs398=$it618_video_lang['s398'];
	$it618_video_langs400=$it618_video_lang['s400'];
	$it618_video_langs1769=$it618_video_lang['s1787'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<div style="width:480px"><input type="text" class="txt" style="width:480px;margin-bottom:6px" id="name1000'+n+'" name="newit618_name[]"><br>$it618_video_langs399<input type="text" class="txt" style="width:26px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" id="time11000'+n+'" name="newit618_videotime1[]">$it618_video_langs397<input type="text" class="txt" style="width:26px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" id="time21000'+n+'" name="newit618_videotime2[]">$it618_video_langs398<input type="text" class="txt" style="width:26px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" id="time31000'+n+'" name="newit618_videotime3[]">$it618_video_langs400<span style="float:right"><a href="javascript:" onclick="media_select(1000'+n+')">$it618_video_langs1769</a></span></div>'],
		[1,'<textarea id="videourl1000'+n+'" name="newit618_videourl[]" style="width:430px;height:46px"></textarea>'],
		[1,'<input type="text" class="txt" style="width:26px" name="newit618_order[]">']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$it618_video_lang['s831'].'</a></div></td></tr>';
    
    echo '
    <span id="it618_media_select"></span>
	<script>
	var vid,type;
	
	function media_select(id){
		vid=id;type="audio";title="'.$it618_video_lang['s1790'].'";
		document.getElementById("it618_media_select").click();
	}
	
    var dialog_media;
    KindEditor.ready(function(K) {K("#it618_media_select").click(function() {
    
        dialog_media = K.dialog({
            width : 848,
            height: 558,
            title : title,
            body : \'<div><iframe id="ifa_media" src="plugin.php?id=it618_video:sc_media_select'.$adminsid.'&type=\'+type+\'" style="border:0;" frameborder=0 width="848" height="536"></iframe></div>\',
            closeBtn : {
                name : "'.$it618_video_lang['t285'].'",
                click : function(e) {
                    dialog_media.remove();
                }
            }
        });
    
    });});
    </script>';
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_video_getlang('s644').'</label></td><td colspan="15"><input type="submit" class="btn" name="it618submit" value="'.it618_video_getlang('s645').'"/>'.$tmp.'<input type=hidden value='.$page.' name=page /></div><br></td></tr>';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>