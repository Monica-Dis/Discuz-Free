<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$ppp = 50;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$lid=intval($_GET['lid']);
$preurl=$_GET['preurl'];

$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_lesson['it618_pid']);

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($it618_video_shop['it618_isdel']==1){
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			DB::delete('it618_video_goods_video', "id=$delid");
			$del=$del+1;
		}
	}else{
		$del=$it618_video_lang['s1604'];
	}
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			$it618_isuser=trim($_GET['it618_isuser'][$id]);
			
			$it618_saleprice=$_GET['it618_saleprice'][$id];
			
			$it618_score=$_GET['it618_score'][$id];
			if($_GET['it618_jfid'][$id]==0)$it618_score=0;
			
			if($Shopisale!=1){
				$it618_saleprice=1;
			}
			
			C::t('#it618_video#it618_video_goods_video')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_description' => trim($_GET['it618_description'][$id]),
				'it618_issale' => $_GET['it618_issale'][$id],
				'it618_price' => $_GET['it618_price'][$id],
				'it618_saleprice' => $it618_saleprice,
				'it618_jfid' => $_GET['it618_jfid'][$id],
				'it618_score' => $it618_score,
				'it618_ison' => trim($_GET['it618_ison'][$id]),
				'it618_isuser' => trim($_GET['it618_isuser'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id])
			));
			
			if($IsChat==1){
				C::t('#it618_video#it618_video_goods_video')->update($id,array(
					'it618_ischat' => trim($_GET['it618_ischat'][$id])
				));
			}
			
			$ok1=$ok1+1;
		}
	}
	
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_description_array = !empty($_GET['newit618_description']) ? $_GET['newit618_description'] : array();
	$newit618_ischat_array = !empty($_GET['newit618_ischat']) ? $_GET['newit618_ischat'] : array();
	$newit618_isuser_array = !empty($_GET['newit618_isuser']) ? $_GET['newit618_isuser'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		
		if(trim($newit618_name_array[$key]) != '') {
			                                        
			$id=C::t('#it618_video#it618_video_goods_video')->insert(array(
				'it618_pid' => $it618_video_goods_lesson['it618_pid'],
				'it618_lid' => $lid,
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_description' => trim($newit618_description_array[$key]),
				'it618_isuser' => trim($newit618_isuser_array[$key]),
				'it618_order' => trim($newit618_order_array[$key])
			), true);
			
			if($IsChat==1){
				C::t('#it618_video#it618_video_goods_video')->update($id,array(
					'it618_ischat' => trim($newit618_ischat_array[$key])
				));
			}
			
			$ok2=$ok2+1;
		}
	}
	
	$it618_video_goods_videotmp=C::t('#it618_video#it618_video_goods_video')->fetch_count_time_by_pid($it618_video_goods_lesson['it618_pid']);
	C::t('#it618_video#it618_video_goods')->update($it618_video_goods_lesson['it618_pid'],array(
		'it618_videocount' => $it618_video_goods_videotmp['videocount'],
		'it618_videotime' => $it618_video_goods_videotmp['videotime']
	));
	
	$it618_video_goods_videotmp=C::t('#it618_video#it618_video_goods_video')->fetch_count_time_by_lid($it618_video_goods_lesson['id']);
	C::t('#it618_video#it618_video_goods_lesson')->update($it618_video_goods_lesson['id'],array(
		'it618_videocount' => $it618_video_goods_videotmp['videocount'],
		'it618_videotime' => $it618_video_goods_videotmp['videotime']
	));

	it618_cpmsg($it618_video_lang['s33'].$ok1.' '.$it618_video_lang['s34'].$ok2.' '.$it618_video_lang['s35'].$del.')', "plugin.php?id=it618_video:sc_product_content$adminsid&lid=$lid&preurl=$preurl&page=$page&lid=$lid", 'succeed');
}

if(submitcheck('it618submit_move')){
	$ok=0;
	foreach($_GET['delete'] as $key => $id) {
		C::t('#it618_video#it618_video_goods_video')->update($id,array(
			'it618_lid' => $_GET['lessonid']
		));
		$ok=$ok+1;
	}
	
	$it618_video_goods_videotmp=C::t('#it618_video#it618_video_goods_video')->fetch_count_time_by_lid($_GET['lessonid']);
	C::t('#it618_video#it618_video_goods_lesson')->update($_GET['lessonid'],array(
		'it618_videocount' => $it618_video_goods_videotmp['videocount'],
		'it618_videotime' => $it618_video_goods_videotmp['videotime']
	));
	
	$it618_video_goods_videotmp=C::t('#it618_video#it618_video_goods_video')->fetch_count_time_by_lid($lid);
	C::t('#it618_video#it618_video_goods_lesson')->update($lid,array(
		'it618_videocount' => $it618_video_goods_videotmp['videocount'],
		'it618_videotime' => $it618_video_goods_videotmp['videotime']
	));
	
	it618_cpmsg($it618_video_lang['s643'].$ok, "plugin.php?id=it618_video:sc_product_content$adminsid&lid=$lid&preurl=$preurl&page=$page&lid=$lid", 'succeed');
}

it618_showformheader("plugin.php?id=it618_video:sc_product_content$adminsid&lid=$lid&preurl=$preurl&page=$page&lid=$lid");
showtableheaders('<a href="plugin.php?id=it618_video:sc_product_lesson'.$adminsid.'&pid='.$it618_video_goods_lesson['it618_pid'].'&preurl='.$preurl.'">'.$it618_video_lang['s506'].'<font color=red>'.$it618_video_lang['s514'].$it618_video_goods['it618_name'].' - '.$it618_video_goods_lesson['it618_name'].$it618_video_lang['s515'].'</font></a> '.$it618_video_lang['s537'],'sc_product_content');

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_video')." WHERE it618_lid=".$lid);
$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_video:sc_product_content&page=$page&lid=$lid");

echo '
<style>
.sc_product_content tr td{vertical-align:top}
</style>
<tr><td colspan=15>'.$it618_video_lang['s368'].$count.'<span style="float:right;color:red">'.it618_video_getlang('s412').'</span></td></tr>';

showsubtitle(array($it618_video_lang['s56'], it618_video_getlang('s382'),$it618_video_lang['s464'],$it618_video_lang['s384'], $it618_video_lang['s385']));

$it618_exam = $_G['cache']['plugin']['it618_exam'];

$n=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_video')." WHERE it618_lid=".$lid." ORDER BY it618_order limit $startlimit,$ppp");
while($it618_video_goods_video = DB::fetch($query)) {
	
	if($it618_video_goods_video['it618_ischat']==1){$it618_ischat_checked='checked="checked"';}else $it618_ischat_checked="";
	
	if($it618_video_goods_video['it618_isuser']==0){$it618_isuser_selected0='selected="selected"';$isusercolor='#390';}else $it618_isuser_selected0="";
	if($it618_video_goods_video['it618_isuser']==1){$it618_isuser_selected1='selected="selected"';$isusercolor='#f30';}else $it618_isuser_selected1="";
	if($it618_video_goods_video['it618_isuser']==2){$it618_isuser_selected2='selected="selected"';$isusercolor='#22b1fe';}else $it618_isuser_selected2="";
	
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_video_audio')." WHERE it618_vid=".$it618_video_goods_video['id']);
	$it618_videotimestr='<font color=red>'.$count.'</font>'.$it618_video_lang['s539'].' '.it618_video_getvideotime($it618_video_goods_video['it618_videotime']);
	
	if($Shopisale==1){
		$salecount = $it618_video_goods_video['it618_salecount'];
		$salemoney = $it618_video_goods_video['it618_salemoney'];
		
		$typecountall = C::t('#it618_video#it618_video_goods_type')->counttype_by_pid_lid_vid($it618_video_goods_video['it618_pid'],$it618_video_goods_video['it618_lid'],$it618_video_goods_video['id']);
		$typecountok = C::t('#it618_video#it618_video_goods_type')->counttype_by_pid_lid_vid_ok($it618_video_goods_video['it618_pid'],$it618_video_goods_video['it618_lid'],$it618_video_goods_video['id']);
		$goodstypestr='<a href="javascript:" onclick="showgoodstype('.$it618_video_goods_video['it618_pid'].','.$it618_video_goods_video['it618_lid'].','.$it618_video_goods_video['id'].')"><img src="source/plugin/it618_video/images/price.png" style="vertical-align:middle;height:13px;margin-top:-1px;margin-right:3px">'.$it618_video_lang['s710'].'</font></a> <font color=#888>('.$typecountok.'/'.$typecountall.')</font><span style="float:right;color:#999">'.it618_video_getlang('s119').''.$salecount.' '.it618_video_getlang('s120').''.$salemoney.'</span>';
		
		$goodstypecss='';
		if($typecountok>0){
			$goodstypecss='display:none';
		}
	}else{
		$goodstypecss='display:none';
		$salecss='display:none';
	}
	
	if($it618_video_goods_video['it618_issale']==1){
		$it618_issale_checked='checked="checked"';
		$issalecss='';
	}else{
		$it618_issale_checked="";
		$issalecss='display:none';
	}
	
	if($IsChat==1){
		if($it618_video_goods_video['it618_ischat']==0){$it618_ischat_selected0='selected="selected"';}else $it618_ischat_selected0="";
		if($it618_video_goods_video['it618_ischat']==1){$it618_ischat_selected1='selected="selected"';}else $it618_ischat_selected1="";
		if($it618_video_goods_video['it618_ischat']==2){$it618_ischat_selected2='selected="selected"';}else $it618_ischat_selected2="";
		if($it618_video_goods_video['it618_ischat']==3){$it618_ischat_selected3='selected="selected"';}else $it618_ischat_selected3="";
		
		$chatstr='<br><select name="it618_ischat['.$it618_video_goods_video['id'].']" style="margin-top:3px"><option value=3 '.$it618_ischat_selected3.'>'.$it618_video_lang['s1018'].'</option><option value=2 '.$it618_ischat_selected2.'>'.$it618_video_lang['s1019'].'</option><option value=1 '.$it618_ischat_selected1.'>'.$it618_video_lang['s1020'].'</option><option value=0 '.$it618_ischat_selected0.'>'.$it618_video_lang['s1021'].'</option></select>';
	}
	
	if($it618_video_goods_video['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
		
	if($typecountall>0||$salecount>0){
		$disabled="disabled=\"disabled\"";
	}
	
	if($it618_exam['seotitle']!=''){
		$examcount=C::t('#it618_video#it618_video_goods_video_exam')->count_by_vid($it618_video_goods_video['id']);
		$tmpexam='<a href="javascript:" onclick="addexams('.$it618_video_goods_video['id'].',\''.$it618_video_goods['it618_name'].' -> '.it618_video_getsmsstr($it618_video_goods_video['it618_name'],60).'\')"><img src="source/plugin/it618_video/images/addpaper.png" style="vertical-align:middle;height:15px;margin-top:-1px;margin-right:3px">'.$it618_video_lang['s1426'].'</a> <a href="javascript:" onclick="editexams('.$it618_video_goods_video['id'].',\''.$it618_video_goods['it618_name'].' -> '.it618_video_getsmsstr($it618_video_goods_video['it618_name'],60).'\')"><img src="source/plugin/it618_video/images/paper.png" style="vertical-align:middle;height:14px;margin-top:-1px;margin-right:3px">'.$it618_video_lang['s1427'].'</a> <font color=#888>('.$examcount.')</font>';
	}
	
	$tmpurl=it618_video_getrewrite('video_lesson',$it618_video_goods_video['id'],'plugin.php?id=it618_video:lesson&lid='.$it618_video_goods_video['id']);
	
	showtablerow('', array('class="td25"', '', '', '', '', ''), array(
		'<input class="checkbox" type="checkbox" id="chk_del'.$it618_video_goods_video['id'].'" name="delete[]" value="'.$it618_video_goods_video['id'].'" '.$disabled.'><label for="chk_del'.$it618_video_goods_video['id'].'">'.$it618_video_goods_video['id'].'</label>',
		'<input type="text" class="txt" style="width:410px;margin-right:3px;margin-bottom:6px" name="it618_name['.$it618_video_goods_video['id'].']" value="'.$it618_video_goods_video['it618_name'].'"><br><textarea name="it618_description['.$it618_video_goods_video['id'].']" style="width:410px;height:58px">'.$it618_video_goods_video['it618_description'].'</textarea>
		',
		'
		<div style="width:410px;position:relative">
		<div style="line-height:20px">
		<a href="'.$tmpurl.'" target="_blank" style="display:inline-block;float:right; padding:1px 5px;padding-bottom:3px; background-color:#22b1fe; margin-top:3px; color:#fff; border-radius:3px">'.$it618_members_lang['s849'].'</a>
		<a href="javascript:" onclick="showvideocontent('.$it618_video_goods_video['id'].')"><img src="source/plugin/it618_video/images/xq.png" style="vertical-align:middle;height:13px;margin-top:-2px;margin-right:3px;margin-left:-3px">'.it618_video_getlang('s1602').'</a> <font color=#888>('.strlen($it618_video_goods_video['it618_message']).')</font>
		<br>
		<a href="plugin.php?id=it618_video:sc_product_content_audio'.$adminsid.'&vid='.$it618_video_goods_video['id'].'&preurl='.$preurl.'"><img src="source/plugin/it618_video/images/audio.png" style="vertical-align:middle;height:14px;margin-top:-3px;margin-right:3px">'.$it618_video_lang['s20'].'</a> <font color=#888>('.$it618_videotimestr.')</font></span>
		
		<br>
		<span style="float:right">'.$tmpexam.'</span>
		<a href="plugin.php?id=it618_video:sc_product_data'.$adminsid.'&vid='.$it618_video_goods_video['id'].'&preurl='.$preurl.'"><img src="source/plugin/it618_video/images/fj.png" style="vertical-align:middle;height:13px;margin-top:-3px;margin-right:3px">'.$it618_video_lang['s442'].'</a> <font color=#888>('.$it618_video_goods_video['it618_datacount'].''.$it618_video_lang['s443'].'/'.it618_video_getsize($it618_video_goods_video['it618_datasize']).')</font></span>

		</div>
		
		<div style="width:410px;line-height:26px;margin-top:6px'.$salecss.';border:#f1f1f1 1px solid;padding:3px"><input class="checkbox" type="checkbox" id="chk_isprotect'.$n.'" name="it618_issale['.$it618_video_goods_video['id'].']" '.$it618_issale_checked.' value="1" onchange="getprice(this,'.$it618_video_goods_video['id'].')"><label for="chk_isprotect'.$n.'">'.it618_video_getlang('s1897').'</label> <span id="spanprice'.$it618_video_goods_video['id'].'" style="'.$issalecss.'">
		
		<div style="'.$goodstypecss.'">
		<input type="text" class="txt" style="width:80px;margin-right:3px;color:red;" name="it618_saleprice['.$it618_video_goods_video['id'].']" value="'.$it618_video_goods_video['it618_saleprice'].'">'.it618_video_getlang('s125').'+<input type="text" class="txt" style="width:80px;margin-right:3px;;color:red" name="it618_score['.$it618_video_goods_video['id'].']" value="'.$it618_video_goods_video['it618_score'].'"><select name="it618_jfid['.$it618_video_goods_video['id'].']">'.it618_video_getjftype($it618_video_goods_video['it618_jfid']).'</select> '.$it618_video_lang['s1795'].'<input type="text" class="txt" style="width:80px;margin-right:3px;" name="it618_price['.$it618_video_goods_video['id'].']" value="'.$it618_video_goods_video['it618_price'].'">'.it618_video_getlang('s125').'
		</div>
		<div>
		'.$goodstypestr.$goodspinstr.'
		</div>
		</span></div>
		</div>
		',
		'<div style="text-align:center"><select style="color:'.$isusercolor.'" name="it618_isuser['.$it618_video_goods_video['id'].']"><option value=1 '.$it618_isuser_selected1.' style="color:#f30">'.$it618_video_lang['s27'].'</option><option value=2 '.$it618_isuser_selected2.' style="color:#22b1fe">'.$it618_video_lang['s28'].'</option><option value=0 '.$it618_isuser_selected0.' style="color:#390">'.$it618_video_lang['s30'].'</option></select>'.$chatstr.'</div>',
		'<input type="text" class="txt" style="width:40px;text-align:center;margin-bottom:3px" name="it618_order['.$it618_video_goods_video['id'].']" value="'.$it618_video_goods_video['it618_order'].'"><br>
		<input class="checkbox" type="checkbox" id="chk_ison'.$n.'" name="it618_ison['.$it618_video_goods_video['id'].']" '.$it618_ison_checked.' value="1"><label for="chk_ison'.$n.'">'.it618_video_getlang('s104').'</label>'
	));
	$n=$n+1;
}

$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_lesson')." where it618_pid=".$it618_video_goods_lesson['it618_pid']." and id!=".$lid." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
}
	

	$it618_video_langs315=$it618_video_lang['s315'];
	$it618_video_langss373=$it618_video_lang['s373'];
	$it618_gtypes702=it618_video_getlang('s702');
	$it618_video_langs27=$it618_video_lang['s27'];
	$it618_video_langs28=$it618_video_lang['s28'];
	$it618_video_langs30=$it618_video_lang['s30'];
	$it618_video_langs1018=$it618_video_lang['s1018'];
	$it618_video_langs1019=$it618_video_lang['s1019'];
	$it618_video_langs1020=$it618_video_lang['s1020'];
	$it618_video_langs1021=$it618_video_lang['s1021'];
	
	if($IsChat!=1){
		$chatcss='display:none';
	}
	
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:430px;margin-bottom:10px" name="newit618_name[]"><br>$it618_video_langss373'],
		[1,''],
		[1,'<textarea name="newit618_description[]" style="width:400px;height:46px"></textarea>'],
		[1,'<select name="newit618_isuser[]"><option value=1 style="color:#f30">$it618_video_langs27</option><option value=2 style="color:#22b1fe">$it618_video_langs28</option><option value=0 style="color:#390">$it618_video_langs30</option></select><span style="$chatcss"><br><select name="newit618_ischat[]"><option value=3>$it618_video_langs1018</option><option value=2>$it618_video_langs1019</option><option value=1>$it618_video_langs1020</option><option value=0>$it618_video_langs1021</option></select></span>'],
		[1,'<input type="text" class="txt" style="width:26px" name="newit618_order[]">']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$it618_video_lang['s831'].'</a></div></td></tr>';
    
    echo '
    <span id="it618_media_select"></span>
	<script>
	function getprice(obj,tmpn){
		if(!obj.checked){
			document.getElementById("spanprice"+tmpn).style.display="none";
		}else{
			document.getElementById("spanprice"+tmpn).style.display="";
		}
	}
	
	function showgoodstype(pid,lid,vid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_video_lang['s710'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_video:sc_product_type'.$adminsid.'&pid="+pid+"&lid="+lid+"&vid="+vid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	
	function showvideocontent(vid){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>'.$it618_video_lang['s367'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_video:sc_product_content_edit'.$adminsid.'&vid="+vid,
			cancel: function(index, layero){ 

			}    
		});
	}
	
	function addexams(vid,title){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>"+title+" - '.$it618_video_lang['s1426'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_exam:sc_product_examadd'.$adminsid.'&vid="+vid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	
	function editexams(vid,title){
		layerindex=layer.open({
			type: 2,
			title: "<div style=\'float:left;color:blue\'>"+title+" - '.$it618_video_lang['s1427'].'</div>",
			shadeClose: false,
			scrollbar: false,
			shade:  [0.5, "#393D49"],
			maxmin: false,
			area: ["100%", "100%"],
			content: "plugin.php?id=it618_exam:sc_product_examedit'.$adminsid.'&vid="+vid,
			cancel: function(index, layero){ 
				location.reload();
			}    
		});
	}
	
	var vid,type;
	function media_select(id){
		vid=id;type="video";title="'.$it618_video_lang['s1777'].'";
		document.getElementById("it618_media_select").click();
	}
	
	function media_select1(id){
		vid=id;type="audio";title="'.$it618_video_lang['s1790'].'";
		document.getElementById("it618_media_select").click();
	}
	
    var dialog_media;
    KindEditor.ready(function(K) {K("#it618_media_select").click(function() {
    
        dialog_media = K.dialog({
            width : 848,
            height: 558,
            title : title,
            body : \'<div><iframe id="ifa_media" src="plugin.php?id=it618_video:sc_media_select'.$adminsid.'&type=\'+type+\'" style="border:0;" frameborder=0 width="848" height="536"></iframe></div>\',
            closeBtn : {
                name : "'.$it618_video_lang['t285'].'",
                click : function(e) {
                    dialog_media.remove();
                }
            }
        });
    
    });});
    </script>';
	
	if($tmp!='')$tmp='<span style="float:right"><select name="lessonid">'.$tmp.'</select> <input type="submit" class="btn" name="it618submit_move" value="'.$it618_gtypes702.'" onclick="return confirm(\''.it618_video_getlang('s661').'\')" /></span>';
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_video_getlang('s644').'</label></td><td colspan="15"><input type="submit" class="btn" name="it618submit" value="'.it618_video_getlang('s645').'"/>'.$tmp.'<div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></div><br></td></tr>';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>