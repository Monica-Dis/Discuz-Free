<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

if(submitcheck('it618submit')){
	DB::query("update ".DB::table('it618_video_shop')." set it618_isqunchat=".intval($_GET['isquanchat']).",it618_qunchattime=".intval($_GET['qunchattime'])." where id=".$ShopId);

	it618_cpmsg(it618_video_getlang('s16'), "plugin.php?id=it618_video:sc_subscribe$adminsid", 'succeed');
}

echo '
<script charset="utf-8" src="source/plugin/it618_video/js/jquery.js"></script>
';

it618_showformheader("plugin.php?id=it618_video:sc_subscribe$adminsid");
showtableheaders($it618_video_lang['s1400'],'it618_video_subscribe');

if($it618_video_shop['it618_isqunchat']==1)$it618_isqunchat_checked='checked="checked"';else $it618_isqunchat_checked="";

	echo '<tr><td colspan="15"><div class="fixsel">'.it618_video_getlang('s1406').' <input id="finduid" class="txt" style="width:76px" /> &nbsp;<input type="button" class="btn" value="'.it618_video_getlang('t244').'" onclick="findsalelist()" /><div style="float:right;margin-top:3px"><input class="checkbox" type="checkbox" id="chk_isqunchat" name="isquanchat" '.$it618_isqunchat_checked.' value="1"><label for="chk_isqunchat">'.$it618_video_lang['s1509'].'</label> '.$it618_video_lang['s1510'].' <input name="qunchattime" value="'.$it618_video_shop['it618_qunchattime'].'" class="txt" style="width:58px;margin-right:3px" />'.$it618_video_lang['s1511'].' <input type="submit" class="btn" name="it618submit" value="'.$it618_video_lang['s1512'].'"/></div></div></td></tr>';
	
	echo '<tr><td colspan="15" id="tr_salesum"></td></tr>';
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
		showsubtitle(array(it618_video_getlang('s1401'),it618_video_getlang('s1942'),it618_video_getlang('s1947'),it618_video_getlang('s1402')));
	}else{
		showsubtitle(array(it618_video_getlang('s1401'),it618_video_getlang('s1947'),it618_video_getlang('s1402')));
	}
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_video/wap/images/loading.gif"></td></tr><tbody id="tr_salelist"></tbody>';
	
	echo '<tr id="salepage"></tr>';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/
echo '
<script>
var saleurl="'.$_G['siteurl'].'plugin.php?id=it618_video:ajax";
var sqlurl="";
function getshopsubscribelist(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("tr_salelist").style.display="none";
	IT618_VIDEO.post(url+sqlurl+"'.$adminsid.'&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"shopsubscribe_get",ac1:"pcshopsubscribe"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_VIDEO("#tr_salesum").html(tmparr[0]);
	IT618_VIDEO("#tr_salelist").html(tmparr[1]);
	IT618_VIDEO("#salepage").html(tmparr[2]);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("tr_salelist").style.display="";
	}, "html");	
	saleurl=url;
}
getshopsubscribelist(saleurl);

function findsalelist(){
	var finduid = document.getElementById("finduid").value;
	
	sqlurl="&finduid="+finduid;
	var url="'.$_G['siteurl'].'plugin.php?id=it618_video:ajax";
	getshopsubscribelist(url);
}
</script>
';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>