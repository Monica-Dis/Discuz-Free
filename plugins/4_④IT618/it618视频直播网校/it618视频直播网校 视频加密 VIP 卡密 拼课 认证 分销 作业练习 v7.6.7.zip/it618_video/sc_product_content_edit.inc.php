<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$vid=intval($_GET['vid']);
$preurl=$_GET['preurl'];
$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_id($vid);
$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_video['it618_pid']);
$it618_video_goods_lesson=C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($it618_video_goods_video['it618_lid']);
if($it618_video_goods_video['it618_liveid']==0){
	$videoname=$it618_video_goods_video['it618_name'];
}else{
	$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
	$videoname=$it618_video_live['it618_name'];
}

$it618_message=$it618_video_goods_video['it618_message'];
if($_GET['type']=='usercodeabout'){
	$type='usercodeabout';
	$it618_message=$it618_video_goods_video['it618_usercodeabout'];
}
if($_GET['type']=='videocontent'){
	$type='videocontent';
}

if(submitcheck('it618submit')){
	if($_GET['type']=='usercodeabout'){
		C::t('#it618_video#it618_video_goods_video')->update($vid,array(
			'it618_usercodeabout' => $_GET['it618_message']
		));
	}else{
		C::t('#it618_video#it618_video_goods_video')->update($vid,array(
			'it618_message' => $_GET['it618_message'],
			'it618_ischatdefault' => $_GET['it618_ischatdefault']
		));
	}
	
	if($_GET['type']=='videocontent'){
		C::t('#it618_video#it618_video_goods_video')->update($vid,array(
			'it618_ismessagedefault' => $_GET['it618_ismessagedefault'],
			'it618_ismessagetb' => $_GET['it618_ismessagetb'],
			'it618_messagename' => $_GET['it618_messagename']
		));
	}

	echo '<script>parent.location.reload();parent.layer.closeAll();</script>';
}

it618_showformheader("plugin.php?id=it618_video:sc_product_content_edit$adminsid&vid=$vid&type=$type");
showtableheaders($it618_video_goods['it618_name'].' - '.$it618_video_goods_lesson['it618_name'].' - '.$videoname,'sc_product_video_edit');

if($_GET['type']!='usercodeabout'){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php';
	}
	
	if($it618_video_goods_video['it618_ischatdefault']==1){$it618_ischatdefault_checked='checked="checked"';}else $it618_ischatdefault_checked="";
	if($it618_video_goods_video['it618_ismessagedefault']==1){$it618_ismessagedefault_checked='checked="checked"';}else $it618_ismessagedefault_checked="";
	if($it618_video_goods_video['it618_ismessagetb']==1){$it618_ismessagetb_checked='checked="checked"';}else $it618_ismessagetb_checked="";
	if($it618_video_goods_video['it618_messagename']=='')$it618_video_goods_video['it618_messagename']=$it618_video_lang['s1814'];
	
	if($player_ischat!=1&&$IsChat==1){
		$chatstr='<tr><td><input type="checkbox" id="it618_ischatdefault" name="it618_ischatdefault" value=1 style="vertical-align:middle" '.$it618_ischatdefault_checked.'><label for="it618_ischatdefault">'.$it618_video_lang['s2003'].'</label></td></tr>';
	}
	
	if($_GET['type']=='videocontent'){
		$tmpstr='
		<tr><td>'.$it618_video_lang['s2001'].'<input type="text" class="txt" style="width:390px;margin-bottom:3px;margin-left:6px" id="it618_messagename" name="it618_messagename" value="'.$it618_video_goods_video['it618_messagename'].'" ><br><font color=#999>'.$it618_video_lang['s2002'].'</font></td></tr>
		<tr><td><input type="checkbox" id="it618_ismessagedefault" name="it618_ismessagedefault" value=1 style="vertical-align:middle" '.$it618_ismessagedefault_checked.'><label for="it618_ismessagedefault">'.$it618_video_lang['s2000'].'</label></td></tr>
		<tr><td><input type="checkbox" id="it618_ismessagetb" name="it618_ismessagetb" value=1 style="vertical-align:middle" '.$it618_ismessagetb_checked.'><label for="it618_ismessagetb">'.$it618_video_lang['s1606'].'</label></td></tr>
		';
	}
}

echo '
<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/plugins/code/prettify.js"></script>

<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_video/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_video/kindeditor/php/upload_json.php?shopid='.$ShopId.'&imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_video/kindeditor/php/file_manager_json.php?shopid='.$ShopId.'\',
			allowFileManager : true,
			filterMode:false
		});
	});
</script>

'.$chatstr.'
'.$tmpstr.'
<tr><td><textarea name="it618_message" style="width:780px;height:430px;visibility:hidden;">'.$it618_message.'</textarea></td></tr>
';

echo '<tr><td><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_video_getlang('s1970').'" /></div></td></tr>';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>