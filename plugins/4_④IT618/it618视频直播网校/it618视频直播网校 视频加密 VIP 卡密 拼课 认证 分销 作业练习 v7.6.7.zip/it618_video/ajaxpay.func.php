<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function pay_success($out_trade_no){
	global $_G;
	
	if($it618_salepay=C::t('#it618_credits#it618_credits_salepay')->fetch_by_out_trade_no($out_trade_no)){
		if($it618_salepay['it618_state']==1)return;
	}else{
		return;	
	}
	
	$salepay_saletype=$it618_salepay['it618_saletype'];
	$salepay_saleid=$it618_salepay['it618_saleid'];
	$salepay_paytype=$it618_salepay['it618_paytype'];
	$salepay_payid=$it618_salepay['it618_payid'];
	$salepay_url=$it618_salepay['it618_url'];
	$salepay_wap=$it618_salepay['it618_wap'];

	require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';
	
	set_time_limit (0);
	ignore_user_abort(true);

	$flagkm=0;$times=0;
	while($flagkm==0){
		if(DB::result_first("select count(1) from ".DB::table('it618_video_salework'))==0){
			$flagkm=1;
		}
		if($flagkm==0){
			sleep(1);
			$times=$times+1;
		}
		if($times>60){
			it618_video_delsalework();
		}
	}
	C::t('#it618_video#it618_video_salework')->insert(array(
		'it618_iswork' => 1
	), true);
	
	if($salepay_saletype=='0301'){
		$it618_video_sale=C::t('#it618_video#it618_video_sale')->fetch_by_id($salepay_saleid);
			
		if($it618_video_sale['it618_state']!=1){
			C::t('#it618_video#it618_video_sale')->update($salepay_saleid,array(
				'it618_state' => 1,
			));
			
			if($it618_video_sale['it618_tuijid']>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
				Union_TuiTC_Add($it618_video_sale['it618_tuijid'],$salepay_saleid);
			}
			
			C::t('#it618_credits#it618_credits_salepay')->update_state_by_out_trade_no(1,$_G['timestamp'],$out_trade_no);
			
			for($i=1;$i<=8;$i++){
				if($it618_video_sale['it618_credit'.$i]>0){
					C::t('common_member_count')->increase($it618_video_sale['it618_uid'], array(
						'extcredits'.$i => (0-$it618_video_sale['it618_credit'.$i]))
					);
				}
			}
			
			it618_video_updategoodscount($it618_video_sale);
			
			it618_video_qrxf($it618_video_sale['id']);
			
			it618_video_delsalework();
	
			it618_video_sendmessage('sale_user',$it618_video_sale['id']);
			it618_video_sendmessage('sale_shop',$it618_video_sale['id']);
			it618_video_sendmessage('sale_admin',$it618_video_sale['id']);
			
			return 'success';
		}
	
	}
	
	if($salepay_saletype=='0302'){
		$it618_video_gwcsale_main=C::t('#it618_video#it618_video_gwcsale_main')->fetch_by_id($salepay_saleid);
			
		if($it618_video_gwcsale_main['it618_state']!=1){
			C::t('#it618_video#it618_video_gwcsale_main')->update($salepay_saleid,array(
				'it618_state' => 1
			));
			
			C::t('#it618_credits#it618_credits_salepay')->update_state_by_out_trade_no(1,$_G['timestamp'],$out_trade_no);
			
			foreach(C::t('#it618_video#it618_video_gwcsale')->fetch_all_by_gwcid($salepay_saleid) as $it618_video_gwcsale) {
				
				if($IsUnion==1&&$it618_video_gwcsale['it618_tuijid']>0){
					require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
					$it618_tuijid=Union_IsTuiJoin('video',$it618_video_gwcsale['it618_pid'],$it618_video_gwcsale['it618_tuijid']);
				}
				
				$id = C::t('#it618_video#it618_video_sale')->insert(array(
					'it618_gwcid' => $salepay_saleid,
					'it618_shopid' => $it618_video_gwcsale['it618_shopid'],
					'it618_uid' => $it618_video_gwcsale['it618_uid'],
					'it618_pid' => $it618_video_gwcsale['it618_pid'],
					'it618_gtypeid' => $it618_video_gwcsale['it618_gtypeid'],
					'it618_tuijid' => $it618_tuijid,
					'it618_price' => $it618_video_gwcsale['it618_price'],
					'it618_jfid' => $it618_video_gwcsale['it618_jfid'],
					'it618_score' => $it618_video_gwcsale['it618_score'],
					'it618_count' => $it618_video_gwcsale['it618_count'],
					'it618_quanmoney' => $it618_video_gwcsale['it618_quanmoney'],
					'it618_vipzk' => $it618_video_gwcsale['it618_vipzk'],
					'it618_sfmoney' => $it618_video_gwcsale['it618_sfmoney'],
					'it618_sfscore' => $it618_video_gwcsale['it618_sfscore'],
					'it618_jfbl' => $it618_video_gwcsale['it618_jfbl'],
					'it618_tel' => $it618_video_gwcsale['it618_tel'],
					'it618_state' => 1,
					'it618_time' => $it618_video_gwcsale['it618_time']
				), true);
				
				if($it618_tuijid>0){
					Union_TuiTC_Add($it618_tuijid,$id);
				}
				
				$it618_video_sale=C::t('#it618_video#it618_video_sale')->fetch_by_id($id);
				
				for($i=1;$i<=8;$i++){
					if($it618_video_sale['it618_credit'.$i]>0){
						C::t('common_member_count')->increase($it618_video_sale['it618_uid'], array(
							'extcredits'.$i => (0-$it618_video_sale['it618_credit'.$i]))
						);
					}
				}
				
				it618_video_updategoodscount($it618_video_sale);
			
				it618_video_qrxf($it618_video_sale['id']);
			}
			
			C::t('#it618_video#it618_video_gwcsale')->delete_by_uid($it618_video_gwcsale_main['it618_uid']);
			C::t('#it618_video#it618_video_gwc')->delete_by_uid($it618_video_gwcsale_main['it618_uid']);
			
			it618_video_delsalework();

			it618_video_sendmessage('gwc_user',$it618_video_gwcsale_main['id']);
			foreach(C::t('#it618_video#it618_video_sale')->fetch_all_shopid_by_gwcid($it618_video_gwcsale_main['id']) as $shopids) {
				it618_video_sendmessage('gwc_shop',$it618_video_gwcsale_main['id'],$shopids['it618_shopid']);
			}
			it618_video_sendmessage('gwc_admin',$it618_video_gwcsale_main['id']);
			
			return 'success';

		}
	
	}
	
	it618_video_delsalework();

}
?>