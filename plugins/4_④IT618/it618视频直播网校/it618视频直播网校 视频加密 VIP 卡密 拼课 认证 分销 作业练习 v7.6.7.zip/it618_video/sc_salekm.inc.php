<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

if($it618_video_shop['it618_issalekm']==1){
	$IsSaleKm=1;
}else{
	$shopadmin=explode(",",$it618_video['video_shopadmin']);
	if(in_array($_G['uid'],$shopadmin)){
		$IsSaleKm=1;
	}
}

if($IsSaleKm!=1){
	echo $it618_video_lang['s513'];exit;
}

$typeid=intval($_GET['typeid']);
$it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($typeid);
		
$tmptitle=it618_video_getgoodstypename($it618_video_goods_type);

echo '
<script charset="utf-8" src="source/plugin/it618_video/js/laydate/laydate.js"></script>
<script charset="utf-8" src="source/plugin/it618_video/js/jquery.js"></script>
<style>
#tr_salelist td.tdgroup img{vertical-align:middle; margin-top:-3px; margin-right:5px; width:20px; height:20px; border-radius:3px}
</style>
';

showtableheaders($tmptitle,'it618_video_sum');

	echo '<tr><td colspan="15"><div class="fixsel">'.it618_video_getlang('s2277').' <input id="finduid" class="txt" style="width:76px" />'.it618_video_getlang('s2278').' <input id="findtypeid" class="txt" style="width:76px" value="'.$typeid.'"/>'.it618_video_getlang('s2279').' <input id="it618_time1" class="txt" style="width:90px;margin-right:0" readonly="readonly" />-<input id="it618_time2" class="txt" style="width:90px;" readonly="readonly"/> &nbsp;<input type="button" class="btn" value="'.it618_video_getlang('s25').'" onclick="findsalkmlist()" /> <input type="button" class="btn" value="'.it618_video_getlang('s2284').'" onclick="dao()" /> </div></td></tr>';
	
	echo '<tr id="tr_salesum"></tr>';
	
	showsubtitle(array(it618_video_getlang('s2127'),it618_video_getlang('s2281'),it618_video_getlang('s2036'),it618_video_getlang('s2037')));
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_video/template/mall_wap/images/loading.gif"></td></tr><tbody id="tr_salelist"></tbody>';
	
	echo '<tr id="salepage"></tr>';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/
echo '
<script>
laydate.render({
  elem: "#it618_time1"
});
laydate.render({
  elem: "#it618_time2"
});

var saleurl="'.$_G['siteurl'].'plugin.php?id=it618_video:ajax";
var sqlurl="";
function getsalekmlist(url){
	document.getElementById("img_loading").style.display="";
	document.getElementById("tr_salelist").style.display="none";
	IT618_VIDEO.post(url+sqlurl+"'.$adminsid.'&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"salekm_get"},function (data, textStatus){
	var tmparr=data.split("it618_split");
	IT618_VIDEO("#tr_salesum").html(tmparr[0]);
	IT618_VIDEO("#tr_salelist").html(tmparr[1]);
	IT618_VIDEO("#salepage").html(tmparr[2]);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("tr_salelist").style.display="";
	}, "html");	
	saleurl=url;
}
findsalkmlist();

function findsalkmlist(){
	var finduid = document.getElementById("finduid").value;
	var findtypeid = document.getElementById("findtypeid").value;
	var it618_time1 = document.getElementById("it618_time1").value;
	var it618_time2 = document.getElementById("it618_time2").value;
	
	sqlurl="&finduid="+finduid+"&findtypeid="+findtypeid+"&it618_time1="+it618_time1+"&it618_time2="+it618_time2;
	var url="'.$_G['siteurl'].'plugin.php?id=it618_video:ajax";
	getsalekmlist(url);
}

function dao(){
	findsalkmlist();
	IT618_VIDEO.get(saleurl+sqlurl+"'.$adminsid.'&formhash='.FORMHASH.'&rand="+Math.random(), {ac:"salekm_dao"},function (data, textStatus){
	window.open(data);
	}, "html");	
}
</script>
';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>