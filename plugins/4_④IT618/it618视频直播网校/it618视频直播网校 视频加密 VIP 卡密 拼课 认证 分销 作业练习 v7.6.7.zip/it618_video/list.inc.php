<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$pagetype='list';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/video_default.func.php';

$class1=intval($_GET['class1']);
$class2=intval($_GET['class2']);
$price=intval($_GET['price']);
$order=intval($_GET['order']);

if(video_is_mobile()){ 
	if($class2>0){
		$tmpurl=it618_video_getrewrite('video_wap','search@'.$class1.'@'.$class2,'plugin.php?id=it618_video:wap&pagetype=search&cid1='.$class1.'&cid2='.$class2);
	}else{
		$tmpurl=it618_video_getrewrite('video_wap','search@'.$class1,'plugin.php?id=it618_video:wap&pagetype=search&cid='.$class1);
	}
	dheader("location:$tmpurl");
}

$tmpidsarr=explode(',',$hotclassgoods[1]);
for($i=0;$i<count($tmpidsarr);$i++){
	$id=intval($tmpidsarr[$i]);
	$it618_video_class2=C::t('#it618_video#it618_video_class2')->fetch_by_id($id);
	$tmpurl=it618_video_getrewrite('video_list',$it618_video_class2['it618_class1_id'].'@'.$id,'plugin.php?id=it618_video:list&class1='.$it618_video_class2['it618_class1_id'].'&class2='.$id);
	$listhotclass.='<li><a href="'.$tmpurl.'">'.$it618_video_class2['it618_classname'].'</a></li>';
}

if($class1>0){
	$class1name=C::t('#it618_video#it618_video_class1')->fetch_it618_name_by_id($class1);
	$classtitle.=$class1name.' ';
	$tmpurl=it618_video_getrewrite('video_list','0@0@'.$price.'@'.$order,'plugin.php?id=it618_video:list&class1=0&class2=0&price='.$price.'&order='.$order);
	$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$class1name.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
}

if($class2>0){
	$tmpname=C::t('#it618_video#it618_video_class2')->fetch_it618_name_by_id($class2);
	$classtitle.=$tmpname.' ';
	$tmpurl=it618_video_getrewrite('video_list',$class1.'@0@'.$price.'@'.$order,'plugin.php?id=it618_video:list&class1='.$class1.'&class2=0&price='.$price.'&order='.$order);
	$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$tmpname.'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
}

$pricename[0]=it618_video_getlang('s466');$pricename[1]='50'.it618_video_getlang('s468');$pricename[2]='50-100'.it618_video_getlang('s125');$pricename[3]='100-200'.it618_video_getlang('s125');$pricename[4]='200-300'.it618_video_getlang('s125');$pricename[5]='300'.it618_video_getlang('s469');
if($price>0){
	$tmpurl=it618_video_getrewrite('video_list',$class1.'@'.$class2.'@0@'.$order,'plugin.php?id=it618_video:list&class1='.$class1.'&class2='.$class2.'&price=0&order='.$order);
	$listnav.='<span class="sfbc-item"><em class="sfbc-item-title"><font>'.$pricename[$price].'</font><a class="item-close" href="'.$tmpurl.'"></a></em></span><i class="crumb-icon"></i>';
}

$listnav.='@';
$listnav=str_replace('<i class="crumb-icon"></i>@','',$listnav);

if($class1==0)$current=' class="current"';else $current='';
$tmpurl=it618_video_getrewrite('video_list','0@0@'.$price.'@'.$order,'plugin.php?id=it618_video:list&class1=0&class2=0&price='.$price.'&order='.$order);
$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_video_getlang('s466').'</a></li>';
$query = DB::query("SELECT * FROM ".DB::table('it618_video_class1')." ORDER BY it618_order");
while($it618_video_class1 = DB::fetch($query)) {
	$goodscount=C::t('#it618_video#it618_video_goods')->count_by_search('g.it618_state=1','',0,$it618_video_class1['id']);
	if($class1==$it618_video_class1['id'])$current=' class="current"';else $current='';
	
	$tmpurl=it618_video_getrewrite('video_list',$it618_video_class1['id'].'@0@'.$price.'@'.$order,'plugin.php?id=it618_video:list&class1='.$it618_video_class1['id'].'&price='.$price.'&order='.$order);
	$str_class1.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_video_class1['it618_classname'].'<span>'.$goodscount.'</span></a></li>';
}

if($class1>0){
	if($class2==0)$current=' class="current"';else $current='';
	$tmpurl=it618_video_getrewrite('video_list',$class1.'@0@'.$price.'@'.$order,'plugin.php?id=it618_video:list&class1='.$class1.'&class2=0&price='.$price.'&order='.$order);
	$str_class2.='<li><a href="'.$tmpurl.'"'.$current.'>'.it618_video_getlang('s466').'</a></li>';
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_class2')." where it618_class1_id=".$class1." ORDER BY it618_order");
	while($it618_video_class2 = DB::fetch($query)) {
		$goodscount=C::t('#it618_video#it618_video_goods')->count_by_search('g.it618_state=1','',0,0,$it618_video_class2['id']);
		if($class2==$it618_video_class2['id'])$current=' class="current"';else $current='';
		
		$tmpurl=it618_video_getrewrite('video_list',$class1.'@'.$it618_video_class2['id'].'@'.$price.'@'.$order,'plugin.php?id=it618_video:list&class1='.$class1.'&class2='.$it618_video_class2['id'].'&price='.$price.'&order='.$order);
		$str_class2.='<li><a href="'.$tmpurl.'"'.$current.'>'.$it618_video_class2['it618_classname'].'<span>'.$goodscount.'</span></a></li>';
	}
}

for($i=0;$i<=5;$i++){
	if($i==1){$price1=0;$price2=50;}
	if($i==2){$price1=50;$price2=100;}
	if($i==3){$price1=100;$price2=200;}
	if($i==4){$price1=200;$price2=300;}
	if($i==5){$price1=300;$price2=0;}
	if($price==$i)$current=' class="current"';else $current='';
	if($i>0){
		$goodscount=C::t('#it618_video#it618_video_goods')->count_by_search('g.it618_state=1','',0,0,0,'',$price1,$price2);
		$tmpstr='<span>'.$goodscount.'</span>';
	}
	
	$tmpurl=it618_video_getrewrite('video_list',$class1.'@'.$class2.'@'.$i.'@'.$order,'plugin.php?id=it618_video:list&class1='.$class1.'&class2='.$class2.'&price='.$i.'&order='.$order);
	$str_price.='<li><a href="'.$tmpurl.'"'.$current.'>'.$pricename[$i].$tmpstr.'</a></li>';
}

$price1=0;$price2=0;
if($price==1){$price1=0;$price2=50;}
if($price==2){$price1=50;$price2=100;}
if($price==3){$price1=100;$price2=200;}
if($price==4){$price1=200;$price2=300;}
if($price==5){$price1=300;$price2=0;}

if($order==0){$current0=' class="left current"';$it618orderby='g.it618_order desc,g.id desc';}else $current0=' class="left"';
if($order==1){$current1=' class="current"';$it618orderby='g.it618_salecount desc';}else $current1='';
if($order==2){$current2=' class="current"';$it618orderby='g.it618_views desc';}else $current2='';
if($order==3){$current3=' class="current"';$it618orderby='g.it618_saleprice';}else $current3='';
if($order==4){$current4=' class="current"';$it618orderby='g.it618_saleprice desc';}else $current4='';
if($order==5){$current5=' class="current"';$it618orderby='g.it618_time desc';}else $current5='';

for($i=0;$i<=5;$i++){
	$tmpurl=it618_video_getrewrite('video_list',$class1.'@'.$class2.'@'.$price.'@'.$i,'plugin.php?id=it618_video:list&class1='.$class1.'&class2='.$class2.'&price='.$price.'&order='.$i);
	$orderurl[$i]=$tmpurl;
}

if($templatename=='mall'){
	$video_listpagecount=$it618_video['video_listpagecount']*3;
}

if($templatename=='edu'){
	$video_listpagecount=$it618_video['video_listpagecount']*4;
}

$ppp=$video_listpagecount;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$it618sql='g.it618_state=1';

$count = C::t('#it618_video#it618_video_goods')->count_by_search($it618sql,$it618orderby,0,$class1,$class2,'',$price1,$price2);
$hrefsql=it618_video_getrewrite('video_list',$class1.'@'.$class2.'@'.$price.'@'.$order.'@it618page','plugin.php?id=it618_video:list&class1='.$class1.'&class2='.$class2.'&price='.$price.'&order='.$order);
$multipage = multi($count, $ppp, $page, $_G['siteurl'].$hrefsql);
$multipage = it618_video_multipage($multipage,$uri);

foreach(C::t('#it618_video#it618_video_goods')->fetch_all_by_search(
	$it618sql,$it618orderby,0,$class1,$class2,'',$price1,$price2,$startlimit,$ppp
) as $it618_video_goods) {
	
	$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
	
	$jfbl='';
	if($it618_video_goods['it618_jfbl']>0&&$it618_video_goods['it618_saleprice']>0){
		//$jfbl='<div class="divjfbl">'.$it618_video_lang['s1371'].str_replace(".00","",$it618_video_goods['it618_jfbl']).'%'.$creditname.'</div>';
	}
	
	if($templatename=='mall'){
		$pricestr='<span class="price" style="color:#f60;font-size:20px">'.$it618_video_lang['s1534'].'</span>';
		if($it618_video_shop['it618_issale']==1){
			if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
				$pricestr='<span class="price" style="padding:0;padding-right:3px">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
			}else{
				$pricestr='<span class="price" style="color:#390;font-size:20px">'.$it618_video_lang['s106'].'</span>';
			}
		}
		
		$it618_isvip='';
		$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
		if(count($vipgroupids)>0){
			$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
		}
		
		$it618_islive='';
		if(C::t('#it618_video#it618_video_live')->count_by_pid_ok($it618_video_goods['id'])>0){
			$it618_islive='<img src="source/plugin/it618_video/images/live.gif" class="imglive">';
		}
		
		$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
		$str_goodslist.='<div class="goods">
					'.$jfbl.$it618_islive.'
					<a class="goods-img" href="'.$tmpurl.'" target="_blank">
					<img imgsrc="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" src="source/plugin/it618_video/images/a.gif" class="dynload" width="308" height="185" alt="'.$it618_video_goods['it618_name'].'" />
					<span class="goods-place" title="'.$it618_video_shop['it618_about'].'">'.$it618_video_shop['it618_name'].'<br>'.cutstr($it618_video_shop['it618_about'],68,'...').'</span>
					</a>
					<h3>
					<a class="goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'">'.$it618_video_goods['it618_name'].'</a>
					<a class="goods-text" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_description'].'">'.$it618_video_goods['it618_description'].'</a>
					<span style="color:#999;line-height:35px;font-weight:normal;font-size:12px"><span style="float:right"><font color=red>'.$it618_video_goods['it618_plays'].'</font>'.it618_video_getlang('s931').'</span>'.$it618_isvip.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'</span>
					</h3>
					<div class="goods-info">
					'.$pricestr.'
					</div>
					</div>';
	}
	
	if($templatename=='edu'){
		$pricestr='<span style="color:#f60;font-size:13px">'.$it618_video_lang['s1534'].'</span>';
		if($it618_video_shop['it618_issale']==1){
			if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
				$pricestr='<span class="price">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
			}else{
				$pricestr='<span style="color:#390;">'.$it618_video_lang['s106'].'</span>';
			}
		}
		
		$it618_isvip='';
		$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
		if(count($vipgroupids)>0){
			$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
		}
		
		$it618_islive='';
		if(C::t('#it618_video#it618_video_live')->count_by_pid_ok($it618_video_goods['id'])>0){
			$it618_islive='<img src="source/plugin/it618_video/images/live.gif" class="imglive">';
		}
		
		$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
		$str_goodslist.='<div class="course-card" title="'.$it618_video_goods['it618_name'].'">
									'.$jfbl.$it618_islive.'
									<div class="course-img">
										<a href="'.$tmpurl.'" target="_blank"><img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" alt="'.$it618_video_goods['it618_name'].'" class="goodsimg"></a>
										<div class="course-name">
											<a href="'.$tmpurl.'" target="_blank">'.cutstr($it618_video_goods['it618_name'],48,'...').'</a>
										</div>
										<div class="course-author">
											'.$it618_isvip.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'
											<a href="'.$tmpurl.'" target="_blank" title="'.$it618_video_shop['it618_name'].'">'.cutstr($it618_video_shop['it618_name'],14,'...').'</a>
										</div>
										<div class="course-price">
											'.$pricestr.'
											<span class="course-plays">'.$it618_video_goods['it618_plays'].''.it618_video_getlang('s931').'</span>
										</div>
									</div>
								</div>';
	}
}

$it618sql='g.it618_state=1';
foreach(C::t('#it618_video#it618_video_goods')->fetch_all_by_search(
	$it618sql,'it618_salecount desc',0,$class1,0,'',0,0,0,5
) as $it618_video_goods) {
	
	$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
	
	if($templatename=='mall'){
		$pricestr='<span class="price" style="color:#f60;font-size:20px">'.$it618_video_lang['s1534'].'</span>';
		if($it618_video_shop['it618_issale']==1){
			if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
				$pricestr='<span class="price" style="padding:0;padding-right:3px">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
			}else{
				$pricestr='<span class="price" style="color:#390;font-size:20px">'.$it618_video_lang['s106'].'</span>';
			}
		}
		
		$it618_isvip='';
		$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
		if(count($vipgroupids)>0){
			$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
		}
					
		$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
		$str_goodshot.='<div class="small-goods"><a class="small-goods-img" href="'.$tmpurl.'" target="_blank"><img class="dynload" src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" alt="'.$it618_video_goods['it618_name'].'"/></a><h4><a class="small-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'">'.$it618_video_goods['it618_name'].'</a><a class="small-goods-text" href="'.$tmpurl.'" target="_blank" title="">'.$it618_video_goods['it618_description'].'</a><span style="color:#999;line-height:35px;font-weight:normal;font-size:12px"><span style="float:right"><font color=red>'.$it618_video_goods['it618_plays'].'</font>'.it618_video_getlang('s931').'</span>'.$it618_isvip.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'</span></h4><div class="small-goods-info">'.$pricestr.'</div></div>';
	}
	
	if($templatename=='edu'){
		$pricestr='<span style="color:#f60;font-size:13px">'.$it618_video_lang['s1534'].'</span>';
		if($it618_video_shop['it618_issale']==1){
			if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
				$pricestr='<span class="price">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
			}else{
				$pricestr='<span style="color:#390;">'.$it618_video_lang['s106'].'</span>';
			}
		}
		
		$it618_isvip='';
		$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
		if(count($vipgroupids)>0){
			$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
		}
		
		$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
		$str_goodshot.='<div class="course-card" title="'.$it618_video_goods['it618_name'].'">
									<div class="course-img">
										<a href="'.$tmpurl.'" target="_blank"><img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" alt="'.$it618_video_goods['it618_name'].'" class="goodsimg"></a>
										<div class="course-name">
											<a href="'.$tmpurl.'" target="_blank">'.cutstr($it618_video_goods['it618_name'],48,'...').'</a>
										</div>
										<div class="course-author">
											'.$it618_isvip.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'
											<a href="'.$tmpurl.'" target="_blank" title="'.$it618_video_shop['it618_name'].'">'.cutstr($it618_video_shop['it618_name'],14,'...').'</a>
										</div>
										<div class="course-price">
											'.$pricestr.'
											<span class="course-plays">'.$it618_video_goods['it618_plays'].''.it618_video_getlang('s931').'</span>
										</div>
									</div>
								</div>';
	}
}

$classtitle1=str_replace(' ','',$classtitle);
if($classtitle1=='')$classtitle=it618_video_getlang('s100');
$metatitle=$classtitle.' - '.$metatitle;

require_once DISCUZ_ROOT.'./source/plugin/it618_video/it618_api.func.php';
$_G['mobiletpl'][2]='/';
include template('it618_video:'.$templatename.'/video_default');
?>