<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$osstype=intval($_GET['osstype']);

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		C::t('#it618_video#it618_video_media_aclass')->delete_by_id($delid);
		$del=$del+1;
	}

	if(is_array($_GET['it618_classname'])) {
		foreach($_GET['it618_classname'] as $id => $val) {

			C::t('#it618_video#it618_video_media_aclass')->update($id,array(
				'it618_classname' => dhtmlspecialchars($_GET['it618_classname'][$id]),
				'it618_order' => dhtmlspecialchars($_GET['it618_order'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_classname_array = !empty($_GET['newit618_classname']) ? $_GET['newit618_classname'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_classname_array as $key => $value) {
		$newit618_classname = trim($newit618_classname_array[$key]);
		
		if($newit618_classname != '') {
			
			C::t('#it618_video#it618_video_media_aclass')->insert(array(
				'it618_shopid' => $ShopId,
				'it618_osstype' => $_GET['osstype'],
				'it618_classname' => dhtmlspecialchars($newit618_classname_array[$key]),
				'it618_order' => dhtmlspecialchars($newit618_order_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}

	it618_cpmsg(it618_video_getlang('s33').$ok1.' '.it618_video_getlang('s34').$ok2.' '.it618_video_getlang('s35').$del.')', "plugin.php?id=it618_video:sc_media_aclass$adminsid&osstype=".$osstype, 'succeed');
}

if($osstype==1){
	$tmposstype=$it618_video_lang['s1193'];
}else{
	$tmposstype=$it618_video_lang['t27'];
}

it618_showformheader("plugin.php?id=it618_video:sc_media_aclass$adminsid&osstype=".$osstype);
showtableheaders($tmposstype,'it618_video_media_aclass');
	$count = C::t('#it618_video#it618_video_media_aclass')->count_by_shopid_osstype($ShopId,$osstype);
	
	echo '<tr><td colspan=4>'.it618_video_getlang('s13').$count.'</td></tr>';
	showsubtitle(array('', it618_video_getlang('s45'), it618_video_getlang('s50'),it618_video_getlang('s12')));

	foreach(C::t('#it618_video#it618_video_media_aclass')->fetch_all_by_shopid_osstype($ShopId,$osstype) as $it618_video_media_aclass) {
		
		$mediacount = C::t('#it618_video#it618_video_media_audio')->count_by_aclass_id($it618_video_media_aclass['id']);
		$disabled="";
		if($mediacount>0)$disabled="disabled=\"disabled\"";
		showtablerow('', array('class="td25"', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"".$it618_video_media_aclass['id']."\" $disabled>",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_classname[".$it618_video_media_aclass['id']."]\" value=\"".$it618_video_media_aclass['it618_classname']."\">",
			'<input class="txt" type="text" name="it618_order['.$it618_video_media_aclass['id'].']" value="'.$it618_video_media_aclass['it618_order'].'">',
			$mediacount
		));
	}

	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_classname[]").length;
	
		return [
		[[1,''], [1,'<input type="text" class="txt" style=\"width:200px\" name="newit618_classname[]">'], [1, ' <input class="txt" type="text" name="newit618_order[]" value="1">'], [1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	</script>
EOT;
	echo '<tr><td></td><td colspan="4"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.it618_video_getlang('s831').'</a></div></td></tr>';
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_video_getlang('s591').'</label></td><td colspan="4"><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.it618_video_getlang('s592').'"/></div></td></tr>';
showtablefooter(); /*dis'.'m.tao'.'bao.com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>