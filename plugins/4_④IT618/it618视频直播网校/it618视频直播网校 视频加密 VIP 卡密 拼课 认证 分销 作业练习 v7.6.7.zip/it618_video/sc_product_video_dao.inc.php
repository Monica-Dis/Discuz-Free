<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$lid=intval($_GET['lid']);

$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_lesson['it618_pid']);

if(submitcheck('it618submit_dao')){
	
	if (preg_match('/\.\./', $_GET['it618_name_dao'])||$_GET['it618_name_dao']=='') {
		cpmsg($it618_video_lang['s1992'], "plugin.php?id=it618_video:sc_product_video_dao$adminsid&lid=$lid", 'error');
	}
	
	$tmparr=explode("source/plugin/it618_video/kindeditor",$_GET['it618_name_dao']);
	$file_path='source/plugin/it618_video/kindeditor'.$tmparr[1];
	
	require_once DISCUZ_ROOT.'./source/plugin/it618_video/phpexcel/reader.php';

	$data = new Spreadsheet_Excel_Reader();
	
	$data->setOutputEncoding('GB2312');
	
	$data->read(DISCUZ_ROOT.'./'.$file_path);

	error_reporting(E_ALL ^ E_NOTICE);
	
	$ok=0;
	for ($i = 2; $i <= $data->sheets[0]['numRows']; $i++) {

		$msgtmpstr='';
		
		$it618_name=it618_video_utftogbk(trim($data->sheets[0]['cells'][$i][1]));

		if($it618_name==''){
			if(it618_video_utftogbk(trim($data->sheets[0]['cells'][$i+1][1]))==''&&it618_video_utftogbk(trim($data->sheets[0]['cells'][$i+2][1]))==''){
				break;
			}else{
				continue;
			}
		}
		
		$it618_description=it618_video_utftogbk(trim($data->sheets[0]['cells'][$i][2]));
		$it618_videourl=it618_video_utftogbk(trim($data->sheets[0]['cells'][$i][3]));
		$it618_videotime1=it618_video_utftogbk(trim($data->sheets[0]['cells'][$i][4]));
		$it618_videotime2=it618_video_utftogbk(trim($data->sheets[0]['cells'][$i][5]));
		$it618_videotime3=it618_video_utftogbk(trim($data->sheets[0]['cells'][$i][6]));
		$it618_isuser=it618_video_utftogbk(trim($data->sheets[0]['cells'][$i][7]));
		$it618_order=it618_video_utftogbk(trim($data->sheets[0]['cells'][$i][8]));
		
		if($it618_isuser==1){
			$it618_isuser=0;
		}else if($it618_isuser==2){
			$it618_isuser=2;
		}else{
			$it618_isuser=1;
		}
		
		$it618_videotime=$it618_videotime1*3600+$it618_videotime2*60+$it618_videotime3;
		
		$it618_videourl=str_replace("'",'"',$it618_videourl);
		$it618_videourl=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" frameborder=0 allowfullscreen=1>',$it618_videourl);
		
		$tmparr=explode("<iframe",$it618_videourl);
		if(count($tmparr)>1){
			$urlarr=explode("https://",$_G['siteurl']);
			if(count($urlarr)>1){
				$it618_videourl=str_replace("http://","https://",$it618_videourl);
			}
		}
		
		if($it618_video_media_mts=C::t('#it618_video#it618_video_media_mts')->fetch_by_url($it618_videourl)){
			if($it618_video_media_mts['it618_shopid']!=$ShopId){
				$it618_videourl='';
			}
		}
			
		if($it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_lid_url($lid, $it618_videourl)){
			$msgstr.='<br>'.$it618_name.'<br>';
		}else{						
			$id=C::t('#it618_video#it618_video_goods_video')->insert(array(
				'it618_pid' => $it618_video_goods_lesson['it618_pid'],
				'it618_lid' => $lid,
				'it618_name' => $it618_name,
				'it618_description' => $it618_description,
				'it618_videourl' => $it618_videourl,
				'it618_isuser' => 1,
				'it618_videotime' => $it618_videotime,
				'it618_videotime1' => $it618_videotime1,
				'it618_videotime2' => $it618_videotime2,
				'it618_videotime3' => $it618_videotime3,
				'it618_isuser' => $it618_isuser,
				'it618_order' => $it618_order,
				'it618_ison' => 1
			), true);
			
			$ok=$ok+1;
		}
	
	}

	if(file_exists(DISCUZ_ROOT.'./'.$file_path)){
		$result=unlink(DISCUZ_ROOT.'./'.$file_path);
	}
	
	if($msgstr!='')$msgstr='<br><div style="color:red;font-weight:normal;text-align:left">'.$it618_video_lang['s1994'].'<br>'.$msgstr.'</div>';
	it618_cpmsg($it618_video_lang['s1993'].$ok.$msgstr, "plugin.php?id=it618_video:sc_product_video_dao$adminsid&lid=$lid", 'succeed');
}

echo '
<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/kindeditor-min.js"></script>
<script>
	KindEditor.ready(function(K) {
				var uploadbutton = K.uploadbutton({
					button : K(\'#btn_upfile\')[0],
					fieldName : \'imgFile\',
					url : \'source/plugin/it618_video/kindeditor/php/upload_json.php?shopid='.$ShopId.'&dir=file&filetype=xls\',
					afterUpload : function(data) {
						if (data.error === 0) {
							var url = K.formatUrl(data.url, \'absolute\');
							K(\'#it618_name_dao\').val(url);
						} else {
							alert(data.message);
						}
					},
					afterError : function(str) {
						alert(str);
					}
				});
				uploadbutton.fileBox.change(function(e) {
					uploadbutton.submit();
				});
			});
</script>';

it618_showformheader("plugin.php?id=it618_video:sc_product_video_dao$adminsid&lid=$lid");
showtableheaders('','it618_video_goods');

echo '
<tr><td colspan=14 style="line-height:26px">'.$it618_video_lang['s1987'].'</td></tr>
<tr><td colspan=14><input id="it618_name_dao" name="it618_name_dao" class="txt" style="width:300px" value=""><input type="submit" class="btn" id="btn_upfile" value="'.$it618_video_lang['s1989'].'"/>
<br><input type="submit" class="btn" name="it618submit_dao" onclick="return checkvalue()" value="'.$it618_video_lang['s1990'].'"/></td></tr>
<script>
function checkvalue(){
	if(confirm(\''.$it618_video_lang['s1991'].'\')){
		if(document.getElementById("it618_name_dao").value==""){
			alert("'.$it618_video_lang['s1992'].'");
			return false;
		}
	}else{
		return false;
	}
}
</script>
';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>