<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_video;

$it618_video = $_G['cache']['plugin']['it618_video'];
$metatitle = $it618_video['seotitle'];

require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

if($it618_video_goods_video_audio=C::t('#it618_video#it618_video_goods_video_audio')->fetch_by_id($_GET['aid'])){
	$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($it618_video_goods_video_audio['it618_vid']);
	$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_video['it618_pid']);
	$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
	
	$isgoodsprice=0;
	if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
		$isgoodsprice=1;
	}
	
	if($it618_video_goods_video['it618_isuser']==0){
		$isok=1;
	}
	
	if($it618_video_goods_video['it618_isuser']==2){
		if($_G['uid']>0){
			$isok=1;
		}else{
			$btnstr=$it618_video_lang['t204'];
		}
	}
	
	if($it618_video_goods_video['it618_isuser']==1){
		$btnstr=$it618_video_lang['t263'];
		if($isgoodsprice>0){
			$videopower=it618_video_getpower($_G['uid'],$it618_video_goods_video['it618_pid'],$it618_video_goods_video['it618_lid'],$it618_video_goods_video['id']);
			if($videopower['state']>0){
				$isok=1;
			}else{
				$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
				if(count($vipgroupids)>0){
					if($_G['uid']>0){
						if(count($vipgroupids)>0){
							$tmpgrouparr=it618_video_getisvipuser($vipgroupids);
							$isvipuser=count($tmpgrouparr[0]);
						}
					}
					if($isvipuser>0){
						$isok=1;
					}else{
						if($_G['uid']>0){
							$btnstr=$it618_video_lang['t260'];
						}else{
							$btnstr=$it618_video_lang['t419'];
						}
					}
				}
			}
		}else{
			$isok=1;
		}
		
		if($_G['uid']>0){
			if($_G['uid']==$it618_video_shop['it618_uid']){
				$isok=1;
			}
		}
	}
	
	if($isok!=1){
		echo $btnstr;
		exit;
	}
	
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_video_audio')." WHERE it618_vid=".$it618_video_goods_video_audio['it618_vid']);
	
	$name=it618_video_gbktoutf($it618_video_goods_video_audio['it618_name']);
	$url=it618_video_getsignedurl($it618_video_goods_video_audio['it618_videourl']);
	$urlext=pathinfo($url, PATHINFO_EXTENSION);
	$tmparr=explode("?",$urlext);
	$urlext=$tmparr[0];
}else{
	echo $it618_video_lang['s513'];
	exit;
}

$_G['mobiletpl'][2]='/';
include template('it618_video:audio');
?>