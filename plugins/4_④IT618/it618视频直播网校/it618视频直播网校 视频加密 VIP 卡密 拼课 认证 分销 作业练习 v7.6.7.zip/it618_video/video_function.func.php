<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_video = $_G['cache']['plugin']['it618_video'];
$metatitle = $it618_video['seotitle'];
$metakeywords = $it618_video['seokeywords'];
$metadescription = $it618_video['seodescription'];
$creditname=$_G['setting']['extcredits'][$it618_video['video_credit']]['title'];
require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

$hotclassgoods=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('hotclassgoods');
$hotclassgoods=explode('@@@',$hotclassgoods);

if($templatename=='mall'&&$pagetype=='index'){
	$tmpidsarr=explode(',',$hotclassgoods[0]);
	for($i=0;$i<count($tmpidsarr);$i++){
		$id=intval($tmpidsarr[$i]);
		$it618_video_class2=C::t('#it618_video#it618_video_class2')->fetch_by_id($id);
		$tmpurl=it618_video_getrewrite('video_list',$it618_video_class2['it618_class1_id'].'@'.$id,'plugin.php?id=it618_video:list&class1='.$it618_video_class2['it618_class1_id'].'&class2='.$id);
		$homehotclass.='<li><a href="'.$tmpurl.'">'.$it618_video_class2['it618_classname'].'</a></li>';
	}
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_gonggao')." where it618_order<>0 ORDER BY it618_order");
	while($it618_video_gonggao = DB::fetch($query)) {
		$it618_title=$it618_video_gonggao['it618_title'];
		$it618_title=cutstr($it618_title,110,'...');
		
		if($it618_video_gonggao['it618_isbold']==1){
			$it618_title='<b>'.$it618_title.'</b>';
		}
		
		if($it618_video_gonggao['it618_color']!=''){
			$it618_title='<font color="'.$it618_video_gonggao['it618_color'].'">'.$it618_title.'</font>';
		}
		
		$str_gonggao.='<tr><td><a href="'.$it618_video_gonggao['it618_url'].'" target="_blank" title="'.$it618_video_gonggao['it618_title'].'"><div>'.$it618_title.'</div></a></td></tr>';
	}
	
	foreach(C::t('#it618_video#it618_video_focus')->fetch_all_by_type_order(17) as $it618_video_focus) {
		if($it618_video_focus['it618_url']!=''){
			$str_focus.='<li class="swiper-slide"><a href="'.$it618_video_focus['it618_url'].'" target="_blank"><img src="'.$it618_video_focus['it618_img'].'" width="940" height="358" /></a></li>';
		}else{
			$str_focus.='<li class="swiper-slide"><img src="'.$it618_video_focus['it618_img'].'" width="940" height="358" /></li>';
		}
	}
	
	foreach(C::t('#it618_video#it618_video_focus')->fetch_all_by_type_order(2) as $it618_video_focus) {
		if($it618_video_focus['it618_url']!=''){
			$str_focus2.='<li class="swiper-slide"><a href="'.$it618_video_focus['it618_url'].'" target="_blank"><img src="'.$it618_video_focus['it618_img'].'" width="1200" height="63" /></a></li>';
		}else{
			$str_focus2.='<li class="swiper-slide"><img src="'.$it618_video_focus['it618_img'].'" width="1200" height="63" /></li>';
		}
	}
	
	foreach(C::t('#it618_video#it618_video_focus')->fetch_all_by_type_order(3) as $it618_video_focus) {
		if($it618_video_focus['it618_url']!=''){
			$str_focus3.='<li class="swiper-slide"><a href="'.$it618_video_focus['it618_url'].'" target="_blank"><img src="'.$it618_video_focus['it618_img'].'" width="223" height="231" /></a></li>';
		}else{
			$str_focus3.='<li class="swiper-slide"><img src="'.$it618_video_focus['it618_img'].'" width="223" height="231" /></li>';
		}
	}
	
	foreach(C::t('#it618_video#it618_video_focus')->fetch_all_by_type_order(4) as $it618_video_focus) {
		if($it618_video_focus['it618_url']!=''){
			$str_focus4.='<li class="swiper-slide"><a href="'.$it618_video_focus['it618_url'].'" target="_blank"><img src="'.$it618_video_focus['it618_img'].'" width="223" height="231" /></a></li>';
		}else{
			$str_focus4.='<li class="swiper-slide"><img src="'.$it618_video_focus['it618_img'].'" width="223" height="231" /></li>';
		}
	}
}

if($pagetype=='index'){
	$zjsalegoods=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('zjsalegoods');
	$weeksalegoods=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('weeksalegoods');
	$newgoods=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('newgoods');
	$hotgoods=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('hotgoods');
	
	$tmparr=explode(",",$zjsalegoods);
	if(count($tmparr)>2){
		$zjsalegoods_count=$tmparr[0];
		$zjsalegoods_order=$tmparr[2];
	}else{
		$zjsalegoods_count=15;
		$zjsalegoods_order=3;
	}
	
	$tmparr=explode(",",$weeksalegoods);
	if(count($tmparr)>2){
		$weeksalegoods_count=$tmparr[0];
		$weeksalegoods_order=$tmparr[2];
	}else{
		$weeksalegoods_count=15;
		$weeksalegoods_order=4;
	}
	
	$tmparr=explode(",",$newgoods);
	if(count($tmparr)>2){
		$newgoods_count=$tmparr[0];
		$newgoods_order=$tmparr[2];
	}else{
		$newgoods_count=15;
		$newgoods_order=1;
	}
	
	$tmparr=explode(",",$hotgoods);
	if(count($tmparr)>2){
		$hotgoods_count=$tmparr[0];
		$hotgoods_order=$tmparr[2];
	}else{
		$hotgoods_count=15;
		$hotgoods_order=2;
	}
	
	$homegoods_arr=array("zjsalegoods"=>$zjsalegoods_order,"weeksalegoods"=>$weeksalegoods_order,"newgoods"=>$newgoods_order,"hotgoods"=>$hotgoods_order);
	asort($homegoods_arr);
	
	$n=1;
	foreach($homegoods_arr as $key=>$homegoods){
		if($n==1)$current=' class="current" ';else $current=' ';
		if($key=='zjsalegoods'){
			if($IsPinEdu==1){
				$it618_video_lang['t91']=$it618_video_lang['s593'];
				$it618_video_lang['t90']=$it618_video_lang['s595'];
			}
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-rc-new"),\'rc-new\');get_home_goods(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-rc-new" onclick="tabCutover(this,\'rc-new\');get_home_goods(\''.$key.'\');" title="'.$it618_video_lang['t90'].'">'.$it618_video_lang['t91'].'<i></i></span>';
		}
		
		if($key=='weeksalegoods'){
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-rc-week"),\'re-week\');get_home_goods(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-rc-week" onclick="tabCutover(this,\'re-week\');get_home_goods(\''.$key.'\');" title="'.$it618_video_lang['t92'].'">'.$it618_video_lang['t93'].'<i></i></span>';
		}
		
		if($key=='newgoods'){
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-re-newjf"),\'re-newjf\');get_home_goods(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-re-newjf" onclick="tabCutover(this,\'re-newjf\');get_home_goods(\''.$key.'\');" title="'.$it618_video_lang['t312'].'">'.$it618_video_lang['s989'].'<i></i></span>';
		}
		
		if($key=='hotgoods'){
			if($n==1)$homegoods_js='<script type="text/javascript">tabCutover(document.getElementById("span-re-hotjf"),\'re-hotjf\');get_home_goods(\''.$key.'\');</script>';
			$tab_goods.='<span'.$current.' id="span-re-hotjf" onclick="tabCutover(this,\'re-hotjf\');get_home_goods(\''.$key.'\');" title="'.$it618_video_lang['t313'].'">'.$it618_video_lang['s990'].'<i></i></span>';
		}
		$n=$n+1;
	
		if($key=='zjsalegoods'){
			$home_goods.='<div class="rc-new" id="home_goods_'.$key.'"></div>';
		}
		
		if($key=='weeksalegoods'){
			$home_goods.='<div class="re-week" id="home_goods_'.$key.'"></div>';
		}
		
		if($key=='newgoods'){
			$home_goods.='<div class="re-newjf" id="home_goods_'.$key.'"></div>';
		}
		
		if($key=='hotgoods'){
			$home_goods.='<div class="re-hotjf" id="home_goods_'.$key.'"></div>';
		}
	}
	
	$homegoods_str='<div class="recommend-goods">
			<div class="recommend-title">
				'.$tab_goods.'
			</div>
			<div class="recommend-content">
				'.$home_goods.'
			</div>
			</div>';
}

if($templatename=='edu'&&$pagetype=='index'){
	$i=1;
	foreach(C::t('#it618_video#it618_video_focus')->fetch_all_by_type_order(18) as $it618_video_focus) {
		$indexfocuscss.='.main_image li .img_'.$i.'{background:url(\''.$it618_video_focus['it618_img'].'\') center top no-repeat}';
		
		
		$indexfocusem.='<em></em>';
		
		if($it618_video_focus['it618_url']!=''){
			$indexfocusimg.='<li><a href="'.$it618_video_focus['it618_url'].'" target="_blank"><span class="img_'.$i.'"></span></a></li>';
		}else{
			$indexfocusimg.='<li><span class="img_'.$i.'"></span></li>';
		}
		$i=$i+1;
	}
}

if($templatename=='mall'&&$pagetype=='product'){
	foreach(C::t('#it618_video#it618_video_focus')->fetch_all_by_type_order(6) as $it618_video_focus) {
		if($it618_video_focus['it618_url']!=''){
			$str_focus6.='<li><a href="'.$it618_video_focus['it618_url'].'" target="_blank"><img src="'.$it618_video_focus['it618_img'].'" width="223" height="180" /></a></li>';
		}else{
			$str_focus6.='<li><img src="'.$it618_video_focus['it618_img'].'" width="223" height="180" /></li>';
		}
	}
}

if($templatename=='mall'&&($pagetype=='list'||$pagetype=='search')){
	foreach(C::t('#it618_video#it618_video_focus')->fetch_all_by_type_order(5) as $it618_video_focus) {
		if($it618_video_focus['it618_url']!=''){
			$str_focus5.='<li><a href="'.$it618_video_focus['it618_url'].'" target="_blank"><img src="'.$it618_video_focus['it618_img'].'" width="223" height="180" /></a></li>';
		}else{
			$str_focus5.='<li><img src="'.$it618_video_focus['it618_img'].'" width="223" height="180" /></li>';
		}
	}
}
?>