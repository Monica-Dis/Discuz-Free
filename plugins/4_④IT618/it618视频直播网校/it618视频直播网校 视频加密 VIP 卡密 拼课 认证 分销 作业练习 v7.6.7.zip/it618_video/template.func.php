<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$it618_video;

$it618_video = $_G['cache']['plugin']['it618_video'];
$creditname=$_G['setting']['extcredits'][$it618_video['video_credit']]['title'];
require_once DISCUZ_ROOT.'./source/plugin/it618_video/lang.func.php';

function it618_video_template_pchomehotgoods($templatename,$hotclassgoods){
	global $_G,$it618_video,$it618_video_lang,$creditname;

	if($templatename=='mall'){
		
		$tmpidsarr=explode(',',$hotclassgoods);
		$n=1;
		for($i=1;$i<=count($tmpidsarr);$i++){
			$id=intval($tmpidsarr[$i-1]);
			$it618sql='g.it618_state=1 and g.id='.$id;
			foreach(C::t('#it618_video#it618_video_goods')->fetch_all_by_search(
				$it618sql,'',0,0,0,'',0,0,0,0
			) as $it618_video_goods) {
				$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
				
				$pricestr='<span class="price" style="color:#f60;font-size:20px">'.$it618_video_lang['s1534'].'</span>';
				if($it618_video_shop['it618_issale']==1){
					if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
						$pricestr='<span class="price" style="padding:0;padding-right:3px">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
					}else{
						$pricestr='<span class="price" style="color:#390;font-size:20px">'.$it618_video_lang['s106'].'</span>';
					}
				}
				
				$it618_isvip='';
				$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
				if(count($vipgroupids)>0){
					$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
				}
				
				$it618_islive='';
				if(C::t('#it618_video#it618_video_live')->count_by_pid_ok($it618_video_goods['id'])>0){
					$it618_islive='<img src="source/plugin/it618_video/images/live.gif" class="imglive">';
				}
				
				$jfbl='';
				if($it618_video_goods['it618_jfbl']>0&&$it618_video_goods['it618_saleprice']>0){
					//$jfbl='<div class="divjfbl">'.$it618_video_lang['s1371'].str_replace(".00","",$it618_video_goods['it618_jfbl']).'%'.$creditname.'</div>';
				}
				
				$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
		
				$homehotgoods.='<div class="index-goods">
									'.$jfbl.$it618_islive.'
									<a class="index-goods-img" href="'.$tmpurl.'" target="_blank">
										<img class="dynload lsSwitchload" imgsrc="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" src="source/plugin/it618_video/images/a.gif" alt="'.$it618_video_goods['it618_name'].'"/>
										<span class="index-goods-place" title="'.$it618_video_shop['it618_about'].'">'.$it618_video_shop['it618_name'].'<br>'.cutstr($it618_video_shop['it618_about'],40,'...').'</span>
									</a>
									<h3>
										<a class="index-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'">'.$it618_video_goods['it618_name'].'</a>
										<a class="index-goods-text" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_description'].'">'.$it618_video_goods['it618_description'].'</a>
										<span style="color:#999;line-height:35px;font-weight:normal;font-size:12px"><span style="float:right"><font color=red>'.$it618_video_goods['it618_plays'].'</font>'.it618_video_getlang('s931').'</span>'.$it618_isvip.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'</span>
									</h3>
									<div class="index-goods-info">
										'.$pricestr.'
									</div>
								</div>';
				$n=$n+1;
				
				if($n>8)return $homehotgoods;
			}
		}
	}
	
	if($templatename=='edu'){
		
		$tmpidsarr=explode(',',$hotclassgoods);
		$n=1;
		for($i=1;$i<=count($tmpidsarr);$i++){
			$id=intval($tmpidsarr[$i-1]);
			$it618sql='g.it618_state=1 and g.id='.$id;
			foreach(C::t('#it618_video#it618_video_goods')->fetch_all_by_search(
				$it618sql,'',0,0,0,'',0,0,0,0
			) as $it618_video_goods) {
				$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
				
				$pricestr='<span style="color:#f60;font-size:13px">'.$it618_video_lang['s1534'].'</span>';
				if($it618_video_shop['it618_issale']==1){
					if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
						$pricestr='<span class="price">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
					}else{
						$pricestr='<span style="color:#390;">'.$it618_video_lang['s106'].'</span>';
					}
				}
				
				$it618_isvip='';
				$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
				if(count($vipgroupids)>0){
					$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
				}
				
				$it618_islive='';
				if(C::t('#it618_video#it618_video_live')->count_by_pid_ok($it618_video_goods['id'])>0){
					$it618_islive='<img src="source/plugin/it618_video/images/live.gif" class="imglive">';
				}
				
				$jfbl='';
				if($it618_video_goods['it618_jfbl']>0&&$it618_video_goods['it618_saleprice']>0){
					//$jfbl='<div class="divjfbl">'.$it618_video_lang['s1371'].str_replace(".00","",$it618_video_goods['it618_jfbl']).'%'.$creditname.'</div>';
				}
				
				$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
				$homehotgoods.='<div class="course-card" title="'.$it618_video_goods['it618_name'].'">
									'.$jfbl.$it618_islive.'
									<div class="course-img">
										<a href="'.$tmpurl.'" target="_blank"><img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" alt="'.$it618_video_goods['it618_name'].'" class="goodsimg"></a>
										<div class="course-name">
											<a href="'.$tmpurl.'" target="_blank">'.cutstr($it618_video_goods['it618_name'],48,'...').'</a>
										</div>
										<div class="course-author">
											'.$it618_isvip.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'
											<a href="'.$tmpurl.'" target="_blank" title="'.$it618_video_shop['it618_name'].'">'.cutstr($it618_video_shop['it618_name'],14,'...').'</a>
										</div>
										<div class="course-price">
											'.$pricestr.'
											<span class="course-plays">'.$it618_video_goods['it618_plays'].''.it618_video_getlang('s931').'</span>
										</div>
									</div>
								</div>';
			}
		}
	}
	
	return $homehotgoods;
}

function it618_video_template_pchomeclassgoods($templatename){
	global $_G,$it618_video,$it618_video_lang,$creditname;

	if($templatename=='mall'){
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_class1')." ORDER BY it618_order");
		while($it618_video_class1 = DB::fetch($query1)) {
			
			if($it618_video_class1['it618_goodscount']==0)continue;
			
			$tmpurl=it618_video_getrewrite('video_list',$it618_video_class1['id'],'plugin.php?id=it618_video:list&class1='.$it618_video_class1['id']);
			$str_goods.='<div class="index-floor">
							<h2 class="index-floor-title">
								<a href="'.$tmpurl.'">'.$it618_video_class1['it618_classname'].'</a>
								<div class="fr">
									{it618classtj}
									<a href="'.$tmpurl.'" target="_blank">'.it618_video_getlang('s466').'&nbsp;<em>&gt;&gt;</em></a>
								</div>
							</h2>
							<div class="index-goods-list cl">
								{it618goods}
							</div>
							<div class="floor-more"><a href="'.$tmpurl.'">'.it618_video_getlang('s467').$it618_video_class1['it618_classname'].'&nbsp;&gt;&gt;</a></div>
						</div>';

			$query2 = DB::query("SELECT * FROM ".DB::table('it618_video_class2')." where it618_class1_id=".$it618_video_class1['id']." ORDER BY it618_order");
			$it618classtj='';
			while($it618_video_class2 = DB::fetch($query2)) {
				if($it618_video_class2['it618_color']!="")
				$tmpname='<font color='.$it618_video_class2['it618_color'].'>'.cutstr($it618_video_class2['it618_classname'],12,'...').'</font>';else $tmpname=cutstr($it618_video_class2['it618_classname'],12,'...');
				
				$tmpurl=it618_video_getrewrite('video_list',$it618_video_class1['id'].'@'.$it618_video_class2['id'],'plugin.php?id=it618_video:list&class1='.$it618_video_class1['id'].'&class2='.$it618_video_class2['id']);
				if($it618_video_class2['it618_istj']==1)$it618classtj.='<a href="'.$tmpurl.'" target="_blank" title="'.$it618_video_class2['it618_classname'].'">'.$tmpname.'</a><span></span>';
		
			}
			
			$it618goods='';
			foreach(C::t('#it618_video#it618_video_goods')->fetch_all_by_search(
				'g.it618_state=1','g.it618_order desc,g.id desc',0,$it618_video_class1['id'],0,'',0,0,$startlimit,$it618_video_class1['it618_goodscount']*4
			) as $it618_video_goods) {
				$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
				
				$pricestr='<span class="price" style="color:#f60;font-size:20px">'.$it618_video_lang['s1534'].'</span>';
				if($it618_video_shop['it618_issale']==1){
					if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
						$pricestr='<span class="price" style="padding:0;padding-right:3px">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
					}else{
						$pricestr='<span class="price" style="color:#390;font-size:20px">'.$it618_video_lang['s106'].'</span>';
					}
				}
				
				$it618_isvip='';
				$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
				if(count($vipgroupids)>0){
					$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
				}
				
				$it618_islive='';
				if(C::t('#it618_video#it618_video_live')->count_by_pid_ok($it618_video_goods['id'])>0){
					$it618_islive='<img src="source/plugin/it618_video/images/live.gif" class="imglive">';
				}
				
				$jfbl='';
				if($it618_video_goods['it618_jfbl']>0&&$it618_video_goods['it618_saleprice']>0){
					//$jfbl='<div class="divjfbl">'.$it618_video_lang['s1371'].str_replace(".00","",$it618_video_goods['it618_jfbl']).'%'.$creditname.'</div>';
				}
				
				$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
		
				$it618goods.='<div class="index-goods">
									'.$jfbl.$it618_islive.'
									<a class="index-goods-img" href="'.$tmpurl.'" target="_blank">
										<img class="dynload lsSwitchload" imgsrc="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" src="source/plugin/it618_video/images/a.gif" alt="'.$it618_video_goods['it618_name'].'"/>
										<span class="index-goods-place" title="'.$it618_video_shop['it618_about'].'">'.$it618_video_shop['it618_name'].'<br>'.cutstr($it618_video_shop['it618_about'],40,'...').'</span>
									</a>
									<h3>
										<a class="index-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'">'.$it618_video_goods['it618_name'].'</a>
										<a class="index-goods-text" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_description'].'">'.$it618_video_goods['it618_description'].'</a>
										<span style="color:#999;line-height:35px;font-weight:normal;font-size:12px"><span style="float:right"><font color=red>'.$it618_video_goods['it618_plays'].'</font>'.it618_video_getlang('s931').'</span>'.$it618_isvip.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'</span>
									</h3>
									<div class="index-goods-info">
										'.$pricestr.'
									</div>
								</div>';
				
			}
			
			$str_goods=str_replace("{it618classtj}",$it618classtj,$str_goods);
			$str_goods=str_replace("{it618goods}",$it618goods,$str_goods);
		}
	}
	
	if($templatename=='edu'){
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_class1')." ORDER BY it618_order");
		while($it618_video_class1 = DB::fetch($query1)) {
			
			if($it618_video_class1['it618_goodscount']==0)continue;
			
			$tmpurl=it618_video_getrewrite('video_list',$it618_video_class1['id'],'plugin.php?id=it618_video:list&class1='.$it618_video_class1['id']);
			$str_goods.='<div class="content">
							  <div class="content-c">
								  <div class="homemoddiv">
									  <div class="homemodtitle">
										  <h3><a href="'.$tmpurl.'">'.$it618_video_class1['it618_classname'].'</a></h3>
									  </div>
									  {it618goods}
								  </div>
						  
							  </div>
						  </div>';
			
			$it618goods='';
			foreach(C::t('#it618_video#it618_video_goods')->fetch_all_by_search(
				'g.it618_state=1','g.it618_order desc,g.id desc',0,$it618_video_class1['id'],0,'',0,0,$startlimit,$it618_video_class1['it618_goodscount']*5
			) as $it618_video_goods) {
				$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
				
				$pricestr='<span style="color:#f60;font-size:13px">'.$it618_video_lang['s1534'].'</span>';
				if($it618_video_shop['it618_issale']==1){
					if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
						$pricestr='<span class="price">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
					}else{
						$pricestr='<span style="color:#390;">'.$it618_video_lang['s106'].'</span>';
					}
				}
				
				$it618_isvip='';
				$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
				if(count($vipgroupids)>0){
					$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
				}
				
				$it618_islive='';
				if(C::t('#it618_video#it618_video_live')->count_by_pid_ok($it618_video_goods['id'])>0){
					$it618_islive='<img src="source/plugin/it618_video/images/live.gif" class="imglive">';
				}
				
				$jfbl='';
				if($it618_video_goods['it618_jfbl']>0&&$it618_video_goods['it618_saleprice']>0){
					//$jfbl='<div class="divjfbl">'.$it618_video_lang['s1371'].str_replace(".00","",$it618_video_goods['it618_jfbl']).'%'.$creditname.'</div>';
				}
				
				$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
				$it618goods.='<div class="course-card" title="'.$it618_video_goods['it618_name'].'">
									'.$jfbl.$it618_islive.'
									<div class="course-img">
										<a href="'.$tmpurl.'" target="_blank"><img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" alt="'.$it618_video_goods['it618_name'].'" class="goodsimg"></a>
										<div class="course-name">
											<a href="'.$tmpurl.'" target="_blank">'.cutstr($it618_video_goods['it618_name'],48,'...').'</a>
										</div>
										<div class="course-author">
											'.$it618_isvip.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'
											<a href="'.$tmpurl.'" target="_blank" title="'.$it618_video_shop['it618_name'].'">'.cutstr($it618_video_shop['it618_name'],14,'...').'</a>
										</div>
										<div class="course-price">
											'.$pricestr.'
											<span class="course-plays">'.$it618_video_goods['it618_plays'].''.it618_video_getlang('s931').'</span>
										</div>
									</div>
								</div>';
			}
			
			$str_goods=str_replace("{it618goods}",$it618goods,$str_goods);
		}
	}
	
	return $str_goods;
}

function it618_video_template_pcpagetjgoods($templatename,$shopid){
	global $_G,$it618_video,$it618_video_lang;

	if($templatename=='mall'){
		
		$it618sql='g.it618_state=1';
		foreach(C::t('#it618_video#it618_video_goods')->fetch_all_by_search(
			$it618sql,'g.it618_shoporder desc,g.it618_plays desc',$shopid,0,0,'',0,0,0,5
		) as $it618_video_goods) {
			
			$tmppids[]=$it618_video_goods['id'];
			
			$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
			
			$pricestr='<span class="price" style="color:#f60;font-size:20px">'.$it618_video_lang['s1534'].'</span>';
			if($it618_video_shop['it618_issale']==1){
				if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
					$pricestr='<span class="price" style="padding:0;padding-right:3px">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
				}else{
					$pricestr='<span class="price" style="color:#390;font-size:20px">'.$it618_video_lang['s106'].'</span>';
				}
			}
			
			$it618_isviptmp='';
			$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
			if(count($vipgroupids)>0){
				$it618_isviptmp='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
			}
			
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
			$tjgoods.='<div class="small-goods">
						<a class="small-goods-img" href="'.$tmpurl.'" target="_blank"><img class="dynload" src="source/plugin/it618_video/images/a.gif" imgsrc="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" alt="'.$it618_video_goods['it618_name'].'" width="198" height="118"></a>
						<h4>
							<a class="small-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'">'.$it618_video_goods['it618_name'].'</a>
							<a class="small-goods-text" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_description'].'">'.$it618_video_goods['it618_description'].'</a>
							<span style="color:#999;line-height:35px;font-weight:normal;font-size:12px"><span style="float:right"><font color=red>'.$it618_video_goods['it618_plays'].'</font>'.it618_video_getlang('s931').'</span>'.$it618_isvip.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'</span>
						</h4>
						<div class="small-goods-info">
							'.$pricestr.'
						</div>
					</div>';
		}
		
		$it618sql='g.it618_state=1';
		foreach(C::t('#it618_video#it618_video_goods')->fetch_all_by_search(
			$it618sql,'rand()',$shopid,0,0,'',0,0,0,5
		) as $it618_video_goods) {
			
			if(in_array($it618_video_goods['id'], $tmppids)){
				continue;
			}
			
			if($n==5){
				break;
			}
			
			$n=$n+1;
			
			$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
			
			$pricestr='<span class="price" style="color:#f60;font-size:20px">'.$it618_video_lang['s1534'].'</span>';
			if($it618_video_shop['it618_issale']==1){
				if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
					$pricestr='<span class="price" style="padding:0;padding-right:3px">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
				}else{
					$pricestr='<span class="price" style="color:#390;font-size:20px">'.$it618_video_lang['s106'].'</span>';
				}
			}
			
			$it618_isviptmp='';
			$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
			if(count($vipgroupids)>0){
				$it618_isviptmp='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
			}
			
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
			$roundgoods.='<div class="small-goods">
						<a class="small-goods-img" href="'.$tmpurl.'" target="_blank"><img class="dynload" src="source/plugin/it618_video/images/a.gif" imgsrc="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" alt="'.$it618_video_goods['it618_name'].'" width="198" height="118"></a>
						<h4>
							<a class="small-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'">'.$it618_video_goods['it618_name'].'</a>
							<a class="small-goods-text" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_description'].'">'.$it618_video_goods['it618_description'].'</a>
							<span style="color:#999;line-height:35px;font-weight:normal;font-size:12px"><span style="float:right"><font color=red>'.$it618_video_goods['it618_plays'].'</font>'.it618_video_getlang('s931').'</span>'.$it618_isvip.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'</span>
						</h4>
						<div class="small-goods-info">
							'.$pricestr.'
						</div>
					</div>';
		}
	}
	
	if($templatename=='edu'){
		
		$it618sql='g.it618_state=1';
		foreach(C::t('#it618_video#it618_video_goods')->fetch_all_by_search(
			$it618sql,'g.it618_shoporder desc,g.it618_plays desc',$shopid,0,0,'',0,0,0,5
		) as $it618_video_goods) {
			
			$tmppids[]=$it618_video_goods['id'];
			
			$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
			
			$pricestr='<span style="color:#f60;font-size:13px">'.$it618_video_lang['s1534'].'</span>';
			if($it618_video_shop['it618_issale']==1){
				if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
					$pricestr='<span class="price">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
				}else{
					$pricestr='<span style="color:#390;">'.$it618_video_lang['s106'].'</span>';
				}
			}
			
			$it618_isvip='';
			$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
			if(count($vipgroupids)>0){
				$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
			}
			
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
			$tjgoods.='<div class="course-card" title="'.$it618_video_goods['it618_name'].'">
								<div class="course-img">
									<a href="'.$tmpurl.'" target="_blank"><img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" alt="'.$it618_video_goods['it618_name'].'" class="goodsimg"></a>
									<div class="course-name">
										<a href="'.$tmpurl.'" target="_blank">'.cutstr($it618_video_goods['it618_name'],48,'...').'</a>
									</div>
									<div class="course-author">
										'.$it618_isvip.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'
									</div>
									<div class="course-price">
										'.$pricestr.'
										<span class="course-plays">'.$it618_video_goods['it618_plays'].''.it618_video_getlang('s931').'</span>
									</div>
								</div>
							</div>';
		}
		
		$it618sql='g.it618_state=1';
		foreach(C::t('#it618_video#it618_video_goods')->fetch_all_by_search(
			$it618sql,'rand()',$shopid,0,0,'',0,0,0,10
		) as $it618_video_goods) {
			
			if(in_array($it618_video_goods['id'], $tmppids)){
				continue;
			}
			
			if($n==5){
				break;
			}
			
			$n=$n+1;
			
			$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
			
			$pricestr='<span style="color:#f60;font-size:13px">'.$it618_video_lang['s1534'].'</span>';
			if($it618_video_shop['it618_issale']==1){
				if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
					$pricestr='<span class="price">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
				}else{
					$pricestr='<span style="color:#390;">'.$it618_video_lang['s106'].'</span>';
				}
			}
			
			$it618_isvip='';
			$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
			if(count($vipgroupids)>0){
				$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
			}
			
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
			$roundgoods.='<div class="course-card" title="'.$it618_video_goods['it618_name'].'">
								<div class="course-img">
									<a href="'.$tmpurl.'" target="_blank"><img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" alt="'.$it618_video_goods['it618_name'].'" class="goodsimg"></a>
									<div class="course-name">
										<a href="'.$tmpurl.'" target="_blank">'.cutstr($it618_video_goods['it618_name'],48,'...').'</a>
									</div>
									<div class="course-author">
										'.$it618_isvip.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'
									</div>
									<div class="course-price">
										'.$pricestr.'
										<span class="course-plays">'.$it618_video_goods['it618_plays'].''.it618_video_getlang('s931').'</span>
									</div>
								</div>
							</div>';
		}
	}
	
	return $tjgoods.'it618_split'.$roundgoods;
}

function it618_video_template_waphomegoods($videostyle){
	global $_G,$it618_video,$template_set,$it618_video_lang;

	$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_class1')." ORDER BY it618_order");
	while($it618_video_class1 = DB::fetch($query1)) {
		
		if($it618_video_class1['it618_wapgoodscount']==0)continue;
		
		$it618goods='';$tdn=1;
		foreach(C::t('#it618_video#it618_video_goods')->fetch_all_by_search(
			'g.it618_state=1','g.it618_order desc,g.id desc',0,$it618_video_class1['id'],0,'',0,0,$startlimit,$it618_video_class1['it618_wapgoodscount']*2
		) as $it618_video_goods) {
		
			$pj=$it618_video_goods['it618_pjpfstr'];
			
			$tmpurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);
			
			$it618_isvip='';
			$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
			if(count($vipgroupids)>0){
				$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" class="imgvip">';
			}
			
			$it618_islive='';
			if(C::t('#it618_video#it618_video_live')->count_by_pid_ok($it618_video_goods['id'])>0){
				$it618_islive='<img src="source/plugin/it618_video/images/live.gif" class="imglive">';
			}
			
			$pricestr='<span style="color:#f30">'.$it618_video_lang['s1534'].'</span>';
			$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
			if($it618_video_shop['it618_issale']==1){
				if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
					$pricestr='<span style="color:#f30">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
				}else{
					$pricestr='<span style="color:#390">'.$it618_video_lang['s106'].'</span>';
				}
			}
			
			if($it618_video_goods['it618_price']>0){
				$pricestr.=' <del>&yen;'.$it618_video_goods['it618_price'].'</del>';
			}
			
			$jfbl='';
			if($it618_video_goods['it618_jfbl']>0&&$it618_video_goods['it618_saleprice']>0){
				//$jfbl='<div class="divjfbl">'.$it618_video_lang['s1371'].str_replace(".00","",$it618_video_goods['it618_jfbl']).'%'.$creditname.'</div>';
			}
			
			if($videostyle=='1'){
			
				$it618goods.='<tr>
								<td class="tdleft">'.$jfbl.$it618_islive.'<a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'"/></a></td>
								<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
										<div class="tdname">'.$it618_video_goods['it618_name'].'</div>
										<div class="tddes">'.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).' '.$it618_video_goods['it618_plays'].it618_video_getlang('s931').'</div>
										<div class="tdprice">'.$it618_isvip.$pricestr.'</div>
									</td>
							  </tr>
							  <tr><td colspan="2" class="tdcolspan"></td></tr>';
			}else{
				if($tdn%2>0){
					$trtmpstr='<tr>';
					$tdstr='class="tdleft"';
				}else{
					$tdstr='class="tdright"';
				}
				
				$trtmpstr.='<td '.$tdstr.'><div class="tddiv">
								<a href="'.$tmpurl.'">
								'.$jfbl.$it618_islive.'
								<div class="divtime">'.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).' <img src="source/plugin/it618_video/images/plays.png" class="imguser">'.$it618_video_goods['it618_plays'].'</div>
								<img class="lazy" data-original="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'"/>
									<div class="tdname">'.$it618_video_goods['it618_name'].'</div>
									<div class="tdprice">'.$it618_isvip.$pricestr.'</div>
								</a></div></td>';
							
				if($tdn%2==0){
					$trtmpstr.='</tr>';
					$it618goods.=$trtmpstr;
				}
				
				$tdn=$tdn+1;
			}
		}
	
		if($videostyle=='1'){
			$tmparr=explode('</tr>',$it618goods);
			if(count($tmparr)>1){
				$it618goods=$it618goods.'@@@';
				$it618goods=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$it618goods);
			}
			$tmpdtheight=13;
		}else{
			$trtmpstr1=$trtmpstr.'@@@';
			$tmparr=explode('</td>@@@',$trtmpstr1);
			if(count($tmparr)>1){
				$trtmpstr=str_replace('<td class="tdleft"','<td class="tdleft tdleft1" style="padding-right:13px"',$trtmpstr.'</tr>');
				$it618goods.=$trtmpstr;
			}
			$tmpdtheight=13;
		}
			
		$tmpurl=it618_video_getrewrite('video_wap','search@'.$it618_video_class1['id'],'plugin.php?id=it618_video:wap&pagetype=search&cid='.$it618_video_class1['id']);
		$str_goods.='<dl class="list" style="margin:0;margin-bottom:10px;">
						<dd><dl style="padding:0">
							<dt style="text-align:left;padding-left:15px;font-size:18px; color:#000; padding-right:15px;background-color:#fff;height:'.$tmpdtheight.'px;padding-top:20px"><p style="float:right;font-size:14px;color:#aaa;font-weight:normal;margin-top:-1px" onclick="location.href=\''.$tmpurl.'\'">'.$it618_video_lang['t301'].$it618_video_lang['s994'].'<img src="source/plugin/it618_video/wap/images/uc_right.png" style="vertical-align:middle;height:21px;margin-top:-3px"></p>'.$it618_video_class1['it618_classname'].'</dt>
							<dd id="dd_goods'.$it618_video_class1['id'].'">
							<table width="100%" class="tablelist'.$videostyle.'">
								'.$it618goods.'
							</table>
							</dd>
						</dl></dd>
					</dl>';
	
	}
	
	return $str_goods;
}
	
?>