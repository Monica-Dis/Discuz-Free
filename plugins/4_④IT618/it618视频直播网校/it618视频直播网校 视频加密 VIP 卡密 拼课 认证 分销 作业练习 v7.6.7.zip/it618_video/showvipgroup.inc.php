<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_video = $_G['cache']['plugin']['it618_video'];

require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

$pid=intval($_GET['pid']);

if(!($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id_state($pid,1))){
	$error=1;
	$errormsg=it618_video_getlang('s470');
}else{
	if(!it618_video_issecretok($it618_video_goods)){
		$error=1;
		$errormsg=it618_video_getlang('s470');
	}
	
	$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
	if($it618_video_shop['it618_state']!=2||$it618_video_shop['it618_htstate']!=1){
		$error=1;
		$errormsg=it618_video_getlang('s470');
	}
}

$vipgroupids_mf=it618_video_getgoodsvipgroupids($it618_video_goods);
$vipgroupids_zk = array();$vipgroupids_sale = array();

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/function.func.php';
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_group_zk')." where it618_shoptype='video' and it618_pid=$pid and it618_zk>0");
	while($it618_group_group_zk = DB::fetch($query)) {
		if(!in_array($it618_group_group_zk['it618_groupid'], $vipgroupids_zk)){
			$vipgroupids_zk[]=$it618_group_group_zk['it618_groupid'];
		}
	}
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_group_group_salepower')." where it618_shoptype='video' and it618_pid=$pid and it618_isok=1");
	while($it618_group_group_salepower = DB::fetch($query)) {
		if(!in_array($it618_group_group_salepower['it618_groupid'], $vipgroupids_sale)){
			$vipgroupids_sale[]=$it618_group_group_salepower['it618_groupid'];
		}
	}
}

$vipgroupids=array_merge($vipgroupids_mf,$vipgroupids_zk,$vipgroupids_sale);

if($_G['uid']>0){
	if(count($vipgroupids)>0){
		$okvipgroupids=it618_video_getisvipuser($vipgroupids);
	}
}

for($i=0;$i<count($vipgroupids);$i++){
	$grouptitle = DB::result_first("SELECT grouptitle FROM ".DB::table('common_usergroup')." where groupid=".$vipgroupids[$i]);
	$payurl='';
	if($IsGroup==1){
		if($it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($vipgroupids[$i])){
			$groupico='<img src="'.$it618_group_group['it618_ico'].'" style="width:23px;vertical-align:middle;margin-top:-1px;margin-right:5px">';

			$groupclassid=$it618_group_group['it618_classid'];
			if($it618_group_goodstmp = DB::fetch_first("SELECT * FROM ".DB::table('it618_group_goods')." where it618_groupid=".$vipgroupids[$i]." and it618_state=1 ORDER BY it618_unit")){
				$payurl=it618_group_getrewrite('group_product',$it618_group_goodstmp['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goodstmp['id']);
			}
		}else{
			$groupico='source/plugin/it618_group/images/vip.png';
			$grouptype = DB::result_first("SELECT type FROM ".DB::table('common_usergroup')." WHERE groupid=".$vipgroupids[$i]);
			if($grouptype=='system'){$groupico='source/plugin/it618_group/images/system.png';}
			if($grouptype=='member'){$groupico='source/plugin/it618_group/images/member.png';}
			$groupico='<img src="'.$groupico.'" style="width:23px;vertical-align:middle;margin-top:-1px;margin-right:5px">';
		}
	}
	
	$grouppaybtn='';
	$tmpstr='<span class="spanpay">'.$it618_video_lang['s1224'].'</span>';
	if(in_array($vipgroupids[$i], $okvipgroupids[0])){
		$grouptime=$okvipgroupids[1][array_search($vipgroupids[$i],$okvipgroupids[0])];
		
		$tmpstr='<span class="spanok">'.$grouptime.'</span>';
		
		if($payurl!=''&&$grouptime!=$it618_video_lang['s1153']){
			$grouppaybtn='<a href="'.$payurl.'" target="_blank" class="grouppaybtn grouppaybtn1">'.$it618_video_lang['s1635'].'</a>';
		}
	}else{
		if($payurl!=''){
			$grouppaybtn='<a href="'.$payurl.'" target="_blank" class="grouppaybtn">'.$it618_video_lang['s1634'].'</a>';
		}
	}
	
	$mfstr='';$zkstr='';$salestr='';
	if(in_array($vipgroupids[$i], $vipgroupids_mf)){
		$mfstr='<font color=#390>'.$it618_video_lang['s1954'].'</font>';
	}
	
	if(in_array($vipgroupids[$i], $vipgroupids_zk)&&$mfstr==''){
		$it618_group_group_zk=C::t('#it618_group#it618_group_group_zk')->fetch_by_groupid_shoptype_pid($vipgroupids[$i],'video',$pid);
		$zk=round(($it618_group_group_zk['it618_zk']/10),2);
		$zkstr=$zk.$it618_video_lang['s1550'];
	}
	
	if(in_array($vipgroupids[$i], $vipgroupids_sale)&&$salestr==''){
		$salestr=$it618_video_lang['s1553'];
	}
	
	$groupstr.='<tr><td>'.$groupico.$grouptitle.'</td><td class="tdpower">'.$zkstr.$mfstr.$salestr.'</td><td>'.$grouppaybtn.''.$tmpstr.'</td></tr>';
}

if($groupclassid>0){
	$classurl=it618_group_getrewrite('group_class',$groupclassid,'plugin.php?id=it618_group:class&cid='.$groupclassid);
}

$_G['mobiletpl'][2]='/';
include template('it618_video:showvipgroup');
?>