<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;

if(isset($_GET['liveid'])){
	require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';
	$liveid=intval($_GET['liveid']);
	
	if(!($it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($liveid))){
		echo it618_video_getlang('s1335');exit;
	}else{
		if($it618_video_live['it618_chkstate']!=1){
			echo it618_video_getlang('s1335');exit;
		}
		
		$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_live['it618_shopid']);
		if($it618_video_shop['it618_state']!=2||$it618_video_shop['it618_htstate']!=1){
			echo it618_video_getlang('s1335');exit;
		}
		
		if($it618_video_shop['it618_uid']!=$_G['uid']){
			echo it618_video_getlang('s1335');exit;
		}
	}
	
	$it618_video_liveset = C::t('#it618_video#it618_video_liveset')->fetch_by_id($it618_video_live['it618_liveset_id']);
	
	if($it618_video_live['it618_chkstate']==1){
		if($it618_video_live['it618_btime']>$_G['timestamp']){
			if($it618_video_live['it618_btime']-$_G['timestamp']<=$it618_video_liveset['it618_copytime']*60){
				$flag=1;
			}
		}
		
		if($it618_video_live['it618_btime']<$_G['timestamp']&&$_G['timestamp']<$it618_video_live['it618_etime']){
			$flag=1;
		}
	}
	
	if($flag==1){
		if($it618_video_live['it618_rtmpcode']==''){
			it618_video_setlivecdn($it618_video_live);
			$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($liveid);
		}
		
		$liveurl='rtmp://'.$it618_video_liveset['it618_pushdomainname'].'/'.$it618_video_liveset['it618_appname'].'/';
		$it618_rtmpcode=$it618_video_live['it618_rtmpcode'];
		
		if($_GET['type']=='A')$url=$liveurl;
		if($_GET['type']=='B')$url=$it618_rtmpcode;
		if($_GET['type']=='C')$url=$liveurl.$it618_rtmpcode;
	}else{
		echo it618_video_getlang('s1335');exit;	
	}
	
}else{
	$tmparr=explode($_G['siteurl'],$_GET['url']);
	if(count($tmparr)==1)exit;
	
	$url=urldecode($_GET['url']);
	$tmparr=explode("&q=",$url);
	if(count($tmparr)>1){
		$url=$tmparr[0].'&q='.urlencode($tmparr[1]);
	}
}

include DISCUZ_ROOT.'./source/plugin/it618_video/phpqrcode.php';

$errorCorrectionLevel = 'L';//�ݴ����� 
$matrixPointSize = 6;//����ͼƬ��С  
QRcode::png($url, false, $errorCorrectionLevel, $matrixPointSize, 2); 
?>