<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsUnion,$IsCredits,$IsChat,$it618_video,$it618_hongbao_lang;

if(video_is_mobile())$wap=1;

if($IsUnion==1&&$pagetype=='lecturer'){
	if($it618_video_shop['it618_issale']==1){
		$sql='it618_ison=1';
		$quancount=C::t('#it618_union#it618_union_quan')->count_by_shoptype_shopid('video',$it618_video_shop['id'],$sql);
		
		if($template_isshoptui==1){
			$tuicount=C::t('#it618_union#it618_union_tui')->count_by_shoptype_shopid('video',$it618_video_shop['id'],$sql);
		}
	}
}

if($IsUnion==1&&$pagetype=='product'){
	$sql='it618_ison=1 and (it618_pids=\'\' or CONCAT(\',\',it618_pids,\',\') like \'%,'.$pid.',%\')';
	$quancount=C::t('#it618_union#it618_union_quan')->count_by_shoptype_shopid('video',$it618_video_goods['it618_shopid'],$sql);
	
	if($quancount>0){
		$shopquanurl=it618_video_getrewrite('video_lecturer',$it618_video_goods['it618_shopid'],'plugin.php?id=it618_video:lecturer&lid='.$it618_video_goods['it618_shopid'].'&quan','?quan');
		
		$union_quanmoney=C::t('#it618_union#it618_union_quan')->fetch_money_by_shoptype_shopid('video',$it618_video_goods['it618_shopid'],$sql,'it618_money desc');
		if($union_quanmoney>0){
			$union_quan=$it618_union_lang['s1584'].$union_quanmoney.$it618_union_lang['s1585'];
		}
		$union_quanmoney=C::t('#it618_union#it618_union_quan')->fetch_mjmoney_by_shoptype_shopid('video',$it618_video_goods['it618_shopid'],$sql,'it618_mjmoney2 desc');
		if($union_quanmoney['it618_mjmoney2']>0){
			$union_quan.=' '.$it618_union_lang['s1582'].$union_quanmoney['it618_mjmoney1'].$it618_union_lang['s1585'].$it618_union_lang['s1583'].$union_quanmoney['it618_mjmoney2'].$it618_union_lang['s1585'];
		}
	}
	
	if($template_ispagetui==1){
		$tuicount=C::t('#it618_union#it618_union_tui')->count_by_shoptype_shopid('video',$it618_video_goods['it618_shopid'],$sql);
		if($tuicount>0){
			$union_tuitcbl=C::t('#it618_union#it618_union_tui')->fetch_tc_by_shoptype_shopid('video',$it618_video_goods['it618_shopid'],$sql,'it618_tcbl desc');
			$union_tuitc=$it618_union_lang['s1580'].str_replace(".00","",$union_tuitcbl).'%'.$it618_union_lang['s1581'];
		}
	}
}

if($IsUnion==1){
	$tuipower=1;
	$tuiuid=intval($_GET['tuiuid']);
	if($tuiuid>0){
		$usercount=DB::result_first("SELECT count(1) FROM ".DB::table('common_member')." WHERE uid=".$tuiuid);
		if($usercount>0){
			if($it618_union['union_yqpowermode']==1||$it618_union['union_yqpowermode']==3){
				$union_tuigroup=(array)unserialize($it618_union['union_tuigroup']);
				
				if($union_tuigroup[0]!=''){
					require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
					$tmpgrouparr=it618_union_getisvipuser($union_tuigroup);
					if(count($tmpgrouparr[0])==0){
						$tuipower=0;
					}
				}
			}
			if($it618_union['union_yqpowermode']==2||$it618_union['union_yqpowermode']==3){
				if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($tuiuid)==0){
					$tuipower=0;
				}
			}
		}
	}
	
	if($tuipower==1){
		if($it618_union['union_cookietime']==0)$union_cookietime=3600;else $union_cookietime=$it618_union['union_cookietime']*3600;
		dsetcookie('it618_union_tuiuid',$tuiuid,$union_cookietime);
	}
}

if($IsPinEdu==1&&$pagetype=='product'){
	require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/function.func.php';
	$shoptype='video';
	$pingoods=it618_pinedu_getpingoods($shoptype,$it618_video_goods['id'],$wap);
	
	if($pingoods['pinstr']!=''){
		$ispinok=1;
		$jqueryname='IT618_VIDEO';
		if($wap==1){
			if($_GET['e']!=''){
				$pinurl=$_G['siteurl'].it618_video_getrewrite('video_wap','pin@tmptypeid@tmpspid','plugin.php?id=it618_video:wap&pagetype=pin&cid1=tmptypeid&cid2=tmpspid'.'&e='.$_GET['e'],'?e='.$_GET['e']);
			}else{
				$pinurl=$_G['siteurl'].it618_video_getrewrite('video_wap','pin@tmptypeid@tmpspid','plugin.php?id=it618_video:wap&pagetype=pin&cid1=tmptypeid&cid2=tmpspid');
			}
			
			$tmpmobiletpl=$_G['mobiletpl'][IN_MOBILE];
			$_G['mobiletpl'][2]='/';
			include template('it618_pinedu:pinsale');
			$_G['mobiletpl'][IN_MOBILE]=$tmpmobiletpl;
		}else{
			include template('it618_pinedu:pinsale');
		}
	}
}

if($IsCredits==1){
	$it618_hongbao = $_G['cache']['plugin']['it618_hongbao'];
	
	if(in_array(1,(array)unserialize($it618_hongbao['hongbao_power']))){
		$ishongbao=0;
		if($wap==1){
			if($pagetype=='video'||$pagetype=='search')$ishongbao=1;
		}else{
			if($pagetype=='index'||$pagetype=='list'||$pagetype=='search')$ishongbao=1;
		}
		
		if($ishongbao==1){
			$it618_hbtype='it618_video_admin';
			$tid=0;
			if($it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid($it618_hbtype,$tid)){
				$authorid=$it618_hongbao_main['it618_uid'];
			}else{
				$it618_video = $_G['cache']['plugin']['it618_video'];
				$shopadmin=explode(",",$it618_video['video_shopadmin']);
				if(in_array($_G['uid'],$shopadmin)){
					$authorid=$_G['uid'];
				}
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';
			$_G['mobiletpl'][2]='/';
			include template('it618_hongbao:hongbao');
		}
	}
	
	if(in_array(2,(array)unserialize($it618_hongbao['hongbao_power']))){
		$ishongbao=0;
		if($pagetype=='lecturer')$ishongbao=1;
		
		if($ishongbao==1){
			$it618_hbtype='it618_video_shop';
			$tid=$it618_video_shop['id'];
			if($it618_hongbao_main=C::t('#it618_hongbao#it618_hongbao_main')->fetch_by_it618_type_tid($it618_hbtype,$tid)){
				$authorid=$it618_hongbao_main['it618_uid'];
			}else{
				$shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_id($tid);
				if($_G['uid']==$shoptmp['it618_uid']&&$shoptmp['it618_state']==2&&$shoptmp['it618_htstate']==1){
					$authorid=$_G['uid'];
				}
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_hongbao/lang.func.php';
			$_G['mobiletpl'][2]='/';
			include template('it618_hongbao:hongbao');
		}
	}
}

if($IsChat==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_chat/function.func.php';
	
	$chatplugin='it618_video';
	if($pagetype=='product'){
		$chatsid=$it618_video_goods['it618_shopid'];
	}elseif($pagetype=='lecturer'){
		$chatsid=$ShopId;
	}else{
		$chatsid=0;
	}
	
	if($pagetype=='product')$goodsid=$pid;
	
	$it618_chat_kefu = it618_chat_getkefu($chatplugin,$chatsid,$wap,$goodsid);
}

if(($pagetype=='lecturer'||$pagetype=='product')&&$it618_chat_kefu==''){
	$video_kefu = $it618_video['video_kefu'];
	$video_kefu=explode(",",$video_kefu);

	if($it618_video_shop['it618_kefuqq']!=''){
		$qqarr=explode(",",$it618_video_shop['it618_kefuqq']);
		$qqnamearr=explode(",",$it618_video_shop['it618_kefuqqname']);
		for($i=0;$i<count($qqarr);$i++)
		{
			if($qqarr[$i]!='')$shopqq.='<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$qqarr[$i].'&site=qq&menu=yes"><img border="0" src="source/plugin/it618_video/images/qqbtnsmall.gif" align="absmiddle"/>'.$qqnamearr[$i].'</a> ';
			
			$shoprightqq.='<h3>'.$qqnamearr[$i].'</h3>
			<ul>
				<li><span>'.$it618_video_lang['s1060'].'</span>
				<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin='.$qqarr[$i].'&site=qq&menu=yes"><img border="0" src="source/plugin/it618_video/images/qqbtn.gif" align="absmiddle"/></a>
				</li>
			</ul>';
			
		}
		
	}
}
?>