<?php
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if(count($reabc)!=11)return;

require_once DISCUZ_ROOT.'./source/plugin/it618_video/function/it618_video.func.php';

if($reabc[8]!='d')return;
$ppp = $it618_video['pagecount'];
$page = max(1, intval($_GET['page']));
if($_GET['findbtn']==1)$page=1;
$startlimit = ($page - 1) * $ppp;
$deletes = '';
$extrasql = '';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_tx&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_tx');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_tx' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*dism��taobao��com*/
?>