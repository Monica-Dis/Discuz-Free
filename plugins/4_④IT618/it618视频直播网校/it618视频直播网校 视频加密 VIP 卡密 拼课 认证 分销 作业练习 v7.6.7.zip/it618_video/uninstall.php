<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_video_shop`;

DROP TABLE IF EXISTS `pre_it618_video_nav`;

DROP TABLE IF EXISTS `pre_it618_video_class1`;

DROP TABLE IF EXISTS `pre_it618_video_class2`;

DROP TABLE IF EXISTS `pre_it618_video_class_vipgroup`;

DROP TABLE IF EXISTS `pre_it618_video_focus`;

DROP TABLE IF EXISTS `pre_it618_video_media_class`;

DROP TABLE IF EXISTS `pre_it618_video_media_aclass`;

DROP TABLE IF EXISTS `pre_it618_video_media_tieclass`;

DROP TABLE IF EXISTS `pre_it618_video_media_tie`;

DROP TABLE IF EXISTS `pre_it618_video_tie`;

DROP TABLE IF EXISTS `pre_it618_video_media_shopaoss`;

DROP TABLE IF EXISTS `pre_it618_video_media_aoss`;

DROP TABLE IF EXISTS `pre_it618_video_media_audio`;

DROP TABLE IF EXISTS `pre_it618_video_media_shopwmf`;

DROP TABLE IF EXISTS `pre_it618_video_media_wmf`;

DROP TABLE IF EXISTS `pre_it618_video_media`;

DROP TABLE IF EXISTS `pre_it618_video_media_mts`;

DROP TABLE IF EXISTS `pre_it618_video_shopliveset`;

DROP TABLE IF EXISTS `pre_it618_video_liveset`;

DROP TABLE IF EXISTS `pre_it618_video_live_order`;

DROP TABLE IF EXISTS `pre_it618_video_live`;

DROP TABLE IF EXISTS `pre_it618_video_media_liveclass`;

DROP TABLE IF EXISTS `pre_it618_video_media_live`;

DROP TABLE IF EXISTS `pre_it618_video_goods`;

DROP TABLE IF EXISTS `pre_it618_video_goods_type`;

DROP TABLE IF EXISTS `pre_it618_video_goods_lesson`;

DROP TABLE IF EXISTS `pre_it618_video_goods_video`;

DROP TABLE IF EXISTS `pre_it618_video_goods_video_pl`;

DROP TABLE IF EXISTS `pre_it618_video_goods_video_audio`;

DROP TABLE IF EXISTS `pre_it618_video_goods_data`;

DROP TABLE IF EXISTS `pre_it618_video_play`;

DROP TABLE IF EXISTS `pre_it618_video_error`;

DROP TABLE IF EXISTS `pre_it618_video_play_pj`;

DROP TABLE IF EXISTS `pre_it618_video_play_pjpic`;

DROP TABLE IF EXISTS `pre_it618_video_sale`;

DROP TABLE IF EXISTS `pre_it618_video_goods_km`;

DROP TABLE IF EXISTS `pre_it618_video_salekm`;

DROP TABLE IF EXISTS `pre_it618_video_goods_time`;

DROP TABLE IF EXISTS `pre_it618_video_gwc`;

DROP TABLE IF EXISTS `pre_it618_video_gwcsale_main`;

DROP TABLE IF EXISTS `pre_it618_video_gwcsale`;

DROP TABLE IF EXISTS `pre_it618_video_bank`;

DROP TABLE IF EXISTS `pre_it618_video_txbl`;

DROP TABLE IF EXISTS `pre_it618_video_cdn`;

DROP TABLE IF EXISTS `pre_it618_video_tx`;

DROP TABLE IF EXISTS `pre_it618_video_jfhl`;

DROP TABLE IF EXISTS `pre_it618_video_set`;

DROP TABLE IF EXISTS `pre_it618_video_style`;

DROP TABLE IF EXISTS `pre_it618_video_wapstyle`;

DROP TABLE IF EXISTS `pre_it618_video_iconav`;

DROP TABLE IF EXISTS `pre_it618_video_gonggao`;

DROP TABLE IF EXISTS `pre_it618_video_diy`;

DROP TABLE IF EXISTS `pre_it618_video_findkey`;

DROP TABLE IF EXISTS `pre_it618_video_bottomnav`;

DROP TABLE IF EXISTS `pre_it618_video_videowork`;

DROP TABLE IF EXISTS `pre_it618_video_mediawork`;

DROP TABLE IF EXISTS `pre_it618_video_salework`;

EOF;

runquery($sql);

$cache_file = DISCUZ_ROOT.'./data/sysdata/cache_it618_video.php';
if(file_exists($cache_file)){
	$result=unlink($cache_file);
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>