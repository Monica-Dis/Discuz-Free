<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$videoadmin=getcookie('videoadmin');
if($videoadmin!=1)exit;
require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

$it618_url=$_GET['playurl'];
$tmparr1=explode(".m3u8",$it618_url);
if(count($tmparr1)>1){
	$tmpstr1='m3u8';
	if($it618_video_media_mts=C::t('#it618_video#it618_video_media_mts')->fetch_by_url($it618_url)){
		$it618_video_media=C::t('#it618_video#it618_video_media')->fetch_by_id($it618_video_media_mts['it618_media_id']);
		$it618_video_media_wmf=C::t('#it618_video#it618_video_media_wmf')->fetch_by_id($it618_video_media['it618_wmf_id']);
		dsetcookie('it618_hlskms'.md5($it618_video_media['it618_mediaid'].$it618_video_media_wmf['it618_accesskey']),1,31536000);
	}
	$it618_url=it618_video_cdnkeyurl($it618_url);
}else{
	$it618_url=it618_video_getsignedurl($it618_url);
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php';
}

$player_version=$it618_video_lang['playerversion'];

echo '
<div class="prism-player" id="J_prismPlayer"></div>
<link rel="stylesheet" href="https://g.alicdn.com/de/prismplayer/'.$player_version.'/skins/default/aliplayer-min.css" />
<script type="text/javascript" src="https://g.alicdn.com/de/prismplayer/'.$player_version.'/aliplayer-min.js" charset="utf-8"></script>
<style type="text/css">
  .prism-player .prism-cover{
    background-color:none;
    display:block;
  }
  
  .prism-player .prism-marker-text{
    display:none;
  }
</style>

<script type="text/javascript">
var layout=[
	{
	  "name": "bigPlayButton",
	  "align": "blabs",
	  "x": 345,
	  "y": 180
	},
	{
	  "name": "H5Loading",
	  "align": "cc"
	},
	{
	  "name": "errorDisplay",
	  "align": "tlabs",
	  "x": 0,
	  "y": 0
	},
	{
	  "name": "infoDisplay"
	},
	{
	  "name": "tooltip",
	  "align": "blabs",
	  "x": 0,
	  "y": 56
	},
	{
	  "name": "thumbnail"
	},
	{
	  "name": "controlBar",
	  "align": "blabs",
	  "x": 0,
	  "y": 0,
	  "children": [
		{
		  "name": "progress",
		  "align": "blabs",
		  "x": 0,
		  "y": 44
		},
		{
		  "name": "playButton",
		  "align": "tl",
		  "x": 15,
		  "y": 12
		},
		{
		  "name": "timeDisplay",
		  "align": "tl",
		  "x": 10,
		  "y": 7
		},
		{
		  "name": "fullScreenButton",
		  "align": "tr",
		  "x": 10,
		  "y": 12
		},
		{
		  "name": "setting",
		  "align": "tr",
		  "x": 15,
		  "y": 12
		},
		{
		  "name": "volume",
		  "align": "tr",
		  "x": 5,
		  "y": 10
		}
	  ]
	}
  ];

player = new Aliplayer({
	"id": "J_prismPlayer",
	"source": "'.$it618_url.'",
	"width": "100%",
	"height": "100%",
	"autoplay": true,
	"isLive": false,
	"rePlay": false,
	"playsinline": true,
	"preload": true,
	"controlBarVisibility": "hover",
	"useH5Prism": true,
	"skinLayout": layout,
  }, function (player) {
  }
);
</script>
';
?>