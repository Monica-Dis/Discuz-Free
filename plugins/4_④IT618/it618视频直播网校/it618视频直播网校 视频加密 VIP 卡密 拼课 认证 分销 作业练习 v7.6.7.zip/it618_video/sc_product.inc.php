<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$ppp = 10;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$it618sql = "1";

$state0='';$state1='';$state2='';$state3='';$state4='';$state5='';$state6='';$state7='';
if($_GET['state']==0){$state0='selected="selected"';}
if($_GET['state']==1){$it618sql .= " and g.it618_state = 0";$state1='selected="selected"';}
if($_GET['state']==2){$it618sql .= " and g.it618_state = 1";$state2='selected="selected"';}
if($_GET['state']==3){$it618sql .= " and g.it618_state = 2";$state3='selected="selected"';}
if($_GET['state']==4){$it618sql .= " and g.it618_isvip = 0";$state4='selected="selected"';}
if($_GET['state']==5){$it618sql .= " and g.it618_isvip = 1";$state5='selected="selected"';}
if($_GET['state']==6){$it618sql .= " and g.it618_issecret = 0";$state6='selected="selected"';}
if($_GET['state']==7){$it618sql .= " and g.it618_issecret = 1";$state7='selected="selected"';}

$orderby0='';$orderby1='';$orderby2='';$orderby3='';
if($_GET['orderby']==0){$it618orderby = "g.it618_shoporder desc,id desc";$orderby0='selected="selected"';}
if($_GET['orderby']==1){$it618orderby = "g.it618_salecount desc";$orderby1='selected="selected"';}
if($_GET['orderby']==2){$it618orderby = "g.it618_views desc";$orderby2='selected="selected"';}
if($_GET['orderby']==3){$it618orderby = "g.it618_saleprice desc";$orderby3='selected="selected"';}

$urlsql='&key='.$_GET['key'].'&price1='.$_GET['price1'].'&price2='.$_GET['price2'].'&it618_class1_id='.$_GET['it618_class1_id'].'&it618_class2_id='.$_GET['it618_class2_id'].'&state='.$_GET['state'].'&orderby='.$_GET['orderby'];

$preurl="plugin.php?id=it618_video:sc_product$adminsid".$urlsql."&page=$page";
$preurl=str_replace("&","@",$preurl);

if(submitcheck('it618submit_del')){
	$del=0;
	if($it618_video_shop['it618_isdel']==1){
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			$salecount = C::t('#it618_video#it618_video_sale')->sumcount_by_it618_pid($delid);
			$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($delid);
			if($salecount==0&&$it618_video_goods['it618_videocount']==0){
	
				$tmpurl=$_G['siteurl'].it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
				
				$tmparr=explode("source",$it618_video_goods['it618_picbig']);
				$tmparr1=explode("://",$it618_video_goods['it618_picbig']);
				$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
				
				if(file_exists($it618_picbig)&&count($tmparr1)==1){
					$result=unlink($it618_picbig);
				}
				
				for($i=0;$i<=4;$i++){
					if($i==0)$tmpi='';else $tmpi=$i;
					$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
					
					if($it618_video_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
						$tmparr=explode("source",$it618_video_goods['it618_picbig'.$tmpi]);
						$tmparr1=explode("://",$it618_video_goods['it618_picbig'.$tmpi]);
						$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
						
						if(file_exists($it618_picbig)&&count($tmparr1)==1){
							$result=unlink($it618_picbig);
						}
					}
					
					$file_ext=strtolower(substr($it618_video_goods['it618_picbig'.$tmpi],strrpos($it618_video_goods['it618_picbig'.$tmpi], '.')+1)); 
					$file_extarr=explode("?",$file_ext);
					$file_ext=$file_extarr[0];
					$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/data/shop'.$ShopId.'/smallimage/goods'.$delid.'_'.$i.'.'.$file_ext;
					if(file_exists($it618_smallurl)){
						$result=unlink($it618_smallurl);
					}
				}
				
				C::t('#it618_video#it618_video_goods')->delete_by_id($delid);
				$del=$del+1;
			}else{
				$flag=1;
			}
		}
	}else{
		$del=$it618_video_lang['s1604'];
	}
	
	if($flag==1)$tmpstr='<br><br>'.$it618_video_lang['s1775'];

	it618_cpmsg(it618_video_getlang('s342').$del.$tmpstr, "plugin.php?id=it618_video:sc_product$adminsid&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_on')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($delid);
		if($it618_video_goods['it618_state']==0){
			DB::query("update ".DB::table('it618_video_goods')." set it618_state=1 where id=".$delid);
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_video_getlang('s343').$ok, "plugin.php?id=it618_video:sc_product$adminsid&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_down')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($delid);
		if($it618_video_goods['it618_state']==1){
			DB::query("update ".DB::table('it618_video_goods')." set it618_state=0 where id=".$delid);
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_video_getlang('s344').$ok, "plugin.php?id=it618_video:sc_product$adminsid&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_edit')){
	$ok=0;
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {

			$it618_saleprice=$_GET['it618_saleprice'][$id];
			
			$it618_score=$_GET['it618_score'][$id];
			if($_GET['it618_jfid'][$id]==0)$it618_score=0;
			
			if($Shopisale!=1){
				$it618_saleprice=1;
			}
			
			C::t('#it618_video#it618_video_goods')->update($id,array(
				'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
				'it618_description' => dhtmlspecialchars($_GET['it618_description'][$id]),
				'it618_price' => $_GET['it618_price'][$id],
				'it618_saleprice' => $it618_saleprice,
				'it618_jfid' => $_GET['it618_jfid'][$id],
				'it618_score' => $it618_score,
				'it618_jfbl' => $_GET['it618_jfbl'][$id],
				'it618_xgtype' => $_GET['it618_xgtype'][$id],
				'it618_xgtime1' => dhtmlspecialchars($_GET['it618_xgtime1'][$id]),
				'it618_xgtime2' => dhtmlspecialchars($_GET['it618_xgtime2'][$id]),
				'it618_shoporder' => $_GET['it618_shoporder'][$id],
				'it618_isbm' => $_GET['it618_isbm'][$id],
				'it618_isprotect' => $_GET['it618_isprotect'][$id]
			));
	
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_video_getlang('s345').$ok, "plugin.php?id=it618_video:sc_product$adminsid&page=$page".$urlsql, 'succeed');
}

$tmp='<option value="0">'.it618_video_getlang('s346').'</option>';
$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_class1')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}
$tmp1=str_replace('<option value='.$_GET['it618_class1_id'].'>','<option value='.$_GET['it618_class1_id'].' selected="selected">',$tmp);

if($_GET['it618_class1_id']>0){
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_class2')." where it618_class1_id=".$_GET['it618_class1_id']." ORDER BY it618_order");
	$indextmp=1;
	$index=0;
	while($it618_tmp =	DB::fetch($query)) {
		if($it618_tmp['id']==$_GET['it618_class2_id']){
			$index=$indextmp;
		}
		$indextmp+=1;
	}
	$jstmp.="redirec_class(document.getElementById('it618_class1_id').options.selectedIndex);redirec_class_sel('it618_class2_id',".$index.");";
}

if($Shopisale!=1){
	$issalecss='display:none';
}

it618_showformheader("plugin.php?id=it618_video:sc_product$adminsid&page=$page".$urlsql);
showtableheaders(it618_video_getlang('s349'),'it618_video_sum');
	echo '<tr><td colspan=14>'.it618_video_getlang('s97').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:150px" /><span style="'.$issalecss.'"> '.it618_video_getlang('s98').' <input name="price1" value="'.$_GET['price1'].'" class="txt" style="width:50px;margin-right:0" /> - <input name="price2" value="'.$_GET['price2'].'" class="txt" style="width:50px" /></span> '.it618_video_getlang('s99').' <select id="it618_class1_id" name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex)">'.$tmp1.'</select> <select id="it618_class2_id"  name="it618_class2_id"><option value="0">'.it618_video_getlang('s100').'</option></select> '.it618_video_getlang('s101').' <select name="state"><option value=0 '.$state0.'>'.it618_video_getlang('s102').'</option><option value=1 '.$state1.'>'.it618_video_getlang('s103').'</option><option value=2 '.$state2.'>'.it618_video_getlang('s104').'</option><option value=3 '.$state3.'>'.it618_video_getlang('s105').'</option><option value=4 '.$state4.'>'.$it618_video_lang['s39'].'</option><option value=5 '.$state5.'>'.$it618_video_lang['s40'].'</option><option value=6 '.$state6.'>'.$it618_video_lang['s1176'].'</option><option value=7 '.$state7.'>'.$it618_video_lang['s1177'].'</option></select> <select name="orderby"><option value=0 '.$orderby0.'>'.it618_video_getlang('s110').'</option><option value=1 '.$orderby1.' style="'.$issalecss.'">'.it618_video_getlang('s111').'</option><option value=2 '.$orderby2.'>'.it618_video_getlang('s112').'</option><option value=3 '.$orderby3.' style="'.$issalecss.'">'.it618_video_getlang('s113').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_video_getlang('s350').'" /></td></tr>';
	
	$count = C::t('#it618_video#it618_video_goods')->count_by_search($it618sql,'',$ShopId,$_GET['it618_class1_id'],$_GET['it618_class2_id'],$_GET['key'],$_GET['price1'],$_GET['price2']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_video:sc_product$adminsid".$urlsql);
	
	if($Shopisale==1){
		echo '<tr><td colspan=14>'.it618_video_getlang('s114').$count.'<span style="float:right;">'.it618_video_getlang('s927').'</span></td></tr>';
		showsubtitle(array('',it618_video_getlang('s115'),it618_video_getlang('s116'),it618_video_getlang('t307'),$it618_video_lang['s1047'],it618_video_getlang('s1705')));
	}else{
		echo '<tr><td colspan=14>'.it618_video_getlang('s114').$count.'<span style="float:right;"></span></td></tr>';
		showsubtitle(array('',it618_video_getlang('s115'),it618_video_getlang('s1533'),'','',it618_video_getlang('s1705')));
	}
	
	$n=1;
	foreach(C::t('#it618_video#it618_video_goods')->fetch_all_by_search(
		$it618sql,$it618orderby,$ShopId,$_GET['it618_class1_id'],$_GET['it618_class2_id'],$_GET['key'],$_GET['price1'],$_GET['price2'],$startlimit,$ppp
	) as $it618_video_goods) {
		
		if(C::t('#it618_video#it618_video_goods_lesson')->count_by_pid($it618_video_goods['id'])==0){
			$lid=C::t('#it618_video#it618_video_goods_lesson')->insert(array(
				'it618_pid' => $it618_video_goods['id'],
				'it618_name' => $it618_video_lang['s488']
			), true);
			
			DB::query("update ".DB::table('it618_video_goods_video')." set it618_lid=".$lid." where it618_pid=".$it618_video_goods['id']." and it618_lid=0");
			DB::query("update ".DB::table('it618_video_goods')." set it618_lessoncount=1 where id=".$it618_video_goods['id']);
		}
		
		if($it618_video_goods['it618_isbm']==1)$it618_isbm_checked='checked="checked"';else $it618_isbm_checked="";
		if($it618_video_goods['it618_isprotect']==1)$it618_isprotect_checked='checked="checked"';else $it618_isprotect_checked="";
		
		if($it618_video_goods['it618_state']==0)$it618_state='<input type="checkbox" id="state'.$it618_video_goods['id'].'" onClick="savegoodsstate('.$it618_video_goods['id'].')" class="chk_it618"> <label for="state'.$it618_video_goods['id'].'"></label>';
		if($it618_video_goods['it618_state']==1)$it618_state='<input type="checkbox" id="state'.$it618_video_goods['id'].'" onClick="savegoodsstate('.$it618_video_goods['id'].')" checked="checked" class="chk_it618"> <label for="state'.$it618_video_goods['id'].'"></label>';
		if($it618_video_goods['it618_state']==2)$it618_state='<font color=red>'.it618_video_getlang('s105').'</font>';
		
		if($it618_video_goods['it618_xgtype']==0)$it618_xgtype0=' selected="selected"';else $it618_xgtype0="";
		if($it618_video_goods['it618_xgtype']==1)$it618_xgtype1=' selected="selected"';else $it618_xgtype1="";
		if($it618_video_goods['it618_xgtype']==2)$it618_xgtype2=' selected="selected"';else $it618_xgtype2="";
		
		$salecount = $it618_video_goods['it618_salecount'];
		$salemoney = $it618_video_goods['it618_salemoney'];

		$jfpricecss='display:none';
		if($it618_video_goods['it618_paytype']==1){
			$jfpricecss	= 'display:';
		}
		
		$it618_isvip='';
		$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
		if(count($vipgroupids)>0){
			$it618_isvip='<br><img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-left:15px">';
		}
		
		$it618_issecret='';$secretstr='';
		if($it618_video_goods['it618_issecret']==1){
			$it618_issecret='<br><img src="source/plugin/it618_video/images/secret.png" style="vertical-align:middle;height:18px;margin-left:15px">';
			$secretcount=0;
			if($it618_video_goods['it618_secretusers']!='')$secretcount=count(explode(",",$it618_video_goods['it618_secretusers']));
			$secretstr=' <img src="source/plugin/it618_video/images/bm.png" style="vertical-align:middle;height:16px;margin-top:-1px;margin-right:3px"><a href="javascript:" onclick="showsecret('.$it618_video_goods['id'].')">'.$it618_video_lang['s1564'].'</a> <font color="#888">('.$secretcount.')</font>';
		}
		
		$tmpurl=it618_video_getrewrite('video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
		
		$it618_videotimestr=$it618_video_goods['it618_lessoncount'].$it618_video_lang['s489'].' '.$it618_video_goods['it618_videocount'].$it618_video_lang['s108'].' '.it618_video_getvideotime($it618_video_goods['it618_videotime']);
		
		if($it618_video_goods['it618_gtype']==1){
			$it618_gtype=it618_video_getlang('s380');
		}else{
			$it618_gtype=it618_video_getlang('s386');
		}
		
		if($Shopisale==1){
			$typecountall = C::t('#it618_video#it618_video_goods_type')->counttype_by_pid_lid_vid($it618_video_goods['id'],0,0);
			$typecountok = C::t('#it618_video#it618_video_goods_type')->counttype_by_pid_lid_vid_ok($it618_video_goods['id'],0,0);
			$goodstypestr='<a href="javascript:" onclick="showgoodstype('.$it618_video_goods['id'].',0,0)"><img src="source/plugin/it618_video/images/price.png" style="vertical-align:middle;height:13px;margin-top:-1px;margin-right:3px">'.$it618_video_lang['s710'].'</a> <font color="#888">('.$typecountok.'/'.$typecountall.')</font>';
			
			$goodstypecss='';
			if($typecountok>0){
				$goodstypecss='display:none';
			}
			$issalebr='<br>';
		}else{
			$goodstypecss='display:none';
			$issalecss='display:none';
		}
		
		$redatmpstr='';
		if($it618_video_goods['it618_state']!=1)$redatmpstr='<a href="'.$tmpurl.'" target="_blank">'.it618_video_getlang('t315').'</a>';

		showtablerow('', array('', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_video_goods['id'].'"><label for="chk_del'.$n.'">'.$it618_video_goods['id'].$it618_isvip.$it618_issecret.'</label>',
			'<a style="float:left" href="'.$tmpurl.'" target="_blank"><img src="'.it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']).'" width="133" height="80" align="absmiddle" style="border-radius:3px"/></a><div style="float:left;margin-left:5px;line-height:20px"><input type="text" class="txt" style="width:300px;margin-right:3px;margin-bottom:3px" name="it618_name['.$it618_video_goods['id'].']" value="'.$it618_video_goods['it618_name'].'"><a href="javascript:" onclick="showedit('.$it618_video_goods['id'].')">'.it618_video_getlang('s351').'</a> '.$redatmpstr.'<br><textarea class="txt" style="width:300px;height:51px" name="it618_description['.$it618_video_goods['id'].']">'.$it618_video_goods['it618_description'].'</textarea>'.'</div>',
			'<div style="line-height:28px"><span style="'.$goodstypecss.'"><input type="text" class="txt" style="width:48px;margin-right:3px;color:red;" name="it618_saleprice['.$it618_video_goods['id'].']" value="'.$it618_video_goods['it618_saleprice'].'">'.it618_video_getlang('s125').'+<input type="text" class="txt" style="width:48px;margin-right:3px;;color:red" name="it618_score['.$it618_video_goods['id'].']" value="'.$it618_video_goods['it618_score'].'"><select name="it618_jfid['.$it618_video_goods['id'].']">'.it618_video_getjftype($it618_video_goods['it618_jfid']).'</select> '.$it618_video_lang['s1795'].'<input type="text" class="txt" style="width:48px;margin-right:3px;" name="it618_price['.$it618_video_goods['id'].']" value="'.$it618_video_goods['it618_price'].'">'.it618_video_getlang('s125').'<br></span>'.$goodstypestr.$issalebr.'<a href="plugin.php?id=it618_video:sc_product_lesson'.$adminsid.'&pid='.$it618_video_goods['id'].'&preurl='.$preurl.'"><img src="source/plugin/it618_video/images/zj.png" style="vertical-align:middle;height:12px;margin-top:-1px;margin-right:3px">'.$it618_gtype.'</a> <font color="#888">('.$it618_videotimestr.')</font><br>'.$secretstr.'</div>',
			'<span style="'.$issalecss.'"><select id="it618_xgtype'.$n.'" name="it618_xgtype['.$it618_video_goods['id'].']" style="margin-top:3px"><option value="0"'.$it618_xgtype0.'>'.it618_video_getlang('s944').'</option><option value="1"'.$it618_xgtype1.'>'.it618_video_getlang('s945').'</option><option value="2"'.$it618_xgtype2.'>'.it618_video_getlang('s946').'</option></select><br><input type="text" class="txt" style="width:115px;margin-top:3px" id="it618_xgtime1_'.$n.'" name="it618_xgtime1['.$it618_video_goods['id'].']" readonly="readonly" value="'.$it618_video_goods['it618_xgtime1'].'"><br><input type="text" class="txt" style="width:115px;margin-top:3px" id="it618_xgtime2_'.$n.'" name="it618_xgtime2['.$it618_video_goods['id'].']" readonly="readonly" value="'.$it618_video_goods['it618_xgtime2'].'"></span>',
			'<span style="'.$issalecss.'"><input type="text" class="txt" style="width:58px;margin-right:1px;margin-bottom:3px" name="it618_jfbl['.$it618_video_goods['id'].']" value="'.$it618_video_goods['it618_jfbl'].'">%<br><div style="line-height:15px">'.it618_video_getlang('s118').''.$it618_video_goods['it618_views'].'<br>'.it618_video_getlang('s119').''.$salecount.'<br>'.it618_video_getlang('s120').''.$salemoney.'</span>',
			$it618_state.'<input type="text" class="txt" style="width:23px;" name="it618_shoporder['.$it618_video_goods['id'].']" value="'.$it618_video_goods['it618_shoporder'].'"><span style="'.$issalecss.'"><br><input class="checkbox" type="checkbox" id="chk_isbm'.$n.'" name="it618_isbm['.$it618_video_goods['id'].']" '.$it618_isbm_checked.' value="1"><label for="chk_isbm'.$n.'">'.it618_video_getlang('s862').'</label></span><br><input class="checkbox" type="checkbox" id="chk_isprotect'.$n.'" name="it618_isprotect['.$it618_video_goods['id'].']" '.$it618_isprotect_checked.' value="1"><label for="chk_isprotect'.$n.'">'.it618_video_getlang('s1016').'</label>'
		));
		
		$tmpjs.='laydate.render({
				  elem: "#it618_xgtime1_"+'.$n.'
				  ,type: "datetime"
				  ,format: "yyyy-MM-dd HH:mm"
				});
				laydate.render({
				  elem: "#it618_xgtime2_"+'.$n.'
				  ,type: "datetime"
				  ,format: "yyyy-MM-dd HH:mm"
				});';
		
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_video_getlang('s129').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.it618_video_getlang('s352').'" onclick="return confirm(\''.it618_video_getlang('s353').'\')" /> <input type="submit" class="btn" name="it618submit_edit" value="'.it618_video_getlang('s354').'" onclick="return checkvalue()"/> <input type="submit" class="btn" name="it618submit_on" value="'.it618_video_getlang('s355').'" onclick="return confirm(\''.it618_video_getlang('s356').'\')" /> <input type="submit" class="btn" name="it618submit_down" value="'.it618_video_getlang('s357').'" onclick="return confirm(\''.it618_video_getlang('s358').'\')" /><br>'.it618_video_getlang('s135').'<input type=hidden value='.$page.' name=page /></div><br></td></tr>';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/
$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_video_class1'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_class1')." ORDER BY it618_order");
$n1=1;
$tmp1='';
while($it618_tmp1 =	DB::fetch($query1)) {
	$n2=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_video_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
		$n2=$n2+1;
	}
	$n1=$n1+1;
}
echo '
<style>.it618_video_sum tr td{line-height:22px}.laydate-btns-time{float:left}</style>
	<script>
	'.$tmpjs.'
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x)
	{
	 var temp = document.getElementById("it618_class2_id"); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	function redirec_class_sel(id,index)
	{
	 var temp = document.getElementById(id); 
	 temp.options[index].selected=true;
	
	}
	</script>';
	
echo '
<script>
function showedit(pid){
	layerindex=layer.open({
		type: 2,
		title: "<div style=\'float:left;color:blue\'>'.$it618_video_lang['s409'].'</div>",
		shadeClose: false,
		scrollbar: false,
		shade:  [0.5, "#393D49"],
		maxmin: false,
		area: ["100%", "100%"],
		content: "plugin.php?id=it618_video:sc_product_edit'.$adminsid.'&pid="+pid,
		cancel: function(index, layero){ 
			location.reload();
		}    
	});
}

function showgoodstype(pid,lid,vid){
	layerindex=layer.open({
		type: 2,
		title: "<div style=\'float:left;color:blue\'>'.$it618_video_lang['s710'].'</div>",
		shadeClose: false,
		scrollbar: false,
		shade:  [0.5, "#393D49"],
		maxmin: false,
		area: ["100%", "100%"],
		content: "plugin.php?id=it618_video:sc_product_type'.$adminsid.'&pid="+pid+"&lid="+lid+"&vid="+vid,
		cancel: function(index, layero){ 
			location.reload();
		}    
	});
}

function showsecret(pid){
	layerindex=layer.open({
		type: 2,
		title: "<div style=\'float:left;color:blue\'>'.$it618_video_lang['s1564'].'</div>",
		shadeClose: false,
		scrollbar: false,
		shade:  [0.5, "#393D49"],
		maxmin: false,
		area: ["100%", "100%"],
		content: "plugin.php?id=it618_video:sc_product_secret'.$adminsid.'&pid="+pid,
		cancel: function(index, layero){ 
			location.reload();
		}    
	});
}
</script>
';

echo '
<style>
.chk_it618{
    display: none;
}

.chk_it618 + label {
	background-color: #f9f9f9;
	padding: 9px;
	border-radius: 50px;
	display: inline-block;
	position: relative;
	-webkit-transition: all 0.1s ease-in;
	transition: all 0.1s ease-in;
	width: 23px;
	height: 3px;
	filter:alpha(opacity=80);  
    -moz-opacity:0.8;  
    -khtml-opacity: 0.8;  
    opacity: 0.8;
	cursor:pointer;
	margin-right:3px;
	margin-bottom:-6px
}

.chk_it618  + label:after {
	content: \' \';
	position: absolute;
	top: 0;
	-webkit-transition: box-shadow 0.1s ease-in;
	transition: box-shadow 0.1s ease-in;
	left: 0;
	width: 100%;
	height: 100%;
	border-radius: 100px;
	box-shadow: inset 0 0 0 0 #eee, 0 0 1px rgba(0,0,0,0.4);
}

.chk_it618  + label:before {
	content: \' \';
	position: absolute;
	background: white;
	top: 1px;
	left: 1px;
	z-index: 999999;
	width: 20px;
	-webkit-transition: all 0.1s ease-in;
	transition: all 0.1s ease-in;
	height: 18px;
	border-radius: 100px;
	box-shadow: 0 3px 1px rgba(0,0,0,0.05), 0 0px 1px rgba(0,0,0,0.3);
}

.chk_it618:active + label:after {
	box-shadow: inset 0 0 0 20px #eee, 0 0 1px #eee;
}

.chk_it618:active + label:before {
	width: 20px;
}

.chk_it618:checked:active + label:before {
	width: 20px;
	left: 10px;
}

.chk_it618  + label:active {
	box-shadow: 0 1px 2px rgba(0,0,0,0.05), inset 0px 1px 3px rgba(0,0,0,0.1);
}

.chk_it618:checked + label:before {
	content: \' \';
	position: absolute;
	left: 19px;
	border-radius: 100px;
}

.chk_it618:checked + label:after {
	content: \' \';
	font-size: 1.5em;
	position: absolute;
	background: #390;
	box-shadow: 0 0 1px #4cda60;
}
</style>

<script>
		'.$jstmp.'
		
		function savegoodsstate(pid){
			IT618_VIDEO.get("'.$_G['siteurl'].'plugin.php?id=it618_video:ajax'.$adminsid.'&pid="+pid+"&formhash='.FORMHASH.'", {ac:"savegoodsstate"},function (data, textStatus){
			
			}, "html");	
		}
		
		function checkvalue(){
			for(var i=1;i<'.$n.';i++){
				var chk_del = document.getElementById("chk_del"+i).value;
				var it618_xgtype = document.getElementById("it618_xgtype"+i).value;
				var it618_xgtime1 = document.getElementById("it618_xgtime1_"+i).value;
				var it618_xgtime2 = document.getElementById("it618_xgtime2_"+i).value;
				
				var tmparr1=it618_xgtime1.split(" ");
				var tmparr2=it618_xgtime2.split(" ");
				
				if(it618_xgtype>0){
					if(it618_xgtime1==""){
						alert("'.it618_video_getlang('s949').'"+chk_del+") '.it618_video_getlang('s950').'");
						document.getElementById("it618_xgtime1_"+i).focus();
						return false;
					}
					if(it618_xgtime2==""){
						alert("'.it618_video_getlang('s949').'"+chk_del+") '.it618_video_getlang('s951').'");
						document.getElementById("it618_xgtime2_"+i).focus();
						return false;
					}
					if(parseInt(tmparr2[0].replace(/-/g,""))<parseInt(tmparr1[0].replace(/-/g,""))){
						alert("'.it618_video_getlang('s949').'"+chk_del+")'.it618_video_getlang('s947').'");
						document.getElementById("it618_xgtime1_"+i).focus();
						return false;
					}
					
					var flag=0;
					if(it618_xgtype==2){
						flag=1;
					}else{
						if(parseInt(tmparr2[0].replace(/-/g,""))==parseInt(tmparr1[0].replace(/-/g,""))){
							flag=1;
						}
					}
					if(flag==1&&parseInt(tmparr2[1].replace(":",""))<=parseInt(tmparr1[1].replace(":",""))){
						alert("'.it618_video_getlang('s949').'"+chk_del+")'.it618_video_getlang('s948').'");
						document.getElementById("it618_xgtime1_"+i).focus();
						return false;
					}
				}
			}
		}
		</script>';
echo '
	  <script type="text/javascript">
		function check_all(obj,id)
		{
			for(var i=1;i<'.$n.';i++)
			{
				document.getElementById(id+""+i).checked = obj.checked;
			}
		}
	  </script>';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>