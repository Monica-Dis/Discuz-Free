<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_video = $_G['cache']['plugin']['it618_video'];
$metatitle = $it618_video['seotitle'];

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php';
	if($player_browseruid!=''&&$_G['uid']>0){
		if($player_browseruid==$_G['uid']){
			echo $_SERVER['HTTP_USER_AGENT'];exit;
		}
	}
}

$lid=intval($_GET['lid']);
require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

$stylecount=C::t('#it618_video#it618_video_style')->count_by_isok();
$it618_video_style=C::t('#it618_video#it618_video_style')->fetch_by_isok();

if(video_is_mobile()){ 
	$tmpurl=it618_video_getrewrite('video_wap','lesson@'.$lid,'plugin.php?id=it618_video:wap&pagetype=lesson&cid='.$lid);
	dheader("location:$tmpurl");
}

$homeurl=it618_video_getrewrite('video_home','','plugin.php?id=it618_video:index');

if(!($it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id_ison($lid))){
	
	if($it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_vid($lid)){
		if($it618_video_live['it618_ossbucket']==''&&$it618_video_live['it618_ossendpoint']==''){
			$tmpurl=it618_video_getrewrite('video_product',$it618_video_live['it618_pid'],'plugin.php?id=it618_video:product&pid='.$it618_video_live['it618_pid']);
			echo it618_video_getlang('s1393').' <a href="'.$tmpurl.'">'.$it618_video_lang['s1395'].'</a>';exit;
		}else{
			echo it618_video_getlang('s389').' <a href="'.$homeurl.'">'.$it618_video_lang['s18'].'</a>';exit;	
		}
	}else{
		echo it618_video_getlang('s389').' <a href="'.$homeurl.'">'.$it618_video_lang['s18'].'</a>';exit;
	}
}else{
	if($it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_vid($lid)){
		if($it618_video_live['it618_ossbucket']!=''&&$it618_video_live['it618_ossendpoint']!=''){
			if($it618_video_live['it618_etime']<$_G['timestamp']){
				if($it618_video_live['it618_isok']==0){
					$tmptime=intval(($_G['timestamp']-$it618_video_live['it618_etime'])/60);
					$it618_video_lang['s1394']=str_replace("{time}",(5-$tmptime),$it618_video_lang['s1394']);
					$tmpurl=it618_video_getrewrite('video_product',$it618_video_live['it618_pid'],'plugin.php?id=it618_video:product&pid='.$it618_video_live['it618_pid']);
					echo it618_video_getlang('s1394').' <a href="'.$tmpurl.'">'.$it618_video_lang['s1395'].'</a>';exit;
				}
			}
		}
	}
}

$pid=$it618_video_goods_video['it618_pid'];
$producturl=it618_video_getrewrite('video_product',$pid,'plugin.php?id=it618_video:product&pid='.$pid);

if(!($it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id_state($pid,1))){
	echo it618_video_getlang('s470').' <a href="'.$homeurl.'">'.$it618_video_lang['s18'].'</a>';exit;
}else{
	if(!it618_video_issecretok($it618_video_goods)){
		echo it618_video_getlang('s470').' <a href="'.$homeurl.'">'.$it618_video_lang['s18'].'</a>';exit;
	}
	
	$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
	if($it618_video_shop['it618_state']!=2||$it618_video_shop['it618_htstate']!=1){
		echo it618_video_getlang('s470').' <a href="'.$homeurl.'">'.$it618_video_lang['s18'].'</a>';exit;
	}
	
	$lecturerurl=it618_video_getrewrite('video_lecturer',$it618_video_shop['id'],'plugin.php?id=it618_video:lecturer&lid='.$it618_video_shop['id']);
	$lecturerlogo=$it618_video_shop['it618_ulogo'];
	
	if(C::t('#it618_video#it618_video_shop_subscribe')->count_by_shopid_uid($it618_video_shop['id'],$_G['uid'])>0){
		$subscribetitle=$it618_video_lang['s1397'];
	}else{
		$subscribetitle='<font color="'.$it618_video_style['it618_color1'].'">'.$it618_video_lang['s1396'].'</font>';
	}
	
	$shopsubscribes=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_shop_subscribe')." WHERE it618_shopid=".$it618_video_shop['id']);
	$shopviews=DB::result_first("SELECT SUM(it618_views) FROM ".DB::table('it618_video_goods')." WHERE it618_shopid=".$it618_video_shop['id']);
}

if($it618_video_goods_video['it618_liveid']>0){
	$it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
	$it618_name=$it618_video_live['it618_name'];
	$it618_description=$it618_video_live['it618_description'];
}else{
	$it618_name=$it618_video_goods_video['it618_name'];
	$it618_description=$it618_video_goods_video['it618_description'];
}
if($it618_description=='')$it618_description=$it618_video_goods['it618_description'];

$shop_tongji='<div style="display:none">'.$it618_video_shop['it618_tongji'].'</div>';

C::t('#it618_video#it618_video_goods')->update_it618_views_by_id($pid);

$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($it618_video_goods_video['it618_lid']);
if($it618_video_goods_lesson['it618_saleprice']>0&&$it618_video_goods_lesson['it618_issale']==1){
	$goodslessonprice='<a href="javascript:" class="salebtn salebtn1" onclick="showpay_l('.$it618_video_goods_video['it618_lid'].')">'.$it618_video_lang['s795'].'</a>';
}

if($it618_video_goods_video['it618_saleprice']>0&&$it618_video_goods_video['it618_issale']==1){
	$goodsvideoprice='<a href="javascript:" class="salebtn salebtn1" onclick="showpay_v('.$it618_video_goods_video['it618_lid'].','.$it618_video_goods_video['id'].')">'.$it618_video_lang['s796'].'</a>';
}

$isgoodsprice=0;
if($it618_video_goods['it618_saleprice']>0||$it618_video_goods['it618_score']>0){
	$isgoodsprice=1;
}

if($it618_video_shop['it618_issale']==0){
	$isgoodsprice=1;
}

$vipgroupids=it618_video_getgoodsvipgroupids($it618_video_goods);
if($_G['uid']>0){
	$videopower=it618_video_getpower($_G['uid'],$it618_video_goods_video['it618_pid'],$it618_video_goods_video['it618_lid'],$it618_video_goods_video['id']);
	if(count($vipgroupids)>0){
		$tmpgrouparr=it618_video_getisvipuser($vipgroupids);
		$isvipuser=count($tmpgrouparr[0]);
	}
}

if($it618_video_goods_video['it618_liveid']>0){
	$it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
	$it618_name=$it618_video_live['it618_name'];
	
	if($it618_video_live['it618_etime']<$_G['timestamp']){
		$tmpurl=it618_video_getrewrite('video_product',$pid,'plugin.php?id=it618_video:product&pid='.$pid);
		dheader("location:$tmpurl");
	}else{
		if($it618_video_live['it618_btime']>$_G['timestamp']){
			$timeflag=1;
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=date('Y-m-d H:i:s', $it618_video_live['it618_btime']);
			$timetip=date('Y-m-d H:i:s', $it618_video_live['it618_btime']).' - '.date('Y-m-d H:i:s', $it618_video_live['it618_etime']);
		}
	}
	$liveid=$it618_video_goods_video['it618_liveid'];
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/message.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_video/config/message.php';
	}
	
	if($it618_isok==1&&$it618_body_live_user_isok==1){
		if($it618_video_live['it618_liveset_id']>0){
			$it618_video_liveset=C::t('#it618_video#it618_video_liveset')->fetch_by_id($it618_video_live['it618_liveset_id']);
			$it618_liveordertime=$it618_video_liveset['it618_liveordertime'];
		}else{
			$it618_liveordertime=5;
		}
		if($it618_liveordertime>=5&&(($it618_video_live['it618_btime']-$_G['timestamp'])>$it618_liveordertime*60)){
			$isliveorder=1;
			if(C::t('#it618_video#it618_video_live_order')->count_by_liveid_uid($liveid,$_G['uid'])>0){
				$liveorderbtntitle=$it618_video_lang['s1385'];
				$orderok=1;
			}else{
				$liveorderbtntitle=$it618_video_lang['s1370'];	
				$orderok=0;
			}
		}
	}
}else{
	$it618_name=$it618_video_goods_video['it618_name'];
}

$it618_name1=cutstr($it618_name,58,'...');

$it618_isuser=$it618_video_goods_video['it618_isuser'];

$producturl=it618_video_getrewrite('video_product',$pid,'plugin.php?id=it618_video:product&pid='.$pid);

if($it618_isuser==0){
	$isok=1;
}

if($it618_isuser==2){
	if($_G['uid']>0){
		$isok=1;
	}else{
		$btnstr=$it618_video_lang['t204'];
		$it618_isvipstr='<a href="javascript:" class="loginbtn salebtn">'.$it618_video_lang['t205'].'</a>';
	}
}

if($it618_isuser==1){
	$btnstr=$it618_video_lang['t263'];
	if($isgoodsprice>0){
		if($videopower['state']>0){
			$isok=1;
			if($videopower['state']==2){
				$isajaxpower=1;
			}
		}else{
			if(count($vipgroupids)>0){
				$it618_isvip='<img src="source/plugin/it618_video/images/vip.png" style="vertical-align:middle;margin-top:-3px;margin-right:3px">';
				if($isvipuser>0){
					$isok=1;
				}else{
					if($it618_video_shop['it618_issale']==1){
						if($_G['uid']>0){
							$btnstr=$it618_video_lang['t800'];
						}else{
							$btnstr=$it618_video_lang['t419'];
							if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
								$btnstr=str_replace("{url}",'javascript:userlogin()',$btnstr);
							}else{
								$refererurl=it618_video_getrewrite('video_wap','lesson@'.$lid,'plugin.php?id=it618_video:wap&pagetype=lesson&cid='.$lid);
								$btnstr=str_replace("{url}",'member.php?mod=logging&action=login&referer='.$refererurl,$btnstr);
							}
						}
					}else{
						$btnstr=$it618_video_lang['s1592'];
					}
					$it618_isvipstr='<a href="javascript:" class="vipbtn salebtn showvipgroupbtn">'.$it618_video_lang['s19'].'</a>';
				}
			}
		}
	}else{
		$isok=1;
	}
	
	if($_G['uid']==$it618_video_shop['it618_uid']){
		$isok=1;
	}
}

if($isok!=1){
	if($it618_video_goods_video['it618_previewtime']>0){
		$isok=1;
		$previewtime=$it618_video_goods_video['it618_previewtime'];
	}
}

if($isok==1){
	$tmpcode=md5($_G['timestamp'].FORMHASH.rand());
		
	C::t('#it618_video#it618_video_videowork')->insert(array(
		'it618_code' => $tmpcode,
		'it618_video' => $it618_video_goods['it618_gtype'].'it618_split'.$it618_video_goods_video['id']
	), true);
	
	$playadtime=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('playadtime');
	$playad=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('playad');
	
	if($it618_video_goods['it618_gtype']==1){
		$isvideo=1;
		$tmparr=explode("<iframe",$it618_video_goods_video['it618_videourl']);
		if(count($tmparr)>1)$isiframe=1;
	}
	
	$it618_video_play_pj=C::t('#it618_video#it618_video_play_pj')->fetch_by_pid_uid($pid,$_G['uid']);
}

$n=1;$l=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_lesson')." WHERE it618_pid=".$pid." ORDER BY it618_order");
while($it618_video_goods_lesson = DB::fetch($query)) {
	if($it618_video_goods['it618_lessoncount']>1){
		if($it618_video_goods_lesson['it618_type']==1){
			$videostr.='<li class="lesson" style="font-weight:bold;color:#ccc;font-size:15px;cursor:pointer" onclick="getcourse('.$l.',\'\')">
							<img src="source/plugin/it618_video/template/mall_wap/images/bli0.png" id="liimg'.$l.'" width="15" style="vertical-align:middle;margin-top:-5px; margin-right:13px;margin-left:2px">'.cutstr($it618_video_goods_lesson['it618_name'],38,'...').'
						</li>';
		}else{
			$videostr.='<li class="lesson" style="font-weight:bold;color:#ccc;font-size:15px;cursor:pointer;">
							<img src="source/plugin/it618_video/images/link1.png" width="18" style="vertical-align:middle;margin-top:-5px; margin-right:13px;margin-left:2px"><a href="'.$it618_video_goods_lesson['it618_url'].'" target="_blank" title="'.$it618_video_goods_lesson['it618_name'].'" style="font-size:15px;color:#ccc;display:inline">'.cutstr($it618_video_goods_lesson['it618_name'],38,'...').'</a>
						</li>';
		}
	}
	
	if($it618_video_goods_lesson['it618_type']==1){
		$v=1;
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_goods_video')." WHERE it618_lid=".$it618_video_goods_lesson['id']." and it618_ison=1 ORDER BY it618_order,id");
		while($it618_tmp = DB::fetch($query1)) {
			$videopowertmp=it618_video_getpower($_G['uid'],$it618_tmp['it618_pid'],$it618_tmp['it618_lid'],$it618_tmp['id']);
			
			$lessonurl=it618_video_getrewrite('video_lesson',$it618_tmp['id'],'plugin.php?id=it618_video:lesson&lid='.$it618_tmp['id']);
			$lessonurlarr[$n]=$lessonurl;
			if($lid==$it618_tmp['id']){
				$curstr='cur';
				$curn=$n;
			}else{
				$curstr='';
			}
			
			$isuserstr='';
			
			if($it618_tmp['it618_liveid']>0){
				$it618_usercode=$it618_tmp['it618_usercode'];
				$it618_tmp=C::t('#it618_video#it618_video_live')->fetch_by_id($it618_tmp['it618_liveid']);
				
				$livestate='';
				if($it618_tmp['it618_btime']>$_G['timestamp']){
					$livestate=it618_video_gettime1($it618_tmp['it618_btime']).$it618_video_lang['s1316'];
				}
				
				if($it618_tmp['it618_btime']<$_G['timestamp']&&$_G['timestamp']<$it618_tmp['it618_etime']){
					$livestate='<img src="source/plugin/it618_video/images/live.gif" style="vertical-align:middle;margin-top:-3px;height:20px;-webkit-filter: grayscale(100%);"> '.$it618_video_lang['s1973'];
				}
				
				if($livestate=='')continue;
				if($it618_video_goods['it618_isprotect']==1&&$_G['uid']!=$it618_video_shop['it618_uid']&&$it618_tmp['it618_isuser']==1){
					if(it618_video_isprotect($isgoodsprice,$videopowertmp,$isvipuser))continue;
				}
				
				if($isgoodsprice==0||$it618_tmp['it618_isuser']==0||$it618_tmp['it618_isuser']==2){
					if($it618_usercode!=''){
						$tmpuserstr=$it618_video_lang['s1609'];
					}else{
						$tmpuserstr=$it618_video_lang['s1968'];
					}
	
					$isuserstr='<span style="border:#666 1px solid; padding:0; height:13px; line-height:13px; display:inline-block; padding-left:2px; padding-right:2px; border-radius:3px;color:#999;font-size:12px;vertical-align:middle;margin-top:-3px">'.$tmpuserstr.'</span> ';
				}
				
				if($curstr=='cur'){
					$livestate=str_replace(";-webkit-filter: grayscale(100%);","",$livestate);
				}
				
				$videostr.='<li class="lesson '.$curstr.' lesson'.$l.'">
							   <a href="'.$lessonurl.'" title="'.$it618_tmp['it618_name'].'"><p class="fl">'.$l.'.'.$v.'&nbsp;&nbsp; '.$it618_tmp['it618_name'].'</p><span class="time fr">'.$isuserstr.$livestate.'</span></a>
							</li>';
			}else{
				
				if($it618_video_goods['it618_isprotect']==1&&$_G['uid']!=$it618_video_shop['it618_uid']&&$it618_tmp['it618_isuser']==1){
					if(it618_video_isprotect($isgoodsprice,$videopowertmp,$isvipuser))continue;
				}
				
				if($isgoodsprice==0||$it618_tmp['it618_isuser']==0||$it618_tmp['it618_isuser']==2){
					if($it618_tmp['it618_usercode']!=''){
						$tmpuserstr=$it618_video_lang['s1609'];
					}else{
						$tmpuserstr=$it618_video_lang['s1968'];
					}
					$isuserstr='<span style="border:#666 1px solid; padding:0; height:13px; line-height:13px; display:inline-block; padding-left:2px; padding-right:2px; border-radius:3px;color:#999;font-size:12px;vertical-align:middle;margin-top:-1px">'.$tmpuserstr.'</span> ';
				}
				
				$previewtimestr='';
				if($it618_tmp['it618_previewtime']>0){
					$previewtimestr='<span style="border:#666 1px solid; padding:0; height:13px; line-height:13px; display:inline-block; padding-left:2px; padding-right:2px; border-radius:3px;color:#999;font-size:12px;vertical-align:middle;margin-top:-1px">'.$it618_video_lang['s1969'].'</span> ';
				}
				
				if($it618_tmp['it618_islive']==1){
					$timestr='<img src="source/plugin/it618_video/images/live.gif" style="vertical-align:middle;margin-top:-3px;height:20px;-webkit-filter: grayscale(100%);"> '.$it618_video_lang['s1973'];
				}else{
					$timestr=it618_video_getvideotimestr($it618_tmp);
				}
				
				if($curstr=='cur'){
					$timestr=str_replace(";-webkit-filter: grayscale(100%);","",$timestr);
				}
				
				$videostr.='<li class="lesson '.$curstr.' lesson'.$l.'">
							   <a href="'.$lessonurl.'" title="'.$it618_tmp['it618_name'].'"><p class="fl">'.$l.'.'.$v.'&nbsp;&nbsp; '.$it618_tmp['it618_name'].'</p><span class="time fr">'.$isuserstr.$previewtimestr.$timestr.'</span></a>
							</li>';
			}
			$n=$n+1;
			$v=$v+1;
		}
	}
	$l=$l+1;
}

if($curn==$n-1){
	$nexturl='';
}else{
	$nexturl=$lessonurlarr[$curn+1];
}

if($playadtime=='')$playadtime=0;
$playadnotids=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('playadnotids');
$tmparr=explode(",",$playadnotids);
if(in_array($pid,$tmparr)){
	$playadtime=0;
}

if($isvipuser>0&&$playadtime>0){
	$playadvip=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('playadvip');
	$tmparr=explode(",",$playadvip);
	if(!in_array($pid,$tmparr)){
		$playadtime=0;
	}
}

$lessontopad=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('lessontopad');
$lessonbottomad=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('lessonbottomad');

if($it618_video_goods_video['it618_ischat']==0)$IsChat=0;

$metatitle=$it618_name.' - '.$metatitle;
$metakeywords=$it618_video_goods['it618_seokeywords'];
$metadescription=$it618_video_goods_video['it618_description'];

$url_this=$_G['siteurl'].it618_video_getrewrite('video_wap','lesson@'.$lid,'plugin.php?id=it618_video:wap&pagetype=lesson&cid='.$lid);
$vqrcodesrc='plugin.php?id=it618_video:urlcode&url='.urlencode($url_this);

if($player_httptime=='')$player_httptime=1.5;
$player_httptime=$player_httptime*1000;
if($IsChat==0)$player_ischat=0;

if($isok==1&&$isvideo==1&&$isiframe!=1){
	
	$player_version=$it618_video_lang['playerversion'];
		
	if($_G['uid']>0){
		if($player_ismemory==1)$memorytime=$player_memorytime*1000;
		if($player_memorydo==1)$memorydo=str_replace("{time}",$player_memorytime,$it618_video_lang['t353']);
		if($player_memorydo==2)$memorydo=str_replace("{time}",$player_memorytime,$it618_video_lang['t374']);
	
		$player_marquee=str_replace("{uid}",$_G['uid'],$player_marquee);
		$player_marquee=str_replace("{username}",dhtmlspecialchars($_G['username']),$player_marquee);
		$player_marquee=str_replace(array("\r\n", "\r", "\n"),"",$player_marquee);
		
		$isscreencapad=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('isscreencapad');
		if($isscreencapad==1){
			$noscreencapaduids=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('noscreencapaduids');
			$tmparr=explode(",",$noscreencapaduids);
			if(!in_array($_G['uid'],$tmparr)){
				$screencapadtime=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('screencapadtime');
				if($screencapadtime=='')$screencapadtime=5;
				$screencapadtime=$screencapadtime*60;
				$screencapad=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('screencapad');
				$screencapadwidthheight=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('screencapadwidthheight');
				$tmparr=explode(",",$screencapadwidthheight);
				$screencapadw=$tmparr[0]+6;
				$screencapadh=$tmparr[1]+6;
			}
		}
	}else{
		$player_ismarquee=0;	
	}
}

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	if(isset($_GET['reg']))$winapireg='winapireg';
	$it618_members_index=it618_members_getmembers($_GET['id'],'#it618_members','',$winapireg);
	if($_G['uid']>0)$it618_members_index.=it618_members_getmembers($_GET['id'],'#it618_members_wxbd','plugin.php?id=it618_members:home&ac=wxsubscribe').'<div id="it618_members_wxbd"></div>';
	if($it618_video['video_saletel']==2){
		if($_G['uid']>0)$it618_members_telbd=it618_members_getmembers($_GET['id'],'#it618_members_telbd','plugin.php?id=it618_members:home&ac=salebdtel').'<div id="it618_members_telbd"></div>';
	}
}

$query3 = DB::query("SELECT * FROM ".DB::table('it618_video_goods_data')." WHERE it618_vid=".$it618_video_goods_video['id']." and it618_dataurl!='' ORDER BY it618_order");
while($it618_video_goods_data = DB::fetch($query3)) {
	$isoktmp=0;
	if($it618_video_goods_data['it618_isuser']==0){
		$isoktmp=1;
	}
	
	if($it618_video_goods_data['it618_isuser']==2){
		$it618_dataurl='<font color=#999>'.$it618_video_lang['s942'].'</font>';
		if($_G['uid']>0){
			$isoktmp=1;
		}
	}
	
	if($it618_video_goods_data['it618_isuser']==1){
		$it618_dataurl='<font color=#999>'.$it618_video_lang['s805'].'</font>';
		
		if($isgoodsprice>0){
			if($videopowertmp['state']>0){
				$isoktmp=1;
			}else{
				if($isvipok==1){
					$isoktmp=1;
				}
			}
		}else{
			$isoktmp=1;
		}
		
		if($_G['uid']>0){
			$it618_video_shoptmp=C::t('#it618_video#it618_video_shop')->fetch_by_uid($_G['uid']);
			if($it618_video_goods['it618_shopid']==$it618_video_shoptmp['id']){
				$isoktmp=1;
			}
		}
	}

	if($isoktmp==1){
		$it618_dataurl1='href="plugin.php?id=it618_video:datadown&did='.$it618_video_goods_data['id'].'" target="_blank"';
		$it618_dataurl=''.$it618_video_lang['s806'].'';
	}
	
	$datastr.='<tr>
				  <td>
				  <a '.$it618_dataurl1.' class="videotdbtn">'.$it618_video_goods_data['it618_name'].'</a>
				  <p><span style="border:#ddd 1px solid; padding:0; height:15px; line-height:15px; display:inline-block; padding-left:2px; padding-right:2px; border-radius:3px;color:#aaa;font-size:12px;vertical-align:middle;margin-top:-1px;float:right;margin-right:8px">'.$it618_dataurl.'</span><span>'.$it618_video_goods_data['it618_datasizestr'].' , '.$it618_video_lang['s46'].': '.$it618_video_goods_data['it618_views'].'</span></p>
				  </td>
			  </tr>';
}

if($datastr!=''){
	$datastr='<table class="dataexam" style="margin-bottom:13px"><tr><td class="dataexamtitle">'.$it618_video_lang['t138'].'</td><tr>'.$datastr.'<tr></table>';
}

$query3 = DB::query("SELECT * FROM ".DB::table('it618_video_goods_video_exam')." WHERE it618_vid=".$it618_video_goods_video['id']." ORDER BY it618_order");
while($it618_video_goods_video_exam = DB::fetch($query3)) {
	
	$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_video_goods_video_exam['it618_tid']);
	
	$examurl=it618_video_exam_getrewrite('exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
	
	$it618_exam_goods['it618_examscore']=str_replace(".0","",$it618_exam_goods['it618_examscore']);
	$it618_examstr=str_replace("{qcount}",$it618_exam_goods['it618_questioncount'],$it618_video_lang['s1429']);
	$it618_examstr=str_replace("{score}",$it618_exam_goods['it618_examscore'],$it618_examstr);
	$it618_examstr=str_replace("{time}",$it618_exam_goods['it618_examtime'],$it618_examstr);
	
	$isuserstr='';
	if($it618_video_goods_video_exam['it618_power']==1&&$isgoodsprice==1){
		$isuserstr='<span style="border:#ddd 1px solid; padding:0; height:15px; line-height:15px; display:inline-block; padding-left:2px; padding-right:2px; border-radius:3px;color:#aaa;font-size:12px;vertical-align:middle;margin-top:-1px;float:right;margin-right:8px">'.$it618_video_lang['s1574'].'</span> ';
	}

	$examstr.='<tr>
				  <td>
				  <a href="'.$examurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a>
				  <p>'.$isuserstr.'<span>'.$it618_examstr.'</span></p>
				  </td>
			  </tr>';
}

if($examstr!=''){
	$examstr='<table class="dataexam"><tr><td class="dataexamtitle">'.$it618_video_lang['s1428'].'</td><tr>'.$examstr.'</table>';
}

if($datastr==''||$examstr==''){
	if($examstr!='')$it618_video_lang['s2129']=$it618_video_lang['t297'];
	if($datastr!='')$it618_video_lang['s2129']=$it618_video_lang['t409'];
}

if($it618_video_goods['it618_gtype']==1){
	if($it618_video_goods_video['it618_message']!=''){
		if($it618_video_goods_video['it618_ismessagetb']==1){
			$it618_message=$it618_video_lang['s1605'];
		}else{
			$it618_message=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$it618_video_goods_video['it618_message']);
			$it618_message=preg_replace('/<table.+?>/','<table cellspacing="0" cellpadding="0" width="100%">',$it618_message);
			$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="220" frameborder="0" allowfullscreen="1">',$it618_message);
			$it618_message=str_replace('&it618mediatype=audio"','&wap=1" style="border:0;width:100%;height:53px" scrolling="no" frameborder=0',$it618_message);
		}
	}
}

if($player_ischat==0){
	if($it618_video_goods_video['it618_ischatdefault']==1){
		$player_ischat=1;
	}
}

if($it618_video_goods_video['it618_ismessagedefault']==1){
	$it618_ismessagedefault=1;
	$player_ischat=0;
}

$it618_messagename=$it618_video_lang['s1814'];
if($it618_video_goods_video['it618_messagename']!=''){
	$it618_messagename=$it618_video_goods_video['it618_messagename'];
}

if($IsCredits==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$it618_credits_buygroup=it618_credits_getcredits($_GET['id'],'#vippaybtn','plugin.php?id=it618_credits:do&dotype=buygroup');
}

$it618_videoimg=$it618_video_goods_video['it618_videoimg'];
if($it618_videoimg==''){
	$it618_videoimg=$it618_video_goods['it618_picbig'];

	$tmparr1=explode(".m3u8",$it618_video_goods_video['it618_videourl']);
	if(count($tmparr1)>1){
		if($it618_video_media_mts=C::t('#it618_video#it618_video_media_mts')->fetch_by_url($it618_video_goods_video['it618_videourl'])){
			$it618_video_media=C::t('#it618_video#it618_video_media')->fetch_by_id($it618_video_media_mts['it618_media_id']);
			$it618_videoimg=it618_video_cdnkeyurl($it618_video_media['it618_coverurl']);
		}
	}
}

$_G['mobiletpl'][2]='/';
include template('it618_video:lesson');
?>