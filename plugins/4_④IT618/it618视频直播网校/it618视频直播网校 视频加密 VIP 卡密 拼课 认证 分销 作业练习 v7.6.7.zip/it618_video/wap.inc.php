<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;

$it618_video = $_G['cache']['plugin']['it618_video'];
$metakeywords = $it618_video['seokeywords'];
$metadescription = $it618_video['seodescription'];
$sitetitle=$it618_video['seotitle'];

require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

$video_home=it618_video_getrewrite('video_home','','plugin.php?id=it618_video:index');
$waphome=it618_video_getrewrite('video_wap','','plugin.php?id=it618_video:wap');
$wapsearch=it618_video_getrewrite('video_wap','search@0','plugin.php?id=it618_video:wap&pagetype=search&cid=0');
$wapu=it618_video_getrewrite('video_wap','u@'.$_G['uid'],'plugin.php?id=it618_video:wap&pagetype=u');

$tmparr=explode($_G['siteurl'],$_SERVER['HTTP_REFERER']);

$stylecount=C::t('#it618_video#it618_video_wapstyle')->count_by_isok_search();
$it618_video_wapstyle=C::t('#it618_video#it618_video_wapstyle')->fetch_by_isok_search();

if(isset($_GET['pagetype'])){
	$pagetypearray = array('video', 'lecturer', 'product', 'pin', 'lesson', 'sc', 'sc_live_add', 'sc_liveset', 'sc_live', 'sc_product_add', 'sc_product_edit', 'sc_product', 'sc_product_lesson', 'sc_product_type', 'sc_product_video', 'sc_subscribe', 'sc_gwc', 'uc', 'search', 'gwcsale', 'u');
	$pagetype = !in_array($_GET['pagetype'], $pagetypearray) ? 'video' : $_GET['pagetype'];
}else{
	$pagetype='video';
	$navtitle=$sitetitle;
}

if($it618_video['video_style']>2){
	$videostyle=getcookie('videostyle');
	if($videostyle==''){
		if($it618_video['video_style']==3)$videostyle='1';else $videostyle='2';
	}

	if($pagetype=='video'||$pagetype=='search'||$pagetype=='lecturer'){
		if($videostyle=='1')$videostyle1='2';else $videostyle1='1';
		$videostylestrtmp='<div class="style-btn" onClick="videostyle()"><i class="icon-style'.$videostyle1.'"></i></div>';
	}
}else{
	if($it618_video['video_style']==1)$videostyle='1';else $videostyle='2';
}

$ucbottomtitle=$it618_video_lang['s1560'];
$gwcpcount=0;
$gwcurl=it618_video_getrewrite('video_wap','gwcsale@'.$_G['uid'],'plugin.php?id=it618_video:wap&pagetype=gwcsale');
if($_G['uid']>0){
	$logout='<li><a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="react">'.it618_video_getlang('s460').'</a></li>';
	$strusr='<a href="member.php?mod=logging&action=logout&formhash='.FORMHASH.'" class="btn btn-weak">'.it618_video_getlang('s460').'</a> <a href="'.it618_video_rewriteurl($_G['uid']).'" target="_blank">'.it618_video_getusername($_G['uid']).'</a>';
	
	$gwcpcount=C::t('#it618_video#it618_video_gwc')->count_by_uid($_G['uid']);
	$ucbottomtitle=$it618_video_lang['s832'];
}

$n=0;
$query = DB::query("SELECT * FROM ".DB::table('it618_video_bottomnav')." where it618_order<>0 ORDER BY it618_order");
while($it618_video_bottomnav = DB::fetch($query)) {	
	$it618_url=$it618_video_bottomnav['it618_url'];
	$iscur=0;
	
	$tmpurlarr1=explode("{waphome}",$it618_url);
	$tmpurl=it618_video_getrewrite('video_wap','','plugin.php?id=it618_video:wap');
	$it618_url=str_replace("{waphome}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='index'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{wapsearch}",$it618_url);
	$tmpurl=it618_video_getrewrite('video_wap','search@0','plugin.php?id=it618_video:wap&pagetype=search&cid=0');
	$it618_url=str_replace("{wapsearch}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='search'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{wapgwc}",$it618_url);
	$tmpurl=it618_video_getrewrite('video_wap','gwcsale@'.$_G['uid'],'plugin.php?id=it618_video:wap&pagetype=gwcsale');
	$it618_url=str_replace("{wapgwc}",$tmpurl,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='gwcsale'){
			$iscur=1;
		}
	}
	
	if($it618_video_bottomnav['id']==5)$it618_url=it618_video_getrewrite('video_wap','u@'.$_G['uid'],'plugin.php?id=it618_video:wap&pagetype=u');
	
	if($iscur==0){
		$REQUEST_URI=str_replace("/","",$_SERVER['REQUEST_URI']);
		$REQUEST_URI=str_replace("?mobile=2","",$REQUEST_URI);
		$REQUEST_URI=str_replace("&mobile=2","",$REQUEST_URI);
		if($REQUEST_URI==$it618_url){
			$iscur=1;
		}
	}
	
	if($iscur==1){
		$it618_img=$it618_video_bottomnav['it618_curimg'];
		if($it618_img=='')$it618_img=$it618_video_bottomnav['it618_img'];
		$it618_title='<font color="'.$it618_video_bottomnav['it618_color'].'">'.$it618_video_bottomnav['it618_title'].'</font>';
	}else{
		$it618_img=$it618_video_bottomnav['it618_img'];
		$it618_title=$it618_video_bottomnav['it618_title'];
	}
	
	if($it618_video_bottomnav['id']==5&&$_G['uid']==0){
		$it618_title=$it618_video_lang['s1560'];
	}
	
	if($it618_video_bottomnav['id']==1){
		$bottomnav.='<td align="center" style="it618width;color:#666;height:48px;border-top:#f1f1f1 1px solid;" class="mymenu"><a href="javascript:" style="color:#666"><img src="'.$it618_video_bottomnav['it618_img'].'" height="23" style="margin-bottom:3px;"><br>'.$it618_title.'</a></td>';
	}else{
		$bottomnav.='<td align="center" style="it618width;color:#666;height:48px;border-top:#f1f1f1 1px solid;"><a href="'.$it618_url.'" style="color:#666"><img src="'.$it618_img.'" height="23" style="margin-bottom:3px;"><br>'.$it618_title.'</a></td>';
	}

	$n=$n+1;
}

$n=100/$n;
$bottomnav=str_replace("it618width","width:$n%",$bottomnav);

$wap=1;

$urlarr=explode("https:",$_G['siteurl']);
if(count($urlarr)==1){
	$thisurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}else{
	$thisurl = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}
$thisurl=str_replace("?mobile=2","",$thisurl);
$thisurl=str_replace("&mobile=2","",$thisurl);

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')===false)$iswx=0;

if($iswx==1){
	$wx_appid=trim($it618_video['video_appid']);
	$wx_secret=trim($it618_video['video_appsecret']);
	if($wx_appid==''&&$wx_secret==''){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
			if($wx_isok!=1)$wx_appid='';
		}
	}
}

if($wx_appid!=''&&$wx_secret!=''){
	if($pagetype=='lecturer'){
		$lid=intval($_GET['cid']);
		$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($lid);
		$wxshare_title=$it618_video_shop['it618_name'];
		$wxshare_imgUrl=$it618_video_shop['it618_logo'];
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_video_shop['it618_about'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$_G['siteurl'].it618_video_getrewrite('video_wap','lecturer@'.$lid,'plugin.php?id=it618_video:wap&pagetype=lecturer&cid='.$lid);
		
	}elseif($pagetype=='product'){
		$pid=intval($_GET['cid']);
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
		$wxshare_title=$it618_video_goods['it618_name'];
		$wxshare_imgUrl=it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']);
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_video_goods['it618_description'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		if($_GET['e']!=''){
			$wxshare_link=$_G['siteurl'].it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id'].'&e='.$_GET['e'],'?e='.$_GET['e']);
		}else{
			$wxshare_link=$_G['siteurl'].it618_video_getrewrite('video_wap','product@'.$it618_video_goods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$it618_video_goods['id']);
		}
		
	}elseif($pagetype=='lesson'){
		$lid=intval($_GET['cid']);
		$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($lid);
		$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_video['it618_pid']);
		
		if($it618_video_goods_video['it618_liveid']>0){
			$it618_video_live = C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid']);
			$wxshare_title=$it618_video_live['it618_name'];
			$wxshare_desc=$it618_video_live['it618_description'];
			if($wxshare_desc=='')$wxshare_desc=$it618_video_goods_video['it618_description'];
		}else{
			$wxshare_title=$it618_video_goods_video['it618_name'];
			$wxshare_desc=$it618_video_goods_video['it618_description'];
		}
		
		if($it618_video_goods_video['it618_videoimg']!=''){
			$wxshare_imgUrl=$it618_video_goods_video['it618_videoimg'];
		}else{
			$wxshare_imgUrl=it618_video_getwapppic($it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']);	
		}
		
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		
		if($wxshare_desc=='')$wxshare_desc=$it618_video_goods['it618_description'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$_G['siteurl'].it618_video_getrewrite('video_wap','lesson@'.$lid,'plugin.php?id=it618_video:wap&pagetype=lesson&cid='.$lid);
	}else{
		$wxshare_title=$it618_video['seotitle'];
		
		if($it618_video['video_wxlogo']!=''){
			$wxshare_imgUrl=$it618_video['video_wxlogo'];
		}else{
			$wxshare_imgUrl=$it618_video['video_logo'];
			$tmparr=explode('src="',$wxshare_imgUrl);
			$tmparr1=explode('"',$tmparr[1]);
			$wxshare_imgUrl=$tmparr1[0];
		}
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_video['seodescription'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$_G['siteurl'].it618_video_getrewrite('video_wap','','plugin.php?id=it618_video:wap');
	}
	
	if($wxshare_title!=''){
		$isshare=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_video/wxshare.php';
		$wxshare = new JSSDK($wx_appid, $wx_secret, $thisurl, DISCUZ_ROOT);
		$signPackage = $wxshare->getSignPackage();
	}
}

$wapbottomsubnav=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('wapbottomsubnav');
$wapbottomsubnavdefault=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('wapbottomsubnavdefault');
$footer_mall_wap=C::t('#it618_video#it618_video_set')->getsetvalue_by_setname('footer_mall_wap');

$searchurl=it618_video_getrewrite('video_wap','search@0','plugin.php?id=it618_video:wap&pagetype=search&cid=0&findkey=1','?findkey=1');

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	$getapplogin=it618_members_getapplogin($_GET['id']);
	if($appurl=it618_members_apploginok($_GET['token'])){
		dheader("location:$appurl");
	}
}

if($pagetype=='video'||$pagetype=='product'){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/appad.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_video/config/appad.php';
	}
	
	if($appad_browseragent!=''){
		$browseragent=explode(",",$appad_browseragent);
		for($i=0;$i<count($browseragent);$i++){
			if(strpos($_SERVER['HTTP_USER_AGENT'],$browseragent[$i])!==false){
				$appad_ishome=0;
				$appad_isproduct=0;
				break;
			}
		}
	}
	
	$it618_video_appad=getcookie('it618_video_appad');
	if($it618_video_appad!=''){
		$appad_isproduct=0;
	}
}

if($pagetype!='lesson'){
	if($pagetype=='product')$footercss='margin-bottom:80px;';else $footercss='margin-bottom:60px;';
}else{
	$footercss='display:none;';
}

if($IsGroup==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_group/group.func.php';
	$it618_group_wapad=it618_group_getad($_GET['id'],1);
}

require_once DISCUZ_ROOT.'./source/plugin/it618_video/wap/'.$pagetype.'.inc.php';
?>