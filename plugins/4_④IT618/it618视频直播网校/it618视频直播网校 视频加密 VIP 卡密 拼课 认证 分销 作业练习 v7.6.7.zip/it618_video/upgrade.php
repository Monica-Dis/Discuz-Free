<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
/*
	Install Uninstall Upgrade AutoStat System Code
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/message.php')){
	rename(DISCUZ_ROOT.'./source/plugin/it618_video/rewrite.php',DISCUZ_ROOT.'./source/plugin/it618_video/config/rewrite.php');
	rename(DISCUZ_ROOT.'./source/plugin/it618_video/message.php',DISCUZ_ROOT.'./source/plugin/it618_video/config/message.php');
	rename(DISCUZ_ROOT.'./source/plugin/it618_video/player.php',DISCUZ_ROOT.'./source/plugin/it618_video/config/player.php');
	rename(DISCUZ_ROOT.'./source/plugin/it618_video/templateset.php',DISCUZ_ROOT.'./source/plugin/it618_video/config/templateset.php');
}
DB::query("update ".DB::table('common_plugin')." set name='".lang('plugin/it618_video', 'it618_name')."' where identifier='it618_video'");

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_video_class_vipgroup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_vipgroup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_media_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_media_shopwmf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_wmf_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_media_wmf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_accessid` varchar(50) NOT NULL,
  `it618_accesskey` varchar(50) NOT NULL,
  `it618_endpoint` varchar(50) NOT NULL,
  `it618_wmfpath` varchar(255) NOT NULL,
  `it618_type` varchar(255) NOT NULL,
  `it618_size` int(10) unsigned NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  `it618_mediacount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mtscount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mediasize` float(9,2) NOT NULL DEFAULT '0',
  `it618_mtssize` float(9,2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_media` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_class_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_wmf_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_endpoint` varchar(255) NOT NULL,
  `it618_mediaid` varchar(255) NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_coverurl` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_duration` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_fps` float(9,2) NOT NULL DEFAULT '0',
  `it618_bitrate` float(9,2) NOT NULL DEFAULT '0',
  `it618_width` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_height` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_size` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mtscount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mtssize` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_media_mts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_wmf_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_wmfid` varchar(50) NOT NULL,
  `it618_wmfname` varchar(255) NOT NULL,
  `it618_media_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_actname` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_duration` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_fps` float(9,2) NOT NULL DEFAULT '0',
  `it618_bitrate` float(9,2) NOT NULL DEFAULT '0',
  `it618_width` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_height` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_size` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_lesson` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(255) NOT NULL,
  `it618_videocount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videotime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_lesson_exam` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_lid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_media_aclass` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_media_shopaoss` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_aoss_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_media_aoss` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_accessid` varchar(50) NOT NULL,
  `it618_accesskey` varchar(50) NOT NULL,
  `it618_endpoint` varchar(50) NOT NULL,
  `it618_bucket` varchar(255) NOT NULL,
  `it618_type` varchar(255) NOT NULL,
  `it618_size` int(10) unsigned NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  `it618_mediacount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mediasize` float(9,2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_media_audio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_aclass_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_aoss_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_endpoint` varchar(50) NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_time1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_size` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_chkstate` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_video_audio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_vid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(255) NOT NULL,
  `it618_videourl` varchar(1000) NOT NULL,
  `it618_videotime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videotime1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videotime2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videotime3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_play` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_gtype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_vid` int(10) unsigned NOT NULL,
  `it618_playtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_btime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_curtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_alltime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ip` varchar(20) NOT NULL,
  `it618_ips` varchar(1000) NOT NULL,
  `it618_playcode` varchar(32) NOT NULL,
  `it618_ucode` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name1` varchar(255) NOT NULL,
  `it618_order1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_timetype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_price` float(9,2) NOT NULL,
  `it618_saleprice` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ison` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_km` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_typeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_code` varchar(32) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_usedel` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_xgtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_salekm` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_typeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_code` varchar(32) NOT NULL,
  `it618_bz` varchar(32) NOT NULL,
  `it618_xgtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_time` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_islock` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_block` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopids` varchar(300) NOT NULL,
  `it618_pids` varchar(800) NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` varchar(50) NOT NULL,
  `it618_about` varchar(800) NOT NULL,
  `it618_bz` varchar(800) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_error` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_vid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tel` varchar(20) NOT NULL,
  `it618_content` varchar(2000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_play_pj` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_score1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pjjl` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_content` varchar(2000) NOT NULL,
  `it618_hfcontent` varchar(2000) NOT NULL,
  `it618_pjtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_play_pjpic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pjid` int(10) unsigned NOT NULL,
  `it618_pjpic` varchar(255) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_video_exam` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_vid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_power` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_video_pl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_vid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_content` varchar(2000) NOT NULL,
  `it618_hfcontent` varchar(2000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_hftime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_media_tieclass` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_media_tie` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_cid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(255) NOT NULL,
  `it618_url` varchar(1000) NOT NULL,
  `it618_time1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isautoplay` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_islive` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isuser` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_media_iframeclass` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_media_iframe` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_cid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(255) NOT NULL,
  `it618_url` varchar(1000) NOT NULL,
  `it618_isautoplay` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_islive` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isuser` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_exam_collect` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_cdn` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_cdnurl` varchar(200) NOT NULL,
  `it618_ossurl` varchar(200) NOT NULL,
  `it618_key` varchar(50) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  `it618_iscdnok` int(10) unsigned NOT NULL,
  `it618_iskeyok` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_shopliveset` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_liveset_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_liveset` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_accessid` varchar(50) NOT NULL,
  `it618_accesskey` varchar(50) NOT NULL,
  `it618_cdnkey` varchar(50) NOT NULL,
  `it618_ossbucket` varchar(255) NOT NULL,
  `it618_ossendpoint` varchar(255) NOT NULL,
  `it618_appname` varchar(50) NOT NULL,
  `it618_cnname` varchar(50) NOT NULL,
  `it618_domainname` varchar(255) NOT NULL,
  `it618_livetime` int(10) unsigned NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_sqtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_copytime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  `it618_livecount` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_live_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_liveid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tel` varchar(50) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_live` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_liveset_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_lid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(255) NOT NULL,
  `it618_btime` int(10) unsigned NOT NULL,
  `it618_etime` int(10) unsigned NOT NULL,
  `it618_livetime` int(10) unsigned NOT NULL,
  `it618_ossbucket` varchar(255) NOT NULL,
  `it618_ossendpoint` varchar(255) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  `it618_description` varchar(1000) NOT NULL,
  `it618_isuser` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_streamname` varchar(32) NOT NULL,
  `it618_rtmpcode` varchar(300) NOT NULL,
  `it618_flvurl` varchar(300) NOT NULL,
  `it618_m3u8url` varchar(300) NOT NULL,
  `it618_forbid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_forbidtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isonline` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_chkstate` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_media_liveclass` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_media_live` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_class_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_liveset_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_live_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_endpoint` varchar(255) NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_coverurl` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_duration` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_size` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_chkstate` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_tie` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_fid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_first` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mids` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_shop_subscribe` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_shop_push` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_url` varchar(150) NOT NULL,
  `it618_message` varchar(800) NOT NULL,
  `it618_allcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_wxcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_telcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_collect` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_video_mediawork` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_code` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_shop'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_ulogo', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_ulogo` varchar(255) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_waplogo', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_waplogo` varchar(255) NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_logourl` varchar(255) NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_waplogourl` varchar(255) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_isdel', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_isdel` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}
if(!in_array('it618_issale', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_issale` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}
if(!in_array('it618_issalekm', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_issalekm` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_ischeck', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_ischeck` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}
if(!in_array('it618_ischeck_audio', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_ischeck_audio` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}
if(!in_array('it618_ischeck_live', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_ischeck_live` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}
if(!in_array('it618_istiemedia', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_istiemedia` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}
if(!in_array('it618_isiframemedia', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_isiframemedia` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}
if(!in_array('it618_message', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_message` mediumtext NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_classid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_classid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_subscribes', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_subscribes` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_views', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_views` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_order', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_order` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_tongji', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_tongji` varchar(1000) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_liveset', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_liveset` varchar(1000) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_livetime', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_livetime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_isqunchat', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_isqunchat` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_qunchattime', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_qunchattime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_wxmessagecount', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop')." add `it618_wxmessagecount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_goods_km'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_shopid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_km')." add `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_isadmin', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_km')." add `it618_isadmin` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "update ".DB::table('it618_video_goods_km')." set it618_isadmin=1;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_shop_subscribe'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_isqunchat', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop_subscribe')." add `it618_isqunchat` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_tel', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop_subscribe')." add `it618_tel` varchar(50) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_shop_push'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_istelmessage', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_shop_push')." add `it618_istelmessage` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_class1'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_vipgroupid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_class1')." add `it618_vipgroupid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_goods'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_shoporder', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_shoporder` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_lessoncount', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_lessoncount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_allvideocount', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_allvideocount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "update ".DB::table('it618_video_goods')." set it618_allvideocount=it618_videocount;"; 
	DB::query($sql);
}
if(!in_array('it618_isvip', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_isvip` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_isbm', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_isbm` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_isprotect', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_isprotect` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_issecret', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_issecret` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "alter table ".DB::table('it618_video_goods_data')." modify column it618_dataurl varchar(1000);"; 
	DB::query($sql);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_video'));
	while($it618_video_goods_video = DB::fetch($query)) {
		
		if($it618_video_media_mts=C::t('#it618_video#it618_video_media_mts')->fetch_by_url($it618_video_goods_video['it618_videourl'])){
			
			$tmparr=it618_video_getvideotimearr($it618_video_media_mts['it618_duration']);
			
			C::t('#it618_video#it618_video_goods_video')->update($it618_video_goods_video['id'],array(
				'it618_videotime' => $it618_video_media_mts['it618_duration'],
				'it618_videotime1' => $tmparr[0],
				'it618_videotime2' => $tmparr[1],
				'it618_videotime3' => $tmparr[2],
			));
		}
	}
}

if(!in_array('it618_isuser', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_isuser` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}
if(!in_array('it618_isip', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_isip` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_isaddr', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_isaddr` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}
if(!in_array('it618_secretusers', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_secretusers` varchar(8000) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_shopuid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_shopuid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods'));
	while($it618_video_goods = DB::fetch($query)) {
		$it618_video_shop = C::t('#it618_video#it618_video_shop')->fetch_by_id($it618_video_goods['it618_shopid']);
		C::t('#it618_video#it618_video_goods')->update($it618_video_goods['id'],array(
			'it618_shopuid' => $it618_video_shop['it618_uid']
		));
	}
}
if(!in_array('it618_gtype', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_gtype` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}
if(!in_array('it618_class1_id1', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_class1_id1` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_class1_id2` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_class1_id3` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_class2_id1` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_class2_id2` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_class2_id3` int(10) unsigned NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_jfid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_video_sale')." add `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_video_gwcsale')." add `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}
if(!in_array('it618_score', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_score` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
	$sql = "Alter table ".DB::table('it618_video_sale')." add `it618_score` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_video_sale')." add `it618_quanmoney` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_video_gwcsale')." add `it618_score` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
	$sql = "Alter table ".DB::table('it618_video_gwcsale')." add `it618_quanmoney` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_video_gwc')." add `it618_pricescore` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_video_gwc')." add `it618_quanmoney` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}
if(!in_array('it618_plays', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_plays` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_plays` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
	$sql = "Alter table ".DB::table('it618_video_goods_video_audio')." add `it618_plays` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}
if(!in_array('it618_ptypename', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_ptypename` varchar(255) NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_ptypename1` varchar(255) NOT NULL;"; 
	DB::query($sql);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_sale')." where it618_tel!='' and it618_state!=0");
	while($it618_video_sale = DB::fetch($query)) {
		$count=C::t('#it618_video#it618_video_goods_time')->count_by_uid_pid($it618_video_sale['it618_uid'],$it618_video_sale['it618_pid']);
		if($count==0){
			C::t('#it618_video#it618_video_goods_time')->insert(array(
				'it618_shopid' => $it618_video_sale['it618_shopid'],
				'it618_pid' => $it618_video_sale['it618_pid'],
				'it618_uid' => $it618_video_sale['it618_uid'],
				'it618_etime' => 0
			), true);
		}
	}
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_goods_type'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_lid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_type')." add `it618_lid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$sql = "update ".DB::table('it618_video_goods_type')." set it618_timetype=6 where it618_time=0;"; 
	DB::query($sql);
}

if(!in_array('it618_vid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_type')." add `it618_vid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_typename', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_type')." add `it618_typename` varchar(255) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_typeabout', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_type')." add `it618_typeabout` varchar(1000) NOT NULL;"; 
	DB::query($sql);
}

if(in_array('it618_index1', $col_field)){		
	$sql = "update ".DB::table('it618_video_goods_type')." set it618_ison=0 where it618_index1>0;"; 
	DB::query($sql);
}

if(!in_array('it618_counttype', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_type')." add `it618_counttype` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_goods_lesson'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_type', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_lesson')." add `it618_type` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}

if(!in_array('it618_url', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_lesson')." add `it618_url` varchar(255) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_testids', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_lesson')." add `it618_testids` varchar(3000) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_issale', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_lesson')." add `it618_issale` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods_lesson')." add `it618_price` float(9,2) NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods_lesson')." add `it618_saleprice` float(9,2) NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods_lesson')." add `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods_lesson')." add `it618_score` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_issale` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_price` float(9,2) NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_saleprice` float(9,2) NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_score` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_salecount', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_lesson')." add `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods')." add `it618_salemoney` float(9,2) NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods_lesson')." add `it618_salemoney` float(9,2) NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_salemoney` float(9,2) NOT NULL;"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_ison` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
		
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_live')." where it618_isok=0");
	while($it618_video_live = DB::fetch($query)) {
		$sql = "update ".DB::table('it618_video_goods_video')." set it618_isuser=".$it618_video_live['it618_isuser']." where it618_liveid=".$it618_video_live['id'].";"; 
		DB::query($sql);
	}
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods'));
	while($it618_video_goods = DB::fetch($query)) {
		$it618_salemoney=DB::result_first("SELECT SUM(it618_price*it618_count) FROM ".DB::table('it618_video_sale')." WHERE it618_pid=".$it618_video_goods['id']." AND it618_state!=0 AND it618_tel<>''");
		if($it618_salemoney=='')$it618_salemoney=0;
		$sql = "update ".DB::table('it618_video_goods')." set it618_salemoney=".$it618_salemoney." where id=".$it618_video_goods['id'].";"; 
		DB::query($sql);
	}
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_goods_video'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_ismessagetb', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_ismessagetb` int(10) unsigned NOT NULL DEFAULT '0'"; 
	DB::query($sql);
}

if(!in_array('it618_ismessagedefault', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_ismessagedefault` int(10) unsigned NOT NULL DEFAULT '0'"; 
	DB::query($sql);
}

if(!in_array('it618_ischatdefault', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_ischatdefault` int(10) unsigned NOT NULL DEFAULT '0'"; 
	DB::query($sql);
}

if(!in_array('it618_messagename', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_messagename` varchar(10) NOT NULL"; 
	DB::query($sql);
}

if(!in_array('it618_usercode', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_usercode` varchar(255) NOT NULL"; 
	DB::query($sql);
}

if(!in_array('it618_usercodeabout', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_usercodeabout` mediumtext NOT NULL"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_sale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_lid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_sale')." add `it618_lid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_vid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_sale')." add `it618_vid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_pinsaleid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_sale')." add `it618_pinsaleid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_vipzk', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_sale')." add `it618_vipzk` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_sale')." add `it618_sfmoney` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_sale')." add `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$sql = "Alter table ".DB::table('it618_video_gwcsale')." add `it618_vipzk` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_gwcsale')." add `it618_sfmoney` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_gwcsale')." add `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_sale'));
	while($it618_video_sale = DB::fetch($query)) {
		$it618_sfmoney = $it618_video_sale['it618_price']*$it618_video_sale['it618_count']-$it618_video_sale['it618_quanmoney'];
		$it618_sfscore = $it618_video_sale['it618_score']*$it618_video_sale['it618_count'];
		$sql = "update ".DB::table('it618_video_sale')." set it618_sfmoney=$it618_sfmoney,it618_sfscore=$it618_sfscore where id=".$it618_video_sale['id']; 
		DB::query($sql);
	}
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_gwc'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_lid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_gwc')." add `it618_lid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_vid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_gwc')." add `it618_vid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_iseditprice', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_gwc')." add `it618_iseditprice` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_gwcsale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_lid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_gwcsale')." add `it618_lid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_vid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_gwcsale')." add `it618_vid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_goods_time'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_lid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_time')." add `it618_lid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_vid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_time')." add `it618_vid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_media_aoss'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_osstype', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_media_aoss')." add `it618_osstype` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_media_aclass'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_osstype', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_media_aclass')." add `it618_osstype` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_media_audio'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_osstype', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_media_audio')." add `it618_osstype` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_sale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_gtypeid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_sale')." add `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_count', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_sale')." add `it618_count` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}

if(!in_array('it618_tuijid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_gwc')." add `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_gwcsale')." add `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_sale')." add `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_sale')." add `it618_tuitcbl` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_sale')." add `it618_tuitc` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_gwcsale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_gtypeid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_gwcsale')." add `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_count', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_gwcsale')." add `it618_count` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_gwcsale_main'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_moneybz', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_gwcsale_main')." add `it618_moneybz` varchar(255) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_gwc'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_money', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_gwc')." add `it618_money` float(9,2) NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_gtypeid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_gwc')." add `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_count', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_gwc')." add `it618_count` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_media'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_chkstate', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_media')." add `it618_chkstate` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}

if(!in_array('it618_urldel', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_media')." add `it618_urldel` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_media_wmf'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_isurldel', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_media_wmf')." add `it618_isurldel` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_media_audio'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_ext', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_media_audio')." add `it618_ext` varchar(10) NOT NULL;"; 
	DB::query($sql);  
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_play_pj'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_notecontent', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_play_pj')." add `it618_notecontent` mediumtext NOT NULL;"; 
	DB::query($sql);  
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_goods_video'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_lid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_lid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}

if(!in_array('it618_datacount', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_datacount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}

if(!in_array('it618_datasize', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_datasize` float(9,2) NOT NULL;"; 
	DB::query($sql);  
}

if(!in_array('it618_message', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_message` mediumtext NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('it618_islive', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_islive` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}

if(!in_array('it618_ischat', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_ischat` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);  
}

if(!in_array('it618_previewtime', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_previewtime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}

if(!in_array('it618_liveid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_liveid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
}
if(!in_array('it618_livebtime', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_video')." add `it618_livebtime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);  
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_video')." where it618_liveid>0");
	while($it618_video_goods_video = DB::fetch($query)) {
		
		if($it618_video_live=C::t('#it618_video#it618_video_live')->fetch_by_id($it618_video_goods_video['it618_liveid'])){
			
			C::t('#it618_video#it618_video_goods_video')->update($it618_video_goods_video['id'],array(
				'it618_livebtime' => $it618_video_live['it618_btime']
			));
		}
	}
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_goods_data'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_isuser', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_data')." add `it618_isuser` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);  
}

if(!in_array('it618_datasizestr', $col_field)){
	$sql = "alter table ".DB::table('it618_video_goods_data')." add `it618_datasizestr` varchar(30) NOT NULL;"; 
	DB::query($sql);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_data'));
	while($it618_video_goods_data = DB::fetch($query)) {
		
		$size=$it618_video_goods_data['it618_datasize'];
		$format = 'M';
		$size1=$size;
		$size /= pow(1024, 2); 
		$getsize=number_format($size, 2);
		if($getsize<1){
			$format = 'K';
			$size1 /= pow(1024, 1); 
			$getsize=number_format($size1, 2);
		}
		
		C::t('#it618_video#it618_video_goods_data')->update($it618_video_goods_data['id'],array(
			'it618_datasizestr' => $getsize.$format
		));
	}
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_bank'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}
if(!in_array('it618_wxname', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_bank')." add `it618_wxname` varchar(50) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_wx', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_bank')." add `it618_wx` varchar(100) NOT NULL;"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_cdn'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_ishttps', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_cdn')." add `it618_ishttps` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_liveset'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_pushdomainname', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_liveset')." add `it618_pushdomainname` varchar(255) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_pushcdnkey', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_liveset')." add `it618_pushcdnkey` varchar(50) NOT NULL;"; 
	DB::query($sql);
}
if(!in_array('it618_pcflash', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_liveset')." add `it618_pcflash` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql);
}
if(!in_array('it618_liveordertime', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_liveset')." add `it618_liveordertime` int(10) unsigned NOT NULL DEFAULT '3';"; 
	DB::query($sql);
}
if(!in_array('it618_iseditetime', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_liveset')." add `it618_iseditetime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
	$sql = "Alter table ".DB::table('it618_video_live')." add `it618_iseditetime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_live'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_vid', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_live')." add `it618_vid` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

if(!in_array('it618_usercode', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_live')." add `it618_usercode` varchar(255) NOT NULL"; 
	DB::query($sql);
}

if(!in_array('it618_savetype', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_live')." add `it618_savetype` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_goods_lesson_exam'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_power', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_goods_lesson_exam')." add `it618_power` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_video_bottomnav'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_curimg', $col_field)){
	$sql = "Alter table ".DB::table('it618_video_bottomnav')." add `it618_curimg` varchar(255) NOT NULL;"; 
	DB::query($sql);
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczFfZDM4ZmMyZmFjYjk0ODZhYTg0MmExODNkNzkwYWJhNDcucG5n'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE1M19mYzdhNzMxODczNGJkMWJiMTBmNWNiZGRjMTQ2YWE4My5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE1OF8yZDAzYmRlNDQwMDlhNWEwNGZlNTQ2MDg5ZTMxZjZlYy5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE4NF84NTI2NmJmMmQ4NTZjMjliMzE2MWFmMzgxNTAyMWM3NS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE4NV84YTBjOWRkNzhkNjg1ZDFmZjA1N2NkMWY3ZDIxM2M1YS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE4Nl9lODIwNGE0NzFmOGMzNjVlNjg5ZDVlNGRmNjE5MzM4Ni5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE4OV8wOGJmMjk3NmRkYjc2YjFiMTRlOGI3OWM4MWQ4MWQ1OS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE5MF8wZGUwNGVmYzJmOWUxZmE0YWY1ZjE1NTA5YjUxYzNhNS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE3Ml84MzcyZjRmYjdiNDZjMzJmMjJhOTQ2MWFmMWQzODY1NC5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE3M18wYmI2MGUwZWE5NDZlOTM1ZDVlY2VjZmZlOTNkMDY0ZS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE3NV80ZjZkNTQyMjk5NjVmMDkyNDIwNDY5Y2Y3ODIxNzM0Ny5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE3Nl9hY2EyMDc1NjExZjRmY2I4NjdhMGIwZTA3ZjYyZTQxOS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE3Ml84MzcyZjRmYjdiNDZjMzJmMjJhOTQ2MWFmMWQzODY1NC5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE3M18wYmI2MGUwZWE5NDZlOTM1ZDVlY2VjZmZlOTNkMDY0ZS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE3NV80ZjZkNTQyMjk5NjVmMDkyNDIwNDY5Y2Y3ODIxNzM0Ny5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE3Nl9hY2EyMDc1NjExZjRmY2I4NjdhMGIwZTA3ZjYyZTQxOS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE4NF84NTI2NmJmMmQ4NTZjMjliMzE2MWFmMzgxNTAyMWM3NS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE4NV84YTBjOWRkNzhkNjg1ZDFmZjA1N2NkMWY3ZDIxM2M1YS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE4Nl9lODIwNGE0NzFmOGMzNjVlNjg5ZDVlNGRmNjE5MzM4Ni5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2Rpc2N1el9wbHVnaW5faXQ2MThfdmlkZW8ueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2Rpc2N1el9wbHVnaW5faXQ2MThfdmlkZW9fU0NfR0JLLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2Rpc2N1el9wbHVnaW5faXQ2MThfdmlkZW9fU0NfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2Rpc2N1el9wbHVnaW5faXQ2MThfdmlkZW9fVENfQklHNS54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2Rpc2N1el9wbHVnaW5faXQ2MThfdmlkZW9fVENfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2xhbmd1YWdlLlRDX0JJRzUucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2xhbmd1YWdlLlRDX1VURjgucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2luc3RhbGwucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL3VwZ3JhZGUucGhw'));
?>