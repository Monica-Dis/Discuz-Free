<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_video_shop`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_shop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_classid` int(10) unsigned NOT NULL,
  `it618_name` varchar(200) NOT NULL,
  `it618_tel` varchar(200) NOT NULL,
  `it618_msgtel` varchar(20) NOT NULL,
  `it618_msgisok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_qq` varchar(200) NOT NULL,
  `it618_dianhua` varchar(200) NOT NULL,
  `it618_kefuqq` varchar(200) NOT NULL,
  `it618_kefuqqname` varchar(200) NOT NULL,
  `it618_kefuwx` varchar(200) NOT NULL,
  `it618_kefuwxname` varchar(200) NOT NULL,
  `it618_yytime` varchar(200) NOT NULL,
  `it618_ulogo` varchar(255) NOT NULL,
  `it618_logo` varchar(255) NOT NULL,
  `it618_waplogo` varchar(255) NOT NULL,
  `it618_logourl` varchar(255) NOT NULL,
  `it618_waplogourl` varchar(255) NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_tongji` varchar(1000) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_isdel` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_issale` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_issalekm` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ischeck` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_ischeck_audio` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_ischeck_live` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_istiemedia` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_isiframemedia` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_liveset` varchar(1000) NOT NULL,
  `it618_livetime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL,
  `it618_htstate` int(10) unsigned NOT NULL,
  `it618_money` float(9,2) NOT NULL DEFAULT '0',
  `it618_price` float(9,2) NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '1000',
  `it618_tcbl` float(9,2) NOT NULL DEFAULT '5',
  `it618_messagecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_subscribes` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isqunchat` int(10) unsigned NOT NULL,
  `it618_qunchattime` int(10) unsigned NOT NULL,
  `it618_wxmessagecount` int(10) unsigned NOT NULL,
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_rztime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_htetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_shop_subscribe`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_shop_subscribe` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isquanchat` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tel` varchar(50) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_shop_push`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_shop_push` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_url` varchar(150) NOT NULL,
  `it618_message` varchar(800) NOT NULL,
  `it618_istelmessage` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_allcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_wxcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_telcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_shopclass`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_shopclass` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_nav`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_class1`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_class1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_classname` varchar(255) NOT NULL,
  `it618_pj` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_goodscount` int(10) unsigned NOT NULL,
  `it618_wapgoodscount` int(10) unsigned NOT NULL,
  `it618_img` varchar(255) NOT NULL DEFAULT '',
  `it618_url` varchar(255) NOT NULL,
  `it618_vipgroupid` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_class2`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_class2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_class_vipgroup`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_class_vipgroup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_goods_vipgroup`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_vipgroup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_focus`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_media_class`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_media_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_media_aclass`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_media_aclass` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_osstype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_media_tieclass`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_media_tieclass` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_media_tie`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_media_tie` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_cid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(255) NOT NULL,
  `it618_url` varchar(1000) NOT NULL,
  `it618_time1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isautoplay` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_islive` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isuser` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_tie`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_tie` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_fid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_first` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mids` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_media_iframeclass`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_media_iframeclass` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_media_iframe`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_media_iframe` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_cid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_type` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(255) NOT NULL,
  `it618_url` varchar(1000) NOT NULL,
  `it618_isautoplay` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_islive` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isuser` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_media_shopaoss`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_media_shopaoss` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_aoss_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_media_aoss`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_media_aoss` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_osstype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_accessid` varchar(50) NOT NULL,
  `it618_accesskey` varchar(50) NOT NULL,
  `it618_endpoint` varchar(50) NOT NULL,
  `it618_bucket` varchar(255) NOT NULL,
  `it618_type` varchar(255) NOT NULL,
  `it618_size` int(10) unsigned NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  `it618_mediacount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mediasize` float(9,2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_media_audio`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_media_audio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_aclass_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_aoss_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_endpoint` varchar(50) NOT NULL,
  `it618_osstype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_ext` varchar(10) NOT NULL,
  `it618_time1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_size` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_chkstate` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_media_shopwmf`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_media_shopwmf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_wmf_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_media_wmf`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_media_wmf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_accessid` varchar(50) NOT NULL,
  `it618_accesskey` varchar(50) NOT NULL,
  `it618_endpoint` varchar(50) NOT NULL,
  `it618_wmfpath` varchar(255) NOT NULL,
  `it618_type` varchar(255) NOT NULL,
  `it618_size` int(10) unsigned NOT NULL,
  `it618_about` varchar(1000) NOT NULL,
  `it618_isurldel` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  `it618_mediacount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mtscount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mediasize` float(9,2) NOT NULL DEFAULT '0',
  `it618_mtssize` float(9,2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_media`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_media` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_class_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_wmf_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_endpoint` varchar(255) NOT NULL,
  `it618_mediaid` varchar(255) NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_coverurl` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_urldel` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_duration` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_fps` float(9,2) NOT NULL DEFAULT '0',
  `it618_bitrate` float(9,2) NOT NULL DEFAULT '0',
  `it618_width` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_height` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_size` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mtscount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_mtssize` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_chkstate` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_media_mts`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_media_mts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_wmf_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_wmfid` varchar(50) NOT NULL,
  `it618_wmfname` varchar(255) NOT NULL,
  `it618_media_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_actname` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_duration` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_fps` float(9,2) NOT NULL DEFAULT '0',
  `it618_bitrate` float(9,2) NOT NULL DEFAULT '0',
  `it618_width` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_height` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_size` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_shopliveset`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_shopliveset` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_liveset_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_liveset`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_liveset` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_accessid` varchar(50) NOT NULL,
  `it618_accesskey` varchar(50) NOT NULL,
  `it618_ossbucket` varchar(255) NOT NULL,
  `it618_ossendpoint` varchar(255) NOT NULL,
  `it618_appname` varchar(50) NOT NULL,
  `it618_cnname` varchar(50) NOT NULL,
  `it618_domainname` varchar(255) NOT NULL,
  `it618_cdnkey` varchar(50) NOT NULL,
  `it618_pushdomainname` varchar(255) NOT NULL,
  `it618_pushcdnkey` varchar(50) NOT NULL,
  `it618_pcflash` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_liveordertime` int(10) unsigned NOT NULL,
  `it618_livetime` int(10) unsigned NOT NULL,
  `it618_iseditetime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_about` varchar(1000) NOT NULL,
  `it618_sqtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_copytime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  `it618_livecount` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_live_order`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_live_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_liveid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tel` varchar(50) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_live`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_live` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_liveset_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_lid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_vid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(255) NOT NULL,
  `it618_btime` int(10) unsigned NOT NULL,
  `it618_etime` int(10) unsigned NOT NULL,
  `it618_livetime` int(10) unsigned NOT NULL,
  `it618_iseditetime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_savetype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ossbucket` varchar(255) NOT NULL,
  `it618_ossendpoint` varchar(255) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  `it618_description` varchar(1000) NOT NULL,
  `it618_isuser` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_usercode` varchar(255) NOT NULL,
  `it618_streamname` varchar(32) NOT NULL,
  `it618_rtmpcode` varchar(300) NOT NULL,
  `it618_flvurl` varchar(300) NOT NULL,
  `it618_m3u8url` varchar(300) NOT NULL,
  `it618_forbid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_forbidtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isonline` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_chkstate` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_media_liveclass`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_media_liveclass` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_media_live`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_media_live` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_class_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_liveset_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_live_id` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_endpoint` varchar(255) NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_coverurl` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_duration` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_size` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_chkstate` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_goods`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_class2_id` int(10) unsigned NOT NULL,
  `it618_class1_id1` int(10) unsigned NOT NULL,
  `it618_class2_id1` int(10) unsigned NOT NULL,
  `it618_class1_id2` int(10) unsigned NOT NULL,
  `it618_class2_id2` int(10) unsigned NOT NULL,
  `it618_class1_id3` int(10) unsigned NOT NULL,
  `it618_class2_id3` int(10) unsigned NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_ptypename` varchar(255) NOT NULL,
  `it618_ptypename1` varchar(255) NOT NULL,
  `it618_gtype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_description` varchar(1000) NOT NULL,
  `it618_seokeywords` varchar(1000) NOT NULL,
  `it618_seodescription` varchar(1000) NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_saleprice` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jfbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_xgtype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgtime1` varchar(20) NOT NULL,
  `it618_xgtime2` varchar(20) NOT NULL,
  `it618_isbm` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isprotect` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_picbig` varchar(255) NOT NULL,
  `it618_picbig1` varchar(255) NOT NULL,
  `it618_picbig2` varchar(255) NOT NULL,
  `it618_picbig3` varchar(255) NOT NULL,
  `it618_picbig4` varchar(255) NOT NULL,
  `it618_picsmall` varchar(255) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shoporder` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_plays` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_lessoncount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_allvideocount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videocount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videotime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salemoney` float(9,2) NOT NULL,
  `it618_pjpfstr` varchar(255) NOT NULL,
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isvip` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_issecret` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isuser` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_isip` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isaddr` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_secretusers` varchar(8000) NOT NULL,
  `it618_shopuid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_goods_type`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_lid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_vid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_typename` varchar(255) NOT NULL,
  `it618_typeabout` varchar(1000) NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name1` varchar(255) NOT NULL,
  `it618_order1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_timetype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_counttype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_price` float(9,2) NOT NULL,
  `it618_saleprice` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ison` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_goods_lesson`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_lesson` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_type` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_name` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_testids` varchar(3000) NOT NULL,
  `it618_videocount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videotime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_issale` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_price` float(9,2) NOT NULL,
  `it618_saleprice` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salemoney` float(9,2) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_goods_video_exam`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_video_exam` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_vid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_power` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_goods_video`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_video` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_lid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_liveid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_livebtime` int(10) unsigned NOT NULL,
  `it618_name` varchar(255) NOT NULL,
  `it618_description` varchar(1000) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_messagename` varchar(10) NOT NULL,
  `it618_ismessagetb` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ismessagedefault` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videoimg` varchar(255) NOT NULL,
  `it618_videourl` varchar(1000) NOT NULL,
  `it618_videotype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videotime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videotime1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videotime2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videotime3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_islive` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ischat` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ischatdefault` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isuser` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_usercode` varchar(255) NOT NULL,
  `it618_usercodeabout` mediumtext NOT NULL,
  `it618_previewtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_datacount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_datasize` float(9,2) NOT NULL,
  `it618_issale` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_price` float(9,2) NOT NULL,
  `it618_saleprice` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salemoney` float(9,2) NOT NULL,
  `it618_ison` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_plays` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_goods_video_pl`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_video_pl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_vid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_content` varchar(2000) NOT NULL,
  `it618_hfcontent` varchar(2000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_hftime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_goods_video_audio`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_video_audio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_vid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(255) NOT NULL,
  `it618_videourl` varchar(1000) NOT NULL,
  `it618_videotime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videotime1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videotime2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_videotime3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_goods_data`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_vid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_name` varchar(255) NOT NULL,
  `it618_dataurl` varchar(1000) NOT NULL,
  `it618_datatype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_datasize` float(9,2) NOT NULL,
  `it618_datasizestr` varchar(30) NOT NULL,
  `it618_isuser` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_play`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_play` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_gtype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_vid` int(10) unsigned NOT NULL,
  `it618_playtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_btime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_curtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_alltime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ip` varchar(20) NOT NULL,
  `it618_ips` varchar(1000) NOT NULL,
  `it618_playcode` varchar(32) NOT NULL,
  `it618_ucode` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_error`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_error` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_vid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tel` varchar(20) NOT NULL,
  `it618_content` varchar(2000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_play_pj`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_play_pj` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_score1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score2` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score3` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score4` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pjjl` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_content` varchar(2000) NOT NULL,
  `it618_hfcontent` varchar(2000) NOT NULL,
  `it618_notecontent` mediumtext NOT NULL,
  `it618_pjtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_play_pjpic`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_play_pjpic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pjid` int(10) unsigned NOT NULL,
  `it618_pjpic` varchar(255) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_gwcid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_lid` int(10) unsigned NOT NULL,
  `it618_vid` int(10) unsigned NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_price` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_quanmoney` float(9,2) NOT NULL,
  `it618_vipzk` float(9,2) NOT NULL DEFAULT '0',
  `it618_sfmoney` float(9,2) NOT NULL,
  `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jfbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tc` float(9,2) NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuitcbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tuitc` float(9,2) NOT NULL DEFAULT '0',
  `it618_pinsaleid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_goods_km`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_km` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isadmin` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_typeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_code` varchar(32) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_usedel` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_xgtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_salekm`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_salekm` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_typeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_code` varchar(32) NOT NULL,
  `it618_bz` varchar(32) NOT NULL,
  `it618_xgtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_goods_time`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_time` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_lid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_vid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_islock` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_goods_block`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_goods_block` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopids` varchar(300) NOT NULL,
  `it618_pids` varchar(800) NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` varchar(50) NOT NULL,
  `it618_about` varchar(800) NOT NULL,
  `it618_bz` varchar(800) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_gwc`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_gwc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_lid` int(10) unsigned NOT NULL,
  `it618_vid` int(10) unsigned NOT NULL,
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_price` float(9,2) NOT NULL DEFAULT '0',
  `it618_pricescore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_money` float(9,2) NOT NULL DEFAULT '0',
  `it618_quanmoney` float(9,2) NOT NULL DEFAULT '0',
  `it618_iseditprice` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_gwcsale_main`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_gwcsale_main` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_moneybz` varchar(255) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_gwcsale`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_gwcsale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_gwcid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_shopid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_lid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_vid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_gtypeid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_tuijid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_price` float(9,2) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_quanmoney` float(9,2) NOT NULL,
  `it618_vipzk` float(9,2) NOT NULL DEFAULT '0',
  `it618_sfmoney` float(9,2) NOT NULL,
  `it618_sfscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jfbl` float(9,2) NOT NULL DEFAULT '0',
  `it618_tel` varchar(20) NOT NULL,
  `it618_bz` varchar(2000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_bank`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_bank` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_name` varchar(50) NOT NULL,
  `it618_bankname` varchar(200) NOT NULL,
  `it618_bankid` varchar(50) NOT NULL,
  `it618_bankaddr` varchar(50) NOT NULL,
  `it618_alipayname` varchar(50) NOT NULL,
  `it618_alipay` varchar(100) NOT NULL,
  `it618_wxname` varchar(50) NOT NULL,
  `it618_wx` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_txbl`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_txbl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_num1` int(10) unsigned NOT NULL,
  `it618_num2` int(10) unsigned NOT NULL,
  `it618_bl` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_cdn`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_cdn` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_cdnurl` varchar(200) NOT NULL,
  `it618_ossurl` varchar(200) NOT NULL,
  `it618_key` varchar(50) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL,
  `it618_ishttps` int(10) unsigned NOT NULL,
  `it618_iscdnok` int(10) unsigned NOT NULL,
  `it618_iskeyok` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_tx`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_tx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_shopid` int(10) unsigned NOT NULL,
  `it618_price` float(9,2) NOT NULL,
  `it618_bl` float(9,2) NOT NULL,
  `it618_type` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_bz` varchar(1000) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_jfhl`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_jfhl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_jfid` int(10) unsigned NOT NULL,
  `it618_hl` float(9,3) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_set`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_style`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_style` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_wapstyle`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_iconav`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_iconav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_gonggao`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_diy`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_diy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(100) NOT NULL,
  `it618_sql` varchar(200) NOT NULL,
  `it618_type` varchar(50) NOT NULL,
  `it618_modecode` mediumtext NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_isjs` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_catchtime` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_findkey`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_findkey` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_key` varchar(200) NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_collect`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_collect` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_bottomnav`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_curimg` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_videowork`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_videowork` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_code` varchar(32) NOT NULL,
  `it618_video` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_mediawork`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_mediawork` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_code` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_video_salework`;
CREATE TABLE IF NOT EXISTS `pre_it618_video_salework` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczFfZDM4ZmMyZmFjYjk0ODZhYTg0MmExODNkNzkwYWJhNDcucG5n'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE1M19mYzdhNzMxODczNGJkMWJiMTBmNWNiZGRjMTQ2YWE4My5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE1OF8yZDAzYmRlNDQwMDlhNWEwNGZlNTQ2MDg5ZTMxZjZlYy5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE4NF84NTI2NmJmMmQ4NTZjMjliMzE2MWFmMzgxNTAyMWM3NS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE4NV84YTBjOWRkNzhkNjg1ZDFmZjA1N2NkMWY3ZDIxM2M1YS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE4Nl9lODIwNGE0NzFmOGMzNjVlNjg5ZDVlNGRmNjE5MzM4Ni5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE4OV8wOGJmMjk3NmRkYjc2YjFiMTRlOGI3OWM4MWQ4MWQ1OS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE5MF8wZGUwNGVmYzJmOWUxZmE0YWY1ZjE1NTA5YjUxYzNhNS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE3Ml84MzcyZjRmYjdiNDZjMzJmMjJhOTQ2MWFmMWQzODY1NC5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE3M18wYmI2MGUwZWE5NDZlOTM1ZDVlY2VjZmZlOTNkMDY0ZS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE3NV80ZjZkNTQyMjk5NjVmMDkyNDIwNDY5Y2Y3ODIxNzM0Ny5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE3Nl9hY2EyMDc1NjExZjRmY2I4NjdhMGIwZTA3ZjYyZTQxOS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE3Ml84MzcyZjRmYjdiNDZjMzJmMjJhOTQ2MWFmMWQzODY1NC5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE3M18wYmI2MGUwZWE5NDZlOTM1ZDVlY2VjZmZlOTNkMDY0ZS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE3NV80ZjZkNTQyMjk5NjVmMDkyNDIwNDY5Y2Y3ODIxNzM0Ny5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE3Nl9hY2EyMDc1NjExZjRmY2I4NjdhMGIwZTA3ZjYyZTQxOS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE4NF84NTI2NmJmMmQ4NTZjMjliMzE2MWFmMzgxNTAyMWM3NS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE4NV84YTBjOWRkNzhkNjg1ZDFmZjA1N2NkMWY3ZDIxM2M1YS5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2tpbmRlZGl0b3IvZGF0YS9zaG9wMS9zbWFsbGltYWdlcy9nb29kczE4Nl9lODIwNGE0NzFmOGMzNjVlNjg5ZDVlNGRmNjE5MzM4Ni5wbmc='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2Rpc2N1el9wbHVnaW5faXQ2MThfdmlkZW8ueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2Rpc2N1el9wbHVnaW5faXQ2MThfdmlkZW9fU0NfR0JLLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2Rpc2N1el9wbHVnaW5faXQ2MThfdmlkZW9fU0NfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2Rpc2N1el9wbHVnaW5faXQ2MThfdmlkZW9fVENfQklHNS54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2Rpc2N1el9wbHVnaW5faXQ2MThfdmlkZW9fVENfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2xhbmd1YWdlLlRDX0JJRzUucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2xhbmd1YWdlLlRDX1VURjgucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL3VwZ3JhZGUucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2l0NjE4X3ZpZGVvL2luc3RhbGwucGhw'));
?>