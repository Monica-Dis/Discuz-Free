<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/function.func.php';

echo '
<script charset="utf-8" src="source/plugin/it618_video/js/jquery.js"></script>
';

showtableheaders(it618_video_getlang('s1792'),'it618_video_sum');

	echo '<tr><td colspan="4"><div class="fixsel">'.it618_video_getlang('s1793').' <input id="gwcuid" class="txt" style="width:76px" /><input type="button" class="btn" value="'.it618_video_getlang('s1794').'" onclick="gwclist_editprice(1)" /></div></td></tr>';
	
	showsubtitle(array(it618_video_getlang('t752'),it618_video_getlang('t753'),it618_video_getlang('s1132')));
	
	echo '<tr><td id="img_loading" style="display:none"><img src="source/plugin/it618_video/wap/images/loading.gif"></td></tr><tbody id="gwclist"></tbody>';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/
echo '
<script>
function save_editprice(gid){
	var price = document.getElementById("it618_price"+gid).value;
	var score = document.getElementById("it618_pricescore"+gid).value;
	IT618_VIDEO.get("'.$_G['siteurl'].'plugin.php?id=it618_video:ajax'.$adminsid.'&gid="+gid+"&price="+price+"&score="+score+"&formhash='.FORMHASH.'", {ac:"save_editprice"},function (data, textStatus){
	gwclist_editprice();
	}, "html");

}

function state_editprice(){
	var gwcuid = document.getElementById("gwcuid").value;
	IT618_VIDEO.get("'.$_G['siteurl'].'plugin.php?id=it618_video:ajax'.$adminsid.'&gwcuid="+gwcuid+"&formhash='.FORMHASH.'", {ac:"state_editprice"},function (data, textStatus){
	alert(data);
	document.getElementById("gwclist").style.display="none";
	document.getElementById("gwcuid").value="";
	}, "html");

}

function gwclist_editprice(){
	var gwcuid = document.getElementById("gwcuid").value;
	document.getElementById("img_loading").style.display="";
	document.getElementById("gwclist").style.display="none";
	IT618_VIDEO.get("'.$_G['siteurl'].'plugin.php?id=it618_video:ajax'.$adminsid.'&gwcuid="+gwcuid+"&formhash='.FORMHASH.'", {ac:"gwclist_editprice",ac1:"pcgwc"},function (data, textStatus){
	IT618_VIDEO("#gwclist").html(data);
	document.getElementById("img_loading").style.display="none";
	document.getElementById("gwclist").style.display="";
	}, "html");	
}
</script>
';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>