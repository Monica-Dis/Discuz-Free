<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$ppp = 20;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$pid=intval($_GET['pid']);
$preurl=$_GET['preurl'];
$urlsql='&pid='.$pid;

$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_video_goods_lesson', "id=$delid");
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			$it618_saleprice=$_GET['it618_saleprice'][$id];
			
			$it618_score=$_GET['it618_score'][$id];
			if($_GET['it618_jfid'][$id]==0)$it618_score=0;
			
			if($Shopisale!=1){
				$it618_saleprice=1;
			}

			C::t('#it618_video#it618_video_goods_lesson')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_url' => trim($_GET['it618_url'][$id]),
				'it618_issale' => $_GET['it618_issale'][$id],
				'it618_price' => $_GET['it618_price'][$id],
				'it618_saleprice' => $it618_saleprice,
				'it618_jfid' => $_GET['it618_jfid'][$id],
				'it618_score' => $it618_score,
				'it618_order' => trim($_GET['it618_order'][$id])
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_type_array = !empty($_GET['newit618_type']) ? $_GET['newit618_type'] : array();
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		
		if(trim($newit618_name_array[$key]) != '') {
			                                        
			C::t('#it618_video#it618_video_goods_lesson')->insert(array(
				'it618_pid' => $pid,
				'it618_type' => trim($newit618_type_array[$key]),
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_order' => trim($newit618_order_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}
	
	$it618_lessoncount=C::t('#it618_video#it618_video_goods_lesson')->count_by_pid($pid);
	C::t('#it618_video#it618_video_goods')->update($pid,array(
		'it618_lessoncount' => $it618_lessoncount
	));

	it618_cpmsg($it618_video_lang['s33'].$ok1.' '.$it618_video_lang['s34'].$ok2.' '.$it618_video_lang['s35'].$del.')', "plugin.php?id=it618_video:sc_product_lesson$adminsid&pid=$pid&preurl=$preurl&type=$type", 'succeed');
}

if($_GET['type']=='live')$type='live';

it618_showformheader("plugin.php?id=it618_video:sc_product_lesson$adminsid&pid=$pid&preurl=$preurl&type=$type");

$preurlhref=str_replace("@","&",$preurl);
$tmparr=explode("sc_live",$preurlhref);

if($_GET['type']=='live'||count($tmparr)>1){
	showtableheaders('<a href="'.$preurlhref.'">'.$it618_video_lang['s2004'].'<font color=red>'.$it618_video_lang['s514'].$it618_video_goods['it618_name'].$it618_video_lang['s515'].'</font></a> '.$it618_video_lang['s490'],'admin_shopproduct_type');
}else{
	showtableheaders('<a href="'.$preurlhref.'">'.$it618_video_lang['s504'].'<font color=red>'.$it618_video_lang['s514'].$it618_video_goods['it618_name'].$it618_video_lang['s515'].'</font></a> '.$it618_video_lang['s490'],'admin_shopproduct_type');
}

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_lesson')." WHERE it618_pid=".$pid);

echo '<tr><td colspan=15>'.$it618_video_lang['s491'].$count.'<span style="float:right;">'.$it618_video_lang['s492'].'</span></td></tr>';

if($Shopisale!=1){
	$it618_video_lang['s716']='';
}

showsubtitle(array($it618_video_lang['s493'], $it618_video_lang['s494'],$it618_video_lang['s1587'],$it618_video_lang['s716'],$it618_video_lang['s503']));

$n=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_lesson')." WHERE it618_pid=".$pid." ORDER BY it618_order");
while($it618_video_goods_lesson = DB::fetch($query)) {
	
	if($it618_video_goods_lesson['it618_type']==1){
		$disabled="";
		
		$it618_videotimestr=$it618_video_goods_lesson['it618_videocount'].$it618_video_lang['s108'].' '.it618_video_getvideotime($it618_video_goods_lesson['it618_videotime']);
		
		$livestr='';
		if($it618_video_goods['it618_gtype']==1){
			$it618_gtype='<a href="plugin.php?id=it618_video:sc_product_video'.$adminsid.'&lid='.$it618_video_goods_lesson['id'].'&preurl='.$preurl.'"><img src="source/plugin/it618_video/images/zj.png" style="vertical-align:middle;height:12px;margin-top:-1px;margin-right:3px">'.it618_video_getlang('s370').'</a> <font color=#888>('.$it618_videotimestr.')</font>';
			$livestr='<a href="plugin.php?id=it618_video:sc_liveset'.$adminsid.'&lid='.$it618_video_goods_lesson['id'].'"><img src="source/plugin/it618_video/images/zb.png" style="vertical-align:middle;height:18px;margin-top:-1px;margin-right:3px">'.$it618_video_lang['s1563'].'</a>';
		}else{
			$it618_gtype='<a href="plugin.php?id=it618_video:sc_product_content'.$adminsid.'&lid='.$it618_video_goods_lesson['id'].'&preurl='.$preurl.'"><img src="source/plugin/it618_video/images/zj.png" style="vertical-align:middle;height:12px;margin-top:-1px;margin-right:3px">'.it618_video_getlang('s371').'</a> <font color=#888>('.$it618_videotimestr.')</font>';
		}
		
		if($Shopisale==1){
			$typecountall = C::t('#it618_video#it618_video_goods_type')->counttype_by_pid_lid_vid($pid,$it618_video_goods_lesson['id'],0);
			$typecountok = C::t('#it618_video#it618_video_goods_type')->counttype_by_pid_lid_vid_ok($pid,$it618_video_goods_lesson['id'],0);
			$goodstypestr='<a href="javascript:" onclick="showgoodstype('.$pid.','.$it618_video_goods_lesson['id'].',0)"><img src="source/plugin/it618_video/images/price.png" style="vertical-align:middle;height:13px;margin-top:-1px;margin-right:3px">'.$it618_video_lang['s710'].'</a> <font color=#888>('.$typecountok.'/'.$typecountall.')</font>';
			
			$goodstypecss='';
			if($typecountok>0){
				$goodstypecss='display:none';
			}
		}else{
			$goodstypecss='display:none';
			$salecss='display:none';
		}
		
		if($it618_video_goods_lesson['it618_issale']==1){
			$it618_issale_checked='checked="checked"';
			$issalecss='';
		}else{
			$it618_issale_checked="";
			$issalecss='display:none';
		}
		
		$salecount = $it618_video_goods_lesson['it618_salecount'];
		$salemoney = $it618_video_goods_lesson['it618_salemoney'];
			
		if($it618_video_goods_lesson['it618_videocount']>0||$typecountall>0||$salecount>0||$examcount>0){
			$disabled="disabled=\"disabled\"";
		}
	
		showtablerow('', array('class="td25"', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_video_goods_lesson['id'].'" name="delete[]" value="'.$it618_video_goods_lesson['id'].'" '.$disabled.'><label for="chk_del'.$it618_video_goods_lesson['id'].'">'.$it618_video_goods_lesson['id'].'</label>',
			'<input type="text" class="txt" style="width:260px;margin-bottom:10px" name="it618_name['.$it618_video_goods_lesson['id'].']" value="'.$it618_video_goods_lesson['it618_name'].'">',
			'<br>'.$it618_gtype.'<br><br>'.$livestr.'<br>',
			'<div style="width:360px;'.$salecss.'">
			<div style="float:left;">
			<input class="checkbox" type="checkbox" id="chk_isprotect'.$n.'" name="it618_issale['.$it618_video_goods_lesson['id'].']" '.$it618_issale_checked.' value="1" onchange="getprice(this,'.$it618_video_goods_lesson['id'].')"><label for="chk_isprotect'.$n.'">'.it618_video_getlang('s1897').'</label>
			</div>
			<div  id="spanprice'.$it618_video_goods_lesson['id'].'" style="float:left;'.$issalecss.';width:360px;">
			<span style="'.$goodstypecss.';line-height:29px">
			<input type="text" class="txt" style="width:68px;margin-right:3px;color:red;" name="it618_saleprice['.$it618_video_goods_lesson['id'].']" value="'.$it618_video_goods_lesson['it618_saleprice'].'">'.it618_video_getlang('s125').'+<input type="text" class="txt" style="width:68px;margin-right:3px;;color:red" name="it618_score['.$it618_video_goods_lesson['id'].']" value="'.$it618_video_goods_lesson['it618_score'].'"><select name="it618_jfid['.$it618_video_goods_lesson['id'].']">'.it618_video_getjftype($it618_video_goods_lesson['it618_jfid']).'</select> '.$it618_video_lang['s1795'].'<input type="text" class="txt" style="width:68px;margin-right:3px;" name="it618_price['.$it618_video_goods_lesson['id'].']" value="'.$it618_video_goods_lesson['it618_price'].'">'.it618_video_getlang('s125').'
			</span>
			<br><span style="float:right;color:#999">'.it618_video_getlang('s119').''.$salecount.' '.it618_video_getlang('s120').''.$salemoney.'</span>'.$goodstypestr.'</div>
			</div>',
			'<input type="text" class="txt" style="width:30px;text-align:center;" name="it618_order['.$it618_video_goods_lesson['id'].']" value="'.$it618_video_goods_lesson['it618_order'].'">'
		));
		$n=$n+1;
	}else{
		showtablerow('', array('class="td25"', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_video_goods_lesson['id'].'" name="delete[]" value="'.$it618_video_goods_lesson['id'].'"><label for="chk_del'.$it618_video_goods_lesson['id'].'">'.$it618_video_goods_lesson['id'].'</label>',
			'<input type="text" class="txt" style="width:260px;margin-bottom:10px" name="it618_name['.$it618_video_goods_lesson['id'].']" value="'.$it618_video_goods_lesson['it618_name'].'">',
			'<input type="text" class="txt" style="width:260px;margin-bottom:10px" name="it618_url['.$it618_video_goods_lesson['id'].']" value="'.$it618_video_goods_lesson['it618_url'].'">',
			'',
			'<input type="text" class="txt" style="width:30px;text-align:center;" name="it618_order['.$it618_video_goods_lesson['id'].']" value="'.$it618_video_goods_lesson['it618_order'].'">'
		));
	}
}

echo '
<script>
function getprice(obj,tmpn){
	if(!obj.checked){
		document.getElementById("spanprice"+tmpn).style.display="none";
	}else{
		document.getElementById("spanprice"+tmpn).style.display="";
	}
}

function showgoodstype(pid,lid,vid){
	layerindex=layer.open({
		type: 2,
		title: "<div style=\'float:left;color:blue\'>'.$it618_video_lang['s710'].'</div>",
		shadeClose: false,
		scrollbar: false,
		shade:  [0.5, "#393D49"],
		maxmin: false,
		area: ["100%", "100%"],
		content: "plugin.php?id=it618_video:sc_product_type'.$adminsid.'&pid="+pid+"&lid="+lid+"&vid="+vid,
		cancel: function(index, layero){ 
			location.reload();
		}    
	});
}
</script>
';
	
	$it618_video_lang790=$it618_video_lang['s790'];
	$it618_video_lang791=$it618_video_lang['s791'];
	$it618_video_lang792=$it618_video_lang['s792'];
	
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<select name="newit618_type[]"><option value=1>$it618_video_lang790</option><option value=0>$it618_video_lang791</option></select> <input type="text" class="txt" style="width:225px" name="newit618_name[]">'],
		[1,'$it618_video_lang792'], 
		[1,''], 
		[1,'<input type="text" class="txt" style="width:30px" name="newit618_order[]">']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$it618_video_lang['s831'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />");
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>