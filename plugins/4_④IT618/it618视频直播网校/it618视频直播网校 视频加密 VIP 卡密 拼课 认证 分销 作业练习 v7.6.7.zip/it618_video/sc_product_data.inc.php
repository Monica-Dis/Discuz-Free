<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$ppp = 20;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$vid=intval($_GET['vid']);
$preurl=$_GET['preurl'];

$it618_video_goods_video = C::t('#it618_video#it618_video_goods_video')->fetch_by_id($vid);
$it618_video_goods_lesson = C::t('#it618_video#it618_video_goods_lesson')->fetch_by_id($it618_video_goods_video['it618_lid']);
$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_goods_video['it618_pid']);

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_video_goods_data', "id=$delid");
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			$it618_dataurl=trim($_GET['it618_dataurl'][$id]);
//			$tmparr=explode("http",$it618_dataurl);
//			if(count($tmparr)==1){
//				if(file_exists(DISCUZ_ROOT.'./'.$it618_dataurl)){
//					$it618_datasize=filesize(DISCUZ_ROOT.'./'.$it618_dataurl);
//				}
//			}else{
//				$header_array = get_headers($it618_dataurl, true);
//				$it618_datasize = $header_array['Content-Length'];
//			}
//			
//			if(is_array($it618_datasize))$it618_datasize=0;
			
			C::t('#it618_video#it618_video_goods_data')->update($id,array(
				'it618_name' => trim($_GET['it618_name'][$id]),
				'it618_dataurl' => $it618_dataurl,
				'it618_datasizestr' => trim($_GET['it618_datasizestr'][$id]),
				'it618_isuser' => trim($_GET['it618_isuser'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id])
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_name_array = !empty($_GET['newit618_name']) ? $_GET['newit618_name'] : array();
	$newit618_dataurl_array = !empty($_GET['newit618_dataurl']) ? $_GET['newit618_dataurl'] : array();
	$newit618_datasizestr_array = !empty($_GET['newit618_datasizestr']) ? $_GET['newit618_datasizestr'] : array();
	$newit618_isuser_array = !empty($_GET['newit618_isuser']) ? $_GET['newit618_isuser'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_name_array as $key => $value) {
		
		if(trim($newit618_name_array[$key]) != '') {
			                                        
			C::t('#it618_video#it618_video_goods_data')->insert(array(
				'it618_vid' => $vid,
				'it618_name' => trim($newit618_name_array[$key]),
				'it618_dataurl' => trim($newit618_dataurl_array[$key]),
				'it618_datasizestr' => trim($newit618_datasizestr_array[$key]),
				'it618_isuser' => trim($newit618_isuser_array[$key]),
				'it618_order' => trim($newit618_order_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}
	
//	$it618_video_goods_datatmp=C::t('#it618_video#it618_video_goods_data')->fetch_count_size_by_vid($vid);
//	C::t('#it618_video#it618_video_goods_video')->update($vid,array(
//		'it618_datacount' => $it618_video_goods_datatmp['datacount'],
//		'it618_datasize' => $it618_video_goods_datatmp['datasize']
//	));

	it618_cpmsg($it618_video_lang['s33'].$ok1.' '.$it618_video_lang['s34'].$ok2.' '.$it618_video_lang['s35'].$del.')', "plugin.php?id=it618_video:sc_product_data$adminsid&vid=$vid&preurl=$preurl", 'succeed');
}

echo '
<link rel="stylesheet" href="source/plugin/it618_video/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_video/kindeditor/kindeditor-min.js"></script>
';

it618_showformheader("plugin.php?id=it618_video:sc_product_data$adminsid&vid=$vid&preurl=$preurl");
$preurl=str_replace("@","&",$preurl);

if($it618_video_goods['it618_gtype']==1){
	$it618_gtype=$it618_video_lang['s507'];
	$it618_gtype1='sc_product_video';
}else{
	$it618_gtype=$it618_video_lang['s521'];
	$it618_gtype1='sc_product_content';
}

showtableheaders('<a href="plugin.php?id=it618_video:'.$it618_gtype1.'&lid='.$it618_video_goods_video['it618_lid'].'&preurl='.$preurl.'">'.$it618_gtype.'<font color=red>'.$it618_video_lang['s514'].$it618_video_goods['it618_name'].' - '.$it618_video_goods_lesson['it618_name'].' - '.$it618_video_goods_video['it618_name'].$it618_video_lang['s515'].'</font></a> '.$it618_video_lang['s442'],'sc_product_video');

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_video_goods_data')." WHERE it618_vid=".$vid);

echo '<tr><td colspan=15>'.$it618_video_lang['s525'].$count.'<span style="float:right;color:red">'.$it618_video_lang['s533'].'</span></td></tr>';

showsubtitle(array($it618_video_lang['s56'], $it618_video_lang['s526'], $it618_video_lang['s532'], $it618_video_lang['s527'],$it618_video_lang['s528'],$it618_video_lang['s529']));

$n=1;
$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods_data')." WHERE it618_vid=".$vid." ORDER BY it618_order");
while($it618_video_goods_data = DB::fetch($query)) {
	
	if($it618_video_goods_data['it618_isuser']==0){$it618_isuser_selected0='selected="selected"';$isusercolor='#390';}else $it618_isuser_selected0="";
	if($it618_video_goods_data['it618_isuser']==1){$it618_isuser_selected1='selected="selected"';$isusercolor='#f30';}else $it618_isuser_selected1="";
	if($it618_video_goods_data['it618_isuser']==2){$it618_isuser_selected2='selected="selected"';$isusercolor='#22b1fe';}else $it618_isuser_selected2="";
	
	showtablerow('', array('class="td25"', '', '', '', '', ''), array(
		'<input class="checkbox" type="checkbox" id="chk_del'.$it618_video_goods_data['id'].'" name="delete[]" value="'.$it618_video_goods_data['id'].'" '.$disabled.'><label for="chk_del'.$it618_video_goods_data['id'].'">'.$it618_video_goods_data['id'].'</label>',
		'<input type="text" class="txt" style="width:260px" id="name'.$it618_video_goods_data['id'].'" name="it618_name['.$it618_video_goods_data['id'].']" value="'.$it618_video_goods_data['it618_name'].'">',
		'<div style="width:490px;position:relative"><textarea id="videourl'.$it618_video_goods_data['id'].'" name="it618_dataurl['.$it618_video_goods_data['id'].']" style="width:490px;height:50px;">'.$it618_video_goods_data['it618_dataurl'].'</textarea><div style="position:absolute;bottom:5px;right:1px">[<a href="javascript:" onclick="media_select('.$it618_video_goods_data['id'].')">'.it618_video_getlang('s2026').'</a>]<div><div>',
		'<input type="text" class="txt" style="width:68px;margin-bottom:3px" id="size'.$it618_video_goods_data['id'].'" name="it618_datasizestr['.$it618_video_goods_data['id'].']" value="'.$it618_video_goods_data['it618_datasizestr'].'"><br>'.$it618_video_lang['s46'].': '.$it618_video_goods_data['it618_views'].'',
		'<select style="color:'.$isusercolor.'" name="it618_isuser['.$it618_video_goods_data['id'].']"><option value=1 '.$it618_isuser_selected1.' style="color:#f30">'.$it618_video_lang['s27'].'</option><option value=2 '.$it618_isuser_selected2.' style="color:#22b1fe">'.$it618_video_lang['s28'].'</option><option value=0 '.$it618_isuser_selected0.' style="color:#390">'.$it618_video_lang['s30'].'</option></select>',
		'<input type="text" class="txt" style="width:50px;text-align:center;" name="it618_order['.$it618_video_goods_data['id'].']" value="'.$it618_video_goods_data['it618_order'].'">'
	));
	
	$n=$n+1;
}

echo '
    <span id="it618_media_select"></span>
	<script>
	var vid,type;
	
	function media_select(id){
		vid=id;type="attach";title="'.$it618_video_lang['s2025'].'";
		document.getElementById("it618_media_select").click();
	}
	
    var dialog_media;
    KindEditor.ready(function(K) {K("#it618_media_select").click(function() {
    
        dialog_media = K.dialog({
            width : 848,
            height: 558,
            title : title,
            body : \'<div><iframe id="ifa_media" src="plugin.php?id=it618_video:sc_media_select'.$adminsid.'&type=\'+type+\'" style="border:0;" frameborder=0 width="848" height="536"></iframe></div>\',
            closeBtn : {
                name : "'.$it618_video_lang['t285'].'",
                click : function(e) {
                    dialog_media.remove();
                }
            }
        });
    
    });});
    </script>';

	$it618_video_langs530=$it618_video_lang['s530'];
	$it618_video_langs315=$it618_video_lang['s315'];
	$it618_video_langs27=$it618_video_lang['s27'];
	$it618_video_langs28=$it618_video_lang['s28'];
	$it618_video_langs30=$it618_video_lang['s30'];
	$it618_video_langs2026=$it618_video_lang['s2026'];
	echo <<<EOT
	<script type="text/JavaScript">
	$tmpjs
	var rowtypedata;
	function rundata(){
		
		var n=document.getElementsByName("newit618_name[]").length;
		
		return [
		[[1,''], 
		[1,'<input type="text" class="txt" style="width:260px" id="name1000'+n+'" name="newit618_name[]">'],
		[1,'<div style="width:490px;position:relative"><div style="position:absolute;bottom:5px;right:1px">[<a href="javascript:" onclick="media_select(1000'+n+')">$it618_video_langs2026</a>]</div><textarea id="videourl1000'+n+'" name="newit618_dataurl[]" style="width:490px;height:50px;"></textarea></div>'],
		[1,'<input type="text" class="txt" style="width:68px" id="size1000'+n+'" name="newit618_datasizestr[]">'],
		[1,'<select name="newit618_isuser"><option value=1 style="color:#f30">$it618_video_langs27</option><option value=2 style="color:#22b1fe">$it618_video_langs28</option><option value=0 style="color:#390">$it618_video_langs30</option></select>'],
		[1,'<input type="text" class="txt" style="width:50px" name="newit618_order[]">']]
		];
	}
	rowtypedata=rundata();
	
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$it618_video_lang['s831'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />");
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>