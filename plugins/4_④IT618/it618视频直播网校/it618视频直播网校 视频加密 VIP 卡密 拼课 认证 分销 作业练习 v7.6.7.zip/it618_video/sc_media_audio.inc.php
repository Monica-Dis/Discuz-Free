<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_header.func.php';

$osstype=intval($_GET['osstype']);
$typecss='style="display:"';
$lang_s234=$it618_video_lang['s234'];

if($osstype==0){
	$lang_t29=$it618_video_lang['t29'];
	$lang_s840=$it618_video_lang['s840'];
}

if($osstype==1){
	$lang_t29=$it618_video_lang['t798'];
	$lang_s840=$it618_video_lang['s1200'];
}

if($osstype==2){
	$lang_t29=$it618_video_lang['s2019'];
	$lang_s840=$it618_video_lang['s838'];
	$typecss='style="display:none"';
	$lang_s234=$it618_video_lang['s2020'];
}

$ppp = 10;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$it618sql = "it618_osstype=$osstype";

$state0='';$state1='';$state2='';$state3='';
if($_GET['state']==0){$state0='selected="selected"';}
if($_GET['state']==1){$it618sql .= " and it618_chkstate = 0";$state1='selected="selected"';}
if($_GET['state']==2){$it618sql .= " and it618_chkstate = 1";$state2='selected="selected"';}
if($_GET['state']==3){$it618sql .= " and it618_chkstate = 2";$state3='selected="selected"';}

$orderby0='';$orderby1='';
if($_GET['orderby']==0){$it618orderby = "it618_time desc";$orderby0='selected="selected"';}
if($_GET['orderby']==1){$it618orderby = "it618_size desc";$orderby1='selected="selected"';}

$urlsql='&osstype='.$osstype.'&key='.$_GET['key'].'&class_id='.$_GET['class_id'].'&state='.$_GET['state'].'orderby='.$_GET['orderby'];

if(submitcheck('it618submit_edit')){
	$ok=0;
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			C::t('#it618_video#it618_video_media_audio')->update($id,array(
				'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
				'it618_time1' => $_GET['it618_time1'][$id],
				'it618_time2' => $_GET['it618_time2'][$id],
				'it618_time3' => $_GET['it618_time3'][$id],
				'it618_aclass_id' => $_GET['it618_aclass_id'][$id]
			));
	
			$ok=$ok+1;
		}
	}

	it618_cpmsg(it618_video_getlang('s345').$ok, "plugin.php?id=it618_video:sc_media_audio$adminsid&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_delete')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_video_media_audio = C::t('#it618_video#it618_video_media_audio')->fetch_by_id($delid);
		if($it618_video_media_audio['it618_chkstate']==0){
			it618_video_deletemediaaudio($it618_video_media_audio['it618_url']);
			DB::query("delete from ".DB::table('it618_video_media_audio')." where id=".$delid);
			$ok=$ok+1;
		}
	}

	it618_cpmsg($it618_video_lang['s193'].$ok, "plugin.php?id=it618_video:sc_media_audio$adminsid&page=$page".$urlsql, 'succeed');
}

$query1 = DB::query("SELECT * FROM ".DB::table('it618_video_media_aclass')." where it618_shopid=$ShopId and it618_osstype=$osstype ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
}

$tmp1=str_replace('<option value='.$_GET['class_id'].'>','<option value='.$_GET['class_id'].' selected="selected">',$tmp);

it618_showformheader("plugin.php?id=it618_video:sc_media_audio$adminsid&page=$page".$urlsql);
showtableheaders($lang_t29,'it618_video_sum');
	echo '<tr><td colspan=14>'.it618_video_getlang('s97').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:300px" /> '.it618_video_getlang('s848').' <select name="class_id"><option value=0>'.it618_video_getlang('s102').'</option>'.$tmp1.'</select> '.it618_video_getlang('s101').' <select name="state"><option value=0 '.$state0.'>'.it618_video_getlang('s102').'</option><option value=1 '.$state1.'>'.it618_video_getlang('s677').'</option><option value=2 '.$state2.'>'.it618_video_getlang('s678').'</option><option value=3 '.$state3.'>'.it618_video_getlang('s679').'</option></select> <select name="orderby"><option value=0 '.$orderby0.'>'.it618_video_getlang('s697').'</option><option value=1 '.$orderby1.'>'.it618_video_getlang('s886').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_video_getlang('s350').'" /></td></tr>';
	
	$count = C::t('#it618_video#it618_video_media_audio')->count_by_search($it618sql,'',$ShopId,$_GET['class_id'],$_GET['key']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_video:sc_media_audio$adminsid".$urlsql);
	
	$sumsize = C::t('#it618_video#it618_video_media_audio')->sum_size_by_search($it618sql,'',$ShopId,$_GET['class_id'],$_GET['key']);
	
	echo '<tr><td colspan=14>'.it618_video_getlang('s850').$count.' '.$it618_video_lang['s235'].round(($sumsize/1024/1024),2).'M <span style="float:right;color:red">'.$lang_s840.'</span></td></tr>';
	showsubtitle(array('',it618_video_getlang('s231'),it618_video_getlang('s232'),$lang_s234,$it618_video_lang['s845']));

	$n=1;
	foreach(C::t('#it618_video#it618_video_media_audio')->fetch_all_by_search(
		$it618sql,$it618orderby,$ShopId,$_GET['class_id'],$_GET['key'],$startlimit,$ppp
	) as $it618_video_media_audio) {

		$tmp1=str_replace('<option value='.$it618_video_media_audio['it618_aclass_id'].'>','<option value='.$it618_video_media_audio['it618_aclass_id'].' selected="selected">',$tmp);
		
		$urlstr='';
		if($it618_video_media_audio['it618_chkstate']==0){
			$it618_chkstate='<font color=red>'.$it618_video_lang['s677'].'</font>';
		}
		
		if($it618_video_media_audio['it618_chkstate']==1){
			$it618_chkstate='<font color=green>'.$it618_video_lang['s678'].'</font>';
			$urlstr='[<a href="'.it618_video_getsignedurl($it618_video_media_audio['it618_url']).'" target="_blank">'.$it618_video_lang['s46'].'</a>]';
		}
		
		if($it618_video_media_audio['it618_chkstate']==2){
			$it618_chkstate='<font color=blue>'.$it618_video_lang['s679'].'</font>';
		}

		showtablerow('', array('', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_video_media_audio['id'].'"><label for="chk_del'.$n.'">'.$it618_video_media_audio['id'].'</label>',
			'<select id="class'.$n.'" name="it618_aclass_id['.$it618_video_media_audio['id'].']" style="margin-bottom:4px">'.$tmp1.'</select>',
			'<input type="text" class="txt" style="width:380px;margin-bottom:4px" name="it618_name['.$it618_video_media_audio['id'].']" value="'.$it618_video_media_audio['it618_name'].'">',
			'<span '.$typecss.'>'.$it618_video_lang['s399'].'<input type="text" class="txt" style="width:23px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" name="it618_time1['.$it618_video_media_audio['id'].']" value="'.$it618_video_media_audio['it618_time1'].'">'.$it618_video_lang['s397'].'
			<input type="text" class="txt" style="width:23px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" name="it618_time2['.$it618_video_media_audio['id'].']" value="'.$it618_video_media_audio['it618_time2'].'">'.$it618_video_lang['s398'].'
			<input type="text" class="txt" style="width:23px;color:blue;text-align:center;margin-right:3px" onclick="this.select();" name="it618_time3['.$it618_video_media_audio['id'].']" value="'.$it618_video_media_audio['it618_time3'].'">'.$it618_video_lang['s400'].' </span>'.$it618_video_media_audio['it618_ext'].' '.round(($it618_video_media_audio['it618_size']/1024/1024),2).'MB '.$urlstr.' <font color=#999>'.date('Y-m-d H:i:s', $it618_video_media_audio['it618_time']).'</font>',
			$it618_chkstate
		));
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_video_getlang('s129').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><select onchange="mediaclass(this)">'.$tmp.'</select><input type="submit" class="btn" name="it618submit_edit" value="'.it618_video_getlang('s851').'"/> <input type="submit" class="btn" name="it618submit_delete" value="'.$it618_video_lang['s191'].'" onclick="return confirm(\''.$it618_video_lang['s1432'].'\')"/><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

showtablefooter(); /*dis'.'m.tao'.'bao.com*/

echo '
<script type="text/javascript">
  function mediaclass(obj){
	  for(var i=1;i<'.$n.';i++){
		  document.getElementById("class"+i).selectedIndex = obj.selectedIndex;
	  }
  }
  
  function check_all(obj,id){
	  for(var i=1;i<'.$n.';i++){
		  document.getElementById(id+""+i).checked = obj.checked;
	  }
  }
</script>';
require_once DISCUZ_ROOT.'./source/plugin/it618_video/sc_footer.func.php';
?>