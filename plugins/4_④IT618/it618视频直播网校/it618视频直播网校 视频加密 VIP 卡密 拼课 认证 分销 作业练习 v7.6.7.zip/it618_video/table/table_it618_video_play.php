<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_video_play extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_video_play';
		$this->_pk = 'id';
		parent::__construct(); /*dism_ taobao _com*/
	}
	
	public function count_by_vid_uid($vid, $uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_vid=%d AND it618_uid=%d", array($this->_table, $vid, $uid));
	}
	
	public function fetch_by_vid_uid($vid, $uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_vid=%d AND it618_uid=%d", array($this->_table, $vid, $uid));
	}
	
	public function fetch_by_uid_etime($uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_uid=%d order by it618_etime desc", array($this->_table, $uid));
	}
	
	public function fetch_by_uid_pid_etime($uid, $pid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_uid=%d AND it618_pid=%d order by it618_etime desc", array($this->_table, $uid, $pid));
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_it618_playcode($playcode) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_playcode=%s", array($this->_table, $playcode));
	}
	
	public function count_by_search($it618sql = '', $it618orderby='', $shopid = 0, $uid = 0, $pid = 0, $vid = 0, $ips='') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $shopid, $uid, $pid, $vid, $ips);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby='', $shopid = 0, $uid = 0, $pid = 0, $vid = 0, $ips='', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $shopid, $uid, $pid, $vid, $ips);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby='', $shopid = 0, $uid = 0, $pid = 0, $vid = 0, $ips='') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($shopid)) {
			$parameter[] = $shopid;
			$wherearr[] = 'it618_shopid=%d';
		}
		if(!empty($uid)) {
			$parameter[] = $uid;
			$wherearr[] = 'it618_uid=%d';
		}
		if(!empty($pid)) {
			$parameter[] = $pid;
			$wherearr[] = 'it618_pid=%d';
		}
		if(!empty($vid)) {
			$parameter[] = $vid;
			$wherearr[] = 'it618_vid=%d';
		}
		if(!empty($ips)) {
			$parameter[] = '%'.$ips.'%';
			$wherearr[] = "it618_ips LIKE %s";
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function countsum_by_search($it618sql = '', $it618orderby='', $shopid = 0, $uid = 0, $pid = 0) {
		$condition = $this->makesum_query_condition($it618sql, $shopid, $uid, $pid);
		$data = array();
		$query = DB::query("SELECT it618_pid,it618_uid,sum(it618_playtime) as sumtime FROM %t $condition[0] and it618_playtime>0 group by it618_pid,it618_uid", $condition[1]);
		while($value = DB::fetch($query)) {
			$count=$count+1;
		}
		return $count;
	}
	
	public function fetchsum_all_by_search($it618sql = '', $it618orderby='', $shopid = 0, $uid = 0, $pid = 0, $start = 0, $limit = 0) {
		$condition = $this->makesum_query_condition($it618sql, $shopid, $uid, $pid);
		$data = array();
		$query = DB::query("SELECT it618_pid,it618_uid,sum(it618_playtime) as sumtime FROM %t $condition[0] and it618_playtime>0 group by it618_pid,it618_uid order by sumtime desc".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function makesum_query_condition($it618sql = '', $shopid = 0, $uid = 0, $pid = 0) {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($shopid)) {
			$parameter[] = $shopid;
			$wherearr[] = 'it618_shopid=%d';
		}
		if(!empty($uid)) {
			$parameter[] = $uid;
			$wherearr[] = 'it618_uid=%d';
		}
		if(!empty($pid)) {
			$parameter[] = $pid;
			$wherearr[] = 'it618_pid=%d';
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
}

?>