<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_video_shopliveset extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_video_shopliveset';
		$this->_pk = 'id';
		parent::__construct(); /*dism_ taobao _com*/
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function count_ok_by_shopid_livesetid($shopid,$livesetid) {
		return DB::result_first("SELECT COUNT(1) FROM %t s join ".DB::table('it618_video_liveset')." w on s.it618_liveset_id=w.id and w.it618_isok=1 WHERE s.it618_shopid=%d and s.it618_liveset_id=%d", array($this->_table, $shopid,$livesetid));
	}
	
	public function count_ok_by_shopid($shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t s join ".DB::table('it618_video_liveset')." w on s.it618_liveset_id=w.id and w.it618_isok=1 WHERE s.it618_shopid=%d", array($this->_table, $shopid));
	}
	
	public function count_all_by_shopid($shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d", array($this->_table, $shopid));
	}
	
	public function count_by_shopid_livesetid($shopid,$livesetid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d AND it618_liveset_id=%d", array($this->_table, $shopid,$livesetid));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_by_shopid($shopid) {
		DB::query("DELETE FROM %t WHERE it618_shopid=%d", array($this->_table, $shopid));
	}
}

?>