<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_video_media_live extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_video_media_live';
		$this->_pk = 'id';
		parent::__construct(); /*dism_ taobao _com*/
	}
	
	public function count_by_shopid($shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d", array($this->_table, $shopid));
	}
	
	public function count_by_class_id($class_id) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_class_id=%d", array($this->_table, $class_id));
	}
	
	public function count_by_liveset_id($liveset_id) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_liveset_id=%d", array($this->_table, $liveset_id));
	}
	
	public function count_by_url($url) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_url=%s", array($this->_table, $url));
	}
	
	public function fetch_by_url($url) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_url=%s", array($this->_table, $url));
	}
	
	public function count_by_shopid_state($shopid,$state) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d and it618_state=%d", array($this->_table, $shopid, $state));
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_id_state($id,$state) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d AND it618_state=%d", array($this->_table, $id, $state));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function count_by_search($it618sql = '', $it618orderby='', $shopid = 0, $class_id = 0, $it618_name = '') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $shopid, $class_id, $it618_name);
		return DB::result_first("SELECT COUNT(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby='', $shopid = 0, $class_id = 0, $it618_name = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $shopid, $class_id, $it618_name);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby='', $shopid = 0, $class_id = 0, $it618_name = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($shopid)) {
			$parameter[] = $shopid;
			$wherearr[] = 'it618_shopid=%d';
		}
		if(!empty($class_id)) {
			$parameter[] = $class_id;
			$wherearr[] = 'it618_class_id=%d';
		}
		if(!empty($it618_name)) {
			$tmparr=explode(" ",$it618_name);
			for($n=0;$n<count($tmparr);$n++){
				if($tmparr[$n]!=''){
					$parameter[] = '%'.$tmparr[$n].'%';
					$tmpsql.='it618_name LIKE %s OR ';
				}
			}
			$tmpsql.='@';
			$tmpsql=str_replace(" OR @","",$tmpsql);
			$wherearr[] = $tmpsql;
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
}

?>