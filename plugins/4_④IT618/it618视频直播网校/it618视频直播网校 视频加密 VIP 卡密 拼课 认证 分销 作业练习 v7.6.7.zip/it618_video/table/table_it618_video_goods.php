<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_video_goods extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_video_goods';
		$this->_pk = 'id';
		parent::__construct(); /*dism_ taobao _com*/
	}
	
	public function count_by_shopid($shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d", array($this->_table, $shopid));
	}
	
	public function count_by_shopid_state($shopid,$state) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d and it618_state=%d", array($this->_table, $shopid, $state));
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_id_state($id,$state) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d AND it618_state=%d", array($this->_table, $id, $state));
	}
	
	public function fetch_it618_shopid_by_id($id) {
		return DB::result_first("SELECT it618_shopid FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function count_by_search($it618sql = '', $it618orderby='', $shopid = 0, $class1 = 0, $class2 = 0, $it618_name = '', $price1 = 0, $price2 = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $shopid, $class1, $class2, $it618_name, $price1, $price2);
		return DB::result_first("SELECT COUNT(1) FROM %t g join ".DB::table('it618_video_shop')." s on g.it618_shopid=s.id and s.it618_state=2 and s.it618_htstate=1 $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby='', $shopid = 0, $class1 = 0, $class2 = 0, $it618_name = '', $price1 = 0, $price2 = 0, $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $shopid, $class1, $class2, $it618_name, $price1, $price2);
		$data = array();
		$query = DB::query("SELECT g.* FROM %t g join ".DB::table('it618_video_shop')." s on g.it618_shopid=s.id and s.it618_state=2 and s.it618_htstate=1 $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby='', $shopid = 0, $class1 = 0, $class2 = 0, $it618_name = '', $price1 = 0, $price2 = 0) {
		global $_G,$it618_videotmp;
		$it618_videotmp = $_G['cache']['plugin']['it618_video'];
		
		$parameter = array($this->_table);
		$wherearr = array();
		
		$uid=$_G['uid'];
		if($uid=='')$uid=0;
		$video_shopadmin=explode(",",$it618_videotmp['video_shopadmin']);
		if(!in_array($uid, $video_shopadmin)){
			$bmsql='(g.it618_issecret=0 or g.it618_shopuid='.$uid.' or (g.it618_issecret=1 and CONCAT(\',\',g.it618_secretusers,\',\') like \'%,'.$uid.',%\'))';
			$parameter[] = $bmsql;
			$wherearr[] = "%i";
		}
		
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($shopid)) {
			$parameter[] = $shopid;
			$wherearr[] = 'g.it618_shopid=%d';
		}
		if(!empty($class1)) {
			$parameter[] = $class1;
			$parameter[] = $class1;
			$parameter[] = $class1;
			$parameter[] = $class1;

			$wherearr[]='(g.it618_class1_id=%d OR g.it618_class1_id1=%d OR g.it618_class1_id2=%d OR g.it618_class1_id3=%d)';
		}
		if(!empty($class2)) {
			$parameter[] = $class2;
			$parameter[] = $class2;
			$parameter[] = $class2;
			$parameter[] = $class2;

			$wherearr[]='(g.it618_class2_id=%d OR g.it618_class2_id1=%d OR g.it618_class2_id2=%d OR g.it618_class2_id3=%d)';
		}
		if(!empty($it618_name)) {
			$tmparr=explode(" ",$it618_name);
			for($n=0;$n<count($tmparr);$n++){
				$parameter[] = '%'.$tmparr[$n].'%';
				$parameter[] = '%'.$tmparr[$n].'%';
				$tmpsql.='g.it618_name LIKE %s OR g.it618_description LIKE %s OR ';
			}
			$tmpsql.='@';
			$tmpsql=str_replace(" OR @","",$tmpsql);
			$wherearr[] = '('.$tmpsql.')';
		}
		if(!empty($price1)) {
			$parameter[] = $price1;
			$wherearr[] = 'g.it618_saleprice>=%d';
		}
		if(!empty($price2)) {
			$parameter[] = $price2;
			$wherearr[] = 'g.it618_saleprice<=%d';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function update_it618_views_by_id($id) {
		DB::query("UPDATE %t SET it618_views=it618_views+1 WHERE id=%d", array($this->_table, $id));
	}
	
	public function update_it618_plays_by_id($id) {
		DB::query("UPDATE %t SET it618_plays=it618_plays+1 WHERE id=%d", array($this->_table, $id));
	}
}

?>