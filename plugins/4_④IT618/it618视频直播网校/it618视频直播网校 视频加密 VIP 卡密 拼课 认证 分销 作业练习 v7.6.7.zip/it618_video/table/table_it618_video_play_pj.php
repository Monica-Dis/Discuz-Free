<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_video_play_pj extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_video_play_pj';
		$this->_pk = 'id';
		parent::__construct(); /*dism_ taobao _com*/
	}
	
	public function count_by_pid_uid($pid, $uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pid=%d AND it618_uid=%d", array($this->_table, $pid, $uid));
	}
	
	public function fetch_by_pid_uid($pid, $uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_pid=%d AND it618_uid=%d", array($this->_table, $pid, $uid));
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function countpj_by_pid($pid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_score1>0 AND it618_pid=%d", array($this->_table, $pid));
	}
	
	public function countpj1_by_pid_score($pid,$score) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_score1=%d AND it618_pid=%d", array($this->_table, $score, $pid));
	}
	
	public function fetch_sumpjscore_by_pid($pid) {
		return DB::fetch_first("SELECT SUM(it618_score1) as score1,SUM(it618_score2) as score2,SUM(it618_score3) as score3,SUM(it618_score4) as score4 FROM %t WHERE it618_pid=%d", array($this->_table, $pid));
	}
	
	public function fetch_allpj_by_it618_pid($it618_pid, $start = 0, $limit = 0) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_score1>0 AND it618_pid=%d ORDER BY it618_pjtime DESC".DB::limit($start, $limit), array($this->_table,$it618_pid));
	}
	
	public function count_by_search($it618sql = '', $it618orderby='', $shopid = 0, $uid = 0, $pname = '') {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $shopid, $uid, $pname);
		return DB::result_first("SELECT COUNT(1) FROM %t p join ".DB::table('it618_video_goods')." g on p.it618_pid=g.id $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618sql = '', $it618orderby='', $shopid = 0, $uid = 0, $pname = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618sql, $it618orderby, $shopid, $uid, $pname);
		$data = array();
		$query = DB::query("SELECT p.* FROM %t p join ".DB::table('it618_video_goods')." g on p.it618_pid=g.id $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618sql = '', $it618orderby='', $shopid = 0, $uid = 0, $pname = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($shopid)) {
			$parameter[] = $shopid;
			$wherearr[] = 'p.it618_shopid=%d';
		}
		if(!empty($uid)) {
			$parameter[] = $uid;
			$wherearr[] = 'p.it618_uid=%d';
		}
		if(!empty($pname)) {
			$parameter[] = '%'.$pname.'%';
			$wherearr[] = "g.it618_name LIKE %s";
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
}

?>