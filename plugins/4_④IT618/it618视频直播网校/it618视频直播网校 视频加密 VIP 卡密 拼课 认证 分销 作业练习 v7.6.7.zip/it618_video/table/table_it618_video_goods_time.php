<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_video_goods_time extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_video_goods_time';
		$this->_pk = 'id';
		parent::__construct(); /*dism_ taobao _com*/
	}
	
	public function count_by_it618_pid($it618_pid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pid=%d", array($this->_table, $it618_pid));
	}
	
	public function count_by_uid_pid($uid, $pid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d AND it618_pid=%d", array($this->_table, $uid, $pid));
	}
	
	public function fetch_by_uid_pid($uid, $pid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_uid=%d AND it618_pid=%d", array($this->_table, $uid, $pid));
	}
	
	public function fetch_by_uid_pid_lid_vid($uid, $pid, $lid, $vid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_uid=%d AND it618_pid=%d AND it618_lid=%d AND it618_vid=%d", array($this->_table, $uid, $pid, $lid, $vid));
	}
	
	public function count_by_uid_pid_time0($uid, $pid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d AND it618_pid=%d AND it618_etime=0", array($this->_table, $uid, $pid));
	}
	
	public function sumcount_by_it618_pid($it618_pid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pid=%d", array($this->_table, $it618_pid));
	}
	
	public function sumcount_by_shopid($shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d", array($this->_table, $shopid));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_uid_by_id($id) {
		return DB::result_first("SELECT it618_uid FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function count_by_search($it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0) {
		$condition = $this->make_query_condition($it618_shopid, $it618sql, $it618orderby, $it618_name, $it618_uid);
		return DB::result_first("SELECT count(1) FROM %t t LEFT JOIN ".DB::table('it618_video_goods')." g ON t.it618_pid=g.id $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0, $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618_shopid, $it618sql, $it618orderby, $it618_name, $it618_uid);
		$data = array();
		$query = DB::query("SELECT t.* FROM %t t LEFT JOIN ".DB::table('it618_video_goods')." g ON t.it618_pid=g.id $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_name = '', $it618_uid = 0) {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618_shopid)) {
			$parameter[] = $it618_shopid;
			$wherearr[] = 't.it618_shopid=%d';
		}
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618_name)) {
			$parameter[] = '%'.$it618_name.'%';
			$parameter[] = '%'.$it618_name.'%';
			$wherearr[] = "(g.it618_name LIKE %s or g.it618_description LIKE %s)";
		}
		if(!empty($it618_uid)) {
			$parameter[] = $it618_uid;
			$wherearr[] = 't.it618_uid=%d';
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}

?>