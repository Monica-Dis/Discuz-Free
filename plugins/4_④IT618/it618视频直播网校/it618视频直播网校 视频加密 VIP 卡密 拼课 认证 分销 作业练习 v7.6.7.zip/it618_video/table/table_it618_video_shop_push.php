<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_video_shop_push extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_video_shop_push';
		$this->_pk = 'id';
		parent::__construct(); /*dism_ taobao _com*/
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function count_by_shopid($shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_shopid=%d", array($this->_table, $shopid));
	}
	
	public function fetch_by_shopid($shopid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_shopid=%d", array($this->_table, $shopid));
	}
	
	public function count_by_search($it618_shopid = 0, $it618sql = '', $it618orderby = '', $it618_uid = 0) {
		$condition = $this->make_query_condition($it618_shopid, $it618sql, $it618orderby, $it618_uid);
		return DB::result_first("SELECT count(1) FROM %t $condition[0]", $condition[1]);
	}
	
	public function fetch_all_by_search($it618_shopid = 0, $it618sql = '', $it618orderby = '', $start = 0, $limit = 0) {
		$condition = $this->make_query_condition($it618_shopid, $it618sql, $it618orderby);
		$data = array();
		$query = DB::query("SELECT * FROM %t $condition[0]".DB::limit($start, $limit), $condition[1]);
		while($value = DB::fetch($query)) {
			$data[] = $value;
		}
		return $data;
	}
	
	private function make_query_condition($it618_shopid = 0, $it618sql = '', $it618orderby = '') {
		$parameter = array($this->_table);
		$wherearr = array();
		if(!empty($it618_shopid)) {
			$parameter[] = $it618_shopid;
			$wherearr[] = 'it618_shopid=%d';
		}
		if(!empty($it618sql)) {
			$parameter[] = $it618sql;
			$wherearr[] = "%i";
		}
		if(!empty($it618orderby)) {
			$parameter[] = $it618orderby;
			$wherearr[] = "1 ORDER BY %i";
		}
		
		$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
		return array($wheresql, $parameter);
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}

?>