<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_video_gwc extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_video_gwc';
		$this->_pk = 'id';
		parent::__construct(); /*dism_ taobao _com*/
	}
	
	public function count_by_search() {
		return DB::result_first("SELECT COUNT(1) FROM %t", array($this->_table));
	}
	
	public function count_by_uid($uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d", array($this->_table,$uid));
	}
	
	public function count_by_uid_state($uid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d AND it618_state=1", array($this->_table,$uid));
	}
	
	public function count_by_uid_shopid($uid,$shopid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d AND it618_shopid=%d", array($this->_table,$uid,$shopid));
	}
	
	public function count_by_uid_pid_lid_vid_gtypeid($uid,$pid,$lid,$vid,$gtypeid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_uid=%d AND it618_pid=%d AND it618_lid=%d AND it618_vid=%d AND it618_gtypeid=%d", array($this->_table,$uid,$pid,$lid,$vid,$gtypeid));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_all_by_search() {
		return DB::fetch_all("SELECT * FROM %t", array($this->_table));
	}
	
	public function fetch_all_by_uid($uid) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_uid=%d order by it618_shopid", array($this->_table,$uid));
	}
	
	public function fetch_all_by_uid_shopid($uid,$shopid) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_uid=%d AND it618_shopid=%d", array($this->_table,$uid,$shopid));
	}
	
	public function fetch_all_shopid_by_uid($uid) {
		return DB::fetch_all("SELECT it618_shopid FROM %t WHERE it618_uid=%d group by it618_shopid", array($this->_table,$uid));
	}
	
	public function update_count1_by_id_uid($id,$uid) {
		DB::query("UPDATE %t SET it618_count=it618_count-1 WHERE it618_count>0 and id=%d AND it618_uid=%d", array($this->_table, $id, $uid));
	}
	
	public function update_count2_by_id_uid($id,$uid) {
		DB::query("UPDATE %t SET it618_count=it618_count+1 WHERE id=%d AND it618_uid=%d", array($this->_table, $id, $uid));
	}
	
	public function update_state_by_uid_shopid($state,$uid,$shopid) {
		DB::query("UPDATE %t SET it618_state=%d WHERE it618_uid=%d AND it618_shopid=%d", array($this->_table, $state, $uid, $shopid));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_by_uid($uid) {
		DB::query("DELETE FROM %t WHERE it618_uid=%d", array($this->_table, $uid));
	}

	public function delete_by_id_uid($id,$uid) {
		DB::query("DELETE FROM %t WHERE id=%d AND it618_uid=%d", array($this->_table, $id, $uid));
	}
	
	public function delete_by_uid_pid($uid,$pid) {
		DB::query("DELETE FROM %t WHERE it618_uid=%d AND it618_pid=%d", array($this->_table,$uid,$pid));
	}
}

?>