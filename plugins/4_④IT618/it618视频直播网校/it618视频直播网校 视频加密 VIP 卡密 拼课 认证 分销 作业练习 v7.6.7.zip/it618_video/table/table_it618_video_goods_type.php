<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_video_goods_type extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_video_goods_type';
		$this->_pk = 'id';
		parent::__construct(); /*dism_ taobao _com*/
	}
	
	public function count_by_search() {
		return DB::result_first("SELECT COUNT(1) FROM %t", array($this->_table));
	}
	
	public function sumsalecount_by_lid($lid) {
		return DB::result_first("SELECT SUM(it618_salecount) FROM %t WHERE it618_lid=%d", array($this->_table, $lid));
	}
	
	public function counttype_by_pid_lid_vid($pid,$lid,$vid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pid=%d AND it618_lid=%d AND it618_vid=%d", array($this->_table, $pid,$lid,$vid));
	}
	
	public function counttype_by_pid_lid_vid_ok($pid,$lid,$vid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pid=%d AND it618_lid=%d AND it618_vid=%d AND it618_ison=1", array($this->_table, $pid,$lid,$vid));
	}
	
	public function fetch_it618_name_by_id($id) {
		$tmp = DB::fetch_first("SELECT it618_name,it618_name1 FROM %t WHERE id=%d", array($this->_table, $id));
		$namestr=$tmp['it618_name'];
		if($tmp['it618_name1']!='')$namestr.=' * '.$tmp['it618_name1'];
		return $namestr;
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_idok($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_ison>0 AND id=%d", array($this->_table, $id));
	}
	
	public function fetch_all_by_it618_pid_lid_vid($pid,$lid,$vid) {
		return DB::fetch_all("SELECT * FROM %t WHERE it618_pid=%d AND it618_lid=%d AND it618_vid=%d AND it618_ison>0 ORDER BY it618_timetype desc,it618_time", array($this->_table,$pid,$lid,$vid));
	}
	
	public function fetch_price_by_it618_pid_lid_vid($pid,$lid,$vid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_pid=%d AND it618_lid=%d AND it618_vid=%d AND it618_ison>0 AND it618_saleprice>0 ORDER BY it618_saleprice,it618_time", array($this->_table,$pid,$lid,$vid));
	}
	
	public function fetch_score_by_it618_pid_lid_vid($pid,$lid,$vid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_pid=%d AND it618_lid=%d AND it618_vid=%d AND it618_ison>0 AND it618_score>0 ORDER BY it618_score,it618_time", array($this->_table,$pid,$lid,$vid));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_by_pid($pid) {
		DB::query("DELETE FROM %t WHERE it618_pid=%d", array($this->_table, $pid));
	}
}

?>