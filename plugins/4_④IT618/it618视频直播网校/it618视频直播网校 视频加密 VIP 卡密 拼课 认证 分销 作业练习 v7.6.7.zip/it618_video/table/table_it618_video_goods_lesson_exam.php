<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_video_goods_lesson_exam extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_video_goods_lesson_exam';
		$this->_pk = 'id';
		parent::__construct(); /*dism_ taobao _com*/
	}
	
	public function count_by_search() {
		return DB::result_first("SELECT COUNT(1) FROM %t", array($this->_table));
	}
	
	public function count_by_pid($pid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pid=%d", array($this->_table, $pid));
	}
	
	public function count_by_tid($tid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_tid=%d", array($this->_table, $tid));
	}
	
	public function count_by_lid($lid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_lid=%d", array($this->_table, $lid));
	}
	
	public function count_by_pid_tid($pid,$tid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_pid=%d and it618_tid=%d", array($this->_table, $pid, $tid));
	}
	
	public function fetch_by_pid_tid($pid,$tid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_pid=%d and it618_tid=%d", array($this->_table, $pid, $tid));
	}
	
	public function sum_score_by_lid($lid) {
		return DB::result_first("SELECT SUM(it618_score) FROM %t WHERE it618_lid=%d", array($this->_table, $lid));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_all_by_search() {
		return DB::fetch_all("SELECT * FROM %t ORDER BY it618_order", array($this->_table));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_by_pid($pid) {
		DB::query("DELETE FROM %t WHERE it618_pid=%d", array($this->_table, $pid));
	}
}

?>