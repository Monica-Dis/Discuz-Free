<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_video_goods_video_audio extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_video_goods_video_audio';
		$this->_pk = 'id';
		parent::__construct(); /*dism_ taobao _com*/
	}
	
	public function count_by_search() {
		return DB::result_first("SELECT COUNT(1) FROM %t", array($this->_table));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_vid($vid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_vid=%d ORDER BY it618_order", array($this->_table, $vid));
	}
	
	public function fetch_count_time_by_vid($vid) {
		return DB::fetch_first("SELECT COUNT(1) as videocount,SUM(it618_videotime) as videotime FROM %t WHERE it618_vid=%d", array($this->_table, $vid));
	}
	
	public function fetch_all_by_search() {
		return DB::fetch_all("SELECT * FROM %t ORDER BY it618_order", array($this->_table));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_by_pid($pid) {
		DB::query("DELETE FROM %t WHERE it618_pid=%d", array($this->_table, $pid));
	}
	
	public function update_it618_plays_by_id($id) {
		DB::query("UPDATE %t SET it618_plays=it618_plays+1 WHERE id=%d", array($this->_table, $id));
	}
}

?>