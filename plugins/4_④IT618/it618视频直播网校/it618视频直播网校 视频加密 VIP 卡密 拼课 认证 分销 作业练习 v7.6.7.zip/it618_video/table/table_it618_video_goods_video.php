<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_it618_video_goods_video extends discuz_table
{
	public function __construct() {
		$this->_table = 'it618_video_goods_video';
		$this->_pk = 'id';
		parent::__construct(); /*dism_ taobao _com*/
	}
	
	public function count_by_search() {
		return DB::result_first("SELECT COUNT(1) FROM %t", array($this->_table));
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_by_id_ison($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d and it618_ison=1", array($this->_table, $id));
	}
	
	public function fetch_by_url($url) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_videourl=%s", array($this->_table, $url));
	}
	
	public function fetch_by_lid_url($lid, $url) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_lid=%d and it618_videourl=%s", array($this->_table, $lid, $url));
	}
	
	public function fetch_by_liveid($liveid) {
		return DB::fetch_first("SELECT * FROM %t WHERE it618_liveid=%d", array($this->_table, $liveid));
	}
	
	public function fetch_count_time_by_pid($pid) {
		return DB::fetch_first("SELECT COUNT(1) as videocount,SUM(it618_videotime) as videotime FROM %t WHERE it618_pid=%d", array($this->_table, $pid));
	}
	
	public function fetch_count_time_by_lid($lid) {
		return DB::fetch_first("SELECT COUNT(1) as videocount,SUM(it618_videotime) as videotime FROM %t WHERE it618_lid=%d", array($this->_table, $lid));
	}
	
	public function fetch_mfvideo_by_pid($pid) {
		return DB::fetch_first("SELECT v.* FROM %t v left join ".DB::table('it618_video_goods_lesson')." l on v.it618_lid=l.id WHERE it618_isuser!=1 and v.it618_pid=%d order by l.it618_order, v.it618_order", array($this->_table, $pid));
	}
	
	public function fetch_order_by_lid($lid) {
		return DB::result_first("SELECT max(it618_order) FROM %t WHERE it618_lid=%d", array($this->_table, $lid))+1;
	}
	
	public function count_by_lid($lid) {
		return DB::result_first("SELECT COUNT(1) FROM %t WHERE it618_lid=%d", array($this->_table, $lid));
	}
	
	public function fetch_all_by_search() {
		return DB::fetch_all("SELECT * FROM %t ORDER BY it618_order", array($this->_table));
	}
	
	public function delete_by_id($id) {
		DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_by_pid($pid) {
		DB::query("DELETE FROM %t WHERE it618_pid=%d", array($this->_table, $pid));
	}
	
	public function update_it618_plays_by_id($id) {
		DB::query("UPDATE %t SET it618_plays=it618_plays+1 WHERE id=%d", array($this->_table, $id));
	}
}

?>