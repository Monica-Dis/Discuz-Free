<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if($reabc[4]!='8')return;

require_once DISCUZ_ROOT.'./source/plugin/it618_video/function/it618_video.func.php';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_media&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_media', 'admin_media_audio', 'admin_media_audio', 'admin_media_audio', 'admin_media_live');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_media' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<count($cparray);$i++){
	if($cp==$cparray[$i]){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

if($cp=='admin_media_audio'){
	$osstype=intval($_GET['osstype']);
	if($osstype==0){
		$strtmp[1]='';
		$strtmp[2]='class="current"';
		$strtmp[3]='';
	}
	if($osstype==1){
		$strtmp[1]='';
		$strtmp[2]='';
		$strtmp[3]='class="current"';
	}
	if($osstype==2){
		$strtmp[1]='class="current"';
		$strtmp[2]='';
		$strtmp[3]='';
	}
}

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_media'.$urls.'"><span>'.$it618_video_lang['t34'].'</span></a></li>
<li '.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_media_audio&osstype=2'.$urls.'"><span>'.$it618_video_lang['s2019'].'</span></a></li>
<li '.$strtmp[2].'><a href="'.$hosturl.'plugins&cp=admin_media_audio'.$urls.'"><span>'.$it618_video_lang['t29'].'</span></a></li>
<li '.$strtmp[3].'><a href="'.$hosturl.'plugins&cp=admin_media_audio&osstype=1'.$urls.'"><span>'.$it618_video_lang['t798'].'</span></a></li>
<li '.$strtmp[4].'><a href="'.$hosturl.'plugins&cp=admin_media_live'.$urls.'"><span>'.$it618_video_lang['s1278'].'</span></a></li>
</ul></div>';

dsetcookie('videoadmin','1',31536000);

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter(); /*dism��taobao��com*/
?>