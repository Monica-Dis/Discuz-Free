<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1Qh0" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$IsMembers,$IsGroup,$IsCredits,$IsUnion,$IsPinEdu,$IsChat,$IsWxMini,$RegName,$templatename,$templatename_wap,$templatename_wapu,$templatename_admin,$template_pagedefaut,$template_ispagetui,$template_isshoptui,$template_isselect,$template_set;
$RegName=$_G['setting']['regname'];

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/config/templateset.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_video/config/templateset.php';
}

if($template_pcname=='')$template_pcname='mall';
if($template_wapname=='')$template_wapname='mall_wap';
if($template_wapuname=='')$template_wapuname='';
if($template_adminname=='')$template_adminname='sc';

$templatename=$template_pcname;
$templatename_wap=$template_wapname;
$templatename_wapu=$template_wapuname;
$templatename_admin=$template_adminname;

$it618_video_pcstylename=getcookie('it618_video_pcstylename');
if($it618_video_pcstylename!=''){
	$templatename=$it618_video_pcstylename;
}

if(!file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/plugins/it618media/it618.png')){
	$templatename='mall';
}

if(!file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/plugins/it618media/it6181.png')){
	$templatename_wapu='';
}

if(!file_exists(DISCUZ_ROOT.'./source/plugin/it618_video/kindeditor/plugins/image/it618.png')){
	$templatename_admin='sc';
}

$it618_members = $_G['cache']['plugin']['it618_members'];
if($it618_members['members_isok']==1){
	$IsMembers=1;
}

$it618_credits = $_G['cache']['plugin']['it618_credits'];
if($it618_credits['seotitle']!=''&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/kindeditor/plugins/autoheight/it618.png')){
	$IsCredits=1;
}

$it618_group = $_G['cache']['plugin']['it618_group'];
if($it618_group['pagecount']!=''){
	$IsGroup=1;
}

$it618_union = $_G['cache']['plugin']['it618_union'];
if($it618_union['seotitle']!=''){
	if($it618_union['seotitle']!=''&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/kindeditor/plugins/code/it618.png')){
		$IsUnion=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/lang.func.php';
	}
}

$it618_pinedu = $_G['cache']['plugin']['it618_pinedu'];
if($it618_pinedu['pagecount']!=''){
	if($it618_pinedu['pagecount']!=''&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_pinedu/kindeditor/plugins/code/it618.png')){
		$IsPinEdu=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_pinedu/lang.func.php';
	}
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_chat/app_chat/config.php')){
	$IsChat=1;
	require_once DISCUZ_ROOT.'./source/plugin/it618_chat/lang.func.php';
}

$it618_wxmini = $_G['cache']['plugin']['it618_wxmini'];
if($it618_wxmini['pagecount']!=''&&file_exists(DISCUZ_ROOT.'./source/plugin/it618_wxmini/kindeditor/plugins/autoheight/it618.png')){
	$IsWxMini=1;
}

$langpluginname='it618_video';
if($_SERVER['HTTP_HOST']=='localhost'||strpos($_SERVER['HTTP_HOST'],'localhost'))$language = 'language.php';else$language = 'language.'.currentlang().'.php';
if(!file_exists(DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language))$language = 'language.php';
require_once DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language;$language_edit = 'language.'.currentlang().'_edit.php';
if(file_exists(DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language_edit)){
$lang_version=$it618_video_lang['version'];	$lang_it618=$it618_video_lang['it618'];	require_once DISCUZ_ROOT.'./source/plugin/'.$langpluginname.'/'.$language_edit;$it618_video_lang['version']=$lang_version;$it618_video_lang['it618']=$lang_it618;
}
?>