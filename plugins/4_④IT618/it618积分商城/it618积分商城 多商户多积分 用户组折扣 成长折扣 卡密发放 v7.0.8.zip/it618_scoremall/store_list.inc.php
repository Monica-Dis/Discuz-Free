<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/function.func.php';
$navtitle = $it618_scoremall['seotitle'];
$metakeywords = $it618_scoremall['seokeywords'];
$metadescription = $it618_scoremall['seodescription'];

if(scoremall_is_mobile()){ 
	$tmpurl=it618_scoremall_getrewrite('scoremall_wap','','plugin.php?id=it618_scoremall:wap');
	dheader("location:$tmpurl");
}

$query = DB::query("SELECT st.id,st.it618_uid,st.it618_name,st.it618_logo,sum(sa.it618_count) as salecount FROM ".DB::table('it618_scoremall_store')." st,".DB::table('it618_scoremall_sale')." sa WHERE st.it618_uid=sa.it618_saleuid and st.it618_htstate=1 group by st.it618_uid ORDER BY salecount desc limit 0,".$mall_storetopcount);
$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
while($it618_scoremall_store = DB::fetch($query)) {
	$pcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_goods')." WHERE it618_uid=".$it618_scoremall_store['it618_uid']);
	$tmpurl=it618_scoremall_getrewrite('productlist','sid@'.$it618_scoremall_store['id'].'@1','plugin.php?id=it618_scoremall:scoremall_list&sid='.$it618_scoremall_store['id']);
	$str_hotstore.='<li><div class="img_holder"><a href="'.$tmpurl.'" target="_blank"><img src="'.$it618_scoremall_store['it618_logo'].'" alt="'.$it618_scoremall_store['it618_name'].'" /></a></div><a href="'.$tmpurl.'" class="it618_title" title="'.$it618_scoremall_store['it618_name'].'" target="_blank">'.$it618_scoremall_store['it618_name'].'</a><p><span class="score">'.it618_mall_getlang('s402').'<span>'.$pcount.'</span></span><span class="cost"></span></p><p><a href="'.$tmpurl.'" class="glb_graybtn_s" target="_blank"><span>'.it618_mall_getlang('s403').'</span></a>'.it618_mall_getlang('s404').'<span class="num">'.$it618_scoremall_store['salecount'].'</span>'.it618_mall_getlang('s3').'</p></li>';
	if($ii1ill[14]!='l')return;
}

$ppp = $mall_storelistcount;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$sql="";
$it618_title='<span>'.it618_mall_getlang('s405').'</span>';

if(isset($_GET['sname']) && $_GET['sname']){
	$sql=" and it618_name like '%".addslashes($_GET['sname'])."%'";
	$it618_title='<span>'.it618_mall_getlang('s406').$_GET['sname'].'</span>';
}

$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_store')." WHERE it618_htstate=1 $sql ORDER BY id");
$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_scoremall:store_list");
$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
if($ii1ill[5]!='_')return;

$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_htstate=1 $sql ORDER BY id LIMIT $startlimit, $ppp");
while($it618_scoremall_store = DB::fetch($query)) {
	$pcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_goods')." WHERE it618_uid=".$it618_scoremall_store['it618_uid']);
	$scount = DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_scoremall_sale')." WHERE it618_saleuid=".$it618_scoremall_store['it618_uid']);
	if($scount=='')$scount="0";
	$tmpurl=it618_scoremall_getrewrite('productlist','sid@'.$it618_scoremall_store['id'].'@1','plugin.php?id=it618_scoremall:scoremall_list&sid='.$it618_scoremall_store['id']);
	$str_storelist.='<li><div class="img_holder"><a href="'.$tmpurl.'" target="_blank"><img src="'.$it618_scoremall_store['it618_logo'].'" alt="'.$it618_scoremall_store['it618_name'].'" /></a></div><a href="'.$tmpurl.'" class="it618_title" target="product_detail">'.$it618_scoremall_store['it618_name'].'</a><p>'.it618_mall_getlang('s402').'<span class="score"><span>'.$pcount.'</span></span><span class="cost"></span></p><p><a href="'.$tmpurl.'" class="glb_graybtn_s" target="search"><span>'.it618_mall_getlang('s403').'</span></a>'.it618_mall_getlang('s404').'<span class="num">'.$scount.'</span>'.it618_mall_getlang('s3').'</p></li>';
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	if($ii1ill[3]!='1')return;
}

$navtitle=it618_mall_getlang('s406').' - '.$navtitle;

$it618_scoremall_help=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_help'));

$tmpurl1=it618_scoremall_getrewrite('home','','plugin.php?id=it618_scoremall:scoremall');
$tmpurl2=it618_scoremall_getrewrite('gwc','','plugin.php?id=it618_scoremall:gwc');
$tmpurl3=it618_scoremall_getrewrite('storelist','','plugin.php?id=it618_scoremall:store_list');

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_scoremall:store_list');
?>