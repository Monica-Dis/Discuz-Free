<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/scoremall_default.func.php';

if(scoremall_is_mobile()){ 
	$tmpurl=it618_scoremall_getrewrite('scoremall_wap','','plugin.php?id=it618_scoremall:wap');
	dheader("location:$tmpurl");
}

global $oss;
if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/php/aliyunossconfig.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/php/aliyunossconfig.php';
	if($it618_isok==1){
		$oss='&oss';
	}
}

$shopuid=0;
$shopadmin=explode(",",$it618_scoremall['mall_wapsaleUID']);
if(in_array($_G['uid'],$shopadmin)){
	$shopuid=$_G['uid'];
}

$ppp = $qtpagecount;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$it618_mall_lang92=it618_mall_getlang('s92');
$it618_mall_lang93=it618_mall_getlang('s93');
$it618_mall_lang94=it618_mall_getlang('s94');

$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_htstate<>2");
while($it618_scoremall_store = DB::fetch($query)) {
	if($_G['timestamp']>=$it618_scoremall_store['it618_htetime']){
		DB::query("update ".DB::table('it618_scoremall_store')." set it618_htstate=2 where id=".$it618_scoremall_store['id']);
		DB::query("update ".DB::table('it618_scoremall_goods')." set it618_htstate=0 WHERE it618_uid=".$it618_scoremall_store['it618_uid']);
	}
}

if($_G['uid']<=0){
	showmessage(it618_mall_getlang('s11'), '', array(), array('alert' => 'error'));
}else{
	
	if($it618_scoremall['mall_isstore']==0){
		showmessage(it618_mall_getlang('s463'), '', array(), array('alert' => 'error'));
	}
	
	if(DB::result_first("select count(1) from ".DB::table('it618_scoremall_store')." where it618_uid=".$_G['uid'])==0){
		showmessage(it618_mall_getlang('s281'), '', array(), array('alert' => 'error'));
	}
	
	$it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_uid=".$_G['uid']);
	if($it618_scoremall_store['it618_htstate']==0){
		showmessage(it618_mall_getlang('s393'), '', array(), array('alert' => 'error'));
	}
	if($it618_scoremall_store['it618_htstate']==2){
		showmessage(it618_mall_getlang('s394'), '', array(), array('alert' => 'error'));
	}
	
	$pid=intval($_GET['pid']);
	if($pid>0){
		$it618_uid = DB::result_first("SELECT it618_uid FROM ".DB::table('it618_scoremall_goods')." WHERE id=".$pid);
		if($it618_uid!=$_G['uid']){
			showmessage(it618_mall_getlang('s684'), '', array(), array('alert' => 'error'));
		}
	}
}


$li1il11=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$li1il11[]=substr($_GET['id'],$i,1);}
if(count($li1il11)!=15)return;

$groupupscore=DB::result_first("SELECT it618_score FROM ".DB::table('it618_scoremall_store_groupup')." where it618_uid=".$_G['uid']);
$it618_scoremall_store_level=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store_level')." where it618_score1<=".$groupupscore." and it618_score2>=".$groupupscore);
$groupuplevel_store=$it618_scoremall_store_level['it618_level'];
$groupupscore_store_str=$groupupscore."/".$it618_scoremall_store_level['it618_score2'];
if($li1il11[8]!='o')return;
$groupupjd_store=(($groupupscore-$it618_scoremall_store_level['it618_score1'])/($it618_scoremall_store_level['it618_score2']-$it618_scoremall_store_level['it618_score1'])*100)."%";

if($li1il11[9]!='r')return;
if(isset($_GET['cid']) && $_GET['cid']){
	$cid=$_GET['cid'];
}else{
	$cid=1;
}
if($li1il11[14]!='l')return;
$menuname[1]=it618_mall_getlang('s282');
$menuname[2]=it618_mall_getlang('s283');
$menuname[3]=it618_mall_getlang('s284');
$menuname[4]=it618_mall_getlang('s285');
$menuname[5]=it618_mall_getlang('s286');
$menuname[6]=it618_mall_getlang('s287');
$menuname[7]=it618_mall_getlang('s473');
$menuname[8]=it618_mall_getlang('s525');

$cur[$cid]='it618_curmenu';$curmenuname=$menuname[$cid];
$navtitle=$curmenuname.it618_mall_getlang('s288').$navtitle;

$it618_pcount=DB::result_first("SELECT it618_pcount FROM ".DB::table('it618_scoremall_store')." where it618_uid=".$_G['uid']);
$it618_pprice=DB::result_first("SELECT it618_pprice FROM ".DB::table('it618_scoremall_store')." where it618_uid=".$_G['uid']);
$it618_htetime=DB::result_first("SELECT it618_htetime FROM ".DB::table('it618_scoremall_store')." where it618_uid=".$_G['uid']);

$it618_htetime=it618_mall_getlang('s655').'<font color=red>'.$it618_pcount.'</font> '.it618_mall_getlang('s742').'<font color=red>'.$it618_pprice.'</font> '.it618_mall_getlang('s395').'<font color=red>'.date('Y-m-d', $it618_htetime).'</font>';
if($li1il11[14]!='l')return;
if($cid==1){
	if($_GET['key']) {
		$extrasql .= " AND g.it618_name LIKE '%".addcslashes(addslashes($_GET['key']),'%_')."%'";
	}
	
	if($_GET['findcode']) {
		$extrasql .= " AND s.it618_code LIKE '%".addcslashes(addslashes($_GET['findcode']),'%_')."%'";
	}

	if($_GET['finduid']) {
		$extrasql .= " AND s.it618_uid = ".intval($_GET['finduid']);
	}
	if($li1il11[8]!='o')return;
	if($_GET['state']) {
		$state0='';$state1='';$state2='';$state3='';$state4='';$state5='';$state6='';
		if($_GET['state']==0){$extrasql .= "";$state0='selected="selected"';}
		if($_GET['state']==1){$extrasql .= " AND s.it618_state = 1";$state1='selected="selected"';}
		if($_GET['state']==2){$extrasql .= " AND s.it618_state = 2";$state2='selected="selected"';}
		if($_GET['state']==3){$extrasql .= " AND s.it618_state = 3";$state3='selected="selected"';}
		if($_GET['state']==4){$extrasql .= " AND s.it618_state = 4";$state4='selected="selected"';}
		if($_GET['state']==5){$extrasql .= " AND s.it618_state = 5";$state5='selected="selected"';}
		if($_GET['state']==6){$extrasql .= " AND s.it618_state = 6";$state6='selected="selected"';}
	}
	if($li1il11[14]!='l')return;

	if($_GET['key']!='')$uri.='&key='.$_GET['key'];
	if($_GET['findcode']!='')$uri.='&findcode='.$_GET['findcode'];
	if($_GET['finduid']!='')$uri.='&finduid='.$_GET['finduid'];
	if($_GET['state']!=0)$uri.='&state='.$_GET['state'];

	if($uri!=''){
		$uri='?'.$uri;
		$uri=str_replace("?&","?",$uri);
	}
	
	if(submitcheck('it618submit_sale_del')){
		$del=0;
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			if($li1il11[0]!='i')return;
			$it618_scoremall_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$delid);
			if($it618_scoremall_sale['it618_saleuid']!=$_G['uid']){
				continue;
			}
			$buyuid=$it618_scoremall_sale['it618_uid'];
			$saleuid=$it618_scoremall_sale['it618_saleuid'];
			if($it618_scoremall_sale['it618_state']==1){
				if($li1il11[0]!='i')return;
				DB::delete('it618_scoremall_sale', "id=$delid");
				if(count($li1il11)!=15)return;
				$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
				if($li1il11[8]!='o')return;
				C::t('common_member_count')->increase($buyuid, array(
					'extcredits'.$it618_scoremall_sale['it618_jfid'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']))
				);
				if($it618_scoremall_sale['it618_jfid1']>0){
					C::t('common_member_count')->increase($buyuid, array(
						'extcredits'.$it618_scoremall_sale['it618_jfid1'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']))
					);
				}
				DB::delete('it618_scoremall_groupuplog', "it618_saleid=$delid");
				DB::query("update ".DB::table('it618_scoremall_groupup')." set it618_score=it618_score-".($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney'])." where it618_uid=".$buyuid);
				DB::query("update ".DB::table('it618_scoremall_goods')." set it618_salecount=it618_salecount-".$it618_scoremall_sale['it618_count'].",it618_count=it618_count+".$it618_scoremall_sale['it618_count']." where id=".$it618_scoremall_goods['id']);
				if($li1il11[8]!='o')return;
				if($saleuid>0&&DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_store_groupuplog')." WHERE it618_saleid=".$delid)>0){
					C::t('common_member_count')->increase($saleuid, array(
						'extcredits'.$it618_scoremall_sale['it618_jfid'] => (0-($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']-$it618_scoremall_sale['it618_saletc'])))
					);
					if($it618_scoremall_sale['it618_jfid1']>0){
						C::t('common_member_count')->increase($saleuid, array(
							'extcredits'.$it618_scoremall_sale['it618_jfid1'] => (0-($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']-$it618_scoremall_sale['it618_saletc1'])))
						);
					}
					DB::delete('it618_scoremall_store_groupuplog', "it618_saleid=$delid");
					if($li1il11[0]!='i')return;
					DB::query("update ".DB::table('it618_scoremall_store_groupup')." set it618_score=it618_score-".($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1'])." where it618_uid=".$saleuid);
				}
				if($li1il11[14]!='l')return;
				$del=$del+1;
			}
		}
		
		showmessage(it618_mall_getlang('s145').$del.it618_mall_getlang('s146'), '', array(), array('alert' => 'right'));

	}
	
	if(submitcheck('it618submit_sale_yifahuo')){
		$ok=0;
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			if($li1il11[0]!='i')return;
			$it618_scoremall_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$delid);
			if($it618_scoremall_sale['it618_saleuid']!=$_G['uid']){
				continue;
			}
			if(count($li1il11)!=15)return;
			if($it618_scoremall_sale['it618_state']==1){
				DB::query("update ".DB::table('it618_scoremall_sale')." set it618_state=2 WHERE id=".$delid);
				$ok=$ok+1;
			}
		}
		
		showmessage(it618_mall_getlang('s147').$ok, dreferer(), array(), array('alert' => 'right'));
	}
	
	if(submitcheck('it618submit_sale_kd')){
		$ok=0;
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			$it618_scoremall_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$delid);
			if($it618_scoremall_sale['it618_saleuid']!=$_G['uid']){
				continue;
			}
			
			if($it618_scoremall_sale['it618_state']==2){
				C::t('#it618_scoremall#it618_scoremall_sale')->update($delid,array(
					'it618_kdid' => intval($_GET['it618_kdid'][$delid]),
					'it618_kddan' => dhtmlspecialchars($_GET['it618_kddan'][$delid])
				));
				$ok=$ok+1;
			}
		}
		
		showmessage(it618_mall_getlang('s417').$ok, dreferer(), array(), array('alert' => 'right'));
	}
	
	if(submitcheck('it618submit_sale_tongyi')){
		$ok=0;
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			$it618_scoremall_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$delid);
			if($it618_scoremall_sale['it618_saleuid']!=$_G['uid']){
				continue;
			}
			$buyuid=$it618_scoremall_sale['it618_uid'];
			$saleuid=$it618_scoremall_sale['it618_saleuid'];
			if($it618_scoremall_sale['it618_state']==4){
				DB::query("update ".DB::table('it618_scoremall_sale')." set it618_state=5 WHERE id=".$delid);
				if(count($li1il11)!=15)return;
				$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
				if(count($li1il11)!=15)return;
				C::t('common_member_count')->increase($buyuid, array(
					'extcredits'.$it618_scoremall_sale['it618_jfid'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']))
				);
				if($it618_scoremall_sale['it618_jfid1']>0){
					C::t('common_member_count')->increase($buyuid, array(
						'extcredits'.$it618_scoremall_sale['it618_jfid1'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']))
					);
				}
				DB::delete('it618_scoremall_groupuplog', "it618_saleid=$delid");
				DB::query("update ".DB::table('it618_scoremall_groupup')." set it618_score=it618_score-".($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney'])." where it618_uid=".$buyuid);
				DB::query("update ".DB::table('it618_scoremall_goods')." set it618_salecount=it618_salecount-".$it618_scoremall_sale['it618_count'].",it618_count=it618_count+".$it618_scoremall_sale['it618_count']." where id=".$it618_scoremall_goods['id']);
				if($li1il11[8]!='o')return;
				if($saleuid>0&&DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_store_groupuplog')." WHERE it618_saleid=".$delid)>0){
					C::t('common_member_count')->increase($saleuid, array(
						'extcredits'.$it618_scoremall_sale['it618_jfid'] => (0-($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']-$it618_scoremall_sale['it618_saletc'])))
					);
					if($it618_scoremall_sale['it618_jfid1']>0){
						C::t('common_member_count')->increase($saleuid, array(
							'extcredits'.$it618_scoremall_sale['it618_jfid1'] => (0-($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']-$it618_scoremall_sale['it618_saletc1'])))
						);
					}
					DB::delete('it618_scoremall_store_groupuplog', "it618_saleid=$delid");
					if($li1il11[0]!='i')return;
					DB::query("update ".DB::table('it618_scoremall_store_groupup')." set it618_score=it618_score-".($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1'])." where it618_uid=".$saleuid);
				}
				$ok=$ok+1;
			}
		}
		
		showmessage(it618_mall_getlang('s244').$ok, dreferer(), array(), array('alert' => 'right'));
		
	}
	
	if(submitcheck('it618submit_sale_jujue')){
		$ok=0;
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			$it618_scoremall_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$delid);
			if($it618_scoremall_sale['it618_saleuid']!=$_G['uid']){
				continue;
			}
			if(count($li1il11)!=15)return;
			if($it618_scoremall_sale['it618_state']==4){
				DB::query("update ".DB::table('it618_scoremall_sale')." set it618_state=6 WHERE id=".$delid);
				$ok=$ok+1;
				if($li1il11[14]!='l')return;
			}
		}
		
		showmessage(it618_mall_getlang('s245').$ok, dreferer(), array(), array('alert' => 'right'));

	}
	
	if(submitcheck('it618submit_data')){
		$strtmp=it618_mall_getlang('s556')."\n";
		$query = DB::query("SELECT s.* FROM ".DB::table('it618_scoremall_sale')." s,".DB::table('it618_scoremall_goods')." g WHERE g.it618_uid=".$_G['uid']." and s.it618_pid=g.id $extrasql order by it618_pid,it618_time desc");
		while($it618_scoremall_sale = DB::fetch($query)) {
			$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
			
			$strtmp.=$it618_scoremall_goods['it618_name'].",".$it618_scoremall_sale['it618_count'].",".it618_scoremall_getusername($it618_scoremall_sale['it618_uid']).",".$it618_scoremall_sale['it618_addr'].$it618_scoremall_sale['it618_bz'].",".$it618_scoremall_sale['it618_code'].",".date('Y-m-d H:i:s', $it618_scoremall_sale['it618_time'])."\n";
			$datacount=$datacount+1;
		}
	
		$timestr=date("YmdHis") . '_' . $datacount;
		$datapath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/temp/shop/shop'.$_G['uid'].'/';
		if (!file_exists($datapath)) {
			mkdir($datapath);
		}
		it618_scoremall_delfile($datapath);
		
		@$fp = fopen($datapath.$timestr.'.csv',"w");
		if(!$fp){
			echo "system error";
			exit();
		}else {
			fwrite($fp,$strtmp);
			fclose($fp);
		}
		
		showmessage($it618_mall_lang['s1060'].'<a href="javascript:" onclick="window.open(\''.$_G['siteurl'].'source/plugin/it618_scoremall/temp/shop/shop'.$_G['uid'].'/'.$timestr.'.csv\')"><font color=red>'.$it618_mall_lang['s1061'].'</font></a>', '', array(), array('alert' => 'right'));
	}

	if(isset($_GET['saleid'])){
		$extrasql .= " AND s.id = ".intval($_GET['saleid']);
	}
	if($li1il11[14]!='l')return;
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_sale')." s,".DB::table('it618_scoremall_goods')." g WHERE g.it618_uid=".$_G['uid']." and s.it618_pid=g.id ". $extrasql);
	if($li1il11[0]!='i')return;
	$count1 = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_sale')." s,".DB::table('it618_scoremall_goods')." g WHERE s.it618_state = 5 and g.it618_uid=".$_G['uid']." and s.it618_pid=g.id ". $extrasql);
	
	if($_GET['state']==0)$tuihuo=' '.it618_mall_getlang('s248').$count1;
	
	
	if($_G['cache']['plugin']['it618_scoremall']['rewriteurl']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_scoremall:scoremall_store&cid=1".$uri);
	}else{
		$hrefsql=it618_scoremall_getrewrite('store','ac@find@1@0@it618page','plugin.php?id=it618_scoremall:scoremall_store&cid=1');
		$multipage = multi($count, $ppp, $page, $_G['siteurl'].$hrefsql);
		$multipage = it618_scoremall_multipage($multipage,$uri);
	}
	
	if($li1il11[8]!='o')return;
	$tmpstr1.='<tr>
				<td colspan="15"><div class="fixsel">'.it618_mall_getlang('s150').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.it618_mall_getlang('s522').' <input name="findcode" value="'.$_GET['findcode'].'" class="txt" style="width:155px" /> '.it618_mall_getlang('s151').' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> '.it618_mall_getlang('s152').' <select name="state"><option value=0 '.$state0.'>'.it618_mall_getlang('s153').'</option><option value=1 '.$state1.'>'.it618_getbuyname(it618_mall_getlang('s154')).'</option><option value=2 '.$state2.'>'.it618_mall_getlang('s155').'</option><option value=3 '.$state3.'>'.it618_mall_getlang('s156').'</option><option value=4 '.$state4.'>'.it618_mall_getlang('s157').'</option><option value=5 '.$state5.'>'.it618_mall_getlang('s246').'</option><option value=6 '.$state6.'>'.it618_mall_getlang('s247').'</option></select> &nbsp;<input type="submit" class="btn" name="it618submit_sale_find" value="'.it618_mall_getlang('s149').'" /></div></td></tr><tr><td colspan=13>'.it618_mall_getlang('s158').$count.' '.$tuihuo.'
				</td>
				</tr>
				<tr class="header">
				<th></th><th>'.it618_mall_getlang('s160').'</th><th width=150 style="text-align:center">'.$it618_mall_lang['s161'].'/'.$it618_mall_lang['s162'].'/'.$it618_mall_lang['s473'].'</th><th width="50" style="text-align:center">'.it618_mall_getlang('s163').'</th><th width=150 style="text-align:center">'.$it618_mall_lang['s164'].'/'.$it618_mall_lang['s254'].'/'.$it618_mall_lang['s255'].'</th><th>'.it618_mall_getlang('s165').'</th><th>'.it618_mall_getlang('s411').'</th><th>'.it618_mall_getlang('s166').'</th><th>'.it618_getbuyname(it618_mall_getlang('s167')).'</th>
				</tr>';

	$query = DB::query("SELECT s.* FROM ".DB::table('it618_scoremall_sale')." s,".DB::table('it618_scoremall_goods')." g WHERE g.it618_uid=".$_G['uid']." and s.it618_pid=g.id ".$extrasql." order by id desc LIMIT ".$startlimit.",".$ppp);
	$n=1;
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_kd')." ORDER BY it618_order DESC");
	$tmp.='<option value="0">'.it618_mall_getlang('s412').'</option>';
	while($it618_tmp =	DB::fetch($query1)) {
		$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
	}
	while($it618_scoremall_sale = DB::fetch($query)) {
		if(count($li1il11)!=15)return;
		$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
		$it618_class3_id=$it618_scoremall_goods['it618_class3_id'];
		$it618_name=$it618_scoremall_goods['it618_name'];
		$it618_picsmall=it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']);
		if($li1il11[0]!='i')return;
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_scoremall_sale['it618_uid']);
		if($li1il11[8]!='o')return;
		if($it618_scoremall_sale['it618_state']==2){
			$tmp1=str_replace('<option value='.$it618_scoremall_sale['it618_kdid'].'>','<option value='.$it618_scoremall_sale['it618_kdid'].' selected="selected">',$tmp);
			$strkd='<font color=green>'.it618_mall_getlang('s413').'<select name="it618_kdid['.$it618_scoremall_sale[id].']">'.$tmp1.'</select><br>'.it618_mall_getlang('s414').'<input type="text" class="txt" style="width:112px" name="it618_kddan['.$it618_scoremall_sale[id].']" value="'.$it618_scoremall_sale['it618_kddan'].'"></font>';
		}else{
			if($it618_scoremall_sale['it618_kdid']!=0&&$it618_scoremall_sale['it618_kddan']!=''){
				$it618_scoremall_kd=DB::fetch_first("select * from ".DB::table('it618_scoremall_kd')." WHERE id=".$it618_scoremall_sale['it618_kdid']);
				$strkd=''.it618_mall_getlang('s413').'<a href="'.$it618_scoremall_kd['it618_url'].'" target="_blank">'.$it618_scoremall_kd['it618_name'].'</a><br>'.it618_mall_getlang('s414').'<font color=green>'.$it618_scoremall_sale['it618_kddan'].'</font>';
			}else{
				$strkd='';	
			}
		}
		
		$strtmp='';
		
		if(count(explode($it618_mall_lang['s30'],$it618_scoremall_sale['it618_addr']))>1){
			$strtmp=$it618_mall_lang['s169'];
		}else{
			$strtmp='';
			$strkd='';
		}
		if($it618_scoremall_sale['it618_bz']!=""){
			$strtmp.=$it618_mall_lang['s171'];
			if($strtmp==$it618_mall_lang['s171']){
				$strtmp=str_replace('/','',$strtmp);
			}
		}else{
			$strtmp.='';
		}
		$strtmp='<a href="javascript:" id="bz'.$it618_scoremall_sale[id].'">'.$strtmp.'</a>';
		if($li1il11[8]!='o')return;
		if($it618_scoremall_sale['it618_state']==1)$it618_state='<font color=red>'.it618_getbuyname(it618_mall_getlang('s173')).'</font>';
		if($it618_scoremall_sale['it618_state']==2)$it618_state='<font color=green>'.it618_mall_getlang('s174').'</font>';
		if($it618_scoremall_sale['it618_state']==3)$it618_state='<font color=green>'.it618_mall_getlang('s175').'</font>';
		if($it618_scoremall_sale['it618_state']==4)$it618_state='<font color=red>'.it618_mall_getlang('s176').'</font>';
		if($it618_scoremall_sale['it618_state']==5)$it618_state='<font color=#999>'.it618_mall_getlang('s246').'</font>';
		if($it618_scoremall_sale['it618_state']==6)$it618_state='<font color=blue>'.it618_mall_getlang('s247').'</font>';
		if(count($li1il11)!=15)return;
		$tmpstr='';
		$saleid=$it618_scoremall_sale['id'];
		for($i=0;$i<7-strlen($saleid);$i++){
			$tmpstr.='0';
		}
		$saleid=$tmpstr.$saleid;
		
		if($it618_scoremall_sale['it618_code']!=''){
			$strcode=' '.$it618_mall_lang['s521'].$it618_scoremall_sale['it618_code'];
		}else{
			$strcode='';
		}
		
		$jfname=$_G['setting']['extcredits'][$it618_scoremall_sale['it618_jfid']]['title'];
		$it618_price1='';
		if($it618_scoremall_sale['it618_price1']>0){
			$jfname1=$_G['setting']['extcredits'][$it618_scoremall_sale['it618_jfid1']]['title'];
			$it618_price1=' + '.$it618_scoremall_sale['it618_price1'].$jfname1;
		}
		
		$it618_quanmoney='';
		if($it618_scoremall_sale['it618_quanmoney']>0){
			$it618_quanmoney=$it618_scoremall_sale['it618_quanmoney'].$jfname;
		}
		if($it618_scoremall_sale['it618_quanmoney1']>0){
			$it618_quanmoney=$it618_scoremall_sale['it618_quanmoney1'].$jfname1;
		}
		
		$it618_money1='';
		if($it618_scoremall_sale['it618_price1']>0){
			$it618_money1=' + '.intval($it618_scoremall_sale['it618_price1']*$it618_scoremall_sale['it618_count']-$it618_scoremall_sale['it618_quanmoney1']).$jfname1;
		}
		
		$it618_saletc='';
		if($it618_scoremall_sale['it618_saletc']>0){
			$it618_saletc=$it618_scoremall_sale['it618_saletc'].$jfname;
		}
		
		$it618_saletc1='';
		if($it618_scoremall_sale['it618_saletc1']>0){
			$it618_saletc1=' + '.$it618_scoremall_sale['it618_saletc1'].$jfname1;
		}
		
		$it618_kmcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods_salekm')." where it618_saleid=".$it618_scoremall_sale['id']);
		$it618_btnkm='';
		if($it618_scoremall_sale['it618_km']!=''||$it618_kmcount>0){
			$it618_btnkm='<a href="javascript:" onclick="showWindow(\'it618_showkm\',\''.$_G['siteurl'].'plugin.php?id=it618_scoremall:showkm&ac=shop&saleid='.$it618_scoremall_sale['id'].'\');" class="it618_btn">'.it618_mall_getlang('s441').'</a>';
		}
		
		$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
		$tmpstr1.='<tr class="hover align"><td width="40"><input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_scoremall_sale[id].'"><label for="chk_del'.$n.'" title="'.it618_mall_getlang('s401').'D'.$saleid.$strcode.'">'.$it618_scoremall_sale['id'].'</label></td>
			<td><a href="'.$tmpurl.'" title="'.it618_mall_getlang('s177').''.$it618_scoremall_sale['it618_pid'].' '.it618_mall_getlang('s178').''.it618_scoremall_class1name($it618_class3_id).' '.it618_scoremall_class2name($it618_class3_id).' '.it618_scoremall_class3name($it618_class3_id).'" target="_blank"><img style="float:left" src="'.$it618_picsmall.'" width="50" height="50" /><div style="float:left;width:180px;text-align:left;padding-left:3px">'.$it618_name.'</div></a></td>
			<td>'.$it618_scoremall_sale['it618_price'].$jfname.$it618_price1.'<br>'.$it618_scoremall_sale['it618_zk'].'%<br>'.$it618_quanmoney.'</td>
			<td>'.$it618_scoremall_sale['it618_count'].'</td>
			<td>'.intval($it618_scoremall_sale['it618_price']*$it618_scoremall_sale['it618_count']-$it618_scoremall_sale['it618_quanmoney']).$jfname.$it618_money1.'<br>'.$it618_scoremall_sale['it618_tc'].'%<br>'.$it618_saletc.$it618_saletc1.'</td>
			<td>'.$strtmp.'</td>
			<td align="left">'.$strkd.$it618_btnkm.'</td>
			<td width="40"><font color=red>'.$it618_state.'</font></td>
			<td width="70"><a href="'.it618_scoremall_rewriteurl($it618_scoremall_sale['it618_uid']).'" target="_blank">'.$username.'</a><br>'.date('Y-m-d H:i:s', $it618_scoremall_sale['it618_time']).'</td>';
		$n=$n+1;
		$tmpjs1.='KindEditor.ready(function(K) {K(\'#bz'.$it618_scoremall_sale[id].'\').click(function() {
			var dialog = K.dialog({
				width : 538,
				title : \''.it618_mall_getlang('s179').'\',
				body : \'<div><iframe id="frm" src="plugin.php?id=it618_scoremall:adminshowsalemsg&saleid='.$it618_scoremall_sale[id].'" style="border:0;" frameborder=0 width="520" height="180"></iframe></div>\',
				closeBtn : {
					name : \''.it618_mall_getlang('s180').'\',
					click : function(e) {
						dialog.remove();
					}
				},
				noBtn : {
					name : \''.it618_mall_getlang('s180').'\',
					click : function(e) {
						dialog.remove();
					}
				}
			});
		});});';
	}
	$uri=str_replace("?","",$uri);
	$uri=str_replace("(","it618_str1",$uri);
	$uri=str_replace(")","it618_str2",$uri);
	if($count>0)$tmpstr1.='<tr><td class="td25"><input type="checkbox" id="chk_del" class="checkbox" onclick="check_all(this, \'chk_del\','.$n.')" /><label for="chk_del">'.it618_mall_getlang('s415').'</label></td><td colspan="15"><div class="fixsel" style="float:left"><input type="submit" class="btn" name="it618submit_sale_del" value="'.it618_mall_getlang('s182').'" onclick="return confirm(\''.it618_mall_getlang('s183').'\')" /> <input type="submit" class="btn" name="it618submit_sale_yifahuo" value="'.it618_mall_getlang('s184').'" onclick="return confirm(\''.it618_mall_getlang('s185').'\')"/> <input type="submit" class="btn" name="it618submit_sale_kd" value="'.it618_mall_getlang('s416').'"/> <input type="submit" class="btn" name="it618submit_sale_tongyi" value="'.it618_mall_getlang('s256').'" onclick="return confirm(\''.it618_mall_getlang('s257').'\')"/> <input type="submit" class="btn" name="it618submit_sale_jujue" value="'.it618_mall_getlang('s258').'" onclick="return confirm(\''.it618_mall_getlang('s259').'\')"/> <input type="submit" class="btn" name="it618submit_data" value="'.it618_mall_getlang('s555').'"/> </td></tr><tr><td></td><td colspan="11">'.it618_getbuyname(it618_mall_getlang('s186')).'</td></tr><tr><td colspan="15">&nbsp;<input type=hidden value='.$page.' name=page /></div><div style="float:right">'.$multipage.'</div></td></tr>';
}elseif($cid==2){
	if(submitcheck('it618submit_product_add')){
		$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_goods')." WHERE it618_uid=".$_G['uid']);
		$pcount = DB::result_first("SELECT it618_pcount FROM ".DB::table('it618_scoremall_store')." WHERE it618_uid=".$_G['uid']);
		if($count>=$pcount){
			showmessage(it618_mall_getlang('s656').' <font color=red>'.$count.'</font> '.it618_mall_getlang('s657').' <font color=red>'.$pcount.'</font> '.it618_mall_getlang('s658'), '', array(), array('alert' => 'error'));
		}
		if($_GET['it618_class3_id']=='0'){
			showmessage(it618_mall_getlang('s92'), '', array(), array('alert' => 'error'));
		}
		if($li1il11[0]!='i')return;
		if($_GET['it618_name']==''){
			showmessage(it618_mall_getlang('s93'), '', array(), array('alert' => 'error'));
		}
		if($_GET['it618_picbig']==''){
			showmessage(it618_mall_getlang('s94'), '', array(), array('alert' => 'error'));
		}
		
		if($it618_scoremall['mall_credit']=='')$mall_credit=1;else $mall_credit=$it618_scoremall['mall_credit'];
		
		$it618_jforder = DB::result_first("SELECT it618_jforder FROM ".DB::table('it618_scoremall_goods')." WHERE it618_uid=".$_G['uid'])." order by it618_jforder desc";
	
		$pid=C::t('#it618_scoremall#it618_scoremall_goods')->insert(array(
			'it618_class3_id' => $_GET['it618_class3_id'],
			'it618_name' => dhtmlspecialchars($_GET['it618_name']),
			'it618_jfid' => $mall_credit,
			'it618_picbig' => dhtmlspecialchars($_GET['it618_picbig']),
			'it618_picbig1' => dhtmlspecialchars($_GET['it618_picbig1']),
			'it618_picbig2' => dhtmlspecialchars($_GET['it618_picbig2']),
			'it618_picbig3' => dhtmlspecialchars($_GET['it618_picbig3']),
			'it618_picbig4' => dhtmlspecialchars($_GET['it618_picbig4']),
			'it618_message_daishen' => $_GET['it618_message'],
			'it618_uid' => $_G['uid'],
			'it618_jforder' => $it618_jforder,
			'it618_state' => 0,
		), true);
		
		$storename=DB::result_first("SELECT it618_name FROM ".DB::table('it618_scoremall_store')." WHERE it618_uid=".$_G['uid']);
		
		for($i=0;$i<=4;$i++){
			if($i==0)$tmpi='';else $tmpi=$i;
			$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
			
			if($get_it618_picbig!=''){
				$smallpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/data/u'.$_G['uid'].'/smallimage/';
				if (!file_exists($smallpath)) {
					mkdir($smallpath);
				}
	
				$tmparr1=explode("://",$get_it618_picbig);
				if(count($tmparr1)>1){
					$it618_url=$get_it618_picbig;
				}else{
					$tmparr=explode("source",$get_it618_picbig);
					$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
				}
				
				$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
				$file_extarr=explode("?",$file_ext);
				$file_ext=$file_extarr[0];
				$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/data/u'.$_G['uid'].'/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext;
				it618_scoremall_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,640,1);
	
			}
		}
	
		showmessage(it618_mall_getlang('s239'), 'plugin.php?id=it618_scoremall:scoremall_store&cid=3', array(), array('alert' => 'right'));
	}
	if(count($li1il11)!=15)return;
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class1')." ORDER BY it618_order DESC");
	while($it618_tmp =	DB::fetch($query1)) {
		$class2count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_class2')." WHERE it618_class1_id=".$it618_tmp['id']);
		if($class2count>0){
			$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
		}
	}

	$tmpstr2='<tr>
			  <td width=60>'.it618_mall_getlang('s97').'</td><td><select id="it618_class1_id" name="it618_class1_id" onchange="redirec_class2(this.options.selectedIndex);redirec_class3(this.options[this.options.selectedIndex].value);"><option value="0">'.it618_mall_getlang('s98').'</option>'.$tmp.'</select><select id="it618_class2_id" name="it618_class2_id" onchange="redirec_class3(this.options[this.options.selectedIndex].value);"><option value="0">'.it618_mall_getlang('s99').'</option></select><select id="it618_class3_id" name="it618_class3_id"><option value="0">'.it618_mall_getlang('s100').'</option></select></td>
			  </tr>
			  <tr>
			  <td>'.it618_mall_getlang('s101').'</td><td><input type="text" class="txt" style="width:400px" id="it618_name" name="it618_name"></td>
			  </tr>
			  <tr><td>'.$it618_mall_lang['s104'].'</td><td><img id="img1" width="80" height="80" align="absmiddle"/><input type="text" id="url1" name="it618_picbig" readonly="readonly"/> <input type="button" id="image1" value="'.$it618_mall_lang['s105'].'" />   '.$it618_mall_lang['s106'].'</td></tr>
<tr><td></td><td><img id="img11"  width="80" height="80" align="absmiddle"/><input type="text" id="url11" name="it618_picbig1" readonly="readonly" /> <input type="button" id="image11" value="'.$it618_mall_lang['s105'].'" /> <input type="button" value="'.$it618_mall_lang['s107'].'" onclick="delpic(1)" /> <img id="img12"  width="80" height="80" align="absmiddle"/><input type="text" id="url12" name="it618_picbig2" readonly="readonly"/> <input type="button" id="image12" value="'.$it618_mall_lang['s105'].'" /> <input type="button" value="'.$it618_mall_lang['s107'].'" onclick="delpic(2)" /></td></tr>
<tr><td></td><td><img id="img13" width="80" height="80" align="absmiddle"/><input type="text" id="url13" name="it618_picbig3" readonly="readonly"/> <input type="button" id="image13" value="'.$it618_mall_lang['s105'].'"/> <input type="button" value="'.$it618_mall_lang['s107'].'" onclick="delpic(3)" />  <img id="img14" width="80" height="80" align="absmiddle"/><input type="text" id="url14" name="it618_picbig4" readonly="readonly"/> <input type="button" id="image14" value="'.$it618_mall_lang['s105'].'" /> <input type="button" value="'.$it618_mall_lang['s107'].'" onclick="delpic(4)" /></td></tr>
			  <tr>
			  <td>'.it618_mall_getlang('s109').'</td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;"></textarea>'.it618_mall_getlang('s523').'</td>
			  </tr>';
	
	$count2 = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_class2'));
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class1')." ORDER BY it618_order DESC");
	$n1=1;
	if($li1il11[0]!='i')return;
	while($it618_tmp1 =	DB::fetch($query1)) {
		$class2count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_class2')." WHERE it618_class1_id=".$it618_tmp1['id']);
		if($class2count>0){
			$n2=1;
			$query2 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order DESC");
			while($it618_tmp2 =	DB::fetch($query2)) {
				$tmp2.='select_class2['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
				$n2=$n2+1;
			}
			$n1=$n1+1;
		}
	}
	if(count($li1il11)!=15)return;
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class2')." ORDER BY it618_order desc");
	$n1=1;
	$n3=1;
	while($it618_tmp1 =	DB::fetch($query1)) {
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." where it618_class2_id=".$it618_tmp1['id']." ORDER BY it618_order DESC");
		while($it618_tmp2 =	DB::fetch($query2)) {
			$tmp3.='select_class3['.$n3.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp1['id'].'_'.$it618_tmp2['id'].'");';
			$n3=$n3+1;
		}
		$n1=$n1+1;
	}
	if($li1il11[8]!='o')return;
	$cid2_js= '
	<script>
	var shopuid='.$shopuid.';
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_scoremall/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_scoremall/kindeditor/php/upload_json.php?uid='.$_G[uid].'&imgwidth=910'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_scoremall/kindeditor/php/file_manager_json.php?uid='.$_G[uid].'\',
			allowFileManager : true,
			filterMode:false
		});
		
		K(\'#image1\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		K(\'#image11\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url11\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url11\').val(url);
						K(\'#img11\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		K(\'#image12\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url12\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url12\').val(url);
						K(\'#img12\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		K(\'#image13\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url13\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url13\').val(url);
						K(\'#img13\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		K(\'#image14\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url14\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url14\').val(url);
						K(\'#img14\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
	});
	
	var arrcount='.$count2.';
	var select_class2 = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class2[i] = new Array();
	}
	
	'.$tmp2.'
	
	function redirec_class2(x)
	{
	 var temp = document.getElementById("it618_class2_id"); 
	 temp.options.length=1;
	 for (i=1;i<select_class2[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class2[x][i].text,select_class2[x][i].value);
	 }
	 temp.options[0].selected=true;
	 
	}
	
	redirec_class2(document.getElementById("it618_class1_id").options.selectedIndex);
	
	
	
	var arrcount='.$n3.';
	var select_class3 = new Array(arrcount);
	
	'.$tmp3.'
	
	function redirec_class3(x)
	{
	 var temp = document.getElementById("it618_class3_id"); 
	 temp.options.length=1;
	 n=1;
	 for (i=1;i<select_class3.length;i++)
	 {
		 var tmparr=select_class3[i].value.split("_");
		 if(tmparr[0]==x){
			 temp.options[n]=new Option(select_class3[i].text,tmparr[1]);
			 n=n+1;
		 }
	 }
	 temp.options[0].selected=true;
	
	}
	
	redirec_class3(document.getElementById("it618_class2_id").options[document.getElementById("it618_class2_id").options.selectedIndex].value);
	</script>
	';
}elseif($cid==3){
	if($_GET['key']!=''){
		$extrasql .= " AND it618_name LIKE '%".addcslashes(addslashes($_GET['key']),'%_')."%'";
	}
	
	$chkstate0='';$chkstate1='';$chkstate2='';$chkstate3='';
	if($_GET['chkstate']==0){$extrasql .= "";$chkstate0='selected="selected"';}
	if($_GET['chkstate']==1){$extrasql .= " AND it618_state = 0";$chkstate1='selected="selected"';}
	if($_GET['chkstate']==2){$extrasql .= " AND it618_state = 1";$chkstate2='selected="selected"';}
	if($_GET['chkstate']==3){$extrasql .= " AND it618_state = 2";$chkstate3='selected="selected"';}
	if($li1il11[0]!='i')return;
	$state0='';$state1='';$state2='';$state3='';$state4='';$state5='';$state6='';$state7='';$state8='';$state9='';$state10='';$state11='';$state12='';$state13='';
	if($_GET['state']==0){$extrasql .= "";$state0='selected="selected"';}
	if($_GET['state']==1){$extrasql .= " AND it618_isbm = 1";$state1='selected="selected"';}
	if($_GET['state']==2){$extrasql .= " AND it618_isbm = 0";$state2='selected="selected"';}
	if($_GET['state']==3){$extrasql .= " AND it618_isaddr = 1";$state3='selected="selected"';}
	if($_GET['state']==4){$extrasql .= " AND it618_isaddr = 0";$state4='selected="selected"';}
	if($_GET['state']==5){$extrasql .= " AND it618_ison = 1";$state5='selected="selected"';}
	if($_GET['state']==6){$extrasql .= " AND it618_ison = 0";$state6='selected="selected"';}
	if($_GET['state']==7){$extrasql .= " AND it618_isorder = 1";$state7='selected="selected"';}
	if($_GET['state']==8){$extrasql .= " AND it618_isorder = 0";$state8='selected="selected"';}
	if($_GET['state']==9){$extrasql .= " AND it618_istaobao = 1";$state9='selected="selected"';}
	if($_GET['state']==10){$extrasql .= " AND it618_istaobao = 0";$state10='selected="selected"';}
	if($_GET['state']==11){$extrasql .= " AND it618_isquan = 1";$state11='selected="selected"';}
	if($_GET['state']==12){$extrasql .= " AND it618_isquan = 2";$state12='selected="selected"';}
	if($_GET['state']==13){$extrasql .= " AND it618_isquan = 0";$state13='selected="selected"';}
	if(count($li1il11)!=15)return;
	$orderby0='';$orderby1='';$orderby2='';$orderby3='';$orderby4='';
	if($_GET['orderby']==0){$extrasql .= " order by it618_order desc,id desc";$orderby0='selected="selected"';}
	if($_GET['orderby']==1){$extrasql .= " order by it618_count desc";$orderby1='selected="selected"';}
	if($_GET['orderby']==2){$extrasql .= " order by it618_salecount desc";$orderby2='selected="selected"';}
	if($_GET['orderby']==3){$extrasql .= " order by it618_views desc";$orderby3='selected="selected"';}
	if($_GET['orderby']==4){$extrasql .= " order by it618_score desc";$orderby4='selected="selected"';}
	
	if($_GET['key']!='')$uri.='&key='.$_GET['key'];
	if($_GET['chkstate']!=0)$uri.='&chkstate='.$_GET['chkstate'];
	if($_GET['state']!=0)$uri.='&state='.$_GET['state'];
	if($_GET['orderby']!=0)$uri.='&orderby='.$_GET['orderby'];

	if($uri!=''){
		$uri='?'.$uri;
		$uri=str_replace("?&","?",$uri);
	}
	
	if($li1il11[4]!='8')return;
	if(submitcheck('it618submit_product_del')){
		$del=0;
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			$salecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_sale')." WHERE it618_pid=".$delid);
			if($salecount<=0){
				$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$delid);
				$tmpurl=$_G['siteurl'].it618_scoremall_getrewrite('product',$delid,'plugin.php?id=it618_scoremall:scoremall_page&pid='.$delid);
				$qrcodeurl=md5($tmpurl);
				$qrcodeurl='source/plugin/it618_scoremall/qrcode/'.$qrcodeurl.'.png';
				$tmparr=explode("source",$qrcodeurl);
				$qrcodeurl=DISCUZ_ROOT.'./source'.$tmparr[1];
				
				if(file_exists($qrcodeurl)){
					$result=unlink($qrcodeurl);
				}
				
				for($i=0;$i<=4;$i++){
					if($i==0)$tmpi='';else $tmpi=$i;
					$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
					
					if($it618_scoremall_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
						$tmparr=explode("source",$it618_scoremall_goods['it618_picbig'.$tmpi]);
						$tmparr1=explode("://",$it618_scoremall_goods['it618_picbig'.$tmpi]);
						$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
						
						if(file_exists($it618_picbig)&&count($tmparr1)==1){
							$result=unlink($it618_picbig);
						}
					}
					
					$file_ext=strtolower(substr($it618_scoremall_goods['it618_picbig'.$tmpi],strrpos($it618_scoremall_goods['it618_picbig'.$tmpi], '.')+1)); 
					$file_extarr=explode("?",$file_ext);
					$file_ext=$file_extarr[0];
					$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/data/u'.$it618_scoremall_goods['it618_uid'].'/smallimage/goods'.$delid.'_'.$i.'.'.$file_ext;
					if(file_exists($it618_smallurl)){
						$result=unlink($it618_smallurl);
					}
				}
				
				DB::delete('it618_scoremall_goods', "id=$delid");
				$del=$del+1;
				if($li1il11[0]!='i')return;
			}
		}
		
		if($li1il11[4]!='8')return;
		showmessage(it618_mall_getlang('s114').$del, dreferer(), array(), array('alert' => 'right'));
	}
	
	if(submitcheck('it618submit_product_edits')){
		$ok=0;
		
		if(is_array($_GET['it618_name'])) {
			foreach($_GET['it618_name'] as $id => $val) {
				if(intval($_GET['it618_score'][$id])<$it618_pprice){
					$it618_score=$it618_pprice;
				}else{
					$it618_score=intval($_GET['it618_score'][$id]);
				}
				
				if(intval($_GET['it618_score1'][$id])<$it618_pprice){
					$it618_score1=$it618_pprice;
				}else{
					$it618_score1=intval($_GET['it618_score1'][$id]);
				}
				
				$it618_jfid=$_GET['it618_jfid'][$id];
				$it618_jfid1=$_GET['it618_jfid1'][$id];
				
				if($it618_jfid==$it618_jfid1){
					$it618_jfid1=0;
					$it618_score1=0;
				}
				
				C::t('#it618_scoremall#it618_scoremall_goods')->update($id,array(
					'it618_name' => dhtmlspecialchars($_GET['it618_name'][$id]),
					'it618_score' => $it618_score,
					'it618_score1' => $it618_score1,
					'it618_jfid' => $it618_jfid,
					'it618_jfid1' => $it618_jfid1,
					'it618_xiangoutime' => intval($_GET['it618_xiangoutime'][$id]),
					'it618_xiangoucount' => intval($_GET['it618_xiangoucount'][$id]),
					'it618_xgtype' => $_GET['it618_xgtype'][$id],
					'it618_xgtime1' => dhtmlspecialchars($_GET['it618_xgtime1'][$id]),
					'it618_xgtime2' => dhtmlspecialchars($_GET['it618_xgtime2'][$id]),
					'it618_ison' => $_GET['it618_ison'][$id],
					'it618_isbm' => $_GET['it618_isbm'][$id],
					'it618_isorder' => $_GET['it618_isorder'][$id],
					'it618_istaobao' => $_GET['it618_istaobao'][$id],
					'it618_isquan' => $_GET['it618_isquan'][$id],
					'it618_taobaourl' => dhtmlspecialchars($_GET['it618_taobaourl'][$id]),
					'it618_isaddr' => $_GET['it618_isaddr'][$id],
					'it618_order' => intval($_GET['it618_order'][$id]),
				));
				
				if($_GET['it618_count'][$id]!='-1'){
					C::t('#it618_scoremall#it618_scoremall_goods')->update($id,array(
						'it618_count' => intval($_GET['it618_count'][$id])
					));
				}
				$ok=$ok+1;
				if($li1il11[14]!='l')return;
			}
		}
		if($li1il11[4]!='8')return;
		showmessage(it618_mall_getlang('s113').$ok, dreferer(), array(), array('alert' => 'right'));
	}
	
	if(submitcheck('it618submit_product_edit')){
		if($_GET['it618_class3_id']=='0'){
			showmessage(it618_mall_getlang('s92'), '', array(), array('alert' => 'error'));
		}
		if($li1il11[0]!='i')return;
		if($_GET['it618_name']==''){
			showmessage(it618_mall_getlang('s93'), '', array(), array('alert' => 'error'));
		}
		if($_GET['it618_picbig']==''){
			showmessage(it618_mall_getlang('s94'), '', array(), array('alert' => 'error'));
		}
		if(count($li1il11)!=15)return;
		$it618_uid=DB::result_first("SELECT it618_uid FROM ".DB::table('it618_scoremall_goods')." WHERE id=".intval($_GET['pid']));
		if($it618_uid!=$_G['uid']){
			showmessage(it618_mall_getlang('s661'), '', array(), array('alert' => 'error'));
		}
		
		for($i=0;$i<=4;$i++){
			if($i==0)$tmpi='';else $tmpi=$i;
			$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
			
			if($it618_scoremall_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
				$tmparr=explode("source",$it618_scoremall_goods['it618_picbig'.$tmpi]);
				$tmparr1=explode("://",$it618_scoremall_goods['it618_picbig'.$tmpi]);
				$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
				
				if(file_exists($it618_picbig)&&count($tmparr1)==1){
					$result=unlink($it618_picbig);
				}
			}
			
			$file_ext=strtolower(substr($it618_scoremall_goods['it618_picbig'.$tmpi],strrpos($it618_scoremall_goods['it618_picbig'.$tmpi], '.')+1)); 
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/data/u'.$_G['uid'].'/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext;
			if(file_exists($it618_smallurl)){
				$result=unlink($it618_smallurl);
			}
			
			if($get_it618_picbig!=''){
				$smallpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/data/u'.$_G['uid'].'/smallimage/';
				if (!file_exists($smallpath)) {
					mkdir($smallpath);
				}
	
				$tmparr1=explode("://",$get_it618_picbig);
				if(count($tmparr1)>1){
					$it618_url=$get_it618_picbig;
				}else{
					$tmparr=explode("source",$get_it618_picbig);
					$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
				}
				
				$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1));
				$file_extarr=explode("?",$file_ext);
				$file_ext=$file_extarr[0];
				$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/data/u'.$_G['uid'].'/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext;
				it618_scoremall_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,640,1);
			}
	
		}
		
		$it618_ischeck=DB::result_first("SELECT it618_ischeck FROM ".DB::table('it618_scoremall_goods')." WHERE id=".intval($_GET['pid']));
		if($it618_ischeck==0){
			C::t('#it618_scoremall#it618_scoremall_goods')->update(intval($_GET['pid']),array(
				'it618_class3_id' => $_GET['it618_class3_id'],
				'it618_name' => dhtmlspecialchars($_GET['it618_name']),
				'it618_picbig' => dhtmlspecialchars($_GET['it618_picbig']),
				'it618_picbig1' => dhtmlspecialchars($_GET['it618_picbig1']),
				'it618_picbig2' => dhtmlspecialchars($_GET['it618_picbig2']),
				'it618_picbig3' => dhtmlspecialchars($_GET['it618_picbig3']),
				'it618_picbig4' => dhtmlspecialchars($_GET['it618_picbig4']),
				'it618_message' => $_GET['it618_message'],
			));
			if($li1il11[4]!='8')return;
			
			showmessage(it618_mall_getlang('s240'), 'plugin.php?id=it618_scoremall:scoremall_store&cid=3&page='.$_GET['page'], array(), array('alert' => 'right'));
			
		}else{
			C::t('#it618_scoremall#it618_scoremall_goods')->update(intval($_GET['pid']),array(
				'it618_class3_id' => $_GET['it618_class3_id'],
				'it618_name' => dhtmlspecialchars($_GET['it618_name']),
				'it618_picbig' => dhtmlspecialchars($_GET['it618_picbig']),
				'it618_picbig1' => dhtmlspecialchars($_GET['it618_picbig1']),
				'it618_picbig2' => dhtmlspecialchars($_GET['it618_picbig2']),
				'it618_picbig3' => dhtmlspecialchars($_GET['it618_picbig3']),
				'it618_picbig4' => dhtmlspecialchars($_GET['it618_picbig4']),
				'it618_message_daishen' => $_GET['it618_message'],
				'it618_state' => 0,
			));
			$storename=DB::result_first("SELECT it618_name FROM ".DB::table('it618_scoremall_store')." WHERE it618_uid=".$_G['uid']);
			if($li1il11[4]!='8')return;
			showmessage(it618_mall_getlang('s241'), 'plugin.php?id=it618_scoremall:scoremall_store&cid=3&page='.$_GET['page'], array(), array('alert' => 'right'));
		}
		
	}
	
	if(submitcheck('it618submit_km')){
		$ok1=0;
		$del=0;

		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			DB::delete('it618_scoremall_goods_km', "id=$delid");
			$del=$del+1;
		}
	
		if(is_array($_GET['it618_code'])) {
			foreach($_GET['it618_code'] as $id => $val) {
	
				C::t('#it618_scoremall#it618_scoremall_goods_km')->update($id,array(
					'it618_code' => trim($_GET['it618_code'][$id])
				));
				$ok1=$ok1+1;
			}
		}
		
		$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".intval($_GET['pid']));
		DB::query("update ".DB::table('it618_scoremall_goods')." set it618_count=".$kmcount." where id=".intval($_GET['pid']));
		
		showmessage(it618_mall_getlang('s39').$ok1.' '.it618_mall_getlang('s41').$del.")", dreferer(), array(), array('alert' => 'right'));
	}
	
	if(submitcheck('it618submit_km_adds')){
		$ok1=0;
		
		$lines=str_replace(array("\r\n", "\r", "\n"), '@||@', $_GET['it618_name_adds']);
		$line=explode("@||@",$lines);
	
		foreach($line as $key =>$li)
		{
			if(trim($li)!=''){
				C::t('#it618_scoremall#it618_scoremall_goods_km')->insert(array(
					'it618_pid' => intval($_GET['pid']),
					'it618_code' => trim($li)
				), true);
				$ok1=$ok1+1;
			}
		}
		
		$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".intval($_GET['pid']));
		DB::query("update ".DB::table('it618_scoremall_goods')." set it618_count=".$kmcount." where id=".intval($_GET['pid']));
		
		showmessage(it618_mall_getlang('s425').$ok1, dreferer(), array(), array('alert' => 'right'));
	
	}
	
	if(submitcheck('it618submit_km_dao')){
		$ok1=0;
		$tmparr=explode("source/plugin/it618_scoremall/kindeditor",$_GET['it618_name_dao']);
		$file_path='source/plugin/it618_scoremall/kindeditor'.$tmparr[1];
		
		if (!file_exists($file_path)) {
			showmessage(it618_mall_getlang('s426'), '', array(), array('alert' => 'error'));
		}
		
		$lines = dfsockopen($_G['siteurl'].$file_path);
		ini_set('memory_limit', '-1');
		$lines=str_replace(array("\r\n", "\r", "\n"), '@||@', $lines);
		$line=explode("@||@",$lines);
		$ok1=0;
	
		foreach($line as $key =>$li)
		{
			if(trim($li)!=''){
				C::t('#it618_scoremall#it618_scoremall_goods_km')->insert(array(
					'it618_pid' => intval($_GET['pid']),
					'it618_code' => trim($li)
				), true);
				$ok1=$ok1+1;
			}
		}
		@unlink($file_path);
		$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".intval($_GET['pid']));
		DB::query("update ".DB::table('it618_scoremall_goods')." set it618_count=".$kmcount." where id=".intval($_GET['pid']));
		
		showmessage(it618_mall_getlang('s427').$ok1, dreferer(), array(), array('alert' => 'right'));
	}
	
	if(submitcheck('it618submit_km_clear')){
		DB::query("delete from ".DB::table('it618_scoremall_goods_km')." where it618_pid=".intval($_GET['pid']));
		DB::query("update ".DB::table('it618_scoremall_goods')." set it618_count=0 where id=".intval($_GET['pid']));
		
		showmessage(it618_mall_getlang('s428').$ok, dreferer(), array(), array('alert' => 'right'));
	}

	if(isset($_GET['ac']) && $_GET['ac']=='edit'){
		$edit=2;
		$pid=intval($_GET['pid']);
		$it618_scoremall_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE id=".$pid);

		if($it618_scoremall_goods['it618_uid']!=$_G['uid']){
			showmessage(it618_mall_getlang('s661'), '', array(), array('alert' => 'error'));
		}
		
		if($it618_scoremall_goods['it618_state']==0){
			showmessage(it618_mall_getlang('s242'), '', array(), array('alert' => 'info'));
		}
		if($li1il11[0]!='i')return;
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class1')." ORDER BY it618_order DESC");
		while($it618_tmp =	DB::fetch($query1)) {
			$class2count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_class2')." WHERE it618_class1_id=".$it618_tmp['id']);
			if($class2count>0){
				$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
			}
		}
		if($li1il11[4]!='8')return;
		$class2id = DB::result_first("select it618_class2_id from ".DB::table('it618_scoremall_class3')." where id=".$it618_scoremall_goods['it618_class3_id']);
		$class1id = DB::result_first("select it618_class1_id from ".DB::table('it618_scoremall_class2')." where id=".$class2id);
		$tmp1=str_replace('<option value='.$class1id.'>','<option value='.$class1id.' selected="selected">',$tmp);
		if(count($li1il11)!=15)return;
		
		$it618_ischeck=DB::result_first("SELECT it618_ischeck FROM ".DB::table('it618_scoremall_goods')." WHERE id=".$pid);
		if($it618_ischeck==1){
			$ischeck='<font color=red>'.it618_mall_getlang('s109').'</font>';
		}else{
			$ischeck=it618_mall_getlang('s109');
		}
		
		$tmpstr3edit='<tr>
                    <td width=60>'.it618_mall_getlang('s97').'</td><td><select id="it618_class1_id" name="it618_class1_id" onchange="redirec_class2(this.options.selectedIndex);redirec_class3(this.options[this.options.selectedIndex].value);"><option value="0">'.it618_mall_getlang('s98').'</option>'.$tmp1.'</select><select id="it618_class2_id" name="it618_class2_id" onchange="redirec_class3(this.options[this.options.selectedIndex].value)"><option value="0" id="0">'.it618_mall_getlang('s99').'</option></select><select id="it618_class3_id" name="it618_class3_id"><option value="0">'.it618_mall_getlang('s100').'</option></select></td>
                    </tr>
                    <tr>
                    <td>'.it618_mall_getlang('s101').'</td><td><input type="text" class="txt" style="width:400px" id="it618_name" name="it618_name" value="'.$it618_scoremall_goods['it618_name'].'"></td>
                    </tr>
                    <tr><td>'.$it618_mall_lang['s104'].'</td><td><img id="img1" src="'.$it618_scoremall_goods['it618_picbig'].'" width="80" height="80" align="absmiddle"/><input type="text" id="url1" name="it618_picbig" readonly="readonly" value="'.$it618_scoremall_goods['it618_picbig'].'"/> <input type="button" id="image1" value="'.$it618_mall_lang['s105'].'" />  '.$it618_mall_lang['s106'].'</td></tr>
<tr><td></td><td><img id="img11" src="'.$it618_scoremall_goods['it618_picbig1'].'" width="80" height="80" align="absmiddle"/><input type="text" id="url11" name="it618_picbig1" readonly="readonly" value="'.$it618_scoremall_goods['it618_picbig1'].'"/> <input type="button" id="image11" value="'.$it618_mall_lang['s105'].'" /> <input type="button" value="'.$it618_mall_lang['s107'].'" onclick="delpic(1)" /> <img id="img12" src="'.$it618_scoremall_goods['it618_picbig2'].'" width="80" height="80" align="absmiddle"/><input type="text" id="url12" name="it618_picbig2" readonly="readonly" value="'.$it618_scoremall_goods['it618_picbig2'].'"/> <input type="button" id="image12" value="'.$it618_mall_lang['s105'].'" /> <input type="button" value="'.$it618_mall_lang['s107'].'" onclick="delpic(2)" /></td></tr>
<tr><td></td><td><img id="img13" src="'.$it618_scoremall_goods['it618_picbig3'].'" width="80" height="80" align="absmiddle"/><input type="text" id="url13" name="it618_picbig3" readonly="readonly" value="'.$it618_scoremall_goods['it618_picbig3'].'"/> <input type="button" id="image13" value="'.$it618_mall_lang['s105'].'" /> <input type="button" value="'.$it618_mall_lang['s107'].'" onclick="delpic(3)" />  <img id="img14" src="'.$it618_scoremall_goods['it618_picbig4'].'" width="80" height="80" align="absmiddle"/><input type="text" id="url14" name="it618_picbig4" readonly="readonly" value="'.$it618_scoremall_goods['it618_picbig4'].'"/> <input type="button" id="image14" value="'.$it618_mall_lang['s105'].'" /> <input type="button" value="'.$it618_mall_lang['s107'].'" onclick="delpic(4)" /></td></tr>
                    <tr>
                    <td>'.$ischeck.'</td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;">'.$it618_scoremall_goods['it618_message'].'</textarea>'.it618_mall_getlang('s523').'</td>
                    </tr>';
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class2')." where it618_class1_id=".$class1id." ORDER BY it618_order DESC");
		$indextmp=1;
		$index=0;
		while($it618_tmp =	DB::fetch($query)) {
			if($it618_tmp['id']==$class2id){
				$index=$indextmp;
			}
			$indextmp+=1;
			if($li1il11[14]!='l')return;
		}
		$jstmp.="redirec_class_sel('it618_class2_id',".$index.");";
		if(count($li1il11)!=15)return;
		$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." where it618_class2_id=".$class2id." ORDER BY it618_order DESC");
		$indextmp=1;
		$index=0;
		while($it618_tmp =	DB::fetch($query)) {
			if($it618_tmp['id']==$it618_scoremall_goods['it618_class3_id']){
				$index=$indextmp;
			}
			$indextmp+=1;
		}
		$jstmp.="redirec_class3(document.getElementById('it618_class2_id').options[document.getElementById('it618_class2_id').options.selectedIndex].value);redirec_class_sel('it618_class3_id',".$index.");";
		
		$count2 = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_class2'));
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class1')." ORDER BY it618_order DESC");
		$n1=1;
		while($it618_tmp1 =	DB::fetch($query1)) {
			$class2count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_class2')." WHERE it618_class1_id=".$it618_tmp1['id']);
			if($class2count>0){
					$n2=1;
					$query2 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order DESC");
					while($it618_tmp2 =	DB::fetch($query2)) {
						$tmp2.='select_class2['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
						$n2=$n2+1;
						if($li1il11[4]!='8')return;
					}
					$n1=$n1+1;
			}
		}
		if(count($li1il11)!=15)return;
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class2')." ORDER BY it618_order desc");
		$n1=1;
		$n3=1;
		while($it618_tmp1 =	DB::fetch($query1)) {
			$query2 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." where it618_class2_id=".$it618_tmp1['id']." ORDER BY it618_order DESC");
			while($it618_tmp2 =	DB::fetch($query2)) {
				$tmp3.='select_class3['.$n3.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp1['id'].'_'.$it618_tmp2['id'].'");';
				$n3=$n3+1;
				if($li1il11[4]!='8')return;
			}
			$n1=$n1+1;
		}
		
		$tmpstr3_edit= '
		<script>
		var shopuid='.$shopuid.';
		KindEditor.ready(function(K) {
			var editor1 = K.create(\'textarea[name="it618_message"]\', {
				cssPath : \'source/plugin/it618_scoremall/kindeditor/plugins/code/prettify.css\',
				uploadJson : \'source/plugin/it618_scoremall/kindeditor/php/upload_json.php?uid='.$_G[uid].'&imgwidth=910'.$oss.'\',
				fileManagerJson : \'source/plugin/it618_scoremall/kindeditor/php/file_manager_json.php?uid='.$_G[uid].'\',
				allowFileManager : true,
				filterMode:false
			});
			
			K(\'#image1\').click(function() {
				editor1.loadPlugin(\'image\', function() {
					editor1.plugin.imageDialog({
						imageUrl : K(\'#url1\').val(),
						clickFn : function(url, title, width, height, border, align) {
							K(\'#url1\').val(url);
							K(\'#img1\').attr(\'src\',url);
							editor1.hideDialog();
						}
					});
				});
			});
			
			K(\'#image11\').click(function() {
				editor1.loadPlugin(\'image\', function() {
					editor1.plugin.imageDialog({
						imageUrl : K(\'#url11\').val(),
						clickFn : function(url, title, width, height, border, align) {
							K(\'#url11\').val(url);
							K(\'#img11\').attr(\'src\',url);
							editor1.hideDialog();
						}
					});
				});
			});
			
			K(\'#image12\').click(function() {
				editor1.loadPlugin(\'image\', function() {
					editor1.plugin.imageDialog({
						imageUrl : K(\'#url12\').val(),
						clickFn : function(url, title, width, height, border, align) {
							K(\'#url12\').val(url);
							K(\'#img12\').attr(\'src\',url);
							editor1.hideDialog();
						}
					});
				});
			});
			
			K(\'#image13\').click(function() {
				editor1.loadPlugin(\'image\', function() {
					editor1.plugin.imageDialog({
						imageUrl : K(\'#url13\').val(),
						clickFn : function(url, title, width, height, border, align) {
							K(\'#url13\').val(url);
							K(\'#img13\').attr(\'src\',url);
							editor1.hideDialog();
						}
					});
				});
			});
			
			K(\'#image14\').click(function() {
				editor1.loadPlugin(\'image\', function() {
					editor1.plugin.imageDialog({
						imageUrl : K(\'#url14\').val(),
						clickFn : function(url, title, width, height, border, align) {
							K(\'#url14\').val(url);
							K(\'#img14\').attr(\'src\',url);
							editor1.hideDialog();
						}
					});
				});
			});
			
		});
		
		var arrcount='.$count2.';
		var select_class2 = new Array(arrcount+1);
		
		for (i=0; i<arrcount+1; i++) 
		{
		 select_class2[i] = new Array();
		}
		
		'.$tmp2.'
		
		function redirec_class2(x)
		{
		 var temp = document.getElementById("it618_class2_id"); 
		 temp.options.length=1;
		 for (i=1;i<select_class2[x].length;i++)
		 {
		  temp.options[i]=new Option(select_class2[x][i].text,select_class2[x][i].value);
		 }
		 temp.options[0].selected=true;
		 
		}
		
		redirec_class2(document.getElementById("it618_class1_id").options.selectedIndex);
		
		var arrcount='.$n3.';
		var select_class3 = new Array(arrcount);
		
		'.$tmp3.'
		
		function redirec_class3(x)
		{
		 var temp = document.getElementById("it618_class3_id"); 
		 temp.options.length=1;
		 n=1;
		 for (i=1;i<select_class3.length;i++)
		 {
			 var tmparr=select_class3[i].value.split("_");
			 if(tmparr[0]==x){
				 temp.options[n]=new Option(select_class3[i].text,tmparr[1]);
				 n=n+1;
			 }
		 }
		 temp.options[0].selected=true;
		
		}
		
		function redirec_class_sel(id,index)
		{
		 var temp = document.getElementById(id); 
		 temp.options[index].selected=true;
		
		}
		
		'.$jstmp.'
		</script>';
	}elseif(isset($_GET['ac']) && $_GET['ac']=='km'){
		$edit=3;
		$pid=intval($_GET['pid']);
		$it618_scoremall_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE id=".$pid);
		
		if($li1il11[0]!='i')return;
		$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('it618_scoremall_goods_km')." w WHERE it618_pid=".$pid);
		$hrefsql=it618_scoremall_getrewrite('store','ac@km@3@'.$pid.'@it618page','plugin.php?id=it618_scoremall:scoremall_store&cid=3&ac=km&pid='.$pid);
		$multipage = multi($count, $ppp, $page, $_G['siteurl'].$hrefsql);
		$multipage = it618_scoremall_multipage($multipage,'');
		$tmpstr3km.='<tr><td>'.it618_mall_getlang('s438').'<font color=red>'.$it618_scoremall_goods['it618_name'].'</font> '.it618_mall_getlang('s430').$count.'</td></tr>';
	
		$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".$pid." LIMIT ".$startlimit.",".$ppp);
		$n=1;
		while($it618_scoremall_goods_km = DB::fetch($query)) {
			if(count($li1il11)!=15)return;
			$tmpstr3km.='<tr class="hover"><td><input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_scoremall_goods_km[id].'">
				<input type="text" class="txt" style="width:400px" name="it618_code['.$it618_scoremall_goods_km[id].']" value="'.dhtmlspecialchars($it618_scoremall_goods_km[it618_code]).'"></td></tr>';
			$n=$n+1;
		}
		if($count>0)$tmpstr3km.='<tr>
					<td>
					<div class="fixsel" style="float:left"><input type="checkbox" id="chk_del" class="checkbox" onclick="check_all(this, \'chk_del\','.$n.')" /><label for="chk_del">'.it618_mall_getlang('s235').'</label> <input type="submit" class="btn" name="it618submit_km" value="'.it618_mall_getlang('s236').'" /> <input type="submit" class="btn" name="it618submit_km_clear" value="'.it618_mall_getlang('s431').'" onclick="return confirm(\''.it618_mall_getlang('s432').'\')" /> <input type="botton" class="btn" value="'.it618_mall_getlang('s439').'" style="width:70px" onclick="location.href=\'plugin.php?id=it618_scoremall:scoremall_store&cid=3&page='.$_GET['page'].'\'"/><input type=hidden value=$page name=page /></div><div style="float:right">'.$multipage.'</div></td>
					</tr>';
					
		$tmpstr3km.='<tr><td colspan=2>'.it618_mall_getlang('s433').'<br><textarea name="it618_name_adds" style="width:400px;height:200px;margin-top:2px;"></textarea><br><input type="submit" class="btn" name="it618submit_km_adds" style="margin-top:3px" value="'.it618_mall_getlang('s435').'"/></td></tr>
		  <tr><td colspan=2>'.it618_mall_getlang('s434').'<br><input id="it618_name_dao" name="it618_name_dao" class="txt" style="width:310px;margin-right:3px"><input type="submit" id="btn_upfile" value="'.it618_mall_getlang('s436').'"/><br><input type="submit" class="btn" name="it618submit_km_dao" style="margin-top:3px" value="'.it618_mall_getlang('s437').'"/></td></tr>';
	}else{
		$edit=1;
		$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('it618_scoremall_goods')." w WHERE it618_uid=".$_G['uid'].$extrasql);
		if($_G['cache']['plugin']['it618_scoremall']['rewriteurl']==0){
			$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_scoremall:scoremall_store&cid=3".$uri);
		}else{
			$hrefsql=it618_scoremall_getrewrite('store','ac@find@3@0@it618page','plugin.php?id=it618_scoremall:scoremall_store&cid=3');
			$multipage = multi($count, $ppp, $page, $_G['siteurl'].$hrefsql);
			$multipage = it618_scoremall_multipage($multipage,$uri);
		}
		
		$it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." where it618_uid=".$_G['uid']);
		if($it618_scoremall_store['it618_ptaobao']!=1){
			$it618_ptaobao='display:none';
		}
		
		$tmpstr3.='<tr>
					<td colspan="20"><div class="fixsel">'.it618_mall_getlang('s117').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.it618_mall_getlang('s213').'<select name="chkstate"><option value=0 '.$chkstate0.'>'.it618_mall_getlang('s214').'</option><option value=1 '.$chkstate1.'>'.it618_mall_getlang('s215').'</option><option value=2 '.$chkstate2.'>'.it618_mall_getlang('s216').'</option><option value=3 '.$chkstate3.'>'.it618_mall_getlang('s217').'</option></select> '.it618_mall_getlang('s118').' <select name="state"><option value=0 '.$state0.'>'.it618_mall_getlang('s119').'</option><option value=1 '.$state1.'>'.it618_getbuyname(it618_mall_getlang('s218')).'</option><option value=2 '.$state2.'>'.it618_getbuyname(it618_mall_getlang('s219')).'</option><option value=3 '.$state3.'>'.it618_mall_getlang('s120').'</option><option value=4 '.$state4.'>'.it618_mall_getlang('s121').'</option><option value=5 '.$state5.'>'.it618_mall_getlang('s122').'</option><option value=6 '.$state6.'>'.it618_mall_getlang('s123').'</option><option value=7 '.$state7.'>'.it618_mall_getlang('s536').'</option><option value=8 '.$state8.'>'.it618_mall_getlang('s537').'</option><option value=9 '.$state9.'>'.it618_mall_getlang('s662').'</option><option value=10 '.$state10.'>'.it618_mall_getlang('s663').'</option><option value=11 '.$state11.'>'.it618_mall_getlang('s708').'</option><option value=12 '.$state12.'>'.it618_mall_getlang('s690').'</option><option value=13 '.$state13.'>'.it618_mall_getlang('s691').'</option></select> '.it618_mall_getlang('s126').' <select name="orderby"><option value=0 '.$orderby0.'>'.it618_mall_getlang('s127').'</option><option value=1 '.$orderby1.'>'.it618_mall_getlang('s128').'</option><option value=2 '.$orderby2.'>'.it618_mall_getlang('s129').'</option><option value=3 '.$orderby3.'>'.it618_mall_getlang('s130').'</option><option value=4 '.$orderby4.'>'.it618_mall_getlang('s131').'</option></select> &nbsp;<input type="submit" class="btn" name="it618submit_product_find" value="'.it618_mall_getlang('s116').'" /></div></td></tr><tr><td colspan=20>'.it618_mall_getlang('s132').$count.' <span style="float:right">'.it618_mall_getlang('s232').'</span>
					</td>
					</tr>
					</tr>
					<tr class="header"><th></th><th style="text-align:left">'.it618_mall_getlang('s135').'/'.it618_mall_getlang('s664').'</th><th style="text-align:left">'.it618_mall_getlang('s136').'</th><th style="text-align:left">'.$it618_mall_lang['s137'].'/'.it618_mall_getlang('s221').'</th><th style="text-align:left">'.it618_mall_getlang('s768').'/'.it618_mall_getlang('s707').'</th><th>'.it618_mall_getlang('s224').'</th><th>'.it618_mall_getlang('s225').'</th><th>'.it618_mall_getlang('s141').'</th><th>'.it618_mall_getlang('s542').'</th><th style="'.$it618_ptaobao.'">'.it618_mall_getlang('s665').'</th>
					</tr>';
		
		$groupupscore=DB::result_first("SELECT it618_score FROM ".DB::table('it618_scoremall_store_groupup')." where it618_uid=".$_G['uid']);
		$it618_scoremall_store_level=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store_level')." where it618_score1<=".$groupupscore." and it618_score2>=".$groupupscore);
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''){
				$jfidstr.='<option value="'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].'</option>';
			}
		}
		
		$jfidstr1='<option value="0">'.$it618_mall_lang['s997'].'</option>'.$jfidstr;
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_uid=".$_G['uid'].$extrasql." LIMIT ".$startlimit.",".$ppp);
		$n=1;
		while($it618_scoremall_goods = DB::fetch($query)) {
			if(count($li1il11)!=15)return;
			if($it618_scoremall_goods['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
			if($it618_scoremall_goods['it618_saletype']==1)$it618_saletype_checked='checked="checked"';else $it618_saletype_checked="";
			if($it618_scoremall_goods['it618_isaddr']==1)$it618_isaddr_checked='checked="checked"';else $it618_isaddr_checked="";
			if($it618_scoremall_goods['it618_isbm']==1)$it618_isbm_checked='checked="checked"';else $it618_isbm_checked="";
			if($it618_scoremall_goods['it618_isorder']==1)$it618_isorder_checked='checked="checked"';else $it618_isorder_checked="";
			if($it618_scoremall_goods['it618_istaobao']==1)$it618_istaobao_checked='checked="checked"';else $it618_istaobao_checked="";
			$isquan0='';$isquan1='';$isquan2='';
			if($it618_scoremall_goods['it618_isquan']==0)$isquan0='selected="selected"';
			if($it618_scoremall_goods['it618_isquan']==1)$isquan1='selected="selected"';
			if($it618_scoremall_goods['it618_isquan']==2)$isquan2='selected="selected"';
			if($li1il11[4]!='8')return;
			if($it618_scoremall_goods['it618_state']==0)$it618_state='<font color=red>'.it618_mall_getlang('s215').'</font>';
			if($it618_scoremall_goods['it618_state']==1)$it618_state='<font color=blue>'.it618_mall_getlang('s216').'</font>';
			if($it618_scoremall_goods['it618_state']==2)$it618_state='<font color=green>'.it618_mall_getlang('s217').'</font>';
			
			if($it618_scoremall_goods['it618_xgtype']==0)$it618_xgtype0=' selected="selected"';else $it618_xgtype0="";
			if($it618_scoremall_goods['it618_xgtype']==1)$it618_xgtype1=' selected="selected"';else $it618_xgtype1="";
			if($it618_scoremall_goods['it618_xgtype']==2)$it618_xgtype2=' selected="selected"';else $it618_xgtype2="";
			
			if($it618_scoremall_goods['it618_state']==0){
				$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
				$stredit='<a href="'.$tmpurl.'" target="_blank">'.it618_mall_getlang('s233').'</a>';
			}else{
				$tmpurl=it618_scoremall_getrewrite('store','ac@edit@3@'.$it618_scoremall_goods[id].'@'.$page,'plugin.php?id=it618_scoremall:scoremall_store&cid=3&ac=edit&pid='.$it618_scoremall_goods[id].'&page='.$page);
				$stredit='<a href="'.$tmpurl.'">'.it618_mall_getlang('s144').'</a>';
			}
			$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".$it618_scoremall_goods['id']);
			$tmpurl=it618_scoremall_getrewrite('store','ac@km@3@'.$it618_scoremall_goods[id].'@'.$page,'plugin.php?id=it618_scoremall:scoremall_store&cid=3&ac=km&pid='.$it618_scoremall_goods[id].'&page='.$page);
			if($kmcount>0){
				$it618_count='<input type="hidden" name="it618_count['.$it618_scoremall_goods[id].']" value="-1"><a href="'.$tmpurl.'"><font color=blue>'.it618_mall_getlang('s440').'(<font color=red>'.$it618_scoremall_goods[it618_count].'</font>)</font></a>';
				$it618_isaddr_checked="";
			}else{
				$it618_count='<input type="text" class="txt" style="width:50px;margin-bottom:3px;color:green" name="it618_count['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[it618_count].'"><a href="'.$tmpurl.'">'.it618_mall_getlang('s440').'</a>';
			}
			if($li1il11[14]!='l')return;
			$salecount = DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_scoremall_sale')." WHERE it618_state <>5 and it618_pid=".$it618_scoremall_goods['id']);
			if($salecount=='')$salecount=0;
			if($salecount>0)$disabled='disabled="disabled"';else $disabled='';
			$username='<a href="'.it618_scoremall_rewriteurl($it618_scoremall_goods['it618_uid']).'" target="_blank">'.it618_scoremall_getusername($it618_scoremall_goods[it618_uid]).'</a>';
			$editstr=it618_scoremall_getrewrite('store','ac@edit@3@'.$it618_scoremall_goods[id].'@'.$page,'plugin.php?id=it618_scoremall:scoremall_store&cid=3&ac=edit&pid='.$it618_scoremall_goods[id].'&page='.$page);
			$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
			
			if($it618_scoremall_goods[it618_tc]>0){
				$it618_tcstr=' '.$it618_mall_lang['s960'].'<font color=red>'.$it618_scoremall_goods[it618_tc].'</font>%';
			}else{
				$it618_tcstr=' '.$it618_mall_lang['s960'].'<font color=red>'.$it618_scoremall_store_level['it618_tc'].'</font>%';
			}
			
			$jfidstr=str_replace('value="'.$it618_scoremall_goods['it618_jfid'].'"','value="'.$it618_scoremall_goods['it618_jfid'].'" selected="selected"',$jfidstr);
			$jfidstr1=str_replace('value="'.$it618_scoremall_goods['it618_jfid1'].'"','value="'.$it618_scoremall_goods['it618_jfid1'].'" selected="selected"',$jfidstr1);
			
			$tmpstr3.='<tr class="hover align"><td class="td25"><input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_scoremall_goods[id].'" '.$disabled.'><label for="chk_del'.$n.'">'.$it618_scoremall_goods['id'].'</label></td>
				<td align="left"><div style="width:350px"><a style="float:left" href="'.$tmpurl.'" target="_blank" title="'.$it618_mall_lang['s134'].$it618_mall_lang['s670'].it618_scoremall_class1name($it618_scoremall_goods['it618_class3_id']).' '.it618_scoremall_class2name($it618_scoremall_goods['it618_class3_id']).' '.it618_scoremall_class3name($it618_scoremall_goods['it618_class3_id']).'"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'" width="80" height="80" style="margin-right:3px"/></a><input type="text" class="txt" style="width:230px;margin-right:3px" name="it618_name['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[it618_name].'"><a href="'.$editstr.'">'.$it618_mall_lang['s144'].'</a><br><input type="text" class="txt" style="width:230px;margin-right:1px;margin-top:3px;margin-bottom:3px;'.$it618_ptaobao.'" name="it618_taobaourl['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[it618_taobaourl].'"><br>'.$it618_mall_lang['s334'].$it618_state.$it618_tcstr.'</div></td>
				<td align="left"><input type="text" class="txt" style="width:50px;margin-right:1px;height:18px;color:red" name="it618_score['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[it618_score].'"><select name="it618_jfid['.$it618_scoremall_goods[id].']">'.$jfidstr.'</select><br><input type="text" class="txt" style="width:50px;margin-right:1px;height:18px;color:red;margin-top:3px" name="it618_score1['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[it618_score1].'"><select name="it618_jfid1['.$it618_scoremall_goods[id].']" style="margin-top:1px">'.$jfidstr1.'</select><br>'.$it618_mall_lang['s692'].' : <font color=red>'.$salecount.'</font></td>
				<td align="left">'.$it618_count.'<br><input type="text" class="txt" style="width:35px" name="it618_xiangoutime['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[it618_xiangoutime].'">/<input type="text" class="txt" style="width:35px" name="it618_xiangoucount['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[it618_xiangoucount].'"><br>'.$it618_mall_lang['s139'].' : '.$it618_scoremall_goods[it618_views].'</td>
				<td align="left"><select id="it618_xgtype'.$n.'" name="it618_xgtype['.$it618_scoremall_goods[id].']"><option value="0"'.$it618_xgtype0.'>'.$it618_mall_lang['s769'].'</option><option value="1"'.$it618_xgtype1.'>'.$it618_mall_lang['s770'].'</option><option value="2"'.$it618_xgtype2.'>'.$it618_mall_lang['s771'].'</option></select><select name="it618_isquan['.$it618_scoremall_goods['id'].']"><option value="0" '.$isquan0.'>'.it618_mall_getlang('s709').'</option><option value="1" '.$isquan1.'>'.it618_mall_getlang('s710').'</option><option value="2" '.$isquan2.'>'.it618_mall_getlang('s693').'</option></select><br><input type="text" class="txt" style="width:123px;margin-top:3px" id="it618_xgtime1_'.$n.'" name="it618_xgtime1['.$it618_scoremall_goods['id'].']" readonly="readonly" value="'.$it618_scoremall_goods['it618_xgtime1'].'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')"><br><input type="text" class="txt" style="width:123px;margin-top:3px" id="it618_xgtime2_'.$n.'" name="it618_xgtime2['.$it618_scoremall_goods['id'].']" readonly="readonly" value="'.$it618_scoremall_goods['it618_xgtime2'].'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')"></td>
				<td><input class="checkbox" type="checkbox" id="chk_isbm'.$n.'" name="it618_isbm['.$it618_scoremall_goods['id'].']" '.$it618_isbm_checked.' value="1"></td>
				<td><input class="checkbox" type="checkbox" id="chk_addr'.$n.'" name="it618_isaddr['.$it618_scoremall_goods['id'].']" '.$it618_isaddr_checked.' value="1"></td>
				<td><input class="checkbox" type="checkbox" id="chk_ison'.$n.'" name="it618_ison['.$it618_scoremall_goods['id'].']" '.$it618_ison_checked.' value="1"></td>
				<td><input class="checkbox" type="checkbox" id="chk_isorder'.$n.'" name="it618_isorder['.$it618_scoremall_goods['id'].']" '.$it618_isorder_checked.' value="1"></td>
				<td style="'.$it618_ptaobao.'"><input class="checkbox" type="checkbox" id="chk_istaobao'.$n.'" name="it618_istaobao['.$it618_scoremall_goods['id'].']" '.$it618_istaobao_checked.' value="1"></td>';
			$n=$n+1;
		}
		if($count>0)$tmpstr3.='<tr>
					<td class="td25"><input type="checkbox" id="chk_del" class="checkbox" onclick="check_all(this, \'chk_del\','.$n.')" /><label for="chk_del">'.it618_mall_getlang('s235').'</label></td>
					<td colspan="20"><div class="fixsel" style="float:left"><input type="submit" class="btn" name="it618submit_product_del" value="'.it618_mall_getlang('s488').'" onclick="return confirm(\''.it618_mall_getlang('s489').'\')" /> <input type="submit" class="btn" name="it618submit_product_edits" value="'.it618_mall_getlang('s490').'" onclick="return checkvalue()"/> <input type="checkbox" id="chk_isbm" class="checkbox" onclick="check_all(this, \'chk_isbm\','.$n.')" /><label for="chk_isbm"> '.it618_getbuyname(it618_mall_getlang('s218')).'</label> <input type="checkbox" id="chk_addr" class="checkbox" onclick="check_all(this, \'chk_addr\','.$n.')" /><label for="chk_addr"> '.it618_mall_getlang('s231').'</label> <input type="checkbox" id="chk_ison" class="checkbox" onclick="check_all(this, \'chk_ison\','.$n.')" /><label for="chk_ison"> '.it618_mall_getlang('s141').'</label> <input type="checkbox" id="chk_isorder" class="checkbox" onclick="check_all(this, \'chk_isorder\','.$n.')" /><label for="chk_isorder"> '.it618_mall_getlang('s542').'</label> <input type="checkbox" id="chk_istaobao" class="checkbox" onclick="check_all(this, \'chk_istaobao\','.$n.')" /><label for="chk_istaobao"> '.it618_mall_getlang('s665').'</label> <input type="checkbox" id="chk_isquan" class="checkbox" onclick="check_all(this, \'chk_isquan\','.$n.')" /><label for="chk_isquan"> '.it618_mall_getlang('s707').'</label><br>'.it618_mall_getlang('s961').'<input type=hidden value=$page name=page /></div><div style="float:right">'.$multipage.'</div></td>
					</tr><script charset="utf-8" src="source/plugin/it618_scoremall/js/Calendar.js"></script>
<script type="text/javascript">
		function check_all(obj,id)
		{
			for(var i=1;i<'.$n.';i++)
			{
				document.getElementById(id+""+i).checked = obj.checked;
			}
		}
		
		function checkvalue(){
			for(var i=1;i<'.$n.';i++){
				var chk_del = document.getElementById("chk_del"+i).value;
				var it618_xgtype = document.getElementById("it618_xgtype"+i).value;
				var it618_xgtime1 = document.getElementById("it618_xgtime1_"+i).value;
				var it618_xgtime2 = document.getElementById("it618_xgtime2_"+i).value;
				
				var tmparr1=it618_xgtime1.split(" ");
				var tmparr2=it618_xgtime2.split(" ");
				
				if(it618_xgtype>0){
					if(it618_xgtime1==""){
						alert("'.it618_mall_getlang('s949').'"+chk_del+") '.it618_mall_getlang('s950').'");
						document.getElementById("it618_xgtime1_"+i).focus();
						return false;
					}
					if(it618_xgtime2==""){
						alert("'.it618_mall_getlang('s949').'"+chk_del+") '.it618_mall_getlang('s951').'");
						document.getElementById("it618_xgtime2_"+i).focus();
						return false;
					}
					if(parseInt(tmparr2[0].replace(/-/g,""))<parseInt(tmparr1[0].replace(/-/g,""))){
						alert("'.it618_mall_getlang('s949').'"+chk_del+")'.it618_mall_getlang('s947').'");
						document.getElementById("it618_xgtime1_"+i).focus();
						return false;
					}
					
					var flag=0;
					if(it618_xgtype==2){
						flag=1;
					}else{
						if(parseInt(tmparr2[0].replace(/-/g,""))==parseInt(tmparr1[0].replace(/-/g,""))){
							flag=1;
						}
					}
					if(flag==1&&parseInt(tmparr2[1].replace(":",""))<=parseInt(tmparr1[1].replace(":",""))){
						alert("'.it618_mall_getlang('s949').'"+chk_del+")'.it618_mall_getlang('s948').'");
						document.getElementById("it618_xgtime1_"+i).focus();
						return false;
					}
				}
			}
		}
	  </script>';
	}
}elseif($cid==4){
	if($li1il11[4]!='8')return;
	$it618_scoremall_store=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_uid=".$_G['uid']);
	if(count($li1il11)!=15)return;
	if(submitcheck('it618submit_store_edit')){

		C::t('#it618_scoremall#it618_scoremall_store')->update($it618_scoremall_store['id'],array(
			'it618_name' => dhtmlspecialchars($_GET['it618_name']),
			'it618_logo' => dhtmlspecialchars($_GET['it618_logo']),
			'it618_tel' => dhtmlspecialchars($_GET['it618_tel']),
			'it618_messagetel' => dhtmlspecialchars($_GET['it618_messagetel']),
			'it618_messageisok' => $_GET['it618_messageisok'],
			'it618_qq' => dhtmlspecialchars($_GET['it618_qq']),
			'it618_width' => intval($_GET['it618_width']),
			'it618_height' => intval($_GET['it618_height']),
			'it618_servertitle' => dhtmlspecialchars($_GET['it618_servertitle']),
			'it618_server' => $_GET['it618_server'],
			'it618_message' => $_GET['it618_message'],
			'it618_message_daishen' => $_GET['it618_message'],
		));
		if($li1il11[4]!='8')return;
		showmessage(it618_mall_getlang('s260'), dreferer(), array(), array('alert' => 'right'));
		
	}
	
	if($it618_scoremall_store['it618_messageisok']==1)$it618_messageisok_checked='checked="checked"';else $it618_messageisok_checked="";
	if($it618_scoremall_store['it618_logo']!='')$it618_logo='<img id="img1" src="'.$it618_scoremall_store['it618_logo'].'" width="200" height="75" align="absmiddle"/>';
	
	$tmpstr4='<tr>
               <td>'.it618_mall_getlang('s261').'</td><td><input type="text" class="txt" style="width:400px" name="it618_name" value="'.$it618_scoremall_store['it618_name'].'"></td>
               </tr>
			   <tr><td>'.it618_mall_getlang('s396').'</td><td>'.$it618_logo.' <input type="text" class="txt" id="url1" name="it618_logo" value="'.$it618_scoremall_store['it618_logo'].'" readonly="readonly" /> <input type="button" class="btn" id="image1" value="'.it618_mall_getlang('s397').'" />  '.it618_mall_getlang('s398').'</td></tr>
			   <tr>
               <td><font color=red>'.it618_mall_getlang('s715').'</font></td><td>'.it618_mall_getlang('s716').'<input type="text" class="txt" style="width:100px" name="it618_messagetel" value="'.$it618_scoremall_store['it618_messagetel'].'"> <input type="checkbox" id="it618_messageisok" name="it618_messageisok" value="1" style="vertical-align:middle" '.$it618_messageisok_checked.'> <label for="it618_messageisok">'.it618_mall_getlang('s719').'</label> '.it618_mall_getlang('s718').'</td>
               </tr>
			   <tr>
               <td>'.it618_mall_getlang('s262').'</td><td>'.it618_mall_getlang('s263').'<input type="text" class="txt" style="width:100px" name="it618_tel" value="'.$it618_scoremall_store['it618_tel'].'"> '.it618_mall_getlang('s264').'<input type="text" class="txt" style="width:100px" name="it618_qq" value="'.$it618_scoremall_store['it618_qq'].'"> '.it618_mall_getlang('s265').'</td>
               </tr>
               <tr>
               <td><font color=red>'.it618_mall_getlang('s266').'</font></td><td><div style="margin-bottom:5px">'.it618_mall_getlang('s267').'<input type="text" class="txt" style="width:200px" name="it618_servertitle" value="'.$it618_scoremall_store['it618_servertitle'].'"> '.it618_mall_getlang('s268').'<input type="text" class="txt" style="width:50px" name="it618_width" value="'.$it618_scoremall_store['it618_width'].'"> '.it618_mall_getlang('s269').'<input type="text" class="txt" style="width:50px" name="it618_height" value="'.$it618_scoremall_store['it618_height'].'"></div><textarea name="it618_server" style="width:700px;height:300px;visibility:hidden;">'.$it618_scoremall_store['it618_server'].'</textarea>'.it618_mall_getlang('s270').'</td>
               </tr>
               <td><font color=red>'.it618_mall_getlang('s271').'</font></td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;">'.$it618_scoremall_store['it618_message'].'</textarea>'.it618_mall_getlang('s272').'</td>
               </tr>';
	
}elseif($cid==5){
	$tmpstr5.='<tr class="header">
				<th width=150>'.it618_mall_getlang('s273').'</th><th width=50>'.it618_mall_getlang('s274').'</th><th width=100>'.it618_mall_getlang('s275').'</th><th width=100>'.it618_mall_getlang('s276').'</th><th>'.it618_mall_getlang('s277').'</th>
				</tr>';
				
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_store_groupuplog')." w WHERE it618_uid=".$_G['uid']);
	$hrefsql=it618_scoremall_getrewrite('store','0@0@5@0@it618page','plugin.php?id=it618_scoremall:scoremall_store&cid=5');
	$multipage = multi($count, $ppp, $page, $_G['siteurl'].$hrefsql);
	$multipage = it618_scoremall_multipage($multipage,'');
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_store_groupuplog')." where it618_uid=".$_G['uid']." order by id desc LIMIT ".$startlimit.",15");
	while($it618_scoremall_store_groupuplog = DB::fetch($query)) {
		if($li1il11[4]!='8')return;
		$tmpstr5.='<tr class="hover align">
			<td>'.date('Y-m-d H:i:s', $it618_scoremall_store_groupuplog['it618_time']).'</td>
			<td>'.$it618_scoremall_store_groupuplog['it618_saleid'].'</td>
			<td>'.$it618_scoremall_store_groupuplog['it618_score'].'</td>
			<td>'.$it618_scoremall_store_groupuplog['it618_curallscore'].'</td>
			<td align="left">'.$it618_scoremall_store_groupuplog['it618_bz'].'</td></tr>';
	}
	
	if($count>0)$tmpstr5.='<tr>
					<td colspan="15"><input type=hidden value=$page name=page /><div style="float:right">'.$multipage.'</div></td>
					</tr>';
}elseif($cid==6){
	$tmpstr6.='<tr class="header">
				<th>'.it618_mall_getlang('s278').'</th><th>'.it618_mall_getlang('s279').'</th><th>'.it618_mall_getlang('s280').'</th>
				</tr>';
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_store_level')." order by it618_level");
	while($it618_scoremall_store_level = DB::fetch($query)) {
		if($groupuplevel_store==$it618_scoremall_store_level['it618_level'])$curcss='curlevel'; else $curcss='';
		$tmpstr6.='<tr class="hover align '.$curcss.'">
			<td>'.$it618_scoremall_store_level['it618_level'].'</td>
			<td>'.$it618_scoremall_store_level['it618_score1'].'-'.$it618_scoremall_store_level['it618_score2'].'</td>
			<td>'.$it618_scoremall_store_level['it618_tc'].'%</td></tr>';
	}
}elseif($cid==7){
	if(submitcheck('it618submitadd')) {
		$it618_count=intval($_GET['it618_count']);
		$it618_storeid = DB::result_first("SELECT id FROM ".DB::table('it618_scoremall_store')." WHERE it618_uid=".$_G['uid']);
		if($_GET['chketime']==1){
			$it618_etime=explode(" ",$_GET['it618_etime']);
			$it618_date=explode("-",$it618_etime[0]);
			$it618_hour=explode(":",$it618_etime[1]);
			
			$it618_etime=mktime($it618_hour[0], $it618_hour[1], $it618_hour[2], $it618_date[1], $it618_date[2], $it618_date[0]);
			if($it618_etime<$_G['timestamp']){
				showmessage(it618_mall_getlang('s468'), '', array(), array('alert' => 'error'));
			}
		}else{
			$it618_etime=0;
		}
		$ok=0;
		$it618_addtime=$_G['timestamp'];
		for($i=0;$i<$it618_count;$i++){
			$id=C::t('#it618_scoremall#it618_scoremall_quan')->insert(array(
				'it618_storeid' => $it618_storeid,
				'it618_adduid' => $_G['uid'],
				'it618_type' => 1,
				'it618_jfid' => $_GET['it618_jfid'],
				'it618_score' => $_GET['it618_score'],
				'it618_bz' => dhtmlspecialchars($_GET['it618_bz']),
				'it618_etime' => $it618_etime,
				'it618_addtime' => $it618_addtime
			), true);
			$tmpstr=strtoupper(md5('0'.$_G['uid'].$id));
			C::t('#it618_scoremall#it618_scoremall_quan')->update($id,array(
				'it618_code' => substr($tmpstr, 0, 9).substr($tmpstr, 23, 32)
			));
			$ok=$ok+1;
		}
		showmessage(it618_mall_getlang('s469').$ok, dreferer(), array(), array('alert' => 'right'));
	}
	
	if(submitcheck('it618submitdel')){
		$del=0;

		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			DB::delete('it618_scoremall_quan', "id=$delid");
			$del=$del+1;
		}
	
		showmessage(it618_mall_getlang('s467').$del, dreferer(), array(), array('alert' => 'right'));
	}
	
	if(submitcheck('it618submit_data')){
		if(isset($_GET['it618_bzfind'])){
			$bzfind=$_GET['it618_bzfind'];
		}else{
			$bzfind='allquan';
		}
		
		if($bzfind!='allquan')$extrasql = " AND it618_bz LIKE '".addcslashes(addslashes($bzfind),'%_')."'";
		
		$it618_storeid = DB::result_first("SELECT id FROM ".DB::table('it618_scoremall_store')." WHERE  it618_uid=".$_G['uid']);

		$strtmp=it618_mall_getlang('s509').",".it618_mall_getlang('s482').",".it618_mall_getlang('s483').",".it618_mall_getlang('s686')."\n";
		$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_quan')." WHERE it618_usetime=0$extrasql and it618_storeid=".$it618_storeid." ORDER BY id DESC");
		while($it618_scoremall_quan = DB::fetch($query)) {
			if($it618_scoremall_quan['it618_etime']==0){
				$it618_etime=it618_mall_getlang('s485');
			}else{
				$it618_etime=date('Y-m-d H:i:s', $it618_scoremall_quan['it618_etime']);
			}
			
			$datacount=$datacount+1;
			$strtmp.=$it618_scoremall_quan['it618_code'].",".$it618_scoremall_quan['it618_score'].",".$it618_etime.",".$it618_scoremall_quan['it618_bz']."\n";
		
		}
	
		$timestr=date("YmdHis") . '_' . $datacount;
		$datapath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/temp/shop/shop'.$_G['uid'].'/';
		if (!file_exists($datapath)) {
			mkdir($datapath);
		}
		it618_scoremall_delfile($datapath);
		
		@$fp = fopen($datapath.$timestr.'.csv',"w");
		if(!$fp){
			echo "system error";
			exit();
		}else {
			fwrite($fp,$strtmp);
			fclose($fp);
		}
		
		showmessage($it618_mall_lang['s1060'].'<a href="javascript:" onclick="window.open(\''.$_G['siteurl'].'source/plugin/it618_scoremall/temp/shop/shop'.$_G['uid'].'/'.$timestr.'.csv\')"><font color=red>'.$it618_mall_lang['s1061'].'</font></a>', '', array(), array('alert' => 'right'));
	}
	
	if($_GET['ac']=='uselist'){
		$it618_storeid = DB::result_first("SELECT id FROM ".DB::table('it618_scoremall_store')." WHERE it618_uid=".$_G['uid']);
		$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('it618_scoremall_quan')." WHERE it618_usetime>0 and it618_storeid=".$it618_storeid);
		$ppp=20;
		$hrefsql=it618_scoremall_getrewrite('store','ac@uselist@7@0@it618page','plugin.php?id=it618_scoremall:scoremall_store&cid=7&ac=uselist');
		$multipage = multi($count, $ppp, $page, $_G['siteurl'].$hrefsql);
		$multipage = it618_scoremall_multipage($multipage,'');
		
		$tmpurl1=it618_scoremall_getrewrite('store','0@0@7@0@1','plugin.php?id=it618_scoremall:scoremall_store&cid=7');
		$tmpurl2=it618_scoremall_getrewrite('store','ac@uselist@7@0@1','plugin.php?id=it618_scoremall:scoremall_store&cid=7&ac=uselist');
		$tmpstr7.='<tr><td colspan="6"><a class="it618_menu" href="'.$tmpurl1.'">'.it618_mall_getlang('s505').'</a> <a  class="it618_menu it618_curmenu" href="'.$tmpurl2.'">'.it618_mall_getlang('s506').'</a></td></tr><tr><td colspan=6>'.it618_mall_getlang('s507').$count.' <span style="float:right"><font color=red>'.it618_mall_getlang('s508').'</font></span></td></tr></tr><tr class="header"><th>'.it618_mall_getlang('s509').'</th><th>'.it618_mall_getlang('s482').'</th><th>'.it618_mall_getlang('s483').'</th><th>'.it618_mall_getlang('s484').'</th><th>'.it618_mall_getlang('s510').'</th><th>'.it618_mall_getlang('s511').'</th></tr>';
	
		$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_quan')." WHERE it618_usetime>0 and it618_storeid=".$it618_storeid." ORDER BY id DESC LIMIT $startlimit, $ppp");
		$n=1;
		while($it618_scoremall_quan = DB::fetch($query)) {
			$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_scoremall_quan['it618_useuid']);
			if($it618_scoremall_quan['it618_etime']==0){
				$it618_etime=it618_mall_getlang('s485');
			}else{
				$it618_etime=date('Y-m-d H:i:s', $it618_scoremall_quan['it618_etime']);
			}
			$jfname=$_G['setting']['extcredits'][$it618_scoremall_quan['it618_jfid']]['title'];
			$tmpstr7.='<tr class="hover align"><td align="left"><input type="text" class="txt" style="width:300px;margin-left:3px" name="it618_code['.$it618_scoremall_quan[id].']" value="'.$it618_scoremall_quan[it618_code].'" onclick="this.select()"></td>
				<td><span style="color:#F60; font-weight:bold">'.$it618_scoremall_quan['it618_score'].'</span>'.$jfname.'</td>
				<td>'.$it618_etime.'</td>
				<td>'.date('Y-m-d H:i:s', $it618_scoremall_quan['it618_addtime']).'</td>
				<td>'.$username.'</td>
				<td>'.date('Y-m-d H:i:s', $it618_scoremall_quan['it618_usetime']).'</td>';
			$n=$n+1;
		}
		if($count>0)$tmpstr7.='<tr>
					<td colspan=5><input type=hidden value=$page name=page /></div><div style="float:right">'.$multipage.'</div></td>
					</tr>';	
	}else{
		if(isset($_GET['it618_bzfind'])){
			$bzfind=$_GET['it618_bzfind'];
		}else{
			$bzfind='allquan';
		}
		
		if($bzfind!='allquan')$extrasql = " AND it618_bz LIKE '".addcslashes(addslashes($bzfind),'%_')."'";
		
		$urlsql='?it618_bzfind='.$bzfind;
		
		//
		$strtmp="";
		for($i=2014;$i<=2020;$i++){
			if(date('Y')==$i){
				$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
			}else{
				$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
			}
		}
		$sel_year='<select id="sel_year" onclick="returnvalue()">'.$strtmp.'</select>';
		
		//
		$strtmp="";
		for($i=1;$i<=12;$i++){
			if(date('n')==$i){
				$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
			}else{
				$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
			}
		}
		$sel_month='<select id="sel_month" onclick="returnvalue()">'.$strtmp.'</select>';
		
		//
		$strtmp="";
		for($i=1;$i<=31;$i++){
			if(date('j')==$i){
				$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
			}else{
				$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
			}
		}
		$sel_date='<select id="sel_date" onclick="returnvalue()">'.$strtmp.'</select>';
		
		//
		$strtmp="";
		for($i=0;$i<=23;$i++){
			if(0==$i){
				$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
			}else{
				$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
			}
		}
		$sel_hour='<select id="sel_hour" onclick="returnvalue()">'.$strtmp.'</select>';
		
		//
		$strtmp="";
		for($i=0;$i<=59;$i++){
			if(0==$i){
				$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
			}else{
				$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
			}
		}
		$sel_minute='<select id="sel_minute" onclick="returnvalue()">'.$strtmp.'</select>';
		
		//
		$strtmp="";
		for($i=0;$i<=59;$i++){
			if(0==$i){
				$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
			}else{
				$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
			}
		}
		$sel_second='<select id="sel_second" onclick="returnvalue()">'.$strtmp.'</select>';
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''){
				$jfidstr.='<option value="'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].'</option>';
			}
		}
		
		$it618_storeid = DB::result_first("SELECT id FROM ".DB::table('it618_scoremall_store')." WHERE it618_uid=".$_G['uid']);
		DB::query("delete FROM ".DB::table('it618_scoremall_quan')." WHERE it618_etime<>0 and it618_etime<".$_G['timestamp']);
		$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('it618_scoremall_quan')." WHERE it618_usetime=0$extrasql and it618_storeid=".$it618_storeid);
		$ppp=20;
		$hrefsql=it618_scoremall_getrewrite('store','0@0@7@0@it618page','plugin.php?id=it618_scoremall:scoremall_store&cid=7');
		$multipage = multi($count, $ppp, $page, $_G['siteurl'].$hrefsql);
		$multipage = it618_scoremall_multipage($multipage,$urlsql);
		
		$it618_bzfind='<option value="allquan">'.it618_mall_getlang('s694').'</option>';
		$query = DB::query("SELECT count(1) as quancount,it618_bz FROM ".DB::table('it618_scoremall_quan')." WHERE it618_usetime=0 and it618_storeid=".$it618_storeid." group by it618_bz");
		while($it618_scoremall_quan = DB::fetch($query)) {
			$it618_bzfind.='<option value='.$it618_scoremall_quan['it618_bz'].'>'.$it618_scoremall_quan['it618_bz'].' ('.it618_mall_getlang('s695').$it618_scoremall_quan['quancount'].')</option>';
		}
		$it618_bzfind=str_replace('<option value='.$_GET['it618_bzfind'].'>','<option value='.$_GET['it618_bzfind'].' selected="selected">',$it618_bzfind);
		
		$tmpurl1=it618_scoremall_getrewrite('store','0@0@7@0@1','plugin.php?id=it618_scoremall:scoremall_store&cid=7');
		$tmpurl2=it618_scoremall_getrewrite('store','ac@uselist@7@0@1','plugin.php?id=it618_scoremall:scoremall_store&cid=7&ac=uselist');
		$tmpstr7.='<tr><td colspan="6"><a class="it618_menu it618_curmenu" href="'.$tmpurl1.'">'.it618_mall_getlang('s505').'</a> <a  class="it618_menu" href="'.$tmpurl2.'">'.it618_mall_getlang('s506').'</a></td></tr><tr><td colspan="6">'.$it618_mall_lang['s998'].'<select name="it618_jfid">'.$jfidstr.'</select> '.it618_mall_getlang('s475').'<input name="it618_count" value="" class="txt" style="width:50px" /> '.it618_mall_getlang('s476').'<input name="it618_score" value="" class="txt" style="width:50px" /> '.it618_mall_getlang('s477').'<input type="checkbox" id="chketime" name="chketime" style="vertical-align:middle" onclick="setetime(this)" value="1"/><input type="hidden" id="it618_etime" name="it618_etime"><span id="etime" style="display:none">'.$sel_year.$sel_month.$sel_date.$sel_hour.$sel_minute.$sel_second.'</span> '.it618_mall_getlang('s696').'<input name="it618_bz" value="" class="txt" style="width:200px" /> <input type="submit" class="btn" name="it618submitadd" value="'.it618_mall_getlang('s512').'" /> </td></tr><tr><td colspan="6">'.it618_mall_getlang('s697').' <select name="it618_bzfind">'.$it618_bzfind.'</select> <input type="submit" class="btn" name="it618submitfind" value="'.it618_mall_getlang('s43').'" /></tr><tr><td colspan=6>'.it618_mall_getlang('s513').$count.' <span style="float:right"><font color=red>'.it618_mall_getlang('s508').'</font></span></td></tr></tr><tr class="header"><th width=50></th><th>'.it618_mall_getlang('s509').'</th><th>'.it618_mall_getlang('s482').'</th><th>'.it618_mall_getlang('s483').'</th><th>'.it618_mall_getlang('s686').'</th><th>'.it618_mall_getlang('s484').'</th></tr>';
	
		$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_quan')." WHERE it618_usetime=0$extrasql and it618_storeid=".$it618_storeid." ORDER BY id DESC LIMIT $startlimit, $ppp");
		$n=1;
		while($it618_scoremall_quan = DB::fetch($query)) {
			if(count($li1il11)!=15)return;
			if($it618_scoremall_quan['it618_etime']==0){
				$it618_etime=it618_mall_getlang('s485');
			}else{
				$it618_etime=date('Y-m-d H:i:s', $it618_scoremall_quan['it618_etime']);
			}
			$jfname=$_G['setting']['extcredits'][$it618_scoremall_quan['it618_jfid']]['title'];
			$tmpstr7.='<tr class="hover align"><td width=50><input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_scoremall_quan[id].'"></td>
				<td align="left"><input type="text" class="txt" style="width:200px;margin-left:3px" name="it618_code['.$it618_scoremall_quan[id].']" value="'.$it618_scoremall_quan[it618_code].'" onclick="this.select()"></td>
				<td><span style="color:#F60; font-weight:bold">'.$it618_scoremall_quan['it618_score'].'</span>'.$jfname.'</td>
				<td>'.$it618_etime.'</td>
				<td>'.$it618_scoremall_quan['it618_bz'].'</td>
				<td>'.date('Y-m-d H:i:s', $it618_scoremall_quan['it618_addtime']).'</td>';
			$n=$n+1;
		}
		if($count>0)$tmpstr7.='<tr>
					<td colspan=6><input type="checkbox" id="chk_del" class="checkbox" onclick="check_all(this, \'chk_del\','.$n.')" /><label for="chk_del">'.it618_mall_getlang('s235').'</label> <input type="submit" class="btn" name="it618submitdel" value="'.it618_mall_getlang('s514').'" /> <input type="submit" class="btn" name="it618submit_data" value="'.it618_mall_getlang('s520').'"/><input type=hidden value=$page name=page /></div><div style="float:right">'.$multipage.'</div></td>
					</tr>';	
	}
}elseif($cid==8){
	if($_GET['key']) {
		$extrasql .= " AND g.it618_name LIKE '%".addcslashes(addslashes($_GET['key']),'%_')."%'";
	}

	if($_GET['finduid']) {
		$extrasql .= " AND s.it618_uid = ".intval($_GET['finduid']);
	}
	if($li1il11[8]!='o')return;
	if($li1il11[14]!='l')return;
	
	$sql='&key='.$_GET['key'].'&finduid='.$_GET['finduid'];
	if($_GET['key']!='')$uri.='&key='.$_GET['key'];
	if($_GET['finduid']!='')$uri.='&finduid='.$_GET['finduid'];

	if($uri!=''){
		$uri='?'.$uri;
		$uri=str_replace("?&","?",$uri);
	}
	
	if(submitcheck('it618submit_order_del')){
		$del=0;
		foreach($_GET['delete'] as $key => $delid) {
			$delid=intval($delid);
			if($li1il11[0]!='i')return;
			DB::delete('it618_scoremall_order', "id=$delid");
			$del=$del+1;
		}
		
		showmessage(it618_mall_getlang('s524').$del, '', array(), array('alert' => 'right'));

	}
	if($li1il11[14]!='l')return;
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_order')." s,".DB::table('it618_scoremall_goods')." g WHERE g.it618_uid=".$_G['uid']." and s.it618_pid=g.id ". $extrasql);

	if($_G['cache']['plugin']['it618_scoremall']['rewriteurl']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_scoremall:scoremall_store&cid=8".$uri);
	}else{
		$hrefsql=it618_scoremall_getrewrite('store','ac@find@8@0@it618page','plugin.php?id=it618_scoremall:scoremall_store&cid=8');
		$multipage = multi($count, $ppp, $page, $_G['siteurl'].$hrefsql);
		$multipage = it618_scoremall_multipage($multipage,$uri);
	}
	if($li1il11[8]!='o')return;
	$tmpstr1.='<tr>
				<td colspan="15"><div class="fixsel">'.it618_mall_getlang('s150').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.it618_mall_getlang('s151').' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" />&nbsp;<input type="submit" class="btn" name="it618submit_order_find" value="'.it618_mall_getlang('s149').'" /></div></td></tr><tr><td colspan=13>'.it618_mall_getlang('s526').$count.'
				</td>
				</tr>
				<tr class="header">
				<th></th><th>'.it618_mall_getlang('s527').'</th><th>'.it618_mall_getlang('s538').'</th><th>'.it618_mall_getlang('s530').'</th><th>'.it618_mall_getlang('s531').'</th><th>'.it618_mall_getlang('s532').'</th>
				</tr>';

	$query = DB::query("SELECT s.* FROM ".DB::table('it618_scoremall_order')." s,".DB::table('it618_scoremall_goods')." g WHERE g.it618_uid=".$_G['uid']." and s.it618_pid=g.id ".$extrasql." order by id desc LIMIT ".$startlimit.",".$ppp);
	$n=1;
	while($it618_scoremall_order = DB::fetch($query)) {
		if(count($li1il11)!=15)return;
		$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_order['it618_pid']);
		$it618_class3_id=$it618_scoremall_goods['it618_class3_id'];
		$it618_name=$it618_scoremall_goods['it618_name'];
		$it618_picsmall=it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']);
		if($li1il11[0]!='i')return;
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_scoremall_order['it618_uid']);
		if($li1il11[8]!='o')return;
		
		$strcontent=$it618_scoremall_order['it618_addr'];
		if($it618_scoremall_order['it618_bz']!=''){
			$strcontent.='<br><font color=red>'.$it618_mall_lang['s533'].'</font>'.dhtmlspecialchars($it618_scoremall_order['it618_bz']);
		}
		
		if(count($li1il11)!=15)return;
		$tmpstr='';
		$orderid=$it618_scoremall_order['id'];
		for($i=0;$i<7-strlen($orderid);$i++){
			$tmpstr.='0';
		}
		$orderid=$tmpstr.$orderid;
		
		$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
		$tmpstr1.='<tr class="hover align"><td width="40"><input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_scoremall_order[id].'"> <label for="chk_del'.$n.'" title="'.it618_mall_getlang('s401').'D'.$orderid.$strcode.'">'.$it618_scoremall_order['id'].'</label></td>
			<td width=230><a href="'.$tmpurl.'" title="'.it618_mall_getlang('s177').''.$it618_scoremall_order['it618_pid'].' '.it618_mall_getlang('s178').''.it618_scoremall_class1name($it618_class3_id).' '.it618_scoremall_class2name($it618_class3_id).' '.it618_scoremall_class3name($it618_class3_id).'" target="_blank"><img style="float:left" src="'.$it618_picsmall.'" width="50" height="50" /><div style="float:left;width:150px;text-align:left;padding-left:3px">'.$it618_name.'</div></a></td>
			<td>'.$it618_scoremall_order['it618_count'].'</td>
			<td align="left" width="40%">'.$strcontent.'</td>
			<td><a href="'.it618_scoremall_rewriteurl($it618_scoremall_order['it618_uid']).'" target="_blank">'.$username.'</a></td>
			<td width="70">'.date('Y-m-d H:i:s', $it618_scoremall_order['it618_time']).'</td>';
		$n=$n+1;
	}
	if($count>0)$tmpstr1.='<tr><td class="td25"><input type="checkbox" id="chk_del" class="checkbox" onclick="check_all(this, \'chk_del\','.$n.')" /><label for="chk_del">'.it618_mall_getlang('s415').'</label></td><td colspan="15"><div class="fixsel" style="float:left"><input type="submit" class="btn" name="it618submit_order_del" value="'.it618_mall_getlang('s534').'" onclick="return confirm(\''.it618_mall_getlang('s535').'\')" /><input type=hidden value='.$page.' name=page /></div><div style="float:right">'.$multipage.'</div></td></tr>';
}
	
function it618_scoremall_class1name($aid){
	$class2id = DB::result_first("select it618_class2_id from ".DB::table('it618_scoremall_class3')." where id=".$aid);
	$class1id = DB::result_first("select it618_class1_id from ".DB::table('it618_scoremall_class2')." where id=".$class2id);
	return DB::result_first("select it618_classname from ".DB::table('it618_scoremall_class1')." where id=".$class1id);
}

function it618_scoremall_class2name($aid){
	$class2id = DB::result_first("select it618_class2_id from ".DB::table('it618_scoremall_class3')." where id=".$aid);
	return DB::result_first("select it618_classname from ".DB::table('it618_scoremall_class2')." where id=".$class2id);
}

function it618_scoremall_class3name($aid){
	return DB::result_first("select it618_classname from ".DB::table('it618_scoremall_class3')." where id=".$aid);
}

function it618_scoremall_getusername($uid){
	return DB::result_first("select username from ".DB::table('common_member')." where uid=".$uid);
}

function towstr($i){
	if(strlen($i)==1)return "0".$i;else return $i;
}

$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$_G['uid']);
$it618_scoremall_help=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_help'));
$uidhref=it618_scoremall_rewriteurl($_G['uid']);

//if($it618_scoremall['mall_isgwc']==1){
//	if($_G['uid']>0)$gwcgoodscount=DB::result_first('SELECT count(1) FROM '.DB::table('it618_scoremall_gwc').' WHERE it618_uid = '.$_G['uid']);
//}

if(isset($_GET['page'])){
	$page=$_GET['page'];
}else{
	$page=1;
}

$tmpurl1=it618_scoremall_getrewrite('home','','plugin.php?id=it618_scoremall:scoremall');
$tmpurl2=it618_scoremall_getrewrite('store','','plugin.php?id=it618_scoremall:scoremall_store');
$tmpurl3=it618_scoremall_getrewrite('gwc','','plugin.php?id=it618_scoremall:gwc');
$tmpurl4=it618_scoremall_getrewrite('store','0@0@1@0@1','plugin.php?id=it618_scoremall:scoremall_store&cid=1');
$tmpurl5=it618_scoremall_getrewrite('store','0@0@2@0@1','plugin.php?id=it618_scoremall:scoremall_store&cid=2');
$tmpurl6=it618_scoremall_getrewrite('store','0@0@3@0@1','plugin.php?id=it618_scoremall:scoremall_store&cid=3');
$tmpurl7=it618_scoremall_getrewrite('store','0@0@4@0@1','plugin.php?id=it618_scoremall:scoremall_store&cid=4');
$tmpurl8=it618_scoremall_getrewrite('store','0@0@5@0@1','plugin.php?id=it618_scoremall:scoremall_store&cid=5');
$tmpurl9=it618_scoremall_getrewrite('store','0@0@7@0@1','plugin.php?id=it618_scoremall:scoremall_store&cid=7');
$tmpurl10=it618_scoremall_getrewrite('store','0@0@8@0@1','plugin.php?id=it618_scoremall:scoremall_store&cid=8');
$tmpurl11=it618_scoremall_getrewrite('store','0@0@9@0@1','plugin.php?id=it618_scoremall:scoremall_store&cid=9');
$tmpurl12=it618_scoremall_getrewrite('store','0@0@6@0@1','plugin.php?id=it618_scoremall:scoremall_store&cid=6');

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_scoremall:scoremall_store');
?>