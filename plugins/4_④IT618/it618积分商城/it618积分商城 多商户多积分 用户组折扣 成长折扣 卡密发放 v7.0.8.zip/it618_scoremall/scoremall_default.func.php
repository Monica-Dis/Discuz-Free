<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $it618_mall_lang2;
require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/function.func.php';
$navtitle = $it618_scoremall['seotitle'];
$metakeywords = $it618_scoremall['seokeywords'];
$metadescription = $it618_scoremall['seodescription'];

$jlcreditname=$_G['setting']['extcredits'][$it618_scoremall['mall_jlcredit']]['title'];

$scoremall_homeurl=it618_scoremall_getrewrite('home','','plugin.php?id=it618_scoremall:scoremall');
$scoremall_ucurl=it618_scoremall_getrewrite('uc','','plugin.php?id=it618_scoremall:scoremall_uc');
$scoremall_storeurl=it618_scoremall_getrewrite('store','','plugin.php?id=it618_scoremall:scoremall_store');
$scoremall_listurl=it618_scoremall_getrewrite('productlist','','plugin.php?id=it618_scoremall:scoremall_list');
$findurl=it618_scoremall_getrewrite('productlist','ac@find@1','plugin.php?id=it618_scoremall:scoremall_list');

$isnotstore=1;
if($_G['uid']>0){
	if(DB::result_first("select count(1) from ".DB::table('it618_scoremall_store')." where it618_uid=".$_G['uid'])==0){
		$isnotstore=1;
		$ac_renzheng='add';
	}else{
		$it618_scoremall_store=DB::fetch_first("select * from ".DB::table('it618_scoremall_store')." where it618_uid=".$_G['uid']);
		$it618_state=$it618_scoremall_store['it618_state'];
		if($it618_state==2){
			$isnotstore=0;
		}else{
			$isnotstore=1;
			$ac_renzheng='edit&rid='.$it618_scoremall_store['id'];
		}
	}
}

$count1=DB::result_first("select count(1) from ".DB::table('it618_scoremall_class1'));

if($count1>1){
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class1')." ORDER BY it618_order desc");
	while($it618_scoremall_class1 = DB::fetch($query1)) {
		if($it618_scoremall_class1['it618_color']!="")$tmpname='<font color='.$it618_scoremall_class1['it618_color'].'>'.$it618_scoremall_class1['it618_classname'].'</font>';else 	$tmpname=$it618_scoremall_class1['it618_classname'];
		$tmpurl1=it618_scoremall_getrewrite('productlist','class1@'.$it618_scoremall_class1['id'].'@1','plugin.php?id=it618_scoremall:scoremall_list&class1='.$it618_scoremall_class1['id']);
		
		$count=DB::result_first("select count(1) from ".DB::table('it618_scoremall_class2')." where it618_class1_id=".$it618_scoremall_class1['id']);
		if($count==0)$tmppop='it618classpop1';else $tmppop='it618classpop';
		$str_class.='<li><div class=it618classtx><a href="'.$tmpurl1.'"><i>&nbsp;</i>'.$tmpname.'</a></div>it618temp<div class='.$tmppop.'>';
		
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class2')." where it618_class1_id=".$it618_scoremall_class1['id']." ORDER BY it618_order desc");
		$it618temp='';
		while($it618_scoremall_class2 = DB::fetch($query2)) {
			if($it618_scoremall_class2['it618_color']!="")$tmpname='<font color='.$it618_scoremall_class2['it618_color'].'>'.$it618_scoremall_class2['it618_classname'].'</font>';else $tmpname=$it618_scoremall_class2['it618_classname'];
			$tmpurl2=it618_scoremall_getrewrite('productlist','class2@'.$it618_scoremall_class2['id'].'@1','plugin.php?id=it618_scoremall:scoremall_list&class2='.$it618_scoremall_class2['id']);
			if($it618_scoremall_class2['it618_istj']==1)$it618temp.=' <a href="'.$tmpurl2.'">'.$tmpname.'</a>';
	
			$str_class.='<dl><dt><a href="'.$tmpurl2.'"><b>'.$tmpname.'</b></a></dt><dd>';
	
			$query3 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." where it618_class2_id=".$it618_scoremall_class2['id']." ORDER BY it618_order desc");
			while($it618_scoremall_class3 = DB::fetch($query3)) {
				$tmpurl3=it618_scoremall_getrewrite('productlist','class3@'.$it618_scoremall_class3['id'].'@1','plugin.php?id=it618_scoremall:scoremall_list&class3='.$it618_scoremall_class3['id']);
				if($it618_scoremall_class3['it618_color']!="")$tmpname='<font color='.$it618_scoremall_class3['it618_color'].'>'.$it618_scoremall_class3['it618_classname'].'</font>';else $tmpname=$it618_scoremall_class3['it618_classname'];
				if($it618_scoremall_class3['it618_istj']==1)$it618temp.=' <a href="'.$tmpurl3.'">'.$tmpname.'</a>';
				$str_class.='<a href="'.$tmpurl3.'">'.$tmpname.'</a>';
			}
			$str_class.='</dd></dl>';
		}
		
		$imgstr='';
		if($it618temp!=''){
			$it618temp="<dl><dd>$it618temp</dd></dl>";
			$imgstr='<a href="'.$it618_scoremall_class1['it618_url'].'" target="_blank"><img src="'.$it618_scoremall_class1['it618_img'].'"></a>';
		}
		$str_class=str_replace("it618temp",$it618temp,$str_class);
		$str_class.='<div class=clr></div>
						<div class=it618classimg>'.$imgstr.'</div>
					</div></li>';
	}
}else{
	$count2=DB::result_first("select count(1) from ".DB::table('it618_scoremall_class2'));
	if($count2>1){
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class2')." ORDER BY it618_order desc");
		while($it618_scoremall_class2 = DB::fetch($query2)) {
			$it618temp='';
			if($it618_scoremall_class2['it618_color']!="")$tmpname='<font color='.$it618_scoremall_class2['it618_color'].'>'.$it618_scoremall_class2['it618_classname'].'</font>';else $tmpname=$it618_scoremall_class2['it618_classname'];
			$tmpurl2=it618_scoremall_getrewrite('productlist','class2@'.$it618_scoremall_class2['id'].'@1','plugin.php?id=it618_scoremall:scoremall_list&class2='.$it618_scoremall_class2['id']);
			if($it618_scoremall_class2['it618_istj']==1)$it618temp.=' <a href="'.$tmpurl2.'">'.$tmpname.'</a>';
			
			$count=DB::result_first("select count(1) from ".DB::table('it618_scoremall_class3')." where it618_class2_id=".$it618_scoremall_class2['id']);
			if($count==0)$tmppop='it618classpop1';else $tmppop='it618classpop';
			$str_class.='<li><div class=it618classtx><a href="'.$tmpurl2.'"><i>&nbsp;</i>'.$tmpname.'</a></div>it618temp<div class='.$tmppop.'>';
	
			$str_class.='<dl><dd>';
	
			$query3 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." where it618_class2_id=".$it618_scoremall_class2['id']." ORDER BY it618_order desc");
			while($it618_scoremall_class3 = DB::fetch($query3)) {
				$tmpurl3=it618_scoremall_getrewrite('productlist','class3@'.$it618_scoremall_class3['id'].'@1','plugin.php?id=it618_scoremall:scoremall_list&class3='.$it618_scoremall_class3['id']);
				if($it618_scoremall_class3['it618_color']!="")$tmpname='<font color='.$it618_scoremall_class3['it618_color'].'>'.$it618_scoremall_class3['it618_classname'].'</font>';else $tmpname=$it618_scoremall_class3['it618_classname'];
				if($it618_scoremall_class3['it618_istj']==1)$it618temp.=' <a href="'.$tmpurl3.'">'.$tmpname.'</a>';
				$str_class.='<a href="'.$tmpurl3.'">'.$tmpname.'</a>';
			}
			$str_class.='</dd></dl>';
			
			if($it618temp!=''){
				$it618temp="<dl><dd>$it618temp</dd></dl>";
				$imgstr='<a href="'.$it618_scoremall_class1['it618_url'].'" target="_blank"><img src="'.$it618_scoremall_class1['it618_img'].'"></a>';
			}
			$str_class=str_replace("it618temp",$it618temp,$str_class);
			$str_class.='<div class=clr></div>
						</div></li>';
		}
	}else{
		$query3 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." ORDER BY it618_order desc");
		while($it618_scoremall_class3 = DB::fetch($query3)) {
			$tmpurl3=it618_scoremall_getrewrite('productlist','class3@'.$it618_scoremall_class3['id'].'@1','plugin.php?id=it618_scoremall:scoremall_list&class3='.$it618_scoremall_class3['id']);
			if($it618_scoremall_class3['it618_color']!="")$tmpname='<font color='.$it618_scoremall_class3['it618_color'].'>'.$it618_scoremall_class3['it618_classname'].'</font>';else $tmpname=$it618_scoremall_class3['it618_classname'];
			
			$str_class.='<li><div class=it618classtx><a href="'.$tmpurl3.'"><i>&nbsp;</i>'.$tmpname.'</a></div></li>';
			
		}
	}
}
//From: Dism_taobao-com
?>