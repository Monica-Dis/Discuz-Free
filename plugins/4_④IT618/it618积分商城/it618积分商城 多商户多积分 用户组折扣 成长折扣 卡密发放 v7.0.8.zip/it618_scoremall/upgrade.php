<?php
/*
	Install Uninstall Upgrade AutoStat System Code
	admin.php?action=plugins&operation=pluginupgrade&dir=it618_scoremall
*/
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/message.php')){
	rename(DISCUZ_ROOT.'./source/plugin/it618_scoremall/rewrite.php',DISCUZ_ROOT.'./source/plugin/it618_scoremall/config/rewrite.php');
	rename(DISCUZ_ROOT.'./source/plugin/it618_scoremall/message.php',DISCUZ_ROOT.'./source/plugin/it618_scoremall/config/message.php');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_tips` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(200) NOT NULL,
  `it618_message1` mediumtext NOT NULL,
  `it618_message2` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_help` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_waphomead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_store` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_logo` varchar(200) NOT NULL,
  `it618_name` varchar(200) NOT NULL,
  `it618_tel` varchar(200) NOT NULL,
  `it618_qq` varchar(200) NOT NULL,
  `it618_liyou` varchar(8000) NOT NULL,
  `it618_width` int(10) unsigned NOT NULL DEFAULT '400',
  `it618_height` int(10) unsigned NOT NULL DEFAULT '300',
  `it618_servertitle` varchar(800) NOT NULL,
  `it618_server` mediumtext NOT NULL,
  `it618_server_daishen` mediumtext NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_message_daishen` mediumtext NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_htstate` int(10) unsigned NOT NULL,
  `it618_filespace` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_rztime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_htetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_store_level` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_level` int(10) unsigned NOT NULL,
  `it618_score1` int(10) unsigned NOT NULL,
  `it618_score2` int(10) unsigned NOT NULL,
  `it618_tc` float(9,2) NOT NULL,
  `it618_filesizes` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_store_groupup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_score` int(10) unsigned NOT NULL NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_store_groupuplog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_score` int(10) unsigned NOT NULL NULL DEFAULT '0',
  `it618_curallscore` int(10) unsigned NOT NULL NULL DEFAULT '0',
  `it618_bz` varchar(2000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_goods_km` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_code` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_pl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_quoteid` int(10) unsigned NOT NULL,
  `it618_content` varchar(2000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_kd` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_url` varchar(1000) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_quan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_storeid` int(10) unsigned NOT NULL,
  `it618_adduid` int(10) unsigned NOT NULL,
  `it618_useuid` int(10) unsigned NOT NULL,
  `it618_code` varchar(32) NOT NULL,
  `it618_type` int(10) unsigned NOT NULL,
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_usetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_saleuid` int(10) unsigned NOT NULL,
  `it618_count` int(10) unsigned NOT NULL,
  `it618_addr` varchar(2000) NOT NULL,
  `it618_bz` varchar(8000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_goods_salekm` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_code` varchar(1000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_kmpower` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_diy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(100) NOT NULL,
  `it618_type` varchar(50) NOT NULL,
  `it618_modecode` mediumtext NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_isjs` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_catchtime` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_salework` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_gwc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_count` int(10) unsigned NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_code` varchar(32) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_storeid` int(10) unsigned NOT NULL,
  `it618_tel` varchar(100) NOT NULL,
  `it618_password` varchar(100) NOT NULL,
  `it618_Body` mediumtext NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_taobao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_groupzk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_zk` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_iconav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_wapfocus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_scoremall_goods'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_xiangoucount', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_xiangoucount` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_isbm', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_isbm` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_state', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_state` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_htstate', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_htstate` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}
if(!in_array('it618_jforder', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_jforder` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_store_order', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_store_order` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_message_daishen', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_message_daishen` mediumtext NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_grouppower', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_grouppower` varchar(800) NOT NULL default '';"; 
	DB::query($sql); 
}
if(!in_array('it618_tc', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_tc` float(9,2) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_iszk', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_iszk` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_isorder', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_isorder` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_ischeck', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_ischeck` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sql); 
}
if(!in_array('it618_istaobao', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_istaobao` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_isquan', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_isquan` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_taobaourl', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_taobaourl` varchar(300) NOT NULL default '';"; 
	DB::query($sql); 
}
if(!in_array('it618_xiangoutime', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_xiangoutime` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_xgtype', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_xgtype` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql);
}
if(!in_array('it618_xgtime1', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_xgtime1` varchar(20) NOT NULL;"; 
	DB::query($sql);  
}
if(!in_array('it618_xgtime2', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_xgtime2` varchar(20) NOT NULL;"; 
	DB::query($sql);  
}
if(!in_array('it618_jfid1', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_jfid1` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_score1', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_score1` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_picbig1', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_picbig1` varchar(300) NOT NULL default '';"; 
	DB::query($sql); 
}
if(!in_array('it618_picbig2', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_picbig2` varchar(300) NOT NULL default '';"; 
	DB::query($sql); 
}
if(!in_array('it618_picbig3', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_picbig3` varchar(300) NOT NULL default '';"; 
	DB::query($sql); 
}
if(!in_array('it618_picbig4', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_goods')." add `it618_picbig4` varchar(300) NOT NULL default '';"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_scoremall_sale'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_saletc', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_sale')." add `it618_saletc` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_tc', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_sale')." add `it618_tc` float(9,2) NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_saleuid', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_sale')." add `it618_saleuid` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_kdid', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_sale')." add `it618_kdid` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_kddan', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_sale')." add `it618_kddan` varchar(100) NOT NULL;";
	DB::query($sql); 
}
if(!in_array('it618_km', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_sale')." add `it618_km` mediumtext NOT NULL;";
	DB::query($sql); 
}
if(!in_array('it618_quanmoney', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_sale')." add `it618_quanmoney` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_quanmoney1', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_sale')." add `it618_quanmoney1` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_code', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_sale')." add `it618_code` varchar(32) NOT NULL;";
	DB::query($sql); 
}
if(!in_array('it618_tel', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_sale')." add `it618_tel` varchar(20) NOT NULL;";
	DB::query($sql); 
}
if(!in_array('it618_jfid1', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_sale')." add `it618_jfid1` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_score1', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_sale')." add `it618_score1` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_price1', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_sale')." add `it618_price1` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}
if(!in_array('it618_saletc1', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_sale')." add `it618_saletc1` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_scoremall_store'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_logo', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_store')." add `it618_logo` varchar(200) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_htstate', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_store')." add `it618_htstate` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}
if(!in_array('it618_htetime', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_store')." add `it618_htetime` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}
if(!in_array('it618_pprice', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_store')." add `it618_pprice` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}
if(!in_array('it618_pcount', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_store')." add `it618_pcount` int(10) unsigned NOT NULL DEFAULT '100';"; 
	DB::query($sql); 
}
if(!in_array('it618_ptaobao', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_store')." add `it618_ptaobao` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}
if(!in_array('it618_messagetel', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_store')." add `it618_messagetel` varchar(20) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_messageisok', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_store')." add `it618_messageisok` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_scoremall_class1'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_homeposition', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_class1')." add `it618_homeposition` int(10) NOT NULL DEFAULT '2';"; 
	DB::query($sql); 
}
if(!in_array('it618_homecount', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_class1')." add `it618_homecount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}
if(!in_array('it618_homeordertype', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_class1')." add `it618_homeordertype` int(10) unsigned NOT NULL DEFAULT '1';"; 
	DB::query($sql); 
}
if(!in_array('it618_img', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_class1')." add `it618_img` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_url', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_class1')." add `it618_url` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}
if(!in_array('it618_homewapcount', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_class1')." add `it618_homewapcount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_scoremall_class2'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_homeposition', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_class2')." add `it618_homeposition` int(10) NOT NULL DEFAULT '2'"; 
	DB::query($sql); 
}
if(!in_array('it618_homecount', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_class2')." add `it618_homecount` int(10) unsigned NOT NULL DEFAULT '0'"; 
	DB::query($sql); 
}
if(!in_array('it618_homeordertype', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_class2')." add `it618_homeordertype` int(10) unsigned NOT NULL DEFAULT '1'"; 
	DB::query($sql); 
}
if(!in_array('it618_homewapcount', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_class2')." add `it618_homewapcount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_scoremall_class3'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_homeposition', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_class3')." add `it618_homeposition` int(10) NOT NULL DEFAULT '2'"; 
	DB::query($sql); 
}
if(!in_array('it618_homecount', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_class3')." add `it618_homecount` int(10) unsigned NOT NULL DEFAULT '0'"; 
	DB::query($sql); 
}
if(!in_array('it618_homeordertype', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_class3')." add `it618_homeordertype` int(10) unsigned NOT NULL DEFAULT '1'"; 
	DB::query($sql); 
}
if(!in_array('it618_homewapcount', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_class3')." add `it618_homewapcount` int(10) unsigned NOT NULL DEFAULT '0';"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_scoremall_diy'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_pids', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_diy')." add `it618_pids` varchar(8000) NOT NULL"; 
	DB::query($sql); 
}

if(!in_array('it618_catch', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_diy')." add `it618_catch` mediumtext NOT NULL"; 
	DB::query($sql); 
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_scoremall_quan'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_bz', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_quan')." add `it618_bz` varchar(1000) NOT NULL DEFAULT ''";
	DB::query($sql); 
}

if(DB::result_first("select count(1) from ".DB::table('it618_scoremall_wapstyle'))==0){
	$sql = str_replace("\r\n", "\n", lang('plugin/it618_scoremall', 'it618_update1'));
	runquery($sql);
}

unset($col_field);
$query = DB::query("SHOW COLUMNS FROM ".DB::table('it618_scoremall_bottomnav'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('it618_curimg', $col_field)){
	$sql = "Alter table ".DB::table('it618_scoremall_bottomnav')." add `it618_curimg` varchar(255) NOT NULL;"; 
	DB::query($sql);
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>