<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/scoremall_default.func.php';

$navtitle=it618_mall_getlang('s10').' - '.$navtitle;

if(scoremall_is_mobile()){ 
	$tmpurl=it618_scoremall_getrewrite('scoremall_wap','','plugin.php?id=it618_scoremall:wap');
	dheader("location:$tmpurl");
}

$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_htstate<>2");
while($it618_scoremall_store = DB::fetch($query)) {
	if($_G['timestamp']>=$it618_scoremall_store['it618_htetime']){
		DB::query("update ".DB::table('it618_scoremall_store')." set it618_htstate=2 where id=".$it618_scoremall_store['id']);
		DB::query("update ".DB::table('it618_scoremall_goods')." set it618_htstate=0 WHERE it618_uid=".$it618_scoremall_store['it618_uid']);
	}
}

if($_G['uid']<=0){
	showmessage(it618_mall_getlang('s11'), '', array(), array('alert' => 'error'));	
}


$ili1ll=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ili1ll[]=substr($_GET['id'],$i,1);}
$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$_G['uid']);
if($creditnum=="")$creditnum=0;
if(count($ili1ll)!=15)return;
$avatarimg=it618_scoremall_discuz_uc_avatar($_G['uid'],'middle');
$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_groupup')." where it618_uid=".$_G['uid']);
if($count==""||$count==0){
	DB::insert('it618_scoremall_groupup', array(
		'it618_uid' => $_G['uid'],
	));
}

$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_groupup')." where it618_uid=".$_G['uid']);
if($count==""||$count==0){
	C::t('#it618_scoremall#it618_scoremall_groupup')->insert(array(
		'it618_uid' => $_G['uid'],
	), true);
}
$groupupscore=DB::result_first("SELECT it618_score FROM ".DB::table('it618_scoremall_groupup')." where it618_uid=".$_G['uid']);
$it618_scoremall_level=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_level')." where it618_score1<=".$groupupscore." and it618_score2>=".$groupupscore);
$groupuplevel=$it618_scoremall_level['it618_level'];
$ili1ll=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ili1ll[]=substr($_GET['id'],$i,1);}
$groupupscore_str=$groupupscore."/".$it618_scoremall_level['it618_score2'];
$groupupjd=(($groupupscore-$it618_scoremall_level['it618_score1'])/($it618_scoremall_level['it618_score2']-$it618_scoremall_level['it618_score1'])*100)."%";
if($ili1ll[9]!='r')return;
$cid=1;
if(isset($_GET['cid']) && $_GET['cid']){
	$cid=$_GET['cid'];
}

if($cid==1)$cur1='class="cur"';
if($cid==2)$cur2='class="cur"';
if($cid==3)$cur3='class="cur"';
if($cid==4)$cur4='class="cur"';
if($cid==5)$cur5='class="cur"';
if($cid==6)$cur6='class="cur"';

if($cid==1){
	$ppp = 10;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$allcount1=DB::result_first("select count(1) from ".DB::table('it618_scoremall_sale')." WHERE it618_uid=".$_G['uid']);
	$tmpurl=it618_scoremall_getrewrite('uc','1@it618page','plugin.php?id=it618_scoremall:scoremall_uc&cid=1');
	$multipage = multi($allcount1, $ppp, $page, $_G['siteurl'].$tmpurl);
	$multipage = it618_scoremall_multipage($multipage);
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_sale')." WHERE it618_uid=".$_G['uid']." order by id desc LIMIT $startlimit, $ppp");
	$n=1;
	while($it618_scoremall_sale = DB::fetch($query)) {
		if($n%2==0){
			$strcss='style="background-color:#fff"';
		}else{
			$strcss='style="background-color:#fcfcfc"';
		}
		if(count(explode(it618_mall_getlang('s30'),$it618_scoremall_sale['it618_addr']))>1){
			$straddr='<li class="info addr" style="line-height:17px">'.$it618_scoremall_sale['it618_addr'].'</li>';
		}else{
			$straddr='';
		}

		$it618_btn='';
		if($it618_scoremall_sale['it618_state']==1){
			$it618_btn='<a href="javascript:" onclick="if(confirm(\''.it618_mall_getlang('s557').'\'))delsale('.$it618_scoremall_sale['id'].')" class="it618_btn">'.it618_mall_getlang('s558').'</a>';
		}
		if($it618_scoremall_sale['it618_state']==2){
			$it618_btn='<a href="javascript:" onclick="if(confirm(\''.it618_mall_getlang('s14').'\'))setstate('.$it618_scoremall_sale['id'].',3)" class="it618_btn">'.it618_mall_getlang('s15').'</a><a href="javascript:" onclick="if(confirm(\''.it618_mall_getlang('s464').'\'))setstate('.$it618_scoremall_sale['id'].',4)" class="it618_btn">'.it618_mall_getlang('s16').'</a>';
		}

		if($it618_scoremall_sale['it618_state']==1)$it618_state='<font color=red>'.it618_getbuyname(it618_mall_getlang('s173')).'</font>';
		if($it618_scoremall_sale['it618_state']==2)$it618_state='<font color=green>'.it618_mall_getlang('s174').'</font>';
		if($it618_scoremall_sale['it618_state']==3)$it618_state='<font color=green>'.it618_mall_getlang('s175').'</font>';
		if($it618_scoremall_sale['it618_state']==4)$it618_state='<font color=red>'.it618_mall_getlang('s176').'</font>';
		if($it618_scoremall_sale['it618_state']==5)$it618_state='<font color=#999>'.it618_mall_getlang('s246').'</font>';
		if($it618_scoremall_sale['it618_state']==6)$it618_state='<font color=blue>'.it618_mall_getlang('s247').'</font>';
		
		$n=$n+1;
		$ili1ll=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ili1ll[]=substr($_GET['id'],$i,1);}
		$it618_scoremall_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
		if($ili1ll[5]!='_')return;
		
		if($it618_scoremall_sale['it618_kdid']!=0&&$it618_scoremall_sale['it618_kddan']!=''){
			$it618_scoremall_kd=DB::fetch_first("select * from ".DB::table('it618_scoremall_kd')." WHERE id=".$it618_scoremall_sale['it618_kdid']);
			$strkd=it618_mall_getlang('s413').'<a href="'.$it618_scoremall_kd['it618_url'].'" target="_blank"><font color=green>'.$it618_scoremall_kd['it618_name'].'</font></a> '.it618_mall_getlang('s414').'<font color=green>'.$it618_scoremall_sale['it618_kddan'].'</font>';
		}else{
			$strkd='';	
		}
		
		$it618_kmcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods_salekm')." where it618_saleid=".$it618_scoremall_sale['id']);
		
		if($it618_scoremall_sale['it618_km']!=''||$it618_kmcount>0){
			$it618_btn.='<a href="javascript:" onclick="showWindow(\'it618_showkm\',\''.$_G['siteurl'].'plugin.php?id=it618_scoremall:showkm&saleid='.$it618_scoremall_sale['id'].'\');" class="it618_btn">'.it618_mall_getlang('s441').'</a>';
			$strcode='';

		}else{
			$strcode=' '.it618_mall_getlang('s521').'<font color=green>'.$it618_scoremall_sale['it618_code'].'</font>';	
		}
		
		$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_sale['it618_pid'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_sale['it618_pid']);
		$it618_name=cutstr($it618_scoremall_goods['it618_name'], 60);
		
		$jfname=$_G['setting']['extcredits'][$it618_scoremall_sale['it618_jfid']]['title'];
		$it618_price1='';
		if($it618_scoremall_sale['it618_price1']>0){
			$jfname1=$_G['setting']['extcredits'][$it618_scoremall_sale['it618_jfid1']]['title'];
			$it618_price1=' + <span class="count">'.$it618_scoremall_sale['it618_price1'].'</span> <font color=green>'.$jfname1.'</font>';
		}
		
		$it618_quanmoney='';
		if($it618_scoremall_sale['it618_quanmoney']>0){
			$it618_quanmoney=it618_mall_getlang('s515').'<span class="count">'.$it618_scoremall_sale['it618_quanmoney'].'</span> <font color=green>'.$jfname.'</font>';
		}
		if($it618_scoremall_sale['it618_quanmoney1']>0){
			$it618_quanmoney=it618_mall_getlang('s515').'<span class="count">'.$it618_scoremall_sale['it618_quanmoney1'].'</span> <font color=green>'.$jfname1.'</font>';
		}
		
		$uc_get1.='
                 <ul class="ucul" '.$strcss.'>
				 <li class="img"><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'" width="100" height="100" /></a></li>
				 <li class="info" style="line-height:28px"><span class="name"><a href="'.$tmpurl.'" title="'.$it618_scoremall_goods['it618_name'].'" target="_blank">'.$it618_name.'</a></span></li>
				 <li class="info" style="line-height:26px"><span style="float:right">'.$it618_btn.'</span>'.it618_getbuyname(it618_mall_getlang('s19')).'<span class="count">'.$it618_scoremall_sale['it618_price'].'</span> <font color=green>'.$jfname.'</font>'.$it618_price1.' '.it618_mall_getlang('s20').'<span class="count">'.$it618_scoremall_sale['it618_count'].'</span> '.$it618_quanmoney.'</span></li>
				 <li class="info">'.it618_mall_getlang('s22').'<span class="state">'.$it618_state.'</span> '.$strkd.' <font color=#999>'.date('Y-m-d H:i:s', $it618_scoremall_sale['it618_time']).'</font> '.$strcode.' '.it618_mall_getlang('s401').$it618_scoremall_sale['id'].'</li>
				 '.$straddr.'
				 </ul>';
	}
	$uc_get1.=$multipage;
}

$ppp = 20;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

if($cid==2){
	$count=DB::result_first("select count(1) from ".DB::table('it618_scoremall_sale')." WHERE it618_uid=".$_G['uid']);
	$tmpurl=it618_scoremall_getrewrite('uc','2@it618page','plugin.php?id=it618_scoremall:scoremall_uc&cid=2');
	$multipage = multi($count, $ppp, $page, $_G['siteurl'].$tmpurl);
	$multipage = it618_scoremall_multipage($multipage);
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_sale')." WHERE it618_uid=".$_G['uid']." order by id desc LIMIT $startlimit, $ppp");
	$ili1ll=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ili1ll[]=substr($_GET['id'],$i,1);}
	$n=1;
	while($it618_scoremall_sale = DB::fetch($query)) {
		if($n%2==0){
			$strcss='<tr>';
		}else{
			$strcss='<tr class="odd">';
		}
		$n=$n+1;
		$it618_scoremall_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
		if($ili1ll[3]!='1')return;
		
		$jfname=$_G['setting']['extcredits'][$it618_scoremall_sale['it618_jfid']]['title'];
		$it618_price1='';
		if($it618_scoremall_sale['it618_price1']>0){
			$jfname1=$_G['setting']['extcredits'][$it618_scoremall_sale['it618_jfid1']]['title'];
			$it618_price1=' + <font color=red>'.($it618_scoremall_sale['it618_price1']*$it618_scoremall_sale['it618_count']-$it618_scoremall_sale['it618_quanmoney1']).'</font>'.$jfname1;
		}
		
		$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_sale['it618_pid'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_sale['it618_pid']);
		$uc_get2.=$strcss.'
                 <td>'.date('Y-m-d H:i:s', $it618_scoremall_sale['it618_time']).'</td>
                 <td><font color=red>'.($it618_scoremall_sale['it618_price']*$it618_scoremall_sale['it618_count']-$it618_scoremall_sale['it618_quanmoney']).'</font>'.$jfname.$it618_price1.'</td>
                 <td class="al">'.it618_getbuyname(it618_mall_getlang('s23')).''.$it618_scoremall_sale['it618_count'].''.it618_mall_getlang('s24').'<a href="'.$tmpurl.'" title="'.$it618_scoremall_goods['it618_name'].'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a></td>
                 </tr>';
	}

}

if($cid==3){
	$count=DB::result_first("select count(1) from ".DB::table('it618_scoremall_groupuplog')." WHERE it618_uid=".$_G['uid']);
	$tmpurl=it618_scoremall_getrewrite('uc','3@it618page','plugin.php?id=it618_scoremall:scoremall_uc&cid=3');
	$multipage = multi($count, $ppp, $page, $_G['siteurl'].$tmpurl);
	$multipage = it618_scoremall_multipage($multipage);
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_groupuplog')." WHERE it618_uid=".$_G['uid']." order by id desc LIMIT $startlimit, $ppp");
	$ili1ll=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ili1ll[]=substr($_GET['id'],$i,1);}
	$n=1;
	while($it618_scoremall_groupuplog = DB::fetch($query)) {
		if($n%2==0){
			$strcss='<tr>';
		}else{
			$strcss='<tr class="odd">';
		}
		$n=$n+1;
		if($ili1ll[0]!='i')return;
		$uc_get3.=$strcss.'
                 <td>'.date('Y-m-d H:i:s', $it618_scoremall_groupuplog['it618_time']).'</td>
                 <td>'.$it618_scoremall_groupuplog['it618_score'].'</td>
				 <td>'.$it618_scoremall_groupuplog['it618_curallscore'].'</td>
                 <td class="al">'.$it618_scoremall_groupuplog['it618_bz'].'</td>
                 </tr>';
	}
}

if($cid==5){
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_level')." order by it618_level");
	$ili1ll=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ili1ll[]=substr($_GET['id'],$i,1);}
	$n=1;
	if($ili1ll[14]!='l')return;
	while($it618_scoremall_level = DB::fetch($query)) {
		if($it618_scoremall_level['it618_level']==$groupuplevel){
			$strcss1='style="color:#F60;font-weight:bold"';
		}else{
			$strcss1='';
		}
		if($n%2==0){
			$strcss='<tr '.$strcss1.'>';
		}else{
			$strcss='<tr class="odd" '.$strcss1.'>';
		}
		
		$n=$n+1;
		$uc_get5.=$strcss.'
                 <td>'.$it618_scoremall_level['it618_level'].'</td>
                 <td>'.$it618_scoremall_level['it618_score1'].'-'.$it618_scoremall_level['it618_score2'].'</td>
				 <td>'.$it618_scoremall_level['it618_zk'].'%</td>
                 </tr>';
	}
}


$it618_mall_lang41=it618_getbuyname($it618_mall_lang['t41']);

$it618_scoremall_help=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_help'));
$uidhref=it618_scoremall_rewriteurl($_G['uid']);

//if($it618_scoremall['mall_isgwc']==1){
//	if($_G['uid']>0)$gwcgoodscount=DB::result_first('SELECT count(1) FROM '.DB::table('it618_scoremall_gwc').' WHERE it618_uid = '.$_G['uid']);
//}

$tmpurl1=it618_scoremall_getrewrite('home','','plugin.php?id=it618_scoremall:scoremall');
$tmpurl2=it618_scoremall_getrewrite('uc','','plugin.php?id=it618_scoremall:scoremall_uc');
$tmpurl3=it618_scoremall_getrewrite('gwc','','plugin.php?id=it618_scoremall:gwc');
$tmpurl4=it618_scoremall_getrewrite('uc','1@1','plugin.php?id=it618_scoremall:scoremall_uc&cid=1');
$tmpurl5=it618_scoremall_getrewrite('uc','2@1','plugin.php?id=it618_scoremall:scoremall_uc&cid=2');
$tmpurl6=it618_scoremall_getrewrite('uc','3@1','plugin.php?id=it618_scoremall:scoremall_uc&cid=3');
$tmpurl7=it618_scoremall_getrewrite('uc','4@1','plugin.php?id=it618_scoremall:scoremall_uc&cid=4');
$tmpurl8=it618_scoremall_getrewrite('uc','5@1','plugin.php?id=it618_scoremall:scoremall_uc&cid=5');
$tmpurl9=it618_scoremall_getrewrite('uc','6@1','plugin.php?id=it618_scoremall:scoremall_uc&cid=6');

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_scoremall:scoremall_uc');
?>