<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/function.func.php';
$metakeywords = $it618_scoremall['seokeywords'];
$metadescription = $it618_scoremall['seodescription'];

$jlcreditname=$_G['setting']['extcredits'][$it618_scoremall['mall_jlcredit']]['title'];
$sitetitle=$it618_scoremall['seotitle'];
$navtitle=$sitetitle;

if(!scoremall_is_mobile()){
	$ispc=1;
}

$mall_wapurl=explode("|",str_replace(array("\r\n", "\r", "\n"), '|', $it618_scoremall['mall_wapurl']));

$waphome=it618_scoremall_getrewrite('scoremall_wap','','plugin.php?id=it618_scoremall:wap');
$scoremall_home=it618_scoremall_getrewrite('home','','plugin.php?id=it618_scoremall:scoremall');
$pid=intval($_GET['cid']);
$product_home=it618_scoremall_getrewrite('product',$pid,'plugin.php?id=it618_scoremall:scoremall_page&pid='.$pid);
$wapsearch=it618_scoremall_getrewrite('scoremall_wap','search@0@0','plugin.php?id=it618_scoremall:wap&pagetype=search');
$uurl=it618_scoremall_getrewrite('scoremall_wap','u@0@0','plugin.php?id=it618_scoremall:wap&pagetype=u');

$uhref='href="'.$uurl.'"';
if($_G['uid']<=0){
	$uhref='href="javascript:" onclick="userlongin()"';
}

$tmparr=explode($_G['siteurl'],$_SERVER['HTTP_REFERER']);

$stylecount=C::t('#it618_scoremall#it618_scoremall_wapstyle')->count_by_isok_search();
$it618_scoremall_wapstyle=C::t('#it618_scoremall#it618_scoremall_wapstyle')->fetch_by_isok_search();


if(isset($_GET['pagetype'])){
	$pagetype=$_GET['pagetype'];
}else{
	$pagetype='scoremall';
}

if($_G['uid']>0){
	$logout='<li><a href="'.$mall_wapurl[2].'&formhash='.FORMHASH.'" class="react">'.it618_mall_getlang('s619').'</a></li>';
	$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$_G['uid']);

	$strusr='<a href="'.$mall_wapurl[2].'&formhash='.FORMHASH.'" class="btn btn-weak">'.it618_mall_getlang('s619').'</a> <a href="'.it618_scoremall_rewriteurl($_G['uid']).'" target="_blank">'.$username.'</a> '.it618_mall_getlang('s620').$creditname.':<font color=red id="mycreditnum">'.$creditnum.'</font>';
}

$pid=intval($_GET['cid']);
if($pid>0)$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE id=".$pid);

if($it618_scoremall_goods['it618_uid']>0){
	$it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_uid=".$it618_scoremall_goods['it618_uid']);
	if($it618_scoremall_store['it618_htstate']==0){
		echo it618_mall_getlang('s399');exit;
	}
	if($it618_scoremall_store['it618_htstate']==2){
		echo it618_mall_getlang('s400');exit;
	}
	$servertitle=$it618_scoremall_store['it618_servertitle'];
	$servercontent=$it618_scoremall_store['it618_server'];
	$it618_ptaobao=$it618_scoremall_store['it618_ptaobao'];
}else{
	$it618_scoremall_server=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_server'));
	$servertitle=$it618_scoremall_server['it618_title'];
	$servercontent=$it618_scoremall_server['it618_message'];
	$servercontent=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$servercontent);
	$servercontent=preg_replace('/<img.+?src=\"(.+?)\".+?>/','<img src="\1"/>',$servercontent);
	$servercontent=preg_replace('/<table.+?>/','<table cellspacing="0" cellpadding="0" width="100%">',$servercontent);
	$servercontent=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="200" frameborder="0" allowfullscreen="1">',$servercontent);
	$it618_ptaobao=1;
}

$it618_mall_lang1=it618_getbuyname(it618_mall_getlang('s1'));
$it618_mall_lang29=it618_getbuyname($it618_mall_lang['t29']);
$it618_mall_lang93=it618_getbuyname($it618_mall_lang['t93']);
$it618_mall_lang107=it618_getbuyname($it618_mall_lang['t107']);
$it618_mall_lang108=it618_getbuyname($it618_mall_lang['t108']);
$it618_mall_lang110=it618_getbuyname($it618_mall_lang['t110']);
$it618_mall_lang114=it618_getbuyname($it618_mall_lang['t114']);
$it618_mall_lang116=it618_getbuyname($it618_mall_lang['t116']);
$it618_mall_lang119=it618_getbuyname($it618_mall_lang['t119']);
$it618_mall_lang120=it618_getbuyname($it618_mall_lang['t120']);
$it618_mall_lang121=it618_getbuyname($it618_mall_lang['t121']);
$it618_mall_lang123=it618_getbuyname($it618_mall_lang['t123']);

$n=0;
$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_bottomnav')." where it618_order<>0 ORDER BY it618_order");
while($it618_scoremall_bottomnav = DB::fetch($query)) {
	$it618_url=$it618_scoremall_bottomnav['it618_url'];
	$iscur=0;
	
	$tmpurlarr1=explode("{waphome}",$it618_url);
	$it618_url=str_replace("{waphome}",$waphome,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='scoremall'){
			$iscur=1;
		}
	}
	
	$tmpurlarr1=explode("{wapsearch}",$it618_url);
	$it618_url=str_replace("{wapsearch}",$wapsearch,$it618_url);
	if(count($tmpurlarr1)>1){
		if($pagetype=='search'){
			$iscur=1;
		}
	}
	
	if($it618_scoremall_bottomnav['id']==5)$it618_url=it618_scoremall_getrewrite('scoremall_wap','u@0@0','plugin.php?id=it618_scoremall:wap&pagetype=u');
	
	if($iscur==0){
		$REQUEST_URI=str_replace("/","",$_SERVER['REQUEST_URI']);
		$REQUEST_URI=str_replace("?mobile=2","",$REQUEST_URI);
		$REQUEST_URI=str_replace("&mobile=2","",$REQUEST_URI);
		if($REQUEST_URI==$it618_url){
			$iscur=1;
		}
	}
	
	if($iscur==1){
		$it618_img=$it618_scoremall_bottomnav['it618_curimg'];
		$it618_title='<font color="'.$it618_scoremall_bottomnav['it618_color'].'">'.$it618_scoremall_bottomnav['it618_title'].'</font>';
	}else{
		$it618_img=$it618_scoremall_bottomnav['it618_img'];
		$it618_title=$it618_scoremall_bottomnav['it618_title'];
	}
	
	if($it618_scoremall_bottomnav['id']==1){
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;" class="mymenu"><a href="javascript:" style="color:#666"><img src="'.$it618_scoremall_bottomnav['it618_img'].'" height="20" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}else{
		$href='href="'.$it618_url.'"';
		if($_G['uid']<=0&&$it618_scoremall_bottomnav['id']==5){
			$href='href="javascript:" onclick="userlongin()"';
		}
		
		if($it618_url=='{wapkefu}'){
			$href='href="javascript:" onClick="getkefu()"';
		}
		
		$bottomnav.='<td align="center" style="it618width;color:#333;height:48px;border-top:#f1f1f1 1px solid;"><a '.$href.'style="color:#666"><img src="'.$it618_img.'" height="20" style="margin-bottom:3px"><br>'.$it618_title.'</a></td>';
	}

	$n=$n+1;
}


$urlarr=explode("https:",$_G['siteurl']);
if(count($urlarr)==1){
	$thisurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}else{
	$thisurl = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}
$thisurl=str_replace("?mobile=2","",$thisurl);
$thisurl=str_replace("&mobile=2","",$thisurl);

$iswx=1;
if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger')==false)$iswx=0;

if($iswx==1){
	$wx_appid=trim($it618_scoremall['mall_appid']);
	$wx_secret=trim($it618_scoremall['mall_appsecret']);
	if($wx_appid==''&&$wx_secret==''){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php')){
			require DISCUZ_ROOT.'./source/plugin/it618_credits/pay_wx/config.php';
		}
	}
}

if($wx_appid!=''&&$wx_secret!=''){

	if($pagetype=='product'){
		$pid=intval($_GET['cid']);
		$it618_scoremall_goods = C::t('#it618_scoremall#it618_scoremall_goods')->fetch_by_id($pid);
		
		$wxshare_title=$it618_scoremall_goods['it618_name'];
		$wxshare_imgUrl=it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']);
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		
		$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid']]['title'];
		$wxshare_desc=$it618_scoremall_goods['it618_score'].$jfname;
		if($it618_scoremall_goods['it618_jfid1']>0){
			$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid1']]['title'];
			$wxshare_desc.='+'.$it618_scoremall_goods['it618_score1'].$jfname1;
		}
		$wxshare_desc.=' '.$it618_mall_lang['t227'].':'.$it618_scoremall_goods['it618_scoremallcount'].' '.$it618_mall_lang['t228'].':'.$it618_scoremall_goods['it618_views'];
		
		$wxshare_desc=$it618_scoremall_goods['it618_description'];
		$wxshare_link=$_G['siteurl'].it618_scoremall_getrewrite('scoremall_wap','product@'.$it618_scoremall_goods['id'].'@0','plugin.php?id=it618_scoremall:wap&pagetype=product&cid='.$it618_scoremall_goods['id']);
		
	}else{
		$wxshare_title=$it618_scoremall['seotitle'];
		$wxshare_imgUrl=$it618_scoremall['mall_logo'];
		$tmparr=explode('://',$wxshare_imgUrl);
		if(count($tmparr)==1)$wxshare_imgUrl=$_G['siteurl'].$wxshare_imgUrl;
		$wxshare_desc=$it618_scoremall['seodescription'];
		$wxshare_desc=str_replace(array("\r\n", "\r", "\n"), '', $wxshare_desc);
		$wxshare_link=$_G['siteurl'].it618_scoremall_getrewrite('scoremall_wap','','plugin.php?id=it618_scoremall:wap');
	}
	
	if($wxshare_title!=''){
		$isshare=1;
		require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/wxshare.php';
		$wxshare = new JSSDK($wx_appid, $wx_secret, $thisurl);
		$signPackage = $wxshare->getSignPackage();
	}
}

$wapbottomsubnav=C::t('#it618_scoremall#it618_scoremall_set')->getsetvalue_by_setname('wapbottomsubnav');
$wapbottomsubnavdefault=C::t('#it618_scoremall#it618_scoremall_set')->getsetvalue_by_setname('wapbottomsubnavdefault');

if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_members/kindeditor/plugins/image/images/it618.png')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_members/members.func.php';
	$getapplogin=it618_members_getapplogin($_GET['id']);
	if($appurl=it618_members_apploginok($_GET['token'])){
		dheader("location:$appurl");
	}
}

require DISCUZ_ROOT.'./source/plugin/it618_scoremall/wap/'.$pagetype.'.inc.php';
?>