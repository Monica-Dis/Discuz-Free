<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

global $_G;
if($reabc[4]!='8')return;

loadcache('plugin');
$it618_scoremall = $_G['cache']['plugin']['it618_scoremall'];

require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/function/it618_scoremall.func.php';

if($reabc[13]!='l')return;
$ppp = $pagecount;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$deletes = '';
$extrasql = '';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin_set&identifier='.$identifier.'&operation='.$operation.'&do='.$do;

$cparray = array('admin_focus', 'admin_level', 'admin_server', 'admin_share', 'admin_tips', 'admin_help', 'admin_gonggao', 'admin_kd', 'admin_diy', 'admin_message', 'admin_rewrite', 'admin_wapstyle', 'admin_groupzk','admin_hot','admin_waphomead','admin_iconav','admin_bottomnav','admin_aliyunoss','admin_count','admin_ordergoods', 'admin_wapfocus');
$cp = !in_array($_GET['cp'], $cparray) ? 'admin_hot' : $_GET['cp'];
define(TOOLS_ROOT, dirname(__FILE__).'/');

for($i=0;$i<count($cparray);$i++){
	if($cp==$cparray[$i]){
		$strtmp[]='class="current"';
	}else{
		$strtmp[]='';
	}
}

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">
<li '.$strtmp[13].'><a href="'.$hosturl.'plugins&cp=admin_hot'.$urls.'"><span>'.$it618_mall_lang['s963'].'</span></a></li>
<li '.$strtmp[0].'><a href="'.$hosturl.'plugins&cp=admin_focus'.$urls.'"><span>'.$it618_mall_lang['s59'].'</span></a></li>
<li '.$strtmp[20].'><a href="'.$hosturl.'plugins&cp=admin_wapfocus'.$urls.'"><span>'.$it618_mall_lang['s108'].'</span></a></li>
<li '.$strtmp[11].'><a href="'.$hosturl.'plugins&cp=admin_wapstyle'.$urls.'"><span>'.$it618_mall_lang['s760'].'</span></a></li>
<li '.$strtmp[15].'><a href="'.$hosturl.'plugins&cp=admin_iconav'.$urls.'"><span>'.$it618_mall_lang['s1472'].'</span></a></li>
<li '.$strtmp[16].'><a href="'.$hosturl.'plugins&cp=admin_bottomnav'.$urls.'"><span>'.$it618_mall_lang['s1054'].'</span></a></li>
<li '.$strtmp[1].'><a href="'.$hosturl.'plugins&cp=admin_level'.$urls.'"><span>'.$it618_mall_lang['s60'].'</span></a></li>
<li '.$strtmp[12].'><a href="'.$hosturl.'plugins&cp=admin_groupzk'.$urls.'"><span>'.$it618_mall_lang['s959'].'</span></a></li>
<li '.$strtmp[2].'><a href="'.$hosturl.'plugins&cp=admin_server'.$urls.'"><span>'.$it618_mall_lang['s61'].'</span></a></li>
<li '.$strtmp[3].'><a href="'.$hosturl.'plugins&cp=admin_share'.$urls.'"><span>'.$it618_mall_lang['s62'].'</span></a></li>
<li '.$strtmp[4].'><a href="'.$hosturl.'plugins&cp=admin_tips'.$urls.'"><span>'.$it618_mall_lang['s351'].'</span></a></li>
<li '.$strtmp[5].'><a href="'.$hosturl.'plugins&cp=admin_help'.$urls.'"><span>'.$it618_mall_lang['s352'].'</span></a></li>
<li '.$strtmp[6].'><a href="'.$hosturl.'plugins&cp=admin_gonggao'.$urls.'"><span>'.$it618_mall_lang['s356'].'</span></a></li>
<li '.$strtmp[7].'><a href="'.$hosturl.'plugins&cp=admin_kd'.$urls.'"><span>'.$it618_mall_lang['s462'].'</span></a></li>
<li '.$strtmp[8].'><a href="'.$hosturl.'plugins&cp=admin_diy'.$urls.'"><span>'.$it618_mall_lang['s543'].'</span></a></li>
<li '.$strtmp[9].'><a href="'.$hosturl.'plugins&cp=admin_message'.$urls.'"><span>'.$it618_mall_lang['s544'].'</span></a></li>
<li '.$strtmp[10].'><a href="'.$hosturl.'plugins&cp=admin_rewrite'.$urls.'"><span>'.$it618_mall_lang['s600'].'</span></a></li>
<li '.$strtmp[14].'><a href="'.$hosturl.'plugins&cp=admin_waphomead'.$urls.'"><span>'.$it618_mall_lang['s1138'].'</span></a></li>
<li '.$strtmp[17].'><a href="'.$hosturl.'plugins&cp=admin_aliyunoss'.$urls.'"><span>'.$it618_mall_lang['s1878'].'</span></a></li>
<li '.$strtmp[18].'><a href="'.$hosturl.'plugins&cp=admin_count'.$urls.'"><span>'.$it618_mall_lang['s774'].'</span></a></li>
<li '.$strtmp[19].'><a href="'.$hosturl.'plugins&cp=admin_ordergoods'.$urls.'"><span>'.$it618_mall_lang['s796'].'</span></a></li>
</ul></div>';

require TOOLS_ROOT.'./include/'.$cp.'.inc.php';
showformfooter();
?>