<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/scoremall_default.func.php';

if(scoremall_is_mobile()){ 
	$tmpurl=it618_scoremall_getrewrite('scoremall_wap','','plugin.php?id=it618_scoremall:wap');
	dheader("location:$tmpurl");
}

$mall_homemode=(array)unserialize($it618_scoremall['mall_homemode']);
for($i=1;$i<=8;$i++){
	$homelist[$i]=0;
}

if($it618_scoremall['mall_buyname']==it618_mall_getlang('s0')){
	$it618_mall_lang2=it618_mall_getlang('s442');
}else{
	$it618_mall_lang2=it618_mall_getlang('s2');
}

$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_htstate<>2");
while($it618_scoremall_store = DB::fetch($query)) {
	if($_G['timestamp']>=$it618_scoremall_store['it618_htetime']){
		DB::query("update ".DB::table('it618_scoremall_store')." set it618_htstate=2 where id=".$it618_scoremall_store['id']);
		DB::query("update ".DB::table('it618_scoremall_goods')." set it618_htstate=0 WHERE it618_uid=".$it618_scoremall_store['it618_uid']);
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_focus')." WHERE it618_is=1 ORDER BY it618_order DESC");
$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
while($it618_scoremall_focus = DB::fetch($query)) {
	$str_focus.='<li><a href="'.$it618_scoremall_focus['it618_url'].'" target="_blank" title="'.$it618_scoremall_focus['it618_tip'].'"><img src="'.$it618_scoremall_focus['it618_img'].'" /><p>'.$it618_scoremall_focus['it618_title'].'</p></a></li>';
	if(count($i1ii1)!=15)return;
}

$mall_homewidthheight=explode(",",$it618_scoremall['mall_homewidthheight']);

$index=1;
if(in_array($index, $mall_homemode)&&DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods')."  WHERE it618_ison=1 and it618_state=2 and it618_htstate=1")>0){
	$homelist[$index]=1;
	$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 order by it618_salecount desc");
	$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
	
	$it618_count=$it618_scoremall_goods['it618_count'];
	if($it618_count>0){
		$tmpbtn='<a href="'.$tmpurl.'" class="glb_orgbtn_m right"><span>'.it618_getbuyname(it618_mall_getlang('s1')).'</span></a>';
	}else{
		$tmpbtn='<a class="glb_orgbtn_m"><span><font color=#ccc>'.$it618_scoremall['mall_nocount'].'</font></span></a>';
	}
	
	$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid']]['title'];
	$it618_score1='';
	if($it618_scoremall_goods['it618_jfid1']>0){
		$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid1']]['title'];
		$it618_score1='+<span class="n_score" style="padding-left:1px"><span>'.$it618_scoremall_goods['it618_score1'].'</span>'.$jfname1.'</span>';
	}
	
	$str_salefirstgoods='<div class="jf_sidetab_con"><a href="'.$tmpurl.'" class="onsale_goods" target="product_detail"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'" /><br>'.$it618_scoremall_goods['it618_name'].'</a><div class="onsale_info clearfix">'.$tmpbtn.'<p><span class="n_score" style="padding-right:2px"><span>'.$it618_scoremall_goods['it618_score'].'</span>'.$jfname.'</span>'.$it618_score1.'<br>'.$it618_mall_lang2.' <span class="num">'.$it618_scoremall_goods['it618_salecount'].'</span> '.it618_mall_getlang('s3').'</p></div></div>';
	$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
	if($i1ii1[0]!='i')return;
	
	$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 order by it618_views desc");
	$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
	$it618_count=$it618_scoremall_goods['it618_count'];
	if($it618_count>0){
		$tmpbtn='<a href="'.$tmpurl.'" class="glb_orgbtn_m right"><span>'.it618_getbuyname(it618_mall_getlang('s1')).'</span></a>';
	}else{
		$tmpbtn='<a class="glb_orgbtn_m"><span><font color=#ccc>'.$it618_scoremall['mall_nocount'].'</font></span></a>';
	}
	
	$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid']]['title'];
	$it618_score1='';
	if($it618_scoremall_goods['it618_jfid1']>0){
		$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid1']]['title'];
		$it618_score1='+<span class="n_score" style="padding-left:1px"><span>'.$it618_scoremall_goods['it618_score1'].'</span>'.$jfname1.'</span>';
	}
	
	$str_hotfirstgoods='<div class="jf_sidetab_con" style="display:none"><a href="'.$tmpurl.'" class="onsale_goods" target="product_detail"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'" /><br>'.$it618_scoremall_goods['it618_name'].'</a><div class="onsale_info clearfix">'.$tmpbtn.'<p><span class="n_score" style="padding-right:2px"><span>'.$it618_scoremall_goods['it618_score'].'</span>'.$jfname.'</span>'.$it618_score1.'<br>'.$it618_mall_lang2.' <span class="num">'.$it618_scoremall_goods['it618_salecount'].'</span> '.it618_mall_getlang('s3').'</p></div></div>';
}

$index=2;
if(in_array($index, $mall_homemode)){
	$homelist[$index]=1;
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_gonggao')." where it618_order<>0 ORDER BY it618_order");
	while($it618_scoremall_gonggao = DB::fetch($query)) {
		$it618_title=$it618_scoremall_gonggao['it618_title'];
		$it618_title=cutstr($it618_title,34,'...');
		
		if($it618_scoremall_gonggao['it618_isbold']==1){
			$it618_title='<b>'.$it618_title.'</b>';
		}
		
		if($it618_scoremall_gonggao['it618_color']!=''){
			$it618_title='<font color="'.$it618_scoremall_gonggao['it618_color'].'">'.$it618_title.'</font>';
		}
		
		$str_gonggao.='<li><a href="'.$it618_scoremall_gonggao['it618_url'].'" title="'.$it618_scoremall_gonggao['it618_title'].'" target="_blank">'.$it618_title.'</a></li>';
	}
}

$index=3;
if(in_array($index, $mall_homemode)){
	$homelist[$index]=1;
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_sale')." ORDER BY id desc limit 0,".$mall_zuijinbuy);
	$n=1;
	while($it618_scoremall_sale = DB::fetch($query)) {
		$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE id=".$it618_scoremall_sale['it618_pid']);
		if($it618_scoremall_goods['it618_ison']==1){
			if($it618_scoremall_goods['it618_isbm']==1){
				$tmpavatar='<img src="source/plugin/it618_scoremall/images/noavatar_small.gif"/>';
				$tmpuser='*****';
			}else{
				$tmpavatar='<a href="'.it618_scoremall_rewriteurl($it618_scoremall_sale['it618_uid']).'" target="_blank" c="1"><img src="'.it618_scoremall_discuz_uc_avatar($it618_scoremall_sale['it618_uid'],'small').'"></a>';
				$tmpuser=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_scoremall_sale['it618_uid']);
			}
			$timecount=intval(($_G['timestamp']-$it618_scoremall_sale['it618_time'])/3600);
			if($timecount>24){
				$timecount=intval($timecount/24);
				$timestr=$timecount.it618_mall_getlang('s360');
			}elseif($timecount>=1){
				$timestr=$timecount.it618_mall_getlang('s361');
			}else{
				$timecount=intval(($_G['timestamp']-$it618_scoremall_sale['it618_time'])/60);
				if($timecount>=1){
					$timestr=$timecount.it618_mall_getlang('s362');
				}else{
					$timecount=intval(($_G['timestamp']-$it618_scoremall_sale['it618_time']));
					$timestr=$timecount.it618_mall_getlang('s363');
				}
			}
			$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
			$str_zuijinbuy.='<li><span>'.$tmpavatar.'</span><p>'.$tmpuser.' '.$timestr.' '.it618_getbuyname(it618_mall_getlang('s364')).'<font color=red>'.$it618_scoremall_sale['it618_count'].'</font>'.it618_mall_getlang('s365').'<a href="'.$tmpurl.'" title="'.$it618_scoremall_goods['it618_name'].'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a></p></li>';
			$n=$n+1;
		}

	}
}

$tomonth = date('n'); 
$todate = date('j'); 
$toyear = date('Y');

$index=4;
if(in_array($index, $mall_homemode)){
	$homelist[$index]=1;
	$time=mktime(0, 0, 0, $tomonth, 1, $toyear);
	$query = DB::query("SELECT it618_pid,sum(it618_count) as salecount FROM ".DB::table('it618_scoremall_sale')." where it618_time>=$time group by it618_pid ORDER BY salecount desc");
	$n=1;
	while($it618_scoremall_sale = DB::fetch($query)) {
		$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE id=".$it618_scoremall_sale['it618_pid']);
		if($n<=$mall_rankcount&&$it618_scoremall_goods['it618_ison']==1){
			if($n==1)$tmpstr1='class="cur"';else $tmpstr1='';
			if($n<=3)$tmpstr2='<span class="t'.$n.'"></span>';else $tmpstr2='<span class="num">'.$n.'</span>';
			$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
			
			$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
			$str_monthrank.='<li '.$tmpstr1.'><span class="it618_top3">'.$it618_scoremall_sale['salecount'].'</span>'.$tmpstr2.'<div class="imgtext"><a href="'.$tmpurl.'" class="img" target="_blank"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'" width="48" height="48" /></a><a href="'.$tmpurl.'" class="txt it618_top3" title="'.$it618_scoremall_goods['it618_name'].'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a></div></li>';
			if($i1ii1[4]!='8')return;
			$n=$n+1;
		}
	}
	
	$time=mktime(0, 0, 0, 1, 1, $toyear);
	$query = DB::query("SELECT it618_pid,sum(it618_count) as salecount FROM ".DB::table('it618_scoremall_sale')." where it618_time>=$time group by it618_pid ORDER BY salecount desc");
	$n=1;
	while($it618_scoremall_sale = DB::fetch($query)) {
		$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE id=".$it618_scoremall_sale['it618_pid']);
		if($n<=$mall_rankcount&&$it618_scoremall_goods['it618_ison']==1){
			if($n==1)$tmpstr1='class="cur"';else $tmpstr1='';
			if($n<=3)$tmpstr2='<span class="t'.$n.'"></span>';else $tmpstr2='<span class="num">'.$n.'</span>';
			$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
			
			$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
			$str_yearrank.='<li '.$tmpstr1.'><span class="it618_top3">'.$it618_scoremall_sale['salecount'].'</span>'.$tmpstr2.'<div class="imgtext"><a href="'.$tmpurl.'" class="img" target="_blank"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'" width="48" height="48" /></a><a href="'.$tmpurl.'" class="txt it618_top3" title="'.$it618_scoremall_goods['it618_name'].'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a></div></li>';
			if($i1ii1[4]!='8')return;
			$n=$n+1;
		}
	}
}

$index=5;
if(in_array($index, $mall_homemode)&&$it618_scoremall['mall_isstore']==1){
	$homelist[$index]=1;
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_store')." where it618_htstate=1 ORDER BY id desc limit 0,".$mall_renzhengcount);
	$n=1;
	while($it618_scoremall_store = DB::fetch($query)) {
		$tmpurl=it618_scoremall_getrewrite('productlist','sid@'.$it618_scoremall_store['id'].'@1','plugin.php?id=it618_scoremall:scoremall_list&sid='.$it618_scoremall_store['id']);
		$str_store.='<li><span><img src="'.$it618_scoremall_store['it618_logo'].'"/></span><p>'.$it618_scoremall_store['it618_name'].'<br /><a href="'.$tmpurl.'" target="_blank">'.it618_mall_getlang('s392').'&gt;&gt;</a></p></li>';
	}
}

for($i=1;$i<=3;$i++){
	$querytmp = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class'.$i)." where it618_homecount<>0 ORDER BY it618_order");
	while($it618_scoremall_class = DB::fetch($querytmp)) {
		$strgoodtmp=getgoodsbyclass($i,$it618_scoremall_class['id'],$it618_scoremall_class['it618_classname'],$it618_scoremall_class['it618_homeposition'],$it618_scoremall_class['it618_homecount'],$it618_scoremall_class['it618_homeordertype']);
		if($strgoodtmp!=''){
			if($it618_scoremall_class['it618_homeposition']==1)$it618_homeposition1.=$strgoodtmp;
			if($it618_scoremall_class['it618_homeposition']==2)$it618_homeposition2.=$strgoodtmp;
			if($it618_scoremall_class['it618_homeposition']==3)$it618_homeposition3.=$strgoodtmp;
		}
	}
}
		
function getgoodsbyclass($classtype,$classid,$classname,$position,$count,$ordertype){
	global $_G,$it618_scoremall,$it618_mall_lang2;
	if($classtype==1){
		$rightclasstmpurl=it618_scoremall_getrewrite('productlist','class1@'.$classid.'@1','plugin.php?id=it618_scoremall:scoremall_list&class1='.$classid);
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class2')." where it618_class1_id=".$classid." ORDER BY it618_order desc");
		while($it618_scoremall_class2 = DB::fetch($query2)) {
			$query3 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." where it618_class2_id=".$it618_scoremall_class2['id']." ORDER BY it618_order desc");
			while($it618_scoremall_class3 = DB::fetch($query3)) {
				$rightclassid.=$it618_scoremall_class3['id'].',';
			}
		}
		$rightclassid=$rightclassid.'0';
	}elseif($classtype==2){
		$rightclasstmpurl=it618_scoremall_getrewrite('productlist','class2@'.$classid.'@1','plugin.php?id=it618_scoremall:scoremall_list&class2='.$classid);
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." where it618_class2_id=".$classid." ORDER BY it618_order desc");
		while($it618_scoremall_class3 = DB::fetch($query2)) {
			$rightclassid.=$it618_scoremall_class3['id'].',';
		}
		$rightclassid=$rightclassid.'0';
	}else{
		$rightclassid=$classid;
		$rightclasstmpurl=it618_scoremall_getrewrite('productlist','class3@'.$classid.'@1','plugin.php?id=it618_scoremall:scoremall_list&class3='.$classid);
	}
	
	if($rightclassid!=''){
		if($ordertype==1)$rightsql='ORDER BY id desc';
		if($ordertype==2)$rightsql='ORDER BY it618_salecount desc';
		if($ordertype==3)$rightsql='and it618_istj=1 ORDER BY id desc';
		if($ordertype==4)$rightsql='and it618_istj=1 ORDER BY it618_salecount desc';
		if($ordertype==5)$rightsql='ORDER BY it618_count desc';
		if($ordertype==6)$rightsql='and it618_istj=1 ORDER BY it618_count desc';
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 and it618_class3_id in($rightclassid) $rightsql limit 0,".$count);
		while($it618_scoremall_goods = DB::fetch($query)) {
			$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
			$it618_count=$it618_scoremall_goods['it618_count'];
			if($it618_count>0){
				$tmpbtn='<a href="'.$tmpurl.'" class="glb_graybtn_s" target="_blank"><span>'.it618_getbuyname(it618_mall_getlang('s1')).'</span></a>';
			}else{
				$tmpbtn='<a class="glb_graybtn_s"><span><font color=#ccc>'.$it618_scoremall['mall_nocount'].'</font></span></a>';
			}
			
			$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid']]['title'];
			$it618_score1='';
			if($it618_scoremall_goods['it618_jfid1']>0){
				$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid1']]['title'];
				$it618_score1='+<span class="score" style="padding-left:1px"><span>'.$it618_scoremall_goods['it618_score1'].'</span>'.$jfname1.'</span>';
			}
			
			$str_goods.='<li><div class="img_holder"><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'" /></a></div><a href="'.$tmpurl.'" class="it618_title" title="'.$it618_scoremall_goods['it618_name'].'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a><p><span class="score" style="padding-right:3px"><span>'.$it618_scoremall_goods['it618_score'].'</span>'.$jfname.'</span>'.$it618_score1.'<span class="cost"></span></p><p style="color:#999;padding:0"><span style="float:right">'.it618_mall_getlang('s139').'<span class="num">'.$it618_scoremall_goods['it618_views'].'</span></span>'.it618_mall_getlang('s5').'<span class="num">'.$it618_count.'</span>'.it618_mall_getlang('s3').'</p><p>'.$tmpbtn.$it618_mall_lang2.'<span class="num">'.$it618_scoremall_goods['it618_salecount'].'</span>'.it618_mall_getlang('s3').'</p></li>';
			$i1iii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1iii1[]=substr($_GET['id'],$i,1);}
			if(count($i1iii1)!=15)return;
		}
		
		if($position==1){
			$str_goods='<div class="jf_main mt18"> 
							 <div class="jf_main_hd"> 
							 <span style="float:right; margin-top:18px"><a href="'.$rightclasstmpurl.'" target="_blank">'.it618_mall_getlang('s634').'&gt;&gt;</a></span><h2 class="it618_title">'.$classname.'</h2> 
							 </div> 
							 <div class="jf_main_bd"> 
							 <div class="jf_goods_items liflag"> 
								 <ul class="jf_goods_imglist clearfix"> 
								 '.$str_goods.'
								 </ul> 
							 </div> 
							 </div> 
						 </div>';
		}elseif($position==2){
			$str_goods='<div class="jf_main mt20"> 
							 <div class="jf_main_hd"> 
							  
							 <div class="jf_select_bar"><a href="'.$rightclasstmpurl.'" target="_blank">'.it618_mall_getlang('s634').'&gt;&gt;</a></div> 
							  
							 <h2 class="it618_title">'.$classname.'</h2>
							 </div> 
							 <div class="jf_main_bd"> 
								 <div class="jf_goods_items"> 
									 <ul class="jf_goods_imglist jf_goods_imglist_s clearfix" id="j-group-goods-1"> 
									 '.$str_goods.'
									 </ul> 
								 </div> 
							 </div> 
						</div>';
		}else{
			$str_goods='<div class="jf_main mt18"> 
                         <div class="jf_main_hd"> 
                         <span style="float:right; margin-top:18px"><a href="'.$rightclasstmpurl.'" target="_blank">'.it618_mall_getlang('s634').'&gt;&gt;</a></span> <h2 class="it618_title">'.$classname.'</h2>
                         </div> 
                         <div class="jf_main_bd">
                         <div class="jf_goods_items"> 
                            <ul class="jf_goods_imglist1 jf_goods_imglist_s1 clearfix">
                            '.$str_goods.'
                            </ul> 
                        </div>  
                        </div>
                     </div>';
		}
	}
	
	return $str_goods;

}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/ordergoods.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/ordergoods.php';
}
if($is_ordergoodsok==1){
	$tmpordergoodscount=0;
	if($ordergoods_order==1)$jforder='id desc';
	if($ordergoods_order==2)$jforder='it618_salecount desc';
	if($ordergoods_order==3)$jforder='it618_views desc';
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 and it618_uid>0 ORDER BY it618_jforder desc,it618_uid,".$jforder);
	while($it618_scoremall_goods = DB::fetch($query)) {
		if($tmpuid!=$it618_scoremall_goods['it618_uid']){
			$tmpuid=$it618_scoremall_goods['it618_uid'];
			
			$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
			$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
			$it618_count=$it618_scoremall_goods['it618_count'];
			if($it618_count>0){
				$tmpbtn='<a href="'.$tmpurl.'" class="glb_graybtn_s" target="_blank"><span>'.it618_getbuyname(it618_mall_getlang('s1')).'</span></a>';
			}else{
				$tmpbtn='<a class="glb_graybtn_s"><span><font color=#ccc>'.$it618_scoremall['mall_nocount'].'</font></span></a>';
			}
			
			$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid']]['title'];
			$it618_score1='';
			if($it618_scoremall_goods['it618_jfid1']>0){
				$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid1']]['title'];
				$it618_score1='+<span class="score" style="padding-left:1px"><span>'.$it618_scoremall_goods['it618_score1'].'</span>'.$jfname1.'</span>';
			}
			
			$str_jfordergoods.='<li><div class="img_holder"><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'" /></a></div><a href="'.$tmpurl.'" class="it618_title" title="'.$it618_scoremall_goods['it618_name'].'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a><p><span class="score" style="padding-right:3px"><span>'.$it618_scoremall_goods['it618_score'].'</span>'.$jfname.'</span>'.$it618_score1.'<span class="cost"></span></p><p style="color:#999;padding:0"><span style="float:right">'.it618_mall_getlang('s139').'<span class="num">'.$it618_scoremall_goods['it618_views'].'</span></span>'.it618_mall_getlang('s5').'<span class="num">'.$it618_count.'</span>'.it618_mall_getlang('s3').'</p><p>'.$tmpbtn.$it618_mall_lang2.'<span class="num">'.$it618_scoremall_goods['it618_salecount'].'</span>'.it618_mall_getlang('s3').'</p></li>';
			if($i1ii1[10]!='e')return;
			$tmpordergoodscount=$tmpordergoodscount+1;
			if($tmpordergoodscount==$ordergoods_pccount)break;
		}
	}
}

$index=6;
if(in_array($index, $mall_homemode)&&$mall_hotgoodscount>0){
	$homelist[$index]=1;
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 ORDER BY it618_salecount desc limit 0,".$mall_hotgoodscount);
	while($it618_scoremall_goods = DB::fetch($query)) {
		$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
		$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
		$it618_count=$it618_scoremall_goods['it618_count'];
		if($it618_count>0){
			$tmpbtn='<a href="'.$tmpurl.'" class="glb_graybtn_s" target="_blank"><span>'.it618_getbuyname(it618_mall_getlang('s1')).'</span></a>';
		}else{
			$tmpbtn='<a class="glb_graybtn_s"><span><font color=#ccc>'.$it618_scoremall['mall_nocount'].'</font></span></a>';
		}
		
		$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid']]['title'];
		$it618_score1='';
		if($it618_scoremall_goods['it618_jfid1']>0){
			$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid1']]['title'];
			$it618_score1='+<span class="score" style="padding-left:1px"><span>'.$it618_scoremall_goods['it618_score1'].'</span>'.$jfname1.'</span>';
		}
		
		$str_hotgoods.='<li><div class="img_holder"><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'" /></a></div><a href="'.$tmpurl.'" class="it618_title" title="'.$it618_scoremall_goods['it618_name'].'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a><p><span class="score" style="padding-right:3px"><span>'.$it618_scoremall_goods['it618_score'].'</span>'.$jfname.'</span>'.$it618_score1.'<span class="cost"></span></p><p style="color:#999;padding:0"><span style="float:right">'.it618_mall_getlang('s139').'<span class="num">'.$it618_scoremall_goods['it618_views'].'</span></span>'.it618_mall_getlang('s5').'<span class="num">'.$it618_count.'</span>'.it618_mall_getlang('s3').'</p><p>'.$tmpbtn.$it618_mall_lang2.'<span class="num">'.$it618_scoremall_goods['it618_salecount'].'</span>'.it618_mall_getlang('s3').'</p></li>';
		if($i1ii1[10]!='e')return;
	}
}

$index=7;
if(in_array($index, $mall_homemode)&&$mall_newgoodscount>0){
	$homelist[$index]=1;
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 ORDER BY id desc limit 0,".$mall_newgoodscount);
	while($it618_scoremall_goods = DB::fetch($query)) {
		$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
		$it618_count=$it618_scoremall_goods['it618_count'];
		if($it618_count>0){
			$tmpbtn='<a href="'.$tmpurl.'" class="glb_graybtn_s" target="_blank"><span>'.it618_getbuyname(it618_mall_getlang('s1')).'</span></a>';
		}else{
			$tmpbtn='<a class="glb_graybtn_s"><span><font color=#ccc>'.$it618_scoremall['mall_nocount'].'</font></span></a>';
		}
		
		$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid']]['title'];
		$it618_score1='';
		if($it618_scoremall_goods['it618_jfid1']>0){
			$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid1']]['title'];
			$it618_score1='+<span class="score" style="padding-left:1px"><span>'.$it618_scoremall_goods['it618_score1'].'</span>'.$jfname1.'</span>';
		}
		
		$str_newgoods.='<li><div class="img_holder"><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'" /></a></div><a href="'.$tmpurl.'" class="it618_title" title="'.$it618_scoremall_goods['it618_name'].'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a><p><span class="score" style="padding-right:3px"><span>'.$it618_scoremall_goods['it618_score'].'</span>'.$jfname.'</span>'.$it618_score1.'<span class="cost"></span></p><p style="color:#999;padding:0"><span style="float:right">'.it618_mall_getlang('s139').'<span class="num">'.$it618_scoremall_goods['it618_views'].'</span></span>'.it618_mall_getlang('s5').'<span class="num">'.$it618_count.'</span>'.it618_mall_getlang('s3').'</p><p>'.$tmpbtn.$it618_mall_lang2.'<span class="num">'.$it618_scoremall_goods['it618_salecount'].'</span>'.it618_mall_getlang('s3').'</p></li>';
	}
}

$index=8;
if(in_array($index, $mall_homemode)&&$mall_tjgoodscount>0){
	$homelist[$index]=1;
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 and it618_istj=1 ORDER BY it618_order DESC,id desc limit 0,".$mall_tjgoodscount);
	$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
	while($it618_scoremall_goods = DB::fetch($query)) {
		$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
		$it618_count=$it618_scoremall_goods['it618_count'];
		if($it618_count>0){
			$tmpbtn='<a href="'.$tmpurl.'" class="glb_graybtn_s" target="_blank"><span>'.it618_getbuyname(it618_mall_getlang('s1')).'</span></a>';
		}else{
			$tmpbtn='<a class="glb_graybtn_s"><span><font color=#ccc>'.$it618_scoremall['mall_nocount'].'</font></span></a>';
		}
		
		$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid']]['title'];
		$it618_score1='';
		if($it618_scoremall_goods['it618_jfid1']>0){
			$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid1']]['title'];
			$it618_score1='+<span class="score" style="padding-left:1px"><span>'.$it618_scoremall_goods['it618_score1'].'</span>'.$jfname1.'</span>';
		}
		
		$str_tjgoods.='<li><div class="img_holder"><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'" /></a></div><a href="'.$tmpurl.'" class="it618_title" title="'.$it618_scoremall_goods['it618_name'].'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a><p><span class="score" style="padding-right:3px"><span>'.$it618_scoremall_goods['it618_score'].'</span>'.$jfname.'</span>'.$it618_score1.'<span class="cost"></span></p><p style="color:#999;padding:0"><span style="float:right">'.it618_mall_getlang('s139').'<span class="num">'.$it618_scoremall_goods['it618_views'].'</span></span>'.it618_mall_getlang('s5').'<span class="num">'.$it618_count.'</span>'.it618_mall_getlang('s3').'</p><p>'.$tmpbtn.$it618_mall_lang2.'<span class="num">'.$it618_scoremall_goods['it618_salecount'].'</span>'.it618_mall_getlang('s3').'</p></li>';
		if($i1ii1[13]!='l')return;
	}
}

$it618_scoremall_help=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_help'));

function it618_scoremall_rewriteurl1($fl_html){
	global $_G;
	if($_G['cache']['plugin']['it618_scoremall']['rewriteurl']==1){
		//	forum.php?mod=viewthread&tid=43
		//	thread-43-1-1.html
		$tmparr=explode("forum.php?mod=viewthread",$fl_html);
		if(count($tmparr)>1){
			$fl_html="";
			foreach($tmparr as $key => $tmp){
				if(strpos($tmp,"tid=")==1){
					$tmp=str_replace("&tid=","thread-",$tmp);
					$tmparr1=explode('"',$tmp,2);
					$fl_html.=$tmparr1[0].'-1-1.html"'.$tmparr1[1];
				}else{
					$fl_html.=$tmp;
				}
			}
		}
		
		$tmparr=explode("do=album&id=",$fl_html);
		if(count($tmparr)>1){return $fl_html;}
		
		//	home.php?mod=space&uid=5
		//	space-uid-5.html
		$tmparr=explode("home.php?mod=space",$fl_html);
		if(count($tmparr)>1){
			$fl_html="";
			foreach($tmparr as $key => $tmp){
				if(strpos($tmp,"uid=")==1){
					$tmp=str_replace("&uid=","space-uid-",$tmp);
					$tmparr1=explode('"',$tmp,2);
					$fl_html.=$tmparr1[0].'.html"'.$tmparr1[1];
				}else{
					$fl_html.=$tmp;
				}
			}
		}

	}
	return $fl_html;
}


$it618_mall_lang8=it618_getbuyname($it618_mall_lang['t8']);
$it618_mall_lang14=it618_getbuyname($it618_mall_lang['t14']);
$it618_mall_lang150=it618_getbuyname($it618_mall_lang['t150']);

$it618_mall_lang128=str_replace("(creditname)",$creditname,$it618_mall_lang['t128']);

$uidhref=it618_scoremall_rewriteurl($_G['uid']);
$tmpurl3=it618_scoremall_getrewrite('storelist','','plugin.php?id=it618_scoremall:store_list');
$tmpurl5=it618_scoremall_getrewrite('productlist','','plugin.php?id=it618_scoremall:scoremall_list');
$tmpurl6=it618_scoremall_getrewrite('productlist','ac@tjgoods@1','plugin.php?id=it618_scoremall:scoremall_list&ac=tjgoods');
$tmpurl7=it618_scoremall_getrewrite('productlist','ac@find@1','plugin.php?id=it618_scoremall:scoremall_list');

include template('it618_scoremall:scoremall');
?>