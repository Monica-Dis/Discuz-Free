<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/scoremall_default.func.php';

if(scoremall_is_mobile()){ 
	$tmpurl=it618_scoremall_getrewrite('scoremall_wap','','plugin.php?id=it618_scoremall:wap');
	dheader("location:$tmpurl");
}


if($it618_scoremall['mall_buyname']==it618_mall_getlang('s0')){
	$it618_mall_lang2=it618_mall_getlang('s442');
}else{
	$it618_mall_lang2=it618_mall_getlang('s2');
}

$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_htstate<>2");
while($it618_scoremall_store = DB::fetch($query)) {
	if($_G['timestamp']>=$it618_scoremall_store['it618_htetime']){
		DB::query("update ".DB::table('it618_scoremall_store')." set it618_htstate=2 where id=".$it618_scoremall_store['id']);
		DB::query("update ".DB::table('it618_scoremall_goods')." set it618_htstate=0 WHERE it618_uid=".$it618_scoremall_store['it618_uid']);
	}
}

$mall_homewidthheight=explode(",",$it618_scoremall['mall_homewidthheight']);
if($mall_homewidthheight[0]<889)$mall_pagelistrightcount=0;

if($mall_pagelistrightcount>0){
	if($mall_pagelistlisttype==1){
		$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 ORDER BY it618_salecount desc limit 0,".$mall_pagelistrightcount);
		while($it618_scoremall_goods_tmp = DB::fetch($query)) {
			$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods_tmp['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods_tmp['id']);
			$kmcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".$it618_scoremall_goods_tmp['id']);
			if($kmcount>0)
			{
				$it618_count=$kmcount;
			}else{
				$it618_count=$it618_scoremall_goods_tmp['it618_count'];
			}
			if($it618_count>0){
				$tmpbtn='<a href="'.$tmpurl.'" class="glb_graybtn_s" target="_blank"><span>'.it618_getbuyname(it618_mall_getlang('s1')).'</span></a>';
			}else{
				$tmpbtn='<a class="glb_graybtn_s"><span><font color=#ccc>'.$it618_scoremall['mall_nocount'].'</font></span></a>';
			}
			
			$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods_tmp['it618_jfid']]['title'];
			$it618_score1='';
			if($it618_scoremall_goods_tmp['it618_jfid1']>0){
				$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods_tmp['it618_jfid1']]['title'];
				$it618_score1='+<span class="score" style="padding-left:1px"><span>'.$it618_scoremall_goods_tmp['it618_score1'].'</span>'.$jfname1.'</span>';
			}
			
			$str_hotgoods.='<li><div class="img_holder"><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods_tmp['it618_uid'],$it618_scoremall_goods_tmp['id'],$it618_scoremall_goods_tmp['it618_picbig']).'"  /></a></div><a href="'.$tmpurl.'" class="it618_title" title="'.$it618_scoremall_goods_tmp['it618_name'].'" target="_blank">'.$it618_scoremall_goods_tmp['it618_name'].'</a><p><span class="score" style="padding-right:3px"><span>'.$it618_scoremall_goods_tmp['it618_score'].'</span>'.$jfname.'</span>'.$it618_score1.'<span class="cost"></span></p><p style="color:#999;padding:0"><span style="float:right">'.it618_mall_getlang('s139').'<span class="num">'.$it618_scoremall_goods_tmp['it618_views'].'</span></span>'.it618_mall_getlang('s5').'<span class="num">'.$it618_count.'</span>'.it618_mall_getlang('s3').'</p><p>'.$tmpbtn.$it618_mall_lang2.'<span class="num">'.$it618_scoremall_goods_tmp['it618_salecount'].'</span>'.it618_mall_getlang('s3').'</p></li>';
			$i1iii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1iii1[]=substr($_GET['id'],$i,1);}
			if(count($i1iii1)!=15)return;
		}
	}else{
		$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 ORDER BY id desc limit 0,".$mall_pagelistrightcount);
		while($it618_scoremall_goods_tmp = DB::fetch($query)) {
			$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods_tmp['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods_tmp['id']);
			$kmcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".$it618_scoremall_goods_tmp['id']);
			if($kmcount>0)
			{
				$it618_count=$kmcount;
			}else{
				$it618_count=$it618_scoremall_goods_tmp['it618_count'];
			}
			if($it618_count>0){
				$tmpbtn='<a href="'.$tmpurl.'" class="glb_graybtn_s" target="_blank"><span>'.it618_getbuyname(it618_mall_getlang('s1')).'</span></a>';
			}else{
				$tmpbtn='<a class="glb_graybtn_s"><span><font color=#ccc>'.$it618_scoremall['mall_nocount'].'</font></span></a>';
			}
			
			$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods_tmp['it618_jfid']]['title'];
			$it618_score1='';
			if($it618_scoremall_goods_tmp['it618_jfid1']>0){
				$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods_tmp['it618_jfid1']]['title'];
				$it618_score1='+<span class="score" style="padding-left:1px"><span>'.$it618_scoremall_goods_tmp['it618_score1'].'</span>'.$jfname1.'</span>';
			}
			
			$str_newgoods.='<li><div class="img_holder"><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods_tmp['it618_uid'],$it618_scoremall_goods_tmp['id'],$it618_scoremall_goods_tmp['it618_picbig']).'"  /></a></div><a href="'.$tmpurl.'" class="it618_title" title="'.$it618_scoremall_goods['it618_name'].'" target="_blank">'.$it618_scoremall_goods_tmp['it618_name'].'</a><p><span class="score" style="padding-right:3px"><span>'.$it618_scoremall_goods_tmp['it618_score'].'</span>'.$jfname.'</span>'.$it618_score1.'<span class="cost"></span></p><p style="color:#999;padding:0"><span style="float:right">'.it618_mall_getlang('s139').'<span class="num">'.$it618_scoremall_goods_tmp['it618_views'].'</span></span>'.it618_mall_getlang('s5').'<span class="num">'.$it618_count.'</span>'.it618_mall_getlang('s3').'</p><p>'.$tmpbtn.$it618_mall_lang2.'<span class="num">'.$it618_scoremall_goods_tmp['it618_salecount'].'</span>'.it618_mall_getlang('s3').'</p></li>';
			$i1iii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1iii1[]=substr($_GET['id'],$i,1);}
			if(count($i1iii1)!=15)return;
		}
	}
}

$ppp = $mall_pagelistcount;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$sql="";
$it618_title='<span>'.it618_mall_getlang('s339').'</span>';
$hrefsql=it618_scoremall_getrewrite('productlist','0@0@it618page','plugin.php?id=it618_scoremall:scoremall_list');

if(isset($_GET['pname'])){
	$sql=" and it618_name like '%".addslashes($_GET['pname'])."%'";
	$uri='?pname='.$_GET['pname'];
	$hrefsql=it618_scoremall_getrewrite('productlist','ac@find@it618page','plugin.php?id=it618_scoremall:scoremall_list&pname='.$_GET['pname']);
	$it618_title='<span>'.it618_mall_getlang('s4').' <font color=red>'.$_GET['pname'].'</font></span>';
}
if(isset($_GET['class1']) && $_GET['class1']){
	$class3s="0";
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class2')." WHERE it618_class1_id=".intval($_GET['class1']));
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	while($it618_scoremall_class2 = DB::fetch($query)) {
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." WHERE it618_class2_id=".$it618_scoremall_class2['id']);
		while($it618_scoremall_class3 = DB::fetch($query1)) {
			$class3s.=",".$it618_scoremall_class3['id'];
			if(count($ii1ill)!=15)return;
		}
	}
	$sql.=" and it618_class3_id in(".$class3s.")";
	$hrefsql=it618_scoremall_getrewrite('productlist','class1@'.$_GET['class1'].'@it618page','plugin.php?id=it618_scoremall:scoremall_list&class1='.$_GET['class1']);
	$it618_title='<span>'.DB::result_first("SELECT it618_classname FROM ".DB::table('it618_scoremall_class1')." WHERE id=".intval($_GET['class1'])).'</span>';
}
if(isset($_GET['class2']) && $_GET['class2']){
	$class3s="0";
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." WHERE it618_class2_id=".intval($_GET['class2']));
	while($it618_scoremall_class3 = DB::fetch($query)) {
		$class3s.=",".$it618_scoremall_class3['id'];
		$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	}
	$sql.=" and it618_class3_id in(".$class3s.")";
	$hrefsql=it618_scoremall_getrewrite('productlist','class2@'.$_GET['class2'].'@it618page','plugin.php?id=it618_scoremall:scoremall_list&class2='.$_GET['class2']);
	if($ii1ill[12]!='a')return;
	$classid1=DB::result_first("SELECT it618_class1_id FROM ".DB::table('it618_scoremall_class2')." WHERE id=".intval($_GET['class2']));
	$classname1=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_scoremall_class1')." WHERE id=".$classid1);
	$classname2=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_scoremall_class2')." WHERE id=".intval($_GET['class2']));
	$tmpurl=it618_scoremall_getrewrite('productlist','class1@'.$classid1.'@1','plugin.php?id=it618_scoremall:scoremall_list&class1='.$classid1);
	
	$count1=DB::result_first("select count(1) from ".DB::table('it618_scoremall_class1'));
	if($count1==1){
		$it618_title='<span>'.$classname2.'</span>';
	}else{
		$it618_title='<span><a href="'.$tmpurl.'">'.$classname1.'</a></span><span class="split">&gt;</span><span>'.$classname2.'</span>';
	}
	
}

if(isset($_GET['class3']) && $_GET['class3']){
	$sql=" and it618_class3_id =".intval($_GET['class3']);
	$hrefsql=it618_scoremall_getrewrite('productlist','class3@'.$_GET['class3'].'@it618page','plugin.php?id=it618_scoremall:scoremall_list&class3='.$_GET['class3']);
	$classid2=DB::result_first("SELECT it618_class2_id FROM ".DB::table('it618_scoremall_class3')." WHERE id=".intval($_GET['class3']));
	$classid1=DB::result_first("SELECT it618_class1_id FROM ".DB::table('it618_scoremall_class2')." WHERE id=".$classid2);
	$classname1=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_scoremall_class1')." WHERE id=".$classid1);
	$classname2=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_scoremall_class2')." WHERE id=".$classid2);
	$classname3=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_scoremall_class3')." WHERE id=".intval($_GET['class3']));
	$tmpurl1=it618_scoremall_getrewrite('productlist','class1@'.$classid1.'@1','plugin.php?id=it618_scoremall:scoremall_list&class1='.$classid1);
	$tmpurl2=it618_scoremall_getrewrite('productlist','class2@'.$classid2.'@1','plugin.php?id=it618_scoremall:scoremall_list&class2='.$classid2);
	
	$count1=DB::result_first("select count(1) from ".DB::table('it618_scoremall_class1'));
	$count2=DB::result_first("select count(1) from ".DB::table('it618_scoremall_class2'));
	if($count1==1&&$count2==1){
		$it618_title='<span>'.$classname3.'</span>';
	}elseif($count1==1&&$count2>1){
		$it618_title='<span><a href="'.$tmpurl2.'">'.$classname2.'</a></span><span class="split">&gt;</span><span>'.$classname3.'</span>';
	}else{
		$it618_title='<span><a href="'.$tmpurl1.'">'.$classname1.'</a></span><span class="split">&gt;</span><span><a href="'.$tmpurl2.'">'.$classname2.'</a></span><span class="split">&gt;</span><span>'.$classname3.'</span>';
	}
}

if(isset($_GET['sid']) && $_GET['sid']){
	$it618_uid=DB::result_first("SELECT it618_uid FROM ".DB::table('it618_scoremall_store')." WHERE id=".intval($_GET['sid']));
	$sql=" and it618_uid =".$it618_uid;
	$hrefsql=it618_scoremall_getrewrite('productlist','sid@'.$_GET['sid'].'@it618page','plugin.php?id=it618_scoremall:scoremall_list&sid='.$_GET['sid']);
	$it618_name=DB::result_first("SELECT it618_name FROM ".DB::table('it618_scoremall_store')." WHERE id=".intval($_GET['sid']));
	$it618_title='<span>'.it618_mall_getlang('s409').' <font color=red>'.$it618_name.'</font> '.it618_mall_getlang('s410').'</span>';
}

if(isset($_GET['ac']) && $_GET['ac']=="tjgoods"){
	$sql=" and it618_istj=1";
	$hrefsql=it618_scoremall_getrewrite('productlist','ac@tjgoods@it618page','plugin.php?id=it618_scoremall:scoremall_list&ac=tjgoods');
	$it618_title='<span>'.it618_mall_getlang('s8').'</span>';
}

$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_htstate=1 and it618_state=2 $sql ORDER BY it618_order DESC");

$multipage = multi($count, $ppp, $page, $_G['siteurl'].$hrefsql);
$multipage = it618_scoremall_multipage($multipage,$uri);

$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
if($ii1ill[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/ordergoods.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/ordergoods.php';
	if($ordergoods_isfind==1){
		$orderbytmp=',it618_jforder desc';
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 $sql ORDER BY it618_order DESC".$orderbytmp." LIMIT $startlimit, $ppp");
while($it618_scoremall_goods = DB::fetch($query)) {
	$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
	$it618_count=$it618_scoremall_goods['it618_count'];
	if($it618_count>0){
		$tmpbtn='<a href="'.$tmpurl.'" class="glb_graybtn_s" target="_blank"><span>'.it618_getbuyname(it618_mall_getlang('s1')).'</span></a>';
	}else{
		$tmpbtn='<a class="glb_graybtn_s"><span><font color=#ccc>'.$it618_scoremall['mall_nocount'].'</font></span></a>';
	}
	
	$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid']]['title'];
	$it618_score1='';
	if($it618_scoremall_goods['it618_jfid1']>0){
		$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid1']]['title'];
		$it618_score1='+<span class="score" style="padding-left:1px"><span>'.$it618_scoremall_goods['it618_score1'].'</span>'.$jfname1.'</span>';
	}
	
	$str_goodslist.='<li><div class="img_holder"><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'" /></a></div><a href="'.$tmpurl.'" class="it618_title" title="'.$it618_scoremall_goods['it618_name'].'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a><p><span class="score" style="padding-right:3px"><span>'.$it618_scoremall_goods['it618_score'].'</span>'.$jfname.'</span>'.$it618_score1.'<span class="cost"></span></p><p style="color:#999;padding:0"><span style="float:right">'.it618_mall_getlang('s139').'<span class="num">'.$it618_scoremall_goods['it618_views'].'</span></span>'.it618_mall_getlang('s5').'<span class="num">'.$it618_count.'</span>'.it618_mall_getlang('s3').'</p><p>'.$tmpbtn.$it618_mall_lang2.'<span class="num">'.$it618_scoremall_goods['it618_salecount'].'</span>'.it618_mall_getlang('s3').'</p></li>';
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	if($ii1ill[3]!='1')return;
}

$navtitle=it618_mall_getlang('s4').' - '.$navtitle;


$it618_mall_lang14=it618_getbuyname($it618_mall_lang['t14']);

$it618_scoremall_help=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_help'));

//if($it618_scoremall['mall_isgwc']==1){
//	if($_G['uid']>0)$gwcgoodscount=DB::result_first('SELECT count(1) FROM '.DB::table('it618_scoremall_gwc').' WHERE it618_uid = '.$_G['uid']);
//}

$tmpurl1=it618_scoremall_getrewrite('home','','plugin.php?id=it618_scoremall:scoremall');
$tmpurl2=it618_scoremall_getrewrite('gwc','','plugin.php?id=it618_scoremall:gwc');
$tmpurl3=it618_scoremall_getrewrite('productlist','ac@mygoods@1','plugin.php?id=it618_scoremall:scoremall_list&ac=mygoods');
$tmpurl4=it618_scoremall_getrewrite('productlist','ac@find@1','plugin.php?id=it618_scoremall:scoremall_list');

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_scoremall:scoremall_list');
?>