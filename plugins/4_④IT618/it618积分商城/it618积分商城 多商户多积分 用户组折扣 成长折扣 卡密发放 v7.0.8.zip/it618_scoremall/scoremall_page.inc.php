<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/scoremall_default.func.php';

$pid=intval($_GET['pid']);
if(scoremall_is_mobile()){ 
	$tmpurl=it618_scoremall_getrewrite('scoremall_wap','product@'.$pid.'@0','plugin.php?id=it618_scoremall:wap&pagetype=product&cid='.$pid);
	dheader("location:$tmpurl");
}

if($it618_scoremall['mall_buyname']==it618_mall_getlang('s0')){
	$it618_mall_lang2=it618_mall_getlang('s442');
}else{
	$it618_mall_lang2=it618_mall_getlang('s2');
}

$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_htstate<>2");
while($it618_scoremall_store = DB::fetch($query)) {
	if($_G['timestamp']>=$it618_scoremall_store['it618_htetime']){
		DB::query("update ".DB::table('it618_scoremall_store')." set it618_htstate=2 where id=".$it618_scoremall_store['id']);
		DB::query("update ".DB::table('it618_scoremall_goods')." set it618_htstate=0 WHERE it618_uid=".$it618_scoremall_store['it618_uid']);
	}
}

$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE id=".$pid);

if($it618_scoremall_goods['it618_ison']==0||$it618_scoremall_goods['it618_state']!=2){
	showmessage(it618_mall_getlang('s9'), '', array(), array('alert' => 'error'));
}

$kmcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".$it618_scoremall_goods['id']);
if($kmcount>0){
	DB::query("update ".DB::table('it618_scoremall_goods')." set it618_count=".$kmcount." WHERE id=".$it618_scoremall_goods['id']);
}
			
DB::query("update ".DB::table('it618_scoremall_goods')." set it618_views=it618_views+1 WHERE id=".$pid);

if($it618_scoremall_goods['it618_uid']>0){
	$it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_uid=".$it618_scoremall_goods['it618_uid']);
	if($it618_scoremall_store['it618_htstate']==0){
		showmessage(it618_mall_getlang('s399'), '', array(), array('alert' => 'error'));
	}
	if($it618_scoremall_store['it618_htstate']==2){
		showmessage(it618_mall_getlang('s400'), '', array(), array('alert' => 'error'));
	}
}

for($i=0;$i<=4;$i++){
	if($i==0){$tmpi='';$tmpcss=' class="firstimg curimg"';}else {$tmpi=$i;$tmpcss='';}
	$it618_picbig=$it618_scoremall_goods['it618_picbig'.$tmpi];
	if($it618_picbig!=''){
		$goodspicbig.='<li'.$tmpcss.'><img width="48" height="48" border="0" src="'.it618_scoremall_getgoodspic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_picbig,$i).'" rel="'.$it618_picbig.'" ></li>';
	}
}

$mall_homewidthheight=explode(",",$it618_scoremall['mall_homewidthheight']);
if($mall_homewidthheight[0]<889)$mall_pagerightcount=0;

if($mall_pagerightcount>0){
	if($mall_pagelisttype==1){
		$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 ORDER BY it618_salecount desc limit 0,".$mall_pagerightcount);
		while($it618_scoremall_goods_tmp = DB::fetch($query)) {
			$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods_tmp['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods_tmp['id']);
			$kmcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".$it618_scoremall_goods_tmp['id']);
			if($kmcount>0)
			{
				$it618_count=$kmcount;
			}else{
				$it618_count=$it618_scoremall_goods_tmp['it618_count'];
			}
			if($it618_count>0){
				$tmpbtn='<a href="'.$tmpurl.'" class="glb_graybtn_s" target="_blank"><span>'.it618_getbuyname(it618_mall_getlang('s1')).'</span></a>';
			}else{
				$tmpbtn='<a class="glb_graybtn_s"><span><font color=#ccc>'.$it618_scoremall['mall_nocount'].'</font></span></a>';
			}
			
			$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods_tmp['it618_jfid']]['title'];
			$it618_score1='';
			if($it618_scoremall_goods_tmp['it618_jfid1']>0){
				$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods_tmp['it618_jfid1']]['title'];
				$it618_score1='+<span class="score" style="padding-left:1px"><span>'.$it618_scoremall_goods_tmp['it618_score1'].'</span>'.$jfname1.'</span>';
			}
			
			$str_hotgoods.='<li><div class="img_holder"><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods_tmp['it618_uid'],$it618_scoremall_goods_tmp['id'],$it618_scoremall_goods_tmp['it618_picbig']).'" alt="'.$it618_scoremall_goods_tmp['it618_name'].'" /></a></div><a href="'.$tmpurl.'" class="it618_title" title="'.$it618_scoremall_goods_tmp['it618_name'].'" target="_blank">'.$it618_scoremall_goods_tmp['it618_name'].'</a><p><span class="score" style="padding-right:3px"><span>'.$it618_scoremall_goods_tmp['it618_score'].'</span>'.$jfname.'</span>'.$it618_score1.'<span class="cost"></span></p><p style="color:#999;padding:0"><span style="float:right">'.it618_mall_getlang('s139').'<span class="num">'.$it618_scoremall_goods_tmp['it618_views'].'</span></span>'.it618_mall_getlang('s5').'<span class="num">'.$it618_count.'</span>'.it618_mall_getlang('s3').'</p><p>'.$tmpbtn.$it618_mall_lang2.'<span class="num">'.$it618_scoremall_goods_tmp['it618_salecount'].'</span>'.it618_mall_getlang('s3').'</p></li>';
			$i1iii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1iii1[]=substr($_GET['id'],$i,1);}
			if(count($i1iii1)!=15)return;
		}
	}else{
		$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 ORDER BY id desc limit 0,".$mall_pagerightcount);
		while($it618_scoremall_goods_tmp = DB::fetch($query)) {
			$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods_tmp['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods_tmp['id']);
			$kmcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".$it618_scoremall_goods_tmp['id']);
			if($kmcount>0)
			{
				$it618_count=$kmcount;
			}else{
				$it618_count=$it618_scoremall_goods_tmp['it618_count'];
			}
			if($it618_count>0){
				$tmpbtn='<a href="'.$tmpurl.'" class="glb_graybtn_s" target="_blank"><span>'.it618_getbuyname(it618_mall_getlang('s1')).'</span></a>';
			}else{
				$tmpbtn='<a class="glb_graybtn_s"><span><font color=#ccc>'.$it618_scoremall['mall_nocount'].'</font></span></a>';
			}
			
			$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods_tmp['it618_jfid']]['title'];
			$it618_score1='';
			if($it618_scoremall_goods_tmp['it618_jfid1']>0){
				$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods_tmp['it618_jfid1']]['title'];
				$it618_score1='+<span class="score" style="padding-left:1px"><span>'.$it618_scoremall_goods_tmp['it618_score1'].'</span>'.$jfname1.'</span>';
			}
			
			$str_newgoods.='<li><div class="img_holder"><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods_tmp['it618_uid'],$it618_scoremall_goods_tmp['id'],$it618_scoremall_goods_tmp['it618_picbig']).'" alt="'.$it618_scoremall_goods_tmp['it618_name'].'" /></a></div><a href="'.$tmpurl.'" class="it618_title" title="'.$it618_scoremall_goods_tmp['it618_name'].'" target="_blank">'.$it618_scoremall_goods_tmp['it618_name'].'</a><p><span class="score" style="padding-right:3px"><span>'.$it618_scoremall_goods_tmp['it618_score'].'</span>'.$jfname.'</span>'.$it618_score1.'<span class="cost"></span></p><p style="color:#999;padding:0"><span style="float:right">'.it618_mall_getlang('s139').'<span class="num">'.$it618_scoremall_goods_tmp['it618_views'].'</span></span>'.it618_mall_getlang('s5').'<span class="num">'.$it618_count.'</span>'.it618_mall_getlang('s3').'</p><p>'.$tmpbtn.$it618_mall_lang2.'<span class="num">'.$it618_scoremall_goods_tmp['it618_salecount'].'</span>'.it618_mall_getlang('s3').'</p></li>';
			$i1iii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1iii1[]=substr($_GET['id'],$i,1);}
			if(count($i1iii1)!=15)return;
		}
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 ORDER BY it618_order DESC limit 0,".$mall_pagetjcount);
while($it618_scoremall_goods_tmp = DB::fetch($query)) {
	$i1iii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1iii1[]=substr($_GET['id'],$i,1);}
	$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods_tmp['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods_tmp['id']);
	$kmcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".$it618_scoremall_goods_tmp['id']);
	if($kmcount>0)
	{
		$it618_count=$kmcount;
	}else{
		$it618_count=$it618_scoremall_goods_tmp['it618_count'];
	}
	if($it618_count>0){
		$tmpbtn='<a href="'.$tmpurl.'" class="glb_graybtn_s" target="_blank"><span>'.it618_getbuyname(it618_mall_getlang('s1')).'</span></a>';
	}else{
		$tmpbtn='<a class="glb_graybtn_s"><span><font color=#ccc>'.$it618_scoremall['mall_nocount'].'</font></span></a>';
	}
	
	$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods_tmp['it618_jfid']]['title'];
	$it618_score1='';
	if($it618_scoremall_goods_tmp['it618_jfid1']>0){
		$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods_tmp['it618_jfid1']]['title'];
		$it618_score1='+<span class="score" style="padding-left:1px"><span>'.$it618_scoremall_goods_tmp['it618_score1'].'</span>'.$jfname1.'</span>';
	}
	
	$str_tjgoods.='<li><div class="img_holder"><a href="'.$tmpurl.'" target="_blank"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods_tmp['it618_uid'],$it618_scoremall_goods_tmp['id'],$it618_scoremall_goods_tmp['it618_picbig']).'" alt="'.$it618_scoremall_goods_tmp['it618_name'].'" /></a></div><a href="'.$tmpurl.'" class="it618_title" title="'.$it618_scoremall_goods_tmp['it618_name'].'" target="_blank">'.$it618_scoremall_goods_tmp['it618_name'].'</a><p><span class="score" style="padding-right:3px"><span>'.$it618_scoremall_goods_tmp['it618_score'].'</span>'.$jfname.'</span>'.$it618_score1.'<span class="cost"></span></p><p style="color:#999;padding:0"><span style="float:right">'.it618_mall_getlang('s139').'<span class="num">'.$it618_scoremall_goods_tmp['it618_views'].'</span></span>'.it618_mall_getlang('s5').'<span class="num">'.$it618_count.'</span>'.it618_mall_getlang('s3').'</p><p>'.$tmpbtn.$it618_mall_lang2.'<span class="num">'.$it618_scoremall_goods_tmp['it618_salecount'].'</span>'.it618_mall_getlang('s3').'</p></li>';
	if($i1iii1[8]!='o')return;
}

$jfname1='';
$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid']]['title'];
if($it618_scoremall_goods['it618_jfid1']>0){
	$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid1']]['title'];
}
if($_G['uid']>0){
	$jfcount=DB::result_first("select extcredits".$it618_scoremall_goods['it618_jfid']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
	if($jfcount=="")$jfcount=0;
	if($it618_scoremall_goods['it618_jfid1']>0){
		$jfcount1=DB::result_first("select extcredits".$it618_scoremall_goods['it618_jfid1']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
		if($jfcount1=="")$jfcount1=0;
	}
}

$classid3=DB::result_first("SELECT it618_class3_id FROM ".DB::table('it618_scoremall_goods')." WHERE id=".$pid);
$classid2=DB::result_first("SELECT it618_class2_id FROM ".DB::table('it618_scoremall_class3')." WHERE id=".$classid3);
$classid1=DB::result_first("SELECT it618_class1_id FROM ".DB::table('it618_scoremall_class2')." WHERE id=".$classid2);
$classname1=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_scoremall_class1')." WHERE id=".$classid1);
$classname2=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_scoremall_class2')." WHERE id=".$classid2);
$classname3=DB::result_first("SELECT it618_classname FROM ".DB::table('it618_scoremall_class3')." WHERE id=".$classid3);
$tmpurl1=it618_scoremall_getrewrite('productlist','class1@'.$classid1.'@1','plugin.php?id=it618_scoremall:scoremall_list&class1='.$classid1);
$tmpurl2=it618_scoremall_getrewrite('productlist','class2@'.$classid2.'@1','plugin.php?id=it618_scoremall:scoremall_list&class2='.$classid2);
$tmpurl3=it618_scoremall_getrewrite('productlist','class3@'.$classid3.'@1','plugin.php?id=it618_scoremall:scoremall_list&class3='.$classid3);

$count1=DB::result_first("select count(1) from ".DB::table('it618_scoremall_class1'));
$count2=DB::result_first("select count(1) from ".DB::table('it618_scoremall_class2'));
if($count1==1&&$count2==1){
	$it618_title='<span><a href="'.$tmpurl3.'">'.$classname3.'</a></span><span class="split">&gt;</span><span>'.$it618_scoremall_goods['it618_name'].'</span>';
}elseif($count1==1&&$count2>1){
	$it618_title='<span><a href="'.$tmpurl2.'">'.$classname2.'</a></span><span class="split">&gt;</span><span><a href="'.$tmpurl3.'">'.$classname3.'</a></span><span class="split">&gt;</span><span>'.$it618_scoremall_goods['it618_name'].'</span>';
}else{
	$it618_title='<span><a href="'.$tmpurl1.'">'.$classname1.'</a></span><span class="split">&gt;</span><span><a href="'.$tmpurl2.'">'.$classname2.'</a></span><span class="split">&gt;</span><span><a href="'.$tmpurl3.'">'.$classname3.'</a></span><span class="split">&gt;</span><span>'.$it618_scoremall_goods['it618_name'].'</span>';
}

if($it618_scoremall_goods['it618_uid']>0){
	$it618_storeid=$it618_scoremall_store['id'];
	$it618_storename=$it618_scoremall_store['it618_name'];
	$server_width1=$it618_scoremall_store['it618_width'];$server_width2=$server_width1-20;
	$server_height1=$it618_scoremall_store['it618_height'];$server_height2=$server_height1-20;$server_height3=$server_height1+15;
	$servertitle=$it618_scoremall_store['it618_servertitle'];
	$servercontent=$it618_scoremall_store['it618_server'];
	$it618_ptaobao=$it618_scoremall_store['it618_ptaobao'];
}else{
	$it618_scoremall_server=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_server'));
	$server_width1=$it618_scoremall_server['it618_width'];$server_width2=$server_width1-20;
	$server_height1=$it618_scoremall_server['it618_height'];$server_height2=$server_height1-20;$server_height3=$server_height1+15;
	$servertitle=$it618_scoremall_server['it618_title'];
	$servercontent=$it618_scoremall_server['it618_message'];
	$servercontent=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe width="915" height="555" src="\1" frameborder="0" allowfullscreen="1"/>',$servercontent);
	$it618_ptaobao=1;
}
	
$it618_scoremall_share=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_share'));
$share_width1=$it618_scoremall_share['it618_width'];$share_width2=$share_width1-20;
$share_height1=$it618_scoremall_share['it618_height'];$share_height2=$share_height1-20;$share_height3=$share_height1+15;

$it618_scoremall_tips=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_tips'));

$navtitle=$it618_scoremall_goods['it618_name'].' - '.$navtitle ;
$metakeywords=$it618_scoremall_goods['it618_name'].','.$metakeywords ;

$it618_mall_lang1=it618_getbuyname(it618_mall_getlang('s1'));

$it618_mall_lang29=it618_getbuyname($it618_mall_lang['t29']);
$it618_mall_lang114=it618_getbuyname($it618_mall_lang['t114']);
$it618_mall_lang116=it618_getbuyname($it618_mall_lang['t116']);
$it618_mall_lang119=it618_getbuyname($it618_mall_lang['t119']);
$it618_mall_lang120=it618_getbuyname($it618_mall_lang['t120']);
$it618_mall_lang121=it618_getbuyname($it618_mall_lang['t121']);


$it618_scoremall_help=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_help'));
$plcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_pl')." WHERE it618_pid=".$pid);
$kmcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".$pid);
if($kmcount>0)
{
	$it618_count=$kmcount;
}else{
	$it618_count=$it618_scoremall_goods['it618_count'];
}
$salecount = DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_scoremall_sale')." WHERE it618_state <>5 and it618_pid=".$pid);
if($salecount=='')$salecount=0;
DB::query("update ".DB::table('it618_scoremall_goods')." set it618_salecount=".$salecount." WHERE id=".$pid);

$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe width="915" height="555" src="\1" frameborder="0" allowfullscreen="1"/>',$it618_scoremall_goods['it618_message']);
$left_arr=explode("[it618buy",$it618_message);

if(count($left_arr)>1){
	$n=1;
	foreach($left_arr as $key => $left_arrstr){
		if($n==1){
			$tmpmessage=$left_arrstr;
		}else{
			$tmpmessage.="[it618buy".$left_arrstr;
		}
		$n=$n+1;
		
		$tmparr=explode("[/it618buy]",$left_arrstr);
		if(count($tmparr)>1){
			
			$buycount=DB::result_first('SELECT count(1) FROM '.DB::table('it618_scoremall_sale').' WHERE it618_pid='.$pid.' and it618_uid = '.$_G['uid']);
			$mall_pagebuypower=explode(",".$_G['uid'].",",",".$it618_scoremall['mall_pagebuypower'].",");
			if(count($mall_pagebuypower)>1||($it618_scoremall_goods['it618_uid']==$_G['uid']&&$_G['uid']>0)||$buycount>0){
				$tmpmessage = str_replace("[it618buy]","",$tmpmessage);
				$tmpmessage = str_replace("[/it618buy]","",$tmpmessage);
			}else{
				$flagarr=explode("][/",str_replace(" ","","[it618buy".$tmparr[0]."[/it618buy]"));
				if(count($flagarr)<=1){
					$tmpmessage = str_replace("[it618buy".$tmparr[0]."[/it618buy]",$it618_scoremall['mall_pagebuytip'],$tmpmessage);
				}else{
					$tmpmessage = str_replace("[it618buy]","",$tmpmessage);
					$tmpmessage = str_replace("[/it618buy]","",$tmpmessage);
				}
			}
			
		}
	}
	$it618_message=$tmpmessage;
}

$tmpjfname=$jfname;
if($jfname1!='')$tmpjfname=$tmpjfname.','.$jfname1;
$mall_ordertip=str_replace("{creditname}",$tmpjfname,$it618_scoremall['mall_ordertip']);

if($it618_scoremall_goods['it618_isquan']==0)$it618_isquan=$it618_mall_lang['s772'];
if($it618_scoremall_goods['it618_isquan']==1)$it618_isquan=$it618_mall_lang['s710'];
if($it618_scoremall_goods['it618_isquan']==2)$it618_isquan=$it618_mall_lang['s473'];

$timeflag=0;$isxgok=0;
if($it618_scoremall_goods['it618_xgtype']==0)$isxgok=1;

if($it618_scoremall_goods['it618_xgtype']==1){
	$timestr=$it618_scoremall_goods['it618_xgtime1'].' - '.$it618_scoremall_goods['it618_xgtime2'];
	
	$timetmp1=explode(" ",$it618_scoremall_goods['it618_xgtime1']);
	$timetmp2=explode(" ",$it618_scoremall_goods['it618_xgtime2']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);
	
	
	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
	
	$timeflag=1;
	if($etime<$_G['timestamp']){
		$timeflag=0;
		$timetip=it618_mall_getlang('s952');
	}else{
		if($btime>$_G['timestamp']){
			$timetip=it618_mall_getlang('s953');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_scoremall_goods['it618_xgtime1'];
		}else{
			$timetip=it618_mall_getlang('s954');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_scoremall_goods['it618_xgtime2'];
			$isxgok=1;
		}
	}
	
	$isxg=1;
}

if($it618_scoremall_goods['it618_xgtype']==2){
	$timetmp1=explode(" ",$it618_scoremall_goods['it618_xgtime1']);
	$timetmp2=explode(" ",$it618_scoremall_goods['it618_xgtime2']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);
	
	$timestr=$timetmp1[0].' - '.$timetmp2[0].' '.it618_mall_getlang('s955').' '.$timetmp1[1].' - '.$timetmp2[1];
	
	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
	
	$timeflag=1;
	if($etime<$_G['timestamp']){
		$timeflag=0;
		$timetip=it618_mall_getlang('s952');
		
	}else{
		if($btime>$_G['timestamp']){
			$timetip=it618_mall_getlang('s953');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_scoremall_goods['it618_xgtime1'];
		}else{
			$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
			$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
			$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
			
			if($btimecur>$_G['timestamp']){
				$timetip=it618_mall_getlang('s953');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $btimecur);
			}
			
			if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
				$timetip=it618_mall_getlang('s954');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $etimecur);
				$isxgok=1;
			}
			
			if($etimecur<$_G['timestamp']){
				$timetip=it618_mall_getlang('s953');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $btimecur1);
			}
		}
	}
	
	$isxg=1;
}

if($it618_scoremall_goods['it618_iszk']==1&&$_G['uid']>0){
	$groupid=$_G['groupid'];
	$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$groupid);
	
	$groupzk=DB::result_first("select it618_zk from ".DB::table('it618_scoremall_groupzk')." where it618_groupid=".$groupid);
}


//if($it618_scoremall['mall_isgwc']==1){
//	if($_G['uid']>0)$gwcgoodscount=DB::result_first('SELECT count(1) FROM '.DB::table('it618_scoremall_gwc').' WHERE it618_uid = '.$_G['uid']);
//}

$url_this=$_G['siteurl'].it618_scoremall_getrewrite('scoremall_wap','product@'.$pid.'@0','plugin.php?id=it618_scoremall:wap&pagetype=product&cid='.$pid);
$qrcodesrc=scoremall_qrcode($url_this);

$tmpurl1=it618_scoremall_getrewrite('home','','plugin.php?id=it618_scoremall:scoremall');
$tmpurl2=it618_scoremall_getrewrite('gwc','','plugin.php?id=it618_scoremall:gwc');
$tmpurl3=it618_scoremall_getrewrite('productlist','sid@'.$it618_storeid.'@1','plugin.php?id=it618_scoremall:scoremall_list&sid='.$it618_storeid);
$tmpurl4=it618_scoremall_getrewrite('storelist','','plugin.php?id=it618_scoremall:store_list');

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_scoremall:scoremall_page');
?>