<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/function.func.php';

$uid = $_G['uid'];
if($uid<=0){
	if($_GET['wap']!=1){
		showmessage(it618_mall_getlang('s539'), '', array(), array('alert' => 'error'));
	}else{
		echo 'it618_split'.it618_mall_getlang('s539');return;
	}
}else{
	$it618_scoremall_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".intval($_GET['pid']));
	
	if($it618_scoremall_goods['it618_isorder']==0){
		if($_GET['wap']!=1){
			showmessage(it618_mall_getlang('s540'), '', array(), array('alert' => 'error'));
		}else{
			echo 'it618_split'.it618_mall_getlang('s540');return;
		}
	}
	
	if($it618_scoremall_goods['it618_uid']>0){
		$it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_uid=".$it618_scoremall_goods['it618_uid']);
		if($it618_scoremall_store['it618_htstate']==0){
			if($_GET['wap']!=1){
			showmessage(it618_mall_getlang('s339'), '', array(), array('alert' => 'error'));
		}else{
			echo 'it618_split'.it618_mall_getlang('s339');return;
		}
		}
		if($it618_scoremall_store['it618_htstate']==2){
			if($_GET['wap']!=1){
			showmessage(it618_mall_getlang('s400'), '', array(), array('alert' => 'error'));
		}else{
			echo 'it618_split'.it618_mall_getlang('s400');return;
		}
		}
	}
	$liil1i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liil1i[]=substr($_GET['id'],$i,1);}
	$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$_G['uid']);
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_groupup')." where it618_uid=".$_G['uid']);
	if($count==""||$count==0){
		C::t('#it618_scoremall#it618_scoremall_groupup')->insert(array(
			'it618_uid' => $_G['uid'],
		), true);
	}
	if(count($liil1i)!=15)return;
	
	if($it618_scoremall_goods['it618_ison']==0||$it618_scoremall_goods['it618_state']!=2){
		if($_GET['wap']!=1){
			showmessage(it618_mall_getlang('s29'), '', array(), array('alert' => 'error'));
		}else{
			echo 'it618_split'.it618_mall_getlang('s29');return;
		}
	}
	
	if($liil1i[8]!='o')return;
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_addr')." WHERE it618_uid=".$uid." order by id desc");
	$liil1i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liil1i[]=substr($_GET['id'],$i,1);}
	$n=1;
	$iscurcount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_addr')." where it618_iscur=1 and it618_uid=".$uid);
	while($it618_scoremall_addr = DB::fetch($query)) {
		if($it618_scoremall_addr['it618_iscur']==0){
			$strtmp='';
		}else{
			$strtmp='checked="checked"';
		}
		if($iscurcount==0&&$n==1)$strtmp='checked="checked"';
		if($n%2==0){
			$strcss='<tr>';
		}else{
			$strcss='<tr class="odd">';
		}

		$liil1i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liil1i[]=substr($_GET['id'],$i,1);}
		if($liil1i[3]!='1')return;
		if($_GET['wap']!=1){
			$addr_get.=$strcss.'
					 <td><input type="radio" '.$strtmp.' name="it618_addr"/></td>
					 <td>'.$it618_scoremall_addr['it618_name'].'</td>
					 <td>'.$it618_scoremall_addr['it618_addr'].'</td>
					 <td>'.$it618_scoremall_addr['it618_yzbm'].'</td>
					 <td>'.$it618_scoremall_addr['it618_tel'].'<input type="hidden" id="it618_addrid'.($n-1).'" value="'.$it618_scoremall_addr['id'].'"/></td>
					 </tr>';
		}else{
			$addr_get.=$strcss.'
					 <td><input type="radio" '.$strtmp.' name="it618_addr"/></td>
					 <td>'.$it618_scoremall_addr['it618_name'].'</td>
					 <td>'.$it618_scoremall_addr['it618_addr'].'</td>
					 <td>'.$it618_scoremall_addr['it618_tel'].'<input type="hidden" id="it618_addrid'.($n-1).'" title="'.$it618_scoremall_addr['it618_tel'].'" value="'.$it618_scoremall_addr['id'].'"/></td>
					 </tr>';
		}
		$n=$n+1;
	}
	
	if($addr_get==""){
		$isaddr=1;
	}
}

$addrurl=it618_scoremall_getrewrite('scoremall_wap','addr@0@0','plugin.php?id=it618_scoremall:wap&pagetype=addr&cid=0');

$_G['mobiletpl'][IN_MOBILE]='/';
if($_GET['wap']!=1){
	include template('it618_scoremall:showorder');
}else{
	include template('it618_scoremall:showwaporder');
}
//From: Dism_taobao-com
?>