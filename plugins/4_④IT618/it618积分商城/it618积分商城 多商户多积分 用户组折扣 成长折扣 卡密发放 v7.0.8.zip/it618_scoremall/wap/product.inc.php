<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pid=intval($_GET['cid']);
if(!scoremall_is_mobile()){ 
	$tmpurl=it618_scoremall_getrewrite('product',$pid,'plugin.php?id=it618_scoremall:scoremall_page&pid='.$pid);
	dheader("location:$tmpurl");
}
$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE id=".$pid);

$navtitle=$it618_scoremall_goods['it618_name'].' - '.$sitetitle;

$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_htstate<>2");
while($it618_scoremall_store = DB::fetch($query)) {
	if($_G['timestamp']>=$it618_scoremall_store['it618_htetime']){
		DB::query("update ".DB::table('it618_scoremall_store')." set it618_htstate=2 where id=".$it618_scoremall_store['id']);
		DB::query("update ".DB::table('it618_scoremall_goods')." set it618_htstate=0 WHERE it618_uid=".$it618_scoremall_store['it618_uid']);
	}
}

for($i=0;$i<=4;$i++){
	if($i==0){$tmpi='';$tmpcss=' class="firstimg curimg"';}else {$tmpi=$i;$tmpcss='';}
	$it618_picbig=$it618_scoremall_goods['it618_picbig'.$tmpi];
	if($it618_picbig!=''){
		$goodspicbig.='<div class="swiper-slide"><img class="img" src="'.it618_scoremall_getgoodspic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_picbig,$i).'" /></div>';
	}
}

if($it618_scoremall_goods['it618_ison']==0||$it618_scoremall_goods['it618_state']!=2){
	echo it618_mall_getlang('s9');exit;
}

DB::query("update ".DB::table('it618_scoremall_goods')." set it618_views=it618_views+1 WHERE id=".$pid);
$kmcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".$it618_scoremall_goods['id']);
if($kmcount>0){
	DB::query("update ".DB::table('it618_scoremall_goods')." set it618_count=".$kmcount." WHERE id=".$it618_scoremall_goods['id']);
}
$plcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_pl')." WHERE it618_pid=".$pid);

$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
if($ii1ill[5]!='_')return;

$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid']]['title'];
if($it618_scoremall_goods['it618_jfid1']>0){
	$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid1']]['title'];
}
if($_G['uid']>0){
	$jfcount=DB::result_first("select extcredits".$it618_scoremall_goods['it618_jfid']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
	if($jfcount=="")$jfcount=0;
	if($it618_scoremall_goods['it618_jfid1']>0){
		$jfcount1=DB::result_first("select extcredits".$it618_scoremall_goods['it618_jfid1']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
		if($jfcount1=="")$jfcount1=0;
	}
}

$it618_message=$it618_scoremall_goods['it618_message'];
$it618_message=str_replace('type="application/x-shockwave-flash"','type="application/x-shockwave-flash" wmode="opaque"',$it618_message);
$it618_message=preg_replace('/<img.+?src=\"(.+?)\".+?>/','<img src="\1"/>',$it618_message);
$it618_message=preg_replace('/<table.+?>/','<table cellspacing="0" cellpadding="0" width="100%">',$it618_message);
$it618_message=preg_replace('/<iframe.+?src=\"(.+?)\".+?>/','<iframe src="\1" width="640" height="200" frameborder="0" allowfullscreen="1">',$it618_message);
$left_arr=explode("[it618buy",$it618_message);

if(count($left_arr)>1){
	$n=1;
	foreach($left_arr as $key => $left_arrstr){
		if($n==1){
			$tmpmessage=$left_arrstr;
		}else{
			$tmpmessage.="[it618buy".$left_arrstr;
		}
		$n=$n+1;
		
		$tmparr=explode("[/it618buy]",$left_arrstr);
		if(count($tmparr)>1){
			
			$buycount=DB::result_first('SELECT count(1) FROM '.DB::table('it618_scoremall_sale').' WHERE it618_pid='.$pid.' and it618_uid = '.$_G['uid']);
			$mall_pagebuypower=explode(",".$_G['uid'].",",",".$it618_scoremall['mall_pagebuypower'].",");
			if(count($mall_pagebuypower)>1||($it618_scoremall_goods['it618_uid']==$_G['uid']&&$_G['uid']>0)||$buycount>0){
				$tmpmessage = str_replace("[it618buy]","",$tmpmessage);
				$tmpmessage = str_replace("[/it618buy]","",$tmpmessage);
			}else{
				$flagarr=explode("][/",str_replace(" ","","[it618buy".$tmparr[0]."[/it618buy]"));
				if(count($flagarr)<=1){
					$tmpmessage = str_replace("[it618buy".$tmparr[0]."[/it618buy]",$it618_scoremall['mall_pagebuytip'],$tmpmessage);
				}else{
					$tmpmessage = str_replace("[it618buy]","",$tmpmessage);
					$tmpmessage = str_replace("[/it618buy]","",$tmpmessage);
				}
			}
			
		}
	}
	$it618_message=$tmpmessage;
}

if($it618_scoremall_goods['it618_isquan']==0)$it618_isquan=$it618_mall_lang['s772'];
if($it618_scoremall_goods['it618_isquan']==1)$it618_isquan=$it618_mall_lang['s710'];
if($it618_scoremall_goods['it618_isquan']==2)$it618_isquan=$it618_mall_lang['s473'];

$timeflag=0;$isxgok=0;
if($it618_scoremall_goods['it618_xgtype']==0)$isxgok=1;

if($it618_scoremall_goods['it618_xgtype']==1){
	$timestr=$it618_scoremall_goods['it618_xgtime1'].' - '.$it618_scoremall_goods['it618_xgtime2'];
	
	$timetmp1=explode(" ",$it618_scoremall_goods['it618_xgtime1']);
	$timetmp2=explode(" ",$it618_scoremall_goods['it618_xgtime2']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);
	
	
	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
	
	$timeflag=1;
	if($etime<$_G['timestamp']){
		$timeflag=0;
		$timetip=it618_mall_getlang('s952');
	}else{
		if($btime>$_G['timestamp']){
			$timetip=it618_mall_getlang('s953');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_scoremall_goods['it618_xgtime1'];
		}else{
			$timetip=it618_mall_getlang('s954');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_scoremall_goods['it618_xgtime2'];
			$isxgok=1;
		}
	}
	
	$isxg=1;
}

if($it618_scoremall_goods['it618_xgtype']==2){
	$timetmp1=explode(" ",$it618_scoremall_goods['it618_xgtime1']);
	$timetmp2=explode(" ",$it618_scoremall_goods['it618_xgtime2']);
	$timetmp11=explode("-",$timetmp1[0]);
	$timetmp12=explode(":",$timetmp1[1]);
	$timetmp21=explode("-",$timetmp2[0]);
	$timetmp22=explode(":",$timetmp2[1]);
	
	$timestr=$timetmp1[0].' - '.$timetmp2[0].' '.it618_mall_getlang('s955').' '.$timetmp1[1].' - '.$timetmp2[1];
	
	$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
	$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
	
	$timeflag=1;
	if($etime<$_G['timestamp']){
		$timeflag=0;
		$timetip=it618_mall_getlang('s952');
		
	}else{
		if($btime>$_G['timestamp']){
			$timetip=it618_mall_getlang('s953');
			$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
			$etimestr=$it618_scoremall_goods['it618_xgtime1'];
		}else{
			$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
			$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
			$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
			
			if($btimecur>$_G['timestamp']){
				$timetip=it618_mall_getlang('s953');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $btimecur);
			}
			
			if($btimecur<$_G['timestamp']&&$etimecur>$_G['timestamp']){
				$timetip=it618_mall_getlang('s954');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $etimecur);
				$isxgok=1;
			}
			
			if($etimecur<$_G['timestamp']){
				$timetip=it618_mall_getlang('s953');
				$btimestr=date('Y-m-d H:i:s', $_G['timestamp']);
				$etimestr=date('Y-m-d H:i:s', $btimecur1);
			}
		}
	}
	
	$isxg=1;
}

if($it618_scoremall_goods['it618_iszk']==1&&$_G['uid']>0){
	$groupid=$_G['groupid'];
	$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$groupid);
	
	$groupzk=DB::result_first("select it618_zk from ".DB::table('it618_scoremall_groupzk')." where it618_groupid=".$groupid);
}

if($IsCredits==1){
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$creditsurl=it618_credits_getrewriteapi('credits_wap','recharge','plugin.php?id=it618_credits:wap&dotype=recharge');
}

$idforly=$pid;
$wap=1;

$buyurl=it618_scoremall_getrewrite('scoremall_wap','buy@'.$it618_scoremall_goods['id'].'@0','plugin.php?id=it618_scoremall:wap&pagetype=buy&cid='.$it618_scoremall_goods['id']);
$orderurl=it618_scoremall_getrewrite('scoremall_wap','order@'.$it618_scoremall_goods['id'].'@0','plugin.php?id=it618_scoremall:wap&pagetype=order&cid='.$it618_scoremall_goods['id']);

$bottommenu=C::t('#it618_scoremall#it618_scoremall_bottomnav')->fetch_by_id(1);

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_scoremall:wap_scoremall');
?>