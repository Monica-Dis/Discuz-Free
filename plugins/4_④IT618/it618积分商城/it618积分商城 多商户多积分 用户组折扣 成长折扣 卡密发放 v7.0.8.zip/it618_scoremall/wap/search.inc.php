<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$cid=intval($_GET['cid']);
if(!scoremall_is_mobile()){ 
	if($cid>0){
		$tmpurl=it618_scoremall_getrewrite('scoremall_list',$cid,'plugin.php?id=it618_scoremall:list&class1='.$cid);
	}else{
		$tmpurl=it618_scoremall_getrewrite('scoremall_list','','plugin.php?id=it618_scoremall:list');
	}
	dheader("location:$tmpurl");
}

$navtitle=$it618_mall_lang['t260'].' - '.$sitetitle;

$n=1;
$classflag=0;
$count1=DB::result_first("select count(1) from ".DB::table('it618_scoremall_class1'));
$count2=DB::result_first("select count(1) from ".DB::table('it618_scoremall_class2'));
$classtmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'productclass1\',0,0)" name="productclass1"><span>'.$it618_mall_lang['t272'].'</span><i></i></a>';
if($count1==1&&$count2==1){
	$query3 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." ORDER BY it618_order desc");
	while($it618_scoremall_class3 = DB::fetch($query3)) {
		$classtmp.='<a href="javascript:void(0)" onclick="setselect(\'productclass1\','.$n.','.$it618_scoremall_class3['id'].')" name="productclass1"><span>'.$it618_scoremall_class3['it618_classname'].'</span><i></i></a>';
		$n=$n+1;
	}
}else{
	$classflag=1;
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class2')." ORDER BY it618_order desc");
	while($it618_scoremall_class2 = DB::fetch($query2)) {
		$classtmp.='<a href="javascript:void(0)" onclick="setselect(\'productclass1\','.$n.','.$it618_scoremall_class2['id'].')" name="productclass1"><span>'.$it618_scoremall_class2['it618_classname'].'</span><i></i></a>';
		$n=$n+1;
	}
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_scoremall:wap_scoremall');
?>