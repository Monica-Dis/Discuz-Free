<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!scoremall_is_mobile()){ 
	$tmpurl=it618_scoremall_getrewrite('home','','plugin.php?id=it618_scoremall:scoremall');
	dheader("location:$tmpurl");
}

$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_wapfocus')." WHERE it618_order>0 ORDER BY it618_order DESC");
$i1ii1=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$i1ii1[]=substr($_GET['id'],$i,1);}
while($it618_scoremall_wapfocus = DB::fetch($query)) {
	if($it618_scoremall_wapfocus['it618_url']!=''){
		$str_focus.='<div class="swiper-slide"><a href="'.$it618_scoremall_wapfocus['it618_url'].'" target="_blank"><img class="img" src="'.it618_scoremall_getwapppic('wapad',$it618_scoremall_wapfocus['id'],$it618_scoremall_wapfocus['it618_img']).'"/></a></div>';
	}else{
		$str_focus.='<div class="swiper-slide"><img class="img" src="'.it618_scoremall_getwapppic('wapad',$it618_scoremall_wapfocus['id'],$it618_scoremall_wapfocus['it618_img']).'" /></div>';
	}
}

$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_gonggao')." where it618_order<>0 ORDER BY it618_order");
while($it618_scoremall_gonggao = DB::fetch($query)) {
	$it618_title=$it618_scoremall_gonggao['it618_title'];
	$it618_title=cutstr($it618_title,62,'...');
	
	if($it618_scoremall_gonggao['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_scoremall_gonggao['it618_color']!=''){
		$it618_title='<font color="'.$it618_scoremall_gonggao['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$str_gonggao.='<div class="swiper-slide"><a href='.$it618_scoremall_gonggao['it618_url'].'>'.$it618_title.'</a></div>';
}

$n=1;
$str_iconav='<div class="swiper-slide" style="padding-top:8px; background-color:#fff"><table class="iconav"><tr>';
$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_iconav')." where it618_order<>0 ORDER BY it618_order");
while($it618_scoremall_iconav = DB::fetch($query)) {
	$it618_title=$it618_scoremall_iconav['it618_title'];
	
	if($it618_scoremall_iconav['it618_target']==1){
		$it618_target=' target="_blank"';
	}else{
		$it618_target='';
	}
	
	if($it618_scoremall_iconav['it618_isbold']==1){
		$it618_title='<b>'.$it618_title.'</b>';
	}
	
	if($it618_scoremall_iconav['it618_color']!=''){
		$it618_title='<font color="'.$it618_scoremall_iconav['it618_color'].'">'.$it618_title.'</font>';
	}
	
	$it618_url=$it618_scoremall_iconav['it618_url'];
	
	$str_iconav.='<td width="20%"><a href="'.$it618_url.'"'.$it618_target.'><img src="'.$it618_scoremall_iconav['it618_img'].'"/><br>'.$it618_title.'</a></td>';
	
	if($n%10==0)$str_iconav.='</table></div><div class="swiper-slide" style="padding-top:8px; background-color:#fff"><table class="iconav">';
	if($n%5==0)$str_iconav.='</tr><tr>';
	
	$isiconav=1;

	$n=$n+1;
}

$iconavcount=$n-1;

for($i=1;$i<=$n%5;$i++){
	$str_iconav.='<td width="20%"></td>';
}
$str_iconav.='</tr>';
$str_iconav=str_replace('<tr><td width="20%"></td></tr>','',$str_iconav);
$str_iconav.='</table></div>';
$str_iconav=str_replace('<div class="swiper-slide" style="padding-top:8px; background-color:#fff"><table class="iconav"></tr></table></div>','',$str_iconav);

$zjsalegoods=C::t('#it618_scoremall#it618_scoremall_set')->getsetvalue_by_setname('zjsalegoods');
$weeksalegoods=C::t('#it618_scoremall#it618_scoremall_set')->getsetvalue_by_setname('weeksalegoods');
$newgoods=C::t('#it618_scoremall#it618_scoremall_set')->getsetvalue_by_setname('newgoods');
$hotgoods=C::t('#it618_scoremall#it618_scoremall_set')->getsetvalue_by_setname('hotgoods');
$waphomead=DB::result_first("SELECT it618_message FROM ".DB::table('it618_scoremall_waphomead'));

$tmparr=explode(",",$zjsalegoods);
if(count($tmparr)>1){
	$zjsalegoods_count=$tmparr[0];
	$zjsalegoods_order=$tmparr[1];
}else{
	$zjsalegoods_count=8;
	$zjsalegoods_order=1;
}

$tmparr=explode(",",$weeksalegoods);
if(count($tmparr)>1){
	$weeksalegoods_count=$tmparr[0];
	$weeksalegoods_order=$tmparr[1];
}else{
	$weeksalegoods_count=8;
	$weeksalegoods_order=2;
}

$tmparr=explode(",",$newgoods);
if(count($tmparr)>1){
	$newgoods_count=$tmparr[0];
	$newgoods_order=$tmparr[1];
}else{
	$newgoods_count=8;
	$newgoods_order=3;
}

$tmparr=explode(",",$hotgoods);
if(count($tmparr)>1){
	$hotgoods_count=$tmparr[0];
	$hotgoods_order=$tmparr[1];
}else{
	$hotgoods_count=8;
	$hotgoods_order=4;
}

$homegoods_arr=array("zjsalegoods"=>$zjsalegoods_order,"weeksalegoods"=>$weeksalegoods_order,"newgoods"=>$newgoods_order,"hotgoods"=>$hotgoods_order);
asort($homegoods_arr);

$n=1;
foreach($homegoods_arr as $key=>$homegoods){
	if($n==1)$current=' class="current" ';else $current=' ';
	if($home_goods_js=='')$home_goods_js='get_home_goods("'.$key.'");';
	if($key=='zjsalegoods'){
		$tab_goods.='<li'.$current.'onclick="it618_scoremall_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_mall_lang['s987'].'</li>';
	}
	
	if($key=='weeksalegoods'){
		$tab_goods.='<li'.$current.'onclick="it618_scoremall_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_mall_lang['s988'].'</li>';
	}
	
	if($key=='newgoods'){
		$tab_goods.='<li'.$current.'onclick="it618_scoremall_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_mall_lang['s989'].'</li>';
	}
	
	if($key=='hotgoods'){
		$tab_goods.='<li'.$current.'onclick="it618_scoremall_tabChange(this,\'searchli_bd\');get_home_goods(\''.$key.'\');">'.$it618_mall_lang['s990'].'</li>';
	}
	
	if($n==1)$bdstyle=' ;display:';else $bdstyle=' ;display:none';
	$home_goods.='<dl class="list" id="searchli_bd'.($n-1).'" style="border-top:none; margin:0;'.$bdstyle.'">
					<dd><dl style="padding:0">
						<dd>
						<div style="-webkit-overflow-scrolling:touch;overflow:scroll;">
						<table class="tablelist3" id="home_goods_'.$key.'"></table>
						</div>
						</dd>
					</dl></dd>
				  </dl>';
	
	$n=$n+1;
}

$homegoods_str='<ul class="searchli1">'.$tab_goods.'</ul><div id="home_goods">'.$home_goods.'</div><script>'.$home_goods_js.'</script>';

for($i=1;$i<=3;$i++){
	$querytmp = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class'.$i)." where it618_homewapcount<>0 ORDER BY it618_order");
	while($it618_scoremall_class = DB::fetch($querytmp)) {
		$strgoodtmp=getgoodsbyclass($i,$it618_scoremall_class['id'],$it618_scoremall_class['it618_classname'],$it618_scoremall_class['it618_homewapcount'],$it618_scoremall_class['it618_homeordertype']);
		if($strgoodtmp!=''){
			$str_goods.=$strgoodtmp;
		}
	}
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/ordergoods.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/ordergoods.php';
}
if($is_ordergoodsok==1){
	$tmpordergoodscount=0;
	if($ordergoods_order==1)$jforder='id desc';
	if($ordergoods_order==2)$jforder='it618_salecount desc';
	if($ordergoods_order==3)$jforder='it618_views desc';
	
	$tdn=1;
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 and it618_uid>0 ORDER BY it618_jforder desc,it618_uid,".$jforder);
	while($it618_scoremall_goods = DB::fetch($query)) {
		if($tmpuid!=$it618_scoremall_goods['it618_uid']){
			$tmpuid=$it618_scoremall_goods['it618_uid'];

			$it618_count=$it618_scoremall_goods['it618_count'];
			
			$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid']]['title'];
			$it618_score1='';
			if($it618_scoremall_goods['it618_jfid1']>0){
				$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid1']]['title'];
				$it618_score1='+<font style="font-size:13px">'.$it618_scoremall_goods['it618_score1'].'</font>'.$jfname1.'';
			}
			
			$tmpurl=it618_scoremall_getrewrite('scoremall_wap','product@'.$it618_scoremall_goods['id'].'@0','plugin.php?id=it618_scoremall:wap&pagetype=product&cid='.$it618_scoremall_goods['id']);
			
			if($tdn%2>0){
				$trtmpstr1='<tr class="trimg">';
				$trtmpstr2='<tr class="trabout">';
				$tdstr='class="tdleft"';
			}else{
				$tdstr='class="tdright"';
			}
			
			$trtmpstr1.='<td '.$tdstr.'><a href="'.$tmpurl.'">
							<img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'"/>
						</a></td>';
			
			$trtmpstr2.='<td '.$tdstr.'><a href="'.$tmpurl.'" class="react">
						<div class="tdname">'.$it618_scoremall_goods['it618_name'].'</div>
						<div class="tdabout"><span style="float:right">'.it618_mall_getlang('s627').':'.$it618_scoremall_goods['it618_salecount'].'</span>'.it618_mall_getlang('s5').':'.$it618_count.' '.it618_mall_getlang('s625').':'.$it618_scoremall_goods['it618_views'].'</div>
						<div class="tdprice" style="color:red"><font style="font-size:13px">'.$it618_scoremall_goods['it618_score'].'</font>'.$jfname.''.$it618_score1.'</div>
					</a></td>';
						
			if($tdn%2==0){
				$trtmpstr1.='</tr>';
				$trtmpstr2.='</tr>';
				$home_goodstmp.=$trtmpstr1.$trtmpstr2;
			}
			
			$tdn=$tdn+1;
		}
	}
		
	$trtmpstr=$trtmpstr1.'@@@';
	$tmparr=explode('</td>@@@',$trtmpstr);
	if(count($tmparr)>1){
		$trtmpstr1.='</tr>';
		$trtmpstr2.='</tr>';
		$home_goodstmp.=$trtmpstr1.$trtmpstr2;
	}
	
	$wapsearch=it618_scoremall_getrewrite('scoremall_wap','search@0@0','plugin.php?id=it618_scoremall:wap&pagetype=search');
	$str_jfordergoods.='<dl class="list">
				<dd><dl style="padding:0">
					<dt style="text-align:center;font-weight:bold;padding-left:0; padding-right:0; background:url(source/plugin/it618_scoremall/wap/images/dtbd.png) no-repeat center">'.$ordergoods_title.'</dt>
					<dd>
					<table width="100%" class="tablelist">
						'.$home_goodstmp.'
					</table>
					</dd>
				</dl></dd>
			</dl>';
}
		

function getgoodsbyclass($classtype,$classid,$classname,$count,$ordertype){
	global $_G,$it618_mall;
	$tdn=1;
	if($classtype==1){
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class2')." where it618_class1_id=".$classid." ORDER BY it618_order desc");
		while($it618_scoremall_class2 = DB::fetch($query2)) {
			$query3 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." where it618_class2_id=".$it618_scoremall_class2['id']." ORDER BY it618_order desc");
			while($it618_scoremall_class3 = DB::fetch($query3)) {
				$rightclassid.=$it618_scoremall_class3['id'].',';
			}
		}
		$rightclassid=$rightclassid.'0';
	}elseif($classtype==2){
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." where it618_class2_id=".$classid." ORDER BY it618_order desc");
		while($it618_scoremall_class3 = DB::fetch($query2)) {
			$rightclassid.=$it618_scoremall_class3['id'].',';
		}
		$rightclassid=$rightclassid.'0';
	}else{
		$rightclassid=$classid;
	}
	
	if($rightclassid!=''){
		if($ordertype==1)$rightsql='ORDER BY id desc';
		if($ordertype==2)$rightsql='ORDER BY it618_salecount desc';
		if($ordertype==3)$rightsql='and it618_istj=1 ORDER BY id desc';
		if($ordertype==4)$rightsql='and it618_istj=1 ORDER BY it618_salecount desc';
		if($ordertype==5)$rightsql='ORDER BY it618_count desc';
		if($ordertype==6)$rightsql='and it618_istj=1 ORDER BY it618_count desc';
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 and it618_class3_id in($rightclassid) $rightsql limit 0,".$count);
		while($it618_scoremall_goods = DB::fetch($query)) {

			$it618_count=$it618_scoremall_goods['it618_count'];
			
			$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid']]['title'];
			$it618_score1='';
			if($it618_scoremall_goods['it618_jfid1']>0){
				$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid1']]['title'];
				$it618_score1='+<font style="font-size:13px">'.$it618_scoremall_goods['it618_score1'].'</font>'.$jfname1.'';
			}
			
			$tmpurl=it618_scoremall_getrewrite('scoremall_wap','product@'.$it618_scoremall_goods['id'].'@0','plugin.php?id=it618_scoremall:wap&pagetype=product&cid='.$it618_scoremall_goods['id']);
			
			if($tdn%2>0){
				$trtmpstr1='<tr class="trimg">';
				$trtmpstr2='<tr class="trabout">';
				$tdstr='class="tdleft"';
			}else{
				$tdstr='class="tdright"';
			}
			
			$trtmpstr1.='<td '.$tdstr.'><a href="'.$tmpurl.'">
							<img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'"/>
						</a></td>';
			
			$trtmpstr2.='<td '.$tdstr.'><a href="'.$tmpurl.'" class="react">
						<div class="tdname">'.$it618_scoremall_goods['it618_name'].'</div>
						<div class="tdabout"><span style="float:right">'.it618_mall_getlang('s627').':'.$it618_scoremall_goods['it618_salecount'].'</span>'.it618_mall_getlang('s5').':'.$it618_count.' '.it618_mall_getlang('s625').':'.$it618_scoremall_goods['it618_views'].'</div>
						<div class="tdprice" style="color:red"><font style="font-size:13px">'.$it618_scoremall_goods['it618_score'].'</font>'.$jfname.''.$it618_score1.'</div>
					</a></td>';
						
			if($tdn%2==0){
				$trtmpstr1.='</tr>';
				$trtmpstr2.='</tr>';
				$home_goodstmp.=$trtmpstr1.$trtmpstr2;
			}
			
			$tdn=$tdn+1;
		}
		
		$trtmpstr=$trtmpstr1.'@@@';
		$tmparr=explode('</td>@@@',$trtmpstr);
		if(count($tmparr)>1){
			$trtmpstr1.='</tr>';
			$trtmpstr2.='</tr>';
			$home_goodstmp.=$trtmpstr1.$trtmpstr2;
		}
	}

	$wapsearch=it618_scoremall_getrewrite('scoremall_wap','search@0@0','plugin.php?id=it618_scoremall:wap&pagetype=search');
	$str_goods.='<dl class="list">
					<dd><dl style="padding:0">
						<dt style="text-align:center;font-weight:bold;padding-left:0; padding-right:0; background:url(source/plugin/it618_scoremall/wap/images/dtbd.png) no-repeat center">'.$classname.$it618_mall_lang['s995'].'</dt>
						<dd>
						<table width="100%" class="tablelist">
							'.$home_goodstmp.'
						</table>
						</dd>
					</dl></dd>
				</dl>';
	
	return $str_goods;

}

$idforly=0;$wap=1;

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_scoremall:wap_scoremall');
?>