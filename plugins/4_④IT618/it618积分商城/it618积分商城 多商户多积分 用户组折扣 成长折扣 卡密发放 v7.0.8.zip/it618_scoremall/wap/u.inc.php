<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($it618_scoremall['scoremall_computer']==1){
	if(!scoremall_is_mobile()){
		dheader("location:$scoremall_home");
	}
}

$navtitle=it618_mall_getlang('t326').' - '.$sitetitle;

if($_G['uid']<=0){
	$tmpurl=it618_scoremall_getrewrite('scoremall_wap','','plugin.php?id=it618_scoremall:wap');
	dheader("location:$tmpurl");
}

$menuusername=$_G['username'];
$u_avatarimg=it618_scoremall_discuz_uc_avatar($_G['uid'],'middle');

if($IsCredits==1){
	$it618_money=C::t('#it618_credits#it618_credits_uset')->fetch_money_by_uid($_G['uid']);
	require_once DISCUZ_ROOT.'./source/plugin/it618_credits/credits.func.php';
	$creditsurl=it618_credits_getrewriteapi('credits_wap','uc','plugin.php?id=it618_credits:wap&dotype=uc');
}

$ucurl=it618_scoremall_getrewrite('scoremall_wap','uc@'.$_G['uid'].'@0','plugin.php?id=it618_scoremall:wap&pagetype=uc');
$quanurl=it618_scoremall_getrewrite('scoremall_wap','quan@'.$_G['uid'].'@0','plugin.php?id=it618_scoremall:wap&pagetype=quan');
$addrurl=it618_scoremall_getrewrite('scoremall_wap','addr@0@0','plugin.php?id=it618_scoremall:wap&pagetype=addr&cid=0');

$uccount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_sale')." where it618_uid=".$_G['uid']);
$quancount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_quan')." where it618_useuid=".$_G['uid']);
$addrcount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_addr')." where it618_uid=".$_G['uid']);

$it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_htstate<>0 and it618_htstate<>2 and it618_uid=".$_G['uid']);
if($_G['uid']==$it618_scoremall_store['it618_uid']){
	$scurl=it618_scoremall_getrewrite('scoremall_wap','sc@'.$it618_scoremall_store['id'].'@0','plugin.php?id=it618_scoremall:wap&pagetype=sc&cid='.$it618_scoremall_store['id']);
	$ishop=1;
	$shopcount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_sale')." where it618_saleuid=".$_G['uid']);
}
if($_G['uid']==$it618_scoremall['mall_wapsaleUID']){
	$adminurl=it618_scoremall_getrewrite('scoremall_wap','sc@0@0','plugin.php?id=it618_scoremall:wap&pagetype=sc&cid=0');
	$isadmin=1;
	$admincount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_sale'));
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_scoremall:wap_scoremall');
?>