<?php
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_focus')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_wapfocus')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_server')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_share')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_tips')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_help')."");

DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_level')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_groupup')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_groupuplog')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_addr')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_class1')."");

DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_class2')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_class3')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_goods')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_goods_km')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_sale')."");

DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_store')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_store_level')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_store_groupup')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_store_groupuplog')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_pl')."");

DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_kd')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_kmpower')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_salework')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_diy')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_gwc')."");

DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_message')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_goods_salekm')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_order')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('it618_scoremall_quan')."");

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>