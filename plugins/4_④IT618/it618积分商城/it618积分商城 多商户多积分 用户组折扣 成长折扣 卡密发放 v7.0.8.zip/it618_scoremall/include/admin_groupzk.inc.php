<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if(submitcheck('it618submit')){

	if(is_array($_GET['it618_zk'])) {
		foreach($_GET['it618_zk'] as $id => $val) {
			
				C::t('#it618_scoremall#it618_scoremall_groupzk')->update($id,array(
					'it618_zk' => floatval($_GET['it618_zk'][$id])
				));
		}
	}

	cpmsg($it618_mall_lang['s1131'], "action=plugins&identifier=$identifier&cp=admin_groupzk&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1", 'succeed');
}

if(count($reabc)!=15)return;
if(submitcheck('it618daosubmit')) {
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup'));
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_groupzk')." WHERE it618_groupid=".$common_usergroup[groupid])==0){
			C::t('#it618_scoremall#it618_scoremall_groupzk')->insert(array(
				'it618_groupid' => $common_usergroup[groupid],
				'it618_zk' => 100,
			), true);
		}
	}
}

if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_groupzk'))==0){
	$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup'));
	while($common_usergroup =	DB::fetch($query)) {
		if(DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_groupzk')." WHERE it618_groupid=".$common_usergroup[groupid])==0){
			C::t('#it618_scoremall#it618_scoremall_groupzk')->insert(array(
				'it618_groupid' => $common_usergroup[groupid],
				'it618_zk' => 100,
			), true);
		}
	}	
}

showformheader("plugins&identifier=$identifier&cp=admin_groupzk&pmod=admin_set&operation=$operation&do=$do&cp1=$cp1");

showtableheaders($strtmptitle[$cp1],'it618_scoremall_groupzk');
	showsubmit('it618daosubmit', $it618_mall_lang['s1125']);
	if($reabc[5]!='_')return;
	
	$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_groupzk'));
	echo '<tr><td colspan=4>'.$it618_mall_lang['s1126'].$count.'<span style="float:right;color:red">'.$it618_mall_lang['s1127'].'</span></td></tr>';

	showsubtitle(array($it618_mall_lang['s1128'],$it618_mall_lang['s1129']));

	$query = DB::query("SELECT p.id,g.groupid,g.grouptitle,p.it618_zk FROM ".DB::table('it618_scoremall_groupzk')." p,".DB::table('common_usergroup')." g WHERE p.it618_groupid=g.groupid");
	while($it618_scoremall_groupzk =	DB::fetch($query)) {
		
		if($reabc[1]!='t')return;
		showtablerow('', array('class="td28"', '', ''), array(
			$it618_scoremall_groupzk[grouptitle]."<input type=\"hidden\" name=\"id[$it618_scoremall_groupzk[id]]\" value=\"$it618_scoremall_groupzk[id]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:100px\" name=\"it618_zk[$it618_scoremall_groupzk[id]]\" value=\"$it618_scoremall_groupzk[it618_zk]\">%",
		));
	}
	showsubmit('it618submit', $it618_mall_lang['s1130']);
	showtablefooter();/*Dism��taobao��com*/
?>