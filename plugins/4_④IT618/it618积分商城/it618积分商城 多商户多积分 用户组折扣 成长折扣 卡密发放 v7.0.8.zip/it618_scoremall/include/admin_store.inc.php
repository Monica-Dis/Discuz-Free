<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if($_GET['key']) {
	$extrasql .= " AND it618_name LIKE '%".addcslashes(addslashes($_GET['key']),'%_')."%'";
}

if($_GET['state']) {
	$state0='';$state1='';$state2='';$state3='';$state4='';
	if($_GET['state']==0){$extrasql .= "";$state0='selected="selected"';}
	if($_GET['state']==1){$extrasql .= " AND it618_state = 0";$state1='selected="selected"';}
	if($_GET['state']==2){$extrasql .= " AND it618_state = 1";$state2='selected="selected"';}
	if($_GET['state']==3){$extrasql .= " AND it618_state = 2";$state3='selected="selected"';}
}

if($_GET['htstate']) {
	$htstate0='';$htstate1='';$htstate2='';$htstate3='';$htstate4='';
	if($_GET['htstate']==0){$extrasql .= "";$htstate0='selected="selected"';}
	if($_GET['htstate']==1){$extrasql .= " AND it618_htstate = 0";$htstate1='selected="selected"';}
	if($_GET['htstate']==2){$extrasql .= " AND it618_htstate = 1";$htstate2='selected="selected"';}
	if($_GET['htstate']==3){$extrasql .= " AND it618_htstate = 2";$htstate3='selected="selected"';}
}

$sql='&key='.$_GET['key'].'&state='.$_GET['state'].'&htstate='.$_GET['htstate'];

$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_htstate<>2");
while($it618_scoremall_store = DB::fetch($query)) {
	if($_G['timestamp']>=$it618_scoremall_store['it618_htetime']){
		DB::query("update ".DB::table('it618_scoremall_store')." set it618_htstate=2 where id=".$it618_scoremall_store['id']);
		DB::query("update ".DB::table('it618_scoremall_goods')." set it618_htstate=0 WHERE it618_uid=".$it618_scoremall_store['it618_uid']);
	}
}

if(submitcheck('it618submit_del')){
	$del=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." where id=".$delid);
		if($it618_scoremall_store['it618_state']!=2){
			
			DB::delete('it618_scoremall_store', "id=$delid");
			$del=$del+1;
		}
	}

	cpmsg($it618_mall_lang['s295'].$del, "action=plugins&identifier=$identifier&cp=admin_store&pmod=admin_store&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_edit')){
	$ok=0;
	if($reabc[8]!='o')return;
	foreach($_GET['it618_pprice'] as $id => $val) {
		$delid=intval($delid);

		C::t('#it618_scoremall#it618_scoremall_store')->update($id,array(
			'it618_pprice' => $_GET['it618_pprice'][$id],
			'it618_pcount' => $_GET['it618_pcount'][$id],
			'it618_ptaobao' => $_GET['it618_ptaobao'][$id]
		));	
		$ok=$ok+1;
	}

	cpmsg($it618_mall_lang['s647'].$ok, "action=plugins&identifier=$identifier&cp=admin_store&pmod=admin_store&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_pass')){
	$ok=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." where id=".$delid);
		$tomonth = date('n'); 
		$todate = date('j'); 
		$toyear = date('Y');
		$it618_htetime=mktime(0, 0, 0, $tomonth+$it618_scoremall['mall_httimecount'], $todate, $toyear);
		if($it618_scoremall_store['it618_state']==0){
			DB::query("update ".DB::table('it618_scoremall_store')." set it618_state=2,it618_htstate=1,it618_htetime=".$it618_htetime." WHERE id=".$delid);
			C::t('#it618_scoremall#it618_scoremall_store_groupup')->insert(array(
				'it618_uid' => $it618_scoremall_store['it618_uid'],
			), true);
			$ok=$ok+1;
		}
	}
	
	cpmsg($it618_mall_lang['s296'].$ok, "action=plugins&identifier=$identifier&cp=admin_store&pmod=admin_store&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_nopass')){
	$ok=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_scoremall_store = DB::fetch_first("SELECT it618_state FROM ".DB::table('it618_scoremall_store')." where id=".$delid);
		
		if($it618_scoremall_store['it618_state']==0){
			DB::query("update ".DB::table('it618_scoremall_store')." set it618_state=1 WHERE id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_mall_lang['s297'].$ok, "action=plugins&identifier=$identifier&cp=admin_store&pmod=admin_store&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_editht')){
	$ok=0;
	if($reabc[8]!='o')return;
	$time=mktime(0, 0, 0, $_GET['sel_month'], $_GET['sel_date'], $_GET['sel_year']);
	if($_G['timestamp']>=$time){
		cpmsg($it618_mall_lang['s367'], "action=plugins&identifier=$identifier&cp=admin_store&pmod=admin_store&operation=$operation&do=$do&page=$page".$sql, 'succeed');
	}
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." where id=".$delid);
		
		if($it618_scoremall_store['it618_state']==2){
			DB::query("update ".DB::table('it618_scoremall_store')." set it618_htstate=1,it618_htetime=".$time." WHERE id=".$delid);
			DB::query("update ".DB::table('it618_scoremall_goods')." set it618_htstate=1 WHERE it618_uid=".$it618_scoremall_store['it618_uid']);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_mall_lang['s368'].$ok, "action=plugins&identifier=$identifier&cp=admin_store&pmod=admin_store&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_clock')){
	$ok=0;
	if($reabc[8]!='o')return;

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." where id=".$delid);
		
		if($it618_scoremall_store['it618_state']==2){
			DB::query("update ".DB::table('it618_scoremall_store')." set it618_htstate=0 WHERE id=".$delid);
			DB::query("update ".DB::table('it618_scoremall_goods')." set it618_htstate=0 WHERE it618_uid=".$it618_scoremall_store['it618_uid']);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_mall_lang['s369'].$ok, "action=plugins&identifier=$identifier&cp=admin_store&pmod=admin_store&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_unclock')){
	$ok=0;
	if($reabc[8]!='o')return;

	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." where id=".$delid);
		
		if($it618_scoremall_store['it618_state']==2){
			DB::query("update ".DB::table('it618_scoremall_store')." set it618_htstate=1 WHERE id=".$delid);
			DB::query("update ".DB::table('it618_scoremall_goods')." set it618_htstate=1 WHERE it618_uid=".$it618_scoremall_store['it618_uid']);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_mall_lang['s370'].$ok, "action=plugins&identifier=$identifier&cp=admin_store&pmod=admin_store&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=15)return;

echo '
<link rel="stylesheet" href="source/plugin/it618_scoremall/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_scoremall/kindeditor/kindeditor-min.js"></script>
';

showformheader("plugins&identifier=$identifier&cp=admin_store&pmod=admin_store&operation=$operation&do=$do");
showtableheaders($it618_mall_lang['s298'],'it618_store_renzheng');
	showsubmit('it618sercsubmit', $it618_mall_lang['s299'], $it618_mall_lang['s300'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.$it618_mall_lang['s301'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> '.$it618_mall_lang['s302'].' <select name="state"><option value=0 '.$state0.'>'.$it618_mall_lang['s303'].'</option><option value=1 '.$state1.'>'.$it618_mall_lang['s304'].'</option><option value=2 '.$state2.'>'.$it618_mall_lang['s305'].'</option><option value=3 '.$state3.'>'.$it618_mall_lang['s306'].'</option></select> '.$it618_mall_lang['s371'].' <select name="htstate"><option value=0 '.$htstate0.'>'.$it618_mall_lang['s303'].'</option><option value=1 '.$htstate1.'>'.$it618_mall_lang['s372'].'</option><option value=2 '.$htstate2.'>'.$it618_mall_lang['s373'].'</option><option value=3 '.$htstate3.'>'.$it618_mall_lang['s374'].'</option></select>');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_store')." WHERE 1=1 $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_store&pmod=admin_store&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=15>'.$it618_mall_lang['s307'].$count.'<span style="float:right;color:red">'.$it618_mall_lang['s650'].'</span></td></tr>';
	showsubtitle(array('', $it618_mall_lang['s308'],$it618_mall_lang['s313'],$it618_mall_lang['s376'],$creditname,$it618_mall_lang['s315'],$it618_mall_lang['s316'],$it618_mall_lang['s648'],$it618_mall_lang['s318'],$it618_mall_lang['s319'],$it618_mall_lang['s320']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE 1=1 $extrasql order by id desc LIMIT $startlimit, $ppp");
	while($it618_scoremall_store = DB::fetch($query)) {
		
		if($it618_scoremall_store['it618_ptaobao']==1)$it618_ptaobao_checked='checked="checked"';else $it618_ptaobao_checked="";
		
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_scoremall_store['it618_uid']);
		
		$pcount=0;$salecount=0;$salesum=0;$saletc=0;
		if($it618_scoremall_store['it618_state']==2){
			$groupupscore=DB::result_first("SELECT it618_score FROM ".DB::table('it618_scoremall_store_groupup')." where it618_uid=".$it618_scoremall_store['it618_uid']);
			$it618_level=DB::result_first("SELECT it618_level FROM ".DB::table('it618_scoremall_store_level')." where it618_score1<=".$groupupscore." and it618_score2>=".$groupupscore);
			$pcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods')." where it618_uid=".$it618_scoremall_store['it618_uid']);
			if($pcount=='')$pcount=0;
			$salecount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_sale')." where it618_saleuid=".$it618_scoremall_store['it618_uid']);
			if($salecount=='')$salecount=0;
			$salesum=DB::result_first("select sum(it618_price*it618_count-it618_quanmoney) from ".DB::table('it618_scoremall_sale')." where it618_saleuid=".$it618_scoremall_store['it618_uid']);
			if($salesum=='')$salesum=0;
			$saletc=DB::result_first("select sum(it618_saletc) from ".DB::table('it618_scoremall_sale')." where it618_saleuid=".$it618_scoremall_store['it618_uid']);
			if($saletc=='')$saletc=0;
		}
		
		if($it618_scoremall_store['it618_state']==0)$it618_state='<font color=red>'.$it618_mall_lang['s304'].'</font>';
		if($it618_scoremall_store['it618_state']==1)$it618_state='<font color=blue>'.$it618_mall_lang['s305'].'</font>';
		if($it618_scoremall_store['it618_state']==2)$it618_state='<font color=green>'.$it618_mall_lang['s306'].'</font>';
		
		if($it618_scoremall_store['it618_state']==2){
			if($it618_scoremall_store['it618_htstate']==0)$it618_htstate='<font color=red>'.$it618_mall_lang['s372'].'</font>';
			if($it618_scoremall_store['it618_htstate']==1)$it618_htstate='<font color=green>'.$it618_mall_lang['s373'].'</font>';
			if($it618_scoremall_store['it618_htstate']==2)$it618_htstate='<font color=#ccc>'.$it618_mall_lang['s374'].'</font>';
			$httime=date('Y-m-d', $it618_scoremall_store['it618_htetime']);
		}else{
			$it618_htstate='';	
			$httime='';
		}
		
		$tmpurl=it618_scoremall_getrewrite('productlist','sid@'.$it618_scoremall_store['id'].'@1','plugin.php?id=it618_scoremall:scoremall_list&sid='.$it618_scoremall_store['id']);
		
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_scoremall_store[id].'" name="delete[]" value="'.$it618_scoremall_store[id].'" '.$disabled.'><input type="hidden" name="id['.$it618_scoremall_store[id].']" value="'.$it618_scoremall_store[id].'"><label for="chk_del'.$it618_scoremall_store[id].'">'.$it618_scoremall_store['id'].'</label>',
			'<a href="'.$tmpurl.'" target="_blank">'.$it618_scoremall_store['it618_name'].'</a> <a href="javascript:" id="liyou'.$it618_scoremall_store[id].'">'.$it618_mall_lang['s741'].'</span>',
			$it618_state,
			$httime.' '.$it618_htstate.' <a href="home.php?mod=space&uid='.$it618_scoremall_store['it618_uid'].'" target="_blank">'.$username.'</a>',
			$groupupscore,
			$it618_level,
			'<input class="txt" type="text" style="width:50px;margin-right:0" name="it618_pprice['.$it618_scoremall_store['id'].']" value="'.$it618_scoremall_store['it618_pprice'].'">/<input class="txt" type="text" style="width:40px;margin-right:0" name="it618_pcount['.$it618_scoremall_store['id'].']" value="'.$it618_scoremall_store['it618_pcount'].'">/'.$pcount.'/<input class="checkbox" type="checkbox" name="it618_ptaobao['.$it618_scoremall_store['id'].']" '.$it618_ptaobao_checked.' value="1">',
			$salecount,
			$salesum,
			$saletc
		));
		
		$morecontent='{logo}<br><strong>'.$it618_mall_lang['s378'].'</strong>{name}<br><strong>'.$it618_mall_lang['s379'].'</strong>{tel}<br><strong>'.$it618_mall_lang['s380'].'</strong>{qq}<br><strong>'.$it618_mall_lang['s381'].'</strong>{liyou}<br><strong>'.$it618_mall_lang['s382'].'</strong>{time}<br>';
		$morecontent=str_replace("{name}",$it618_scoremall_store['it618_name'],$morecontent);
		$morecontent=str_replace("{logo}",'<img src="'.$it618_scoremall_store['it618_logo'].'" width=200 height=75/>',$morecontent);
		$morecontent=str_replace("{tel}",$it618_scoremall_store['it618_tel'],$morecontent);
		$morecontent=str_replace("{qq}",$it618_scoremall_store['it618_qq'],$morecontent);
		$morecontent=str_replace("{liyou}",$it618_scoremall_store['it618_liyou'],$morecontent);
		$morecontent=str_replace("{time}",date('Y-m-d H:i:s', $it618_scoremall_store['it618_time']),$morecontent);
		
		$morecontent=str_replace("'","\"",$morecontent);
		$morecontent=str_replace(array("\r\n", "\r", "\n"),"",$morecontent);
		$tmpjs.='KindEditor.ready(function(K) {K(\'#liyou'.$it618_scoremall_store[id].'\').click(function() {
			var dialog = K.dialog({
				width : 500,
				height : 300,
				title : \''.$it618_mall_lang['s383'].'\',
				body : \'<div style="margin:10px;">'.$morecontent.'</div>\',
				closeBtn : {
					name : \''.$it618_mall_lang['s180'].'\',
					click : function(e) {
						dialog.remove();
					}
				},
				noBtn : {
					name : \''.$it618_mall_lang['s180'].'\',
					click : function(e) {
						dialog.remove();
					}
				}
			});
		});});';
	}
	
	$tmptime=date('Y-m-d H:i:s', $_G['timestamp']);
	$timearr=explode(" ",$tmptime);
	$timearr1=explode("-",$timearr[0]);
	$timearr2=explode(":",$timearr[1]);
	//
	$strtmp="";
	for($i=2013;$i<=2050;$i++){
		if($timearr1[0]==$i){
			$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
		}else{
			$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
		}
	}
	$sel_year='<select name="sel_year">'.$strtmp.'</select>';
	
	//
	$strtmp="";
	for($i=1;$i<=12;$i++){
		if($timearr1[1]==$i){
			$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
		}else{
			$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
		}
	}
	$sel_month='<select name="sel_month">'.$strtmp.'</select>';
	
	//
	$strtmp="";
	for($i=1;$i<=31;$i++){
		if($timearr1[2]==$i){
			$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
		}else{
			$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
		}
	}
	$sel_date='<select name="sel_date">'.$strtmp.'</select>';
	
	function towstr($i){
		if(strlen($i)==1)return "0".$i;else return $i;
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_mall_lang['s415'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.$it618_mall_lang['s322'].'" onclick="return confirm(\''.$it618_mall_lang['s323'].'\')" /> <input type="submit" class="btn" name="it618submit_edit" value="'.$it618_mall_lang['s649'].'"/> <input type="submit" class="btn" name="it618submit_pass" value="'.$it618_mall_lang['s324'].'" onclick="return confirm(\''.$it618_mall_lang['s325'].'\')"/> <input type="submit" class="btn" name="it618submit_nopass" value="'.$it618_mall_lang['s326'].'" onclick="return confirm(\''.$it618_mall_lang['s327'].'\')"/> '.$it618_mall_lang['s328'].'<br>'.$it618_mall_lang['s384'].' '.$sel_year.$sel_month.$sel_date.'<input type="submit" class="btn" name="it618submit_editht" value="'.$it618_mall_lang['s385'].'" onclick="return confirm(\''.$it618_mall_lang['s386'].'\')"/> <input type="submit" class="btn" name="it618submit_clock" value="'.$it618_mall_lang['s387'].'" onclick="return confirm(\''.$it618_mall_lang['s388'].'\')"/> <input type="submit" class="btn" name="it618submit_unclock" value="'.$it618_mall_lang['s389'].'" onclick="return confirm(\''.$it618_mall_lang['s390'].'\')"/> <font color=red>'.$it618_mall_lang['s391'].'</font> &nbsp;<input type=hidden value='.$page.' name=page /></div></td></tr>';

	if(count($reabc)!=15)return;
showtablefooter();/*Dism��taobao��com*/
echo '<script>'.$tmpjs.'</script>';
?>