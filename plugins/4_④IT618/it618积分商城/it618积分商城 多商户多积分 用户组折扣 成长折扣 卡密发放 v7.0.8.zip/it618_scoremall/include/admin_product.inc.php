<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if($_GET['key']!=''){
	$extrasql .= " AND it618_name LIKE '%".addcslashes(addslashes($_GET['key']),'%_')."%'";
}

if($_GET['storeid']!=''){
	$extrasql .= " AND it618_uid = ".intval($_GET['storeid']);
}

$chkstate0='';$chkstate1='';$chkstate2='';$chkstate3='';
if($_GET['chkstate']==0){$extrasql .= "";$chkstate0='selected="selected"';}
if($_GET['chkstate']==1){$extrasql .= " AND it618_state = 0";$chkstate1='selected="selected"';}
if($_GET['chkstate']==2){$extrasql .= " AND it618_state = 1";$chkstate2='selected="selected"';}
if($_GET['chkstate']==3){$extrasql .= " AND it618_state = 2";$chkstate3='selected="selected"';}

$state0='';$state1='';$state2='';$state3='';$state4='';$state5='';$state6='';$state7='';$state8='';$state9='';$state10='';$state10='';$state11='';$state12='';$state13='';$state14='';$state15='';$state16='';$state17='';
if($_GET['state']==0){$extrasql .= "";$state0='selected="selected"';}
if($_GET['state']==1){$extrasql .= " AND it618_isbm = 1";$state1='selected="selected"';}
if($_GET['state']==2){$extrasql .= " AND it618_isbm = 0";$state2='selected="selected"';}
if($_GET['state']==3){$extrasql .= " AND it618_isaddr = 1";$state3='selected="selected"';}
if($_GET['state']==4){$extrasql .= " AND it618_isaddr = 0";$state4='selected="selected"';}
if($_GET['state']==5){$extrasql .= " AND it618_ison = 1";$state5='selected="selected"';}
if($_GET['state']==6){$extrasql .= " AND it618_ison = 0";$state6='selected="selected"';}
if($_GET['state']==7){$extrasql .= " AND it618_istj = 1";$state7='selected="selected"';}
if($_GET['state']==8){$extrasql .= " AND it618_istj = 0";$state8='selected="selected"';}
if($_GET['state']==9){$extrasql .= " AND it618_isorder = 1";$state9='selected="selected"';}
if($_GET['state']==10){$extrasql .= " AND it618_isorder = 0";$state10='selected="selected"';}
if($_GET['state']==11){$extrasql .= " AND it618_istaobao = 1";$state11='selected="selected"';}
if($_GET['state']==12){$extrasql .= " AND it618_istaobao = 0";$state12='selected="selected"';}
if($_GET['state']==13){$extrasql .= " AND it618_ischeck = 1";$state13='selected="selected"';}
if($_GET['state']==14){$extrasql .= " AND it618_ischeck = 0";$state14='selected="selected"';}
if($_GET['state']==15){$extrasql .= " AND it618_isquan = 1";$state15='selected="selected"';}
if($_GET['state']==16){$extrasql .= " AND it618_isquan = 2";$state16='selected="selected"';}
if($_GET['state']==17){$extrasql .= " AND it618_isquan = 0";$state17='selected="selected"';}

$orderby0='';$orderby1='';$orderby2='';$orderby3='';$orderby4='';
if($_GET['orderby']==0){$extrasql .= " order by it618_order desc,id desc";$orderby0='selected="selected"';}
if($_GET['orderby']==1){$extrasql .= " order by it618_count desc";$orderby1='selected="selected"';}
if($_GET['orderby']==2){$extrasql .= " order by it618_salecount desc";$orderby2='selected="selected"';}
if($_GET['orderby']==3){$extrasql .= " order by it618_views desc";$orderby3='selected="selected"';}
if($_GET['orderby']==4){$extrasql .= " order by it618_score desc";$orderby4='selected="selected"';}

$sql='&key='.$_GET['key'].'&storeid='.$_GET['storeid'].'&chkstate='.$_GET['chkstate'].'&state='.$_GET['state'].'&orderby='.$_GET['orderby'];

if(submitcheck('it618submit_del')){
	$del=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$salecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_sale')." WHERE it618_pid=".$delid);
		if($salecount<=0){
			$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$delid);
			$tmpurl=$_G['siteurl'].it618_scoremall_getrewrite('product',$delid,'plugin.php?id=it618_scoremall:scoremall_page&pid='.$delid);
			$qrcodeurl=md5($tmpurl);
			$qrcodeurl='source/plugin/it618_scoremall/qrcode/'.$qrcodeurl.'.png';
			$tmparr=explode("source",$qrcodeurl);
			$qrcodeurl=DISCUZ_ROOT.'./source'.$tmparr[1];
			
			if(file_exists($qrcodeurl)){
				$result=unlink($qrcodeurl);
			}
			
			for($i=0;$i<=4;$i++){
				if($i==0)$tmpi='';else $tmpi=$i;
				$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
				
				if($it618_scoremall_goods['it618_picbig'.$tmpi]!=$get_it618_picbig){
					$tmparr=explode("source",$it618_scoremall_goods['it618_picbig'.$tmpi]);
					$tmparr1=explode("://",$it618_scoremall_goods['it618_picbig'.$tmpi]);
					$it618_picbig=DISCUZ_ROOT.'./source'.$tmparr[1];
					
					if(file_exists($it618_picbig)&&count($tmparr1)==1){
						$result=unlink($it618_picbig);
					}
				}
				
				$file_ext=strtolower(substr($it618_scoremall_goods['it618_picbig'.$tmpi],strrpos($it618_scoremall_goods['it618_picbig'.$tmpi], '.')+1)); 
				$file_extarr=explode("?",$file_ext);
				$file_ext=$file_extarr[0];
				$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/data/u'.$it618_scoremall_goods['it618_uid'].'/smallimage/goods'.$delid.'_'.$i.'.'.$file_ext;
				if(file_exists($it618_smallurl)){
					$result=unlink($it618_smallurl);
				}
			}
			
			DB::delete('it618_scoremall_goods', "id=$delid");
			$del=$del+1;
		}
	}

	cpmsg($it618_mall_lang['s114'].$del, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_edit')){
	$ok=0;
	if($reabc[8]!='o')return;
	
	if(is_array($_GET['it618_name'])) {
		foreach($_GET['it618_name'] as $id => $val) {
			
			$it618_jfid=$_GET['it618_jfid'][$id];
			$it618_jfid1=$_GET['it618_jfid1'][$id];
			$it618_score=$_GET['it618_score'][$id];
			$it618_score1=$_GET['it618_score1'][$id];
			
			if($it618_jfid==$it618_jfid1){
				$it618_jfid1=0;
				$it618_score1=0;
			}
			
			if($it618_jfid1==0)$it618_score1=0;
		
			C::t('#it618_scoremall#it618_scoremall_goods')->update($id,array(
				'it618_name' => $_GET['it618_name'][$id],
				'it618_score' => $it618_score,
				'it618_score1' => $it618_score1,
				'it618_jfid' => $it618_jfid,
				'it618_jfid1' => $it618_jfid1,
				'it618_views' => $_GET['it618_views'][$id],
				'it618_xiangoutime' => intval($_GET['it618_xiangoutime'][$id]),
				'it618_xiangoucount' => intval($_GET['it618_xiangoucount'][$id]),
				'it618_xgtype' => $_GET['it618_xgtype'][$id],
				'it618_xgtime1' => $_GET['it618_xgtime1'][$id],
				'it618_xgtime2' => $_GET['it618_xgtime2'][$id],
				'it618_tc' => $_GET['it618_tc'][$id],
				'it618_ischeck' => $_GET['it618_ischeck'][$id],
				'it618_ison' => $_GET['it618_ison'][$id],
				'it618_isbm' => $_GET['it618_isbm'][$id],
				'it618_istj' => $_GET['it618_istj'][$id],
				'it618_iszk' => $_GET['it618_iszk'][$id],
				'it618_isaddr' => $_GET['it618_isaddr'][$id],
				'it618_isorder' => $_GET['it618_isorder'][$id],
				'it618_istaobao' => $_GET['it618_istaobao'][$id],
				'it618_isquan' => $_GET['it618_isquan'][$id],
				'it618_taobaourl' => $_GET['it618_taobaourl'][$id],
				'it618_order' => $_GET['it618_order'][$id]
			));
			
			if($_GET['it618_count'][$id]!='-1'){
				C::t('#it618_scoremall#it618_scoremall_goods')->update($id,array(
					'it618_count' => $_GET['it618_count'][$id]
				));
			}
	
			$ok=$ok+1;
		}
	}

	cpmsg($it618_mall_lang['s113'].$ok, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_pass')){
	$ok=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$delid);
		
		if($it618_scoremall_goods['it618_state']==0){
			if($it618_scoremall_goods['it618_uid']==0){
				DB::query("update ".DB::table('it618_scoremall_goods')." set it618_state=2 WHERE id=".$delid);
			}else{
				DB::query("update ".DB::table('it618_scoremall_goods')." set it618_state=2,it618_message=it618_message_daishen WHERE id=".$delid);
			}
			
			$ok=$ok+1;
		}
	}
	
	cpmsg($it618_mall_lang['s210'].$ok, "action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_nopass')){
	$ok=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$delid);
		
		if($it618_scoremall_goods['it618_state']==0){
			DB::query("update ".DB::table('it618_scoremall_goods')." set it618_state=1 WHERE id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_mall_lang['s211'].$ok, "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=15)return;

showformheader("plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do");
showtableheaders($it618_mall_lang['s115'],'it618_scoremall_sum');
	showsubmit('it618sercsubmit', $it618_mall_lang['s116'], $it618_mall_lang['s117'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" />'.$it618_mall_lang['s212'].' <input name="storeid" value="'.$_GET['storeid'].'" class="txt" style="width:50px" />'.$it618_mall_lang['s213'].' <select name="chkstate"><option value=0 '.$chkstate0.'>'.$it618_mall_lang['s214'].'</option><option value=1 '.$chkstate1.'>'.$it618_mall_lang['s215'].'</option><option value=2 '.$chkstate2.'>'.$it618_mall_lang['s216'].'</option><option value=3 '.$chkstate3.'>'.$it618_mall_lang['s217'].'</option></select> '.$it618_mall_lang['s118'].' <select name="state"><option value=0 '.$state0.'>'.$it618_mall_lang['s119'].'</option><option value=1 '.$state1.'>'.$it618_mall_lang['s218'].'</option><option value=2 '.$state2.'>'.$it618_mall_lang['s219'].'</option><option value=3 '.$state3.'>'.$it618_mall_lang['s120'].'</option><option value=4 '.$state4.'>'.$it618_mall_lang['s121'].'</option><option value=5 '.$state5.'>'.$it618_mall_lang['s122'].'</option><option value=6 '.$state6.'>'.$it618_mall_lang['s123'].'</option><option value=7 '.$state7.'>'.$it618_mall_lang['s124'].'</option><option value=8 '.$state8.'>'.$it618_mall_lang['s125'].'</option><option value=9 '.$state9.'>'.$it618_mall_lang['s536'].'</option><option value=10 '.$state10.'>'.$it618_mall_lang['s537'].'</option><option value=11 '.$state11.'>'.$it618_mall_lang['s662'].'</option><option value=12 '.$state12.'>'.$it618_mall_lang['s663'].'</option><option value=13 '.$state13.'>'.$it618_mall_lang['s651'].'</option><option value=14 '.$state14.'>'.$it618_mall_lang['s652'].'</option><option value=15 '.$state15.'>'.$it618_mall_lang['s708'].'</option><option value=16 '.$state16.'>'.$it618_mall_lang['s690'].'</option><option value=17 '.$state17.'>'.$it618_mall_lang['s691'].'</option></select> '.$it618_mall_lang['s126'].' <select name="orderby"><option value=0 '.$orderby0.'>'.$it618_mall_lang['s127'].'</option><option value=1 '.$orderby1.'>'.$it618_mall_lang['s128'].'</option><option value=2 '.$orderby2.'>'.$it618_mall_lang['s129'].'</option><option value=3 '.$orderby3.'>'.$it618_mall_lang['s130'].'</option><option value=4 '.$orderby4.'>'.$it618_mall_lang['s131'].'</option></select>');
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('it618_scoremall_goods')." w WHERE 1 $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_product&pmod=admin_product&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=20>'.$it618_mall_lang['s132'].$count.' <span style="float:right">'.$it618_mall_lang['s220'].'</span></td></tr>';
	showsubtitle(array('',$it618_mall_lang['s135'].'/'.$it618_mall_lang['s664'].'/'.$it618_mall_lang['s223'],$it618_mall_lang['s136'],$it618_mall_lang['s137'].'/'.$it618_mall_lang['s221'],$it618_mall_lang['s768'].'/'.$it618_mall_lang['s707'],$it618_mall_lang['s653'],$it618_mall_lang['s224'],$it618_mall_lang['s225'],$it618_mall_lang['s141'],$it618_mall_lang['s142'],$it618_mall_lang['s958'],$it618_mall_lang['s542'],$it618_mall_lang['s665'],$it618_mall_lang['s143']));
	
	for($i=1;$i<=8;$i++){
		if($_G['setting']['extcredits'][$i]['title']!=''){
			$jfidstrtmp.='<option value="'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].'</option>';
		}
	}
	
	$jfidstrtmp1='<option value="0">'.$it618_mall_lang['s997'].'</option>'.$jfidstrtmp;

	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE 1 $extrasql LIMIT $startlimit, $ppp");
	$n=1;
	while($it618_scoremall_goods = DB::fetch($query)) {
		if($it618_scoremall_goods['it618_ischeck']==1)$it618_ischeck_checked='checked="checked"';else $it618_ischeck_checked="";
		if($it618_scoremall_goods['it618_ison']==1)$it618_ison_checked='checked="checked"';else $it618_ison_checked="";
		if($it618_scoremall_goods['it618_saletype']==1)$it618_saletype_checked='checked="checked"';else $it618_saletype_checked="";
		if($it618_scoremall_goods['it618_istj']==1)$it618_istj_checked='checked="checked"';else $it618_istj_checked="";
		if($it618_scoremall_goods['it618_iszk']==1)$it618_iszk_checked='checked="checked"';else $it618_iszk_checked="";
		if($it618_scoremall_goods['it618_isaddr']==1)$it618_isaddr_checked='checked="checked"';else $it618_isaddr_checked="";
		if($it618_scoremall_goods['it618_isbm']==1)$it618_isbm_checked='checked="checked"';else $it618_isbm_checked="";
		if($it618_scoremall_goods['it618_isorder']==1)$it618_isorder_checked='checked="checked"';else $it618_isorder_checked="";
		if($it618_scoremall_goods['it618_istaobao']==1)$it618_istaobao_checked='checked="checked"';else $it618_istaobao_checked="";
		if($it618_scoremall_goods['it618_state']==0)$it618_state='<font color=red>'.$it618_mall_lang['s215'].'</font>';
		if($it618_scoremall_goods['it618_state']==1)$it618_state='<font color=blue>'.$it618_mall_lang['s216'].'</font>';
		if($it618_scoremall_goods['it618_state']==2)$it618_state='<font color=green>'.$it618_mall_lang['s217'].'</font>';
		
		$isquan0='';$isquan1='';$isquan2='';
		if($it618_scoremall_goods['it618_isquan']==0)$isquan0='selected="selected"';
		if($it618_scoremall_goods['it618_isquan']==1)$isquan1='selected="selected"';
		if($it618_scoremall_goods['it618_isquan']==2)$isquan2='selected="selected"';
		
		if($it618_scoremall_goods['it618_xgtype']==0)$it618_xgtype0=' selected="selected"';else $it618_xgtype0="";
		if($it618_scoremall_goods['it618_xgtype']==1)$it618_xgtype1=' selected="selected"';else $it618_xgtype1="";
		if($it618_scoremall_goods['it618_xgtype']==2)$it618_xgtype2=' selected="selected"';else $it618_xgtype2="";

		if($it618_scoremall_goods[it618_uid]==0){
			$postuser=$it618_mall_lang['s227'];
		}else{
			$postuser='<a href="home.php?mod=space&uid='.$it618_scoremall_goods['it618_uid'].'" target="_blank">'.it618_scoremall_getusername($it618_scoremall_goods[it618_uid]).'</a>';
		}
		
		$username='<a href="home.php?mod=space&uid='.$it618_scoremall_goods['it618_uid'].'" target="_blank">'.it618_scoremall_getusername($it618_scoremall_goods[it618_uid]).'</a>';
		$salecount = DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_scoremall_sale')." WHERE it618_state <>5 and it618_pid=".$it618_scoremall_goods['id']);
		if($salecount=='')$salecount=0;
		
		$kmcount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".$it618_scoremall_goods['id']);
		if($kmcount>0){
			$it618_count='<input type="hidden" name="it618_count['.$it618_scoremall_goods[id].']" value="-1"> <a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_product_km&pmod=admin_product&operation='.$operation.'&do='.$do.'&pid='.$it618_scoremall_goods[id].'&page='.$page.'"><div style="padding-top:6px"><font color=blue>'.$it618_mall_lang['s440'].'</font>(<font color=red>'.$it618_scoremall_goods[it618_count].'</font>)</div></a>';
			$it618_isaddr_checked="";
		}else{
			$it618_count='<input type="text" class="txt" style="width:50px;margin-right:1px;margin-bottom:3px;color:green" name="it618_count['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[it618_count].'"> <a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_product_km&pmod=admin_product&operation='.$operation.'&do='.$do.'&pid='.$it618_scoremall_goods[id].'&page='.$page.'"><font color=blue>'.$it618_mall_lang['s440'].'</font></a>';
		}
		$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
		
		$it618_tccss='';
		if($it618_scoremall_goods[it618_tc]>0){
			$it618_tccss=';color:red';
		}
		
		$it618_tcstr='';$it618_ptaobao='';
		if($it618_scoremall_goods[it618_uid]>0){
			$it618_tcstr='<br>'.$it618_mall_lang['s957'].' : <input type="text" class="txt" style="width:40px;margin-left:4px;margin-top:3px;margin-right:0'.$it618_tccss.'" name="it618_tc['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[it618_tc].'">%';
			$it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." where it618_uid=".$it618_scoremall_goods[it618_uid]);
			if($it618_scoremall_store['it618_ptaobao']!=1){
				$it618_ptaobao=' style="display:none"';
			}
		}
		
		$jfidstr=str_replace('value="'.$it618_scoremall_goods['it618_jfid'].'"','value="'.$it618_scoremall_goods['it618_jfid'].'" selected="selected"',$jfidstrtmp);
		$jfidstr1=str_replace('value="'.$it618_scoremall_goods['it618_jfid1'].'"','value="'.$it618_scoremall_goods['it618_jfid1'].'" selected="selected"',$jfidstrtmp1);
		
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_scoremall_goods[id].'"><input type="hidden" name="id['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[id].'"><label for="chk_del'.$n.'">'.$it618_scoremall_goods['id'].'</label>',
			'<div style="width:340px"><a style="float:left" href="'.$tmpurl.'" target="_blank" title="'.$it618_mall_lang['s134'].$it618_mall_lang['s670'].it618_scoremall_class1name($it618_scoremall_goods['it618_class3_id']).' '.it618_scoremall_class2name($it618_scoremall_goods['it618_class3_id']).' '.it618_scoremall_class3name($it618_scoremall_goods['it618_class3_id']).'"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'" width="68" height="68" style="margin-right:3px"/></a><input type="text" class="txt" style="width:230px;margin-right:3px" name="it618_name['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[it618_name].'"><a href="'.ADMINSCRIPT.'?action=plugins&identifier='.$identifier.'&cp=admin_product_edit&pmod=admin_product&operation='.$operation.'&do='.$do.'&pid='.$it618_scoremall_goods[id].'">'.$it618_mall_lang['s144'].'</a><br><input type="text" class="txt" style="width:230px;margin-right:1px;margin-top:3px;margin-bottom:3px" name="it618_taobaourl['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[it618_taobaourl].'"><br>'.$it618_mall_lang['s226'].':'.$postuser.'<span style="float:right;margin-right:30px">'.$it618_state.'</span></div>',
			'<input type="text" class="txt" style="width:50px;margin-right:1px;height:18px;color:red" name="it618_score['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[it618_score].'"><select name="it618_jfid['.$it618_scoremall_goods[id].']">'.$jfidstr.'</select><br><input type="text" class="txt" style="width:50px;margin-right:1px;height:18px;color:red;margin-top:3px" name="it618_score1['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[it618_score1].'"><select name="it618_jfid1['.$it618_scoremall_goods[id].']" style="margin-top:1px">'.$jfidstr1.'</select><br>'.$it618_mall_lang['s692'].' : <font color="red">'.$salecount.'</font>',
			$it618_count.'<br><input type="text" class="txt" style="width:40px;margin-right:0" name="it618_xiangoutime['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[it618_xiangoutime].'">/<input type="text" class="txt" style="width:40px" name="it618_xiangoucount['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[it618_xiangoucount].'">'.$it618_tcstr.'<br>'.$it618_mall_lang['s139'].' : <input type="text" class="txt" style="width:50px;margin-left:4px;margin-top:3px;margin-bottom:3px" name="it618_views['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[it618_views].'">',
			'<select id="it618_xgtype'.$n.'" name="it618_xgtype['.$it618_scoremall_goods[id].']"><option value="0"'.$it618_xgtype0.'>'.$it618_mall_lang['s769'].'</option><option value="1"'.$it618_xgtype1.'>'.$it618_mall_lang['s770'].'</option><option value="2"'.$it618_xgtype2.'>'.$it618_mall_lang['s771'].'</option></select><select name="it618_isquan['.$it618_scoremall_goods['id'].']"><option value="0" '.$isquan0.'>'.$it618_mall_lang['s709'].'</option><option value="1" '.$isquan1.'>'.$it618_mall_lang['s710'].'</option><option value="2" '.$isquan2.'>'.$it618_mall_lang['s693'].'</option></select><br><input type="text" class="txt" style="width:122px;margin-top:3px" id="it618_xgtime1_'.$n.'" name="it618_xgtime1['.$it618_scoremall_goods['id'].']" readonly="readonly" value="'.$it618_scoremall_goods['it618_xgtime1'].'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')"><br><input type="text" class="txt" style="width:122px;margin-top:3px" id="it618_xgtime2_'.$n.'" name="it618_xgtime2['.$it618_scoremall_goods['id'].']" readonly="readonly" value="'.$it618_scoremall_goods['it618_xgtime2'].'" onclick="SetDate(this,\'yyyy-MM-dd hh:mm\')">',
			'<input class="checkbox" type="checkbox" id="chk_ischeck'.$n.'" name="it618_ischeck['.$it618_scoremall_goods['id'].']" '.$it618_ischeck_checked.' value="1">',
			'<input class="checkbox" type="checkbox" id="chk_isbm'.$n.'" name="it618_isbm['.$it618_scoremall_goods['id'].']" '.$it618_isbm_checked.' value="1">',
			'<input class="checkbox" type="checkbox" id="chk_addr'.$n.'" name="it618_isaddr['.$it618_scoremall_goods['id'].']" '.$it618_isaddr_checked.' value="1">',
			'<input class="checkbox" type="checkbox" id="chk_ison'.$n.'" name="it618_ison['.$it618_scoremall_goods['id'].']" '.$it618_ison_checked.' value="1">',
			'<input class="checkbox" type="checkbox" id="chk_istj'.$n.'" name="it618_istj['.$it618_scoremall_goods['id'].']" '.$it618_istj_checked.' value="1">',
			'<input class="checkbox" type="checkbox" id="chk_iszk'.$n.'" name="it618_iszk['.$it618_scoremall_goods['id'].']" '.$it618_iszk_checked.' value="1">',
			'<input class="checkbox" type="checkbox" id="chk_isorder'.$n.'" name="it618_isorder['.$it618_scoremall_goods['id'].']" '.$it618_isorder_checked.' value="1">',
			'<input class="checkbox" type="checkbox" id="chk_istaobao'.$n.'" name="it618_istaobao['.$it618_scoremall_goods['id'].']" '.$it618_istaobao_checked.' '.$it618_ptaobao.' value="1">',
			'<input type="text" class="txt" style="width:20px" name="it618_order['.$it618_scoremall_goods[id].']" value="'.$it618_scoremall_goods[it618_order].'">'
		));
		$n=$n+1;
	}
	
	function it618_scoremall_class1name($aid){
		$class2id = DB::result_first("select it618_class2_id from ".DB::table('it618_scoremall_class3')." where id=".$aid);
		if($class2id=='')return;
		$class1id = DB::result_first("select it618_class1_id from ".DB::table('it618_scoremall_class2')." where id=".$class2id);
		return DB::result_first("select it618_classname from ".DB::table('it618_scoremall_class1')." where id=".$class1id);
	}
	
	function it618_scoremall_class2name($aid){
		$class2id = DB::result_first("select it618_class2_id from ".DB::table('it618_scoremall_class3')." where id=".$aid);
		if($class2id=='')return;
		return DB::result_first("select it618_classname from ".DB::table('it618_scoremall_class2')." where id=".$class2id);
	}
	
	function it618_scoremall_class3name($aid){
		return DB::result_first("select it618_classname from ".DB::table('it618_scoremall_class3')." where id=".$aid);
	}
	
	function it618_scoremall_getusername($uid){
		return DB::result_first("select username from ".DB::table('common_member')." where uid=".$uid);
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_mall_lang['s415'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.$it618_mall_lang['s488'].'" onclick="return confirm(\''.$it618_mall_lang['s489'].'\')" /> <input type="submit" class="btn" name="it618submit_edit" value="'.$it618_mall_lang['s490'].'" onclick="return checkvalue()"/> <input type="submit" class="btn" name="it618submit_pass" value="'.$it618_mall_lang['s228'].'" onclick="return confirm(\''.$it618_mall_lang['s229'].'\')" /> <input type="submit" class="btn" name="it618submit_nopass" value="'.$it618_mall_lang['s230'].'" onclick="return confirm(\''.$it618_mall_lang['s234'].'\')" /> <input type="checkbox" id="chk_ischeck" class="checkbox" onclick="check_all(this, \'chk_ischeck\')" /><label for="chk_ischeck">'.$it618_mall_lang['s654'].'</label> <input type="checkbox" id="chk_isbm" class="checkbox" onclick="check_all(this, \'chk_isbm\')" /><label for="chk_isbm">'.$it618_mall_lang['s218'].'</label> <input type="checkbox" id="chk_addr" class="checkbox" onclick="check_all(this, \'chk_addr\')" /><label for="chk_addr">'.$it618_mall_lang['s231'].'</label> <input type="checkbox" id="chk_ison" class="checkbox" onclick="check_all(this, \'chk_ison\')" /><label for="chk_ison">'.$it618_mall_lang['s141'].'</label> <input type="checkbox" id="chk_istj" class="checkbox" onclick="check_all(this, \'chk_istj\')" /><label for="chk_istj">'.$it618_mall_lang['s142'].'</label> <input type="checkbox" id="chk_iszk" class="checkbox" onclick="check_all(this, \'chk_iszk\')" /><label for="chk_iszk">'.$it618_mall_lang['s958'].'</label> <input type="checkbox" id="chk_isorder" class="checkbox" onclick="check_all(this, \'chk_isorder\')" /><label for="chk_isorder">'.$it618_mall_lang['s542'].'</label> <input type="checkbox" id="chk_istaobao" class="checkbox" onclick="check_all(this, \'chk_istaobao\')" /><label for="chk_istaobao">'.$it618_mall_lang['s665'].'</label> <input type="checkbox" id="chk_isquan" class="checkbox" onclick="check_all(this, \'chk_isquan\')" /><label for="chk_isquan">'.$it618_mall_lang['s707'].'</label><br>'.$it618_mall_lang['s669'].'<input type=hidden value='.$page.' name=page /></div></td></tr>';
	if(count($reabc)!=15)return;
showtablefooter();/*Dism��taobao��com*/
echo '<script charset="utf-8" src="source/plugin/it618_scoremall/js/Calendar.js"></script>
<script type="text/javascript">
		function check_all(obj,id)
		{
			for(var i=1;i<'.$n.';i++)
			{
				document.getElementById(id+""+i).checked = obj.checked;
			}
		}
		
		function checkvalue(){
			for(var i=1;i<'.$n.';i++){
				var chk_del = document.getElementById("chk_del"+i).value;
				var it618_xgtype = document.getElementById("it618_xgtype"+i).value;
				var it618_xgtime1 = document.getElementById("it618_xgtime1_"+i).value;
				var it618_xgtime2 = document.getElementById("it618_xgtime2_"+i).value;
				
				var tmparr1=it618_xgtime1.split(" ");
				var tmparr2=it618_xgtime2.split(" ");
				
				if(it618_xgtype>0){
					if(it618_xgtime1==""){
						alert("'.it618_mall_getlang('s949').'"+chk_del+") '.it618_mall_getlang('s950').'");
						document.getElementById("it618_xgtime1_"+i).focus();
						return false;
					}
					if(it618_xgtime2==""){
						alert("'.it618_mall_getlang('s949').'"+chk_del+") '.it618_mall_getlang('s951').'");
						document.getElementById("it618_xgtime2_"+i).focus();
						return false;
					}
					if(parseInt(tmparr2[0].replace(/-/g,""))<parseInt(tmparr1[0].replace(/-/g,""))){
						alert("'.it618_mall_getlang('s949').'"+chk_del+")'.it618_mall_getlang('s947').'");
						document.getElementById("it618_xgtime1_"+i).focus();
						return false;
					}
					
					var flag=0;
					if(it618_xgtype==2){
						flag=1;
					}else{
						if(parseInt(tmparr2[0].replace(/-/g,""))==parseInt(tmparr1[0].replace(/-/g,""))){
							flag=1;
						}
					}
					if(flag==1&&parseInt(tmparr2[1].replace(":",""))<=parseInt(tmparr1[1].replace(":",""))){
						alert("'.it618_mall_getlang('s949').'"+chk_del+")'.it618_mall_getlang('s948').'");
						document.getElementById("it618_xgtime1_"+i).focus();
						return false;
					}
				}
			}
		}
	  </script>';
?>