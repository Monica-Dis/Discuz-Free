<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(count($reabc)!=15)return;
showformheader("plugins&identifier=$identifier&cp=admin_quan&pmod=admin_quan&operation=$operation&do=$do");
showtableheaders($it618_mall_lang['s486'],'it618_scoremall_quan');

	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('it618_scoremall_quan')." w WHERE it618_usetime>0 and it618_storeid=0");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_quan&pmod=admin_quan&operation=$operation&do=$do");
	
	echo '<tr><td colspan=10>'.$it618_mall_lang['s487'].$count.'<span style="float:right;">'.$it618_mall_lang['s479'].'</span></td></tr>';
	showsubtitle(array($it618_mall_lang['s480'], $it618_mall_lang['s481'], $it618_mall_lang['s482'],$it618_mall_lang['s483'],$it618_mall_lang['s484'],$it618_mall_lang['s510'],$it618_mall_lang['s511']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_quan')." WHERE it618_usetime>0 and it618_storeid=0 ORDER BY id DESC LIMIT $startlimit, $ppp");
	while($it618_scoremall = DB::fetch($query)) {
		if($it618_scoremall['it618_type']==1){
			$it618_type=$it618_mall_lang['s473'];
		}else{
			$it618_type=$it618_mall_lang['s474'];
		}
		if($it618_scoremall['it618_etime']==0){
			$it618_etime=$it618_mall_lang['s485'];
		}else{
			$it618_etime=date('Y-m-d H:i:s', $it618_scoremall['it618_etime']);
		}
		$jfname=$_G['setting']['extcredits'][$it618_scoremall['it618_jfid']]['title'];
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_scoremall['it618_useuid']);
		showtablerow('', array('', '', ''), array(
			$it618_scoremall['it618_code'],
			$it618_type,
			'<span style="color:#F60; font-weight:bold">'.$it618_scoremall['it618_score'].'</span>'.$jfname,
			$it618_etime,
			date('Y-m-d H:i:s', $it618_scoremall['it618_addtime']),
			$username,
			date('Y-m-d H:i:s', $it618_scoremall['it618_usetime'])
		));

	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo '<tr><td colspan=10><input type=hidden value=$page name=page />'.$multipage.'</td></tr>';
	if(count($reabc)!=15)return;
showtablefooter();/*Dism��taobao��com*/
?>