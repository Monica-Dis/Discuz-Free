<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_scoremall_class1', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_classname'])) {
		foreach($_GET['it618_classname'] as $id => $val) {

			C::t('#it618_scoremall#it618_scoremall_class1')->update($id,array(
				'it618_classname' => trim($_GET['it618_classname'][$id]),
				'it618_img' => trim($_GET['it618_img'][$id]),
				'it618_url' => trim($_GET['it618_url'][$id]),
				'it618_color' => trim($_GET['it618_color'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
				'it618_homeposition' => trim($_GET['it618_homeposition'][$id]),
				'it618_homecount' => trim($_GET['it618_homecount'][$id]),
				'it618_homeordertype' => trim($_GET['it618_homeordertype'][$id]),
				'it618_homewapcount' => trim($_GET['it618_homewapcount'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_classname_array = !empty($_GET['newit618_classname']) ? $_GET['newit618_classname'] : array();
	$newit618_color_array = !empty($_GET['newit618_color']) ? $_GET['newit618_color'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_classname_array as $key => $value) {
		$newit618_classname = addslashes(trim($newit618_classname_array[$key]));
		
		if($newit618_classname != '') {
			
			C::t('#it618_scoremall#it618_scoremall_class1')->insert(array(
				'it618_classname' => trim($newit618_classname_array[$key]),
				'it618_color' => trim($newit618_color_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_mall_lang['s39'].$ok1.' '.$it618_mall_lang['s40'].$ok2.' '.$it618_mall_lang['s41'].$del.')', "action=plugins&identifier=$identifier&cp=admin_class1&pmod=admin_class&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=15)return;
if(submitcheck('it618sercsubmit')) {
	if($_GET['beforeword']) {
		$extrasql = "AND it618_classname LIKE '%".addcslashes(addslashes($_GET['beforeword']),'%_')."%'";
	}
}

showformheader("plugins&identifier=$identifier&cp=admin_class1&pmod=admin_class&operation=$operation&do=$do");
showtableheaders($it618_mall_lang['s42'],'it618_scoremall_class1');
	showsubmit('it618sercsubmit', $it618_mall_lang['s43'], $it618_mall_lang['s44'].'<input name="beforeword" value="'.$_GET['beforeword'].'" class="txt" />');
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('it618_scoremall_class1')." w WHERE 1 $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_class1&pmod=admin_class&operation=$operation&do=$do");
	
	echo '<tr><td colspan=10>'.$it618_mall_lang['s45'].$count.'<span style="float:right;color:red">'.$it618_mall_lang['s635'].'</span></td></tr>';
	showsubtitle(array('', $it618_mall_lang['s46'], $it618_mall_lang['s47'],$it618_mall_lang['s636'],$it618_mall_lang['s637'], $it618_mall_lang['s48'],$it618_mall_lang['s49'],$it618_mall_lang['s57']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class1')." WHERE 1 $extrasql ORDER BY it618_order DESC LIMIT $startlimit, $ppp");
	while($it618_scoremall =	DB::fetch($query)) {
		$class2count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_class2')." WHERE it618_class1_id=".$it618_scoremall['id']);
		$class3s="0";
		$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class2')." WHERE it618_class1_id=".$it618_scoremall['id']);
		while($it618_scoremall_class2 = DB::fetch($query1)) {
			$query2 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." WHERE it618_class2_id=".$it618_scoremall_class2['id']);
			while($it618_scoremall_class3 = DB::fetch($query2)) {
				$class3s.=",".$it618_scoremall_class3['id'];
			}
		}
		$sql=" and it618_class3_id in(".$class3s.")";
		$goodscount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_goods')." WHERE 1".$sql);
		$disabled="";
		if($class2count>0)$disabled="disabled=\"disabled\"";
		
		$it618_homeposition='<select name="it618_homeposition['.$it618_scoremall['id'].']"><option value="1">'.$it618_mall_lang['s639'].'</option><option value="2">'.$it618_mall_lang['s640'].'</option><option value="3">'.$it618_mall_lang['s641'].'</option></select>';
		$it618_homeposition=str_replace('value="'.$it618_scoremall['it618_homeposition'].'"','value="'.$it618_scoremall['it618_homeposition'].'" selected="selected"',$it618_homeposition);
		
		$it618_homeordertype='<select name="it618_homeordertype['.$it618_scoremall['id'].']"><option value="1">'.$it618_mall_lang['s642'].'</option><option value="2">'.$it618_mall_lang['s643'].'</option><option value="3">'.$it618_mall_lang['s644'].'</option><option value="4">'.$it618_mall_lang['s645'].'</option><option value="5">'.$it618_mall_lang['s766'].'</option><option value="6">'.$it618_mall_lang['s767'].'</option></select>';
		$it618_homeordertype=str_replace('value="'.$it618_scoremall['it618_homeordertype'].'"','value="'.$it618_scoremall['it618_homeordertype'].'" selected="selected"',$it618_homeordertype);

		
		showtablerow('', array('class="td25"', '', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_scoremall[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_scoremall[id]]\" value=\"$it618_scoremall[id]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:90px\" name=\"it618_classname[$it618_scoremall[id]]\" value=\"$it618_scoremall[it618_classname]\">",
			"<input id=\"c".$it618_scoremall['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"it618_color[$it618_scoremall[id]]\" value=\"$it618_scoremall[it618_color]\" onchange=\"updatecolorpreview('c".$it618_scoremall['id']."')\"><input id=\"c".$it618_scoremall['id']."\" onclick=\"c".$it618_scoremall['id']."_frame.location='static/image/admincp/getcolor.htm?c".$it618_scoremall['id']."|c".$it618_scoremall['id']."_v';showMenu({'ctrlid':'c".$it618_scoremall['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c".$it618_scoremall['id']."_menu\" style=\"display: none\"><iframe name=\"c".$it618_scoremall['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			$it618_homeposition.'/<input class="txt" style="width:50px;margin-right:0" type="text" name="it618_homecount['.$it618_scoremall['id'].']" value="'.$it618_scoremall['it618_homecount'].'">/'.$it618_homeordertype.'<br><div style="margin-top:3px">'.$it618_mall_lang['s1032'].' <input class="txt" style="width:50px;margin-right:0" type="text" name="it618_homewapcount['.$it618_scoremall['id'].']" value="'.$it618_scoremall['it618_homewapcount'].'"></div>',
			'<img id="img'.$it618_scoremall['id'].'" src="'.$it618_scoremall['it618_img'].'" width="150" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" id="url'.$it618_scoremall['id'].'" name="it618_img['.$it618_scoremall['id'].']" style="width:30px" readonly="readonly" value="'.$it618_scoremall['it618_img'].'" /> <input type="button" id="image'.$it618_scoremall['id'].'" value="'.$it618_mall_lang['s70'].'" /><br><input class="txt" type="text" style="width:251px;margin-top:3px" name="it618_url['.$it618_scoremall['id'].']" value="'.$it618_scoremall['it618_url'].'">',
			'<input class="txt" type="text" style="width:40px;" name="it618_order['.$it618_scoremall['id'].']" value="'.$it618_scoremall['it618_order'].'">',
			$class2count,
			$goodscount
		));
		$tmpcolorjs.="updatecolorpreview('c".$it618_scoremall['id']."');";
		$editorjs.='K(\'#image'.$it618_scoremall['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url'.$it618_scoremall['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$it618_scoremall['id'].'\').val(url);
								K(\'#img'.$it618_scoremall['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});';
	}
	
	echo '
<link rel="stylesheet" href="source/plugin/it618_scoremall/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_scoremall/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_scoremall/kindeditor/lang/zh_CN.js"></script>
<script>
	var shopuid=0;
	KindEditor.ready(function(K) {
				var editor = K.editor({
					allowFileManager : true
				});
				'.$editorjs.'
			});
</script>';

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_classname[]").length;
	
		return [
		[[1,''], [1,'<input type="text" class="txt" style=\"width:90px\" name="newit618_classname[]">'], [1,'<input id="c_add'+n+'_v" type="text" class="txt" style=\"width:80px;float:left\" name="newit618_color[]" onchange="updatecolorpreview(\'c_add'+n+'\')"><input id="c_add'+n+'" onclick="c_add'+n+'_frame.location=\'static/image/admincp/getcolor.htm?c_add'+n+'|c_add'+n+'_v\';showMenu({\'ctrlid\':\'c_add'+n+'\'})" type="button" class="colorwd" value="" style="background: "><span id="c_add'+n+'_menu" style="display: none"><iframe name="c_add'+n+'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>'], [1,''], [1,''], [1, ' <input class="txt" type="text" name="newit618_order[]">'], [1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	</script>
EOT;
	echo '<tr><td></td><td colspan="10"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />", $multipage);
	if(count($reabc)!=15)return;
showtablefooter();/*Dism��taobao��com*/
?>