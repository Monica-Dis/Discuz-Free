<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/function.func.php';
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_scoremall_focus', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_url'])) {
		foreach($_GET['it618_url'] as $id => $val) {

			C::t('#it618_scoremall#it618_scoremall_focus')->update($id,array(
				'it618_title' => trim($_GET['it618_title'][$id]),
				'it618_img' => trim($_GET['it618_img'][$id]),
				'it618_url' => trim($_GET['it618_url'][$id]),
				'it618_tip' => trim($_GET['it618_tip'][$id]),
				'it618_is' => intval($_GET['it618_is'][$id]),
				'it618_order' => intval($_GET['it618_order'][$id]),
			));
			it618_scoremall_getwapppic('wapad',$id,$_GET['it618_img'][$id],0);
			$ok1=$ok1+1;
		}
	}

	$newit618_title_array = !empty($_GET['newit618_title']) ? $_GET['newit618_title'] : array();
	$newit618_img_array = !empty($_GET['newit618_img']) ? $_GET['newit618_img'] : array();
	$newit618_url_array = !empty($_GET['newit618_url']) ? $_GET['newit618_url'] : array();
	$newit618_tip_array = !empty($_GET['newit618_tip']) ? $_GET['newit618_tip'] : array();
	$newit618_is_array = !empty($_GET['newit618_is']) ? $_GET['newit618_is'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	
	foreach($newit618_url_array as $key => $value) {

		C::t('#it618_scoremall#it618_scoremall_focus')->insert(array(
			'it618_title' => trim($newit618_title_array[$key]),
			'it618_img' => trim($newit618_img_array[$key]),
			'it618_url' => trim($newit618_url_array[$key]),
			'it618_tip' => trim($newit618_tip_array[$key]),
			'it618_is' => intval($newit618_is_array[$key]),
			'it618_order' => intval($newit618_order_array[$key]),
		), true);
		$ok2=$ok2+1;
	}

	cpmsg($it618_mall_lang['s39'].$ok1.' '.$it618_mall_lang['s40'].$ok2.' '.$it618_mall_lang['s41'].$del.')', "action=plugins&identifier=$identifier&cp=admin_focus&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

if(count($reabc)!=15)return;
if(submitcheck('it618sercsubmit')) {
		$extrasql = "AND it618_title LIKE '%".addcslashes(addslashes($_GET['beforeword']),'%_')."%'";	
}
showformheader("plugins&identifier=$identifier&cp=admin_focus&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($it618_mall_lang['s59'],'it618_scoremall_focus');
	showsubmit('it618sercsubmit', $it618_mall_lang['s63'], $it618_mall_lang['s64'].' <input name="beforeword" value="" class="txt" />');
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('it618_scoremall_focus')." w WHERE 1 $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_focus&pmod=admin_set&operation=$operation&do=$do");
	
	echo '<tr><td colspan=5>'.$it618_mall_lang['s65'].$count.'</td></tr>';
	showtablerow('', array('class="td25"', '', '', '', ''), array('', $it618_mall_lang['s66'],"<div style='width:390px'>".$it618_mall_lang['s67']."</div>","<div style='width:225px'>".$it618_mall_lang['s68']."</div>","<div style='width:100px'>".$it618_mall_lang['s69']."</div>"));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_focus')." WHERE 1 $extrasql ORDER BY it618_order desc LIMIT $startlimit, $ppp");
	while($it618_scoremall_focus =	DB::fetch($query)) {
		if($it618_scoremall_focus['it618_is']==1)$checked='checked="checked"';else $checked="";
		showtablerow('', array('class="td25"', '', '', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_scoremall_focus[id]\"><input type=\"hidden\" name=\"id[$it618_scoremall_focus[id]]\" value=\"$it618_scoremall_focus[id]\">",
			"<textarea class=\"txt\" style=\"width:200px;height:80px\" name=\"it618_title[$it618_scoremall_focus[id]]\">$it618_scoremall_focus[it618_title]</textarea>",
			'<img id="img'.$it618_scoremall_focus['id'].'" src="'.$it618_scoremall_focus['it618_img'].'" width="200" height="80" align="absmiddle" style="margin-right:3px"/><input class="txt" type="text" id="url'.$it618_scoremall_focus['id'].'" name="it618_img['.$it618_scoremall_focus['id'].']" readonly="readonly" value="'.$it618_scoremall_focus['it618_img'].'" /> <input type="button" id="image'.$it618_scoremall_focus['id'].'" value="'.$it618_mall_lang['s70'].'" />',
			'<textarea type="text" style="width:100px;height:80px" name="it618_url['.$it618_scoremall_focus['id'].']">'.$it618_scoremall_focus['it618_url'].'</textarea><textarea type="text" style="width:120px;height:80px;margin-left:5px" name="it618_tip['.$it618_scoremall_focus['id'].']">'.$it618_scoremall_focus['it618_tip'].'</textarea>',
			'<input class="checkbox" type="checkbox" name="it618_is['.$it618_scoremall_focus['id'].']" '.$checked.' value="1">/ <input class="txt" style="width:30px" type="text" name="it618_order['.$it618_scoremall_focus['id'].']" value="'.$it618_scoremall_focus['it618_order'].'">'
		));
		
		$editorjs.='K(\'#image'.$it618_scoremall_focus['id'].'\').click(function() {
					editor.loadPlugin(\'image\', function() {
						editor.plugin.imageDialog({
							imageUrl : K(\'#url'.$it618_scoremall_focus['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$it618_scoremall_focus['id'].'\').val(url);
								K(\'#img'.$it618_scoremall_focus['id'].'\').attr(\'src\',url);
								editor.hideDialog();
							}
						});
					});
				});';
	}
	
	echo '
<link rel="stylesheet" href="source/plugin/it618_scoremall/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_scoremall/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_scoremall/kindeditor/lang/zh_CN.js"></script>
<script>
	var shopuid=0;
	KindEditor.ready(function(K) {
				var editor = K.editor({
					allowFileManager : true
				});
				'.$editorjs.'
			});
</script>';

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	$it618_mall_lang71=$it618_mall_lang['s71'];
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_classname[]").length;
	
		return [
				[[1,''], [1,'<textarea type="text" class="txt" style=\"width:200px;height:80px\" name="newit618_title[]"></textarea>'], [1, '$it618_mall_lang71'], [1, ' <textarea class="txt" style=\"width:100px;height:80px\" name="newit618_url[]"></textarea><textarea class="txt" style=\"width:120px;height:80px\" name="newit618_tip[]"></textarea>'], [1, ' <input class="checkbox" type="checkbox" name="newit618_is[]" value="1">/ <input class="txt" style="width:30px" type="text" name="newit618_order[]" value="1">'], [1,'']]
				];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="5"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />", $multipage);
	if(count($reabc)!=15)return;
showtablefooter();/*Dism��taobao��com*/
?>