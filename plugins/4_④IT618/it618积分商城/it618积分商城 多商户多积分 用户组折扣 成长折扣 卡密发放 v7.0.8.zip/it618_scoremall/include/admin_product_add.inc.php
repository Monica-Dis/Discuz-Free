<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/function.func.php';
if(submitcheck('it618submit')){
	if($_GET['it618_class3_id']=='0'){
		cpmsg($it618_mall_lang['s92'], "action=plugins&identifier=$identifier&cp=admin_product_add&pmod=admin_product&operation=$operation&do=$do&page=$page", 'error');
	}
	if($_GET['it618_name']==''){
		cpmsg($it618_mall_lang['s93'], "action=plugins&identifier=$identifier&cp=admin_product_add&pmod=admin_product&operation=$operation&do=$do&page=$page", 'error');
	}
	if($_GET['it618_picbig']==''){
		cpmsg($it618_mall_lang['s94'], "action=plugins&identifier=$identifier&cp=admin_product_add&pmod=admin_product&operation=$operation&do=$do&page=$page", 'error');
	}
	
	$gp_array = !empty($_GET['gp']) ? $_GET['gp'] : array();
	foreach($gp_array as $key => $value) {
		$gp.=$value.',';
	}
	if($gp!='')$gp=str_replace(",,","",$gp.',');
	
	if($it618_scoremall['mall_credit']=='')$mall_credit=1;else $mall_credit=$it618_scoremall['mall_credit'];
	
	$pid=C::t('#it618_scoremall#it618_scoremall_goods')->insert(array(
		'it618_class3_id' => $_GET['it618_class3_id'],
		'it618_name' => $_GET['it618_name'],
		'it618_jfid' => $mall_credit,
		'it618_picbig' => $_GET['it618_picbig'],
		'it618_picbig1' => $_GET['it618_picbig1'],
		'it618_picbig2' => $_GET['it618_picbig2'],
		'it618_picbig3' => $_GET['it618_picbig3'],
		'it618_picbig4' => $_GET['it618_picbig4'],
		'it618_message' => $_GET['it618_message'],
		'it618_grouppower' => $gp,
		'it618_uid' => 0,
		'it618_state' => 2,
		'it618_updatetime' => $_G['timestamp']
	), true);
	
	for($i=0;$i<=4;$i++){
		if($i==0)$tmpi='';else $tmpi=$i;
		$get_it618_picbig=$_GET['it618_picbig'.$tmpi];
		
		if($get_it618_picbig!=''){
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/data/u0/smallimage/';
			if (!file_exists($smallpath)) {
				mkdir($smallpath);
			}

			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			$file_ext=strtolower(substr($get_it618_picbig,strrpos($get_it618_picbig, '.')+1)); 
			$file_extarr=explode("?",$file_ext);
			$file_ext=$file_extarr[0];
			$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/data/u0/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext;
			it618_scoremall_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,640,1);

		}
	}

	cpmsg($it618_mall_lang['s95'].$gp, "action=plugins&identifier=$identifier&cp=admin_product_add&pmod=admin_product&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_product_add&pmod=admin_product&operation=$operation&do=$do");
showtableheaders($it618_mall_lang['s96'],'it618_scoremall_goods');

$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class1')." ORDER BY it618_order DESC");
while($it618_tmp =	DB::fetch($query1)) {
	$class2count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_class2')." WHERE it618_class1_id=".$it618_tmp['id']);
	if($class2count>0){
		$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
}

$n=1;
$query = DB::query("SELECT * FROM ".DB::table('common_usergroup'));
while($common_usergroup = DB::fetch($query)) {
	$gpstr.='<input class="checkbox" type="checkbox" id="chk_gp'.$n.'" name="gp[]" value="'.$common_usergroup['groupid'].'"><label for="chk_gp'.$n.'">'.$common_usergroup['grouptitle'].'</label> ';
	$n=$n+1;
}
	
echo '
<link rel="stylesheet" href="source/plugin/it618_scoremall/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_scoremall/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_scoremall/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_scoremall/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_scoremall/kindeditor/plugins/code/prettify.js"></script>
<script>
	var shopuid=0;
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_scoremall/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_scoremall/kindeditor/php/upload_json.php?imgwidth=910'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_scoremall/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false
		});
		
		K(\'#image1\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url1\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url1\').val(url);
						K(\'#img1\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		K(\'#image11\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url11\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url11\').val(url);
						K(\'#img11\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		K(\'#image12\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url12\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url12\').val(url);
						K(\'#img12\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		K(\'#image13\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url13\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url13\').val(url);
						K(\'#img13\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
		K(\'#image14\').click(function() {
			editor1.loadPlugin(\'image\', function() {
				editor1.plugin.imageDialog({
					imageUrl : K(\'#url14\').val(),
					clickFn : function(url, title, width, height, border, align) {
						K(\'#url14\').val(url);
						K(\'#img14\').attr(\'src\',url);
						editor1.hideDialog();
					}
				});
			});
		});
		
	});
</script>
	
<tr><td width=60>'.$it618_mall_lang['s97'].'</td><td><select id="it618_class1_id" name="it618_class1_id" onchange="redirec_class2(this.options.selectedIndex);redirec_class3(0);"><option value="0">'.$it618_mall_lang['s98'].'</option>'.$tmp.'</select><select id="it618_class2_id" name="it618_class2_id" onchange="redirec_class3(this.options[this.options.selectedIndex].value);"><option value="0">'.$it618_mall_lang['s99'].'</option></select><select id="it618_class3_id" name="it618_class3_id"><option value="0">'.$it618_mall_lang['s100'].'</option></select></td></tr>
<tr><td>'.$it618_mall_lang['s101'].'</td><td><input type="text" class="txt" style="width:400px" name="it618_name" id="it618_name"></td></tr>
<tr><td>'.$it618_mall_lang['s104'].'</td><td><img id="img1" width="80" height="80" align="absmiddle"/><input type="text" id="url1" name="it618_picbig" readonly="readonly"/> <input type="button" id="image1" value="'.$it618_mall_lang['s105'].'" />   '.$it618_mall_lang['s106'].'</td></tr>
<tr><td></td><td><img id="img11"  width="80" height="80" align="absmiddle"/><input type="text" id="url11" name="it618_picbig1" readonly="readonly" /> <input type="button" id="image11" value="'.$it618_mall_lang['s105'].'" /> <input type="button" value="'.$it618_mall_lang['s107'].'" onclick="delpic(1)" /> <img id="img12"  width="80" height="80" align="absmiddle"/><input type="text" id="url12" name="it618_picbig2" readonly="readonly"/> <input type="button" id="image12" value="'.$it618_mall_lang['s105'].'" /> <input type="button" value="'.$it618_mall_lang['s107'].'" onclick="delpic(2)" /></td></tr>
<tr><td></td><td><img id="img13" width="80" height="80" align="absmiddle"/><input type="text" id="url13" name="it618_picbig3" readonly="readonly"/> <input type="button" id="image13" value="'.$it618_mall_lang['s105'].'"/> <input type="button" value="'.$it618_mall_lang['s107'].'" onclick="delpic(3)" />  <img id="img14" width="80" height="80" align="absmiddle"/><input type="text" id="url14" name="it618_picbig4" readonly="readonly"/> <input type="button" id="image14" value="'.$it618_mall_lang['s105'].'" /> <input type="button" value="'.$it618_mall_lang['s107'].'" onclick="delpic(4)" /></td></tr>
<tr><td>'.$it618_mall_lang['s109'].'</td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;"></textarea>'.$it618_mall_lang['s523'].'</td></tr>
<tr><td>'.$it618_mall_lang['s516'].'</td><td><div style="width:700px">'.$gpstr.'<br><input class="checkbox" type="checkbox" id="chk_gpall" onclick="check_all(this, \'chk_gp\')"><label for="chk_gpall">'.$it618_mall_lang['s415'].'</label> <font color=red>'.$it618_mall_lang['s517'].'</font><div></td></tr>
<tr><td colspan="2"><div class="fixsel"><input type="submit" class="btn" onclick="return checkvalue();" name="it618submit" value="'.$it618_mall_lang['s110'].'" /></div></td></tr>';

if(count($reabc)!=15)return;
showtablefooter();/*Dism��taobao��com*/

$count2 = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_class2'));
$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class1')." ORDER BY it618_order DESC");
$n1=1;
while($it618_tmp1 =	DB::fetch($query1)) {
	$class2count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_class2')." WHERE it618_class1_id=".$it618_tmp1['id']);
	if($class2count>0){
		$n2=1;
		$query2 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order DESC");
		while($it618_tmp2 =	DB::fetch($query2)) {
			$tmp2.='select_class2['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
			$n2=$n2+1;
		}
		$n1=$n1+1;
	}
}

$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class2')." ORDER BY it618_order");
$n1=1;
$n3=1;
while($it618_tmp1 =	DB::fetch($query1)) {
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." where it618_class2_id=".$it618_tmp1['id']." ORDER BY it618_order DESC");
	while($it618_tmp2 =	DB::fetch($query2)) {
		$tmp3.='select_class3['.$n3.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp1['id'].'_'.$it618_tmp2['id'].'");';
		$n3=$n3+1;
	}
	$n1=$n1+1;
}

echo '
<script>
var arrcount='.$count2.';
var select_class2 = new Array(arrcount+1);

for (i=0; i<arrcount+1; i++) 
{
 select_class2[i] = new Array();
}

'.$tmp2.'

function redirec_class2(x)
{
 var temp = document.getElementById("it618_class2_id"); 
 temp.options.length=1;
 for (i=1;i<select_class2[x].length;i++)
 {
  temp.options[i]=new Option(select_class2[x][i].text,select_class2[x][i].value);
 }
 temp.options[0].selected=true;
 
}

redirec_class2(document.getElementById("it618_class1_id").options.selectedIndex);



var arrcount='.$n3.';
var select_class3 = new Array(arrcount);

'.$tmp3.'

function redirec_class3(x)
{
 var temp = document.getElementById("it618_class3_id"); 
 temp.options.length=1;
 n=1;
 for (i=1;i<select_class3.length;i++)
 {
	 var tmparr=select_class3[i].value.split("_");
  	 if(tmparr[0]==x){
		 temp.options[n]=new Option(select_class3[i].text,tmparr[1]);
		 n=n+1;
	 }
 }
 temp.options[0].selected=true;

}

redirec_class3(document.getElementById("it618_class2_id").options[document.getElementById("it618_class2_id").options.selectedIndex].value);

function checkvalue(){
	if(document.getElementById("it618_class3_id").value=="0"){
		alert("'.$it618_mall_lang['s92'].'");
		return false;
	}
	if(document.getElementById("it618_name").value==""){
		alert("'.$it618_mall_lang['s93'].'");
		return false;
	}
	if(document.getElementById("url1").value==""){
		alert("'.$it618_mall_lang['s94'].'");
		return false;
	}
}

function check_all(obj,id)
{
	for(var i=1;i<'.$n.';i++)
	{
		document.getElementById(id+""+i).checked = obj.checked;
	}
}
</script>
'
?>