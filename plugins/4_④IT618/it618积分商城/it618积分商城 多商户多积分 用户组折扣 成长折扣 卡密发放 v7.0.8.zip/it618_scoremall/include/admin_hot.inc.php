<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if(C::t('#it618_scoremall#it618_scoremall_set')->count_by_setname('zjsalegoods')==0){
	C::t('#it618_scoremall#it618_scoremall_set')->insert(array(
		'setname' => 'zjsalegoods',
		'setvalue' => '8,1'
	), true);
	C::t('#it618_scoremall#it618_scoremall_set')->insert(array(
		'setname' => 'weeksalegoods',
		'setvalue' => '8,2'
	), true);
	C::t('#it618_scoremall#it618_scoremall_set')->insert(array(
		'setname' => 'newgoods',
		'setvalue' => '8,3'
	), true);
	C::t('#it618_scoremall#it618_scoremall_set')->insert(array(
		'setname' => 'hotgoods',
		'setvalue' => '8,4'
	), true);
}

if(submitcheck('it618submit')){
	
	$it618_scoremall_set=C::t('#it618_scoremall#it618_scoremall_set')->fetch_by_setname('zjsalegoods');
	C::t('#it618_scoremall#it618_scoremall_set')->update($it618_scoremall_set['id'],array(
		'setvalue' => $_GET['zjsalegoods']
	));
	
	$it618_scoremall_set=C::t('#it618_scoremall#it618_scoremall_set')->fetch_by_setname('weeksalegoods');
	C::t('#it618_scoremall#it618_scoremall_set')->update($it618_scoremall_set['id'],array(
		'setvalue' => $_GET['weeksalegoods']
	));
	
	$it618_scoremall_set=C::t('#it618_scoremall#it618_scoremall_set')->fetch_by_setname('newgoods');
	C::t('#it618_scoremall#it618_scoremall_set')->update($it618_scoremall_set['id'],array(
		'setvalue' => $_GET['newgoods']
	));
	
	$it618_scoremall_set=C::t('#it618_scoremall#it618_scoremall_set')->fetch_by_setname('hotgoods');
	C::t('#it618_scoremall#it618_scoremall_set')->update($it618_scoremall_set['id'],array(
		'setvalue' => $_GET['hotgoods']
	));

	cpmsg($it618_mall_lang['s965'], "action=plugins&identifier=$identifier&cp=admin_hot&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

$it618_scoremall_set=C::t('#it618_scoremall#it618_scoremall_set')->getsetvalue_by_setname($setname);
$value=explode('@@@',$it618_scoremall_set);

$zjsalegoods=C::t('#it618_scoremall#it618_scoremall_set')->getsetvalue_by_setname('zjsalegoods');
$weeksalegoods=C::t('#it618_scoremall#it618_scoremall_set')->getsetvalue_by_setname('weeksalegoods');
$newgoods=C::t('#it618_scoremall#it618_scoremall_set')->getsetvalue_by_setname('newgoods');
$hotgoods=C::t('#it618_scoremall#it618_scoremall_set')->getsetvalue_by_setname('hotgoods');

showformheader("plugins&identifier=$identifier&cp=admin_hot&cp1=$cp1&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($it618_mall_lang['s963'].'<span style="font-weight:normal;color:red;margin-left:230px">'.$it618_mall_lang['s964'].'</span>','it618_scoremall_set');

echo '
<tr><td>'.$it618_mall_lang['s987'].'</td><td>'.$it618_mall_lang['s991'].'<input type="text" name="zjsalegoods" style="width:80px;" value="'.$zjsalegoods.'">  '.$it618_mall_lang['s992'].'8,1</td></tr>
<tr><td>'.$it618_mall_lang['s988'].'</td><td>'.$it618_mall_lang['s991'].'<input type="text" name="weeksalegoods" style="width:80px;" value="'.$weeksalegoods.'"> '.$it618_mall_lang['s992'].'8,2</td></tr>
<tr><td>'.$it618_mall_lang['s989'].'</td><td>'.$it618_mall_lang['s991'].'<input type="text" name="newgoods" style="width:80px;" value="'.$newgoods.'"> '.$it618_mall_lang['s992'].'8,3</td></tr>
<tr><td>'.$it618_mall_lang['s990'].'</td><td>'.$it618_mall_lang['s991'].'<input type="text" name="hotgoods" style="width:80px;" value="'.$hotgoods.'"> '.$it618_mall_lang['s992'].'8,4</td></tr>
';

showsubmit('it618submit', $it618_mall_lang['s87']);
if(count($reabc)!=15)return;
showtablefooter();/*Dism��taobao��com*/

?>