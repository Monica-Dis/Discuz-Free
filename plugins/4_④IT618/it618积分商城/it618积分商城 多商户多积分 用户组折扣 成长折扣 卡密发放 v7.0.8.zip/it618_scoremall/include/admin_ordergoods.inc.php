<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/ordergoods.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/ordergoods.php';
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_scoremall/ordergoods.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$is_ordergoodsok=\''.trim($_GET['is_ordergoodsok'])."';\n";
		$fileData .= '$ordergoods_credit=\''.trim($_GET['ordergoods_credit'])."';\n";
		$fileData .= '$ordergoods_order=\''.trim($_GET['ordergoods_order'])."';\n";
		$fileData .= '$ordergoods_title=\''.trim($_GET['ordergoods_title'])."';\n";
		$fileData .= '$ordergoods_pccount=\''.trim($_GET['ordergoods_pccount'])."';\n";
		$fileData .= '$ordergoods_wapcount=\''.trim($_GET['ordergoods_wapcount'])."';\n";
		$fileData .= '$ordergoods_isfind=\''.trim($_GET['ordergoods_isfind'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_mall_lang['s812'], "action=plugins&identifier=$identifier&cp=admin_ordergoods&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

if(submitcheck('it618submit_update')){
	$ok=0;
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_htstate=1");
	while($it618_scoremall_store = DB::fetch($query)) {
		$creditnum=DB::result_first("select extcredits".$ordergoods_credit." from ".DB::table('common_member_count')." where uid=".$it618_scoremall_store['it618_uid']);
		if($creditnum=="")$creditnum=0;
		DB::query("update ".DB::table('it618_scoremall_goods')." set it618_jforder=".$creditnum." where it618_uid=".$it618_scoremall_store['it618_uid']);
		$ok=$ok+1;
	}
	cpmsg($it618_mall_lang['s809'].$ok, "action=plugins&identifier=$identifier&cp=admin_ordergoods&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_ordergoods&pmod=admin_set&operation=$operation&do=$do");

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		$extcredits.='<option value="'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].'</option>';
	}
}

$extcredits=str_replace('<option value="'.$ordergoods_credit.'"','<option value="'.$ordergoods_credit.'" selected="selected"',$extcredits);

$curjfname=$_G['setting']['extcredits'][$ordergoods_credit]['title'];

$it618_mall_lang['s806']=str_replace("{jfname}",$curjfname,$it618_mall_lang['s806']);
$it618_mall_lang['s813']=str_replace("{jfname}",$curjfname,$it618_mall_lang['s813']);

if($is_ordergoodsok==1)$is_ordergoodsok_checked='checked="checked"';else $is_ordergoodsok_checked='';
if($ordergoods_isfind==1)$ordergoods_isfind_checked='checked="checked"';else $ordergoods_isfind_checked='';

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_mall_lang['s796'].'</th></tr>
<tr><td colspan="15">'.$it618_mall_lang['s802'].'</th></tr>
<tr class="hover"><td width=230>'.$it618_mall_lang['s800'].'</td><td><input type="checkbox" id="is_ordergoodsok" name="is_ordergoodsok" value="1" style="vertical-align:middle" '.$is_ordergoodsok_checked.'><label for="is_ordergoodsok" style="color:green">'.$it618_mall_lang['s801'].'</label></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s797'].'</td><td><select name="ordergoods_credit">'.$extcredits.'</select>
</td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s804'].'</td><td><input name="ordergoods_order" value="'.$ordergoods_order.'" /> '.$it618_mall_lang['s805'].'</td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s798'].'</td><td><input name="ordergoods_title" value="'.$ordergoods_title.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s799'].'</td><td><input name="ordergoods_pccount" value="'.$ordergoods_pccount.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s803'].'</td><td><input name="ordergoods_wapcount" value="'.$ordergoods_wapcount.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s807'].'</td><td><input type="checkbox" id="ordergoods_isfind" name="ordergoods_isfind" value="1" style="vertical-align:middle" '.$ordergoods_isfind_checked.'><label for="ordergoods_isfind">'.$it618_mall_lang['s808'].'</label></td></tr>
<tr><td colspan=2>
<input type="submit" class="btn" name="it618submit" value="'.$it618_mall_lang['s810'].'" />
<input type="submit" class="btn" name="it618submit_update" value="'.$it618_mall_lang['s806'].'" onclick="return confirm(\''.$it618_mall_lang['s813'].'\')" />
</td></tr>
</table>
';

if(count($reabc)!=11)return;
showtablefooter();/*Dism��taobao��com*/

?>