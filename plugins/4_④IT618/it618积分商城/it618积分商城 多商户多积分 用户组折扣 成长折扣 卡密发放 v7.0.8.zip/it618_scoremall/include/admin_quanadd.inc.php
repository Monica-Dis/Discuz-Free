<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(isset($_GET['it618_bzfind'])){
	$bzfind=$_GET['it618_bzfind'];
}else{
	$bzfind='allquan';
}

if($bzfind!='allquan')$extrasql = " AND it618_bz LIKE '".addcslashes(addslashes($bzfind),'%_')."'";

$urlsql='&it618_bzfind='.$bzfind;

if(submitcheck('it618submit')){
	$del=0;
	
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_scoremall_quan', "id=$delid");
		$del=$del+1;
	}

	cpmsg($it618_mall_lang['s467'].$del, "action=plugins&identifier=$identifier&cp=admin_quanadd&pmod=admin_quan&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_clear')){
	DB::query("delete from ".DB::table('it618_scoremall_quan')." where it618_usetime=0 and it618_storeid=0");
	
	cpmsg($it618_mall_lang['s704'], "action=plugins&identifier=$identifier&cp=admin_quanadd&pmod=admin_quan&operation=$operation&do=$do&page=$page&pid=".$pid.$urlsql, 'succeed');
}

if(count($reabc)!=15)return;
if(submitcheck('it618submitadd')) {
	$it618_count=intval($_GET['it618_count']);
	if($_GET['chketime']==1){
		$it618_etime=explode(" ",$_GET['it618_etime']);
		$it618_date=explode("-",$it618_etime[0]);
		$it618_hour=explode(":",$it618_etime[1]);
		
		$it618_etime=mktime($it618_hour[0], $it618_hour[1], $it618_hour[2], $it618_date[1], $it618_date[2], $it618_date[0]);
		if($it618_etime<$_G['timestamp']){
			cpmsg($it618_mall_lang['s468'], "action=plugins&identifier=$identifier&cp=admin_quanadd&pmod=admin_quan&operation=$operation&do=$do&page=$page".$urlsql, 'error');
		}
	}else{
		$it618_etime=0;
	}
	$ok=0;
	$it618_addtime=$_G['timestamp'];
	for($i=0;$i<$it618_count;$i++){
		$id=C::t('#it618_scoremall#it618_scoremall_quan')->insert(array(
			'it618_storeid' => 0,
			'it618_adduid' => $_G['uid'],
			'it618_type' => $_GET['it618_type'],
			'it618_jfid' => $_GET['it618_jfid'],
			'it618_score' => $_GET['it618_score'],
			'it618_bz' => $_GET['it618_bz'],
			'it618_etime' => $it618_etime,
			'it618_addtime' => $it618_addtime
		), true);
		$tmpstr=strtoupper(md5('0'.$_G['uid'].$id));
		C::t('#it618_scoremall#it618_scoremall_quan')->update($id,array(
			'it618_code' => substr($tmpstr, 0, 9).substr($tmpstr, 23, 32)
		));
		$ok=$ok+1;
	}
	cpmsg($it618_mall_lang['s469'].$ok,"action=plugins&identifier=$identifier&cp=admin_quanadd&pmod=admin_quan&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(submitcheck('it618submit_data')){
	$strtmp=$it618_mall_lang['s480'].",".$it618_mall_lang['s481'].",".$it618_mall_lang['s482'].",".$it618_mall_lang['s483'].",".$it618_mall_lang['s686']."\n";
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_quan')." WHERE it618_usetime=0 and it618_storeid=0 $extrasql ORDER BY id DESC");
	while($it618_scoremall_quan = DB::fetch($query)) {
		if($it618_scoremall_quan['it618_type']==1){
			$it618_type=$it618_mall_lang['s473'];
		}else{
			$it618_type=$it618_mall_lang['s474'];
		}
		if($it618_scoremall_quan['it618_etime']==0){
			$it618_etime=$it618_mall_lang['s485'];
		}else{
			$it618_etime=date('Y-m-d H:i:s', $it618_scoremall_quan['it618_etime']);
		}
		
		$strtmp.=$it618_scoremall_quan['it618_code'].",".$it618_type.",".$it618_scoremall_quan['it618_score'].",".$it618_etime.",".$it618_scoremall_quan['it618_bz']."\n";
		$datacount=$datacount+1;
	}

	$timestr=date("YmdHis") . '_' . $datacount;
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/temp/admin/';
	it618_scoremall_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	cpmsg($it618_mall_lang['s1060'].'<a href="javascript:" onclick="window.open(\''.$_G['siteurl'].'source/plugin/it618_scoremall/temp/admin/'.$timestr.'.csv\')"><font color=red>'.$it618_mall_lang['s1061'].'</font></a>', "action=plugins&identifier=$identifier&cp=admin_quanadd&pmod=admin_quan&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}


//
$strtmp="";
for($i=2014;$i<=2020;$i++){
	if(date('Y')==$i){
		$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
}
$sel_year='<select id="sel_year" onclick="returnvalue()">'.$strtmp.'</select>';

//
$strtmp="";
for($i=1;$i<=12;$i++){
	if(date('n')==$i){
		$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
}
$sel_month='<select id="sel_month" onclick="returnvalue()">'.$strtmp.'</select>';

//
$strtmp="";
for($i=1;$i<=31;$i++){
	if(date('j')==$i){
		$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
}
$sel_date='<select id="sel_date" onclick="returnvalue()">'.$strtmp.'</select>';

//
$strtmp="";
for($i=0;$i<=23;$i++){
	if(0==$i){
		$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
}
$sel_hour='<select id="sel_hour" onclick="returnvalue()">'.$strtmp.'</select>';

//
$strtmp="";
for($i=0;$i<=59;$i++){
	if(0==$i){
		$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
}
$sel_minute='<select id="sel_minute" onclick="returnvalue()">'.$strtmp.'</select>';

//
$strtmp="";
for($i=0;$i<=59;$i++){
	if(0==$i){
		$strtmp.='<option value="'.towstr($i).'" selected="selected">'.towstr($i).'</option>';
	}else{
		$strtmp.='<option value="'.towstr($i).'">'.towstr($i).'</option>';
	}
}
$sel_second='<select id="sel_second" onclick="returnvalue()">'.$strtmp.'</select>';

function towstr($i){
	if(strlen($i)==1)return "0".$i;else return $i;
}

for($i=1;$i<=8;$i++){
	if($_G['setting']['extcredits'][$i]['title']!=''){
		$jfidstr.='<option value="'.$i.'">'.$_G['setting']['extcredits'][$i]['title'].'</option>';
	}
}

showformheader("plugins&identifier=$identifier&cp=admin_quanadd&pmod=admin_quan&operation=$operation&do=$do".$urlsql);
showtableheaders($it618_mall_lang['s705'],'it618_scoremall_quanadd');
	showsubmit('it618submitadd', $it618_mall_lang['s471'], $it618_mall_lang['s472'].'<select name="it618_type"><option value=1>'.$it618_mall_lang['s473'].'</option><option value=2>'.$it618_mall_lang['s474'].'</option></select> '.$it618_mall_lang['s998'].'<select name="it618_jfid">'.$jfidstr.'</select> '.$it618_mall_lang['s475'].'<input name="it618_count" value="" class="txt" style="width:50px" /> '.$it618_mall_lang['s476'].'<input name="it618_score" value="" class="txt" style="width:50px" /> '.$it618_mall_lang['s477'].'<input type="checkbox" id="chketime" name="chketime" style="vertical-align:middle" onclick="setetime(this)" value="1"/><input type="hidden" id="it618_etime" name="it618_etime"><span id="etime" style="display:none">'.$sel_year.$sel_month.$sel_date.$sel_hour.$sel_minute.$sel_second.'</span> '.$it618_mall_lang['s696'].'<input name="it618_bz" value="" class="txt" style="width:200px" />');
	DB::query("delete FROM ".DB::table('it618_scoremall_quan')." WHERE it618_etime<>0 and it618_etime<".$_G['timestamp']);
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('it618_scoremall_quan')." WHERE it618_usetime=0 and it618_storeid=0 $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_quanadd&pmod=admin_quan&operation=$operation&do=$do".$urlsql);
showtablefooter();/*Dism��taobao��com*/

showtableheaders($it618_mall_lang['s470'],'it618_scoremall_quanadd');
$it618_bzfind='<option value="allquan">'.$it618_mall_lang['s694'].'</option>';
$query = DB::query("SELECT count(1) as quancount,it618_bz FROM ".DB::table('it618_scoremall_quan')." WHERE it618_usetime=0 and it618_storeid=0 group by it618_bz");
while($it618_scoremall_quan = DB::fetch($query)) {
	$it618_bzfind.='<option value='.$it618_scoremall_quan['it618_bz'].'>'.$it618_scoremall_quan['it618_bz'].' ('.$it618_mall_lang['s695'].$it618_scoremall_quan['quancount'].')</option>';
}
$it618_bzfind=str_replace('<option value='.$_GET['it618_bzfind'].'>','<option value='.$_GET['it618_bzfind'].' selected="selected">',$it618_bzfind);

showsubmit('it618submitfind', $it618_mall_lang['s43'], $it618_mall_lang['s697'].' <select name="it618_bzfind">'.$it618_bzfind.'</select>');
	echo '<tr><td colspan=7>'.$it618_mall_lang['s478'].$count.'<span style="float:right;">'.$it618_mall_lang['s479'].'</span></td></tr>';
	showsubtitle(array('', $it618_mall_lang['s480'], $it618_mall_lang['s481'], $it618_mall_lang['s482'],$it618_mall_lang['s999'],$it618_mall_lang['s483'],$it618_mall_lang['s686'],$it618_mall_lang['s484']));
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_quan')." WHERE it618_usetime=0 and it618_storeid=0 $extrasql ORDER BY id DESC LIMIT $startlimit, $ppp");
	while($it618_scoremall = DB::fetch($query)) {
		if($it618_scoremall['it618_type']==1){
			$it618_type=$it618_mall_lang['s473'];
		}else{
			$it618_type=$it618_mall_lang['s474'];
		}
		if($it618_scoremall['it618_etime']==0){
			$it618_etime=$it618_mall_lang['s485'];
		}else{
			$it618_etime=date('Y-m-d H:i:s', $it618_scoremall['it618_etime']);
		}
		$jfname=$_G['setting']['extcredits'][$it618_scoremall['it618_jfid']]['title'];
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_scoremall[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_scoremall[id]]\" value=\"$it618_scoremall[id]\">",
			"<input type=\"text\" class=\"txt\" style=\"width:200px\" name=\"it618_code[$it618_scoremall[id]]\" value=\"$it618_scoremall[it618_code]\" onclick=\"this.select()\">",
			$it618_type,
			'<span style="color:#F60; font-weight:bold">'.$it618_scoremall['it618_score'].'</span>',
			$jfname,
			$it618_etime,
			$it618_scoremall['it618_bz'],
			date('Y-m-d H:i:s', $it618_scoremall['it618_addtime'])
		));

	}

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_mall_lang['s415'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit" value="'.$it618_mall_lang['s518'].'"/><input type="submit" class="btn" name="it618submit_clear" value="'.$it618_mall_lang['s706'].'" onclick="return confirm(\''.$it618_mall_lang['s956'].'\')"/><input type="submit" class="btn" name="it618submit_data" value="'.$it618_mall_lang['s519'].'"/><input type=hidden value='.$page.' name=page /></div></td></tr>';

	if(count($reabc)!=15)return;
showtablefooter();/*Dism��taobao��com*/
echo '<script>
function returnvalue(){
document.getElementById("it618_etime").value=document.getElementById("sel_year").value+"-"+document.getElementById("sel_month").value+"-"+document.getElementById("sel_date").value+" "+document.getElementById("sel_hour").value+":"+document.getElementById("sel_minute").value+":"+document.getElementById("sel_second").value;
}

function setetime(chkobj){
	if(chkobj.checked==true){
		document.getElementById("etime").style.display="";
		returnvalue();
	}else{
		document.getElementById("etime").style.display="none";
	}
}
</script>';
?>