<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
DB::query("delete from ".DB::table('it618_scoremall_kmpower'));
C::t('#it618_scoremall#it618_scoremall_kmpower')->insert(array(
	'it618_uid' => $_G['uid']
), true);
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if($_GET['key']) {
	$extrasql .= " AND g.it618_name LIKE '%".addcslashes(addslashes($_GET['key']),'%_')."%'";
}

if($_GET['findcode']) {
	$extrasql .= " AND s.it618_code LIKE '%".addcslashes(addslashes($_GET['findcode']),'%_')."%'";
}

if($_GET['finduid']) {
	$extrasql .= " AND s.it618_uid = ".intval($_GET['finduid']);
}

if($_GET['state']) {
	$state0='';$state1='';$state2='';$state3='';$state4='';$state5='';$state6='';
	if($_GET['state']==0){$extrasql .= "";$state0='selected="selected"';}
	if($_GET['state']==1){$extrasql .= " AND s.it618_state = 1";$state1='selected="selected"';}
	if($_GET['state']==2){$extrasql .= " AND s.it618_state = 2";$state2='selected="selected"';}
	if($_GET['state']==3){$extrasql .= " AND s.it618_state = 3";$state3='selected="selected"';}
	if($_GET['state']==4){$extrasql .= " AND s.it618_state = 4";$state4='selected="selected"';}
	if($_GET['state']==5){$extrasql .= " AND s.it618_state = 5";$state5='selected="selected"';}
	if($_GET['state']==6){$extrasql .= " AND s.it618_state = 6";$state6='selected="selected"';}
}

$sql='&key='.$_GET['key'].'&findcode='.$_GET['findcode'].'&finduid='.$_GET['finduid'].'&state='.$_GET['state'];

if(submitcheck('it618submit_del')){
	$del=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_scoremall_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$delid);
		$buyuid=$it618_scoremall_sale['it618_uid'];
		$saleuid=$it618_scoremall_sale['it618_saleuid'];
		if($it618_scoremall_sale['it618_state']==1){
			
			DB::delete('it618_scoremall_sale', "id=$delid");
			
			$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
			
			C::t('common_member_count')->increase($buyuid, array(
				'extcredits'.$it618_scoremall_sale['it618_jfid'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']))
			);
			if($it618_scoremall_sale['it618_jfid1']>0){
				C::t('common_member_count')->increase($buyuid, array(
					'extcredits'.$it618_scoremall_sale['it618_jfid1'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']))
				);
			}
			DB::delete('it618_scoremall_groupuplog', "it618_saleid=$delid");
			DB::query("update ".DB::table('it618_scoremall_groupup')." set it618_score=it618_score-".($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney'])." where it618_uid=".$buyuid);
			DB::query("update ".DB::table('it618_scoremall_goods')." set it618_salecount=it618_salecount-".$it618_scoremall_sale['it618_count'].",it618_count=it618_count+".$it618_scoremall_sale['it618_count']." where id=".$it618_scoremall_goods['id']);
			
			if($saleuid>0&&DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_store_groupuplog')." WHERE it618_saleid=".$delid)>0){
				C::t('common_member_count')->increase($saleuid, array(
					'extcredits'.$it618_scoremall_sale['it618_jfid'] => (0-($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']-$it618_scoremall_sale['it618_saletc'])))
				);
				if($it618_scoremall_sale['it618_jfid1']>0){
					C::t('common_member_count')->increase($saleuid, array(
						'extcredits'.$it618_scoremall_sale['it618_jfid1'] => (0-($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']-$it618_scoremall_sale['it618_saletc1'])))
					);
				}
				DB::delete('it618_scoremall_store_groupuplog', "it618_saleid=$delid");
				if($li1il11[0]!='i')return;
				DB::query("update ".DB::table('it618_scoremall_store_groupup')." set it618_score=it618_score-".($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1'])." where it618_uid=".$saleuid);
			}
						
			$del=$del+1;
		}
	}

	cpmsg($it618_mall_lang['s145'].$del.$it618_mall_lang['s146'], "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_yifahuo')){
	$ok=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_scoremall_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$delid);
		
		if($it618_scoremall_sale['it618_state']==1){
			DB::query("update ".DB::table('it618_scoremall_sale')." set it618_state=2 WHERE id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_mall_lang['s147'].$ok, "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_kd')){
	$ok=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_scoremall_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$delid);
		
		if($it618_scoremall_sale['it618_state']==2){
			C::t('#it618_scoremall#it618_scoremall_sale')->update($delid,array(
				'it618_kdid' => intval($_GET['it618_kdid'][$delid]),
				'it618_kddan' => $_GET['it618_kddan'][$delid]
			));
			$ok=$ok+1;
		}
	}

	cpmsg($it618_mall_lang['s417'].$ok, "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_tongyi')){
	$ok=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_scoremall_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$delid);
		$buyuid=$it618_scoremall_sale['it618_uid'];
		$saleuid=$it618_scoremall_sale['it618_saleuid'];
		if($it618_scoremall_sale['it618_state']==4){
			DB::query("update ".DB::table('it618_scoremall_sale')." set it618_state=5 WHERE id=".$delid);
			
			$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
			
			C::t('common_member_count')->increase($buyuid, array(
				'extcredits'.$it618_scoremall_sale['it618_jfid'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']))
			);
			if($it618_scoremall_sale['it618_jfid1']>0){
				C::t('common_member_count')->increase($buyuid, array(
					'extcredits'.$it618_scoremall_sale['it618_jfid1'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']))
				);
			}
			DB::delete('it618_scoremall_groupuplog', "it618_saleid=$delid");
			DB::query("update ".DB::table('it618_scoremall_groupup')." set it618_score=it618_score-".($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney'])." where it618_uid=".$buyuid);
			DB::query("update ".DB::table('it618_scoremall_goods')." set it618_salecount=it618_salecount-".$it618_scoremall_sale['it618_count'].",it618_count=it618_count+".$it618_scoremall_sale['it618_count']." where id=".$it618_scoremall_goods['id']);
			
			if($saleuid>0&&DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_store_groupuplog')." WHERE it618_saleid=".$delid)>0){
				C::t('common_member_count')->increase($saleuid, array(
					'extcredits'.$it618_scoremall_sale['it618_jfid'] => (0-($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']-$it618_scoremall_sale['it618_saletc'])))
				);
				if($it618_scoremall_sale['it618_jfid1']>0){
					C::t('common_member_count')->increase($saleuid, array(
						'extcredits'.$it618_scoremall_sale['it618_jfid1'] => (0-($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']-$it618_scoremall_sale['it618_saletc1'])))
					);
				}
				DB::delete('it618_scoremall_store_groupuplog', "it618_saleid=$delid");
				if($li1il11[0]!='i')return;
				DB::query("update ".DB::table('it618_scoremall_store_groupup')." set it618_score=it618_score-".($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1'])." where it618_uid=".$saleuid);
			}
			$ok=$ok+1;
		}
	}

	cpmsg($it618_mall_lang['s244'].$ok, "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_jujue')){
	$ok=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_scoremall_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$delid);
		
		if($it618_scoremall_sale['it618_state']==4){
			DB::query("update ".DB::table('it618_scoremall_sale')." set it618_state=6 WHERE id=".$delid);
			$ok=$ok+1;
		}
	}

	cpmsg($it618_mall_lang['s245'].$ok, "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_yishouhuo')){
	$ok=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$it618_scoremall_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$delid);
		$buyuid=$it618_scoremall_sale['it618_uid'];
		$saleuid=$it618_scoremall_sale['it618_saleuid'];
		if($it618_scoremall_sale['it618_state']==2||$it618_scoremall_sale['it618_state']==6){
			DB::query("update ".DB::table('it618_scoremall_sale')." set it618_state=3 WHERE id=".$delid);
			it618_scoremall_qrxf($it618_scoremall_sale);
			$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
			
			if($saleuid>0&&DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_store_groupuplog')." WHERE it618_saleid=".$delid)==0){
				C::t('common_member_count')->increase($saleuid, array(
					'extcredits'.$it618_scoremall_sale['it618_jfid'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']-$it618_scoremall_sale['it618_saletc']))
				);
				if($it618_scoremall_sale['it618_jfid1']>0){
					C::t('common_member_count')->increase($saleuid, array(
						'extcredits'.$it618_scoremall_sale['it618_jfid1'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']-$it618_scoremall_sale['it618_saletc1']))
					);
				}
				$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
				$it618_score=DB::result_first("select it618_score from ".DB::table('it618_scoremall_store_groupup')." where it618_uid=".$it618_scoremall_sale['it618_saleuid']);
				$id = C::t('#it618_scoremall#it618_scoremall_store_groupuplog')->insert(array(
					'it618_uid' => $it618_scoremall_sale['it618_saleuid'],
					'it618_saleid' => $it618_scoremall_sale['id'],
					'it618_score' => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']),
					'it618_curallscore' => ($it618_score+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']),
					'it618_bz' => $it618_mall_lang['s344'].$it618_scoremall_sale['it618_count'].$it618_mall_lang['s203'].'<a href="'.$tmpurl.'" title="'.$it618_scoremall_goods['it618_name'].'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a>',
					'it618_time' => $_G['timestamp']
				), true);
				DB::query("update ".DB::table('it618_scoremall_store_groupup')." set it618_score=it618_score+".($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1'])." where it618_uid=".$it618_scoremall_sale['it618_saleuid']);
			}
			$ok=$ok+1;
		}
	}

	cpmsg($it618_mall_lang['s666'].$ok, "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_data')){
	
	$strtmp=$it618_mall_lang['s556']."\n";
	$query = DB::query("SELECT s.* FROM ".DB::table('it618_scoremall_sale')." s,".DB::table('it618_scoremall_goods')." g WHERE s.it618_pid=g.id $extrasql order by it618_pid,it618_time desc");
	while($it618_scoremall_sale = DB::fetch($query)) {
		$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
		
		$strtmp.=$it618_scoremall_goods['it618_name'].",".$it618_scoremall_sale['it618_count'].",".it618_scoremall_getusername($it618_scoremall_sale['it618_uid']).",".$it618_scoremall_sale['it618_addr'].$it618_scoremall_sale['it618_bz'].",".$it618_scoremall_sale['it618_code'].",".date('Y-m-d H:i:s', $it618_scoremall_sale['it618_time'])."\n";
		$datacount=$datacount+1;
	}

	$timestr=date("YmdHis") . '_' . $datacount;
	$datapath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/temp/admin/';
	it618_scoremall_delfile($datapath);
	
	@$fp = fopen($datapath.$timestr.'.csv',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		fwrite($fp,$strtmp);
		fclose($fp);
	}
	
	cpmsg($it618_mall_lang['s1060'].'<a href="javascript:" onclick="window.open(\''.$_G['siteurl'].'source/plugin/it618_scoremall/temp/admin/'.$timestr.'.csv\')"><font color=red>'.$it618_mall_lang['s1061'].'</font></a>', "action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=15)return;

echo '
<link rel="stylesheet" href="source/plugin/it618_scoremall/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_scoremall/kindeditor/kindeditor-min.js"></script>
';

showformheader("plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do");
showtableheaders($it618_mall_lang['s148'],'it618_scoremall_sum');
	showsubmit('it618sercsubmit', $it618_mall_lang['s149'], $it618_mall_lang['s150'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.$it618_mall_lang['s522'].' <input name="findcode" value="'.$_GET['findcode'].'" class="txt" style="width:155px" />'.$it618_mall_lang['s151'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" /> '.$it618_mall_lang['s152'].' <select name="state"><option value=0 '.$state0.'>'.$it618_mall_lang['s153'].'</option><option value=1 '.$state1.'>'.$it618_mall_lang['s154'].'</option><option value=2 '.$state2.'>'.$it618_mall_lang['s155'].'</option><option value=3 '.$state3.'>'.$it618_mall_lang['s156'].'</option><option value=4 '.$state4.'>'.$it618_mall_lang['s157'].'</option><option value=5 '.$state5.'>'.$it618_mall_lang['s246'].'</option><option value=6 '.$state6.'>'.$it618_mall_lang['s247'].'</option></select>');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_sale')." s,".DB::table('it618_scoremall_goods')." g WHERE s.it618_pid=g.id $extrasql");
	$count1 = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_sale')." s,".DB::table('it618_scoremall_goods')." g WHERE s.it618_state = 5 and g.it618_uid=".$_G['uid']." and s.it618_pid=g.id ". $extrasql);
	if($_GET['state']==0)$tuihuo=' '.$it618_mall_lang['s248'].$count1;
	
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_sale&pmod=admin_sale&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=18>'.$it618_mall_lang['s158'].$count.$tuihuo.'<span style="float:right;color:blue">'.$it618_mall_lang['s1049'].'</span></td></tr>';
	showsubtitle(array('', $it618_mall_lang['s160'],$it618_mall_lang['s161'].'/'.$it618_mall_lang['s162'].'/'.$it618_mall_lang['s473'],$it618_mall_lang['s163'],$it618_mall_lang['s164'].'/'.$it618_mall_lang['s254'].'/'.$it618_mall_lang['s255'],$it618_mall_lang['s253'],$it618_mall_lang['s165'],$it618_mall_lang['s411'],$it618_mall_lang['s166'],$it618_mall_lang['s167'],$it618_mall_lang['s168']));
	
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_kd')." ORDER BY it618_order DESC");
	$tmp.='<option value="0">'.$it618_mall_lang['s412'].'</option>';
	while($it618_tmp =	DB::fetch($query1)) {
		$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
	}
	$query = DB::query("SELECT s.* FROM ".DB::table('it618_scoremall_sale')." s,".DB::table('it618_scoremall_goods')." g WHERE s.it618_pid=g.id $extrasql order by id desc LIMIT $startlimit, $ppp");
	while($it618_scoremall_sale = DB::fetch($query)) {
		
		$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
		$it618_class3_id=$it618_scoremall_goods['it618_class3_id'];
		$it618_name=$it618_scoremall_goods['it618_name'];
		$it618_picsmall=it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']);
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_scoremall_sale['it618_uid']);
		
		if($it618_scoremall_sale['it618_state']==2){
			$tmp1=str_replace('<option value='.$it618_scoremall_sale['it618_kdid'].'>','<option value='.$it618_scoremall_sale['it618_kdid'].' selected="selected">',$tmp);
			$strkd='<font color=green>'.$it618_mall_lang['s413'].'<select name="it618_kdid['.$it618_scoremall_sale[id].']">'.$tmp1.'</select><br>'.$it618_mall_lang['s414'].'<input type="text" class="txt" style="width:112px" name="it618_kddan['.$it618_scoremall_sale[id].']" value="'.$it618_scoremall_sale['it618_kddan'].'"></font>';
		}else{
			if($it618_scoremall_sale['it618_kdid']!=0&&$it618_scoremall_sale['it618_kddan']!=''){
				$it618_scoremall_kd=DB::fetch_first("select * from ".DB::table('it618_scoremall_kd')." WHERE id=".$it618_scoremall_sale['it618_kdid']);
				$strkd=''.$it618_mall_lang['s413'].'<a href="'.$it618_scoremall_kd['it618_url'].'" target="_blank">'.$it618_scoremall_kd['it618_name'].'</a><br>'.$it618_mall_lang['s414'].'<font color=green>'.$it618_scoremall_sale['it618_kddan'].'</font>';
			}else{
				$strkd='';	
			}
		}
		
		$strcontent='';$strtmp='';

		if(count(explode($it618_mall_lang['s30'],$it618_scoremall_sale['it618_addr']))>1){
			$strtmp=$it618_mall_lang['s169'];
		}else{
			$strtmp='';
			$strkd='';
		}
		if($it618_scoremall_sale['it618_bz']!=""){
			$strtmp.=$it618_mall_lang['s171'];
			if($strtmp==$it618_mall_lang['s171']){
				$strtmp=str_replace('/','',$strtmp);
			}
		}else{
			$strtmp.='';
		}
		$strtmp='<a href="javascript:" id="bz'.$it618_scoremall_sale[id].'">'.$strtmp.'</a>';
		
		if($it618_scoremall_sale['it618_state']==1)$it618_state='<font color=red>'.$it618_mall_lang['s173'].'</font>';
		if($it618_scoremall_sale['it618_state']==2)$it618_state='<font color=green>'.$it618_mall_lang['s174'].'</font>';
		if($it618_scoremall_sale['it618_state']==3)$it618_state='<font color=green>'.$it618_mall_lang['s175'].'</font>';
		if($it618_scoremall_sale['it618_state']==4)$it618_state='<font color=red>'.$it618_mall_lang['s176'].'</font>';
		if($it618_scoremall_sale['it618_state']==5)$it618_state='<font color=#999>'.$it618_mall_lang['s246'].'</font>';
		if($it618_scoremall_sale['it618_state']==6)$it618_state='<font color=blue>'.$it618_mall_lang['s247'].'</font>';
		
		if($it618_scoremall_sale[it618_saleuid]==0){
			$saleuser=$it618_mall_lang['s227'];
		}else{
			$saleuser='<a href="home.php?mod=space&uid='.$it618_scoremall_goods['it618_uid'].'" target="_blank">'.it618_scoremall_getusername($it618_scoremall_goods[it618_uid]).'</a>';
		}
		
		if($it618_scoremall_sale['it618_code']!=''){
			$strcode=' '.$it618_mall_lang['s521'].$it618_scoremall_sale['it618_code'];
		}else{
			$strcode='';
		}
		
		$it618_kmcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods_salekm')." where it618_saleid=".$it618_scoremall_sale['id']);
		if($it618_scoremall_sale['it618_km']!=''||$it618_kmcount>0){
			$strkm='<a href="javascript:" id="km'.$it618_scoremall_sale[id].'">'.it618_mall_getlang('s441').'</a>';
			
		}else{
			$strkm='';
		}
		
		$jfname=$_G['setting']['extcredits'][$it618_scoremall_sale['it618_jfid']]['title'];
		$it618_price1='';
		if($it618_scoremall_sale['it618_price1']>0){
			$jfname1=$_G['setting']['extcredits'][$it618_scoremall_sale['it618_jfid1']]['title'];
			$it618_price1=' + '.$it618_scoremall_sale['it618_price1'].$jfname1;
		}
		
		$it618_quanmoney='';
		if($it618_scoremall_sale['it618_quanmoney']>0){
			$it618_quanmoney=$it618_scoremall_sale['it618_quanmoney'].$jfname;
		}
		if($it618_scoremall_sale['it618_quanmoney1']>0){
			$it618_quanmoney=$it618_scoremall_sale['it618_quanmoney1'].$jfname1;
		}
		
		$it618_money1='';
		if($it618_scoremall_sale['it618_price1']>0){
			$it618_money1=' + '.intval($it618_scoremall_sale['it618_price1']*$it618_scoremall_sale['it618_count']-$it618_scoremall_sale['it618_quanmoney1']).$jfname1;
		}
		
		$it618_saletc='';
		if($it618_scoremall_sale['it618_saletc']>0){
			$it618_saletc=$it618_scoremall_sale['it618_saletc'].$jfname;
		}
		
		$it618_saletc1='';
		if($it618_scoremall_sale['it618_saletc1']>0){
			$it618_saletc1=' + '.$it618_scoremall_sale['it618_saletc1'].$jfname1;
		}
		
		$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_scoremall_sale[id].'" name="delete[]" value="'.$it618_scoremall_sale[id].'"><input type="hidden" name="id['.$it618_scoremall_sale[id].']" value="'.$it618_scoremall_sale[id].'"><label for="chk_del'.$it618_scoremall_sale[id].'" title="'.$strcode.'">'.$it618_scoremall_sale['id'].'</label>',
			'<a href="'.$tmpurl.'" title="'.$it618_mall_lang['s177'].''.$it618_scoremall_sale['it618_pid'].' '.$it618_mall_lang['s178'].''.it618_scoremall_class1name($it618_class3_id).' '.it618_scoremall_class2name($it618_class3_id).' '.it618_scoremall_class3name($it618_class3_id).'" target="_blank"><img style="float:left;" src="'.$it618_picsmall.'" width="50" height="50" align="absmiddle"/><div style="float:left;width:180px;margin-left:3px">'.$it618_name.'</a>',
			$it618_scoremall_sale['it618_price'].$jfname.$it618_price1.'<br>'.$it618_scoremall_sale['it618_zk'].'%'.'<br>'.$it618_quanmoney,
			$it618_scoremall_sale['it618_count'],
			intval($it618_scoremall_sale['it618_price']*$it618_scoremall_sale['it618_count']-$it618_scoremall_sale['it618_quanmoney']).$jfname.$it618_money1.'<br>'.$it618_scoremall_sale['it618_tc'].'%'.'<br>'.$it618_saletc.$it618_saletc1,
			'<div style="width:50px">'.$saleuser.'</div>',
			$strtmp,
			$strkd,
			$it618_state.'<br>'.$strkm,
			'<div style="width:50px"><a href="home.php?mod=space&uid='.$it618_scoremall_sale['it618_uid'].'" target="_blank">'.it618_scoremall_getusername($it618_scoremall_sale['it618_uid']).'</a></div>',
			'<div style="width:75px">'.date('Y-m-d H:i:s', $it618_scoremall_sale['it618_time']).'</div>'
		));
		$tmpjs.='KindEditor.ready(function(K) {K(\'#bz'.$it618_scoremall_sale[id].'\').click(function() {
			var dialog = K.dialog({
				width : 538,
				title : \''.$it618_mall_lang['s179'].'\',
				body : \'<div><iframe id="frm" src="plugin.php?id=it618_scoremall:adminshowsalemsg&saleid='.$it618_scoremall_sale[id].'" style="border:0;" frameborder=0 width="520" height="180"></iframe></div>\',
				closeBtn : {
					name : \''.$it618_mall_lang['s180'].'\',
					click : function(e) {
						dialog.remove();
					}
				},
				noBtn : {
					name : \''.$it618_mall_lang['s180'].'\',
					click : function(e) {
						dialog.remove();
					}
				}
			});
		});});
		
		KindEditor.ready(function(K) {K(\'#km'.$it618_scoremall_sale[id].'\').click(function() {
			var dialog = K.dialog({
				width : 538,
				title : \''.$it618_mall_lang['s441'].'\',
				body : \'<div style="margin:10px;"><iframe id="frm" src="plugin.php?id=it618_scoremall:adminshowkm&saleid='.$it618_scoremall_sale[id].'" style="border:0;" frameborder=0 width="600" height="330"></iframe></div>\',
				closeBtn : {
					name : \''.$it618_mall_lang['s180'].'\',
					click : function(e) {
						dialog.remove();
					}
				},
				noBtn : {
					name : \''.$it618_mall_lang['s180'].'\',
					click : function(e) {
						dialog.remove();
					}
				}
			});
		});});';
	}

	function it618_scoremall_class1name($aid){
		$class2id = DB::result_first("select it618_class2_id from ".DB::table('it618_scoremall_class3')." where id=".$aid);
		$class1id = DB::result_first("select it618_class1_id from ".DB::table('it618_scoremall_class2')." where id=".$class2id);
		return DB::result_first("select it618_classname from ".DB::table('it618_scoremall_class1')." where id=".$class1id);
	}
	
	function it618_scoremall_class2name($aid){
		$class2id = DB::result_first("select it618_class2_id from ".DB::table('it618_scoremall_class3')." where id=".$aid);
		return DB::result_first("select it618_classname from ".DB::table('it618_scoremall_class2')." where id=".$class2id);
	}
	
	function it618_scoremall_class3name($aid){
		return DB::result_first("select it618_classname from ".DB::table('it618_scoremall_class3')." where id=".$aid);
	}
	
	function it618_scoremall_getusername($uid){
		return DB::result_first("select username from ".DB::table('common_member')." where uid=".$uid);
	}
	$sql=str_replace("(","it618_str1",$sql);
	$sql=str_replace(")","it618_str2",$sql);
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_mall_lang['s415'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.$it618_mall_lang['s182'].'" onclick="return confirm(\''.$it618_mall_lang['s183'].'\')" /> <input type="submit" class="btn" name="it618submit_yifahuo" value="'.$it618_mall_lang['s184'].'" onclick="return confirm(\''.$it618_mall_lang['s185'].'\')"/> <input type="submit" class="btn" name="it618submit_kd" value="'.$it618_mall_lang['s416'].'"/> <input type="submit" class="btn" name="it618submit_tongyi" value="'.$it618_mall_lang['s256'].'" onclick="return confirm(\''.$it618_mall_lang['s257'].'\')"/> <input type="submit" class="btn" name="it618submit_jujue" value="'.$it618_mall_lang['s258'].'" onclick="return confirm(\''.$it618_mall_lang['s259'].'\')"/> <input type="submit" class="btn" style="color:red" name="it618submit_yishouhuo" value="'.$it618_mall_lang['s667'].'" onclick="return confirm(\''.$it618_mall_lang['s668'].'\')"/> <input type="submit" class="btn" name="it618submit_data" value="'.$it618_mall_lang['s555'].'"/> <br>'.$it618_mall_lang['s186'].' &nbsp;<input type=hidden value='.$page.' name=page /></div></td></tr>';

	if(count($reabc)!=15)return;
showtablefooter();/*Dism��taobao��com*/
echo '<script>'.$tmpjs.'</script>';
?>