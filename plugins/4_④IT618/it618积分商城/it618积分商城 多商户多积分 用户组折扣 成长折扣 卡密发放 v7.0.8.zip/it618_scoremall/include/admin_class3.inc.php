<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_class1'));
if($count==0){
	cpmsg($it618_mall_lang['s1062'], "action=plugins&identifier=$identifier&cp=admin_class1&pmod=admin_class&operation=$operation&do=$do", 'error');	
}

$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_class2'));
if($count==0){
	cpmsg($it618_mall_lang['s1063'], "action=plugins&identifier=$identifier&cp=admin_class2&pmod=admin_class&operation=$operation&do=$do", 'error');	
}

$n=1;
$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class2')." ORDER BY it618_order");
while($it618_tmp =	DB::fetch($query1)) {
	if(isset($_GET['classid'])){
		if($_GET['classid']==$it618_tmp['id']){
			$licss='class="current"';
			$classid=$it618_tmp['id'];
		}else{
			$licss='';
		}
	}else{
		if($n==1){
			$licss='class="current"';
			$classid=$it618_tmp['id'];
		}else{
			$licss='';
		}
	}
	
	if($it618_tmp['id']==$classid)$tmpadd2.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('it618_scoremall_class3')." w WHERE it618_class2_id=".$it618_tmp['id']);
	
	$submenu.='<li '.$licss."><a href=\"".ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_class3&pmod=admin_class&classid=".$it618_tmp['id']."&operation=$operation&do=$do&page=$page\"><span>".$it618_tmp['it618_classname'].'(<font color=red>'.$count.'</font>)</span></a></li>';
	
	$n=$n+1;
}
$tmpadd2=str_replace('<option value='.$classid.'>','<option value='.$classid.' selected="selected">',$tmpadd2);

$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class1')." ORDER BY it618_order DESC");
while($it618_tmp =	DB::fetch($query1)) {
	$class2count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_class2')." WHERE it618_class1_id=".$it618_tmp['id']);
	if($class2count>0){
		$tmpadd1.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
	}
}
$it618_class1_id = DB::result_first("SELECT it618_class1_id FROM ".DB::table('it618_scoremall_class2')." WHERE id=".$classid);
$tmpadd1=str_replace('<option value='.$it618_class1_id.'>','<option value='.$it618_class1_id.' selected="selected">',$tmpadd1);

echo '<div class="itemtitle" style="width:100%;margin-bottom:5px;margin-top:3px"><ul class="tab1" id="submenu">'.$submenu.'</ul></div>';

$extrasql .= "it618_class2_id =".$classid;
$urlsql='&classid='.$classid;

if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_scoremall_class3', "id=$delid");
		$del=$del+1;
	}

	if(is_array($_GET['it618_classname'])) {
		foreach($_GET['it618_classname'] as $id => $val) {

			C::t('#it618_scoremall#it618_scoremall_class3')->update($id,array(
				'it618_class2_id' => trim($_GET['it618_class2_id'][$id]),
				'it618_classname' => trim($_GET['it618_classname'][$id]),
				'it618_color' => trim($_GET['it618_color'][$id]),
				'it618_order' => trim($_GET['it618_order'][$id]),
				'it618_homeposition' => trim($_GET['it618_homeposition'][$id]),
				'it618_homecount' => trim($_GET['it618_homecount'][$id]),
				'it618_homeordertype' => trim($_GET['it618_homeordertype'][$id]),
				'it618_homewapcount' => trim($_GET['it618_homewapcount'][$id]),
				'it618_istj' => trim($_GET['it618_istj'][$id])
			));
			$ok1=$ok1+1;
		}
	}
	
	$newit618_class2_id_array = !empty($_GET['newit618_class2_id']) ? $_GET['newit618_class2_id'] : array();
	$newit618_classname_array = !empty($_GET['newit618_classname']) ? $_GET['newit618_classname'] : array();
	$newit618_color_array = !empty($_GET['newit618_color']) ? $_GET['newit618_color'] : array();
	$newit618_order_array = !empty($_GET['newit618_order']) ? $_GET['newit618_order'] : array();
	$newit618_istj_array = !empty($_GET['newit618_istj']) ? $_GET['newit618_istj'] : array();
	
	foreach($newit618_classname_array as $key => $value) {
		$newit618_classname = addslashes(trim($newit618_classname_array[$key]));
		
		if($newit618_classname != '') {
			
			C::t('#it618_scoremall#it618_scoremall_class3')->insert(array(
				'it618_class2_id' => trim($newit618_class2_id_array[$key]),
				'it618_classname' => trim($newit618_classname_array[$key]),
				'it618_color' => trim($newit618_color_array[$key]),
				'it618_order' => trim($newit618_order_array[$key]),
				'it618_istj' => trim($newit618_istj_array[$key])
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_mall_lang['s39'].$ok1.' '.$it618_mall_lang['s40'].$ok2.' '.$it618_mall_lang['s41'].$del.')', "action=plugins&identifier=$identifier&cp=admin_class3&pmod=admin_class&operation=$operation&do=$do&page=$page".$urlsql, 'succeed');
}

if(count($reabc)!=15)return;
if(submitcheck('it618sercsubmit')) {
	if($_GET['beforeword']) {
		$extrasql.= " AND it618_classname LIKE '%".addcslashes(addslashes($_GET['beforeword']),'%_')."%'";
	}
}
showformheader("plugins&identifier=$identifier&cp=admin_class3&pmod=admin_class&operation=$operation&do=$do".$urlsql);
showtableheaders($it618_mall_lang['s54'],'it618_scoremall_class3');
	showsubmit('it618sercsubmit', $it618_mall_lang['s43'], $it618_mall_lang['s44'].' <input name="beforeword" value="'.$_GET['beforeword'].'" class="txt" />');
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('it618_scoremall_class3')." WHERE $extrasql");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_class3&pmod=admin_class&operation=$operation&do=$do".$urlsql);
	
	echo '<tr><td colspan=10>'.$it618_mall_lang['s45'].$count.'<span style="float:right">'.$it618_mall_lang['s407'].'</span></td></tr>';
	showsubtitle(array('', $it618_mall_lang['s55'],$it618_mall_lang['s56'], $it618_mall_lang['s47'],$it618_mall_lang['s636'],$it618_mall_lang['s48'],$it618_mall_lang['s57'],$it618_mall_lang['s408']));
	
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class1')." ORDER BY it618_order DESC");
	while($it618_tmp =	DB::fetch($query1)) {
		$class2count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_class2')." WHERE it618_class1_id=".$it618_tmp['id']);
		if($class2count>0){
			$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_classname'].'</option>';
		}
	}
		
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." WHERE $extrasql ORDER BY it618_order DESC LIMIT $startlimit, $ppp");
	while($it618_scoremall = DB::fetch($query)) {
		$goodscount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_goods')." WHERE it618_class3_id=".$it618_scoremall['id']);
		$disabled="";
		if($goodscount>0)$disabled="disabled=\"disabled\"";
		
		$it618_class1_id = DB::result_first("SELECT it618_class1_id FROM ".DB::table('it618_scoremall_class2')." WHERE id=".$it618_scoremall['it618_class2_id']);
		$tmp1=str_replace('<option value='.$it618_class1_id.'>','<option value='.$it618_class1_id.' selected="selected">',$tmp);
		
		if($it618_class1_id=='')$it618_class1_id=0;
		$query11 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class2')." where it618_class1_id=".$it618_class1_id." ORDER BY it618_order DESC");
		$indextmp=1;
		$index=0;
		while($it618_tmp =	DB::fetch($query11)) {
			if($it618_tmp['id']==$it618_scoremall['it618_class2_id']){
				$index=$indextmp;
			}
			$indextmp+=1;
		}
		$jstmp.='redirec_class(document.getElementById("it618_class1_id'.$it618_scoremall['id'].'").options.selectedIndex,'.$it618_scoremall['id'].');redirec_class_sel('.$it618_scoremall['id'].','.$index.');';
		if($it618_scoremall['it618_istj']==1)$it618_istj_checked='checked="checked"';else $it618_istj_checked="";
		
		$it618_homeposition='<select name="it618_homeposition['.$it618_scoremall['id'].']"><option value="1">'.$it618_mall_lang['s639'].'</option><option value="2">'.$it618_mall_lang['s640'].'</option><option value="3">'.$it618_mall_lang['s641'].'</option></select>';
		$it618_homeposition=str_replace('value="'.$it618_scoremall['it618_homeposition'].'"','value="'.$it618_scoremall['it618_homeposition'].'" selected="selected"',$it618_homeposition);
		
		$it618_homeordertype='<select name="it618_homeordertype['.$it618_scoremall['id'].']"><option value="1">'.$it618_mall_lang['s642'].'</option><option value="2">'.$it618_mall_lang['s643'].'</option><option value="3">'.$it618_mall_lang['s644'].'</option><option value="4">'.$it618_mall_lang['s645'].'</option><option value="5">'.$it618_mall_lang['s766'].'</option><option value="6">'.$it618_mall_lang['s767'].'</option></select>';
		$it618_homeordertype=str_replace('value="'.$it618_scoremall['it618_homeordertype'].'"','value="'.$it618_scoremall['it618_homeordertype'].'" selected="selected"',$it618_homeordertype);
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_scoremall[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_scoremall[id]]\" value=\"$it618_scoremall[id]\">",
			'<select id="it618_class1_id'.$it618_scoremall[id].'" name="it618_class1_id" onchange="redirec_class(this.options.selectedIndex,'.$it618_scoremall[id].')"><option value="0">'.$it618_mall_lang['s53'].'</option>'.$tmp1.'</select><select id="it618_class2_id'.$it618_scoremall[id].'" name="it618_class2_id['.$it618_scoremall[id].']"><option value="0">'.$it618_mall_lang['s58'].'</option></select>',
			"<input type=\"text\" class=\"txt\" style=\"width:100px\" name=\"it618_classname[$it618_scoremall[id]]\" value=\"$it618_scoremall[it618_classname]\">",
			"<input id=\"c".$it618_scoremall['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"it618_color[$it618_scoremall[id]]\" value=\"$it618_scoremall[it618_color]\" onchange=\"updatecolorpreview('c".$it618_scoremall['id']."')\"><input id=\"c".$it618_scoremall['id']."\" onclick=\"c".$it618_scoremall['id']."_frame.location='static/image/admincp/getcolor.htm?c".$it618_scoremall['id']."|c".$it618_scoremall['id']."_v';showMenu({'ctrlid':'c".$it618_scoremall['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:\"><span id=\"c".$it618_scoremall['id']."_menu\" style=\"display: none\"><iframe name=\"c".$it618_scoremall['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			$it618_homeposition.'/<input class="txt" style="width:50px;margin-right:0" type="text" name="it618_homecount['.$it618_scoremall['id'].']" value="'.$it618_scoremall['it618_homecount'].'">/'.$it618_homeordertype.'<br><div style="margin-top:3px">'.$it618_mall_lang['s1032'].' <input class="txt" style="width:50px;margin-right:0" type="text" name="it618_homewapcount['.$it618_scoremall['id'].']" value="'.$it618_scoremall['it618_homewapcount'].'"></div>',
			'<input class="txt" type="text" style="width:40px;" name="it618_order['.$it618_scoremall['id'].']" value="'.$it618_scoremall['it618_order'].'">',
			$goodscount,
			'<input class="checkbox" type="checkbox" id="chk_istj'.$n.'" name="it618_istj['.$it618_scoremall['id'].']" '.$it618_istj_checked.' value="1">'
		));
		$tmpcolorjs.="updatecolorpreview('c".$it618_scoremall['id']."');";
		
		$checkjs.='if(document.getElementById("it618_class2_id'.$it618_scoremall[id].'").value=="0"){
						alert("'.$it618_mall_lang['s646'].'");
						document.getElementById("it618_class2_id'.$it618_scoremall[id].'").focus();
						return false;
					}'."\n";
	}
	
	global $_G;
if($reabc[4]!='8')return;

	loadcache('plugin');
	$it618_scoremall = $_G['cache']['plugin']['it618_scoremall'];

	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_class2'));
	$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class1')." ORDER BY it618_order DESC");
	$n1=1;
	$tmp1='';
	while($it618_tmp1 =	DB::fetch($query1)) {
		$class2count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_class2')." WHERE it618_class1_id=".$it618_tmp1['id']);
		if($class2count>0){
			$n2=1;
			$query2 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class2')." where it618_class1_id=".$it618_tmp1['id']." ORDER BY it618_order DESC");
			while($it618_tmp2 =	DB::fetch($query2)) {
				$tmp1.='select_class['.$n1.']['.$n2.'] = new Option("'.$it618_tmp2['it618_classname'].'", "'.$it618_tmp2['id'].'");';
				$n2=$n2+1;
			}
			$n1=$n1+1;
		}
	}
	
	echo '
	<script>
	var arrcount='.$count.';
	var select_class = new Array(arrcount+1);
	
	for (i=0; i<arrcount+1; i++) 
	{
	 select_class[i] = new Array();
	}
	
	'.$tmp1.'
	
	function redirec_class(x,n)
	{
	 var temp = document.getElementById("it618_class2_id"+n); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	
	}
	
	function redirec_class_sel(n,index)
	{
	 var temp = document.getElementById("it618_class2_id"+n); 
	 temp.options[index].selected=true;
	
	}
	
	function redirec_class_add(x,n)
	{
	 var temp = document.getElementById("it618_class2_id_add"+n); 
	 temp.options.length=1;
	 for (i=1;i<select_class[x].length;i++)
	 {
	  temp.options[i]=new Option(select_class[x][i].text,select_class[x][i].value);
	 }
	 temp.options[0].selected=true;
	}
	
	'.$jstmp.'
	
	</script>';
	
	$it618_mall_lang53=$it618_mall_lang['s53'];
	$it618_mall_lang58=$it618_mall_lang['s58'];
	$it618_mall_lang646=$it618_mall_lang['s646'];

	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_classname[]").length;
	
		return [
		[[1,''], 
		[1,'<select onchange="redirec_class_add(this.options.selectedIndex,'+n+')"><option value="0">$it618_mall_lang53</option>$tmpadd1</select><select id="it618_class2_id_add'+n+'" name="newit618_class2_id[]"><option value="0">$it618_mall_lang58</option>$tmpadd2</select>'], 
		[1,'<input type="text" class="txt" style="width:100px" name="newit618_classname[]">'], 
		[1,'<input id="c_add'+n+'_v" type="text" class="txt" style=\"width:80px;float:left\" name="newit618_color[]" onchange="updatecolorpreview(\'c_add'+n+'\')"><input id="c_add'+n+'" onclick="c_add'+n+'_frame.location=\'static/image/admincp/getcolor.htm?c_add'+n+'|c_add'+n+'_v\';showMenu({\'ctrlid\':\'c_add'+n+'\'})" type="button" class="colorwd" value="" style="background: "><span id="c_add'+n+'_menu" style="display: none"><iframe name="c_add'+n+'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>'],
		[1,''],
		[1,'<input class="txt" type="text" style="width:50px" name="newit618_order[]">'], 
		[1,'']]
		];
	}
	rowtypedata=rundata();
	$tmpcolorjs
	function checkvalue(){
		$checkjs
		
		var n=document.getElementsByName("newit618_classname[]").length;
		for(i=0;i<n;i++){
			if(document.getElementById("it618_class2_id_add"+i).value=="0"){
				alert("$it618_mall_lang646");
				document.getElementById("it618_class2_id_add"+i).focus();
				return false;
			}
		}
	}
	
	</script>
EOT;
	echo '<tr><td></td><td colspan="3"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallv9Ve" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallv9Ve">'.$it618_mall_lang['s235'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" id="submit_it618submit" name="it618submit" onclick="return checkvalue();" value="'.$it618_mall_lang['s514'].'" /> &nbsp;<input type=hidden value='.$page.' name=page /></div></td></tr>';

	if(count($reabc)!=15)return;
showtablefooter();/*Dism��taobao��com*/
    
?>