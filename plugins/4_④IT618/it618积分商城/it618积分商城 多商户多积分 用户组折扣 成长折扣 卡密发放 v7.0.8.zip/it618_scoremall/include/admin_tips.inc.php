<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	
	DB::query("DELETE FROM ".DB::table('it618_scoremall_tips')."");

	C::t('#it618_scoremall#it618_scoremall_tips')->insert(array(
		'it618_title' => $_GET['it618_title'],
		'it618_message1' => $_GET['it618_message1'],
		'it618_message2' => $_GET['it618_message2']
	), true);

	cpmsg($it618_mall_lang['s88'], "action=plugins&identifier=$identifier&cp=admin_tips&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_tips&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($it618_mall_lang['s351'],'it618_scoremall_tips');

$it618_scoremall_tips=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_tips'));
echo '
<link rel="stylesheet" href="source/plugin/it618_scoremall/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_scoremall/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_scoremall/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_scoremall/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_scoremall/kindeditor/plugins/code/prettify.js"></script>
<script>
	var shopuid=0;
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message1"]\', {
			cssPath : \'source/plugin/it618_scoremall/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_scoremall/kindeditor/php/upload_json.php?imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_scoremall/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
		
		var editor2 = K.create(\'textarea[name="it618_message2"]\', {
			cssPath : \'source/plugin/it618_scoremall/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_scoremall/kindeditor/php/upload_json.php?imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_scoremall/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
				
		prettyPrint();
	});
</script>

<tr><td width=120>'.$it618_mall_lang['s353'].'</td><td><textarea name="it618_message1" style="width:700px;height:100px;visibility:hidden;">'.$it618_scoremall_tips['it618_message1'].'</textarea></td></tr>
<tr><td>'.$it618_mall_lang['s354'].'</td><td><input type="text" class="txt" style="width:300px" name="it618_title" value="'.$it618_scoremall_tips['it618_title'].'"></td></tr>
<tr><td>'.$it618_mall_lang['s355'].'</td><td><textarea name="it618_message2" style="width:700px;height:300px;visibility:hidden;">'.$it618_scoremall_tips['it618_message2'].'</textarea></td></tr>
';

showsubmit('it618submit', $it618_mall_lang['s87']);
if(count($reabc)!=15)return;
showtablefooter();/*Dism��taobao��com*/

?>