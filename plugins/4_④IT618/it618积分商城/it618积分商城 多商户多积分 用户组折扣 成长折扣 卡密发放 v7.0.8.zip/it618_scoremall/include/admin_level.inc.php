<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}

if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	$ok1=0;
	$ok2=0;
	$del=0;
	
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_scoremall_level', "id=$delid");
		$del=$del+1;
	}
	
	if(is_array($_GET['it618_level'])) {
		foreach($_GET['it618_level'] as $id => $val) {

			C::t('#it618_scoremall#it618_scoremall_level')->update($id,array(
				'it618_level' => trim($_GET['it618_level'][$id]),
				'it618_score1' => trim($_GET['it618_score1'][$id]),
				'it618_score2' => trim($_GET['it618_score2'][$id]),
				'it618_zk' => trim($_GET['it618_zk'][$id]),
			));
			$ok1=$ok1+1;
		}
	}

	$newit618_level_array = !empty($_GET['newit618_level']) ? $_GET['newit618_level'] : array();
	$newit618_score1_array = !empty($_GET['newit618_score1']) ? $_GET['newit618_score1'] : array();
	$newit618_score2_array = !empty($_GET['newit618_score2']) ? $_GET['newit618_score2'] : array();
	$newit618_zk_array = !empty($_GET['newit618_zk']) ? $_GET['newit618_zk'] : array();
	
	foreach($newit618_level_array as $key => $value) {
		$newit618_level = addslashes(trim($newit618_level_array[$key]));
		
		if($newit618_level != '') {
			
			C::t('#it618_scoremall#it618_scoremall_level')->insert(array(
				'it618_level' => trim($newit618_level_array[$key]),
				'it618_score1' => trim($newit618_score1_array[$key]),
				'it618_score2' => trim($newit618_score2_array[$key]),
				'it618_zk' => trim($newit618_zk_array[$key]),
			), true);
			$ok2=$ok2+1;
		}
	}

	cpmsg($it618_mall_lang['s39'].$ok1.' '.$it618_mall_lang['s40'].$ok2.' '.$it618_mall_lang['s41'].$del.')', "action=plugins&identifier=$identifier&cp=admin_level&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}
if($reabc[0]!='i')return;
showformheader("plugins&identifier=$identifier&cp=admin_level&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($it618_mall_lang['s72'],'it618_scoremall_level');
	
	echo '<tr><td colspan=4>'.$it618_mall_lang['s73'].'</td></tr>';
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_level')." w WHERE 1 $extrasql");
	echo '<tr><td colspan=4>'.$it618_mall_lang['s74'].$count.'</td></tr>';
	showsubtitle(array('', $it618_mall_lang['s75'], $it618_mall_lang['s76'], $it618_mall_lang['s77'], '<div style="width:400px">'.$it618_mall_lang['s78'].'</div>'));
	
	for($i=1;$i<=10;$i++){
		$tmp.='<option value='.$i.'>'.$it618_mall_lang['s79'].$i.'</option>';
	}
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_level')." WHERE 1 $extrasql ORDER BY it618_score2 ASC LIMIT $startlimit, $ppp");
	while($it618_scoremall =	DB::fetch($query)) {
		$count=DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_groupup')." where it618_score>=".$it618_scoremall['it618_score1']." and it618_score<=".$it618_scoremall['it618_score2']);
		$tmp1=str_replace('<option value='.$it618_scoremall['it618_level'].'>','<option value='.$it618_scoremall['it618_level'].' selected="selected">',$tmp);
		
		showtablerow('', array('class="td25"', '', ''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$it618_scoremall[id]\" $disabled><input type=\"hidden\" name=\"id[$it618_scoremall[id]]\" value=\"$it618_scoremall[id]\">",
			'<select name="it618_level['.$it618_scoremall[id].']">'.$tmp1.'</select>',
			$it618_mall_lang['s76'].'<input class="txt" type="text" name="it618_score1['.$it618_scoremall['id'].']" value="'.$it618_scoremall['it618_score1'].'">- <input class="txt" type="text" name="it618_score2['.$it618_scoremall['id'].']" value="'.$it618_scoremall['it618_score2'].'">',
			'<input class="txt" type="text" name="it618_zk['.$it618_scoremall['id'].']" value="'.$it618_scoremall['it618_zk'].'">%',
			$count
		));

	}
	
	if($reabc[2]+$reabc[3]+$reabc[4]!=15)return;
	echo <<<EOT
	<script type="text/JavaScript">
	var rowtypedata;
	function rundata(){
		var n=document.getElementsByName("newit618_level[]").length;
	
		return [
		[[1,''], [1,'<select name="newit618_level[]">$tmp</select>'], [1, '<input class="txt" type="text" name="newit618_score1[]">- <input class="txt" type="text" name="newit618_score2[]">'], [1, '<input class="txt" type="text" name="newit618_zk[]">%'], [1,'']]
		];
	}
	rowtypedata=rundata();
	</script>
EOT;
	echo '<tr><td></td><td colspan="4"><div><a href="###" onclick="rowtypedata=rundata();addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	
	showsubmit('it618submit', 'submit', 'del', "<input type=hidden value=$page name=page />", $multipage);
	if(count($reabc)!=15)return;
showtablefooter();/*Dism��taobao��com*/
?>