<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if($_GET['key']) {
	$extrasql .= " AND g.it618_name LIKE '%".addcslashes(addslashes($_GET['key']),'%_')."%'";
}

if($_GET['finduid']) {
	$extrasql .= " AND s.it618_uid = ".intval($_GET['finduid']);
}

$sql='&key='.$_GET['key'].'&finduid='.$_GET['finduid'];

if(submitcheck('it618submit_del')){
	$del=0;
	if($reabc[8]!='o')return;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		DB::delete('it618_scoremall_order', "id=$delid");
		$del=$del+1;
	}

	cpmsg($it618_mall_lang['s524'].$del, "action=plugins&identifier=$identifier&cp=admin_order&pmod=admin_order&operation=$operation&do=$do&page=$page".$sql, 'succeed');
}

if(count($reabc)!=15)return;

echo '
<link rel="stylesheet" href="source/plugin/it618_scoremall/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/it618_scoremall/kindeditor/kindeditor-min.js"></script>
';

showformheader("plugins&identifier=$identifier&cp=admin_order&pmod=admin_order&operation=$operation&do=$do");
showtableheaders($it618_mall_lang['s525'],'it618_scoremall_sum');
	showsubmit('it618sercsubmit', $it618_mall_lang['s149'], $it618_mall_lang['s150'].' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.$it618_mall_lang['s151'].' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:50px" />');
	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_order')." s,".DB::table('it618_scoremall_goods')." g WHERE s.it618_pid=g.id $extrasql");
	
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_order&pmod=admin_order&operation=$operation&do=$do".$sql);
	
	echo '<tr><td colspan=10>'.$it618_mall_lang['s526'].$count.'</td></tr>';
	showsubtitle(array('', $it618_mall_lang['s527'],$it618_mall_lang['s538'],$it618_mall_lang['s529'],$it618_mall_lang['s530'],$it618_mall_lang['s531'],$it618_mall_lang['s532']));
	
	$query = DB::query("SELECT s.* FROM ".DB::table('it618_scoremall_order')." s,".DB::table('it618_scoremall_goods')." g WHERE s.it618_pid=g.id $extrasql order by id desc LIMIT $startlimit, $ppp");
	while($it618_scoremall_order = DB::fetch($query)) {
		
		$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_order['it618_pid']);
		$it618_class3_id=$it618_scoremall_goods['it618_class3_id'];
		$it618_name=$it618_scoremall_goods['it618_name'];
		$it618_picsmall=it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']);
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_scoremall_order['it618_uid']);

		$strcontent=$it618_scoremall_order['it618_addr'];
		if($it618_scoremall_order['it618_bz']!=''){
			$strcontent.='<br><font color=red>'.$it618_mall_lang['s533'].'</font>'.dhtmlspecialchars($it618_scoremall_order['it618_bz']);
		}
		
		if($it618_scoremall_order[it618_saleuid]==0){
			$orderuser=$it618_mall_lang['s227'];
		}else{
			$orderuser='<a href="home.php?mod=space&uid='.$it618_scoremall_goods['it618_uid'].'" target="_blank">'.it618_scoremall_getusername($it618_scoremall_goods[it618_uid]).'</a>';
		}
		
		$tmpstr='';
		$orderid=$it618_scoremall_order['id'];
		for($i=0;$i<7-strlen($orderid);$i++){
			$tmpstr.='0';
		}
		$orderid=$tmpstr.$orderid;
		$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$it618_scoremall_order[id].'" name="delete[]" value="'.$it618_scoremall_order[id].'"><input type="hidden" name="id['.$it618_scoremall_order[id].']" value="'.$it618_scoremall_order[id].'"><label for="chk_del'.$it618_scoremall_order[id].'" title="'.$it618_mall_lang['s401'].'D'.$orderid.$strcode.'">'.$it618_scoremall_order['id'].'</label>',
			'<a href="'.$tmpurl.'" title="'.$it618_mall_lang['s177'].''.$it618_scoremall_order['it618_pid'].' '.$it618_mall_lang['s178'].''.it618_scoremall_class1name($it618_class3_id).' '.it618_scoremall_class2name($it618_class3_id).' '.it618_scoremall_class3name($it618_class3_id).'" target="_blank"><img style="float:left;" src="'.$it618_picsmall.'" width="50" height="50" align="absmiddle"/><div style="float:left;width:200px;margin-left:3px">'.$it618_name.'<br></div></a>',
			$it618_scoremall_order['it618_count'],
			'<div style="width:50px">'.$orderuser.'</div>',
			'<div style="width:400px">'.$strcontent.'</div>',
			'<div style="width:80px"><a href="home.php?mod=space&uid='.$it618_scoremall_order['it618_uid'].'" target="_blank">'.it618_scoremall_getusername($it618_scoremall_order['it618_uid']).'</a></div>',
			'<div style="width:75px">'.date('Y-m-d H:i:s', $it618_scoremall_order['it618_time']).'</div>'
		));
	}

	function it618_scoremall_class1name($aid){
		$class2id = DB::result_first("select it618_class2_id from ".DB::table('it618_scoremall_class3')." where id=".$aid);
		$class1id = DB::result_first("select it618_class1_id from ".DB::table('it618_scoremall_class2')." where id=".$class2id);
		return DB::result_first("select it618_classname from ".DB::table('it618_scoremall_class1')." where id=".$class1id);
	}
	
	function it618_scoremall_class2name($aid){
		$class2id = DB::result_first("select it618_class2_id from ".DB::table('it618_scoremall_class3')." where id=".$aid);
		return DB::result_first("select it618_classname from ".DB::table('it618_scoremall_class2')." where id=".$class2id);
	}
	
	function it618_scoremall_class3name($aid){
		return DB::result_first("select it618_classname from ".DB::table('it618_scoremall_class3')." where id=".$aid);
	}
	
	function it618_scoremall_getusername($uid){
		return DB::result_first("select username from ".DB::table('common_member')." where uid=".$uid);
	}

	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.$it618_mall_lang['s415'].'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.$it618_mall_lang['s534'].'" onclick="return confirm(\''.$it618_mall_lang['s535'].'\')" /><input type=hidden value='.$page.' name=page /></div></td></tr>';

	if(count($reabc)!=15)return;
showtablefooter();/*Dism��taobao��com*/
?>