<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/config/rewrite.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/config/rewrite.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_scoremall/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$home=\''.'scoremall'."';\n";
		$fileData .= '$gwc=\''.'gwc'."';\n";
		$fileData .= '$productlist=\''.'productlist'."';\n";
		$fileData .= '$product=\''.'product'."';\n";
		$fileData .= '$uc=\''.'uc'."';\n";
		$fileData .= '$store=\''.'store'."';\n";
		$fileData .= '$storelist=\''.'storelist'."';\n";
		$fileData .= '$wap=\''.'scoremall_wap'."';\n";
		
		$urltype='.html';
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$home1=\''.$urltype."';\n";
		$fileData .= '$gwc1=\''.$urltype."';\n";
		$fileData .= '$productlist1=\'-{action}-{value}-{page}'.$urltype."';\n";
		$fileData .= '$product1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$uc1=\'-{cid}-{page}'.$urltype."';\n";
		$fileData .= '$store1=\'-{action}-{value}-{cid}-{pid}-{page}'.$urltype."';\n";
		$fileData .= '$storelist1=\'-{page}'.$urltype."';\n";
		$fileData .= '$wap1=\'-{pagetype}-{cid}-{page}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/config/rewrite.php';
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_scoremall/config/rewrite.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$home=\''.str_replace("-","",$_GET['scoremall_home'])."';\n";
		$fileData .= '$gwc=\''.str_replace("-","",$_GET['scoremall_gwc'])."';\n";
		$fileData .= '$productlist=\''.str_replace("-","",$_GET['scoremall_productlist'])."';\n";
		$fileData .= '$product=\''.str_replace("-","",$_GET['scoremall_product'])."';\n";
		$fileData .= '$uc=\''.str_replace("-","",$_GET['scoremall_uc'])."';\n";
		$fileData .= '$store=\''.str_replace("-","",$_GET['scoremall_store'])."';\n";
		$fileData .= '$storelist=\''.str_replace("-","",$_GET['scoremall_storelist'])."';\n";
		$fileData .= '$wap=\''.str_replace("-","",$_GET['scoremall_wap'])."';\n";
		
		$urltype=str_replace("-","",$_GET['urltype']);
		$urltype=str_replace("?","",$_GET['urltype']);
		$fileData .= '$urltype=\''.$urltype."';\n";
		$fileData .= '$home1=\''.$urltype."';\n";
		$fileData .= '$gwc1=\''.$urltype."';\n";
		$fileData .= '$productlist1=\'-{action}-{value}-{page}'.$urltype."';\n";
		$fileData .= '$product1=\'-{pid}'.$urltype."';\n";
		$fileData .= '$uc1=\'-{cid}-{page}'.$urltype."';\n";
		$fileData .= '$store1=\'-{action}-{value}-{cid}-{pid}-{page}'.$urltype."';\n";
		$fileData .= '$storelist1=\'-{page}'.$urltype."';\n";
		$fileData .= '$wap1=\'-{pagetype}-{cid}-{page}'.$urltype."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_mall_lang['s599'], "action=plugins&identifier=$identifier&cp=admin_rewrite&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_rewrite&pmod=admin_set&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_mall_lang['s600'].'</th></tr>
<tr><td class="vtop tips2" colspan="3">'.$it618_mall_lang['s601'].'</td></tr>
<tr><td colspan="3">'.$it618_mall_lang['s602'].'<input name="urltype" value="'.$urltype.'"/></td></tr>
<tr class="header"><th>'.$it618_mall_lang['s603'].'</th><th>'.$it618_mall_lang['s604'].'</th><th>'.$it618_mall_lang['s605'].'</th></tr>
<tr class="hover">
<td>'.$it618_mall_lang['s606'].'</td><td></td><td class="longtxt"><input name="scoremall_home" value="'.$home.'"/>'.$home.$home1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_mall_lang['s607'].'</td><td></td><td class="longtxt"><input name="scoremall_gwc" value="'.$gwc.'" />'.$gwc.$gwc1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_mall_lang['s608'].'</td><td>{action}, {value}, {page}</td><td class="longtxt"><input name="scoremall_productlist" value="'.$productlist.'"/>'.$productlist.$productlist1.'</td></tr>
<tr class="hover">
<td>'.$it618_mall_lang['s609'].'</td><td>{pid}</td><td class="longtxt"><input name="scoremall_product" value="'.$product.'"/>'.$product.$product1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_mall_lang['s610'].'</td><td>{cid}, {page}</td><td class="longtxt"><input name="scoremall_uc" value="'.$uc.'"/>'.$uc.$uc1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_mall_lang['s611'].'</td><td>{action}, {value}, {cid}, {pid}, {page}</td><td class="longtxt"><input name="scoremall_store" value="'.$store.'"/>'.$store.$store1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_mall_lang['s612'].'</td><td>{page}</td><td class="longtxt"><input name="scoremall_storelist" value="'.$storelist.'"/>'.$storelist.$storelist1.'</td>
</tr>
<tr class="hover">
<td>'.$it618_mall_lang['s559'].'</td><td>{pagetype}, {cid}, {page}</td><td class="longtxt"><input name="scoremall_wap" value="'.$wap.'"/>'.$wap.$wap1.'</td>
</tr>
</table>
';

showsubmit('it618submit', $it618_mall_lang['s613']);

$urltype1=$urltype;
if($urltype!='')$urltype=str_replace(".","\\.",$urltype);

$strtmp= '<br><h1>'.$it618_mall_lang['s614'].'</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
	<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$home.$urltype.'$ $1/plugin.php?id=it618_scoremall:scoremall&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$gwc.$urltype.'$ $1/plugin.php?id=it618_scoremall:gwc&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$productlist.$urltype.'$ $1/plugin.php?id=it618_scoremall:scoremall_list&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$uc.$urltype.'$ $1/plugin.php?id=it618_scoremall:scoremall_uc&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$store.$urltype.'$ $1/plugin.php?id=it618_scoremall:scoremall_store&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$storelist.$urltype.'$ $1/plugin.php?id=it618_scoremall:store_list&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$productlist.'-(.+)-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_scoremall:scoremall_list&$2=$3&page=$4&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$product.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_scoremall:scoremall_page&pid=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$uc.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_scoremall:scoremall_uc&cid=$2&page=$3&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$store.'-(.+)-(.+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_scoremall:scoremall_store&$2=$3&cid=$4&pid=$5&page=$6&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$storelist.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_scoremall:store_list&page=$2&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$wap.$urltype.'$ $1/plugin.php?id=it618_scoremall:wap&%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_scoremall:wap&pagetype=$2&cid=$3&page=$4&%1</font>
&lt;/IfModule&gt;
</pre>

<h1>'.$it618_mall_lang['s615'].'</h1>
<pre class="colorbox">
'.$it618_mall_lang['s616'].'
<font color=blue>RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$home.$urltype.'$ plugin.php?id=it618_scoremall:scoremall&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$gwc.$urltype.'$ plugin.php?id=it618_scoremall:gwc&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$productlist.$urltype.'$ plugin.php?id=it618_scoremall:scoremall_list&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$uc.$urltype.'$ plugin.php?id=it618_scoremall:scoremall_uc&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$store.$urltype.'$ plugin.php?id=it618_scoremall:scoremall_store&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$storelist.$urltype.'$ plugin.php?id=it618_scoremall:store_list&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$productlist.'-(.+)-(.+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_scoremall:scoremall_list&$1=$2&page=$3&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$product.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_scoremall:scoremall_page&pid=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$uc.'-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_scoremall:scoremall_uc&cid=$1&page=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$store.'-(.+)-(.+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_scoremall:scoremall_store&$1=$2&cid=$3&pid=$4&page=$5&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$storelist.'-([0-9]+)'.$urltype.'$ plugin.php?id=it618_scoremall:store_list&page=$1&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$wap.$urltype.'$ plugin.php?id=it618_scoremall:wap&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ plugin.php?id=it618_scoremall:wap&pagetype=$1&cid=$2&page=$3&%1</font>

</pre>

<h1>'.$it618_mall_lang['s617'].'</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
<font color=blue>RewriteRule ^(.*)/'.$home.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_scoremall:scoremall&$3
RewriteRule ^(.*)/'.$gwc.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_scoremall:gwc&$3
RewriteRule ^(.*)/'.$productlist.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_scoremall:scoremall_list&$3
RewriteRule ^(.*)/'.$uc.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_scoremall:scoremall_uc&$3
RewriteRule ^(.*)/'.$store.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_scoremall:scoremall_store&$3
RewriteRule ^(.*)/'.$storelist.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_scoremall:store_list&$3
RewriteRule ^(.*)/'.$productlist.'-(.+)-(.+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_scoremall:scoremall_list&$2=$3&page=$4&$6
RewriteRule ^(.*)/'.$product.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_scoremall:scoremall_page&pid=$2&$4
RewriteRule ^(.*)/'.$uc.'-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_scoremall:scoremall_uc&cid=$2&page=$3&$5
RewriteRule ^(.*)/'.$store.'-(.+)-(.+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_scoremall:scoremall_store&$2=$3&cid=$4&pid=$5&page=$6&$8
RewriteRule ^(.*)/'.$storelist.'-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_scoremall:store_list&page=$2&$4
RewriteRule ^(.*)/'.$wap.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_scoremall:wap&$3
RewriteRule ^(.*)/'.$wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'(\?(.*))*$ $1/plugin\.php\?id=it618_scoremall:wap&pagetype=$2&cid=$3&page=$4&$6
</font>

</pre>

<h1>'.$it618_mall_lang['s618'].'</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
		<font color=blue>&lt;rule name="scoremall_home"&gt;
			&lt;match url="^(.*/)*'.$home.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_scoremall:scoremall&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="scoremall_gwc"&gt;
			&lt;match url="^(.*/)*'.$gwc.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_scoremall:gwc&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="scoremall_productlist_home"&gt;
			&lt;match url="^(.*/)*'.$productlist.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_scoremall:scoremall_list&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="scoremall_uc_home"&gt;
			&lt;match url="^(.*/)*'.$uc.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_scoremall:scoremall_uc&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="scoremall_store_home"&gt;
			&lt;match url="^(.*/)*'.$store.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_scoremall:scoremall_store&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="scoremall_store_home1"&gt;
			&lt;match url="^(.*/)*'.$storelist.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_scoremall:store_list&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="scoremall_productlist"&gt;
			&lt;match url="^(.*/)*'.$productlist.'-(.+)-(.+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_scoremall:scoremall_list&amp;amp;{R:2}={R:3}&amp;amp;page={R:4}&amp;amp;{R:5}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="scoremall_product"&gt;
			&lt;match url="^(.*/)*'.$product.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_scoremall:scoremall_page&amp;amp;pid={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="scoremall_uc"&gt;
			&lt;match url="^(.*/)*'.$uc.'-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_scoremall:scoremall_uc&amp;amp;cid={R:2}&amp;amp;page={R:3}&amp;amp;{R:4}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="scoremall_store"&gt;
			&lt;match url="^(.*/)*'.$store.'-(.+)-(.+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_scoremall:scoremall_store&amp;amp;{R:2}={R:3}&amp;amp;cid={R:4}&amp;amp;pid={R:5}&amp;amp;page={R:6}&amp;amp;{R:7}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="scoremall_storelist"&gt;
			&lt;match url="^(.*/)*'.$storelist.'-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_scoremall:store_list&amp;amp;page={R:2}&amp;amp;{R:3}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="wap"&gt;
			&lt;match url="^(.*/)*'.$wap.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_scoremall:wap&amp;amp;{R:2}" /&gt;
		&lt;/rule&gt;
		&lt;rule name="wap1"&gt;
			&lt;match url="^(.*/)*'.$wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype1.'\?*(.*)$" /&gt;
			&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=it618_scoremall:wap&amp;amp;pagetype={R:2}&amp;amp;cid={R:3}&amp;amp;page={R:4}&amp;amp;{R:5}" /&gt;
		&lt;/rule&gt;</font>
	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
<font color=blue>match URL into $ with ^(.*)/'.$home.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_scoremall:scoremall&$2
endif
match URL into $ with ^(.*)/'.$gwc.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_scoremall:gwc&$2
endif
match URL into $ with ^(.*)/'.$productlist.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_scoremall:scoremall_list&$2
endif
match URL into $ with ^(.*)/'.$uc.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_scoremall:scoremall_uc&$2
endif
match URL into $ with ^(.*)/'.$store.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_scoremall:scoremall_store&$2
endif
match URL into $ with ^(.*)/'.$storelist.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_scoremall:store_list&$2
endif
match URL into $ with ^(.*)/'.$productlist.'-(.+)-(.+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_scoremall:scoremall_list&$2=$3&page=$4&$5
endif
match URL into $ with ^(.*)/'.$product.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_scoremall:scoremall_page&pid=$2&$3
endif
match URL into $ with ^(.*)/'.$uc.'-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_scoremall:scoremall_uc&cid=$2&page=$3&$4
endif
match URL into $ with ^(.*)/'.$store.'-(.+)-(.+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_scoremall:scoremall_store&$2=$3&cid=$4&pid=$5&page=$6&$7
endif
match URL into $ with ^(.*)/'.$storelist.'-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_scoremall:store_list&page=$2&$3
endif
match URL into $ with ^(.*)/'.$wap.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_scoremall:wap&$2
endif
match URL into $ with ^(.*)/'.$wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'\?*(.*)$
if matched then
	set URL = $1/plugin.php?id=it618_scoremall:wap&pagetype=$2&cid=$3&page=$4&$5
endif
</font>

</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
<font color=blue>rewrite ^([^\.]*)/'.$home.$urltype.'$ $1/plugin.php?id=it618_scoremall:scoremall&$2 last;
rewrite ^([^\.]*)/'.$gwc.$urltype.'$ $1/plugin.php?id=it618_scoremall:gwc&$2 last;
rewrite ^([^\.]*)/'.$productlist.$urltype.'$ $1/plugin.php?id=it618_scoremall:scoremall_list&$2 last;
rewrite ^([^\.]*)/'.$uc.$urltype.'$ $1/plugin.php?id=it618_scoremall:scoremall_uc&$2 last;
rewrite ^([^\.]*)/'.$store.$urltype.'$ $1/plugin.php?id=it618_scoremall:scoremall_store&$2 last;
rewrite ^([^\.]*)/'.$storelist.$urltype.'$ $1/plugin.php?id=it618_scoremall:store_list&$2 last;
rewrite ^([^\.]*)/'.$productlist.'-(.+)-(.+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_scoremall:scoremall_list&$2=$3&page=$4&$5 last;
rewrite ^([^\.]*)/'.$product.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_scoremall:scoremall_page&pid=$2&$3 last;
rewrite ^([^\.]*)/'.$uc.'-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_scoremall:scoremall_uc&cid=$2&page=$3&$4 last;
rewrite ^([^\.]*)/'.$store.'-(.+)-(.+)-([0-9]+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_scoremall:scoremall_store&$2=$3&cid=$4&pid=$5&page=$6&$7 last;
rewrite ^([^\.]*)/'.$storelist.'-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_scoremall:store_list&page=$2&$3 last;
rewrite ^([^\.]*)/'.$wap.$urltype.'$ $1/plugin.php?id=it618_scoremall:wap&$2 last;
rewrite ^([^\.]*)/'.$wap.'-(.+)-([0-9]+)-([0-9]+)'.$urltype.'$ $1/plugin.php?id=it618_scoremall:wap&pagetype=$2&cid=$3&page=$4&$5 last;</font>
if (!-e $request_filename) {
	return 404;
}
</pre>
';

echo $strtmp;

if(count($reabc)!=11)return;
showtablefooter();/*Dism��taobao��com*/

?>