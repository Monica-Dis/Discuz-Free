<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/count.php')){
	require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/count.php';
}else{
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_scoremall/count.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$mall_hotgoodscount=\''.'8'."';\n";//��ҳ������Ʒ��
		$fileData .= '$mall_newgoodscount=\''.'8'."';\n";//��ҳ������Ʒ��
		$fileData .= '$mall_tjgoodscount=\''.'12'."';\n";//��ҳ�Ƽ���Ʒ��
		$fileData .= '$mall_zuijinbuy=\''.'10'."';\n";//��ҳ��������¼��
		$fileData .= '$mall_rankcount=\''.'10'."';\n";//��ҳ��Ʒ���а�������
		$fileData .= '$mall_renzhengcount=\''.'10'."';\n";//��ҳ�����֤��¼��
		$fileData .= '$mall_pagelistcount=\''.'12'."';\n";//��Ʒ�б�ҳÿҳ��Ʒ��
		$fileData .= '$mall_pagelisttype=\''.'1'."';\n";//��Ʒ��ϸҳ�Ҳ�����
		$fileData .= '$mall_pagerightcount=\''.'4'."';\n";//��Ʒ��ϸҳ�Ҳ���Ʒ��
		$fileData .= '$mall_pagelistlisttype=\''.'2'."';\n";//��Ʒ�б�ҳ�Ҳ�����
		$fileData .= '$mall_pagelistrightcount=\''.'3'."';\n";//��Ʒ�б�ҳ�Ҳ���Ʒ��
		$fileData .= '$mall_pagetjcount=\''.'4'."';\n";//��Ʒ��ϸҳ�Ƽ���Ʒ��
		$fileData .= '$mall_pagebuycount=\''.'10'."';\n";//	��Ʒ��ϸҳÿҳ�����¼��
		$fileData .= '$mall_pageplcount=\''.'10'."';\n";//��Ʒ��ϸҳÿҳ������¼��
		$fileData .= '$mall_storelistcount=\''.'12'."';\n";//�̼��б�ÿҳ�̼���
		$fileData .= '$mall_storetopcount=\''.'5'."';\n";//�̼��б����۰��̼���
		$fileData .= '$qtpagecount=\''.'10'."';\n";//ǰ̨ÿҳ��¼��
		$fileData .= '$pagecount=\''.'10'."';\n";//��̨ÿҳ��¼��
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
		
		require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/count.php';
	}
}

if(submitcheck('it618submit')){
	@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_scoremall/count.php',"w");
	if(!$fp){
		echo "system error";
		exit();
	}else {
		$fileData = '$mall_hotgoodscount=\''.intval($_GET['mall_hotgoodscount'])."';\n";
		$fileData .= '$mall_newgoodscount=\''.intval($_GET['mall_newgoodscount'])."';\n";
		$fileData .= '$mall_tjgoodscount=\''.intval($_GET['mall_tjgoodscount'])."';\n";
		$fileData .= '$mall_zuijinbuy=\''.intval($_GET['mall_zuijinbuy'])."';\n";
		$fileData .= '$mall_rankcount=\''.intval($_GET['mall_rankcount'])."';\n";
		$fileData .= '$mall_renzhengcount=\''.intval($_GET['mall_renzhengcount'])."';\n";
		$fileData .= '$mall_pagelistcount=\''.intval($_GET['mall_pagelistcount'])."';\n";
		$fileData .= '$mall_pagelisttype=\''.intval($_GET['mall_pagelisttype'])."';\n";
		$fileData .= '$mall_pagerightcount=\''.intval($_GET['mall_pagerightcount'])."';\n";
		$fileData .= '$mall_pagelistlisttype=\''.intval($_GET['mall_pagelistlisttype'])."';\n";
		$fileData .= '$mall_pagelistrightcount=\''.intval($_GET['mall_pagelistrightcount'])."';\n";
		$fileData .= '$mall_pagetjcount=\''.intval($_GET['mall_pagetjcount'])."';\n";
		$fileData .= '$mall_pagebuycount=\''.intval($_GET['mall_pagebuycount'])."';\n";
		$fileData .= '$mall_pageplcount=\''.intval($_GET['mall_pageplcount'])."';\n";
		$fileData .= '$mall_storelistcount=\''.intval($_GET['mall_storelistcount'])."';\n";
		$fileData .= '$mall_storetopcount=\''.intval($_GET['mall_storetopcount'])."';\n";
		$fileData .= '$qtpagecount=\''.intval($_GET['qtpagecount'])."';\n";
		$fileData .= '$pagecount=\''.intval($_GET['pagecount'])."';\n";
		
		fwrite($fp,"<?php\n".$fileData."?>");
		fclose($fp);
	}

	cpmsg($it618_mall_lang['s795'], "action=plugins&identifier=$identifier&cp=admin_count&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_count&pmod=admin_set&operation=$operation&do=$do");

echo '
<table class="tb tb2 nobdb">
<tr><th colspan="15" class="partition">'.$it618_mall_lang['s774'].'</th></tr>
<tr class="hover"><td width=230>'.$it618_mall_lang['s775'].'</td><td><input name="mall_hotgoodscount" value="'.$mall_hotgoodscount.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s776'].'</td><td><input name="mall_newgoodscount" value="'.$mall_newgoodscount.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s777'].'</td><td><input name="mall_tjgoodscount" value="'.$mall_tjgoodscount.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s778'].'</td><td><input name="mall_zuijinbuy" value="'.$mall_zuijinbuy.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s779'].'</td><td><input name="mall_rankcount" value="'.$mall_rankcount.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s781'].'</td><td><input name="mall_renzhengcount" value="'.$mall_renzhengcount.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s782'].'</td><td><input name="mall_pagelistcount" value="'.$mall_pagelistcount.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s783'].'</td><td><input name="mall_pagelisttype" value="'.$mall_pagelisttype.'" /> '.$it618_mall_lang['s794'].'</td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s784'].'</td><td><input name="mall_pagerightcount" value="'.$mall_pagerightcount.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s785'].'</td><td><input name="mall_pagelistlisttype" value="'.$mall_pagelistlisttype.'" /> '.$it618_mall_lang['s794'].'</td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s786'].'</td><td><input name="mall_pagelistrightcount" value="'.$mall_pagelistrightcount.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s787'].'</td><td><input name="mall_pagetjcount" value="'.$mall_pagetjcount.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s788'].'</td><td><input name="mall_pagebuycount" value="'.$mall_pagebuycount.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s789'].'</td><td><input name="mall_pageplcount" value="'.$mall_pageplcount.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s790'].'</td><td><input name="mall_storelistcount" value="'.$mall_storelistcount.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s791'].'</td><td><input name="mall_storetopcount" value="'.$mall_storetopcount.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s792'].'</td><td><input name="qtpagecount" value="'.$qtpagecount.'" /></td></tr>
<tr class="hover"><td>'.$it618_mall_lang['s793'].'</td><td><input name="pagecount" value="'.$pagecount.'" /></td></tr>
</table>
';

showsubmit('it618submit', $it618_mall_lang['s613']);

if(count($reabc)!=11)return;
showtablefooter();/*Dism��taobao��com*/

?>