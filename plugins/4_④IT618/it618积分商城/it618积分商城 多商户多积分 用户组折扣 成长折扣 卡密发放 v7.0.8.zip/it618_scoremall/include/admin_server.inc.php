<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
if(submitcheck('it618submit')){
	
	DB::query("DELETE FROM ".DB::table('it618_scoremall_server')."");

	C::t('#it618_scoremall#it618_scoremall_server')->insert(array(
		'it618_title' => $_GET['it618_title'],
		'it618_width' => intval($_GET['it618_width']),
		'it618_height' => intval($_GET['it618_height']),
		'it618_message' => $_GET['it618_message'],
	), true);

	cpmsg($it618_mall_lang['s81'], "action=plugins&identifier=$identifier&cp=admin_server&pmod=admin_set&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&identifier=$identifier&cp=admin_server&pmod=admin_set&operation=$operation&do=$do");
showtableheaders($it618_mall_lang['s82'],'it618_scoremall_server');

$it618_scoremall_server=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_server'));
echo '
<link rel="stylesheet" href="source/plugin/it618_scoremall/kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="source/plugin/it618_scoremall/kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="source/plugin/it618_scoremall/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/it618_scoremall/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="source/plugin/it618_scoremall/kindeditor/plugins/code/prettify.js"></script>
<script>
	var shopuid=0;
	KindEditor.ready(function(K) {
		var editor1 = K.create(\'textarea[name="it618_message"]\', {
			cssPath : \'source/plugin/it618_scoremall/kindeditor/plugins/code/prettify.css\',
			uploadJson : \'source/plugin/it618_scoremall/kindeditor/php/upload_json.php?imgwidth=1200'.$oss.'\',
			fileManagerJson : \'source/plugin/it618_scoremall/kindeditor/php/file_manager_json.php\',
			allowFileManager : true,
			filterMode:false,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K(\'form[name=example]\')[0].submit();
				});
			}
		});
				
		prettyPrint();
	});
</script>
	
<tr><td width=70>'.$it618_mall_lang['s83'].'</td><td><input type="text" class="txt" style="width:400px" name="it618_title" value="'.$it618_scoremall_server['it618_title'].'"></td></tr>
<tr><td>'.$it618_mall_lang['s84'].'</td><td><input type="text" class="txt" style="width:80px" name="it618_width" value="'.$it618_scoremall_server['it618_width'].'"> '.$it618_mall_lang['s85'].'<input type="text" class="txt" style="width:80px" name="it618_height" value="'.$it618_scoremall_server['it618_height'].'"></td></tr>
<tr><td>'.$it618_mall_lang['s86'].'</td><td><textarea name="it618_message" style="width:700px;height:400px;visibility:hidden;">'.$it618_scoremall_server['it618_message'].'</textarea></td></tr>
';

showsubmit('it618submit', $it618_mall_lang['s87']);
if(count($reabc)!=15)return;
showtablefooter();/*Dism��taobao��com*/

?>