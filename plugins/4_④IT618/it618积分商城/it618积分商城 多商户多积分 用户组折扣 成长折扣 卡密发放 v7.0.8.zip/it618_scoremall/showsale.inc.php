<?php
 /**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/function.func.php';

$uid = $_G['uid'];
if($uid<=0){
	if($_GET['wap']!=1){
		showmessage(it618_getbuyname(it618_mall_getlang('s27')), '', array(), array('alert' => 'error'));
	}else{
		echo 'it618_split'.it618_getbuyname(it618_mall_getlang('s27'));return;
	}
}else{
	$mall_buygroups=(array)unserialize($it618_scoremall['mall_buygroups']);
	$it618_scoremall_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".intval($_GET['pid']));
	
	if($_G['uid']==$it618_scoremall_goods['it618_uid']){
		if($_GET['wap']!=1){
			showmessage(it618_getbuyname(it618_mall_getlang('s340')), '', array(), array('alert' => 'error'));
		}else{
			echo 'it618_split'.it618_getbuyname(it618_mall_getlang('s340'));return;
		}
	}
	
	if($it618_scoremall_goods['it618_grouppower']!=''){
		$gp_arr=explode(",",$it618_scoremall_goods['it618_grouppower']);
		if(!in_array($_G['groupid'], $gp_arr)){
			if($_GET['wap']!=1){
				showmessage(it618_getbuyname(it618_mall_getlang('s359')), '', array(), array('alert' => 'error'));
			}else{
				echo 'it618_split'.it618_getbuyname(it618_mall_getlang('s359'));return;
			}
		}
	}else{
		if(!in_array($_G['groupid'], $mall_buygroups)){
			if($_GET['wap']!=1){
				showmessage(it618_getbuyname(it618_mall_getlang('s359')), '', array(), array('alert' => 'error'));
			}else{
				echo 'it618_split'.it618_getbuyname(it618_mall_getlang('s359'));return;
			}
		}
	}
	
	if($it618_scoremall_goods['it618_uid']>0){
		$it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_uid=".$it618_scoremall_goods['it618_uid']);
		if($it618_scoremall_store['it618_htstate']==0){
			if($_GET['wap']!=1){
				showmessage(it618_mall_getlang('s399'), '', array(), array('alert' => 'error'));
			}else{
				echo 'it618_split'.it618_mall_getlang('s399');return;
			}
		}
		if($it618_scoremall_store['it618_htstate']==2){
			if($_GET['wap']!=1){
				showmessage(it618_mall_getlang('s400'), '', array(), array('alert' => 'error'));
			}else{
				echo 'it618_split'.it618_mall_getlang('s400');return;
			}
		}
	}
	
	$liil1i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liil1i[]=substr($_GET['id'],$i,1);}
	$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$_G['uid']);

	$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid']]['title'];
	$jfcount=DB::result_first("select extcredits".$it618_scoremall_goods['it618_jfid']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
	if($jfcount=="")$jfcount=0;
	if($it618_scoremall_goods['it618_jfid1']>0){
		$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid1']]['title'];
		$jfcount1=DB::result_first("select extcredits".$it618_scoremall_goods['it618_jfid1']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
		if($jfcount1=="")$jfcount1=0;
	}

	$count = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_scoremall_groupup')." where it618_uid=".$_G['uid']);
	if($count==""||$count==0){
		C::t('#it618_scoremall#it618_scoremall_groupup')->insert(array(
			'it618_uid' => $_G['uid'],
		), true);
	}

	$groupupscore=DB::result_first("SELECT it618_score FROM ".DB::table('it618_scoremall_groupup')." where it618_uid=".$uid);
	$it618_scoremall_level=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_level')." where it618_score1<=".$groupupscore." and it618_score2>=".$groupupscore);
	
	if($it618_scoremall_goods['it618_iszk']==1){
		$groupid=$_G['groupid'];
		$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$groupid);
		
		$groupzk=DB::result_first("select it618_zk from ".DB::table('it618_scoremall_groupzk')." where it618_groupid=".$groupid);
		if($groupzk==''){
			if($_GET['wap']!=1){
				showmessage(it618_mall_getlang('s946'), '', array(), array('alert' => 'error'));
			}else{
				echo 'it618_split'.it618_mall_getlang('s946');return;
			}	
		}
		
		$allzk=round($groupzk*$it618_scoremall_level['it618_zk']/100,2);
		$price=intval($it618_scoremall_goods['it618_score']*$allzk/100);
		$price1=intval($it618_scoremall_goods['it618_score1']*$allzk/100);
	}else{
		$price=intval($it618_scoremall_goods['it618_score']*$it618_scoremall_level['it618_zk']/100);
		$price1=intval($it618_scoremall_goods['it618_score1']*$it618_scoremall_level['it618_zk']/100);
	}
	
	if(count($liil1i)!=15)return;
	
	if(!$it618_scoremall_level){
		if($_GET['wap']!=1){
			showmessage(it618_mall_getlang('s28'), '', array(), array('alert' => 'error'));
		}else{
			echo 'it618_split'.it618_mall_getlang('s28');return;
		}	
	}
	
	if($it618_scoremall_goods['it618_ison']==0||$it618_scoremall_goods['it618_state']!=2){
		if($_GET['wap']!=1){
			showmessage(it618_mall_getlang('s29'), '', array(), array('alert' => 'error'));
		}else{
			echo 'it618_split'.it618_mall_getlang('s29');return;
		}	
	}
	
	if($liil1i[8]!='o')return;
	$kmcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".intval($_GET['pid']));
	if($kmcount>0)
	{
		$it618_count=$kmcount;
	}else{
		$it618_count=$it618_scoremall_goods['it618_count'];
	}
	
	if($it618_count<=0){
		if($_GET['wap']!=1){
			showmessage(it618_mall_getlang('s554'), '', array(), array('alert' => 'error'));
		}else{
			echo 'it618_split'.it618_mall_getlang('s554');return;
		}	
	}
	
	if($it618_scoremall_goods['it618_isaddr']==1&&$kmcount==0){
		$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_addr')." WHERE it618_uid=".$uid." order by id desc");
		$liil1i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liil1i[]=substr($_GET['id'],$i,1);}
		$n=1;
		$iscurcount=DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_addr')." where it618_iscur=1 and it618_uid=".$uid);
		while($it618_scoremall_addr = DB::fetch($query)) {
			if($it618_scoremall_addr['it618_iscur']==0){
				$strtmp='';
			}else{
				$strtmp='checked="checked"';
			}
			if($iscurcount==0&&$n==1)$strtmp='checked="checked"';
			if($n%2==0){
				$strcss='<tr>';
			}else{
				$strcss='<tr class="odd">';
			}
			
			$liil1i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$liil1i[]=substr($_GET['id'],$i,1);}
			if($liil1i[3]!='1')return;
			if($_GET['wap']!=1){
				$addr_get.=$strcss.'
						 <td><input type="radio" '.$strtmp.' name="it618_addr"/></td>
						 <td>'.$it618_scoremall_addr['it618_name'].'</td>
						 <td>'.$it618_scoremall_addr['it618_addr'].'</td>
						 <td>'.$it618_scoremall_addr['it618_yzbm'].'</td>
						 <td>'.$it618_scoremall_addr['it618_tel'].'<input type="hidden" id="it618_addrid'.($n-1).'" title="'.$it618_scoremall_addr['it618_tel'].'" value="'.$it618_scoremall_addr['id'].'"/></td>
						 </tr>';
			}else{
				$addr_get.=$strcss.'
					 <td><input type="radio" '.$strtmp.' name="it618_addr"/></td>
					 <td>'.$it618_scoremall_addr['it618_name'].'</td>
					 <td>'.$it618_scoremall_addr['it618_addr'].'</td>
					 <td>'.$it618_scoremall_addr['it618_tel'].'<input type="hidden" id="it618_addrid'.($n-1).'" title="'.$it618_scoremall_addr['it618_tel'].'" value="'.$it618_scoremall_addr['id'].'"/></td>
					 </tr>';
			}
		    $n=$n+1;
		}
		
		if($addr_get==""){
			$isaddr=1;
		}
	}
}

if($IsCredits==1){
	if($_GET['wap']!=1){
		$creditsstr='<a href="javascript:" onclick="document.getElementById(\'it618_credits_tmp\').click();"><img src="source/plugin/it618_credits/images/ico.png" style="vertical-align:middle;margin-top:-4px"> '.$it618_mall_lang['s962'].'</a>';
	}else{
		if($_G['cache']['plugin']['it618_scoremall']['rewriteurl']==0){
			$creditsstr='<a href="plugin.php?id=it618_credits:wap"><img src="source/plugin/it618_credits/images/ico.png" style="vertical-align:middle;margin-top:-4px"> '.$it618_mall_lang['s962'].'</a>';
		}else{
			$creditsstr='<a href="credits_wap.html"><img src="source/plugin/it618_credits/images/ico.png" style="vertical-align:middle;margin-top:-4px"> '.$it618_mall_lang['s962'].'</a>';
		}
	}
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/config/message.php')){
	require DISCUZ_ROOT.'./source/plugin/it618_scoremall/config/message.php';
}

$goodspic=it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']);

if($it618_scoremall_goods['it618_isquan']==1)$it618_isquan=it618_mall_getlang('s711').$creditname.it618_mall_getlang('s712');
if($it618_scoremall_goods['it618_isquan']==2)$it618_isquan=it618_mall_getlang('s713');
$it618_isquan=it618_getbuyname($it618_isquan);


$it618_mall_lang91=it618_getbuyname($it618_mall_lang['t91']);
$it618_mall_lang93=it618_getbuyname($it618_mall_lang['t93']);
$it618_mall_lang99=it618_getbuyname($it618_mall_lang['t99']);
$it618_mall_lang107=it618_getbuyname($it618_mall_lang['t107']);
$it618_mall_lang108=it618_getbuyname($it618_mall_lang['t108']);
$it618_mall_lang110=it618_getbuyname($it618_mall_lang['t110']);
$it618_mall_lang112=it618_getbuyname($it618_mall_lang['t112']);
$it618_mall_lang113=it618_getbuyname($it618_mall_lang['t113']);
$it618_mall_lang123=it618_getbuyname($it618_mall_lang['t123']);

$tmpurl1=it618_scoremall_getrewrite('uc','','plugin.php?id=it618_scoremall:scoremall_uc');
$addrurl=it618_scoremall_getrewrite('scoremall_wap','addr@0@0','plugin.php?id=it618_scoremall:wap&pagetype=addr&cid=0');

$_G['mobiletpl'][IN_MOBILE]='/';
if($_GET['wap']!=1){
	include template('it618_scoremall:showsale');
}else{
	include template('it618_scoremall:showwapsale');
}
//From: Dism_taobao-com
?>