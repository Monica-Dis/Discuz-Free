<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

class plugin_it618_scoremall_forum {
	
	function viewthread_sidebottom_output(){
		global $_G,$postlist;
		$it618_scoremall = $_G['cache']['plugin']['it618_scoremall'];
		
		if($it618_scoremall['mall_isstorelogo']==1){
			$viewthread_sidebottom=array();
			foreach($postlist as $id => $post){
				
				$scoremall_leftad='';
				if($post['authorid']>0){
					if($it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." where it618_uid=".$post['authorid'])){
						require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/function.func.php';
						$tmpurl=it618_scoremall_getrewrite('productlist','sid@'.$it618_scoremall_store['id'].'@1','plugin.php?id=it618_scoremall:scoremall_list&sid='.$it618_scoremall_store['id']);
						$scoremall_leftad='<a href="'.$tmpurl.'" target="_blank"><img src="'.$it618_scoremall_store['it618_logo'].'" style="margin-left:15px;margin-bottom:10px" width= "130" /></a>';
					}
		
					$viewthread_sidebottom[]=$scoremall_leftad;
				}
	
			}
	
			return $viewthread_sidebottom;
		}
	}

}

class plugin_it618_scoremall{

	function global_header(){
		
		$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_diy'));
		while($it618_scoremall_diy = DB::fetch($query)) {
			$blockcount=DB::result_first("select count(1) from ".DB::table('common_block')." where name='".$it618_scoremall_diy['it618_name']."'");
			if($blockcount>0){
				if($it618_scoremall_diy["it618_catchtime"]>0){
					if((time()-$it618_scoremall_diy["it618_time"])<(60*$it618_scoremall_diy["it618_catchtime"])){
						break;
					}else{
						DB::query("update ".DB::table('it618_scoremall_diy')." set it618_time=".intval(time())." where id=".$it618_scoremall_diy["id"]);
					}
				}
				
				if($it618_scoremall_diy['it618_type']=='diyhtml'){
					$content=$it618_scoremall_diy['it618_modecode'];
				}else{
					require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/function.func.php';
					$content=it618_scoremall_getmode($it618_scoremall_diy['it618_type'],$it618_scoremall_diy['it618_modecode'],$it618_scoremall_diy['it618_pids'],$it618_scoremall_diy['it618_count']);
				}
				$setarr = array(
					'summary' => $content,
					'dateline' => $_G['timestamp']
				);
				DB::update('common_block', $setarr, "name='".$it618_scoremall_diy['it618_name']."'");
			}

		}
		
		return '';
		
	}
}
//From: Dism_taobao-com
?>