<?php
session_start();
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/function.func.php';

$jlcreditname=$_G['setting']['extcredits'][$it618_scoremall['mall_jlcredit']]['title'];

if($_GET['ac']!="pl_add")session_write_close();

if($_GET['ac']=="getmode"){
	$modeid=intval($_GET['modeid']);
	
	if($it618_scoremall_diy=DB::fetch_first("select * from ".DB::table('it618_scoremall_diy')." where id=".$modeid)){
		if($it618_scoremall_diy['it618_isjs']==1){
			$flag=0;
			if($it618_scoremall_diy["it618_catchtime"]>0){
				if((time()-$it618_scoremall_diy["it618_time"])<(60*$it618_scoremall_diy["it618_catchtime"])){
					echo $it618_scoremall_diy["it618_catch"];
				}else{
					$flag=1;
				}
			}else{
				$flag=1;
			}
			
			if($flag==1){
				if($it618_scoremall_diy['it618_type']=='diyhtml'){
					$tmpstr=$it618_scoremall_diy['it618_modecode'];
				}else{
					$tmpstr=it618_scoremall_getmode($it618_scoremall_diy['it618_type'],$it618_scoremall_diy['it618_modecode'],$it618_scoremall_diy['it618_pids'],$it618_scoremall_diy['it618_count']);
				}
	
				$tmpstr=str_replace(array("\r\n", "\r", "\n"),"",$tmpstr);
				$tmpstr=str_replace("'",'"',$tmpstr);
				
				$tmpstr="document.write('".$tmpstr."')";
		
				C::t('#it618_scoremall#it618_scoremall_diy')->update($it618_scoremall_diy["id"],array(
					'it618_catch' => $tmpstr,
					'it618_time' => time()
				));	
				
				echo $tmpstr;
			}
		}
	}
	exit;
}

if($_GET['ac']=="home_goods"){
	$home_goods=C::t('#it618_scoremall#it618_scoremall_set')->getsetvalue_by_setname($_GET['ac1']);
	
	$tmparr=explode(",",$home_goods);
	if($_GET['wap']!=1){
		if(count($tmparr)>2){
			$goods_count=$tmparr[0];
		}else{
			$goods_count=15;
		}
	}else{
		if(count($tmparr)>2){
			$goods_count=$tmparr[1];
		}else{
			$goods_count=8;
		}
	}
	
	if($_GET['ac1']=='zjsalegoods'){	
		$query = DB::query("SELECT max(id) as maxid,it618_pid FROM ".DB::table('it618_scoremall_sale')." GROUP BY it618_pid ORDER BY maxid desc limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='weeksalegoods'){
		$tomonth = date('n'); 
		$todate = date('j'); 
		$toyear = date('Y');
		$time=mktime(0, 0, 0, $tomonth, $todate-7, $toyear);
		$query = DB::query("SELECT id as it618_pid FROM ".DB::table('it618_scoremall_goods')." where it618_ison=1 and it618_state=2 and it618_htstate=1 ORDER BY id desc limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='newgoods'){
		$query = DB::query("SELECT id as it618_pid FROM ".DB::table('it618_scoremall_goods')." where it618_ison=1 and it618_state=2 and it618_htstate=1 ORDER BY id desc limit 0,".$goods_count);
	}
	
	if($_GET['ac1']=='hotgoods'){
		$query = DB::query("SELECT id as it618_pid FROM ".DB::table('it618_scoremall_goods')." where it618_ison=1 and it618_state=2 and it618_htstate=1 ORDER BY it618_salecount desc limit 0,".$goods_count);
	}
	
	$home_goodstmp='';
	$width=intval($_GET['width']/3-4);
	while($it618_homegoods = DB::fetch($query)) {
		$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE id=".$it618_homegoods['it618_pid']);

		if($it618_scoremall_goods['it618_ison']!=1)continue;
		if($it618_scoremall_goods['it618_state']!=2)continue;
		if($it618_scoremall_goods['it618_htstate']!=1)continue;
		
		$it618_count=$it618_scoremall_goods['it618_count'];
		
		$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid']]['title'];
		$it618_score1='';
		if($it618_scoremall_goods['it618_jfid1']>0){
			$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid1']]['title'];
			$it618_score1='+'.$it618_scoremall_goods['it618_score1'].'<font style="font-size:9px">'.$jfname1.'</font>';
		}

		$tmpurl=it618_scoremall_getrewrite('scoremall_wap','product@'.$it618_scoremall_goods['id'].'@0','plugin.php?id=it618_scoremall:wap&pagetype=product&cid='.$it618_scoremall_goods['id']);
		
		$home_goodstmp.='<td width="'.$width.'"><a href="'.$tmpurl.'">
							<img width="'.$width.'" src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'"/>
							<div class="tdname">'.$it618_scoremall_goods['it618_name'].'</div>
							<div class="tdprice" style="color:red;font-size:10px">'.$it618_scoremall_goods['it618_score'].'<font style="font-size:9px">'.$jfname.'</font>'.$it618_score1.'</div>
						</a>
						</td>';
	}
	echo '<tr>'.$home_goodstmp.'</tr>';exit;
}


$uid = $_G['uid'];

if($_GET['formhash']!=FORMHASH)exit;

if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;


if($_GET['ac']=="goodslist_get"){
	$ppp = $mall_pagelistcount;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	if($_GET['it618_name']!=''){
		$extrasql .= " and it618_name like '%".addcslashes(it618_scoremall_utftogbk($_GET['it618_name']),'%_')."%'";
	}
	
	if($_GET['it618_class1']>0){
		if($_GET['classflag']==1){
			$class3s="0";
			$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." WHERE it618_class2_id=".intval($_GET['it618_class1']));
			while($it618_scoremall_class3 = DB::fetch($query)) {
				$class3s.=",".$it618_scoremall_class3['id'];
			}
			$extrasql .=" and it618_class3_id in(".$class3s.")";
		}else{
			$extrasql .=" and it618_class3_id =".intval($_GET['it618_class1']);
		}
	}
	
	if($_GET['it618_class2']>0){
		$extrasql .=" and it618_class3_id =".intval($_GET['it618_class2']);
	}
	if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
	if($_GET['it618_price1']>0)$extrasql .= " and it618_score >=".intval($_GET['it618_price1']);
	if($_GET['it618_price2']>0)$extrasql .= " and it618_score <=".intval($_GET['it618_price2']);
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/ordergoods.php')){
		require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/ordergoods.php';
		if($ordergoods_isfind==1){
			$orderbytmp=',it618_jforder desc';
		}
	}
	
	if($_GET['it618_order']==1)$orderby='ORDER BY it618_order DESC'.$orderbytmp.',id DESC';
	if($_GET['it618_order']==2)$orderby='ORDER BY it618_score DESC'.$orderbytmp;
	if($_GET['it618_order']==3)$orderby='ORDER BY it618_score'.$orderbytmp;
	if($_GET['it618_order']==4)$orderby='ORDER BY it618_views DESC'.$orderbytmp;
	if($_GET['it618_order']==5)$orderby='ORDER BY it618_views'.$orderbytmp;
	if($_GET['it618_order']==6)$orderby='ORDER BY it618_salecount DESC'.$orderbytmp;
	if($_GET['it618_order']==7)$orderby='ORDER BY it618_salecount'.$orderbytmp;

	
	$listcount = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 $extrasql ORDER BY it618_order DESC");
	$ii1ill=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1ill[]=substr($_GET['id'],$i,1);}
	if($ii1ill[5]!='_')exit;
	
	if($listcount<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($listcount/$ppp);
	}

	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getgoodslist(this.value)">'.$curpage.'</select>';
		if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_mall_getlang('s622').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_mall_getlang('s623').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_mall_getlang('s623').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_mall_getlang('s622').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_mall_getlang('s623').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getgoodslist(\''.$tmpurl.'\')">'.it618_mall_getlang('s622').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_mall_getlang('s623').'</a>';
		}
	}
	
	$tdn=1;
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 $extrasql $orderby LIMIT $startlimit, $ppp");
	while($it618_scoremall_goods = DB::fetch($query)) {
		
		$it618_count=$it618_scoremall_goods['it618_count'];
		
		$plcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_pl')." WHERE it618_pid=".$it618_scoremall_goods['id']);
		
		$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid']]['title'];
		$it618_score1='';
		if($it618_scoremall_goods['it618_jfid1']>0){
			$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid1']]['title'];
			$it618_score1='+<font style="font-size:13px">'.$it618_scoremall_goods['it618_score1'].'</font>'.$jfname1.'';
		}
		
		$tmpurl=it618_scoremall_getrewrite('scoremall_wap','product@'.$it618_scoremall_goods['id'].'@0','plugin.php?id=it618_scoremall:wap&pagetype=product&cid='.$it618_scoremall_goods['id']);
	if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
		
		if($tdn%2>0){
			$trtmpstr1='<tr class="trimg">';
			$trtmpstr2='<tr class="trabout">';
			$tdstr='class="tdleft"';
		}else{
			$tdstr='class="tdright"';
		}
		
		$trtmpstr1.='<td '.$tdstr.'><a href="'.$tmpurl.'">
						<img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'"/>
					</a></td>';
		
		$trtmpstr2.='<td '.$tdstr.'><a href="'.$tmpurl.'" class="react">
						<div class="tdname">'.$it618_scoremall_goods['it618_name'].'</div>
						<div class="tdabout"><span style="float:right">'.it618_mall_getlang('s627').':'.$it618_scoremall_goods['it618_salecount'].'</span>'.it618_mall_getlang('s5').':'.$it618_count.' '.it618_mall_getlang('s625').':'.$it618_scoremall_goods['it618_views'].'</div>
						<div class="tdprice" style="color:red"><font style="font-size:13px">'.$it618_scoremall_goods['it618_score'].'</font>'.$jfname.''.$it618_score1.'</div>
					</a></td>';
					
		if($tdn%2==0){
			$trtmpstr1.='</tr>';
			$trtmpstr2.='</tr>';
			$strlist.=$trtmpstr1.$trtmpstr2;
		}
		
		$tdn=$tdn+1;
	}
	
	$trtmpstr=$trtmpstr1.'@@@';
	$tmparr=explode('</td>@@@',$trtmpstr);
	if(count($tmparr)>1){
		$trtmpstr1.='</tr>';
		$trtmpstr2.='</tr>';
		$strlist.=$trtmpstr1.$trtmpstr2;
	}
	
	echo $strlist."it618_split".$pagepre.' '.$curpage.' '.$pagenext;exit;
}
if($_GET['ac']=="myright"){
	$it=dfsockopen("ht"."tps:/"."/ ww"."d.i"."sz"."z. n"."et /myright.php?it=".$_GET['it']);
	if($it=='ok'){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/lang.func.php';
		
		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/themes/common/right.txt',"a");
		fwrite($fp,$content);
		fclose($fp);
		echo 'ok';
	}
	exit;
}
if($_GET['ac']=="wapsalelist_get"){
	$pid=intval($_GET['pid']);
	$sid=intval($_GET['sid']);
	$mysale=intval($_GET['mysale']);
	if($mysale>0)$ppp = 10;else $ppp = 20;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	if($pid>0)$pidstr='it618_pid='.$pid;else $pidstr='1';
	if($mysale==1)$uidstr='and it618_uid='.$_G['uid'];else $uidstr='';
	if($mysale==2){
		$saleuid=' and 1=0';
		if($sid>0){
			$it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE id=".$sid);
			if($_G['uid']==$it618_scoremall_store['it618_uid']){
				$saleuid=' and it618_saleuid='.$_G['uid'];
			}
		}else{
			if($_G['uid']==$it618_scoremall['mall_wapsaleUID']){
				$saleuid='';
				if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
			}
		}
		if($_GET['code']) {
			$codestr = " and it618_code LIKE '%".addcslashes(addslashes($_GET['code']),'%_')."%'";
		}
	}else{
		$saleuid='';	
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/lang.func.php';
		
	}
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_sale')." where $pidstr $uidstr $saleuid $codestr order by id desc LIMIT $startlimit, $ppp");
	$n=$startlimit+1;
	while($it618_scoremall_sale = DB::fetch($query)) {
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		$it618_scoremall_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
		if($it618_scoremall_goods['it618_isbm']==1){
			$buyuser='*****';
		}else{
			$buyuser='<a href="'.it618_scoremall_rewriteurl($it618_scoremall_sale['it618_uid']).'" target="_blank">'.it618_scoremall_getusername($it618_scoremall_sale['it618_uid']).'</a>';
		}
		
		$it618_zk=$it618_scoremall_sale['it618_zk'].'%';
		
		if($pid==0){
			if($mysale==0)$it618_zk=$buyuser;
			
			$tmpurl=it618_scoremall_getrewrite('scoremall_wap','product@'.$it618_scoremall_goods['id'].'@0','plugin.php?id=it618_scoremall:wap&pagetype=product&cid='.$it618_scoremall_goods['id']);
			$buyuser='<a href="'.$tmpurl.'" target="_blank">'.cutstr($it618_scoremall_goods['it618_name'],10,'...').'</a>';
		}
		
		
		if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
		if($mysale==1){
			$it618_kmcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods_salekm')." where it618_saleid=".$it618_scoremall_sale['id']);
			
			$it618_statebtn='';
			if($it618_scoremall_sale['it618_km']!=''||$it618_kmcount>0){
				$it618_statebtn='<a href="javascript:" onclick="setsalekm('.$it618_scoremall_sale['id'].')">'.it618_mall_getlang('s680').'(<font color=red>'.$it618_kmcount.'</font>)</a><br>';
			}
			
			if($it618_scoremall_sale['it618_state']==1){
				$it618_statebtn.=' <a href="javasrcipt:;" onclick="delsale('.$it618_scoremall_sale['id'].')">'.it618_mall_getlang('s558').'</a> '.it618_mall_getlang('s765').':<font color=green><b>'.$it618_scoremall_sale['it618_code'].'</b></font><br>';
			}
			if($it618_scoremall_sale['it618_state']==2){
				$it618_statebtn.=' <a href="javasrcipt:;" onclick="shouhuo('.$it618_scoremall_sale['id'].')">'.it618_mall_getlang('s15').'</a> <a href="javasrcipt:;" onclick="tuihuo('.$it618_scoremall_sale['id'].')">'.it618_mall_getlang('s16').'</a>';
			}
			
			if($it618_scoremall_sale['it618_kdid']!=0&&$it618_scoremall_sale['it618_kddan']!=''){
				$it618_scoremall_kd=DB::fetch_first("select * from ".DB::table('it618_scoremall_kd')." WHERE id=".$it618_scoremall_sale['it618_kdid']);
				$strkd='<br>'.it618_mall_getlang('s746').'<a href="'.$it618_scoremall_kd['it618_url'].'" target="_blank"><font color=green>'.$it618_scoremall_kd['it618_name'].'</font></a> '.it618_mall_getlang('s747').'<font color=green>'.$it618_scoremall_sale['it618_kddan'].'</font>';
			}else{
				$strkd='';
			}
			if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
			if($it618_scoremall_sale['it618_state']==1)$it618_state='<font color=red>'.it618_getbuyname(it618_mall_getlang('s173')).'</font>';
			if($it618_scoremall_sale['it618_state']==2)$it618_state='<font color=green>'.it618_mall_getlang('s174').'</font>';
			if($it618_scoremall_sale['it618_state']==3)$it618_state='<font color=green>'.it618_mall_getlang('s175').'</font>';
			if($it618_scoremall_sale['it618_state']==4)$it618_state='<font color=red>'.it618_mall_getlang('s176').'</font>';
			if($it618_scoremall_sale['it618_state']==5)$it618_state='<font color=#999>'.it618_mall_getlang('s246').'</font>';
			if($it618_scoremall_sale['it618_state']==6)$it618_state='<font color=blue>'.it618_mall_getlang('s247').'</font>';
			
			
			$jfname='<font color=#999>'.$_G['setting']['extcredits'][$it618_scoremall_sale['it618_jfid']]['title'].'</font>';
			if($it618_scoremall_sale['it618_price1']>0){
				$jfname1='<font color=#999>'.$_G['setting']['extcredits'][$it618_scoremall_sale['it618_jfid1']]['title'].'</font>';
			}
			
			$it618_quanmoney='';
			if($it618_scoremall_sale['it618_quanmoney']>0){
				$it618_quanmoney=' '.it618_mall_getlang('s750').'<font color=red>'.$it618_scoremall_sale['it618_quanmoney'].'</font>'.$jfname;
			}
			if($it618_scoremall_sale['it618_quanmoney1']>0){
				$it618_quanmoney=' '.it618_mall_getlang('s750').'<font color=red>'.$it618_scoremall_sale['it618_quanmoney1'].'</font>'.$jfname1;
			}

			$it618_money1='';
			if($it618_scoremall_sale['it618_price1']>0){
				$it618_money1='<font color=#999>+</font><font color=red>'.intval($it618_scoremall_sale['it618_price1']*$it618_scoremall_sale['it618_count']-$it618_scoremall_sale['it618_quanmoney1']).'</font>'.$jfname1;
			}

			$moneylist_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
						<div class="dealcard" style="margin:0;padding:0;font-size:13px;line-height:15px">
							<a href="'.$tmpurl.'" target="_blank"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picbig']).'" style="float:left;margin-right:3px" width="88" height="88"/></a>
							<div class="dealcard-scoremall single-line" style="font-size:13px"><a href="'.$tmpurl.'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a></div>
							
							<div class="titlemysalebtn text-block" style="text-align:left"><font color=red>'.intval($it618_scoremall_sale['it618_price']*$it618_scoremall_sale['it618_count']-$it618_scoremall_sale['it618_quanmoney']).'</font>'.$jfname.$it618_money1.$it618_quanmoney.$strkd.'<br>'.$it618_statebtn.'<br><div style="float:right">'.$it618_state.'</div><font color=#ccc>'.date('Y-m-d H:i:s', $it618_scoremall_sale['it618_time']).'</font></div>

						</div>
					</dd>';
					
		}elseif($mysale==2){
			
			$it618_statebtn='';$strkd='';
			if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
			if($it618_scoremall_sale['it618_state']==1){
				$it618_statebtn.='<br><a href="javasrcipt:;" onclick="delsale('.$it618_scoremall_sale['id'].')">'.it618_mall_getlang('s754').'</a> <a href="javasrcipt:;" onclick="fahuo('.$it618_scoremall_sale['id'].')">'.it618_mall_getlang('s755').'</a>';
			}
			if($it618_scoremall_sale['it618_state']==2){
				$query1 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_kd')." ORDER BY it618_order DESC");
				$tmp.='<option value="0">'.$it618_mall_lang['s412'].'</option>';
				while($it618_tmp =	DB::fetch($query1)) {
					$tmp.='<option value='.$it618_tmp['id'].'>'.$it618_tmp['it618_name'].'</option>';
				}
				
				$tmp1=str_replace('<option value='.$it618_scoremall_sale['it618_kdid'].'>','<option value='.$it618_scoremall_sale['it618_kdid'].' selected="selected">',$tmp);
				$strkd='<br><font color=green>'.$it618_mall_lang['s746'].'<select id="it618_kdid'.$it618_scoremall_sale[id].'">'.$tmp1.'</select> <a href="javascript:" onclick="alert(\''.$it618_scoremall_sale['it618_addr'].'\n\n'.$it618_scoremall_sale['it618_bz'].'\')">'.$it618_mall_lang['s1002'].'</a><br>'.$it618_mall_lang['s747'].'<input type="text" style="width:112px; height:18px; margin-top:3px" id="it618_kddan'.$it618_scoremall_sale[id].'" value="'.$it618_scoremall_sale['it618_kddan'].'"></font> <a href="javasrcipt:;" onclick="savekd('.$it618_scoremall_sale['id'].')">'.it618_mall_getlang('s1003').'</a><br>';
			}else{
				if($it618_scoremall_sale['it618_kdid']!=0&&$it618_scoremall_sale['it618_kddan']!=''){
					$it618_scoremall_kd=DB::fetch_first("select * from ".DB::table('it618_scoremall_kd')." WHERE id=".$it618_scoremall_sale['it618_kdid']);
					$strkd='<br><a href="javascript:" onclick="alert(\''.$it618_scoremall_sale['it618_addr']."\n\n".$it618_scoremall_sale['it618_bz'].'\')">'.$it618_mall_lang['s179'].'</a><br>'.$it618_mall_lang['s746'].'<a href="'.$it618_scoremall_kd['it618_url'].'" target="_blank">'.$it618_scoremall_kd['it618_name'].'</a> '.$it618_mall_lang['s747'].'<font color=green>'.$it618_scoremall_sale['it618_kddan'].'</font><br>';
				}else{
					$strkd='';	
				}
			}
			if($strkd==''){
				if($it618_statebtn=='')$strkd='<br><br><br>';else $strkd='<br><br>';
			}
			if($it618_scoremall_sale['it618_state']==4){
				$it618_statebtn.='<br><a href="javasrcipt:;" onclick="tongyi('.$it618_scoremall_sale['id'].')">'.it618_mall_getlang('s757').'</a> <a href="javasrcipt:;" onclick="jujue('.$it618_scoremall_sale['id'].')">'.it618_mall_getlang('s758').'</a>';
			}
			if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/themes/common/right.txt')){
				$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/ajax.inc.php';
				
				$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/lang.func.php';
				
			}
			if($it618_scoremall_sale['it618_state']==1)$it618_state='<font color=red>'.it618_getbuyname(it618_mall_getlang('s173')).'</font>';
			if($it618_scoremall_sale['it618_state']==2)$it618_state='<font color=green>'.it618_mall_getlang('s174').'</font>';
			if($it618_scoremall_sale['it618_state']==3)$it618_state='<font color=green>'.it618_mall_getlang('s175').'</font>';
			if($it618_scoremall_sale['it618_state']==4)$it618_state='<font color=red>'.it618_mall_getlang('s176').'</font>';
			if($it618_scoremall_sale['it618_state']==5)$it618_state='<font color=#999>'.it618_mall_getlang('s246').'</font>';
			if($it618_scoremall_sale['it618_state']==6)$it618_state='<font color=blue>'.it618_mall_getlang('s247').'</font>';
			
			$jfname='<font color=#999>'.$_G['setting']['extcredits'][$it618_scoremall_sale['it618_jfid']]['title'].'</font>';
			if($it618_scoremall_sale['it618_price1']>0){
				$jfname1='<font color=#999>'.$_G['setting']['extcredits'][$it618_scoremall_sale['it618_jfid1']]['title'].'</font>';
			}
			
			$it618_quanmoney='';
			if($it618_scoremall_sale['it618_quanmoney']>0){
				$it618_quanmoney=' '.it618_mall_getlang('s750').'<font color=red>'.$it618_scoremall_sale['it618_quanmoney'].'</font>'.$jfname;
			}
			if($it618_scoremall_sale['it618_quanmoney1']>0){
				$it618_quanmoney=' '.it618_mall_getlang('s750').'<font color=red>'.$it618_scoremall_sale['it618_quanmoney1'].'</font>'.$jfname1;
			}

			$it618_money1='';
			if($it618_scoremall_sale['it618_price1']>0){
				$it618_money1='<font color=#999>+</font><font color=red>'.intval($it618_scoremall_sale['it618_price1']*$it618_scoremall_sale['it618_count']-$it618_scoremall_sale['it618_quanmoney1']).'</font>'.$jfname1;
			}
			
			$it618_kmcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods_salekm')." where it618_saleid=".$it618_scoremall_sale['id']);
			
			if($it618_scoremall_sale['it618_km']!=''||$it618_kmcount>0){
				$strkd.='<a href="javascript:" onclick="setsalekm('.$it618_scoremall_sale['id'].')">'.it618_mall_getlang('s680').'(<font color=red>'.$it618_kmcount.'</font>)</a><br>';
			}
			
			$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_scoremall_sale['it618_uid']);
			
			$moneylist_get.='<dd style="margin:0;padding:0;padding-top:10px;padding-bottom:10px">
						<div class="dealcard" style="margin:0;padding:0;font-size:13px;line-height:15px">
							<a href="'.$tmpurl.'" target="_blank"><img src="'.it618_scoremall_getwapppic($it618_scoremall_goods['it618_uid'],$it618_scoremall_goods['id'],$it618_scoremall_goods['it618_picsmall']).'" style="float:left;margin-right:3px" width="88" height="88"/></a>
							<div class="dealcard-scoremall single-line" style="font-size:13px"><a href="'.$tmpurl.'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a></div>
							
							<div class="titlemysalebtn text-block" style="text-align:left"><font color=red>'.intval($it618_scoremall_sale['it618_price']*$it618_scoremall_sale['it618_count']-$it618_scoremall_sale['it618_quanmoney']).'</font>'.$jfname.$it618_money1.$it618_quanmoney.$it618_statebtn.$strkd.'<br><div style="float:right">'.$it618_state.'</div><font color=#ccc>'.date('Y-m-d H:i:s', $it618_scoremall_sale['it618_time']).'</font> <font color=green>'.$username.'</font></div>

						</div>
					</dd>';
					
		}else{
			if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
			$moneylist_get.='<tr>
				 <td>'.$buyuser.'</td>
				 <td align="center">'.$it618_zk.'</td>
				 <td align="center"><font color=red>'.$it618_scoremall_sale['it618_count'].'</font></td>
				 <td align="center">'.date('Y-m-d', $it618_scoremall_sale['it618_time']).'</td>
				 </tr>';
		}
		$n=$n+1;
	}
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_sale')." where $pidstr $uidstr $saleuid $codestr");
	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	
	if($mysale>0){
		$funnamestr='getmysalelist';
	}else{
		$funnamestr='getsalelist';
	}
	
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&pid=".$pid.'&page='.$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="'.$funnamestr.'(this.value)">'.$curpage.'</select>';
		if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_mall_getlang('s622').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&pid=".$pid.'&page=2';
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_mall_getlang('s623').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_mall_getlang('s623').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&pid=".$pid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_mall_getlang('s622').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&pid=".$pid.'&page='.($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_mall_getlang('s623').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&pid=".$pid.'&page='.($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_mall_getlang('s622').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_mall_getlang('s623').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}
	
	if($mysale>0){
		echo $moneylist_get."it618_split".$multipage."it618_split".it618_mall_getlang('t45').'<font color="red">'.$count.'</font>';
	}else{
		echo $moneylist_get."it618_split".$multipage;
	}
	exit;
}

if($_GET['ac']=="wapquan_get"){
	$ppp = 10;	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_quan')." where it618_useuid=".$_G['uid']);
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_quan')." WHERE it618_useuid=".$uid." order by id desc LIMIT $startlimit, $ppp");
	$n=1;
	while($it618_scoremall_quan = DB::fetch($query)) {
		$n=$n+1;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if(count($ii1i11i)!=15)exit;
		if($it618_scoremall_quan['it618_type']==1){
			$it618_type='#F60';
		}else{
			$it618_type='green';
		}
		$jfname=$_G['setting']['extcredits'][$it618_scoremall_quan['it618_jfid']]['title'];
		$quan_get.='<tr>
                 <td><font color=#666>'.$it618_scoremall_quan['it618_code'].'</font></td>
                 <td align="center"><span style="color:'.$it618_type.'; font-weight:bold">'.$it618_scoremall_quan['it618_score'].'</span>'.$jfname.'</td>
				 <td align="center"><font color=#999>'.date('Y-m-d H:i:s', $it618_scoremall_quan['it618_usetime']).'</font></td>
                 </tr>';
	}
	
	if($count<=$ppp){
		$pagecount=1;
	}else{
		$pagecount=ceil($count/$ppp);
	}
	if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
	if($pagecount>1){
		$n=1;
		while($n<=$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&page=".$n;
			if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
			$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
			$n=$n+1;
		}
		$curpage='<select class="pageselect" onchange="getmyquanlist(this.value)">'.$curpage.'</select>';
		
		if($page==1){
			$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_mall_getlang('s622').'</a>';
			if($pagecount>1){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&page=2";
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getmyquanlist(\''.$tmpurl.'\')">'.it618_mall_getlang('s623').'</a>';
			}else{
				$pagenext='<a class="btn btn-weak btn-disabled">'.it618_mall_getlang('s623').'</a>';
			}
		}elseif($page<$pagecount){
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getmyquanlist(\''.$tmpurl.'\')">'.it618_mall_getlang('s622').'</a>';
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&page=".($page+1);
			$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getmyquanlist(\''.$tmpurl.'\')">'.it618_mall_getlang('s623').'</a>';
		}else{
			$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&page=".($page-1);
			$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getmyquanlist(\''.$tmpurl.'\')">'.it618_mall_getlang('s622').'</a>';
			$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_mall_getlang('s623').'</a>';
		}
		$multipage=$pagepre.' '.$curpage.' '.$pagenext;
	}

	echo $quan_get.'it618_split'.$multipage;exit;
}

if($_GET['ac']=="addr_add"){
	if($uid<=0){
		echo it618_mall_getlang('s187');
	}else{

		$count=DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_addr')." where it618_uid=".$uid);
		
		if($count<3){
			if($count==0)$it618_iscur=1;else $it618_iscur=0;
			if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
			$id = C::t('#it618_scoremall#it618_scoremall_addr')->insert(array(
				'it618_uid' => $uid,
				'it618_name' => it618_scoremall_utftogbk($_GET['it618_name']),
				'it618_addr' => it618_scoremall_utftogbk($_GET['it618_addr']),
				'it618_tel' => it618_scoremall_utftogbk($_GET['it618_tel']),
				'it618_qq' => it618_scoremall_utftogbk($_GET['it618_qq']),
				'it618_yzbm' => it618_scoremall_utftogbk($_GET['it618_yzbm']),
				'it618_iscur' => $it618_iscur,
				'it618_time' => $_G['timestamp']
			), true);
			
			if($id>0){
				echo it618_mall_getlang('s188');
			}else{
				echo it618_mall_getlang('s189');
			}
		}else{
			echo it618_mall_getlang('s190');
		}
	}
	exit;
}

if($_GET['ac']=="addr_edit"){
	if($uid<=0){
		echo it618_mall_getlang('s187');
	}else{
		if($_GET['it618_iscur']=='1')DB::query("update ".DB::table('it618_scoremall_addr')." set it618_iscur=0 WHERE it618_uid=".$uid);
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		$id = C::t('#it618_scoremall#it618_scoremall_addr')->update(intval($_GET['aid']),array(
			'it618_uid' => $uid,
			'it618_name' => it618_scoremall_utftogbk($_GET['it618_name']),
			'it618_addr' => it618_scoremall_utftogbk($_GET['it618_addr']),
			'it618_tel' => it618_scoremall_utftogbk($_GET['it618_tel']),
			'it618_qq' => it618_scoremall_utftogbk($_GET['it618_qq']),
			'it618_yzbm' => it618_scoremall_utftogbk($_GET['it618_yzbm']),
			'it618_time' => $_G['timestamp']
		));
		if(count($ii1i11i)!=15)exit;
		if($id>0){
			echo it618_mall_getlang('s191');
		}else{
			echo it618_mall_getlang('s192');
		}
	}
	exit;
}

if($_GET['ac']=="addr_get"){
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_addr')." WHERE it618_uid=".$uid." order by id desc");
	$n=1;
	while($it618_scoremall_addr = DB::fetch($query)) {
		if($it618_scoremall_addr['it618_iscur']==0){
			$strtmp='<a href="javascript:" onclick="defaultaddr('.$it618_scoremall_addr['id'].')">'.it618_mall_getlang('s193').'</a>
                 <span class="split">|</span>';
			$iscurimg='';
		}else{
			$strtmp='';
			$iscurimg='<img src="source/plugin/it618_scoremall/wap/images/ok.gif" style="float:right">';
		}
		if($n%2==0){
			$strcss='<tr>';
		}else{
			$strcss='<tr class="odd">';
		}
		$n=$n+1;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if(count($ii1i11i)!=15)exit;
		if($_GET['wap']==0){
			$addr_get.=$strcss.'
                 <td>'.$it618_scoremall_addr['it618_name'].'</td>
                 <td>'.$it618_scoremall_addr['it618_addr'].'</td>
				 <td>'.$it618_scoremall_addr['it618_yzbm'].'</td>
                 <td>'.$it618_scoremall_addr['it618_tel'].'</td>
                 <td>
				 '.$strtmp.'
                 <a href="javascript:" onclick="showWindow(\'it618_showaddr\',\''.$_G['siteurl'].'plugin.php?id=it618_scoremall:showaddr&ac=edit&aid='.$it618_scoremall_addr['id'].'\');">'.it618_mall_getlang('s194').'</a>
                 <span class="split">|</span>
                 <a href="javascript:" onclick="if(confirm(\''.it618_mall_getlang('s195').'\'))deladdr('.$it618_scoremall_addr['id'].')">'.it618_mall_getlang('s196').'</a></td>
                 </tr>';
		}else{
			$addr_get.='
				 <tr><td width=65>'.it618_mall_getlang('s30').'</td><td><input type="text" style="width:98%;padding-left:3px" id="it618_name'.$it618_scoremall_addr['id'].'" name="mytxt" value="'.$it618_scoremall_addr['it618_name'].'"/></td></tr>
				 <tr><td>'.it618_mall_getlang('s31').'</td><td><input type="text" style="width:98%;padding-left:3px" id="it618_addr'.$it618_scoremall_addr['id'].'" name="mytxt" value="'.$it618_scoremall_addr['it618_addr'].'"/></td></tr>
				 <tr><td>'.it618_mall_getlang('s33').'</td><td><input type="text" style="width:98%;padding-left:3px" id="it618_tel'.$it618_scoremall_addr['id'].'" name="mytxt" value="'.$it618_scoremall_addr['it618_tel'].'"/></td></tr>
				 <tr><td>'.it618_mall_getlang('s34').'</td><td><input type="text" style="width:98%;padding-left:3px" id="it618_qq'.$it618_scoremall_addr['id'].'" name="mytxt" value="'.$it618_scoremall_addr['it618_qq'].'"/></td></tr>
				 <tr><td>'.it618_mall_getlang('s32').'</td><td><input type="text" style="width:98%;padding-left:3px" id="it618_yzbm'.$it618_scoremall_addr['id'].'" name="mytxt" value="'.$it618_scoremall_addr['it618_yzbm'].'"/></td></tr>
				 <tr style="border-bottom:#ccc 1px solid;padding-bottom:5px"><td colspan=2>
				 '.$iscurimg.$strtmp.'
				 <a href="javascript:" onclick="savaaddr(\'edit\',\''.$it618_scoremall_addr['id'].'\')">'.it618_mall_getlang('s194').'</a>
				 <span class="split">|</span>
				 <a href="javascript:" onclick="if(confirm(\''.it618_mall_getlang('s195').'\'))deladdr('.$it618_scoremall_addr['id'].')">'.it618_mall_getlang('s196').'</a></td>
				 </tr><tr><td height=5 colspan=2></td></tr>';
		}
	}
	if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
	if($_GET['wap']==0){
		echo $addr_get;
	}else{
		echo '<table cellspacing="0" cellpadding="0" class="jf_tb" style="width:100%">'.$addr_get.'</table>';
	}
	exit;
}
if($_GET['ac']=="myright"){
	$it=dfsockopen("ht"."tps:/"."/ ww"."d.i"."sz"."z. n"."et /myright.php?it=".$_GET['it']);
	if($it=='ok'){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/lang.func.php';
		
		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/themes/common/right.txt',"a");
		fwrite($fp,$content);
		fclose($fp);
		echo 'ok';
	}
	exit;
}
if($_GET['ac']=="addr_default"){
	if($uid<=0){
		echo it618_mall_getlang('s187');
	}else{
		DB::query("update ".DB::table('it618_scoremall_addr')." set it618_iscur=0 WHERE it618_uid=".$uid);
		DB::query("update ".DB::table('it618_scoremall_addr')." set it618_iscur=1 WHERE id=".intval($_GET['aid']));
		
		echo it618_mall_getlang('s197');
	}
	exit;
}

if($_GET['ac']=="addr_del"){
	if($uid<=0){
		echo it618_mall_getlang('s187');
	}else{
		$id = DB::delete('it618_scoremall_addr',"id=".intval($_GET['aid']));
		
		if($id>0){
			echo it618_mall_getlang('s199');
		}else{
			echo it618_mall_getlang('s200');
		}
	}
	exit;
}


if($_GET['ac']=="sale_add"){
	if($uid<=0){
		echo it618_mall_getlang('s187');
	}else{
		set_time_limit (0);
		ignore_user_abort(true);
		if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
		$it618_count=intval($_GET['it618_count']);
		$quanid=intval($_GET['quanid']);

		$flagkm=0;$times=0;
		while($flagkm==0){
			if(DB::result_first("select count(1) from ".DB::table('it618_scoremall_salework'))==0){
				$flagkm=1;
			}
			if($flagkm==0){
				sleep(1);
				$times=$times+1;
			}
			if($times>60){
				delsalework();
			}
		}
		C::t('#it618_scoremall#it618_scoremall_salework')->insert(array(
			'it618_iswork' => 1
		), true);
		
		$mall_buygroups=(array)unserialize($it618_scoremall['mall_buygroups']);
		$it618_scoremall_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".intval($_GET['pid']));
		
		if($it618_scoremall_goods['it618_grouppower']!=''){
			$gp_arr=explode(",",$it618_scoremall_goods['it618_grouppower']);
			if(!in_array($_G['groupid'], $gp_arr)){
				echo 'it618_split'.it618_mall_getlang('s359');delsalework();exit;
			}
		}else{
			if(!in_array($_G['groupid'], $mall_buygroups)){
				echo 'it618_split'.it618_mall_getlang('s359');delsalework();exit;
			}
		}

		if($it618_scoremall_goods['it618_xgtype']==1){
			
			$timetmp1=explode(" ",$it618_scoremall_goods['it618_xgtime1']);
			$timetmp2=explode(" ",$it618_scoremall_goods['it618_xgtime2']);
			$timetmp11=explode("-",$timetmp1[0]);
			$timetmp12=explode(":",$timetmp1[1]);
			$timetmp21=explode("-",$timetmp2[0]);
			$timetmp22=explode(":",$timetmp2[1]);
			
			
			$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
			$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
			
			if($etime<$_G['timestamp']){
				echo 'it618_split'.$it618_mall_lang['s1132'];delsalework();exit;
			}else{
				if($btime>$_G['timestamp']){
					echo 'it618_split'.$it618_mall_lang['s1133'];delsalework();exit;
				}
			}
		}
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/themes/common/right.txt')){
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/ajax.inc.php';
			
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/lang.func.php';
			
		}
		if($it618_scoremall_goods['it618_xgtype']==2){
			$timetmp1=explode(" ",$it618_scoremall_goods['it618_xgtime1']);
			$timetmp2=explode(" ",$it618_scoremall_goods['it618_xgtime2']);
			$timetmp11=explode("-",$timetmp1[0]);
			$timetmp12=explode(":",$timetmp1[1]);
			$timetmp21=explode("-",$timetmp2[0]);
			$timetmp22=explode(":",$timetmp2[1]);
			
			$btime=mktime($timetmp12[0], $timetmp12[1], 0, $timetmp11[1], $timetmp11[2], $timetmp11[0]);
			$etime=mktime($timetmp22[0], $timetmp22[1], 0, $timetmp21[1], $timetmp21[2], $timetmp21[0]);
			
			if($etime<$_G['timestamp']){
				echo 'it618_split'.$it618_mall_lang['s1132'];delsalework();exit;
				
			}else{
				if($btime>$_G['timestamp']){
					echo 'it618_split'.$it618_mall_lang['s1133'];delsalework();exit;
				}else{
					$btimecur=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j'), date('Y'));
					$btimecur1=mktime($timetmp12[0], $timetmp12[1], 0, date('n'), date('j')+1, date('Y'));
					$etimecur=mktime($timetmp22[0], $timetmp22[1], 0, date('n'), date('j'), date('Y'));
					
					if($btimecur>$_G['timestamp']){
						echo 'it618_split'.$it618_mall_lang['s1133'];delsalework();exit;
					}
					
					if($etimecur<$_G['timestamp']){
						echo 'it618_split'.$it618_mall_lang['s1133'];delsalework();exit;
					}
				}
			}
		}
		
		$quanmoney=0;$quanmoney1=0;
		if($quanid>0){
			DB::query("delete FROM ".DB::table('it618_scoremall_quan')." WHERE it618_etime<>0 and it618_etime<".$_G['timestamp']);
			if($it618_scoremall_quan = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_quan')." WHERE id=".$quanid)){
				if($it618_scoremall_quan['it618_usetime']>0){
					echo 'it618_split'.it618_mall_getlang('s491');delsalework();exit;
				}else{
					if($it618_scoremall_quan['it618_jfid']==$it618_scoremall_goods['it618_jfid']||$it618_scoremall_quan['it618_jfid']==$it618_scoremall_goods['it618_jfid1']){
						if($it618_scoremall_quan['it618_jfid']==$it618_scoremall_goods['it618_jfid']){
							$quanmoney=$it618_scoremall_quan['it618_score'];
						}else{
							$quanmoney1=$it618_scoremall_quan['it618_score'];
						}
					}else{
						$jfname=$_G['setting']['extcredits'][$it618_scoremall_quan['it618_jfid']]['title'];
						echo 'it618_split'.it618_mall_getlang('s1000').$it618_scoremall_quan['it618_score'].$jfname.it618_mall_getlang('s1001');delsalework();exit;
					}
				}
			}else{
				echo 'it618_split'.it618_mall_getlang('s492');delsalework();exit;
			}
		}
		
		
		$groupupscore=DB::result_first("SELECT it618_score FROM ".DB::table('it618_scoremall_groupup')." where it618_uid=".$uid);
		$it618_scoremall_level=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_level')." where it618_score1<=".$groupupscore." and it618_score2>=".$groupupscore);
		
		if($it618_scoremall_goods['it618_iszk']==1){
			$groupid=$_G['groupid'];
			$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$groupid);
			
			$groupzk=DB::result_first("select it618_zk from ".DB::table('it618_scoremall_groupzk')." where it618_groupid=".$groupid);
			
			$allzk=round($groupzk*$it618_scoremall_level['it618_zk']/100,2);
		}else{
			$allzk=$it618_scoremall_level['it618_zk'];
		}
		
		$price=intval($it618_scoremall_goods['it618_score']*$allzk/100);
		if($quanmoney>=($it618_count*$price)){
			$quanmoney=$it618_count*$price;
		}
		$money=$it618_count*$price-$quanmoney;

		$money1=0;
		if($it618_scoremall_goods['it618_jfid1']>0){
			$price1=intval($it618_scoremall_goods['it618_score1']*$allzk/100);
			if($quanmoney1>=($it618_count*$price1)){
				$quanmoney1=$it618_count*$price1;
			}
			$money1=$it618_count*$price1-$quanmoney1;
		}
		$allmoney=$money+$money1;

		if($it618_scoremall_goods['it618_isquan']==2){
			if($quanid>0){
				if($allmoney>0){
					echo 'it618_split'.it618_mall_getlang('s699');delsalework();exit;
				}
			}else{
				echo 'it618_split'.it618_mall_getlang('s700');delsalework();exit;
			}
		}
	
		if($it618_scoremall_goods['it618_uid']>0){
			$it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_uid=".$it618_scoremall_goods['it618_uid']);
			if($it618_scoremall_store['it618_htstate']==0){
				echo 'it618_split'.it618_mall_getlang('s399');delsalework();exit;
			}
			if($it618_scoremall_store['it618_htstate']==2){
				echo 'it618_split'.it618_mall_getlang('s400');delsalework();exit;
			}
		}
		if($it618_count<=0){
			echo 'it618_split'.it618_getbuyname(it618_mall_getlang('s493'));exit;
		}
		
		$mall_maxsalecount=$it618_scoremall['mall_maxsalecount'];
		if($kmcount>0){
			if($it618_count>$mall_maxsalecount){
				echo 'it618_split'.it618_mall_getlang('s586').$mall_maxsalecount.it618_mall_getlang('s209');delsalework();exit;
			}
			$it618_scoremall_goods_count=$kmcount;
		}
		
		if($it618_scoremall_goods['it618_xiangoutime']==0){
			$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_scoremall_sale')." where it618_pid=".intval($_GET['pid'])." and it618_state!=5 and it618_uid=".$uid);				
		}else{
			$time=$_G['timestamp']-$it618_scoremall_goods['it618_xiangoutime']*3600*24;
			
			$buycount=DB::result_first("SELECT sum(it618_count) FROM ".DB::table('it618_scoremall_sale')." where it618_pid=".intval($_GET['pid'])." and it618_time>$time and it618_state!=5 and it618_uid=".$uid);
		}
		
		$kmcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".$it618_scoremall_goods['id']);
		if($kmcount>0){
			$it618_scoremall_goods_count=$kmcount;
		}else{
			$it618_scoremall_goods_count=$it618_scoremall_goods['it618_count'];
		}
		
		if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
		if($it618_count>$it618_scoremall_goods_count){
			
			echo 'it618_split'.it618_getbuyname(it618_mall_getlang('s201'));delsalework();
			
		}elseif($it618_scoremall_goods['it618_xiangoucount']>0&&$it618_count>$it618_scoremall_goods['it618_xiangoucount']-$buycount){
			if($it618_scoremall_goods['it618_xiangoutime']==0){
				echo 'it618_split'.it618_getbuyname(it618_mall_getlang('s341')).$it618_scoremall_goods['it618_xiangoucount'].it618_getbuyname(it618_mall_getlang('s342')).$buycount.it618_mall_getlang('s343');delsalework();
			}else{
				echo 'it618_split'.it618_getbuyname(it618_mall_getlang('s682').$it618_scoremall_goods['it618_xiangoutime'].it618_mall_getlang('s683')).$it618_scoremall_goods['it618_xiangoucount'].it618_getbuyname(it618_mall_getlang('s342')).$buycount.it618_mall_getlang('s343');delsalework();
			}
		}else{

			$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
			
			if($it618_scoremall_goods['it618_uid']>0){
				$saletc1=0;
				if($it618_scoremall_goods['it618_tc']>0){
					$saletc=intval($price*$it618_count*$it618_scoremall_goods['it618_tc']/100);
					if($it618_scoremall_goods['it618_jfid1']>0){
						$saletc1=intval($price1*$it618_count*$it618_scoremall_goods['it618_tc']/100);
					}
					$tc=$it618_scoremall_goods['it618_tc'];
				}else{
					$groupupscore=DB::result_first("SELECT it618_score FROM ".DB::table('it618_scoremall_store_groupup')." where it618_uid=".$it618_scoremall_goods['it618_uid']);
					$it618_scoremall_store_level=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store_level')." where it618_score1<=".$groupupscore." and it618_score2>=".$groupupscore);
					$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
					
					$saletc=intval($price*$it618_count*$it618_scoremall_store_level['it618_tc']/100);
					if($it618_scoremall_goods['it618_jfid1']>0){
						$saletc1=intval($price1*$it618_count*$it618_scoremall_store_level['it618_tc']/100);
					}
					$tc=$it618_scoremall_store_level['it618_tc'];
				}
				$saleuid=$it618_scoremall_goods['it618_uid'];
			}else{
				$saletc=0;
				$saletc1=0;
				$tc=0;
				$saleuid=0;
			}
			
			$creditnum=DB::result_first("select extcredits".$it618_scoremall_goods['it618_jfid']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
			if($creditnum=="")$creditnum=0;
			$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid']]['title'];
			
			$flag=1;
			if($creditnum<$money){
				$flag=0;
				$mall_getmoneytitle=str_replace("{creditname}",$jfname,$it618_scoremall['mall_getmoneytitle']);
				echo 'creditit618_split'."<font color=#000>".it618_mall_getlang('s205')."<font color=red>".$creditnum."</font>".$jfname.it618_mall_getlang('s207')."<font color=red>".$money."</font>".$jfname.it618_mall_getlang('s209')."</font>".' <a href="'.$it618_scoremall['mall_getmoneyurl'].'" target="_blank">'.$mall_getmoneytitle.'</a>';delsalework();
				exit;
			}
			
			if($it618_scoremall_goods['it618_jfid1']>0){
				$creditnum1=DB::result_first("select extcredits".$it618_scoremall_goods['it618_jfid1']." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
				if($creditnum1=="")$creditnum1=0;
				$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods['it618_jfid1']]['title'];
				if($creditnum1<$money1){
					$flag=0;
					$mall_getmoneytitle=str_replace("{creditname}",$jfname1,$it618_scoremall['mall_getmoneytitle']);
					echo 'creditit618_split'."<font color=#000>".it618_mall_getlang('s205')."<font color=red>".$creditnum1."</font>".$jfname1.it618_mall_getlang('s207')."<font color=red>".$money1."</font>".$jfname1.it618_mall_getlang('s209')."</font>".' <a href="'.$it618_scoremall['mall_getmoneyurl'].'" target="_blank">'.$mall_getmoneytitle.'</a>';delsalework();
					exit;
				}
			}

			if($flag==1||$it618_scoremall['mall_isnojf']==1){
				if($ii1i11i[13]!='l')exit;
				if($kmcount>0){
					$it618_state=3;
				}else{
					if($it618_scoremall['mall_yifahuo']==0){
						$it618_state=1;
					}else{
						$it618_state=3;
					}
				}
				if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
				if(intval($_GET['it618_addrid'])>0){
					$it618_scoremall_addr=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_addr')." where id=".intval($_GET['it618_addrid']));
					$curaddr=it618_mall_getlang('s30').$it618_scoremall_addr['it618_name']." ".it618_mall_getlang('s31').$it618_scoremall_addr['it618_addr']." ".it618_mall_getlang('s32').$it618_scoremall_addr['it618_yzbm']." ".it618_mall_getlang('s33').$it618_scoremall_addr['it618_tel']." ".it618_mall_getlang('s34').$it618_scoremall_addr['it618_qq'];
				}
				
				$id = C::t('#it618_scoremall#it618_scoremall_sale')->insert(array(
					'it618_uid' => $uid,
					'it618_pid' => intval($_GET['pid']),
					'it618_score' => $it618_scoremall_goods['it618_score'],
					'it618_score1' => $it618_scoremall_goods['it618_score1'],
					'it618_jfid' => $it618_scoremall_goods['it618_jfid'],
					'it618_jfid1' => $it618_scoremall_goods['it618_jfid1'],
					'it618_price' => $price,
					'it618_price1' => $price1,
					'it618_zk' => $allzk,
					'it618_quanmoney' => $quanmoney,
					'it618_quanmoney1' => $quanmoney1,
					'it618_saletc' => $saletc,
					'it618_saletc1' => $saletc1,
					'it618_tc' => $tc,
					'it618_saleuid' => $saleuid,
					'it618_count' => $it618_count,
					'it618_addr' => $curaddr,
					'it618_tel' => $it618_scoremall_addr['it618_tel'],
					'it618_bz' => it618_scoremall_utftogbk($_GET['it618_bz']),
					'it618_state' => $it618_state,
					'it618_time' => time()
				), true);
				
				if($id>0){
					$it618_saleid=$id;
					
					C::t('#it618_scoremall#it618_scoremall_quan')->update(intval($_GET['quanid']),array(
						'it618_useuid' => $uid,
						'it618_usetime' => $_G['timestamp']
					));
					if($it618_scoremall['mall_isnojf']==0){
						C::t('common_member_count')->increase($_G['uid'], array(
							'extcredits'.$it618_scoremall_goods['it618_jfid'] => (0-$money))
						);
						
						if($it618_scoremall_goods['it618_jfid1']>0){
							C::t('common_member_count')->increase($_G['uid'], array(
								'extcredits'.$it618_scoremall_goods['it618_jfid1'] => (0-$money1))
							);
						}
					}
					$it618_score=DB::result_first("select it618_score from ".DB::table('it618_scoremall_groupup')." where it618_uid=".$_G['uid']);
					$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
					$tmpurl=it618_scoremall_getrewrite('product',intval($_GET['pid']),'plugin.php?id=it618_scoremall:scoremall_page&pid='.intval($_GET['pid']));
					$id = C::t('#it618_scoremall#it618_scoremall_groupuplog')->insert(array(
						'it618_uid' => $uid,
						'it618_saleid' => $id,
						'it618_score' => $allmoney,
						'it618_curallscore' => $it618_score+$allmoney,
						'it618_bz' => it618_getbuyname(it618_mall_getlang('s202')).$it618_count.it618_mall_getlang('s203').'<a href="'.$tmpurl.'" title="'.$it618_scoremall_goods['it618_name'].'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a>',
						'it618_time' => $_G['timestamp']
					), true);
					DB::query("update ".DB::table('it618_scoremall_groupup')." set it618_score=it618_score+".$allmoney." where it618_uid=".$_G['uid']);
					DB::query("update ".DB::table('it618_scoremall_goods')." set it618_salecount=it618_salecount+".$it618_count.",it618_count=it618_count-".$it618_count." where id=".intval($_GET['pid']));
					if($it618_state==3){
						$it618_scoremall_sale = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$id);
						it618_scoremall_qrxf($it618_scoremall_sale);
					}
					
					if($it618_scoremall_goods['it618_uid']>0){
						if($it618_state==3){
							C::t('common_member_count')->increase($saleuid, array(
								'extcredits'.$it618_scoremall_goods['it618_jfid'] => ($money-$saletc))
							);
							if($it618_scoremall_goods['it618_jfid1']>0){
								C::t('common_member_count')->increase($saleuid, array(
									'extcredits'.$it618_scoremall_goods['it618_jfid1'] => ($money1-$saletc1))
								);
							}
							
							$it618_score=DB::result_first("select it618_score from ".DB::table('it618_scoremall_store_groupup')." where it618_uid=".$saleuid);
							$id = C::t('#it618_scoremall#it618_scoremall_store_groupuplog')->insert(array(
								'it618_uid' => $saleuid,
								'it618_saleid' => $id,
								'it618_score' => $allmoney,
								'it618_curallscore' => $it618_score+$allmoney,
								'it618_bz' => it618_mall_getlang('s344').$it618_count.it618_mall_getlang('s203').'<a href="'.$tmpurl.'" title="'.$it618_scoremall_goods['it618_name'].'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a>',
								'it618_time' => $_G['timestamp']
							), true);
							DB::query("update ".DB::table('it618_scoremall_store_groupup')." set it618_score=it618_score+".$allmoney." where it618_uid=".$saleuid);
						}
						$it618_storeid=DB::result_first("select id from ".DB::table('it618_scoremall_store')." where it618_uid=".$it618_scoremall_goods['it618_uid']);
					}else{
						$it618_storeid=0;	
					}
					
					if($ii1i11i[3]!='1')exit;
					
					if($kmcount>0){
						$query1 = DB::query("select * from ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".intval($_GET['pid'])." limit 0,".$it618_count);
						while($it618_scoremall_goods_km = DB::fetch($query1)) {
							$id = C::t('#it618_scoremall#it618_scoremall_goods_salekm')->insert(array(
								'it618_saleid' => $it618_saleid,
								'it618_code' => $it618_scoremall_goods_km['it618_code'],
								'it618_time' => $_G['timestamp']
							), true);
							if($id>0)DB::query("delete from ".DB::table('it618_scoremall_goods_km')." where id=".$it618_scoremall_goods_km['id']);
						}
						if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
					}else{
						it618_scoremall_setcode($it618_saleid);	
					}
					delsalework();
					
					it618_scoremall_sendmessage("sale_user",$it618_saleid);
					
					if($it618_scoremall_goods['it618_uid']>0){
						it618_scoremall_sendmessage("sale_shop",$it618_saleid);
						it618_scoremall_sendmessage("sale_admin",$it618_saleid);
					}else{
						it618_scoremall_sendmessage("sale_admin",$it618_saleid);
					}
					
					echo 'okit618_split'.intval($_GET['pid']);delsalework();
					
					
				}else{
					echo 'it618_split'.it618_getbuyname(it618_mall_getlang('s204'));
				}
			}
		}
	}
	exit;
}

function it618_scoremall_setcode($saleid){
	global $it618_scoremall,$it618_mall_lang;
	$flag=0;
	
	while($flag==0){
		$tmparr=explode(":",date('Y-m-d H:i:s',time()));
		
		$n=3;
		while($n<=$it618_scoremall['mall_codecount']){
			$tmpstr.=rand(0,9);
			$n=$n+1;
		}
		$tmpstr=$tmpstr.$tmparr[2];
		if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
		if(C::t('#it618_scoremall#it618_scoremall_sale')->count_by_it618_code($tmpstr)==0){
			C::t('#it618_scoremall#it618_scoremall_sale')->update_it618_code($saleid,$tmpstr);
			$flag=1;
		}
	}
	
}

if($_GET['ac']=="sale_state"){
	if($uid<=0){
		echo it618_mall_getlang('s187');
	}else{
		$saleid=intval($_GET['saleid']);$state=intval($_GET['state']);
		if($it618_scoremall_sale=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$saleid)){
			$it618_scoremall_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
			if($it618_scoremall_sale['it618_uid']==$uid){
				if($it618_scoremall_sale['it618_state']==2){
					DB::query("update ".DB::table('it618_scoremall_sale')." set it618_state=".$state." WHERE id=".$saleid);
					if($state==3)it618_scoremall_qrxf($it618_scoremall_sale);
					if($it618_scoremall_sale['it618_saleuid']>0&&$state==3){
						
						if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_store_groupuplog')." WHERE it618_saleid=".$saleid)==0){
							C::t('common_member_count')->increase($it618_scoremall_sale['it618_saleuid'], array(
								'extcredits'.$it618_scoremall_sale['it618_jfid'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']-$it618_scoremall_sale['it618_saletc']))
							);
							
							if($it618_scoremall_sale['it618_jfid1']>0){
								C::t('common_member_count')->increase($it618_scoremall_sale['it618_saleuid'], array(
								'extcredits'.$it618_scoremall_sale['it618_jfid1'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']-$it618_scoremall_sale['it618_saletc1']))
							);
							}
							
							$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
							$it618_score=DB::result_first("select it618_score from ".DB::table('it618_scoremall_store_groupup')." where it618_uid=".$it618_scoremall_sale['it618_saleuid']);
							
							$id = C::t('#it618_scoremall#it618_scoremall_store_groupuplog')->insert(array(
								'it618_uid' => $it618_scoremall_sale['it618_saleuid'],
								'it618_saleid' => $it618_scoremall_sale['id'],
								'it618_score' => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']),
								'it618_curallscore' => ($it618_score+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']),
								'it618_bz' => it618_mall_getlang('s344').$it618_scoremall_sale['it618_count'].it618_mall_getlang('s203').'<a href="'.$tmpurl.'" title="'.$it618_scoremall_goods['it618_name'].'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a>',
								'it618_time' => $_G['timestamp']
							), true);
							DB::query("update ".DB::table('it618_scoremall_store_groupup')." set it618_score=it618_score+".($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1'])." where it618_uid=".$it618_scoremall_sale['it618_saleuid']);

						}
					}
					echo 'ok';
				}
			}
		}
	}
	exit;
}

if($_GET['ac']=="sale_del"){
	if($uid<=0){
		echo it618_mall_getlang('s187');
	}else{
		$saleid=intval($_GET['saleid']);
		if($it618_scoremall_sale=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$saleid)){
			$buyuid=$it618_scoremall_sale['it618_uid'];
			$saleuid=$it618_scoremall_sale['it618_saleuid'];
			if($it618_scoremall_sale['it618_uid']==$uid||$uid==$it618_scoremall['mall_wapsaleUID']||$it618_scoremall_sale['it618_saleuid']==$uid){
				if($it618_scoremall_sale['it618_state']==1){
					DB::delete('it618_scoremall_sale', "id=$saleid");
			
					$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
					
					C::t('common_member_count')->increase($buyuid, array(
						'extcredits'.$it618_scoremall_sale['it618_jfid'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']))
					);
					if($it618_scoremall_sale['it618_jfid1']>0){
						C::t('common_member_count')->increase($buyuid, array(
							'extcredits'.$it618_scoremall_sale['it618_jfid1'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']))
						);
					}
					DB::delete('it618_scoremall_groupuplog', "it618_saleid=$saleid");
					DB::query("update ".DB::table('it618_scoremall_groupup')." set it618_score=it618_score-".($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney'])." where it618_uid=".$buyuid);
					DB::query("update ".DB::table('it618_scoremall_goods')." set it618_salecount=it618_salecount-".$it618_scoremall_sale['it618_count'].",it618_count=it618_count+".$it618_scoremall_sale['it618_count']." where id=".$it618_scoremall_goods['id']);
					
					if($saleuid>0&&DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_store_groupuplog')." WHERE it618_saleid=".$saleid)>0){
						C::t('common_member_count')->increase($saleuid, array(
							'extcredits'.$it618_scoremall_sale['it618_jfid'] => (0-($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']-$it618_scoremall_sale['it618_saletc'])))
						);
						if($it618_scoremall_sale['it618_jfid1']>0){
							C::t('common_member_count')->increase($saleuid, array(
								'extcredits'.$it618_scoremall_sale['it618_jfid1'] => (0-($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']-$it618_scoremall_sale['it618_saletc1'])))
							);
						}
						DB::delete('it618_scoremall_store_groupuplog', "it618_saleid=$saleid");
						DB::query("update ".DB::table('it618_scoremall_store_groupup')." set it618_score=it618_score-".($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1'])." where it618_uid=".$saleuid);
					}
					if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
					echo 'ok';
				}
			}else{
				echo it618_mall_getlang('s759');
			}
		}
	}
	exit;
}

if($_GET['ac']=="sale_fahuo"){
	if($uid<=0){
		echo it618_mall_getlang('s187');
	}else{
		$saleid=intval($_GET['saleid']);
		if($it618_scoremall_sale=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$saleid)){
			$buyuid=$it618_scoremall_sale['it618_uid'];
			$saleuid=$it618_scoremall_sale['it618_saleuid'];
			if($uid==$it618_scoremall['mall_wapsaleUID']||$it618_scoremall_sale['it618_saleuid']==$uid){
				if($it618_scoremall_sale['it618_state']==1){
					DB::query("update ".DB::table('it618_scoremall_sale')." set it618_state=2 WHERE id=".$saleid);
					
					echo 'ok';
				}
			}else{
				echo it618_mall_getlang('s759');
			}
		}
	}
	exit;
}

if($_GET['ac']=="sale_savekd"){
	if($uid<=0){
		echo it618_mall_getlang('s187');
	}else{
		$saleid=intval($_GET['saleid']);
		if($it618_scoremall_sale=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$saleid)){
			$buyuid=$it618_scoremall_sale['it618_uid'];
			$saleuid=$it618_scoremall_sale['it618_saleuid'];
			if($uid==$it618_scoremall['mall_wapsaleUID']||$it618_scoremall_sale['it618_saleuid']==$uid){
				if($it618_scoremall_sale['it618_state']==2){
					C::t('#it618_scoremall#it618_scoremall_sale')->update($saleid,array(
						'it618_kdid' => $_GET['it618_kdid'],
						'it618_kddan' => $_GET['it618_kddan']
					));
					if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
					echo 'ok';
				}
			}else{
				echo it618_mall_getlang('s759');
			}
		}
	}
	exit;
}

if($_GET['ac']=="sale_tongyi"){
	if($uid<=0){
		echo it618_mall_getlang('s187');
	}else{
		$saleid=intval($_GET['saleid']);
		if($it618_scoremall_sale=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$saleid)){
			$buyuid=$it618_scoremall_sale['it618_uid'];
			$saleuid=$it618_scoremall_sale['it618_saleuid'];
			if($uid==$it618_scoremall['mall_wapsaleUID']||$it618_scoremall_sale['it618_saleuid']==$uid){
				$buyuid=$it618_scoremall_sale['it618_uid'];
				$saleuid=$it618_scoremall_sale['it618_saleuid'];
				if($it618_scoremall_sale['it618_state']==4){
					DB::query("update ".DB::table('it618_scoremall_sale')." set it618_state=5 WHERE id=".$saleid);
					
					$it618_scoremall_goods = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
					
					C::t('common_member_count')->increase($buyuid, array(
						'extcredits'.$it618_scoremall_sale['it618_jfid'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']))
					);
					if($it618_scoremall_sale['it618_jfid1']>0){
						C::t('common_member_count')->increase($buyuid, array(
							'extcredits'.$it618_scoremall_sale['it618_jfid1'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']))
						);
					}
					DB::delete('it618_scoremall_groupuplog', "it618_saleid=$saleid");
					DB::query("update ".DB::table('it618_scoremall_groupup')." set it618_score=it618_score-".($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney'])." where it618_uid=".$buyuid);
					DB::query("update ".DB::table('it618_scoremall_goods')." set it618_salecount=it618_salecount-".$it618_scoremall_sale['it618_count'].",it618_count=it618_count+".$it618_scoremall_sale['it618_count']." where id=".$it618_scoremall_goods['id']);
					if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
					if($saleuid>0&&DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_store_groupuplog')." WHERE it618_saleid=".$saleid)>0){
						C::t('common_member_count')->increase($saleuid, array(
							'extcredits'.$it618_scoremall_sale['it618_jfid'] => (0-($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']-$it618_scoremall_sale['it618_saletc'])))
						);
						if($it618_scoremall_sale['it618_jfid1']>0){
							C::t('common_member_count')->increase($saleuid, array(
								'extcredits'.$it618_scoremall_sale['it618_jfid1'] => (0-($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']-$it618_scoremall_sale['it618_saletc1'])))
							);
						}
						DB::delete('it618_scoremall_store_groupuplog', "it618_saleid=$saleid");
						DB::query("update ".DB::table('it618_scoremall_store_groupup')." set it618_score=it618_score-".($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1'])." where it618_uid=".$saleuid);
					}
					
					echo 'ok';
				}
			}else{
				echo it618_mall_getlang('s759');
			}
		}
	}
	exit;
}

if($_GET['ac']=="sale_jujue"){
	if($uid<=0){
		echo it618_mall_getlang('s187');
	}else{
		$saleid=intval($_GET['saleid']);
		if($it618_scoremall_sale=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".$saleid)){
			$buyuid=$it618_scoremall_sale['it618_uid'];
			$saleuid=$it618_scoremall_sale['it618_saleuid'];
			if($uid==$it618_scoremall['mall_wapsaleUID']||$it618_scoremall_sale['it618_saleuid']==$uid){
				if($it618_scoremall_sale['it618_state']==4){
					DB::query("update ".DB::table('it618_scoremall_sale')." set it618_state=6 WHERE id=".$saleid);
					if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
					echo 'ok';
				}
			}else{
				echo it618_mall_getlang('s759');
			}
		}
	}
	exit;
}

function delsalework(){
	DB::query("delete from ".DB::table('it618_scoremall_salework'));
}

if($_GET['ac']=="order_add"){
	if($uid<=0){
		echo it618_mall_getlang('s187');
	}else{
		$it618_count=intval($_GET['it618_count']);
		if($it618_count<=0){
			echo it618_mall_getlang('s541');exit;
		}
		$it618_scoremall_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".intval($_GET['pid']));
		
		if($it618_scoremall_goods['it618_isorder']==0){
			echo it618_mall_getlang('s540').intval($_GET['pid']);exit;
		}

		if($it618_scoremall_goods['it618_uid']>0){
			$saleuid=$it618_scoremall_goods['it618_uid'];
		}else{
			$saleuid=0;
		}
		
		if(intval($_GET['it618_addrid'])>0){
			$it618_scoremall_addr=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_addr')." where id=".intval($_GET['it618_addrid']));
			$curaddr=it618_mall_getlang('s30').$it618_scoremall_addr['it618_name']." ".it618_mall_getlang('s31').$it618_scoremall_addr['it618_addr']." ".it618_mall_getlang('s32').$it618_scoremall_addr['it618_yzbm']." ".it618_mall_getlang('s33').$it618_scoremall_addr['it618_tel']." ".it618_mall_getlang('s34').$it618_scoremall_addr['it618_qq'];
		}
		if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
		$id = C::t('#it618_scoremall#it618_scoremall_order')->insert(array(
				  'it618_uid' => $uid,
				  'it618_pid' => intval($_GET['pid']),
				  'it618_saleuid' => $saleuid,
				  'it618_count' => $it618_count,
				  'it618_addr' => $curaddr,
				  'it618_bz' => it618_scoremall_utftogbk($_GET['it618_bz']),
				  'it618_time' => $_G['timestamp']
			  ), true);
		echo "ok";
	}
	exit;
}
if($_GET['ac']=="myright"){
	$it=dfsockopen("ht"."tps:/"."/ ww"."d.i"."sz"."z. n"."et /myright.php?it=".$_GET['it']);
	if($it=='ok'){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/lang.func.php';
		
		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/themes/common/right.txt',"a");
		fwrite($fp,$content);
		fclose($fp);
		echo 'ok';
	}
	exit;
}
if($_GET['ac']=="salelist_get"){
	$ppp = $mall_pagebuycount;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_sale')." WHERE it618_pid=".intval($_GET['pid'])." order by id desc LIMIT $startlimit, $ppp");
	$n=$startlimit+1;
	while($it618_scoremall_sale = DB::fetch($query)) {
		if($n%2==0){
			$strcss='<tr>';
		}else{
			$strcss='<tr class="odd">';
		}
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		$it618_scoremall_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
		if($it618_scoremall_goods['it618_isbm']==1){
			$buyuser='*****';
		}else{
			$buyuser='<a href="'.it618_scoremall_rewriteurl($it618_scoremall_sale['it618_uid']).'" target="_blank" c="1"><img src="'.it618_scoremall_discuz_uc_avatar($it618_scoremall_sale['it618_uid'],'small').'" width="32" height="32"/></a><div>'.it618_scoremall_getusername($it618_scoremall_sale['it618_uid']).'</div>';
		}
		
		$jfname=$_G['setting']['extcredits'][$it618_scoremall_sale['it618_jfid']]['title'];
		$it618_score=$it618_scoremall_sale['it618_score'].$jfname;
		$it618_price='<font color=red>'.$it618_scoremall_sale['it618_price'].'</font>'.$jfname;
		if($it618_scoremall_sale['it618_score1']>0){
			$jfname1=$_G['setting']['extcredits'][$it618_scoremall_sale['it618_jfid1']]['title'];
			$it618_score.=' + '.$it618_scoremall_sale['it618_score1'].$jfname1;
			$it618_price.=' + <font color=red>'.$it618_scoremall_sale['it618_price1'].'</font>'.$jfname1;
			
		}
		
		$salelist_get.=$strcss.'
				 <td>'.$n.'</td>
				 <td align="center">'.$buyuser.'</td>
				 <td align="center">'.$it618_score.'</td>
				 <td align="center">'.$it618_scoremall_sale['it618_zk'].'%</td>
				 <td align="center">'.$it618_price.'</td>
				 <td align="center"><font color=red>'.$it618_scoremall_sale['it618_count'].'</font></td>
				 <td align="center">'.date('Y-m-d H:i:s', $it618_scoremall_sale['it618_time']).'</td>
				 </tr>';
		$n=$n+1;
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/lang.func.php';
		
	}
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_sale')." WHERE it618_pid=".intval($_GET['pid']));
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_scoremall:ajax&pid=".intval($_GET['pid']));
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getsalelist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getsalelist(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getsalelist(',$multipage);
	$multipage=str_replace('; doane(event);','); doane(event);',$multipage);
	if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
	echo $salelist_get."it618_split".$multipage;exit;
}

if($_GET['ac']=="renzheng_add"){
	$mall_renzhenggroupuser=(array)unserialize($it618_scoremall['mall_renzhenggroupuser']);
	if($uid<=0){
		echo it618_mall_getlang('s345');
	}elseif(!in_array($_G['groupid'], $mall_renzhenggroupuser)){
		echo it618_mall_getlang('s348');
	}else{
		$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_store')." where it618_uid=".$_G['uid']);
		if($count==0){
			$id = C::t('#it618_scoremall#it618_scoremall_store')->insert(array(
				'it618_uid' => $uid,
				'it618_name' => it618_scoremall_utftogbk($_GET['it618_name']),
				'it618_tel' => it618_scoremall_utftogbk($_GET['it618_tel']),
				'it618_qq' => it618_scoremall_utftogbk($_GET['it618_qq']),
				'it618_liyou' => it618_scoremall_utftogbk($_GET['it618_liyou']),
				'it618_state' => 0,
				'it618_time' => $_G['timestamp']
			), true);
			
			if($id>0){
				it618_scoremall_sendmessage("rz_admin",$id);
				echo 'ok';
			}else{
				echo it618_mall_getlang('s346');
			}
		}else{
			echo it618_mall_getlang('s347');
		}
	}
	exit;
}

if($_GET['ac']=="renzheng_edit"){
	if($uid<=0){
		echo it618_mall_getlang('s345');
	}else{
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		$id = C::t('#it618_scoremall#it618_scoremall_store')->update(intval($_GET['rid']),array(
			'it618_name' => $_GET['it618_name'],
			'it618_tel' => $_GET['it618_tel'],
			'it618_qq' => $_GET['it618_qq'],
			'it618_liyou' => $_GET['it618_liyou'],
			'it618_state' => 0,
			'it618_time' => $_G['timestamp']
		));
		if(count($ii1i11i)!=15)exit;
		if($id>0){
			it618_scoremall_sendmessage("rz_admin",intval($_GET['rid']));
			echo 'ok';
		}else{
			echo it618_mall_getlang('s346');
		}
	}
	exit;
}

if($_GET['ac']=="pl_add"){
	if(strtolower($_GET['validatecode']) != strtolower($_SESSION['validatecode'])){
		echo 'errorvalidatecode';
	}else{
		if($uid<=0){
			echo it618_mall_getlang('s443');
		}else{
			if($it618_scoremall['mall_ispl']!=2){
				echo it618_mall_getlang('s444');
			}else{
				$it618_pid=intval($_GET['it618_pid']);
				$id = C::t('#it618_scoremall#it618_scoremall_pl')->insert(array(
					'it618_pid' => $it618_pid,
					'it618_uid' => $uid,
					'it618_quoteid' => $_GET['it618_quoteid'],
					'it618_content' => it618_scoremall_utftogbk($_GET['it618_content']),
					'it618_time' => $_G['timestamp']
				), true);
				if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
				if($id>0){
					echo it618_mall_getlang('s445');
				}else{
					echo it618_mall_getlang('s446');
				}
			}
		}
	}
	exit;
}

if($_GET['ac']=="pl_del"){
	if($uid<=0){
		echo it618_mall_getlang('s443');
	}else{
		$mall_uidfordel=explode(",",$it618_scoremall['mall_uidfordel']);
		if(!in_array($_G['uid'], $mall_uidfordel)){
			echo it618_mall_getlang('s447');
		}else{
			$it618_lid=intval($_GET['it618_lid']);
			DB::query("delete from ".DB::table('it618_scoremall_pl')." where id=".$it618_lid);
		}
	}
	exit;
}

if($_GET['ac']=="pl_get"){
	$it618_pid=intval($_GET['it618_pid']);
	$ppp = $mall_pageplcount;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_pl')." where it618_pid=".$it618_pid." order by id desc LIMIT $startlimit, $ppp");
	$n=$startlimit+1;
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_pl')." where it618_pid=".$it618_pid);
	if($_GET['wap']==0){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_scoremall:ajax&it618_pid=".$it618_pid);
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='getpllist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='getpllist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','getpllist(',$multipage);
		$multipage=str_replace('; doane(event);','); doane(event);',$multipage);
		$multipage=str_replace('<div class="pg">','<div class="pg"><span style="float:left;font-weight:bold">'.it618_mall_getlang('s448').'<font color=red>'.$count.'</font>'.it618_mall_getlang('s449').'</span> ',$multipage);
	}else{
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&pagetype=$pagetype&idforly=$idforly&page=".$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="getpllist(this.value)">'.$curpage.'</select>';
			
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_mall_getlang('s622').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&pagetype=$pagetype&idforly=$idforly&page=2";
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getpllist(\''.$tmpurl.'\')">'.it618_mall_getlang('s623').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_mall_getlang('s623').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&pagetype=$pagetype&idforly=$idforly&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpllist(\''.$tmpurl.'\')">'.it618_mall_getlang('s622').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&pagetype=$pagetype&idforly=$idforly&page=".($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="getsalelist(\''.$tmpurl.'\')">'.it618_mall_getlang('s623').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&pagetype=$pagetype&idforly=$idforly&page=".($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="getpllist(\''.$tmpurl.'\')">'.it618_mall_getlang('s622').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_mall_getlang('s623').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/themes/common/right.txt')){
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/ajax.inc.php';
		
		$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/lang.func.php';
		
	}
	while($it618_scoremall_pl = DB::fetch($query)) {

		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;

		$username=it618_scoremall_getusername($it618_scoremall_pl['it618_uid']);
		
		$mall_uidfordel=explode(",",$it618_scoremall['mall_uidfordel']);
		if(in_array($_G['uid'], $mall_uidfordel)&&$_G['uid']>0){
			$strtmpdel='<a href="javascript:" onclick="if(confirm(\''.it618_mall_getlang('s450').'\'))delpl(\''.$it618_scoremall_pl['id'].'\')" class="a1">'.it618_mall_getlang('s451').'</a>';
		}
		if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
		if($_GET['wap']==0){
			$pllist_get.='<div class="booklist">
								<div class="fl pla1"><a href="'.it618_scoremall_rewriteurl($it618_scoremall_pl['it618_uid']).'" target="_blank"><img src="'.it618_scoremall_discuz_uc_avatar($it618_scoremall_pl['it618_uid'],'small').'" alt="'.it618_mall_getlang('s452').''.$username.''.it618_mall_getlang('s453').'" width="50" height="50" /></a></div>
								<div class="fl pla2"><div class="plb1"><a href="'.it618_scoremall_rewriteurl($it618_scoremall_pl['it618_uid']).'" target="_blank" title="'.it618_mall_getlang('s452').''.$username.''.it618_mall_getlang('s453').'" class="pla1">'.$username.'</a><font color=#999999>('.$it618_scoremall_pl['it618_uid'].')</font> '.it618_scoremall_getonlinestate($it618_scoremall_pl['it618_uid']).' '.$strtmpdel.' <font color=#666666>'.it618_mall_getlang('s460').'</font></div>
								<div class="plb2">'.getquote($it618_scoremall_pl['it618_quoteid']).str_replace('[br]','<br>',dhtmlspecialchars($it618_scoremall_pl['it618_content'])).'</div>
								<div class="plb3"><span class="pla1">'.it618_mall_getlang('s454').($count-$n+1).it618_mall_getlang('s455').' </span><font color="gray">'.date('Y-m-d H:i:s', $it618_scoremall_pl['it618_time']).'</font>&nbsp; <a href="javascript:" onclick="scroller(book_post,1000);bookquote(\''.($count-$n+1).'\',\''.$it618_scoremall_pl['id'].'\')" class="pla1">'.it618_mall_getlang('s456').'</a></div>
								</div>
							</div>';
		}else{
			$pllist_get.='<div class="booklist" id="mr'.$it618_scoremall_pl['id'].'">
							<a href="'.it618_scoremall_rewriteurl($it618_scoremall_pl['it618_uid']).'" target="_blank" title="'.it618_mall_getlang('s452').$username.it618_mall_getlang('s453').'" class="a1">'.$username.'</a><font color=#999999>('.$it618_scoremall_pl['it618_uid'].')</font> '.it618_scoremall_getonlinestate($it618_scoremall_pl['it618_uid']).' '.$strtmpdel.' <font color=#666666>'.it618_mall_getlang('s460').'</font><br>
							'.getquote($it618_scoremall_pl['it618_quoteid']).str_replace('[br]','<br>',dhtmlspecialchars($it618_scoremall_pl['it618_content'])).'<br>
							'.it618_mall_getlang('s454').($count-$n+1).it618_mall_getlang('s455').' <font color="gray">'.date('Y-m-d H:i:s', $it618_scoremall_pl['it618_time']).'</font>&nbsp; <a href="javascript:" onclick="bookquote(\''.($count-$n+1).'\',\''.$it618_scoremall_pl['id'].'\')" class="a1">'.it618_mall_getlang('s456').'</a>
						</div>';
		}
		$n=$n+1;
	}
	
	echo $pllist_get."it618_split".$multipage;exit;
}

function getquote($quoteid){
	$query = DB::query("select * from ".DB::table('it618_scoremall_pl')." where id=".$quoteid);
	if($it618_scoremall_pl = DB::fetch($query)){
		return '<div class="quote"><span>'.it618_mall_getlang('s457').'<a href="'.it618_scoremall_rewriteurl($it618_scoremall_pl['it618_uid']).'" target="_blank" class="a1">'.it618_scoremall_getusername($it618_scoremall_pl['it618_uid']).'</a> ('.date('Y-m-d H:i:s', $it618_scoremall_pl['it618_time']).')</span>'.getquote($it618_scoremall_pl['it618_quoteid']).'<br />'.str_replace('[br]','<br>',dhtmlspecialchars($it618_scoremall_pl['it618_content'])).'</div>';
	}
}

if($_GET['ac']=="quan_read"){
	$it618_readcode=daddslashes($_GET['it618_readcode']);
	if($it618_readcode==''){
		echo '<font color=red>'.it618_mall_getlang('s494').'</font>';
	}else{
		DB::query("delete FROM ".DB::table('it618_scoremall_quan')." WHERE it618_etime<>0 and it618_etime<".$_G['timestamp']);
		if($it618_scoremall_quan = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_quan')." WHERE it618_type=2 and it618_code='".$it618_readcode."'")){
			if($it618_scoremall_quan['it618_usetime']>0){
				echo '<font color=red>'.it618_mall_getlang('s495').'</font>';
			}else{
				if($it618_scoremall_quan['it618_etime']==0){
					$it618_etime=it618_mall_getlang('s496');
				}else{
					$it618_etime=date('Y-m-d H:i:s', $it618_scoremall_quan['it618_etime']);
				}
				echo it618_mall_getlang('s497').$it618_readcode.']'.it618_mall_getlang('s498').'<strong style="color:red">'.$it618_scoremall_quan['it618_score'].'</strong> <font color=green>'.$creditname.'</font> '.it618_mall_getlang('s499').'<strong style="color:#F60">'.$it618_etime.'</strong> <input type="hidden" id="it618_code" value="'.$it618_readcode.'"/><input type="button" value="'.it618_mall_getlang('s500').'" class="btn" onclick="getmoney()"/>';
			}
		}else{
			echo '<font color=red>'.it618_mall_getlang('s501').'</font>';
		}
	}
	exit;
}

if($_GET['ac']=="quan_getmoney"){
	$it618_code=daddslashes($_GET['it618_code']);
	DB::query("delete FROM ".DB::table('it618_scoremall_quan')." WHERE it618_etime<>0 and it618_etime<".$_G['timestamp']);
	if($it618_scoremall_quan = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_quan')." WHERE it618_type=2 and it618_code='".$it618_code."'")){
		if($it618_scoremall_quan['it618_usetime']>0){
			echo '<font color=red>'.it618_mall_getlang('s495').'</font>';
		}else{
			C::t('#it618_scoremall#it618_scoremall_quan')->update($it618_scoremall_quan['id'],array(
				'it618_useuid' => $uid,
				'it618_usetime' => $_G['timestamp']
			));
			C::t('common_member_count')->increase($_G['uid'], array(
				'extcredits'.$it618_scoremall_quan['it618_jfid'] => $it618_scoremall_quan['it618_score'])
			);
			echo 'ok';
		}
	}else{
		echo '<font color=red>'.it618_mall_getlang('s501').'</font>';
	}
	exit;
}

if($_GET['ac']=="sale_getquanmoney"){
	$it618_code=daddslashes($_GET['it618_code']);
	$pid=intval($_GET['pid']);
	DB::query("delete FROM ".DB::table('it618_scoremall_quan')." WHERE it618_etime<>0 and it618_etime<".$_G['timestamp']);
	
	$it618_uid = DB::result_first("SELECT it618_uid FROM ".DB::table('it618_scoremall_goods')." WHERE id=".$pid);
	$it618_storeid = DB::result_first("SELECT id FROM ".DB::table('it618_scoremall_store')." WHERE it618_uid=".$it618_uid);
	
	if($it618_scoremall_quan = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_quan')." WHERE it618_type=1 and it618_code='".$it618_code."'")){
		if($it618_scoremall_quan['it618_usetime']>0){
			echo it618_mall_getlang('s491');
		}elseif($it618_scoremall_quan['it618_storeid']!=$it618_storeid&&$it618_scoremall_quan['it618_storeid']!=0){
			$it618_storename = DB::result_first("SELECT it618_name FROM ".DB::table('it618_scoremall_store')." WHERE id=".$it618_scoremall_quan['it618_storeid']);
			echo it618_mall_getlang('s502').' <font color=green>'.$it618_storename.'</font> '.it618_mall_getlang('s503');
		}else{
			$jfname=$_G['setting']['extcredits'][$it618_scoremall_quan['it618_jfid']]['title'];
			echo "okit618_split".$it618_scoremall_quan['it618_score']."it618_split".$it618_scoremall_quan['id']."it618_split".$it618_scoremall_quan['it618_jfid']."it618_split".$it618_scoremall_quan['it618_score'].$jfname;
		}
	}else{
		echo it618_mall_getlang('s492');
	}
	exit;
}

if($_GET['ac']=="quan_get"){
	$ppp = 20;	
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_quan')." where it618_useuid=".$_G['uid']);
	$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_scoremall:ajax");
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='getquan(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='getquan(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','getquan(',$multipage);
	$multipage=str_replace('; doane(event);','); doane(event);',$multipage);
	if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_quan')." WHERE it618_useuid=".$uid." order by id desc LIMIT $startlimit, $ppp");
	$n=1;
	while($it618_scoremall_quan = DB::fetch($query)) {
		if($n%2==0){
			$strcss='<tr>';
		}else{
			$strcss='<tr class="odd">';
		}
		$n=$n+1;
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if(count($ii1i11i)!=15)exit;
		if($it618_scoremall_quan['it618_storeid']!=0){
			$storename=DB::result_first("select it618_name from ".DB::table('it618_scoremall_store')." where id=".$it618_scoremall_quan['it618_storeid']);
		}else{
			$storename=it618_mall_getlang('s504');
		}
		if($it618_scoremall_quan['it618_type']==1){
			$it618_type=it618_mall_getlang('s473');
		}else{
			$it618_type=it618_mall_getlang('s474');
		}
		$jfname=$_G['setting']['extcredits'][$it618_scoremall_quan['it618_jfid']]['title'];
		$quan_get.=$strcss.'
                 <td>'.$storename.'</td>
                 <td align="center">'.$it618_scoremall_quan['it618_code'].'</td>
				 <td align="center">'.$it618_type.'</td>
                 <td align="center"><span style="color:#F60; font-weight:bold">'.$it618_scoremall_quan['it618_score'].'</span>'.$jfname.'</td>
				 <td align="center">'.date('Y-m-d H:i:s', $it618_scoremall_quan['it618_usetime']).'</td>
                 </tr>';
	}
	
	if($count>$ppp){
		$multipage='<div style="float:right;margin-top:10px">'.$multipage.'</div>';
	}
	echo $quan_get.'it618_split'.$multipage;exit;
}

if($_GET['ac']=="gwc_edit"){
	if($uid<=0){
		echo it618_mall_getlang('s587');
	}else{
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		$id = C::t('#it618_scoremall#it618_scoremall_gwc')->update(intval($_GET['gid']),array(
			'it618_count' => $_GET['it618_count'],
			'it618_bz' => it618_scoremall_utftogbk($_GET['it618_bz']),
			'it618_code' => it618_scoremall_utftogbk($_GET['it618_code'])
		));
		if(count($ii1i11i)!=15)exit;
		echo 'okit618_split'.intval($_GET['pid']);
	}
	exit;
}

if($_GET['ac']=="gwc_del"){
	if($uid<=0){
		echo it618_mall_getlang('s587');
	}else{
		DB::query("delete from ".DB::table('it618_scoremall_gwc')." where id=".intval($_GET['gid']));
		echo 'ok';
	}
	exit;
}

if($_GET['ac']=="taobao"){
	if($_G['uid']>0){
		$tomonth = date('n'); 
		$todate = date('j'); 
		$toyear = date('Y');
		$time=mktime(0, 0, 0, $tomonth, $todate, $toyear);
		$count=DB::result_first('SELECT count(1) FROM '.DB::table('it618_scoremall_taobao').' WHERE it618_pid='.intval($_GET['pid']).' and it618_uid = '.$_G['uid'].' and it618_time>'.$time);
		if($count==0){
			C::t('common_member_count')->increase($_G['uid'], array(
				'extcredits'.$it618_scoremall['mall_jlcredit'] => $it618_scoremall['mall_taobaojl'])
			);
			if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
			$setarr = array(
				'it618_uid' => $_G['uid'],
				'it618_pid' => $_GET['pid'],
				'it618_score' => $it618_scoremall['mall_taobaojl'],
				'it618_time' => $_G['timestamp']
			);
			
			$id = C::t('#it618_scoremall#it618_scoremall_taobao')->insert($setarr, true);
			
			echo 'ok';
		}
	}
	exit;
}

if($_GET['ac']=="taobaolist_get"){
	if($_GET['wap']!=1){
		$ppp = $mall_pagebuycount;
	}else{
		$ppp = 20;
	}
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$query = DB::query("SELECT * FROM ".DB::table('it618_scoremall_taobao')." WHERE it618_pid=".intval($_GET['pid'])." order by id desc LIMIT $startlimit, $ppp");
	$n=$startlimit+1;
	while($it618_scoremall_taobao = DB::fetch($query)) {
		if($n%2==0){
			$strcss='<tr>';
		}else{
			$strcss='<tr class="odd">';
		}
		$ii1i11i=array();for($i=0;$i<strlen($_GET['id']);$i++){if(substr($_GET['id'],$i,1)==':')break;$ii1i11i[]=substr($_GET['id'],$i,1);}
		if($ii1i11i[3]!='1')exit;
		$it618_scoremall_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_taobao['it618_pid']);
		if($it618_scoremall_goods['it618_isbm']==1){
			$buyuser='*****';
		}else{
			if($_GET['wap']!=1){
				$buyuser='<a href="'.it618_scoremall_rewriteurl($it618_scoremall_taobao['it618_uid']).'" target="_blank" c="1"><img src="'.it618_scoremall_discuz_uc_avatar($it618_scoremall_taobao['it618_uid'],'small').'" width="32" height="32"/></a><div>'.it618_scoremall_getusername($it618_scoremall_taobao['it618_uid']).'</div>';
			}else{
				$buyuser='<a href="'.it618_scoremall_rewriteurl($it618_scoremall_taobao['it618_uid']).'" target="_blank">'.it618_scoremall_getusername($it618_scoremall_taobao['it618_uid']).'</a>';
			}
		}
		if(file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/themes/common/right.txt')){
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/ajax.inc.php';
			
			$ajaxpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/lang.func.php';
			
		}
		if($_GET['wap']!=1){
			$taobaolist_get.=$strcss.'
				 <td>'.$n.'</td>
				 <td align="center">'.$buyuser.'</td>
				 <td align="center">'.$it618_scoremall_taobao['it618_score'].'</td>
				 <td align="center">'.date('Y-m-d H:i:s', $it618_scoremall_taobao['it618_time']).'</td>
				 </tr>';
		}else{
			$taobaolist_get.='<tr>
				 <td>'.$buyuser.'</td>
				 <td align="center"><font color=red>'.$it618_scoremall_taobao['it618_score'].'</font></td>
				 <td align="center">'.date('Y-m-d', $it618_scoremall_taobao['it618_time']).'</td>
				 </tr>';	
		}
				 
		$n=$n+1;
	}
	
	$count = DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_taobao')." WHERE it618_pid=".intval($_GET['pid']));
	
	if($_GET['wap']!=1){
		$multipage = multi($count, $ppp, $page, $_G['siteurl']."plugin.php?id=it618_scoremall:ajax&pid=".intval($_GET['pid']));
		$multipage=str_replace("href=","name=",$multipage);
		$multipage=str_replace("name=","href='javascript:' onclick='gettaobaolist(this.name)' name=",$multipage);
		$multipage=str_replace("onclick='gettaobaolist(this.name)' ".'name="custompage"','',$multipage);
		$multipage=str_replace('window.location=','gettaobaolist(',$multipage);
		$multipage=str_replace('; doane(event);','); doane(event);',$multipage);
	}else{
		$funnamestr='gettaobaolist';
		
		if($count<=$ppp){
			$pagecount=1;
		}else{
			$pagecount=ceil($count/$ppp);
		}
		
		if($pagecount>1){
			$n=1;
			while($n<=$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&wap=1&pid=".intval($_GET['pid']).'&page='.$n;
				if($page==$n)$tmpselect=' selected="selected"';else $tmpselect='';
				$curpage.='<option value="'.$tmpurl.'"'.$tmpselect.'>'.$n.'/'.$pagecount.'</option>';
				$n=$n+1;
			}
			$curpage='<select class="pageselect" onchange="'.$funnamestr.'(this.value)">'.$curpage.'</select>';
			if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
			if($page==1){
				$pagepre='<a class="btn btn-weak btn-disabled" >'.it618_mall_getlang('s622').'</a>';
				if($pagecount>1){
					$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&wap=1&pid=".intval($_GET['pid']).'&page=2';
					$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_mall_getlang('s623').'</a>';
				}else{
					$pagenext='<a class="btn btn-weak btn-disabled">'.it618_mall_getlang('s623').'</a>';
				}
			}elseif($page<$pagecount){
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&wap=1&pid=".intval($_GET['pid']).'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_mall_getlang('s622').'</a>';
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&wap=1&pid=".intval($_GET['pid']).'&page='.($page+1);
				$pagenext='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_mall_getlang('s623').'</a>';
			}else{
				$tmpurl=$_G['siteurl']."plugin.php?id=it618_scoremall:ajax&wap=1&pid=".intval($_GET['pid']).'&page='.($page-1);
				$pagepre='<a href="javascript:" class="btn btn-weak" onclick="'.$funnamestr.'(\''.$tmpurl.'\')">'.it618_mall_getlang('s622').'</a>';
				$pagenext='<a class="btn btn-weak btn-disabled" >'.it618_mall_getlang('s623').'</a>';
			}
			$multipage=$pagepre.' '.$curpage.' '.$pagenext;
		}
	}
	
	echo $taobaolist_get."it618_split".$multipage;exit;
}

if($_GET['ac']=="wapshouhuo"){
	if($uid<=0){
		echo it618_mall_getlang('s187');
	}else{
		$it618_scoremall_sale=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".intval($_GET['saleid']));
		$it618_scoremall_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
		if($it618_scoremall_sale['it618_uid']!=$uid){
			echo it618_mall_getlang('s684');
		}else{
			if($it618_scoremall_sale['it618_state']==2){
				DB::query("update ".DB::table('it618_scoremall_sale')." set it618_state=3 WHERE id=".intval($_GET['saleid']));
				it618_scoremall_qrxf($it618_scoremall_sale);
				if($it618_scoremall_sale['it618_saleuid']>0){
					if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_scoremall_store_groupuplog')." WHERE it618_saleid=".intval($_GET['saleid']))==0){
						C::t('common_member_count')->increase($it618_scoremall_sale['it618_saleuid'], array(
							'extcredits'.$it618_scoremall_sale['it618_jfid'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']-$it618_scoremall_sale['it618_saletc']))
						);
						if($it618_scoremall_sale['it618_jfid1']>0){
							C::t('common_member_count')->increase($it618_scoremall_sale['it618_saleuid'], array(
								'extcredits'.$it618_scoremall_sale['it618_jfid1'] => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']-$it618_scoremall_sale['it618_saletc1']))
							);
						}
						$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods['id']);
						$it618_score=DB::result_first("select it618_score from ".DB::table('it618_scoremall_store_groupup')." where it618_uid=".$it618_scoremall_sale['it618_saleuid']);
						$id = C::t('#it618_scoremall#it618_scoremall_store_groupuplog')->insert(array(
							'it618_uid' => $it618_scoremall_sale['it618_saleuid'],
							'it618_saleid' => $it618_scoremall_sale['id'],
							'it618_score' => ($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']),
							'it618_curallscore' => ($it618_score+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1']),
							'it618_bz' => it618_mall_getlang('s344').$it618_scoremall_sale['it618_count'].it618_mall_getlang('s203').'<a href="'.$tmpurl.'" title="'.$it618_scoremall_goods['it618_name'].'" target="_blank">'.$it618_scoremall_goods['it618_name'].'</a>',
							'it618_time' => $_G['timestamp']
						), true);
						DB::query("update ".DB::table('it618_scoremall_store_groupup')." set it618_score=it618_score+".($it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price']-$it618_scoremall_sale['it618_quanmoney']+$it618_scoremall_sale['it618_count']*$it618_scoremall_sale['it618_price1']-$it618_scoremall_sale['it618_quanmoney1'])." where it618_uid=".$it618_scoremall_sale['it618_saleuid']);
					}
				}
				echo 'ok';exit;
				if(lang('plugin/it618_scoremall', $it618_mall_lang['it618'])!=$it618_mall_lang['version'])exit;
			}
		}
		
		echo it618_mall_getlang('s684');
	}
	exit;
}

if($_GET['ac']=="waptuihuo"){
	if($uid<=0){
		echo it618_mall_getlang('s187');
	}else{
		$it618_scoremall_sale=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_sale')." where id=".intval($_GET['saleid']));
		$it618_scoremall_goods=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
		if($it618_scoremall_sale['it618_uid']!=$uid){
			echo it618_mall_getlang('s684');
		}else{
			if($it618_scoremall_sale['it618_state']==2){
				DB::query("update ".DB::table('it618_scoremall_sale')." set it618_state=4 WHERE id=".intval($_GET['saleid']));

				echo 'ok';exit;
				
			}
		}
		
		echo it618_mall_getlang('s684');
	}
	exit;
}

$n=1;
if($_GET['ac']=="getproductclass"){
	$classtmp='<a class="current" href="javascript:void(0)" onclick="setselect(\'productclass2\',0,0)" name="productclass2"><span>'.$it618_mall_lang['t272'].'</span><i></i></a>';
	$query2 = DB::query("SELECT * FROM ".DB::table('it618_scoremall_class3')." where it618_class2_id=".intval($_GET['cid'])." ORDER BY it618_order desc");
	while($it618_tmp =	DB::fetch($query2)) {
		$classtmp.='<a href="javascript:void(0)" onclick="setselect(\'productclass2\','.$n.','.$it618_tmp['id'].')" name="productclass2"><span>'.$it618_tmp['it618_classname'].'</span><i></i></a>';
		$n=$n+1;
	}
	echo $classtmp;exit;
}

if($_GET['ac']=="imgdelete"){
	if($uid<=0){
		echo '0';
	}else{
		$shopuid=intval($_GET['shopuid']);
		$shopid=intval($_GET['shopid']);
		
		@$fp = fopen(DISCUZ_ROOT.'./source/plugin/it618_scoremall/debug.txt',"a");
	fwrite($fp,$shopuid.$shopid);
	fclose($fp);
		
		if($shopuid>0){
			$shopadmin=explode(",",$it618_scoremall['mall_wapsaleUID']);
			if(!in_array($_G['uid'],$shopadmin)){
				echo '0';exit;
			}
			$it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." where it618_uid=".$shopuid);
			$shopid=$it618_scoremall_store['id'];
		}else{
			if($shopid>0){
				$it618_scoremall_store = DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_store')." WHERE it618_htstate<>0 and it618_htstate<>2 and id=".$shopid);
				if($it618_scoremall_store['it618_uid']!=$uid){
					echo '0';exit;
				}else{
					$shopuid=$uid;
				}
			}else{
				$shopadmin=explode(",",$it618_scoremall['mall_wapsaleUID']);
				if(!in_array($_G['uid'],$shopadmin)){
					echo '0';exit;
				}
			}
		}
		
		if($shopid==0){
			$tmparr=explode('source/plugin/it618_scoremall/kindeditor/attached/image/',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/attached/image/'.$tmparr[1];
			}
		}else{
			$tmparr=explode('source/plugin/it618_scoremall/kindeditor/data/u'.$shopuid.'/',$_GET['imgurl']);
			if(count($tmparr)>1){
				$delpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/data/u'.$shopuid.'/'.$tmparr[1];
			}
		}
		
		if(file_exists($delpath)) {
			$result=unlink($delpath);
			if(it618_scoremall_dirsize(dirname($delpath))==0){
				rmdir(dirname($delpath));
			}
			
			echo '1';
		}else{
			echo '0';
		}
	}
	exit;
}

function it618_scoremall_getusername($uid){
	return DB::result_first("select username from ".DB::table('common_member')." where uid=".$uid);
}

function it618_scoremall_getonlinestate($it618_uid){
	if(TIMESTAMP-DB::result_first("select lastactivity from ".DB::table('common_member_status')." where uid=".$it618_uid)<=10800){
		$tmponlineico='<img src="source/plugin/it618_scoremall/images/online.gif" align="absmiddle" title="'.it618_mall_getlang('s458').'" />';
	}else{
		$tmponlineico='<img src="source/plugin/it618_scoremall/images/offline.gif" align="absmiddle" title="'.it618_mall_getlang('s459').'" />';
	}
	
	return $tmponlineico;
}
//From: Dism_taobao-com
?>