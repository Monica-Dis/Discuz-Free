<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G,$it618_scoremall;
$it618_scoremall = $_G['cache']['plugin']['it618_scoremall'];

require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/lang.func.php';

function it618_scoremall_qrxf($it618_scoremall_sale){
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
	}
	
	if($union_scoremall_isok==1&&($it618_scoremall_sale['it618_price']>=$union_scoremall_money)){
		require_once DISCUZ_ROOT.'./source/plugin/it618_union/unionsaletc.func.php';
		for($i=1;$i<=8;$i++){
			$salecredit[$i]=0;
			if($i==$it618_scoremall_sale['it618_jfid']){
				$salecredit[$i]=$it618_scoremall_sale['it618_price'];
			}
			if($i==$it618_scoremall_sale['it618_jfid1']){
				$salecredit[$i]=$it618_scoremall_sale['it618_price1'];
			}
		}
		Union_SaleCreditsTC('it618_scoremall',$salecredit,$it618_scoremall_sale['id'],$it618_scoremall_sale['it618_uid']);
	}
}

function it618_scoremall_sendmessage($type,$id,$type1=''){
	global $_G,$it618_scoremall;
	
	$it618_members = $_G['cache']['plugin']['it618_members'];
	if (!file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/config/message.php'))return;
	require DISCUZ_ROOT.'./source/plugin/it618_scoremall/config/message.php';
	
	$urlarr=explode("https://",$_G['siteurl']);
	if(count($urlarr)==1)$httpstr='http://';else $httpstr='https://';
	$url_this = $httpstr.$_SERVER ['HTTP_HOST'].'/';
	
	$tmpurl=it618_scoremall_getrewrite('scoremall_wap','','plugin.php?id=it618_scoremall:wap');
	
	if($it618_isok==1){
		
		if($it618_isok_admin==1){
			if($type=='rz_admin'&&$it618_body_rz_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_rz_admin;
				
				$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_scoremall_store['it618_uid']);
				$it618_scoremall_store=DB::fetch_first("select * from ".DB::table('it618_scoremall_store')." where it618_uid=".$id);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_rz_admin_tplid_wxsms;
				$body_wxsms=$it618_body_rz_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{username}",$username,$tmpvalue);
						$tmpvalue=str_replace("{shopname}",$it618_scoremall_store['it618_name'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_scoremall_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{username}",$username,$Body);
				$Body=str_replace("{shopname}",$it618_scoremall_store['it618_name'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_rz_admin_tplid;
					
					$tmparr=explode("{username}",$ALDYBody);
					if(count($tmparr)>1)$param.='"username":"'.$username.'",';
					
					$tmparr=explode("{shopname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"shopname":"'.it618_scoremall_getsmsstr($it618_scoremall_store['it618_name'],$it618_length).'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
			
			if($type=='sale_admin'&&$it618_body_sale_admin_isok==1){
				$tel=$it618_tel_admin;
				$Body=$it618_body_sale_admin;
				
				$it618_scoremall_sale=DB::fetch_first("select * from ".DB::table('it618_scoremall_sale')." where id=".$id);
				$it618_scoremall_goods=DB::fetch_first("select * from ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
				$tmpurl=it618_scoremall_getrewrite('scoremall_wap','product@'.$it618_scoremall_goods['id'].'@0','plugin.php?id=it618_scoremall:wap&pagetype=product&cid='.$it618_scoremall_goods['id']);
				$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_scoremall_sale['it618_uid']);
				
				$uid=$it618_uid_admin;
				$tplid_wxsms=$it618_body_sale_admin_tplid_wxsms;
				$body_wxsms=$it618_body_sale_admin_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{username}",$username,$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_scoremall_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{pprice}",$it618_scoremall_sale['it618_price'],$tmpvalue);
						$tmpvalue=str_replace("{pcount}",$it618_scoremall_sale['it618_count'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_scoremall_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{username}",$username,$Body);
				$Body=str_replace("{pname}",$it618_scoremall_goods['it618_name'],$Body);
				$Body=str_replace("{pprice}",$it618_scoremall_sale['it618_price'],$Body);
				$Body=str_replace("{pcount}",$it618_scoremall_sale['it618_count'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_admin_tplid;
					
					$tmparr=explode("{username}",$ALDYBody);
					if(count($tmparr)>1)$param.='"username":"'.$username.'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_scoremall_getsmsstr($it618_scoremall_goods['it618_name'],$it618_length).'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$it618_scoremall_sale['it618_price'].'",';
					
					$tmparr=explode("{pcount}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pcount":"'.$it618_scoremall_sale['it618_count'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sale_shop'&&$it618_body_sale_shop_isok==1){
			$it618_scoremall_sale=DB::fetch_first("select * from ".DB::table('it618_scoremall_sale')." where id=".$id);
			$it618_scoremall_store=DB::fetch_first("select * from ".DB::table('it618_scoremall_store')." where it618_uid=".$it618_scoremall_sale['it618_saleuid']);
			
			if($it618_scoremall_store['it618_messageisok']==1){
				$tel=$it618_scoremall_store['it618_messagetel'];
				$Body=$it618_body_sale_shop;
				
				$it618_scoremall_goods=DB::fetch_first("select * from ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
				$tmpurl=it618_scoremall_getrewrite('scoremall_wap','product@'.$it618_scoremall_goods['id'].'@0','plugin.php?id=it618_scoremall:wap&pagetype=product&cid='.$it618_scoremall_goods['id']);
				$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_scoremall_sale['it618_uid']);
				
				$uid=$it618_scoremall_sale['it618_saleuid'];
				$tplid_wxsms=$it618_body_sale_shop_tplid_wxsms;
				$body_wxsms=$it618_body_sale_shop_wxsms;
				if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
					$param_wxsms=array();
					$tmparr=explode("@",$body_wxsms);
					for($i=0;$i<count($tmparr);$i++){
						$tmparr1=explode("|",$tmparr[$i]);
						$tmplabel=$tmparr1[0];
						$tmpvalue=$tmparr1[1];
						
						$tmpvalue=str_replace("{username}",$username,$tmpvalue);
						$tmpvalue=str_replace("{pname}",$it618_scoremall_goods['it618_name'],$tmpvalue);
						$tmpvalue=str_replace("{pprice}",$it618_scoremall_sale['it618_price'],$tmpvalue);
						$tmpvalue=str_replace("{pcount}",$it618_scoremall_sale['it618_count'],$tmpvalue);
						
						$param_wxsms[$tmplabel]=array();
						$param_wxsms[$tmplabel]["value"]=it618_scoremall_gbktoutf($tmpvalue);
						$param_wxsms[$tmplabel]["color"]="#666666";
					}
				}
				
				$ALDYBody=$Body;
				$Body=str_replace("{username}",$username,$Body);
				$Body=str_replace("{pname}",$it618_scoremall_goods['it618_name'],$Body);
				$Body=str_replace("{pprice}",$it618_scoremall_sale['it618_price'],$Body);
				$Body=str_replace("{pcount}",$it618_scoremall_sale['it618_count'],$Body);
				
				if($it618_type!='smsbao'){
					$tplid=$it618_body_sale_shop_tplid;
					
					$tmparr=explode("{username}",$ALDYBody);
					if(count($tmparr)>1)$param.='"username":"'.$username.'",';
					
					$tmparr=explode("{pname}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pname":"'.it618_scoremall_getsmsstr($it618_scoremall_goods['it618_name'],$it618_length).'",';
					
					$tmparr=explode("{pprice}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pprice":"'.$it618_scoremall_sale['it618_price'].'",';
					
					$tmparr=explode("{pcount}",$ALDYBody);
					if(count($tmparr)>1)$param.='"pcount":"'.$it618_scoremall_sale['it618_count'].'",';
					
					if($param!=''){
						$param.='@';
						$param=str_replace(",@","",$param);
					}
				}
			}
		}
		
		if($type=='sale_user'&&$it618_body_sale_user_isok==1){
			$it618_scoremall_sale=DB::fetch_first("select * from ".DB::table('it618_scoremall_sale')." where id=".$id);
			
			$tel=$it618_scoremall_sale['it618_tel'];
			$Body=$it618_body_sale_user;
			
			$it618_scoremall_goods=DB::fetch_first("select * from ".DB::table('it618_scoremall_goods')." where id=".$it618_scoremall_sale['it618_pid']);
			$tmpurl=it618_scoremall_getrewrite('scoremall_wap','product@'.$it618_scoremall_goods['id'].'@0','plugin.php?id=it618_scoremall:wap&pagetype=product&cid='.$it618_scoremall_goods['id']);
			$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_scoremall_sale['it618_uid']);
			
			$uid=$it618_scoremall_sale['it618_uid'];
			$tplid_wxsms=$it618_body_sale_user_tplid_wxsms;
			$body_wxsms=$it618_body_sale_user_wxsms;
			if($tplid_wxsms!=''&&$it618_members['members_iswxsms']==1){
				$param_wxsms=array();
				$tmparr=explode("@",$body_wxsms);
				for($i=0;$i<count($tmparr);$i++){
					$tmparr1=explode("|",$tmparr[$i]);
					$tmplabel=$tmparr1[0];
					$tmpvalue=$tmparr1[1];
					
					$tmpvalue=str_replace("{username}",$username,$tmpvalue);
					$tmpvalue=str_replace("{pname}",$it618_scoremall_goods['it618_name'],$tmpvalue);
					$tmpvalue=str_replace("{pprice}",$it618_scoremall_sale['it618_price'],$tmpvalue);
					$tmpvalue=str_replace("{pcount}",$it618_scoremall_sale['it618_count'],$tmpvalue);
					$tmpvalue=str_replace("{code}",$it618_scoremall_sale['it618_code'],$tmpvalue);
					
					$param_wxsms[$tmplabel]=array();
					$param_wxsms[$tmplabel]["value"]=it618_scoremall_gbktoutf($tmpvalue);
					$param_wxsms[$tmplabel]["color"]="#666666";
				}
			}
			
			$ALDYBody=$Body;
			$Body=str_replace("{username}",$username,$Body);
			$Body=str_replace("{pname}",$it618_scoremall_goods['it618_name'],$Body);
			$Body=str_replace("{pprice}",$it618_scoremall_sale['it618_price'],$Body);
			$Body=str_replace("{pcount}",$it618_scoremall_sale['it618_count'],$Body);
			$Body=str_replace("{code}",$it618_scoremall_sale['it618_code'],$Body);
			
			if($it618_type!='smsbao'){
				$tplid=$it618_body_sale_user_tplid;
				
				$tmparr=explode("{username}",$ALDYBody);
				if(count($tmparr)>1)$param.='"username":"'.$username.'",';
				
				$tmparr=explode("{pname}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pname":"'.it618_scoremall_getsmsstr($it618_scoremall_goods['it618_name'],$it618_length).'",';
				
				$tmparr=explode("{pprice}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pprice":"'.$it618_scoremall_sale['it618_price'].'",';
				
				$tmparr=explode("{pcount}",$ALDYBody);
				if(count($tmparr)>1)$param.='"pcount":"'.$it618_scoremall_sale['it618_count'].'",';
				
				$tmparr=explode("{code}",$ALDYBody);
				if(count($tmparr)>1)$param.='"code":"'.$it618_scoremall_sale['it618_code'].'",';
				
				if($param!=''){
					$param.='@';
					$param=str_replace(",@","",$param);
				}
			}
		}
		
		if($Body!=''||(count($param_wxsms)>0&&$uid!='')){
			require_once DISCUZ_ROOT.'./source/plugin/it618_scoremall/message.func.php';
			
			if(count($param_wxsms)>0&&$uid!=''){
				$tmparr=explode(",",$uid);
				for($i=0;$i<count($tmparr);$i++){
					$wxsms=sendSMS_WX($tmparr[$i],$url_this.$tmpurl,$tplid_wxsms,$param_wxsms);
				}
			}
			
			if($Body!=''&&$wxsms!='true'){
				$Body=str_replace('$','',$Body);
	
				if($it618_smsbaosign!='')$it618_smsbaosign=it618_scoremall_getlang('s879').$it618_smsbaosign.it618_scoremall_getlang('s880');
				if($it618_type=='smsbao'){
					sendSMS($it618_tel,$it618_password,$tel,$it618_smsbaosign.$Body);
				}else{
					sendSMS_ALi($tel,$Body,$it618_sign,$tplid,$param,$it618_type);
				}
			}
		}
	}
}

function it618_scoremall_getsmsstr($strtmp,$length){
	if($length>0){
		$tmpstr = "";
		$strlen = $length;
		for($i = 0; $i < $strlen; $i++){
			if(ord(substr($strtmp, $i, 1)) > 0xa0) {
				if(CHARSET=='gbk'){
					$tmpstr .= substr($strtmp, $i, 2);
					$i++;
				}else{
					$tmpstr.=substr($str,$i,3);
					$i+=2;
				}
			} else {
				$tmpstr .= substr($strtmp, $i, 1);
			}
			
		}
		return $tmpstr; 
	}
	return $strtmp;
}

function it618_scoremall_get_contents($str){
	return dfsockopen($str);
}

function it618_scoremall_getmode($modetype,$modecode,$modepids,$modecount){
	global $_G,$it618_scoremall;
	
	
	$tmparr=explode("[loop]",$modecode);
	$tmparr1=explode("[/loop]",$tmparr[1]);

	if($modetype=='product_diy'){
		$tmppidsarr=explode(',',$modepids);
		for($i=0;$i<count($tmppidsarr);$i++){
			$pid=intval($tmppidsarr[$i]);
			if($pid>0){
				if(DB::result_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 and id=".$pid)>0)
				$tmpdata[]=DB::fetch_first("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 and id=".$pid);
			}
		}
	}else{
		if($modetype=='product_new')$sql='ORDER BY id desc limit 0,'.$modecount;
		if($modetype=='product_tj')$sql='and it618_istj=1 ORDER BY id desc limit 0,'.$modecount;
		if($modetype=='product_hot')$sql='ORDER BY it618_salecount desc limit 0,'.$modecount;
	
		$tmpdata=DB::fetch_all("SELECT * FROM ".DB::table('it618_scoremall_goods')." WHERE it618_ison=1 and it618_state=2 and it618_htstate=1 $sql");
	}
	
	$n=1;
	foreach($tmpdata as $it618_scoremall_goods_tmp) {
		
		$plcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_pl')." WHERE it618_pid=".$it618_scoremall_goods_tmp['id']);
		$kmcount=DB::result_first("select count(1) from ".DB::table('it618_scoremall_goods_km')." WHERE it618_pid=".$it618_scoremall_goods_tmp['id']);
		if($kmcount>0)
		{
			$it618_count=$kmcount;
		}else{
			$it618_count=$it618_scoremall_goods_tmp['it618_count'];
		}
		
		if($it618_scoremall_goods_tmp['it618_uid']==0)$it618_scoremall_goods_tmp['it618_uid']=1;
		
		$username=DB::result_first("select username from ".DB::table('common_member')." where uid=".$it618_scoremall_goods_tmp['it618_uid']);
		$postuser='<a href="'.it618_scoremall_rewriteurl($it618_scoremall_goods_tmp['it618_uid']).'" target="_blank">'.$username.'</a>';
		
		$srcarr=explode("source/",it618_scoremall_getwapppic($it618_scoremall_goods_tmp['it618_uid'],$it618_scoremall_goods_tmp['id'],$it618_scoremall_goods_tmp['it618_picbig']));
		$it618_picsmall="source/".$srcarr[1];
		
		$jfname=$_G['setting']['extcredits'][$it618_scoremall_goods_tmp['it618_jfid']]['title'];
		$price='<span class="jfprice">'.$it618_scoremall_goods_tmp['it618_score'].'</span>'.$jfname;
		if($it618_scoremall_goods_tmp['it618_jfid1']>0){
			$jfname1=$_G['setting']['extcredits'][$it618_scoremall_goods_tmp['it618_jfid1']]['title'];
			$price=$price.'+<span class="jfprice">'.$it618_scoremall_goods_tmp['it618_score'].'</span>'.$jfname1;
		}

		$tmpurl=it618_scoremall_getrewrite('product',$it618_scoremall_goods_tmp['id'],'plugin.php?id=it618_scoremall:scoremall_page&pid='.$it618_scoremall_goods_tmp['id']);
		$tmpstr=str_replace("{index}",$n,$tmparr1[0]);
		$tmpstr=str_replace("{id}",$it618_scoremall_goods_tmp['id'],$tmpstr);
		$tmpstr=str_replace("{name}",$it618_scoremall_goods_tmp['it618_name'],$tmpstr);
		$tmpstr=str_replace("{url}",$tmpurl,$tmpstr);
		$tmpstr=str_replace("{src}",$it618_picsmall,$tmpstr);
		$tmpstr=str_replace("{price}",$price,$tmpstr);
		$tmpstr=str_replace("{count}",$it618_count,$tmpstr);
		$tmpstr=str_replace("{view}",$it618_scoremall_goods_tmp['it618_views'],$tmpstr);
		$tmpstr=str_replace("{plcount}",$plcount,$tmpstr);
		$tmpstr=str_replace("{salecount}",$it618_scoremall_goods_tmp['it618_salecount'],$tmpstr);
		$tmpstr=str_replace("{time}",date('Y-m-d H:i:s', $it618_scoremall_goods_tmp['it618_updatetime']),$tmpstr);
		$tmpstr=str_replace("{date}",date('Y-m-d', $it618_scoremall_goods_tmp['it618_updatetime']),$tmpstr);
		$tmpstr=str_replace("{username}",$username,$tmpstr);
		$tmpstr=str_replace("{username+url}",$postuser,$tmpstr);
		
		//{summary,100,'...'}
		$summarytmp=it618_scoremall_str_substr("{summary,", "}", $tmpstr);
		$summarytmp=explode(",",$summarytmp);
		$it618_message=cutstr(strip_tags($it618_scoremall_goods_tmp['it618_message']),$summarytmp[0],str_replace("'","",$summarytmp[1]));
		
		$tmpstr=str_replace("{summary,".$summarytmp[0].",".$summarytmp[1]."}",$it618_message,$tmpstr);
		
		//{avatar,40,40}
		$avatartmp=it618_scoremall_str_substr("{avatar,", "}", $tmpstr);
		$avatartmp=explode(",",$avatartmp);
		$avatar='<a href="'.it618_scoremall_rewriteurl($it618_scoremall_goods_tmp['it618_uid']).'" target="_blank"><img src="'.it618_scoremall_discuz_uc_avatar($it618_scoremall_goods_tmp['it618_uid'],'small').'" width="'.$avatartmp[0].'" height="'.$avatartmp[1].'" /></a>';
		
		$tmpstr=str_replace("{avatar,".$avatartmp[0].",".$avatartmp[1]."}",$avatar,$tmpstr);
		
		$content.=$tmpstr;
		
		$n=$n+1;
	}
	
	$content=$tmparr[0].$content.$tmparr1[1];
	$content=str_replace("{siteurl}",$_G['siteurl'],$content);
	
	return $content;
}

function it618_getbuyname($langstr){
	global $it618_scoremall;
	$mall_buyname = $it618_scoremall['mall_buyname'];
	return str_replace(it618_mall_getlang('s0'),$mall_buyname,$langstr);
}

function it618_scoremall_str_substr($start, $end, $str)
{
    $temp = explode($start, $str, 2);
    $content = explode($end, $temp[1], 2);
    return $content[0];
} 

function it618_scoremall_rewriteurl($uid){
	global $_G;
	if($_G['cache']['plugin']['it618_scoremall']['rewriteurl']==1){
		return 'space-uid-'.$uid.'.html';
	}else{
		return 'home.php?mod=space&uid='.$uid;
	}
}

function it618_scoremall_discuz_uc_avatar($uid, $size = '', $returnsrc = TRUE) {
	require_once DISCUZ_ROOT.'./config/config_ucenter.php';
	if($uid > 0) {
	   $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	   $uid = abs(intval($uid));
	   if(empty($GLOBALS['avatarmethod'])) {
		return $returnsrc ? UC_API.'/avatar.php?uid='.$uid.'&size='.$size : '<img src="'.UC_API.'/avatar.php?uid='.$uid.'&size='.$size.'" />';
	   } else {
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$file = UC_API.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_'.$size.'.jpg';
		return $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.UC_API.'/images/noavatar_'.$size.'.gif\'" />';
	   }
	} else {
	   $file = $GLOBALS['boardurl'].IMGDIR.'/syspm.gif';
	   return $returnsrc ? $file : '<img src="'.$file.'" />';
	}
}

function it618_scoremall_multipage($pagevalue,$uri=''){
	global $_G;
	if($_G['cache']['plugin']['it618_scoremall']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/config/rewrite.php')){
		return $pagevalue;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_scoremall/config/rewrite.php';

	$tmparr=explode("it618page".$urltype."?page=",$pagevalue);
	$pagevalue='';
	$urltype=$urltype.$uri;
	for($i=0;$i<count($tmparr);$i++){
		
		$tmpstr=$tmparr[$i];
		$tmparr1=explode('" class=',$tmpstr);
		if(count($tmparr1)>1){
			$page=$tmparr1[0];
			$tmpstr=str_replace($page.'" class=',$page.$urltype.'" class=',$tmpstr);
		}
		
		$tmparr1=explode('">',$tmpstr);
		$tmparr2=explode('</a><',$tmparr1[1]);
		if(count($tmparr2)>1){
			$page=$tmparr2[0];
			$tmpstr=str_replace($page.'">'.$page.'</a>',$page.$urltype.'">'.$page.'</a>',$tmpstr);
			
		}
		
		$pagevalue.=$tmpstr;
	}
	
	$pagevalue=str_replace("+this.value","+this.value+'".$urltype."'",$pagevalue);
	
	return $pagevalue;
}

function it618_scoremall_getrewrite($pagetype,$pagevalue,$url){
	global $_G;
	if($_G['cache']['plugin']['it618_scoremall']['rewriteurl']==0||!file_exists(DISCUZ_ROOT.'./source/plugin/it618_scoremall/config/rewrite.php')){
		return $url;
	}
	
	require DISCUZ_ROOT.'./source/plugin/it618_scoremall/config/rewrite.php';
	
	if($pagetype=='scoremall_wap'){//scoremall_wap-{pagetype}-{cid}-{page}.html
		$tmparr=explode("@",$pagevalue);
		$pageurl=$wap.$wap1;
		
		if($pagevalue==''){
			$pageurl=str_replace("-{pagetype}-{cid}-{page}","",$pageurl);
		}else{
			$tmparr=explode("@",$pagevalue);
			$pageurl=str_replace("{pagetype}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{cid}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{page}",$tmparr[2],$pageurl);
		}
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='home'){
		return $home.$urltype;
	}
	
	if($pagetype=='gwc'){
		return $gwc.$urltype;
	}
	
	if($pagetype=='productlist'){//productlist-{action}-{value}-{page}.html
		if($pagevalue!=''){
			$tmparr=explode("@",$pagevalue);
			
			$pageurl=$productlist.$productlist1;
			$pageurl=str_replace("{action}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{value}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{page}",$tmparr[2],$pageurl);
			
			return $pageurl.$uri;
		}else{
			return $productlist.$urltype;
		}
	}
	
	if($pagetype=='product'){//product-{pid}.html
	
		$pageurl=$product.$product1;
		$pageurl=str_replace("{pid}",$pagevalue,$pageurl);
		
		return $pageurl.$uri;
	}
	
	if($pagetype=='uc'){//uc-{cid}-{page}.html
		if($pagevalue!=''){
			$tmparr=explode("@",$pagevalue);
			
			$pageurl=$uc.$uc1;
			$pageurl=str_replace("{cid}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{page}",$tmparr[1],$pageurl);
			
			return $pageurl.$uri;
		}else{
			return $uc.$urltype;
		}
	}
	
	if($pagetype=='store'){//store-{action}-{value}-{cid}-{pid}-{page}-.html
		if($pagevalue!=''){
			$tmparr=explode("@",$pagevalue);
			
			$pageurl=$store.$store1;
			$pageurl=str_replace("{action}",$tmparr[0],$pageurl);
			$pageurl=str_replace("{value}",$tmparr[1],$pageurl);
			$pageurl=str_replace("{cid}",$tmparr[2],$pageurl);
			$pageurl=str_replace("{pid}",$tmparr[3],$pageurl);
			$pageurl=str_replace("{page}",$tmparr[4],$pageurl);
			
			return $pageurl.$uri;
		}else{
			return $store.$urltype;
		}
	}
	
	if($pagetype=='storelist'){//storelist-{page}.html
		if($pagevalue!=''){
			$pageurl=$storelist.$storelist1;
			$pageurl=str_replace("{page}",$pagevalue,$pageurl);
			
			return $pageurl.$uri;
		}else{
			return $storelist.$urltype;
		}
	}
}

function it618_scoremall_utftogbk($strcontent){
	$strcontent=dhtmlspecialchars($strcontent);
	
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}
	
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return it618_scoremall_gbktoutf($strcontent);
	}
}

function it618_scoremall_gbktoutf($strcontent){
	$s1 = iconv('utf-8','gbk',$strcontent);
	$s0 = iconv('gbk','utf-8',$s1);
	if($s0 == $strcontent){
		$tmpstr = $s1;
	}else{
		$tmpstr = $strcontent;
	}

	return iconv('gbk','utf-8', $tmpstr);
}

function it618_scoremall_delfile($dirName){
	it618_scoremall_del_dir($dirName);
}

function it618_scoremall_del_dir($dir,$type=0){
    if(is_dir($dir)){
        foreach(scandir($dir) as $row){
            if($row == '.' || $row == '..'){
                continue;
            }
            $path = $dir .'/'. $row;
            if(filetype($path) == 'dir'){
                it618_scoremall_del_dir($path,$type);
            }else{
                unlink($path);
            }
        }
        if($type==1)rmdir($dir);
    }else{
        return false;
    }
}

function it618_scoremall_dirsize($dir) { 
	@$dh = opendir($dir); 
	$size = 0; 
	while ($file = @readdir($dh)) { 
	if ($file != "." and $file != "..") { 
	$path = $dir."/".$file; 
	if (is_dir($path)) { 
	$size += it618_scoremall_dirsize($path); 
	} elseif (is_file($path)) { 
	$size += filesize($path); 
	} 
	} 
	} 
	@closedir($dh); 
	return $size; 
}

function it618_scoremall_getfileext($filestr){
	$file_ext=strtolower(substr($filestr,strrpos($filestr, '.')+1)); 
	$tmparr=explode("?",$file_ext);
	return $tmparr[0];
}

function it618_scoremall_getgoodspic($shopid,$pid,$it618_picbig,$i=0){
	$file_ext=it618_scoremall_getfileext($it618_picbig);
	
	return 'source/plugin/it618_scoremall/kindeditor/data/u'.$shopid.'/smallimage/goods'.$pid.'_'.$i.'.'.$file_ext.'?'.substr(md5($it618_picbig),0,6);
}

function it618_scoremall_getwapppic($shopid,$pid,$get_it618_picbig,$type=1){
	$file_ext=it618_scoremall_getfileext($get_it618_picbig);
	
	if($shopid=='wapad'){
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/data/smallimage/wapad'.$pid.'.'.$file_ext;
		
		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {
				
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/data/smallimage/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}

			it618_scoremall_imagetosmall($it618_url,$it618_smallurl,$file_ext,660,230,1);
		}
		
		$it618_smallurl='source/plugin/it618_scoremall/kindeditor/data/smallimage/wapad'.$pid.'.'.$file_ext;
	}else{
		$it618_smallurl=DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/data/u'.$shopid.'/smallimage/goods'.$pid.'_0.'.$file_ext;
		
		if($type==1){
			if(!file_exists($it618_smallurl))$flag=1;
		}else{
			$flag=1;
		}
		if($flag==1) {
			
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/data/u'.$shopid.'/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
				
			$smallpath=DISCUZ_ROOT.'./source/plugin/it618_scoremall/kindeditor/data/u'.$shopid.'/smallimage/';
			if(!file_exists($smallpath)) {
				mkdir($smallpath);
			}
		
			$tmparr1=explode("://",$get_it618_picbig);
			if(count($tmparr1)>1){
				$it618_url=$get_it618_picbig;
			}else{
				$tmparr=explode("source",$get_it618_picbig);
				$it618_url=DISCUZ_ROOT.'./source'.$tmparr[1];
			}
			
			it618_scoremall_imagetosmall($it618_url,$it618_smallurl,$file_ext,640,640,1);
		}
		
		$it618_smallurl='source/plugin/it618_scoremall/kindeditor/data/u'.$shopid.'/smallimage/goods'.$pid.'_0.'.$file_ext;
	}
	
	return $it618_smallurl.'?'.substr(md5($get_it618_picbig),0,6);
}

function it618_scoremall_imagetosmall($bigimagepath,$smallimagepath,$file_ext,$width,$height,$type=0){
	//��ΪPHPֻ�ܶ���Դ���в���������Ҫ����Ҫ�������ŵ�ͼƬ���п���������Ϊ�µ���Դ 
	if($file_ext=='jpg'||$file_ext=='jpeg')$src=imagecreatefromjpeg($bigimagepath); 
	if($file_ext=='png')$src=imagecreatefrompng($bigimagepath); 
	if($file_ext=='gif')$src=imagecreatefromgif($bigimagepath); 
	
	//ȡ��ԴͼƬ�Ŀ��Ⱥ͸߶� 
	$size_src=@getimagesize($bigimagepath); 
	$w=$size_src['0']; 
	$h=$size_src['1']; 
	
	//$maxָ�����ų��������Ŀ��ȣ�Ҳ�п����Ǹ߶ȣ�
	
	if($type==0){
		//�������ֵΪ300�������һ���ߵĳ��ȣ��õ����ź��ͼƬ���Ⱥ͸߶� 
		if($w > $h){ 
		   $w=$max;
		   $h=$h*($max/$size_src['0']); 
		}else{ 
		   $h=$max;
		   $w=$w*($max/$size_src['1']); 
		} 
	}else{
		$w=$width;
		$h=$height;
	}
	
	//����һ��$w����$h�ߵ����ͼƬ��Դ 
	$image=imagecreatetruecolor($w, $h); 
	 
	//�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h�� 
	imagecopyresampled($image, $src, 0, 0, 0, 0, $w, $h, $size_src['0'], $size_src['1']); 
	
	if($file_ext=='jpg'||$file_ext=='jpeg')imagejpeg($image,$smallimagepath); 
	if($file_ext=='png')imagepng($image,$smallimagepath); 
	if($file_ext=='gif')imagegif($image,$smallimagepath); 
	@chmod($smallimagepath, 0644);
	
	//������Դ 
	imagedestroy($image); 
}

function scoremall_qrcode($url){
	include DISCUZ_ROOT.'./source/plugin/it618_scoremall/phpqrcode.php';
	
	$qrcodeurl=md5($url);
	$qrcodeurl='source/plugin/it618_scoremall/qrcode/'.$qrcodeurl.'.png';
	if(!file_exists($qrcodeurl)){
		$errorCorrectionLevel = 'L';//�ݴ����� 
		$matrixPointSize = 6;//����ͼƬ��С 
		//���ɶ�ά��ͼƬ 
		QRcode::png($url, $qrcodeurl, $errorCorrectionLevel, $matrixPointSize, 2); 
	}

	return $qrcodeurl;	
}

function scoremall_is_mobile(){ 
	$user_agent = $_SERVER['HTTP_USER_AGENT']; 
	$mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte"); 
	$is_mobile = false; 
	foreach ($mobile_agents as $device) { 
	if (stristr($user_agent, $device)) { 
	$is_mobile = true; 
	break; 
	} 
	} 
	return $is_mobile; 
}
//From: Dism_taobao-com
?>