<?php
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_scoremall_focus`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(5000) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_tip` varchar(1000) NOT NULL,
  `it618_is` int(10) unsigned NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_wapfocus`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_wapfocus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_server`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_server` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(200) NOT NULL,
  `it618_width` int(10) unsigned NOT NULL,
  `it618_height` int(10) unsigned NOT NULL,
  `it618_message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_share`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_share` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(200) NOT NULL,
  `it618_width` int(10) unsigned NOT NULL,
  `it618_height` int(10) unsigned NOT NULL,
  `it618_message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_tips`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_tips` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(200) NOT NULL,
  `it618_message1` mediumtext NOT NULL,
  `it618_message2` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_help`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_help` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_waphomead`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_waphomead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_level`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_level` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_level` int(10) unsigned NOT NULL,
  `it618_score1` int(10) unsigned NOT NULL,
  `it618_score2` int(10) unsigned NOT NULL,
  `it618_zk` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_groupup`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_groupup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_groupuplog`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_groupuplog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_curallscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_bz` varchar(2000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_addr`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_addr` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_name` varchar(100) NOT NULL,
  `it618_addr` varchar(1000) NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_qq` varchar(20) NOT NULL,
  `it618_bz` varchar(2000) NOT NULL,
  `it618_yzbm` varchar(10) NOT NULL,
  `it618_iscur` int(10) unsigned NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_class1`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_class1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_classname` varchar(255) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_homeposition` int(10) unsigned NOT NULL DEFAULT '2',
  `it618_homecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_homeordertype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_homewapcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_class2`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_class2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class1_id` int(10) unsigned NOT NULL,
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_homeposition` int(10) unsigned NOT NULL DEFAULT '2',
  `it618_homecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_homeordertype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_homewapcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_class3`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_class3` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class2_id` int(10) unsigned NOT NULL,
  `it618_classname` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  `it618_homeposition` int(10) unsigned NOT NULL DEFAULT '2',
  `it618_homecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_homeordertype` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_homewapcount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_goods`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_class3_id` int(10) unsigned NOT NULL,
  `it618_name` varchar(1000) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jfid1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_salescore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_count` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xiangoutime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xiangoucount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgtype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_xgtime1` varchar(20) NOT NULL,
  `it618_xgtime2` varchar(20) NOT NULL,
  `it618_salecount` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_picbig` varchar(300) NOT NULL,
  `it618_picbig1` varchar(300) NOT NULL,
  `it618_picbig2` varchar(300) NOT NULL,
  `it618_picbig3` varchar(300) NOT NULL,
  `it618_picbig4` varchar(300) NOT NULL,
  `it618_picsmall` varchar(300) NOT NULL,
  `it618_picico` varchar(800) NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_message_daishen` mediumtext NOT NULL,
  `it618_grouppower` varchar(800) NOT NULL,
  `it618_tc` float(9,2) NOT NULL,
  `it618_jforder` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_store_order` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_views` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_ischeck` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_ison` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_saletype` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istj` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_iszk` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isaddr` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isbm` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isorder` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_istaobao` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_isquan` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_taobaourl` varchar(300) NOT NULL,
  `it618_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_htstate` int(10) unsigned NOT NULL DEFAULT '1',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_goods_km`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_goods_km` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_code` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_goods_salekm`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_goods_salekm` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_code` varchar(1000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_sale`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_kdid` int(10) unsigned NOT NULL,
  `it618_km` mediumtext NOT NULL,
  `it618_code` varchar(32) NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_jfid1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_price` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_price1` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_zk` float(9,2) NOT NULL,
  `it618_quanmoney` int(10) unsigned NOT NULL,
  `it618_quanmoney1` int(10) unsigned NOT NULL,
  `it618_saletc` int(10) unsigned NOT NULL,
  `it618_saletc1` int(10) unsigned NOT NULL,
  `it618_tc` float(9,2) NOT NULL,
  `it618_saleuid` int(10) unsigned NOT NULL,
  `it618_count` int(10) unsigned NOT NULL,
  `it618_addr` varchar(2000) NOT NULL,
  `it618_tel` varchar(20) NOT NULL,
  `it618_kddan` varchar(100) NOT NULL,
  `it618_bz` varchar(8000) NOT NULL,
  `it618_state` int(10) unsigned NOT NULL,
  `it618_statebz` varchar(8000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_order`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_saleuid` int(10) unsigned NOT NULL,
  `it618_count` int(10) unsigned NOT NULL,
  `it618_addr` varchar(2000) NOT NULL,
  `it618_bz` varchar(8000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_store`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_store` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_logo` varchar(200) NOT NULL,
  `it618_name` varchar(200) NOT NULL,
  `it618_tel` varchar(200) NOT NULL,
  `it618_messagetel` varchar(20) NOT NULL,
  `it618_messageisok` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_qq` varchar(200) NOT NULL,
  `it618_liyou` varchar(8000) NOT NULL,
  `it618_width` int(10) unsigned NOT NULL DEFAULT '400',
  `it618_height` int(10) unsigned NOT NULL DEFAULT '300',
  `it618_servertitle` varchar(800) NOT NULL,
  `it618_server` mediumtext NOT NULL,
  `it618_server_daishen` mediumtext NOT NULL,
  `it618_message` mediumtext NOT NULL,
  `it618_message_daishen` mediumtext NOT NULL,
  `it618_pprice` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_pcount` int(10) unsigned NOT NULL DEFAULT '100',
  `it618_ptaobao` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_state` int(10) unsigned NOT NULL,
  `it618_htstate` int(10) unsigned NOT NULL,
  `it618_filespace` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_rztime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_htetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_store_level`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_store_level` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_level` int(10) unsigned NOT NULL,
  `it618_score1` int(10) unsigned NOT NULL,
  `it618_score2` int(10) unsigned NOT NULL,
  `it618_tc` float(9,2) NOT NULL,
  `it618_filesizes` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_store_groupup`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_store_groupup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_store_groupuplog`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_store_groupuplog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_saleid` int(10) unsigned NOT NULL,
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_curallscore` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_bz` varchar(2000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_pl`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_pl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_quoteid` int(10) unsigned NOT NULL,
  `it618_content` varchar(2000) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_kd`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_kd` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(255) NOT NULL,
  `it618_url` varchar(1000) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_quan`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_quan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_storeid` int(10) unsigned NOT NULL,
  `it618_adduid` int(10) unsigned NOT NULL,
  `it618_useuid` int(10) unsigned NOT NULL,
  `it618_code` varchar(32) NOT NULL,
  `it618_bz` varchar(1000) NOT NULL DEFAULT '',
  `it618_type` int(10) unsigned NOT NULL,
  `it618_jfid` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_etime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_usetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_kmpower`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_kmpower` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_salework`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_salework` (
  `it618_iswork` int(10) unsigned NOT NULL
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_diy`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_diy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_name` varchar(100) NOT NULL,
  `it618_type` varchar(50) NOT NULL,
  `it618_pids` varchar(8000) NOT NULL,
  `it618_modecode` mediumtext NOT NULL,
  `it618_catch` mediumtext NOT NULL,
  `it618_count` int(10) unsigned NOT NULL DEFAULT '10',
  `it618_isjs` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_catchtime` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_gwc`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_gwc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_count` int(10) unsigned NOT NULL,
  `it618_bz` varchar(1000) NOT NULL,
  `it618_code` varchar(32) NOT NULL,
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_message`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_storeid` int(10) unsigned NOT NULL,
  `it618_tel` varchar(100) NOT NULL,
  `it618_password` varchar(100) NOT NULL,
  `it618_Body` mediumtext NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_taobao`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_taobao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_uid` int(10) unsigned NOT NULL,
  `it618_pid` int(10) unsigned NOT NULL,
  `it618_score` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_wapstyle`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_wapstyle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_color1` varchar(50) NOT NULL,
  `it618_color2` varchar(50) NOT NULL,
  `it618_isok` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_groupzk`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_groupzk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_groupid` int(10) unsigned NOT NULL,
  `it618_zk` float(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_set`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(50) NOT NULL,
  `setvalue` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_iconav`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_iconav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_target` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_bottomnav`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_bottomnav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(10) NOT NULL,
  `it618_img` varchar(255) NOT NULL,
  `it618_curimg` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_it618_scoremall_gonggao`;
CREATE TABLE IF NOT EXISTS `pre_it618_scoremall_gonggao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `it618_title` varchar(255) NOT NULL,
  `it618_url` varchar(255) NOT NULL,
  `it618_color` varchar(50) NOT NULL,
  `it618_isbold` int(10) unsigned NOT NULL DEFAULT '0',
  `it618_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>