var indexPage = {
    init : function(){
        //幻灯片
        if(IT618_SCOREMALL(".jf_slidebox .slide_img li").length>1){
            ue.marquee({
                hovertarget : ".jf_slidebox",//鼠标hover停止切换的对象
                target : '.jf_slidebox .slide_img',//滚动对象 一般为 ul
                items : '.jf_slidebox .slide_img li', //滚动的详细列表
                gotobtn : ".jf_slidebox .slide_num li",
                delay : 3000,//切换间隔时间
                speed : 600,//切换速度
                visiblenum : 1,
                scrollnull : 1,
                currentclass : "cur",
                autoplay : true,//是否自动播放
                afterSlide : function(){
                    var $targetA = this.current.find("a");
                    var href = $targetA.attr("href"),
                        target = $targetA.attr("target"),
                        title = $targetA.attr("title");
                    if (!target){
                        target = "";
                    } else {
                       target = 'target="' + target + '"';
                    }
                    IT618_SCOREMALL(".jf_slidebox .slide_title").html('<a href="' + href + '" ' + target + '>' + title + '</a>');
                },//每滚动一个完的回调函数
                beforeSlide : function(){
                    var $targetImg = this.current.find('img');
                    var imgSrc = $targetImg.attr('data-src');
                    $targetImg.attr('src',imgSrc);
                },//每滚动一个之前的回调函数
                mode : 1,//1表示竖直方向滚动 0表示水平方向滚动
                direction : 0
            });
        }

        //等级
        var is_hover_level = false;
        IT618_SCOREMALL(".jf_level,.pop_box").hover(function(){
            is_hover_level = true;
            setTimeout(checkLevelHover, 150);
        }, function(){
            is_hover_level = false;
            setTimeout(checkLevelHover, 150);
        })

        function checkLevelHover(){
            if (is_hover_level){
                IT618_SCOREMALL(".pop_box").show();
            } else {
                IT618_SCOREMALL(".pop_box").hide();
            }
        }
		
		IT618_SCOREMALL(".it618_utab .jf_sidetab li").bind("click", function(){
            var index = IT618_SCOREMALL(this).index();
            IT618_SCOREMALL(this).addClass("cur").siblings().removeClass("cur");
            IT618_SCOREMALL(".it618_utab .jf_sidetab_con").hide().eq(index).show();
        })
		
        //特卖 tab
        IT618_SCOREMALL(".it618_saletab .jf_sidetab li").bind("click", function(){
            var index = IT618_SCOREMALL(this).index();
            IT618_SCOREMALL(this).addClass("cur").siblings().removeClass("cur");
            IT618_SCOREMALL(".it618_saletab .jf_sidetab_con").hide().eq(index).show();
        })

        //排行榜
        IT618_SCOREMALL("#jf_rankbox1 .jf_ranktab li").bind("click", function(){
            var index = IT618_SCOREMALL(this).index();
            IT618_SCOREMALL(this).addClass("cur").siblings().removeClass("cur");
            IT618_SCOREMALL("#jf_rankbox1 .jf_rankcon").hide().eq(index).show();
        })
		IT618_SCOREMALL("#jf_rankbox2 .jf_ranktab li").bind("click", function(){
            var index = IT618_SCOREMALL(this).index();
            IT618_SCOREMALL(this).addClass("cur").siblings().removeClass("cur");
            IT618_SCOREMALL("#jf_rankbox2 .jf_rankcon").hide().eq(index).show();
        })

        IT618_SCOREMALL(".jf_ranklist li").mouseover(function(){
            IT618_SCOREMALL(this).addClass("cur").siblings().removeClass("cur");
        })

    }
};
