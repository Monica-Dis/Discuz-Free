<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_it618_union_focus`;

DROP TABLE IF EXISTS `pre_it618_union_wapstyle`;

DROP TABLE IF EXISTS `pre_it618_union_gonggao`;

DROP TABLE IF EXISTS `pre_it618_union_iconav`;

DROP TABLE IF EXISTS `pre_it618_union_userset`;

DROP TABLE IF EXISTS `pre_it618_union_reguser`;

DROP TABLE IF EXISTS `pre_it618_union_jl`;

DROP TABLE IF EXISTS `pre_it618_union_saletc`;

DROP TABLE IF EXISTS `pre_it618_union_quan`;

DROP TABLE IF EXISTS `pre_it618_union_quansale`;

DROP TABLE IF EXISTS `pre_it618_union_tui`;

DROP TABLE IF EXISTS `pre_it618_union_tuijoin`;

DROP TABLE IF EXISTS `pre_it618_union_tuitc`;

DROP TABLE IF EXISTS `pre_it618_union_set`;

DROP TABLE IF EXISTS `pre_it618_union_nav`;

DROP TABLE IF EXISTS `pre_it618_union_sharecode_class`;

DROP TABLE IF EXISTS `pre_it618_union_sharecode_font`;

DROP TABLE IF EXISTS `pre_it618_union_sharecode`;

DROP TABLE IF EXISTS `pre_it618_union_bottomnav`;

DROP TABLE IF EXISTS `pre_it618_union_salework`;

EOF;

runquery($sql);

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>