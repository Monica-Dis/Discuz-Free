<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_header.func.php';

$urlsql='&key='.$_GET['key'];

if(submitcheck('it618submit_del')){
	$del=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		$joincount = C::t('#it618_union#it618_union_tuijoin')->count_by_tid($delid);
		
		if($joincount<=0){
			$it618_union_tui = C::t('#it618_union#it618_union_tui')->fetch_by_id($delid);
			
			$tmpurl=$_G['siteurl'].it618_union_getrewrite('union_wap','tui@'.$it618_union_tui['id'],'plugin.php?id=it618_union:wap&pagetype=tui&cid='.$it618_union_tui['id']);
			$qrcodeurl=md5($tmpurl);
			$qrcodeurl='source/plugin/it618_union/qrcode/'.$qrcodeurl.'.png';
			$tmparr=explode("source",$qrcodeurl);
			$qrcodeurl=DISCUZ_ROOT.'./source'.$tmparr[1];
			
			if(file_exists($qrcodeurl)){
				$result=unlink($qrcodeurl);
			}
			
			$tmparr=explode("source",$it618_union_tui['it618_pic']);
			$tmparr1=explode("://",$it618_union_tui['it618_pic']);
			$it618_pic=DISCUZ_ROOT.'./source'.$tmparr[1];
			
			if(file_exists($it618_pic)&&count($tmparr1)==1){
				$result=unlink($it618_pic);
			}
			
			C::t('#it618_union#it618_union_tui')->delete_by_id($delid);
			$del=$del+1;
		}
	}

	it618_cpmsg(it618_union_getlang('s553').$del, "plugin.php?id=it618_union:sc_tui$adminsid&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_on')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		
		C::t('#it618_union#it618_union_tui')->update($delid,array(
			'it618_ison' => 1
		));

		$ok=$ok+1;
	}

	it618_cpmsg(it618_union_getlang('s554').$ok, "plugin.php?id=it618_union:sc_tui$adminsid&page=$page".$sql, 'succeed');
}

if(submitcheck('it618submit_noton')){
	$ok=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		
		C::t('#it618_union#it618_union_tui')->update($delid,array(
			'it618_ison' => 0
		));

		$ok=$ok+1;
	}

	it618_cpmsg(it618_union_getlang('s555').$ok, "plugin.php?id=it618_union:sc_tui$adminsid&page=$page".$sql, 'succeed');
}

it618_showformheader("plugin.php?id=it618_union:sc_tui$adminsid");
showtableheaders(it618_union_getlang('s509'),'it618_union_sum');
	echo '<tr><td colspan=14>'.it618_union_getlang('s219').' <input name="key" value="'.$_GET['key'].'" class="txt" style="width:200px" /> '.it618_union_getlang('s224').' <select name="state"><option value=0 '.$state0.'>'.it618_union_getlang('s225').'</option><option value=1 '.$state1.'>'.it618_union_getlang('s226').'</option><option value=2 '.$state2.'>'.it618_union_getlang('s227').'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_union_getlang('s231').'" /></td></tr>';
	
	$count = C::t('#it618_union#it618_union_tui')->count_by_shoptype_shopid($ShopType,$ShopId,$it618sql,'',$_GET['key']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_union:sc_tui$adminsid".$urlsql);
	
	echo '<tr><td colspan=15>'.it618_union_getlang('s539').$count.'<span style="float:right;">'.it618_union_getlang('s586').'</span></td></tr>';
	showsubtitle(array('',it618_union_getlang('s532'),it618_union_getlang('s533'),it618_union_getlang('s534'),it618_union_getlang('s535'),it618_union_getlang('s536'),it618_union_getlang('s537')));
	
	$n=1;
	foreach(C::t('#it618_union#it618_union_tui')->fetch_all_by_shoptype_shopid(
		$ShopType,$ShopId,$it618sql,$it618orderby,$_GET['key'],$startlimit,$ppp
	) as $it618_union_tui) {
		
		if($it618_union_tui['it618_ison']==1){
			$it618_ison='<font color=green>'.$it618_union_lang['s226'].'</font>';
		}else{
			$it618_ison='<font color=#999>'.$it618_union_lang['s227'].'</font>';
		}
		
		$count=count(explode(",",$it618_union_tui['it618_pids']));
		$it618_pids='<a href="javascript:" onclick="showgoods(\'tui\','.$it618_union_tui['id'].')">'.$it618_union_lang['s545'].'(<font color=red>'.$count.'</font>)</a>';
		
		$preurl="plugin.php?id=it618_union:sc_tui$adminsid".$urlsql."&page=$page";
		$preurl=str_replace("&","@",$preurl);
		
		$tmpurl=it618_union_getrewrite('union_tui',$it618_union_tui['id'],'plugin.php?id=it618_union:union_tui&tid='.$it618_union_tui['id']);
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			'<input class="checkbox" type="checkbox" id="chk_del'.$n.'" name="delete[]" value="'.$it618_union_tui['id'].'" '.$disabled.'><label for="chk_del'.$n.'">'.$it618_union_tui['id'].'</label>',
			'<div style="width:480px">
			<a style="float:left" href="'.$tmpurl.'" target="_blank"><img src="'.$it618_union_tui['it618_pic'].'" width="38" height="38" style="margin-right:6px" align="absmiddle"/></a>
			<div style="width:410px;float:left;line-height:20px"><a href="plugin.php?id=it618_union:sc_tui_edit'.$adminsid.'&tid='.$it618_union_tui['id'].'&preurl='.$preurl.'" style="float:right">'.$it618_union_lang['s234'].'</a>'.$it618_union_tui['it618_name'].'</div>
			</div>',
			$it618_pids,
			'<font color=red>'.$it618_union_tui['it618_tcbl'].'%</font>',
			$it618_union_tui['it618_etime'],
			$it618_union_tui['it618_joincount'],
			$it618_ison,
		));
				
		$n=$n+1;
	}
	
	echo '<tr><td class="td25"><input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkallDx4b">'.it618_union_getlang('s238').'</label></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type="submit" class="btn" name="it618submit_del" value="'.it618_union_getlang('s548').'" onclick="return confirm(\''.it618_union_getlang('s551').'\')" /> <input type="submit" class="btn" name="it618submit_on" value="'.it618_union_getlang('s549').'"/> <input type="submit" class="btn" name="it618submit_noton" value="'.it618_union_getlang('s550').'"/><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

showtablefooter();

echo '<script type="text/javascript">
		function check_all(obj,id)
		{
			for(var i=1;i<'.$n.';i++)
			{
				document.getElementById(id+""+i).checked = obj.checked;
			}
		}
	  </script>';
	  
require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_showgoods.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_footer.func.php';
?>