<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_union = $_G['cache']['plugin']['it618_union'];
require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';

$shoptype=$_GET['shoptype'];
$pid=intval($_GET['pid']);
$uid=$_G['uid'];

$url_tuitc=it618_union_getrewrite('union_uc','tuitc','plugin.php?id=it618_union:union_uc&pagetype=tuitc');
$url_tui=it618_union_getrewrite('union_uc','tui','plugin.php?id=it618_union:union_uc&pagetype=tui');

$shoptypearray = array('video', 'exam', 'group', 'brand', 'tuan');
$shoptype = !in_array($_GET['shoptype'], $shoptypearray) ? '' : $_GET['shoptype'];

if($shoptype=='video'){
	$tmpgoods = C::t('#it618_video#it618_video_goods')->fetch_by_id($pid);
	$it618_pic=it618_union_getgoodspic_plugin('it618_video',$tmpgoods['it618_shopid'],$tmpgoods['id'],$tmpgoods['it618_picbig']);
	$shoptuiurl=it618_union_getrewrite_plugin('it618_video','video_lecturer',$tmpgoods['it618_shopid'],'plugin.php?id=it618_video:lecturer&lid='.$tmpgoods['it618_shopid'].'&tui','?tui');
}
if($shoptype=='exam'){
	$tmpgoods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($pid);
	$it618_pic=it618_union_getgoodspic_plugin('it618_exam',$tmpgoods['it618_shopid'],$tmpgoods['id'],$tmpgoods['it618_picbig']);
	$shoptuiurl=it618_union_getrewrite_plugin('it618_exam','exam_teacher',$tmpgoods['it618_shopid'],'plugin.php?id=it618_exam:teacher&lid='.$tmpgoods['it618_shopid'].'&tui','?tui');
}
if($shoptype=='group'){
	$tmpgoods = C::t('#it618_group#it618_group_goods')->fetch_by_id($pid);
	$it618_pic=it618_union_getgoodspic_plugin('it618_group',0,$tmpgoods['id'],$tmpgoods['it618_picbig']);
	$shoptuiurl=it618_union_getrewrite('union_tuis','','plugin.php?id=it618_union:union_tuis');
}
if($shoptype=='brand'){
	$tmpgoods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid);
	$it618_pic=it618_union_getgoodspic_plugin('it618_brand',$tmpgoods['it618_shopid'],$tmpgoods['id'],$tmpgoods['it618_picbig']);
	$shoptuiurl=it618_union_getrewrite_plugin('it618_brand','shop_page',$tmpgoods['it618_shopid'].'@1','plugin.php?id=it618_brand:onepage&sid='.$tmpgoods['it618_shopid'].'&oid=1');
}
if($shoptype=='tuan'){
	$tmpgoods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($pid);
	$it618_pic=it618_union_getgoodspic_plugin('it618_tuan',$tmpgoods['it618_shopid'],$tmpgoods['id'],$tmpgoods['it618_picbig']);
	$shoptuiurl=it618_union_getrewrite_plugin('it618_tuan','tuan_shop',$tmpgoods['it618_shopid'],'plugin.php?id=it618_tuan:shop&sid='.$tmpgoods['it618_shopid'].'&tui','?tui');
}

$it618_name=$tmpgoods['it618_name'];

if($uid>0){
	$it618sql='it618_uid='.$uid;

	$n=0;
	$tidsstr=',';
	$jointuiid='1=1';
	foreach(C::t('#it618_union#it618_union_tuijoin')->fetch_all_by_shoptype_shopid(
		$shoptype,$tmpgoods['it618_shopid'],$it618sql,'id desc'
	) as $it618_union_tuijoin) {
		
		$it618_union_tui = C::t('#it618_union#it618_union_tui')->fetch_by_id($it618_union_tuijoin['it618_tid']);
		
		if(strtotime($it618_union_tui['it618_etime'].':00')>$_G['timestamp']){
			$it618_pids=explode(",",$it618_union_tui['it618_pids']);
			if(!in_array($pid, $it618_pids)){
				continue;
			}
		}else{
			continue;
		}
		
		$jointuiid.=' and id!='.$it618_union_tui['id'];
		
		$n=$n+1;

		if($shoptype=='video'){
			$tmpurl=it618_union_getrewrite_plugin('it618_video','video_wap','product@'.$pid,'plugin.php?id=it618_video:wap&pagetype=product&cid='.$pid.'&tuiuid='.$uid.'&e='.$it618_union_tuijoin['it618_code'],'?tuiuid='.$uid.'&e='.$it618_union_tuijoin['it618_code']);
			
			$copyurl='<a href="javascript:" class="copytuiurl'.$n.'" data-clipboard-text="'.$it618_name."\n".$_G['siteurl'].$tmpurl.'" style="float:right">'.$it618_union_lang['s572'].'</a>';
			$codeurl='<a href="javascript:" onclick="getcodeurl('.$it618_union_tuijoin['id'].','.$pid.')" style="float:right;margin-left:10px">'.$it618_union_lang['s695'].'</a>';
			$tidsstr.=$n.',';

		}
		
		if($shoptype=='exam'){
			$tmpurl=it618_union_getrewrite_plugin('it618_exam','exam_wap','product@'.$pid,'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$pid.'&tuiuid='.$uid.'&e='.$it618_union_tuijoin['it618_code'],'?tuiuid='.$uid.'&e='.$it618_union_tuijoin['it618_code']);
			
			$copyurl='<a href="javascript:" class="copytuiurl'.$n.'" data-clipboard-text="'.$it618_name."\n".$_G['siteurl'].$tmpurl.'" style="float:right">'.$it618_union_lang['s572'].'</a>';
			$codeurl='<a href="javascript:" onclick="getcodeurl('.$it618_union_tuijoin['id'].','.$pid.')" style="float:right;margin-left:10px">'.$it618_union_lang['s695'].'</a>';
			$tidsstr.=$n.',';

		}
		
		if($shoptype=='group'){
			$tmpurl=it618_union_getrewrite_plugin('it618_group','group_wap','product@'.$pid,'plugin.php?id=it618_group:wap&pagetype=product&cid1='.$pid.'&tuiuid='.$uid.'&e='.$it618_union_tuijoin['it618_code'],'?tuiuid='.$uid.'&e='.$it618_union_tuijoin['it618_code']);
			
			$copyurl='<a href="javascript:" class="copytuiurl'.$n.'" data-clipboard-text="'.$it618_name."\n".$_G['siteurl'].$tmpurl.'" style="float:right">'.$it618_union_lang['s572'].'</a>';
			$codeurl='<a href="javascript:" onclick="getcodeurl('.$it618_union_tuijoin['id'].','.$pid.')" style="float:right;margin-left:10px">'.$it618_union_lang['s695'].'</a>';
			$tidsstr.=$n.',';

		}
		
		if($shoptype=='brand'){
			$tmpurl=it618_union_getrewrite_plugin('it618_brand','brand_wap','product@'.$tmpgoods['it618_shopid'].'@0@'.$pid.'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$tmpgoods['it618_shopid'].'&cid='.$pid.'&tuiuid='.$uid.'&e='.$it618_union_tuijoin['it618_code'],'?tuiuid='.$uid.'&e='.$it618_union_tuijoin['it618_code']);
			
			$copyurl='<a href="javascript:" class="copytuiurl'.$n.'" data-clipboard-text="'.$it618_name."\n".$_G['siteurl'].$tmpurl.'" style="float:right">'.$it618_union_lang['s572'].'</a>';
			$codeurl='<a href="javascript:" onclick="getcodeurl('.$it618_union_tuijoin['id'].','.$pid.')" style="float:right;margin-left:10px">'.$it618_union_lang['s695'].'</a>';
			$tidsstr.=$n.',';

		}
		
		if($shoptype=='tuan'){
			$tmpurl=it618_union_getrewrite_plugin('it618_tuan','tuan_wap','product@'.$pid,'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$pid.'&tuiuid='.$uid.'&e='.$it618_union_tuijoin['it618_code'],'?tuiuid='.$uid.'&e='.$it618_union_tuijoin['it618_code']);
			
			$copyurl='<a href="javascript:" class="copytuiurl'.$n.'" data-clipboard-text="'.$it618_name."\n".$_G['siteurl'].$tmpurl.'" style="float:right">'.$it618_union_lang['s572'].'</a>';
			$codeurl='<a href="javascript:" onclick="getcodeurl('.$it618_union_tuijoin['id'].','.$pid.')" style="float:right;margin-left:10px">'.$it618_union_lang['s695'].'</a>';
			$tidsstr.=$n.',';

		}
		
		$salestr.='<tr><td width="76">
					<a href="'.$tmpurl.'"><img src="'.$it618_union_tui['it618_pic'].'" height="76" width="76" style="border-radius:3px;margin-right:10px"/></a>
					</td>
					<td>
					<font style="color:#555;font-size:13px">'.$it618_union_tui['it618_name'].'</font>
					<div style="padding-top:26px;font-size:12px">'.$it618_union_lang['s534'].':<font color=red>'.$it618_union_tui['it618_tcbl'].'%</font></div>
					<div style="padding-top:6px;font-size:12px" class="divurlbtn">'.$it618_union_tui['it618_etime'].$codeurl.$copyurl.'</div>
					</td></tr>';
		
	}
	
}

foreach(C::t('#it618_union#it618_union_tui')->fetch_all_by_shoptype_shopid(
		$shoptype,$tmpgoods['it618_shopid'],$jointuiid,'id desc'
	) as $it618_union_tui) {
	
	if(strtotime($it618_union_tui['it618_etime'].':00')>$_G['timestamp']){
		$it618_pids=explode(",",$it618_union_tui['it618_pids']);
		if(!in_array($pid, $it618_pids)){
			continue;
		}
	}else{
		continue;
	}
	
	$n=$n+1;

	$tmpurl=it618_union_getrewrite('union_wap','tui@'.$it618_union_tui['id'],'plugin.php?id=it618_union:wap&pagetype=tui&cid='.$it618_union_tui['id']);
			
	$jionbtn='<a  href="'.$tmpurl.'" style="height:28px; line-height:28px; float:right; padding:0 10px; background-color:#fc6a52; color:#fff; font-size:12px; border-radius:6px; margin-top:-10px" target="_blank">'.$it618_union_lang['s615'].'</a>';
	
	$salestr.='<tr><td width="76">
				<a href="'.$tmpurl.'"><img src="'.$it618_union_tui['it618_pic'].'" height="76" width="76" style="border-radius:3px;margin-right:10px"/></a>
				</td>
				<td>
				<font style="color:#555;font-size:13px">'.$it618_union_tui['it618_name'].'</font>
				<div style="padding-top:26px;font-size:12px">'.$it618_union_lang['s534'].':<font color=red>'.$it618_union_tui['it618_tcbl'].'%</font></div>
				<div style="padding-top:6px;font-size:12px" class="divurlbtn">'.$it618_union_tui['it618_etime'].$jionbtn.'</div>
				</td></tr>';
	
}

$_G['mobiletpl'][2]='/';
include template('it618_union:showgoodstuis');
?>