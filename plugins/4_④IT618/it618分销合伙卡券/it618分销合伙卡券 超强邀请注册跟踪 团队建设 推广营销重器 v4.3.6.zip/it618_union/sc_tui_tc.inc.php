<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_header.func.php';

$urlsql='&finduid='.$_GET['finduid'].'&it618_saletime1='.$_GET['it618_saletime1'].'&it618_saletime2='.$_GET['it618_saletime2'].'&it618_tctime1='.$_GET['it618_tctime1'].'&it618_tctime2='.$_GET['it618_tctime2'].'&it618_state='.$_GET['it618_state'];

$it618sql='1=1';
if($_GET['finduid']>0)$it618sql.=' and it618_uid='.intval($_GET['finduid']);
if($_GET['it618_state']==1){$it618sql.=' and it618_state=0';$state1='selected="selected"';}
if($_GET['it618_state']==2){$it618sql.=' and it618_state=1';$state2='selected="selected"';}
if($_GET['it618_state']==3){$it618sql.=' and it618_state=2';$state3='selected="selected"';}

it618_showformheader("plugin.php?id=it618_union:sc_tui_tc$adminsid".$urlsql);
showtableheaders(it618_union_getlang('s510'),'it618_union_sum');
	echo '<tr><td colspan=14>'.it618_union_getlang('s609').' <input name="finduid" value="'.$_GET['finduid'].'" class="txt" style="width:80px" />'.$it618_union_lang['s598'].' <input id="it618_saletime1" name="it618_saletime1" class="txt" style="width:80px;margin-right:0;" readonly value="'.$_GET['it618_saletime1'].'" /> - <input id="it618_saletime2" name="it618_saletime2" class="txt" style="width:83px;"  readonly value="'.$_GET['it618_saletime2'].'"/>'.$it618_union_lang['s599'].' <input id="it618_tctime1" name="it618_tctime1" class="txt" style="width:80px;margin-right:0;" readonly value="'.$_GET['it618_tctime1'].'" /> - <input id="it618_tctime2" name="it618_tctime2" class="txt" style="width:83px;" readonly value="'.$_GET['it618_tctime2'].'"/>'.$it618_union_lang['s600'].' <select name="it618_state"><option value="0">'.$it618_union_lang['s607'].'</option><option value="1" '.$state1.'>'.$it618_union_lang['s601'].'</option><option value="2" '.$state2.'>'.$it618_union_lang['s602'].'</option><option value="3" '.$state3.'>'.$it618_union_lang['s603'].'</option></select> &nbsp;<input type="submit" class="btn" name="it618sercsubmit" value="'.it618_union_getlang('s231').'" /></td></tr>';
	
	$count = C::t('#it618_union#it618_union_tuitc')->count_by_shoptype_shopid($ShopType,$ShopId,$it618sql,'','',$_GET['it618_saletime1'],$_GET['it618_saletime2'],$_GET['it618_tctime1'],$_GET['it618_tctime2']);
	$multipage = multi($count, $ppp, $page, "plugin.php?id=it618_union:sc_tui_tc$adminsid".$urlsql);
	
	echo '<tr><td colspan=15>'.it618_union_getlang('s606').$count.'<span style="float:right;">'.it618_union_getlang('s610').'</span></td></tr>';
	showsubtitle(array(it618_union_getlang('s605'),it618_union_getlang('s595'),it618_union_getlang('s596'),it618_union_getlang('s597'),it618_union_getlang('s608'),it618_union_getlang('s598'),it618_union_getlang('s599'),it618_union_getlang('s600')));
	
	$n=1;
	foreach(C::t('#it618_union#it618_union_tuitc')->fetch_all_by_shoptype_shopid(
		$ShopType,$ShopId,$it618sql,'id desc','',$_GET['it618_saletime1'],$_GET['it618_saletime2'],$_GET['it618_tctime1'],$_GET['it618_tctime2'],$startlimit,$ppp
	) as $it618_union_tuitc) {
		
		if($it618_union_tuitc['it618_shoptype']=='video'){
			if($it618_video_sale = C::t('#it618_video#it618_video_sale')->fetch_by_id($it618_union_tuitc['it618_saleid'])){
				$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_video',$it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']);
				$goodsname=$it618_video_goods['it618_name'];
				$goodsurl=it618_union_getrewrite_plugin('it618_video','video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
				
				if($it618_video_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_video#it618_video_goods_type')->fetch_it618_name_by_id($it618_video_sale['it618_gtypeid']);
				}else{
					$gtypename=$it618_union_lang['s25'];
				}
				
				$goodcount=$it618_video_sale['it618_count'];
				
				$tmpmoney=it618_union_getsaletcmoney_plugin('it618_video',$it618_video_sale,$it618_union_tuitc['it618_tcbl']);
				
				$salemoneystr=$tmpmoney[0];
				$tcmoneystr='<font color=red>'.$tmpmoney[1].'</font>';
			}else{
				continue;
			}
		}
		
		if($it618_union_tuitc['it618_shoptype']=='exam'){
			if($it618_exam_sale = C::t('#it618_exam#it618_exam_sale')->fetch_by_id($it618_union_tuitc['it618_saleid'])){
				$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_exam',$it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']);
				$goodsname=$it618_exam_goods['it618_name'];
				$goodsurl=it618_union_getrewrite_plugin('it618_exam','exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
				
				if($it618_exam_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_exam#it618_exam_goods_type')->fetch_it618_name_by_id($it618_exam_sale['it618_gtypeid']);
				}else{
					$gtypename=$it618_union_lang['s25'];
				}
				
				$goodcount=$it618_exam_sale['it618_count'];
				
				$tmpmoney=it618_union_getsaletcmoney_plugin('it618_exam',$it618_exam_sale,$it618_union_tuitc['it618_tcbl']);
				
				$salemoneystr=$tmpmoney[0];
				$tcmoneystr='<font color=red>'.$tmpmoney[1].'</font>';
			}else{
				continue;
			}
		}
		
		if($it618_union_tuitc['it618_shoptype']=='group'){
			if($it618_group_sale = C::t('#it618_group#it618_group_sale')->fetch_by_id($it618_union_tuitc['it618_saleid'])){
				$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_sale['it618_pid']);
				$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
				$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
				$it618_unit=it618_union_getvipgoodsunit($it618_group_goods);
	
				//$goodspic=it618_union_getgoodspic_plugin('it618_group',0,$it618_group_goods['id'],$it618_group_goods['it618_picbig']);
				$goodspic=$it618_group_group['it618_ico'];
				$goodsname=$grouptitle.' '.$it618_unit;
				$goodsurl=it618_union_getrewrite_plugin('it618_group','group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id']);
				
				$goodcount=$it618_group_sale['it618_count'];
				
				$tmpmoney=it618_union_getsaletcmoney_plugin('it618_group',$it618_group_sale,$it618_union_tuitc['it618_tcbl']);
				
				$salemoneystr=$tmpmoney[0];
				$tcmoneystr='<font color=red>'.$tmpmoney[1].'</font>';
			}else{
				continue;
			}
		}
		
		if($it618_union_tuitc['it618_shoptype']=='brand'){
			if($it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($it618_union_tuitc['it618_saleid'])){
				$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_brand',$it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']);
				$goodsname=$it618_brand_goods['it618_name'];
				$goodsurl=it618_union_getrewrite_plugin('it618_brand','shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id']);
				
				if($it618_brand_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
				}
				
				$goodcount=$it618_brand_sale['it618_count'];
				
				$tmpmoney=it618_union_getsaletcmoney_plugin('it618_brand',$it618_brand_sale,$it618_union_tuitc['it618_tcbl']);
				
				$salemoneystr=$tmpmoney[0];
				$tcmoneystr='<font color=red>'.$tmpmoney[1].'</font>';
			}else{
				continue;
			}
		}
		
		if($it618_union_tuitc['it618_shoptype']=='tuan'){
			if($it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($it618_union_tuitc['it618_saleid'])){
				$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_tuan',$it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']);
				$goodsname=$it618_tuan_goods['it618_name'];
				$goodsurl=it618_union_getrewrite_plugin('it618_tuan','tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
				
				if($it618_tuan_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
				}
				
				$goodcount=$it618_tuan_sale['it618_count'];
				
				$tmpmoney=it618_union_getsaletcmoney_plugin('it618_tuan',$it618_tuan_sale,$it618_union_tuitc['it618_tcbl']);
				
				$salemoneystr=$tmpmoney[0];
				$tcmoneystr='<font color=red>'.$tmpmoney[1].'</font>';
			}else{
				continue;
			}
		}
		
		$it618_tctime='';
		if($it618_union_tuitc['it618_state']==0){
			$it618_state='<font color=red>'.$it618_union_lang['s601'].'</font>';
		}
		if($it618_union_tuitc['it618_state']==1){
			$it618_state='<font color=#999>'.$it618_union_lang['s602'].'</font>';
		}
		if($it618_union_tuitc['it618_state']==2){
			$it618_state='<font color=#390>'.$it618_union_lang['s603'].'</font>';
			$it618_tctime=date('Y-m-d H:i:s', $it618_union_tuitc['it618_tctime']);
		}
		
		if($gtypename!='')$gtypename=$gtypename.'*'.$goodcount;
		
		showtablerow('', array('class="td25"', '', '', '', '', '', '', '', '', '', '', '', ''), array(
			$it618_union_tuitc['id'],
			'<div style="width:360px">
			<a style="float:left" href="'.$goodsurl.'" target="_blank"><img src="'.$goodspic.'" width="38" height="38" style="margin-right:6px" align="absmiddle"/></a>
			<div style="width:310px;float:left;line-height:20px;text-align:left">'.$goodsname.'<br><font color=blue>'.$gtypename.'</font>
			</div></div>',
			$salemoneystr,
			'<font color=#f60>'.$it618_union_tuitc['it618_tcbl'].'%</font><br>'.$tcmoneystr,
			it618_union_getusername($it618_union_tuitc['it618_uid']),
			'<font color=#999>'.date('Y-m-d H:i:s', $it618_union_tuitc['it618_saletime']).'</font>',
			'<font color=#999>'.$it618_tctime.'</font>',
			$it618_state
		));
				
		$n=$n+1;
	}
	
		echo '<tr><td class="td25"></td><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type=hidden value='.$page.' name=page /></div></td></tr>
	<script charset="utf-8" src="source/plugin/it618_union/js/laydate/laydate.js"></script>
	<script>
	laydate.render({
  elem: "#it618_saletime1"
});
laydate.render({
  elem: "#it618_saletime2"
});

laydate.render({
  elem: "#it618_tctime1"
});
laydate.render({
  elem: "#it618_tctime2"
});
	</script>
	';

showtablefooter();

require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_showgoods.func.php';
require_once DISCUZ_ROOT.'./source/plugin/it618_union/sc_footer.func.php';
?>