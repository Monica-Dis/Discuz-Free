<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_union = $_G['cache']['plugin']['it618_union'];
require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';

$jid=intval($_GET['jid']);
$pid=intval($_GET['pid']);

if($it618_union_tuijoin = C::t('#it618_union#it618_union_tuijoin')->fetch_by_id($jid)){
	
	if($it618_union_tuijoin['it618_shoptype']=='video'){
		if($tmpgoods=C::t('#it618_video#it618_video_goods')->fetch_by_id($pid)){
			
			if($_GET['wap']!=1){
				$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_video','video_product',$pid,'plugin.php?id=it618_video:product&pid='.$pid.'&tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code'],'?tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code']);
			}else{
				$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_video','video_wap','product@'.$pid,'plugin.php?id=it618_video:wap&pagetype=product&cid='.$pid.'&tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code'],'?tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code']);
			}
			
			$it618_name=$tmpgoods['it618_name'];
			$it618_description=$tmpgoods['it618_description'];
			$it618_price=it618_union_getgoodsprice_plugin('it618_video',$tmpgoods);
			$share_img=$_G['siteurl'].it618_union_getgoodspic_plugin('it618_video',$tmpgoods['it618_shopid'],$tmpgoods['id'],$tmpgoods['it618_picbig']);
			
			if($IsWxMini==1){
				if($it618_wxmini_app=C::t('#it618_wxmini#it618_wxmini_app')->fetch_by_pluginid('it618_video')){
					$tmpurl=$_G['siteurl'].'plugin.php?id=it618_wxmini:url&aid='.$it618_wxmini_app['id'].'&q='.urlencode($tmpurl);
				}
			}
			$codesrc='plugin.php?id=it618_union:urlcode&url='.urlencode($tmpurl);
			
			$sharecodecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." WHERE id=2 and it618_istui=1 and it618_state=1");
			if($sharecodecount>0){
				$share_img=$_G['siteurl'].'plugin.php?id=it618_union:sharecode&cid=2&class=tui&dataid='.$tmpgoods['id'].'&shareurl='.urlencode($tmpurl);
			}
		}else{
			echo it618_union_getlang('s542');exit;
		}
	}
	
	if($it618_union_tuijoin['it618_shoptype']=='exam'){
		if($tmpgoods=C::t('#it618_exam#it618_exam_goods')->fetch_by_id($pid)){
			if($_GET['wap']!=1){
				$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_exam','exam_product',$pid,'plugin.php?id=it618_exam:product&pid='.$pid.'&tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code'],'?tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code']);
			}else{
				$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_exam','exam_wap','product@'.$pid,'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$pid.'&tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code'],'?tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code']);
			}
			
			$it618_name=$tmpgoods['it618_name'];
			$it618_description=$tmpgoods['it618_description'];
			$it618_price=it618_union_getgoodsprice_plugin('it618_exam',$tmpgoods);
			$share_img=$_G['siteurl'].it618_union_getgoodspic_plugin('it618_exam',$tmpgoods['it618_shopid'],$tmpgoods['id'],$tmpgoods['it618_picbig']);
			
			if($IsWxMini==1){
				if($it618_wxmini_app=C::t('#it618_wxmini#it618_wxmini_app')->fetch_by_pluginid('it618_exam')){
					$tmpurl=$_G['siteurl'].'plugin.php?id=it618_wxmini:url&aid='.$it618_wxmini_app['id'].'&q='.urlencode($tmpurl);
				}
			}
			$codesrc='plugin.php?id=it618_union:urlcode&url='.urlencode($tmpurl);
			
			$sharecodecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." WHERE id=3 and it618_istui=1 and it618_state=1");
			if($sharecodecount>0){
				$share_img=$_G['siteurl'].'plugin.php?id=it618_union:sharecode&cid=3&class=tui&dataid='.$tmpgoods['id'].'&shareurl='.urlencode($tmpurl);
			}
		}else{
			echo it618_union_getlang('s542');exit;
		}
	}
	
	if($it618_union_tuijoin['it618_shoptype']=='group'){
		if($tmpgoods=C::t('#it618_group#it618_group_goods')->fetch_by_id($pid)){
			if($_GET['wap']!=1){
				$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_group','group_product',$pid,'plugin.php?id=it618_group:product&pid='.$pid.'&tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code'],'?tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code']);
			}else{
				$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_group','group_wap','product@'.$pid,'plugin.php?id=it618_group:wap&pagetype=product&cid1='.$pid.'&tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code'],'?tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code']);
			}
			
			$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($tmpgoods['it618_groupid']);
			$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$tmpgoods['it618_groupid']);
			$it618_unit=it618_union_getvipgoodsunit($tmpgoods);
			
			$it618_name=$grouptitle.' '.$it618_unit;
			$it618_description=$tmpgoods['it618_description'];
			$it618_price=it618_union_getgoodsprice_plugin('it618_group',$tmpgoods);
			$share_img=$_G['siteurl'].it618_union_getgoodspic_plugin('it618_group',0,$tmpgoods['id'],$tmpgoods['it618_picbig']);
			
			if($IsWxMini==1){
				if($it618_wxmini_app=C::t('#it618_wxmini#it618_wxmini_app')->fetch_by_pluginid('it618_group')){
					$tmpurl=$_G['siteurl'].'plugin.php?id=it618_wxmini:url&aid='.$it618_wxmini_app['id'].'&q='.urlencode($tmpurl);
				}
			}
			$codesrc='plugin.php?id=it618_union:urlcode&url='.urlencode($tmpurl);
			
			$sharecodecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." WHERE id=8 and it618_istui=1 and it618_state=1");
			if($sharecodecount>0){
				$share_img=$_G['siteurl'].'plugin.php?id=it618_union:sharecode&cid=8&class=tui&dataid='.$tmpgoods['id'].'&shareurl='.urlencode($tmpurl);
			}
		}else{
			echo it618_union_getlang('s542');exit;
		}
	}
	
	if($it618_union_tuijoin['it618_shoptype']=='brand'){
		if($tmpgoods=C::t('#it618_brand#it618_brand_goods')->fetch_by_id($pid)){
			if($_GET['wap']!=1){
				$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_brand','shop_product',$tmpgoods['it618_shopid'].'@'.$pid,'plugin.php?id=it618_brand:product&sid='.$tmpgoods['it618_shopid'].'&pid='.$pid.'&tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code'],'?tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code']);
			}else{
				$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_brand','brand_wap','product@'.$tmpgoods['it618_shopid'].'@0@'.$pid.'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$tmpgoods['it618_shopid'].'&cid='.$pid.'&tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code'],'?tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code']);
			}
			
			$it618_name=$tmpgoods['it618_name'];
			$it618_description=$tmpgoods['it618_seodescription'];
			$it618_price=it618_union_getgoodsprice_plugin('it618_brand',$tmpgoods);
			$share_img=$_G['siteurl'].it618_union_getgoodspic_plugin('it618_brand',$tmpgoods['it618_shopid'],$tmpgoods['id'],$tmpgoods['it618_picbig']);
			
			if($IsWxMini==1){
				if($it618_wxmini_app=C::t('#it618_wxmini#it618_wxmini_app')->fetch_by_pluginid('it618_brand')){
					$tmpurl=$_G['siteurl'].'plugin.php?id=it618_wxmini:url&aid='.$it618_wxmini_app['id'].'&q='.urlencode($tmpurl);
				}
			}
			$codesrc='plugin.php?id=it618_union:urlcode&url='.urlencode($tmpurl);
			
			$sharecodecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." WHERE id=4 and it618_istui=1 and it618_state=1");
			if($sharecodecount>0){
				$share_img=$_G['siteurl'].'plugin.php?id=it618_union:sharecode&cid=4&class=tui&dataid='.$tmpgoods['id'].'&shareurl='.urlencode($tmpurl);
			}
		}else{
			echo it618_union_getlang('s542');exit;
		}
	}
	
	if($it618_union_tuijoin['it618_shoptype']=='tuan'){
		if($tmpgoods=C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($pid)){
			if($_GET['wap']!=1){
				$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_tuan','tuan_product',$pid,'plugin.php?id=it618_tuan:product&pid='.$pid.'&tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code'],'?tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code']);
			}else{
				$tmpurl=$_G['siteurl'].it618_union_getrewrite_plugin('it618_tuan','tuan_wap','product@'.$pid,'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$pid.'&tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code'],'?tuiuid='.$it618_union_tuijoin['it618_uid'].'&e='.$it618_union_tuijoin['it618_code']);
			}
			
			$it618_name=$tmpgoods['it618_name'];
			$it618_description=$tmpgoods['it618_description'];
			$it618_price=it618_union_getgoodsprice_plugin('it618_tuan',$tmpgoods);
			$share_img=$_G['siteurl'].it618_union_getgoodspic_plugin('it618_tuan',$tmpgoods['it618_shopid'],$tmpgoods['id'],$tmpgoods['it618_picbig']);
			
			if($IsWxMini==1){
				if($it618_wxmini_app=C::t('#it618_wxmini#it618_wxmini_app')->fetch_by_pluginid('it618_tuan')){
					$tmpurl=$_G['siteurl'].'plugin.php?id=it618_wxmini:url&aid='.$it618_wxmini_app['id'].'&q='.urlencode($tmpurl);
				}
			}
			$codesrc='plugin.php?id=it618_union:urlcode&url='.urlencode($tmpurl);
			
			$sharecodecount = DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." WHERE id=5 and it618_istui=1 and it618_state=1");
			if($sharecodecount>0){
				$share_img=$_G['siteurl'].'plugin.php?id=it618_union:sharecode&cid=5&class=tui&dataid='.$tmpgoods['id'].'&shareurl='.urlencode($tmpurl);
			}
		}else{
			echo it618_union_getlang('s542');exit;
		}
	}
	
}else{
	echo it618_union_getlang('s542');exit;
}

$_G['mobiletpl'][2]='/';
include template('it618_union:showcode');
?>