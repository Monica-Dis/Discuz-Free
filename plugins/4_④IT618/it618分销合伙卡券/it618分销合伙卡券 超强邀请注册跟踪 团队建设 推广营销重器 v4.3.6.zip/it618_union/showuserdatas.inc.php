<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_union = $_G['cache']['plugin']['it618_union'];
require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';

$uid = intval($_GET['uid']);
$tuiuid = intval($_GET['tuiuid']);

if($tuiuid>0){
	if(!$it618_union_reguser=DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." WHERE it618_tuiuid=".$_G['uid']." and it618_uid=$tuiuid")){
		echo $it618_union_lang['s1004'];exit;
	}else{
		if(!$it618_union_reguser=DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." WHERE it618_tuiuid=".$tuiuid." and it618_uid=$uid")){
			echo $it618_union_lang['s1004'];exit;
		}
	}
}else{
	if(!$it618_union_reguser=DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." WHERE it618_tuiuid=".$_G['uid']." and it618_uid=$uid")){
		echo $it618_union_lang['s1004'];exit;
	}
}

$it618_union_userset=C::t('#it618_union#it618_union_userset')->fetch_by_uid($it618_union_reguser['it618_uid']);

if($it618_union_userset['it618_tel']!=''&&$it618_union_userset['it618_tel_isopen']==1)$usersetstr.=$it618_union_lang['s117'].'<a href="tel://'.$it618_union_userset['it618_tel'].'">'.$it618_union_userset['it618_tel'].'</a> ';
		
if($it618_union_userset['it618_qq']!='')$usersetstr.=$it618_union_lang['s118'].'<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin='.$it618_union_userset['it618_qq'].'&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:'.$it618_union_userset['it618_qq'].':52" align="absmiddle"/></a> ';
if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
if($it618_union_userset['it618_wx']!='')$usersetstr.=$it618_union_lang['s119'].$it618_union_userset['it618_wx'];

echo $usersetstr;
?>