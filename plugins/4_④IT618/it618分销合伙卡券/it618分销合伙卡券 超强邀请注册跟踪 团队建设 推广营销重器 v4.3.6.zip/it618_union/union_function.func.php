<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$pagetype;

$it618_union = $_G['cache']['plugin']['it618_union'];
$metatitle = $it618_union['seotitle'];
$metakeywords = $it618_union['seokeywords'];
$metadescription = $it618_union['seodescription'];

require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';

if(($pagetype=='index'&&$it618_union['union_isquantui']!=1)||$pagetype=='yqreg'){
	if($_G['uid']>0){
		$tuipower=1;
		
		if($it618_union['union_yqpowermode']==1||$it618_union['union_yqpowermode']==3){
			$union_tuigroup=(array)unserialize($it618_union['union_tuigroup']);
			if($union_tuigroup[0]!=''){
				$tmpgrouparr=it618_union_getisvipuser($union_tuigroup);
				if(count($tmpgrouparr[0])==0){
					$tuipower=0;
					$tuipowerabout=$it618_union['union_tuipowerabout2'];
				}
			}
		}
		if($it618_union['union_yqpowermode']==2||$it618_union['union_yqpowermode']==3){
			if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($_G['uid'])==0){
				$tuipower=0;
				$tuipowerabout=$it618_union['union_tuipowerabout3'];
			}
		}
		
		$tuiurl=$_G['siteurl'].it618_union_getrewrite('union_yq',$_G['uid'],'plugin.php?id=it618_union:union&tuiuid='.$_G['uid']);
		
		$tmpurl=$tuiurl;
		if($IsWxMini==1){
			if($it618_wxmini_app=C::t('#it618_wxmini#it618_wxmini_app')->fetch_by_pluginid('it618_union')){
				$tmpurl=$_G['siteurl'].'plugin.php?id=it618_wxmini:url&aid='.$it618_wxmini_app['id'].'&q='.urlencode($tuiurl);
			}
		}
			
		$qrcodesrc=$_G['siteurl'].'plugin.php?id=it618_union:urlcode&url='.urlencode($tmpurl);
	}else{
		$tuipower=0;	
		$tuipowerabout=$it618_union['union_tuipowerabout1'];
	}
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/shareset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_union/config/shareset.php';
	}
	
	$clipboarddata=$share_name."\n".$tuiurl;
	
	$yqjlmoney=explode("@",$it618_union['union_yqjlmoney']);
	if($yqjlmoney[0]>0||$yqjlmoney[1]>0){
		$yqjlmoneystr=$it618_union_lang['s834'];
		if($yqjlmoney[0]>0){
			$it618_union_lang['s835']=str_replace("{money}",$yqjlmoney[0],$it618_union_lang['s835']);
			$yqjlmoneystr.=$it618_union_lang['s835'];
		}
		if($yqjlmoney[1]>0){
			$it618_union_lang['s836']=str_replace("{money}",$yqjlmoney[1],$it618_union_lang['s836']);
			$yqjlmoneystr.=$it618_union_lang['s836'];
		}
	}
	
	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/jlset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_union/config/jlset.php';
	}
	
	$tmpn=0;
	if($jl_group_isok1==1||$jl_tuicount_isok1==1){
		$jlstrtmp='';$jfstr='';$jfstr1='';
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''&&$jl_credit11[$i]>0){
				$jfstr.='<span>'.$jl_credit11[$i].'</span> '.$_G['setting']['extcredits'][$i]['title'].' + ';
			}
			if($_G['setting']['extcredits'][$i]['title']!=''&&$jl_credit12[$i]>0){
				$jfstr1.='<span>'.$jl_credit12[$i].'</span> '.$_G['setting']['extcredits'][$i]['title'].' + ';
			}
		}
		
		$tmpn=$tmpn+1;if($tmpn%2==0)$tmpbg='style="background-color:#f9f9f9"';else $tmpbg='';
		if($jfstr1!='')$tmprow='rowspan=2';else $tmprow='';
		
		if($jl_tuicount_isok1==1&&$jl_tuicount1>0){
			$jlstrtmp=$it618_union_lang['s653'].'<font color=red>'.$jl_tuicount1.'</font><br>';
		}
		
		if($jl_group_isok1==1){
			$grouptitle=DB::result_first("SELECT grouptitle FROM ".DB::table('common_usergroup')." WHERE groupid=".$jl_group1);
			$jlstrtmp.=$it618_union_lang['s654'].'<font color=red>'.$grouptitle.'</font>'.$it618_union_lang['s655'].'<br>';
		}
		
		if($jl_do_isok1==1){
			$jlstrtmp.='<font color=#999>'.$it618_union_lang['s667'].'</font>';
		}else{
			$jlstrtmp.='<font color=#999>'.$it618_union_lang['s668'].'</font>';
		}
		
		$jlstr.='<tr '.$tmpbg.'><td '.$tmprow.' >[G1] '.$jlstrtmp.'</td><td>'.$it618_union_lang['t64'].'</td><td>'.gettmpstr($jfstr).'</td></tr>';
		if($jfstr1!='')$jlstr.='<tr '.$tmpbg.'><td>'.$it618_union_lang['t65'].'</td><td>'.gettmpstr($jfstr1).'</td></tr>';
	}
	
	if($jl_group_isok2==1||$jl_tuicount_isok2==1){
		$jlstrtmp='';$jfstr='';$jfstr1='';
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''&&$jl_credit21[$i]>0){
				$jfstr.='<span>'.$jl_credit21[$i].'</span> '.$_G['setting']['extcredits'][$i]['title'].' + ';
			}
			if($_G['setting']['extcredits'][$i]['title']!=''&&$jl_credit22[$i]>0){
				$jfstr1.='<span>'.$jl_credit22[$i].'</span> '.$_G['setting']['extcredits'][$i]['title'].' + ';
			}
		}
		
		$tmpn=$tmpn+1;if($tmpn%2==0)$tmpbg='style="background-color:#f9f9f9"';else $tmpbg='';
		if($jfstr1!='')$tmprow='rowspan=2';else $tmprow='';
		
		if($jl_tuicount_isok2==1&&$jl_tuicount2>0){
			$jlstrtmp=$it618_union_lang['s653'].'<font color=red>'.$jl_tuicount2.'</font><br>';
		}
		
		if($jl_group_isok2==1){
			$grouptitle=DB::result_first("SELECT grouptitle FROM ".DB::table('common_usergroup')." WHERE groupid=".$jl_group2);
			$jlstrtmp.=$it618_union_lang['s654'].'<font color=red>'.$grouptitle.'</font>'.$it618_union_lang['s655'].'<br>';
		}
		
		if($jl_do_isok2==1){
			$jlstrtmp.='<font color=#999>'.$it618_union_lang['s667'].'</font>';
		}else{
			$jlstrtmp.='<font color=#999>'.$it618_union_lang['s668'].'</font>';
		}
		
		$jlstr.='<tr '.$tmpbg.'><td '.$tmprow.' >[G2] '.$jlstrtmp.'</td><td>'.$it618_union_lang['t64'].'</td><td>'.gettmpstr($jfstr).'</td></tr>';
		if($jfstr1!='')$jlstr.='<tr '.$tmpbg.'><td>'.$it618_union_lang['t65'].'</td><td>'.gettmpstr($jfstr1).'</td></tr>';
	}
	
	if($jl_group_isok3==1||$jl_tuicount_isok3==1){
		$jlstrtmp='';$jfstr='';$jfstr1='';
		
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''&&$jl_credit31[$i]>0){
				$jfstr.='<span>'.$jl_credit31[$i].'</span> '.$_G['setting']['extcredits'][$i]['title'].' + ';
			}
			if($_G['setting']['extcredits'][$i]['title']!=''&&$jl_credit32[$i]>0){
				$jfstr1.='<span>'.$jl_credit32[$i].'</span> '.$_G['setting']['extcredits'][$i]['title'].' + ';
			}
		}
		
		$tmpn=$tmpn+1;if($tmpn%2==0)$tmpbg='style="background-color:#f9f9f9"';else $tmpbg='';
		if($jfstr1!='')$tmprow='rowspan=2';else $tmprow='';
		
		if($jl_tuicount_isok3==1&&$jl_tuicount3>0){
			$jlstrtmp=$it618_union_lang['s653'].'<font color=red>'.$jl_tuicount3.'</font><br>';
		}
		
		if($jl_group_isok3==1){
			$grouptitle=DB::result_first("SELECT grouptitle FROM ".DB::table('common_usergroup')." WHERE groupid=".$jl_group3);
			$jlstrtmp.=$it618_union_lang['s654'].'<font color=red>'.$grouptitle.'</font>'.$it618_union_lang['s655'].'<br>';
		}
		
		if($jl_do_isok3==1){
			$jlstrtmp.='<font color=#999>'.$it618_union_lang['s667'].'</font>';
		}else{
			$jlstrtmp.='<font color=#999>'.$it618_union_lang['s668'].'</font>';
		}
		
		$jlstr.='<tr '.$tmpbg.'><td '.$tmprow.' >[G3] '.$jlstrtmp.'</td><td>'.$it618_union_lang['t64'].'</td><td>'.gettmpstr($jfstr).'</td></tr>';
		if($jfstr1!='')$jlstr.='<tr '.$tmpbg.'><td>'.$it618_union_lang['t65'].'</td><td>'.gettmpstr($jfstr1).'</td></tr>';
	}
	
	if($jlstr!='')$jlstr='<table width="100%" class="salecss"><tr><th width=320>'.$it618_union_lang['t133'].'</th><th width=130>'.$it618_union_lang['t134'].'</th><th>'.$it618_union_lang['t135'].'</th></tr>'.$jlstr.'</table>';

	if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php')){
		require DISCUZ_ROOT.'./source/plugin/it618_union/config/saleset.php';
	}
	
	$tmpn=0;
	
	if($union_credits_isok==1){
		$tmpn=$tmpn+1;if($tmpn%2==0)$tmpbg='style="background-color:#f9f9f9"';else $tmpbg='';
		if($union_credits_tcbl2>0)$tmprow='rowspan=2';else $tmprow='';
		$salestr.='<tr '.$tmpbg.'><td '.$tmprow.' class=salename>'.$union_credits_name.'</td><td '.$tmprow.'>'.$it618_union_lang['s267'].' '.$it618_union_lang['s481'].'<font color=red>'.$union_credits_money.'</font>'.$it618_union_lang['s482'].'</td><td>'.$it618_union_lang['t64'].'</td><td><span>'.$union_credits_tcbl1.'%</span></td></tr>';
		if($union_credits_tcbl2>0)$salestr.='<tr '.$tmpbg.'><td>'.$it618_union_lang['t65'].'</td><td><span>'.$union_credits_tcbl2.'%</span></td></tr>';
	}
	
	if($union_video_isok==1){
		$tmpn=$tmpn+1;if($tmpn%2==0)$tmpbg='style="background-color:#f9f9f9"';else $tmpbg='';
		if($union_video_tcbl2>0)$tmprow='rowspan=2';else $tmprow='';
		$salestr.='<tr '.$tmpbg.'><td '.$tmprow.'  class=salename>'.$union_video_name.'</td><td '.$tmprow.' >'.$it618_union_lang['s700'].' '.$it618_union_lang['s481'].'<font color=red>'.$union_video_money.'</font>'.$it618_union_lang['s482'].'</td><td>'.$it618_union_lang['t64'].'</td><td><span>'.$union_video_tcbl1.'%</span></td></tr>';
		if($union_video_tcbl2>0)$salestr.='<tr '.$tmpbg.'><td>'.$it618_union_lang['t65'].'</td><td><span>'.$union_video_tcbl2.'%</span></td></tr>';
	}
	
	if($union_exam_isok==1){
		$tmpn=$tmpn+1;if($tmpn%2==0)$tmpbg='style="background-color:#f9f9f9"';else $tmpbg='';
		if($union_exam_tcbl2>0)$tmprow='rowspan=2';else $tmprow='';
		$salestr.='<tr '.$tmpbg.'><td '.$tmprow.'  class=salename>'.$union_exam_name.'</td><td '.$tmprow.' >'.$it618_union_lang['s700'].' '.$it618_union_lang['s481'].'<font color=red>'.$union_exam_money.'</font>'.$it618_union_lang['s482'].'</td><td>'.$it618_union_lang['t64'].'</td><td><span>'.$union_exam_tcbl1.'%</span></td></tr>';
		if($union_exam_tcbl2>0)$salestr.='<tr '.$tmpbg.'><td>'.$it618_union_lang['t65'].'</td><td><span>'.$union_exam_tcbl2.'%</span></td></tr>';
	}
	
	if($union_group_isok==1){
		$tmpn=$tmpn+1;if($tmpn%2==0)$tmpbg='style="background-color:#f9f9f9"';else $tmpbg='';
		if($union_group_tcbl2>0)$tmprow='rowspan=2';else $tmprow='';
		$salestr.='<tr '.$tmpbg.'><td '.$tmprow.'  class=salename>'.$union_group_name.'</td><td '.$tmprow.' >'.$it618_union_lang['s700'].' '.$it618_union_lang['s481'].'<font color=red>'.$union_group_money.'</font>'.$it618_union_lang['s482'].'</td><td>'.$it618_union_lang['t64'].'</td><td><span>'.$union_group_tcbl1.'%</span></td></tr>';
		if($union_group_tcbl2>0)$salestr.='<tr '.$tmpbg.'><td>'.$it618_union_lang['t65'].'</td><td><span>'.$union_group_tcbl2.'%</span></td></tr>';
	}
	
	if($union_brand_isok==1){
		$tmpn=$tmpn+1;if($tmpn%2==0)$tmpbg='style="background-color:#f9f9f9"';else $tmpbg='';
		if($union_brand_tcbl2>0)$tmprow='rowspan=2';else $tmprow='';
		$salestr.='<tr '.$tmpbg.'><td '.$tmprow.'  class=salename>'.$union_brand_name.'</td><td '.$tmprow.' >'.$it618_union_lang['s268'].' '.$it618_union_lang['s481'].'<font color=red>'.$union_brand_money.'</font>'.$it618_union_lang['s482'].' '.$it618_union_lang['s465'].'</td><td>'.$it618_union_lang['t64'].'</td><td><span>'.$union_brand_tcbl1.'%</span></td></tr>';
		if($union_brand_tcbl2>0)$salestr.='<tr '.$tmpbg.'><td>'.$it618_union_lang['t65'].'</td><td><span>'.$union_brand_tcbl2.'%</span></td></tr>';
	}
	
	if($union_tuan_isok==1){
		$tmpn=$tmpn+1;if($tmpn%2==0)$tmpbg='style="background-color:#f9f9f9"';else $tmpbg='';
		if($union_tuan_tcbl2>0)$tmprow='rowspan=2';else $tmprow='';
		$salestr.='<tr '.$tmpbg.'><td '.$tmprow.'  class=salename>'.$union_tuan_name.'</td><td '.$tmprow.' >'.$it618_union_lang['s700'].' '.$it618_union_lang['s481'].'<font color=red>'.$union_tuan_money.'</font>'.$it618_union_lang['s482'].' '.$it618_union_lang['s465'].'</td><td>'.$it618_union_lang['t64'].'</td><td><span>'.$union_tuan_tcbl1.'%</span></td></tr>';
		if($union_tuan_tcbl2>0)$salestr.='<tr '.$tmpbg.'><td>'.$it618_union_lang['t65'].'</td><td><span>'.$union_tuan_tcbl2.'%</span></td></tr>';
	}
	
	if($union_waimai_isok==1){
		$tmpn=$tmpn+1;if($tmpn%2==0)$tmpbg='style="background-color:#f9f9f9"';else $tmpbg='';
		if($union_waimai_tcbl2>0)$tmprow='rowspan=2';else $tmprow='';
		$salestr.='<tr '.$tmpbg.'><td '.$tmprow.'  class=salename>'.$union_waimai_name.'</td><td '.$tmprow.' >'.$it618_union_lang['s481'].'<font color=red>'.$union_waimai_money.'</font>'.$it618_union_lang['s482'].' '.$it618_union_lang['s465'].'</td><td>'.$it618_union_lang['t64'].'</td><td><span>'.$union_waimai_tcbl1.'%</span></td></tr>';
		if($union_waimai_tcbl2>0)$salestr.='<tr '.$tmpbg.'><td>'.$it618_union_lang['t65'].'</td><td><span>'.$union_waimai_tcbl2.'%</span></td></tr>';
	}
	
	if($union_sale_isok==1){
		$tmpn=$tmpn+1;if($tmpn%2==0)$tmpbg='style="background-color:#f9f9f9"';else $tmpbg='';
		if($union_sale_tcbl2>0)$tmprow='rowspan=2';else $tmprow='';
		$salestr.='<tr '.$tmpbg.'><td '.$tmprow.'  class=salename>'.$union_sale_name.'</td><td '.$tmprow.' >'.$it618_union_lang['s999'].' '.$it618_union_lang['s1000'].'<font color=red>'.$union_sale_money.'</font>'.$it618_union_lang['s482'].'</td><td>'.$it618_union_lang['t64'].'</td><td><span>'.$union_sale_tcbl1.'%</span></td></tr>';
		if($union_sale_tcbl2>0)$salestr.='<tr '.$tmpbg.'><td>'.$it618_union_lang['t65'].'</td><td><span>'.$union_sale_tcbl2.'%</span></td></tr>';
	}
	
	if($union_paotui_isok==1){
		$tmpn=$tmpn+1;if($tmpn%2==0)$tmpbg='style="background-color:#f9f9f9"';else $tmpbg='';
		if($union_paotui_tcbl2>0)$tmprow='rowspan=2';else $tmprow='';
		$salestr.='<tr '.$tmpbg.'><td '.$tmprow.'  class=salename>'.$union_paotui_name.'</td><td '.$tmprow.' >'.$it618_union_lang['s481'].'<font color=red>'.$union_paotui_money.'</font>'.$it618_union_lang['s482'].' '.$it618_union_lang['s465'].'</td><td>'.$it618_union_lang['t64'].'</td><td><span>'.$union_paotui_tcbl1.'%</span></td></tr>';
		if($union_paotui_tcbl2>0)$salestr.='<tr '.$tmpbg.'><td>'.$it618_union_lang['t65'].'</td><td><span>'.$union_paotui_tcbl2.'%</span></td></tr>';
	}
	
	if($union_witkey_isok==1){
		$tmpn=$tmpn+1;if($tmpn%2==0)$tmpbg='style="background-color:#f9f9f9"';else $tmpbg='';
		if($union_witkey_post1>0)$tmprow='rowspan=2';else $tmprow='';
		$salestr.='<tr '.$tmpbg.'><td rowspan=4 class=salename1>'.$union_witkey_name.'</td><td '.$tmprow.' >'.$it618_union_lang['s648'].'<font color=red>'.$union_witkey_post_money.'</font></td><td>'.$it618_union_lang['t64'].'</td><td><span>'.$union_witkey_post.'%</span></td></tr>';
		if($union_witkey_post1>0)$salestr.='<tr '.$tmpbg.'><td>'.$it618_union_lang['t65'].'</td><td><span>'.$union_witkey_post1.'%</span></td></tr>';
		
		if($union_witkey_get1>0)$tmprow='rowspan=2';else $tmprow='';
		$salestr.='<tr '.$tmpbg.'><td '.$tmprow.' >'.$it618_union_lang['s649'].'<font color=red>'.$union_witkey_get_money.'</font></td><td>'.$it618_union_lang['t64'].'</td><td><span>'.$union_witkey_get.'%</span></td></tr>';
		if($union_witkey_get1>0)$salestr.='<tr '.$tmpbg.'><td>'.$it618_union_lang['t65'].'</td><td><span>'.$union_witkey_get1.'%</span></td></tr>';
	}
		
	if($union_wike_isok==1){
		$tmpn=$tmpn+1;if($tmpn%2==0)$tmpbg='style="background-color:#f9f9f9"';else $tmpbg='';
		if($union_wike_post1>0)$tmprow='rowspan=2';else $tmprow='';
		$salestr.='<tr '.$tmpbg.'><td rowspan=4 class=salename1>'.$union_wike_name.'</td><td '.$tmprow.' >'.$it618_union_lang['s648'].'<font color=red>'.$union_wike_post_money.'</font></td><td>'.$it618_union_lang['t64'].'</td><td><span>'.$union_wike_post.'%</span></td></tr>';
		if($union_wike_post1>0)$salestr.='<tr '.$tmpbg.'><td>'.$it618_union_lang['t65'].'</td><td><span>'.$union_wike_post1.'%</span></td></tr>';
		
		if($union_wike_get1>0)$tmprow='rowspan=2';else $tmprow='';
		$salestr.='<tr '.$tmpbg.'><td '.$tmprow.' >'.$it618_union_lang['s649'].'<font color=red>'.$union_wike_get_money.'</font></td><td>'.$it618_union_lang['t64'].'</td><td><span>'.$union_wike_get.'%</span></td></tr>';
		if($union_wike_get1>0)$salestr.='<tr '.$tmpbg.'><td>'.$it618_union_lang['t65'].'</td><td><span>'.$union_wike_get1.'%</span></td></tr>';
	}
	
	if($union_scoremall_isok==1){
		$tmpn=$tmpn+1;if($tmpn%2==0)$tmpbg='style="background-color:#f9f9f9"';else $tmpbg='';
		if($union_scoremall1>0)$tmprow='rowspan=2';else $tmprow='';
		$salestr.='<tr '.$tmpbg.'><td rowspan=4 class=salename1>'.$union_scoremall_name.'</td><td '.$tmprow.' >'.$it618_union_lang['s651'].'<font color=red>'.$union_scoremall_money.'</font> '.$it618_union_lang['s465'].'</td><td>'.$it618_union_lang['t64'].'</td><td><span>'.$union_scoremall.'%</span></td></tr>';
		if($union_scoremall1>0)$salestr.='<tr '.$tmpbg.'><td>'.$it618_union_lang['t65'].'</td><td><span>'.$union_scoremall1.'%</span></td></tr>';
	}
	
	$salestr='<table width="100%" class="salecss"><tr><th width=180>'.$it618_union_lang['s475'].'</th><th>'.$it618_union_lang['s480'].'</th><th width=130>'.$it618_union_lang['s476'].'</th><th>'.$it618_union_lang['s477'].'</th></tr>'.$salestr.'</table>';
}

function gettmpstr($tmpstr){
	if($tmpstr!=''){
		$tmpstr=$tmpstr.'@';
		$tmpstr=str_replace('+ @','',$tmpstr);
	}
	
	return $tmpstr;
}
?>