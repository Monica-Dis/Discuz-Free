<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_union = $_G['cache']['plugin']['it618_union'];
require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';

$shoptype=$_GET['shoptype'];
$pid=intval($_GET['pid']);
$uid=$_G['uid'];

$shoptypearray = array('video', 'exam', 'group', 'brand', 'tuan');
$shoptype = !in_array($_GET['shoptype'], $shoptypearray) ? '' : $_GET['shoptype'];

$it618sql="it618_saletype='it618_".$shoptype."' and it618_pid=".$pid;

$url_yqreg=it618_union_getrewrite('union_uc','yqreg','plugin.php?id=it618_union:union_uc&pagetype=yqreg');
$url_saletc=it618_union_getrewrite('union_uc','saletc','plugin.php?id=it618_union:union_uc&pagetype=saletc');

if($uid>0){
	foreach(C::t('#it618_union#it618_union_saletc')->fetch_all_by_search(
			$it618sql,'id desc',$uid, '', '',0,30
	) as $it618_union_saletc) {
	
		if(lang('plugin/it618_union', $it618_union_lang['it618'])!=$it618_union_lang['version'])exit;
	
		if($it618_union_saletc['it618_saletype']=='it618_video'){
			if($it618_video_sale = C::t('#it618_video#it618_video_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
				$it618_video_goods = C::t('#it618_video#it618_video_goods')->fetch_by_id($it618_video_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_video',$it618_video_goods['it618_shopid'],$it618_video_goods['id'],$it618_video_goods['it618_picbig']);
				
				$goodsurl=it618_union_getrewrite_plugin('it618_video','video_product',$it618_video_goods['id'],'plugin.php?id=it618_video:product&pid='.$it618_video_goods['id']);
				$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_video_goods['it618_name'].'</a>';
				
				if($it618_video_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_video#it618_video_goods_type')->fetch_it618_name_by_id($it618_video_sale['it618_gtypeid']);
					$gtypename=str_replace("all",$it618_union_lang['s880'],$gtypename);
				}else{
					$gtypename=$it618_union_lang['s25'];
				}
				
				$goodcount=$it618_union_lang['s1890'].$it618_video_sale['it618_count'];
				
				$saletime=$it618_video_sale['it618_time'];
			}else{
				continue;
			}
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_exam'){
			if($it618_exam_sale = C::t('#it618_exam#it618_exam_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
				$it618_exam_goods = C::t('#it618_exam#it618_exam_goods')->fetch_by_id($it618_exam_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_exam',$it618_exam_goods['it618_shopid'],$it618_exam_goods['id'],$it618_exam_goods['it618_picbig']);
				
				$goodsurl=it618_union_getrewrite_plugin('it618_exam','exam_product',$it618_exam_goods['id'],'plugin.php?id=it618_exam:product&pid='.$it618_exam_goods['id']);
				$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_exam_goods['it618_name'].'</a>';
				
				if($it618_exam_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_exam#it618_exam_goods_type')->fetch_it618_name_by_id($it618_exam_sale['it618_gtypeid']);
				}else{
					$gtypename=$it618_union_lang['s25'];
				}
				
				$goodcount=$it618_union_lang['s1890'].$it618_exam_sale['it618_count'];
				
				$saletime=$it618_exam_sale['it618_time'];
			}else{
				continue;
			}
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_group'){
			
			if($it618_group_sale = C::t('#it618_group#it618_group_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
				$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_sale['it618_pid']);
				$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($it618_group_goods['it618_groupid']);
				$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$it618_group_goods['it618_groupid']);
				$it618_unit=it618_union_getvipgoodsunit($it618_group_goods);
	
				//$goodspic=it618_union_getgoodspic_plugin('it618_group',0,$it618_group_goods['id'],$it618_group_goods['it618_picbig']);
				$goodspic=$it618_group_group['it618_ico'];
				$goodsname=$grouptitle.' '.$it618_unit;
				$goodsurl=it618_union_getrewrite_plugin('it618_group','group_product',$it618_group_goods['id'],'plugin.php?id=it618_group:product&pid='.$it618_group_goods['id']);
				
				if($it618_group_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_group#it618_group_goods_type')->fetch_it618_name_by_id($it618_group_sale['it618_gtypeid']);
				}else{
					$gtypename=$it618_union_lang['s25'];
				}
				
				$goodcount=$it618_union_lang['s1890'].$it618_group_sale['it618_count'];
				
				$saletime=$it618_group_sale['it618_time'];
			}else{
				continue;
			}
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_brand'){
			if($it618_brand_sale = C::t('#it618_brand#it618_brand_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
				$it618_brand_goods = C::t('#it618_brand#it618_brand_goods')->fetch_by_id($it618_brand_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_brand',$it618_brand_goods['it618_shopid'],$it618_brand_goods['id'],$it618_brand_goods['it618_picbig']);
				
				$goodsurl=it618_union_getrewrite_plugin('it618_brand','shop_product',$it618_brand_goods['it618_shopid'].'@'.$it618_brand_goods['id'],'plugin.php?id=it618_brand:product&sid='.$it618_brand_goods['it618_shopid'].'&pid='.$it618_brand_goods['id']);
				$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_brand_goods['it618_name'].'</a>';
				
				if($it618_brand_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_brand#it618_brand_goods_type')->fetch_it618_name_by_id($it618_brand_sale['it618_gtypeid']);
				}
				
				$goodcount=$it618_union_lang['s1890'].$it618_brand_sale['it618_count'];
				
				$saletime=$it618_brand_sale['it618_time'];
			}else{
				continue;
			}
		}
		
		if($it618_union_saletc['it618_saletype']=='it618_tuan'){
			if($it618_tuan_sale = C::t('#it618_tuan#it618_tuan_sale')->fetch_by_id($it618_union_saletc['it618_saleid'])){
				$it618_tuan_goods = C::t('#it618_tuan#it618_tuan_goods')->fetch_by_id($it618_tuan_sale['it618_pid']);
				$goodspic=it618_union_getgoodspic_plugin('it618_tuan',$it618_tuan_goods['it618_shopid'],$it618_tuan_goods['id'],$it618_tuan_goods['it618_picbig']);
				
				$goodsurl=it618_union_getrewrite_plugin('it618_tuan','tuan_product',$it618_tuan_goods['id'],'plugin.php?id=it618_tuan:product&pid='.$it618_tuan_goods['id']);
				$goodsname='<a href="'.$goodsurl.'" target="_blank">'.$it618_tuan_goods['it618_name'].'</a>';
				
				if($it618_tuan_sale['it618_gtypeid']>0){
					$gtypename=C::t('#it618_tuan#it618_tuan_goods_type')->fetch_it618_name_by_id($it618_tuan_sale['it618_gtypeid']);
				}
				
				$goodcount=$it618_union_lang['s1890'].$it618_tuan_sale['it618_count'];
				
				$saletime=$it618_tuan_sale['it618_time'];
			}else{
				continue;
			}
		}
		
		$salemoneystr='';
		if($it618_union_saletc['it618_salemoney']>0){
			$salemoneystr=$it618_union_saletc['it618_salemoney'].' '.$it618_union_lang['s195'];
		}else{
			for($i=1;$i<=8;$i++){
				if($it618_union_saletc['it618_salecredit'.$i]>0)$salemoneystr.=$it618_union_saletc['it618_salecredit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].' ';
			}
		}
		
		$tcmoneystr='';
		if($it618_union_saletc['it618_tcmoney']>0){
			$tcmoneystr=$it618_union_saletc['it618_tcmoney'].' '.$it618_union_lang['s195'];
		}else{
			for($i=1;$i<=8;$i++){
				if($_G['setting']['extcredits'][$i]['title']!=''&&$it618_union_saletc['it618_credit'.$i]>0){
					if($_GET['wap']==1){
						$tcmoneystr.=$it618_union_saletc['it618_credit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].', ';
					}else{
						$tcmoneystr.=$it618_union_saletc['it618_credit'.$i].' '.$_G['setting']['extcredits'][$i]['title'].', ';
					}
				}
			}
			if($tcmoneystr!=''){
				$tcmoneystr=$tcmoneystr.'@';
				$tcmoneystr=str_replace(', @','',$tcmoneystr);
			}
		}
		
		if($it618_union_saletc['it618_type']==1){
			$tmpuser=$it618_union_lang['s990'].it618_union_getusername($it618_union_saletc['it618_saleuid']);
		}else{
			$tmpuser=$it618_union_lang['s991'].it618_union_getusername($it618_union_saletc['it618_tuiuidfind']);
		}
	
		$mysale_get.='<tr>
						<td class="tdleft"><img src="'.$goodspic.'"/></td>
						<td class="tdright">
							<div class="tdname">'.$goodsname.'</div>
							<div class="tddes"><font color=#999>'.$gtypename.' '.$goodcount.'</font> '.$salemoneystr.'</div>
							<div class="tddes">'.$tmpuser.'</div>
							<div class="tddes"><font color=#999>'.date('Y-m-d H:i:s', $it618_union_saletc['it618_time']).'</font></div>
							<div class="tdprice">'.$tcmoneystr.'</div>
						</td>
					  </tr>
					  <tr><td colspan="2" class="tdcolspan"></td></tr>';
	}
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('it618_union:showyq');
?>