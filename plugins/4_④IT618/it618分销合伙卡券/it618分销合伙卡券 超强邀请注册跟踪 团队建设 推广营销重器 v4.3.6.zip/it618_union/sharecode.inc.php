<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';

$it618sql="it618_isok=1";
if($_GET['class']=='yqreg'){$it618sql.=" and it618_class='yqreg'";}
if($_GET['class']=='shop'){$it618sql.=" and it618_class='shop'";}
if($_GET['class']=='product'){$it618sql.=" and it618_class='product'";}
if($_GET['class']=='tui'){$it618sql.=" and it618_class='tui'";}
$dataid=intval($_GET['dataid']);

$count = C::t('#it618_union#it618_union_sharecode')->count_all_by_search($it618sql." and it618_type='bgimg'",'',$_GET['cid']);
if($count==0){
	echo $it618_union_lang['s404'];exit;
}

foreach(C::t('#it618_union#it618_union_sharecode')->fetch_all_by_search(
		$it618sql,'',$_GET['cid'],0,1000
) as $it618_union_sharecode) {
	if($it618_union_sharecode['it618_type']=='txt'){
		
		$txttmp=it618_union_getsharecodetxtimg($it618_union_sharecode,$dataid);
		$tmptmparr=explode("{uname}",$txttmp);
		if(count($tmptmparr)>1)$txttmp='';
		$tmptmparr=explode("{uid}",$txttmp);
		if(count($tmptmparr)>1)$txttmp='';
		
		if($txttmp!=''){
			$it618_font = DB::result_first("SELECT it618_font FROM ".DB::table('it618_union_sharecode_font')." where id=".$it618_union_sharecode['it618_fontid']);
			$canvas_txt.='
				ctx.font="'.($it618_union_sharecode['it618_fontsize']+3).'px '.$it618_font.'";
				ctx.fillStyle ="'.$it618_union_sharecode['it618_fontcolor'].'";
				drawtext(ctx,"'.it618_union_utftogbk($txttmp).'",'.$it618_union_sharecode['it618_left'].','.$it618_union_sharecode['it618_top'].','.$it618_union_sharecode['it618_width'].');
				';
		}
	}
	
	if($it618_union_sharecode['it618_type']=='img'){
		$imgtmp=it618_union_getsharecodetxtimg($it618_union_sharecode,$dataid);
		$tmptmparr=explode("{userimgsrc}",$imgtmp);
		if(count($tmptmparr)>1)$imgtmp='';
		if($imgtmp!=''){
			$tmpid=$it618_union_sharecode['id'];
			$tmpcodearr=explode(":urlcode&url=",$imgtmp);
			if(count($tmpcodearr)>1){
				
				$url=urldecode($tmpcodearr[1]);
				$tmparrtmp1=explode("&q=",$url);
				if(count($tmparrtmp1)>1){
					$url=$tmparrtmp1[0].'&q='.urlencode($tmparrtmp1[1]);
				}
				
				$canvas_img.='
				IT618_UNION("#qrcode").qrcode({
				 text: "'.$url.'", 
				});
				var img'.$tmpid.' = new Image();
				var canvascode = IT618_UNION("canvas")[1];
				img'.$tmpid.'.src = canvascode.toDataURL("image/png");
				img'.$tmpid.'.setAttribute("crossOrigin", "Anonymous");
				img'.$tmpid.'.onload = function() {
				ctx.globalAlpha='.($it618_union_sharecode['it618_opacity']/100).';
				ctx.drawImage(img'.$tmpid.', '.($it618_union_sharecode['it618_left']+5).', '.$it618_union_sharecode['it618_top'].', '.($it618_union_sharecode['it618_width']-10).', '.($it618_union_sharecode['it618_height']-10).');
				n=n+1;
				}
				';
			}else{
				$it618_radius1='';$it618_radius2='';
				if($it618_union_sharecode['it618_radius']>0){
					$it618_radius1='
					drawRoundedRect(ctx, '.$it618_union_sharecode['it618_left'].', '.$it618_union_sharecode['it618_top'].', '.$it618_union_sharecode['it618_width'].', '.$it618_union_sharecode['it618_height'].', '.$it618_union_sharecode['it618_radius'].');ctx.clip();
					';
					$it618_radius2='ctx.restore();';
				}
				$canvas_img.='
				var img'.$tmpid.' = new Image();
				img'.$tmpid.'.src = "'.$imgtmp.'?'.$_G['timestamp'].'";
				img'.$tmpid.'.setAttribute("crossOrigin", "Anonymous");
				img'.$tmpid.'.onload = function() {
				ctx.globalAlpha='.($it618_union_sharecode['it618_opacity']/100).';
				'.$it618_radius1.'
				ctx.drawImage(img'.$tmpid.', '.$it618_union_sharecode['it618_left'].', '.$it618_union_sharecode['it618_top'].', '.$it618_union_sharecode['it618_width'].', '.$it618_union_sharecode['it618_height'].');
				'.$it618_radius2.'
				n=n+1;
				}
				';
			}
			$imgcount=$imgcount+1;
		}
	}
	
	if($it618_union_sharecode['it618_type']=='bgimg'&&$bgimgurl==''){
		$bgimgurl=$it618_union_sharecode['it618_img'];
		$tmparr=explode('://',$bgimgurl);
		if(count($tmparr)==1)$bgimgurl=$_G['siteurl'].$bgimgurl;
	}
}

$_G['mobiletpl'][2]='/';
include template('it618_union:sharecode');
?>