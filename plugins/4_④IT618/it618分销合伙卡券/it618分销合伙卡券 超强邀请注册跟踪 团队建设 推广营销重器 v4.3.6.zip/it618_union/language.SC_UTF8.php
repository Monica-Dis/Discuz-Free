<?php
/**
 *	开发团队：IT618
 *	it618_copyright 插件设计：<a href="http://t.cn/Aiux1012" target="_blank" title="专业Discuz!应用及周边提供商">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $it618_union_lang;

function it618_union_getlang($langid){
	global $it618_union_lang;
	return $it618_union_lang[$langid];
}

$it618_union_lang['version']='v4.3.6';
$it618_union_lang['s1'] = '电脑版首页轮播';
$it618_union_lang['s2'] = '首页公告管理';
$it618_union_lang['s3'] = '手机版图标导航';
$it618_union_lang['s4'] = '手机版风格';
$it618_union_lang['s5'] = '消息提醒设置';
$it618_union_lang['s6'] = '伪静态设置';
$it618_union_lang['s7'] = '更新成功！(成功修改数:';
$it618_union_lang['s8'] = '成功添加数:';
$it618_union_lang['s9'] = '成功删除数:';
$it618_union_lang['s10'] = '设置数：';
$it618_union_lang['s11'] = '团队奖励设置';
$it618_union_lang['s12'] = '奖励记录';
$it618_union_lang['s13'] = '分销提成设置';
$it618_union_lang['s14'] = '我的分销提成';
$it618_union_lang['s15'] = '欢迎您，';
$it618_union_lang['s16'] = '用户组：';
$it618_union_lang['s17'] = '抱歉，请先登录！';
$it618_union_lang['s18'] = '更新成功！';
$it618_union_lang['s19'] = '更新';
$it618_union_lang['s20'] = '团队奖励设置更新成功！';
$it618_union_lang['s21'] = '<font color=red><b>某人他邀请了一个会员</b>(比如这个会员取名MM)</font>，MM达到以下3个团队奖励条件时就触发以下奖励，前台邀请会员全站访问触发自动奖励检测时间周期：';
$it618_union_lang['s22'] = '注意：自动获取会员的自定义用户组，会员当前用户组不需要切换也可以识别，<font color=blue>如果邀请会员数与拥有用户组的复选框都不勾选，表示没有此团队奖励</font>';
$it618_union_lang['s23'] = '是否自动奖励积分，如果不是自动，需要管理员在后台手工奖励';
$it618_union_lang['s24'] = 'MM拥有用户组：';
$it618_union_lang['s25'] = '永久';
$it618_union_lang['s26'] = 'MM的邀请会员数>=';
$it618_union_lang['s27'] = '可以奖励以下积分(积分数为0时表示不奖励此积分，推荐邀请会员本人的奖励数高于队长)：';
$it618_union_lang['s28'] = '个';
$it618_union_lang['s29'] = '主题数：';
$it618_union_lang['s30'] = '注册时间：';
$it618_union_lang['s31'] = '电脑版通栏轮播';
$it618_union_lang['s32'] = '风格数：';
$it618_union_lang['s33'] = '背景颜色';
$it618_union_lang['s34'] = '个人中心页头渐变色';
$it618_union_lang['s35'] = '默认风格';
$it618_union_lang['s36'] = '秒 注意：时间越小越占服务器cup';
$it618_union_lang['s43'] = '导航数：';
$it618_union_lang['s44'] = '注意：图标尺寸自定义，为了美观，多个图标尺寸要一致，排序为0时不显示';
$it618_union_lang['s45'] = '新窗口';
$it618_union_lang['s60'] = '宽:';
$it618_union_lang['s61'] = '高:';
$it618_union_lang['s62'] = '轮播广告数：';
$it618_union_lang['s63'] = '注意：排序值为0时表示图片不显示，数值越小越在前';
$it618_union_lang['s64'] = '图片';
$it618_union_lang['s65'] = '图片链接(为空时图片不带链接)';
$it618_union_lang['s66'] = '排序';
$it618_union_lang['s67'] = '上传图片';
$it618_union_lang['s68'] = '提交后再上传图片';
$it618_union_lang['s69'] = '注意：图片上传后，自动强制压缩图片宽高为640px,280px，请上传前保证图片是这个比例，这样不变形更加美观';
$it618_union_lang['s72'] = '文字颜色(无突出效果时要为空)';
$it618_union_lang['s73'] = '公告数：';
$it618_union_lang['s74'] = '注意：此公告同时也会显示在手机版首页，排序为0时不显示';
$it618_union_lang['s75'] = '标题';
$it618_union_lang['s76'] = '链接';
$it618_union_lang['s77'] = '文字粗体';
$it618_union_lang['s78'] = '排序';
$it618_union_lang['s79'] = '图标';
$it618_union_lang['s80'] = '上一页';
$it618_union_lang['s81'] = '下一页';
$it618_union_lang['s82'] = '我的团队';
$it618_union_lang['s83'] = '钱包充值提现';
$it618_union_lang['s84'] = '手机版底部导航';
$it618_union_lang['s85'] = '我的分销提成';
$it618_union_lang['s86'] = '退出';
$it618_union_lang['s87'] = '我的设置';
$it618_union_lang['s88'] = '团队成长奖励';
$it618_union_lang['s89'] = '查找';
$it618_union_lang['s90'] = '按会员编号';
$it618_union_lang['s91'] = '提成时间';
$it618_union_lang['s92'] = '记录数：';
$it618_union_lang['s93'] = '会员';
$it618_union_lang['s94'] = '奖励';
$it618_union_lang['s95'] = '比率';
$it618_union_lang['s96'] = '我的团队';
$it618_union_lang['s97'] = '分销提成设置更新成功！';
$it618_union_lang['s98'] = '<font color=red>注意：以下交易模板提成奖励，都是网站给的(现金提成奖励直接是钱包余额)，和商家没关系，目的就是推广网站，给网站带来交易</font>';
$it618_union_lang['s99'] = '电脑版顶部导航';
$it618_union_lang['s100'] = '警告：以下内容有的需要结合编辑器的代码模式(<font color=blue>代码模式/内容模式 通过编辑器的第一个功能图标切换</font>)修改，如果你对代码不了解修改前请一定对内容进行备份！';
$it618_union_lang['s101'] = '电脑版底部信息';
$it618_union_lang['s102'] = '抱歉，此优惠券不存在或已下架！';
$it618_union_lang['s103'] = '抱歉，此优惠券已领完！';
$it618_union_lang['s104'] = '抱歉，此优惠券使用时间已过期，请与商家联系！';
$it618_union_lang['s105'] = '邀请会员管理';
$it618_union_lang['s106'] = '邀请会员编号';
$it618_union_lang['s107'] = '注册时间';
$it618_union_lang['s108'] = '会员数：';
$it618_union_lang['s109'] = '注册会员';
$it618_union_lang['s110'] = '拥有用户组';
$it618_union_lang['s111'] = '用户组';
$it618_union_lang['s112'] = '已加入:';
$it618_union_lang['s113'] = '邀请会员数';
$it618_union_lang['s114'] = '邀请会员';
$it618_union_lang['s115'] = '奖励';
$it618_union_lang['s116'] = '查看';
$it618_union_lang['s117'] = '手机号：';
$it618_union_lang['s118'] = 'QQ：';
$it618_union_lang['s119'] = '公众号：';
$it618_union_lang['s120'] = '电脑版图标导航';
$it618_union_lang['s121'] = '邀请';
$it618_union_lang['s122'] = '注册成为新会员';
$it618_union_lang['s136'] = 'URL 静态化可以提高搜索引擎抓取，开启本功能需要对 Web 服务器增加相应的 Rewrite 支持，且会轻微增加服务器负担。同时您还可以调整每个页面的静态格式，但不得删除其中的标记，重置静态格式请留空。<br><font color=red>注意，修改静态格式后您需要修改服务器的 Rewrite 规则设置，并且要把DZ默认的插件规则删除或放最后一行，此插件规则才有效果</font>';
$it618_union_lang['s137'] = '静态格式扩展名：';
$it618_union_lang['s138'] = '页面';
$it618_union_lang['s139'] = '标记';
$it618_union_lang['s140'] = '格式';
$it618_union_lang['s141'] = '分销合伙卡券电脑版首页';
$it618_union_lang['s142'] = '已付款，资金暂由支付宝保管，请您先<a href="{alipayurl}"><font color=red><b>确认收货</b></font></a>，确认收货后就可以成功交易了！';
$it618_union_lang['s143'] = '电脑版图标导航';
$it618_union_lang['s144'] = '手机版图标导航';
$it618_union_lang['s145'] = '图标';
$it618_union_lang['s146'] = '同前';
$it618_union_lang['s147'] = '分销合伙卡券手机版页';
$it618_union_lang['s148'] = 'Apache Web Server(独立主机用户)';
$it618_union_lang['s149'] = 'Apache Web Server(虚拟主机用户)';
$it618_union_lang['s150'] = '# 将 RewriteEngine 模式打开
RewriteEngine On

# 修改以下语句中的 /discuz 为您的论坛目录地址，如果程序放在根目录中，请将 /discuz 修改为 /
RewriteBase /discuz

# Rewrite 系统规则请勿修改';
$it618_union_lang['s151'] = 'IIS Web Server(独立主机用户)';
$it618_union_lang['s152'] = 'IIS7 Web Server(独立主机用户)';
$it618_union_lang['s153'] = '在线时间';
$it618_union_lang['s154'] = '用户组等级';
$it618_union_lang['s155'] = '发布主题数';
$it618_union_lang['s156'] = '邀请会员数';
$it618_union_lang['s157'] = '某人自己奖励：';
$it618_union_lang['s158'] = '邀请注册分享链接：';
$it618_union_lang['s159'] = '某人上级奖励：';
$it618_union_lang['s160'] = '首页';
$it618_union_lang['s161'] = '二级分销';
$it618_union_lang['s162'] = '分销向导';
$it618_union_lang['s163'] = '我的团队';
$it618_union_lang['s164'] = '团队成长奖励';
$it618_union_lang['s165'] = '分销提成说明';
$it618_union_lang['s166'] = '我的分销提成';
$it618_union_lang['s167'] = '优惠券';
$it618_union_lang['s168'] = '领取优惠券';
$it618_union_lang['s169'] = '我的优惠券';
$it618_union_lang['s170'] = '合伙人';
$it618_union_lang['s171'] = '加入合伙项目';
$it618_union_lang['s172'] = '我的合伙';
$it618_union_lang['s173'] = '我的合伙提成';
$it618_union_lang['s174'] = '添加优惠券';
$it618_union_lang['s175'] = '编辑优惠券';
$it618_union_lang['s176'] = '优惠券管理';
$it618_union_lang['s177'] = '优惠券类型：';
$it618_union_lang['s178'] = '满减券';
$it618_union_lang['s179'] = '代金券';
$it618_union_lang['s180'] = '提示：优惠券保存后，优惠券类型是不可修改的';
$it618_union_lang['s181'] = '优惠券名称：';
$it618_union_lang['s182'] = '优惠券价格：';
$it618_union_lang['s183'] = '提示：为0时表示这个积分不加入价格，如果积分价格都为0，表示此券免费领取';
$it618_union_lang['s184'] = '指定商品：';
$it618_union_lang['s185'] = '<font color=red>提示1：为了方便管理和买家查看，最多可以指定30个商品，如果更多，请直接设置商品无限制<br>提示2：指定商品以外的商品是不能用优惠券的，优惠券领取成功后，会记录当时的指定商品</font>';
$it618_union_lang['s186'] = '有效时间：';
$it618_union_lang['s187'] = '提示：优惠券只能在有效时间内使用，优惠券领取成功后，会记录当时的有效时间';
$it618_union_lang['s188'] = '限量领取：';
$it618_union_lang['s189'] = '限时领取：';
$it618_union_lang['s190'] = '优惠券图片：';
$it618_union_lang['s191'] = '选择图片';
$it618_union_lang['s192'] = '优惠券面值：';
$it618_union_lang['s193'] = '应付金额满';
$it618_union_lang['s194'] = '元时自动减';
$it618_union_lang['s195'] = '元';
$it618_union_lang['s196'] = '可以抵应付金额';
$it618_union_lang['s197'] = '每个会员在';
$it618_union_lang['s198'] = '天内只能领取';
$it618_union_lang['s199'] = '个优惠券 <font color=#999>提示：天数为0表示永久，天数和个数都为0表示没有数量限制</font>';
$it618_union_lang['s200'] = '不限时购';
$it618_union_lang['s201'] = '一个时段';
$it618_union_lang['s202'] = '每天时段';
$it618_union_lang['s203'] = '优惠券详情：';
$it618_union_lang['s204'] = 'SEO关键词：';
$it618_union_lang['s205'] = 'SEO描述：';
$it618_union_lang['s206'] = '保存';
$it618_union_lang['s207'] = '优惠券保存成功！';
$it618_union_lang['s208'] = '优惠券库存：';
$it618_union_lang['s209'] = '提示：库存为0时不能领取优惠券';
$it618_union_lang['s210'] = '抱歉，请填写优惠券名称！';
$it618_union_lang['s211'] = '抱歉，请上传优惠券图片！';
$it618_union_lang['s212'] = '抱歉，优惠券面值金额必须大于0！';
$it618_union_lang['s213'] = '抱歉，优惠券面值金额必须大于0，并且不能大于满金额！';
$it618_union_lang['s214'] = '抱歉，请设置优惠券有效时间！';
$it618_union_lang['s215'] = '技巧：不同时期不同类型和用途的优惠券，请新添加，不要修改以前的优惠券，以前的不需要了，可以下架，这样方便统计和管理';
$it618_union_lang['s216'] = '成功删除优惠券数：';
$it618_union_lang['s217'] = '成功上架优惠券数：';
$it618_union_lang['s218'] = '成功下架优惠券数：';
$it618_union_lang['s219'] = '按关键字';
$it618_union_lang['s220'] = '优惠券类型';
$it618_union_lang['s221'] = '全部类型';
$it618_union_lang['s222'] = '满减券';
$it618_union_lang['s223'] = '代金券';
$it618_union_lang['s224'] = '状态';
$it618_union_lang['s225'] = '全部';
$it618_union_lang['s226'] = '上架';
$it618_union_lang['s227'] = '下架';
$it618_union_lang['s228'] = '优惠券名称/有效期';
$it618_union_lang['s229'] = '优惠券价格/指定商品/限量限时';
$it618_union_lang['s230'] = '状态';
$it618_union_lang['s231'] = '查询';
$it618_union_lang['s232'] = '优惠券数：';
$it618_union_lang['s233'] = '提示：如果是购物车交易，优惠券金额自动按比例分配到购物车的商品交易，算商家奖励时不会减优惠券金额，而算商家可提现金额时会减优惠券金额';
$it618_union_lang['s234'] = '编辑';
$it618_union_lang['s235'] = '删除选中优惠券';
$it618_union_lang['s236'] = '上架选中优惠券';
$it618_union_lang['s237'] = '下架选中优惠券';
$it618_union_lang['s238'] = '全选';
$it618_union_lang['s239'] = '确定要删除选中优惠券？此操作不可逆，有交易的优惠券是不能删除的！';
$it618_union_lang['s240'] = '满';
$it618_union_lang['s241'] = '减';
$it618_union_lang['s242'] = '面值:';
$it618_union_lang['s243'] = '库存:';
$it618_union_lang['s244'] = '没有限制';
$it618_union_lang['s245'] = '限量:';
$it618_union_lang['s246'] = '限时:';
$it618_union_lang['s247'] = '每会员{time}天内只能领取{count}个';
$it618_union_lang['s248'] = '抱歉，如果开启限时领取，请设置领取限制时间！';
$it618_union_lang['s249'] = '{dt1}-{dt2}时间内';
$it618_union_lang['s250'] = '{d1}-{d2}日期内 每天{t1}-{t2}';
$it618_union_lang['s251'] = '已卖:';
$it618_union_lang['s252'] = '商品:';
$it618_union_lang['s253'] = '抱歉，此优惠券不存在！';
$it618_union_lang['s254'] = '抱歉，您不是此优惠券的商家！';
$it618_union_lang['s255'] = '优惠券修改成功！';
$it618_union_lang['s256'] = '<font color=#390>免费</font>';
$it618_union_lang['s257'] = '抱歉，限时领取已结束！';
$it618_union_lang['s258'] = '抱歉，限时领取还没有开始！';
$it618_union_lang['s259'] = '优惠券名称/面值';
$it618_union_lang['s260'] = '优惠券价格/指定商品';
$it618_union_lang['s261'] = '优惠券使用时间/领取会员';
$it618_union_lang['s262'] = '状态';
$it618_union_lang['s263'] = '未使用';
$it618_union_lang['s264'] = '已使用';
$it618_union_lang['s265'] = '提示：会员领取您的收费优惠券后并且使用，优惠券积分会自动转给您，请保证优惠券可以正常使用';
$it618_union_lang['s266'] = '按会员UID';
$it618_union_lang['s267'] = '积分充值、购买用户组';
$it618_union_lang['s268'] = '线上现金价格交易';
$it618_union_lang['s269'] = '领优惠券';
$it618_union_lang['s270'] = '我也要领';
$it618_union_lang['s271'] = '领优惠券';
$it618_union_lang['s272'] = '券领取时间';
$it618_union_lang['s273'] = '优惠券使用时间/领取时间';
$it618_union_lang['s274'] = '最近领券';
$it618_union_lang['s275'] = '一周热领';
$it618_union_lang['s276'] = '最新优惠券';
$it618_union_lang['s277'] = '人气优惠券';
$it618_union_lang['s278'] = '更多优惠券';
$it618_union_lang['s279'] = '库存:';
$it618_union_lang['s280'] = '已领:';
$it618_union_lang['s281'] = '价格:';
$it618_union_lang['s282'] = '合伙项目';
$it618_union_lang['s283'] = '我的优惠券';
$it618_union_lang['s284'] = '我的合伙';
$it618_union_lang['s285'] = '合伙提成';
$it618_union_lang['s286'] = '查看';
$it618_union_lang['s287'] = '优惠券电脑版搜索页';
$it618_union_lang['s288'] = '优惠券详情页';
$it618_union_lang['s289'] = '合伙电脑版搜索页';
$it618_union_lang['s290'] = '合伙详情页';
$it618_union_lang['s291'] = '个人中心电脑版页';
$it618_union_lang['s292'] = '同上';
$it618_union_lang['s293'] = '注册会员';
$it618_union_lang['s294'] = '邀请会员';
$it618_union_lang['s295'] = '奖励';
$it618_union_lang['s296'] = '奖励会员';
$it618_union_lang['s297'] = '奖励信息';
$it618_union_lang['s298'] = '提成时间';
$it618_union_lang['s299'] = '交易会员';
$it618_union_lang['s300'] = '交易类型';
$it618_union_lang['s301'] = '交易编号';
$it618_union_lang['s302'] = '交易金额';
$it618_union_lang['s303'] = '抱歉，领取优惠券需要{jf1}，而您只有{jf2}！';
$it618_union_lang['s304'] = '手机版首页轮播';
$it618_union_lang['s305'] = '金额:';
$it618_union_lang['s306'] = '我的可用优惠券';
$it618_union_lang['s307'] = '本店应付金额：';
$it618_union_lang['s308'] = '用券后应付金额：';
$it618_union_lang['s309'] = '现在领券';
$it618_union_lang['s310'] = '用券后应付总额：';
$it618_union_lang['s311'] = '减';
$it618_union_lang['s312'] = '天后无效';
$it618_union_lang['s313'] = '小时后无效';
$it618_union_lang['s314'] = '分钟后无效';
$it618_union_lang['s315'] = '秒后无效';
$it618_union_lang['s316'] = '抱歉，优惠券不符合条件，点击确定后，重新获取符合条件的优惠券！';
$it618_union_lang['s317'] = '确定提交订单？您选择的优惠券在订单提交后出现付款界面时，就不能再使用了！';
$it618_union_lang['s318'] = '您现在没有可用的优惠券，请多关注我们的优惠活动！';
$it618_union_lang['s319'] = '抱歉，优惠券不符合条件，请关闭当前交易窗口，再点购买重新获取符合条件的优惠券！';
$it618_union_lang['s320'] = '张券';
$it618_union_lang['s321'] = '您有';
$it618_union_lang['s322'] = '张优惠券';
$it618_union_lang['s323'] = '，点此马上使用';
$it618_union_lang['s324'] = '您现在没有可用的优惠券，请多关注我们的优惠活动！';
$it618_union_lang['s325'] = '进店购物';
$it618_union_lang['s326'] = '商家名称：';
$it618_union_lang['s327'] = '<font color=red>注意：不需要设置排序值，每次访问时随机顺序显示</font>';
$it618_union_lang['s328'] = '抱歉，此合伙项目不存在！';
$it618_union_lang['s329'] = '抱歉，您不是合伙项目的商家！';
$it618_union_lang['s342'] = '天前';
$it618_union_lang['s343'] = '小时前';
$it618_union_lang['s344'] = '分钟前';
$it618_union_lang['s345'] = '秒前';
$it618_union_lang['s346'] = '<font color=green>提示：默认有短信宝接口，如果配合 <a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a> 可以有阿里云短信接口，此插件以后还可以扩展更多短信接口</font>';
$it618_union_lang['s347'] = '海报图片设置';
$it618_union_lang['s348'] = '项目数：';
$it618_union_lang['s349'] = '项目名称';
$it618_union_lang['s350'] = '子项目启用 文字元素/图片元素/背景图片';
$it618_union_lang['s351'] = '状态';
$it618_union_lang['s352'] = '文字';
$it618_union_lang['s353'] = '图片';
$it618_union_lang['s354'] = '背景';
$it618_union_lang['s355'] = '邀请注册';
$it618_union_lang['s356'] = '商家分享';
$it618_union_lang['s357'] = '商品分享';
$it618_union_lang['s358'] = '商品合伙项目';
$it618_union_lang['s359'] = '内容长度';
$it618_union_lang['s360'] = '全选';
$it618_union_lang['s361'] = '什么是图片合成：就是程序会在背景图片上按文字与图片的设置参数，合成一个图片，有些像photoshop的图层功能<br>注意：项目和子项目都开启时，子项目的分享海报会是图片的方式展示，否则就以网页方式展示，<font color=red>请用预览功能调好再启用，预览时会自动调用最有人气的商家商品与商品数据做为测试</font><br><font color=blue>如果海报图片调用了会员头像，海报不能显示同时插件访问链接是https的，可能是“论坛后台-站长-UCenter 设置”的UCenter 访问地址不是https</font>';
$it618_union_lang['s362'] = '全选';
$it618_union_lang['s363'] = '全选';
$it618_union_lang['s364'] = '运行中';
$it618_union_lang['s365'] = '未安装';
$it618_union_lang['s366'] = '未开启';
$it618_union_lang['s367'] = '修改以上项目';
$it618_union_lang['s368'] = '开启选中项目';
$it618_union_lang['s369'] = '不开启选中项目';
$it618_union_lang['s370'] = '确定要开启选中项目？';
$it618_union_lang['s371'] = '确定要不开启选中项目？';
$it618_union_lang['s372'] = '项目修改成功！';
$it618_union_lang['s373'] = '成功开启项目数：';
$it618_union_lang['s374'] = '成功不开启项目数：';
$it618_union_lang['s375'] = '预览';
$it618_union_lang['s376'] = '文字内容';
$it618_union_lang['s377'] = '字体';
$it618_union_lang['s378'] = '字体颜色';
$it618_union_lang['s379'] = '左边距';
$it618_union_lang['s380'] = '顶边距';
$it618_union_lang['s381'] = '宽度';
$it618_union_lang['s382'] = '高度';
$it618_union_lang['s383'] = '图片地址';
$it618_union_lang['s384'] = '启用';
$it618_union_lang['s385'] = '记录数：';
$it618_union_lang['s386'] = '注意：文字内容在指定宽度内会自动换行，每个设置项必设置，不启用的是不画的';
$it618_union_lang['s387'] = '注意：图片会按指定的宽度与高度强制显示，推荐图片指定的宽高与原始宽高比例一致，每个设置项必设置，不启用的是不画的';
$it618_union_lang['s388'] = '注意：生成海报图片的宽高就是背景图片的原始宽高，文字与图片就是在背景图片上画的，只能启用一个';
$it618_union_lang['s389'] = '提交后再设置';
$it618_union_lang['s390'] = '备注';
$it618_union_lang['s391'] = '字体大小';
$it618_union_lang['s392'] = '上传ttf字库文件';
$it618_union_lang['s393'] = '也可引用ttf字库文件地址';
$it618_union_lang['s394'] = '标签说明：{title} 邀请注册标题，{about} 邀请注册描述，{uname} 分享者会员名称，{uid} 分享者UID ';
$it618_union_lang['s395'] = '标签说明：{imgsrc} 邀请注册主图地址，{codeimgsrc} 邀请二维码图片地址，{userimgsrc} 分享者头像图片地址 ';
$it618_union_lang['s396'] = '以下文字内容可以直接设置或引用标签，也可以自定义文字内容，<font color=blue>内容长度大于0时，会自动截取指定长度，内容长度为0时不会截取</font>';
$it618_union_lang['s397'] = '以下图片地址可以直接设置标签，如果标签没有需要的图片，可以自己再上传或引用';
$it618_union_lang['s398'] = '标签说明：{shopname} 商家名称，{shopabout} 商家描述，{shopaddr} 商家地址，{shoptel} 商家电话，{uname} 分享者会员名称，{uid} 分享者UID';
$it618_union_lang['s399'] = '标签说明：{logosrc} 商家LOGO地址，{codeimgsrc} 商家店铺二维码图片地址，{userimgsrc} 分享者头像图片地址 ';
$it618_union_lang['s400'] = '标签说明：{pname} 商品名称，{pabout} 商品描述，{pprice} 商品价格，{uname} 分享者会员名称，{uid} 分享者UID';
$it618_union_lang['s401'] = '标签说明：{pimgsrc} 商品主图地址，{codeimgsrc} 商品页二维码图片地址，{userimgsrc} 分享者头像图片地址 ';
$it618_union_lang['s402'] = '标签说明：{pname} 商品名称，{pabout} 商品描述，{pprice} 商品价格，{uname} 分享者会员名称，{uid} 分享者UID ';
$it618_union_lang['s403'] = '标签说明：{pimgsrc} 商品主图地址，{codeimgsrc} 商品页二维码图片地址，{userimgsrc} 分享者头像图片地址 ';
$it618_union_lang['s404'] = '抱歉，背景图片还未启用或设置！';
$it618_union_lang['s405'] = '项目管理';
$it618_union_lang['s406'] = '字体管理';
$it618_union_lang['s407'] = '字体名称';
$it618_union_lang['s408'] = '字体';
$it618_union_lang['s409'] = '调用数';
$it618_union_lang['s410'] = '排序';
$it618_union_lang['s411'] = '启用';
$it618_union_lang['s412'] = '消息提醒设置更新成功！';
$it618_union_lang['s413'] = '<strong>第三方短信接口，按短信条数收费，给第三方充值就可以了</strong> 到此短信平台，<a href="http://www.smsbao.com/reg?r=10122" target="_blank"><font color=green><b>http://www.smsbao.com/reg<font color=red>?r=10122</font></font></a></b> 注册账号并充值，然后填以下内容就可以了';
$it618_union_lang['s414'] = '启用消息接口：';
$it618_union_lang['s415'] = '如果不启用，系统不会有消息提醒功能';
$it618_union_lang['s416'] = '短信接口账号：';
$it618_union_lang['s417'] = '短信接口密码：';
$it618_union_lang['s418'] = '测试接收人手机号：';
$it618_union_lang['s419'] = '多个手机号用英文字母逗号隔开';
$it618_union_lang['s420'] = '测试短信内容：';
$it618_union_lang['s421'] = '管理员手机号：';
$it618_union_lang['s422'] = '如果不启用，管理员不会有消息提醒';
$it618_union_lang['s423'] = '消息模板';
$it618_union_lang['s424'] = '注意：消息模板只有在“启用”状态，才发送提醒消息，如果短信消息模板和微信消息模板都设置了，优先发送微信消息，发送成功了，就不发短信了，方便节省短信成本';
$it618_union_lang['s425'] = '<font color="green">会员通过邀请链接注册成功时 - 管理员消息模板</font>';
$it618_union_lang['s426'] = '<font color="#999999">示例：会员${user} 通过${tuiuser}的邀请链接成功注册！
<br>标签说明：{user}注册会员，{tuiuser}邀请会员</font>';
$it618_union_lang['s427'] = '<font color="green">注册会员达到条件奖励时 - 管理员消息模板</font>';
$it618_union_lang['s428'] = '<font color="#999999">示例：会员${user} 达到奖励条件，${tuiuser}获得${jl}！
<br>标签说明：{user}注册会员，{tuiuser}邀请会员，{jl}奖励内容</font>';
$it618_union_lang['s429'] = '<font color="green">会员通过邀请链接注册成功时</font> - <font color="red">邀请会员消息模板</font>';
$it618_union_lang['s430'] = '<font color="#999999">示例：会员${user} 通过您的邀请链接成功注册！
<br>标签说明：{user}注册会员，{tuiuser}邀请会员</font>';
$it618_union_lang['s431'] = '<font color="green">注册会员达到条件奖励时</font> - <font color="red">邀请会员消息模板</font>';
$it618_union_lang['s432'] = '<font color="#999999">示例：您的团队成员${user} 达到奖励条件，您获得${jl}！
<br>标签说明：{user}注册会员，{tuiuser}邀请会员，{jl}奖励内容</font>';
$it618_union_lang['s441'] = '更新';
$it618_union_lang['s442'] = '更新时发送一个测试短信';
$it618_union_lang['s443'] = '分享海报';
$it618_union_lang['s444'] = '邀请链接：';
$it618_union_lang['s445'] = '邀请分享设置';
$it618_union_lang['s446'] = '邀请分享设置更新成功！';
$it618_union_lang['s447'] = '<font color=red>说明：百度分享对手机版支持不好，最好用手机浏览器、微信或APP自带的分享功能，直接分享手机版的分享页</font>';
$it618_union_lang['s448'] = '海报标题：';
$it618_union_lang['s449'] = '海报图片：';
$it618_union_lang['s450'] = '上传图片';
$it618_union_lang['s451'] = '注意：推荐上传宽大于高的图片，方便搞海报';
$it618_union_lang['s452'] = '手机版分享链接：';
$it618_union_lang['s453'] = '分享页链接，<font color=red>如果未登录状态，会自动跳转到分享页对应会员的邀请链接，如果是会员登录状态，自动跳转到自己的分享页</font>';
$it618_union_lang['s454'] = '海报描述：';
$it618_union_lang['s455'] = '手机版分享说明：';
$it618_union_lang['s456'] = '电脑版分享链接：';
$it618_union_lang['s457'] = '直接是会员的邀请链接';
$it618_union_lang['s458'] = '电脑版邀请方法：';
$it618_union_lang['s459'] = '电脑版分享说明：';
$it618_union_lang['s460'] = '手机版邀请方法：';
$it618_union_lang['s461'] = '提示：以上内容是电脑版二维码右侧说明，支持HTML代码';
$it618_union_lang['s462'] = '提示：以上内容是手机版二维码右侧说明，支持HTML代码';
$it618_union_lang['s463'] = '邀请方法：<br>
1、点击分享图标，直接用百度分享<br>
2、给您的朋友扫左侧邀请注册二维码<br>
3、直接复制以下邀请注册链接<br>
<font color=#999>说明：可以点左侧的功能菜单，直接查看您的邀请会员与分销提成情况</font>';
$it618_union_lang['s464'] = '邀请方法：<br>
1、点击分享图标到分享页，直接分享页面<br>
2、给您的朋友扫左侧邀请注册二维码<br>
3、直接复制以下邀请注册链接<br>
<font color=#999>说明：可以点底部导航“我的”菜单，直接查看您的邀请会员与分销提成情况</font>';
$it618_union_lang['s465'] = '并且确认消费';
$it618_union_lang['s466'] = '抱歉，此插件还未开启，请先开启！';
$it618_union_lang['s467'] = '模块名称：';
$it618_union_lang['s468'] = '方便会员知道是在哪个插件交易';
$it618_union_lang['s469'] = '钱包充值提现';
$it618_union_lang['s470'] = '联盟商家';
$it618_union_lang['s471'] = '视频直播课堂';
$it618_union_lang['s472'] = '多功能商城';
$it618_union_lang['s473'] = '外卖商城';
$it618_union_lang['s474'] = '同城微跑腿';
$it618_union_lang['s475'] = '交易模块';
$it618_union_lang['s476'] = '奖励';
$it618_union_lang['s477'] = '奖励提成比率';
$it618_union_lang['s478'] = '【';
$it618_union_lang['s479'] = '】';
$it618_union_lang['s480'] = '交易条件';
$it618_union_lang['s481'] = '交易金额大于等于';
$it618_union_lang['s482'] = '元';
$it618_union_lang['s483'] = '提示：如果调用数大于0时，表示有项目文字调用，是不能删除的';
$it618_union_lang['s484'] = '';
$it618_union_lang['s485'] = '';
$it618_union_lang['s486'] = '提示：默认提供了一些font-family字体，如果想有更多请看：https://www.cnit618.com/thread-3112-1-1.html';
$it618_union_lang['s487'] = '抱歉，请先在字体管理添加字体！';
$it618_union_lang['s488'] = '导购返利';
$it618_union_lang['s489'] = '抱歉，您最多只能领取';
$it618_union_lang['s490'] = '个，您已经领取了';
$it618_union_lang['s491'] = '个！';
$it618_union_lang['s492'] = '抱歉，';
$it618_union_lang['s493'] = '天内您最多只能领取';
$it618_union_lang['s494'] = '优惠券设置';
$it618_union_lang['s495'] = '以下是支持优惠券插件的积分类型权限：';
$it618_union_lang['s496'] = '优惠券设置更新成功！';
$it618_union_lang['s497'] = ' <font color=#999>只能用以下积分类型设置优惠券价格</font>';
$it618_union_lang['s498'] = '<font color=green>管理员没有设置积分类型权限，价格只能免费</font>';
$it618_union_lang['s499'] = '折扣卡';
$it618_union_lang['s500'] = ' 如果勾选，在此插件线上的现金交易，会有现金提成奖励';
$it618_union_lang['s501'] = '营销管理';
$it618_union_lang['s502'] = '添加优惠券';
$it618_union_lang['s503'] = '优惠券管理';
$it618_union_lang['s504'] = '优惠券领取';
$it618_union_lang['s505'] = '添加折扣卡';
$it618_union_lang['s506'] = '折扣卡管理';
$it618_union_lang['s507'] = '折扣卡交易';
$it618_union_lang['s508'] = '添加合伙项目';
$it618_union_lang['s509'] = '合伙项目管理';
$it618_union_lang['s510'] = '合伙项目加入';
$it618_union_lang['s511'] = '访问分销合伙卡券首页';
$it618_union_lang['s512'] = '提示：如果想不同的商品提成比率与截止时间不同，推荐添加多个合伙项目，也方便统计效果，在交易确认消费后合伙人获取项目提成';
$it618_union_lang['s513'] = '项目名称：';
$it618_union_lang['s514'] = '项目图片：';
$it618_union_lang['s515'] = '提成比率：';
$it618_union_lang['s516'] = '提示：项目保存以后，提成比率只能增大修改不能减小修改，提成比率不能小于<font color=red>{tcbl}%</font> 当提成比率大于<font color=red>{viptcbl}%</font>时为高级合伙项目';
$it618_union_lang['s517'] = '截止时间：';
$it618_union_lang['s518'] = '提示：项目保存以后，截止时间可以延长修改不能减短修改';
$it618_union_lang['sn'] = '';
$it618_union_lang['s519'] = '指定商品：';
$it618_union_lang['s520'] = '提成规则：';
$it618_union_lang['s521'] = '
加入合伙后，复制指定商品的推广链接分享给好友后，在推广截止时间内通过此推广链接购买商品，就算有效推广，交易确认消费后提成会以余额或积分的方式自动转账给您<br><font color=#f30>请注意，交易金额以最后买家实付金额为准，比如用了优惠券、折扣等情况</font>
';
$it618_union_lang['s522'] = '提示：项目保存以后，项目类型不可修改，如果是商品项目，商品可以增加修改';
$it618_union_lang['s523'] = '注意：项目修改前已承接的也同步项目修改后的设置';
$it618_union_lang['s524'] = '推广详情：';
$it618_union_lang['s525'] = '提示：合伙人加入后，可以获取每个指定商品的推广链接，买家通过这个推广链接交易成功，就算推广有效，交易确认消费后，推广提成金额自动转给合伙人';
$it618_union_lang['s526'] = '抱歉，请设置项目提成比率！';
$it618_union_lang['s527'] = '抱歉，请设置项目截止时间！';
$it618_union_lang['s528'] = '抱歉，指定商品数最少要1个！';
$it618_union_lang['s529'] = '抱歉，请填写项目名称！';
$it618_union_lang['s530'] = '抱歉，请上传项目图片！';
$it618_union_lang['s531'] = '合伙项目保存成功！';
$it618_union_lang['s532'] = '项目名称';
$it618_union_lang['s533'] = '指定商品';
$it618_union_lang['s534'] = '提成比率';
$it618_union_lang['s535'] = '截止时间';
$it618_union_lang['s536'] = '加入人数';
$it618_union_lang['s537'] = '状态';
$it618_union_lang['s538'] = '项目类型';
$it618_union_lang['s539'] = '项目数：';
$it618_union_lang['s540'] = '提示：';
$it618_union_lang['s541'] = '查看指定商品';
$it618_union_lang['s542'] = '抱歉，参数有误！';
$it618_union_lang['s543'] = '关闭';
$it618_union_lang['s544'] = '进店购物';
$it618_union_lang['s545'] = '查看指定商品';
$it618_union_lang['s546'] = '免费';
$it618_union_lang['s547'] = '所有商品无限制';
$it618_union_lang['s548'] = '删除选中项目';
$it618_union_lang['s549'] = '上架选中项目';
$it618_union_lang['s550'] = '下架选中项目';
$it618_union_lang['s551'] = '确定要删除选中项目？此操作不可逆！';
$it618_union_lang['s552'] = '扫码访问手机版';
$it618_union_lang['s553'] = '成功删除合伙项目项目数：';
$it618_union_lang['s554'] = '成功上架合伙项目数：';
$it618_union_lang['s555'] = '成功下架合伙项目数：';
$it618_union_lang['s556'] = '合伙项目';
$it618_union_lang['s557'] = '合伙项目详情';
$it618_union_lang['s558'] = '加入合伙';
$it618_union_lang['s559'] = '确定要加入此合伙项目？';
$it618_union_lang['s560'] = '退出';
$it618_union_lang['s561'] = '登录';
$it618_union_lang['s562'] = '注册';
$it618_union_lang['s563'] = '您已成功加入此合伙项目！';
$it618_union_lang['s564'] = '抱歉，此合伙项目不存在或已下架！';
$it618_union_lang['s565'] = '抱歉，此合伙项目截止时间已过期！';
$it618_union_lang['s566'] = '抱歉，此合伙项目您已加入了！';
$it618_union_lang['s567'] = '我已加入合伙';
$it618_union_lang['s568'] = '加入时间';
$it618_union_lang['s569'] = '合伙项目数：';
$it618_union_lang['s570'] = '合伙详情';
$it618_union_lang['s571'] = '分享商品';
$it618_union_lang['s572'] = '复制';
$it618_union_lang['s573'] = '商品的合伙标题与链接已复制成功，分享给好友赚提成！';
$it618_union_lang['s574'] = '最新合伙项目';
$it618_union_lang['s575'] = '推广';
$it618_union_lang['s576'] = '≥';
$it618_union_lang['s577'] = '提成';
$it618_union_lang['s578'] = '热门合伙项目';
$it618_union_lang['s579'] = '他们都在加入';
$it618_union_lang['s580'] = '我也加入';
$it618_union_lang['s581'] = '最新卡券';
$it618_union_lang['s582'] = '热门卡券';
$it618_union_lang['s583'] = '最新合伙';
$it618_union_lang['s584'] = '热门合伙';
$it618_union_lang['s585'] = '合伙项目提成';
$it618_union_lang['s586'] = '提示：项目下架后，不影响合伙项目，只是不能再加入了，截止时间内的有效交易都会自提成';
$it618_union_lang['s587'] = '加入会员';
$it618_union_lang['s588'] = '提示：有效推广的交易确认消费后，您的交易收入=交易实收-平台商家提成-推广提成';
$it618_union_lang['s589'] = '注意：指定商品保存后，是不能取消的，修改推广时，可以增加指定商品，也就是说只能增加不能减少';
$it618_union_lang['s590'] = '抱歉，提成比率不能小于{tcbl}%！';
$it618_union_lang['s591'] = '抱歉，截止时间不能小于上次保存的截止时间！';
$it618_union_lang['s592'] = '抱歉，您现有的用户组没有权限加入此合伙项目！';
$it618_union_lang['s593'] = '抱歉，您现有的用户组没有权限加入此高级合伙项目！';
$it618_union_lang['s594'] = '抱歉，您现有的用户组没有权限领取优惠券！';
$it618_union_lang['s595'] = '商品名称';
$it618_union_lang['s596'] = '交易金额';
$it618_union_lang['s597'] = '提成金额';
$it618_union_lang['s598'] = '交易时间';
$it618_union_lang['s599'] = '结算时间';
$it618_union_lang['s600'] = '状态';
$it618_union_lang['s601'] = '未结算';
$it618_union_lang['s602'] = '已失效';
$it618_union_lang['s603'] = '已结算';
$it618_union_lang['s604'] = '合伙项目提成结算<font color=red>{money}</font>元，结算单号:{tuitcid}';
$it618_union_lang['s605'] = '单号';
$it618_union_lang['s606'] = '记录数：';
$it618_union_lang['s607'] = '全部状态';
$it618_union_lang['s608'] = '合伙人';
$it618_union_lang['s609'] = '按合伙人UID';
$it618_union_lang['s610'] = '提示：交易确认消费了就是已结算状态，如果交易退款或退货了就是已失效状态';
$it618_union_lang['s611'] = '分享海报';
$it618_union_lang['s612'] = '长按识别二维码';
$it618_union_lang['s613'] = '分享：方法1、截图以上海报有效部分，分享图片 方法2、点击商品图片访问带推广链接的商品，用浏览器分享页面';
$it618_union_lang['s614'] = '<font color=red>提示：长按以上海报图片即可分享给微信QQ等好友</font>';
$it618_union_lang['s615'] = '我要加入';
$it618_union_lang['s616'] = '我要领券';
$it618_union_lang['s617'] = '我已加入';
$it618_union_lang['s618'] = '手机版底部二级导航，格式(多个导航要换行)：<br>
&lt;li&gt;&lt;a class="react" href="导航链接1"&gt;导航名称1&lt;/a&gt;&lt;/li&gt;<br>
&lt;li&gt;&lt;a class="react" href="导航链接2"&gt;导航名称2&lt;/a&gt;&lt;/li&gt;';
$it618_union_lang['it618']='i11ill1lliiiililiiililil1i1l1iiiililililililililililii11111111111i1iili1l1ililili11lili11i111111ilililil11111111l111l11ill1i1illii11';
$it618_union_lang['s623'] = '消息模板';
$it618_union_lang['s624'] = '注意：消息模板只有在“启用”状态，才发送提醒消息，如果短信消息模板和微信消息模板都设置了，优先发送微信消息，发送成功了，就不发短信了，方便节省短信成本';
$it618_union_lang['s625'] = '<font color=blue>it618钱包充值提现</font>';
$it618_union_lang['s626'] = '<font color=blue>it618联盟商家</font>';
$it618_union_lang['s627'] = '我自己的奖励提成比率：';
$it618_union_lang['s628'] = '我队长的奖励提成比率：';
$it618_union_lang['s629'] = '<font color=blue>it618视频直播课堂</font>';
$it618_union_lang['s630'] = '<font color=blue>it618外卖商城</font>';
$it618_union_lang['s631'] = '<font color=blue>it618多功能商城</font>';
$it618_union_lang['s632'] = '<font color=blue>it618同城微跑腿</font>';
$it618_union_lang['s633'] = '<br><font color=#f60>当我邀请的会员</font>，在此模块交易成功，交易金额大于等于';
$it618_union_lang['s634'] = '元时，';
$it618_union_lang['s635'] = '无限制 我的所有商品都支持券';
$it618_union_lang['s636'] = '有限制 指定部分商品支持券';
$it618_union_lang['s637'] = '抱歉，指定商品数最多只能30个！';
$it618_union_lang['s638'] = '支持此商家所有商品';
$it618_union_lang['s639'] = '任务悬赏威客';
$it618_union_lang['s640'] = '<font color=green>it618任务悬赏威客</font>';
$it618_union_lang['s641'] = '<font color=#f60>当您的团队成员</font>，发布的任务完成时，付款大于等于';
$it618_union_lang['s642'] = '<font color=#f60>当您的团队成员</font>，承接的任务完成时，收入大于等于';
$it618_union_lang['s643'] = '时';
$it618_union_lang['s644'] = '<font color=#f60>当您的团队成员</font>，在此模块交易成功，第一积分大于等于';
$it618_union_lang['s645'] = ' 如果勾选，在此插件交易时，会员有积分提成奖励(奖励的积分类型就是交易积分类型)';
$it618_union_lang['s646'] = '积分商城';
$it618_union_lang['s647'] = '<font color=green>it618积分商城</font>';
$it618_union_lang['s648'] = '任务完成时发布人 付款金额大于等于';
$it618_union_lang['s649'] = '任务完成时承接人 收入金额大于等于';
$it618_union_lang['s650'] = '交易积分';
$it618_union_lang['s651'] = '第一积分大于等于';
$it618_union_lang['s652'] = '类型';
$it618_union_lang['s653'] = '他的团队成员数大于等于';
$it618_union_lang['s654'] = '拥有';
$it618_union_lang['s655'] = '用户组';
$it618_union_lang['s656'] = '团队成员数：';
$it618_union_lang['s657'] = '拥有用户组：';
$it618_union_lang['s658'] = '手工奖励选中会员成长';
$it618_union_lang['s659'] = '确定要手工奖励？注册会员没有达到条件也会奖励的(方便补充奖励)，此操作不可逆！';
$it618_union_lang['s660'] = '全选';
$it618_union_lang['s661'] = '提示：不管是自动奖励还是手工奖励，如果某团队奖励已经奖励，就不能再奖励了，如果奖励，就是自动按团队奖励设置奖励积分';
$it618_union_lang['s662'] = '成功设置团队奖励';
$it618_union_lang['s663'] = '会员数：';
$it618_union_lang['s664'] = 'G1-团队奖励1：';
$it618_union_lang['s665'] = 'G2-团队奖励2：';
$it618_union_lang['s666'] = 'G3-团队奖励3：';
$it618_union_lang['s667'] = '系统自动奖励';
$it618_union_lang['s668'] = '管理手工奖励';
$it618_union_lang['s669'] = '抱歉，项目提成比率不能大于60%！';
$it618_union_lang['s670'] = '给指定会员私券';
$it618_union_lang['s671'] = '买家私券说明：<br>
1、私券不显示在前台的，也就是说不是公开领取的，但是用法和公开券一样<br>
2、私券不需要买家领取，指定买家在我的优惠券可以查看，同时在交易时符合条件可以使用<br>
3、和公开券不同的是，私券是直接指定会员，同时需要给平台同等券面值金额的提成，提成比率和分销提成比率一样
';
$it618_union_lang['s672'] = '提示：优惠券只能在有效时间内使用';
$it618_union_lang['s673'] = '提示：可以说明这个私券';
$it618_union_lang['s674'] = '指定会员：';
$it618_union_lang['s675'] = '提示：不存在的会员uid添加私券时自动忽略，如果是一个会员直接填写会员uid，如果是多个会员，每个会员uid用逗号,隔开，如：1,2,3';
$it618_union_lang['s676'] = '私券数量：';
$it618_union_lang['s677'] = '<font color=red>注意：如果是指定多个会员时，私券数量为N，是表示每个会员都会有N个私券</font>';
$it618_union_lang['s678'] = '提成金额：';
$it618_union_lang['s679'] = '注意：您添加私券前需要预付给平台提成金额，并且此金额直接从您的钱包余额内扣，<font color=blue>提成金额=提成比率(';
$it618_union_lang['s680'] = ')*券面值*会员数*券数量</font>';
$it618_union_lang['s681'] = '验证会员';
$it618_union_lang['s682'] = '添加私券';
$it618_union_lang['s683'] = '抱歉，合伙项目现金提成需要钱包余额支持，请先安装钱包插件！';
$it618_union_lang['s684'] = '我的私券';
$it618_union_lang['s685'] = '确定要添加私券？会从您的钱包余额扣除提成金额，此操作不可逆！';
$it618_union_lang['s686'] = '我的钱包余额：';
$it618_union_lang['s687'] = '抱歉，私券提成需要钱包余额支持，请先安装钱包插件！';
$it618_union_lang['s688'] = '抱歉，请先填写指定会员！';
$it618_union_lang['s689'] = '抱歉，私券数量要大于0！';
$it618_union_lang['s690'] = '提成金额：';
$it618_union_lang['s691'] = '抱歉，您的提成金额大于您的钱包余额，请补充您的余额！';
$it618_union_lang['s692'] = '{money}元私券{ucount}个会员每个会员{count}个';
$it618_union_lang['s693'] = '私券添加成功！';
$it618_union_lang['s694'] = '<font color=#f60>私券</font>';
$it618_union_lang['s695'] = '分享海报';
$it618_union_lang['s696'] = '项目结束';
$it618_union_lang['s697'] = '分享商品已有合伙项目';
$it618_union_lang['s698'] = '加入更多合伙项目';
$it618_union_lang['s699'] = '';
$it618_union_lang['s700'] = '现金价格部分';
$it618_union_lang['s701'] = '一级分销提成提成结算<font color=red>{money}</font>元，结算单号:{saletcid}';
$it618_union_lang['s702'] = '二级分销提成提成结算<font color=red>{money}</font>元，结算单号:{saletcid}';
$it618_union_lang['s760'] = '天';
$it618_union_lang['s761'] = '个月';
$it618_union_lang['s762'] = '季';
$it618_union_lang['s763'] = '年';
$it618_union_lang['s764'] = '永久';
$it618_union_lang['s765'] = '全站VIP';
$it618_union_lang['s766'] = 'it618用户组VIP会员';
$it618_union_lang['s767'] = '<font color=blue>it618用户组VIP会员</font>';
$it618_union_lang['s768'] = 'it618任务威客众包';
$it618_union_lang['s769'] = '<font color=blue>it618任务威客众包</font>';
$it618_union_lang['s770'] = '任务威客众包';
$it618_union_lang['s771'] = '起';
$it618_union_lang['s829'] = '我的VIP';
$it618_union_lang['s830'] = '详情/续购/全站VIP';
$it618_union_lang['s831'] = '圆角';
$it618_union_lang['s832'] = '透明(30-100)';
$it618_union_lang['s833'] = '注册奖金';
$it618_union_lang['s834'] = '通过您的邀请海报或邀请链接注册成功以后';
$it618_union_lang['s835'] = '，您自己立即获得<font color=red>{money}</font>元奖金';
$it618_union_lang['s836'] = '，您的团队队长立即获得<font color=red>{money}</font>元奖金';
$it618_union_lang['s837'] = '邀请注册成功，您获得{money}元奖金';
$it618_union_lang['s838'] = '您的队员邀请注册成功，您获得{money}元奖金';
$it618_union_lang['s839'] = '注册奖金：';
$it618_union_lang['s840'] = '提示：奖金以钱包余额方式转账给您，奖金记录请查看您的钱包余额账单';
$it618_union_lang['s872'] = '抱歉，您已提交了商家认证申请资料，资料审核中，请等待！';
$it618_union_lang['s873'] = '抱歉，您已提交了商家认证申请资料，审核未通过，可以尝试再提交申请！';
$it618_union_lang['s874'] = '抱歉，您的商家帐号当前是锁定状态，请与管理员联系！';
$it618_union_lang['s875'] = '抱歉，您的商家帐号当前是过期状态，请与管理员联系！';
$it618_union_lang['s876'] = '抱歉，您不是商家，可以提交商家认证申请资料！';
$it618_union_lang['s877'] = '在线考试答题';
$it618_union_lang['s878'] = '<font color=blue>it618在线考试答题</font>';
$it618_union_lang['s879'] = 'vip专属';
$it618_union_lang['s880'] = '全课程';
$it618_union_lang['s881'] = '我的合伙提成';
$it618_union_lang['s882'] = '更多合伙项目';
$it618_union_lang['s883'] = '最近邀请的新成员：';
$it618_union_lang['s884'] = '共有{count}个成员 查看团队奖励';
$it618_union_lang['s885'] = '所有分销提成';
$it618_union_lang['s886'] = '二级分销向导';
$it618_union_lang['s887'] = '';
$it618_union_lang['s888'] = '说明：此内容显示在所有分享海报的邀请奖励菜单，方便让会员知道通过所有海报也可以邀请注册';
$it618_union_lang['s889'] = '';
$it618_union_lang['s890'] = '我';
$it618_union_lang['s891'] = '海报图片';
$it618_union_lang['s892'] = '合伙提成';
$it618_union_lang['s893'] = '我的团队';
$it618_union_lang['s894'] = '分销提成';
$it618_union_lang['s895'] = '抱歉，请扫描二维码访问手机版，再分享海报！';
$it618_union_lang['s896'] = '扫描以上二维码访问手机版';
$it618_union_lang['s897'] = '手机版方便分享海报图片';
$it618_union_lang['s898'] = '合伙项目标题与链接已复制成功！';
$it618_union_lang['s899'] = '分享推广';
$it618_union_lang['s900'] = '成员信息';
$it618_union_lang['s912'] = '名称';
$it618_union_lang['s913'] = '链接';
$it618_union_lang['s914'] = '名称颜色';
$it618_union_lang['s915'] = '排序';
$it618_union_lang['s916'] = '数量：';
$it618_union_lang['s917'] = '提示：排序值为0时不显示';
$it618_union_lang['s918'] = '新窗口打开';
$it618_union_lang['s952'] = '限时交易已结束，敬请期待下期活动！';
$it618_union_lang['s953'] = '距离开始';
$it618_union_lang['s954'] = '距离结束';
$it618_union_lang['s955'] = '每天';
$it618_union_lang['s976'] = '导航数：';
$it618_union_lang['s977'] = '注意：导航图标为了清晰，推荐宽高60到120，导航标题推荐最多4个字，排序为0时不显示';
$it618_union_lang['s978'] = '图标';
$it618_union_lang['s979'] = '标题';
$it618_union_lang['s980'] = '链接';
$it618_union_lang['s981'] = '新窗口';
$it618_union_lang['s982'] = '文字颜色(无突出效果时要为空)';
$it618_union_lang['s983'] = '文字粗体';
$it618_union_lang['s984'] = '排序';
$it618_union_lang['s985'] = '提交后再上传图片';
$it618_union_lang['s986'] = '提示：{waphome}表示首页链接，{wapyqreg}表示分销提成链接，{waptuis}表示合伙项目链接';
$it618_union_lang['s987'] = '显示默认菜单(刷新页面、复制链接、注册登录等)';
$it618_union_lang['s988'] = '电脑版主导航';
$it618_union_lang['s989'] = '编辑合伙项目';
$it618_union_lang['s990'] = '一级会员：';
$it618_union_lang['s991'] = '二级会员：';
$it618_union_lang['s992'] = '充值 ';
$it618_union_lang['s993'] = '购买';
$it618_union_lang['s994'] = '在{name}现金交易';
$it618_union_lang['s995'] = '抱歉，提成比率不能小于上次保存的提成比率{tcbl}%！';
$it618_union_lang['s996'] = '<font color=blue>it618淘宝客导购</font>';
$it618_union_lang['s997'] = '如果勾选，在此插件线上的现金返利，会有现金提成奖励';
$it618_union_lang['s998'] = '<br><font color=#f60>当我邀请的会员</font>，在此模块现金返利成功，返利金额大于等于';
$it618_union_lang['s999'] = '现金返利方式';
$it618_union_lang['s1000'] = '返利金额大于等于';
$it618_union_lang['s1001'] = '成员';
$it618_union_lang['s1002'] = '他的团队';
$it618_union_lang['s1003'] = '的团队';
$it618_union_lang['s1004'] = '抱歉，当前会员不是您的队员，您不能查看他的团队！';
$it618_union_lang['s1005'] = '成员UID';
$it618_union_lang['s1006'] = '成员数：';
$it618_union_lang['s1007'] = '成员';
$it618_union_lang['s1008'] = '信息';
$it618_union_lang['s1009'] = '用户组';
$it618_union_lang['s1010'] = '团队成员数';
$it618_union_lang['s1011'] = '我的一级注册奖金与成长奖励';
$it618_union_lang['s1012'] = '查看团队';
$it618_union_lang['s1013'] = '注册：';
$it618_union_lang['s1014'] = '我的二级注册奖金与成长奖励';
$it618_union_lang['s1015'] = '注册奖金：';
$it618_union_lang['s1016'] = '成长奖励：';
$it618_union_lang['s1017'] = '联系我';
$it618_union_lang['s1018'] = '还拥有';
$it618_union_lang['s1019'] = '个';
$it618_union_lang['s1021'] = '天';
$it618_union_lang['s1022'] = '月';
$it618_union_lang['s1023'] = '年';
$it618_union_lang['s1024'] = '还拥有的用户组';
$it618_union_lang['s1025'] = '公开给团队长信息';
$it618_union_lang['s1026'] = '一级总奖励：';
$it618_union_lang['s1027'] = '二级总奖励：';
$it618_union_lang['s1028'] = '按注册时间';
$it618_union_lang['s1029'] = '按成员人数';
$it618_union_lang['s1030'] = '显示顺序';
$it618_union_lang['s1040'] = '短信接口类型：';
$it618_union_lang['s1041'] = '默认标配短信接口(短信宝)';
$it618_union_lang['s1042'] = 'IT618统一短信接口(阿里大鱼)';
$it618_union_lang['s1043'] = '短信签名：';
$it618_union_lang['s1044'] = 'IT618统一短信接口(阿里云短信)';
$it618_union_lang['s1045'] = '<font color=green><b>抱歉，您还没有安装 【<a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a>】，此插件为IT618公用短信接口插件，<font color=red>同时还是IT618公用微信模板消息接口插件！</font></b></font>';
$it618_union_lang['s1046'] = '短信模板ID：';
$it618_union_lang['s1047'] = '启用,短信消息模板：,短信消息模板ID：,微信消息模板：,微信消息模板ID：';
$it618_union_lang['s1048'] = '已实名认证';
$it618_union_lang['s1220'] = '已拥有';
$it618_union_lang['s1221'] = '知道了';
$it618_union_lang['s1222'] = '购买/续费 用户组';
$it618_union_lang['s1223'] = '权限用户组';
$it618_union_lang['s1224'] = '未拥有';
$it618_union_lang['s1225'] = '如果您拥有以下任意一个用户组，就可以领取优惠券，无需要切换用户组就有权限';
$it618_union_lang['s1226'] = '如果您拥有以下任意一个用户组，就可以加入合伙人，无需要切换用户组就有权限';
$it618_union_lang['s1227'] = '如果您拥有以下任意一个用户组，就可以加入高级合伙人，无需要切换用户组就有权限';
$it618_union_lang['s1228'] = '￥';
$it618_union_lang['s1229'] = '清空所有 文字图片背景设置 并自动添加默认值';
$it618_union_lang['s1230'] = '确定要清空并添加默认值？';
$it618_union_lang['s1231'] = '清空并添加默认值成功！';
$it618_union_lang['s1232'] = '当前商品的合伙项目：';
$it618_union_lang['s1233'] = '当前商品我的分销提成：';
$it618_union_lang['s1234'] = '模板设置';
$it618_union_lang['s1235'] = '手机版模板';
$it618_union_lang['s1236'] = '默认';
$it618_union_lang['s1237'] = '设置项';
$it618_union_lang['s1238'] = '设置值';
$it618_union_lang['s1239'] = '说明';
$it618_union_lang['s1240'] = '注意：每个模板的前台内容可能有部分不同，需要独立设置，切换后会自动显示当前模板的设置菜单，<font color=red>请多关注此插件的增值模板</font>';
$it618_union_lang['s1241'] = '电脑版模板';
$it618_union_lang['s1242'] = '默认(和论坛共页头页脚)';
$it618_union_lang['s1243'] = '模板设置更新成功！';
$it618_union_lang['s1580'] = '赚';
$it618_union_lang['s1581'] = '分成';
$it618_union_lang['s1582'] = '满';
$it618_union_lang['s1583'] = '减';
$it618_union_lang['s1584'] = '无条件减';
$it618_union_lang['s1585'] = '元';
$it618_union_lang['s1791'] = '管理员UID<font color=#999>(用于微信消息，多个UID用,隔开)</font>：';
$it618_union_lang['s1878'] = '在线编辑器设置';
$it618_union_lang['s1879'] = '启用oss接口：';
$it618_union_lang['s1880'] = '如果不启用，上传图片到本地，如果启用，上传图片到oss，并且返回图片网络引用链接';
$it618_union_lang['s1881'] = 'IT618插件阿里云OSS接口设置方法';
$it618_union_lang['s1882'] = 'Access Key ID：';
$it618_union_lang['s1883'] = 'Access Key Secret：';
$it618_union_lang['s1884'] = 'Bucket名称：';
$it618_union_lang['s1885'] = 'Bucket域名EndPoint：';
$it618_union_lang['s1886'] = 'Bucket外网访问域名：';
$it618_union_lang['s1888'] = '如果是个人认证，变量字符最多限制个数：';
$it618_union_lang['s1889'] = '不受限制时请不要填写';
$it618_union_lang['s1890'] = '数量:';
$it618_union_lang['s1901'] = '微信消息模板ID：';
$it618_union_lang['s1902'] = '微信消息标签值：';
$it618_union_lang['s1903'] = '<font color=#999>提示：优先发送微信消息，发送成功了，就不发短信了</font>';
$it618_union_lang['s1904'] = '关闭';
$it618_union_lang['s1905'] = '参数名称';
$it618_union_lang['s1906'] = '参数内容';
$it618_union_lang['s1907'] = '提示：最多支持9个微信消息模板参数，参数名称比如是：first,keyword1,keyword2,keyword3,...,remark，参数内容支持以上一个标签或多个标签';
$it618_union_lang['s1908'] = '取消';
$it618_union_lang['s1909'] = '保存';
$it618_union_lang['s1910'] = '抱歉，如果参数名称填写了，就必须填写参数内容！';
$it618_union_lang['s1911'] = '<font color=green>提示：默认有短信宝接口，如果配合 <a href="http://dism.taobao.com/?@it618_members.plugin" target="_blank">it618会员登录认证</a> 可以有阿里云短信接口，此插件以后还可以扩展更多短信接口</font>';
$it618_union_lang['s1958'] = '当前菜单标题颜色';
$it618_union_lang['s1959'] = '当前菜单图标';

//{lang it618_union:it618_union_lang(\d+)} {$it618_union_lang['t$1']}
$it618_union_lang['t1'] = '欢迎您，';
$it618_union_lang['t2'] = '返回';
$it618_union_lang['t3'] = '首页';
$it618_union_lang['t4'] = '刷新';
$it618_union_lang['t5'] = '导航';
$it618_union_lang['t6'] = '最新注册';
$it618_union_lang['t7'] = '本周排行';
$it618_union_lang['t8'] = '本月排行';
$it618_union_lang['t9'] = '总排行';
$it618_union_lang['t10'] = '会员信息与我的二级奖励';
$it618_union_lang['t11'] = '分销合伙卡券首页';
$it618_union_lang['t12'] = '全站首页';
$it618_union_lang['t13'] = '登录';
$it618_union_lang['t14'] = '注册';
$it618_union_lang['t15'] = '邀请方法：<br>
    1、分享左侧注册邀请二维码<br>
    2、分享以下注册邀请链接<br>
    <font color=#999>说明：我邀请的会员、我的设置、我的奖励等功能，请点击导般菜单</font>';
$it618_union_lang['t16'] = '团队奖励';
$it618_union_lang['t17'] = '您的团队成员，达到以下成长条件时：';
$it618_union_lang['t18'] = '有以下奖励方式：';
$it618_union_lang['t19'] = '邀请会员奖励';
$it618_union_lang['t20'] = '注册会员';
$it618_union_lang['t21'] = '注册时间';
$it618_union_lang['t22'] = '邀请会员';
$it618_union_lang['t23'] = '名次';
$it618_union_lang['t24'] = '会员';
$it618_union_lang['t25'] = '邀请数';
$it618_union_lang['t26'] = '我的团队';
$it618_union_lang['t27'] = '会员编号';
$it618_union_lang['t28'] = '状态';
$it618_union_lang['t29'] = '全部';
$it618_union_lang['t30'] = '未奖励';
$it618_union_lang['t31'] = '已奖励';
$it618_union_lang['t32'] = '注册时间';
$it618_union_lang['t33'] = '搜索';
$it618_union_lang['t34'] = '会员';
$it618_union_lang['t35'] = '会员信息与我的一级奖励';
$it618_union_lang['t36'] = '成长奖励';
$it618_union_lang['t37'] = '我的分销提成';
$it618_union_lang['t38'] = '提成时间';
$it618_union_lang['t39'] = '奖励';
$it618_union_lang['t40'] = '比率';
$it618_union_lang['t41'] = '奖励';
$it618_union_lang['t42'] = '我的设置';
$it618_union_lang['t43'] = '手机号码：';
$it618_union_lang['t44'] = '我的团队队长能看见手机号';
$it618_union_lang['t45'] = '开启会员邀请成功消息提醒';
$it618_union_lang['t46'] = '开启邀请会员奖励消息提醒';
$it618_union_lang['t47'] = 'QQ号码：';
$it618_union_lang['t48'] = '微信公众号：';
$it618_union_lang['t49'] = '更新';
$it618_union_lang['t50'] = '抱歉，请输入手机号码！';
$it618_union_lang['t51'] = '抱歉，请输入有效的11位手机号码！';
$it618_union_lang['t52'] = '抱歉，请输入QQ号码！';
$it618_union_lang['t53'] = '确定要更新我的设置？';
$it618_union_lang['t54'] = '关闭';
$it618_union_lang['t55'] = '请升级您的微信版本！';
$it618_union_lang['t56'] = '邀请标题与链接复制成功！';
$it618_union_lang['t57'] = '我直接发以上链接';
$it618_union_lang['t58'] = '点我一键复制';
$it618_union_lang['t59'] = '给好友 也可以点分享';
$it618_union_lang['t60'] = '分享图片：';
$it618_union_lang['t61'] = '分享标题：';
$it618_union_lang['t62'] = '分享描述：';
$it618_union_lang['t63'] = '分享链接：';
$it618_union_lang['t64'] = '我自己本人';
$it618_union_lang['t65'] = '我的团队长';
$it618_union_lang['t66'] = '奖励';
$it618_union_lang['t67'] = '奖励积分数量';
$it618_union_lang['t68'] = '恭喜您，成功领取一个优惠券！';
$it618_union_lang['t69'] = '您的团队成员，如果在以下模块完成交易时：';
$it618_union_lang['t70'] = '注册会员';
$it618_union_lang['t71'] = '我的团队';
$it618_union_lang['t72'] = '奖励信息';
$it618_union_lang['t73'] = '提成时间';
$it618_union_lang['t74'] = '我邀请的会员编号';
$it618_union_lang['t75'] = '分销提成';
$it618_union_lang['t76'] = '交易会员';
$it618_union_lang['t77'] = '我的团队';
$it618_union_lang['t78'] = '交易金额';
$it618_union_lang['t79'] = '奖励信息';
$it618_union_lang['t80'] = '提成时间';
$it618_union_lang['t80'] = '提成时间';
$it618_union_lang['t81'] = '抱歉，请先登录！也可以点确定直接跳转到登录页面！';
$it618_union_lang['t82'] = '确定要免费领取此优惠券？';
$it618_union_lang['t83'] = '我的钱包';
$it618_union_lang['t84'] = '关闭';
$it618_union_lang['t85'] = '如果您的浏览器没有自动跳转，请点击这里';
$it618_union_lang['t86'] = '提示';
$it618_union_lang['t87'] = '删?';
$it618_union_lang['t88'] = '提交';
$it618_union_lang['t89'] = '请输入优惠券名称关键字';
$it618_union_lang['t90'] = '搜索';
$it618_union_lang['t91'] = '优惠券';
$it618_union_lang['t92'] = '已领取';
$it618_union_lang['t93'] = '优惠券面值：';
$it618_union_lang['t94'] = '使用时间：';
$it618_union_lang['t95'] = '剩余数量：';
$it618_union_lang['t96'] = '优惠券价格：';
$it618_union_lang['t97'] = '限量领取：';
$it618_union_lang['t98'] = '限时领取：';
$it618_union_lang['t99'] = '优惠券详情';
$it618_union_lang['t100'] = '分销向导';
$it618_union_lang['t101'] = '我的团队';
$it618_union_lang['t102'] = '团队奖励';
$it618_union_lang['t103'] = '分销提成';
$it618_union_lang['t104'] = '优惠券';
$it618_union_lang['t105'] = '合伙项目';
$it618_union_lang['t106'] = '我的';
$it618_union_lang['t107'] = '我的设置';
$it618_union_lang['t108'] = '访问我的个人空间';
$it618_union_lang['t109'] = '我的钱包';
$it618_union_lang['t110'] = '余额:';
$it618_union_lang['t111'] = '元/查看积分';
$it618_union_lang['t112'] = '我的团队';
$it618_union_lang['t113'] = '优惠券';
$it618_union_lang['t114'] = '我的设置';
$it618_union_lang['t115'] = '我的钱包';
$it618_union_lang['t116'] = '退出';
$it618_union_lang['t117'] = '最近邀请注册';
$it618_union_lang['t118'] = '周排行';
$it618_union_lang['t119'] = '月排行';
$it618_union_lang['t120'] = '总排行';
$it618_union_lang['t121'] = '最新优惠券';
$it618_union_lang['t122'] = '满减券';
$it618_union_lang['t123'] = '代金券';
$it618_union_lang['t124'] = '查看更多优惠券';
$it618_union_lang['t125'] = '热门优惠券榜';
$it618_union_lang['t126'] = '周';
$it618_union_lang['t127'] = '月';
$it618_union_lang['t128'] = '总';
$it618_union_lang['t129'] = '他们都在领';
$it618_union_lang['t130'] = '个';
$it618_union_lang['t131'] = '邀请链接与奖励说明';
$it618_union_lang['t132'] = '合伙项目';
$it618_union_lang['t133'] = '成长条件';
$it618_union_lang['t134'] = '奖励';
$it618_union_lang['t135'] = '奖励积分数量';
$it618_union_lang['t136'] = '请输入合伙项目名称关键字';
$it618_union_lang['t137'] = '已加入';
$it618_union_lang['t138'] = '人';
$it618_union_lang['t139'] = '链接复制成功！';
$it618_union_lang['t140'] = '合伙项目';
$it618_union_lang['t141'] = '消息提醒：';
$it618_union_lang['t142'] = '二级成长奖励';
$it618_union_lang['t143'] = '用户组：';
$it618_union_lang['t307'] = '限时抢购';
$it618_union_lang['t308'] = '天';
$it618_union_lang['t309'] = '时';
$it618_union_lang['t310'] = '分';
$it618_union_lang['t311'] = '秒';
$it618_union_lang['t312'] = '确定要用积分兑换此优惠券？点确定后就会自动扣此券所需的积分数！';
$it618_union_lang['t654'] = '抱歉，请先登录！也可以直接点确定跳转到登录页面！';
$it618_union_lang['t758'] = '返回上页';
$it618_union_lang['t759'] = '刷新页面';
$it618_union_lang['t760'] = '搜索商品';
$it618_union_lang['t763'] = '复制链接';
$it618_union_lang['t764'] = '请升级您的微信版本！';
$it618_union_lang['t765'] = '链接复制成功！';

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_nav'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_union_nav` (`id`, `it618_name`, `it618_target`, `it618_url`, `it618_color`, `it618_order`) VALUES
(1, '首页', 0, '{home}','',1),
(2, '分销提成', 0, '{yqreg}','',2),
(3, '优惠券', 0, '{quans}','',3),
(4, '合伙项目', 0, '{tuis}','',4);

EOF;
$sql=str_replace("pre_it618_union_nav",DB::table('it618_union_nav'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_bottomnav'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_union_bottomnav` (`id`, `it618_title`, `it618_img`, `it618_curimg`, `it618_url`, `it618_color`, `it618_order`) VALUES
(1, '发现', 'source/plugin/it618_union/wap/images/menu.png', '', '','',3),
(2, '首页', 'source/plugin/it618_union/wap/images/home.png', 'source/plugin/it618_union/wap/images/curhome.png', '{waphome}','',1),
(3, '邀请', 'source/plugin/it618_union/wap/images/yqreg.png', 'source/plugin/it618_union/wap/images/curyqreg.png', '{wapyqreg}','',2),
(4, '合伙', 'source/plugin/it618_union/wap/images/tuis.png', 'source/plugin/it618_union/wap/images/curtuis.png', '{waptuis}','',4),
(5, '我的', 'source/plugin/it618_union/wap/images/uc.png', 'source/plugin/it618_union/wap/images/curuc.png', '','',5);

EOF;
$sql=str_replace("pre_it618_union_bottomnav",DB::table('it618_union_bottomnav'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_union_sharecode_class` (`id`, `it618_plugin`, `it618_name`, `it618_state`) VALUES
(1, 'it618_union', '分销合伙卡券', 0),
(2, 'it618_video', '视频直播课堂', 0),
(3, 'it618_exam', '在线考试答题',0),
(4, 'it618_brand', '联盟商家',0),
(5, 'it618_tuan', '多功能商城',0),
(6, 'it618_waimai', '外卖商城',0);
EOF;
$sql=str_replace("pre_it618_union_sharecode_class",DB::table('it618_union_sharecode_class'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode'));
if($count==0){
$sql = <<<EOF

INSERT INTO `pre_it618_union_sharecode`(`it618_cid`,`it618_class`,`it618_type`,`it618_content`,`it618_length`,`it618_img`,`it618_left`,`it618_top`,`it618_width`,`it618_height`,`it618_fontsize`,`it618_fontid`,`it618_fontcolor`,`it618_about`,`it618_isok`) values
('1','yqreg','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('1','yqreg','img','','0','{imgsrc}','0','0','430','238','0','0','','主图片','1'),
('1','yqreg','txt','{title}','0','','10','268','250','0','12','1','#000','','1'),
('1','yqreg','txt','{about}','0','','10','310','250','0','10','1','#888888','','1'),
('1','yqreg','txt','长按识别二维码','0','','301','390','250','0','9','1','#0099FF','','1'),
('1','yqreg','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二维码图片','1'),
('1','yqreg','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者头像','1'),
('1','yqreg','txt','邀请人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('2','shop','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('2','shop','img','','0','{logosrc}','0','0','430','238','0','0','','主图片','1'),
('2','shop','txt','{shopname}','0','','10','268','250','0','12','1','#000','','1'),
('2','shop','txt','{shopabout}','0','','10','300','250','0','10','1','#888888','','1'),
('2','shop','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二维码图片','1'),
('2','shop','txt','长按识别二维码','0','','301','390','250','0','9','1','#0099FF','','1'),
('2','shop','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者头像','1'),
('2','shop','txt','邀请人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('2','product','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('2','product','img','','0','{pimgsrc}','0','0','430','238','0','0','','主图片','1'),
('2','product','txt','{pname}','0','','10','268','250','0','12','1','#000','','1'),
('2','product','txt','{pabout}','99','','10','320','250','0','10','1','#888888','','1'),
('2','product','txt','{pprice}','0','','10','390','250','0','13','1','#FF0000','','1'),
('2','product','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二维码图片','1'),
('2','product','txt','长按识别二维码','0','','301','390','250','0','9','1','#0099FF','','1'),
('2','product','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者头像','1'),
('2','product','txt','邀请人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('2','tui','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('2','tui','img','','0','{pimgsrc}','0','0','430','238','0','0','','主图片','1'),
('2','tui','txt','{pname}','0','','10','268','250','0','12','1','#000','','1'),
('2','tui','txt','{pabout}','99','','10','320','250','0','10','1','#888888','','1'),
('2','tui','txt','{pprice}','0','','10','390','250','0','13','1','#FF0000','','1'),
('2','tui','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二维码图片','1'),
('2','tui','txt','长按识别二维码','0','','301','390','250','0','9','1','#0099FF','','1'),
('2','tui','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者头像','1'),
('2','tui','txt','邀请人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('4','shop','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('4','shop','img','','0','{logosrc}','0','0','430','238','0','0','','主图片','1'),
('4','shop','txt','{shopname}','0','','10','268','250','0','12','1','#000','','1'),
('4','shop','txt','{shopabout}','0','','10','300','250','0','10','1','#888888','','1'),
('4','shop','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二维码图片','1'),
('4','shop','txt','长按识别二维码','0','','301','390','250','0','9','1','#0099FF','','1'),
('4','shop','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者头像','1'),
('4','shop','txt','邀请人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('4','product','bgimg','','0','source/plugin/it618_union/images/codebg1.png','0','0','0','0','0','0','','','1'),
('4','product','img','','0','{pimgsrc}','0','0','430','415','0','0','','主图片','1'),
('4','product','txt','{pname}','52','','10','453','250','0','12','1','#000','','1'),
('4','product','txt','{pabout}','99','','10','503','250','0','10','1','#888888','','1'),
('4','product','txt','{pprice}','0','','10','575','250','0','13','1','#FF0000','','1'),
('4','product','img','','0','{codeimgsrc}','283','438','123','123','0','0','','二维码图片','1'),
('4','product','txt','长按识别二维码','0','','301','568','250','0','9','1','#0099FF','','1'),
('4','product','img','','0','{userimgsrc}','10','583','20','20','0','0','','分享者头像','1'),
('4','product','txt','邀请人：{uname}({uid})','0','','35','598','250','0','10','1','#888888','','1'),
('4','tui','bgimg','','0','source/plugin/it618_union/images/codebg1.png','0','0','0','0','0','0','','','1'),
('4','tui','img','','0','{pimgsrc}','0','0','430','415','0','0','','主图片','1'),
('4','tui','txt','{pname}','52','','10','453','250','0','12','1','#000','','1'),
('4','tui','txt','{pabout}','99','','10','503','250','0','10','1','#888888','','1'),
('4','tui','txt','{pprice}','0','','10','575','250','0','13','1','#FF0000','','1'),
('4','tui','img','','0','{codeimgsrc}','283','438','123','123','0','0','','二维码图片','1'),
('4','tui','txt','长按识别二维码','0','','301','568','250','0','9','1','#0099FF','','1'),
('4','tui','img','','0','{userimgsrc}','10','583','20','20','0','0','','分享者头像','1'),
('4','tui','txt','邀请人：{uname}({uid})','0','','35','598','250','0','10','1','#888888','','1'),
('5','shop','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('5','shop','img','','0','{logosrc}','0','0','430','238','0','0','','主图片','1'),
('5','shop','txt','{shopname}','0','','10','268','250','0','12','1','#000','','1'),
('5','shop','txt','{shopabout}','0','','10','300','250','0','10','1','#888888','','1'),
('5','shop','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二维码图片','1'),
('5','shop','txt','长按识别二维码','0','','301','390','250','0','9','1','#0099FF','','1'),
('5','shop','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者头像','1'),
('5','shop','txt','邀请人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('5','product','bgimg','','0','source/plugin/it618_union/images/codebg1.png','0','0','0','0','0','0','','','1'),
('5','product','img','','0','{pimgsrc}','0','0','430','415','0','0','','主图片','1'),
('5','product','txt','{pname}','52','','10','453','250','0','12','1','#000','','1'),
('5','product','txt','{pabout}','99','','10','503','250','0','10','1','#888888','','1'),
('5','product','txt','{pprice}','0','','10','575','250','0','13','1','#FF0000','','1'),
('5','product','img','','0','{codeimgsrc}','283','438','123','123','0','0','','二维码图片','1'),
('5','product','txt','长按识别二维码','0','','301','568','250','0','9','1','#0099FF','','1'),
('5','product','img','','0','{userimgsrc}','10','583','20','20','0','0','','分享者头像','1'),
('5','product','txt','邀请人：{uname}({uid})','0','','35','598','250','0','10','1','#888888','','1'),
('5','tui','bgimg','','0','source/plugin/it618_union/images/codebg1.png','0','0','0','0','0','0','','','1'),
('5','tui','img','','0','{pimgsrc}','0','0','430','415','0','0','','主图片','1'),
('5','tui','txt','{pname}','52','','10','453','250','0','12','1','#000','','1'),
('5','tui','txt','{pabout}','99','','10','503','250','0','10','1','#888888','','1'),
('5','tui','txt','{pprice}','0','','10','575','250','0','13','1','#FF0000','','1'),
('5','tui','img','','0','{codeimgsrc}','283','438','123','123','0','0','','二维码图片','1'),
('5','tui','txt','长按识别二维码','0','','301','568','250','0','9','1','#0099FF','','1'),
('5','tui','img','','0','{userimgsrc}','10','583','20','20','0','0','','分享者头像','1'),
('5','tui','txt','邀请人：{uname}({uid})','0','','35','598','250','0','10','1','#888888','','1'),
('6','shop','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('6','shop','img','','0','{logosrc}','0','0','430','238','0','0','','主图片','1'),
('6','shop','txt','{shopname}','0','','10','268','250','0','12','1','#000','','1'),
('6','shop','txt','{shopabout}','0','','10','300','250','0','10','1','#888888','','1'),
('6','shop','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二维码图片','1'),
('6','shop','txt','长按识别二维码','0','','301','390','250','0','9','1','#0099FF','','1'),
('6','shop','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者头像','1'),
('6','shop','txt','邀请人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1');

EOF;
$sql=str_replace("pre_it618_union_sharecode",DB::table('it618_union_sharecode'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." where id=7");
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_union_sharecode_class` (`id`, `it618_plugin`, `it618_name`, `it618_state`) VALUES
(7, 'it618_sale', '淘宝客导购', 0);

EOF;
$sql=str_replace("pre_it618_union_sharecode_class",DB::table('it618_union_sharecode_class'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode')." where it618_cid=7");
if($count==0){
$sql = <<<EOF

INSERT INTO `pre_it618_union_sharecode`(`it618_cid`,`it618_class`,`it618_type`,`it618_content`,`it618_length`,`it618_img`,`it618_left`,`it618_top`,`it618_width`,`it618_height`,`it618_fontsize`,`it618_fontid`,`it618_fontcolor`,`it618_about`,`it618_isok`) values
('7','product','bgimg','','0','source/plugin/it618_union/images/codebg1.png','0','0','0','0','0','0','','','1'),
('7','product','img','','0','{pimgsrc}','0','0','430','415','0','0','','主图片','1'),
('7','product','txt','{pname}','52','','10','453','250','0','12','1','#000','','1'),
('7','product','txt','{pabout}','99','','10','503','250','0','10','1','#888888','','1'),
('7','product','txt','券后价 : {pprice}','0','','10','578','250','0','13','1','#FF0000','','1'),
('7','product','img','','0','{codeimgsrc}','283','438','123','123','0','0','','二维码图片','1'),
('7','product','txt','长按识别二维码','0','','301','568','250','0','9','1','#0099FF','','1'),
('7','product','img','','0','{userimgsrc}','10','583','20','20','0','0','','分享者头像','1'),
('7','product','txt','邀请人：{uname}({uid})','0','','35','598','250','0','10','1','#888888','','1');

EOF;
$sql=str_replace("pre_it618_union_sharecode",DB::table('it618_union_sharecode'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_class')." where id=8");
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_union_sharecode_class` (`id`, `it618_plugin`, `it618_name`, `it618_state`) VALUES
(8, 'it618_group', 'VIP会员', 0);

EOF;
$sql=str_replace("pre_it618_union_sharecode_class",DB::table('it618_union_sharecode_class'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode')." where it618_cid=3");
if($count==0){
$sql = <<<EOF

INSERT INTO `pre_it618_union_sharecode`(`it618_cid`,`it618_class`,`it618_type`,`it618_content`,`it618_length`,`it618_img`,`it618_left`,`it618_top`,`it618_width`,`it618_height`,`it618_fontsize`,`it618_fontid`,`it618_fontcolor`,`it618_about`,`it618_isok`) values
('3','shop','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('3','shop','img','','0','{logosrc}','0','0','430','238','0','0','','主图片','1'),
('3','shop','txt','{shopname}','0','','10','268','250','0','12','1','#000','','1'),
('3','shop','txt','{shopabout}','0','','10','300','250','0','10','1','#888888','','1'),
('3','shop','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二维码图片','1'),
('3','shop','txt','长按识别二维码','0','','301','390','250','0','9','1','#0099FF','','1'),
('3','shop','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者头像','1'),
('3','shop','txt','邀请人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('3','product','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('3','product','img','','0','{pimgsrc}','0','0','430','238','0','0','','主图片','1'),
('3','product','txt','{pname}','0','','10','268','250','0','12','1','#000','','1'),
('3','product','txt','{pabout}','99','','10','320','250','0','10','1','#888888','','1'),
('3','product','txt','{pprice}','0','','10','390','250','0','13','1','#FF0000','','1'),
('3','product','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二维码图片','1'),
('3','product','txt','长按识别二维码','0','','301','390','250','0','9','1','#0099FF','','1'),
('3','product','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者头像','1'),
('3','product','txt','邀请人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('3','tui','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('3','tui','img','','0','{pimgsrc}','0','0','430','238','0','0','','主图片','1'),
('3','tui','txt','{pname}','0','','10','268','250','0','12','1','#000','','1'),
('3','tui','txt','{pabout}','99','','10','320','250','0','10','1','#888888','','1'),
('3','tui','txt','{pprice}','0','','10','390','250','0','13','1','#FF0000','','1'),
('3','tui','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二维码图片','1'),
('3','tui','txt','长按识别二维码','0','','301','390','250','0','9','1','#0099FF','','1'),
('3','tui','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者头像','1'),
('3','tui','txt','邀请人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1');

EOF;
$sql=str_replace("pre_it618_union_sharecode",DB::table('it618_union_sharecode'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode')." where it618_cid=8");
if($count==0){
$sql = <<<EOF

INSERT INTO `pre_it618_union_sharecode`(`it618_cid`,`it618_class`,`it618_type`,`it618_content`,`it618_length`,`it618_img`,`it618_left`,`it618_top`,`it618_width`,`it618_height`,`it618_fontsize`,`it618_fontid`,`it618_fontcolor`,`it618_about`,`it618_isok`) values
('8','product','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('8','product','img','','0','{pimgsrc}','0','0','430','238','0','0','','主图片','1'),
('8','product','txt','{pname}','0','','10','268','250','0','12','1','#000','','1'),
('8','product','txt','{pabout}','99','','10','320','250','0','10','1','#888888','','1'),
('8','product','txt','{pprice}','0','','10','390','250','0','13','1','#FF0000','','1'),
('8','product','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二维码图片','1'),
('8','product','txt','长按识别二维码','0','','301','390','250','0','9','1','#0099FF','','1'),
('8','product','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者头像','1'),
('8','product','txt','邀请人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1'),
('8','tui','bgimg','','0','source/plugin/it618_union/images/codebg.png','0','0','0','0','0','0','','','1'),
('8','tui','img','','0','{pimgsrc}','0','0','430','238','0','0','','主图片','1'),
('8','tui','txt','{pname}','0','','10','268','250','0','12','1','#000','','1'),
('8','tui','txt','{pabout}','99','','10','320','250','0','10','1','#888888','','1'),
('8','tui','txt','{pprice}','0','','10','390','250','0','13','1','#FF0000','','1'),
('8','tui','img','','0','{codeimgsrc}','283','260','123','123','0','0','','二维码图片','1'),
('8','tui','txt','长按识别二维码','0','','301','390','250','0','9','1','#0099FF','','1'),
('8','tui','img','','0','{userimgsrc}','10','400','20','20','0','0','','分享者头像','1'),
('8','tui','txt','邀请人：{uname}({uid})','0','','35','415','250','0','10','1','#888888','','1');

EOF;
$sql=str_replace("pre_it618_union_sharecode",DB::table('it618_union_sharecode'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_set'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_union_set` (`id`, `setname`, `setvalue`) VALUES
(1, 'pctopnav', '<a target="_blank" href="http://www.cnit618.com/forum.php">论坛</a><span></span> <a href="http://www.cnit618.com/forum-58-1.html" target="_blank">插件教程</a><span></span> <a href="http://www.cnit618.com/forum-55-1.html" target="_blank">常见问题</a><span></span> <a href="http://dism.taobao.com/?@5683.developer" target="_blank" style="font-weight:bold;color:red;">在线购买插件</a> '),
(2, 'pcbottom', '<style>\r\n.page-footer .footer-content ul li.liebao{margin-left: 290px;}\r\n.page-footer .footer-content ul li.help-center{border-right: none;}\r\n</style><ul>\r\n	<li class="liebao" onclick="location=''#''">\r\n		IT618网\r\n	</li>\r\n	<li onclick="location=''#''">\r\n		关于我们\r\n	</li>\r\n	<li onclick="location=''#''">\r\n		应用中心\r\n	</li>\r\n	<li onclick="location=''#''">\r\n		常见问题\r\n	</li>\r\n	<li class="help-center" onclick="location=''#''">\r\n		帮助中心\r\n	</li>\r\n</ul>\r\n<span class="copyright"> 版权所有：湖北网络科技股份有限公司\r\n              网站备案/许可证号： <a style="color:#898890;" target="_blank" href="#"> 鄂A1-12345678-1 </a> <a style="color:#898890;" target="_blank" href="#">鄂网文[2018]0001-001号</a> 联系QQ： <a style="color:#898890;" href="#" target="_blank">12345678</a> 联系电话：021-12345678 </span>');

EOF;
$sql=str_replace("pre_it618_union_set",DB::table('it618_union_set'),$sql);
DB::query($sql);
}

$count=DB::result_first("SELECT COUNT(1) FROM ".DB::table('it618_union_sharecode_font'));
if($count==0){
$sql = <<<EOF
INSERT INTO `pre_it618_union_sharecode_font` (`id`, `it618_name`, `it618_font`, `it618_order`) VALUES
(1, '微软雅黑', 'Microsoft YaHei', 1),(2, '微软正黑体', 'Microsoft JhengHei', 2),(3, '宋体', 'SimSun', 3),(4, '新宋体', 'NSimSun', 4),(5, '黑体', 'SimHei', 5);

EOF;
$sql=str_replace("pre_it618_union_sharecode_font",DB::table('it618_union_sharecode_font'),$sql);
DB::query($sql);
}

?>