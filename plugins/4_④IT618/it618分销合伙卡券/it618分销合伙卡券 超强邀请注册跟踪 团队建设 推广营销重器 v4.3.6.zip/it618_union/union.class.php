<?php
/**
 *	�����Ŷӣ�IT618
 *	it618_copyright �����ƣ�<a href="http://t.cn/Aiux1012" target="_blank" title="רҵDiscuz!Ӧ�ü��ܱ��ṩ��">DisM.Taobao.Com</a>
 */
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

class plugin_it618_union_base {
	function common_base() {
		global $_G,$it618_union_lang;
		$it618_union = $_G['cache']['plugin']['it618_union'];
		
		$tuiuid=getcookie('it618_union_tuiuid');
		if($tuiuid==''&&$it618_union['union_tuiuid']>0){
			if($it618_union['union_cookietime']==0)$union_cookietime=3600;else $union_cookietime=$it618_union['union_cookietime']*3600;
			dsetcookie('it618_union_tuiuid',$it618_union['union_tuiuid'],$union_cookietime);	
		}
		
		if($_G['uid']>0){
			require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';
			
			$lastactivity=getcookie('lastactivity');
			
			if($lastactivity!=1){
				dsetcookie('lastactivity',1,10);
				
				$extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
		
				$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
				$groupterms = dunserialize($memberfieldforum['groupterms']);
				unset($memberfieldforum);
				$expgrouparray = $expirylist = $termsarray = array();
				
				if(!empty($groupterms['ext']) && is_array($groupterms['ext'])) {
					$termsarray = $groupterms['ext'];
				}
				if(!empty($groupterms['main']['time']) && (empty($termsarray[$_G['groupid']]) || $termsarray[$_G['groupid']] > $groupterm['main']['time'])) {
					$termsarray[$_G['groupid']] = $groupterms['main']['time'];
				}
				
				foreach($termsarray as $expgroupid => $expiry) {
					if($expiry <= TIMESTAMP) {
						$expgrouparray[] = $expgroupid;
					}
				}
				
				if(!empty($groupterms['ext'])) {
					foreach($groupterms['ext'] as $extgroupid => $time) {
						$expirylist[$extgroupid] = array('timestamp' => $time, 'time' => date('Y-m-d H:i:s', $time), 'type' => 'ext', 'noswitch' => $time < TIMESTAMP);
					}
				}
				
				if(!empty($groupterms['main'])) {
					$expirylist[$_G['groupid']] = array('timestamp' => $groupterms['main']['time'], 'time' => date('Y-m-d H:i:s', $groupterms['main']['time']), 'type' => 'main');
				}
				
				$groupids = array();
				foreach($_G['cache']['usergroups'] as $groupid => $usergroup) {
					if(!empty($usergroup['pubtype'])) {
						$groupids[] = $groupid;
					}
				}
				
				$expiryids = array_keys($expirylist);
				if(!$expiryids && $_G['member']['groupexpiry']) {
					C::t('common_member')->update($_G['uid'], array('groupexpiry' => 0));
				}
				
				$groupids = array_merge($extgroupids, $expiryids, $groupids);
				
				$tmpgroups=implode(',',$groupids);
				DB::query("UPDATE ".DB::table('it618_union_reguser')." SET it618_groupid=".$_G['groupid'].",it618_groups='".$tmpgroups."' where it618_uid=".$_G['uid']);
				
				C::t('#it618_union#it618_union_reguser')->update_lastactivity_by_uid(TIMESTAMP,$_G['uid']);
				
				$yqjlmoneywork=getcookie('yqjlmoneywork');
				
				$yqjlmoney=explode("@",$it618_union['union_yqjlmoney']);
				$regtimecounttmp=0;
				if($IsCredits==1&&$yqjlmoney[0]>0&&$yqjlmoneywork!=1){
					dsetcookie('yqjlmoneywork',1,10);
					if($it618_union_reguser = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where it618_money1=0 and it618_uid=".$_G['uid'])) {
						$regtimecounttmp=$_G['timestamp']-$it618_union_reguser['it618_time'];
						if($it618_union['union_yqjlmoney_time']==0)$it618_union['union_yqjlmoney_time']=1;
					}
				}
					
				if($regtimecounttmp>0&&$regtimecounttmp<=$it618_union['union_yqjlmoney_time']*3600*24){

					$tmptime=$_G['timestamp'];
					
					$isrzpower=1;
					if($it618_union['union_yqjlmoney_isrz']==1&&$IsMembers==1){
						$isrzpower=0;
						if(C::t('#it618_members#it618_members_rzuser')->count_by_uid_rzok($_G['uid'])>0){
							$isrzpower=1;
						}
					}
					
					if($yqjlmoney[0]>0||$yqjlmoney[1]>0){
						if($yqjlmoney[0]>0){
							if($isrzpower==1){
								require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
								
								$it618_bz=$it618_union_lang['s837'];
								$it618_bz=str_replace("{money}",$yqjlmoney[0],$it618_bz);
								
								savemoney(array(
									'it618_uid' => $it618_union_reguser['it618_tuiuid'],
									'it618_type' => 'zy',
									'it618_money1' => $yqjlmoney[0],
									'it618_bz' => $it618_bz,
									'it618_zytype' => 'it618_union_yqmoney1',
									'it618_zyid' => $it618_union_reguser['id'],
									'it618_time' => $tmptime
								));
								
								C::t('#it618_union#it618_union_reguser')->update($it618_union_reguser['id'],array(
									'it618_money1' => $yqjlmoney[0]
								));
							}
							
						}
						
						if($yqjlmoney[1]>0){
							if($isrzpower==1){
								if($it618_union_reguser1 = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where it618_uid=".$it618_union_reguser['it618_tuiuid'])) {
									require_once DISCUZ_ROOT.'./source/plugin/it618_credits/function.func.php';
									
									$it618_bz=$it618_union_lang['s838'];
									$it618_bz=str_replace("{money}",$yqjlmoney[1],$it618_bz);
									
									savemoney(array(
										'it618_uid' => $it618_union_reguser1['it618_tuiuid'],
										'it618_type' => 'zy',
										'it618_money1' => $yqjlmoney[1],
										'it618_bz' => $it618_bz,
										'it618_zytype' => 'it618_union_yqmoney2',
										'it618_zyid' => $it618_union_reguser['id'],
										'it618_time' => $tmptime
									));
									
									C::t('#it618_union#it618_union_reguser')->update($it618_union_reguser['id'],array(
										'it618_money2' => $yqjlmoney[1]
									));
									
								}
							}
						}
					}
				}
			}
			
			$union_do=getcookie('union_do');
			if($tuiuid>0&&$tuiuid!=$_G['uid']&&$union_do!=1){

				if(DB::result_first("SELECT count(1) FROM ".DB::table('it618_union_reguser')." WHERE it618_uid=".$_G['uid'])==0){
					dsetcookie('union_do',1,10);
					$regtime=DB::result_first("SELECT regdate FROM ".DB::table('common_member')." WHERE uid=".$_G['uid']);
					$regtimecount=$_G['timestamp']-$regtime;
					
					if($regtimecount<=60){
						$reguserid=C::t('#it618_union#it618_union_reguser')->insert(array(
							'it618_uid' => $_G['uid'],
							'it618_tuiuid' => $tuiuid,
							'it618_time' => $regtime
						), true);
						
						$tuicount=DB::result_first("select count(1) from ".DB::table('it618_union_reguser')." where it618_tuiuid=".$tuiuid);
						$sql = "update ".DB::table('it618_union_reguser')." set it618_yqcount=".$tuicount." where it618_uid=".$tuiuid;
						DB::query($sql);
						
						it618_union_sendmessage('reg_user',$reguserid);
						it618_union_sendmessage('reg_admin',$reguserid);
					}
				}

			}

			$union_reguser=getcookie('union_reguser');

			if($union_reguser!=1) {
				if (file_exists(DISCUZ_ROOT.'./source/plugin/it618_union/config/jlset.php')){
					require DISCUZ_ROOT.'./source/plugin/it618_union/config/jlset.php';
				}
				
				if($jl_times==0)$jl_times=3;
				dsetcookie('union_reguser',1,$jl_times);
				
				$isgroup=0;
				if(($jl_group_isok1==1||$jl_tuicount_isok1==1)&&$jl_do_isok1==1){
					if($it618_union_reguser = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where it618_uid=".$_G['uid']." and it618_isjl11=0")) {
						
						$jlflag1=1;$jlflag2=1;
						
						if($jl_tuicount_isok1==1){
							$tuicount=DB::result_first("select count(1) from ".DB::table('it618_union_reguser')." where it618_tuiuid=".$it618_union_reguser['it618_uid']);
							if($tuicount<$jl_tuicount1){
								$jlflag1=0;
							}
						}
						
						if($jl_group_isok1==1){
							$jlgroupids1[]=$jl_group1;
							$tmpgrouparr=it618_union_getisvipuser($jlgroupids1);
							if(count($tmpgrouparr[0])==0){
								$jlflag2=0;
							}
						}
						
						if($jlflag1==1&&$jlflag2==1){
							it618_union_yqjl('G1',$jl_credit11,$jl_credit12,$it618_union_reguser);
						}
					}
				}
				
				if(($jl_group_isok2==1||$jl_tuicount_isok2==1)&&$jl_do_isok2==1){
					if($it618_union_reguser = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where it618_uid=".$_G['uid']." and it618_isjl21=0")) {
						
						$jlflag1=1;$jlflag2=1;
						
						if($jl_tuicount_isok2==1){
							$tuicount=DB::result_first("select count(1) from ".DB::table('it618_union_reguser')." where it618_tuiuid=".$it618_union_reguser['it618_uid']);
							if($tuicount<$jl_tuicount2){
								$jlflag1=0;
							}
						}
						
						if($jl_group_isok2==1){
							$jlgroupids2[]=$jl_group2;
							$tmpgrouparr=it618_union_getisvipuser($jlgroupids2);
							if(count($tmpgrouparr[0])==0){
								$jlflag2=0;
							}
						}
						
						if($jlflag1==1&&$jlflag2==1){
							it618_union_yqjl('G2',$jl_credit21,$jl_credit22,$it618_union_reguser);
						}
					}
				}
				
				if(($jl_group_isok3==1||$jl_tuicount_isok3==1)&&$jl_do_isok3==1){
					if($it618_union_reguser = DB::fetch_first("SELECT * FROM ".DB::table('it618_union_reguser')." where it618_uid=".$_G['uid']." and it618_isjl31=0")) {
						
						$jlflag1=1;$jlflag2=1;
						
						if($jl_tuicount_isok3==1){
							$tuicount=DB::result_first("select count(1) from ".DB::table('it618_union_reguser')." where it618_tuiuid=".$it618_union_reguser['it618_uid']);
							if($tuicount<$jl_tuicount3){
								$jlflag1=0;
							}
						}
						
						if($jl_group_isok3==1){
							$jlgroupids3[]=$jl_group3;
							$tmpgrouparr=it618_union_getisvipuser($jlgroupids3);
							if(count($tmpgrouparr[0])==0){
								$jlflag2=0;
							}
						}
						
						if($jlflag1==1&&$jlflag2==1){
							it618_union_yqjl('G3',$jl_credit31,$jl_credit32,$it618_union_reguser);
						}
					}
				}
			}

		}
	}
}

class plugin_it618_union extends plugin_it618_union_base {
	function common() {
		$this->common_base();
	}
}

class mobileplugin_it618_union extends plugin_it618_union_base {
	function common() {
		$this->common_base();
	}
}

?>