<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

$it618_union = $_G['cache']['plugin']['it618_union'];
require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';

$showtype=$_GET['showtype'];
$showid=intval($_GET['showid']);

if($showtype=='quan'){
	if($it618_union_quan = C::t('#it618_union#it618_union_quan')->fetch_by_id($showid)){
		$it618_name=$it618_union_quan['it618_name'];
		$about=it618_union_getquantype($it618_union_quan);
		
		$shoptype=$it618_union_quan['it618_shoptype'];
		$shopid=$it618_union_quan['it618_shopid'];
		$pids=$it618_union_quan['it618_pids'];
	}else{
		echo 'alertit618_split'.it618_union_getlang('s542');exit;
	}
}

if($showtype=='quansale'){
	if($it618_union_quansale = C::t('#it618_union#it618_union_quansale')->fetch_by_id($showid)){
		$it618_union_quan = C::t('#it618_union#it618_union_quan')->fetch_by_id($it618_union_quansale['it618_qid']);
		$it618_name=$it618_union_quan['it618_name'];
		$about=it618_union_getquantype($it618_union_quansale);
		
		$shoptype=$it618_union_quansale['it618_shoptype'];
		$shopid=$it618_union_quansale['it618_shopid'];
		$pids=$it618_union_quansale['it618_pids'];
	}else{
		echo 'alertit618_split'.it618_union_getlang('s542');exit;
	}
}

if($showtype=='tui'){
	if($it618_union_tui = C::t('#it618_union#it618_union_tui')->fetch_by_id($showid)){
		$it618_name=$it618_union_tui['it618_name'];
		$about=$it618_union_lang['s534'].':<font color=red>'.$it618_union_tui['it618_tcbl'].'%</font>';
		
		$shoptype=$it618_union_tui['it618_shoptype'];
		$shopid=$it618_union_tui['it618_shopid'];
		$pids=$it618_union_tui['it618_pids'];
	}else{
		echo 'alertit618_split'.it618_union_getlang('s542');exit;
	}
}

if($showtype=='tuijoin'){
	if($it618_union_tuijoin = C::t('#it618_union#it618_union_tuijoin')->fetch_by_id($showid)){
		$it618_union_tui = C::t('#it618_union#it618_union_tui')->fetch_by_id($it618_union_tuijoin['it618_tid']);
		$it618_name=$it618_union_tui['it618_name'];
		$about=$it618_union_lang['s534'].':<font color=red>'.$it618_union_tui['it618_tcbl'].'%</font>';
		
		$shoptype=$it618_union_tui['it618_shoptype'];
		$shopid=$it618_union_tui['it618_shopid'];
		$pids=$it618_union_tui['it618_pids'];
	}else{
		echo 'alertit618_split'.it618_union_getlang('s542');exit;
	}
}

if($pids!=''){
	$height=90;
	if($shoptype=='video'){
		$height=55;
		$query = DB::query("SELECT * FROM ".DB::table('it618_video_goods')." where it618_state=1 and it618_shopid=$shopid and id in(".$pids.")");
	}
	
	if($shoptype=='exam'){
		$height=55;
		$query = DB::query("SELECT * FROM ".DB::table('it618_exam_goods')." where it618_state=1 and it618_shopid=$shopid and id in(".$pids.")");
	}
	
	if($shoptype=='group'){
		$height=55;
		$query = DB::query("SELECT * FROM ".DB::table('it618_group_goods')." where it618_state=1 and id in(".$pids.")");
	}
	
	if($shoptype=='brand'){
		$query = DB::query("SELECT * FROM ".DB::table('it618_brand_goods')." where it618_ison=1 and it618_shopid=$shopid and id in(".$pids.")");
	}
	
	if($shoptype=='tuan'){
		$query = DB::query("SELECT * FROM ".DB::table('it618_tuan_goods')." where it618_state=1 and it618_shopid=$shopid and id in(".$pids.")");
	}
	
	$pidsstr=',';
	while($tmpgoods = DB::fetch($query)) {

		if($shoptype=='video'){
			$goodspic=it618_union_getgoodspic_plugin('it618_video',$tmpgoods['it618_shopid'],$tmpgoods['id'],$tmpgoods['it618_picbig']);
			$goodsprice=it618_union_getgoodsprice_plugin('it618_video',$tmpgoods);
			
			$tmpurl=it618_union_getrewrite_plugin('it618_video','video_product',$tmpgoods['id'],'plugin.php?id=it618_video:product&pid='.$tmpgoods['id']);
			
			if($showtype=='tuijoin'){
				
				if($_GET['wap']!=1){
					$tmpurl=it618_union_getrewrite_plugin('it618_video','video_product',$tmpgoods['id'],'plugin.php?id=it618_video:product&pid='.$tmpgoods['id'].'&e='.$it618_union_tuijoin['it618_code'],'?e='.$it618_union_tuijoin['it618_code']);
					
					$copyurl='<a href="javascript:" class="goodsbtn" onclick="getcopyurl(\''.$it618_name.'\n'.$_G['siteurl'].$tmpurl.'\')" style="float:right">'.$it618_union_lang['s572'].'</a>';
					$codeurl='<a href="javascript:" class="goodsbtn" onclick="getcodeurl('.$it618_union_tuijoin['id'].','.$tmpgoods['id'].')" style="float:right;margin-left:10px">'.$it618_union_lang['s695'].'</a>';
				}else{
					$tmpurl=it618_union_getrewrite_plugin('it618_video','video_wap','product@'.$tmpgoods['id'],'plugin.php?id=it618_video:wap&pagetype=product&cid='.$tmpgoods['id'].'&e='.$it618_union_tuijoin['it618_code'],'?e='.$it618_union_tuijoin['it618_code']);

					$copyurl='<a href="javascript:" class="goodsbtn copytuiurl'.$tmpgoods['id'].'" data-clipboard-text="'.$it618_name."\n".$_G['siteurl'].$tmpurl.'" style="float:right">'.$it618_union_lang['s572'].'</a>';
					$codeurl='<a href="javascript:" class="goodsbtn" onclick="getcodeurl('.$it618_union_tuijoin['id'].','.$tmpgoods['id'].')" style="float:right;margin-left:10px">'.$it618_union_lang['s695'].'</a>';
					$pidsstr.=$tmpgoods['id'].',';
				}
			}
		}
		
		if($shoptype=='exam'){
			$goodspic=it618_union_getgoodspic_plugin('it618_exam',$tmpgoods['it618_shopid'],$tmpgoods['id'],$tmpgoods['it618_picbig']);
			$goodsprice=it618_union_getgoodsprice_plugin('it618_exam',$tmpgoods);
			
			$tmpurl=it618_union_getrewrite_plugin('it618_exam','exam_product',$tmpgoods['id'],'plugin.php?id=it618_exam:product&pid='.$tmpgoods['id']);
			
			if($showtype=='tuijoin'){
				
				if($_GET['wap']!=1){
					$tmpurl=it618_union_getrewrite_plugin('it618_exam','exam_product',$tmpgoods['id'],'plugin.php?id=it618_exam:product&pid='.$tmpgoods['id'].'&e='.$it618_union_tuijoin['it618_code'],'?e='.$it618_union_tuijoin['it618_code']);
					
					$copyurl='<a href="javascript:" class="goodsbtn" onclick="getcopyurl(\''.$it618_name.'\n'.$_G['siteurl'].$tmpurl.'\')" style="float:right">'.$it618_union_lang['s572'].'</a>';
					$codeurl='<a href="javascript:" class="goodsbtn" onclick="getcodeurl('.$it618_union_tuijoin['id'].','.$tmpgoods['id'].')" style="float:right;margin-left:10px">'.$it618_union_lang['s695'].'</a>';
				}else{
					$tmpurl=it618_union_getrewrite_plugin('it618_exam','exam_wap','product@'.$tmpgoods['id'],'plugin.php?id=it618_exam:wap&pagetype=product&cid='.$tmpgoods['id'].'&e='.$it618_union_tuijoin['it618_code'],'?e='.$it618_union_tuijoin['it618_code']);

					$copyurl='<a href="javascript:" class="goodsbtn copytuiurl'.$tmpgoods['id'].'" data-clipboard-text="'.$it618_name."\n".$_G['siteurl'].$tmpurl.'" style="float:right">'.$it618_union_lang['s572'].'</a>';
					$codeurl='<a href="javascript:" class="goodsbtn" onclick="getcodeurl('.$it618_union_tuijoin['id'].','.$tmpgoods['id'].')" style="float:right;margin-left:10px">'.$it618_union_lang['s695'].'</a>';
					$pidsstr.=$tmpgoods['id'].',';
				}
			}
		}
		
		if($shoptype=='group'){
			$goodspic=it618_union_getgoodspic_plugin('it618_group',0,$tmpgoods['id'],$tmpgoods['it618_picbig']);
			$goodsprice=it618_union_getgoodsprice_plugin('it618_group',$tmpgoods);
			$it618_group_goods = C::t('#it618_group#it618_group_goods')->fetch_by_id($it618_group_sale['it618_pid']);
			$it618_group_group=C::t('#it618_group#it618_group_group')->fetch_by_groupid($tmpgoods['it618_groupid']);
			$grouptitle=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid=".$tmpgoods['it618_groupid']);
			$it618_unit=it618_union_getvipgoodsunit($tmpgoods);
			$tmpgoods['it618_name']=$grouptitle.' '.$it618_unit;
			
			$tmpurl=it618_union_getrewrite_plugin('it618_group','group_product',$tmpgoods['id'],'plugin.php?id=it618_group:product&pid='.$tmpgoods['id']);
			
			if($showtype=='tuijoin'){
				
				if($_GET['wap']!=1){
					$tmpurl=it618_union_getrewrite_plugin('it618_group','group_product',$tmpgoods['id'],'plugin.php?id=it618_group:product&pid='.$tmpgoods['id'].'&e='.$it618_union_tuijoin['it618_code'],'?e='.$it618_union_tuijoin['it618_code']);
					
					$copyurl='<a href="javascript:" class="goodsbtn" onclick="getcopyurl(\''.$it618_name.'\n'.$_G['siteurl'].$tmpurl.'\')" style="float:right">'.$it618_union_lang['s572'].'</a>';
					$codeurl='<a href="javascript:" class="goodsbtn" onclick="getcodeurl('.$it618_union_tuijoin['id'].','.$tmpgoods['id'].')" style="float:right;margin-left:10px">'.$it618_union_lang['s695'].'</a>';
				}else{
					$tmpurl=it618_union_getrewrite_plugin('it618_group','group_wap','product@'.$tmpgoods['id'],'plugin.php?id=it618_group:wap&pagetype=product&cid1='.$tmpgoods['id'].'&e='.$it618_union_tuijoin['it618_code'],'?e='.$it618_union_tuijoin['it618_code']);

					$copyurl='<a href="javascript:" class="goodsbtn copytuiurl'.$tmpgoods['id'].'" data-clipboard-text="'.$it618_name."\n".$_G['siteurl'].$tmpurl.'" style="float:right">'.$it618_union_lang['s572'].'</a>';
					$codeurl='<a href="javascript:" class="goodsbtn" onclick="getcodeurl('.$it618_union_tuijoin['id'].','.$tmpgoods['id'].')" style="float:right;margin-left:10px">'.$it618_union_lang['s695'].'</a>';
					$pidsstr.=$tmpgoods['id'].',';
				}
			}
		}
		
		if($shoptype=='brand'){
			$goodspic=it618_union_getgoodspic_plugin('it618_brand',$tmpgoods['it618_shopid'],$tmpgoods['id'],$tmpgoods['it618_picbig']);
			$goodsprice=it618_union_getgoodsprice_plugin('it618_brand',$tmpgoods);
			
			$tmpurl=it618_union_getrewrite_plugin('it618_brand','shop_product',$tmpgoods['it618_shopid'].'@'.$tmpgoods['id'],'plugin.php?id=it618_brand:product&sid='.$tmpgoods['it618_shopid'].'&pid='.$tmpgoods['id']);
			
			if($showtype=='tuijoin'){
				
				if($_GET['wap']!=1){
					$tmpurl=it618_union_getrewrite_plugin('it618_brand','shop_product',$tmpgoods['it618_shopid'].'@'.$tmpgoods['id'],'plugin.php?id=it618_brand:product&sid='.$tmpgoods['it618_shopid'].'&pid='.$tmpgoods['id'].'&e='.$it618_union_tuijoin['it618_code'],'?e='.$it618_union_tuijoin['it618_code']);
					
					$copyurl='<a href="javascript:" class="goodsbtn" onclick="getcopyurl(\''.$it618_name.'\n'.$_G['siteurl'].$tmpurl.'\')" style="float:right">'.$it618_union_lang['s572'].'</a>';
					$codeurl='<a href="javascript:" class="goodsbtn" onclick="getcodeurl('.$it618_union_tuijoin['id'].','.$tmpgoods['id'].')" style="float:right;margin-left:10px">'.$it618_union_lang['s695'].'</a>';
				}else{
					$tmpurl=it618_union_getrewrite_plugin('it618_brand','brand_wap','product@'.$tmpgoods['it618_shopid'].'@0@'.$tmpgoods['id'].'@0','plugin.php?id=it618_brand:wap&pagetype=product&sid='.$tmpgoods['it618_shopid'].'&cid='.$tmpgoods['id'].'&e='.$it618_union_tuijoin['it618_code'],'?e='.$it618_union_tuijoin['it618_code']);
					
					$copyurl='<a href="javascript:" class="goodsbtn copytuiurl'.$tmpgoods['id'].'" data-clipboard-text="'.$it618_name."\n".$_G['siteurl'].$tmpurl.'" style="float:right">'.$it618_union_lang['s572'].'</a>';
					$codeurl='<a href="javascript:" class="goodsbtn" onclick="getcodeurl('.$it618_union_tuijoin['id'].','.$tmpgoods['id'].')" style="float:right;margin-left:10px">'.$it618_union_lang['s695'].'</a>';
					$pidsstr.=$tmpgoods['id'].',';
				}
			}
		}
		
		if($shoptype=='tuan'){
			$goodspic=it618_union_getgoodspic_plugin('it618_tuan',$tmpgoods['it618_shopid'],$tmpgoods['id'],$tmpgoods['it618_picbig']);
			$goodsprice=it618_union_getgoodsprice_plugin('it618_tuan',$tmpgoods);
			
			$tmpurl=it618_union_getrewrite_plugin('it618_tuan','tuan_product',$tmpgoods['id'],'plugin.php?id=it618_tuan:product&pid='.$tmpgoods['id']);
			
			if($showtype=='tuijoin'){

				if($_GET['wap']!=1){
					$tmpurl=it618_union_getrewrite_plugin('it618_tuan','tuan_product',$tmpgoods['id'],'plugin.php?id=it618_tuan:product&pid='.$tmpgoods['id'].'&e='.$it618_union_tuijoin['it618_code'],'?e='.$it618_union_tuijoin['it618_code']);
					
					$copyurl='<a href="javascript:" class="goodsbtn" onclick="getcopyurl(\''.$_G['siteurl'].$tmpurl.'\')" style="float:right">'.$it618_union_lang['s572'].'</a>';
					$codeurl='<a href="javascript:" class="goodsbtn" onclick="getcodeurl('.$it618_union_tuijoin['id'].','.$tmpgoods['id'].')" style="float:right;margin-left:10px">'.$it618_union_lang['s695'].'</a>';
				}else{
					$tmpurl=it618_union_getrewrite_plugin('it618_tuan','tuan_wap','product@'.$tmpgoods['id'],'plugin.php?id=it618_tuan:wap&pagetype=product&cid='.$tmpgoods['id'].'&e='.$it618_union_tuijoin['it618_code'],'?e='.$it618_union_tuijoin['it618_code']);
					
					$copyurl='<a href="javascript:" class="goodsbtn copytuiurl'.$tmpgoods['id'].'" data-clipboard-text="'.$it618_name."\n".$_G['siteurl'].$tmpurl.'" style="float:right">'.$it618_union_lang['s572'].'</a>';
					$codeurl='<a href="javascript:" class="goodsbtn" onclick="getcodeurl('.$it618_union_tuijoin['id'].','.$tmpgoods['id'].')" style="float:right;margin-left:10px">'.$it618_union_lang['s695'].'</a>';
					$pidsstr.=$tmpgoods['id'].',';
				}
			}
		}
		
		if($_GET['wap']!=1){
			$salestr.='<li>
			<a href="'.$tmpurl.'" target="_blank"><img src="'.$goodspic.'"/></a>
			<div>'.$tmpgoods['it618_name'].'<br>'.$goodsprice.'</div>
			<span class="spanbtn">'.$codeurl.$copyurl.'</span>
			</li>';
		}else{			
			$salestr.='<tr><td width="76">
						<a href="'.$tmpurl.'"><img src="'.$goodspic.'" height="76" style="border-radius:3px;margin-right:10px"/></a>
						</td>
						<td>
						<font style="color:#333;font-size:14px;line-height:15px">'.$tmpgoods['it618_name'].'</font>
						<div style="padding-top:18px;">'.$goodsprice.'</div>
						<div style="padding-top:6px">'.$codeurl.$copyurl.'</div>
						</td></tr>';
		}
		
	}
	
}

$_G['mobiletpl'][2]='/';
include template('it618_union:showgoods');
?>