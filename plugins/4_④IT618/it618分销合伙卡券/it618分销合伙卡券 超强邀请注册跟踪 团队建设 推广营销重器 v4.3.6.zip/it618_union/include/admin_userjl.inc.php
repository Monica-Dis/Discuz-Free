<?php
(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) && exit('Access Denied');
$tempabc=$_GET['identifier'];$reabc=array();
for($i=0;$i<strlen($tempabc);$i++){$reabc[]=substr($tempabc,$i,1);}
if($reabc[5]!='_')return;
require_once DISCUZ_ROOT.'./source/plugin/it618_union/function.func.php';

$urlsql='&uid='.$_GET['uid'].'&it618_time1='.$_GET['it618_time1'].'&it618_time2='.$_GET['it618_time2'];
if($reabc[6]!='u')return;

if(submitcheck('it618sercsubmit')){
	$ppp = $it618_union['pagecount'];
	$page = 1;
	$startlimit = 0;
}

showformheader("plugins&findbtn=1&identifier=$identifier&cp=admin_userjl&pmod=admin_userjl&operation=$operation&do=$do&page=$page".$urlsql);
showtableheaders($it618_union_lang['s88'],'it618_regsafe_checks');
	showsubmit('it618sercsubmit', $it618_union_lang['s89'], $it618_union_lang['s90'].' <input name="uid" style="width:50px" value="'.$_GET['uid'].'" class="txt" /> '.$it618_union_lang['s91'].' <input id="it618_time1" name="it618_time1" class="txt" style="width:80px;margin-right:0" readonly="readonly" value="'.$_GET['it618_time1'].'" /> - <input id="it618_time2" name="it618_time2" class="txt" style="width:80px;" readonly="readonly" value="'.$_GET['it618_time2'].'"/>');
	if($reabc[8]!='i')return;
	$count=C::t('#it618_union#it618_union_jl')->count_by_search($it618sql,'',$_GET['uid'], $_GET['it618_time1'], $_GET['it618_time2']);
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_userjl&pmod=admin_userjl&operation=$operation&do=$do".$urlsql);
	
	echo '<tr><td colspan=8>'.$it618_union_lang['s92'].$count.'</td></tr>';
	showsubtitle(array($it618_union_lang['s293'], $it618_union_lang['s294'],$it618_union_lang['s295'],$it618_union_lang['s296'],$it618_union_lang['s297'],$it618_union_lang['s298']));
	
	foreach(C::t('#it618_union#it618_union_jl')->fetch_all_by_search(
		$it618sql,'id desc',$_GET['uid'], $_GET['it618_time1'], $_GET['it618_time2'],$startlimit,$ppp
	) as $it618_union_jl) {
		
		$salestr='';
		for($i=1;$i<=8;$i++){
			if($_G['setting']['extcredits'][$i]['title']!=''&&$it618_union_jl['it618_credit'.$i]>0){
				$salestr.='<font color=red>'.$it618_union_jl['it618_credit'.$i].'</font> '.$_G['setting']['extcredits'][$i]['title'].', ';
			}
		}
		if($salestr!=''){
			$salestr=$salestr.'@';
			$salestr=str_replace(', @','',$salestr);
		}

		showtablerow('', array('', '', '', '', ''), array(
			'<a href="'.it618_union_rewriteurl($it618_union_jl['it618_uid']).'" target="_blank">'.it618_union_getusername($it618_union_jl['it618_uid']).'</a>',
			'<a href="'.it618_union_rewriteurl($it618_union_jl['it618_tuiuidfind']).'" target="_blank">'.it618_union_getusername($it618_union_jl['it618_tuiuidfind']).'</a>',
			$it618_union_jl['it618_jltype'],
			'<a href="'.it618_union_rewriteurl($it618_union_jl['it618_tuiuid']).'" target="_blank">'.it618_union_getusername($it618_union_jl['it618_tuiuid']).'</a>',
			$salestr,
			date('Y-m-d H:i:s', $it618_union_jl['it618_time'])
		));
	}

echo '<tr><td colspan="15"><div class="cuspages right">'.$multipage.'</div><div class="fixsel"><input type=hidden value='.$page.' name=page /></div><br></td></tr>';

	if(count($reabc)!=11)return;
	showtablefooter();
	echo '<script charset="utf-8" src="source/plugin/it618_union/js/laydate/laydate.js"></script>
	<script>
	laydate.render({
	  elem: "#it618_time1"
	});
	laydate.render({
	  elem: "#it618_time2"
	});
	</script>';
?>